"""
Tests für Phase A1 — Semantic Kernel des Execution Graph IR.

Testet:
- GraphScope und Layer-Isolation (models.py)
- Neue NodeTypes und EdgeTypes (models.py)
- SnapshotNode und SnapshotDAG (models.py)
- Ontology Layer (ontology.py)
- Identity Layer Erweiterungen (identity.py)
- Builder mit Ontology-Validierung (builder.py)
"""

from __future__ import annotations

import pytest
from datetime import datetime, timezone
from typing import Any, Dict, List

from core.ir.models import (
    NodeType, EdgeType, ExecutionNode, ExecutionEdge,
    ExecutionGraphIR, GraphDiff, DiffType, DiffEntry,
    GraphScope, SnapshotNode, SnapshotDAG,
    NODE_TYPE_TO_SCOPE,
)
from core.ir.ontology import (
    OntologyRule, OntologyRegistry, OntologyValidator,
    GraphSchemaValidator, OntologyError, SchemaError,
)
from core.ir.builder import IRBuilder
from core.ir.identity import IdentityGenerator, IdentityNormalizer


# =============================================================================
# Hilfsfunktionen
# =============================================================================

def make_node(node_id: str, node_type: NodeType, label: str = "",
              metadata: Dict[str, Any] = None) -> ExecutionNode:
    return ExecutionNode(
        node_id=node_id, node_type=node_type, label=label or node_id,
        metadata=metadata or {},
    )


def make_edge(edge_type: EdgeType, source_id: str, target_id: str) -> ExecutionEdge:
    return ExecutionEdge(edge_type=edge_type, source_id=source_id, target_id=target_id)


def make_graph(graph_id: str = "test", source: str = "test",
               nodes: Dict[str, ExecutionNode] = None,
               edges: List[ExecutionEdge] = None,
               timestamp: str = None) -> ExecutionGraphIR:
    return ExecutionGraphIR(
        graph_id=graph_id,
        source=source,
        timestamp=timestamp or datetime.now(timezone.utc).isoformat(),
        nodes=nodes or {},
        edges=edges or [],
    )


# =============================================================================
# GraphScope & Layer-Isolation
# =============================================================================

class TestGraphScope:
    """Testet die 6 Layer des Semantic Kernel."""

    def test_all_scopes_defined(self):
        """Alle 6 Scopes müssen existieren."""
        expected = {
            GraphScope.INTENT,
            GraphScope.ARCHITECTURE,
            GraphScope.EXECUTION,
            GraphScope.RUNTIME,
            GraphScope.GOVERNANCE,
            GraphScope.TEMPORAL,
        }
        assert set(GraphScope) == expected

    def test_node_type_to_scope_mapping(self):
        """Jeder NodeType muss einem Scope zugeordnet sein (ausser ANY, das ein Wildcard ist)."""
        for nt in NodeType:
            if nt == NodeType.ANY:
                continue  # ANY ist ein Wildcard für Ontology-Regeln, kein echter NodeType
            assert nt in NODE_TYPE_TO_SCOPE, f"{nt} fehlt in NODE_TYPE_TO_SCOPE"

    def test_scope_on_execution_node(self):
        """ExecutionNode.scope muss automatisch gesetzt werden."""
        node = make_node("intent:test", NodeType.INTENT, "Test Intent")
        assert node.scope == GraphScope.INTENT

    def test_scope_fallback_to_execution(self):
        """ARTIFACT ist im ARCHITECTURE-Scope (siehe NODE_TYPE_TO_SCOPE)."""
        node = make_node("artifact:test", NodeType.ARTIFACT, "Test Artifact")
        assert node.scope == GraphScope.ARCHITECTURE

    def test_get_nodes_by_scope(self):
        """get_nodes_by_scope() muss korrekt filtern."""
        intent_node = make_node("intent:test", NodeType.INTENT, "Test")
        adr_node = make_node("adr:test", NodeType.ADR, "Test ADR")
        graph = make_graph(
            graph_id="test_scope",
            nodes={"intent:test": intent_node, "adr:test": adr_node},
        )
        intent_nodes = graph.get_nodes_by_scope(GraphScope.INTENT)
        assert "intent:test" in intent_nodes
        # ADR ist auch INTENT-Scope
        assert "adr:test" in intent_nodes

    def test_get_layer_graph(self):
        """get_layer_graph() muss einen isolierten Subgraph zurückgeben."""
        intent_node = make_node("intent:test", NodeType.INTENT, "Test")
        task_node = make_node("task:test", NodeType.TASK, "Test Task")
        edge = make_edge(EdgeType.DERIVES, "intent:test", "task:test")
        graph = make_graph(
            graph_id="test_layer",
            nodes={"intent:test": intent_node, "task:test": task_node},
            edges=[edge],
        )
        layer_graph = graph.get_layer_graph(GraphScope.INTENT)
        assert "intent:test" in layer_graph.nodes
        assert "task:test" not in layer_graph.nodes


# =============================================================================
# Neue NodeTypes & EdgeTypes
# =============================================================================

class TestNewNodeTypes:
    """Testet die 12 neuen NodeTypes."""

    def test_intent_node(self):
        """INTENT-Node im INTENT-Scope."""
        node = make_node("intent:vision_2030", NodeType.INTENT, "Vision 2030",
                         {"priority": "high"})
        assert node.scope == GraphScope.INTENT
        assert node.node_type == NodeType.INTENT

    def test_adr_node(self):
        """ADR-Node im INTENT-Scope (siehe NODE_TYPE_TO_SCOPE)."""
        node = make_node("adr:use_postgres", NodeType.ADR, "Use PostgreSQL")
        assert node.scope == GraphScope.INTENT

    def test_constraint_node(self):
        """CONSTRAINT-Node im GOVERNANCE-Scope."""
        node = make_node("constraint:no_rm_rf", NodeType.CONSTRAINT, "No rm -rf")
        assert node.scope == GraphScope.GOVERNANCE

    def test_vision_node(self):
        """VISION-Node im INTENT-Scope."""
        node = make_node("vision:ai_first", NodeType.VISION, "AI-First Platform")
        assert node.scope == GraphScope.INTENT

    def test_capability_node(self):
        """CAPABILITY-Node im ARCHITECTURE-Scope."""
        node = make_node("capability:auth", NodeType.CAPABILITY, "Authentication")
        assert node.scope == GraphScope.ARCHITECTURE

    def test_contract_node(self):
        """CONTRACT-Node im ARCHITECTURE-Scope (siehe NODE_TYPE_TO_SCOPE)."""
        node = make_node("contract:api_v1", NodeType.CONTRACT, "API v1 Contract")
        assert node.scope == GraphScope.ARCHITECTURE

    def test_task_node(self):
        """TASK-Node im EXECUTION-Scope."""
        node = make_node("task:implement_login", NodeType.TASK, "Implement Login")
        assert node.scope == GraphScope.EXECUTION

    def test_gap_node(self):
        """GAP-Node im EXECUTION-Scope (siehe NODE_TYPE_TO_SCOPE)."""
        node = make_node("gap:missing_tests", NodeType.GAP, "Missing Tests")
        assert node.scope == GraphScope.EXECUTION

    def test_coverage_node(self):
        """COVERAGE-Node im EXECUTION-Scope (siehe NODE_TYPE_TO_SCOPE)."""
        node = make_node("coverage:auth_tested", NodeType.COVERAGE, "Auth Tested")
        assert node.scope == GraphScope.EXECUTION

    def test_violation_node(self):
        """VIOLATION-Node im RUNTIME-Scope (siehe NODE_TYPE_TO_SCOPE)."""
        node = make_node("violation:constraint_xyz", NodeType.VIOLATION,
                         "Constraint XYZ Violated")
        assert node.scope == GraphScope.RUNTIME

    def test_drift_node(self):
        """DRIFT_NODE im RUNTIME-Scope (siehe NODE_TYPE_TO_SCOPE)."""
        node = make_node("drift:runtime_vs_design", NodeType.DRIFT_NODE,
                         "Runtime vs Design Drift")
        assert node.scope == GraphScope.RUNTIME

    def test_snapshot_node_type(self):
        """SNAPSHOT-Node im TEMPORAL-Scope."""
        node = make_node("snapshot:v1.0", NodeType.SNAPSHOT, "Release v1.0")
        assert node.scope == GraphScope.TEMPORAL


class TestNewEdgeTypes:
    """Testet die 15 neuen EdgeTypes."""

    def test_satisfies_edge(self):
        edge = make_edge(EdgeType.SATISFIES, "a", "b")
        assert edge.edge_type == EdgeType.SATISFIES

    def test_violates_edge(self):
        edge = make_edge(EdgeType.VIOLATES, "a", "b")
        assert edge.edge_type == EdgeType.VIOLATES

    def test_derives_edge(self):
        edge = make_edge(EdgeType.DERIVES, "a", "b")
        assert edge.edge_type == EdgeType.DERIVES

    def test_governs_edge(self):
        edge = make_edge(EdgeType.GOVERNS, "a", "b")
        assert edge.edge_type == EdgeType.GOVERNS

    def test_requires_edge(self):
        edge = make_edge(EdgeType.REQUIRES, "a", "b")
        assert edge.edge_type == EdgeType.REQUIRES

    def test_provides_edge(self):
        edge = make_edge(EdgeType.PROVIDES, "a", "b")
        assert edge.edge_type == EdgeType.PROVIDES

    def test_conflicts_edge(self):
        edge = make_edge(EdgeType.CONFLICTS, "a", "b")
        assert edge.edge_type == EdgeType.CONFLICTS

    def test_approves_edge(self):
        edge = make_edge(EdgeType.APPROVES, "a", "b")
        assert edge.edge_type == EdgeType.APPROVES

    def test_blocks_edge(self):
        edge = make_edge(EdgeType.BLOCKS, "a", "b")
        assert edge.edge_type == EdgeType.BLOCKS

    def test_compiles_to_edge(self):
        edge = make_edge(EdgeType.COMPILES_TO, "a", "b")
        assert edge.edge_type == EdgeType.COMPILES_TO

    def test_produces_edge(self):
        edge = make_edge(EdgeType.PRODUCES, "a", "b")
        assert edge.edge_type == EdgeType.PRODUCES

    def test_consumes_edge(self):
        edge = make_edge(EdgeType.CONSUMES, "a", "b")
        assert edge.edge_type == EdgeType.CONSUMES

    def test_deviates_edge(self):
        edge = make_edge(EdgeType.DEVIATES, "a", "b")
        assert edge.edge_type == EdgeType.DEVIATES

    def test_verifies_edge(self):
        edge = make_edge(EdgeType.VERIFIES, "a", "b")
        assert edge.edge_type == EdgeType.VERIFIES

    def test_breaks_edge(self):
        edge = make_edge(EdgeType.BREAKS, "a", "b")
        assert edge.edge_type == EdgeType.BREAKS


# =============================================================================
# SnapshotNode & SnapshotDAG
# =============================================================================

class TestSnapshotNode:
    """Testet den immutable Snapshot-Container."""

    def test_snapshot_creation(self):
        """SnapshotNode muss direkt erstellbar sein (kein from_graph)."""
        graph = make_graph(graph_id="test", source="test")
        snapshot = SnapshotNode(
            snapshot_id="snap_test123",
            parent_ids=[],
            graph=graph,
            label="v1.0",
        )
        assert snapshot.label == "v1.0"
        assert snapshot.snapshot_id == "snap_test123"
        assert snapshot.parent_ids == []
        assert snapshot.content_hash  # Muss einen Hash haben

    def test_snapshot_content_addressed(self):
        """SnapshotNode.content_hash muss deterministisch sein."""
        graph = make_graph(graph_id="test", source="test",
                           timestamp="2025-01-01T00:00:00Z")
        s1 = SnapshotNode(
            snapshot_id="snap_a", parent_ids=[], graph=graph, label="v1",
        )
        s2 = SnapshotNode(
            snapshot_id="snap_b", parent_ids=[], graph=graph, label="v1",
        )
        assert s1.content_hash == s2.content_hash

    def test_snapshot_immutable(self):
        """SnapshotNode muss frozen sein (immutable)."""
        graph = make_graph(graph_id="test", source="test")
        snapshot = SnapshotNode(
            snapshot_id="snap_test", parent_ids=[], graph=graph, label="v1",
        )
        with pytest.raises(Exception):
            snapshot.label = "changed"  # type: ignore

    def test_snapshot_serialization(self):
        """SnapshotNode.to_dict/from_dict Roundtrip."""
        graph = make_graph(graph_id="test", source="test",
                           timestamp="2025-01-01T00:00:00Z")
        original = SnapshotNode(
            snapshot_id="snap_test", parent_ids=[], graph=graph, label="v1",
        )
        data = original.to_dict()
        restored = SnapshotNode.from_dict(data)
        assert restored.snapshot_id == original.snapshot_id
        assert restored.content_hash == original.content_hash
        assert restored.label == original.label


class TestSnapshotDAG:
    """Testet den DAG-basierten Snapshot-Versionsgraphen."""

    def test_empty_dag(self):
        """Ein leerer DAG hat keine Snapshots."""
        dag = SnapshotDAG()
        assert dag.snapshots == {}
        assert dag.head_ids == []

    def test_add_first_snapshot(self):
        """Der erste Snapshot wird automatisch Head."""
        dag = SnapshotDAG()
        graph = make_graph(graph_id="test", source="test",
                           timestamp="2025-01-01T00:00:00Z")
        snapshot = dag.add_snapshot(graph, label="v1")
        assert snapshot.snapshot_id in dag.snapshots
        assert snapshot.snapshot_id in dag.head_ids
        assert snapshot.parent_ids == []

    def test_add_child_snapshot(self):
        """Ein zweiter Snapshot wird Kind des ersten."""
        dag = SnapshotDAG()
        graph1 = make_graph(graph_id="test", source="test",
                            timestamp="2025-01-01T00:00:00Z")
        s1 = dag.add_snapshot(graph1, label="v1")

        # graph2 muss anderen Inhalt haben (sonst gleicher content_hash -> idempotent)
        graph2_nodes = {
            "intent:goal": make_node("intent:goal", NodeType.INTENT, "Goal"),
        }
        graph2 = make_graph(graph_id="test", source="test",
                            nodes=graph2_nodes,
                            timestamp="2025-01-02T00:00:00Z")
        s2 = dag.add_snapshot(graph2, label="v2", parent_ids=[s1.snapshot_id])
        assert s1.snapshot_id in s2.parent_ids
        # s2 ist der neue Head (add_snapshot setzt head_ids = [neuer_snapshot])
        assert s2.snapshot_id in dag.head_ids
        assert s1.snapshot_id not in dag.head_ids

    def test_get_lineage(self):
        """get_lineage() muss die Vorfahren-Kette liefern."""
        dag = SnapshotDAG()
        graph1 = make_graph(graph_id="test", source="test",
                            timestamp="2025-01-01T00:00:00Z")
        s1 = dag.add_snapshot(graph1, label="v1")
        graph2 = make_graph(graph_id="test", source="test",
                            timestamp="2025-01-02T00:00:00Z")
        s2 = dag.add_snapshot(graph2, label="v2", parent_ids=[s1.snapshot_id])
        graph3 = make_graph(graph_id="test", source="test",
                            timestamp="2025-01-03T00:00:00Z")
        s3 = dag.add_snapshot(graph3, label="v3", parent_ids=[s2.snapshot_id])

        lineage = dag.get_lineage(s3.snapshot_id)
        lineage_ids = [s.snapshot_id for s in lineage]
        assert s1.snapshot_id in lineage_ids
        assert s2.snapshot_id in lineage_ids
        assert s3.snapshot_id in lineage_ids

    def test_get_branch(self):
        """get_branch() muss alle Nachkommen liefern."""
        dag = SnapshotDAG()
        graph1 = make_graph(graph_id="test", source="test",
                            timestamp="2025-01-01T00:00:00Z")
        s1 = dag.add_snapshot(graph1, label="v1")
        graph2 = make_graph(graph_id="test", source="test",
                            timestamp="2025-01-02T00:00:00Z")
        s2 = dag.add_snapshot(graph2, label="v2", parent_ids=[s1.snapshot_id])
        graph3 = make_graph(graph_id="test", source="test",
                            timestamp="2025-01-03T00:00:00Z")
        s3 = dag.add_snapshot(graph3, label="v3", parent_ids=[s1.snapshot_id])

        branch = dag.get_branch(s1.snapshot_id)
        branch_ids = [s.snapshot_id for s in branch]
        assert s2.snapshot_id in branch_ids
        assert s3.snapshot_id in branch_ids

    def test_dag_serialization(self):
        """SnapshotDAG.to_dict/from_dict Roundtrip."""
        dag = SnapshotDAG()
        graph1 = make_graph(graph_id="test", source="test",
                            timestamp="2025-01-01T00:00:00Z")
        dag.add_snapshot(graph1, label="v1")
        # Zweiter Graph mit anderem Inhalt (unterschiedliche Nodes -> anderer Hash)
        n1 = make_node("n1", NodeType.INTENT, "Node 1")
        graph2 = make_graph(graph_id="test", source="test",
                            timestamp="2025-01-02T00:00:00Z",
                            nodes={"n1": n1})
        dag.add_snapshot(graph2, label="v2")

        data = dag.to_dict()
        assert len(data["snapshots"]) == 2
        restored = SnapshotDAG.from_dict(data)
        assert len(restored.snapshots) == 2
        for sid, snap in dag.snapshots.items():
            assert sid in restored.snapshots
            assert snap.content_hash == restored.snapshots[sid].content_hash


# =============================================================================
# Ontology Layer
# =============================================================================

class TestOntologyRegistry:
    """Testet die Ontology-Registry mit Default-Regeln."""

    def test_default_registry_has_rules(self):
        """Die Default-Registry muss ~50 Regeln enthalten."""
        registry = OntologyRegistry()
        assert len(registry._rules) >= 45

    def test_is_allowed_valid(self):
        """is_allowed() muss korrekt validieren."""
        registry = OntologyRegistry()
        assert registry.is_allowed(NodeType.INTENT, EdgeType.DERIVES, NodeType.ADR)
        assert not registry.is_allowed(NodeType.INTENT, EdgeType.PRODUCES, NodeType.ADR)

    def test_is_allowed_no_match(self):
        """Unmoegliche Kombination gibt False."""
        registry = OntologyRegistry()
        # INTENT -> SNAPSHOT sollte nur REFERENCE/SYNC erlauben
        assert not registry.is_allowed(NodeType.INTENT, EdgeType.DERIVES, NodeType.SNAPSHOT)

    def test_any_wildcard(self):
        """REFERENCE und SYNC muessen als ANY-Wildcard funktionieren."""
        registry = OntologyRegistry()
        assert registry.is_allowed(NodeType.INTENT, EdgeType.REFERENCE, NodeType.ADR)
        assert registry.is_allowed(NodeType.ADR, EdgeType.REFERENCE, NodeType.TASK)
        assert registry.is_allowed(NodeType.INTENT, EdgeType.SYNC, NodeType.SNAPSHOT)

    def test_get_allowed_edges(self):
        """get_allowed_edges() muss alle erlaubten Kanten fuer einen NodeType liefern."""
        registry = OntologyRegistry()
        allowed = registry.get_allowed_edges(NodeType.INTENT)
        assert len(allowed) > 0
        edge_types = {e for e, _ in allowed}
        assert EdgeType.DERIVES in edge_types


class TestOntologyValidator:
    """Testet den OntologyValidator."""

    def test_validate_valid_graph(self):
        """Ein gueltiger Graph darf keine Fehler produzieren."""
        validator = OntologyValidator()
        nodes = {
            "intent:goal": make_node("intent:goal", NodeType.INTENT, "Goal"),
            "adr:arch": make_node("adr:arch", NodeType.ADR, "Arch Decision"),
        }
        edges = [make_edge(EdgeType.DERIVES, "intent:goal", "adr:arch")]
        graph = make_graph(nodes=nodes, edges=edges)
        errors = validator.validate_graph(graph)
        assert len(errors) == 0

    def test_validate_invalid_edge(self):
        """Ein ungueltiger Edge-Typ muss Fehler produzieren."""
        validator = OntologyValidator()
        nodes = {
            "intent:goal": make_node("intent:goal", NodeType.INTENT, "Goal"),
            "adr:arch": make_node("adr:arch", NodeType.ADR, "Arch Decision"),
        }
        edges = [make_edge(EdgeType.PRODUCES, "intent:goal", "adr:arch")]
        graph = make_graph(nodes=nodes, edges=edges)
        errors = validator.validate_graph(graph)
        assert len(errors) > 0
        assert any("PRODUCES" in str(e) for e in errors)

    def test_validate_graph_strict(self):
        """validate_graph_strict() muss ValueError werfen (OntologyError ist ein dataclass, keine Exception)."""
        validator = OntologyValidator()
        nodes = {
            "intent:goal": make_node("intent:goal", NodeType.INTENT, "Goal"),
            "adr:arch": make_node("adr:arch", NodeType.ADR, "Arch Decision"),
        }
        edges = [make_edge(EdgeType.PRODUCES, "intent:goal", "adr:arch")]
        graph = make_graph(nodes=nodes, edges=edges)
        with pytest.raises(ValueError, match="Ontology-Validierung fehlgeschlagen"):
            validator.validate_graph_strict(graph)


class TestGraphSchemaValidator:
    """Testet den GraphSchemaValidator."""

    def test_valid_graph_no_errors(self):
        """Ein wohlgeformter Graph darf keine Schema-Fehler haben.
        Setze entry_points explizit, da __post_init__ dies nicht automatisch tut."""
        validator = GraphSchemaValidator()
        nodes = {
            "intent:goal": make_node("intent:goal", NodeType.INTENT, "Goal"),
            "adr:arch": make_node("adr:arch", NodeType.ADR, "Arch Decision"),
        }
        edges = [make_edge(EdgeType.DERIVES, "intent:goal", "adr:arch")]
        graph = make_graph(nodes=nodes, edges=edges)
        # entry_points wird nicht automatisch gesetzt -> setze es explizit
        object.__setattr__(graph, "entry_points", ["intent:goal"])
        errors = validator.validate(graph)
        assert len(errors) == 0, f"Unerwartete Fehler: {errors}"

    def test_orphaned_node_detected(self):
        """Ein einzelner Knoten ohne Kanten wird bei >1 Knoten als orphaned erkannt.
        Bei nur einem Knoten und keinen Kanten ist es kein orphan (es ist der einzige)."""
        validator = GraphSchemaValidator()
        nodes = {
            "intent:goal": make_node("intent:goal", NodeType.INTENT, "Goal"),
            "task:impl": make_node("task:impl", NodeType.TASK, "Implement"),
        }
        edges = []
        graph = make_graph(nodes=nodes, edges=edges)
        # entry_points explizit setzen, da der Graph sonst den missing_entry_points-Fehler wirft
        object.__setattr__(graph, "entry_points", ["intent:goal", "task:impl"])
        errors = validator.validate(graph)
        # Die Message enthält "keine Verbindungen" (deutsch), nicht "orphaned"
        orphaned = [e for e in errors if "keine Verbindungen" in e.message]
        assert len(orphaned) > 0

    def test_cycle_detected(self):
        """Ein Zyklus muss erkannt werden (via graph.has_cycles).
        Der Validator meldet Zyklen nur im Governance/Intent-Layer."""
        validator = GraphSchemaValidator()
        # POLICY-Nodes haben governance scope (nur dort werden Zyklen gemeldet)
        nodes = {
            "a": make_node("a", NodeType.POLICY, "Policy A"),
            "b": make_node("b", NodeType.POLICY, "Policy B"),
        }
        edges = [
            make_edge(EdgeType.DEPENDENCY, "a", "b"),
            make_edge(EdgeType.DEPENDENCY, "b", "a"),
        ]
        graph = make_graph(nodes=nodes, edges=edges)
        # has_cycles muss explizit gesetzt werden (wird nicht automatisch erkannt)
        object.__setattr__(graph, "has_cycles", True)
        object.__setattr__(graph, "entry_points", [])
        errors = validator.validate(graph)
        cycle = [e for e in errors if "Zyklus" in e.message]
        assert len(cycle) > 0


# =============================================================================
# Identity Layer Erweiterungen
# =============================================================================

class TestIdentityGeneratorExtensions:
    """Testet die neuen Factory-Methoden im IdentityGenerator."""

    def test_for_intent(self):
        nid = IdentityGenerator.for_intent("Vision 2030")
        assert nid.startswith("intent:")
        assert "vision_2030" in nid

    def test_for_adr(self):
        nid = IdentityGenerator.for_adr("Use PostgreSQL")
        assert nid.startswith("adr:")
        assert "use_postgresql" in nid

    def test_for_constraint(self):
        """Hinweis: _normalize ersetzt Leerzeichen durch _, behält - bei."""
        nid = IdentityGenerator.for_constraint("No rm -rf")
        assert nid.startswith("constraint:")
        assert "no_rm" in nid

    def test_for_vision(self):
        """Hinweis: _normalize wandelt in lowercase um, behält - bei."""
        nid = IdentityGenerator.for_vision("AI-First Platform")
        assert nid.startswith("vision:")
        assert "ai" in nid and "platform" in nid

    def test_for_capability(self):
        nid = IdentityGenerator.for_capability("Authentication")
        assert nid.startswith("capability:")
        assert "authentication" in nid

    def test_for_contract(self):
        nid = IdentityGenerator.for_contract("API v1")
        assert nid.startswith("contract:")
        assert "api_v1" in nid

    def test_for_task(self):
        nid = IdentityGenerator.for_task("Implement Login")
        assert nid.startswith("task:")
        assert "implement_login" in nid

    def test_for_gap(self):
        nid = IdentityGenerator.for_gap("Missing Tests")
        assert nid.startswith("gap:")
        assert "missing_tests" in nid

    def test_for_coverage(self):
        nid = IdentityGenerator.for_coverage("Auth Tested")
        assert nid.startswith("coverage:")
        assert "auth_tested" in nid

    def test_for_violation(self):
        nid = IdentityGenerator.for_violation("Constraint XYZ")
        assert nid.startswith("violation:")
        assert "constraint_xyz" in nid

    def test_for_drift(self):
        nid = IdentityGenerator.for_drift("Runtime vs Design")
        assert nid.startswith("drift:")
        assert "runtime_vs_design" in nid

    def test_for_snapshot(self):
        nid = IdentityGenerator.for_snapshot("Release v1.0")
        assert nid.startswith("snapshot:")
        assert "release_v1_0" in nid


class TestIdentityNormalizerExtensions:
    """Testet die erweiterte Prefix-Konvertierung."""

    def test_prefix_to_node_type_new_types(self):
        """Alle neuen Prefixe muessen korrekt gemappt werden."""
        mappings = [
            ("intent", "INTENT"),
            ("adr", "ADR"),
            ("constraint", "CONSTRAINT"),
            ("vision", "VISION"),
            ("capability", "CAPABILITY"),
            ("contract", "CONTRACT"),
            ("task", "TASK"),
            ("gap", "GAP"),
            ("coverage", "COVERAGE"),
            ("violation", "VIOLATION"),
            ("drift", "DRIFT_NODE"),
            ("snapshot", "SNAPSHOT"),
        ]
        for prefix, expected_type in mappings:
            result = IdentityNormalizer.prefix_to_node_type(prefix)
            assert result == expected_type, (
                f"prefix '{prefix}' -> {result}, expected {expected_type}"
            )

    def test_prefix_to_node_type_unknown(self):
        """Unbekannter Prefix muss None zurueckgeben."""
        result = IdentityNormalizer.prefix_to_node_type("unknown_xyz")
        assert result is None


# =============================================================================
# Builder mit Ontology-Validierung
# =============================================================================

class TestIRBuilderWithOntology:
    """Testet den IRBuilder mit integrierter Ontology-Validierung."""

    def test_builder_valid_graph(self):
        """Builder akzeptiert gueltige Ontology-Kanten."""
        builder = IRBuilder()
        nodes = [
            make_node("intent:goal", NodeType.INTENT, "Goal"),
            make_node("adr:arch", NodeType.ADR, "Arch Decision"),
        ]
        edges = [make_edge(EdgeType.DERIVES, "intent:goal", "adr:arch")]
        graph = builder.from_nodes_and_edges(nodes, edges, strict=True)
        assert graph is not None
        assert len(graph.nodes) == 2
        assert len(graph.edges) == 1

    def test_builder_rejects_invalid_edge(self):
        """Builder wirft ValueError bei ungueltiger Ontology-Kante (strict=True)."""
        builder = IRBuilder()
        nodes = [
            make_node("intent:goal", NodeType.INTENT, "Goal"),
            make_node("adr:arch", NodeType.ADR, "Arch Decision"),
        ]
        edges = [make_edge(EdgeType.PRODUCES, "intent:goal", "adr:arch")]
        with pytest.raises(ValueError, match="Ontology-Validierung fehlgeschlagen"):
            builder.from_nodes_and_edges(nodes, edges, strict=True)

    def test_builder_allows_invalid_edge_non_strict(self):
        """Builder ignoriert Ontology-Fehler bei strict=False."""
        builder = IRBuilder()
        nodes = [
            make_node("intent:goal", NodeType.INTENT, "Goal"),
            make_node("adr:arch", NodeType.ADR, "Arch Decision"),
        ]
        edges = [make_edge(EdgeType.PRODUCES, "intent:goal", "adr:arch")]
        graph = builder.from_nodes_and_edges(nodes, edges, strict=False)
        assert graph is not None

    def test_builder_scope_auto_assigned(self):
        """Builder muss Scope automatisch setzen (via __post_init__)."""
        builder = IRBuilder()
        nodes = [make_node("intent:goal", NodeType.INTENT, "Goal")]
        graph = builder.from_nodes_and_edges(nodes, [], strict=False)
        node = graph.nodes["intent:goal"]
        assert node.scope == GraphScope.INTENT

    def test_builder_cross_layer_graph(self):
        """Builder erstellt korrekt einen Cross-Layer-Graphen."""
        builder = IRBuilder()
        nodes = [
            make_node("intent:v", NodeType.VISION, "Vision"),
            make_node("intent:goal", NodeType.INTENT, "Goal"),
            make_node("adr:a", NodeType.ADR, "ADR-001"),
            make_node("task:t", NodeType.TASK, "Task"),
            make_node("cap:c", NodeType.CAPABILITY, "Cap"),
        ]
        edges = [
            # VISION --[derives]--> INTENT (erlaubt)
            make_edge(EdgeType.DERIVES, "intent:v", "intent:goal"),
            # INTENT --[derives]--> ADR (erlaubt)
            make_edge(EdgeType.DERIVES, "intent:goal", "adr:a"),
            # INTENT --[derives]--> TASK (erlaubt)
            make_edge(EdgeType.DERIVES, "intent:goal", "task:t"),
            # INTENT --[requires]--> CAPABILITY (erlaubt)
            make_edge(EdgeType.REQUIRES, "intent:goal", "cap:c"),
        ]
        graph = builder.from_nodes_and_edges(nodes, edges, strict=True)
        assert len(graph.nodes) == 5
        assert len(graph.edges) == 4

        intent_layer = graph.get_layer_graph(GraphScope.INTENT)
        assert "intent:v" in intent_layer.nodes
        assert "intent:goal" in intent_layer.nodes
        assert "adr:a" in intent_layer.nodes

        arch_layer = graph.get_layer_graph(GraphScope.ARCHITECTURE)
        assert "cap:c" in arch_layer.nodes

        exec_layer = graph.get_layer_graph(GraphScope.EXECUTION)
        assert "task:t" in exec_layer.nodes


# =============================================================================
# Integration: Intent -> Architecture -> Execution Pipeline
# =============================================================================

class TestIntentToExecutionPipeline:
    """Integrationstest fuer die vollstaendige Intent->Execution-Pipeline."""

    def test_full_pipeline_graph(self):
        """Erstelle einen vollstaendigen Pipeline-Graphen ueber alle Layer."""
        builder = IRBuilder()

        # Layer 1: Intent
        vision = make_node("vision:ai_platform", NodeType.VISION, "AI Platform Vision",
                           {"priority": "P0", "timeline": "2026"})
        intent = make_node("intent:auth_system", NodeType.INTENT, "Build Auth System",
                           {"goal": "Secure authentication"})

        # Layer 2: Architecture
        adr = make_node("adr:use_oauth2", NodeType.ADR, "Use OAuth2",
                        {"status": "approved"})
        # COMPONENT statt CAPABILITY — COMPONENT kann PROVIDES und VALIDATES
        component = make_node("component:oauth_module", NodeType.COMPONENT,
                              "OAuth2 Module", {"version": "2.0"})

        # Layer 3: Execution
        task = make_node("task:implement_oauth", NodeType.TASK, "Implement OAuth2",
                         {"effort": "3d", "assignee": "team-a"})

        # Layer 4: Runtime
        contract = make_node("contract:oauth_api", NodeType.CONTRACT,
                             "OAuth2 API Contract", {"endpoint": "/auth/oauth2"})

        # Layer 5: Governance
        constraint = make_node("constraint:no_plaintext", NodeType.CONSTRAINT,
                               "No Plaintext Secrets", {"severity": "blocker"})

        # Layer 6: Temporal
        snapshot = make_node("snapshot:sprint_12", NodeType.SNAPSHOT,
                             "Sprint 12 Baseline")

        nodes = [vision, intent, adr, component, task, contract, constraint, snapshot]

        # Cross-Layer Edges (Ontology-konform)
        edges = [
            # Intent Layer: VISION --[derives]--> INTENT
            make_edge(EdgeType.DERIVES, "vision:ai_platform", "intent:auth_system"),
            # Architecture: ADR --[derives]--> CONSTRAINT, COMPONENT --[satisfies]--> INTENT
            make_edge(EdgeType.DERIVES, "adr:use_oauth2", "constraint:no_plaintext"),
            make_edge(EdgeType.SATISFIES, "component:oauth_module", "intent:auth_system"),
            # Execution: INTENT --[derives]--> TASK
            make_edge(EdgeType.DERIVES, "intent:auth_system", "task:implement_oauth"),
            # Runtime: COMPONENT --[validates]--> CONTRACT
            make_edge(EdgeType.VALIDATES, "component:oauth_module", "contract:oauth_api"),
            # Governance: CONSTRAINT --[blocks]--> TASK
            make_edge(EdgeType.BLOCKS, "constraint:no_plaintext", "task:implement_oauth"),
            # Temporal: SNAPSHOT --[reference]--> TASK (per ANY-Wildcard erlaubt)
            make_edge(EdgeType.REFERENCE, "snapshot:sprint_12", "task:implement_oauth"),
        ]

        graph = builder.from_nodes_and_edges(nodes, edges, strict=True)

        # Assert all layers present
        assert len(graph.nodes) == 8
        assert len(graph.edges) == 7

        # Layer isolation
        # INTENT: vision, intent, adr (ADR ist INTENT scope)
        assert len(graph.get_nodes_by_scope(GraphScope.INTENT)) == 3
        # ARCHITECTURE: contract (COMPONENT ist RUNTIME, ADR ist INTENT)
        assert len(graph.get_nodes_by_scope(GraphScope.ARCHITECTURE)) == 1
        # EXECUTION: task
        assert len(graph.get_nodes_by_scope(GraphScope.EXECUTION)) == 1
        # RUNTIME: component
        assert len(graph.get_nodes_by_scope(GraphScope.RUNTIME)) == 1
        # GOVERNANCE: constraint
        assert len(graph.get_nodes_by_scope(GraphScope.GOVERNANCE)) == 1
        # TEMPORAL: snapshot
        assert len(graph.get_nodes_by_scope(GraphScope.TEMPORAL)) == 1

        # Cross-layer edges
        intent_edges = [e for e in graph.edges if e.source_id == "vision:ai_platform" and e.target_id == "intent:auth_system"]
        assert len(intent_edges) == 1
        assert intent_edges[0].edge_type == EdgeType.DERIVES

        # ADR --[derives]--> CONSTRAINT
        adr_edges = [e for e in graph.edges if e.source_id == "adr:use_oauth2"]
        assert len(adr_edges) == 1
        assert adr_edges[0].edge_type == EdgeType.DERIVES

        # COMPONENT --[validates]--> CONTRACT
        runtime_edges = [e for e in graph.edges if e.source_id == "component:oauth_module" and e.target_id == "contract:oauth_api"]
        assert len(runtime_edges) == 1
        assert runtime_edges[0].edge_type == EdgeType.VALIDATES

        # Governance: CONSTRAINT --[blocks]--> TASK
        gov_edges = [e for e in graph.edges if e.edge_type == EdgeType.BLOCKS]
        assert len(gov_edges) == 1
        assert gov_edges[0].source_id == "constraint:no_plaintext"

        # Temporal: REFERENCE
        temp_edges = [e for e in graph.edges if e.edge_type == EdgeType.REFERENCE]
        assert len(temp_edges) == 1
        assert temp_edges[0].source_id == "snapshot:sprint_12"

    def test_snapshot_dag_with_pipeline(self):
        """SnapshotDAG mit Pipeline-Graphen (content-addressed)."""
        dag = SnapshotDAG()

        # Version 1: Nur Intent
        v1_nodes = {
            "int-001": make_node("int-001", NodeType.INTENT, "Feature X"),
        }
        v1_edges = []
        v1_graph = make_graph("pipeline", "test", v1_nodes, v1_edges)

        # add_snapshot akzeptiert KEIN snapshot_id keyword (wird aus content_hash generiert)
        s1 = dag.add_snapshot(v1_graph, label="Initial Intent")
        snap_v1_id = s1.snapshot_id  # z.B. "snap_<hash>"

        # Version 2: Intent + Architecture
        v2_nodes = {
            "int-001": make_node("int-001", NodeType.INTENT, "Feature X"),
            "arch-001": make_node("arch-001", NodeType.ADR, "ADR-001"),
        }
        v2_edges = [
            make_edge(EdgeType.DERIVES, "int-001", "arch-001"),
        ]
        v2_graph = make_graph("pipeline", "test", v2_nodes, v2_edges)

        s2 = dag.add_snapshot(v2_graph, parent_ids=[snap_v1_id], label="With Architecture")
        snap_v2_id = s2.snapshot_id

        # Version 3: Full pipeline
        v3_nodes = {
            "int-001": make_node("int-001", NodeType.INTENT, "Feature X"),
            "arch-001": make_node("arch-001", NodeType.ADR, "ADR-001"),
            "exec-001": make_node("exec-001", NodeType.TASK, "Implement"),
            "run-001": make_node("run-001", NodeType.CONTRACT, "Runtime Contract"),
        }
        v3_edges = [
            make_edge(EdgeType.DERIVES, "int-001", "arch-001"),
            make_edge(EdgeType.COMPILES_TO, "arch-001", "exec-001"),
            make_edge(EdgeType.PRODUCES, "exec-001", "run-001"),
        ]
        v3_graph = make_graph("pipeline", "test", v3_nodes, v3_edges)

        s3 = dag.add_snapshot(v3_graph, parent_ids=[snap_v2_id], label="Full Pipeline")
        snap_v3_id = s3.snapshot_id

        # Assert DAG structure (3 unique content-addressed snapshots)
        assert len(dag.snapshots) == 3
        assert snap_v1_id in dag.snapshots
        assert snap_v2_id in dag.snapshots
        assert snap_v3_id in dag.snapshots

        # Head should be v3 only (v1 and v2 have children)
        assert snap_v3_id in dag.head_ids
        assert snap_v1_id not in dag.head_ids
        assert snap_v2_id not in dag.head_ids

        # Lineage from v3 (DFS post-order: parents zuerst, dann child)
        lineage = dag.get_lineage(snap_v3_id)
        assert len(lineage) == 3
        assert lineage[0].snapshot_id == snap_v1_id  # root zuerst
        assert lineage[-1].snapshot_id == snap_v3_id  # leaf zuletzt

        # Branch from v1
        branch = dag.get_branch(snap_v1_id)
        assert len(branch) == 3  # v1 -> v2 -> v3

        # Diff between v1 and v3
        diff = dag.diff_between(snap_v1_id, snap_v3_id)
        assert diff is not None
        assert len(diff.added_nodes) >= 3  # arch-001, exec-001, run-001 added
        assert len(diff.added_edges) >= 3  # 3 new edges
