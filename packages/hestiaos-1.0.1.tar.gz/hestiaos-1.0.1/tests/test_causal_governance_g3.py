"""
G3 — Causal Governance & Shadow Mode Invariant Tests.

Prüft die kausale Vorhersage-Pipeline und den Shadow Mode:
🔴 INV-G3-001: Shadow Mode Non-Interference
🟡 INV-G3-002: Drift Propagation Logic
🟢 INV-G3-003: Deterministic Expansion
"""

import pytest
from core.governance.causal_kernel import causal_kernel, CausalImpactReport, CausalBias
from core.governance.system_mode import SystemMode, DriftVector
from core.governance.dsgk_decision import DSGKDecision, DecisionType, build_decision
from core.bootstrap.control_plane import CanonicalState, SystemCondition, SystemSignals
from core.bootstrap.models import BootState
from core.bootstrap.arbitrator import SystemArbitrator, ArbitrationResult
from core.processing.network_error_classifier import CircuitState

class MockCommand:
    def __init__(self, command_type: str):
        self.command_type = command_type

def test_causal_expansion_heuristics():
    """INV-G3-003: Gleicher Command = Gleiche Expansion."""
    cmd = MockCommand("write")
    context = {}
    
    expansion1 = causal_kernel.expand(cmd, context)
    expansion2 = causal_kernel.expand(cmd, context)
    
    assert expansion1 == expansion2
    assert len(expansion1) == 2
    assert expansion1[0]["type"] == "write"
    assert expansion1[1]["type"] == "read"

def test_causal_drift_propagation():
    """INV-G3-002: Drift Propagation wird im Report abgebildet."""
    cmd = MockCommand("code_exec")
    report = causal_kernel.analyze(cmd, {})
    
    # code_exec + memory expansion sollte Drift-Bias erzeugen
    assert report.instability_prediction.system_drift > 0.0
    assert report.risk_projection > 0.1
    assert SystemMode.DEGRADED in report.mode_shift_probability

def test_shadow_mode_non_interference():
    """INV-G3-001: G3 darf G2-Ergebnis im Shadow Mode nicht verändern."""
    arb = SystemArbitrator()
    decision = build_decision(violations=[], risk_score=0.1, reason="OK", policy="test")
    
    signals = SystemSignals(boot_state=BootState.READY, db_ready=True, migrations_ok=True)
    state = CanonicalState(condition=SystemCondition.GREEN, priority_vector=[0,0,0,0,0], signals=signals, message="All good")
    
    # Report mit hohem Risiko
    heavy_report = CausalImpactReport(risk_projection=0.9, confidence=1.0)
    heavy_bias = causal_kernel.project_to_governance(heavy_report)
    
    # Ohne G3
    outcome_no_g3 = arb.arbitrate(
        dsgk=decision,
        control_state=state,
        circuit_state=CircuitState.CLOSED,
        drift_vector=None
    )
    
    # Mit G3 (Shadow Mode)
    outcome_with_g3 = arb.arbitrate(
        dsgk=decision,
        control_state=state,
        circuit_state=CircuitState.CLOSED,
        drift_vector=None,
        causal_report=heavy_report,
        causal_bias=heavy_bias
    )
    
    assert outcome_with_g3.result == outcome_no_g3.result
    assert outcome_with_g3.causal_report == heavy_report

def test_causal_bias_projection():
    """Stage 3: Mapping von Report zu Bias."""
    report = CausalImpactReport(risk_projection=0.5)
    bias = causal_kernel.project_to_governance(report)
    
    assert bias.risk_offset == 0.25  # 0.5 * 0.5
    assert bias.sensitivity_multiplier == 2.0  # 1.0 + (0.5 * 2.0)
    assert bias.is_shadow_mode is True
