
import asyncio
import aiohttp
import sys
import json
import time

API_URL = "http://localhost:8000/chat/stream"

async def start_complex_task(session, i):
    payload = {
        "message": "Write a very complex python script to calculate fibonacci with dynamic programming and explain it.",
        "use_tools": True
    }
    print(f"[{i}] Starting request...")
    try:
        async with session.post(API_URL, json=payload, timeout=2.0) as response:
            async for line in response.content:
                if line:
                    decoded = line.decode('utf-8')
                    print(f"[{i}] Token: {decoded[:50]}...")
    except asyncio.TimeoutError:
        print(f"[{i}] CANCELLED (Timeout simulated)")
    except Exception as e:
        print(f"[{i}] Error: {e}")

async def test_cancellation():
    async with aiohttp.ClientSession() as session:
        # 1. Start a task and kill it
        print("--- Step 1: Start and Cancel ---")
        await start_complex_task(session, 1)
        
        # Wait a moment for server to process cancellation
        await asyncio.sleep(1)
        
        # 2. Check Metrics
        print("\n--- Step 2: Check Metrics ---")
        async with session.get("http://localhost:8000/metrics") as response:
            text = await response.text()
            print(text)
            if "core01_cancellations_total 1" in text or "core01_cancellations_total 1.0" in text:
                 print("SUCCESS: Cancellation recorded.")
            else:
                 print("WARNING: Cancellation count mismatch.")

        # 3. Start another task immediately (Deadlock check)
        print("\n--- Step 3: Deadlock Check (New Request) ---")
        # This one should run longer to prove it works
        payload = {
            "message": "List files",
            "use_tools": True
        }
        try:
            async with session.post(API_URL, json=payload) as response:
                 print(f"Status: {response.status}")
                 async for line in response.content:
                     print(f"Received: {line.decode('utf-8').strip()}")
                 print("SUCCESS: System is alive.")
        except Exception as e:
            print(f"FAIL: System seems dead locked. Error: {e}")

if __name__ == "__main__":
    asyncio.run(test_cancellation())
