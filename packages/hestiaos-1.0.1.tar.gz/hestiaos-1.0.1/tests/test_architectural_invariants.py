import pytest
from core.governance.command_processor import process_command
from core.commands.base import Command, CommandType
from core.governance.invariant_checker import invariant_checker
from core.governance.command_trace_store import command_trace_store

class TestArchitecturalInvariants:
    """
    Formal Verification Tests for the HestiaOS Kernel.
    Ensures that the 5-layer governance structure is impenetrable.
    """

    def test_invariant_causal_locking(self):
        """INV-SYSTEM-003: Every execution MUST have a causal epoch."""
        cmd = Command(command_type=CommandType.READ, payload={"target": "test"})
        trace = process_command(cmd)
        
        violations = invariant_checker.verify_trace(trace)
        assert len(violations) == 0, f"Invariant Violation: {violations}"
        assert trace.epoch_id is not None
        assert trace.epoch_id.startswith("ep_")

    def test_invariant_policy_consistency(self):
        """INV-GOV-001: Every execution MUST have a canon-backed policy context."""
        cmd = Command(command_type=CommandType.WRITE, payload={"target": "test"})
        trace = process_command(cmd)
        
        assert trace.policy_context is not None
        assert trace.policy_context.policy_id == "core.write.v1"
        assert trace.policy_context.policy_version == "1.0.0"

    def test_history_integrity(self):
        """INV-CAUSAL-001: The causal graph must be consistent (no orphans)."""
        # 1. Root Command
        cmd1 = Command(command_type=CommandType.READ, payload={"id": 1})
        trace1 = process_command(cmd1)
        
        # 2. Child Command
        cmd2 = Command(command_type=CommandType.WRITE, payload={"id": 2})
        trace2 = process_command(cmd2, parent_id=trace1.cmd_id)
        
        # 3. Verify via Invariant Checker
        history = [trace1, trace2]
        report = invariant_checker.verify_history(history)
        
        assert report["is_valid"] is True
        assert report["stats"]["total_traces"] == 2

    def test_detection_of_orphaned_causality(self):
        """Verifies that the checker detects broken causal chains."""
        cmd = Command(command_type=CommandType.READ, payload={"id": 1})
        trace = process_command(cmd, parent_id="non-existent-id")
        
        report = invariant_checker.verify_history([trace])
        assert report["is_valid"] is False
        assert report["violations"][0]["invariant_id"] == "INV-CAUSAL-001"
