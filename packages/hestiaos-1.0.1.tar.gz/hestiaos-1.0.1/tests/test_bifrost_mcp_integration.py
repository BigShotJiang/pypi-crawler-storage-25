import asyncio
import os
import sys
from pathlib import Path
import json

# Pfade hinzufügen für HestiaOS Core-Module
sys.path.insert(0, str(Path(__file__).parent.parent))

from core.gateway.factory import GatewayFactory
from core.gateway.bifrost_mcp_gateway import BifrostMCPGateway
from core.observability.logger import system_logger

async def test_mcp_integration():
    """Testet die dynamische Tool Execution via BifrostMCPGateway."""
    system_logger.info("Starting Bifrost MCP Integration Test")
    
    # 1. Gateway Instanziierung über die Factory
    resilient_gateway = GatewayFactory.create_gateway()
    
    # Pruefen, ob BifrostMCPGateway korrekt initialisiert wurde als Fallback oder Primary
    bifrost = resilient_gateway.fallback if hasattr(resilient_gateway.fallback, "list_tools") else resilient_gateway.primary
    
    if not isinstance(bifrost, BifrostMCPGateway):
        system_logger.error("BifrostMCPGateway was not instantiated properly. Check config!")
        # Fallback if tests are run isolated
        from core.routing.mcp_gateway import MCPGateway
        mcp = MCPGateway()
        bifrost = BifrostMCPGateway({"url": "http://127.0.0.1:4002/v1", "api_key": "sk-hestiaos"}, tool_governor=mcp.tool_governor)
    
    # 2. Tools listen
    tools = await bifrost.list_tools()
    system_logger.info("Retrieved tools from BifrostMCPGateway via ToolGovernor", extra={"count": len(tools)})
    
    if len(tools) == 0:
        system_logger.warning("No tools available to test. Check EGL/ToolGovernor.")
    else:
        system_logger.info(f"Sample tool: {tools[0].get('function', {}).get('name')}")
        
    # 3. Simulate a chat completion that predicts a tool
    # Normalerweise würde Bifrost auf die Completion APIs antworten und unsere Pipeline würde die Tool-Calls executen.
    # Für den isolierten Test nutzen wir den direkten "execute_tool" Endpoint.
    
    system_logger.info("Testing internal execute_tool routing...")
    try:
        # We try to execute memory.get tool if available
        res = await bifrost.execute_tool("memory.get", {"user_id": "test_user", "key": "test_key"})
        system_logger.info("Tool execution via Bifrost -> MCP Gateway -> Governor successful!", extra={"result": res})
    except Exception as e:
        system_logger.error("Tool execution failed", extra={"error": str(e)})

if __name__ == "__main__":
    asyncio.run(test_mcp_integration())
