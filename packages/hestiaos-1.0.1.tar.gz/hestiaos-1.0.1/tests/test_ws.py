
import asyncio
import websockets
import sys

async def test_ws(url, origin):
    # In websockets 14+, use 'additional_headers' or just 'headers'
    # Actually, connect takes 'origin' as an explicit parameter in some versions
    print(f"Connecting to {url} with Origin {origin}...")
    try:
        async with websockets.connect(url, origin=origin) as ws:
            print("Connected successfully!")
            await ws.close()
    except Exception as e:
        print(f"Connection failed: {e}")

if __name__ == "__main__":
    url = sys.argv[1] if len(sys.argv) > 1 else "ws://localhost:8000/ws/null"
    origin = sys.argv[2] if len(sys.argv) > 2 else "http://localhost:8080"
    asyncio.run(test_ws(url, origin))
