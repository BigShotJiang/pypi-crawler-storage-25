import unittest
from core.neural_pathways import PathwayOptimizer

class TestPathwayOptimizer(unittest.TestCase):
    def setUp(self):
        self.optimizer = PathwayOptimizer()

    def test_empty_ranking(self):
        self.assertEqual(self.optimizer.rank_pathways("agent1", 0.5), ["default"])

    def test_ranking_by_success(self):
        # High success pathway should rank higher with low curiosity
        self.optimizer.update_pathway_metrics("agent1", "path_a", True, 0.1)
        self.optimizer.update_pathway_metrics("agent1", "path_b", False, 0.1)
        
        ranked = self.optimizer.rank_pathways("agent1", 0.1)
        self.assertEqual(ranked[0], "path_a")

    def test_exploration_by_curiosity(self):
        # With high curiosity, a new/untested path should rank higher
        self.optimizer.update_pathway_metrics("agent1", "well_tested", True, 0.1)
        for _ in range(10):
            self.optimizer.update_pathway_metrics("agent1", "well_tested", True, 0.1)
            
        # path_new is untested (total=0 in logic? wait, my update adds it)
        # Let's add it once
        self.optimizer.update_pathway_metrics("agent1", "path_new", True, 0.1)
        
        ranked = self.optimizer.rank_pathways("agent1", 0.9)
        # path_new has much lower total_count, so exploration bonus should be higher
        self.assertEqual(ranked[0], "path_new")

    def test_metrics_retrieval(self):
        self.optimizer.update_pathway_metrics("agent1", "path_a", True, 0.5)
        metrics = self.optimizer.get_metrics()
        self.assertIn("agent1", metrics)
        self.assertEqual(metrics["agent1"]["path_a"]["avg_latency"], 0.5)

if __name__ == "__main__":
    unittest.main()
