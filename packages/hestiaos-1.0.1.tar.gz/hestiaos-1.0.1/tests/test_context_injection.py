import pytest
import json
import asyncio
from typing import Dict, Any, Optional
from unittest.mock import MagicMock, AsyncMock
from core.orchestrator import Orchestrator
from tests.conftest import MockBackendRouter
from core.llm_engine import LLMEngine
from core.interfaces import IContextManager, IToolExecutor

class MockContextManager:
    async def load_context(self, session_id: str, user_message: str) -> Dict[str, Any]:
        return {
            "vault_context": "",
            "memory_context": [],
            "last_agent": "mediator",
            "history_summary": "",
            "preferences": {}
        }
    def is_stepwise_enabled(self, session_id: str) -> bool: return False
    def get_pending_tool_call(self, session_id: str) -> Optional[Dict]: return None
    async def set_last_active_agent(self, session_id: str, agent: str): pass

class MockToolExecutor:
    def __init__(self):
        self.execute = AsyncMock(return_value={"success": True, "result": "ok"})
        self.stream_execute = AsyncMock()
        self.get_tool_definitions = MagicMock(return_value=[])
        self.get_tools_dict = MagicMock(return_value={})

@pytest.mark.asyncio
async def test_context_header_injection():
    """Verify HESTIAOS EXECUTION CONTEXT is injected into system prompt."""
    # Setup mocks
    llm = MagicMock(spec=LLMEngine)
    ctx_mgr = MockContextManager()
    tool_exec = MockToolExecutor()
    models_cfg = {"expert": {"name": "test-expert"}}
    
    orch = Orchestrator(
        llm_engine=llm,
        context_manager=ctx_mgr,
        tool_executor=tool_exec,
        models_config=models_cfg,
        backend_router=MockBackendRouter()
    )
    
    # Test cases
    test_cases = [
        {"tenant": "business", "expected_mode": "business", "expected_assurance": "High Assurance"},
        {"tenant": "science", "expected_mode": "science", "expected_assurance": "High Assurance"},
        {"tenant": "research", "expected_mode": "science", "expected_assurance": "High Assurance"},
        {"tenant": None, "expected_mode": "community", "expected_assurance": "Experimental"},
        {"tenant": "random-corp", "expected_mode": "community", "expected_assurance": "Experimental"}
    ]
    
    for case in test_cases:
        tenant = case["tenant"]
        mode = orch._resolve_mode_from_tenant(tenant)
        header = orch._build_context_header(tenant, mode, "mediator", "test-session")
        
        assert f"TENANT: {tenant or 'default'}" in header
        assert f"MODE: {case['expected_mode']}" in header
        assert case["expected_assurance"] in header
        assert "EGL-ENFORCED" in header

if __name__ == "__main__":
    asyncio.run(test_context_header_injection())
