"""
Tests für die Artifact Replay Engine.

Testet:
    - Full Rebuild: Event Log → kompletter Artifact-Graph
    - Time-Travel: Zustand zu einem beliebigen Zeitpunkt
    - Determinismus-Prüfung: Gleicher Log → gleicher Graph
    - Einzelnes Artifact rekonstruieren
    - Event-Statistiken
    - Lebenszyklus-Analyse
    - Service Integration (execute_transformation via Service)
"""

import pytest
from datetime import datetime, timezone, timedelta

from core.artifact.models import Artifact, ArtifactType, ArtifactStatus
from core.artifact.store import ArtifactStore
from core.artifact.event_log import ArtifactEventLog
from core.artifact.service import ArtifactService
from core.artifact.replay import ReplayEngine
from core.artifact.graph import GraphScope


# =============================================================================
# Fixtures
# =============================================================================


@pytest.fixture
def store():
    s = ArtifactStore(":memory:")
    yield s
    s.close()


@pytest.fixture
def event_log(store):
    return ArtifactEventLog(store.conn)


@pytest.fixture
def service(store, event_log):
    return ArtifactService(store, event_log)


@pytest.fixture
def replay(store, event_log):
    return ReplayEngine(store, event_log)


@pytest.fixture
def populated_service(service):
    """Erzeuge einen Service mit mehreren Artifacts und Status-Änderungen."""
    # IDEA 1 → SPEC → Tasks
    idea1 = service.create_artifact(
        type=ArtifactType.IDEA,
        title="KI-Code-Review",
        content="Automatisches Code-Review mit KI",
        tags=["ai", "code-review"],
    )
    service.complete_artifact(idea1.id)
    spec1 = service.create_artifact(
        type=ArtifactType.SPEC,
        title="Spec: KI-Code-Review",
        content=idea1.content,
        parent_id=idea1.id,
    )
    tasks1 = []
    for desc in ["Datenmodell", "API", "Tests"]:
        t = service.create_artifact(
            type=ArtifactType.TASK,
            title=desc,
            content=f"Aufgabe: {desc}",
            parent_id=spec1.id,
        )
        tasks1.append(t)
    service.update_artifact_fields(tasks1[0].id, status=ArtifactStatus.ACTIVE)
    service.complete_artifact(tasks1[0].id)

    # IDEA 2 (unprocessed)
    idea2 = service.create_artifact(
        type=ArtifactType.IDEA,
        title="Dashboard",
        content="Ein Dashboard für Metriken",
        tags=["ui", "metrics"],
    )

    # DECISION
    decision = service.create_artifact(
        type=ArtifactType.DECISION,
        title="Tech-Stack Entscheidung",
        content="Python + FastAPI + SQLite",
    )
    service.complete_artifact(decision.id)

    return service


# =============================================================================
# Tests: Core Replay
# =============================================================================


class TestReplayCore:
    """Tests für die Kernfunktionen der Replay Engine."""

    def test_rebuild_empty(self, replay):
        """Leerer Event Log → leeres Dict."""
        graph = replay.rebuild_graph()
        assert graph == {}

    def test_rebuild_single_artifact(self, replay, service):
        """Ein Artifact erstellen und rekonstruieren."""
        art = service.create_artifact(
            type=ArtifactType.IDEA,
            title="Test-Idee",
            content="Beschreibung",
        )

        graph = replay.rebuild_graph()
        assert art.id in graph
        reconstructed = graph[art.id]
        assert reconstructed.title == "Test-Idee"
        assert reconstructed.type == ArtifactType.IDEA
        assert reconstructed.status == ArtifactStatus.DRAFT

    def test_rebuild_multiple_artifacts(self, replay, populated_service):
        """Mehrere Artifacts mit verschiedenen Typen rekonstruieren."""
        graph = replay.rebuild_graph()

        # Mindestens 7 Artifacts: 2 IDEAs, 1 SPEC, 3 TASKs, 1 DECISION
        assert len(graph) >= 7

        # Typen prüfen
        types = {a.type for a in graph.values()}
        assert ArtifactType.IDEA in types
        assert ArtifactType.SPEC in types
        assert ArtifactType.TASK in types
        assert ArtifactType.DECISION in types

    def test_rebuild_with_status_changes(self, replay, populated_service):
        """Status-Änderungen werden korrekt rekonstruiert."""
        graph = replay.rebuild_graph()

        # Mindestens ein Artifact sollte DONE sein
        done_artifacts = [
            a for a in graph.values()
            if a.status == ArtifactStatus.DONE
        ]
        assert len(done_artifacts) >= 1

    def test_rebuild_single_by_id(self, replay, populated_service):
        """Einzelnes Artifact per ID rekonstruieren."""
        # Erstes Artifact aus dem Service holen
        all_arts = populated_service.list_artifacts()
        target = all_arts[0]

        reconstructed = replay.rebuild_single(target.id)
        assert reconstructed is not None
        assert reconstructed.id == target.id
        assert reconstructed.title == target.title
        assert reconstructed.type == target.type

    def test_rebuild_nonexistent(self, replay):
        """Nicht-existierendes Artifact gibt None zurück."""
        result = replay.rebuild_single("nonexistent")
        assert result is None


# =============================================================================
# Tests: Time-Travel
# =============================================================================


class TestReplayTimeTravel:
    """Tests für die Time-Travel-Funktionalität."""

    def test_rebuild_at_time_before_creation(self, replay, service):
        """Vor der Erstellung eines Artifacts existiert es nicht."""
        art = service.create_artifact(
            type=ArtifactType.IDEA,
            title="Spätere Idee",
            content="Content",
        )

        # Zeitstempel vor der Erstellung
        early_time = "2020-01-01T00:00:00Z"
        graph = replay.rebuild_at_time(early_time)
        assert art.id not in graph

    def test_rebuild_at_time_after_creation(self, replay, service):
        """Nach der Erstellung ist das Artifact vorhanden."""
        art = service.create_artifact(
            type=ArtifactType.IDEA,
            title="Test",
            content="Content",
        )

        late_time = "2030-01-01T00:00:00Z"
        graph = replay.rebuild_at_time(late_time)
        assert art.id in graph

    def test_rebuild_at_time_between_events(self, replay, service):
        """Zustand zwischen zwei Events rekonstruieren."""
        art = service.create_artifact(
            type=ArtifactType.IDEA,
            title="Meine Idee",
            content="Content",
        )

        # Status ändern
        service.complete_artifact(art.id)

        # Zustand NACH creation aber VOR complete_artifact
        # Wir müssen den genauen Timestamp kennen
        events = service.event_log.get_artifact_timeline(art.id)
        creation_time = None
        status_change_time = None
        for e in events:
            if e["event_type"] == "created":
                creation_time = e["created_at"]
            elif e["event_type"] == "status_changed":
                status_change_time = e["created_at"]

        assert creation_time is not None
        assert status_change_time is not None

        # Zustand zwischen creation und status_change
        between = replay.rebuild_at_time(creation_time)
        assert between[art.id].status == ArtifactStatus.DRAFT

        # Zustand nach status_change
        after = replay.rebuild_at_time(status_change_time)
        assert after[art.id].status == ArtifactStatus.DONE

    def test_get_artifact_at_time(self, replay, service):
        """Artifact zu einem bestimmten Zeitpunkt abfragen."""
        art = service.create_artifact(
            type=ArtifactType.IDEA,
            title="Test",
            content="Content",
        )
        service.complete_artifact(art.id)

        events = service.event_log.get_artifact_timeline(art.id)
        creation_time = None
        for e in events:
            if e["event_type"] == "created":
                creation_time = e["created_at"]
                break

        assert creation_time is not None

        # Vor status_change
        before = replay.get_artifact_at_time(art.id, creation_time)
        assert before is not None
        assert before.status == ArtifactStatus.DRAFT

        # Aktuell
        current = replay.get_artifact_at_time(art.id, "2030-01-01T00:00:00Z")
        assert current is not None
        assert current.status == ArtifactStatus.DONE


# =============================================================================
# Tests: Determinismus
# =============================================================================


class TestReplayDeterminism:
    """Tests für die Determinismus-Prüfung."""

    def test_determinism_empty(self, replay):
        """Leerer Event Log ist deterministisch."""
        assert replay.verify_determinism()

    def test_determinism_with_data(self, replay, populated_service):
        """Gefüllter Event Log ist deterministisch."""
        assert replay.verify_determinism()

    def test_determinism_detailed(self, replay, populated_service):
        """Detaillierte Determinismus-Prüfung."""
        result = replay.verify_determinism_detailed()
        assert result["deterministic"] is True
        assert result["total_artifacts"] >= 7
        assert len(result["mismatches"]) == 0
        assert result["replay_duration_ms"] > 0


# =============================================================================
# Tests: Event-Statistiken
# =============================================================================


class TestReplayStatistics:
    """Tests für die Event-Statistiken."""

    def test_statistics_empty(self, replay):
        """Leerer Event Log."""
        stats = replay.get_event_statistics()
        assert stats["total_events"] == 0
        assert stats["total_artifacts"] == 0

    def test_statistics_with_data(self, replay, populated_service):
        """Gefüllter Event Log."""
        stats = replay.get_event_statistics()
        assert stats["total_events"] > 0
        assert stats["total_artifacts"] >= 7
        assert "created" in stats["events_by_type"]
        assert "status_changed" in stats["events_by_type"]
        assert stats["time_range"] is not None
        assert stats["time_range"]["first"] is not None
        assert stats["time_range"]["last"] is not None
        assert stats["avg_events_per_artifact"] > 0


# =============================================================================
# Tests: Lebenszyklus
# =============================================================================


class TestReplayLifecycle:
    """Tests für die Lebenszyklus-Analyse."""

    def test_lifecycle_nonexistent(self, replay):
        """Nicht-existierendes Artifact."""
        lc = replay.get_artifact_lifecycle("nonexistent")
        assert lc["exists"] is False
        assert lc["total_events"] == 0

    def test_lifecycle_created_only(self, replay, service):
        """Artifact nur erstellt, nie geändert."""
        art = service.create_artifact(
            type=ArtifactType.IDEA,
            title="Einfache Idee",
            content="Content",
        )

        lc = replay.get_artifact_lifecycle(art.id)
        assert lc["exists"] is True
        assert lc["total_events"] == 1
        assert lc["created_at"] is not None
        assert lc["deleted_at"] is None
        assert len(lc["status_sequence"]) == 1  # draft

    def test_lifecycle_with_changes(self, replay, populated_service):
        """Artifact mit mehreren Status-Änderungen."""
        all_arts = populated_service.list_artifacts()
        # Finde ein Artifact mit Status-Änderungen
        for art in all_arts:
            lc = replay.get_artifact_lifecycle(art.id)
            if lc["total_events"] > 1:
                assert lc["exists"] is True
                assert lc["created_at"] is not None
                assert len(lc["status_sequence"]) >= 1
                return

        # Falls keins gefunden (sollte nicht passieren)
        pytest.skip("Kein Artifact mit mehreren Events gefunden")

    def test_lifecycle_current_state(self, replay, populated_service):
        """current_state entspricht dem aktuellen Zustand."""
        all_arts = populated_service.list_artifacts()
        target = all_arts[0]

        lc = replay.get_artifact_lifecycle(target.id)
        assert lc["current_state"] is not None
        assert lc["current_state"].id == target.id
        assert lc["current_state"].status == target.status


# =============================================================================
# Tests: Service Integration
# =============================================================================


class TestServiceTransformationIntegration:
    """Tests für die Service-Integration der TransformationEngine."""

    def test_execute_transformation_via_service(self, service):
        """Transformation über den Service ausführen."""
        idea = service.create_artifact(
            type=ArtifactType.IDEA,
            title="Test-Idee",
            content="Content",
        )

        result = service.execute_transformation(
            idea.id,
            "idea_to_spec",
        )

        assert result.success
        assert result.primary is not None
        assert result.primary.type == ArtifactType.SPEC

    def test_service_can_transform(self, service):
        """can_transform über den Service."""
        idea = service.create_artifact(
            type=ArtifactType.IDEA,
            title="Test",
            content="Content",
        )

        assert service.can_transform(idea, "idea_to_spec")
        assert not service.can_transform(idea, "nonexistent")

    def test_service_list_transformations(self, service):
        """Verfügbare Transformationen über den Service listen."""
        transformations = service.list_transformations()
        assert "idea_to_spec" in transformations
        assert "spec_to_task_graph" in transformations
        assert "merge_artifacts" in transformations

    def test_service_full_pipeline(self, service):
        """Vollständige Pipeline über den Service."""
        idea = service.create_artifact(
            type=ArtifactType.IDEA,
            title="Pipeline-Test",
            content="Content",
        )

        # IDEA → SPEC
        spec_result = service.execute_transformation(idea.id, "idea_to_spec")
        assert spec_result.success
        spec = spec_result.primary

        # SPEC → Tasks
        task_result = service.execute_transformation(
            spec.id,
            "spec_to_task_graph",
            task_descriptions=["Task 1", "Task 2"],
        )
        assert task_result.success
        assert len(task_result.secondary) == 2

    def test_service_transformation_preserves_event_log(self, service):
        """Transformationen über den Service schreiben in den Event Log."""
        idea = service.create_artifact(
            type=ArtifactType.IDEA,
            title="Test",
            content="Content",
        )

        events_before = service.event_log.count_events()

        service.execute_transformation(idea.id, "idea_to_spec")

        events_after = service.event_log.count_events()
        assert events_after > events_before
