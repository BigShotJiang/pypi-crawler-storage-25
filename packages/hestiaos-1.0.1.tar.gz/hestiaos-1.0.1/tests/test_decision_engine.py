#!/usr/bin/env python3
"""
Tests für die DecisionEngine (CI-CRT-016 / Execution Control Plane).

Test-Suite nach Referenz-Implementation aus dem Execution Control Plane Architecture.
Alle 5 Tests müssen 100% grün sein.

Architektur-Invarianten (getestet):
1. CI-CRT ist Signal-Generator, keine Decision Engine
2. Gate 2 ist einzige Entscheidungsinstanz
3. Severity wird immer im Gate berechnet (derive_severity)
4. Unknown Reachability ist konservativ (None → high)
5. Jede Entscheidung MUSS ein AuditEntry erzeugen
6. DecisionContext.timestamp ist NICHT entscheidungsrelevant
"""

import pytest
from core.governance.decision_engine import (
    DecisionEngine,
    DecisionContext,
    DriftSignal,
    AuditEntry,
)


# ──────────────────────────────────────────────
# Fixtures
# ──────────────────────────────────────────────

@pytest.fixture
def engine() -> DecisionEngine:
    return DecisionEngine()


@pytest.fixture
def strict_context() -> DecisionContext:
    return DecisionContext(
        environment="prod",
        enforcement_mode="strict",
        request_id="test-001",
    )


@pytest.fixture
def permissive_context() -> DecisionContext:
    return DecisionContext(
        environment="dev",
        enforcement_mode="permissive",
        request_id="test-002",
    )


# ──────────────────────────────────────────────
# Test 1: Determinismus
# ──────────────────────────────────────────────

class TestDecisionDeterminism:
    """Gleiche Inputs → identische Entscheidung (auch bei timestamp-Variation)."""

    def test_decision_determinism(self, engine: DecisionEngine) -> None:
        """Gleiche DriftSignale + gleicher Context → identische Entscheidung."""
        signal = DriftSignal(
            drift_detected=True,
            drift_type="A",
            reachable=True,
            ast_confidence=0.95,
        )
        context = DecisionContext(
            environment="prod",
            enforcement_mode="strict",
            request_id="det-test",
        )

        entry_1 = engine.decide(signal, context)
        entry_2 = engine.decide(signal, context)

        assert entry_1.decision == entry_2.decision
        assert entry_1.derived_severity == entry_2.derived_severity
        assert entry_1.decision_reason == entry_2.decision_reason
        assert entry_1.decision_factors == entry_2.decision_factors

    def test_timestamp_not_decision_relevant(self, engine: DecisionEngine) -> None:
        """timestamp-Variation darf Entscheidung nicht ändern."""
        signal = DriftSignal(
            drift_detected=True,
            drift_type="B",
            reachable=True,
            ast_confidence=0.90,
        )
        context_1 = DecisionContext(
            environment="prod",
            enforcement_mode="strict",
            request_id="ts-test",
            timestamp="2025-01-01T00:00:00Z",
        )
        context_2 = DecisionContext(
            environment="prod",
            enforcement_mode="strict",
            request_id="ts-test",
            timestamp="2025-06-15T12:30:00Z",
        )

        entry_1 = engine.decide(signal, context_1)
        entry_2 = engine.decide(signal, context_2)

        assert entry_1.decision == entry_2.decision
        assert entry_1.derived_severity == entry_2.derived_severity


# ──────────────────────────────────────────────
# Test 2: Unknown Reachability → BLOCK
# ──────────────────────────────────────────────

class TestUnknownReachability:
    """reachable=None → konservativ BLOCK (sound over complete)."""

    def test_unknown_reachability_is_blocked(
        self, engine: DecisionEngine, strict_context: DecisionContext
    ) -> None:
        """reachable=None bei Drift → severity=high → BLOCK."""
        signal = DriftSignal(
            drift_detected=True,
            drift_type="A3",
            reachable=None,
            ast_confidence=0.80,
        )

        entry = engine.decide(signal, strict_context)

        assert entry.derived_severity == "high"
        assert entry.decision == "BLOCK"
        assert entry.decision_factors["policy_rule"] == "strict:high"

    def test_unknown_reachability_permissive(
        self, engine: DecisionEngine, permissive_context: DecisionContext
    ) -> None:
        """reachable=None → severity=high → permissive: ALLOW_WITH_ANNOTATION."""
        signal = DriftSignal(
            drift_detected=True,
            drift_type="A3",
            reachable=None,
            ast_confidence=0.80,
        )

        entry = engine.decide(signal, permissive_context)

        assert entry.derived_severity == "high"
        assert entry.decision == "ALLOW_WITH_ANNOTATION"


# ──────────────────────────────────────────────
# Test 3: Context beeinflusst Entscheidung
# ──────────────────────────────────────────────

class TestContextAffectsDecision:
    """strict vs permissive → unterschiedliche Entscheidung bei gleichem Signal."""

    def test_context_affects_decision(self, engine: DecisionEngine) -> None:
        """Gleiches Signal, unterschiedlicher Mode → unterschiedliche Entscheidung."""
        signal = DriftSignal(
            drift_detected=True,
            drift_type="A",
            reachable=True,
            ast_confidence=0.95,
        )
        strict_ctx = DecisionContext(
            environment="prod",
            enforcement_mode="strict",
            request_id="ctx-test-1",
        )
        permissive_ctx = DecisionContext(
            environment="dev",
            enforcement_mode="permissive",
            request_id="ctx-test-2",
        )

        strict_entry = engine.decide(signal, strict_ctx)
        permissive_entry = engine.decide(signal, permissive_ctx)

        # Gleiche severity, aber unterschiedliche Entscheidung
        assert strict_entry.derived_severity == permissive_entry.derived_severity
        assert strict_entry.decision != permissive_entry.decision
        assert strict_entry.decision == "BLOCK"
        assert permissive_entry.decision == "ALLOW_WITH_ANNOTATION"


# ──────────────────────────────────────────────
# Test 4: Kein Drift → immer ALLOW
# ──────────────────────────────────────────────

class TestNoDrift:
    """Kein Drift → severity=none → immer ALLOW (egal welcher Mode)."""

    def test_no_drift_always_allow_strict(
        self, engine: DecisionEngine, strict_context: DecisionContext
    ) -> None:
        """Kein Drift, strict → ALLOW."""
        signal = DriftSignal(
            drift_detected=False,
            drift_type=None,
            reachable=True,
            ast_confidence=1.0,
        )

        entry = engine.decide(signal, strict_context)

        assert entry.derived_severity == "none"
        assert entry.decision == "ALLOW"

    def test_no_drift_always_allow_permissive(
        self, engine: DecisionEngine, permissive_context: DecisionContext
    ) -> None:
        """Kein Drift, permissive → ALLOW."""
        signal = DriftSignal(
            drift_detected=False,
            drift_type=None,
            reachable=True,
            ast_confidence=1.0,
        )

        entry = engine.decide(signal, permissive_context)

        assert entry.derived_severity == "none"
        assert entry.decision == "ALLOW"


# ──────────────────────────────────────────────
# Test 5: CFG kann Unsicherheit nicht downgraden
# ──────────────────────────────────────────────

class TestCFGCannotDowngradeUncertainty:
    """Unsicherheit (reachable=None) > Typ — CFG darf nicht entschärfen.

    derive_severity() Reihenfolge:
    1. Kein Drift → none
    2. reachable=None → high (Unsicherheit > Typ)
    3. Drift A/B → high
    4. reachable=False → low
    5. Sonst → medium
    """

    def test_cfg_cannot_downgrade_uncertainty(
        self, engine: DecisionEngine, strict_context: DecisionContext
    ) -> None:
        """reachable=None → high, auch wenn drift_type=C (weniger kritisch)."""
        signal = DriftSignal(
            drift_detected=True,
            drift_type="C",  # Weniger kritisch als A/B
            reachable=None,  # Aber nicht beweisbar unreachable
            ast_confidence=0.75,
        )

        entry = engine.decide(signal, strict_context)

        # Unsicherheit dominiert → high → BLOCK
        assert entry.derived_severity == "high", (
            f"Erwartet high, bekommen {entry.derived_severity}. "
            f"Reihenfolge: reachable=None MUSS vor drift_type-Check kommen."
        )
        assert entry.decision == "BLOCK"

    def test_proven_dead_code_low_severity(
        self, engine: DecisionEngine, strict_context: DecisionContext
    ) -> None:
        """reachable=False bei Drift A/B → severity=high (A/B dominiert Dead Code).

        Rule 3 (drift_type in ("A", "B") → high) kommt vor
        Rule 4 (reachable=False → low). A/B ist immer kritisch.
        """
        signal = DriftSignal(
            drift_detected=True,
            drift_type="A",
            reachable=False,  # CFG hat bewiesen: Dead Code
            ast_confidence=0.95,
        )

        entry = engine.decide(signal, strict_context)

        # A/B dominiert → high, auch wenn Dead Code
        assert entry.derived_severity == "high"
        assert entry.decision == "BLOCK"

    def test_proven_dead_code_non_ab_low_severity(
        self, engine: DecisionEngine, strict_context: DecisionContext
    ) -> None:
        """reachable=False bei Drift C/D → low → ALLOW_WITH_ANNOTATION.

        Rule 3 matched nicht (C/D sind nicht A/B),
        Rule 4 matched (reachable=False) → low.
        """
        signal = DriftSignal(
            drift_detected=True,
            drift_type="C",
            reachable=False,  # CFG hat bewiesen: Dead Code
            ast_confidence=0.85,
        )

        entry = engine.decide(signal, strict_context)

        assert entry.derived_severity == "low"
        assert entry.decision == "ALLOW_WITH_ANNOTATION"

    def test_uncertainty_over_type_ordering(
        self, engine: DecisionEngine, strict_context: DecisionContext
    ) -> None:
        """Expliziter Test der derive_severity()-Reihenfolge.

        reachable=None MUSS vor drift_type geprüft werden.
        """
        # Signal mit reachable=None + drift_type=A
        signal_a_unknown = DriftSignal(
            drift_detected=True,
            drift_type="A",
            reachable=None,
            ast_confidence=0.90,
        )
        # Signal mit reachable=True + drift_type=A
        signal_a_reachable = DriftSignal(
            drift_detected=True,
            drift_type="A",
            reachable=True,
            ast_confidence=0.90,
        )

        sev_unknown = engine.derive_severity(signal_a_unknown)
        sev_reachable = engine.derive_severity(signal_a_reachable)

        # Beide sind high (A + reachable=None → high, A + reachable=True → high)
        # Aber der Pfad ist unterschiedlich:
        # unknown: Rule 2 (reachable=None) matched zuerst
        # reachable: Rule 3 (drift_type=A) matched
        assert sev_unknown == "high"
        assert sev_reachable == "high"


# ──────────────────────────────────────────────
# Zusätzliche Tests: derive_severity() isoliert
# ──────────────────────────────────────────────

class TestDeriveSeverity:
    """Isolierte Tests für derive_severity() — alle Pfade."""

    def test_no_drift(self, engine: DecisionEngine) -> None:
        signal = DriftSignal(False, None, True, 1.0)
        assert engine.derive_severity(signal) == "none"

    def test_drift_unknown_reachability(self, engine: DecisionEngine) -> None:
        signal = DriftSignal(True, "A3", None, 0.80)
        assert engine.derive_severity(signal) == "high"

    def test_drift_a_reachable(self, engine: DecisionEngine) -> None:
        signal = DriftSignal(True, "A", True, 0.95)
        assert engine.derive_severity(signal) == "high"

    def test_drift_b_reachable(self, engine: DecisionEngine) -> None:
        signal = DriftSignal(True, "B", True, 0.90)
        assert engine.derive_severity(signal) == "high"

    def test_drift_c_reachable(self, engine: DecisionEngine) -> None:
        signal = DriftSignal(True, "C", True, 0.85)
        assert engine.derive_severity(signal) == "medium"

    def test_drift_d_reachable(self, engine: DecisionEngine) -> None:
        signal = DriftSignal(True, "D", True, 0.80)
        assert engine.derive_severity(signal) == "medium"

    def test_drift_a_dead_code(self, engine: DecisionEngine) -> None:
        """Drift A + Dead Code → high (A/B dominiert)."""
        signal = DriftSignal(True, "A", False, 0.95)
        assert engine.derive_severity(signal) == "high"

    def test_drift_b_dead_code(self, engine: DecisionEngine) -> None:
        """Drift B + Dead Code → high (A/B dominiert)."""
        signal = DriftSignal(True, "B", False, 0.90)
        assert engine.derive_severity(signal) == "high"

    def test_drift_c_dead_code(self, engine: DecisionEngine) -> None:
        signal = DriftSignal(True, "C", False, 0.85)
        assert engine.derive_severity(signal) == "low"


# ──────────────────────────────────────────────
# Zusätzliche Tests: AuditEntry Struktur
# ──────────────────────────────────────────────

class TestAuditEntry:
    """Jede Entscheidung MUSS ein vollständiges AuditEntry erzeugen."""

    def test_audit_entry_has_all_fields(
        self, engine: DecisionEngine, strict_context: DecisionContext
    ) -> None:
        signal = DriftSignal(True, "A", True, 0.95)
        entry = engine.decide(signal, strict_context)

        assert isinstance(entry, AuditEntry)
        assert entry.request_id == "test-001"
        assert entry.decision_context is strict_context
        assert entry.drift_signal is signal
        assert entry.derived_severity == "high"
        assert entry.decision == "BLOCK"
        assert isinstance(entry.decision_reason, str)
        assert len(entry.decision_reason) > 0
        assert isinstance(entry.decision_factors, dict)
        assert entry.policy_version == "v1.0"

    def test_audit_entry_decision_factors_structure(
        self, engine: DecisionEngine, strict_context: DecisionContext
    ) -> None:
        signal = DriftSignal(True, "B", True, 0.90)
        entry = engine.decide(signal, strict_context)

        factors = entry.decision_factors
        assert "drift_detected" in factors
        assert "drift_type" in factors
        assert "reachable" in factors
        assert "ast_confidence" in factors
        assert "severity" in factors
        assert "enforcement_mode" in factors
        assert "policy_rule" in factors

        assert factors["drift_detected"] is True
        assert factors["drift_type"] == "B"
        assert factors["reachable"] is True
        assert factors["severity"] == "high"
        assert factors["enforcement_mode"] == "strict"
        assert factors["policy_rule"] == "strict:high"


# ──────────────────────────────────────────────
# Zusätzliche Tests: Policy Implementierungen
# ──────────────────────────────────────────────

class TestStrictPolicy:
    """_strict_policy() — alle Severity-Level."""

    def test_strict_none(self) -> None:
        assert DecisionEngine._strict_policy("none") == "ALLOW"

    def test_strict_low(self) -> None:
        assert DecisionEngine._strict_policy("low") == "ALLOW_WITH_ANNOTATION"

    def test_strict_medium(self) -> None:
        assert DecisionEngine._strict_policy("medium") == "BLOCK"

    def test_strict_high(self) -> None:
        assert DecisionEngine._strict_policy("high") == "BLOCK"


class TestPermissivePolicy:
    """_permissive_policy() — alle Severity-Level."""

    def test_permissive_none(self) -> None:
        assert DecisionEngine._permissive_policy("none") == "ALLOW"

    def test_permissive_low(self) -> None:
        assert DecisionEngine._permissive_policy("low") == "ALLOW"

    def test_permissive_medium(self) -> None:
        assert DecisionEngine._permissive_policy("medium") == "ALLOW_WITH_ANNOTATION"

    def test_permissive_high(self) -> None:
        assert DecisionEngine._permissive_policy("high") == "ALLOW_WITH_ANNOTATION"
