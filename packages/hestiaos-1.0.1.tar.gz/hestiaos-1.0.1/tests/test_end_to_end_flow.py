#!/usr/bin/env python3
"""
End-to-End Response Flow Test
Validates that the orchestrator can communicate with vLLM and return actual content.
"""

import asyncio
import sys
import os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from unittest.mock import Mock, AsyncMock, patch
import json

async def test_orchestrator_vllm_response():
    """Test that orchestrator can get actual content from vLLM backend."""
    print("🧪 Testing orchestrator-vLLM response flow...")
    
    # Mock the llm_engine to simulate vLLM response
    mock_llm_engine = Mock()
    
    # Simulate vLLM response chunks with actual content
    async def mock_call_vllm(model, messages, tools=None, options=None, timeout=None):
        # Yield vLLM-style chunks
        chunks = [
            {"choices": [{"delta": {"content": "Hello"}}]},
            {"choices": [{"delta": {"content": " there"}}]},
            {"choices": [{"delta": {"content": "! How can I help"}}]},
            {"choices": [{"delta": {"content": " you today?"}}]},
        ]
        for chunk in chunks:
            yield chunk
    
    mock_llm_engine.call_vllm = mock_call_vllm
    
    # Mock other dependencies
    mock_backend_router = AsyncMock()
    mock_selection = Mock()
    mock_selection.backend_id = "expert_gpu"
    mock_selection.backend_type = Mock()
    mock_selection.backend_type.value = "vllm"
    mock_selection.model = "Qwen/Qwen2.5-1.5B-Instruct"
    
    mock_backend_router.select_backend.return_value = mock_selection
    
    mock_context_manager = AsyncMock()
    mock_context_manager.load_context.return_value = {"chat_history": []}
    
    mock_tool_executor = Mock()
    mock_models_config = {}
    
    # Import orchestrator after mocking
    from core.orchestrator import Orchestrator
    
    # Create orchestrator with mocked dependencies
    orchestrator = Orchestrator(
        llm_engine=mock_llm_engine,
        context_manager=mock_context_manager,
        tool_executor=mock_tool_executor,
        models_config=mock_models_config,
        backend_router=mock_backend_router
    )
    
    # Test the response flow
    user_message = "Hello, can you help me?"
    
    # Create a mock context with session_id and trace_id
    mock_context = Mock()
    mock_context.mode = "business"
    mock_context.tenant_id = "test_tenant"
    mock_context.session_id = "test_session"
    mock_context.trace_id = "test_trace"
    
    # Collect responses
    responses = []
    async for chunk in orchestrator._process_message_internal(
        user_message=user_message,
        context=mock_context,
        use_tools=False
    ):
        responses.append(chunk)
    
    # Parse responses
    parsed_responses = []
    for response in responses:
        if response.startswith("data: "):
            try:
                data = json.loads(response[6:].strip())
                parsed_responses.append(data)
            except:
                pass
    
    print(f"📊 Received {len(parsed_responses)} response chunks")
    
    # Check for actual content
    content_chunks = [r for r in parsed_responses if r.get("type") == "token" and r.get("content")]
    routing_chunks = [r for r in parsed_responses if r.get("type") == "routing"]
    
    print(f"  - Content chunks: {len(content_chunks)}")
    print(f"  - Routing chunks: {len(routing_chunks)}")
    
    # Verify we got actual content
    if content_chunks:
        print("✅ SUCCESS: Orchestrator received actual content from vLLM")
        print(f"   Sample content: {content_chunks[0].get('content')}")
        return True
    else:
        print("❌ FAILURE: No content chunks received")
        return False

async def test_api_endpoint_integration():
    """Test the actual API endpoint with vLLM backend."""
    print("\n🧪 Testing API endpoint integration...")
    
    # Check if vLLM service is running
    import aiohttp
    vllm_url = "http://localhost:8001"
    
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(f"{vllm_url}/health", timeout=2) as response:
                if response.status == 200:
                    print("✅ vLLM service is running")
                else:
                    print(f"⚠️ vLLM service returned status {response.status}")
                    return False
    except Exception as e:
        print(f"❌ vLLM service not reachable: {e}")
        print("   Note: vLLM service needs to be running on port 8001")
        return False
    
    # Test the actual API endpoint
    import subprocess
    import time
    
    print("   Testing /chat endpoint...")
    
    # We'll use curl to test the endpoint
    curl_command = [
        "curl", "-X", "POST", "http://localhost:8000/chat",
        "-H", "Content-Type: application/json",
        "-d", '{"message": "Hello, can you help me?", "session_id": "test_e2e"}',
        "--max-time", "10"
    ]
    
    try:
        result = subprocess.run(curl_command, capture_output=True, text=True)
        if result.returncode == 0:
            print("✅ API endpoint responded successfully")
            
            # Parse response
            try:
                response_data = json.loads(result.stdout)
                if "response" in response_data:
                    response_text = response_data["response"]
                    if "Ich bin hier" in response_text and "konnte ich die benötigten Werkzeuge nicht aktivieren" in response_text:
                        print("⚠️ WARNING: Still getting hardcoded fallback message")
                        print(f"   Response: {response_text[:100]}...")
                        return False
                    else:
                        print(f"✅ SUCCESS: Got actual LLM response")
                        print(f"   Response preview: {response_text[:100]}...")
                        return True
                else:
                    print(f"❌ Unexpected response format: {result.stdout[:200]}")
                    return False
            except json.JSONDecodeError:
                print(f"❌ Response is not valid JSON: {result.stdout[:200]}")
                return False
        else:
            print(f"❌ curl failed with code {result.returncode}")
            print(f"   stderr: {result.stderr}")
            return False
    except Exception as e:
        print(f"❌ Error testing API endpoint: {e}")
        return False

async def main():
    """Run all end-to-end tests."""
    print("🚀 Starting End-to-End Response Flow Validation")
    print("=" * 60)
    
    # Test 1: Orchestrator response flow
    test1_passed = await test_orchestrator_vllm_response()
    
    # Test 2: API endpoint integration
    test2_passed = await test_api_endpoint_integration()
    
    print("\n" + "=" * 60)
    print("📋 TEST SUMMARY")
    print(f"  Test 1 (Orchestrator flow): {'✅ PASS' if test1_passed else '❌ FAIL'}")
    print(f"  Test 2 (API integration): {'✅ PASS' if test2_passed else '❌ FAIL'}")
    
    if test1_passed and test2_passed:
        print("\n🎉 All end-to-end tests passed! The system is working correctly.")
        return True
    else:
        print("\n⚠️ Some tests failed. Check the logs above for details.")
        return False

if __name__ == "__main__":
    success = asyncio.run(main())
    sys.exit(0 if success else 1)