import json

capability_keywords = ["welche tools", "was kannst du", "deine fähigkeiten", "was machst du", "how can you help", "what tools"]

def test_match(msg):
    match = any(kw in msg.lower() for kw in capability_keywords)
    print(f"Message: '{msg}' -> Match: {match}")

test_match("@hestia hallo")
test_match("hallo")
test_match("@hestia was machst du")
test_match("was kannst du")
test_match("help")

# get_request_type logic
tool_keywords_grt = ["tool", "kannst du", "welche", "funktionen", "befehle"]
def test_grt(msg):
    msg_lower = msg.lower()
    match = any(kw in msg_lower for kw in tool_keywords_grt)
    print(f"GRT Tool Query: '{msg}' -> Match: {match}")

test_grt("@hestia hallo")
test_grt("hallo")
test_grt("welche uhrzeit?")
