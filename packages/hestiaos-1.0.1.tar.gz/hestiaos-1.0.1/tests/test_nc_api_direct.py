#!/usr/bin/env python3
"""
Direct test of Nextcloud Talk API
"""
import asyncio
import httpx
import json
import base64
import sys

async def test_api():
    """Test API directly"""
    # Configuration from config/user.yml
    url = "https://cloud.walter-consult.com"
    user = "HestiaOS"
    password = "dF48x-gteDz-a5cfE-qRiCz-GCTct"
    room_token = "6mvoe63h"
    
    # Encode credentials
    auth_str = f"{user}:{password}"
    auth_b64 = base64.b64encode(auth_str.encode()).decode()
    
    headers = {
        "OCS-APIRequest": "true",
        "Accept": "application/json",
        "Authorization": f"Basic {auth_b64}"
    }
    
    try:
        async with httpx.AsyncClient(timeout=10.0, verify=True) as client:
            # Test 1: Simple GET to check connection
            print(f"🔗 Testing connection to {url}...")
            test_url = f"{url}/status.php"
            response = await client.get(test_url)
            print(f"   Status endpoint: {response.status_code} - {response.text[:100]}")
            
            # Test 2: OCS API endpoint
            print(f"\n🔗 Testing OCS API for room {room_token}...")
            ocs_url = f"{url}/ocs/v1.php/apps/spreed/api/v1/chat/{room_token}"
            response = await client.get(ocs_url, headers=headers)
            print(f"   OCS API: {response.status_code}")
            print(f"   Response headers: {dict(response.headers)}")
            print(f"   Response text (first 500 chars): {response.text[:500]}")
            
            # Try to parse as JSON
            if response.text.strip():
                try:
                    data = response.json()
                    print(f"   JSON parsed successfully")
                    if 'ocs' in data:
                        print(f"   OCS meta: {data['ocs'].get('meta', {})}")
                        if 'data' in data['ocs']:
                            messages = data['ocs']['data']
                            print(f"   Found {len(messages)} messages")
                            for msg in messages[-3:]:
                                print(f"     - ID {msg.get('id')}: {msg.get('actorDisplayName')}: {msg.get('message', '')[:50]}...")
                except json.JSONDecodeError as e:
                    print(f"   JSON parse failed: {e}")
                    print(f"   Raw response: {response.text[:200]}")
            else:
                print(f"   Empty response")
                
            # Test 3: Check if we can post a message
            print(f"\n📝 Testing message send...")
            message_data = {
                "message": "Test message from API test",
                "actorDisplayName": "API Test",
                "actorType": "bots"
            }
            response = await client.post(ocs_url, headers=headers, json=message_data)
            print(f"   POST response: {response.status_code}")
            print(f"   POST response text: {response.text[:200]}")
            
    except Exception as e:
        print(f"❌ Error: {e}")
        import traceback
        traceback.print_exc()

async def main():
    await test_api()

if __name__ == "__main__":
    asyncio.run(main())