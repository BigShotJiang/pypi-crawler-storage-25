"""
Tests for Workflow DSL — run_state_machine.py (RunStateMachine).
"""

import pytest

from core.workflow_dsl.run_state_machine import (
    RunStateMachine,
    TransitionError,
    TransitionEvent,
    TRANSITION_MATRIX,
    TERMINAL_STATUSES,
)
from core.workflow_dsl.run_store import RunStatus


class TestTransitionMatrix:
    """Verify the transition matrix is complete and correct."""

    def test_pending_allowed(self):
        assert RunStatus.RUNNING in TRANSITION_MATRIX[RunStatus.PENDING]
        assert RunStatus.CANCELLED in TRANSITION_MATRIX[RunStatus.PENDING]

    def test_pending_disallowed(self):
        assert RunStatus.COMPLETED not in TRANSITION_MATRIX[RunStatus.PENDING]
        assert RunStatus.FAILED not in TRANSITION_MATRIX[RunStatus.PENDING]
        assert RunStatus.PAUSED not in TRANSITION_MATRIX[RunStatus.PENDING]

    def test_running_allowed(self):
        assert RunStatus.PAUSED in TRANSITION_MATRIX[RunStatus.RUNNING]
        assert RunStatus.COMPLETED in TRANSITION_MATRIX[RunStatus.RUNNING]
        assert RunStatus.FAILED in TRANSITION_MATRIX[RunStatus.RUNNING]
        assert RunStatus.CANCELLED in TRANSITION_MATRIX[RunStatus.RUNNING]

    def test_running_disallowed(self):
        assert RunStatus.PENDING not in TRANSITION_MATRIX[RunStatus.RUNNING]

    def test_paused_allowed(self):
        assert RunStatus.RUNNING in TRANSITION_MATRIX[RunStatus.PAUSED]
        assert RunStatus.CANCELLED in TRANSITION_MATRIX[RunStatus.PAUSED]

    def test_paused_disallowed(self):
        assert RunStatus.COMPLETED not in TRANSITION_MATRIX[RunStatus.PAUSED]
        assert RunStatus.FAILED not in TRANSITION_MATRIX[RunStatus.PAUSED]

    def test_terminal_states_empty(self):
        for status in TERMINAL_STATUSES:
            assert TRANSITION_MATRIX[status] == set()

    def test_all_statuses_covered(self):
        """Every RunStatus should have an entry in the matrix."""
        for status in RunStatus:
            assert status in TRANSITION_MATRIX


class TestRunStateMachine:
    def setup_method(self):
        self.sm = RunStateMachine()

    def test_validate_transition_valid(self):
        assert self.sm.validate_transition(RunStatus.PENDING, RunStatus.RUNNING) is True
        assert self.sm.validate_transition(RunStatus.RUNNING, RunStatus.PAUSED) is True
        assert self.sm.validate_transition(RunStatus.PAUSED, RunStatus.RUNNING) is True
        assert self.sm.validate_transition(RunStatus.RUNNING, RunStatus.COMPLETED) is True

    def test_validate_transition_invalid(self):
        assert self.sm.validate_transition(RunStatus.PENDING, RunStatus.COMPLETED) is False
        assert self.sm.validate_transition(RunStatus.COMPLETED, RunStatus.RUNNING) is False
        assert self.sm.validate_transition(RunStatus.FAILED, RunStatus.PENDING) is False

    def test_validate_transition_none_is_pending(self):
        """None current status should only allow PENDING."""
        assert self.sm.validate_transition(None, RunStatus.PENDING) is True
        assert self.sm.validate_transition(None, RunStatus.RUNNING) is False

    def test_transition_success(self):
        event = self.sm.transition("run-1", RunStatus.PENDING, RunStatus.RUNNING)
        assert isinstance(event, TransitionEvent)
        assert event.run_id == "run-1"
        assert event.from_status == RunStatus.PENDING
        assert event.to_status == RunStatus.RUNNING

    def test_transition_invalid_raises(self):
        with pytest.raises(TransitionError, match="Invalid transition"):
            self.sm.transition("run-1", RunStatus.PENDING, RunStatus.COMPLETED)

    def test_transition_full_cycle(self):
        """Test a complete run lifecycle."""
        self.sm.transition("run-1", None, RunStatus.PENDING)
        self.sm.transition("run-1", RunStatus.PENDING, RunStatus.RUNNING)
        self.sm.transition("run-1", RunStatus.RUNNING, RunStatus.PAUSED)
        self.sm.transition("run-1", RunStatus.PAUSED, RunStatus.RUNNING)
        self.sm.transition("run-1", RunStatus.RUNNING, RunStatus.COMPLETED)

    def test_transition_pause_resume_cycle(self):
        self.sm.transition("run-1", RunStatus.PENDING, RunStatus.RUNNING)
        self.sm.transition("run-1", RunStatus.RUNNING, RunStatus.PAUSED)
        self.sm.transition("run-1", RunStatus.PAUSED, RunStatus.RUNNING)
        self.sm.transition("run-1", RunStatus.RUNNING, RunStatus.PAUSED)
        self.sm.transition("run-1", RunStatus.PAUSED, RunStatus.RUNNING)
        self.sm.transition("run-1", RunStatus.RUNNING, RunStatus.COMPLETED)

    def test_transition_cancel_from_pending(self):
        self.sm.transition("run-1", RunStatus.PENDING, RunStatus.CANCELLED)

    def test_transition_cancel_from_running(self):
        self.sm.transition("run-1", RunStatus.PENDING, RunStatus.RUNNING)
        self.sm.transition("run-1", RunStatus.RUNNING, RunStatus.CANCELLED)

    def test_transition_cancel_from_paused(self):
        self.sm.transition("run-1", RunStatus.PENDING, RunStatus.RUNNING)
        self.sm.transition("run-1", RunStatus.RUNNING, RunStatus.PAUSED)
        self.sm.transition("run-1", RunStatus.PAUSED, RunStatus.CANCELLED)

    def test_transition_fail_from_running(self):
        self.sm.transition("run-1", RunStatus.PENDING, RunStatus.RUNNING)
        event = self.sm.transition("run-1", RunStatus.RUNNING, RunStatus.FAILED, error="timeout")
        assert event.error == "timeout"

    def test_transition_from_terminal_raises(self):
        self.sm.transition("run-1", RunStatus.PENDING, RunStatus.RUNNING)
        self.sm.transition("run-1", RunStatus.RUNNING, RunStatus.COMPLETED)
        with pytest.raises(TransitionError):
            self.sm.transition("run-1", RunStatus.COMPLETED, RunStatus.RUNNING)

    def test_is_terminal(self):
        assert self.sm.is_terminal(RunStatus.COMPLETED) is True
        assert self.sm.is_terminal(RunStatus.FAILED) is True
        assert self.sm.is_terminal(RunStatus.CANCELLED) is True
        assert self.sm.is_terminal(RunStatus.PENDING) is False
        assert self.sm.is_terminal(RunStatus.RUNNING) is False

    def test_can_transition(self):
        assert self.sm.can_transition(RunStatus.PENDING) is True
        assert self.sm.can_transition(RunStatus.RUNNING) is True
        assert self.sm.can_transition(RunStatus.PAUSED) is True
        assert self.sm.can_transition(RunStatus.COMPLETED) is False
        assert self.sm.can_transition(RunStatus.FAILED) is False

    def test_get_allowed_transitions(self):
        allowed = self.sm.get_allowed_transitions(RunStatus.PENDING)
        assert RunStatus.RUNNING in allowed
        assert RunStatus.CANCELLED in allowed
        assert len(allowed) == 2

    def test_get_allowed_transitions_terminal(self):
        allowed = self.sm.get_allowed_transitions(RunStatus.COMPLETED)
        assert allowed == set()

    def test_get_allowed_transitions_returns_copy(self):
        allowed = self.sm.get_allowed_transitions(RunStatus.PENDING)
        allowed.add(RunStatus.COMPLETED)
        # Original should be unchanged
        original = self.sm.get_allowed_transitions(RunStatus.PENDING)
        assert RunStatus.COMPLETED not in original

    # --- Hooks ---

    def test_on_transition_hook(self):
        events = []
        self.sm.on("on_transition", lambda e: events.append(e))
        self.sm.transition("run-1", RunStatus.PENDING, RunStatus.RUNNING)
        assert len(events) == 1
        assert events[0].to_status == RunStatus.RUNNING

    def test_on_terminal_hook(self):
        events = []
        self.sm.on("on_terminal", lambda e: events.append(e))
        self.sm.transition("run-1", RunStatus.PENDING, RunStatus.RUNNING)
        self.sm.transition("run-1", RunStatus.RUNNING, RunStatus.COMPLETED)
        assert len(events) == 1
        assert events[0].to_status == RunStatus.COMPLETED

    def test_on_failure_hook(self):
        events = []
        self.sm.on("on_failure", lambda e: events.append(e))
        self.sm.transition("run-1", RunStatus.PENDING, RunStatus.RUNNING)
        self.sm.transition("run-1", RunStatus.RUNNING, RunStatus.FAILED, error="crash")
        assert len(events) == 1
        assert events[0].error == "crash"

    def test_hook_not_called_for_unregistered_event(self):
        """Unknown event names should not raise errors."""
        self.sm.on("nonexistent_event", lambda e: None)  # Should not raise

    # --- Metrics ---

    def test_transition_count(self):
        assert self.sm.transition_count == 0
        self.sm.transition("run-1", RunStatus.PENDING, RunStatus.RUNNING)
        assert self.sm.transition_count == 1
        self.sm.transition("run-1", RunStatus.RUNNING, RunStatus.COMPLETED)
        assert self.sm.transition_count == 2

    def test_reset_metrics(self):
        self.sm.transition("run-1", RunStatus.PENDING, RunStatus.RUNNING)
        self.sm.reset_metrics()
        assert self.sm.transition_count == 0
