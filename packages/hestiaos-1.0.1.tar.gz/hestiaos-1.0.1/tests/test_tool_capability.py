import pytest
import asyncio
from core.tool_manager import ToolManager
from core.interfaces.base_tool import BaseTool, CapabilityRegistry

def test_capability_registry():
    registry = CapabilityRegistry()
    registry.register("test_tool", "test_capability")
    
    assert "test_tool" in registry.get_tools_for_capability("test_capability")
    assert registry.get_capability_for_tool("test_tool") == "test_capability"
    assert "test_capability" in registry.list_capabilities()

@pytest.mark.asyncio
async def test_tool_manager_standardization():
    manager = ToolManager()
    
    # Verify native tools are registered and standardized
    assert "read_file" in manager.pydantic_tools
    assert "read_file" in manager.tools
    
    read_file_tool = manager.pydantic_tools["read_file"]
    assert isinstance(read_file_tool, BaseTool)
    assert read_file_tool.capability == "filesystem"
    assert "filesystem" in manager.capability_registry.list_capabilities()
    assert "read_file" in manager.capability_registry.get_tools_for_capability("filesystem")

@pytest.mark.asyncio
async def test_legacy_wrapper():
    manager = ToolManager()
    
    legacy_tool = {
        "description": "Legacy Test Tool",
        "parameters": {"type": "object", "properties": {}},
        "function": lambda x: x
    }
    
    # Manually register a legacy tool to see if it's wrapped
    manager.tools["legacy_tool"] = legacy_tool
    manager._load_native_tools() # Re-runs and should wrap
    
    assert "legacy_tool" in manager.pydantic_tools
    assert manager.pydantic_tools["legacy_tool"].capability in ["filesystem", "system"] # based on our heuristic
