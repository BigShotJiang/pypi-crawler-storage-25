import unittest
import asyncio
import sys
import os

# Add current directory to path
sys.path.append(os.getcwd())

from core.ultron_protocol import ConductorController

class TestUltronProtocol(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.conductor = ConductorController(agent_id="test_agent")

    async def test_conductor_alignment(self):
        # 1. Generative expectation
        await self.conductor.process_signal(
            source="planning",
            data={"action": "list_files", "path": "/home"},
            signal_type="generative"
        )
        
        # 2. Sensory sensory (Aligned)
        result = await self.conductor.process_signal(
            source="tool:ls",
            data={"action": "list_files", "path": "/home"},
            signal_type="sensory"
        )
        
        self.assertEqual(result["reality_status"], "aligned")
        self.assertGreater(self.conductor.get_conduction_coherence(), 0.9)

    async def test_conductor_discrepancy(self):
        # 1. Generative expectation: We expect a success
        await self.conductor.process_signal(
            source="planning",
            data={"status": "success", "files_found": 10},
            signal_type="generative"
        )
        
        # 2. Sensory input: We got a failure (Discrepancy!)
        result = await self.conductor.process_signal(
            source="tool:ls",
            data={"status": "error", "error": "permission denied"},
            signal_type="sensory"
        )
        
        self.assertIn(result["reality_status"], ["discrepancy_detected", "hallucination_likely"])
        self.assertLess(self.conductor.get_conduction_coherence(), 0.6)

    async def test_conductor_coherence_metrics(self):
        # Set high coherence
        await self.conductor.process_signal("gen", {"a": 1}, "generative")
        await self.conductor.process_signal("sen", {"a": 1}, "sensory")
        c1 = self.conductor.get_conduction_coherence()
        
        # Set low coherence
        await self.conductor.process_signal("gen", {"b": 2}, "generative")
        await self.conductor.process_signal("sen", {"c": 3}, "sensory")
        c2 = self.conductor.get_conduction_coherence()
        
        self.assertGreater(c1, c2)

if __name__ == "__main__":
    unittest.main()
