#!/usr/bin/env python3
"""Test script for mobile access to HestiaOS via Tailscale."""

import requests
import time
import sys

def test_tailscale_connectivity():
    """Test basic Tailscale connectivity."""
    print("Testing Tailscale connectivity...")
    
    # Test local connectivity first
    try:
        response = requests.get("http://localhost:8000/health", timeout=5)
        if response.status_code == 200:
            print("✅ Local HestiaOS health check: OK")
        else:
            print(f"❌ Local health check failed: {response.status_code}")
            return False
    except Exception as e:
        print(f"❌ Local connectivity failed: {e}")
        return False
    
    # Test via Tailscale IP
    tailscale_ip = "100.84.58.61"
    try:
        response = requests.get(f"http://{tailscale_ip}:8000/health", timeout=5)
        if response.status_code == 200:
            print(f"✅ Tailscale IP ({tailscale_ip}) health check: OK")
            return True
        else:
            print(f"❌ Tailscale health check failed: {response.status_code}")
            return False
    except Exception as e:
        print(f"❌ Tailscale connectivity failed: {e}")
        print("\n⚠️  Possible issues:")
        print("1. Tailscale not running on this machine")
        print("2. Firewall blocking port 8000")
        print("3. HestiaOS not bound to 0.0.0.0")
        return False

def test_chat_api():
    """Test the chat API via Tailscale."""
    print("\nTesting Chat API via Tailscale...")
    
    tailscale_ip = "100.84.58.61"
    test_message = "Hallo von Tailscale Test"
    
    try:
        start_time = time.time()
        response = requests.post(
            f"http://{tailscale_ip}:8000/chat",
            json={
                "message": test_message,
                "session_id": "tailscale_test",
                "mode": "expert"
            },
            timeout=30
        )
        end_time = time.time()
        
        if response.status_code == 200:
            data = response.json()
            processing_time = data.get("processing_time", 0)
            response_text = data.get("response", "")
            
            print(f"✅ Chat API successful")
            print(f"   Status: {response.status_code}")
            print(f"   Response time: {end_time - start_time:.2f}s")
            print(f"   Processing time: {processing_time:.2f}s")
            print(f"   Response length: {len(response_text)} characters")
            
            # Check for reasoning content (should be filtered)
            reasoning_indicators = ["<think>", "Okay, the user", "Let me think"]
            has_reasoning = any(indicator in response_text for indicator in reasoning_indicators)
            
            if has_reasoning:
                print("⚠️  Warning: Response may contain reasoning content")
            else:
                print("✅ No reasoning content detected")
            
            return True
        else:
            print(f"❌ Chat API failed: {response.status_code}")
            print(f"   Response: {response.text[:200]}")
            return False
            
    except Exception as e:
        print(f"❌ Chat API error: {e}")
        return False

def test_mobile_simulation():
    """Simulate mobile device access."""
    print("\nSimulating mobile device access...")
    
    # Mobile devices would use the same Tailscale IP
    tailscale_ip = "100.84.58.61"
    
    tests = [
        ("Health check", f"http://{tailscale_ip}:8000/health", "GET"),
        ("API docs", f"http://{tailscale_ip}:8000/docs", "GET"),
        ("OpenAPI spec", f"http://{tailscale_ip}:8000/openapi.json", "GET"),
    ]
    
    all_passed = True
    for test_name, url, method in tests:
        try:
            if method == "GET":
                response = requests.get(url, timeout=10)
            else:
                response = requests.post(url, timeout=10)
            
            if response.status_code < 400:
                print(f"✅ {test_name}: Accessible")
            else:
                print(f"❌ {test_name}: Failed ({response.status_code})")
                all_passed = False
                
        except Exception as e:
            print(f"❌ {test_name}: Error ({e})")
            all_passed = False
    
    return all_passed

def check_firewall():
    """Check if firewall might be blocking access."""
    print("\nChecking firewall configuration...")
    
    try:
        import subprocess
        # Check if ufw is active
        result = subprocess.run(["sudo", "ufw", "status"], capture_output=True, text=True)
        if "Status: active" in result.stdout:
            print("⚠️  UFW firewall is ACTIVE")
            # Check if port 8000 is allowed
            if ":8000" in result.stdout and "ALLOW" in result.stdout:
                print("✅ Port 8000 is allowed in UFW")
            else:
                print("❌ Port 8000 may be blocked by UFW")
                print("   Run: sudo ufw allow 8000/tcp")
        else:
            print("✅ UFW firewall is inactive or not installed")
            
    except Exception as e:
        print(f"⚠️  Could not check firewall: {e}")

def main():
    """Main test function."""
    print("="*80)
    print("HESTIAOS MOBILE ACCESS TEST VIA TAILSCALE")
    print("="*80)
    
    print(f"\nSystem Information:")
    print(f"  Hostname: core01")
    print(f"  Tailscale IP: 100.84.58.61")
    print(f"  HestiaOS Port: 8000")
    print(f"  Test Time: {time.ctime()}")
    
    all_tests_passed = True
    
    # Run tests
    if not test_tailscale_connectivity():
        all_tests_passed = False
    
    check_firewall()
    
    if all_tests_passed:
        if not test_chat_api():
            all_tests_passed = False
        
        if not test_mobile_simulation():
            all_tests_passed = False
    
    print("\n" + "="*80)
    if all_tests_passed:
        print("✅ ALL TESTS PASSED - Mobile access via Tailscale is working!")
        print("\n📱 Mobile Setup Instructions:")
        print("1. Install Tailscale on your GrapheneOS device")
        print("2. Log in with: chris.walter.87.cw@")
        print("3. Connect to Tailscale network")
        print("4. Open browser to: http://100.84.58.61:8000/")
        print("5. Or use API directly: http://100.84.58.61:8000/chat")
    else:
        print("❌ SOME TESTS FAILED - Check configuration")
        print("\n🔧 Troubleshooting Steps:")
        print("1. Ensure Tailscale is running: sudo tailscale up")
        print("2. Check HestiaOS is running: ps aux | grep uvicorn")
        print("3. Verify port 8000 is open: sudo ss -tlnp | grep :8000")
        print("4. Check firewall: sudo ufw status")
    
    print("="*80)
    
    return 0 if all_tests_passed else 1

if __name__ == "__main__":
    sys.exit(main())