"""
Tests for Science Edition Phase 2 Implementation
Verification of Consciousness Metrics, HMSP v2, and Logic Evolution.
"""

import pytest
import asyncio
from datetime import datetime
from unittest.mock import MagicMock, AsyncMock

from core.observability.consciousness_metrics import ConsciousnessMetricsCollector, MetricCategory
from core.hmsp_v2 import HMSPV2Protocol
from core.agent_communication import MessageType, AgentRole, Priority
from core.learning_system import LearningSystem, LearningDomain, LearningType

class TestSciencePhase2:
    
    @pytest.fixture
    def metrics_collector(self):
        return ConsciousnessMetricsCollector(agent_id="test_agent")
    
    def test_metrics_collection(self, metrics_collector):
        """Test recording and aggregating metrics"""
        metrics_collector.record_value("awareness_level", 3.0)
        metrics_collector.record_value("awareness_level", 4.0)
        
        aggr = metrics_collector.aggregate_metrics(window_minutes=1)
        assert "awareness_level" in aggr
        assert aggr["awareness_level"].current_value == 4.0
        assert aggr["awareness_level"].avg_value == 3.5
        assert aggr["awareness_level"].category == MetricCategory.AWARENESS
        
    def test_hmsp_v2_wrapping(self):
        """Test HMSP v2 message wrapping"""
        protocol = HMSPV2Protocol(agent_id="test_agent", agent_role=AgentRole.ORCHESTRATOR)
        
        loop = asyncio.get_event_loop()
        message = loop.run_until_complete(protocol.wrap_message(
            MessageType.NOTIFICATION, 
            {"test": "data"},
            Priority.HIGH
        ))
        
        assert message.sender_id == "test_agent"
        assert message.payload["high_speed"] is True
        assert message.payload["data"]["test"] == "data"
        
    @pytest.mark.asyncio
    async def test_logic_evolution_hooks(self):
        """Test logic evolution proposals in LearningSystem"""
        # Mock dependencies
        id_manager = MagicMock()
        protocol = MagicMock()
        awareness = MagicMock()
        registry = MagicMock()
        context = MagicMock()
        
        ls = LearningSystem(
            agent_id="test_id",
            consciousness_protocol=protocol,
            awareness_system=awareness,
            identity_manager=id_manager,
            agent_registry=registry,
            shared_context=context
        )
        
        # Set high expertise to trigger proposal
        ls.domain_expertise[LearningDomain.DECISION_MAKING] = 0.9
        
        proposals = await ls.propose_logic_adaptation()
        assert proposals.get("skip_analyze_on_high_confidence") is True
        assert proposals.get("confidence_threshold") == 0.9
