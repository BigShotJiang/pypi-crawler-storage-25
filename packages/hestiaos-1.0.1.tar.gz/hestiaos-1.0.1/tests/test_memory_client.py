import pytest
import asyncio
import json
from unittest.mock import MagicMock, AsyncMock
from brain.memory_client import HestiaMemoryClient, MemoryProvider

@pytest.fixture
def mock_provider():
    provider = MagicMock(spec=MemoryProvider)
    provider.add = AsyncMock(return_value=True)
    provider.search = AsyncMock(return_value=[])
    return provider

@pytest.fixture
def memory_client(mock_provider):
    return HestiaMemoryClient(provider=mock_provider)

@pytest.mark.asyncio
async def test_anonymization_email(memory_client):
    text = "Contact me at dev@hestia.os"
    anonymized = memory_client._anonymize(text)
    assert "dev@hestia.os" not in anonymized
    assert "<EMAIL_HASH:" in anonymized

@pytest.mark.asyncio
async def test_anonymization_phone(memory_client):
    text = "My number is +491234567890"
    anonymized = memory_client._anonymize(text)
    assert "+491234567890" not in anonymized
    assert "<PHONE_HASH:" in anonymized

@pytest.mark.asyncio
async def test_memory_remember_calls_provider(memory_client, mock_provider):
    content = "Secret email: secret@hestia.os"
    user_id = "user_abc"
    
    success = await memory_client.remember(user_id, content)
    
    assert success is True
    # The provider should receive the anonymized content
    args = mock_provider.add.call_args[0]
    assert args[0] == user_id
    assert "secret@hestia.os" not in args[1]
    assert "<EMAIL_HASH:" in args[1]

@pytest.mark.asyncio
async def test_memory_recall_calls_provider(memory_client, mock_provider):
    query = "Find info about secret@hestia.os"
    user_id = "user_abc"
    
    await memory_client.recall(user_id, query)
    
    # Provider should receive anonymized query
    args = mock_provider.search.call_args[0]
    assert args[0] == user_id
    assert "secret@hestia.os" not in args[1]
    assert "<EMAIL_HASH:" in args[1]

def test_deterministic_hashing(memory_client):
    # Same PII should result in the same hash for entity resolution
    email = "test@example.com"
    hash1 = memory_client._anonymize(f"Contact {email}")
    hash2 = memory_client._anonymize(f"The address {email}")
    
    # Extract hashes
    h1 = hash1.split(":")[1].split(">")[0]
    h2 = hash2.split(":")[1].split(">")[0]
    assert h1 == h2
