#!/usr/bin/env python3
"""
Test the fix for Nextcloud Talk plugin not responding to @hestia mentions.
"""
import asyncio
import httpx
import sys
import os
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

async def test_fix():
    """Test if the fix would work"""
    print("🧪 Testing the fix for @hestia mention response...")
    
    url = "https://cloud.walter-consult.com"
    user = "HestiaOS"
    password = "dF48x-gteDz-a5cfE-qRiCz-GCTct"
    room_token = "6mvoe63h"
    
    headers = {
        "OCS-APIRequest": "true",
        "Accept": "application/json"
    }
    
    async with httpx.AsyncClient(verify=False, timeout=10.0) as client:
        # Get recent messages
        print(f"📨 Fetching recent messages from room {room_token}...")
        resp = await client.get(
            f"{url}/ocs/v1.php/apps/spreed/api/v1/chat/{room_token}?lookIntoFuture=0&limit=10",
            headers=headers,
            auth=(user, password)
        )
        
        if resp.status_code != 200:
            print(f"❌ Failed to get messages: {resp.status_code}")
            return False
        
        data = resp.json()
        messages = data.get('ocs', {}).get('data', [])
        print(f"✅ Found {len(messages)} recent messages")
        
        # Simulate what the fixed _initialize_last_ids would do
        print("\n🔍 Simulating plugin startup with fix...")
        
        unprocessed_mentions = []
        latest_id = 0
        
        if messages:
            latest_msg = messages[-1]
            latest_id = latest_msg.get('id', 0)
            print(f"   Latest message ID: {latest_id}")
            
            # Check for mentions in recent messages
            for msg in messages:
                msg_id = msg.get('id', 0)
                actor = msg.get('actorId', '')
                content = msg.get('message', '').lower()
                actor_display = msg.get('actorDisplayName', 'unknown')
                
                # Skip messages from HestiaOS itself
                if actor == user:
                    print(f"   Skipping self-message {msg_id} from {actor_display}")
                    continue
                
                # Check for mentions
                if "@hestia" in content or "@hestian" in content:
                    unprocessed_mentions.append({
                        'id': msg_id,
                        'actor': actor_display,
                        'content': msg.get('message', '')[:50]
                    })
                    print(f"   ✓ Found mention in message {msg_id} from {actor_display}: '{msg.get('message', '')[:50]}...'")
        
        # Report findings
        print(f"\n📊 Analysis:")
        print(f"   Total recent messages: {len(messages)}")
        print(f"   Unprocessed @hestia mentions: {len(unprocessed_mentions)}")
        print(f"   Latest message ID: {latest_id}")
        
        if unprocessed_mentions:
            print(f"\n✅ The fix would process these mentions on startup:")
            for mention in unprocessed_mentions:
                print(f"   - ID {mention['id']}: {mention['actor']}: '{mention['content']}...'")
            
            # Check if Hestia has already responded to any of these
            print(f"\n🤖 Checking if Hestia has responded to these mentions...")
            
            # Get all messages to see responses
            resp = await client.get(
                f"{url}/ocs/v1.php/apps/spreed/api/v1/chat/{room_token}?lookIntoFuture=0&limit=30",
                headers=headers,
                auth=(user, password)
            )
            
            if resp.status_code == 200:
                all_data = resp.json()
                all_messages = all_data.get('ocs', {}).get('data', [])
                
                # Find Hestia responses
                hestia_responses = [m for m in all_messages if m.get('actorDisplayName') == 'HestiaOS']
                print(f"   Hestia has sent {len(hestia_responses)} total messages")
                
                # Check if any Hestia messages appear after the mentions
                for mention in unprocessed_mentions:
                    mention_id = mention['id']
                    # Find Hestia messages with ID > mention_id
                    responses_after = [m for m in hestia_responses if m.get('id', 0) > mention_id]
                    if responses_after:
                        print(f"   ✓ Hestia responded after mention {mention_id} ({len(responses_after)} responses)")
                    else:
                        print(f"   ❌ Hestia has NOT responded to mention {mention_id}")
            
            return True
        else:
            print(f"\n⚠️ No unprocessed @hestia mentions found in recent messages")
            print(f"   This could mean:")
            print(f"   1. All mentions have been processed")
            print(f"   2. There are no recent mentions")
            print(f"   3. The room has different messages")
            
            # Send a test mention to verify
            print(f"\n💬 Sending test mention to verify plugin is working...")
            test_resp = await client.post(
                f"{url}/ocs/v1.php/apps/spreed/api/v1/chat/{room_token}",
                headers=headers,
                auth=(user, password),
                json={"message": "@hestia Test - Please respond if you're working"}
            )
            
            if test_resp.status_code in [200, 201]:
                print(f"✅ Test message sent")
                print(f"   Waiting 10 seconds for possible response...")
                await asyncio.sleep(10)
                
                # Check for response
                resp = await client.get(
                    f"{url}/ocs/v1.php/apps/spreed/api/v1/chat/{room_token}?lookIntoFuture=0&limit=5",
                    headers=headers,
                    auth=(user, password)
                )
                
                if resp.status_code == 200:
                    check_data = resp.json()
                    check_messages = check_data.get('ocs', {}).get('data', [])
                    hestia_responses = [m for m in check_messages if m.get('actorDisplayName') == 'HestiaOS' and m.get('id', 0) > latest_id]
                    
                    if hestia_responses:
                        print(f"✅ Hestia responded to test message!")
                        for r in hestia_responses:
                            print(f"   - '{r.get('message', '')[:80]}...'")
                    else:
                        print(f"❌ Hestia did not respond to test message")
                        print(f"   Plugin may still have issues")
            
            return False

async def main():
    await test_fix()

if __name__ == "__main__":
    asyncio.run(main())