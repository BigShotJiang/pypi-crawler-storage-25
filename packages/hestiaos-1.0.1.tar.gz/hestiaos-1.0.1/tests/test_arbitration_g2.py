"""
G2 — Arbitration Correctness & Drift Isolation Tests.

Prüft die 3 Architektur-Risiken des hybriden Governance-Layers:

🔴 Priorität 1 — Arbitration Correctness (INV-G2-003, INV-G2-004)
    DSGK > Circuit Breaker > Control Plane > Drift Sensitivity > Default

🟡 Priorität 2 — Drift Isolation (INV-G2-001, INV-G2-005, INV-G2-006)
    Drift darf nicht mutieren, nicht in DSGK influencen, nicht in Signals.

Siehe: plans/g2_runtime_governance_coupling.md
"""

import pytest

from core.governance.system_mode import SystemMode, DriftVector
from core.governance.dsgk_decision import DSGKDecision, DecisionType
from core.governance.reasoning_budget import ReasoningBudget
from core.bootstrap.control_plane import CanonicalState, SystemCondition, SystemSignals
from core.bootstrap.arbitrator import SystemArbitrator, ArbitrationResult
from core.processing.network_error_classifier import CircuitState
from core.bootstrap.models import BootState


# ── Test Helpers ────────────────────────────────────────────────────


def _make_dsgk_decision(decision_type: DecisionType) -> DSGKDecision:
    """Erzeugt eine minimale DSGKDecision für Tests."""
    return DSGKDecision(
        decision=decision_type,
        reason="test",
        risk_score=0.0,
        policy="test.v1",
        violations=[],
        budget=ReasoningBudget(),
    )


def _make_canonical_state(condition: SystemCondition) -> CanonicalState:
    """Erzeugt einen CanonicalState mit minimalen Signalen."""
    signals = SystemSignals(
        boot_state=BootState.READY,
        db_ready=True,
        migrations_ok=True,
    )
    return CanonicalState(
        condition=condition,
        priority_vector=[0, 0, 0, 0, 0],
        signals=signals,
        message="test state",
    )


def _make_drift_vector(
    is_significant: bool = True,
    arbitration_level: str = "BLOCK",
    system_drift: float = 0.8,
) -> DriftVector:
    """Erzeugt einen DriftVector für Tests."""
    return DriftVector(
        policy_drift=0.5,
        execution_drift=0.5,
        provider_drift=0.5,
        system_drift=system_drift,
        stability_score=1.0 - system_drift,
        sample_size=100,
        is_significant=is_significant,
        esl_trace_level="HARD_DRIFT",
        arbitration_level=arbitration_level,
    )


# ═══════════════════════════════════════════════════════════════════════
# 🔴 Priorität 1 — Arbitration Correctness
# ═══════════════════════════════════════════════════════════════════════


class TestArbitrationPriority:
    """INV-G2-003 + INV-G2-004: DSGK > Circuit > Infra > Drift > Default."""

    def test_dsgk_block_overrides_drift(self):
        """INV-G2-003: DSGK BLOCK hat Vorrang vor Drift BLOCK."""
        arb = SystemArbitrator()
        decision = _make_dsgk_decision(DecisionType.BLOCK)
        state = _make_canonical_state(SystemCondition.GREEN)
        drift = _make_drift_vector(is_significant=True, arbitration_level="BLOCK")

        outcome = arb.arbitrate(
            dsgk=decision,
            control_state=state,
            circuit_state=CircuitState.CLOSED,
            drift_vector=drift,
        )

        assert outcome.result == ArbitrationResult.BLOCK
        assert outcome.authority == "DSGK"
        assert outcome.reason == "POLICY_VIOLATION"

    def test_circuit_open_overrides_drift(self):
        """INV-G2-004: Circuit OPEN hat Vorrang vor Drift BLOCK."""
        arb = SystemArbitrator()
        decision = _make_dsgk_decision(DecisionType.ALLOW)
        state = _make_canonical_state(SystemCondition.GREEN)
        drift = _make_drift_vector(is_significant=True, arbitration_level="BLOCK")

        outcome = arb.arbitrate(
            dsgk=decision,
            control_state=state,
            circuit_state=CircuitState.OPEN,
            drift_vector=drift,
        )

        assert outcome.result == ArbitrationResult.BLOCK
        assert outcome.authority == "CIRCUIT_BREAKER"
        assert outcome.reason == "SYSTEM_STABILITY"

    def test_infra_red_overrides_drift(self):
        """Control Plane RED hat Vorrang vor Drift BLOCK."""
        arb = SystemArbitrator()
        decision = _make_dsgk_decision(DecisionType.ALLOW)
        state = _make_canonical_state(SystemCondition.RED)
        drift = _make_drift_vector(is_significant=True, arbitration_level="BLOCK")

        outcome = arb.arbitrate(
            dsgk=decision,
            control_state=state,
            circuit_state=CircuitState.CLOSED,
            drift_vector=drift,
        )

        assert outcome.result == ArbitrationResult.BLOCK
        assert outcome.authority == "CONTROL_PLANE"
        assert outcome.reason == "INFRASTRUCTURE_FAILURE"

    def test_drift_block_when_significant(self):
        """Drift BLOCK feuert nur bei is_significant=True."""
        arb = SystemArbitrator()
        decision = _make_dsgk_decision(DecisionType.ALLOW)
        state = _make_canonical_state(SystemCondition.GREEN)

        # Nicht signifikant → Drift darf NICHT blocken
        drift_not_sig = _make_drift_vector(is_significant=False, arbitration_level="BLOCK")
        outcome = arb.arbitrate(
            dsgk=decision,
            control_state=state,
            circuit_state=CircuitState.CLOSED,
            drift_vector=drift_not_sig,
        )
        assert outcome.result == ArbitrationResult.ALLOW

        # Signifikant → Drift BLOCK
        drift_sig = _make_drift_vector(is_significant=True, arbitration_level="BLOCK")
        outcome = arb.arbitrate(
            dsgk=decision,
            control_state=state,
            circuit_state=CircuitState.CLOSED,
            drift_vector=drift_sig,
        )
        assert outcome.result == ArbitrationResult.BLOCK
        assert outcome.authority == "DRIFT_ARBITRATION"

    def test_drift_none_no_effect(self):
        """Kein DriftVector → kein Einfluss auf Arbitration (Default ALLOW)."""
        arb = SystemArbitrator()
        decision = _make_dsgk_decision(DecisionType.ALLOW)
        state = _make_canonical_state(SystemCondition.GREEN)

        outcome = arb.arbitrate(
            dsgk=decision,
            control_state=state,
            circuit_state=CircuitState.CLOSED,
            drift_vector=None,
        )

        assert outcome.result == ArbitrationResult.ALLOW
        assert outcome.authority == "KERNEL"
        assert outcome.reason == "HEALTHY"

    def test_drift_warning_throttles(self):
        """Drift WARNING → THROTTLE (via Performance Adaptation)."""
        arb = SystemArbitrator()
        decision = _make_dsgk_decision(DecisionType.ALLOW)
        state = _make_canonical_state(SystemCondition.YELLOW)
        drift = _make_drift_vector(is_significant=True, arbitration_level="WARN")

        outcome = arb.arbitrate(
            dsgk=decision,
            control_state=state,
            circuit_state=CircuitState.CLOSED,
            drift_vector=drift,
        )

        # YELLOW (Regel 4) kommt vor Drift (Regel 5)
        assert outcome.result == ArbitrationResult.THROTTLE
        assert outcome.authority == "CONTROL_PLANE"

    def test_arbitration_priority_order(self):
        """INV-G2-003+004: Vollständige Prioritätskette."""
        arb = SystemArbitrator()
        drift = _make_drift_vector(is_significant=True, arbitration_level="BLOCK")

        # 1. DSGK BLOCK → DSGK (höchste Priorität)
        outcome1 = arb.arbitrate(
            dsgk=_make_dsgk_decision(DecisionType.BLOCK),
            control_state=_make_canonical_state(SystemCondition.RED),
            circuit_state=CircuitState.OPEN,
            drift_vector=drift,
        )
        assert outcome1.authority == "DSGK"

        # 2. DSGK ALLOW + Circuit OPEN → CIRCUIT_BREAKER
        outcome2 = arb.arbitrate(
            dsgk=_make_dsgk_decision(DecisionType.ALLOW),
            control_state=_make_canonical_state(SystemCondition.RED),
            circuit_state=CircuitState.OPEN,
            drift_vector=drift,
        )
        assert outcome2.authority == "CIRCUIT_BREAKER"

        # 3. DSGK ALLOW + Circuit CLOSED + RED → CONTROL_PLANE
        outcome3 = arb.arbitrate(
            dsgk=_make_dsgk_decision(DecisionType.ALLOW),
            control_state=_make_canonical_state(SystemCondition.RED),
            circuit_state=CircuitState.CLOSED,
            drift_vector=drift,
        )
        assert outcome3.authority == "CONTROL_PLANE"
        assert outcome3.reason == "INFRASTRUCTURE_FAILURE"

        # 4. DSGK ALLOW + Circuit CLOSED + GREEN + Drift BLOCK → DRIFT_ARBITRATION
        outcome4 = arb.arbitrate(
            dsgk=_make_dsgk_decision(DecisionType.ALLOW),
            control_state=_make_canonical_state(SystemCondition.GREEN),
            circuit_state=CircuitState.CLOSED,
            drift_vector=drift,
        )
        assert outcome4.authority == "DRIFT_ARBITRATION"

        # 5. DSGK ALLOW + Circuit CLOSED + GREEN + kein Drift → KERNEL (Default)
        outcome5 = arb.arbitrate(
            dsgk=_make_dsgk_decision(DecisionType.ALLOW),
            control_state=_make_canonical_state(SystemCondition.GREEN),
            circuit_state=CircuitState.CLOSED,
            drift_vector=None,
        )
        assert outcome5.authority == "KERNEL"
        assert outcome5.result == ArbitrationResult.ALLOW


# ═══════════════════════════════════════════════════════════════════════
# 🟡 Priorität 2 — Drift Isolation
# ═══════════════════════════════════════════════════════════════════════


class TestDriftIsolation:
    """INV-G2-001, INV-G2-005, INV-G2-006: Drift darf nicht mutieren."""

    def test_drift_does_not_mutate_signals(self):
        """INV-G2-005: DriftVector verändert keine SystemSignals."""
        signals = SystemSignals(
            boot_state=BootState.READY,
            db_ready=True,
            migrations_ok=True,
        )
        original_stability = signals.drift_stability_score
        original_drift = signals.drift_system_drift

        drift = _make_drift_vector(is_significant=True, arbitration_level="BLOCK")

        # DriftVector lesen (keine Mutation)
        _ = drift.system_drift
        _ = drift.stability_score

        # Signals müssen unverändert sein
        assert signals.drift_stability_score == original_stability
        assert signals.drift_system_drift == original_drift

    def test_drift_does_not_influence_dsgk(self):
        """INV-G2-006: DSGK-Entscheidung bleibt identisch mit/ohne Drift.

        DSGK ist eine reine Funktion des Inputs — Drift darf NIEMALS
        die DSGK-Entscheidung beeinflussen.
        """
        decision_without = _make_dsgk_decision(DecisionType.ALLOW)
        decision_with = _make_dsgk_decision(DecisionType.ALLOW)

        drift = _make_drift_vector(is_significant=True, arbitration_level="BLOCK")

        # DSGKDecision ist frozen — kann nicht mutiert werden
        # Aber wir prüfen, dass die Entscheidung identisch bleibt
        assert decision_without.decision == decision_with.decision
        assert decision_without.decision == DecisionType.ALLOW

        # Auch bei BLOCK: DSGK bleibt stabil
        block_without = _make_dsgk_decision(DecisionType.BLOCK)
        block_with = _make_dsgk_decision(DecisionType.BLOCK)
        assert block_without.decision == block_with.decision
        assert block_with.decision == DecisionType.BLOCK

    def test_drift_vector_immutable(self):
        """INV-G2-001: DriftVector ist frozen — keine Mutation nach Erzeugung."""
        drift = _make_drift_vector(is_significant=True, arbitration_level="BLOCK")

        with pytest.raises(AttributeError):
            drift.system_drift = 0.0  # type: ignore

        with pytest.raises(AttributeError):
            drift.is_significant = False  # type: ignore

        with pytest.raises(AttributeError):
            drift.arbitration_level = "PASS"  # type: ignore

    def test_drift_vector_fields_are_typed(self):
        """DriftVector-Felder haben korrekte Typen."""
        drift = _make_drift_vector()

        assert isinstance(drift.policy_drift, float)
        assert isinstance(drift.execution_drift, float)
        assert isinstance(drift.provider_drift, float)
        assert isinstance(drift.system_drift, float)
        assert isinstance(drift.stability_score, float)
        assert isinstance(drift.sample_size, int)
        assert isinstance(drift.is_significant, bool)
        assert isinstance(drift.esl_trace_level, str)
        assert isinstance(drift.arbitration_level, str)

    def test_drift_vector_ranges(self):
        """DriftVector-Werte sind im gültigen Bereich 0.0-1.0."""
        drift = _make_drift_vector()

        assert 0.0 <= drift.policy_drift <= 1.0
        assert 0.0 <= drift.execution_drift <= 1.0
        assert 0.0 <= drift.provider_drift <= 1.0
        assert 0.0 <= drift.system_drift <= 1.0
        assert 0.0 <= drift.stability_score <= 1.0


# ═══════════════════════════════════════════════════════════════════════
# SystemMode Tests
# ═══════════════════════════════════════════════════════════════════════


class TestSystemMode:
    """SystemMode Enum — Korrektheit der Werte."""

    def test_system_mode_values(self):
        """Enum-Werte sind korrekt."""
        assert SystemMode.EXECUTE.value == "EXECUTE"
        assert SystemMode.THROTTLE.value == "THROTTLE"
        assert SystemMode.DEGRADED.value == "DEGRADED"
        assert SystemMode.BLOCK_OVERRIDE.value == "BLOCK"

    def test_system_mode_distinct(self):
        """Alle Enum-Werte sind unterschiedlich."""
        values = [m.value for m in SystemMode]
        assert len(values) == len(set(values))

    def test_system_mode_order(self):
        """SystemMode hat genau 4 definierte Modi."""
        assert len(SystemMode) == 4
