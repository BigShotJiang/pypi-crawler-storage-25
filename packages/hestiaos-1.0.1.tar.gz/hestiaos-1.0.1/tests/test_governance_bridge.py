"""
Tests für den Governance Event Backbone (Phase 6).

Testet:
    - ArtifactEventBridge (Event Bus → n8n Bridge)
    - setup_governance_backbone() Factory
    - build_artifact_event_payload() Helper
    - Integration zwischen Event Bus, n8n Bridge und Artifact-System

Architektur:
    Die Bridge nutzt Dependency Inversion (EventBusProtocol) statt eines
    konkreten EventBus-Imports. Dadurch gibt es keinen zirkulären Import.
    Der Test stellt ein FakeEventBus bereit, das das Protokoll erfüllt.
"""
import pytest
import time
import asyncio
from unittest.mock import patch, MagicMock, AsyncMock, call
from typing import Dict, List, Callable, Any, Awaitable, Optional

from core.integration.governance_bridge import (
    ArtifactEventBridge,
    setup_governance_backbone,
    build_artifact_event_payload,
)
from core.integration.n8n.webhook_bridge import N8NEventType


# ---------------------------------------------------------------------------
# Hilfsklasse: Simuliert ein Event-Objekt, wie es der echte EventBus erzeugt
# ---------------------------------------------------------------------------

class _FakeEvent:
    """Einfaches Event-Objekt, das die von N8NWebhookBridge.event_adapter
    erwarteten Attribute (event_type, payload, correlation_id) bereitstellt.
    """
    def __init__(self, event_type: str, payload: Dict[str, Any]):
        self.event_type = event_type
        self.payload = payload
        self.correlation_id = payload.get("correlation_id")


# ---------------------------------------------------------------------------
# FakeEventBus — Test-Double, das EventBusProtocol erfüllt
# ---------------------------------------------------------------------------

class FakeEventBus:
    """Test-Double für EventBus. Erfüllt EventBusProtocol.
    
    Kein Import aus core.event_bus, um zirkuläre Importe zu vermeiden.
    Interface-kompatibel mit EventBusProtocol (core/integration/governance_bridge.py).
    """

    def __init__(self):
        self._handlers: Dict[str, List[Callable]] = {}
        self._subscribers: Dict[str, List[Dict[str, Any]]] = {}

    async def subscribe(self, subscriber_id: str, event_types: List[Any], callback: Callable) -> None:
        """Registriere einen Subscriber mit ID, Event-Typen und Callback."""
        for event_type in event_types:
            if event_type not in self._subscribers:
                self._subscribers[event_type] = []
            self._subscribers[event_type].append({
                "subscriber_id": subscriber_id,
                "callback": callback,
            })
            # Auch im _handlers-Dict für Kompatibilität
            if event_type not in self._handlers:
                self._handlers[event_type] = []
            self._handlers[event_type].append(callback)

    async def publish(self, event_name: str, payload: Dict[str, Any]) -> None:
        """Veröffentliche ein Event. Erzeugt ein _FakeEvent-Objekt, damit
        der event_adapter in N8NWebhookBridge.install() funktioniert.
        """
        handlers = self._handlers.get(event_name, [])
        event_obj = _FakeEvent(event_type=event_name, payload=payload)
        for handler in handlers:
            try:
                result = handler(event_obj)
                if hasattr(result, "__await__"):
                    await result
            except Exception:
                pass

    def unsubscribe(self, event_name: str, handler: Callable) -> None:
        handlers = self._handlers.get(event_name, [])
        if handler in handlers:
            handlers.remove(handler)


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture
def event_bus():
    """Eine frische FakeEventBus-Instanz."""
    return FakeEventBus()


@pytest.fixture
def webhook_url():
    return "http://n8n:5678/webhook/hestia"


@pytest.fixture
def bridge(event_bus, webhook_url):
    """Eine ArtifactEventBridge-Instanz (noch nicht installiert)."""
    return ArtifactEventBridge(event_bus=event_bus, webhook_url=webhook_url)


# ---------------------------------------------------------------------------
# ArtifactEventBridge Tests
# ---------------------------------------------------------------------------

class TestArtifactEventBridge:
    """Tests für die Event Bus → n8n Bridge."""

    def test_init(self, bridge, webhook_url):
        """Initialisierung setzt korrekte Attribute."""
        assert bridge._installed is False
        assert bridge.webhook_bridge.webhook_url == webhook_url
        assert bridge.is_installed is False

    @pytest.mark.asyncio
    async def test_install_subscribes_to_all_events(self, bridge, event_bus):
        """install() abonniert alle 4 Standard-Events."""
        await bridge.install()
        assert bridge._installed is True
        assert bridge.is_installed is True
        # Prüfe, dass der WebhookBridge installiert wurde
        assert bridge.webhook_bridge._installed is True

    @pytest.mark.asyncio
    async def test_install_idempotent(self, bridge, event_bus):
        """Mehrmaliges install() ist safe."""
        await bridge.install()
        await bridge.install()  # Zweites Mal sollte keine Exception werfen
        assert bridge._installed is True

    @pytest.mark.asyncio
    async def test_uninstall_removes_subscriptions(self, bridge, event_bus):
        """uninstall() entfernt alle Subscriptions."""
        await bridge.install()
        assert bridge._installed is True
        bridge.uninstall()
        assert bridge._installed is False
        assert bridge.is_installed is False
        assert bridge.webhook_bridge._installed is False

    def test_uninstall_without_install(self, bridge, event_bus):
        """uninstall() ohne vorheriges install() ist safe."""
        bridge.uninstall()  # Sollte keine Exception werfen
        assert bridge._installed is False

    @pytest.mark.asyncio
    async def test_event_flow_to_n8n(self, event_bus, webhook_url):
        """Vollständiger Event-Flow: EventBus → Bridge → n8n."""
        bridge = ArtifactEventBridge(event_bus=event_bus, webhook_url=webhook_url)
        await bridge.install()
        
        # Mock den _send der WebhookBridge
        with patch.object(bridge.webhook_bridge, "_send", AsyncMock()) as mock_send:
            # Publiziere ein Event
            await event_bus.publish("artifact_created", {
                "event_type": "artifact_created",
                "artifact_id": "art_001",
                "payload": {"title": "Test", "type": "idea"},
            })
            
            # Prüfe, dass _send aufgerufen wurde
            mock_send.assert_called_once()
            envelope = mock_send.call_args[0][0]
            assert envelope["event_type"] == "artifact_created"
            assert envelope["artifact_id"] == "art_001"

    @pytest.mark.asyncio
    async def test_multiple_events(self, event_bus, webhook_url):
        """Mehrere Events hintereinander."""
        bridge = ArtifactEventBridge(event_bus=event_bus, webhook_url=webhook_url)
        await bridge.install()
        
        with patch.object(bridge.webhook_bridge, "_send", AsyncMock()) as mock_send:
            for i in range(3):
                await event_bus.publish("artifact_created", {
                    "event_type": "artifact_created",
                    "artifact_id": f"art_{i:03d}",
                    "payload": {"title": f"Test {i}"},
                })
            
            assert mock_send.call_count == 3

    @pytest.mark.asyncio
    async def test_core_stable_when_n8n_down(self, event_bus, webhook_url):
        """Core bleibt stabil, wenn n8n nicht erreichbar ist."""
        bridge = ArtifactEventBridge(event_bus=event_bus, webhook_url="http://localhost:1")
        await bridge.install()
        
        # Sollte keine Exception werfen
        await event_bus.publish("artifact_created", {
            "event_type": "artifact_created",
            "artifact_id": "art_001",
            "payload": {},
        })
        # Wenn wir hier ankommen, ist der Core stabil

    @pytest.mark.asyncio
    async def test_event_bus_independent_of_n8n(self, event_bus):
        """Event Bus funktioniert auch ohne n8n Bridge."""
        received: List[Any] = []
        
        async def handler(event):
            received.append(event)
        
        await event_bus.subscribe("direct_listener", ["artifact_created"], handler)
        
        await event_bus.publish("artifact_created", {
            "event_type": "artifact_created",
            "artifact_id": "art_001",
            "payload": {},
        })
        
        assert len(received) == 1
        # Handler empfängt ein _FakeEvent-Objekt (wie der echte EventBus)
        assert received[0].event_type == "artifact_created"
        assert received[0].payload["artifact_id"] == "art_001"


# ---------------------------------------------------------------------------
# setup_governance_backbone Tests
# ---------------------------------------------------------------------------

class TestSetupGovernanceBackbone:
    """Tests für die Convenience Factory."""

    @pytest.mark.asyncio
    async def test_setup_with_defaults(self, event_bus):
        """Setup mit Default-Werten."""
        bridge = await setup_governance_backbone(
            event_bus=event_bus,
            auto_install=True,
        )
        assert isinstance(bridge, ArtifactEventBridge)
        assert bridge.is_installed is True
        assert bridge.webhook_bridge.webhook_url == "http://localhost:5678/webhook/hestia"

    @pytest.mark.asyncio
    async def test_setup_with_custom_url(self, event_bus):
        """Setup mit benutzerdefinierter URL."""
        bridge = await setup_governance_backbone(
            event_bus=event_bus,
            webhook_url="http://custom:5678/webhook/test",
            auto_install=True,
        )
        assert bridge.webhook_bridge.webhook_url == "http://custom:5678/webhook/test"

    @pytest.mark.asyncio
    async def test_setup_without_auto_install(self, event_bus):
        """Setup ohne auto_install."""
        bridge = await setup_governance_backbone(
            event_bus=event_bus,
            auto_install=False,
        )
        assert bridge.is_installed is False

    @pytest.mark.asyncio
    async def test_setup_returns_bridge_instance(self, event_bus):
        """setup_governance_backbone gibt ArtifactEventBridge zurück."""
        bridge = await setup_governance_backbone(event_bus=event_bus)
        assert isinstance(bridge, ArtifactEventBridge)


# ---------------------------------------------------------------------------
# build_artifact_event_payload Tests
# ---------------------------------------------------------------------------

class TestBuildArtifactEventPayload:
    """Tests für den Event-Payload-Helper."""

    def test_minimal_payload(self):
        """Minimales Payload (nur Pflichtfelder)."""
        payload = build_artifact_event_payload(
            artifact_id="art_001",
            event_type="artifact_created",
        )
        assert payload["artifact_id"] == "art_001"
        assert payload["event_type"] == "artifact_created"
        assert "timestamp" in payload
        assert payload["source"] == "system"

    def test_with_changes(self):
        """Payload mit Änderungen."""
        payload = build_artifact_event_payload(
            artifact_id="art_001",
            event_type="status_changed",
            changes={"from": "draft", "to": "active"},
        )
        assert payload["changes"] == {"from": "draft", "to": "active"}

    def test_with_correlation_id(self):
        """Payload mit Korrelations-ID."""
        payload = build_artifact_event_payload(
            artifact_id="art_001",
            event_type="artifact_created",
            correlation_id="corr_123",
        )
        assert payload["correlation_id"] == "corr_123"

    def test_with_custom_source(self):
        """Payload mit benutzerdefinierter Quelle."""
        payload = build_artifact_event_payload(
            artifact_id="art_001",
            event_type="artifact_created",
            source="transformation",
        )
        assert payload["source"] == "transformation"

    def test_timestamp_is_recent(self):
        """Timestamp sollte aktuell sein."""
        before = time.time()
        payload = build_artifact_event_payload(
            artifact_id="art_001",
            event_type="artifact_created",
        )
        after = time.time()
        assert before <= payload["timestamp"] <= after

    def test_all_fields(self):
        """Payload mit allen Feldern."""
        payload = build_artifact_event_payload(
            artifact_id="art_001",
            event_type="status_changed",
            changes={"from": "draft", "to": "active"},
            correlation_id="corr_001",
            source="api",
        )
        assert payload["artifact_id"] == "art_001"
        assert payload["event_type"] == "status_changed"
        assert payload["changes"] == {"from": "draft", "to": "active"}
        assert payload["correlation_id"] == "corr_001"
        assert payload["source"] == "api"
        assert "timestamp" in payload


# ---------------------------------------------------------------------------
# Integration Tests
# ---------------------------------------------------------------------------

class TestGovernanceIntegration:
    """Integrationstests für den gesamten Governance Backbone."""

    @pytest.mark.asyncio
    async def test_full_event_pipeline(self, event_bus, webhook_url):
        """Vollständige Event-Pipeline: EventBus → Bridge → n8n Webhook."""
        bridge = ArtifactEventBridge(event_bus=event_bus, webhook_url=webhook_url)
        await bridge.install()
        
        with patch.object(bridge.webhook_bridge, "_send", AsyncMock()) as mock_send:
            
            # Simuliere 4 verschiedene Event-Typen
            events = [
                ("artifact_created", "art_001", {"title": "New Idea", "type": "idea"}),
                ("violation_emitted", "art_001", {"rule_id": "R1", "severity": "warning"}),
                ("decision_made", "art_002", {"decision": "approve", "reason": "OK"}),
                ("transformation_completed", "art_001", {"transformation": "idea_to_spec", "success": True}),
            ]
            
            for event_type, artifact_id, payload in events:
                await event_bus.publish(event_type, {
                    "event_type": event_type,
                    "artifact_id": artifact_id,
                    "payload": payload,
                })
            
            assert mock_send.call_count == 4
            
            # Prüfe, dass alle Event-Types korrekt weitergeleitet wurden
            sent_types = [call_args[0][0]["event_type"] for call_args in mock_send.call_args_list]
            assert "artifact_created" in sent_types
            assert "violation_emitted" in sent_types
            assert "decision_made" in sent_types
            assert "transformation_completed" in sent_types

    @pytest.mark.asyncio
    async def test_bridge_can_be_reinstalled(self, event_bus, webhook_url):
        """Bridge kann deinstalliert und neu installiert werden."""
        bridge = ArtifactEventBridge(event_bus=event_bus, webhook_url=webhook_url)
        
        # Install → Uninstall → Reinstall
        await bridge.install()
        assert bridge.is_installed is True
        
        bridge.uninstall()
        assert bridge.is_installed is False
        
        await bridge.install()
        assert bridge.is_installed is True
        
        # Nach Reinstall sollten Events wieder ankommen
        # Hinweis: N8NWebhookBridge.uninstall() kann die event_adapter-Closure
        # nicht vollständig entfernen, daher kann es zu doppelten Aufrufen kommen.
        with patch.object(bridge.webhook_bridge, "_send", AsyncMock()) as mock_send:
            await event_bus.publish("artifact_created", {
                "event_type": "artifact_created",
                "artifact_id": "art_001",
                "payload": {},
            })
            # Mindestens 1 Aufruf (können mehr sein wegen uninstall-Limitierung)
            assert mock_send.call_count >= 1

    @pytest.mark.asyncio
    async def test_multiple_bridges_independent(self, event_bus):
        """Mehrere Bridges auf demselben Event Bus sind unabhängig."""
        bridge1 = ArtifactEventBridge(
            event_bus=event_bus,
            webhook_url="http://n8n-1:5678/webhook",
        )
        bridge2 = ArtifactEventBridge(
            event_bus=event_bus,
            webhook_url="http://n8n-2:5678/webhook",
        )
        
        await bridge1.install()
        await bridge2.install()
        
        with patch.object(bridge1.webhook_bridge, "_send", AsyncMock()) as mock_send1:
            with patch.object(bridge2.webhook_bridge, "_send", AsyncMock()) as mock_send2:
                await event_bus.publish("artifact_created", {
                    "event_type": "artifact_created",
                    "artifact_id": "art_001",
                    "payload": {},
                })
                
                mock_send1.assert_called_once()
                mock_send2.assert_called_once()

    @pytest.mark.asyncio
    async def test_event_without_bridge_still_works(self, event_bus):
        """Events funktionieren auch ohne installierte Bridge."""
        received = []
        
        async def handler(event):
            received.append(event)
        
        await event_bus.subscribe("direct_listener", ["artifact_created"], handler)
        
        await event_bus.publish("artifact_created", {
            "event_type": "artifact_created",
            "artifact_id": "art_001",
            "payload": {},
        })
        
        assert len(received) == 1
