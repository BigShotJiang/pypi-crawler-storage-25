"""
Final Integration Test for HestiaOS Science Edition
Verifies all core components: Telemetry, Metrics, Sync, MCP, and Audit.
"""

import pytest
import asyncio
import os
from pathlib import Path
from unittest.mock import MagicMock, AsyncMock

from core.observability.scientific_telemetry import ScientificTelemetry
from core.observability.consciousness_metrics import ConsciousnessMetricsCollector
from core.vector_sync import VectorSyncManager
from core.observability.science_audit import ScienceAuditManager
from core.hmsp_v2 import HMSPV2Protocol
from core.agent_communication import AgentRole, MessageType

class TestScienceEditionFinal:
    
    @pytest.mark.asyncio
    async def test_full_component_initialization(self):
        """Verify all new modules can be instantiated and initialized."""
        # 1. Telemetry
        telemetry = ScientificTelemetry(agent_id="science_tester")
        assert telemetry is not None
        
        # 2. Metrics
        metrics = ConsciousnessMetricsCollector(agent_id="science_tester")
        assert metrics is not None
        
        # 3. Vector Sync
        comm_client = MagicMock()
        sync = VectorSyncManager(agent_id="science_tester", comm_client=comm_client)
        assert sync is not None
        
        # 4. Audit
        audit = ScienceAuditManager(storage_path="/tmp/science_test_audit.log")
        assert audit is not None
        
        # 5. HMSP v2
        hmsp = HMSPV2Protocol(agent_id="science_tester", agent_role=AgentRole.RESEARCHER)
        assert hmsp is not None

    def test_ethical_guardrails(self):
        """Test the ethical compliance checker."""
        audit = ScienceAuditManager(storage_path="/tmp/science_test_audit.log")
        
        safe_data = {"temperature": 36.5, "status": "nominal"}
        unsafe_data = {"email": "user@example.com", "password": "123"}
        
        assert audit.check_ethical_compliance(safe_data) is True
        assert audit.check_ethical_compliance(unsafe_data) is False

    @pytest.mark.asyncio
    async def test_metrics_recording_flow(self):
        """Verify metrics aggregation works."""
        metrics = ConsciousnessMetricsCollector(agent_id="science_tester")
        metrics.record_value("interaction_density", 10.0)
        
        report = metrics.get_structured_report()
        assert "interaction_density" in report["metrics"]
        assert report["metrics"]["interaction_density"]["current"] == 10.0

    def test_roadmap_consistency(self):
        """Ensure the roadmap reflects the implementation."""
        roadmap_path = "/home/admin01/dev/01_hestiaos-gitlab-stable/docs/SCIENCE_EDITION_ROADMAP.md"
        with open(roadmap_path, "r") as f:
            content = f.read()
            
        # Check for core components in roadmap
        assert "scientific_telemetry.py" in content
        assert "anchoring_v2.py" in content
        assert "knowledge_synthesis.py" in content
        assert "HMSP v2" in content
        assert "Logic Evolution" in content
