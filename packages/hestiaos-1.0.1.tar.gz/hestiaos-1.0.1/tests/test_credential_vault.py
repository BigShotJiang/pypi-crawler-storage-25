#!/usr/bin/env python3
"""
Test script for Credential Vault implementation.
Verifies security requirements are met.
"""
import os
import sys
import json
import tempfile
import shutil
from pathlib import Path

# Add project root to path
sys.path.insert(0, str(Path(__file__).parent.parent))

from core.vault_service import CredentialVault, AccessRequest, ConsentLevel
from mcp_proxy.secret_injector import SecretRedaction

def test_encryption_at_rest():
    """Test that secrets are encrypted on disk."""
    print("Test 1: Encryption at Rest")
    
    # Create temporary directory for test
    test_dir = tempfile.mkdtemp()
    vault_path = Path(test_dir) / "test_vault.enc"
    
    try:
        # Create vault with test key
        os.environ["CREDENTIAL_VAULT_KEY"] = "test_key_32_bytes_long_for_encryption"
        vault = CredentialVault(storage_path=vault_path)
        
        # Store a test credential
        metadata = {
            "tenant_scope": "test_tenant",
            "allowed_tools": ["test_tool"],
            "allowed_roles": ["test_role"],
            "consent_level": "implicit",
            "provider": "test"
        }
        
        secret = "super_secret_api_key_12345"
        vault.put("test_credential", secret, metadata)
        
        # Read raw vault file
        with open(vault_path, 'r') as f:
            vault_data = json.load(f)
        
        # Verify secret is encrypted (not plaintext)
        encrypted_data = vault_data.get("test_credential", "")
        assert isinstance(encrypted_data, str), "Credential should be stored as string"
        assert secret not in encrypted_data, "Secret should not be in plaintext"
        assert len(encrypted_data) > len(secret), "Encrypted data should be longer"
        
        print("  ✓ Secrets are encrypted on disk")
        
        # Verify metadata file doesn't contain secrets
        meta_path = vault_path.with_suffix('.meta.json')
        with open(meta_path, 'r') as f:
            meta_data = json.load(f)
        
        credential_meta = meta_data.get("test_credential", {})
        assert "super_secret_api_key_12345" not in json.dumps(credential_meta), \
            "Metadata should not contain secrets"
        
        print("  ✓ Metadata doesn't contain secrets")
        
        return True
        
    finally:
        # Cleanup
        if os.path.exists(test_dir):
            shutil.rmtree(test_dir)
        os.environ.pop("CREDENTIAL_VAULT_KEY", None)

def test_rbac_access_control():
    """Test RBAC and tenant isolation."""
    print("\nTest 2: RBAC & Access Control")
    
    test_dir = tempfile.mkdtemp()
    vault_path = Path(test_dir) / "test_vault.enc"
    
    try:
        os.environ["CREDENTIAL_VAULT_KEY"] = "test_key_32_bytes_long_for_encryption"
        vault = CredentialVault(storage_path=vault_path)
        
        # Store credential for tenant A
        metadata = {
            "tenant_scope": "tenant_a",
            "allowed_tools": ["tool_a"],
            "allowed_roles": ["role_a"],
            "consent_level": "implicit",
            "provider": "test"
        }
        vault.put("cred_a", "secret_a", metadata)
        
        # Test 2.1: Correct tenant can access
        request_a = AccessRequest(
            credential_ref="cred_a",
            tenant_id="tenant_a",
            tool_name="tool_a",
            user_role="role_a",
            session_id="test",
            client_id="test"
        )
        secret = vault.get("cred_a", request_a)
        assert secret == "secret_a", "Correct tenant should access"
        print("  ✓ Correct tenant can access credential")
        
        # Test 2.2: Wrong tenant denied
        request_b = AccessRequest(
            credential_ref="cred_a",
            tenant_id="tenant_b",  # Wrong tenant
            tool_name="tool_a",
            user_role="role_a",
            session_id="test",
            client_id="test"
        )
        secret = vault.get("cred_a", request_b)
        assert secret is None, "Wrong tenant should be denied"
        print("  ✓ Wrong tenant is denied access")
        
        # Test 2.3: Wrong tool denied
        request_c = AccessRequest(
            credential_ref="cred_a",
            tenant_id="tenant_a",
            tool_name="tool_b",  # Wrong tool
            user_role="role_a",
            session_id="test",
            client_id="test"
        )
        secret = vault.get("cred_a", request_c)
        assert secret is None, "Wrong tool should be denied"
        print("  ✓ Wrong tool is denied access")
        
        # Test 2.4: Wrong role denied
        request_d = AccessRequest(
            credential_ref="cred_a",
            tenant_id="tenant_a",
            tool_name="tool_a",
            user_role="role_b",  # Wrong role
            session_id="test",
            client_id="test"
        )
        secret = vault.get("cred_a", request_d)
        assert secret is None, "Wrong role should be denied"
        print("  ✓ Wrong role is denied access")
        
        return True
        
    finally:
        if os.path.exists(test_dir):
            shutil.rmtree(test_dir)
        os.environ.pop("CREDENTIAL_VAULT_KEY", None)

def test_secret_redaction():
    """Test secret redaction in logs."""
    print("\nTest 3: Secret Redaction")
    
    # Test various secret patterns
    test_cases = [
        ('Authorization: Bearer sk-abc123def456', 'Authorization: Bearer [REDACTED]'),
        ('PRIVATE-TOKEN: glpat-xyz789', 'PRIVATE-TOKEN: [REDACTED]'),
        ('api_key=sk_test_123456', 'api_key=[REDACTED]'),
        ('password=superSecret123', 'password=[REDACTED]'),
        ('token="abcdef123456"', 'token=[REDACTED]'),
        ('No secrets here', 'No secrets here'),  # Should remain unchanged
    ]
    
    all_passed = True
    for input_text, expected in test_cases:
        redacted = SecretRedaction.redact_string(input_text)
        if redacted == expected:
            print(f"  ✓ Redacted: {input_text[:30]}...")
        else:
            print(f"  ✗ Failed: {input_text}")
            print(f"    Expected: {expected}")
            print(f"    Got: {redacted}")
            all_passed = False
    
    return all_passed

def test_audit_logging():
    """Test audit logging without secret leakage."""
    print("\nTest 4: Audit Logging")
    
    test_dir = tempfile.mkdtemp()
    vault_path = Path(test_dir) / "test_vault.enc"
    
    try:
        os.environ["CREDENTIAL_VAULT_KEY"] = "test_key_32_bytes_long_for_encryption"
        vault = CredentialVault(storage_path=vault_path)
        
        # Store a credential
        metadata = {
            "tenant_scope": "audit_test",
            "allowed_tools": ["audit_tool"],
            "allowed_roles": ["audit_role"],
            "consent_level": "implicit",
            "provider": "test"
        }
        vault.put("audit_cred", "secret_value_123", metadata)
        
        # Access the credential
        request = AccessRequest(
            credential_ref="audit_cred",
            tenant_id="audit_test",
            tool_name="audit_tool",
            user_role="audit_role",
            session_id="test_session",
            client_id="test_client"
        )
        vault.get("audit_cred", request)
        
        # Check audit log
        audit_log_path = vault_path.with_suffix('.audit.log')
        assert audit_log_path.exists(), "Audit log should be created"
        
        with open(audit_log_path, 'r') as f:
            lines = f.readlines()
        
        # Verify audit entries exist
        assert len(lines) >= 2, "Should have at least 2 audit entries (store + access)"
        
        # Verify no secrets in audit log
        audit_content = ''.join(lines)
        assert "secret_value_123" not in audit_content, "Secrets should not be in audit log"
        
        # Verify audit entries have required fields
        for line in lines:
            entry = json.loads(line.strip())
            assert "timestamp" in entry
            assert "event_type" in entry
            assert "credential_ref" in entry
            assert "tenant_id" in entry
            assert "decision" in entry
            assert "secret_value_123" not in json.dumps(entry), "No secrets in JSON"
        
        print("  ✓ Audit log created without secrets")
        print("  ✓ Audit entries contain required fields")
        
        return True
        
    finally:
        if os.path.exists(test_dir):
            shutil.rmtree(test_dir)
        os.environ.pop("CREDENTIAL_VAULT_KEY", None)

def test_consent_levels():
    """Test consent level enforcement."""
    print("\nTest 5: Consent Levels")
    
    test_dir = tempfile.mkdtemp()
    vault_path = Path(test_dir) / "test_vault.enc"
    
    try:
        os.environ["CREDENTIAL_VAULT_KEY"] = "test_key_32_bytes_long_for_encryption"
        vault = CredentialVault(storage_path=vault_path)
        
        # Store credential with STRICT consent
        metadata = {
            "tenant_scope": "consent_test",
            "allowed_tools": ["consent_tool"],
            "allowed_roles": ["consent_role"],
            "consent_level": "strict",  # Requires explicit consent
            "provider": "test"
        }
        vault.put("strict_cred", "secret_123", metadata)
        
        # Test 5.1: Access without consent (should fail)
        request_no_consent = AccessRequest(
            credential_ref="strict_cred",
            tenant_id="consent_test",
            tool_name="consent_tool",
            user_role="consent_role",
            session_id="test",
            client_id="test",
            consent_granted=False  # No consent
        )
        secret = vault.get("strict_cred", request_no_consent)
        assert secret is None, "STRICT consent without grant should fail"
        print("  ✓ STRICT consent blocks access without consent")
        
        # Test 5.2: Access with consent (should succeed)
        request_with_consent = AccessRequest(
            credential_ref="strict_cred",
            tenant_id="consent_test",
            tool_name="consent_tool",
            user_role="consent_role",
            session_id="test",
            client_id="test",
            consent_granted=True  # Consent granted
        )
        secret = vault.get("strict_cred", request_with_consent)
        assert secret == "secret_123", "STRICT consent with grant should succeed"
        print("  ✓ STRICT consent allows access with consent")
        
        # Test 5.3: IMPLICIT consent (should succeed without explicit consent)
        metadata_implicit = metadata.copy()
        metadata_implicit["consent_level"] = "implicit"
        vault.put("implicit_cred", "secret_456", metadata_implicit)
        
        request_implicit = AccessRequest(
            credential_ref="implicit_cred",
            tenant_id="consent_test",
            tool_name="consent_tool",
            user_role="consent_role",
            session_id="test",
            client_id="test",
            consent_granted=False  # No explicit consent needed
        )
        secret = vault.get("implicit_cred", request_implicit)
        assert secret == "secret_456", "IMPLICIT consent should succeed"
        print("  ✓ IMPLICIT consent allows access without explicit consent")
        
        return True
        
    finally:
        if os.path.exists(test_dir):
            shutil.rmtree(test_dir)
        os.environ.pop("CREDENTIAL_VAULT_KEY", None)

def test_no_plaintext_in_logs():
    """Verify no plaintext secrets appear in any output."""
    print("\nTest 6: No Plaintext Secrets in Output")
    
    import io
    import contextlib
    
    test_dir = tempfile.mkdtemp()
    vault_path = Path(test_dir) / "test_vault.enc"
    
    try:
        os.environ["CREDENTIAL_VAULT_KEY"] = "test_key_32_bytes_long_for_encryption"
        
        # Capture all output during vault operations
        output = io.StringIO()
        with contextlib.redirect_stdout(output), contextlib.redirect_stderr(output):
            vault = CredentialVault(storage_path=vault_path)
            
            metadata = {
                "tenant_scope": "log_test",
                "allowed_tools": ["log_tool"],
                "allowed_roles": ["log_role"],
                "consent_level": "implicit",
                "provider": "test"
            }
            
            # Use a recognizable test secret
            test_secret = "TEST_SECRET_glpat_abc123def456"
            vault.put("log_cred", test_secret, metadata)
            
            request = AccessRequest(
                credential_ref="log_cred",
                tenant_id="log_test",
                tool_name="log_tool",
                user_role="log_role",
                session_id="test",
                client_id="test"
            )
            vault.get("log_cred", request)
        
        # Check captured output
        captured = output.getvalue()
        
        # The secret should NOT appear in any output
        if test_secret in captured:
            print(f"  ✗ Secret leaked in output: {test_secret}")
            # Print context for debugging
            lines = captured.split('\n')
            for i, line in enumerate(lines):
                if test_secret in line:
                    print(f"    Line {i}: {line[:100]}...")
            return False
        else:
            print("  ✓ No secrets in console output")
            return True
            
    finally:
        if os.path.exists(test_dir):
            shutil.rmtree(test_dir)
        os.environ.pop("CREDENTIAL_VAULT_KEY", None)

def main():
    """Run all tests."""
    print("=" * 60)
    print("Credential Vault Security Tests")
    print("=" * 60)
    
    tests = [
        ("Encryption at Rest", test_encryption_at_rest),
        ("RBAC & Access Control", test_rbac_access_control),
        ("Secret Redaction", test_secret_redaction),
        ("Audit Logging", test_audit_logging),
        ("Consent Levels", test_consent_levels),
        ("No Plaintext in Logs", test_no_plaintext_in_logs),
    ]
    
    results = []
    for test_name, test_func in tests:
        try:
            success = test_func()
            results.append((test_name, success))
        except Exception as e:
            print(f"  ✗ {test_name} failed with exception: {e}")
            import traceback
            traceback.print_exc()
            results.append((test_name, False))
    
    print("\n" + "=" * 60)
    print("Test Summary")
    print("=" * 60)
    
    all_passed = True
    for test_name, success in results:
        status = "✓ PASS" if success else "✗ FAIL"
        print(f"{test_name:30} {status}")
        if not success:
            all_passed = False
    
    print("\n" + "=" * 60)
    if all_passed:
        print("ALL TESTS PASSED - Security requirements verified")
        print("=" * 60)
        return 0
    else:
        print("SOME TESTS FAILED - Review security implementation")
        print("=" * 60)
        return 1

if __name__ == "__main__":
    sys.exit(main())