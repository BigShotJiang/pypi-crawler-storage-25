"""
Integration tests for hardened BSE governance.

Tests the fail-closed behavior, scope enforcement, and approval requirements
for the hardened MCP governance engine.
"""

import pytest
from unittest.mock import Mock, patch, MagicMock
from datetime import datetime
import uuid

from core.mcp_governance import (
    MCPGovernanceEngine,
    GovernanceDecision,
    RiskClass,
    AuditEvent,
)
from core.request_context import RequestContext, RequestContextManager


class TestGovernanceHardening:
    """Tests for hardened governance behavior."""
    
    def setup_method(self):
        """Set up fresh governance engine for each test."""
        self.governance = MCPGovernanceEngine()
        self.request_context_manager = RequestContextManager()
    
    def test_global_scope_requires_operator(self):
        """Test that global scope requires operator privileges."""
        # Create non-operator context
        context = RequestContext(
            request_id=str(uuid.uuid4()),
            trace_id=str(uuid.uuid4()),
            user_id="user123",
            actor_id="agent456",
            scope="global",
            is_operator=False,
        )
        
        # Check permission for global operation
        decision = self.governance.check_permission(
            tool_name="embedding_service",
            operation="embed",
            request_context=context,
        )
        
        # Should be denied with approval required
        assert decision.allowed is False
        assert decision.risk_class == RiskClass.HIGH
        assert "Global scope requires operator" in decision.reason
        assert decision.requires_approval is True
        assert decision.approval_token is not None
        assert decision.approved is False
    
    def test_global_scope_with_operator_allowed(self):
        """Test that global scope is allowed for operators."""
        # Create operator context
        context = RequestContext(
            request_id=str(uuid.uuid4()),
            trace_id=str(uuid.uuid4()),
            user_id="user123",
            actor_id="operator456",
            scope="global",
            is_operator=True,
        )
        
        # Mock rate limit to allow
        with patch.object(self.governance, '_check_rate_limit', return_value=True):
            # Check permission for global operation
            decision = self.governance.check_permission(
                tool_name="embedding_service",
                operation="embed",
                request_context=context,
            )
            
            # Should be allowed (subject to other checks)
            # Note: actual decision depends on risk class and other factors
            # but shouldn't be blocked solely due to global scope
    
    def test_missing_trace_id_denied(self):
        """Test that missing trace_id results in denial."""
        # Create context without trace_id
        context = RequestContext(
            request_id=str(uuid.uuid4()),
            trace_id="",  # Empty trace_id
            user_id="user123",
            actor_id="agent456",
            scope="agent",
            is_operator=False,
        )
        
        decision = self.governance.check_permission(
            tool_name="test_tool",
            operation="test",
            request_context=context,
        )
        
        assert decision.allowed is False
        assert decision.risk_class == RiskClass.CRITICAL
        assert "Missing trace_id" in decision.reason
    
    def test_no_request_context_denied(self):
        """Test that missing request context results in denial."""
        decision = self.governance.check_permission(
            tool_name="test_tool",
            operation="test",
            request_context=None,
        )
        
        assert decision.allowed is False
        assert decision.risk_class == RiskClass.CRITICAL
        assert "Missing trace_id" in decision.reason
    
    def test_high_risk_requires_approval(self):
        """Test that HIGH risk operations require approval."""
        context = RequestContext(
            request_id=str(uuid.uuid4()),
            trace_id=str(uuid.uuid4()),
            user_id="user123",
            actor_id="agent456",
            scope="agent",
            is_operator=False,
        )
        
        # Mock to return HIGH risk
        with patch.object(self.governance, '_determine_risk_class', return_value=RiskClass.HIGH):
            with patch.object(self.governance, '_check_rate_limit', return_value=True):
                decision = self.governance.check_permission(
                    tool_name="memory_write",
                    operation="write",
                    request_context=context,
                )
                
                # Should require approval and be blocked
                assert decision.requires_approval is True
                assert decision.allowed is False  # Fail-closed
                assert decision.approval_token is not None
                assert decision.approved is False
    
    def test_critical_risk_requires_approval(self):
        """Test that CRITICAL risk operations require approval."""
        context = RequestContext(
            request_id=str(uuid.uuid4()),
            trace_id=str(uuid.uuid4()),
            user_id="user123",
            actor_id="agent456",
            scope="agent",
            is_operator=False,
        )
        
        # Mock to return CRITICAL risk
        with patch.object(self.governance, '_determine_risk_class', return_value=RiskClass.CRITICAL):
            with patch.object(self.governance, '_check_rate_limit', return_value=True):
                decision = self.governance.check_permission(
                    tool_name="system_shutdown",
                    operation="shutdown",
                    request_context=context,
                )
                
                # Should require approval and be blocked
                assert decision.requires_approval is True
                assert decision.allowed is False  # Fail-closed
                assert decision.approval_token is not None
                assert decision.approved is False
    
    def test_approval_token_workflow(self):
        """Test approval token generation and verification."""
        context = RequestContext(
            request_id=str(uuid.uuid4()),
            trace_id=str(uuid.uuid4()),
            user_id="user123",
            actor_id="agent456",
            scope="agent",
            is_operator=False,
        )
        
        # Get decision requiring approval
        with patch.object(self.governance, '_determine_risk_class', return_value=RiskClass.HIGH):
            with patch.object(self.governance, '_check_rate_limit', return_value=True):
                decision = self.governance.check_permission(
                    tool_name="memory_write",
                    operation="write",
                    request_context=context,
                )
                
                token = decision.approval_token
                assert token is not None
                assert decision.allowed is False
                assert decision.approved is False
                
                # Token should not be approved initially
                assert self.governance.is_token_approved(token) is False
                
                # Approve the token
                approved = self.governance._approve_token(token, approved_by="operator123")
                assert approved is True
                
                # Token should now be approved
                assert self.governance.is_token_approved(token) is True
    
    def test_approved_token_allows_operation(self):
        """Test that approved token allows operation on re-check."""
        context = RequestContext(
            request_id=str(uuid.uuid4()),
            trace_id=str(uuid.uuid4()),
            user_id="user123",
            actor_id="agent456",
            scope="agent",
            is_operator=False,
        )
        
        # First check - get approval token
        with patch.object(self.governance, '_determine_risk_class', return_value=RiskClass.HIGH):
            with patch.object(self.governance, '_check_rate_limit', return_value=True):
                decision1 = self.governance.check_permission(
                    tool_name="memory_write",
                    operation="write",
                    request_context=context,
                )
                
                token = decision1.approval_token
                assert token is not None
                assert decision1.allowed is False
                
                # Approve the token
                self.governance._approve_token(token, approved_by="operator123")
                
                # Simulate re-check with approved token
                # Note: In actual usage, the agent would need to pass the approved token
                # For this test, we verify the token is marked as approved
                assert self.governance.is_token_approved(token) is True
    
    def test_audit_event_contains_trace_id(self):
        """Test that audit events contain trace_id."""
        context = RequestContext(
            request_id=str(uuid.uuid4()),
            trace_id="test_trace_123",
            user_id="user123",
            actor_id="agent456",
            scope="agent",
            is_operator=False,
        )
        
        # Trigger an audit event
        with patch.object(self.governance, '_check_rate_limit', return_value=True):
            decision = self.governance.check_permission(
                tool_name="test_tool",
                operation="test",
                request_context=context,
            )
            
            # Check audit log
            audit_log = self.governance.get_audit_log()
            assert len(audit_log) > 0
            
            latest_event = audit_log[-1]
            assert latest_event.trace_id == "test_trace_123"
            assert latest_event.operation == "test"
    
    def test_audit_id_is_uuid(self):
        """Test that audit IDs use UUID format."""
        context = RequestContext(
            request_id=str(uuid.uuid4()),
            trace_id=str(uuid.uuid4()),
            user_id="user123",
            actor_id="agent456",
            scope="agent",
            is_operator=False,
        )
        
        with patch.object(self.governance, '_check_rate_limit', return_value=True):
            decision = self.governance.check_permission(
                tool_name="test_tool",
                operation="test",
                request_context=context,
            )
            
            assert decision.audit_id is not None
            assert decision.audit_id.startswith("audit_")
            # Should be hex UUID (32 chars after "audit_")
            audit_uuid = decision.audit_id[6:]  # Remove "audit_" prefix
            assert len(audit_uuid) == 32
            # Should be valid hex
            int(audit_uuid, 16)  # Will raise ValueError if not hex
    
    def test_rate_limit_blocking(self):
        """Test that rate limiting blocks operations."""
        context = RequestContext(
            request_id=str(uuid.uuid4()),
            trace_id=str(uuid.uuid4()),
            user_id="user123",
            actor_id="agent456",
            scope="agent",
            is_operator=False,
        )
        
        # Mock rate limit to deny
        with patch.object(self.governance, '_check_rate_limit', return_value=False):
            decision = self.governance.check_permission(
                tool_name="test_tool",
                operation="test",
                request_context=context,
            )
            
            assert decision.allowed is False
            assert "rate limit" in decision.reason.lower() or "Permission denied" in decision.reason
    
    def test_scope_validation_agent_allowed(self):
        """Test that agent scope is allowed for non-operators."""
        context = RequestContext(
            request_id=str(uuid.uuid4()),
            trace_id=str(uuid.uuid4()),
            user_id="user123",
            actor_id="agent456",
            scope="agent",
            is_operator=False,
        )
        
        with patch.object(self.governance, '_check_rate_limit', return_value=True):
            decision = self.governance.check_permission(
                tool_name="embedding_service",
                operation="embed",
                request_context=context,
            )
            
            # Agent scope should not be blocked by scope check
            # (may still be blocked by other checks like risk class)
            # We just verify it doesn't get "Global scope requires operator" error
            assert "Global scope requires operator" not in decision.reason
    
    def test_legacy_interface_backward_compatibility(self):
        """Test that legacy interface still works (for integration)."""
        # The old check_permission signature should still be callable
        # but will fail due to missing request_context
        decision = self.governance.check_permission(
            tool_name="test_tool",
            user_id="user123",
            scope="agent",
            operation="test",
        )
        
        # Should fail due to missing request_context
        assert decision.allowed is False
        assert decision.risk_class == RiskClass.CRITICAL


if __name__ == "__main__":
    pytest.main([__file__, "-v"])