#!/usr/bin/env python3
"""
Real-World Fix Engine Test

This test validates the AST-based fix engine with real HestiaOS code.
It intentionally introduces security vulnerabilities and tests if the fix engine can detect and fix them.
"""

import sys
import os
import tempfile
import asyncio
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from core.capabilities.ast_fix_engine import ASTFixEngine, FixConfidence, FixType
from core.hsp.policies.auto_fix_policy import AutoFixPolicy, CodeOwnershipLevel
from core.hsp.schemas import HSPRequestSchema


def create_vulnerable_test_file():
    """Create a test file with intentional security vulnerabilities"""
    test_code = '''#!/usr/bin/env python3
"""
Test file with intentional security vulnerabilities for fix engine testing.
"""

import subprocess
import os

# B307: eval() usage
def calculate_expression(expr):
    """Calculate expression using eval (intentionally vulnerable)"""
    return eval(expr)  # VULNERABLE: eval with user input

# B602: subprocess with shell=True
def run_command(cmd):
    """Run command using subprocess (intentionally vulnerable)"""
    result = subprocess.run(cmd, shell=True)  # VULNERABLE: shell=True in call
    return result.returncode

# B105: hardcoded password
def connect_to_database():
    """Connect to database with hardcoded password"""
    password = "SuperSecret123!"  # VULNERABLE: hardcoded string
    return f"Connected with password: {password}"

# B106: password in variable name
def authenticate_user():
    """Authenticate user with password variable"""
    user_password = "AnotherSecret456"  # VULNERABLE: variable name
    return user_password

# Safe code for comparison
def safe_function():
    """This function is safe and should not be modified"""
    x = 1 + 2
    return x * 3

if __name__ == "__main__":
    # Test the vulnerable functions
    print(calculate_expression("2 + 2"))
    print(run_command("echo hello"))
    print(connect_to_database())
    print(authenticate_user())
'''
    return test_code


def test_fix_engine_with_real_vulnerabilities():
    """Test fix engine with intentionally vulnerable code"""
    print("Testing fix engine with real vulnerabilities...")
    
    # Create test file
    test_code = create_vulnerable_test_file()
    
    # Simulate Bandit findings
    bandit_findings = [
        {"test_id": "B307", "line_number": 12, "issue_text": "Use of eval detected."},
        {"test_id": "B602", "line_number": 17, "issue_text": "subprocess call with shell=True identified."},
        {"test_id": "B105", "line_number": 23, "issue_text": "Hardcoded password string."},
        {"test_id": "B106", "line_number": 29, "issue_text": "Possible hardcoded password in variable name."},
    ]
    
    # Initialize fix engine
    fix_engine = ASTFixEngine()
    
    # Generate fixes
    fixes = fix_engine.generate_fixes("vulnerable_test.py", test_code, bandit_findings)
    
    print(f"  Generated {len(fixes)} fixes")
    assert len(fixes) == 4, f"Expected 4 fixes, got {len(fixes)}"
    
    # Check fix types
    fix_types = {fix.fix_type for fix in fixes}
    assert FixType.SECURITY in fix_types, "Should have security fixes"
    
    # Apply fixes
    fixed_code, results = fix_engine.apply_fixes(test_code, fixes)
    
    # Count successful fixes
    successful_fixes = len([r for r in results if r['status'] == 'applied'])
    print(f"  Applied fixes: {successful_fixes} successful")
    assert successful_fixes >= 3, f"Expected at least 3 successful fixes, got {successful_fixes}"
    
    # Verify fixes were applied
    import re
    
    # Check eval was replaced
    assert "eval(" not in fixed_code or "safe_eval(" in fixed_code or "ast.literal_eval(" in fixed_code, "eval() still present in code context"
    
    # Check shell=True was removed
    assert not re.search(r'shell\s*=\s*True\s*[),]', fixed_code), "shell=True still present in code context"
    
    # Check hardcoded password was replaced
    assert not re.search(r'=\s*["\']SuperSecret123!["\']', fixed_code), "hardcoded password SuperSecret123! still present in variable assignment"
    assert "os.environ.get" in fixed_code, "os.environ.get not found"
    
    print("  ✓ Fix engine test with vulnerabilities passed")
    return True


async def test_hsp_policy_integration():
    """Test HSP policy integration with fix engine"""
    print("Testing HSP policy integration...")
    
    # Create test fixes
    test_fixes = [
        {
            "fix_id": "eval_to_safe_eval",
            "fix_type": "security",
            "confidence": 0.95,
            "description": "Replace eval() with safe_eval()",
            "line_number": 11
        },
        {
            "fix_id": "hardcoded_password",
            "fix_type": "security_high_risk",
            "confidence": 0.8,
            "description": "Replace hardcoded password with env var",
            "line_number": 23
        }
    ]
    
    # Initialize HSP policy
    policy = AutoFixPolicy()
    
    # Test context: application code in staging
    context = {
        "file_path": "/home/user/project/app/vulnerable_test.py",
        "security_level": "high",
        "environment": "staging",
        "contains_secrets": True,
        "current_changes_in_file": 0,
        "has_approval": True
    }
    
    request = HSPRequestSchema(
        request_id="test_real_world",
        trace_id="trace_real_world",
        timestamp="2024-01-01T00:00:00Z",
        context=context,
        source="test",
        metadata={}
    )
    
    # Evaluate policy
    constraints = await policy.evaluate(request, test_fixes, context)
    
    print(f"  Policy evaluation result: {constraints.is_valid}")
    print(f"  Allowed fixes: {len(constraints.metadata.get('allowed_fixes', []))}")
    print(f"  Denied fixes: {len(constraints.metadata.get('denied_fixes', []))}")
    
    # Should be valid and allow fixes for staging environment
    assert constraints.is_valid == True, "Should be valid for staging"
    assert len(constraints.metadata.get('allowed_fixes', [])) > 0, "Should allow some fixes"
    
    print("  ✓ HSP policy integration test passed")
    return True


async def test_end_to_end_workflow():
    """Test end-to-end workflow: detect, generate fixes, apply with HSP governance"""
    print("Testing end-to-end workflow...")
    
    # Step 1: Create vulnerable code
    test_code = create_vulnerable_test_file()
    
    # Step 2: Simulate Bandit findings
    bandit_findings = [
        {"test_id": "B307", "line_number": 12, "issue_text": "Use of eval detected."},
        {"test_id": "B105", "line_number": 23, "issue_text": "Hardcoded password string."},
    ]
    
    # Step 3: Generate fixes
    fix_engine = ASTFixEngine()
    fixes = fix_engine.generate_fixes("e2e_test.py", test_code, bandit_findings)
    
    print(f"  Generated {len(fixes)} fixes from findings")
    
    # Step 4: Convert fixes to HSP format
    hsp_fixes = []
    for fix in fixes:
        hsp_fixes.append({
            "fix_id": fix.fix_id,
            "fix_type": fix.fix_type.value,
            "confidence": 0.9 if fix.confidence == FixConfidence.HIGH else 0.7,
            "description": fix.description,
            "line_number": fix.line_number
        })
    
    # Step 5: Apply HSP policy
    policy = AutoFixPolicy()
    context = {
        "file_path": "/home/user/project/app/e2e_test.py",
        "security_level": "medium",
        "environment": "development",
        "contains_secrets": False,
        "current_changes_in_file": 0,
        "has_approval": False
    }
    
    request = HSPRequestSchema(
        request_id="test_e2e",
        trace_id="trace_e2e",
        timestamp="2024-01-01T00:00:00Z",
        context=context,
        source="test",
        metadata={}
    )
    
    constraints = await policy.evaluate(request, hsp_fixes, context)
    
    print(f"  HSP allowed {len(constraints.metadata.get('allowed_fixes', []))} of {len(hsp_fixes)} fixes")
    
    # Step 6: Apply only allowed fixes
    allowed_fix_ids = constraints.metadata.get('allowed_fixes', [])
    allowed_fixes = [fix for fix in fixes if fix.fix_id in allowed_fix_ids]
    
    if allowed_fixes:
        fixed_code, results = fix_engine.apply_fixes(test_code, allowed_fixes)
        successful = len([r for r in results if r['status'] == 'applied'])
        print(f"  Applied {successful} allowed fixes successfully")
        assert successful > 0, "Should apply at least one fix"
    else:
        print("  No fixes allowed by HSP (this is valid based on policy)")
    
    print("  ✓ End-to-end workflow test passed")
    return True


async def run_all_tests_async():
    """Run all real-world fix engine tests (async version)"""
    print("=" * 60)
    print("Real-World Fix Engine Test Suite")
    print("=" * 60)
    
    tests = [
        test_fix_engine_with_real_vulnerabilities,
        test_hsp_policy_integration,
        test_end_to_end_workflow,
    ]
    
    passed = 0
    failed = 0
    
    for test in tests:
        try:
            if test.__name__ == "test_fix_engine_with_real_vulnerabilities":
                # This is a sync function
                if test():
                    passed += 1
            else:
                # These are async functions
                if await test():
                    passed += 1
        except Exception as e:
            print(f"  ✗ Test {test.__name__} failed: {e}")
            failed += 1
    
    print("\n" + "=" * 60)
    print(f"Test Results: {passed} passed, {failed} failed")
    print("=" * 60)
    
    if failed == 0:
        print("✓ All tests passed!")
        return True
    else:
        print(f"✗ {failed} test(s) failed")
        return False


def run_all_tests():
    """Run all tests synchronously"""
    import asyncio
    return asyncio.run(run_all_tests_async())


if __name__ == "__main__":
    success = run_all_tests()
    sys.exit(0 if success else 1)