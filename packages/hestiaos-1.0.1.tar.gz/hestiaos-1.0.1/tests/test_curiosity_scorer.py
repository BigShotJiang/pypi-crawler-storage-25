import unittest
from core.runtime.health.heartbeat_system import CuriosityScorer

class TestCuriosityScorer(unittest.TestCase):
    def setUp(self):
        self.scorer = CuriosityScorer()

    def test_calculate_novelty_empty(self):
        self.assertEqual(self.scorer.calculate_novelty(""), 0.0)

    def test_calculate_novelty_low(self):
        # Repetitive string should have low entropy
        score = self.scorer.calculate_novelty("aaaaa")
        self.assertLess(score, 0.1)

    def test_calculate_novelty_high(self):
        # Diverse string should have higher entropy
        score = self.scorer.calculate_novelty("abcdefghij1234567890")
        self.assertGreater(score, 0.5)

    def test_calculate_learning_potential_empty(self):
        self.assertEqual(self.scorer.calculate_learning_potential("", {}), 0.0)

    def test_calculate_learning_potential_question(self):
        # Questions should have higher potential
        score = self.scorer.calculate_learning_potential("What is the meaning of life?", {})
        self.assertGreater(score, 0.4)

    def test_calculate_curiosity_score(self):
        # Combined score
        score = self.scorer.calculate_curiosity_score("Tell me about the universe?", {})
        self.assertGreater(score, 0.0)
        self.assertLessEqual(score, 1.0)

if __name__ == "__main__":
    unittest.main()
