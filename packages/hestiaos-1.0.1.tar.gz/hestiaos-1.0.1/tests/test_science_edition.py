import os
import pytest
import shutil
import asyncio
from datetime import datetime, timedelta
from typing import Dict, Any

from core.observability.scientific_telemetry import ScientificTelemetry, TelemetryMetric
from core.anchoring_v2 import AnchoringV2
from core.knowledge_synthesis import KnowledgeSynthesis
from core.consciousness_identity import IdentityManager, CompositeIdentity
from core.shared_context import SharedContextManager, ContextType, ContextPriority, ContextConsistency

# Mock LLM Bridge for testing
class MockLLMBridge:
    async def generate(self, prompt: str, **kwargs) -> Dict[str, Any]:
        return {
            "success": True,
            "text": "Synthesized knowledge report content.",
            "provider": "mock",
            "usage": {"total_tokens": 100}
        }

@pytest.fixture
def test_dirs():
    dirs = {
        "logs": "/tmp/hestia_test_logs",
        "anchors": "/tmp/hestia_test_anchors",
        "vault": "/tmp/hestia_test_vault"
    }
    for d in dirs.values():
        os.makedirs(d, exist_ok=True)
    yield dirs
    # Cleanup
    for d in dirs.values():
        shutil.rmtree(d, ignore_errors=True)

class TestScientificTelemetry:
    def test_log_interaction_and_calculate_metrics(self, test_dirs):
        telemetry = ScientificTelemetry(agent_id="test_agent", log_directory=test_dirs["logs"])
        
        # Log some interactions
        telemetry.log_interaction("agent_a", "agent_b", "request", success=True)
        telemetry.log_interaction("agent_b", "agent_a", "response", success=True)
        telemetry.log_interaction("agent_a", "agent_c", "broadcast", success=False)
        
        # Manually trigger metric calculation
        metric = telemetry.calculate_metrics()
        
        assert metric.interaction_count == 3
        assert metric.active_agents == 3
        assert metric.interaction_density == 1.0 # 3 interactions / 3 agents
        assert metric.system_entropy > 0.0
        assert metric.coordination_score == 2/3 # 2 successes / 3 total
        
        summary = telemetry.get_summary()
        assert summary["interactions_last_min"] == 3
        assert summary["active_agents"] == 3

    def test_export_functionality(self, test_dirs):
        telemetry = ScientificTelemetry(agent_id="test_agent", log_directory=test_dirs["logs"])
        telemetry.log_interaction("agent_a", "agent_b", "request")
        telemetry.calculate_metrics()
        
        csv_file = "test_export.csv"
        json_file = "test_export.json"
        
        telemetry.export_csv(csv_file)
        telemetry.export_json(json_file)
        
        assert os.path.exists(os.path.join(test_dirs["logs"], csv_file))
        assert os.path.exists(os.path.join(test_dirs["logs"], json_file))

class TestAnchoringV2:
    def test_create_and_recover_anchor(self, test_dirs):
        anchoring = AnchoringV2(anchor_dir=test_dirs["anchors"])
        identity_manager = IdentityManager(agent_name="Test Agent", agent_role="tester")
        identity = identity_manager.identity
        
        # Create anchor
        anchor_path = anchoring.create_anchor(identity)
        assert os.path.exists(anchor_path)
        
        # Recover anchor
        recovered_identity = anchoring.recover_identity(identity.software_identity.agent_id)
        assert recovered_identity is not None
        assert recovered_identity.software_identity.agent_name == "Test Agent"
        assert recovered_identity.software_identity.agent_id == identity.software_identity.agent_id

@pytest.mark.asyncio
class TestKnowledgeSynthesis:
    async def test_synthesize_experience(self, test_dirs, monkeypatch):
        from unittest.mock import MagicMock
        
        mock_identity = MagicMock()
        mock_identity.identity.software_identity.agent_id = "agent_id_1"
        mock_identity.agent_name = "Agent 1"
        
        mock_protocol = MagicMock()
        mock_comm = MagicMock()
        # Mock communication client to avoid background tasks
        mock_comm.register_handler = MagicMock(side_effect=lambda *args, **kwargs: asyncio.Future())
        
        scm = SharedContextManager(mock_identity, mock_protocol, mock_comm)
        # Manually create default spaces since we're not calling .start() which creates them
        from core.shared_context import ContextSpace, ContextType as CT
        scm.context_spaces["task_coordination"] = ContextSpace(
            space_id="task_coordination",
            name="Task Coordination",
            description="test",
            context_type=CT.TASK,
            creator_id="agent_id_1"
        )
        
        llm = MockLLMBridge()
        
        synthesis = KnowledgeSynthesis(scm, llm, output_dir=test_dirs["vault"])
        
        # Add some mock context items
        await scm.create_context_item(
            context_type=ContextType.KNOWLEDGE,
            content={"observation": "High interaction density detected"},
            space_id="task_coordination"
        )
        
        # Perform synthesis
        filepath = await synthesis.synthesize_recent_experience(hours=1)
        
        assert filepath is not None
        assert os.path.exists(filepath)
