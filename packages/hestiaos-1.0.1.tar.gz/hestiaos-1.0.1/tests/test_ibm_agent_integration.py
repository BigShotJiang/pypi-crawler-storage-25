import asyncio
import os
import json
from pathlib import Path
from dotenv import load_dotenv
# Legacy AntigravityBridge (ehemals core.antigravity_bridge — archiviert in archive/antigravity_bridge.py)
# Antigravity ist obsolet — Bridge gibt None zurück
def get_bridge():
    return None

async def test_ibm_agent_integration():
    print("🚀 Teste IBM Agent Integration...")
    
    # Lade .env
    env_path = Path(__file__).parent.parent / ".env"
    load_dotenv(env_path)
    
    bridge = get_bridge()
    
    # Test 1: Routing-Check
    print("\n📋 Test 1: Routing Check")
    test_prompt = "Frage an den IBM Watsonx Orchestrate Agent: Wie kann ich meine Workflows automatisieren?"
    print(f"📝 Prompt: {test_prompt}")
    
    result = await bridge.process(test_prompt)
    
    print("\n📊 Ergebnis:")
    print(json.dumps({
        "success": result.get("success"),
        "provider": result.get("provider"),
        "fallback_from": result.get("fallback_from"),
        "text_snippet": result.get("text", "")[:100] + "..." if result.get("text") else None,
        "error": result.get("error")
    }, indent=2))
    
    # Test 2: Fallback Check (Simulation durch falsche ID)
    print("\n📋 Test 2: Fallback Check (Simuliert)")
    # Wir ändern kurz die ID im Environment für diesen Test-Lauf der Bridge
    os.environ["IBM_AGENT_ID"] = "invalid-id"
    # Da die Bridge-Objekte in RoutingLogic bereits erstellt wurden, 
    # müssen wir entweder die Bridge-Instanz manipulieren oder einen neuen Test machen.
    # Einfacher: Wir prüfen ob das System bei Fehlern auf Watsonx/Ollama ausweicht.
    
    if result.get("success"):
        print("\n✅ IBM Agent Integrationstest erfolgreich!")
    else:
        print("\n⚠️ IBM Agent Test schlug fehl (evtl. wegen 404/401), Fallback wurde geprüft.")

if __name__ == "__main__":
    asyncio.run(test_ibm_agent_integration())
