#!/usr/bin/env python3
"""Test to understand routing message duplication issue."""

import asyncio
import json

async def simulate_orchestrator():
    """Simulate the orchestrator's _process_message_internal method."""
    # Simulate scheduler returning 3 agents
    selected_agent_id = "expert_gpu"
    fallback_chain = ["fast_cpu", "tool_cpu"]
    agents_to_try = [selected_agent_id] + fallback_chain
    
    print(f"Agents to try: {agents_to_try}")
    
    # Yield routing message (once)
    routing_msg = f"data: {json.dumps({'type': 'routing', 'content': f' [Routing to {selected_agent_id}...] '})}\n\n"
    print(f"Yielding routing message: {routing_msg.strip()}")
    yield routing_msg
    
    # Simulate trying each agent
    for i, agent_id in enumerate(agents_to_try):
        print(f"\nTrying agent {i+1}: {agent_id}")
        
        # Simulate agent failure
        if i < len(agents_to_try) - 1:  # All but last fail
            print(f"Agent {agent_id} failed, continuing to next...")
            continue
        else:
            # Last agent succeeds
            print(f"Agent {agent_id} succeeded!")
            yield f"data: {json.dumps({'type': 'token', 'content': 'Hello from LLM!'})}\n\n"
            break
    
    yield "data: [DONE]\n\n"

async def simulate_process_message_wrapper():
    """Simulate the process_message wrapper with queue system."""
    # Simulate the queue (empty for now)
    queue = asyncio.Queue()
    
    async def _run_orchestration():
        try:
            async for chunk in simulate_orchestrator():
                yield chunk
        finally:
            await queue.put(None)
    
    orch_gen = _run_orchestration()
    
    print("\n=== Wrapper output ===")
    chunks_collected = []
    
    try:
        while True:
            # Check queue (empty)
            while not queue.empty():
                event = await queue.get()
                if event is None:
                    break
                chunk = f"data: {json.dumps(event)}\n\n"
                print(f"Queue yield: {chunk.strip()}")
                chunks_collected.append(chunk)
                yield chunk
            
            try:
                chunk = await anext(orch_gen)
                if chunk == "data: [DONE]\n\n":
                    while not queue.empty():
                        event = await queue.get()
                        if event is None:
                            break
                        chunk = f"data: {json.dumps(event)}\n\n"
                        print(f"Queue yield (after DONE): {chunk.strip()}")
                        chunks_collected.append(chunk)
                        yield chunk
                    break
                
                print(f"Direct yield: {chunk.strip()}")
                chunks_collected.append(chunk)
                yield chunk
            except StopAsyncIteration:
                break
    finally:
        print(f"\nTotal chunks collected: {len(chunks_collected)}")
        for i, chunk in enumerate(chunks_collected):
            print(f"Chunk {i+1}: {chunk.strip()}")

async def simulate_agent_process_message():
    """Simulate agent.process_message collecting response."""
    response_text = ""
    
    print("\n=== Agent collecting response ===")
    async for chunk in simulate_process_message_wrapper():
        if not chunk:
            continue
        
        # Simulate agent's line splitting logic
        lines = chunk.split('\n')
        for line in lines:
            line = line.strip()
            if not line or not line.startswith("data: "):
                continue
            
            payload = line[6:].strip()
            if payload == "[DONE]":
                break
            
            try:
                data = json.loads(payload)
                if data.get("type") in ["token", "routing", "tool_call"]:
                    content = data.get("content", "")
                    response_text += content
                    print(f"Appended content: '{content}'")
            except:
                pass
    
    print(f"\nFinal response text: '{response_text}'")
    return response_text

async def main():
    print("=== Testing routing duplication issue ===\n")
    
    # Run the simulation
    response = await simulate_agent_process_message()
    
    print(f"\n=== Result ===")
    print(f"Response contains routing message {response.count('Routing to')} times")
    if response.count('Routing to') > 1:
        print("ERROR: Routing message appears multiple times!")
    else:
        print("OK: Routing message appears only once")

if __name__ == "__main__":
    asyncio.run(main())