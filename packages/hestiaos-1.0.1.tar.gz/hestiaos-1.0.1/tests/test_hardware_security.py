import os
import pytest
import asyncio
import shutil
from pathlib import Path
from core.encryption_system import EncryptionManager, get_encryption_manager
from core.hardware_security import HardwareKeyModule

@pytest.fixture
def temp_config(tmp_path):
    config_dir = tmp_path / "config"
    key_dir = tmp_path / "keys"
    config_dir.mkdir()
    key_dir.mkdir()
    return config_dir, key_dir

def test_hardware_fail_closed(temp_config, monkeypatch):
    """Test that system fails closed if hardware is configured but missing."""
    config_dir, key_dir = temp_config
    monkeypatch.setenv("HESTIA_SECURITY_BACKEND", "yubikey-piv")
    monkeypatch.setenv("HESTIA_YUBIKEY_PIN", "INVALID_PIN_FOR_FAIL_CLOSED")
    
    # Create valid metadata but no hardware unwrap success
    metadata = {
        "created_at": "2026-03-10T12:00:00",
        "ciphertext": "invalid",
        "recovery_wrapped": "invalid"
    }
    with open(key_dir / "aes_context_master.wrapped", 'w') as f:
        import json
        json.dump(metadata, f)

    # Initialization should raise PermissionError/Exception because unwrap fails
    with pytest.raises(Exception) as excinfo:
        # We need to bypass the singleton for testing
        mgr = EncryptionManager(config_path=key_dir)
    
    assert "Hardware initialization failed" in str(excinfo.value)

def test_yubikey_enrollment_and_unwrap(temp_config, monkeypatch):
    """Test full enrollment and unwrap cycle (simulated)."""
    config_dir, key_dir = temp_config
    monkeypatch.setenv("HESTIA_SECURITY_BACKEND", "yubikey-piv")
    monkeypatch.setenv("HESTIA_YUBIKEY_PIN", "SIMULATED_PIN")
    
    mgr = EncryptionManager(config_path=key_dir)
    
    # Enroll
    mnemonic = mgr.enroll_yubikey(pin="SIMULATED_PIN")
    assert len(mnemonic.split()) == 24
    
    # Restart Manager (simulate reload)
    mgr2 = EncryptionManager(config_path=key_dir)
    assert "aes_context_master" in mgr2.keys
    assert mgr2.keys["aes_context_master"].key_data == b"simulated_unwrapped_master_key"

def test_recovery_phrase_logic(temp_config, monkeypatch):
    """Test recovery phrase unwrap logic."""
    config_dir, key_dir = temp_config
    # Start as local, then switch
    mgr = EncryptionManager(config_path=key_dir)
    
    # Access the raw key before wrapping
    original_key = mgr.keys["aes_context_master"].key_data
    
    # Enroll
    mnemonic = mgr.enroll_yubikey(pin="SIMULATED_PIN")
    
    # Wipe keys from manager to simulate cold start
    mgr.keys.clear()
    
    # Recover
    success = mgr.recover_master_key(mnemonic)
    assert success is True
    assert mgr.keys["aes_context_master"].key_data == original_key

def test_gated_unwrap_wrong_pin(temp_config, monkeypatch):
    """Test that wrong PIN prevents unwrapping."""
    config_dir, key_dir = temp_config
    monkeypatch.setenv("HESTIA_SECURITY_BACKEND", "yubikey-piv")
    monkeypatch.setenv("HESTIA_YUBIKEY_PIN", "WRONG_PIN")
    
    # Pre-create metadata
    mgr_init = EncryptionManager(config_path=key_dir)
    mgr_init.enroll_yubikey(pin="SIMULATED_PIN")
    
    # Reload with wrong PIN
    with pytest.raises(Exception):
        EncryptionManager(config_path=key_dir)

@pytest.mark.asyncio
async def test_rotation_on_compromise(temp_config):
    """Test re-wrapping master key when phrase is compromised."""
    config_dir, key_dir = temp_config
    mgr = EncryptionManager(config_path=key_dir)
    
    # Initial enrollment
    old_mnemonic = mgr.enroll_yubikey(pin="SIMULATED_PIN")
    
    # Re-enroll (Rotation)
    new_mnemonic = mgr.enroll_yubikey(pin="SIMULATED_PIN")
    
    assert old_mnemonic != new_mnemonic
    
    # Verify new works, old fails (actually, in this impl re-enroll overwrites metadata)
    assert mgr.recover_master_key(new_mnemonic) is True
    # The old mnemonic will fail because salt/params changed or just ciphertext mismatch
    # In our impl, salt is re-generated if no params file, but re-enroll keeps same key.
    # However, unwrap_key will fail on AESGCM tag mismatch if KEK is different.
    assert mgr.recover_master_key(old_mnemonic) is False
