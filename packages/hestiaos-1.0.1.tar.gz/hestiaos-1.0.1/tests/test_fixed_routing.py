h#!/usr/bin/env python3
"""Test the fixed routing duplication issue."""

import asyncio
import json
import sys
import os

# Add the project root to the path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

async def test_orchestrator_direct():
    """Test the orchestrator directly to see routing messages."""
    print("=== Testing orchestrator routing duplication fix ===\n")
    
    # We need to mock the dependencies
    from unittest.mock import AsyncMock, Mock, MagicMock
    
    # Create mock dependencies
    mock_llm_engine = Mock()
    mock_context_manager = Mock()
    mock_tool_executor = Mock()
    mock_models_config = {}
    
    # Import after path setup
    from core.orchestrator import Orchestrator
    from core.context import ExecutionContext
    from tests.conftest import MockBackendRouter
    
    # Create orchestrator with mocks
    orchestrator = Orchestrator(
        llm_engine=mock_llm_engine,
        context_manager=mock_context_manager,
        tool_executor=mock_tool_executor,
        models_config=mock_models_config,
        backend_router=MockBackendRouter()
    )
    
    # Mock the scheduler to return 3 agents
    mock_scheduler = AsyncMock()
    mock_scheduler.select_agent.return_value = MagicMock(
        selected_agent="expert_gpu",
        fallback_chain=["fast_cpu", "tool_cpu"],
        agent_type="VLLM",
        confidence=0.9,
        reasoning="Test reasoning",
        estimated_latency_ms=100.0
    )
    orchestrator.scheduler = mock_scheduler
    
    # Mock the backend router
    mock_backend_router = AsyncMock()
    mock_selection = MagicMock()
    mock_selection.backend_id = "expert_gpu"
    mock_selection.endpoint = "http://localhost:8001"
    mock_selection.model = "Qwen/Qwen2.5-1.5B-Instruct"
    mock_backend_router.select_backend.return_value = mock_selection
    orchestrator.backend_router = mock_backend_router
    
    # Mock the backend client to simulate vLLM response
    mock_backend_client = AsyncMock()
    
    # Simulate vLLM response with tokens
    async def mock_call_generator(selection, messages, trace_id):
        # First yield some content
        yield {"content": "Hello"}
        yield {"content": " from"}
        yield {"content": " vLLM!"}
    
    mock_backend_client.call = mock_call_generator
    orchestrator.backend_client = mock_backend_client
    
    # Mock other dependencies
    orchestrator.task_classifier = Mock()
    orchestrator.task_classifier.classify.return_value = MagicMock(
        categories=[MagicMock(value="general")],
        requires_gpu=False,
        requires_tools=False,
        complexity_score=0.5
    )
    
    orchestrator.prompts = {"expert_gpu": "You are an expert assistant."}
    orchestrator.context_manager.load_context = AsyncMock(return_value={"chat_history": []})
    orchestrator._get_tools_prompt = Mock(return_value="")
    orchestrator._get_skills_xml = Mock(return_value="")
    orchestrator._build_context_header = Mock(return_value="=== CONTEXT ===\n")
    
    # Create execution context
    context = ExecutionContext(
        session_id="test_session",
        tenant_id="test_tenant",
        mode="business",
        trace_id="test_trace"
    )
    
    # Collect all chunks
    chunks = []
    print("Collecting response chunks...")
    async for chunk in orchestrator.process_message("Hello, how are you?", context):
        chunks.append(chunk)
        print(f"Chunk: {chunk.strip()}")
    
    # Analyze the chunks
    print(f"\n=== Analysis ===")
    print(f"Total chunks: {len(chunks)}")
    
    routing_count = 0
    token_count = 0
    done_count = 0
    
    for chunk in chunks:
        if not chunk.startswith("data: "):
            continue
        
        payload = chunk[6:].strip()
        if payload == "[DONE]":
            done_count += 1
            continue
        
        try:
            data = json.loads(payload)
            if data.get("type") == "routing":
                routing_count += 1
                print(f"Routing message: {data.get('content')}")
            elif data.get("type") == "token":
                token_count += 1
        except:
            pass
    
    print(f"\nRouting messages: {routing_count}")
    print(f"Token messages: {token_count}")
    print(f"DONE messages: {done_count}")
    
    if routing_count == 1:
        print("✅ SUCCESS: Routing message appears only once!")
        return True
    else:
        print(f"❌ FAILURE: Routing message appears {routing_count} times (should be 1)")
        return False

async def test_api_endpoint():
    """Test the API endpoint to see actual response."""
    print("\n=== Testing API endpoint ===")
    
    # We can't easily test the full API without starting the server,
    # but we can test the agent's process_message method
    
    try:
        from core.agent import Core01Agent
        
        # Create a mock agent with our fixed orchestrator
        mock_orchestrator = Mock()
        
        # Simulate the agent's process_message method
        async def mock_stream_process_message(message, use_tools=True, use_cloud=False, 
                                            session_id=None, tenant_id=None, agent_id=None):
            # Simulate our fixed orchestrator response
            yield 'data: {"type": "routing", "content": " [Routing to expert_gpu...] "}\n\n'
            yield 'data: {"type": "token", "content": "Hello"}\n\n'
            yield 'data: {"type": "token", "content": " from vLLM"}\n\n'
            yield 'data: [DONE]\n\n'
        
        mock_orchestrator.process_message = mock_stream_process_message
        
        # Create agent with mock orchestrator
        agent = Core01Agent()
        agent.orchestrator = mock_orchestrator
        
        # Test process_message (non-streaming)
        print("Testing agent.process_message()...")
        result = await agent.process_message(
            message="Hello",
            session_id="test",
            tenant_id="test"
        )
        
        response_text = result.get("response", "")
        routing_count = response_text.count("Routing to")
        
        print(f"Response: {response_text[:100]}...")
        print(f"Routing count in response: {routing_count}")
        
        if routing_count == 1:
            print("✅ SUCCESS: Agent response contains routing message only once!")
            return True
        else:
            print(f"❌ FAILURE: Agent response contains routing message {routing_count} times")
            return False
            
    except Exception as e:
        print(f"Error testing API endpoint: {e}")
        return False

async def main():
    """Run all tests."""
    print("Testing routing duplication fix...\n")
    
    # Test 1: Direct orchestrator test
    test1_passed = await test_orchestrator_direct()
    
    # Test 2: API endpoint test  
    test2_passed = await test_api_endpoint()
    
    print(f"\n=== Final Results ===")
    print(f"Test 1 (Orchestrator): {'✅ PASS' if test1_passed else '❌ FAIL'}")
    print(f"Test 2 (API Endpoint): {'✅ PASS' if test2_passed else '❌ FAIL'}")
    
    if test1_passed and test2_passed:
        print("\n🎉 All tests passed! Routing duplication issue is fixed.")
        return 0
    else:
        print("\n⚠️ Some tests failed. Routing duplication may still exist.")
        return 1

if __name__ == "__main__":
    exit_code = asyncio.run(main())
    sys.exit(exit_code)