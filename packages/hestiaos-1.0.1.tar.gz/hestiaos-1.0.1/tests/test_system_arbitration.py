import pytest
from unittest.mock import MagicMock, patch
import time

from core.bootstrap.control_plane import SystemControlPlane, SystemCondition, CanonicalState, SystemSignals
from core.bootstrap.arbitrator import SystemArbitrator, ArbitrationResult
from core.governance.dsgk_decision import DSGKDecision, DecisionType
from core.processing.network_error_classifier import CircuitState
from core.bootstrap.models import BootState

@pytest.fixture
def mock_signals():
    return SystemSignals(
        boot_state=BootState.READY,
        db_ready=True,
        migrations_ok=True,
        inference_ready=True,
        inference_latency_ms=100.0,
        epoch_id=1,
        macro_id=1
    )

@pytest.fixture
def control_plane():
    return SystemControlPlane()

@pytest.fixture
def arbitrator():
    return SystemArbitrator()

def test_control_plane_transitions(control_plane):
    """Test that control plane correctly transitions between states."""
    # 1. GREEN
    signals = SystemSignals(
        boot_state=BootState.READY,
        db_ready=True,
        migrations_ok=True,
        inference_ready=True,
        inference_latency_ms=100.0
    )
    state = control_plane.compute_state(signals)
    assert state.condition == SystemCondition.GREEN
    assert control_plane.get_performance_factor() == 1.0

    # 2. YELLOW
    signals = SystemSignals(
        boot_state=BootState.READY,
        db_ready=True,
        migrations_ok=True,
        inference_ready=True,
        inference_latency_ms=600.0
    )
    for _ in range(20):
        state = control_plane.compute_state(signals)
    
    assert state.condition == SystemCondition.YELLOW
    assert control_plane.get_performance_factor() < 1.0

    # 3. RED (DB Down)
    signals = SystemSignals(
        boot_state=BootState.READY,
        db_ready=False,
        migrations_ok=True,
        inference_ready=True,
        inference_latency_ms=100.0
    )
    state = control_plane.compute_state(signals)
    assert state.condition == SystemCondition.RED
    assert control_plane.get_performance_factor() == 0.0

def test_arbitrator_logic(arbitrator):
    """Test the arbitration priority rules."""
    from core.governance.reasoning_budget import ReasoningBudget
    budget = ReasoningBudget(max_tool_calls=5, max_reasoning_depth=3, max_runtime_ms=30000)
    
    dsgk_allow = DSGKDecision(
        decision=DecisionType.ALLOW, 
        reason="ok", 
        risk_score=0.1, 
        policy="test", 
        violations=[], 
        budget=budget
    )
    dsgk_block = DSGKDecision(
        decision=DecisionType.BLOCK, 
        reason="policy", 
        risk_score=1.0, 
        policy="test", 
        violations=["test_v"], 
        budget=budget
    )
    
    # Priority vector required for CanonicalState
    pv = [0, 0, 0, 0, 0] # Example vector
    
    state_green = CanonicalState(condition=SystemCondition.GREEN, message="ok", signals=MagicMock(), priority_vector=pv)
    state_yellow = CanonicalState(condition=SystemCondition.YELLOW, message="slow", signals=MagicMock(), priority_vector=pv)
    state_red = CanonicalState(condition=SystemCondition.RED, message="fail", signals=MagicMock(), priority_vector=pv)

    # Rule 1: DSGK BLOCK > All
    outcome = arbitrator.arbitrate(dsgk_block, state_green)
    assert outcome.result == ArbitrationResult.BLOCK
    assert outcome.authority == "DSGK"

    # Rule 2: RED > All
    outcome = arbitrator.arbitrate(dsgk_allow, state_red)
    assert outcome.result == ArbitrationResult.BLOCK
    assert outcome.authority == "CONTROL_PLANE"

    # Rule 3: Circuit OPEN > All
    outcome = arbitrator.arbitrate(dsgk_allow, state_green, circuit_state=CircuitState.OPEN)
    assert outcome.result == ArbitrationResult.BLOCK
    assert outcome.authority == "CIRCUIT_BREAKER"

    # Rule 4: YELLOW -> THROTTLE
    outcome = arbitrator.arbitrate(dsgk_allow, state_yellow)
    assert outcome.result == ArbitrationResult.THROTTLE
    assert outcome.authority == "CONTROL_PLANE"

    # Rule 5: GREEN -> ALLOW
    outcome = arbitrator.arbitrate(dsgk_allow, state_green)
    assert outcome.result == ArbitrationResult.ALLOW
    assert outcome.authority == "KERNEL"

@patch("core.bootstrap.control_plane.control_plane")
def test_arbitration_performance_factor(mock_cp, arbitrator):
    """Test that performance factor is correctly passed through."""
    mock_cp.get_performance_factor.return_value = 0.5
    pv = [0, 0, 0, 0, 0]
    state_yellow = CanonicalState(condition=SystemCondition.YELLOW, message="slow", signals=MagicMock(), priority_vector=pv)
    
    from core.governance.reasoning_budget import ReasoningBudget
    budget = ReasoningBudget(max_tool_calls=5, max_reasoning_depth=3, max_runtime_ms=30000)
    dsgk_allow = DSGKDecision(decision=DecisionType.ALLOW, reason="ok", risk_score=0.1, policy="test", violations=[], budget=budget)
    
    outcome = arbitrator.arbitrate(dsgk_allow, state_yellow)
    
    assert outcome.result == ArbitrationResult.THROTTLE
    assert outcome.performance_factor == 0.5

def test_control_plane_hysteresis(control_plane):
    """Test that hysteresis prevents state flapping."""
    # 1. Start at GREEN
    signals = SystemSignals(
        boot_state=BootState.READY, db_ready=True, migrations_ok=True, 
        inference_ready=True, inference_latency_ms=300.0
    )
    control_plane.compute_state(signals)
    assert control_plane.get_status().condition == SystemCondition.GREEN
    
    # 2. Go to 450ms (Below enter threshold)
    signals = SystemSignals(
        boot_state=BootState.READY, db_ready=True, migrations_ok=True, 
        inference_ready=True, inference_latency_ms=450.0
    )
    for _ in range(20): control_plane.compute_state(signals)
    assert control_plane.get_status().condition == SystemCondition.GREEN
    
    # 3. Go to 600ms (Enter YELLOW)
    signals = SystemSignals(
        boot_state=BootState.READY, db_ready=True, migrations_ok=True, 
        inference_ready=True, inference_latency_ms=600.0
    )
    for _ in range(20): control_plane.compute_state(signals)
    assert control_plane.get_status().condition == SystemCondition.YELLOW
    
    # 4. Drop to 400ms (Still in YELLOW due to hysteresis)
    signals = SystemSignals(
        boot_state=BootState.READY, db_ready=True, migrations_ok=True, 
        inference_ready=True, inference_latency_ms=400.0
    )
    for _ in range(20): control_plane.compute_state(signals)
    assert control_plane.get_status().condition == SystemCondition.YELLOW
    
    # 5. Drop to 300ms (Exit YELLOW)
    signals = SystemSignals(
        boot_state=BootState.READY, db_ready=True, migrations_ok=True, 
        inference_ready=True, inference_latency_ms=300.0
    )
    for _ in range(20): control_plane.compute_state(signals)
    assert control_plane.get_status().condition == SystemCondition.GREEN
