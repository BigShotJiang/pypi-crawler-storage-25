"""
API tests for Service Accounts endpoints.
"""

import pytest
from fastapi.testclient import TestClient
from unittest.mock import Mock, patch

from api.factory import create_app
from core.vault.service_accounts import (
    ServiceAccountCreateRequest,
    ServiceAccountUpdateRequest,
    ServiceAccountSecretSetRequest,
    Provider,
    AuthType,
    ServiceAccountStatus
)


class TestServiceAccountsAPI:
    """Test service accounts API endpoints."""
    
    @pytest.fixture
    def client(self):
        """Create test client with mocked dependencies."""
        # Create app with agents disabled
        app = create_app(start_agents=False)
        
        # Mock the service account manager to avoid real encryption
        with patch('api.routers.service_accounts.get_service_account_manager') as mock_manager:
            mock_manager_instance = Mock()
            mock_manager.return_value = mock_manager_instance
            self.mock_manager = mock_manager_instance
            
            with TestClient(app) as client:
                self.client = client
                yield client
    
    @pytest.fixture
    def admin_headers(self):
        """Headers for admin user."""
        return {
            "X-Tenant-ID": "test-tenant",
            "X-Session-ID": "test_session"  # Uses dev mock bypass
        }
    
    @pytest.fixture
    def operator_headers(self):
        """Headers for operator user (will be denied for some operations)."""
        # Note: The dev mock bypass only works with "test_session" which gives admin role
        # For testing RBAC, we need to mock the RBAC system
        return {
            "X-Tenant-ID": "test-tenant",
            "X-Session-ID": "operator_session"
        }
    
    def test_create_service_account_admin_success(self, client, admin_headers):
        """Test admin successfully creating a service account."""
        # Setup mock
        mock_account = Mock()
        mock_account.id = "test-id-123"
        mock_account.tenant_id = "test-tenant"
        mock_account.name = "test-account"
        mock_account.provider = Provider.GITLAB
        mock_account.auth_type = AuthType.BEARER
        mock_account.allowed_scopes = []
        mock_account.created_by = "admin"
        mock_account.created_at = "2024-01-01T00:00:00"
        mock_account.status = ServiceAccountStatus.ACTIVE
        
        self.mock_manager.create_account.return_value = mock_account
        
        # Create request
        request_data = {
            "name": "test-account",
            "provider": "gitlab",
            "auth_type": "bearer",
            "allowed_scopes": []
        }
        
        # Execute
        response = client.post(
            "/api/service-accounts",
            json=request_data,
            headers=admin_headers
        )
        
        # Verify
        assert response.status_code == 201
        data = response.json()
        assert data["id"] == "test-id-123"
        assert data["name"] == "test-account"
        assert data["provider"] == "gitlab"
        assert data["auth_type"] == "bearer"
        assert data["status"] == "active"
        
        # Verify manager was called
        self.mock_manager.create_account.assert_called_once()
    
    def test_create_service_account_validation_error(self, client, admin_headers):
        """Test validation error when creating account."""
        # Invalid request - missing required fields
        request_data = {
            "name": "",  # Empty name
            "provider": "invalid_provider",  # Invalid provider
        }
        
        response = client.post(
            "/api/service-accounts",
            json=request_data,
            headers=admin_headers
        )
        
        # Should return 400 Bad Request
        assert response.status_code == 400
    
    def test_list_service_accounts(self, client, admin_headers):
        """Test listing service accounts."""
        # Setup mock
        mock_account = Mock()
        mock_account.id = "test-id"
        mock_account.tenant_id = "test-tenant"
        mock_account.name = "test-account"
        mock_account.provider = Provider.GITLAB
        mock_account.auth_type = AuthType.BEARER
        mock_account.allowed_scopes = []
        mock_account.created_by = "admin"
        mock_account.created_at = "2024-01-01T00:00:00"
        mock_account.status = ServiceAccountStatus.ACTIVE
        
        self.mock_manager.list_accounts.return_value = [mock_account]
        
        # Execute
        response = client.get(
            "/api/service-accounts",
            headers=admin_headers
        )
        
        # Verify
        assert response.status_code == 200
        data = response.json()
        assert len(data) == 1
        assert data[0]["id"] == "test-id"
        assert data[0]["name"] == "test-account"
        
        # Verify manager was called
        self.mock_manager.list_accounts.assert_called_once()
    
    def test_list_service_accounts_with_provider_filter(self, client, admin_headers):
        """Test listing service accounts with provider filter."""
        # Setup mock
        mock_account = Mock()
        mock_account.id = "test-id"
        mock_account.tenant_id = "test-tenant"
        mock_account.name = "test-account"
        mock_account.provider = Provider.GITLAB
        mock_account.auth_type = AuthType.BEARER
        mock_account.allowed_scopes = []
        mock_account.created_by = "admin"
        mock_account.created_at = "2024-01-01T00:00:00"
        mock_account.status = ServiceAccountStatus.ACTIVE
        
        self.mock_manager.list_accounts.return_value = [mock_account]
        
        # Execute with provider filter
        response = client.get(
            "/api/service-accounts?provider=gitlab",
            headers=admin_headers
        )
        
        # Verify
        assert response.status_code == 200
        self.mock_manager.list_accounts.assert_called_once()
        # Check that provider filter was passed
        call_kwargs = self.mock_manager.list_accounts.call_args[1]
        assert call_kwargs.get("provider") == Provider.GITLAB
    
    def test_get_service_account(self, client, admin_headers):
        """Test getting a specific service account."""
        # Setup mock
        mock_account = Mock()
        mock_account.id = "test-id"
        mock_account.tenant_id = "test-tenant"
        mock_account.name = "test-account"
        mock_account.provider = Provider.GITLAB
        mock_account.auth_type = AuthType.BEARER
        mock_account.allowed_scopes = []
        mock_account.created_by = "admin"
        mock_account.created_at = "2024-01-01T00:00:00"
        mock_account.status = ServiceAccountStatus.ACTIVE
        
        self.mock_manager.get_account.return_value = mock_account
        
        # Execute
        response = client.get(
            "/api/service-accounts/test-id",
            headers=admin_headers
        )
        
        # Verify
        assert response.status_code == 200
        data = response.json()
        assert data["id"] == "test-id"
        assert data["name"] == "test-account"
        
        # Verify manager was called
        self.mock_manager.get_account.assert_called_once()
    
    def test_get_service_account_not_found(self, client, admin_headers):
        """Test getting non-existent service account."""
        # Setup mock to return None
        self.mock_manager.get_account.return_value = None
        
        # Execute
        response = client.get(
            "/api/service-accounts/non-existent-id",
            headers=admin_headers
        )
        
        # Verify
        assert response.status_code == 404
        assert "not found" in response.json()["detail"].lower()
    
    def test_update_service_account(self, client, admin_headers):
        """Test updating a service account."""
        # Setup mock
        mock_account = Mock()
        mock_account.id = "test-id"
        mock_account.tenant_id = "test-tenant"
        mock_account.name = "updated-name"
        mock_account.provider = Provider.GITLAB
        mock_account.auth_type = AuthType.BEARER
        mock_account.allowed_scopes = ["read", "write"]
        mock_account.created_by = "admin"
        mock_account.created_at = "2024-01-01T00:00:00"
        mock_account.status = ServiceAccountStatus.DISABLED
        
        self.mock_manager.update_account.return_value = mock_account
        
        # Update request
        request_data = {
            "name": "updated-name",
            "allowed_scopes": ["read", "write"],
            "status": "disabled"
        }
        
        # Execute
        response = client.put(
            "/api/service-accounts/test-id",
            json=request_data,
            headers=admin_headers
        )
        
        # Verify
        assert response.status_code == 200
        data = response.json()
        assert data["name"] == "updated-name"
        assert data["status"] == "disabled"
        assert data["allowed_scopes"] == ["read", "write"]
        
        # Verify manager was called
        self.mock_manager.update_account.assert_called_once()
    
    def test_delete_service_account(self, client, admin_headers):
        """Test deleting a service account."""
        # Setup mock
        self.mock_manager.delete_account.return_value = True
        
        # Execute
        response = client.delete(
            "/api/service-accounts/test-id",
            headers=admin_headers
        )
        
        # Verify
        assert response.status_code == 204  # No content
        
        # Verify manager was called
        self.mock_manager.delete_account.assert_called_once()
    
    def test_delete_service_account_not_found(self, client, admin_headers):
        """Test deleting non-existent service account."""
        # Setup mock to return False (not found)
        self.mock_manager.delete_account.return_value = False
        
        # Execute
        response = client.delete(
            "/api/service-accounts/non-existent-id",
            headers=admin_headers
        )
        
        # Verify
        assert response.status_code == 404
        assert "not found" in response.json()["detail"].lower()
    
    def test_set_service_account_secret(self, client, admin_headers):
        """Test setting secret for a service account."""
        # Setup mock
        self.mock_manager.set_secret.return_value = True
        
        # Secret request
        request_data = {
            "secret": "my-secret-token"
        }
        
        # Execute
        response = client.post(
            "/api/service-accounts/test-id/secret",
            json=request_data,
            headers=admin_headers
        )
        
        # Verify
        assert response.status_code == 204  # No content
        
        # Verify manager was called
        self.mock_manager.set_secret.assert_called_once()
    
    def test_set_service_account_secret_not_found(self, client, admin_headers):
        """Test setting secret for non-existent account."""
        # Setup mock to return False (not found)
        self.mock_manager.set_secret.return_value = False
        
        # Secret request
        request_data = {
            "secret": "my-secret-token"
        }
        
        # Execute
        response = client.post(
            "/api/service-accounts/non-existent-id/secret",
            json=request_data,
            headers=admin_headers
        )
        
        # Verify
        assert response.status_code == 404
        assert "not found" in response.json()["detail"].lower()
    
    def test_get_audit_events(self, client, admin_headers):
        """Test getting audit events for a service account."""
        # Setup mock
        from core.vault.service_accounts import AuditEvent, AuditEventType
        from datetime import datetime
        
        mock_event = AuditEvent(
            event_type=AuditEventType.SERVICE_ACCOUNT_CREATED,
            tenant_id="test-tenant",
            service_account_id="test-id",
            provider=Provider.GITLAB,
            actor="admin",
            timestamp=datetime.now()
        )
        
        self.mock_manager.get_audit_events.return_value = [mock_event]
        
        # Execute
        response = client.get(
            "/api/service-accounts/test-id/audit",
            headers=admin_headers
        )
        
        # Verify
        assert response.status_code == 200
        data = response.json()
        assert len(data) == 1
        assert data[0]["event_type"] == "SERVICE_ACCOUNT_CREATED"
        assert data[0]["actor"] == "admin"
        
        # Verify manager was called
        self.mock_manager.get_audit_events.assert_called_once()
    
    def test_rbac_permission_denied(self, client):
        """Test RBAC permission denied (mocked)."""
        # This test would require mocking the RBAC system to return permission error
        # For now, we'll test with invalid session
        headers = {
            "X-Tenant-ID": "test-tenant",
            "X-Session-ID": "invalid_session"  # Not "test_session"
        }
        
        # The dev mock bypass only works with "test_session"
        # Without it, the RBAC system will try to look up the session and fail
        # This should return 401 or 500 depending on RBAC implementation
        
        response = client.get(
            "/api/service-accounts",
            headers=headers
        )
        
        # Expect some error (401 or 500)
        assert response.status_code in [401, 403, 500]
    
    def test_tenant_isolation(self, client):
        """Test tenant isolation (mocked)."""
        # This would require more complex mocking of RBAC and storage
        # For now, we verify the tenant ID is passed to manager calls
        headers = {
            "X-Tenant-ID": "tenant-a",
            "X-Session-ID": "test_session"
        }
        
        mock_account = Mock()
        mock_account.id = "test-id"
        mock_account.tenant_id = "tenant-a"  # Same tenant
        mock_account.name = "test-account"
        mock_account.provider = Provider.GITLAB
        mock_account.auth_type = AuthType.BEARER
        mock_account.allowed_scopes = []
        mock_account.created_by = "admin"
        mock_account.created_at = "2024-01-01T00:00:00"
        mock_account.status = ServiceAccountStatus.ACTIVE
        
        self.mock_manager.get_account.return_value = mock_account
        
        response = client.get(
            "/api/service-accounts/test-id",
            headers=headers
        )
        
        # Verify tenant ID was passed
        call_kwargs = self.mock_manager.get_account.call_args[1]
        assert call_kwargs.get("tenant_id") == "tenant-a"