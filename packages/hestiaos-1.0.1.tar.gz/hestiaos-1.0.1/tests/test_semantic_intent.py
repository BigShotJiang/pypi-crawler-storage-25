"""
Tests für den SemanticIntentAnalyzer (C2.3 — RalphIntentProcessor → CronIntelligenceEngine).

Testet:
1. Heuristik-basierte Intent-Analyse (Fallback ohne LLM)
2. Style-Erkennung
3. Energie-Detektion
4. Tempo-Extraktion
5. Capability-Ableitung
6. Cache-Verhalten
7. Batch-Analyse
8. Edge Cases (leerer Input, unbekannte Styles)
9. Cron-Job-Registrierung
"""

import pytest
from typing import Dict, Any, Optional

from core.intelligence.semantic_intent import (
    SemanticIntentAnalyzer,
    SemanticIntent,
    register_intent_analysis_job,
    VALID_STYLES,
)
from core.scheduler.cron_intelligence import JobRegistry


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture
def analyzer() -> SemanticIntentAnalyzer:
    """Erstelle einen SemanticIntentAnalyzer ohne LLM-Bridge (reine Heuristik)."""
    return SemanticIntentAnalyzer()


# ---------------------------------------------------------------------------
# Tests: Heuristik-Analyse
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_analyze_vibe_start(analyzer: SemanticIntentAnalyzer):
    """Teste Erkennung von 'vibe.start' Intent."""
    intent = await analyzer.analyze("start a dark ambient vibe")
    assert intent.intent == "vibe.start"
    assert intent.style == "dark"
    assert 0.0 <= intent.energy <= 1.0
    assert intent.confidence == 0.6  # Heuristik
    assert "session.start" in intent.capabilities
    assert "audio.initialize" in intent.capabilities
    assert intent.raw_text == "start a dark ambient vibe"


@pytest.mark.asyncio
async def test_analyze_audio_generate(analyzer: SemanticIntentAnalyzer):
    """Teste Erkennung von 'audio.generate' Intent."""
    intent = await analyzer.analyze("generate some ambient sound")
    assert intent.intent == "audio.generate"
    assert "audio.generate" in intent.capabilities


@pytest.mark.asyncio
async def test_analyze_pattern_create(analyzer: SemanticIntentAnalyzer):
    """Teste Erkennung von 'pattern.create' Intent."""
    intent = await analyzer.analyze("create a rhythmic pattern")
    assert intent.intent == "pattern.create"
    assert "pattern.create" in intent.capabilities


@pytest.mark.asyncio
async def test_analyze_vibe_stop(analyzer: SemanticIntentAnalyzer):
    """Teste Erkennung von 'vibe.stop' Intent."""
    intent = await analyzer.analyze("stop the music")
    assert intent.intent == "vibe.stop"


@pytest.mark.asyncio
async def test_analyze_vibe_pause(analyzer: SemanticIntentAnalyzer):
    """Teste Erkennung von 'vibe.pause' Intent."""
    intent = await analyzer.analyze("pause the session")
    assert intent.intent == "vibe.pause"


@pytest.mark.asyncio
async def test_analyze_vibe_resume(analyzer: SemanticIntentAnalyzer):
    """Teste Erkennung von 'vibe.resume' Intent."""
    intent = await analyzer.analyze("resume the vibe")
    assert intent.intent == "vibe.resume"


# ---------------------------------------------------------------------------
# Tests: Style-Erkennung
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_style_techno(analyzer: SemanticIntentAnalyzer):
    """Teste Erkennung von 'techno' Style."""
    intent = await analyzer.analyze("play a techno beat at 120 bpm")
    assert intent.style == "techno"


@pytest.mark.asyncio
async def test_style_glitch(analyzer: SemanticIntentAnalyzer):
    """Teste Erkennung von 'glitch' Style."""
    intent = await analyzer.analyze("create glitch effects")
    assert intent.style == "glitch"


@pytest.mark.asyncio
async def test_style_dark(analyzer: SemanticIntentAnalyzer):
    """Teste Erkennung von 'dark' Style."""
    intent = await analyzer.analyze("düstere atmosphäre")
    assert intent.style == "dark"


@pytest.mark.asyncio
async def test_style_bright(analyzer: SemanticIntentAnalyzer):
    """Teste Erkennung von 'bright' Style."""
    intent = await analyzer.analyze("bright and happy melody")
    assert intent.style == "bright"


@pytest.mark.asyncio
async def test_style_chill(analyzer: SemanticIntentAnalyzer):
    """Teste Erkennung von 'chill' Style."""
    intent = await analyzer.analyze("entspannte chill musik")
    assert intent.style == "chill"


@pytest.mark.asyncio
async def test_style_energetic(analyzer: SemanticIntentAnalyzer):
    """Teste Erkennung von 'energetic' Style."""
    intent = await analyzer.analyze("energische intensive musik")
    assert intent.style == "energetic"


@pytest.mark.asyncio
async def test_style_experimental(analyzer: SemanticIntentAnalyzer):
    """Teste Erkennung von 'experimental' Style."""
    intent = await analyzer.analyze("experimentelle avantgarde klänge")
    assert intent.style == "experimental"


@pytest.mark.asyncio
async def test_style_default_ambient(analyzer: SemanticIntentAnalyzer):
    """Teste Fallback auf 'ambient' bei unbekanntem Style."""
    intent = await analyzer.analyze("play something")
    assert intent.style == "ambient"


# ---------------------------------------------------------------------------
# Tests: Energie-Detektion
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_energy_low(analyzer: SemanticIntentAnalyzer):
    """Teste niedrige Energie bei 'slow/calm'."""
    intent = await analyzer.analyze("slow and calm music")
    assert intent.energy == 0.2


@pytest.mark.asyncio
async def test_energy_high(analyzer: SemanticIntentAnalyzer):
    """Teste hohe Energie bei 'fast/energisch'."""
    intent = await analyzer.analyze("schnelle energische musik")
    assert intent.energy == 0.8


@pytest.mark.asyncio
async def test_energy_medium(analyzer: SemanticIntentAnalyzer):
    """Teste mittlere Energie bei 'medium/normal'."""
    intent = await analyzer.analyze("normale geschwindigkeit")
    assert intent.energy == 0.5


@pytest.mark.asyncio
async def test_energy_max(analyzer: SemanticIntentAnalyzer):
    """Teste maximale Energie bei 'very/max'."""
    intent = await analyzer.analyze("sehr intensive musik")
    assert intent.energy == 0.9


# ---------------------------------------------------------------------------
# Tests: Tempo-Extraktion
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_tempo_extraction(analyzer: SemanticIntentAnalyzer):
    """Teste Extraktion von BPM aus dem Text."""
    intent = await analyzer.analyze("120 bpm techno beat")
    assert intent.parameters["tempo"] == 120


@pytest.mark.asyncio
async def test_tempo_with_keyword(analyzer: SemanticIntentAnalyzer):
    """Teste Extraktion mit Zahl vor 'bpm' Keyword."""
    intent = await analyzer.analyze("140 bpm techno beat")
    assert intent.parameters["tempo"] == 140


@pytest.mark.asyncio
async def test_tempo_missing(analyzer: SemanticIntentAnalyzer):
    """Teste fehlendes Tempo."""
    intent = await analyzer.analyze("play ambient music")
    assert intent.parameters["tempo"] is None


# ---------------------------------------------------------------------------
# Tests: Capability-Ableitung
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_capabilities_vibe_start(analyzer: SemanticIntentAnalyzer):
    """Teste Capabilities für vibe.start."""
    intent = await analyzer.analyze("start a vibe")
    assert "session.start" in intent.capabilities
    assert "audio.initialize" in intent.capabilities


@pytest.mark.asyncio
async def test_capabilities_audio(analyzer: SemanticIntentAnalyzer):
    """Teste Capabilities für audio.generate."""
    intent = await analyzer.analyze("generate audio")
    assert "audio.generate" in intent.capabilities


@pytest.mark.asyncio
async def test_capabilities_pattern(analyzer: SemanticIntentAnalyzer):
    """Teste Capabilities für pattern.create."""
    intent = await analyzer.analyze("create pattern")
    assert "pattern.create" in intent.capabilities


# ---------------------------------------------------------------------------
# Tests: Cache
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_cache_hit(analyzer: SemanticIntentAnalyzer):
    """Teste, dass der Cache bei identischem Input greift."""
    text = "start a dark ambient vibe"
    intent1 = await analyzer.analyze(text)
    intent2 = await analyzer.analyze(text)
    assert intent1.to_dict() == intent2.to_dict()
    assert len(analyzer._cache) == 1


@pytest.mark.asyncio
async def test_cache_miss_different_text(analyzer: SemanticIntentAnalyzer):
    """Teste, dass unterschiedlicher Text unterschiedliche Cache-Einträge erzeugt."""
    await analyzer.analyze("start a dark ambient vibe")
    await analyzer.analyze("play techno music")
    assert len(analyzer._cache) == 2


@pytest.mark.asyncio
async def test_clear_cache(analyzer: SemanticIntentAnalyzer):
    """Teste, dass clear_cache() funktioniert."""
    await analyzer.analyze("start a vibe")
    assert len(analyzer._cache) == 1
    analyzer.clear_cache()
    assert len(analyzer._cache) == 0


# ---------------------------------------------------------------------------
# Tests: Batch-Analyse
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_analyze_batch(analyzer: SemanticIntentAnalyzer):
    """Teste Batch-Analyse mehrerer Texte."""
    texts = [
        "start a dark ambient vibe",
        "play techno music",
        "stop the session",
    ]
    results = await analyzer.analyze_batch(texts)
    assert len(results) == 3
    assert results[0].style == "dark"
    assert results[1].style == "techno"
    assert results[2].intent == "vibe.stop"


# ---------------------------------------------------------------------------
# Tests: Edge Cases
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_empty_input(analyzer: SemanticIntentAnalyzer):
    """Teste leeren Input."""
    intent = await analyzer.analyze("")
    assert intent.intent == "unknown"
    assert intent.confidence == 0.0


@pytest.mark.asyncio
async def test_whitespace_input(analyzer: SemanticIntentAnalyzer):
    """Teste Whitespace-Input."""
    intent = await analyzer.analyze("   ")
    assert intent.intent == "unknown"
    assert intent.confidence == 0.0


@pytest.mark.asyncio
async def test_none_input(analyzer: SemanticIntentAnalyzer):
    """Teste None-Input (wird als leerer String behandelt)."""
    intent = await analyzer.analyze(None)  # type: ignore
    assert intent.intent == "unknown"


@pytest.mark.asyncio
async def test_german_keywords(analyzer: SemanticIntentAnalyzer):
    """Teste deutsche Keywords."""
    intent = await analyzer.analyze("stopp die musik")
    assert intent.intent == "vibe.stop"


@pytest.mark.asyncio
async def test_unknown_style_normalization(analyzer: SemanticIntentAnalyzer):
    """Teste Normalisierung unbekannter Styles."""
    # Direkter Test der statischen Methode
    normalized = SemanticIntentAnalyzer._normalize_style("unknown_style_xyz")
    assert normalized == "ambient"


@pytest.mark.asyncio
async def test_energy_clamping(analyzer: SemanticIntentAnalyzer):
    """Teste Clamping von Energie-Werten."""
    assert SemanticIntentAnalyzer._clamp_energy(1.5) == 1.0
    assert SemanticIntentAnalyzer._clamp_energy(-0.5) == 0.0
    assert SemanticIntentAnalyzer._clamp_energy("invalid") == 0.5


@pytest.mark.asyncio
async def test_confidence_clamping(analyzer: SemanticIntentAnalyzer):
    """Teste Clamping von Confidence-Werten."""
    assert SemanticIntentAnalyzer._clamp_confidence(1.5) == 1.0
    assert SemanticIntentAnalyzer._clamp_confidence(-0.5) == 0.0


# ---------------------------------------------------------------------------
# Tests: SemanticIntent Dataclass
# ---------------------------------------------------------------------------


def test_semantic_intent_to_dict():
    """Teste Serialisierung von SemanticIntent."""
    intent = SemanticIntent(
        intent="vibe.start",
        style="ambient",
        energy=0.5,
        raw_text="test",
    )
    d = intent.to_dict()
    assert d["intent"] == "vibe.start"
    assert d["style"] == "ambient"
    assert d["energy"] == 0.5
    assert d["raw_text"] == "test"
    assert "analyzed_at" in d


def test_semantic_intent_from_dict():
    """Teste Deserialisierung von SemanticIntent."""
    data = {
        "intent": "audio.generate",
        "style": "techno",
        "energy": 0.8,
        "confidence": 0.9,
        "parameters": {"tempo": 120},
        "capabilities": ["audio.generate"],
        "raw_text": "play techno",
    }
    intent = SemanticIntent.from_dict(data)
    assert intent.intent == "audio.generate"
    assert intent.style == "techno"
    assert intent.energy == 0.8
    assert intent.parameters["tempo"] == 120


# ---------------------------------------------------------------------------
# Tests: Cron-Job-Registrierung
# ---------------------------------------------------------------------------


def test_register_intent_analysis_job():
    """Teste Registrierung des Cron-Jobs."""
    registry = JobRegistry()
    register_intent_analysis_job(registry)
    job = registry.get("intelligence_semantic_intent_analysis")
    assert job is not None
    assert job.name == "intelligence_semantic_intent_analysis"
    assert job.cron_expr == "*/30 * * * *"
    assert job.enabled is True
    assert job.metadata["engine"] == "semantic_intent"
    assert job.metadata["version"] == "2.0"


def test_register_intent_analysis_job_twice():
    """Teste, dass doppelte Registrierung überschreibt."""
    registry = JobRegistry()
    register_intent_analysis_job(registry)
    register_intent_analysis_job(registry)
    assert len(registry) == 1


# ---------------------------------------------------------------------------
# Tests: VALID_STYLES
# ---------------------------------------------------------------------------


def test_valid_styles_contains_expected():
    """Teste, dass VALID_STYLES die erwarteten Styles enthält."""
    assert "ambient" in VALID_STYLES
    assert "techno" in VALID_STYLES
    assert "glitch" in VALID_STYLES
    assert "dark" in VALID_STYLES
    assert "bright" in VALID_STYLES
    assert "chill" in VALID_STYLES
    assert "energetic" in VALID_STYLES
    assert "experimental" in VALID_STYLES
    assert len(VALID_STYLES) == 10  # inkl. traditional, custom
