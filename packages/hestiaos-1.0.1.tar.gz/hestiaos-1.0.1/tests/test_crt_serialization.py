"""
Tests: Canonical Runtime Truth (CRT) Serialization Contract
============================================================
Prüft die Serialisierung von ExecutionEnvelope und ExecutionDependency
gemäss ADR-002 / CI-CRT-001.

Testet:
- asdict() + JSON roundtrip für ExecutionEnvelope
- asdict() + JSON roundtrip für ExecutionDependency
- schema_version wird korrekt gesetzt
- Keine verbotenen Felder (CI-CRT-001)
"""

import json
import uuid
from dataclasses import asdict
from datetime import datetime, timezone

import pytest

from core.observability.execution_envelope import ExecutionEnvelope
from core.observability.execution_dependency import ExecutionDependency
from core.events.event_schema import TraceState


# ---------------------------------------------------------------------------
# CI-CRT-001: Verbotene Feldnamen
# ---------------------------------------------------------------------------

FORBIDDEN_FIELD_NAMES = {
    "causal_strength",
    "confidence",
    "is_inferred",
    "deviation_class",
    "causal_direction",
    "causal_classification",
    "causal_confidence",
    "causal_relation_type",
    "inferred_causality",
    "semantic_profile",
    "recovery_spec",
    "projection_function",
}


def _check_no_forbidden_fields(obj, path: str = ""):
    """Rekursive Prüfung auf verbotene Feldnamen (CI-CRT-001)."""
    if isinstance(obj, dict):
        for key, value in obj.items():
            full_path = f"{path}.{key}" if path else key
            if key in FORBIDDEN_FIELD_NAMES:
                pytest.fail(
                    f"CI-CRT-001 Verletzung: Verbotenes Feld '{full_path}' "
                    f"gefunden in {type(obj).__name__}"
                )
            _check_no_forbidden_fields(value, full_path)
    elif isinstance(obj, (list, tuple)):
        for i, item in enumerate(obj):
            _check_no_forbidden_fields(item, f"{path}[{i}]")


# ---------------------------------------------------------------------------
# ExecutionEnvelope Serialisierung
# ---------------------------------------------------------------------------


class TestExecutionEnvelopeSerialization:
    """Testet die Serialisierung von ExecutionEnvelope."""

    def test_envelope_asdict_roundtrip(self):
        """ExecutionEnvelope → asdict() → JSON → dict → ExecutionEnvelope."""
        envelope = ExecutionEnvelope(
            execution_id=uuid.uuid4(),
            task_id="test_task_001",
            epoch=1,
            state=TraceState.ACTIVE,
            schema_version="1.0.0",
            timestamp_start=1000.0,
            timestamp_end=2000.0,
            final_decision="EXECUTE",
            final_mode="EXPLORE",
            metadata={"source": "test", "version": "1"},
        )

        # asdict()
        data = asdict(envelope)
        assert isinstance(data, dict)
        assert data["schema_version"] == "1.0.0"
        assert data["task_id"] == "test_task_001"
        assert data["epoch"] == 1
        assert data["state"] == TraceState.ACTIVE

        # CI-CRT-001: Keine verbotenen Felder
        _check_no_forbidden_fields(data)

        # JSON roundtrip
        json_str = json.dumps(data, default=str)
        restored_data = json.loads(json_str)

        assert restored_data["schema_version"] == "1.0.0"
        assert restored_data["task_id"] == "test_task_001"
        assert restored_data["epoch"] == 1
        assert restored_data["state"] == "TraceState.ACTIVE"

    def test_envelope_default_schema_version(self):
        """schema_version hat Default-Wert '1.0.0'."""
        envelope = ExecutionEnvelope(
            execution_id=uuid.uuid4(),
            task_id="test",
            epoch=0,
        )
        assert envelope.schema_version == "1.0.0"

    def test_envelope_minimal_serialization(self):
        """Minimaler ExecutionEnvelope serialisierbar."""
        envelope = ExecutionEnvelope(
            execution_id=uuid.uuid4(),
            task_id="minimal",
            epoch=0,
        )
        data = asdict(envelope)
        json_str = json.dumps(data, default=str)
        restored = json.loads(json_str)

        assert restored["task_id"] == "minimal"
        assert restored["schema_version"] == "1.0.0"
        assert restored["state"] == "TraceState.INIT"

    def test_envelope_uuid_serialization(self):
        """UUID wird korrekt serialisiert/deserialisiert."""
        original_id = uuid.uuid4()
        envelope = ExecutionEnvelope(
            execution_id=original_id,
            task_id="uuid_test",
            epoch=0,
        )
        data = asdict(envelope)
        json_str = json.dumps(data, default=str)
        restored = json.loads(json_str)

        # UUID wird als String gespeichert
        assert restored["execution_id"] == str(original_id)

    def test_envelope_metadata_serialization(self):
        """Metadata-Dict wird korrekt serialisiert."""
        envelope = ExecutionEnvelope(
            execution_id=uuid.uuid4(),
            task_id="meta_test",
            epoch=0,
            metadata={
                "key1": "value1",
                "key2": 42,
                "key3": {"nested": True},
            },
        )
        data = asdict(envelope)
        json_str = json.dumps(data, default=str)
        restored = json.loads(json_str)

        assert restored["metadata"]["key1"] == "value1"
        assert restored["metadata"]["key2"] == 42
        assert restored["metadata"]["key3"]["nested"] is True

    def test_envelope_ci_crt_001_compliance(self):
        """ExecutionEnvelope enthält keine verbotenen Felder (CI-CRT-001)."""
        envelope = ExecutionEnvelope(
            execution_id=uuid.uuid4(),
            task_id="ci_crt_test",
            epoch=0,
        )
        data = asdict(envelope)
        _check_no_forbidden_fields(data)


# ---------------------------------------------------------------------------
# ExecutionDependency Serialisierung
# ---------------------------------------------------------------------------


class TestExecutionDependencySerialization:
    """Testet die Serialisierung von ExecutionDependency."""

    def test_dependency_asdict_roundtrip(self):
        """ExecutionDependency → asdict() → JSON → dict."""
        dep = ExecutionDependency(
            source_id=uuid.uuid4(),
            target_id=uuid.uuid4(),
            dependency_type="sequence",
            timestamp=1000.0,
            metadata={"reason": "test"},
        )

        data = asdict(dep)
        assert isinstance(data, dict)
        assert data["dependency_type"] == "sequence"
        assert data["timestamp"] == 1000.0

        # CI-CRT-001: Keine verbotenen Felder
        _check_no_forbidden_fields(data)

        # JSON roundtrip
        json_str = json.dumps(data, default=str)
        restored = json.loads(json_str)

        assert restored["dependency_type"] == "sequence"
        assert restored["timestamp"] == 1000.0

    def test_dependency_minimal_serialization(self):
        """Minimaler ExecutionDependency serialisierbar."""
        dep = ExecutionDependency(
            source_id=uuid.uuid4(),
            target_id=uuid.uuid4(),
            dependency_type="sequence",
        )
        data = asdict(dep)
        json_str = json.dumps(data, default=str)
        restored = json.loads(json_str)

        assert restored["dependency_type"] == "sequence"
        assert restored["timestamp"] == 0.0

    def test_dependency_uuid_serialization(self):
        """UUIDs werden korrekt serialisiert."""
        src_id = uuid.uuid4()
        tgt_id = uuid.uuid4()
        dep = ExecutionDependency(
            source_id=src_id,
            target_id=tgt_id,
            dependency_type="causal_trigger",
        )
        data = asdict(dep)
        json_str = json.dumps(data, default=str)
        restored = json.loads(json_str)

        assert restored["source_id"] == str(src_id)
        assert restored["target_id"] == str(tgt_id)

    def test_dependency_metadata_serialization(self):
        """Metadata wird korrekt serialisiert."""
        dep = ExecutionDependency(
            source_id=uuid.uuid4(),
            target_id=uuid.uuid4(),
            dependency_type="feedback_loop",
            metadata={"loop_count": 3, "source_layer": "POST"},
        )
        data = asdict(dep)
        json_str = json.dumps(data, default=str)
        restored = json.loads(json_str)

        assert restored["metadata"]["loop_count"] == 3
        assert restored["metadata"]["source_layer"] == "POST"

    def test_dependency_no_forbidden_fields(self):
        """ExecutionDependency enthält keine verbotenen Felder (CI-CRT-001)."""
        dep = ExecutionDependency(
            source_id=uuid.uuid4(),
            target_id=uuid.uuid4(),
            dependency_type="sequence",
        )
        data = asdict(dep)
        _check_no_forbidden_fields(data)

    def test_dependency_no_causal_fields(self):
        """ExecutionDependency hat KEINE CausalRelation-Felder."""
        dep = ExecutionDependency(
            source_id=uuid.uuid4(),
            target_id=uuid.uuid4(),
            dependency_type="sequence",
        )
        # Diese Felder DÜRFEN NICHT existieren
        assert not hasattr(dep, 'causal_strength')
        assert not hasattr(dep, 'confidence')
        assert not hasattr(dep, 'is_inferred')
        assert not hasattr(dep, 'deviation_class')
        assert not hasattr(dep, 'causal_direction')
        assert not hasattr(dep, 'causal_classification')
        assert not hasattr(dep, 'causal_confidence')

    def test_dependency_has_required_fields(self):
        """ExecutionDependency hat alle erforderlichen CRT-Felder."""
        dep = ExecutionDependency(
            source_id=uuid.uuid4(),
            target_id=uuid.uuid4(),
            dependency_type="sequence",
        )
        # Diese Felder MÜSSEN existieren
        assert hasattr(dep, 'source_id')
        assert hasattr(dep, 'target_id')
        assert hasattr(dep, 'dependency_type')
        assert hasattr(dep, 'timestamp')
        assert hasattr(dep, 'metadata')


# ---------------------------------------------------------------------------
# CI-CRT-001: Gesamtprüfung
# ---------------------------------------------------------------------------


class TestCI_CRT_001:
    """Gesamtprüfung der Constitutional Invariant CI-CRT-001."""

    def test_all_core_fields_compliant(self):
        """Alle Kern-Dataclasses sind CI-CRT-001-konform."""
        # ExecutionEnvelope
        env = ExecutionEnvelope(
            execution_id=uuid.uuid4(),
            task_id="test",
            epoch=0,
        )
        _check_no_forbidden_fields(asdict(env))

        # ExecutionDependency
        dep = ExecutionDependency(
            source_id=uuid.uuid4(),
            target_id=uuid.uuid4(),
            dependency_type="sequence",
        )
        _check_no_forbidden_fields(asdict(dep))

    def test_forbidden_field_names_not_in_core(self):
        """Keiner der verbotenen Feldnamen existiert in CRT-Dataclasses."""
        env_fields = set(ExecutionEnvelope.__dataclass_fields__.keys())
        dep_fields = set(ExecutionDependency.__dataclass_fields__.keys())

        for forbidden in FORBIDDEN_FIELD_NAMES:
            assert forbidden not in env_fields, (
                f"CI-CRT-001: Verbotenes Feld '{forbidden}' in ExecutionEnvelope"
            )
            assert forbidden not in dep_fields, (
                f"CI-CRT-001: Verbotenes Feld '{forbidden}' in ExecutionDependency"
            )
