#!/usr/bin/env python3
"""
Real HestiaOS Tool Orchestration Test

This test validates tool orchestration with actual HestiaOS repository code,
testing the complete workflow with HSP governance on real Python files.
"""

import asyncio
import sys
import os
from datetime import datetime
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from core.capabilities.tool_orchestration import (
    ToolOrchestratorCapability,
    ToolConfiguration,
    ToolExecutionMode
)
from core.hsp.policies.tool_orchestration_policy import ToolOrchestrationPolicy
from core.hsp.schemas import HSPRequestSchema
from core.hsp.tracing import HSPTraceSystem


class RealHestiaOSToolOrchestrationTest:
    """Test tool orchestration with real HestiaOS codebase"""
    
    def __init__(self):
        self.trace_system = HSPTraceSystem()
        self.orchestrator = ToolOrchestratorCapability(trace_system=self.trace_system)
        self.policy = ToolOrchestrationPolicy()
        
        # Get actual HestiaOS Python files
        self.hestiaos_root = os.path.dirname(os.path.abspath(__file__))
        self.python_files = self._find_python_files()
    
    def _find_python_files(self):
        """Find Python files in the HestiaOS codebase"""
        python_files = []
        
        # Directories to analyze
        target_dirs = [
            os.path.join(self.hestiaos_root, "core"),
            os.path.join(self.hestiaos_root, "plugins"),
            os.path.join(self.hestiaos_root, "tests")
        ]
        
        for target_dir in target_dirs:
            if os.path.exists(target_dir):
                for root, dirs, files in os.walk(target_dir):
                    for file in files:
                        if file.endswith(".py"):
                            full_path = os.path.join(root, file)
                            # Skip test files for this test
                            if "test_" in file or "_test.py" in file:
                                continue
                            python_files.append(full_path)
        
        # Limit to 5 files for testing
        return python_files[:5]
    
    async def test_discovery_and_availability(self):
        """Test tool discovery and availability checking"""
        print("\n=== Testing Tool Discovery ===")
        
        context = {
            "language": "python",
            "repository_type": "private",
            "data_sensitivity": "medium"
        }
        
        available_tools = await self.orchestrator.discover_available_tools(context)
        
        print(f"Available tools: {[t.tool_id for t in available_tools]}")
        
        for tool in available_tools:
            print(f"  - {tool.tool_id}: {tool.name}")
            print(f"    Mode: {tool.execution_mode.value}")
            print(f"    Languages: {tool.supported_languages}")
        
        return available_tools
    
    async def test_policy_evaluation(self, tool_configs):
        """Test HSP policy evaluation for tool selection"""
        print("\n=== Testing HSP Policy Evaluation ===")
        
        # Create HSP request for internal repository
        internal_request = HSPRequestSchema(
            request_id="hestiaos-test-1",
            trace_id=self.trace_system.start_trace(
                "hestiaos-test-1",
                "tool_orchestration_policy_evaluation",
                {"test_type": "internal_repository"}
            ),
            timestamp=datetime.now().isoformat(),
            context={
                "repository_type": "private",
                "data_sensitivity": "medium",
                "compliance_requirements": [],
                "language": "python",
                "file_count": len(self.python_files)
            },
            source="hestiaos_test",
            metadata={}
        )
        
        # Convert tool configs for policy
        tool_config_dicts = [{"tool_id": t.tool_id, "name": t.name} for t in tool_configs]
        
        # Evaluate policy
        constraints = await self.policy.evaluate(internal_request, tool_config_dicts)
        
        print(f"Security Level: {constraints.metadata.get('security_level')}")
        print(f"Allowed Tools: {constraints.tools.allowed_tools}")
        print(f"Denied Tools: {constraints.tools.denied_tools}")
        print(f"Max Tool Calls: {constraints.tools.max_tool_calls}")
        print(f"Timeout: {constraints.tools.tool_timeout_seconds}s")
        print(f"Is Valid: {constraints.is_valid}")
        
        # Filter tools based on policy
        allowed_tools = [t for t in tool_configs if t.tool_id in constraints.tools.allowed_tools]
        
        print(f"\nTools allowed by policy: {[t.tool_id for t in allowed_tools]}")
        
        return allowed_tools, constraints
    
    async def test_file_analysis(self, tool_configs):
        """Test tool execution on actual HestiaOS files"""
        print("\n=== Testing File Analysis ===")
        print(f"Analyzing {len(self.python_files)} Python files from HestiaOS")
        
        all_results = {}
        
        for i, file_path in enumerate(self.python_files):
            print(f"\n--- File {i+1}: {os.path.basename(file_path)} ---")
            print(f"Path: {file_path}")
            
            # Create trace for this file analysis
            trace_id = self.trace_system.start_trace(
                f"file-analysis-{i}",
                "file_analysis",
                {
                    "file_path": file_path,
                    "file_name": os.path.basename(file_path),
                    "tool_count": len(tool_configs)
                }
            )
            
            try:
                # Execute tools on this file
                results = await self.orchestrator.execute_tools(
                    tool_configs=tool_configs,
                    target_path=file_path,
                    context={"language": "python", "file_type": "source"},
                    trace_id=trace_id
                )
                
                # Aggregate results
                aggregated = await self.orchestrator.aggregate_results(results, {})
                
                all_results[file_path] = {
                    "results": results,
                    "aggregated": aggregated
                }
                
                # Print summary
                successful = sum(1 for r in results.values() 
                               if r.status.value == "completed")
                print(f"  Tools executed: {len(results)}, Successful: {successful}")
                
                if aggregated.get("issues"):
                    print(f"  Issues found: {len(aggregated['issues'])}")
                
            except Exception as e:
                print(f"  Error analyzing file: {e}")
                all_results[file_path] = {"error": str(e)}
        
        return all_results
    
    async def test_cross_file_analysis(self, tool_configs):
        """Test analyzing multiple files together (directory-level analysis)"""
        print("\n=== Testing Cross-File Analysis ===")
        
        # Use core directory as target
        core_dir = os.path.join(self.hestiaos_root, "core")
        if not os.path.exists(core_dir):
            print(f"Core directory not found: {core_dir}")
            return None
        
        trace_id = self.trace_system.start_trace(
            "cross-file-analysis",
            "directory_analysis",
            {
                "directory": core_dir,
                "tool_count": len(tool_configs),
                "analysis_type": "directory"
            }
        )
        
        print(f"Analyzing directory: {core_dir}")
        
        try:
            # Execute tools on directory
            results = await self.orchestrator.execute_tools(
                tool_configs=tool_configs,
                target_path=core_dir,
                context={"language": "python", "analysis_scope": "directory"},
                trace_id=trace_id
            )
            
            # Aggregate results
            aggregated = await self.orchestrator.aggregate_results(results, {
                "analysis_scope": "directory",
                "file_count": len(self.python_files)
            })
            
            print(f"\nDirectory Analysis Results:")
            print(f"  Tools executed: {len(results)}")
            print(f"  Successful tools: {aggregated['summary']['successful_tools']}")
            print(f"  Total execution time: {aggregated['summary']['total_execution_time_ms']}ms")
            
            if aggregated.get("risk_assessment"):
                risk = aggregated["risk_assessment"]
                print(f"  Risk level: {risk.get('risk_level', 'UNKNOWN')}")
                print(f"  Risk score: {risk.get('risk_score', 0):.2f}")
            
            return aggregated
            
        except Exception as e:
            print(f"Error in cross-file analysis: {e}")
            return None
    
    async def run_comprehensive_test(self):
        """Run comprehensive test suite"""
        print("=" * 60)
        print("Real HestiaOS Tool Orchestration Test")
        print("=" * 60)
        
        print(f"\nHestiaOS Root: {self.hestiaos_root}")
        print(f"Python files found: {len(self.python_files)}")
        
        # Test 1: Tool discovery
        available_tools = await self.test_discovery_and_availability()
        
        if not available_tools:
            print("No tools available for testing!")
            return False
        
        # Test 2: Policy evaluation
        allowed_tools, constraints = await self.test_policy_evaluation(available_tools)
        
        if not allowed_tools:
            print("No tools allowed by policy!")
            return False
        
        # Test 3: Individual file analysis
        file_results = await self.test_file_analysis(allowed_tools)
        
        # Test 4: Cross-file analysis
        directory_results = await self.test_cross_file_analysis(allowed_tools)
        
        # Generate summary
        print("\n" + "=" * 60)
        print("TEST SUMMARY")
        print("=" * 60)
        
        total_files = len(file_results)
        successful_files = sum(1 for r in file_results.values() if "error" not in r)
        
        print(f"Files analyzed: {total_files}")
        print(f"Successful analyses: {successful_files}")
        print(f"Tool orchestration: {'PASS' if successful_files > 0 else 'FAIL'}")
        print(f"HSP policy enforcement: {'PASS' if constraints.is_valid else 'FAIL'}")
        
        # Check if any issues were found
        total_issues = 0
        for file_path, result in file_results.items():
            if "aggregated" in result:
                issues = result["aggregated"].get("issues", [])
                total_issues += len(issues)
        
        print(f"Total issues detected: {total_issues}")
        
        if directory_results:
            print(f"Directory analysis: COMPLETED")
            if directory_results.get("risk_assessment"):
                risk = directory_results["risk_assessment"]
                print(f"  Overall risk: {risk.get('risk_level', 'UNKNOWN')}")
        
        return successful_files > 0


async def main():
    """Main test execution"""
    test = RealHestiaOSToolOrchestrationTest()
    
    try:
        success = await test.run_comprehensive_test()
        
        print("\n" + "=" * 60)
        if success:
            print("SUCCESS: Real HestiaOS tool orchestration test passed!")
            print("The system successfully:")
            print("  1. Discovered available analysis tools")
            print("  2. Applied HSP governance policies")
            print("  3. Executed tools on real HestiaOS code")
            print("  4. Aggregated and correlated results")
            print("  5. Generated risk assessments")
        else:
            print("FAILURE: Test did not complete successfully")
        
        print("=" * 60)
        
    except Exception as e:
        print(f"\nERROR: Test failed with exception: {e}")
        import traceback
        traceback.print_exc()
        return False
    
    return success


if __name__ == "__main__":
    result = asyncio.run(main())
    sys.exit(0 if result else 1)