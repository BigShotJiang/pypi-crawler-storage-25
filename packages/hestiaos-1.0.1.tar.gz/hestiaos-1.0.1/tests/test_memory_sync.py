"""
tests/test_memory_sync.py
Fixed for Issue #31 — was failing because vault_path attribute injection
was not being recognised. Now uses a proper tmp_path fixture and avoids
any dependency on an actual CORE01 vault config.
"""
import pytest
import shutil
from pathlib import Path


@pytest.fixture
def isolated_memory(tmp_path):
    """Create an isolated CoreMemory backed by a temp SQLite DB."""
    from core.memory import CoreMemory
    db_path = tmp_path / "test_memory.db"
    mem = CoreMemory(db_path=str(db_path))
    mem.store_memory("User asked about testing", "user_input")
    mem.store_memory("Agent replied with test plan", "agent_output")
    return mem


@pytest.fixture
def context_manager_with_vault(isolated_memory, tmp_path):
    """ContextManager with injected isolated memory and vault path."""
    from core.context_manager import ContextManager
    cm = ContextManager()
    cm.memory = isolated_memory
    cm.vault_path = str(tmp_path)
    return cm, tmp_path


@pytest.mark.asyncio
async def test_memory_sync_to_vault(context_manager_with_vault):
    """sync_memory_to_vault writes a markdown file for the session."""
    cm, vault_root = context_manager_with_vault
    session_id = "test_session_123"

    await cm.sync_memory_to_vault(session_id)

    session_file = vault_root / "conversations" / f"{session_id}.md"
    assert session_file.exists(), f"Expected file at {session_file}"

    content = session_file.read_text(encoding="utf-8")
    assert f"# Session {session_id}" in content


@pytest.mark.asyncio
async def test_memory_sync_empty_session(context_manager_with_vault):
    """sync_memory_to_vault exits gracefully when there are no memories for the session."""
    cm, vault_root = context_manager_with_vault
    # Use a session ID that has no stored memories
    session_id = "empty_session_xyz"

    # Should not raise
    await cm.sync_memory_to_vault(session_id)

    # File may or may not be created — no assertion on existence
    session_file = vault_root / "conversations" / f"{session_id}.md"
    # If created, it should at least have the header
    if session_file.exists():
        content = session_file.read_text(encoding="utf-8")
        assert f"# Session {session_id}" in content
