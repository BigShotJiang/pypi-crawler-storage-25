import pytest
import yaml
from pathlib import Path
from core.model_authority import ModelAuthority
from core.artifact import ArtifactManager, ArtifactType, ArtifactStatus
from core.artifact.state_machine import TransitionError
from core.artifact.graph import GraphScope

@pytest.fixture
def authority(tmp_path):
    """ModelAuthority mit temporärer canon.yaml."""
    canon_dir = tmp_path / "core" / "invariants"
    canon_dir.mkdir(parents=True)
    canon_file = canon_dir / "canon.yaml"
    
    initial_config = {
        "model_authority": {
            "roles": {
                "primary": "valid-model",
                "mediator": "valid-model",
                "thinking": "valid-model",
                "expert": "valid-model"
            }
        }
    }
    with open(canon_file, "w") as f:
        yaml.dump(initial_config, f)
    
    # Pfad patchen
    ModelAuthority._config_path = canon_file
    # Singleton resetten
    ModelAuthority._instance = None
    return ModelAuthority()

@pytest.fixture
def art_manager():
    """ArtifactManager in-memory."""
    return ArtifactManager(":memory:")


# --- TEST 1: Policy Bypass (Invalid Model Injection) ---
def test_policy_bypass_rejection(authority):
    """Prüft, ob ungültige Proposals komplett abgelehnt werden."""
    invalid_proposal = {
        "primary": "gpt-4o-mini",          # valide Syntax, aber...
        "reasoning": "tiny-3b-model",      # VERBOTEN durch Policy
        "expert": "nonexistent-model"      # VERBOTEN (nicht verfügbar)
    }
    
    old_id = authority.envelope.snapshot_id
    
    new_envelope, result = authority.apply_proposal(invalid_proposal)
    
    # 1. Erwartung: allowed=False
    assert result.allowed is False
    # 2. Erwartung: Mehrere Gründe gemeldet
    assert len(result.reasons) >= 2 
    # 3. Erwartung: Snapshot ID darf sich NICHT geändert haben
    assert authority.envelope.snapshot_id == old_id


# --- TEST 2: Graph Inconsistency (Cycle Detection) ---
def test_graph_cycle_detection(art_manager):
    """Prüft, ob Zyklen im Abhängigkeitsgraph erkannt werden."""
    t1 = art_manager.create_artifact(ArtifactType.TASK, "Task A")
    t2 = art_manager.create_artifact(ArtifactType.TASK, "Task B")
    
    # Zyklus bauen: A -> B -> A
    art_manager.update_artifact_fields(t1.id, dependencies=[t2.id])
    art_manager.update_artifact_fields(t2.id, dependencies=[t1.id])
    
    health = art_manager.get_project_health(t1.id, scope=GraphScope.GLOBAL)
    
    assert health["has_cycles"] is True


# --- TEST 3: State Machine Boundary Abuse ---
def test_state_machine_abuse(art_manager):
    """Prüft, ob illegale Status-Übergänge hart scheitern."""
    art = art_manager.create_artifact(ArtifactType.IDEA, "Test Idee", status=ArtifactStatus.DRAFT)
    
    # Illegal: DRAFT -> ACTIVE (für IDEA nicht erlaubt laut Spec)
    with pytest.raises(TransitionError):
        art_manager.update_artifact_fields(art.id, status=ArtifactStatus.ACTIVE)
    
    # Illegal: ARCHIVED -> ACTIVE
    art_manager.update_artifact_fields(art.id, status=ArtifactStatus.ARCHIVED)
    with pytest.raises(TransitionError):
        art_manager.update_artifact_fields(art.id, status=ArtifactStatus.ACTIVE)


# --- TEST 4: Cross-Layer Drift (Precedence Test) ---
def test_cross_layer_precedence(art_manager):
    """
    Sicherstellen, dass der State-Layer gewinnt, 
    auch wenn der Service-Layer "versucht" etwas zu tun.
    """
    art = art_manager.create_artifact(ArtifactType.TASK, "Task", status=ArtifactStatus.DONE)
    
    # Versuch: Status ändern, aber State Machine sollte blockieren
    # Da wir in DONE sind, ist DRAFT nicht mehr erlaubt.
    try:
        art_manager.update_artifact_fields(art.id, status=ArtifactStatus.DRAFT)
    except TransitionError:
        pass
    
    # Check: Event Log darf KEINE Statusänderung enthalten
    history = art_manager.get_artifact_history(art.id)
    status_changes = [e for e in history if e["event_type"] == "status_changed"]
    
    # Es darf nur die initiale Erstellung und evtl. gültige Änderungen geben, 
    # aber KEIN Drift zum illegalen DRAFT.
    for event in status_changes:
        assert event["to_status"] != "draft"


# --- TEST 5: Atomic Persistence Check ---
def test_atomic_persistence_failure_rollback(authority, tmp_path):
    """
    Prüft, ob bei einem Dateisystem-Fehler (Permission denied)
    die in-memory Authority stabil bleibt.
    """
    # Verzeichnis schreibgeschützt machen
    authority._config_path.chmod(0o444)
    
    valid_proposal = {
        "primary": "writer",
        "mediator": "mediator",
        "thinking": "qwen3:14b",
        "expert": "expert"
    }
    
    old_hash = authority.envelope.canon_hash
    
    # Das muss fehlschlagen beim Schreiben in die canon.yaml
    with pytest.raises(Exception):
        authority.apply_proposal(valid_proposal)
    
    # In-Memory State muss unverändert sein
    assert authority.envelope.canon_hash == old_hash
