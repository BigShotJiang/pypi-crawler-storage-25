import asyncio
import httpx
import pytest
from unittest.mock import AsyncMock, patch, MagicMock

from mcp_servers.nextcloud_server import parse_propfind, _current_checkpoints

# Sample XML for testing PROPFIND parsing
SAMPLE_PROPFIND_XML = """<?xml version="1.0"?>
<d:multistatus xmlns:d="DAV:" xmlns:s="http://sabredav.org/ns" xmlns:nc="http://nextcloud.org/ns">
  <d:response>
    <d:href>/remote.php/dav/files/user/folder1/</d:href>
    <d:propstat>
      <d:prop>
        <d:getlastmodified>Wed, 10 Nov 2021 16:20:00 GMT</d:getlastmodified>
        <d:resourcetype><d:collection/></d:resourcetype>
        <d:getetag>"12345dir"</d:getetag>
      </d:prop>
      <d:status>HTTP/1.1 200 OK</d:status>
    </d:propstat>
  </d:response>
  <d:response>
    <d:href>/remote.php/dav/files/user/folder1/file.txt</d:href>
    <d:propstat>
      <d:prop>
        <d:getlastmodified>Wed, 10 Nov 2021 16:21:00 GMT</d:getlastmodified>
        <d:resourcetype/>
        <d:getetag>"67890file"</d:getetag>
      </d:prop>
      <d:status>HTTP/1.1 200 OK</d:status>
    </d:propstat>
  </d:response>
</d:multistatus>"""

def test_parse_propfind():
    """Test the XML parsing logic for PROPFIND."""
    parsed = parse_propfind(SAMPLE_PROPFIND_XML)
    assert len(parsed) == 2
    
    dir_path = "/remote.php/dav/files/user/folder1/"
    assert dir_path in parsed
    assert parsed[dir_path]["type"] == "directory"
    assert parsed[dir_path]["etag"] == "12345dir"
    
    file_path = "/remote.php/dav/files/user/folder1/file.txt"
    assert file_path in parsed
    assert parsed[file_path]["type"] == "file"
    assert parsed[file_path]["etag"] == "67890file"

@pytest.mark.asyncio
@patch("mcp_servers.nextcloud_server.asyncio.sleep", new_callable=AsyncMock)
@patch("mcp_servers.nextcloud_server.propfind_raw", new_callable=AsyncMock)
async def test_start_poller_diffs(mock_propfind, mock_sleep):
    """Test that the Nextcloud Poller accurately detects creation, modification, and deletion events."""
    from mcp_servers.nextcloud_server import start_poller, NEXTCLOUD_URL
    import mcp_servers.nextcloud_server as nc_server
    
    # Needs a mock URL to prevent early exit
    nc_server.NEXTCLOUD_URL = "https://mock"
    
    test_path = "/test_watch"
    
    # 1st iteration: Poller initializes and takes first snapshot
    mock_propfind.side_effect = [
        # Snapshot 1
        """<?xml version="1.0"?><d:multistatus xmlns:d="DAV:"><d:response><d:href>/file1</d:href><d:propstat><d:status>HTTP/1.1 200 OK</d:status><d:prop><d:getetag>"A"</d:getetag></d:prop></d:propstat></d:response></d:multistatus>""",
        # Snapshot 2 (file1 modified, file2 created)
        """<?xml version="1.0"?><d:multistatus xmlns:d="DAV:"><d:response><d:href>/file1</d:href><d:propstat><d:status>HTTP/1.1 200 OK</d:status><d:prop><d:getetag>"B"</d:getetag></d:prop></d:propstat></d:response><d:response><d:href>/file2</d:href><d:propstat><d:status>HTTP/1.1 200 OK</d:status><d:prop><d:getetag>"C"</d:getetag></d:prop></d:propstat></d:response></d:multistatus>""",
        # Snapshot 3 (file1 deleted)
        """<?xml version="1.0"?><d:multistatus xmlns:d="DAV:"><d:response><d:href>/file2</d:href><d:propstat><d:status>HTTP/1.1 200 OK</d:status><d:prop><d:getetag>"C"</d:getetag></d:prop></d:propstat></d:response></d:multistatus>""",
        Exception("STOP_TEST") # Throw to break the infinite while loop
    ]
    
    nc_server._current_checkpoints.clear()
    
    try:
        await start_poller(test_path, poll_interval=1)
    except Exception as e:
        if str(e) != "STOP_TEST":
            raise
    
    # The checkpoints should reflect snapshot 3
    assert test_path in nc_server._current_checkpoints
    final_checkpoint = nc_server._current_checkpoints[test_path]
    assert "/file2" in final_checkpoint
    assert "/file1" not in final_checkpoint
    
    # Verify sleep was called indicating intervals
    assert mock_sleep.call_count == 3
    # Check that backoff resets normally
    assert mock_sleep.call_args_list[0][0][0] == 1 # First sleep 1s
    assert mock_sleep.call_args_list[1][0][0] == 1 # Second sleep 1s

@pytest.mark.asyncio
@patch("mcp_servers.nextcloud_server.asyncio.sleep", new_callable=AsyncMock)
@patch("mcp_servers.nextcloud_server.propfind_raw", new_callable=AsyncMock)
async def test_start_poller_exponential_backoff(mock_propfind, mock_sleep):
    """Test that exponential backoff activates upon exceptions."""
    from mcp_servers.nextcloud_server import start_poller
    import mcp_servers.nextcloud_server as nc_server
    nc_server.NEXTCLOUD_URL = "https://mock"
    
    mock_propfind.side_effect = [
        httpx.HTTPError("Network failed"), # Fail 1 -> backoff 20
        httpx.HTTPError("Network failed"), # Fail 2 -> backoff 40
        """<?xml version="1.0"?><d:multistatus xmlns:d="DAV:"/>""", # Success -> backoff resets to 10
        Exception("STOP_TEST")
    ]
    
    try:
        await start_poller("/test", poll_interval=10, max_backoff=300)
    except Exception as e:
        if str(e) != "STOP_TEST":
            raise

    # Backoff sequence: 20s, 40s, 10s (recovered)
    assert mock_sleep.call_count == 3
    assert mock_sleep.call_args_list[0][0][0] == 20
    assert mock_sleep.call_args_list[1][0][0] == 40
    assert mock_sleep.call_args_list[2][0][0] == 10
