"""
Integration tests for Embedding & RAG Foundation integration.

Tests that the integration adapter works correctly with both
Community Edition and Business/Science Edition, and maintains
backward compatibility with existing code.
"""

import pytest
import asyncio
from unittest.mock import Mock, patch, AsyncMock

from core.embedding_integration_adapter import (
    EmbeddingIntegrationAdapter,
    get_ce_embedding_adapter,
    get_bse_embedding_adapter,
    get_embedding_adapter,
)
from api.factory import build_container


class TestEmbeddingIntegrationAdapter:
    """Tests for the embedding integration adapter."""
    
    def test_adapter_creation_ce(self):
        """Test creating Community Edition adapter."""
        adapter = EmbeddingIntegrationAdapter(use_governed=False)
        assert adapter.use_governed is False
        assert adapter._simple_service is not None or adapter._legacy_service is not None
    
    def test_adapter_creation_bse(self):
        """Test creating Business/Science Edition adapter."""
        adapter = EmbeddingIntegrationAdapter(use_governed=True)
        assert adapter.use_governed is True
        # BSE adapter might fall back to CE if governance not available
        assert adapter._governed_service is not None or adapter._simple_service is not None
    
    @patch('core.embedding_integration_adapter.NEW_FOUNDATION_AVAILABLE', True)
    @patch('core.embedding_integration_adapter.SimpleEmbeddingService')
    def test_generate_embedding_with_new_foundation_ce(self, mock_simple_service):
        """Test generate_embedding with new foundation (CE)."""
        # Mock simple service
        mock_service = Mock()
        # Create a mock numpy array
        mock_embedding = Mock()
        mock_embedding.tolist.return_value = [0.1, 0.2, 0.3] * 256  # 768 dimensions
        mock_service.embed.return_value.embedding = mock_embedding
        mock_service.embed.return_value.vector_id = "vec_123"
        mock_simple_service.return_value = mock_service
        
        adapter = EmbeddingIntegrationAdapter(use_governed=False)
        adapter._simple_service = mock_service
        
        # Test embedding generation
        embedding = asyncio.run(adapter.generate_embedding("test text"))
        
        assert len(embedding) == 768
        assert embedding[0] == 0.1
        assert embedding[1] == 0.2
        assert embedding[2] == 0.3
        
        # Verify service was called
        mock_service.embed.assert_called_once()
    
    @patch('core.embedding_integration_adapter.NEW_FOUNDATION_AVAILABLE', False)
    @patch('core.embedding_service.embedding_service', new_callable=Mock)
    def test_generate_embedding_with_legacy_service(self, mock_embedding_service):
        """Test generate_embedding falls back to legacy service when new foundation not available."""
        # Mock legacy service
        mock_embedding_service.generate_embedding = AsyncMock(return_value=[0.5] * 768)
        
        adapter = EmbeddingIntegrationAdapter(use_governed=False)
        
        # Test embedding generation
        embedding = asyncio.run(adapter.generate_embedding("test text"))
        
        assert len(embedding) == 768
        assert embedding[0] == 0.5
        
        # Verify legacy service was called
        mock_embedding_service.generate_embedding.assert_called_once_with("test text")
    
    @patch('core.embedding_integration_adapter.NEW_FOUNDATION_AVAILABLE', True)
    @patch('core.embedding_integration_adapter.SimpleEmbeddingService')
    def test_embed_text_method(self, mock_simple_service):
        """Test new embed_text method."""
        # Mock simple service
        mock_service = Mock()
        mock_service.embed.return_value.vector_id = "vec_456"
        mock_simple_service.return_value = mock_service
        
        adapter = EmbeddingIntegrationAdapter(use_governed=False)
        adapter._simple_service = mock_service
        
        # Test embed_text
        vector_id = adapter.embed_text("test text", metadata={"author": "test"})
        
        assert vector_id == "vec_456"
        mock_service.embed.assert_called_once()
    
    @patch('core.embedding_integration_adapter.NEW_FOUNDATION_AVAILABLE', True)
    @patch('core.embedding_integration_adapter.SimpleEmbeddingService')
    def test_search_similar(self, mock_simple_service):
        """Test search_similar method."""
        # Mock simple service
        mock_service = Mock()
        mock_service.search.return_value = [
            {
                "vector_id": "vec_1",
                "content_ref": "doc1",
                "similarity_score": 0.85,
                "metadata": {"source": "test"}
            }
        ]
        mock_simple_service.return_value = mock_service
        
        adapter = EmbeddingIntegrationAdapter(use_governed=False)
        adapter._simple_service = mock_service
        
        # Test search
        results = adapter.search_similar("test query", limit=5, similarity_threshold=0.7)
        
        assert len(results) == 1
        assert results[0]["vector_id"] == "vec_1"
        assert results[0]["similarity_score"] == 0.85
        mock_service.search.assert_called_once_with(
            query="test query",
            modality="text",
            limit=5,
            similarity_threshold=0.7
        )
    
    @patch('core.embedding_integration_adapter.NEW_FOUNDATION_AVAILABLE', True)
    @patch('core.embedding_integration_adapter.SimpleEmbeddingService')
    def test_retrieve_context(self, mock_simple_service):
        """Test retrieve_context method."""
        # Mock simple service
        mock_service = Mock()
        
        # Create mock snippets
        mock_snippet = Mock()
        mock_snippet.content_ref = "doc1"
        mock_snippet.text = "This is document 1"
        mock_snippet.modality = "text"
        mock_snippet.similarity_score = 0.82
        mock_snippet.metadata = {"source": "test"}
        
        # Create mock context packet
        mock_context_packet = Mock()
        mock_context_packet.query = "test query"
        mock_context_packet.snippets = [mock_snippet]
        mock_context_packet.total_snippets = 1
        mock_context_packet.retrieved_at = Mock()
        mock_context_packet.retrieved_at.isoformat.return_value = "2024-01-01T00:00:00"
        
        mock_service.retrieve_context.return_value = mock_context_packet
        mock_simple_service.return_value = mock_service
        
        adapter = EmbeddingIntegrationAdapter(use_governed=False)
        adapter._simple_service = mock_service
        
        # Test retrieve_context
        context = adapter.retrieve_context("test query", max_snippets=3, max_tokens_per_snippet=100)
        
        assert context["query"] == "test query"
        assert len(context["snippets"]) == 1
        assert context["snippets"][0]["text"] == "This is document 1"
        mock_service.retrieve_context.assert_called_once_with(
            query="test query",
            modality="text",
            max_snippets=3,
            max_tokens_per_snippet=100
        )
    
    @patch('core.embedding_integration_adapter.NEW_FOUNDATION_AVAILABLE', True)
    @patch('core.embedding_integration_adapter.SimpleEmbeddingService')
    def test_get_stats(self, mock_simple_service):
        """Test get_stats method."""
        # Mock simple service
        mock_service = Mock()
        mock_service.get_stats.return_value = {
            "service": "simple_embedding_service",
            "vector_store_backend": "sqlite",
            "total_vectors": 42
        }
        mock_simple_service.return_value = mock_service
        
        adapter = EmbeddingIntegrationAdapter(use_governed=False)
        adapter._simple_service = mock_service
        
        # Test get_stats
        stats = adapter.get_stats()
        
        assert stats["service"] == "simple_embedding_service"
        assert stats["vector_store_backend"] == "sqlite"
        assert stats["total_vectors"] == 42
        assert stats["edition"] == "community"
        assert stats["new_foundation"] is True
        assert stats["use_governed"] is False


class TestGlobalAdapters:
    """Tests for global adapter instances."""
    
    def test_get_ce_embedding_adapter(self):
        """Test get_ce_embedding_adapter returns singleton."""
        adapter1 = get_ce_embedding_adapter()
        adapter2 = get_ce_embedding_adapter()
        
        assert adapter1 is adapter2
        assert adapter1.use_governed is False
    
    def test_get_bse_embedding_adapter(self):
        """Test get_bse_embedding_adapter returns singleton."""
        adapter1 = get_bse_embedding_adapter()
        adapter2 = get_bse_embedding_adapter()
        
        assert adapter1 is adapter2
        assert adapter1.use_governed is True
    
    def test_get_embedding_adapter(self):
        """Test get_embedding_adapter returns correct adapter based on flag."""
        ce_adapter = get_embedding_adapter(use_governed=False)
        bse_adapter = get_embedding_adapter(use_governed=True)
        
        assert ce_adapter.use_governed is False
        assert bse_adapter.use_governed is True
        assert ce_adapter is not bse_adapter


class TestFactoryIntegration:
    """Tests for factory integration."""
    
    def test_build_container_includes_embedding_adapters(self):
        """Test that build_container includes embedding adapters."""
        container = build_container()
        
        # Check that container has embedding adapters
        assert hasattr(container, 'ce_embedding_adapter')
        assert hasattr(container, 'bse_embedding_adapter')
        
        # Adapters should be instances of EmbeddingIntegrationAdapter
        assert container.ce_embedding_adapter is not None
        assert container.bse_embedding_adapter is not None
        
        # Check edition flags
        assert container.ce_embedding_adapter.use_governed is False
        assert container.bse_embedding_adapter.use_governed is True


class TestArchitecturalInvariants:
    """Tests for architectural invariants."""
    
    def test_index_memory_knowledge_separation(self):
        """Test that Index ≠ Memory ≠ Knowledge principle is maintained."""
        # This is enforced at the architectural level in the core components
        # The integration adapter should not violate this principle
        
        adapter = get_ce_embedding_adapter()
        
        # The adapter should not have methods that write to memory
        # It should only have embedding and retrieval methods
        assert hasattr(adapter, 'generate_embedding')
        assert hasattr(adapter, 'embed_text')
        assert hasattr(adapter, 'search_similar')
        assert hasattr(adapter, 'retrieve_context')
        
        # It should NOT have memory write methods
        # (This is enforced by the architecture, not runtime checks)
    
    def test_retrieval_only_rag(self):
        """Test that RAG is retrieval-only (no memory writes)."""
        # The retrieve_context method should only retrieve, not write
        # This is enforced by the RAGFoundation architecture
        
        adapter = get_ce_embedding_adapter()
        
        # The adapter provides retrieve_context which is retrieval-only
        # It does not provide methods to write context back to memory
        assert hasattr(adapter, 'retrieve_context')
        
        # There should be no "store_context" or similar write method
        # (This check is conceptual - the architecture enforces this)
    
    def test_governance_never_flows_backward(self):
        """Test that governance concepts don't flow backward to CE."""
        ce_adapter = get_ce_embedding_adapter()
        bse_adapter = get_bse_embedding_adapter()
        
        # CE adapter should not have governance dependencies
        # It might have governance attributes (from the unified adapter class)
        # but they should not be functional in CE
        
        # BSE adapter should have governance enabled
        assert bse_adapter.use_governed is True
        
        # The key is that CE code doesn't depend on governance modules
        # This is enforced by the import structure and conditional loading


class TestBackwardCompatibility:
    """Tests for backward compatibility with existing code."""
    
    @patch('core.embedding_integration_adapter.NEW_FOUNDATION_AVAILABLE', True)
    @patch('core.embedding_integration_adapter.SimpleEmbeddingService')
    def test_backward_compatible_embedding_generation(self, mock_simple_service):
        """Test that generate_embedding maintains backward compatibility."""
        # Mock service to return non-768 embedding
        mock_service = Mock()
        # Create a mock numpy array
        mock_embedding = Mock()
        mock_embedding.tolist.return_value = [0.1, 0.2, 0.3] * 128  # 384 dimensions
        mock_service.embed.return_value.embedding = mock_embedding
        mock_service.embed.return_value.vector_id = "vec_123"
        mock_simple_service.return_value = mock_service
        
        adapter = EmbeddingIntegrationAdapter(use_governed=False)
        adapter._simple_service = mock_service
        
        # Test embedding generation with non-768 dimensions
        embedding = asyncio.run(adapter.generate_embedding("test text"))
        
        # Should be projected to 768 dimensions (backward compatibility)
        assert len(embedding) == 768
        
        # First 384 dimensions should match, last 384 should be zeros
        assert embedding[0] == 0.1
        assert embedding[1] == 0.2
        assert embedding[2] == 0.3
        assert embedding[383] == 0.3  # Last of original
        assert embedding[384] == 0.0  # First padded zero
        assert embedding[767] == 0.0  # Last padded zero


if __name__ == "__main__":
    pytest.main([__file__, "-v"])