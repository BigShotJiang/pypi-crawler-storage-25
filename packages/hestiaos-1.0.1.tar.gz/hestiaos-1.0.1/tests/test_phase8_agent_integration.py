#!/usr/bin/env python3
"""
Test Phase 8: Agent Context Integration with Response Contract System

This test verifies that the AgentContext class correctly integrates with
the Response Contract System implemented by Antigravity.
"""

import asyncio
import sys
from pathlib import Path

# Add core to path
sys.path.insert(0, str(Path(__file__).parent))

from core.agent.agent_context import create_agent_context, AgentRole, AgentState
from core.contracts.response_contract import ResponseContract, OutputChannel
from core.processing.response_processor import ResponseContractProcessor


async def test_response_contract_integration():
    """Test basic integration of Response Contract System with AgentContext."""
    print("=== Phase 8: Agent Context Integration Test ===")
    
    # Create a response processor
    processor = ResponseContractProcessor()
    
    # Create agent context with response processor
    agent = create_agent_context(
        agent_id="test_agent_1",
        role=AgentRole.EXECUTOR,
        response_processor=processor
    )
    
    print(f"Created agent: {agent.agent_id} with role: {agent.role.value}")
    
    # Define a test task that returns raw text with reasoning
    async def test_task_with_reasoning(ctx):
        """Task that returns text containing reasoning and response."""
        return """Thinking: I need to analyze this problem first.
Let me break it down step by step.

The user is asking about the weather in Berlin.
First, I should check if we have weather data available.
Then I need to format the response clearly.

Final Answer: The weather in Berlin is currently 18°C with partial clouds.
Expect light rain in the evening."""
    
    # Execute the task
    print("\n1. Executing task with reasoning text...")
    result = await agent.execute(test_task_with_reasoning)
    
    # Check if we got a ResponseContract
    if isinstance(result, ResponseContract):
        print("✅ Success: execute() returned a ResponseContract")
        
        # Check channels
        print(f"   Contract ID: {result.id}")
        print(f"   Channels: {list(result.channels.keys())}")
        
        # Get reasoning content
        reasoning = result.get_channel(OutputChannel.REASONING)
        if reasoning:
            print(f"✅ Reasoning channel found ({len(reasoning)} chars)")
            # Show first 100 chars of reasoning
            print(f"   Reasoning preview: {reasoning[:100]}...")
        else:
            print("❌ No reasoning channel found")
        
        # Get response content
        response = result.get_channel(OutputChannel.RESPONSE)
        if response:
            print(f"✅ Response channel found ({len(response)} chars)")
            print(f"   Response: {response}")
        else:
            print("❌ No response channel found")
        
        # Test get_display_output (user view)
        user_output = result.get_display_output(debug_mode=False)
        print(f"\n2. User output (debug_mode=False):")
        print(f"   {user_output}")
        
        # Test get_display_output (debug view)
        debug_output = result.get_display_output(debug_mode=True)
        print(f"\n3. Debug output (debug_mode=True):")
        print(f"   First 150 chars: {debug_output[:150]}...")
        
        # Check execution history
        history = agent.get_execution_history()
        print(f"\n4. Execution history: {len(history)} contracts")
        
        # Check latest contract
        latest = agent.get_latest_contract()
        if latest and latest.id == result.id:
            print("✅ Latest contract matches execution result")
        
        # Check has_reasoning_content
        if agent.has_reasoning_content():
            print("✅ Agent correctly detected reasoning content")
        
        # Test get_display_output from agent context
        agent_output = agent.get_display_output(debug_mode=False)
        print(f"\n5. Agent.get_display_output(): {agent_output[:100]}...")
        
    else:
        print(f"❌ execute() returned {type(result)}, expected ResponseContract")
        print(f"   Result: {result}")
        return False
    
    # Test error handling
    print("\n6. Testing error handling...")
    
    async def failing_task(ctx):
        """Task that raises an exception."""
        raise ValueError("Test error for error contract")
    
    try:
        await agent.execute(failing_task)
        print("❌ Expected exception not raised")
        return False
    except ValueError as e:
        print(f"✅ Exception caught: {e}")
        
        # Check if error contract was created
        history = agent.get_execution_history()
        if len(history) >= 2:
            error_contract = history[-1]
            error_content = error_contract.get_channel(OutputChannel.ERROR)
            if error_content and "Test error" in error_content:
                print("✅ Error contract created with correct error message")
            else:
                print("❌ Error contract not created correctly")
        else:
            print("❌ No error contract in history")
    
    # Test execution stats
    print("\n7. Testing execution stats...")
    stats = agent.get_execution_stats()
    print(f"   Stats keys: {list(stats.keys())}")
    
    if stats.get('has_response_contract_system'):
        print("✅ Response Contract System detected in stats")
        print(f"   Contract count: {stats.get('response_contract_count', 0)}")
    else:
        print("❌ Response Contract System not detected in stats")
    
    print("\n=== Phase 8 Integration Test Complete ===")
    return True


async def test_backward_compatibility():
    """Test backward compatibility when Response Contract System is not available."""
    print("\n=== Testing Backward Compatibility ===")
    
    # Create agent without response processor (simulating missing system)
    agent = create_agent_context(
        agent_id="test_agent_2",
        role=AgentRole.GENERALIST,
        response_processor=None
    )
    
    # Define a simple task
    async def simple_task(ctx):
        return "Simple response without reasoning"
    
    print("1. Executing simple task...")
    result = await agent.execute(simple_task)
    
    # Should return raw string (backward compatibility)
    if isinstance(result, str):
        print(f"✅ Backward compatibility: execute() returned string: {result}")
    else:
        print(f"❌ Expected string, got {type(result)}")
        return False
    
    # Check that response contract methods return empty/default values
    history = agent.get_execution_history()
    if not history:
        print("✅ get_execution_history() returns empty list (backward compatible)")
    
    latest = agent.get_latest_contract()
    if latest is None:
        print("✅ get_latest_contract() returns None (backward compatible)")
    
    display_output = agent.get_display_output()
    if display_output == "":
        print("✅ get_display_output() returns empty string (backward compatible)")
    
    if not agent.has_reasoning_content():
        print("✅ has_reasoning_content() returns False (backward compatible)")
    
    print("\n=== Backward Compatibility Test Complete ===")
    return True


async def main():
    """Run all tests."""
    print("Phase 8: Agent Context Integration with Response Contract System")
    print("=" * 70)
    
    success = True
    
    try:
        # Test 1: Response Contract Integration
        if not await test_response_contract_integration():
            success = False
        
        # Test 2: Backward Compatibility
        if not await test_backward_compatibility():
            success = False
            
    except Exception as e:
        print(f"\n❌ Test failed with exception: {e}")
        import traceback
        traceback.print_exc()
        success = False
    
    if success:
        print("\n✅ All Phase 8 integration tests passed!")
        return 0
    else:
        print("\n❌ Some tests failed")
        return 1


if __name__ == "__main__":
    exit_code = asyncio.run(main())
    sys.exit(exit_code)