import asyncio
import os
import yaml
from pathlib import Path
from core.tool_manager import ToolManager # analyzer: ignore # analyzer: ignore
from core.cli.manager import CLIManager

async def test_permanent_plugin_control():
    print("🚀 Starting Permanent Plugin Control Test...")
    
    # 1. Setup - Mock user.yml
    config_dir = Path("config")
    config_dir.mkdir(exist_ok=True)
    user_yml = config_dir / "user.yml"
    
    # Clean start
    if user_yml.exists():
        user_yml.unlink()
    
    tm = ToolManager()
    await tm.load_plugins()
    
    # Find a plugin to test with
    if not tm.plugins:
        print("❌ No plugins found to test.")
        return
    
    plugin_id = list(tm.plugins.keys())[0]
    print(f"📦 Testing with plugin: {plugin_id}")
    
    # Ensure it's enabled by default
    plugin = tm.plugins[plugin_id]
    plugin.enabled = True
    
    # 2. Disable Plugin
    print(f"🚫 Disabling plugin {plugin_id}...")
    tm.update_plugin(plugin_id, enabled=False)
    
    # Check if persisted
    with open(user_yml, "r") as f:
        conf = yaml.safe_load(f)
        assert conf[plugin_id]["enabled"] == False
        print(f"✅ State persisted to {user_yml}")
    
    # 3. Check Filtering
    definitions = tm.get_tool_definitions()
    tool_names = [d["function"]["name"] for d in definitions if "function" in d]
    
    plugin_tools = plugin.get_tools()
    for pt in plugin_tools:
        name = pt["function"]["name"] if isinstance(pt, dict) and "function" in pt else pt.get("name")
        if name:
            assert name not in tool_names
            print(f"✅ Tool {name} is hidden.")
            
            # 4. Check Execution Guard
            res = await tm.execute_tool(name, {})
            assert "disabled" in res["error"]
            print(f"✅ Execution of {name} blocked.")

    # 5. Check CLI Filtering
    cli = CLIManager(tool_manager=tm)
    help_text = await cli.show_help([], "test")
    assert f"&/ {plugin_id}:" not in help_text
    print(f"✅ CLI commands for {plugin_id} are hidden.")

    # 6. Re-enable and check
    print(f"✅ Re-enabling plugin {plugin_id}...")
    tm.update_plugin(plugin_id, enabled=True)
    with open(user_yml, "r") as f:
        conf = yaml.safe_load(f)
        assert conf[plugin_id]["enabled"] == True
        
    definitions = tm.get_tool_definitions()
    tool_names = [d["function"]["name"] for d in definitions if "function" in d]
    for pt in plugin_tools:
        name = pt["function"]["name"] if isinstance(pt, dict) and "function" in pt else pt.get("name")
        if name:
            assert name in tool_names
            print(f"✅ Tool {name} is visible again.")

    print("🎉 All Permanent Plugin Control tests passed!")

if __name__ == "__main__":
    asyncio.run(test_permanent_plugin_control())
