import asyncio
import os
import shutil
import json
from pathlib import Path
from core.project_service import ProjectService
from plugins.pm_plugin import ProjectManagementPlugin
from core.domain.models import TaskStatus

async def test_pm_integration():
    print("🚀 Starting PM Integration Test (v2)")
    
    # Setup temporary vault
    vault_path = Path("./test_vault_pm")
    if vault_path.exists():
        shutil.rmtree(vault_path)
    vault_path.mkdir()
    
    try:
        # Initialize Plugin
        plugin = ProjectManagementPlugin()
        # Mocking the service initialization to use our test vault
        plugin.service = ProjectService(vault_path)
        
        # 1. Initialize Project
        print("\n1️⃣ Testing pm_init_project...")
        init_args = {
            "project_id": "test-project-alpha",
            "goal": "Verify the PM integration works flawlessly.",
            "scope": "Limited to automated testing.",
            "initial_tasks": ["Setup test environment", "Run integration suite"]
        }
        res_init = await plugin.execute("pm_init_project", init_args, {})
        print(f"Result: {res_init['status']}")
        assert res_init["status"] == "success"
        
        # 2. List Projects
        print("\n2️⃣ Testing pm_list_projects...")
        res_list = await plugin.execute("pm_list_projects", {}, {})
        print(f"Result: {res_list['status']}, Projects found: {len(res_list['data'])}")
        assert res_list["status"] == "success"
        assert len(res_list["data"]) >= 1
        assert res_list["data"][0]["id"] == "test-project-alpha"
        
        # 3. Add Task
        print("\n3️⃣ Testing pm_add_task...")
        add_task_args = {
            "project_id": "test-project-alpha",
            "description": "Verify Markdown rendering of nested tasks."
        }
        res_add = await plugin.execute("pm_add_task", add_task_args, {})
        print(f"Result: {res_add['status']}")
        assert res_add["status"] == "success"
        
        # 4. Get Project Details
        print("\n4️⃣ Testing pm_get_project...")
        res_get = await plugin.execute("pm_get_project", {"project_id": "test-project-alpha"}, {})
        print(f"Result: {res_get['status']}")
        assert res_get["status"] == "success"
        project_data = res_get["data"]
        assert len(project_data["tasks"]) == 3 # 2 initial + 1 added
        print(f"Project Goal: {project_data['goal']}")
        
        # 5. Update Task Status
        print("\n5️⃣ Testing pm_update_task...")
        update_args = {
            "project_id": "test-project-alpha",
            "task_id": "task_0",
            "status": "DONE"
        }
        res_update = await plugin.execute("pm_update_task", update_args, {})
        print(f"Result: {res_update['status']}")
        assert res_update["status"] == "success"
        
        # 6. Verify Filesystem
        print("\n6️⃣ Verifying Filesystem...")
        project_md = vault_path / "_HestiaOS" / "Projects" / "test-project-alpha" / "Project.md"
        index_md = vault_path / "_HestiaOS" / "Projects" / "Index.md"
        
        assert project_md.exists(), "Project.md missing"
        assert index_md.exists(), "Index.md missing"
        
        project_content = project_md.read_text()
        index_content = index_md.read_text()
        
        print(f"--- Project.md Snapshot ---\n{project_content[:200]}...\n")
        print(f"--- Index.md Snapshot ---\n{index_content}\n")
        
        assert "[x] Setup test environment `task_0` (DONE)" in project_content
        assert "test-project-alpha" in index_content
        assert "1/3" in index_content # progress check
        
        print("\n✨ ALL PM INTEGRATION TESTS PASSED!")
        
    finally:
        # Cleanup
        if vault_path.exists():
            shutil.rmtree(vault_path)
            print("\n🧹 Cleaned up test vault.")

if __name__ == "__main__":
    asyncio.run(test_pm_integration())
