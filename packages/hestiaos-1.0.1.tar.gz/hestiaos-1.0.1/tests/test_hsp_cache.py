#!/usr/bin/env python3
"""
Test HSP Decision Cache Implementation

Validates cache correctness, performance, and governance safety.
"""

import asyncio
import time
import hashlib
from typing import Dict, Any
from datetime import datetime

# Add project root to path
import sys
import os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from core.hsp.cache import HSPDecisionCache, CacheKeyComponents, CacheHitStatus
from core.hsp.middleware_cached import CachedHSPMiddleware, create_cached_hsp_middleware
from core.hsp.schemas import HSPRequestSchema, HSPDecision, HSPDecisionOutcome
from core.hsp.tracing import HSPTraceSystem


class MockEGLClient:
    """Mock EGL client for testing"""
    
    def __init__(self):
        self.call_count = 0
    
    async def evaluate(self, request: Dict[str, Any]) -> Dict[str, Any]:
        """Mock EGL evaluation"""
        self.call_count += 1
        await asyncio.sleep(0.01)  # Simulate processing time
        return {
            "decision": "allow",
            "confidence": 0.9,
            "reasoning": "Mock EGL decision",
            "metadata": {"call_count": self.call_count}
        }


class MockPolicyStore:
    """Mock policy store for testing"""
    
    def __init__(self):
        self.policies = {"default": {"rules": [], "version": "1.0.0"}}
    
    def get_policy(self, policy_name: str) -> Dict[str, Any]:
        """Get policy by name"""
        return self.policies.get(policy_name, {"rules": [], "version": "1.0.0"})


class MockHSPPipeline:
    """Mock HSP pipeline for testing"""
    
    def __init__(self):
        self.call_count = 0
        self.trace_system = HSPTraceSystem()
    
    async def execute(self, hsp_request: HSPRequestSchema) -> HSPDecision:
        """Mock pipeline execution"""
        self.call_count += 1
        await asyncio.sleep(0.05)  # Simulate processing time (50ms)
        
        return HSPDecision(
            outcome=HSPDecisionOutcome.ALLOW,
            trace_id=hsp_request.trace_id,
            request_id=hsp_request.request_id,
            timestamp=datetime.now(),
            reason=f"Mock decision #{self.call_count}",
            constraints={},
            metadata={
                "pipeline_call_count": self.call_count,
                "cache_info": {"hit": False, "source": "pipeline"}
            }
        )


async def test_cache_key_generation():
    """Test cache key generation correctness"""
    print("🧪 Testing cache key generation...")
    
    # Create identical key components
    components1 = CacheKeyComponents(
        file_content_hash="abc123",
        policy_version="1.0.0",
        hsp_schema_version="1.0.0",
        environment="test",
        security_level="medium",
        code_ownership="team"
    )
    
    components2 = CacheKeyComponents(
        file_content_hash="abc123",
        policy_version="1.0.0",
        hsp_schema_version="1.0.0",
        environment="test",
        security_level="medium",
        code_ownership="team"
    )
    
    # Keys should be identical
    key1 = components1.generate_key()
    key2 = components2.generate_key()
    
    assert key1 == key2, "Identical components should generate identical keys"
    print(f"  ✓ Identical components: {key1[:16]}...")
    
    # Create different key components
    components3 = CacheKeyComponents(
        file_content_hash="xyz789",  # Different content
        policy_version="1.0.0",
        hsp_schema_version="1.0.0",
        environment="test",
        security_level="medium",
        code_ownership="team"
    )
    
    key3 = components3.generate_key()
    assert key1 != key3, "Different content should generate different keys"
    print(f"  ✓ Different content: {key3[:16]}...")
    
    print("  ✅ Cache key generation tests passed")


async def test_cache_basic_operations():
    """Test basic cache operations"""
    print("\n🧪 Testing basic cache operations...")
    
    trace_system = HSPTraceSystem()
    cache = HSPDecisionCache(trace_system=trace_system, config={
        "cache_enabled": True,
        "cache_ttl_seconds": 10,
        "max_cache_entries": 100
    })
    
    # Create test request
    request = HSPRequestSchema(
        request_id="test-1",
        trace_id="trace-1",
        timestamp=datetime.now().isoformat(),
        context={
            "file_content": "print('hello')",
            "security_level": "medium",
            "code_ownership": "team"
        },
        source="test"
    )
    
    # Test cache miss
    decision, status = await cache.get_decision(request, "trace-1")
    assert status == CacheHitStatus.MISS
    assert decision is None
    print("  ✓ Cache miss works correctly")
    
    # Create test decision
    test_decision = HSPDecision(
        outcome=HSPDecisionOutcome.ALLOW,
        trace_id="trace-1",
        request_id="test-1",
        timestamp=datetime.now(),
        reason="Test decision",
        constraints={},
        metadata={}
    )
    
    # Store decision
    await cache.store_decision(request, test_decision, "trace-1")
    print("  ✓ Decision stored successfully")
    
    # Test cache hit
    decision, status = await cache.get_decision(request, "trace-1")
    assert status == CacheHitStatus.HIT
    assert decision is not None
    assert decision.request_id == "test-1"
    print("  ✓ Cache hit works correctly")
    
    # Test cache bypass
    cache.set_bypass_mode(True)
    decision, status = await cache.get_decision(request, "trace-2")
    assert status == CacheHitStatus.BYPASS
    print("  ✓ Cache bypass works correctly")
    
    cache.set_bypass_mode(False)
    
    print("  ✅ Basic cache operations tests passed")


async def test_cache_performance():
    """Test cache performance benefits"""
    print("\n🧪 Testing cache performance...")
    
    trace_system = HSPTraceSystem()
    cache = HSPDecisionCache(trace_system=trace_system)
    
    # Create mock pipeline
    pipeline = MockHSPPipeline()
    
    # Create test request
    request = HSPRequestSchema(
        request_id="perf-test",
        trace_id="trace-perf",
        timestamp=datetime.now().isoformat(),
        context={
            "file_content": "print('performance test')",
            "security_level": "medium",
            "code_ownership": "team"
        },
        source="test"
    )
    
    # First call (cache miss)
    start_time = time.time()
    decision1 = await pipeline.execute(request)
    first_call_time = (time.time() - start_time) * 1000
    
    # Store in cache
    await cache.store_decision(request, decision1, "trace-perf")
    
    # Simulate cached pipeline
    cache_hit_start = time.time()
    cached_decision, status = await cache.get_decision(request, "trace-perf")
    cache_hit_time = (time.time() - cache_hit_start) * 1000
    
    # Verify cache hit
    assert status == CacheHitStatus.HIT
    assert cached_decision.request_id == decision1.request_id
    
    # Calculate speedup
    speedup = first_call_time / cache_hit_time if cache_hit_time > 0 else 0
    
    print(f"  ✓ First call (pipeline): {first_call_time:.2f} ms")
    print(f"  ✓ Cache hit: {cache_hit_time:.2f} ms")
    print(f"  ✓ Speedup: {speedup:.1f}x")
    
    assert cache_hit_time < first_call_time, "Cache should be faster than pipeline"
    print("  ✅ Cache performance test passed")


async def test_cache_invalidation():
    """Test cache invalidation mechanisms"""
    print("\n🧪 Testing cache invalidation...")
    
    trace_system = HSPTraceSystem()
    cache = HSPDecisionCache(trace_system=trace_system, config={
        "policy_version": "1.0.0",
        "hsp_schema_version": "1.0.0"
    })
    
    # Create and store multiple decisions
    decisions_stored = 0
    for i in range(5):
        request = HSPRequestSchema(
            request_id=f"test-{i}",
            trace_id=f"trace-{i}",
            timestamp=datetime.now().isoformat(),
            context={
                "file_content": f"code_{i}",
                "security_level": "medium",
                "code_ownership": "team"
            },
            source="test"
        )
        
        decision = HSPDecision(
            outcome=HSPDecisionOutcome.ALLOW,
            trace_id=f"trace-{i}",
            request_id=f"test-{i}",
            timestamp=datetime.now(),
            reason=f"Decision {i}",
            constraints={},
            metadata={}
        )
        
        await cache.store_decision(request, decision, f"trace-{i}")
        decisions_stored += 1
    
    # Check cache has entries
    stats = cache.get_stats()
    assert stats["stats"]["total_entries"] == decisions_stored
    print(f"  ✓ Stored {decisions_stored} decisions")
    
    # Test policy version invalidation
    invalidated = await cache.invalidate_by_policy_version("2.0.0")
    assert invalidated == decisions_stored
    print(f"  ✓ Policy version change invalidated {invalidated} entries")
    
    # Verify cache is empty
    stats = cache.get_stats()
    assert stats["stats"]["total_entries"] == 0
    print("  ✓ Cache cleared successfully")
    
    # Test file content invalidation
    # Store a decision with specific file content
    file_hash = hashlib.sha256(b"specific_file").hexdigest()
    
    request = HSPRequestSchema(
        request_id="file-test",
        trace_id="trace-file",
        timestamp=datetime.now().isoformat(),
        context={
            "file_content": "specific_file",
            "security_level": "medium",
            "code_ownership": "team"
        },
        source="test"
    )
    
    decision = HSPDecision(
        outcome=HSPDecisionOutcome.ALLOW,
        trace_id="trace-file",
        request_id="file-test",
        timestamp=datetime.now(),
        reason="File-specific decision",
        constraints={},
        metadata={}
    )
    
    await cache.store_decision(request, decision, "trace-file")
    
    # Invalidate by file content
    invalidated = await cache.invalidate_by_file_content(file_hash)
    assert invalidated == 1
    print(f"  ✓ File content change invalidated {invalidated} entry")
    
    print("  ✅ Cache invalidation tests passed")


async def test_cached_middleware_integration():
    """Test cached middleware integration"""
    print("\n🧪 Testing cached middleware integration...")
    
    # Create mock dependencies
    egl_client = MockEGLClient()
    policy_store = MockPolicyStore()
    trace_system = HSPTraceSystem()
    
    # Create cached middleware
    middleware = create_cached_hsp_middleware(
        egl_client=egl_client,
        policy_store=policy_store,
        trace_system=trace_system,
        config={
            "cache": {
                "cache_enabled": True,
                "cache_ttl_seconds": 30,
                "max_cache_entries": 100
            }
        }
    )
    
    # Create mock request
    class MockURL:
        path = '/api/test'
    
    class MockClient:
        host = '127.0.0.1'
    
    class MockRequest:
        method = "POST"
        url = MockURL()
        client = MockClient()
        headers = {"user-agent": "test-client"}
    
    # First request (should be cache miss)
    context1 = {
        "file_content": "print('test')",
        "security_level": "medium",
        "code_ownership": "team",
        "user_id": "user1"
    }
    
    start_time = time.time()
    decision1 = await middleware.intercept_request(MockRequest(), context1)
    first_request_time = (time.time() - start_time) * 1000
    
    # Second request with same context (should be cache hit)
    start_time = time.time()
    decision2 = await middleware.intercept_request(MockRequest(), context1)
    second_request_time = (time.time() - start_time) * 1000
    
    # Verify cache hit improved performance
    assert second_request_time < first_request_time
    speedup = first_request_time / second_request_time
    
    print(f"  ✓ First request: {first_request_time:.2f} ms")
    print(f"  ✓ Second request: {second_request_time:.2f} ms")
    print(f"  ✓ Speedup: {speedup:.1f}x")
    
    # Get cache stats
    stats = middleware.get_cache_stats()
    hit_rate = stats["overall"]["hit_rate"]
    
    print(f"  ✓ Cache hit rate: {hit_rate:.1%}")
    
    # Test cache management
    invalidation_result = await middleware.invalidate_cache("test_invalidation")
    assert invalidation_result["hsp_cache_cleared"] == True
    
    print("  ✅ Cached middleware integration tests passed")


async def test_governance_safety():
    """Test governance safety guarantees"""
    print("\n🧪 Testing governance safety...")
    
    trace_system = HSPTraceSystem()
    cache = HSPDecisionCache(trace_system=trace_system, config={
        "policy_version": "1.0.0",
        "environment": "production"
    })
    
    # Test 1: Different environments should not share cache
    cache_dev = HSPDecisionCache(trace_system=trace_system, config={
        "policy_version": "1.0.0",
        "environment": "development"
    })
    
    # Same request, different environments
    request = HSPRequestSchema(
        request_id="env-test",
        trace_id="trace-env",
        timestamp=datetime.now().isoformat(),
        context={
            "file_content": "same_code",
            "security_level": "medium",
            "code_ownership": "team"
        },
        source="test"
    )
    
    decision = HSPDecision(
        outcome=HSPDecisionOutcome.ALLOW,
        trace_id="trace-env",
        request_id="env-test",
        timestamp=datetime.now(),
        reason="Test decision",
        constraints={},
        metadata={}
    )
    
    # Store in production cache
    await cache.store_decision(request, decision, "trace-env")
    
    # Should not be found in development cache
    dev_decision, dev_status = await cache_dev.get_decision(request, "trace-env")
    assert dev_status == CacheHitStatus.MISS
    print("  ✓ Environment isolation works")
    
    # Test 2: Policy version changes invalidate cache
    await cache.store_decision(request, decision, "trace-env")
    
    # Change policy version
    invalidated = await cache.invalidate_by_policy_version("2.0.0")
    assert invalidated > 0
    
    # Cache should be empty
    stats = cache.get_stats()
    assert stats["stats"]["total_entries"] == 0
    print("  ✓ Policy version changes trigger invalidation")
    
    # Test 3: File content changes invalidate cache
    await cache.store_decision(request, decision, "trace-env")
    
    # Get file hash
    file_hash = hashlib.sha256(b"same_code").hexdigest()
    invalidated = await cache.invalidate_by_file_content(file_hash)
    assert invalidated == 1
    print("  ✓ File content changes trigger invalidation")
    
    # Test 4: Audit trail
    cache.audit_enabled = True
    await cache.store_decision(request, decision, "trace-audit")
    
    assert len(cache.audit_log) > 0
    print(f"  ✓ Audit trail has {len(cache.audit_log)} entries")
    
    print("  ✅ Governance safety tests passed")


async def main():
    """Run all tests"""
    print("=" * 60)
    print("HSP Decision Cache Implementation Tests")
    print("=" * 60)
    
    try:
        await test_cache_key_generation()
        await test_cache_basic_operations()
        await test_cache_performance()
        await test_cache_invalidation()
        await test_cached_middleware_integration()
        await test_governance_safety()
        
        print("\n" + "=" * 60)
        print("✅ ALL TESTS PASSED")
        print("=" * 60)
        
        # Print summary
        print("\n📊 Implementation Summary:")
        print("-" * 40)
        print("✓ Content-addressed caching (file hash based)")
        print("✓ Policy-versioned caching")
        print("✓ Context-aware keys (environment, security level)")
        print("✓ Strict invalidation rules")
        print("✓ Audit trail for governance compliance")
        print("✓ Cache isolation by environment")
        print("✓ Performance monitoring")
        print("✓ Governance safety guarantees")
        
    except AssertionError as e:
        print(f"\n❌ TEST FAILED: {e}")
        import traceback
        traceback.print_exc()
        return 1
    
    return 0


if __name__ == "__main__":
    exit_code = asyncio.run(main())
    exit(exit_code)