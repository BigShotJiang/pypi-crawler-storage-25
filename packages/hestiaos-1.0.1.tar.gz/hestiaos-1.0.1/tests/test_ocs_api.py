#!/usr/bin/env python3
import httpx
import asyncio
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

async def test_ocs_endpoints():
    """Test OCS v1 API endpoints"""
    
    url = "https://cloud.walter-consult.com"
    user = "HestiaOS"
    password = "dF48x-gteDz-a5cfE-qRiCz-GCTct"
    room_token = "6mvoe63h"
    
    headers = {
        "OCS-APIRequest": "true",
        "Accept": "application/json"
    }
    
    async with httpx.AsyncClient(verify=True, timeout=10.0) as client:
        
        # Test 1: Capabilities
        print("Testing /ocs/v1.php/cloud/capabilities...")
        try:
            resp = await client.get(
                f"{url}/ocs/v1.php/cloud/capabilities",
                headers=headers,
                auth=(user, password)
            )
            print(f"  Status: {resp.status_code}")
            if resp.status_code == 200:
                print("  ✅ Capabilities endpoint OK")
            else:
                print(f"  ❌ Error: {resp.text[:100]}")
        except Exception as e:
            print(f"  ❌ Exception: {e}")
        
        # Test 2: Room Info
        print(f"\nTesting /ocs/v1.php/apps/spreed/api/v1/rooms/{room_token}...")
        try:
            resp = await client.get(
                f"{url}/ocs/v1.php/apps/spreed/api/v1/rooms/{room_token}",
                headers=headers,
                auth=(user, password)
            )
            print(f"  Status: {resp.status_code}")
            if resp.status_code == 200:
                print("  ✅ Room endpoint OK")
            else:
                print(f"  ❌ Error: {resp.text[:100]}")
        except Exception as e:
            print(f"  ❌ Exception: {e}")
        
        # Test 3: Chat Messages (Polling)
        print(f"\nTesting /ocs/v1.php/apps/spreed/api/v1/chat/{room_token}...")
        try:
            resp = await client.get(
                f"{url}/ocs/v1.php/apps/spreed/api/v1/chat/{room_token}?lookIntoFuture=0&limit=5",
                headers=headers,
                auth=(user, password)
            )
            print(f"  Status: {resp.status_code}")
            if resp.status_code == 200:
                print("  ✅ Chat polling endpoint OK")
                data = resp.json()
                messages = data.get('ocs', {}).get('data', [])
                print(f"  Messages in room: {len(messages)}")
            else:
                print(f"  ❌ Error: {resp.text[:100]}")
        except Exception as e:
            print(f"  ❌ Exception: {e}")
        
        # Test 4: Send Message
        print(f"\nTesting POST /ocs/v1.php/apps/spreed/api/v1/chat/{room_token}...")
        try:
            resp = await client.post(
                f"{url}/ocs/v1.php/apps/spreed/api/v1/chat/{room_token}",
                headers=headers,
                auth=(user, password),
                json={"message": "ROO Test Message - Task 5 Verification"}
            )
            print(f"  Status: {resp.status_code}")
            if resp.status_code in [200, 201]:
                print("  ✅ Send message endpoint OK")
            else:
                print(f"  ❌ Error: {resp.text[:100]}")
        except Exception as e:
            print(f"  ❌ Exception: {e}")

if __name__ == "__main__":
    asyncio.run(test_ocs_endpoints())