#!/usr/bin/env python3
"""
Test RBAC Permission Management and Validation.
"""

import unittest
import asyncio
from datetime import datetime, timedelta

from core.rbac_system import (
    Role, Permission, RBACManager, UserContext
)


class TestRBACPermissions(unittest.IsolatedAsyncioTestCase):
    """Test RBAC permission management and validation."""
    
    def setUp(self):
        """Set up test environment."""
        self.rbac = RBACManager()
        self.session_ids = []
    
    def tearDown(self):
        """Clean up test sessions."""
        for session_id in self.session_ids:
            if session_id in self.rbac.user_contexts:
                del self.rbac.user_contexts[session_id]
    
    def _create_test_context(self, roles, username="testuser"):
        """Helper to create a test user context."""
        context = self.rbac.create_user_context(
            user_id=f"user_{len(self.session_ids)}",
            username=username,
            roles=roles,
            session_id=f"test_session_{len(self.session_ids)}",
            ttl_hours=1
        )
        self.session_ids.append(context.session_id)
        return context
    
    def test_create_user_context(self):
        """Test creating user contexts with different roles."""
        # Create guest user
        guest_context = self._create_test_context([Role.GUEST], "guest_user")
        self.assertIsNotNone(guest_context)
        self.assertEqual(guest_context.username, "guest_user")
        self.assertIn(Role.GUEST, guest_context.roles)
        self.assertIn(Permission.READ, guest_context.permissions)
        self.assertNotIn(Permission.WRITE, guest_context.permissions)
        
        # Create admin user
        admin_context = self._create_test_context([Role.ADMIN], "admin_user")
        self.assertIn(Role.ADMIN, admin_context.roles)
        self.assertIn(Permission.ADMIN, admin_context.permissions)
        self.assertIn(Permission.MANAGE_USERS, admin_context.permissions)
        
        # Create user with multiple roles
        multi_context = self._create_test_context([Role.VIEWER, Role.OPERATOR], "multi_user")
        self.assertIn(Role.VIEWER, multi_context.roles)
        self.assertIn(Role.OPERATOR, multi_context.roles)
        self.assertIn(Permission.READ, multi_context.permissions)
        self.assertIn(Permission.WRITE, multi_context.permissions)
    
    def test_get_user_context(self):
        """Test retrieving user contexts."""
        context = self._create_test_context([Role.VIEWER])
        session_id = context.session_id
        
        # Should retrieve the context
        retrieved = self.rbac.get_user_context(session_id)
        self.assertIsNotNone(retrieved)
        self.assertEqual(retrieved.session_id, session_id)
        self.assertEqual(retrieved.username, context.username)
        
        # Non-existent session should return None
        self.assertIsNone(self.rbac.get_user_context("non_existent_session"))
    
    def test_get_user_permissions(self):
        """Test getting user permissions."""
        # Guest permissions
        guest_context = self._create_test_context([Role.GUEST])
        guest_perms = self.rbac.get_user_permissions(guest_context.session_id)
        self.assertIn(Permission.READ, guest_perms)
        self.assertIn(Permission.VIEW_LOGS, guest_perms)
        self.assertNotIn(Permission.WRITE, guest_perms)
        
        # Admin permissions
        admin_context = self._create_test_context([Role.ADMIN])
        admin_perms = self.rbac.get_user_permissions(admin_context.session_id)
        self.assertIn(Permission.ADMIN, admin_perms)
        self.assertIn(Permission.MANAGE_USERS, admin_perms)
        self.assertIn(Permission.MANAGE_ROLES, admin_perms)
        
        # Empty permissions for invalid session
        empty_perms = self.rbac.get_user_permissions("invalid_session")
        self.assertEqual(len(empty_perms), 0)
    
    def test_validate_access_basic(self):
        """Test basic access validation."""
        # Guest user - should have READ but not WRITE
        guest_context = self._create_test_context([Role.GUEST])
        
        self.assertTrue(
            self.rbac.validate_access(
                guest_context.session_id,
                Permission.READ
            )
        )
        
        self.assertFalse(
            self.rbac.validate_access(
                guest_context.session_id,
                Permission.WRITE
            )
        )
        
        # Admin user - should have all permissions
        admin_context = self._create_test_context([Role.ADMIN])
        
        self.assertTrue(
            self.rbac.validate_access(
                admin_context.session_id,
                Permission.READ
            )
        )
        
        self.assertTrue(
            self.rbac.validate_access(
                admin_context.session_id,
                Permission.WRITE
            )
        )
        
        self.assertTrue(
            self.rbac.validate_access(
                admin_context.session_id,
                Permission.ADMIN
            )
        )
    
    def test_validate_access_with_resource(self):
        """Test access validation with resource specification."""
        viewer_context = self._create_test_context([Role.VIEWER])
        
        # Should work without resource
        self.assertTrue(
            self.rbac.validate_access(
                viewer_context.session_id,
                Permission.READ
            )
        )
        
        # Should also work with resource (no policies to block)
        self.assertTrue(
            self.rbac.validate_access(
                viewer_context.session_id,
                Permission.READ,
                resource="/api/data"
            )
        )
    
    def test_validate_access_invalid_session(self):
        """Test access validation with invalid session."""
        self.assertFalse(
            self.rbac.validate_access(
                "invalid_session_id",
                Permission.READ
            )
        )
        
        self.assertFalse(
            self.rbac.validate_access(
                "",
                Permission.READ
            )
        )
        
        self.assertFalse(
            self.rbac.validate_access(
                None,
                Permission.READ
            )
        )
    
    def test_session_expiration_access(self):
        """Test that expired sessions cannot access resources."""
        # Create a context with very short TTL
        context = self.rbac.create_user_context(
            user_id="expiring_user",
            username="expiring",
            roles=[Role.VIEWER],
            session_id="expiring_session",
            ttl_hours=0.0001  # ~0.36 seconds
        )
        
        # Immediately should work
        self.assertTrue(
            self.rbac.validate_access(
                "expiring_session",
                Permission.READ
            )
        )
        
        # Wait for expiration
        import time
        time.sleep(0.5)  # Wait for expiration
        
        # Should no longer work
        self.assertFalse(
            self.rbac.validate_access(
                "expiring_session",
                Permission.READ
            )
        )
        
        # Context should be removed from manager
        self.assertIsNone(self.rbac.get_user_context("expiring_session"))
    
    def test_cleanup_expired_sessions(self):
        """Test cleanup of expired sessions."""
        # Create multiple sessions
        sessions = []
        for i in range(5):
            context = self.rbac.create_user_context(
                user_id=f"user_{i}",
                username=f"user_{i}",
                roles=[Role.VIEWER],
                session_id=f"session_{i}",
                ttl_hours=0 if i % 2 == 0 else 1  # Half expire immediately
            )
            sessions.append(context.session_id)
        
        # Manually expire some sessions
        for i, session_id in enumerate(sessions):
            if i % 2 == 0:  # Even indices expire immediately
                context = self.rbac.user_contexts[session_id]
                context.expires_at = datetime.now() - timedelta(hours=1)
        
        # Count before cleanup
        initial_count = len(self.rbac.user_contexts)
        
        # Run cleanup
        self.rbac.cleanup_expired_sessions()
        
        # Count after cleanup
        final_count = len(self.rbac.user_contexts)
        
        # Should have removed expired sessions
        self.assertLess(final_count, initial_count)
        self.assertEqual(final_count, 2)  # 2 non-expired sessions (1 and 3)
    
    def test_multiple_roles_permissions(self):
        """Test that users with multiple roles get union of permissions."""
        context = self._create_test_context([Role.GUEST, Role.OPERATOR])
        
        # Should have GUEST permissions
        self.assertTrue(
            self.rbac.validate_access(
                context.session_id,
                Permission.READ
            )
        )
        
        self.assertTrue(
            self.rbac.validate_access(
                context.session_id,
                Permission.VIEW_LOGS
            )
        )
        
        # Should have OPERATOR permissions
        self.assertTrue(
            self.rbac.validate_access(
                context.session_id,
                Permission.WRITE
            )
        )
        
        self.assertTrue(
            self.rbac.validate_access(
                context.session_id,
                Permission.EXECUTE
            )
        )
        
        # Should NOT have ADMIN permissions
        self.assertFalse(
            self.rbac.validate_access(
                context.session_id,
                Permission.ADMIN
            )
        )
    
    async def test_async_validate_access(self):
        """Test async access validation."""
        context = self._create_test_context([Role.VIEWER])
        
        # Should work for valid permission
        result = await self.rbac.async_validate_access(
            context.session_id,
            Permission.READ
        )
        self.assertTrue(result)
        
        # Should fail for invalid permission
        result = await self.rbac.async_validate_access(
            context.session_id,
            Permission.ADMIN
        )
        self.assertFalse(result)
    
    def test_permission_enum_completeness(self):
        """Test that permission enum covers all required operations."""
        required_permissions = [
            "read", "write", "execute", "delete", "admin",
            "configure", "audit", "manage_users", "manage_roles",
            "manage_plugins", "manage_models", "start_stop",
            "backup_restore", "view_logs", "view_metrics",
            "view_consciousness", "modify_consciousness", "evolve_consciousness",
            "execute_tools", "manage_tools", "api_read", "api_write", "api_admin"
        ]
        
        for perm_name in required_permissions:
            try:
                perm = Permission(perm_name)
                self.assertIsNotNone(perm)
            except ValueError:
                self.fail(f"Missing required permission: {perm_name}")


if __name__ == "__main__":
    unittest.main()