#!/usr/bin/env python3
"""
Test script for PostgreSQL persistence implementation.
Validates that the 3-layer memory system's short-term memory (PostgreSQL)
is properly integrated and functional.
"""

import asyncio
import sys
import os
from datetime import datetime

# Add project root to path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

async def test_database_connection():
    """Test database connection and basic operations."""
    print("🧪 Testing PostgreSQL Database Connection...")
    
    try:
        from core.persistence.database import get_database_manager, initialize_database
        
        # Initialize database
        print("  Initializing database connection...")
        success = initialize_database()
        
        if not success:
            print("  ❌ Database initialization failed")
            return False
        
        # Get database manager
        db_manager = get_database_manager()
        
        # Test connection
        print("  Testing database connection...")
        connection_ok = db_manager.test_connection()
        
        if not connection_ok:
            print("  ❌ Database connection test failed")
            return False
        
        # Get health status
        print("  Getting database health status...")
        health = db_manager.health_check()
        
        print(f"  ✅ Database connection successful")
        print(f"  Status: {health.get('status', 'unknown')}")
        print(f"  PostgreSQL Version: {health.get('postgres_version', 'unknown')}")
        
        return True
        
    except Exception as e:
        print(f"  ❌ Database connection test failed with error: {e}")
        return False

async def test_user_manager():
    """Test UserManager with PostgreSQL persistence."""
    print("\n🧪 Testing UserManager (PostgreSQL Persistence)...")
    
    try:
        from auth.jwt import UserManager, get_user_manager
        from auth.jwt import UserRole
        
        # Get user manager
        user_manager = get_user_manager()
        
        # Test database status
        print("  Checking UserManager database status...")
        if hasattr(user_manager, 'get_database_status'):
            status = user_manager.get_database_status()
            print(f"  Database available: {status.get('database_available', 'unknown')}")
        
        # Create test user
        print("  Creating test user...")
        test_username = f"test_user_{int(datetime.now().timestamp())}"
        test_password = "test_password_123"
        
        user = user_manager.create_user(
            username=test_username,
            password=test_password,
            tenant_id="test_tenant",
            role=UserRole.USER
        )
        
        if not user:
            print("  ❌ User creation failed")
            return False
        
        print(f"  ✅ User created: {user.get('username')} ({user.get('user_id')})")
        
        # Authenticate user
        print("  Authenticating test user...")
        auth_user = user_manager.authenticate_user(test_username, test_password)
        
        if not auth_user:
            print("  ❌ User authentication failed")
            return False
        
        print(f"  ✅ User authenticated: {auth_user.get('username')}")
        
        # Get user by ID
        print("  Getting user by ID...")
        user_by_id = user_manager.get_user_by_id(user.get('user_id'))
        
        if not user_by_id:
            print("  ❌ Get user by ID failed")
            return False
        
        print(f"  ✅ User retrieved: {user_by_id.get('username')}")
        
        # Update user role
        print("  Updating user role...")
        updated_user = user_manager.update_user_role(user.get('user_id'), UserRole.ADMIN)
        
        if not updated_user:
            print("  ❌ User role update failed")
            return False
        
        print(f"  ✅ User role updated to: {updated_user.get('role')}")
        
        # List users
        print("  Listing all users...")
        users = user_manager.list_users()
        
        if not isinstance(users, list):
            print("  ❌ User listing failed")
            return False
        
        print(f"  ✅ Found {len(users)} users")
        
        # Cleanup (optional - comment out to keep test data)
        # Note: UserManager.delete_user method would need to be implemented
        
        return True
        
    except Exception as e:
        print(f"  ❌ UserManager test failed with error: {e}")
        import traceback
        traceback.print_exc()
        return False

async def test_user_config_manager():
    """Test UserConfigManager with PostgreSQL persistence."""
    print("\n🧪 Testing UserConfigManager (PostgreSQL Persistence)...")
    
    try:
        from auth.user_config import UserConfigManager, get_user_config_manager, UserConfigSchema
        from auth.user_config import ModelPreference
        
        # Get config manager
        config_manager = get_user_config_manager()
        
        # Test database status
        print("  Checking UserConfigManager database status...")
        if hasattr(config_manager, 'get_database_status'):
            status = config_manager.get_database_status()
            print(f"  Database available: {status.get('database_available', 'unknown')}")
        
        # Create test user ID
        test_user_id = f"test_user_config_{int(datetime.now().timestamp())}"
        
        # Get config (should create default)
        print("  Getting user config (should create default)...")
        config = config_manager.get_config(test_user_id)
        
        if not isinstance(config, UserConfigSchema):
            print("  ❌ Get config failed")
            return False
        
        print(f"  ✅ Default config created: preferred_model={config.preferred_model}")
        
        # Update config
        print("  Updating user config...")
        updates = {
            "preferred_model": ModelPreference.EXPERT_GPU,
            "temperature": 0.8,
            "enable_streaming": True
        }
        
        updated_config = config_manager.update_config(test_user_id, updates)
        
        if not isinstance(updated_config, UserConfigSchema):
            print("  ❌ Config update failed")
            return False
        
        print(f"  ✅ Config updated: preferred_model={updated_config.preferred_model}, temperature={updated_config.temperature}")
        
        # Set complete config
        print("  Setting complete config...")
        new_config = UserConfigSchema(
            preferred_model=ModelPreference.MEDIATOR,
            temperature=0.5,
            enable_reasoning_display=True,
            max_response_tokens=4096
        )
        
        set_config = config_manager.set_config(test_user_id, new_config)
        
        if not isinstance(set_config, UserConfigSchema):
            print("  ❌ Set config failed")
            return False
        
        print(f"  ✅ Complete config set: preferred_model={set_config.preferred_model}, max_tokens={set_config.max_response_tokens}")
        
        # List configs
        print("  Listing user configs...")
        configs = config_manager.list_users_with_configs()
        
        if not isinstance(configs, list):
            print("  ❌ Config listing failed")
            return False
        
        print(f"  ✅ Found {len(configs)} user configs")
        
        # Export/Import config
        print("  Testing config export/import...")
        export_json = config_manager.export_config(test_user_id)
        
        if not export_json or not isinstance(export_json, str):
            print("  ❌ Config export failed")
            return False
        
        print(f"  ✅ Config exported ({len(export_json)} bytes)")
        
        # Delete config
        print("  Deleting user config...")
        delete_success = config_manager.delete_config(test_user_id)
        
        if not delete_success:
            print("  ❌ Config deletion failed")
            return False
        
        print(f"  ✅ Config deleted for user: {test_user_id}")
        
        return True
        
    except Exception as e:
        print(f"  ❌ UserConfigManager test failed with error: {e}")
        import traceback
        traceback.print_exc()
        return False

async def test_migration_system():
    """Test database migration system."""
    print("\n🧪 Testing Migration System...")
    
    try:
        from core.persistence.migrations import MigrationManager
        
        # Create migration manager
        migration_manager = MigrationManager()
        
        # Get database status
        print("  Getting database migration status...")
        status = migration_manager.get_database_status()
        
        if not isinstance(status, dict):
            print("  ❌ Failed to get migration status")
            return False
        
        print(f"  ✅ Migration status retrieved")
        print(f"  Applied migrations: {status.get('migrations', {}).get('applied', 0)}")
        
        # Check table counts
        tables = status.get('tables', {})
        for table_name, count in tables.items():
            print(f"  Table {table_name}: {count}")
        
        return True
        
    except Exception as e:
        print(f"  ❌ Migration system test failed with error: {e}")
        return False

async def test_admin_api_endpoints():
    """Test Admin Console API endpoints (simulated)."""
    print("\n🧪 Testing Admin Console API Endpoints (Simulated)...")
    
    try:
        # Note: This is a simulation since we can't easily test FastAPI endpoints
        # without running the server. We'll test the underlying managers instead.
        
        from auth.jwt import get_user_manager
        from auth.user_config import get_user_config_manager
        
        user_manager = get_user_manager()
        config_manager = get_user_config_manager()
        
        # Simulate API operations
        print("  Simulating admin API operations...")
        
        # 1. Create user (simulated)
        test_username = f"api_test_user_{int(datetime.now().timestamp())}"
        user = user_manager.create_user(
            username=test_username,
            password="api_test_pass",
            tenant_id="api_test",
            role="user"
        )
        
        if not user:
            print("  ❌ Simulated user creation failed")
            return False
        
        user_id = user.get('user_id')
        print(f"  ✅ Simulated user creation: {user_id}")
        
        # 2. Update user config (simulated)
        config = config_manager.get_config(user_id)
        if not config:
            print("  ❌ Simulated config retrieval failed")
            return False
        
        print(f"  ✅ Simulated config retrieval for user: {user_id}")
        
        # 3. List users (simulated)
        users = user_manager.list_users()
        if not isinstance(users, list):
            print("  ❌ Simulated user listing failed")
            return False
        
        print(f"  ✅ Simulated user listing: {len(users)} users")
        
        # 4. List configs (simulated)
        configs = config_manager.list_users_with_configs()
        if not isinstance(configs, list):
            print("  ❌ Simulated config listing failed")
            return False
        
        print(f"  ✅ Simulated config listing: {len(configs)} configs")
        
        return True
        
    except Exception as e:
        print(f"  ❌ Admin API simulation failed with error: {e}")
        return False

async def run_comprehensive_test():
    """Run all PostgreSQL persistence tests."""
    print("=" * 70)
    print("🚀 COMPREHENSIVE POSTGRESQL PERSISTENCE TEST SUITE")
    print("=" * 70)
    print(f"Test started at: {datetime.now().isoformat()}")
    print()
    
    test_results = []
    
    # Run all tests
    test_results.append(("Database Connection", await test_database_connection()))
    test_results.append(("User Manager", await test_user_manager()))
    test_results.append(("User Config Manager", await test_user_config_manager()))
    test_results.append(("Migration System", await test_migration_system()))
    test_results.append(("Admin API Endpoints", await test_admin_api_endpoints()))
    
    # Print summary
    print("\n" + "=" * 70)
    print("📊 TEST SUMMARY")
    print("=" * 70)
    
    passed = 0
    total = len(test_results)
    
    for test_name, result in test_results:
        status = "✅ PASS" if result else "❌ FAIL"
        print(f"{status} - {test_name}")
        if result:
            passed += 1
    
    print(f"\n📈 Results: {passed}/{total} tests passed ({passed/total*100:.1f}%)")
    
    if passed == total:
        print("\n🎉 ALL TESTS PASSED! PostgreSQL persistence is fully functional.")
        print("   The 3-layer memory system's short-term memory (PostgreSQL) is operational.")
        return True
    else:
        print(f"\n⚠️  {total - passed} test(s) failed. Review the output above.")
        return False

if __name__ == "__main__":
    # Run tests
    success = asyncio.run(run_comprehensive_test())
    
    # Exit with appropriate code
    sys.exit(0 if success else 1)