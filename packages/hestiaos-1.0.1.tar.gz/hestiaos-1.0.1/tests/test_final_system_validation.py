#!/usr/bin/env python3
"""Final system validation test for HestiaOS output sanitization."""

import sys
import json
import requests
import time

def test_api_with_reasoning_filtering():
    """Test the API with a message that triggers reasoning."""
    print("Testing API with reasoning filtering...")
    
    # Test message that should trigger reasoning
    test_message = "Hallo, wie geht es dir?"
    
    try:
        response = requests.post(
            "http://localhost:8000/api/chat",
            json={
                "message": test_message,
                "session_id": "test_session_final",
                "mode": "expert"
            },
            timeout=30
        )
        
        if response.status_code == 200:
            data = response.json()
            print(f"API Response status: {response.status_code}")
            print(f"Response received: {len(data.get('response', ''))} characters")
            
            # Check if response contains reasoning markers
            response_text = data.get('response', '')
            
            # These should NOT be in the final response
            reasoning_indicators = [
                "<think>",
                "</think>",
                "Okay, the user",
                "I need to respond",
                "Since the user is speaking",
                "Let me think",
                "Thinking:"
            ]
            
            found_reasoning = False
            for indicator in reasoning_indicators:
                if indicator.lower() in response_text.lower():
                    print(f"⚠️  Warning: Found reasoning indicator in response: {indicator}")
                    found_reasoning = True
            
            if not found_reasoning:
                print("✅ No reasoning markers found in API response")
            
            # Check if response is reasonable length (not empty)
            if len(response_text.strip()) > 10:
                print(f"✅ Response is reasonable length: {len(response_text.strip())} characters")
                print(f"✅ Response preview: {response_text[:100]}...")
            else:
                print(f"⚠️  Response might be too short: {len(response_text.strip())} characters")
            
            return True
        else:
            print(f"❌ API returned status code: {response.status_code}")
            print(f"Response: {response.text}")
            return False
            
    except Exception as e:
        print(f"❌ API test failed: {e}")
        return False

def test_output_filter_directly():
    """Test the OutputFilter directly with various inputs."""
    print("\n" + "="*80)
    print("Testing OutputFilter directly...")
    
    try:
        from core.output_filter import OutputFilter
        from core.contracts.response_contract import OutputChannel
        
        test_cases = [
            {
                "name": "XML reasoning with German answer",
                "input": '''<think>
Okay, the user said "hallo". I should respond in German.
Hallo! Ich bin hier um zu helfen.
</think>''',
                "expected_contains": ["Hallo! Ich bin hier um zu helfen"],
                "expected_not_contains": ["<think>", "Okay, the user"]
            },
            {
                "name": "Informal reasoning",
                "input": '''Okay, let me think about this. The user is asking in German.
Hallo! Wie kann ich helfen?''',
                "expected_contains": ["Hallo! Wie kann ich helfen"],
                "expected_not_contains": ["Okay, let me think"]
            },
            {
                "name": "Simple greeting",
                "input": "Guten Tag! Was kann ich für Sie tun?",
                "expected_contains": ["Guten Tag! Was kann ich für Sie tun"],
                "expected_not_contains": []
            }
        ]
        
        all_passed = True
        output_filter = OutputFilter(debug_mode=False, strict_mode=True)
        
        for test_case in test_cases:
            print(f"\nTest: {test_case['name']}")
            contract = output_filter.filter(test_case['input'])
            response = contract.get_channel(OutputChannel.RESPONSE)
            
            if response:
                print(f"  Response: {response[:80]}...")
                
                # Check expected content
                for expected in test_case['expected_contains']:
                    if expected in response:
                        print(f"  ✅ Contains expected: '{expected}'")
                    else:
                        print(f"  ❌ Missing expected: '{expected}'")
                        all_passed = False
                
                # Check for unwanted content
                for not_expected in test_case['expected_not_contains']:
                    if not_expected in response:
                        print(f"  ❌ Contains unwanted: '{not_expected}'")
                        all_passed = False
                    else:
                        print(f"  ✅ No unwanted: '{not_expected}'")
            else:
                print(f"  ❌ No response generated")
                all_passed = False
        
        if all_passed:
            print("\n✅ All OutputFilter tests passed")
        else:
            print("\n❌ Some OutputFilter tests failed")
            
        return all_passed
        
    except Exception as e:
        print(f"❌ OutputFilter test failed: {e}")
        import traceback
        traceback.print_exc()
        return False

def test_phase9_validation_suite():
    """Run the Phase 9 validation suite."""
    print("\n" + "="*80)
    print("Running Phase 9.0 Validation Suite...")
    
    try:
        import subprocess
        result = subprocess.run(
            ["python3", "-m", "pytest", "tests/test_phase9_validation_suite.py", "-v", "--tb=short"],
            capture_output=True,
            text=True,
            cwd="."
        )
        
        print(f"Exit code: {result.returncode}")
        
        # Count passed tests
        lines = result.stdout.split('\n')
        passed_count = sum(1 for line in lines if "PASSED" in line)
        failed_count = sum(1 for line in lines if "FAILED" in line or "ERROR" in line)
        
        print(f"Tests passed: {passed_count}")
        print(f"Tests failed: {failed_count}")
        
        if result.returncode == 0:
            print("✅ Phase 9.0 Validation Suite passed")
            return True
        else:
            print("❌ Phase 9.0 Validation Suite failed")
            # Print last few lines for context
            print("\nLast 20 lines of output:")
            for line in lines[-20:]:
                print(line)
            return False
            
    except Exception as e:
        print(f"❌ Failed to run validation suite: {e}")
        return False

def main():
    """Main validation function."""
    print("="*80)
    print("HESTIAOS FINAL SYSTEM VALIDATION")
    print("="*80)
    
    all_tests_passed = True
    
    # Test 1: Phase 9 validation suite
    if not test_phase9_validation_suite():
        all_tests_passed = False
    
    # Test 2: OutputFilter directly
    if not test_output_filter_directly():
        all_tests_passed = False
    
    # Test 3: API integration
    if not test_api_with_reasoning_filtering():
        all_tests_passed = False
    
    print("\n" + "="*80)
    if all_tests_passed:
        print("✅ ALL SYSTEM VALIDATION TESTS PASSED")
        print("HestiaOS output sanitization is fully operational.")
    else:
        print("❌ SOME TESTS FAILED")
        print("System validation incomplete.")
    print("="*80)
    
    return 0 if all_tests_passed else 1

if __name__ == "__main__":
    sys.exit(main())