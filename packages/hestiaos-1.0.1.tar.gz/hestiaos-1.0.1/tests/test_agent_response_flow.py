import httpx
import json

API_URL = "http://localhost:8000/chat"

def test_greeting_response():
    """Verify that '@hestia hallo' returns a greeting, not a tool list."""
    payload = {
        "message": "@hestia hallo",
        "session_id": "test_greeting"
    }
    print(f"Sending: {payload['message']}...")
    response = httpx.post(API_URL, json=payload, timeout=60.0)
    assert response.status_code == 200
    data = response.json()
    content = data.get("response", "").lower()
    print(f"Response: {content[:100]}...")
    
    # Assertions
    assert content != ""
    assert "lade tool-liste" not in content
    assert "ich habe zugriff auf folgende tools" not in content
    # A greeting should be somewhat concise (less than 1000 chars usually)
    assert len(content) < 1000

def test_capabilities_response():
    """Verify that asking about capabilities returns a meaningful AI response."""
    payload = {
        "message": "@hestia was kannst du?",
        "session_id": "test_capabilities"
    }
    print(f"Sending: {payload['message']}...")
    response = httpx.post(API_URL, json=payload, timeout=60.0)
    assert response.status_code == 200
    data = response.json()
    content = data.get("response", "").lower()
    print(f"Response: {content[:100]}...")
    
    # It should not JUST be the tool list, but a conversational response
    assert content != ""
    assert "lade tool-liste" not in content
    # It can mention tools, but it should be a response
    assert len(content.split()) > 5 

if __name__ == "__main__":
    # If run directly, run the tests
    import sys
    try:
        print("Running greeting test...")
        test_greeting_response()
        print("✅ Greeting test passed!")
        
        print("Running capabilities test...")
        test_capabilities_response()
        print("✅ Capabilities test passed!")
    except Exception as e:
        print(f"❌ Test failed: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)
