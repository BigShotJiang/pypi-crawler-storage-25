import pytest
import asyncio
from unittest.mock import patch, MagicMock
from scripts.issue_watcher import IssueWatcher

@pytest.fixture
def watcher():
    return IssueWatcher()

@pytest.mark.asyncio
async def test_poll_issues_dry_run(watcher):
    # Mocking the poll_issues method directly to test processing logic isolation
    with patch.object(watcher, "poll_issues", new_callable=MagicMock) as mock_poll:
        # Erzeuge eine asynchrone Rückgabe (Future), auf die Pytest "awaiten" kann
        f = asyncio.Future()
        f.set_result([{"iid": 99, "title": "Test Bug", "description": "Lösche uvloop"}])
        mock_poll.return_value = f
        
        issues = await watcher.poll_issues()
        assert len(issues) == 1
        assert issues[0]["iid"] == 99
        assert issues[0]["iid"] == 99

def test_simulate_auto_fix_uvloop(watcher):
    # Testet die Heuristik
    success = watcher.simulate_auto_fix("Bitte uvloop fixen im Venv")
    assert success is True
    
def test_simulate_auto_fix_unknown(watcher):
    # Testet unbekannten Context
    success = watcher.simulate_auto_fix("Bitte den Algorithmus optimieren")
    assert success is False
