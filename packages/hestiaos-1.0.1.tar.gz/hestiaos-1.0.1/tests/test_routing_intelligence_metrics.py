"""
CI-CRT-036: Routing Intelligence Metrics — Tests.

Testet den RoutingMetricsCollector:
1. Event Bus Subscription: subscribe/unsubscribe
2. Decision Counting: routing_decisions_total
3. Fallback Counting: routing_fallback_total
4. No-Backend Counting: routing_no_backend_total
5. Health Score Metriken: set_health_score(), set_all_health_scores()
6. Policy Score Metriken: set_policy_score()
7. Prometheus Export: generate_prometheus_metrics()
8. Global Singleton: get_routing_metrics(), reset_routing_metrics()
"""

import pytest
from unittest.mock import AsyncMock, patch, MagicMock

from core.routing_intelligence.metrics import (
    RoutingMetricsCollector,
    get_routing_metrics,
    reset_routing_metrics,
)
from core.backend.router_base import EVENT_ROUTING_DECISION


# ============================================================================
# RoutingMetricsCollector
# ============================================================================


class TestRoutingMetricsCollector:
    """Tests für den RoutingMetricsCollector."""

    def setup_method(self):
        self.collector = RoutingMetricsCollector()

    # ------------------------------------------------------------------
    # Event Bus Subscription
    # ------------------------------------------------------------------

    def test_subscribe_to_events(self):
        """subscribe_to_events() registriert Handler am Event Bus."""
        import sys
        from unittest.mock import MagicMock

        mock_event_bus = MagicMock()
        mock_event_bus.subscribe = MagicMock()
        mock_event_bus_module = MagicMock()
        mock_event_bus_module.event_bus = mock_event_bus
        sys.modules["core.event_bus"] = mock_event_bus_module

        try:
            self.collector.subscribe_to_events()
            mock_event_bus.subscribe.assert_called_once_with(
                EVENT_ROUTING_DECISION, self.collector._event_handler
            )
        finally:
            sys.modules.pop("core.event_bus", None)

    def test_unsubscribe_from_events(self):
        """unsubscribe_from_events() entfernt Handler."""
        import sys
        from unittest.mock import MagicMock

        mock_event_bus = MagicMock()
        mock_event_bus.subscribe = MagicMock()
        mock_event_bus.unsubscribe = MagicMock()
        mock_event_bus_module = MagicMock()
        mock_event_bus_module.event_bus = mock_event_bus
        sys.modules["core.event_bus"] = mock_event_bus_module

        try:
            self.collector.subscribe_to_events()
            self.collector.unsubscribe_from_events()
            mock_event_bus.unsubscribe.assert_called_once()
        finally:
            sys.modules.pop("core.event_bus", None)

    # ------------------------------------------------------------------
    # Decision Counting
    # ------------------------------------------------------------------

    @pytest.mark.asyncio
    async def test_handle_routing_decision_counts(self):
        """RoutingDecision-Event wird korrekt gezählt."""
        await self.collector._handle_routing_decision({
            "selected_backend": "expert_gpu",
            "mode": "business",
            "reason": "preferred_backend_healthy",
            "fallback_used": False,
            "fallback_chain": [],
        })

        key = "expert_gpu|business|preferred_backend_healthy"
        assert self.collector._decision_counts[key] == 1

    @pytest.mark.asyncio
    async def test_multiple_decisions_counted(self):
        """Mehrere Entscheidungen werden korrekt hochgezählt."""
        for i in range(5):
            await self.collector._handle_routing_decision({
                "selected_backend": "gpu",
                "mode": "business",
                "reason": "preferred_backend_healthy",
                "fallback_used": False,
                "fallback_chain": [],
            })

        key = "gpu|business|preferred_backend_healthy"
        assert self.collector._decision_counts[key] == 5

    @pytest.mark.asyncio
    async def test_different_backends_separate_counts(self):
        """Verschiedene Backends haben separate Counter."""
        await self.collector._handle_routing_decision({
            "selected_backend": "gpu_a",
            "mode": "business",
            "reason": "preferred_backend_healthy",
            "fallback_used": False,
            "fallback_chain": [],
        })
        await self.collector._handle_routing_decision({
            "selected_backend": "gpu_b",
            "mode": "business",
            "reason": "preferred_backend_healthy",
            "fallback_used": False,
            "fallback_chain": [],
        })

        assert self.collector._decision_counts["gpu_a|business|preferred_backend_healthy"] == 1
        assert self.collector._decision_counts["gpu_b|business|preferred_backend_healthy"] == 1

    # ------------------------------------------------------------------
    # Fallback Counting
    # ------------------------------------------------------------------

    @pytest.mark.asyncio
    async def test_fallback_counted(self):
        """Fallback-Ereignis wird gezählt."""
        await self.collector._handle_routing_decision({
            "selected_backend": "fallback_cpu",
            "mode": "business",
            "reason": "fallback_backend_selected",
            "fallback_used": True,
            "fallback_chain": ["preferred_gpu", "community_cpu"],
        })

        key = "business|preferred_gpu,community_cpu"
        assert self.collector._fallback_counts[key] == 1

    @pytest.mark.asyncio
    async def test_no_fallback_not_counted(self):
        """Ohne Fallback wird kein Fallback-Counter erhöht."""
        await self.collector._handle_routing_decision({
            "selected_backend": "gpu",
            "mode": "business",
            "reason": "preferred_backend_healthy",
            "fallback_used": False,
            "fallback_chain": [],
        })

        assert len(self.collector._fallback_counts) == 0

    # ------------------------------------------------------------------
    # No-Backend Counting
    # ------------------------------------------------------------------

    @pytest.mark.asyncio
    async def test_no_backend_counted(self):
        """Kein-Backend-Ereignis wird gezählt."""
        await self.collector._handle_routing_decision({
            "selected_backend": None,
            "mode": "business",
            "reason": "no_healthy_backend",
            "fallback_used": True,
            "fallback_chain": ["gpu1", "gpu2"],
        })

        assert self.collector._no_backend_counts["business"] == 1

    @pytest.mark.asyncio
    async def test_no_backend_none_string(self):
        """selected_backend='none' wird auch als 'kein Backend' gezählt."""
        await self.collector._handle_routing_decision({
            "selected_backend": "none",
            "mode": "science",
            "reason": "no_backends_for_mode",
            "fallback_used": False,
            "fallback_chain": [],
        })

        assert self.collector._no_backend_counts["science"] == 1

    # ------------------------------------------------------------------
    # Health Score Metriken
    # ------------------------------------------------------------------

    def test_set_health_score(self):
        """set_health_score() setzt einen Score für ein Backend."""
        self.collector.set_health_score("gpu_a", "weighted", 0.85)
        assert self.collector._health_scores["gpu_a"]["weighted"] == 0.85

    def test_set_all_health_scores(self):
        """set_all_health_scores() setzt mehrere Scores."""
        scores = {
            "gpu_a": {"weighted": 0.85, "availability": 0.9},
            "gpu_b": {"weighted": 0.45, "availability": 0.5},
        }
        self.collector.set_all_health_scores(scores)
        assert self.collector._health_scores["gpu_a"]["weighted"] == 0.85
        assert self.collector._health_scores["gpu_b"]["weighted"] == 0.45

    # ------------------------------------------------------------------
    # Policy Score Metriken
    # ------------------------------------------------------------------

    def test_set_policy_score(self):
        """set_policy_score() setzt einen Policy-Score."""
        self.collector.set_policy_score("balanced", 0.75)
        assert self.collector._policy_scores["balanced"] == 0.75

    # ------------------------------------------------------------------
    # Prometheus Export
    # ------------------------------------------------------------------

    @pytest.mark.asyncio
    async def test_generate_prometheus_metrics_empty(self):
        """generate_prometheus_metrics() ohne Daten."""
        output = self.collector.generate_prometheus_metrics()
        assert isinstance(output, str)
        assert "hestia_routing_decisions_total" in output
        assert "hestia_routing_fallback_total" in output
        assert "hestia_routing_no_backend_total" in output
        assert "hestia_backend_health_score" in output
        assert "hestia_routing_policy_score" in output

    @pytest.mark.asyncio
    async def test_generate_prometheus_metrics_with_data(self):
        """generate_prometheus_metrics() mit Daten."""
        await self.collector._handle_routing_decision({
            "selected_backend": "expert_gpu",
            "mode": "business",
            "reason": "preferred_backend_healthy",
            "fallback_used": False,
            "fallback_chain": [],
        })
        self.collector.set_health_score("expert_gpu", "weighted", 0.85)
        self.collector.set_policy_score("balanced", 0.75)

        output = self.collector.generate_prometheus_metrics()

        # Prüfe dass die Metriken im Output sind
        assert 'hestia_routing_decisions_total{backend="expert_gpu",mode="business",reason="preferred_backend_healthy"} 1' in output
        assert 'hestia_backend_health_score{backend="expert_gpu",score_type="weighted"} 0.85' in output
        assert 'hestia_routing_policy_score{policy="balanced"} 0.75' in output

    @pytest.mark.asyncio
    async def test_prometheus_format_help_lines(self):
        """Prometheus-Output enthält HELP und TYPE Lines."""
        output = self.collector.generate_prometheus_metrics()
        lines = output.split("\n")

        help_lines = [l for l in lines if l.startswith("# HELP")]
        type_lines = [l for l in lines if l.startswith("# TYPE")]

        assert len(help_lines) == 5
        assert len(type_lines) == 5

    # ------------------------------------------------------------------
    # Reset
    # ------------------------------------------------------------------

    def test_reset(self):
        """reset() setzt alle Metriken zurück."""
        self.collector.set_health_score("gpu", "weighted", 0.85)
        self.collector.set_policy_score("balanced", 0.75)
        self.collector.reset()

        assert len(self.collector._decision_counts) == 0
        assert len(self.collector._fallback_counts) == 0
        assert len(self.collector._no_backend_counts) == 0
        assert len(self.collector._health_scores) == 0
        assert len(self.collector._policy_scores) == 0

    # ------------------------------------------------------------------
    # Summary
    # ------------------------------------------------------------------

    @pytest.mark.asyncio
    async def test_get_metrics_summary(self):
        """get_metrics_summary() gibt alle Metriken zurück."""
        await self.collector._handle_routing_decision({
            "selected_backend": "gpu",
            "mode": "business",
            "reason": "preferred_backend_healthy",
            "fallback_used": False,
            "fallback_chain": [],
        })
        self.collector.set_health_score("gpu", "weighted", 0.85)

        summary = self.collector.get_metrics_summary()
        assert "decision_counts" in summary
        assert "health_scores" in summary
        assert "timestamp" in summary
        assert summary["health_scores"]["gpu"]["weighted"] == 0.85


# ============================================================================
# Global Singleton
# ============================================================================


class TestMetricsSingleton:
    """Tests für das globale Singleton."""

    def setup_method(self):
        reset_routing_metrics()

    def test_get_routing_metrics_returns_instance(self):
        """get_routing_metrics() gibt eine RoutingMetricsCollector-Instanz zurück."""
        collector = get_routing_metrics()
        assert isinstance(collector, RoutingMetricsCollector)

    def test_get_routing_metrics_singleton(self):
        """get_routing_metrics() gibt immer dieselbe Instanz zurück."""
        c1 = get_routing_metrics()
        c2 = get_routing_metrics()
        assert c1 is c2

    def test_reset_routing_metrics(self):
        """reset_routing_metrics() setzt die Instanz zurück."""
        c1 = get_routing_metrics()
        reset_routing_metrics()
        c2 = get_routing_metrics()
        assert c1 is not c2
