#!/usr/bin/env python3
"""Test German reasoning detection and filtering."""

import sys
sys.path.insert(0, '.')

from core.output_filter import OutputFilter
from core.processing.response_processor import ResponseContractProcessor, PatternMatcher
from core.contracts.response_contract import ResponseContract, OutputChannel

def test_german_reasoning_patterns():
    """Test German reasoning patterns that might be missed."""
    print("Testing German reasoning patterns...")
    
    # Test cases based on user report
    test_cases = [
        {
            "name": "German reasoning about mobile access",
            "input": '''Okay, der Nutzer sagt, dass er mich jetzt auch von unterwegs erreichen kann. Das bedeutet wahrscheinlich, dass er mobile Zugriff eingerichtet hat. Ich sollte mich freundlich und hilfsbereit zeigen.

Das ist großartig! Es freut mich zu hören, dass du jetzt mobilen Zugriff eingerichtet hast. Jetzt kann ich dir auch von unterwegs assistieren. Wie kann ich dir helfen?''',
            "expected_response_contains": ["Das ist großartig!", "mobilen Zugriff"],
            "expected_not_contains": ["Okay, der Nutzer sagt", "Das bedeutet wahrscheinlich"]
        },
        {
            "name": "German informal reasoning",
            "input": '''Hmm, der Nutzer teilt mit, dass er mobilen Zugriff hat. Ich sollte das positiv aufnehmen und meine Bereitschaft zur Hilfe bekunden.

Super! Mobile Zugriffsmöglichkeiten erweitern unsere Flexibilität. Woran kann ich gerade für dich arbeiten?''',
            "expected_response_contains": ["Super!", "Mobile Zugriffsmöglichkeiten"],
            "expected_not_contains": ["Hmm, der Nutzer", "Ich sollte das positiv aufnehmen"]
        },
        {
            "name": "German with XML tags",
            "input": '''<denken>
Der Nutzer hat mobilen Zugriff eingerichtet. Das ist eine gute Nachricht. Ich sollte mich darüber freuen und Hilfe anbieten.
</denken>

Fantastisch! Mit mobilem Zugriff bin ich immer für dich da. Was steht an?''',
            "expected_response_contains": ["Fantastisch!", "mobilem Zugriff"],
            "expected_not_contains": ["<denken>", "Der Nutzer hat mobilen Zugriff"]
        },
        {
            "name": "Mixed German/English reasoning",
            "input": '''Okay, the user says they can reach me from mobile now. Das ist gut. I should respond positively in German.

Ausgezeichnet! Jetzt können wir auch unterwegs zusammenarbeiten. Was kann ich für dich tun?''',
            "expected_response_contains": ["Ausgezeichnet!", "unterwegs zusammenarbeiten"],
            "expected_not_contains": ["Okay, the user", "Das ist gut"]
        }
    ]
    
    output_filter = OutputFilter(debug_mode=False, strict_mode=True)
    all_passed = True
    
    for test_case in test_cases:
        print(f"\n{'='*60}")
        print(f"Test: {test_case['name']}")
        print(f"{'='*60}")
        
        contract = output_filter.filter(test_case['input'])
        response = contract.get_channel(OutputChannel.RESPONSE)
        reasoning = contract.get_channel(OutputChannel.REASONING)
        
        print(f"Input length: {len(test_case['input'])}")
        print(f"Has response: {response is not None}")
        print(f"Has reasoning: {reasoning is not None}")
        
        if response:
            print(f"\nResponse ({len(response)} chars):")
            print(f"  {response[:100]}...")
            
            # Check expected content
            for expected in test_case['expected_response_contains']:
                if expected in response:
                    print(f"  ✅ Contains expected: '{expected}'")
                else:
                    print(f"  ❌ Missing expected: '{expected}'")
                    all_passed = False
            
            # Check for unwanted content
            for not_expected in test_case['expected_not_contains']:
                if not_expected in response:
                    print(f"  ❌ Contains unwanted: '{not_expected}'")
                    all_passed = False
                else:
                    print(f"  ✅ No unwanted: '{not_expected}'")
        else:
            print("❌ No response generated")
            all_passed = False
        
        if reasoning:
            print(f"\nReasoning detected ({len(reasoning)} chars):")
            print(f"  {reasoning[:100]}...")
    
    return all_passed

def test_pattern_matcher_directly():
    """Test the PatternMatcher directly with German patterns."""
    print("\n" + "="*60)
    print("Testing PatternMatcher directly...")
    print("="*60)
    
    matcher = PatternMatcher()
    
    german_reasoning_lines = [
        "Okay, der Nutzer sagt",
        "Hmm, der Nutzer teilt mit",
        "Der Nutzer hat mobilen Zugriff",
        "Das bedeutet wahrscheinlich",
        "Ich sollte mich freundlich zeigen",
        "Ich sollte das positiv aufnehmen",
        "Das ist eine gute Nachricht",
        "Ich sollte mich darüber freuen",
    ]
    
    german_answer_lines = [
        "Das ist großartig!",
        "Super!",
        "Fantastisch!",
        "Ausgezeichnet!",
        "Das freut mich zu hören",
        "Jetzt kann ich dir auch von unterwegs assistieren",
    ]
    
    print("\nTesting reasoning detection:")
    for line in german_reasoning_lines:
        is_reasoning = matcher.is_reasoning_line(line)
        print(f"  '{line[:30]}...' -> Reasoning: {is_reasoning}")
    
    print("\nTesting answer detection:")
    for line in german_answer_lines:
        is_answer = matcher.is_answer_line(line)
        print(f"  '{line[:30]}...' -> Answer: {is_answer}")
    
    # Check current patterns
    print("\nCurrent REASONING_PREFIXES (German):")
    german_patterns = [p for p in matcher.REASONING_PREFIXES if any(germ_word in p.lower() for germ_word in ['der ', 'das ', 'die ', 'nutzer', 'sollte'])]
    for pattern in german_patterns[:10]:
        print(f"  {pattern}")

def test_real_api_call():
    """Test the actual API with the problematic prompt."""
    print("\n" + "="*60)
    print("Testing real API call with German prompt...")
    print("="*60)
    
    import requests
    import json
    
    prompt = "Ich kann dich jetzt auch von unterwegs erreichen!"
    
    try:
        response = requests.post(
            "http://localhost:8000/chat",
            json={
                "message": prompt,
                "session_id": "german_test",
                "mode": "expert"
            },
            timeout=30
        )
        
        if response.status_code == 200:
            data = response.json()
            response_text = data.get("response", "")
            
            print(f"API Response status: {response.status_code}")
            print(f"Response length: {len(response_text)}")
            print(f"\nFull response:")
            print("-" * 40)
            print(response_text)
            print("-" * 40)
            
            # Check for reasoning indicators
            reasoning_indicators = [
                "Okay, der Nutzer",
                "Okay, the user",
                "Hmm,",
                "Das bedeutet",
                "Ich sollte",
                "Der Nutzer",
                "Das ist eine",
                "<think>",
                "<denken>"
            ]
            
            found_reasoning = []
            for indicator in reasoning_indicators:
                if indicator.lower() in response_text.lower():
                    found_reasoning.append(indicator)
            
            if found_reasoning:
                print(f"\n⚠️  Found reasoning indicators: {found_reasoning}")
                return False
            else:
                print("\n✅ No reasoning indicators found")
                return True
        else:
            print(f"❌ API failed: {response.status_code}")
            print(response.text[:200])
            return False
            
    except Exception as e:
        print(f"❌ API error: {e}")
        return False

def main():
    """Main test function."""
    print("="*80)
    print("GERMAN REASONING DETECTION TEST")
    print("="*80)
    
    all_passed = True
    
    # Test pattern matcher
    test_pattern_matcher_directly()
    
    # Test German reasoning patterns
    if not test_german_reasoning_patterns():
        all_passed = False
    
    # Test real API call
    if not test_real_api_call():
        all_passed = False
    
    print("\n" + "="*80)
    if all_passed:
        print("✅ ALL TESTS PASSED")
    else:
        print("❌ SOME TESTS FAILED - German reasoning detection needs improvement")
        print("\nRecommended actions:")
        print("1. Add German reasoning patterns to PatternMatcher")
        print("2. Test with more German reasoning examples")
        print("3. Consider German XML tags like <denken>")
    
    print("="*80)
    
    return 0 if all_passed else 1

if __name__ == "__main__":
    sys.exit(main())