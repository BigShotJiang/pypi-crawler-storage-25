import unittest
import asyncio
import os
from datetime import datetime
from unittest.mock import AsyncMock, MagicMock, patch

from core.identity import HardwareIdentity
from core.consciousness_identity import IdentityManager, AwarenessLevel
from core.consciousness import ConsciousnessProtocol, AgentRole, ConsciousnessLevel, AwarenessState

class TestHardwareIdentityIntegration(unittest.TestCase):
    def setUp(self):
        self.agent_id = "hw_test_agent"
        self.agent_role = AgentRole.ORCHESTRATOR
        self.comm_client = AsyncMock()
        
    def test_hardware_identity_telemetry(self):
        """Verify HardwareIdentity collects telemetry"""
        hw = HardwareIdentity()
        telemetry = hw.get_realtime_telemetry()
        
        self.assertIn("cpu_usage_percent", telemetry)
        self.assertIn("memory_usage_percent", telemetry)
        self.assertIn("disk_usage_percent", telemetry)
        self.assertIsInstance(telemetry["cpu_usage_percent"], (int, float))

    def test_dynamic_system_prompt(self):
        """Verify system prompt includes telemetry"""
        hw = HardwareIdentity()
        prompt = hw.generate_system_prompt()
        
        self.assertIn("HARDWARE AWARENESS", prompt)
        self.assertIn("CPU utilization is", prompt)
        # Check that it's not "unknown" if psutil worked
        telemetry = hw.get_realtime_telemetry()
        if "cpu_usage_percent" in telemetry:
            self.assertIn(f"{telemetry['cpu_usage_percent']}%", prompt)

    def test_identity_manager_refresh(self):
        """Verify IdentityManager summary includes load info"""
        im = IdentityManager("test_agent", "orchestrator")
        summary = im.identity.get_summary()
        
        self.assertIn("cpu_load", summary)
        self.assertIn("mem_load", summary)
        self.assertIsInstance(summary["cpu_load"], (int, float))

    async def async_test_protocol_hardware_awareness(self):
        """Verify ConsciousnessProtocol includes hardware metrics in announcements"""
        protocol = ConsciousnessProtocol(self.agent_id, self.agent_role, self.comm_client)
        
        # Manually trigger announcement
        with patch.object(protocol.comm_client, 'broadcast') as mock_broadcast:
            await protocol.announce_consciousness()
            
            # Check if metrics were added to state
            self.assertGreater(len(protocol.consciousness.hardware_metrics), 0)
            self.assertIn("cpu_usage_percent", protocol.consciousness.hardware_metrics)
            
            # Verify they were broadcast
            mock_broadcast.assert_called()

    def test_protocol_hardware_awareness(self):
        asyncio.run(self.async_test_protocol_hardware_awareness())

if __name__ == "__main__":
    unittest.main()
