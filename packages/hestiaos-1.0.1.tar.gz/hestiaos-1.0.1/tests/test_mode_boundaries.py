import pytest
import os
from unittest.mock import MagicMock, patch
from core.mode_detection import ModeDetector
from core.mode_guard import mode_guard, ModeViolationError
from core.tool_executor_factory import ToolExecutorFactory, GovernedToolExecutor, CommunityToolExecutor

class TestModeBoundaries:
    """Test mode isolation and execution path enforcement."""

    def setup_method(self):
        # Clear cache before each test
        ModeDetector._cached_mode = None

    def test_detection_by_env(self):
        """Verify mode detection via environment variable."""
        with patch.dict(os.environ, {"HESTIAOS_MODE": "business"}):
            assert ModeDetector.detect() == "business"

    def test_detection_by_config(self, tmp_path):
        """Verify mode detection via config file."""
        # Mocking the config path in ModeDetector is tricky, so we patch the detect method or the file existence
        config_content = "mode: \"science\"\n"
        config_dir = tmp_path / "config"
        config_dir.mkdir()
        config_file = config_dir / "mode.yaml"
        config_file.write_text(config_content)
        
        with patch("os.path.join", return_value=str(config_file)):
            with patch("os.path.exists", return_value=True):
                 assert ModeDetector.detect() == "science"

    def test_factory_business_requires_gateway(self):
        """Business mode must fail if no MCP Gateway is provided."""
        with patch.dict(os.environ, {"HESTIAOS_MODE": "business"}):
            with pytest.raises(ValueError, match="requires a valid MCPGateway instance"):
                ToolExecutorFactory.create(tool_manager=MagicMock())

    def test_factory_community_requires_manager(self):
        """Community mode must fail if no ToolManager is provided."""
        with patch.dict(os.environ, {"HESTIAOS_MODE": "community"}):
            with pytest.raises(ValueError, match="requires a valid ToolManager instance"):
                ToolExecutorFactory.create(mcp_gateway=MagicMock())

    def test_factory_creates_correct_types(self):
        """Verify the factory returns the correct implementation for each mode."""
        mock_gateway = MagicMock()
        mock_manager = MagicMock()

        # Business
        with patch.dict(os.environ, {"HESTIAOS_MODE": "business"}):
            executor = ToolExecutorFactory.create(mcp_gateway=mock_gateway)
            assert isinstance(executor, GovernedToolExecutor)
            assert executor.get_mode() == "business"

        # Community
        ModeDetector._cached_mode = None
        with patch.dict(os.environ, {"HESTIAOS_MODE": "community"}):
            executor = ToolExecutorFactory.create(tool_manager=mock_manager)
            assert isinstance(executor, CommunityToolExecutor)
            assert executor.get_mode() == "community"

    @pytest.mark.asyncio
    async def test_mode_guard_enforcement(self):
        """Verify that @mode_guard blocks unauthorized modes."""
        
        @mode_guard(["business", "science"])
        async def restricted_action():
            return "success"

        # Allowed mode
        with patch.dict(os.environ, {"HESTIAOS_MODE": "business"}):
            ModeDetector._cached_mode = "business"
            assert await restricted_action() == "success"

        # Unauthorized mode
        ModeDetector._cached_mode = "community"
        with patch.dict(os.environ, {"HESTIAOS_MODE": "community"}):
            with pytest.raises(ModeViolationError, match="requires \['business', 'science'\]"):
                await restricted_action()

    @pytest.mark.asyncio
    async def test_mode_guard_soft_enforcement(self):
        """Verify that @mode_guard (strict=False) logs and returns None."""
        
        @mode_guard(["business"], strict=False)
        async def soft_action():
            return "success"

        # Unauthorized mode
        ModeDetector._cached_mode = "community"
        with patch.dict(os.environ, {"HESTIAOS_MODE": "community"}):
            result = await soft_action()
            assert result is None
