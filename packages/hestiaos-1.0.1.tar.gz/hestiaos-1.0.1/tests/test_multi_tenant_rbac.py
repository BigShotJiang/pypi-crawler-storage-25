import pytest
from core.rbac_system import RBACManager, Role, Permission

def test_tenant_isolation():
    rbac = RBACManager()
    
    # Create user in Tenant A
    user_a = rbac.create_user_context(
        user_id="user_a",
        username="User A",
        roles=[Role.OPERATOR],
        tenant_id="tenant_a",
        session_id="session_a"
    )
    
    # Create user in Tenant B
    user_b = rbac.create_user_context(
        user_id="user_b",
        username="User B",
        roles=[Role.OPERATOR],
        tenant_id="tenant_b",
        session_id="session_b"
    )
    
    # 1. User A should have access to Tenant A
    assert rbac.validate_access("session_a", Permission.READ, resource="data:x", tenant_id="tenant_a") is True
    
    # 2. User A should NOT have access to Tenant B (Isolation)
    assert rbac.validate_access("session_a", Permission.READ, resource="data:y", tenant_id="tenant_b") is False
    
    # 3. User B should have access to Tenant B
    assert rbac.validate_access("session_b", Permission.READ, resource="data:y", tenant_id="tenant_b") is True

def test_system_tenant_bypass():
    rbac = RBACManager()
    
    # Create System user
    user_sys = rbac.create_user_context(
        user_id="sys",
        username="System",
        roles=[Role.SYSTEM],
        tenant_id="system",
        session_id="session_sys"
    )
    
    # System tenant should be able to access any tenant
    assert rbac.validate_access("session_sys", Permission.READ, resource="data:x", tenant_id="tenant_a") is True
    assert rbac.validate_access("session_sys", Permission.READ, resource="data:y", tenant_id="tenant_b") is True
