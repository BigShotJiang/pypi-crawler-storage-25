import pytest
import asyncio
import sys
import os
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from core.sandbox import ToolSandbox
from pathlib import Path

@pytest.mark.asyncio
async def test_sandbox_path_validation():
    sandbox = ToolSandbox(allowed_paths=["/tmp"])
    current_dir = os.getcwd()
    
    # Safe Path (Current Dir)
    safe_file = f"{current_dir}/test_safe.txt"
    assert sandbox.is_safe_path(safe_file) == True

    # Safe Path (/tmp)
    assert sandbox.is_safe_path("/tmp/test.txt") == True

    # Unsafe Path
    assert sandbox.is_safe_path("/etc/passwd") == False
    assert sandbox.is_safe_path("/var/log/syslog") == False

@pytest.mark.asyncio
async def test_sandbox_command_validation():
    sandbox = ToolSandbox()
    
    assert sandbox.is_safe_command("ls -la") == True
    assert sandbox.is_safe_command("rm -rf /") == False
    assert sandbox.is_safe_command("echo 'hello'; rm -rf /") == False

@pytest.mark.asyncio
async def test_sandbox_execution_wrapper():
    sandbox = ToolSandbox()
    
    async def mock_execute():
        return "Executed"
        
    # Valid
    result = await sandbox.execute("read_file", {"path": f"{os.getcwd()}/test.txt"}, mock_execute)
    assert result == "Executed"
    
    # Invalid Path
    result = await sandbox.execute("read_file", {"path": "/etc/shadow"}, mock_execute)
    assert isinstance(result, dict) and "error" in result
    
    # Invalid Command
    result = await sandbox.execute("run_command", {"command": "rm -rf /"}, mock_execute)
    assert isinstance(result, dict) and "error" in result
