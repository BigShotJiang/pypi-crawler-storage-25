"""
Tests for Workflow DSL — step_tracker.py (StepStateTracker).
"""

import pytest
import os
import tempfile

from core.workflow_dsl.step_tracker import (
    StepStateTracker,
    StepTrackerError,
    StepTrackingContext,
)
from core.workflow_dsl.run_store import (
    WorkflowRunStore,
    StepRunStatus,
)


class TestStepStateTracker:
    def setup_method(self):
        self.temp_db = tempfile.NamedTemporaryFile(suffix=".db", delete=False)
        self.temp_db.close()
        self.store = WorkflowRunStore(db_path=self.temp_db.name)
        self.tracker = StepStateTracker(self.store)

        # Create a run for all tests
        self.run = self.store.create_run(
            workflow_name="test_wf",
            workflow_version="1.0.0",
            trigger_type="manual",
        )

    def teardown_method(self):
        self.store.close()
        os.unlink(self.temp_db.name)

    # --- start_step ---

    def test_start_step(self):
        ctx = self.tracker.start_step(
            self.run.run_id, "s1", "Step 1", "llm",
            input_snapshot={"prompt": "hello"},
        )
        assert ctx.run_id == self.run.run_id
        assert ctx.step_id == "s1"
        assert ctx.status == StepRunStatus.RUNNING
        assert ctx.input_snapshot["prompt"] == "hello"
        assert ctx.started_at is not None
        assert ctx._start_time is not None

        # Verify persistence
        record = self.store.get_step_state(self.run.run_id, "s1")
        assert record is not None
        assert record.status == StepRunStatus.RUNNING

    def test_start_step_without_input(self):
        ctx = self.tracker.start_step(
            self.run.run_id, "s1", "Step 1", "llm",
        )
        assert ctx.input_snapshot is None

    def test_start_step_already_active_raises(self):
        self.tracker.start_step(self.run.run_id, "s1", "Step 1", "llm")
        with pytest.raises(StepTrackerError, match="already active"):
            self.tracker.start_step(self.run.run_id, "s1", "Step 1", "llm")

    def test_start_multiple_steps(self):
        ctx1 = self.tracker.start_step(self.run.run_id, "s1", "Step 1", "llm")
        ctx2 = self.tracker.start_step(self.run.run_id, "s2", "Step 2", "tool")
        assert ctx1.step_id == "s1"
        assert ctx2.step_id == "s2"

    # --- complete_step ---

    def test_complete_step(self):
        ctx = self.tracker.start_step(
            self.run.run_id, "s1", "Step 1", "llm",
            input_snapshot={"prompt": "hello"},
        )
        result = self.tracker.complete_step(
            ctx, output_snapshot={"response": "world"},
        )
        assert result.status == StepRunStatus.COMPLETED
        assert result.output_snapshot["response"] == "world"
        assert result.duration_ms is not None
        assert result.duration_ms >= 0
        assert result.completed_at is not None

        # Verify persistence
        record = self.store.get_step_state(self.run.run_id, "s1")
        assert record.status == StepRunStatus.COMPLETED
        assert record.output_snapshot["response"] == "world"

    def test_complete_step_not_active_raises(self):
        ctx = StepTrackingContext(
            run_id=self.run.run_id,
            step_id="s1",
            step_name="Step 1",
            step_type="llm",
        )
        with pytest.raises(StepTrackerError, match="not active"):
            self.tracker.complete_step(ctx)

    def test_complete_step_twice_raises(self):
        ctx = self.tracker.start_step(self.run.run_id, "s1", "Step 1", "llm")
        self.tracker.complete_step(ctx)
        with pytest.raises(StepTrackerError, match="not active"):
            self.tracker.complete_step(ctx)

    def test_complete_step_removes_from_active(self):
        ctx = self.tracker.start_step(self.run.run_id, "s1", "Step 1", "llm")
        assert self.tracker.get_active_step(self.run.run_id, "s1") is not None
        self.tracker.complete_step(ctx)
        assert self.tracker.get_active_step(self.run.run_id, "s1") is None

    # --- fail_step ---

    def test_fail_step(self):
        ctx = self.tracker.start_step(
            self.run.run_id, "s1", "Step 1", "llm",
        )
        result = self.tracker.fail_step(ctx, error="timeout")
        assert result.status == StepRunStatus.FAILED
        assert result.error == "timeout"
        assert result.duration_ms is not None

        # Verify persistence
        record = self.store.get_step_state(self.run.run_id, "s1")
        assert record.status == StepRunStatus.FAILED
        assert record.error == "timeout"

    def test_fail_step_not_active_raises(self):
        ctx = StepTrackingContext(
            run_id=self.run.run_id,
            step_id="s1",
            step_name="Step 1",
            step_type="llm",
        )
        with pytest.raises(StepTrackerError, match="not active"):
            self.tracker.fail_step(ctx, error="crash")

    def test_fail_step_with_output(self):
        ctx = self.tracker.start_step(self.run.run_id, "s1", "Step 1", "llm")
        result = self.tracker.fail_step(
            ctx, error="partial failure",
            output_snapshot={"partial": "data"},
        )
        assert result.output_snapshot["partial"] == "data"

    # --- skip_step ---

    def test_skip_step(self):
        ctx = self.tracker.skip_step(
            self.run.run_id, "s1", "Step 1", "condition",
            reason="condition not met",
        )
        assert ctx.status == StepRunStatus.SKIPPED
        assert ctx.error == "condition not met"
        assert ctx.duration_ms == 0.0

        # Verify persistence
        record = self.store.get_step_state(self.run.run_id, "s1")
        assert record.status == StepRunStatus.SKIPPED

    def test_skip_step_without_reason(self):
        ctx = self.tracker.skip_step(
            self.run.run_id, "s1", "Step 1", "condition",
        )
        assert ctx.status == StepRunStatus.SKIPPED
        assert ctx.error is None

    def test_skip_step_not_in_active(self):
        """Skipped steps should not be in active set."""
        self.tracker.skip_step(self.run.run_id, "s1", "Step 1", "condition")
        assert self.tracker.get_active_step(self.run.run_id, "s1") is None

    # --- increment_retry ---

    def test_increment_retry(self):
        ctx = self.tracker.start_step(self.run.run_id, "s1", "Step 1", "llm")
        count = self.tracker.increment_retry(ctx)
        assert count == 1
        assert ctx.retry_count == 1

        count = self.tracker.increment_retry(ctx)
        assert count == 2

    def test_increment_retry_not_active_raises(self):
        ctx = StepTrackingContext(
            run_id=self.run.run_id,
            step_id="s1",
            step_name="Step 1",
            step_type="llm",
        )
        with pytest.raises(StepTrackerError, match="not active"):
            self.tracker.increment_retry(ctx)

    def test_increment_retry_updates_start_time(self):
        ctx = self.tracker.start_step(self.run.run_id, "s1", "Step 1", "llm")
        original_start = ctx.started_at
        self.tracker.increment_retry(ctx)
        assert ctx.started_at != original_start

    # --- get_active_step / get_active_steps ---

    def test_get_active_step_exists(self):
        ctx = self.tracker.start_step(self.run.run_id, "s1", "Step 1", "llm")
        result = self.tracker.get_active_step(self.run.run_id, "s1")
        assert result is ctx

    def test_get_active_step_not_found(self):
        result = self.tracker.get_active_step(self.run.run_id, "nonexistent")
        assert result is None

    def test_get_active_steps(self):
        self.tracker.start_step(self.run.run_id, "s1", "Step 1", "llm")
        self.tracker.start_step(self.run.run_id, "s2", "Step 2", "tool")
        steps = self.tracker.get_active_steps(self.run.run_id)
        assert len(steps) == 2

    def test_get_active_steps_empty(self):
        steps = self.tracker.get_active_steps(self.run.run_id)
        assert steps == []

    def test_has_active_steps(self):
        assert self.tracker.has_active_steps(self.run.run_id) is False
        self.tracker.start_step(self.run.run_id, "s1", "Step 1", "llm")
        assert self.tracker.has_active_steps(self.run.run_id) is True

    def test_has_active_steps_after_complete(self):
        ctx = self.tracker.start_step(self.run.run_id, "s1", "Step 1", "llm")
        self.tracker.complete_step(ctx)
        assert self.tracker.has_active_steps(self.run.run_id) is False

    # --- Full lifecycle ---

    def test_full_step_lifecycle(self):
        """Start → retry → complete."""
        ctx = self.tracker.start_step(
            self.run.run_id, "s1", "Step 1", "llm",
            input_snapshot={"prompt": "hello"},
        )
        self.tracker.increment_retry(ctx)
        self.tracker.increment_retry(ctx)
        result = self.tracker.complete_step(
            ctx, output_snapshot={"response": "world"},
        )
        assert result.retry_count == 2
        assert result.status == StepRunStatus.COMPLETED

        record = self.store.get_step_state(self.run.run_id, "s1")
        assert record.retry_count == 2
        assert record.status == StepRunStatus.COMPLETED

    def test_multiple_runs_independent_tracking(self):
        """Steps in different runs should not interfere."""
        run2 = self.store.create_run(
            workflow_name="wf2", workflow_version="1.0.0", trigger_type="manual",
        )
        ctx1 = self.tracker.start_step(self.run.run_id, "s1", "Step 1", "llm")
        ctx2 = self.tracker.start_step(run2.run_id, "s1", "Step 1", "llm")

        assert self.tracker.get_active_step(self.run.run_id, "s1") is ctx1
        assert self.tracker.get_active_step(run2.run_id, "s1") is ctx2

        self.tracker.complete_step(ctx1)
        assert self.tracker.get_active_step(self.run.run_id, "s1") is None
        assert self.tracker.get_active_step(run2.run_id, "s1") is ctx2
