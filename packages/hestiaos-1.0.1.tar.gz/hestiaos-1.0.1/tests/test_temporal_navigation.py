"""
Tests für den TemporalNavigator.

Testet:
- TemporalQuery-Erstellung und Serialisierung
- get_snapshot() mit verschiedenen Query-Typen
- diff_between() zwischen zwei Snapshots
- find_introduction() eines Nodes
- get_timeline() eines Nodes
- find_regression() einer Capability
- Snapshot-Management (add_snapshot, list_snapshots, get_lineage, get_branch)
"""

import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

import pytest
from datetime import datetime, timezone
from typing import Dict, List

from core.ir.models import (
    ExecutionGraphIR, ExecutionNode, ExecutionEdge,
    NodeType, EdgeType, GraphScope, SnapshotDAG,
)
from core.ir.temporal_navigation import (
    TemporalNavigator, TemporalQuery, TemporalDiffResult, TimelineEntry,
)


# =============================================================================
# Fixtures
# =============================================================================


@pytest.fixture
def base_graph() -> ExecutionGraphIR:
    """Basis-Graph für Snapshot-Tests (Snapshot 1)."""
    nodes: Dict[str, ExecutionNode] = {
        "v1": ExecutionNode(
            node_id="v1", node_type=NodeType.VISION,
            label="HestiaOS Vision", scope=GraphScope.INTENT,
        ),
        "i1": ExecutionNode(
            node_id="i1", node_type=NodeType.INTENT,
            label="Runtime Contract Analysis", scope=GraphScope.INTENT,
        ),
        "a1": ExecutionNode(
            node_id="a1", node_type=NodeType.ADR,
            label="ADR-017: Runtime Contract Format", scope=GraphScope.INTENT,
        ),
        "cap1": ExecutionNode(
            node_id="cap1", node_type=NodeType.CAPABILITY,
            label="contract_analysis", scope=GraphScope.ARCHITECTURE,
            metadata={"status": "implemented"},
        ),
        "comp1": ExecutionNode(
            node_id="comp1", node_type=NodeType.COMPONENT,
            label="RuntimeContractAnalyzer", scope=GraphScope.RUNTIME,
        ),
    }

    edges: List[ExecutionEdge] = [
        ExecutionEdge(source_id="i1", target_id="cap1", edge_type=EdgeType.SATISFIES),
        ExecutionEdge(source_id="i1", target_id="a1", edge_type=EdgeType.REFERENCE),
        ExecutionEdge(source_id="cap1", target_id="comp1", edge_type=EdgeType.IMPLEMENTS),
    ]

    return ExecutionGraphIR(
        graph_id="snap1",
        source="pytest",
        timestamp="2026-01-01T00:00:00+00:00",
        nodes=nodes,
        edges=edges,
    )


@pytest.fixture
def extended_graph(base_graph: ExecutionGraphIR) -> ExecutionGraphIR:
    """Erweiterter Graph für Snapshot 2 (neue ADR + Constraint)."""
    nodes = dict(base_graph.nodes)
    nodes["a2"] = ExecutionNode(
        node_id="a2", node_type=NodeType.ADR,
        label="ADR-018: Governance Protocol", scope=GraphScope.INTENT,
    )
    nodes["c1"] = ExecutionNode(
        node_id="c1", node_type=NodeType.CONSTRAINT,
        label="No circular dependencies", scope=GraphScope.GOVERNANCE,
    )

    edges = list(base_graph.edges) + [
        ExecutionEdge(source_id="i1", target_id="a2", edge_type=EdgeType.REFERENCE),
        ExecutionEdge(source_id="a2", target_id="c1", edge_type=EdgeType.REFERENCE),
    ]

    return ExecutionGraphIR(
        graph_id="snap2",
        source="pytest",
        timestamp="2026-02-01T00:00:00+00:00",
        nodes=nodes,
        edges=edges,
    )


@pytest.fixture
def modified_graph(extended_graph: ExecutionGraphIR) -> ExecutionGraphIR:
    """Graph für Snapshot 3 (ADR-017 modifiziert, Capability-Status geändert)."""
    nodes = dict(extended_graph.nodes)
    # Modifiziere a1 (ADR-017)
    nodes["a1"] = ExecutionNode(
        node_id="a1", node_type=NodeType.ADR,
        label="ADR-017: Runtime Contract Format v2", scope=GraphScope.INTENT,
    )
    # Capability-Status auf "partial" setzen (Regression)
    nodes["cap1"] = ExecutionNode(
        node_id="cap1", node_type=NodeType.CAPABILITY,
        label="contract_analysis", scope=GraphScope.ARCHITECTURE,
        metadata={"status": "partial"},
    )
    # Füge Violation hinzu
    nodes["viol1"] = ExecutionNode(
        node_id="viol1", node_type=NodeType.VIOLATION,
        label="ADR-017 Violation", scope=GraphScope.RUNTIME,
    )

    edges = list(extended_graph.edges) + [
        ExecutionEdge(source_id="viol1", target_id="a1", edge_type=EdgeType.VIOLATES),
    ]

    return ExecutionGraphIR(
        graph_id="snap3",
        source="pytest",
        timestamp="2026-03-01T00:00:00+00:00",
        nodes=nodes,
        edges=edges,
    )


@pytest.fixture
def navigator_with_snapshots(
    base_graph: ExecutionGraphIR,
    extended_graph: ExecutionGraphIR,
    modified_graph: ExecutionGraphIR,
) -> TemporalNavigator:
    """Navigator mit 3 Snapshots (lineare Historie)."""
    nav = TemporalNavigator()
    nav.add_snapshot(base_graph, label="Initial", metadata={"version": "1.0"})
    nav.add_snapshot(extended_graph, label="Extended", metadata={"version": "2.0"})
    nav.add_snapshot(modified_graph, label="Modified", metadata={"version": "3.0"})
    return nav


# =============================================================================
# TemporalQuery Tests
# =============================================================================


class TestTemporalQuery:
    """Tests für die TemporalQuery-Dataclass."""

    def test_create_query_by_id(self):
        """Erstelle eine Query mit Snapshot-ID."""
        query = TemporalQuery(snapshot_id="snap_a1b2c3d4")
        assert query.snapshot_id == "snap_a1b2c3d4"
        assert query.timestamp is None
        assert query.node_id is None

    def test_create_query_by_timestamp(self):
        """Erstelle eine Query mit Timestamp."""
        query = TemporalQuery(timestamp="2026-05-07T10:00:00+00:00")
        assert query.timestamp == "2026-05-07T10:00:00+00:00"

    def test_create_query_by_node_id(self):
        """Erstelle eine Query mit Node-ID."""
        query = TemporalQuery(node_id="a1", edge_type="violates")
        assert query.node_id == "a1"
        assert query.edge_type == "violates"

    def test_query_serialization(self):
        """Teste Serialisierung/Deserialisierung."""
        query = TemporalQuery(
            snapshot_id="snap_test",
            timestamp="2026-01-01T00:00:00+00:00",
            node_id="a1",
            edge_type="reference",
        )
        data = query.to_dict()
        restored = TemporalQuery.from_dict(data)
        assert restored.snapshot_id == query.snapshot_id
        assert restored.timestamp == query.timestamp
        assert restored.node_id == query.node_id
        assert restored.edge_type == query.edge_type

    def test_query_empty(self):
        """Leere Query = alle Felder sind None."""
        query = TemporalQuery()
        assert query.snapshot_id is None
        assert query.timestamp is None
        assert query.node_id is None
        assert query.edge_type is None


# =============================================================================
# TemporalNavigator Tests
# =============================================================================


class TestTemporalNavigator:
    """Tests für den TemporalNavigator."""

    # ── Snapshot Management ───────────────────────────────────────

    def test_add_snapshot(self, base_graph):
        """Füge einen Snapshot hinzu."""
        nav = TemporalNavigator()
        snap = nav.add_snapshot(base_graph, label="Initial")
        assert snap.snapshot_id is not None
        assert snap.label == "Initial"
        assert snap.graph.graph_id == base_graph.graph_id

    def test_add_snapshot_with_metadata(self, base_graph):
        """Füge Snapshot mit Metadaten hinzu."""
        nav = TemporalNavigator()
        snap = nav.add_snapshot(
            base_graph,
            label="Initial",
            metadata={"author": "test", "version": "1.0"},
        )
        assert snap.metadata.get("author") == "test"
        assert snap.metadata.get("version") == "1.0"

    def test_add_multiple_snapshots(self, base_graph, extended_graph):
        """Füge mehrere Snapshots hinzu (lineare Historie)."""
        nav = TemporalNavigator()
        snap1 = nav.add_snapshot(base_graph, label="Initial")
        snap2 = nav.add_snapshot(extended_graph, label="Extended")
        assert snap2.parent_ids == [snap1.snapshot_id]
        assert len(nav.snapshot_dag.snapshots) == 2

    def test_list_snapshots(self, navigator_with_snapshots):
        """Liste alle Snapshots auf."""
        snapshots = navigator_with_snapshots.list_snapshots()
        assert len(snapshots) == 3
        # Chronologisch sortiert
        assert snapshots[0]["label"] == "Initial"
        assert snapshots[1]["label"] == "Extended"
        assert snapshots[2]["label"] == "Modified"

    def test_list_snapshots_heads(self, navigator_with_snapshots):
        """Liste nur Heads auf."""
        heads = navigator_with_snapshots.list_snapshots(scope="heads")
        assert len(heads) == 1  # Nur der letzte Snapshot ist ein Head
        assert heads[0]["label"] == "Modified"

    def test_get_lineage(self, navigator_with_snapshots):
        """Hole die Vorfahren-Kette eines Snapshots."""
        snapshots = navigator_with_snapshots.list_snapshots()
        last_id = snapshots[-1]["snapshot_id"]
        lineage = navigator_with_snapshots.get_lineage(last_id)
        assert len(lineage) == 3  # Alle 3 Snapshots in der Kette
        assert lineage[0]["label"] == "Initial"
        assert lineage[-1]["label"] == "Modified"

    def test_get_branch(self, navigator_with_snapshots):
        """Hole alle Nachkommen eines Snapshots (inkl. Start-Snapshot)."""
        snapshots = navigator_with_snapshots.list_snapshots()
        first_id = snapshots[0]["snapshot_id"]
        branch = navigator_with_snapshots.get_branch(first_id)
        # get_branch() gibt den Start-Snapshot + alle Nachkommen zurück
        assert len(branch) == 3  # Initial + Extended + Modified

    def test_get_snapshot_by_label(self, navigator_with_snapshots):
        """Finde Snapshot anhand des Labels."""
        graph = navigator_with_snapshots.get_snapshot_by_label("Extended")
        assert graph is not None
        assert graph.graph_id == "snap2"

    def test_get_snapshot_by_label_nonexistent(self, navigator_with_snapshots):
        """Nicht-existentes Label gibt None."""
        graph = navigator_with_snapshots.get_snapshot_by_label("Nonexistent")
        assert graph is None

    # ── get_snapshot() ────────────────────────────────────────────

    def test_get_snapshot_by_id(self, navigator_with_snapshots):
        """Lade Snapshot per ID."""
        snapshots = navigator_with_snapshots.list_snapshots()
        snap_id = snapshots[0]["snapshot_id"]
        query = TemporalQuery(snapshot_id=snap_id)
        graph = navigator_with_snapshots.get_snapshot(query)
        assert graph is not None
        assert graph.graph_id == "snap1"

    def test_get_snapshot_by_id_nonexistent(self, navigator_with_snapshots):
        """Nicht-existente Snapshot-ID gibt None."""
        query = TemporalQuery(snapshot_id="nonexistent")
        graph = navigator_with_snapshots.get_snapshot(query)
        assert graph is None

    def test_get_snapshot_by_timestamp(self, navigator_with_snapshots):
        """Lade Snapshot per Timestamp (dynamisch, da add_snapshot Timestamp setzt)."""
        snapshots = navigator_with_snapshots.list_snapshots()
        # Verwende den tatsächlichen Timestamp des ersten Snapshots
        ts = snapshots[0]["timestamp"]
        query = TemporalQuery(timestamp=ts)
        graph = navigator_with_snapshots.get_snapshot(query)
        assert graph is not None
        assert graph.graph_id == "snap1"

    def test_get_snapshot_by_timestamp_exact(self, navigator_with_snapshots):
        """Lade Snapshot mit exaktem Timestamp."""
        snapshots = navigator_with_snapshots.list_snapshots()
        # Verwende den tatsächlichen Timestamp des zweiten Snapshots
        ts = snapshots[1]["timestamp"]
        query = TemporalQuery(timestamp=ts)
        graph = navigator_with_snapshots.get_snapshot(query)
        assert graph is not None
        assert graph.graph_id == "snap2"

    def test_get_snapshot_by_timestamp_before_first(self, navigator_with_snapshots):
        """Timestamp vor erstem Snapshot gibt None."""
        query = TemporalQuery(timestamp="2025-01-01T00:00:00+00:00")
        graph = navigator_with_snapshots.get_snapshot(query)
        assert graph is None

    def test_get_snapshot_by_timestamp_invalid(self, navigator_with_snapshots):
        """Ungültiger Timestamp gibt None."""
        query = TemporalQuery(timestamp="invalid-date")
        graph = navigator_with_snapshots.get_snapshot(query)
        assert graph is None

    def test_get_snapshot_by_node_id(self, navigator_with_snapshots):
        """Lade Snapshot per Node-ID (finde neuesten Snapshot mit Node)."""
        query = TemporalQuery(node_id="a2")
        graph = navigator_with_snapshots.get_snapshot(query)
        assert graph is not None
        # a2 wurde in snap2 eingeführt und ist in snap3 noch vorhanden
        # Sollte snap3 zurückgeben (neuester)
        assert graph.graph_id == "snap3"

    def test_get_snapshot_by_node_id_removed(self, navigator_with_snapshots):
        """Node existiert in neueren Snapshots nicht mehr."""
        # c1 existiert in snap2 und snap3
        query = TemporalQuery(node_id="c1")
        graph = navigator_with_snapshots.get_snapshot(query)
        assert graph is not None
        assert graph.graph_id == "snap3"

    def test_get_snapshot_by_node_id_nonexistent(self, navigator_with_snapshots):
        """Nicht-existente Node-ID gibt None."""
        query = TemporalQuery(node_id="nonexistent")
        graph = navigator_with_snapshots.get_snapshot(query)
        assert graph is None

    def test_get_snapshot_empty_query(self, navigator_with_snapshots):
        """Leere Query gibt None."""
        query = TemporalQuery()
        graph = navigator_with_snapshots.get_snapshot(query)
        assert graph is None

    # ── diff_between() ────────────────────────────────────────────

    def test_diff_between_adjacent(self, navigator_with_snapshots):
        """Diff zwischen zwei benachbarten Snapshots."""
        snapshots = navigator_with_snapshots.list_snapshots()
        result = navigator_with_snapshots.diff_between(
            snapshots[0]["snapshot_id"],
            snapshots[1]["snapshot_id"],
        )
        assert result is not None
        assert isinstance(result, TemporalDiffResult)
        assert result.from_snapshot_id == snapshots[0]["snapshot_id"]
        assert result.to_snapshot_id == snapshots[1]["snapshot_id"]
        # snap2 hat 2 neue Nodes (a2, c1) und 2 neue Edges
        assert len(result.diff.added_nodes) >= 2
        assert len(result.diff.added_edges) >= 2

    def test_diff_between_non_adjacent(self, navigator_with_snapshots):
        """Diff zwischen nicht benachbarten Snapshots."""
        snapshots = navigator_with_snapshots.list_snapshots()
        result = navigator_with_snapshots.diff_between(
            snapshots[0]["snapshot_id"],
            snapshots[2]["snapshot_id"],
        )
        assert result is not None
        # snap3 hat a1 modifiziert, cap1 modifiziert, viol1 hinzugefügt
        assert len(result.diff.modified_nodes) >= 1
        assert len(result.diff.added_nodes) >= 1

    def test_diff_between_same(self, navigator_with_snapshots):
        """Diff zwischen identischen Snapshots."""
        snapshots = navigator_with_snapshots.list_snapshots()
        result = navigator_with_snapshots.diff_between(
            snapshots[0]["snapshot_id"],
            snapshots[0]["snapshot_id"],
        )
        assert result is not None
        assert len(result.diff.added_nodes) == 0
        assert len(result.diff.removed_nodes) == 0

    def test_diff_between_nonexistent(self, navigator_with_snapshots):
        """Nicht-existente Snapshot-ID gibt None."""
        result = navigator_with_snapshots.diff_between("nonexistent", "also_nonexistent")
        assert result is None

    def test_diff_between_summary(self, navigator_with_snapshots):
        """Diff enthält textuelle Zusammenfassung."""
        snapshots = navigator_with_snapshots.list_snapshots()
        result = navigator_with_snapshots.diff_between(
            snapshots[0]["snapshot_id"],
            snapshots[1]["snapshot_id"],
        )
        assert result is not None
        assert "Node(s) hinzugefügt" in result.summary
        assert "Edge(s) hinzugefügt" in result.summary

    def test_diff_between_serialization(self, navigator_with_snapshots):
        """TemporalDiffResult serialisieren."""
        snapshots = navigator_with_snapshots.list_snapshots()
        result = navigator_with_snapshots.diff_between(
            snapshots[0]["snapshot_id"],
            snapshots[1]["snapshot_id"],
        )
        assert result is not None
        data = result.to_dict()
        assert "from_snapshot_id" in data
        assert "to_snapshot_id" in data
        assert "diff" in data
        assert "summary" in data

    # ── find_introduction() ───────────────────────────────────────

    def test_find_introduction_first_snapshot(self, navigator_with_snapshots):
        """Node wurde im ersten Snapshot eingeführt."""
        snap_id = navigator_with_snapshots.find_introduction("v1")
        assert snap_id is not None
        snapshots = navigator_with_snapshots.list_snapshots()
        assert snap_id == snapshots[0]["snapshot_id"]

    def test_find_introduction_later_snapshot(self, navigator_with_snapshots):
        """Node wurde in einem späteren Snapshot eingeführt."""
        snap_id = navigator_with_snapshots.find_introduction("a2")
        assert snap_id is not None
        snapshots = navigator_with_snapshots.list_snapshots()
        assert snap_id == snapshots[1]["snapshot_id"]  # Extended

    def test_find_introduction_nonexistent(self, navigator_with_snapshots):
        """Nicht-existenter Node gibt None."""
        snap_id = navigator_with_snapshots.find_introduction("nonexistent")
        assert snap_id is None

    def test_find_introduction_violation(self, navigator_with_snapshots):
        """Violation wurde im letzten Snapshot eingeführt."""
        snap_id = navigator_with_snapshots.find_introduction("viol1")
        assert snap_id is not None
        snapshots = navigator_with_snapshots.list_snapshots()
        assert snap_id == snapshots[2]["snapshot_id"]  # Modified

    # ── get_timeline() ────────────────────────────────────────────

    def test_get_timeline_introduced_first(self, navigator_with_snapshots):
        """Timeline eines Nodes, der im ersten Snapshot eingeführt wurde."""
        timeline = navigator_with_snapshots.get_timeline("v1")
        assert len(timeline) == 3  # In allen 3 Snapshots vorhanden
        assert timeline[0].change_type == "introduced"
        assert timeline[1].change_type == "unchanged"
        assert timeline[2].change_type == "unchanged"

    def test_get_timeline_introduced_later(self, navigator_with_snapshots):
        """Timeline eines Nodes, der später eingeführt wurde."""
        timeline = navigator_with_snapshots.get_timeline("a2")
        assert len(timeline) >= 2  # In snap2 und snap3
        assert timeline[0].change_type == "introduced"

    def test_get_timeline_modified(self, navigator_with_snapshots):
        """Timeline eines Nodes, der modifiziert wurde."""
        timeline = navigator_with_snapshots.get_timeline("a1")
        assert len(timeline) == 3
        # a1 wurde in snap1 eingeführt, in snap2 unverändert, in snap3 modifiziert
        assert timeline[0].change_type == "introduced"
        assert timeline[1].change_type == "unchanged"
        assert timeline[2].change_type == "modified"

    def test_get_timeline_nonexistent(self, navigator_with_snapshots):
        """Nicht-existenter Node gibt leere Timeline."""
        timeline = navigator_with_snapshots.get_timeline("nonexistent")
        assert len(timeline) == 0

    def test_get_timeline_entries_have_metadata(self, navigator_with_snapshots):
        """Timeline-Einträge haben Metadaten."""
        timeline = navigator_with_snapshots.get_timeline("a1")
        for entry in timeline:
            assert entry.snapshot_id is not None
            assert entry.timestamp is not None
            assert "label" in entry.metadata

    def test_get_timeline_modified_has_previous_label(self, navigator_with_snapshots):
        """Modifizierter Eintrag enthält vorherigen Label."""
        timeline = navigator_with_snapshots.get_timeline("a1")
        modified_entry = [e for e in timeline if e.change_type == "modified"]
        assert len(modified_entry) == 1
        assert "previous_label" in modified_entry[0].metadata
        assert modified_entry[0].metadata["previous_label"] == "ADR-017: Runtime Contract Format"

    # ── find_regression() ─────────────────────────────────────────

    def test_find_regression_detected(self, navigator_with_snapshots):
        """Regression wird erkannt (implemented -> partial)."""
        snap_id = navigator_with_snapshots.find_regression("cap1")
        assert snap_id is not None
        snapshots = navigator_with_snapshots.list_snapshots()
        assert snap_id == snapshots[2]["snapshot_id"]  # Modified

    def test_find_regression_no_regression(self, base_graph):
        """Keine Regression bei stabilem Status."""
        nav = TemporalNavigator()
        nav.add_snapshot(base_graph, label="Initial")
        snap_id = nav.find_regression("cap1")
        assert snap_id is None  # Keine Regression

    def test_find_regression_nonexistent(self, navigator_with_snapshots):
        """Nicht-existente Capability gibt None."""
        snap_id = navigator_with_snapshots.find_regression("nonexistent")
        assert snap_id is None

    def test_find_regression_missing_capability(self, navigator_with_snapshots):
        """Capability fehlt in einem Snapshot (missing)."""
        # Erstelle einen Snapshot, in dem cap1 fehlt
        nodes = {
            "v1": ExecutionNode(
                node_id="v1", node_type=NodeType.VISION,
                label="HestiaOS Vision", scope=GraphScope.INTENT,
            ),
        }
        graph = ExecutionGraphIR(
            graph_id="missing_cap",
            source="pytest",
            timestamp="2026-04-01T00:00:00+00:00",
            nodes=nodes,
            edges=[],
        )
        nav = TemporalNavigator()
        nav.add_snapshot(navigator_with_snapshots.snapshot_dag.snapshots[
            list(navigator_with_snapshots.snapshot_dag.snapshots.keys())[0]
        ].graph, label="Initial")
        nav.add_snapshot(graph, label="Missing Cap")
        snap_id = nav.find_regression("cap1")
        assert snap_id is not None

    # ── Edge Cases ────────────────────────────────────────────────

    def test_empty_navigator(self):
        """Navigator ohne Snapshots."""
        nav = TemporalNavigator()
        assert nav.list_snapshots() == []
        assert nav.get_snapshot(TemporalQuery(snapshot_id="test")) is None
        assert nav.find_introduction("test") is None
        assert nav.get_timeline("test") == []
        assert nav.find_regression("test") is None

    def test_snapshot_dag_property(self, navigator_with_snapshots):
        """snapshot_dag property gibt den DAG zurück."""
        dag = navigator_with_snapshots.snapshot_dag
        assert isinstance(dag, SnapshotDAG)
        assert len(dag.snapshots) == 3

    def test_diff_between_timestamps(self, navigator_with_snapshots):
        """Diff enthält korrekte Timestamps (dynamisch)."""
        snapshots = navigator_with_snapshots.list_snapshots()
        result = navigator_with_snapshots.diff_between(
            snapshots[0]["snapshot_id"],
            snapshots[2]["snapshot_id"],
        )
        assert result is not None
        assert result.from_timestamp == snapshots[0]["timestamp"]
        assert result.to_timestamp == snapshots[2]["timestamp"]

    def test_timeline_entry_to_dict(self, navigator_with_snapshots):
        """TimelineEntry serialisieren."""
        timeline = navigator_with_snapshots.get_timeline("v1")
        entry = timeline[0]
        data = entry.to_dict()
        assert "snapshot_id" in data
        assert "timestamp" in data
        assert "node" in data
        assert "change_type" in data
        assert "metadata" in data
