import asyncio
import os
import json
import sys
from pathlib import Path

# Add project root to path
sys.path.insert(0, str(Path(__file__).parent.parent))
from core.memory_coordinator import MemoryCoordinator
from core.orchestrator import Orchestrator
from tests.conftest import MockBackendRouter
from core.llm_engine import LLMEngine
from core.context_manager import ContextManager
from core.consciousness_audit import consciousness_audit
from core.consciousness_security import ConsciousnessEncryption
from core.routing.mcp_gateway import MCPGateway
from core.interfaces import IContextManager, IToolExecutor

async def test_advanced_integration():
    print("🚀 Starting Advanced Integration Test (Phase 7/8)...")
    
    # 1. Setup Mock Environment
    vault_path = Path("/home/admin01/Dokumente/obsidian")
    vault_path.mkdir(parents=True, exist_ok=True)
    
    # Ensure it's in config
    from core.config.legacy_adapter import config_manager
    config_manager.update_override("obsidian.vault_path", str(vault_path))
    
    # Create a dummy manifest
    architect_dir = vault_path / "01_Agents" / "Architect"
    architect_dir.mkdir(parents=True, exist_ok=True)
    with open(architect_dir / "behavior.md", "w") as f:
        f.write("STRICT_RULE: Always use scientific notation.")
    
    # Create a dummy note for search
    notes_dir = vault_path / "Notizen"
    notes_dir.mkdir(parents=True, exist_ok=True)
    with open(notes_dir / "research_2026.md", "w") as f:
        f.write("Topic: Quantum Entanglement in Agents. Priority: High.")

    # 2. Test Vault Search in MemoryCoordinator
    print("🔍 Testing Vault Search...")
    mc = MemoryCoordinator()
    context = await mc.retrieve_context("Quantum Entanglement")
    assert any("research_2026.md" in str(res) for res in context["knowledge"])
    print("✅ Vault Search verified.")

    # 3. Test Manifest Loading in Orchestrator
    print("📜 Testing Role Manifest Loading...")
    from core.config import config_manager
    from core.tool_manager import ToolManager # analyzer: ignore # analyzer: ignore
    llm = LLMEngine(ollama_host="http://localhost:11434")
    cm = ContextManager()
    tm = ToolManager()
    te_legacy = ToolExecutor(tool_manager=tm) # analyzer: ignore
    
    # Use MCP Gateway as the unified executor
    te = MCPGateway()
    te.tool_manager = tm
    te.tool_executor = te_legacy
    
    models_config = {"vault": {"path": str(vault_path)}}
    orch = Orchestrator(llm, cm, te, models_config,
        backend_router=MockBackendRouter()
    )
    
    manifest = await orch._get_role_manifest("Architect")
    assert "STRICT_RULE" in manifest
    print("✅ Role Manifest loading verified.")

    # 4. Test Audit Logging
    print("🔐 Testing Consciousness Audit...")
    consciousness_audit.log_operation(
        operation="test_op",
        agent_id="test_agent",
        role="administrator",
        session_id="test_session",
        success=True,
        details={"info": "verification"}
    )
    
    log_path = Path("logs/consciousness_audit.log")
    assert log_path.exists()
    with open(log_path, "r") as f:
        last_line = f.readlines()[-1]
        assert "test_op" in last_line
        assert "entry_hash" in last_line
    print("✅ Audit Logging verified.")

    # 5. Test Encryption
    print("🔑 Testing Consciousness Encryption...")
    enc = ConsciousnessEncryption()
    test_data = {"secret": "private_context"}
    encrypted = enc.encrypt_context_item(test_data)
    decrypted = enc.decrypt_context_item(encrypted)
    assert decrypted == test_data
    print("✅ Encryption verified.")

    # 6. Interface Protocol Check
    print("🧩 Checking Protocol Compliance...")
    assert isinstance(cm, IContextManager)
    assert isinstance(te, IToolExecutor)
    print("✅ Protocol compliance verified.")

    print("🎉 All Phase 7/8 Advanced Integration tests passed!")

if __name__ == "__main__":
    asyncio.run(test_advanced_integration())
