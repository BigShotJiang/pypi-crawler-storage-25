"""
Tests for MCP Proxy Credential Resolver.
"""

import pytest
from unittest.mock import Mock, patch, MagicMock

from mcp_proxy.credential_resolver import (
    CredentialResolver,
    ResolvedCredential,
    get_credential_resolver
)
from core.vault.service_accounts import (
    Provider,
    AuthType,
    ServiceAccount,
    ServiceAccountStatus
)
from core.vault.crypto_adapter import EncryptedStorageAdapter


class TestResolvedCredential:
    """Test ResolvedCredential class."""
    
    def test_auth_headers(self):
        """Test authentication header generation."""
        # Bearer token
        cred = ResolvedCredential(
            auth_type=AuthType.BEARER,
            secret="test-token-123",
            provider=Provider.GITLAB,
            service_account_id="acc-1"
        )
        headers = cred.get_auth_header()
        assert headers == {"Authorization": "Bearer test-token-123"}
        
        # Private token (GitLab style)
        cred = ResolvedCredential(
            auth_type=AuthType.PRIVATE_TOKEN,
            secret="glpat-abc123",
            provider=Provider.GITLAB,
            service_account_id="acc-2"
        )
        headers = cred.get_auth_header()
        assert headers == {"Private-Token": "glpat-abc123"}
        
        # API Key
        cred = ResolvedCredential(
            auth_type=AuthType.API_KEY,
            secret="api-key-123",
            provider=Provider.N8N,
            service_account_id="acc-3"
        )
        headers = cred.get_auth_header()
        assert headers == {"X-API-Key": "api-key-123"}
        
        # Basic auth
        cred = ResolvedCredential(
            auth_type=AuthType.BASIC,
            secret="dXNlcjpwYXNz",  # "user:pass" base64 encoded
            provider=Provider.GENERIC,
            service_account_id="acc-4"
        )
        headers = cred.get_auth_header()
        assert headers == {"Authorization": "Basic dXNlcjpwYXNz"}
    
    def test_inject_into_request(self):
        """Test injecting credential into request data."""
        cred = ResolvedCredential(
            auth_type=AuthType.BEARER,
            secret="test-token",
            provider=Provider.GITLAB,
            service_account_id="acc-1"
        )
        
        # Request without headers
        request_data = {"url": "https://api.example.com", "method": "GET"}
        injected = cred.inject_into_request(request_data)
        
        assert injected["headers"] == {"Authorization": "Bearer test-token"}
        assert injected["url"] == "https://api.example.com"
        assert injected["method"] == "GET"
        
        # Request with existing headers
        request_data = {
            "url": "https://api.example.com",
            "headers": {"Content-Type": "application/json"}
        }
        injected = cred.inject_into_request(request_data)
        
        assert injected["headers"] == {
            "Content-Type": "application/json",
            "Authorization": "Bearer test-token"
        }


class TestCredentialResolver:
    """Test CredentialResolver class."""
    
    @pytest.fixture
    def mock_manager(self):
        return Mock()
    
    @pytest.fixture
    def resolver(self, mock_manager):
        return CredentialResolver(mock_manager)
    
    def test_map_tool_to_provider(self, resolver):
        """Test mapping tool names to providers."""
        assert resolver.map_tool_to_provider("gitlab.create_issue") == Provider.GITLAB
        assert resolver.map_tool_to_provider("gitlab_merge_request") == Provider.GITLAB
        assert resolver.map_tool_to_provider("n8n.execute_workflow") == Provider.N8N
        assert resolver.map_tool_to_provider("mem0.search") == Provider.MEM0
        assert resolver.map_tool_to_provider("nextcloud_talk.send_message") == Provider.GENERIC
        assert resolver.map_tool_to_provider("matrix.send_message") == Provider.GENERIC
        assert resolver.map_tool_to_provider("unknown_tool") == Provider.GENERIC
    
    def test_resolve_for_tool_success(self, resolver, mock_manager):
        """Test successful credential resolution."""
        # Setup mock account
        mock_account = Mock(spec=ServiceAccount)
        mock_account.id = "acc-1"
        mock_account.auth_type = AuthType.BEARER
        mock_account.provider = Provider.GITLAB
        mock_account.allowed_scopes = ["read", "write"]
        
        # Setup manager to return account and secret
        mock_manager.get_secret_for_tool.return_value = (mock_account, "decrypted-secret-123")
        
        # Execute
        credential = resolver.resolve_for_tool(
            tenant_id="tenant-1",
            tool_name="gitlab.create_issue",
            provider=Provider.GITLAB,
            sandbox_level="restricted"
        )
        
        # Verify
        assert credential is not None
        assert credential.auth_type == AuthType.BEARER
        assert credential.secret == "decrypted-secret-123"
        assert credential.provider == Provider.GITLAB
        assert credential.service_account_id == "acc-1"
        
        # Verify manager was called
        mock_manager.get_secret_for_tool.assert_called_once_with(
            tenant_id="tenant-1",
            provider=Provider.GITLAB,
            tool_name="gitlab.create_issue",
            sandbox_level="restricted"
        )
    
    def test_resolve_for_tool_no_account(self, resolver, mock_manager):
        """Test credential resolution when no account exists."""
        # Setup manager to return None
        mock_manager.get_secret_for_tool.return_value = None
        
        # Execute
        credential = resolver.resolve_for_tool(
            tenant_id="tenant-1",
            tool_name="gitlab.create_issue",
            provider=Provider.GITLAB,
            sandbox_level="restricted"
        )
        
        # Verify
        assert credential is None
        mock_manager.get_secret_for_tool.assert_called_once()
    
    def test_resolve_and_inject_success(self, resolver, mock_manager):
        """Test successful credential resolution and injection."""
        # Setup mock account
        mock_account = Mock(spec=ServiceAccount)
        mock_account.id = "acc-1"
        mock_account.auth_type = AuthType.BEARER
        mock_account.provider = Provider.GITLAB
        
        # Setup manager to return account and secret
        mock_manager.get_secret_for_tool.return_value = (mock_account, "decrypted-secret-123")
        
        # Original request data
        request_data = {
            "url": "https://gitlab.com/api/v4/projects",
            "method": "GET"
        }
        
        # Execute
        injected_request, credential = resolver.resolve_and_inject(
            tenant_id="tenant-1",
            tool_name="gitlab.get_projects",
            request_data=request_data,
            sandbox_level="restricted"
        )
        
        # Verify
        assert injected_request is not None
        assert credential is not None
        
        # Check that auth header was added
        assert "headers" in injected_request
        assert injected_request["headers"] == {"Authorization": "Bearer decrypted-secret-123"}
        
        # Check original data preserved
        assert injected_request["url"] == "https://gitlab.com/api/v4/projects"
        assert injected_request["method"] == "GET"
    
    def test_resolve_and_inject_failure(self, resolver, mock_manager):
        """Test credential resolution failure."""
        # Setup manager to return None
        mock_manager.get_secret_for_tool.return_value = None
        
        # Original request data
        request_data = {"url": "https://example.com"}
        
        # Execute
        injected_request, credential = resolver.resolve_and_inject(
            tenant_id="tenant-1",
            tool_name="unknown.tool",
            request_data=request_data,
            sandbox_level="restricted"
        )
        
        # Verify
        assert injected_request is None
        assert credential is None
    
    def test_validate_tool_access(self, resolver):
        """Test tool access validation."""
        # Test with admin role
        assert resolver.validate_tool_access(
            tenant_id="tenant-1",
            tool_name="gitlab.create_issue",
            user_roles=["admin"]
        ) is True
        
        # Test with system role
        assert resolver.validate_tool_access(
            tenant_id="tenant-1",
            tool_name="gitlab.create_issue",
            user_roles=["system"]
        ) is True
        
        # Test with operator role
        assert resolver.validate_tool_access(
            tenant_id="tenant-1",
            tool_name="gitlab.create_issue",
            user_roles=["operator"]
        ) is True
        
        # Test with viewer role (should fail)
        assert resolver.validate_tool_access(
            tenant_id="tenant-1",
            tool_name="gitlab.create_issue",
            user_roles=["viewer"]
        ) is False
        
        # Test with guest role (should fail)
        assert resolver.validate_tool_access(
            tenant_id="tenant-1",
            tool_name="gitlab.create_issue",
            user_roles=["guest"]
        ) is False
        
        # Test with multiple roles including valid one
        assert resolver.validate_tool_access(
            tenant_id="tenant-1",
            tool_name="gitlab.create_issue",
            user_roles=["viewer", "operator", "guest"]
        ) is True
    
    def test_resolve_for_tool_exception(self, resolver, mock_manager):
        """Test exception handling during credential resolution."""
        # Setup manager to raise exception
        mock_manager.get_secret_for_tool.side_effect = Exception("Test error")
        
        # Execute
        credential = resolver.resolve_for_tool(
            tenant_id="tenant-1",
            tool_name="gitlab.create_issue",
            provider=Provider.GITLAB,
            sandbox_level="restricted"
        )
        
        # Verify
        assert credential is None
        mock_manager.get_secret_for_tool.assert_called_once()


class TestCredentialResolverIntegration:
    """Integration tests for CredentialResolver."""
    
    def test_get_credential_resolver_singleton(self):
        """Test singleton pattern for credential resolver."""
        # Get first instance
        resolver1 = get_credential_resolver()
        assert isinstance(resolver1, CredentialResolver)
        
        # Get second instance - should be the same object
        resolver2 = get_credential_resolver()
        assert resolver2 is resolver1
    
    def test_resolver_with_encrypted_storage(self):
        """Test resolver with encrypted storage adapter."""
        # Create mocks
        mock_storage = Mock(spec=EncryptedStorageAdapter)
        mock_rbac = Mock()
        
        # Create manager with encrypted storage
        from core.vault.manager import ServiceAccountManager
        manager = ServiceAccountManager(mock_storage, mock_rbac)
        
        # Create resolver with manager
        resolver = CredentialResolver(manager)
        
        # Setup mock account
        mock_account = Mock(spec=ServiceAccount)
        mock_account.id = "acc-1"
        mock_account.auth_type = AuthType.BEARER
        mock_account.provider = Provider.GITLAB
        mock_account.status = ServiceAccountStatus.ACTIVE
        
        # Setup storage to return account
        mock_storage.list_accounts.return_value = [mock_account]
        mock_storage.get_secret.return_value = ("decrypted-secret", Mock())
        
        # Note: This test is simplified since we're mocking heavily
        # In a real integration test, we would use actual implementations
        assert resolver is not None