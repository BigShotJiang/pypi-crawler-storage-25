#!/usr/bin/env python3
"""
Test sending a message right now and checking response.
"""
import asyncio
import httpx
import sys
import os
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

async def test_now():
    """Test current state"""
    print("🚀 Testing current Nextcloud Talk integration...")
    
    url = "https://cloud.walter-consult.com"
    user = "HestiaOS"
    password = "dF48x-gteDz-a5cfE-qRiCz-GCTct"
    room_token = "6mvoe63h"
    
    headers = {
        "OCS-APIRequest": "true",
        "Accept": "application/json"
    }
    
    async with httpx.AsyncClient(verify=False, timeout=10.0) as client:
        # Check current messages
        print("📊 Checking current room state...")
        resp = await client.get(
            f"{url}/ocs/v1.php/apps/spreed/api/v1/chat/{room_token}?lookIntoFuture=0&limit=5",
            headers=headers,
            auth=(user, password)
        )
        
        if resp.status_code != 200:
            print(f"❌ Failed to get messages: {resp.status_code}")
            return
        
        data = resp.json()
        messages = data.get('ocs', {}).get('data', [])
        print(f"✅ Found {len(messages)} recent messages")
        
        for msg in messages:
            print(f"   - {msg.get('actorDisplayName')}: '{msg.get('message', '')[:50]}...'")
        
        # Send a test message
        print(f"\n💬 Sending test message...")
        test_message = "@hestia This is a test from Roo - please respond if you're working"
        resp = await client.post(
            f"{url}/ocs/v1.php/apps/spreed/api/v1/chat/{room_token}",
            headers=headers,
            auth=(user, password),
            json={"message": test_message}
        )
        
        if resp.status_code in [200, 201]:
            print(f"✅ Message sent: '{test_message[:50]}...'")
            
            # Wait for response
            print("⏳ Waiting 20 seconds for response...")
            await asyncio.sleep(20)
            
            # Check for response
            print("\n🔍 Checking for response...")
            resp = await client.get(
                f"{url}/ocs/v1.php/apps/spreed/api/v1/chat/{room_token}?lookIntoFuture=0&limit=10",
                headers=headers,
                auth=(user, password)
            )
            
            if resp.status_code == 200:
                data = resp.json()
                messages = data.get('ocs', {}).get('data', [])
                
                # Find Hestia responses
                hestia_responses = [m for m in messages if m.get('actorDisplayName') == 'HestiaOS']
                if hestia_responses:
                    print(f"✅ Hestia responded with {len(hestia_responses)} message(s)")
                    for msg in hestia_responses[-3:]:
                        print(f"   - '{msg.get('message', '')[:80]}...'")
                else:
                    print("❌ No response from Hestia")
            else:
                print(f"❌ Failed to check messages: {resp.status_code}")
        else:
            print(f"❌ Failed to send message: {resp.status_code}")

async def main():
    await test_now()

if __name__ == "__main__":
    asyncio.run(main())