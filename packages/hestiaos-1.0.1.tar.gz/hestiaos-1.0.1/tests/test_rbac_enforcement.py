#!/usr/bin/env python3
"""
Test RBAC Policy Enforcement and Integration.
"""

import unittest
import tempfile
import json
from pathlib import Path
from datetime import datetime, timedelta
from unittest.mock import patch

from core.rbac_system import (
    Role, Permission, RBACManager
)


class TestRBACEnforcement(unittest.TestCase):
    """Test RBAC policy enforcement and integration scenarios."""
    
    def setUp(self):
        """Set up test environment with policies."""
        # Create a temporary config file with test policies
        self.temp_dir = tempfile.mkdtemp()
        self.config_path = Path(self.temp_dir) / "rbac_policies.json"
        
        policies = [
            # Policy 1: Admin-only access to admin API
            {
                "resource": "/api/admin/*",
                "action": "*",
                "roles": ["admin"],
                "effect": "allow"
            },
            {
                "resource": "/api/admin/*",
                "action": "*",
                "roles": ["*"],
                "effect": "deny"
            },
            
            # Policy 2: Public read access to public API
            {
                "resource": "/api/public/*",
                "action": "read",
                "roles": ["*"],
                "effect": "allow"
            },
            
            # Policy 3: Time-based access to sensitive data
            {
                "resource": "/api/sensitive/*",
                "action": "*",
                "roles": ["operator", "admin"],
                "effect": "conditional",
                "conditions": {
                    "time_of_day": [9, 17]  # 9 AM to 5 PM
                }
            },
            
            # Policy 4: Day-based access
            {
                "resource": "/api/weekend/*",
                "action": "*",
                "roles": ["admin"],
                "effect": "conditional",
                "conditions": {
                    "day_of_week": [0, 1, 2, 3, 4]  # Monday-Friday only
                }
            },
            
            # Policy 5: Metadata-based access
            {
                "resource": "/api/metadata/*",
                "action": "*",
                "roles": ["operator", "admin"],
                "effect": "conditional",
                "conditions": {
                    "metadata": {
                        "department": "engineering"
                    }
                }
            }
        ]
        
        with open(self.config_path, 'w') as f:
            json.dump(policies, f)
        
        self.rbac = RBACManager(self.config_path)
        self.session_ids = []
    
    def tearDown(self):
        """Clean up test resources."""
        import shutil
        for session_id in self.session_ids:
            if session_id in self.rbac.user_contexts:
                del self.rbac.user_contexts[session_id]
        
        if self.temp_dir:
            shutil.rmtree(self.temp_dir)
    
    def _create_test_context(self, roles, username="testuser", metadata=None):
        """Helper to create a test user context."""
        context = self.rbac.create_user_context(
            user_id=f"user_{len(self.session_ids)}",
            username=username,
            roles=roles,
            session_id=f"test_session_{len(self.session_ids)}",
            ttl_hours=1,
            metadata=metadata or {}
        )
        self.session_ids.append(context.session_id)
        return context
    
    def test_policy_loading(self):
        """Test that policies are loaded correctly from config."""
        self.assertEqual(len(self.rbac.policies), 6)

        
        # Check first policy
        first_policy = self.rbac.policies[0]
        self.assertEqual(first_policy["resource"], "/api/admin/*")
        self.assertEqual(first_policy["action"], "*")
        self.assertEqual(first_policy["roles"], ["admin"])
        self.assertEqual(first_policy["effect"], "allow")
    
    def test_admin_only_access(self):
        """Test admin-only resource access."""
        # Create admin user
        admin_context = self._create_test_context([Role.ADMIN], "admin_user")
        
        # Create non-admin user
        viewer_context = self._create_test_context([Role.VIEWER], "viewer_user")
        
        # Admin should have access to admin API
        self.assertTrue(
            self.rbac.validate_access(
                admin_context.session_id,
                Permission.API_READ,
                resource="/api/admin/users"
            )
        )
        
        # Non-admin should NOT have access to admin API
        self.assertFalse(
            self.rbac.validate_access(
                viewer_context.session_id,
                Permission.API_READ,
                resource="/api/admin/users"
            )
        )
        
        # Even with correct permission, policy should block
        self.assertFalse(
            self.rbac.validate_access(
                viewer_context.session_id,
                Permission.READ,
                resource="/api/admin/users"
            )
        )
    
    def test_public_access(self):
        """Test public resource access."""
        # Create guest user
        guest_context = self._create_test_context([Role.GUEST], "guest_user")
        
        # Guest should have read access to public API
        self.assertTrue(
            self.rbac.validate_access(
                guest_context.session_id,
                Permission.READ,
                resource="/api/public/data"
            )
        )
        
        # Guest should NOT have write access to public API
        self.assertFalse(
            self.rbac.validate_access(
                guest_context.session_id,
                Permission.WRITE,
                resource="/api/public/data"
            )
        )
        
        # Admin should also have read access (inherited from public policy)
        admin_context = self._create_test_context([Role.ADMIN], "admin_user")
        self.assertTrue(
            self.rbac.validate_access(
                admin_context.session_id,
                Permission.READ,
                resource="/api/public/data"
            )
        )
    
    def test_time_based_access(self):
        """Test time-based conditional access."""
        # Create operator user
        operator_context = self._create_test_context([Role.OPERATOR], "operator_user")
        
        # Test during business hours (2 PM = 14)
        with patch('core.rbac_system.datetime') as mock_datetime:
            mock_datetime.now.return_value = datetime(2024, 1, 1, 14, 0, 0)
            mock_datetime.side_effect = lambda *args, **kwargs: datetime(*args, **kwargs)
            
            # Should have access during business hours
            self.assertTrue(
                self.rbac.validate_access(
                    operator_context.session_id,
                    Permission.READ,
                    resource="/api/sensitive/data"
                )
            )
        
        # Test outside business hours (8 PM = 20)
        with patch('core.rbac_system.datetime') as mock_datetime:
            mock_datetime.now.return_value = datetime(2024, 1, 1, 20, 0, 0)
            mock_datetime.side_effect = lambda *args, **kwargs: datetime(*args, **kwargs)
            
            # Should NOT have access outside business hours
            self.assertFalse(
                self.rbac.validate_access(
                    operator_context.session_id,
                    Permission.READ,
                    resource="/api/sensitive/data"
                )
            )
        
        # Guest should never have access (wrong role)
        guest_context = self._create_test_context([Role.GUEST], "guest_user")
        self.assertFalse(
            self.rbac.validate_access(
                guest_context.session_id,
                Permission.READ,
                resource="/api/sensitive/data"
            )
        )
    
    def test_day_based_access(self):
        """Test day-of-week conditional access."""
        # Create admin user
        admin_context = self._create_test_context([Role.ADMIN], "admin_user")
        
        # Test on Monday (weekday 0)
        with patch('core.rbac_system.datetime') as mock_datetime:
            mock_datetime.now.return_value = datetime(2024, 1, 1, 12, 0, 0)  # Monday
            mock_datetime.side_effect = lambda *args, **kwargs: datetime(*args, **kwargs)
            
            # Should have access on weekday
            self.assertTrue(
                self.rbac.validate_access(
                    admin_context.session_id,
                    Permission.READ,
                    resource="/api/weekend/data"
                )
            )
        
        # Test on Saturday (weekday 5)
        with patch('core.rbac_system.datetime') as mock_datetime:
            mock_datetime.now.return_value = datetime(2024, 1, 6, 12, 0, 0)  # Saturday
            mock_datetime.side_effect = lambda *args, **kwargs: datetime(*args, **kwargs)
            
            # Should NOT have access on weekend
            self.assertFalse(
                self.rbac.validate_access(
                    admin_context.session_id,
                    Permission.READ,
                    resource="/api/weekend/data"
                )
            )
    
    def test_metadata_based_access(self):
        """Test metadata-based conditional access."""
        # Create operator with correct metadata
        operator_eng_context = self._create_test_context(
            [Role.OPERATOR],
            "operator_eng",
            metadata={"department": "engineering"}
        )
        
        # Create operator with wrong metadata
        operator_sales_context = self._create_test_context(
            [Role.OPERATOR],
            "operator_sales",
            metadata={"department": "sales"}
        )
        
        # Create operator with no metadata
        operator_no_meta_context = self._create_test_context(
            [Role.OPERATOR],
            "operator_no_meta"
        )
        
        # Engineering operator should have access
        self.assertTrue(
            self.rbac.validate_access(
                operator_eng_context.session_id,
                Permission.READ,
                resource="/api/metadata/data"
            )
        )
        
        # Sales operator should NOT have access
        self.assertFalse(
            self.rbac.validate_access(
                operator_sales_context.session_id,
                Permission.READ,
                resource="/api/metadata/data"
            )
        )
        
        # Operator with no metadata should NOT have access
        self.assertFalse(
            self.rbac.validate_access(
                operator_no_meta_context.session_id,
                Permission.READ,
                resource="/api/metadata/data"
            )
        )
        
        # Admin with correct metadata should have access
        admin_eng_context = self._create_test_context(
            [Role.ADMIN],
            "admin_eng",
            metadata={"department": "engineering"}
        )
        
        self.assertTrue(
            self.rbac.validate_access(
                admin_eng_context.session_id,
                Permission.READ,
                resource="/api/metadata/data"
            )
        )
    
    def test_policy_evaluation_order(self):
        """Test that policies are evaluated in order."""
        # Create admin user
        admin_context = self._create_test_context([Role.ADMIN], "admin_user")
        
        # First policy allows admin access to /api/admin/*
        self.assertTrue(
            self.rbac.validate_access(
                admin_context.session_id,
                Permission.READ,
                resource="/api/admin/users"
            )
        )
        
        # Second policy denies everyone else - but admin is allowed by first policy
        # This tests that first matching policy applies
        
        # Create guest user
        guest_context = self._create_test_context([Role.GUEST], "guest_user")
        
        # Guest should be denied by second policy
        self.assertFalse(
            self.rbac.validate_access(
                guest_context.session_id,
                Permission.READ,
                resource="/api/admin/users"
            )
        )
    
    def test_resource_pattern_matching(self):
        """Test resource pattern matching in policies."""
        # Create test policies with patterns
        test_policies = [
            {
                "resource": "/api/v1/*",
                "action": "*",
                "roles": ["admin"],
                "effect": "allow"
            },
            {
                "resource": "/api/*/admin",
                "action": "*",
                "roles": ["admin"],
                "effect": "allow"
            },
            {
                "resource": "/specific/resource",
                "action": "*",
                "roles": ["admin"],
                "effect": "allow"
            }
        ]
        
        # Create temporary RBAC manager with test policies
        with tempfile.NamedTemporaryFile(mode='w', suffix='.json') as f:
            json.dump(test_policies, f)
            f.flush()
            
            test_rbac = RBACManager(Path(f.name))
            
            # Create admin user
            admin_context = test_rbac.create_user_context(
                user_id="test_admin",
                username="admin",
                roles=[Role.ADMIN],
                session_id="test_session"
            )
            
            # Test pattern matching
            self.assertTrue(
                test_rbac.validate_access(
                    "test_session",
                    Permission.READ,
                    resource="/api/v1/users"
                )
            )
            
            self.assertTrue(
                test_rbac.validate_access(
                    "test_session",
                    Permission.READ,
                    resource="/api/v2/admin"
                )
            )
            
            self.assertTrue(
                test_rbac.validate_access(
                    "test_session",
                    Permission.READ,
                    resource="/specific/resource"
                )
            )
            
            # Should not match
            self.assertFalse(
                test_rbac.validate_access(
                    "test_session",
                    Permission.READ,
                    resource="/api/v2/users"  # Not v1 and not ending with /admin
                )
            )
    
    def test_action_specific_policies(self):
        """Test action-specific policies."""
        test_policies = [
            {
                "resource": "/api/data/*",
                "action": "read",
                "roles": ["*"],
                "effect": "allow"
            },
            {
                "resource": "/api/data/*",
                "action": "write",
                "roles": ["operator", "admin"],
                "effect": "allow"
            }
        ]
        
        with tempfile.NamedTemporaryFile(mode='w', suffix='.json') as f:
            json.dump(test_policies, f)
            f.flush()
            
            test_rbac = RBACManager(Path(f.name))
            
            # Create guest and operator users
            guest_context = test_rbac.create_user_context(
                user_id="guest",
                username="guest",
                roles=[Role.GUEST],
                session_id="guest_session"
            )
            
            operator_context = test_rbac.create_user_context(
                user_id="operator",
                username="operator",
                roles=[Role.OPERATOR],
                session_id="operator_session"
            )
            
            # Guest can read but not write
            self.assertTrue(
                test_rbac.validate_access(
                    "guest_session",
                    Permission.READ,
                    resource="/api/data/records",
                    action="read"
                )
            )
            
            self.assertFalse(
                test_rbac.validate_access(
                    "guest_session",
                    Permission.WRITE,
                    resource="/api/data/records",
                    action="write"
                )
            )
            
            # Operator can both read and write
            self.assertTrue(
                test_rbac.validate_access(
                    "operator_session",
                    Permission.READ,
                    resource="/api/data/records",
                    action="read"
                )
            )
            
            self.assertTrue(
                test_rbac.validate_access(
                    "operator_session",
                    Permission.WRITE,
                    resource="/api/data/records",
                    action="write"
                )
            )
    
    def test_complex_policy_scenarios(self):
        """Test complex real-world policy scenarios."""
        complex_policies = [
            # Multi-role access to critical systems
            {
                "resource": "/api/critical/*",
                "action": "*",
                "roles": ["admin", "system"],
                "effect": "allow"
            },
            
            # Department-specific access with time restrictions
            {
                "resource": "/api/hr/*",
                "action": "*",
                "roles": ["admin", "operator"],
                "effect": "conditional",
                "conditions": {
                    "metadata": {
                        "department": "hr"
                    },
                    "time_of_day": [8, 18]
                }
            },
            
            # Emergency override
            {
                "resource": "/api/emergency/*",
                "action": "*",
                "roles": ["admin"],
                "effect": "allow"
            },
            {
                "resource": "/api/emergency/*",
                "action": "read",
                "roles": ["operator"],
                "effect": "allow",
                "conditions": {
                    "metadata": {
                        "emergency_override": "true"
                    }
                }
            }
        ]
        
        with tempfile.NamedTemporaryFile(mode='w', suffix='.json') as f:
            json.dump(complex_policies, f)
            f.flush()
            
            test_rbac = RBACManager(Path(f.name))
            
            # Test emergency override scenario
            admin_context = test_rbac.create_user_context(
                user_id="admin",
                username="admin",
                roles=[Role.ADMIN],
                session_id="admin_session"
            )
            
            operator_emergency_context = test_rbac.create_user_context(
                user_id="operator_emergency",
                username="operator_emergency",
                roles=[Role.OPERATOR],
                session_id="operator_emergency_session",
                metadata={"emergency_override": "true"}
            )
            
            operator_normal_context = test_rbac.create_user_context(
                user_id="operator_normal",
                username="operator_normal",
                roles=[Role.OPERATOR],
                session_id="operator_normal_session"
            )
            
            # Admin always has emergency access
            self.assertTrue(
                test_rbac.validate_access(
                    "admin_session",
                    Permission.READ,
                    resource="/api/emergency/shutdown"
                )
            )
            
            # Operator with emergency override can read
            self.assertTrue(
                test_rbac.validate_access(
                    "operator_emergency_session",
                    Permission.READ,
                    resource="/api/emergency/shutdown"
                )
            )
            
            # Normal operator cannot access emergency
            self.assertFalse(
                test_rbac.validate_access(
                    "operator_normal_session",
                    Permission.READ,
                    resource="/api/emergency/shutdown"
                )
            )
            
            # Test HR department access
            hr_operator_context = test_rbac.create_user_context(
                user_id="hr_operator",
                username="hr_operator",
                roles=[Role.OPERATOR],
                session_id="hr_operator_session",
                metadata={"department": "hr"}
            )
            
            # Mock business hours
            with patch('core.rbac_system.datetime') as mock_datetime:
                mock_datetime.now.return_value = datetime(2024, 1, 1, 12, 0, 0)  # Noon
                mock_datetime.side_effect = lambda *args, **kwargs: datetime(*args, **kwargs)
                
                # HR operator should have access during business hours
                self.assertTrue(
                    test_rbac.validate_access(
                        "hr_operator_session",
                        Permission.READ,
                        resource="/api/hr/employees"
                    )
                )


if __name__ == "__main__":
    unittest.main()