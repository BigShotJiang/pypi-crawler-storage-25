"""
Tests für den DriftMonitor (Observer).

Testet:
    - check() mit verschiedenen Metrics-Werten
    - Level-Wechsel-Logging
    - Kein Log bei gleichem Level
    - current_level-Property
    - reset()
    - Custom metrics_provider
"""

import logging
from typing import Dict
from unittest.mock import MagicMock, patch

import pytest
from core.governance.drift_policy import DriftLevel, DriftPolicyEngine
from core.governance.drift_monitor import DriftMonitor


@pytest.fixture
def engine():
    """Standard DriftPolicyEngine mit Default-Thresholds."""
    return DriftPolicyEngine()


@pytest.fixture
def metrics_provider():
    """Erstellt einen Metrics-Provider, der ein Dict zurückgibt."""
    def _provider(metrics: Dict[str, int] = None):
        if metrics is None:
            return {}
        return metrics
    return _provider


class TestDriftMonitorCheck:
    """Tests für die check()-Methode."""

    def test_clean_when_no_metrics(self, engine):
        """check() mit leerem Metrics-Dict → CLEAN."""
        monitor = DriftMonitor(engine, lambda: {})
        assert monitor.check() == DriftLevel.CLEAN

    def test_clean_when_counter_missing(self, engine):
        """check() wenn Counter nicht im Dict → CLEAN."""
        monitor = DriftMonitor(engine, lambda: {"other_metric": 999})
        assert monitor.check() == DriftLevel.CLEAN

    def test_clean_at_zero(self, engine):
        """check() mit counter=0 → CLEAN."""
        monitor = DriftMonitor(engine, lambda: {"event_bus_unexpected_return_total": 0})
        assert monitor.check() == DriftLevel.CLEAN

    def test_warning_at_11(self, engine):
        """check() mit counter=11 → WARNING."""
        monitor = DriftMonitor(engine, lambda: {"event_bus_unexpected_return_total": 11})
        assert monitor.check() == DriftLevel.WARNING

    def test_degraded_at_101(self, engine):
        """check() mit counter=101 → DEGRADED."""
        monitor = DriftMonitor(engine, lambda: {"event_bus_unexpected_return_total": 101})
        assert monitor.check() == DriftLevel.DEGRADED

    def test_breaker_at_501(self, engine):
        """check() mit counter=501 → BREAKER."""
        monitor = DriftMonitor(engine, lambda: {"event_bus_unexpected_return_total": 501})
        assert monitor.check() == DriftLevel.BREAKER

    def test_custom_metrics_provider_called(self, engine):
        """Der metrics_provider muss bei jedem check() aufgerufen werden."""
        mock_provider = MagicMock(return_value={"event_bus_unexpected_return_total": 0})
        monitor = DriftMonitor(engine, mock_provider)
        monitor.check()
        mock_provider.assert_called_once()


class TestDriftMonitorLevelChangeLogging:
    """Tests für das Logging bei Level-Wechseln."""

    def test_level_change_logged(self, engine):
        """Level-Wechsel muss geloggt werden."""
        monitor = DriftMonitor(engine, lambda: {"event_bus_unexpected_return_total": 11})
        with patch("core.governance.drift_monitor.system_logger.warning") as mock_log:
            monitor.check()
            mock_log.assert_called_once()
            args, kwargs = mock_log.call_args
            assert "DriftLevel changed to WARNING" in args[0]
            assert kwargs["extra"]["drift_level"] == "WARNING"
            assert kwargs["extra"]["counter_value"] == 11
            assert kwargs["extra"]["previous_level"] == "CLEAN"

    def test_no_log_on_same_level(self, engine):
        """Gleicher Level darf nicht erneut geloggt werden."""
        monitor = DriftMonitor(engine, lambda: {"event_bus_unexpected_return_total": 11})
        with patch("core.governance.drift_monitor.system_logger.warning") as mock_log:
            monitor.check()  # CLEAN → WARNING: logged
            monitor.check()  # WARNING → WARNING: NOT logged
            assert mock_log.call_count == 1

    def test_log_on_each_level_change(self, engine):
        """Jeder Level-Wechsel muss geloggt werden."""
        counter = [0]

        def provider():
            return {"event_bus_unexpected_return_total": counter[0]}

        monitor = DriftMonitor(engine, provider)
        with patch("core.governance.drift_monitor.system_logger.warning") as mock_log:
            counter[0] = 11
            monitor.check()  # CLEAN → WARNING: logged
            counter[0] = 101
            monitor.check()  # WARNING → DEGRADED: logged
            counter[0] = 501
            monitor.check()  # DEGRADED → BREAKER: logged
            assert mock_log.call_count == 3

    def test_log_contains_all_extra_fields(self, engine):
        """Der Log-Eintrag muss alle extra-Felder enthalten."""
        monitor = DriftMonitor(engine, lambda: {"event_bus_unexpected_return_total": 501})
        with patch("core.governance.drift_monitor.system_logger.warning") as mock_log:
            monitor.check()
            extra = mock_log.call_args[1]["extra"]
            assert "drift_level" in extra
            assert "drift_level_value" in extra
            assert "counter_value" in extra
            assert "previous_level" in extra
            assert "thresholds" in extra


class TestDriftMonitorCurrentLevel:
    """Tests für die current_level-Property."""

    def test_initial_level_is_clean(self, engine):
        """current_level muss initial CLEAN sein."""
        monitor = DriftMonitor(engine, lambda: {})
        assert monitor.current_level == DriftLevel.CLEAN

    def test_current_level_updates_after_check(self, engine):
        """current_level muss nach check() den neuen Level enthalten."""
        monitor = DriftMonitor(engine, lambda: {"event_bus_unexpected_return_total": 501})
        monitor.check()
        assert monitor.current_level == DriftLevel.BREAKER

    def test_current_level_without_check(self, engine):
        """current_level ohne vorherigen check() → CLEAN."""
        monitor = DriftMonitor(engine, lambda: {})
        assert monitor.current_level == DriftLevel.CLEAN


class TestDriftMonitorReset:
    """Tests für reset()."""

    def test_reset_sets_clean(self, engine):
        """reset() setzt current_level auf CLEAN zurück."""
        monitor = DriftMonitor(engine, lambda: {"event_bus_unexpected_return_total": 501})
        monitor.check()
        assert monitor.current_level == DriftLevel.BREAKER
        monitor.reset()
        assert monitor.current_level == DriftLevel.CLEAN

    def test_reset_does_not_affect_next_check(self, engine):
        """Nach reset() muss check() wieder den korrekten Level ermitteln."""
        monitor = DriftMonitor(engine, lambda: {"event_bus_unexpected_return_total": 501})
        monitor.check()
        monitor.reset()
        # Auch nach reset: counter=501 → BREAKER
        level = monitor.check()
        assert level == DriftLevel.BREAKER
