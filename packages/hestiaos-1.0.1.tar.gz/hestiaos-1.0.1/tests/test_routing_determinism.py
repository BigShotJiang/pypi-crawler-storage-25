"""
CI-CRT-032: Routing Determinism Logging — Tests.

Testet das vollständige Routing Decision Event-System:
1. RoutingDecision Dataclass + to_event_payload()
2. compute_context_hash() — Determinismus + Mode-Extraktion
3. publish_routing_decision() — Event Bus Integration
4. EGLBackendRouter — RoutingDecision wird bei allen Exit-Punkten publiziert
"""

import pytest
import json
import hashlib
from unittest.mock import AsyncMock, patch, MagicMock
from typing import Dict, Any, List, Optional

from core.backend.router_base import (
    RoutingDecision,
    RouterContext,
    BackendSelection,
    BackendType,
    BackendStatus,
    BackendConfig,
    compute_context_hash,
    publish_routing_decision,
    EVENT_ROUTING_DECISION,
)


# ============================================================================
# RoutingDecision Dataclass
# ============================================================================


class TestRoutingDecision:
    """Tests für den RoutingDecision Event-Dataclass (CI-CRT-032)."""

    def test_minimal_decision(self):
        """RoutingDecision mit minimalen Pflichtfeldern."""
        decision = RoutingDecision(
            trace_id="trace-123",
            selected_backend="expert_gpu",
            candidate_backends=["expert_gpu", "community_cpu"],
            reason="preferred_backend_healthy",
            context_hash="abc123",
        )
        assert decision.trace_id == "trace-123"
        assert decision.selected_backend == "expert_gpu"
        assert decision.candidate_backends == ["expert_gpu", "community_cpu"]
        assert decision.reason == "preferred_backend_healthy"
        assert decision.context_hash == "abc123"
        assert decision.task_type == "unknown"  # default
        assert decision.mode == "community"  # default
        assert decision.fallback_used is False
        assert decision.fallback_chain == []
        assert decision.timestamp > 0

    def test_full_decision(self):
        """RoutingDecision mit allen Feldern."""
        decision = RoutingDecision(
            trace_id="trace-456",
            selected_backend="fallback_cpu",
            candidate_backends=["expert_gpu", "community_cpu", "fallback_cpu"],
            reason="fallback_backend_selected",
            context_hash="def456",
            task_type="code_generation",
            mode="business",
            fallback_used=True,
            fallback_chain=["expert_gpu", "community_cpu"],
        )
        assert decision.task_type == "code_generation"
        assert decision.mode == "business"
        assert decision.fallback_used is True
        assert decision.fallback_chain == ["expert_gpu", "community_cpu"]

    def test_selected_backend_none(self):
        """RoutingDecision wenn kein Backend verfügbar."""
        decision = RoutingDecision(
            trace_id="trace-789",
            selected_backend=None,
            candidate_backends=["expert_gpu"],
            reason="no_healthy_backend",
            context_hash="ghi789",
        )
        assert decision.selected_backend is None

    def test_to_event_payload_minimal(self):
        """to_event_payload() erzeugt korrektes Dict."""
        decision = RoutingDecision(
            trace_id="trace-123",
            selected_backend="expert_gpu",
            candidate_backends=["expert_gpu"],
            reason="preferred_backend_healthy",
            context_hash="abc123",
        )
        payload = decision.to_event_payload()

        assert payload["event_type"] == EVENT_ROUTING_DECISION
        assert payload["trace_id"] == "trace-123"
        assert payload["selected_backend"] == "expert_gpu"
        assert payload["candidate_backends"] == ["expert_gpu"]
        assert payload["reason"] == "preferred_backend_healthy"
        assert payload["context_hash"] == "abc123"
        assert payload["task_type"] == "unknown"
        assert payload["mode"] == "community"
        assert payload["fallback_used"] is False
        assert payload["fallback_chain"] == []
        assert isinstance(payload["timestamp"], float)

    def test_to_event_payload_full(self):
        """to_event_payload() mit allen Feldern."""
        decision = RoutingDecision(
            trace_id="trace-456",
            selected_backend="fallback_cpu",
            candidate_backends=["expert_gpu", "fallback_cpu"],
            reason="fallback_backend_selected",
            context_hash="def456",
            task_type="code_review",
            mode="science",
            fallback_used=True,
            fallback_chain=["expert_gpu"],
        )
        payload = decision.to_event_payload()

        assert payload["task_type"] == "code_review"
        assert payload["mode"] == "science"
        assert payload["fallback_used"] is True
        assert payload["fallback_chain"] == ["expert_gpu"]

    def test_to_event_payload_none_backend(self):
        """to_event_payload() wenn kein Backend gewählt."""
        decision = RoutingDecision(
            trace_id="trace-789",
            selected_backend=None,
            candidate_backends=["expert_gpu"],
            reason="no_healthy_backend",
            context_hash="ghi789",
        )
        payload = decision.to_event_payload()
        assert payload["selected_backend"] is None


# ============================================================================
# compute_context_hash
# ============================================================================


class TestComputeContextHash:
    """Tests für compute_context_hash() (CI-CRT-032)."""

    def test_deterministic_hash(self):
        """Gleicher Input → gleicher Hash."""
        ctx1 = RouterContext(
            candidate_agents=["expert_gpu", "community_cpu"],
            execution_state={"mode": "business"},
            trace_id="trace-1",
            task_type="code_gen",
        )
        ctx2 = RouterContext(
            candidate_agents=["expert_gpu", "community_cpu"],
            execution_state={"mode": "business"},
            trace_id="trace-2",  # trace_id ändert sich — sollte Hash nicht beeinflussen
            task_type="code_gen",
        )
        h1 = compute_context_hash(ctx1)
        h2 = compute_context_hash(ctx2)
        assert h1 == h2, "Hash muss deterministisch sein (trace_id darf nicht eingehen)"

    def test_different_candidates_different_hash(self):
        """Unterschiedliche candidate_agents → unterschiedlicher Hash."""
        ctx1 = RouterContext(
            candidate_agents=["expert_gpu"],
            execution_state={"mode": "business"},
            trace_id="trace-1",
            task_type="code_gen",
        )
        ctx2 = RouterContext(
            candidate_agents=["community_cpu"],
            execution_state={"mode": "business"},
            trace_id="trace-1",
            task_type="code_gen",
        )
        assert compute_context_hash(ctx1) != compute_context_hash(ctx2)

    def test_different_mode_different_hash(self):
        """Unterschiedlicher Mode → unterschiedlicher Hash."""
        ctx1 = RouterContext(
            candidate_agents=["expert_gpu"],
            execution_state={"mode": "business"},
            trace_id="trace-1",
            task_type="code_gen",
        )
        ctx2 = RouterContext(
            candidate_agents=["expert_gpu"],
            execution_state={"mode": "science"},
            trace_id="trace-1",
            task_type="code_gen",
        )
        assert compute_context_hash(ctx1) != compute_context_hash(ctx2)

    def test_different_task_type_different_hash(self):
        """Unterschiedlicher task_type → unterschiedlicher Hash."""
        ctx1 = RouterContext(
            candidate_agents=["expert_gpu"],
            execution_state={"mode": "business"},
            trace_id="trace-1",
            task_type="code_gen",
        )
        ctx2 = RouterContext(
            candidate_agents=["expert_gpu"],
            execution_state={"mode": "business"},
            trace_id="trace-1",
            task_type="code_review",
        )
        assert compute_context_hash(ctx1) != compute_context_hash(ctx2)

    def test_mode_from_execution_context_object(self):
        """Mode wird aus ExecutionContext-Objekt extrahiert."""
        class FakeExecutionContext:
            mode = "science"

        ctx = RouterContext(
            candidate_agents=["expert_gpu"],
            execution_state=FakeExecutionContext(),
            trace_id="trace-1",
            task_type="research",
        )
        h = compute_context_hash(ctx)
        assert isinstance(h, str)
        assert len(h) == 16  # SHA256 truncated to 16 chars

    def test_mode_default_community(self):
        """Ohne mode-Feld → default 'community'."""
        ctx = RouterContext(
            candidate_agents=["expert_gpu"],
            execution_state={},
            trace_id="trace-1",
            task_type="code_gen",
        )
        h = compute_context_hash(ctx)
        assert isinstance(h, str)
        assert len(h) == 16

    def test_hash_length(self):
        """Hash ist immer 16 Zeichen hex."""
        ctx = RouterContext(
            candidate_agents=["a", "b"],
            execution_state={"mode": "community"},
            trace_id="trace-1",
            task_type="test",
        )
        h = compute_context_hash(ctx)
        assert len(h) == 16
        # Validiere dass es hex ist
        int(h, 16)


# ============================================================================
# publish_routing_decision
# ============================================================================


class TestPublishRoutingDecision:
    """Tests für publish_routing_decision() (CI-CRT-032).

    Hinweis: event_bus wird per `from core.event_bus import event_bus` importiert
    (lokaler Name in publish_routing_decision), daher mocken wir die Funktion selbst
    und testen stattdessen die Logik über die EGLBackendRouter-Integrationstests.
    """

    def test_decision_to_payload_contract(self):
        """RoutingDecision → to_event_payload() erfüllt den Event-Contract."""
        decision = RoutingDecision(
            trace_id="trace-123",
            selected_backend="expert_gpu",
            candidate_backends=["expert_gpu", "community_cpu"],
            reason="preferred_backend_healthy",
            context_hash="abc123",
            task_type="code_gen",
            mode="business",
        )
        payload = decision.to_event_payload()

        # Contract: alle Felder die der Event Bus erwartet
        assert "event_type" in payload
        assert "trace_id" in payload
        assert "selected_backend" in payload
        assert "candidate_backends" in payload
        assert "reason" in payload
        assert "context_hash" in payload
        assert "task_type" in payload
        assert "mode" in payload
        assert "fallback_used" in payload
        assert "fallback_chain" in payload
        assert "timestamp" in payload

        # Contract: event_type ist korrekt
        assert payload["event_type"] == EVENT_ROUTING_DECISION

    def test_publish_routing_decision_is_callable(self):
        """publish_routing_decision ist eine aufrufbare Funktion."""
        assert callable(publish_routing_decision)

    def test_compute_context_hash_is_callable(self):
        """compute_context_hash ist eine aufrufbare Funktion."""
        assert callable(compute_context_hash)


# ============================================================================
# EGLBackendRouter Integration
# ============================================================================


class FakeExecutionContext:
    """Minimaler ExecutionContext für Tests."""
    def __init__(self, mode: str = "community"):
        self.mode = mode


class TestEGLBackendRouterRoutingDecision:
    """Testet dass EGLBackendRouter bei allen Exit-Punkten RoutingDecision published."""

    @pytest.mark.asyncio
    async def test_preferred_backend_publishes_decision(self):
        """Exit 1: preferred backend healthy → RoutingDecision wird published."""
        from enterprise.egl.backend_router import EGLBackendRouter

        router = EGLBackendRouter(config_path="nonexistent.yaml")
        # Emergency fallback ist registriert

        context = RouterContext(
            candidate_agents=["emergency_fallback"],
            execution_state=FakeExecutionContext(mode="community"),
            trace_id="trace-preferred",
            task_type="test",
        )

        with patch.object(router, "get_health_status", return_value=BackendStatus.HEALTHY):
            with patch("enterprise.egl.backend_router.publish_routing_decision") as mock_publish:
                result = await router.select_backend(context)

                assert result is not None
                assert result.backend_id == "emergency_fallback"
                mock_publish.assert_called_once()
                decision = mock_publish.call_args[0][0]
                assert isinstance(decision, RoutingDecision)
                assert decision.trace_id == "trace-preferred"
                assert decision.selected_backend == "emergency_fallback"
                assert decision.reason == "preferred_backend_healthy"

    @pytest.mark.asyncio
    async def test_fallback_backend_publishes_decision(self):
        """Exit 2: preferred unhealthy, fallback healthy → RoutingDecision mit fallback_used=True."""
        from enterprise.egl.backend_router import EGLBackendRouter

        router = EGLBackendRouter(config_path="nonexistent.yaml")

        # Registriere zwei Backends
        router.backends["preferred"] = BackendConfig(
            backend_id="preferred",
            backend_type=BackendType.MOCK,
            endpoint="http://localhost:1",
            model="test",
            mode="community",
            priority=1,
        )
        router.backends["fallback"] = BackendConfig(
            backend_id="fallback",
            backend_type=BackendType.MOCK,
            endpoint="http://localhost:2",
            model="test",
            mode="community",
            priority=2,
        )

        context = RouterContext(
            candidate_agents=["preferred"],
            execution_state=FakeExecutionContext(mode="community"),
            trace_id="trace-fallback",
            task_type="test",
        )

        # preferred ist unhealthy, fallback ist healthy
        async def mock_health(backend_id):
            if backend_id == "preferred":
                return BackendStatus.UNHEALTHY
            return BackendStatus.HEALTHY

        with patch.object(router, "get_health_status", side_effect=mock_health):
            with patch("enterprise.egl.backend_router.publish_routing_decision") as mock_publish:
                result = await router.select_backend(context)

                assert result is not None
                assert result.backend_id == "fallback"
                assert result.fallback_used is True
                mock_publish.assert_called_once()
                decision = mock_publish.call_args[0][0]
                assert isinstance(decision, RoutingDecision)
                assert decision.trace_id == "trace-fallback"
                assert decision.selected_backend == "fallback"
                assert decision.reason == "fallback_backend_selected"
                assert decision.fallback_used is True
                assert "preferred" in decision.fallback_chain

    @pytest.mark.asyncio
    async def test_no_healthy_backend_publishes_decision(self):
        """Exit 3: kein Backend gesund → RoutingDecision mit selected_backend=None."""
        from enterprise.egl.backend_router import EGLBackendRouter

        router = EGLBackendRouter(config_path="nonexistent.yaml")

        # Nur emergency fallback — den markieren wir als unhealthy
        context = RouterContext(
            candidate_agents=["emergency_fallback"],
            execution_state=FakeExecutionContext(mode="community"),
            trace_id="trace-none",
            task_type="test",
        )

        with patch.object(router, "get_health_status", return_value=BackendStatus.UNHEALTHY):
            with patch("enterprise.egl.backend_router.publish_routing_decision") as mock_publish:
                result = await router.select_backend(context)

                assert result is None
                mock_publish.assert_called_once()
                decision = mock_publish.call_args[0][0]
                assert isinstance(decision, RoutingDecision)
                assert decision.trace_id == "trace-none"
                assert decision.selected_backend is None
                assert decision.reason == "no_healthy_backend"

    @pytest.mark.asyncio
    async def test_no_backends_for_mode_publishes_decision(self):
        """Exit 4: kein Backend für Mode → RoutingDecision mit selected_backend=None + reason='no_backends_for_mode'."""
        from enterprise.egl.backend_router import EGLBackendRouter

        router = EGLBackendRouter(config_path="nonexistent.yaml")
        # Emergency fallback hat mode="community" — wir fragen mode="science"
        # Da emergency_fallback mode="community" hat, wird es durch den Filter
        # "b.mode == mode or b.mode == 'community'" trotzdem gefunden.
        # Also müssen wir den emergency fallback entfernen, um diesen Pfad zu testen.
        router.backends.clear()

        context = RouterContext(
            candidate_agents=["science_gpu"],
            execution_state=FakeExecutionContext(mode="science"),
            trace_id="trace-nomode",
            task_type="test",
        )

        with patch("enterprise.egl.backend_router.publish_routing_decision") as mock_publish:
            result = await router.select_backend(context)

            assert result is None
            mock_publish.assert_called_once()
            decision = mock_publish.call_args[0][0]
            assert isinstance(decision, RoutingDecision)
            assert decision.trace_id == "trace-nomode"
            assert decision.selected_backend is None
            assert decision.reason == "no_backends_for_mode"

    @pytest.mark.asyncio
    async def test_context_hash_included_in_decision(self):
        """context_hash wird korrekt berechnet und in RoutingDecision übernommen."""
        from enterprise.egl.backend_router import EGLBackendRouter

        router = EGLBackendRouter(config_path="nonexistent.yaml")

        context = RouterContext(
            candidate_agents=["emergency_fallback"],
            execution_state=FakeExecutionContext(mode="community"),
            trace_id="trace-hash",
            task_type="test",
        )

        expected_hash = compute_context_hash(context)

        with patch.object(router, "get_health_status", return_value=BackendStatus.HEALTHY):
            with patch("enterprise.egl.backend_router.publish_routing_decision") as mock_publish:
                await router.select_backend(context)

                decision = mock_publish.call_args[0][0]
                assert decision.context_hash == expected_hash


# ============================================================================
# Event Bus Subscription Test
# ============================================================================


class TestEventBusSubscription:
    """Testet dass RoutingDecision-Events über den Event Bus empfangen werden können.

    Hinweis: Der globale event_bus in core/event_bus/__init__.py hat einen
    Pre-Existing Circular Import (core/agent_legacy → core/orchestrator).
    Daher testen wir hier mit einer isolierten EventBus-Instanz, die wir
    direkt aus core/event_bus.py importieren (ohne den __init__.py-Pfad).
    """

    @pytest.mark.asyncio
    async def test_can_subscribe_to_routing_decision_events(self):
        """Man kann sich auf EVENT_ROUTING_DECISION subscriben."""
        # Isolierter Import: core/event_bus.py direkt, nicht core/event_bus/__init__.py
        import importlib.util
        spec = importlib.util.spec_from_file_location(
            "core.event_bus_module",
            "core/event_bus.py"
        )
        event_bus_module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(event_bus_module)

        bus = event_bus_module.EventBus()
        received_events = []

        async def handler(payload):
            received_events.append(payload)

        bus.subscribe(EVENT_ROUTING_DECISION, handler)

        # Publiziere direkt
        await bus.publish(EVENT_ROUTING_DECISION, {
            "event_type": EVENT_ROUTING_DECISION,
            "trace_id": "trace-sub",
            "selected_backend": "expert_gpu",
            "candidate_backends": ["expert_gpu"],
            "reason": "test",
            "context_hash": "abc",
            "task_type": "test",
            "mode": "community",
            "fallback_used": False,
            "fallback_chain": [],
            "timestamp": 12345.0,
        })

        assert len(received_events) == 1
        assert received_events[0]["trace_id"] == "trace-sub"
        assert received_events[0]["selected_backend"] == "expert_gpu"

    @pytest.mark.asyncio
    async def test_multiple_subscribers_all_receive(self):
        """Alle Subscriber erhalten das RoutingDecision-Event."""
        import importlib.util
        spec = importlib.util.spec_from_file_location(
            "core.event_bus_module",
            "core/event_bus.py"
        )
        event_bus_module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(event_bus_module)

        bus = event_bus_module.EventBus()
        received_1 = []
        received_2 = []

        async def handler1(payload):
            received_1.append(payload)

        async def handler2(payload):
            received_2.append(payload)

        bus.subscribe(EVENT_ROUTING_DECISION, handler1)
        bus.subscribe(EVENT_ROUTING_DECISION, handler2)

        await bus.publish(EVENT_ROUTING_DECISION, {
            "event_type": EVENT_ROUTING_DECISION,
            "trace_id": "trace-multi",
            "selected_backend": "expert_gpu",
            "candidate_backends": ["expert_gpu"],
            "reason": "test",
            "context_hash": "abc",
            "task_type": "test",
            "mode": "community",
            "fallback_used": False,
            "fallback_chain": [],
            "timestamp": 12345.0,
        })

        assert len(received_1) == 1
        assert len(received_2) == 1
        assert received_1[0]["trace_id"] == "trace-multi"
        assert received_2[0]["trace_id"] == "trace-multi"
