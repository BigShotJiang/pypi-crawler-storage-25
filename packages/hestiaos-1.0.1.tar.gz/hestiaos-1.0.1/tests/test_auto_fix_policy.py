#!/usr/bin/env python3
"""
Test Auto-Fix Policy

This test validates the HSP policy for governing automatic code fixes.
"""

import sys
import os
import asyncio
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from core.hsp.policies.auto_fix_policy import AutoFixPolicy, CodeOwnershipLevel, AutoFixRiskLevel
from core.hsp.schemas import HSPRequestSchema


async def test_policy_evaluation():
    """Test basic policy evaluation"""
    print("Testing policy evaluation...")
    
    policy = AutoFixPolicy()
    
    # Create test fixes
    test_fixes = [
        {
            "fix_id": "eval_to_safe_eval",
            "fix_type": "security",
            "confidence": 0.95,
            "description": "Replace eval() with safe_eval()",
            "line_number": 10
        },
        {
            "fix_id": "hardcoded_password",
            "fix_type": "security_high_risk",
            "confidence": 0.8,
            "description": "Replace hardcoded password with env var",
            "line_number": 15
        },
        {
            "fix_id": "password_variable_name",
            "fix_type": "security_low_risk",
            "confidence": 0.6,
            "description": "Rename password variable",
            "line_number": 20
        }
    ]
    
    # Test case 1: Application code in staging
    context1 = {
        "file_path": "/home/user/project/app/auth.py",
        "security_level": "high",
        "environment": "staging",
        "contains_secrets": True,
        "current_changes_in_file": 0,
        "has_approval": True
    }
    
    request1 = HSPRequestSchema(
        request_id="test_1",
        trace_id="trace_1",
        timestamp="2024-01-01T00:00:00Z",
        context=context1,
        source="test",
        metadata={}
    )
    
    constraints1 = await policy.evaluate(request1, test_fixes, context1)
    
    print(f"  Test 1 - Application code in staging:")
    print(f"    Is valid: {constraints1.is_valid}")
    print(f"    Allowed fixes: {len(constraints1.metadata.get('allowed_fixes', []))}")
    print(f"    Denied fixes: {len(constraints1.metadata.get('denied_fixes', []))}")
    
    assert constraints1.is_valid == True, "Should be valid for application code"
    assert len(constraints1.metadata.get('allowed_fixes', [])) > 0, "Should allow some fixes"
    
    # Test case 2: Core code (should be more restrictive)
    context2 = {
        "file_path": "/home/user/project/core/engine.py",
        "security_level": "high",
        "environment": "development",
        "contains_secrets": False,
        "current_changes_in_file": 0,
        "has_approval": False
    }
    
    request2 = HSPRequestSchema(
        request_id="test_2",
        trace_id="trace_2",
        timestamp="2024-01-01T00:00:00Z",
        context=context2,
        source="test",
        metadata={}
    )
    
    constraints2 = await policy.evaluate(request2, test_fixes, context2)
    
    print(f"  Test 2 - Core code:")
    print(f"    Is valid: {constraints2.is_valid}")
    print(f"    Allowed fixes: {len(constraints2.metadata.get('allowed_fixes', []))}")
    print(f"    Denied fixes: {len(constraints2.metadata.get('denied_fixes', []))}")
    
    # Core code should be more restrictive
    assert len(constraints2.metadata.get('allowed_fixes', [])) <= len(constraints1.metadata.get('allowed_fixes', [])), \
        "Core code should have fewer allowed fixes"
    
    # Test case 3: Production environment (should be most restrictive)
    context3 = {
        "file_path": "/home/user/project/app/api.py",
        "security_level": "high",
        "environment": "production",
        "contains_secrets": False,
        "current_changes_in_file": 0,
        "has_approval": True
    }
    
    request3 = HSPRequestSchema(
        request_id="test_3",
        trace_id="trace_3",
        timestamp="2024-01-01T00:00:00Z",
        context=context3,
        source="test",
        metadata={}
    )
    
    constraints3 = await policy.evaluate(request3, test_fixes, context3)
    
    print(f"  Test 3 - Production environment:")
    print(f"    Is valid: {constraints3.is_valid}")
    print(f"    Allowed fixes: {len(constraints3.metadata.get('allowed_fixes', []))}")
    print(f"    Denied fixes: {len(constraints3.metadata.get('denied_fixes', []))}")
    
    # Production should be most restrictive
    production_allowed = len(constraints3.metadata.get('allowed_fixes', []))
    staging_allowed = len(constraints1.metadata.get('allowed_fixes', []))
    assert production_allowed <= staging_allowed, "Production should have fewer allowed fixes than staging"
    
    print("  ✓ Policy evaluation test passed")
    return True


def test_ownership_detection():
    """Test code ownership detection"""
    print("Testing ownership detection...")
    
    policy = AutoFixPolicy()
    
    test_cases = [
        ("/home/user/project/core/engine.py", CodeOwnershipLevel.CORE),
        ("/home/user/project/lib/utils.py", CodeOwnershipLevel.LIBRARY),
        ("/home/user/project/app/main.py", CodeOwnershipLevel.APPLICATION),
        ("/home/user/project/tests/test_auth.py", CodeOwnershipLevel.TEST),
        ("/home/user/project/vendor/external_lib.py", CodeOwnershipLevel.EXTERNAL),
        ("/home/user/project/unknown.py", CodeOwnershipLevel.APPLICATION)  # Default
    ]
    
    for file_path, expected_ownership in test_cases:
        context = {"file_path": file_path}
        ownership = policy._determine_code_ownership(file_path, context)
        
        print(f"  {file_path} -> {ownership.value} (expected: {expected_ownership.value})")
        assert ownership == expected_ownership, \
            f"Expected {expected_ownership.value} for {file_path}, got {ownership.value}"
    
    print("  ✓ Ownership detection test passed")
    return True


def test_risk_assessment():
    """Test risk assessment for different fix types"""
    print("Testing risk assessment...")
    
    policy = AutoFixPolicy()
    
    # Check risk profiles
    risk_profiles = policy.fix_risk_profiles
    
    print(f"  Risk profiles defined: {len(risk_profiles)}")
    assert len(risk_profiles) > 0, "Should have risk profiles defined"
    
    # Check specific risk levels
    assert risk_profiles["eval_to_safe_eval"]["risk_level"] == AutoFixRiskLevel.LOW
    assert risk_profiles["subprocess_shell_false"]["risk_level"] == AutoFixRiskLevel.MEDIUM
    assert risk_profiles["hardcoded_password"]["risk_level"] == AutoFixRiskLevel.HIGH
    
    print("  ✓ Risk assessment test passed")
    return True


def test_fix_allowance_logic():
    """Test fix allowance logic"""
    print("Testing fix allowance logic...")
    
    policy = AutoFixPolicy()
    
    # Test cases: (fix_id, confidence, code_ownership, is_production, expected_allowed, expected_reason_contains)
    test_cases = [
        # Low risk fix in application code, non-production, high confidence -> allowed
        ("eval_to_safe_eval", 0.95, CodeOwnershipLevel.APPLICATION, False, True, "allowed"),
        
        # High risk fix in core code -> denied
        ("hardcoded_password", 0.9, CodeOwnershipLevel.CORE, False, False, "not allowed"),
        
        # Low confidence fix -> denied
        ("password_variable_name", 0.5, CodeOwnershipLevel.APPLICATION, False, False, "below minimum"),
        
        # High risk fix in production -> denied
        ("hardcoded_password", 0.8, CodeOwnershipLevel.APPLICATION, True, False, "not allowed in production"),
        
        # Test code with low risk fix -> allowed
        ("eval_to_safe_eval", 0.7, CodeOwnershipLevel.TEST, False, True, "allowed"),
    ]
    
    for i, (fix_id, confidence, ownership, is_prod, expected_allowed, expected_reason) in enumerate(test_cases, 1):
        context = {
            "has_approval": True,
            "current_changes_in_file": 0
        }
        
        is_allowed, reason = policy._is_fix_allowed(
            fix_id, "security", confidence, ownership, is_prod, context
        )
        
        print(f"  Test {i}: {fix_id} in {ownership.value} (prod: {is_prod}) -> allowed: {is_allowed}")
        print(f"    Reason: {reason}")
        
        assert is_allowed == expected_allowed, \
            f"Test {i}: Expected allowed={expected_allowed}, got {is_allowed}"
        
        assert expected_reason in reason.lower(), \
            f"Test {i}: Expected reason to contain '{expected_reason}', got '{reason}'"
    
    print("  ✓ Fix allowance logic test passed")
    return True


async def test_integration_with_ast_fix_engine():
    """Test integration with AST fix engine"""
    print("Testing integration with AST fix engine...")
    
    try:
        from core.capabilities.ast_fix_engine import ASTFixEngine
        
        # Create test code with security issues
        test_code = '''password = "secret123"

def insecure_function():
    result = eval("2 + 2")
    return result
'''
        
        # Generate fixes using AST fix engine
        fix_engine = ASTFixEngine()
        
        # Simulate Bandit findings
        bandit_findings = [
            {"test_id": "B105", "line_number": 1, "issue_text": "Hardcoded password string."},
            {"test_id": "B307", "line_number": 4, "issue_text": "Use of eval detected."}
        ]
        
        fixes = fix_engine.generate_fixes("test.py", test_code, bandit_findings)
        
        print(f"  AST fix engine generated {len(fixes)} fixes")
        
        if fixes:
            # Convert to policy format
            fix_proposals = []
            for fix in fixes:
                fix_proposals.append({
                    "fix_id": fix.bandit_test_id or fix.fix_id,
                    "fix_type": fix.fix_type.value,
                    "confidence": 0.8 if fix.confidence.value == "high" else 0.6,
                    "description": fix.description,
                    "line_number": fix.line_number
                })
            
            # Evaluate with policy
            policy = AutoFixPolicy()
            
            context = {
                "file_path": "test.py",
                "security_level": "medium",
                "environment": "staging",
                "contains_secrets": True,
                "current_changes_in_file": 0,
                "has_approval": True
            }
            
            request = HSPRequestSchema(
                request_id="integration_test",
                trace_id="integration_trace",
                timestamp="2024-01-01T00:00:00Z",
                context=context,
                source="test",
                metadata={}
            )
            
            constraints = await policy.evaluate(request, fix_proposals, context)
            
            print(f"  Policy allowed {len(constraints.metadata.get('allowed_fixes', []))} fixes")
            print(f"  Policy denied {len(constraints.metadata.get('denied_fixes', []))} fixes")
            
            # Should have some decision
            assert constraints.metadata.get('total_fixes_proposed', 0) == len(fix_proposals)
            
            print("  ✓ Integration test passed")
        else:
            print("  ⚠ No fixes generated, skipping integration test")
            
    except ImportError as e:
        print(f"  ⚠ AST fix engine not available: {e}")
    
    return True


async def run_all_tests():
    """Run all tests"""
    print("=" * 60)
    print("Auto-Fix Policy Test Suite")
    print("=" * 60)
    
    tests = [
        test_ownership_detection,
        test_risk_assessment,
        test_fix_allowance_logic,
        test_policy_evaluation,
        test_integration_with_ast_fix_engine
    ]
    
    passed = 0
    failed = 0
    
    for test in tests:
        try:
            if test.__name__.startswith("test_"):
                # Regular function
                if test():
                    passed += 1
            else:
                # Async function
                if await test():
                    passed += 1
        except Exception as e:
            print(f"  ✗ Test {test.__name__} failed: {e}")
            import traceback
            traceback.print_exc()
            failed += 1
    
    print("\n" + "=" * 60)
    print(f"Test Results: {passed} passed, {failed} failed")
    print("=" * 60)
    
    if failed == 0:
        print("✓ All tests passed!")
        return True
    else:
        print(f"✗ {failed} test(s) failed")
        return False


if __name__ == "__main__":
    # Run async tests
    success = asyncio.run(run_all_tests())
    sys.exit(0 if success else 1)