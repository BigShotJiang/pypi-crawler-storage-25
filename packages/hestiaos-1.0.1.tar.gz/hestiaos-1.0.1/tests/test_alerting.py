import asyncio
from datetime import datetime
from core.observability.consciousness_alerting import ConsciousnessAlertingSystem, AlertRule, AlertType, AlertSeverity, AlertState
from core.observability.consciousness_observability import HealthStatus

class MockProtocol:
    def __init__(self):
        self.agent_id = "TEST_AGENT"

class MockMetrics:
    def __init__(self):
        self.values = {}
    def aggregate_metrics(self, window_minutes=5):
        return {}

class MockObservability:
    def __init__(self):
        self.health_checks = {}
    def log_structured(self, **kwargs):
        pass

async def test_alert_triggering():
    protocol = MockProtocol()
    alert_system = ConsciousnessAlertingSystem(protocol)
    
    # Manually add a rule
    rule = AlertRule(
        rule_id="test_rule",
        name="Test Alert",
        alert_type=AlertType.METRIC_ANOMALY,
        severity=AlertSeverity.HIGH,
        condition={"type": "metric_threshold", "metric": "test_metric", "threshold": 100},
        auto_resolve=True
    )
    alert_system.add_alert_rule(rule)
    
    # Record a value that triggers the alert
    alert_system.record_metric_value("test_metric", 150)
    
    # Check conditions
    print(f"Checking conditions for {rule.rule_id}...")
    met = await alert_system._evaluate_condition(rule.condition)
    print(f"Condition met: {met}")
    
    await alert_system._check_alert_conditions()
    
    active_alerts = alert_system.get_active_alerts(rule_id="test_rule")
    print(f"Active alerts: {len(active_alerts)}")
    assert len(active_alerts) == 1
    assert active_alerts[0].state == AlertState.ACTIVE

async def test_alert_resolution():
    protocol = MockProtocol()
    alert_system = ConsciousnessAlertingSystem(protocol)
    
    rule = AlertRule(
        rule_id="res_rule",
        name="Resolution Test",
        alert_type=AlertType.METRIC_ANOMALY,
        severity=AlertSeverity.LOW,
        condition={"type": "metric_threshold", "metric": "test_metric", "threshold": 100},
        auto_resolve=True
    )
    alert_system.add_alert_rule(rule)
    
    # Trigger
    alert_system.record_metric_value("test_metric", 150)
    await alert_system._check_alert_conditions()
    assert len(alert_system.get_active_alerts(rule_id="res_rule")) == 1
    
    # Resolve (condition cleared)
    alert_system.record_metric_value("test_metric", 50)
    await alert_system._check_alert_conditions()
    assert len(alert_system.get_active_alerts(rule_id="res_rule")) == 0

async def test_anomaly_detection():
    protocol = MockProtocol()
    alert_system = ConsciousnessAlertingSystem(protocol)
    
    rule = AlertRule(
        rule_id="anomaly_rule",
        name="Anomaly Test",
        alert_type=AlertType.METRIC_ANOMALY,
        severity=AlertSeverity.MEDIUM,
        condition={"type": "anomaly_detection", "metric": "test_metric", "sigma_threshold": 2.0},
        auto_resolve=False
    )
    alert_system.add_alert_rule(rule)
    
    # Build history
    for _ in range(10):
        alert_system.record_metric_value("test_metric", 10.0)
    
    # Change one value slightly to avoid zero stdev
    alert_system.record_metric_value("test_metric", 11.0)
    
    # Now record anomaly
    alert_system.record_metric_value("test_metric", 100.0)
    
    await alert_system._check_alert_conditions()
    assert len(alert_system.get_active_alerts(rule_id="anomaly_rule")) == 1

async def main():
    await test_alert_triggering()
    await test_alert_resolution()
    await test_anomaly_detection()
    print("✅ All alerting tests passed!")

if __name__ == "__main__":
    asyncio.run(main())
