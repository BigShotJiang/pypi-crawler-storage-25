import asyncio
import sys
import os
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from core.wave_engine import wave_engine, WaveStatus
from core.embedding_service import embedding_service

class TestRealWave(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        await embedding_service.startup()
        await wave_engine.llm_engine.startup()

    async def asyncTearDown(self):
        await embedding_service.shutdown()
        await wave_engine.llm_engine.shutdown()

    async def test_real_propagation_and_sync(self):
        tenant_id = "test-tenant-real"
        # A problem that can be split into reasoning (Mediator), expertise (Expert), and implementation (Worker)
        problem = "Design a distributed caching layer for HestiaOS that uses Redis and preserves tenant isolation."
        
        print(f"\n[1] Creating real wave for: '{problem}'")
        wave_id = await wave_engine.create_wave(problem, tenant_id)
        wave = wave_engine.waves[wave_id]
        
        print("[2] Preparing agents...")
        await wave_engine.prepare_propagation(wave_id)
        
        print("[3] Approving propagation (Checkpoint 1)...")
        await wave_engine.approve_propagation(wave_id, "admin-user")
        
        print("[4] Waiting for parallel propagation (Ollama)...")
        # Real LLM calls will take some time
        timeout = 400 # 6 minutes
        start_time = asyncio.get_event_loop().time()
        while wave["status"] != WaveStatus.PENDING_SYNCHRONIZATION:
            if asyncio.get_event_loop().time() - start_time > timeout:
                self.fail("Propagation timed out")
            await asyncio.sleep(2)
            print(f"  ... status: {wave['status']}")
            for agent in wave["agents"]:
                print(f"    - Agent {agent['agent_id']}: {agent['status']}")
        
        print(f"[5] Propagation completed. Synchronizing (Correlation ID: {wave_id})...")
        final_output = await wave_engine.synchronize(wave_id, "admin-user")
        
        self.assertIsNotNone(final_output)
        self.assertIn("REDIS", final_output.upper())
        self.assertIn("TENANT", final_output.upper())
        self.assertIn("conflict_score", wave)
        print(f"  Conflict Score: {wave['conflict_score']}")
        
        print("\n=== FINAL SYNCHRONIZED OUTPUT ===")
        print(final_output)
        print("===================================")

if __name__ == "__main__":
    unittest.main()
