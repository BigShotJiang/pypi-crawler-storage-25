"""
Phase E — Execution Observability Layer
=========================================
E8: Validierung — Vollständiger Integrationstest

Testet alle 7 Komponenten (CRT-konform, ADR-002):
1. Trace-Erzeugung (E1)
2. CounterfactualSpace (E2)
3. Dependency Ordering + Dependency Consistency (E3)
4. ExecutionTraceMiddleware (E4)
5. Deterministisches Replay (E5) — T2-MINIMAL
6. Integration (E6)
7. Factory (E7)

Testet alle Architektur-Constraints:
- CRT-Compliance (CI-CRT-001)
- Truth Layer Isolation (T1+T2 only in Core)
- Dependency Semantics (keine CausalRelation im Core)
- CORRUPTED → FINALIZED (reduzierter TraceState)
"""

import pytest
import time
import uuid
from dataclasses import dataclass
from typing import Any, Dict, List, Optional

from core.events import (
    InvariantTraceEvent,
    EGLTraceEvent,
    SHFTraceEvent,
    CBTraceEvent,
    ExecutionEvent,
    PostGateEvent,
    TraceState,
    TransitionNode,
    validate_transition_order,
)
from core.adapters.trace_adapter import (
    DependencyEdge,
    ExecutionTrace,
)
from core.observability.edge_types import (
    ALLOWED_EDGE_TYPES,
    EVENT_LAYER_MAP,
)
from core.observability.counterfactual_space import CounterfactualSpace
from core.observability.trace_collector import (
    TraceCollector,
    TraceCollectorConfig,
    validate_dependency_order,
    check_dependency_consistency,
)
from core.observability.trace_middleware import (
    ExecutionTraceMiddleware,
    MiddlewareConfig,
)
from core.observability.trace_replay import TraceReplay, ReplayResult
from core.observability.integration import (
    create_pre_gate_hook,
    create_egl_hook,
    integrate_middleware_with_kernel,
    create_trace_aware_execution_kernel,
)
from core.observability.factory import (
    create_traced_execution_kernel,
    create_traced_egl_engine,
    get_trace_stats,
)


# =============================================================================
# Hilfsklassen für Tests
# =============================================================================

@dataclass
class MockContext:
    """Mock ExecutionContext für Tests."""
    task_id: str = "test-task"
    mode: str = "EXPLORE"
    trust_level: str = "passive"
    invariants: Dict[str, Any] = None
    shf_state: Any = None
    cb_state: Any = None
    post_gate_result: Any = None

    def __post_init__(self):
        if self.invariants is None:
            self.invariants = {}


@dataclass
class MockSHFState:
    score: float = 0.8
    zone: str = "green"
    execution_mode: str = "EXPLORE"
    delta: float = 0.0
    weights: Dict[str, float] = None

    def __post_init__(self):
        if self.weights is None:
            self.weights = {"w1": 0.5, "w2": 0.5}


@dataclass
class MockCBState:
    state: str = "closed"
    failure_count: int = 0
    threshold: int = 5
    execution_mode: str = "EXPLORE"


@dataclass
class MockPostGateResult:
    shf_score: float = 0.85
    zone: str = "green"
    execution_mode: str = "EXPLORE"
    feedback_action: str = "none"
    duration_ms: float = 10.0


async def mock_execute_func(task_id: str, context: Any, **kwargs) -> str:
    """Mock Execution-Funktion."""
    return f"executed:{task_id}"


async def mock_failing_execute_func(task_id: str, context: Any, **kwargs) -> str:
    """Mock Execution-Funktion die fehlschlägt."""
    raise RuntimeError("Execution failed")


# =============================================================================
# E1: Test Trace Events
# =============================================================================

class TestTraceEvents:
    """Testet die Datenklassen in trace_events.py."""

    def test_execution_trace_creation(self):
        """Test: ExecutionTrace kann erstellt werden."""
        trace = ExecutionTrace(
            execution_id=uuid.uuid4(),
            task_id="test-task",
            causal_epoch=1,
        )
        assert trace.trace_state == TraceState.INIT
        assert not trace.is_finalized()
        assert trace.is_replayable() is False  # INIT ist nicht replayable

    def test_trace_state_machine(self):
        """Test: TraceState-Machine (INIT → ACTIVE → FINALIZED)."""
        trace = ExecutionTrace(
            execution_id=uuid.uuid4(),
            task_id="test",
            causal_epoch=0,
        )
        assert trace.trace_state == TraceState.INIT

        trace.trace_state = TraceState.ACTIVE
        assert not trace.is_finalized()

        trace.trace_state = TraceState.FINALIZED
        assert trace.is_finalized()
        assert trace.is_replayable()

    def test_finalized_trace(self):
        """Test: FINALIZED ist der einzige Endzustand im CORE-TraceState.

        Seit PR-1 (TraceState-Reduktion) existieren CORRUPTED und
        RECOVERABLE_CORRUPTED nicht mehr im CORE-TraceState.
        Science-spezifische Korruptionszustände werden in der
        Science Edition verwaltet (science.trace_semantics).
        """
        trace = ExecutionTrace(
            execution_id=uuid.uuid4(),
            task_id="test",
            causal_epoch=0,
            trace_state=TraceState.FINALIZED,
        )
        assert trace.is_finalized()
        assert trace.is_replayable()

        # ACTIVE ist nicht finalized
        trace.trace_state = TraceState.ACTIVE
        assert not trace.is_finalized()
        assert not trace.is_replayable()

    def test_dependency_edge_creation(self):
        """Test: DependencyEdge mit CRT-konformen Attributen (CI-CRT-001)."""
        edge = DependencyEdge(
            source_id=uuid.uuid4(),
            target_id=uuid.uuid4(),
            edge_type="causal_trigger",
        )
        assert edge.edge_type == "causal_trigger"
        # CI-CRT-001: Keine causal_strength, confidence, is_inferred, deviation_class
        assert not hasattr(edge, 'causal_strength')
        assert not hasattr(edge, 'confidence')
        assert not hasattr(edge, 'is_inferred')
        assert not hasattr(edge, 'deviation_class')

    def test_t2_projection(self):
        """Test: T2 = DependencyEdges (CRT-konform, keine Science-Projektion)."""
        edges = [
            DependencyEdge(uuid.uuid4(), uuid.uuid4(), "sequence"),
            DependencyEdge(uuid.uuid4(), uuid.uuid4(), "dependency"),
        ]
        assert len(edges) == 2
        # T2 enthält nur emitted edges — keine inferred edges im Core
        assert all(hasattr(e, 'edge_type') for e in edges)

    def test_counterfactual_decision(self):
        """Test: Counterfactual als Dict (CRT-konform, kein Science-Typ)."""
        cf = {
            "decision_id": str(uuid.uuid4()),
            "alternative_decision": "RESTRICT",
            "alternative_mode": "DAMPENED",
            "score": 0.3,
            "rejected_by": "shf",
            "rejection_reason": "Score too low",
            "is_budget_dropped": True,
            "entropy_contribution": 0.1,
        }
        assert cf["is_budget_dropped"]
        assert cf["rejected_by"] == "shf"

    def test_transition_node(self):
        """Test: TransitionNode für T1_{t+1} = F(T1_t, ...)."""
        node = TransitionNode(
            step=1,
            transition_type="invariant",
            state_before="hash_before",
            state_after="hash_after",
            input_data={"inv_count": 5},
            output_data={"passed": True},
        )
        assert node.step == 1
        assert node.transition_type == "invariant"

    def test_transition_order_validation(self):
        """Test: validate_transition_order()."""
        nodes = [
            TransitionNode(0, "init", "", ""),
            TransitionNode(1, "invariant", "", ""),
            TransitionNode(2, "egl", "", ""),
            TransitionNode(3, "shf", "", ""),
            TransitionNode(4, "cb", "", ""),
            TransitionNode(5, "exec", "", ""),
            TransitionNode(6, "post", "", ""),
        ]
        assert validate_transition_order(nodes)

        # Falsche Reihenfolge
        bad_nodes = [
            TransitionNode(0, "init", "", ""),
            TransitionNode(1, "exec", "", ""),  # exec vor invariant
        ]
        assert not validate_transition_order(bad_nodes)

    def test_layer_mapping(self):
        """Test: EVENT_LAYER_MAP."""
        assert EVENT_LAYER_MAP["InvariantTraceEvent"] == "L_INV"
        assert EVENT_LAYER_MAP["EGLTraceEvent"] == "L_EGL"
        assert EVENT_LAYER_MAP["SHFTraceEvent"] == "L_SHF"
        assert EVENT_LAYER_MAP["CBTraceEvent"] == "L_CB"
        assert EVENT_LAYER_MAP["ExecutionEvent"] == "L_EXEC"
        assert EVENT_LAYER_MAP["PostGateEvent"] == "L_POST"

    def test_allowed_edge_types(self):
        """Test: ALLOWED_EDGE_TYPES enthält alle Layer-Paare."""
        assert ("L_INV", "L_EGL") in ALLOWED_EDGE_TYPES
        assert ("L_EGL", "L_SHF") in ALLOWED_EDGE_TYPES
        assert ("L_SHF", "L_CB") in ALLOWED_EDGE_TYPES
        assert ("L_CB", "L_EXEC") in ALLOWED_EDGE_TYPES
        assert ("L_EXEC", "L_POST") in ALLOWED_EDGE_TYPES
        # Feedback Loop
        assert ("L_POST", "L_INV") in ALLOWED_EDGE_TYPES


# =============================================================================
# E2: Test CounterfactualSpace
# =============================================================================

class TestCounterfactualSpace:
    """Testet den CounterfactualSpace (T4) — CRT-konform als Dict-Struktur."""

    def test_counterfactual_space_creation(self):
        """Test: CounterfactualSpace als separate Entity."""
        space = CounterfactualSpace(
            space_id=uuid.uuid4(),
            execution_id=uuid.uuid4(),
        )
        assert space.total_counterfactuals == 0
        assert len(space.get_visible()) == 0

    def test_counterfactual_with_visible(self):
        """Test: CounterfactualSpace mit sichtbaren Counterfactuals (als Dict)."""
        cfs = [
            {"decision_id": str(uuid.uuid4()), "alternative_decision": "ALLOW", "score": 0.9, "rejected_by": "invariant", "rejection_reason": "ok"},
            {"decision_id": str(uuid.uuid4()), "alternative_decision": "RESTRICT", "score": 0.5, "rejected_by": "shf", "rejection_reason": "low score"},
            {"decision_id": str(uuid.uuid4()), "alternative_decision": "BLOCK", "score": 0.1, "rejected_by": "cb", "rejection_reason": "open"},
        ]
        space = CounterfactualSpace(
            space_id=uuid.uuid4(),
            execution_id=uuid.uuid4(),
            counterfactuals=cfs,
            visible_indices=[0, 1],  # Nur die ersten beiden sind sichtbar
        )
        assert len(space.get_visible()) == 2
        assert space.hidden_count == 1  # 3 - 2 = 1 hidden

    def test_select_visible_counterfactuals(self):
        """Test: Deterministische CF-Auswahl (als Dict)."""
        cfs = [
            {"decision_id": str(uuid.uuid4()), "alternative_decision": "A", "score": 0.9, "rejected_by": "inv", "rejection_reason": "r1"},
            {"decision_id": str(uuid.uuid4()), "alternative_decision": "B", "score": 0.7, "rejected_by": "egl", "rejection_reason": "r2"},
            {"decision_id": str(uuid.uuid4()), "alternative_decision": "C", "score": 0.5, "rejected_by": "shf", "rejection_reason": "r3"},
            {"decision_id": str(uuid.uuid4()), "alternative_decision": "D", "score": 0.3, "rejected_by": "cb", "rejection_reason": "r4"},
            {"decision_id": str(uuid.uuid4()), "alternative_decision": "E", "score": 0.1, "rejected_by": "inv", "rejection_reason": "r5"},
        ]
        # Budget=3, Seed=42
        visible = CounterfactualSpace.select_visible_counterfactuals(cfs, 3, 42)
        assert len(visible) == 3  # Top 3 nach Score

        # Deterministisch: Gleicher Input → gleicher Output
        visible2 = CounterfactualSpace.select_visible_counterfactuals(cfs, 3, 42)
        assert visible == visible2

    def test_entropy_calculation(self):
        """Test: Entropy-Berechnung im CounterfactualSpace (als Dict)."""
        cfs = [
            {"decision_id": str(uuid.uuid4()), "alternative_decision": "A", "score": 0.9, "rejected_by": "inv", "rejection_reason": "r1"},
            {"decision_id": str(uuid.uuid4()), "alternative_decision": "B", "score": 0.7, "rejected_by": "egl", "rejection_reason": "r2"},
        ]
        space = CounterfactualSpace(
            space_id=uuid.uuid4(),
            execution_id=uuid.uuid4(),
            counterfactuals=cfs,
            visible_indices=[0, 1],
        )
        entropy = space.entropy()
        assert entropy > 0.0  # Es gibt Entropy bei 2 Alternativen

    def test_entropy_normalization(self):
        """Test: Epoch-normalisierte Entropy (als Dict)."""
        cfs = [
            {"decision_id": str(uuid.uuid4()), "alternative_decision": "A", "score": 0.9, "rejected_by": "inv", "rejection_reason": "r1"},
            {"decision_id": str(uuid.uuid4()), "alternative_decision": "B", "score": 0.7, "rejected_by": "egl", "rejection_reason": "r2"},
        ]
        space = CounterfactualSpace(
            space_id=uuid.uuid4(),
            execution_id=uuid.uuid4(),
            counterfactuals=cfs,
            visible_indices=[0, 1],
            entropy_normalization_epoch=2,
        )
        entropy = space.entropy()
        unnormalized = CounterfactualSpace(
            space_id=uuid.uuid4(),
            execution_id=uuid.uuid4(),
            counterfactuals=cfs,
            visible_indices=[0, 1],
            entropy_normalization_epoch=0,
        ).entropy()
        assert entropy < unnormalized  # Normalisiert = kleiner


# =============================================================================
# E3: Test TraceCollector
# =============================================================================

class TestTraceCollector:
    """Testet den TraceCollector (CRT-konform)."""

    def test_collector_creation(self):
        """Test: TraceCollector kann erstellt werden."""
        collector = TraceCollector()
        stats = collector.get_stats()
        assert stats["active_traces"] == 0
        assert stats["history_size"] == 0

    def test_create_and_finalize_trace(self):
        """Test: Trace-Lebenszyklus (create → activate → finalize)."""
        collector = TraceCollector()
        trace = collector.create_trace("test-task", causal_epoch=1)
        assert trace.trace_state == TraceState.INIT

        collector.activate_trace(trace)
        assert trace.trace_state == TraceState.ACTIVE

        collector.finalize_trace(trace)
        assert trace.trace_state == TraceState.FINALIZED

    def test_mark_failed_trace(self):
        """Test: mark_corrupted setzt auf FINALIZED (CORE-TraceState).

        Seit PR-1 (TraceState-Reduktion) existieren CORRUPTED und
        RECOVERABLE_CORRUPTED nicht mehr im CORE-TraceState.
        mark_corrupted setzt im CORE auf FINALIZED.
        Science-spezifische RecoverySpecs werden ignoriert.
        """
        collector = TraceCollector()
        trace = collector.create_trace("test-task")

        # mark_corrupted → FINALIZED
        collector.mark_corrupted(trace, reason="Test failure")
        assert trace.trace_state == TraceState.FINALIZED
        assert trace.is_finalized()

        # Auch ohne recovery_spec → FINALIZED (CRT-konform)
        trace2 = collector.create_trace("test-task-2")
        collector.mark_corrupted(
            trace2,
            reason="Recoverable failure",
        )
        assert trace2.trace_state == TraceState.FINALIZED

    def test_dependency_edge_management(self):
        """Test: DependencyEdges zu Traces hinzufügen (CRT-konform)."""
        collector = TraceCollector()
        trace = collector.create_trace("test")
        collector.activate_trace(trace)

        e1_id = uuid.uuid4()
        e2_id = uuid.uuid4()

        edge = collector.add_dependency_edge(
            trace, e1_id, e2_id, "causal_trigger",
        )
        assert edge.edge_type == "causal_trigger"
        assert len(trace.dependency_edges) == 1
        # CI-CRT-001: Keine causal_strength, confidence im Core
        assert not hasattr(edge, 'causal_strength')
        assert not hasattr(edge, 'confidence')

    def test_transition_node_management(self):
        """Test: TransitionNodes zu Traces hinzufügen."""
        collector = TraceCollector()
        trace = collector.create_trace("test")
        collector.activate_trace(trace)

        node = collector.add_transition_node(
            trace, 1, "invariant",
            "state_before", "state_after",
            input_data={"inv_count": 5},
        )
        assert node.step == 1
        assert len(trace.transition_nodes) == 1

    def test_dependency_consistency(self):
        """Test: Dependency Consistency (CRT-konform, kein CausalRelation)."""
        collector = TraceCollector()
        trace = collector.create_trace("test")
        collector.activate_trace(trace)

        a, b, c = uuid.uuid4(), uuid.uuid4(), uuid.uuid4()

        # Kette A → B → C
        collector.add_dependency_edge(trace, a, b, "sequence")
        collector.add_dependency_edge(trace, b, c, "sequence")

        # Dependency Order validieren (erwartet ExecutionTrace, nicht list)
        violations = validate_dependency_order(trace)
        assert len(violations) == 0

        # Dependency Consistency prüfen (erwartet ExecutionTrace, nicht list)
        violations2 = check_dependency_consistency(trace)
        assert len(violations2) == 0

    def test_counterfactual_space_in_collector(self):
        """Test: CounterfactualSpace im Collector (als Dict)."""
        collector = TraceCollector()
        exec_id = uuid.uuid4()

        cfs = [
            {"decision_id": str(uuid.uuid4()), "alternative_decision": "ALLOW", "score": 0.9, "rejected_by": "inv", "rejection_reason": "ok"},
        ]
        space = collector.create_counterfactual_space(
            execution_id=exec_id,
            counterfactuals=cfs,
            budget=5, seed=42,
        )
        assert space.execution_id == exec_id
        assert len(space.get_visible()) == 1

        # Wieder abrufbar
        retrieved = collector.get_counterfactual_space(space.space_id)
        assert retrieved is not None
        assert retrieved.space_id == space.space_id

    def test_query_methods(self):
        """Test: Query-Methoden des Collectors."""
        collector = TraceCollector()
        trace = collector.create_trace("task-1", causal_epoch=1)
        collector.activate_trace(trace)
        collector.finalize_trace(trace)

        trace2 = collector.create_trace("task-2", causal_epoch=1)
        collector.activate_trace(trace2)
        collector.finalize_trace(trace2)

        # Nach Task
        tasks = collector.get_traces_by_task("task-1")
        assert len(tasks) == 1

        # Nach Epoche
        epochs = collector.get_traces_by_epoch(1)
        assert len(epochs) == 2

        # Recent
        recent = collector.get_recent_traces(1)
        assert len(recent) == 1

    def test_performance_mode(self):
        """Test: Performance-Mode Wechsel (CRT-konform)."""
        collector = TraceCollector()
        assert collector._performance_mode == "adaptive"

        collector.set_performance_mode("red")
        # CRT-konform: enable_crnf existiert nicht mehr
        assert collector.config.max_counterfactuals_per_execution == 0

        collector.set_performance_mode("green")
        assert collector.config.max_counterfactuals_per_execution == 50


# =============================================================================
# E4: Test ExecutionTraceMiddleware
# =============================================================================

class TestExecutionTraceMiddleware:
    """Testet die ExecutionTraceMiddleware (CRT-konform)."""

    @pytest.mark.asyncio
    async def test_middleware_wraps_execution(self):
        """Test: Middleware wrappt eine erfolgreiche Execution."""
        collector = TraceCollector()
        middleware = ExecutionTraceMiddleware(collector)

        ctx = MockContext(mode="EXPLORE")
        result, trace = await middleware.wrap_execution(
            mock_execute_func, "test-task", ctx
        )
        assert result == "executed:test-task"
        assert trace is not None
        assert trace.trace_state == TraceState.FINALIZED
        assert trace.task_id == "test-task"

    @pytest.mark.asyncio
    async def test_middleware_crash_safety(self):
        """Test: Middleware markiert Trace als CORRUPTED bei Exception."""
        collector = TraceCollector()
        middleware = ExecutionTraceMiddleware(collector)

        ctx = MockContext(mode="EXPLORE")
        with pytest.raises(RuntimeError, match="Execution failed"):
            await middleware.wrap_execution(
                mock_failing_execute_func, "failing-task", ctx
            )

        # Trace sollte als CORRUPTED markiert sein
        active = collector.get_active_traces()
        assert len(active) == 0  # Trace wurde aus active entfernt

    @pytest.mark.asyncio
    async def test_middleware_traces_all_layers(self):
        """Test: Middleware erzeugt Traces für alle Layer."""
        collector = TraceCollector()
        middleware = ExecutionTraceMiddleware(collector)

        ctx = MockContext(
            mode="EXPLORE",
            invariants={"INV-001": type('obj', (object,), {"passed": True, "severity": "info", "details": "ok"})(),
                        "INV-002": type('obj', (object,), {"passed": True, "severity": "info", "details": "ok"})()},
            shf_state=MockSHFState(),
            cb_state=MockCBState(),
            post_gate_result=MockPostGateResult(),
        )

        result, trace = await middleware.wrap_execution(
            mock_execute_func, "test-task", ctx
        )
        assert trace is not None
        assert trace.trace_state == TraceState.FINALIZED

    @pytest.mark.asyncio
    async def test_middleware_disabled_tracing(self):
        """Test: Tracing kann deaktiviert werden."""
        collector = TraceCollector()
        middleware = ExecutionTraceMiddleware(
            collector,
            config=MiddlewareConfig(enable_tracing=False),
        )

        ctx = MockContext(mode="EXPLORE")
        result, trace = await middleware.wrap_execution(
            mock_execute_func, "test-task", ctx
        )
        assert result == "executed:test-task"
        assert trace is None  # Kein Trace bei deaktiviertem Tracing


# =============================================================================
# E5: Test TraceReplay (T2-MINIMAL)
# =============================================================================

class TestTraceReplay:
    """Testet das deterministische Replay (T2-MINIMAL, CRT-konform)."""

    def test_replay_successful_execution(self):
        """Test: Replay einer erfolgreichen Execution."""
        collector = TraceCollector()
        trace = collector.create_trace("test-task")
        collector.activate_trace(trace)
        collector.finalize_trace(trace)

        replay = TraceReplay(collector)
        result = replay.replay(trace.execution_id)
        assert result.trace is not None
        # CRT-konform: is_deterministic existiert nicht mehr im ReplayResult
        assert result.blocked_by is None

    def test_replay_blocked_by_invariant(self):
        """Test: Replay einer durch INV blockierten Execution."""
        collector = TraceCollector()
        trace = collector.create_trace("test-task")
        collector.activate_trace(trace)

        # Füge blockierte Invariante hinzu
        trace.invariant_trace.append(InvariantTraceEvent(
            inv_id="INV-001", severity="blocker", passed=False,
            details="Critical invariant violated",
        ))
        collector.finalize_trace(trace)

        replay = TraceReplay(collector)
        result = replay.replay(trace.execution_id)
        assert result.blocked_by == "invariant"
        assert "INV-001" in str(result.decision_path)

    def test_replay_blocked_by_egl(self):
        """Test: Replay einer durch EGL blockierten Execution."""
        collector = TraceCollector()
        trace = collector.create_trace("test-task")
        collector.activate_trace(trace)

        trace.invariant_trace.append(InvariantTraceEvent(inv_id="INV-001", passed=True))
        trace.egl_trace.append(EGLTraceEvent(
            tool_name="test", policy_decision="DENY",
            reason="Not allowed in current mode",
        ))
        collector.finalize_trace(trace)

        replay = TraceReplay(collector)
        result = replay.replay(trace.execution_id)
        assert result.blocked_by == "egl"

    def test_replay_blocked_by_shf(self):
        """Test: Replay einer durch SHF blockierten Execution."""
        collector = TraceCollector()
        trace = collector.create_trace("test-task")
        collector.activate_trace(trace)

        trace.invariant_trace.append(InvariantTraceEvent(inv_id="INV-001", passed=True))
        trace.egl_trace.append(EGLTraceEvent(tool_name="test", policy_decision="ALLOW"))
        trace.shf_trace.append(SHFTraceEvent(shf_score=0.1, zone="red", execution_mode="BLOCKED"))
        collector.finalize_trace(trace)

        replay = TraceReplay(collector)
        result = replay.replay(trace.execution_id)
        assert result.blocked_by == "shf"

    def test_replay_blocked_by_cb(self):
        """Test: Replay einer durch CB blockierten Execution."""
        collector = TraceCollector()
        trace = collector.create_trace("test-task")
        collector.activate_trace(trace)

        trace.invariant_trace.append(InvariantTraceEvent(inv_id="INV-001", passed=True))
        trace.egl_trace.append(EGLTraceEvent(tool_name="test", policy_decision="ALLOW"))
        trace.shf_trace.append(SHFTraceEvent(shf_score=0.5, zone="yellow"))
        trace.cb_trace.append(CBTraceEvent(cb_state="open", failure_count=5, threshold=5))
        collector.finalize_trace(trace)

        replay = TraceReplay(collector)
        result = replay.replay(trace.execution_id)
        assert result.blocked_by == "circuit_breaker"

    def test_replay_with_dependency_chain(self):
        """Test: Dependency Chain im Replay (T2-MINIMAL)."""
        collector = TraceCollector()
        trace = collector.create_trace("test-task")
        collector.activate_trace(trace)

        # Füge DependencyEdges hinzu
        inv_id = uuid.uuid4()
        egl_id = uuid.uuid4()
        trace.dependency_edges.append(DependencyEdge(inv_id, egl_id, "causal_trigger"))
        collector.finalize_trace(trace)

        replay = TraceReplay(collector)
        chain = replay.dependency_chain(trace.execution_id)
        assert len(chain) == 1
        assert chain[0].edge_type == "causal_trigger"

    def test_get_alternatives(self):
        """Test: Entscheidungsalternativen aus dem Trace abrufen."""
        collector = TraceCollector()
        trace = collector.create_trace("test-task")
        collector.activate_trace(trace)

        trace.decision_alternatives = {"ALLOW": 0.9, "RESTRICT": 0.5}
        collector.finalize_trace(trace)

        # CRT-konform: Alternativen direkt aus dem Trace
        # TraceReplay.get_alternatives() wurde in Schritt 1c entfernt
        alts = trace.decision_alternatives
        assert len(alts) == 2
        assert alts["ALLOW"] == 0.9


# =============================================================================
# E6: Test Integration
# =============================================================================

class TestIntegration:
    """Testet die Integration (Hooks + Factory)."""

    def test_create_pre_gate_hook(self):
        """Test: PreGate-Hook kann erstellt werden."""
        collector = TraceCollector()
        middleware = ExecutionTraceMiddleware(collector)
        hook = create_pre_gate_hook(middleware)
        assert callable(hook)

    def test_create_egl_hook(self):
        """Test: EGL-Hook kann erstellt werden."""
        collector = TraceCollector()
        middleware = ExecutionTraceMiddleware(collector)
        hook = create_egl_hook(middleware)
        assert callable(hook)

    def test_factory_creates_kernel(self):
        """Test: Factory erzeugt Kernel mit Trace-Integration."""
        kernel = create_traced_execution_kernel()
        assert hasattr(kernel, '_trace_collector')
        assert hasattr(kernel, '_trace_middleware')
        assert hasattr(kernel, '_trace_replay')
        assert hasattr(kernel, 'execute')

    def test_factory_kernel_has_trace_stats(self):
        """Test: Factory-Kernel hat Trace-Statistiken."""
        kernel = create_traced_execution_kernel()
        stats = get_trace_stats(kernel)
        assert "active_traces" in stats
        assert stats["active_traces"] == 0

    def test_create_traced_egl_engine(self):
        """Test: Factory erzeugt EGLEngine mit Trace."""
        engine = create_traced_egl_engine()
        assert engine is not None


# =============================================================================
# E8: CRNF Tests — Science Edition
# =============================================================================

@pytest.mark.skip(reason="CRNF ist Science Edition (science.trace_semantics). "
                         "Diese Tests gehören in die Science-Testsuite, "
                         "nicht in Core. ADR-002: CRT = Observable Deterministic Facts.")
class TestCRNF:
    """Testet die Causal Reduction Normal Form (Science Edition)."""

    def test_is_crnf_empty_graph(self):
        pass

    def test_is_crnf_no_transitive(self):
        pass

    def test_is_crnf_with_transitive(self):
        pass

    def test_to_crnf_removes_transitive(self):
        pass
