import pytest
from core.bootstrap.container import Container
from core.bootstrap.app_factory import create_control_plane_app, create_worker_runtime
from core.infrastructure.config.loader import load_config
from core.project.project_manager import ProjectManager
from core.project.scheduler import ProjectScheduler

def test_container_singleton_integrity():
    """Verify that the container correctly manages and returns singletons."""
    config = load_config()
    container = Container(config)
    
    # Factory that creates a unique object
    def pm_factory():
        return ProjectManager(memory_coordinator=None)
    
    pm1 = container.get("pm", pm_factory)
    pm2 = container.get("pm", pm_factory)
    
    assert pm1 is pm2
    assert isinstance(pm1, ProjectManager)
    assert container._creation_log["pm"] == "ProjectManager"

def test_container_http_client_singleton():
    """Verify that managed HTTP clients are treated as singletons within the container."""
    config = load_config()
    container = Container(config)
    
    client1 = container.get_http_client("test")
    client2 = container.get_http_client("test")
    
    assert client1 is client2

def test_control_plane_app_factory():
    """Verify that the control plane app is correctly wired with its dependencies."""
    app = create_control_plane_app()
    
    assert hasattr(app.state, "app_state")
    app_state = app.state.app_state
    
    assert isinstance(app_state.container, Container)
    assert isinstance(app_state.scheduler, ProjectScheduler)
    
    # Verify the internal graph
    assert app_state.scheduler.pm is not None
    assert app_state.scheduler.rm is not None
    assert app_state.scheduler.dr is not None
    assert app_state.scheduler.policy is not None
    assert app_state.scheduler.nm is not None
    assert app_state.scheduler.pr is not None

def test_worker_runtime_factory():
    """Verify that the worker runtime is correctly initialized via the factory."""
    worker = create_worker_runtime()
    
    assert worker.config is not None
    assert worker.client is not None
    assert worker.node_id is not None

def test_container_creation_log():
    """Verify that the container correctly tracks the creation of services."""
    config = load_config()
    container = Container(config)
    
    container.get("test_service", lambda: ProjectManager(None))
    
    dump = container.debug_dump()
    assert "test_service" in dump
    assert dump["test_service"] == "ProjectManager"
