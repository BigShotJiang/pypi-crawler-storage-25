#!/usr/bin/env python3
"""
Test end-to-end API response flow.
This script tests that the API returns proper responses instead of hardcoded fallback.
"""

import asyncio
import aiohttp
import json
import sys

async def test_chat_endpoint():
    """Test the /chat endpoint with a simple message."""
    print("🧪 Testing API /chat endpoint...")
    
    url = "http://localhost:8000/api/v1/chat"
    headers = {
        "Content-Type": "application/json",
        "Accept": "application/json"
    }
    
    payload = {
        "message": "Hello, how are you?",
        "session_id": "test-session-123",
        "tenant_id": "test-tenant",
        "mode": "business"
    }
    
    try:
        async with aiohttp.ClientSession() as session:
            async with session.post(url, json=payload, headers=headers, timeout=30) as response:
                print(f"  Status: {response.status}")
                print(f"  Headers: {dict(response.headers)}")
                
                response_text = await response.text()
                print(f"  Response length: {len(response_text)} chars")
                
                # Try to parse as JSON
                try:
                    response_json = json.loads(response_text)
                    print(f"  Response JSON keys: {list(response_json.keys())}")
                    
                    # Check for the hardcoded fallback message
                    if "response" in response_json:
                        response_content = response_json["response"]
                        if "Ich bin hier, um Ihnen zur Seite zu stehen" in response_content:
                            print("❌ WARNING: Hardcoded fallback message detected!")
                            print(f"  Response: {response_content[:200]}...")
                            return False
                        else:
                            print(f"✅ Valid response received (not hardcoded fallback)")
                            print(f"  Response preview: {response_content[:200]}...")
                            return True
                    else:
                        print(f"⚠️  Response doesn't contain 'response' key")
                        print(f"  Full response: {response_json}")
                        return False
                        
                except json.JSONDecodeError:
                    print(f"⚠️  Response is not valid JSON")
                    print(f"  Response text: {response_text[:500]}...")
                    return False
                    
    except Exception as e:
        print(f"❌ Error calling API: {e}")
        return False

async def test_stream_endpoint():
    """Test the /chat/stream endpoint."""
    print("\n🧪 Testing API /chat/stream endpoint...")
    
    url = "http://localhost:8000/api/v1/chat/stream"
    headers = {
        "Content-Type": "application/json",
        "Accept": "text/event-stream"
    }
    
    payload = {
        "message": "Tell me a short story",
        "session_id": "test-session-456",
        "tenant_id": "test-tenant",
        "mode": "business"
    }
    
    try:
        async with aiohttp.ClientSession() as session:
            async with session.post(url, json=payload, headers=headers, timeout=30) as response:
                print(f"  Status: {response.status}")
                print(f"  Content-Type: {response.headers.get('Content-Type', 'unknown')}")
                
                # Read streaming response
                chunks = []
                async for chunk in response.content.iter_any():
                    if chunk:
                        chunk_text = chunk.decode('utf-8', errors='ignore')
                        chunks.append(chunk_text)
                        print(f"  Chunk: {chunk_text[:100]}...")
                
                full_response = ''.join(chunks)
                print(f"  Total chunks: {len(chunks)}")
                print(f"  Total response length: {len(full_response)} chars")
                
                # Check for hardcoded fallback
                if "Ich bin hier, um Ihnen zur Seite zu stehen" in full_response:
                    print("❌ WARNING: Hardcoded fallback message detected in stream!")
                    return False
                else:
                    print("✅ Stream response received without hardcoded fallback")
                    return True
                    
    except Exception as e:
        print(f"❌ Error calling stream API: {e}")
        return False

async def test_vllm_direct():
    """Test direct vLLM endpoint to confirm it's working."""
    print("\n🧪 Testing direct vLLM endpoint...")
    
    url = "http://localhost:8001/v1/chat/completions"
    headers = {
        "Content-Type": "application/json"
    }
    
    payload = {
        "model": "Qwen/Qwen2.5-1.5B-Instruct",
        "messages": [
            {"role": "user", "content": "Hello, how are you?"}
        ],
        "max_tokens": 50,
        "stream": False
    }
    
    try:
        async with aiohttp.ClientSession() as session:
            async with session.post(url, json=payload, headers=headers, timeout=10) as response:
                print(f"  vLLM Status: {response.status}")
                response_json = await response.json()
                
                if "choices" in response_json and len(response_json["choices"]) > 0:
                    content = response_json["choices"][0].get("message", {}).get("content", "")
                    print(f"✅ vLLM direct response: {content[:100]}...")
                    return True
                else:
                    print(f"⚠️  vLLM response missing choices: {response_json}")
                    return False
                    
    except Exception as e:
        print(f"❌ Error calling vLLM directly: {e}")
        return False

async def main():
    """Run all tests."""
    print("🚀 Starting end-to-end response flow validation...")
    
    # Test direct vLLM first
    vllm_ok = await test_vllm_direct()
    if not vllm_ok:
        print("❌ vLLM not working - cannot proceed with API tests")
        return
    
    # Test API endpoints
    chat_ok = await test_chat_endpoint()
    stream_ok = await test_stream_endpoint()
    
    print("\n" + "="*50)
    print("TEST SUMMARY:")
    print(f"  vLLM direct connection: {'✅ PASS' if vllm_ok else '❌ FAIL'}")
    print(f"  API /chat endpoint: {'✅ PASS' if chat_ok else '❌ FAIL'}")
    print(f"  API /chat/stream endpoint: {'✅ PASS' if stream_ok else '❌ FAIL'}")
    
    if chat_ok and stream_ok:
        print("\n🎉 End-to-end response flow validation PASSED!")
        print("   No hardcoded fallback messages detected.")
        print("   vLLM integration is working correctly.")
    else:
        print("\n⚠️  End-to-end response flow validation has issues.")
        print("   Some tests failed or hardcoded fallback detected.")

if __name__ == "__main__":
    asyncio.run(main())