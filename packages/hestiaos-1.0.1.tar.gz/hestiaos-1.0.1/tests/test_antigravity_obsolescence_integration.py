"""
tests/test_antigravity_obsolescence_integration.py — C2.4 End-to-End Integration Test.

Testet die vollständige Pipeline der Antigravity-Obsoleszenz:
  User Input
  → SemanticIntentAnalyzer (C2.3)
  → IREventRouter (C1.4)
  → CapabilityEngine (C1.3)
  → OrchestratorExecutionAdapter (C2.2)
  → TemporalVibeManager (C2.1)
  → Snapshot Persist

Dieser Test validiert, dass alle Komponenten zusammenspielen und die
4 identifizierten Lücken geschlossen sind.
"""

import sys
import types
import pytest
from typing import Dict, Any, Optional, List

# ---------------------------------------------------------------------------
# Workaround: core/orchestrator/__init__.py importiert kernel.py,
# das MultiAgentScheduler aus core.scheduler braucht (existiert nicht).
#
# Strategie: Wir blockieren das Laden von core.orchestrator.__init__,
# indem wir ein Dummy-Modul in sys.modules eintragen, BEVOR Python
# versucht, das Package zu laden. Dann laden wir execution_adapter.py
# direkt als Modul.
# ---------------------------------------------------------------------------

# 1. Dummy-Modul für core.orchestrator eintragen (blockiert __init__.py)
_orch_pkg = types.ModuleType("core.orchestrator")
_orch_pkg.__path__ = ["core/orchestrator"]  # type: ignore[attr-defined]
_orch_pkg.__file__ = "core/orchestrator/__init__.py"  # type: ignore[attr-defined]
_orch_pkg.__package__ = "core.orchestrator"
sys.modules["core.orchestrator"] = _orch_pkg

# 2. execution_adapter.py direkt als Modul laden
import importlib.util
_exec_spec = importlib.util.spec_from_file_location(
    "core.orchestrator.execution_adapter",
    "core/orchestrator/execution_adapter.py",
    submodule_search_locations=[],
)
_exec_mod = importlib.util.module_from_spec(_exec_spec)
sys.modules["core.orchestrator.execution_adapter"] = _exec_mod
_exec_spec.loader.exec_module(_exec_mod)

OrchestratorExecutionAdapter = _exec_mod.OrchestratorExecutionAdapter
ExecutionRequest = _exec_mod.ExecutionRequest
ExecutionResult = _exec_mod.ExecutionResult
ExecutionStrategy = _exec_mod.ExecutionStrategy
TaskType = _exec_mod.TaskType
create_orchestrator_adapter = _exec_mod.create_orchestrator_adapter
AntigravityToOrchestratorBridge = _exec_mod.AntigravityToOrchestratorBridge

# 3. Normale Imports für Module ohne defekte __init__-Ketten
from core.intelligence.semantic_intent import (
    SemanticIntentAnalyzer,
    SemanticIntent,
    register_intent_analysis_job,
)
from core.ir.capability_engine import CapabilityEngine, Capability, CapabilityStatus
from core.ir.ir_event_router import IREventRouter
from core.ir.query_engine import GraphQueryEngine
from core.vibe.temporal_vibe import TemporalVibeManager, VibeSnapshot
from core.scheduler.cron_intelligence import JobRegistry, CronJob


# ---------------------------------------------------------------------------
# Fixtures: Vollständige integrierte Test-Umgebung
# ---------------------------------------------------------------------------


@pytest.fixture
def capability_engine() -> CapabilityEngine:
    """CapabilityEngine mit registrierten Providern und Capabilities."""
    engine = CapabilityEngine()

    # Capabilities registrieren — sc_adapter bekommt auch "chill" und "bright"
    engine.register_many([
        Capability(
            capability_id="session.start",
            name="Session Start",
            description="Startet eine neue Vibe-Session",
            status=CapabilityStatus.IMPLEMENTED,
            provided_by=("foxdot_adapter",),
            styles=("ambient",),
        ),
        Capability(
            capability_id="audio.generate",
            name="Audio Generation",
            description="Generiert Audio basierend auf Style/Energy",
            status=CapabilityStatus.IMPLEMENTED,
            provided_by=("foxdot_adapter",),
            styles=("ambient",),
        ),
        Capability(
            capability_id="pattern.create",
            name="Pattern Creation",
            description="Erstellt musikalische Patterns",
            status=CapabilityStatus.IMPLEMENTED,
            provided_by=("foxdot_adapter",),
            styles=("techno",),
        ),
        Capability(
            capability_id="session.start",
            name="Session Start",
            description="Startet eine neue SuperCollider-Session",
            status=CapabilityStatus.IMPLEMENTED,
            provided_by=("sc_adapter",),
            styles=("dark", "bright", "chill"),
        ),
        Capability(
            capability_id="audio.generate",
            name="Audio Generation",
            description="Generiert Audio mit SuperCollider",
            status=CapabilityStatus.IMPLEMENTED,
            provided_by=("sc_adapter",),
            styles=("dark", "bright", "chill"),
        ),
    ])

    # Provider-Capabilities registrieren (für IR-Graph)
    engine.register_provider_capabilities(
        component_id="foxdot_adapter",
        capabilities=["session.start", "audio.generate", "pattern.create"],
        styles=["ambient", "techno", "glitch"],
    )
    engine.register_provider_capabilities(
        component_id="sc_adapter",
        capabilities=["session.start", "audio.generate"],
        styles=["dark", "bright", "chill"],
    )

    return engine


@pytest.fixture
def vibe_manager() -> TemporalVibeManager:
    """TemporalVibeManager für Session-State."""
    return TemporalVibeManager()


@pytest.fixture
def event_router(capability_engine: CapabilityEngine) -> IREventRouter:
    """IREventRouter basierend auf CapabilityEngine."""
    router = IREventRouter(capability_engine=capability_engine)
    router.sync_graph()
    return router


@pytest.fixture
def execution_adapter(
    capability_engine: CapabilityEngine,
    event_router: IREventRouter,
    vibe_manager: TemporalVibeManager,
) -> OrchestratorExecutionAdapter:
    """OrchestratorExecutionAdapter mit allen Komponenten."""
    adapter = OrchestratorExecutionAdapter(
        capability_engine=capability_engine,
        event_router=event_router,
        vibe_manager=vibe_manager,
    )
    return adapter


@pytest.fixture
def semantic_analyzer() -> SemanticIntentAnalyzer:
    """SemanticIntentAnalyzer (reine Heuristik, kein LLM)."""
    return SemanticIntentAnalyzer()


# ---------------------------------------------------------------------------
# Test 1: Vollständiger User-Input → Execution Flow
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_full_user_input_to_execution(
    semantic_analyzer: SemanticIntentAnalyzer,
    event_router: IREventRouter,
    execution_adapter: OrchestratorExecutionAdapter,
    vibe_manager: TemporalVibeManager,
):
    """Teste den vollständigen Flow: User Input → Analyse → Routing → Execution → State Update.

    Simuliert: User sagt "start a dark ambient vibe"

    Hinweis: SESSION_MANAGEMENT mapped zu DIRECT (kein State-Update).
    Für State-Tests verwenden wir AUDIO_GENERATION (→ SEMANTIC), das den
    VibeManager über den EventRouter mit Providern versorgt.
    """
    # Schritt 1: User Input → SemanticIntentAnalyzer
    intent = await semantic_analyzer.analyze("start a dark ambient vibe")
    assert intent.intent == "vibe.start"
    assert intent.style == "dark"
    assert intent.energy == 0.5
    assert "session.start" in intent.capabilities

    # Schritt 2: Intent → Event für IR-Router
    event = {
        "type": "vibe.start",
        "session_id": "integration-test-session",
        "semantic": {
            "style": intent.style,
            "energy": intent.energy,
            "confidence": intent.confidence,
        },
        "routing": {
            "capabilities": intent.capabilities,
        },
    }

    # Schritt 3: Event → IREventRouter
    routing_result = await event_router.route_event(event)
    assert len(routing_result["selected_providers"]) > 0
    # Dark style sollte zu sc_adapter routen
    assert any("sc_adapter" in c["component_id"] for c in routing_result["selected_providers"])

    # Schritt 4: ExecutionAdapter mit AUDIO_GENERATION (→ SEMANTIC) ausführen
    # AUDIO_GENERATION mapped zu SEMANTIC, was den EventRouter nutzt
    request = ExecutionRequest(
        task_id="integration-test-task",
        description="Integration test task",
        session_id="integration-test-session",
        task_type=TaskType.AUDIO_GENERATION,
        context={
            "event": event,
            "routing_result": routing_result,
            "style": intent.style,
        },
    )
    result = await execution_adapter.execute_task(request)
    assert result.success is True

    # Schritt 5: TemporalVibeManager State prüfen
    state = await vibe_manager.get_current_state("integration-test-session")
    assert state is not None
    assert state.session_id == "integration-test-session"


# ---------------------------------------------------------------------------
# Test 2: Semantic → IR-Router → CapabilityEngine Integration
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_semantic_to_ir_router_integration(
    semantic_analyzer: SemanticIntentAnalyzer,
    event_router: IREventRouter,
):
    """Teste die Integration zwischen SemanticIntentAnalyzer und IREventRouter.

    Validiert Lücke 2 (Semantic Router → IR Query Engine).
    """
    # Verschiedene Intents analysieren und routen
    test_cases = [
        ("play techno music", "techno", "foxdot_adapter"),
        ("dark atmosphere", "dark", "sc_adapter"),
        ("chill vibes", "chill", "sc_adapter"),
        ("glitch effects", "glitch", "foxdot_adapter"),
    ]

    for text, expected_style, expected_provider in test_cases:
        # Semantic Analyse
        intent = await semantic_analyzer.analyze(text)
        assert intent.style == expected_style, f"Expected style {expected_style} for '{text}', got {intent.style}"

        # Event bauen
        event = {
            "type": "vibe.start",
            "session_id": "test-session",
            "semantic": {"style": intent.style, "energy": intent.energy},
            "routing": {"capabilities": intent.capabilities},
        }

        # IR-Routing
        result = await event_router.route_event(event)

        # Prüfe dass der erwartete Provider in Candidates ist
        provider_ids = [c["component_id"] for c in result["selected_providers"]]
        assert expected_provider in provider_ids, (
            f"Expected provider {expected_provider} for style '{expected_style}', "
            f"got {provider_ids}"
        )


# ---------------------------------------------------------------------------
# Test 3: ExecutionAdapter → TemporalVibeManager State Consistency
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_execution_state_consistency(
    execution_adapter: OrchestratorExecutionAdapter,
    vibe_manager: TemporalVibeManager,
):
    """Teste die State-Konsistenz zwischen ExecutionAdapter und TemporalVibeManager.

    Validiert Lücke 3 (Vibe State → Execution Graph Snapshots).

    Hinweis: SESSION_MANAGEMENT → DIRECT (kein State), VIBE_TRANSITION → VIBE_CODING
    (braucht existierenden State). Daher verwenden wir AUDIO_GENERATION (→ SEMANTIC)
    für State-Erstellung und -Updates.
    """
    session_id = "state-consistency-test"

    # Execute mehrere Tasks — AUDIO_GENERATION mapped zu SEMANTIC,
    # was den EventRouter nutzt und State im VibeManager erstellt
    tasks = [
        ExecutionRequest(
            task_id="task-1",
            description="Generate audio - creates state",
            session_id=session_id,
            task_type=TaskType.AUDIO_GENERATION,
            context={"style": "ambient", "energy": 0.5},
        ),
        ExecutionRequest(
            task_id="task-2",
            description="Generate more audio - updates state",
            session_id=session_id,
            task_type=TaskType.AUDIO_GENERATION,
            context={"style": "techno", "energy": 0.8},
        ),
    ]

    for task in tasks:
        result = await execution_adapter.execute_task(task)
        assert result.success is True, f"Task {task.task_id} failed: {result.error_message}"

    # Prüfe Snapshot via VibeManager
    state = await vibe_manager.get_current_state(session_id)
    assert state is not None
    assert state.session_id == session_id

    # Prüfe Timeline
    timeline = await vibe_manager.get_session_timeline(session_id)
    assert len(timeline) >= 2, f"Expected >= 2 timeline entries, got {len(timeline)}"


# ---------------------------------------------------------------------------
# Test 4: AntigravityToOrchestratorBridge Kompatibilität
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_compatibility_bridge_integration(
    execution_adapter: OrchestratorExecutionAdapter,
):
    """Teste die AntigravityToOrchestratorBridge als Drop-in-Ersatz.

    Validiert Lücke 2 + 3: Der alte Antigravity-Code kann die Bridge nutzen.
    """
    bridge = AntigravityToOrchestratorBridge(execution_adapter)

    # Altes Antigravity-Interface — AUDIO_GENERATION (→ SEMANTIC) für State-Erstellung
    request = ExecutionRequest(
        task_id="bridge-test",
        description="Bridge test",
        session_id="bridge-session",
        task_type=TaskType.AUDIO_GENERATION,
        context={"style": "ambient", "energy": 0.5},
    )
    result = await bridge.execute_task(request)
    assert result.success is True

    # Strategien verfügbar
    strategies = await bridge.get_available_strategies()
    assert ExecutionStrategy.DIRECT in strategies
    assert ExecutionStrategy.SEMANTIC in strategies

    # Metriken — der interne Metrik-Key heißt "tasks_executed"
    metrics = await bridge.get_metrics()
    assert "tasks_executed" in metrics
    assert metrics["tasks_executed"] >= 1


# ---------------------------------------------------------------------------
# Test 5: CronIntelligenceEngine Integration (C2.3)
# ---------------------------------------------------------------------------


def test_cron_intelligence_integration():
    """Teste die Integration des SemanticIntentAnalyzer in die CronIntelligenceEngine.

    Validiert Lücke 4 (RalphIntentProcessor → Intelligence Pipeline).
    """
    registry = JobRegistry()

    # Registriere den Intent-Analyse-Job
    register_intent_analysis_job(registry)

    # Prüfe Job-Existenz
    job = registry.get("intelligence_semantic_intent_analysis")
    assert job is not None
    assert job.enabled is True
    assert job.metadata["engine"] == "semantic_intent"
    assert job.metadata["version"] == "2.0"

    # Prüfe dass der Job ausführbar ist (Handler existiert)
    assert callable(job.handler)


# ---------------------------------------------------------------------------
# Test 6: Vollständiger Resilience-Test (Fehlerbehandlung)
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_full_pipeline_resilience(
    semantic_analyzer: SemanticIntentAnalyzer,
    event_router: IREventRouter,
    execution_adapter: OrchestratorExecutionAdapter,
    vibe_manager: TemporalVibeManager,
):
    """Teste die Resilience der gesamten Pipeline bei Fehlern.

    - Unbekannter Intent
    - Event ohne Capabilities → sollte keine Provider matchen
    - Unbekannte Session
    """
    # 1. Unbekannter Intent → sollte nicht crashen
    intent = await semantic_analyzer.analyze("")
    assert intent.intent == "unknown"
    assert intent.confidence == 0.0

    # 2. Event ohne Routing-Capabilities → IREventRouter sollte graceful handeln
    #    (selected_providers kann trotzdem Provider enthalten, da der Router
    #     alle Capabilities matched wenn keine spezifischen angegeben sind)
    bad_event = {"type": "unknown", "session_id": "resilience-test"}
    result = await event_router.route_event(bad_event)
    # Router wirft keine Exception — das ist der Resilience-Test
    assert "selected_providers" in result
    assert "total_candidates" in result

    # 3. ExecutionAdapter mit unbekannter Session
    #    AUDIO_GENERATION (→ SEMANTIC) erstellt State im VibeManager
    request = ExecutionRequest(
        task_id="resilience-task",
        description="Resilience test",
        session_id="brand-new-session",
        task_type=TaskType.AUDIO_GENERATION,
        context={"style": "ambient", "energy": 0.5},
    )
    result = await execution_adapter.execute_task(request)
    assert result.success is True

    # 4. State existiert nach Execution
    state = await vibe_manager.get_current_state("brand-new-session")
    assert state is not None


# ---------------------------------------------------------------------------
# Test 7: TaskType → Strategy Mapping Konsistenz
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_task_type_strategy_mapping_consistency(
    execution_adapter: OrchestratorExecutionAdapter,
):
    """Teste dass alle TaskTypes korrekt auf Strategien gemappt werden."""
    mappings = {
        TaskType.SESSION_MANAGEMENT: ExecutionStrategy.DIRECT,
        TaskType.AUDIO_GENERATION: ExecutionStrategy.SEMANTIC,
        TaskType.VIBE_TRANSITION: ExecutionStrategy.VIBE_CODING,
        TaskType.PATTERN_CREATION: ExecutionStrategy.SEMANTIC,
        TaskType.PARAMETER_CONTROL: ExecutionStrategy.DIRECT,
        TaskType.FEEDBACK_PROCESSING: ExecutionStrategy.SEMANTIC,
    }

    for task_type, expected_strategy in mappings.items():
        strategy = execution_adapter.get_strategy_for_task_type(task_type)
        assert strategy == expected_strategy, (
            f"Expected {expected_strategy} for {task_type}, got {strategy}"
        )


# ---------------------------------------------------------------------------
# Test 8: Provider-Registrierung und IR-Graph Konsistenz
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_provider_ir_graph_consistency(
    capability_engine: CapabilityEngine,
    event_router: IREventRouter,
):
    """Teste dass Provider-Registrierung und IR-Graph konsistent sind.

    Validiert dass die IR-Graph-Struktur (C1.4) mit der
    CapabilityEngine (C1.3) übereinstimmt.
    """
    # IR-Graph vom EventRouter holen
    graph = event_router.get_graph()
    assert graph is not None

    # Prüfe dass alle registrierten Provider als Nodes existieren
    provider_ids = {"foxdot_adapter", "sc_adapter"}
    graph_node_ids = set(graph.nodes.keys())

    # Provider sollten als COMPONENT-Nodes existieren
    for pid in provider_ids:
        assert pid in graph_node_ids, f"Provider {pid} fehlt im IR-Graph"

    # Prüfe PROVIDES-Edges
    assert len(graph.edges) > 0, "IR-Graph sollte PROVIDES-Edges haben"

    # Prüfe dass Routing über IR-Graph funktioniert
    event = {
        "type": "vibe.start",
        "session_id": "graph-test",
        "semantic": {"style": "techno", "energy": 0.8},
        "routing": {"capabilities": ["pattern.create"]},
    }
    result = await event_router.route_event(event)
    # Techno + pattern.create → foxdot_adapter
    foxdot_found = any("foxdot_adapter" in c["component_id"] for c in result["selected_providers"])
    assert foxdot_found, "foxdot_adapter sollte für techno+pattern.create gefunden werden"


# ---------------------------------------------------------------------------
# Test 9: Shutdown-Korrektheit
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_graceful_shutdown(
    execution_adapter: OrchestratorExecutionAdapter,
    vibe_manager: TemporalVibeManager,
):
    """Teste dass alle Komponenten graceful shutdown können."""
    # Vorher: Tasks ausführen
    request = ExecutionRequest(
        task_id="shutdown-task",
        description="Shutdown test",
        session_id="shutdown-session",
        task_type=TaskType.SESSION_MANAGEMENT,
        context={"action": "start"},
    )
    result = await execution_adapter.execute_task(request)
    assert result.success is True

    # Shutdown
    await execution_adapter.shutdown()
    await vibe_manager.shutdown()

    # Nach Shutdown: Keine weiteren Tasks möglich (Adapter ist gestoppt)
    # Aber keine Exception sollte fliegen
    result2 = await execution_adapter.execute_task(request)
    assert result2.success is False  # Sollte fehlschlagen nach Shutdown


# ---------------------------------------------------------------------------
# Test 10: Factory Function Integration
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_factory_function_integration(
    capability_engine: CapabilityEngine,
    event_router: IREventRouter,
    vibe_manager: TemporalVibeManager,
):
    """Teste die create_orchestrator_adapter Factory Function.

    Hinweis: create_orchestrator_adapter erstellt intern einen IntentOrchestrator,
    der keinen vibe_manager-Parameter akzeptiert. Daher wird der Factory-Aufruf
    ohne vibe_manager getestet.
    """
    adapter = await create_orchestrator_adapter(
        capability_engine=capability_engine,
        event_router=event_router,
    )
    assert adapter is not None
    assert isinstance(adapter, OrchestratorExecutionAdapter)

    # Factory-Adapter sollte Tasks ausführen können
    request = ExecutionRequest(
        task_id="factory-test",
        description="Factory test",
        session_id="factory-session",
        task_type=TaskType.SESSION_MANAGEMENT,
        context={"action": "start"},
    )
    result = await adapter.execute_task(request)
    assert result.success is True
