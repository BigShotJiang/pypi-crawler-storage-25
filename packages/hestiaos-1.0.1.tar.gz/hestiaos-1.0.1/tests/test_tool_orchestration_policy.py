#!/usr/bin/env python3
"""
Test HSP Policy for Tool Orchestration
"""

import asyncio
import sys
import os
from datetime import datetime
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from core.hsp.policies.tool_orchestration_policy import (
    ToolOrchestrationPolicy,
    ToolSecurityLevel,
    ToolPerformanceProfile
)
from core.hsp.schemas import HSPRequestSchema


async def test_tool_orchestration_policy():
    """Test the tool orchestration HSP policy"""
    
    policy = ToolOrchestrationPolicy()
    
    print("=== Testing Tool Orchestration Policy ===")
    print("=" * 50)
    
    # Test 1: Public repository (low security)
    print("\n--- Test 1: Public Repository ---")
    public_request = HSPRequestSchema(
        request_id="test-1",
        trace_id="trace-1",
        timestamp=datetime.now().isoformat(),
        context={
            "repository_type": "public",
            "data_sensitivity": "low",
            "compliance_requirements": [],
            "urgency": "normal",
            "resource_constraints": {
                "memory_mb": 2048,
                "timeout_seconds": 300
            }
        },
        source="test",
        metadata={}
    )
    
    tool_configs = [
        {"tool_id": "bandit", "name": "Bandit"},
        {"tool_id": "radon", "name": "Radon"},
        {"tool_id": "pylint", "name": "Pylint"},
        {"tool_id": "safety", "name": "Safety"}  # This requires network access
    ]
    
    constraints = await policy.evaluate(public_request, tool_configs)
    
    print(f"Security Level: {constraints.metadata.get('security_level')}")
    print(f"Performance Profile: {constraints.metadata.get('performance_profile')}")
    print(f"Allowed Tools: {constraints.tools.allowed_tools}")
    print(f"Denied Tools: {constraints.tools.denied_tools}")
    print(f"Max Tool Calls: {constraints.tools.max_tool_calls}")
    print(f"Timeout: {constraints.tools.tool_timeout_seconds}s")
    print(f"Is Valid: {constraints.is_valid}")
    print(f"Validation Errors: {constraints.validation_errors}")
    print(f"Reasoning:\n{constraints.reasoning}")
    
    # Test 2: Internal repository with compliance requirements
    print("\n--- Test 2: Internal Repository with GDPR ---")
    gdpr_request = HSPRequestSchema(
        request_id="test-2",
        trace_id="trace-2",
        timestamp=datetime.now().isoformat(),
        context={
            "repository_type": "private",
            "data_sensitivity": "high",
            "compliance_requirements": ["gdpr"],
            "urgency": "normal",
            "resource_constraints": {
                "memory_mb": 1024,
                "timeout_seconds": 180
            }
        },
        source="test",
        metadata={}
    )
    
    constraints2 = await policy.evaluate(gdpr_request, tool_configs)
    
    print(f"Security Level: {constraints2.metadata.get('security_level')}")
    print(f"Allowed Tools: {constraints2.tools.allowed_tools}")
    print(f"Denied Tools: {constraints2.tools.denied_tools}")
    print(f"Audit Required: {constraints2.policies.audit_required}")
    print(f"Approval Required: {constraints2.metadata.get('requires_approval', False)}")
    print(f"Is Valid: {constraints2.is_valid}")
    
    # Test 3: Classified repository (highest security)
    print("\n--- Test 3: Classified Repository ---")
    classified_request = HSPRequestSchema(
        request_id="test-3",
        trace_id="trace-3",
        timestamp=datetime.now().isoformat(),
        context={
            "repository_type": "classified",
            "data_sensitivity": "critical",
            "compliance_requirements": ["pci_dss", "hipaa"],
            "urgency": "high",
            "resource_constraints": {
                "memory_mb": 4096,
                "timeout_seconds": 600
            }
        },
        source="test",
        metadata={}
    )
    
    constraints3 = await policy.evaluate(classified_request, tool_configs)
    
    print(f"Security Level: {constraints3.metadata.get('security_level')}")
    print(f"Allowed Tools: {constraints3.tools.allowed_tools}")
    print(f"Denied Tools: {constraints3.tools.denied_tools}")
    print(f"Is Valid: {constraints3.is_valid}")
    print(f"Validation Errors: {constraints3.validation_errors}")
    
    # Test 4: Tool validation at different security levels
    print("\n--- Test 4: Tool Validation by Security Level ---")
    
    test_tools = ["bandit", "radon", "pylint", "safety", "trivy"]
    
    for security_level in ToolSecurityLevel:
        validation = policy.validate_tool_selection(test_tools, security_level)
        print(f"\n{security_level.value}:")
        print(f"  Valid: {validation['valid']}")
        print(f"  Valid Tools: {validation['valid_tools']}")
        print(f"  Invalid Tools: {validation['invalid_tools']}")
        if validation['recommendations']:
            print(f"  Recommendations: {validation['recommendations'][0]}")
    
    # Test 5: Performance profile determination
    print("\n--- Test 5: Performance Profile Determination ---")
    
    test_contexts = [
        {"memory_mb": 512, "urgency": "normal", "expected": ToolPerformanceProfile.LIGHTWEIGHT},
        {"memory_mb": 1024, "urgency": "high", "expected": ToolPerformanceProfile.STANDARD},
        {"memory_mb": 2048, "urgency": "normal", "expected": ToolPerformanceProfile.STANDARD},
        {"memory_mb": 4096, "urgency": "normal", "expected": ToolPerformanceProfile.HEAVY},
    ]
    
    for ctx in test_contexts:
        profile = policy._determine_performance_profile({
            "resource_constraints": {"memory_mb": ctx["memory_mb"]},
            "urgency": ctx["urgency"]
        })
        print(f"Memory: {ctx['memory_mb']}MB, Urgency: {ctx['urgency']} -> {profile.value} "
              f"(expected: {ctx['expected'].value})")
        assert profile == ctx['expected'], f"Mismatch: {profile} != {ctx['expected']}"
    
    print("\n=== All Tests Passed ===")
    return True


async def test_integration_with_tool_orchestrator():
    """Test integration between policy and tool orchestrator"""
    print("\n=== Testing Policy-Orchestrator Integration ===")
    
    from core.capabilities.tool_orchestration import ToolOrchestratorCapability
    from core.hsp.policies.tool_orchestration_policy import ToolOrchestrationPolicy
    
    # Create instances
    orchestrator = ToolOrchestratorCapability()
    policy = ToolOrchestrationPolicy()
    
    # Simulate a code review request
    context = {
        "repository_type": "internal",
        "data_sensitivity": "medium",
        "compliance_requirements": [],
        "language": "python",
        "file_path": "/path/to/code.py"
    }
    
    # Discover available tools
    available_tools = await orchestrator.discover_available_tools(context)
    print(f"Available tools: {[t.tool_id for t in available_tools]}")
    
    # Create HSP request
    request = HSPRequestSchema(
        request_id="integration-test",
        trace_id="integration-trace",
        timestamp=datetime.now().isoformat(),
        context=context,
        source="integration_test",
        metadata={}
    )
    
    # Convert tool configs for policy evaluation
    tool_configs = [{"tool_id": t.tool_id, "name": t.name} for t in available_tools]
    
    # Get policy constraints
    constraints = await policy.evaluate(request, tool_configs)
    
    print(f"\nPolicy Constraints:")
    print(f"  Allowed tools: {constraints.tools.allowed_tools}")
    print(f"  Denied tools: {constraints.tools.denied_tools}")
    print(f"  Max concurrent: {constraints.metadata.get('concurrent_tools_limit', 1)}")
    print(f"  Max memory: {constraints.resources.max_memory_mb}MB")
    
    # Filter tools based on policy
    allowed_tool_configs = [t for t in available_tools if t.tool_id in constraints.tools.allowed_tools]
    
    print(f"\nFiltered Tools (after policy):")
    for tool in allowed_tool_configs:
        print(f"  - {tool.tool_id}: {tool.name}")
    
    # Simulate execution with policy constraints
    if allowed_tool_configs and constraints.is_valid:
        print("\nPolicy allows tool execution with constraints:")
        print(f"  Max tool calls: {constraints.tools.max_tool_calls}")
        print(f"  Timeout: {constraints.tools.tool_timeout_seconds}s")
        print(f"  Max execution time: {constraints.resources.max_latency_ms}ms")
        
        # In a real scenario, we would execute tools here with these constraints
        return True
    else:
        print("\nPolicy blocks tool execution")
        print(f"Validation errors: {constraints.validation_errors}")
        return False


async def main():
    """Main test function"""
    print("Testing HSP Policy for Tool Orchestration")
    print("=" * 50)
    
    try:
        # Test basic policy functionality
        await test_tool_orchestration_policy()
        
        # Test integration with tool orchestrator
        await test_integration_with_tool_orchestrator()
        
        print("\n" + "=" * 50)
        print("SUCCESS: All tests passed!")
        return True
        
    except Exception as e:
        print(f"\nERROR: {e}")
        import traceback
        traceback.print_exc()
        return False


if __name__ == "__main__":
    success = asyncio.run(main())
    sys.exit(0 if success else 1)