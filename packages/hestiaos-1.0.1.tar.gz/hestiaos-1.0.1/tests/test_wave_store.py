# tests/test_wave_store.py
import pytest
from core.protocol.wave_store import WaveStore
from core.protocol.wave import WaveState


def test_wave_store_create_and_get():
    store = WaveStore()
    wave = store.create_wave(
        tenant_id="tenant1",
        created_by="user1",
        request_id="req123"
    )
    
    assert wave.tenant_id == "tenant1"
    assert wave.created_by == "user1"
    assert wave.request_id == "req123"
    assert wave.state == WaveState.CREATED
    
    # Retrieve the wave
    retrieved = store.get_wave(wave.wave_id, tenant_id="tenant1")
    assert retrieved.wave_id == wave.wave_id
    assert retrieved.tenant_id == "tenant1"


def test_wave_store_get_nonexistent():
    store = WaveStore()
    with pytest.raises(KeyError):
        store.get_wave("nonexistent", tenant_id="tenant1")


def test_wave_store_get_wrong_tenant():
    store = WaveStore()
    wave = store.create_wave(tenant_id="tenant1", created_by="user1")
    
    with pytest.raises(KeyError):
        store.get_wave(wave.wave_id, tenant_id="tenant2")


def test_wave_store_list_waves():
    store = WaveStore()
    
    # Create waves for different tenants
    wave1 = store.create_wave(tenant_id="tenant1", created_by="user1")
    wave2 = store.create_wave(tenant_id="tenant1", created_by="user2")
    wave3 = store.create_wave(tenant_id="tenant2", created_by="user3")
    
    # List waves for tenant1
    tenant1_waves = store.list_waves(tenant_id="tenant1")
    assert len(tenant1_waves) == 2
    wave_ids = {w.wave_id for w in tenant1_waves}
    assert wave1.wave_id in wave_ids
    assert wave2.wave_id in wave_ids
    assert wave3.wave_id not in wave_ids
    
    # List waves for tenant2
    tenant2_waves = store.list_waves(tenant_id="tenant2")
    assert len(tenant2_waves) == 1
    assert tenant2_waves[0].wave_id == wave3.wave_id


def test_wave_store_delete_wave():
    store = WaveStore()
    wave = store.create_wave(tenant_id="tenant1", created_by="user1")
    
    # Delete the wave
    store.delete_wave(wave.wave_id, tenant_id="tenant1")
    
    # Verify it's gone
    with pytest.raises(KeyError):
        store.get_wave(wave.wave_id, tenant_id="tenant1")
    
    # Verify list is empty
    assert len(store.list_waves(tenant_id="tenant1")) == 0


def test_wave_store_delete_immutable_wave():
    store = WaveStore()
    wave = store.create_wave(tenant_id="t1", created_by="tester")
    
    # legal lifecycle
    wave.transition(WaveState.PROPAGATION_PENDING)
    wave.transition(WaveState.PROPAGATED)
    wave.transition(WaveState.SYNC_PENDING)
    wave.transition(WaveState.COMMITTED)
    
    # Try to delete immutable wave
    with pytest.raises(ValueError, match="Cannot delete immutable wave"):
        store.delete_wave(wave.wave_id, tenant_id="t1")
    
    # Verify wave still exists
    retrieved = store.get_wave(wave.wave_id, tenant_id="t1")
    assert retrieved.state == WaveState.COMMITTED


def test_wave_store_delete_wrong_tenant():
    store = WaveStore()
    wave = store.create_wave(tenant_id="tenant1", created_by="user1")
    
    # Try to delete with wrong tenant
    with pytest.raises(KeyError):
        store.delete_wave(wave.wave_id, tenant_id="tenant2")
    
    # Verify wave still exists
    assert store.get_wave(wave.wave_id, tenant_id="tenant1") is not None


def test_wave_store_isolation_between_stores():
    store1 = WaveStore()
    store2 = WaveStore()
    
    wave1 = store1.create_wave(tenant_id="tenant1", created_by="user1")
    
    # Wave should not exist in store2
    with pytest.raises(KeyError):
        store2.get_wave(wave1.wave_id, tenant_id="tenant1")
    
    # Create same wave in store2
    wave2 = store2.create_wave(tenant_id="tenant1", created_by="user1")
    assert wave1.wave_id != wave2.wave_id  # Different IDs