"""
G2 — Budget Coupling Tests.

Prüft Priorität 3 des hybriden Governance-Layers:

🟢 Priorität 3 — Budget Determinism (INV-G2-007)
    compute_budget_factor() ist eine reine Funktion:
    - Gleicher Input → gleicher Output
    - Keine I/O, keine Seiteneffekte
    - Deterministische Matrix

Siehe: plans/g2_runtime_governance_coupling.md
"""

import pytest

from core.governance.system_mode import SystemMode
from core.governance.drift_policy import DriftLevel
from core.governance.budget_coupling import compute_budget_factor


class TestBudgetCouplingMatrix:
    """INV-G2-007: compute_budget_factor() Matrix-Korrektheit."""

    def test_budget_execute_clean(self):
        """EXECUTE + CLEAN → 1.0 (volle Kapazität)."""
        factor = compute_budget_factor(SystemMode.EXECUTE, DriftLevel.CLEAN)
        assert factor == 1.0

    def test_budget_execute_warning(self):
        """EXECUTE + WARNING → 0.8."""
        factor = compute_budget_factor(SystemMode.EXECUTE, DriftLevel.WARNING)
        assert factor == 0.8

    def test_budget_execute_degraded(self):
        """EXECUTE + DEGRADED → 0.5."""
        factor = compute_budget_factor(SystemMode.EXECUTE, DriftLevel.DEGRADED)
        assert factor == 0.5

    def test_budget_execute_breaker(self):
        """EXECUTE + BREAKER → 0.0 (keine Kapazität)."""
        factor = compute_budget_factor(SystemMode.EXECUTE, DriftLevel.BREAKER)
        assert factor == 0.0

    def test_budget_throttle_clean(self):
        """THROTTLE + CLEAN → 0.7."""
        factor = compute_budget_factor(SystemMode.THROTTLE, DriftLevel.CLEAN)
        assert factor == 0.7

    def test_budget_throttle_warning(self):
        """THROTTLE + WARNING → 0.5."""
        factor = compute_budget_factor(SystemMode.THROTTLE, DriftLevel.WARNING)
        assert factor == 0.5

    def test_budget_throttle_degraded(self):
        """THROTTLE + DEGRADED → 0.3."""
        factor = compute_budget_factor(SystemMode.THROTTLE, DriftLevel.DEGRADED)
        assert factor == 0.3

    def test_budget_throttle_breaker(self):
        """THROTTLE + BREAKER → 0.0."""
        factor = compute_budget_factor(SystemMode.THROTTLE, DriftLevel.BREAKER)
        assert factor == 0.0

    def test_budget_degraded_clean(self):
        """DEGRADED + CLEAN → 0.3."""
        factor = compute_budget_factor(SystemMode.DEGRADED, DriftLevel.CLEAN)
        assert factor == 0.3

    def test_budget_degraded_warning(self):
        """DEGRADED + WARNING → 0.2."""
        factor = compute_budget_factor(SystemMode.DEGRADED, DriftLevel.WARNING)
        assert factor == 0.2

    def test_budget_degraded_degraded(self):
        """DEGRADED + DEGRADED → 0.1."""
        factor = compute_budget_factor(SystemMode.DEGRADED, DriftLevel.DEGRADED)
        assert factor == 0.1

    def test_budget_degraded_breaker(self):
        """DEGRADED + BREAKER → 0.0."""
        factor = compute_budget_factor(SystemMode.DEGRADED, DriftLevel.BREAKER)
        assert factor == 0.0

    def test_budget_block_override_clean(self):
        """BLOCK_OVERRIDE + CLEAN → 0.0."""
        factor = compute_budget_factor(SystemMode.BLOCK_OVERRIDE, DriftLevel.CLEAN)
        assert factor == 0.0

    def test_budget_block_override_warning(self):
        """BLOCK_OVERRIDE + WARNING → 0.0."""
        factor = compute_budget_factor(SystemMode.BLOCK_OVERRIDE, DriftLevel.WARNING)
        assert factor == 0.0

    def test_budget_block_override_degraded(self):
        """BLOCK_OVERRIDE + DEGRADED → 0.0."""
        factor = compute_budget_factor(SystemMode.BLOCK_OVERRIDE, DriftLevel.DEGRADED)
        assert factor == 0.0

    def test_budget_block_override_breaker(self):
        """BLOCK_OVERRIDE + BREAKER → 0.0."""
        factor = compute_budget_factor(SystemMode.BLOCK_OVERRIDE, DriftLevel.BREAKER)
        assert factor == 0.0


class TestBudgetDeterminism:
    """INV-G2-007: compute_budget_factor() ist eine reine Funktion."""

    def test_budget_pure_function(self):
        """INV-G2-007: Gleicher Input → gleicher Output (Determinismus)."""
        result_1 = compute_budget_factor(SystemMode.EXECUTE, DriftLevel.CLEAN)
        result_2 = compute_budget_factor(SystemMode.EXECUTE, DriftLevel.CLEAN)
        result_3 = compute_budget_factor(SystemMode.EXECUTE, DriftLevel.CLEAN)

        assert result_1 == result_2 == result_3 == 1.0

    def test_budget_deterministic_all_combinations(self):
        """Alle 16 Kombinationen sind deterministisch."""
        for mode in SystemMode:
            for level in DriftLevel:
                r1 = compute_budget_factor(mode, level)
                r2 = compute_budget_factor(mode, level)
                assert r1 == r2, (
                    f"Nicht-deterministisch für {mode}.{level}: {r1} != {r2}"
                )

    def test_budget_no_side_effects(self):
        """INV-G2-007: Keine I/O, keine Mutation — prüfbar durch Wiederholbarkeit."""
        # Mehrmaliger Aufruf darf keine Seiteneffekte haben
        factors_before = [
            compute_budget_factor(mode, level)
            for mode in SystemMode
            for level in DriftLevel
        ]

        # Nochmal aufrufen
        factors_after = [
            compute_budget_factor(mode, level)
            for mode in SystemMode
            for level in DriftLevel
        ]

        assert factors_before == factors_after


class TestBudgetEdgeCases:
    """Grenzfälle für compute_budget_factor()."""

    def test_budget_unknown_mode_defaults_zero(self):
        """Unbekannter SystemMode → Default 0.0."""
        # Verwende einen String statt Enum (zur Laufzeit möglich)
        factor = compute_budget_factor("UNKNOWN_MODE", DriftLevel.CLEAN)  # type: ignore
        assert factor == 0.0

    def test_budget_unknown_level_defaults_zero(self):
        """Unbekannter DriftLevel → Default 0.0."""
        factor = compute_budget_factor(SystemMode.EXECUTE, "UNKNOWN_LEVEL")  # type: ignore
        assert factor == 0.0

    def test_budget_monotonic_decreasing(self):
        """Budget-Faktor ist monoton fallend mit steigendem DriftLevel."""
        for mode in SystemMode:
            clean = compute_budget_factor(mode, DriftLevel.CLEAN)
            warning = compute_budget_factor(mode, DriftLevel.WARNING)
            degraded = compute_budget_factor(mode, DriftLevel.DEGRADED)
            breaker = compute_budget_factor(mode, DriftLevel.BREAKER)

            assert clean >= warning >= degraded >= breaker, (
                f"Monotonie verletzt für {mode}: "
                f"{clean} >= {warning} >= {degraded} >= {breaker}"
            )

    def test_budget_monotonic_decreasing_by_mode(self):
        """Budget-Faktor ist monoton fallend mit steigender Mode-Strenge."""
        for level in DriftLevel:
            execute = compute_budget_factor(SystemMode.EXECUTE, level)
            throttle = compute_budget_factor(SystemMode.THROTTLE, level)
            degraded = compute_budget_factor(SystemMode.DEGRADED, level)
            block = compute_budget_factor(SystemMode.BLOCK_OVERRIDE, level)

            assert execute >= throttle >= degraded >= block, (
                f"Mode-Monotonie verletzt für {level}: "
                f"{execute} >= {throttle} >= {degraded} >= {block}"
            )
