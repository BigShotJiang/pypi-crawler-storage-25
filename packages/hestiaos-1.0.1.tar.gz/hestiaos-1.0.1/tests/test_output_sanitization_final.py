#!/usr/bin/env python3
"""Final test for output sanitization with reasoning filtering."""

import sys
sys.path.insert(0, '.')

from core.output_filter import OutputFilter
from core.processing.response_processor import ResponseContractProcessor, PatternMatcher
from core.contracts.response_contract import ResponseContract, OutputChannel

def test_mixed_language_output():
    """Test mixed language output with English reasoning and German answer."""
    raw_output = '''<think>
Okay, the user said "hallo," which is the German word for "hello." I need to respond in a friendly and helpful manner. Since the user is speaking German, I should reply in German as well.

Hallo! Ich bin hier, um Ihnen zu helfen. Wie kann ich Ihnen heute assistieren?
</think>'''
    
    print("Testing mixed language output...")
    print(f"Raw output length: {len(raw_output)}")
    print(f"Raw output preview: {raw_output[:100]}...")
    
    # Test OutputFilter
    output_filter = OutputFilter(debug_mode=False, strict_mode=True)
    contract = output_filter.filter(raw_output)
    
    print(f"\nOutputFilter result:")
    print(f"  Has reasoning: {contract.get_channel(OutputChannel.REASONING) is not None}")
    print(f"  Has response: {contract.get_channel(OutputChannel.RESPONSE) is not None}")
    
    reasoning = contract.get_channel(OutputChannel.REASONING)
    response = contract.get_channel(OutputChannel.RESPONSE)
    
    if reasoning:
        print(f"  Reasoning length: {len(reasoning)}")
        print(f"  Reasoning preview: {reasoning[:100]}...")
    
    if response:
        print(f"  Response length: {len(response)}")
        print(f"  Response: {response}")
    
    display_output = output_filter.get_display_output(contract)
    print(f"\nDisplay output: {display_output}")
    
    # Test ResponseContractProcessor directly
    print("\n" + "="*80)
    print("Testing ResponseContractProcessor directly...")
    
    processor = ResponseContractProcessor(strict_mode=True)
    contract2 = processor.process(raw_output)
    
    print(f"ResponseContractProcessor result:")
    print(f"  Has reasoning: {contract2.get_channel(OutputChannel.REASONING) is not None}")
    print(f"  Has response: {contract2.get_channel(OutputChannel.RESPONSE) is not None}")
    
    reasoning2 = contract2.get_channel(OutputChannel.REASONING)
    response2 = contract2.get_channel(OutputChannel.RESPONSE)
    
    if reasoning2:
        print(f"  Reasoning length: {len(reasoning2)}")
        print(f"  Reasoning preview: {reasoning2[:100]}...")
    
    if response2:
        print(f"  Response length: {len(response2)}")
        print(f"  Response: {response2}")
    
    display_output2 = contract2.get_display_output(debug_mode=False)
    print(f"\nDisplay output: {display_output2}")
    
    # Verify that reasoning is filtered out
    assert response is not None, "Response should not be None"
    assert "<think>" not in response, "Response should not contain <think> tags"
    assert "Okay, the user said" not in response, "Response should not contain English reasoning"
    assert "Hallo! Ich bin hier" in response, "Response should contain German answer"
    
    print("\n✅ Test passed: Reasoning correctly filtered, only German answer remains")

def test_informal_reasoning():
    """Test informal reasoning without XML tags."""
    raw_output = '''Okay, the user greeted me with "hallo". I should respond in German since they're using German.

Hallo! Wie geht es Ihnen heute?'''
    
    print("\n" + "="*80)
    print("Testing informal reasoning...")
    
    output_filter = OutputFilter(debug_mode=False, strict_mode=True)
    contract = output_filter.filter(raw_output)
    
    response = contract.get_channel(OutputChannel.RESPONSE)
    print(f"Response: {response}")
    
    # In this case, the entire output might be treated as response
    # since there's no clear reasoning marker
    assert response is not None, "Response should not be None"
    
    print("✅ Informal reasoning test completed")

def test_greeting_only():
    """Test simple greeting without reasoning."""
    raw_output = "Hallo! Wie kann ich Ihnen helfen?"
    
    print("\n" + "="*80)
    print("Testing greeting only...")
    
    output_filter = OutputFilter(debug_mode=False, strict_mode=True)
    contract = output_filter.filter(raw_output)
    
    response = contract.get_channel(OutputChannel.RESPONSE)
    reasoning = contract.get_channel(OutputChannel.REASONING)
    
    print(f"Response: {response}")
    print(f"Reasoning: {reasoning}")
    
    assert response == raw_output, "Simple greeting should be passed through as response"
    assert reasoning is None, "No reasoning should be detected"
    
    print("✅ Greeting only test passed")

if __name__ == "__main__":
    print("="*80)
    print("FINAL OUTPUT SANITIZATION TEST SUITE")
    print("="*80)
    
    try:
        test_mixed_language_output()
        test_informal_reasoning()
        test_greeting_only()
        
        print("\n" + "="*80)
        print("✅ ALL TESTS PASSED - Output sanitization is working correctly!")
        print("="*80)
    except Exception as e:
        print(f"\n❌ Test failed: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)