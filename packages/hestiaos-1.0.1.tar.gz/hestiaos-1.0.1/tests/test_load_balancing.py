import unittest
import asyncio
from unittest.mock import MagicMock, patch

from core.agent_registry import AgentRegistry, AgentStatus, AgentCapability
from core.consciousness_identity import IdentityManager
from core.load_balancer import ConsciousnessLoadBalancer
from core.agent_communication import AgentRole

class TestLoadBalancing(unittest.TestCase):
    def setUp(self):
        # We need a real-ish IdentityManager because AgentRegistry accesses nested attributes
        self.identity = IdentityManager("orchestrator_main", AgentRole.ORCHESTRATOR.value)
        
        self.registry = AgentRegistry(self.identity)
        self.lb = ConsciousnessLoadBalancer(self.registry)
        self.registry.set_load_balancer(self.lb)

    async def async_test_least_load_selection(self):
        """Verify that the least loaded agent is selected"""
        # 1. Register two agents with same role
        agent1_id = "worker_1"
        agent2_id = "worker_2"
        role = "worker"
        
        await self.registry.register_agent(agent1_id, "Worker 1", role, status=AgentStatus.ACTIVE)
        await self.registry.register_agent(agent2_id, "Worker 2", role, status=AgentStatus.ACTIVE)
        
        a1 = self.registry.get_agent(agent1_id)
        a2 = self.registry.get_agent(agent2_id)
        
        # Add capabilities
        a1.add_capability(AgentCapability.LLM_INFERENCE)
        a2.add_capability(AgentCapability.LLM_INFERENCE)
        
        # 2. Set high load on agent 1, low load on agent 2
        a1.cpu_usage = 90.0
        a1.memory_usage = 80.0
        
        a2.cpu_usage = 10.0
        a2.memory_usage = 20.0
        
        # 3. Request recommendation
        best = self.registry.recommend_agent_for_task([AgentCapability.LLM_INFERENCE])
        
        # 4. Verify agent 2 (less loaded) was chosen
        self.assertIsNotNone(best)
        self.assertEqual(best.agent_id, agent2_id, f"Expected {agent2_id} to be selected, but got {best.agent_id}")

    def test_load_balancing_logic(self):
        asyncio.run(self.async_test_least_load_selection())

if __name__ == "__main__":
    unittest.main()
