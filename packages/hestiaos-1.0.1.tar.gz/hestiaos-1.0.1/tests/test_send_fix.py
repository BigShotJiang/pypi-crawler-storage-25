#!/usr/bin/env python3
"""
Test the fixed _send_message logic.
"""
import asyncio
import httpx
import json
from datetime import datetime

async def test_send_message():
    """Test sending a message with the fixed logic"""
    print("🔍 Testing Fixed _send_message Logic")
    print("=" * 60)
    
    server_url = "https://cloud.walter-consult.com"
    username = "HestiaOS"
    password = "3kUqYk$7~EUNWHDE%C3%"
    token = "6mvoe63h"
    verify_ssl = True
    
    # Test message
    timestamp = datetime.now().strftime("%H:%M:%S")
    test_id = f"diag-{int(datetime.now().timestamp())}"
    test_message = f"[Test {test_id}] Fix verification at {timestamp}"
    
    endpoint = f"{server_url}/ocs/v1.php/apps/spreed/api/v1/chat/{token}"
    headers = {
        "OCS-APIRequest": "true",
        "Accept": "application/json",
        "Content-Type": "application/json"
    }
    
    print(f"📤 Sending: '{test_message}'")
    
    try:
        async with httpx.AsyncClient(timeout=10.0, verify=verify_ssl) as client:
            resp = await client.post(
                endpoint,
                headers=headers,
                auth=(username, password),
                json={"message": test_message}
            )
            
            print(f"\n📥 Response:")
            print(f"  HTTP Status: {resp.status_code}")
            
            if resp.headers.get('content-type', '').lower().startswith('application/json'):
                data = resp.json()
                ocs_meta = data.get('ocs', {}).get('meta', {})
                ocs_status = ocs_meta.get('status', 'unknown')
                ocs_statuscode = ocs_meta.get('statuscode', 'unknown')
                ocs_message = ocs_meta.get('message', '')
                
                print(f"  OCS Status: {ocs_status}")
                print(f"  OCS Status code: {ocs_statuscode}")
                if ocs_message:
                    print(f"  OCS Message: {ocs_message}")
                
                # Check for message ID
                ocs_data = data.get('ocs', {}).get('data', {})
                has_message_id = isinstance(ocs_data, dict) and "id" in ocs_data
                
                if has_message_id:
                    message_id = ocs_data["id"]
                    print(f"  ✅ Message ID: {message_id}")
                
                # Apply the fixed logic
                success = False
                
                # SUCCESS conditions
                if has_message_id:
                    print(f"  ✅ FIXED LOGIC: SUCCESS (message ID present)")
                    success = True
                elif resp.status_code in [200, 201]:
                    # Check for auth errors
                    is_auth_error = (
                        ocs_statuscode in [401, 403, 404] or
                        "unauthorised" in ocs_message.lower() or
                        "forbidden" in ocs_message.lower() or
                        "not found" in ocs_message.lower()
                    )
                    
                    if is_auth_error:
                        print(f"  ❌ FIXED LOGIC: FAILURE (auth error)")
                        success = False
                    else:
                        print(f"  ✅ FIXED LOGIC: SUCCESS (HTTP success, no auth error)")
                        success = True
                else:
                    print(f"  ❌ FIXED LOGIC: FAILURE (HTTP failure)")
                    success = False
                
                # Verify message appears
                if success:
                    print(f"\n🔍 Verifying message appears...")
                    await asyncio.sleep(1)
                    
                    poll_resp = await client.get(
                        endpoint,
                        headers=headers,
                        auth=(username, password),
                        params={"lookIntoFuture": 0, "limit": 5, "format": "json"}
                    )
                    
                    if poll_resp.status_code == 200:
                        poll_data = poll_resp.json()
                        messages = poll_data.get('ocs', {}).get('data', [])
                        
                        found = any(
                            test_id in msg.get('message', '')
                            for msg in messages
                        )
                        
                        if found:
                            print(f"  ✅ Message confirmed in room")
                        else:
                            print(f"  ⚠️  Message not in recent 5 messages")
                
                return success
            else:
                print(f"  ⚠️  Non-JSON response")
                if resp.status_code in [200, 201]:
                    print(f"  ✅ FIXED LOGIC: SUCCESS (HTTP success)")
                    return True
                else:
                    print(f"  ❌ FIXED LOGIC: FAILURE (HTTP failure)")
                    return False
                    
    except Exception as e:
        print(f"  ❌ Error: {e}")
        return False

async def main():
    """Run test"""
    print("🚀 Nextcloud Talk Send Logic Fix Test")
    print("=" * 60)
    
    success = await test_send_message()
    
    print("\n" + "=" * 60)
    print("📊 TEST RESULT")
    print("=" * 60)
    
    if success:
        print("✅ FIX VERIFIED")
        print("  _send_message now correctly identifies successful sends")
        print("\n🎯 FIX SUMMARY:")
        print("  1. Checks for message ID presence (definite success)")
        print("  2. Checks HTTP 200/201 with no auth errors")
        print("  3. Handles OCS status 'failure' with code 201 as success")
        print("  4. Properly detects auth/permission errors")
    else:
        print("❌ FIX FAILED")
        print("  Need to investigate further")
    
    print("\n🚀 NEXT STEPS:")
    print("1. Restart HestiaOS to load fixed plugin")
    print("2. Send '@hestia diag-123' in Nextcloud Talk")
    print("3. Verify response appears in room")
    
    return success

if __name__ == "__main__":
    result = asyncio.run(main())
    exit(0 if result else 1)