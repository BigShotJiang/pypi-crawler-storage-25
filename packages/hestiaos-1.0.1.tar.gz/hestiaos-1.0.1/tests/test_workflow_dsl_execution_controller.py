"""
Tests for Workflow DSL — execution_controller.py (ExecutionController).
"""

import asyncio
import pytest
import os
import tempfile

from core.workflow_dsl.execution_controller import (
    ExecutionController,
    ExecutionControllerError,
    RunStateSnapshot,
)
from core.workflow_dsl.run_store import (
    WorkflowRunStore,
    RunStatus,
    StepRunStatus,
)
from core.workflow_dsl.run_state_machine import RunStateMachine
from core.workflow_dsl.step_tracker import StepStateTracker


class TestExecutionController:
    def setup_method(self):
        self.temp_db = tempfile.NamedTemporaryFile(suffix=".db", delete=False)
        self.temp_db.close()
        self.store = WorkflowRunStore(db_path=self.temp_db.name)
        self.state_machine = RunStateMachine()
        self.step_tracker = StepStateTracker(self.store)
        self.controller = ExecutionController(
            store=self.store,
            state_machine=self.state_machine,
            step_tracker=self.step_tracker,
        )

    def teardown_method(self):
        self.store.close()
        os.unlink(self.temp_db.name)

    def _create_running_run(self) -> str:
        """Helper: create a run in RUNNING state."""
        run = self.store.create_run(
            workflow_name="test_wf",
            workflow_version="1.0.0",
            trigger_type="manual",
        )
        self.store.update_run_status(run.run_id, RunStatus.RUNNING)
        return run.run_id

    def _create_paused_run(self) -> str:
        """Helper: create a run in PAUSED state."""
        run_id = self._create_running_run()
        self.store.update_run_status(run_id, RunStatus.PAUSED)
        return run_id

    # --- pause ---

    @pytest.mark.asyncio
    async def test_pause_running(self):
        run_id = self._create_running_run()
        result = await self.controller.pause(run_id)
        assert result.status == RunStatus.PAUSED

    @pytest.mark.asyncio
    async def test_pause_pending_raises(self):
        run = self.store.create_run(
            workflow_name="test_wf", workflow_version="1.0.0", trigger_type="manual",
        )
        with pytest.raises(ExecutionControllerError, match="Invalid transition"):
            await self.controller.pause(run.run_id)

    @pytest.mark.asyncio
    async def test_pause_nonexistent_raises(self):
        with pytest.raises(ExecutionControllerError, match="not found"):
            await self.controller.pause("nonexistent")

    @pytest.mark.asyncio
    async def test_pause_already_paused_raises(self):
        run_id = self._create_paused_run()
        with pytest.raises(ExecutionControllerError, match="Invalid transition"):
            await self.controller.pause(run_id)

    @pytest.mark.asyncio
    async def test_pause_completed_raises(self):
        run_id = self._create_running_run()
        self.store.update_run_status(run_id, RunStatus.COMPLETED)
        with pytest.raises(ExecutionControllerError, match="Invalid transition"):
            await self.controller.pause(run_id)

    # --- resume ---

    @pytest.mark.asyncio
    async def test_resume_paused(self):
        run_id = self._create_paused_run()
        result = await self.controller.resume(run_id)
        assert result.status == RunStatus.RUNNING

    @pytest.mark.asyncio
    async def test_resume_running_raises(self):
        run_id = self._create_running_run()
        with pytest.raises(ExecutionControllerError, match="Invalid transition"):
            await self.controller.resume(run_id)

    @pytest.mark.asyncio
    async def test_resume_nonexistent_raises(self):
        with pytest.raises(ExecutionControllerError, match="not found"):
            await self.controller.resume("nonexistent")

    @pytest.mark.asyncio
    async def test_resume_completed_raises(self):
        run_id = self._create_running_run()
        self.store.update_run_status(run_id, RunStatus.COMPLETED)
        with pytest.raises(ExecutionControllerError, match="Invalid transition"):
            await self.controller.resume(run_id)

    # --- cancel ---

    @pytest.mark.asyncio
    async def test_cancel_pending(self):
        run = self.store.create_run(
            workflow_name="test_wf", workflow_version="1.0.0", trigger_type="manual",
        )
        result = await self.controller.cancel(run.run_id)
        assert result.status == RunStatus.CANCELLED

    @pytest.mark.asyncio
    async def test_cancel_running(self):
        run_id = self._create_running_run()
        result = await self.controller.cancel(run_id)
        assert result.status == RunStatus.CANCELLED

    @pytest.mark.asyncio
    async def test_cancel_paused(self):
        run_id = self._create_paused_run()
        result = await self.controller.cancel(run_id)
        assert result.status == RunStatus.CANCELLED

    @pytest.mark.asyncio
    async def test_cancel_with_reason(self):
        run_id = self._create_running_run()
        result = await self.controller.cancel(run_id, reason="manual override")
        assert result.error == "manual override"

    @pytest.mark.asyncio
    async def test_cancel_nonexistent_raises(self):
        with pytest.raises(ExecutionControllerError, match="not found"):
            await self.controller.cancel("nonexistent")

    @pytest.mark.asyncio
    async def test_cancel_completed_raises(self):
        run_id = self._create_running_run()
        self.store.update_run_status(run_id, RunStatus.COMPLETED)
        with pytest.raises(ExecutionControllerError, match="terminal state"):
            await self.controller.cancel(run_id)

    @pytest.mark.asyncio
    async def test_cancel_cancels_active_steps(self):
        run_id = self._create_running_run()
        ctx = self.step_tracker.start_step(run_id, "s1", "Step 1", "llm")
        await self.controller.cancel(run_id, reason="abort")

        # Step should be failed
        record = self.store.get_step_state(run_id, "s1")
        assert record.status == StepRunStatus.FAILED
        assert "abort" in record.error

    # --- fail ---

    @pytest.mark.asyncio
    async def test_fail_running(self):
        run_id = self._create_running_run()
        result = await self.controller.fail(run_id, error="timeout")
        assert result.status == RunStatus.FAILED
        assert result.error == "timeout"

    @pytest.mark.asyncio
    async def test_fail_pending_raises(self):
        run = self.store.create_run(
            workflow_name="test_wf", workflow_version="1.0.0", trigger_type="manual",
        )
        with pytest.raises(ExecutionControllerError, match="Invalid transition"):
            await self.controller.fail(run.run_id, error="crash")

    @pytest.mark.asyncio
    async def test_fail_nonexistent_raises(self):
        with pytest.raises(ExecutionControllerError, match="not found"):
            await self.controller.fail("nonexistent", error="crash")

    @pytest.mark.asyncio
    async def test_fail_fails_active_steps(self):
        run_id = self._create_running_run()
        ctx = self.step_tracker.start_step(run_id, "s1", "Step 1", "llm")
        await self.controller.fail(run_id, error="system error")

        record = self.store.get_step_state(run_id, "s1")
        assert record.status == StepRunStatus.FAILED

    # --- complete ---

    @pytest.mark.asyncio
    async def test_complete_running(self):
        run_id = self._create_running_run()
        result = await self.controller.complete(run_id)
        assert result.status == RunStatus.COMPLETED

    @pytest.mark.asyncio
    async def test_complete_pending_raises(self):
        run = self.store.create_run(
            workflow_name="test_wf", workflow_version="1.0.0", trigger_type="manual",
        )
        with pytest.raises(ExecutionControllerError, match="Invalid transition"):
            await self.controller.complete(run.run_id)

    @pytest.mark.asyncio
    async def test_complete_nonexistent_raises(self):
        with pytest.raises(ExecutionControllerError, match="not found"):
            await self.controller.complete("nonexistent")

    # --- get_run_state ---

    def test_get_run_state_exists(self):
        run_id = self._create_running_run()
        snapshot = self.controller.get_run_state(run_id)
        assert snapshot is not None
        assert snapshot.run_id == run_id
        assert snapshot.status == RunStatus.RUNNING
        assert snapshot.steps == []
        assert snapshot.has_active_steps is False

    def test_get_run_state_with_steps(self):
        run_id = self._create_running_run()
        self.step_tracker.start_step(run_id, "s1", "Step 1", "llm")
        self.step_tracker.start_step(run_id, "s2", "Step 2", "tool")

        snapshot = self.controller.get_run_state(run_id)
        assert len(snapshot.steps) == 2
        assert snapshot.has_active_steps is True

    def test_get_run_state_with_completed_step(self):
        run_id = self._create_running_run()
        ctx = self.step_tracker.start_step(run_id, "s1", "Step 1", "llm")
        self.step_tracker.complete_step(ctx)

        snapshot = self.controller.get_run_state(run_id)
        assert len(snapshot.steps) == 1
        assert snapshot.steps[0]["status"] == "completed"
        assert snapshot.has_active_steps is False

    def test_get_run_state_not_found(self):
        snapshot = self.controller.get_run_state("nonexistent")
        assert snapshot is None

    def test_get_run_state_cancelled(self):
        run_id = self._create_running_run()
        self.step_tracker.start_step(run_id, "s1", "Step 1", "llm")
        # Cancel via controller to properly fail steps
        import asyncio
        asyncio.run(self.controller.cancel(run_id, reason="test"))

        snapshot = self.controller.get_run_state(run_id)
        assert snapshot.status == RunStatus.CANCELLED
        assert snapshot.error == "test"
        assert snapshot.steps[0]["status"] == "failed"

    # --- can_control ---

    def test_can_control_running(self):
        run_id = self._create_running_run()
        assert self.controller.can_control(run_id) is True

    def test_can_control_paused(self):
        run_id = self._create_paused_run()
        assert self.controller.can_control(run_id) is True

    def test_can_control_pending(self):
        run = self.store.create_run(
            workflow_name="test_wf", workflow_version="1.0.0", trigger_type="manual",
        )
        assert self.controller.can_control(run.run_id) is True

    def test_can_control_completed(self):
        run_id = self._create_running_run()
        self.store.update_run_status(run_id, RunStatus.COMPLETED)
        assert self.controller.can_control(run_id) is False

    def test_can_control_failed(self):
        run_id = self._create_running_run()
        self.store.update_run_status(run_id, RunStatus.FAILED)
        assert self.controller.can_control(run_id) is False

    def test_can_control_cancelled(self):
        run_id = self._create_running_run()
        self.store.update_run_status(run_id, RunStatus.CANCELLED)
        assert self.controller.can_control(run_id) is False

    def test_can_control_nonexistent(self):
        assert self.controller.can_control("nonexistent") is False

    # --- pause/resume cycle ---

    @pytest.mark.asyncio
    async def test_pause_resume_cycle(self):
        run_id = self._create_running_run()
        await self.controller.pause(run_id)
        assert self.store.get_run(run_id).status == RunStatus.PAUSED
        await self.controller.resume(run_id)
        assert self.store.get_run(run_id).status == RunStatus.RUNNING
        await self.controller.pause(run_id)
        assert self.store.get_run(run_id).status == RunStatus.PAUSED
        await self.controller.resume(run_id)
        assert self.store.get_run(run_id).status == RunStatus.RUNNING

    @pytest.mark.asyncio
    async def test_concurrent_pause_resume_same_run(self):
        """Concurrent operations on the same run should be serialized."""
        run_id = self._create_running_run()

        async def pause_then_resume():
            await self.controller.pause(run_id)
            await self.controller.resume(run_id)

        async def cancel_it():
            await self.controller.cancel(run_id)

        # Run concurrently — should not corrupt state
        await asyncio.gather(pause_then_resume(), cancel_it())
        final = self.store.get_run(run_id)
        assert final.status in (RunStatus.RUNNING, RunStatus.CANCELLED)
