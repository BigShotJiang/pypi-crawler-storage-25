"""
Tests for Workflow DSL — registry.py (WorkflowRegistry).
"""

import pytest
import os
import tempfile
import shutil

from core.workflow_dsl.registry import WorkflowRegistry, RegistryError
from core.workflow_dsl.models import (
    WorkflowDefinition,
    StepDefinition,
    StepType,
    TriggerConfig,
    TriggerType,
)


class TestWorkflowRegistry:
    def setup_method(self):
        self.temp_dir = tempfile.mkdtemp()
        self.registry = WorkflowRegistry(base_dir=self.temp_dir)

    def teardown_method(self):
        shutil.rmtree(self.temp_dir)

    def _make_workflow(
        self, name: str = "test_wf", version: str = "1.0.0"
    ) -> WorkflowDefinition:
        return WorkflowDefinition(
            name=name,
            version=version,
            description=f"{name} v{version}",
            steps=[StepDefinition(id="s1", name="Step 1", type=StepType.LLM)],
            triggers=[TriggerConfig(type=TriggerType.WEBHOOK)],
        )

    def test_register(self):
        wf = self._make_workflow()
        result = self.registry.register(wf)
        assert result == "1.0.0"

        expected_path = os.path.join(self.temp_dir, "test_wf", "v1.0.0.yaml")
        assert os.path.exists(expected_path)

    def test_register_duplicate_version_raises(self):
        wf = self._make_workflow()
        self.registry.register(wf)
        with pytest.raises(RegistryError, match="already exists"):
            self.registry.register(wf)

    def test_get_latest_version(self):
        self.registry.register(self._make_workflow(version="1.0.0"))
        self.registry.register(self._make_workflow(version="2.0.0"))

        result = self.registry.get("test_wf")
        assert result is not None
        assert result.version == "2.0.0"

    def test_get_specific_version(self):
        self.registry.register(self._make_workflow(version="1.0.0"))
        self.registry.register(self._make_workflow(version="2.0.0"))

        result = self.registry.get("test_wf", "1.0.0")
        assert result is not None
        assert result.version == "1.0.0"

    def test_get_nonexistent_workflow(self):
        result = self.registry.get("nonexistent")
        assert result is None

    def test_get_nonexistent_version(self):
        self.registry.register(self._make_workflow())
        result = self.registry.get("test_wf", "9.9.9")
        assert result is None

    def test_list_empty(self):
        result = self.registry.list()
        assert result == []

    def test_list_multiple_workflows(self):
        self.registry.register(self._make_workflow(name="wf_a", version="1.0.0"))
        self.registry.register(self._make_workflow(name="wf_b", version="1.0.0"))

        result = self.registry.list()
        assert len(result) == 2
        names = {m.name for m in result}
        assert names == {"wf_a", "wf_b"}

    def test_list_versions(self):
        self.registry.register(self._make_workflow(version="1.0.0"))
        self.registry.register(self._make_workflow(version="2.0.0"))
        self.registry.register(self._make_workflow(version="1.5.0"))

        versions = self.registry.list_versions("test_wf")
        assert versions == ["1.0.0", "1.5.0", "2.0.0"]

    def test_list_versions_nonexistent(self):
        versions = self.registry.list_versions("nonexistent")
        assert versions == []

    def test_delete_version(self):
        self.registry.register(self._make_workflow(version="1.0.0"))
        self.registry.register(self._make_workflow(version="2.0.0"))

        result = self.registry.delete("test_wf", "1.0.0")
        assert result is True

        versions = self.registry.list_versions("test_wf")
        assert versions == ["2.0.0"]

    def test_delete_all_versions(self):
        self.registry.register(self._make_workflow(version="1.0.0"))
        self.registry.register(self._make_workflow(version="2.0.0"))

        result = self.registry.delete("test_wf")
        assert result is True

        result = self.registry.get("test_wf")
        assert result is None

    def test_delete_nonexistent(self):
        result = self.registry.delete("nonexistent")
        assert result is False

    def test_delete_nonexistent_version(self):
        self.registry.register(self._make_workflow())
        result = self.registry.delete("test_wf", "9.9.9")
        assert result is False

    def test_round_trip_preserves_data(self):
        original = self._make_workflow(name="roundtrip", version="1.0.0")
        self.registry.register(original)

        loaded = self.registry.get("roundtrip")
        assert loaded is not None
        assert loaded.name == "roundtrip"
        assert loaded.version == "1.0.0"
        assert loaded.description == "roundtrip v1.0.0"
        assert len(loaded.steps) == 1
        assert loaded.steps[0].id == "s1"
        assert len(loaded.triggers) == 1
        assert loaded.triggers[0].type == TriggerType.WEBHOOK
