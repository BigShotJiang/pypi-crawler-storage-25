"""
Tests for Workflow DSL — run_store.py (WorkflowRunStore).
"""

import pytest
import os
import tempfile
import json

from core.workflow_dsl.run_store import (
    WorkflowRunStore,
    RunRecord,
    StepRecord,
    RunStatus,
    StepRunStatus,
)


class TestRunRecord:
    def test_default_status(self):
        record = RunRecord(
            run_id="test-1",
            workflow_name="test_wf",
            workflow_version="1.0.0",
            trigger_type="manual",
        )
        assert record.status == RunStatus.PENDING
        assert record.created_at is not None
        assert record.updated_at is not None

    def test_custom_status(self):
        record = RunRecord(
            run_id="test-1",
            workflow_name="test_wf",
            workflow_version="1.0.0",
            trigger_type="webhook",
            status=RunStatus.RUNNING,
        )
        assert record.status == RunStatus.RUNNING


class TestStepRecord:
    def test_default_status(self):
        step = StepRecord(
            run_id="run-1",
            step_id="s1",
            step_name="Step 1",
            step_type="llm",
        )
        assert step.status == StepRunStatus.PENDING
        assert step.retry_count == 0

    def test_with_snapshots(self):
        step = StepRecord(
            run_id="run-1",
            step_id="s1",
            step_name="Step 1",
            step_type="llm",
            input_snapshot={"prompt": "hello"},
            output_snapshot={"response": "world"},
        )
        assert step.input_snapshot["prompt"] == "hello"
        assert step.output_snapshot["response"] == "world"


class TestWorkflowRunStore:
    def setup_method(self):
        self.temp_db = tempfile.NamedTemporaryFile(suffix=".db", delete=False)
        self.temp_db.close()
        self.store = WorkflowRunStore(db_path=self.temp_db.name)

    def teardown_method(self):
        self.store.close()
        os.unlink(self.temp_db.name)

    # --- Run CRUD ---

    def test_create_run(self):
        record = self.store.create_run(
            workflow_name="test_wf",
            workflow_version="1.0.0",
            trigger_type="manual",
        )
        assert record.run_id is not None
        assert record.status == RunStatus.PENDING
        assert record.workflow_name == "test_wf"

    def test_create_run_with_custom_id(self):
        record = self.store.create_run(
            workflow_name="test_wf",
            workflow_version="1.0.0",
            trigger_type="webhook",
            run_id="custom-id-123",
        )
        assert record.run_id == "custom-id-123"

    def test_create_run_with_payload(self):
        record = self.store.create_run(
            workflow_name="test_wf",
            workflow_version="1.0.0",
            trigger_type="webhook",
            trigger_payload={"event": "push", "repo": "test"},
        )
        assert record.trigger_payload["event"] == "push"

    def test_get_run_exists(self):
        created = self.store.create_run(
            workflow_name="test_wf",
            workflow_version="1.0.0",
            trigger_type="manual",
        )
        fetched = self.store.get_run(created.run_id)
        assert fetched is not None
        assert fetched.run_id == created.run_id
        assert fetched.status == RunStatus.PENDING

    def test_get_run_not_found(self):
        result = self.store.get_run("nonexistent")
        assert result is None

    def test_update_run_status(self):
        created = self.store.create_run(
            workflow_name="test_wf",
            workflow_version="1.0.0",
            trigger_type="manual",
        )
        result = self.store.update_run_status(created.run_id, RunStatus.RUNNING)
        assert result is True

        fetched = self.store.get_run(created.run_id)
        assert fetched.status == RunStatus.RUNNING

    def test_update_run_status_with_error(self):
        created = self.store.create_run(
            workflow_name="test_wf",
            workflow_version="1.0.0",
            trigger_type="manual",
        )
        self.store.update_run_status(
            created.run_id, RunStatus.FAILED, error="Something went wrong"
        )
        fetched = self.store.get_run(created.run_id)
        assert fetched.status == RunStatus.FAILED
        assert fetched.error == "Something went wrong"

    def test_update_run_nonexistent(self):
        result = self.store.update_run_status("nonexistent", RunStatus.RUNNING)
        assert result is False

    def test_list_runs_empty(self):
        runs = self.store.list_runs()
        assert runs == []

    def test_list_runs_all(self):
        self.store.create_run(workflow_name="wf_a", workflow_version="1.0.0", trigger_type="manual")
        self.store.create_run(workflow_name="wf_b", workflow_version="1.0.0", trigger_type="webhook")
        runs = self.store.list_runs()
        assert len(runs) == 2

    def test_list_runs_filter_by_workflow(self):
        self.store.create_run(workflow_name="wf_a", workflow_version="1.0.0", trigger_type="manual")
        self.store.create_run(workflow_name="wf_b", workflow_version="1.0.0", trigger_type="manual")
        runs = self.store.list_runs(workflow_name="wf_a")
        assert len(runs) == 1
        assert runs[0].workflow_name == "wf_a"

    def test_list_runs_filter_by_status(self):
        r1 = self.store.create_run(workflow_name="wf_a", workflow_version="1.0.0", trigger_type="manual")
        self.store.create_run(workflow_name="wf_b", workflow_version="1.0.0", trigger_type="manual")
        self.store.update_run_status(r1.run_id, RunStatus.RUNNING)
        runs = self.store.list_runs(status=RunStatus.RUNNING)
        assert len(runs) == 1

    def test_list_runs_limit_offset(self):
        for i in range(5):
            self.store.create_run(
                workflow_name="test_wf",
                workflow_version="1.0.0",
                trigger_type="manual",
            )
        runs = self.store.list_runs(limit=2, offset=0)
        assert len(runs) == 2

    def test_delete_run(self):
        created = self.store.create_run(
            workflow_name="test_wf",
            workflow_version="1.0.0",
            trigger_type="manual",
        )
        result = self.store.delete_run(created.run_id)
        assert result is True
        assert self.store.get_run(created.run_id) is None

    def test_delete_run_nonexistent(self):
        result = self.store.delete_run("nonexistent")
        assert result is False

    # --- Step CRUD ---

    def test_save_and_get_step(self):
        run = self.store.create_run(
            workflow_name="test_wf",
            workflow_version="1.0.0",
            trigger_type="manual",
        )
        step = StepRecord(
            run_id=run.run_id,
            step_id="s1",
            step_name="Step 1",
            step_type="llm",
        )
        self.store.save_step_state(step)

        fetched = self.store.get_step_state(run.run_id, "s1")
        assert fetched is not None
        assert fetched.step_id == "s1"
        assert fetched.status == StepRunStatus.PENDING

    def test_save_step_with_snapshots(self):
        run = self.store.create_run(
            workflow_name="test_wf",
            workflow_version="1.0.0",
            trigger_type="manual",
        )
        step = StepRecord(
            run_id=run.run_id,
            step_id="s1",
            step_name="Step 1",
            step_type="llm",
            input_snapshot={"prompt": "hello"},
            output_snapshot={"response": "world"},
        )
        self.store.save_step_state(step)

        fetched = self.store.get_step_state(run.run_id, "s1")
        assert fetched.input_snapshot["prompt"] == "hello"
        assert fetched.output_snapshot["response"] == "world"

    def test_update_step_status(self):
        run = self.store.create_run(
            workflow_name="test_wf",
            workflow_version="1.0.0",
            trigger_type="manual",
        )
        step = StepRecord(
            run_id=run.run_id,
            step_id="s1",
            step_name="Step 1",
            step_type="llm",
        )
        self.store.save_step_state(step)

        result = self.store.update_step_status(
            run.run_id, "s1", StepRunStatus.COMPLETED,
            output_snapshot={"result": "done"},
            duration_ms=150.5,
        )
        assert result is True

        fetched = self.store.get_step_state(run.run_id, "s1")
        assert fetched.status == StepRunStatus.COMPLETED
        assert fetched.output_snapshot["result"] == "done"
        assert fetched.duration_ms == 150.5

    def test_list_step_states(self):
        run = self.store.create_run(
            workflow_name="test_wf",
            workflow_version="1.0.0",
            trigger_type="manual",
        )
        for i in range(3):
            step = StepRecord(
                run_id=run.run_id,
                step_id=f"s{i}",
                step_name=f"Step {i}",
                step_type="llm",
            )
            self.store.save_step_state(step)

        steps = self.store.list_step_states(run.run_id)
        assert len(steps) == 3
        assert steps[0].step_id == "s0"
        assert steps[2].step_id == "s2"

    def test_list_step_states_empty(self):
        run = self.store.create_run(
            workflow_name="test_wf",
            workflow_version="1.0.0",
            trigger_type="manual",
        )
        steps = self.store.list_step_states(run.run_id)
        assert steps == []

    def test_get_step_state_not_found(self):
        run = self.store.create_run(
            workflow_name="test_wf",
            workflow_version="1.0.0",
            trigger_type="manual",
        )
        result = self.store.get_step_state(run.run_id, "nonexistent")
        assert result is None

    # --- Stats ---

    def test_get_run_stats_empty(self):
        stats = self.store.get_run_stats()
        assert stats["total_runs"] == 0
        assert stats["by_status"] == {}
        assert stats["by_workflow"] == {}

    def test_get_run_stats_with_data(self):
        r1 = self.store.create_run(workflow_name="wf_a", workflow_version="1.0.0", trigger_type="manual")
        self.store.create_run(workflow_name="wf_a", workflow_version="1.0.0", trigger_type="manual")
        self.store.create_run(workflow_name="wf_b", workflow_version="1.0.0", trigger_type="manual")
        self.store.update_run_status(r1.run_id, RunStatus.RUNNING)

        stats = self.store.get_run_stats()
        assert stats["total_runs"] == 3
        assert stats["by_status"]["pending"] == 2
        assert stats["by_status"]["running"] == 1
        assert stats["by_workflow"]["wf_a"] == 2
        assert stats["by_workflow"]["wf_b"] == 1

    # --- Edge Cases ---

    def test_create_run_empty_workflow_name(self):
        record = self.store.create_run(
            workflow_name="",
            workflow_version="1.0.0",
            trigger_type="manual",
        )
        assert record.workflow_name == ""

    def test_multiple_runs_same_workflow(self):
        for i in range(10):
            self.store.create_run(
                workflow_name="test_wf",
                workflow_version="1.0.0",
                trigger_type="manual",
            )
        runs = self.store.list_runs(workflow_name="test_wf")
        assert len(runs) == 10

    def test_step_cascade_delete(self):
        """Steps should be deleted when their parent run is deleted."""
        run = self.store.create_run(
            workflow_name="test_wf",
            workflow_version="1.0.0",
            trigger_type="manual",
        )
        step = StepRecord(
            run_id=run.run_id,
            step_id="s1",
            step_name="Step 1",
            step_type="llm",
        )
        self.store.save_step_state(step)
        self.store.delete_run(run.run_id)

        steps = self.store.list_step_states(run.run_id)
        assert steps == []
