"""
Tests for Workflow DSL — triggers.py (TriggerDispatcher).
"""

import pytest
from unittest.mock import AsyncMock, MagicMock

from core.workflow_dsl.triggers import TriggerDispatcher, TriggerError
from core.workflow_dsl.context import WorkflowEvent
from core.workflow_dsl.models import (
    WorkflowDefinition,
    StepDefinition,
    StepType,
    TriggerConfig,
    TriggerType,
)


class TestTriggerDispatcher:
    def setup_method(self):
        self.execute_callback = AsyncMock()
        self.dispatcher = TriggerDispatcher(execute_callback=self.execute_callback)

    def _make_workflow(self, name: str = "test_wf") -> WorkflowDefinition:
        return WorkflowDefinition(
            name=name,
            version="1.0.0",
            steps=[StepDefinition(id="s1", name="Step 1", type=StepType.LLM)],
            triggers=[TriggerConfig(type=TriggerType.WEBHOOK)],
        )

    @pytest.mark.asyncio
    async def test_dispatch_calls_callback(self):
        event = WorkflowEvent(
            type="webhook",
            payload={"key": "value"},
            source="test",
            correlation_id="corr-1",
            workflow_name="test_wf",
        )
        await self.dispatcher.dispatch(event)
        self.execute_callback.assert_called_once_with(event)

    @pytest.mark.asyncio
    async def test_dispatch_without_callback_logs_warning(self):
        dispatcher = TriggerDispatcher(execute_callback=None)
        event = WorkflowEvent(
            type="webhook",
            payload={},
            source="test",
            correlation_id="corr-1",
        )
        # Should not raise
        await dispatcher.dispatch(event)

    @pytest.mark.asyncio
    async def test_dispatch_callback_error_raises_trigger_error(self):
        self.execute_callback.side_effect = Exception("Execution failed")
        event = WorkflowEvent(
            type="webhook",
            payload={},
            source="test",
            correlation_id="corr-1",
            workflow_name="test_wf",
        )
        with pytest.raises(TriggerError, match="Failed to execute workflow"):
            await self.dispatcher.dispatch(event)

    # --- Trigger factories ---

    def test_create_webhook_event(self):
        event = self.dispatcher.create_webhook_event(
            workflow_name="test_wf",
            payload={"code": "test"},
            source="gitlab",
            metadata={"branch": "main"},
        )
        assert event.type == "webhook"
        assert event.payload == {"code": "test"}
        assert event.source == "gitlab"
        assert event.workflow_name == "test_wf"
        assert event.metadata == {"branch": "main"}
        assert event.correlation_id is not None

    def test_create_event_bus_event(self):
        event = self.dispatcher.create_event_bus_event(
            workflow_name="test_wf",
            event_type="code_review.completed",
            payload={"review_id": 42},
            correlation_id="fixed-corr-id",
        )
        assert event.type == "event_bus"
        assert event.payload == {"review_id": 42}
        assert event.source == "event_bus"
        assert event.correlation_id == "fixed-corr-id"
        assert event.metadata == {"event_type": "code_review.completed"}

    def test_create_event_bus_event_auto_correlation_id(self):
        event = self.dispatcher.create_event_bus_event(
            workflow_name="test_wf",
            event_type="test.event",
            payload={},
        )
        assert event.correlation_id is not None
        assert len(event.correlation_id) > 0

    def test_create_schedule_event(self):
        event = self.dispatcher.create_schedule_event(
            workflow_name="test_wf",
            schedule_id="cron_daily",
            payload={"date": "2025-01-01"},
        )
        assert event.type == "schedule"
        assert event.payload == {"date": "2025-01-01"}
        assert event.source == "schedule:cron_daily"
        assert event.metadata == {"schedule_id": "cron_daily"}

    def test_create_schedule_event_default_payload(self):
        event = self.dispatcher.create_schedule_event(
            workflow_name="test_wf",
            schedule_id="hourly",
        )
        assert event.payload == {}

    def test_create_manual_event(self):
        event = self.dispatcher.create_manual_event(
            workflow_name="test_wf",
            payload={"reason": "manual review"},
            user="developer",
        )
        assert event.type == "manual"
        assert event.payload == {"reason": "manual review"}
        assert event.source == "user:developer"

    def test_create_manual_event_default_user(self):
        event = self.dispatcher.create_manual_event(
            workflow_name="test_wf",
        )
        assert event.source == "user:admin"

    # --- Webhook route management ---

    def test_register_webhook_route(self):
        path = self.dispatcher.register_webhook_route(
            "/webhooks/workflow/code_review", "code_review_wf"
        )
        assert path == "/webhooks/workflow/code_review"
        routes = self.dispatcher.get_webhook_routes()
        assert routes["/webhooks/workflow/code_review"] == "code_review_wf"

    def test_register_webhook_route_overwrite(self):
        self.dispatcher.register_webhook_route("/webhooks/test", "old_wf")
        self.dispatcher.register_webhook_route("/webhooks/test", "new_wf")
        routes = self.dispatcher.get_webhook_routes()
        assert routes["/webhooks/test"] == "new_wf"

    def test_unregister_webhook_route(self):
        self.dispatcher.register_webhook_route("/webhooks/test", "test_wf")
        result = self.dispatcher.unregister_webhook_route("/webhooks/test")
        assert result is True
        assert "/webhooks/test" not in self.dispatcher.get_webhook_routes()

    def test_unregister_nonexistent_route(self):
        result = self.dispatcher.unregister_webhook_route("/webhooks/nonexistent")
        assert result is False

    def test_get_webhook_routes_returns_copy(self):
        self.dispatcher.register_webhook_route("/webhooks/test", "test_wf")
        routes = self.dispatcher.get_webhook_routes()
        routes["/webhooks/hacked"] = "evil_wf"
        assert "/webhooks/hacked" not in self.dispatcher.get_webhook_routes()

    # --- EventBus subscription config ---

    def test_create_event_bus_subscription_config(self):
        workflow = self._make_workflow("test_wf")
        workflow.triggers = [
            TriggerConfig(type=TriggerType.EVENT, config={"event_type": "test.event"}),
            TriggerConfig(type=TriggerType.WEBHOOK),
        ]
        subscriptions = self.dispatcher.create_event_bus_subscription_config(workflow)
        assert len(subscriptions) == 1
        assert subscriptions[0]["event_type"] == "test.event"
        assert subscriptions[0]["workflow_name"] == "test_wf"

    def test_create_event_bus_subscription_config_wildcard(self):
        workflow = self._make_workflow("test_wf")
        workflow.triggers = [
            TriggerConfig(type=TriggerType.EVENT, config={}),
        ]
        subscriptions = self.dispatcher.create_event_bus_subscription_config(workflow)
        assert len(subscriptions) == 1
        assert subscriptions[0]["event_type"] == "*"

    def test_create_event_bus_subscription_config_no_event_triggers(self):
        workflow = self._make_workflow("test_wf")
        workflow.triggers = [
            TriggerConfig(type=TriggerType.WEBHOOK),
            TriggerConfig(type=TriggerType.MANUAL),
        ]
        subscriptions = self.dispatcher.create_event_bus_subscription_config(workflow)
        assert subscriptions == []

    def test_create_event_bus_subscription_config_with_filter(self):
        workflow = self._make_workflow("test_wf")
        workflow.triggers = [
            TriggerConfig(
                type=TriggerType.EVENT,
                config={
                    "event_type": "code_review.completed",
                    "filter": {"project": "hestia"},
                },
            ),
        ]
        subscriptions = self.dispatcher.create_event_bus_subscription_config(workflow)
        assert subscriptions[0]["filter"] == {"project": "hestia"}
