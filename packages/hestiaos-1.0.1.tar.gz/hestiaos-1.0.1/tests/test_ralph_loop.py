import asyncio
from pathlib import Path
from core.ralph_manager import RalphLoopManager

async def test_ralph_loop():
    print("🚀 Starte RALPH Loop Integrationstest...")
    
    # Path zum Test-Loop
    loop_dir = Path("ralph_loops/test_loop")
    manager = RalphLoopManager(loop_dir)
    
    # Test-Lauf (1 Iteration)
    print("🔄 Führe eine Iteration aus...")
    await manager.run_loop(iterations=1)
    
    # Verifizierung
    print("\n🔍 Verifizierung der Ergebnisse:")
    
    if manager.progress_file.exists():
        print(f"✅ progress.txt wurde erstellt.")
        print(f"Inhalt:\n---\n{manager.progress_file.read_text()}---")
    else:
        print("❌ progress.txt fehlt!")

    success_file = loop_dir / "ralph_success.txt"
    # Hinweis: Da der Agent in diesem Test-Setup (Kommandozeile) nicht wirklich 
    # Dateien schreiben kann (außer er nutzt Tools, die hier nicht gebunden sind),
    # erwarten wir primär den Log-Eintrag in progress.txt.
    
    print("\n✅ Test-Iteration abgeschlossen.")

if __name__ == "__main__":
    asyncio.run(test_ralph_loop())
