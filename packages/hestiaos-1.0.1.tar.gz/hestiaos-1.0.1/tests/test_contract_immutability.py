"""
Contract Immutability Tests — G1.0 Public Governance Contract Freeze.

Validates that all public governance schemas remain stable and that
real runtime outputs conform to the frozen contracts.

Key invariants tested:
- INV-CT-001: collapse() is deterministic (no I/O, no randomness)
- INV-CT-002: No field loss of security-relevant data
- INV-CT-003: No semantic transformation changes meaning
- INV-CT-004: ESL is the single source of truth for drift
- INV-CT-005: CommandTrace is pure projection (no enrichment)
- INV-DSGK-002: Same command + same snapshot → same decision (G1.1)
- INV-DSGK-003: DSGK decision NOT affected by SystemCondition (G1.1)
"""

import json
import os
from pathlib import Path
from typing import Any

import pytest
from jsonschema import validate, ValidationError

from core.commands.base import Command, CommandType
from core.governance.command_processor import process_command
from core.governance.command_trace import CommandTrace, trace_to_dict
from core.governance.dsgk_decision import DSGKDecision, build_decision
from core.governance.execution_boundary import ExecutionBoundary, ExecutionWitness
from core.governance.execution_semantics import ExecutionTrace, TraceRecorder, SideEffectClass


# ── Load Schemas ───────────────────────────────────────────────────

SCHEMA_DIR = Path(__file__).parent.parent / "core" / "governance" / "contracts"

with open(SCHEMA_DIR / "dsgk_decision.schema.json") as f:
    DSGK_DECISION_SCHEMA = json.load(f)

with open(SCHEMA_DIR / "command_trace.schema.json") as f:
    COMMAND_TRACE_SCHEMA = json.load(f)


# ── Helpers ────────────────────────────────────────────────────────

def _make_command(cmd_type: CommandType, cmd_input: str = "test input") -> Command:
    """Erzeugt einen minimalen Command für Tests."""
    from dataclasses import dataclass

    @dataclass(frozen=True)
    class _TestCommand(Command):
        command_type: CommandType = cmd_type
        input: str = cmd_input

    return _TestCommand()


def _deep_serialize(obj: Any) -> Any:
    """Rekursive Serialisierung für JSON-Schema-Validierung.
    
    Konvertiert Enums zu ihren .value-Strings und Dataclasses zu Dicts.
    """
    from dataclasses import is_dataclass, asdict
    from enum import Enum
    
    if isinstance(obj, Enum):
        return obj.value
    if is_dataclass(obj):
        return {k: _deep_serialize(v) for k, v in asdict(obj).items()}
    if isinstance(obj, dict):
        return {k: _deep_serialize(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [_deep_serialize(item) for item in obj]
    return obj


def _make_execution_trace(trace_id: str = "test_trace", drift_level: str = "PASS") -> ExecutionTrace:
    """Erzeugt einen minimalen ExecutionTrace für Tests."""
    return ExecutionTrace(
        id=trace_id,
        symbol="test_symbol",
        inputs={"command_type": "READ"},
        outputs={"drift_level": drift_level},
        env_hash="abc123",
        control_path_hash="def456",
        side_effect_profile=SideEffectClass.PURE,
        trace_hash="ghi789"
    )


# ── INV-CT-001: Deterministische Projektion ───────────────────────

class TestInvCT001:
    """INV-CT-001: collapse() ist deterministisch — kein I/O, keine Randomness."""

    def test_collapse_deterministic_same_input(self):
        """Gleicher Input → gleicher Output (deterministisch).
        
        timestamp wird von collapse() neu erzeugt und ist nicht deterministisch
        (Mikrosekunden-Drift). Alle anderen Felder müssen identisch sein.
        """
        cmd = _make_command(CommandType.READ)
        trace = process_command(cmd)
        exec_trace = _make_execution_trace()

        witness1 = ExecutionBoundary.collapse(trace, exec_trace)
        witness2 = ExecutionBoundary.collapse(trace, exec_trace)

        # Alle Felder außer timestamp müssen identisch sein
        assert witness1.command_id == witness2.command_id
        assert witness1.policy == witness2.policy
        assert witness1.decision == witness2.decision
        assert witness1.provider == witness2.provider
        assert witness1.latency_ms == witness2.latency_ms
        assert witness1.risk_score == witness2.risk_score
        assert witness1.drift_level == witness2.drift_level
        # timestamp wird neu erzeugt — nicht vergleichbar

    def test_collapse_deterministic_different_input(self):
        """Unterschiedlicher Input → unterschiedlicher Output (erwartet)."""
        cmd_read = _make_command(CommandType.READ)
        cmd_write = _make_command(CommandType.WRITE)
        trace_read = process_command(cmd_read)
        trace_write = process_command(cmd_write)
        exec_trace = _make_execution_trace()

        witness_read = ExecutionBoundary.collapse(trace_read, exec_trace)
        witness_write = ExecutionBoundary.collapse(trace_write, exec_trace)

        assert witness_read.command_id != witness_write.command_id, (
            "INV-CT-001 FAILED: Unterschiedliche Commands erzeugen gleiche command_id."
        )


# ── INV-CT-002: Kein Feldverlust ──────────────────────────────────

class TestInvCT002:
    """INV-CT-002: Kein Feldverlust von sicherheitsrelevanten Daten."""

    def test_witness_contains_all_required_fields(self):
        """ExecutionWitness muss alle sicherheitsrelevanten Felder enthalten."""
        cmd = _make_command(CommandType.READ)
        trace = process_command(cmd)
        exec_trace = _make_execution_trace()

        witness = ExecutionBoundary.collapse(trace, exec_trace)

        required_fields = ["command_id", "policy", "decision", "latency_ms", "timestamp", "risk_score", "drift_level"]
        for field in required_fields:
            assert hasattr(witness, field), (
                f"INV-CT-002 FAILED: Feld '{field}' fehlt im ExecutionWitness."
            )

    def test_decision_preserved_in_witness(self):
        """DSGK-Entscheidung muss unverändert im Witness erhalten bleiben."""
        cmd = _make_command(CommandType.READ)
        trace = process_command(cmd)
        exec_trace = _make_execution_trace()

        witness = ExecutionBoundary.collapse(trace, exec_trace)

        assert witness.decision == trace.dsgk_decision, (
            f"INV-CT-002 FAILED: Entscheidung verändert: "
            f"trace={trace.dsgk_decision}, witness={witness.decision}"
        )

    def test_policy_preserved_in_witness(self):
        """Policy muss unverändert im Witness erhalten bleiben."""
        cmd = _make_command(CommandType.READ)
        trace = process_command(cmd)
        exec_trace = _make_execution_trace()

        witness = ExecutionBoundary.collapse(trace, exec_trace)

        assert witness.policy == trace.policy, (
            f"INV-CT-002 FAILED: Policy verändert: "
            f"trace={trace.policy}, witness={witness.policy}"
        )


# ── INV-CT-003: Keine semantische Transformation ──────────────────

class TestInvCT003:
    """INV-CT-003: Keine Transformation verändert semantische Bedeutung."""

    def test_decision_type_stable(self):
        """decision muss str mit Enum-Werten bleiben."""
        cmd = _make_command(CommandType.READ)
        trace = process_command(cmd)
        exec_trace = _make_execution_trace()

        witness = ExecutionBoundary.collapse(trace, exec_trace)

        assert isinstance(witness.decision, str), (
            f"INV-CT-003 FAILED: decision Typ geändert: {type(witness.decision)}"
        )
        assert witness.decision in ("ALLOW", "ALLOW_WITH_WARNINGS", "BLOCK"), (
            f"INV-CT-003 FAILED: decision Wert außerhalb Enum: {witness.decision}"
        )

    def test_risk_score_type_stable(self):
        """risk_score muss float im Bereich [0.0, 1.0] bleiben."""
        cmd = _make_command(CommandType.READ)
        trace = process_command(cmd)
        exec_trace = _make_execution_trace()

        witness = ExecutionBoundary.collapse(trace, exec_trace)

        assert isinstance(witness.risk_score, float), (
            f"INV-CT-003 FAILED: risk_score Typ geändert: {type(witness.risk_score)}"
        )
        assert 0.0 <= witness.risk_score <= 1.0, (
            f"INV-CT-003 FAILED: risk_score außerhalb Bereich: {witness.risk_score}"
        )

    def test_latency_type_stable(self):
        """latency_ms muss float bleiben."""
        cmd = _make_command(CommandType.READ)
        trace = process_command(cmd)
        exec_trace = _make_execution_trace()

        witness = ExecutionBoundary.collapse(trace, exec_trace)

        assert isinstance(witness.latency_ms, float), (
            f"INV-CT-003 FAILED: latency_ms Typ geändert: {type(witness.latency_ms)}"
        )


# ── INV-CT-004: ESL als einzige Wahrheit ──────────────────────────

class TestInvCT004:
    """INV-CT-004: ESL ist die einzige autorisierte Quelle für Drift."""

    def test_drift_level_comes_from_esl(self):
        """drift_level muss aus ExecutionTrace stammen, nicht aus Heuristiken."""
        cmd = _make_command(CommandType.READ)
        trace = process_command(cmd)
        exec_trace = _make_execution_trace(drift_level="HARD_DRIFT")

        witness = ExecutionBoundary.collapse(trace, exec_trace)

        assert witness.drift_level == "HARD_DRIFT", (
            "INV-CT-004 FAILED: drift_level kommt nicht aus ExecutionTrace. "
            f"Erwartet: HARD_DRIFT, Erhalten: {witness.drift_level}"
        )

    def test_drift_level_defaults_to_pass(self):
        """Ohne drift_level im ExecutionTrace muss Default 'PASS' sein."""
        cmd = _make_command(CommandType.READ)
        trace = process_command(cmd)
        exec_trace = _make_execution_trace(drift_level="PASS")

        witness = ExecutionBoundary.collapse(trace, exec_trace)

        assert witness.drift_level == "PASS", (
            f"INV-CT-004 FAILED: Default drift_level sollte PASS sein: {witness.drift_level}"
        )


# ── INV-CT-005: CommandTrace = reine Projektion ───────────────────

class TestInvCT005:
    """INV-CT-005: CommandTrace ist write-once, immutable, reine Projektion."""

    def test_command_trace_immutable(self):
        """CommandTrace muss frozen sein (keine Mutation nach Erstellung)."""
        cmd = _make_command(CommandType.READ)
        trace = process_command(cmd)

        with pytest.raises(Exception):
            trace.dsgk_decision = "MUTATED"

    def test_command_trace_has_all_required_fields(self):
        """CommandTrace muss alle Pflichtfelder aus dem Schema enthalten."""
        cmd = _make_command(CommandType.READ)
        trace = process_command(cmd)

        required = ["command_id", "input", "dsgk_decision", "reason", "risk_score", "policy", "violations", "budget", "timestamp"]
        for field in required:
            assert hasattr(trace, field), (
                f"INV-CT-005 FAILED: Pflichtfeld '{field}' fehlt im CommandTrace."
            )

    def test_command_trace_no_enrichment(self):
        """CommandTrace darf keine Felder enthalten, die nicht im Schema definiert sind."""
        cmd = _make_command(CommandType.READ)
        trace = process_command(cmd)
        d = trace_to_dict(trace)

        # Erlaubte Felder aus dem Schema
        allowed = {
            "command_id", "input", "dsgk_decision", "reason", "risk_score",
            "policy", "violations", "budget", "budget_usage", "runtime_result",
            "parent_id", "epoch_id", "latency_ms", "execution_trace", "timestamp"
        }
        # G1.1 Erweiterungen: Agent Tracing (autorisiert für roo)
        authorized_extensions = {"agent_id", "sequence_id", "parent_agent_trace"}
        extra = set(d.keys()) - allowed - authorized_extensions
        assert not extra, (
            f"INV-CT-005 FAILED: CommandTrace enthält undefinierte Felder: {extra}"
        )


# ── Schema-Validierung gegen Runtime-Outputs ──────────────────────

class TestSchemaValidation:
    """Validates that real runtime outputs conform to frozen schemas."""

    def test_dsgk_decision_schema_conformant(self):
        """DSGKDecision muss dem dsgk_decision.schema.json entsprechen."""
        cmd = _make_command(CommandType.READ)
        from core.governance.command_processor import explain_decision
        decision = explain_decision(cmd)

        decision_dict = decision.to_dict()

        try:
            validate(instance=decision_dict, schema=DSGK_DECISION_SCHEMA)
        except ValidationError as e:
            pytest.fail(f"DSGKDecision schema violation: {e.message}")

    def test_command_trace_schema_conformant(self):
        """CommandTrace muss dem command_trace.schema.json entsprechen."""
        cmd = _make_command(CommandType.READ)
        trace = process_command(cmd)
        trace_dict = _deep_serialize(trace_to_dict(trace))

        try:
            validate(instance=trace_dict, schema=COMMAND_TRACE_SCHEMA)
        except ValidationError as e:
            pytest.fail(f"CommandTrace schema violation: {e.message}")

    def test_all_command_types_schema_conformant(self):
        """Alle CommandTypes müssen schema-konforme Traces produzieren."""
        for cmd_type in [CommandType.READ, CommandType.WRITE, CommandType.EXTERNAL]:
            cmd = _make_command(cmd_type)
            trace = process_command(cmd)
            trace_dict = _deep_serialize(trace_to_dict(trace))

            try:
                validate(instance=trace_dict, schema=COMMAND_TRACE_SCHEMA)
            except ValidationError as e:
                pytest.fail(
                    f"CommandTrace schema violation for {cmd_type.value}: {e.message}"
                )

    def test_block_decision_schema_conformant(self):
        """BLOCK-Entscheidungen müssen schema-konform sein."""
        cmd = _make_command(CommandType.EXTERNAL)
        from core.governance.command_processor import explain_decision
        decision = explain_decision(cmd)

        assert decision.decision.value == "BLOCK", (
            f"Erwartet BLOCK für EXTERNAL, erhalten: {decision.decision.value}"
        )

        decision_dict = decision.to_dict()
        try:
            validate(instance=decision_dict, schema=DSGK_DECISION_SCHEMA)
        except ValidationError as e:
            pytest.fail(f"BLOCK decision schema violation: {e.message}")


# ── Schema-Stabilität (keine unerwarteten Änderungen) ─────────────

class TestSchemaStability:
    """Stellt sicher, dass die Schema-Dateien selbst nicht unerwartet geändert werden."""

    def test_dsgk_schema_has_required_fields(self):
        """DSGK Schema muss alle erforderlichen Felder definieren."""
        required = ["decision", "reason", "risk_score", "policy", "violations"]
        props = DSGK_DECISION_SCHEMA.get("properties", {})
        for field in required:
            assert field in props, (
                f"Schema-Stabilität FAILED: Feld '{field}' fehlt im DSGK Schema."
            )

    def test_command_trace_schema_has_required_fields(self):
        """CommandTrace Schema muss alle erforderlichen Felder definieren."""
        required = ["command_id", "input", "dsgk_decision", "reason", "risk_score", "policy", "violations", "budget", "timestamp"]
        props = COMMAND_TRACE_SCHEMA.get("properties", {})
        for field in required:
            assert field in props, (
                f"Schema-Stabilität FAILED: Feld '{field}' fehlt im CommandTrace Schema."
            )

    def test_schema_additional_properties_false(self):
        """Beide Schemas müssen additionalProperties: false setzen."""
        assert DSGK_DECISION_SCHEMA.get("additionalProperties") is False, (
            "DSGK Schema erlaubt zusätzliche Felder (additionalProperties != false)."
        )
        assert COMMAND_TRACE_SCHEMA.get("additionalProperties") is False, (
            "CommandTrace Schema erlaubt zusätzliche Felder (additionalProperties != false)."
        )


# ── G1.1: DSGK Isolation Tests ──────────────────────────────────────


class TestG11DSGKIsolation:
    """G1.1: DSGK = Pure Function Boundary — ContextSnapshot Isolation.

    INV-DSGK-001: DSGK darf NIEMALS Runtime-Module importieren.
    INV-DSGK-002: Gleicher Command + gleicher Snapshot → gleiche Entscheidung.
    INV-DSGK-003: DSGK-Entscheidung darf NICHT von SystemCondition abhängen.
    """

    def test_dsgk_deterministic_with_snapshot(self):
        """INV-DSGK-002: Gleicher Command + gleicher Snapshot → identische Entscheidung.

        ContextSnapshot ist frozen → deterministischer Replay garantiert.
        build_decision() muss bei identischen Inputs identische Outputs liefern.
        """
        from core.governance.context_snapshot import ContextSnapshot

        snapshot = ContextSnapshot(
            governance_profile="balanced",
            performance_factor=1.0,
            policy_canon_hash="abc123",
            timestamp="2026-01-01T00:00:00",
        )

        d1 = build_decision(
            violations=[],
            policy="core.read.v1",
            profile="balanced",
            context_snapshot=snapshot,
        )
        d2 = build_decision(
            violations=[],
            policy="core.read.v1",
            profile="balanced",
            context_snapshot=snapshot,
        )

        assert d1.decision == d2.decision, (
            f"Determinismus verletzt: {d1.decision} != {d2.decision}"
        )
        assert d1.budget == d2.budget, (
            f"Budget-Determinismus verletzt: {d1.budget} != {d2.budget}"
        )
        assert d1.risk_score == d2.risk_score, (
            f"Risk-Score-Determinismus verletzt: {d1.risk_score} != {d2.risk_score}"
        )

    def test_dsgk_not_affected_by_runtime_state(self):
        """INV-DSGK-003: DSGK-Entscheidung darf NICHT von SystemCondition abhängen.

        Nur das Governance-Profil ändert sich (balanced → strict).
        Die Entscheidung (ALLOW/BLOCK) muss gleich bleiben.
        Nur das Budget darf sich unterscheiden (performance_factor).
        """
        from core.governance.context_snapshot import ContextSnapshot

        snapshot_balanced = ContextSnapshot(
            governance_profile="balanced",
            performance_factor=1.0,
            policy_canon_hash="abc123",
            timestamp="2026-01-01T00:00:00",
        )
        snapshot_strict = ContextSnapshot(
            governance_profile="strict",
            performance_factor=0.5,
            policy_canon_hash="abc123",
            timestamp="2026-01-01T00:00:00",
        )

        d_balanced = build_decision(
            violations=[],
            policy="core.read.v1",
            profile=snapshot_balanced.governance_profile,
            context_snapshot=snapshot_balanced,
        )
        d_strict = build_decision(
            violations=[],
            policy="core.read.v1",
            profile=snapshot_strict.governance_profile,
            context_snapshot=snapshot_strict,
        )

        # Entscheidung muss gleich bleiben (beide ALLOW)
        assert d_balanced.decision == d_strict.decision, (
            f"Runtime-State hat Entscheidung beeinflusst: "
            f"{d_balanced.decision} != {d_strict.decision}"
        )

        # Budget darf sich unterscheiden (performance_factor)
        # strict = 0.5 → geringeres Budget
        assert d_balanced.budget.max_tool_calls >= d_strict.budget.max_tool_calls, (
            f"strict profile sollte niedrigeres Budget haben: "
            f"{d_balanced.budget.max_tool_calls} < {d_strict.budget.max_tool_calls}"
        )

    def test_context_snapshot_immutable(self):
        """ContextSnapshot muss frozen sein — keine Mutation nach Erzeugung."""
        from dataclasses import FrozenInstanceError
        from core.governance.context_snapshot import ContextSnapshot

        snapshot = ContextSnapshot(
            governance_profile="balanced",
            performance_factor=1.0,
            policy_canon_hash="abc123",
            timestamp="2026-01-01T00:00:00",
        )

        with pytest.raises(FrozenInstanceError):
            snapshot.governance_profile = "strict"  # type: ignore

    def test_create_context_snapshot_returns_valid_snapshot(self):
        """create_context_snapshot() muss einen gültigen ContextSnapshot liefern."""
        from core.governance.context_snapshot import create_context_snapshot

        snapshot = create_context_snapshot()

        assert isinstance(snapshot.governance_profile, str), (
            f"governance_profile muss str sein, ist {type(snapshot.governance_profile)}"
        )
        assert isinstance(snapshot.performance_factor, float), (
            f"performance_factor muss float sein, ist {type(snapshot.performance_factor)}"
        )
        assert isinstance(snapshot.policy_canon_hash, str), (
            f"policy_canon_hash muss str sein, ist {type(snapshot.policy_canon_hash)}"
        )
        assert isinstance(snapshot.timestamp, str), (
            f"timestamp muss str sein, ist {type(snapshot.timestamp)}"
        )
        # timestamp muss ISO-8601 sein
        assert "T" in snapshot.timestamp, (
            f"timestamp muss ISO-8601 Format haben: {snapshot.timestamp}"
        )
