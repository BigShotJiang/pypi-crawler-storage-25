import pytest
import asyncio
from src.orchestrator import Orchestrator
from src.adapters.mcp_proxy_adapter import MCPProxyAdapter
from src.adapters.antigravity_adapter import AntigravityAdapter
from src.adapters.core_adapter import CoreAdapter

@pytest.fixture
async def orchestrator():
    o = Orchestrator()
    # Dummy Configs for testing
    o.register_adapter("mcp_proxy", MCPProxyAdapter({"proxy_url": "http://localhost:8090"}))
    o.register_adapter("antigravity", AntigravityAdapter({}))
    o.register_adapter("core", CoreAdapter({"core_url": "http://localhost:8000"}))
    
    await o.initialize_all()
    yield o
    await asyncio.gather(*[a.shutdown() for a in o.adapters.values()])

@pytest.mark.asyncio
async def test_health_check(orchestrator):
    health = await orchestrator.global_health()
    assert "mcp_proxy" in health
    assert "antigravity" in health
    assert "core" in health
    # Antigravity should return 'ok' immediately since it has no external http dependency yet
    assert health["antigravity"]["status"] == "ok"

@pytest.mark.asyncio
async def test_routing(orchestrator):
    # Test routing to antigravity mapping (no http fetch involved, safe to test)
    result = await orchestrator.route_request("antigravity", {
        "action": "test_enrichment"
    })
    assert result.get("_enriched_by_antigravity") is True
