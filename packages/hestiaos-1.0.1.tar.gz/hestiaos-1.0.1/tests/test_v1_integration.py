#!/usr/bin/env python3
"""
Test script to verify V1 Learned Importance Model integration with MemoryCoordinator
"""
import asyncio
import sys
import os
from typing import Dict, Any

# Add the project root to the Python path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

async def test_v1_analyzer_loading():
    """Test that V1 analyzer can be loaded and initialized"""
    print("=== Test 1: V1 Analyzer Loading ===")
    
    try:
        from core.memory.importance.v1.analyzer import V1DualModeImportanceAnalyzer
        print("✓ V1DualModeImportanceAnalyzer import successful")
        
        # Try to load the trained model
        model_path = "v1_importance_model.pkl"
        if os.path.exists(model_path):
            print(f"✓ Model file found at {model_path}")
            
            analyzer = V1DualModeImportanceAnalyzer(model_path=model_path)
            print("✓ V1DualModeImportanceAnalyzer initialized successfully")
            
            # Test basic prediction
            test_text = "This is an important memory that should be stored."
            test_metadata = {"keywords": ["important", "memory"], "session_importance": 0.8}
            
            result = await analyzer.analyze_importance(test_text, test_metadata)
            print(f"✓ Analyzer returned result")
            
            if isinstance(result, dict):
                importance_score = result.get("importance_score", 0.0)
                heuristic_score = result.get("heuristic_score", 0.0)
                learned_score = result.get("learned_score")
                model_confidence = result.get("model_confidence", 0.0)
                
                print(f"  - Importance score: {importance_score:.3f}")
                print(f"  - Heuristic score: {heuristic_score:.3f}")
                print(f"  - Learned score: {learned_score if learned_score is not None else 'N/A'}")
                print(f"  - Model confidence: {model_confidence:.3f}")
                print(f"  - Used model: {result.get('used_model', 'unknown')}")
            else:
                print(f"  - Importance score: {result:.3f}")
                
            return True
        else:
            print(f"✗ Model file not found at {model_path}")
            return False
            
    except ImportError as e:
        print(f"✗ Import error: {e}")
        return False
    except Exception as e:
        print(f"✗ Error initializing analyzer: {e}")
        return False

async def test_memory_coordinator_integration():
    """Test MemoryCoordinator with V1 analyzer integration"""
    print("\n=== Test 2: MemoryCoordinator Integration ===")
    
    try:
        from core.memory_coordinator import MemoryCoordinator
        print("✓ MemoryCoordinator import successful")
        
        # Create MemoryCoordinator instance
        coordinator = MemoryCoordinator()
        print("✓ MemoryCoordinator instance created")
        
        # Check if V1 analyzer was initialized
        if coordinator.v1_analyzer:
            print("✓ V1 analyzer successfully initialized in MemoryCoordinator")
            
            # Test importance analysis
            test_cases = [
                {
                    "text": "Merke dir diese wichtige Information für später.",
                    "metadata": {"keywords": ["wichtig", "information"], "session_importance": 0.9},
                    "description": "Explicit store command with important keywords"
                },
                {
                    "text": "Das ist nur Smalltalk, nicht wichtig.",
                    "metadata": {"keywords": [], "session_importance": 0.2},
                    "description": "Low importance small talk"
                },
                {
                    "text": "Implementiere das PostgreSQL persistence system mit SQLAlchemy ORM.",
                    "metadata": {"keywords": ["postgresql", "sqlalchemy", "orm", "implementation"], "session_importance": 0.95},
                    "description": "Technical implementation with many keywords"
                },
                {
                    "text": "Hallo, wie geht es dir heute?",
                    "metadata": {"keywords": [], "session_importance": 0.1},
                    "description": "Casual greeting (should be filtered)"
                }
            ]
            
            for i, test_case in enumerate(test_cases, 1):
                print(f"\n  Test case {i}: {test_case['description']}")
                importance = await coordinator.analyze_importance(
                    test_case["text"], 
                    test_case["metadata"]
                )
                print(f"    Importance score: {importance:.3f}")
                
                # Check which memory layer this would go to
                if importance < coordinator.importance_thresholds["sqlite_only"]:
                    layer = "Filtered out (artificial forgetting)"
                elif importance < coordinator.importance_thresholds["mem0_temp"]:
                    layer = "SQLite only (short-term)"
                elif importance < coordinator.importance_thresholds["mem0_perm"]:
                    layer = "mem0 temporary (muscle memory)"
                elif importance < coordinator.importance_thresholds["obsidian"]:
                    layer = "mem0 permanent (muscle memory)"
                else:
                    layer = "Obsidian (long-term knowledge vault)"
                    
                print(f"    Memory layer: {layer}")
                
            return True
        else:
            print("✗ V1 analyzer not initialized in MemoryCoordinator")
            print("  Falling back to heuristic analysis...")
            
            # Test heuristic fallback
            test_text = "Test with heuristic fallback"
            test_metadata = {"keywords": ["test"]}
            importance = await coordinator.analyze_importance(test_text, test_metadata)
            print(f"  Heuristic importance: {importance:.3f}")
            return False
            
    except Exception as e:
        print(f"✗ Error testing MemoryCoordinator: {e}")
        import traceback
        traceback.print_exc()
        return False

async def test_artificial_forgetting_logic():
    """Test the artificial forgetting logic with importance thresholds"""
    print("\n=== Test 3: Artificial Forgetting Logic ===")
    
    try:
        from core.memory_coordinator import MemoryCoordinator
        coordinator = MemoryCoordinator()
        
        # Test different importance levels
        test_levels = [
            (0.1, "Very low importance - should be filtered"),
            (0.25, "Low importance - borderline filtering"),
            (0.35, "Medium-low - SQLite only"),
            (0.6, "Medium - mem0 temporary"),
            (0.8, "High - mem0 permanent"),
            (0.95, "Very high - Obsidian vault")
        ]
        
        for importance, description in test_levels:
            print(f"\n  {description}")
            print(f"    Importance: {importance:.3f}")
            
            # Determine routing based on thresholds
            if importance < coordinator.importance_thresholds["sqlite_only"]:
                action = "FILTERED OUT (artificial forgetting)"
                explanation = "Content deemed irrelevant - not stored in any layer"
            elif importance < coordinator.importance_thresholds["mem0_temp"]:
                action = "SQLite only"
                explanation = "Short-term storage for potentially useful content"
            elif importance < coordinator.importance_thresholds["mem0_perm"]:
                action = "mem0 temporary"
                explanation = "Muscle memory for active learning"
            elif importance < coordinator.importance_thresholds["obsidian"]:
                action = "mem0 permanent"
                explanation = "Important muscle memory patterns"
            else:
                action = "Obsidian vault"
                explanation = "Long-term knowledge storage"
                
            print(f"    Action: {action}")
            print(f"    Explanation: {explanation}")
            
        return True
        
    except Exception as e:
        print(f"✗ Error testing artificial forgetting: {e}")
        return False

async def main():
    """Run all integration tests"""
    print("V1 Learned Importance Model Integration Test")
    print("=" * 50)
    
    results = []
    
    # Run tests
    results.append(await test_v1_analyzer_loading())
    results.append(await test_memory_coordinator_integration())
    results.append(await test_artificial_forgetting_logic())
    
    # Summary
    print("\n" + "=" * 50)
    print("TEST SUMMARY")
    print("=" * 50)
    
    total_tests = len(results)
    passed_tests = sum(results)
    
    print(f"Total tests: {total_tests}")
    print(f"Passed: {passed_tests}")
    print(f"Failed: {total_tests - passed_tests}")
    
    if passed_tests == total_tests:
        print("\n✅ All tests passed! V1 integration successful.")
        return 0
    else:
        print("\n❌ Some tests failed. Check logs for details.")
        return 1

if __name__ == "__main__":
    exit_code = asyncio.run(main())
    sys.exit(exit_code)