#!/usr/bin/env python3
"""
Test AST Fix Engine

This test validates the AST-based fix engine with real Bandit findings.
"""

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from core.capabilities.ast_fix_engine import ASTFixEngine, CodeFix, FixConfidence, FixType


def test_eval_fix():
    """Test eval() → safe_eval() transformation"""
    print("Testing eval() fix...")
    
    test_code = '''def test_function():
    result = eval("2 + 2")
    return result

x = eval(user_input)
'''
    
    bandit_findings = [
        {"test_id": "B307", "line_number": 2, "issue_text": "Use of eval detected."},
        {"test_id": "B307", "line_number": 5, "issue_text": "Use of eval detected."}
    ]
    
    fix_engine = ASTFixEngine()
    fixes = fix_engine.generate_fixes("test.py", test_code, bandit_findings)
    
    print(f"  Generated {len(fixes)} fixes")
    assert len(fixes) == 2, f"Expected 2 fixes, got {len(fixes)}"
    
    # Check first fix (literal eval)
    fix1 = fixes[0]
    assert fix1.fix_type == FixType.SECURITY
    assert fix1.confidence == FixConfidence.HIGH
    assert "eval" in fix1.old_code
    assert "safe_eval" in fix1.new_code or "ast.literal_eval" in fix1.new_code
    
    # Apply fixes
    fixed_code, results = fix_engine.apply_fixes(test_code, fixes)
    
    print(f"  Applied fixes: {len([r for r in results if r['status'] == 'applied'])} successful")
    assert "eval" not in fixed_code or "safe_eval" in fixed_code or "ast.literal_eval" in fixed_code
    
    print("  ✓ Eval fix test passed")
    return True


def test_subprocess_shell_fix():
    """Test subprocess shell=True → shell=False transformation"""
    print("Testing subprocess shell fix...")
    
    test_code = '''import subprocess

def run_command():
    subprocess.run("ls -la", shell=True)
    subprocess.call(["echo", "test"], shell=1)
    subprocess.Popen("cat file.txt", shell=True)
'''
    
    bandit_findings = [
        {"test_id": "B602", "line_number": 4, "issue_text": "subprocess call with shell=True identified."},
        {"test_id": "B602", "line_number": 5, "issue_text": "subprocess call with shell=True identified."},
        {"test_id": "B602", "line_number": 6, "issue_text": "subprocess call with shell=True identified."}
    ]
    
    fix_engine = ASTFixEngine()
    fixes = fix_engine.generate_fixes("test.py", test_code, bandit_findings)
    
    print(f"  Generated {len(fixes)} fixes")
    assert len(fixes) == 3, f"Expected 3 fixes, got {len(fixes)}"
    
    # Check fixes
    for fix in fixes:
        assert fix.fix_type == FixType.SECURITY
        assert fix.confidence == FixConfidence.MEDIUM
        assert "shell=True" in fix.old_code or "shell=1" in fix.old_code
        assert "shell=False" in fix.new_code or "shell=0" in fix.new_code
    
    # Apply fixes
    fixed_code, results = fix_engine.apply_fixes(test_code, fixes)
    
    print(f"  Applied fixes: {len([r for r in results if r['status'] == 'applied'])} successful")
    assert "shell=True" not in fixed_code
    assert "shell=1" not in fixed_code
    
    print("  ✓ Subprocess shell fix test passed")
    return True


def test_hardcoded_password_fix():
    """Test hardcoded password → environment variable transformation"""
    print("Testing hardcoded password fix...")
    
    test_code = '''password = "secret123"
api_key = "abc123def456"
token = "xyz789"
'''
    
    bandit_findings = [
        {"test_id": "B105", "line_number": 1, "issue_text": "Hardcoded password string."},
        {"test_id": "B105", "line_number": 2, "issue_text": "Hardcoded API key."},
        {"test_id": "B105", "line_number": 3, "issue_text": "Hardcoded token."}
    ]
    
    fix_engine = ASTFixEngine()
    fixes = fix_engine.generate_fixes("test.py", test_code, bandit_findings)
    
    print(f"  Generated {len(fixes)} fixes")
    assert len(fixes) == 3, f"Expected 3 fixes, got {len(fixes)}"
    
    # Check fixes
    for fix in fixes:
        assert fix.fix_type == FixType.SECURITY
        assert fix.confidence == FixConfidence.MEDIUM
        assert "os.environ.get" in fix.new_code
    
    # Apply fixes
    fixed_code, results = fix_engine.apply_fixes(test_code, fixes)
    
    print(f"  Applied fixes: {len([r for r in results if r['status'] == 'applied'])} successful")
    assert "os.environ.get" in fixed_code
    
    print("  ✓ Hardcoded password fix test passed")
    return True


def test_unsafe_import_fix():
    """Test unsafe import → comment transformation"""
    print("Testing unsafe import fix...")
    
    test_code = '''import pickle
import marshal
import json
'''
    
    bandit_findings = [
        {"test_id": "B403", "line_number": 1, "issue_text": "Consider possible security implications associated with pickle module."},
        {"test_id": "B403", "line_number": 2, "issue_text": "Consider possible security implications associated with marshal module."}
    ]
    
    fix_engine = ASTFixEngine()
    fixes = fix_engine.generate_fixes("test.py", test_code, bandit_findings)
    
    print(f"  Generated {len(fixes)} fixes")
    assert len(fixes) == 2, f"Expected 2 fixes, got {len(fixes)}"
    
    # Check fixes
    for fix in fixes:
        assert fix.fix_type == FixType.SECURITY
        assert fix.confidence == FixConfidence.MEDIUM
        assert "#" in fix.new_code  # Should be commented out
    
    # Apply fixes
    fixed_code, results = fix_engine.apply_fixes(test_code, fixes)
    
    print(f"  Applied fixes: {len([r for r in results if r['status'] == 'applied'])} successful")
    assert "# import pickle" in fixed_code or "# Consider using json" in fixed_code
    
    print("  ✓ Unsafe import fix test passed")
    return True


def test_integration_with_real_code():
    """Test integration with real HestiaOS code"""
    print("Testing integration with real code...")
    
    # Read a real Python file from the codebase
    real_file_path = os.path.join(os.path.dirname(__file__), "core", "hsp", "middleware.py")
    
    if os.path.exists(real_file_path):
        with open(real_file_path, 'r') as f:
            real_code = f.read()
        
        # Simulate Bandit findings (in reality, these would come from actual Bandit scan)
        simulated_findings = [
            # These are simulated - in reality would come from actual Bandit scan
            {"test_id": "B105", "line_number": 50, "issue_text": "Simulated hardcoded password finding"},
            {"test_id": "B307", "line_number": 100, "issue_text": "Simulated eval finding"},
        ]
        
        fix_engine = ASTFixEngine()
        fixes = fix_engine.generate_fixes(real_file_path, real_code, simulated_findings)
        
        print(f"  Generated {len(fixes)} fixes for real code")
        
        if fixes:
            # Apply fixes
            fixed_code, results = fix_engine.apply_fixes(real_code, fixes)
            
            applied_count = len([r for r in results if r['status'] == 'applied'])
            print(f"  Applied {applied_count} fixes successfully")
            
            # Verify the fixes didn't break the code structure
            assert len(fixed_code.split('\n')) == len(real_code.split('\n')) or applied_count == 0
            
            print("  ✓ Real code integration test passed")
        else:
            print("  ⚠ No fixes generated (expected for clean code)")
    else:
        print("  ⚠ Real file not found, skipping integration test")
    
    return True


def run_all_tests():
    """Run all tests"""
    print("=" * 60)
    print("AST Fix Engine Test Suite")
    print("=" * 60)
    
    tests = [
        test_eval_fix,
        test_subprocess_shell_fix,
        test_hardcoded_password_fix,
        test_unsafe_import_fix,
        test_integration_with_real_code
    ]
    
    passed = 0
    failed = 0
    
    for test in tests:
        try:
            if test():
                passed += 1
        except Exception as e:
            print(f"  ✗ Test failed: {e}")
            failed += 1
    
    print("\n" + "=" * 60)
    print(f"Test Results: {passed} passed, {failed} failed")
    print("=" * 60)
    
    if failed == 0:
        print("✓ All tests passed!")
        return True
    else:
        print(f"✗ {failed} test(s) failed")
        return False


if __name__ == "__main__":
    success = run_all_tests()
    sys.exit(0 if success else 1)