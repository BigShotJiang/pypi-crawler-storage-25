import sys
import os
from pathlib import Path

# Add project root to path
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from hands.filesystem import FileSystemTools

def test_path_traversal():
    print("Testing Path Traversal Protection...")
    
    # 1. Test allowed path
    try:
        FileSystemTools.read_file("data/test_allowed.txt") 
        # It's okay if file doesn't exist, we just want to ensure it doesn't raise ValueError for path
    except ValueError as e:
         print(f"FAILED: Allowed path rejected: {e}")
    except Exception:
         pass # Expected if file missing
         
    # 2. Test forbidden path (relative)
    try:
        FileSystemTools.read_file("../../etc/passwd")
        print("FAILED: ../../etc/passwd was NOT blocked!")
    except ValueError as e:
        print(f"PASSED: ../../etc/passwd blocked: {e}")
    except Exception as e:
        if "Access denied" in str(e):
             print(f"PASSED: ../../etc/passwd blocked: {e}")
        else:
             print(f"FAILED: Unexpected error for ../../etc/passwd: {type(e)} {e}")

    # 3. Test forbidden path (absolute)
    try:
        FileSystemTools.read_file("/etc/shadow")
        print("FAILED: /etc/shadow was NOT blocked!")
    except ValueError as e:
         print(f"PASSED: /etc/shadow blocked: {e}")
    except Exception as e:
         # The tool returns {"error": ...} usually, but safe_path raises ValueError. 
         # Wait, read_file catches exceptions and returns {"error": str(e)}
         # So we need to check the return value of read_file, OR test safe_path directly.
         pass
         
    # Let's test safe_path directly for stricter assertion
    try:
        FileSystemTools.safe_path("../../etc/passwd")
        print("FAILED (Direct): safe_path allowed ../../etc/passwd")
    except ValueError as e:
        print(f"PASSED (Direct): safe_path blocked ../../etc/passwd: {e}")

    # 4. Test API return value behavior
    result = FileSystemTools.read_file("/etc/passwd")
    if "error" in result and "Access denied" in result["error"]:
        print(f"PASSED (API): read_file returned error for /etc/passwd: {result['error']}")
    else:
        print(f"FAILED (API): read_file result unexpected: {result}")

if __name__ == "__main__":
    test_path_traversal()
