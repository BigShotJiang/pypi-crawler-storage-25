"""
INV-G3-CIT: Causal Integrity Test
Verifiziert die semantische Kopplung und die Shadow-Mode-Invariante.
"""

import pytest
from core.governance.causal_kernel import causal_kernel
from core.governance.dsgk_decision import build_decision
from core.bootstrap.control_plane import CanonicalState, SystemCondition, SystemSignals
from core.bootstrap.models import BootState
from core.bootstrap.arbitrator import SystemArbitrator, ArbitrationResult
from core.processing.network_error_classifier import CircuitState

class MockCommand:
    def __init__(self, command_id: str, command_type: str):
        self.command_id = command_id
        self.command_type = command_type

def test_causal_pipeline_integrity(caplog):
    """Prüft ob alle 4 Stages semantisch durchlaufen werden und G2 nicht verändern."""
    import logging
    caplog.set_level(logging.DEBUG)
    
    arb = SystemArbitrator()
    cmd = MockCommand("cmd_test_001", "code_exec")
    decision = build_decision(violations=[], risk_score=0.1, policy="core.code_exec.v1")
    signals = SystemSignals(boot_state=BootState.READY, db_ready=True, migrations_ok=True)
    state = CanonicalState(condition=SystemCondition.GREEN, priority_vector=[0,0,0,0,0], signals=signals)

    # 1. Analyse Trigger
    report = causal_kernel.analyze(cmd, {})
    bias = causal_kernel.project_to_governance(report)
    
    # 2. Arbitrate (Shadow Mode)
    outcome = arb.arbitrate(
        dsgk=decision,
        control_state=state,
        circuit_state=CircuitState.CLOSED,
        drift_vector=None,
        causal_report=report,
        causal_bias=bias
    )

    # Verifikation der Stage-Ausführung via Logs
    log_text = caplog.text
    assert "[G3-STAGE-0] Intake: Command cmd_test_001" in log_text
    assert "[G3-STAGE-1] Expansion: Type 'code_exec'" in log_text
    assert "[G3-STAGE-2] Simulation: 2 nodes" in log_text  # code_exec + memory
    assert "[G3-STAGE-3] Projection: Risk=" in log_text

    # Verifikation der semantischen Reichhaltigkeit
    assert report.risk_projection > 0.0
    assert report.instability_prediction.system_drift > 0.0
    assert bias.risk_offset > 0.0

    # Verifikation der Shadow-Mode Invariante (Non-Interference)
    # Wenn wir G3 weglassen, muss das Ergebnis IDENTISCH sein
    outcome_vanilla = arb.arbitrate(
        dsgk=decision,
        control_state=state,
        circuit_state=CircuitState.CLOSED,
        drift_vector=None
    )
    
    assert outcome.result == outcome_vanilla.result
    assert outcome.authority == outcome_vanilla.authority
    
    # Verifikation der Transport-Integrität
    assert outcome.causal_report == report
    assert outcome_vanilla.causal_report is None

def test_causal_determinism_and_drift_projection():
    """Prüft ob unterschiedliche Commands unterschiedliche Drift-Projektionen erzeugen."""
    cmd_read = MockCommand("c1", "read")
    cmd_write = MockCommand("c2", "write")
    
    report_read = causal_kernel.analyze(cmd_read, {})
    report_write = causal_kernel.analyze(cmd_write, {})
    
    # Write sollte höheres Risiko/Drift-Bias haben als Read
    assert report_write.risk_projection > report_read.risk_projection
    assert report_write.instability_prediction.system_drift > report_read.instability_prediction.system_drift
