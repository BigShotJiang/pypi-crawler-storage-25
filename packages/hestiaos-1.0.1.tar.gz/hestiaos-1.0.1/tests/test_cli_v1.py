import subprocess
import json
import os
import time
from pathlib import Path

# Paths
CLI_EXEC = ["python3", "-m", "core.cli.main"]
TICKETS_FILE = "logs/tickets.json"

def run_cli(args):
    """Run CLI command and return parsed JSON result"""
    cmd = CLI_EXEC + args
    res = subprocess.run(cmd, capture_output=True, text=True, env={**os.environ, "PYTHONPATH": "."})
    if res.returncode != 0:
        print(f"CLI Error Output: {res.stderr}")
    return res.stdout.strip(), res.returncode

def test_json_output_standard():
    """Verify that monitor command returns valid JSON V1 schema"""
    print("🧪 Testing JSON Output Standard (&/ monitor)...")
    stdout, rc = run_cli(["monitor"])
    
    try:
        data = json.loads(stdout)
        assert data["status"] in ["success", "error"]
        if data["status"] == "success":
            assert "cpu" in data["data"]
            assert "memory" in data["data"]
            assert "gpu" in data["data"] or data["data"]["gpu"] is None
        print("✅ Pass: monitor returns valid JSON schema.")
    except Exception as e:
        print(f"❌ Fail: {e}")
        print(f"Raw output: {stdout}")

def test_help_output():
    """Verify help is readable Markdown"""
    print("🧪 Testing Help Output (&/ help)...")
    stdout, rc = run_cli(["help"])
    assert "# 🖥️ HestiaOS CLI" in stdout
    print("✅ Pass: help returns readable Markdown.")

def test_ticket_lifecycle():
    """Verify Ticket Lifecycle: Creation -> List -> Show -> Fix -> Escalate"""
    print("🧪 Testing Ticket Lifecycle...")
    
    # 1. Trigger doctor (ensure at least one issue exists or simulate one)
    # We'll just check if tickets can be listed first
    stdout, rc = run_cli(["tickets", "list"])
    initial_tickets = json.loads(stdout)["data"]["tickets"]
    initial_count = len(initial_tickets)
    
    # Run doctor --fix to force ticket creation on failure
    print("   > Running doctor --fix...")
    run_cli(["doctor", "--fix"])
    
    # 2. Check if new ticket appeared
    stdout, rc = run_cli(["tickets", "list"])
    new_tickets = json.loads(stdout)["data"]["tickets"]
    assert len(new_tickets) >= initial_count
    print(f"✅ Pass: Ticket count is now {len(new_tickets)}.")
    
    if len(new_tickets) > 0:
        latest_id = new_tickets[-1]["id"]
        
        # 3. Show ticket
        print(f"   > Showing ticket {latest_id}...")
        stdout, rc = run_cli(["tickets", "show", latest_id])
        ticket_data = json.loads(stdout)["data"]
        assert ticket_data["id"] == latest_id
        
        # 4. Fix ticket (Local Agent Escalation)
        print(f"   > Fixing ticket {latest_id}...")
        stdout, rc = run_cli(["tickets", "fix", latest_id])
        fix_res = json.loads(stdout)["data"]
        assert fix_res["status"] == "IN_PROGRESS"
        
        # 5. Escalate ticket (External Report)
        print(f"   > Escalating ticket {latest_id}...")
        stdout, rc = run_cli(["tickets", "escalate", latest_id])
        esc_res = json.loads(stdout)["data"]
        assert "report_path" in esc_res
        
    print("✅ Pass: Full ticket lifecycle transition verified.")

def test_invalid_command():
    """Verify error handling for invalid commands"""
    print("🧪 Testing Invalid Command Handling...")
    stdout, rc = run_cli(["nospace_invalid_cmd"])
    data = json.loads(stdout)
    assert data["status"] == "error"
    assert data["error"]["code"] == "INVALID_COMMAND"
    print("✅ Pass: Invalid command returns structured error.")

if __name__ == "__main__":
    print("🚀 Starting HestiaOS CLI V1 Validation Suite\n")
    test_json_output_standard()
    test_help_output()
    test_ticket_lifecycle()
    test_invalid_command()
    print("\n🏁 Validation Suite Complete.")
