import asyncio
import httpx
from core.config import config_manager

async def test_v4():
    nc_config = config_manager.get("nextcloud", {})
    url = nc_config.get("url", "").rstrip("/")
    user = nc_config.get("user", "")
    password = nc_config.get("password", "")
    token = "6mvoe63h"
    
    headers = {"OCS-APIRequest": "true", "Accept": "application/json"}
    auth = (user, password)
    
    endpoints = [
        f"{url}/ocs/v2.php/apps/spreed/api/v4/room?format=json",
        f"{url}/ocs/v2.php/apps/spreed/api/v4/chat/{token}?format=json"
    ]
    
    async with httpx.AsyncClient(timeout=10.0) as client:
        for ep in endpoints:
            print(f"Testing {ep}...")
            resp = await client.get(ep, headers=headers, auth=auth)
            print(f"Status: {resp.status_code}")
            print(f"Body: {resp.text[:500]}")

if __name__ == "__main__":
    asyncio.run(test_v4())
