"""
Tests for the Invariant Canon Layer (v3).

Covers:
  - IR Model: frozen dataclasses, construction, immutability
  - Predicate Evaluator: AND/OR/NOT/EQ/IN/CALL
  - Function Registry: ALLOWED_FUNCTIONS, register, call, forbidden
  - Conflict Resolution: priority ordering, trace generation
  - Consistency Layer: all 8 preflight checks
  - Compiler: YAML → CanonIR round-trip
  - Manager: singleton, file loading
  - CI Drift Consumer: config generation from IR
  - Integration: end-to-end evaluation pipeline
"""

import os
import sys
import json
import tempfile
import pytest
from typing import Dict, Any, List

# Ensure core is importable
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from core.invariants.ir import (
    CanonIR, InvariantNode, BoundaryNode, PolicyNode, TestNode, PredicateAST,
)
from core.invariants.predicates import PredicateEvaluator
from core.invariants.function_registry import (
    ALLOWED_FUNCTIONS, register_function, call_function, _implementation_registry,
)
from core.invariants.conflict import resolve_conflicts, PRIORITY
from core.invariants.evaluation import InvariantEvaluator, EvaluationResult
from core.invariants.consistency import (
    ConsistencyValidator, ConsistencyIssue, ConsistencyReport, validate_ir,
)
from core.invariants.compiler import CanonCompiler
from core.invariants.manager import InvariantManager, get_invariant_manager
from core.invariants.consumers.ci_drift import get_drift_config


# =========================================================================
# 1. IR Model Tests
# =========================================================================

class TestIRModel:
    """Verify that all IR dataclasses are frozen, typed, and constructable."""

    def test_predicate_ast_creation(self):
        ast = PredicateAST(op="EQ", key="layer", value="memory")
        assert ast.op == "EQ"
        assert ast.key == "layer"
        assert ast.value == "memory"
        assert ast.args == []

    def test_predicate_ast_nested(self):
        ast = PredicateAST(
            op="AND",
            args=[
                PredicateAST(op="EQ", key="layer", value="memory"),
                PredicateAST(op="NOT", args=[PredicateAST(op="EQ", key="filepath", value="coordinator.py")]),
            ]
        )
        assert ast.op == "AND"
        assert len(ast.args) == 2
        assert ast.args[0].op == "EQ"
        assert ast.args[1].op == "NOT"

    def test_predicate_ast_frozen(self):
        ast = PredicateAST(op="EQ", key="x", value=1)
        with pytest.raises((AttributeError, Exception)):
            ast.op = "NE"  # Should fail because frozen=True

    def test_invariant_node_creation(self):
        node = InvariantNode(
            id="inv.test.1",
            name="Test Invariant",
            description="A test invariant",
            severity="FATAL",
            scope=["memory"],
            condition=PredicateAST(op="EQ", key="layer", value="memory"),
            action="DENY",
            source="canon.yaml",
        )
        assert node.id == "inv.test.1"
        assert node.action == "DENY"
        assert node.severity == "FATAL"

    def test_boundary_node_creation(self):
        node = BoundaryNode(
            id="boundary.memory",
            name="memory",
            path="core/memory/",
            allowed_patterns=["cosine_similarity"],
            forbidden_patterns=["subprocess"],
            note="Memory layer boundary",
        )
        assert node.id == "boundary.memory"
        assert "cosine_similarity" in node.allowed_patterns

    def test_policy_node_creation(self):
        node = PolicyNode(
            id="pol.security.test",
            name="Test Policy",
            type="security",
            severity="fatal",
            description="A test policy",
            condition=PredicateAST(op="EQ", key="action", value="write"),
        )
        assert node.id == "pol.security.test"
        assert node.type == "security"

    def test_test_node_creation(self):
        node = TestNode(
            id="test.memory.coordinator_no_scoring",
            suite="memory",
            name="coordinator_no_scoring",
            description="Test that coordinator has no scoring",
        )
        assert node.id == "test.memory.coordinator_no_scoring"
        assert node.suite == "memory"

    def test_canon_ir_creation(self):
        ir = CanonIR(
            version="3.0",
            invariants=[
                InvariantNode(id="inv.1", name="I1", description="", severity="FATAL",
                              scope=["global"], condition=PredicateAST(op="EQ", key="x", value=1),
                              action="DENY", source="test"),
            ],
            boundaries=[
                BoundaryNode(id="b.1", name="test", path="test/",
                             allowed_patterns=[], forbidden_patterns=[], note=""),
            ],
            metadata={"key": "value"},
        )
        assert ir.version == "3.0"
        assert len(ir.invariants) == 1
        assert len(ir.boundaries) == 1
        assert ir.metadata["key"] == "value"

    def test_canon_ir_frozen(self):
        ir = CanonIR(version="3.0")
        with pytest.raises((AttributeError, Exception)):
            ir.version = "4.0"


# =========================================================================
# 2. Predicate Evaluator Tests
# =========================================================================

class TestPredicateEvaluator:
    """Verify that the PredicateEvaluator correctly evaluates all AST ops."""

    def setup_method(self):
        self.evaluator = PredicateEvaluator()

    def test_eq_match(self):
        ast = PredicateAST(op="EQ", key="layer", value="memory")
        assert self.evaluator.evaluate(ast, {"layer": "memory"}) is True

    def test_eq_no_match(self):
        ast = PredicateAST(op="EQ", key="layer", value="memory")
        assert self.evaluator.evaluate(ast, {"layer": "cli"}) is False

    def test_in_list(self):
        ast = PredicateAST(op="IN", key="role", value=["admin", "user"])
        assert self.evaluator.evaluate(ast, {"role": "admin"}) is True
        assert self.evaluator.evaluate(ast, {"role": "guest"}) is False

    def test_and_all_true(self):
        ast = PredicateAST(
            op="AND",
            args=[
                PredicateAST(op="EQ", key="a", value=1),
                PredicateAST(op="EQ", key="b", value=2),
            ]
        )
        assert self.evaluator.evaluate(ast, {"a": 1, "b": 2}) is True

    def test_and_one_false(self):
        ast = PredicateAST(
            op="AND",
            args=[
                PredicateAST(op="EQ", key="a", value=1),
                PredicateAST(op="EQ", key="b", value=99),
            ]
        )
        assert self.evaluator.evaluate(ast, {"a": 1, "b": 2}) is False

    def test_or_all_false(self):
        ast = PredicateAST(
            op="OR",
            args=[
                PredicateAST(op="EQ", key="a", value=1),
                PredicateAST(op="EQ", key="b", value=2),
            ]
        )
        assert self.evaluator.evaluate(ast, {"a": 99, "b": 98}) is False

    def test_or_one_true(self):
        ast = PredicateAST(
            op="OR",
            args=[
                PredicateAST(op="EQ", key="a", value=1),
                PredicateAST(op="EQ", key="b", value=2),
            ]
        )
        assert self.evaluator.evaluate(ast, {"a": 1, "b": 98}) is True

    def test_not_true(self):
        ast = PredicateAST(op="NOT", args=[PredicateAST(op="EQ", key="x", value=1)])
        assert self.evaluator.evaluate(ast, {"x": 2}) is True

    def test_not_false(self):
        ast = PredicateAST(op="NOT", args=[PredicateAST(op="EQ", key="x", value=1)])
        assert self.evaluator.evaluate(ast, {"x": 1}) is False

    def test_complex_nested(self):
        """Test a realistic nested predicate: AND(NOT(EQ), OR(EQ, EQ))"""
        ast = PredicateAST(
            op="AND",
            args=[
                PredicateAST(op="NOT", args=[PredicateAST(op="EQ", key="role", value="guest")]),
                PredicateAST(
                    op="OR",
                    args=[
                        PredicateAST(op="EQ", key="layer", value="memory"),
                        PredicateAST(op="EQ", key="layer", value="policy"),
                    ]
                ),
            ]
        )
        assert self.evaluator.evaluate(ast, {"role": "admin", "layer": "memory"}) is True
        assert self.evaluator.evaluate(ast, {"role": "guest", "layer": "memory"}) is False
        assert self.evaluator.evaluate(ast, {"role": "admin", "layer": "cli"}) is False

    def test_unknown_op_raises(self):
        ast = PredicateAST(op="UNKNOWN")
        with pytest.raises(ValueError, match="Unknown operation"):
            self.evaluator.evaluate(ast, {})


# =========================================================================
# 3. Function Registry Tests
# =========================================================================

class TestFunctionRegistry:
    """Verify that the Function Registry enforces bounded evaluation."""

    def setup_method(self):
        # Clear registry before each test
        _implementation_registry.clear()

    def test_allowed_functions_contains_expected(self):
        assert "memory.cosine_similarity" in ALLOWED_FUNCTIONS
        assert "ast.scan_file" in ALLOWED_FUNCTIONS
        assert "system.permission_check" in ALLOWED_FUNCTIONS

    def test_register_allowed_function(self):
        def dummy():
            return True
        register_function("memory.cosine_similarity", dummy)
        assert "memory.cosine_similarity" in _implementation_registry

    def test_register_forbidden_function_raises(self):
        def dummy():
            return True
        with pytest.raises(ValueError, match="not in the allowed canon"):
            register_function("unknown.function", dummy)

    def test_call_registered_function(self):
        def dummy(ctx=None, **kw):
            return 42
        register_function("system.permission_check", dummy)
        result = call_function("system.permission_check", context={})
        assert result == 42

    def test_call_unregistered_function_raises(self):
        with pytest.raises(PermissionError, match="Forbidden function call"):
            call_function("unknown.function")

    def test_call_missing_implementation_raises(self):
        # Function is in ALLOWED_FUNCTIONS but not registered
        with pytest.raises(RuntimeError, match="Function implementation missing"):
            call_function("module.importable")


# =========================================================================
# 4. Conflict Resolution Tests
# =========================================================================

class TestConflictResolution:
    """Verify that conflict resolution follows Partial Order Semantics."""

    def test_priority_ordering(self):
        """BoundaryNode should sort before PolicyNode before InvariantNode."""
        boundary = BoundaryNode(id="b.1", name="test", path="test/",
                                allowed_patterns=[], forbidden_patterns=[], note="")
        policy = PolicyNode(id="p.1", name="test", type="security", severity="fatal",
                            description="", condition=PredicateAST(op="EQ", key="x", value=1))
        invariant = InvariantNode(id="i.1", name="test", description="", severity="FATAL",
                                  scope=["global"], condition=PredicateAST(op="EQ", key="x", value=1),
                                  action="DENY", source="test")

        sorted_nodes, trace = resolve_conflicts([invariant, policy, boundary])
        assert sorted_nodes[0].id == "b.1"  # Boundary first (priority 0)
        assert sorted_nodes[1].id == "p.1"  # Policy second (priority 1)
        assert sorted_nodes[2].id == "i.1"  # Invariant last (priority 2)

    def test_conflict_trace_generated(self):
        """When multiple types are present, a trace should be generated."""
        boundary = BoundaryNode(id="b.1", name="test", path="test/",
                                allowed_patterns=[], forbidden_patterns=[], note="")
        policy = PolicyNode(id="p.1", name="test", type="security", severity="fatal",
                            description="", condition=PredicateAST(op="EQ", key="x", value=1))

        sorted_nodes, trace = resolve_conflicts([policy, boundary])
        assert len(trace) > 0
        assert "Conflict resolution active" in trace[0]

    def test_single_type_no_conflict_trace(self):
        """When only one type is present, no conflict trace needed."""
        nodes = [
            InvariantNode(id="i.1", name="test", description="", severity="FATAL",
                          scope=["global"], condition=PredicateAST(op="EQ", key="x", value=1),
                          action="DENY", source="test"),
        ]
        sorted_nodes, trace = resolve_conflicts(nodes)
        assert len(trace) == 0  # No conflict with single node

    def test_priority_map_completeness(self):
        """All IR node types should have a priority entry."""
        from core.invariants.ir import BoundaryNode, PolicyNode, InvariantNode, TestNode
        assert BoundaryNode in PRIORITY
        assert PolicyNode in PRIORITY
        assert InvariantNode in PRIORITY
        assert TestNode in PRIORITY


# =========================================================================
# 5. Consistency Layer Tests
# =========================================================================

class TestConsistencyLayer:
    """Verify all 8 preflight consistency checks."""

    def test_valid_ir_passes(self):
        """A well-formed IR should pass all checks."""
        ir = CanonIR(
            version="3.0",
            invariants=[
                InvariantNode(id="inv.1", name="I1", description="", severity="FATAL",
                              scope=["global"], condition=PredicateAST(op="EQ", key="x", value=1),
                              action="DENY", source="test"),
            ],
            boundaries=[
                BoundaryNode(id="b.1", name="test", path="test/",
                             allowed_patterns=[], forbidden_patterns=[], note=""),
            ],
        )
        report = validate_ir(ir)
        assert report.valid is True
        assert len(report.issues) == 0

    def test_circular_conflict_detected(self):
        """Two invariants with opposite actions in same scope should be flagged."""
        ir = CanonIR(
            version="3.0",
            invariants=[
                InvariantNode(id="inv.deny", name="Deny All", description="",
                              severity="FATAL", scope=["memory"],
                              condition=PredicateAST(op="EQ", key="x", value=1),
                              action="DENY", source="test"),
                InvariantNode(id="inv.allow", name="Allow All", description="",
                              severity="INFO", scope=["memory"],
                              condition=PredicateAST(op="EQ", key="x", value=1),
                              action="ALLOW", source="test"),
            ],
        )
        report = validate_ir(ir)
        circular = [i for i in report.issues if i.category == "circular_conflict"]
        assert len(circular) >= 1
        assert circular[0].severity == "ERROR"

    def test_function_registry_violation_detected(self):
        """CALL to unregistered function should be flagged as ERROR."""
        ir = CanonIR(
            version="3.0",
            invariants=[
                InvariantNode(id="inv.bad_call", name="Bad", description="",
                              severity="FATAL", scope=["global"],
                              condition=PredicateAST(op="CALL", key="nonexistent.function"),
                              action="DENY", source="test"),
            ],
        )
        report = validate_ir(ir)
        violations = [i for i in report.issues if i.category == "function_registry_violation"]
        assert len(violations) == 1
        assert violations[0].severity == "ERROR"
        assert "nonexistent.function" in violations[0].message

    def test_duplicate_id_detected(self):
        """Duplicate node IDs should be flagged as ERROR."""
        ir = CanonIR(
            version="3.0",
            invariants=[
                InvariantNode(id="inv.dup", name="Dup1", description="",
                              severity="FATAL", scope=["global"],
                              condition=PredicateAST(op="EQ", key="x", value=1),
                              action="DENY", source="test"),
                InvariantNode(id="inv.dup", name="Dup2", description="",
                              severity="FATAL", scope=["global"],
                              condition=PredicateAST(op="EQ", key="x", value=2),
                              action="DENY", source="test"),
            ],
        )
        report = validate_ir(ir)
        dups = [i for i in report.issues if i.category == "duplicate_id"]
        assert len(dups) == 1
        assert dups[0].severity == "ERROR"

    def test_unreachable_scope_detected(self):
        """Invariant with scope that has no matching boundary should be warned."""
        ir = CanonIR(
            version="3.0",
            invariants=[
                InvariantNode(id="inv.ghost", name="Ghost", description="",
                              severity="FATAL", scope=["nonexistent_layer"],
                              condition=PredicateAST(op="EQ", key="x", value=1),
                              action="DENY", source="test"),
            ],
            boundaries=[
                BoundaryNode(id="b.1", name="memory", path="core/memory/",
                             allowed_patterns=[], forbidden_patterns=[], note=""),
            ],
        )
        report = validate_ir(ir)
        unreachable = [i for i in report.issues if i.category == "unreachable_node"]
        assert len(unreachable) == 1
        assert unreachable[0].severity == "WARN"

    def test_predicate_depth_warning(self):
        """Deeply nested predicates should generate a warning."""
        # Build a deeply nested AND chain
        def build_deep(depth: int) -> PredicateAST:
            if depth <= 1:
                return PredicateAST(op="EQ", key="x", value=1)
            return PredicateAST(op="AND", args=[build_deep(depth - 1), PredicateAST(op="EQ", key="y", value=2)])

        ir = CanonIR(
            version="3.0",
            invariants=[
                InvariantNode(id="inv.deep", name="Deep", description="",
                              severity="FATAL", scope=["global"],
                              condition=build_deep(25),  # Exceeds MAX_DEPTH of 20
                              action="DENY", source="test"),
            ],
        )
        report = validate_ir(ir)
        depth_issues = [i for i in report.issues if i.category == "predicate_depth"]
        assert len(depth_issues) == 1
        assert depth_issues[0].severity == "WARN"

    def test_consistency_report_summary(self):
        """ConsistencyReport should have a meaningful summary."""
        ir = CanonIR(version="3.0")
        report = validate_ir(ir)
        assert isinstance(report.summary, str)
        assert len(report.summary) > 0

    def test_has_errors_and_warnings(self):
        """ConsistencyReport helper methods should work correctly."""
        issues = [
            ConsistencyIssue(severity="ERROR", category="test", node_id="n1", message="err"),
            ConsistencyIssue(severity="WARN", category="test", node_id="n2", message="warn"),
        ]
        report = ConsistencyReport(valid=False, issues=issues, summary="test")
        assert report.has_errors() is True
        assert report.has_warnings() is True


# =========================================================================
# 6. Compiler Tests
# =========================================================================

class TestCanonCompiler:
    """Verify that the CanonCompiler correctly transforms YAML → CanonIR."""

    def setup_method(self):
        self.compiler = CanonCompiler()

    def test_compile_empty(self):
        ir = self.compiler.compile({})
        assert ir.version == "1.0"
        assert len(ir.invariants) == 0
        assert len(ir.boundaries) == 0
        assert len(ir.policies) == 0
        assert len(ir.test_specs) == 0

    def test_compile_boundaries(self):
        data = {
            "version": "3.0",
            "layers": [
                {
                    "name": "memory",
                    "path": "core/memory/",
                    "allowed_patterns": ["cosine_similarity"],
                    "forbidden_patterns": ["subprocess"],
                    "note": "Memory layer",
                }
            ]
        }
        ir = self.compiler.compile(data)
        assert len(ir.boundaries) == 1
        assert ir.boundaries[0].id == "boundary.memory"
        assert ir.boundaries[0].path == "core/memory/"

    def test_compile_invariants(self):
        data = {
            "invariants": [
                {
                    "id": "inv.test.1",
                    "severity": "FATAL",
                    "scope": ["global"],
                    "condition": {"op": "EQ", "key": "layer", "value": "memory"},
                    "action": "DENY",
                }
            ]
        }
        ir = self.compiler.compile(data)
        assert len(ir.invariants) == 1
        assert ir.invariants[0].id == "inv.test.1"
        assert ir.invariants[0].condition.op == "EQ"

    def test_compile_policies(self):
        data = {
            "policies": [
                {
                    "id": "pol.test.1",
                    "type": "security",
                    "severity": "fatal",
                    "description": "Test",
                    "condition": {"op": "EQ", "key": "action", "value": "write"},
                }
            ]
        }
        ir = self.compiler.compile(data)
        assert len(ir.policies) == 1
        assert ir.policies[0].type == "security"

    def test_compile_tests(self):
        data = {
            "self_test": {
                "suites": [
                    {
                        "name": "memory",
                        "tests": ["test_a", "test_b"],
                    }
                ]
            }
        }
        ir = self.compiler.compile(data)
        assert len(ir.test_specs) == 2
        assert ir.test_specs[0].suite == "memory"
        assert ir.test_specs[0].name == "test_a"

    def test_compile_predicate_nested(self):
        data = {
            "invariants": [
                {
                    "id": "inv.complex",
                    "severity": "FATAL",
                    "scope": ["global"],
                    "condition": {
                        "op": "AND",
                        "args": [
                            {"op": "EQ", "key": "a", "value": 1},
                            {"op": "OR", "args": [
                                {"op": "EQ", "key": "b", "value": 2},
                                {"op": "EQ", "key": "c", "value": 3},
                            ]},
                        ],
                    },
                    "action": "DENY",
                }
            ]
        }
        ir = self.compiler.compile(data)
        inv = ir.invariants[0]
        assert inv.condition.op == "AND"
        assert len(inv.condition.args) == 2
        assert inv.condition.args[1].op == "OR"
        assert len(inv.condition.args[1].args) == 2

    def test_compile_with_metadata(self):
        data = {
            "version": "3.0",
            "metadata": {"ci_drift": {"key": "value"}},
        }
        ir = self.compiler.compile(data)
        assert ir.metadata["ci_drift"]["key"] == "value"


# =========================================================================
# 7. Manager Tests
# =========================================================================

class TestInvariantManager:
    """Verify that the InvariantManager loads and compiles canon.yaml."""

    def test_manager_loads_canon_yaml(self):
        """The manager should load the real canon.yaml from the project."""
        manager = InvariantManager()
        ir = manager.get_ir()
        assert ir.version == "3.0"
        assert len(ir.boundaries) > 0
        assert len(ir.invariants) > 0

    def test_manager_singleton(self):
        """get_invariant_manager should return the same instance."""
        m1 = get_invariant_manager()
        m2 = get_invariant_manager()
        assert m1 is m2

    def test_manager_get_layer(self):
        """get_layer should return the correct boundary by name."""
        manager = InvariantManager()
        layer = manager.get_layer("memory")
        assert layer is not None
        assert layer.name == "memory"
        assert "core/memory/" in layer.path

    def test_manager_get_layer_nonexistent(self):
        """get_layer should return None for unknown layers."""
        manager = InvariantManager()
        assert manager.get_layer("nonexistent") is None

    def test_manager_custom_path(self):
        """Manager should accept a custom canon path."""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.yaml', delete=False) as f:
            f.write("version: '1.0'\nlayers: []\ninvariants: []\n")
            f.flush()
            manager = InvariantManager(canon_path=f.name)
            ir = manager.get_ir()
            assert ir.version == "1.0"
            os.unlink(f.name)


# =========================================================================
# 8. CI Drift Consumer Tests
# =========================================================================

class TestCIDriftConsumer:
    """Verify that the CI Drift consumer generates correct config from IR."""

    def test_get_drift_config_returns_dict(self):
        config = get_drift_config()
        assert isinstance(config, dict)
        assert "SCORING_PATTERNS" in config
        assert "SECURITY_PATTERNS" in config
        assert "GOVERNANCE_PATTERNS" in config
        assert "ALLOWED_PATHS" in config

    def test_scoring_patterns_present(self):
        config = get_drift_config()
        assert "cosine_similarity" in config["SCORING_PATTERNS"]

    def test_security_patterns_present(self):
        config = get_drift_config()
        assert "rm -rf" in config["SECURITY_PATTERNS"]

    def test_allowed_paths_present(self):
        config = get_drift_config()
        assert "core/policy/" in config["ALLOWED_PATHS"]

    def test_scoring_allowed_layers(self):
        config = get_drift_config()
        # Memory layer allows cosine_similarity
        assert "core/memory/" in config["SCORING_ALLOWED_LAYERS"]


# =========================================================================
# 9. Integration Tests
# =========================================================================

class TestIntegration:
    """End-to-end tests for the Invariant Canon evaluation pipeline."""

    def test_full_pipeline_from_yaml(self):
        """Load canon.yaml, compile to IR, validate, and evaluate."""
        manager = InvariantManager()
        ir = manager.get_ir()

        # Validate
        report = validate_ir(ir)
        # The real canon.yaml should be valid
        assert report.valid is True, f"IR validation failed: {report.summary}"

        # Evaluate with a context that should match no invariants
        evaluator = InvariantEvaluator(ir)
        result = evaluator.evaluate({"scope": "global", "layer": "cli"})
        assert isinstance(result, EvaluationResult)
        assert result.decision in ("ALLOW", "DENY", "FLAG")

    def test_evaluation_deny_on_match(self):
        """If an invariant matches with action=DENY, the decision should be DENY."""
        ir = CanonIR(
            version="3.0",
            invariants=[
                InvariantNode(id="inv.deny_all", name="Deny All", description="",
                              severity="FATAL", scope=["global"],
                              condition=PredicateAST(op="EQ", key="danger", value=True),
                              action="DENY", source="test"),
            ],
        )
        evaluator = InvariantEvaluator(ir)
        result = evaluator.evaluate({"scope": "global", "danger": True})
        assert result.decision == "DENY"

    def test_evaluation_allow_when_no_match(self):
        """If no invariant matches, the decision should be ALLOW."""
        ir = CanonIR(
            version="3.0",
            invariants=[
                InvariantNode(id="inv.deny_danger", name="Deny Danger", description="",
                              severity="FATAL", scope=["global"],
                              condition=PredicateAST(op="EQ", key="danger", value=True),
                              action="DENY", source="test"),
            ],
        )
        evaluator = InvariantEvaluator(ir)
        result = evaluator.evaluate({"scope": "global", "danger": False})
        assert result.decision == "ALLOW"

    def test_evaluation_flag_on_match(self):
        """If an invariant matches with action=FLAG, the decision should be FLAG."""
        ir = CanonIR(
            version="3.0",
            invariants=[
                InvariantNode(id="inv.flag_test", name="Flag Test", description="",
                              severity="INFO", scope=["global"],
                              condition=PredicateAST(op="EQ", key="flag_me", value=True),
                              action="FLAG", source="test"),
            ],
        )
        evaluator = InvariantEvaluator(ir)
        result = evaluator.evaluate({"scope": "global", "flag_me": True})
        assert result.decision == "FLAG"

    def test_evaluation_trace_contains_triggered_nodes(self):
        """The resolution trace should list all triggered nodes."""
        ir = CanonIR(
            version="3.0",
            invariants=[
                InvariantNode(id="inv.test", name="Test", description="",
                              severity="FATAL", scope=["global"],
                              condition=PredicateAST(op="EQ", key="x", value=1),
                              action="DENY", source="test"),
            ],
        )
        evaluator = InvariantEvaluator(ir)
        result = evaluator.evaluate({"scope": "global", "x": 1})
        assert "inv.test" in result.triggered_nodes
        assert len(result.resolution_trace) > 0

    def test_ci_drift_consumer_integration(self):
        """The CI Drift consumer should work with the real canon.yaml."""
        config = get_drift_config()
        assert isinstance(config, dict)
        # Verify that the config is internally consistent
        for pattern in config["SCORING_PATTERNS"]:
            if pattern in ["cosine_similarity"]:
                assert "core/memory/" in config["SCORING_ALLOWED_LAYERS"]
