import unittest
import json
import asyncio
from unittest.mock import MagicMock, AsyncMock
from core.wave_engine import WaveEngine, WaveStatus
from core.security_vault import security_vault

class TestWaveEncryption(unittest.TestCase):
    def setUp(self):
        self.engine = WaveEngine()
        self.engine.waves = {}
        # Mock LLM Engine
        self.engine.llm_engine = MagicMock()
        
    def test_synchronize_encrypts_results(self):
        wave_id = "test-wave-123"
        tenant_id = "tenant-secure"
        self.engine.waves[wave_id] = {
            "wave_id": wave_id,
            "tenant_id": tenant_id,
            "status": WaveStatus.PENDING_SYNCHRONIZATION,
            "partial_results": {
                "agent-1": {"agent_id": "agent-1", "weight": 0.8, "data": {"decisions": {"analyze": True}}}
            }
        }
        
        # Mock Expert Unifier response
        mock_response = {
            "choices": [{"delta": {"content": '{"summary": "All good", "decisions": {"proceed": true}, "reasoning": "Trust weights align."}'}}]
        }
        
        async def mock_call(*args, **kwargs):
            yield mock_response
            
        self.engine.llm_engine.call_ollama.side_effect = mock_call
        
        # Run sync
        loop = asyncio.get_event_loop()
        final_output = loop.run_until_complete(self.engine.synchronize(wave_id, "expert-user"))
        
        wave = self.engine.waves[wave_id]
        
        # Verify encryption
        self.assertEqual(wave["final_output"], "[ENCRYPTED]")
        self.assertIn("final_output_encrypted", wave)
        self.assertEqual(wave["partial_results"], "[ENCRYPTED]")
        self.assertIn("partial_results_encrypted", wave)
        
        # Decrypt and verify
        decrypted_output = security_vault.decrypt(tenant_id, wave["final_output_encrypted"])
        self.assertIn("All good", decrypted_output)
        
        decrypted_partials = security_vault.decrypt(tenant_id, wave["partial_results_encrypted"])
        partials_data = json.loads(decrypted_partials)
        self.assertTrue(partials_data["agent-1"]["data"]["decisions"]["analyze"])

if __name__ == "__main__":
    unittest.main()
