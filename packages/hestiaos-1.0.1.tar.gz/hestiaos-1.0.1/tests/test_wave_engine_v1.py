import asyncio
import json
import unittest
from core.wave_engine import wave_engine, WaveStatus
from core.embedding_service import embedding_service

class TestWaveEngine(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        await embedding_service.startup()

    async def asyncTearDown(self):
        await embedding_service.shutdown()

    async def test_end_to_end_wave_flow(self):
        tenant_id = "test-tenant-123"
        problem = "Optimize the neural shunt for 768-dim tunneling."
        
        # 1. Create Wave
        print("\n--- Phase 1: Creation ---")
        wave_id = await wave_engine.create_wave(problem, tenant_id)
        self.assertIsNotNone(wave_id)
        wave = wave_engine.waves[wave_id]
        self.assertEqual(wave["status"], WaveStatus.CREATED)
        self.assertEqual(len(wave["embedding"]), 768)
        print(f"Wave {wave_id} created with 768-dim embedding.")

        # 2. Prepare Propagation
        print("\n--- Phase 2: Preparation ---")
        await wave_engine.prepare_propagation(wave_id)
        self.assertEqual(wave["status"], WaveStatus.PENDING_PROPAGATION)
        self.assertEqual(len(wave["agents"]), 3) # Based on wave_agents.yml
        print(f"Propagation prepared for {len(wave['agents'])} agents.")

        # 3. Approve Propagation (Checkpoint 1)
        print("\n--- Phase 3: Approval 1 ---")
        success = await wave_engine.approve_propagation(wave_id, "admin-user")
        self.assertTrue(success)
        self.assertEqual(wave["status"], WaveStatus.PROPAGATING)
        print("Propagation approved.")

        # 4. Wait for Simulation
        print("\n--- Phase 4: Simulated Processing ---")
        # Since _simulate_propagation is a background task, we wait for status change
        for _ in range(10):
            if wave["status"] == WaveStatus.PENDING_SYNCHRONIZATION:
                break
            await asyncio.sleep(0.5)
        
        self.assertEqual(wave["status"], WaveStatus.PENDING_SYNCHRONIZATION)
        self.assertEqual(len(wave["partial_results"]), 3)
        print("Partial results collected.")

        # 5. Synchronize (Checkpoint 2)
        print("\n--- Phase 5: Synchronization & Commitment ---")
        final_output = await wave_engine.synchronize(wave_id, "admin-user")
        self.assertIsNotNone(final_output)
        self.assertEqual(wave["status"], WaveStatus.COMMITTED)
        print("Wave committed successfully.")
        print(f"Final Output: {final_output[:100]}...")

if __name__ == "__main__":
    unittest.main()
