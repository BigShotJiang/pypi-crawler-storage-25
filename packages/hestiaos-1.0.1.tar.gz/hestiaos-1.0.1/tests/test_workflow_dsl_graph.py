"""
Tests for Workflow DSL — graph.py (Graph Builder + Cycle Detection).
"""

import pytest

from core.workflow_dsl.graph import (
    GraphBuilder,
    GraphError,
    GraphNode,
    GraphEdge,
    ExecutionGraph,
)
from core.workflow_dsl.models import StepDefinition, StepType


class TestGraphNode:
    def test_minimal(self):
        node = GraphNode(
            step_id="s1",
            step_type=StepType.LLM,
            config={},
            inputs={},
            outputs={},
        )
        assert node.step_id == "s1"
        assert node.step_type == StepType.LLM
        assert node.branches == {}
        assert node.subworkflow_name is None
        assert node.timeout_seconds == 30


class TestGraphEdge:
    def test_sequential(self):
        edge = GraphEdge(source_id="s1", target_id="s2")
        assert edge.source_id == "s1"
        assert edge.target_id == "s2"
        assert edge.branch_key is None

    def test_branch(self):
        edge = GraphEdge(source_id="s1", target_id="s2", branch_key="pass")
        assert edge.branch_key == "pass"


class TestExecutionGraph:
    def test_empty(self):
        graph = ExecutionGraph()
        assert graph.nodes == {}
        assert graph.edges == []
        assert graph.entry_points == []
        assert graph.topological_order == []
        assert graph.max_depth == 0


class TestGraphBuilder:
    def setup_method(self):
        self.builder = GraphBuilder()

    def _step(self, sid: str, stype: StepType = StepType.LLM, branches=None) -> StepDefinition:
        return StepDefinition(id=sid, name=sid, type=stype, branches=branches)

    def test_single_step(self):
        graph = self.builder.build([self._step("s1")])
        assert "s1" in graph.nodes
        assert graph.entry_points == ["s1"]
        assert graph.topological_order == ["s1"]
        assert graph.max_depth == 1

    def test_sequential_steps(self):
        graph = self.builder.build([self._step("s1"), self._step("s2"), self._step("s3")])
        assert len(graph.nodes) == 3
        assert graph.entry_points == ["s1"]
        assert graph.topological_order == ["s1", "s2", "s3"]
        assert len(graph.edges) == 2

    def test_condition_with_branches(self):
        on_pass = self._step("on_pass")
        on_fail = self._step("on_fail")
        condition = self._step(
            "cond", StepType.CONDITION,
            branches={"pass": [on_pass], "fail": [on_fail]},
        )
        after = self._step("after")

        graph = self.builder.build([condition, after])
        assert len(graph.nodes) == 4
        assert graph.entry_points == ["cond"]
        assert len(graph.edges) == 4

    def test_cycle_detection(self):
        steps = [self._step("s1"), self._step("s2")]
        graph = self.builder.build(steps)
        cycles = self.builder.detect_cycles(graph)
        assert cycles == []

        graph.edges.append(GraphEdge(source_id="s2", target_id="s1"))
        cycles = self.builder.detect_cycles(graph)
        assert len(cycles) > 0

    def test_cycle_raises(self):
        graph = ExecutionGraph()
        graph.nodes["s1"] = GraphNode(
            step_id="s1", step_type=StepType.LLM, config={}, inputs={}, outputs={}
        )
        graph.nodes["s2"] = GraphNode(
            step_id="s2", step_type=StepType.LLM, config={}, inputs={}, outputs={}
        )
        graph.edges.append(GraphEdge(source_id="s1", target_id="s2"))
        graph.edges.append(GraphEdge(source_id="s2", target_id="s1"))

        self.builder._validate_integrity(graph)
        cycles = self.builder.detect_cycles(graph)
        if cycles:
            with pytest.raises(GraphError, match="Cycle detected"):
                raise GraphError(f"Cycle detected in workflow graph: {cycles}")

    def test_missing_step_reference_raises(self):
        graph = ExecutionGraph()
        graph.nodes["s1"] = GraphNode(
            step_id="s1", step_type=StepType.LLM, config={}, inputs={}, outputs={}
        )
        graph.edges.append(GraphEdge(source_id="s1", target_id="s2"))

        with pytest.raises(GraphError, match="unknown target"):
            self.builder._validate_integrity(graph)

    def test_topological_sort_deterministic(self):
        steps = [self._step("b"), self._step("a")]
        graph = self.builder.build(steps)
        assert graph.topological_order == ["b", "a"]

    def test_depth_calculation(self):
        graph = self.builder.build([self._step("s1"), self._step("s2"), self._step("s3")])
        assert graph.max_depth == 3

    def test_subworkflow_reference(self):
        step = StepDefinition(
            id="sub",
            name="Sub Workflow",
            type=StepType.SUBWORKFLOW,
            config={"workflow": "nested_pipeline"},
        )
        graph = self.builder.build([step])
        assert graph.nodes["sub"].subworkflow_name == "nested_pipeline"
