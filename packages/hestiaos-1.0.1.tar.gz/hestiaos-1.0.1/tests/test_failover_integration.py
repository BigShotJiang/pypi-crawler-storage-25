import unittest
import asyncio
from datetime import datetime, timedelta
from unittest.mock import AsyncMock, MagicMock, patch

from core.consciousness import ConsciousnessProtocol, AgentRole, AwarenessState, ConsciousnessLevel
from core.consciousness_identity import IdentityManager
from core.agent_registry import AgentRegistry, AgentStatus
from core.shared_context import SharedContextManager, ContextType, ContextItem
from core.failover_controller import FailoverController

class TestFailoverIntegration(unittest.TestCase):
    def setUp(self):
        self.agent_id = "test_orchestrator"
        self.agent_role = AgentRole.ORCHESTRATOR
        
        # Mocks
        self.comm_client = AsyncMock()
        self.identity_manager = IdentityManager(self.agent_id, self.agent_role.value)
        self.shared_context = MagicMock(spec=SharedContextManager)
        self.shared_context.context_type = ContextType
        
        # Real Registry but mocked shared_context
        self.registry = AgentRegistry(self.identity_manager, shared_context=self.shared_context)
        
        # Protocol with replication support
        self.protocol = ConsciousnessProtocol(
            self.agent_id, self.agent_role, self.comm_client, 
            shared_context=self.shared_context
        )
        
        # Failover Controller
        self.failover = FailoverController(self.registry, self.shared_context)

    async def async_test_replication_cycle(self):
        """Verify that protocol replicates state to HA space"""
        await self.protocol.replicate_consciousness()
        
        # Check if create_context_item was called with STATE
        self.shared_context.create_context_item.assert_called_with(
            context_type=ContextType.STATE,
            content=unittest.mock.ANY,
            space_id="high_availability",
            priority="high",
            consistency="eventual"
        )

    async def async_test_failover_detection(self):
        """Verify that FailoverController detects offline critical agents"""
        # 1. Register a fake peer orchestrator
        peer_id = "peer_orchestrator"
        await self.registry.register_agent(peer_id, "Peer", AgentRole.ORCHESTRATOR.value)
        
        # 2. Mock state in HA space
        mock_item = MagicMock(spec=ContextItem)
        mock_item.content = {
            "agent_id": peer_id,
            "consciousness_state": {"level": "collective"},
            "timestamp": datetime.utcnow().isoformat()
        }
        self.shared_context.request_context.return_value = [mock_item]
        
        # 3. Mark peer as OFFLINE
        peer = self.registry.get_agent(peer_id)
        peer.status = AgentStatus.OFFLINE
        
        # 4. Trigger failover check
        with patch.object(self.failover.logger, 'warning') as mock_warn:
            await self.failover._check_for_failures()
            mock_warn.assert_called_with(unittest.mock.ANY)
            
        # 5. Verify state was requested
        self.shared_context.request_context.assert_called_with(
            space_id="high_availability",
            context_type=ContextType.STATE
        )

    def test_replication_cycle(self):
        asyncio.run(self.async_test_replication_cycle())

    def test_failover_detection(self):
        asyncio.run(self.async_test_failover_detection())

if __name__ == "__main__":
    unittest.main()
