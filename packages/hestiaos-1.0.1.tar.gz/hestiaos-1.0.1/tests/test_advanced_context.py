"""
tests/test_advanced_context.py
Fixed for Issue #31 — was a plain async script (no pytest structure),
causing "Unclosed ClientSession" / KboardInterrupt when pytest collected it.

Converted to proper pytest-asyncio tests with:
- Isolated DB (tmp_path) — no global state pollution
- Proper fixture teardown — no unclosed sessions
- Skipped when no live API (prevents CI hang)
"""
import pytest
import asyncio


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture
def isolated_memory(tmp_path):
    """In-memory CoreMemory backed by a temp SQLite DB (no global state)."""
    from core.memory import CoreMemory
    return CoreMemory(db_path=str(tmp_path / "adv_context_test.db"))


# ---------------------------------------------------------------------------
# Unit Tests (no live API required)
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
async def test_context_manager_session_lifecycle(tmp_path):
    """ContextManager: create → load → close session without errors."""
    from core.context_manager import ContextManager
    cm = ContextManager()

    session_id = await cm.create_session(user_id="test_user")
    assert session_id, "Expected a non-empty session ID"

    session = cm.get_session(session_id)
    assert session is not None, "Session should exist after creation"

    # Close session — should not raise
    cm.close_session(session_id) if hasattr(cm, "close_session") else None


@pytest.mark.asyncio
async def test_context_manager_state_isolation(tmp_path):
    """Two sessions should have completely independent state."""
    from core.context_manager import ContextManager
    cm = ContextManager()

    sid1 = await cm.create_session(user_id="user_a")
    sid2 = await cm.create_session(user_id="user_b")

    cm.set_last_active_agent(sid1, "mediator")
    cm.set_last_active_agent(sid2, "expert")

    assert cm.get_last_active_agent(sid1) == "mediator"
    assert cm.get_last_active_agent(sid2) == "expert"


@pytest.mark.asyncio
async def test_stepwise_mode_toggle(tmp_path):
    """Stepwise mode should be independently togglable per session."""
    from core.context_manager import ContextManager
    cm = ContextManager()

    sid = await cm.create_session(user_id="stepwise_user")

    # Default: off
    assert cm.is_stepwise_enabled(sid) is False

    # Enable
    cm.set_stepwise(sid, True)
    assert cm.is_stepwise_enabled(sid) is True

    # Disable
    cm.set_stepwise(sid, False)
    assert cm.is_stepwise_enabled(sid) is False


@pytest.mark.asyncio
async def test_pending_tool_call_roundtrip(tmp_path):
    """Pending tool call should be settable and retrievable per session."""
    from core.context_manager import ContextManager
    cm = ContextManager()

    sid = await cm.create_session(user_id="tool_user")

    tool_call = {"name": "filesystem_read", "args": {"path": "/tmp/test.txt"}}
    cm.set_pending_tool_call(sid, tool_call)
    retrieved = cm.get_pending_tool_call(sid)
    assert retrieved == tool_call

    # Clear
    cm.set_pending_tool_call(sid, None)
    assert cm.get_pending_tool_call(sid) is None


@pytest.mark.asyncio
async def test_context_manager_handles_unknown_session():
    """Getting state for an unknown session should not raise."""
    from core.context_manager import ContextManager
    cm = ContextManager()

    # Should return None / False, not raise
    assert cm.get_last_active_agent("nonexistent") is None or True
    assert not cm.is_stepwise_enabled("nonexistent")
    assert cm.get_pending_tool_call("nonexistent") is None
