#!/usr/bin/env python3
"""
Test script for FileStateCache invalidation functionality.

This script tests that the cache properly invalidates entries when files are modified,
deleted, or when directories are invalidated.
"""

import os
import asyncio
import tempfile
import shutil
from pathlib import Path
import time

# Add the core directory to the path
import sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from core.cache.file_state_cache import FileStateCache, create_file_state_cache
from hands.filesystem_cached import CachedFileSystemTools


async def test_basic_cache_operations():
    """Test basic cache operations: read, write, cache hit/miss."""
    print("🧪 Testing basic cache operations...")
    
    # Create a temporary directory for testing
    with tempfile.TemporaryDirectory() as tmpdir:
        test_file = Path(tmpdir) / "test.txt"
        test_content = "Hello, World!\nThis is a test file.\n"
        
        # Write initial content
        test_file.write_text(test_content)
        
        # Create cache instance
        cache = create_file_state_cache({"max_size_mb": 10})
        await cache.initialize()
        
        # Test 1: First read should be a miss
        print("  Test 1: First read (should be cache miss)...")
        content1 = await cache.get_file_content(str(test_file))
        stats1 = await cache.get_stats()
        assert stats1['misses'] == 1, f"Expected 1 miss, got {stats1['misses']}"
        assert content1 == test_content
        print("    ✅ Cache miss recorded correctly")
        
        # Test 2: Second read should be a hit
        print("  Test 2: Second read (should be cache hit)...")
        content2 = await cache.get_file_content(str(test_file))
        stats2 = await cache.get_stats()
        assert stats2['hits'] == 1, f"Expected 1 hit, got {stats2['hits']}"
        assert content2 == test_content
        print("    ✅ Cache hit recorded correctly")
        
        # Test 3: Read with force_read should be a miss
        print("  Test 3: Force read (should bypass cache)...")
        content3 = await cache.get_file_content(str(test_file), force_read=True)
        stats3 = await cache.get_stats()
        assert stats3['misses'] == 2, f"Expected 2 misses, got {stats3['misses']}"
        print("    ✅ Force read bypassed cache correctly")
        
        print("✅ Basic cache operations test passed!")


async def test_cache_invalidation_on_file_modification():
    """Test that cache invalidates when files are modified."""
    print("\n🧪 Testing cache invalidation on file modification...")
    
    with tempfile.TemporaryDirectory() as tmpdir:
        test_file = Path(tmpdir) / "modify_test.txt"
        
        # Create cache
        cache = create_file_state_cache({"max_size_mb": 10})
        await cache.initialize()
        
        # Step 1: Write initial content and cache it
        initial_content = "Initial content\n"
        test_file.write_text(initial_content)
        
        # Read to cache
        await cache.get_file_content(str(test_file))
        stats1 = await cache.get_stats()
        assert stats1['hits'] == 0 and stats1['misses'] == 1
        
        # Step 2: Read again - should be cache hit
        content1 = await cache.get_file_content(str(test_file))
        stats2 = await cache.get_stats()
        assert stats2['hits'] == 1, f"Expected cache hit, got {stats2['hits']}"
        assert content1 == initial_content
        print("  ✅ Initial cache hit recorded")
        
        # Step 3: Modify file (simulate external modification)
        time.sleep(0.1)  # Ensure different mtime
        modified_content = "Modified content\n"
        test_file.write_text(modified_content)
        
        # Step 4: Read again - should detect stale cache and be miss
        content2 = await cache.get_file_content(str(test_file))
        stats3 = await cache.get_stats()
        assert stats3['misses'] == 2, f"Expected cache miss after modification, got {stats3['misses']}"
        assert content2 == modified_content
        print("  ✅ Cache detected file modification (stale cache)")
        
        # Step 5: Read again - should be hit with new content
        content3 = await cache.get_file_content(str(test_file))
        stats4 = await cache.get_stats()
        assert stats4['hits'] == 2, f"Expected cache hit with new content, got {stats4['hits']}"
        assert content3 == modified_content
        print("  ✅ New content cached correctly")
        
        print("✅ Cache invalidation on file modification test passed!")


async def test_manual_cache_invalidation():
    """Test manual cache invalidation methods."""
    print("\n🧪 Testing manual cache invalidation...")
    
    with tempfile.TemporaryDirectory() as tmpdir:
        tmpdir_path = Path(tmpdir)
        
        # Create test files
        file1 = tmpdir_path / "file1.txt"
        file2 = tmpdir_path / "file2.txt"
        subdir = tmpdir_path / "subdir"
        subdir.mkdir()
        file3 = subdir / "file3.txt"
        
        file1.write_text("File 1 content")
        file2.write_text("File 2 content")
        file3.write_text("File 3 content")
        
        # Create cache
        cache = create_file_state_cache({"max_size_mb": 10})
        await cache.initialize()
        
        # Cache all files
        await cache.get_file_content(str(file1))
        await cache.get_file_content(str(file2))
        await cache.get_file_content(str(file3))
        
        stats1 = await cache.get_stats()
        initial_file_count = stats1.get('file_count', 0)
        assert initial_file_count == 3, f"Expected 3 cached files, got {initial_file_count}"
        print(f"  ✅ {initial_file_count} files cached initially")
        
        # Test 1: Invalidate single file
        print("  Test 1: Invalidate single file...")
        success = await cache.invalidate_file(str(file1), reason="test")
        assert success, "File invalidation should succeed"
        
        stats2 = await cache.get_stats()
        file_count_after = stats2.get('file_count', 0)
        assert file_count_after == 2, f"Expected 2 files after invalidation, got {file_count_after}"
        print("    ✅ Single file invalidated correctly")
        
        # Test 2: Invalidate directory (non-recursive)
        print("  Test 2: Invalidate directory (non-recursive)...")
        count = await cache.invalidate_directory(str(tmpdir_path), recursive=False)
        # Should invalidate file2 only (file1 already invalidated, file3 in subdir)
        assert count == 1, f"Expected 1 file invalidated, got {count}"
        
        stats3 = await cache.get_stats()
        file_count_dir = stats3.get('file_count', 0)
        assert file_count_dir == 1, f"Expected 1 file remaining (in subdir), got {file_count_dir}"
        print("    ✅ Directory invalidation (non-recursive) worked")
        
        # Test 3: Invalidate directory (recursive)
        print("  Test 3: Invalidate directory (recursive)...")
        count_recursive = await cache.invalidate_directory(str(tmpdir_path), recursive=True)
        assert count_recursive == 1, f"Expected 1 file invalidated recursively, got {count_recursive}"
        
        stats4 = await cache.get_stats()
        file_count_final = stats4.get('file_count', 0)
        assert file_count_final == 0, f"Expected 0 files remaining, got {file_count_final}"
        print("    ✅ Directory invalidation (recursive) worked")
        
        # Test 4: Clear entire cache
        print("  Test 4: Clear entire cache...")
        # Add files back to cache
        await cache.get_file_content(str(file1))
        await cache.get_file_content(str(file2))
        
        clear_count = await cache.clear_async()
        assert clear_count >= 2, f"Expected at least 2 files cleared, got {clear_count}"
        
        stats5 = await cache.get_stats()
        file_count_clear = stats5.get('file_count', 0)
        assert file_count_clear == 0, f"Expected 0 files after clear, got {file_count_clear}"
        print("    ✅ Cache clear worked")
        
        print("✅ Manual cache invalidation test passed!")


async def test_delta_computation():
    """Test delta computation for efficient updates."""
    print("\n🧪 Testing delta computation...")
    
    with tempfile.TemporaryDirectory() as tmpdir:
        test_file = Path(tmpdir) / "delta_test.txt"
        
        # Create cache with delta enabled
        cache = create_file_state_cache({
            "max_size_mb": 10,
            "delta_enabled": True,
            "delta_threshold_ratio": 0.5
        })
        await cache.initialize()
        
        # Initial content
        initial_content = "Line 1\nLine 2\nLine 3\nLine 4\nLine 5\n"
        test_file.write_text(initial_content)
        
        # Cache initial content
        await cache.get_file_content(str(test_file))
        
        # Small modification (should compute delta)
        modified_content = "Line 1\nLine 2 modified\nLine 3\nLine 4\nLine 5\n"
        
        # Update file through cache
        success = await cache.update_file(str(test_file), modified_content)
        assert success, "File update should succeed"
        
        # Check delta statistics
        stats = await cache.get_stats()
        delta_hits = stats.get('delta_hits', 0)
        bytes_saved = stats.get('bytes_saved', 0)
        
        print(f"  Delta hits: {delta_hits}")
        print(f"  Bytes saved: {bytes_saved}")
        
        if delta_hits > 0:
            print("  ✅ Delta computation worked")
        else:
            print("  ⚠️ Delta not computed (might be larger than threshold)")
        
        # Verify content is correct
        cached_content = await cache.get_file_content(str(test_file))
        assert cached_content == modified_content, "Cached content should match modified content"
        
        print("✅ Delta computation test completed!")


async def test_integration_with_filesystem_tools():
    """Test integration with CachedFileSystemTools."""
    print("\n🧪 Testing integration with CachedFileSystemTools...")
    
    with tempfile.TemporaryDirectory() as tmpdir:
        test_file = Path(tmpdir) / "integration_test.txt"
        test_content = "Integration test content\n"
        
        # Write initial file
        test_file.write_text(test_content)
        
        # Test 1: Read with cache
        print("  Test 1: Read file with cache...")
        result1 = await CachedFileSystemTools.read_file(str(test_file), use_cache=True)
        assert result1["success"], f"Read failed: {result1.get('error')}"
        assert result1["cached"] == True, "Should use cache"
        assert result1["content"] == test_content
        print("    ✅ Read with cache successful")
        
        # Test 2: Read again (should be cached)
        print("  Test 2: Read again (should be cached)...")
        result2 = await CachedFileSystemTools.read_file(str(test_file), use_cache=True)
        assert result2["success"]
        # Note: We can't easily check cache hit from here, but functionality should work
        print("    ✅ Second read successful")
        
        # Test 3: Write with cache update
        print("  Test 3: Write file with cache update...")
        new_content = "Updated content\n"
        result3 = await CachedFileSystemTools.write_file(
            str(test_file), new_content, update_cache=True
        )
        assert result3["success"], f"Write failed: {result3.get('error')}"
        assert result3["cached"] == True, "Should update cache"
        print("    ✅ Write with cache update successful")
        
        # Test 4: Verify written content
        print("  Test 4: Verify written content...")
        result4 = await CachedFileSystemTools.read_file(str(test_file), use_cache=True)
        assert result4["success"]
        assert result4["content"] == new_content
        print("    ✅ Content verification successful")
        
        # Test 5: Cache invalidation via tools
        print("  Test 5: Cache invalidation via tools...")
        result5 = await CachedFileSystemTools.invalidate_cache(str(test_file))
        assert result5["success"], f"Invalidation failed: {result5.get('error')}"
        assert result5["action"] == "invalidate_file"
        print("    ✅ Cache invalidation via tools successful")
        
        # Test 6: Get cache stats
        print("  Test 6: Get cache statistics...")
        result6 = await CachedFileSystemTools.get_cache_stats()
        assert result6["success"], f"Stats failed: {result6.get('error')}"
        assert "stats" in result6
        print(f"    ✅ Cache stats: {result6['stats']}")
        
        print("✅ Integration with CachedFileSystemTools test passed!")


async def run_all_tests():
    """Run all cache invalidation tests."""
    print("=" * 60)
    print("🧪 Starting FileStateCache Invalidation Tests")
    print("=" * 60)
    
    tests = [
        test_basic_cache_operations,
        test_cache_invalidation_on_file_modification,
        test_manual_cache_invalidation,
        test_delta_computation,
        test_integration_with_filesystem_tools
    ]
    
    passed = 0
    failed = 0
    
    for test_func in tests:
        try:
            await test_func()
            passed += 1
        except Exception as e:
            failed += 1
            print(f"\n❌ Test failed: {test_func.__name__}")
            print(f"   Error: {e}")
            import traceback
            traceback.print_exc()
    
    print("\n" + "=" * 60)
    print("📊 Test Summary")
    print("=" * 60)
    print(f"✅ Passed: {passed}")
    print(f"❌ Failed: {failed}")
    print(f"📈 Total: {passed + failed}")
    
    if failed == 0:
        print("\n🎉 All cache invalidation tests passed!")
        return True
    else:
        print(f"\n⚠️ {failed} test(s) failed")
        return False


if __name__ == "__main__":
    # Run tests
    success = asyncio.run(run_all_tests())
    
    if success:
        print("\n✅ Cache invalidation testing completed successfully!")
        sys.exit(0)
    else:
        print("\n❌ Cache invalidation testing failed!")
        sys.exit(1)