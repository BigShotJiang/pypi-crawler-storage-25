"""
Unit tests for Crypto Adapter using EncryptionManager.
"""

import pytest
import base64
from unittest.mock import Mock, MagicMock, patch

from core.vault.crypto_adapter import CryptoAdapter, EncryptedStorageAdapter
from core.vault.service_accounts import ServiceAccountSecret
from core.vault.storage import InMemoryServiceAccountStorage


class TestCryptoAdapter:
    """Test CryptoAdapter with mocked EncryptionManager."""
    
    @pytest.fixture
    def mock_encryption_manager(self):
        mock = Mock()
        mock.keys = {}
        return mock
    
    @pytest.fixture
    def crypto_adapter(self, mock_encryption_manager):
        return CryptoAdapter(mock_encryption_manager)
    
    def test_check_availability_success(self, mock_encryption_manager):
        """Test availability check when backend is available."""
        # Setup - mock successful key generation
        mock_encryption_manager.generate_aes_key.return_value = None
        
        adapter = CryptoAdapter(mock_encryption_manager)
        
        # Verify
        mock_encryption_manager.generate_aes_key.assert_called_once_with("test_availability")
    
    def test_check_availability_failure(self, mock_encryption_manager):
        """Test availability check when backend fails."""
        # Setup - mock failure
        mock_encryption_manager.generate_aes_key.side_effect = Exception("Backend down")
        
        # Execute & Verify
        with pytest.raises(RuntimeError, match="Encryption backend unavailable"):
            CryptoAdapter(mock_encryption_manager)
    
    def test_encrypt_secret_success(self, crypto_adapter, mock_encryption_manager):
        """Test successful secret encryption."""
        # Setup
        tenant_id = "tenant-1"
        secret_data = "my-secret-token"
        key_id = f"service_account_{tenant_id}"
        
        # Mock encryption
        mock_encryption_manager.encrypt_aes.return_value = {
            "ciphertext": base64.b64encode(b"encrypted-data").decode(),
            "iv": base64.b64encode(b"test-iv").decode()
        }
        
        # Execute
        secret = crypto_adapter.encrypt_secret(tenant_id, secret_data)
        
        # Verify
        assert isinstance(secret, ServiceAccountSecret)
        assert secret.ciphertext == b"encrypted-data"
        assert secret.nonce == b"test-iv"
        assert secret.version == "v1"
        assert secret.metadata["key_id"] == key_id
        assert secret.metadata["tenant_id"] == tenant_id
        
        # Verify calls
        mock_encryption_manager.generate_aes_key.assert_called_with(key_id)
        mock_encryption_manager.encrypt_aes.assert_called_with(
            key_id=key_id,
            data=secret_data
        )
    
    def test_encrypt_secret_key_exists(self, crypto_adapter, mock_encryption_manager):
        """Test encryption when key already exists."""
        # Setup - key already in manager
        tenant_id = "tenant-1"
        key_id = f"service_account_{tenant_id}"
        mock_encryption_manager.keys = {key_id: Mock()}
        
        mock_encryption_manager.encrypt_aes.return_value = {
            "ciphertext": base64.b64encode(b"encrypted").decode(),
            "iv": base64.b64encode(b"iv").decode()
        }
        
        # Execute
        crypto_adapter.encrypt_secret(tenant_id, "secret")
        
        # Verify key generation was NOT called
        mock_encryption_manager.generate_aes_key.assert_not_called()
    
    def test_encrypt_secret_failure(self, crypto_adapter, mock_encryption_manager):
        """Test encryption failure."""
        # Setup
        mock_encryption_manager.encrypt_aes.side_effect = Exception("Encryption failed")
        
        # Execute & Verify
        with pytest.raises(RuntimeError, match="Failed to encrypt secret"):
            crypto_adapter.encrypt_secret("tenant-1", "secret")
    
    def test_decrypt_secret_success(self, crypto_adapter, mock_encryption_manager):
        """Test successful secret decryption."""
        # Setup
        tenant_id = "tenant-1"
        key_id = f"service_account_{tenant_id}"
        
        # Create secret
        secret = ServiceAccountSecret(
            ciphertext=b"encrypted-data",
            nonce=b"test-iv",
            metadata={"key_id": key_id}
        )
        
        # Mock decryption
        mock_encryption_manager.keys = {key_id: Mock()}
        mock_encryption_manager.decrypt_aes.return_value = "decrypted-secret"
        
        # Execute
        result = crypto_adapter.decrypt_secret(tenant_id, secret)
        
        # Verify
        assert result == "decrypted-secret"
        mock_encryption_manager.decrypt_aes.assert_called_once()
    
    def test_decrypt_secret_key_not_found(self, crypto_adapter, mock_encryption_manager):
        """Test decryption when key not found."""
        # Setup
        tenant_id = "tenant-1"
        secret = ServiceAccountSecret(
            ciphertext=b"data",
            nonce=b"iv",
            metadata={"key_id": "missing-key"}
        )
        
        # Mock - key not in manager
        mock_encryption_manager.keys = {}
        
        # Execute & Verify
        with pytest.raises(RuntimeError, match="Encryption key not found"):
            crypto_adapter.decrypt_secret(tenant_id, secret)
    
    def test_decrypt_secret_failure(self, crypto_adapter, mock_encryption_manager):
        """Test decryption failure."""
        # Setup
        tenant_id = "tenant-1"
        key_id = f"service_account_{tenant_id}"
        
        secret = ServiceAccountSecret(
            ciphertext=b"data",
            nonce=b"iv",
            metadata={"key_id": key_id}
        )
        
        mock_encryption_manager.keys = {key_id: Mock()}
        mock_encryption_manager.decrypt_aes.return_value = None  # Empty result
        
        # Execute & Verify
        with pytest.raises(RuntimeError, match="Decryption returned empty result"):
            crypto_adapter.decrypt_secret(tenant_id, secret)
    
    def test_serialize_deserialize_secret(self, crypto_adapter):
        """Test serialization and deserialization of secrets."""
        # Create secret
        original_secret = ServiceAccountSecret(
            ciphertext=b"test-ciphertext",
            nonce=b"test-nonce",
            version="v1",
            metadata={"key_id": "test-key", "algorithm": "aes-256-gcm"}
        )
        
        # Serialize
        serialized = crypto_adapter.serialize_secret(original_secret)
        
        # Verify serialized format
        assert isinstance(serialized, str)
        assert "ciphertext" in serialized
        assert "nonce" in serialized
        
        # Deserialize
        deserialized = crypto_adapter.deserialize_secret(serialized)
        
        # Verify round-trip
        assert deserialized.ciphertext == original_secret.ciphertext
        assert deserialized.nonce == original_secret.nonce
        assert deserialized.version == original_secret.version
        assert deserialized.metadata == original_secret.metadata
    
    def test_serialize_failure(self, crypto_adapter):
        """Test serialization failure."""
        # Create secret with non-serializable metadata (circular reference)
        secret = ServiceAccountSecret(
            ciphertext=b"data",
            nonce=b"iv"
        )
        secret.metadata["self"] = secret  # Circular reference
        
        # Execute & Verify
        with pytest.raises(RuntimeError, match="Failed to serialize secret"):
            crypto_adapter.serialize_secret(secret)
    
    def test_deserialize_failure(self, crypto_adapter):
        """Test deserialization failure."""
        # Invalid JSON
        invalid_json = "{not valid json"
        
        # Execute & Verify
        with pytest.raises(RuntimeError, match="Failed to deserialize secret"):
            crypto_adapter.deserialize_secret(invalid_json)


class TestEncryptedStorageAdapter:
    """Test EncryptedStorageAdapter integration."""
    
    @pytest.fixture
    def mock_storage(self):
        return Mock(spec=InMemoryServiceAccountStorage)
    
    @pytest.fixture
    def mock_crypto_adapter(self):
        return Mock(spec=CryptoAdapter)
    
    @pytest.fixture
    def encrypted_adapter(self, mock_storage, mock_crypto_adapter):
        return EncryptedStorageAdapter(mock_storage, mock_crypto_adapter)
    
    def test_set_secret_success(self, encrypted_adapter, mock_storage, mock_crypto_adapter):
        """Test successful secret storage with encryption."""
        # Setup
        tenant_id = "tenant-1"
        account_id = "acc-1"
        plaintext_secret = "my-token"
        
        mock_secret = Mock(spec=ServiceAccountSecret)
        mock_crypto_adapter.encrypt_secret.return_value = mock_secret
        mock_storage.set_secret.return_value = True
        
        # Execute
        result = encrypted_adapter.set_secret(tenant_id, account_id, plaintext_secret)
        
        # Verify
        assert result is True
        mock_crypto_adapter.encrypt_secret.assert_called_with(tenant_id, plaintext_secret)
        mock_storage.set_secret.assert_called_with(tenant_id, account_id, mock_secret)
    
    def test_set_secret_encryption_failure(self, encrypted_adapter, mock_crypto_adapter):
        """Test secret storage when encryption fails."""
        # Setup
        mock_crypto_adapter.encrypt_secret.side_effect = Exception("Encryption failed")
        
        # Execute
        result = encrypted_adapter.set_secret("tenant-1", "acc-1", "secret")
        
        # Verify
        assert result is False
    
    def test_get_secret_success(self, encrypted_adapter, mock_storage, mock_crypto_adapter):
        """Test successful secret retrieval with decryption."""
        # Setup
        tenant_id = "tenant-1"
        account_id = "acc-1"
        
        mock_encrypted_secret = Mock(spec=ServiceAccountSecret)
        mock_storage.get_secret.return_value = mock_encrypted_secret
        mock_crypto_adapter.decrypt_secret.return_value = "decrypted-secret"
        
        # Execute
        result = encrypted_adapter.get_secret(tenant_id, account_id)
        
        # Verify
        assert result is not None
        plaintext, encrypted_secret = result
        assert plaintext == "decrypted-secret"
        assert encrypted_secret == mock_encrypted_secret
        
        mock_storage.get_secret.assert_called_with(tenant_id, account_id)
        mock_crypto_adapter.decrypt_secret.assert_called_with(tenant_id, mock_encrypted_secret)
    
    def test_get_secret_not_found(self, encrypted_adapter, mock_storage):
        """Test secret retrieval when secret doesn't exist."""
        # Setup
        mock_storage.get_secret.return_value = None
        
        # Execute
        result = encrypted_adapter.get_secret("tenant-1", "acc-1")
        
        # Verify
        assert result is None
    
    def test_get_secret_decryption_failure(self, encrypted_adapter, mock_storage, mock_crypto_adapter):
        """Test secret retrieval when decryption fails."""
        # Setup
        mock_encrypted_secret = Mock(spec=ServiceAccountSecret)
        mock_storage.get_secret.return_value = mock_encrypted_secret
        mock_crypto_adapter.decrypt_secret.side_effect = Exception("Decryption failed")
        
        # Execute
        result = encrypted_adapter.get_secret("tenant-1", "acc-1")
        
        # Verify
        assert result is None
    
    def test_get_encrypted_secret_only(self, encrypted_adapter, mock_storage):
        """Test getting encrypted secret without decryption."""
        # Setup
        mock_secret = Mock(spec=ServiceAccountSecret)
        mock_storage.get_secret.return_value = mock_secret
        
        # Execute
        result = encrypted_adapter.get_encrypted_secret_only("tenant-1", "acc-1")
        
        # Verify
        assert result == mock_secret
        mock_storage.get_secret.assert_called_with("tenant-1", "acc-1")
    
    def test_delegate_methods(self, encrypted_adapter, mock_storage):
        """Test that other storage methods are properly delegated."""
        # Test create_account
        mock_account = Mock()
        encrypted_adapter.create_account(mock_account)
        mock_storage.create_account.assert_called_with(mock_account)
        
        # Test get_account
        encrypted_adapter.get_account("tenant-1", "acc-1")
        mock_storage.get_account.assert_called_with("tenant-1", "acc-1")
        
        # Test list_accounts
        encrypted_adapter.list_accounts("tenant-1", provider="gitlab")
        mock_storage.list_accounts.assert_called_with("tenant-1", provider="gitlab")
        
        # Test update_account
        encrypted_adapter.update_account("tenant-1", "acc-1", name="new-name")
        mock_storage.update_account.assert_called_with("tenant-1", "acc-1", name="new-name")
        
        # Test delete_account
        encrypted_adapter.delete_account("tenant-1", "acc-1")
        mock_storage.delete_account.assert_called_with("tenant-1", "acc-1")
        
        # Test delete_secret
        encrypted_adapter.delete_secret("tenant-1", "acc-1")
        mock_storage.delete_secret.assert_called_with("tenant-1", "acc-1")
        
        # Test log_audit_event
        mock_event = Mock()
        encrypted_adapter.log_audit_event(mock_event)
        mock_storage.log_audit_event.assert_called_with(mock_event)
        
        # Test get_audit_events
        encrypted_adapter.get_audit_events("tenant-1", limit=50)
        mock_storage.get_audit_events.assert_called_with("tenant-1", limit=50)