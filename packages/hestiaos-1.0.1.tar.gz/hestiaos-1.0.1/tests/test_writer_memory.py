#!/usr/bin/env python3
"""
Test writer agent memory recall, persist, and incremental knowledge.
"""

import asyncio
import sys
import os
from pathlib import Path

# Add project root to path
sys.path.insert(0, str(Path(__file__).parent.parent))

from plugins.writer_memory import WriterMemoryPlugin
from core.config import config_manager
from core.path_validate import path_manager


async def test_writer_memory():
    """Test writer memory plugin functionality."""
    print("🧪 Testing Writer Memory Plugin")
    
    # Create test plugin instance
    plugin = WriterMemoryPlugin()
    
    # Initialize plugin
    await plugin.initialize()
    
    if not plugin.initialized:
        print("❌ Plugin initialization failed")
        return False
    
    print(f"✅ Plugin initialized with vault: {plugin.vault_path}")
    
    # Test 1: Write a new note
    print("\n📝 Test 1: Writing new note")
    write_result = await plugin._write_note({
        "title": "Test Memory Recall",
        "content": "This is a test note for memory recall verification.",
        "category": "HestiaOS/Agent Memory",
        "tags": ["test", "memory", "recall"]
    })
    
    if not write_result.get("success"):
        print(f"❌ Write failed: {write_result.get('error')}")
        return False
    
    note_path = write_result.get("path")
    print(f"✅ Note written: {note_path}")
    
    # Test 2: Read the note back
    print("\n📖 Test 2: Reading note back")
    read_result = await plugin._read_note({
        "path": note_path,
        "max_lines": 10
    })
    
    if not read_result.get("success"):
        print(f"❌ Read failed: {read_result.get('error')}")
        return False
    
    content = read_result.get("content", "")
    if "test note for memory recall" in content:
        print("✅ Memory recall successful")
    else:
        print(f"❌ Memory recall failed. Content: {content[:100]}...")
        return False
    
    # Test 3: Append to the note
    print("\n➕ Test 3: Appending to note")
    append_result = await plugin._append_to_note({
        "path": note_path,
        "content": "This is appended content for incremental knowledge test.",
        "section_title": "Incremental Knowledge"
    })
    
    if not append_result.get("success"):
        print(f"❌ Append failed: {append_result.get('error')}")
        return False
    
    print("✅ Append successful")
    
    # Test 4: Read again to verify append
    print("\n📖 Test 4: Verifying append")
    read_again_result = await plugin._read_note({
        "path": note_path,
        "max_lines": 20
    })
    
    if not read_again_result.get("success"):
        print(f"❌ Read after append failed: {read_again_result.get('error')}")
        return False
    
    content_after = read_again_result.get("content", "")
    if "incremental knowledge test" in content_after.lower():
        print("✅ Incremental knowledge verified")
    else:
        print("❌ Incremental knowledge not found")
        return False
    
    # Test 5: Search for the note
    print("\n🔍 Test 5: Searching notes")
    search_result = await plugin._search_notes({
        "query": "memory recall",
        "max_results": 5,
        "search_type": "content"
    })
    
    if not search_result.get("success"):
        print(f"❌ Search failed: {search_result.get('error')}")
        return False
    
    results = search_result.get("results", [])
    if any("memory recall" in str(result).lower() for result in results):
        print("✅ Search successful")
    else:
        print(f"❌ Search didn't find note. Results: {len(results)}")
    
    # Test 6: Test writer role policies
    print("\n🎭 Test 6: Writer role policies")
    
    # Test that plugin respects writer role
    context = {"agent_role": "writer"}
    execute_result = await plugin.execute("obsidian_read", {"path": note_path, "max_lines": 5}, context)
    
    if execute_result.get("success"):
        print("✅ Writer role can read notes")
    else:
        print(f"❌ Writer role read failed: {execute_result.get('error')}")
    
    # Test non-writer role warning
    non_writer_context = {"agent_role": "researcher"}
    await plugin.execute("obsidian_read", {"path": note_path, "max_lines": 5}, non_writer_context)
    print("✅ Non-writer role triggers warning (expected)")
    
    print("\n🎉 All tests passed!")
    return True


async def test_agent_role_integration():
    """Test agent role integration with tool routing."""
    print("\n🔗 Testing Agent Role Integration")
    
    # Import necessary modules
    from core.agent_role_manager import AgentRoleManager
    from core.routing.tool_catalog import ToolCatalog
    from core.tool_manager import ToolManager # analyzer: ignore # analyzer: ignore
    
    # Create mock tool manager
    tool_manager = ToolManager()
    
    # Load agent roles
    role_manager = AgentRoleManager()
    
    # Get writer role
    writer_role = role_manager.get_role("writer")
    if not writer_role:
        print("❌ Writer role not found in configuration")
        # Verify configuration loaded correctly
    print("✅ Writer role loaded: writer")
    print(f"  - Description: {writer_role.description}")
    print(f"  - Primary agent: {writer_role.primary}")
    if writer_role.fallback:
        print(f"  - Fallback agent: {writer_role.fallback}")
    print(f"  - Allowed tools: {list(writer_role.tools.allow)}")
    
    # Test tool catalog filtering
    tool_catalog = ToolCatalog(tool_manager)
    
    # Get tools for writer role
    writer_tools = tool_catalog.get_tools_for_session(
        session_id="test-session",
        agent_role="writer"
    )
    
    print(f"✅ Tool catalog returns {len(writer_tools)} tools for writer role")
    
    # Check if writer memory tools are included
    writer_tool_names = [tool.get("name", "") for tool in writer_tools]
    if "obsidian_read" in writer_tool_names or "obsidian_write" in writer_tool_names:
        print("✅ Writer memory tools available in catalog")
    else:
        print("⚠️  Writer memory tools not in catalog (may need plugin registration)")
    
    return True


async def main():
    """Run all tests."""
    print("=" * 60)
    print("Writer Agent Memory System Test")
    print("=" * 60)
    
    success = True
    
    try:
        # Test basic memory functionality
        if not await test_writer_memory():
            success = False
        
        # Test agent role integration
        if not await test_agent_role_integration():
            success = False
            
    except Exception as e:
        print(f"❌ Test failed with exception: {e}")
        import traceback
        traceback.print_exc()
        success = False
    
    print("\n" + "=" * 60)
    if success:
        print("✅ All tests passed!")
        return 0
    else:
        print("❌ Some tests failed")
        return 1


if __name__ == "__main__":
    exit_code = asyncio.run(main())
    sys.exit(exit_code)