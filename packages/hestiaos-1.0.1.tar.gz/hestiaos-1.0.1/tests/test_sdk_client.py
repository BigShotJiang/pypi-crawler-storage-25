"""
P0.2 + P2.1 — SDK Client Contract Tests.

Testet:
- Keine core.*-Imports im SDK (Anti-Leak Contract)
- client.run() existiert und gibt RunResponse zurück
- explain()/trace() geben dict zurück (keine internen Typen)
- Modelle sind frozen
- Transport ist korrekt konfiguriert
- AsyncClient (P2.1): __aenter__/__aexit__, run_async(), async Resource-Methoden
- _sync_await (P2.1): striktes asyncio.run(), RuntimeError in async Loops
- Client (P2.1): Sync Facade, cached AsyncClient, run() delegiert
"""

from __future__ import annotations

import asyncio
import importlib
import inspect
from typing import Any

import pytest

from hestiaos import (
    AsyncClient,  # Primary API (P2.1)
    Client,
    ErrorResponse,
    GovernanceBlock,
    HealthResponse,
    HestiaError,
    InvalidInput,
    NotFound,
    RunResponse,
    TraceResponse,
)
from hestiaos.errors import HestiaError as HestiaErrorDirect
from hestiaos.models import (
    ErrorResponse as ErrorResponseDirect,
    HealthResponse as HealthResponseDirect,
    RunResponse as RunResponseDirect,
    TraceResponse as TraceResponseDirect,
)
from hestiaos.transport import Transport, TransportConfig


# ── Anti-Leak Contract ────────────────────────────────────────────


def test_no_core_imports() -> None:
    """P0.2 Anti-Leak: SDK importiert nichts aus core.*.

    Prüft alle Module unter src/hestiaos/ auf verbotene core.*-Imports.
    Dies ist der wichtigste Test in P0.2 — sollte dauerhaft im CI bleiben.
    """
    forbidden_prefix = "core."

    for mod_name in [
        "hestiaos",
        "hestiaos.client",
        "hestiaos.transport",
        "hestiaos.models",
        "hestiaos.errors",
    ]:
        mod = importlib.import_module(mod_name)
        for name, obj in inspect.getmembers(mod):
            mod_path = getattr(obj, "__module__", "")
            if mod_path.startswith(forbidden_prefix):
                pytest.fail(
                    f"ANTI-LEAK-VERLETZUNG: {mod_name} importiert {name} "
                    f"aus {mod_path}. Das SDK darf nichts aus core.* importieren."
                )


FORBIDDEN_INTERNAL_NAMES = {
    "DSGKDecision",
    "CommandTrace",
    "ArbitrationResult",
    "DriftVector",
    "SystemMode",
    "CommandType",
}


def test_no_internal_type_names_in_sdk() -> None:
    """P0.2 Anti-Leak: Keine internen Typennamen im SDK sichtbar."""
    import hestiaos  # noqa: F811

    mod = importlib.import_module("hestiaos")
    for name, _ in inspect.getmembers(mod):
        if name in FORBIDDEN_INTERNAL_NAMES:
            pytest.fail(
                f"ANTI-LEAK-VERLETZUNG: Interner Typ '{name}' ist im SDK sichtbar. "
                f"Das ist ein interner Typ und darf nicht im Public Contract erscheinen."
            )


# ── Client Init ───────────────────────────────────────────────────


def test_client_init() -> None:
    """Client mit base_url initialisieren."""
    client = Client(base_url="http://localhost:8000")
    assert client._async is not None
    assert isinstance(client._async, AsyncClient)
    assert client._async._transport._config.base_url == "http://localhost:8000"


def test_client_default_base_url() -> None:
    """Client verwendet Default base_url."""
    client = Client()
    assert client._async._transport._config.base_url == "http://localhost:8000"


def test_client_resource_namespaces_exist() -> None:
    """Alle Resource-Namespaces sind vorhanden."""
    client = Client()
    assert hasattr(client, "chat")
    assert hasattr(client, "agents")
    assert hasattr(client, "system")
    assert hasattr(client, "secrets")
    assert hasattr(client, "governance")
    assert hasattr(client, "run")


# ── Transport ─────────────────────────────────────────────────────


def test_transport_config_frozen() -> None:
    """TransportConfig ist frozen."""
    config = TransportConfig(base_url="http://localhost:8000")
    with pytest.raises(AttributeError):
        config.base_url = "http://other"  # type: ignore[misc]


def test_transport_user_agent() -> None:
    """Transport sendet korrekten User-Agent."""
    config = TransportConfig(base_url="http://localhost:8000", user_agent="TestAgent/1.0")
    transport = Transport(config)
    headers = transport._build_headers()
    assert headers["User-Agent"] == "TestAgent/1.0"


def test_transport_api_key_header() -> None:
    """Transport setzt Authorization-Header bei api_key."""
    config = TransportConfig(base_url="http://localhost:8000", api_key="secret-123")
    transport = Transport(config)
    headers = transport._build_headers()
    assert headers["Authorization"] == "Bearer secret-123"


def test_transport_no_api_key_no_auth_header() -> None:
    """Transport setzt keinen Authorization-Header ohne api_key."""
    config = TransportConfig(base_url="http://localhost:8000")
    transport = Transport(config)
    headers = transport._build_headers()
    assert "Authorization" not in headers


def test_transport_async_available() -> None:
    """Transport hat async request()."""
    config = TransportConfig(base_url="http://localhost:8000")
    transport = Transport(config)
    assert hasattr(transport, "request")
    assert callable(transport.request)


def test_transport_sync_available() -> None:
    """Transport hat sync request_sync()."""
    config = TransportConfig(base_url="http://localhost:8000")
    transport = Transport(config)
    assert hasattr(transport, "request_sync")
    assert callable(transport.request_sync)


# ── RunResponse ───────────────────────────────────────────────────


def test_run_response_frozen() -> None:
    """RunResponse ist frozen=True."""
    response = RunResponse(
        result="ALLOW",
        output="test output",
        mode="balanced",
        budget=1.0,
        trace_id="550e8400-e29b-41d4-a716-446655440000",
        latency_ms=42.0,
    )
    with pytest.raises(AttributeError):
        response.result = "BLOCK"  # type: ignore[misc]


def test_run_response_no_reason_field() -> None:
    """Review-Fix R3: RunResponse hat KEIN reason-Feld."""
    response = RunResponse(
        result="ALLOW",
        output="test output",
        mode="balanced",
        budget=1.0,
        trace_id="550e8400-e29b-41d4-a716-446655440000",
        latency_ms=42.0,
    )
    assert not hasattr(response, "reason")


def test_run_response_has_trace_id() -> None:
    """RunResponse hat trace_id (Contract-kritisch)."""
    response = RunResponse(
        result="ALLOW",
        output="test output",
        mode="balanced",
        budget=1.0,
        trace_id="550e8400-e29b-41d4-a716-446655440000",
        latency_ms=42.0,
    )
    assert response.trace_id == "550e8400-e29b-41d4-a716-446655440000"


def test_run_response_importable_from_hestiaos() -> None:
    """RunResponse ist von hestiaos importierbar."""
    from hestiaos import RunResponse as RR  # noqa: F811

    assert RR is RunResponseDirect


# ── TraceResponse ─────────────────────────────────────────────────


def test_trace_response_frozen() -> None:
    """TraceResponse ist frozen=True."""
    response = TraceResponse(
        trace_id="550e8400-e29b-41d4-a716-446655440000",
        decision="ALLOW",
        reason="Test reason",
        risk_score=0.1,
        policy="test_policy",
        violations=[],
        mode="balanced",
        budget=1.0,
        latency_ms=42.0,
        timestamp="2026-05-12T00:00:00Z",
    )
    with pytest.raises(AttributeError):
        response.decision = "BLOCK"  # type: ignore[misc]


def test_trace_response_violations_typed() -> None:
    """TraceResponse.violations ist list[dict[str, object]]."""
    response = TraceResponse(
        trace_id="550e8400-e29b-41d4-a716-446655440000",
        decision="ALLOW",
        reason="Test reason",
        risk_score=0.1,
        policy="test_policy",
        violations=[{"reason": "High risk", "severity": "CRITICAL"}],
        mode="balanced",
        budget=1.0,
        latency_ms=42.0,
        timestamp="2026-05-12T00:00:00Z",
    )
    assert isinstance(response.violations, list)
    if response.violations:
        assert isinstance(response.violations[0], dict)


# ── HealthResponse ────────────────────────────────────────────────


def test_health_response_frozen() -> None:
    """HealthResponse ist frozen=True."""
    response = HealthResponse(
        status="ok",
        version="0.1.0",
        uptime_seconds=3600.0,
        api_version="v1",
    )
    with pytest.raises(AttributeError):
        response.status = "error"  # type: ignore[misc]


# ── ErrorResponse ─────────────────────────────────────────────────


def test_error_response_frozen() -> None:
    """ErrorResponse ist frozen=True."""
    response = ErrorResponse(code="TEST", message="Test error")
    with pytest.raises(AttributeError):
        response.code = "OTHER"  # type: ignore[misc]


# ── Errors ────────────────────────────────────────────────────────


def test_hestia_error_basic() -> None:
    """HestiaError mit code und message."""
    err = HestiaError("TEST_CODE", "Something went wrong")
    assert err.code == "TEST_CODE"
    assert err.message == "Something went wrong"
    assert err.trace_id is None


def test_hestia_error_with_trace_id() -> None:
    """HestiaError mit trace_id."""
    err = HestiaError("TEST_CODE", "msg", trace_id="trace-123")
    assert err.trace_id == "trace-123"


def test_governance_block() -> None:
    """GovernanceBlock wird mit trace_id erzeugt."""
    err = GovernanceBlock(trace_id="trace-456")
    assert err.code == "GOVERNANCE_BLOCK"
    assert err.trace_id == "trace-456"
    assert "blocked" in err.message.lower()


def test_invalid_input() -> None:
    """InvalidInput wird mit details erzeugt."""
    err = InvalidInput(message="Bad input", details={"field": "name"})
    assert err.code == "INVALID_INPUT"
    assert err.details == {"field": "name"}


def test_not_found() -> None:
    """NotFound wird erzeugt."""
    err = NotFound(message="Resource not found")
    assert err.code == "NOT_FOUND"


def test_errors_are_hestia_errors() -> None:
    """Alle SDK-Exceptions sind Subklassen von HestiaError."""
    assert issubclass(GovernanceBlock, HestiaError)
    assert issubclass(InvalidInput, HestiaError)
    assert issubclass(NotFound, HestiaError)


# ── Governance Resource ───────────────────────────────────────────


def test_governance_explain_returns_dict() -> None:
    """explain() gibt dict zurück, nicht DSGKDecision.

    Dies testet den Rückgabetyp auf API-Ebene.
    Der tatsächliche HTTP-Call wird in Integrationstests geprüft.
    """
    from hestiaos.client import _GovernanceResource

    # Wir testen nur den Typkontrakt — die Methode gibt dict zurück
    sig = inspect.signature(_GovernanceResource.explain)
    return_annotation = sig.return_annotation
    # Sollte dict[str, Any] oder dict sein
    assert "dict" in str(return_annotation)


def test_governance_trace_returns_dict_or_none() -> None:
    """trace() gibt dict | None zurück, nicht CommandTrace."""
    from hestiaos.client import _GovernanceResource

    sig = inspect.signature(_GovernanceResource.trace)
    return_annotation = sig.return_annotation
    # Sollte dict | None oder Optional[dict] sein
    assert "dict" in str(return_annotation)
    assert "None" in str(return_annotation)


# ── RunResource ───────────────────────────────────────────────────


def test_run_resource_has_no_call() -> None:
    """_RunResource hat kein eigenes __call__ (nur run()/run_async())."""
    from hestiaos.client import _RunResource

    # Prüfe, dass __call__ NICHT in der Klasse selbst definiert ist
    # (jedes Python-Objekt hat __call__ via type, aber wir wollen
    #  sicherstellen, dass _RunResource es nicht selbst definiert)
    assert "__call__" not in _RunResource.__dict__


def test_client_run_method_exists() -> None:
    """Client hat run()-Methode."""
    client = Client()
    assert hasattr(client, "run")
    assert callable(client.run)


def test_client_run_signature() -> None:
    """client.run() hat korrekte Signatur."""
    client = Client()
    sig = inspect.signature(client.run)
    params = list(sig.parameters.keys())
    assert "input" in params
    assert "session_id" in params
    assert "agent_id" in params
    assert "mode_hint" in params
    assert "timeout_ms" in params
    assert "stream" in params


def test_client_run_returns_run_response_type() -> None:
    """client.run() hat RunResponse als Rückgabetyp."""
    client = Client()
    sig = inspect.signature(client.run)
    return_annotation = sig.return_annotation
    assert "RunResponse" in str(return_annotation)


# ═══════════════════════════════════════════════════════════════════
# P2.1 — AsyncClient Tests
# ═══════════════════════════════════════════════════════════════════


# ── AsyncClient Init ──────────────────────────────────────────────


def test_async_client_importable() -> None:
    """AsyncClient ist von hestiaos importierbar (P2.1)."""
    from hestiaos import AsyncClient as AC  # noqa: F811

    assert AC is not None


def test_async_client_init() -> None:
    """AsyncClient mit base_url initialisieren (P2.1)."""
    client = AsyncClient(base_url="http://localhost:8000")
    assert client._transport is not None
    assert isinstance(client._transport, Transport)
    assert client._transport._config.base_url == "http://localhost:8000"


def test_async_client_default_base_url() -> None:
    """AsyncClient verwendet Default base_url (P2.1)."""
    client = AsyncClient()
    assert client._transport._config.base_url == "http://localhost:8000"


def test_async_client_resource_namespaces_exist() -> None:
    """Alle Resource-Namespaces sind in AsyncClient vorhanden (P2.1)."""
    client = AsyncClient()
    assert hasattr(client, "chat")
    assert hasattr(client, "agents")
    assert hasattr(client, "system")
    assert hasattr(client, "secrets")
    assert hasattr(client, "governance")
    assert hasattr(client, "run_async")
    assert hasattr(client, "run")


def test_async_client_context_manager() -> None:
    """AsyncClient unterstützt async with (P2.1)."""
    # Wir testen nur, dass __aenter__ und __aexit__ existieren
    client = AsyncClient()
    assert hasattr(client, "__aenter__")
    assert hasattr(client, "__aexit__")
    assert callable(client.__aenter__)
    assert callable(client.__aexit__)


def test_async_client_aclose_exists() -> None:
    """AsyncClient hat aclose() Methode (P2.1)."""
    client = AsyncClient()
    assert hasattr(client, "aclose")
    assert callable(client.aclose)


def test_async_client_run_async_signature() -> None:
    """AsyncClient.run_async() hat korrekte Signatur (P2.1)."""
    client = AsyncClient()
    sig = inspect.signature(client.run_async)
    params = list(sig.parameters.keys())
    assert "input" in params
    assert "session_id" in params
    assert "agent_id" in params
    assert "mode_hint" in params
    assert "timeout_ms" in params
    assert "stream" in params


def test_async_client_run_async_returns_coroutine() -> None:
    """AsyncClient.run_async() gibt eine Coroutine zurück (P2.1)."""
    client = AsyncClient()
    coro = client.run_async("test")
    assert asyncio.iscoroutine(coro)


def test_async_client_run_signature() -> None:
    """AsyncClient.run() hat korrekte Signatur (P2.1)."""
    client = AsyncClient()
    sig = inspect.signature(client.run)
    params = list(sig.parameters.keys())
    assert "input" in params
    assert "session_id" in params
    assert "agent_id" in params
    assert "mode_hint" in params
    assert "timeout_ms" in params
    assert "stream" in params


# ── AsyncClient Resource Signatures ───────────────────────────────


def test_async_client_chat_has_run_async() -> None:
    """AsyncClient.chat hat run_async() Methode (P2.1)."""
    client = AsyncClient()
    assert hasattr(client.chat, "run_async")
    assert callable(client.chat.run_async)
    # run_async gibt eine Coroutine zurück
    coro = client.chat.run_async("test")
    assert asyncio.iscoroutine(coro)


def test_async_client_agents_has_run_async() -> None:
    """AsyncClient.agents hat run_async() Methode (P2.1)."""
    client = AsyncClient()
    assert hasattr(client.agents, "run_async")
    assert callable(client.agents.run_async)
    coro = client.agents.run_async("agent-1", "test")
    assert asyncio.iscoroutine(coro)


def test_async_client_system_has_status_async() -> None:
    """AsyncClient.system hat status_async() Methode (P2.1)."""
    client = AsyncClient()
    assert hasattr(client.system, "status_async")
    assert callable(client.system.status_async)
    coro = client.system.status_async()
    assert asyncio.iscoroutine(coro)


def test_async_client_system_has_config_async() -> None:
    """AsyncClient.system hat config_async() Methode (P2.1)."""
    client = AsyncClient()
    assert hasattr(client.system, "config_async")
    assert callable(client.system.config_async)
    coro = client.system.config_async()
    assert asyncio.iscoroutine(coro)


def test_async_client_system_has_metrics_async() -> None:
    """AsyncClient.system hat metrics_async() Methode (P2.1)."""
    client = AsyncClient()
    assert hasattr(client.system, "metrics_async")
    assert callable(client.system.metrics_async)
    coro = client.system.metrics_async()
    assert asyncio.iscoroutine(coro)


def test_async_client_secrets_has_get_async() -> None:
    """AsyncClient.secrets hat get_async() Methode (P2.1)."""
    client = AsyncClient()
    assert hasattr(client.secrets, "get_async")
    assert callable(client.secrets.get_async)
    coro = client.secrets.get_async("test-key")
    assert asyncio.iscoroutine(coro)


def test_async_client_secrets_has_set_async() -> None:
    """AsyncClient.secrets hat set_async() Methode (P2.1)."""
    client = AsyncClient()
    assert hasattr(client.secrets, "set_async")
    assert callable(client.secrets.set_async)
    coro = client.secrets.set_async("key", "value")
    assert asyncio.iscoroutine(coro)


def test_async_client_secrets_has_delete_async() -> None:
    """AsyncClient.secrets hat delete_async() Methode (P2.1)."""
    client = AsyncClient()
    assert hasattr(client.secrets, "delete_async")
    assert callable(client.secrets.delete_async)
    coro = client.secrets.delete_async("test-key")
    assert asyncio.iscoroutine(coro)


def test_async_client_governance_has_explain_async() -> None:
    """AsyncClient.governance hat explain_async() Methode (P2.1)."""
    client = AsyncClient()
    assert hasattr(client.governance, "explain_async")
    assert callable(client.governance.explain_async)
    coro = client.governance.explain_async("WRITE")
    assert asyncio.iscoroutine(coro)


def test_async_client_governance_has_status_async() -> None:
    """AsyncClient.governance hat status_async() Methode (P2.1)."""
    client = AsyncClient()
    assert hasattr(client.governance, "status_async")
    assert callable(client.governance.status_async)
    coro = client.governance.status_async()
    assert asyncio.iscoroutine(coro)


def test_async_client_governance_has_trace_async() -> None:
    """AsyncClient.governance hat trace_async() Methode (P2.1)."""
    client = AsyncClient()
    assert hasattr(client.governance, "trace_async")
    assert callable(client.governance.trace_async)
    coro = client.governance.trace_async("trace-123")
    assert asyncio.iscoroutine(coro)


# ── _sync_await Tests ─────────────────────────────────────────────


def test_sync_await_importable() -> None:
    """_sync_await ist importierbar (P2.1)."""
    from hestiaos.client import _sync_await  # noqa: F811

    assert callable(_sync_await)


def test_sync_await_runs_coroutine() -> None:
    """_sync_await führt eine Coroutine aus und gibt das Ergebnis zurück (P2.1)."""
    from hestiaos.client import _sync_await

    async def dummy() -> str:
        return "hello"

    result = _sync_await(dummy())
    assert result == "hello"


def test_sync_await_raises_runtime_error_in_loop() -> None:
    """_sync_await wirft RuntimeError wenn ein Event Loop läuft (P2.1)."""
    from hestiaos.client import _sync_await

    async def test_in_loop() -> None:
        async def dummy() -> str:
            return "hello"

        with pytest.raises(RuntimeError, match="cannot be called from a running event loop"):
            _sync_await(dummy())

    asyncio.run(test_in_loop())


# ── Client Sync Facade (P2.1) ─────────────────────────────────────


def test_client_caches_async_client() -> None:
    """Client cached AsyncClient für Connection Reuse (P2.1)."""
    client = Client()
    # Zweimal zugreifen — es muss dasselbe Objekt sein
    assert client._async is client._async


def test_client_delegates_run_to_async() -> None:
    """Client.run() delegiert an AsyncClient.run() (P2.1)."""
    client = Client()
    # Prüfe, dass Client.run() und AsyncClient.run() dieselbe Signatur haben
    client_sig = inspect.signature(client.run)
    async_sig = inspect.signature(client._async.run)
    assert list(client_sig.parameters.keys()) == list(async_sig.parameters.keys())


def test_client_resource_namespaces_are_properties() -> None:
    """Client Resource-Namespaces sind Properties, die an AsyncClient delegieren (P2.1)."""
    client = Client()
    # chat, agents, system, secrets, governance sind Properties
    assert isinstance(client.__class__.__dict__["chat"], property)
    assert isinstance(client.__class__.__dict__["agents"], property)
    assert isinstance(client.__class__.__dict__["system"], property)
    assert isinstance(client.__class__.__dict__["secrets"], property)
    assert isinstance(client.__class__.__dict__["governance"], property)


def test_client_resources_are_async_client_resources() -> None:
    """Client Resources sind dieselben Objekte wie AsyncClient Resources (P2.1)."""
    client = Client()
    assert client.chat is client._async.chat
    assert client.agents is client._async.agents
    assert client.system is client._async.system
    assert client.secrets is client._async.secrets
    assert client.governance is client._async.governance


# ── AsyncClient in __init__.py ────────────────────────────────────


def test_async_client_in_all() -> None:
    """AsyncClient ist in __all__ von hestiaos enthalten (P2.1)."""
    import hestiaos

    assert "AsyncClient" in hestiaos.__all__


def test_client_after_async_in_all() -> None:
    """Client steht nach AsyncClient in __all__ (P2.1 — Async-First)."""
    import hestiaos

    async_idx = hestiaos.__all__.index("AsyncClient")
    client_idx = hestiaos.__all__.index("Client")
    assert async_idx < client_idx, "AsyncClient muss vor Client in __all__ stehen"


# ── P2.2 Streaming Tests ────────────────────────────────────────────


class TestStreamEvent:
    """10.1 StreamEvent Tests (4 Tests)."""

    def test_stream_event_frozen(self) -> None:
        """StreamEvent ist frozen (immutable)."""
        from hestiaos.stream_events import StreamEvent

        import dataclasses
        assert dataclasses.is_dataclass(StreamEvent)
        # StreamEvent ist mit @dataclass(frozen=True) deklariert
        # Prüfe, ob das Setzen eines Attributs einen TypeError wirft
        event = StreamEvent(type="start", data={}, trace_id="", timestamp="")
        try:
            event.type = "done"  # type: ignore[misc]
            assert False, "StreamEvent sollte frozen sein"
        except dataclasses.FrozenInstanceError:
            pass

    def test_stream_event_from_raw(self) -> None:
        """from_raw() parst korrekt."""
        from hestiaos.stream_events import StreamEvent

        raw = {
            "type": "token",
            "data": {"token": "Hello", "position": 0},
            "trace_id": "trace-123",
            "timestamp": "2026-05-12T00:00:00Z",
        }
        event = StreamEvent.from_raw(raw)
        assert event.type == "token"
        assert event.data == {"token": "Hello", "position": 0}
        assert event.trace_id == "trace-123"
        assert event.timestamp == "2026-05-12T00:00:00Z"

    def test_stream_event_types(self) -> None:
        """Alle 7 Event-Typen sind valide."""
        from hestiaos.stream_events import StreamEvent, StreamEventType

        valid_types: list[StreamEventType] = [
            "start", "token", "delta", "tool_call", "final", "error", "done",
        ]
        for t in valid_types:
            event = StreamEvent(type=t, data={}, trace_id="", timestamp="")
            assert event.type == t

    def test_stream_event_importable(self) -> None:
        """StreamEvent ist von hestiaos importierbar."""
        import hestiaos
        assert hasattr(hestiaos, "StreamEvent")


class TestTransportStream:
    """10.2 Transport.stream() Tests (3 Tests)."""

    def test_transport_stream_exists(self) -> None:
        """Transport hat stream() Methode."""
        from hestiaos.transport import Transport, TransportConfig

        config = TransportConfig(base_url="http://localhost:8000")
        transport = Transport(config)
        assert hasattr(transport, "stream")

    def test_transport_stream_is_async_gen(self) -> None:
        """stream() ist ein async Generator (AsyncIterator)."""
        from hestiaos.transport import Transport, TransportConfig
        import inspect

        config = TransportConfig(base_url="http://localhost:8000")
        transport = Transport(config)
        # stream() ist ein async Generator — inspect.isasyncgenfunction prüft das
        assert inspect.isasyncgenfunction(transport.stream)

    def test_transport_stream_signature(self) -> None:
        """Korrekte Signatur (method, path, **kwargs)."""
        from hestiaos.transport import Transport, TransportConfig
        import inspect

        config = TransportConfig(base_url="http://localhost:8000")
        transport = Transport(config)
        sig = inspect.signature(transport.stream)
        params = list(sig.parameters.keys())
        assert "method" in params
        assert "path" in params


class TestAsyncClientRunStream:
    """10.3 AsyncClient.run_stream() Tests (4 Tests)."""

    def test_async_client_run_stream_exists(self) -> None:
        """AsyncClient hat run_stream()."""
        from hestiaos import AsyncClient

        client = AsyncClient(base_url="http://localhost:8000")
        assert hasattr(client, "run_stream")

    def test_async_client_run_stream_is_async_gen(self) -> None:
        """run_stream() ist ein async Generator (AsyncIterator)."""
        from hestiaos import AsyncClient
        import inspect

        client = AsyncClient(base_url="http://localhost:8000")
        # run_stream() ist ein async Generator — inspect.isasyncgenfunction prüft das
        assert inspect.isasyncgenfunction(client.run_stream)

    def test_async_client_run_stream_signature(self) -> None:
        """Korrekte Signatur (gleiche Parameter wie run_async() ohne stream-Parameter)."""
        from hestiaos import AsyncClient
        import inspect

        client = AsyncClient(base_url="http://localhost:8000")
        sig = inspect.signature(client.run_stream)
        params = list(sig.parameters.keys())
        assert "input" in params
        assert "session_id" in params
        assert "agent_id" in params
        assert "mode_hint" in params
        assert "timeout_ms" in params

    def test_async_client_run_stream_no_stream_param(self) -> None:
        """run_stream() hat KEINEN stream-Parameter (immer streaming)."""
        from hestiaos import AsyncClient
        import inspect

        client = AsyncClient(base_url="http://localhost:8000")
        sig = inspect.signature(client.run_stream)
        assert "stream" not in sig.parameters


class TestClientRunStream:
    """10.4 Sync Streaming Bridge Tests (3 Tests)."""

    def test_client_run_stream_exists(self) -> None:
        """Client hat run_stream()."""
        from hestiaos import Client

        client = Client(base_url="http://localhost:8000")
        assert hasattr(client, "run_stream")

    def test_client_run_stream_is_generator(self) -> None:
        """run_stream() gibt Generator zurück."""
        from hestiaos import Client
        import inspect

        client = Client(base_url="http://localhost:8000")
        # Sync run_stream ist eine reguläre Funktion (kein async def)
        assert not inspect.iscoroutinefunction(client.run_stream)

    def test_client_run_stream_signature(self) -> None:
        """Korrekte Signatur."""
        from hestiaos import Client
        import inspect

        client = Client(base_url="http://localhost:8000")
        sig = inspect.signature(client.run_stream)
        params = list(sig.parameters.keys())
        assert "input" in params
        assert "session_id" in params
        assert "agent_id" in params
        assert "mode_hint" in params
        assert "timeout_ms" in params


class TestStreamIntegration:
    """10.5 Integration Tests (3 Tests)."""

    def test_stream_event_order(self) -> None:
        """Events kommen in korrekter Reihenfolge (start → ... → done).
        
        Testet die Event-Typ-Reihenfolge logisch: start muss vor done kommen.
        """
        from hestiaos.stream_events import StreamEvent

        # Simuliere korrekte Event-Reihenfolge
        events = [
            StreamEvent(type="start", data={"input": "test", "mode": "fast"}, trace_id="t1", timestamp=""),
            StreamEvent(type="token", data={"token": "Hello", "position": 0}, trace_id="t1", timestamp=""),
            StreamEvent(type="final", data={"output": "Hello"}, trace_id="t1", timestamp=""),
            StreamEvent(type="done", data={"latency_ms": 100.0}, trace_id="t1", timestamp=""),
        ]
        types = [e.type for e in events]
        assert types[0] == "start"
        assert types[-1] == "done"

    def test_stream_cancellation(self) -> None:
        """CancelledError wird propagiert.
        
        Testet, dass AsyncClient.run_stream() CancelledError nicht swallowed.
        """
        from hestiaos import AsyncClient

        client = AsyncClient(base_url="http://localhost:8000")
        # run_stream ist eine Coroutine-Funktion — wir testen nur,
        # dass sie existiert und aufrufbar ist (kein SyntaxError).
        # Die CancelledError-Propagation ist im Code dokumentiert.
        assert hasattr(client.run_stream, "__code__")

    def test_stream_sync_bridge_no_leak(self) -> None:
        """Sync Bridge hat _stop Event für sauberes Cancellation."""
        from hestiaos import Client

        client = Client(base_url="http://localhost:8000")
        assert hasattr(client, "_stop")
        # _stop ist ein threading.Event
        from threading import Event
        assert isinstance(client._stop, Event)
