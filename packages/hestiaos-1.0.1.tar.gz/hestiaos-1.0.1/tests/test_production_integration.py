import asyncio
import httpx

async def test_all_services():
    services = {
        "core": "http://localhost:8000/health",
        "mcp_proxy": "http://localhost:8090/health",
        "frontend": "http://localhost:8081"
    }
    
    async with httpx.AsyncClient() as client:
        for name, url in services.items():
            try:
                resp = await client.get(url, timeout=2.0)
                print(f"✅ {name}: {resp.status_code}")
            except Exception as e:
                print(f"❌ {name}: {e}")

if __name__ == "__main__":
    asyncio.run(test_all_services())
