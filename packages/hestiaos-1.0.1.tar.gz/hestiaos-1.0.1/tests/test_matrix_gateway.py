import asyncio
import unittest
from unittest.mock import AsyncMock, patch, MagicMock
from plugins.matrix_gateway import MatrixGatewayPlugin

class TestMatrixGateway(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.plugin = MatrixGatewayPlugin()
        # Mock configuration
        self.plugin.rooms = {"!test:matrix.org": {"alias": "main", "allow_tools": True}}
        self.plugin.user_id = "@hestia:matrix.org"
        self.plugin.client = AsyncMock()

    @patch("httpx.AsyncClient.post")
    async def test_trigger_logic(self, mock_post):
        # Setup mock chat response
        mock_post.return_value = MagicMock(status_code=200)
        mock_post.return_value.json.return_value = {"response": "Hello Matrix!"}
        
        # Mock room and event
        mock_room = MagicMock()
        mock_room.room_id = "!test:matrix.org"
        
        mock_event = MagicMock()
        mock_event.sender = "@user:matrix.org"
        
        # Test case 1: No trigger
        mock_event.body = "hallo"
        await self.plugin._on_message(mock_room, mock_event)
        self.plugin.client.room_send.assert_not_called()
        
        # Test case 2: Trigger @hestia
        mock_event.body = "@hestia status"
        await self.plugin._on_message(mock_room, mock_event)
        
        # Allow background tasks to run
        await asyncio.sleep(0.1)
        
        # Verify message was sent back
        self.plugin.client.room_send.assert_called_with(
            room_id="!test:matrix.org",
            message_type="m.room.message",
            content={"msgtype": "m.text", "body": "Hello Matrix!"}
        )

    async def test_execute_tool(self):
        # Test send_matrix_message tool
        self.plugin.client.room_send.return_value = True
        
        result = await self.plugin.execute(
            "send_matrix_message", 
            {"room": "!test:matrix.org", "message": "Tool test"},
            {}
        )
        self.assertTrue(result["success"])
        self.plugin.client.room_send.assert_called()

if __name__ == "__main__":
    unittest.main()
