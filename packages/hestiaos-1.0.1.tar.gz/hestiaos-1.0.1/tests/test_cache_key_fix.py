#!/usr/bin/env python3
"""Test script to verify cache key fix for different inputs."""

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from core.cache.key_builder import CacheKeyBuilder, CacheLayer, KeyVersion

def test_cache_key_fix():
    """Test that different inputs produce different cache keys."""
    print("Testing cache key fix for different inputs...")
    
    # Create a key builder
    builder = CacheKeyBuilder(
        default_layer=CacheLayer.HSP,
        default_version=KeyVersion.V2,
        hash_algorithm="sha256"
    )
    
    # Test case 1: Different IDs should produce different keys
    input1 = {"type": "test", "id": 123}
    input2 = {"type": "test", "id": 456}
    
    key1 = builder.build_key(input1)
    key2 = builder.build_key(input2)
    
    print(f"\nTest 1: Different IDs")
    print(f"Input 1: {input1}")
    print(f"Key 1: {key1}")
    print(f"Input 2: {input2}")
    print(f"Key 2: {key2}")
    print(f"Keys are different: {key1 != key2}")
    
    if key1 == key2:
        print("❌ FAIL: Different inputs produced same key!")
        return False
    else:
        print("✅ PASS: Different inputs produced different keys")
    
    # Test case 2: Different types should produce different keys
    input3 = {"type": "test", "id": 123}
    input4 = {"type": "other", "id": 123}
    
    key3 = builder.build_key(input3)
    key4 = builder.build_key(input4)
    
    print(f"\nTest 2: Different types")
    print(f"Input 3: {input3}")
    print(f"Key 3: {key3}")
    print(f"Input 4: {input4}")
    print(f"Key 4: {key4}")
    print(f"Keys are different: {key3 != key4}")
    
    if key3 == key4:
        print("❌ FAIL: Different types produced same key!")
        return False
    else:
        print("✅ PASS: Different types produced different keys")
    
    # Test case 3: Different values should produce different keys
    input5 = {"a": 1, "b": 2}
    input6 = {"a": 3, "b": 4}
    
    key5 = builder.build_key(input5)
    key6 = builder.build_key(input6)
    
    print(f"\nTest 3: Different values")
    print(f"Input 5: {input5}")
    print(f"Key 5: {key5}")
    print(f"Input 6: {input6}")
    print(f"Key 6: {key6}")
    print(f"Keys are different: {key5 != key6}")
    
    if key5 == key6:
        print("❌ FAIL: Different values produced same key!")
        return False
    else:
        print("✅ PASS: Different values produced different keys")
    
    # Test case 4: Same inputs should produce same keys
    input7 = {"type": "test", "id": 123}
    input8 = {"type": "test", "id": 123}
    
    key7 = builder.build_key(input7)
    key8 = builder.build_key(input8)
    
    print(f"\nTest 4: Same inputs")
    print(f"Input 7: {input7}")
    print(f"Key 7: {key7}")
    print(f"Input 8: {input8}")
    print(f"Key 8: {key8}")
    print(f"Keys are same: {key7 == key8}")
    
    if key7 != key8:
        print("❌ FAIL: Same inputs produced different keys!")
        return False
    else:
        print("✅ PASS: Same inputs produced same keys")
    
    # Test case 5: Ephemeral fields should be ignored
    input9 = {"type": "test", "id": 123, "timestamp": "2024-01-01T00:00:00Z", "request_id": "req-123"}
    input10 = {"type": "test", "id": 123, "timestamp": "2024-02-02T00:00:00Z", "request_id": "req-456"}
    
    key9 = builder.build_key(input9)
    key10 = builder.build_key(input10)
    
    print(f"\nTest 5: Ephemeral fields ignored")
    print(f"Input 9: {input9}")
    print(f"Key 9: {key9}")
    print(f"Input 10: {input10}")
    print(f"Key 10: {key10}")
    print(f"Keys are same (ephemeral fields ignored): {key9 == key10}")
    
    if key9 != key10:
        print("❌ FAIL: Same semantic content with different ephemeral fields produced different keys!")
        return False
    else:
        print("✅ PASS: Ephemeral fields correctly ignored")
    
    # Test case 6: Nested structures
    input11 = {"type": "test", "data": {"a": 1, "b": 2}}
    input12 = {"type": "test", "data": {"a": 1, "b": 3}}
    
    key11 = builder.build_key(input11)
    key12 = builder.build_key(input12)
    
    print(f"\nTest 6: Nested structures")
    print(f"Input 11: {input11}")
    print(f"Key 11: {key11}")
    print(f"Input 12: {input12}")
    print(f"Key 12: {key12}")
    print(f"Keys are different: {key11 != key12}")
    
    if key11 == key12:
        print("❌ FAIL: Different nested values produced same key!")
        return False
    else:
        print("✅ PASS: Different nested values produced different keys")
    
    print("\n" + "="*60)
    print("All tests passed! Cache key fix is working correctly.")
    print("="*60)
    return True

def test_normalize_context_directly():
    """Test the _normalize_context method directly."""
    print("\n\nTesting _normalize_context method directly...")
    
    builder = CacheKeyBuilder(
        default_layer=CacheLayer.HSP,
        default_version=KeyVersion.V2,
        hash_algorithm="sha256"
    )
    
    # Test the problematic case from earlier
    context1 = {"type": "test", "id": 123}
    context2 = {"type": "test", "id": 456}
    
    normalized1 = builder._normalize_context(context1)
    normalized2 = builder._normalize_context(context2)
    
    print(f"\nDirect normalization test:")
    print(f"Context 1: {context1}")
    print(f"Normalized 1: {normalized1}")
    print(f"Context 2: {context2}")
    print(f"Normalized 2: {normalized2}")
    
    if normalized1 == normalized2:
        print("❌ FAIL: Different contexts normalized to same dict!")
        return False
    else:
        print("✅ PASS: Different contexts normalized to different dicts")
    
    # Check that fields are preserved
    if "type" not in normalized1 or "id" not in normalized1:
        print(f"❌ FAIL: Fields missing from normalized1: {normalized1}")
        return False
    
    if normalized1["type"] != "test" or normalized1["id"] != 123:
        print(f"❌ FAIL: Values not preserved in normalized1: {normalized1}")
        return False
    
    print("✅ PASS: All fields correctly preserved")
    return True

if __name__ == "__main__":
    try:
        success1 = test_cache_key_fix()
        success2 = test_normalize_context_directly()
        
        if success1 and success2:
            print("\n🎉 All tests passed successfully!")
            sys.exit(0)
        else:
            print("\n❌ Some tests failed!")
            sys.exit(1)
    except Exception as e:
        print(f"\n❌ Error during testing: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)