"""
Tests for Workflow DSL — executor.py (WorkflowExecutor).
"""

import asyncio
import pytest
from unittest.mock import AsyncMock, MagicMock
from datetime import datetime

from core.workflow_dsl.executor import WorkflowExecutor, ExecutorError
from core.workflow_dsl.models import (
    WorkflowDefinition,
    StepDefinition,
    StepType,
    RetryConfig,
    ResourceBudget,
    TriggerConfig,
    TriggerType,
)
from core.workflow_dsl.context import WorkflowEvent, ExecutionContext, ExecutionStatus
from core.workflow_dsl.expressions import ExpressionEngine
from core.workflow_dsl.graph import GraphBuilder


class TestWorkflowExecutor:
    def setup_method(self):
        self.llm_executor = AsyncMock(return_value={"response": "llm output"})
        self.tool_executor = AsyncMock(return_value={"response": "tool output"})
        self.executor = WorkflowExecutor(
            llm_executor=self.llm_executor,
            tool_executor=self.tool_executor,
        )
        self.trigger_event = WorkflowEvent(
            type="webhook",
            payload={"code": "test"},
            source="test",
            correlation_id="corr-1",
        )

    def _make_workflow(self, steps, **kwargs) -> WorkflowDefinition:
        return WorkflowDefinition(
            name="test_wf",
            version="1.0.0",
            steps=steps,
            **kwargs,
        )

    def _llm_step(self, sid: str = "s1", name: str = "LLM Step") -> StepDefinition:
        return StepDefinition(id=sid, name=name, type=StepType.LLM)

    def _tool_step(self, sid: str = "t1", name: str = "Tool Step", tool: str = "plugin.test") -> StepDefinition:
        return StepDefinition(
            id=sid,
            name=name,
            type=StepType.TOOL,
            config={"tool": tool, "args": {}},
        )

    @pytest.mark.asyncio
    async def test_single_llm_step(self):
        wf = self._make_workflow([self._llm_step()])
        ctx = await self.executor.execute(wf, self.trigger_event)

        assert ctx.status == ExecutionStatus.COMPLETED
        assert ctx.steps_executed == 1
        assert len(ctx.trace) == 1
        assert ctx.trace[0].step_id == "s1"
        assert ctx.trace[0].status == ExecutionStatus.COMPLETED

    @pytest.mark.asyncio
    async def test_single_tool_step(self):
        wf = self._make_workflow([self._tool_step()])
        ctx = await self.executor.execute(wf, self.trigger_event)

        assert ctx.status == ExecutionStatus.COMPLETED
        assert ctx.steps_executed == 1
        self.tool_executor.assert_called_once()

    @pytest.mark.asyncio
    async def test_multiple_steps_sequential(self):
        steps = [self._llm_step("s1"), self._tool_step("t1"), self._llm_step("s2")]
        wf = self._make_workflow(steps)
        ctx = await self.executor.execute(wf, self.trigger_event)

        assert ctx.status == ExecutionStatus.COMPLETED
        assert ctx.steps_executed == 3
        assert len(ctx.trace) == 3

    @pytest.mark.asyncio
    async def test_no_llm_executor_raises(self):
        executor = WorkflowExecutor(tool_executor=self.tool_executor)
        wf = self._make_workflow([self._llm_step()])

        with pytest.raises(ExecutorError, match="no LLM executor configured"):
            await executor.execute(wf, self.trigger_event)

    @pytest.mark.asyncio
    async def test_no_tool_executor_raises(self):
        executor = WorkflowExecutor(llm_executor=self.llm_executor)
        wf = self._make_workflow([self._tool_step()])

        with pytest.raises(ExecutorError, match="no tool executor configured"):
            await executor.execute(wf, self.trigger_event)

    @pytest.mark.asyncio
    async def test_invalid_tool_reference_raises(self):
        step = StepDefinition(
            id="t1",
            name="Bad Tool",
            type=StepType.TOOL,
            config={"tool": "no_dot"},
        )
        wf = self._make_workflow([step])

        with pytest.raises(ExecutorError, match="invalid tool reference"):
            await self.executor.execute(wf, self.trigger_event)

    @pytest.mark.asyncio
    async def test_condition_step_true(self):
        condition = StepDefinition(
            id="cond",
            name="Check",
            type=StepType.CONDITION,
            config={"expression": "${trigger.payload.code}"},
            branches={
                "pass": [self._llm_step("on_pass")],
                "fail": [self._llm_step("on_fail")],
            },
        )
        wf = self._make_workflow([condition])
        ctx = await self.executor.execute(wf, self.trigger_event)

        assert ctx.status == ExecutionStatus.COMPLETED
        # Condition + pass branch executed (fail branch skipped)
        assert ctx.steps_executed >= 2

    @pytest.mark.asyncio
    async def test_condition_step_false(self):
        condition = StepDefinition(
            id="cond",
            name="Check",
            type=StepType.CONDITION,
            config={"expression": "${trigger.payload.nonexistent}"},
            branches={
                "pass": [self._llm_step("on_pass")],
                "fail": [self._llm_step("on_fail")],
            },
        )
        wf = self._make_workflow([condition])

        with pytest.raises(ExecutorError):
            await self.executor.execute(wf, self.trigger_event)

    @pytest.mark.asyncio
    async def test_condition_no_expression_raises(self):
        condition = StepDefinition(
            id="cond",
            name="Check",
            type=StepType.CONDITION,
            config={},
        )
        wf = self._make_workflow([condition])

        with pytest.raises(ExecutorError, match="no expression configured"):
            await self.executor.execute(wf, self.trigger_event)

    @pytest.mark.asyncio
    async def test_transform_step(self):
        transform = StepDefinition(
            id="trans",
            name="Transform",
            type=StepType.TRANSFORM,
            config={
                "mapping": {
                    "greeting": "Hello, ${trigger.payload.code}",
                }
            },
        )
        wf = self._make_workflow([transform])
        ctx = await self.executor.execute(wf, self.trigger_event)

        assert ctx.status == ExecutionStatus.COMPLETED
        assert ctx.step_outputs["trans"]["result"]["greeting"] == "Hello, test"

    @pytest.mark.asyncio
    async def test_transform_no_mapping_raises(self):
        transform = StepDefinition(
            id="trans",
            name="Transform",
            type=StepType.TRANSFORM,
            config={},
        )
        wf = self._make_workflow([transform])

        with pytest.raises(ExecutorError, match="no mapping configured"):
            await self.executor.execute(wf, self.trigger_event)

    @pytest.mark.asyncio
    async def test_retry_on_failure(self):
        self.llm_executor.side_effect = [
            Exception("First failure"),
            {"response": "success"},
        ]
        step = self._llm_step("s1")
        step.retry = RetryConfig(max_retries=1, delay_seconds=0.01)
        wf = self._make_workflow([step])

        ctx = await self.executor.execute(wf, self.trigger_event)
        assert ctx.status == ExecutionStatus.COMPLETED
        assert self.llm_executor.call_count == 2

    @pytest.mark.asyncio
    async def test_retry_exhausted_raises(self):
        self.llm_executor.side_effect = Exception("Always fails")
        step = self._llm_step("s1")
        step.retry = RetryConfig(max_retries=1, delay_seconds=0.01)
        wf = self._make_workflow([step])

        with pytest.raises(ExecutorError, match="Always fails"):
            await self.executor.execute(wf, self.trigger_event)
        assert self.llm_executor.call_count == 2  # initial + 1 retry

    @pytest.mark.asyncio
    async def test_resource_budget_max_steps(self):
        many_steps = [self._llm_step(f"s{i}") for i in range(60)]
        wf = self._make_workflow(
            many_steps,
            resource_budget=ResourceBudget(max_steps=10),
        )

        with pytest.raises(ExecutorError, match="Resource budget exceeded"):
            await self.executor.execute(wf, self.trigger_event)

    @pytest.mark.asyncio
    async def test_unknown_step_type_raises(self):
        step = StepDefinition(id="bad", name="Bad", type=StepType.SUBWORKFLOW)
        wf = self._make_workflow([step])

        with pytest.raises(ExecutorError, match="Unknown step type"):
            await self.executor.execute(wf, self.trigger_event)

    @pytest.mark.asyncio
    async def test_execution_context_has_run_id(self):
        wf = self._make_workflow([self._llm_step()])
        ctx = await self.executor.execute(wf, self.trigger_event)

        assert ctx.run_id is not None
        assert len(ctx.run_id) > 0

    @pytest.mark.asyncio
    async def test_execution_context_has_workflow_snapshot(self):
        wf = self._make_workflow([self._llm_step()])
        ctx = await self.executor.execute(wf, self.trigger_event)

        assert ctx.workflow_name == "test_wf"
        assert ctx.version == "1.0.0"
        assert ctx.workflow_definition["name"] == "test_wf"

    @pytest.mark.asyncio
    async def test_input_resolution(self):
        step = StepDefinition(
            id="s1",
            name="With Inputs",
            type=StepType.LLM,
            inputs={"code": "${trigger.payload.code}"},
        )
        wf = self._make_workflow([step])
        await self.executor.execute(wf, self.trigger_event)

        # LLM executor should have been called with resolved inputs
        call_args = self.llm_executor.call_args
        assert call_args is not None
        # The executor passes (role, inputs) where inputs contain resolved values
        args, _ = call_args
        assert args[1]["code"] == "test"

    @pytest.mark.asyncio
    async def test_timeout_triggers_retry(self):
        self.llm_executor.side_effect = asyncio.TimeoutError()
        step = self._llm_step("s1")
        step.timeout_seconds = 1
        step.retry = RetryConfig(max_retries=1, delay_seconds=0.01)
        wf = self._make_workflow([step])

        with pytest.raises(ExecutorError, match="timed out"):
            await self.executor.execute(wf, self.trigger_event)

    @pytest.mark.asyncio
    async def test_graph_validation_failure_propagates(self):
        """Invalid graph (cycle) should raise ExecutorError."""
        # Create steps that form a cycle via branch reference
        s1 = self._llm_step("s1")
        s2 = self._llm_step("s2")
        # Sequential steps s1 -> s2 is fine, but we need a cycle
        # Use a condition that references back to s1
        cond = StepDefinition(
            id="cond",
            name="Cycle",
            type=StepType.CONDITION,
            config={"expression": "${trigger.payload.code}"},
            branches={
                "pass": [s1],  # s1 already exists, creating a cycle
                "fail": [s2],
            },
        )
        wf = self._make_workflow([cond, s1])

        with pytest.raises(ExecutorError, match="Graph validation failed"):
            await self.executor.execute(wf, self.trigger_event)


