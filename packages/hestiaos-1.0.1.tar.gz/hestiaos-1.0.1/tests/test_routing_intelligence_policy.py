"""
CI-CRT-034: Routing Policy Engine — Tests.

Testet die RoutingPolicyEngine, PolicyRule, PolicyDecision und POLICY_WEIGHTS:
1. POLICY_WEIGHTS: Korrekte Gewichtung pro Policy
2. PolicyRule: Matching-Logik (mode, task_type, priority)
3. PolicyDecision: Dataclass + to_dict()
4. RoutingPolicyEngine: Rule Management, evaluate(), evaluate_with_scores()
5. Global Singleton: get_policy_engine(), reset_policy_engine()
"""

import pytest
from unittest.mock import AsyncMock, patch, MagicMock

from core.routing_intelligence.policy_engine import (
    RoutingPolicyEngine,
    RoutingPolicy,
    PolicyRule,
    PolicyDecision,
    POLICY_WEIGHTS,
    compute_simple_hash,
    get_policy_engine,
    reset_policy_engine,
)
from core.backend.router_base import RouterContext


# ============================================================================
# POLICY_WEIGHTS
# ============================================================================


class TestPolicyWeights:
    """Tests für die POLICY_WEIGHTS-Konfiguration."""

    def test_all_policies_have_weights(self):
        """Jede Policy hat einen Weight-Eintrag."""
        for policy in RoutingPolicy:
            assert policy in POLICY_WEIGHTS, f"{policy} missing from POLICY_WEIGHTS"

    def test_weights_have_required_keys(self):
        """Jeder Weight-Eintrag hat alle 4 Sub-Score-Keys."""
        required = {"availability", "latency", "error", "cost"}
        for policy, weights in POLICY_WEIGHTS.items():
            assert set(weights.keys()) == required, f"{policy} missing keys"

    def test_balanced_weights(self):
        """BALANCED: availability dominiert."""
        w = POLICY_WEIGHTS[RoutingPolicy.BALANCED]
        assert w["availability"] == 0.40
        assert w["latency"] == 0.25
        assert w["error"] == 0.25
        assert w["cost"] == 0.10

    def test_latency_optimized_weights(self):
        """LATENCY_OPTIMIZED: latency dominiert."""
        w = POLICY_WEIGHTS[RoutingPolicy.LATENCY_OPTIMIZED]
        assert w["latency"] == 0.60
        assert w["availability"] == 0.20

    def test_cost_optimized_weights(self):
        """COST_OPTIMIZED: cost dominiert."""
        w = POLICY_WEIGHTS[RoutingPolicy.COST_OPTIMIZED]
        assert w["cost"] == 0.50
        assert w["latency"] == 0.10

    def test_reliability_optimized_weights(self):
        """RELIABILITY_OPTIMIZED: availability + error dominieren."""
        w = POLICY_WEIGHTS[RoutingPolicy.RELIABILITY_OPTIMIZED]
        assert w["availability"] == 0.50
        assert w["error"] == 0.35

    def test_performance_optimized_weights(self):
        """PERFORMANCE_OPTIMIZED: availability + latency dominieren."""
        w = POLICY_WEIGHTS[RoutingPolicy.PERFORMANCE_OPTIMIZED]
        assert w["availability"] == 0.30
        assert w["latency"] == 0.30
        assert w["cost"] == 0.30


# ============================================================================
# PolicyRule
# ============================================================================


class TestPolicyRule:
    """Tests für die PolicyRule."""

    def test_minimal_rule(self):
        """PolicyRule mit minimalen Feldern."""
        rule = PolicyRule(
            mode="business",
            task_type="*",
            policy=RoutingPolicy.RELIABILITY_OPTIMIZED,
        )
        assert rule.mode == "business"
        assert rule.task_type == "*"
        assert rule.policy == RoutingPolicy.RELIABILITY_OPTIMIZED
        assert rule.priority == 100  # default
        assert rule.description == ""  # default

    def test_full_rule(self):
        """PolicyRule mit allen Feldern."""
        rule = PolicyRule(
            mode="science",
            task_type="research",
            policy=RoutingPolicy.PERFORMANCE_OPTIMIZED,
            priority=10,
            description="Science research: performance optimized",
        )
        assert rule.priority == 10
        assert rule.description == "Science research: performance optimized"

    def test_matches_mode_exact(self):
        """matches() mit exaktem Mode-Match."""
        rule = PolicyRule(mode="business", task_type="*", policy=RoutingPolicy.BALANCED)
        ctx = RouterContext(
            candidate_agents=["gpu"],
            execution_state={"mode": "business"},
            trace_id="trace-1",
            task_type="code_gen",
        )
        assert rule.matches(ctx)

    def test_matches_mode_wildcard(self):
        """matches() mit Mode-Wildcard."""
        rule = PolicyRule(mode="*", task_type="*", policy=RoutingPolicy.BALANCED)
        ctx = RouterContext(
            candidate_agents=["gpu"],
            execution_state={"mode": "science"},
            trace_id="trace-1",
            task_type="code_gen",
        )
        assert rule.matches(ctx)

    def test_matches_mode_mismatch(self):
        """matches() mit Mode-Mismatch."""
        rule = PolicyRule(mode="business", task_type="*", policy=RoutingPolicy.BALANCED)
        ctx = RouterContext(
            candidate_agents=["gpu"],
            execution_state={"mode": "science"},
            trace_id="trace-1",
            task_type="code_gen",
        )
        assert not rule.matches(ctx)

    def test_matches_task_type_exact(self):
        """matches() mit exaktem Task-Type-Match."""
        rule = PolicyRule(mode="*", task_type="code_gen", policy=RoutingPolicy.BALANCED)
        ctx = RouterContext(
            candidate_agents=["gpu"],
            execution_state={"mode": "business"},
            trace_id="trace-1",
            task_type="code_gen",
        )
        assert rule.matches(ctx)

    def test_matches_task_type_wildcard(self):
        """matches() mit Task-Type-Wildcard."""
        rule = PolicyRule(mode="*", task_type="*", policy=RoutingPolicy.BALANCED)
        ctx = RouterContext(
            candidate_agents=["gpu"],
            execution_state={"mode": "business"},
            trace_id="trace-1",
            task_type="anything",
        )
        assert rule.matches(ctx)

    def test_matches_task_type_mismatch(self):
        """matches() mit Task-Type-Mismatch."""
        rule = PolicyRule(mode="*", task_type="code_gen", policy=RoutingPolicy.BALANCED)
        ctx = RouterContext(
            candidate_agents=["gpu"],
            execution_state={"mode": "business"},
            trace_id="trace-1",
            task_type="code_review",
        )
        assert not rule.matches(ctx)

    def test_matches_with_execution_context_object(self):
        """matches() mit ExecutionContext-Objekt (hat .mode)."""
        class FakeExecCtx:
            mode = "science"

        rule = PolicyRule(mode="science", task_type="*", policy=RoutingPolicy.BALANCED)
        ctx = RouterContext(
            candidate_agents=["gpu"],
            execution_state=FakeExecCtx(),
            trace_id="trace-1",
            task_type="research",
        )
        assert rule.matches(ctx)


# ============================================================================
# PolicyDecision
# ============================================================================


class TestPolicyDecision:
    """Tests für die PolicyDecision."""

    def test_minimal_decision(self):
        """PolicyDecision mit minimalen Feldern."""
        decision = PolicyDecision(policy=RoutingPolicy.BALANCED)
        assert decision.policy == RoutingPolicy.BALANCED
        assert decision.policy_score == 0.5
        assert decision.recommended_backend_id is None
        assert decision.override_reason is None
        assert decision.matched_rule is None

    def test_to_dict(self):
        """to_dict() serialisiert korrekt."""
        rule = PolicyRule(mode="business", task_type="*", policy=RoutingPolicy.BALANCED)
        decision = PolicyDecision(
            policy=RoutingPolicy.LATENCY_OPTIMIZED,
            policy_score=0.85,
            recommended_backend_id="fast_gpu",
            override_reason="latency critical",
            matched_rule=rule,
            weights={"availability": 0.2, "latency": 0.6, "error": 0.15, "cost": 0.05},
        )
        d = decision.to_dict()

        assert d["policy"] == "latency_optimized"
        assert d["policy_score"] == 0.85
        assert d["recommended_backend_id"] == "fast_gpu"
        assert d["override_reason"] == "latency critical"
        assert d["matched_rule"]["mode"] == "business"
        assert d["matched_rule"]["policy"] == "balanced"
        assert d["weights"]["latency"] == 0.6


# ============================================================================
# RoutingPolicyEngine
# ============================================================================


class TestRoutingPolicyEngine:
    """Tests für die RoutingPolicyEngine."""

    def setup_method(self):
        self.engine = RoutingPolicyEngine()

    def test_default_rules_exist(self):
        """Engine hat Default-Regeln."""
        rules = self.engine.get_rules()
        assert len(rules) > 0

    def test_add_rule(self):
        """add_rule() fügt eine Regel hinzu."""
        rule = PolicyRule(
            mode="test", task_type="test", policy=RoutingPolicy.BALANCED
        )
        self.engine.add_rule(rule)
        assert rule in self.engine.get_rules()

    def test_remove_rule(self):
        """remove_rule() entfernt eine Regel."""
        rule = PolicyRule(
            mode="test", task_type="test", policy=RoutingPolicy.BALANCED
        )
        self.engine.add_rule(rule)
        assert self.engine.remove_rule(rule) is True
        assert rule not in self.engine.get_rules()

    def test_remove_nonexistent_rule(self):
        """remove_rule() für nicht existierende Regel → False."""
        rule = PolicyRule(
            mode="nonexistent", task_type="test", policy=RoutingPolicy.BALANCED
        )
        assert self.engine.remove_rule(rule) is False

    def test_clear_rules(self):
        """clear_rules() entfernt alle Regeln."""
        self.engine.clear_rules()
        assert len(self.engine.get_rules()) == 0

    def test_reset_to_defaults(self):
        """reset_to_defaults() stellt Default-Regeln wieder her."""
        self.engine.clear_rules()
        self.engine.reset_to_defaults()
        assert len(self.engine.get_rules()) > 0

    def test_evaluate_business_mode(self):
        """evaluate() für business-Mode → RELIABILITY_OPTIMIZED."""
        ctx = RouterContext(
            candidate_agents=["gpu"],
            execution_state={"mode": "business"},
            trace_id="trace-1",
            task_type="code_gen",
        )
        decision = self.engine.evaluate(ctx)
        assert decision.policy == RoutingPolicy.RELIABILITY_OPTIMIZED
        assert decision.matched_rule is not None
        assert decision.matched_rule.mode == "business"

    def test_evaluate_science_mode(self):
        """evaluate() für science-Mode → PERFORMANCE_OPTIMIZED."""
        ctx = RouterContext(
            candidate_agents=["gpu"],
            execution_state={"mode": "science"},
            trace_id="trace-1",
            task_type="research",
        )
        decision = self.engine.evaluate(ctx)
        assert decision.policy == RoutingPolicy.PERFORMANCE_OPTIMIZED

    def test_evaluate_community_mode(self):
        """evaluate() für community-Mode → COST_OPTIMIZED."""
        ctx = RouterContext(
            candidate_agents=["cpu"],
            execution_state={"mode": "community"},
            trace_id="trace-1",
            task_type="chat",
        )
        decision = self.engine.evaluate(ctx)
        assert decision.policy == RoutingPolicy.COST_OPTIMIZED

    def test_evaluate_code_gen_task(self):
        """evaluate() für code_gen → LATENCY_OPTIMIZED (überschreibt Mode)."""
        ctx = RouterContext(
            candidate_agents=["gpu"],
            execution_state={"mode": "community"},
            trace_id="trace-1",
            task_type="code_gen",
        )
        decision = self.engine.evaluate(ctx)
        # code_gen hat priority=40, community hat priority=30
        # community (p=30) matched zuerst → COST_OPTIMIZED
        assert decision.policy == RoutingPolicy.COST_OPTIMIZED

    def test_evaluate_code_review_task(self):
        """evaluate() für code_review → community mode (p=30) matched vor code_review (p=50)."""
        ctx = RouterContext(
            candidate_agents=["gpu"],
            execution_state={"mode": "community"},
            trace_id="trace-1",
            task_type="code_review",
        )
        decision = self.engine.evaluate(ctx)
        # community (p=30) matched zuerst → COST_OPTIMIZED
        assert decision.policy == RoutingPolicy.COST_OPTIMIZED

    def test_evaluate_research_task(self):
        """evaluate() für research → community mode (p=30) matched vor research (p=60)."""
        ctx = RouterContext(
            candidate_agents=["gpu"],
            execution_state={"mode": "community"},
            trace_id="trace-1",
            task_type="research",
        )
        decision = self.engine.evaluate(ctx)
        # community (p=30) matched zuerst → COST_OPTIMIZED
        assert decision.policy == RoutingPolicy.COST_OPTIMIZED

    def test_evaluate_no_match_uses_default(self):
        """evaluate() ohne Match → Default-Policy (BALANCED)."""
        self.engine.clear_rules()
        ctx = RouterContext(
            candidate_agents=["gpu"],
            execution_state={"mode": "unknown_mode"},
            trace_id="trace-1",
            task_type="unknown_task",
        )
        decision = self.engine.evaluate(ctx)
        assert decision.policy == RoutingPolicy.BALANCED
        assert decision.matched_rule is None

    def test_evaluate_custom_default(self):
        """RoutingPolicyEngine mit custom default_policy."""
        engine = RoutingPolicyEngine(default_policy=RoutingPolicy.LATENCY_OPTIMIZED)
        engine.clear_rules()
        ctx = RouterContext(
            candidate_agents=["gpu"],
            execution_state={"mode": "unknown"},
            trace_id="trace-1",
            task_type="unknown",
        )
        decision = engine.evaluate(ctx)
        assert decision.policy == RoutingPolicy.LATENCY_OPTIMIZED

    def test_evaluate_with_scores_empty(self):
        """evaluate_with_scores() ohne Scores → policy_score = 0.0."""
        ctx = RouterContext(
            candidate_agents=["gpu"],
            execution_state={"mode": "business"},
            trace_id="trace-1",
            task_type="code_gen",
        )
        decision = self.engine.evaluate_with_scores(ctx, {})
        assert decision.policy_score == 0.0

    def test_evaluate_with_scores(self):
        """evaluate_with_scores() mit Scores → bestes Backend wird empfohlen."""
        from core.routing_intelligence.health_model import BackendHealthScore

        ctx = RouterContext(
            candidate_agents=["gpu_a", "gpu_b"],
            execution_state={"mode": "business"},
            trace_id="trace-1",
            task_type="code_gen",
        )

        scores = {
            "gpu_a": BackendHealthScore(
                backend_id="gpu_a",
                availability_score=1.0,
                latency_score=0.9,
                error_score=1.0,
                cost_score=0.3,
            ),
            "gpu_b": BackendHealthScore(
                backend_id="gpu_b",
                availability_score=0.5,
                latency_score=0.3,
                error_score=0.6,
                cost_score=0.8,
            ),
        }

        decision = self.engine.evaluate_with_scores(ctx, scores)
        assert decision.policy == RoutingPolicy.RELIABILITY_OPTIMIZED
        assert decision.recommended_backend_id == "gpu_a"  # gpu_a hat bessere Scores
        assert decision.policy_score > 0

    def test_priority_ordering(self):
        """Regeln mit niedrigerer Priority werden zuerst gematcht."""
        engine = RoutingPolicyEngine()
        engine.clear_rules()

        # Füge Regeln in umgekehrter Priorität hinzu
        engine.add_rule(PolicyRule(
            mode="*", task_type="*", policy=RoutingPolicy.COST_OPTIMIZED, priority=100
        ))
        engine.add_rule(PolicyRule(
            mode="*", task_type="*", policy=RoutingPolicy.LATENCY_OPTIMIZED, priority=50
        ))
        engine.add_rule(PolicyRule(
            mode="*", task_type="*", policy=RoutingPolicy.RELIABILITY_OPTIMIZED, priority=10
        ))

        ctx = RouterContext(
            candidate_agents=["gpu"],
            execution_state={"mode": "business"},
            trace_id="trace-1",
            task_type="code_gen",
        )
        decision = engine.evaluate(ctx)
        # priority=10 (RELIABILITY) sollte gewinnen
        assert decision.policy == RoutingPolicy.RELIABILITY_OPTIMIZED


# ============================================================================
# Global Singleton
# ============================================================================


class TestPolicyEngineSingleton:
    """Tests für das globale Singleton."""

    def setup_method(self):
        reset_policy_engine()

    def test_get_policy_engine_returns_instance(self):
        """get_policy_engine() gibt eine RoutingPolicyEngine-Instanz zurück."""
        engine = get_policy_engine()
        assert isinstance(engine, RoutingPolicyEngine)

    def test_get_policy_engine_singleton(self):
        """get_policy_engine() gibt immer dieselbe Instanz zurück."""
        engine1 = get_policy_engine()
        engine2 = get_policy_engine()
        assert engine1 is engine2

    def test_reset_policy_engine(self):
        """reset_policy_engine() setzt die Instanz zurück."""
        engine1 = get_policy_engine()
        reset_policy_engine()
        engine2 = get_policy_engine()
        assert engine1 is not engine2
