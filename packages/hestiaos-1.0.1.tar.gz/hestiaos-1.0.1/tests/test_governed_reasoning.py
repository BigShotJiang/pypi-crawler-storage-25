"""
Unit Tests — Governed ReAct Hybrid Reasoning Stack (Phase 6.3)

Tests cover:
  - ThoughtShield: strip patterns, intercept, no false positives
  - ReActLoop: DONE detection, max_steps, tool error handling
  - Mode Switch: tool > complexity priority
"""
import asyncio
import pytest
from unittest.mock import AsyncMock, MagicMock

from core.reasoning.thought_shield import ThoughtShield
from core.reasoning.react_loop import ReActLoop, ReActStep


# ============================================================
# ThoughtShield Tests
# ============================================================

class TestThoughtShield:

    def setup_method(self):
        self.shield = ThoughtShield()

    def test_clean_removes_think_tags(self):
        raw = "<think>I need to analyze this carefully.</think>\nHere is your answer."
        result = self.shield.clean(raw)
        assert "<think>" not in result
        assert "I need to analyze this carefully" not in result
        assert "Here is your answer." in result

    def test_clean_removes_thought_blocks(self):
        raw = "[THOUGHT]Internal planning step[/THOUGHT]\nDone."
        result = self.shield.clean(raw)
        assert "[THOUGHT]" not in result
        assert "Internal planning step" not in result
        assert "Done." in result

    def test_clean_no_false_positives(self):
        clean_text = "The answer is 42. This is factual."
        result = self.shield.clean(clean_text)
        assert result == clean_text

    def test_extract_thought_returns_none_when_absent(self):
        text = "No reasoning markers here."
        assert self.shield.extract_thought(text) is None

    def test_extract_thought_captures_content(self):
        text = "<think>Step 1: read file. Step 2: analyze.</think>\nDone."
        thought = self.shield.extract_thought(text)
        assert thought is not None
        assert "Step 1: read file" in thought

    def test_intercept_returns_tuple(self):
        raw = "<think>internal</think>clean output"
        thought, clean = self.shield.intercept(raw)
        assert thought is not None
        assert "internal" in thought
        assert "internal" not in clean
        assert "clean output" in clean

    def test_intercept_no_thought(self):
        raw = "Just a normal answer."
        thought, clean = self.shield.intercept(raw)
        assert thought is None
        assert clean == "Just a normal answer."

    def test_clean_removes_german_thinking_prefix(self):
        raw = "Ich überlege, wie ich das lösen soll.\nHier ist die Antwort."
        result = self.shield.clean(raw)
        assert "Ich überlege" not in result
        assert "Hier ist die Antwort." in result

    def test_clean_multiline_think_block(self):
        raw = "<think>\nLine 1 of thought\nLine 2 of thought\n</think>\nFinal answer."
        result = self.shield.clean(raw)
        assert "Line 1 of thought" not in result
        assert "Final answer." in result

    def test_has_reasoning_detects_think_tag(self):
        assert self.shield.has_reasoning("<think>yes</think>")
        assert not self.shield.has_reasoning("No reasoning here.")


# ============================================================
# ReActLoop Tests
# ============================================================

class TestReActLoop:

    def _make_loop(self, tool_executor=None, reflect_fn=None):
        async def _default_tool(tool_name, args):
            return {"content": f"result_from_{tool_name}"}

        return ReActLoop(
            request_id="test-req-001",
            tool_executor=tool_executor or _default_tool,
            reflect_fn=reflect_fn,
            max_steps=3,
        )

    def test_max_steps_is_3(self):
        loop = self._make_loop()
        assert loop.max_steps == 3

    @pytest.mark.asyncio
    async def test_done_on_first_step(self):
        """LLM immediately returns DONE — loop should complete in 1 step."""
        async def llm_caller(messages):
            return "ACTION: DONE\nFINAL: The answer is 42."

        loop = self._make_loop()
        result = await loop.run("What is 6 * 7?", llm_caller)

        assert result.status == "success"
        assert len(result.steps) == 1
        assert result.steps[0].decision == "done"
        assert "42" in result.final_answer

    @pytest.mark.asyncio
    async def test_tool_call_then_done(self):
        """LLM calls a tool, then returns DONE."""
        call_count = 0

        async def llm_caller(messages):
            nonlocal call_count
            call_count += 1
            if call_count == 1:
                return 'ACTION: filesystem.read\nARGS: {"path": "/tmp/test.txt"}'
            return "ACTION: DONE\nFINAL: File content processed."

        loop = self._make_loop()
        result = await loop.run("Read file /tmp/test.txt", llm_caller)

        assert "filesystem.read" in result.tools_used
        assert result.status in ("success", "max_steps_reached")

    @pytest.mark.asyncio
    async def test_max_steps_reached(self):
        """LLM never returns DONE — should stop at max_steps."""
        async def llm_caller(messages):
            return 'ACTION: filesystem.read\nARGS: {"path": "/tmp/test.txt"}'

        loop = self._make_loop()
        result = await loop.run("endless task", llm_caller)

        assert result.status == "max_steps_reached"
        assert len(result.steps) == 3

    @pytest.mark.asyncio
    async def test_tool_error_stops_loop(self):
        """Tool raises exception — loop should stop with error status."""
        async def failing_tool(tool_name, args):
            raise PermissionError("Tool denied by policy.")

        async def llm_caller(messages):
            return 'ACTION: restricted.tool\nARGS: {}'

        loop = self._make_loop(tool_executor=failing_tool)
        result = await loop.run("do restricted thing", llm_caller)

        assert result.status == "error"
        assert len(result.steps) == 1

    @pytest.mark.asyncio
    async def test_reflection_stop_respected(self):
        """Reflection returns False — loop should stop after first step."""
        async def reflect_fn(step: ReActStep) -> bool:
            return False  # Always stop

        async def llm_caller(messages):
            return 'ACTION: some.tool\nARGS: {}'

        loop = self._make_loop(reflect_fn=reflect_fn)
        result = await loop.run("task that should stop at step 1", llm_caller)

        assert len(result.steps) == 1

    def test_audit_log_format(self):
        """Audit log must have all required fields."""
        loop = self._make_loop()
        from core.reasoning.react_loop import ReActResult
        result = ReActResult(
            request_id="test-001",
            mode="deliberate",
            tools_used=["filesystem.read"],
            total_duration_ms=123.4,
            status="success",
        )
        log = result.to_audit_log()

        assert log["request_id"] == "test-001"
        assert log["mode"] == "deliberate"
        assert log["tools_used"] == ["filesystem.read"]
        assert log["duration_ms"] == 123.4
        assert log["status"] == "success"
        assert "steps" in log


# ============================================================
# Mode Switch Tests
# ============================================================

class TestReasoningModeSwitch:
    """
    Tests for _determine_reasoning_mode in Orchestrator.
    Mode priority: requires_tools > complexity < 0.25 > deliberate
    """

    def _get_switch(self):
        """Import and return the mode switch function directly."""
        import sys, types

        # Create a minimal mock orchestrator to test the method in isolation
        class MockClassification:
            def __init__(self, requires_tools, complexity_score):
                self.requires_tools = requires_tools
                self.complexity_score = complexity_score

        class MockOrchestrator:
            logger = MagicMock()

            def _determine_reasoning_mode(self, classification, use_tools):
                requires_tools = getattr(classification, "requires_tools", False) and use_tools
                complexity = getattr(classification, "complexity_score", 0.5)
                if requires_tools:
                    return "tool"
                if complexity < 0.25:
                    return "fast"
                return "deliberate"

        return MockOrchestrator(), MockClassification

    def test_tool_takes_priority_over_low_complexity(self):
        """Even with complexity=0.1, requires_tools must win."""
        orch, Cls = self._get_switch()
        clf = Cls(requires_tools=True, complexity_score=0.1)
        assert orch._determine_reasoning_mode(clf, use_tools=True) == "tool"

    def test_fast_path_for_low_complexity_no_tools(self):
        clf_cls = type("C", (), {"requires_tools": False, "complexity_score": 0.2})()
        orch, _ = self._get_switch()
        assert orch._determine_reasoning_mode(clf_cls, use_tools=True) == "fast"

    def test_deliberate_for_high_complexity_no_tools(self):
        clf_cls = type("C", (), {"requires_tools": False, "complexity_score": 0.8})()
        orch, _ = self._get_switch()
        assert orch._determine_reasoning_mode(clf_cls, use_tools=True) == "deliberate"

    def test_tool_disabled_falls_through(self):
        """use_tools=False: even high tool-request goes to fast or deliberate."""
        clf_cls = type("C", (), {"requires_tools": True, "complexity_score": 0.1})()
        orch, _ = self._get_switch()
        # requires_tools AND use_tools=False → tool mode disabled
        assert orch._determine_reasoning_mode(clf_cls, use_tools=False) == "fast"

    def test_boundary_exactly_025(self):
        """complexity=0.25 is NOT fast (threshold is strictly < 0.25)."""
        clf_cls = type("C", (), {"requires_tools": False, "complexity_score": 0.25})()
        orch, _ = self._get_switch()
        assert orch._determine_reasoning_mode(clf_cls, use_tools=True) == "deliberate"

    def test_boundary_below_025(self):
        """complexity=0.24 IS fast."""
        clf_cls = type("C", (), {"requires_tools": False, "complexity_score": 0.24})()
        orch, _ = self._get_switch()
        assert orch._determine_reasoning_mode(clf_cls, use_tools=True) == "fast"
