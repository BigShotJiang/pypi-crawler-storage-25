"""
Tests für die DriftEngine (statistische Drift-Analyse).

Testet:
    - Unit: ingest(), ingest_batch(), compute_stability_metrics()
    - Unit: L1 Distance, Drift Classification
    - Unit: Cache Invalidation, Auto-Trigger, Window Size
    - Arbitration: DriftArbitrationContract mit Konfliktmatrix
    - Integration: ESL → DriftEngine, CRITICAL → no crash
"""

import pytest
from typing import Any, Dict, List
from dataclasses import dataclass

from core.drift.engine import (
    DriftEngine,
    DriftLevel,
    DriftMetric,
    DriftWeights,
    StabilityMetrics,
    ExecutionWitness,
    AgentExecutionWitness,
)
from core.drift.baseline import (
    DistributionBaseline,
    VersionedBaseline,
    DriftBaselineBuilder,
)
from core.governance.execution_boundary import (
    DriftArbitrationContract,
    ArbitrationResult,
)


# ── Helpers ──────────────────────────────────────────────────────


def _make_witness(
    command_id: str = "cmd_001",
    policy: str = "default",
    decision: str = "ALLOW",
    provider: str = "ollama",
    latency_ms: float = 100.0,
    agent_id: str = None,
    agent_run_id: str = None,
) -> Any:
    """Erzeugt ein minimales Witness-Objekt (duck-typed)."""
    @dataclass
    class _Witness:
        command_id: str
        policy: str
        decision: str
        provider: str
        latency_ms: float
        agent_id: str
        agent_run_id: str
    return _Witness(
        command_id=command_id,
        policy=policy,
        decision=decision,
        provider=provider,
        latency_ms=latency_ms,
        agent_id=agent_id or "agent_default",
        agent_run_id=agent_run_id or "run_default",
    )


def _make_baseline(
    policy_dist: Dict[str, float] = None,
    decision_dist: Dict[str, float] = None,
    provider_dist: Dict[str, float] = None,
    version: str = "v1",
    sample_size: int = 100,
) -> VersionedBaseline:
    """Erzeugt eine Test-Baseline."""
    return VersionedBaseline(
        version=version,
        created_at="2026-01-01T00:00:00",
        sample_size=sample_size,
        baseline=DistributionBaseline(
            policy_distribution=policy_dist or {"default": 1.0},
            decision_distribution=decision_dist or {"ALLOW": 1.0},
            provider_distribution=provider_dist or {"ollama": 1.0},
        ),
    )


# ── Unit Tests: DriftEngine ─────────────────────────────────────


class TestDriftEngineIngest:
    """Tests für ingest()."""

    def test_ingest_single_witness(self):
        engine = DriftEngine()
        witness = _make_witness()
        engine.ingest(witness)
        assert len(engine.history) == 1
        assert engine.history[0].command_id == "cmd_001"

    def test_ingest_batch(self):
        engine = DriftEngine()
        @dataclass
        class _Cmd:
            dsgk_decision: str
            latency_ms: float
        @dataclass
        class _Batch:
            agent_run_id: str
            agent_id: str
            commands: List[_Cmd]

        batch = _Batch(
            agent_run_id="run_001",
            agent_id="agent_001",
            commands=[
                _Cmd(dsgk_decision="ALLOW", latency_ms=50.0),
                _Cmd(dsgk_decision="ALLOW", latency_ms=100.0),
                _Cmd(dsgk_decision="BLOCK", latency_ms=30.0),
            ],
        )
        engine.ingest_batch(batch)
        assert len(engine.agent_history) == 1
        assert engine.agent_history[0].agent_run_id == "run_001"
        assert engine.agent_history[0].command_count == 3
        assert engine.agent_history[0].decision_sequence == "ALLOW|ALLOW|BLOCK"

    def test_window_size_enforced(self):
        engine = DriftEngine()
        engine.window_size = 5
        for i in range(10):
            engine.ingest(_make_witness(command_id=f"cmd_{i:03d}"))
        assert len(engine.history) == 5
        assert engine.history[0].command_id == "cmd_005"
        assert engine.history[-1].command_id == "cmd_009"

    def test_ingest_batch_creates_agent_witness(self):
        engine = DriftEngine()
        @dataclass
        class _Cmd:
            dsgk_decision: str
            latency_ms: float
        @dataclass
        class _Batch:
            agent_run_id: str
            agent_id: str
            commands: List[_Cmd]

        batch = _Batch(
            agent_run_id="run_002",
            agent_id="agent_002",
            commands=[_Cmd(dsgk_decision="ALLOW", latency_ms=10.0)],
        )
        engine.ingest_batch(batch)
        assert len(engine.agent_history) == 1
        assert engine.agent_history[0].agent_id == "agent_002"


class TestDriftEngineStability:
    """Tests für compute_stability_metrics() und stability Property."""

    def test_compute_stability_no_baseline(self):
        engine = DriftEngine()
        metrics = engine.compute_stability_metrics()
        assert metrics.stability_score == 1.0
        assert metrics.baseline_version == "NONE"
        assert metrics.system_drift.level == DriftLevel.STABLE

    def test_compute_stability_insufficient_samples(self):
        baseline = _make_baseline()
        engine = DriftEngine(baseline=baseline)
        # Nur 10 Samples (< 50)
        for i in range(10):
            engine.ingest(_make_witness(command_id=f"cmd_{i:03d}"))
        metrics = engine.compute_stability_metrics()
        assert metrics.is_statistically_significant is False
        assert metrics.sample_size == 10

    def test_compute_stability_with_baseline(self):
        baseline = _make_baseline(
            policy_dist={"default": 0.5, "strict": 0.5},
            decision_dist={"ALLOW": 0.8, "BLOCK": 0.2},
            provider_dist={"ollama": 1.0},
        )
        engine = DriftEngine(baseline=baseline)
        # 50 Samples mit abweichender Verteilung
        for i in range(50):
            policy = "default" if i < 25 else "strict"
            engine.ingest(_make_witness(
                command_id=f"cmd_{i:03d}",
                policy=policy,
                decision="ALLOW" if i < 40 else "BLOCK",
            ))
        metrics = engine.compute_stability_metrics()
        assert metrics.is_statistically_significant is True
        assert metrics.sample_size == 50
        # Bei identischer Verteilung sollte drift ~0 sein
        assert metrics.system_drift.value < 0.3

    def test_stability_property(self):
        baseline = _make_baseline()
        engine = DriftEngine(baseline=baseline)
        for i in range(50):
            engine.ingest(_make_witness(command_id=f"cmd_{i:03d}"))
        # stability Property sollte cached metrics zurückgeben
        metrics = engine.stability
        assert metrics is not None
        assert isinstance(metrics, StabilityMetrics)
        # Zweiter Aufruf sollte dasselbe Objekt zurückgeben (Cache)
        assert engine.stability is metrics

    def test_stability_property_none_before_ingest(self):
        engine = DriftEngine()
        assert engine.stability is None

    def test_auto_trigger_at_threshold(self):
        """INV-DRIFT-006: Nach 50 Ingests ist stability != None."""
        engine = DriftEngine()
        for i in range(49):
            engine.ingest(_make_witness(command_id=f"cmd_{i:03d}"))
        assert engine.stability is None  # Noch nicht genug
        engine.ingest(_make_witness(command_id="cmd_050"))
        assert engine.stability is not None  # Auto-Trigger bei Threshold

    def test_cache_invalidation_on_ingest(self):
        baseline = _make_baseline()
        engine = DriftEngine(baseline=baseline)
        for i in range(50):
            engine.ingest(_make_witness(command_id=f"cmd_{i:03d}"))
        first = engine.stability
        # Neuer ingest invalidiert Cache
        engine.ingest(_make_witness(command_id="cmd_new"))
        assert engine._last_metrics is None
        # Neuberechnung beim nächsten Zugriff
        second = engine.stability
        assert second is not None
        # Sollte unterschiedliche Objekte sein (Cache invalidiert)
        assert first is not second


class TestDriftEngineL1Distance:
    """Tests für L1 Distance Berechnung."""

    def test_l1_distance_identical(self):
        engine = DriftEngine()
        p = {"A": 0.5, "B": 0.5}
        q = {"A": 0.5, "B": 0.5}
        assert engine._l1_distance(p, q) == 0.0

    def test_l1_distance_opposite(self):
        engine = DriftEngine()
        p = {"A": 1.0}
        q = {"B": 1.0}
        assert engine._l1_distance(p, q) == 1.0

    def test_l1_distance_partial(self):
        engine = DriftEngine()
        p = {"A": 1.0}
        q = {"A": 0.5, "B": 0.5}
        # |1.0 - 0.5| + |0 - 0.5| = 0.5 + 0.5 = 1.0 → /2 = 0.5
        assert engine._l1_distance(p, q) == 0.5


class TestDriftEngineClassification:
    """Tests für Drift-Klassifikation."""

    def test_classify_drift_stable(self):
        engine = DriftEngine()
        metric = engine._classify_drift(0.0)
        assert metric.level == DriftLevel.STABLE
        assert metric.value == 0.0

    def test_classify_drift_warning(self):
        engine = DriftEngine()
        metric = engine._classify_drift(0.10)
        assert metric.level == DriftLevel.WARNING

    def test_classify_drift_critical(self):
        engine = DriftEngine()
        metric = engine._classify_drift(0.20)
        assert metric.level == DriftLevel.CRITICAL


# ── Arbitration Tests: DriftArbitrationContract ─────────────────


class TestDriftArbitrationContract:
    """Tests für DriftArbitrationContract mit Konfliktmatrix."""

    def test_policy_breaker_wins(self):
        """INV-ARB-001: PolicyEngine BREAKER → BLOCK."""
        contract = DriftArbitrationContract()
        result = contract.resolve(
            policy_level="BREAKER",
            system_level="STABLE",
            trace_level="PASS",
        )
        assert result.level == "BLOCK"
        assert result.source == "policy_engine"

    def test_drift_engine_critical_wins(self):
        """INV-ARB-002: DriftEngine CRITICAL → WARN."""
        contract = DriftArbitrationContract()
        result = contract.resolve(
            policy_level="CLEAN",
            system_level="CRITICAL",
            trace_level="PASS",
        )
        assert result.level == "WARN"
        assert result.source == "drift_engine"
        # Sollte einen Konflikt melden (ESL=PASS vs DriftEngine=CRITICAL)
        assert len(result.conflicts) > 0

    def test_esl_hard_drift_at_stable(self):
        """INV-ARB-003: ESL HARD + DriftEngine STABLE → WARN."""
        contract = DriftArbitrationContract()
        result = contract.resolve(
            policy_level="CLEAN",
            system_level="STABLE",
            trace_level="HARD_DRIFT",
        )
        assert result.level == "WARN"
        assert result.source == "esl"
        assert "ESL=HARD_DRIFT vs DriftEngine=STABLE" in result.conflicts

    def test_no_drift(self):
        """Alles STABLE/CLEAN/PASS → PASS."""
        contract = DriftArbitrationContract()
        result = contract.resolve(
            policy_level="CLEAN",
            system_level="STABLE",
            trace_level="PASS",
        )
        assert result.level == "PASS"
        assert result.source == "drift_engine"

    def test_drift_engine_warning(self):
        """DriftEngine WARNING → WARN."""
        contract = DriftArbitrationContract()
        result = contract.resolve(
            policy_level="CLEAN",
            system_level="WARNING",
            trace_level="PASS",
        )
        assert result.level == "WARN"
        assert result.source == "drift_engine"

    def test_arbitration_result_has_explainability(self):
        """ArbitrationResult enthält source + reason + conflicts."""
        contract = DriftArbitrationContract()
        result = contract.resolve(
            policy_level="CLEAN",
            system_level="CRITICAL",
            trace_level="HARD_DRIFT",
        )
        assert result.level == "WARN"
        assert result.source == "drift_engine"
        assert len(result.reason) > 0
        assert isinstance(result.conflicts, list)


# ── Integration Tests ───────────────────────────────────────────


class TestDriftEngineIntegration:
    """Integrationstests: ESL → DriftEngine, CRITICAL → no crash."""

    def test_esl_hard_drift_propagates_to_drift_engine(self):
        """ESL HARD_DRIFT muss statistisch in DriftEngine sichtbar sein.
        
        Wenn viele Witnesses mit drift_level=HARD_DRIFT eingehen,
        sollte die DriftEngine eine erhöhte Drift erkennen.
        """
        baseline = _make_baseline(
            policy_dist={"default": 1.0},
            decision_dist={"ALLOW": 1.0},
            provider_dist={"ollama": 1.0},
        )
        engine = DriftEngine(baseline=baseline)
        
        # 50 Witnesses mit abweichendem decision-Wert (BLOCK statt ALLOW)
        for i in range(50):
            engine.ingest(_make_witness(
                command_id=f"cmd_{i:03d}",
                decision="BLOCK",  # Abweichung von Baseline (ALLOW)
            ))
        
        metrics = engine.stability
        assert metrics is not None
        # execution_drift sollte > 0 sein (abweichende Entscheidungen)
        assert metrics.execution_drift.value > 0.0

    def test_drift_engine_critical_does_not_crash_command_processor(self):
        """DriftEngine CRITICAL darf command_processor nicht blockieren.
        
        Die DriftEngine ist read-only — sie kann keine Exceptions werfen,
        die den CommandProcessor blockieren.
        """
        engine = DriftEngine()
        # Auch bei extremen Werten darf ingest nicht crashen
        try:
            engine.ingest(_make_witness(command_id="test"))
            engine.compute_stability_metrics()
        except Exception:
            pytest.fail("DriftEngine hat unerwartete Exception geworfen")

    def test_stability_metrics_available_via_governance_init(self):
        """core.governance.drift_engine.stability ist erreichbar."""
        from core.governance import drift_engine
        # stability kann None sein (noch nicht genug Samples), aber der Zugriff darf nicht crashen
        result = drift_engine.stability
        assert result is None or isinstance(result, StabilityMetrics)
