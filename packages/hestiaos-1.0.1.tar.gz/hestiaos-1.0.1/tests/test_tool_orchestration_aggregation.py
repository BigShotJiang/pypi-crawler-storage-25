#!/usr/bin/env python3
"""
Test tool orchestration aggregation and correlation
"""

import asyncio
import sys
import os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from core.capabilities.tool_orchestration import (
    ToolOrchestratorCapability,
    ToolConfiguration,
    ToolExecutionMode,
    ToolExecutionStatus,
    ToolExecutionResult
)


async def test_aggregation():
    """Test the aggregation and correlation of tool results"""
    
    # Create orchestrator
    orchestrator = ToolOrchestratorCapability()
    
    # Create mock tool results
    mock_results = {
        "bandit": ToolExecutionResult(
            tool_id="bandit",
            status=ToolExecutionStatus.COMPLETED,
            output={
                "results": [
                    {
                        "issue_severity": "HIGH",
                        "issue_text": "Use of insecure function 'eval'",
                        "line_number": 42,
                        "filename": "test.py"
                    },
                    {
                        "issue_severity": "MEDIUM",
                        "issue_text": "Hardcoded password detected",
                        "line_number": 15,
                        "filename": "test.py"
                    }
                ],
                "metrics": {
                    "confidence": "HIGH",
                    "files_analyzed": 1
                }
            },
            execution_time_ms=1200
        ),
        "radon": ToolExecutionResult(
            tool_id="radon",
            status=ToolExecutionStatus.COMPLETED,
            output={
                "complexity": {
                    "average_cyclomatic": 3.2,
                    "maintainability_index": 78.5
                },
                "issues": [
                    {
                        "type": "complexity",
                        "message": "Function 'process_data' has high cyclomatic complexity (12)",
                        "line": 87
                    }
                ]
            },
            execution_time_ms=800
        ),
        "pylint": ToolExecutionResult(
            tool_id="pylint",
            status=ToolExecutionStatus.FAILED,
            error="Tool not available",
            execution_time_ms=100
        )
    }
    
    # Test aggregation
    context = {
        "language": "python",
        "file_path": "test.py"
    }
    
    aggregated = await orchestrator.aggregate_results(mock_results, context)
    
    print("=== Aggregation Test Results ===")
    print(f"Total tools executed: {aggregated['summary']['total_tools_executed']}")
    print(f"Successful tools: {aggregated['summary']['successful_tools']}")
    print(f"Failed tools: {aggregated['summary']['failed_tools']}")
    print(f"Total execution time: {aggregated['summary']['total_execution_time_ms']}ms")
    
    print("\n=== Tool Results ===")
    for tool_id, result in aggregated['tool_results'].items():
        print(f"{tool_id}: {result['status']} ({result.get('execution_time_ms', 0)}ms)")
    
    print("\n=== Extracted Issues ===")
    for issue in aggregated['issues']:
        print(f"- {issue.get('tool', 'unknown')}: {issue.get('type', 'unknown')} - {issue.get('message', 'No message')}")
    
    print("\n=== Correlated Issues ===")
    for issue in aggregated['correlated_issues']:
        print(f"- Line {issue.get('line', 'N/A')}: {issue.get('type', 'unknown')} ({issue.get('severity', 'MEDIUM')})")
        print(f"  Message: {issue.get('message', 'No message')}")
        print(f"  Sources: {', '.join(issue.get('sources', []))}")
        print(f"  Confidence: {issue.get('confidence', 'MEDIUM')}")
    
    print("\n=== Risk Assessment ===")
    risk = aggregated['risk_assessment']
    print(f"Risk score: {risk.get('risk_score', 0)}")
    print(f"Risk level: {risk.get('risk_level', 'UNKNOWN')}")
    print(f"Total issues: {risk.get('total_issues', 0)}")
    print(f"Critical: {risk.get('critical_issues', 0)}, High: {risk.get('high_issues', 0)}, Medium: {risk.get('medium_issues', 0)}, Low: {risk.get('low_issues', 0)}")
    
    print("\n=== Recommendations ===")
    for rec in risk.get('recommendations', []):
        print(f"- {rec}")
    
    return aggregated


class EnhancedToolAggregator:
    """Enhanced tool result aggregation with correlation"""
    
    def correlate_issues(self, issues: list) -> list:
        """Correlate issues from multiple tools"""
        if not issues:
            return []
        
        # Group by line number and type
        grouped = {}
        for issue in issues:
            line = issue.get('line', 0)
            issue_type = issue.get('type', 'unknown')
            key = f"{line}:{issue_type}"
            
            if key not in grouped:
                grouped[key] = {
                    'line': line,
                    'type': issue_type,
                    'message': issue.get('message', ''),
                    'severity': issue.get('severity', 'MEDIUM'),
                    'sources': [],
                    'count': 0
                }
            
            grouped[key]['sources'].append(issue.get('tool', 'unknown'))
            grouped[key]['count'] += 1
            
            # Keep the most severe severity
            severity_order = {'CRITICAL': 4, 'HIGH': 3, 'MEDIUM': 2, 'LOW': 1, 'INFO': 0}
            current_sev = severity_order.get(grouped[key]['severity'], 0)
            new_sev = severity_order.get(issue.get('severity', 'MEDIUM'), 0)
            if new_sev > current_sev:
                grouped[key]['severity'] = issue.get('severity', 'MEDIUM')
        
        # Convert to list
        correlated = []
        for key, data in grouped.items():
            correlated.append({
                'line': data['line'],
                'type': data['type'],
                'message': data['message'],
                'severity': data['severity'],
                'sources': data['sources'],
                'tool_count': data['count'],
                'confidence': 'HIGH' if data['count'] > 1 else 'MEDIUM'
            })
        
        return correlated
    
    def calculate_risk_score(self, issues: list) -> float:
        """Calculate overall risk score from issues"""
        if not issues:
            return 0.0
        
        severity_weights = {
            'CRITICAL': 1.0,
            'HIGH': 0.7,
            'MEDIUM': 0.4,
            'LOW': 0.2,
            'INFO': 0.05
        }
        
        total_weight = 0.0
        for issue in issues:
            severity = issue.get('severity', 'MEDIUM')
            weight = severity_weights.get(severity, 0.4)
            
            # Increase weight for issues detected by multiple tools
            tool_count = issue.get('tool_count', 1)
            multiplier = 1.0 + (0.2 * (tool_count - 1))
            
            total_weight += weight * multiplier
        
        # Normalize to 0-1 scale
        max_possible = len(issues) * 1.0 * 1.4  # All critical with 2+ tools
        if max_possible == 0:
            return 0.0
        
        return min(total_weight / max_possible, 1.0)


async def main():
    """Main test function"""
    print("Testing Tool Orchestration Aggregation & Correlation")
    print("=" * 50)
    
    try:
        results = await test_aggregation()
        
        # Test enhanced aggregator
        aggregator = EnhancedToolAggregator()
        issues = results['issues']
        risk_score = aggregator.calculate_risk_score(issues)
        
        print(f"\n=== Risk Assessment ===")
        print(f"Total issues: {len(issues)}")
        print(f"Risk score: {risk_score:.2f}")
        print(f"Risk level: {'HIGH' if risk_score > 0.7 else 'MEDIUM' if risk_score > 0.3 else 'LOW'}")
        
        return True
        
    except Exception as e:
        print(f"Error: {e}")
        import traceback
        traceback.print_exc()
        return False


if __name__ == "__main__":
    success = asyncio.run(main())
    sys.exit(0 if success else 1)