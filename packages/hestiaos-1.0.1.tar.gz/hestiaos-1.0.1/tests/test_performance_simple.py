#!/usr/bin/env python3
"""
Simple Performance Test for Tool Orchestration
Measures orchestration overhead vs standalone execution
"""

import asyncio
import time
import statistics
import subprocess
import json
import os
import sys
from datetime import datetime

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from core.capabilities.tool_orchestration import ToolOrchestratorCapability
from core.hsp.policies.tool_orchestration_policy import ToolOrchestrationPolicy
from core.hsp.schemas import HSPRequestSchema
from core.hsp.tracing import HSPTraceSystem

async def measure_standalone_bandit(file_path):
    """Measure standalone bandit execution"""
    start = time.time()
    try:
        result = subprocess.run(
            ["bandit", "-f", "json", file_path],
            capture_output=True,
            text=True,
            timeout=10
        )
        elapsed = time.time() - start
        issues = 0
        if result.returncode == 0:
            try:
                data = json.loads(result.stdout)
                issues = len(data.get("results", []))
            except:
                pass
        return elapsed, issues, result.returncode == 0
    except:
        return time.time() - start, 0, False

async def measure_orchestrated(file_path, orchestrator, policy, trace_system):
    """Measure orchestrated execution"""
    start = time.time()
    
    # Get tools
    context = {"language": "python"}
    tools = await orchestrator.discover_available_tools(context)
    
    # HSP policy
    hsp_request = HSPRequestSchema(
        request_id=f"perf-{int(time.time())}",
        trace_id=trace_system.start_trace(f"perf-{int(time.time())}", "performance", {}),
        timestamp=datetime.now().isoformat(),
        context={"language": "python", "data_sensitivity": "medium"},
        source="performance_test",
        metadata={}
    )
    
    tool_dicts = [{"tool_id": t.tool_id, "name": t.name} for t in tools]
    constraints = await policy.evaluate(hsp_request, tool_dicts)
    
    # Execute
    allowed = [t for t in tools if t.tool_id in constraints.tools.allowed_tools]
    results = await orchestrator.execute_tools(allowed, file_path, {"language": "python"}, hsp_request.trace_id)
    
    # Aggregate
    aggregated = await orchestrator.aggregate_results(results, {})
    
    elapsed = time.time() - start
    issues = len(aggregated.get("issues", []))
    
    return elapsed, issues, True

async def main():
    print("Tool Orchestration Performance Test")
    print("=" * 50)
    
    # Setup
    trace_system = HSPTraceSystem()
    orchestrator = ToolOrchestratorCapability(trace_system=trace_system)
    policy = ToolOrchestrationPolicy()
    
    # Test file
    test_file = os.path.join(os.path.dirname(__file__), "core", "tool_executor.py")
    if not os.path.exists(test_file):
        print(f"Test file not found: {test_file}")
        return
    
    print(f"Test file: {os.path.basename(test_file)}")
    print(f"File size: {os.path.getsize(test_file) / 1024:.1f} KB")
    
    # Warmup
    print("\nWarmup runs...")
    for _ in range(2):
        await measure_standalone_bandit(test_file)
        await measure_orchestrated(test_file, orchestrator, policy, trace_system)
    
    # Measurements
    print("\nPerformance measurements (3 iterations each):")
    
    standalone_times = []
    standalone_issues = []
    orchestrated_times = []
    orchestrated_issues = []
    
    for i in range(3):
        print(f"\nIteration {i+1}:")
        
        # Standalone
        s_time, s_issues, s_ok = await measure_standalone_bandit(test_file)
        standalone_times.append(s_time)
        standalone_issues.append(s_issues)
        print(f"  Standalone: {s_time:.3f}s, {s_issues} issues, {'OK' if s_ok else 'FAIL'}")
        
        # Orchestrated
        o_time, o_issues, o_ok = await measure_orchestrated(test_file, orchestrator, policy, trace_system)
        orchestrated_times.append(o_time)
        orchestrated_issues.append(o_issues)
        print(f"  Orchestrated: {o_time:.3f}s, {o_issues} issues, {'OK' if o_ok else 'FAIL'}")
        
        await asyncio.sleep(0.5)
    
    # Results
    print("\n" + "=" * 50)
    print("RESULTS")
    print("=" * 50)
    
    s_avg = statistics.mean(standalone_times)
    o_avg = statistics.mean(orchestrated_times)
    s_issues_avg = statistics.mean(standalone_issues)
    o_issues_avg = statistics.mean(orchestrated_issues)
    
    overhead = o_avg - s_avg
    overhead_pct = (overhead / s_avg) * 100 if s_avg > 0 else 0
    
    print(f"\nStandalone execution:")
    print(f"  Average time: {s_avg:.3f}s")
    print(f"  Time range: {min(standalone_times):.3f}s - {max(standalone_times):.3f}s")
    print(f"  Issues detected: {s_issues_avg:.1f} average")
    
    print(f"\nOrchestrated execution:")
    print(f"  Average time: {o_avg:.3f}s")
    print(f"  Time range: {min(orchestrated_times):.3f}s - {max(orchestrated_times):.3f}s")
    print(f"  Issues detected: {o_issues_avg:.1f} average")
    
    print(f"\nComparison:")
    print(f"  Overhead: {overhead:.3f}s ({overhead_pct:.1f}%)")
    print(f"  Speed ratio: {s_avg/o_avg:.2f}x (orchestrated is {o_avg/s_avg:.2f}x slower)")
    
    if s_issues_avg > 0:
        print(f"  Issue detection ratio: {o_issues_avg/s_issues_avg:.2f}x")
    else:
        print(f"  Issue detection: Both detected {o_issues_avg:.1f} issues")
    
    # Recommendations
    print("\n" + "=" * 50)
    print("RECOMMENDATIONS")
    print("=" * 50)
    
    if overhead_pct < 20:
        print("✓ Low overhead (<20%): Orchestration benefits outweigh costs")
        print("  Suitable for production use")
    elif overhead_pct < 50:
        print("⚠ Moderate overhead (20-50%): Acceptable for security-critical workflows")
        print("  Consider caching policy evaluations")
    else:
        print("✗ High overhead (>50%): Needs optimization")
        print("  Review: HSP policy complexity, trace collection, tool coordination")
    
    if o_issues_avg >= s_issues_avg:
        print("✓ Issue detection preserved or improved")
    else:
        print("⚠ Issue detection reduced - check tool compatibility")
    
    # Phase 2.6 completion analysis
    print("\n" + "=" * 50)
    print("PHASE 2.6 COMPLETION ANALYSIS")
    print("=" * 50)
    print("\nKey Findings:")
    print(f"1. Orchestration overhead: {overhead_pct:.1f}%")
    print(f"2. Absolute overhead: {overhead:.3f}s per file")
    print(f"3. Orchestration includes: HSP policy, trace system, coordination")
    print(f"4. Issue detection: {'Preserved' if o_issues_avg >= s_issues_avg else 'Reduced'}")
    print("\nNext Steps for Phase 2.7:")
    print("1. Optimize HSP policy evaluation (caching)")
    print("2. Consider async tool execution")
    print("3. Evaluate trade-off: security governance vs performance")
    print("4. Production deployment strategy should account for overhead")

if __name__ == "__main__":
    asyncio.run(main())
