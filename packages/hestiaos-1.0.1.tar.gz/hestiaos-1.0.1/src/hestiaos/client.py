"""
HestiaOS SDK Client — Resource-Oriented Public API.

Das SDK ist Resource-Oriented, nicht API-Wrapper-lastig.
Jeder Resource-Namespace ist ein Attribut des Client-Objekts.

Async-First (P2.1):
    - AsyncClient ist die primäre API (production-grade, alle Umgebungen).
    - Client ist eine sync Facade (nur für CLI/Scripts, RuntimeError in async Loops).
    - Jede Resource hat zwei Methoden: run_async() (async) und run() (sync).
    - _sync_await() verwendet strikt asyncio.run() — kein Thread-Fallback.

Streaming (P2.2):
    - AsyncClient.run_stream() — async Generator für Event-basiertes Streaming.
    - Client.run_stream() — sync Generator via Threaded Bridge.
    - Zwei verschiedene Sync-Strategien:
      * _sync_await() für einfache Coroutinen (run(), status(), etc.)
      * Threaded Bridge für async Generatoren (run_stream())

Anti-Leak Contract (P0.2):
    - KEINE Imports aus core.*
    - KEINE internen Typen in Responses (DSGKDecision, CommandTrace, etc.)
    - explain()/trace() geben dict zurück, keine internen Dataclasses
"""

from __future__ import annotations

import asyncio
from dataclasses import dataclass, asdict
from queue import Queue as QueueType
from threading import Event, Thread
from typing import Any, AsyncIterator, Generator

from .errors import GovernanceBlock
from .models import HealthResponse, RunResponse, TraceResponse
from .stream_events import StreamEvent
from .transport import Transport, TransportConfig


# ── Sync-Await Helper ──────────────────────────────────────────────


def _sync_await(coro: Any, timeout: float | None = None) -> Any:
    """Führt eine Coroutine synchron aus — NUR für CLI/Scripts.

    Verwendet strikt ``asyncio.run()``.
    Wenn bereits ein Event Loop läuft (FastAPI, Jupyter), wird ein
    RuntimeError geworfen — der Nutzer muss AsyncClient verwenden.

    Args:
        coro: Die auszuführende Coroutine.
        timeout: Optionales Timeout in Sekunden (via asyncio.wait_for).

    Raises:
        RuntimeError: Wenn ein Event Loop bereits läuft.
        TimeoutError: Wenn das Timeout überschritten wird.
    """
    try:
        loop = asyncio.get_running_loop()
        if loop.is_running():
            raise RuntimeError(
                "Client.run() cannot be called from a running event loop. "
                "Use AsyncClient instead: 'await AsyncClient().run_async(...)'"
            )
    except RuntimeError as e:
        if "cannot be called from a running event loop" in str(e):
            raise
        pass

    async def _run_with_timeout() -> Any:
        if timeout is not None:
            return await asyncio.wait_for(coro, timeout=timeout)
        return await coro

    return asyncio.run(_run_with_timeout())


# ── Response Models (lokal — keine core.*-Imports) ────────────────


@dataclass
class ChatResponse:
    """Antwort auf eine Chat-Nachricht."""
    response: str
    session_id: str
    processing_time: float
    model: str
    trace_id: str | None = None


@dataclass
class AgentResult:
    """Ergebnis einer Agent-Ausführung."""
    agent_id: str
    status: str  # RUNNING | COMPLETED | FAILED | BLOCKED
    output: str | None = None
    error: str | None = None
    trace_id: str | None = None


@dataclass
class SystemStatus:
    """System-Health-Status."""
    status: str  # OK | DEGRADED | ERROR
    ollama: bool
    vllm: bool
    dsgk: bool
    storage: bool
    version: str
    uptime_seconds: float


@dataclass
class SystemMetrics:
    """Systemmetriken inkl. GPU."""
    cpu_percent: float
    memory_percent: float
    active_sessions: int
    requests_total: int
    avg_latency_ms: float
    gpu_percent: float | None = None
    vram_percent: float | None = None
    vram_used_bytes: int | None = None
    vram_total_bytes: int | None = None


# ── Resource-Namespaces ───────────────────────────────────────────


class _ChatResource:
    """Resource-Namespace für Chat-Operationen."""

    def __init__(self, transport: Transport) -> None:
        self._transport = transport

    async def run_async(self, message: str, session_id: str | None = None) -> ChatResponse:
        """POST /chat — Sendet eine Chat-Nachricht via API (async)."""
        response = await self._transport.request(
            "POST",
            "/api/chat",
            json={"message": message, "session_id": session_id},
        )
        response.raise_for_status()
        data = response.json()
        return ChatResponse(**data)

    def run(self, message: str, session_id: str | None = None) -> ChatResponse:
        """POST /chat — Sendet eine Chat-Nachricht via API (sync)."""
        return _sync_await(self.run_async(message, session_id))

    def __call__(self, message: str, session_id: str | None = None) -> ChatResponse:
        """Alias für run() (sync)."""
        return self.run(message, session_id)

    def send(self, message: str, session_id: str | None = None) -> ChatResponse:
        """Alias für run() (sync, kompatibel)."""
        return self.run(message, session_id)


class _AgentsResource:
    """Resource-Namespace für Agent-Operationen."""

    def __init__(self, transport: Transport) -> None:
        self._transport = transport

    async def run_async(self, agent_id: str, task: str, config: dict | None = None) -> AgentResult:
        """POST /agents/run — Startet einen Agenten via API (async)."""
        response = await self._transport.request(
            "POST",
            "/api/agents/run",
            json={"agent_id": agent_id, "task": task, "config": config},
        )
        response.raise_for_status()
        return AgentResult(**response.json())

    def run(self, agent_id: str, task: str, config: dict | None = None) -> AgentResult:
        """POST /agents/run — Startet einen Agenten via API (sync)."""
        return _sync_await(self.run_async(agent_id, task, config))

    def __call__(self, agent_id: str, task: str, config: dict | None = None) -> AgentResult:
        """Alias für run() (sync)."""
        return self.run(agent_id, task, config)


class _SystemResource:
    """Resource-Namespace für System-Operationen."""

    def __init__(self, transport: Transport) -> None:
        self._transport = transport

    async def status_async(self) -> SystemStatus:
        """GET /system/status — Gibt System-Health zurück (async)."""
        response = await self._transport.request(
            "GET",
            "/api/system/status",
        )
        response.raise_for_status()
        return SystemStatus(**response.json())

    def status(self) -> SystemStatus:
        """GET /system/status — Gibt System-Health zurück (sync)."""
        return _sync_await(self.status_async())

    async def config_async(self) -> dict[str, Any]:
        """GET /system/config — Gibt aktuelle Systemkonfiguration zurück (async)."""
        response = await self._transport.request(
            "GET",
            "/api/system/config",
        )
        response.raise_for_status()
        return response.json()

    def config(self) -> dict[str, Any]:
        """GET /system/config — Gibt aktuelle Systemkonfiguration zurück (sync)."""
        return _sync_await(self.config_async())

    async def metrics_async(self) -> SystemMetrics:
        """GET /system/metrics — Gibt Systemmetriken zurück (async)."""
        response = await self._transport.request(
            "GET",
            "/api/system/metrics",
        )
        response.raise_for_status()
        return SystemMetrics(**response.json())

    def metrics(self) -> SystemMetrics:
        """GET /system/metrics — Gibt Systemmetriken zurück (sync)."""
        return _sync_await(self.metrics_async())


class _SecretsResource:
    """Resource-Namespace für Secret-Operationen."""

    def __init__(self, transport: Transport) -> None:
        self._transport = transport

    async def get_async(self, key: str) -> str:
        """GET /secrets/{key} — Liest ein Secret aus dem Vault (async)."""
        response = await self._transport.request(
            "GET",
            f"/api/secrets/{key}",
        )
        response.raise_for_status()
        return response.json()["value"]

    def get(self, key: str) -> str:
        """GET /secrets/{key} — Liest ein Secret aus dem Vault (sync)."""
        return _sync_await(self.get_async(key))

    async def set_async(self, key: str, value: str, provider: str = "custom") -> None:
        """POST /api/secrets — Setzt ein Secret im Vault (async)."""
        response = await self._transport.request(
            "POST",
            "/api/secrets",
            json={
                "credential_ref": key,
                "secret": value,
                "provider": provider,
                "allowed_tools": ["*"],
            },
        )
        response.raise_for_status()

    def set(self, key: str, value: str, provider: str = "custom") -> None:
        """POST /api/secrets — Setzt ein Secret im Vault (sync)."""
        return _sync_await(self.set_async(key, value, provider))

    async def delete_async(self, key: str) -> None:
        """DELETE /secrets/{key} — Löscht ein Secret (async)."""
        response = await self._transport.request(
            "DELETE",
            f"/api/secrets/{key}",
        )
        response.raise_for_status()

    def delete(self, key: str) -> None:
        """DELETE /secrets/{key} — Löscht ein Secret (sync)."""
        return _sync_await(self.delete_async(key))

    def __call__(self, key: str) -> str:
        """Alias für get() (sync)."""
        return self.get(key)


class _GovernanceResource:
    """Resource-Namespace für Governance-Operationen.

    Ruft die API-Endpoints via HTTP auf (SDK → API → Kernel).
    Kein direkter Zugriff auf command_processor oder command_trace_store.
    """

    def __init__(self, transport: Transport) -> None:
        self._transport = transport

    async def explain_async(
        self, command_type: str, command_input: dict | None = None
    ) -> dict[str, Any]:
        """Erklärt eine DSGK-Entscheidung (async).

        Ruft POST /api/governance/explain auf.
        Nutzt shared_dsgk_evaluation() auf dem Server — kein direkter Aufruf.

        Returns:
            dict — das rohe API-Response-Dict (KEIN DSGKDecision-Objekt).
        """
        response = await self._transport.request(
            "POST",
            "/api/governance/explain",
            json={
                "command_type": command_type,
                "command_input": command_input or {},
            },
        )
        response.raise_for_status()
        return response.json()

    def explain(self, command_type: str, command_input: dict | None = None) -> dict[str, Any]:
        """Erklärt eine DSGK-Entscheidung (sync)."""
        return _sync_await(self.explain_async(command_type, command_input))

    async def status_async(self) -> dict[str, Any]:
        """GET /api/governance/stability — Get current drift and stability scores (async)."""
        response = await self._transport.request(
            "GET",
            "/api/governance/stability",
        )
        response.raise_for_status()
        return response.json()

    def status(self) -> dict[str, Any]:
        """GET /api/governance/stability — Get current drift and stability scores (sync)."""
        return _sync_await(self.status_async())

    async def trace_async(self, command_id: str) -> dict[str, Any] | None:
        """Ruft einen vollständigen CommandTrace ab (async).

        Ruft GET /api/governance/trace/{command_id} auf.
        Kein direkter Zugriff auf CommandTraceStore.

        Returns:
            dict — das rohe API-Response-Dict (KEIN CommandTrace-Objekt).
            None — wenn der Trace nicht gefunden wurde (404).
        """
        try:
            response = await self._transport.request(
                "GET",
                f"/api/governance/trace/{command_id}",
            )
            if response.status_code == 404:
                return None
            response.raise_for_status()
            return response.json()
        except Exception:
            return None

    def trace(self, command_id: str) -> dict[str, Any] | None:
        """Ruft einen vollständigen CommandTrace ab (sync)."""
        return _sync_await(self.trace_async(command_id))


class _RunResource:
    """Resource-Namespace für Governance-geguardete Execution.

    NUR run()/run_async()/run_stream_async() — kein __call__ (bewusste Design-Entscheidung).
    """

    def __init__(self, transport: Transport) -> None:
        self._transport = transport

    async def run_async(
        self,
        input: str,
        session_id: str | None = None,
        agent_id: str | None = None,
        mode_hint: str | None = None,
        timeout_ms: int = 30000,
        stream: bool = False,
    ) -> RunResponse:
        """POST /api/v1/run — Führt Input durch Governance aus (async).

        Args:
            input: Der Input-String, der durch die Governance geprüft wird.
            session_id: Optionale Session-ID für Kontext.
            agent_id: Optionaler Agent-ID für Kontext.
            mode_hint: Optionaler Mode-Hint ("fast", "balanced", "deep").
            timeout_ms: Timeout in Millisekunden (Default: 30000).
            stream: Ob Streaming aktiviert werden soll (Default: False).

        Returns:
            RunResponse — das Ergebnis der Governance-geguardeten Execution.

        Raises:
            GovernanceBlock: Wenn die Governance den Request blockt (HTTP 403).
        """
        response = await self._transport.request(
            "POST",
            "/api/v1/run",
            json={
                "input": input,
                "context": {
                    "session_id": session_id,
                    "agent_id": agent_id,
                    "mode_hint": mode_hint,
                },
                "options": {
                    "timeout_ms": timeout_ms,
                    "stream": stream,
                },
            },
        )
        if response.status_code == 403:
            raise GovernanceBlock(
                trace_id=response.json().get("trace_id", "")
            )
        response.raise_for_status()
        return RunResponse(**response.json())

    def run(
        self,
        input: str,
        session_id: str | None = None,
        agent_id: str | None = None,
        mode_hint: str | None = None,
        timeout_ms: int = 30000,
        stream: bool = False,
    ) -> RunResponse:
        """POST /api/v1/run — Führt Input durch Governance aus (sync).

        NUR für CLI/Scripts. In async Umgebungen AsyncClient.run_async() verwenden.
        """
        return _sync_await(self.run_async(
            input=input,
            session_id=session_id,
            agent_id=agent_id,
            mode_hint=mode_hint,
            timeout_ms=timeout_ms,
            stream=stream,
        ))

    async def run_stream_async(
        self,
        input: str,
        session_id: str | None = None,
        agent_id: str | None = None,
        mode_hint: str | None = None,
        timeout_ms: int = 30000,
    ) -> AsyncIterator[dict[str, Any]]:
        """POST /api/v1/run/stream — Streamed Execution (roh).

        P2.2: Liefert rohe Event-Dicts vom Transport.
        AsyncClient.run_stream() wrappt diese in StreamEvent.

        Args:
            input: Der Input-String, der durch die Governance geprüft wird.
            session_id: Optionale Session-ID für Kontext.
            agent_id: Optionaler Agent-ID für Kontext.
            mode_hint: Optionaler Mode-Hint ("fast", "balanced", "deep").
            timeout_ms: Timeout in Millisekunden (Default: 30000).

        Yields:
            dict — rohe Event-Dicts vom API-Server.
        """
        async for event in self._transport.stream(
            "POST",
            "/api/v1/run/stream",
            json={
                "input": input,
                "context": {
                    "session_id": session_id,
                    "agent_id": agent_id,
                    "mode_hint": mode_hint,
                },
                "options": {
                    "timeout_ms": timeout_ms,
                    "stream": True,
                },
            },
        ):
            yield event


# ── AsyncClient (Primary API) ──────────────────────────────────────


class AsyncClient:
    """
    Async-First HestiaOS SDK Client — Primäre API.

    AsyncClient ist die production-grade API für alle Umgebungen.
    Sie besitzt den Transport und verwaltet dessen Lifecycle.

    Usage:
        async with AsyncClient(base_url="http://localhost:8000") as client:
            result = await client.run_async("Hello, world!")
            status = await client.system.status_async()
            decision = await client.governance.explain_async("WRITE")

    Oder ohne Context Manager (Lifecycle manuell):
        client = AsyncClient(base_url="http://localhost:8000")
        try:
            result = await client.run_async("Hello, world!")
        finally:
            await client.aclose()
    """

    def __init__(
        self,
        base_url: str = "http://localhost:8000",
        api_key: str | None = None,
        timeout: float = 30.0,
        retries: int = 3,
    ) -> None:
        config = TransportConfig(
            base_url=base_url.rstrip("/"),
            api_key=api_key,
            timeout=timeout,
            retries=retries,
        )
        self._transport = Transport(config)

        # Resource-Namespaces
        self.chat = _ChatResource(self._transport)
        self.agents = _AgentsResource(self._transport)
        self.system = _SystemResource(self._transport)
        self.secrets = _SecretsResource(self._transport)
        self.governance = _GovernanceResource(self._transport)
        self._run = _RunResource(self._transport)

    async def __aenter__(self) -> AsyncClient:
        """Context Manager Entry — gibt self zurück."""
        return self

    async def __aexit__(self, *args: object) -> None:
        """Context Manager Exit — schließt den Transport."""
        await self._transport._client.aclose()
        self._transport._sync_client.close()

    async def aclose(self) -> None:
        """Schließt den Transport explizit (ohne Context Manager)."""
        await self._transport._client.aclose()
        self._transport._sync_client.close()

    async def run_async(
        self,
        input: str,
        session_id: str | None = None,
        agent_id: str | None = None,
        mode_hint: str | None = None,
        timeout_ms: int = 30000,
        stream: bool = False,
    ) -> RunResponse:
        """Führt Input durch Governance aus (async).

        Dies ist der primäre Entry Point für Governance-geguardete Execution.

        Args:
            input: Der Input-String, der durch die Governance geprüft wird.
            session_id: Optionale Session-ID für Kontext.
            agent_id: Optionaler Agent-ID für Kontext.
            mode_hint: Optionaler Mode-Hint ("fast", "balanced", "deep").
            timeout_ms: Timeout in Millisekunden (Default: 30000).
            stream: Ob Streaming aktiviert werden soll (Default: False).

        Returns:
            RunResponse — das Ergebnis der Governance-geguardeten Execution.

        Raises:
            GovernanceBlock: Wenn die Governance den Request blockt (HTTP 403).
        """
        return await self._run.run_async(
            input=input,
            session_id=session_id,
            agent_id=agent_id,
            mode_hint=mode_hint,
            timeout_ms=timeout_ms,
            stream=stream,
        )

    def run(
        self,
        input: str,
        session_id: str | None = None,
        agent_id: str | None = None,
        mode_hint: str | None = None,
        timeout_ms: int = 30000,
        stream: bool = False,
    ) -> RunResponse:
        """Führt Input durch Governance aus (sync — NUR für CLI/Scripts).

        Warnung: Diese Methode darf NICHT in async Umgebungen
        (FastAPI, Jupyter) verwendet werden. Nutze stattdessen run_async().
        """
        return self._run.run(
            input=input,
            session_id=session_id,
            agent_id=agent_id,
            mode_hint=mode_hint,
            timeout_ms=timeout_ms,
            stream=stream,
        )

    async def run_stream(
        self,
        input: str,
        session_id: str | None = None,
        agent_id: str | None = None,
        mode_hint: str | None = None,
        timeout_ms: int = 30000,
    ) -> AsyncIterator[StreamEvent]:
        """Führt Input durch Governance aus — streaming (async).

        P2.2: Liefert Events inkrementell, sobald sie vom Server kommen.
        Ermöglicht Token-by-Token Output, Tool-Call Visibility,
        und frühzeitiges Cancellation.

        Args:
            input: Der Input-String, der durch die Governance geprüft wird.
            session_id: Optionale Session-ID für Kontext.
            agent_id: Optionaler Agent-ID für Kontext.
            mode_hint: Optionaler Mode-Hint ("fast", "balanced", "deep").
            timeout_ms: Timeout in Millisekunden (Default: 30000).

        Yields:
            StreamEvent — typisierte Events (start, token, delta, tool_call,
                          final, error, done).

        Raises:
            GovernanceBlock: Wenn der initiale Request geblockt wird.
        """
        try:
            async for raw in self._run.run_stream_async(
                input=input,
                session_id=session_id,
                agent_id=agent_id,
                mode_hint=mode_hint,
                timeout_ms=timeout_ms,
            ):
                yield StreamEvent.from_raw(raw)
        except asyncio.CancelledError:
            # Cooperative Cancellation: sofortige Propagation
            raise

    def __repr__(self) -> str:
        return f"AsyncClient(base_url='{self._transport._config.base_url}')"


# ── Sync Client Facade ─────────────────────────────────────────────


class Client:
    """
    HestiaOS SDK Client — Sync Facade (NUR für CLI/Scripts).

    Client ist eine sync Facade um AsyncClient.
    Sie cached den AsyncClient für Connection Reuse.

    RESTRICTED: Darf NICHT in async Umgebungen (FastAPI, Jupyter) verwendet werden.
    In async Umgebungen immer AsyncClient nutzen.

    Usage:
        from hestiaos import Client

        client = Client(base_url="http://localhost:8000")
        response = client.run("Hello, world!")
        status = client.system.status()
        decision = client.governance.explain("WRITE")

    Async-Äquivalent:
        from hestiaos import AsyncClient

        async with AsyncClient(base_url="http://localhost:8000") as client:
            response = await client.run_async("Hello, world!")
    """

    def __init__(
        self,
        base_url: str = "http://localhost:8000",
        api_key: str | None = None,
        timeout: float = 30.0,
        retries: int = 3,
    ) -> None:
        self._async = AsyncClient(
            base_url=base_url,
            api_key=api_key,
            timeout=timeout,
            retries=retries,
        )
        # P2.2 Fix #3: threading.Event() für deterministisches Sync-Cancellation
        self._stop = Event()

    @property
    def chat(self) -> _ChatResource:
        """Chat-Resource-Namespace."""
        return self._async.chat

    @property
    def agents(self) -> _AgentsResource:
        """Agents-Resource-Namespace."""
        return self._async.agents

    @property
    def system(self) -> _SystemResource:
        """System-Resource-Namespace."""
        return self._async.system

    @property
    def secrets(self) -> _SecretsResource:
        """Secrets-Resource-Namespace."""
        return self._async.secrets

    @property
    def governance(self) -> _GovernanceResource:
        """Governance-Resource-Namespace."""
        return self._async.governance

    def run(
        self,
        input: str,
        session_id: str | None = None,
        agent_id: str | None = None,
        mode_hint: str | None = None,
        timeout_ms: int = 30000,
        stream: bool = False,
    ) -> RunResponse:
        """Führt Input durch Governance aus (POST /api/v1/run).

        NUR für CLI/Scripts. In async Umgebungen AsyncClient.run_async() verwenden.

        Args:
            input: Der Input-String, der durch die Governance geprüft wird.
            session_id: Optionale Session-ID für Kontext.
            agent_id: Optionaler Agent-ID für Kontext.
            mode_hint: Optionaler Mode-Hint ("fast", "balanced", "deep").
            timeout_ms: Timeout in Millisekunden (Default: 30000).
            stream: Ob Streaming aktiviert werden soll (Default: False).

        Returns:
            RunResponse — das Ergebnis der Governance-geguardeten Execution.

        Raises:
            GovernanceBlock: Wenn die Governance den Request blockt (HTTP 403).
        """
        return self._async.run(
            input=input,
            session_id=session_id,
            agent_id=agent_id,
            mode_hint=mode_hint,
            timeout_ms=timeout_ms,
            stream=stream,
        )

    def run_stream(
        self,
        input: str,
        session_id: str | None = None,
        agent_id: str | None = None,
        mode_hint: str | None = None,
        timeout_ms: int = 30000,
        timeout: float | None = None,
    ) -> Generator[StreamEvent, None, None]:
        """Führt Input durch Governance aus — streaming (sync).

        P2.2: NUR für CLI/Scripts. Nutzt eine Threaded Async Bridge
        (da async Generatoren nicht mit asyncio.run() konsumiert werden können).

        In async Umgebungen AsyncClient.run_stream() verwenden.

        Args:
            input: Der Input-String, der durch die Governance geprüft wird.
            session_id: Optionale Session-ID für Kontext.
            agent_id: Optionaler Agent-ID für Kontext.
            mode_hint: Optionaler Mode-Hint ("fast", "balanced", "deep").
            timeout_ms: Timeout in Millisekunden (Default: 30000).
            timeout: Optionales Timeout in Sekunden für den gesamten Stream.

        Yields:
            StreamEvent — typisierte Events.

        Raises:
            TimeoutError: Wenn das Timeout überschritten wird.
        """
        queue: QueueType[StreamEvent | None] = QueueType()
        STOP = None  # Sentinel
        self._stop.clear()

        async def _worker() -> None:
            """Läuft im Worker-Thread, konsumiert den async Stream."""
            try:
                async for event in self._async.run_stream(
                    input=input,
                    session_id=session_id,
                    agent_id=agent_id,
                    mode_hint=mode_hint,
                    timeout_ms=timeout_ms,
                ):
                    if self._stop.is_set():
                        break
                    queue.put(event)
            finally:
                queue.put(STOP)  # type: ignore[arg-type]

        # EXPLIZITER EVENT-LOOP LIFECYCLE (Fix #1):
        # - asyncio.run() im Thread erzeugt neuen Loop pro Stream
        # - Verhindert Connection-Pool-Reuse, nicht cancel-safe
        # - Stattdessen: new_event_loop + shutdown_asyncgens + close
        _stream_timeout = timeout

        def _runner() -> None:
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
            try:
                if _stream_timeout is not None:
                    loop.run_until_complete(
                        asyncio.wait_for(_worker(), timeout=_stream_timeout)
                    )
                else:
                    loop.run_until_complete(_worker())
            finally:
                loop.run_until_complete(loop.shutdown_asyncgens())
                loop.close()

        thread = Thread(target=_runner, daemon=True)
        thread.start()

        try:
            while True:
                # DETERMINISTISCHES CANCELLATION (Fix #3):
                # - threading.Event() als _stop Signal
                # - daemon=True allein ist best-effort
                # - Ermöglicht CLI-Abbruch via KeyboardInterrupt
                if self._stop.is_set():
                    break
                try:
                    item = queue.get(timeout=0.5)
                except Exception:
                    continue
                if item is STOP:
                    break
                yield item
        finally:
            # Generator-Exit: _stop setzen + Thread join
            self._stop.set()
            thread.join(timeout=2.0)

    def __repr__(self) -> str:
        return f"Client(base_url='{self._async._transport._config.base_url}')"
