"""
HestiaOS SDK — Version.
"""

__version__ = "1.0.1"
