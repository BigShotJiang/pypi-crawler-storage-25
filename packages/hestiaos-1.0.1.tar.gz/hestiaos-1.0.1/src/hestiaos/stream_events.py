"""P2.2 — StreamEvent Modell für Event-basiertes Streaming.

Definiert das Event-Modell für Streaming-Responses.
Kein Chunk-Modell — Events sind strukturierte, typisierte Nachrichten.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Literal, TypeGuard


StreamEventType = Literal[
    "start",
    "token",
    "delta",
    "tool_call",
    "final",
    "error",
    "done",
]


@dataclass(frozen=True)
class StreamEvent:
    """Ein Event im Streaming-Response.

    Attributes:
        type: Event-Typ (start, token, delta, tool_call, final, error, done).
        data: Event-Daten (strukturiertes dict, typabhängig).
        trace_id: Trace-ID für Audit-Trail.
        timestamp: ISO-8601 Zeitstempel des Events.
    """

    type: StreamEventType
    data: dict[str, Any]
    trace_id: str
    timestamp: str

    @classmethod
    def from_raw(cls, raw: dict[str, Any]) -> StreamEvent:
        """Erzeugt ein StreamEvent aus einem rohen API-Dict.

        Args:
            raw: Roh-Dict vom API-Server (aus Transport.stream()).

        Returns:
            StreamEvent — typisiertes Event.
        """
        return cls(
            type=raw["type"],
            data=raw.get("data", {}),
            trace_id=raw.get("trace_id", ""),
            timestamp=raw.get("timestamp", ""),
        )


# ── Type-Narrowing Guards (F6) ──────────────────────────────────────


def is_start_event(event: StreamEvent) -> TypeGuard[StreamEvent]:
    """TypeGuard: Prüft ob das Event ein start-Event ist."""
    return event.type == "start"


def is_token_event(event: StreamEvent) -> TypeGuard[StreamEvent]:
    """TypeGuard: Prüft ob das Event ein token-Event ist."""
    return event.type == "token"


def is_delta_event(event: StreamEvent) -> TypeGuard[StreamEvent]:
    """TypeGuard: Prüft ob das Event ein delta-Event ist."""
    return event.type == "delta"


def is_tool_call_event(event: StreamEvent) -> TypeGuard[StreamEvent]:
    """TypeGuard: Prüft ob das Event ein tool_call-Event ist."""
    return event.type == "tool_call"


def is_final_event(event: StreamEvent) -> TypeGuard[StreamEvent]:
    """TypeGuard: Prüft ob das Event ein final-Event ist."""
    return event.type == "final"


def is_error_event(event: StreamEvent) -> TypeGuard[StreamEvent]:
    """TypeGuard: Prüft ob das Event ein error-Event ist."""
    return event.type == "error"


def is_done_event(event: StreamEvent) -> TypeGuard[StreamEvent]:
    """TypeGuard: Prüft ob das Event ein done-Event ist."""
    return event.type == "done"
