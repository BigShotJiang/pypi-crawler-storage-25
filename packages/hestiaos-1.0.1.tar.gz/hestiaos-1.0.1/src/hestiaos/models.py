"""
HestiaOS SDK — Public Response Models.

Alle Modelle sind frozen dataclasses (immutable).
Sie spiegeln die Contract-Semantik der API v1-Endpoints,
importieren aber KEINE API-Pydantic-Klassen (keine Response-Duplikation).

Warnung (Review Gate 1):
    - trace_id ist Contract-kritisch: niemals optional, niemals umbenennen,
      niemals UUID-Format ändern.
    - RunResponse hat KEIN reason-Feld (gehört nur in Trace API).
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class RunResponse:
    """Ergebnis einer Governance-geguardeten Execution.

    Enthält NUR das Decision Surface — keine Policy-Begründung.
    Begründung gehört in die Trace API (TraceResponse).

    Attributes:
        result: Entscheidung der Governance ("ALLOW" | "THROTTLE" | "BLOCK").
        output: Output der Execution (None bei BLOCK).
        mode: System-Mode zum Zeitpunkt der Execution.
        budget: Reasoning-Budget (0.0 bei BLOCK).
        trace_id: Eindeutige Trace-ID (UUID, Contract-kritisch).
        latency_ms: Latenz der Execution in Millisekunden.
    """

    result: str  # "ALLOW" | "THROTTLE" | "BLOCK"
    output: str | None
    mode: str
    budget: float
    trace_id: str
    latency_ms: float


@dataclass(frozen=True)
class TraceResponse:
    """Vollständiges Governance-Audit für eine Execution.

    Attributes:
        trace_id: Eindeutige Trace-ID (UUID, Contract-kritisch).
        decision: Governance-Entscheidung ("ALLOW" | "THROTTLE" | "BLOCK").
        reason: Policy-Begründung der Entscheidung.
        risk_score: Berechneter Risiko-Score (0.0–1.0).
        policy: Angewandte Policy.
        violations: Liste der Policy-Verstöße (flache dicts).
        mode: System-Mode zum Zeitpunkt der Execution.
        budget: Reasoning-Budget.
        latency_ms: Latenz in Millisekunden.
        timestamp: ISO-8601 Zeitstempel der Execution.
    """

    trace_id: str
    decision: str
    reason: str
    risk_score: float
    policy: str
    violations: list[dict[str, object]]
    mode: str
    budget: float
    latency_ms: float
    timestamp: str


@dataclass(frozen=True)
class HealthResponse:
    """System-Health-Status.

    Attributes:
        status: Health-Status ("ok" | "degraded" | "error").
        version: HestiaOS-Version.
        uptime_seconds: Uptime in Sekunden.
        api_version: API-Version (z. B. "v1").
    """

    status: str
    version: str
    uptime_seconds: float
    api_version: str


@dataclass(frozen=True)
class ErrorResponse:
    """Standardisierter SDK-Fehler.

    Attributes:
        code: Fehlercode (z. B. "GOVERNANCE_BLOCK", "INVALID_INPUT").
        message: Menschlesbare Fehlerbeschreibung.
        trace_id: Optionale Trace-ID für Debugging.
        details: Optionale Detailinformationen.
    """

    code: str
    message: str
    trace_id: str | None = None
    details: dict[str, object] | None = None
