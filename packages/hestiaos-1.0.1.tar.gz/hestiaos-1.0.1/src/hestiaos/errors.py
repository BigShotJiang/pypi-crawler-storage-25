"""
HestiaOS SDK — Public Exception Classes.

Basis-Exception für alle SDK-Fehler ist HestiaError.
Spezifische Subklassen für bekannte Fehlerfälle.
"""

from __future__ import annotations


class HestiaError(Exception):
    """Basis-Exception für alle SDK-Fehler.

    Attributes:
        code: Maschinenlesbarer Fehlercode (z. B. "GOVERNANCE_BLOCK").
        message: Menschlesbare Fehlerbeschreibung.
        trace_id: Optionale Trace-ID für Debugging.
    """

    def __init__(self, code: str, message: str, trace_id: str | None = None) -> None:
        self.code = code
        self.message = message
        self.trace_id = trace_id
        super().__init__(f"[{code}] {message}")


class GovernanceBlock(HestiaError):
    """Request wurde von der Governance geblockt (HTTP 403).

    Tritt auf, wenn die DSGK-Entscheidung BLOCK ist.
    """

    def __init__(self, trace_id: str) -> None:
        super().__init__(
            code="GOVERNANCE_BLOCK",
            message="Request blocked by governance",
            trace_id=trace_id,
        )


class InvalidInput(HestiaError):
    """Request-Schema ungültig (HTTP 422).

    Tritt auf, wenn der Input nicht dem erwarteten Schema entspricht.
    """

    def __init__(
        self,
        message: str = "Invalid input",
        trace_id: str | None = None,
        details: dict[str, object] | None = None,
    ) -> None:
        super().__init__(code="INVALID_INPUT", message=message, trace_id=trace_id)
        self.details = details


class NotFound(HestiaError):
    """Ressource nicht gefunden (HTTP 404)."""

    def __init__(self, message: str = "Resource not found", trace_id: str | None = None) -> None:
        super().__init__(code="NOT_FOUND", message=message, trace_id=trace_id)
