"""
HestiaOS SDK — HTTP Transport Layer.

Async-first mit httpx.AsyncClient, sync Facade für sync-Nutzer.
Kein direkter `import requests` mehr im SDK.

P2.2: Transport.stream() — async Generator für SSE-basiertes Streaming.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, AsyncIterator

import httpx


@dataclass(frozen=True)
class TransportConfig:
    """Konfiguration für den HTTP-Transport.

    Attributes:
        base_url: Basis-URL der HestiaOS API (z. B. http://localhost:8000).
        api_key: Optionaler API-Key für Authentifizierung.
        timeout: Request-Timeout in Sekunden (Default: 30.0).
        retries: Anzahl Wiederholungen bei Fehlschlag (Default: 3).
        user_agent: User-Agent-Header (Default: "HestiaOS-SDK/0.1.0").
    """

    base_url: str
    api_key: str | None = None
    timeout: float = 30.0
    retries: int = 3
    user_agent: str = "HestiaOS-SDK/0.1.0"


class Transport:
    """HTTP-Transport für das HestiaOS SDK.

    Bietet sowohl async (`request()`) als auch sync (`request_sync()`) Zugriff.
    Intern wird httpx verwendet — kein `import requests`.

    Usage:
        config = TransportConfig(base_url="http://localhost:8000")
        transport = Transport(config)

        # Async
        response = await transport.request("GET", "/api/v1/health")

        # Sync
        response = transport.request_sync("POST", "/api/v1/run", json={...})
    """

    def __init__(self, config: TransportConfig) -> None:
        self._config = config
        headers = self._build_headers()

        self._client = httpx.AsyncClient(
            base_url=config.base_url,
            timeout=config.timeout,
            headers=headers,
        )
        self._sync_client = httpx.Client(
            base_url=config.base_url,
            timeout=config.timeout,
            headers=headers,
        )

    def _build_headers(self) -> dict[str, str]:
        headers: dict[str, str] = {
            "User-Agent": self._config.user_agent,
        }
        if self._config.api_key:
            headers["Authorization"] = f"Bearer {self._config.api_key}"
        return headers

    async def request(self, method: str, path: str, **kwargs: object) -> httpx.Response:
        """Async HTTP request.

        Args:
            method: HTTP-Methode (GET, POST, PUT, DELETE, ...).
            path: Request-Pfad (z. B. "/api/v1/health").
            **kwargs: Zusätzliche Argumente für httpx.AsyncClient.request().

        Returns:
            httpx.Response — die rohe Response.
        """
        return await self._client.request(method, path, **kwargs)

    def request_sync(self, method: str, path: str, **kwargs: object) -> httpx.Response:
        """Sync HTTP request (Facade für sync-Nutzer).

        Args:
            method: HTTP-Methode (GET, POST, PUT, DELETE, ...).
            path: Request-Pfad (z. B. "/api/v1/health").
            **kwargs: Zusätzliche Argumente für httpx.Client.request().

        Returns:
            httpx.Response — die rohe Response.
        """
        return self._sync_client.request(method, path, **kwargs)

    async def stream(
        self,
        method: str,
        path: str,
        **kwargs: object,
    ) -> AsyncIterator[dict[str, Any]]:
        """Async HTTP Streaming — liefert rohe Events als Dicts.

        Nutzt httpx.AsyncClient für SSE-style chunked responses.
        Parst Zeilen-basiert, yield rohe Dicts (keine SDK-Transformation).

        SSE Parser ist robust gegen:
        - Heartbeat-Lines (": ping")
        - Leere Lines
        - Multiline JSON

        Args:
            method: HTTP-Methode (GET, POST, ...).
            path: Request-Pfad (z. B. "/api/v1/run/stream").
            **kwargs: Zusätzliche Argumente für httpx.AsyncClient.request().

        Yields:
            dict — rohes Event-Dict vom API-Server.

        Raises:
            httpx.HTTPStatusError: Bei nicht-2xx Status.
        """
        async with self._client.stream(method, path, **kwargs) as response:
            response.raise_for_status()
            async for line in response.aiter_lines():
                # ROBUSTER SSE PARSER (Fix #2):
                # - toleriert Heartbeat-Lines (": ping")
                # - toleriert leere Lines
                # - toleriert multiline JSON
                if not line or "data:" not in line:
                    continue
                payload = line.split("data:", 1)[1].strip()
                if not payload:
                    continue
                import json

                yield json.loads(payload)
