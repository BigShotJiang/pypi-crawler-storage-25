"""
Anti-Leak Contract Guard — P0.4 Leak-Tripwire.

Prüft, dass keine internen Kernel-Typen in SDK, API-Routern oder Adaptern
vorkommen. Failt fast in CI.

Usage:
    python -m hestiaos.contract_guard
    # oder:
    python src/hestiaos/contract_guard.py
"""

from __future__ import annotations

import ast
import sys
from pathlib import Path
from typing import NoReturn

# ── Verbotene Patterns ──────────────────────────────────────────────
# Jeder Fund eines dieser Strings in einer Datei ist ein Leak.
FORBIDDEN_PATTERNS: list[str] = [
    "DSGKDecision",
    "CommandTrace",
    "ArbitrationResult",
    "DriftVector",
    "SystemMode",
    "DecisionType",
]

# ── Zu scannende Verzeichnisse ──────────────────────────────────────
# Nur P0-relevante Pfade: SDK + v1-Router + Adapter.
# Legacy-Router (chat.py, governance.py) werden in späteren Phasen migriert.
SCAN_DIRS: list[Path] = [
    Path("src/hestiaos"),
    Path("api/routers/v1_run.py"),
    Path("api/routers/v1_trace.py"),
    Path("api/routers/v1_health.py"),
    Path("api/adapters"),
]

# ── Ausnahmen (erlaubte Vorkommen) ──────────────────────────────────
# Format: "dateipfad::pattern" — z.B. "api/adapters/v1_adapter.py::DSGKDecision"
# Wird aktuell nicht benötigt, da der Adapter die einzige legitime
# Grenze ist und dort die Patterns in Strings/Type-Annotations
# vorkommen dürfen.
ALLOWED_EXCEPTIONS: set[str] = set()


def _scan_file(filepath: Path) -> list[str]:
    """Scannt eine einzelne Datei auf verbotene Patterns.

    Verwendet AST, um nur echte Identifier-Treffer zu finden
    (keine Substring-Treffer in Kommentaren oder Strings).
    """
    try:
        tree = ast.parse(filepath.read_text(encoding="utf-8"), filename=str(filepath))
    except SyntaxError:
        return [f"  ❌ SyntaxError in {filepath}"]

    violations: list[str] = []

    for node in ast.walk(tree):
        # Nur Name- und Attribute-Nodes prüfen (echte Identifier)
        if isinstance(node, ast.Name):
            name = node.id
        elif isinstance(node, ast.Attribute):
            name = node.attr
        else:
            continue

        if name in FORBIDDEN_PATTERNS:
            key = f"{filepath}::{name}"
            if key not in ALLOWED_EXCEPTIONS:
                violations.append(
                    f"  ❌ {filepath}:{node.lineno}: "
                    f"Verbotener Typ '{name}' gefunden"
                )

    return violations


def _collect_files(root: Path) -> list[Path]:
    """Sammelt alle zu scannenden .py-Dateien aus SCAN_DIRS.

    Unterstützt sowohl Verzeichnisse (rekursiv) als auch einzelne Dateien.
    """
    files: list[Path] = []
    for entry in SCAN_DIRS:
        full_path = root / entry
        if full_path.is_dir():
            for fp in sorted(full_path.rglob("*.py")):
                if fp.name == "__init__.py":
                    continue
                files.append(fp)
        elif full_path.is_file() and full_path.suffix == ".py":
            files.append(full_path)
    return files


def run_guard() -> int:
    """Führt den Guard aus. Returncode: 0 = ok, 1 = Leak gefunden."""
    root = Path.cwd()
    all_violations: list[str] = []
    files = _collect_files(root)

    for filepath in files:
        violations = _scan_file(filepath)
        all_violations.extend(violations)

    print(f"🔍 Anti-Leak Contract Guard: {len(files)} Dateien gescannt")

    if not all_violations:
        print("✅ Keine Leaks gefunden — Anti-Leak Contract intakt.")
        return 0

    print(f"\n❌ {len(all_violations)} Anti-Leak-Verletzung(en) gefunden:\n")
    for v in all_violations:
        print(v)

    print(
        "\n⚠️  Jeder dieser Typen gehört NUR in api/adapters/v1_adapter.py.\n"
        "   SDK und Router dürfen KEINE Kernel-Typen importieren oder referenzieren."
    )
    return 1


def main() -> NoReturn:
    sys.exit(run_guard())


if __name__ == "__main__":
    main()
