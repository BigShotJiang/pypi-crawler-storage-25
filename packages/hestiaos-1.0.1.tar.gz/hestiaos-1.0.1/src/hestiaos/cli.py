"""
HestiaOS CLI — Typer-basierte Kommandozeile.

Usage:
    hestiaos --help
    hestiaos run "create report"
    hestiaos trace abc123
    hestiaos health
    hestiaos --base-url http://localhost:8000 run "hello" --json
"""

from __future__ import annotations

import json
import sys
from typing import Any, NoReturn, Optional

import typer

from hestiaos import Client, GovernanceBlock

app = typer.Typer(
    name="hestiaos",
    help="HestiaOS CLI — Interact with the HestiaOS platform.",
    no_args_is_help=True,
)


# ── Globale Callback-Optionen ───────────────────────────────────────
@app.callback()
def _main(
    ctx: typer.Context,
    base_url: Optional[str] = typer.Option(
        None, "--base-url", "-u", help="HestiaOS API base URL (default: http://localhost:8000)"
    ),
    api_key: Optional[str] = typer.Option(
        None, "--api-key", "-k", help="API key for authentication"
    ),
    json_output: bool = typer.Option(
        False, "--json", "-j", help="Output as raw JSON"
    ),
) -> None:
    """Globale Optionen für alle CLI-Commands."""
    ctx.ensure_object(dict)
    ctx.obj["base_url"] = base_url or "http://localhost:8000"
    ctx.obj["api_key"] = api_key
    ctx.obj["json_output"] = json_output


# ── Hilfsfunktionen ─────────────────────────────────────────────────
def _make_client(ctx: typer.Context) -> Client:
    """Erzeugt einen Client aus den globalen Optionen."""
    opts = ctx.obj
    return Client(
        base_url=opts["base_url"],
        api_key=opts.get("api_key"),
    )


def _print_result(ctx: typer.Context, data: dict[str, Any]) -> None:
    """Gibt das Ergebnis aus — entweder als JSON oder als Text."""
    if ctx.obj["json_output"]:
        print(json.dumps(data, indent=2, default=str))
    else:
        for key, value in data.items():
            print(f"{key}: {value}")


def _exit_on_error(message: str, code: int = 1) -> NoReturn:
    """Gibt eine Fehlermeldung aus und beendet das Programm."""
    print(f"❌ {message}", file=sys.stderr)
    raise typer.Exit(code=code)


# ── Commands ────────────────────────────────────────────────────────
@app.command()
def run(
    ctx: typer.Context,
    input_text: str = typer.Argument(..., help="Input text to process"),
) -> None:
    """Führt einen Command durch die Governance-Pipeline aus."""
    client = _make_client(ctx)
    try:
        result = client.run(input_text)
    except GovernanceBlock as e:
        _exit_on_error(str(e), code=1)

    data: dict[str, Any] = {
        "result": result.result,
        "trace_id": result.trace_id,
        "output": result.output,
        "mode": result.mode,
        "budget": result.budget,
        "latency_ms": result.latency_ms,
    }
    _print_result(ctx, data)


@app.command()
def trace(
    ctx: typer.Context,
    trace_id: str = typer.Argument(..., help="Trace ID to retrieve"),
) -> None:
    """Ruft einen vollständigen Governance-Trace ab."""
    client = _make_client(ctx)
    result = client.governance.trace(trace_id)
    if result is None:
        _exit_on_error(f"Trace '{trace_id}' not found", code=1)

    _print_result(ctx, result)


@app.command()
def health(
    ctx: typer.Context,
) -> None:
    """Prüft den Health-Status des HestiaOS-Servers."""
    client = _make_client(ctx)
    status = client.system.status()
    data: dict[str, Any] = {
        "status": status.status,
        "version": status.version,
        "uptime_seconds": status.uptime_seconds,
    }
    _print_result(ctx, data)


def main() -> None:
    """Entrypoint für pyproject.toml [project.scripts]."""
    app()


if __name__ == "__main__":
    main()
