"""
HestiaOS SDK — Domain Interface für die HestiaOS-Plattform.

Das SDK ist Resource-Oriented, nicht API-Wrapper-lastig.
Jeder Resource-Namespace ist ein Attribut des Client-Objekts.
Der Client mapped auf typed Commands, nicht direkt auf HTTP.

Async-First (P2.1):
    - AsyncClient ist die primäre API (production-grade, alle Umgebungen).
    - Client ist eine sync Facade (nur für CLI/Scripts).

Usage (async — empfohlen):
    from hestiaos import AsyncClient

    async with AsyncClient(base_url="http://localhost:8000") as client:
        result = await client.run_async("Hello, world!")
        status = await client.system.status_async()

Usage (sync — nur CLI/Scripts):
    from hestiaos import Client

    client = Client(base_url="http://localhost:8000")
    result = client.run("Hello, world!")
    status = client.system.status()
"""

from __future__ import annotations

from .client import (
    AgentResult,
    AsyncClient,  # Primary API (P2.1)
    ChatResponse,
    Client,       # Sync Facade
    SystemMetrics,
    SystemStatus,
)
from .stream_events import StreamEvent  # P2.2 Streaming API
from .errors import GovernanceBlock, HestiaError, InvalidInput, NotFound
from .models import (
    ErrorResponse,
    HealthResponse,
    RunResponse,
    TraceResponse,
)
from .version import __version__

__all__ = [
    "AsyncClient",   # Primary API (P2.1)
    "Client",        # Sync Facade
    "StreamEvent",   # P2.2 Streaming API
    "ChatResponse",
    "AgentResult",
    "SystemStatus",
    "SystemMetrics",
    "RunResponse",
    "TraceResponse",
    "HealthResponse",
    "ErrorResponse",
    "HestiaError",
    "GovernanceBlock",
    "InvalidInput",
    "NotFound",
    "__version__",
]
