import pandas as pd
import numpy as np
from sdv.single_table import CTGANSynthesizer
from sdv.metadata import SingleTableMetadata

# Sample df1 (full population)
df1 = pd.DataFrame(
    {
        "age": ["0-17", "18-34", "18-34", "35-54", "35-54"],
        "ethnicity": ["A", "A", "B", "A", "B"],
        "location": ["XX", "Urban", "Rural", "Urban", "Rural"],
        "value": [400, 1000, 500, 800, 300],  # Number of people
    }
)

# Sample df2 (partial population)
df2 = pd.DataFrame(
    {
        "age": ["18-34", "18-34", "35-54", "35-54"],
        "ethnicity": ["A", "B", "A", "B"],
        "work_status": ["Employed", "Unemployed", "Employed", "Unemployed"],
        "value": [600, 200, 400, 100],
    }
)


# Step 1: Expand aggregates to pseudo-unit records
def expand_df(df, count_col="value"):
    expanded_rows = []
    for _, row in df.iterrows():
        for _ in range(int(row[count_col])):
            expanded_rows.append(row.drop(count_col).to_dict())
    return pd.DataFrame(expanded_rows)


df1_expanded = expand_df(df1)
df2_expanded = expand_df(df2)

# Step 2: Estimate conditional probabilities for work_status from df2
work_status_probs = (
    df2.groupby(["age", "ethnicity", "work_status"])["value"].sum()
    / df2.groupby(["age", "ethnicity"])["value"].sum()
)
work_status_probs = work_status_probs.reset_index()


# Step 3: Assign work_status to df1_expanded probabilistically
def assign_work_status(row, probs):
    key = (row["age"], row["ethnicity"])
    available_probs = probs[probs[["age", "ethnicity"]].apply(tuple, axis=1) == key]
    if not available_probs.empty:
        return np.random.choice(
            available_probs["work_status"], p=available_probs["value"]
        )
    return "Unknown"  # Handle missing combinations from df2


combined_df = df1_expanded.copy()
combined_df["work_status"] = combined_df.apply(
    assign_work_status, args=(work_status_probs,), axis=1
)

# Step 4: Define metadata for CTGAN
metadata = SingleTableMetadata()
metadata.detect_from_dataframe(combined_df)
metadata.update_column(column_name="age", sdtype="categorical")
metadata.update_column(column_name="ethnicity", sdtype="categorical")
metadata.update_column(column_name="location", sdtype="categorical")
metadata.update_column(column_name="work_status", sdtype="categorical")

# Step 5: Train CTGAN
model = CTGANSynthesizer(
    metadata=metadata,
    epochs=300,  # Adjust based on dataset size/complexity
    batch_size=500,
    enforce_min_max_values=False,  # For categorical data
    verbose=True,
)
model.fit(combined_df)

# Step 6: Generate synthetic population
total_population = int(sum(df1["value"]))
synthetic_population = model.sample(num_rows=total_population)

# Step 7: Validate by re-aggregating
synthetic_agg_df1 = (
    synthetic_population.groupby(["age", "ethnicity", "location"])
    .size()
    .reset_index(name="value")
)
synthetic_agg_df2 = (
    synthetic_population.groupby(["age", "ethnicity", "work_status"])
    .size()
    .reset_index(name="value")
)

# Scale df2 for comparison (since df2 covers partial population)
scale_factor = sum(df1["value"]) / sum(df2["value"])
df2_scaled = df2.assign(value=lambda x: x["value"] * scale_factor)

print("Synthetic vs df1:\n", synthetic_agg_df1, "\nOriginal df1:\n", df1)
print(
    "Synthetic vs df2 (scaled):\n",
    synthetic_agg_df2,
    "\nOriginal df2 (scaled):\n",
    df2_scaled,
)

# Optional: Save synthetic population to CSV
synthetic_population.to_csv("synthetic_population_ctgan.csv", index=False)
