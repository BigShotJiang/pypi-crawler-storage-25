import pandas as pd
from process.data.utils import obtain_api_key
from process.data.data import obtain_data
from yaml import safe_load
from pandas import DataFrame
from sklearn.preprocessing import LabelEncoder
from sklearn.model_selection import train_test_split
from xgboost import XGBClassifier
import numpy as np
from pickle import dump as pickle_dump
from pickle import load as pickle_load
import itertools

# Open and load the YAML file
with open("config.yml", "r") as fid:
    cfg = safe_load(fid)


if "pop" not in cfg["tables"]:
    raise Exception("Base POP data is missing ...")

api_key = obtain_api_key(cfg)

df2 = obtain_data(cfg["tables"]["work"], api_key)

import pandas as pd
from pandas import DataFrame
from sklearn.preprocessing import LabelEncoder
from sklearn.model_selection import train_test_split
from xgboost import XGBClassifier
from sklearn.metrics import accuracy_score, confusion_matrix, classification_report


def model_train(
    df: DataFrame,
    deps_cols: list,
    target_cols: list,
    test_size: float = 0.2,
    random_state: None or int = None,
):
    """
    Train an XGBoost model with native categorical support to predict the probability
    of each (target_cols) combination given categorical features (deps_cols).

    Parameters
    ----------
    df : DataFrame
        Input data containing both predictor and target columns.
    deps_cols : list
        List of predictor (feature) column names.
    target_cols : list
        List of columns to combine into the target variable.
    test_size : float
        Fraction of data to use for testing.
    random_state : int or None
        Random seed for reproducibility.

    Returns
    -------
    probs_df : DataFrame
        Predicted probabilities for each target combination, with most likely label and probability.
    model : XGBClassifier
        Trained XGBoost model.
    target_encoder : LabelEncoder
        Encoder for decoding target labels.
    """

    # --- 1️⃣ Combine multiple target columns into one label string ---
    df = df.copy()  # avoid modifying original
    df = df.loc[df.index.repeat(df["value"])].copy()
    # df = df.drop(columns=["value"]).reset_index(drop=True)
    df["target"] = df[target_cols].astype(str).agg("_".join, axis=1)

    # --- 2️⃣ Encode the target (for multiclass numeric labels) ---
    target_encoder = LabelEncoder()
    df["target_encoded"] = target_encoder.fit_transform(df["target"])

    # --- 3️⃣ Convert dependent columns to categorical dtype ---
    for col in deps_cols:
        df[col] = df[col].astype("category")

    X = df[deps_cols + target_cols + ["value"]]
    y = df["target_encoded"]

    # --- 4️⃣ Split data ---
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=test_size, random_state=random_state
    )

    # --- 5️⃣ Train model with native categorical support ---
    model = XGBClassifier(
        objective="multi:softprob",
        eval_metric="mlogloss",
        tree_method="hist",  # required for categorical support
        enable_categorical=True,  # enables native handling of categories
        random_state=random_state,
        use_label_encoder=False,
    )

    model.fit(X_train[deps_cols], y_train)

    return {
        "model": model,
        "target_encoder": target_encoder,
        "test_data": {"x": X_test, "y": y_test},
        "deps_cols": deps_cols,
        "target_cols": target_cols,
    }


def model_predict(model, target_encoder, x_data):
    # --- 1. Predict probabilities ---
    probs = model.predict_proba(x_data)
    class_labels = target_encoder.classes_

    # --- 2. Build output dataframe ---
    probs_df = pd.DataFrame(probs, columns=class_labels)

    # probs_df = pd.concat([x_data, probs_df], axis=1)
    probs_df = pd.concat(
        [x_data.reset_index(drop=True), probs_df.reset_index(drop=True)], axis=1
    )
    return probs_df


def model_sample(df_probs, deps_cols, target_cols, n_samples=1, seed=None):
    """
    Vectorized sampling of industry/work_status per row based on probabilities.

    Parameters
    ----------
    df_probs : pd.DataFrame
        Wide format: feature columns + probability columns like A_1, A_2, etc.
        Must also contain 'most_likely' and 'max_prob' columns (ignored here).
    n_samples : int
        How many samples per row (default 1).
    seed : int or None
        Random seed for reproducibility.

    Returns
    -------
    pd.DataFrame
        Columns: age, gender, location, industry, work_status
    """
    if seed is not None:
        np.random.seed(seed)

    prob_cols = [c for c in df_probs.columns if c not in deps_cols]

    # Extract probabilities as NumPy array
    probs_array = df_probs[prob_cols].values.astype(float)
    probs_array = probs_array / probs_array.sum(axis=1, keepdims=True)  # normalize

    # Number of rows
    n_rows = df_probs.shape[0]

    # Repeat rows for n_samples
    repeated_features = np.repeat(df_probs[deps_cols].values, n_samples, axis=0)

    # Flatten probabilities for sampling
    sampled_cols = []
    for i in range(n_rows):
        sampled = np.random.choice(prob_cols, size=n_samples, p=probs_array[i])
        sampled_cols.extend(sampled)

    # Split industry/work_status
    sampled_cols = [s.split("_") for s in sampled_cols]
    sampled_cols = np.array(sampled_cols)

    # Combine features and sampled
    df_long = pd.DataFrame(
        np.hstack([repeated_features, sampled_cols]), columns=deps_cols + target_cols
    )

    """
    # Convert numeric columns back if needed
    df_long[["age", "gender", "location"]] = df_long[
        ["age", "gender", "location"]
    ].astype(df_probs[feature_cols].dtypes.to_dict())
    """
    return df_long


run_model_train = False
run_model_pred = False
run_postprocess = True

if run_model_train:
    model = model_train(
        df2,
        deps_cols=["age", "gender", "location"],
        target_cols=["industry", "work_status"],
    )
    pickle_dump(model, open("model.p", "wb"))

if run_model_pred:
    model = pickle_load(open("model.p", "rb"))
    pred = model_predict(
        model["model"],
        model["target_encoder"],
        model["test_data"]["x"][model["deps_cols"]],
    )

    pred = model_sample(pred, model["deps_cols"], model["target_cols"], n_samples=1)

    pickle_dump(pred, open("pred.p", "wb"))

if run_postprocess:

    model = pickle_load(open("model.p", "rb"))
    pred = pickle_load(open("pred.p", "rb"))

    truth = model["test_data"]["x"]

    group_cols = model["deps_cols"] + model["target_cols"]

    eval_dict = {col: [] for col in group_cols}
    eval_dict["pred"] = []
    eval_dict["truth"] = []

    # Get unique values for each column
    unique_vals = [pred[col].unique() for col in group_cols]

    # Iterate over all combinations
    for combination in itertools.product(*unique_vals):
        # Build boolean mask dynamically
        mask_pred = pd.Series(True, index=pred.index)
        mask_truth = pd.Series(True, index=truth.index)
        for col, val in zip(group_cols, combination):
            mask_pred &= pred[col] == val
            mask_truth &= truth[col] == val

        proc_pred = pred[mask_pred]
        proc_truth = truth[mask_truth]

        # Append combination values to eval_dict
        for col, val in zip(group_cols, combination):
            eval_dict[col].append(val)

        eval_dict["pred"].append(len(proc_pred))
        eval_dict["truth"].append(len(proc_truth))

    eval_dict = pd.DataFrame.from_dict(eval_dict)

    eval_dict.to_csv("eval.csv", index=False)
