import pandas as pd
import numpy as np
from yaml import safe_load
from process.data.utils import obtain_api_key
from process.data.data import obtain_data


def generate_synthetic_population(
    config_file, marginals=None, columns=None, max_iter=500, tol=1e-6
):
    """
    Generate a synthetic population from marginal data using Iterative Proportional Fitting (IPF).

    Parameters:
    - config_file (str): Path to the YAML configuration file.
    - marginals (pd.DataFrame, optional): Marginal table with categorical columns and 'value' column.
    - columns (list, optional): List of column names for categorical variables.
    - max_iter (int): Maximum iterations for IPF (default: 500).
    - tol (float): Convergence tolerance for IPF (default: 1e-6).

    Returns:
    - pd.DataFrame: Synthetic population in long format.
    """
    # Load configuration and API key
    with open(config_file, "r") as fid:
        cfg = safe_load(fid)
    api_key = obtain_api_key(cfg)

    # Obtain marginals if not provided
    if marginals is None:
        marginals = obtain_data(cfg["tables"]["pop"], api_key)

    # Validate inputs
    if columns is None:
        columns = [col for col in marginals.columns if col != "value"]
    if not all(col in marginals.columns for col in columns):
        raise ValueError("All specified columns must be in marginals DataFrame")
    if "value" not in marginals.columns:
        raise ValueError("Marginals DataFrame must contain a 'value' column")

    # Get unique levels for each categorical variable
    levels = [marginals[col].unique() for col in columns]
    index_mappings = [{val: i for i, val in enumerate(lvl)} for lvl in levels]

    # Initialize seed array with ones
    seed_shape = [len(lvl) for lvl in levels]
    seed = np.ones(seed_shape)

    # Initialize target array
    target = np.zeros_like(seed)

    # Fill target with marginal values
    for _, row in marginals.iterrows():
        indices = [index_mappings[i][row[col]] for i, col in enumerate(columns)]
        target[tuple(indices)] = row["value"]

    # IPF function
    def ipf(seed, target, max_iter, tol):
        estimate = seed.copy()
        mask = target > 0
        for _ in range(max_iter):
            scale = np.divide(target, estimate, out=np.ones_like(target), where=mask)
            new_estimate = estimate * scale
            if np.allclose(new_estimate, estimate, rtol=tol, atol=1):
                break
            estimate = new_estimate
        return estimate

    # Run IPF
    fitted = ipf(seed, target, max_iter, tol)

    # Flatten fitted array into long format
    records = []
    indices = np.ndindex(*seed_shape)
    for idx in indices:
        count = int(round(fitted[idx]))
        if count > 0:
            record = tuple(levels[i][idx[i]] for i in range(len(columns)))
            for _ in range(count):
                records.append(record)

    # Create DataFrame
    synthetic_pop = pd.DataFrame(records, columns=columns)

    return synthetic_pop


# Example usage
if __name__ == "__main__":
    # Example marginal table for testing
    """
    marginals = pd.DataFrame({
        "gender": [2, 3, 1, 1, 1],
        "location": ["09", "08", "06", "04", "07"],
        "ethnicity": ["411", "115", "211", "213", "223"],
        "age": [2, 4, 1, 1, 4],
        "value": [48, 0, 3462, 534, 0]
    })
    columns = ["gender", "location", "ethnicity", "age"]
    synthetic_pop = generate_synthetic_population("config.yml", marginals, columns)
    """
    synthetic_pop = generate_synthetic_population("config.yml")
    print("Synthetic population size:", len(synthetic_pop))
    print(synthetic_pop.head())
