"""Abstract base class for trajectory upload backends."""

from __future__ import annotations

from abc import abstractmethod
from typing import Any, List

from trajectory_sdk.primitives.primitives import Trajectory
from trajectory_sdk.utils.retry import Retryable


class BaseUpload(Retryable):
  """Contract for uploading trajectories to a remote backend."""

  def on_failure(self, exception: Exception, *args: Any, **kwargs: Any) -> Any:
    raise RuntimeError(f"Upload failed: {exception}") from exception

  @abstractmethod
  def upload(self, trajectories: List[Trajectory], dataset: str) -> None:
    """Upload a batch of trajectories to the backend."""
    ...

  def close(self) -> None:
    """Release any resources held by the backend."""
