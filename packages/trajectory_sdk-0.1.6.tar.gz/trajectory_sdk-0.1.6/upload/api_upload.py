"""HTTP API upload backend for trajectories."""

from __future__ import annotations

import json
import logging
from dataclasses import asdict
from typing import List

import requests

from trajectory_sdk.primitives.primitives import Trajectory
from trajectory_sdk.upload.base_upload import BaseUpload
from trajectory_sdk.utils.retry import NonRetryableError, sync_catch_and_retry

_log = logging.getLogger(__name__)

_RETRYABLE_STATUS_CODES = frozenset({429, 500, 502, 503, 504})


class ApiUpload(BaseUpload):
  """Upload trajectories to the Trajectory API over HTTP."""

  def __init__(self, api_base_url: str, api_key: str) -> None:
    self._url = f"{api_base_url.rstrip('/')}/api/v1/trajectories/upload"
    self._headers = {
      "X-API-Key": api_key,
      "Content-Type": "application/json",
    }

  @sync_catch_and_retry()
  def upload(self, trajectories: List[Trajectory], dataset: str) -> None:
    """Serialize trajectories and POST them to the upload API."""
    payload = json.dumps(
      {
        "dataset": dataset,
        "trajectories": [asdict(t) for t in trajectories],
      },
      default=str,
    )

    _log.info("Uploading %d trajectories to %s", len(trajectories), self._url)
    resp = requests.post(self._url, data=payload, headers=self._headers, timeout=120)

    if resp.status_code == 200:
      body = resp.json()
      _log.info(
        "Upload complete: %s",
        body.get("message", f"{len(trajectories)} trajectories accepted"),
      )
      return

    msg = f"Upload failed (HTTP {resp.status_code}): {resp.text}"
    if resp.status_code not in _RETRYABLE_STATUS_CODES:
      raise NonRetryableError(msg)
    raise RuntimeError(msg)
