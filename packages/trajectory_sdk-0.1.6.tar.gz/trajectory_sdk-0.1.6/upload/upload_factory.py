"""Factory for creating upload backend instances by name."""

from __future__ import annotations

from typing import Any

from trajectory_sdk.upload.base_upload import BaseUpload


class UploadFactory:
  """Create upload backend instances by name."""

  @staticmethod
  def create(name: str, **kwargs: Any) -> BaseUpload:
    """Instantiate an upload backend by name.

    Supported names:
      - ``"api"`` -- ApiUpload (requires ``api_base_url`` and ``api_key``)
    """
    if name == "api":
      from trajectory_sdk.upload.api_upload import ApiUpload

      return ApiUpload(
        api_base_url=kwargs["api_base_url"],
        api_key=kwargs["api_key"],
      )

    raise ValueError(f"Unknown upload backend: {name}")
