"""Orchestrate trajectory uploads via the Trajectory API."""

from __future__ import annotations

import json
import logging
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import asdict
from typing import Any, Dict, List

from trajectory_sdk.primitives.primitives import Trajectory
from trajectory_sdk.upload.api_upload import ApiUpload

logger = logging.getLogger(__name__)

_MAX_BATCH_BYTES = 128 * 1024 * 1024  # 128 MB
_MAX_BATCH_COUNT = 1000
_MAX_WORKERS = 8


class UploadManager:
  """Validates, batches by payload size, and uploads trajectories."""

  def __init__(self, api_base_url: str, api_key: str) -> None:
    self._backend = ApiUpload(api_base_url, api_key)

  def upload(self, trajectories: List[Trajectory], dataset: str) -> Dict[str, Any]:
    """Filter empty trajectories, batch by serialized size, and upload."""
    valid = [t for t in trajectories if t.steps and t.steps[-1].messages]
    skipped = len(trajectories) - len(valid)
    if skipped:
      logger.info("Skipping %d empty trajectories", skipped)

    if not valid:
      logger.warning("No valid trajectories to upload")
      return {"uploaded": 0, "skipped": skipped, "batches": 0, "elapsed_s": 0.0}

    batches = self._create_batches(valid)
    total = len(batches)

    logger.info(
      "Uploading %d trajectories in %d batch(es) to dataset '%s'",
      len(valid),
      total,
      dataset,
    )
    t0 = time.perf_counter()
    self._upload_batches(batches, dataset, total)
    elapsed = time.perf_counter() - t0

    logger.info("Upload complete: %d trajectories in %.1fs", len(valid), elapsed)
    return {
      "uploaded": len(valid),
      "skipped": skipped,
      "batches": total,
      "elapsed_s": round(elapsed, 2),
    }

  def _upload_batches(
    self,
    batches: List[List[Trajectory]],
    dataset: str,
    total: int,
  ) -> None:
    """Upload batches concurrently, raising the first error encountered."""
    errors: list[Exception] = []

    with ThreadPoolExecutor(max_workers=min(_MAX_WORKERS, total)) as pool:
      futures = {
        pool.submit(self._backend.upload, batch, dataset): i for i, batch in enumerate(batches, 1)
      }
      for future in as_completed(futures):
        batch_num = futures[future]
        try:
          future.result()
          logger.info("Batch %d/%d uploaded", batch_num, total)
        except Exception as exc:
          logger.error("Batch %d/%d failed: %s", batch_num, total, exc)
          errors.append(exc)

    if errors:
      raise errors[0]

  def _create_batches(
    self,
    trajectories: List[Trajectory],
  ) -> List[List[Trajectory]]:
    """Split trajectories into batches respecting byte-size and count limits.

    A single trajectory that exceeds the byte limit is sent alone (never dropped).
    """
    sizes = [len(json.dumps(asdict(t), default=str)) for t in trajectories]

    batches: List[List[Trajectory]] = []
    current_batch: List[Trajectory] = []
    current_bytes = 0

    for traj, size in zip(trajectories, sizes):
      if current_batch and (
        current_bytes + size > _MAX_BATCH_BYTES or len(current_batch) >= _MAX_BATCH_COUNT
      ):
        batches.append(current_batch)
        current_batch = []
        current_bytes = 0

      current_batch.append(traj)
      current_bytes += size

    if current_batch:
      batches.append(current_batch)

    return batches
