"""Factory for creating provider instances by name."""

from __future__ import annotations

from typing import Any, Optional

from trajectory_sdk.providers.base_provider import BaseProvider


class ProviderFactory:
  """Create provider instances by name."""

  @staticmethod
  def create(
    name: str,
    api_key: str,
    project_id: str,
    *,
    workspace_id: Optional[str] = None,
    **kwargs: Any,
  ) -> BaseProvider:
    """Instantiate a provider by name.

    Supported names:
      - ``"langsmith"`` -- LangSmithProvider
    """
    if name == "langsmith":
      from trajectory_sdk.providers.langsmith_provider import LangSmithProvider

      return LangSmithProvider(api_key, project_id, workspace_id=workspace_id)

    raise ValueError(f"Unknown provider: {name}")
