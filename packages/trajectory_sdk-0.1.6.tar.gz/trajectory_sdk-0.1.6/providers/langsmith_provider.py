"""LangSmith provider -- all LangSmith API, parsing, bulk import, and export logic."""

from __future__ import annotations

import hashlib
import json
import logging
import math
import os
import tempfile
import time
from collections import defaultdict
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass, field, replace
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Sequence

import requests
from langsmith import Client
from langsmith.schemas import Run, TracerSessionResult

from trajectory_sdk.primitives.primitives import (
  ConversationSummary,
  Message,
  ParsedConversation,
  ParsedTurn,
  ToolCall,
  ToolDefinition,
  ToolResponse,
  Trajectory,
)
from trajectory_sdk.providers.base_provider import BaseProvider

_log = logging.getLogger(__name__)

TARGET_PROJECT_ID = "1622a52a-74c0-42e1-ab83-1d7219a4bd89"
CACHE_TTL_SECONDS = 300
LANGSMITH_API_BASE = "https://api.smith.langchain.com"

# ---------------------------------------------------------------------------
# Module-level constants
# ---------------------------------------------------------------------------

_STR_FIELDS = (
  "id",
  "parent_run_id",
  "trace_id",
  "session_id",
  "first_token_time",
  "reference_example_id",
)

_PASSTHRU_FIELDS = (
  "name",
  "run_type",
  "status",
  "error",
  "parent_run_ids",
  "metadata",
  "tags",
  "feedback_stats",
  "total_tokens",
  "prompt_tokens",
  "completion_tokens",
  "total_cost",
  "prompt_cost",
  "completion_cost",
  "inputs",
  "outputs",
  "extra",
  "events",
  "serialized",
  "dotted_order",
)

_CANONICAL_ROLES = {"system", "user", "assistant", "tool"}

_ROLE_MAP: Dict[str, str] = {
  "human": "user",
  "ai": "assistant",
  "AIMessage": "assistant",
  "AIMessageChunk": "assistant",
  "HumanMessage": "user",
  "SystemMessage": "system",
  "ToolMessage": "tool",
  "FunctionMessage": "tool",
  "function": "tool",
}

_SUB_LLM_JUNK_KEYS = frozenset(
  {
    "isSufficient",
    "selectedOptions",
    "inputsBinding",
    "toolName",
    "suggestedUseCase",
    "suggestModelReasoning",
    "fieldContexts",
    "fieldSelection",
    "suggestionDescription",
    "taskDescription",
    "additionalContext",
    "confidence",
    "fieldId",
  }
)

_SELECT_FIELDS = [
  "id",
  "name",
  "run_type",
  "start_time",
  "end_time",
  "status",
  "error",
  "extra",
  "events",
  "inputs",
  "outputs",
  "serialized",
  "parent_run_id",
  "trace_id",
  "session_id",
  "dotted_order",
  "first_token_time",
  "reference_example_id",
  "total_tokens",
  "prompt_tokens",
  "completion_tokens",
  "total_cost",
  "prompt_cost",
  "completion_cost",
  "feedback_stats",
  "tags",
]

# ---------------------------------------------------------------------------
# Module-level data holder (not a helper function)
# ---------------------------------------------------------------------------


@dataclass
class _TurnCollector:
  all_messages: List[Message] = field(default_factory=list)
  _seen_system: bool = field(default=False, repr=False)
  error: Optional[str] = None
  last_llm_run_id: Optional[str] = None
  tool_ordinal: int = 0
  found_llm_run: bool = False

  def add(self, msg: Message) -> None:
    if msg.role == "system" and not self._seen_system:
      self._seen_system = True
    self.all_messages.append(msg)

  def capture_error(self, err: Optional[str]) -> None:
    if err and self.error is None:
      self.error = err


# ---------------------------------------------------------------------------
# Bulk import: multiprocessing shared state + workers (must be module-level)
# ---------------------------------------------------------------------------

_NEEDED_COLS = [
  "id",
  "name",
  "run_type",
  "error",
  "inputs",
  "outputs",
  "extra",
  "start_time",
  "end_time",
  "dotted_order",
  "trace_id",
  "parent_run_id",
  "is_root",
  "total_tokens",
  "prompt_tokens",
  "completion_tokens",
  "total_cost",
  "status",
]

_JSON_FIELDS = frozenset({"inputs", "outputs", "extra"})
_NULLABLE_FIELDS = frozenset({"error", "parent_run_id", "trace_id"})

_shared_table = None
_shared_conv_indices: Dict[str, List[int]] = {}


def _init_worker(table: Any, conv_indices: Dict[str, List[int]]) -> None:
  global _shared_table, _shared_conv_indices
  _shared_table = table
  _shared_conv_indices = conv_indices


try:
  import orjson as _json_mod

  def _loads(v: str) -> Any:
    return _json_mod.loads(v)

except ImportError:
  import json as _json_mod  # type: ignore[no-redef]

  def _loads(v: str) -> Any:  # type: ignore[misc]
    return _json_mod.loads(v)  # type: ignore[union-attr]


def _parse_json(value: Any) -> Any:
  if value is None:
    return None
  if isinstance(value, float) and math.isnan(value):
    return None
  if isinstance(value, str):
    try:
      return _loads(value)
    except Exception:
      return value
  return value


def _process_row(row: dict) -> dict:
  """Parse JSON columns and extract metadata from a raw parquet row."""
  for col in _JSON_FIELDS:
    if col in row:
      row[col] = _parse_json(row[col])
  for col in _NULLABLE_FIELDS:
    v = row.get(col)
    if isinstance(v, float) and math.isnan(v):
      row[col] = None
  for ts_col in ("start_time", "end_time"):
    val = row.get(ts_col)
    if val is not None and not isinstance(val, str):
      row[ts_col] = str(val)

  extra = row.get("extra")
  row["metadata"] = extra.get("metadata", {}) if isinstance(extra, dict) else {}
  return row


def _rows_to_tree(rows: List[dict]) -> List[dict]:
  """Build parent-child run tree from flat rows."""
  by_id: Dict[str, dict] = {}
  for row in rows:
    node = dict(row)
    node["children"] = []
    by_id[node["id"]] = node

  roots: List[dict] = []
  for node in by_id.values():
    pid = node.get("parent_run_id")
    if pid and pid in by_id:
      by_id[pid]["children"].append(node)
    else:
      roots.append(node)
  return roots


def _build_thread_payload(conv_id: str, runs: List[dict]) -> dict:
  """Build raw thread dict compatible with LangSmithProvider.parse_conversation()."""
  traces: Dict[str, List[dict]] = defaultdict(list)
  for run in runs:
    traces[run.get("trace_id") or run.get("id") or "unknown"].append(run)

  turns: List[dict] = []
  for trace_id, trace_runs in traces.items():
    root_rows = [r for r in trace_runs if r.get("is_root")]
    root = root_rows[0] if root_rows else trace_runs[0]

    turns.append(
      {
        "trace_id": trace_id,
        "start_time": root.get("start_time"),
        "end_time": root.get("end_time"),
        "num_runs": len(trace_runs),
        "runs": _rows_to_tree(trace_runs),
      }
    )

  turns.sort(key=lambda t: t.get("start_time") or "")

  return {
    "conversation_id": conv_id,
    "num_turns": len(turns),
    "total_runs": sum(t["num_runs"] for t in turns),
    "turns": turns,
  }


def _worker_process_conversation(conv_id: str) -> Any:
  """Extract rows from the shared arrow table, parse JSON, build trajectory."""
  indices = _shared_conv_indices[conv_id]
  sub = _shared_table.take(indices)
  rows = sub.to_pylist()
  for row in rows:
    _process_row(row)

  payload = _build_thread_payload(conv_id, rows)
  try:
    provider = LangSmithProvider(api_key="", project_id="")
    parsed = provider.parse_conversation(payload)
    return provider._build_trajectory(parsed)
  except Exception as e:
    _log.warning("Failed to convert %s: %s", conv_id, e)
    return None


def _sequential_import(
  table: Any,
  conv_indices: Dict[str, List[int]],
  conv_ids: List[str],
) -> List[Any]:
  provider = LangSmithProvider(api_key="", project_id="")
  trajectories = []

  for cid in conv_ids:
    sub = table.take(conv_indices[cid])
    rows = sub.to_pylist()
    for row in rows:
      _process_row(row)

    payload = _build_thread_payload(cid, rows)
    try:
      parsed = provider.parse_conversation(payload)
      trajectories.append(provider._build_trajectory(parsed))
    except Exception as e:
      _log.warning("Failed to convert %s: %s", cid, e)

  return trajectories


# ---------------------------------------------------------------------------
# Module-level cache
# ---------------------------------------------------------------------------

_conversation_cache: dict[tuple[str, str], tuple[float, dict]] = {}


# ---------------------------------------------------------------------------
# Provider
# ---------------------------------------------------------------------------


class LangSmithProvider(BaseProvider):
  """LangSmith trace provider with integrated bulk import and export."""

  def __init__(
    self,
    api_key: str,
    project_id: str,
    workspace_id: Optional[str] = None,
  ) -> None:
    super().__init__(api_key, project_id)
    self.workspace_id = workspace_id
    self._resolved_project_id: Optional[str] = None
    self._client_headers: dict[str, str] = {"x-tenant-id": workspace_id} if workspace_id else {}

  # ------------------------------------------------------------------
  # Static helpers -- dict conversion
  # ------------------------------------------------------------------

  @staticmethod
  def _str_or_none(val: Any) -> Optional[str]:
    return str(val) if val is not None else None

  @staticmethod
  def _run_to_dict(run: Run) -> dict:
    """Convert a LangSmith Run object to a plain dictionary."""
    d = {k: LangSmithProvider._str_or_none(getattr(run, k, None)) for k in _STR_FIELDS}
    d.update({k: getattr(run, k, None) for k in _PASSTHRU_FIELDS})
    d["start_time"] = str(run.start_time) if run.start_time else None
    d["end_time"] = str(run.end_time) if run.end_time else None
    return d

  @staticmethod
  def _project_to_dict(p: TracerSessionResult) -> dict:
    """Convert a LangSmith project object to a plain dictionary."""
    return {
      "id": str(p.id),
      "name": p.name,
      "description": getattr(p, "description", None),
      "run_count": getattr(p, "run_count", None),
    }

  # ------------------------------------------------------------------
  # Static helpers -- trace tree construction
  # ------------------------------------------------------------------

  @staticmethod
  def _build_full_trace(all_runs: Sequence[Run]) -> list[dict]:
    """Build a run tree from a flat list of runs using a parent-child hashmap. O(n)."""
    nodes_by_id: dict[str, dict] = {}
    for run in all_runs:
      node = LangSmithProvider._run_to_dict(run)
      node["children"] = []
      nodes_by_id[node["id"]] = node

    roots = []
    for node in nodes_by_id.values():
      parent_id = node["parent_run_id"]
      if parent_id and parent_id in nodes_by_id:
        nodes_by_id[parent_id]["children"].append(node)
      else:
        roots.append(node)

    return roots

  # ------------------------------------------------------------------
  # Static helpers -- message extraction
  # ------------------------------------------------------------------

  @staticmethod
  def _normalise_role(raw: str) -> str:
    return raw if raw in _CANONICAL_ROLES else _ROLE_MAP.get(raw, "assistant")

  @staticmethod
  def _is_llm_run(run: dict) -> bool:
    return run.get("run_type") in {"llm", "chat_model"}

  @staticmethod
  def _is_tool_run(run: dict) -> bool:
    return run.get("run_type") == "tool"

  @staticmethod
  def _content_to_str(content: Any) -> Optional[str]:
    if content is None:
      return None
    if isinstance(content, str):
      return content
    if isinstance(content, list):
      parts: List[str] = []
      for block in content:
        if isinstance(block, str):
          parts.append(block)
        elif isinstance(block, dict):
          text = block.get("text")
          if text:
            parts.append(str(text))
      return "".join(parts) or None
    return str(content)

  @staticmethod
  def _unwrap_messages(raw: Any) -> List[dict]:
    if not isinstance(raw, list):
      return []
    if raw and isinstance(raw[0], list):
      raw = raw[0]
    return [m for m in raw if isinstance(m, dict)]

  @staticmethod
  def _parse_arguments(args: Any) -> Dict[str, Any]:
    if args is None:
      return {}
    if isinstance(args, dict):
      return args
    if isinstance(args, str):
      try:
        parsed = json.loads(args)
        if isinstance(parsed, dict):
          return parsed
      except (json.JSONDecodeError, TypeError):
        pass
      return {"raw": args}
    return {"raw": str(args)}

  @staticmethod
  def _first_str(d: dict, *keys: str) -> Optional[str]:
    for k in keys:
      v = d.get(k)
      if isinstance(v, str):
        return v
    return None

  @staticmethod
  def _extract_tool_calls_from_message(message: dict) -> List[ToolCall]:
    tool_calls: List[ToolCall] = []

    raw_calls = message.get("tool_calls") or message.get("additional_kwargs", {}).get("tool_calls")
    if raw_calls and isinstance(raw_calls, list):
      for tc in raw_calls:
        if not isinstance(tc, dict):
          continue
        func = tc.get("function") or {}
        name = func.get("name") or tc.get("name") or "unknown"
        args = func.get("arguments") or tc.get("args") or tc.get("arguments")
        tool_calls.append(
          ToolCall(
            name=name,
            arguments=LangSmithProvider._parse_arguments(args),
            id=tc.get("id"),
          )
        )
      return tool_calls

    fc = message.get("function_call") or message.get("additional_kwargs", {}).get("function_call")
    if fc and isinstance(fc, dict):
      tool_calls.append(
        ToolCall(
          name=fc.get("name", "unknown"),
          arguments=LangSmithProvider._parse_arguments(fc.get("arguments")),
          id=None,
        )
      )

    return tool_calls

  @staticmethod
  def _extract_tool_definitions(run: dict) -> List[ToolDefinition]:
    """Extract tool/function definitions from an LLM run's inputs or invocation params."""
    inputs = run.get("inputs") or {}
    extra = run.get("extra") or {}
    invocation_params = extra.get("invocation_params") or {}

    raw_tools = inputs.get("tools") or invocation_params.get("tools")

    if not raw_tools:
      args_list = inputs.get("args")
      if isinstance(args_list, list) and args_list and isinstance(args_list[0], dict):
        raw_tools = args_list[0].get("tools")

    if isinstance(raw_tools, dict):
      defs: List[ToolDefinition] = []
      for name, defn in raw_tools.items():
        if isinstance(defn, dict):
          defs.append(
            ToolDefinition(
              name=name,
              description=defn.get("description", ""),
              parameters=defn.get("parameters") or defn.get("inputSchema") or {},
            )
          )
      if defs:
        return defs

    if isinstance(raw_tools, list):
      defs = []
      for tool in raw_tools:
        if not isinstance(tool, dict):
          continue
        func = tool.get("function") or tool
        name = func.get("name")
        if name:
          defs.append(
            ToolDefinition(
              name=name,
              description=func.get("description", ""),
              parameters=func.get("parameters") or func.get("inputSchema") or {},
            )
          )
      if defs:
        return defs

    raw_fns = inputs.get("functions") or invocation_params.get("functions")
    if isinstance(raw_fns, list):
      defs = []
      for func in raw_fns:
        if not isinstance(func, dict):
          continue
        name = func.get("name")
        if name:
          defs.append(
            ToolDefinition(
              name=name,
              description=func.get("description", ""),
              parameters=func.get("parameters") or func.get("inputSchema") or {},
            )
          )
      if defs:
        return defs

    return []

  @staticmethod
  def _extract_tool_defs_from_message(message: dict) -> Optional[List[ToolDefinition]]:
    """Extract tool definitions embedded directly on a message dict."""
    raw_defs = message.get("tool_definitions")
    if not isinstance(raw_defs, list) or not raw_defs:
      return None
    defs: List[ToolDefinition] = []
    for td in raw_defs:
      if not isinstance(td, dict):
        continue
      name = td.get("name")
      if name:
        defs.append(
          ToolDefinition(
            name=name,
            description=td.get("description", ""),
            parameters=td.get("parameters") or td.get("inputSchema") or {},
          )
        )
    return defs or None

  @staticmethod
  def _messages_from_dicts(raw: Any, default_role: str = "user") -> List[Message]:
    return [
      Message(
        role=LangSmithProvider._normalise_role(m.get("role") or m.get("type") or default_role),
        content=LangSmithProvider._content_to_str(m.get("content")),
        tool_calls=LangSmithProvider._extract_tool_calls_from_message(m) or None,
        tool_definitions=LangSmithProvider._extract_tool_defs_from_message(m),
      )
      for m in LangSmithProvider._unwrap_messages(raw)
    ]

  @staticmethod
  def _extract_input_messages(inputs: dict) -> List[Message]:
    raw_msgs = inputs.get("messages")
    if raw_msgs is not None:
      msgs = LangSmithProvider._messages_from_dicts(raw_msgs, default_role="user")
      if msgs:
        return msgs

    messages: List[Message] = []
    chat_history = inputs.get("chat_history")
    if isinstance(chat_history, list):
      messages.extend(LangSmithProvider._messages_from_dicts(chat_history, default_role="user"))

    user_text = inputs.get("input") or inputs.get("prompt")
    if isinstance(user_text, str):
      messages.append(Message(role="user", content=user_text))
      return messages

    prompts = inputs.get("prompts")
    if isinstance(prompts, list) and prompts:
      for p in prompts:
        messages.append(Message(role="user", content=str(p)))
      return messages

    return messages

  @staticmethod
  def _extract_output_messages(outputs: dict) -> List[Message]:
    generations = outputs.get("generations")
    if isinstance(generations, list) and generations:
      gen_list = generations[0] if generations and isinstance(generations[0], list) else generations
      messages: List[Message] = []
      for gen in gen_list:
        if not isinstance(gen, dict):
          continue
        msg = gen.get("message")
        if isinstance(msg, dict):
          content = LangSmithProvider._content_to_str(msg.get("content"))
          tc = LangSmithProvider._extract_tool_calls_from_message(msg)
          messages.append(
            Message(
              role="assistant",
              content=content,
              tool_calls=tc if tc else None,
            )
          )
        else:
          text = gen.get("text")
          if text:
            messages.append(Message(role="assistant", content=str(text)))
      if messages:
        return messages

    output_obj = outputs.get("output")
    if isinstance(output_obj, dict):
      content = LangSmithProvider._content_to_str(output_obj.get("content"))
      tc = LangSmithProvider._extract_tool_calls_from_message(output_obj)
      return [Message(role="assistant", content=content, tool_calls=tc if tc else None)]

    if isinstance(output_obj, str):
      return [Message(role="assistant", content=output_obj)]

    if "content" in outputs:
      tc = LangSmithProvider._extract_tool_calls_from_message(outputs)
      return [
        Message(
          role="assistant",
          content=LangSmithProvider._content_to_str(outputs["content"]),
          tool_calls=tc or None,
        )
      ]

    return []

  @staticmethod
  def _extract_tool_response(
    run: dict,
    parent_llm_run_id: Optional[str],
    ordinal: int,
  ) -> Message:
    outputs = run.get("outputs") or {}
    inputs = run.get("inputs") or {}
    metadata = run.get("metadata") or {}
    tool_name = run.get("name") or "unknown_tool"

    response = LangSmithProvider._content_to_str(
      outputs.get("output") or outputs.get("result") or outputs.get("response")
    )
    error = run.get("error") or outputs.get("error")
    if response is None and not error and outputs:
      response = json.dumps(outputs)

    if response is None and not error:
      response = "{}"

    args_list = inputs.get("args")
    if isinstance(args_list, list) and len(args_list) >= 2 and isinstance(args_list[1], dict):
      tool_args = args_list[0] if isinstance(args_list[0], dict) else {}
      tc_id_from_input = args_list[1].get("toolCallId")
    else:
      tool_args = {k: v for k, v in inputs.items() if k != "tool_call_id"}
      tc_id_from_input = inputs.get("tool_call_id")

    tool_call_id = (
      metadata.get("tool_call_id")
      or tc_id_from_input
      or f"{parent_llm_run_id or 'root'}:{tool_name}:{ordinal}"
    )

    tool_response = ToolResponse(
      id=tool_call_id,
      name=tool_name,
      arguments=tool_args,
      response=None if error else response,
      error=error,
    )

    return Message(role="tool", tool_response=tool_response)

  @staticmethod
  def _is_inside_tool_impl(run: dict, id_to_run: Dict[str, dict]) -> bool:
    """Check if a run is nested inside a tool implementation (i.e. it's a sub-LLM)."""
    parent_id = run.get("parent_run_id")
    while parent_id and parent_id in id_to_run:
      parent = id_to_run[parent_id]
      if LangSmithProvider._is_tool_run(parent) or (parent.get("name") or "").startswith("tool:"):
        return True
      parent_id = parent.get("parent_run_id")
    return False

  @staticmethod
  def _is_sub_llm_junk_content(content: Optional[str]) -> bool:
    """Catch sub-LLM outputs that slipped through tree-aware filtering."""
    if not content:
      return False
    stripped = content.strip()
    if not stripped.startswith("{"):
      return False
    try:
      data = json.loads(stripped)
    except (json.JSONDecodeError, TypeError):
      return False
    if not isinstance(data, dict):
      return False
    return bool(frozenset(data.keys()) & _SUB_LLM_JUNK_KEYS)

  @staticmethod
  def _clean_conversation_messages(all_messages: List[Message]) -> List[Message]:
    """Clean up multi-turn artifacts from the combined message list."""
    if not all_messages:
      return all_messages

    seen: set[str] = set()
    result: List[Message] = []

    for msg in all_messages:
      content = msg.content or ""

      if msg.is_empty() or LangSmithProvider._is_sub_llm_junk_content(content):
        continue

      if msg.role in ("user", "assistant"):
        dedup_parts = [content]
        if msg.tool_calls:
          dedup_parts.extend(f"{tc.name}:{tc.id}" for tc in msg.tool_calls)
        h = hashlib.md5("|".join(dedup_parts).encode()).hexdigest()
        if h in seen:
          continue
        seen.add(h)

      result.append(msg)

    changed = True
    while changed:
      cleaned: List[Message] = []
      changed = False
      for i, msg in enumerate(result):
        if (
          i < len(result) - 1
          and msg.role == "assistant"
          and not msg.tool_calls
          and msg.content
          and not msg.content.strip().startswith("{")
          and result[i + 1].role == "assistant"
          and result[i + 1].tool_calls
        ):
          changed = True
          continue
        cleaned.append(msg)
      result = cleaned

    pending_calls = 0
    final: List[Message] = []
    for msg in result:
      if msg.role == "assistant" and msg.tool_calls:
        pending_calls += len(msg.tool_calls)
      if msg.role == "tool" and msg.tool_response:
        if pending_calls > 0:
          pending_calls -= 1
          final.append(msg)
      else:
        final.append(msg)

    return final

  @staticmethod
  def _clean_expired_cache() -> None:
    now = time.time()
    expired = [k for k, (ts, _) in _conversation_cache.items() if now - ts >= CACHE_TTL_SECONDS]
    for k in expired:
      del _conversation_cache[k]

  # ------------------------------------------------------------------
  # Instance helpers -- turn parsing and trace fetching
  # ------------------------------------------------------------------

  def _parse_single_turn(self, turn_payload: dict) -> ParsedTurn:
    raw_runs: List[dict] = turn_payload.get("runs") or []

    flat_runs = self.flatten_run_tree(raw_runs)
    flat_runs.sort(key=self.run_sort_key)

    token_counts = self.aggregate_tokens(flat_runs)
    total_cost = self.aggregate_cost(flat_runs)

    id_to_run: Dict[str, dict] = {r.get("id", ""): r for r in flat_runs if r.get("id")}
    flat_runs = [r for r in flat_runs if not self._is_inside_tool_impl(r, id_to_run)]

    col = _TurnCollector()

    for run in flat_runs:
      col.capture_error(run.get("error"))

      if self._is_llm_run(run):
        if not col.found_llm_run:
          col.found_llm_run = True
          input_msgs = self._extract_input_messages(run.get("inputs") or {})
          tool_defs = self._extract_tool_definitions(run)
          if tool_defs and input_msgs:
            input_msgs[0] = replace(input_msgs[0], tool_definitions=tool_defs)
          for msg in input_msgs:
            col.add(msg)
        col.last_llm_run_id = run.get("id")
        col.tool_ordinal = 0
        for msg in self._extract_output_messages(run.get("outputs") or {}):
          col.add(msg)

      elif self._is_tool_run(run):
        col.tool_ordinal += 1
        col.add(self._extract_tool_response(run, col.last_llm_run_id, col.tool_ordinal))

    if not col.found_llm_run and raw_runs:
      root = raw_runs[0]
      root_inputs = root.get("inputs") or {}
      root_outputs = root.get("outputs") or {}

      user_text = self._first_str(
        root_inputs, "input", "prompt", "query", "question", "userMessage"
      )
      if user_text:
        col.add(Message(role="user", content=user_text))

      assistant_text = (
        root_outputs.get("output")
        or root_outputs.get("result")
        or root_outputs.get("answer")
        or root_outputs.get("response")
      )
      if isinstance(assistant_text, str):
        col.add(Message(role="assistant", content=assistant_text))
      elif isinstance(assistant_text, dict):
        content = self._content_to_str(assistant_text.get("content"))
        if content:
          col.add(Message(role="assistant", content=content))

    return ParsedTurn(
      messages=col.all_messages,
      source_run_id=turn_payload.get("trace_id", ""),
      start_time=turn_payload.get("start_time"),
      end_time=turn_payload.get("end_time"),
      error=col.error,
      token_counts=token_counts,
      total_cost=total_cost if total_cost > 0 else None,
    )

  def _fetch_single_trace(self, client: Client, trace_id: str) -> dict:
    """Fetch all runs for a single trace with full details in one API call."""
    full_runs = list(client.list_runs(trace_id=trace_id, select=_SELECT_FIELDS))

    root = next((r for r in full_runs if not getattr(r, "parent_run_id", None)), None)
    return {
      "trace_id": trace_id,
      "start_time": str(root.start_time) if root and root.start_time else None,
      "end_time": str(root.end_time) if root and root.end_time else None,
      "num_runs": len(full_runs),
      "runs": self._build_full_trace(full_runs),
    }

  def _fetch_traces_parallel(self, client: Client, trace_ids: list[str]) -> list[dict]:
    """Fetch traces in parallel with automatic retry of failures."""
    results: list[dict] = []
    failed: list[str] = []
    with ThreadPoolExecutor(max_workers=min(len(trace_ids), 64)) as executor:
      futures = {executor.submit(self._fetch_single_trace, client, tid): tid for tid in trace_ids}
      for future in as_completed(futures):
        try:
          results.append(future.result())
        except Exception:
          failed.append(futures[future])

    for tid in failed:
      try:
        time.sleep(0.5)
        results.append(self._fetch_single_trace(client, tid))
      except Exception:
        _log.debug("Retry failed for trace %s", tid)

    return results

  # ------------------------------------------------------------------
  # Bulk export helpers (instance methods using self.api_key etc.)
  # ------------------------------------------------------------------

  def _langsmith_headers(self) -> dict[str, str]:
    """Build standard headers for LangSmith bulk-export REST calls."""
    return {
      "Content-Type": "application/json",
      "X-API-Key": self.api_key,
      "X-Tenant-Id": self.workspace_id or "",
    }

  def _trigger_bulk_export(
    self,
    destination_id: str,
    start_time: datetime,
    end_time: datetime,
  ) -> str:
    """Create a bulk export job scoped by session (project) and time range.

    The LangSmith bulk export API's ``session_id`` captures all runs
    (root and child) in the project. No ``in(trace_id, ...)`` filter is
    needed -- ``session_id`` + time range is sufficient.
    """
    url = f"{LANGSMITH_API_BASE}/api/v1/bulk-exports"
    headers = self._langsmith_headers()

    data = {
      "bulk_export_destination_id": destination_id,
      "session_id": self.project_id,
      "format_version": "v2_beta",
      "start_time": start_time.isoformat().replace("+00:00", "Z"),
      "end_time": end_time.isoformat().replace("+00:00", "Z"),
    }

    _log.info(
      "Creating bulk export for project %s (%s to %s) ...",
      self.project_id,
      data["start_time"],
      data["end_time"],
    )
    resp = requests.post(url, headers=headers, json=data)
    resp.raise_for_status()

    result = resp.json()
    export_id: str = result["id"]
    _log.info("Bulk export created: %s", export_id)
    return export_id

  def _poll_for_completion(self, export_id: str, poll_interval: float = 5.0) -> None:
    """Block until the bulk export finishes (or raises on failure)."""
    url = f"{LANGSMITH_API_BASE}/api/v1/bulk-exports/{export_id}"
    headers = self._langsmith_headers()

    _log.info("Polling export %s for completion ...", export_id)
    while True:
      resp = requests.get(url, headers=headers)
      resp.raise_for_status()
      status = resp.json()["status"]

      if status == "Completed":
        _log.info("Export completed successfully")
        return
      if status == "Failed":
        raise RuntimeError(f"Bulk export failed: {resp.json()}")

      _log.info("  status=%s, waiting %.0fs ...", status, poll_interval)
      time.sleep(poll_interval)

  def _download_parquet(self, export_id: str, output_path: Optional[str] = None) -> str:
    """Download the exported parquet file(s) from GCS."""
    headers = {"X-API-Key": self.api_key, "X-Tenant-Id": self.workspace_id or ""}

    _log.info("Fetching export run metadata for %s ...", export_id)
    resp = requests.get(
      f"{LANGSMITH_API_BASE}/api/v1/bulk-exports/{export_id}/runs",
      headers=headers,
    )
    resp.raise_for_status()
    runs = resp.json()

    parquet_files: List[str] = []
    for run in runs:
      metadata = run.get("metadata") or {}
      result = metadata.get("result") or {}
      parquet_files.extend(result.get("exported_files", []))

    if not parquet_files:
      raise RuntimeError(f"No parquet files found in export {export_id}")

    _log.info("Found %d parquet file(s) to download", len(parquet_files))

    if output_path is None:
      output_path = os.path.join(tempfile.gettempdir(), f"export_{export_id}.parquet")

    first_file = parquet_files[0]
    bucket_name = first_file.split("/")[0]
    _log.info("Downloading from GCS bucket: %s", bucket_name)

    from google.cloud import storage as gcs_storage

    gcs_client = gcs_storage.Client()
    bucket = gcs_client.bucket(bucket_name)

    if len(parquet_files) == 1:
      blob_path = "/".join(first_file.split("/")[1:])
      _log.info("Downloading gs://%s/%s", bucket_name, blob_path)
      bucket.blob(blob_path).download_to_filename(output_path)
    else:
      import pyarrow
      import pyarrow.parquet as pq

      tables = []
      for pf in parquet_files:
        blob_path = "/".join(pf.split("/")[1:])
        local = output_path + f".part{len(tables)}"
        _log.info("Downloading gs://%s/%s", bucket_name, blob_path)
        bucket.blob(blob_path).download_to_filename(local)
        tables.append(pq.read_table(local))
        os.remove(local)

      merged = pyarrow.concat_tables(tables)
      pq.write_table(merged, output_path)

    _log.info("Saved parquet to %s", output_path)
    return output_path

  def _run_bulk_export(
    self,
    destination_id: str,
    start_time: datetime,
    end_time: datetime,
    output_path: Optional[str] = None,
  ) -> str:
    """Full pipeline: trigger export -> poll -> download."""
    export_id = self._trigger_bulk_export(destination_id, start_time, end_time)
    self._poll_for_completion(export_id)
    return self._download_parquet(export_id, output_path)

  @staticmethod
  def _import_from_parquet(
    path: str,
    *,
    limit: Optional[int] = None,
    max_workers: Optional[int] = None,
  ) -> list:
    """Import trajectories from a LangSmith parquet export."""
    try:
      import pyarrow.parquet as pq
    except ImportError as exc:
      raise ImportError(
        "pyarrow is required for parquet imports. "
        'Install with: pip install "trajectory-sdk[parquet]"'
      ) from exc

    _log.info("Loading parquet: %s", path)
    table = pq.read_table(path, columns=_NEEDED_COLS)
    _log.info("Read %d rows", table.num_rows)

    extra_list = table.column("extra").to_pylist()
    trace_id_list = table.column("trace_id").to_pylist()
    id_list = table.column("id").to_pylist()

    trace_to_conv: Dict[str, str] = {}
    row_conv_ids: List[Optional[str]] = [None] * table.num_rows

    for i in range(table.num_rows):
      cid = None
      ev = extra_list[i]
      if isinstance(ev, str):
        try:
          ex = _loads(ev)
          md = ex.get("metadata", {})
          if isinstance(md, dict):
            cid = md.get("conversation_id")
        except Exception:
          pass
      if cid:
        row_conv_ids[i] = cid
        tid = trace_id_list[i]
        is_nan = isinstance(tid, float) and math.isnan(tid)
        if tid and not is_nan:
          trace_to_conv[str(tid)] = cid

    conv_indices: Dict[str, List[int]] = defaultdict(list)
    for i in range(table.num_rows):
      cid = row_conv_ids[i]
      if not cid:
        tid = trace_id_list[i]
        is_nan = isinstance(tid, float) and math.isnan(tid)
        tid_str = str(tid) if tid and not is_nan else None
        cid = trace_to_conv.get(tid_str) if tid_str else None
      if not cid:
        tid = trace_id_list[i]
        is_nan = isinstance(tid, float) and math.isnan(tid)
        cid = tid if tid and not is_nan else id_list[i]
      conv_indices[cid].append(i)

    del extra_list, trace_id_list, id_list, row_conv_ids, trace_to_conv
    _log.info("Grouped into %d conversations", len(conv_indices))

    conv_ids = sorted(conv_indices.keys())
    if limit:
      conv_ids = conv_ids[:limit]

    if max_workers is None:
      max_workers = min(os.cpu_count() or 4, 8)

    conv_indices_dict = dict(conv_indices)

    if len(conv_ids) <= 20 or max_workers <= 1:
      trajectories = _sequential_import(table, conv_indices_dict, conv_ids)
    else:
      from multiprocessing import Pool

      with Pool(
        max_workers,
        initializer=_init_worker,
        initargs=(table, conv_indices_dict),
      ) as pool:
        results = pool.map(_worker_process_conversation, conv_ids, chunksize=50)
      trajectories = [t for t in results if t is not None]

    _log.info("Produced %d trajectories", len(trajectories))
    return trajectories

  # ------------------------------------------------------------------
  # Tracing setup
  # ------------------------------------------------------------------

  def setup_tracing(self, api_key: str, project: str) -> None:
    os.environ["LANGCHAIN_TRACING_V2"] = "true"
    os.environ["LANGCHAIN_API_KEY"] = api_key
    os.environ["LANGCHAIN_PROJECT"] = project

    client = Client(api_key=api_key, headers=self._client_headers)
    for p in client.list_projects():
      if p.name == project:
        self._resolved_project_id = str(p.id)
        break

  def flush(self) -> None:
    time.sleep(2)

  def get_project_id(self) -> Optional[str]:
    return self._resolved_project_id

  # ------------------------------------------------------------------
  # Bulk import
  # ------------------------------------------------------------------

  def import_from_bulk_export(
    self,
    source: Optional[str] = None,
    *,
    destination_id: Optional[str] = None,
    limit: Optional[int] = None,
    since: Optional[Any] = None,
  ) -> list[Trajectory]:
    """Import trajectories from a LangSmith parquet bulk export.

    When *source* is a local parquet file path, parse it directly.
    When *source* is ``None``, trigger a live bulk export from
    LangSmith (requires *workspace_id* on the provider and
    *destination_id*), download the parquet, then parse.

    *since* narrows the export time window. Pass a ``timedelta``
    (e.g. ``timedelta(hours=1)``) or a ``datetime`` for the start
    of the window.  When ``None``, all project data is exported.
    """
    if source is None:
      if not self.workspace_id:
        raise ValueError("workspace_id is required for live bulk export (pass to init())")
      if not destination_id:
        raise ValueError("destination_id is required for live bulk export (pass to init())")

      from datetime import timedelta as _td

      end_time = datetime.now(timezone.utc)
      if since is None:
        start_time = datetime(2020, 1, 1, tzinfo=timezone.utc)
      elif isinstance(since, _td):
        start_time = end_time - since
      elif isinstance(since, datetime):
        start_time = since if since.tzinfo else since.replace(tzinfo=timezone.utc)
      else:
        raise TypeError(f"since must be a timedelta or datetime, got {type(since).__name__}")

      source = self._run_bulk_export(destination_id, start_time, end_time)

    return self._import_from_parquet(source, limit=limit)

  @staticmethod
  def _conversation_id_from_run(run: dict) -> Optional[str]:
    extra = run.get("extra") or {}
    if not isinstance(extra, dict):
      return None
    metadata = extra.get("metadata") or {}
    if not isinstance(metadata, dict):
      return None
    conv_id = metadata.get("conversation_id") or metadata.get("session_id")
    if isinstance(conv_id, str) and conv_id:
      return conv_id
    return None

  @staticmethod
  def _normalise_live_run_row(row: dict) -> dict:
    """Normalize live list_runs payloads to parser-compatible run rows."""
    if row.get("inputs") is None:
      row["inputs"] = {}
    if row.get("outputs") is None:
      row["outputs"] = {}
    if row.get("extra") is None:
      row["extra"] = {}

    if not row.get("parent_run_id"):
      parent_ids = row.get("parent_run_ids")
      if isinstance(parent_ids, list) and parent_ids:
        row["parent_run_id"] = str(parent_ids[-1])

    return row

  def _group_runs_by_conversation(
    self,
    rows: list[dict],
    conversation_ids: Optional[set[str]] = None,
  ) -> Dict[str, List[dict]]:
    trace_to_conv: Dict[str, str] = {}
    for row in rows:
      conv_id = self._conversation_id_from_run(row)
      trace_id = row.get("trace_id")
      if conv_id and trace_id:
        trace_to_conv[str(trace_id)] = conv_id

    grouped: Dict[str, List[dict]] = defaultdict(list)
    for row in rows:
      conv_id = self._conversation_id_from_run(row)
      trace_id = row.get("trace_id")
      if not conv_id and trace_id:
        conv_id = trace_to_conv.get(str(trace_id))
      if not conv_id:
        conv_id = str(trace_id or row.get("id") or "unknown")

      if conversation_ids and conv_id not in conversation_ids:
        continue
      grouped[conv_id].append(row)

    return grouped

  def import_from_runs_query(
    self,
    *,
    limit: Optional[int] = None,
    conversation_ids: Optional[List[str]] = None,
    start_time: Optional[datetime] = None,
    end_time: Optional[datetime] = None,
    trace_filter: Optional[str] = None,
    filter: Optional[str] = None,
    **kwargs: Any,
  ) -> list[Trajectory]:
    """Import trajectories from a single live list_runs query."""
    client = Client(api_key=self.api_key, headers=self._client_headers)

    list_runs_kwargs: Dict[str, Any] = dict(kwargs)
    list_runs_kwargs.setdefault("project_id", self.project_id)
    list_runs_kwargs.setdefault("is_root", False)
    list_runs_kwargs.setdefault("select", _SELECT_FIELDS)
    if limit is not None:
      list_runs_kwargs["limit"] = limit
    if start_time is not None:
      list_runs_kwargs["start_time"] = start_time
    if end_time is not None:
      list_runs_kwargs["end_time"] = end_time
    if trace_filter is not None:
      list_runs_kwargs["trace_filter"] = trace_filter
    if filter is not None:
      list_runs_kwargs["filter"] = filter

    runs = list(client.list_runs(**list_runs_kwargs))
    if not runs:
      return []

    rows = [self._normalise_live_run_row(self._run_to_dict(run)) for run in runs]
    requested_ids = set(conversation_ids) if conversation_ids else None
    grouped = self._group_runs_by_conversation(rows, requested_ids)
    if not grouped:
      return []

    trajectories: List[Trajectory] = []
    for conv_id in sorted(grouped.keys()):
      payload = _build_thread_payload(conv_id, grouped[conv_id])
      try:
        parsed = self.parse_conversation(payload)
        trajectories.append(self._build_trajectory(parsed))
      except Exception as e:
        _log.warning("Failed to import conversation %s from runs query: %s", conv_id, e)

    return trajectories

  # ------------------------------------------------------------------
  # SDK pipeline methods
  # ------------------------------------------------------------------

  def fetch_conversation(self, conversation_id: str) -> dict | None:
    return self.get_thread(self.api_key, self.project_id, conversation_id)

  def parse_conversation(self, raw_data: dict) -> ParsedConversation:
    conversation_id = raw_data.get("conversation_id", "")
    num_turns = raw_data.get("num_turns", 0)
    turns = [self._parse_single_turn(t) for t in raw_data.get("turns", [])]

    all_messages: List[Message] = []
    for turn in turns:
      all_messages.extend(turn.messages)

    cleaned = self._clean_conversation_messages(all_messages)

    single_turn = ParsedTurn(
      messages=cleaned,
      source_run_id=turns[0].source_run_id if turns else "",
      start_time=turns[0].start_time if turns else None,
      end_time=turns[-1].end_time if turns else None,
      error=next((t.error for t in turns if t.error), None),
      token_counts={
        k: sum(t.token_counts.get(k, 0) for t in turns)
        for k in ("total_tokens", "prompt_tokens", "completion_tokens")
      },
      total_cost=sum(t.total_cost or 0 for t in turns) or None,
    )

    return ParsedConversation(
      conversation_id=conversation_id,
      data_source="langsmith",
      num_turns=num_turns,
      turns=[single_turn],
    )

  def list_conversations(
    self,
    *,
    query: Optional[str] = None,
    limit: int = 50,
  ) -> list[ConversationSummary]:
    raw = self.list_threads(self.api_key, self.project_id, query=query, limit=limit)
    return [
      ConversationSummary(
        conversation_id=t["conversation_id"],
        num_turns=t["num_turns"],
        first_seen=t.get("first_seen"),
        last_seen=t.get("last_seen"),
        root_run_names=t.get("root_run_names", []),
      )
      for t in raw.get("threads", [])
    ]

  # ------------------------------------------------------------------
  # Server-facing methods
  # ------------------------------------------------------------------

  def validate_key(self, api_key: str) -> list[dict[str, Any]]:
    return self.list_projects(api_key)

  def list_projects(self, api_key: str) -> list[dict[str, Any]]:
    client = Client(api_key=api_key, headers=self._client_headers)
    try:
      return [self._project_to_dict(client.read_project(project_id=TARGET_PROJECT_ID))]
    except Exception as e:
      _log.debug("Failed to fetch project directly: %s", e)
      return [self._project_to_dict(p) for p in client.list_projects(limit=100)]

  def list_threads(
    self,
    api_key: str,
    project_id: str,
    query: Optional[str] = None,
    limit: int = 50,
  ) -> dict[str, Any]:
    client = Client(api_key=api_key, headers=self._client_headers)

    filter_parts = []
    if query:
      filter_parts.append(f'has(metadata, "{query}")')

    runs = list(
      client.list_runs(
        project_id=project_id,
        is_root=True,
        filter=" and ".join(filter_parts) if filter_parts else None,
        limit=50,
      )
    )

    threads: dict[str, dict] = {}
    for run in runs:
      metadata = getattr(run, "metadata", {}) or {}
      conv_id = metadata.get("conversation_id") or metadata.get("session_id")
      if not conv_id:
        continue

      if conv_id not in threads:
        threads[conv_id] = {
          "conversation_id": conv_id,
          "num_turns": 0,
          "first_seen": None,
          "last_seen": None,
          "root_run_names": [],
        }

      t = threads[conv_id]
      t["num_turns"] += 1

      ts = str(run.start_time) if run.start_time else None
      if ts:
        if t["first_seen"] is None or ts < t["first_seen"]:
          t["first_seen"] = ts
        if t["last_seen"] is None or ts > t["last_seen"]:
          t["last_seen"] = ts

      if run.name and run.name not in t["root_run_names"]:
        t["root_run_names"].append(run.name)

    thread_list = sorted(threads.values(), key=lambda t: t["last_seen"] or "", reverse=True)[:limit]
    return {"threads": thread_list, "total": len(threads)}

  @staticmethod
  def _conversation_lookup_strategies(
    project_id: str,
    conversation_id: str,
  ) -> list[tuple[str, dict[str, Any]]]:
    """Return an ordered list of (strategy_name, list_runs_kwargs) to try."""
    return [
      (
        "thread_id",
        {
          "project_id": project_id,
          "filter": f'eq(thread_id, "{conversation_id}")',
          "limit": 100,
        },
      ),
      (
        "trace_id",
        {
          "trace_id": conversation_id,
          "limit": 100,
        },
      ),
      (
        "metadata.conversation_id",
        {
          "project_id": project_id,
          "filter": f'has(metadata, \'{{"conversation_id": "{conversation_id}"}}\' )',
          "is_root": True,
          "limit": 100,
        },
      ),
    ]

  def get_thread(
    self,
    api_key: str,
    project_id: str,
    conversation_id: str,
  ) -> Optional[dict[str, Any]]:
    _log.debug(
      "get_thread called with project_id=%s, conversation_id=%s",
      project_id,
      conversation_id,
    )
    self._clean_expired_cache()
    cache_key = (project_id, conversation_id)

    if cache_key in _conversation_cache:
      cached_time, cached_result = _conversation_cache[cache_key]
      if time.time() - cached_time < CACHE_TTL_SECONDS:
        _log.debug("Returning cached result")
        return cached_result

    client = Client(api_key=api_key, headers=self._client_headers)
    root_runs: list[Any] = []

    for strategy, kwargs in self._conversation_lookup_strategies(project_id, conversation_id):
      try:
        runs = list(client.list_runs(**kwargs))
      except Exception as e:
        _log.debug("Strategy %s failed: %s", strategy, e)
        continue
      _log.debug("Strategy %s returned %d runs", strategy, len(runs))
      if len(runs) >= 100:
        _log.warning("Hit limit of 100 runs -- there may be more runs not fetched")
      root_runs = [r for r in runs if not getattr(r, "parent_run_id", None)]
      if root_runs:
        _log.debug("Found %d root runs via %s", len(root_runs), strategy)
        break

    if not root_runs:
      _log.debug("No root runs found for conversation_id=%s", conversation_id)
      return None

    trace_ids = list({str(r.trace_id) for r in root_runs if getattr(r, "trace_id", None)})
    _log.debug("Extracted %d unique trace_ids", len(trace_ids))

    all_turns = self._fetch_traces_parallel(client, trace_ids)
    total_runs = sum(t["num_runs"] for t in all_turns)

    _log.debug("Fetched %d turns with %d total runs", len(all_turns), total_runs)
    all_turns.sort(key=lambda t: t["start_time"] or "")
    for i, turn in enumerate(all_turns):
      turn["turn_index"] = i

    result: dict[str, Any] = {
      "conversation_id": conversation_id,
      "num_turns": len(all_turns),
      "total_runs": total_runs,
      "turns": all_turns,
    }

    _conversation_cache[cache_key] = (time.time(), result)
    return result

  def get_run_detail(self, api_key: str, run_id: str) -> Optional[dict[str, Any]]:
    client = Client(api_key=api_key, headers=self._client_headers)
    try:
      run = client.read_run(run_id)
    except Exception:
      return None
    return {
      "id": str(run.id),
      "inputs": run.inputs if hasattr(run, "inputs") else {},
      "outputs": run.outputs if hasattr(run, "outputs") else {},
      "error": getattr(run, "error", None),
      "extra": getattr(run, "extra", {}),
      "events": getattr(run, "events", []),
    }
