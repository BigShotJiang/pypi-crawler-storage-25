"""Abstract base class for trace providers with built-in trajectory building."""

from __future__ import annotations

import logging
from abc import ABC, abstractmethod
from dataclasses import asdict
from datetime import datetime, timedelta
from typing import Any, Dict, List, Optional, Union

from trajectory_sdk.primitives.primitives import (
  ConversationSummary,
  ExecutionMetrics,
  Message,
  ParsedConversation,
  Step,
  Task,
  Telemetry,
  Trajectory,
  TrajectoryMetrics,
)
from trajectory_sdk.utils.hashing import content_hash, idempotency_key

_log = logging.getLogger(__name__)


class BaseProvider(ABC):
  """Base class for all trace providers.

  Subclasses implement the abstract methods for provider-specific logic.
  Building trajectories from parsed conversations is handled here.
  """

  def __init__(self, api_key: str, project_id: str) -> None:
    self.api_key = api_key
    self.project_id = project_id

  # ------------------------------------------------------------------
  # Abstract -- SDK pipeline (fetch, parse, list)
  # ------------------------------------------------------------------

  @abstractmethod
  def fetch_conversation(self, conversation_id: str) -> dict | None:
    """Fetch raw conversation data from the provider API."""
    ...

  @abstractmethod
  def parse_conversation(self, raw_data: dict) -> ParsedConversation:
    """Parse raw provider data into a ParsedConversation."""
    ...

  @abstractmethod
  def list_conversations(
    self,
    *,
    query: Optional[str] = None,
    limit: int = 50,
  ) -> list[ConversationSummary]:
    """List available conversations from the provider."""
    ...

  # ------------------------------------------------------------------
  # Abstract -- server-facing (validate, list projects, threads, runs)
  # ------------------------------------------------------------------

  @abstractmethod
  def validate_key(self, api_key: str) -> list[dict[str, Any]]:
    """Validate an API key and return a list of project dicts."""
    ...

  @abstractmethod
  def list_projects(self, api_key: str) -> list[dict[str, Any]]:
    """List available projects for the given API key."""
    ...

  @abstractmethod
  def list_threads(
    self,
    api_key: str,
    project_id: str,
    query: Optional[str] = None,
    limit: int = 50,
  ) -> dict[str, Any]:
    """List conversation threads in a project."""
    ...

  @abstractmethod
  def get_thread(
    self,
    api_key: str,
    project_id: str,
    conversation_id: str,
  ) -> Optional[dict[str, Any]]:
    """Get full thread detail by conversation_id."""
    ...

  @abstractmethod
  def get_run_detail(self, api_key: str, run_id: str) -> Optional[dict[str, Any]]:
    """Fetch full details for a single run."""
    ...

  # ------------------------------------------------------------------
  # Abstract -- tracing setup (for agent instrumentation)
  # ------------------------------------------------------------------

  @abstractmethod
  def setup_tracing(self, api_key: str, project: str) -> None:
    """Configure env vars and SDK state so decorated functions emit traces."""
    ...

  @abstractmethod
  def flush(self) -> None:
    """Flush any buffered traces to the backend."""
    ...

  @abstractmethod
  def get_project_id(self) -> Optional[str]:
    """Return the resolved project ID, or None."""
    ...

  # ------------------------------------------------------------------
  # Concrete -- bulk import (override in subclasses that support it)
  # ------------------------------------------------------------------

  def import_from_bulk_export(
    self,
    source: Optional[str] = None,
    *,
    destination_id: Optional[str] = None,
    limit: Optional[int] = None,
    since: Optional[Union[timedelta, datetime]] = None,
  ) -> list[Trajectory]:
    """Import trajectories from a provider bulk-export file or live export."""
    raise NotImplementedError(
      f"{type(self).__name__} does not support bulk import from export files."
    )

  # ------------------------------------------------------------------
  # Shared helpers -- usable by any provider implementation
  # ------------------------------------------------------------------

  @staticmethod
  def flatten_run_tree(runs: List[dict]) -> List[dict]:
    """DFS-flatten a run tree into a single list."""
    flat: List[dict] = []
    stack = list(reversed(runs))
    while stack:
      node = stack.pop()
      flat.append(node)
      children = node.get("children") or []
      for child in reversed(children):
        stack.append(child)
    return flat

  @staticmethod
  def run_sort_key(run: dict) -> str:
    """Sort key preferring dotted_order, falling back to start_time."""
    return run.get("dotted_order") or run.get("start_time") or ""

  @staticmethod
  def aggregate_tokens(runs: List[dict]) -> Dict[str, int]:
    """Sum token counts across runs."""
    return {
      k: sum(r.get(k) or 0 for r in runs)
      for k in ("total_tokens", "prompt_tokens", "completion_tokens")
    }

  @staticmethod
  def aggregate_cost(runs: List[Dict[str, Any]]) -> float:
    """Sum cost across runs."""
    return sum(float(r.get("total_cost") or 0) for r in runs)

  # ------------------------------------------------------------------
  # Builder -- ParsedConversation -> Trajectory
  # ------------------------------------------------------------------

  @staticmethod
  def _step(running: list[Message]) -> Step:
    """Snapshot the running message list into a Step."""
    return Step(messages=list(running))

  @staticmethod
  def _parse_total_time(start: Optional[str], end: Optional[str]) -> Optional[float]:
    """Parse ISO timestamps and return delta in seconds, or None."""
    if not start or not end:
      return None
    try:
      t0 = datetime.fromisoformat(start.replace("Z", "+00:00"))
      t1 = datetime.fromisoformat(end.replace("Z", "+00:00"))
      return (t1 - t0).total_seconds()
    except (ValueError, TypeError, AttributeError):
      return None

  @staticmethod
  def _count_tool_calls(messages: List[Message]) -> int:
    """Count tool calls across all assistant messages."""
    return sum(len(m.tool_calls) for m in messages if m.role == "assistant" and m.tool_calls)

  @staticmethod
  def _count_tool_failures(messages: List[Message]) -> int:
    """Count tool responses that have an error."""
    return sum(
      1 for m in messages if m.role == "tool" and m.tool_response and m.tool_response.error
    )

  def _build_cumulative_steps(self, messages: List[Message]) -> List[Step]:
    """Build cumulative Step[] matching the engine's step lifecycle.

    Each step ends after a complete agent turn: either a tool response or
    a final assistant message (no tool_calls). Step 0 includes the initial
    context (system + user) plus the first agent turn's response.

    When system messages appear mid-conversation (new turn), they replace
    the system prefix in ``running`` so later steps use the updated context
    while earlier steps keep the original.
    """
    if not messages:
      return []

    running: List[Message] = []
    steps: List[Step] = []
    seen_first_user = False
    in_system_block = False

    for msg in messages:
      if msg.role == "system" and seen_first_user:
        if not in_system_block:
          in_system_block = True
          running = [m for m in running if m.role != "system"]
        running.insert(
          sum(1 for m in running if m.role == "system"),
          msg,
        )
        continue

      if msg.role != "system":
        in_system_block = False

      running.append(msg)

      if not seen_first_user:
        if msg.role == "user":
          seen_first_user = True
          steps.append(self._step(running))
        continue

      if msg.role == "tool":
        steps.append(self._step(running))
      elif msg.role == "assistant" and not msg.tool_calls:
        steps.append(self._step(running))

    if not steps or len(running) > len(steps[-1].messages):
      steps.append(self._step(running))

    return steps

  def _build_trajectory(self, parsed: ParsedConversation) -> Trajectory:
    """Build a complete Trajectory from a ParsedConversation."""
    all_messages: List[Message] = []
    for turn in parsed.turns:
      all_messages.extend(turn.messages)

    steps = self._build_cumulative_steps(all_messages)

    total_tokens = sum(t.token_counts.get("total_tokens", 0) for t in parsed.turns) or None
    total_cost = sum(t.total_cost or 0 for t in parsed.turns) or None
    completion_tokens = (
      sum(t.token_counts.get("completion_tokens", 0) for t in parsed.turns) or None
    )

    task = Task(
      id=f"{parsed.data_source}:{parsed.conversation_id}",
      data_source=parsed.data_source,
      conversation_id=parsed.conversation_id,
      num_turns=parsed.num_turns,
      num_steps=len(steps),
      total_tokens=total_tokens,
      total_cost=total_cost,
    )

    first_start = next(
      (t.start_time for t in parsed.turns if t.start_time),
      None,
    )
    last_end = next(
      (t.end_time for t in reversed(parsed.turns) if t.end_time),
      None,
    )
    total_time = self._parse_total_time(first_start, last_end)

    has_error = any(t.error for t in parsed.turns)
    execution_metrics = ExecutionMetrics(
      total_time=total_time,
      termination_reason="ERROR" if has_error else "ENV_DONE",
    )

    n_calls = self._count_tool_calls(all_messages)
    n_fails = self._count_tool_failures(all_messages)
    traj_metrics = TrajectoryMetrics(
      steps=len(steps),
      num_tool_calls=n_calls,
      num_tool_failures=n_fails,
      tool_error_rate=n_fails / n_calls if n_calls > 0 else 0.0,
      tokens_generated=completion_tokens,
    )

    traj_dict_for_hash = asdict(
      Trajectory(
        task=task,
        steps=steps,
        metrics=traj_metrics,
        execution_metrics=execution_metrics,
      )
    )
    c_hash = content_hash(traj_dict_for_hash)
    i_key = idempotency_key(
      parsed.data_source,
      parsed.conversation_id,
      c_hash,
    )

    telemetry = Telemetry(
      source=parsed.data_source,
      data={
        "source_run_ids": [t.source_run_id for t in parsed.turns],
        "conversation_id": parsed.conversation_id,
        "content_hash": c_hash,
        "idempotency_key": i_key,
      },
    )

    first_error = next(
      (t.error for t in parsed.turns if t.error),
      None,
    )

    return Trajectory(
      task=task,
      steps=steps,
      metrics=traj_metrics,
      execution_metrics=execution_metrics,
      telemetry=telemetry,
      error=first_error,
    )
