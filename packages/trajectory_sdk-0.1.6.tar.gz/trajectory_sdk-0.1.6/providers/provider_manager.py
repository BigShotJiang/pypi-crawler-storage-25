"""Orchestrate the provider pipeline: fetch, build, transform."""

from __future__ import annotations

import logging
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timedelta
from typing import Any, List, Optional, Union

from tqdm import tqdm

from trajectory_sdk.primitives.primitives import Trajectory
from trajectory_sdk.providers.base_provider import BaseProvider
from trajectory_sdk.transforms.transform_manager import TransformManager

_log = logging.getLogger(__name__)


class ProviderManager:
  """Manage the conversation import pipeline.

  Handles threaded fetching, building, and optional transforming.
  """

  def __init__(
    self,
    provider: BaseProvider,
    transform_manager: Optional[TransformManager] = None,
  ) -> None:
    self._provider = provider
    self._transform_manager = transform_manager

  def import_conversations(self, conversation_ids: List[str]) -> List[Trajectory]:
    """Fetch, parse, build, and optionally transform conversations."""
    raw_data: dict[str, dict] = {}

    def _fetch(conv_id: str) -> tuple[str, dict | None]:
      return conv_id, self._provider.fetch_conversation(conv_id)

    with ThreadPoolExecutor(max_workers=min(len(conversation_ids), 8)) as executor:
      futures = [executor.submit(_fetch, cid) for cid in conversation_ids]
      with tqdm(total=len(futures), desc="Fetching", unit="conv") as pbar:
        for future in as_completed(futures):
          try:
            conv_id, raw = future.result()
            if raw:
              raw_data[conv_id] = raw
          except Exception as e:
            _log.warning("Failed to fetch conversation: %s", e)
          pbar.update(1)

    trajectories: list[Trajectory] = []
    for conv_id in conversation_ids:
      if conv_id not in raw_data:
        continue
      try:
        parsed = self._provider.parse_conversation(raw_data[conv_id])
        trajectory = self._provider._build_trajectory(parsed)
        trajectories.append(trajectory)
      except Exception as e:
        _log.warning("Failed to import conversation %s: %s", conv_id, e)

    if self._transform_manager and trajectories:
      trajectories = self._transform_manager.run(trajectories)

    return trajectories

  def import_bulk(
    self,
    source: Optional[str] = None,
    *,
    destination_id: Optional[str] = None,
    limit: Optional[int] = None,
    since: Optional[Union[timedelta, datetime]] = None,
  ) -> list[Trajectory]:
    """Import via bulk export, then optionally transform."""
    trajectories = self._provider.import_from_bulk_export(
      source, destination_id=destination_id, limit=limit, since=since
    )

    if self._transform_manager and trajectories:
      trajectories = self._transform_manager.run(trajectories)

    return trajectories

  def import_from_runs_query(self, **kwargs: Any) -> list[Trajectory]:
    """Import trajectories from a single provider-side runs query."""
    importer = getattr(self._provider, "import_from_runs_query", None)
    if importer is None:
      raise NotImplementedError(
        f"{type(self._provider).__name__} does not support import_from_runs_query()."
      )

    trajectories = importer(**kwargs)
    if self._transform_manager and trajectories:
      trajectories = self._transform_manager.run(trajectories)

    return trajectories

  def transform_conversation(self, raw_data: dict) -> Trajectory:
    """Parse and build a single conversation without fetching."""
    parsed = self._provider.parse_conversation(raw_data)
    trajectory = self._provider._build_trajectory(parsed)

    if self._transform_manager:
      trajectories = self._transform_manager.run([trajectory])
      return trajectories[0]

    return trajectory
