"""End-to-end pipeline test: raw data -> provider.parse -> provider.build -> save."""

import json
from dataclasses import asdict

from trajectory_sdk.providers.langsmith_provider import LangSmithProvider
from trajectory_sdk.tests.sample_data import (
  make_conversation,
  make_llm_run,
  make_tool_run,
  make_turn,
)


def test_full_pipeline(tmp_path):
  """Raw LangSmith data flows through parse -> build -> disk."""
  tool_calls = [{"function": {"name": "calc", "arguments": '{"x": "2+2"}'}, "id": "tc-1"}]
  llm = make_llm_run(
    user_content="What is 2+2?",
    assistant_content="Let me calculate.",
    tool_calls=tool_calls,
    total_tokens=150,
    completion_tokens=50,
    total_cost=0.002,
  )
  tool = make_tool_run(output="4", dotted_order="20250101T000002Z")
  llm_final = make_llm_run(
    run_id="run-2",
    user_content="",
    assistant_content="The answer is 4.",
    total_tokens=80,
    completion_tokens=30,
    total_cost=0.001,
    dotted_order="20250101T000003Z",
  )
  turn = make_turn(runs=[{**llm, "children": [tool]}, llm_final])
  raw = make_conversation(conversation_id="pipeline-test", turns=[turn])

  provider = LangSmithProvider(api_key="", project_id="")
  parsed = provider.parse_conversation(raw)
  assert parsed.conversation_id == "pipeline-test"
  assert len(parsed.turns) == 1
  assert len(parsed.turns[0].messages) > 0

  trajectory = provider._build_trajectory(parsed)
  assert trajectory.task.conversation_id == "pipeline-test"
  assert trajectory.task.data_source == "langsmith"
  assert len(trajectory.steps) > 0
  assert trajectory.telemetry is not None
  c_hash = trajectory.telemetry.data["content_hash"]
  assert len(c_hash) > 0

  export_dir = tmp_path / "exports"
  export_dir.mkdir()
  traj_dict = asdict(trajectory)
  file_path = export_dir / "pipeline-test.json"
  with open(file_path, "w") as f:
    json.dump(traj_dict, f, indent=2, default=str)

  saved = json.loads(file_path.read_text())
  assert saved["task"]["conversation_id"] == "pipeline-test"
  assert len(saved["steps"]) == len(trajectory.steps)
