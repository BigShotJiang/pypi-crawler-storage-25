"""Functional tests for the parsing layer (provider.parse_conversation)."""

from trajectory_sdk.providers.langsmith_provider import LangSmithProvider
from trajectory_sdk.tests.sample_data import (
  make_conversation,
  make_llm_run,
  make_openai_llm_run,
  make_tool_run,
  make_turn,
)

_provider = LangSmithProvider(api_key="", project_id="")


def test_parse_simple_conversation():
  """Single turn with one LLM run produces correct messages."""
  raw = make_conversation()
  parsed = _provider.parse_conversation(raw)

  assert parsed.conversation_id == "conv-test-123"
  assert parsed.data_source == "langsmith"
  assert parsed.num_turns == 1
  assert len(parsed.turns) == 1

  turn = parsed.turns[0]
  assert turn.source_run_id == "trace-1"
  assert len(turn.messages) == 2

  user_msg = turn.messages[0]
  assert user_msg.role == "user"
  assert user_msg.content == "What is 2+2?"

  assistant_msg = turn.messages[1]
  assert assistant_msg.role == "assistant"
  assert assistant_msg.content == "The answer is 4."


def test_extract_with_tool_calls():
  """Turn with LLM + tool run produces user, assistant, and tool messages."""
  tool_calls = [{"function": {"name": "calculator", "arguments": '{"expr": "2+2"}'}, "id": "tc-1"}]
  llm = make_llm_run(
    assistant_content="Let me calculate that.",
    tool_calls=tool_calls,
  )
  tool = make_tool_run(dotted_order="20250101T000002Z")
  turn = make_turn(runs=[{**llm, "children": [tool]}])
  raw = make_conversation(turns=[turn])

  parsed = _provider.parse_conversation(raw)

  messages = parsed.turns[0].messages
  roles = [m.role for m in messages]
  assert "user" in roles
  assert "assistant" in roles
  assert "tool" in roles

  tool_msg = next(m for m in messages if m.role == "tool")
  assert tool_msg.tool_response is not None
  assert tool_msg.tool_response.name == "calculator"
  assert tool_msg.tool_response.response == "4"


def test_parse_tool_error():
  """Tool run with error is captured."""
  llm = make_llm_run(
    tool_calls=[{"function": {"name": "calc", "arguments": "{}"}, "id": "tc-1"}],
  )
  tool = make_tool_run(error="division by zero", dotted_order="20250101T000002Z")
  turn = make_turn(runs=[{**llm, "children": [tool]}])
  raw = make_conversation(turns=[turn])

  parsed = _provider.parse_conversation(raw)

  tool_msg = next(m for m in parsed.turns[0].messages if m.role == "tool")
  assert tool_msg.tool_response is not None
  assert tool_msg.tool_response.error == "division by zero"
  assert parsed.turns[0].error == "division by zero"


def test_parse_multi_turn():
  """Multiple turns are consolidated into a single turn with all messages."""
  turn1 = make_turn(
    runs=[make_llm_run(user_content="Hi", assistant_content="Hello!")],
    trace_id="t1",
    start_time="2025-01-01T00:00:00Z",
  )
  turn2 = make_turn(
    runs=[make_llm_run(run_id="r2", user_content="How are you?", assistant_content="Good!")],
    trace_id="t2",
    start_time="2025-01-01T00:01:00Z",
  )
  raw = make_conversation(turns=[turn1, turn2])

  parsed = _provider.parse_conversation(raw)

  assert parsed.num_turns == 2
  assert len(parsed.turns) == 1
  msgs = parsed.turns[0].messages
  user_msgs = [m for m in msgs if m.role == "user"]
  assert user_msgs[0].content == "Hi"
  assert user_msgs[1].content == "How are you?"


def test_parse_token_counts():
  """Token counts are aggregated from runs."""
  raw = make_conversation()
  parsed = _provider.parse_conversation(raw)

  turn = parsed.turns[0]
  assert turn.token_counts["total_tokens"] == 100
  assert turn.token_counts["prompt_tokens"] == 60
  assert turn.token_counts["completion_tokens"] == 40


def test_parse_openai_format_simple():
  """LLM run with OpenAI-style outputs (content at top level) is parsed correctly."""
  llm = make_openai_llm_run(user_content="Hello", assistant_content="Hi there!")
  turn = make_turn(runs=[llm])
  raw = make_conversation(turns=[turn])

  parsed = _provider.parse_conversation(raw)

  messages = parsed.turns[0].messages
  assert len(messages) == 2
  assert messages[0].role == "user"
  assert messages[0].content == "Hello"
  assert messages[1].role == "assistant"
  assert messages[1].content == "Hi there!"


def test_parse_openai_format_with_tool_calls():
  """OpenAI-style LLM run with tool calls + tool run + second LLM run roundtrips correctly."""
  tc = [
    {
      "id": "call_abc",
      "type": "function",
      "function": {"name": "calculator", "arguments": '{"expression": "2+2"}'},
    }
  ]
  llm1 = make_openai_llm_run(
    run_id="llm-1",
    user_content="What is 2+2?",
    assistant_content="Let me calculate.",
    tool_calls=tc,
    dotted_order="20250101T000000Z",
  )
  tool = make_tool_run(dotted_order="20250101T000001Z")
  llm2 = make_openai_llm_run(
    run_id="llm-2",
    assistant_content="The answer is 4.",
    dotted_order="20250101T000002Z",
    input_messages=[
      [
        {"role": "user", "content": "What is 2+2?"},
        {"role": "assistant", "content": "Let me calculate.", "tool_calls": tc},
        {"role": "tool", "content": "4"},
      ]
    ],
  )
  turn = make_turn(runs=[{**llm1, "children": [tool, llm2]}])
  raw = make_conversation(turns=[turn])

  parsed = _provider.parse_conversation(raw)

  messages = parsed.turns[0].messages
  roles = [m.role for m in messages]
  assert roles == ["user", "assistant", "tool", "assistant"], f"Got roles: {roles}"

  assert messages[0].content == "What is 2+2?"
  assert messages[1].content == "Let me calculate."
  assert messages[1].tool_calls is not None
  assert messages[1].tool_calls[0].name == "calculator"
  assert messages[2].role == "tool"
  assert messages[3].content == "The answer is 4."


def test_extract_tool_definitions_openai_tools():
  """OpenAI tools format: inputs.tools as a list of {type, function} dicts."""
  tools = [
    {
      "type": "function",
      "function": {
        "name": "calculator",
        "description": "Evaluate a math expression",
        "parameters": {"type": "object", "properties": {"expr": {"type": "string"}}},
      },
    },
    {
      "type": "function",
      "function": {
        "name": "weather",
        "description": "Get the weather",
        "parameters": {"type": "object", "properties": {"city": {"type": "string"}}},
      },
    },
  ]
  run = {"inputs": {"tools": tools}, "extra": {}}
  defs = LangSmithProvider._extract_tool_definitions(run)
  assert len(defs) == 2
  assert defs[0].name == "calculator"
  assert defs[0].description == "Evaluate a math expression"
  assert "expr" in defs[0].parameters.get("properties", {})
  assert defs[1].name == "weather"


def test_extract_tool_definitions_legacy_functions():
  """Legacy OpenAI functions format: inputs.functions as a list of dicts."""
  fns = [
    {
      "name": "search",
      "description": "Search the web",
      "parameters": {"type": "object", "properties": {"query": {"type": "string"}}},
    }
  ]
  run = {"inputs": {"functions": fns}, "extra": {}}
  defs = LangSmithProvider._extract_tool_definitions(run)
  assert len(defs) == 1
  assert defs[0].name == "search"


def test_extract_tool_definitions_invocation_params():
  """Tool defs in extra.invocation_params.tools."""
  tools = [
    {
      "type": "function",
      "function": {
        "name": "get_time",
        "description": "Get current time",
        "parameters": {},
      },
    }
  ]
  run = {"inputs": {}, "extra": {"invocation_params": {"tools": tools}}}
  defs = LangSmithProvider._extract_tool_definitions(run)
  assert len(defs) == 1
  assert defs[0].name == "get_time"


def test_extract_tool_definitions_ai_sdk_dict():
  """Vercel AI SDK format: inputs.args[0].tools as a dict keyed by name."""
  run = {
    "inputs": {
      "args": [
        {
          "tools": {
            "getWeather": {
              "description": "Get weather for a city",
              "parameters": {"type": "object", "properties": {"city": {"type": "string"}}},
            }
          },
          "messages": [],
        }
      ]
    },
    "extra": {},
  }
  defs = LangSmithProvider._extract_tool_definitions(run)
  assert len(defs) == 1
  assert defs[0].name == "getWeather"
  assert defs[0].description == "Get weather for a city"


def test_parse_conversation_includes_tool_definitions():
  """Tool definitions from LLM run inputs are attached to the first message."""
  tools = [
    {
      "type": "function",
      "function": {
        "name": "calculator",
        "description": "Evaluate a math expression",
        "parameters": {"type": "object", "properties": {"expr": {"type": "string"}}},
      },
    }
  ]
  tool_calls = [{"function": {"name": "calculator", "arguments": '{"expr": "2+2"}'}, "id": "tc-1"}]
  llm = make_llm_run(
    assistant_content="Let me calculate.",
    tool_calls=tool_calls,
    tools=tools,
  )
  tool = make_tool_run(dotted_order="20250101T000002Z")
  turn = make_turn(runs=[{**llm, "children": [tool]}])
  raw = make_conversation(turns=[turn])

  parsed = _provider.parse_conversation(raw)

  first_msg = parsed.turns[0].messages[0]
  assert first_msg.tool_definitions is not None
  assert len(first_msg.tool_definitions) == 1
  assert first_msg.tool_definitions[0].name == "calculator"
  assert first_msg.tool_definitions[0].description == "Evaluate a math expression"


def test_parse_conversation_tool_definitions_on_message():
  """Tool definitions embedded on message dicts (as in real LangSmith data) are extracted."""
  tool_defs = [
    {
      "name": "get_order_details",
      "description": "Get order details by order ID",
      "parameters": {"type": "object", "properties": {"order_id": {"type": "string"}}},
    },
    {
      "name": "find_user",
      "description": "Find a user by name",
      "parameters": {"type": "object", "properties": {"name": {"type": "string"}}},
    },
  ]
  llm = make_llm_run(assistant_content="I can help with that.")
  llm["inputs"]["messages"] = [
    [
      {"role": "system", "content": "You are a helpful assistant.", "tool_definitions": tool_defs},
      {"role": "user", "content": "What is 2+2?"},
    ]
  ]
  turn = make_turn(runs=[llm])
  raw = make_conversation(turns=[turn])

  parsed = _provider.parse_conversation(raw)

  system_msg = next(m for m in parsed.turns[0].messages if m.role == "system")
  assert system_msg.tool_definitions is not None
  assert len(system_msg.tool_definitions) == 2
  assert system_msg.tool_definitions[0].name == "get_order_details"
  assert system_msg.tool_definitions[1].name == "find_user"

  user_msg = next(m for m in parsed.turns[0].messages if m.role == "user")
  assert user_msg.tool_definitions is None


def test_extract_tool_defs_from_message_dict():
  """Direct unit test for _extract_tool_defs_from_message."""
  msg = {
    "role": "system",
    "content": "You are a helper.",
    "tool_definitions": [
      {"name": "search", "description": "Search", "parameters": {"type": "object"}},
    ],
  }
  defs = LangSmithProvider._extract_tool_defs_from_message(msg)
  assert defs is not None
  assert len(defs) == 1
  assert defs[0].name == "search"

  assert (
    LangSmithProvider._extract_tool_defs_from_message({"role": "user", "content": "hi"}) is None
  )
  assert (
    LangSmithProvider._extract_tool_defs_from_message({"role": "user", "tool_definitions": []})
    is None
  )


def test_parse_conversation_no_tool_definitions():
  """When no tools are defined, tool_definitions remains None."""
  raw = make_conversation()
  parsed = _provider.parse_conversation(raw)

  for msg in parsed.turns[0].messages:
    assert msg.tool_definitions is None


def test_parse_fallback_no_llm_run():
  """When no LLM run is found, fallback extraction from root inputs/outputs."""
  chain_run = {
    "id": "chain-1",
    "name": "MyChain",
    "run_type": "chain",
    "status": "success",
    "start_time": "2025-01-01T00:00:00Z",
    "end_time": "2025-01-01T00:00:01Z",
    "dotted_order": "20250101T000000Z",
    "inputs": {"input": "What is the capital of France?"},
    "outputs": {"output": "Paris"},
    "total_tokens": 0,
    "prompt_tokens": 0,
    "completion_tokens": 0,
    "total_cost": 0,
    "error": None,
    "children": [],
  }
  turn = make_turn(runs=[chain_run])
  raw = make_conversation(turns=[turn])

  parsed = _provider.parse_conversation(raw)

  messages = parsed.turns[0].messages
  assert len(messages) == 2
  assert messages[0].role == "user"
  assert messages[0].content == "What is the capital of France?"
  assert messages[1].role == "assistant"
  assert messages[1].content == "Paris"
