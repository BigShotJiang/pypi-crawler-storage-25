"""Mock LangSmith data for functional tests."""


def make_llm_run(
  run_id: str = "run-1",
  user_content: str = "What is 2+2?",
  assistant_content: str = "The answer is 4.",
  tool_calls: list | None = None,
  tools: list | None = None,
  extra: dict | None = None,
  total_tokens: int = 100,
  prompt_tokens: int = 60,
  completion_tokens: int = 40,
  total_cost: float = 0.001,
  start_time: str = "2025-01-01T00:00:00Z",
  dotted_order: str = "20250101T000000Z",
) -> dict:
  """Build a mock LLM run dict."""
  outputs: dict = {}
  if tool_calls:
    outputs["generations"] = [
      [
        {
          "message": {
            "role": "assistant",
            "content": assistant_content,
            "tool_calls": tool_calls,
          }
        }
      ]
    ]
  else:
    outputs["generations"] = [[{"message": {"role": "assistant", "content": assistant_content}}]]

  inputs: dict = {"messages": [[{"role": "user", "content": user_content}]]}
  if tools is not None:
    inputs["tools"] = tools

  return {
    "id": run_id,
    "name": "ChatOpenAI",
    "run_type": "llm",
    "status": "success",
    "start_time": start_time,
    "end_time": "2025-01-01T00:00:01Z",
    "dotted_order": dotted_order,
    "inputs": inputs,
    "outputs": outputs,
    "extra": extra or {},
    "total_tokens": total_tokens,
    "prompt_tokens": prompt_tokens,
    "completion_tokens": completion_tokens,
    "total_cost": total_cost,
    "error": None,
    "parent_run_id": None,
    "trace_id": "trace-1",
    "children": [],
  }


def make_openai_llm_run(
  run_id: str = "run-1",
  user_content: str = "What is 2+2?",
  assistant_content: str = "The answer is 4.",
  tool_calls: list | None = None,
  tools: list | None = None,
  extra: dict | None = None,
  total_tokens: int = 100,
  prompt_tokens: int = 60,
  completion_tokens: int = 40,
  total_cost: float = 0.001,
  start_time: str = "2025-01-01T00:00:00Z",
  dotted_order: str = "20250101T000000Z",
  input_messages: list | None = None,
) -> dict:
  """Build a mock LLM run dict using OpenAI-style outputs (content + tool_calls at top level)."""
  outputs: dict = {"content": assistant_content}
  if tool_calls:
    outputs["tool_calls"] = tool_calls

  if input_messages is None:
    input_messages = [[{"role": "user", "content": user_content}]]

  inputs: dict = {"messages": input_messages}
  if tools is not None:
    inputs["tools"] = tools

  return {
    "id": run_id,
    "name": "llm_step_0",
    "run_type": "llm",
    "status": "success",
    "start_time": start_time,
    "end_time": "2025-01-01T00:00:01Z",
    "dotted_order": dotted_order,
    "inputs": inputs,
    "outputs": outputs,
    "extra": extra or {},
    "total_tokens": total_tokens,
    "prompt_tokens": prompt_tokens,
    "completion_tokens": completion_tokens,
    "total_cost": total_cost,
    "error": None,
    "parent_run_id": None,
    "trace_id": "trace-1",
    "children": [],
  }


def make_tool_run(
  run_id: str = "tool-run-1",
  tool_name: str = "calculator",
  inputs: dict | None = None,
  output: str = "4",
  error: str | None = None,
  dotted_order: str = "20250101T000001Z",
) -> dict:
  """Build a mock tool run dict."""
  return {
    "id": run_id,
    "name": tool_name,
    "run_type": "tool",
    "status": "error" if error else "success",
    "start_time": "2025-01-01T00:00:01Z",
    "end_time": "2025-01-01T00:00:02Z",
    "dotted_order": dotted_order,
    "inputs": inputs or {"expression": "2+2"},
    "outputs": {"output": output},
    "total_tokens": 0,
    "prompt_tokens": 0,
    "completion_tokens": 0,
    "total_cost": 0,
    "error": error,
    "parent_run_id": "run-1",
    "trace_id": "trace-1",
    "metadata": {},
    "children": [],
  }


def make_turn(
  runs: list | None = None,
  trace_id: str = "trace-1",
  start_time: str = "2025-01-01T00:00:00Z",
  end_time: str = "2025-01-01T00:00:02Z",
) -> dict:
  """Build a mock turn payload."""
  if runs is None:
    runs = [make_llm_run()]
  return {
    "trace_id": trace_id,
    "start_time": start_time,
    "end_time": end_time,
    "num_runs": len(runs),
    "runs": runs,
  }


def make_conversation(
  conversation_id: str = "conv-test-123",
  turns: list | None = None,
) -> dict:
  """Build a mock raw conversation dict as returned by the provider."""
  if turns is None:
    turns = [make_turn()]
  return {
    "conversation_id": conversation_id,
    "num_turns": len(turns),
    "total_runs": sum(t["num_runs"] for t in turns),
    "turns": turns,
  }
