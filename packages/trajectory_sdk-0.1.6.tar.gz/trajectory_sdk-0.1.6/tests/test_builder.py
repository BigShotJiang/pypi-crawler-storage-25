"""Functional tests for the builder layer (now in BaseProvider)."""

from trajectory_sdk.primitives.primitives import Message, ParsedConversation, ParsedTurn
from trajectory_sdk.providers.langsmith_provider import LangSmithProvider

_provider = LangSmithProvider(api_key="", project_id="")


def _make_parsed(messages_per_turn: list[list[tuple[str, str]]]) -> ParsedConversation:
  """Build a ParsedConversation from a list of (role, content) tuples per turn."""
  turns = []
  for i, msgs in enumerate(messages_per_turn):
    turns.append(
      ParsedTurn(
        messages=[Message(role=r, content=c) for r, c in msgs],
        source_run_id=f"trace-{i}",
        start_time=f"2025-01-01T00:0{i}:00Z",
        end_time=f"2025-01-01T00:0{i}:30Z",
        token_counts={"total_tokens": 50, "prompt_tokens": 30, "completion_tokens": 20},
      )
    )
  return ParsedConversation(
    conversation_id="conv-builder-test",
    data_source="test",
    num_turns=len(turns),
    turns=turns,
  )


def test_build_simple_trajectory():
  """Single turn with user + assistant produces a valid Trajectory."""
  parsed = _make_parsed([[("user", "Hello"), ("assistant", "Hi there!")]])
  traj = _provider._build_trajectory(parsed)

  assert traj.task.conversation_id == "conv-builder-test"
  assert traj.task.data_source == "test"
  assert traj.task.num_turns == 1
  assert len(traj.steps) > 0
  assert traj.error is None


def test_build_cumulative_steps():
  """Steps are cumulative -- each step contains all messages up to that point."""
  parsed = _make_parsed(
    [
      [("user", "Q1"), ("assistant", "A1")],
      [("user", "Q2"), ("assistant", "A2")],
    ]
  )
  traj = _provider._build_trajectory(parsed)

  last_step = traj.steps[-1]
  all_contents = [m.content for m in last_step.messages]
  assert "Q1" in all_contents
  assert "A1" in all_contents
  assert "Q2" in all_contents
  assert "A2" in all_contents


def test_build_metrics():
  """Builder computes trajectory metrics correctly."""
  parsed = _make_parsed([[("user", "Hi"), ("assistant", "Hello")]])
  traj = _provider._build_trajectory(parsed)

  assert traj.metrics is not None
  assert traj.metrics.steps == len(traj.steps)
  assert traj.task.total_tokens == 50


def test_build_execution_metrics():
  """Builder computes execution time from turn timestamps."""
  parsed = _make_parsed([[("user", "Hi"), ("assistant", "Hello")]])
  traj = _provider._build_trajectory(parsed)

  assert traj.execution_metrics is not None
  assert traj.execution_metrics.total_time is not None
  assert traj.execution_metrics.total_time >= 0
  assert traj.execution_metrics.termination_reason == "ENV_DONE"


def test_build_error_trajectory():
  """Turn with an error sets termination_reason to ERROR."""
  turn = ParsedTurn(
    messages=[Message(role="user", content="crash")],
    source_run_id="trace-err",
    error="something broke",
    token_counts={},
  )
  parsed = ParsedConversation(
    conversation_id="conv-err",
    data_source="test",
    num_turns=1,
    turns=[turn],
  )
  traj = _provider._build_trajectory(parsed)

  assert traj.error == "something broke"
  assert traj.execution_metrics.termination_reason == "ERROR"


def test_build_telemetry():
  """Builder produces telemetry with content hash and idempotency key."""
  parsed = _make_parsed([[("user", "Hi"), ("assistant", "Hello")]])
  traj = _provider._build_trajectory(parsed)

  assert traj.telemetry is not None
  assert traj.telemetry.source == "test"
  assert "content_hash" in traj.telemetry.data
  assert "idempotency_key" in traj.telemetry.data
  assert traj.telemetry.data["conversation_id"] == "conv-builder-test"


def test_build_tool_call_metrics():
  """Builder counts tool calls and failures."""
  from trajectory_sdk.primitives.primitives import ToolCall, ToolResponse

  msgs = [
    Message(role="user", content="calculate"),
    Message(
      role="assistant",
      content="calling tool",
      tool_calls=[ToolCall(name="calc", arguments={"x": 1})],
    ),
    Message(
      role="tool",
      content="result",
      tool_response=ToolResponse(id="tc1", name="calc", arguments={}, response="42"),
    ),
    Message(
      role="assistant",
      content="calling broken tool",
      tool_calls=[ToolCall(name="broken", arguments={})],
    ),
    Message(
      role="tool",
      content="error",
      tool_response=ToolResponse(id="tc2", name="broken", arguments={}, error="fail"),
    ),
    Message(role="assistant", content="done"),
  ]
  turn = ParsedTurn(messages=msgs, source_run_id="t1", token_counts={})
  parsed = ParsedConversation(
    conversation_id="conv-tools",
    data_source="test",
    num_turns=1,
    turns=[turn],
  )
  traj = _provider._build_trajectory(parsed)

  assert traj.metrics.num_tool_calls == 2
  assert traj.metrics.num_tool_failures == 1
  assert traj.metrics.tool_error_rate == 0.5
