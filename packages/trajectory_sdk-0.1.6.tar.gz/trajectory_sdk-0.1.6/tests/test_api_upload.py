"""Tests for the HTTP API upload path."""

from __future__ import annotations

import json
from dataclasses import asdict
from unittest.mock import MagicMock, patch

import pytest

from trajectory_sdk.primitives.primitives import (
  Message,
  Step,
  Task,
  Trajectory,
)
from trajectory_sdk.upload.api_upload import ApiUpload
from trajectory_sdk.upload.upload_manager import UploadManager
from trajectory_sdk.utils.retry import RetryPolicy


def _make_trajectory(conv_id: str = "conv-1", content_size: int = 0) -> Trajectory:
  """Build a minimal valid trajectory, optionally inflated to *content_size* bytes."""
  content = "hey"
  if content_size > 0:
    content = "x" * content_size
  return Trajectory(
    task=Task(conversation_id=conv_id, data_source="test"),
    steps=[
      Step(
        messages=[Message(role="user", content="hi"), Message(role="assistant", content=content)]
      )
    ],
  )


def _empty_trajectory() -> Trajectory:
  return Trajectory(task=Task(conversation_id="empty"), steps=[])


# ---- ApiUpload unit tests ----


class TestApiUpload:
  def test_posts_correct_url_and_headers(self) -> None:
    with patch("trajectory_sdk.upload.api_upload.requests.post") as mock_post:
      mock_post.return_value = MagicMock(status_code=200, json=lambda: {"message": "ok"})
      backend = ApiUpload("https://api.example.com", "test-key-123")
      traj = _make_trajectory()
      backend.upload([traj], "my_dataset")

      mock_post.assert_called_once()
      call_kwargs = mock_post.call_args
      assert call_kwargs.kwargs["headers"]["X-API-Key"] == "test-key-123"
      assert call_kwargs.kwargs["headers"]["Content-Type"] == "application/json"
      assert "https://api.example.com/api/v1/trajectories/upload" in call_kwargs.args

  def test_request_body_structure(self) -> None:
    with patch("trajectory_sdk.upload.api_upload.requests.post") as mock_post:
      mock_post.return_value = MagicMock(status_code=200, json=lambda: {})
      traj = _make_trajectory("conv-abc")
      backend = ApiUpload("https://api.example.com", "key")
      backend.upload([traj], "ds1")

      sent_body = json.loads(mock_post.call_args.kwargs["data"])
      assert sent_body["dataset"] == "ds1"
      assert len(sent_body["trajectories"]) == 1
      assert sent_body["trajectories"][0] == json.loads(json.dumps(asdict(traj), default=str))

  def test_multiple_trajectories(self) -> None:
    with patch("trajectory_sdk.upload.api_upload.requests.post") as mock_post:
      mock_post.return_value = MagicMock(status_code=200, json=lambda: {})
      trajs = [_make_trajectory(f"conv-{i}") for i in range(3)]
      backend = ApiUpload("https://api.example.com", "key")
      backend.upload(trajs, "ds")

      sent_body = json.loads(mock_post.call_args.kwargs["data"])
      assert len(sent_body["trajectories"]) == 3

  def test_raises_on_non_200(self) -> None:
    with patch("trajectory_sdk.upload.api_upload.requests.post") as mock_post:
      mock_post.return_value = MagicMock(
        status_code=422,
        text='{"detail":"bad payload"}',
        json=lambda: {"detail": "bad payload"},
      )
      backend = ApiUpload("https://api.example.com", "key")
      with pytest.raises(RuntimeError, match="Upload failed.*422.*bad payload"):
        backend.upload([_make_trajectory()], "ds")

  def test_raises_on_500_plain_text(self) -> None:
    resp = MagicMock(status_code=500, text="Internal Server Error")
    resp.json.side_effect = ValueError("not json")
    with (
      patch("trajectory_sdk.upload.api_upload.requests.post", return_value=resp),
      patch("trajectory_sdk.utils.retry.time.sleep"),
    ):
      backend = ApiUpload("https://api.example.com", "key")
      with pytest.raises(RuntimeError, match="Upload failed.*500.*Internal Server Error"):
        backend.upload([_make_trajectory()], "ds")

  def test_trailing_slash_stripped(self) -> None:
    with patch("trajectory_sdk.upload.api_upload.requests.post") as mock_post:
      mock_post.return_value = MagicMock(status_code=200, json=lambda: {})
      backend = ApiUpload("https://api.example.com/", "key")
      backend.upload([_make_trajectory()], "ds")

      url = mock_post.call_args.args[0]
      assert url == "https://api.example.com/api/v1/trajectories/upload"


# ---- Retry tests ----


class TestApiUploadRetry:
  def test_retries_on_500_then_succeeds(self) -> None:
    fail_resp = MagicMock(status_code=500, text="error")
    fail_resp.json.side_effect = ValueError
    ok_resp = MagicMock(status_code=200, json=lambda: {"message": "ok"})

    with (
      patch(
        "trajectory_sdk.upload.api_upload.requests.post", side_effect=[fail_resp, ok_resp]
      ) as mock_post,
      patch("trajectory_sdk.utils.retry.time.sleep") as mock_sleep,
    ):
      backend = ApiUpload("https://api.example.com", "key")
      backend.upload([_make_trajectory()], "ds")

      assert mock_post.call_count == 2
      mock_sleep.assert_called_once()

  def test_retries_on_connection_error(self) -> None:
    import requests as req

    ok_resp = MagicMock(status_code=200, json=lambda: {})
    with (
      patch(
        "trajectory_sdk.upload.api_upload.requests.post",
        side_effect=[req.ConnectionError("reset"), ok_resp],
      ) as mock_post,
      patch("trajectory_sdk.utils.retry.time.sleep"),
    ):
      backend = ApiUpload("https://api.example.com", "key")
      backend.upload([_make_trajectory()], "ds")

      assert mock_post.call_count == 2

  def test_raises_after_max_retries_exhausted(self) -> None:
    fail_resp = MagicMock(status_code=503, text="unavailable")
    fail_resp.json.side_effect = ValueError

    with (
      patch("trajectory_sdk.upload.api_upload.requests.post", return_value=fail_resp) as mock_post,
      patch("trajectory_sdk.utils.retry.time.sleep"),
      patch.object(ApiUpload, "get_retry_policy", return_value=RetryPolicy(max_retries=2)),
    ):
      backend = ApiUpload("https://api.example.com", "key")
      with pytest.raises(RuntimeError, match="Upload failed.*503"):
        backend.upload([_make_trajectory()], "ds")

      assert mock_post.call_count == 3

  def test_no_retry_on_4xx(self) -> None:
    """Client errors (except 429) should fail immediately."""
    resp = MagicMock(status_code=400, text="bad request", json=lambda: {"detail": "bad request"})
    with patch("trajectory_sdk.upload.api_upload.requests.post", return_value=resp) as mock_post:
      backend = ApiUpload("https://api.example.com", "key")
      with pytest.raises(RuntimeError, match="400"):
        backend.upload([_make_trajectory()], "ds")

      assert mock_post.call_count == 1

  def test_connection_error_exhausts_retries(self) -> None:
    import requests as req

    with (
      patch(
        "trajectory_sdk.upload.api_upload.requests.post",
        side_effect=req.ConnectionError("down"),
      ),
      patch("trajectory_sdk.utils.retry.time.sleep"),
      patch.object(ApiUpload, "get_retry_policy", return_value=RetryPolicy(max_retries=2)),
    ):
      backend = ApiUpload("https://api.example.com", "key")
      with pytest.raises(RuntimeError, match="Upload failed"):
        backend.upload([_make_trajectory()], "ds")

  def test_zero_retries_means_single_attempt(self) -> None:
    fail_resp = MagicMock(status_code=502, text="bad gateway")
    fail_resp.json.side_effect = ValueError

    with (
      patch("trajectory_sdk.upload.api_upload.requests.post", return_value=fail_resp) as mock_post,
      patch.object(ApiUpload, "get_retry_policy", return_value=RetryPolicy(max_retries=0)),
    ):
      backend = ApiUpload("https://api.example.com", "key")
      with pytest.raises(RuntimeError, match="502"):
        backend.upload([_make_trajectory()], "ds")

      assert mock_post.call_count == 1


# ---- UploadManager tests ----


class TestUploadManager:
  def test_filters_empty_trajectories(self) -> None:
    with patch("trajectory_sdk.upload.api_upload.requests.post") as mock_post:
      mock_post.return_value = MagicMock(status_code=200, json=lambda: {})
      mgr = UploadManager("https://api.example.com", "key")
      result = mgr.upload([_make_trajectory(), _empty_trajectory()], "ds")

      sent_body = json.loads(mock_post.call_args.kwargs["data"])
      assert len(sent_body["trajectories"]) == 1
      assert result["uploaded"] == 1
      assert result["skipped"] == 1

  def test_all_empty_skips_upload(self) -> None:
    with patch("trajectory_sdk.upload.api_upload.requests.post") as mock_post:
      mgr = UploadManager("https://api.example.com", "key")
      result = mgr.upload([_empty_trajectory()], "ds")
      mock_post.assert_not_called()
      assert result["uploaded"] == 0
      assert result["skipped"] == 1


# ---- Batching tests ----


class TestUploadManagerBatching:
  def test_small_trajectories_in_single_batch(self) -> None:
    """Trajectories that fit in one batch should produce exactly one POST."""
    with patch("trajectory_sdk.upload.api_upload.requests.post") as mock_post:
      mock_post.return_value = MagicMock(status_code=200, json=lambda: {})
      trajs = [_make_trajectory(f"c-{i}") for i in range(5)]
      mgr = UploadManager("https://api.example.com", "key")
      mgr.upload(trajs, "ds")

      assert mock_post.call_count == 1
      sent = json.loads(mock_post.call_args.kwargs["data"])
      assert len(sent["trajectories"]) == 5

  @patch("trajectory_sdk.upload.upload_manager._MAX_BATCH_BYTES", 5000)
  def test_large_trajectories_split_into_batches(self) -> None:
    """Trajectories exceeding byte limit should be split across POSTs."""
    with patch("trajectory_sdk.upload.api_upload.requests.post") as mock_post:
      mock_post.return_value = MagicMock(status_code=200, json=lambda: {})
      trajs = [_make_trajectory(f"c-{i}", content_size=2000) for i in range(5)]
      mgr = UploadManager("https://api.example.com", "key")
      mgr.upload(trajs, "ds")

      assert mock_post.call_count > 1
      total_uploaded = 0
      for c in mock_post.call_args_list:
        body = json.loads(c.kwargs["data"])
        total_uploaded += len(body["trajectories"])
      assert total_uploaded == 5

  @patch("trajectory_sdk.upload.upload_manager._MAX_BATCH_COUNT", 3)
  def test_count_limit_splits_batches(self) -> None:
    """Count limit should cap items per batch."""
    with patch("trajectory_sdk.upload.api_upload.requests.post") as mock_post:
      mock_post.return_value = MagicMock(status_code=200, json=lambda: {})
      trajs = [_make_trajectory(f"c-{i}") for i in range(7)]
      mgr = UploadManager("https://api.example.com", "key")
      mgr.upload(trajs, "ds")

      assert mock_post.call_count == 3
      counts = [len(json.loads(c.kwargs["data"])["trajectories"]) for c in mock_post.call_args_list]
      assert counts == [3, 3, 1]

  @patch("trajectory_sdk.upload.upload_manager._MAX_BATCH_BYTES", 500)
  def test_oversized_single_trajectory_still_uploaded(self) -> None:
    """A trajectory larger than the byte limit should be sent alone, not dropped."""
    with patch("trajectory_sdk.upload.api_upload.requests.post") as mock_post:
      mock_post.return_value = MagicMock(status_code=200, json=lambda: {})
      big = _make_trajectory("big", content_size=10_000)
      small = _make_trajectory("small")
      mgr = UploadManager("https://api.example.com", "key")
      result = mgr.upload([big, small], "ds")

      assert mock_post.call_count == 2
      assert result["uploaded"] == 2
      assert result["batches"] == 2
      conv_ids = set()
      for c in mock_post.call_args_list:
        body = json.loads(c.kwargs["data"])
        conv_ids.add(body["trajectories"][0]["task"]["conversation_id"])
      assert conv_ids == {"big", "small"}

  @patch("trajectory_sdk.upload.upload_manager._MAX_BATCH_COUNT", 2)
  def test_batch_failure_raises_without_silencing(self) -> None:
    """If a batch fails (after retries), the error propagates."""
    fail_resp = MagicMock(status_code=422, text="bad", json=lambda: {"detail": "bad"})

    with patch("trajectory_sdk.upload.api_upload.requests.post", return_value=fail_resp):
      mgr = UploadManager("https://api.example.com", "key")
      with pytest.raises(RuntimeError, match="422"):
        mgr.upload([_make_trajectory(f"c-{i}") for i in range(4)], "ds")


# ---- api.upload() integration tests ----


class TestApiUploadFunction:
  def test_raises_without_init(self) -> None:
    import trajectory_sdk.api as api_mod

    api_mod._config = None
    api_mod._provider = None
    api_mod._provider_manager = None
    with pytest.raises(RuntimeError, match="SDK not initialised"):
      api_mod.upload([_make_trajectory()], "ds")

  def test_raises_without_trajectory_api_key(self) -> None:
    import trajectory_sdk.api as api_mod
    from trajectory_sdk.primitives.primitives import SDKConfig

    api_mod._config = SDKConfig(
      provider="langsmith", api_key="", project_id="proj", trajectory_api_key=None
    )
    with pytest.raises(ValueError, match="trajectory_api_key is required"):
      api_mod.upload([_make_trajectory()], "ds")

  def test_upload_delegates_to_manager(self) -> None:
    import trajectory_sdk.api as api_mod
    from trajectory_sdk.primitives.primitives import SDKConfig

    api_mod._config = SDKConfig(
      provider="langsmith",
      api_key="",
      project_id="proj",
      trajectory_api_key="tj_key",
      api_base_url="https://api.example.com",
    )
    with patch("trajectory_sdk.upload.api_upload.requests.post") as mock_post:
      mock_post.return_value = MagicMock(status_code=200, json=lambda: {})
      api_mod.upload([_make_trajectory()], "my_ds")

      sent_body = json.loads(mock_post.call_args.kwargs["data"])
      assert sent_body["dataset"] == "my_ds"
      assert mock_post.call_args.kwargs["headers"]["X-API-Key"] == "tj_key"


# ---- init() provider-optional tests ----


class TestInitRequiresApiKey:
  def test_init_without_langsmith_key_raises(self) -> None:
    import trajectory_sdk.api as api_mod

    with patch.dict("os.environ", {}, clear=True):
      import os

      env_keys = ["LANGSMITH_API_KEY", "LANGCHAIN_API_KEY"]
      for k in env_keys:
        os.environ.pop(k, None)

      with pytest.raises(ValueError, match="No API key provided"):
        api_mod.init(project_id="proj", trajectory_api_key="tj_key")

  def test_init_with_langsmith_key_sets_provider(self) -> None:
    import trajectory_sdk.api as api_mod

    with patch(
      "trajectory_sdk.providers.provider_factory.ProviderFactory.create",
      return_value=MagicMock(),
    ) as mock_create:
      api_mod.init(project_id="proj", api_key="lsv2_test", trajectory_api_key="tj_key")
      mock_create.assert_called_once_with("langsmith", "lsv2_test", "proj", workspace_id=None)
      assert api_mod._provider is not None
