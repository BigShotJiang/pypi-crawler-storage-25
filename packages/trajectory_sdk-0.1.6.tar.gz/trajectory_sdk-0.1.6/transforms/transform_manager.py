"""Orchestrate running multiple transforms on trajectories."""

from __future__ import annotations

import logging
from typing import List

from trajectory_sdk.primitives.primitives import Trajectory
from trajectory_sdk.transforms.base_transform import BaseTransform

_log = logging.getLogger(__name__)


class TransformManager:
  """Run a sequence of transforms on trajectories.

  Transforms are applied in order; each receives the output of the previous.
  """

  def __init__(self, transforms: List[BaseTransform]) -> None:
    self._transforms = list(transforms)

  def run(self, trajectories: List[Trajectory]) -> List[Trajectory]:
    """Apply all transforms in sequence."""
    for t in self._transforms:
      _log.info("Running transform: %s", type(t).__name__)
      trajectories = t.transform_batch(trajectories)
    return trajectories

  def add(self, transform: BaseTransform) -> None:
    """Append a transform to the pipeline."""
    self._transforms.append(transform)
