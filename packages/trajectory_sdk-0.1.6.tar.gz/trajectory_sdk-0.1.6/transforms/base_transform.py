"""Abstract base class for trajectory transforms."""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import List

from trajectory_sdk.primitives.primitives import Trajectory


class BaseTransform(ABC):
  """Contract for transforming trajectories.

  Subclasses implement ``transform`` (single trajectory).
  The default ``transform_batch`` loops ``transform``; override
  for batch-optimised strategies.
  """

  @abstractmethod
  def transform(self, trajectory: Trajectory) -> Trajectory:
    """Transform a single trajectory. Returns a new Trajectory."""
    ...

  def transform_batch(self, trajectories: List[Trajectory]) -> List[Trajectory]:
    """Transform multiple trajectories."""
    return [self.transform(t) for t in trajectories]
