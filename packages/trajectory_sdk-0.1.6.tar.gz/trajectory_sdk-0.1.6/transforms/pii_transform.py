"""PII redaction transform base class and implementations."""

from __future__ import annotations

from abc import abstractmethod
from typing import List

from trajectory_sdk.primitives.primitives import PiiPolicy, RedactionPreview, Trajectory
from trajectory_sdk.transforms.base_transform import BaseTransform


class BasePiiTransform(BaseTransform):
  """Abstract base for PII redaction strategies.

  Subclasses implement ``transform`` (single trajectory) and ``preview``
  (dry-run).
  """

  @abstractmethod
  def preview(self, trajectories: List[Trajectory]) -> RedactionPreview:
    """Dry run -- show what would be redacted without modifying data."""
    ...


class RegexPiiTransform(BasePiiTransform):
  """Regex-based PII redaction (EMAIL, PHONE, SSN, CREDIT_CARD)."""

  def __init__(self, policy: PiiPolicy) -> None:
    self.policy = policy

  def transform(self, trajectory: Trajectory) -> Trajectory:
    raise NotImplementedError("Regex PII redaction not yet implemented")

  def preview(self, trajectories: List[Trajectory]) -> RedactionPreview:
    raise NotImplementedError("Regex PII preview not yet implemented")
