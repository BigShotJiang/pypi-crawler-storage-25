"""Factory for creating transform instances by name."""

from __future__ import annotations

from typing import Any

from trajectory_sdk.transforms.base_transform import BaseTransform


class TransformFactory:
  """Create transform instances by name."""

  @staticmethod
  def create(name: str, **kwargs: Any) -> BaseTransform:
    """Instantiate a transform by name.

    Supported names:
      - ``"pii"`` -- RegexPiiTransform (requires ``policy`` kwarg)
    """
    if name == "pii":
      from trajectory_sdk.primitives.primitives import PiiPolicy
      from trajectory_sdk.transforms.pii_transform import RegexPiiTransform

      policy = kwargs.get("policy")
      if policy is None:
        policy = PiiPolicy(name="default", rules=["EMAIL", "PHONE", "SSN", "CREDIT_CARD"])
      return RegexPiiTransform(policy=policy)

    raise ValueError(f"Unknown transform: {name}")
