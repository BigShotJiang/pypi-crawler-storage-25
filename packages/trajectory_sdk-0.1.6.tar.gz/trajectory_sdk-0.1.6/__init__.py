"""Trajectory SDK -- import and transform agent traces into Trajectory format.

Usage::

    import trajectory_sdk as tj

    # Pass api_key explicitly, or let the SDK read LANGSMITH_API_KEY / LANGCHAIN_API_KEY
    tj.init(provider="langsmith", project_id="...")

    conversations = tj.list_conversations()
    trajectories = tj.import_conversations(conversations)
    tj.save(trajectories, "./exports")
"""

from trajectory_sdk.api import (  # noqa: F401
  import_conversations,
  init,
  list_conversations,
  save,
  transform,
  upload,
)
from trajectory_sdk.primitives.primitives import (  # noqa: F401
  ConversationSummary,
  ParsedConversation,
  ParsedTurn,
  Trajectory,
)
from trajectory_sdk.providers.base_provider import BaseProvider  # noqa: F401
from trajectory_sdk.transforms.pii_transform import BasePiiTransform  # noqa: F401

__all__ = [
  "init",
  "list_conversations",
  "import_conversations",
  "save",
  "upload",
  "transform",
  "Trajectory",
  "ConversationSummary",
  "ParsedTurn",
  "ParsedConversation",
  "BaseProvider",
  "BasePiiTransform",
]
