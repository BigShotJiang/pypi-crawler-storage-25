"""Trajectory schema types and provider-agnostic intermediates."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Literal, Optional, Sequence, Tuple

# ---------------------
# Type aliases
# ---------------------

TrainableStatus = Literal["trainable", "not_trainable", "superseded", "summarization_boundary"]
Role = Literal["system", "user", "assistant", "tool"]
TerminationReason = Literal[
  "TIMEOUT", "ENV_DONE", "MAX_STEPS", "TRUNCATION", "STALE", "ERROR", "NONE"
]
PiiRule = Literal["EMAIL", "PHONE", "CREDIT_CARD", "SSN"]


# ---------------------
# Trajectory schema
# ---------------------


@dataclass(frozen=True)
class ToolCall:
  name: str
  arguments: Dict[str, Any]
  id: Optional[str] = None


@dataclass(frozen=True)
class ToolResponse:
  id: str
  name: str
  arguments: Dict[str, Any]
  response: Any = None
  error: Optional[str] = None
  metadata: Optional[Dict[str, Any]] = None


@dataclass(frozen=True)
class ToolDefinition:
  name: str
  description: str
  parameters: Dict[str, Any]


@dataclass(frozen=True)
class Message:
  role: Role
  content: Optional[str] = None
  tool_calls: Optional[List[ToolCall]] = None
  tool_response: Optional[ToolResponse] = None
  tool_definitions: Optional[List[ToolDefinition]] = None
  usage: Optional[Dict[str, int]] = None
  finish_reason: Optional[str] = None
  metadata: Optional[Dict[str, Any]] = None
  reasoning: Optional[str] = None
  trainable_status: TrainableStatus = "not_trainable"

  def is_empty(self) -> bool:
    return not self.content and self.tool_calls is None and self.tool_response is None


@dataclass(frozen=True)
class RewardComponent:
  name: str
  value: float
  scaled_value: Optional[float] = None
  explanation: Optional[str] = None
  weight: float = 1.0
  range: Optional[Tuple[float, float]] = None
  metadata: Optional[Dict[str, Any]] = None


@dataclass(frozen=True)
class Reward:
  aggregated_value: Optional[float] = None
  aggregation_method: Optional[str] = None
  components: Optional[List[RewardComponent]] = None


@dataclass(frozen=True)
class Step:
  messages: List[Message]  # CUMULATIVE
  reward: Optional[Reward] = None
  info: Optional[Dict[str, Any]] = None
  trainable_status: TrainableStatus = "not_trainable"


@dataclass(frozen=True)
class TrajectoryMetrics:
  steps: Optional[int] = None
  tokens_generated: Optional[int] = None
  aggregated_reward: Optional[float] = None
  num_tool_calls: Optional[int] = None
  num_tool_failures: Optional[int] = None
  num_tool_response_none: Optional[int] = None
  tool_error_rate: Optional[float] = None


@dataclass(frozen=True)
class ExecutionMetrics:
  env_time: Optional[float] = None
  llm_time: Optional[float] = None
  total_time: Optional[float] = None
  termination_reason: Optional[TerminationReason] = None


@dataclass(frozen=True)
class Telemetry:
  source: str
  data: Dict[str, Any]


@dataclass(frozen=True)
class Task:
  id: Optional[str] = None
  data_source: Optional[str] = None
  conversation_id: Optional[str] = None
  num_turns: Optional[int] = None
  num_steps: Optional[int] = None
  total_tokens: Optional[int] = None
  total_cost: Optional[float] = None


@dataclass(frozen=True)
class Trajectory:
  task: Task
  steps: List[Step]
  reward: Optional[Reward] = None
  metrics: Optional[TrajectoryMetrics] = None
  execution_metrics: Optional[ExecutionMetrics] = None
  reference_trajectory: Optional[Dict[str, Any]] = None
  telemetry: Optional[Telemetry] = None
  idx: Optional[int] = None
  error: Optional[str] = None


# ---------------------
# SDK config
# ---------------------


@dataclass(frozen=True)
class SDKConfig:
  provider: str
  api_key: str
  project_id: str
  workspace_id: Optional[str] = None
  destination_id: Optional[str] = None
  trajectory_api_key: Optional[str] = None
  api_base_url: str = "https://trajectory-api-d7xmsmflpa-uc.a.run.app"
  debug: bool = False


# ---------------------
# Provider intermediates
# ---------------------


@dataclass
class ParsedTurn:
  """One turn's worth of structured data, extracted from a provider trace."""

  messages: List[Message]
  source_run_id: str
  start_time: Optional[str] = None
  end_time: Optional[str] = None
  error: Optional[str] = None
  token_counts: Dict[str, int] = field(default_factory=dict)
  total_cost: Optional[float] = None


@dataclass
class ParsedConversation:
  """A full conversation parsed from provider data. Fed into the builder."""

  conversation_id: str
  data_source: str
  num_turns: int
  turns: List[ParsedTurn]


# ---------------------
# Public result types
# ---------------------


@dataclass(frozen=True)
class ConversationSummary:
  conversation_id: str
  num_turns: int
  first_seen: Optional[str] = None
  last_seen: Optional[str] = None
  root_run_names: List[str] = field(default_factory=list)


@dataclass(frozen=True)
class RedactionPreview:
  """Dry-run result from a PII redactor."""

  total_rule_counts: Dict[str, int]
  samples: List[Dict[str, Any]]


# ---------------------
# PII policy
# ---------------------


@dataclass(frozen=True)
class PiiPolicy:
  name: str
  rules: Sequence[PiiRule]
