"""SDK session management and public API functions."""

from __future__ import annotations

import json
import os
from dataclasses import asdict
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any, List, Optional, Union

from trajectory_sdk.primitives.primitives import (
  ConversationSummary,
  SDKConfig,
  Trajectory,
)
from trajectory_sdk.providers.base_provider import BaseProvider
from trajectory_sdk.providers.provider_factory import ProviderFactory
from trajectory_sdk.providers.provider_manager import ProviderManager
from trajectory_sdk.transforms.base_transform import BaseTransform
from trajectory_sdk.transforms.transform_manager import TransformManager
from trajectory_sdk.upload.upload_manager import UploadManager

_config: Optional[SDKConfig] = None
_provider: Optional[BaseProvider] = None
_provider_manager: Optional[ProviderManager] = None


def _require_provider() -> BaseProvider:
  if _provider is None:
    raise RuntimeError("SDK not initialised. Call trajectory_sdk.init(...) first.")
  return _provider


def _require_provider_manager() -> ProviderManager:
  if _provider_manager is None:
    raise RuntimeError("SDK not initialised. Call trajectory_sdk.init(...) first.")
  return _provider_manager


def _resolve_api_key(api_key: Optional[str]) -> str:
  """Resolve API key from explicit value or environment variables."""
  if api_key:
    return api_key
  env_key = os.environ.get("LANGSMITH_API_KEY") or os.environ.get("LANGCHAIN_API_KEY")
  if env_key:
    return env_key
  raise ValueError(
    "No API key provided. Either pass api_key= to init() or set "
    "LANGSMITH_API_KEY / LANGCHAIN_API_KEY in your environment."
  )


def init(
  *,
  provider: str = "langsmith",
  api_key: Optional[str] = None,
  project_id: str,
  workspace_id: Optional[str] = None,
  destination_id: Optional[str] = None,
  trajectory_api_key: Optional[str] = None,
  transforms: Optional[List[BaseTransform]] = None,
  debug: bool = False,
) -> None:
  """Configure the SDK. Call once before other functions.

  If *api_key* is not provided, the SDK reads from the ``LANGSMITH_API_KEY``
  or ``LANGCHAIN_API_KEY`` environment variable.
  """
  global _config, _provider, _provider_manager
  resolved_key = _resolve_api_key(api_key)
  resolved_traj_key = trajectory_api_key or os.environ.get("TRAJECTORY_API_KEY")
  _config = SDKConfig(
    provider=provider,
    api_key=resolved_key,
    project_id=project_id,
    workspace_id=workspace_id,
    destination_id=destination_id,
    trajectory_api_key=resolved_traj_key,
    debug=debug,
  )
  _provider = ProviderFactory.create(provider, resolved_key, project_id, workspace_id=workspace_id)

  transform_manager = TransformManager(transforms) if transforms else None
  _provider_manager = ProviderManager(_provider, transform_manager=transform_manager)


def list_conversations(*, limit: int = 50, **kwargs: Any) -> list[ConversationSummary]:
  """List available conversations from the configured provider."""
  return _require_provider().list_conversations(limit=limit, **kwargs)


def import_conversations(
  conversations: Union[list[str], list[ConversationSummary], None] = None,
  *,
  bulk: bool = False,
  runs_query: bool = False,
  source: Optional[str] = None,
  limit: Optional[int] = None,
  since: Optional[Union[timedelta, datetime]] = None,
  **kwargs: Any,
) -> list[Trajectory]:
  """Import conversations and return one Trajectory per conversation.

  For bulk import from a provider export file (e.g. parquet)::

      trajectories = tj.import_conversations(bulk=True, source="export.parquet")

  For time-scoped bulk import (e.g. last hour)::

      from datetime import timedelta

      trajectories = tj.import_conversations(bulk=True, since=timedelta(hours=1))

  For individual conversation import::

      trajectories = tj.import_conversations(["conv_id_1", "conv_id_2"])
  """
  mgr = _require_provider_manager()

  if bulk and runs_query:
    raise ValueError("bulk and runs_query are mutually exclusive")

  if bulk:
    destination_id = _config.destination_id if _config else None
    return mgr.import_bulk(source, destination_id=destination_id, limit=limit, since=since)

  if runs_query:
    ids = None
    if conversations is not None:
      ids = [c.conversation_id if isinstance(c, ConversationSummary) else c for c in conversations]
    return mgr.import_from_runs_query(limit=limit, conversation_ids=ids, **kwargs)

  if conversations is None:
    raise ValueError("conversations list is required when bulk=False")

  ids = [c.conversation_id if isinstance(c, ConversationSummary) else c for c in conversations]
  return mgr.import_conversations(ids)


def transform(
  raw_data: dict,
  *,
  provider: str = "langsmith",
  api_key: str = "",
  project_id: str = "",
) -> Trajectory:
  """Transform raw conversation data without fetching. For custom pipelines."""
  p = ProviderFactory.create(provider, api_key, project_id)
  parsed = p.parse_conversation(raw_data)
  return p._build_trajectory(parsed)


def save(
  trajectories: Union[Trajectory, list[Trajectory]],
  output_dir: str,
) -> None:
  """Save trajectories to JSON files, one per conversation.

  Each file is named ``{output_dir}/{conversation_id}.json``.
  """
  if isinstance(trajectories, Trajectory):
    trajectories = [trajectories]
  out = Path(output_dir)
  out.mkdir(parents=True, exist_ok=True)
  for traj in trajectories:
    conv_id = traj.task.conversation_id or "unknown"
    safe_name = conv_id.replace("/", "_").replace("\\", "_")
    file_path = out / f"{safe_name}.json"
    with open(file_path, "w", encoding="utf-8") as f:
      json.dump(asdict(traj), f, indent=2, default=str)


def upload(
  trajectories: Union[Trajectory, list[Trajectory]],
  dataset: str,
) -> None:
  """Upload trajectories via the Trajectory API."""
  if _config is None:
    raise RuntimeError("SDK not initialised. Call trajectory_sdk.init(...) first.")

  if not _config.trajectory_api_key:
    raise ValueError(
      "trajectory_api_key is required for upload. "
      "Pass trajectory_api_key= to init() or set TRAJECTORY_API_KEY."
    )

  if isinstance(trajectories, Trajectory):
    trajectories = [trajectories]

  UploadManager(_config.api_base_url, _config.trajectory_api_key).upload(trajectories, dataset)
