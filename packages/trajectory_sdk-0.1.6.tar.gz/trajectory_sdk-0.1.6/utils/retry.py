"""Retry infrastructure: policy, non-retryable marker, and decorator."""

from __future__ import annotations

import logging
import time
from abc import ABC
from dataclasses import dataclass
from functools import wraps
from typing import Any, Callable

logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class RetryPolicy:
  """Configuration for retry behavior used by sync retry helpers."""

  max_retries: int = 3
  initial_backoff_seconds: float = 1.0
  backoff_multiplier: float = 2.0


class NonRetryableError(Exception):
  """Raise inside a retryable method to fail immediately without retrying."""


class Retryable(ABC):
  """Mixin for components that support retry logic."""

  def get_retry_policy(self) -> RetryPolicy:
    return RetryPolicy()

  def on_failure(self, exception: Exception, *args: Any, **kwargs: Any) -> Any:
    raise RuntimeError(f"{self.__class__.__name__} failed: {exception}") from exception


def sync_catch_and_retry() -> Callable:
  """Decorator for sync methods on Retryable classes."""

  def decorator(func: Callable[..., Any]) -> Callable[..., Any]:
    @wraps(func)
    def _wrapped(*args: Any, **kwargs: Any) -> Any:
      self = args[0] if args else None
      if not isinstance(self, Retryable):
        raise TypeError(
          f"{func.__qualname__} is decorated with @sync_catch_and_retry(), "  # type: ignore
          "but the method is not on a Retryable instance."
        )
      policy = self.get_retry_policy()
      attempts = policy.max_retries + 1
      backoff = policy.initial_backoff_seconds

      for attempt_idx in range(1, attempts + 1):
        try:
          return func(*args, **kwargs)
        except NonRetryableError as e:
          logger.info("%s failed with non-retryable error: %s", func.__qualname__, e)  # type: ignore
          return self.on_failure(e, *args, **kwargs)
        except Exception as e:
          if attempt_idx >= attempts:
            return self.on_failure(e, *args, **kwargs)
          logger.warning(
            "%s attempt %d/%d failed: %s: %s. Retrying...",
            func.__qualname__,  # type: ignore
            attempt_idx,
            attempts,
            type(e).__name__,
            e,
          )
          time.sleep(backoff)
          backoff *= policy.backoff_multiplier

    return _wrapped

  return decorator
