import pytest
from zschrome.protocol import build_request, parse_response, build_field_spec
from zschrome.selector import Selector
from zschrome.field import Field


def test_build_request_simple():
    req = build_request("get_text", selector=Selector.css(".title"))
    assert req["action"] == "get_text"
    assert "id" in req
    assert req["params"]["selector"] == {"type": "css", "value": ".title"}


def test_build_request_with_variables():
    sel = Selector.css(".card:nth-child({n})").bind(n=3)
    req = build_request("click", selector=sel)
    assert req["params"]["selector"]["variables"] == {"n": 3}


def test_build_request_with_tab_id():
    req = build_request("click", selector=Selector.css(".btn"), tab_id=123)
    assert req["tab_id"] == 123


def test_parse_response_success():
    result = parse_response({"id": "1", "ok": True, "data": {"text": "hello"}})
    assert result == {"text": "hello"}


def test_parse_response_error():
    from zschrome.errors import SelectorNotFound
    with pytest.raises(SelectorNotFound):
        parse_response({"id": "1", "ok": False, "error": "not found", "code": "SELECTOR_NOT_FOUND"})


def test_parse_response_no_code():
    from zschrome.errors import ZSChromeError
    with pytest.raises(ZSChromeError):
        parse_response({"id": "1", "ok": False, "error": "something wrong"})


def test_parse_response_unknown_code():
    from zschrome.errors import ZSChromeError
    with pytest.raises(ZSChromeError):
        parse_response({"id": "1", "ok": False, "error": "x", "code": "UNKNOWN_CODE"})


def test_build_field_spec_text():
    spec = build_field_spec(Field.text(".title"))
    assert spec == {"extract": "text", "selector": {"type": "css", "value": ".title"}}


def test_build_field_spec_attr():
    spec = build_field_spec(Field.attr("href", "a"))
    assert spec["extract"] == "attr"
    assert spec["attr_name"] == "href"


def test_build_request_id_increment():
    req1 = build_request("click", selector=Selector.css(".a"))
    req2 = build_request("click", selector=Selector.css(".b"))
    id1 = int(req1["id"].split("-")[1])
    id2 = int(req2["id"].split("-")[1])
    assert id2 == id1 + 1
