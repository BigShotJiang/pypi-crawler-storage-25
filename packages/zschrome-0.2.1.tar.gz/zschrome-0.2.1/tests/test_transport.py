import asyncio
import pytest
from zschrome.transport import Transport


class FakeWebSocket:
    """Simulates a WebSocket for testing Transport."""
    def __init__(self):
        self.sent = []
        self._incoming = asyncio.Queue()
        self._open = True
        self._closed = False

    async def send(self, text):
        if not self._open:
            raise ConnectionError("not open")
        self.sent.append(text)

    async def recv(self):
        return await self._incoming.get()

    async def close(self):
        self._open = False
        self._closed = True

    def push_incoming(self, text):
        self._incoming.put_nowait(text)

    @property
    def closed(self):
        return self._closed


@pytest.mark.asyncio
async def test_transport_send():
    fake = FakeWebSocket()
    t = Transport("127.0.0.1", 9527)
    t._ws = fake
    t._connected = True

    await t.send({"action": "click", "params": {}})
    assert len(fake.sent) == 1
    assert '"action"' in fake.sent[0]


@pytest.mark.asyncio
async def test_transport_receive():
    t = Transport("127.0.0.1", 9527)

    await t._receive_queue.put({"id": "1", "ok": True, "data": "hello"})
    response = await t.receive()
    assert response == {"id": "1", "ok": True, "data": "hello"}


@pytest.mark.asyncio
async def test_transport_close():
    fake = FakeWebSocket()
    t = Transport("127.0.0.1", 9527)
    t._ws = fake
    t._connected = True

    await t.close()
    assert fake.closed
    assert not t._connected
