import pytest
from zschrome.errors import (
    ZSChromeError,
    ConnectionLost,
    TimeoutError,
    SelectorNotFound,
    ActionError,
)


def test_base_error():
    err = ZSChromeError("something went wrong")
    assert str(err) == "something went wrong"
    assert isinstance(err, Exception)


def test_error_hierarchy():
    assert issubclass(ConnectionLost, ZSChromeError)
    assert issubclass(TimeoutError, ZSChromeError)
    assert issubclass(SelectorNotFound, ZSChromeError)
    assert issubclass(ActionError, ZSChromeError)


def test_error_can_be_caught_by_base():
    try:
        raise SelectorNotFound(".missing")
    except ZSChromeError as e:
        assert ".missing" in str(e)


def test_error_with_details():
    err = ActionError("element is disabled", code="ELEMENT_DISABLED")
    assert err.args[0] == "element is disabled"
    assert err.details == {"code": "ELEMENT_DISABLED"}
