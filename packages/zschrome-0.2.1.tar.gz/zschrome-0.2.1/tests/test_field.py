import pytest
from zschrome.field import Field


def test_field_text_default():
    f = Field.text()
    d = f.to_dict()
    assert d["extract"] == "text"


def test_field_text_with_sub_selector():
    f = Field.text(".title")
    d = f.to_dict()
    assert d["extract"] == "text"
    assert d["selector"] == {"type": "css", "value": ".title"}


def test_field_attr():
    f = Field.attr("href")
    d = f.to_dict()
    assert d["extract"] == "attr"
    assert d["attr_name"] == "href"


def test_field_attr_with_sub_selector():
    f = Field.attr("src", "img.thumb")
    d = f.to_dict()
    assert d["extract"] == "attr"
    assert d["attr_name"] == "src"
    assert d["selector"] == {"type": "css", "value": "img.thumb"}


def test_field_html():
    f = Field.html()
    d = f.to_dict()
    assert d["extract"] == "html"


def test_field_html_with_sub_selector():
    f = Field.html(".content")
    d = f.to_dict()
    assert d["extract"] == "html"
    assert d["selector"] == {"type": "css", "value": ".content"}


def test_field_exists():
    f = Field.exists(".coupon-badge")
    d = f.to_dict()
    assert d["extract"] == "exists"
    assert d["selector"] == {"type": "css", "value": ".coupon-badge"}


def test_field_text_contains():
    f = Field.text_contains("价格")
    d = f.to_dict()
    assert d["extract"] == "text_contains"
    assert d["pattern"] == "价格"


def test_field_text_matches():
    f = Field.text_matches(r"\d+件")
    d = f.to_dict()
    assert d["extract"] == "text_matches"
    assert d["pattern"] == r"\d+件"


def test_field_repr():
    f = Field.text(".title")
    assert "Field" in repr(f)
    assert "text" in repr(f)
