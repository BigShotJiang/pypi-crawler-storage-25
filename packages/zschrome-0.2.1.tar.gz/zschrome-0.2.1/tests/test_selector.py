import pytest
from zschrome.selector import Selector


def test_css_selector_basic():
    sel = Selector.css(".product-card")
    assert sel.to_dict() == {"type": "css", "value": ".product-card"}


def test_xpath_selector_basic():
    sel = Selector.xpath("//div[@class='product']")
    assert sel.to_dict() == {"type": "xpath", "value": "//div[@class='product']"}


def test_selector_bind():
    sel = Selector.css(".card:nth-child({n}) .{field}")
    bound = sel.bind(n=3, field="price")
    d = bound.to_dict()
    assert d["variables"] == {"n": 3, "field": "price"}


def test_selector_bind_chaining():
    sel = Selector.css(".card:nth-child({n}) .{field}")
    bound = sel.bind(n=3).bind(field="title")
    d = bound.to_dict()
    assert d["variables"] == {"n": 3, "field": "title"}


def test_selector_find():
    container = Selector.css(".product-list")
    child = container.find(".title")
    d = child.to_dict()
    assert d["value"] == ".product-list .title"


def test_selector_sibling():
    sel = Selector.css(".card")
    next_el = sel.sibling("+ .pagination")
    d = next_el.to_dict()
    assert d["value"] == ".card + .pagination"


def test_selector_parent():
    sel = Selector.css(".title")
    parent = sel.parent()
    d = parent.to_dict()
    assert d.get("modifier") == "parent"


def test_selector_where():
    sel = Selector.css(".product-card").where("[data-type='hot']")
    d = sel.to_dict()
    assert d["value"] == ".product-card[data-type='hot']"


def test_selector_repr():
    sel = Selector.css(".card")
    assert "Selector" in repr(sel)
    assert ".card" in repr(sel)
