import pytest
from zschrome.page import Page, TableData
from zschrome.selector import Selector
from zschrome.field import Field


class FakeTransport:
    def __init__(self, responses=None):
        self.sent = []
        self._responses = responses or []
        self._idx = 0
        self.connected = True

    async def request(self, msg, timeout=30):
        self.sent.append(msg)
        if self._idx < len(self._responses):
            resp = self._responses[self._idx]
            self._idx += 1
            return resp
        return {"id": msg["id"], "ok": True, "data": None}

    async def send(self, msg):
        self.sent.append(msg)

    async def close(self):
        self.connected = False

    async def connect(self):
        self.connected = True

    async def receive(self, timeout=None):
        return {}


@pytest.mark.asyncio
async def test_page_click():
    t = FakeTransport()
    page = Page(t, tab_id=1)
    await page.click(Selector.css(".btn"))
    assert t.sent[0]["action"] == "click"
    assert t.sent[0]["params"]["selector"] == {"type": "css", "value": ".btn"}


@pytest.mark.asyncio
async def test_page_type():
    t = FakeTransport()
    page = Page(t, tab_id=1)
    await page.type(Selector.css("#q"), "hello")
    assert t.sent[0]["action"] == "type"
    assert t.sent[0]["params"]["text"] == "hello"


@pytest.mark.asyncio
async def test_page_press_key():
    t = FakeTransport()
    page = Page(t, tab_id=1)
    await page.press_key("Enter")
    assert t.sent[0]["action"] == "press_key"
    assert t.sent[0]["params"]["key"] == "Enter"


@pytest.mark.asyncio
async def test_page_select():
    t = FakeTransport()
    page = Page(t, tab_id=1)
    await page.select(Selector.css("#category"), label="电子产品")
    assert t.sent[0]["action"] == "select"
    assert t.sent[0]["params"]["by"] == "label"
    assert t.sent[0]["params"]["value"] == "电子产品"


@pytest.mark.asyncio
async def test_page_get_text():
    t = FakeTransport([{"id": "req-1", "ok": True, "data": "hello world"}])
    page = Page(t, tab_id=1)
    result = await page.get_text(Selector.css(".title"))
    assert result == "hello world"


@pytest.mark.asyncio
async def test_page_get_fields():
    t = FakeTransport([
        {"id": "req-1", "ok": True, "data": {"title": "keyboard", "price": "¥299"}}
    ])
    page = Page(t, tab_id=1)
    result = await page.get_fields(
        Selector.css(".detail"),
        {"title": Field.text(".title"), "price": Field.text(".price")}
    )
    assert result == {"title": "keyboard", "price": "¥299"}


@pytest.mark.asyncio
async def test_page_get_table():
    t = FakeTransport([
        {"id": "req-1", "ok": True, "data": {
            "headers": ["Name", "Price"],
            "rows": [["A", "100"], ["B", "200"]]
        }}
    ])
    page = Page(t, tab_id=1)
    result = await page.get_table(Selector.css("table"))
    assert result.headers == ["Name", "Price"]
    assert len(result.rows) == 2


@pytest.mark.asyncio
async def test_page_wait():
    t = FakeTransport()
    page = Page(t, tab_id=1)
    await page.wait(Selector.css(".result"), timeout=5)
    assert t.sent[0]["action"] == "wait"
    assert t.sent[0]["params"]["timeout_seconds"] == 5


@pytest.mark.asyncio
async def test_page_navigate():
    t = FakeTransport()
    page = Page(t, tab_id=1)
    await page.navigate("https://example.com")
    assert t.sent[0]["action"] == "navigate"
    assert t.sent[0]["params"]["url"] == "https://example.com"


@pytest.mark.asyncio
async def test_page_eval():
    t = FakeTransport([{"id": "req-1", "ok": True, "data": 42}])
    page = Page(t, tab_id=1)
    result = await page.eval("1 + 41")
    assert result == 42
