import pytest
from zschrome.browser import Browser
from zschrome.page import Page


class FakeTransport:
    def __init__(self):
        self.sent = []
        self.connected = True

    async def request(self, msg, timeout=30):
        self.sent.append(msg)
        if msg["action"] == "eval" and "document.location.href" in msg.get("params", {}).get("code", ""):
            return {"id": msg["id"], "ok": True, "data": "https://example.com"}
        return {"id": msg["id"], "ok": True, "data": None}

    async def send(self, msg):
        self.sent.append(msg)

    async def close(self):
        self.connected = False

    async def connect(self):
        self.connected = True


@pytest.mark.asyncio
async def test_browser_connect_creates_current_page():
    t = FakeTransport()
    browser = Browser()
    browser._transport = t
    browser._current_page = Page(t, tab_id=0)
    page = browser.current_page
    assert page is not None
    assert page.tab_id == 0


@pytest.mark.asyncio
async def test_browser_close():
    t = FakeTransport()
    browser = Browser()
    browser._transport = t
    browser._current_page = Page(t, tab_id=0)
    await browser.close()
    assert not t.connected
