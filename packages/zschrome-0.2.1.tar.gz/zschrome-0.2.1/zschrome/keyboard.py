from __future__ import annotations
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from zschrome.page import Page


class Keyboard:
    """Keyboard actions dispatched to the currently focused element.

    Usage::

        await page.keyboard.press("Enter")
        await page.keyboard.type("hello")
        await page.keyboard.insert_text("hello")
    """

    def __init__(self, page: Page):
        self._page = page

    async def press(self, key: str) -> None:
        """Press a key or key combination.

        Examples: ``"Enter"``, ``"Tab"``, ``"Control+A"``, ``"Shift+Tab"``.
        """
        await self._page._call("locator_press", key=key)

    async def type(self, text: str) -> None:
        """Type text character by character at the current focus.

        Dispatches keydown/keypress/input/keyup for each character, plus a
        final change event. Uses the native value setter so framework-managed
        inputs (React/Vue/Angular) pick up the change.
        """
        await self._page._call("locator_type", text=str(text))

    async def insert_text(self, text: str) -> None:
        """Directly set the value of the focused element.

        No keyboard events are dispatched — just the native setter + input +
        change events. Faster than :meth:`type` when character-by-character
        simulation isn't needed.
        """
        await self._page._call("locator_set_text", text=str(text))

    async def copy(self, text: str) -> None:
        """Copy *text* to the system clipboard.

        Uses an off-screen textarea + ``execCommand('copy')``.
        """
        await self._page._call("locator_copy", text=str(text))

    async def paste(self) -> None:
        """Paste from clipboard (Ctrl+V) at the currently focused element."""
        await self._page._call("locator_paste")
