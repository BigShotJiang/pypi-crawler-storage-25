from __future__ import annotations
from typing import Optional, Any
from dataclasses import dataclass

from zschrome.selector import Selector, xpath_to_css
from zschrome.field import Field
from zschrome.protocol import build_request, build_field_spec, parse_response


def _auto_selector(selector: str) -> Selector:
    """Auto-detect XPath vs CSS and return the appropriate Selector.

    XPath is detected when the string starts with ``//`` or ``(//``.
    Convertible XPath is converted to CSS; others are kept as XPath.
    """
    s = selector.strip()
    if s.startswith("(//"):
        s = s[1:]
    if s.startswith("//"):
        css = xpath_to_css(s)
        if css != s:
            return Selector.css(css)
        return Selector.xpath(s)
    return Selector.css(selector)


@dataclass
class TableData:
    headers: list[str]
    rows: list[list[str]]


class Page:
    """Represents a single browser tab. All actions target this tab."""

    def __init__(self, transport, tab_id: int):
        self._transport = transport
        self._tab_id = tab_id

    @property
    def tab_id(self) -> int:
        return self._tab_id

    async def _call(self, action: str, selector: Optional[Selector] = None, **params) -> Any:
        if "tab_id" not in params:
            params["tab_id"] = self._tab_id
        req = build_request(action, selector=selector, **params)
        return parse_response(await self._transport.request(req))

    # --- Page control ---

    async def navigate(self, url: str, timeout: float = 60.0) -> None:
        await self._call("navigate", url=url, timeout=timeout)

    async def refresh(self) -> None:
        await self._call("refresh")

    async def close(self) -> None:
        await self._call("close_tab")

    # ── Tab management ──

    async def list_tabs(self) -> list[dict]:
        """Return all open browser tabs with id, url, title, active flag."""
        return await self._call("list_tabs")

    async def switch_to_tab(self, tab_id: int) -> None:
        """Activate the tab with the given *tab_id*."""
        await self._call("switch_to_tab", tab_id=tab_id)

    async def find_tab(self, url_substring: str) -> Optional[int]:
        """Find a tab whose URL contains *url_substring* and return its id.

        Returns None if no matching tab is found.
        """
        tabs = await self.list_tabs()
        for t in tabs:
            if url_substring in (t.get("url") or ""):
                return t["id"]
        return None

    async def scroll_to(self, x: int = 0, y: int = 0, *, selector: Optional[Selector] = None) -> None:
        if selector is not None:
            await self._call("scroll", selector=selector)
        else:
            await self._call("scroll", x=x, y=y)

    # --- Data reading ---

    async def get_html(self, selector: Selector) -> str:
        return await self._call("get_html", selector=selector)

    async def get_text(self, selector: Selector) -> str:
        return await self._call("get_text", selector=selector)

    async def get_fields(self, container: Selector, fields: dict[str, Field]) -> dict:
        field_specs = {name: build_field_spec(f) for name, f in fields.items()}
        return await self._call("get_fields", selector=container, fields=field_specs)

    async def get_table(self, selector: Selector) -> TableData:
        data = await self._call("get_table", selector=selector)
        return TableData(headers=data["headers"], rows=data["rows"])

    async def extract_list(
        self, sample_a: Selector, sample_b: Selector, fields: dict[str, Field]
    ) -> list[dict]:
        field_specs = {name: build_field_spec(f) for name, f in fields.items()}
        return await self._call(
            "extract_list",
            sample_a=sample_a.to_dict(),
            sample_b=sample_b.to_dict(),
            fields=field_specs,
        )

    # --- Interaction ---

    async def click(self, selector: Selector) -> None:
        await self._call("click", selector=selector)

    async def right_click(self, selector: Selector) -> None:
        await self._call("right_click", selector=selector)

    async def hover(self, selector: Selector) -> None:
        await self._call("hover", selector=selector)

    async def move_to(self, selector: Selector) -> None:
        await self._call("move_to", selector=selector)

    async def type(self, selector: Selector, text: str) -> None:
        await self._call("type", selector=selector, text=text)

    async def set_text(self, selector: Selector, text: str) -> None:
        await self._call("set_text", selector=selector, text=text)

    async def press_key(self, key: str) -> None:
        await self._call("press_key", key=key)

    async def select(self, selector: Selector, *, label: Optional[str] = None,
                     value: Optional[str] = None, index: Optional[int] = None) -> None:
        if label is not None:
            await self._call("select", selector=selector, by="label", value=label)
        elif value is not None:
            await self._call("select", selector=selector, by="value", value=value)
        elif index is not None:
            await self._call("select", selector=selector, by="index", value=index)
        else:
            raise ValueError("Must specify label, value, or index")

    async def check(self, selector: Selector) -> None:
        await self._call("check", selector=selector)

    async def uncheck(self, selector: Selector) -> None:
        await self._call("uncheck", selector=selector)

    # --- Wait ---

    async def wait(self, selector: Selector, *,
                   state: str = "visible",
                   timeout: float = 30.0,
                   text_contains: Optional[str] = None) -> None:
        params = {"state": state, "timeout_seconds": timeout}
        if text_contains:
            params["text_contains"] = text_contains
        await self._call("wait", selector=selector, **params)

    async def wait_manual(self, message: str, timeout: Optional[float] = None) -> None:
        params: dict = {"message": message}
        if timeout is not None:
            params["timeout_seconds"] = timeout
        await self._call("wait_manual", **params)

    # --- Screenshots & Save ---

    async def screenshot_element(self, selector: Selector, path: Optional[str] = None) -> str:
        import base64
        b64 = await self._call("screenshot_element", selector=selector)
        if path:
            with open(path, "wb") as f:
                f.write(base64.b64decode(b64))
        return b64

    async def screenshot_page(self, path: Optional[str] = None) -> str:
        import base64
        b64 = await self._call("screenshot_page")
        if path:
            with open(path, "wb") as f:
                f.write(base64.b64decode(b64))
        return b64

    async def save_as(self, format: str) -> None:
        await self._call("save_as", format=format)

    # ── JS Execution ──

    async def eval(self, code: str) -> Any:
        """Evaluate a simple expression in the page (property chains, method calls)."""
        return await self._call("eval", code=code)

    async def eval_raw(self, code: str) -> Any:
        """Run arbitrary JavaScript in the page's isolated world.

        Unlike :meth:`eval`, this supports full JS: loops, closures, destructuring,
        arrow functions, etc. The *code* is wrapped in an IIFE so it can use
        ``return`` to send data back.

        Example::

            products = await page.eval_raw('''
                const cards = document.querySelectorAll('.product-card');
                return Array.from(cards).map(c => ({
                    title: c.querySelector('.title')?.innerText,
                    price: c.querySelector('.price')?.innerText,
                }));
            ''')
        """
        return await self._call("eval_raw", code=code)

    # ── Bulk extraction (CSP-safe, no eval) ──

    async def extract_cards(
        self,
        card_selectors: list[str] = None,
        title_selectors: list[str] = None,
        price_selectors: list[str] = None,
        shop_selectors: list[str] = None,
        sales_selectors: list[str] = None,
    ) -> list[dict]:
        """Extract product-card data from the page using pure DOM heuristics.

        Each parameter is a list of CSS selectors tried in order. Default
        selectors use case-insensitive matching and common e-commerce patterns.

        Returns a list of dicts with keys: title, price, shop, sales, link.
        """
        params = {}
        if card_selectors: params["card_selectors"] = card_selectors
        if title_selectors: params["title_selectors"] = title_selectors
        if price_selectors: params["price_selectors"] = price_selectors
        if shop_selectors: params["shop_selectors"] = shop_selectors
        if sales_selectors: params["sales_selectors"] = sales_selectors
        return await self._call("locator_extract_cards", **params)

    # --- Bulk extraction (CSP-safe, no eval) ---

    async def query_all(self, selector: Selector, fields: dict[str, Field]) -> list[dict]:
        field_specs = {name: build_field_spec(f) for name, f in fields.items()}
        return await self._call("query_all", selector=selector, fields=field_specs)

    async def click_by_text(self, text: str) -> bool:
        return await self._call("click_by_text", text=text)

    # --- Element Picker ---

    async def start_picker(self) -> None:
        await self._call("start_picker")

    async def stop_picker(self) -> None:
        await self._call("stop_picker")

    async def pick_element(self) -> Selector:
        await self._call("start_picker")
        try:
            while True:
                msg = await self._transport.receive(timeout=120)
                if msg.get("type") == "picker_result":
                    css_value = msg.get("css", "")
                    return Selector.css(css_value)
        finally:
            await self._call("stop_picker")

    async def pick_elements(self, count: int = 1) -> list[Selector]:
        selectors = []
        await self._call("start_picker")
        try:
            for _ in range(count):
                while True:
                    msg = await self._transport.receive(timeout=120)
                    if msg.get("type") == "picker_result":
                        css_value = msg.get("css", "")
                        selectors.append(Selector.css(css_value))
                        break
        finally:
            await self._call("stop_picker")
        return selectors

    # ── Locator API (Playwright-style) ──

    def locator(self, selector: str) -> "Locator":
        """Create a Locator for *selector*, a CSS selector string.

        Supports comma-separated groups; the first sub-selector that matches
        a visible element wins. The returned Locator auto-waits before every
        action.
        """
        from zschrome.locator import Locator
        return Locator(self, selector)

    def get_by_text(self, text: str, *, exact: bool = False) -> "Locator":
        """Create a Locator that finds elements by visible text content.

        Searches ``a, button, span, div, li, p`` and elements with
        ``[role="button"]`` / ``[role="link"]``.

        Args:
            text: Text to search for (substring match unless *exact* is True).
            exact: If True, require exact match instead of substring.
        """
        from zschrome.locator import Locator
        strategy = "text_exact" if exact else "text"
        return Locator(self, text, strategy=strategy)

    def get_by_placeholder(self, text: str) -> "Locator":
        """Create a Locator for an input/textarea with *text* as placeholder."""
        from zschrome.locator import Locator
        return Locator(self, f'[placeholder="{text}"]')

    def get_by_role(self, role: str, *, name: str = None) -> "Locator":
        """Create a Locator for elements with an ARIA *role*.

        Args:
            role: The ARIA role value.
            name: Optional accessible name (matches ``aria-label`` or ``name`` attribute).
        """
        from zschrome.locator import Locator
        if name:
            return Locator(self, f'[role="{role}"][aria-label="{name}"], [role="{role}"][name="{name}"]')
        return Locator(self, f'[role="{role}"]')

    @property
    def keyboard(self) -> "Keyboard":
        """Return a :class:`Keyboard` instance bound to this page."""
        from zschrome.keyboard import Keyboard
        return Keyboard(self)

    async def url(self) -> str:
        return await self._call("get_url")

    # ── CDP global actions (trusted OS-level events via chrome.debugger) ──

    async def globalclick(self, selector: str) -> None:
        """Click an element using CDP Input.dispatchMouseEvent.

        Generates real OS-level mouse events that bypass ``isTrusted`` checks.
        Use this on sites (e.g. Taobao) that ignore synthetic DOM events.

        Accepts CSS selectors or XPath expressions. XPath is auto-detected
        (strings starting with ``//`` or ``(//``) and converted to CSS.
        For complex XPath, use :meth:`xclick` which falls back to XPath
        evaluation if CSS conversion fails.

        Args:
            selector: CSS or XPath selector string.
        """
        sel = _auto_selector(selector)
        await self._call("globalclick", selector=sel)

    async def globaltype(self, text: str) -> None:
        """Type text using CDP Input.dispatchKeyEvent (trusted keystrokes).

        Each character is dispatched individually as a ``char`` event.
        """
        await self._call("globaltype", text=str(text))

    async def wait_for_load(self, timeout: float = 60.0) -> None:
        """Wait for the page to reach ``readyState === 'complete'`` via CDP.

        Polls ``document.readyState`` every 500 ms. Useful after
        ``Browser.connect_or_launch`` (which doesn't go through ``navigate``).
        """
        await self._call("wait_for_load", timeout=timeout)

    async def wait_for_selector(self, selector: str, timeout: float = 30.0) -> None:
        """Wait for an element matching *selector* to appear in the DOM via CDP.

        Searches the main document and all iframes. Useful when content is
        dynamically loaded after page load.

        Accepts CSS selectors or XPath expressions (auto-detected).

        Args:
            selector: CSS or XPath selector string.
            timeout: Max seconds to wait.
        """
        sel = _auto_selector(selector)
        await self._call("wait_for_selector", selector=sel, timeout=timeout)

    async def globalkey(self, key: str) -> None:
        """Press a key using CDP (trusted OS-level key event).

        Dispatches rawKeyDown + char + keyUp sequence. Supports named keys
        like ``"Enter"``, ``"Tab"``, ``"Escape"``, ``"Backspace"``, etc.

        Args:
            key: Key name (e.g. ``"Enter"``, ``"Tab"``, ``"a"``).
        """
        await self._call("globalkey", key=key)

    async def xclick(self, xpath: str) -> None:
        """Click an element by XPath (CDP trusted event).

        Unlike :meth:`globalclick`, this method explicitly uses XPath.
        If the XPath cannot be converted to CSS it falls back to
        XPath evaluation in the content script.

        Args:
            xpath: XPath expression.
        """
        css = xpath_to_css(xpath)
        if css != xpath:
            sel = Selector.css(css)
        else:
            sel = Selector.xpath(xpath)
        await self._call("globalclick", selector=sel)

    async def xwait(self, xpath: str, timeout: float = 30.0) -> None:
        """Wait for an element matching *xpath* to appear in the DOM.

        Like :meth:`xclick`, explicitly uses XPath with CSS fallback.

        Args:
            xpath: XPath expression.
            timeout: Max seconds to wait.
        """
        css = xpath_to_css(xpath)
        if css != xpath:
            sel = Selector.css(css)
        else:
            sel = Selector.xpath(xpath)
        await self._call("wait_for_selector", selector=sel, timeout=timeout)
