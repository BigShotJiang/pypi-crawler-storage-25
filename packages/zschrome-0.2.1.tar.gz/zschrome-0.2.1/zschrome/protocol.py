import itertools
from typing import Any, Optional

from zschrome.selector import Selector
from zschrome.field import Field
from zschrome.errors import (
    ZSChromeError,
    SelectorNotFound,
    SelectorAmbiguous,
    ActionError,
    TimeoutError,
    PageClosedError,
    ProtocolError,
)

_counter = itertools.count(1)

ERROR_CODE_MAP = {
    "SELECTOR_NOT_FOUND": SelectorNotFound,
    "SELECTOR_AMBIGUOUS": SelectorAmbiguous,
    "ELEMENT_NOT_INTERACTABLE": ActionError,
    "ELEMENT_DISABLED": ActionError,
    "PAGE_NOT_READY": ActionError,
    "TAB_CLOSED": PageClosedError,
    "TIMEOUT": TimeoutError,
    "INVALID_PARAMS": ZSChromeError,
    "INTERNAL_ERROR": ProtocolError,
}


def build_request(
    action: str,
    selector: Optional[Selector] = None,
    tab_id: Optional[int] = None,
    **params,
) -> dict:
    msg: dict = {
        "id": f"req-{next(_counter)}",
        "action": action,
        "params": {},
    }
    if tab_id is not None:
        msg["tab_id"] = tab_id
    if selector is not None:
        msg["params"]["selector"] = selector.to_dict()
    msg["params"].update(params)
    return msg


def build_field_spec(field: Field) -> dict:
    return field.to_dict()


def parse_response(response: dict) -> Any:
    if response.get("ok"):
        data = response.get("data")
        # Content-script errors are wrapped as {error: "msg"} — the SW always
        # sends ok:true, so we detect them here and raise properly.
        if isinstance(data, dict) and list(data.keys()) == ["error"]:
            raise ProtocolError(data["error"])
        return data

    error_msg = response.get("error", "Unknown error")
    error_code = response.get("code", "")

    exc_cls = ERROR_CODE_MAP.get(error_code, ZSChromeError)
    raise exc_cls(error_msg)
