from __future__ import annotations
from typing import Optional, Any, TYPE_CHECKING

if TYPE_CHECKING:
    from zschrome.page import Page


class Locator:
    """Playwright-style Locator with built-in auto-waiting.

    Every action method polls the DOM (in the content script) until a visible,
    enabled element matches, or *timeout* seconds expire.

    CSS selector groups (comma-separated) are tried in order; the first
    sub-selector that produces visible matches wins. This eliminates manual
    try/except fallback loops for basic operations.

    Usage::

        await page.locator("input#q, input[name='q']").fill("keyword")
        await page.keyboard.press("Enter")
    """

    def __init__(
        self,
        page: Page,
        selector: str,
        *,
        strategy: str = "css",
        index: Optional[int] = None,
    ):
        self._page = page
        self._selector = selector
        self._strategy = strategy  # "css", "text", "text_exact"
        self._index = index        # None=first, 0=first, N=nth, -1=last

    async def _call(self, action: str, **params) -> Any:
        from zschrome.selector import Selector
        sel = Selector.css(self._selector)
        params["locator_strategy"] = self._strategy
        if self._index is not None:
            params["locator_index"] = self._index
        return await self._page._call(action, selector=sel, **params)

    # ── Actions ──

    async def click(self, *, timeout: float = 30.0) -> None:
        """Click the element. Auto-waits for visibility and enabled state."""
        await self._call("locator_click", timeout=timeout)

    async def fill(self, text: str, *, timeout: float = 30.0) -> None:
        """Clear the field and fill with *text*.

        Composes click + clear + paste (Ctrl+V). The most reliable cross-site
        approach for framework-managed inputs.
        """
        await self._call("locator_fill", text=str(text), timeout=timeout)

    async def clear(self, *, timeout: float = 30.0) -> None:
        """Clear the input's value. Focuses the element first."""
        await self._call("locator_clear", timeout=timeout)

    async def paste(self, text: str, *, timeout: float = 30.0) -> None:
        """Paste *text* into the element via Ctrl+V.

        Copies *text* to clipboard, focuses the element, clears it, then
        dispatches Ctrl+V + InputEvent. More reliable than fill() on some
        framework-managed inputs.
        """
        await self._call("locator_paste", text=str(text), timeout=timeout)

    async def type(self, text: str, *, timeout: float = 30.0) -> None:
        """Type *text* character by character without clearing first."""
        await self._call("locator_type", text=str(text), timeout=timeout)

    async def press(self, key: str) -> None:
        """Press a key or key combination (e.g. ``"Enter"``, ``"Control+A"``)."""
        await self._call("locator_press", key=key)

    async def hover(self, *, timeout: float = 30.0) -> None:
        """Hover the mouse over the element."""
        await self._call("locator_hover", timeout=timeout)

    async def check(self, *, timeout: float = 30.0) -> None:
        """Check a checkbox or radio button."""
        await self._call("locator_check", timeout=timeout)

    async def uncheck(self, *, timeout: float = 30.0) -> None:
        """Uncheck a checkbox."""
        await self._call("locator_uncheck", timeout=timeout)

    async def select_option(
        self,
        *,
        label: Optional[str] = None,
        value: Optional[str] = None,
        index: Optional[int] = None,
        timeout: float = 30.0,
    ) -> None:
        """Select an option in a ``<select>`` element."""
        if label is not None:
            await self._call("locator_select_option", by="label", value=label, timeout=timeout)
        elif value is not None:
            await self._call("locator_select_option", by="value", value=value, timeout=timeout)
        elif index is not None:
            await self._call("locator_select_option", by="index", value=index, timeout=timeout)
        else:
            raise ValueError("Must specify label, value, or index")

    # ── Data reading ──

    async def text_content(self, *, timeout: float = 30.0) -> str:
        """Return visible text content. Auto-waits for element presence."""
        return await self._call("locator_text_content", timeout=timeout)

    async def inner_html(self, *, timeout: float = 30.0) -> str:
        """Return inner HTML. Auto-waits for element presence."""
        return await self._call("locator_inner_html", timeout=timeout)

    async def get_attribute(self, name: str, *, timeout: float = 30.0) -> Optional[str]:
        """Return an attribute value, or *None*. Auto-waits for element presence."""
        return await self._call("locator_get_attribute", name=name, timeout=timeout)

    # ── State ──

    async def is_visible(self) -> bool:
        """Check if the element is currently visible (no wait)."""
        return await self._call("locator_is_visible")

    async def is_enabled(self) -> bool:
        """Check if the element is currently enabled (5 s wait)."""
        return await self._call("locator_is_enabled")

    async def count(self) -> int:
        """Return the number of visible, enabled matching elements."""
        result = await self._call("locator_count")
        return int(result)

    # ── Sub-locators ──

    def locator(self, selector: str) -> Locator:
        """Create a nested Locator scoped to descendants of this one."""
        return Locator(
            self._page,
            f"{self._selector} {selector}",
            strategy=self._strategy,
        )

    def first(self) -> Locator:
        """Return a Locator for the first matching element."""
        return Locator(self._page, self._selector, strategy=self._strategy, index=0)

    def last(self) -> Locator:
        """Return a Locator for the last matching element."""
        return Locator(self._page, self._selector, strategy=self._strategy, index=-1)

    def nth(self, index: int) -> Locator:
        """Return a Locator for the Nth matching element (0-based)."""
        return Locator(self._page, self._selector, strategy=self._strategy, index=index)

    # ── Collection ──

    async def all(self) -> list[Locator]:
        """Return a Locator for each matching element."""
        info = await self._call("locator_all")
        count = info.get("count", 0) if isinstance(info, dict) else int(info)
        effective_sel = (
            info.get("effective_selector", self._selector)
            if isinstance(info, dict)
            else self._selector
        )
        return [
            Locator(self._page, effective_sel, strategy=self._strategy, index=i)
            for i in range(count)
        ]

    async def all_text_contents(self) -> list[str]:
        """Extract text from all matching elements in a single round-trip."""
        return await self._call("locator_all_text_contents")

    async def all_inner_html(self) -> list[str]:
        """Extract inner HTML from all matching elements in a single round-trip."""
        return await self._call("locator_all_inner_html")

    # ── Wait ──

    async def wait_for(self, state: str = "visible", *, timeout: float = 30.0) -> None:
        """Wait for the element to reach *state* (``"visible"`` or ``"hidden"``)."""
        await self._call("locator_wait_for", state=state, timeout=timeout)

    # ── CDP global action ──

    async def globalclick(self) -> None:
        """Click via CDP Input.dispatchMouseEvent (trusted OS-level event).

        Bypasses ``isTrusted`` checks on sites that ignore synthetic DOM events
        (e.g. Taobao). Uses the locator's selector directly via CDP, without
        auto-waiting.
        """
        await self._call("globalclick")

    def __repr__(self) -> str:
        idx = f"[{self._index}]" if self._index is not None else ""
        return f"Locator({self._selector!r}{idx})"
