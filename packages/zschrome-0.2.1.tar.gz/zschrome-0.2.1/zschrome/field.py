from __future__ import annotations
from typing import Optional


class Field:
    """Defines how to extract a value from a DOM element."""

    def __init__(
        self,
        extract: str,
        sub_selector: Optional[str] = None,
        attr_name: Optional[str] = None,
        pattern: Optional[str] = None,
    ):
        self._extract = extract
        self._sub_selector = sub_selector
        self._attr_name = attr_name
        self._pattern = pattern

    @classmethod
    def text(cls, sub_selector: Optional[str] = None) -> Field:
        return cls("text", sub_selector=sub_selector)

    @classmethod
    def html(cls, sub_selector: Optional[str] = None) -> Field:
        return cls("html", sub_selector=sub_selector)

    @classmethod
    def attr(cls, attr_name: str, sub_selector: Optional[str] = None) -> Field:
        return cls("attr", sub_selector=sub_selector, attr_name=attr_name)

    @classmethod
    def exists(cls, sub_selector: str) -> Field:
        return cls("exists", sub_selector=sub_selector)

    @classmethod
    def text_contains(cls, pattern: str) -> Field:
        return cls("text_contains", pattern=pattern)

    @classmethod
    def text_matches(cls, pattern: str) -> Field:
        return cls("text_matches", pattern=pattern)

    def to_dict(self) -> dict:
        d: dict = {"extract": self._extract}
        if self._sub_selector:
            d["selector"] = {"type": "css", "value": self._sub_selector}
        if self._attr_name:
            d["attr_name"] = self._attr_name
        if self._pattern:
            d["pattern"] = self._pattern
        return d

    def __repr__(self) -> str:
        return f"Field({self._extract}, sub={self._sub_selector!r})"
