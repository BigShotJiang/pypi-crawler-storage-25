from __future__ import annotations
import re
from typing import Optional


def xpath_to_css(xpath: str) -> str:
    """Convert a subset of XPath to a CSS selector.

    Handles the most common patterns copyable from browser DevTools.
    For patterns that cannot be converted, the original string is returned
    (callers should warn or fall back to XPath-based evaluation).

    Conversions::

        //*[@id="foo"]              →  #foo
        //tag[@id="foo"]            →  tag#foo
        //*[@class="foo"]           →  .foo
        //tag[@class="foo"]         →  tag.foo
        /tag1/tag2                  →  tag1 > tag2
        //tag1//tag2                →  tag1 tag2
        tag[N]                      →  tag:nth-of-type(N)
        //tag[@attr="value"]        →  tag[attr="value"]
        //tag[contains(@attr,"v")]  →  tag[attr*="v"]
    """
    xpath = xpath.strip()

    # Normalise parenthesised forms: (//foo)[N] or (//foo)
    xpath = re.sub(r'^\(//', '//', xpath)
    xpath = re.sub(r'\)\[\d+\]$', '', xpath)
    xpath = re.sub(r'\)$', '', xpath)

    if not xpath.startswith("/"):
        return xpath

    # Split into path steps
    parts = _split_xpath_steps(xpath)
    css_parts = []

    for part in parts:
        css = _step_to_css(part)
        if css is None:
            return xpath
        css_parts.append(css)

    result = _build_css(xpath, css_parts)
    return result


def _split_xpath_steps(xpath: str) -> list[str]:
    """Extract tag/attribute steps from an XPath."""
    # Remove leading / or //
    xpath = re.sub(r"^/+", "", xpath)
    # Split on / but not inside brackets or quotes
    parts = []
    depth = 0
    current = []
    in_quote = False
    quote_char = None
    for ch in xpath:
        if in_quote:
            current.append(ch)
            if ch == quote_char:
                in_quote = False
            continue
        if ch in ('"', "'"):
            in_quote = True
            quote_char = ch
            current.append(ch)
            continue
        if ch == "[":
            depth += 1
        elif ch == "]":
            depth -= 1
        if ch == "/" and depth == 0:
            if current:
                parts.append("".join(current).strip())
            current = []
        else:
            current.append(ch)
    if current:
        parts.append("".join(current).strip())
    return [p for p in parts if p]


def _step_to_css(step: str) -> Optional[str]:
    """Convert a single XPath step to a CSS fragment. Returns None if impossible."""
    if step == "*":
        return "*"

    # Extract tag name and predicates
    m = re.match(r"^(\*|[a-zA-Z_][\w-]*)(.*)", step)
    if not m:
        return None
    tag = m.group(1)
    rest = m.group(2)

    css = tag if tag != "*" else ""

    # Handle predicates
    predicates = []
    depth = 0
    current = []
    for ch in rest:
        if ch == "[":
            depth += 1
            if depth == 1:
                continue
        elif ch == "]":
            depth -= 1
            if depth == 0:
                predicates.append("".join(current))
                current = []
                continue
        if depth > 0:
            current.append(ch)

    for pred in predicates:
        pred = pred.strip()

        # [@id="value"]
        m = re.match(r'^@id\s*=\s*["\']([^"\']+)["\']$', pred)
        if m:
            css = f"#{m.group(1)}"
            continue

        # [@class="value"]
        m = re.match(r'^@class\s*=\s*["\']([^"\']+)["\']$', pred)
        if m:
            if css:
                css += f".{m.group(1)}"
            else:
                css = f".{m.group(1)}"
            continue

        # [contains(@class, "value")]
        m = re.match(r'^contains\s*\(\s*@class\s*,\s*["\']([^"\']+)["\']\s*\)$', pred)
        if m:
            css += f'[class*="{m.group(1)}"]'
            continue

        # [contains(@attr, "value")]
        m = re.match(r'^contains\s*\(\s*@(\w+)\s*,\s*["\']([^"\']+)["\']\s*\)$', pred)
        if m:
            css += f'[{m.group(1)}*="{m.group(2)}"]'
            continue

        # [@attr="value"]
        m = re.match(r'^@(\w+)\s*=\s*["\']([^"\']+)["\']$', pred)
        if m:
            css += f'[{m.group(1)}="{m.group(2)}"]'
            continue

        # [@attr] (boolean attribute)
        m = re.match(r"^@(\w+)$", pred)
        if m:
            css += f"[{m.group(1)}]"
            continue

        # Numeric index [N]
        m = re.match(r"^(\d+)$", pred)
        if m:
            css += f":nth-of-type({m.group(1)})"
            continue

        # last()
        if pred == "last()":
            css += ":last-of-type"
            continue

        # Unrecognized predicate
        return None

    return css or "*"


def _build_css(xpath: str, css_parts: list[str]) -> str:
    """Build CSS selector from parts, inferring combinators from the XPath.

    ``//`` = descendant combinator (space), ``/`` = child combinator (`` > ``).
    The leading ``//`` or ``/`` is skipped (first part has no combinator).
    """
    if not css_parts:
        return xpath

    # Split XPath into (combinator, step) pairs
    # e.g. "//*[@id='x']/div//span" → [(None, '*[@id="x"]'), ('/', 'div'), ('//', 'span')]
    segments = []
    pos = 0
    while pos < len(xpath):
        if xpath[pos : pos + 2] == "//":
            end = pos + 2
            combinator = "//"
        elif xpath[pos] == "/":
            end = pos + 1
            combinator = "/"
        else:
            pos += 1
            continue

        # Find the end of the step (next / or //, respecting brackets)
        step_start = end
        depth = 0
        while end < len(xpath):
            ch = xpath[end]
            if ch == "[":
                depth += 1
            elif ch == "]":
                depth -= 1
            elif ch == "/" and depth == 0:
                break
            end += 1

        step = xpath[step_start:end].strip()
        if step:
            segments.append((combinator, step))
        pos = end

    if not segments:
        return css_parts[0] if css_parts else xpath

    # Build result: first part has no combinator
    result = ""
    for idx, (comb, step) in enumerate(segments):
        css = _step_to_css(step)
        if css is None:
            return xpath
        if idx == 0:
            result = css
        elif comb == "//":
            result += " " + css
        else:  # "/"
            result += " > " + css

    return result


class Selector:
    """Represents a CSS or XPath selector with optional variables.

    Variables are denoted as {name} in the selector string.
    Use bind() to fill them in, producing a new Selector.
    """

    def __init__(
        self,
        selector_type: str,
        value: str,
        variables: Optional[dict] = None,
        modifier: Optional[str] = None,
    ):
        self._type = selector_type
        self._value = value
        self._variables = dict(variables) if variables else {}
        self._modifier = modifier

    @classmethod
    def css(cls, value: str) -> Selector:
        return cls("css", value)

    @classmethod
    def xpath(cls, value: str) -> Selector:
        return cls("xpath", value)

    def bind(self, **kwargs) -> Selector:
        merged = {**self._variables, **kwargs}
        return Selector(self._type, self._value, merged, self._modifier)

    def find(self, sub_selector: str) -> Selector:
        new_value = f"{self._value} {sub_selector}"
        return Selector(self._type, new_value, dict(self._variables))

    def sibling(self, combinator: str) -> Selector:
        new_value = f"{self._value} {combinator}"
        return Selector(self._type, new_value, dict(self._variables))

    def parent(self) -> Selector:
        return Selector(self._type, self._value, dict(self._variables), modifier="parent")

    def closest(self, ancestor_selector: str) -> Selector:
        return Selector(self._type, self._value, dict(self._variables), modifier=f"closest:{ancestor_selector}")

    def where(self, condition: str) -> Selector:
        new_value = f"{self._value}{condition}"
        return Selector(self._type, new_value, dict(self._variables))

    def to_dict(self) -> dict:
        d: dict = {"type": self._type, "value": self._value}
        if self._variables:
            d["variables"] = self._variables
        if self._modifier:
            d["modifier"] = self._modifier
        return d

    def __repr__(self) -> str:
        return f"Selector({self._type}={self._value!r})"
