class ZSChromeError(Exception):
    """Base exception for all ZSChrome errors."""

    def __init__(self, *args, **kwargs):
        super().__init__(*args)
        self.details = kwargs


class ConnectionLost(ZSChromeError):
    """WebSocket connection to the extension was lost."""
    pass


class TimeoutError(ZSChromeError):
    """A wait operation timed out."""
    pass


class SelectorNotFound(ZSChromeError):
    """The selector did not match any element."""
    pass


class SelectorAmbiguous(ZSChromeError):
    """The selector matched multiple elements when exactly one was required."""
    pass


class ActionError(ZSChromeError):
    """An action could not be performed (element not interactable, disabled, etc.)."""
    pass


class PageClosedError(ZSChromeError):
    """The target tab was closed."""
    pass


class ProtocolError(ZSChromeError):
    """The extension returned a malformed or unexpected response."""
    pass
