import asyncio
import json
import logging
from typing import Optional, Any

import websockets
from websockets.exceptions import ConnectionClosed

logger = logging.getLogger(__name__)


class Transport:
    """Runs a WebSocket server that the Chrome Extension connects to.

    The Extension is the WebSocket client; Python is the server.
    This avoids needing a separate relay process.
    """

    def __init__(self, host: str = "127.0.0.1", port: int = 9527):
        self._host = host
        self._port = port
        self._ws: Optional[Any] = None
        self._connected = False
        self._receive_queue: asyncio.Queue = asyncio.Queue()
        self._server: Optional[Any] = None
        self._listen_task: Optional[asyncio.Task] = None
        self._connection_event: asyncio.Event = asyncio.Event()

    async def connect(self, timeout: float = 30.0) -> None:
        """Start WebSocket server and wait for the Extension to connect.

        Args:
            timeout: Max seconds to wait for the extension to connect.
        """
        self._connection_event.clear()

        async def handle(websocket):
            if self._ws is not None:
                logger.warning("Already connected, rejecting new connection")
                await websocket.close()
                return

            self._ws = websocket
            self._connected = True
            self._connection_event.set()
            logger.info(f"Extension connected from {websocket.remote_address}")

            try:
                async for message in websocket:
                    try:
                        data = json.loads(message)
                        await self._receive_queue.put(data)
                    except json.JSONDecodeError:
                        logger.warning(f"Invalid JSON received: {message[:200]}")
            except ConnectionClosed:
                logger.warning("Extension disconnected")
                self._connected = False
                self._ws = None
                self._connection_event.clear()
            except Exception as e:
                logger.error(f"WebSocket error: {e}")
                self._connected = False
                self._ws = None
                self._connection_event.clear()

        self._server = await websockets.serve(handle, self._host, self._port)
        logger.info(f"Server listening on ws://{self._host}:{self._port}, waiting for Extension...")

        # Wait for extension to connect (with timeout)
        try:
            await asyncio.wait_for(self._connection_event.wait(), timeout=timeout)
        except asyncio.TimeoutError:
            self._server.close()
            await self._server.wait_closed()
            raise ConnectionError(
                f"No Extension connected within {timeout}s. "
                f"Make sure the Chrome Extension is loaded and connected."
            )

    async def send(self, message: dict) -> None:
        if not self._connected or not self._ws:
            raise ConnectionError("Not connected")
        text = json.dumps(message, ensure_ascii=False)
        await self._ws.send(text)

    async def receive(self, timeout: Optional[float] = None) -> dict:
        if timeout is not None:
            return await asyncio.wait_for(self._receive_queue.get(), timeout=timeout)
        return await self._receive_queue.get()

    async def request(self, message: dict, timeout: float = 30.0) -> dict:
        await self.send(message)
        msg_id = message.get("id")

        deadline = asyncio.get_running_loop().time() + timeout
        while True:
            remaining = deadline - asyncio.get_running_loop().time()
            if remaining <= 0:
                from zschrome.errors import TimeoutError
                raise TimeoutError(f"Request {msg_id} timed out after {timeout}s")

            response = await self.receive(timeout=remaining)

            if "id" in response and response["id"] == msg_id:
                return response

    async def close(self) -> None:
        self._connected = False
        self._connection_event.clear()
        if self._ws:
            await self._ws.close()
            self._ws = None
        if self._server:
            self._server.close()
            await self._server.wait_closed()
            self._server = None

    @property
    def connected(self) -> bool:
        return self._connected
