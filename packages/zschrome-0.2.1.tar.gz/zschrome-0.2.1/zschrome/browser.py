from __future__ import annotations

import asyncio
import os
import shutil
import subprocess
import sys
from typing import Optional

from zschrome.transport import Transport
from zschrome.page import Page


def _find_chrome() -> str:
    """Locate the Chrome/Chromium executable on this system."""
    if sys.platform == "win32":
        candidates = [
            os.path.expandvars(r"%ProgramFiles%\Google\Chrome\Application\chrome.exe"),
            os.path.expandvars(r"%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe"),
            os.path.expandvars(r"%LocalAppData%\Google\Chrome\Application\chrome.exe"),
        ]
    elif sys.platform == "darwin":
        candidates = ["/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"]
    else:
        candidates = [
            "google-chrome", "google-chrome-stable",
            "chromium-browser", "chromium",
        ]

    for p in candidates:
        if os.path.exists(p) or (not p.startswith("/") and shutil.which(p)):
            return p

    raise FileNotFoundError(
        "Cannot find Chrome. Set CHROME_PATH env var or install Chrome."
    )


def launch_chrome(url: Optional[str] = None, headless: bool = False) -> subprocess.Popen:
    """Launch Chrome browser (reuses existing profile if already running).

    Args:
        url: Optional URL to open on launch.
        headless: If True, run headless (requires Chrome 112+ new headless).

    Returns:
        The Popen process handle.
    """
    chrome = os.environ.get("CHROME_PATH", _find_chrome())
    args = [chrome]

    if headless:
        args.append("--headless=new")

    if url:
        args.append(url)

    # On Windows, CREATE_NEW_PROCESS_GROUP avoids attaching to the terminal
    kwargs = {"stdout": subprocess.DEVNULL, "stderr": subprocess.DEVNULL}
    if sys.platform == "win32":
        kwargs["creationflags"] = subprocess.CREATE_NEW_PROCESS_GROUP

    proc = subprocess.Popen(args, **kwargs)
    return proc


class Browser:
    """Manages the WebSocket connection to the Chrome Extension.

    Usage:
        browser = await Browser.connect_or_launch("https://www.taobao.com")
        page = browser.current_page
    """

    def __init__(self):
        self._transport: Optional[Transport] = None
        self._current_page: Optional[Page] = None
        self._chrome_process: Optional[subprocess.Popen] = None

    # ── Connection ──

    @classmethod
    async def connect(cls, host: str = "127.0.0.1", port: int = 9527,
                      timeout: float = 30.0) -> Browser:
        """Start the WebSocket server and wait for the Extension to connect.

        Args:
            timeout: Max seconds to wait for the extension.
        """
        print(f"ZSChrome: Waiting for Extension on ws://{host}:{port} ...")
        browser = cls()
        browser._transport = Transport(host, port)
        await browser._transport.connect(timeout=timeout)
        browser._current_page = Page(browser._transport, tab_id=0)
        print("ZSChrome: Connected.")
        return browser

    @classmethod
    async def connect_or_launch(
        cls,
        url: Optional[str] = None,
        host: str = "127.0.0.1",
        port: int = 9527,
    ) -> Browser:
        """Launch Chrome (if needed), then connect to the Extension.

        Opens Chrome with the given URL, then retries connection for up to
        ~60 seconds so the extension has time to load and reconnect.
        """
        proc = launch_chrome(url)

        # Give Chrome a moment to start before the first attempt
        await asyncio.sleep(1.5)

        attempts = 4
        for i in range(attempts):
            try:
                browser = await cls.connect(host=host, port=port, timeout=15.0)
                browser._chrome_process = proc
                return browser
            except ConnectionError:
                if i < attempts - 1:
                    print(f"ZSChrome: Extension not ready, retrying ({i + 2}/{attempts})...")
                    await asyncio.sleep(2.0)
                else:
                    raise ConnectionError(
                        "Cannot connect to ZSChrome Extension after launching Chrome. "
                        "Make sure the extension is loaded in chrome://extensions and "
                        "Developer Mode is enabled."
                    )

    # ── Page access ──

    @property
    def current_page(self) -> Page:
        if self._current_page is None:
            raise RuntimeError("Not connected. Call Browser.connect() first.")
        return self._current_page

    async def pages(self) -> list[Page]:
        return [self.current_page]

    async def new_page(self, url: Optional[str] = None) -> Page:
        await self.current_page.eval("window.open('about:blank')")
        if url:
            await self.current_page.navigate(url)
        return self.current_page

    # ── Teardown ──

    async def close(self) -> None:
        if self._transport:
            try:
                await self.current_page._call("close_browser")
            except Exception:
                pass
            await self._transport.close()
            self._transport = None
            self._current_page = None

        if self._chrome_process:
            try:
                self._chrome_process.terminate()
                self._chrome_process.wait(timeout=3)
            except Exception:
                try:
                    self._chrome_process.kill()
                except Exception:
                    pass
            self._chrome_process = None
