"""Regression tests for the shell exec tool's interactive-command guard.

The guard used to substring-match on ``ssh``/``passwd``/etc, so innocent
commands like ``cat ~/.ssh/config`` or ``sed 's/ssh/telnet/' file`` got
rejected with "may prompt for a password" even though no interactive
binary was being invoked. The current implementation tokenizes the
command and only flags the actual executable.
"""

from __future__ import annotations

import pytest

from kyber.agent.tools.shell import ExecTool


@pytest.fixture
def tool() -> ExecTool:
    return ExecTool()


@pytest.mark.parametrize(
    "command,label",
    [
        ("cat ~/.ssh/config", "reading ssh config"),
        ("grep ssh /etc/services", "grep for ssh"),
        ("echo 'ssh is great'", "echo containing ssh in a string"),
        ('sed -i "s/ssh/telnet/g" file.txt', "sed referencing ssh"),
        ("ssh -o BatchMode=yes host date", "ssh with BatchMode=yes"),
        ("sudo -n apt install -y vim", "sudo -n + apt install -y"),
        ("gh auth status", "gh auth status (not `gh login`)"),
        ("cat passwd_file.txt", "cat of file whose name contains passwd"),
        ("echo passwd", "echo of the literal word passwd"),
        ("ls -la && cat README.md", "two allowed sub-commands"),
    ],
)
def test_allows_safe_commands(tool: ExecTool, command: str, label: str) -> None:
    assert tool._guard_interactive_command(command) is None, label


@pytest.mark.parametrize(
    "command,label",
    [
        ("ssh host date", "bare ssh invocation"),
        ("scp foo host:bar", "bare scp"),
        ("sudo ls", "sudo without -n"),
        ("apt install vim", "apt install without -y"),
        ("passwd", "passwd"),
        ("gh login", "gh login"),
        ("docker login", "docker login"),
        ("npm login", "npm login"),
        ("cat x && ssh host date", "safe sub-command followed by ssh"),
    ],
)
def test_blocks_interactive_commands(
    tool: ExecTool, command: str, label: str
) -> None:
    err = tool._guard_interactive_command(command)
    assert err is not None, label
    assert "Error:" in err


def test_heredoc_body_mentioning_ssh_is_allowed(tool: ExecTool) -> None:
    """Doc updates via ``cat > /path << EOF ... ssh ... EOF`` must go through.

    This was the concrete bug — Kyber tried to push updated docs to a VPS,
    the docs body contained the word ``ssh``, and the guard rejected the
    whole write.
    """
    cmd = (
        'cat > /var/www/docs/page.mdx << EOF\n'
        '# Kyber\n'
        'Connect via ssh, Tailscale, or Kyber Network.\n'
        'EOF'
    )
    assert tool._guard_interactive_command(cmd) is None
