"""Tests for the cross-machine dashboard proxy.

Browser hits ``/api/peer/<name>/<rest>`` on the local dashboard. The
dashboard forwards to the local gateway (``/network/peer-forward``),
which in turn calls the remote peer's gateway over the HMAC-signed
WebSocket, which dispatches to the peer's localhost dashboard and
returns the body. Here we mock the gateway hop so we can verify the
outer-most wrapping/unwrapping without needing a live network.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import httpx
from fastapi.testclient import TestClient

from kyber.config.schema import Config
from kyber.dashboard import server as dashboard_server


def _make_config(tmp_path: Path) -> Config:
    cfg = Config()
    cfg.agents.defaults.workspace = str(tmp_path / "workspace")
    cfg.dashboard.auth_token = "test-token"
    return cfg


class _FakeAsyncClient:
    """Stand-in for ``httpx.AsyncClient`` that captures gateway calls.

    The dashboard's ``_proxy_gateway`` helper instantiates
    ``httpx.AsyncClient`` directly. Swapping it out in-place lets us
    pretend the gateway answered without having to stand one up.
    """

    def __init__(self, *, expected_payload: dict[str, Any], response: dict[str, Any]) -> None:
        self._expected = expected_payload
        self._response = response
        self.calls: list[tuple[str, str, dict[str, Any] | None]] = []

    async def __aenter__(self):
        return self

    async def __aexit__(self, exc_type, exc, tb):
        return None

    async def request(self, method, url, *, headers=None, json=None):  # noqa: A002
        self.calls.append((method, url, json))
        # Emulate the gateway's response: ``{status, body}`` envelope.
        return httpx.Response(200, json=self._response, request=httpx.Request(method, url))


def test_peer_proxy_forwards_and_unwraps_body(monkeypatch, tmp_path: Path) -> None:
    cfg = _make_config(tmp_path)

    def fake_load_config() -> Config:
        return cfg

    monkeypatch.setattr(dashboard_server, "load_config", fake_load_config)

    captured: list[tuple[str, str, dict[str, Any] | None]] = []

    def fake_async_client_cls(*args, **kwargs):
        # Called once per proxied request. Return a fresh client each time
        # so we can verify per-call assertions below.
        client = _FakeAsyncClient(
            expected_payload={},
            response={
                "status": 200,
                "body": {"config": {"foo": "bar"}, "viaPeer": True},
            },
        )
        captured.append(("client", "created", None))
        # Share calls list for the outer assertions.
        fake_async_client_cls.last = client
        return client

    monkeypatch.setattr(dashboard_server.httpx, "AsyncClient", fake_async_client_cls)

    app = dashboard_server.create_dashboard_app(cfg)
    client = TestClient(app, base_url="http://localhost")

    resp = client.get(
        "/api/peer/Matts-VPS/config",
        headers={"Authorization": "Bearer test-token"},
    )

    assert resp.status_code == 200
    # The inner body from the peer should surface directly, NOT the outer
    # envelope — the browser sees the peer's dashboard response as if it
    # came straight from its own.
    body = resp.json()
    assert body == {"config": {"foo": "bar"}, "viaPeer": True}

    # And the gateway was called with the right forward envelope.
    last_client = fake_async_client_cls.last
    assert last_client.calls, "dashboard never hit the gateway"
    method, url, payload = last_client.calls[0]
    assert method == "POST"
    assert url.endswith("/network/peer-forward")
    assert payload is not None
    assert payload["peer_name"] == "Matts-VPS"
    assert payload["method"] == "GET"
    assert payload["path"] == "/api/config"


def test_peer_proxy_forwards_post_body(monkeypatch, tmp_path: Path) -> None:
    """Non-GET methods serialize their JSON body into the forward envelope."""
    cfg = _make_config(tmp_path)
    monkeypatch.setattr(dashboard_server, "load_config", lambda: cfg)

    def fake_async_client_cls(*args, **kwargs):
        client = _FakeAsyncClient(
            expected_payload={},
            response={"status": 201, "body": {"ok": True}},
        )
        fake_async_client_cls.last = client
        return client

    monkeypatch.setattr(dashboard_server.httpx, "AsyncClient", fake_async_client_cls)

    app = dashboard_server.create_dashboard_app(cfg)
    client = TestClient(app, base_url="http://localhost")

    resp = client.post(
        "/api/peer/Matts-VPS/tasks/%E2%9A%A1abc/cancel",
        headers={"Authorization": "Bearer test-token"},
        json={"reason": "user-cancelled"},
    )

    assert resp.status_code == 201
    assert resp.json() == {"ok": True}

    last_client = fake_async_client_cls.last
    _, url, payload = last_client.calls[0]
    assert url.endswith("/network/peer-forward")
    assert payload["method"] == "POST"
    # URL-encoded path segment round-trips intact so the peer sees the
    # same thing it would on its own dashboard.
    assert payload["path"].startswith("/api/tasks/")
    assert payload["body"] == {"reason": "user-cancelled"}


def test_peer_proxy_requires_auth(monkeypatch, tmp_path: Path) -> None:
    cfg = _make_config(tmp_path)
    monkeypatch.setattr(dashboard_server, "load_config", lambda: cfg)
    app = dashboard_server.create_dashboard_app(cfg)
    client = TestClient(app, base_url="http://localhost")

    resp = client.get("/api/peer/Matts-VPS/config")
    assert resp.status_code == 401


def test_peer_proxy_surfaces_peer_error_status(monkeypatch, tmp_path: Path) -> None:
    """If the peer's dashboard returned a 404, the browser sees 404."""
    cfg = _make_config(tmp_path)
    monkeypatch.setattr(dashboard_server, "load_config", lambda: cfg)

    def fake_async_client_cls(*args, **kwargs):
        client = _FakeAsyncClient(
            expected_payload={},
            response={"status": 404, "body": {"error": "not found on peer"}},
        )
        fake_async_client_cls.last = client
        return client

    monkeypatch.setattr(dashboard_server.httpx, "AsyncClient", fake_async_client_cls)

    app = dashboard_server.create_dashboard_app(cfg)
    client = TestClient(app, base_url="http://localhost")

    resp = client.get(
        "/api/peer/Matts-VPS/something-not-there",
        headers={"Authorization": "Bearer test-token"},
    )
    assert resp.status_code == 404
    assert resp.json() == {"error": "not found on peer"}
