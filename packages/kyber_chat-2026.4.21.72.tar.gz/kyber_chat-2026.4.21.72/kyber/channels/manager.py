"""Channel manager for coordinating chat channels."""

import asyncio
import contextlib
import random
from datetime import datetime, timedelta
from typing import Any

from loguru import logger

from kyber.bus.events import OutboundMessage
from kyber.bus.queue import MessageBus
from kyber.channels.base import BaseChannel
from kyber.channels.errors import PermanentDeliveryError, TemporaryDeliveryError
from kyber.config.schema import Config


class ChannelManager:
    """
    Manages chat channels and coordinates message routing.
    
    Responsibilities:
    - Initialize enabled channels (Telegram, WhatsApp, etc.)
    - Start/stop channels
    - Route outbound messages
    """
    
    def __init__(self, config: Config, bus: MessageBus):
        self.config = config
        self.bus = bus
        self.channels: dict[str, BaseChannel] = {}
        self._dispatch_task: asyncio.Task | None = None
        
        self._init_channels()
    
    def _init_channels(self) -> None:
        """Initialize channels based on config."""
        
        # Telegram channel
        if self.config.channels.telegram.enabled:
            try:
                from kyber.channels.telegram import TelegramChannel
                self.channels["telegram"] = TelegramChannel(
                    self.config.channels.telegram,
                    self.bus,
                    groq_api_key=self.config.providers.groq.api_key,
                )
                logger.info("Telegram channel enabled")
            except ImportError as e:
                logger.warning(f"Telegram channel not available: {e}")
        
        # WhatsApp channel
        if self.config.channels.whatsapp.enabled:
            try:
                from kyber.channels.whatsapp import WhatsAppChannel
                self.channels["whatsapp"] = WhatsAppChannel(
                    self.config.channels.whatsapp, self.bus
                )
                logger.info("WhatsApp channel enabled")
            except ImportError as e:
                logger.warning(f"WhatsApp channel not available: {e}")

        # Discord channel
        if self.config.channels.discord.enabled:
            try:
                from kyber.channels.discord import DiscordChannel
                self.channels["discord"] = DiscordChannel(
                    self.config.channels.discord, self.bus
                )
                logger.info("Discord channel enabled")
            except ImportError as e:
                logger.warning(f"Discord channel not available: {e}")
    
    def attach_agent(self, agent: Any) -> None:
        """Hand every channel a reference to the running AgentCore.

        Used by slash commands (``/cancel``, ``/usage``) that need live
        agent state. Safe to call multiple times; only the most recent
        agent is retained per channel.
        """
        for ch in self.channels.values():
            try:
                ch.agent = agent
            except Exception:
                # Defensive — channels can override ``agent`` however they
                # like. Never let a quirky override break startup.
                pass

    async def start_all(self) -> None:
        """Start every enabled channel + the outbound dispatcher.

        Each channel runs in its own supervised task. A crash in any one
        of them (e.g. Discord rejects a stale token with ``Improper token
        has been passed``) is logged loudly but **does not kill this
        coroutine** — otherwise the gateway supervisor sees the whole
        ``channels`` task as done and tears the gateway down, leaving
        nothing on the port for the network/dashboard to talk to.

        The broken channel backs off exponentially and retries so that
        transient issues (network blips, rate limits, Discord's API
        hiccups) self-heal without needing human intervention. Truly
        fatal errors (bad token) keep getting retried with the max
        backoff — the user fixes config, service stays up.
        """
        if not self.channels:
            # No channels is a valid configuration (headless box with only
            # the dashboard + network roles). Keep this task alive by
            # waiting forever — the gateway supervisor treats a completed
            # channels task as "channels died, shut down."
            logger.warning("No channels enabled — channel supervisor idling")
            self._dispatch_task = asyncio.create_task(self._dispatch_outbound())
            try:
                await asyncio.Event().wait()
            except asyncio.CancelledError:
                return
            return

        self._dispatch_task = asyncio.create_task(self._dispatch_outbound())

        async def _supervise(name: str, channel) -> None:
            """Run ``channel.start()`` forever, restarting on failure."""
            backoff_s = 2.0
            max_backoff_s = 120.0
            while True:
                logger.info(f"Starting {name} channel…")
                try:
                    await channel.start()
                    # ``start()`` returned normally — either graceful stop
                    # from ``stop_all`` or a silent early-return from a
                    # misconfigured channel. If we're being shut down, the
                    # CancelledError path below handles it; otherwise,
                    # treat this as a soft failure and retry with backoff.
                    logger.warning(
                        f"{name} channel exited normally; restarting after {backoff_s:.0f}s"
                    )
                except asyncio.CancelledError:
                    logger.info(f"{name} channel supervisor cancelled")
                    raise
                except Exception as e:
                    logger.error(
                        f"{name} channel crashed: {type(e).__name__}: {e}. "
                        f"Retrying in {backoff_s:.0f}s"
                    )
                try:
                    await asyncio.sleep(backoff_s)
                except asyncio.CancelledError:
                    raise
                backoff_s = min(max_backoff_s, backoff_s * 2.0)

        tasks = [
            asyncio.create_task(_supervise(name, channel), name=f"channel-{name}")
            for name, channel in self.channels.items()
        ]

        # Run forever — each supervisor handles its own retries. If the
        # whole supervisor is cancelled (process shutdown), we cancel
        # the children too.
        try:
            await asyncio.gather(*tasks)
        except asyncio.CancelledError:
            for t in tasks:
                t.cancel()
            for t in tasks:
                with contextlib.suppress(asyncio.CancelledError, Exception):
                    await t
            raise
    
    async def stop_all(self) -> None:
        """Stop all channels and the dispatcher."""
        logger.info("Stopping all channels...")
        
        # Stop dispatcher
        if self._dispatch_task:
            self._dispatch_task.cancel()
            try:
                await self._dispatch_task
            except asyncio.CancelledError:
                pass
        
        # Stop all channels
        for name, channel in self.channels.items():
            try:
                await channel.stop()
                logger.info(f"Stopped {name} channel")
            except Exception as e:
                logger.error(f"Error stopping {name}: {e}")
    
    async def _dispatch_outbound(self) -> None:
        """Dispatch outbound messages to the appropriate channel."""
        logger.info("Outbound dispatcher started")

        # Pending retries: (retry_at, attempts, message, last_error)
        pending: list[tuple[datetime, int, OutboundMessage, str]] = []

        def _schedule_retry(msg: OutboundMessage, attempts: int, err: Exception) -> None:
            # Exponential backoff with jitter; cap at 5 minutes.
            delay_s = min(300.0, float(2 ** min(8, max(0, attempts - 1))))
            delay_s = delay_s * (0.8 + random.random() * 0.4)  # +/-20%
            retry_at = datetime.now() + timedelta(seconds=delay_s)
            pending.append((retry_at, attempts, msg, str(err)))

        # Internal-only channels that don't need outbound delivery.
        # Messages originating from these sources (e.g. dashboard, cron) are
        # fire-and-forget; the caller doesn't expect a chat response.
        _SILENT_CHANNELS = frozenset({"dashboard", "cron", "internal", "system"})

        async def _try_send(msg: OutboundMessage, attempts: int = 1) -> None:
            if msg.channel in _SILENT_CHANNELS:
                return  # silently drop — no chat channel to deliver to
            if not (msg.content or "").strip():
                logger.warning(
                    f"Dropping empty outbound payload for {msg.channel}:{msg.chat_id} "
                    f"(attempt {attempts})"
                )
                return
            channel = self.channels.get(msg.channel)
            if not channel:
                raise PermanentDeliveryError(f"Unknown channel: {msg.channel}")
            try:
                await asyncio.wait_for(channel.send(msg), timeout=30.0)
            except asyncio.TimeoutError:
                raise TemporaryDeliveryError(
                    f"Send to {msg.channel}:{msg.chat_id} timed out after 30s"
                )
            logger.info(f"Delivered to {msg.channel}:{msg.chat_id} (attempt {attempts})")

        while True:
            try:
                now = datetime.now()
                # Prefer due retries first so completions aren't lost.
                msg: OutboundMessage | None = None
                attempts = 1
                last_err = ""

                if pending:
                    pending.sort(key=lambda x: x[0])
                    retry_at, attempts, msg, last_err = pending[0]
                    if retry_at <= now:
                        pending.pop(0)
                    else:
                        msg = None

                timeout = 1.0
                if pending:
                    pending.sort(key=lambda x: x[0])
                    timeout = min(timeout, max(0.0, (pending[0][0] - now).total_seconds()))

                if msg is None:
                    msg = await asyncio.wait_for(self.bus.consume_outbound(), timeout=timeout)
                    attempts = 1
                    last_err = ""

                try:
                    await _try_send(msg, attempts=attempts)
                except PermanentDeliveryError as e:
                    logger.error(f"Permanent outbound delivery failure to {msg.channel}:{msg.chat_id}: {e}")
                except TemporaryDeliveryError as e:
                    logger.error(
                        f"Temporary outbound delivery failure to {msg.channel}:{msg.chat_id} "
                        f"(attempt {attempts}): {e}"
                    )
                    _schedule_retry(msg, attempts + 1, e)
                except Exception as e:
                    # Treat unknown exceptions as transient by default; channels can
                    # raise PermanentDeliveryError to prevent pointless retries.
                    logger.error(
                        f"Error sending to {msg.channel}:{msg.chat_id} "
                        f"(attempt {attempts}): {e}"
                    )
                    _schedule_retry(msg, attempts + 1, e)

            except asyncio.TimeoutError:
                continue
            except asyncio.CancelledError:
                break
            except Exception as e:
                # CRITICAL: Never let the dispatch loop die. If it crashes,
                # ALL subsequent outbound messages are lost forever.
                logger.error(f"Unexpected error in outbound dispatcher (recovering): {e}")
                await asyncio.sleep(0.5)
    
    def get_channel(self, name: str) -> BaseChannel | None:
        """Get a channel by name."""
        return self.channels.get(name)
    
    def get_status(self) -> dict[str, Any]:
        """Get status of all channels."""
        return {
            name: {
                "enabled": True,
                "running": channel.is_running
            }
            for name, channel in self.channels.items()
        }
    
    @property
    def enabled_channels(self) -> list[str]:
        """Get list of enabled channel names."""
        return list(self.channels.keys())
