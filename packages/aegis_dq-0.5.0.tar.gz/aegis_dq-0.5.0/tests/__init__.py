"""Aegis test suite."""
