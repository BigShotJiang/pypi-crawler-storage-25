"""Aegis agent nodes."""
