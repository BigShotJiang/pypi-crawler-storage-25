# 微博公开内容 MCP Server

## 概述

`Astron-weibo-mcp` 是一个基于 MCP 协议的微博工具服务，直接调用微博游客态公开接口获取公开内容，无需额外部署后端服务。

当前工程形态：
- 使用 `MCP Python SDK`
- 使用单文件 `server.py` 承载工具定义和 HTTP 调用
- 通过独立 `pyproject` 打包
- 支持 `uvx` 一键启动
- 通过环境变量配置超时和 User-Agent
- 首版不依赖 Playwright 或浏览器运行时
- 采用多入口游客态策略：`m.weibo.cn`、`weibo.cn/pub`、`api.weibo.cn`

当前提供 6 个原子工具：
- `get_hot_list`
- `get_feed_list`
- `search_content`
- `get_content_detail`
- `get_author_profile`
- `get_author_content_list`

## 工具列表

### 1. 获取热榜 `get_hot_list`
- 描述：读取微博热搜榜。
- 参数：
  - `limit`：返回条数，默认 `20`
  - `refresh`：是否刷新，默认 `False`

### 2. 获取信息流 `get_feed_list`
- 描述：读取微博游客态公开信息流。
- 参数：
  - `channel`：频道参数，默认 `hot`
  - `cursor`：分页游标，默认空
  - `limit`：返回条数，默认 `20`
  - `refresh`：是否刷新，默认 `False`

### 3. 搜索内容 `search_content`
- 描述：搜索微博公开内容。
- 参数：
  - `query`：搜索词，必填
  - `cursor`：分页游标，默认空
  - `limit`：返回条数，默认 `20`

### 4. 获取内容详情 `get_content_detail`
- 描述：读取微博内容详情。
- 参数：
  - `content_id`：内容 ID
  - `url`：内容完整 URL

### 5. 获取作者主页 `get_author_profile`
- 描述：读取微博作者公开主页。
- 参数：
  - `author_id`：作者 ID
  - `url`：作者主页 URL

### 6. 获取作者作品列表 `get_author_content_list`
- 描述：读取微博作者公开作品列表。
- 参数：
  - `author_id`：作者 ID
  - `url`：作者主页 URL
  - `cursor`：分页游标，默认空
  - `limit`：返回条数，默认 `20`

## 环境变量

可选环境变量：

```bash
export WEIBO_MCP_TIMEOUT_SECONDS="20"
export WEIBO_MCP_USER_AGENT="Mozilla/5.0 ..."
export WEIBO_MCP_ENABLE_VISITOR_ACTIVATION="1"
```

说明：
- `WEIBO_MCP_TIMEOUT_SECONDS` 控制公开接口请求超时。
- `WEIBO_MCP_USER_AGENT` 用于覆盖默认请求头。
- `WEIBO_MCP_ENABLE_VISITOR_ACTIVATION` 控制是否启用游客访问激活流程（默认开启）。

## 安装与启动

### 推荐方式：使用 uvx 一键启动

```bash
uvx --from astron-weibo-mcp astron-weibo-mcp
```

如果你还没有安装 `uv` / `uvx`，可先执行：

```bash
curl -fsSL https://install.astral.sh/uv | bash
```

### 使用 pip 安装

```bash
pip install astron-weibo-mcp
weibo-mcp
```

### 本地源码运行

```bash
cd MCP/weibo-mcp
PYTHONPATH=src python3 -m weibo_mcp.server
```

## 客户端配置

### 使用 uvx

```json
{
  "mcpServers": {
    "weibo-mcp": {
      "command": "uvx",
      "args": ["--from", "astron-weibo-mcp", "astron-weibo-mcp"],
      "env": {
        "WEIBO_MCP_TIMEOUT_SECONDS": "20"
      }
    }
  }
}
```

### 使用本地源码

```json
{
  "mcpServers": {
    "weibo-mcp": {
      "command": "python3",
      "args": ["-m", "weibo_mcp.server"],
      "env": {
        "PYTHONPATH": "/path/to/MCP/weibo-mcp/src",
        "WEIBO_MCP_TIMEOUT_SECONDS": "20"
      }
    }
  }
}
```

## 平台差异说明

1. 这个 MCP 直接请求微博游客态公开接口，不依赖额外后端服务。
2. 当前仅面向公开内容能力，不包含登录态、私有内容或用户专属数据。
3. 返回结果保持结构化 JSON，便于 Cursor、Claude Desktop 等客户端消费。
4. 微博游客态接口可能受网络、地区或平台风控影响，偶发失败时建议稍后重试。
5. 在当前实现中，`get_hot_list` 可回退到 `weibo.cn/pub` 话题列表，`get_author_profile` 可回退到 `api.weibo.cn/2/profile`。
6. `get_content_detail` 增加了 `weibo.cn/comment/{bid}` 的游客态回退（自动支持数字 `mid` 转 `bid`）。
7. 启用游客访问激活流程后，`get_feed_list`、`search_content`、`get_author_content_list` 在多数环境可恢复真实数据；若平台风控升级，仍可能返回结构化空结果（`raw.source=unavailable`）。

## 发布说明

```bash
cd MCP/weibo-mcp
rm -rf build dist src/*.egg-info
python3 -m build --no-isolation
python3 -m twine check dist/*
python3 -m twine upload dist/*
```

## License

Apache License 2.0. See `LICENSE`.
