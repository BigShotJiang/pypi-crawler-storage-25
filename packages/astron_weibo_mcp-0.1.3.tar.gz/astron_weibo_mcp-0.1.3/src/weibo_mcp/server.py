"""Astron Weibo MCP server."""

from __future__ import annotations

import html as html_lib
import json
import os
import random
import re
from datetime import datetime, timezone
from typing import Any
from urllib.parse import parse_qs, quote, unquote, urlparse

import requests
from mcp.server.fastmcp import Context, FastMCP

from weibo_mcp import __version__


HOME_URL = "https://m.weibo.cn/"
HOT_LIST_URL = "https://s.weibo.com/top/summary"
WEIBO_CN_PUB_URL = "https://weibo.cn/pub/"
CONTAINER_API_URL = "https://m.weibo.cn/api/container/getIndex"
STATUS_SHOW_API_URL = "https://m.weibo.cn/api/statuses/show"
STATUS_EXTEND_API_URL = "https://m.weibo.cn/statuses/extend"
API_WEIBO_PROFILE_URL = "https://api.weibo.cn/2/profile"
WEIBO_CN_COMMENT_URL_TEMPLATE = "https://weibo.cn/comment/{content_id}"
STATUS_URL_TEMPLATE = "https://m.weibo.cn/status/{content_id}"
AUTHOR_URL_TEMPLATE = "https://m.weibo.cn/u/{author_id}"

DEFAULT_LIMIT = 20
MAX_LIMIT = 50
TAG_RE = re.compile(r"<[^>]+>")
STATUS_ID_RE = re.compile(r"/status/(\d+)")
STATUS_BID_RE = re.compile(r"/status/([0-9A-Za-z]+)")
AUTHOR_ID_RE = re.compile(r"/(?:u|profile)/(\d+)")
DIGIT_RE = re.compile(r"\d+")
B62_ALPHABET = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"
VISITOR_GEN_URL = "https://visitor.passport.weibo.cn/visitor/genvisitor"
VISITOR_ACTIVATE_URL = "https://visitor.passport.weibo.cn/visitor/visitor"


def _current_iso() -> str:
    return datetime.now(tz=timezone.utc).astimezone().isoformat()


def get_timeout_seconds() -> float:
    raw = os.getenv("WEIBO_MCP_TIMEOUT_SECONDS", "20").strip()
    try:
        value = float(raw)
    except ValueError as exc:
        raise RuntimeError("WEIBO_MCP_TIMEOUT_SECONDS 必须是数字") from exc
    if value <= 0:
        raise RuntimeError("WEIBO_MCP_TIMEOUT_SECONDS 必须大于 0")
    return value


def get_user_agent() -> str:
    value = os.getenv("WEIBO_MCP_USER_AGENT", "").strip()
    if value:
        return value
    return (
        "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 "
        "(KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36 "
        f"Astron-Weibo-MCP/{__version__}"
    )


def get_enable_visitor_activation() -> bool:
    raw = os.getenv("WEIBO_MCP_ENABLE_VISITOR_ACTIVATION", "1").strip().lower()
    return raw not in {"0", "false", "no", "off"}


def create_session(*, prime_home: bool = True) -> requests.Session:
    session = requests.Session()
    session.headers.update(
        {
            "User-Agent": get_user_agent(),
            "Accept-Language": "zh-CN,zh;q=0.9",
        }
    )
    if prime_home:
        _prime_home(session)
    if get_enable_visitor_activation():
        _try_activate_visitor_access(session)
    return session


def _prime_home(session: requests.Session) -> None:
    for url in (HOME_URL, HOT_LIST_URL):
        try:
            session.get(url, timeout=get_timeout_seconds())
        except requests.RequestException:
            pass


def _try_activate_visitor_access(session: requests.Session) -> bool:
    if getattr(session, "_weibo_visitor_activated", False):
        return True
    if not get_enable_visitor_activation():
        return False

    callback = f"gen_cb_{random.randint(100000, 999999)}"
    try:
        response = session.get(
            VISITOR_GEN_URL,
            params={
                "cb": callback,
                "fp": "0",
                "tid": "",
                "from": "weibo",
                "_rand": str(random.random()),
            },
            timeout=get_timeout_seconds(),
        )
        if response.status_code != 200:
            return False
        match = re.search(r"\((\{.*\})\)", response.text)
        if not match:
            return False
        payload = json.loads(match.group(1))
        data = payload.get("data") if isinstance(payload, dict) else None
        tid = str((data or {}).get("tid") or "").strip()
        if not tid:
            return False
    except (requests.RequestException, ValueError):
        return False

    activated = False
    for w_value in ("2", "3", "1", "0"):
        try:
            session.get(
                VISITOR_ACTIVATE_URL,
                params={
                    "a": "incarnate",
                    "t": tid,
                    "w": w_value,
                    "c": "095",
                    "gc": "",
                    "cb": "cross_domain",
                    "from": "weibo",
                    "_rand": str(random.random()),
                },
                timeout=get_timeout_seconds(),
            )
        except requests.RequestException:
            continue

        if session.cookies.get("SUB") and session.cookies.get("SUBP"):
            activated = True
            break

    setattr(session, "_weibo_visitor_activated", activated)
    return activated


def _classify_weibo_response(response: requests.Response) -> str | None:
    url = str(response.url or "")
    text = response.text or ""
    status = response.status_code

    if "visitor.passport.weibo.cn/visitor" in url or "Sina Visitor System" in text:
        return "visitor_block"
    if "passport.weibo.com/sso/signin" in url:
        return "signin_required"
    if url.rstrip("/") == "https://weibo.cn/pub" or "https://weibo.cn/pub/" in url:
        return "pub_landing"
    if status == 403:
        return "forbidden"
    if status == 432:
        return "anti_crawler_432"
    return None


def _request_json(
    session: requests.Session,
    url: str,
    *,
    params: dict[str, Any] | None = None,
    referer: str = HOME_URL,
    require_ok: bool = True,
) -> dict[str, Any]:
    for attempt in range(2):
        try:
            response = session.get(
                url,
                params=params,
                headers={
                    "Referer": referer,
                    "Accept": "application/json, text/plain, */*",
                    "X-Requested-With": "XMLHttpRequest",
                },
                timeout=get_timeout_seconds(),
            )
        except requests.RequestException as exc:
            raise RuntimeError(f"请求失败: {url}; error={exc}") from exc

        if response.status_code in {403, 418, 429} and attempt == 0:
            _prime_home(session)
            continue

        blocked = _classify_weibo_response(response)
        if blocked and attempt == 0:
            _try_activate_visitor_access(session)
            _prime_home(session)
            continue

        if response.status_code != 200:
            raise RuntimeError(
                "调用失败: "
                f"HTTP {response.status_code}; "
                f"error_type={blocked or 'http_error'}; "
                f"url={response.url}; "
                f"body={response.text[:500]}"
            )

        try:
            payload = response.json()
        except ValueError as exc:
            if blocked:
                raise RuntimeError(
                    "调用失败: 响应为反爬/登录页面; "
                    f"error_type={blocked}; "
                    f"url={response.url}"
                ) from exc
            raise RuntimeError(f"调用失败: 响应不是合法 JSON; url={response.url}") from exc

        if not isinstance(payload, dict):
            raise RuntimeError(f"调用失败: 响应不是对象; url={response.url}")

        if require_ok:
            ok = payload.get("ok")
            if ok not in (1, True, "1"):
                if attempt == 0:
                    _try_activate_visitor_access(session)
                    _prime_home(session)
                    continue
                raise RuntimeError(
                    "调用失败: "
                    f"ok={ok}; "
                    f"error_type={blocked or 'api_not_ok'}; "
                    f"url={response.url}; "
                    f"message={payload.get('msg') or payload.get('message')}"
                )
        return payload

    raise RuntimeError(f"调用失败: 访问 {url} 时触发风控，请稍后重试")


def _request_text(
    session: requests.Session,
    url: str,
    *,
    referer: str,
    allow_block_types: set[str] | None = None,
) -> str:
    for attempt in range(2):
        try:
            response = session.get(
                url,
                headers={
                    "Referer": referer,
                    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
                },
                timeout=get_timeout_seconds(),
            )
        except requests.RequestException as exc:
            raise RuntimeError(f"请求失败: {url}; error={exc}") from exc

        if response.status_code in {403, 418, 429} and attempt == 0:
            _prime_home(session)
            continue
        blocked = _classify_weibo_response(response)
        if blocked and attempt == 0:
            _try_activate_visitor_access(session)
            _prime_home(session)
            continue
        if response.status_code != 200:
            raise RuntimeError(
                "调用失败: "
                f"HTTP {response.status_code}; "
                f"error_type={blocked or 'http_error'}; "
                f"url={response.url}; "
                f"body={response.text[:500]}"
            )
        if blocked and (allow_block_types is None or blocked not in allow_block_types):
            raise RuntimeError(
                "调用失败: 返回页面不可用; "
                f"error_type={blocked}; "
                f"url={response.url}"
            )
        return response.text

    raise RuntimeError(f"调用失败: 访问 {url} 时触发风控，请稍后重试")


def _normalize_limit(limit: int, *, maximum: int = MAX_LIMIT) -> int:
    value = _to_int(limit)
    if value is None:
        return DEFAULT_LIMIT
    return max(1, min(value, maximum))


def _parse_page_cursor(cursor: str) -> int:
    value = _to_int(cursor)
    if value is None or value <= 0:
        return 1
    return value


def _to_int(value: Any) -> int | None:
    if value in (None, ""):
        return None
    if isinstance(value, bool):
        return None
    if isinstance(value, int):
        return value
    if isinstance(value, float):
        return int(value)
    text = clean_text(str(value)).replace(",", "")
    if not text:
        return None
    try:
        return int(text)
    except ValueError:
        match = re.search(r"(\d+(?:\.\d+)?)([万亿]?)", text)
        if not match:
            return None
        number = float(match.group(1))
        unit = match.group(2)
        if unit == "万":
            number *= 10_000
        elif unit == "亿":
            number *= 100_000_000
        return int(number)


def clean_text(value: str) -> str:
    text = html_lib.unescape(value or "")
    text = TAG_RE.sub(" ", text)
    return " ".join(text.split())


def _html_to_text(value: str) -> str:
    text = html_lib.unescape(value or "")
    text = re.sub(r"(?i)<br\s*/?>", "\n", text)
    text = TAG_RE.sub(" ", text)
    text = text.replace("\xa0", " ")
    return " ".join(text.split())


def _summarize_text(value: str, limit: int) -> str:
    text = clean_text(value)
    if len(text) <= limit:
        return text
    return text[: limit - 1] + "…"


_AUTHOR_PROFILE_CACHE: dict[str, dict[str, Any]] = {}
_AUTHOR_CONTENT_CACHE: dict[str, dict[str, dict[str, Any]]] = {}


def _remember_author(author: dict[str, Any]) -> None:
    if not isinstance(author, dict):
        return
    author_id = clean_text(str(author.get("id") or ""))
    if not author_id or not author_id.isdigit():
        return
    existing = dict(_AUTHOR_PROFILE_CACHE.get(author_id, {}))
    merged = {
        "id": author_id,
        "name": clean_text(str(author.get("name") or existing.get("name") or "")),
        "url": _absolute_weibo_url(clean_text(str(author.get("url") or existing.get("url") or ""))),
        "avatar": _absolute_weibo_url(clean_text(str(author.get("avatar") or existing.get("avatar") or ""))),
        "bio": clean_text(str(author.get("bio") or existing.get("bio") or "")),
        "follower_count": author.get("follower_count")
        if author.get("follower_count") is not None
        else existing.get("follower_count"),
        "following_count": author.get("following_count")
        if author.get("following_count") is not None
        else existing.get("following_count"),
        "content_count": author.get("content_count")
        if author.get("content_count") is not None
        else existing.get("content_count"),
    }
    _AUTHOR_PROFILE_CACHE[author_id] = merged


def _remember_item(item: dict[str, Any]) -> None:
    if not isinstance(item, dict):
        return
    author_id = clean_text(str(item.get("author_id") or ""))
    if not author_id or not author_id.isdigit():
        return
    author_name = clean_text(str(item.get("author_name") or ""))
    if author_name:
        _remember_author(
            {
                "id": author_id,
                "name": author_name,
                "url": AUTHOR_URL_TEMPLATE.format(author_id=author_id),
                "avatar": "",
                "bio": "",
                "follower_count": None,
                "following_count": None,
                "content_count": None,
            }
        )
    item_id = clean_text(str(item.get("id") or item.get("url") or ""))
    if not item_id:
        return
    bucket = _AUTHOR_CONTENT_CACHE.setdefault(author_id, {})
    bucket[item_id] = dict(item)


def _remember_items(items: list[dict[str, Any]]) -> None:
    for item in items:
        _remember_item(item)


def _absolute_weibo_url(url: str) -> str:
    text = (url or "").strip()
    if not text:
        return ""
    if text.startswith("https://"):
        return text
    if text.startswith("http://"):
        return "https://" + text[len("http://") :]
    if text.startswith("//"):
        return "https:" + text
    if text.startswith("/"):
        return f"https://m.weibo.cn{text}"
    if text.startswith("sinaweibo://"):
        return ""
    return text


def _extract_author_id(author_id: str, url: str) -> str:
    if author_id.strip().isdigit():
        return author_id.strip()
    text = url.strip()
    if not text:
        return ""
    if _extract_search_keyword_from_url(text):
        return ""
    match = AUTHOR_ID_RE.search(text)
    if match:
        return match.group(1)
    lfid_match = re.search(r"lfid=100505(\d+)", text)
    if lfid_match:
        return lfid_match.group(1)
    uid_match = re.search(r"[?&]uid=(\d+)", text)
    if uid_match:
        return uid_match.group(1)
    return ""


def _extract_content_id(content_id: str, url: str) -> str:
    text = content_id.strip()
    if text:
        return text if text.isdigit() else ""
    raw_url = url.strip()
    if not raw_url:
        return ""
    match = STATUS_ID_RE.search(raw_url)
    if match:
        return match.group(1)
    bid_match = STATUS_BID_RE.search(raw_url)
    if bid_match:
        return bid_match.group(1)
    return ""


def _extract_search_keyword_from_url(url: str) -> str:
    raw_url = url.strip()
    if not raw_url:
        return ""
    parsed = urlparse(raw_url)
    values = parse_qs(parsed.query)
    for key in ("q", "keyword"):
        candidates = values.get(key, [""])
        if candidates and candidates[0].strip():
            return candidates[0].strip()
    container_ids = values.get("containerid", [""])
    if container_ids and container_ids[0].strip():
        decoded = unquote(container_ids[0].strip())
        nested_values = parse_qs(decoded)
        for key in ("q", "keyword"):
            candidates = nested_values.get(key, [""])
            if candidates and candidates[0].strip():
                return candidates[0].strip().strip("#")
    return ""


def _resolve_first_item_from_search_url(session: requests.Session, url: str) -> dict[str, Any] | None:
    keyword = _extract_search_keyword_from_url(url)
    if not keyword:
        return None
    payload = _request_json(
        session,
        CONTAINER_API_URL,
        params={"containerid": f"100103type=1&q={keyword}", "page": 1},
        referer=f"https://m.weibo.cn/search?containerid=100103type=1&q={quote(keyword)}",
    )
    items = _parse_cards_payload(payload, limit=1)
    return items[0] if items else None


def _int_to_base62(value: int) -> str:
    if value <= 0:
        return "0"
    result = ""
    current = value
    while current > 0:
        current, remainder = divmod(current, 62)
        result = B62_ALPHABET[remainder] + result
    return result


def _mid_to_bid(content_id: str) -> str:
    mid = (content_id or "").strip()
    if not mid.isdigit():
        return mid
    chunks: list[str] = []
    remain = mid
    while remain:
        chunks.append(remain[-7:])
        remain = remain[:-7]

    encoded: list[str] = []
    for index, part in enumerate(reversed(chunks)):
        unit = _int_to_base62(int(part))
        if index != 0:
            unit = unit.rjust(4, "0")
        encoded.append(unit)
    return "".join(encoded)


def _build_paging(*, has_more: bool = False, next_cursor: str = "") -> dict[str, Any]:
    return {
        "has_more": bool(has_more),
        "next_cursor": next_cursor if has_more else "",
    }


def _build_list_result(
    capability: str,
    items: list[dict[str, Any]],
    raw: dict[str, Any],
    *,
    has_more: bool = False,
    next_cursor: str = "",
) -> dict[str, Any]:
    if capability == "search":
        items = [
            item
            for item in items
            if (clean_text(str(item.get("result_type", ""))) or "real") == "real"
            and bool(clean_text(str(item.get("content", ""))))
        ]
    item_types = [clean_text(str(item.get("result_type", ""))) or "real" for item in items]
    status = "empty" if not items else ("ok" if any(item_type == "real" for item_type in item_types) else "degraded")
    result_type = ""
    if item_types:
        if any(item_type == "real" for item_type in item_types):
            result_type = "real"
        else:
            result_type = item_types[0] if len(set(item_types)) == 1 else "mixed"
    _remember_items(items)
    result = {
        "platform": "weibo",
        "capability": capability,
        "status": status,
        "update_time": _current_iso(),
        "items": items,
        "paging": _build_paging(has_more=has_more, next_cursor=next_cursor),
    }
    if result_type:
        result["result_type"] = result_type
    return result


def _build_author_result(author: dict[str, Any], raw: dict[str, Any]) -> dict[str, Any]:
    result_type = clean_text(str(author.get("result_type", ""))) or "real" if author else ""
    if author:
        _remember_author(author)
    result = {
        "platform": "weibo",
        "status": "empty" if not author else ("degraded" if result_type != "real" else "ok"),
        "author": author,
    }
    if result_type:
        result["result_type"] = result_type
    return result


def _build_detail_result(item: dict[str, Any], raw: dict[str, Any]) -> dict[str, Any]:
    result_type = clean_text(str(item.get("result_type", ""))) or "real" if item else ""
    if item:
        _remember_item(item)
    result = {
        "platform": "weibo",
        "status": "empty" if not item else ("degraded" if result_type != "real" else "ok"),
        "item": item,
    }
    if result_type:
        result["result_type"] = result_type
    return result


def _build_topic_detail_item(keyword: str, page_url: str) -> dict[str, Any]:
    title = clean_text(keyword).strip("#")
    if not title:
        return {}
    return {
        "id": re.sub(r"[^0-9a-zA-Z_]+", "_", page_url or title)[:120],
        "title": title,
        "summary": title,
        "content": title,
        "url": _absolute_weibo_url(page_url),
        "cover": "",
        "author_name": "",
        "author_id": "",
        "publish_time": "",
        "rank": 1,
        "comment_count": None,
        "like_count": None,
        "share_count": None,
        "view_count": None,
        "source_type": "hot_topic",
        "result_type": "topic",
        "tags": [title],
    }


def _extract_hashtags(text: str) -> list[str]:
    return [tag.strip("#") for tag in re.findall(r"#([^#\n]{1,80})#", text)]


def _parse_card_item(card: dict[str, Any], rank: int) -> dict[str, Any] | None:
    mblog = card.get("mblog")
    if not isinstance(mblog, dict):
        return None

    text = _html_to_text(str(mblog.get("text", "")))
    user_node = mblog.get("user")
    user: dict[str, Any] = user_node if isinstance(user_node, dict) else {}
    author_id = str(user.get("idstr") or user.get("id") or "").strip()
    author_name = clean_text(str(user.get("screen_name") or ""))

    content_id = clean_text(str(mblog.get("id") or mblog.get("mid") or card.get("itemid") or ""))
    url = _absolute_weibo_url(
        str(card.get("scheme") or mblog.get("scheme") or STATUS_URL_TEMPLATE.format(content_id=content_id))
    )

    cover = ""
    for key in ("thumbnail_pic", "bmiddle_pic", "original_pic"):
        value = mblog.get(key)
        if isinstance(value, str) and value.strip():
            cover = _absolute_weibo_url(value.strip())
            break

    if not content_id and not url and not text:
        return None

    return {
        "id": content_id or url,
        "title": _summarize_text(text or author_name or content_id, 60),
        "summary": _summarize_text(text, 120),
        "content": text,
        "url": url,
        "cover": cover,
        "author_name": author_name,
        "author_id": author_id,
        "publish_time": clean_text(str(mblog.get("created_at") or "")),
        "rank": rank,
        "comment_count": _to_int(mblog.get("comments_count")),
        "like_count": _to_int(mblog.get("attitudes_count")),
        "share_count": _to_int(mblog.get("reposts_count")),
        "view_count": _to_int(mblog.get("reads_count")),
        "source_type": "weibo_post",
        "result_type": "real",
        "tags": _extract_hashtags(text),
    }


def _flatten_cards(cards: list[Any]) -> list[dict[str, Any]]:
    flattened: list[dict[str, Any]] = []
    for node in cards:
        if not isinstance(node, dict):
            continue
        flattened.append(node)
        group = node.get("card_group")
        if isinstance(group, list):
            flattened.extend(_flatten_cards(group))
    return flattened


def _parse_cards_payload(payload: dict[str, Any], *, limit: int) -> list[dict[str, Any]]:
    data = payload.get("data")
    if not isinstance(data, dict):
        return []

    cards = data.get("cards")
    if not isinstance(cards, list):
        return []

    items: list[dict[str, Any]] = []
    for rank, card in enumerate(_flatten_cards(cards), start=1):
        item = _parse_card_item(card, rank)
        if item is None:
            continue
        item_id = str(item.get("id") or "").strip()
        if item_id and any(str(existing.get("id") or "").strip() == item_id for existing in items):
            continue
        items.append(item)
        if len(items) >= limit:
            break

    for index, item in enumerate(items, start=1):
        item["rank"] = index
    return items


def _parse_hot_list_html(html: str, *, limit: int) -> list[dict[str, Any]]:
    tbody_match = re.search(r"<tbody>(.*?)</tbody>", html, re.S)
    rows = re.findall(r"<tr[^>]*>(.*?)</tr>", tbody_match.group(1), re.S) if tbody_match else []
    items: list[dict[str, Any]] = []
    for index, row in enumerate(rows, start=1):
        anchor = re.search(r'<a[^>]*href="([^"]+)"[^>]*>(.*?)</a>', row, re.S)
        if not anchor:
            continue
        title = _html_to_text(anchor.group(2))
        href = _absolute_weibo_url(anchor.group(1))
        if not title and not href:
            continue

        rank = index
        rank_match = re.search(r'ranktop(\d+)', row)
        if rank_match:
            rank = int(rank_match.group(1))

        hot_text = ""
        hot_match = re.search(r'<td class="td-02">(.*?)</td>', row, re.S)
        if hot_match:
            hot_text = _html_to_text(hot_match.group(1))

        hot_value = _to_int(hot_text)
        items.append(
            {
                "id": re.sub(r"[^0-9a-zA-Z_]+", "_", href or title)[:120],
                "title": title,
                "summary": title,
                "content": title,
                "url": href,
                "rank": rank,
                "hot_value": hot_value,
                "hot_text": hot_text,
                "source_type": "hot_topic",
                "result_type": "topic",
            }
        )
        if len(items) >= limit:
            break

    if items:
        return items

    for index, match in enumerate(
        re.finditer(r'<a[^>]*href="([^"]*/weibo\?q=[^"]+)"[^>]*>(.*?)</a>', html, re.S),
        start=1,
    ):
        href = _absolute_weibo_url(match.group(1))
        title = _html_to_text(match.group(2))
        if not title and not href:
            continue
        if any(str(existing.get("url", "")) == href for existing in items):
            continue
        items.append(
            {
                "id": re.sub(r"[^0-9a-zA-Z_]+", "_", href or title)[:120],
                "title": title,
                "summary": title,
                "content": title,
                "url": href,
                "rank": index,
                "hot_value": None,
                "hot_text": "",
                "source_type": "hot_topic",
                "result_type": "topic",
            }
        )
        if len(items) >= limit:
            break

    return items


def _parse_hot_list_pub_html(html: str, *, limit: int) -> list[dict[str, Any]]:
    items: list[dict[str, Any]] = []
    seen_titles: set[str] = set()
    for match in re.finditer(r'<a[^>]*href="([^"]+)"[^>]*>(.*?)</a>', html, re.S):
        href = _absolute_weibo_url(match.group(1))
        title = _html_to_text(match.group(2))
        if not title:
            continue
        if href.startswith("https://m.weibo.cn/search?") is False:
            continue
        if "containerid=100103type" not in href:
            continue
        if title in {"触屏版", "客户端", "客服"}:
            continue
        if title in seen_titles:
            continue
        seen_titles.add(title)
        rank = len(items) + 1
        items.append(
            {
                "id": re.sub(r"[^0-9a-zA-Z_]+", "_", title)[:120],
                "title": title,
                "summary": title,
                "content": title,
                "url": href,
                "rank": rank,
                "hot_value": None,
                "hot_text": "",
                "source_type": "hot_topic",
                "result_type": "topic",
            }
        )
        if len(items) >= limit:
            break
    return items


def _extract_render_data(html: str) -> dict[str, Any] | None:
    match = re.search(r"var\s+\$render_data\s*=\s*\[(.*?)\]\[0\]\s*\|\|\s*\[\];", html, re.S)
    if not match:
        return None
    raw = match.group(1).strip()
    if not raw:
        return None
    try:
        payload = json.loads(f"[{raw}]")
    except ValueError:
        return None
    if not isinstance(payload, list) or not payload:
        return None
    first = payload[0]
    return first if isinstance(first, dict) else None


def _parse_content_from_status_html(html: str, *, fallback_id: str, fallback_url: str) -> dict[str, Any] | None:
    render_data = _extract_render_data(html)
    if isinstance(render_data, dict):
        status = render_data.get("status")
        if isinstance(status, dict):
            item = _parse_card_item({"mblog": status, "scheme": fallback_url}, 1)
            if item is not None:
                item["id"] = item.get("id") or fallback_id
                item["url"] = item.get("url") or fallback_url
                return item

    title_match = re.search(r"<title>(.*?)</title>", html, re.S | re.I)
    title = clean_text(title_match.group(1)) if title_match else ""
    desc_match = re.search(r'<meta\s+name="description"\s+content="([^"]*)"', html, re.I)
    content = clean_text(desc_match.group(1)) if desc_match else ""
    if not title and not content:
        return None
    return {
        "id": fallback_id or fallback_url,
        "title": _summarize_text(title or content, 60),
        "summary": _summarize_text(content, 120),
        "content": content,
        "url": fallback_url,
        "author_name": "",
        "author_id": "",
        "publish_time": "",
        "rank": 1,
        "comment_count": None,
        "like_count": None,
        "share_count": None,
        "source_type": "weibo_post",
        "tags": _extract_hashtags(content),
    }


def _parse_content_from_weibo_cn_comment_html(
    html: str,
    *,
    fallback_id: str,
    fallback_url: str,
) -> dict[str, Any] | None:
    if "target weibo does not exist" in html:
        return None

    main_match = re.search(r'<div class="c" id="M_">(.*?)<div class="c"></div>', html, re.S)
    if not main_match:
        return None
    block = main_match.group(1)

    author_match = re.search(r'<a href="/(?:u/)?(\d+)">(.*?)</a>', block, re.S)
    content_match = re.search(r'<span class="ctt">(.*?)</span>', block, re.S)
    time_match = re.search(r'<span class="ct">(.*?)</span>', block, re.S)
    content = _html_to_text(content_match.group(1) if content_match else "")
    author_name = clean_text(author_match.group(2) if author_match else "")
    author_id = clean_text(author_match.group(1) if author_match else "")
    publish_time = clean_text(time_match.group(1) if time_match else "")

    if not content and not author_name:
        return None

    return {
        "id": fallback_id or fallback_url,
        "title": _summarize_text(content or author_name, 60),
        "summary": _summarize_text(content, 120),
        "content": content,
        "url": fallback_url,
        "author_name": author_name,
        "author_id": author_id,
        "publish_time": publish_time,
        "rank": 1,
        "comment_count": None,
        "like_count": None,
        "share_count": None,
        "source_type": "weibo_post",
        "tags": _extract_hashtags(content),
    }


def _parse_author_profile(payload: dict[str, Any], *, author_id: str, url: str) -> dict[str, Any] | None:
    data = payload.get("data")
    if not isinstance(data, dict):
        return None
    user = data.get("userInfo")
    if not isinstance(user, dict):
        return None

    content_count = _to_int(user.get("statuses_count"))
    tabs_info = data.get("tabsInfo")
    if isinstance(tabs_info, dict):
        tabs = tabs_info.get("tabs")
        if isinstance(tabs, list):
            for tab in tabs:
                if not isinstance(tab, dict) or tab.get("tabKey") != "weibo":
                    continue
                content_count = content_count or _to_int(tab.get("headSubTitleText"))
                break

    resolved_id = clean_text(str(user.get("id") or user.get("idstr") or author_id or ""))
    profile_url = _absolute_weibo_url(clean_text(str(user.get("profile_url") or "")))

    return {
        "id": resolved_id,
        "name": clean_text(str(user.get("screen_name") or "")),
        "url": profile_url or url,
        "avatar": _absolute_weibo_url(
            clean_text(str(user.get("avatar_hd") or user.get("profile_image_url") or ""))
        ),
        "bio": clean_text(
            str(user.get("description") or user.get("verified_reason") or "")
        ),
        "follower_count": _to_int(user.get("followers_count") or user.get("followers_count_str")),
        "following_count": _to_int(user.get("follow_count")),
        "content_count": content_count,
    }


def _parse_author_profile_api_weibo(
    payload: dict[str, Any],
    *,
    author_id: str,
    url: str,
) -> dict[str, Any] | None:
    user_node = payload.get("userInfo")
    if not isinstance(user_node, dict):
        return None

    resolved_id = clean_text(str(user_node.get("id") or user_node.get("idstr") or author_id or ""))
    profile_url = _absolute_weibo_url(clean_text(str(user_node.get("profile_url") or "")))
    return {
        "id": resolved_id,
        "name": clean_text(str(user_node.get("screen_name") or user_node.get("name") or "")),
        "url": profile_url or url,
        "avatar": _absolute_weibo_url(
            clean_text(
                str(
                    user_node.get("avatar_hd")
                    or user_node.get("avatar_large")
                    or user_node.get("profile_image_url")
                    or ""
                )
            )
        ),
        "bio": clean_text(str(user_node.get("description") or "")),
        "follower_count": _to_int(user_node.get("followers_count") or user_node.get("followers_count_str")),
        "following_count": _to_int(user_node.get("friends_count") or user_node.get("follow_count")),
        "content_count": _to_int(user_node.get("statuses_count")),
    }


def _build_author_from_detail_item(
    item: dict[str, Any],
    *,
    author_id: str,
    url: str,
) -> dict[str, Any] | None:
    if not isinstance(item, dict):
        return None

    resolved_id = clean_text(str(item.get("author_id") or author_id or ""))
    resolved_name = clean_text(str(item.get("author_name") or ""))
    resolved_url = _absolute_weibo_url(clean_text(str(item.get("url") or url or "")))
    if not resolved_id and not resolved_name and not resolved_url:
        return None

    profile_url = AUTHOR_URL_TEMPLATE.format(author_id=resolved_id) if resolved_id else resolved_url

    bio = clean_text(str(item.get("summary") or item.get("content") or ""))
    return {
        "id": resolved_id,
        "name": resolved_name,
        "url": profile_url or url,
        "avatar": "",
        "bio": bio,
        "follower_count": None,
        "following_count": None,
        "content_count": None,
    }


def _build_author_content_fallback_item(item: dict[str, Any], *, author_id: str) -> dict[str, Any] | None:
    if not isinstance(item, dict):
        return None
    resolved_author_id = clean_text(str(item.get("author_id") or author_id or ""))
    resolved_name = clean_text(str(item.get("author_name") or ""))
    if not resolved_author_id and not resolved_name:
        return None
    fallback_item = dict(item)
    if resolved_author_id:
        fallback_item["author_id"] = resolved_author_id
    if resolved_name and not fallback_item.get("author_name"):
        fallback_item["author_name"] = resolved_name
    return fallback_item


def fetch_hot_list_data(*, limit: int, refresh: bool) -> dict[str, Any]:
    del refresh
    safe_limit = _normalize_limit(limit)
    session = create_session(prime_home=True)
    errors: list[str] = []
    try:
        html = _request_text(session, HOT_LIST_URL, referer="https://s.weibo.com/")
        items = _parse_hot_list_html(html, limit=safe_limit)
        if items:
            return _build_list_result("hot_list", items, {})
        errors.append("hot_html_empty")
    except RuntimeError as exc:
        errors.append(str(exc))

    try:
        pub_html = _request_text(
            session,
            WEIBO_CN_PUB_URL,
            referer=WEIBO_CN_PUB_URL,
            allow_block_types={"pub_landing"},
        )
        pub_items = _parse_hot_list_pub_html(pub_html, limit=safe_limit)
        if pub_items:
            return _build_list_result("hot_list", pub_items, {})
        errors.append("weibo_cn_pub_empty")
    except RuntimeError as exc:
        errors.append(str(exc))

    return _build_list_result(
        "hot_list",
        [],
        {},
    )


def fetch_feed_list_data(
    *,
    channel: str,
    cursor: str,
    limit: int,
    refresh: bool,
) -> dict[str, Any]:
    refresh = bool(refresh)
    allowed_channels = {"", "hot", "home", "all"}
    if clean_text(channel).lower() not in allowed_channels:
        return _build_list_result("feed_list", [], {}, has_more=False, next_cursor="")
    safe_limit = _normalize_limit(limit)
    page = _parse_page_cursor(cursor)
    session = create_session(prime_home=True)
    try:
        payload = _request_json(
            session,
            CONTAINER_API_URL,
            params={
                "containerid": "102803",
                "page": page,
                "openApp": 0,
            },
            referer=HOME_URL,
        )
        items = _parse_cards_payload(payload, limit=safe_limit)
        if not items:
            hot_fallback = fetch_hot_list_data(limit=safe_limit, refresh=refresh)
            fallback_items = hot_fallback.get("items") if isinstance(hot_fallback, dict) else []
            if isinstance(fallback_items, list) and fallback_items:
                return _build_list_result(
                    "feed_list",
                    fallback_items,
                    {"source": "hot_list_fallback"},
                    has_more=False,
                    next_cursor="",
                )
            raise RuntimeError("微博信息流未解析到结果")

        data_node = payload.get("data")
        data: dict[str, Any] = data_node if isinstance(data_node, dict) else {}
        cardlist_node = data.get("cardlistInfo")
        cardlist_info: dict[str, Any] = cardlist_node if isinstance(cardlist_node, dict) else {}
        has_more = len(items) >= safe_limit or bool(cardlist_info.get("page"))
        next_cursor = str(page + 1) if has_more else ""

        return _build_list_result("feed_list", items, {}, has_more=has_more, next_cursor=next_cursor)
    except RuntimeError as exc:
        hot_fallback = fetch_hot_list_data(limit=safe_limit, refresh=refresh)
        fallback_items = hot_fallback.get("items") if isinstance(hot_fallback, dict) else []
        if isinstance(fallback_items, list) and fallback_items:
            return _build_list_result(
                "feed_list",
                fallback_items,
                {"source": "hot_list_fallback"},
                has_more=False,
                next_cursor="",
            )
        return _build_list_result("feed_list", [], {}, has_more=False, next_cursor="")


def fetch_search_content_data(*, query: str, cursor: str, limit: int) -> dict[str, Any]:
    keyword = query.strip()
    if not keyword:
        return _build_list_result("search", [], {}, has_more=False, next_cursor="")

    safe_limit = _normalize_limit(limit)
    page = _parse_page_cursor(cursor)
    session = create_session(prime_home=True)
    try:
        payload = _request_json(
            session,
            CONTAINER_API_URL,
            params={
                "containerid": f"100103type=1&q={keyword}",
                "page": page,
            },
            referer=f"https://m.weibo.cn/search?containerid=100103type=1&q={quote(keyword)}",
        )
        items = _parse_cards_payload(payload, limit=safe_limit)
        if not items:
            raise RuntimeError("微博搜索未解析到结果")

        data_node = payload.get("data")
        data: dict[str, Any] = data_node if isinstance(data_node, dict) else {}
        cardlist_node = data.get("cardlistInfo")
        cardlist_info: dict[str, Any] = cardlist_node if isinstance(cardlist_node, dict) else {}
        has_more = len(items) >= safe_limit or bool(cardlist_info.get("page"))
        next_cursor = str(page + 1) if has_more else ""

        keyword_lower = keyword.lower()
        filtered_items = []
        for item in items:
            text = " ".join(
                [
                    clean_text(item.get("title", "")),
                    clean_text(item.get("summary", "")),
                    clean_text(item.get("content", "")),
                    clean_text(item.get("author_name", "")),
                ]
            ).lower()
            if keyword_lower and keyword_lower in text:
                filtered_items.append(item)
        if not filtered_items:
            return _build_list_result("search", [], {}, has_more=False, next_cursor="")

        return _build_list_result("search", filtered_items, {}, has_more=has_more, next_cursor=next_cursor)
    except RuntimeError as exc:
        return _build_list_result("search", [], {}, has_more=False, next_cursor="")


def fetch_content_detail_data(*, content_id: str, url: str) -> dict[str, Any]:
    identifier = _extract_content_id(content_id, url)
    session = create_session(prime_home=True)
    search_keyword = _extract_search_keyword_from_url(url)
    if not identifier and url.strip():
        try:
            resolved_item = _resolve_first_item_from_search_url(session, url)
        except RuntimeError:
            resolved_item = None
        if resolved_item is not None:
            resolved_id = clean_text(str(resolved_item.get("id") or ""))
            resolved_url = clean_text(str(resolved_item.get("url") or ""))
            if resolved_id:
                identifier = resolved_id
                if resolved_url:
                    url = resolved_url
    if not identifier:
        if search_keyword:
            topic_item = _build_topic_detail_item(search_keyword, url.strip())
            if topic_item:
                return _build_detail_result(topic_item, {})
        return _build_detail_result({}, {})

    page_url = _absolute_weibo_url(url.strip()) or STATUS_URL_TEMPLATE.format(content_id=identifier)
    detail_source = "m_weibo"

    item: dict[str, Any] | None = None
    show_payload: dict[str, Any] = {}
    try:
        show_payload = _request_json(
            session,
            STATUS_SHOW_API_URL,
            params={"id": identifier},
            referer=page_url,
            require_ok=False,
        )
        mblog = show_payload.get("data")
        if not isinstance(mblog, dict) and isinstance(show_payload, dict) and show_payload.get("id"):
            mblog = show_payload
        if isinstance(mblog, dict):
            item = _parse_card_item({"mblog": mblog, "scheme": page_url}, 1)
    except RuntimeError:
        item = None

    try:
        extend_payload = _request_json(
            session,
            STATUS_EXTEND_API_URL,
            params={"id": identifier},
            referer=page_url,
            require_ok=False,
        )
        extend_data = extend_payload.get("data") if isinstance(extend_payload.get("data"), dict) else {}
        if item is not None and isinstance(extend_data, dict):
            long_text = _html_to_text(str(extend_data.get("longTextContent") or ""))
            if long_text:
                item["content"] = long_text
                item["summary"] = _summarize_text(long_text, 120)
                item["title"] = _summarize_text(long_text, 60)
            item["comment_count"] = _to_int(extend_data.get("comments_count") or item.get("comment_count"))
            item["like_count"] = _to_int(extend_data.get("attitudes_count") or item.get("like_count"))
            item["share_count"] = _to_int(extend_data.get("reposts_count") or item.get("share_count"))
    except RuntimeError:
        pass

    if item is None:
        try:
            html = _request_text(session, page_url, referer=HOME_URL)
            item = _parse_content_from_status_html(html, fallback_id=identifier, fallback_url=page_url)
            if item is not None:
                detail_source = "status_html"
        except RuntimeError:
            item = None

    if item is None:
        bid = _mid_to_bid(identifier)
        comment_url = WEIBO_CN_COMMENT_URL_TEMPLATE.format(content_id=bid)
        try:
            comment_html = _request_text(
                session,
                comment_url,
                referer=WEIBO_CN_PUB_URL,
                allow_block_types={"pub_landing"},
            )
            item = _parse_content_from_weibo_cn_comment_html(
                comment_html,
                fallback_id=identifier,
                fallback_url=page_url,
            )
            if item is not None:
                detail_source = "weibo_cn_comment"
        except RuntimeError:
            item = None

    if item is None:
        return _build_detail_result({}, {})

    item["id"] = item.get("id") or identifier
    item["url"] = item.get("url") or page_url

    return _build_detail_result(item, {})


def fetch_author_profile_data(*, author_id: str, url: str) -> dict[str, Any]:
    resolved_author_id = _extract_author_id(author_id, url)
    session = create_session(prime_home=True)
    if not resolved_author_id and url.strip():
        try:
            resolved_item = _resolve_first_item_from_search_url(session, url)
        except RuntimeError:
            resolved_item = None
        if resolved_item is not None:
            resolved_author_id = clean_text(str(resolved_item.get("author_id") or ""))
            if resolved_author_id:
                url = clean_text(str(resolved_item.get("url") or ""))
    if not resolved_author_id:
        return _build_author_result({}, {})

    page_url = _absolute_weibo_url(url.strip()) or AUTHOR_URL_TEMPLATE.format(author_id=resolved_author_id)

    try:
        payload = _request_json(
            session,
            CONTAINER_API_URL,
            params={
                "type": "uid",
                "value": resolved_author_id,
                "containerid": f"100505{resolved_author_id}",
            },
            referer=page_url,
        )
        author = _parse_author_profile(payload, author_id=resolved_author_id, url=page_url)
        if author is None:
            raise RuntimeError("微博作者主页未解析到结果")
        return _build_author_result(author, {})
    except RuntimeError:
        try:
            fallback_payload = _request_json(
                session,
                API_WEIBO_PROFILE_URL,
                params={"uid": resolved_author_id},
                referer=HOME_URL,
                require_ok=False,
            )
            fallback_author = _parse_author_profile_api_weibo(
                fallback_payload,
                author_id=resolved_author_id,
                url=page_url,
            )
            if fallback_author is not None:
                return _build_author_result(
                    fallback_author,
                    {},
                )
        except RuntimeError:
            pass
        cached_author = _AUTHOR_PROFILE_CACHE.get(resolved_author_id)
        if cached_author:
            return _build_author_result(dict(cached_author), {"source": "seen_content_cache"})
        if url.strip():
            try:
                detail_result = fetch_content_detail_data(content_id="", url=url)
                detail_item = detail_result.get("item") if isinstance(detail_result, dict) else None
                if isinstance(detail_item, dict):
                    detail_fallback_author = _build_author_from_detail_item(
                        detail_item,
                        author_id=resolved_author_id,
                        url=url,
                    )
                    if detail_fallback_author is not None:
                        return _build_author_result(detail_fallback_author, {"source": "content_detail_fallback"})
            except RuntimeError:
                pass
        return _build_author_result({}, {})


def _search_author_posts(
    session: requests.Session,
    *,
    author_name: str,
    author_id: str,
    limit: int,
) -> list[dict[str, Any]]:
    keyword = author_name.strip()
    resolved_author_id = clean_text(author_id)
    if not keyword or not resolved_author_id:
        return []
    items: list[dict[str, Any]] = []
    seen: set[str] = set()
    for page in range(1, 3):
        payload = _request_json(
            session,
            CONTAINER_API_URL,
            params={
                "containerid": f"100103type=1&q={keyword}",
                "page": page,
            },
            referer=f"https://m.weibo.cn/search?containerid=100103type=1&q={quote(keyword)}",
        )
        page_items = _parse_cards_payload(payload, limit=max(limit * 3, 20))
        if not page_items:
            continue
        for item in page_items:
            if clean_text(str(item.get("author_id", ""))) != resolved_author_id:
                continue
            key = clean_text(str(item.get("id") or item.get("url") or item.get("title") or ""))
            if not key or key in seen:
                continue
            seen.add(key)
            items.append(item)
            if len(items) >= limit:
                return items
    return items


def fetch_author_content_list_data(
    *,
    author_id: str,
    url: str,
    cursor: str,
    limit: int,
) -> dict[str, Any]:
    resolved_author_id = _extract_author_id(author_id, url)
    safe_limit = _normalize_limit(limit)
    page = _parse_page_cursor(cursor)
    session = create_session(prime_home=True)
    if not resolved_author_id and url.strip():
        try:
            resolved_item = _resolve_first_item_from_search_url(session, url)
        except RuntimeError:
            resolved_item = None
        if resolved_item is not None:
            resolved_author_id = clean_text(str(resolved_item.get("author_id") or ""))
            if resolved_author_id:
                url = clean_text(str(resolved_item.get("url") or ""))
    if not resolved_author_id:
        return _build_list_result("author_content_list", [], {}, has_more=False, next_cursor="")

    page_url = _absolute_weibo_url(url.strip()) or AUTHOR_URL_TEMPLATE.format(author_id=resolved_author_id)

    try:
        payload = _request_json(
            session,
            CONTAINER_API_URL,
            params={
                "type": "uid",
                "value": resolved_author_id,
                "containerid": f"107603{resolved_author_id}",
                "page": page,
            },
            referer=page_url,
        )

        items = _parse_cards_payload(payload, limit=safe_limit)
        for item in items:
            item["author_id"] = item.get("author_id") or resolved_author_id

        if not items:
            raise RuntimeError("微博作者内容列表未解析到结果")

        data_node = payload.get("data")
        data: dict[str, Any] = data_node if isinstance(data_node, dict) else {}
        cardlist_node = data.get("cardlistInfo")
        cardlist_info: dict[str, Any] = cardlist_node if isinstance(cardlist_node, dict) else {}
        has_more = len(items) >= safe_limit or bool(cardlist_info.get("page"))
        next_cursor = str(page + 1) if has_more else ""

        return _build_list_result("author_content_list", items, {}, has_more=has_more, next_cursor=next_cursor)
    except RuntimeError:
        author_name = ""
        try:
            profile_result = fetch_author_profile_data(author_id=resolved_author_id, url=page_url)
            author_name = clean_text(profile_result.get("author", {}).get("name", ""))
        except RuntimeError:
            author_name = ""
        if author_name:
            try:
                items = _search_author_posts(
                    session,
                    author_name=author_name,
                    author_id=resolved_author_id,
                    limit=safe_limit,
                )
            except RuntimeError:
                items = []
            if items:
                return _build_list_result(
                    "author_content_list",
                    items,
                    {"source": "search_exact_author"},
                    has_more=len(items) >= safe_limit,
                    next_cursor="",
                )
        cached_bucket = _AUTHOR_CONTENT_CACHE.get(resolved_author_id, {})
        cached_items = list(cached_bucket.values())[:safe_limit]
        if cached_items:
            return _build_list_result(
                "author_content_list",
                cached_items,
                {"source": "seen_content_cache"},
                has_more=len(cached_bucket) > safe_limit,
                next_cursor="",
            )
        return _build_list_result("author_content_list", [], {}, has_more=False, next_cursor="")


mcp = FastMCP(
    "WEIBO_MCP",
    instructions=(
        "Astron Weibo MCP server，基于微博游客态公开接口提供公开内容工具能力，"
        "无需额外部署后端服务。"
    ),
)


@mcp.tool()
def get_hot_list(
    ctx: Context,
    limit: int = 20,
    refresh: bool = False,
) -> dict[str, Any]:
    """
    获取微博热搜榜。

    参数：
    - limit: 返回条数，范围建议 1-50。
    - refresh: 是否刷新数据。
    """
    del ctx
    return fetch_hot_list_data(limit=limit, refresh=refresh)


@mcp.tool()
def get_feed_list(
    ctx: Context,
    channel: str = "hot",
    cursor: str = "",
    limit: int = 20,
    refresh: bool = False,
) -> dict[str, Any]:
    """
    获取微博公开信息流。

    参数：
    - channel: 频道参数，当前游客态实现保留该参数。
    - cursor: 分页游标，可为空。
    - limit: 返回条数，范围建议 1-50。
    - refresh: 是否刷新数据。
    """
    del ctx
    return fetch_feed_list_data(
        channel=channel,
        cursor=cursor,
        limit=limit,
        refresh=refresh,
    )


@mcp.tool()
def search_content(
    ctx: Context,
    query: str,
    cursor: str = "",
    limit: int = 20,
) -> dict[str, Any]:
    """
    搜索微博公开内容。

    参数：
    - query: 搜索关键词。
    - cursor: 分页游标，可为空。
    - limit: 返回条数，范围建议 1-50。
    """
    del ctx
    return fetch_search_content_data(query=query, cursor=cursor, limit=limit)


@mcp.tool()
def get_content_detail(
    ctx: Context,
    content_id: str = "",
    url: str = "",
) -> dict[str, Any]:
    """
    获取微博内容详情。

    参数：
    - content_id: 微博 ID。
    - url: 微博详情 URL。
    """
    del ctx
    return fetch_content_detail_data(content_id=content_id, url=url)


@mcp.tool()
def get_author_profile(
    ctx: Context,
    author_id: str = "",
    url: str = "",
) -> dict[str, Any]:
    """
    获取微博作者主页。

    参数：
    - author_id: 作者 ID。
    - url: 作者主页 URL。
    """
    del ctx
    return fetch_author_profile_data(author_id=author_id, url=url)


@mcp.tool()
def get_author_content_list(
    ctx: Context,
    author_id: str = "",
    url: str = "",
    cursor: str = "",
    limit: int = 20,
) -> dict[str, Any]:
    """
    获取微博作者公开作品列表。

    参数：
    - author_id: 作者 ID。
    - url: 作者主页 URL。
    - cursor: 分页游标，可为空。
    - limit: 返回条数，范围建议 1-50。
    """
    del ctx
    return fetch_author_content_list_data(
        author_id=author_id,
        url=url,
        cursor=cursor,
        limit=limit,
    )


def main() -> None:
    mcp.run()


if __name__ == "__main__":
    main()
