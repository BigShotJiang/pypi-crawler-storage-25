# Examples

## Create An Uploadable Room

```bash
hivemind init --service http://localhost:8100 --api-key hmk_owner

hivemind room create ./agents/my-scope \
  --rules-file rules.md \
  --query-visibility sealed
```

The output includes:

```text
Room: room_...
Invite: hmroom://...
```

## Add Room Data

```bash
hivemind room add-data room_... --file company_docs.md --meta source=docs
hivemind room add-data room_... "private note" --meta source=note
hivemind room data room_...
```

## Participant Inspection And Ask

```bash
hivemind room inspect 'hmroom://...'
hivemind room inspect 'hmroom://...' --json | jq '.room.manifest'
hivemind room ask 'hmroom://...' "What changed this month?"
```

`room ask` defaults to `--timeout 600`, `--max-llm-calls 20`,
`--max-tokens 100000`, and `--memory-mb 256`. Use explicit larger budgets for
dynamic scope/query/mediator rooms.

With a participant-owned query agent:

```bash
hivemind room ask 'hmroom://...' \
  "What changed this month?" \
  --agent ./participant-query-agent
```

## Fixed Query Agent Room

```bash
hivemind room create ./agents/my-scope \
  --query-agent ./agents/fixed-query \
  --query-visibility inspectable \
  --rules-file rules.md
```

Participants can ask questions but cannot upload replacement query code.

If the scope and query agents are already registered, the command is shorter:

```bash
hivemind room create scope_agent_id \
  --query-agent query_agent_id \
  --rules-file rules.md
```

For the current live watch-history tenant:

```bash
hivemind --profile watch-history room create agents/default-scope \
  --name watch-history-hashtags \
  --query-agent agents/default-query \
  --mediator-agent agents/default-mediator \
  --scope-visibility inspectable \
  --query-visibility inspectable \
  --rules-file rules.md \
  --trust-mode owner_approved \
  --llm-provider tinfoil \
  --llm-provider openrouter
```

## Non-LLM Room Egress Deny

```bash
hivemind room create ./agents/my-scope \
  --rules-file rules.md \
  --no-llm
```

The sandbox bridge rejects all LLM calls. The final room output is still allowed.
Use this only for pinned agents that do not call LLM endpoints.

## Owner-Approved Deployment Updates

```bash
hivemind room trust room_... --mode owner_approved --approve-live
```

Existing invite links keep working because recipients verify the updated room
manifest against the owner public key embedded in the original link.

## Direct HTTP

Create a room:

```bash
curl -X POST "$BASE/v1/rooms" \
  -H "Authorization: Bearer $OWNER_KEY" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "demo",
    "rules": "Only answer aggregate questions.",
    "scope_agent_id": "scope123",
    "query_mode": "uploadable",
    "query_visibility": "sealed",
    "output_visibility": "querier_only",
    "egress": {"llm_providers": ["tinfoil"], "allow_artifacts": false},
    "trust": {"mode": "operator_updates"}
  }'
```

Add data:

```bash
curl -X POST "$BASE/v1/rooms/$ROOM_ID/data" \
  -H "Authorization: Bearer $OWNER_KEY" \
  -H "Content-Type: application/json" \
  -d '{"text": "private document", "metadata": {"source": "demo"}}'
```

Run:

```bash
curl -X POST "$BASE/v1/rooms/$ROOM_ID/runs" \
  -H "Authorization: Bearer $INVITE_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"query": "Summarize the private document."}'
```

Poll:

```bash
curl "$BASE/v1/runs/$RUN_ID" -H "Authorization: Bearer $INVITE_TOKEN"
```
