import asyncio
import logging
import secrets
import threading
from contextlib import asynccontextmanager
from uuid import uuid4

from fastapi import Depends, FastAPI, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware

from .api.admin_tenants import register_admin_tenant_routes
from .api.agent_registry import register_agent_registry_routes
from .api.agent_uploads import register_agent_upload_routes
from .api.agent_helpers import (
    image_digest as _server_image_digest,
    spawn_bg as _spawn_bg,
    tenant_image_tag as _server_tenant_image_tag,
)
from .api.billing import register_admin_billing_routes, register_owner_billing_routes
from .api.runs import register_run_routes
from .api.room_helpers import (
    apply_room_to_query_request as _apply_room_to_query_request,
    load_room_for_caller as _load_room_for_caller,
    room_prompt_for_run as _room_prompt_for_run,
    room_wrap_id as _room_wrap_id,
)
from .api.rooms import register_room_routes
from .api.signup import register_signup_routes
from .api.system import register_system_routes
from .api.tenant_owner import register_tenant_owner_routes
from .config import Settings
from .core import Hivemind
from .models import (
    IndexRequest,
    IndexResponse,
    QueryRequest,
    StoreRequest,
    StoreResponse,
)
from .room_vault import RoomVaultSealed
from .tenants import Caller, Role, TenantRegistry
from .version import APP_VERSION

logger = logging.getLogger(__name__)

# Backward-compatible private helper export used by older tests/tools.
_image_digest = _server_image_digest
_tenant_image_tag = _server_tenant_image_tag


def create_app(settings: Settings | None = None) -> FastAPI:
    if settings is None:
        settings = Settings()

    @asynccontextmanager
    async def lifespan(app: FastAPI):
        # Strong-ref set for fire-and-forget tasks so the event loop can't
        # GC them mid-flight (per asyncio docs) and so we can cancel them
        # cleanly on shutdown. Spawning code uses _spawn_bg below.
        background_tasks: set[asyncio.Task] = set()
        app.state.background_tasks = background_tasks

        # Fetch TDX quote + measurements for /v1/attestation. Cheap,
        # cached for process lifetime; falls back to ready=false outside
        # a TEE so local dev boots normally.
        try:
            from . import attestation
            await asyncio.to_thread(attestation.bootstrap)
        except Exception as e:
            logger.warning("attestation bootstrap raised: %s", e)

        # Kick off agent-base image provisioning in the background — do
        # NOT block HTTP readiness on it. GHCR pull can fail (private
        # repo, network blip) and fall back to a multi-minute inline
        # Dockerfile build that will OOM-kill a 2GB CVM. When that ran
        # under `await`, lifespan never completed and uvicorn served
        # "Empty reply from server" until the whole container restart-
        # looped. Uploading agents before this task completes returns
        # the usual "agent-base not present" error — acceptable vs. a
        # hung control plane.
        async def _bootstrap_agent_base():
            try:
                from .agent_base_bootstrap import ensure_agent_base_image
                await asyncio.to_thread(ensure_agent_base_image)
            except Exception as e:
                logger.warning("agent-base bootstrap raised: %s", e)

        agent_base_task = _spawn_bg(app, _bootstrap_agent_base())

        registry = TenantRegistry(settings)
        app.state.registry = registry
        app.state.agent_base_task = agent_base_task
        yield
        # Cancel + drain any in-flight pipeline / upload runs before we
        # shut down the registry, so they don't crash mid-DB-call writing
        # against a closed connection.
        if background_tasks:
            for t in list(background_tasks):
                t.cancel()
            await asyncio.gather(*background_tasks, return_exceptions=True)
        # Close per-tenant Hivemind instances + control DB.
        await asyncio.to_thread(registry.close)

    app = FastAPI(title="Hivemind Core", version=APP_VERSION, lifespan=lifespan)

    # Translate TenantSealed (raised when an operation needs the
    # tenant's DEK but no valid bearer has thawed it since process
    # start) to a clear 503. Capability-token holders see this until
    # the owner interacts with the system after a redeploy.
    from .seal import TenantSealed as _TenantSealed
    from fastapi.responses import JSONResponse as _JSONResponse

    @app.exception_handler(_TenantSealed)
    async def _on_tenant_sealed(_request, exc):  # pragma: no cover
        return _JSONResponse(
            status_code=503,
            content={
                "detail": (
                    "Tenant is sealed: encrypted data cannot be read "
                    "until the owner (hmk_) interacts after the last "
                    "process restart. Have the tenant owner make any "
                    "request, then retry."
                ),
                "error": str(exc),
            },
        )

    @app.exception_handler(RoomVaultSealed)
    async def _on_room_vault_sealed(_request, exc):  # pragma: no cover
        return _JSONResponse(
            status_code=503,
            content={
                "detail": (
                    "Room data is sealed: encrypted room data cannot be "
                    "read until a room participant presents a bearer token "
                    "that has a key wrap for this room."
                ),
                "error": str(exc),
            },
        )

    cors_origins = [
        origin.strip()
        for origin in (settings.cors_allow_origins or "").split(",")
        if origin.strip()
    ]
    if cors_origins:
        app.add_middleware(
            CORSMiddleware,
            allow_origins=cors_origins,
            allow_methods=["*"],
            allow_headers=["*"],
        )

    def _registry(request: Request) -> TenantRegistry:
        return request.app.state.registry

    def _bearer(request: Request) -> str:
        auth = request.headers.get("Authorization", "")
        if not auth.startswith("Bearer "):
            raise HTTPException(status_code=401, detail="Unauthorized")
        return auth.removeprefix("Bearer ").strip()

    async def _payer_for_request(
        request: Request,
        caller: Caller,
        *,
        billable_role: str,
    ) -> dict:
        """Resolve who pays for this run.

        Query-token calls attach the participant tenant's ``hmk_`` API key so
        the data owner is not charged for the participant's LLM spend. Owner
        calls default to the owner tenant. Query-token calls without a tenant
        API key are rejected before work starts; the credit-enforcement setting
        controls whether a known payer must have enough positive balance, not
        whether a payer is required.
        """
        payer_key = (
            request.headers.get("X-Hivemind-Api-Key")
            or request.headers.get("X-Hivemind-Payer-Key")
            or ""
        ).strip()
        if payer_key:
            payer = await asyncio.to_thread(
                _registry(request).resolve_payer_key,
                payer_key,
            )
            if payer is None:
                raise HTTPException(401, "invalid tenant API key")
            return {
                "payer_tenant_id": payer["tenant_id"],
                "payer_token_id": payer.get("payer_token_id") or "",
                "billable_role": billable_role,
            }
        if caller.role == "owner":
            return {
                "payer_tenant_id": caller.tenant_id,
                "payer_token_id": "",
                "billable_role": billable_role,
            }
        raise HTTPException(
            402,
            "room invite queries require a tenant API key so usage can be "
            "charged to the querying tenant. In the CLI, run "
            "`hivemind --profile NAME init --service URL --api-key hmk_...` "
            "and then retry with `hivemind --profile NAME room ask ...`.",
        )

    def _billing_provider_for_room(req_provider: str | None, room: dict | None) -> str:
        if room is None:
            return (req_provider or "openrouter").strip().lower()
        allowed = [
            p.strip().lower()
            for p in room.get("allowed_llm_providers") or []
            if p.strip()
        ]
        if not allowed:
            return ""
        return (req_provider or allowed[0]).strip().lower()

    def _billing_models_for_query(hm: Hivemind, req: QueryRequest) -> list[str]:
        roles = ["scope", "query"]
        if req.mediator_agent_id or hm.settings.default_mediator_agent:
            roles.append("mediator")
        models: list[str] = []
        for role in roles:
            model = hm.pipeline._model_for(role, req.model)
            if model and model not in models:
                models.append(model)
        return models

    async def _prepare_billing_hold(
        request: Request,
        caller: Caller,
        hm: Hivemind,
        *,
        run_id: str,
        provider: str,
        models: list[str],
        max_tokens: int,
        billable_role: str,
    ) -> dict:
        payer = await _payer_for_request(
            request,
            caller,
            billable_role=billable_role,
        )
        hold = {"hold_micro_usd": 0, "status": "unbilled"}
        if payer.get("payer_tenant_id"):
            try:
                hold = await asyncio.to_thread(
                    _registry(request).billing_hold_for_run,
                    tenant_id=payer["payer_tenant_id"],
                    payer_token_id=payer.get("payer_token_id") or "",
                    run_id=run_id,
                    provider=provider,
                    models=models,
                    max_tokens=max_tokens,
                    billable_role=billable_role,
                    enforce=settings.billing_enforce_credits,
                )
            except ValueError as e:
                detail = str(e)
                status = 402 if "insufficient billing credit" in detail else 400
                raise HTTPException(status, detail)
        return {
            **payer,
            "billing_provider": provider,
            "billing_model": ",".join(models),
            "billing_hold_micro_usd": int(hold.get("hold_micro_usd") or 0),
            "billing_status": hold.get("status") or "unbilled",
        }

    async def _settle_empty_billing(
        hm: Hivemind,
        run_id: str,
        billing: dict,
        *,
        billable_role: str,
    ) -> None:
        if not billing.get("payer_tenant_id") or hm.billing_meter is None:
            return
        usage = {
            "calls": 0,
            "prompt_tokens": 0,
            "completion_tokens": 0,
            "total_tokens": 0,
            "max_tokens": 0,
            "stages": {},
        }
        try:
            settlement = await asyncio.to_thread(
                hm.billing_meter.settle_run,
                payer_tenant_id=billing.get("payer_tenant_id"),
                payer_token_id=billing.get("payer_token_id") or "",
                run_id=run_id,
                usage=usage,
                hold_micro_usd=int(billing.get("billing_hold_micro_usd") or 0),
                billable_role=billable_role,
                default_provider=billing.get("billing_provider"),
                default_model=billing.get("billing_model"),
            )
            if hasattr(hm.run_store, "update_usage"):
                await asyncio.to_thread(
                    hm.run_store.update_usage,
                    run_id,
                    usage,
                    billing_cost_micro_usd=int(
                        settlement.get("cost_micro_usd") or 0
                    ),
                    billing_status=settlement.get("billing_status") or "settled",
                    billing_settled_at=settlement.get("settled_at"),
                )
        except Exception as e:
            logger.warning("empty billing settlement failed for %s: %s", run_id, e)

    async def get_caller(request: Request) -> Caller:
        """Auth + role resolution. Recognizes hmk_ (owner) and hmq_
        (query capability) tokens.

        Stashes ``tenant_id`` and ``caller`` on ``request.state`` so
        downstream code (logging, role-specific handlers) can read them
        without re-resolving. 401 on any missing/invalid/revoked token.
        """
        registry = _registry(request)
        token = _bearer(request)
        caller = await asyncio.to_thread(registry.resolve_any, token)
        if caller is None:
            raise HTTPException(status_code=401, detail="Unauthorized")
        request.state.tenant_id = caller.tenant_id
        request.state.caller = caller
        return caller

    def requires_role(*roles: Role):
        """Build a FastAPI dependency that gates by caller role.

        Use as ``Depends(requires_role("owner"))`` or
        ``Depends(requires_role("owner", "query"))``. Returns the resolved
        :class:`Caller` so handlers can read constraints / hive directly.
        """
        allowed = set(roles)

        async def _dep(caller: Caller = Depends(get_caller)) -> Caller:
            if caller.role not in allowed:
                raise HTTPException(
                    status_code=403,
                    detail=(
                        f"role '{caller.role}' not permitted "
                        f"(need one of: {sorted(allowed)})"
                    ),
                )
            return caller

        return _dep

    async def get_tenant_hive(
        caller: Caller = Depends(requires_role("owner")),
    ) -> Hivemind:
        """Owner-only Hivemind dependency.

        Backward-compatible shim for endpoints that pre-date capability
        tokens — they all run as the tenant owner. New endpoints that
        accept query tokens should depend on :func:`get_caller` or
        :func:`requires_role` directly.
        """
        return caller.hive

    def _require_scope_agent_id(hm: Hivemind, scope_agent_id: str | None) -> str:
        """Resolve the effective scope agent or reject the request up front."""
        resolved = (scope_agent_id or hm.settings.default_scope_agent or "").strip()
        if not resolved:
            raise HTTPException(
                400,
                "scope_agent_id is required (no default scope agent configured)",
            )
        return resolved

    async def _ensure_scope_agent_exists(hm: Hivemind, scope_agent_id: str) -> None:
        agent = await asyncio.to_thread(hm.agent_store.get, scope_agent_id)
        if not agent:
            raise HTTPException(404, f"Scope agent '{scope_agent_id}' not found")

    async def check_admin(request: Request):
        """Gate admin endpoints with the separate HIVEMIND_ADMIN_KEY."""
        if not settings.admin_key:
            raise HTTPException(
                status_code=503,
                detail="Admin API disabled (HIVEMIND_ADMIN_KEY unset)",
            )
        token = _bearer(request)
        if not secrets.compare_digest(token, settings.admin_key):
            raise HTTPException(status_code=401, detail="Unauthorized")

    register_signup_routes(app, settings)
    register_admin_tenant_routes(app, settings, check_admin)
    register_admin_billing_routes(app, check_admin)
    register_owner_billing_routes(app, requires_role)
    register_tenant_owner_routes(app, _bearer, requires_role, get_tenant_hive)
    register_system_routes(app, settings, check_admin, requires_role)
    register_run_routes(app, requires_role)
    register_agent_registry_routes(app, settings, requires_role, get_tenant_hive)

    # ── Internal pipeline primitives ──
    #
    # Room endpoints below are the public execution surface. These lower-level
    # primitives are kept for tests/admin maintenance and are hidden from the
    # generated API schema so new clients do not learn the old generic path.

    @app.post(
        "/v1/_internal/store",
        response_model=StoreResponse,
        include_in_schema=False,
    )
    async def store(
        req: StoreRequest,
        caller: Caller = Depends(requires_role("owner")),
    ):
        try:
            return await caller.hive.pipeline.run_store(req)
        except ValueError as e:
            raise HTTPException(status_code=400, detail=str(e))

    def _force_scope_for_query_token(
        req: QueryRequest, caller: Caller
    ) -> QueryRequest:
        """If caller is a query-token holder, pin scope_agent_id to the
        token's bound scope agent. Owner-supplied scope_agent_id is left
        alone."""
        if caller.role != "query":
            return req
        bound = caller.constraints.get("scope_agent_id") or ""
        if not bound:
            raise HTTPException(
                status_code=500,
                detail="query token missing scope_agent_id constraint",
            )
        # Always overwrite — query tokens cannot bypass their bound scope.
        return req.model_copy(update={"scope_agent_id": bound})

    # ── Query submit (tracked async) ──
    #
    # The only query-execution endpoint. Synchronous ``POST /v1/query``
    # was removed because (a) it doesn't survive the Phala gateway's
    # 60s read timeout and (b) it never produced a Phase 5 signed
    # envelope, so strict-default attestation silently degraded for
    # every URI-based recipient call. Backed by the run_store table —
    # completed rows carry an Ed25519 signature over the run body.
    # Recipients poll status via ``GET /v1/runs/{run_id}``.

    async def _submit_query_run_for_request(
        req: QueryRequest,
        caller: Caller,
        room: dict | None = None,
        request: Request | None = None,
        bearer: str | None = None,
    ) -> dict:
        hm = caller.hive
        query_agent_id = req.query_agent_id or hm.settings.default_query_agent
        scope_agent_id = _require_scope_agent_id(hm, req.scope_agent_id)
        if not query_agent_id:
            raise HTTPException(
                400, "query_agent_id is required (no default configured)"
            )
        await _ensure_scope_agent_exists(hm, scope_agent_id)
        room_vault_items: list[dict] = []
        if room is not None:
            room_vault_items = await asyncio.to_thread(
                hm.room_vault.list_items_for_bearer,
                room["room_id"],
                _room_wrap_id(caller),
                bearer or "",
            )

        run_id = uuid4().hex[:12]
        effective_max_tokens = min(
            req.max_tokens or hm.settings.max_tokens,
            hm.settings.max_tokens,
        )
        billing = {
            "payer_tenant_id": None,
            "payer_token_id": caller.token_id or "",
            "billable_role": "query",
            "billing_provider": _billing_provider_for_room(req.provider, room),
            "billing_model": ",".join(_billing_models_for_query(hm, req)),
            "billing_hold_micro_usd": 0,
            "billing_status": "unbilled",
        }
        if request is not None:
            billing = await _prepare_billing_hold(
                request,
                caller,
                hm,
                run_id=run_id,
                provider=_billing_provider_for_room(req.provider, room),
                models=_billing_models_for_query(hm, req),
                max_tokens=effective_max_tokens,
                billable_role="query",
            )
        await asyncio.to_thread(
            hm.run_store.create, run_id, query_agent_id,
            scope_agent_id=scope_agent_id,
            issuer_token_id=(caller.token_id or None),
            payer_tenant_id=billing.get("payer_tenant_id"),
            payer_token_id=billing.get("payer_token_id"),
            billable_role=billing.get("billable_role"),
            billing_provider=billing.get("billing_provider"),
            billing_model=billing.get("billing_model"),
            billing_hold_micro_usd=int(billing.get("billing_hold_micro_usd") or 0),
            billing_status=billing.get("billing_status") or "unbilled",
            room_id=(room or {}).get("room_id"),
            room_manifest_hash=(room or {}).get("manifest_hash"),
            prompt=_room_prompt_for_run(room, req.query),
            output_visibility=(room or {}).get(
                "output_visibility", "owner_and_querier"
            ),
            artifacts_enabled=bool((room or {}).get("allow_artifacts", True)),
        )

        _spawn_bg(
            app,
            hm.pipeline.run_query_agent_tracked(
                agent_id=query_agent_id,
                run_id=run_id,
                run_store=hm.run_store,
                artifact_store=hm.artifact_store,
                artifact_retention_seconds=hm.settings.artifact_retention_seconds,
                prompt=req.query,
                scope_agent_id=scope_agent_id,
                mediator_agent_id=req.mediator_agent_id,
                max_tokens=req.max_tokens,
                max_calls=req.max_llm_calls,
                timeout_seconds=req.timeout_seconds,
                model=req.model,
                provider=req.provider,
                policy=req.policy,
                room_id=(room or {}).get("room_id"),
                room_manifest_hash=(room or {}).get("manifest_hash"),
                output_visibility=(room or {}).get(
                    "output_visibility", "owner_and_querier"
                ),
                allowed_llm_providers=(room or {}).get("allowed_llm_providers"),
                artifacts_enabled=bool((room or {}).get("allow_artifacts", True)),
                room_vault_items=room_vault_items,
                payer_tenant_id=billing.get("payer_tenant_id"),
                payer_token_id=billing.get("payer_token_id"),
                billable_role=billing.get("billable_role") or "query",
                billing_provider=billing.get("billing_provider"),
                billing_model=billing.get("billing_model"),
                billing_hold_micro_usd=int(
                    billing.get("billing_hold_micro_usd") or 0
                ),
            ),
        )

        return {
            "run_id": run_id,
            "query_agent_id": query_agent_id,
            "scope_agent_id": scope_agent_id,
            "room_id": (room or {}).get("room_id"),
            "status": "pending",
        }

    register_room_routes(
        app,
        settings,
        _bearer,
        requires_role,
        _submit_query_run_for_request,
    )

    @app.post("/v1/_internal/query/run/submit", include_in_schema=False)
    async def submit_query_run(
        req: QueryRequest,
        request: Request,
        caller: Caller = Depends(requires_role("owner", "query")),
    ):
        """Submit a query for tracked async processing.

        Returns a ``run_id``; the run executes via
        ``run_query_agent_tracked`` so the completed row carries a
        signed attestation envelope.
        """
        room: dict | None = None
        room_id = (req.room_id or "").strip()
        if caller.role == "query" and caller.constraints.get("room_id"):
            room = await _load_room_for_caller(caller, room_id)
            req = _apply_room_to_query_request(req, room)
        elif room_id:
            room = await _load_room_for_caller(caller, room_id)
            req = _apply_room_to_query_request(req, room)
        else:
            req = _force_scope_for_query_token(req, caller)
        return await _submit_query_run_for_request(
            req,
            caller,
            room,
            request=request,
            bearer=_bearer(request),
        )

    @app.post(
        "/v1/_internal/index",
        response_model=IndexResponse,
        include_in_schema=False,
    )
    async def index(req: IndexRequest, hm: Hivemind = Depends(get_tenant_hive)):
        try:
            return await hm.pipeline.run_index(req)
        except ValueError as e:
            raise HTTPException(status_code=400, detail=str(e))

    register_agent_upload_routes(
        app,
        settings,
        _bearer,
        requires_role,
        get_tenant_hive,
        _require_scope_agent_id,
        _ensure_scope_agent_exists,
        _prepare_billing_hold,
        _settle_empty_billing,
        _billing_provider_for_room,
        _billing_models_for_query,
    )

    return app


class _LazyApp:
    """ASGI wrapper that delays Settings/.env loading until first request."""

    def __init__(self):
        self._app: FastAPI | None = None
        self._lock = threading.Lock()

    def _get_app(self) -> FastAPI:
        if self._app is None:
            with self._lock:
                if self._app is None:
                    self._app = create_app()
        return self._app

    async def __call__(self, scope, receive, send):
        await self._get_app()(scope, receive, send)


app = _LazyApp()


def main():
    import os
    import tempfile
    import uvicorn

    logging.basicConfig(level=logging.INFO, format="%(levelname)s %(name)s: %(message)s")
    settings = Settings()

    # When enclave-terminated TLS is on, bootstrap attestation BEFORE
    # uvicorn.run() so we have the cert/key in hand before the socket
    # opens. The lifespan call becomes a no-op thanks to bootstrap's
    # idempotency guard.
    ssl_kwargs: dict = {}
    if os.environ.get("HIVEMIND_ENCLAVE_TLS"):
        from . import attestation as _att

        logger.info("HIVEMIND_ENCLAVE_TLS=1 — bootstrapping TLS before listen")
        _att.bootstrap()
        tls = _att.get_tls_material()
        if tls is None:
            logger.error(
                "Enclave TLS requested but derivation failed; falling back to HTTP. "
                "Check DSTACK_SIMULATOR_ENDPOINT / /var/run/dstack.sock."
            )
        else:
            cert_pem, key_pem = tls
            # uvicorn wants filesystem paths. tmpfs mounts are safe inside
            # the enclave; the cert/key are derived fresh every boot anyway.
            tdir = tempfile.mkdtemp(prefix="hivemind-tls-")
            cert_path = os.path.join(tdir, "cert.pem")
            key_path = os.path.join(tdir, "key.pem")
            with open(cert_path, "wb") as f:
                f.write(cert_pem)
            with open(key_path, "wb") as f:
                f.write(key_pem)
            os.chmod(key_path, 0o600)
            ssl_kwargs = {
                "ssl_certfile": cert_path,
                "ssl_keyfile": key_path,
            }
            logger.info(
                "TLS cert derived from dstack-KMS; "
                "fingerprint bound into REPORT_DATA v2"
            )

    uvicorn.run(
        create_app(settings),
        host=settings.host,
        port=settings.port,
        log_level="info",
        **ssl_kwargs,
    )


if __name__ == "__main__":
    main()
