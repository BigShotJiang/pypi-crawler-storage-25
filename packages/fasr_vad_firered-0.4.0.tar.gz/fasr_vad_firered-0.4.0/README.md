# fasr-vad-firered

基于 [FireRedVAD](https://github.com/FireRedTeam/FireRedVAD) 的语音活动检测模型插件，为 fasr 提供非流式 VAD 能力。

## 安装

```bash
pip install fasr-vad-firered
```

## 注册模型

| 注册名 | 类 | 默认 checkpoint | 说明 |
|---|---|---|---|
| `firered` | `FireRedForVAD` | `xukaituo/FireRedVAD` | 非流式 VAD，基于神经网络的语音段检测 |

模型权重默认从 ModelScope 自动下载。权重目录需包含 `cmvn.ark` 和 `model.pth.tar`。

## 使用方式

### 在流水线中使用

```python
from fasr import AudioPipeline

pipeline = (
    AudioPipeline()
    .add_pipe("detector", model="firered")
    .add_pipe("recognizer", model="firered_aed", checkpoint_dir="/path/to/asr-ckpt")
    .add_pipe("sentencizer", model="ct_transformer")
)
```

### 单独使用模型

```python
from fasr.config import registry
from fasr.data import Waveform

model = registry.vad_models.get("firered")()
model.from_checkpoint(use_gpu=True, speech_threshold=0.4)

waveform = Waveform.from_file("example.wav")
segments = model.detect(waveform)
for seg in segments:
    print(f"{seg.start_ms}ms - {seg.end_ms}ms")
```

## `from_checkpoint` 参数

| 参数 | 类型 | 默认值 | 说明 |
|---|---|---|---|
| `checkpoint_dir` | `str \| Path \| None` | `None`（自动下载） | 模型权重目录，需含 `cmvn.ark` 和 `model.pth.tar` |
| `use_gpu` | `bool` | `False` | 是否使用 GPU 推理 |
| `speech_threshold` | `float` | `0.4` | 语音判定阈值，越小越敏感 |

## 依赖

- `fasr`
- `torch >= 2.0.0`
- `soundfile >= 0.12.0`
- `kaldiio >= 2.18.0`、`kaldi-native-fbank >= 1.19.0`
- Python 3.10–3.12
