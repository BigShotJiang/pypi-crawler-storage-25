"""MemPalace — structured memory for pw-agent.

Phase 1: Flat storage with embeddings. Knowledge units are extracted from
conversations, embedded via Ollama, and stored locally. On new queries,
relevant units are retrieved by cosine similarity and injected into context.

Storage: ~/.config/pw-agent/memory/<project_hash>/
  - units.json     — list of knowledge units with metadata
  - vectors.npy    — embedding vectors (numpy array)
  - index.json     — project metadata and stats
"""

import json
import hashlib
import os
import time
from typing import Optional

import numpy as np
import requests

DEFAULT_MEMORY_DIR = os.path.expanduser("~/.config/pw-agent/memory")

# Embedding config
EMBED_MODEL = "nomic-embed-text"  # Tiny, fast, 300MB — falls back to LLM if not available
EMBED_FALLBACK = True  # Use the active LLM for embeddings if embed model not available
EMBED_DIM = 768  # nomic-embed-text dimension (auto-detected on first use)

# Retrieval config
TOP_K = 5  # Number of knowledge units to retrieve per query
MIN_SIMILARITY = 0.3  # Minimum cosine similarity to include
MAX_CONTEXT_CHARS = 3000  # Max chars of memory to inject into prompt


class KnowledgeUnit:
    """A single piece of knowledge extracted from a conversation."""

    def __init__(self, content: str, source: str = "", tags: list[str] = None,
                 timestamp: float = None, unit_id: str = None):
        self.id = unit_id or hashlib.md5(content.encode()).hexdigest()[:12]
        self.content = content
        self.source = source  # e.g. "conversation", "file:path/to/file.py", "tool:bash"
        self.tags = tags or []
        self.timestamp = timestamp or time.time()

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "content": self.content,
            "source": self.source,
            "tags": self.tags,
            "timestamp": self.timestamp,
        }

    @classmethod
    def from_dict(cls, d: dict) -> "KnowledgeUnit":
        return cls(
            content=d["content"],
            source=d.get("source", ""),
            tags=d.get("tags", []),
            timestamp=d.get("timestamp", 0),
            unit_id=d.get("id"),
        )


class MemoryStore:
    """Local memory store for a single project directory."""

    def __init__(self, project_dir: str, ollama_url: str = "http://localhost:11434",
                 memory_dir: str = ""):
        self.project_dir = os.path.abspath(project_dir)
        self.ollama_url = ollama_url
        self.memory_dir = memory_dir or DEFAULT_MEMORY_DIR

        # Project-specific storage path
        project_hash = hashlib.md5(self.project_dir.encode()).hexdigest()[:12]
        self.store_path = os.path.join(self.memory_dir, project_hash)
        os.makedirs(self.store_path, exist_ok=True)

        # Load existing data
        self.units: list[KnowledgeUnit] = []
        self.vectors: Optional[np.ndarray] = None
        self._embed_dim: Optional[int] = None
        self._embed_model: Optional[str] = None
        self._load()

    def _units_path(self) -> str:
        return os.path.join(self.store_path, "units.json")

    def _vectors_path(self) -> str:
        return os.path.join(self.store_path, "vectors.npy")

    def _index_path(self) -> str:
        return os.path.join(self.store_path, "index.json")

    def _load(self):
        """Load units and vectors from disk."""
        units_path = self._units_path()
        if os.path.exists(units_path):
            try:
                with open(units_path, "r") as f:
                    data = json.load(f)
                self.units = [KnowledgeUnit.from_dict(d) for d in data]
            except (json.JSONDecodeError, KeyError):
                self.units = []

        vectors_path = self._vectors_path()
        if os.path.exists(vectors_path):
            try:
                self.vectors = np.load(vectors_path)
                self._embed_dim = self.vectors.shape[1] if len(self.vectors.shape) > 1 else None
            except Exception:
                self.vectors = None

        # Load index for metadata
        index_path = self._index_path()
        if os.path.exists(index_path):
            try:
                with open(index_path, "r") as f:
                    idx = json.load(f)
                self._embed_model = idx.get("embed_model")
                self._embed_dim = idx.get("embed_dim", self._embed_dim)
            except Exception:
                pass

    def _save(self):
        """Persist units and vectors to disk."""
        with open(self._units_path(), "w") as f:
            json.dump([u.to_dict() for u in self.units], f, indent=2)

        if self.vectors is not None and len(self.vectors) > 0:
            np.save(self._vectors_path(), self.vectors)

        with open(self._index_path(), "w") as f:
            json.dump({
                "project_dir": self.project_dir,
                "embed_model": self._embed_model,
                "embed_dim": self._embed_dim,
                "unit_count": len(self.units),
                "last_updated": time.time(),
            }, f, indent=2)

    def _embed(self, texts: list[str]) -> Optional[np.ndarray]:
        """Get embeddings from Ollama. Returns array of shape (N, dim) or None."""
        # Try dedicated embed model first, fall back to active LLM
        model = self._embed_model or EMBED_MODEL

        for attempt_model in [model, None]:  # None = skip if both fail
            if attempt_model is None:
                break
            try:
                resp = requests.post(
                    f"{self.ollama_url}/api/embed",
                    json={"model": attempt_model, "input": texts},
                    timeout=30,
                )
                if resp.status_code == 200:
                    data = resp.json()
                    embeddings = data.get("embeddings", [])
                    if embeddings:
                        arr = np.array(embeddings, dtype=np.float32)
                        self._embed_model = attempt_model
                        self._embed_dim = arr.shape[1]
                        return arr
            except Exception:
                continue

        return None

    def add(self, content: str, source: str = "", tags: list[str] = None) -> bool:
        """Add a knowledge unit to the store."""
        # Skip duplicates (same content hash)
        unit = KnowledgeUnit(content=content, source=source, tags=tags)
        if any(u.id == unit.id for u in self.units):
            return False

        # Get embedding
        embedding = self._embed([content])
        if embedding is None:
            # Store without embedding — can be embedded later
            self.units.append(unit)
            self._save()
            return True

        # Append to vectors
        if self.vectors is None or len(self.vectors) == 0:
            self.vectors = embedding
        else:
            # Handle dimension mismatch (model changed)
            if embedding.shape[1] != self.vectors.shape[1]:
                # Re-embed everything with new model
                self.vectors = embedding
                self.units = [unit]
                self._save()
                return True
            self.vectors = np.vstack([self.vectors, embedding])

        self.units.append(unit)
        self._save()
        return True

    def retrieve(self, query: str, top_k: int = TOP_K) -> list[tuple[KnowledgeUnit, float]]:
        """Retrieve the most relevant knowledge units for a query."""
        if not self.units or self.vectors is None or len(self.vectors) == 0:
            return []

        # Embed the query
        query_vec = self._embed([query])
        if query_vec is None:
            return []

        # Cosine similarity
        query_norm = query_vec / (np.linalg.norm(query_vec, axis=1, keepdims=True) + 1e-8)
        store_norm = self.vectors / (np.linalg.norm(self.vectors, axis=1, keepdims=True) + 1e-8)
        similarities = (store_norm @ query_norm.T).flatten()

        # Top-K above threshold
        indices = np.argsort(similarities)[::-1][:top_k]
        results = []
        for idx in indices:
            sim = float(similarities[idx])
            if sim >= MIN_SIMILARITY:
                results.append((self.units[idx], sim))

        return results

    def format_context(self, query: str) -> str:
        """Retrieve and format relevant memories for injection into the prompt."""
        results = self.retrieve(query)
        if not results:
            return ""

        lines = ["## Relevant memories from previous sessions:"]
        total_chars = 0
        for unit, score in results:
            entry = f"- [{unit.source}] {unit.content}"
            if total_chars + len(entry) > MAX_CONTEXT_CHARS:
                break
            lines.append(entry)
            total_chars += len(entry)

        return "\n".join(lines)

    @property
    def size(self) -> int:
        return len(self.units)


def extract_knowledge(conversation: list[dict], existing_units: list[KnowledgeUnit]) -> list[dict]:
    """Extract knowledge units from a conversation.

    Simple extraction: pull out key facts from assistant responses and
    tool results. No LLM call needed for phase 1 — just heuristics.
    """
    existing_ids = {u.id for u in existing_units}
    new_units = []

    for i, msg in enumerate(conversation):
        role = msg.get("role", "")
        content = msg.get("content", "")

        if not content or len(content) < 50:
            continue

        if role == "assistant":
            # Skip tool calls — they're actions, not knowledge
            if "<tool_call>" in content or "ACTION:" in content:
                continue
            # Skip very short responses
            if len(content) < 100:
                continue

            # Extract the assistant's substantive response as a knowledge unit
            # Truncate to keep units focused
            text = content[:500].strip()
            unit_id = hashlib.md5(text.encode()).hexdigest()[:12]
            if unit_id not in existing_ids:
                new_units.append({
                    "content": text,
                    "source": "conversation",
                    "tags": [],
                })

        elif role == "tool_result":
            # Extract file reads and command outputs as knowledge
            if content.startswith("Result:"):
                result_text = content[7:].strip()
                if len(result_text) > 50:
                    # Determine source from previous assistant message
                    source = "tool"
                    if i > 0:
                        prev = conversation[i - 1].get("content", "")
                        if "read_file" in prev:
                            source = "file"
                        elif "bash" in prev:
                            source = "bash"
                        elif "list_files" in prev:
                            source = "listing"

                    text = result_text[:500].strip()
                    unit_id = hashlib.md5(text.encode()).hexdigest()[:12]
                    if unit_id not in existing_ids:
                        new_units.append({
                            "content": text,
                            "source": source,
                            "tags": [],
                        })

    return new_units
