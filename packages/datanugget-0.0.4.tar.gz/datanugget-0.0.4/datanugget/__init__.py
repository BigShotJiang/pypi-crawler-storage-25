import os

SOLUTIONS = {}

files = [
    ("1", "pca", "1. PCA (Principal Component Analysis)"),
    ("2", "svm_linear", "2. SVM Linear"),
    ("3", "logistic_regression", "3. Logistic Regression"),
    ("4", "linear_regression", "4. Linear Regression"),
    ("5", "confusion_matrix", "5. Confusion Matrix"),
    ("6", "correlation", "6. Correlation Matrix"),
    ("7", "mean_std_median", "7. Mean Median Std"),
    ("8", "train_test_split", "8. Train Test Split"),
    ("9", "scatter_plot", "9. Scatter Plot"),
    ("10", "metrics", "10. Metrics"),
    ("11", "read_csv", "11. CSV Dataset"),
    ("12", "knn_classifier", "12. KNN Classifier"),
    ("13", "perceptron", "13. Perceptron"),
    ("14", "naive_bayes", "14. Naive Bayes"),
    ("15", "gmm_kmeans", "15. GMM KMeans (EM Clustering)"),
    ("16", "lwr", "16. Locally Weighted Regression (LWR)"),
    ("17", "entropy", "17. Entropy (ID3)"),
    ("18", "nn_and", "18. Neural Network AND (NN)"),
]

files_dict = {num: (name, full_name) for num, name, full_name in files}

base_dir = os.path.dirname(os.path.abspath(__file__))

for num, name, full_name in files:
    filepath = os.path.join(base_dir, f"{num}_{name}.py")
    if os.path.exists(filepath):
        with open(filepath, "r") as f:
            SOLUTIONS[num] = f.read()


def help():
    print("Available programs:")
    print("-" * 50)
    for num in sorted(SOLUTIONS.keys(), key=lambda x: int(x)):
        name, full_name = files_dict.get(num, ("unknown", "Unknown"))
        print(f"{full_name}")
    print("-" * 50)
    print("Usage: dn.get('1')")


def get(key, filename):
    num = key.replace("pdf_", "").replace("pdf", "")
    if num in SOLUTIONS:
        with open(filename, "w") as f:
            f.write(SOLUTIONS[num])
        print(f"Generated {filename}")
    else:
        print(f"Not found: {key}")
        print("Run dn.help() to see available files.")
