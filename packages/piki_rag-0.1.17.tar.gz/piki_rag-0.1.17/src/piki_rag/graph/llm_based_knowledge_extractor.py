from typing import List

import yaml

from .knowledge_extraction import KnowledgeExtractor
from .model import KnowledgeExtraction, Relation, Entity
from ..llm.llm_provider import LLMProvider
from ..vector.db import VectorSearchResponseItem


def clean_markdown(response: str):
    if not response:
        return ""
    if response.startswith("```") and response.endswith("```"):
        lines = response.splitlines()
        return "\n".join(lines[1:-1])
    return response


class LLMBasedKnowledgeExtractor(KnowledgeExtractor):
    def __init__(self, llm_provider: LLMProvider, **kwargs):
        self.llm = llm_provider
        self.prompt_template = kwargs.get("prompt_template") or """{input}"""
        self.cleaners = kwargs.get("cleaner") or [lambda x: clean_markdown(x)]

    def extract(
        self, vector_search_response_items: List[VectorSearchResponseItem]
    ) -> List[KnowledgeExtraction]:
        knowledge_extractions = []
        for input in vector_search_response_items:
            response = self.llm.generate(
                prompt=self.prompt_template.format(input=input.text)
            )
            try:
                for cleaner in self.cleaners:
                    response = cleaner(response)
                data = yaml.safe_load(response)
            except:
                continue
            if not data:
                continue
            entities = {
                e["text"]: Entity(text=e["text"], type=e.get("type", "UNKNOWN"))
                for e in data.get("entities", [])
            }
            relations = []
            for rel in data.get("relations", []):
                subject = entities.get(rel["subject"]) or Entity(
                    text=rel["subject"], type="UNKNOWN"
                )
                object_ = entities.get(rel["object"]) or Entity(
                    text=rel["object"], type="UNKNOWN"
                )
                relations.append(
                    Relation(
                        subject=subject,
                        predicate=rel["predicate"],
                        object=object_,
                        source=input.source,
                    )
                )
            knowledge_extractions.append(
                KnowledgeExtraction(
                    chunk=input,
                    entities=list(entities.values()),
                    relations=relations,
                    source=input.source,
                )
            )
        return knowledge_extractions
