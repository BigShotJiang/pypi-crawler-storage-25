import functools
import logging
from collections.abc import Callable
from typing import Any

from git_workspace.assets import Copier, IgnoreManager, Linker
from git_workspace.env import build_env
from git_workspace.fingerprint import compute_fingerprints
from git_workspace.hooks import HookRunner
from git_workspace.worktree import Worktree

logger = logging.getLogger(__name__)


def _env(fn: Callable[..., Any]) -> Callable[..., Any]:
    @functools.wraps(fn)
    def wrapper(worktree: Worktree, runtime_vars: dict[str, str], *args: Any, **kwargs: Any) -> Any:
        fingerprint_vars = compute_fingerprints(worktree, worktree.workspace.manifest.fingerprints)
        env = build_env(worktree, runtime_vars, fingerprint_vars)
        return fn(worktree, runtime_vars, env, *args, **kwargs)

    return wrapper


def _apply_assets(worktree: Worktree, env: dict[str, str]) -> None:
    with IgnoreManager(worktree) as ignore:
        Copier(worktree, ignore, env).apply()
        Linker(worktree, ignore).apply()


@_env
def activate_worktree(
    worktree: Worktree,
    runtime_vars: dict[str, str],
    env: dict[str, str],
    *,
    detached: bool,
    effective_branch: str | None = None,
) -> None:
    """
    Apply assets and run setup/attach hooks when entering a worktree.

    For new worktrees, assets are applied first and then ``on_setup`` hooks are
    run. If ``detached`` is ``False``, ``on_attach`` hooks are also run.

    :param worktree: The worktree being activated.
    :param runtime_vars: Extra variables to inject into the hook environment.
    :param detached: If ``True``, ``on_attach`` hooks are skipped.
    :param effective_branch: Branch name used to evaluate hook conditions. Defaults
        to the worktree's real branch when not provided.
    """
    logger.debug(
        "activating worktree %r (is_new=%s, detached=%s)",
        worktree.branch,
        worktree.is_new,
        detached,
    )

    if worktree.is_new:
        _apply_assets(worktree, env)

    effective = effective_branch or worktree.branch
    with HookRunner(worktree, env=env, effective_branch=effective) as hook_runner:
        if worktree.is_new:
            hook_runner.run_on_setup_hooks()

        if not detached:
            hook_runner.run_on_attach_hooks()


@_env
def reset_worktree(
    worktree: Worktree,
    runtime_vars: dict[str, str],
    env: dict[str, str],
    *,
    effective_branch: str | None = None,
) -> None:
    """
    Re-apply assets and re-run ``on_setup`` hooks for an existing worktree.

    :param worktree: The worktree being reset.
    :param runtime_vars: Extra variables to inject into the hook environment.
    :param effective_branch: Branch name used to evaluate hook conditions. Defaults
        to the worktree's real branch when not provided.
    """
    logger.debug("resetting worktree %r", worktree.branch)
    _apply_assets(worktree, env)

    effective = effective_branch or worktree.branch
    with HookRunner(worktree, env=env, effective_branch=effective) as hook_runner:
        hook_runner.run_on_setup_hooks()


@_env
def deactivate_worktree(
    worktree: Worktree,
    runtime_vars: dict[str, str],
    env: dict[str, str],
    *,
    effective_branch: str | None = None,
) -> None:
    """
    Run ``on_detach`` hooks when leaving a worktree without removing it.

    :param worktree: The worktree being deactivated.
    :param runtime_vars: Extra variables to inject into the hook environment.
    :param effective_branch: Branch name used to evaluate hook conditions. Defaults
        to the worktree's real branch when not provided.
    """
    logger.debug("deactivating worktree %r", worktree.branch)
    effective = effective_branch or worktree.branch
    with HookRunner(worktree, env=env, effective_branch=effective) as hook_runner:
        hook_runner.run_on_detach_hooks()


@_env
def remove_worktree(
    worktree: Worktree,
    runtime_vars: dict[str, str],
    env: dict[str, str],
    *,
    force: bool,
    effective_branch: str | None = None,
) -> None:
    """
    Run detach and teardown hooks, then delete the worktree.

    Runs ``on_detach`` hooks first, then ``on_teardown`` hooks, and finally
    removes the worktree directory.

    :param worktree: The worktree to remove.
    :param runtime_vars: Extra variables to inject into the hook environment.
    :param force: If ``True``, passes ``--force`` to the underlying ``git worktree remove`` call.
    :param effective_branch: Branch name used to evaluate hook conditions. Defaults
        to the worktree's real branch when not provided.
    """
    logger.debug("removing worktree %r (force=%s)", worktree.branch, force)
    effective = effective_branch or worktree.branch
    with HookRunner(worktree, env=env, effective_branch=effective) as hook_runner:
        hook_runner.run_on_detach_hooks()
        hook_runner.run_on_teardown_hooks()

    worktree.delete(force)
