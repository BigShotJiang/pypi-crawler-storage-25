from typing import Annotated

import typer

from git_workspace import operations
from git_workspace.cli.parsers import parse_vars
from git_workspace.ui import console, styled_branch, styled_path
from git_workspace.workspace import Workspace

app = typer.Typer()


@app.command()
def up(
    branch: Annotated[
        str | None,
        typer.Argument(
            help="The target git branch to be activated in the workspace",
        ),
    ] = None,
    base_branch: Annotated[
        str | None,
        typer.Option(
            "-b",
            "--base",
            help="The base branch to use when creating a new branch. If omitted, defaults to the base branch defined in the workspace manifest",
        ),
    ] = None,
    workspace_dir: Annotated[
        str | None,
        typer.Option(
            "-r",
            "--root",
            help="The path to the workspace root. If omitted, the workspace root will be inferred from the current working directory",
        ),
    ] = None,
    runtime_vars: Annotated[
        list[str] | None,
        typer.Option(
            "-v",
            "--var",
            help="A variable that will be forwarded to the workspace's hook scripts. May be specified multiple times",
            callback=parse_vars,
        ),
    ] = None,
    detached: Annotated[
        bool,
        typer.Option(
            "--detached",
            "-d",
            help=(
                "Skip on_attach hooks after activation. Suitable for headless or agent workflows."
            ),
            is_flag=True,
        ),
    ] = False,
    effective_branch: Annotated[
        str | None,
        typer.Option(
            "-a",
            "--as",
            help="Treat the worktree as if it were on this branch when evaluating hook conditions. Does not change the actual branch or GIT_WORKSPACE_BRANCH.",
        ),
    ] = None,
    output: Annotated[
        bool,
        typer.Option(
            "-o",
            "--output",
            is_flag=True,
            help="Print the worktree path to stdout and suppress all other output.",
        ),
    ] = False,
) -> None:
    """
    Spawns a worktree, setting it up first if needed.

    Ensures that a worktree exists for the target branch and then performs lightweight actions to enter or resume working in that workspace.

    If the worktree does not exist, copies and links from the manifest are applied first, followed by on_setup hooks. Unless --detached is passed, on_attach hooks also run — use --detached for headless or automated workflows.
    """
    workspace = Workspace.resolve(workspace_dir)
    worktree = workspace.resolve_or_create_worktree(branch, base_branch)

    console.print(f"Activating {styled_branch(worktree.branch)}")

    operations.activate_worktree(
        worktree,
        runtime_vars=dict(runtime_vars or []),  # ty:ignore[no-matching-overload]
        detached=detached,
        effective_branch=effective_branch,
    )

    console.success(f"Worktree ready at {styled_path(worktree.dir)}")

    if output:
        typer.echo(str(worktree.dir))
