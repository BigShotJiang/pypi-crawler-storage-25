"""MeshCode — Real-time communication between AI agents."""
__version__ = "2.1.2"
