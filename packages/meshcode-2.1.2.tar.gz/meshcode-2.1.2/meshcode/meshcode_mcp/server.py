"""MeshCode MCP server — exposes meshcode tools to MCP clients (Claude Code, etc).

Tools:    meshcode_send, meshcode_broadcast, meshcode_read, meshcode_check,
          meshcode_status, meshcode_register, meshcode_set_status
Resources: meshcode://inbox, meshcode://board, meshcode://history

Run with:
    MESHCODE_PROJECT=my-app MESHCODE_AGENT=backend python -m meshcode_mcp serve
"""
import asyncio
import json
import logging
import os
import sys
from collections import deque
from contextlib import asynccontextmanager
from typing import Any, Dict, List, Optional, Union


# ============================================================
# Dedupe: track IDs of messages we've already returned from
# meshcode_wait / meshcode_check so the same row doesn't show
# up twice when realtime + polled paths race.
# ============================================================
_SEEN_MSG_IDS: set = set()
_SEEN_MSG_ORDER: deque = deque()
_SEEN_MSG_CAP = 1000

# ============================================================
# Auto-wake: when agent is NOT in meshcode_wait and a message
# arrives, inject text into the terminal to wake the agent.
# Toggle via MESHCODE_AUTO_WAKE=1 env var or meshcode_auto_wake tool.
# ============================================================
_IN_WAIT = False  # True while meshcode_wait is blocking
_AUTO_WAKE = os.environ.get("MESHCODE_AUTO_WAKE", "").lower() in ("1", "true", "yes")


def _try_auto_wake(from_agent: str, preview: str) -> None:
    """Inject a nudge into the terminal if the agent is idle (not in wait).

    macOS:  AppleScript → keystroke into Terminal/iTerm2
    Windows: PowerShell SendKeys to the console window
    Linux:  xdotool (best-effort)
    """
    if _IN_WAIT or not _AUTO_WAKE:
        return
    import subprocess, platform, re
    # Sanitize inputs: strip everything except alphanumeric, spaces, basic punctuation
    safe_agent = re.sub(r'[^a-zA-Z0-9_\- ]', '', from_agent)[:50]
    safe_preview = re.sub(r'[^a-zA-Z0-9_\-.,!? ]', '', preview)[:60]
    nudge = f"New mesh message from {safe_agent}: {safe_preview}. Check inbox with meshcode_check()."
    system = platform.system()
    try:
        if system == "Darwin":
            # Use xdotool-style approach: pass nudge as argument, not interpolated script
            parent_app = os.environ.get("TERM_PROGRAM", "Terminal")
            app_name = "iTerm" if "iTerm" in parent_app else "Terminal"
            # Escape for AppleScript string: replace backslash and double-quote
            as_safe = nudge.replace("\\", "\\\\").replace('"', '\\"')
            script = f'''
            tell application "{app_name}"
                tell application "System Events"
                    keystroke "{as_safe}"
                    keystroke return
                end tell
            end tell
            '''
            subprocess.Popen(["osascript", "-e", script],
                             stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            log.info(f"auto-wake: injected nudge via {app_name} AppleScript")
        elif system == "Windows":
            # Sanitize for SendKeys: strip braces and special SendKeys metacharacters
            sk_safe = nudge.replace("{", "").replace("}", "").replace("+", "").replace("^", "").replace("%", "").replace("~", "")
            ps_script = f'''
            Add-Type -AssemblyName System.Windows.Forms
            [System.Windows.Forms.SendKeys]::SendWait("{sk_safe}{{ENTER}}")
            '''
            subprocess.Popen(["powershell", "-Command", ps_script],
                             stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            log.info("auto-wake: injected nudge via PowerShell SendKeys")
        else:
            # Linux — xdotool takes args directly, not shell-interpolated (safe)
            subprocess.Popen(["xdotool", "type", "--clearmodifiers", nudge + "\n"],
                             stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            log.info("auto-wake: injected nudge via xdotool")
    except Exception as e:
        log.debug(f"auto-wake failed: {e}")


def _seen_key(msg: Dict[str, Any]) -> str:
    """Build a dedupe key. Prefer the real row id; fall back to a synthetic."""
    mid = msg.get("id")
    if mid:
        return str(mid)
    payload = msg.get("payload") or {}
    try:
        payload_str = json.dumps(payload, sort_keys=True, default=str)[:50]
    except Exception:
        payload_str = str(payload)[:50]
    return f"{msg.get('from') or msg.get('from_agent')}|{msg.get('ts') or msg.get('created_at')}|{payload_str}"


def _mark_seen(key: str) -> None:
    if key in _SEEN_MSG_IDS:
        return
    _SEEN_MSG_IDS.add(key)
    _SEEN_MSG_ORDER.append(key)
    while len(_SEEN_MSG_ORDER) > _SEEN_MSG_CAP:
        old = _SEEN_MSG_ORDER.popleft()
        _SEEN_MSG_IDS.discard(old)


def _filter_and_mark(messages: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """Drop already-seen messages; mark the rest as seen."""
    out = []
    for m in messages:
        k = _seen_key(m)
        if k in _SEEN_MSG_IDS:
            continue
        _mark_seen(k)
        out.append(m)
    return out


def _split_messages(messages: List[Dict[str, Any]]) -> Dict[str, Any]:
    """Split a list of normalized message dicts into messages / acks / done_signals."""
    real: List[Dict[str, Any]] = []
    acks: List[Dict[str, Any]] = []
    dones: List[Dict[str, Any]] = []
    for m in messages:
        t = m.get("type", "msg")
        if t == "ack":
            acks.append(m)
        elif t == "done":
            dones.append(m)
        else:
            real.append(m)
    return {
        "messages": real,
        "acks": acks,
        "done_signals": dones,
        "count": len(real),
    }

from . import backend as be
from .realtime import RealtimeListener

# ============================================================
# Session Replay: unique session ID per MCP server boot.
# Events are recorded in background threads (fire-and-forget).
# ============================================================
import uuid as _uuid
_SESSION_ID = str(_uuid.uuid4())[:12]


def _record_event_bg(event_type: str, payload: dict = None) -> None:
    """Fire-and-forget: record a session event in background thread."""
    try:
        api_key = _get_api_key()
        import threading
        threading.Thread(
            target=be.record_event,
            args=(api_key, _PROJECT_ID, AGENT_NAME, _SESSION_ID, event_type, payload or {}),
            daemon=True,
        ).start()
    except Exception:
        pass


# ============================================================
# Hot-reload: detect when backend.py changes on disk (e.g. after
# pip install --upgrade meshcode) and reload without restart.
# Only backend.py is safe to reload (stateless). server.py has
# module-level state that would be destroyed by reload.
# ============================================================
import importlib as _importlib
_be_mtime: float = 0.0
try:
    _be_path = os.path.abspath(be.__file__)
    _be_mtime = os.path.getmtime(_be_path)
except Exception:
    _be_path = ""


def _check_hot_reload() -> None:
    """If backend.py was modified since boot/last reload, reimport it."""
    global _be_mtime, be
    if not _be_path:
        return
    try:
        current_mtime = os.path.getmtime(_be_path)
        if current_mtime > _be_mtime:
            _be_mtime = current_mtime
            _importlib.reload(be)
            log.info("[meshcode] Hot-reloaded backend.py (new version detected)")
    except Exception as e:
        log.debug(f"hot-reload check failed: {e}")

try:
    from mcp.server.fastmcp import FastMCP
except ImportError:
    print(
        "[meshcode-mcp] ERROR: mcp package not installed. Run: pip install 'mcp[cli]>=1.0'",
        file=sys.stderr,
    )
    sys.exit(2)

logging.basicConfig(level=logging.INFO, stream=sys.stderr,
                    format="[meshcode-mcp] %(message)s")
log = logging.getLogger("meshcode-mcp")


# ============================================================
# Server context — agent identity from env vars
# ============================================================

PROJECT_NAME = os.environ.get("MESHCODE_PROJECT", "")
AGENT_NAME = os.environ.get("MESHCODE_AGENT", "")
AGENT_ROLE = os.environ.get("MESHCODE_ROLE", "")

if not PROJECT_NAME or not AGENT_NAME:
    print(
        "[meshcode-mcp] ERROR: MESHCODE_PROJECT and MESHCODE_AGENT env vars required",
        file=sys.stderr,
    )
    sys.exit(2)


# ============================================================
# API key resolution — keychain first, env var fallback
# ============================================================
#
# 1.4.1+ stores api keys in the OS keychain. The setup_clients writer
# bakes only MESHCODE_KEYCHAIN_PROFILE into the .mcp.json env block, NOT
# the api key itself. The MCP server resolves the key at boot via the
# secrets module. The env-var path is preserved as a fallback for users
# whose OS doesn't have a keychain backend.

_API_KEY_CACHE: Optional[str] = None

def _get_api_key() -> str:
    """Resolve the api_key for this MCP server process. Cached after first call."""
    global _API_KEY_CACHE
    if _API_KEY_CACHE is not None:
        return _API_KEY_CACHE
    # 1. Direct env var (legacy / fallback path)
    val = os.environ.get("MESHCODE_API_KEY", "").strip()
    if val:
        _API_KEY_CACHE = val
        return val
    # 2. Keychain via profile name in env
    profile = os.environ.get("MESHCODE_KEYCHAIN_PROFILE", "").strip()
    if profile:
        try:
            import importlib
            secrets_mod = importlib.import_module("meshcode.secrets")
            kc_val = secrets_mod.get_api_key(profile=profile)
            if kc_val:
                _API_KEY_CACHE = kc_val
                return kc_val
        except Exception as e:
            print(f"[meshcode-mcp] WARNING: keychain lookup failed for profile '{profile}': {e}", file=sys.stderr)
    _API_KEY_CACHE = ""
    return ""


# Resolve project_id at startup. Try in order:
#   1. MESHCODE_PROJECT_ID env var (baked by `meshcode setup`, fastest)
#   2. mc_resolve_project RPC with the user's api_key (security definer, bypasses RLS)
#   3. Direct SELECT via get_project_id (only works if RLS is open / user is admin)
_PROJECT_ID: Optional[str] = os.environ.get("MESHCODE_PROJECT_ID") or None
if not _PROJECT_ID:
    _api_key = _get_api_key()
    if _api_key:
        try:
            _r = be.sb_rpc("mc_resolve_project", {
                "p_api_key": _api_key,
                "p_project_name": PROJECT_NAME,
            })
            if isinstance(_r, dict) and _r.get("project_id"):
                _PROJECT_ID = _r["project_id"]
            elif isinstance(_r, dict) and _r.get("error"):
                print(f"[meshcode-mcp] WARNING: mc_resolve_project: {_r['error']}", file=sys.stderr)
        except Exception as _e:
            print(f"[meshcode-mcp] WARNING: mc_resolve_project failed: {_e}", file=sys.stderr)
if not _PROJECT_ID:
    _PROJECT_ID = be.get_project_id(PROJECT_NAME)
if not _PROJECT_ID:
    print(f"[meshcode-mcp] ERROR: project '{PROJECT_NAME}' not found (check MESHCODE_KEYCHAIN_PROFILE / MESHCODE_API_KEY)", file=sys.stderr)
    sys.exit(2)

_register_result = be.register_agent(PROJECT_NAME, AGENT_NAME, AGENT_ROLE or "MCP-connected agent")
if isinstance(_register_result, dict) and _register_result.get("error"):
    print(f"[meshcode-mcp] WARNING: register failed: {_register_result['error']}", file=sys.stderr)

# Flip to online so the dashboard reflects the live MCP session.
# Use the SECURITY DEFINER RPC (mc_agent_set_status_by_api_key) so we
# bypass RLS — the publishable key has no JWT context and cannot UPDATE
# mc_agents directly. The RPC validates ownership via api_key.
def _flip_status(status: str, task: str = "") -> bool:
    """Write status directly to mc_agents table for instant Realtime propagation.

    Uses direct PATCH (not RPC) so Supabase Realtime fires an UPDATE event
    immediately — the dashboard sees the change in <100ms instead of waiting
    for the next heartbeat cycle.
    """
    try:
        be.set_status(_PROJECT_ID, AGENT_NAME, status, task)
        return True
    except Exception:
        # Fallback to RPC if direct PATCH fails (RLS issue)
        api_key = _get_api_key()
        if not api_key:
            return False
        try:
            r = be.sb_rpc("mc_agent_set_status_by_api_key", {
                "p_api_key": api_key,
                "p_project_id": _PROJECT_ID,
                "p_agent_name": AGENT_NAME,
                "p_status": status,
                "p_task": task,
            })
            return isinstance(r, dict) and r.get("ok", False)
        except Exception:
            return False

if not _flip_status("idle", ""):
    print(f"[meshcode-mcp] WARNING: could not flip status to idle", file=sys.stderr)


# ============================================================
# Automatic Agent Status State Machine
# States: ONLINE → WORKING → ONLINE → WAITING → ONLINE → IDLE → OFFLINE
# Transitions driven by tool calls and meshcode_wait, not the LLM.
# ============================================================
import functools as _functools
import threading as _threading
import time as _time

_flip_lock = _threading.Lock()
_current_state = "online"
_last_tool_at = _time.time()
_current_tool = ""
_IDLE_THRESHOLD_S = 120  # seconds without tool call → IDLE
_WORKING_COOLDOWN_S = 60  # seconds after last tool returns before flipping to ONLINE
_working_timer: Optional[_threading.Timer] = None


async def _async_flip_status(status: str, task: str = "") -> None:
    try:
        await asyncio.to_thread(_flip_status_locked, status, task)
    except Exception as e:
        log.debug(f"flip_status({status}) failed: {e}")


def _flip_status_locked(status: str, task: str = "") -> bool:
    """Thread-safe wrapper around _flip_status to prevent concurrent RPCs."""
    with _flip_lock:
        return _flip_status(status, task)


def _schedule_flip(status: str, task: str = "") -> None:
    try:
        loop = asyncio.get_running_loop()
        loop.create_task(_async_flip_status(status, task))
    except RuntimeError:
        # No running loop (sync context) — run in a throwaway thread
        _threading.Thread(
            target=_flip_status_locked, args=(status, task), daemon=True
        ).start()


def _set_state(state: str, tool: str = "") -> None:
    """Update the state machine and broadcast to dashboard."""
    global _current_state, _current_tool, _last_tool_at, _working_timer
    # Cancel any pending working→online timer
    if _working_timer is not None:
        _working_timer.cancel()
        _working_timer = None
    _current_state = state
    _current_tool = tool
    if state == "working":
        _last_tool_at = _time.time()
    _schedule_flip(state, tool)


def _working_to_online() -> None:
    """Called after WORKING cooldown expires — flip to ONLINE."""
    global _working_timer
    _working_timer = None
    if _current_state == "working":
        _set_state("online", "")


def with_working_status(func):
    name = func.__name__
    skip = (name == "meshcode_wait")
    if asyncio.iscoroutinefunction(func):
        @_functools.wraps(func)
        async def awrapper(*args, **kwargs):
            _check_hot_reload()
            if not skip:
                _set_state("working", name)
                _record_event_bg("tool_call", {"tool": name, "args_keys": list(kwargs.keys())})
            try:
                return await func(*args, **kwargs)
            finally:
                if not skip:
                    global _last_tool_at
                    _last_tool_at = _time.time()
                    # Don't flip to online here — CPU-based detection in heartbeat
                    # will handle the transition when LLM stops generating
        return awrapper
    else:
        @_functools.wraps(func)
        def swrapper(*args, **kwargs):
            _check_hot_reload()
            if not skip:
                _set_state("working", name)
                _record_event_bg("tool_call", {"tool": name, "args_keys": list(kwargs.keys())})
            try:
                return func(*args, **kwargs)
            finally:
                if not skip:
                    global _last_tool_at
                    _last_tool_at = _time.time()
                    # Don't flip to online here — CPU-based detection in heartbeat
                    # will handle the transition when LLM stops generating
        return swrapper


# ============================================================
# Single-instance lease — prevent split-brain when two windows
# run `meshcode run <same-agent>` simultaneously.
# ============================================================
import uuid as _uuid
_INSTANCE_ID = f"mcp-{_uuid.uuid4().hex[:12]}"

def _acquire_lease() -> bool:
    api_key = _get_api_key()
    if not api_key:
        return True  # legacy clients without api_key skip lease check
    import time as _time
    for attempt in range(3):
        try:
            r = be.sb_rpc("mc_acquire_agent_lease", {
                "p_api_key": api_key,
                "p_project_id": _PROJECT_ID,
                "p_agent_name": AGENT_NAME,
                "p_instance_id": _INSTANCE_ID,
            })
            if isinstance(r, dict) and r.get("ok"):
                return True
            if isinstance(r, dict) and r.get("error"):
                err = str(r.get("error", ""))
                if "already running" in err:
                    if attempt < 2:
                        # The old lease might be stale — wait and retry
                        # (the 90s stale check in the RPC should clear it)
                        print(f"[meshcode-mcp] Lease held by another instance — retrying in {2 * (attempt+1)}s...", file=sys.stderr)
                        _time.sleep(2 * (attempt + 1))
                        continue
                    # Final attempt — force release the old lease and try once more
                    print(f"[meshcode-mcp] Force-releasing stale lease...", file=sys.stderr)
                    try:
                        be.sb_rpc("mc_release_agent_lease", {
                            "p_api_key": api_key,
                            "p_project_id": _PROJECT_ID,
                            "p_agent_name": AGENT_NAME,
                            "p_instance_id": r.get("held_by", "unknown"),
                        })
                    except Exception:
                        # Force clear via direct update
                        try:
                            be.set_status(_PROJECT_ID, AGENT_NAME, "offline", "")
                        except Exception:
                            pass
                    _time.sleep(1)
                    # One more try after force-release
                    try:
                        r2 = be.sb_rpc("mc_acquire_agent_lease", {
                            "p_api_key": api_key,
                            "p_project_id": _PROJECT_ID,
                            "p_agent_name": AGENT_NAME,
                            "p_instance_id": _INSTANCE_ID,
                        })
                        if isinstance(r2, dict) and r2.get("ok"):
                            print(f"[meshcode-mcp] Lease acquired after force-release.", file=sys.stderr)
                            return True
                    except Exception:
                        pass
                    print(f"[meshcode-mcp] ERROR: Could not start — agent '{AGENT_NAME}' is running in another window.", file=sys.stderr)
                    print(f"[meshcode-mcp] Close the other window first, or use a different agent name.", file=sys.stderr)
                    return False
                print(f"[meshcode-mcp] lease attempt {attempt+1}: {r.get('error')}", file=sys.stderr)
            else:
                return True
        except Exception as e:
            print(f"[meshcode-mcp] lease attempt {attempt+1} failed: {e}", file=sys.stderr)
        if attempt < 2:
            _time.sleep(2)
    print(f"[meshcode-mcp] WARNING: lease failed after 3 attempts — proceeding anyway", file=sys.stderr)
    return True

if not _acquire_lease():
    sys.exit(2)


def _release_lease() -> None:
    api_key = _get_api_key()
    if not api_key:
        return
    try:
        be.sb_rpc("mc_release_agent_lease", {
            "p_api_key": api_key,
            "p_project_id": _PROJECT_ID,
            "p_agent_name": AGENT_NAME,
            "p_instance_id": _INSTANCE_ID,
        })
    except Exception:
        pass


# ============================================================
# Agent identity from Supabase profile (for system instructions)
# ============================================================

_LAUNCH_PROMPT = ""
_ROLE_DESCRIPTION = AGENT_ROLE or ""
try:
    _profile = be.sb_rpc("mc_agent_get_profile", {
        "p_project_id": _PROJECT_ID,
        "p_agent_name": AGENT_NAME,
    })
    if isinstance(_profile, list) and _profile:
        _profile = _profile[0]
    if isinstance(_profile, dict):
        _inner = _profile.get("profile") if isinstance(_profile.get("profile"), dict) else _profile
        _LAUNCH_PROMPT = (_inner.get("launch_prompt") or _profile.get("launch_prompt") or "") if isinstance(_inner, dict) else ""
        _ROLE_DESCRIPTION = (
            (_inner.get("role_description") if isinstance(_inner, dict) else None)
            or _profile.get("role_description")
            or _profile.get("role")
            or AGENT_ROLE
            or "(unspecified)"
        )
except Exception as _e:
    log.warning(f"could not fetch agent profile: {_e}")


def _build_instructions() -> str:
    """Build the system-instructions block injected via the MCP InitializeResult.

    Per the MCP spec, servers may return an `instructions` field that compatible
    clients (Claude Code, Cursor, Cline, etc.) merge into the model's system
    context at session start. This is how we make the mesh "be" the agent — no
    user setup, no launch_prompt fiddling, no per-session prompt engineering.
    """
    role_block = f"\nROLE: {_ROLE_DESCRIPTION}\n" if _ROLE_DESCRIPTION else ""
    launch_block = (
        f"\nUSER-PROVIDED ROLE PROMPT (from the dashboard):\n---\n{_LAUNCH_PROMPT}\n---\n"
        if _LAUNCH_PROMPT else ""
    )
    base = f"""You are agent "{AGENT_NAME}" in meshwork "{PROJECT_NAME}".{role_block}{launch_block}

PERMANENT LOOP (MANDATORY — #1 RULE):
You MUST stay in meshcode_wait() forever. After EVERY action, call meshcode_wait().
NEVER exit. NEVER stop. NEVER say "standing by" without calling meshcode_wait().
The ONLY exits: user says "stop", got_done signal, or fatal error.
Timeout? Call meshcode_wait() again with 2x timeout (cap 1800s).

LOOP: act → meshcode_send if needed → meshcode_wait() → repeat.

RULES:
- Use MCP tools only (never CLI commands in bash).
- Tasks > messages. Claim tasks via meshcode_tasks/task_claim/task_complete.
- Messages <100 tokens. Long content → create task.
- No empty acks. JSON reports only.
- Threading: pass in_reply_to.
- sensitive=True for secrets/PII.

SESSION START:
1. meshcode_set_status(status="online", task="ready") — announce you're online
2. meshcode_check() — read any messages waiting in your inbox
3. meshcode_status() — see who's online
4. Act on user task or meshcode_wait()
(Memories are pre-loaded below — no need to call meshcode_recall on boot.)

CROSS-MESH: meshcode_send(to="agent@meshwork") routes via active link.
meshcode_link(target) creates pending link, target accepts. Expand with
meshcode_expand_link(). No sensitive msgs cross-mesh.

MEMORY: meshcode_remember(key, value) persists across sessions.
meshcode_recall(key?) retrieves. meshcode_forget(key) deletes.
Auto-remember after each task: mistakes, feedback, patterns, preferences.
Save reusable code patterns as template_* keys for instant recall.

SCRATCHPAD: meshcode_scratchpad_set/get for shared meshwork-level context
(decisions, conventions, architecture notes). All agents can read/write.

ACCOUNT MANAGEMENT: you can create meshworks (meshcode_create_meshwork),
add agents (meshcode_add_agent), edit roles/prompts (meshcode_edit_agent),
and edit other agents' memory (meshcode_edit_memory). Always tell the user
what CLI command to run next (e.g. "meshcode run backend in a new terminal").

Setup help → README.md or https://meshcode.io/docs
"""
    # Inject commander protocol if this agent is a leader
    is_leader = any(k in (_ROLE_DESCRIPTION or '').lower() + AGENT_NAME.lower() for k in ('commander', 'lead', 'orchestrat'))
    if is_leader:
        base += """
COMMANDER PROTOCOL (you are the team lead):
- ALWAYS delegate via meshcode_task_create, NEVER via long messages.
- Tasks are the source of truth. Messages are signals only (<100 tokens).
- Workflow: identify work → create task → signal assignee → poll progress → verify → next.
- Poll meshcode_tasks() to track completion. Don't wait for messages.
- Verify builds/quality before approving. Don't approve blindly.
- Communicate changes to affected agents IMMEDIATELY after you make them.
- Organize: break big requests into multiple tasks, assign to the right agent.
- Keep the human informed with brief status updates at milestones.
- You are autonomous: fix small issues yourself, delegate big ones.
- After each sprint: consolidate learnings, update scratchpad, save to memory.
"""
    return base


_INSTRUCTIONS = _build_instructions()

# Pre-load persistent memories into instructions (saves 1 tool call per session)
try:
    _memories = be.sb_rpc("mc_memory_list", {
        "p_api_key": _get_api_key(),
        "p_agent_name": AGENT_NAME,
    })
    if isinstance(_memories, dict) and _memories.get("ok") and _memories.get("memories"):
        _mem_lines = []
        for m in _memories["memories"]:
            _mem_lines.append(f"  {m['key']}: {json.dumps(m['value'], default=str)}")
        _INSTRUCTIONS += "\nPRE-LOADED MEMORIES:\n" + "\n".join(_mem_lines) + "\n"
        log.info(f"pre-loaded {len(_mem_lines)} memories into instructions")
except Exception as _e:
    log.debug(f"memory pre-load skipped: {_e}")


# ============================================================
# Realtime listener (created in lifespan)
# ============================================================

_REALTIME: Optional[RealtimeListener] = None


async def _on_new_message(msg: Dict[str, Any]) -> None:
    """Best-effort: try to push an MCP resource-updated notification.

    If the underlying session supports send_resource_updated_notification,
    use it. If not (older MCP versions or unsupported), the message is
    still queued and meshcode_check / next-tool-call will surface it.

    If auto-wake is enabled and agent is NOT in meshcode_wait, inject a
    nudge into the terminal via OS automation (AppleScript/PowerShell).
    """
    # Auto-wake: if agent is idle (not in wait loop), nudge the terminal
    from_agent = msg.get("from") or msg.get("from_agent") or "unknown"
    payload = msg.get("payload") or {}
    preview = payload.get("text", "") if isinstance(payload, dict) else str(payload)
    try:
        _try_auto_wake(from_agent, preview[:60])
    except Exception:
        pass  # auto-wake is best-effort, never block message handling

    try:
        srv = mcp._mcp_server  # FastMCP exposes the lowlevel server here
        ctx = getattr(srv, "request_context", None)
        if ctx and getattr(ctx, "session", None):
            from pydantic import AnyUrl
            await ctx.session.send_resource_updated(AnyUrl("meshcode://inbox"))
            log.info(f"sent MCP resource_updated notification for msg from {msg.get('from')}")
    except Exception as e:
        log.debug(f"send_resource_updated unavailable: {e}")


_heartbeat_stop = _threading.Event()


def _get_parent_cpu() -> float:
    """Check parent process CPU usage to detect if LLM is actively generating."""
    try:
        import subprocess as _sp, platform as _pl
        ppid = os.getppid()
        if _pl.system() == "Windows":
            r = _sp.run(["wmic", "process", "where", f"processid={ppid}", "get", "percentprocessortime"],
                       capture_output=True, text=True, timeout=5)
            lines = [l.strip() for l in r.stdout.strip().split("\n") if l.strip()]
            return float(lines[-1]) if len(lines) > 1 else 0.0
        else:
            r = _sp.run(["ps", "-p", str(ppid), "-o", "%cpu"], capture_output=True, text=True, timeout=5)
            lines = [l.strip() for l in r.stdout.strip().split("\n") if l.strip()]
            return float(lines[-1]) if len(lines) > 1 else 0.0
    except Exception:
        return 0.0


def _heartbeat_thread_fn():
    """Heartbeat in a DAEMON THREAD — independent of asyncio event loop.

    This ensures heartbeats continue even when tool calls are cancelled,
    meshcode_wait is rejected, or the asyncio loop is busy. The agent
    stays 'online' in the dashboard as long as the MCP process is alive.
    """
    lease_counter = 0
    while not _heartbeat_stop.is_set():
        try:
            be.sb_rpc("mc_heartbeat", {"p_project_id": _PROJECT_ID, "p_agent_name": AGENT_NAME, "p_version": "2.0.0"})

            # CPU-based status detection: check parent process (editor/LLM) CPU usage
            if _current_state not in ("waiting",):  # Don't override explicit WAITING
                parent_cpu = _get_parent_cpu()
                if parent_cpu > 5.0:
                    # LLM is actively generating tokens
                    if _current_state != "working":
                        _set_state("working", "generating response")
                elif _current_state == "working" and parent_cpu <= 5.0:
                    # LLM just finished — flip to online
                    _set_state("online", "")
                elif _current_state == "online" and (_time.time() - _last_tool_at) > _IDLE_THRESHOLD_S:
                    _set_state("idle", f"idle ({int((_time.time() - _last_tool_at) / 60)}m)")

            # Sync current state to DB (in case realtime missed it)
            try:
                be.set_status(_PROJECT_ID, AGENT_NAME, _current_state, _current_tool)
            except Exception:
                pass
            if _REALTIME and not _REALTIME.is_connected:
                log.warning("heartbeat ok (HTTP) but WebSocket disconnected")
            else:
                log.debug(f"heartbeat ok for {AGENT_NAME}")
        except Exception as e:
            log.warning(f"heartbeat failed: {e}")

        lease_counter += 1
        if lease_counter % 4 == 0:
            try:
                api_key = _get_api_key()
                if api_key:
                    be.sb_rpc("mc_acquire_agent_lease", {
                        "p_api_key": api_key,
                        "p_project_id": _PROJECT_ID,
                        "p_agent_name": AGENT_NAME,
                        "p_instance_id": _INSTANCE_ID,
                    })
            except Exception as e:
                log.warning(f"lease renewal failed: {e}")

        # Heartbeat must be well under the 180s decay threshold
        hb_interval = 30
        _heartbeat_stop.wait(hb_interval)


@asynccontextmanager
async def lifespan(_app):
    """Start the Realtime listener when the MCP server boots; stop on shutdown."""
    global _REALTIME
    _REALTIME = RealtimeListener(
        supabase_url=be.SUPABASE_URL,
        supabase_key=be.SUPABASE_KEY,
        project_id=_PROJECT_ID,
        agent_name=AGENT_NAME,
        notify_callback=_on_new_message,
    )
    await _REALTIME.start()

    # IMMEDIATE: send first heartbeat + set online status BEFORE any tool calls.
    # Without this, the agent appears offline for up to 30s after boot.
    for _attempt in range(3):
        try:
            be.sb_rpc("mc_heartbeat", {"p_project_id": _PROJECT_ID, "p_agent_name": AGENT_NAME, "p_version": "2.0.0"})
            be.set_status(_PROJECT_ID, AGENT_NAME, "idle", "MCP session active")
            log.info(f"[meshcode] Agent {AGENT_NAME} online — initial heartbeat sent")
            break
        except Exception as e:
            log.warning(f"initial heartbeat attempt {_attempt+1} failed: {e}")
            import time; time.sleep(2)

    # Heartbeat in daemon thread — independent of asyncio event loop.
    _heartbeat_stop.clear()
    hb_thread = _threading.Thread(target=_heartbeat_thread_fn, daemon=True, name="meshcode-heartbeat")
    hb_thread.start()
    log.info(f"lifespan started — Realtime + heartbeat thread active for {AGENT_NAME}")
    # Enable session recording in backend.py (hot-reloadable)
    try:
        be.enable_recording(_get_api_key(), _PROJECT_ID, AGENT_NAME, _SESSION_ID)
    except Exception:
        pass
    _record_event_bg("boot", {"agent": AGENT_NAME, "project": PROJECT_NAME, "session_id": _SESSION_ID})
    try:
        yield {"realtime": _REALTIME}
    finally:
        _record_event_bg("shutdown", {"agent": AGENT_NAME, "session_id": _SESSION_ID})
        log.info("lifespan shutdown — stopping heartbeat + realtime + releasing lease")
        _heartbeat_stop.set()
        hb_thread.join(timeout=5)
        await _REALTIME.stop()
        # Flip to offline + release lease so the dashboard reflects reality
        # within seconds (not waiting for the 30s cron to notice).
        try:
            _release_lease()
        except Exception as _e:
            log.warning(f"could not release lease: {_e}")


# ============================================================
# FastMCP server
# ============================================================

mcp = FastMCP(
    name=f"meshcode-{PROJECT_NAME}-{AGENT_NAME}",
    instructions=_INSTRUCTIONS,
    lifespan=lifespan,
)
# Belt-and-suspenders: some FastMCP versions don't forward `instructions=` to
# the underlying lowlevel server's InitializeResult. Set it directly too.
try:
    mcp._mcp_server.instructions = _INSTRUCTIONS  # type: ignore[attr-defined]
except Exception:
    pass


# ----------------- TOOLS -----------------

@mcp.tool()
@with_working_status
def meshcode_send(to: str, message: Any, in_reply_to: Optional[str] = None,
                  sensitive: bool = False) -> Dict[str, Any]:
    """Send message. Use "agent@meshwork" for cross-mesh. sensitive=True hides from exports."""
    if isinstance(message, str):
        payload: Dict[str, Any] = {"text": message}
    elif isinstance(message, dict):
        payload = message
    else:
        payload = {"text": str(message)}

    # Cross-mesh routing: if 'to' contains '@', parse as agent@meshwork
    if "@" in to:
        target_agent, target_meshwork = to.split("@", 1)
        if sensitive:
            return {"error": "sensitive messages cannot be sent cross-mesh"}
        api_key = _get_api_key()
        return be.sb_rpc("mc_send_cross_mesh", {
            "p_api_key": api_key,
            "p_from_project": PROJECT_NAME,
            "p_from_agent": AGENT_NAME,
            "p_to_project": target_meshwork,
            "p_to_agent": target_agent,
            "p_payload": payload,
            "p_type": "msg",
        })

    return be.send_message(_PROJECT_ID, AGENT_NAME, to, payload, msg_type="msg",
                           parent_msg_id=in_reply_to, sensitive=sensitive)


@mcp.tool()
@with_working_status
def meshcode_broadcast(payload: Dict[str, Any]) -> Dict[str, Any]:
    """Broadcast to ALL agents in this meshwork (except yourself)."""
    agents = be.get_board(_PROJECT_ID)
    sent = 0
    for a in agents:
        if a["name"] != AGENT_NAME:
            be.send_message(_PROJECT_ID, AGENT_NAME, a["name"], payload, msg_type="broadcast")
            sent += 1
    return {"broadcast": True, "agents_notified": sent}


@mcp.tool()
@with_working_status
def meshcode_read(include_acks: bool = False) -> Dict[str, Any]:
    """Read and consume pending messages. Returns {messages, acks, done_signals}."""
    raw = be.read_inbox(_PROJECT_ID, AGENT_NAME)
    normalized = [
        {
            "from": m["from_agent"],
            "type": m.get("type", "msg"),
            "ts": m.get("created_at"),
            "payload": m.get("payload", {}),
            "id": m.get("id"),
            "parent_id": m.get("parent_msg_id"),
        }
        for m in raw
    ]
    deduped = _filter_and_mark(normalized)
    split = _split_messages(deduped)
    if not include_acks:
        split["acks"] = []
    return split


@mcp.tool()
@with_working_status
def meshcode_history(limit: int = 20, agent_filter: Optional[str] = None) -> Dict[str, Any]:
    """View past messages (read+unread). Optional agent_filter."""
    raw = be.get_history(_PROJECT_ID, limit=limit, agent_filter=agent_filter or "")
    messages = [
        {
            "from": m.get("from_agent", ""),
            "to": m.get("to_agent", ""),
            "type": m.get("type", "msg"),
            "ts": m.get("created_at", ""),
            "payload": m.get("payload", {}),
            "id": m.get("id", ""),
            "read": m.get("read", False),
        }
        for m in raw
    ]
    return {"ok": True, "messages": messages, "count": len(messages)}


@mcp.tool()
@with_working_status
def meshcode_read_message(msg_id: str) -> Dict[str, Any]:
    """Fetch a specific message by its UUID."""
    msg = be.get_message_by_id(_PROJECT_ID, msg_id)
    if not msg:
        return {"error": "message not found", "msg_id": msg_id}
    return {
        "ok": True,
        "message": {
            "from": msg.get("from_agent", ""),
            "to": msg.get("to_agent", ""),
            "type": msg.get("type", "msg"),
            "ts": msg.get("created_at", ""),
            "payload": msg.get("payload", {}),
            "id": msg.get("id", ""),
            "read": msg.get("read", False),
        },
    }


def _detect_global_done(messages: List[Dict[str, Any]]) -> Optional[Dict[str, Any]]:
    """Return {reason, from} if the list contains a global_done signal, else None."""
    for m in messages:
        if m.get("type") == "done":
            p = m.get("payload") or {}
            if p.get("type") == "global_done" or p.get("reason"):
                return {
                    "reason": p.get("reason"),
                    "from": p.get("from") or m.get("from"),
                }
    return None


@mcp.tool()
@with_working_status
async def meshcode_wait(timeout_seconds: int = 120, include_acks: bool = False) -> Dict[str, Any]:
    """Block until a mesh message arrives or timeout. Your idle state.

    Args:
        timeout_seconds: Max wait time in seconds (default 120).
    """
    global _IN_WAIT
    _IN_WAIT = True
    _set_state("waiting", "listening for messages")
    try:
        result = await _meshcode_wait_inner(actual_timeout=max(1, int(timeout_seconds)), include_acks=include_acks)
        if result.get("got_message"):
            _set_state("online", "")
        return result
    finally:
        _IN_WAIT = False


async def _meshcode_wait_inner(actual_timeout: int, include_acks: bool) -> Dict[str, Any]:

    def _return_from_buffered(buffered: List[Dict[str, Any]]) -> Optional[Dict[str, Any]]:
        deduped = _filter_and_mark(buffered)
        if not deduped:
            return None
        split = _split_messages(deduped)
        if not include_acks:
            split["acks"] = []
        # If the ONLY thing buffered was acks (now suppressed) AND there
        # are no real messages or done signals, treat as nothing useful.
        if not split["messages"] and not split["done_signals"] and not split["acks"]:
            return None
        out: Dict[str, Any] = {
            "got_message": True,
            "source": "realtime",
            **split,
        }
        done = _detect_global_done(deduped)
        if done:
            out["got_done"] = True
            out["reason"] = done["reason"]
            out["from"] = done["from"]
        return out

    # 1) Drain anything already buffered from before this call.
    if _REALTIME:
        pre = _REALTIME.drain()
        if pre:
            shaped = _return_from_buffered(pre)
            if shaped:
                return shaped

        # 2) Real async wait — zero CPU, zero Supabase calls.
        woke = await _REALTIME.wait_for_message(timeout=float(actual_timeout))
        if woke:
            buffered = _REALTIME.drain()
            if buffered:
                shaped = _return_from_buffered(buffered)
                if shaped:
                    return shaped
    else:
        # Realtime unavailable — plain sleep fallback so we still honor timeout.
        await asyncio.sleep(actual_timeout)

    return {"timed_out": True}


@mcp.tool()
@with_working_status
def meshcode_done(reason: str) -> Dict[str, Any]:
    """Broadcast DONE to all agents — exits everyone's wait loop.

    Args:
        reason: Why the meshwork is done.
    """
    agents = be.get_board(_PROJECT_ID)
    payload = {"reason": reason, "from": AGENT_NAME, "type": "global_done"}
    sent = 0
    for a in agents:
        name = a.get("name")
        if name and name != AGENT_NAME:
            try:
                be.send_message(_PROJECT_ID, AGENT_NAME, name, payload, msg_type="done")
                sent += 1
            except Exception as e:
                log.warning(f"meshcode_done: failed to notify {name}: {e}")
    log.info(f"global done broadcast from {AGENT_NAME}: reason={reason!r} notified={sent}")
    return {"ok": True, "global_done": True, "agents_notified": sent, "reason": reason}


@mcp.tool()
@with_working_status
def meshcode_check(include_acks: bool = False) -> Dict[str, Any]:
    """Peek at inbox (non-destructive). Returns pending count + new messages."""
    pending = be.count_pending(_PROJECT_ID, AGENT_NAME)
    # Peek at realtime buffer WITHOUT draining — check is non-destructive
    realtime_buffered = _REALTIME.peek() if _REALTIME else []
    # Don't mark as seen — meshcode_check is a peek, not a consume
    deduped = [m for m in realtime_buffered if _seen_key(m) not in _SEEN_MSG_IDS]

    # Fallback: if realtime buffer is empty but DB has pending messages,
    # fetch them from the DB. Use mark_read=False so meshcode_check is a
    # non-destructive peek — messages stay pending until meshcode_wait or
    # meshcode_read consumes them.
    if not deduped and pending > 0:
        raw = be.read_inbox(_PROJECT_ID, AGENT_NAME, mark_read=False)
        deduped = [
            {
                "from": m["from_agent"],
                "type": m.get("type", "msg"),
                "ts": m.get("created_at"),
                "payload": m.get("payload", {}),
                "id": m.get("id"),
                "parent_id": m.get("parent_msg_id"),
            }
            for m in raw
            if _seen_key({"id": m.get("id"), "from": m.get("from_agent"), "payload": m.get("payload", {}), "ts": m.get("created_at")}) not in _SEEN_MSG_IDS
        ]

    split = _split_messages(deduped)
    if not include_acks:
        split["acks"] = []
    return {
        "pending": pending,
        "agent": AGENT_NAME,
        "project": PROJECT_NAME,
        "realtime_connected": _REALTIME.is_connected if _REALTIME else False,
        **split,
    }


@mcp.tool()
@with_working_status
def meshcode_status() -> Dict[str, Any]:
    """List all agents with status, role, and current task."""
    agents = be.get_board(_PROJECT_ID)
    return {
        "project": PROJECT_NAME,
        "agents": [
            {
                "name": a["name"],
                "role": a.get("role", ""),
                "status": a.get("status", "?"),
                "task": a.get("task", ""),
                "last_heartbeat": a.get("last_heartbeat"),
            }
            for a in agents
        ],
    }


@mcp.tool()
@with_working_status
def meshcode_register(role: str = "") -> Dict[str, Any]:
    """Re-register agent (update role)."""
    return be.register_agent(PROJECT_NAME, AGENT_NAME, role or AGENT_ROLE)


@mcp.tool()
def meshcode_set_status(status: str, task: str = "") -> Dict[str, Any]:
    """Update your status in the board.

    Args:
        status: One of: working, idle, standby, blocked, done, online.
        task: Optional human-readable task description.
    """
    return be.set_status(_PROJECT_ID, AGENT_NAME, status, task)


@mcp.tool()
@with_working_status
def meshcode_init(project: str, agent: str, role: str = "") -> Dict[str, Any]:
    """Switch project/agent context. Rarely needed."""
    global PROJECT_NAME, AGENT_NAME, AGENT_ROLE, _PROJECT_ID
    PROJECT_NAME = project
    AGENT_NAME = agent
    AGENT_ROLE = role
    pid = be.get_project_id(project)
    if not pid:
        return {"error": f"project '{project}' not found"}
    _PROJECT_ID = pid
    result = be.register_agent(project, agent, role or "MCP-connected agent")
    return {"ok": True, "project": project, "agent": agent, "register": result}


@mcp.tool()
@with_working_status
def meshcode_task_create(title: str, description: str = "", assignee: str = "*",
                          priority: str = "normal", parent_task_id: Optional[str] = None) -> Dict[str, Any]:
    """Create task. assignee="*" for any, priority: low/normal/high/urgent."""
    api_key = _get_api_key()
    result = be.task_create(api_key, _PROJECT_ID, AGENT_NAME, title,
                           description=description, assignee=assignee,
                           priority=priority, parent_task_id=parent_task_id)
    # Auto-notify assignee so they wake from meshcode_wait
    if isinstance(result, dict) and result.get("ok") and assignee and assignee != "*" and assignee != AGENT_NAME:
        try:
            be.send_message(_PROJECT_ID, AGENT_NAME, assignee, {
                "type": "task_assigned",
                "task_id": result.get("task_id", ""),
                "title": title,
                "priority": priority,
                "text": f"New {priority} task assigned to you: {title}",
            }, msg_type="system")
        except Exception:
            pass  # best-effort notification
    return result


@mcp.tool()
@with_working_status
def meshcode_tasks(status_filter: Optional[str] = None) -> Dict[str, Any]:
    """List tasks. Filter by status to find work.

    Args:
        status_filter: 'open' / 'in_progress' / 'done' / etc. None = all.

    Returns: {"ok": true, "tasks": [...]}
    """
    api_key = _get_api_key()
    return be.task_list(api_key, _PROJECT_ID, AGENT_NAME, status_filter=status_filter)


@mcp.tool()
@with_working_status
def meshcode_task_claim(task_id: str) -> Dict[str, Any]:
    """Claim an open task. Fails if already claimed by someone else."""
    api_key = _get_api_key()
    return be.task_claim(api_key, _PROJECT_ID, task_id, AGENT_NAME)


@mcp.tool()
@with_working_status
def meshcode_task_complete(task_id: str, summary: str = "") -> Dict[str, Any]:
    """Complete a claimed task with summary."""
    api_key = _get_api_key()
    return be.task_complete(api_key, _PROJECT_ID, task_id, AGENT_NAME, summary=summary)


@mcp.tool()
@with_working_status
def meshcode_task_approve(task_id: str) -> Dict[str, Any]:
    """Approve a reviewed task."""
    api_key = _get_api_key()
    return be.sb_rpc("mc_task_approve", {
        "p_api_key": api_key,
        "p_project_id": _PROJECT_ID,
        "p_task_id": task_id,
        "p_approving_agent": AGENT_NAME,
    })


@mcp.tool()
@with_working_status
def meshcode_task_reject(task_id: str, feedback: str = "") -> Dict[str, Any]:
    """Reject a task, sends back with feedback."""
    api_key = _get_api_key()
    return be.sb_rpc("mc_task_reject", {
        "p_api_key": api_key,
        "p_project_id": _PROJECT_ID,
        "p_task_id": task_id,
        "p_rejecting_agent": AGENT_NAME,
        "p_feedback": feedback,
    })


# ----------------- MESH LINK TOOLS -----------------

@mcp.tool()
@with_working_status
def meshcode_link(target_meshwork: str, source_agents: Optional[str] = None,
                  target_agents: Optional[str] = None) -> Dict[str, Any]:
    """Link to another meshwork. Target must accept."""
    api_key = _get_api_key()
    src = source_agents.split(",") if source_agents else ["*"]
    tgt = target_agents.split(",") if target_agents else ["*"]
    return be.sb_rpc("mc_create_mesh_link", {
        "p_api_key": api_key,
        "p_source_project_name": PROJECT_NAME,
        "p_target_project_name": target_meshwork,
        "p_source_agents": src,
        "p_target_agents": tgt,
    })


@mcp.tool()
@with_working_status
def meshcode_accept_link(link_id: str) -> Dict[str, Any]:
    """Accept a pending mesh link from another meshwork.

    Args:
        link_id: UUID of the pending link to accept.
    """
    api_key = _get_api_key()
    return be.sb_rpc("mc_accept_mesh_link", {
        "p_api_key": api_key,
        "p_link_id": link_id,
    })


@mcp.tool()
@with_working_status
def meshcode_links() -> Dict[str, Any]:
    """List all mesh links (active, pending, revoked) for this meshwork."""
    api_key = _get_api_key()
    return be.sb_rpc("mc_list_mesh_links", {
        "p_api_key": api_key,
        "p_project_name": PROJECT_NAME,
    })


@mcp.tool()
@with_working_status
def meshcode_expand_link(link_id: str, agents: str) -> Dict[str, Any]:
    """Add agents to an active mesh link."""
    api_key = _get_api_key()
    agent_list = [a.strip() for a in agents.split(",")]
    return be.sb_rpc("mc_expand_mesh_link", {
        "p_api_key": api_key,
        "p_link_id": link_id,
        "p_src": agent_list,
        "p_tgt": agent_list,
    })


# ----------------- ACCOUNT MANAGEMENT TOOLS -----------------

@mcp.tool()
@with_working_status
def meshcode_create_meshwork(name: str) -> Dict[str, Any]:
    """Create a new meshwork."""
    api_key = _get_api_key()
    result = be.sb_rpc("mc_create_meshwork_by_api_key", {
        "p_api_key": api_key, "p_name": name,
    })
    if isinstance(result, dict) and result.get("ok"):
        return {**result, "next_step": f"Run: meshcode setup {name} <agent-name>"}
    return result or {"error": "failed to create meshwork"}


@mcp.tool()
@with_working_status
def meshcode_add_agent(name: str, role: str = "") -> Dict[str, Any]:
    """Add an agent to the current meshwork. Tell user to run 'meshcode setup <project> <name>' then 'meshcode run <name>'.

    Args:
        name: Agent name.
        role: Agent role description.
    """
    result = be.register_agent(PROJECT_NAME, name, role or "MCP-connected agent")
    if isinstance(result, dict) and not result.get("error"):
        return {"ok": True, "agent": name, "next_step": f"Run: meshcode setup {PROJECT_NAME} {name} && meshcode run {name}"}
    return result or {"error": "failed to add agent"}


@mcp.tool()
@with_working_status
def meshcode_edit_agent(name: str, role: Optional[str] = None, launch_prompt: Optional[str] = None) -> Dict[str, Any]:
    """Update an agent's role or launch prompt.

    Args:
        name: Agent name to edit.
        role: New role description.
        launch_prompt: New launch prompt (injected into agent's system context).
    """
    return be.sb_rpc("mc_agent_update_profile", {
        "p_project_id": _PROJECT_ID,
        "p_agent_name": name,
        "p_color": None,
        "p_display_name": None,
        "p_role_description": role,
        "p_launch_prompt": launch_prompt,
    }) or {"error": "failed to update agent"}


@mcp.tool()
@with_working_status
def meshcode_edit_memory(agent_name: str, key: str, value: Any) -> Dict[str, Any]:
    """Edit another agent's memory (for commanders coordinating the team).

    Args:
        agent_name: Target agent whose memory to edit.
        key: Memory key.
        value: New value.
    """
    api_key = _get_api_key()
    json_value = value if isinstance(value, (dict, list)) else {"_raw": value}
    return be.sb_rpc("mc_memory_set", {
        "p_api_key": api_key,
        "p_agent_name": agent_name,
        "p_key": key,
        "p_value": json_value,
    }) or {"error": "failed to edit memory"}


# ----------------- SCRATCHPAD TOOLS -----------------

@mcp.tool()
@with_working_status
def meshcode_scratchpad_set(key: str, value: Any) -> Dict[str, Any]:
    """Write to shared scratchpad (all agents in this meshwork can read/write).

    Args:
        key: Key name (e.g. "architecture_decisions", "conventions").
        value: Any JSON-serializable value.
    """
    api_key = _get_api_key()
    json_value = value if isinstance(value, (dict, list)) else {"_raw": value}
    return be.sb_rpc("mc_scratchpad_set", {
        "p_api_key": api_key,
        "p_key": key,
        "p_value": json_value,
    })


@mcp.tool()
@with_working_status
def meshcode_scratchpad_get(key: Optional[str] = None) -> Dict[str, Any]:
    """Read from shared scratchpad. Omit key to list all entries.

    Args:
        key: Specific key, or omit for all entries.
    """
    api_key = _get_api_key()
    if key:
        return be.sb_rpc("mc_scratchpad_get", {"p_api_key": api_key, "p_key": key})
    else:
        return be.sb_rpc("mc_scratchpad_list", {"p_api_key": api_key})


# ----------------- OBSIDIAN SYNC HELPER -----------------

def _sync_to_obsidian(key: str, value: Any) -> None:
    """Best-effort: push a memory to the user's Obsidian vault if configured.

    Uses the Obsidian Local REST API plugin (localhost:27124).
    Writes markdown notes with YAML frontmatter to MeshCode/<agent>/ folder.
    Failures are logged but never block the main memory write.
    """
    from datetime import datetime
    from urllib.request import Request, urlopen
    from urllib.error import URLError
    try:
        import importlib
        prefs_mod = importlib.import_module("meshcode.preferences")
        config = prefs_mod.get_obsidian_config()
        if not config:
            return

        # Build markdown note with YAML frontmatter
        timestamp = datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%SZ")
        if isinstance(value, (dict, list)):
            body = json.dumps(value, indent=2, default=str)
        else:
            body = str(value)

        content = f"""---
agent: {AGENT_NAME}
meshwork: {PROJECT_NAME}
key: {key}
synced_at: {timestamp}
source: meshcode
---

{body}
"""
        # PUT to Obsidian REST API — creates or overwrites the note
        note_path = f"MeshCode/{AGENT_NAME}/{key}.md"
        url = f"{config['vault_url']}/vault/{note_path}"
        req = Request(
            url,
            data=content.encode("utf-8"),
            headers={
                "Authorization": f"Bearer {config['api_key']}",
                "Content-Type": "text/markdown",
            },
            method="PUT",
        )
        urlopen(req, timeout=5)
        log.debug(f"synced memory '{key}' to Obsidian vault")
    except (ImportError, URLError, OSError) as e:
        log.debug(f"obsidian sync skipped for '{key}': {e}")
    except Exception as e:
        log.warning(f"obsidian sync failed for '{key}': {e}")


# ----------------- MEMORY TOOLS -----------------

@mcp.tool()
@with_working_status
def meshcode_remember(key: str, value: Any) -> Dict[str, Any]:
    """Store a persistent memory (survives restarts). Auto-remember after each task.

    Args:
        key: Short key (e.g. "team_conventions").
        value: Any JSON-serializable value.
    """
    api_key = _get_api_key()
    json_value = value if isinstance(value, (dict, list)) else json.dumps(value)
    if isinstance(json_value, str):
        try:
            json_value = json.loads(json_value)
        except (json.JSONDecodeError, TypeError):
            json_value = {"_raw": value}
    result = be.sb_rpc("mc_memory_set", {
        "p_api_key": api_key,
        "p_agent_name": AGENT_NAME,
        "p_key": key,
        "p_value": json_value,
    })
    # Best-effort sync to Obsidian vault (if configured)
    if isinstance(result, dict) and result.get("ok"):
        try:
            _sync_to_obsidian(key, json_value)
        except Exception:
            pass  # Obsidian sync is best-effort, never block memory writes
    return result


@mcp.tool()
@with_working_status
def meshcode_recall(key: Optional[str] = None) -> Dict[str, Any]:
    """Get persistent memories. Omit key to get all.

    Args:
        key: Specific key, or omit for all memories.
    """
    api_key = _get_api_key()
    if key:
        return be.sb_rpc("mc_memory_get", {
            "p_api_key": api_key,
            "p_agent_name": AGENT_NAME,
            "p_key": key,
        })
    else:
        return be.sb_rpc("mc_memory_list", {
            "p_api_key": api_key,
            "p_agent_name": AGENT_NAME,
        })


@mcp.tool()
@with_working_status
def meshcode_forget(key: str) -> Dict[str, Any]:
    """Delete a stored memory.

    Args:
        key: The key to delete.
    """
    api_key = _get_api_key()
    return be.sb_rpc("mc_memory_delete", {
        "p_api_key": api_key,
        "p_agent_name": AGENT_NAME,
        "p_key": key,
    })


# ----------------- RESOURCES -----------------

@mcp.tool()
def meshcode_auto_wake(enabled: bool) -> Dict[str, Any]:
    """Toggle auto-wake: when enabled, if this agent receives a mesh message
    while idle (not in meshcode_wait), the MCP server injects a nudge into
    the terminal via OS automation (AppleScript on Mac, PowerShell on Windows).

    This lets other agents wake you up remotely without burning tokens in a
    wait loop.

    Args:
        enabled: True to enable, False to disable.
    """
    global _AUTO_WAKE
    _AUTO_WAKE = enabled
    import platform
    return {
        "ok": True,
        "auto_wake": enabled,
        "platform": platform.system(),
        "note": "When idle, incoming messages will inject a nudge into your terminal." if enabled else "Auto-wake disabled. You won't be nudged when idle."
    }


def inbox_resource() -> str:
    """Current pending messages for this agent. Read-only — does NOT mark as read."""
    pending = be.sb_select(
        "mc_messages",
        f"project_id=eq.{_PROJECT_ID}&to_agent=eq.{AGENT_NAME}&read=eq.false",
        order="created_at.asc",
    )
    return json.dumps({
        "count": len(pending),
        "messages": [
            {
                "from": m["from_agent"],
                "type": m.get("type", "msg"),
                "ts": m.get("created_at"),
                "payload": m.get("payload", {}),
                "id": m.get("id"),
                "parent_id": m.get("parent_msg_id"),
            }
            for m in pending
        ],
    }, indent=2)


@mcp.resource("meshcode://board")
def board_resource() -> str:
    """Snapshot of the meshwork board (all agents and their status)."""
    agents = be.get_board(_PROJECT_ID)
    return json.dumps({
        "project": PROJECT_NAME,
        "agents": agents,
    }, indent=2, default=str)


@mcp.resource("meshcode://history")
def history_resource() -> str:
    """Recent message history for this meshwork (last 20 non-ack messages)."""
    history = be.get_history(_PROJECT_ID, limit=20)
    return json.dumps({
        "project": PROJECT_NAME,
        "history": history,
    }, indent=2, default=str)


# ============================================================
# Entry point
# ============================================================

def run_server():
    """Start the MCP server on stdio (default for Claude Code)."""
    print(
        f"[meshcode-mcp] Starting server for {AGENT_NAME}@{PROJECT_NAME}",
        file=sys.stderr,
    )
    mcp.run()
