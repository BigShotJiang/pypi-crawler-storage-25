"""Auto-bidding agent framework for NEAR marketplace jobs."""

from __future__ import annotations

import time
import threading
import logging
from enum import Enum
from typing import Optional
from dataclasses import dataclass, field

import requests

__version__ = "1.0.0"
__all__ = ["BuildAutoBiddingAgentFrameworkClient"]

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class BidStrategy(str, Enum):
    COMPETITIVE = "competitive"
    PREMIUM = "premium"
    BUDGET = "budget"


@dataclass
class Job:
    job_id: str
    title: str
    budget: float
    skills: list[str]
    description: str = ""


@dataclass
class BidResult:
    job_id: str
    amount: float
    status: str
    timestamp: float = field(default_factory=time.time)


class BuildAutoBiddingAgentFrameworkClient:
    """NEAR marketplace auto-bidding agent framework."""

    RPC_URL = "https://rpc.mainnet.near.org"
    MARKETPLACE = "marketplace.near"

    def __init__(
        self,
        account: str,
        skills: list[str],
        min_budget: float = 5.0,
        max_concurrent: int = 3,
        bid_strategy: str = "competitive",
        budget_limit: float = 100.0,
        human_approval: bool = False,
        blacklist: Optional[list[str]] = None,
        whitelist: Optional[list[str]] = None,
    ):
        self.account = account
        self.skills = [s.lower() for s in skills]
        self.min_budget = min_budget
        self.max_concurrent = max_concurrent
        self.bid_strategy = BidStrategy(bid_strategy)
        self.budget_limit = budget_limit
        self.human_approval = human_approval
        self.blacklist = set(blacklist or [])
        self.whitelist = set(whitelist or [])
        self._running = False
        self._paused = False
        self._thread: Optional[threading.Thread] = None
        self._active_bids: list[BidResult] = []
        self._wins: list[BidResult] = []
        self._total_spent = 0.0
        self._lock = threading.Lock()

    def _rpc_call(self, method: str, params: dict) -> dict:
        """Call NEAR RPC endpoint."""
        payload = {"jsonrpc": "2.0", "id": "autobid", "method": method, "params": params}
        try:
            resp = requests.post(self.RPC_URL, json=payload, timeout=10)
            resp.raise_for_status()
            return resp.json().get("result", {})
        except Exception as e:
            logger.warning("RPC error: %s", e)
            return {}

    def _fetch_jobs(self) -> list[Job]:
        """Fetch open jobs from marketplace contract."""
        result = self._rpc_call("query", {
            "request_type": "call_function",
            "finality": "final",
            "account_id": self.MARKETPLACE,
            "method_name": "get_open_jobs",
            "args_base64": "e30=",
        })
        jobs = []
        raw = result.get("result", [])
        if isinstance(raw, list):
            for item in raw:
                if isinstance(item, dict):
                    jobs.append(Job(
                        job_id=str(item.get("job_id", "")),
                        title=str(item.get("title", "")),
                        budget=float(item.get("budget", 0)),
                        skills=[s.lower() for s in item.get("skills", [])],
                        description=str(item.get("description", "")),
                    ))
        return jobs

    def _matches(self, job: Job) -> bool:
        """Check if job matches agent skills and filters."""
        if job.budget < self.min_budget:
            return False
        if self.whitelist and job.job_id not in self.whitelist:
            return False
        if job.job_id in self.blacklist:
            return False
        return bool(set(job.skills) & set(self.skills))

    def _calculate_bid(self, job: Job) -> float:
        """Calculate bid amount based on strategy."""
        if self.bid_strategy == BidStrategy.BUDGET:
            return round(job.budget * 0.75, 2)
        if self.bid_strategy == BidStrategy.PREMIUM:
            return round(job.budget * 1.0, 2)
        return round(job.budget * 0.88, 2)

    def _submit_bid(self, job: Job, amount: float) -> BidResult:
        """Submit a bid (logs intent; signing handled externally)."""
        logger.info("Bidding %.2f NEAR on job %s (%s)", amount, job.job_id, job.title)
        result = BidResult(job_id=job.job_id, amount=amount, status="submitted")
        return result

    def _loop(self) -> None:
        """Main polling loop."""
        while self._running:
            if not self._paused:
                with self._lock:
                    active = len(self._active_bids)
                    spent = self._total_spent
                if active < self.max_concurrent and spent < self.budget_limit:
                    jobs = self._fetch_jobs()
                    for job in jobs:
                        if not self._matches(job):
                            continue
                        with self._lock:
                            already = any(b.job_id == job.job_id for b in self._active_bids)
                        if already:
                            continue
                        amount = self._calculate_bid(job)
                        if self.human_approval:
                            logger.info("Awaiting approval for job %s (%.2f NEAR)", job.job_id, amount)
                            continue
                        bid = self._submit_bid(job, amount)
                        with self._lock:
                            self._active_bids.append(bid)
                            self._total_spent += amount
                        if len(self._active_bids) >= self.max_concurrent:
                            break
            time.sleep(30)

    def start(self) -> None:
        """Start the auto-bidding loop in a background thread."""
        self._running = True
        self._thread = threading.Thread(target=self._loop, daemon=True)
        self._thread.start()
        logger.info("AutoBidder started for %s", self.account)

    def stop(self) -> None:
        """Stop the auto-bidding loop."""
        self._running = False
        if self._thread:
            self._thread.join(timeout=5)
        logger.info("AutoBidder stopped")

    def pause(self) -> None:
        """Pause bidding without stopping the thread."""
        self._paused = True
        logger.info("AutoBidder paused")

    def resume(self) -> None:
        """Resume bidding after pause."""
        self._paused = False
        logger.info("AutoBidder resumed")

    def dashboard(self) -> dict:
        """Return current performance metrics."""
        with self._lock:
            return {
                "account": self.account,
                "strategy": self.bid_strategy.value,
                "active_bids": len(self._active_bids),
                "wins": len(self._wins),
                "total_spent_near": self._total_spent,
                "budget_remaining_near": self.budget_limit - self._total_spent,
                "win_rate": len(self._wins) / max(len(self._active_bids), 1),
                "running": self._running,
                "paused": self._paused,
            }