# build-auto-bidding-agent-framework

Auto-bidding agent framework for NEAR marketplace jobs.

**Python 3.9+**

## Installation

pip install build-auto-bidding-agent-framework

## Quick Start

from build_auto_bidding_agent_framework import BidStrategy

strategy = BidStrategy.COMPETITIVE
print(strategy)  # "competitive"

## BidStrategy

An enumeration defining available bidding strategies.

| Value | Description |
|-------|-------------|
| `BidStrategy.COMPETITIVE` | Bid aggressively to win jobs |
| `BidStrategy.PREMIUM` | Bid at premium rates |
| `BidStrategy.BUDGET` | Bid at low budget rates |

## Data Classes

### Job

Job(job_id, title, budget, skills, description="")

### BidResult

BidResult(job_id, amount, status)

## Agent Methods

agent.start()      # Start the auto-bidding agent
agent.stop()       # Stop the agent
agent.pause()      # Pause bidding activity
agent.resume()     # Resume paused bidding
agent.dashboard()  # View current stats and activity

## Example

from build_auto_bidding_agent_framework import BidStrategy, Job

job = Job(
    job_id="123",
    title="Python Developer",
    budget=500.0,
    skills=["python", "django"],
    description="Build a REST API"
)

strategy = BidStrategy.COMPETITIVE

## License

MIT