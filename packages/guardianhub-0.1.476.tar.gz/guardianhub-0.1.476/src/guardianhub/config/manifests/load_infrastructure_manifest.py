import json
import importlib.resources


def load_infrastructure_manifest() -> list:
    """
    Dynamically loads the Infrastructure_keys_manifest.json file
    from within the SDK package resources.
    """
    # Explicit package string ensures it always finds the sibling JSON file
    ref = importlib.resources.files("guardianhub.config.manifests") / "Infrastructure_keys_manifest.json"

    with ref.open("r", encoding="utf-8") as f:
        return json.load(f)