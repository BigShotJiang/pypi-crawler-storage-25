# guardianhub/config/manifests/__init__.py
from .load_infrastructure_manifest import load_infrastructure_manifest

__all__ = ["load_infrastructure_manifest"]