import httpx
import hvac
from typing import Any, Dict
import json
from pathlib import Path


from guardianhub import get_logger
from guardianhub.clients.langfuse.manager import LangfuseManager
from guardianhub.config.settings import CoreSettings
from guardianhub.config.settings import settings
from guardianhub import DEFAULT_SYSTEM_TENANT_ID



logger = get_logger(__name__)


def mask_secrets(data: dict) -> dict:
    """Mask sensitive values for logging. Shows full keys, masks values."""
    if not data:
        return {}
    return {key: "***MASKED***" for key in data.keys()}


class VaultManager:
    def __init__(self):
        self.client = httpx.Client(
            base_url=settings.endpoints.VAULT_MANAGER_URL,
            timeout=120.0
        )
        # Get the directory where vault_manager.py is located
        current_dir = Path(__file__).parent.resolve()

        # Build the absolute path to the manifest file
        # This points to: .../guardianhub/config/manifests/Infrastructure_keys_manifest.json
        self.manifest_path = current_dir / "manifests" / "Infrastructure_keys_manifest.json"

        # Optional: Safety check to ensure the file exists at startup
        if not self.manifest_path.exists():
            logger.error(f"❌ Infrastructure manifest not found at: {self.manifest_path}")

    async def fetch_tenant_secrets(self, tenant_id: str) -> Dict[str, Dict[str, Any]]:
        """
        Fetches secrets from Vault mapped by service name as defined in the manifest.
        Prevents key collisions (e.g., DB_HOST) by nesting them under service keys.
        """
        try:
            logger.info(f"Fetching secrets from Vault mapped by service name: {tenant_id}")
            vault_url = settings.vault.url
            vault_token = settings.vault.token

            if not vault_token:
                logger.warning("⚠️ No Vault token found")
                return {}

            client = hvac.Client(url=vault_url, token=vault_token)

            # Load the manifest structure
            with open(self.manifest_path, 'r') as f:
                manifest = json.load(f)

            structured_secrets = {}
            namespace = "yantramops/tenants"

            # Iterate through the manifest blocks (yantram, core, llm, etc.)
            for category_block in manifest:
                for category, services in category_block.items():
                    for service_config in services:
                        service_name = service_config["service"]
                        # Remove leading slash and construct path
                        vault_sub_path = service_config["vault_path"].lstrip('/')

                        tenant_path = f"{namespace}/{tenant_id}/{vault_sub_path}"
                        system_path = f"{namespace}/system/{vault_sub_path}"

                        # Attempt to read from Tenant path, fallback to System path
                        service_data = self._read_vault_with_fallback(client, tenant_path, system_path)

                        if service_data:
                            # Filter data based on required_keys in manifest to ensure clean response
                            required_keys = service_config.get("required_keys", [])
                            filtered_data = {
                                k: service_data[k] for k in required_keys
                                if k in service_data and service_data[k] not in ["default_value", "placeholder", ""]
                            }

                            if filtered_data:
                                structured_secrets[service_name] = filtered_data
                                logger.info(f"✅ Loaded {len(filtered_data)} keys for service: {service_name}")
                                logger.info(f"   🔑 Keys fetched: {list(filtered_data.keys())}")
                                logger.debug(f"   🔍 Data (masked): {filtered_data}")

            return structured_secrets

        except Exception as e:
            logger.error(f"❌ Failed to fetch structured tenant secrets: {e}")
            return {}

    def _read_vault_with_fallback(self, client, tenant_path: str, system_path: str):
        """Helper to try tenant path then system path"""
        try:
            res = client.secrets.kv.v2.read_secret_version(path=tenant_path)
            return res['data']['data']
        except Exception:
            try:
                res = client.secrets.kv.v2.read_secret_version(path=system_path)
                return res['data']['data']
            except Exception:
                return None

    def populate_session_tenant(self, structured_secrets: dict):
        """
        Injects structured secrets into settings by service identity.
        """
        if not structured_secrets:
            logger.warning("[VaultManager] No secrets to populate.")
            return

        try:
            logger.info("📋 Starting tenant session hydration with structured_secrets keys: " + str(list(structured_secrets.keys())))
            
            # Logic to sync service-specific URLs
            for service_block in ["yantram_core", "yantram_agents", "yantram_external"]:
                if service_block in structured_secrets:
                    logger.info(f"🔧 Processing service block: {service_block}")
                    logger.info(f"   Keys: {list(structured_secrets[service_block].keys())}")
                    for key, value in structured_secrets[service_block].items():
                        # Check if endpoint already exists in settings
                        if hasattr(settings.endpoints, key):
                            setattr(settings.endpoints, key, value)
                            logger.info(f"   ✅ Updated existing endpoint {key} = {value}")
                        else:
                            # Dynamically add missing endpoint
                            setattr(settings.endpoints, key, value)
                            logger.info(f"   ➕ Added new endpoint {key} = {value}")

            # 1. CORE DATABASE MAPPING
            # Mapping Postgres to the unified POSTGRES_URL
            if "postgres_cred" in structured_secrets:
                pg = structured_secrets["postgres_cred"]
                logger.info(f"🗄️ Processing postgres_cred with keys: {list(pg.keys())}")
                logger.debug(f"   Data (masked): {mask_secrets(pg)}")
                pg_url = (
                    f"postgresql+asyncpg://{pg.get('DB_USERNAME')}:"
                    f"{pg.get('DB_PASSWORD')}@"
                    f"{pg.get('DB_HOST')}:{pg.get('DB_PORT')}/"
                    f"{pg.get('MASTER_TENANT_DB')}"
                )
                settings.endpoints.POSTGRES_URL = pg_url
                logger.info("✅ Postgres URL reconstructed and updated.")

            # Mapping Neo4j (using its specific service block host/URL)
            if "neo4j" in structured_secrets:
                neo = structured_secrets["neo4j"]
                logger.info(f"🕸️ Processing neo4j with keys: {list(neo.keys())}")
                logger.debug(f"   Data (masked): {mask_secrets(neo)}")
                graph_db_url = neo.get("GRAPH_DB_URL") or neo.get("DB_HOST")
                settings.endpoints.GRAPH_DB_URL = graph_db_url
                logger.info(f"✅ Neo4j Endpoint updated: {graph_db_url}")

            # 2. VECTOR (ChromaDB) MAPPING
            if "chromadb" in structured_secrets:
                chroma = structured_secrets["chromadb"]
                logger.info(f"🔍 Processing chromadb with keys: {list(chroma.keys())}")
                logger.debug(f"   Data (masked): {mask_secrets(chroma)}")
                vector_service_url = chroma.get("VECTOR_SERVICE_URL")
                settings.endpoints.VECTOR_SERVICE_URL = vector_service_url
                logger.info(f"   ✅ VECTOR_SERVICE_URL = {vector_service_url}")

                for key, value in chroma.items():
                    attr_name = key.lower()
                    if hasattr(settings.vector, attr_name):
                        # FIX: Handle string-to-list conversion for collections
                        if attr_name == "additional_collections" and isinstance(value, str):
                            try:
                                # Try parsing as JSON list first
                                parsed_value = json.loads(value)
                                if isinstance(parsed_value, list):
                                    value = parsed_value
                                else:
                                    # Fallback: comma separated string
                                    value = [v.strip() for v in value.split(",")]
                            except json.JSONDecodeError:
                                # Fallback: comma separated string
                                value = [v.strip() for v in value.split(",")]

                        setattr(settings.vector, attr_name, value)
                        logger.info(f"   ✅ Updated vector.{attr_name} = {value}")

            # 3. OBSERVABILITY (Langfuse)
            if "langfuse" in structured_secrets:
                lf = structured_secrets["langfuse"]
                logger.info(f"📊 Processing langfuse with keys: {list(lf.keys())}")
                logger.debug(f"   Data (masked): {mask_secrets(lf)}")
                langfuse_host = lf.get("LANGFUSE_HOST")
                settings.endpoints.LANGFUSE_HOST = langfuse_host
                logger.info(f"   ✅ LANGFUSE_HOST = {langfuse_host}")
                # Populate credentials for SDK access
                langfuse_public_key = lf.get("LANGFUSE_PUBLIC_KEY")
                langfuse_secret_key = lf.get("LANGFUSE_SECRET_KEY")
                langfuse_project_id = lf.get("LANGFUSE_PROJECT_ID")
                settings.credentials.LANGFUSE_PUBLIC_KEY = langfuse_public_key
                settings.credentials.LANGFUSE_SECRET_KEY = langfuse_secret_key
                settings.credentials.LANGFUSE_PROJECT_ID = langfuse_project_id
                logger.info(f"   ✅ LANGFUSE_PUBLIC_KEY = {langfuse_public_key}")
                logger.info(f"   ✅ LANGFUSE_SECRET_KEY = ***MASKED***")
                logger.info(f"   ✅ LANGFUSE_PROJECT_ID = {langfuse_project_id}")

            # 4. LLM CONFIGURATION (Dynamic Registry)
            # Check for common LLM service names in the response
            for provider in ["aura", "openai", "gemini", "deepseek"]:
                if provider in structured_secrets:
                    llm_data = structured_secrets[provider]
                    logger.info(f"🤖 Processing LLM provider: {provider}")
                    logger.info(f"   Keys: {list(llm_data.keys())}")
                    logger.debug(f"   Data (masked): {mask_secrets(llm_data)}")
                    # Update the LLM model_configs dict in settings
                    config = {
                        "model_name": llm_data.get("LLM_MODEL_NAME"),
                        "api_key": llm_data.get("LLM_API_KEY"),
                        "base_url": llm_data.get("LLM_BASE_URL") or llm_data.get("LLM_URL"),
                        "provider": provider.upper()
                    }

                    # Use standard Pydantic update if available, or manual dict update
                    settings.llm.model_configs[provider] = config
                    logger.info(f"   ✅ LLM config updated for {provider.upper()}")
                    logger.info(f"      model_name: {config['model_name']}")
                    logger.info(f"      base_url: {config['base_url']}")
                    logger.info(f"      api_key: ***MASKED***")

            # Mapping Neo4j (using its specific service block host/URL)
            if "temporal" in structured_secrets:
                temporal = structured_secrets["temporal"]
                logger.info(f"🕸️ Processing temporal with keys: {list(temporal.keys())}")
                logger.debug(f"   Data (masked): {mask_secrets(temporal)}")
                temporal_host_url = temporal.get("TEMPORAL_HOST_URL")
                settings.endpoints.TEMPORAL_HOST_URL = temporal_host_url
                logger.info(f"✅ Temporal Endpoint updated: {temporal_host_url}")

            # 5. LEGACY FLAT ACCESS (Optional)
            # If any part of the app still expects GH_CREDENTIALS.DB_HOST,
            # we can flatten everything into the credentials object as a fallback.
            logger.info("📜 Processing legacy flat access for credentials...")
            for service, keys in structured_secrets.items():
                # Skip if keys is not a dictionary (e.g., string or other type)
                if not isinstance(keys, dict):
                    logger.warning(f"   ⚠️ Skipping {service} - expected dict, got {type(keys).__name__}")
                    continue
                logger.debug(f"   Service: {service}, Keys: {list(keys.keys())}")
                for key, value in keys.items():
                    setattr(settings.credentials, key.upper(), value)
                    logger.debug(f"   ✅ Set credentials.{key.upper()} = {value if 'SECRET' not in key.upper() and 'PASSWORD' not in key.upper() and 'TOKEN' not in key.upper() and 'KEY' not in key.upper() else '***MASKED***'}")

            # --- FINALIZATION ---
            # Reset managers to pick up new configurations
            LangfuseManager.reset()

            # Build a summary of updated endpoints for verification
            # We filter for uppercase keys (standard for endpoints) or all public attributes
            current_endpoints = {
                k: v for k, v in settings.endpoints.__dict__.items()
                if not k.startswith("_")
            }

            logger.info("📡 [Final Endpoint Configuration]")
            for endpoint, url in current_endpoints.items():
                logger.info(f"   🔗 {endpoint:<30} -> {url}")

            logger.info(f"🚀 Tenant session hydration complete for service blocks: {list(structured_secrets.keys())}")
            logger.info(f"🚀 Tenant session hydration complete for service blocks: {list(structured_secrets.keys())}")

        except Exception as e:
            logger.error(f"❌ Failed to update settings from structured secrets: {e}", exc_info=True)

    async def sync_tenant_session(self, tenant_id: str) -> None:
        """
        Dynamically fetches secrets from Vault and hydrates the global settings object
        using the structural metadata defined explicitly within the infrastructure manifest.

        No hardcoded service logic or if/else checks.
        """
        try:
            logger.info(f"🔄 Starting atomic sync and configuration hydration for tenant: {tenant_id}")
            vault_url = settings.vault.url
            vault_token = settings.vault.token

            if not vault_token:
                logger.warning("⚠️ No Vault token found. Aborting session sync.")
                return

            client = hvac.Client(url=vault_url, token=vault_token)

            with open(self.manifest_path, 'r') as f:
                manifest = json.load(f)

            namespace = "yantramops/tenants"

            # Traverse the generic list-of-dicts structure of the manifest
            for category_block in manifest:
                for category, services in category_block.items():
                    for service_config in services:
                        service_name = service_config["service"]
                        vault_sub_path = service_config["vault_path"].lstrip('/')

                        tenant_path = f"{namespace}/{tenant_id}/{vault_sub_path}"
                        system_path = f"{namespace}/system/{vault_sub_path}"

                        # Read from Vault with fallback
                        service_data = self._read_vault_with_fallback(client, tenant_path, system_path)
                        if not service_data:
                            continue

                        # --- Dynamic Mapping Rules ---

                        # 1. Update Endpoint Specific Keys
                        for url_key in service_config.get("required_urls", []):
                            if url_key in service_data:
                                val = service_data[url_key]
                                setattr(settings.endpoints, url_key, val)
                                logger.info(f"   🔗 [Endpoint] {url_key} -> {val}")

                        # 2. Update Credential Specific Keys
                        for cred_key in service_config.get("required_cred_keys", []):
                            if cred_key in service_data:
                                setattr(settings.credentials, cred_key, service_data[cred_key])
                                logger.info(f"   🔑 [Credential] {cred_key} -> ***MASKED***")

                        # 3. Dynamic Path Resolution and Property Injection
                        settings_path = service_config.get("settings_path")
                        required_keys = service_config.get("required_keys", [])
                        logger.info(f"Settings Path: {settings_path}, Required Keys: {required_keys}, for Service - {service_name}")

                        if settings_path and required_keys:
                            # Safely resolve target object nested within your settings configuration
                            target_obj = self._resolve_settings_target(settings, settings_path)

                            if target_obj is not None:
                                logger.info(f"   ⚙️ Hydrating target path: settings.{settings_path}")
                                for key in required_keys:
                                    if key in service_data:
                                        val = service_data[key]

                                        # Clean array string notations if applicable (e.g. comma separated strings to arrays)
                                        cleaned_val = self._sanitize_value(key, val)

                                        # Determine attribute target naming convention (handles objects or dicts gracefully)
                                        self._set_dynamic_attribute(target_obj, key.lower(), cleaned_val)

            # --- Finalization & Reset Hook ---
            LangfuseManager.reset()
            logger.info(f"🚀 Dynamic hydration complete for tenant context: {tenant_id}")

        except Exception as e:
            logger.error(f"❌ Failed to dynamically process configurations: {e}", exc_info=True)

    def _read_vault_with_fallback(self, client, tenant_path: str, system_path: str):
        """Helper to try tenant path then system path"""
        try:
            res = client.secrets.kv.v2.read_secret_version(path=tenant_path)
            return res['data']['data']
        except Exception:
            try:
                res = client.secrets.kv.v2.read_secret_version(path=system_path)
                return res['data']['data']
            except Exception:
                return None

    def _resolve_settings_target(self, root_obj: Any, path_str: str) -> Any:
        """
        Dynamically navigates a dot-separated string representation of an object graph.
        Supports dictionary key lookups and object attributes.
        """
        try:
            current = root_obj
            for part in path_str.split('.'):
                if isinstance(current, dict):
                    current = current[part]
                else:
                    current = getattr(current, part)
            return current
        except Exception as e:
            logger.error(f"⚠️ Could not resolve target path 'settings.{path_str}': {e}")
            return None


    def _set_dynamic_attribute(self, target: Any, key: str, value: Any) -> None:
        attr_name = key.lower()

        # 1. Handle standard objects that allow dynamic attributes
        if hasattr(target, attr_name):
            logger.info(f"      ✅ Set {key.lower()} on target object.")
            setattr(target, attr_name, value)
        else:
            # Fallback: Log a warning or handle the unmodifiable object gracefully
            logger.info(f"Warning: Cannot set attribute '{attr_name}' on protected type {type(target)}")

    def _sanitize_value(self, key: str, value: Any) -> Any:
        """Normalizes and safely translates serialization mismatches like stringified lists."""
        if isinstance(value, str) and ("collection" in key.lower() or value.startswith("[")):
            try:
                parsed = json.loads(value)
                if isinstance(parsed, list):
                    return parsed
            except json.JSONDecodeError:
                if "," in value:
                    return [v.strip() for v in value.split(",")]
        return value