import os
import httpx
from typing import Optional, Any, List, Set
from enum import Enum
from opentelemetry import trace
from guardianhub import get_logger
from guardianhub.config.settings import settings
from psycopg_pool import AsyncConnectionPool
from langgraph.checkpoint.postgres.aio import AsyncPostgresSaver
logger = get_logger(__name__)


class ServiceFlavor(str, Enum):
    CORE = "core"
    PERSISTENCE = "persistence"
    KNOWLEDGE = "mind"
    WORKFLOW = "muscle"
    GATEWAY_UPLINK = "satellite"


class ServiceContainer:
    """Tenant-aware service container: The physical connection layer."""

    def __init__(self, tenant_id):
        print("Initializing container ...........")
        self.tenant_id = tenant_id
        self._http_client: Optional[httpx.AsyncClient] = None
        self._db_pool: Optional[Any] = None

        # Clients
        self.vector: Optional[Any] = None
        self.llm: Optional[Any] = None
        self.registry: Optional[Any] = None
        self.graph: Optional[Any] = None
        self.checkpointer: Optional[Any] = None
        self.gateway_client: Optional[Any] = None

        self._active_flavors: Set[ServiceFlavor] = set()
        self.tracer: Optional[trace.Tracer] = None
        self._initialized = False

    @property
    def langfuse(self) -> Optional[Any]:
        from guardianhub.clients.langfuse.manager import LangfuseManager
        return LangfuseManager.get_instance()

    async def initialize(self, flavors: List[ServiceFlavor]):
        if self._initialized:
            logger.warning(f"Container for tenant {self.tenant_id} already initialized, skipping")
            return
        
        self._active_flavors = set(flavors)
        logger.info(f"Initializing container for tenant {self.tenant_id} with flavors: {flavors}")

        try:
            if ServiceFlavor.CORE in self._active_flavors:
                from guardianhub.clients.llm_client import LLMClient
                from guardianhub.clients.tool_registry_client import ToolRegistryClient

                self._http_client = httpx.AsyncClient(
                    limits=httpx.Limits(max_keepalive_connections=20, max_connections=100),
                    timeout=settings.endpoints.get("GLOBAL_TIMEOUT", 30.0)
                )
                self.tracer = trace.get_tracer(settings.service.name or "guardianhub-service")
                self.llm = LLMClient(shared_client=self._http_client)
                self.registry = ToolRegistryClient(http_client=self._http_client)

            if ServiceFlavor.KNOWLEDGE in self._active_flavors:
                from guardianhub.clients.vector_client import VectorClient
                from guardianhub.clients.graph_db_client import GraphDBClient
                self.vector = VectorClient(shared_client=self._http_client)
                self.graph = GraphDBClient(shared_client=self._http_client)
                await self.vector.initialize()

            if ServiceFlavor.PERSISTENCE in self._active_flavors:
                # Forming DB URL from conatiner code
                db_url = (
                    f"postgresql+asyncpg://{settings.db.db_username}:"
                    f"{settings.db.db_password}@"
                    f"{settings.db.db_host}:{settings.db.db_port}/"
                    f"{settings.db.master_tenant_db}"
                )

                if not db_url:
                    raise RuntimeError("POSTGRES_URL not found in settings. Ensure Vault is configured correctly.")

                logger.debug(f"Formed DB Url from Container : {db_url}")
                settings.endpoints.POSTGRES_URL = db_url
                # psycopg expects postgresql:// not postgresql+asyncpg://
                db_url = db_url.replace("postgresql+asyncpg://", "postgresql://")
                await self._initialize_db_well(db_url)

            # Only set initialized to True after all steps succeed
            self._initialized = True
            logger.info(f"Container for tenant {self.tenant_id} successfully initialized")
        except Exception as e:
            logger.error(f"Failed to initialize container for tenant {self.tenant_id}: {e}", exc_info=True)
            # Reset state on failure
            self._initialized = False
            self._active_flavors = set()
            raise

    async def _initialize_db_well(self, db_url: str):
        # 1. Clean the URL: psycopg3 doesn't use the "+asyncpg" dialect prefix
        clean_url = db_url.replace("+asyncpg", "")


        # 2. Initialize the pool using the conninfo parameter
        # Psycopg3 will automatically detect if it's a URL if it starts with postgresql://
        self._db_pool = AsyncConnectionPool(
            conninfo=clean_url,  # 👈 Use named argument
            max_size=10,
            kwargs={"autocommit": True}
        )
        await self._db_pool.open()
        self._checkpointer = AsyncPostgresSaver(self._db_pool)
        await self._checkpointer.setup()

    async def shutdown(self):
        if self._http_client: await self._http_client.aclose()
        if self._db_pool: await self._db_pool.close()
        self._initialized = False