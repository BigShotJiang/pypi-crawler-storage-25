import asyncio
import time
from typing import Optional, List, Dict
from guardianhub import get_logger
# Use a relative import to avoid confusion
from .container import ServiceContainer, ServiceFlavor
logger = get_logger(__name__)
from guardianhub import DEFAULT_SYSTEM_TENANT_ID


class TenantContainerRegistry:
    _containers: Dict[str, ServiceContainer] = {}
    _initialization_errors: Dict[str, str] = {}  # Track initialization errors
    _initialization_times: Dict[str, float] = {}  # Track last initialization attempt
    _lock = asyncio.Lock()
    _INITIALIZATION_COOLDOWN = 30  # Seconds to wait before retrying failed initialization

    @classmethod
    async def get_container(cls, tenant_id: str, flavors: List[ServiceFlavor] = None) -> ServiceContainer:

        from opentelemetry import baggage
        tenant_id = tenant_id or baggage.get_baggage("tenant_id")
        if not tenant_id:
            # 🎯 Force a search for the culprit instead of defaulting to master
            raise ValueError("Critical Identity Failure: tenant_id cannot be None or empty.")

        if not tenant_id:
            # If it's still missing, we fallback to 'system' (your anchored boot tenant)
            # but NEVER 'master'
            tenant_id = DEFAULT_SYSTEM_TENANT_ID


        if flavors is None: flavors = [ServiceFlavor.CORE]

        # Check if we're in cooldown period for this tenant (previous initialization failed)
        if tenant_id in cls._initialization_errors:
            last_attempt = cls._initialization_times.get(tenant_id, 0)
            if time.time() - last_attempt < cls._INITIALIZATION_COOLDOWN:
                error_msg = cls._initialization_errors[tenant_id]
                logger.error(f"Container initialization for tenant '{tenant_id}' recently failed: {error_msg}. "
                           f"Retry allowed in {cls._INITIALIZATION_COOLDOWN - (time.time() - last_attempt):.0f}s")
                raise RuntimeError(f"Container initialization for tenant '{tenant_id}' failed: {error_msg}")
            # Cooldown expired, clear error and retry
            del cls._initialization_errors[tenant_id]
            del cls._initialization_times[tenant_id]

        if tenant_id in cls._containers:
            container = cls._containers[tenant_id]
            if container._initialized:
                return container
            # Container exists but not initialized - this shouldn't happen often
            logger.warning(f"Found uninitialized container for tenant {tenant_id} in cache. Removing it.")
            del cls._containers[tenant_id]

        async with cls._lock:
            # Double-check after acquiring lock
            if tenant_id in cls._containers:
                container = cls._containers[tenant_id]
                if container._initialized:
                    return container
                else:
                    # Remove and recreate
                    logger.warning(f"Removing uninitialized container for tenant {tenant_id} (double-check)")
                    del cls._containers[tenant_id]

            logger.info(f"Creating new container for tenant: {tenant_id}")
            container = ServiceContainer(tenant_id=tenant_id)
            
            try:
                await cls._hydrate_tenant_credentials(container)
                await container.initialize(flavors=flavors)
                
                # Only store if initialization succeeded
                cls._containers[tenant_id] = container
                logger.info(f"Container for tenant '{tenant_id}' successfully initialized and cached")
                return container
            except Exception as e:
                # Track the error and set cooldown
                error_msg = str(e)
                cls._initialization_errors[tenant_id] = error_msg
                cls._initialization_times[tenant_id] = time.time()
                logger.error(f"Failed to initialize container for tenant '{tenant_id}': {error_msg}", exc_info=True)
                # Clean up the failed container
                await container.shutdown()
                raise RuntimeError(f"Container initialization failed for tenant '{tenant_id}': {error_msg}") from e

    @classmethod
    async def _hydrate_tenant_credentials(cls, container: ServiceContainer):
        from guardianhub.config.vault_manager import VaultManager
        from guardianhub.config.settings import CoreSettings

        logger.info(f"Hydrating tenant credentials for {container.tenant_id}")
        try:
            vault = VaultManager()
            secrets = await vault.sync_tenant_session(container.tenant_id)
        except Exception as e:
            logger.warning(f"Vault hydration failed for {container.tenant_id}: {e}")

    @classmethod
    async def shutdown_all(cls):
        for container in list(cls._containers.values()):
            await container.shutdown()
        cls._containers.clear()
        cls._initialization_errors.clear()
        cls._initialization_times.clear()

    @classmethod
    def clear_tenant(cls, tenant_id: str):
        """Manually clear a tenant's container (e.g., after config changes)."""
        if tenant_id in cls._containers:
            logger.info(f"Clearing container for tenant: {tenant_id}")
            del cls._containers[tenant_id]
        if tenant_id in cls._initialization_errors:
            del cls._initialization_errors[tenant_id]
        if tenant_id in cls._initialization_times:
            del cls._initialization_times[tenant_id]