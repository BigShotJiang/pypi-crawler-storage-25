"""
Copyright (c) 2025 SignalWire

This file is part of the SignalWire SDK.

Licensed under the MIT License.
See LICENSE file in the project root for full license information.
"""

"""Claude Skills - Load Claude-style SKILL.md files as SignalWire agent tools"""
