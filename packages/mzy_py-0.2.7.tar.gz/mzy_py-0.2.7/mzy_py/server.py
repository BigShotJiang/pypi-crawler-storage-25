import os
import threading
import time
import socket
from flask import Flask, send_from_directory
from werkzeug.serving import make_server

__all__ = ["run_html_server"]

def run_html_server(*, html_file: str = "index.html",
                    port: int = 5000,
                    host: str = "127.0.0.1",
                    debug: bool = False,
                    ready_timeout: float = 5) -> None:
    """
    一键启动静态 HTML 文件微型服务器（支持 Ctrl+C 正常退出）。

    参数
    ----
    html_file : str
        要托管的 HTML 文件名（可含相对路径）。
    port : int
        监听端口。
    host : str
        监听地址，0.0.0.0 允许局域网访问。
    debug : bool
        是否开启 Flask debug 模式（debug 模式下退出逻辑可能受影响）。
    ready_timeout : float
        等待服务器启动的最大秒数，超时抛 RuntimeError。
    """
    if not os.path.isfile(html_file):
        raise FileNotFoundError(html_file)

    folder = os.path.dirname(html_file) or "."
    fname = os.path.basename(html_file)
    app = Flask(__name__)

    @app.route("/")
    def index():
        return send_from_directory(folder, fname)

    # 存储服务器实例，用于后续关闭
    server = None

    def _run():
        nonlocal server
        # 创建线程安全的 WSGI 服务器
        server = make_server(host, port, app, threaded=True, use_reloader=False)
        # 关闭 debug 模式的自动重载（避免创建额外进程）
        app.debug = debug
        server.serve_forever()

    # 启动后台线程
    thread = threading.Thread(target=_run, daemon=True)
    thread.start()

    # 等待服务器就绪
    url = f"http://{host}:{port}"
    start = time.time()
    while time.time() - start < ready_timeout:
        try:
            with socket.create_connection((host, port), timeout=0.5):
                break
        except (OSError, ConnectionRefusedError):
            time.sleep(0.2)
    else:
        raise RuntimeError(f"Server failed to start on {url}")

    print(f"HTML server is running at {url}")
    print("Press Ctrl+C to stop (notebook 请中断 kernel).")

    try:
        # 阻塞主线程，直到收到中断信号
        while thread.is_alive():
            thread.join(timeout=0.5)
    except KeyboardInterrupt:
        print("\nShutting down server...")
        # 优雅关闭 Flask 服务器
        if server:
            server.shutdown()
        # 等待后台线程退出
        thread.join(timeout=2.0)
        print("Server shutdown successfully.")

if __name__ == "__main__":
    # 测试用例
    run_html_server(html_file="index.html", port=5000, host="0.0.0.0")