from __future__ import annotations

import json
from collections.abc import Awaitable, Callable
from datetime import UTC, datetime
from pathlib import Path
from urllib.parse import urlparse

import httpx
from fastapi import FastAPI, Request
from fastapi.responses import FileResponse, JSONResponse, PlainTextResponse, Response
from fastapi.staticfiles import StaticFiles

from stronk_mask.admin import (
    AdminAccessRecord,
    AdminAuthError,
    AdminLoginRateLimiter,
    AdminPrincipal,
    ApplyConflictError,
    ApplyManager,
    ApplyNotFoundError,
    ApplyRollbackError,
    AuditStore,
    OperatorStateError,
    OperatorStateStore,
    OperatorStateStoreError,
    SsrfBlockedError,
    authenticate_admin_request,
    build_admin_session_binding,
    build_auth_error_response,
    build_login_rate_limit_key,
    enforce_same_origin_for_state_change,
    fetch_openai_models,
    hash_admin_session_token,
    issue_admin_session_token,
    load_host_allowlist,
    normalize_provider_secret_ref,
    require_admin_roles,
    resolve_admin_request_context,
    resolve_secret_ref,
    validate_provider_base_url,
    verify_admin_password,
)
from stronk_mask.admin.artifacts import (
    GatewayArtifactsSnapshot,
    load_gateway_artifacts,
    summarize_doctor_status,
)
from stronk_mask.admin.auth import AdminTrustedProxyIdentity
from stronk_mask.admin.operator_state import Provider
from stronk_mask.admin.ssrf import HostResolver, ResolvedTarget
from stronk_mask.admin.ui import resolve_admin_ui_dir
from stronk_mask.config import Settings, get_settings

ENROLLMENT_MANAGER_ROLES = frozenset({"admin"})
DEBUG_PROXY_TIMEOUT_SECONDS = 5.0

ADMIN_SECURITY_HEADERS = {
    "Cache-Control": "no-store, private, max-age=0",
    "Pragma": "no-cache",
    "Expires": "0",
    "Referrer-Policy": "no-referrer",
    "X-Content-Type-Options": "nosniff",
    "X-Frame-Options": "DENY",
    "Content-Security-Policy": (
        "default-src 'self'; "
        "base-uri 'none'; "
        "connect-src 'self'; "
        "font-src 'self' data:; "
        "frame-ancestors 'none'; "
        "form-action 'self'; "
        "img-src 'self' data:; "
        "script-src 'self'; "
        "style-src 'self' 'unsafe-inline'"
    ),
}


def create_app(
    settings: Settings | None = None,
    debug_bridge_transport: httpx.AsyncBaseTransport | None = None,
    outbound_transport: httpx.AsyncBaseTransport | None = None,
    host_resolver: HostResolver | None = None,
    restart_hook: Callable[[], object | Awaitable[object]] | None = None,
) -> FastAPI:
    app_settings = settings or get_settings()
    store = (
        AuditStore(
            app_settings.audit_db_path,
            max_events=app_settings.audit_max_events,
            max_access_logs=app_settings.admin_access_log_max_entries,
            prune_interval=app_settings.audit_prune_interval,
        )
        if app_settings.audit_storage_enabled and app_settings.audit_db_path
        else None
    )
    login_limiter = AdminLoginRateLimiter(
        attempt_limit=app_settings.admin_login_attempt_limit,
        window_seconds=app_settings.admin_login_attempt_window_seconds,
    )
    ui_dir = resolve_admin_ui_dir(app_settings)
    resolved_ui_dir = ui_dir.resolve() if ui_dir is not None else None
    state_store = (
        OperatorStateStore(app_settings.admin_config_path)
        if app_settings.admin_config_path is not None
        else None
    )
    apply_manager = (
        ApplyManager(
            store=state_store,
            bundle_env_path=app_settings.admin_bundle_env_path,
            generated_dir=app_settings.admin_generated_artifacts_path,
            secrets_dir=app_settings.admin_secrets_path,
            public_healthcheck_base_url=app_settings.admin_public_healthcheck_base_url,
            outbound_transport=outbound_transport,
            restart_hook=restart_hook,
        )
        if (
            state_store is not None
            and app_settings.admin_bundle_env_path is not None
            and app_settings.admin_generated_artifacts_path is not None
        )
        else None
    )
    app = FastAPI(title=f"{app_settings.app_name} admin")
    app.state.operator_state_store = state_store
    app.state.apply_manager = apply_manager

    @app.exception_handler(AdminAuthError)
    async def handle_admin_auth_error(request: Request, error: AdminAuthError) -> Response:
        return _finalize_admin_response(
            request,
            build_auth_error_response(request, error.status_code, error.message),
        )

    @app.middleware("http")
    async def enforce_admin_access(
        request: Request,
        call_next: Callable[[Request], Awaitable[Response]],
    ) -> Response:
        if request.url.path == "/health":
            return await call_next(request)
        try:
            request.state.admin_trusted_proxy_identity = resolve_admin_request_context(
                request,
                app_settings,
            )
        except AdminAuthError as error:
            _record_access(
                store=store,
                settings=app_settings,
                actor="anonymous",
                roles=tuple(),
                request=request,
                status_code=error.status_code,
            )
            return _finalize_admin_response(
                request,
                build_auth_error_response(request, error.status_code, error.message),
            )
        if request.url.path.startswith("/api/") and not app_settings.enable_admin_api:
            return _finalize_admin_response(
                request,
                PlainTextResponse("Admin API is disabled.", status_code=404),
            )
        if not request.url.path.startswith("/api/") and not app_settings.enable_admin_ui:
            return _finalize_admin_response(
                request,
                PlainTextResponse("Admin UI is disabled.", status_code=404),
            )

        principal = None
        if _requires_authenticated_admin(request):
            try:
                principal = authenticate_admin_request(request, app_settings, store=store)
            except AdminAuthError as error:
                _record_access(
                    store=store,
                    settings=app_settings,
                    actor="anonymous",
                    roles=tuple(),
                    request=request,
                    status_code=error.status_code,
                )
                return _finalize_admin_response(
                    request,
                    build_auth_error_response(request, error.status_code, error.message),
                )
        else:
            try:
                principal = authenticate_admin_request(request, app_settings, store=store)
            except AdminAuthError:
                principal = None

        request.state.admin_principal = principal
        response = await call_next(request)
        principal = getattr(request.state, "admin_principal", principal)
        actor = principal.user if principal is not None else "anonymous"
        roles = principal.roles if principal is not None else tuple()
        _record_access(
            store=store,
            settings=app_settings,
            actor=actor,
            roles=roles,
            request=request,
            status_code=response.status_code,
        )
        return _finalize_admin_response(request, response)

    @app.get("/health")
    async def health() -> dict[str, object]:
        return {
            "status": "ok",
            "plane": "admin",
            "ui_built": ui_dir is not None,
            "audit_storage_enabled": app_settings.audit_storage_enabled,
        }

    @app.get("/api/session")
    async def session_status(request: Request) -> Response:
        principal = getattr(request.state, "admin_principal", None)
        if principal is None:
            return build_auth_error_response(
                request,
                401,
                "Admin session is required for the control plane.",
            )
        return JSONResponse(content=_build_session_payload(request, principal, app_settings))

    @app.post("/api/session/login")
    async def session_login(request: Request) -> Response:
        enforce_same_origin_for_state_change(request, app_settings)
        payload = _parse_request_payload(await request.body())
        username = str((payload or {}).get("username", "")).strip()
        password = str((payload or {}).get("password", ""))
        client_ip = _resolve_client_ip(request, app_settings)
        rate_limit_key = build_login_rate_limit_key(client_ip, username)
        if login_limiter.is_limited(rate_limit_key):
            return JSONResponse(
                status_code=429,
                content={
                    "error": {
                        "message": "Too many login attempts. Try again later.",
                        "type": "admin_auth_error",
                        "code": "admin_rate_limited",
                    }
                },
            )
        if not _is_valid_bootstrap_login(username, password, app_settings):
            login_limiter.register_failure(rate_limit_key)
            return JSONResponse(
                status_code=401,
                content={
                    "error": {
                        "message": "Invalid username or password.",
                        "type": "admin_auth_error",
                        "code": "admin_invalid_credentials",
                    }
                },
            )

        assert store is not None
        device_id = _normalize_optional_string((payload or {}).get("device_id"))
        browser_public_key = _normalize_optional_string((payload or {}).get("browser_public_key"))
        trusted_identity = getattr(request.state, "admin_trusted_proxy_identity", None)
        session_device_id: str | None = None
        if app_settings.admin_access_mode == "tailscale-serve":
            if trusted_identity is None:
                return _admin_json_error(
                    401,
                    "Trusted Tailscale proxy headers are required for the control plane.",
                    code="admin_trusted_proxy_required",
                )
            if not device_id or not browser_public_key:
                return _admin_json_error(
                    400,
                    "Device enrollment details are required for this admin access mode.",
                    code="admin_enrollment_payload_required",
                )
            enrollment = store.get_enrollment(device_id)
            if enrollment is None or not enrollment.is_approved:
                return _admin_json_error(
                    403,
                    "This browser is not approved for remote admin access yet.",
                    code="admin_enrollment_required",
                )
            if enrollment.tailscale_login.casefold() != trusted_identity.login.casefold():
                return _admin_json_error(
                    403,
                    (
                        "This browser enrollment does not match the current trusted "
                        "Tailscale identity."
                    ),
                    code="admin_enrollment_mismatch",
                )
            if enrollment.browser_public_key != browser_public_key:
                return _admin_json_error(
                    403,
                    "This browser enrollment key does not match the approved record.",
                    code="admin_enrollment_mismatch",
                )
            approved_role = enrollment.approved_role
            if approved_role is None:
                return _admin_json_error(
                    403,
                    "This browser is not approved for remote admin access yet.",
                    code="admin_enrollment_required",
                )
            principal = AdminPrincipal(user=trusted_identity.login, roles=(approved_role,))
            session_device_id = device_id
            auth_binding = build_admin_session_binding(
                app_settings,
                user=principal.user,
                roles=principal.roles,
                device_id=session_device_id,
                tailscale_login=enrollment.tailscale_login,
                browser_public_key=enrollment.browser_public_key,
                approved_role=enrollment.approved_role,
            )
            store.touch_enrollment(
                device_id=session_device_id,
                last_seen_at=datetime.now(UTC).isoformat(),
            )
        else:
            principal = _bootstrap_principal(app_settings)
            auth_binding = build_admin_session_binding(
                app_settings,
                user=principal.user,
                roles=principal.roles,
                device_id=None,
            )
        created_at = int(datetime.now(UTC).timestamp())
        absolute_expires_at = created_at + app_settings.admin_session_absolute_ttl_seconds
        session_token = issue_admin_session_token()
        prior_session_token = request.cookies.get(app_settings.admin_session_cookie_name)
        if prior_session_token:
            store.delete_session(hash_admin_session_token(prior_session_token))
        store.replace_user_session(
            token_hash=hash_admin_session_token(session_token),
            user=principal.user,
            roles=principal.roles,
            device_id=session_device_id,
            auth_binding=auth_binding,
            created_at=created_at,
            absolute_expires_at=absolute_expires_at,
        )
        login_limiter.clear(rate_limit_key)
        request.state.admin_principal = principal
        request.state.admin_session = store.get_session(
            hash_admin_session_token(session_token),
            idle_ttl_seconds=app_settings.admin_session_idle_ttl_seconds,
            now=created_at,
        )
        response = JSONResponse(content=_build_session_payload(request, principal, app_settings))
        _set_admin_session_cookie(response, session_token, app_settings)
        return response

    @app.post("/api/session/logout")
    async def session_logout(request: Request) -> Response:
        enforce_same_origin_for_state_change(request, app_settings)
        session_token = request.cookies.get(app_settings.admin_session_cookie_name)
        if session_token and store is not None:
            store.delete_session(hash_admin_session_token(session_token))
        response = Response(status_code=204)
        response.delete_cookie(
            key=app_settings.admin_session_cookie_name,
            path="/",
            httponly=True,
            samesite="strict",
            secure=app_settings.admin_session_secure_cookies,
        )
        response.headers["Clear-Site-Data"] = '"cache", "cookies", "storage"'
        return response

    @app.post("/api/enrollment/request")
    async def enrollment_request(request: Request) -> Response:
        if (
            app_settings.admin_access_mode != "tailscale-serve"
            or not app_settings.admin_enrollment_required
        ):
            return JSONResponse(
                status_code=404,
                content={
                    "error": {
                        "message": "Enrollment is not enabled for this admin access mode."
                    }
                },
            )
        assert store is not None
        enforce_same_origin_for_state_change(request, app_settings)
        trusted_identity = getattr(request.state, "admin_trusted_proxy_identity", None)
        if trusted_identity is None:
            return _admin_json_error(
                401,
                "Trusted Tailscale proxy headers are required for remote enrollment.",
                code="admin_trusted_proxy_required",
            )
        payload = _parse_request_payload(await request.body())
        username = str((payload or {}).get("username", "")).strip()
        password = str((payload or {}).get("password", ""))
        device_id = _normalize_optional_string((payload or {}).get("device_id"))
        browser_public_key = _normalize_optional_string((payload or {}).get("browser_public_key"))
        client_ip = _resolve_client_ip(request, app_settings)
        rate_limit_key = build_login_rate_limit_key(client_ip, username)
        if login_limiter.is_limited(rate_limit_key):
            return _admin_json_error(
                429,
                "Too many login attempts. Try again later.",
                code="admin_rate_limited",
            )
        if not _is_valid_bootstrap_login(username, password, app_settings):
            login_limiter.register_failure(rate_limit_key)
            return _admin_json_error(
                401,
                "Invalid username or password.",
                code="admin_invalid_credentials",
            )
        if not device_id or not browser_public_key:
            return _admin_json_error(
                400,
                "Device enrollment details are required for remote enrollment.",
                code="admin_enrollment_payload_required",
            )
        try:
            enrollment = store.upsert_enrollment_request(
                device_id=device_id,
                tailscale_login=trusted_identity.login,
                browser_public_key=browser_public_key,
                last_seen_at=datetime.now(UTC).isoformat(),
            )
        except ValueError as error:
            return _admin_json_error(409, str(error), code="admin_enrollment_conflict")
        login_limiter.clear(rate_limit_key)
        status_code = 200 if enrollment.is_approved else 202
        return JSONResponse(
            status_code=status_code,
            content={"enrollment": enrollment.to_payload()},
        )

    @app.get("/api/enrollments")
    async def list_enrollments(request: Request, limit: int = 100) -> Response:
        assert store is not None
        principal = request.state.admin_principal
        require_admin_roles(
            principal,
            ENROLLMENT_MANAGER_ROLES,
            message="Authenticated admin role does not permit enrollment management.",
        )
        bounded_limit = min(max(limit, 1), 200)
        return JSONResponse(
            content={
                "items": [
                    record.to_payload()
                    for record in store.list_enrollments(limit=bounded_limit)
                ]
            }
        )

    @app.post("/api/enrollments/{device_id}/approve")
    async def approve_enrollment(request: Request, device_id: str) -> Response:
        assert store is not None
        principal = request.state.admin_principal
        require_admin_roles(
            principal,
            ENROLLMENT_MANAGER_ROLES,
            message="Authenticated admin role does not permit enrollment management.",
        )
        enforce_same_origin_for_state_change(request, app_settings)
        payload = _parse_request_payload(await request.body())
        approved_role = str((payload or {}).get("role", "")).strip().lower()
        if approved_role not in app_settings.admin_allowed_role_set:
            return _admin_json_error(
                400,
                "Approved role must be one of the configured admin roles.",
                code="admin_invalid_enrollment_role",
            )
        try:
            enrollment = store.approve_enrollment(
                device_id=device_id,
                approved_role=approved_role,
                approved_at=datetime.now(UTC).isoformat(),
            )
        except ValueError as error:
            return _admin_json_error(409, str(error), code="admin_enrollment_conflict")
        if enrollment is None:
            return _admin_json_error(
                404,
                "Enrollment not found.",
                code="admin_enrollment_not_found",
            )
        return JSONResponse(content={"enrollment": enrollment.to_payload()})

    @app.post("/api/enrollments/{device_id}/revoke")
    async def revoke_enrollment(request: Request, device_id: str) -> Response:
        assert store is not None
        principal = request.state.admin_principal
        require_admin_roles(
            principal,
            ENROLLMENT_MANAGER_ROLES,
            message="Authenticated admin role does not permit enrollment management.",
        )
        enforce_same_origin_for_state_change(request, app_settings)
        enrollment = store.revoke_enrollment(
            device_id=device_id,
            revoked_at=datetime.now(UTC).isoformat(),
        )
        if enrollment is None:
            return _admin_json_error(
                404,
                "Enrollment not found.",
                code="admin_enrollment_not_found",
            )
        return JSONResponse(content={"enrollment": enrollment.to_payload()})

    @app.get("/api/overview")
    async def overview() -> dict[str, object]:
        gateway_snapshot = _load_gateway_snapshot(app_settings)
        if store is None:
            return {
                "total_requests": 0,
                "masked_requests": 0,
                "blocked_requests": 0,
                "route_local_requests": 0,
                "rehydrated_responses": 0,
                "error_requests": 0,
                "provider_counts": {},
                "detector_counts": {},
                "action_counts": {},
                "last_event_at": None,
                "gateway": _build_gateway_overview_payload(gateway_snapshot),
            }
        overview_payload = store.overview()
        overview_payload["gateway"] = _build_gateway_overview_payload(gateway_snapshot)
        return overview_payload

    @app.get("/api/events")
    async def events(limit: int = 50, offset: int = 0) -> dict[str, object]:
        if store is None:
            return {"items": []}
        bounded_limit = min(max(limit, 1), 200)
        return {
            "items": [
                event.to_payload()
                for event in store.list_events(limit=bounded_limit, offset=offset)
            ]
        }

    @app.get("/api/events/{request_id}")
    async def event_detail(request_id: str) -> Response:
        if store is None:
            return JSONResponse(
                status_code=404,
                content={"error": {"message": "Event not found."}},
            )
        event = store.get_event(request_id)
        if event is None:
            return JSONResponse(
                status_code=404,
                content={"error": {"message": "Event not found."}},
            )
        return JSONResponse(content=event.to_payload())

    @app.get("/api/config")
    async def config_summary(request: Request) -> dict[str, object]:
        principal = request.state.admin_principal
        viewer = principal.to_payload()
        trace_access = principal.has_any_role(app_settings.admin_trace_allowed_role_set)
        recent_access = (
            [record.to_payload() for record in store.list_access_logs(limit=8)] if store else []
        )
        gateway_snapshot = _load_gateway_snapshot(app_settings)
        return {
            "app_name": app_settings.app_name,
            "app_env": app_settings.app_env,
            "proxy_surfaces": [
                "/v1/models",
                "/v1/chat/completions",
                "/v1/responses",
                "/anthropic/v1/messages",
            ],
            "control_plane": {
                "admin_api_enabled": app_settings.enable_admin_api,
                "admin_ui_enabled": app_settings.enable_admin_ui,
                "audit_storage_enabled": app_settings.audit_storage_enabled,
                "ui_built": ui_dir is not None,
                "content_trace_enabled": app_settings.enable_unsafe_debug_view,
                "content_trace_ttl_seconds": app_settings.unsafe_debug_ttl_seconds,
                "presidio_enabled": app_settings.presidio_enabled,
            },
            "upstreams": {
                "openai_host": _host_only(app_settings.openai_upstream_base_url),
                "anthropic_host": _host_only(app_settings.anthropic_upstream_base_url),
                "allow_insecure_upstreams": app_settings.allow_insecure_upstreams,
                "allow_nonstandard_upstream_hosts": app_settings.allow_nonstandard_upstream_hosts,
            },
            "policy_actions": {
                "email": app_settings.email_action,
                "phone": app_settings.phone_action,
                "business_id": app_settings.business_id_action,
                "person_name": app_settings.person_name_action,
                "organization": app_settings.organization_action,
                "address": app_settings.address_action,
                "api_key": app_settings.api_key_action,
                "bearer_token": app_settings.bearer_token_action,
                "jwt": app_settings.jwt_action,
            },
            "presidio": {
                "languages": list(app_settings.presidio_language_list),
                "score_threshold": app_settings.presidio_score_threshold,
                "english_model": app_settings.presidio_english_model,
                "chinese_model": app_settings.presidio_chinese_model,
            },
            "auth": {
                "auth_mode": app_settings.admin_auth_mode,
                "allowed_roles": sorted(app_settings.admin_allowed_role_set),
                "trace_allowed_roles": sorted(app_settings.admin_trace_allowed_role_set),
                "session_cookie_name": app_settings.admin_session_cookie_name,
                "session_secure_cookies": app_settings.admin_session_secure_cookies,
                "viewer": viewer,
                "trace_access": trace_access,
            },
            "access": {
                "mode": app_settings.admin_access_mode,
                "http_bind": app_settings.admin_http_bind,
                "http_port": app_settings.admin_http_port,
                "allowed_origins": sorted(app_settings.admin_allowed_origin_set),
                "trusted_proxy_mode": app_settings.admin_trusted_proxy_mode,
                "enrollment_required": app_settings.admin_enrollment_required,
            },
            "gateway_artifacts": {
                "artifact_dir": gateway_snapshot["artifact_dir"],
                "schema_version": gateway_snapshot["schema_version"],
                "warnings": list(gateway_snapshot["warnings"]),
            },
            "warnings": _build_config_warnings(app_settings, ui_dir)
            + list(gateway_snapshot["warnings"]),
            "recent_access": recent_access,
        }

    @app.get("/api/operator-state")
    async def operator_state() -> dict[str, object]:
        store_instance = _require_operator_state_store(state_store)
        return store_instance.load_current_payload()

    @app.post("/api/providers")
    async def create_provider(request: Request) -> Response:
        principal = request.state.admin_principal
        _enforce_operator_write(request, principal, app_settings)
        store_instance = _require_operator_state_store(state_store)
        payload = _require_json_object(await request.body())
        try:
            await _probe_provider_upstream(
                base_url=str(payload.get("base_url", "")).strip(),
                secret_ref=normalize_provider_secret_ref(payload.get("secret_ref")),
                settings=app_settings,
                resolver=host_resolver,
                transport=outbound_transport,
            )
            provider = store_instance.create_provider(payload)
        except (
            OperatorStateStoreError,
            OperatorStateError,
            SsrfBlockedError,
            ApplyRollbackError,
        ) as error:
            return _admin_data_error(400, str(error), code="provider_invalid")
        return JSONResponse(status_code=201, content=provider.to_dict())

    @app.put("/api/providers/{provider_id}")
    async def update_provider(provider_id: str, request: Request) -> Response:
        principal = request.state.admin_principal
        _enforce_operator_write(request, principal, app_settings)
        store_instance = _require_operator_state_store(state_store)
        payload = _require_json_object(await request.body())
        try:
            existing_provider = _find_provider(store_instance, provider_id)
            await _probe_provider_upstream(
                base_url=str(payload.get("base_url", existing_provider.base_url)).strip(),
                secret_ref=normalize_provider_secret_ref(
                    payload.get("secret_ref", existing_provider.secret_ref)
                ),
                settings=app_settings,
                resolver=host_resolver,
                transport=outbound_transport,
            )
            provider = store_instance.update_provider(provider_id, payload)
        except (
            OperatorStateStoreError,
            OperatorStateError,
            SsrfBlockedError,
            ApplyRollbackError,
        ) as error:
            return _admin_data_error(400, str(error), code="provider_invalid")
        return JSONResponse(content=provider.to_dict())

    @app.delete("/api/providers/{provider_id}")
    async def delete_provider(provider_id: str, request: Request) -> Response:
        principal = request.state.admin_principal
        _enforce_operator_write(request, principal, app_settings)
        store_instance = _require_operator_state_store(state_store)
        try:
            store_instance.delete_provider(provider_id)
        except OperatorStateStoreError as error:
            return _admin_data_error(404, str(error), code="provider_not_found")
        return JSONResponse(content={"deleted": True})

    @app.post("/api/providers/{provider_id}/test")
    async def test_provider(provider_id: str, request: Request) -> Response:
        principal = request.state.admin_principal
        _enforce_operator_write(request, principal, app_settings)
        store_instance = _require_operator_state_store(state_store)
        try:
            provider = _find_provider(store_instance, provider_id)
            _, latency_ms = await _probe_provider_upstream(
                base_url=provider.base_url,
                secret_ref=provider.secret_ref,
                settings=app_settings,
                resolver=host_resolver,
                transport=outbound_transport,
            )
        except (OperatorStateStoreError, SsrfBlockedError, ApplyRollbackError) as error:
            return JSONResponse(content={"ok": False, "latency_ms": 0, "error": str(error)})
        return JSONResponse(content={"ok": True, "latency_ms": latency_ms})

    @app.post("/api/providers/{provider_id}/discover")
    async def discover_provider_models(provider_id: str, request: Request) -> Response:
        principal = request.state.admin_principal
        _enforce_operator_write(request, principal, app_settings)
        store_instance = _require_operator_state_store(state_store)
        try:
            provider = _find_provider(store_instance, provider_id)
            models, _ = await _probe_provider_upstream(
                base_url=provider.base_url,
                secret_ref=provider.secret_ref,
                settings=app_settings,
                resolver=host_resolver,
                transport=outbound_transport,
            )
        except (OperatorStateStoreError, SsrfBlockedError, ApplyRollbackError) as error:
            return _admin_data_error(400, str(error), code="discover_failed")
        return JSONResponse(content={"models": models})

    @app.post("/api/providers/{provider_id}/models")
    async def create_provider_model(provider_id: str, request: Request) -> Response:
        principal = request.state.admin_principal
        _enforce_operator_write(request, principal, app_settings)
        store_instance = _require_operator_state_store(state_store)
        payload = _require_json_object(await request.body())
        try:
            model = store_instance.create_model(provider_id, payload)
        except OperatorStateStoreError as error:
            return _admin_data_error(400, str(error), code="model_invalid")
        return JSONResponse(status_code=201, content=model.to_dict())

    @app.put("/api/providers/{provider_id}/models/{upstream_id}")
    async def update_provider_model(
        provider_id: str,
        upstream_id: str,
        request: Request,
    ) -> Response:
        principal = request.state.admin_principal
        _enforce_operator_write(request, principal, app_settings)
        store_instance = _require_operator_state_store(state_store)
        payload = _require_json_object(await request.body())
        try:
            model = store_instance.update_model(provider_id, upstream_id, payload)
        except OperatorStateStoreError as error:
            return _admin_data_error(400, str(error), code="model_invalid")
        return JSONResponse(content=model.to_dict())

    @app.delete("/api/providers/{provider_id}/models/{upstream_id}")
    async def delete_provider_model(
        provider_id: str,
        upstream_id: str,
        request: Request,
    ) -> Response:
        principal = request.state.admin_principal
        _enforce_operator_write(request, principal, app_settings)
        store_instance = _require_operator_state_store(state_store)
        try:
            store_instance.delete_model(provider_id, upstream_id)
        except OperatorStateStoreError as error:
            return _admin_data_error(404, str(error), code="model_not_found")
        return JSONResponse(content={"deleted": True})

    @app.post("/api/apply")
    async def apply_operator_state(request: Request) -> Response:
        principal = request.state.admin_principal
        _enforce_operator_write(request, principal, app_settings)
        manager = _require_apply_manager(apply_manager)
        try:
            job = await manager.start_apply()
        except ApplyConflictError as error:
            return JSONResponse(
                status_code=409,
                content={"job_id": error.job_id, "status": "running"},
            )
        return JSONResponse(content={"job_id": job.job_id, "status": "running"})

    @app.get("/api/apply/{job_id}")
    async def apply_status(job_id: str) -> Response:
        manager = _require_apply_manager(apply_manager)
        try:
            job = manager.get_job(job_id)
        except ApplyNotFoundError as error:
            return _admin_data_error(404, str(error), code="apply_not_found")
        return JSONResponse(content=job.to_payload())

    @app.post("/api/apply/{job_id}/rollback")
    async def apply_rollback(job_id: str, request: Request) -> Response:
        principal = request.state.admin_principal
        _enforce_operator_write(request, principal, app_settings)
        manager = _require_apply_manager(apply_manager)
        try:
            job = await manager.rollback(job_id)
        except (ApplyNotFoundError, ApplyRollbackError) as error:
            return _admin_data_error(400, str(error), code="rollback_failed")
        return JSONResponse(content={"status": job.status})

    @app.get("/api/providers")
    async def providers() -> dict[str, object]:
        gateway_snapshot = _load_gateway_snapshot(app_settings)
        materialization = gateway_snapshot["materialization"]
        doctor = gateway_snapshot["doctor"]
        checks = doctor["checks"]
        return {
            "schema_version": gateway_snapshot["schema_version"],
            "artifact_dir": gateway_snapshot["artifact_dir"],
            "materialization_required": not materialization["available"],
            "last_materialized_at": materialization["generated_at"],
            "last_doctor_generated_at": doctor["generated_at"],
            "last_doctor_status": summarize_doctor_status(checks),
            "warnings": list(gateway_snapshot["warnings"]),
            "items": materialization["providers"],
        }

    @app.get("/api/models")
    async def models() -> dict[str, object]:
        gateway_snapshot = _load_gateway_snapshot(app_settings)
        materialization = gateway_snapshot["materialization"]
        hermes = gateway_snapshot["hermes"]
        recommended_aliases = set(hermes["recommended_model_aliases"])
        items = []
        for item in materialization["models"]:
            items.append(
                {
                    **item,
                    "recommended_for_hermes": item["public_alias"] in recommended_aliases,
                }
            )
        return {
            "schema_version": gateway_snapshot["schema_version"],
            "artifact_dir": gateway_snapshot["artifact_dir"],
            "materialization_required": not materialization["available"],
            "last_materialized_at": materialization["generated_at"],
            "recommended_model_aliases": hermes["recommended_model_aliases"],
            "warnings": list(gateway_snapshot["warnings"]),
            "items": items,
        }

    @app.get("/api/policy")
    async def policy() -> dict[str, object]:
        gateway_snapshot = _load_gateway_snapshot(app_settings)
        endpoints = gateway_snapshot["materialization"]["endpoints"]
        return {
            "warnings": _build_config_warnings(app_settings, ui_dir)
            + list(gateway_snapshot["warnings"]),
            "detector_readiness": {
                "presidio_enabled": app_settings.presidio_enabled,
                "languages": list(app_settings.presidio_language_list),
                "score_threshold": app_settings.presidio_score_threshold,
                "english_model": app_settings.presidio_english_model,
                "chinese_model": app_settings.presidio_chinese_model,
            },
            "fail_closed_actions": {
                "email": app_settings.email_action,
                "phone": app_settings.phone_action,
                "business_id": app_settings.business_id_action,
                "person_name": app_settings.person_name_action,
                "organization": app_settings.organization_action,
                "address": app_settings.address_action,
                "api_key": app_settings.api_key_action,
                "bearer_token": app_settings.bearer_token_action,
                "jwt": app_settings.jwt_action,
            },
            "endpoint_posture": endpoints,
        }

    @app.get("/api/access")
    async def access(request: Request) -> dict[str, object]:
        principal = request.state.admin_principal
        session = getattr(request.state, "admin_session", None)
        enrollment_summary = _build_enrollment_summary(store)
        active_enrollment = None
        if session is not None and session.device_id and store is not None:
            enrollment = store.get_enrollment(session.device_id)
            active_enrollment = enrollment.to_payload() if enrollment is not None else None
        is_admin = principal.has_any_role(ENROLLMENT_MANAGER_ROLES)
        return {
            "mode": app_settings.admin_access_mode,
            "viewer": principal.to_payload(),
            "trace_allowed_roles": sorted(app_settings.admin_trace_allowed_role_set),
            "session_posture": {
                "cookie_name": app_settings.admin_session_cookie_name,
                "secure_cookies": app_settings.admin_session_secure_cookies,
                "idle_timeout_seconds": app_settings.admin_session_idle_ttl_seconds,
                "absolute_timeout_seconds": app_settings.admin_session_absolute_ttl_seconds,
                "csrf_same_origin_required": True,
                "login_attempt_limit": app_settings.admin_login_attempt_limit,
                "login_attempt_window_seconds": app_settings.admin_login_attempt_window_seconds,
            },
            "remote_access": {
                "allowed_origins": sorted(app_settings.admin_allowed_origin_set),
                "trusted_proxy_mode": app_settings.admin_trusted_proxy_mode,
                "enrollment_required": app_settings.admin_enrollment_required,
            },
            "enrollment": {
                **enrollment_summary,
                "active_device": active_enrollment,
                "recent": enrollment_summary["recent"] if is_admin else [],
            },
        }

    @app.get("/api/system")
    async def system() -> dict[str, object]:
        gateway_snapshot = _load_gateway_snapshot(app_settings)
        doctor = gateway_snapshot["doctor"]
        return {
            "schema_version": gateway_snapshot["schema_version"],
            "artifact_dir": gateway_snapshot["artifact_dir"],
            "bundle_version": doctor["bundle_version"],
            "generated_at": doctor["generated_at"],
            "private_surface_posture": doctor["private_surface_posture"],
            "check_status": summarize_doctor_status(doctor["checks"]),
            "checks": doctor["checks"],
            "image_pins": doctor["image_pins"],
            "topology": {
                "browser_admin_runtime": "stronk-mask-admin",
                "public_runtime": "stronk-mask",
                "private_backplane": "CLIProxyAPI",
                "browser_direct_cliproxyapi": False,
                "supported_access_modes": ["loopback", "ssh-forward", "tailscale-serve"],
                "current_access_mode": app_settings.admin_access_mode,
            },
            "warnings": list(gateway_snapshot["warnings"]),
        }

    @app.get("/api/debug/traces")
    async def debug_traces(request: Request) -> Response:
        principal = request.state.admin_principal
        require_admin_roles(
            principal,
            app_settings.admin_trace_allowed_role_set,
            message="Authenticated admin role does not permit content trace access.",
        )
        return await _proxy_debug_bridge_json(
            request,
            path="/api/debug/traces",
            settings=app_settings,
            transport=debug_bridge_transport,
        )

    @app.get("/api/debug/traces/{request_id}")
    async def debug_trace_detail(request: Request, request_id: str) -> Response:
        principal = request.state.admin_principal
        require_admin_roles(
            principal,
            app_settings.admin_trace_allowed_role_set,
            message="Authenticated admin role does not permit content trace access.",
        )
        return await _proxy_debug_bridge_json(
            request,
            path=f"/api/debug/traces/{request_id}",
            settings=app_settings,
            transport=debug_bridge_transport,
        )

    if resolved_ui_dir is not None and (resolved_ui_dir / "assets").exists():
        app.mount("/assets", StaticFiles(directory=str(resolved_ui_dir / "assets")), name="assets")

    @app.get("/", include_in_schema=False)
    @app.get("/{path:path}", include_in_schema=False)
    async def ui(path: str = "") -> Response:
        if path.startswith("api/") or path == "health":
            return PlainTextResponse("Not found.", status_code=404)
        if not app_settings.enable_admin_ui:
            return PlainTextResponse("Admin UI is disabled.", status_code=404)
        if ui_dir is None:
            return PlainTextResponse("Admin UI build is unavailable.", status_code=503)

        assert resolved_ui_dir is not None
        candidate = (resolved_ui_dir / path).resolve() if path else resolved_ui_dir / "index.html"
        try:
            candidate.relative_to(resolved_ui_dir)
        except ValueError:
            return PlainTextResponse("Not found.", status_code=404)

        if path and candidate.is_file():
            return FileResponse(candidate)
        index_path = resolved_ui_dir / "index.html"
        if index_path.exists():
            return FileResponse(index_path)
        return PlainTextResponse("Admin UI build is unavailable.", status_code=503)

    return app


def _requires_authenticated_admin(request: Request) -> bool:
    path = request.url.path
    if path == "/health":
        return False
    if not path.startswith("/api/"):
        return False
    return path not in {
        "/api/enrollment/request",
        "/api/session",
        "/api/session/login",
        "/api/session/logout",
    }


def _finalize_admin_response(request: Request, response: Response) -> Response:
    if request.url.path != "/health":
        for header, value in ADMIN_SECURITY_HEADERS.items():
            response.headers.setdefault(header, value)
        response.headers["Cache-Control"] = "no-store, private, max-age=0"
        response.headers["Pragma"] = "no-cache"
        response.headers["Expires"] = "0"
    return response


def _build_session_payload(
    request: Request,
    principal: AdminPrincipal,
    settings: Settings,
) -> dict[str, object]:
    trace_access = principal.has_any_role(settings.admin_trace_allowed_role_set)
    session = getattr(request.state, "admin_session", None)
    trusted_identity = getattr(request.state, "admin_trusted_proxy_identity", None)
    return {
        "viewer": principal.to_payload(),
        "auth_mode": settings.admin_auth_mode,
        "access_mode": settings.admin_access_mode,
        "trace_access": trace_access,
        "trace_allowed_roles": sorted(settings.admin_trace_allowed_role_set),
        "content_trace_enabled": settings.enable_unsafe_debug_view,
        "device_id": session.device_id if session is not None else None,
        "trusted_proxy_login": trusted_identity.login if trusted_identity is not None else None,
        "session_secure_cookies": settings.admin_session_secure_cookies,
    }


def _load_gateway_snapshot(settings: Settings) -> GatewayArtifactsSnapshot:
    return load_gateway_artifacts(settings.admin_generated_artifacts_dir)


def _build_gateway_overview_payload(snapshot: GatewayArtifactsSnapshot) -> dict[str, object]:
    materialization = snapshot["materialization"]
    hermes = snapshot["hermes"]
    doctor = snapshot["doctor"]
    providers = materialization["providers"]
    models = materialization["models"]
    provider_ready = sum(
        1 for provider in providers if _is_ready_posture(provider["readiness_posture"])
    )
    model_ready = sum(1 for model in models if _is_ready_posture(model["readiness_posture"]))
    return {
        "schema_version": snapshot["schema_version"],
        "artifact_dir": snapshot["artifact_dir"],
        "warnings": list(snapshot["warnings"]),
        "provider_summary": {
            "ready": provider_ready,
            "total": len(providers),
            "last_materialized_at": materialization["generated_at"],
        },
        "model_summary": {
            "ready": model_ready,
            "total": len(models),
            "recommended_aliases": hermes["recommended_model_aliases"],
        },
        "doctor": {
            "status": summarize_doctor_status(doctor["checks"]),
            "private_surface_posture": doctor["private_surface_posture"],
            "bundle_version": doctor["bundle_version"],
        },
        "hermes": {
            "public_base_url": hermes["public_base_url"],
            "recommended_model_aliases": hermes["recommended_model_aliases"],
            "credential_flow": hermes["credential_flow"],
            "copy_snippets": hermes["copy_snippets"],
        },
    }


def _build_enrollment_summary(store: AuditStore | None) -> dict[str, object]:
    if store is None:
        return {
            "approved": 0,
            "pending": 0,
            "revoked": 0,
            "recent": [],
        }
    enrollments = store.list_enrollments(limit=12)
    counts = store.enrollment_counts()
    return {
        "approved": counts["approved"],
        "pending": counts["pending"],
        "revoked": counts["revoked"],
        "recent": [enrollment.to_payload() for enrollment in enrollments],
    }


def _record_access(
    *,
    store: AuditStore | None,
    settings: Settings,
    actor: str,
    roles: tuple[str, ...],
    request: Request,
    status_code: int,
) -> None:
    if store is None:
        return
    if _should_skip_access_audit(request, status_code):
        return
    store.record_access(
        AdminAccessRecord(
            created_at=datetime.now(UTC).isoformat(),
            actor=actor,
            roles=roles,
            path=request.url.path,
            method=request.method,
            status_code=status_code,
            source_ip=_resolve_client_ip(request, settings),
        )
    )


def _host_only(url: str) -> str:
    parsed = urlparse(url)
    if parsed.hostname:
        if parsed.port is not None:
            return f"{parsed.hostname}:{parsed.port}"
        return parsed.hostname
    return parsed.netloc or parsed.path


def _build_config_warnings(settings: Settings, ui_dir: Path | None) -> list[str]:
    warnings: list[str] = []
    if settings.enable_debug_mask_endpoint:
        warnings.append("Sanitized debug masking endpoint is enabled.")
    if settings.allow_insecure_upstreams:
        warnings.append("Insecure upstream transport is allowed.")
    if settings.allow_nonstandard_upstream_hosts:
        warnings.append("Non-standard upstream hosts are allowed.")
    if settings.local_route_enabled:
        warnings.append("Local route policy boundary is enabled but execution remains scaffolded.")
    if settings.enable_admin_ui and ui_dir is None:
        warnings.append("Admin UI is enabled but the frontend build is missing.")
    if settings.enable_unsafe_debug_view:
        warnings.append(
            "Content trace monitoring is enabled. Raw request and response content "
            "is held in memory for recent authenticated operator inspection."
        )
    if settings.admin_access_mode == "ssh-forward":
        warnings.append(
            "Admin access mode is ssh-forward; keep the server admin lane loopback-bound."
        )
    if settings.admin_access_mode == "tailscale-serve":
        warnings.append(
            "Admin access mode is tailscale-serve; trusted proxy validation and "
            "device enrollment are enforced."
        )
    return warnings


def _is_ready_posture(value: object) -> bool:
    if not isinstance(value, str):
        return False
    return value.strip().lower() in {"ready", "pass", "ok", "healthy", "configured"}


def _resolve_client_ip(request: Request, settings: Settings) -> str | None:
    trusted_identity = getattr(request.state, "admin_trusted_proxy_identity", None)
    if isinstance(trusted_identity, AdminTrustedProxyIdentity) and (
        settings.admin_access_mode == "tailscale-serve"
    ):
        return trusted_identity.client_ip
    if request.client is not None:
        return request.client.host
    return None


def _should_skip_access_audit(request: Request, status_code: int) -> bool:
    if status_code >= 400:
        return False
    if request.url.path.startswith("/assets/"):
        return True
    return request.method == "GET" and request.url.path in {
        "/api/overview",
        "/api/events",
        "/api/config",
        "/api/session",
    }


def _is_valid_bootstrap_login(username: str, password: str, settings: Settings) -> bool:
    if settings.admin_bootstrap_user is None or settings.admin_bootstrap_password_hash is None:
        return False
    if username != settings.admin_bootstrap_user:
        return False
    return verify_admin_password(password, settings.admin_bootstrap_password_hash)


def _set_admin_session_cookie(
    response: Response,
    session_token: str,
    settings: Settings,
) -> None:
    response.set_cookie(
        key=settings.admin_session_cookie_name,
        value=session_token,
        max_age=settings.admin_session_idle_ttl_seconds,
        httponly=True,
        samesite="strict",
        secure=settings.admin_session_secure_cookies,
        path="/",
    )


def _bootstrap_principal(settings: Settings) -> AdminPrincipal:
    return AdminPrincipal(
        user=settings.admin_bootstrap_user or "operator",
        roles=tuple(sorted(settings.admin_bootstrap_role_set)),
    )


def _parse_request_payload(body: bytes) -> dict[str, object] | None:
    if not body:
        return None
    try:
        payload = json.loads(body.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError):
        return None
    return payload if isinstance(payload, dict) else None


def _normalize_optional_string(value: object) -> str | None:
    normalized = str(value or "").strip()
    return normalized or None


def _require_json_object(body: bytes) -> dict[str, object]:
    payload = _parse_request_payload(body)
    if payload is None:
        raise ValueError("Request body must be a JSON object.")
    return payload


def _admin_json_error(status_code: int, message: str, *, code: str) -> JSONResponse:
    return JSONResponse(
        status_code=status_code,
        content={
            "error": {
                "message": message,
                "type": "admin_auth_error",
                "code": code,
            }
        },
    )


def _admin_data_error(status_code: int, message: str, *, code: str) -> JSONResponse:
    return JSONResponse(
        status_code=status_code,
        content={
            "error": {
                "message": message,
                "type": "admin_validation_error",
                "code": code,
            }
        },
    )


def _enforce_operator_write(
    request: Request,
    principal: AdminPrincipal,
    settings: Settings,
) -> None:
    require_admin_roles(
        principal,
        frozenset({"admin"}),
        message="Authenticated admin role does not permit config writes.",
    )
    enforce_same_origin_for_state_change(request, settings)


def _require_operator_state_store(store: OperatorStateStore | None) -> OperatorStateStore:
    if store is None:
        raise RuntimeError("operator-state store is not configured")
    return store


def _require_apply_manager(manager: ApplyManager | None) -> ApplyManager:
    if manager is None:
        raise RuntimeError("apply manager is not configured")
    return manager


def _find_provider(store: OperatorStateStore, provider_id: str) -> Provider:
    state = store.load_current_state()
    for provider in state.providers:
        if provider.id == provider_id:
            return provider
    raise OperatorStateStoreError(f"provider {provider_id} not found")


def _validate_provider_destination(
    base_url: str,
    *,
    settings: Settings,
    resolver: HostResolver | None = None,
) -> ResolvedTarget:
    allowlist = load_host_allowlist(
        settings.admin_config_path / "ssrf-allowlist.json"
        if settings.admin_config_path is not None
        else None
    )
    return validate_provider_base_url(base_url, allowlist=allowlist, resolver=resolver)


def _resolve_provider_secret(
    secret_ref: str,
    *,
    settings: Settings,
) -> str | None:
    if not secret_ref:
        return None
    value, resolution = resolve_secret_ref(
        secret_ref,
        env_path=settings.admin_bundle_env_path,
        secrets_dir=settings.admin_secrets_path,
    )
    if value is None:
        raise ApplyRollbackError(
            f"provider secret_ref {resolution.name} could not be resolved"
        )
    return value


async def _probe_provider_upstream(
    *,
    base_url: str,
    secret_ref: str,
    settings: Settings,
    resolver: HostResolver | None = None,
    transport: httpx.AsyncBaseTransport | None = None,
) -> tuple[list[dict[str, str]], int]:
    target = _validate_provider_destination(base_url, settings=settings, resolver=resolver)
    secret_value = _resolve_provider_secret(secret_ref, settings=settings)
    return await fetch_openai_models(target, api_key=secret_value, transport=transport)


async def _proxy_debug_bridge_json(
    request: Request,
    *,
    path: str,
    settings: Settings,
    transport: httpx.AsyncBaseTransport | None,
) -> Response:
    if not settings.unsafe_debug_gateway_secret:
        return JSONResponse(
            status_code=503,
            content={"error": {"message": "Content trace monitoring is not fully configured."}},
        )
    headers = {
        "Accept": "application/json",
        "X-Stronk-Unsafe-Debug-Gateway": settings.unsafe_debug_gateway_secret,
    }
    principal = getattr(request.state, "admin_principal", None)
    if principal is not None and settings.admin_proxy_secret:
        headers[settings.admin_user_header] = principal.user
        headers[settings.admin_roles_header] = ",".join(principal.roles)
        headers[settings.admin_proxy_secret_header] = settings.admin_proxy_secret
    elif (cookie_header := request.headers.get("cookie")):
        headers["Cookie"] = cookie_header
    try:
        async with httpx.AsyncClient(
            base_url=settings.admin_debug_bridge_base_url.rstrip("/"),
            transport=transport,
            timeout=DEBUG_PROXY_TIMEOUT_SECONDS,
            follow_redirects=False,
        ) as client:
            bridge_response = await client.get(
                path,
                params=list(request.query_params.multi_items()),
                headers=headers,
            )
    except httpx.HTTPError:
        return JSONResponse(
            status_code=502,
            content={"error": {"message": "Admin trace bridge is unavailable."}},
        )
    if not bridge_response.content:
        return Response(status_code=bridge_response.status_code)
    try:
        payload = bridge_response.json()
    except json.JSONDecodeError:
        return JSONResponse(
            status_code=502,
            content={"error": {"message": "Admin trace bridge returned an invalid response."}},
        )
    return JSONResponse(status_code=bridge_response.status_code, content=payload)
