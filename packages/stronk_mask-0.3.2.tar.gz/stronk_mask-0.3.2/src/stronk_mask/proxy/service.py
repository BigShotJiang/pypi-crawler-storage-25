from __future__ import annotations

import asyncio
import json
import logging
import re
import secrets
import time
from collections.abc import AsyncIterator
from contextlib import suppress
from dataclasses import dataclass
from datetime import UTC, datetime
from http.cookiejar import CookieJar
from typing import Any, cast

import httpx
from fastapi import Request, WebSocket, WebSocketDisconnect
from fastapi.responses import JSONResponse, Response, StreamingResponse

from stronk_mask.admin.models import AdminAccessRecord
from stronk_mask.admin.store import AuditStore
from stronk_mask.config import Settings
from stronk_mask.policy.engine import PolicyEngine
from stronk_mask.providers import OPENAI_CHAT_COMPLETIONS, ProviderSpec
from stronk_mask.proxy.debug import (
    DebugValue,
    UnsafeDebugTraceRecord,
    UnsafeDebugTraceStore,
    cap_debug_value,
)
from stronk_mask.proxy.headers import (
    resolve_provider_upstream_url,
    resolve_upstream_url,
    sanitize_allowed_request_headers,
    sanitize_request_headers,
    sanitize_response_headers,
)
from stronk_mask.proxy.responses_ws import (
    ResponsesWebsocketError,
    ResponsesWebsocketSession,
    is_terminal_response_event,
    response_completed_output,
    response_event_id,
    websocket_json_payloads_from_sse_chunk,
)
from stronk_mask.proxy.sse import SSERehydrator
from stronk_mask.redaction.models import JSONValue, PolicyAction, RedactionResult
from stronk_mask.redaction.pipeline import RedactionEngine, count_rehydratable_placeholders
from stronk_mask.security.audit import AuditEventRecord, build_audit_event, build_audit_summary

TURN_STATE_RE = re.compile(r"^[A-Za-z0-9._:-]+$")
logger = logging.getLogger(__name__)
OPENAI_METADATA_REQUEST_HEADERS = frozenset(
    {
        "accept",
        "authorization",
        "openai-beta",
        "openai-organization",
        "openai-project",
        "x-request-id",
    }
)


@dataclass(frozen=True)
class _TurnSignal:
    message: dict[str, object]


class _WebSocketReceiveCoordinator:
    def __init__(
        self,
        websocket: WebSocket,
        *,
        idle_timeout_seconds: float,
    ) -> None:
        self.websocket = websocket
        self.idle_timeout_seconds = idle_timeout_seconds
        self._turn_signal: _TurnSignal | None = None
        self._receive_task: asyncio.Task[dict[str, object]] | None = None

    async def start(self) -> None:
        self._ensure_receive_task()

    async def close(self) -> None:
        if self._receive_task is None:
            return
        if not self._receive_task.done():
            self._receive_task.cancel()
        with suppress(asyncio.CancelledError):
            await self._receive_task

    async def receive_turn_input(self) -> dict[str, object]:
        if self._turn_signal is not None:
            message = self._turn_signal.message
            self._turn_signal = None
        else:
            self._ensure_receive_task()
            task = self._receive_task
            if task is None:
                raise RuntimeError("WebSocket receive task was not initialized.")
            try:
                message = await asyncio.wait_for(
                    asyncio.shield(task),
                    timeout=self.idle_timeout_seconds,
                )
            except TimeoutError as error:
                raise ResponsesWebsocketError(
                    status_code=408,
                    message="WebSocket idle timeout exceeded.",
                    error_type="invalid_websocket_turn",
                ) from error

        self._receive_task = None
        if message.get("type") != "websocket.disconnect":
            self._ensure_receive_task()
        return message

    def finish_turn(self) -> None:
        return None

    def turn_signal(self) -> _TurnSignal | None:
        if self._turn_signal is not None:
            return self._turn_signal
        if self._receive_task is None or not self._receive_task.done():
            return None
        self._turn_signal = _TurnSignal(message=self._receive_task.result())
        return self._turn_signal

    def _ensure_receive_task(self) -> None:
        if self._receive_task is None:
            self._receive_task = asyncio.create_task(self._receive_message())

    async def _receive_message(self) -> dict[str, object]:
        message = await self.websocket.receive()
        return cast(dict[str, object], message)


@dataclass(frozen=True)
class _QueuedAuditEvent:
    event: AuditEventRecord


@dataclass(frozen=True)
class _QueuedAdminAccess:
    record: AdminAccessRecord


class _EphemeralCookieJar(CookieJar):
    # Prevent pooled upstream clients from persisting cookies across callers.
    def extract_cookies(self, response: Any, request: Any) -> None:
        return None

    def add_cookie_header(self, request: Any) -> None:
        return None


class ProxyService:
    websocket_turn_state_ttl_seconds = 60 * 30

    def __init__(
        self,
        settings: Settings,
        transport: httpx.AsyncBaseTransport | None = None,
    ) -> None:
        self.settings = settings
        self.transport = transport
        self.redaction = RedactionEngine(
            policy=PolicyEngine.from_settings(settings),
            settings=settings,
        )
        self.audit_store = (
            AuditStore(
                settings.audit_db_path,
                max_events=settings.audit_max_events,
                max_access_logs=settings.admin_access_log_max_entries,
                prune_interval=settings.audit_prune_interval,
            )
            if settings.audit_storage_enabled and settings.audit_db_path
            else None
        )
        self.unsafe_debug_store = (
            UnsafeDebugTraceStore(
                max_entries=settings.unsafe_debug_max_entries,
                ttl_seconds=settings.unsafe_debug_ttl_seconds,
            )
            if settings.enable_unsafe_debug_view
            else None
        )
        self._upstream_client: httpx.AsyncClient | None = None
        self._audit_queue: asyncio.Queue[_QueuedAuditEvent | _QueuedAdminAccess | None] | None = (
            asyncio.Queue(maxsize=settings.audit_queue_maxsize)
            if self.audit_store is not None
            else None
        )
        self._audit_worker_task: asyncio.Task[None] | None = None
        self.websocket_turn_sessions: dict[str, ResponsesWebsocketSession] = {}

    async def startup(self) -> None:
        self._get_upstream_client()
        self._ensure_audit_worker()

    async def shutdown(self) -> None:
        if self._audit_queue is not None and self._audit_worker_task is not None:
            await self._audit_queue.put(None)
            with suppress(asyncio.CancelledError):
                await self._audit_worker_task
            self._audit_worker_task = None
        if self._upstream_client is not None:
            await self._upstream_client.aclose()
            self._upstream_client = None

    def _get_upstream_client(self) -> httpx.AsyncClient:
        if self._upstream_client is None:
            self._upstream_client = httpx.AsyncClient(
                follow_redirects=False,
                timeout=self.settings.request_timeout_seconds,
                transport=self.transport,
                cookies=_EphemeralCookieJar(),
                limits=httpx.Limits(
                    max_connections=self.settings.upstream_max_connections,
                    max_keepalive_connections=self.settings.upstream_max_keepalive_connections,
                ),
            )
        return self._upstream_client

    def _ensure_audit_worker(self) -> None:
        if self.audit_store is None or self._audit_queue is None:
            return
        if self._audit_worker_task is not None and not self._audit_worker_task.done():
            return
        self._audit_worker_task = asyncio.create_task(self._audit_writer_loop())

    async def handle(self, request: Request, spec: ProviderSpec) -> Response:
        started_at = time.perf_counter()
        request_id = secrets.token_hex(8)
        body = await request.body()
        if len(body) > self.settings.max_request_body_bytes:
            response = self._error_response(
                spec=spec,
                status_code=413,
                message="Request body exceeds configured privacy boundary limit.",
            )
            self._record_event(
                request_id=request_id,
                spec=spec,
                payload=None,
                result=None,
                stream=False,
                status_code=response.status_code,
                started_at=started_at,
                outcome="proxy_error",
            )
            return response

        try:
            payload = json.loads(body)
        except json.JSONDecodeError:
            response = self._error_response(
                spec=spec,
                status_code=400,
                message="Request body must be valid JSON.",
            )
            self._record_event(
                request_id=request_id,
                spec=spec,
                payload=None,
                result=None,
                stream=False,
                status_code=response.status_code,
                started_at=started_at,
                outcome="proxy_error",
            )
            return response
        if not isinstance(payload, dict):
            response = self._error_response(
                spec=spec,
                status_code=400,
                message="Request body must be a JSON object.",
            )
            self._record_event(
                request_id=request_id,
                spec=spec,
                payload=None,
                result=None,
                stream=False,
                status_code=response.status_code,
                started_at=started_at,
                outcome="proxy_error",
            )
            return response

        payload_obj = payload
        requested_stream = payload_obj.get("stream") is True
        redaction = self.redaction.redact_payload(payload_obj)
        if redaction.blocked:
            response = self._error_response(
                spec=spec,
                status_code=422,
                message="Request blocked by privacy policy.",
                audit=build_audit_summary(redaction),
            )
            self._record_event(
                request_id=request_id,
                spec=spec,
                payload=payload_obj,
                result=redaction,
                stream=requested_stream,
                status_code=response.status_code,
                started_at=started_at,
                outcome="blocked",
            )
            self._record_unsafe_debug_trace(
                request_id=request_id,
                spec=spec,
                original_payload=payload_obj,
                masked_payload=redaction.payload,
                response_upstream=None,
                response_rehydrated=_debug_value_from_bytes(response.body),
                stream=requested_stream,
                status_code=response.status_code,
                outcome="blocked",
            )
            return response
        if redaction.route_local:
            if not self.settings.local_route_enabled or not self.settings.local_route_base_url:
                response = self._error_response(
                    spec=spec,
                    status_code=503,
                    message="Local routing required by policy but unavailable.",
                    audit=build_audit_summary(redaction),
                )
            else:
                response = self._error_response(
                    spec=spec,
                    status_code=501,
                    message=(
                        "Local routing is configured as a policy boundary "
                        "but not implemented yet."
                    ),
                    audit=build_audit_summary(redaction),
                )
            self._record_event(
                request_id=request_id,
                spec=spec,
                payload=payload_obj,
                result=redaction,
                stream=requested_stream,
                status_code=response.status_code,
                started_at=started_at,
                outcome="route_local",
            )
            self._record_unsafe_debug_trace(
                request_id=request_id,
                spec=spec,
                original_payload=payload_obj,
                masked_payload=redaction.payload,
                response_upstream=None,
                response_rehydrated=_debug_value_from_bytes(response.body),
                stream=requested_stream,
                status_code=response.status_code,
                outcome="route_local",
            )
            return response

        try:
            upstream_url = resolve_upstream_url(self.settings, spec)
        except ValueError as error:
            response = self._error_response(spec=spec, status_code=500, message=str(error))
            self._record_event(
                request_id=request_id,
                spec=spec,
                payload=payload_obj,
                result=redaction,
                stream=requested_stream,
                status_code=response.status_code,
                started_at=started_at,
                outcome="proxy_error",
            )
            self._record_unsafe_debug_trace(
                request_id=request_id,
                spec=spec,
                original_payload=payload_obj,
                masked_payload=redaction.payload,
                response_upstream=None,
                response_rehydrated=_debug_value_from_bytes(response.body),
                stream=requested_stream,
                status_code=response.status_code,
                outcome="proxy_error",
            )
            return response

        client = self._get_upstream_client()
        headers = sanitize_request_headers(
            request.headers,
            spec,
            proxy_request_id=request_id,
        )
        upstream_request = client.build_request(
            "POST",
            upstream_url,
            headers=headers,
            json=redaction.payload,
        )

        try:
            upstream_response = await client.send(upstream_request, stream=True)
        except httpx.HTTPError:
            response = self._error_response(
                spec=spec,
                status_code=502,
                message="Upstream request failed without a safe fallback path.",
            )
            self._record_event(
                request_id=request_id,
                spec=spec,
                payload=payload_obj,
                result=redaction,
                stream=requested_stream,
                status_code=response.status_code,
                started_at=started_at,
                outcome="upstream_error",
            )
            self._record_unsafe_debug_trace(
                request_id=request_id,
                spec=spec,
                original_payload=payload_obj,
                masked_payload=redaction.payload,
                response_upstream=None,
                response_rehydrated=_debug_value_from_bytes(response.body),
                stream=requested_stream,
                status_code=response.status_code,
                outcome="upstream_error",
            )
            return response

        content_type = upstream_response.headers.get("content-type", "")
        is_stream_response = (
            requested_stream
            and upstream_response.status_code < 400
            and "text/event-stream" in content_type
        )
        if is_stream_response:
            response_headers = sanitize_response_headers(upstream_response.headers)
            response_headers.pop("content-type", None)
            response_headers.pop("Content-Type", None)
            rehydrator = SSERehydrator(
                redaction.vault,
                capture_limit_bytes=(
                    self.settings.unsafe_debug_stream_tail_bytes
                    if self.unsafe_debug_store is not None
                    else 0
                ),
            )
            return StreamingResponse(
                self._stream_response(
                    upstream_response=upstream_response,
                    rehydrator=rehydrator,
                    request_id=request_id,
                    spec=spec,
                    payload=payload_obj,
                    redaction=redaction,
                    started_at=started_at,
                ),
                status_code=upstream_response.status_code,
                headers=response_headers,
                media_type=content_type,
            )

        raw_bytes = await upstream_response.aread()
        await upstream_response.aclose()
        (
            materialized_response,
            rehydration_count,
            debug_upstream_payload,
            debug_rehydrated_payload,
        ) = self._build_materialized_response(
            upstream_response=upstream_response,
            raw_bytes=raw_bytes,
            redaction=redaction,
            debug_capture_bytes=(
                self.settings.unsafe_debug_body_capture_bytes
                if self.unsafe_debug_store is not None
                else 0
            ),
        )
        self._record_event(
            request_id=request_id,
            spec=spec,
            payload=payload_obj,
            result=redaction,
            stream=requested_stream,
            status_code=upstream_response.status_code,
            started_at=started_at,
            rehydration_count=rehydration_count,
        )
        self._record_unsafe_debug_trace(
            request_id=request_id,
            spec=spec,
            original_payload=payload_obj,
            masked_payload=redaction.payload,
            response_upstream=debug_upstream_payload,
            response_rehydrated=debug_rehydrated_payload,
            stream=requested_stream,
            status_code=upstream_response.status_code,
            outcome=_resolve_debug_outcome(redaction, upstream_response.status_code),
        )
        return materialized_response

    async def handle_openai_models(self, request: Request) -> Response:
        try:
            upstream_url = resolve_provider_upstream_url(
                self.settings,
                provider="openai",
                upstream_path="/v1/models",
            )
        except ValueError as error:
            return self._error_response(
                spec=OPENAI_CHAT_COMPLETIONS,
                status_code=500,
                message=str(error),
            )

        client = self._get_upstream_client()
        headers = sanitize_allowed_request_headers(
            request.headers,
            OPENAI_METADATA_REQUEST_HEADERS,
            default_content_type=None,
        )
        upstream_request = client.build_request(
            "GET",
            upstream_url,
            headers=headers,
        )

        try:
            upstream_response = await client.send(upstream_request)
        except httpx.HTTPError:
            return self._error_response(
                spec=OPENAI_CHAT_COMPLETIONS,
                status_code=502,
                message="Upstream request failed without a safe fallback path.",
            )

        raw_bytes = await upstream_response.aread()
        await upstream_response.aclose()
        response_headers = sanitize_response_headers(upstream_response.headers)
        return Response(
            content=raw_bytes,
            status_code=upstream_response.status_code,
            headers=response_headers,
        )

    async def handle_responses_websocket(
        self,
        websocket: WebSocket,
        spec: ProviderSpec,
    ) -> None:
        try:
            turn_state, session, owner_token = self._resolve_websocket_session(websocket)
        except ResponsesWebsocketError as error:
            await websocket.accept()
            await self._send_websocket_error(
                websocket,
                status_code=error.status_code,
                message=error.message,
                error_type=error.error_type,
            )
            await websocket.close(code=1008)
            return
        accept_headers: list[tuple[bytes, bytes]] = [
            (b"x-codex-turn-state", turn_state.encode("utf-8"))
        ]
        owner_held = True
        coordinator = _WebSocketReceiveCoordinator(
            websocket,
            idle_timeout_seconds=self.settings.websocket_idle_timeout_seconds,
        )
        turn_open = False
        def release_turn_owner() -> None:
            nonlocal owner_held
            if not owner_held:
                return
            session.release_owner(owner_token)
            owner_held = False

        def finish_turn() -> None:
            nonlocal turn_open
            if not turn_open:
                return
            coordinator.finish_turn()
            turn_open = False

        try:
            await websocket.accept(headers=accept_headers)

            await coordinator.start()
            release_turn_owner()
            message_count = 0
            consecutive_errors = 0

            while True:
                try:
                    inbound_message = await coordinator.receive_turn_input()
                    turn_open = True
                    raw_text = self._decode_websocket_receive_message(inbound_message)
                except WebSocketDisconnect:
                    finish_turn()
                    return
                except ResponsesWebsocketError as error:
                    finish_turn()
                    await self._send_websocket_error(
                        websocket,
                        status_code=error.status_code,
                        message=error.message,
                        error_type=error.error_type,
                    )
                    await websocket.close(code=1009 if error.status_code == 413 else 1008)
                    return
                except ValueError:
                    finish_turn()
                    await self._send_websocket_error(
                        websocket,
                        status_code=400,
                        message="WebSocket requests must use JSON text frames.",
                        error_type="invalid_websocket_frame",
                    )
                    await websocket.close(code=1003)
                    return
                except UnicodeDecodeError:
                    finish_turn()
                    await self._send_websocket_error(
                        websocket,
                        status_code=400,
                        message="WebSocket frames must be valid UTF-8 JSON.",
                        error_type="invalid_websocket_frame",
                    )
                    await websocket.close(code=1003)
                    return

                if raw_text is None:
                    finish_turn()
                    continue
                message_count += 1
                if message_count > self.settings.websocket_message_limit:
                    await self._send_websocket_error(
                        websocket,
                        status_code=429,
                        message="WebSocket message budget exceeded for this connection.",
                        error_type="invalid_websocket_turn",
                    )
                    finish_turn()
                    await websocket.close(code=1008)
                    return

                if not owner_held:
                    if not session.try_acquire_owner(owner_token):
                        finish_turn()
                        await self._send_websocket_error(
                            websocket,
                            status_code=409,
                            message="WebSocket turn is already active on another connection.",
                            error_type="invalid_websocket_turn",
                        )
                        await websocket.close(code=1008)
                        return
                    owner_held = True

                request_id = secrets.token_hex(8)
                started_at = time.perf_counter()
                original_debug_payload = _try_parse_debug_json(raw_text)
                working_session = session.clone()
                try:
                    normalized = working_session.normalize(raw_text)
                except ResponsesWebsocketError as error:
                    error_payload = self._build_websocket_error_payload(
                        status_code=error.status_code,
                        message=error.message,
                        error_type=error.error_type,
                    )
                    await self._send_websocket_error(
                        websocket,
                        status_code=error.status_code,
                        message=error.message,
                        error_type=error.error_type,
                    )
                    self._record_event(
                        request_id=request_id,
                        spec=spec,
                        payload=None,
                        result=None,
                        stream=True,
                        status_code=error.status_code,
                        started_at=started_at,
                        outcome="proxy_error",
                    )
                    self._record_unsafe_debug_trace(
                        request_id=request_id,
                        spec=spec,
                        original_payload=original_debug_payload,
                        masked_payload=None,
                        response_upstream=None,
                        response_rehydrated=error_payload,
                        stream=True,
                        status_code=error.status_code,
                        outcome="proxy_error",
                    )
                    consecutive_errors += 1
                    release_turn_owner()
                    finish_turn()
                    if consecutive_errors >= self.settings.websocket_consecutive_error_limit:
                        await websocket.close(code=1008)
                        return
                    continue

                redaction = self.redaction.redact_payload(normalized.payload)
                if redaction.blocked:
                    error_payload = self._build_websocket_error_payload(
                        status_code=422,
                        message="Request blocked by privacy policy.",
                    )
                    await self._send_websocket_error(
                        websocket,
                        status_code=422,
                        message="Request blocked by privacy policy.",
                    )
                    self._record_event(
                        request_id=request_id,
                        spec=spec,
                        payload=normalized.payload,
                        result=redaction,
                        stream=True,
                        status_code=422,
                        started_at=started_at,
                        outcome="blocked",
                    )
                    self._record_unsafe_debug_trace(
                        request_id=request_id,
                        spec=spec,
                        original_payload=original_debug_payload,
                        masked_payload=redaction.payload,
                        response_upstream=None,
                        response_rehydrated=error_payload,
                        stream=True,
                        status_code=422,
                        outcome="blocked",
                    )
                    consecutive_errors += 1
                    release_turn_owner()
                    finish_turn()
                    if consecutive_errors >= self.settings.websocket_consecutive_error_limit:
                        await websocket.close(code=1008)
                        return
                    continue
                if redaction.route_local:
                    route_status = (
                        503
                        if (
                            not self.settings.local_route_enabled
                            or not self.settings.local_route_base_url
                        )
                        else 501
                    )
                    route_message = (
                        "Local routing required by policy but unavailable."
                        if route_status == 503
                        else (
                            "Local routing is configured as a policy boundary "
                            "but not implemented yet."
                        )
                    )
                    error_payload = self._build_websocket_error_payload(
                        status_code=route_status,
                        message=route_message,
                    )
                    await self._send_websocket_error(
                        websocket,
                        status_code=route_status,
                        message=route_message,
                    )
                    self._record_event(
                        request_id=request_id,
                        spec=spec,
                        payload=normalized.payload,
                        result=redaction,
                        stream=True,
                        status_code=route_status,
                        started_at=started_at,
                        outcome="route_local",
                    )
                    self._record_unsafe_debug_trace(
                        request_id=request_id,
                        spec=spec,
                        original_payload=original_debug_payload,
                        masked_payload=redaction.payload,
                        response_upstream=None,
                        response_rehydrated=error_payload,
                        stream=True,
                        status_code=route_status,
                        outcome="route_local",
                    )
                    consecutive_errors += 1
                    release_turn_owner()
                    finish_turn()
                    if consecutive_errors >= self.settings.websocket_consecutive_error_limit:
                        await websocket.close(code=1008)
                        return
                    continue

                if normalized.synthetic_events:
                    queued_turn_collision = False
                    downstream_disconnected = False
                    terminal_delivered = False
                    turn_state_committed = False

                    def sync_turn_signal() -> None:  # noqa: B023
                        nonlocal downstream_disconnected, queued_turn_collision
                        if turn_state_committed:  # noqa: B023
                            return
                        turn_signal = coordinator.turn_signal()
                        if turn_signal is None:
                            return
                        if turn_signal.message["type"] == "websocket.disconnect":
                            downstream_disconnected = True
                        elif turn_signal.message["type"] == "websocket.receive":
                            queued_turn_collision = True

                    try:
                        for event in normalized.synthetic_events:
                            sync_turn_signal()
                            if downstream_disconnected:
                                break
                            event_text = json.dumps(
                                event,
                                ensure_ascii=False,
                                separators=(",", ":"),
                            )
                            if is_terminal_response_event(event):
                                terminal_delivered = await self._send_terminal_websocket_text(
                                    websocket,
                                    event_text,
                                )
                                if terminal_delivered:
                                    session.restore(working_session.checkpoint())
                                    sync_turn_signal()
                                    turn_state_committed = True
                                    if not queued_turn_collision and not downstream_disconnected:
                                        release_turn_owner()
                                else:
                                    downstream_disconnected = True
                                continue
                            await websocket.send_text(event_text)
                    except WebSocketDisconnect:
                        downstream_disconnected = True

                    if downstream_disconnected and not terminal_delivered:
                        finish_turn()
                        return

                    self._record_event(
                        request_id=request_id,
                        spec=spec,
                        payload=normalized.payload,
                        result=redaction,
                        stream=True,
                        status_code=200,
                        started_at=started_at,
                    )
                    self._record_unsafe_debug_trace(
                        request_id=request_id,
                        spec=spec,
                        original_payload=original_debug_payload,
                        masked_payload=redaction.payload,
                        response_upstream=None,
                        response_rehydrated=list(normalized.synthetic_events),
                        stream=True,
                        status_code=200,
                        outcome=_resolve_debug_outcome(redaction, 200),
                    )
                    consecutive_errors = 0
                    if not terminal_delivered:
                        release_turn_owner()
                    if queued_turn_collision:
                        await self._send_websocket_error(
                            websocket,
                            status_code=409,
                            message="Concurrent websocket turns are not allowed on one connection.",
                            error_type="invalid_websocket_turn",
                        )
                        finish_turn()
                        await websocket.close(code=1008)
                        return
                    finish_turn()
                    continue

                try:
                    upstream_url = resolve_upstream_url(self.settings, spec)
                except ValueError as error:
                    error_payload = self._build_websocket_error_payload(
                        status_code=500,
                        message=str(error),
                    )
                    await self._send_websocket_error(
                        websocket,
                        status_code=500,
                        message=str(error),
                    )
                    self._record_event(
                        request_id=request_id,
                        spec=spec,
                        payload=normalized.payload,
                        result=redaction,
                        stream=True,
                        status_code=500,
                        started_at=started_at,
                        outcome="proxy_error",
                    )
                    self._record_unsafe_debug_trace(
                        request_id=request_id,
                        spec=spec,
                        original_payload=original_debug_payload,
                        masked_payload=redaction.payload,
                        response_upstream=None,
                        response_rehydrated=error_payload,
                        stream=True,
                        status_code=500,
                        outcome="proxy_error",
                    )
                    consecutive_errors += 1
                    release_turn_owner()
                    finish_turn()
                    if consecutive_errors >= self.settings.websocket_consecutive_error_limit:
                        await websocket.close(code=1008)
                        return
                    continue

                client = self._get_upstream_client()
                headers = sanitize_request_headers(
                    websocket.headers,
                    spec,
                    proxy_request_id=request_id,
                )
                upstream_request = client.build_request(
                    "POST",
                    upstream_url,
                    headers=headers,
                    json=redaction.payload,
                )

                try:
                    upstream_response = await client.send(upstream_request, stream=True)
                except httpx.HTTPError:
                    error_payload = self._build_websocket_error_payload(
                        status_code=502,
                        message="Upstream request failed without a safe fallback path.",
                        error_type="upstream_error",
                    )
                    await self._send_websocket_error(
                        websocket,
                        status_code=502,
                        message="Upstream request failed without a safe fallback path.",
                        error_type="upstream_error",
                    )
                    self._record_event(
                        request_id=request_id,
                        spec=spec,
                        payload=normalized.payload,
                        result=redaction,
                        stream=True,
                        status_code=502,
                        started_at=started_at,
                        outcome="upstream_error",
                    )
                    self._record_unsafe_debug_trace(
                        request_id=request_id,
                        spec=spec,
                        original_payload=original_debug_payload,
                        masked_payload=redaction.payload,
                        response_upstream=None,
                        response_rehydrated=error_payload,
                        stream=True,
                        status_code=502,
                        outcome="upstream_error",
                    )
                    consecutive_errors += 1
                    release_turn_owner()
                    finish_turn()
                    if consecutive_errors >= self.settings.websocket_consecutive_error_limit:
                        await websocket.close(code=1008)
                        return
                    continue

                content_type = upstream_response.headers.get("content-type", "")
                if upstream_response.status_code >= 400:
                    raw_bytes = await upstream_response.aread()
                    await upstream_response.aclose()
                    upstream_error = self._extract_upstream_error_message(raw_bytes)
                    error_payload = self._build_websocket_error_payload(
                        status_code=upstream_response.status_code,
                        message=upstream_error,
                        error_type="upstream_error",
                    )
                    await self._send_websocket_error(
                        websocket,
                        status_code=upstream_response.status_code,
                        message=upstream_error,
                        error_type="upstream_error",
                    )
                    self._record_event(
                        request_id=request_id,
                        spec=spec,
                        payload=normalized.payload,
                        result=redaction,
                        stream=True,
                        status_code=upstream_response.status_code,
                        started_at=started_at,
                    )
                    self._record_unsafe_debug_trace(
                        request_id=request_id,
                        spec=spec,
                        original_payload=original_debug_payload,
                        masked_payload=redaction.payload,
                        response_upstream=_debug_value_from_bytes(raw_bytes),
                        response_rehydrated=error_payload,
                        stream=True,
                        status_code=upstream_response.status_code,
                        outcome=_resolve_debug_outcome(redaction, upstream_response.status_code),
                    )
                    consecutive_errors += 1
                    release_turn_owner()
                    finish_turn()
                    if consecutive_errors >= self.settings.websocket_consecutive_error_limit:
                        await websocket.close(code=1008)
                        return
                    continue

                if "text/event-stream" not in content_type:
                    raw_bytes = await upstream_response.aread()
                    await upstream_response.aclose()
                    error_payload = self._build_websocket_error_payload(
                        status_code=502,
                        message=(
                            "WebSocket bridge requires an event-stream upstream response "
                            "for /responses requests."
                        ),
                    )
                    await self._send_websocket_error(
                        websocket,
                        status_code=502,
                        message=(
                            "WebSocket bridge requires an event-stream upstream response "
                            "for /responses requests."
                        ),
                    )
                    self._record_event(
                        request_id=request_id,
                        spec=spec,
                        payload=normalized.payload,
                        result=redaction,
                        stream=True,
                        status_code=502,
                        started_at=started_at,
                        outcome="proxy_error",
                    )
                    self._record_unsafe_debug_trace(
                        request_id=request_id,
                        spec=spec,
                        original_payload=original_debug_payload,
                        masked_payload=redaction.payload,
                        response_upstream=_debug_value_from_bytes(raw_bytes),
                        response_rehydrated=error_payload,
                        stream=True,
                        status_code=502,
                        outcome="proxy_error",
                    )
                    consecutive_errors += 1
                    release_turn_owner()
                    finish_turn()
                    if consecutive_errors >= self.settings.websocket_consecutive_error_limit:
                        await websocket.close(code=1008)
                        return
                    continue

                rehydrator = SSERehydrator(
                    redaction.vault,
                    capture_limit_bytes=(
                        self.settings.unsafe_debug_stream_tail_bytes
                        if self.unsafe_debug_store is not None
                        else 0
                    ),
                )
                completed_output: JSONValue = []
                terminal_event_sent = False
                terminal_state_committed = False
                completed_response_id: str | None = None
                downstream_disconnected = False
                queued_turn_collision = False

                def sync_turn_signal() -> None:  # noqa: B023
                    nonlocal downstream_disconnected, queued_turn_collision
                    if terminal_state_committed:  # noqa: B023
                        return
                    turn_signal = coordinator.turn_signal()
                    if turn_signal is None:
                        return
                    if turn_signal.message["type"] == "websocket.disconnect":
                        downstream_disconnected = True
                    elif turn_signal.message["type"] == "websocket.receive":
                        queued_turn_collision = True

                try:
                    async for chunk in rehydrator.transform(upstream_response.aiter_bytes()):
                        sync_turn_signal()
                        if downstream_disconnected:
                            break
                        for payload in websocket_json_payloads_from_sse_chunk(chunk):
                            sync_turn_signal()
                            if downstream_disconnected:
                                break
                            terminal_payload = is_terminal_response_event(payload)
                            terminal_response_id = (
                                response_event_id(payload) if terminal_payload else None
                            )
                            if payload.get("type") == "response.completed":
                                completed_output = response_completed_output(payload)
                            payload_text = json.dumps(
                                payload,
                                ensure_ascii=False,
                                separators=(",", ":"),
                            )
                            if terminal_payload:
                                delivered = await self._send_terminal_websocket_text(
                                    websocket,
                                    payload_text,
                                )
                                if delivered:
                                    terminal_event_sent = True
                                    completed_response_id = terminal_response_id
                                    working_session.last_completed_output = completed_output
                                    working_session.last_response_id = completed_response_id
                                    working_session.last_response_local = False
                                    session.restore(working_session.checkpoint())
                                    sync_turn_signal()
                                    terminal_state_committed = True
                                    if not queued_turn_collision and not downstream_disconnected:
                                        release_turn_owner()
                                else:
                                    downstream_disconnected = True
                                continue
                            await websocket.send_text(payload_text)
                except WebSocketDisconnect:
                    downstream_disconnected = True
                finally:
                    await upstream_response.aclose()

                sync_turn_signal()
                if downstream_disconnected and not terminal_event_sent:
                    finish_turn()
                    return

                if not terminal_event_sent:
                    if queued_turn_collision:
                        await self._send_websocket_error(
                            websocket,
                            status_code=409,
                            message="Concurrent websocket turns are not allowed on one connection.",
                            error_type="invalid_websocket_turn",
                        )
                        finish_turn()
                        await websocket.close(code=1008)
                        return
                    error_payload = self._build_websocket_error_payload(
                        status_code=408,
                        message="Upstream stream closed before response.completed.",
                        error_type="upstream_error",
                    )
                    await self._send_websocket_error(
                        websocket,
                        status_code=408,
                        message="Upstream stream closed before response.completed.",
                        error_type="upstream_error",
                    )
                    self._record_event(
                        request_id=request_id,
                        spec=spec,
                        payload=normalized.payload,
                        result=redaction,
                        stream=True,
                        status_code=408,
                        started_at=started_at,
                        outcome="upstream_error",
                    )
                    self._record_unsafe_debug_trace(
                        request_id=request_id,
                        spec=spec,
                        original_payload=original_debug_payload,
                        masked_payload=redaction.payload,
                        response_upstream=rehydrator.masked_stream_text,
                        response_rehydrated=(
                            rehydrator.rehydrated_stream_text
                            + "\n"
                            + json.dumps(error_payload, ensure_ascii=False, separators=(",", ":"))
                        ).strip(),
                        stream=True,
                        status_code=408,
                        outcome="upstream_error",
                    )
                    consecutive_errors += 1
                    release_turn_owner()
                    finish_turn()
                    if consecutive_errors >= self.settings.websocket_consecutive_error_limit:
                        await websocket.close(code=1008)
                        return
                    continue

                if not terminal_state_committed:
                    working_session.last_completed_output = completed_output
                    working_session.last_response_id = completed_response_id
                    working_session.last_response_local = False
                    session.restore(working_session.checkpoint())
                consecutive_errors = 0
                self._record_event(
                    request_id=request_id,
                    spec=spec,
                    payload=normalized.payload,
                    result=redaction,
                    stream=True,
                    status_code=upstream_response.status_code,
                    started_at=started_at,
                    rehydration_count=rehydrator.rehydration_count,
                )
                self._record_unsafe_debug_trace(
                    request_id=request_id,
                    spec=spec,
                    original_payload=original_debug_payload,
                    masked_payload=redaction.payload,
                    response_upstream=rehydrator.masked_stream_text,
                    response_rehydrated=rehydrator.rehydrated_stream_text,
                    stream=True,
                    status_code=upstream_response.status_code,
                    outcome=_resolve_debug_outcome(redaction, upstream_response.status_code),
                )
                if queued_turn_collision:
                    await self._send_websocket_error(
                        websocket,
                        status_code=409,
                        message="Concurrent websocket turns are not allowed on one connection.",
                        error_type="invalid_websocket_turn",
                    )
                    finish_turn()
                    await websocket.close(code=1008)
                    return
                if downstream_disconnected:
                    finish_turn()
                    return
                finish_turn()
        finally:
            finish_turn()
            await coordinator.close()
            if owner_held:
                session.release_owner(owner_token)

    async def _stream_response(
        self,
        upstream_response: httpx.Response,
        rehydrator: SSERehydrator,
        request_id: str,
        spec: ProviderSpec,
        payload: dict[str, JSONValue],
        redaction: RedactionResult,
        started_at: float,
    ) -> AsyncIterator[bytes]:
        try:
            async for chunk in rehydrator.transform(upstream_response.aiter_bytes()):
                yield chunk
        finally:
            await upstream_response.aclose()
            self._record_event(
                request_id=request_id,
                spec=spec,
                payload=payload,
                result=redaction,
                stream=True,
                status_code=upstream_response.status_code,
                started_at=started_at,
                rehydration_count=rehydrator.rehydration_count,
            )
            self._record_unsafe_debug_trace(
                request_id=request_id,
                spec=spec,
                original_payload=payload,
                masked_payload=redaction.payload,
                response_upstream=rehydrator.masked_stream_text,
                response_rehydrated=rehydrator.rehydrated_stream_text,
                stream=True,
                status_code=upstream_response.status_code,
                outcome=_resolve_debug_outcome(redaction, upstream_response.status_code),
            )

    def _build_materialized_response(
        self,
        upstream_response: httpx.Response,
        raw_bytes: bytes,
        redaction: RedactionResult,
        debug_capture_bytes: int,
    ) -> tuple[Response, int, DebugValue, DebugValue]:
        headers = sanitize_response_headers(upstream_response.headers)
        content_type = upstream_response.headers.get("content-type", "")
        if "application/json" in content_type:
            headers.pop("content-type", None)
            headers.pop("Content-Type", None)
            try:
                parsed = json.loads(raw_bytes)
            except json.JSONDecodeError:
                parsed = None
            if parsed is not None:
                rehydration_count = count_rehydratable_placeholders(parsed, redaction.vault)
                rehydrated = self.redaction.rehydrate_payload(parsed, redaction.vault)
                return (
                    JSONResponse(
                        status_code=upstream_response.status_code,
                        content=rehydrated,
                        headers=headers,
                    ),
                    rehydration_count,
                    cap_debug_value(parsed, limit_bytes=debug_capture_bytes),
                    cap_debug_value(rehydrated, limit_bytes=debug_capture_bytes),
                )

        text = raw_bytes.decode("utf-8", errors="replace")
        rehydration_count = redaction.vault.count_occurrences(text)
        rehydrated_text = redaction.vault.rehydrate_text(text)
        headers.pop("content-type", None)
        headers.pop("Content-Type", None)
        return (
            Response(
                status_code=upstream_response.status_code,
                content=rehydrated_text,
                headers=headers,
                media_type=content_type or "text/plain",
            ),
            rehydration_count,
            cap_debug_value(text, limit_bytes=debug_capture_bytes),
            cap_debug_value(rehydrated_text, limit_bytes=debug_capture_bytes),
        )

    def build_debug_response(self, payload: JSONValue) -> JSONResponse:
        redaction = self.redaction.redact_payload(payload)
        response_payload: JSONValue | None
        if any(
            item.action in {PolicyAction.BLOCK, PolicyAction.ROUTE_LOCAL}
            for item in redaction.decisions
        ):
            response_payload = None
        else:
            response_payload = redaction.payload
        return JSONResponse(
            content={
                "payload": response_payload,
                "detections": [
                    {
                        "type": item.detector.value,
                        "action": item.action.value,
                        "path": item.path,
                        "placeholder": item.placeholder,
                    }
                    for item in redaction.decisions
                ],
                "audit": build_audit_summary(redaction),
                "payload_redacted": response_payload is None,
            }
        )

    def _error_response(
        self,
        spec: ProviderSpec,
        status_code: int,
        message: str,
        audit: dict[str, object] | None = None,
    ) -> JSONResponse:
        if spec.error_shape == "anthropic":
            content: dict[str, object] = {
                "type": "error",
                "error": {
                    "type": "privacy_policy_error",
                    "message": message,
                },
            }
            if audit is not None:
                content["audit"] = audit
            return JSONResponse(status_code=status_code, content=content)

        content = {
            "error": {
                "message": message,
                "type": "privacy_policy_error",
                "code": "privacy_policy_error",
            }
        }
        if audit is not None:
            content["audit"] = audit
        return JSONResponse(status_code=status_code, content=content)

    async def _audit_writer_loop(self) -> None:
        assert self.audit_store is not None
        assert self._audit_queue is not None
        pending_items: list[_QueuedAuditEvent | _QueuedAdminAccess] | None = None
        shutdown_requested = False
        while True:
            if pending_items is None:
                item = await self._audit_queue.get()
                if item is None:
                    return
                items: list[_QueuedAuditEvent | _QueuedAdminAccess] = [item]
                while len(items) < self.settings.audit_prune_interval:
                    try:
                        queued = self._audit_queue.get_nowait()
                    except asyncio.QueueEmpty:
                        break
                    if queued is None:
                        shutdown_requested = True
                        break
                    items.append(queued)
                pending_items = items

            try:
                await asyncio.to_thread(self._flush_audit_batch, pending_items)
            except Exception:
                logger.warning(
                    "Audit batch flush failed; retrying pending batch.",
                    exc_info=True,
                )
                await asyncio.sleep(0.05)
                continue

            pending_items = None
            if shutdown_requested:
                return

    def _flush_audit_batch(self, items: list[_QueuedAuditEvent | _QueuedAdminAccess]) -> None:
        if self.audit_store is None or not items:
            return
        events = [item.event for item in items if isinstance(item, _QueuedAuditEvent)]
        accesses = [item.record for item in items if isinstance(item, _QueuedAdminAccess)]
        self.audit_store.record_event_batch(events)
        self.audit_store.record_access_batch(accesses)

    def _enqueue_audit_write(self, item: _QueuedAuditEvent | _QueuedAdminAccess) -> None:
        if self.audit_store is None or self._audit_queue is None:
            return
        try:
            asyncio.get_running_loop()
        except RuntimeError:
            self._flush_audit_batch([item])
            return
        self._ensure_audit_worker()
        try:
            self._audit_queue.put_nowait(item)
        except asyncio.QueueFull:
            self._flush_audit_batch([item])

    def _record_event(
        self,
        *,
        request_id: str,
        spec: ProviderSpec,
        payload: JSONValue | None,
        result: RedactionResult | None,
        stream: bool,
        status_code: int,
        started_at: float,
        rehydration_count: int = 0,
        outcome: str | None = None,
    ) -> None:
        if self.audit_store is None:
            return
        latency_ms = max(int((time.perf_counter() - started_at) * 1000), 0)
        self._enqueue_audit_write(
            _QueuedAuditEvent(
                event=build_audit_event(
                    request_id=request_id,
                    spec=spec,
                    payload=payload,
                    result=result,
                    status_code=status_code,
                    stream=stream,
                    latency_ms=latency_ms,
                    rehydration_count=rehydration_count,
                    outcome=outcome,
                )
            )
        )

    def _record_unsafe_debug_trace(
        self,
        *,
        request_id: str,
        spec: ProviderSpec,
        original_payload: DebugValue,
        masked_payload: DebugValue,
        response_upstream: DebugValue,
        response_rehydrated: DebugValue,
        stream: bool,
        status_code: int,
        outcome: str,
    ) -> None:
        if self.unsafe_debug_store is None:
            return
        self.unsafe_debug_store.record(
            UnsafeDebugTraceRecord(
                request_id=request_id,
                created_at=datetime.now(UTC).isoformat(),
                provider=spec.name,
                endpoint=spec.public_path,
                model=_debug_extract_model(original_payload),
                stream=stream,
                outcome=outcome,
                status_code=status_code,
                request_original=original_payload,
                request_masked=masked_payload,
                response_upstream=response_upstream,
                response_rehydrated=response_rehydrated,
            )
        )

    def list_unsafe_debug_traces(self, *, limit: int = 20) -> list[UnsafeDebugTraceRecord]:
        if self.unsafe_debug_store is None:
            return []
        bounded_limit = min(max(limit, 1), 100)
        return self.unsafe_debug_store.list(limit=bounded_limit)

    def get_unsafe_debug_trace(self, request_id: str) -> UnsafeDebugTraceRecord | None:
        if self.unsafe_debug_store is None:
            return None
        return self.unsafe_debug_store.get(request_id)

    def record_admin_access(
        self,
        *,
        actor: str,
        roles: tuple[str, ...],
        request: Request,
        status_code: int,
    ) -> None:
        if self.audit_store is None:
            return
        self._enqueue_audit_write(
            _QueuedAdminAccess(
                record=AdminAccessRecord(
                    created_at=datetime.now(UTC).isoformat(),
                    actor=actor,
                    roles=roles,
                    path=request.url.path,
                    method=request.method,
                    status_code=status_code,
                    source_ip=_resolve_admin_source_ip(request),
                )
            )
        )

    def _decode_websocket_receive_message(self, message: dict[str, object]) -> str | None:
        if message["type"] == "websocket.disconnect":
            code = message.get("code", 1000)
            raise WebSocketDisconnect(code if isinstance(code, int) else 1000)
        if message["type"] != "websocket.receive":
            return None
        text = message.get("text")
        if text is not None:
            decoded = str(text)
            if len(decoded.encode("utf-8")) > self.settings.websocket_frame_byte_cap:
                raise ResponsesWebsocketError(
                    status_code=413,
                    message="WebSocket frame exceeds configured privacy boundary limit.",
                    error_type="invalid_websocket_frame",
                )
            return decoded
        payload = message.get("bytes")
        if payload is None:
            return None
        raise ValueError("binary websocket frames are not supported")

    async def _send_terminal_websocket_text(
        self,
        websocket: WebSocket,
        text: str,
    ) -> bool:
        try:
            await websocket.send_text(text)
        except WebSocketDisconnect:
            return False
        return True

    async def _send_websocket_error(
        self,
        websocket: WebSocket,
        *,
        status_code: int,
        message: str,
        error_type: str = "privacy_policy_error",
    ) -> None:
        await websocket.send_text(
            json.dumps(
                self._build_websocket_error_payload(
                    status_code=status_code,
                    message=message,
                    error_type=error_type,
                ),
                ensure_ascii=False,
                separators=(",", ":"),
            )
        )

    def _build_websocket_error_payload(
        self,
        *,
        status_code: int,
        message: str,
        error_type: str = "privacy_policy_error",
    ) -> dict[str, JSONValue]:
        return {
            "type": "error",
            "status": status_code,
            "error": {
                "type": error_type,
                "message": message,
            },
        }

    def _extract_upstream_error_message(self, raw_bytes: bytes) -> str:
        try:
            parsed = json.loads(raw_bytes)
        except json.JSONDecodeError:
            text = raw_bytes.decode("utf-8", errors="replace").strip()
            return text or "Upstream returned an error for the websocket response request."

        if isinstance(parsed, dict):
            error = parsed.get("error")
            if isinstance(error, dict):
                message = error.get("message")
                if isinstance(message, str) and message.strip():
                    return message.strip()
            message = parsed.get("message")
            if isinstance(message, str) and message.strip():
                return message.strip()
        return "Upstream returned an error for the websocket response request."

    def _resolve_websocket_session(
        self,
        websocket: WebSocket,
    ) -> tuple[str, ResponsesWebsocketSession, str]:
        self._purge_websocket_sessions()
        provided_turn_state = websocket.headers.get("x-codex-turn-state")
        turn_state = ""
        if provided_turn_state is not None:
            turn_state = self._validate_turn_state(provided_turn_state)
        if not turn_state:
            turn_state = secrets.token_urlsafe(18)

        session = self.websocket_turn_sessions.get(turn_state)
        if session is None:
            if len(self.websocket_turn_sessions) >= self.settings.websocket_active_session_cap:
                raise ResponsesWebsocketError(
                    status_code=503,
                    message="WebSocket session capacity exceeded.",
                    error_type="invalid_websocket_turn",
                )
            session = ResponsesWebsocketSession()
            self.websocket_turn_sessions[turn_state] = session
        owner_token = secrets.token_hex(8)
        if not session.try_acquire_owner(owner_token):
            raise ResponsesWebsocketError(
                status_code=409,
                message="WebSocket turn is already active on another connection.",
                error_type="invalid_websocket_turn",
            )
        return turn_state, session, owner_token

    def _purge_websocket_sessions(self) -> None:
        now = time.monotonic()
        expired_turn_states = [
            turn_state
            for turn_state, session in self.websocket_turn_sessions.items()
            if (
                session.active_owner_token is None
                and now - session.updated_at > self.websocket_turn_state_ttl_seconds
            )
        ]
        for turn_state in expired_turn_states:
            self.websocket_turn_sessions.pop(turn_state, None)

    def _validate_turn_state(self, raw_turn_state: str) -> str:
        turn_state = raw_turn_state.strip()
        if not turn_state:
            return ""
        if len(turn_state) > self.settings.websocket_turn_state_max_length:
            raise ResponsesWebsocketError(
                status_code=400,
                message="Invalid x-codex-turn-state header.",
                error_type="invalid_websocket_turn",
            )
        if not TURN_STATE_RE.fullmatch(turn_state):
            raise ResponsesWebsocketError(
                status_code=400,
                message="Invalid x-codex-turn-state header.",
                error_type="invalid_websocket_turn",
            )
        return turn_state


def _debug_extract_model(value: DebugValue) -> str | None:
    if not isinstance(value, dict):
        return None
    model = value.get("model")
    return model if isinstance(model, str) and model else None


def _debug_value_from_bytes(raw_bytes: bytes | memoryview) -> DebugValue:
    raw = raw_bytes.tobytes() if isinstance(raw_bytes, memoryview) else raw_bytes
    try:
        return cast(DebugValue, json.loads(raw))
    except json.JSONDecodeError:
        return raw.decode("utf-8", errors="replace")


def _resolve_debug_outcome(result: RedactionResult, status_code: int) -> str:
    if result.blocked:
        return "blocked"
    if result.route_local:
        return "route_local"
    if status_code >= 500:
        return "upstream_error"
    if status_code >= 400:
        return "upstream_rejection"
    if result.masked:
        return "masked"
    return "forwarded"


def _try_parse_debug_json(raw_text: str) -> DebugValue:
    try:
        return cast(DebugValue, json.loads(raw_text))
    except json.JSONDecodeError:
        return raw_text


def _resolve_admin_source_ip(request: Request) -> str | None:
    if request.client is not None:
        return request.client.host
    return None
