from __future__ import annotations

import asyncio
import inspect
import json
import os
from collections.abc import Callable
from dataclasses import dataclass, field
from datetime import UTC, datetime
from pathlib import Path
from threading import Thread
from typing import Any

import httpx

from stronk_mask.admin.materialize import materialize_bundle
from stronk_mask.admin.operator_state import OperatorState, iter_published_aliases
from stronk_mask.admin.operator_state_store import OperatorStateStore, atomic_write_bytes
from stronk_mask.admin.secrets import (
    load_env_file,
    resolve_secret_ref,
    sync_secret_into_env_file,
)

RELOAD_WAIT_SECONDS = 1.0
HEALTHCHECK_TIMEOUT_SECONDS = 5.0
HEALTHCHECK_RETRIES = 3
HEALTHCHECK_RETRY_DELAY_SECONDS = 1.0
DOCKER_SOCKET_PATH = Path("/var/run/docker.sock")
DOCKER_API_BASE_URL = "http://docker"
DOCKER_COMPOSE_PROJECT_LABEL = "com.docker.compose.project"
DOCKER_COMPOSE_SERVICE_LABEL = "com.docker.compose.service"
CLIPROXY_SERVICE_NAME = "cliproxyapi"


@dataclass
class ApplyStep:
    name: str
    status: str = "pending"
    message: str | None = None

    def to_payload(self) -> dict[str, object]:
        return {
            "name": self.name,
            "status": self.status,
            "message": self.message,
        }


@dataclass
class ApplyJob:
    job_id: str
    status: str = "running"
    steps: list[ApplyStep] = field(
        default_factory=lambda: [
            ApplyStep("validate_draft"),
            ApplyStep("backup"),
            ApplyStep("promote_draft"),
            ApplyStep("materialize"),
            ApplyStep("reload"),
            ApplyStep("health_check"),
        ]
    )
    error: str | None = None
    rollback_available: bool = False
    backup_paths: dict[str, str | None] = field(default_factory=dict)
    finished_at: str | None = None

    def to_payload(self) -> dict[str, object]:
        return {
            "job_id": self.job_id,
            "status": self.status,
            "steps": [step.to_payload() for step in self.steps],
            "error": self.error,
            "rollback_available": self.rollback_available,
            "finished_at": self.finished_at,
        }


class ApplyManager:
    def __init__(
        self,
        *,
        store: OperatorStateStore,
        bundle_env_path: Path,
        generated_dir: Path,
        secrets_dir: Path | None,
        public_healthcheck_base_url: str | None = None,
        outbound_transport: httpx.AsyncBaseTransport | None = None,
        reload_wait_seconds: float = RELOAD_WAIT_SECONDS,
        healthcheck_timeout_seconds: float = HEALTHCHECK_TIMEOUT_SECONDS,
        healthcheck_retries: int = HEALTHCHECK_RETRIES,
        healthcheck_retry_delay_seconds: float = HEALTHCHECK_RETRY_DELAY_SECONDS,
        restart_hook: Callable[[], Any] | None = None,
    ) -> None:
        self.store = store
        self.bundle_env_path = bundle_env_path
        self.generated_dir = generated_dir
        self.secrets_dir = secrets_dir
        self.public_healthcheck_base_url = (
            public_healthcheck_base_url.strip() if public_healthcheck_base_url else None
        )
        self.outbound_transport = outbound_transport
        self.reload_wait_seconds = reload_wait_seconds
        self.healthcheck_timeout_seconds = healthcheck_timeout_seconds
        self.healthcheck_retries = healthcheck_retries
        self.healthcheck_retry_delay_seconds = healthcheck_retry_delay_seconds
        self.restart_hook = restart_hook or _default_restart_hook
        self._jobs: dict[str, ApplyJob] = {}
        self._job_counter = 0
        self._active_job_id: str | None = None
        self._lock = asyncio.Lock()

    async def start_apply(self) -> ApplyJob:
        async with self._lock:
            if self._active_job_id is not None:
                running = self._jobs[self._active_job_id]
                raise ApplyConflictError(running.job_id)
            self._job_counter += 1
            job_id = f"apply-{self._job_counter:04d}"
            job = ApplyJob(job_id=job_id)
            self._jobs[job_id] = job
            self._active_job_id = job_id
            worker = Thread(
                target=self._run_apply_in_thread,
                args=(job,),
                daemon=True,
            )
            worker.start()
            return job

    def get_job(self, job_id: str) -> ApplyJob:
        job = self._jobs.get(job_id)
        if job is None:
            raise ApplyNotFoundError(job_id)
        return job

    async def rollback(self, job_id: str) -> ApplyJob:
        job = self.get_job(job_id)
        if not job.rollback_available:
            raise ApplyRollbackError("rollback is not available for this apply job")
        await self._restore_backups(job)
        restored_state = self.store.load_active_state()
        await self._restart_and_probe(restored_state)
        job.status = "rolled_back"
        job.finished_at = _now_iso()
        return job

    async def _run_apply(self, job: ApplyJob) -> None:
        draft_bytes = self.store.draft_path.read_bytes() if self.store.draft_path.exists() else None
        validated_state: OperatorState | None = None
        staged_env_updates: dict[str, str] = {}
        runtime_changed = False
        try:
            validated_state, staged_env_updates = await self._validate_draft(job)
            backups = await self._backup_active_files(job)
            self._stage_env_updates(staged_env_updates)
            self._set_step(job, "promote_draft", "running")
            self.store.promote_draft()
            runtime_changed = True
            self._set_step(job, "promote_draft", "pass")
            self._set_step(job, "materialize", "running")
            materialize_bundle(
                state=validated_state,
                bundle_env_path=self.bundle_env_path,
                generated_dir=self.generated_dir,
            )
            self._set_step(job, "materialize", "pass")
            self._set_step(job, "reload", "running")
            await asyncio.sleep(self.reload_wait_seconds)
            self._set_step(job, "reload", "pass")
            self._set_step(job, "health_check", "running")
            await self._health_check(validated_state)
            self._set_step(job, "health_check", "pass")
            job.status = "success"
            job.rollback_available = bool(backups)
        except Exception as exc:
            rollback_error: Exception | None = None
            try:
                await self._restore_backups(job)
                if draft_bytes is not None:
                    atomic_write_bytes(self.store.draft_path, draft_bytes)
                if runtime_changed and job.backup_paths:
                    restored_state = self.store.load_active_state()
                    await self._restart_and_probe(restored_state)
            except Exception as restore_exc:
                rollback_error = restore_exc
            job.error = str(rollback_error or exc)
            job.status = "failed"
            active_step = _active_step(job)
            if active_step is not None and active_step.status == "running":
                active_step.status = "fail"
                active_step.message = job.error
        finally:
            job.finished_at = _now_iso()
            self._active_job_id = None

    def _run_apply_in_thread(self, job: ApplyJob) -> None:
        asyncio.run(self._run_apply(job))

    async def _validate_draft(self, job: ApplyJob) -> tuple[OperatorState, dict[str, str]]:
        self._set_step(job, "validate_draft", "running")
        if not self.store.draft_path.exists():
            raise ApplyRollbackError("draft config does not exist")
        state = self.store.load_current_state()
        staged_env_updates: dict[str, str] = {}
        for provider in state.providers:
            if provider.secret_ref:
                secret_value, resolution = resolve_secret_ref(
                    provider.secret_ref,
                    env_path=self.bundle_env_path,
                    secrets_dir=self.secrets_dir,
                )
                if secret_value is None:
                    raise ApplyRollbackError(
                        f"provider {provider.id} secret_ref {resolution.name} could not be resolved"
                    )
                if resolution.source == "file":
                    staged_env_updates[resolution.name] = secret_value
        public_api_key, public_resolution = resolve_secret_ref(
            "STRONK_GATEWAY_PUBLIC_API_KEY",
            env_path=self.bundle_env_path,
            secrets_dir=self.secrets_dir,
        )
        if public_api_key is None:
            raise ApplyRollbackError(
                f"gateway public API key {public_resolution.name} could not be resolved"
            )
        if public_resolution.source == "file":
            staged_env_updates[public_resolution.name] = public_api_key
        self._set_step(job, "validate_draft", "pass")
        return state, staged_env_updates

    async def _backup_active_files(self, job: ApplyJob) -> dict[str, str | None]:
        self._set_step(job, "backup", "running")
        backup_map: dict[str, str | None] = {}
        for path in _backup_targets(self.store, self.bundle_env_path, self.generated_dir):
            if not path.exists():
                backup_map[str(path)] = None
                continue
            backup_path = path.with_name(f"{path.name}.bak.{_now_iso()}")
            backup_path.write_bytes(path.read_bytes())
            backup_map[str(path)] = str(backup_path)
        job.backup_paths = backup_map
        job.rollback_available = bool(backup_map)
        self._set_step(job, "backup", "pass")
        return backup_map

    async def _restore_backups(self, job: ApplyJob) -> None:
        for original_text, backup_text in job.backup_paths.items():
            original = Path(original_text)
            if backup_text is None:
                if original.exists():
                    original.unlink()
                continue
            backup = Path(backup_text)
            if not backup.exists():
                continue
            atomic_write_bytes(original, backup.read_bytes())

    def _stage_env_updates(self, updates: dict[str, str]) -> None:
        for secret_ref, value in updates.items():
            sync_secret_into_env_file(
                self.bundle_env_path,
                secret_ref=secret_ref,
                value=value,
            )

    async def _restart_and_probe(self, state: OperatorState) -> None:
        await self._invoke_restart_hook()
        await self._health_check(state)

    async def _health_check(self, state: OperatorState) -> None:
        env_values = load_env_file(self.bundle_env_path)
        public_api_key = env_values.get("STRONK_GATEWAY_PUBLIC_API_KEY", "").strip()
        public_base_url = self.public_healthcheck_base_url or env_values.get(
            "STRONK_GATEWAY_PUBLIC_BASE_URL", ""
        ).strip()
        if not public_base_url:
            port = env_values.get("STRONK_GATEWAY_PUBLIC_HTTP_PORT", "").strip()
            if not port:
                raise ApplyRollbackError("STRONK_GATEWAY_PUBLIC_HTTP_PORT is required")
            public_base_url = f"http://127.0.0.1:{port}/v1"
        expected_aliases = set(iter_published_aliases(state))
        headers = {"Authorization": f"Bearer {public_api_key}", "Accept": "application/json"}
        await self._probe_health(
            base_url=public_base_url,
            expected_aliases=expected_aliases,
            headers=headers,
        )

    async def _probe_health(
        self,
        *,
        base_url: str,
        expected_aliases: set[str],
        headers: dict[str, str],
    ) -> None:
        last_error: str | None = None
        async with httpx.AsyncClient(
            follow_redirects=False,
            timeout=self.healthcheck_timeout_seconds,
            trust_env=False,
            transport=self.outbound_transport,
        ) as client:
            for attempt in range(self.healthcheck_retries):
                try:
                    response = await client.get(
                        f"{base_url.rstrip('/')}/models",
                        headers=headers,
                    )
                    if response.status_code == 401:
                        raise ApplyRollbackError("health-check returned 401")
                    response.raise_for_status()
                    payload = response.json()
                    if not isinstance(payload, dict) or not isinstance(payload.get("data"), list):
                        raise ApplyRollbackError("health-check returned invalid /v1/models payload")
                    aliases = {
                        str(item.get("id", "")).strip()
                        for item in payload["data"]
                        if isinstance(item, dict)
                    }
                    if expected_aliases and not expected_aliases.issubset(aliases):
                        raise ApplyRollbackError("health-check missing expected model aliases")
                    return
                except Exception as exc:
                    last_error = str(exc)
                    if attempt + 1 >= self.healthcheck_retries:
                        break
                    await asyncio.sleep(self.healthcheck_retry_delay_seconds)
        await self._invoke_restart_hook()
        last_error = None
        async with httpx.AsyncClient(
            follow_redirects=False,
            timeout=self.healthcheck_timeout_seconds,
            trust_env=False,
            transport=self.outbound_transport,
        ) as client:
            for attempt in range(self.healthcheck_retries):
                try:
                    response = await client.get(
                        f"{base_url.rstrip('/')}/models",
                        headers=headers,
                    )
                    if response.status_code == 401:
                        raise ApplyRollbackError("health-check returned 401")
                    response.raise_for_status()
                    payload = response.json()
                    if not isinstance(payload, dict) or not isinstance(payload.get("data"), list):
                        raise ApplyRollbackError("health-check returned invalid /v1/models payload")
                    aliases = {
                        str(item.get("id", "")).strip()
                        for item in payload["data"]
                        if isinstance(item, dict)
                    }
                    if expected_aliases and not expected_aliases.issubset(aliases):
                        raise ApplyRollbackError("health-check missing expected model aliases")
                    return
                except Exception as exc:
                    last_error = str(exc)
                    if attempt + 1 >= self.healthcheck_retries:
                        break
                    await asyncio.sleep(self.healthcheck_retry_delay_seconds)
        raise ApplyRollbackError(last_error or "health-check failed")

    async def _invoke_restart_hook(self) -> None:
        result = self.restart_hook()
        if inspect.isawaitable(result):
            await result

    def _set_step(self, job: ApplyJob, name: str, status: str, message: str | None = None) -> None:
        for step in job.steps:
            if step.name == name:
                step.status = status
                step.message = message
                return
        raise ApplyRollbackError(f"unknown apply step {name}")


class ApplyConflictError(RuntimeError):
    def __init__(self, job_id: str) -> None:
        super().__init__(f"apply already running: {job_id}")
        self.job_id = job_id


class ApplyNotFoundError(RuntimeError):
    pass


class ApplyRollbackError(RuntimeError):
    pass


async def _default_restart_hook() -> None:
    project_name = os.environ.get("COMPOSE_PROJECT_NAME", "").strip()
    if not project_name:
        raise ApplyRollbackError(
            "COMPOSE_PROJECT_NAME is required for the cliproxyapi restart hook"
        )
    if not DOCKER_SOCKET_PATH.exists():
        raise ApplyRollbackError("docker socket is required for the cliproxyapi restart hook")

    filters = json.dumps(
        {
            "label": [
                f"{DOCKER_COMPOSE_PROJECT_LABEL}={project_name}",
                f"{DOCKER_COMPOSE_SERVICE_LABEL}={CLIPROXY_SERVICE_NAME}",
            ]
        }
    )
    transport = httpx.AsyncHTTPTransport(uds=str(DOCKER_SOCKET_PATH))
    async with httpx.AsyncClient(
        base_url=DOCKER_API_BASE_URL,
        transport=transport,
        timeout=5.0,
        trust_env=False,
    ) as client:
        response = await client.get("/containers/json", params={"filters": filters})
        response.raise_for_status()
        payload = response.json()
        if not isinstance(payload, list):
            raise ApplyRollbackError("docker restart hook returned an invalid container list")
        if len(payload) != 1:
            raise ApplyRollbackError(
                "expected exactly 1 cliproxyapi container for project "
                f"{project_name}, found {len(payload)}"
            )
        container_id = str(payload[0].get("Id", "")).strip()
        if not container_id:
            raise ApplyRollbackError(
                "docker restart hook could not resolve the cliproxyapi container id"
            )
        restart_response = await client.post(f"/containers/{container_id}/restart", params={"t": 5})
        if restart_response.status_code == 204:
            return
        detail = restart_response.text.strip()
        if detail:
            raise ApplyRollbackError(f"cliproxyapi restart failed: {detail}")
        raise ApplyRollbackError(
            f"cliproxyapi restart failed with status code {restart_response.status_code}"
        )


def _now_iso() -> str:
    return datetime.now(UTC).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def _active_step(job: ApplyJob) -> ApplyStep | None:
    for step in job.steps:
        if step.status == "running":
            return step
    return None


def _backup_targets(
    store: OperatorStateStore,
    bundle_env_path: Path,
    generated_dir: Path,
) -> tuple[Path, ...]:
    return (
        store.active_path,
        bundle_env_path,
        generated_dir / "cliproxy-config.yaml",
        generated_dir / "materialization-summary.json",
        generated_dir / "doctor-report.json",
        generated_dir / "hermes-connect.json",
    )
