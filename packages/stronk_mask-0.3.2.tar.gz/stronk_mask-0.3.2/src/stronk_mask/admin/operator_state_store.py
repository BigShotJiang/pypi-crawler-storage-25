from __future__ import annotations

import json
from dataclasses import replace
from datetime import UTC, datetime
from pathlib import Path
from tempfile import NamedTemporaryFile

from stronk_mask.admin.operator_state import (
    OperatorState,
    PrivacyPolicy,
    Provider,
    ProviderModel,
    create_empty_operator_state,
    load_operator_state,
    normalize_provider_base_url,
    normalize_provider_secret_ref,
    parse_operator_state,
    slugify_identifier,
    validate_operator_state,
)


class OperatorStateStoreError(ValueError):
    pass


def backup_suffix() -> str:
    return datetime.now(UTC).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def atomic_write_bytes(path: Path, payload: bytes) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with NamedTemporaryFile(
        "wb",
        dir=path.parent,
        prefix=f".{path.name}.",
        suffix=".tmp",
        delete=False,
    ) as handle:
        handle.write(payload)
        temp_path = Path(handle.name)
    temp_path.replace(path)


class OperatorStateStore:
    def __init__(self, config_dir: Path) -> None:
        self.config_dir = config_dir
        self.config_dir.mkdir(parents=True, exist_ok=True)
        self.active_path = self.config_dir / "operator-objects.json"
        self.draft_path = self.config_dir / "operator-objects.draft.json"
        self.ssrf_allowlist_path = self.config_dir / "ssrf-allowlist.json"

    def load_active_state(self) -> OperatorState:
        if self.active_path.exists():
            return load_operator_state(self.active_path)
        if self.draft_path.exists():
            return load_operator_state(self.draft_path)
        return create_empty_operator_state()

    def load_current_state(self) -> OperatorState:
        if self.draft_path.exists():
            return load_operator_state(self.draft_path)
        return self.load_active_state()

    def load_current_payload(self) -> dict[str, object]:
        return self.load_current_state().to_dict()

    def ensure_draft(self) -> OperatorState:
        if self.draft_path.exists():
            return load_operator_state(self.draft_path)
        if self.active_path.exists():
            self._copy_file(self.active_path, self.draft_path)
            return load_operator_state(self.draft_path)
        state = create_empty_operator_state()
        self.write_draft(state)
        return state

    def write_draft(self, state: OperatorState) -> None:
        validate_operator_state(state)
        self._atomic_write_json(self.draft_path, state.to_dict())

    def write_active(self, state: OperatorState) -> None:
        validate_operator_state(state)
        self._atomic_write_json(self.active_path, state.to_dict())

    def create_provider(self, payload: dict[str, object]) -> Provider:
        state = self.ensure_draft()
        if "cliproxy_provider_name" in payload or "id" in payload or "models" in payload:
            raise OperatorStateStoreError(
                "providers are created from label/kind/base_url/secret_ref only"
            )
        label = _require_payload_string(payload, "label")
        provider_id = self._provider_id_for_label(label)
        provider = Provider(
            id=provider_id,
            label=label,
            kind=_require_kind(payload.get("kind")),
            base_url=normalize_provider_base_url(payload.get("base_url")),
            secret_ref=normalize_provider_secret_ref(payload.get("secret_ref")),
            cliproxy_provider_name=provider_id,
            models=tuple(),
        )
        if any(existing.id == provider.id for existing in state.providers):
            raise OperatorStateStoreError(f"provider {provider.id} already exists")
        updated = replace(state, providers=state.providers + (provider,))
        validate_operator_state(updated)
        self.write_draft(updated)
        return provider

    def update_provider(self, provider_id: str, payload: dict[str, object]) -> Provider:
        forbidden = {"id", "kind", "cliproxy_provider_name", "models"}
        if forbidden.intersection(payload):
            raise OperatorStateStoreError(
                "provider id, kind, models, and cliproxy_provider_name are immutable"
            )
        state = self.ensure_draft()
        updated_providers: list[Provider] = []
        updated_provider: Provider | None = None
        for provider in state.providers:
            if provider.id != provider_id:
                updated_providers.append(provider)
                continue
            updated_provider = replace(
                provider,
                label=_optional_payload_string(payload, "label") or provider.label,
                base_url=normalize_provider_base_url(payload["base_url"])
                if "base_url" in payload
                else provider.base_url,
                secret_ref=normalize_provider_secret_ref(payload["secret_ref"])
                if "secret_ref" in payload
                else provider.secret_ref,
            )
            updated_providers.append(updated_provider)
        if updated_provider is None:
            raise OperatorStateStoreError(f"provider {provider_id} not found")
        updated = replace(state, providers=tuple(updated_providers))
        validate_operator_state(updated)
        self.write_draft(updated)
        return updated_provider

    def delete_provider(self, provider_id: str) -> None:
        state = self.ensure_draft()
        filtered = tuple(provider for provider in state.providers if provider.id != provider_id)
        if len(filtered) == len(state.providers):
            raise OperatorStateStoreError(f"provider {provider_id} not found")
        self.write_draft(replace(state, providers=filtered))

    def create_model(self, provider_id: str, payload: dict[str, object]) -> ProviderModel:
        state = self.ensure_draft()
        forbidden = {"provider_id"}
        if forbidden.intersection(payload):
            raise OperatorStateStoreError("provider_id is derived from the URL path")
        upstream_id = _require_payload_string(payload, "upstream_id")
        public_alias = _optional_public_alias(payload.get("public_alias"))
        privacy_policy_id = _require_payload_string(payload, "privacy_policy_id")
        enabled = _optional_enabled(payload.get("enabled"), default=True)
        if privacy_policy_id not in {policy.id for policy in state.privacy_policies}:
            raise OperatorStateStoreError(f"privacy_policy_id {privacy_policy_id} not found")
        model = ProviderModel(
            upstream_id=upstream_id,
            public_alias=public_alias,
            privacy_policy_id=privacy_policy_id,
            enabled=enabled,
        )
        updated_providers: list[Provider] = []
        found = False
        for provider in state.providers:
            if provider.id != provider_id:
                updated_providers.append(provider)
                continue
            found = True
            if any(existing.upstream_id == upstream_id for existing in provider.models):
                raise OperatorStateStoreError(
                    f"provider {provider_id} model {upstream_id} already exists"
                )
            updated_providers.append(replace(provider, models=provider.models + (model,)))
        if not found:
            raise OperatorStateStoreError(f"provider {provider_id} not found")
        updated = replace(state, providers=tuple(updated_providers))
        validate_operator_state(updated)
        self.write_draft(updated)
        return model

    def update_model(
        self,
        provider_id: str,
        upstream_id: str,
        payload: dict[str, object],
    ) -> ProviderModel:
        state = self.ensure_draft()
        updated_model: ProviderModel | None = None
        updated_providers: list[Provider] = []
        found_provider = False
        for provider in state.providers:
            if provider.id != provider_id:
                updated_providers.append(provider)
                continue
            found_provider = True
            models: list[ProviderModel] = []
            for model in provider.models:
                if model.upstream_id != upstream_id:
                    models.append(model)
                    continue
                if "upstream_id" in payload and str(payload["upstream_id"]).strip() != upstream_id:
                    raise OperatorStateStoreError("upstream_id is immutable")
                updated_model = replace(
                    model,
                    public_alias=(
                        _optional_public_alias(payload.get("public_alias"))
                        if "public_alias" in payload
                        else model.public_alias
                    ),
                    privacy_policy_id=(
                        _require_payload_string(payload, "privacy_policy_id")
                        if "privacy_policy_id" in payload
                        else model.privacy_policy_id
                    ),
                    enabled=(
                        _optional_enabled(payload.get("enabled"), default=model.enabled)
                        if "enabled" in payload
                        else model.enabled
                    ),
                )
                models.append(updated_model)
            updated_providers.append(replace(provider, models=tuple(models)))
        if not found_provider:
            raise OperatorStateStoreError(f"provider {provider_id} not found")
        if updated_model is None:
            raise OperatorStateStoreError(f"provider {provider_id} model {upstream_id} not found")
        updated = replace(state, providers=tuple(updated_providers))
        validate_operator_state(updated)
        self.write_draft(updated)
        return updated_model

    def delete_model(self, provider_id: str, upstream_id: str) -> None:
        state = self.ensure_draft()
        updated_providers: list[Provider] = []
        found_provider = False
        deleted = False
        for provider in state.providers:
            if provider.id != provider_id:
                updated_providers.append(provider)
                continue
            found_provider = True
            models = tuple(model for model in provider.models if model.upstream_id != upstream_id)
            deleted = len(models) != len(provider.models)
            updated_providers.append(replace(provider, models=models))
        if not found_provider:
            raise OperatorStateStoreError(f"provider {provider_id} not found")
        if not deleted:
            raise OperatorStateStoreError(f"provider {provider_id} model {upstream_id} not found")
        updated = replace(state, providers=tuple(updated_providers))
        validate_operator_state(updated)
        self.write_draft(updated)

    def promote_draft(self) -> None:
        if not self.draft_path.exists():
            raise OperatorStateStoreError("draft config does not exist")
        self.draft_path.replace(self.active_path)

    def backup_active(self) -> Path | None:
        if not self.active_path.exists():
            return None
        target = self.active_path.with_name(f"{self.active_path.name}.bak.{backup_suffix()}")
        self._copy_file(self.active_path, target)
        return target

    def clone_policies_from_active(self) -> tuple[PrivacyPolicy, ...]:
        current = self.load_current_state()
        return current.privacy_policies

    def parse_raw_payload(self, payload: dict[str, object]) -> OperatorState:
        return parse_operator_state(payload)

    def _provider_id_for_label(self, label: str) -> str:
        return slugify_identifier(label)

    def _copy_file(self, source: Path, target: Path) -> None:
        atomic_write_bytes(target, source.read_bytes())

    def _atomic_write_json(self, path: Path, payload: dict[str, object]) -> None:
        rendered = json.dumps(payload, indent=2) + "\n"
        atomic_write_bytes(path, rendered.encode("utf-8"))


def _require_payload_string(payload: dict[str, object], key: str) -> str:
    value = payload.get(key)
    if not isinstance(value, str) or not value.strip():
        raise OperatorStateStoreError(f"{key} must be a non-empty string")
    return value.strip()


def _optional_payload_string(payload: dict[str, object], key: str) -> str | None:
    if key not in payload:
        return None
    value = payload[key]
    if value is None:
        return None
    if not isinstance(value, str) or not value.strip():
        raise OperatorStateStoreError(f"{key} must be a non-empty string")
    return value.strip()


def _require_kind(value: object) -> str:
    if not isinstance(value, str) or value.strip() != "openai_compat":
        raise OperatorStateStoreError("kind must be openai_compat")
    return value.strip()


def _optional_public_alias(value: object) -> str | None:
    if value is None:
        return None
    if not isinstance(value, str):
        raise OperatorStateStoreError("public_alias must be a string or null")
    cleaned = value.strip()
    if not cleaned:
        return None
    return slugify_identifier(cleaned)


def _optional_enabled(value: object, *, default: bool) -> bool:
    if value is None:
        return default
    if not isinstance(value, bool):
        raise OperatorStateStoreError("enabled must be a boolean")
    return value
