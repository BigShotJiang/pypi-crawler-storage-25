from __future__ import annotations

import ipaddress
import json
import re
import socket
import time
from collections.abc import Iterable
from dataclasses import dataclass
from pathlib import Path
from typing import Protocol
from urllib.parse import urljoin, urlparse

import httpcore
import httpx
from httpcore._backends.anyio import AnyIOBackend
from httpcore._backends.base import SOCKET_OPTION, AsyncNetworkStream

MAX_RESPONSE_BYTES = 1_048_576
DEFAULT_TIMEOUT_SECONDS = 10.0
BLOCKED_HOSTNAMES = {
    "localhost",
    "localhost.localdomain",
    "metadata.google.internal",
}
LOCAL_HOSTS = {"localhost", "127.0.0.1", "::1"}
NUMERIC_HOST_PART_RE = re.compile(r"^(?:0x[0-9a-f]+|[0-9]+)$", re.IGNORECASE)


class HostResolver(Protocol):
    def __call__(self, hostname: str) -> list[str]: ...


class SsrfBlockedError(ValueError):
    pass


IPAddress = ipaddress.IPv4Address | ipaddress.IPv6Address


@dataclass(frozen=True)
class ResolvedTarget:
    base_url: str
    hostname: str
    addresses: tuple[str, ...]
    allowlist: tuple[str, ...]


class PinnedAddressBackend(AnyIOBackend):
    def __init__(self, *, hostname: str, addresses: tuple[str, ...]) -> None:
        self.hostname = normalize_hostname(hostname)
        self.addresses = addresses

    async def connect_tcp(
        self,
        host: str,
        port: int,
        timeout: float | None = None,
        local_address: str | None = None,
        socket_options: Iterable[SOCKET_OPTION] | None = None,
    ) -> AsyncNetworkStream:
        if normalize_hostname(host) != self.hostname:
            raise httpcore.ConnectError(f"unexpected host {host!r} for pinned transport")
        if not self.addresses:
            raise httpcore.ConnectError(f"no validated addresses available for {self.hostname}")
        last_error: Exception | None = None
        for address in self.addresses:
            try:
                return await super().connect_tcp(
                    host=address,
                    port=port,
                    timeout=timeout,
                    local_address=local_address,
                    socket_options=socket_options,
                )
            except (httpcore.ConnectError, httpcore.ConnectTimeout) as exc:
                last_error = exc
        if last_error is not None:
            raise last_error
        raise httpcore.ConnectError(f"unable to connect to validated addresses for {self.hostname}")


class PinnedAddressTransport(httpx.AsyncHTTPTransport):
    def __init__(self, target: ResolvedTarget) -> None:
        super().__init__(trust_env=False)
        self._pool._network_backend = PinnedAddressBackend(
            hostname=target.hostname,
            addresses=target.addresses,
        )


def normalize_hostname(value: str) -> str:
    return value.strip().lower().rstrip(".")


def load_host_allowlist(path: Path | None) -> tuple[str, ...]:
    if path is None or not path.exists():
        return tuple()
    raw = json.loads(path.read_text(encoding="utf-8"))
    values: list[str]
    if isinstance(raw, list):
        values = [str(item) for item in raw]
    elif isinstance(raw, dict):
        raw_items = raw.get("allowed_hosts", [])
        if not isinstance(raw_items, list):
            raise SsrfBlockedError("ssrf-allowlist.json must contain allowed_hosts as a list")
        values = [str(item) for item in raw_items]
    else:
        raise SsrfBlockedError("ssrf-allowlist.json must be a list or object")
    return tuple(normalize_hostname(item) for item in values if normalize_hostname(item))


def validate_provider_base_url(
    base_url: str,
    *,
    allowlist: tuple[str, ...] = (),
    resolver: HostResolver | None = None,
) -> ResolvedTarget:
    parsed = urlparse(base_url)
    if parsed.scheme not in {"http", "https"} or not parsed.hostname or not parsed.netloc:
        raise SsrfBlockedError("base_url must include a valid scheme and host")
    if parsed.params or parsed.query or parsed.fragment:
        raise SsrfBlockedError("base_url must not include params, query, or fragment")
    if parsed.username or parsed.password:
        raise SsrfBlockedError("base_url must not embed credentials")

    hostname = normalize_hostname(parsed.hostname)
    if parsed.scheme == "http":
        if hostname not in LOCAL_HOSTS:
            raise SsrfBlockedError("remote providers must use https")
    else:
        assert_public_hostname(hostname, allowlist=allowlist, resolver=resolver)
    if parsed.scheme == "http":
        if hostname not in LOCAL_HOSTS:
            raise SsrfBlockedError("http is only allowed for localhost providers")
        addresses = tuple("127.0.0.1" if hostname == "localhost" else hostname for _ in range(1))
    else:
        addresses = resolve_public_hostname(hostname, allowlist=allowlist, resolver=resolver)

    return ResolvedTarget(
        base_url=base_url.rstrip("/"),
        hostname=hostname,
        addresses=addresses,
        allowlist=allowlist,
    )


def assert_public_hostname(
    hostname: str,
    *,
    allowlist: tuple[str, ...] = (),
    resolver: HostResolver | None = None,
) -> None:
    resolve_public_hostname(hostname, allowlist=allowlist, resolver=resolver)


def resolve_public_hostname(
    hostname: str,
    *,
    allowlist: tuple[str, ...] = (),
    resolver: HostResolver | None = None,
) -> tuple[str, ...]:
    normalized = normalize_hostname(hostname)
    if not normalized:
        raise SsrfBlockedError("hostname must not be empty")
    if allowlist and normalized not in allowlist:
        raise SsrfBlockedError(f"blocked hostname {normalized}: not in allowlist")
    if is_blocked_hostname(normalized):
        raise SsrfBlockedError("blocked hostname or private/internal/special-use IP address")
    if is_private_ip_address(normalized):
        raise SsrfBlockedError("blocked hostname or private/internal/special-use IP address")

    raw_addresses = (resolver or default_resolver)(normalized)
    addresses = tuple(dict.fromkeys(raw_addresses))
    if not addresses:
        raise SsrfBlockedError(f"unable to resolve hostname {normalized}")
    for address in addresses:
        if is_private_ip_address(address):
            raise SsrfBlockedError("blocked: resolves to private/internal/special-use IP address")
    return addresses


def default_resolver(hostname: str) -> list[str]:
    results = socket.getaddrinfo(hostname, None, type=socket.SOCK_STREAM)
    addresses: list[str] = []
    for family, _, _, _, sockaddr in results:
        if family == socket.AF_INET:
            addresses.append(str(sockaddr[0]))
        elif family == socket.AF_INET6:
            addresses.append(str(sockaddr[0]))
    return addresses


def is_blocked_hostname(hostname: str) -> bool:
    normalized = normalize_hostname(hostname)
    if normalized in BLOCKED_HOSTNAMES:
        return True
    return (
        normalized.endswith(".localhost")
        or normalized.endswith(".local")
        or normalized.endswith(".internal")
    )


def is_private_ip_address(value: str) -> bool:
    normalized = value.strip().lower()
    if not normalized:
        return False
    if normalized.startswith("[") and normalized.endswith("]"):
        normalized = normalized[1:-1]
    if "%" in normalized:
        normalized = normalized.split("%", 1)[0]

    direct = _parse_ip_literal(normalized)
    if direct is not None:
        return _is_non_global_ip(direct)

    if ":" in normalized:
        return True

    if _looks_like_unsupported_ipv4_literal(normalized):
        return True
    return False


def _parse_ip_literal(value: str) -> IPAddress | None:
    try:
        return ipaddress.ip_address(value)
    except ValueError:
        return None


def _looks_like_unsupported_ipv4_literal(value: str) -> bool:
    if value.count(".") == 0:
        return bool(NUMERIC_HOST_PART_RE.fullmatch(value))
    parts = value.split(".")
    if len(parts) > 4:
        return False
    if any(part == "" for part in parts):
        return True
    if all(NUMERIC_HOST_PART_RE.fullmatch(part) for part in parts):
        if len(parts) != 4:
            return True
        if any(part.startswith("0") and part != "0" for part in parts):
            return True
        joined = ".".join(parts)
        return _parse_ip_literal(joined) is None
    return False


def _is_non_global_ip(address: IPAddress) -> bool:
    if isinstance(address, ipaddress.IPv4Address):
        return not address.is_global
    if address.ipv4_mapped is not None:
        return _is_non_global_ip(address.ipv4_mapped)
    if address.sixtofour is not None:
        return True
    if address.teredo is not None:
        return True
    return (
        address.is_loopback
        or address.is_link_local
        or address.is_private
        or address.is_multicast
        or address.is_reserved
        or address.is_unspecified
    )


async def fetch_openai_models(
    target: ResolvedTarget,
    *,
    api_key: str | None,
    transport: httpx.AsyncBaseTransport | None = None,
    timeout_seconds: float = DEFAULT_TIMEOUT_SECONDS,
) -> tuple[list[dict[str, str]], int]:
    started = time.perf_counter()
    headers = {"Accept": "application/json"}
    if api_key:
        headers["Authorization"] = f"Bearer {api_key}"

    transport_to_use = transport if transport is not None else PinnedAddressTransport(target)

    async with httpx.AsyncClient(
        follow_redirects=False,
        timeout=timeout_seconds,
        trust_env=False,
        transport=transport_to_use,
    ) as client:
        current_url = f"{target.base_url.rstrip('/')}/models"
        redirect_count = 0
        while True:
            async with client.stream("GET", current_url, headers=headers) as response:
                if response.status_code in {301, 302, 303, 307, 308}:
                    location = response.headers.get("location", "").strip()
                    if not location:
                        raise SsrfBlockedError("redirect response did not include a location")
                    redirected = urlparse(urljoin(str(response.request.url), location))
                    if not _is_same_origin(response.request.url, redirected):
                        raise SsrfBlockedError("cross-host redirects are blocked")
                    current_url = redirected.geturl()
                    redirect_count += 1
                    if redirect_count > 1:
                        raise SsrfBlockedError("too many redirects")
                    continue
                body = await _read_response_body_with_cap(response)
            try:
                payload = json.loads(body)
            except json.JSONDecodeError as exc:
                raise SsrfBlockedError("upstream returned invalid JSON") from exc
            data = payload.get("data")
            if not isinstance(data, list):
                raise SsrfBlockedError("upstream /v1/models payload must contain data[]")
            items: list[dict[str, str]] = []
            for item in data:
                if not isinstance(item, dict):
                    continue
                identifier = str(item.get("id", "")).strip()
                if not identifier:
                    continue
                name = str(item.get("name", identifier)).strip() or identifier
                items.append({"id": identifier, "name": name})
            latency_ms = int((time.perf_counter() - started) * 1000)
            return items, latency_ms


async def _read_response_body_with_cap(response: httpx.Response) -> bytes:
    body = bytearray()
    async for chunk in response.aiter_bytes():
        body.extend(chunk)
        if len(body) > MAX_RESPONSE_BYTES:
            raise SsrfBlockedError("response exceeded 1MB cap")
    return bytes(body)


def _is_same_origin(original_url: httpx.URL, redirected_url: object) -> bool:
    if not isinstance(redirected_url, type(urlparse("https://example.com"))):
        return False
    original_scheme = original_url.scheme
    original_host = normalize_hostname(original_url.host or "")
    original_port = _effective_port(original_scheme, original_url.port)
    redirected_scheme = redirected_url.scheme
    redirected_host = normalize_hostname(redirected_url.hostname or "")
    redirected_port = _effective_port(redirected_scheme, redirected_url.port)
    return (
        original_scheme == redirected_scheme
        and original_host == redirected_host
        and original_port == redirected_port
    )


def _effective_port(scheme: str, port: int | None) -> int | None:
    if port is not None:
        return port
    if scheme == "https":
        return 443
    if scheme == "http":
        return 80
    return None
