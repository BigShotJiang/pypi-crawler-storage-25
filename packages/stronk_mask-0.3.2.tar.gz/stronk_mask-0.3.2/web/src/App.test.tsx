import { cleanup, fireEvent, render, screen, waitFor } from "@testing-library/react";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";

import App from "./App";
import type {
  AccessSummary,
  ApplyJobSummary,
  AuditEvent,
  ConfigSummary,
  DebugTrace,
  DiscoveredModel,
  ModelSummary,
  OperatorStateSummary,
  Overview,
  PolicySummary,
  ProviderSummary,
  RollbackResult,
  SessionSummary,
  SystemSummary,
} from "./types";

const api = vi.hoisted(() => ({
  createProvider: vi.fn(),
  createProviderModel: vi.fn(),
  deleteProvider: vi.fn(),
  deleteProviderModel: vi.fn(),
  discoverProviderModels: vi.fn(),
  fetchAccess: vi.fn(),
  fetchApplyStatus: vi.fn(),
  fetchConfig: vi.fn(),
  fetchDebugTrace: vi.fn(),
  fetchEvent: vi.fn(),
  fetchEvents: vi.fn(),
  fetchModels: vi.fn(),
  fetchOperatorState: vi.fn(),
  fetchOverview: vi.fn(),
  fetchPolicy: vi.fn(),
  fetchProviders: vi.fn(),
  fetchSession: vi.fn(),
  fetchSystem: vi.fn(),
  loginSession: vi.fn(),
  logoutSession: vi.fn(),
  rollbackApply: vi.fn(),
  startApply: vi.fn(),
  testProvider: vi.fn(),
  updateProvider: vi.fn(),
  updateProviderModel: vi.fn(),
}));

vi.mock("./api", () => ({
  ApiError: class ApiError extends Error {
    status: number;
    code: string | null;

    constructor(path: string, status: number, message?: string, code?: string | null) {
      super(message ?? `Request failed for ${path}: ${status}`);
      this.name = "ApiError";
      this.status = status;
      this.code = code ?? null;
    }
  },
  ...api,
}));

const sessionFixture: SessionSummary = {
  viewer: {
    user: "operator",
    roles: ["admin"],
  },
  auth_mode: "session",
  access_mode: "loopback",
  trace_access: true,
  trace_allowed_roles: ["admin"],
  content_trace_enabled: true,
  device_id: null,
  trusted_proxy_login: null,
  session_secure_cookies: false,
};

const overviewFixture: Overview = {
  total_requests: 42,
  masked_requests: 21,
  blocked_requests: 3,
  route_local_requests: 1,
  rehydrated_responses: 19,
  error_requests: 2,
  provider_counts: { openai: 42 },
  detector_counts: { pii: 7 },
  action_counts: { mask: 5 },
  last_event_at: "2026-04-03T18:00:00Z",
  gateway: {
    schema_version: "gateway/v2",
    artifact_dir: "/tmp/generated",
    warnings: ["doctor warning"],
    provider_summary: {
      ready: 1,
      total: 2,
      last_materialized_at: "2026-04-03T17:59:00Z",
    },
    model_summary: {
      ready: 2,
      total: 3,
      recommended_aliases: ["stronk-lm-hot"],
    },
    doctor: {
      status: "ready",
      private_surface_posture: "sealed",
      bundle_version: "v2.0.0",
    },
    hermes: {
      public_base_url: "https://gateway.example.com",
      recommended_model_aliases: ["stronk-lm-hot"],
      credential_flow: "cli_only",
      copy_snippets: [
        {
          label: "Hermes",
          snippet: "hermes login",
        },
      ],
    },
  },
};

const overviewUnsafeSnippetFixture: Overview = {
  ...overviewFixture,
  gateway: {
    ...overviewFixture.gateway,
    hermes: {
      ...overviewFixture.gateway.hermes,
      copy_snippets: [
        {
          label: "Hermes",
          snippet:
            'export HERMES_API_KEY="sk-live-secret"\ncurl -H "Authorization: Bearer sk-live-secret" https://gateway.example.com',
        },
      ],
    },
  },
};

const configFixture: ConfigSummary = {
  app_name: "stronk-mask",
  app_env: "test",
  proxy_surfaces: ["public"],
  control_plane: {
    admin_api_enabled: true,
    admin_ui_enabled: true,
    audit_storage_enabled: true,
    ui_built: true,
    content_trace_enabled: true,
    content_trace_ttl_seconds: 300,
  },
  upstreams: {
    openai_host: "api.openai.com",
    anthropic_host: "api.anthropic.com",
    allow_insecure_upstreams: false,
    allow_nonstandard_upstream_hosts: false,
  },
  policy_actions: {
    email: "mask",
  },
  auth: {
    auth_mode: "session",
    allowed_roles: ["admin"],
    trace_allowed_roles: ["admin"],
    session_cookie_name: "stronk_mask",
    session_secure_cookies: false,
    viewer: {
      user: "operator",
      roles: ["admin"],
    },
    trace_access: true,
  },
  access: {
    mode: "loopback",
    http_bind: "127.0.0.1",
    http_port: 8790,
    allowed_origins: ["http://localhost:4173"],
    trusted_proxy_mode: "off",
    enrollment_required: false,
  },
  gateway_artifacts: {
    artifact_dir: "/tmp/generated",
    schema_version: "gateway/v2",
    warnings: [],
  },
  warnings: ["config warning"],
  recent_access: [],
};

const providersFixture: ProviderSummary = {
  schema_version: "gateway/v2",
  artifact_dir: "/tmp/generated",
  materialization_required: false,
  last_materialized_at: "2026-04-03T17:59:00Z",
  last_doctor_generated_at: "2026-04-03T17:59:30Z",
  last_doctor_status: "ready",
  warnings: ["provider warning"],
  items: [
    {
      label: "OpenAI Production",
      readiness_posture: "ready",
      auth_source_type: "env",
      materialized_at: "2026-04-03T17:59:00Z",
    },
  ],
};

const modelsFixture: ModelSummary = {
  schema_version: "gateway/v2",
  artifact_dir: "/tmp/generated",
  materialization_required: false,
  last_materialized_at: "2026-04-03T17:59:00Z",
  recommended_model_aliases: ["stronk-lm-hot"],
  warnings: ["model warning"],
  items: [
    {
      public_alias: "stronk-lm-hot",
      backend_id: "openai-production",
      endpoint_id: "chat",
      readiness_posture: "ready",
      fallback_note: null,
      recommended_for_hermes: true,
    },
  ],
};

const modelsEmptyFixture: ModelSummary = {
  ...modelsFixture,
  recommended_model_aliases: [],
  items: [],
};

const policyFixture: PolicySummary = {
  warnings: ["policy warning"],
  detector_readiness: {
    presidio_enabled: true,
    languages: ["en"],
    score_threshold: 0.5,
    english_model: "en_core_web_lg",
    chinese_model: "zh_core_web_lg",
  },
  fail_closed_actions: {
    email: "block",
  },
  endpoint_posture: [
    {
      public_alias: "stronk-lm-hot",
      privacy_policy_id: "default",
      backend_linkage: "openai/chat",
    },
  ],
};

const accessFixture: AccessSummary = {
  mode: "loopback",
  viewer: {
    user: "operator",
    roles: ["admin"],
  },
  trace_allowed_roles: ["admin"],
  session_posture: {
    cookie_name: "stronk_mask",
    secure_cookies: false,
    idle_timeout_seconds: 900,
    absolute_timeout_seconds: 28800,
    csrf_same_origin_required: true,
    login_attempt_limit: 5,
    login_attempt_window_seconds: 300,
  },
  remote_access: {
    allowed_origins: ["http://localhost:4173"],
    trusted_proxy_mode: "off",
    enrollment_required: false,
  },
  enrollment: {
    approved: 1,
    pending: 0,
    revoked: 0,
    active_device: null,
    recent: [],
  },
};

const systemFixture: SystemSummary = {
  schema_version: "gateway/v2",
  artifact_dir: "/tmp/generated",
  bundle_version: "v2.0.0",
  generated_at: "2026-04-03T18:00:00Z",
  private_surface_posture: "sealed",
  check_status: "ready",
  checks: [
    {
      name: "doctor",
      status: "ready",
      message: "all checks passed",
      evidence_ref: null,
    },
  ],
  image_pins: {
    gateway: "ghcr.io/example/gateway@sha256:123",
  },
  topology: {
    browser_admin_runtime: "stronk-mask",
    public_runtime: "stronk-gateway",
    private_backplane: "docker",
    browser_direct_cliproxyapi: false,
    supported_access_modes: ["loopback"],
    current_access_mode: "loopback",
  },
  warnings: ["system warning"],
};

const eventFixture: AuditEvent = {
  request_id: "req-123",
  created_at: "2026-04-03T18:00:00Z",
  provider: "openai",
  endpoint: "chat",
  model: "gpt-4.1",
  stream: false,
  outcome: "masked",
  status_code: 200,
  latency_ms: 150,
  detection_count: 2,
  detection_types: {
    email: 2,
  },
  actions: {
    mask: 2,
  },
  placeholder_count: 2,
  rehydration_count: 1,
  masked_paths: ["input.messages[0].content"],
  blocked: false,
  route_local: false,
};

const debugTraceFixture: DebugTrace = {
  request_id: "req-123",
  created_at: "2026-04-03T18:00:00Z",
  provider: "openai",
  endpoint: "chat",
  model: "gpt-4.1",
  stream: false,
  outcome: "masked",
  status_code: 200,
  request_original: { text: "secret" },
  request_masked: { text: "<EMAIL_1>" },
  response_upstream: { text: "ok" },
  response_rehydrated: { text: "ok" },
};

const privacyPolicies = [
  {
    id: "default",
    presidio_required: true,
    spacy_required: true,
    fail_closed_detector_types: ["email"],
  },
];

const operatorStateEmptyFixture: OperatorStateSummary = {
  schema_version: "stronk.operator-state/v2",
  providers: [],
  privacy_policies: privacyPolicies,
};

const operatorStateProviderOnlyFixture: OperatorStateSummary = {
  schema_version: "stronk.operator-state/v2",
  providers: [
    {
      id: "openai-production",
      label: "OpenAI Production",
      kind: "openai_compat",
      base_url: "https://api.openai.com/v1",
      secret_ref: "PROVIDER_OPENAI_API_KEY",
      cliproxy_provider_name: "openai-production",
      models: [],
    },
  ],
  privacy_policies: privacyPolicies,
};

const operatorStateConfiguredFixture: OperatorStateSummary = {
  schema_version: "stronk.operator-state/v2",
  providers: [
    {
      id: "openai-production",
      label: "OpenAI Production",
      kind: "openai_compat",
      base_url: "https://api.openai.com/v1",
      secret_ref: "PROVIDER_OPENAI_API_KEY",
      cliproxy_provider_name: "openai-production",
      models: [
        {
          upstream_id: "gpt-4.1",
          public_alias: "stronk-lm-hot",
          privacy_policy_id: "default",
          enabled: true,
        },
      ],
    },
  ],
  privacy_policies: privacyPolicies,
};

const operatorStateDraftAliasFixture: OperatorStateSummary = {
  schema_version: "stronk.operator-state/v2",
  providers: [
    {
      id: "openai-production",
      label: "OpenAI Production",
      kind: "openai_compat",
      base_url: "https://api.openai.com/v1",
      secret_ref: "PROVIDER_OPENAI_API_KEY",
      cliproxy_provider_name: "openai-production",
      models: [
        {
          upstream_id: "gpt-4.1",
          public_alias: "stronk-lm-hot",
          privacy_policy_id: "default",
          enabled: false,
        },
      ],
    },
  ],
  privacy_policies: privacyPolicies,
};

const operatorStateUnsafeFixture: OperatorStateSummary = {
  schema_version: "stronk.operator-state/v2",
  providers: [
    {
      id: "unsafe-provider",
      label: "Unsafe Provider",
      kind: "openai_compat",
      base_url: "https://user:token@example.com/v1",
      secret_ref: "sk-live-secret",
      cliproxy_provider_name: "unsafe-provider",
      models: [],
    },
  ],
  privacy_policies: privacyPolicies,
};

const discoveredModelsFixture: DiscoveredModel[] = [{ id: "gpt-4.1" }];

function primeAuthenticatedMocks({
  operatorState = operatorStateConfiguredFixture,
  modelSummary = modelsFixture,
}: {
  operatorState?: OperatorStateSummary;
  modelSummary?: ModelSummary;
} = {}) {
  api.fetchSession.mockResolvedValue(sessionFixture);
  api.fetchOverview.mockResolvedValue(overviewFixture);
  api.fetchConfig.mockResolvedValue(configFixture);
  api.fetchProviders.mockResolvedValue(providersFixture);
  api.fetchModels.mockResolvedValue(modelSummary);
  api.fetchPolicy.mockResolvedValue(policyFixture);
  api.fetchAccess.mockResolvedValue(accessFixture);
  api.fetchSystem.mockResolvedValue(systemFixture);
  api.fetchEvents.mockResolvedValue({ items: [eventFixture] });
  api.fetchEvent.mockResolvedValue(eventFixture);
  api.fetchDebugTrace.mockResolvedValue(debugTraceFixture);
  api.fetchOperatorState.mockResolvedValue(operatorState);
}

describe("App", () => {
  beforeEach(() => {
    vi.resetAllMocks();
    const storage = new Map<string, string>();
    Object.defineProperty(window, "localStorage", {
      writable: true,
      value: {
        getItem: vi.fn((key: string) => storage.get(key) ?? null),
        setItem: vi.fn((key: string, value: string) => {
          storage.set(key, value);
        }),
        removeItem: vi.fn((key: string) => {
          storage.delete(key);
        }),
        clear: vi.fn(() => {
          storage.clear();
        }),
      },
    });
    window.history.pushState({}, "", "/");
    Object.defineProperty(window, "matchMedia", {
      writable: true,
      value: vi.fn().mockImplementation((query: string) => ({
        matches: false,
        media: query,
        onchange: null,
        addListener: vi.fn(),
        removeListener: vi.fn(),
        addEventListener: vi.fn(),
        removeEventListener: vi.fn(),
        dispatchEvent: vi.fn(),
      })),
    });
  });

  afterEach(() => {
    cleanup();
    vi.useRealTimers();
  });

  it("renders the login shell when the session is unresolved as unauthenticated", async () => {
    api.fetchSession.mockResolvedValue(null);

    render(<App />);

    expect(await screen.findByRole("button", { name: "Open operator console" })).toBeInTheDocument();
    expect(screen.queryByText("Aggregated operator console for masked-request monitoring, posture, and Hermes setup.")).not.toBeInTheDocument();
    expect(api.fetchOverview).not.toHaveBeenCalled();
    expect(api.fetchConfig).not.toHaveBeenCalled();
  });

  it("renders the overview route and preserves extracted navigation wiring", async () => {
    primeAuthenticatedMocks();

    const { container } = render(<App />);

    expect(await screen.findByRole("heading", { name: "Overview" })).toBeInTheDocument();
    expect(await screen.findByText("https://gateway.example.com")).toBeInTheDocument();
    expect(screen.getByText("doctor warning")).toBeInTheDocument();
    const maskedBadge = container.querySelector(".request-row .status-badge");
    expect(maskedBadge).toHaveTextContent("masked");
    expect(maskedBadge).toHaveClass("tone-accent");

    fireEvent.click(screen.getByRole("button", { name: "Providers" }));

    expect(await screen.findByRole("heading", { name: "Providers" })).toBeInTheDocument();
    expect(await screen.findByText("provider warning")).toBeInTheDocument();
    expect(screen.getByRole("button", { name: /ProvidersRead-only provider readiness/i })).toHaveClass("is-active");
    expect(window.location.pathname).toBe("/providers");
  });

  it("loads a direct request detail route and preserves back-navigation to the requests page", async () => {
    primeAuthenticatedMocks();
    window.history.pushState({}, "", "/requests/req-123");

    render(<App />);

    expect(await screen.findByRole("heading", { name: "Request Detail" })).toBeInTheDocument();
    expect(await screen.findByRole("heading", { name: "req-123" })).toBeInTheDocument();
    await waitFor(() => {
      expect(api.fetchEvent).toHaveBeenCalledWith("req-123");
      expect(api.fetchDebugTrace).toHaveBeenCalledWith("req-123");
    });

    fireEvent.click(screen.getByRole("button", { name: "Back to Requests" }));

    expect(await screen.findByRole("heading", { name: "Requests" })).toBeInTheDocument();
    expect(window.location.pathname).toBe("/requests");
  });

  it("keeps the global error banner outside the animated route frame", async () => {
    api.fetchSession.mockResolvedValue(sessionFixture);
    api.fetchOverview.mockRejectedValue(new Error("Failed to load control plane data."));
    api.fetchConfig.mockResolvedValue(configFixture);
    api.fetchProviders.mockResolvedValue(providersFixture);
    api.fetchModels.mockResolvedValue(modelsFixture);
    api.fetchPolicy.mockResolvedValue(policyFixture);
    api.fetchAccess.mockResolvedValue(accessFixture);
    api.fetchSystem.mockResolvedValue(systemFixture);
    api.fetchEvents.mockResolvedValue({ items: [eventFixture] });
    api.fetchOperatorState.mockResolvedValue(operatorStateConfiguredFixture);

    const { container } = render(<App />);

    expect(await screen.findByText("Failed to load control plane data.")).toBeInTheDocument();
    expect(container.querySelector(".console-workspace > .error-banner")).not.toBeNull();
    expect(container.querySelector(".route-frame .error-banner")).toBeNull();
  });

  it("shows first-time onboarding without adding browser storage beyond the theme preference", async () => {
    primeAuthenticatedMocks({ operatorState: operatorStateEmptyFixture, modelSummary: modelsEmptyFixture });

    render(<App />);

    expect(await screen.findByText("First-time setup wizard")).toBeInTheDocument();
    expect(screen.queryByLabelText(/password/i)).not.toBeInTheDocument();
    expect(screen.queryByLabelText(/api key/i)).not.toBeInTheDocument();
    const calls = (window.localStorage.setItem as ReturnType<typeof vi.fn>).mock.calls;
    expect(calls).not.toHaveLength(0);
    expect(calls.every(([key]) => key === "stronk-mask-theme")).toBe(true);
  });

  it("redacts unsafe operator-state values before they reach the providers UI", async () => {
    primeAuthenticatedMocks({ operatorState: operatorStateUnsafeFixture, modelSummary: modelsEmptyFixture });

    render(<App />);

    fireEvent.click(await screen.findByRole("button", { name: "Providers" }));

    expect(await screen.findByText(/invalid staged base url/i)).toBeInTheDocument();
    expect(screen.queryByText("https://user:token@example.com/v1")).not.toBeInTheDocument();
    expect(screen.queryByText("sk-live-secret")).not.toBeInTheDocument();
  });

  it("redacts unsafe Hermes helper snippet values before rendering them", async () => {
    primeAuthenticatedMocks();
    api.fetchOverview.mockResolvedValue(overviewUnsafeSnippetFixture);

    render(<App />);

    const snippetCard = (await screen.findByText("Hermes")).closest(".snippet-card");
    expect(snippetCard).not.toBeNull();
    expect(snippetCard).toHaveTextContent(/<redacted>/);
    expect(snippetCard?.textContent).toContain("Authorization:");
    expect(screen.queryByText(/sk-live-secret/)).not.toBeInTheDocument();
  });

  it("keeps onboarding on provider setup when save verification fails server-side", async () => {
    primeAuthenticatedMocks({ operatorState: operatorStateEmptyFixture, modelSummary: modelsEmptyFixture });
    api.createProvider.mockRejectedValue(new Error("provider_invalid"));

    render(<App />);

    expect(await screen.findByText("First-time setup wizard")).toBeInTheDocument();

    fireEvent.change(screen.getByLabelText("Label"), { target: { value: "OpenAI Production" } });
    fireEvent.change(screen.getByLabelText("Base URL"), { target: { value: "https://api.openai.com/v1" } });
    fireEvent.change(screen.getByPlaceholderText("PROVIDER_OPENAI_API_KEY"), {
      target: { value: "PROVIDER_OPENAI_API_KEY" },
    });
    fireEvent.click(screen.getByRole("button", { name: "Save + Verify" }));

    expect(
      await screen.findByText(
        "Provider settings were rejected. Use an HTTPS base URL and a PROVIDER_* secret env var name, then try again.",
      ),
    ).toBeInTheDocument();
    expect(api.discoverProviderModels).not.toHaveBeenCalled();
    expect(screen.queryByRole("button", { name: "Publish alias draft" })).not.toBeInTheDocument();
  });

  it("polls apply status, keeps rollback inline, and never renders raw secret-bearing errors", async () => {
    primeAuthenticatedMocks({ operatorState: operatorStateEmptyFixture, modelSummary: modelsEmptyFixture });
    api.createProvider.mockResolvedValue(operatorStateProviderOnlyFixture.providers[0]);
    api.fetchOperatorState
      .mockResolvedValueOnce(operatorStateEmptyFixture)
      .mockResolvedValueOnce(operatorStateProviderOnlyFixture)
      .mockResolvedValue(operatorStateDraftAliasFixture);
    api.discoverProviderModels.mockResolvedValue(discoveredModelsFixture);
    api.createProviderModel.mockResolvedValue(undefined);
    api.startApply.mockResolvedValue({
      job_id: "job-1",
      status: "running",
      steps: [],
      error: null,
      rollback_available: false,
      finished_at: null,
    } satisfies ApplyJobSummary);
    api.fetchApplyStatus
      .mockResolvedValueOnce({
        job_id: "job-1",
        status: "failed",
        steps: [],
        error:
          "The staged configuration failed validation or health checks. Review the provider setup and retry, or rollback to the last working runtime.",
        rollback_available: true,
        finished_at: "2026-04-03T18:05:00Z",
      } satisfies ApplyJobSummary)
      .mockResolvedValueOnce({
        job_id: "job-1",
        status: "rolled_back",
        steps: [],
        error: null,
        rollback_available: false,
        finished_at: "2026-04-03T18:06:00Z",
      } satisfies ApplyJobSummary);
    api.rollbackApply.mockResolvedValue({ status: "rolled_back" } satisfies RollbackResult);

    const { container } = render(<App />);

    expect(await screen.findByText("First-time setup wizard")).toBeInTheDocument();

    fireEvent.change(screen.getByLabelText("Label"), { target: { value: "OpenAI Production" } });
    fireEvent.change(screen.getByLabelText("Base URL"), { target: { value: "https://api.openai.com/v1" } });
    fireEvent.change(screen.getByPlaceholderText("PROVIDER_OPENAI_API_KEY"), {
      target: { value: "PROVIDER_OPENAI_API_KEY" },
    });
    fireEvent.click(screen.getByRole("button", { name: "Save + Verify" }));

    await waitFor(() => {
      expect(api.createProvider).toHaveBeenCalledWith({
        label: "OpenAI Production",
        kind: "openai_compat",
        base_url: "https://api.openai.com/v1",
        secret_ref: "PROVIDER_OPENAI_API_KEY",
      });
    });
    await waitFor(() => {
      expect(api.discoverProviderModels).toHaveBeenCalledWith("openai-production");
    });

    fireEvent.change(screen.getByLabelText("Public alias"), { target: { value: "stronk-lm-hot" } });
    fireEvent.click(screen.getByRole("button", { name: "Publish alias draft" }));

    await waitFor(() => {
      expect(api.createProviderModel).toHaveBeenCalledWith("openai-production", {
        upstream_id: "gpt-4.1",
        public_alias: "stronk-lm-hot",
        privacy_policy_id: "default",
        enabled: true,
      });
    });

    fireEvent.click(await screen.findByRole("button", { name: "Publish alias" }));

    await waitFor(() => {
      expect(api.startApply).toHaveBeenCalled();
      expect(api.fetchApplyStatus).toHaveBeenCalledWith("job-1");
    });

    expect(await screen.findByText(/failed validation or health checks/i)).toBeInTheDocument();
    expect(screen.queryByText("Bearer sk-live-secret")).not.toBeInTheDocument();
    expect(container.querySelector(".console-workspace > .apply-banner")).not.toBeNull();
    expect(container.querySelector(".route-frame .apply-banner")).toBeNull();

    fireEvent.click(screen.getByRole("button", { name: "Rollback" }));

    await waitFor(() => {
      expect(api.rollbackApply).toHaveBeenCalledWith("job-1");
    });
    expect(await screen.findByText("Rollback restored the last working runtime.")).toBeInTheDocument();
  });
});
