import { cleanup, fireEvent, render, screen, waitFor } from "@testing-library/react";
import { afterEach, describe, expect, it, vi } from "vitest";

import { ProvidersPage } from "./ProvidersPage";
import type { DiscoveredModel, OperatorStateProvider, ProviderSummary, ProviderTestResult } from "../types";

const providersFixture: OperatorStateProvider[] = [
  {
    id: "openai-production",
    label: "OpenAI Production",
    kind: "openai_compat",
    base_url: "https://api.openai.com/v1",
    secret_ref: "PROVIDER_OPENAI_API_KEY",
    cliproxy_provider_name: "openai-production",
    models: [],
  },
];

const runtimeSummaryFixture: ProviderSummary = {
  schema_version: "gateway/v2",
  artifact_dir: "/tmp/generated",
  materialization_required: false,
  last_materialized_at: "2026-04-03T17:59:00Z",
  last_doctor_generated_at: "2026-04-03T17:59:30Z",
  last_doctor_status: "ready",
  warnings: [],
  items: [
    {
      label: "OpenAI Production",
      readiness_posture: "ready",
      auth_source_type: "env",
      materialized_at: "2026-04-03T17:59:00Z",
    },
  ],
};

const verificationFixture: Record<string, ProviderTestResult | null> = {
  "openai-production": { ok: true, latency_ms: 150 },
};

const discoveredModelsFixture: Record<string, DiscoveredModel[]> = {
  "openai-production": [{ id: "gpt-4.1" }],
};

describe("ProvidersPage", () => {
  afterEach(() => {
    cleanup();
  });

  it("renders provider cards with runtime posture and discovered model counts", () => {
    render(
      <ProvidersPage
        providers={providersFixture}
        runtimeSummary={runtimeSummaryFixture}
        selectedProviderId="openai-production"
        verificationByProvider={verificationFixture}
        discoveredModelsByProvider={discoveredModelsFixture}
        providerBusyId={null}
        formError={null}
        onSelectProvider={vi.fn()}
        onSaveProvider={vi.fn()}
        onDeleteProvider={vi.fn()}
        onVerifyProvider={vi.fn()}
        onDiscoverProvider={vi.fn()}
        onApply={vi.fn()}
        applyBusy={false}
      />,
    );

    expect(screen.getByText("OpenAI Production")).toBeInTheDocument();
    expect(screen.getByText("runtime ready")).toBeInTheDocument();
    expect(screen.getByText("verified")).toBeInTheDocument();
    expect(screen.getByRole("button", { name: "Discover models (1)" })).toBeEnabled();
  });

  it("submits only env-var secret refs and rejects secret-looking input", async () => {
    const onSaveProvider = vi.fn().mockResolvedValue(undefined);

    render(
      <ProvidersPage
        providers={[]}
        runtimeSummary={null}
        selectedProviderId={null}
        verificationByProvider={{}}
        discoveredModelsByProvider={{}}
        providerBusyId={null}
        formError={null}
        onSelectProvider={vi.fn()}
        onSaveProvider={onSaveProvider}
        onDeleteProvider={vi.fn()}
        onVerifyProvider={vi.fn()}
        onDiscoverProvider={vi.fn()}
        onApply={vi.fn()}
        applyBusy={false}
      />,
    );

    expect(screen.queryByLabelText(/password/i)).not.toBeInTheDocument();
    expect(screen.queryByLabelText(/api key/i)).not.toBeInTheDocument();

    fireEvent.change(screen.getByLabelText("Label"), { target: { value: "OpenAI Production" } });
    fireEvent.change(screen.getByLabelText("Base URL"), { target: { value: "https://api.openai.com/v1" } });
    fireEvent.change(screen.getByPlaceholderText("PROVIDER_OPENAI_API_KEY"), { target: { value: "sk-live-abc123" } });
    expect(screen.getByText(/do not paste a secret value/i)).toBeInTheDocument();

    fireEvent.click(screen.getByRole("button", { name: "Save + Verify" }));
    expect(onSaveProvider).not.toHaveBeenCalled();

    fireEvent.change(screen.getByPlaceholderText("PROVIDER_OPENAI_API_KEY"), {
      target: { value: "PROVIDER_OPENAI_API_KEY" },
    });
    fireEvent.click(screen.getByRole("button", { name: "Save + Verify" }));

    await waitFor(() => {
      expect(onSaveProvider).toHaveBeenCalledWith(null, {
        label: "OpenAI Production",
        kind: "openai_compat",
        base_url: "https://api.openai.com/v1",
        secret_ref: "PROVIDER_OPENAI_API_KEY",
      });
    });
  });

  it("rejects pasted base URLs with query secrets before they enter rendered state", () => {
    render(
      <ProvidersPage
        providers={[]}
        runtimeSummary={null}
        selectedProviderId={null}
        verificationByProvider={{}}
        discoveredModelsByProvider={{}}
        providerBusyId={null}
        formError={null}
        onSelectProvider={vi.fn()}
        onSaveProvider={vi.fn()}
        onDeleteProvider={vi.fn()}
        onVerifyProvider={vi.fn()}
        onDiscoverProvider={vi.fn()}
        onApply={vi.fn()}
        applyBusy={false}
      />,
    );

    const baseUrlInput = screen.getByLabelText("Base URL");

    fireEvent.change(baseUrlInput, { target: { value: "https://api.openai.com/v1" } });
    expect(baseUrlInput).toHaveValue("https://api.openai.com/v1");

    fireEvent.change(baseUrlInput, {
      target: { value: "https://api.openai.com/v1?api_key=sk-live-secret" },
    });

    expect(screen.getByText("Base URL must not include query parameters or fragments.")).toBeInTheDocument();
    expect(baseUrlInput).toHaveValue("https://api.openai.com/v1");
    expect(screen.queryByDisplayValue("https://api.openai.com/v1?api_key=sk-live-secret")).not.toBeInTheDocument();
  });

  it("rejects pasted base URLs with fragments before they enter rendered state", () => {
    render(
      <ProvidersPage
        providers={[]}
        runtimeSummary={null}
        selectedProviderId={null}
        verificationByProvider={{}}
        discoveredModelsByProvider={{}}
        providerBusyId={null}
        formError={null}
        onSelectProvider={vi.fn()}
        onSaveProvider={vi.fn()}
        onDeleteProvider={vi.fn()}
        onVerifyProvider={vi.fn()}
        onDiscoverProvider={vi.fn()}
        onApply={vi.fn()}
        applyBusy={false}
      />,
    );

    const baseUrlInput = screen.getByLabelText("Base URL");

    fireEvent.change(baseUrlInput, {
      target: { value: "https://api.openai.com/v1#sk-live-secret" },
    });

    expect(screen.getByText("Base URL must not include query parameters or fragments.")).toBeInTheDocument();
    expect(baseUrlInput).toHaveValue("");
    expect(screen.queryByDisplayValue("https://api.openai.com/v1#sk-live-secret")).not.toBeInTheDocument();
  });

  it("routes edit, verify, and discover actions for the selected provider", async () => {
    const onSaveProvider = vi.fn().mockResolvedValue(undefined);
    const onDeleteProvider = vi.fn().mockResolvedValue(undefined);
    const onVerifyProvider = vi.fn().mockResolvedValue(undefined);
    const onDiscoverProvider = vi.fn().mockResolvedValue(undefined);
    const onApply = vi.fn().mockResolvedValue(undefined);

    render(
      <ProvidersPage
        providers={providersFixture}
        runtimeSummary={runtimeSummaryFixture}
        selectedProviderId="openai-production"
        verificationByProvider={{
          "openai-production": {
            ok: true,
            latency_ms: 150,
          },
        }}
        discoveredModelsByProvider={{ "openai-production": [] }}
        providerBusyId={null}
        formError={null}
        onSelectProvider={vi.fn()}
        onSaveProvider={onSaveProvider}
        onDeleteProvider={onDeleteProvider}
        onVerifyProvider={onVerifyProvider}
        onDiscoverProvider={onDiscoverProvider}
        onApply={onApply}
        applyBusy={false}
      />,
    );

    fireEvent.click(screen.getAllByRole("button", { name: "Verify" })[0]);
    fireEvent.click(screen.getByRole("button", { name: "Discover models (0)" }));
    fireEvent.click(screen.getByRole("button", { name: "Delete" }));
    fireEvent.click(screen.getByRole("button", { name: "Apply staged config" }));

    await waitFor(() => {
      expect(onVerifyProvider).toHaveBeenCalledWith("openai-production");
      expect(onDiscoverProvider).toHaveBeenCalledWith("openai-production");
      expect(onDeleteProvider).toHaveBeenCalledWith("openai-production");
      expect(onApply).toHaveBeenCalled();
    });

    fireEvent.change(screen.getByLabelText("Label"), { target: { value: "OpenAI Prime" } });
    fireEvent.click(screen.getByRole("button", { name: "Update + Verify" }));

    await waitFor(() => {
      expect(onSaveProvider).toHaveBeenCalledWith("openai-production", {
        label: "OpenAI Prime",
        kind: "openai_compat",
        base_url: "https://api.openai.com/v1",
        secret_ref: "PROVIDER_OPENAI_API_KEY",
      });
    });
  });

  it("disables provider edits while apply is running", () => {
    render(
      <ProvidersPage
        providers={providersFixture}
        runtimeSummary={runtimeSummaryFixture}
        selectedProviderId="openai-production"
        verificationByProvider={verificationFixture}
        discoveredModelsByProvider={discoveredModelsFixture}
        providerBusyId={null}
        formError={null}
        onSelectProvider={vi.fn()}
        onSaveProvider={vi.fn()}
        onDeleteProvider={vi.fn()}
        onVerifyProvider={vi.fn()}
        onDiscoverProvider={vi.fn()}
        onApply={vi.fn()}
        applyBusy={true}
      />,
    );

    expect(screen.getByRole("button", { name: "Add provider" })).toBeDisabled();
    expect(screen.getByRole("button", { name: "Applying..." })).toBeDisabled();
    expect(screen.getByRole("button", { name: "Edit" })).toBeDisabled();
    expect(screen.getAllByRole("button", { name: "Verify" })[0]).toBeDisabled();
    expect(screen.getByRole("button", { name: "Discover models (1)" })).toBeDisabled();
    expect(screen.getByLabelText("Label")).toBeDisabled();
    expect(screen.getByLabelText("Base URL")).toBeDisabled();
    expect(screen.getByPlaceholderText("PROVIDER_OPENAI_API_KEY")).toBeDisabled();
    expect(screen.getByRole("button", { name: "Delete" })).toBeDisabled();
    expect(screen.getByRole("button", { name: "Update + Verify" })).toBeDisabled();
  });
});
