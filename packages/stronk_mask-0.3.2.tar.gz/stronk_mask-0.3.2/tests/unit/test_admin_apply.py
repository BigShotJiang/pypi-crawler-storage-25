from __future__ import annotations

import asyncio
import json
from pathlib import Path

import httpx
import pytest
from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse

from stronk_mask.admin.apply import ApplyManager
from stronk_mask.admin.operator_state_store import OperatorStateStore
from tests.helpers import build_bundle_root, build_public_models_app, write_json


async def wait_for_job(manager: ApplyManager, job_id: str) -> dict[str, object]:
    for _ in range(200):
        payload = manager.get_job(job_id).to_payload()
        if payload["status"] != "running":
            return payload
        await asyncio.sleep(0.01)
    raise AssertionError(f"job {job_id} did not finish")


@pytest.mark.anyio
async def test_apply_promotes_draft_materializes_and_syncs_file_backed_secret(tmp_path: Path) -> None:
    bundle_root = build_bundle_root(
        tmp_path / "bundle",
        env_values={
            "STRONK_GATEWAY_PUBLIC_HTTP_PORT": "54321",
            "STRONK_GATEWAY_PUBLIC_BASE_URL": "http://gateway.test/v1",
            "STRONK_GATEWAY_PUBLIC_API_KEY": "public-key",
        },
    )
    secrets_dir = bundle_root / "secrets"
    (secrets_dir / "PROVIDER_OPENAI_API_KEY").write_text("provider-secret\n", encoding="utf-8")
    (secrets_dir / "PROVIDER_OPENAI_API_KEY").chmod(0o600)
    store = OperatorStateStore(bundle_root / "config")
    provider = store.create_provider(
        {
            "label": "OpenAI Production",
            "kind": "openai_compat",
            "base_url": "https://api.openai.com/v1",
            "secret_ref": "PROVIDER_OPENAI_API_KEY",
        }
    )
    store.create_model(
        provider.id,
        {
            "upstream_id": "gpt-4.1-mini",
            "public_alias": "stronk-lm",
            "privacy_policy_id": "default-openai-chat",
        },
    )
    manager = ApplyManager(
        store=store,
        bundle_env_path=bundle_root / ".env",
        generated_dir=bundle_root / "generated",
        secrets_dir=secrets_dir,
        outbound_transport=httpx.ASGITransport(
            app=build_public_models_app(
                model_ids=["stronk-lm"],
                expected_bearer="public-key",
            )
        ),
        reload_wait_seconds=0.01,
        healthcheck_retry_delay_seconds=0.01,
    )

    job = await manager.start_apply()
    payload = await wait_for_job(manager, job.job_id)

    assert payload["status"] == "success"
    assert json.loads((bundle_root / "config" / "operator-objects.json").read_text(encoding="utf-8"))[
        "providers"
    ][0]["id"] == "openai-production"
    assert "PROVIDER_OPENAI_API_KEY=provider-secret" in (bundle_root / ".env").read_text(
        encoding="utf-8"
    )
    cliproxy_config = (bundle_root / "generated" / "cliproxy-config.yaml").read_text(
        encoding="utf-8"
    )
    assert 'api-key-env: "PROVIDER_OPENAI_API_KEY"' in cliproxy_config
    assert "provider-secret" not in cliproxy_config


@pytest.mark.anyio
async def test_apply_failure_restores_last_known_good_files_and_keeps_draft(tmp_path: Path) -> None:
    initial_state = {
        "schema_version": "stronk.operator-state/v2",
        "providers": [
            {
                "id": "old-provider",
                "label": "Old Provider",
                "kind": "openai_compat",
                "base_url": "https://api.openai.com/v1",
                "secret_ref": "PROVIDER_OLD_API_KEY",
                "cliproxy_provider_name": "old-provider",
                "models": [
                    {
                        "upstream_id": "gpt-4.1-mini",
                        "public_alias": "old-model",
                        "privacy_policy_id": "default-openai-chat",
                        "enabled": True,
                    }
                ],
            }
        ],
        "privacy_policies": [
            {
                "id": "default-openai-chat",
                "presidio_required": True,
                "spacy_required": True,
                "fail_closed_detector_types": ["api_key", "bearer_token", "jwt"],
            }
        ],
    }
    bundle_root = build_bundle_root(
        tmp_path / "bundle",
        operator_state=initial_state,
        env_values={
            "STRONK_GATEWAY_PUBLIC_HTTP_PORT": "54321",
            "STRONK_GATEWAY_PUBLIC_BASE_URL": "http://gateway.test/v1",
            "STRONK_GATEWAY_PUBLIC_API_KEY": "public-key",
            "PROVIDER_OLD_API_KEY": "old-secret",
        },
    )
    secrets_dir = bundle_root / "secrets"
    (secrets_dir / "PROVIDER_NEW_API_KEY").write_text("new-secret\n", encoding="utf-8")
    (secrets_dir / "PROVIDER_NEW_API_KEY").chmod(0o600)
    env_before_apply = (bundle_root / ".env").read_text(encoding="utf-8")
    write_json(bundle_root / "generated" / "materialization-summary.json", {"before": "summary"})
    write_json(bundle_root / "generated" / "doctor-report.json", {"before": "doctor"})
    write_json(bundle_root / "generated" / "hermes-connect.json", {"before": "hermes"})
    (bundle_root / "generated" / "cliproxy-config.yaml").write_text("old-config\n", encoding="utf-8")
    restart_calls: list[str] = []

    async def restart_hook() -> None:
        restart_calls.append("restart")

    store = OperatorStateStore(bundle_root / "config")
    draft_state = store.ensure_draft().to_dict()
    draft_state["providers"][0]["secret_ref"] = "PROVIDER_NEW_API_KEY"
    draft_state["providers"][0]["models"][0]["public_alias"] = "new-model"
    write_json(store.draft_path, draft_state)
    manager = ApplyManager(
        store=store,
        bundle_env_path=bundle_root / ".env",
        generated_dir=bundle_root / "generated",
        secrets_dir=bundle_root / "secrets",
        outbound_transport=httpx.ASGITransport(
            app=build_public_models_app(
                model_ids=["old-model"],
                expected_bearer="public-key",
            )
        ),
        restart_hook=restart_hook,
        reload_wait_seconds=0.01,
        healthcheck_retry_delay_seconds=0.01,
    )

    job = await manager.start_apply()
    payload = await wait_for_job(manager, job.job_id)

    assert payload["status"] == "failed"
    assert restart_calls == ["restart", "restart"]
    active_payload = json.loads(store.active_path.read_text(encoding="utf-8"))
    assert active_payload["providers"][0]["models"][0]["public_alias"] == "old-model"
    assert (bundle_root / "generated" / "cliproxy-config.yaml").read_text(encoding="utf-8") == "old-config\n"
    assert json.loads((bundle_root / "generated" / "doctor-report.json").read_text(encoding="utf-8")) == {
        "before": "doctor"
    }
    assert (bundle_root / ".env").read_text(encoding="utf-8") == env_before_apply
    assert store.draft_path.exists()


@pytest.mark.anyio
async def test_apply_recovers_after_restart_hook_and_reprobes_successfully(tmp_path: Path) -> None:
    bundle_root = build_bundle_root(
        tmp_path / "bundle",
        env_values={
            "STRONK_GATEWAY_PUBLIC_HTTP_PORT": "54321",
            "STRONK_GATEWAY_PUBLIC_BASE_URL": "http://gateway.test/v1",
            "STRONK_GATEWAY_PUBLIC_API_KEY": "public-key",
            "PROVIDER_OPENAI_API_KEY": "provider-secret",
        },
    )
    store = OperatorStateStore(bundle_root / "config")
    provider = store.create_provider(
        {
            "label": "OpenAI Production",
            "kind": "openai_compat",
            "base_url": "https://api.openai.com/v1",
            "secret_ref": "PROVIDER_OPENAI_API_KEY",
        }
    )
    store.create_model(
        provider.id,
        {
            "upstream_id": "gpt-4.1-mini",
            "public_alias": "stronk-lm",
            "privacy_policy_id": "default-openai-chat",
        },
    )
    readiness = {"healthy": False}
    restart_calls: list[str] = []

    async def restart_hook() -> None:
        restart_calls.append("restart")
        readiness["healthy"] = True

    app = FastAPI()

    @app.get("/v1/models")
    async def models(request: Request) -> JSONResponse:
        if request.headers.get("authorization") != "Bearer public-key":
            return JSONResponse(status_code=401, content={"error": "unauthorized"})
        if not readiness["healthy"]:
            return JSONResponse(status_code=503, content={"error": "starting"})
        return JSONResponse(
            status_code=200,
            content={"data": [{"id": "stronk-lm", "object": "model"}]},
        )

    manager = ApplyManager(
        store=store,
        bundle_env_path=bundle_root / ".env",
        generated_dir=bundle_root / "generated",
        secrets_dir=bundle_root / "secrets",
        outbound_transport=httpx.ASGITransport(app=app),
        restart_hook=restart_hook,
        reload_wait_seconds=0.01,
        healthcheck_retry_delay_seconds=0.01,
    )

    job = await manager.start_apply()
    payload = await wait_for_job(manager, job.job_id)

    assert payload["status"] == "success"
    assert restart_calls == ["restart"]


@pytest.mark.anyio
async def test_manual_rollback_restarts_restored_runtime_and_reprobes(tmp_path: Path) -> None:
    initial_state = {
        "schema_version": "stronk.operator-state/v2",
        "providers": [
            {
                "id": "old-provider",
                "label": "Old Provider",
                "kind": "openai_compat",
                "base_url": "https://api.openai.com/v1",
                "secret_ref": "PROVIDER_DEFAULT_API_KEY",
                "cliproxy_provider_name": "old-provider",
                "models": [
                    {
                        "upstream_id": "gpt-4.1-mini",
                        "public_alias": "old-model",
                        "privacy_policy_id": "default-openai-chat",
                        "enabled": True,
                    }
                ],
            }
        ],
        "privacy_policies": [
            {
                "id": "default-openai-chat",
                "presidio_required": True,
                "spacy_required": True,
                "fail_closed_detector_types": ["api_key", "bearer_token", "jwt"],
            }
        ],
    }
    bundle_root = build_bundle_root(
        tmp_path / "bundle",
        operator_state=initial_state,
        env_values={
            "STRONK_GATEWAY_PUBLIC_HTTP_PORT": "54321",
            "STRONK_GATEWAY_PUBLIC_BASE_URL": "http://gateway.test/v1",
            "STRONK_GATEWAY_PUBLIC_API_KEY": "public-key",
            "PROVIDER_DEFAULT_API_KEY": "provider-secret",
        },
    )
    store = OperatorStateStore(bundle_root / "config")
    draft_state = store.ensure_draft().to_dict()
    draft_state["providers"][0]["models"][0]["public_alias"] = "new-model"
    write_json(store.draft_path, draft_state)

    served_aliases = {"value": ["new-model"]}
    restart_calls: list[str] = []

    async def restart_hook() -> None:
        restart_calls.append("restart")
        active_payload = json.loads(store.active_path.read_text(encoding="utf-8"))
        served_aliases["value"] = [
            active_payload["providers"][0]["models"][0]["public_alias"]
        ]

    app = FastAPI()

    @app.get("/v1/models")
    async def models(request: Request) -> JSONResponse:
        if request.headers.get("authorization") != "Bearer public-key":
            return JSONResponse(status_code=401, content={"error": "unauthorized"})
        return JSONResponse(
            status_code=200,
            content={
                "data": [
                    {"id": alias, "object": "model"} for alias in served_aliases["value"]
                ]
            },
        )

    manager = ApplyManager(
        store=store,
        bundle_env_path=bundle_root / ".env",
        generated_dir=bundle_root / "generated",
        secrets_dir=bundle_root / "secrets",
        outbound_transport=httpx.ASGITransport(app=app),
        restart_hook=restart_hook,
        reload_wait_seconds=0.01,
        healthcheck_retry_delay_seconds=0.01,
    )

    apply_job = await manager.start_apply()
    apply_payload = await wait_for_job(manager, apply_job.job_id)

    assert apply_payload["status"] == "success"
    assert restart_calls == []

    rollback_payload = (await manager.rollback(apply_job.job_id)).to_payload()

    assert rollback_payload["status"] == "rolled_back"
    assert restart_calls == ["restart"]
    assert served_aliases["value"] == ["old-model"]
    restored_active = json.loads(store.active_path.read_text(encoding="utf-8"))
    assert restored_active["providers"][0]["models"][0]["public_alias"] == "old-model"


@pytest.mark.anyio
async def test_apply_is_single_flight(tmp_path: Path) -> None:
    bundle_root = build_bundle_root(tmp_path / "bundle")
    store = OperatorStateStore(bundle_root / "config")
    provider = store.create_provider(
        {
            "label": "OpenAI Production",
            "kind": "openai_compat",
            "base_url": "https://api.openai.com/v1",
            "secret_ref": "PROVIDER_DEFAULT_API_KEY",
        }
    )
    store.create_model(
        provider.id,
        {
            "upstream_id": "gpt-4.1-mini",
            "public_alias": "stronk-lm",
            "privacy_policy_id": "default-openai-chat",
        },
    )
    manager = ApplyManager(
        store=store,
        bundle_env_path=bundle_root / ".env",
        generated_dir=bundle_root / "generated",
        secrets_dir=bundle_root / "secrets",
        outbound_transport=httpx.ASGITransport(
            app=build_public_models_app(
                model_ids=["stronk-lm"],
                expected_bearer="stronk-public-key",
            )
        ),
        reload_wait_seconds=0.05,
        healthcheck_retry_delay_seconds=0.01,
    )

    first = await manager.start_apply()
    from stronk_mask.admin.apply import ApplyConflictError

    with pytest.raises(ApplyConflictError):
        await manager.start_apply()
    await wait_for_job(manager, first.job_id)
