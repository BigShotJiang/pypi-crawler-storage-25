from setuptools import find_namespace_packages, setup, find_packages

setup(name='eds_ds_tools',
      version='1.3',
      description='tools for data science',
      #packages=['eds_ds_tools'],
      author_email='wenleicao@gmail.com',
      zip_safe=True,
       include_package_data=True,      
      #packages=find_packages(where="."),
      # packages=find_namespace_packages(where="."),
      #   package_dir={"": "."},
      #   package_data={
      #       'eds_ds_tools': ['*.zip'], # Include all .zip files in 'eds_ds_tools'
      #   },
      #packages = find_packages(where="."),
      packages= ['eds_ds_tools', 'scripts'],
      
      
      )
