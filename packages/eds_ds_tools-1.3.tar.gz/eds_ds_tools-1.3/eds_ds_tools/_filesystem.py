from ._imports import *
from pathlib import Path

def rmtree(root):
    '''remove folder and subfolder file and directory'''
    for p in root.iterdir():
        if p.is_dir():
            rmtree(p)
        else:
            p.unlink()

    root.rmdir()
