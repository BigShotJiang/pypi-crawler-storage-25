#how to check last three month mape and rmse 

def evalute_pipeline ():
    '''
    replaced by athena view
    
    '''
    pass