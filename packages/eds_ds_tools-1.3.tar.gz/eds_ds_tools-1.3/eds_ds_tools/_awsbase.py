from ._imports import *
from ._config import config

class Aws_base:
    clients = {}

    @classmethod
    def _get_client(cls, env, service):    #only dl and dev have permission 
        if env not in cls.clients:
            if config.has_option(f'aws_{env}','aws_session_token'):
                cls.clients[env] = boto3.client(
                    service_name            = service,
                    region_name             = config[f'aws_{env}']['region'], 
                    aws_access_key_id       = config[f'aws_{env}']['aws_access_key_id'],
                    aws_secret_access_key   = config[f'aws_{env}']['aws_secret_access_key'],
                    aws_session_token       = config[f'aws_{env}']['aws_session_token']
                )
            else:
                cls.clients[env] = boto3.client(
                    service_name            = service,
                    region_name             = config[f'aws_{env}']['region'], 
                    aws_access_key_id       = config[f'aws_{env}']['aws_access_key_id'],
                    aws_secret_access_key   = config[f'aws_{env}']['aws_secret_access_key']
                )
        return cls.clients[env]