from cffds.projects.life_cash_flow_forecasting import *
from tabulate import tabulate
logfile, logger = create_logger()

env = sys.argv[1]
#test current code end to end, see if there is error 
cf_types = ['vendor','salary', 'claim loss', 'claim subrogation', 'inflow premiums','inflow receipts','outflow premiums',]
#cf_types = ['vendor','salary',  'inflow premiums','outflow premiums',]
df_job_status = pd.DataFrame (columns = ['Job Type', 'Status',  'Error Info' ])

if env =='dev':
    train_ends = ['2025-02-01']*len(cf_types)   #because dev env, data is not complete, for test purpose
    #train_ends = len(cf_types)*[None]  #we will run scheduled job in dev for few time like prod 
elif env =='prod':
    train_ends = len(cf_types)*[None]

#this is used to determine if job need to run as we schedule 4 time to only run on business day
run_flag = 0
actual_file_year_month, expected_file_year_month = s3_compare_file_dates_in_silver(env)
if env == 'prod':   
    if (expected_file_year_month  >  actual_file_year_month):
        run_flag = 1
    else:
        logger.info(f'''Please check {env} environment silver prediction folder 
                        expect run year month is {expected_file_year_month},
                        maxium year month aleady generated file is {actual_file_year_month}
                    ''')
else:  #dev will run without this limit
    run_flag = 1

if run_flag == 1:
    for t, te in zip(cf_types, train_ends):
        try:
            error_status = 0
            error_status = scoring_pipeline(cf_type = t, env = env, logger=logger, train_end=te)
            #save success info
            logger.info(f'job {t} completed successfully!')
            df_job_status.loc[len(df_job_status)] = [t, 'Success' if error_status ==0 else 'Fail', None]
        except Exception as e:
            error_status = 1
            logger.info(f'job {t} has error')
            logger.error('Error', exc_info=e)
            df_job_status.loc[len(df_job_status)] = [t, 'Fail', e]
    
    save_latest_prediction (env)
    save_monitor_dashboard_value (env)
    sns_sub =  f"Data science team cash flow job status in {env}"
    sns_msg = tabulate(df_job_status, headers='keys', tablefmt='psql')
    if env =='prod':
        send_sns(sns_sub, sns_msg, env)
    else:
        print(sns_msg)
    logger.info(sns_msg)
save_logger(logfile, env=env)