__all__ = [
    'send_sns'
]

from ._imports import *
from ._config import config
from ._awsbase import Aws_base

class Amazonsns(Aws_base):
    clients = {}

    @classmethod
    def get_client(cls, env):
        return super()._get_client(env, 'sns')
    
def snsclient(env):
    return Amazonsns.get_client(env)

@atexit.register
def sns_close():
    for client in Amazonsns.clients.values():
        client.close()


def send_sns(sub, msg, env):
    '''
    env = 'dev'
    sns_sub =  f"Data science team cash flow job status in {env}"
    sns_msg = tabulate(df_job_status, headers='keys', tablefmt='psql') #use tablulate to give table str format
    send_sns(sns_sub, sns_msg, env)  
    '''    
    if env == 'dev':
        arn = r'arn:aws:sns:us-east-2:392523246457:amica_eds_ds_dev' 
    elif env == 'prod':
        arn = r'arn:aws:sns:us-east-2:453362238738:amica_eds_ds_prod'
    response = snsclient(env).publish(
    TopicArn=arn,
    Message= msg,
    Subject= sub
    )

