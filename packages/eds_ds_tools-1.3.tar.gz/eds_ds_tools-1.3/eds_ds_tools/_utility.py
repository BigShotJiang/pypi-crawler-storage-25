from ._imports import *

def inspect_module(object):
    '''
    check object/function source
    inspect_module(evaluate_pipeline)
    '''
    import inspect
    return inspect.getmodule(object)

def filter_list (keyword, alist=[]):
    '''
    filter_list('corr', dir())
    '''
    f= keyword
    p = f'.*{f}.*'

    return list(filter(lambda x: re.search(p, x, re.IGNORECASE),   alist ))