"""Snowflake named query examples."""
