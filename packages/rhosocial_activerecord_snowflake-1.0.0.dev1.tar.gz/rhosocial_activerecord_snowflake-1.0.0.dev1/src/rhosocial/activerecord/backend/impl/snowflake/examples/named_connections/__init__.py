"""Snowflake named connection examples."""
