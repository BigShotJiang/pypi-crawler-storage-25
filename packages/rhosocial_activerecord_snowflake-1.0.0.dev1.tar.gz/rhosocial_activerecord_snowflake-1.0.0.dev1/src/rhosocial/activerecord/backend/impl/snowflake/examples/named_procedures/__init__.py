"""Snowflake named procedure examples."""
