"""B3 Instruments File BVBG.028.02 Options on Equities ingestion."""

from datetime import date
from io import StringIO
from logging import Logger
from typing import Optional, Union

import pandas as pd
from requests import Session

from stpstone.ingestion.countries.br.exchange.b3_instruments_file import B3InstrumentsFile


class B3InstrumentsFileOptnOnEqts(B3InstrumentsFile):
	"""B3 Instruments File BVBG.028.02 InstrumentsFile (OptnOnEqts)."""

	def __init__(
		self,
		date_ref: Optional[date] = None,
		logger: Optional[Logger] = None,
		cls_db: Optional[Session] = None,
	) -> None:
		"""Initialize the class.

		Parameters
		----------
		date_ref : Optional[date]
			The date of reference, by default None.
		logger : Optional[Logger]
			The logger, by default None.
		cls_db : Optional[Session]
			The database session, by default None.

		Returns
		-------
		None
		"""
		super().__init__(
			date_ref=date_ref,
			logger=logger,
			cls_db=cls_db,
		)

	def run(
		self,
		timeout: Optional[Union[int, float, tuple[float, float], tuple[int, int]]] = (
			12.0,
			21.0,
		),
		bool_verify: bool = True,
		bool_insert_or_ignore: bool = False,
		str_table_name: str = "br_b3_instruments_file_optn_on_eqts",
	) -> Optional[pd.DataFrame]:
		"""Run the ingestion process.

		If the database session is provided, the data is inserted into the database.

		Parameters
		----------
		timeout : Optional[Union[int, float, tuple[float, float], tuple[int, int]]]
			The timeout, by default (12.0, 21.0).
		bool_verify : bool
			Whether to verify the SSL certificate, by default True.
		bool_insert_or_ignore : bool
			Whether to insert or ignore the data, by default False.
		str_table_name : str
			The name of the table, by default "br_b3_instruments_file_optn_on_eqts".

		Returns
		-------
		Optional[pd.DataFrame]
			The transformed DataFrame.
		"""
		return super().run(
			timeout=timeout,
			bool_verify=bool_verify,
			bool_insert_or_ignore=bool_insert_or_ignore,
			dict_dtypes={
				"SCTY_CTGY": str,
				"ISIN": str,
				"DSTRBTN_ID": str,
				"CFICD": str,
				"TCKR_SYMB": str,
				"EXRC_PRIC": float,
				"OPTN_STYLE": str,
				"XPRTN_DT": "date",
				"OPTN_TP": str,
				"SRS_TP": str,
				"PRTCN_FLG": str,
				"PRM_UPFRNT_IND": str,
				"TRADG_START_DT": "date",
				"TRADG_END_DT": "date",
				"PMT_TP": str,
				"ALLCN_RND_LOT": int,
				"PRIC_FCTR": int,
				"TRADG_CCY": str,
				"DAYS_TO_STTLM": int,
				"DLVRY_TP": str,
				"AUTOMTC_EXRC_IND": str,
				"EXRC_PRIC_CCY": str,
				"FILE_NAME": "category",
			},
			str_fmt_dt="YYYY-MM-DD",
			cols_from_case="pascal",
			str_table_name=str_table_name,
		)

	def transform_data(self, file: StringIO, file_name: str) -> pd.DataFrame:
		"""Transform file content into a DataFrame.

		Parameters
		----------
		file : StringIO
			The file content.
		file_name : str
			The file name.

		Returns
		-------
		pd.DataFrame
			The transformed DataFrame.
		"""
		return super().transform_data(
			file=file,
			file_name=file_name,
			tag_parent="OptnOnEqtsInf",
			list_tags_children=[
				"SctyCtgy",
				"ISIN",
				"DstrbtnId",
				"CFICd",
				"TckrSymb",
				"ExrcPric",
				"OptnStyle",
				"XprtnDt",
				"OptnTp",
				"SrsTp",
				"PrtcnFlg",
				"PrmUpfrntInd",
				"TradgStartDt",
				"TradgEndDt",
				"PmtTp",
				"AllcnRndLot",
				"PricFctr",
				"TradgCcy",
				"DaysToSttlm",
				"DlvryTp",
				"AutomtcExrcInd",
			],
			list_tups_attributes=[
				("ExrcPric", "Ccy"),
			],
		)
