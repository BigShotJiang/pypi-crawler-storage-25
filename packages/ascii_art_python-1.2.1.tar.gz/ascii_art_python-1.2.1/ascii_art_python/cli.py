"""
An ASCII art image in a style new-skool.
"""
import mimetypes
import sys
import click
import ascii_art_python as aap


@click.command()
@click.argument("source_path", type=click.Path(exists=True))
@click.argument("target_filename", type=click.STRING)
@click.option("--length", "-l", default=15_000, help="The number of characters in the output")
@click.option("--mode", "-m", default="full_mode", help="full_mode / old_skool / new_skool")
def create_and_export(source_path, target_filename, length, mode):
    """
    Creates and exports an ASCII art image or video.
    """
    click.echo(f"▶ Converting '{source_path}'...")
    click.echo(f"▶ Settings: length={length}, mode={mode}")

    type_mime, _ = mimetypes.guess_type(source_path)

    if type_mime is None:
        click.secho("✗ Error: Unable to determine which export type to use")
        sys.exit(1)
    elif type_mime.startswith('image'):
        click.echo("▶ Export type: image")
        if mode == "full_mode":
            image = aap.full_mode.Image.from_path(source_path, length)
        elif mode == "old_skool":
            image = aap.old_skool.Image.from_path(source_path, length)
        elif mode == "new_skool":
            image = aap.new_skool.Image.from_path(source_path, length)
        else:
            click.secho(f"✗ Error: Mode '{mode}' is not recognized.")
            sys.exit(1)
        image.export(target_filename)
        click.echo("✓ Conversion complete!")
    elif type_mime.startswith('video'):
        click.echo("▶ Export type: video")
        if mode == "full_mode":
            video = aap.full_mode.Video(source_path, length, 10)
        elif mode == "old_skool":
            video = aap.old_skool.Video(source_path, length, 10)
        elif mode == "new_skool":
            video = aap.new_skool.Video(source_path, length, 10)
        else:
            click.secho(f"✗ Error: Mode '{mode}' is not recognized.")
            sys.exit(1)
        video.export(target_filename, sound=True)
        click.echo("✓ Conversion complete!")
    else:
        click.secho("✗ Error: Unable to determine which export type to use")
        sys.exit(1)

@click.command()
@click.argument("source_path", type=click.Path(exists=True))
@click.option("--length", "-l", default=3_000, help="The number of characters in the output")
@click.option("--mode", "-m", default="full_mode", help="full_mode / old_skool / new_skool")
def create_and_echo(source_path, length, mode):
    """
    Creates and prints an ASCII art image or video.
    """
    click.echo(f"▶ Converting '{source_path}'...")
    click.echo(f"▶ Settings: length={length}, mode={mode}")

    type_mime, _ = mimetypes.guess_type(source_path)

    if type_mime is None:
        click.secho("✗ Error: Unable to determine which export type to use")
        sys.exit(1)
    elif type_mime.startswith('image'):
        click.echo("▶ Echo type: image")
        if mode == "full_mode":
            image = aap.full_mode.Image.from_path(source_path, length)
        elif mode == "old_skool":
            image = aap.old_skool.Image.from_path(source_path, length)
        elif mode == "new_skool":
            image = aap.new_skool.Image.from_path(source_path, length)
        else:
            click.secho(f"✗ Error: Mode '{mode}' is not recognized.")
            sys.exit(1)
        click.echo(image.get_alternate_lines())
        click.echo("✓ Conversion complete!")
    elif type_mime.startswith('video'):
        click.echo("▶ Echo type: video")
        if mode == "full_mode":
            video = aap.full_mode.Video(source_path, length, 5)
        elif mode == "old_skool":
            video = aap.old_skool.Video(source_path, length, 5)
        elif mode == "new_skool":
            video = aap.new_skool.Video(source_path, length, 5)
        else:
            click.secho(f"✗ Error: Mode '{mode}' is not recognized.")
            sys.exit(1)
        video.print_in_terminal(click.echo)
        click.echo("✓ Conversion complete!")
    else:
        click.secho("✗ Error: Unable to determine which export type to use")
        sys.exit(1)
