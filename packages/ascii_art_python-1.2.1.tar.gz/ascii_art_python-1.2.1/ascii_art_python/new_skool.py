"""
ASCII art tools in a style new-skool.
"""
from typing import Union
import PIL.Image
from . import ascii_base

DEFAULT_GRID: list[str] = ["@", "$", "&", "#", "{", "*", "(", "=", ";", ":", ".", " "]

class Image(ascii_base.Image):
    """
    An ASCII art image in a style new-skool.
    """
    def __init__(
        self,
        image: PIL.Image.Image,
        max_size: int = 100_000,
        grid: Union[list[str], None] = None
    ) -> None:
        super().__init__(image, max_size)
        if grid is None:
            self.grid = DEFAULT_GRID
        else:
            self.grid = grid

    def to_list(self) -> list[str]:
        size = self.size
        ascii_list = [""] * size[1]
        image = self._source_wb.resize(size)
        converion_factor = len(self.grid) / 256
        for i in range(size[1]):
            for j in range(size[0]):
                ascii_list[i] += self.grid[int(image.getpixel((j, i)) * converion_factor)]
        return ascii_list

class Video(ascii_base.Video):
    """
    An ASCII art video in a style new-skool.
    """
    def __init__(self, path: str, frame_size: int = 12_000, fps: int = 10):
        super().__init__(path, Image, frame_size, fps)
