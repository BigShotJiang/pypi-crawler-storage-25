"""
Contains the tools necessary to manage and convert images and videos into ASCII art of all types.
"""
from typing import Union, Any
from abc import ABC, abstractmethod
import sys
from enum import IntEnum
import time
from tqdm import tqdm
import PIL.Image
import PIL.ImageDraw
import PIL.ImageFont
import cv2
from moviepy import VideoFileClip
import numpy
if sys.version_info < (3, 10):
    import importlib_resources as resources
else:
    from importlib import resources


FONT = resources.files("ascii_art_python.assets.fonts").joinpath("KreativeSquareSM.ttf")
FONT2 = resources.files("ascii_art_python.assets.fonts").joinpath("GoogleSansCode-Regular.ttf")
ASCII_CHARS: list[str] = ["@", "$", "&", "#", "{", "*", "(", "=", ";", ":", ".", " "]

class ExportType(IntEnum):
    """
    Defines the export format for the image or video.
    """
    TEXT_FILE = 1
    IMAGE_FILE = 0

class Image(ABC):
    """
    Class to convert and manipulate a classic image into ASCII art.
    """
    def __init__(self, image: PIL.Image.Image, max_size: int = 100_000) -> None:
        self._source_wb = image.convert("L")
        self._max_len = max_size

    @property
    def ratio(self) -> float:
        """
        The compression ratio between the original image and the desired image.
        """
        return min(1.0, numpy.sqrt(
            self._max_len / (self._source_wb.width * self._source_wb.height)
        ))

    @property
    def size(self) -> tuple[int, int]:
        """
        Dimensions (length, width) of the generated image.
        """
        return (
            int(self._source_wb.size[0] * self.ratio),
            int(self._source_wb.size[1] * self.ratio)
        )

    @abstractmethod
    def to_list(self) -> list[str]:
        """
        Converts the image into a list of character strings.

        Returns
        -------
        list[str]
            The image in ASCII art, line by line.
        """

    def get_alternate_lines(self) -> str:
        """
        Returns a character string that can be displayed directly in a standard terminal.
        (Terminal with a fixed-width font in 1/2 format.)

        Returns
        -------
        str
        """
        return "\n".join(self.to_list()[::2])

    def __str__(self) -> str:
        return "\n".join(self.to_list())

    def __len__(self) -> int:
        return min(self._max_len, self._source_wb.width * self._source_wb.height)

    def export(self, filename: str = "mika_export", mode: Union[ExportType, int] = 0) -> None:
        """
        Exports the ASCII image to a text file or an image.

        Parameters
        ----------
        filename : str, optional
            The export file name (without extension), default is "mika_export".
        mode : ExportType or int, optional
            The export format (text or image), default is 0 (IMAGE_FILE).
        
        Returns
        -------
        None
            Does not return anything.
        """
        if mode:
            with open(f"{filename}.txt", "w", encoding="ascii") as f:
                f.write(str(self))
        else:
            self.to_image().save(f"{filename}.png")

    def to_image(self) -> PIL.Image.Image:
        """
        Converts the generated ASCII art into a readable PIL image object.

        Returns
        -------
        PIL.Image.Image
            The generated image containing the ASCII art text.
        """
        font_size = 20
        try:
            font = PIL.ImageFont.truetype(FONT, font_size)
        except IOError:
            print(f"Warning: {FONT} not found for export. Using default font.")
            font = PIL.ImageFont.load_default()

        size_export = (self.size[0] * font_size, self.size[1] * font_size)

        output_image = PIL.Image.new("L", size_export, color=255)
        draw = PIL.ImageDraw.Draw(output_image)

        for i, line in enumerate(self.to_list()):
            draw.text((0, i * font_size), line, fill=0, font=font)
        return output_image

    @classmethod
    def from_path(cls, path: str, max_size: int = 10_000) -> "Image":
        """
        Creates an Image instance from an image file path.

        Parameters
        ----------
        path : str
            The path to the source image file.
        max_size : int, optional
            The maximum size of the resized image, default is 10_000.

        Returns
        -------
        Image
            A new instance of the Image class initialized with the image.
        """
        return cls(PIL.Image.open(path), max_size)

    @classmethod
    def from_string(cls, content: str, font_size: int = 15) -> "Image":
        """
        Creates an Image instance from a string.

        Parameters
        ----------
        content : str
            The text you want to convert.
        font_size : int, optional
            Text size.

        Returns
        -------
        Image
            A new instance of the Image class initialized with the text.
        """
        content_list = content.split("\n")
        try:
            font = PIL.ImageFont.truetype(FONT2, font_size)
        except IOError:
            print(f"Warning: {FONT} not found for export. Using default font.")
            font = PIL.ImageFont.load_default()

        longest_line = max(content_list, key=len)

        text_width = int(font.getlength(longest_line))

        size_export = (text_width, len(content_list) * font_size)

        output_image = PIL.Image.new("L", size_export, color=255)
        draw = PIL.ImageDraw.Draw(output_image)

        for i, s in enumerate(content_list):
            draw.text((0, i * font_size), s, fill=0, font=font)

        return cls(output_image, max_size = text_width * len(content_list) * font_size)

class Video:
    """
    Class to manage the conversion of a full video into an ASCII animation.
    """
    class ExportQuality(IntEnum):
        """
        Defines the compression level for video export.
        """
        HIGH = 1
        LOW = 0

    @staticmethod
    def transfer_audio(source_video_path: str, target_video_path: str, output_path: str) -> None:
        """
        Transfers audio from a source video to a target (muted) video.

        Parameters
        ----------
        source_video_path : str
            The path of the video containing the original audio.
        target_video_path : str
            The path of the target video generated in ASCII art.
        output_path : str
            The save path for the final video combining image and sound.
        
        Returns
        -------
        None
            Does not return anything.
        """
        source_video = VideoFileClip(source_video_path)
        audio = source_video.audio
        target_video = VideoFileClip(target_video_path)

        final_video = target_video.with_audio(audio)

        final_video.write_videofile(
            output_path,
            codec="libx264",
            audio_codec="aac",
            fps=target_video.fps,
            logger=None
        )

        source_video.close()
        target_video.close()
        final_video.close()

    @staticmethod
    def print_from_txt(txt: str) -> None:
        """
        Reads and displays an ASCII animation in the terminal from a text string.

        Parameters
        ----------
        txt : str
            The raw text containing the metadata and frames of the ASCII animation.

        Returns
        -------
        None
            Does not return anything.
        """
        lines = txt.split("\n")
        metadata = lines[0].split("@")
        lines_length, time_between = int(metadata[0]), float(metadata[1])
        next_sleep = time.time() + time_between

        for i in range(len(lines) // lines_length):
            time.sleep(max(next_sleep - time.time(), 0))
            print("\n".join(lines[i * lines_length:(i + 1) * lines_length]))
            next_sleep += time_between

    def __init__(self, path: str, cls: type, frame_size: int = 12_000, fps: int = 10) -> None:
        self.cls = cls
        self.path = path
        self.max_fps = fps
        self.max_frame_size = frame_size

        self._cap = None
        self._frame_skip = 1
        self._frame_count = 0

    def __iter__(self) -> "Video":
        """
        Initializes the video capture and returns the iterator (itself).
        """
        if self._cap is not None:
            self._cap.release()

        self._cap = cv2.VideoCapture(self.path)

        if not self._cap.isOpened():
            raise ValueError(f"Error: Unable to open the video at the location '{self.path}'")

        self._frame_skip = max(1, int(self.fps / self.max_fps))
        self._frame_count = 0

        return self

    def __next__(self) -> Any:
        """
        Retrieves and returns the next valid processed video frame.
        """
        if self._cap is None:
            raise StopIteration

        while True:
            succes, frame = self._cap.read()

            if not succes:
                self._cap.release()
                self._cap = None
                raise StopIteration

            if self._frame_count % self._frame_skip == 0:
                result_frame = self.cls(
                    PIL.Image.fromarray(cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)),
                    self.max_frame_size
                )
                self._frame_count += 1
                return result_frame

            self._frame_count += 1

    def __del__(self) -> None:
        """
        Ensures the release of video resources when the object is destroyed.
        """
        if hasattr(self, "_cap") and self._cap is not None:
            self._cap.release()

    def __len__(self) -> int:
        cap = cv2.VideoCapture(self.path)

        frame_skip = max(1, int(self.fps / self.max_fps))
        if not cap.isOpened():
            raise ValueError(f"Error: Unable to open the video at the location '{self.path}'")

        length = int(cap.get(cv2.CAP_PROP_FRAME_COUNT) / frame_skip)
        cap.release()
        return length

    @property
    def fps(self) -> float:
        """
        Retrieves the frames per second (FPS) of the source video.

        Returns
        -------
        float
            The FPS of the video.
        """
        cap = cv2.VideoCapture(self.path)

        if not cap.isOpened():
            raise ValueError(f"Error: Unable to open the video at the location '{self.path}'")

        fps = cap.get(cv2.CAP_PROP_FPS)
        cap.release()
        return fps

    @property
    def size(self) -> tuple[int, int]:
        """
        Calculates and returns the final size of the exported video frames.

        Returns
        -------
        tuple[int, int]
            A tuple (width, height) representing the size in pixels.
        """
        cap = cv2.VideoCapture(self.path)

        succes, frame = cap.read()
        cap.release()

        if not succes:
            raise ValueError("Error: Unable to read video frames to determine size.")

        size = self.cls(
            PIL.Image.fromarray(cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)),
            self.max_frame_size
        ).size
        return (size[0] * 20, size[1] * 20)

    def export(
        self,
        filename: str = "mika_export", export_type: int = 0,
        quality: Union[ExportQuality, int] = 0, sound: bool = False
    ):
        """
        Exports the ASCII video animation to text or video (.mp4 / .avi) format.

        Parameters
        ----------
        filename : str, optional
            The destination file name (without extension), default is "mika_export".
        export_type : int, optional
            The output format (text or video), default is 0.
        quality : ExportQuality, optional
            The quality/compression level of the video, default is 0.
        sound : bool, optional
            Indicates whether to include the original video's audio, default is False.
        
        Returns
        -------
        None
            Does not return anything.
        """
        if export_type:
            with open(filename + ".vid.txt", "w", encoding="ascii") as f:
                f.write(str(self.size[1] // 40) + "@" + str(1 / min(self.fps, self.max_fps)) + "\n")
                for frame in tqdm(self, "Exporting frames", len(self)):
                    f.write(frame.get_alternate_lines() + "\n")
        else:
            if quality:
                fourcc = cv2.VideoWriter_fourcc(*"FFV1")
                out = cv2.VideoWriter(
                    filename + ".avi",
                    fourcc,
                    self.fps / max(1, int(self.fps / self.max_fps)),
                    self.size, False
                )
            else:
                fourcc = cv2.VideoWriter_fourcc(*"mp4v")
                out = cv2.VideoWriter(
                    filename + ".mp4",
                    fourcc,
                    self.fps / max(1, int(self.fps / self.max_fps)),
                    self.size, False
                )

            for frame in tqdm(self, "Exporting frames", len(self)):
                tab = numpy.array(frame.to_image())
                out.write(tab)
            out.release()

            if sound:
                print("▶ Adding audio...")
                if quality:
                    self.transfer_audio(self.path, filename + ".avi", filename + "_audio.avi")
                else:
                    self.transfer_audio(self.path, filename + ".mp4", filename + "_audio.mp4")

    def print_in_terminal(self, func_print: callable = print) -> None:
        """
        Plays the ASCII video animation by displaying it directly in the terminal.
    
        Returns
        -------
        None
            Does not return anything.
        """
        time_between = 1 / min(self.fps, self.max_fps)
        next_sleep = time.time() + time_between

        for frame in self:
            time.sleep(max(next_sleep - time.time(), 0))
            func_print(frame.get_alternate_lines())
            next_sleep += time_between
