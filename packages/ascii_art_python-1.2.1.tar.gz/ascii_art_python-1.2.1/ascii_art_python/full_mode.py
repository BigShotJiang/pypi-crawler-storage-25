"""
ASCII art tools in a style that blends old-skool and new-skool elements.
"""
from typing import Union
import PIL.Image
import cv2
import numpy as np
from . import ascii_base

DEFAULT_GRID: list[str] = ["@", "$", "&", "#", "{", "*", "(", "=", ";", ":", ".", " "]

class Image(ascii_base.Image):
    """
    An ASCII art image in a style that blends old-skool and new-skool elements.
    """
    def __init__(
        self,
        image: PIL.Image.Image,
        max_size: int = 100_000,
        grid: Union[list[str], None] = None
    ) -> None:
        super().__init__(image, max_size)
        if grid is None:
            self.grid = DEFAULT_GRID
        else:
            self.grid = grid

    def to_list(self) -> list[str]:
        size = self.size
        image = self._source_wb.resize(self.size)
        array = np.array(image)
        edges = cv2.Canny(array, 50, 150)
        sobel_x = cv2.Sobel(array, cv2.CV_64F, 1, 0)
        sobel_y = cv2.Sobel(array, cv2.CV_64F, 0, 1)
        ascii_list = [""] * size[1]
        converion_factor = len(self.grid) / 256
        for i in range(size[1]):
            for j in range(size[0]):
                if edges[i, j] == 255:
                    y = sobel_y[i, j]
                    x = sobel_x[i, j]
                    angle = np.degrees(np.arctan2(y, x)) % 180
                    if 67.5 <= angle < 112.5:
                        ascii_list[i] += "-"  
                    elif 22.5 <= angle < 67.5:
                        ascii_list[i] += "/" 
                    elif 112.5 <= angle < 157.5:
                        ascii_list[i] += "\\"  
                    else:
                        ascii_list[i] += "|"  
                else:
                    ascii_list[i] += self.grid[int(image.getpixel((j, i)) * converion_factor)]
        return ascii_list

class Video(ascii_base.Video):
    """
    An ASCII art video in a style that blends old-skool and new-skool elements.
    """
    def __init__(self, path: str, frame_size: int = 12_000, fps: int = 10) -> None:
        super().__init__(path, Image, frame_size, fps)
