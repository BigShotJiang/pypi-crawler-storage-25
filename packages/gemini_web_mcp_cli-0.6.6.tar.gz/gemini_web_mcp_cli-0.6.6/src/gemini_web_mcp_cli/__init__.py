"""gemini-web-mcp-cli: MCP server and CLI for the Gemini web interface."""

__version__ = "0.6.6"
