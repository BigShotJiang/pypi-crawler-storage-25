from __future__ import annotations


from typing import Literal

from pydantic import AnyUrl, BaseModel, ConfigDict

ProviderName = Literal["google", "github"]


class GoogleUser(BaseModel):
    sub: str
    name: str | None = None
    given_name: str | None = None
    family_name: str | None = None
    picture: AnyUrl | None = None
    email: str | None = None
    email_verified: bool = False

    model_config = ConfigDict(extra="ignore")


class GithubUser(BaseModel):
    id: int
    login: str
    name: str | None = None
    email: str | None = None
    avatar_url: AnyUrl | None = None

    model_config = ConfigDict(extra="ignore")


class GoogleTokenResponse(BaseModel):
    access_token: str
    expires_in: int
    id_token: str | None = None
    scope: str | None = None
    token_type: str | None = None
    refresh_token: str | None = None
    refresh_token_expires_in: int | None = None

    model_config = ConfigDict(extra="ignore")


class GithubTokenResponse(BaseModel):
    access_token: str
    scope: str | None = None
    token_type: str

    model_config = ConfigDict(extra="ignore")


class GoogleTokenErrorResponse(BaseModel):
    error: str
    error_description: str

    model_config = ConfigDict(extra="ignore")
