from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True, slots=True)
class OAuthMessages:
    """User-facing messages raised by the package.

    Override any field you want. Unchanged fields keep the default text.
    """

    token_exchange_failed: str = "Token exchange failed."
    missing_code: str = "Missing 'code' query parameter."
    missing_state: str = "Missing 'state' query parameter."
    missing_state_cookie: str = "Missing OAuth state cookie."
    state_mismatch: str = "OAuth state mismatch."
    invalid_token_response: str = "The provider token response format was invalid."
    invalid_user_response: str = "The provider user response format was invalid."
    user_fetch_failed: str = "Failed to fetch the provider user."
    provider_error: str = "The OAuth provider returned an error."
    invalid_or_expired_state: str = "OAuth state is invalid or expired."
