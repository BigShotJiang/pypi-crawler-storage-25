from typing import Protocol


class StateStore(Protocol):
    """Protocol for temporary OAuth state storage.

    The value must only be consumable once to prevent cross-site request forgery.
    """

    async def set(self, key: str, value: str, ttl_seconds: int = 300) -> None:
        """Save `value` under `key` for `ttl_seconds` seconds."""

    async def pop(self, key: str) -> str | None:
        """Return and delete the value stored at `key`.

        Return `None` when the key does not exist or is already expired.
        """
