from __future__ import annotations

from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from redis.asyncio import Redis


class RedisStore:
    """Redis-backed state store.

    This store is safe for multi-instance / horizontally scaled deployments.

    Uses `SET key value EX seconds` (`SETEX` - deprecated) + `GETDEL key` so each value is consumed exactly once.

    Args:
        redis: An `redis.asyncio.Redis` client instance.
        prefix: Prefix added to every key (default `"dso:"`).
    """

    def __init__(self, redis: Redis, prefix: str = "dso:"):
        self._redis = redis
        self._prefix = prefix

    def _key(self, state: str) -> str:
        return f"{self._prefix}{state}"

    async def set(self, key: str, value: str, ttl_seconds: int = 300) -> None:
        """Save a value with an expiration time."""

        await self._redis.set(self._key(key), value, ttl_seconds)

    async def pop(self, key: str) -> str | None:
        """Return a value once and remove it from Redis."""

        # By default Redis return binary responses, to decode them use decode_responses=True
        value: Any = await self._redis.getdel(self._key(key))

        if not value:
            return None

        if isinstance(value, bytes):
            return value.decode()

        return str(value)
