from asyncio import Lock
from time import monotonic


class MemoryStore:
    """In-process state store.

    Use this only for single-instance deployments.

    For multi-instance deployments consider `RedisStore` or write your own implementation.

    Thread-safe via :class:`asyncio.Lock`.
    """

    def __init__(self):
        self._store: dict[str, tuple[str, float]] = {}
        self._lock = Lock()

    async def set(self, key: str, value: str, ttl_seconds: int = 300) -> None:
        """Save a value until it expires."""

        async with self._lock:
            self._store[key] = (value, monotonic() + ttl_seconds)

    async def pop(self, key: str) -> str | None:
        """Return a value once and remove it from the store."""

        async with self._lock:
            entry = self._store.pop(key, None)

        if entry is None:
            return None

        value, expires_at = entry
        return None if monotonic() > expires_at else value
