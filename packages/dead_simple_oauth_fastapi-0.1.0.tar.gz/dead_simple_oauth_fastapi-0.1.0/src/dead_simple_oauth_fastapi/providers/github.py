from urllib.parse import urlencode

import httpx
from fastapi import status
from fastapi.exceptions import HTTPException
from pydantic import ValidationError

from .base import BaseOAuthClient
from ..models import GithubTokenResponse, GithubUser


class GitHubOAuthClient(BaseOAuthClient[GithubUser]):
    """FastAPI helper for the GitHub web OAuth flow."""

    def get_authorization_url(self, state: str, challenge: str) -> str:
        default_scopes = ("read:user", "user:email")
        scope = ",".join(self.scopes or default_scopes)
        params = {
            "client_id": self.client_id,
            "redirect_uri": self.redirect_uri,
            "scope": scope,
            "state": state,
            "code_challenge": challenge,
            "code_challenge_method": "S256",
        }

        return "https://github.com/login/oauth/authorize?" + urlencode(params)

    async def exchange_code(self, code: str, verifier: str) -> GithubUser:
        """Exchange the GitHub authorization code and return a typed user."""

        async with httpx.AsyncClient() as client:
            token_res = await client.post(
                "https://github.com/login/oauth/access_token",
                headers={"Accept": "application/json"},
                data={
                    "code": code,
                    "client_id": self.client_id,
                    "client_secret": self.client_secret,
                    "redirect_uri": self.redirect_uri,
                    "grant_type": "authorization_code",
                    "code_verifier": verifier,
                },
            )
            if not token_res.is_success:
                raise HTTPException(status.HTTP_400_BAD_REQUEST, self.messages.token_exchange_failed)

            try:
                token = GithubTokenResponse.model_validate(token_res.json())
            except ValidationError:
                raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=self.messages.invalid_token_response)

            user_res = await client.get("https://api.github.com/user", headers={"Authorization": f"Bearer {token.access_token}"})

            if not user_res.is_success:
                raise HTTPException(status.HTTP_400_BAD_REQUEST, self.messages.user_fetch_failed)

            try:
                return GithubUser.model_validate(user_res.json())
            except ValidationError:
                raise HTTPException(status.HTTP_400_BAD_REQUEST, self.messages.invalid_user_response)
