from urllib.parse import urlencode

import httpx
from fastapi import status
from fastapi.exceptions import HTTPException
from pydantic import ValidationError

from .base import BaseOAuthClient
from ..models import GoogleTokenResponse, GoogleUser


class GoogleOAuthClient(BaseOAuthClient[GoogleUser]):
    """FastAPI helper for the Google web OAuth flow."""

    def get_authorization_url(self, state: str, challenge: str) -> str:
        default_scopes = ("openid", "email", "profile")
        scope = " ".join(self.scopes or default_scopes)
        params = {
            "client_id": self.client_id,
            "redirect_uri": self.redirect_uri,
            "response_type": "code",
            "scope": scope,
            "state": state,
            "access_type": "offline",
            "prompt": "consent",
            "code_challenge": challenge,
            "code_challenge_method": "S256",
        }
        return "https://accounts.google.com/o/oauth2/v2/auth?" + urlencode(params)

    async def exchange_code(self, code: str, verifier: str) -> GoogleUser:
        """Exchange the Google authorization code and return a typed user."""

        async with httpx.AsyncClient() as client:
            token_res = await client.post(
                "https://oauth2.googleapis.com/token",
                data={
                    "code": code,
                    "client_id": self.client_id,
                    "client_secret": self.client_secret,
                    "redirect_uri": self.redirect_uri,
                    "grant_type": "authorization_code",
                    "code_verifier": verifier,
                },
            )
            if not token_res.is_success:
                raise HTTPException(status.HTTP_400_BAD_REQUEST, self.messages.token_exchange_failed)

            try:
                token = GoogleTokenResponse.model_validate(token_res.json())
            except ValidationError:
                raise HTTPException(status.HTTP_400_BAD_REQUEST, self.messages.invalid_token_response)

            user_res = await client.get("https://openidconnect.googleapis.com/v1/userinfo", headers={"Authorization": f"Bearer {token.access_token}"})

            if not user_res.is_success:
                raise HTTPException(status.HTTP_400_BAD_REQUEST, self.messages.user_fetch_failed)

            try:
                return GoogleUser.model_validate(user_res.json())
            except ValidationError:
                raise HTTPException(status.HTTP_400_BAD_REQUEST, self.messages.invalid_user_response)
