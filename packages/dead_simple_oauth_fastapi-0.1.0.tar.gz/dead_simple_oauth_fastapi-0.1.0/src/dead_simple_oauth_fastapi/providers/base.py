from abc import ABC, abstractmethod
import base64
import hashlib
import os
import secrets
from typing import Annotated, Generic, Literal, TypeVar

from fastapi import Cookie, Query, Request, status
from fastapi.exceptions import HTTPException
from fastapi.responses import RedirectResponse
from pydantic import BaseModel
from collections.abc import Awaitable, Callable, Sequence

from dead_simple_oauth_fastapi.messages import OAuthMessages

from ..storage.base import StateStore
from ..storage.memory import MemoryStore

UserT = TypeVar("UserT", bound=BaseModel)


class BaseOAuthClient(Generic[UserT], ABC):
    """Base class for OAuth clients.

    Subclasses implement provider-specific authorization parameters and token exchange logic.
    """

    def __init__(
        self,
        client_id: str,
        client_secret: str,
        redirect_uri: str,
        scopes: Sequence[str] | None = None,
        store: StateStore | None = None,
        ttl_seconds: int = 300,
        cookie_name: str = "oauth_state",
        cookie_path: str = "/",
        cookie_domain: str | None = None,
        cookie_samesite: Literal["lax", "strict", "none"] | None = "lax",
        secure_cookie: bool = True,
        messages: OAuthMessages | None = None,
    ) -> None:
        self.client_id = client_id
        self.client_secret = client_secret
        self.redirect_uri = redirect_uri
        self.scopes = scopes
        self.store = store or MemoryStore()
        self.ttl_seconds = ttl_seconds
        self.cookie_name = cookie_name
        self.cookie_path = cookie_path
        self.cookie_domain = cookie_domain
        self.cookie_samesite: Literal["lax", "strict", "none"] | None = cookie_samesite
        self.secure_cookie = secure_cookie
        self.messages = messages or OAuthMessages()

    @staticmethod
    def _generate_state() -> str:
        """Return a random state token for CSRF protection."""
        # return secrets.token_urlsafe(32)
        return hashlib.sha256(os.urandom(1024)).hexdigest()

    @staticmethod
    def _build_pkce_pair() -> tuple[str, str]:
        """Return (code_verifier, code_challenge) for PKCE S256."""

        verifier = secrets.token_urlsafe(48)
        digest = hashlib.sha256(verifier.encode()).digest()
        challenge = base64.urlsafe_b64encode(digest).rstrip(b"=").decode()
        return verifier, challenge

    async def redirect(self, request: Request) -> RedirectResponse:
        """Create a new OAuth flow and redirect the user to the provider."""

        state = self._generate_state()
        verifier, challenge = self._build_pkce_pair()

        await self.store.set(state, verifier, self.ttl_seconds)

        url = self.get_authorization_url(state, challenge)
        res = RedirectResponse(url)
        res.set_cookie(
            key=self.cookie_name,
            value=state,
            max_age=self.ttl_seconds,
            path=self.cookie_path,
            domain=self.cookie_domain,
            secure=self.secure_cookie,
            httponly=True,
            samesite=self.cookie_samesite,
        )
        return res

    @abstractmethod
    def get_authorization_url(self, state: str, challenge: str) -> str:
        """Return the provider authorization URL."""

    def callback_dependency(self) -> Callable[..., Awaitable[UserT]]:
        """Return a FastAPI dependency that validates the callback and returns the user."""

        async def dependency(
            code: Annotated[str | None, Query()] = None,
            state: Annotated[str | None, Query()] = None,
            cookie_state: Annotated[str | None, Cookie(alias=self.cookie_name)] = None,
            error: Annotated[str | None, Query(alias="error")] = None,
        ) -> UserT:
            if error is not None:
                raise HTTPException(status.HTTP_400_BAD_REQUEST, self.messages.provider_error)

            if code is None:
                raise HTTPException(status.HTTP_400_BAD_REQUEST, self.messages.missing_code)

            if state is None:
                raise HTTPException(status.HTTP_400_BAD_REQUEST, self.messages.missing_state)

            if cookie_state is None:
                raise HTTPException(status.HTTP_400_BAD_REQUEST, self.messages.missing_state_cookie)

            if state != cookie_state:
                raise HTTPException(status.HTTP_400_BAD_REQUEST, self.messages.state_mismatch)

            verifier = await self.store.pop(state)
            if verifier is None:
                raise HTTPException(status.HTTP_400_BAD_REQUEST, self.messages.invalid_or_expired_state)

            return await self.exchange_code(code, verifier)

        return dependency

    @abstractmethod
    async def exchange_code(self, code: str, verifier: str) -> UserT:
        """Exchange an authorization code for a provider user."""
