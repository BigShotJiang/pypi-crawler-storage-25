from __future__ import annotations

import re
from collections.abc import Callable
from typing import Any

from rich.console import Console, Group
from rich.text import Text

from comate_cli.terminal_agent.figures import (
    BLACK_CIRCLE,
    BOTTOM_LEFT_CROP,
    BULLET,
    HEAVY_MULTIPLICATION,
    INJECTED_ARROW,
    THINKING_BUBBLE,
)
from comate_cli.terminal_agent.message_style import ASSISTANT_PREFIX
from comate_cli.terminal_agent.models import HistoryEntry


def _render_subtitle_line(subtitle: str, *, error: bool = False) -> Text:
    """Render a ⎿ subtitle line for tool results."""
    line = Text()
    line.append(f"  {BOTTOM_LEFT_CROP} ", style="#555555")
    if error:
        line.append(f" {subtitle}", style="bold red")
    else:
        line.append(f" {subtitle}", style="dim")
    return line


# list / ordered-list / blockquote 起始标记。loose list ("- a\n\n- b\n") 流式
# 按行 commit 后，items 之间的空行会被切成独立 assistant entry，渲染产生多余空行；
# claude code 把整段喂 marked.lexer 在 token 层就消化了，我们逐行 commit 架构下
# 在 printer 层精准跳过即可达到同样视觉效果。
_BLOCK_MARKER_RE = re.compile(r"^\s*([-*+]|\d+\.|>)\s+")


def _starts_with_block_marker(entry: HistoryEntry) -> bool:
    if entry.entry_type != "assistant":
        return False
    text = entry.text
    if not isinstance(text, str):
        return False
    first_line = text.lstrip("\n").split("\n", 1)[0]
    return bool(_BLOCK_MARKER_RE.match(first_line))


def _is_blank_assistant(entry: HistoryEntry) -> bool:
    if entry.entry_type != "assistant":
        return False
    text = entry.text
    return isinstance(text, str) and text.strip() == ""


def _entry_prefix(entry: HistoryEntry) -> str:
    if entry.entry_type == "user":
        return ">"
    if entry.entry_type == "assistant":
        return ASSISTANT_PREFIX
    if entry.entry_type == "tool_call":
        return INJECTED_ARROW
    if entry.entry_type == "tool_result":
        return BLACK_CIRCLE
    if entry.entry_type == "thinking":
        return THINKING_BUBBLE
    return BULLET


def _entry_content(
    entry: HistoryEntry,
    *,
    terminal_width: int,
    render_markdown_to_plain: Callable[..., str],
) -> str:
    if entry.entry_type != "assistant":
        return str(entry.text)
    width = max(terminal_width - 6, 40)
    return render_markdown_to_plain(str(entry.text), width=width)


def render_history_group(
    console: Console,
    entries: list[HistoryEntry],
    *,
    terminal_width: int,
    render_markdown_to_plain: Callable[..., str],
    prev_was_assistant: bool = False,
    prev_was_thinking: bool = False,
    assume_run_continues_at_tail: bool = False,
) -> Group | None:
    if not entries:
        return None

    # spec 对照 claude code utils/messages.ts:740 normalizeMessages：
    # "1 dot = 1 logical assistant block"。streaming 管线把每行 commit 成一条
    # entry_type="assistant" 的 HistoryEntry（spec §6.5），所以"逻辑 message"在
    # printer 这一层被识别为"连续 assistant entry 的 run"——只在 run 起始处加 `●`，
    # 后续行用 2 空格缩进保持视觉对齐。`prev_was_assistant` 把 run 状态跨 drain 传过来。
    renderables: list[Any] = []
    needs_leading_gap_after_thinking = prev_was_thinking
    for idx, entry in enumerate(entries):
        is_assistant = entry.entry_type == "assistant"
        in_run_continuation = is_assistant and prev_was_assistant
        next_entry = entries[idx + 1] if idx + 1 < len(entries) else None
        next_is_assistant = next_entry is not None and next_entry.entry_type == "assistant"
        next_is_thinking = next_entry is not None and next_entry.entry_type == "thinking"

        # 跳过位于两个块标记 entry 之间的空 assistant entry（loose list 视觉对齐）
        if is_assistant and _is_blank_assistant(entry):
            prev_entry = entries[idx - 1] if idx > 0 else None
            if (
                prev_entry is not None
                and _starts_with_block_marker(prev_entry)
                and next_entry is not None
                and _starts_with_block_marker(next_entry)
            ):
                continue

        # Thinking entries: 灰色显示，无前缀。thinking 流式文本里的空白行
        # 只属于模型输出内容，不应把同一个 thinking block 视觉上切散。
        if entry.entry_type == "thinking":
            content = str(entry.text)
            content_lines = [line for line in content.splitlines() if line.strip()]
            if not content_lines:
                prev_was_assistant = False
                continue
            needs_leading_gap_after_thinking = False
            line_text = Text()
            line_text.append("  ", style="dim")
            line_text.append(content_lines[0], style="dim")
            for line in content_lines[1:]:
                line_text.append("\n")
                line_text.append("  ", style="dim")
                line_text.append(line, style="dim")
            renderables.append(line_text)
            is_batch_tail = next_entry is None
            suppress_trailing_gap = (
                is_batch_tail
                and assume_run_continues_at_tail
            )
            if not next_is_thinking and not suppress_trailing_gap:
                renderables.append(Text(""))
            prev_was_assistant = False
            continue

        if needs_leading_gap_after_thinking:
            renderables.append(Text(""))
            needs_leading_gap_after_thinking = False

        # Elapsed entries: 灰色显示，无前缀
        if entry.entry_type == "elapsed":
            line_text = Text()
            line_text.append(str(entry.text), style="dim")
            renderables.append(line_text)
            renderables.append(Text(""))
            prev_was_assistant = False
            continue

        # System entries: 按 severity 区分视觉样式，缩进 2 空格与消息内容列对齐
        if entry.entry_type == "system":
            if entry.severity == "error":
                text_style = "bold #FF6B6B"
            elif entry.severity == "warning":
                text_style = "#E8B830"
            else:
                text_style = "dim"
            content = str(entry.text)
            content_lines = content.splitlines() or [""]
            line_text = Text()
            line_text.append(f"  {content_lines[0]}", style=text_style)
            for line in content_lines[1:]:
                line_text.append("\n")
                line_text.append(f"  {line}", style=text_style)
            renderables.append(line_text)
            renderables.append(Text(""))
            prev_was_assistant = False
            continue

        # File reference hint: reuse subtitle style, attached to preceding user message
        if entry.entry_type == "file_ref":
            if renderables and isinstance(renderables[-1], Text) and not renderables[-1].plain:
                renderables.pop()
            renderables.append(_render_subtitle_line(str(entry.text)))
            renderables.append(Text(""))
            prev_was_assistant = False
            continue

        if entry.entry_type == "tool_result":
            prefix_char = HEAVY_MULTIPLICATION if entry.severity == "error" else BLACK_CIRCLE
            prefix_style = "bold red" if entry.severity == "error" else "bold green"

            is_error = entry.severity == "error"

            if isinstance(entry.text, Text):
                # Rich Text object — preserve styled content (e.g. colored diff)
                text_lines = entry.text.split("\n")
                first_line = Text()
                first_line.append(f"{prefix_char} ", style=prefix_style)
                first_line.append_text(text_lines[0] if text_lines else Text())
                renderables.append(first_line)
                if entry.subtitle:
                    renderables.append(_render_subtitle_line(entry.subtitle, error=is_error))
                for line in text_lines[1:]:
                    renderables.append(line)
                renderables.append(Text(""))
                prev_was_assistant = False
                continue

            content = str(entry.text)
            content_lines = content.splitlines() or [""]

            line_text = Text()
            line_text.append(f"{prefix_char} ", style=prefix_style)
            line_text.append(content_lines[0])
            for line in content_lines[1:]:
                line_text.append("\n")
                line_text.append("  ")
                line_text.append(line)

            renderables.append(line_text)
            if entry.subtitle:
                renderables.append(_render_subtitle_line(entry.subtitle, error=is_error))
            renderables.append(Text(""))
            prev_was_assistant = False
            continue

        if hasattr(entry.text, "__rich_console__"):
            if in_run_continuation:
                prefixed = Text("  ", style="bold")
            else:
                prefix = _entry_prefix(entry)
                prefixed = Text(f"{prefix} ", style="bold")
            prefixed.append_text(entry.text)  # type: ignore[arg-type]
            renderables.append(prefixed)
        else:
            content = _entry_content(
                entry,
                terminal_width=terminal_width,
                render_markdown_to_plain=render_markdown_to_plain,
            )
            content_lines = content.splitlines() or [""]
            if in_run_continuation:
                first_line = f"  {content_lines[0]}"
            else:
                prefix = _entry_prefix(entry)
                first_line = f"{prefix} {content_lines[0]}"
            lines = [first_line]
            for line in content_lines[1:]:
                lines.append(f"  {line}")
            renderables.append("\n".join(lines))

        # 在 assistant run 内部不插入空行；只有 run 末尾才与下一段拉开。
        # assume_run_continues_at_tail=True 时（drain 在 streaming 中），把 batch
        # 末尾的 assistant entry 当作"run 仍在续"处理，不加 trailing Text("")，
        # 避免 4-6fps drain 把同一条逻辑 message 切碎后每个 batch 末尾各加一空行。
        is_batch_tail = next_entry is None
        suppress_trailing_gap = (
            is_batch_tail
            and is_assistant
            and assume_run_continues_at_tail
        )
        if not (is_assistant and next_is_assistant) and not suppress_trailing_gap:
            renderables.append(Text(""))
        prev_was_assistant = is_assistant

    if not renderables:
        return None

    return Group(*renderables)


async def print_history_group_async(console: Console, group: Group) -> None:
    console.print(group, soft_wrap=True)


def print_history_group_sync(console: Console, group: Group) -> None:
    console.print(group, soft_wrap=True)
