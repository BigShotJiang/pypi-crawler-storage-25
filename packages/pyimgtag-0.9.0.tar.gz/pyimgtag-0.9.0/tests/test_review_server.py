"""Tests for the review UI FastAPI server."""

from __future__ import annotations

from unittest.mock import patch

import pytest

fastapi = pytest.importorskip("fastapi")
from starlette.testclient import TestClient  # noqa: E402

from pyimgtag.models import ImageResult  # noqa: E402
from pyimgtag.progress_db import ProgressDB  # noqa: E402
from pyimgtag.review_server import create_app  # noqa: E402
from pyimgtag.webapp.routes_review import _make_thumbnail  # noqa: E402


def _make_db(tmp_path):
    """Create a ProgressDB with a few test images."""
    db_path = tmp_path / "test.db"
    db = ProgressDB(db_path=db_path)
    imgs = [
        ("a.jpg", ["sunset", "beach"], "Warm sunset.", "delete"),
        ("b.jpg", ["dog", "park"], "Dog in park.", "review"),
        ("c.jpg", ["mountain"], "Snowy peaks.", None),
    ]
    for name, tags, summary, cleanup in imgs:
        img = tmp_path / name
        img.write_bytes(b"\x00" * 10)
        db.mark_done(
            img,
            ImageResult(
                file_path=str(img),
                file_name=name,
                tags=tags,
                scene_summary=summary,
                cleanup_class=cleanup,
            ),
        )
    db.close()
    return db_path


class TestReviewServerRoutes:
    def test_index_returns_html(self, tmp_path):
        app = create_app(db_path=_make_db(tmp_path))
        client = TestClient(app)
        r = client.get("/")
        assert r.status_code == 200
        assert "text/html" in r.headers["content-type"]
        assert "pyimgtag" in r.text

    def test_stats_returns_counts(self, tmp_path):
        app = create_app(db_path=_make_db(tmp_path))
        client = TestClient(app)
        r = client.get("/api/stats")
        assert r.status_code == 200
        data = r.json()
        assert data["total"] == 3
        assert "ok" in data
        assert "error" in data

    def test_images_returns_all(self, tmp_path):
        app = create_app(db_path=_make_db(tmp_path))
        client = TestClient(app)
        r = client.get("/api/images")
        assert r.status_code == 200
        data = r.json()
        assert data["total"] == 3
        assert len(data["items"]) == 3

    def test_images_filter_cleanup(self, tmp_path):
        app = create_app(db_path=_make_db(tmp_path))
        client = TestClient(app)
        r = client.get("/api/images?cleanup=delete")
        assert r.status_code == 200
        data = r.json()
        assert data["total"] == 1
        assert data["items"][0]["cleanup_class"] == "delete"

    def test_images_pagination(self, tmp_path):
        app = create_app(db_path=_make_db(tmp_path))
        client = TestClient(app)
        r1 = client.get("/api/images?limit=2&offset=0")
        r2 = client.get("/api/images?limit=2&offset=2")
        assert r1.status_code == 200
        assert r2.status_code == 200
        assert len(r1.json()["items"]) == 2
        assert len(r2.json()["items"]) == 1

    def test_images_items_have_tags_list(self, tmp_path):
        app = create_app(db_path=_make_db(tmp_path))
        client = TestClient(app)
        data = client.get("/api/images").json()
        for item in data["items"]:
            assert "tags_list" in item
            assert isinstance(item["tags_list"], list)

    def test_thumbnail_missing_returns_404(self, tmp_path):
        app = create_app(db_path=_make_db(tmp_path))
        client = TestClient(app)
        r = client.get("/thumbnail?path=/nonexistent/file.jpg")
        assert r.status_code == 404

    def test_patch_tags_updates(self, tmp_path):
        db_path = _make_db(tmp_path)
        app = create_app(db_path=db_path)
        client = TestClient(app)
        # Get the path of the first image
        items = client.get("/api/images").json()["items"]
        fp = items[0]["file_path"]
        r = client.patch(
            "/api/images/tags",
            json={"file_path": fp, "tags": ["new", "tag"]},
        )
        assert r.status_code == 200
        updated = r.json()
        assert updated["tags_list"] == ["new", "tag"]

    def test_patch_tags_normalizes(self, tmp_path):
        db_path = _make_db(tmp_path)
        app = create_app(db_path=db_path)
        client = TestClient(app)
        items = client.get("/api/images").json()["items"]
        fp = items[0]["file_path"]
        r = client.patch(
            "/api/images/tags",
            json={"file_path": fp, "tags": ["  UPPER  ", "dupe", "dupe"]},
        )
        assert r.status_code == 200
        assert r.json()["tags_list"] == ["upper", "dupe"]

    def test_patch_tags_unknown_path_returns_404(self, tmp_path):
        app = create_app(db_path=_make_db(tmp_path))
        client = TestClient(app)
        r = client.patch(
            "/api/images/tags",
            json={"file_path": "/no/such/image.jpg", "tags": ["a"]},
        )
        assert r.status_code == 404

    def test_patch_cleanup_set(self, tmp_path):
        db_path = _make_db(tmp_path)
        app = create_app(db_path=db_path)
        client = TestClient(app)
        items = client.get("/api/images").json()["items"]
        # Find the image with no cleanup_class
        fp = next(i["file_path"] for i in items if i["cleanup_class"] is None)
        r = client.patch(
            "/api/images/cleanup",
            json={"file_path": fp, "cleanup_class": "delete"},
        )
        assert r.status_code == 200
        assert r.json()["cleanup_class"] == "delete"

    def test_patch_cleanup_clear(self, tmp_path):
        db_path = _make_db(tmp_path)
        app = create_app(db_path=db_path)
        client = TestClient(app)
        items = client.get("/api/images").json()["items"]
        fp = next(i["file_path"] for i in items if i["cleanup_class"] == "delete")
        r = client.patch(
            "/api/images/cleanup",
            json={"file_path": fp, "cleanup_class": None},
        )
        assert r.status_code == 200
        assert r.json()["cleanup_class"] is None

    def test_patch_cleanup_unknown_path_returns_404(self, tmp_path):
        app = create_app(db_path=_make_db(tmp_path))
        client = TestClient(app)
        r = client.patch(
            "/api/images/cleanup",
            json={"file_path": "/no/such/image.jpg", "cleanup_class": "delete"},
        )
        assert r.status_code == 404

    def test_images_empty_result_for_nonexistent_filter(self, tmp_path):
        app = create_app(db_path=_make_db(tmp_path))
        client = TestClient(app)
        r = client.get("/api/images?cleanup=nonexistent_class")
        assert r.status_code == 200
        data = r.json()
        assert data["total"] == 0
        assert data["items"] == []

    def test_images_out_of_range_offset_returns_empty(self, tmp_path):
        app = create_app(db_path=_make_db(tmp_path))
        client = TestClient(app)
        r = client.get("/api/images?limit=50&offset=9999")
        assert r.status_code == 200
        data = r.json()
        assert data["items"] == []


class TestThumbnailContainment:
    """Regression tests for issue #98.A — /thumbnail must only serve DB-indexed paths."""

    def _make_db_with_real_image(self, tmp_path):
        """Return (db_path, img_path) with one real JPEG inserted into the DB."""
        from PIL import Image

        img_path = tmp_path / "real.jpg"
        img = Image.new("RGB", (40, 40), color="green")
        img.save(str(img_path), "JPEG")

        db_path = tmp_path / "test.db"
        db = ProgressDB(db_path=db_path)
        db.mark_done(
            img_path,
            ImageResult(
                file_path=str(img_path),
                file_name="real.jpg",
                tags=["test"],
                scene_summary="Test image.",
                cleanup_class=None,
            ),
        )
        db.close()
        return db_path, img_path

    def test_arbitrary_path_returns_404(self, tmp_path, monkeypatch):
        """A valid JPEG not in the DB must return 404 (the DB is the allow-list)."""
        from PIL import Image

        thumb_dir = tmp_path / "thumbs"
        monkeypatch.setattr("pyimgtag.webapp.routes_review._THUMB_DIR", thumb_dir)
        db_path, _ = self._make_db_with_real_image(tmp_path)

        # Create a real JPEG that is NOT indexed in the DB.
        secret = tmp_path / "secret.jpg"
        Image.new("RGB", (10, 10), color="red").save(str(secret), "JPEG")

        app = create_app(db_path=db_path)
        client = TestClient(app)
        r = client.get(f"/thumbnail?path={secret}")
        assert r.status_code == 404

    def test_indexed_path_returns_jpeg(self, tmp_path, monkeypatch):
        """A path recorded in the DB must return 200 with JPEG content."""
        thumb_dir = tmp_path / "thumbs"
        monkeypatch.setattr("pyimgtag.webapp.routes_review._THUMB_DIR", thumb_dir)
        db_path, img_path = self._make_db_with_real_image(tmp_path)
        app = create_app(db_path=db_path)
        client = TestClient(app)
        r = client.get(f"/thumbnail?path={img_path}")
        assert r.status_code == 200
        assert r.content[:3] == b"\xff\xd8\xff"


class TestReviewDocsDisabled:
    """Regression tests for issue #98 — review UI must not expose API schema."""

    def test_openapi_json_returns_404(self, tmp_path):
        app = create_app(db_path=_make_db(tmp_path))
        client = TestClient(app)
        r = client.get("/openapi.json")
        assert r.status_code == 404


class TestMakeThumbnailExtra:
    def test_creates_cache_dir_if_missing(self, tmp_path, monkeypatch):
        thumb_dir = tmp_path / "new_thumbs"
        assert not thumb_dir.exists()
        monkeypatch.setattr("pyimgtag.webapp.routes_review._THUMB_DIR", thumb_dir)
        from PIL import Image

        img_path = tmp_path / "img.jpg"
        img = Image.new("RGB", (40, 40), color="red")
        img.save(str(img_path), "JPEG")

        result = _make_thumbnail(str(img_path), 20)
        assert result is not None
        assert thumb_dir.exists()

    def test_returns_none_on_pil_exception(self, tmp_path, monkeypatch):
        thumb_dir = tmp_path / "thumbs"
        monkeypatch.setattr("pyimgtag.webapp.routes_review._THUMB_DIR", thumb_dir)
        from PIL import Image

        img_path = tmp_path / "img.jpg"
        img = Image.new("RGB", (40, 40), color="blue")
        img.save(str(img_path), "JPEG")

        with patch("PIL.Image.open", side_effect=Exception("PIL broke")):
            result = _make_thumbnail(str(img_path), 20)
        assert result is None


class TestReviewServerServe:
    def test_serve_invokes_uvicorn_with_unified_app(self, tmp_path, capsys):
        """Happy path: serve() should build the unified app and hand it to uvicorn.run."""
        from unittest.mock import MagicMock, patch

        from pyimgtag.review_server import serve

        with (
            patch("uvicorn.run") as mock_run,
            patch("pyimgtag.webapp.unified_app.create_unified_app") as mock_create,
        ):
            mock_create.return_value = MagicMock(name="fastapi-app")
            serve(db_path=str(tmp_path / "p.db"), host="127.0.0.1", port=9999, open_browser=False)

        mock_create.assert_called_once()
        mock_run.assert_called_once()
        assert mock_run.call_args.kwargs["host"] == "127.0.0.1"
        assert mock_run.call_args.kwargs["port"] == 9999
        out = capsys.readouterr().out
        assert "pyimgtag webapp" in out
        assert "/review" in out

    def test_serve_open_browser_deep_links_to_review(self, tmp_path):
        """With open_browser=True, a thread opens webbrowser pointing at /review."""
        import time
        from unittest.mock import MagicMock, patch

        from pyimgtag.review_server import serve

        opened: list[str] = []

        def fake_open(url, *a, **kw):
            opened.append(url)
            return True

        with (
            patch("uvicorn.run"),
            patch("pyimgtag.webapp.unified_app.create_unified_app", return_value=MagicMock()),
            patch("webbrowser.open", side_effect=fake_open),
        ):
            serve(db_path=str(tmp_path / "p.db"), host="127.0.0.1", port=7777, open_browser=True)
            # Browser opens in a background thread with a 1-second sleep; wait for it.
            deadline = time.monotonic() + 3.0
            while time.monotonic() < deadline and not opened:
                time.sleep(0.1)

        assert opened, "browser was never opened"
        assert opened[0].endswith("/review")
        assert "7777" in opened[0]

    def test_serve_raises_when_uvicorn_missing(self, tmp_path, monkeypatch):
        """Missing uvicorn should surface a helpful ImportError."""
        import builtins

        import pytest

        from pyimgtag.review_server import serve

        real_import = builtins.__import__

        def fake_import(name, *a, **kw):
            if name == "uvicorn":
                raise ImportError("gone")
            return real_import(name, *a, **kw)

        monkeypatch.setattr(builtins, "__import__", fake_import)
        with pytest.raises(ImportError, match="uvicorn is required"):
            serve(db_path=str(tmp_path / "p.db"))
