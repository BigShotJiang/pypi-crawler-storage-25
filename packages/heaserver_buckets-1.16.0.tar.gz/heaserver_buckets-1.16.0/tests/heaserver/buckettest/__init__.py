from heaserver.service import heaobjectsupport
from aiohttp import web, ClientSession
from aiohttp.typedefs import LooseHeaders
from typing import Union, Optional
from collections.abc import Mapping, Sequence, AsyncIterator
from heaobject.root import DesktopObject, DesktopObjectTypeVar
from heaobject.person import Group, GroupView, Person, PersonView, decode_group
from heaobject.group import SUPERADMIN_GROUP
from yarl import URL

_url = 'http://localhost:8080'

async def _mock_type_to_resource_url(request: web.Request, type_or_type_name: Union[str, type[DesktopObject]],
                                     parameters: Optional[Mapping[str, Union[Sequence[Union[int, float, complex, str]], Mapping[str, Union[int, float, complex, str]], tuple[str, Union[int, float, complex, str]], int, float, complex, str]]] = None,
                                     **kwargs: Union[Sequence[Union[int, float, complex, str]], Mapping[str, Union[int, float, complex, str]], tuple[str, Union[int, float, complex, str]], int, float, complex, str]) -> str:
    if type_or_type_name in (Group, Group.get_type_name()):
        return f'{_url}/groups'
    elif type_or_type_name in (GroupView, GroupView.get_type_name()):
        return f'{_url}/groupviews'
    elif type_or_type_name in (PersonView, PersonView.get_type_name()):
        return f'{_url}/peopleviews'
    elif type_or_type_name in (Person, Person.get_type_name()):
        return f'{_url}/people'
    else:
        raise ValueError(f'Unexpected type {type_or_type_name}')
heaobjectsupport.type_to_resource_url = _mock_type_to_resource_url
from heaserver.service import client
async def _mock_get_all(app: web.Application, url: Union[URL, str], type_: type[DesktopObjectTypeVar],
                        query_params: Optional[Mapping[str, str]] = None,
                        headers: LooseHeaders | None = None,
                        client_session: ClientSession | None = None) -> AsyncIterator[DesktopObjectTypeVar]:
    url_str = str(url)
    if url_str.startswith(f'{_url}/groups'):
        group: Group | GroupView = Group()
    elif url_str.startswith(f'{_url}/groupviews'):
        group = GroupView()
    else:
        raise ValueError(f'Unexpected URL {url}')
    group.id = '1'
    group.group = SUPERADMIN_GROUP
    yield group
client.get_all = _mock_get_all

async def _mock_get(app: web.Application, url: Union[URL, str],
              type_or_obj: DesktopObjectTypeVar | type[DesktopObjectTypeVar],
              query_params: Optional[Mapping[str, str]] = None,
              headers: LooseHeaders | None = None,
              client_session: ClientSession | None = None) -> DesktopObjectTypeVar | None:
    return None
client.get = _mock_get
