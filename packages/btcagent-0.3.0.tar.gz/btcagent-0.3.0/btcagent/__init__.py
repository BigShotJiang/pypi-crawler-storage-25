import logging

import numpy as np
import numba
import yfinance as yf
import pandas as pd

from . import binance_robot
from . import sentiment_analysis

logger = logging.getLogger(__name__)


@numba.jit(nopython=True, parallel=True)
def get_freq(v, window_size, sell_window_size, nbins=100):
    """Build a frequency map of sequential price movement patterns.

    Scans overlapping triplets (i, j, k) of prices within the given windows
    and accumulates the discretised relative price changes into a 2-D
    histogram.

    Parameters
    ----------
    v : numpy.ndarray
        1-D array of historical prices.
    window_size : int
        Number of recent prices to consider as starting points.
    sell_window_size : int
        Maximum forward look-ahead from each starting point.
    nbins : int, optional
        Number of bins per side for discretising relative price changes.
        Default is 100.

    Returns
    -------
    list[numpy.ndarray]
        A 2-D list of arrays representing the frequency map, indexed by
        ``[nbins + diff_buy][nbins + diff_sell]``.
    """
    L = len(v)
    map_freq = [np.zeros(4 * nbins + 2) for i in range(4 * nbins + 2)]
    for i in numba.prange(max([0, L - window_size]), L):
        if i % 500 == 0:
            print(i)
        for j in range(i + 1, min([i + sell_window_size, L])):
            diff = v[j] - v[i]
            diff_pj = int(nbins * diff / v[i])
            for k in range(j + 1, min([i + sell_window_size, L])):
                diff_pk = int(nbins * (v[k] - v[j]) / v[j])
                map_freq[nbins + diff_pj][nbins + diff_pk] += 1
    return map_freq


@numba.jit(nopython=True, parallel=False)
def compute_expected_return(map_freq, target, ref_freq1, ref_freq2, nbins=100):
    """Compute expected return and loss from a frequency map.

    Iterates over the frequency map produced by :func:`get_freq` and
    partitions outcomes into those that meet the *target* return and those
    that fall below.

    Parameters
    ----------
    map_freq : list[numpy.ndarray]
        Frequency map produced by :func:`get_freq`.
    target : int
        Minimum bin index to consider a successful outcome.
    ref_freq1 : int
        Lower bound (inclusive) of the reference frequency range to scan.
    ref_freq2 : int
        Upper bound (inclusive) of the reference frequency range to scan.
    nbins : int, optional
        Bin count matching the one used in :func:`get_freq`. Default is 100.

    Returns
    -------
    tuple[float, float, float]
        ``(prob_target, expected_loss, expected_return)`` where
        *prob_target* is a percentage probability of meeting the target.
    """
    expected_return = 0
    expected_loss = 0
    expected_acc = 0
    expected_loss_acc = 0

    freq_target = 0
    freq_below = 0
    for selected_freqi in range(len(map_freq)):
        selected_freq = selected_freqi - nbins
        if selected_freq < ref_freq1:
            continue
        if selected_freq > ref_freq2:
            continue
        for ki in range(len(map_freq[nbins + selected_freq])):
            k = ki - nbins
            prob = map_freq[nbins + selected_freq][k + nbins]
            if k >= target:
                freq_target += prob
                expected_return += k * prob
                expected_acc += prob
            else:
                freq_below += prob
                expected_loss += k * prob
                expected_loss_acc += prob
    expected_return /= expected_acc
    expected_loss /= expected_loss_acc
    freq_total = freq_target + freq_below
    prob_target = 100 * freq_target / freq_total
    return prob_target, expected_loss * 100 / nbins, expected_return * 100 / nbins


@numba.jit(nopython=True, parallel=False)
def bitcoin_agent(prices, wc, wv, epsc, epsv, USDTo, BTCo):
    """Simulate a moving-average crossover trading agent on price data.

    The agent buys when the current price drops below
    ``(1 - epsc) * mean(prices[t-wc:t])`` and sells when it rises above
    ``(1 + epsv) * mean(prices[t-wv:t])``.

    Parameters
    ----------
    prices : numpy.ndarray
        1-D array of chronological prices.
    wc : int
        Buy window size (look-back period for the buy signal).
    wv : int
        Sell window size (look-back period for the sell signal).
    epsc : float
        Buy threshold — fraction below the moving average that triggers a buy.
    epsv : float
        Sell threshold — fraction above the moving average that triggers a sell.
    USDTo : float
        Initial USDT balance.
    BTCo : float
        Initial BTC balance.

    Returns
    -------
    list[float]
        ``[wallet_value, BTC_balance, USDT_balance]`` at the end of the
        simulation.
    """
    USDT = USDTo
    BTC = BTCo
    Tc = 0
    Tv = 0
    N = len(prices)
    mean_pricec = np.mean(prices[0:wc])
    mean_pricev = np.mean(prices[0:wv])
    Pc = (1 - epsc) * mean_pricec
    Pv = (1 + epsv) * mean_pricev
    for t_global in range(max(wc, wv), N):
        current_price = prices[t_global]
        mean_pricec = np.mean(prices[t_global - wc : t_global])
        mean_pricev = np.mean(prices[t_global - wv : t_global])
        if t_global >= Tc + wc:
            Pc = (1 - epsc) * mean_pricec
        if t_global >= Tv + wv:
            Pv = (1 + epsv) * mean_pricev

        if USDT > 0:
            if current_price <= Pc:
                BTC += USDT / current_price
                USDT = 0
                Tc = t_global
        if BTC > 0:
            if current_price >= Pv:
                USDT += BTC * current_price
                BTC = 0
                Tv = t_global
    return [max([BTC * current_price, USDT]), BTC, USDT]


@numba.jit(nopython=True, parallel=True)
def optimize_agent(
    prices,
    USDTo,
    BTCo,
    range_wc=[int(1), int(500)],
    range_wv=[int(1), int(500)],
    range_epsc=[float(0), float(0.1)],
    range_epsv=[float(0.0), float(0.3)],
    n_scenarios=100,
):
    """Monte Carlo optimisation of trading agent parameters.

    Randomly samples ``n_scenarios`` combinations of ``(wc, wv, epsc, epsv)``
    from the specified ranges and evaluates each using
    :func:`bitcoin_agent`.  Returns the best, worst and mean results.

    Parameters
    ----------
    prices : numpy.ndarray
        1-D array of chronological prices.
    USDTo : float
        Initial USDT balance for each simulation.
    BTCo : float
        Initial BTC balance for each simulation.
    range_wc : list[int]
        ``[min, max)`` range for the buy window size.
    range_wv : list[int]
        ``[min, max)`` range for the sell window size.
    range_epsc : list[float]
        ``[min, max)`` range for the buy threshold.
    range_epsv : list[float]
        ``[min, max)`` range for the sell threshold.
    n_scenarios : int
        Number of random parameter combinations to evaluate.

    Returns
    -------
    list[float]
        ``[max_wallet, max_wc, max_wv, max_epsc, max_epsv,
        mean_wallet, min_wallet, min_wc, min_wv, min_epsc, min_epsv]``.
    """
    max_wallet_value = -1e30
    max_wc = 0
    max_wv = 0
    max_epsc = 0.0
    max_epsv = 0.0

    scenarios = []
    for i in range(n_scenarios):
        wc = np.random.randint(range_wc[0], range_wc[1])
        wv = np.random.randint(range_wv[0], range_wv[1])
        epsc = np.random.uniform(range_epsc[0], range_epsc[1])
        epsv = np.random.uniform(range_epsv[0], range_epsv[1])
        scenarios.append([wc, wv, epsc, epsv])

    results = np.zeros(n_scenarios, dtype=float)

    for i in numba.prange(n_scenarios):
        wc, wv, epsc, epsv = scenarios[i]
        wallet_value, BTC, USDT = bitcoin_agent(
            prices=prices, wc=wc, wv=wv, epsc=epsc, epsv=epsv, USDTo=USDTo, BTCo=BTCo
        )
        results[i] = wallet_value

    mean_wallet_value = 0
    min_wallet_value = 1e20
    min_wc = 0
    min_wv = 0
    min_epsc = 0
    min_epsv = 0

    for i, scenario in enumerate(scenarios):
        wc, wv, epsc, epsv = scenario
        wallet_value = results[i]
        mean_wallet_value += wallet_value / len(scenarios)
        if wallet_value > max_wallet_value:
            max_wallet_value = wallet_value
            max_wc = wc
            max_wv = wv
            max_epsc = epsc
            max_epsv = epsv
            print(
                "wallet_value: ",
                max_wallet_value,
                " wc: ",
                max_wc,
                " wv: ",
                max_wv,
                " epsc: ",
                max_epsc,
                " epsv: ",
                max_epsv,
            )
        if wallet_value < min_wallet_value:
            min_wallet_value = wallet_value
            min_wc = wc
            min_wv = wv
            min_epsc = epsc
            min_epsv = epsv

    print("mean_wallet_value: ", mean_wallet_value)
    print(
        "min wallet_value: ",
        min_wallet_value,
        " wc: ",
        min_wc,
        " wv: ",
        min_wv,
        " epsc: ",
        min_epsc,
        " epsv: ",
        min_epsv,
    )
    return [
        max_wallet_value,
        max_wc,
        max_wv,
        max_epsc,
        max_epsv,
        mean_wallet_value,
        min_wallet_value,
        min_wc,
        min_wv,
        min_epsc,
        min_epsv,
    ]


def get_target_prices(prices, wc, wv, epsc, epsv):
    """Compute buy and sell target prices from agent parameters.

    Uses the last ``wc`` / ``wv`` prices to calculate moving averages, then
    applies the ``epsc`` / ``epsv`` offsets.

    Parameters
    ----------
    prices : numpy.ndarray
        1-D array of chronological prices.
    wc : int
        Buy window size.
    wv : int
        Sell window size.
    epsc : float
        Buy threshold (fraction below the mean).
    epsv : float
        Sell threshold (fraction above the mean).

    Returns
    -------
    tuple[float, float]
        ``(buy_price, sell_price)``.
    """
    mean_pricec = np.mean(prices[len(prices) - int(wc) : len(prices)])
    mean_pricev = np.mean(prices[len(prices) - int(wv) : len(prices)])
    buy_price = mean_pricec * (1 - epsc)
    sell_price = mean_pricev * (1 + epsv)
    return buy_price, sell_price


def get_token(symbol):
    """Map a trading pair symbol to its base token name.

    Parameters
    ----------
    symbol : str
        Trading pair symbol (e.g. ``"BTCUSDT"``, ``"ETHUSDT"``).

    Returns
    -------
    str or None
        Base token name (e.g. ``"BTC"``, ``"ETH"``), or *None* if the
        symbol is not recognised.
    """
    if symbol == "BTCUSDT":
        return "BTC"
    if symbol == "ETHUSDT":
        return "ETH"
    if symbol == "BTC-USD":
        return "BTC"


def get_prices_using_yfinance(start_date, end_date, ticker="BTC-USD"):
    """Fetch minute-level historical prices from Yahoo Finance.

    Parameters
    ----------
    start_date : str
        Start date in ``"YYYY-MM-DD"`` format.
    end_date : str
        End date in ``"YYYY-MM-DD"`` format.
    ticker : str, optional
        Yahoo Finance ticker symbol. Default is ``"BTC-USD"``.

    Returns
    -------
    numpy.ndarray
        1-D array of open prices at 1-minute intervals.
    """
    import yfinance as yf
    import pandas as pd
    import numpy as np

    data = yf.Ticker(ticker)
    minute_data = data.history(start=start_date, end=end_date, interval="1m")
    return np.array(minute_data).T[0]


def get_prices_using_binance(api_key, api_secret, symbol="BTCUSDT", N=1000):
    """Fetch the last *N* one-minute candle close prices from Binance.

    Parameters
    ----------
    api_key : str
        Binance API key.
    api_secret : str
        Binance API secret.
    symbol : str, optional
        Trading pair symbol. Default is ``"BTCUSDT"``.
    N : int, optional
        Number of candles to fetch. Default is 1000.

    Returns
    -------
    numpy.ndarray
        1-D float array of close prices.
    """
    import requests
    import pandas as pd
    import numpy as np

    def fetch_historical_data(symbol, interval, limit):
        url = "https://api.binance.com/api/v3/klines"
        params = {"symbol": symbol, "interval": interval, "limit": limit}
        headers = {"X-MBX-APIKEY": api_key}
        response = requests.get(url, params=params, headers=headers)
        data = response.json()
        return data

    # Obter os últimos 500 preços cotados a cada minuto
    data = fetch_historical_data(symbol, "1m", N)
    # data = {k: [v] for k, v in data.items()}  # WORKAROUND

    # Converter os dados para um DataFrame do pandas
    df = pd.DataFrame(data)
    df.columns = [
        "Open time",
        "Open",
        "High",
        "Low",
        "Close",
        "Volume",
        "Close time",
        "Quote asset volume",
        "Number of trades",
        "Taker buy base asset volume",
        "Taker buy quote asset volume",
        "Ignore",
    ]

    # Exibir o DataFrame
    return np.array(df["Close"], dtype=float)


def get_account_balance_using_binance(api_key, api_secret, token="BTC", full=False):
    """Retrieve account balances from Binance.

    Parameters
    ----------
    api_key : str
        Binance API key.
    api_secret : str
        Binance API secret.
    token : str, optional
        Base token to query. Default is ``"BTC"``.
    full : bool, optional
        If *True*, include balances locked in open orders. Default is
        *False*.

    Returns
    -------
    tuple[float, float]
        ``(usdt_balance, token_balance)``.
    """
    import binance

    binance.set(api_key, api_secret)
    b = binance.balances()
    
    usdt = float(b["USDT"]["free"])
    token_balance = float(b[token]["free"])
    
    if full:
        orders = binance.openOrders(symbol=f"{token}USDT")
        
        for order in orders:
            price = float(order["price"])
            if order["side"] == "BUY":
                usdt += float(order["origQty"]) * price
            if order["side"] == "SELL":
                token_balance += float(order["origQty"])
    return usdt, token_balance


def get_current_price_using_binance(api_key, api_secret, symbol="BTCUSDT"):
    """Return the current spot price for a symbol on Binance.

    Parameters
    ----------
    api_key : str
        Binance API key.
    api_secret : str
        Binance API secret.
    symbol : str, optional
        Trading pair symbol. Default is ``"BTCUSDT"``.

    Returns
    -------
    str
        Current price as a string (as returned by the Binance API).
    """
    import binance

    binance.set(api_key, api_secret)
    return binance.prices()[symbol]


def get_recommendation(
    prices,
    USDTo,
    BTCo,
    threshold=1,
    range_wc=[1, 300],
    range_wv=[1, 300],
    range_epsc=[0.002, 0.04],
    range_epsv=[0.002, 0.04],
    n_scenarios=5_000_000,
):
    """Optimise the trading agent and return buy/sell recommendations.

    Runs :func:`optimize_agent` and derives target prices from the best
    parameters.  A quality *score* (0–9) is computed based on how the
    best and mean simulated wallet values compare to *threshold*.

    Parameters
    ----------
    prices : numpy.ndarray
        1-D array of historical prices.
    USDTo : float
        Initial USDT balance for simulations.
    BTCo : float
        Initial BTC balance for simulations.
    threshold : float, optional
        Minimum return percentage for a recommendation to be considered
        useful. Default is 1.
    range_wc : list[int], optional
        Buy window range. Default is ``[1, 300]``.
    range_wv : list[int], optional
        Sell window range. Default is ``[1, 300]``.
    range_epsc : list[float], optional
        Buy threshold range. Default is ``[0.002, 0.04]``.
    range_epsv : list[float], optional
        Sell threshold range. Default is ``[0.002, 0.04]``.
    n_scenarios : int, optional
        Number of Monte Carlo scenarios. Default is 5 000 000.

    Returns
    -------
    dict
        ``{"score", "buy_price", "sell_price", "max_wallet",
        "mean_wallet", "min_wallet"}``.
    """
    result = optimize_agent(
        prices=prices,
        USDTo=USDTo,
        BTCo=BTCo,
        range_wc=range_wc,
        range_wv=range_wv,
        range_epsc=range_epsc,
        range_epsv=range_epsv,
        n_scenarios=n_scenarios,
    )
    max_wallet = result[0]
    wc = result[1]
    wv = result[2]
    epsc = result[3]
    epsv = result[4]
    mean_wallet = result[5]
    min_wallet = result[6]
    min_wc = result[7]
    min_wv = result[8]
    min_epsc = result[9]
    min_epsv = result[10]

    score = 0
    if max_wallet - 100 < threshold:
        logger.warning("Max wallet value below threshold (%.1f%%). Recommendation quality: LOW", threshold)
        score += 0
    elif max_wallet - 100 > 2 * threshold:
        logger.info("Max wallet value above 2x threshold (%.1f%%). Recommendation quality: HIGH", 2 * threshold)
        score += 3
    else:
        logger.info("Recommendation quality: MEDIUM")
        score += 1

    if mean_wallet - 100 < threshold:
        logger.warning("Mean wallet value below threshold (%.1f%%). Recommendation quality: LOW", threshold)
        score += 0
    elif mean_wallet - 100 > 2 * threshold:
        logger.info("Mean wallet value above 2x threshold (%.1f%%). Recommendation quality: HIGH", 2 * threshold)
        score += 6
    else:
        logger.info("Recommendation quality: MEDIUM")
        score += 2

    logger.info("Optimization result: max_wallet=%.2f wc=%d wv=%d epsc=%.4f epsv=%.4f",
                max_wallet, wc, wv, epsc, epsv)
    logger.info("Optimization result: min_wallet=%.2f wc=%d wv=%d epsc=%.4f epsv=%.4f",
                min_wallet, min_wc, min_wv, min_epsc, min_epsv)
    logger.info("Optimization result: mean_wallet=%.2f", mean_wallet)
    buy_priceb, sell_priceb = get_target_prices(prices, wc, wv, epsc, epsv)
    return dict(
        score=score,
        buy_price=buy_priceb,
        sell_price=sell_priceb,
        max_wallet=max_wallet,
        mean_wallet=mean_wallet,
        min_wallet=min_wallet,
    )


def create_orders(
    buy_price,
    sell_price,
    symbol,
    api_key,
    api_secret,
    min_usdt=1,
    min_btc=0.0001,
    buyer=lambda buy_quantity, buy_price, symbol, api_key, api_secret: binance_robot.create_buy_order(
        buy_quantity, buy_price, symbol, api_key, api_secret
    ),
    seller=lambda sell_quantity, sell_price, symbol, api_key, api_secret: binance_robot.create_sell_order(
        sell_quantity, sell_price, symbol, api_key, api_secret
    ),
    get_account_balance=lambda api_key, api_secret, token: get_account_balance_using_binance(
        api_key, api_secret, token
    ),
    max_size_buy=0.95,
    max_size_sell=0.95,
):
    """Create buy and sell limit orders on Binance.

    Checks the current account balance and places a sell order if the token
    balance exceeds *min_btc*, and a buy order if the USDT balance exceeds
    *min_usdt*.

    Parameters
    ----------
    buy_price : float
        Limit price for the buy order.
    sell_price : float
        Limit price for the sell order.
    symbol : str
        Trading pair symbol (e.g. ``"BTCUSDT"``).
    api_key : str
        Binance API key.
    api_secret : str
        Binance API secret.
    min_usdt : float, optional
        Minimum USDT balance required to place a buy order. Default is 1.
    min_btc : float, optional
        Minimum token balance required to place a sell order. Default is
        0.0001.
    buyer : callable, optional
        Function to execute buy orders.
    seller : callable, optional
        Function to execute sell orders.
    get_account_balance : callable, optional
        Function to retrieve account balances.
    max_size_buy : float, optional
        Fraction of the token balance to sell. Default is 0.95.
    max_size_sell : float, optional
        Fraction of the USDT balance to use for buying. Default is 0.95.

    Returns
    -------
    list[dict]
        List of order responses from the Binance API.
    """
    usdt_balance, token_balance = get_account_balance(
        api_key=api_key, api_secret=api_secret, token=get_token(symbol)
    )

    # Verificar se deve vender

    orders = []
    if float(token_balance) >= min_btc:
        # Calcular a quantidade de BTC a ser vendida
        sell_quantity = float(token_balance) * max_size_buy
        orders.append(seller(sell_quantity, sell_price, symbol, api_key, api_secret))

    # Verificar se deve comprar
    if float(usdt_balance) >= min_usdt:
        # Calcular a quantidade de USDT a ser utilizada na compra
        buy_quantity = float(usdt_balance) * max_size_sell / buy_price
        orders.append(buyer(buy_quantity, buy_price, symbol, api_key, api_secret))
    return orders
