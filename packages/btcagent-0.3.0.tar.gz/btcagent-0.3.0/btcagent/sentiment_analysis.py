import json
import logging
import os

from google import genai
import anthropic
import openai


logger = logging.getLogger(__name__)


JSON_REPORT_TEMPLATE = """
{{
    "minimum price": 30000,
    "minimum price probability": 0.3,
    "maximum price": 40000,
    "maximum price probability": 0.5,
    "reasoning": "The news about X and Y indicate a positive sentiment, but the news about Z indicates a negative sentiment. Overall, the sentiment is positive, but with some uncertainty.",
    "sentiment": 1
}}
"""

DEFAULT_PROMPT_TEMPLATE = """
Search the internet for the latest news and market data (window of 7 days) that affects {token} price.

Based on your research, do a sentiment analysis and estimate a target price for the next two days.

Consider factors such as:
- Recent price action and trading volume
- Regulatory news and government policy changes
- Major partnerships, adoptions, or technological developments
- Macroeconomic indicators and their impact on crypto markets
- Social media and community sentiment trends

The output format is a json with the fields:

* minimum price
* minimum price probability
* maximum price
* maximum price probability
* reasoning (include specific news sources and events you found)
* sentiment (a value between -1 (minimum negative sentiment) and 1 (maximum positive sentiment))

Return only the json. It's mandatory to follow the output format, otherwise the result will be discarded.

Here is an example of the expected output format:
""" + JSON_REPORT_TEMPLATE


DEFAULT_CONFIG = {
    "gemini": {
        "model": "gemini-3.1-flash-lite-preview",
    },
    "claude": {
        "model": "claude-sonnet-4-6",
    },
    "chatgpt": {
        "model": "gpt-5.4-mini",
    },
    "weights": {
        "gemini": 0.4,
        "claude": 0.35,
        "chatgpt": 0.25,
    },
}


import re


def _parse_json_response(text):
    """Extract a JSON object from a model response.

    Strips markdown code fences if present and attempts direct parsing.
    Falls back to regex extraction of an embedded JSON object.

    Parameters
    ----------
    text : str
        Raw model response text.

    Returns
    -------
    dict
        Parsed JSON object.

    Raises
    ------
    ValueError
        If no valid JSON object can be found in *text*.
    """
    text = text.strip()
    if text.startswith("```"):
        lines = text.splitlines()
        # Remove first and last lines (fences)
        lines = [l for l in lines if not l.strip().startswith("```")]
        text = "\n".join(lines)
    # Try direct parse first
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        pass
    # Try to find a JSON object embedded in the text
    match = re.search(r'\{[^{}]*(?:\{[^{}]*\}[^{}]*)*\}', text, re.DOTALL)
    if match:
        return json.loads(match.group())
    raise ValueError(f"No JSON object found in response: {text[:200]}")


def _validate_sentiment_result(result):
    """Validate that a parsed sentiment result contains all required fields.

    Parameters
    ----------
    result : dict
        Parsed JSON result from a model response.

    Returns
    -------
    dict
        The same *result* dict, unmodified.

    Raises
    ------
    ValueError
        If any required field is missing.
    """
    required = [
        "minimum price",
        "minimum price probability",
        "maximum price",
        "maximum price probability",
        "reasoning",
        "sentiment",
    ]
    for field in required:
        if field not in result:
            raise ValueError(f"Missing required field: {field} Full result: {result}")
    return result


def get_sentiment_analysis(token, config=None, prompt_template=None):
    """Run sentiment analysis using Google Gemini.

    Parameters
    ----------
    token : str
        The token/coin symbol to analyse (e.g. "BTC", "ETH").
    config : dict, optional
        Configuration dict. Uses ``DEFAULT_CONFIG`` when *None*.
        The ``config["gemini"]["model"]`` key controls which Gemini model is
        used.  The Gemini API key is read from the ``GOOGLE_API_KEY``
        environment variable.
    prompt_template : str, optional
        Custom prompt template. Must contain ``{token}`` placeholder.

    Returns
    -------
    dict
        A dict with the sentiment fields plus a ``status`` boolean indicating
        whether the analysis succeeded.
    """
    if config is None:
        config = DEFAULT_CONFIG
    if prompt_template is None:
        prompt_template = DEFAULT_PROMPT_TEMPLATE

    model_name = config.get("gemini", {}).get("model", "gemini-pro")
    prompt = prompt_template.format(token=token)

    try:
        api_key = os.environ.get("GOOGLE_API_KEY")
        if not api_key:
            return {"status": False, "error": "GOOGLE_API_KEY not set"}

        client = genai.Client(api_key=api_key)
        google_search_tool = genai.types.Tool(
            google_search=genai.types.GoogleSearch()
        )
        response = client.models.generate_content(
            model=model_name,
            contents=prompt,
            config=genai.types.GenerateContentConfig(
                tools=[google_search_tool],
            ),
        )

        result = _parse_json_response(response.text)
        result = _validate_sentiment_result(result)
        result["status"] = True
        result["model"] = model_name
        return result
    except Exception as e:
        return {"status": False, "error": str(e)}


def _get_sentiment_claude(token, config, prompt):
    """Run sentiment analysis using Anthropic Claude with web search.

    Parameters
    ----------
    token : str
        Token/coin symbol (e.g. ``"BTC"``).
    config : dict
        Configuration dict with ``config["claude"]["model"]``.
    prompt : str
        Pre-formatted prompt string.

    Returns
    -------
    dict or None
        Parsed sentiment result with a ``"model"`` key, or *None* on
        failure.
    """
    model_name = config.get("claude", {}).get("model", "claude-sonnet-4-6")
    try:
        api_key = os.environ.get("ANTHROPIC_API_KEY")
        if not api_key:
            return None

        client = anthropic.Anthropic(api_key=api_key)
        message = client.messages.create(
            model=model_name,
            max_tokens=4096,
            tools=[{"type": "web_search_20250305", "name": "web_search", "max_uses": 5}],
            messages=[{"role": "user", "content": prompt}],
        )
        # Extract text from response blocks (web search adds non-text blocks)
        text_parts = [
            block.text for block in message.content
            if hasattr(block, "text") and block.type == "text"
        ]
        if not text_parts:
            raise ValueError(
                f"No text blocks in Claude response. "
                f"Block types: {[b.type for b in message.content]}"
            )
        # Use the last text block (final answer after search)
        text = text_parts[-1]
        result = _parse_json_response(text)
        result = _validate_sentiment_result(result)
        result["model"] = model_name
        return result
    except Exception as e:
        logger.error("Claude sentiment analysis failed: %s", e)
        return None


def _get_sentiment_chatgpt(token, config, prompt):
    """Run sentiment analysis using OpenAI ChatGPT with web search.

    Parameters
    ----------
    token : str
        Token/coin symbol (e.g. ``"BTC"``).
    config : dict
        Configuration dict with ``config["chatgpt"]["model"]``.
    prompt : str
        Pre-formatted prompt string.

    Returns
    -------
    dict or None
        Parsed sentiment result with a ``"model"`` key, or *None* on
        failure.
    """
    model_name = config.get("chatgpt", {}).get("model", "gpt-5.4-nano")
    try:
        api_key = os.environ.get("OPENAI_API_KEY")
        if not api_key:
            return None

        client = openai.OpenAI(api_key=api_key)
        response = client.responses.create(
            model=model_name,
            tools=[{"type": "web_search_preview"}],
            input=prompt,
        )
        # Extract text from Responses API output items
        text = ""
        for item in response.output:
            if item.type == "message":
                for content in item.content:
                    if content.type == "output_text":
                        text += content.text
        result = _parse_json_response(text)
        result = _validate_sentiment_result(result)
        result["model"] = model_name
        return result
    except Exception as e:
        logger.error("ChatGPT sentiment analysis failed: %s", e)
        return None


def _get_sentiment_gemini(token, config, prompt):
    """Run sentiment analysis using Google Gemini with web search.

    Parameters
    ----------
    token : str
        Token/coin symbol (e.g. ``"BTC"``).
    config : dict
        Configuration dict with ``config["gemini"]["model"]``.
    prompt : str
        Pre-formatted prompt string.

    Returns
    -------
    dict or None
        Parsed sentiment result with a ``"model"`` key, or *None* on
        failure.
    """
    model_name = config.get("gemini", {}).get("model", "gemini-pro")
    try:
        api_key = os.environ.get("GOOGLE_API_KEY")
        if not api_key:
            return None

        client = genai.Client(api_key=api_key)
        google_search_tool = genai.types.Tool(
            google_search=genai.types.GoogleSearch()
        )
        response = client.models.generate_content(
            model=model_name,
            contents=prompt,
            config=genai.types.GenerateContentConfig(
                tools=[google_search_tool],
            ),
        )
        result = _parse_json_response(response.text)
        result = _validate_sentiment_result(result)
        result["model"] = model_name
        return result
    except Exception as e:
        logger.error("Gemini sentiment analysis failed: %s", e)
        return None


def get_sentiment(token, config=None, prompt_template=None):
    """Compute a weighted-average sentiment using Claude, ChatGPT and Gemini.

    Each model receives the same prompt. The ``minimum price`` and
    ``maximum price`` from each successful response are combined via a
    weighted average (weights defined in ``config["weights"]``).

    Parameters
    ----------
    token : str
        Token symbol.
    config : dict, optional
        Configuration dict (see ``DEFAULT_CONFIG``).
    prompt_template : str, optional
        Custom prompt template with a ``{token}`` placeholder.

    Returns
    -------
    dict
        Combined result with weighted ``minimum price`` and
        ``maximum price``, individual model results, and a ``status`` flag.
    """
    if config is None:
        config = DEFAULT_CONFIG
    if prompt_template is None:
        prompt_template = DEFAULT_PROMPT_TEMPLATE

    prompt = prompt_template.format(token=token)
    weights = config.get("weights", DEFAULT_CONFIG["weights"])

    providers = {
        "gemini": _get_sentiment_gemini,
        "claude": _get_sentiment_claude,
        "chatgpt": _get_sentiment_chatgpt,
    }

    results = {}
    for name, fn in providers.items():
        result = fn(token, config, prompt)
        if result is not None:
            results[name] = result

    if not results:
        return {"status": False, "error": "All models failed"}

    # Compute weighted averages for prices and sentiment
    total_weight = 0.0
    weighted_min = 0.0
    weighted_max = 0.0
    weighted_sentiment = 0.0

    for name, result in results.items():
        w = weights.get(name, 0.0)
        total_weight += w
        weighted_min += w * float(result["minimum price"])
        weighted_max += w * float(result["maximum price"])
        weighted_sentiment += w * float(result["sentiment"])

    avg_min = weighted_min / total_weight
    avg_max = weighted_max / total_weight
    combined_sentiment = weighted_sentiment / total_weight

    # Summarize individual reasonings using Gemini
    combined_reasoning = _summarize_reasoning(token, config, results)

    return {
        "status": True,
        "minimum price": avg_min,
        "maximum price": avg_max,
        "sentiment": combined_sentiment,
        "reasoning": combined_reasoning,
        "models_used": list(results.keys()),
        "individual_results": results,
    }


def _summarize_reasoning(token, config, results):
    """Summarise individual model reasonings into a single paragraph.

    Uses Gemini to produce a coherent summary highlighting points of
    agreement and disagreement.

    Parameters
    ----------
    token : str
        Token/coin symbol.
    config : dict
        Configuration dict with ``config["gemini"]["model"]``.
    results : dict[str, dict]
        Mapping of provider names to their sentiment result dicts.

    Returns
    -------
    str
        Summary text, or the raw concatenated reasonings if Gemini is
        unavailable.
    """
    model_name = config.get("gemini", {}).get("model", "gemini-pro")
    summaries = []
    for name, result in results.items():
        summaries.append(f"### {name} ({result.get('model', 'unknown')})\n{result.get('reasoning', 'N/A')}")
    combined_text = "\n\n".join(summaries)

    summary_prompt = (
        f"The following are sentiment analysis results for {token} from multiple AI models. "
        f"Summarize the key findings into a single coherent reasoning paragraph, "
        f"highlighting points of agreement and disagreement between models.\n\n"
        f"{combined_text}\n\n"
        f"Return only the summary text, no JSON or formatting."
    )

    try:
        api_key = os.environ.get("GOOGLE_API_KEY")
        if not api_key:
            return combined_text

        client = genai.Client(api_key=api_key)
        response = client.models.generate_content(
            model=model_name, contents=summary_prompt
        )
        return response.text.strip()
    except Exception as e:
        logger.error("Failed to summarize reasoning with Gemini: %s", e)
        return combined_text
