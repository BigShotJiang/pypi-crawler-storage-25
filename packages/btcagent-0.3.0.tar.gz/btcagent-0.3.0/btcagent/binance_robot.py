import logging
import requests
import hmac
import hashlib
import time
import json
import numpy as np


logger = logging.getLogger(__name__)

btc_symbol = "BTCUSDT"


# Funções auxiliares para criar as requisições à API
def cancel_order(order, symbol, api_key, api_secret):
    """Cancel an open order on Binance.

    Parameters
    ----------
    order : dict
        Order dict containing at least an ``"orderId"`` key.
    symbol : str
        Trading pair symbol (e.g. ``"BTCUSDT"``).
    api_key : str
        Binance API key.
    api_secret : str
        Binance API secret.

    Returns
    -------
    dict
        Binance API cancellation response.
    """
    # Cancela uma ordem
    logger.info("Cancelling order %s", order.get("orderId", order))

    # Endpoint da API para cancelar uma ordem
    import binance

    binance.set(api_key, api_secret)

    return binance.cancel(symbol=symbol, orderId=order["orderId"])


def create_buy_order(quantity, buy_price, symbol, api_key, api_secret):
    """Place a limit buy order on Binance.

    Quantities are truncated to 5 decimal places and prices to 2 decimal
    places before submission.

    Parameters
    ----------
    quantity : float
        Amount of the base asset to buy.
    buy_price : float
        Limit price in quote asset.
    symbol : str
        Trading pair symbol (e.g. ``"BTCUSDT"``).
    api_key : str
        Binance API key.
    api_secret : str
        Binance API secret.

    Returns
    -------
    dict
        Binance API order response.
    """
    quantity = int(quantity / 0.00001) * 0.00001
    buy_price = int(buy_price / 0.01) * 0.01
    # Compre a mercado
    logger.info("Placing BUY order: quantity=%.5f price=%.2f symbol=%s", quantity, buy_price, symbol)
    import binance

    binance.set(api_key, api_secret)
    # Retornando a resposta da API
    return binance.order(
        symbol=symbol,
        side="BUY",
        quantity=quantity,
        price=buy_price,
    )


def create_sell_order(quantity, sell_price, symbol, api_key, api_secret):
    """Place a limit sell order on Binance.

    Quantities are truncated to 5 decimal places and prices to 2 decimal
    places before submission.

    Parameters
    ----------
    quantity : float
        Amount of the base asset to sell.
    sell_price : float
        Limit price in quote asset.
    symbol : str
        Trading pair symbol (e.g. ``"BTCUSDT"``).
    api_key : str
        Binance API key.
    api_secret : str
        Binance API secret.

    Returns
    -------
    dict
        Binance API order response.
    """
    quantity = int(quantity / 0.00001) * 0.00001
    sell_price = int(sell_price / 0.01) * 0.01

    # Venda a mercado
    logger.info("Placing SELL order: quantity=%.5f price=%.2f symbol=%s", quantity, sell_price, symbol)
    # Endpoint da API para criar uma nova ordem
    import binance

    binance.set(api_key, api_secret)
    # Retornando a resposta da API
    return binance.order(
        symbol=symbol,
        side="SELL",
        quantity=quantity,
        price=sell_price,
    )


import requests
import json


def get_binance_depth(symbol="BTCUSDT", limit=100):
    """Fetch the order book depth for a symbol from the Binance public API.

    Parameters
    ----------
    symbol : str, optional
        Trading pair symbol. Default is ``"BTCUSDT"``.
    limit : int, optional
        Number of price levels to retrieve (max 5000). Default is 100.

    Returns
    -------
    dict or None
        Order book with ``"bids"`` and ``"asks"`` lists, or *None* on
        failure.
    """
    url = f"https://api.binance.com/api/v3/depth?symbol={symbol}&limit={limit}"
    response = requests.get(url)
    if response.status_code == 200:
        depth = response.json()
        return depth
    else:
        logger.error("Failed to fetch Binance depth for %s: HTTP %d", symbol, response.status_code)
        return None


def compute_target_buy_sell_prices(buy_margin=0.02, sell_margin=0.02, symbol="BTCUSDT", limit=5000):
    """Compute target buy and sell prices from the order book depth.

    Fetches the order book, computes quantity-weighted average prices for
    bids and asks, and applies the specified margins to derive target
    trading prices.

    The sell target is the weighted-average bid price scaled up by
    ``(1 + sell_margin)`` (selling above where buyers cluster). The buy
    target is the weighted-average ask price scaled down by
    ``(1 - buy_margin)`` (buying below where sellers cluster).

    Parameters
    ----------
    buy_margin : float, optional
        Fraction to discount the weighted-average ask price for the buy
        target. Default is ``0.02`` (2 %).
    sell_margin : float, optional
        Fraction to mark up the weighted-average bid price for the sell
        target. Default is ``0.02`` (2 %).
    symbol : str, optional
        Trading pair symbol. Default is ``"BTCUSDT"``.
    limit : int, optional
        Number of order-book levels to fetch (max 5000). Default is 5000.

    Returns
    -------
    dict or None
        A dictionary with the following keys, or *None* if the order book
        could not be fetched:

        - ``"buy_price"``  – target buy price (float)
        - ``"sell_price"`` – target sell price (float)
        - ``"weighted_avg_bid"`` – quantity-weighted average bid (float)
        - ``"weighted_avg_ask"`` – quantity-weighted average ask (float)
        - ``"best_bid"`` – highest bid price (float)
        - ``"best_ask"`` – lowest ask price (float)
        - ``"spread"`` – best ask minus best bid (float)
        - ``"total_bid_volume"`` – total bid quantity (float)
        - ``"total_ask_volume"`` – total ask quantity (float)
    """
    depth = get_binance_depth(symbol=symbol, limit=limit)
    if depth is None:
        return None

    bid_prices = np.array([float(b[0]) for b in depth["bids"]])
    bid_quantities = np.array([float(b[1]) for b in depth["bids"]])

    ask_prices = np.array([float(a[0]) for a in depth["asks"]])
    ask_quantities = np.array([float(a[1]) for a in depth["asks"]])

    weighted_avg_bid = np.sum(bid_prices * bid_quantities) / np.sum(bid_quantities)
    weighted_avg_ask = np.sum(ask_prices * ask_quantities) / np.sum(ask_quantities)

    sell_price = weighted_avg_bid * (1 + sell_margin)
    buy_price = weighted_avg_ask * (1 - buy_margin)

    logger.info(
        "Order-book targets: buy=%.2f sell=%.2f (avg_bid=%.2f avg_ask=%.2f)",
        buy_price, sell_price, weighted_avg_bid, weighted_avg_ask,
    )

    return {
        "buy_price": buy_price,
        "sell_price": sell_price,
        "weighted_avg_bid": weighted_avg_bid,
        "weighted_avg_ask": weighted_avg_ask,
        "best_bid": bid_prices[0],
        "best_ask": ask_prices[0],
        "spread": ask_prices[0] - bid_prices[0],
        "total_bid_volume": float(np.sum(bid_quantities)),
        "total_ask_volume": float(np.sum(ask_quantities)),
    }
