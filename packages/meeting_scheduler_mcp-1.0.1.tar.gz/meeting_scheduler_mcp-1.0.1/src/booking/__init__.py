"""Booking engine: create, reschedule, and cancel calendar events."""
