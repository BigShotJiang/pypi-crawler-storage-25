"""
Booking engine: creates, reschedules, and cancels calendar events.

All event operations go through the primary account's provider.  Video
conferencing links are extracted from the provider-specific create-event
response and returned to the caller.

Public API
----------
book_meeting       — create a new event from a Slot.
reschedule_meeting — move an existing event to a new Slot.
cancel_meeting     — delete an existing event.
"""

from __future__ import annotations

import logging
from datetime import datetime, timezone
from typing import Any, Optional

from src.scheduling.models import EventPayload, Slot
from src.scheduling.timezone_utils import UTC, format_local

logger = logging.getLogger(__name__)


def _build_event_payload(
    slot_start: datetime,
    slot_end: datetime,
    title: str,
    participants: list[str],
    organiser_email: str,
    description: str,
    organiser_timezone: str,
    video_provider: str = "auto",
    generate_video_link: bool = True,
) -> EventPayload:
    """Construct an EventPayload from the supplied parameters."""
    return EventPayload(
        title=title,
        description=description,
        start=slot_start,
        end=slot_end,
        organiser_email=organiser_email,
        participant_emails=participants,
        timezone=organiser_timezone,
        generate_video_link=generate_video_link,
        video_provider=video_provider,
    )


def _extract_video_link(provider: Any, raw_response: Optional[dict]) -> Optional[str]:
    """Call the provider-specific hook to pull the video join URL.

    Returns None if the provider does not support video links or if no link
    was generated.
    """
    if raw_response is None:
        return None
    try:
        return provider.get_video_link_from_response(raw_response)
    except Exception as exc:
        logger.warning("Could not extract video link from response: %s", exc)
        return None


def book_meeting(
    slot: Slot,
    title: str,
    participants: list[str],
    organiser_email: str,
    primary_provider: Any,
    description: str = "",
    organiser_timezone: str = "UTC",
    generate_video_link: bool = True,
    video_provider: str = "auto",
) -> dict[str, Any]:
    """Create a calendar event for *slot* via the primary provider.

    Parameters
    ----------
    slot:
        The chosen meeting slot (UTC datetimes).
    title:
        Calendar event title / subject.
    participants:
        List of attendee email addresses.
    organiser_email:
        Email of the meeting organiser (primary account).
    primary_provider:
        Instantiated CalendarProvider for the primary account.
    description:
        Optional body / agenda text.
    organiser_timezone:
        IANA timezone used for invite display times.
    generate_video_link:
        Whether to request a conferencing link from the provider.
    video_provider:
        "auto" lets the provider decide (Google → Meet, Microsoft → Teams).
        Explicit values: "google_meet", "teams", "none".

    Returns
    -------
    dict
        {
          "event_id": str,
          "title": str,
          "start_utc": str (ISO 8601),
          "end_utc": str (ISO 8601),
          "participants": list[str],
          "video_link": str | None,
          "organiser": str,
        }
    """
    event = _build_event_payload(
        slot_start=slot.start,
        slot_end=slot.end,
        title=title,
        participants=participants,
        organiser_email=organiser_email,
        description=description,
        organiser_timezone=organiser_timezone,
        video_provider=video_provider,
        generate_video_link=generate_video_link,
    )

    try:
        event_id = primary_provider.create_event(event)
    except Exception as exc:
        raise RuntimeError(
            f"Failed to create calendar event '{title}': {exc}"
        ) from exc

    # The provider stashes the raw response on itself after create_event().
    raw_response = getattr(primary_provider, "_last_create_response", None)
    video_link = _extract_video_link(primary_provider, raw_response)

    logger.info(
        "Booked event '%s' (id=%s) from %s to %s. Video link: %s",
        title, event_id, slot.start.isoformat(), slot.end.isoformat(), video_link,
    )

    return {
        "event_id": event_id,
        "title": title,
        "start_utc": slot.start.isoformat(),
        "end_utc": slot.end.isoformat(),
        "participants": participants,
        "video_link": video_link,
        "organiser": organiser_email,
    }


def reschedule_meeting(
    event_id: str,
    new_slot: Slot,
    title: str,
    participants: list[str],
    organiser_email: str,
    primary_provider: Any,
    description: str = "",
    organiser_timezone: str = "UTC",
    generate_video_link: bool = True,
    video_provider: str = "auto",
) -> dict[str, Any]:
    """Move an existing event to *new_slot*.

    The event is updated in-place using the provider's update_event method.
    A new video link may or may not be generated depending on provider behaviour
    (Microsoft Graph preserves the Teams link; Google may issue a new Meet URL).

    Parameters
    ----------
    event_id:
        Provider-assigned identifier of the event to reschedule.
    new_slot:
        The new meeting time (UTC datetimes).
    title, participants, organiser_email, primary_provider, description,
    organiser_timezone, generate_video_link, video_provider:
        Same semantics as in book_meeting.

    Returns
    -------
    dict
        Same structure as book_meeting return value, with the same event_id.
    """
    event = _build_event_payload(
        slot_start=new_slot.start,
        slot_end=new_slot.end,
        title=title,
        participants=participants,
        organiser_email=organiser_email,
        description=description,
        organiser_timezone=organiser_timezone,
        video_provider=video_provider,
        generate_video_link=generate_video_link,
    )

    try:
        primary_provider.update_event(event_id, event)
    except Exception as exc:
        raise RuntimeError(
            f"Failed to reschedule event '{event_id}': {exc}"
        ) from exc

    raw_response = getattr(primary_provider, "_last_create_response", None)
    video_link = _extract_video_link(primary_provider, raw_response)

    logger.info(
        "Rescheduled event %s to %s — %s. Video link: %s",
        event_id, new_slot.start.isoformat(), new_slot.end.isoformat(), video_link,
    )

    return {
        "event_id": event_id,
        "title": title,
        "start_utc": new_slot.start.isoformat(),
        "end_utc": new_slot.end.isoformat(),
        "participants": participants,
        "video_link": video_link,
        "organiser": organiser_email,
    }


def cancel_meeting(
    event_id: str,
    primary_provider: Any,
) -> None:
    """Delete an event from the primary calendar.

    Parameters
    ----------
    event_id:
        Provider-assigned identifier of the event to cancel.
    primary_provider:
        Instantiated CalendarProvider for the primary account.

    Raises
    ------
    RuntimeError
        If the provider API call fails (e.g., event not found).
    """
    try:
        primary_provider.delete_event(event_id)
    except Exception as exc:
        raise RuntimeError(
            f"Failed to cancel event '{event_id}': {exc}"
        ) from exc

    logger.info("Cancelled event %s.", event_id)
