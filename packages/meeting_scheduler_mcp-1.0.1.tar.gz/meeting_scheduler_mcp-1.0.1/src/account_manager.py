"""
Account manager: loads and validates the configuration file and instantiates
the correct provider adapter for each configured account.

Configuration file location (in priority order):
1. Path specified by the MEETING_SCHEDULER_CONFIG environment variable.
2. ~/.config/meeting-scheduler/config.toml

Token storage:
  Google    — managed by src/token_storage.py (two-layer encrypted keychain).
  Microsoft — managed by msal-extensions (Keychain ACL on macOS, DPAPI on Windows).
"""

from __future__ import annotations

import logging
import os
import sys
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Optional

if sys.version_info >= (3, 11):
    import tomllib
else:
    import tomli as tomllib  # type: ignore[no-reuse-def]

from src.providers.base import CalendarProvider

logger = logging.getLogger(__name__)

DEFAULT_CONFIG_PATH = Path.home() / ".config" / "meeting-scheduler" / "config.toml"

SUPPORTED_PROVIDERS = {"google", "microsoft"}


# ─── Data classes ─────────────────────────────────────────────────────────────


@dataclass
class AccountConfig:
    """Configuration for a single calendar account."""

    org: str
    email: str
    provider: str
    is_primary: bool
    client_id: str = ""
    client_secret: str = ""


@dataclass
class SchedulingRules:
    """Scheduling rule defaults read from [rules] in config.toml."""

    default_duration_minutes: int = 30
    buffer_before_minutes: int = 0
    buffer_after_minutes: int = 15
    default_working_hours_start: str = "09:00"
    default_working_hours_end: str = "17:00"
    working_days: list[str] = field(default_factory=lambda: [
        "Monday", "Tuesday", "Wednesday", "Thursday", "Friday"
    ])
    advance_notice_hours: int = 24
    max_days_ahead: int = 30
    slot_limit: int = 10

    def as_dict(self) -> dict[str, Any]:
        return {
            "default_duration_minutes": self.default_duration_minutes,
            "buffer_before_minutes": self.buffer_before_minutes,
            "buffer_after_minutes": self.buffer_after_minutes,
            "default_working_hours_start": self.default_working_hours_start,
            "default_working_hours_end": self.default_working_hours_end,
            "working_days": self.working_days,
            "advance_notice_hours": self.advance_notice_hours,
            "max_days_ahead": self.max_days_ahead,
            "slot_limit": self.slot_limit,
        }


@dataclass
class AppConfig:
    """Full parsed application configuration."""

    accounts: list[AccountConfig]
    rules: SchedulingRules

    @property
    def primary_account(self) -> AccountConfig:
        return next(a for a in self.accounts if a.is_primary)

    @property
    def shadow_accounts(self) -> list[AccountConfig]:
        return [a for a in self.accounts if not a.is_primary]


# ─── Config loading & validation ──────────────────────────────────────────────


def _find_config_path() -> Path:
    env_path = os.environ.get("MEETING_SCHEDULER_CONFIG")
    if env_path:
        p = Path(env_path)
        if not p.exists():
            raise FileNotFoundError(
                f"Config file specified by MEETING_SCHEDULER_CONFIG does not exist: {p}"
            )
        return p
    if DEFAULT_CONFIG_PATH.exists():
        return DEFAULT_CONFIG_PATH
    raise FileNotFoundError(
        f"No configuration file found. Expected it at {DEFAULT_CONFIG_PATH} "
        "or set the MEETING_SCHEDULER_CONFIG environment variable."
    )


def _parse_accounts(raw_accounts: list[dict]) -> list[AccountConfig]:
    accounts: list[AccountConfig] = []
    for idx, raw in enumerate(raw_accounts):
        missing = [f for f in ("org", "email", "provider") if f not in raw]
        if missing:
            raise ValueError(
                f"Account #{idx + 1} is missing required field(s): {', '.join(missing)}"
            )
        provider = raw["provider"].lower()
        if provider not in SUPPORTED_PROVIDERS:
            raise ValueError(
                f"Account '{raw['email']}' uses unsupported provider '{provider}'. "
                f"Supported: {', '.join(sorted(SUPPORTED_PROVIDERS))}."
            )
        accounts.append(
            AccountConfig(
                org=raw["org"],
                email=raw["email"].lower(),
                provider=provider,
                is_primary=bool(raw.get("is_primary", False)),
                client_id=raw.get("client_id", ""),
                client_secret=raw.get("client_secret", ""),
            )
        )
    return accounts


def _validate_accounts(accounts: list[AccountConfig]) -> None:
    if not accounts:
        raise ValueError(
            "No accounts are configured. Add at least one [[accounts]] entry."
        )
    primary_accounts = [a for a in accounts if a.is_primary]
    if len(primary_accounts) == 0:
        raise ValueError(
            "No account has is_primary = true. Exactly one account must be primary."
        )
    if len(primary_accounts) > 1:
        emails = ", ".join(a.email for a in primary_accounts)
        raise ValueError(
            f"Multiple accounts have is_primary = true ({emails}). "
            "Exactly one account must be primary."
        )
    emails = [a.email for a in accounts]
    duplicates = {e for e in emails if emails.count(e) > 1}
    if duplicates:
        raise ValueError(
            f"Duplicate account email(s) detected: {', '.join(sorted(duplicates))}."
        )


def _parse_rules(raw_rules: dict) -> SchedulingRules:
    return SchedulingRules(
        default_duration_minutes=int(raw_rules.get("default_duration_minutes", 30)),
        buffer_before_minutes=int(raw_rules.get("buffer_before_minutes", 0)),
        buffer_after_minutes=int(raw_rules.get("buffer_after_minutes", 15)),
        default_working_hours_start=raw_rules.get("default_working_hours_start", "09:00"),
        default_working_hours_end=raw_rules.get("default_working_hours_end", "17:00"),
        working_days=raw_rules.get(
            "working_days",
            ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"],
        ),
        advance_notice_hours=int(raw_rules.get("advance_notice_hours", 24)),
        max_days_ahead=int(raw_rules.get("max_days_ahead", 30)),
        slot_limit=int(raw_rules.get("slot_limit", 10)),
    )


def load_config(config_path: Optional[Path] = None) -> AppConfig:
    """Load and validate the application configuration from a TOML file.

    Raises
    ------
    FileNotFoundError
        If the config file cannot be found.
    ValueError
        If the config is invalid (missing fields, wrong primary count, etc.).
    """
    path = config_path or _find_config_path()
    logger.info("Loading configuration from %s", path)

    with open(path, "rb") as fh:
        raw: dict = tomllib.load(fh)

    raw_accounts = raw.get("accounts", [])
    if not isinstance(raw_accounts, list):
        raise ValueError("The 'accounts' key must be a TOML array ([[accounts]]).")

    accounts = _parse_accounts(raw_accounts)
    _validate_accounts(accounts)
    rules = _parse_rules(raw.get("rules", {}))

    return AppConfig(accounts=accounts, rules=rules)


# ─── Provider factory ─────────────────────────────────────────────────────────


def build_provider(account: AccountConfig, rules: SchedulingRules) -> CalendarProvider:
    """Instantiate the correct CalendarProvider for *account*.

    Authentication is lazy — credentials are loaded from secure storage on the
    first API call, not at construction time.
    """
    kwargs = dict(
        email=account.email,
        is_primary=account.is_primary,
        default_working_hours_start=rules.default_working_hours_start,
        default_working_hours_end=rules.default_working_hours_end,
        default_working_days=rules.working_days,
    )

    if account.provider == "google":
        from src.providers.google import GoogleCalendarProvider
        return GoogleCalendarProvider(
            client_id=account.client_id,
            client_secret=account.client_secret,
            **kwargs,
        )

    if account.provider == "microsoft":
        from src.providers.microsoft import MicrosoftCalendarProvider
        return MicrosoftCalendarProvider(
            client_id=account.client_id,
            **kwargs,
        )

    raise ValueError(
        f"Unknown provider '{account.provider}' for account {account.email}. "
        f"Supported: {', '.join(sorted(SUPPORTED_PROVIDERS))}."
    )


def build_provider_map(config: AppConfig) -> dict[str, CalendarProvider]:
    """Build a mapping from account email → CalendarProvider for all accounts."""
    return {
        account.email: build_provider(account, config.rules)
        for account in config.accounts
    }
