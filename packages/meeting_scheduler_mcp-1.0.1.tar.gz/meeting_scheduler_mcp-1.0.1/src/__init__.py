"""Meeting Scheduler MCP — source package."""
