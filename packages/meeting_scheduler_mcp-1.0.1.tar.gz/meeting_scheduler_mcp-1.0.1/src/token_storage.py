"""
Secure storage for Google OAuth refresh tokens.

Two-layer design
----------------
Layer 1 — encryption key (process / machine locked):
    macOS:   32-byte key stored in a keychain item whose ACL is locked to the
             calling process via Security.framework.  Any other process that
             tries to read it will receive a macOS permission prompt.
    Windows: 32-byte key encrypted with DPAPI (CryptProtectData) and stored in
             keyring.  The ciphertext is machine- and user-bound; it cannot be
             decrypted on a different machine or by a different Windows user.
    Linux:   Key stored in the OS secret store via keyring (no extra ACL;
             fallback for completeness).

Layer 2 — encrypted refresh token:
    All platforms: AES-256-GCM ciphertext stored in the generic keyring.
    Without the Layer-1 key the ciphertext is useless.

Public API
----------
    store_google_refresh_token(email, token)
    load_google_refresh_token(email)  -> str | None
    delete_google_refresh_token(email)
"""

from __future__ import annotations

import base64
import logging
import os
import platform
from typing import Optional

import keyring
from cryptography.hazmat.primitives.ciphers.aead import AESGCM

logger = logging.getLogger(__name__)

_KEYRING_SERVICE = "meeting-scheduler"
_KEY_SUFFIX = ":enc-key"
_TOKEN_SUFFIX = ":refresh-token"
_DPAPI_KEY_SUFFIX = ":dpapi-enc-key"


# ── Public API ────────────────────────────────────────────────────────────────


def store_google_refresh_token(email: str, token: str) -> None:
    """Encrypt and persist *token* for *email* using platform-specific storage."""
    key = _get_or_create_key(email)
    ciphertext = _encrypt(token, key)
    keyring.set_password(
        _KEYRING_SERVICE,
        email + _TOKEN_SUFFIX,
        base64.b64encode(ciphertext).decode(),
    )
    logger.debug("Stored encrypted refresh token for %s.", email)


def load_google_refresh_token(email: str) -> Optional[str]:
    """Load and decrypt the refresh token for *email*, or return None."""
    raw = keyring.get_password(_KEYRING_SERVICE, email + _TOKEN_SUFFIX)
    if not raw:
        return None
    key = _get_or_create_key(email)
    try:
        return _decrypt(base64.b64decode(raw), key)
    except Exception as exc:
        logger.error("Failed to decrypt refresh token for %s: %s", email, exc)
        return None


def delete_google_refresh_token(email: str) -> None:
    """Remove all stored credentials for *email*."""
    for suffix in (_TOKEN_SUFFIX,):
        try:
            keyring.delete_password(_KEYRING_SERVICE, email + suffix)
        except Exception:
            pass
    _delete_key(email)
    logger.debug("Deleted stored credentials for %s.", email)


# ── AES-256-GCM helpers ───────────────────────────────────────────────────────


def _encrypt(plaintext: str, key: bytes) -> bytes:
    nonce = os.urandom(12)  # 96-bit nonce, unique per encryption
    ciphertext = AESGCM(key).encrypt(nonce, plaintext.encode(), None)
    return nonce + ciphertext  # prepend nonce so decrypt can find it


def _decrypt(data: bytes, key: bytes) -> str:
    nonce, ciphertext = data[:12], data[12:]
    return AESGCM(key).decrypt(nonce, ciphertext, None).decode()


# ── Key management dispatcher ─────────────────────────────────────────────────


def _get_or_create_key(email: str) -> bytes:
    system = platform.system()
    account = email + _KEY_SUFFIX
    if system == "Darwin":
        return _macos_get_or_create_key(account)
    if system == "Windows":
        return _windows_get_or_create_key(account)
    return _fallback_get_or_create_key(account)


def _delete_key(email: str) -> None:
    system = platform.system()
    account = email + _KEY_SUFFIX
    if system == "Darwin":
        _macos_delete_key(account)
    elif system == "Windows":
        _windows_delete_key(account)
    else:
        _fallback_delete_key(account)


# ── macOS: Security.framework via ctypes ──────────────────────────────────────
#
# The encryption key is stored as a generic-password keychain item created with
# SecKeychainItemCreateFromContent.  The item's SecAccessRef is built from a
# SecTrustedApplicationRef for the *current process* (NULL path = self), so
# only the process that created the item — and processes the user explicitly
# grants — can read it without a macOS permission prompt.


def _macos_get_or_create_key(account: str) -> bytes:
    key = _macos_load_key(account)
    if key is None:
        key = os.urandom(32)
        _macos_store_key(account, key)
    return key


def _macos_load_key(account: str) -> Optional[bytes]:
    import ctypes
    import ctypes.util

    sec = ctypes.cdll.LoadLibrary(ctypes.util.find_library("Security"))
    sec.SecKeychainFindGenericPassword.restype = ctypes.c_int32

    svc = _KEYRING_SERVICE.encode()
    acct = account.encode()
    length = ctypes.c_uint32(0)
    data_ptr = ctypes.c_void_p()

    status = sec.SecKeychainFindGenericPassword(
        None,
        len(svc), svc,
        len(acct), acct,
        ctypes.byref(length),
        ctypes.byref(data_ptr),
        None,
    )

    if status == -25300:  # errSecItemNotFound
        return None
    if status != 0:
        raise RuntimeError(f"Keychain read failed (OSStatus {status}).")

    raw = bytes(ctypes.string_at(data_ptr.value, length.value))
    sec.SecKeychainItemFreeContent(None, data_ptr)
    return raw


def _macos_store_key(account: str, key: bytes) -> None:
    import ctypes
    import ctypes.util

    sec = ctypes.cdll.LoadLibrary(ctypes.util.find_library("Security"))
    cf = ctypes.cdll.LoadLibrary(ctypes.util.find_library("CoreFoundation"))

    svc = _KEYRING_SERVICE.encode()
    acct = account.encode()

    # Remove any pre-existing item so we can recreate with the correct ACL.
    item_ref = ctypes.c_void_p()
    if sec.SecKeychainFindGenericPassword(
        None, len(svc), svc, len(acct), acct, None, None, ctypes.byref(item_ref)
    ) == 0 and item_ref.value:
        sec.SecKeychainItemDelete(item_ref)
        sec.CFRelease(item_ref)

    # ── Build SecAccessRef locked to the current process ──────────────────────

    # SecTrustedApplicationCreateFromPath(NULL, &app) → trusted app = self
    trusted_app = ctypes.c_void_p()
    status = sec.SecTrustedApplicationCreateFromPath(None, ctypes.byref(trusted_app))
    if status != 0:
        raise RuntimeError(f"SecTrustedApplicationCreateFromPath failed: {status}")

    # CFArrayCreate([trusted_app], kCFTypeArrayCallBacks)
    # kCFTypeArrayCallBacks is a struct exported from CoreFoundation; we need
    # its address (not its value) to pass as a const CFArrayCallBacks *.
    _cb = (ctypes.c_byte * 1).in_dll(cf, "kCFTypeArrayCallBacks")
    callbacks_addr = ctypes.addressof(_cb)

    cf.CFArrayCreate.restype = ctypes.c_void_p
    items = (ctypes.c_void_p * 1)(trusted_app.value)
    cf_array = cf.CFArrayCreate(None, items, 1, callbacks_addr)

    # CFString descriptor (human-readable label shown in Keychain Access)
    kCFStringEncodingUTF8 = 0x08000100
    cf.CFStringCreateWithCString.restype = ctypes.c_void_p
    desc_cfstr = cf.CFStringCreateWithCString(
        None, b"meeting-scheduler-google-key", kCFStringEncodingUTF8
    )

    # SecAccessCreate(descriptor, trustedList, &access)
    sec.SecAccessCreate.restype = ctypes.c_int32
    access = ctypes.c_void_p()
    status = sec.SecAccessCreate(desc_cfstr, cf_array, ctypes.byref(access))
    cf.CFRelease(desc_cfstr)
    cf.CFRelease(cf_array)
    cf.CFRelease(trusted_app)
    if status != 0:
        raise RuntimeError(f"SecAccessCreate failed: {status}")

    # ── Create keychain item with that ACL ────────────────────────────────────

    kSecGenericPasswordItemClass = 0x67656E70  # 'genp'
    kSecServiceItemAttr = 0x73766365           # 'svce'
    kSecAccountItemAttr = 0x61636374           # 'acct'

    class _Attr(ctypes.Structure):
        _fields_ = [
            ("tag", ctypes.c_uint32),
            ("length", ctypes.c_uint32),
            ("data", ctypes.c_void_p),
        ]

    class _AttrList(ctypes.Structure):
        _fields_ = [
            ("count", ctypes.c_uint32),
            ("attr", ctypes.POINTER(_Attr)),
        ]

    svc_buf = ctypes.create_string_buffer(svc)
    acct_buf = ctypes.create_string_buffer(acct)
    attrs = (_Attr * 2)(
        _Attr(kSecServiceItemAttr, len(svc), ctypes.cast(svc_buf, ctypes.c_void_p)),
        _Attr(kSecAccountItemAttr, len(acct), ctypes.cast(acct_buf, ctypes.c_void_p)),
    )
    attr_list = _AttrList(2, attrs)

    key_buf = (ctypes.c_ubyte * len(key))(*key)
    item_out = ctypes.c_void_p()

    sec.SecKeychainItemCreateFromContent.restype = ctypes.c_int32
    status = sec.SecKeychainItemCreateFromContent(
        kSecGenericPasswordItemClass,
        ctypes.byref(attr_list),
        len(key),
        key_buf,
        None,    # default keychain
        access,
        ctypes.byref(item_out),
    )
    cf.CFRelease(access)
    if item_out.value:
        sec.CFRelease(item_out)

    if status != 0:
        raise RuntimeError(f"SecKeychainItemCreateFromContent failed: {status}")

    logger.debug("Stored ACL-locked encryption key for %s in macOS Keychain.", account)


def _macos_delete_key(account: str) -> None:
    import ctypes
    import ctypes.util

    sec = ctypes.cdll.LoadLibrary(ctypes.util.find_library("Security"))
    svc = _KEYRING_SERVICE.encode()
    acct = account.encode()
    item_ref = ctypes.c_void_p()
    status = sec.SecKeychainFindGenericPassword(
        None, len(svc), svc, len(acct), acct, None, None, ctypes.byref(item_ref)
    )
    if status == 0 and item_ref.value:
        sec.SecKeychainItemDelete(item_ref)
        sec.CFRelease(item_ref)


# ── Windows: DPAPI (CryptProtectData) ────────────────────────────────────────
#
# The encryption key is DPAPI-encrypted and stored in keyring.  DPAPI ties the
# ciphertext to the current Windows user account and machine; it cannot be
# decrypted on a different machine even by the same user.


def _windows_get_or_create_key(account: str) -> bytes:
    raw = keyring.get_password(_KEYRING_SERVICE, account + _DPAPI_KEY_SUFFIX)
    if raw:
        try:
            import win32crypt  # type: ignore[import]
            _, key = win32crypt.CryptUnprotectData(
                base64.b64decode(raw), None, None, None, 0
            )
            return key
        except Exception as exc:
            logger.warning("DPAPI decrypt failed for %s: %s. Regenerating key.", account, exc)

    key = os.urandom(32)
    _windows_store_key(account, key)
    return key


def _windows_store_key(account: str, key: bytes) -> None:
    import win32crypt  # type: ignore[import]

    encrypted = win32crypt.CryptProtectData(
        key,
        f"meeting-scheduler-{account}",
        None, None, None,
        0,
    )
    keyring.set_password(
        _KEYRING_SERVICE,
        account + _DPAPI_KEY_SUFFIX,
        base64.b64encode(encrypted).decode(),
    )
    logger.debug("Stored DPAPI-encrypted key for %s.", account)


def _windows_delete_key(account: str) -> None:
    try:
        keyring.delete_password(_KEYRING_SERVICE, account + _DPAPI_KEY_SUFFIX)
    except Exception:
        pass


# ── Linux fallback ────────────────────────────────────────────────────────────


def _fallback_get_or_create_key(account: str) -> bytes:
    raw = keyring.get_password(_KEYRING_SERVICE + ":key", account)
    if raw:
        return base64.b64decode(raw)
    key = os.urandom(32)
    keyring.set_password(_KEYRING_SERVICE + ":key", account, base64.b64encode(key).decode())
    return key


def _fallback_delete_key(account: str) -> None:
    try:
        keyring.delete_password(_KEYRING_SERVICE + ":key", account)
    except Exception:
        pass
