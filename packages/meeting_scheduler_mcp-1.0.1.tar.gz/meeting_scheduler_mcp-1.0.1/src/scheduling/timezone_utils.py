"""
Timezone utility helpers for the meeting-scheduler-mcp application.

All internal datetimes are UTC.  These helpers convert to/from local time and
produce human-readable display strings.
"""

from __future__ import annotations

from datetime import datetime, time, timedelta, timezone
from typing import Optional

import pytz
from dateutil import tz


UTC = timezone.utc


def utc_now() -> datetime:
    """Return the current moment as a timezone-aware UTC datetime."""
    return datetime.now(UTC)


def to_utc(dt: datetime) -> datetime:
    """Convert *dt* to UTC.  If *dt* is naive it is assumed to already be UTC."""
    if dt.tzinfo is None:
        return dt.replace(tzinfo=UTC)
    return dt.astimezone(UTC)


def to_local(dt: datetime, iana_tz: str) -> datetime:
    """Convert UTC *dt* to the local time of *iana_tz*."""
    local_tz = pytz.timezone(iana_tz)
    return dt.astimezone(local_tz)


def format_local(dt: datetime, iana_tz: str) -> str:
    """Return a human-readable local time string for *dt* in *iana_tz*.

    Example output: "2:00 PM EST (Tue, 02 Jun)"
    """
    local_dt = to_local(dt, iana_tz)
    # %Z gives the abbreviated timezone name; %I:%M %p gives 12-hour clock.
    return local_dt.strftime("%-I:%M %p %Z (%a, %d %b)")


def local_time_to_utc(date: datetime, time_str: str, iana_tz: str) -> datetime:
    """Combine *date* (date portion) with *time_str* ("HH:MM") in *iana_tz* → UTC.

    *date* is used only for its year/month/day; the time portion is ignored.
    DST transitions are handled correctly by pytz.localize with is_dst=False.
    """
    local_tz = pytz.timezone(iana_tz)
    hour, minute = (int(p) for p in time_str.split(":"))
    naive = date.replace(hour=hour, minute=minute, second=0, microsecond=0, tzinfo=None)
    # is_dst=None raises AmbiguousTimeError; False picks the first occurrence.
    try:
        local_dt = local_tz.localize(naive, is_dst=False)
    except pytz.exceptions.NonExistentTimeError:
        # Clocks spring forward — shift 1 hour ahead.
        local_dt = local_tz.localize(naive + timedelta(hours=1), is_dst=True)
    return local_dt.astimezone(UTC)


def working_hours_utc(
    day: datetime,
    working_hours_start: str,
    working_hours_end: str,
    iana_tz: str,
) -> tuple[datetime, datetime]:
    """Return the UTC working-hours window for *day* in *iana_tz*.

    *day* should be a UTC midnight or any UTC time on the target day.
    Returns (window_start_utc, window_end_utc).
    """
    start_utc = local_time_to_utc(day, working_hours_start, iana_tz)
    end_utc = local_time_to_utc(day, working_hours_end, iana_tz)
    return start_utc, end_utc


def day_name(dt: datetime, iana_tz: Optional[str] = None) -> str:
    """Return the full English weekday name for *dt* in the given timezone.

    If *iana_tz* is None the UTC date is used.
    """
    if iana_tz:
        dt = to_local(dt, iana_tz)
    return dt.strftime("%A")


def parse_iso(value: str) -> datetime:
    """Parse an ISO 8601 string and ensure the result is timezone-aware UTC.

    Accepts strings with or without timezone offset.  Naive strings are
    treated as UTC.
    """
    from dateutil.parser import isoparse

    dt = isoparse(value)
    return to_utc(dt)


def validate_iana_timezone(tz_str: str) -> bool:
    """Return True if *tz_str* is a valid IANA timezone identifier."""
    try:
        pytz.timezone(tz_str)
        return True
    except pytz.exceptions.UnknownTimeZoneError:
        return False
