"""
Data models used throughout the meeting-scheduler-mcp application.

All datetime fields are stored in UTC.  Conversion to local time for display
is performed only at the presentation layer (scheduling engine output).
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import Optional


@dataclass
class BusyInterval:
    """A half-open interval [start, end) during which a calendar is busy.

    Both timestamps must be timezone-aware UTC datetimes.
    """

    start: datetime  # UTC
    end: datetime    # UTC

    def __post_init__(self) -> None:
        if self.start.tzinfo is None or self.end.tzinfo is None:
            raise ValueError("BusyInterval datetimes must be timezone-aware (UTC).")
        if self.start >= self.end:
            raise ValueError(
                f"BusyInterval start ({self.start}) must be before end ({self.end})."
            )

    def overlaps(self, other: "BusyInterval") -> bool:
        """Return True if this interval overlaps with *other*."""
        return self.start < other.end and other.start < self.end

    def union(self, other: "BusyInterval") -> "BusyInterval":
        """Return the smallest interval that covers both self and *other*.

        Caller must verify the intervals overlap or are adjacent before calling
        this method.
        """
        return BusyInterval(
            start=min(self.start, other.start),
            end=max(self.end, other.end),
        )


@dataclass
class MailboxSettings:
    """Working-hours and timezone preferences for a single mailbox.

    These are either fetched from the provider (Microsoft Graph exposes them;
    Google does not) or fall back to the global rule defaults.
    """

    timezone: str             # IANA timezone string, e.g. "America/New_York"
    working_hours_start: str  # "HH:MM" local time, e.g. "09:00"
    working_hours_end: str    # "HH:MM" local time, e.g. "17:00"
    working_days: list[str]   # Full English day names, e.g. ["Monday", "Tuesday"]


@dataclass
class Slot:
    """A candidate meeting time returned by the scheduling engine.

    *start* and *end* are UTC.  *participants_local* maps each participant's
    email address to a human-readable local-time string for display.
    """

    start: datetime  # UTC
    end: datetime    # UTC
    participants_local: dict[str, str] = field(default_factory=dict)
    # email -> "2:00 PM EST (Tue 2 Jun)"

    def duration_minutes(self) -> int:
        """Return the duration of this slot in whole minutes."""
        return int((self.end - self.start).total_seconds() // 60)


@dataclass
class EventPayload:
    """All the information needed to create a calendar event.

    The booking engine converts a *Slot* plus user-supplied metadata into an
    *EventPayload* before handing it off to the provider adapter.
    """

    title: str
    description: str
    start: datetime            # UTC
    end: datetime              # UTC
    organiser_email: str
    participant_emails: list[str]
    timezone: str              # IANA timezone used for the invite display
    generate_video_link: bool = True
    video_provider: str = "auto"  # "google_meet" | "teams" | "none" | "auto"

    def __post_init__(self) -> None:
        if self.start.tzinfo is None or self.end.tzinfo is None:
            raise ValueError("EventPayload datetimes must be timezone-aware (UTC).")
        if self.start >= self.end:
            raise ValueError("EventPayload start must be before end.")
