"""
Scheduling engine: finds available meeting slots across multiple calendars.

Core algorithm
--------------
1. Collect the primary account holder's busy intervals from the primary provider.
2. For each participant, route the free/busy query through the shadow account
   whose domain matches the participant's email domain.
3. Fetch mailbox settings (timezone + working hours) for every participant.
4. Merge all busy intervals into a single sorted, de-duplicated list.
5. Walk candidate 30-minute (or user-supplied) slots through the search window,
   skipping any that overlap a busy interval or fall outside all participants'
   working hours.
6. Return up to `slot_limit` Slot objects with per-participant local-time strings.

Error classes
-------------
ParticipantDomainNotConfigured — raised when no shadow account covers a domain.
NoSlotsFound                   — raised when the window yields no valid slots.
"""

from __future__ import annotations

import logging
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timedelta, timezone
from typing import TYPE_CHECKING, Optional

from src.scheduling.models import BusyInterval, MailboxSettings, Slot
from src.scheduling.timezone_utils import (
    UTC,
    day_name,
    format_local,
    utc_now,
    working_hours_utc,
)

if TYPE_CHECKING:
    from src.account_manager import AccountConfig
    from src.providers.base import CalendarProvider

logger = logging.getLogger(__name__)


# ─── Custom Exceptions ────────────────────────────────────────────────────────


class ParticipantDomainNotConfigured(Exception):
    """Raised when no configured account can query a participant's domain."""

    def __init__(self, email: str) -> None:
        domain = email.split("@")[-1] if "@" in email else email
        super().__init__(
            f"No account is configured for the domain '{domain}' "
            f"(participant: {email}). Add a shadow account for that org in "
            "config.toml to query their free/busy."
        )
        self.email = email


class NoSlotsFound(Exception):
    """Raised when the scheduling engine cannot find any available slot."""

    REASONS = {"ALL_BUSY", "WINDOW_TOO_SHORT", "OUTSIDE_WORKING_HOURS"}

    def __init__(self, reason: str, detail: str = "") -> None:
        if reason not in self.REASONS:
            reason = "ALL_BUSY"
        message = {
            "ALL_BUSY": "All participants are busy throughout the requested window.",
            "WINDOW_TOO_SHORT": "The search window is too short to fit a meeting.",
            "OUTSIDE_WORKING_HOURS": (
                "No slots fall within all participants' working hours."
            ),
        }[reason]
        if detail:
            message = f"{message} {detail}"
        super().__init__(message)
        self.reason = reason


# ─── Internal helpers ─────────────────────────────────────────────────────────


def _merge_busy_intervals(intervals: list[BusyInterval]) -> list[BusyInterval]:
    """Return a sorted, non-overlapping list of busy intervals.

    Adjacent or overlapping intervals are merged into one.
    """
    if not intervals:
        return []
    sorted_intervals = sorted(intervals, key=lambda b: b.start)
    merged: list[BusyInterval] = [sorted_intervals[0]]
    for current in sorted_intervals[1:]:
        last = merged[-1]
        if current.start <= last.end:
            merged[-1] = last.union(current)
        else:
            merged.append(current)
    return merged


def _expand_with_buffers(
    intervals: list[BusyInterval],
    buffer_before: timedelta,
    buffer_after: timedelta,
) -> list[BusyInterval]:
    """Expand each busy interval by the configured buffer durations.

    This ensures meetings are not scheduled immediately before or after an
    existing commitment.
    """
    expanded = [
        BusyInterval(
            start=max(b.start - buffer_before, b.start - buffer_before),
            end=b.end + buffer_after,
        )
        for b in intervals
    ]
    return _merge_busy_intervals(expanded)


def _slot_is_free(
    slot_start: datetime,
    slot_end: datetime,
    busy: list[BusyInterval],
) -> bool:
    """Return True iff [slot_start, slot_end) does not overlap any busy interval."""
    probe = BusyInterval(start=slot_start, end=slot_end)
    for b in busy:
        if b.start >= slot_end:
            # Busy list is sorted; no further overlap possible.
            break
        if probe.overlaps(b):
            return False
    return True


def _slot_within_working_hours(
    slot_start: datetime,
    slot_end: datetime,
    settings: list[MailboxSettings],
) -> bool:
    """Return True iff the slot fits within EVERY participant's working hours.

    The slot must be fully contained within the intersection of all working-hour
    windows on that day.  If any participant is not working on that day the slot
    is rejected.
    """
    for ms in settings:
        wday = day_name(slot_start, ms.timezone)
        if wday not in ms.working_days:
            return False
        wh_start, wh_end = working_hours_utc(
            slot_start, ms.working_hours_start, ms.working_hours_end, ms.timezone
        )
        if slot_start < wh_start or slot_end > wh_end:
            return False
    return True


def _fetch_busy_for_email(
    email: str,
    provider: "CalendarProvider",
    start: datetime,
    end: datetime,
) -> list[BusyInterval]:
    """Fetch busy intervals for *email* using *provider*, with logging."""
    try:
        intervals = provider.get_free_busy(email, start, end)
        logger.debug("Fetched %d busy intervals for %s.", len(intervals), email)
        return intervals
    except Exception as exc:
        logger.warning(
            "Could not fetch free/busy for %s: %s. Treating as free.", email, exc
        )
        return []


def _fetch_mailbox_settings(
    email: str,
    provider: "CalendarProvider",
    default_settings: MailboxSettings,
) -> MailboxSettings:
    """Fetch mailbox settings for *email*, falling back to *default_settings*."""
    try:
        settings = provider.get_mailbox_settings(email)
        logger.debug("Fetched mailbox settings for %s: tz=%s.", email, settings.timezone)
        return settings
    except Exception as exc:
        logger.warning(
            "Could not fetch mailbox settings for %s: %s. Using defaults.", email, exc
        )
        return default_settings


def _find_provider_for_email(
    email: str,
    primary_account: "AccountConfig",
    shadow_accounts: list["AccountConfig"],
    provider_map: dict[str, "CalendarProvider"],
) -> "CalendarProvider":
    """Return the provider that should be used to query *email*'s free/busy.

    Matching rule: if the email domain matches the primary account's domain,
    use the primary provider.  Otherwise search shadow accounts by domain.
    Raises ParticipantDomainNotConfigured if no match is found.
    """
    participant_domain = email.split("@")[-1].lower()
    primary_domain = primary_account.email.split("@")[-1].lower()

    if participant_domain == primary_domain:
        return provider_map[primary_account.email]

    for shadow in shadow_accounts:
        shadow_domain = shadow.email.split("@")[-1].lower()
        if participant_domain == shadow_domain:
            return provider_map[shadow.email]

    raise ParticipantDomainNotConfigured(email)


# ─── Public API ───────────────────────────────────────────────────────────────


def find_slots(
    primary_account: "AccountConfig",
    shadow_accounts: list["AccountConfig"],
    provider_map: dict[str, "CalendarProvider"],
    participants: list[str],
    duration_minutes: int,
    window_start: datetime,
    window_end: datetime,
    rules: dict,
) -> list[Slot]:
    """Find available meeting slots that work for all participants.

    Parameters
    ----------
    primary_account:
        The AccountConfig with is_primary=True.
    shadow_accounts:
        All AccountConfig objects with is_primary=False.
    provider_map:
        Maps account email → instantiated CalendarProvider.
    participants:
        List of participant email addresses (not including the organiser).
    duration_minutes:
        Desired meeting length in minutes.
    window_start:
        Start of the search window (UTC, timezone-aware).
    window_end:
        End of the search window (UTC, timezone-aware).
    rules:
        Dict from the [rules] section of config.toml.

    Returns
    -------
    list[Slot]
        Up to rules["slot_limit"] Slot objects, earliest first.

    Raises
    ------
    ParticipantDomainNotConfigured
        When a participant's domain does not match any configured account.
    NoSlotsFound
        When no suitable slot exists within the window.
    """
    now = utc_now()
    duration = timedelta(minutes=duration_minutes)
    buffer_before = timedelta(minutes=rules.get("buffer_before_minutes", 0))
    buffer_after = timedelta(minutes=rules.get("buffer_after_minutes", 15))
    advance_notice = timedelta(hours=rules.get("advance_notice_hours", 24))
    slot_limit: int = rules.get("slot_limit", 10)
    default_tz: str = "UTC"

    # Enforce advance-notice: earliest slot start is now + advance_notice.
    earliest_start = now + advance_notice
    effective_window_start = max(window_start, earliest_start)

    if effective_window_start + duration > window_end:
        raise NoSlotsFound(
            "WINDOW_TOO_SHORT",
            f"The window must span at least {duration_minutes} minutes beyond "
            f"the advance-notice period ({advance_notice}).",
        )

    # ── Step 1: determine which provider handles each participant ──────────────
    participant_providers: dict[str, "CalendarProvider"] = {}
    for email in participants:
        participant_providers[email] = _find_provider_for_email(
            email, primary_account, shadow_accounts, provider_map
        )

    default_mailbox = MailboxSettings(
        timezone=default_tz,
        working_hours_start=rules.get("default_working_hours_start", "09:00"),
        working_hours_end=rules.get("default_working_hours_end", "17:00"),
        working_days=rules.get(
            "working_days",
            ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"],
        ),
    )

    # ── Step 2: parallel free/busy + mailbox-settings fetches ─────────────────
    primary_provider = provider_map[primary_account.email]

    all_busy: list[BusyInterval] = []
    mailbox_settings_list: list[MailboxSettings] = []

    with ThreadPoolExecutor(max_workers=min(8, 1 + len(participants))) as pool:
        # Primary account holder's own busy time.
        futures: dict = {
            pool.submit(
                _fetch_busy_for_email,
                primary_account.email,
                primary_provider,
                window_start,
                window_end,
            ): ("busy", primary_account.email),
            pool.submit(
                _fetch_mailbox_settings,
                primary_account.email,
                primary_provider,
                default_mailbox,
            ): ("settings", primary_account.email),
        }

        for email, prov in participant_providers.items():
            futures[
                pool.submit(
                    _fetch_busy_for_email, email, prov, window_start, window_end
                )
            ] = ("busy", email)
            futures[
                pool.submit(
                    _fetch_mailbox_settings, email, prov, default_mailbox
                )
            ] = ("settings", email)

        busy_by_email: dict[str, list[BusyInterval]] = {}
        settings_by_email: dict[str, MailboxSettings] = {}

        for future in as_completed(futures):
            kind, email = futures[future]
            try:
                result = future.result()
            except Exception as exc:
                logger.error("Unexpected error fetching %s for %s: %s", kind, email, exc)
                result = [] if kind == "busy" else default_mailbox
            if kind == "busy":
                busy_by_email[email] = result
            else:
                settings_by_email[email] = result

    # ── Step 3: merge all busy intervals (with buffers) ───────────────────────
    for email, intervals in busy_by_email.items():
        all_busy.extend(intervals)

    all_busy_merged = _merge_busy_intervals(all_busy)
    all_busy_with_buffers = _expand_with_buffers(
        all_busy_merged, buffer_before, buffer_after
    )

    # Collect mailbox settings for working-hours checking.
    for email in [primary_account.email] + participants:
        mailbox_settings_list.append(
            settings_by_email.get(email, default_mailbox)
        )

    # ── Step 4: walk candidate slots ─────────────────────────────────────────
    slots: list[Slot] = []
    candidate_start = effective_window_start

    # Round up to next whole 15-minute boundary for cleaner times.
    remainder = candidate_start.minute % 15
    if remainder:
        candidate_start += timedelta(minutes=15 - remainder)
    candidate_start = candidate_start.replace(second=0, microsecond=0)

    working_days_set = {
        d.lower() for d in rules.get(
            "working_days",
            ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"],
        )
    }

    while candidate_start + duration <= window_end and len(slots) < slot_limit:
        candidate_end = candidate_start + duration

        # Skip non-working days (quick check using primary tz before full check).
        primary_tz = mailbox_settings_list[0].timezone if mailbox_settings_list else "UTC"
        if day_name(candidate_start, primary_tz).lower() not in working_days_set:
            # Jump to next day's working-hours start.
            candidate_start += timedelta(days=1)
            candidate_start = candidate_start.replace(
                hour=0, minute=0, second=0, microsecond=0
            )
            continue

        if (
            _slot_is_free(candidate_start, candidate_end, all_busy_with_buffers)
            and _slot_within_working_hours(
                candidate_start, candidate_end, mailbox_settings_list
            )
        ):
            participants_local: dict[str, str] = {}
            all_emails = [primary_account.email] + participants
            for email, ms in zip(all_emails, mailbox_settings_list):
                participants_local[email] = format_local(candidate_start, ms.timezone)

            slots.append(
                Slot(
                    start=candidate_start,
                    end=candidate_end,
                    participants_local=participants_local,
                )
            )

        candidate_start += timedelta(minutes=15)

    if not slots:
        # Distinguish between "all busy" and "outside working hours" by checking
        # if any free gap exists in the window at all.
        has_free_gap = not _merge_busy_intervals(all_busy_with_buffers) or any(
            b.start > effective_window_start for b in all_busy_with_buffers
        )
        if has_free_gap:
            raise NoSlotsFound("OUTSIDE_WORKING_HOURS")
        raise NoSlotsFound("ALL_BUSY")

    logger.info("Found %d available slot(s).", len(slots))
    return slots
