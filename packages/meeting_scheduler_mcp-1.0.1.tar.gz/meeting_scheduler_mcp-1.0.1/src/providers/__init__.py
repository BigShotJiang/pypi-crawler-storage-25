"""Calendar provider adapters."""
