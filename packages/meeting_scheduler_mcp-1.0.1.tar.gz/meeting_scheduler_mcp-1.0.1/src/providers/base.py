"""
Abstract base class for calendar provider adapters.

All concrete providers (Google, Microsoft) must implement every abstract
method.  The interface is intentionally minimal: free/busy querying,
mailbox settings, event CRUD, and a connectivity health check.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from datetime import datetime

from src.scheduling.models import BusyInterval, EventPayload, MailboxSettings


class CalendarProvider(ABC):
    """Abstract adapter for a calendar back-end (Google or Microsoft).

    Implementations are responsible for:
    * Maintaining a valid OAuth token (or equivalent credential) and refreshing
      it transparently before each API call.
    * Mapping provider-specific error responses into standard Python exceptions
      with human-readable messages.
    * Returning timezone-aware UTC datetimes in all output objects.
    """

    # ── Free / busy ────────────────────────────────────────────────────────────

    @abstractmethod
    def get_free_busy(
        self,
        email: str,
        start: datetime,
        end: datetime,
    ) -> list[BusyInterval]:
        """Return busy intervals for *email* within [start, end).

        Parameters
        ----------
        email:
            The calendar owner whose free/busy is requested.
        start:
            Window start — UTC, timezone-aware.
        end:
            Window end — UTC, timezone-aware.

        Returns
        -------
        list[BusyInterval]
            Zero or more non-overlapping intervals.  The list may be unsorted;
            the scheduling engine will sort and merge them.
        """

    # ── Mailbox settings ───────────────────────────────────────────────────────

    @abstractmethod
    def get_mailbox_settings(self, email: str) -> MailboxSettings:
        """Return working-hours and timezone preferences for *email*.

        Providers that do not expose this information should return a
        MailboxSettings populated with sensible defaults rather than raising
        an error.
        """

    # ── Event management ───────────────────────────────────────────────────────

    @abstractmethod
    def create_event(self, event: EventPayload) -> str:
        """Create a calendar event and return the provider-assigned event ID.

        The implementation should attempt to attach a video conferencing link
        when event.generate_video_link is True and the provider supports it.

        Returns
        -------
        str
            The opaque event identifier assigned by the provider.
        """

    @abstractmethod
    def update_event(self, event_id: str, event: EventPayload) -> None:
        """Replace the event identified by *event_id* with *event*'s data.

        Implementations should perform a full replace (PUT semantics), not a
        partial patch, to keep behaviour consistent across providers.
        """

    @abstractmethod
    def get_event(self, event_id: str) -> dict:
        """Return a normalised summary of the event identified by *event_id*.

        Returns
        -------
        dict
            {
              "title": str,
              "description": str,
              "participants": list[str],   # attendee email addresses
            }

        Raises
        ------
        RuntimeError
            If the event cannot be fetched (e.g. not found or permission error).
        """

    @abstractmethod
    def delete_event(self, event_id: str) -> None:
        """Permanently delete the event identified by *event_id*."""

    # ── Health check ──────────────────────────────────────────────────────────

    @abstractmethod
    def health_check(self) -> bool:
        """Return True iff the provider can authenticate and reach its API.

        This should perform the lightest possible API call (e.g., fetching the
        primary calendar metadata) rather than a full free/busy query.
        """

    # ── Optional hook ─────────────────────────────────────────────────────────

    def get_video_link_from_response(self, response: dict) -> str | None:
        """Extract a video conferencing join URL from a raw provider response.

        The default implementation returns None.  Subclasses should override
        this to pull out the conference link embedded in the create-event
        response body so the booking engine can surface it to callers.
        """
        return None
