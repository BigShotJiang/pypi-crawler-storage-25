"""
Google Calendar API adapter.

Authentication
--------------
OAuth 2.0 tokens are managed via a two-layer secure storage scheme:
  - The refresh token is AES-256-GCM encrypted, stored in the OS keyring.
  - The encryption key lives in an ACL-locked macOS Keychain item (or a
    DPAPI-protected blob on Windows), so only this process can decrypt it.
  - The access token is held in memory only and is never written to disk.

Scopes
------
  Primary account (is_primary=True):
    calendar.events   — create, update, delete events
    calendar.readonly — read own calendar / free-busy

  Shadow account (is_primary=False):
    calendar.freebusy — free/busy queries only; cannot read event details

Free/busy
---------
Uses the Calendar v3 freebusy.query endpoint.

Mailbox settings
----------------
Google Calendar does not expose a working-hours API.  The timezone is fetched
from the primary calendar metadata; working hours fall back to global config
defaults.  Shadow accounts skip the timezone fetch (freebusy scope is enough).

Events
------
Events are created on the primary calendar.  When generate_video_link is True
a Google Meet link is requested via the conferenceData.createRequest field.
"""

from __future__ import annotations

import logging
import time
from datetime import datetime
from typing import Any, Optional

import httpx
from google.auth.exceptions import RefreshError
from google.auth.transport.requests import Request
from google.oauth2.credentials import Credentials as OAuth2Credentials

from src.providers.base import CalendarProvider
from src.scheduling.models import BusyInterval, EventPayload, MailboxSettings
from src.scheduling.timezone_utils import UTC
from src.token_storage import (
    delete_google_refresh_token,
    load_google_refresh_token,
    store_google_refresh_token,
)

logger = logging.getLogger(__name__)

GOOGLE_CALENDAR_BASE = "https://www.googleapis.com/calendar/v3"
TOKEN_REFRESH_RETRIES = 3
TOKEN_REFRESH_BACKOFF_BASE = 1.0

# Bundled OAuth client — registered as a Desktop app on Google Cloud Console.
# The client secret is not sensitive for installed-app flows (see Google OAuth
# docs for native apps — it cannot be kept secret in distributed software).
_BUNDLED_CLIENT_ID = "1032254018339-gpij6n7l0tald9b6vud1q2f2losnuvgj.apps.googleusercontent.com"
_BUNDLED_CLIENT_SECRET = "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"

# Scopes by account role.
_SCOPES_PRIMARY = [
    "https://www.googleapis.com/auth/calendar.events",
    "https://www.googleapis.com/auth/calendar.readonly",
]
_SCOPES_SHADOW = [
    "https://www.googleapis.com/auth/calendar.freebusy",
]


class GoogleCalendarProvider(CalendarProvider):
    """Google Calendar adapter backed by the Calendar REST v3 API."""

    def __init__(
        self,
        email: str,
        is_primary: bool = True,
        default_working_hours_start: str = "09:00",
        default_working_hours_end: str = "17:00",
        default_working_days: Optional[list[str]] = None,
        client_id: str = "",
        client_secret: str = "",
    ) -> None:
        self.email = email
        self.is_primary = is_primary
        self.default_working_hours_start = default_working_hours_start
        self.default_working_hours_end = default_working_hours_end
        self.default_working_days = default_working_days or [
            "Monday", "Tuesday", "Wednesday", "Thursday", "Friday"
        ]
        self.client_id = client_id or _BUNDLED_CLIENT_ID
        self.client_secret = client_secret or _BUNDLED_CLIENT_SECRET
        self._scopes = _SCOPES_PRIMARY if is_primary else _SCOPES_SHADOW
        # Access token held in memory only — never persisted.
        self._credentials: Optional[OAuth2Credentials] = None

    # ── Token management ──────────────────────────────────────────────────────

    def _load_credentials(self) -> OAuth2Credentials:
        """Build OAuth2Credentials from the securely stored refresh token."""
        refresh_token = load_google_refresh_token(self.email)
        if not refresh_token:
            raise RuntimeError(
                f"No credentials found for {self.email}. "
                "Run the OAuth flow to authorise this account."
            )
        return OAuth2Credentials(
            token=None,  # fetched on first API call via refresh
            refresh_token=refresh_token,
            token_uri="https://oauth2.googleapis.com/token",
            client_id=self.client_id,
            client_secret=self.client_secret,
            scopes=self._scopes,
        )

    def _save_refresh_token(self, creds: OAuth2Credentials) -> None:
        """Persist the refresh token if it has been rotated by Google."""
        if creds.refresh_token:
            store_google_refresh_token(self.email, creds.refresh_token)

    def _get_valid_credentials(self) -> OAuth2Credentials:
        """Return valid credentials, refreshing the access token if necessary."""
        if self._credentials is None:
            self._credentials = self._load_credentials()

        creds = self._credentials
        if creds.valid:
            return creds

        last_exc: Exception = RuntimeError("Token refresh failed.")
        for attempt in range(TOKEN_REFRESH_RETRIES):
            try:
                creds.refresh(Request())
                # Persist a rotated refresh token if Google issued a new one.
                self._save_refresh_token(creds)
                self._credentials = creds
                logger.debug("Refreshed Google access token for %s.", self.email)
                return creds
            except RefreshError as exc:
                last_exc = exc
                wait = TOKEN_REFRESH_BACKOFF_BASE * (2 ** attempt)
                logger.warning(
                    "Token refresh attempt %d/%d failed for %s: %s. Retrying in %.1fs.",
                    attempt + 1, TOKEN_REFRESH_RETRIES, self.email, exc, wait,
                )
                time.sleep(wait)

        raise RuntimeError(
            f"Could not refresh Google OAuth token for {self.email} after "
            f"{TOKEN_REFRESH_RETRIES} attempts: {last_exc}"
        )

    def _auth_headers(self) -> dict[str, str]:
        creds = self._get_valid_credentials()
        return {"Authorization": f"Bearer {creds.token}"}

    # ── CalendarProvider interface ─────────────────────────────────────────────

    def get_free_busy(
        self,
        email: str,
        start: datetime,
        end: datetime,
    ) -> list[BusyInterval]:
        """Query the Google freebusy endpoint for *email* within [start, end)."""
        url = f"{GOOGLE_CALENDAR_BASE}/freeBusy"
        payload = {
            "timeMin": start.isoformat(),
            "timeMax": end.isoformat(),
            "items": [{"id": email}],
        }
        response = httpx.post(url, json=payload, headers=self._auth_headers(), timeout=20)
        if response.status_code != 200:
            raise RuntimeError(
                f"Google freebusy query failed for {email}: "
                f"HTTP {response.status_code} — {response.text[:200]}"
            )
        data = response.json()
        calendar_data = data.get("calendars", {}).get(email, {})
        errors = calendar_data.get("errors", [])
        if errors:
            logger.warning("Google freebusy returned errors for %s: %s", email, errors)
        intervals: list[BusyInterval] = []
        for item in calendar_data.get("busy", []):
            s = datetime.fromisoformat(item["start"]).astimezone(UTC)
            e = datetime.fromisoformat(item["end"]).astimezone(UTC)
            intervals.append(BusyInterval(start=s, end=e))
        return intervals

    def get_mailbox_settings(self, email: str) -> MailboxSettings:
        """Fetch the primary calendar timezone; return config defaults for hours.

        Shadow accounts use the freebusy scope which does not cover the
        /calendars/primary endpoint, so we return defaults immediately.
        """
        if not self.is_primary:
            return MailboxSettings(
                timezone="UTC",
                working_hours_start=self.default_working_hours_start,
                working_hours_end=self.default_working_hours_end,
                working_days=self.default_working_days,
            )
        url = f"{GOOGLE_CALENDAR_BASE}/calendars/primary"
        response = httpx.get(url, headers=self._auth_headers(), timeout=15)
        if response.status_code != 200:
            raise RuntimeError(
                f"Could not fetch Google calendar metadata for {email}: "
                f"HTTP {response.status_code}"
            )
        iana_tz = response.json().get("timeZone", "UTC")
        return MailboxSettings(
            timezone=iana_tz,
            working_hours_start=self.default_working_hours_start,
            working_hours_end=self.default_working_hours_end,
            working_days=self.default_working_days,
        )

    def create_event(self, event: EventPayload) -> str:
        """Create a Calendar event and return the event ID."""
        import uuid

        url = f"{GOOGLE_CALENDAR_BASE}/calendars/primary/events"
        params: dict[str, Any] = {}
        body: dict[str, Any] = {
            "summary": event.title,
            "description": event.description,
            "start": {"dateTime": event.start.isoformat(), "timeZone": event.timezone},
            "end": {"dateTime": event.end.isoformat(), "timeZone": event.timezone},
            "attendees": [{"email": e} for e in event.participant_emails],
            "organizer": {"email": event.organiser_email},
        }
        if event.generate_video_link and event.video_provider in ("auto", "google_meet"):
            params["conferenceDataVersion"] = "1"
            body["conferenceData"] = {
                "createRequest": {
                    "requestId": str(uuid.uuid4()),
                    "conferenceSolutionKey": {"type": "hangoutsMeet"},
                }
            }

        response = httpx.post(
            url, json=body, params=params, headers=self._auth_headers(), timeout=20
        )
        if response.status_code not in (200, 201):
            raise RuntimeError(
                f"Google create event failed: HTTP {response.status_code} — "
                f"{response.text[:300]}"
            )
        data = response.json()
        self._last_create_response = data
        return data["id"]

    def get_event(self, event_id: str) -> dict:
        """Fetch title, description, and attendees for an existing event."""
        url = f"{GOOGLE_CALENDAR_BASE}/calendars/primary/events/{event_id}"
        response = httpx.get(url, headers=self._auth_headers(), timeout=15)
        if response.status_code != 200:
            raise RuntimeError(
                f"Google get event {event_id} failed: HTTP {response.status_code}"
            )
        data = response.json()
        participants = [
            a["email"] for a in data.get("attendees", [])
            if a.get("email") and a.get("email") != self.email
        ]
        return {
            "title": data.get("summary", ""),
            "description": data.get("description", ""),
            "participants": participants,
        }

    def update_event(self, event_id: str, event: EventPayload) -> None:
        """Replace a Google Calendar event (PUT semantics)."""
        url = f"{GOOGLE_CALENDAR_BASE}/calendars/primary/events/{event_id}"
        body: dict[str, Any] = {
            "summary": event.title,
            "description": event.description,
            "start": {"dateTime": event.start.isoformat(), "timeZone": event.timezone},
            "end": {"dateTime": event.end.isoformat(), "timeZone": event.timezone},
            "attendees": [{"email": e} for e in event.participant_emails],
        }
        response = httpx.put(url, json=body, headers=self._auth_headers(), timeout=20)
        if response.status_code not in (200, 204):
            raise RuntimeError(
                f"Google update event {event_id} failed: HTTP {response.status_code}"
            )

    def delete_event(self, event_id: str) -> None:
        """Delete a Google Calendar event."""
        url = f"{GOOGLE_CALENDAR_BASE}/calendars/primary/events/{event_id}"
        response = httpx.delete(url, headers=self._auth_headers(), timeout=15)
        if response.status_code not in (200, 204):
            raise RuntimeError(
                f"Google delete event {event_id} failed: HTTP {response.status_code}"
            )

    def health_check(self) -> bool:
        """Verify the token is valid by fetching the primary calendar metadata."""
        try:
            url = f"{GOOGLE_CALENDAR_BASE}/calendars/primary"
            response = httpx.get(url, headers=self._auth_headers(), timeout=10)
            return response.status_code == 200
        except Exception as exc:
            logger.warning("Google health check failed for %s: %s", self.email, exc)
            return False

    def authenticate(self) -> None:
        """Run the interactive OAuth flow and persist the refresh token.

        Opens a browser window for the user to authorise this account.
        Stores the resulting refresh token in secure storage so subsequent
        MCP tool calls can obtain access tokens silently.
        """
        from google_auth_oauthlib.flow import InstalledAppFlow

        client_config = {
            "installed": {
                "client_id": self.client_id,
                "client_secret": self.client_secret,
                "auth_uri": "https://accounts.google.com/o/oauth2/auth",
                "token_uri": "https://oauth2.googleapis.com/token",
                "redirect_uris": ["http://localhost"],
            }
        }
        flow = InstalledAppFlow.from_client_config(client_config, scopes=self._scopes)
        creds = flow.run_local_server(port=0, access_type="offline", prompt="consent")
        store_google_refresh_token(self.email, creds.refresh_token)
        self._credentials = creds
        logger.info("Google OAuth complete for %s.", self.email)

    def get_video_link_from_response(self, response: dict) -> str | None:
        """Extract the Google Meet join URL from a create-event response."""
        conf = response.get("conferenceData", {})
        for entry in conf.get("entryPoints", []):
            if entry.get("entryPointType") == "video":
                return entry.get("uri")
        return None
