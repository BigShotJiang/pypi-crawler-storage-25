"""
Meeting Scheduler MCP Server
=============================

Entry point for the MCP server.  Uses FastMCP (from the `mcp` package) to
expose calendar-scheduling tools to any MCP-compatible client (Claude Desktop,
Cursor, etc.).

Configuration is read from (in priority order):
  1. The path in the MEETING_SCHEDULER_CONFIG environment variable.
  2. ~/.config/meeting-scheduler/config.toml

Tools exposed
-------------
  find_available_slots  — query free/busy and return ranked meeting slots.
  book_meeting          — create a calendar event at a chosen slot.
  reschedule_meeting    — move an existing event to a new time.
  cancel_meeting        — delete an existing event.
  list_accounts         — show configured accounts with role and status.
  health_check          — test authentication for every account.
"""

from __future__ import annotations

import logging
import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Optional

from mcp.server.fastmcp import FastMCP

from src.account_manager import AppConfig, build_provider_map, load_config
from src.booking.engine import (
    book_meeting as _book_meeting,
    cancel_meeting as _cancel_meeting,
    reschedule_meeting as _reschedule_meeting,
)
from src.scheduling.engine import NoSlotsFound, ParticipantDomainNotConfigured, find_slots
from src.scheduling.models import Slot
from src.scheduling.timezone_utils import UTC, parse_iso, utc_now

# ── Logging setup ─────────────────────────────────────────────────────────────

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    stream=sys.stderr,
)
logger = logging.getLogger("meeting_scheduler.mcp")

# ── Application state ─────────────────────────────────────────────────────────

# Config and provider map are loaded lazily on first tool call and cached.
_config: Optional[AppConfig] = None
_provider_map: Optional[dict] = None


def _get_config() -> AppConfig:
    global _config
    if _config is None:
        _config = load_config()
    return _config


def _get_provider_map() -> dict:
    global _provider_map
    if _provider_map is None:
        _provider_map = build_provider_map(_get_config())
    return _provider_map


def _reset_state() -> None:
    """Force a reload of config and providers on the next tool call.

    Useful in tests or when the config file changes at runtime.
    """
    global _config, _provider_map
    _config = None
    _provider_map = None


# ── MCP server instance ───────────────────────────────────────────────────────

mcp = FastMCP("meeting-scheduler")


# ── Tool definitions ─────────────────────────────────────────────────────────


@mcp.tool()
def find_available_slots(
    participants: list[str],
    duration_minutes: int,
    window_start: str,
    window_end: str,
) -> dict:
    """Find available meeting slots for the user and all participants.

    Queries free/busy from the primary calendar (for the organiser) and from
    the appropriate shadow account for each participant, then returns a ranked
    list of slots that fit within everyone's working hours.

    Parameters
    ----------
    participants:
        Email addresses of the meeting attendees (not the organiser).
    duration_minutes:
        Desired meeting length in minutes.
    window_start:
        ISO 8601 UTC datetime string — start of the search window.
        Example: "2024-06-10T00:00:00Z"
    window_end:
        ISO 8601 UTC datetime string — end of the search window.
        Example: "2024-06-20T23:59:59Z"

    Returns
    -------
    dict
        On success:
          {
            "status": "ok",
            "slots": [
              {
                "slot_index": 1,
                "start_utc": "...",
                "end_utc": "...",
                "duration_minutes": 30,
                "participants_local": { "email": "2:00 PM EST (Tue, 10 Jun)", ... }
              },
              ...
            ]
          }
        On error:
          {"status": "error", "error_type": "...", "message": "..."}
    """
    try:
        config = _get_config()
        provider_map = _get_provider_map()

        win_start = parse_iso(window_start)
        win_end = parse_iso(window_end)

        slots = find_slots(
            primary_account=config.primary_account,
            shadow_accounts=config.shadow_accounts,
            provider_map=provider_map,
            participants=participants,
            duration_minutes=duration_minutes,
            window_start=win_start,
            window_end=win_end,
            rules=config.rules.as_dict(),
        )

        return {
            "status": "ok",
            "slots": [
                {
                    "slot_index": i + 1,
                    "start_utc": s.start.isoformat(),
                    "end_utc": s.end.isoformat(),
                    "duration_minutes": s.duration_minutes(),
                    "participants_local": s.participants_local,
                }
                for i, s in enumerate(slots)
            ],
        }

    except ParticipantDomainNotConfigured as exc:
        return {
            "status": "error",
            "error_type": "PARTICIPANT_DOMAIN_NOT_CONFIGURED",
            "message": str(exc),
        }
    except NoSlotsFound as exc:
        return {
            "status": "error",
            "error_type": f"NO_SLOTS_FOUND_{exc.reason}",
            "message": str(exc),
        }
    except FileNotFoundError as exc:
        return {
            "status": "error",
            "error_type": "CONFIG_NOT_FOUND",
            "message": str(exc),
        }
    except Exception as exc:
        logger.exception("Unexpected error in find_available_slots.")
        return {
            "status": "error",
            "error_type": "INTERNAL_ERROR",
            "message": f"An unexpected error occurred: {exc}",
        }


@mcp.tool()
def book_meeting(
    slot_start: str,
    slot_end: str,
    title: str,
    participants: list[str],
    description: str = "",
) -> dict:
    """Book a meeting at the given slot.

    Creates a calendar event on the primary account's calendar, invites all
    participants, and (where supported) attaches a video conferencing link.

    Parameters
    ----------
    slot_start:
        ISO 8601 UTC datetime string for the meeting start.
    slot_end:
        ISO 8601 UTC datetime string for the meeting end.
    title:
        Event title / subject shown in all calendars.
    participants:
        Email addresses of attendees (not the organiser).
    description:
        Optional agenda or notes to include in the event body.

    Returns
    -------
    dict
        On success:
          {
            "status": "ok",
            "event_id": "...",
            "title": "...",
            "start_utc": "...",
            "end_utc": "...",
            "participants": [...],
            "video_link": "https://..." | null,
            "organiser": "..."
          }
        On error:
          {"status": "error", "error_type": "...", "message": "..."}
    """
    try:
        config = _get_config()
        provider_map = _get_provider_map()

        start_dt = parse_iso(slot_start)
        end_dt = parse_iso(slot_end)

        primary = config.primary_account
        primary_provider = provider_map[primary.email]

        # Resolve organiser timezone from mailbox settings if available.
        try:
            organiser_tz = primary_provider.get_mailbox_settings(primary.email).timezone
        except Exception:
            organiser_tz = "UTC"

        slot = Slot(start=start_dt, end=end_dt)

        result = _book_meeting(
            slot=slot,
            title=title,
            participants=participants,
            organiser_email=primary.email,
            primary_provider=primary_provider,
            description=description,
            organiser_timezone=organiser_tz,
        )

        return {"status": "ok", **result}

    except FileNotFoundError as exc:
        return {"status": "error", "error_type": "CONFIG_NOT_FOUND", "message": str(exc)}
    except RuntimeError as exc:
        return {"status": "error", "error_type": "BOOKING_FAILED", "message": str(exc)}
    except Exception as exc:
        logger.exception("Unexpected error in book_meeting.")
        return {
            "status": "error",
            "error_type": "INTERNAL_ERROR",
            "message": f"An unexpected error occurred: {exc}",
        }


@mcp.tool()
def reschedule_meeting(
    event_id: str,
    new_slot_start: str,
    new_slot_end: str,
) -> dict:
    """Reschedule an existing meeting to a new time.

    Updates the calendar event in-place on the primary calendar.  The title,
    participants, and description are preserved from the original event.

    Parameters
    ----------
    event_id:
        The provider-assigned event identifier returned by book_meeting.
    new_slot_start:
        ISO 8601 UTC datetime string for the new start time.
    new_slot_end:
        ISO 8601 UTC datetime string for the new end time.

    Returns
    -------
    dict
        On success: same structure as book_meeting (with the same event_id).
        On error:   {"status": "error", "error_type": "...", "message": "..."}
    """
    try:
        config = _get_config()
        provider_map = _get_provider_map()

        start_dt = parse_iso(new_slot_start)
        end_dt = parse_iso(new_slot_end)

        primary = config.primary_account
        primary_provider = provider_map[primary.email]

        try:
            organiser_tz = primary_provider.get_mailbox_settings(primary.email).timezone
        except Exception:
            organiser_tz = "UTC"

        # Fetch the existing event so title, description, and participants
        # are preserved — the caller only provides the new time.
        try:
            existing = primary_provider.get_event(event_id)
        except Exception as exc:
            raise RuntimeError(
                f"Could not fetch event '{event_id}' to reschedule: {exc}"
            ) from exc

        new_slot = Slot(start=start_dt, end=end_dt)

        result = _reschedule_meeting(
            event_id=event_id,
            new_slot=new_slot,
            title=existing["title"],
            participants=existing["participants"],
            organiser_email=primary.email,
            primary_provider=primary_provider,
            description=existing.get("description", ""),
            organiser_timezone=organiser_tz,
        )

        return {"status": "ok", **result}

    except FileNotFoundError as exc:
        return {"status": "error", "error_type": "CONFIG_NOT_FOUND", "message": str(exc)}
    except RuntimeError as exc:
        return {"status": "error", "error_type": "RESCHEDULE_FAILED", "message": str(exc)}
    except Exception as exc:
        logger.exception("Unexpected error in reschedule_meeting.")
        return {
            "status": "error",
            "error_type": "INTERNAL_ERROR",
            "message": f"An unexpected error occurred: {exc}",
        }


@mcp.tool()
def cancel_meeting(event_id: str) -> dict:
    """Cancel an existing meeting.

    Deletes the event from the primary calendar.  Note: this does not
    automatically send cancellation notices on all providers; behaviour
    depends on the calendar service.

    Parameters
    ----------
    event_id:
        The provider-assigned event identifier returned by book_meeting.

    Returns
    -------
    dict
        On success: {"status": "ok", "message": "Event <event_id> cancelled."}
        On error:   {"status": "error", "error_type": "...", "message": "..."}
    """
    try:
        config = _get_config()
        provider_map = _get_provider_map()

        primary = config.primary_account
        primary_provider = provider_map[primary.email]

        _cancel_meeting(event_id=event_id, primary_provider=primary_provider)

        return {
            "status": "ok",
            "message": f"Event '{event_id}' has been cancelled.",
        }

    except FileNotFoundError as exc:
        return {"status": "error", "error_type": "CONFIG_NOT_FOUND", "message": str(exc)}
    except RuntimeError as exc:
        return {"status": "error", "error_type": "CANCEL_FAILED", "message": str(exc)}
    except Exception as exc:
        logger.exception("Unexpected error in cancel_meeting.")
        return {
            "status": "error",
            "error_type": "INTERNAL_ERROR",
            "message": f"An unexpected error occurred: {exc}",
        }


@mcp.tool()
def list_accounts() -> dict:
    """List all configured accounts with their role and connection status.

    Returns
    -------
    dict
        {
          "status": "ok",
          "accounts": [
            {
              "email": "...",
              "org": "...",
              "provider": "google" | "microsoft",
              "role": "primary" | "shadow",
              "connected": true | false
            },
            ...
          ]
        }
    """
    try:
        config = _get_config()
        provider_map = _get_provider_map()

        accounts_out = []
        for account in config.accounts:
            provider = provider_map.get(account.email)
            connected: bool = False
            if provider:
                try:
                    connected = provider.health_check()
                except Exception:
                    connected = False

            accounts_out.append(
                {
                    "email": account.email,
                    "org": account.org,
                    "provider": account.provider,
                    "role": "primary" if account.is_primary else "shadow",
                    "connected": connected,
                }
            )

        return {"status": "ok", "accounts": accounts_out}

    except FileNotFoundError as exc:
        return {"status": "error", "error_type": "CONFIG_NOT_FOUND", "message": str(exc)}
    except Exception as exc:
        logger.exception("Unexpected error in list_accounts.")
        return {
            "status": "error",
            "error_type": "INTERNAL_ERROR",
            "message": f"An unexpected error occurred: {exc}",
        }


@mcp.tool()
def health_check() -> dict:
    """Verify all configured accounts can authenticate successfully.

    Performs a lightweight API call for each account and reports which are
    healthy and which are failing.

    Returns
    -------
    dict
        {
          "status": "ok" | "degraded" | "error",
          "accounts": [
            {"email": "...", "provider": "...", "healthy": true | false},
            ...
          ],
          "message": "All accounts healthy." | "Some accounts failed: ..."
        }
    """
    try:
        config = _get_config()
        provider_map = _get_provider_map()

        results = []
        failures = []
        for account in config.accounts:
            provider = provider_map.get(account.email)
            healthy = False
            if provider:
                try:
                    healthy = provider.health_check()
                except Exception as exc:
                    logger.warning("Health check error for %s: %s", account.email, exc)
                    healthy = False
            if not healthy:
                failures.append(account.email)
            results.append(
                {
                    "email": account.email,
                    "provider": account.provider,
                    "healthy": healthy,
                }
            )

        if not failures:
            overall = "ok"
            message = "All accounts are healthy."
        else:
            overall = "degraded"
            message = f"The following accounts could not authenticate: {', '.join(failures)}."

        return {"status": overall, "accounts": results, "message": message}

    except FileNotFoundError as exc:
        return {"status": "error", "error_type": "CONFIG_NOT_FOUND", "message": str(exc)}
    except Exception as exc:
        logger.exception("Unexpected error in health_check.")
        return {
            "status": "error",
            "error_type": "INTERNAL_ERROR",
            "message": f"An unexpected error occurred: {exc}",
        }


# ── Entry point ───────────────────────────────────────────────────────────────


def main() -> None:
    """Entry point — dispatches to the CLI wizard or starts the MCP server.

    Usage
    -----
      meeting-scheduler-mcp setup          — first-time setup wizard
      meeting-scheduler-mcp auth <email>   — re-authenticate one account
      meeting-scheduler-mcp status         — print health of all accounts
      meeting-scheduler-mcp                — start the MCP server (default)
    """
    import sys
    from src.cli import run_auth, run_setup_wizard, run_status

    args = sys.argv[1:]

    if not args:
        mcp.run()
        return

    command = args[0].lower()

    if command == "setup":
        run_setup_wizard()
    elif command == "auth":
        if len(args) < 2:
            print("Usage: meeting-scheduler auth <email>")
            sys.exit(1)
        run_auth(args[1])
    elif command == "status":
        run_status()
    else:
        print(f"Unknown command '{command}'.")
        print("Commands: setup | auth <email> | status")
        print("Run without arguments to start the MCP server.")
        sys.exit(1)


if __name__ == "__main__":
    main()
