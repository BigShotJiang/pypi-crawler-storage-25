"""
Unit tests for src/cli.py.

Interactive prompts are replaced with canned inputs via monkeypatching.
Provider calls are replaced with MagicMocks — no real OAuth or HTTP.

Coverage
--------
  _build_toml           one account, core fields present
  _build_toml           two accounts (primary + shadow)
  _build_toml           rules section always present
  _build_toml           no client_id or client_secret written (bundled credentials)
  run_status            all healthy: prints OK, exits 0
  run_status            some failing: prints FAILED, exits 0 (non-fatal)
  run_status            no config: prints message, exits 1
  run_auth              known email: calls authenticate()
  run_auth              unknown email: exits 1
  run_auth              authenticate fails: exits 1
"""

from __future__ import annotations

import sys
from unittest.mock import MagicMock, call, patch

import pytest

from src.cli import _build_toml, run_auth, run_status


# ── _build_toml ───────────────────────────────────────────────────────────────


class TestBuildToml:
    def _google_acc(self, primary: bool = True) -> dict:
        return {
            "org": "Acme",
            "email": "me@acme.com",
            "provider": "google",
            "is_primary": primary,
        }

    def _ms_acc(self, primary: bool = False) -> dict:
        return {
            "org": "Partner",
            "email": "me@partner.com",
            "provider": "microsoft",
            "is_primary": primary,
        }

    def test_contains_account_fields(self) -> None:
        toml = _build_toml([self._google_acc()])
        assert 'org = "Acme"' in toml
        assert 'email = "me@acme.com"' in toml
        assert 'provider = "google"' in toml
        assert "is_primary = true" in toml

    def test_no_client_credentials_written(self) -> None:
        toml = _build_toml([self._google_acc(), self._ms_acc()])
        assert "client_id" not in toml
        assert "client_secret" not in toml

    def test_multiple_accounts_both_present(self) -> None:
        toml = _build_toml([self._google_acc(primary=True), self._ms_acc(primary=False)])
        assert toml.count("[[accounts]]") == 2
        assert "me@acme.com" in toml
        assert "me@partner.com" in toml

    def test_rules_section_always_present(self) -> None:
        toml = _build_toml([self._google_acc()])
        assert "[rules]" in toml
        assert "default_duration_minutes" in toml
        assert "working_days" in toml

    def test_shadow_account_is_primary_false(self) -> None:
        toml = _build_toml([self._ms_acc(primary=False)])
        assert "is_primary = false" in toml


# ── run_status ────────────────────────────────────────────────────────────────


def _make_account(email: str, provider: str, primary: bool):
    from src.account_manager import AccountConfig
    return AccountConfig(
        org="Org", email=email, provider=provider, is_primary=primary
    )


def _make_config(accounts):
    from src.account_manager import AppConfig, SchedulingRules
    return AppConfig(accounts=accounts, rules=SchedulingRules())


class TestRunStatus:
    def test_all_healthy_prints_ok(self, capsys) -> None:
        accounts = [_make_account("a@a.com", "google", True)]
        config = _make_config(accounts)

        healthy_provider = MagicMock()
        healthy_provider.health_check.return_value = True

        with patch("src.account_manager.load_config", return_value=config), \
             patch("src.account_manager.build_provider", return_value=healthy_provider):
            run_status()

        out = capsys.readouterr().out
        assert "OK" in out
        assert "All accounts are healthy" in out

    def test_failing_account_prints_failed(self, capsys) -> None:
        accounts = [_make_account("b@b.com", "microsoft", False)]
        config = _make_config(accounts)

        failing_provider = MagicMock()
        failing_provider.health_check.return_value = False

        with patch("src.account_manager.load_config", return_value=config), \
             patch("src.account_manager.build_provider", return_value=failing_provider):
            run_status()

        out = capsys.readouterr().out
        assert "FAILED" in out
        assert "Some accounts failed" in out

    def test_mixed_health_shows_both(self, capsys) -> None:
        accounts = [
            _make_account("ok@a.com", "google", True),
            _make_account("bad@b.com", "microsoft", False),
        ]
        config = _make_config(accounts)

        good = MagicMock()
        good.health_check.return_value = True
        bad = MagicMock()
        bad.health_check.return_value = False

        with patch("src.account_manager.load_config", return_value=config), \
             patch("src.account_manager.build_provider", side_effect=[good, bad]):
            run_status()

        out = capsys.readouterr().out
        assert "OK" in out
        assert "FAILED" in out

    def test_no_config_exits_1(self) -> None:
        with patch("src.account_manager.load_config", side_effect=FileNotFoundError("no config")):
            with pytest.raises(SystemExit) as exc_info:
                run_status()
        assert exc_info.value.code == 1

    def test_health_check_exception_treated_as_failed(self, capsys) -> None:
        accounts = [_make_account("err@a.com", "google", True)]
        config = _make_config(accounts)

        boom_provider = MagicMock()
        boom_provider.health_check.side_effect = RuntimeError("crash")

        with patch("src.account_manager.load_config", return_value=config), \
             patch("src.account_manager.build_provider", return_value=boom_provider):
            run_status()

        out = capsys.readouterr().out
        assert "FAILED" in out


# ── run_auth ──────────────────────────────────────────────────────────────────


class TestRunAuth:
    def _config_with(self, email: str):
        accounts = [_make_account(email, "google", True)]
        return _make_config(accounts)

    def test_calls_authenticate_on_found_account(self, capsys) -> None:
        config = self._config_with("user@example.com")
        provider = MagicMock()

        with patch("src.account_manager.load_config", return_value=config), \
             patch("src.account_manager.build_provider", return_value=provider):
            run_auth("user@example.com")

        provider.authenticate.assert_called_once()

    def test_email_lookup_is_case_insensitive(self, capsys) -> None:
        config = self._config_with("user@example.com")
        provider = MagicMock()

        with patch("src.account_manager.load_config", return_value=config), \
             patch("src.account_manager.build_provider", return_value=provider):
            run_auth("USER@EXAMPLE.COM")

        provider.authenticate.assert_called_once()

    def test_unknown_email_exits_1(self) -> None:
        config = self._config_with("user@example.com")

        with patch("src.account_manager.load_config", return_value=config):
            with pytest.raises(SystemExit) as exc_info:
                run_auth("nobody@nowhere.com")

        assert exc_info.value.code == 1

    def test_authenticate_failure_exits_1(self) -> None:
        config = self._config_with("user@example.com")
        provider = MagicMock()
        provider.authenticate.side_effect = RuntimeError("Browser closed")

        with patch("src.account_manager.load_config", return_value=config), \
             patch("src.account_manager.build_provider", return_value=provider):
            with pytest.raises(SystemExit) as exc_info:
                run_auth("user@example.com")

        assert exc_info.value.code == 1
