"""
Unit tests for src/providers/google.py (GoogleCalendarProvider).

All HTTP calls are intercepted with httpx mock transports — no real
network traffic is made.  Token storage is replaced with an in-memory
dict so the OS keychain is never touched.

Coverage
--------
  _load_credentials         raises when no token stored
  _load_credentials         builds correct Credentials object
  _save_refresh_token       persists a rotated token
  _get_valid_credentials    returns cached creds when still valid
  _get_valid_credentials    refreshes expired creds
  _get_valid_credentials    raises after max retries
  authenticate              stores token returned by flow
  get_free_busy             parses busy intervals from API response
  get_free_busy             raises on non-200
  get_mailbox_settings      returns defaults for shadow accounts
  get_mailbox_settings      fetches timezone for primary accounts
  get_mailbox_settings      raises on non-200
  create_event              posts correct body, returns event ID
  create_event              includes conference data when video link requested
  create_event              raises on non-200
  update_event              sends PUT with correct body
  update_event              raises on non-200
  delete_event              sends DELETE, succeeds on 204
  delete_event              raises on non-200
  health_check              returns True on 200
  health_check              returns False on 403 / network error
  get_video_link_from_response  extracts Meet URL
  get_video_link_from_response  returns None when absent
"""

from __future__ import annotations

import base64
import json
from datetime import datetime, timezone
from typing import Optional
from unittest.mock import MagicMock, patch

import httpx
import pytest

UTC = timezone.utc

# ── Stub out token_storage so no real keychain is touched ─────────────────────

_TOKEN_STORE: dict[str, str] = {}


def _fake_load(email: str) -> Optional[str]:
    return _TOKEN_STORE.get(email)


def _fake_store(email: str, token: str) -> None:
    _TOKEN_STORE[email] = token


def _fake_delete(email: str) -> None:
    _TOKEN_STORE.pop(email, None)


@pytest.fixture(autouse=True)
def _patch_token_storage(monkeypatch):
    _TOKEN_STORE.clear()
    monkeypatch.setattr("src.providers.google.load_google_refresh_token", _fake_load)
    monkeypatch.setattr("src.providers.google.store_google_refresh_token", _fake_store)
    monkeypatch.setattr("src.providers.google.delete_google_refresh_token", _fake_delete)


from src.providers.google import GoogleCalendarProvider  # noqa: E402


# ── Factories ─────────────────────────────────────────────────────────────────


def _primary(**kwargs) -> GoogleCalendarProvider:
    defaults = dict(
        email="org@primary.com",
        is_primary=True,
        client_id="cid",
        client_secret="csec",
    )
    defaults.update(kwargs)
    return GoogleCalendarProvider(**defaults)


def _shadow(**kwargs) -> GoogleCalendarProvider:
    defaults = dict(
        email="shadow@company.com",
        is_primary=False,
        client_id="cid",
        client_secret="csec",
    )
    defaults.update(kwargs)
    return GoogleCalendarProvider(**defaults)


def _dt(hour: int) -> datetime:
    return datetime(2024, 6, 10, hour, 0, tzinfo=UTC)


# ── _load_credentials ─────────────────────────────────────────────────────────


class TestLoadCredentials:
    def test_raises_when_no_token(self) -> None:
        p = _primary()
        with pytest.raises(RuntimeError, match="No credentials found"):
            p._load_credentials()

    def test_builds_credentials_from_stored_token(self) -> None:
        _TOKEN_STORE["org@primary.com"] = "my_refresh_token"
        p = _primary()
        creds = p._load_credentials()
        assert creds.refresh_token == "my_refresh_token"
        assert creds.client_id == "cid"
        assert creds.client_secret == "csec"

    def test_uses_correct_scopes_for_primary(self) -> None:
        _TOKEN_STORE["org@primary.com"] = "tok"
        p = _primary()
        creds = p._load_credentials()
        assert any("calendar.events" in s for s in creds.scopes)

    def test_uses_freebusy_scope_for_shadow(self) -> None:
        _TOKEN_STORE["shadow@company.com"] = "tok"
        s = _shadow()
        creds = s._load_credentials()
        assert any("freebusy" in s for s in creds.scopes)


# ── _save_refresh_token ───────────────────────────────────────────────────────


class TestSaveRefreshToken:
    def test_persists_rotated_token(self) -> None:
        _TOKEN_STORE["org@primary.com"] = "old"
        p = _primary()
        mock_creds = MagicMock()
        mock_creds.refresh_token = "new_token"
        p._save_refresh_token(mock_creds)
        assert _TOKEN_STORE["org@primary.com"] == "new_token"

    def test_skips_when_no_refresh_token(self) -> None:
        _TOKEN_STORE["org@primary.com"] = "original"
        p = _primary()
        mock_creds = MagicMock()
        mock_creds.refresh_token = None
        p._save_refresh_token(mock_creds)
        assert _TOKEN_STORE["org@primary.com"] == "original"


# ── _get_valid_credentials ────────────────────────────────────────────────────


class TestGetValidCredentials:
    def test_returns_cached_valid_creds(self) -> None:
        p = _primary()
        mock_creds = MagicMock()
        mock_creds.valid = True
        p._credentials = mock_creds
        result = p._get_valid_credentials()
        assert result is mock_creds

    def test_refreshes_expired_creds(self) -> None:
        _TOKEN_STORE["org@primary.com"] = "tok"
        p = _primary()
        mock_creds = MagicMock()
        mock_creds.valid = False
        mock_creds.refresh_token = "tok"
        p._credentials = mock_creds

        def fake_refresh(_):
            mock_creds.valid = True

        mock_creds.refresh.side_effect = fake_refresh
        result = p._get_valid_credentials()
        assert result.valid is True
        mock_creds.refresh.assert_called_once()

    def test_raises_after_max_retries(self) -> None:
        from google.auth.exceptions import RefreshError

        _TOKEN_STORE["org@primary.com"] = "tok"
        p = _primary()
        mock_creds = MagicMock()
        mock_creds.valid = False
        mock_creds.refresh_token = "tok"
        mock_creds.refresh.side_effect = RefreshError("expired")
        p._credentials = mock_creds

        with patch("src.providers.google.time.sleep"):
            with pytest.raises(RuntimeError, match="Could not refresh"):
                p._get_valid_credentials()


# ── authenticate ──────────────────────────────────────────────────────────────


class TestAuthenticate:
    def test_stores_refresh_token(self) -> None:
        p = _primary()
        mock_creds = MagicMock()
        mock_creds.refresh_token = "fresh_token"

        mock_flow = MagicMock()
        mock_flow.run_local_server.return_value = mock_creds

        with patch("google_auth_oauthlib.flow.InstalledAppFlow") as MockFlow:
            MockFlow.from_client_config.return_value = mock_flow
            p.authenticate()

        assert _TOKEN_STORE["org@primary.com"] == "fresh_token"
        assert p._credentials is mock_creds

    def test_uses_correct_scopes(self) -> None:
        p = _primary()
        mock_flow = MagicMock()
        mock_flow.run_local_server.return_value = MagicMock(refresh_token="t")

        with patch("google_auth_oauthlib.flow.InstalledAppFlow") as MockFlow:
            MockFlow.from_client_config.return_value = mock_flow
            p.authenticate()

        _, kwargs = MockFlow.from_client_config.call_args
        assert kwargs["scopes"] == p._scopes

    def test_authenticate_imports_flow_inside_method(self) -> None:
        """authenticate() lazy-imports InstalledAppFlow from google_auth_oauthlib."""
        p = _shadow()
        mock_flow = MagicMock()
        mock_flow.run_local_server.return_value = MagicMock(refresh_token="t")

        with patch("google_auth_oauthlib.flow.InstalledAppFlow") as MockFlow:
            MockFlow.from_client_config.return_value = mock_flow
            p.authenticate()

        MockFlow.from_client_config.assert_called_once()


# ── get_free_busy ─────────────────────────────────────────────────────────────


class TestGetFreeBusy:
    def _make_provider_with_token(self) -> GoogleCalendarProvider:
        _TOKEN_STORE["org@primary.com"] = "tok"
        p = _primary()
        mock_creds = MagicMock()
        mock_creds.valid = True
        mock_creds.token = "access_tok"
        p._credentials = mock_creds
        return p

    def test_parses_busy_intervals(self) -> None:
        p = self._make_provider_with_token()
        api_response = {
            "calendars": {
                "org@primary.com": {
                    "busy": [
                        {"start": "2024-06-10T09:00:00Z", "end": "2024-06-10T10:00:00Z"},
                        {"start": "2024-06-10T14:00:00Z", "end": "2024-06-10T15:00:00Z"},
                    ]
                }
            }
        }
        transport = httpx.MockTransport(
            lambda req: httpx.Response(200, json=api_response)
        )
        with patch.object(httpx, "post", side_effect=lambda *a, **k: httpx.post(
            *a, transport=transport, **{kk: vv for kk, vv in k.items() if kk != "headers"}
        )):
            pass  # use direct mock instead

        with patch("httpx.post") as mock_post:
            mock_post.return_value = httpx.Response(200, json=api_response)
            intervals = p.get_free_busy("org@primary.com", _dt(8), _dt(17))

        assert len(intervals) == 2
        assert intervals[0].start.hour == 9
        assert intervals[1].start.hour == 14

    def test_raises_on_non_200(self) -> None:
        p = self._make_provider_with_token()
        with patch("httpx.post") as mock_post:
            mock_post.return_value = httpx.Response(403, text="Forbidden")
            with pytest.raises(RuntimeError, match="freebusy query failed"):
                p.get_free_busy("org@primary.com", _dt(8), _dt(17))

    def test_returns_empty_when_no_busy(self) -> None:
        p = self._make_provider_with_token()
        api_response = {"calendars": {"org@primary.com": {"busy": []}}}
        with patch("httpx.post") as mock_post:
            mock_post.return_value = httpx.Response(200, json=api_response)
            intervals = p.get_free_busy("org@primary.com", _dt(8), _dt(17))
        assert intervals == []


# ── get_mailbox_settings ──────────────────────────────────────────────────────


class TestGetMailboxSettings:
    def test_shadow_returns_defaults_without_api_call(self) -> None:
        s = _shadow(
            default_working_hours_start="08:00",
            default_working_hours_end="18:00",
        )
        with patch("httpx.get") as mock_get:
            settings = s.get_mailbox_settings("shadow@company.com")
            mock_get.assert_not_called()
        assert settings.working_hours_start == "08:00"
        assert settings.working_hours_end == "18:00"
        assert settings.timezone == "UTC"

    def test_primary_fetches_timezone(self) -> None:
        _TOKEN_STORE["org@primary.com"] = "tok"
        p = _primary()
        mock_creds = MagicMock()
        mock_creds.valid = True
        mock_creds.token = "access_tok"
        p._credentials = mock_creds

        with patch("httpx.get") as mock_get:
            mock_get.return_value = httpx.Response(200, json={"timeZone": "America/New_York"})
            settings = p.get_mailbox_settings("org@primary.com")

        assert settings.timezone == "America/New_York"

    def test_primary_raises_on_non_200(self) -> None:
        _TOKEN_STORE["org@primary.com"] = "tok"
        p = _primary()
        mock_creds = MagicMock()
        mock_creds.valid = True
        mock_creds.token = "access_tok"
        p._credentials = mock_creds

        with patch("httpx.get") as mock_get:
            mock_get.return_value = httpx.Response(403)
            with pytest.raises(RuntimeError, match="calendar metadata"):
                p.get_mailbox_settings("org@primary.com")


# ── create_event ──────────────────────────────────────────────────────────────


class TestCreateEvent:
    def _provider(self) -> GoogleCalendarProvider:
        _TOKEN_STORE["org@primary.com"] = "tok"
        p = _primary()
        creds = MagicMock()
        creds.valid = True
        creds.token = "access_tok"
        p._credentials = creds
        return p

    def _payload(self):
        from src.scheduling.models import EventPayload
        return EventPayload(
            title="Team Sync",
            description="Agenda",
            start=_dt(10),
            end=_dt(11),
            organiser_email="org@primary.com",
            participant_emails=["a@a.com"],
            timezone="UTC",
            generate_video_link=False,
        )

    def test_returns_event_id(self) -> None:
        p = self._provider()
        with patch("httpx.post") as mock_post:
            mock_post.return_value = httpx.Response(201, json={"id": "evt123"})
            eid = p.create_event(self._payload())
        assert eid == "evt123"

    def test_raises_on_non_200(self) -> None:
        p = self._provider()
        with patch("httpx.post") as mock_post:
            mock_post.return_value = httpx.Response(409, text="Conflict")
            with pytest.raises(RuntimeError, match="create event failed"):
                p.create_event(self._payload())

    def test_includes_conference_data_when_video_requested(self) -> None:
        from src.scheduling.models import EventPayload
        p = self._provider()
        payload = EventPayload(
            title="Video Call",
            description="",
            start=_dt(10),
            end=_dt(11),
            organiser_email="org@primary.com",
            participant_emails=[],
            timezone="UTC",
            generate_video_link=True,
            video_provider="google_meet",
        )
        captured: list[dict] = []

        def fake_post(url, json=None, params=None, headers=None, timeout=None):
            captured.append(json or {})
            return httpx.Response(201, json={"id": "vid_evt"})

        with patch("httpx.post", side_effect=fake_post):
            p.create_event(payload)

        body = captured[0]
        assert "conferenceData" in body

    def test_no_conference_data_when_video_disabled(self) -> None:
        p = self._provider()
        captured: list[dict] = []

        def fake_post(url, json=None, params=None, headers=None, timeout=None):
            captured.append(json or {})
            return httpx.Response(201, json={"id": "no_vid"})

        with patch("httpx.post", side_effect=fake_post):
            p.create_event(self._payload())

        assert "conferenceData" not in captured[0]


# ── update_event ──────────────────────────────────────────────────────────────


class TestUpdateEvent:
    def _provider(self) -> GoogleCalendarProvider:
        _TOKEN_STORE["org@primary.com"] = "tok"
        p = _primary()
        creds = MagicMock()
        creds.valid = True
        creds.token = "access_tok"
        p._credentials = creds
        return p

    def _payload(self):
        from src.scheduling.models import EventPayload
        return EventPayload(
            title="Updated",
            description="",
            start=_dt(11),
            end=_dt(12),
            organiser_email="org@primary.com",
            participant_emails=["b@b.com"],
            timezone="UTC",
            generate_video_link=False,
        )

    def test_succeeds_on_200(self) -> None:
        p = self._provider()
        with patch("httpx.put") as mock_put:
            mock_put.return_value = httpx.Response(200, json={})
            p.update_event("evt123", self._payload())  # should not raise

    def test_raises_on_non_200(self) -> None:
        p = self._provider()
        with patch("httpx.put") as mock_put:
            mock_put.return_value = httpx.Response(404)
            with pytest.raises(RuntimeError, match="update event"):
                p.update_event("evt123", self._payload())


# ── get_event ─────────────────────────────────────────────────────────────────


class TestGetEvent:
    def _provider(self) -> GoogleCalendarProvider:
        _TOKEN_STORE["org@primary.com"] = "tok"
        p = _primary()
        creds = MagicMock()
        creds.valid = True
        creds.token = "access_tok"
        p._credentials = creds
        return p

    def test_returns_normalised_dict(self) -> None:
        p = self._provider()
        api_response = {
            "summary": "Project Sync",
            "description": "Agenda",
            "attendees": [
                {"email": "org@primary.com"},   # organiser — should be excluded
                {"email": "a@a.com"},
                {"email": "b@b.com"},
            ],
        }
        with patch("httpx.get") as mock_get:
            mock_get.return_value = httpx.Response(200, json=api_response)
            result = p.get_event("evt_abc")

        assert result["title"] == "Project Sync"
        assert result["description"] == "Agenda"
        assert "a@a.com" in result["participants"]
        assert "b@b.com" in result["participants"]
        assert "org@primary.com" not in result["participants"]

    def test_raises_on_non_200(self) -> None:
        p = self._provider()
        with patch("httpx.get") as mock_get:
            mock_get.return_value = httpx.Response(404)
            with pytest.raises(RuntimeError, match="get event"):
                p.get_event("missing_evt")

    def test_empty_attendees(self) -> None:
        p = self._provider()
        with patch("httpx.get") as mock_get:
            mock_get.return_value = httpx.Response(200, json={"summary": "Solo", "attendees": []})
            result = p.get_event("evt_solo")
        assert result["participants"] == []


# ── delete_event ──────────────────────────────────────────────────────────────


class TestDeleteEvent:
    def _provider(self) -> GoogleCalendarProvider:
        _TOKEN_STORE["org@primary.com"] = "tok"
        p = _primary()
        creds = MagicMock()
        creds.valid = True
        creds.token = "access_tok"
        p._credentials = creds
        return p

    def test_succeeds_on_204(self) -> None:
        p = self._provider()
        with patch("httpx.delete") as mock_del:
            mock_del.return_value = httpx.Response(204)
            p.delete_event("evt123")  # should not raise

    def test_raises_on_non_200(self) -> None:
        p = self._provider()
        with patch("httpx.delete") as mock_del:
            mock_del.return_value = httpx.Response(404)
            with pytest.raises(RuntimeError, match="delete event"):
                p.delete_event("evt123")


# ── health_check ──────────────────────────────────────────────────────────────


class TestHealthCheck:
    def _provider(self) -> GoogleCalendarProvider:
        _TOKEN_STORE["org@primary.com"] = "tok"
        p = _primary()
        creds = MagicMock()
        creds.valid = True
        creds.token = "access_tok"
        p._credentials = creds
        return p

    def test_returns_true_on_200(self) -> None:
        p = self._provider()
        with patch("httpx.get") as mock_get:
            mock_get.return_value = httpx.Response(200, json={"id": "primary"})
            assert p.health_check() is True

    def test_returns_false_on_403(self) -> None:
        p = self._provider()
        with patch("httpx.get") as mock_get:
            mock_get.return_value = httpx.Response(403)
            assert p.health_check() is False

    def test_returns_false_on_network_error(self) -> None:
        p = self._provider()
        with patch("httpx.get") as mock_get:
            mock_get.side_effect = httpx.ConnectError("timeout")
            assert p.health_check() is False


# ── get_video_link_from_response ──────────────────────────────────────────────


class TestGetVideoLinkFromResponse:
    def test_extracts_meet_url(self) -> None:
        p = _primary()
        response = {
            "conferenceData": {
                "entryPoints": [
                    {"entryPointType": "video", "uri": "https://meet.google.com/abc-def-ghi"},
                    {"entryPointType": "phone", "uri": "tel:+1234567890"},
                ]
            }
        }
        assert p.get_video_link_from_response(response) == "https://meet.google.com/abc-def-ghi"

    def test_returns_none_when_no_conference_data(self) -> None:
        p = _primary()
        assert p.get_video_link_from_response({}) is None

    def test_returns_none_when_no_video_entry_point(self) -> None:
        p = _primary()
        response = {"conferenceData": {"entryPoints": [{"entryPointType": "phone"}]}}
        assert p.get_video_link_from_response(response) is None
