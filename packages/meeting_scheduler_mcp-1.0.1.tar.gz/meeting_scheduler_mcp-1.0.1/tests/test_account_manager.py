"""
Unit tests for the account manager module.

Coverage:
  - Valid config loads successfully.
  - Zero primary accounts → ValueError.
  - Two primary accounts → ValueError.
  - Missing required field (org, email, provider) → ValueError.
  - Unsupported provider → ValueError.
  - Duplicate email addresses → ValueError.
  - Rules default values applied when [rules] section is absent.
  - Rules values correctly parsed from config.
  - build_provider returns the correct provider type for each provider string.
"""

from __future__ import annotations

import tempfile
from pathlib import Path
from unittest.mock import MagicMock

import pytest

from src.account_manager import (
    AccountConfig,
    SchedulingRules,
    _parse_accounts,
    _parse_rules,
    _validate_accounts,
    build_provider,
    load_config,
)

# ─── Helpers ──────────────────────────────────────────────────────────────────


def _write_toml(content: str) -> Path:
    tmp = tempfile.NamedTemporaryFile(
        mode="w", suffix=".toml", delete=False, encoding="utf-8"
    )
    tmp.write(content)
    tmp.flush()
    tmp.close()
    return Path(tmp.name)


MINIMAL_VALID_TOML = """
[[accounts]]
org = "Company A"
email = "shathish@companya.com"
provider = "google"
is_primary = true

[[accounts]]
org = "Company B"
email = "shathish@companyb.com"
provider = "microsoft"
is_primary = false
"""

FULL_RULES_TOML = MINIMAL_VALID_TOML + """
[rules]
default_duration_minutes = 45
buffer_before_minutes = 5
buffer_after_minutes = 10
default_working_hours_start = "08:00"
default_working_hours_end = "18:00"
working_days = ["Monday", "Wednesday", "Friday"]
advance_notice_hours = 48
max_days_ahead = 60
slot_limit = 20
"""


# ─── _parse_accounts ──────────────────────────────────────────────────────────


class TestParseAccounts:
    def test_valid_accounts_parsed(self) -> None:
        raw = [
            {"org": "A", "email": "a@a.com", "provider": "google", "is_primary": True},
            {"org": "B", "email": "b@b.com", "provider": "microsoft", "is_primary": False},
        ]
        accounts = _parse_accounts(raw)
        assert len(accounts) == 2
        assert accounts[0].is_primary is True
        assert accounts[1].provider == "microsoft"

    def test_missing_org_raises(self) -> None:
        raw = [{"email": "a@a.com", "provider": "google", "is_primary": True}]
        with pytest.raises(ValueError, match="org"):
            _parse_accounts(raw)

    def test_missing_email_raises(self) -> None:
        raw = [{"org": "A", "provider": "google", "is_primary": True}]
        with pytest.raises(ValueError, match="email"):
            _parse_accounts(raw)

    def test_missing_provider_raises(self) -> None:
        raw = [{"org": "A", "email": "a@a.com", "is_primary": True}]
        with pytest.raises(ValueError, match="provider"):
            _parse_accounts(raw)

    def test_unsupported_provider_raises(self) -> None:
        raw = [{"org": "A", "email": "a@a.com", "provider": "caldav", "is_primary": True}]
        with pytest.raises(ValueError, match="unsupported provider"):
            _parse_accounts(raw)

    def test_email_lowercased(self) -> None:
        raw = [{"org": "A", "email": "USER@EXAMPLE.COM", "provider": "google", "is_primary": True}]
        accounts = _parse_accounts(raw)
        assert accounts[0].email == "user@example.com"

    def test_is_primary_defaults_to_false(self) -> None:
        raw = [{"org": "A", "email": "a@a.com", "provider": "google"}]
        accounts = _parse_accounts(raw)
        assert accounts[0].is_primary is False


# ─── _validate_accounts ───────────────────────────────────────────────────────


class TestValidateAccounts:
    def _acc(self, email: str, primary: bool) -> AccountConfig:
        return AccountConfig(org="Org", email=email, provider="google", is_primary=primary)

    def test_valid_single_primary(self) -> None:
        accounts = [self._acc("a@a.com", True), self._acc("b@b.com", False)]
        _validate_accounts(accounts)  # should not raise

    def test_no_primary_raises(self) -> None:
        accounts = [self._acc("a@a.com", False), self._acc("b@b.com", False)]
        with pytest.raises(ValueError, match="No account has is_primary"):
            _validate_accounts(accounts)

    def test_two_primaries_raises(self) -> None:
        accounts = [self._acc("a@a.com", True), self._acc("b@b.com", True)]
        with pytest.raises(ValueError, match="Multiple accounts have is_primary"):
            _validate_accounts(accounts)

    def test_empty_accounts_raises(self) -> None:
        with pytest.raises(ValueError, match="No accounts"):
            _validate_accounts([])

    def test_duplicate_emails_raises(self) -> None:
        accounts = [self._acc("a@a.com", True), self._acc("a@a.com", False)]
        with pytest.raises(ValueError, match="Duplicate account email"):
            _validate_accounts(accounts)


# ─── _parse_rules ─────────────────────────────────────────────────────────────


class TestParseRules:
    def test_defaults_when_empty(self) -> None:
        rules = _parse_rules({})
        assert rules.default_duration_minutes == 30
        assert rules.buffer_before_minutes == 0
        assert rules.buffer_after_minutes == 15
        assert rules.default_working_hours_start == "09:00"
        assert rules.default_working_hours_end == "17:00"
        assert rules.advance_notice_hours == 24
        assert rules.max_days_ahead == 30
        assert rules.slot_limit == 10
        assert "Monday" in rules.working_days

    def test_custom_values_parsed(self) -> None:
        raw = {
            "default_duration_minutes": 60,
            "buffer_before_minutes": 10,
            "buffer_after_minutes": 20,
            "default_working_hours_start": "08:00",
            "default_working_hours_end": "18:00",
            "working_days": ["Monday", "Wednesday"],
            "advance_notice_hours": 48,
            "max_days_ahead": 60,
            "slot_limit": 20,
        }
        rules = _parse_rules(raw)
        assert rules.default_duration_minutes == 60
        assert rules.buffer_before_minutes == 10
        assert rules.buffer_after_minutes == 20
        assert rules.default_working_hours_start == "08:00"
        assert rules.default_working_hours_end == "18:00"
        assert rules.working_days == ["Monday", "Wednesday"]
        assert rules.advance_notice_hours == 48
        assert rules.max_days_ahead == 60
        assert rules.slot_limit == 20


# ─── load_config ──────────────────────────────────────────────────────────────


class TestLoadConfig:
    def test_loads_valid_config(self) -> None:
        path = _write_toml(MINIMAL_VALID_TOML)
        config = load_config(path)
        assert len(config.accounts) == 2
        assert config.primary_account.email == "shathish@companya.com"
        assert len(config.shadow_accounts) == 1
        assert config.shadow_accounts[0].email == "shathish@companyb.com"

    def test_rules_defaults_when_absent(self) -> None:
        path = _write_toml(MINIMAL_VALID_TOML)
        config = load_config(path)
        assert config.rules.default_duration_minutes == 30

    def test_full_rules_section_parsed(self) -> None:
        path = _write_toml(FULL_RULES_TOML)
        config = load_config(path)
        assert config.rules.default_duration_minutes == 45
        assert config.rules.buffer_before_minutes == 5
        assert config.rules.working_days == ["Monday", "Wednesday", "Friday"]

    def test_zero_primary_raises(self) -> None:
        toml = """
[[accounts]]
org = "A"
email = "a@a.com"
provider = "google"
is_primary = false
"""
        path = _write_toml(toml)
        with pytest.raises(ValueError, match="No account has is_primary"):
            load_config(path)

    def test_two_primaries_raises(self) -> None:
        toml = """
[[accounts]]
org = "A"
email = "a@a.com"
provider = "google"
is_primary = true

[[accounts]]
org = "B"
email = "b@b.com"
provider = "microsoft"
is_primary = true
"""
        path = _write_toml(toml)
        with pytest.raises(ValueError, match="Multiple accounts have is_primary"):
            load_config(path)

    def test_file_not_found_raises(self) -> None:
        with pytest.raises(FileNotFoundError):
            load_config(Path("/nonexistent/path/config.toml"))

    def test_env_var_overrides_default_path(self, tmp_path: Path, monkeypatch) -> None:
        p = tmp_path / "custom.toml"
        p.write_text(MINIMAL_VALID_TOML, encoding="utf-8")
        monkeypatch.setenv("MEETING_SCHEDULER_CONFIG", str(p))
        config = load_config()
        assert config.primary_account.email == "shathish@companya.com"

    def test_env_var_pointing_to_missing_file_raises(self, monkeypatch) -> None:
        monkeypatch.setenv("MEETING_SCHEDULER_CONFIG", "/no/such/file.toml")
        with pytest.raises(FileNotFoundError):
            load_config()


# ─── build_provider ───────────────────────────────────────────────────────────


class TestBuildProvider:
    def _rules(self) -> SchedulingRules:
        return SchedulingRules()

    def test_google_provider_returned(self) -> None:
        from src.providers.google import GoogleCalendarProvider

        acc = AccountConfig(org="A", email="a@a.com", provider="google", is_primary=True)
        prov = build_provider(acc, self._rules())
        assert isinstance(prov, GoogleCalendarProvider)

    def test_microsoft_provider_returned(self) -> None:
        from src.providers.microsoft import MicrosoftCalendarProvider

        acc = AccountConfig(org="B", email="b@b.com", provider="microsoft", is_primary=False)
        prov = build_provider(acc, self._rules())
        assert isinstance(prov, MicrosoftCalendarProvider)

    def test_unknown_provider_raises(self) -> None:
        acc = AccountConfig(org="D", email="d@d.com", provider="unknown", is_primary=True)
        with pytest.raises(ValueError, match="Unknown provider"):
            build_provider(acc, self._rules())

    def test_google_primary_has_write_scope(self) -> None:
        from src.providers.google import GoogleCalendarProvider, _SCOPES_PRIMARY

        acc = AccountConfig(org="A", email="a@a.com", provider="google", is_primary=True)
        prov = build_provider(acc, self._rules())
        assert isinstance(prov, GoogleCalendarProvider)
        assert prov._scopes == _SCOPES_PRIMARY

    def test_google_shadow_has_freebusy_scope(self) -> None:
        from src.providers.google import GoogleCalendarProvider, _SCOPES_SHADOW

        acc = AccountConfig(org="A", email="a@a.com", provider="google", is_primary=False)
        prov = build_provider(acc, self._rules())
        assert isinstance(prov, GoogleCalendarProvider)
        assert prov._scopes == _SCOPES_SHADOW

    def test_microsoft_shadow_has_read_scope(self) -> None:
        from src.providers.microsoft import MicrosoftCalendarProvider, _SCOPES_SHADOW

        acc = AccountConfig(org="B", email="b@b.com", provider="microsoft", is_primary=False)
        prov = build_provider(acc, self._rules())
        assert isinstance(prov, MicrosoftCalendarProvider)
        assert prov._scopes == _SCOPES_SHADOW
