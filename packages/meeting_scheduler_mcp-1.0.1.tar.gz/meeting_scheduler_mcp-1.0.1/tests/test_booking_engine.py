"""
Unit tests for src/booking/engine.py.

The CalendarProvider is replaced with MagicMock — no real HTTP calls.

Coverage
--------
  book_meeting        happy path: returns correct dict with event_id
  book_meeting        extracts video link from _last_create_response
  book_meeting        video_link is None when provider returns None
  book_meeting        raises RuntimeError when create_event fails
  reschedule_meeting  happy path: returns dict with same event_id
  reschedule_meeting  raises RuntimeError when update_event fails
  cancel_meeting      happy path: calls delete_event with correct id
  cancel_meeting      raises RuntimeError when delete_event fails
  _build_event_payload  sets all fields correctly
  _extract_video_link   returns None when raw_response is None
  _extract_video_link   returns None when provider hook raises
"""

from __future__ import annotations

from datetime import datetime, timezone
from unittest.mock import MagicMock

import pytest

from src.booking.engine import (
    _build_event_payload,
    _extract_video_link,
    book_meeting,
    cancel_meeting,
    reschedule_meeting,
)
from src.scheduling.models import Slot

UTC = timezone.utc


def _dt(hour: int) -> datetime:
    return datetime(2024, 6, 10, hour, 0, tzinfo=UTC)


def _slot(start_hour: int, end_hour: int) -> Slot:
    return Slot(start=_dt(start_hour), end=_dt(end_hour))


def _make_provider(event_id: str = "evt_abc", video_url: str | None = None) -> MagicMock:
    provider = MagicMock()
    provider.create_event.return_value = event_id
    provider.get_video_link_from_response.return_value = video_url
    provider._last_create_response = {"id": event_id}
    return provider


# ── _build_event_payload ──────────────────────────────────────────────────────


class TestBuildEventPayload:
    def test_sets_all_fields(self) -> None:
        payload = _build_event_payload(
            slot_start=_dt(10),
            slot_end=_dt(11),
            title="Sync",
            participants=["a@a.com"],
            organiser_email="org@org.com",
            description="Agenda",
            organiser_timezone="America/New_York",
            video_provider="google_meet",
            generate_video_link=True,
        )
        assert payload.title == "Sync"
        assert payload.description == "Agenda"
        assert payload.start == _dt(10)
        assert payload.end == _dt(11)
        assert payload.organiser_email == "org@org.com"
        assert payload.participant_emails == ["a@a.com"]
        assert payload.timezone == "America/New_York"
        assert payload.generate_video_link is True
        assert payload.video_provider == "google_meet"


# ── _extract_video_link ───────────────────────────────────────────────────────


class TestExtractVideoLink:
    def test_returns_none_when_raw_response_is_none(self) -> None:
        provider = MagicMock()
        assert _extract_video_link(provider, None) is None
        provider.get_video_link_from_response.assert_not_called()

    def test_returns_url_from_provider(self) -> None:
        provider = MagicMock()
        provider.get_video_link_from_response.return_value = "https://meet.google.com/xxx"
        result = _extract_video_link(provider, {"id": "evt"})
        assert result == "https://meet.google.com/xxx"

    def test_returns_none_when_provider_hook_raises(self) -> None:
        provider = MagicMock()
        provider.get_video_link_from_response.side_effect = RuntimeError("boom")
        result = _extract_video_link(provider, {"id": "evt"})
        assert result is None


# ── book_meeting ──────────────────────────────────────────────────────────────


class TestBookMeeting:
    def test_happy_path_returns_correct_dict(self) -> None:
        provider = _make_provider("evt_123", video_url=None)
        result = book_meeting(
            slot=_slot(10, 11),
            title="Team Sync",
            participants=["a@a.com", "b@b.com"],
            organiser_email="org@org.com",
            primary_provider=provider,
            description="Agenda",
            organiser_timezone="UTC",
        )
        assert result["event_id"] == "evt_123"
        assert result["title"] == "Team Sync"
        assert result["participants"] == ["a@a.com", "b@b.com"]
        assert result["organiser"] == "org@org.com"
        assert result["start_utc"] == _dt(10).isoformat()
        assert result["end_utc"] == _dt(11).isoformat()

    def test_extracts_video_link(self) -> None:
        provider = _make_provider("evt_456", video_url="https://meet.google.com/abc")
        result = book_meeting(
            slot=_slot(14, 15),
            title="Video Call",
            participants=[],
            organiser_email="org@org.com",
            primary_provider=provider,
        )
        assert result["video_link"] == "https://meet.google.com/abc"

    def test_video_link_none_when_provider_returns_none(self) -> None:
        provider = _make_provider("evt_789", video_url=None)
        result = book_meeting(
            slot=_slot(9, 10),
            title="No Video",
            participants=[],
            organiser_email="org@org.com",
            primary_provider=provider,
            generate_video_link=False,
        )
        assert result["video_link"] is None

    def test_raises_on_provider_error(self) -> None:
        provider = MagicMock()
        provider.create_event.side_effect = RuntimeError("API error")
        with pytest.raises(RuntimeError, match="Failed to create calendar event"):
            book_meeting(
                slot=_slot(10, 11),
                title="Fail",
                participants=[],
                organiser_email="org@org.com",
                primary_provider=provider,
            )

    def test_create_event_called_with_correct_payload(self) -> None:
        provider = _make_provider("evt_check")
        book_meeting(
            slot=_slot(10, 11),
            title="Check",
            participants=["p@p.com"],
            organiser_email="org@org.com",
            primary_provider=provider,
            description="Details",
            organiser_timezone="Asia/Kolkata",
        )
        provider.create_event.assert_called_once()
        payload = provider.create_event.call_args[0][0]
        assert payload.title == "Check"
        assert payload.description == "Details"
        assert payload.timezone == "Asia/Kolkata"
        assert payload.participant_emails == ["p@p.com"]


# ── reschedule_meeting ────────────────────────────────────────────────────────


class TestRescheduleMeeting:
    def test_happy_path_returns_same_event_id(self) -> None:
        provider = MagicMock()
        provider.update_event.return_value = None
        provider.get_video_link_from_response.return_value = None
        provider._last_create_response = None

        result = reschedule_meeting(
            event_id="original_evt",
            new_slot=_slot(15, 16),
            title="Rescheduled",
            participants=["x@x.com"],
            organiser_email="org@org.com",
            primary_provider=provider,
        )
        assert result["event_id"] == "original_evt"
        assert result["start_utc"] == _dt(15).isoformat()
        assert result["end_utc"] == _dt(16).isoformat()

    def test_update_event_called_with_correct_args(self) -> None:
        provider = MagicMock()
        provider.get_video_link_from_response.return_value = None
        provider._last_create_response = None

        reschedule_meeting(
            event_id="evt_to_move",
            new_slot=_slot(11, 12),
            title="Moved",
            participants=[],
            organiser_email="org@org.com",
            primary_provider=provider,
        )
        provider.update_event.assert_called_once()
        call_event_id = provider.update_event.call_args[0][0]
        assert call_event_id == "evt_to_move"

    def test_raises_on_provider_error(self) -> None:
        provider = MagicMock()
        provider.update_event.side_effect = RuntimeError("Not found")
        with pytest.raises(RuntimeError, match="Failed to reschedule event"):
            reschedule_meeting(
                event_id="missing_evt",
                new_slot=_slot(10, 11),
                title="Fail",
                participants=[],
                organiser_email="org@org.com",
                primary_provider=provider,
            )


# ── cancel_meeting ────────────────────────────────────────────────────────────


class TestCancelMeeting:
    def test_calls_delete_event_with_correct_id(self) -> None:
        provider = MagicMock()
        cancel_meeting(event_id="evt_del", primary_provider=provider)
        provider.delete_event.assert_called_once_with("evt_del")

    def test_raises_on_provider_error(self) -> None:
        provider = MagicMock()
        provider.delete_event.side_effect = RuntimeError("Event not found")
        with pytest.raises(RuntimeError, match="Failed to cancel event"):
            cancel_meeting(event_id="gone_evt", primary_provider=provider)
