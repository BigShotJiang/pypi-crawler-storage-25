"""
Unit tests for the scheduling engine.

All tests use mock CalendarProvider instances — no real API calls are made.

Coverage:
  - Busy interval merging and de-duplication.
  - Buffer expansion around busy intervals.
  - Slot intersection logic (free / busy detection).
  - Working-hours filtering (slot inside / outside working hours).
  - Working-day filtering (weekend rejection).
  - NoSlotsFound exception for all-busy and window-too-short scenarios.
  - ParticipantDomainNotConfigured exception.
  - Advance-notice enforcement.
  - End-to-end find_slots with mocked providers.
"""

from __future__ import annotations

import types
from datetime import datetime, timedelta, timezone
from unittest.mock import MagicMock, patch

import pytest

from src.scheduling.engine import (
    NoSlotsFound,
    ParticipantDomainNotConfigured,
    _expand_with_buffers,
    _merge_busy_intervals,
    _slot_is_free,
    _slot_within_working_hours,
    find_slots,
)
from src.scheduling.models import BusyInterval, MailboxSettings, Slot
from src.scheduling.timezone_utils import UTC

# ─── Fixtures ─────────────────────────────────────────────────────────────────


def dt(year: int, month: int, day: int, hour: int = 0, minute: int = 0) -> datetime:
    """Convenience factory for UTC datetimes."""
    return datetime(year, month, day, hour, minute, tzinfo=UTC)


def busy(start_h: int, end_h: int, day: int = 10) -> BusyInterval:
    """Busy interval on 2024-06-<day> from start_h:00 to end_h:00 UTC."""
    return BusyInterval(
        start=dt(2024, 6, day, start_h),
        end=dt(2024, 6, day, end_h),
    )


WEEKDAY_SETTINGS = MailboxSettings(
    timezone="UTC",
    working_hours_start="09:00",
    working_hours_end="17:00",
    working_days=["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"],
)

# 2024-06-10 is a Monday; 2024-06-15 is a Saturday.


# ─── BusyInterval basic tests ─────────────────────────────────────────────────


class TestBusyInterval:
    def test_overlap_detection(self) -> None:
        a = busy(9, 11)
        b = busy(10, 12)
        assert a.overlaps(b)
        assert b.overlaps(a)

    def test_no_overlap(self) -> None:
        a = busy(9, 10)
        b = busy(11, 12)
        assert not a.overlaps(b)

    def test_adjacent_not_overlapping(self) -> None:
        a = busy(9, 10)
        b = busy(10, 11)
        assert not a.overlaps(b)

    def test_union(self) -> None:
        a = busy(9, 11)
        b = busy(10, 13)
        u = a.union(b)
        assert u.start == a.start
        assert u.end == b.end

    def test_invalid_order_raises(self) -> None:
        with pytest.raises(ValueError, match="must be before end"):
            BusyInterval(start=dt(2024, 6, 10, 10), end=dt(2024, 6, 10, 9))

    def test_naive_datetime_raises(self) -> None:
        naive = datetime(2024, 6, 10, 9)
        with pytest.raises(ValueError, match="timezone-aware"):
            BusyInterval(start=naive, end=dt(2024, 6, 10, 10))


# ─── _merge_busy_intervals ────────────────────────────────────────────────────


class TestMergeBusyIntervals:
    def test_empty_list(self) -> None:
        assert _merge_busy_intervals([]) == []

    def test_single_interval(self) -> None:
        result = _merge_busy_intervals([busy(9, 10)])
        assert len(result) == 1

    def test_two_non_overlapping(self) -> None:
        result = _merge_busy_intervals([busy(9, 10), busy(11, 12)])
        assert len(result) == 2

    def test_two_overlapping_merge(self) -> None:
        result = _merge_busy_intervals([busy(9, 11), busy(10, 13)])
        assert len(result) == 1
        assert result[0].start == dt(2024, 6, 10, 9)
        assert result[0].end == dt(2024, 6, 10, 13)

    def test_three_overlapping_merge_to_one(self) -> None:
        result = _merge_busy_intervals([busy(9, 11), busy(10, 12), busy(11, 14)])
        assert len(result) == 1
        assert result[0].end == dt(2024, 6, 10, 14)

    def test_unsorted_input_sorted_output(self) -> None:
        result = _merge_busy_intervals([busy(11, 12), busy(9, 10)])
        assert result[0].start == dt(2024, 6, 10, 9)
        assert result[1].start == dt(2024, 6, 10, 11)

    def test_adjacent_intervals_merged(self) -> None:
        # Engine merges touching intervals (current.start <= last.end).
        result = _merge_busy_intervals([busy(9, 10), busy(10, 11)])
        assert len(result) == 1
        assert result[0].start == dt(2024, 6, 10, 9)
        assert result[0].end == dt(2024, 6, 10, 11)


# ─── _expand_with_buffers ─────────────────────────────────────────────────────


class TestExpandWithBuffers:
    def test_buffer_after_extends_end(self) -> None:
        original = busy(9, 10)
        expanded = _expand_with_buffers(
            [original],
            buffer_before=timedelta(0),
            buffer_after=timedelta(minutes=15),
        )
        assert len(expanded) == 1
        assert expanded[0].end == dt(2024, 6, 10, 10, 15)

    def test_buffer_before_extends_start(self) -> None:
        original = busy(10, 11)
        expanded = _expand_with_buffers(
            [original],
            buffer_before=timedelta(minutes=15),
            buffer_after=timedelta(0),
        )
        assert expanded[0].start == dt(2024, 6, 10, 9, 45)

    def test_buffers_cause_merge(self) -> None:
        # Two intervals 20 minutes apart; 15-min after buffer on the first
        # and 15-min before buffer on the second should cause them to merge.
        b1 = busy(9, 10)
        b2 = BusyInterval(start=dt(2024, 6, 10, 10, 20), end=dt(2024, 6, 10, 11))
        expanded = _expand_with_buffers(
            [b1, b2],
            buffer_before=timedelta(minutes=5),
            buffer_after=timedelta(minutes=15),
        )
        # After: b1 → [09:00, 10:15]; b2 → [10:15, 11:00] — they touch so merge.
        assert len(expanded) == 1


# ─── _slot_is_free ────────────────────────────────────────────────────────────


class TestSlotIsFree:
    def test_slot_fully_free(self) -> None:
        busy_list = [busy(9, 10), busy(14, 15)]
        assert _slot_is_free(dt(2024, 6, 10, 11), dt(2024, 6, 10, 11, 30), busy_list)

    def test_slot_overlaps_busy(self) -> None:
        busy_list = [busy(9, 10)]
        assert not _slot_is_free(dt(2024, 6, 10, 9, 30), dt(2024, 6, 10, 10, 0), busy_list)

    def test_slot_entirely_within_busy(self) -> None:
        busy_list = [busy(9, 12)]
        assert not _slot_is_free(dt(2024, 6, 10, 10), dt(2024, 6, 10, 11), busy_list)

    def test_empty_busy_list(self) -> None:
        assert _slot_is_free(dt(2024, 6, 10, 10), dt(2024, 6, 10, 10, 30), [])

    def test_slot_before_all_busy(self) -> None:
        busy_list = [busy(14, 15)]
        assert _slot_is_free(dt(2024, 6, 10, 10), dt(2024, 6, 10, 10, 30), busy_list)

    def test_slot_after_all_busy(self) -> None:
        busy_list = [busy(9, 10)]
        assert _slot_is_free(dt(2024, 6, 10, 11), dt(2024, 6, 10, 11, 30), busy_list)


# ─── _slot_within_working_hours ───────────────────────────────────────────────


class TestSlotWithinWorkingHours:
    def test_slot_inside_working_hours(self) -> None:
        # 2024-06-10 10:00–10:30 UTC, UTC timezone, 09:00–17:00 Mon-Fri
        result = _slot_within_working_hours(
            dt(2024, 6, 10, 10), dt(2024, 6, 10, 10, 30), [WEEKDAY_SETTINGS]
        )
        assert result is True

    def test_slot_starts_before_working_hours(self) -> None:
        result = _slot_within_working_hours(
            dt(2024, 6, 10, 8, 30), dt(2024, 6, 10, 9, 0), [WEEKDAY_SETTINGS]
        )
        assert result is False

    def test_slot_ends_after_working_hours(self) -> None:
        result = _slot_within_working_hours(
            dt(2024, 6, 10, 16, 45), dt(2024, 6, 10, 17, 15), [WEEKDAY_SETTINGS]
        )
        assert result is False

    def test_slot_on_weekend_rejected(self) -> None:
        # 2024-06-15 is a Saturday.
        result = _slot_within_working_hours(
            dt(2024, 6, 15, 10), dt(2024, 6, 15, 10, 30), [WEEKDAY_SETTINGS]
        )
        assert result is False

    def test_slot_rejected_if_one_participant_outside_hours(self) -> None:
        # Second participant works 13:00–17:00; slot at 10:00 is outside.
        afternoon_settings = MailboxSettings(
            timezone="UTC",
            working_hours_start="13:00",
            working_hours_end="17:00",
            working_days=["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"],
        )
        result = _slot_within_working_hours(
            dt(2024, 6, 10, 10), dt(2024, 6, 10, 10, 30),
            [WEEKDAY_SETTINGS, afternoon_settings],
        )
        assert result is False

    def test_slot_accepted_when_all_within_hours(self) -> None:
        afternoon_settings = MailboxSettings(
            timezone="UTC",
            working_hours_start="13:00",
            working_hours_end="17:00",
            working_days=["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"],
        )
        result = _slot_within_working_hours(
            dt(2024, 6, 10, 14), dt(2024, 6, 10, 14, 30),
            [WEEKDAY_SETTINGS, afternoon_settings],
        )
        assert result is True


# ─── find_slots end-to-end ────────────────────────────────────────────────────


def _make_provider(busy_intervals: list[BusyInterval], tz: str = "UTC") -> MagicMock:
    """Return a mock CalendarProvider."""
    p = MagicMock()
    p.get_free_busy.return_value = busy_intervals
    p.get_mailbox_settings.return_value = MailboxSettings(
        timezone=tz,
        working_hours_start="09:00",
        working_hours_end="17:00",
        working_days=["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"],
    )
    return p


def _make_account(email: str, is_primary: bool = False) -> MagicMock:
    acc = MagicMock()
    acc.email = email
    acc.is_primary = is_primary
    return acc


RULES = {
    "default_duration_minutes": 30,
    "buffer_before_minutes": 0,
    "buffer_after_minutes": 0,
    "default_working_hours_start": "09:00",
    "default_working_hours_end": "17:00",
    "working_days": ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"],
    "advance_notice_hours": 0,  # disabled for test predictability
    "max_days_ahead": 30,
    "slot_limit": 5,
}


class TestFindSlots:
    """End-to-end find_slots tests using mocked providers."""

    @pytest.fixture(autouse=True)
    def _freeze_clock(self, monkeypatch):
        """Freeze utc_now to just before the test windows (2024-06-10 00:00 UTC)
        so advance_notice_hours=0 doesn't discard the fixed 2024 dates."""
        frozen = dt(2024, 6, 9, 23, 59)
        monkeypatch.setattr("src.scheduling.engine.utc_now", lambda: frozen)

    def _run(
        self,
        primary_busy: list[BusyInterval],
        participant_emails: list[str],
        participant_busy: dict[str, list[BusyInterval]],
        window_start: datetime,
        window_end: datetime,
        duration: int = 30,
    ) -> list[Slot]:
        primary_email = "organiser@companya.com"
        primary_acc = _make_account(primary_email, is_primary=True)

        shadow_acc = _make_account("organiser@companyb.com", is_primary=False)

        primary_prov = _make_provider(primary_busy)
        shadow_prov = _make_provider([])

        provider_map = {primary_email: primary_prov, "organiser@companyb.com": shadow_prov}

        for email, busy_list in participant_busy.items():
            domain = email.split("@")[1]
            if domain == "companya.com":
                primary_prov.get_free_busy = MagicMock(
                    side_effect=lambda e, s, end, _busy=busy_list, _org_busy=primary_busy: (
                        _busy if e != primary_email else _org_busy
                    )
                )
            elif domain == "companyb.com":
                shadow_prov.get_free_busy = MagicMock(return_value=busy_list)
                shadow_prov.get_mailbox_settings = MagicMock(
                    return_value=MailboxSettings(
                        timezone="UTC",
                        working_hours_start="09:00",
                        working_hours_end="17:00",
                        working_days=["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"],
                    )
                )
                provider_map[email] = shadow_prov

        return find_slots(
            primary_account=primary_acc,
            shadow_accounts=[shadow_acc],
            provider_map=provider_map,
            participants=participant_emails,
            duration_minutes=duration,
            window_start=window_start,
            window_end=window_end,
            rules=RULES,
        )

    def test_no_busy_returns_slots(self) -> None:
        # Monday 2024-06-10, window 09:00–11:00 — should find multiple slots.
        slots = self._run(
            primary_busy=[],
            participant_emails=[],
            participant_busy={},
            window_start=dt(2024, 6, 10, 9),
            window_end=dt(2024, 6, 10, 11),
        )
        assert len(slots) > 0
        for s in slots:
            assert s.start >= dt(2024, 6, 10, 9)
            assert s.end <= dt(2024, 6, 10, 11)

    def test_all_busy_raises_no_slots_found(self) -> None:
        # Busy all day — no 30-minute gap possible.
        all_day = [BusyInterval(start=dt(2024, 6, 10, 0), end=dt(2024, 6, 10, 23, 59))]
        with pytest.raises(NoSlotsFound):
            self._run(
                primary_busy=all_day,
                participant_emails=[],
                participant_busy={},
                window_start=dt(2024, 6, 10, 9),
                window_end=dt(2024, 6, 10, 17),
            )

    def test_slots_respect_slot_limit(self) -> None:
        slots = self._run(
            primary_busy=[],
            participant_emails=[],
            participant_busy={},
            window_start=dt(2024, 6, 10, 9),
            window_end=dt(2024, 6, 10, 17),
        )
        assert len(slots) <= RULES["slot_limit"]

    def test_window_too_short_raises(self) -> None:
        # 20-minute window for a 30-minute meeting — impossible.
        with pytest.raises(NoSlotsFound, match="window is too short"):
            self._run(
                primary_busy=[],
                participant_emails=[],
                participant_busy={},
                window_start=dt(2024, 6, 10, 9),
                window_end=dt(2024, 6, 10, 9, 20),
            )

    def test_participant_domain_not_configured_raises(self) -> None:
        primary_acc = _make_account("organiser@companya.com", is_primary=True)
        primary_prov = _make_provider([])
        provider_map = {"organiser@companya.com": primary_prov}

        with pytest.raises(ParticipantDomainNotConfigured):
            find_slots(
                primary_account=primary_acc,
                shadow_accounts=[],
                provider_map=provider_map,
                participants=["unknown@unknowndomain.example"],
                duration_minutes=30,
                window_start=dt(2024, 6, 10, 9),
                window_end=dt(2024, 6, 10, 17),
                rules=RULES,
            )

    def test_slots_are_chronological(self) -> None:
        slots = self._run(
            primary_busy=[],
            participant_emails=[],
            participant_busy={},
            window_start=dt(2024, 6, 10, 9),
            window_end=dt(2024, 6, 10, 17),
        )
        for i in range(len(slots) - 1):
            assert slots[i].start < slots[i + 1].start

    def test_buffer_after_prevents_back_to_back(self) -> None:
        """A slot ending at 10:00 with a 15-min buffer should block 10:00–10:30."""
        buffered_rules = {**RULES, "buffer_after_minutes": 15}
        # Busy 09:00–10:00. Buffer means no slot can start before 10:15.
        busy_intervals = [busy(9, 10)]
        primary_acc = _make_account("organiser@companya.com", is_primary=True)
        primary_prov = _make_provider(busy_intervals)
        provider_map = {"organiser@companya.com": primary_prov}

        slots = find_slots(
            primary_account=primary_acc,
            shadow_accounts=[],
            provider_map=provider_map,
            participants=[],
            duration_minutes=30,
            window_start=dt(2024, 6, 10, 9),
            window_end=dt(2024, 6, 10, 17),
            rules=buffered_rules,
        )
        # First slot must start at 10:15 or later (buffer = 15 min after 10:00).
        assert slots[0].start >= dt(2024, 6, 10, 10, 15)

    def test_slots_outside_working_hours_excluded(self) -> None:
        """Slots before 09:00 or after 17:00 must not appear in results."""
        slots = self._run(
            primary_busy=[],
            participant_emails=[],
            participant_busy={},
            window_start=dt(2024, 6, 10, 7),  # window starts at 07:00
            window_end=dt(2024, 6, 10, 19),   # window ends at 19:00
        )
        for slot in slots:
            assert slot.start >= dt(2024, 6, 10, 9), f"Slot before 09:00: {slot.start}"
            assert slot.end <= dt(2024, 6, 10, 17), f"Slot after 17:00: {slot.end}"

    def test_advance_notice_enforced(self) -> None:
        """With 24h advance notice, no slot should start within 24h of 'now'."""
        advance_rules = {**RULES, "advance_notice_hours": 24}
        from unittest.mock import patch
        from src.scheduling import timezone_utils

        fake_now = dt(2024, 6, 10, 8, 0)
        earliest_allowed = fake_now + timedelta(hours=24)

        primary_acc = _make_account("organiser@companya.com", is_primary=True)
        primary_prov = _make_provider([])
        provider_map = {"organiser@companya.com": primary_prov}

        with patch("src.scheduling.engine.utc_now", return_value=fake_now):
            slots = find_slots(
                primary_account=primary_acc,
                shadow_accounts=[],
                provider_map=provider_map,
                participants=[],
                duration_minutes=30,
                window_start=dt(2024, 6, 10, 9),
                window_end=dt(2024, 6, 14, 17),
                rules=advance_rules,
            )

        for slot in slots:
            assert slot.start >= earliest_allowed, (
                f"Slot {slot.start} violates 24h advance notice (now={fake_now})"
            )
