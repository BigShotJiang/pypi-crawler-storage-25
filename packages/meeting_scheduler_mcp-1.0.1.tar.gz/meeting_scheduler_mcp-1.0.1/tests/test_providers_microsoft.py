"""
Unit tests for src/providers/microsoft.py (MicrosoftCalendarProvider).

MSAL and msal-extensions are stubbed so no real Azure AD calls are made.
HTTP calls use unittest.mock.patch on httpx methods.

Coverage
--------
  _build_token_cache        returns SerializableTokenCache (fallback / msal-ext)
  _get_valid_token          returns token from MSAL silent path
  _get_valid_token          migrates legacy keyring refresh token
  _get_valid_token          raises when no token available
  _load_legacy_refresh_token  reads plain refresh_token string
  _load_legacy_refresh_token  reads token from old JSON blob
  _load_legacy_refresh_token  returns None when nothing stored
  authenticate              calls acquire_token_interactive and succeeds
  authenticate              raises on error response
  get_free_busy             parses busy scheduleItems
  get_free_busy             raises on non-200
  get_mailbox_settings      parses Windows TZ + working hours
  get_mailbox_settings      raises on non-200
  create_event              posts body, returns event ID
  create_event              adds Teams link when requested
  create_event              raises on non-200
  update_event              patches event, succeeds on 200
  update_event              raises on non-200
  delete_event              deletes event, succeeds on 204
  delete_event              raises on non-200
  health_check              returns True on 200
  health_check              returns False on error
  get_video_link_from_response  extracts Teams join URL
  get_video_link_from_response  returns None when absent
  _windows_tz_to_iana       maps known timezone names
  _windows_tz_to_iana       passes unknown names through unchanged
"""

from __future__ import annotations

import json
from datetime import datetime, timezone
from typing import Optional
from unittest.mock import MagicMock, patch

import httpx
import msal
import pytest

UTC = timezone.utc


# ── Stub keyring so no OS secret-store is touched ─────────────────────────────

_KEYRING: dict[tuple[str, str], str] = {}


@pytest.fixture(autouse=True)
def _patch_keyring(monkeypatch):
    _KEYRING.clear()

    def _get(svc, acct):
        return _KEYRING.get((svc, acct))

    def _set(svc, acct, val):
        _KEYRING[(svc, acct)] = val

    def _del(svc, acct):
        _KEYRING.pop((svc, acct), None)

    monkeypatch.setattr("keyring.get_password", _get)
    monkeypatch.setattr("keyring.set_password", _set)
    monkeypatch.setattr("keyring.delete_password", _del)


# ── Stub msal-extensions so imports succeed on Linux / CI ─────────────────────

@pytest.fixture(autouse=True)
def _no_msal_extensions(monkeypatch):
    """Make msal_extensions unavailable so _build_token_cache falls back."""
    import sys
    monkeypatch.setitem(sys.modules, "msal_extensions", None)


# ── Stub MSAL PublicClientApplication ─────────────────────────────────────────

def _make_msal_app(accounts=None, silent_result=None, interactive_result=None,
                   refresh_result=None):
    app = MagicMock()
    app.get_accounts.return_value = accounts or []
    app.acquire_token_silent.return_value = silent_result
    app.acquire_token_interactive.return_value = interactive_result or {"access_token": "ia_tok"}
    app.acquire_token_by_refresh_token.return_value = refresh_result or {"access_token": "rr_tok"}
    return app


@pytest.fixture(autouse=True)
def _patch_msal(monkeypatch):
    """Replace PublicClientApplication construction so no real MSAL init runs."""
    def _fake_pca(client_id, authority, token_cache):
        return _make_msal_app()

    monkeypatch.setattr("msal.PublicClientApplication", _fake_pca)


# ── Import after all patches are in place ─────────────────────────────────────

from src.providers.microsoft import (  # noqa: E402
    MicrosoftCalendarProvider,
    _windows_tz_to_iana,
)


# ── Provider factory ──────────────────────────────────────────────────────────

def _primary(**kwargs) -> MicrosoftCalendarProvider:
    defaults = dict(email="me@company.com", is_primary=True, client_id="azure_cid")
    defaults.update(kwargs)
    p = MicrosoftCalendarProvider(**defaults)
    return p


def _shadow(**kwargs) -> MicrosoftCalendarProvider:
    defaults = dict(email="shadow@partner.com", is_primary=False, client_id="azure_cid")
    defaults.update(kwargs)
    return MicrosoftCalendarProvider(**defaults)


def _with_app(provider: MicrosoftCalendarProvider, app) -> MicrosoftCalendarProvider:
    provider._app = app
    return provider


def _dt(hour: int) -> datetime:
    return datetime(2024, 6, 10, hour, 0, tzinfo=UTC)


# ── _build_token_cache ────────────────────────────────────────────────────────


class TestBuildTokenCache:
    def test_returns_serializable_cache_when_extensions_unavailable(self) -> None:
        # msal_extensions is None in sys.modules (set by _no_msal_extensions)
        cache = _primary()._token_cache
        assert isinstance(cache, msal.SerializableTokenCache)


# ── _get_valid_token ──────────────────────────────────────────────────────────


class TestGetValidToken:
    def test_returns_token_from_silent_path(self) -> None:
        p = _primary()
        account_mock = MagicMock()
        app = _make_msal_app(
            accounts=[account_mock],
            silent_result={"access_token": "silent_tok"},
        )
        _with_app(p, app)
        assert p._get_valid_token() == "silent_tok"

    def test_falls_back_to_legacy_keyring(self) -> None:
        p = _primary()
        # No accounts in MSAL cache, silent returns nothing.
        app = _make_msal_app(
            accounts=[],
            refresh_result={"access_token": "legacy_tok"},
        )
        _with_app(p, app)
        # Inject a legacy plain refresh token into keyring.
        _KEYRING[("meeting-scheduler", "me@company.com")] = "legacy_rt"

        assert p._get_valid_token() == "legacy_tok"

    def test_raises_when_no_token_anywhere(self) -> None:
        p = _primary()
        app = _make_msal_app(accounts=[], silent_result=None)
        _with_app(p, app)
        with pytest.raises(RuntimeError, match="No valid token"):
            p._get_valid_token()

    def test_skips_legacy_when_msal_cache_has_account(self) -> None:
        p = _primary()
        account_mock = MagicMock()
        app = _make_msal_app(
            accounts=[account_mock],
            silent_result={"access_token": "cache_tok"},
        )
        _with_app(p, app)
        # Even if legacy token exists, should not be read.
        _KEYRING[("meeting-scheduler", "me@company.com")] = "old_rt"

        token = p._get_valid_token()
        assert token == "cache_tok"
        app.acquire_token_by_refresh_token.assert_not_called()


# ── _load_legacy_refresh_token ────────────────────────────────────────────────


class TestLoadLegacyRefreshToken:
    def test_reads_plain_string(self) -> None:
        p = _primary()
        _KEYRING[("meeting-scheduler", "me@company.com")] = "plain_rt"
        assert p._load_legacy_refresh_token() == "plain_rt"

    def test_reads_from_old_json_blob(self) -> None:
        p = _primary()
        blob = json.dumps({"refresh_token": "json_rt", "access_token": "at"})
        _KEYRING[("meeting-scheduler", "me@company.com")] = blob
        assert p._load_legacy_refresh_token() == "json_rt"

    def test_returns_none_when_nothing_stored(self) -> None:
        p = _primary()
        assert p._load_legacy_refresh_token() is None


# ── authenticate ──────────────────────────────────────────────────────────────


class TestAuthenticate:
    def test_succeeds_on_valid_response(self) -> None:
        p = _primary()
        app = _make_msal_app(interactive_result={"access_token": "ia_tok"})
        _with_app(p, app)
        p.authenticate()  # should not raise
        app.acquire_token_interactive.assert_called_once()

    def test_raises_on_error_response(self) -> None:
        p = _primary()
        app = _make_msal_app(interactive_result={
            "error": "access_denied",
            "error_description": "User declined consent",
        })
        _with_app(p, app)
        with pytest.raises(RuntimeError, match="User declined consent"):
            p.authenticate()

    def test_passes_login_hint(self) -> None:
        p = _primary()
        app = _make_msal_app(interactive_result={"access_token": "t"})
        _with_app(p, app)
        p.authenticate()
        _, kwargs = app.acquire_token_interactive.call_args
        assert kwargs.get("login_hint") == "me@company.com"


# ── get_free_busy ─────────────────────────────────────────────────────────────


class TestGetFreeBusy:
    def _provider(self) -> MicrosoftCalendarProvider:
        p = _primary()
        app = _make_msal_app(
            accounts=[MagicMock()],
            silent_result={"access_token": "tok"},
        )
        _with_app(p, app)
        return p

    def test_parses_busy_schedule_items(self) -> None:
        p = self._provider()
        api_response = {
            "value": [{
                "scheduleItems": [
                    {
                        "status": "Busy",
                        "start": {"dateTime": "2024-06-10T09:00:00"},
                        "end": {"dateTime": "2024-06-10T10:00:00"},
                    },
                    {
                        "status": "Free",
                        "start": {"dateTime": "2024-06-10T10:00:00"},
                        "end": {"dateTime": "2024-06-10T11:00:00"},
                    },
                ]
            }]
        }
        with patch("httpx.post") as mock_post:
            mock_post.return_value = httpx.Response(200, json=api_response)
            intervals = p.get_free_busy("me@company.com", _dt(8), _dt(17))

        assert len(intervals) == 1
        assert intervals[0].start.hour == 9

    def test_includes_tentative_and_oof(self) -> None:
        p = self._provider()
        api_response = {
            "value": [{
                "scheduleItems": [
                    {"status": "Tentative",
                     "start": {"dateTime": "2024-06-10T11:00:00"},
                     "end": {"dateTime": "2024-06-10T11:30:00"}},
                    {"status": "OOF",
                     "start": {"dateTime": "2024-06-10T13:00:00"},
                     "end": {"dateTime": "2024-06-10T14:00:00"}},
                ]
            }]
        }
        with patch("httpx.post") as mock_post:
            mock_post.return_value = httpx.Response(200, json=api_response)
            intervals = p.get_free_busy("me@company.com", _dt(8), _dt(17))

        assert len(intervals) == 2

    def test_raises_on_non_200(self) -> None:
        p = self._provider()
        with patch("httpx.post") as mock_post:
            mock_post.return_value = httpx.Response(401, text="Unauthorized")
            with pytest.raises(RuntimeError, match="getSchedule failed"):
                p.get_free_busy("me@company.com", _dt(8), _dt(17))


# ── get_mailbox_settings ──────────────────────────────────────────────────────


class TestGetMailboxSettings:
    def _provider(self) -> MicrosoftCalendarProvider:
        p = _primary()
        app = _make_msal_app(
            accounts=[MagicMock()],
            silent_result={"access_token": "tok"},
        )
        _with_app(p, app)
        return p

    def test_parses_windows_timezone_and_working_hours(self) -> None:
        p = self._provider()
        api_response = {
            "timeZone": "Eastern Standard Time",
            "workingHours": {
                "daysOfWeek": ["monday", "tuesday", "wednesday", "thursday", "friday"],
                "startTime": "08:00:00.0000000",
                "endTime": "17:00:00.0000000",
            },
        }
        with patch("httpx.get") as mock_get:
            mock_get.return_value = httpx.Response(200, json=api_response)
            settings = p.get_mailbox_settings("me@company.com")

        assert settings.timezone == "America/New_York"
        assert settings.working_hours_start == "08:00"
        assert settings.working_hours_end == "17:00"
        assert "Monday" in settings.working_days

    def test_raises_on_non_200(self) -> None:
        p = self._provider()
        with patch("httpx.get") as mock_get:
            mock_get.return_value = httpx.Response(403)
            with pytest.raises(RuntimeError, match="mailbox settings"):
                p.get_mailbox_settings("me@company.com")

    def test_falls_back_to_defaults_when_working_hours_absent(self) -> None:
        p = _primary(default_working_hours_start="09:00", default_working_hours_end="17:30")
        app = _make_msal_app(accounts=[MagicMock()], silent_result={"access_token": "tok"})
        _with_app(p, app)
        api_response = {"timeZone": "UTC"}
        with patch("httpx.get") as mock_get:
            mock_get.return_value = httpx.Response(200, json=api_response)
            settings = p.get_mailbox_settings("me@company.com")

        assert settings.working_hours_start == "09:00"
        assert settings.working_hours_end == "17:30"


# ── create_event ──────────────────────────────────────────────────────────────


class TestCreateEvent:
    def _provider(self) -> MicrosoftCalendarProvider:
        p = _primary()
        app = _make_msal_app(accounts=[MagicMock()], silent_result={"access_token": "tok"})
        _with_app(p, app)
        return p

    def _payload(self, video=False):
        from src.scheduling.models import EventPayload
        return EventPayload(
            title="Project Review",
            description="Q3 review",
            start=_dt(14),
            end=_dt(15),
            organiser_email="me@company.com",
            participant_emails=["b@b.com"],
            timezone="UTC",
            generate_video_link=video,
            video_provider="teams" if video else "none",
        )

    def test_returns_event_id(self) -> None:
        p = self._provider()
        with patch("httpx.post") as mock_post:
            mock_post.return_value = httpx.Response(201, json={"id": "ms_evt_1"})
            eid = p.create_event(self._payload())
        assert eid == "ms_evt_1"

    def test_raises_on_non_201(self) -> None:
        p = self._provider()
        with patch("httpx.post") as mock_post:
            mock_post.return_value = httpx.Response(400, text="Bad Request")
            with pytest.raises(RuntimeError, match="create event failed"):
                p.create_event(self._payload())

    def test_includes_teams_link_when_requested(self) -> None:
        p = self._provider()
        captured: list[dict] = []

        def fake_post(url, json=None, headers=None, timeout=None):
            captured.append(json or {})
            return httpx.Response(201, json={"id": "t_evt"})

        with patch("httpx.post", side_effect=fake_post):
            p.create_event(self._payload(video=True))

        assert captured[0].get("isOnlineMeeting") is True
        assert captured[0].get("onlineMeetingProvider") == "teamsForBusiness"

    def test_no_teams_link_when_video_disabled(self) -> None:
        p = self._provider()
        captured: list[dict] = []

        def fake_post(url, json=None, headers=None, timeout=None):
            captured.append(json or {})
            return httpx.Response(201, json={"id": "no_vid"})

        with patch("httpx.post", side_effect=fake_post):
            p.create_event(self._payload(video=False))

        assert "isOnlineMeeting" not in captured[0]


# ── update_event ──────────────────────────────────────────────────────────────


class TestUpdateEvent:
    def _provider(self) -> MicrosoftCalendarProvider:
        p = _primary()
        app = _make_msal_app(accounts=[MagicMock()], silent_result={"access_token": "tok"})
        _with_app(p, app)
        return p

    def _payload(self):
        from src.scheduling.models import EventPayload
        return EventPayload(
            title="Updated",
            description="",
            start=_dt(15),
            end=_dt(16),
            organiser_email="me@company.com",
            participant_emails=[],
            timezone="UTC",
            generate_video_link=False,
        )

    def test_succeeds_on_200(self) -> None:
        p = self._provider()
        with patch("httpx.patch") as mock_patch:
            mock_patch.return_value = httpx.Response(200, json={})
            p.update_event("ms_evt_1", self._payload())

    def test_raises_on_non_200(self) -> None:
        p = self._provider()
        with patch("httpx.patch") as mock_patch:
            mock_patch.return_value = httpx.Response(404)
            with pytest.raises(RuntimeError, match="update event"):
                p.update_event("ms_evt_1", self._payload())


# ── get_event ─────────────────────────────────────────────────────────────────


class TestGetEvent:
    def _provider(self) -> MicrosoftCalendarProvider:
        p = _primary()
        app = _make_msal_app(accounts=[MagicMock()], silent_result={"access_token": "tok"})
        _with_app(p, app)
        return p

    def test_returns_normalised_dict(self) -> None:
        p = self._provider()
        api_response = {
            "subject": "Budget Review",
            "body": {"content": "Q3 numbers"},
            "attendees": [
                {"emailAddress": {"address": "me@company.com"}},   # organiser — excluded
                {"emailAddress": {"address": "x@x.com"}},
                {"emailAddress": {"address": "y@y.com"}},
            ],
        }
        with patch("httpx.get") as mock_get:
            mock_get.return_value = httpx.Response(200, json=api_response)
            result = p.get_event("ms_evt_1")

        assert result["title"] == "Budget Review"
        assert result["description"] == "Q3 numbers"
        assert "x@x.com" in result["participants"]
        assert "y@y.com" in result["participants"]
        assert "me@company.com" not in result["participants"]

    def test_raises_on_non_200(self) -> None:
        p = self._provider()
        with patch("httpx.get") as mock_get:
            mock_get.return_value = httpx.Response(404)
            with pytest.raises(RuntimeError, match="get event"):
                p.get_event("missing_evt")

    def test_empty_attendees(self) -> None:
        p = self._provider()
        api_response = {"subject": "Solo", "body": {"content": ""}, "attendees": []}
        with patch("httpx.get") as mock_get:
            mock_get.return_value = httpx.Response(200, json=api_response)
            result = p.get_event("ms_solo")
        assert result["participants"] == []


# ── delete_event ──────────────────────────────────────────────────────────────


class TestDeleteEvent:
    def _provider(self) -> MicrosoftCalendarProvider:
        p = _primary()
        app = _make_msal_app(accounts=[MagicMock()], silent_result={"access_token": "tok"})
        _with_app(p, app)
        return p

    def test_succeeds_on_204(self) -> None:
        p = self._provider()
        with patch("httpx.delete") as mock_del:
            mock_del.return_value = httpx.Response(204)
            p.delete_event("ms_evt_1")

    def test_raises_on_non_204(self) -> None:
        p = self._provider()
        with patch("httpx.delete") as mock_del:
            mock_del.return_value = httpx.Response(404)
            with pytest.raises(RuntimeError, match="delete event"):
                p.delete_event("ms_evt_1")


# ── health_check ──────────────────────────────────────────────────────────────


class TestHealthCheck:
    def _provider(self) -> MicrosoftCalendarProvider:
        p = _primary()
        app = _make_msal_app(accounts=[MagicMock()], silent_result={"access_token": "tok"})
        _with_app(p, app)
        return p

    def test_returns_true_on_200(self) -> None:
        p = self._provider()
        with patch("httpx.get") as mock_get:
            mock_get.return_value = httpx.Response(200, json={"id": "me"})
            assert p.health_check() is True

    def test_returns_false_on_401(self) -> None:
        p = self._provider()
        with patch("httpx.get") as mock_get:
            mock_get.return_value = httpx.Response(401)
            assert p.health_check() is False

    def test_returns_false_on_network_error(self) -> None:
        p = self._provider()
        with patch("httpx.get") as mock_get:
            mock_get.side_effect = httpx.ConnectError("timeout")
            assert p.health_check() is False


# ── get_video_link_from_response ──────────────────────────────────────────────


class TestGetVideoLinkFromResponse:
    def test_extracts_teams_join_url(self) -> None:
        p = _primary()
        response = {"onlineMeeting": {"joinUrl": "https://teams.microsoft.com/l/meetup-join/..."}}
        assert p.get_video_link_from_response(response) == "https://teams.microsoft.com/l/meetup-join/..."

    def test_returns_none_when_no_online_meeting(self) -> None:
        p = _primary()
        assert p.get_video_link_from_response({}) is None

    def test_returns_none_when_join_url_absent(self) -> None:
        p = _primary()
        assert p.get_video_link_from_response({"onlineMeeting": {}}) is None


# ── _windows_tz_to_iana ───────────────────────────────────────────────────────


class TestWindowsTzToIana:
    def test_maps_eastern_standard_time(self) -> None:
        assert _windows_tz_to_iana("Eastern Standard Time") == "America/New_York"

    def test_maps_pacific_standard_time(self) -> None:
        assert _windows_tz_to_iana("Pacific Standard Time") == "America/Los_Angeles"

    def test_maps_india_standard_time(self) -> None:
        assert _windows_tz_to_iana("India Standard Time") == "Asia/Kolkata"

    def test_passes_unknown_name_through(self) -> None:
        assert _windows_tz_to_iana("Some Unknown Timezone") == "Some Unknown Timezone"

    def test_utc_maps_to_utc(self) -> None:
        assert _windows_tz_to_iana("UTC") == "UTC"
