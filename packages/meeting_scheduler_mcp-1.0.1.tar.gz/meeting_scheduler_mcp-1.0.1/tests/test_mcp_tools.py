"""
Unit tests for the MCP tool functions in mcp_server.py.

The entire application layer (config loading, provider map, scheduling
engine, booking engine) is replaced with MagicMocks so these tests only
verify that the tool wrappers handle responses and errors correctly.

Coverage
--------
  find_available_slots   happy path: returns slot list
  find_available_slots   ParticipantDomainNotConfigured → error dict
  find_available_slots   NoSlotsFound → error dict with reason
  find_available_slots   FileNotFoundError → CONFIG_NOT_FOUND
  find_available_slots   unexpected Exception → INTERNAL_ERROR

  book_meeting           happy path: returns ok dict
  book_meeting           FileNotFoundError → CONFIG_NOT_FOUND
  book_meeting           RuntimeError → BOOKING_FAILED
  book_meeting           unexpected Exception → INTERNAL_ERROR

  reschedule_meeting     happy path: returns ok dict
  reschedule_meeting     RuntimeError → RESCHEDULE_FAILED

  cancel_meeting         happy path: returns ok message
  cancel_meeting         RuntimeError → CANCEL_FAILED

  list_accounts          happy path: lists all accounts with connected flag
  list_accounts          provider health_check exception → connected: False

  health_check           all healthy: status ok
  health_check           some failing: status degraded + message
  health_check           FileNotFoundError → CONFIG_NOT_FOUND
"""

from __future__ import annotations

from datetime import datetime, timezone
from unittest.mock import MagicMock, patch

import pytest

UTC = timezone.utc


# ── Helpers ───────────────────────────────────────────────────────────────────


def _dt(hour: int) -> datetime:
    return datetime(2024, 6, 10, hour, 0, tzinfo=UTC)


def _make_account(email: str, org: str, provider: str, primary: bool):
    from src.account_manager import AccountConfig
    return AccountConfig(org=org, email=email, provider=provider, is_primary=primary)


def _make_config(*accounts):
    from src.account_manager import AppConfig, SchedulingRules
    return AppConfig(accounts=list(accounts), rules=SchedulingRules())


def _make_slot(start_hour: int, end_hour: int):
    from src.scheduling.models import Slot
    return Slot(start=_dt(start_hour), end=_dt(end_hour))


# ── Reset MCP server module state between tests ───────────────────────────────

@pytest.fixture(autouse=True)
def _reset_mcp_state():
    import mcp_server
    mcp_server._reset_state()
    yield
    mcp_server._reset_state()


# ── find_available_slots ──────────────────────────────────────────────────────


class TestFindAvailableSlots:
    def _call(self, participants=None, duration=30,
              start="2024-06-10T08:00:00Z", end="2024-06-10T18:00:00Z"):
        from mcp_server import find_available_slots
        return find_available_slots(
            participants=participants or ["other@example.com"],
            duration_minutes=duration,
            window_start=start,
            window_end=end,
        )

    def test_happy_path_returns_slot_list(self) -> None:
        slots = [_make_slot(9, 9), _make_slot(11, 11)]
        slots[0].participants_local = {"other@example.com": "9:00 AM UTC"}
        slots[1].participants_local = {}

        config = _make_config(_make_account("me@a.com", "A", "google", True))
        provider_map = {"me@a.com": MagicMock()}

        with patch("mcp_server._get_config", return_value=config), \
             patch("mcp_server._get_provider_map", return_value=provider_map), \
             patch("mcp_server.find_slots", return_value=slots):
            result = self._call()

        assert result["status"] == "ok"
        assert len(result["slots"]) == 2
        assert result["slots"][0]["slot_index"] == 1
        assert result["slots"][1]["slot_index"] == 2

    def test_participant_domain_not_configured(self) -> None:
        from src.scheduling.engine import ParticipantDomainNotConfigured
        config = _make_config(_make_account("me@a.com", "A", "google", True))
        provider_map = {"me@a.com": MagicMock()}

        with patch("mcp_server._get_config", return_value=config), \
             patch("mcp_server._get_provider_map", return_value=provider_map), \
             patch("mcp_server.find_slots",
                   side_effect=ParticipantDomainNotConfigured("other.com")):
            result = self._call()

        assert result["status"] == "error"
        assert result["error_type"] == "PARTICIPANT_DOMAIN_NOT_CONFIGURED"

    def test_no_slots_found(self) -> None:
        from src.scheduling.engine import NoSlotsFound
        config = _make_config(_make_account("me@a.com", "A", "google", True))
        provider_map = {"me@a.com": MagicMock()}

        with patch("mcp_server._get_config", return_value=config), \
             patch("mcp_server._get_provider_map", return_value=provider_map), \
             patch("mcp_server.find_slots",
                   side_effect=NoSlotsFound("ALL_BUSY", "No free slots")):
            result = self._call()

        assert result["status"] == "error"
        assert "NO_SLOTS_FOUND" in result["error_type"]

    def test_config_not_found(self) -> None:
        with patch("mcp_server._get_config", side_effect=FileNotFoundError("missing")):
            result = self._call()

        assert result["status"] == "error"
        assert result["error_type"] == "CONFIG_NOT_FOUND"

    def test_unexpected_exception(self) -> None:
        config = _make_config(_make_account("me@a.com", "A", "google", True))
        provider_map = {"me@a.com": MagicMock()}

        with patch("mcp_server._get_config", return_value=config), \
             patch("mcp_server._get_provider_map", return_value=provider_map), \
             patch("mcp_server.find_slots", side_effect=ValueError("unexpected")):
            result = self._call()

        assert result["status"] == "error"
        assert result["error_type"] == "INTERNAL_ERROR"


# ── book_meeting ──────────────────────────────────────────────────────────────


class TestBookMeeting:
    def _call(self, title="Team Sync", participants=None,
              start="2024-06-10T10:00:00Z", end="2024-06-10T11:00:00Z"):
        from mcp_server import book_meeting
        return book_meeting(
            slot_start=start,
            slot_end=end,
            title=title,
            participants=participants or ["a@a.com"],
            description="Agenda",
        )

    def test_happy_path_returns_ok(self) -> None:
        primary = _make_account("me@a.com", "A", "google", True)
        config = _make_config(primary)
        provider = MagicMock()
        provider.get_mailbox_settings.return_value = MagicMock(timezone="UTC")
        provider_map = {"me@a.com": provider}

        booking_result = {
            "event_id": "evt_1",
            "title": "Team Sync",
            "start_utc": "2024-06-10T10:00:00+00:00",
            "end_utc": "2024-06-10T11:00:00+00:00",
            "participants": ["a@a.com"],
            "video_link": None,
            "organiser": "me@a.com",
        }
        with patch("mcp_server._get_config", return_value=config), \
             patch("mcp_server._get_provider_map", return_value=provider_map), \
             patch("mcp_server._book_meeting", return_value=booking_result):
            result = self._call()

        assert result["status"] == "ok"
        assert result["event_id"] == "evt_1"

    def test_config_not_found(self) -> None:
        with patch("mcp_server._get_config", side_effect=FileNotFoundError("missing")):
            result = self._call()
        assert result["error_type"] == "CONFIG_NOT_FOUND"

    def test_runtime_error_returns_booking_failed(self) -> None:
        primary = _make_account("me@a.com", "A", "google", True)
        config = _make_config(primary)
        provider = MagicMock()
        provider.get_mailbox_settings.return_value = MagicMock(timezone="UTC")
        provider_map = {"me@a.com": provider}

        with patch("mcp_server._get_config", return_value=config), \
             patch("mcp_server._get_provider_map", return_value=provider_map), \
             patch("mcp_server._book_meeting", side_effect=RuntimeError("API down")):
            result = self._call()

        assert result["status"] == "error"
        assert result["error_type"] == "BOOKING_FAILED"

    def test_unexpected_exception(self) -> None:
        primary = _make_account("me@a.com", "A", "google", True)
        config = _make_config(primary)
        provider = MagicMock()
        provider.get_mailbox_settings.return_value = MagicMock(timezone="UTC")
        provider_map = {"me@a.com": provider}

        with patch("mcp_server._get_config", return_value=config), \
             patch("mcp_server._get_provider_map", return_value=provider_map), \
             patch("mcp_server._book_meeting", side_effect=KeyError("oops")):
            result = self._call()

        assert result["error_type"] == "INTERNAL_ERROR"


# ── reschedule_meeting ────────────────────────────────────────────────────────


class TestRescheduleMeeting:
    def _provider_with_event(self, title="Original Title", participants=None):
        provider = MagicMock()
        provider.get_mailbox_settings.return_value = MagicMock(timezone="UTC")
        provider.get_event.return_value = {
            "title": title,
            "description": "Original body",
            "participants": participants or ["a@a.com"],
        }
        return provider

    def _call(self, event_id="evt_1",
              new_start="2024-06-11T10:00:00Z", new_end="2024-06-11T11:00:00Z"):
        from mcp_server import reschedule_meeting
        return reschedule_meeting(
            event_id=event_id,
            new_slot_start=new_start,
            new_slot_end=new_end,
        )

    def test_happy_path_returns_ok(self) -> None:
        primary = _make_account("me@a.com", "A", "google", True)
        config = _make_config(primary)
        provider = self._provider_with_event()
        provider_map = {"me@a.com": provider}

        reschedule_result = {
            "event_id": "evt_1",
            "title": "Original Title",
            "start_utc": "2024-06-11T10:00:00+00:00",
            "end_utc": "2024-06-11T11:00:00+00:00",
            "participants": ["a@a.com"],
            "video_link": None,
            "organiser": "me@a.com",
        }
        with patch("mcp_server._get_config", return_value=config), \
             patch("mcp_server._get_provider_map", return_value=provider_map), \
             patch("mcp_server._reschedule_meeting", return_value=reschedule_result):
            result = self._call()

        assert result["status"] == "ok"
        assert result["event_id"] == "evt_1"

    def test_preserves_original_title_and_participants(self) -> None:
        primary = _make_account("me@a.com", "A", "google", True)
        config = _make_config(primary)
        provider = self._provider_with_event(title="Q3 Review", participants=["x@x.com"])
        provider_map = {"me@a.com": provider}

        captured: list[dict] = []

        def fake_reschedule(**kwargs):
            captured.append(kwargs)
            return {"event_id": "evt_1", "title": kwargs["title"],
                    "start_utc": "", "end_utc": "",
                    "participants": kwargs["participants"],
                    "video_link": None, "organiser": "me@a.com"}

        with patch("mcp_server._get_config", return_value=config), \
             patch("mcp_server._get_provider_map", return_value=provider_map), \
             patch("mcp_server._reschedule_meeting", side_effect=fake_reschedule):
            self._call()

        assert captured[0]["title"] == "Q3 Review"
        assert captured[0]["participants"] == ["x@x.com"]

    def test_get_event_failure_returns_reschedule_failed(self) -> None:
        primary = _make_account("me@a.com", "A", "google", True)
        config = _make_config(primary)
        provider = MagicMock()
        provider.get_mailbox_settings.return_value = MagicMock(timezone="UTC")
        provider.get_event.side_effect = RuntimeError("Event not found")
        provider_map = {"me@a.com": provider}

        with patch("mcp_server._get_config", return_value=config), \
             patch("mcp_server._get_provider_map", return_value=provider_map):
            result = self._call()

        assert result["error_type"] == "RESCHEDULE_FAILED"

    def test_runtime_error_returns_reschedule_failed(self) -> None:
        primary = _make_account("me@a.com", "A", "google", True)
        config = _make_config(primary)
        provider = self._provider_with_event()
        provider_map = {"me@a.com": provider}

        with patch("mcp_server._get_config", return_value=config), \
             patch("mcp_server._get_provider_map", return_value=provider_map), \
             patch("mcp_server._reschedule_meeting", side_effect=RuntimeError("gone")):
            result = self._call()

        assert result["error_type"] == "RESCHEDULE_FAILED"


# ── cancel_meeting ────────────────────────────────────────────────────────────


class TestCancelMeeting:
    def _call(self, event_id="evt_del"):
        from mcp_server import cancel_meeting
        return cancel_meeting(event_id=event_id)

    def test_happy_path_returns_ok_message(self) -> None:
        primary = _make_account("me@a.com", "A", "google", True)
        config = _make_config(primary)
        provider_map = {"me@a.com": MagicMock()}

        with patch("mcp_server._get_config", return_value=config), \
             patch("mcp_server._get_provider_map", return_value=provider_map), \
             patch("mcp_server._cancel_meeting"):
            result = self._call()

        assert result["status"] == "ok"
        assert "evt_del" in result["message"]

    def test_runtime_error_returns_cancel_failed(self) -> None:
        primary = _make_account("me@a.com", "A", "google", True)
        config = _make_config(primary)
        provider_map = {"me@a.com": MagicMock()}

        with patch("mcp_server._get_config", return_value=config), \
             patch("mcp_server._get_provider_map", return_value=provider_map), \
             patch("mcp_server._cancel_meeting", side_effect=RuntimeError("not found")):
            result = self._call()

        assert result["error_type"] == "CANCEL_FAILED"


# ── list_accounts ─────────────────────────────────────────────────────────────


class TestListAccounts:
    def _call(self):
        from mcp_server import list_accounts
        return list_accounts()

    def test_returns_all_accounts(self) -> None:
        primary = _make_account("me@a.com", "OrgA", "google", True)
        shadow = _make_account("me@b.com", "OrgB", "microsoft", False)
        config = _make_config(primary, shadow)

        healthy = MagicMock()
        healthy.health_check.return_value = True
        sick = MagicMock()
        sick.health_check.return_value = False
        provider_map = {"me@a.com": healthy, "me@b.com": sick}

        with patch("mcp_server._get_config", return_value=config), \
             patch("mcp_server._get_provider_map", return_value=provider_map):
            result = self._call()

        assert result["status"] == "ok"
        assert len(result["accounts"]) == 2
        by_email = {a["email"]: a for a in result["accounts"]}
        assert by_email["me@a.com"]["role"] == "primary"
        assert by_email["me@a.com"]["connected"] is True
        assert by_email["me@b.com"]["role"] == "shadow"
        assert by_email["me@b.com"]["connected"] is False

    def test_health_check_exception_means_not_connected(self) -> None:
        primary = _make_account("me@a.com", "A", "google", True)
        config = _make_config(primary)
        crash = MagicMock()
        crash.health_check.side_effect = RuntimeError("boom")
        provider_map = {"me@a.com": crash}

        with patch("mcp_server._get_config", return_value=config), \
             patch("mcp_server._get_provider_map", return_value=provider_map):
            result = self._call()

        assert result["accounts"][0]["connected"] is False


# ── health_check tool ─────────────────────────────────────────────────────────


class TestHealthCheckTool:
    def _call(self):
        from mcp_server import health_check
        return health_check()

    def test_all_healthy_returns_ok(self) -> None:
        primary = _make_account("me@a.com", "A", "google", True)
        config = _make_config(primary)
        healthy = MagicMock()
        healthy.health_check.return_value = True
        provider_map = {"me@a.com": healthy}

        with patch("mcp_server._get_config", return_value=config), \
             patch("mcp_server._get_provider_map", return_value=provider_map):
            result = self._call()

        assert result["status"] == "ok"
        assert "healthy" in result["message"]

    def test_some_failing_returns_degraded(self) -> None:
        primary = _make_account("me@a.com", "A", "google", True)
        shadow = _make_account("me@b.com", "B", "microsoft", False)
        config = _make_config(primary, shadow)

        good = MagicMock()
        good.health_check.return_value = True
        bad = MagicMock()
        bad.health_check.return_value = False
        provider_map = {"me@a.com": good, "me@b.com": bad}

        with patch("mcp_server._get_config", return_value=config), \
             patch("mcp_server._get_provider_map", return_value=provider_map):
            result = self._call()

        assert result["status"] == "degraded"
        assert "me@b.com" in result["message"]

    def test_config_not_found(self) -> None:
        with patch("mcp_server._get_config", side_effect=FileNotFoundError("no config")):
            result = self._call()

        assert result["error_type"] == "CONFIG_NOT_FOUND"
