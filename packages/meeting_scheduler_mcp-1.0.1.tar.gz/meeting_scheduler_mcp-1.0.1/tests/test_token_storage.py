"""
Unit tests for src/token_storage.py.

The OS keychain is replaced with a plain in-memory dict via a keyring
null-backend fixture, so these tests run without touching the real
macOS Keychain / Windows Credential Manager.

The platform-dispatch layer (_get_or_create_key) is forced to the
fallback (Linux) path by patching platform.system, which avoids
needing ctypes / win32crypt in CI.

Coverage
--------
  _encrypt / _decrypt             round-trip and corruption detection
  store / load / delete           public API happy path
  load returns None               when nothing stored
  load returns None               when ciphertext is corrupted
  delete clears both key and tok  nothing loadable after delete
  fallback key create+load        new key generated and persisted
  fallback key reused             same key returned on second call
  delete_google_refresh_token     removes key + token entries
"""

from __future__ import annotations

import base64
import os
from typing import Optional
from unittest.mock import patch

import pytest

import keyring
import keyring.backend


# ── In-memory keyring backend ─────────────────────────────────────────────────


class _MemoryKeyring(keyring.backend.KeyringBackend):
    """Ephemeral in-memory backend — no OS calls."""

    priority = 100  # beats every real backend

    def __init__(self) -> None:
        self._store: dict[tuple[str, str], str] = {}

    def get_password(self, service: str, username: str) -> Optional[str]:
        return self._store.get((service, username))

    def set_password(self, service: str, username: str, password: str) -> None:
        self._store[(service, username)] = password

    def delete_password(self, service: str, username: str) -> None:
        key = (service, username)
        if key not in self._store:
            raise keyring.errors.PasswordDeleteError("not found")
        del self._store[key]


@pytest.fixture(autouse=True)
def _mem_keyring(monkeypatch):
    """Replace the active keyring with an in-memory backend for every test."""
    backend = _MemoryKeyring()
    monkeypatch.setattr(keyring, "get_password", backend.get_password)
    monkeypatch.setattr(keyring, "set_password", backend.set_password)
    monkeypatch.setattr(keyring, "delete_password", backend.delete_password)
    return backend


@pytest.fixture(autouse=True)
def _linux_platform(monkeypatch):
    """Force the platform dispatch to the fallback (Linux) path."""
    monkeypatch.setattr("platform.system", lambda: "Linux")


# ── Import the module under test AFTER fixtures are applied ──────────────────

from src import token_storage  # noqa: E402  (import after monkeypatch fixtures)


# ── AES-256-GCM helpers ───────────────────────────────────────────────────────


class TestEncryptDecrypt:
    def test_round_trip(self) -> None:
        key = os.urandom(32)
        plaintext = "my_refresh_token_abc123"
        ciphertext = token_storage._encrypt(plaintext, key)
        assert token_storage._decrypt(ciphertext, key) == plaintext

    def test_nonce_prepended(self) -> None:
        key = os.urandom(32)
        data = token_storage._encrypt("hello", key)
        assert len(data) > 12  # nonce(12) + tag(16) + at least 5 bytes ciphertext

    def test_different_nonces_each_call(self) -> None:
        key = os.urandom(32)
        ct1 = token_storage._encrypt("same", key)
        ct2 = token_storage._encrypt("same", key)
        assert ct1 != ct2  # each call uses os.urandom nonce

    def test_wrong_key_raises(self) -> None:
        key = os.urandom(32)
        bad_key = os.urandom(32)
        ciphertext = token_storage._encrypt("secret", key)
        with pytest.raises(Exception):
            token_storage._decrypt(ciphertext, bad_key)

    def test_tampered_ciphertext_raises(self) -> None:
        key = os.urandom(32)
        ciphertext = bytearray(token_storage._encrypt("secret", key))
        ciphertext[-1] ^= 0xFF  # flip a bit in the GCM tag
        with pytest.raises(Exception):
            token_storage._decrypt(bytes(ciphertext), key)


# ── Public API: store / load / delete ─────────────────────────────────────────


class TestStoreLoadDelete:
    EMAIL = "user@example.com"
    TOKEN = "1//refresh_token_string"

    def test_store_then_load_returns_token(self) -> None:
        token_storage.store_google_refresh_token(self.EMAIL, self.TOKEN)
        result = token_storage.load_google_refresh_token(self.EMAIL)
        assert result == self.TOKEN

    def test_load_returns_none_when_nothing_stored(self) -> None:
        result = token_storage.load_google_refresh_token("nobody@nowhere.com")
        assert result is None

    def test_overwrite_token(self) -> None:
        token_storage.store_google_refresh_token(self.EMAIL, "old_token")
        token_storage.store_google_refresh_token(self.EMAIL, "new_token")
        assert token_storage.load_google_refresh_token(self.EMAIL) == "new_token"

    def test_delete_makes_load_return_none(self) -> None:
        token_storage.store_google_refresh_token(self.EMAIL, self.TOKEN)
        token_storage.delete_google_refresh_token(self.EMAIL)
        assert token_storage.load_google_refresh_token(self.EMAIL) is None

    def test_delete_is_idempotent(self) -> None:
        token_storage.delete_google_refresh_token(self.EMAIL)  # nothing stored
        token_storage.delete_google_refresh_token(self.EMAIL)  # should not raise

    def test_load_returns_none_on_corrupted_ciphertext(self, monkeypatch) -> None:
        token_storage.store_google_refresh_token(self.EMAIL, self.TOKEN)
        # Overwrite the stored ciphertext with garbage.
        monkeypatch.setattr(
            keyring, "get_password",
            lambda svc, acct: "not-valid-base64!!" if acct.endswith(":refresh-token") else None,
        )
        result = token_storage.load_google_refresh_token(self.EMAIL)
        assert result is None

    def test_different_emails_independent(self) -> None:
        token_storage.store_google_refresh_token("a@a.com", "token_a")
        token_storage.store_google_refresh_token("b@b.com", "token_b")
        assert token_storage.load_google_refresh_token("a@a.com") == "token_a"
        assert token_storage.load_google_refresh_token("b@b.com") == "token_b"

    def test_delete_only_affects_target_email(self) -> None:
        token_storage.store_google_refresh_token("a@a.com", "token_a")
        token_storage.store_google_refresh_token("b@b.com", "token_b")
        token_storage.delete_google_refresh_token("a@a.com")
        assert token_storage.load_google_refresh_token("b@b.com") == "token_b"


# ── Fallback key management ───────────────────────────────────────────────────


class TestFallbackKeyManagement:
    ACCOUNT = "user@example.com:enc-key"

    def test_new_key_generated_and_stored(self) -> None:
        key = token_storage._fallback_get_or_create_key(self.ACCOUNT)
        assert isinstance(key, bytes)
        assert len(key) == 32

    def test_same_key_returned_on_second_call(self) -> None:
        key1 = token_storage._fallback_get_or_create_key(self.ACCOUNT)
        key2 = token_storage._fallback_get_or_create_key(self.ACCOUNT)
        assert key1 == key2

    def test_delete_forces_new_key(self) -> None:
        key1 = token_storage._fallback_get_or_create_key(self.ACCOUNT)
        token_storage._fallback_delete_key(self.ACCOUNT)
        key2 = token_storage._fallback_get_or_create_key(self.ACCOUNT)
        # New key is generated, likely different (collision probability ≈ 0).
        assert isinstance(key2, bytes)
        assert len(key2) == 32
