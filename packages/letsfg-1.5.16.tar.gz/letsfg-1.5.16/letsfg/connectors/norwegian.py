"""
Norwegian Air hybrid scraper — cookie-farm + curl_cffi direct API.

Norwegian's booking engine (booking.norwegian.com) is an Angular 18 SPA that
calls api-des.norwegian.com (Amadeus Digital Experience Suite). The search API
is behind Incapsula, which blocks raw HTTP clients. The token API is NOT
behind Incapsula.

Strategy (hybrid cookie-farm):
1. ONCE per ~25 min: Playwright opens homepage, fills search form, submits.
   This generates valid Incapsula cookies (reese84, visid_incap, etc.).
   Extract all cookies via context.cookies().
2. For each search: curl_cffi uses farmed cookies to:
   a) POST token/initialization → get Bearer access_token (~0.4s)
   b) POST airlines/DY/v2/search/air-bounds → get flight data (~0.6s)
3. Parse airBoundGroups → FlightOffers

Result: ~1s per search instead of ~45s with full Playwright.

API details (discovered Mar 2026):
  Token: POST api-des.norwegian.com/v1/security/oauth2/token/initialization
    Body: client_id, client_secret, grant_type=client_credentials, fact (JSON)
  Search: POST api-des.norwegian.com/airlines/DY/v2/search/air-bounds
    Body: {commercialFareFamilies, itineraries, travelers, searchPreferences}
  Response: {data: {airBoundGroups: [{boundDetails, airBounds: [{prices, ...}]}]}}
  Prices are in CENTS (divide by 100)
  flightId format: SEG-DY1303-LGWOSL-2026-04-15-0920
"""

from __future__ import annotations

import asyncio
import hashlib
import json
import logging
import os
import random
import re
import shutil
import subprocess
import time
from datetime import datetime, timedelta
from typing import Optional

from curl_cffi import requests as cffi_requests

from ..models.flights import (
    FlightOffer,
    FlightRoute,
    FlightSearchRequest,
    FlightSearchResponse,
    FlightSegment,
)
from .airline_routes import get_city_airports
from .browser import stealth_popen_kwargs, find_chrome, _launched_procs, get_curl_cffi_proxies, proxy_chrome_args, auto_block_if_proxied

logger = logging.getLogger(__name__)

_VIEWPORTS = [
    {"width": 1366, "height": 768},
    {"width": 1440, "height": 900},
    {"width": 1920, "height": 1080},
    {"width": 1280, "height": 720},
]
_LOCALES = ["en-GB", "en-US", "en-IE"]
_TIMEZONES = ["Europe/London", "Europe/Berlin", "Europe/Oslo", "Europe/Paris"]

_CLIENT_ID = "YnF1uDBnJMWsGEmAndoGljO0DgkBeWaE"
_CLIENT_SECRET = "mrYaim0FdBrNRRZf"
_TOKEN_URL = "https://api-des.norwegian.com/v1/security/oauth2/token/initialization"
_SEARCH_URL = "https://api-des.norwegian.com/airlines/DY/v2/search/air-bounds"
_IMPERSONATE = "chrome131"
_UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36"
_COOKIE_MAX_AGE = 25 * 60  # Re-farm cookies after 25 minutes
_DEBUG_PORT = 9460
_USER_DATA_DIR = os.path.join(
    os.path.dirname(os.path.abspath(__file__)), "..", ".norwegian_chrome_profile"
)

# Shared cookie farm state
_farm_lock: Optional[asyncio.Lock] = None
_farmed_cookies: list[dict] = []
_farm_timestamp: float = 0.0
_pw_instance = None
_browser = None
_chrome_proc = None


def _get_farm_lock() -> asyncio.Lock:
    global _farm_lock
    if _farm_lock is None:
        _farm_lock = asyncio.Lock()
    return _farm_lock


async def _get_browser():
    """Launch real headed Chrome via CDP for cookie farming (Incapsula blocks headless)."""
    global _pw_instance, _browser, _chrome_proc
    if _browser:
        try:
            if _browser.is_connected():
                return _browser
        except Exception:
            pass

    from playwright.async_api import async_playwright

    # Try connecting to existing Chrome on the port first
    pw = None
    try:
        pw = await async_playwright().start()
        _browser = await pw.chromium.connect_over_cdp(f"http://127.0.0.1:{_DEBUG_PORT}")
        _pw_instance = pw
        logger.info("Norwegian: connected to existing Chrome on port %d", _DEBUG_PORT)
        return _browser
    except Exception:
        if pw:
            try:
                await pw.stop()
            except Exception:
                pass

    # Launch Chrome HEADED (no --headless) — Incapsula blocks headless Chrome.
    chrome = find_chrome()
    os.makedirs(_USER_DATA_DIR, exist_ok=True)
    args = [
        chrome,
        f"--remote-debugging-port={_DEBUG_PORT}",
        f"--user-data-dir={_USER_DATA_DIR}",
        "--no-first-run",
        *proxy_chrome_args(),
        "--no-default-browser-check",
        "--disable-blink-features=AutomationControlled",
        "--disable-http2",
        "--window-position=-2400,-2400",
        "--window-size=1366,768",
        "about:blank",
    ]
    _chrome_proc = subprocess.Popen(args, **stealth_popen_kwargs())
    _launched_procs.append(_chrome_proc)
    await asyncio.sleep(2.0)

    pw = await async_playwright().start()
    _pw_instance = pw
    _browser = await pw.chromium.connect_over_cdp(f"http://127.0.0.1:{_DEBUG_PORT}")
    logger.info("Norwegian: Chrome launched headed on CDP port %d (pid %d)", _DEBUG_PORT, _chrome_proc.pid)
    return _browser


async def _reset_chrome_profile():
    """Kill Chrome and wipe the profile so next farm gets a fresh start."""
    global _browser, _pw_instance, _chrome_proc, _farmed_cookies, _farm_timestamp
    logger.info("Norwegian: resetting Chrome profile for fresh Incapsula farm")
    if _browser:
        try:
            await _browser.close()
        except Exception:
            pass
        _browser = None
    if _pw_instance:
        try:
            await _pw_instance.stop()
        except Exception:
            pass
        _pw_instance = None
    if _chrome_proc:
        try:
            _chrome_proc.terminate()
            _chrome_proc.wait(timeout=5)
        except Exception:
            try:
                _chrome_proc.kill()
            except Exception:
                pass
        _chrome_proc = None
    _farmed_cookies = []
    _farm_timestamp = 0.0
    if os.path.isdir(_USER_DATA_DIR):
        try:
            shutil.rmtree(_USER_DATA_DIR)
            logger.info("Norwegian: deleted stale Chrome profile %s", _USER_DATA_DIR)
        except Exception as e:
            logger.warning("Norwegian: failed to delete Chrome profile: %s", e)


class NorwegianConnectorClient:
    """Norwegian hybrid scraper — cookie-farm + curl_cffi direct API."""

    def __init__(self, timeout: float = 45.0):
        self.timeout = timeout

    async def close(self):
        pass  # Browser is shared singleton

    async def search_flights(self, req: FlightSearchRequest) -> FlightSearchResponse:
        """
        Search Norwegian flights via cookie-farm + curl_cffi direct API.

        Norwegian requires airport codes (LGW, LTN), not city codes (LON).
        Expands city codes and merges results.
        """
        origins = get_city_airports(req.origin)
        destinations = get_city_airports(req.destination)

        if len(origins) > 1 or len(destinations) > 1:
            all_offers: list[FlightOffer] = []
            for o in origins:
                for d in destinations:
                    if o == d:
                        continue
                    sub_req = FlightSearchRequest(
                        origin=o,
                        destination=d,
                        date_from=req.date_from,
                        return_from=req.return_from,
                        adults=req.adults,
                        children=req.children,
                        infants=req.infants,
                        cabin_class=req.cabin_class,
                        currency=req.currency,
                        max_stopovers=req.max_stopovers,
                    )
                    try:
                        resp = await self._search_single(sub_req)
                        all_offers.extend(resp.offers)
                    except Exception:
                        pass
            all_offers.sort(key=lambda o: o.price)
            search_hash = hashlib.md5(
                f"norwegian{req.origin}{req.destination}{req.date_from}".encode()
            ).hexdigest()[:12]
            return FlightSearchResponse(
                search_id=f"fs_{search_hash}",
                origin=req.origin,
                destination=req.destination,
                currency=all_offers[0].currency if all_offers else req.currency,
                offers=all_offers,
                total_results=len(all_offers),
            )
        return await self._search_single(req)

    async def _search_single(self, req: FlightSearchRequest) -> FlightSearchResponse:
        """Search a single origin→destination pair (airport-level codes).

        Fast path (~2s): curl_cffi direct API call (with or without cookies).
        Slow path (~30s): Full Playwright browser + API interception.
        """
        t0 = time.monotonic()

        try:
            data = None

            # Try curl_cffi with cached cookies (fastest)
            if _farmed_cookies and (time.monotonic() - _farm_timestamp) < _COOKIE_MAX_AGE:
                data = await self._api_search(req, _farmed_cookies)
                if data:
                    logger.info("Norwegian: curl_cffi fast path succeeded (cached cookies)")

            # Try curl_cffi WITHOUT cookies — OAuth2 client_credentials may work
            if not data:
                logger.info("Norwegian: trying API without cookies (direct OAuth2)")
                data = await self._api_search(req, [])
                if data:
                    logger.info("Norwegian: API without cookies succeeded!")

            # Try API without proxy — GCP IP may not be flagged by Incapsula
            if not data:
                logger.info("Norwegian: trying API without proxy")
                data = await self._api_search(req, [], use_proxy=False)
                if data:
                    logger.info("Norwegian: API without proxy succeeded!")

            # Playwright fallback — fills form in browser, intercepts API response
            if not data:
                logger.info("Norwegian: using Playwright search (API failed)")
                data = await self._playwright_search(req)

            if not data:
                logger.warning("Norwegian: no data after all attempts")
                return self._empty(req)

            elapsed = time.monotonic() - t0
            offers = self._parse_air_bounds(data, req)
            offers.sort(key=lambda o: o.price)

            logger.info(
                "Norwegian %s→%s returned %d offers in %.1fs (hybrid API)",
                req.origin, req.destination, len(offers), elapsed,
            )

            search_hash = hashlib.md5(
                f"norwegian{req.origin}{req.destination}{req.date_from}".encode()
            ).hexdigest()[:12]

            return FlightSearchResponse(
                search_id=f"fs_{search_hash}",
                origin=req.origin,
                destination=req.destination,
                currency=offers[0].currency if offers else req.currency,
                offers=offers,
                total_results=len(offers),
            )

        except Exception as e:
            logger.error("Norwegian hybrid error: %s", e)
            return self._empty(req)

    # ------------------------------------------------------------------
    # Cookie farm — Playwright generates Incapsula cookies
    # ------------------------------------------------------------------

    async def _ensure_cookies(self, req: FlightSearchRequest) -> list[dict]:
        """Return valid farmed cookies, farming new ones if needed."""
        global _farmed_cookies, _farm_timestamp
        lock = _get_farm_lock()
        async with lock:
            age = time.monotonic() - _farm_timestamp
            if _farmed_cookies and age < _COOKIE_MAX_AGE:
                return _farmed_cookies
            return await self._farm_cookies(req)

    async def _farm_cookies(self, req: FlightSearchRequest) -> list[dict]:
        """Visit booking.norwegian.com to get valid Incapsula cookies."""
        global _farmed_cookies, _farm_timestamp

        browser = await _get_browser()
        context = browser.contexts[0] if browser.contexts else await browser.new_context(
            viewport=random.choice(_VIEWPORTS),
        )

        try:
            page = await context.new_page()
            await auto_block_if_proxied(page)

            logger.info("Norwegian: farming Incapsula cookies from booking.norwegian.com")
            await page.goto(
                "https://booking.norwegian.com/booking/",
                wait_until="domcontentloaded",
                timeout=30000,
            )
            await asyncio.sleep(3)

            cookies = await context.cookies()
            if cookies:
                _farmed_cookies = cookies
                _farm_timestamp = time.monotonic()
                incap = [c for c in cookies if "incap" in c["name"].lower() or "reese84" in c["name"].lower()]
                logger.info("Norwegian: farmed %d cookies (%d Incapsula)", len(cookies), len(incap))
            return cookies

        except Exception as e:
            logger.error("Norwegian: cookie farm error: %s", e)
            return []
        finally:
            try:
                await page.close()
            except Exception:
                pass

    async def _playwright_search(self, req: FlightSearchRequest) -> Optional[dict]:
        """Playwright search via direct results page navigation + API interception.

        Tries pre-warmed CDP Chrome first, then fresh Playwright Chromium as fallback.
        """
        # Avaday results page URL format (discovered from form submission)
        d_month = req.date_from.strftime("%Y%m")  # e.g., 202609
        d_day = req.date_from.day
        avaday_params = (
            f"?AdultCount={req.adults}"
            f"&A_City={req.destination}&D_City={req.origin}"
            f"&D_Month={d_month}&D_Day={d_day}"
            f"&IncludeTransit=1&TripType=1"
            f"&ChildCount={req.children or 0}&InfantCount={req.infants or 0}"
        )
        avaday_url = f"https://www.norwegian.com/en/start/booking/avaday/{avaday_params}"

        # Also keep homepage params for fallback form fill
        date_str = req.date_from.strftime("%d/%m/%Y")
        homepage_params = (
            f"?D_City={req.origin}&A_City={req.destination}"
            f"&TripType=1&D_Day={date_str}"
            f"&AdultCount={req.adults}"
            f"&ChildCount={req.children or 0}"
            f"&InfantCount={req.infants or 0}"
        )

        # Try pre-warmed Chrome first (goes through proxy)
        result = await self._try_browser_search(req, avaday_url, homepage_params, use_cdp=True)
        if result:
            return result

        # CF blocked through proxy — try fresh system Chrome without proxy
        logger.info("Norwegian PW: trying fresh Chromium without proxy")
        result = await self._try_browser_search(req, avaday_url, homepage_params, use_cdp=False)
        return result

    async def _try_browser_search(
        self, req: FlightSearchRequest, avaday_url: str, homepage_params: str, use_cdp: bool
    ) -> Optional[dict]:
        """Run a single browser search attempt.

        use_cdp=True: connect to pre-warmed Chrome (with proxy)
        use_cdp=False: launch fresh Playwright Chromium (no proxy, GCP direct IP)
        """
        from playwright.async_api import async_playwright

        pw = None
        browser = None
        own_browser = False

        try:
            if use_cdp:
                browser = await _get_browser()
            else:
                pw = await async_playwright().start()
                # Use system Chrome (cleaner fingerprint than Playwright Chromium)
                chrome_path = find_chrome()
                browser = await pw.chromium.launch(
                    executable_path=chrome_path,
                    headless=False,
                    args=[
                        "--disable-blink-features=AutomationControlled",
                        "--disable-http2",
                        "--no-first-run",
                        "--no-default-browser-check",
                        "--window-position=-2400,-2400",
                        "--window-size=1366,768",
                    ],
                )
                own_browser = True
                logger.info("Norwegian PW: launched system Chrome (no proxy): %s", chrome_path)

            context = await browser.new_context(
                viewport=random.choice(_VIEWPORTS),
            )

            # Stealth: inject anti-detection patches before any page loads
            await context.add_init_script("""
                Object.defineProperty(navigator, 'webdriver', { get: () => undefined });
                delete navigator.__proto__.webdriver;
                Object.defineProperty(navigator, 'languages', { get: () => ['en-US', 'en'] });
                Object.defineProperty(navigator, 'plugins', {
                    get: () => [1, 2, 3, 4, 5],
                });
                const origQuery = window.navigator.permissions.query;
                window.navigator.permissions.query = (p) =>
                    p.name === 'notifications' ? Promise.resolve({ state: Notification.permission }) : origQuery(p);
                window.chrome = { runtime: {}, loadTimes: function(){}, csi: function(){} };
            """)
        except Exception as e:
            logger.warning("Norwegian PW: browser setup failed (cdp=%s): %s", use_cdp, e)
            if pw:
                try:
                    await pw.stop()
                except Exception:
                    pass
            return None

        search_data: dict = {}
        api_seen: list[str] = []

        async def _on_response(response):
            url = response.url
            ct = response.headers.get("content-type", "")
            # Log ALL API responses with JSON containing flight-related data
            if response.status == 200 and "json" in ct:
                # Skip analytics, fonts, images
                if any(x in url.lower() for x in ["analytics", "fonts", "images", "tracking", "pixel", "gtag"]):
                    return
                try:
                    text = await response.text()
                    # Only log if it looks like flight data
                    if any(kw in text.lower() for kw in ["airbound", "flight", "price", "fare", "segment", "departure", "arrival"]):
                        api_seen.append(url[:150])
                        logger.info("Norwegian PW JSON flight-related: %s (%d chars)", url[:100], len(text))
                        # Try to parse and check structure
                        try:
                            data = json.loads(text)
                            if isinstance(data, dict):
                                keys = list(data.keys())[:10]
                                logger.info("Norwegian PW: response keys: %s", keys)
                                # Capture any flight data structure we find
                                if data.get("data") or data.get("airBoundGroups") or data.get("flights") or data.get("offers") or "bound" in str(keys).lower():
                                    search_data.update(data)
                                    logger.info("Norwegian: captured flight data from %s", url[:80])
                        except json.JSONDecodeError:
                            pass
                except Exception:
                    pass
            # Also log specific API endpoints we already know about
            if "api-des.norwegian" in url or "air-bounds" in url:
                logger.info("Norwegian PW known API: %d %s", response.status, url[:150])

        page = await context.new_page()
        page.on("response", _on_response)

        tag = "cdp" if use_cdp else "fresh"
        # CDP CF wait is shorter since we have a fallback; fresh gets more time
        cf_max_wait = 12 if use_cdp else 20

        try:
            # Strategy 1: Try direct results page (avaday)
            logger.info("Norwegian PW[%s]: trying avaday results: %s", tag, avaday_url[:100])

            await page.goto(avaday_url, wait_until="domcontentloaded", timeout=40000)
            logger.info("Norwegian PW[%s]: DOM loaded, URL: %s", tag, page.url[:120])

            cf_resolved = await self._wait_cf_challenge(page, max_wait=cf_max_wait)
            if not cf_resolved:
                logger.warning("Norwegian PW[%s]: CF blocked on avaday", tag)
                return None

            # Wait for networkidle — results page loads data via API
            try:
                await page.wait_for_load_state("networkidle", timeout=15000)
            except Exception:
                pass

            await self._dismiss_cookies(page)

            # Wait for air-bounds API response (avaday page loads results automatically)
            logger.info("Norwegian PW[%s]: waiting for API data on results page...", tag)
            wait_start = time.monotonic()
            while not search_data and time.monotonic() - wait_start < 25:
                await asyncio.sleep(0.5)
            if search_data:
                logger.info("Norwegian PW[%s]: got data from results page!", tag)

            # Strategy B: If no data, try homepage as fallback
            if not search_data:
                homepage_url = f"https://www.norwegian.com/en/{homepage_params}"
                logger.info("Norwegian PW[%s]: no data from avaday, trying homepage: %s", tag, homepage_url[:100])

                await page.goto(homepage_url, wait_until="domcontentloaded", timeout=30000)

                cf_resolved = await self._wait_cf_challenge(page, max_wait=10)
                if cf_resolved:
                    try:
                        await page.wait_for_load_state("networkidle", timeout=8000)
                    except Exception:
                        pass

                    await self._dismiss_cookies(page)

                    # Fill form and submit
                    try:
                        await self._fill_search_form(page, req)
                        await self._click_search(page)
                        logger.info("Norwegian PW[%s]: homepage form submitted", tag)

                        deadline = time.monotonic() + 20
                        while not search_data and time.monotonic() < deadline:
                            await asyncio.sleep(0.5)
                    except Exception as e:
                        logger.info("Norwegian PW[%s]: homepage form failed: %s", tag, e)

            if search_data:
                global _farmed_cookies, _farm_timestamp
                cookies = await context.cookies()
                if cookies:
                    _farmed_cookies = cookies
                    _farm_timestamp = time.monotonic()
                    logger.info("Norwegian: refreshed %d cookies from PW search", len(cookies))
                return search_data

            logger.warning("Norwegian PW[%s]: no data. URL: %s | API: %s", tag, page.url[:120], api_seen)
            return None

        except Exception as e:
            logger.error("Norwegian PW[%s]: error: %s", tag, e)
            return None
        finally:
            try:
                await page.close()
            except Exception:
                pass
            try:
                await context.close()
            except Exception:
                pass
            if own_browser:
                try:
                    await browser.close()
                except Exception:
                    pass
            if pw and not use_cdp:
                try:
                    await pw.stop()
                except Exception:
                    pass

    async def _wait_cf_challenge(self, page, max_wait: int = 20) -> bool:
        """Wait for Cloudflare challenge to resolve. Returns True if resolved."""
        for i in range(max_wait // 2):
            title = (await page.title()).lower()
            url = page.url
            if "just a moment" in title or "cf_chl" in url or "__cf_chl" in url:
                if i == 0:
                    logger.info("Norwegian PW: CF challenge detected")
                # Try clicking Turnstile checkbox at multiple intervals
                if i in (2, 4, 6, 8):
                    try:
                        # Method 1: iframe-based Turnstile
                        cf_frame = page.frame_locator("iframe[src*='challenges']").first
                        checkbox = cf_frame.locator("input[type='checkbox'], .cb-i, .ctp-checkbox-label")
                        if await checkbox.count() > 0:
                            await checkbox.first.click(timeout=2000)
                            logger.info("Norwegian PW: clicked Turnstile checkbox (i=%d)", i)
                            await asyncio.sleep(3)
                            continue
                    except Exception:
                        pass
                    try:
                        # Method 2: click center of Turnstile iframe
                        frames = page.locator("iframe[src*='challenges'], iframe[src*='turnstile']")
                        if await frames.count() > 0:
                            box = await frames.first.bounding_box()
                            if box:
                                await page.mouse.click(
                                    box["x"] + box["width"] / 2,
                                    box["y"] + box["height"] / 2,
                                )
                                logger.info("Norwegian PW: clicked Turnstile iframe center (i=%d)", i)
                                await asyncio.sleep(3)
                                continue
                    except Exception:
                        pass
                await asyncio.sleep(2)
            else:
                if i > 0:
                    logger.info("Norwegian PW: CF resolved after %ds", i * 2)
                return True
        logger.warning("Norwegian PW: CF did not resolve after %ds", max_wait)
        return False

    # ------------------------------------------------------------------
    # Direct API via curl_cffi
    # ------------------------------------------------------------------

    async def _api_search(
        self, req: FlightSearchRequest, cookies: list[dict], use_proxy: bool = True
    ) -> Optional[dict]:
        """Get token + search via curl_cffi with farmed cookies."""
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, self._api_search_sync, req, cookies, use_proxy)

    def _api_search_sync(
        self, req: FlightSearchRequest, cookies: list[dict], use_proxy: bool = True
    ) -> Optional[dict]:
        """Synchronous curl_cffi token + search."""
        proxies = get_curl_cffi_proxies() if use_proxy else {}
        sess = cffi_requests.Session(impersonate=_IMPERSONATE, proxies=proxies)

        # Load farmed cookies into session
        for c in cookies:
            domain = c.get("domain", "")
            sess.cookies.set(c["name"], c["value"], domain=domain)

        # Step 1: Get OAuth2 token
        date_str = req.date_from.strftime("%Y-%m-%dT00:00:00")
        fact = json.dumps({
            "keyValuePairs": [
                {"key": "originLocationCode1", "value": req.origin},
                {"key": "destinationLocationCode1", "value": req.destination},
                {"key": "departureDateTime1", "value": date_str},
                {"key": "market", "value": "EN"},
                {"key": "channel", "value": "B2C"},
            ]
        })

        try:
            r_token = sess.post(
                _TOKEN_URL,
                data={
                    "client_id": _CLIENT_ID,
                    "client_secret": _CLIENT_SECRET,
                    "grant_type": "client_credentials",
                    "fact": fact,
                },
                headers={
                    "User-Agent": _UA,
                    "Origin": "https://booking.norwegian.com",
                    "Referer": "https://booking.norwegian.com/",
                },
                timeout=15,
            )
        except Exception as e:
            logger.error("Norwegian: token request failed: %s", e)
            return None

        if r_token.status_code != 200:
            logger.warning("Norwegian: token returned %d (proxy=%s)", r_token.status_code, use_proxy)
            return None

        access_token = r_token.json().get("access_token")
        if not access_token:
            logger.warning("Norwegian: no access_token in response (proxy=%s)", use_proxy)
            return None

        # Step 2: Search flights
        search_body = {
            "commercialFareFamilies": ["DYSTD"],
            "itineraries": [{
                "originLocationCode": req.origin,
                "destinationLocationCode": req.destination,
                "departureDateTime": f"{date_str}.000",
                "directFlights": False,
                "originLocationType": "airport",
                "destinationLocationType": "airport",
                "isRequestedBound": True,
            }],
            "travelers": self._build_travelers(req),
            "searchPreferences": {"showSoldOut": True, "showMilesPrice": False},
        }

        try:
            r_search = sess.post(
                _SEARCH_URL,
                json=search_body,
                headers={
                    "User-Agent": _UA,
                    "Authorization": f"Bearer {access_token}",
                    "Origin": "https://booking.norwegian.com",
                    "Referer": "https://booking.norwegian.com/",
                    "Content-Type": "application/json",
                    "Accept": "application/json, text/plain, */*",
                },
                timeout=30,
            )
        except Exception as e:
            logger.error("Norwegian: search request failed: %s", e)
            return None

        if r_search.status_code != 200:
            logger.warning("Norwegian: search returned %d (proxy=%s)", r_search.status_code, use_proxy)
            return None

        return r_search.json()

    @staticmethod
    def _build_travelers(req: FlightSearchRequest) -> list[dict]:
        travelers = []
        for _ in range(req.adults):
            travelers.append({"passengerTypeCode": "ADT"})
        for _ in range(req.children or 0):
            travelers.append({"passengerTypeCode": "CHD"})
        for _ in range(req.infants or 0):
            travelers.append({"passengerTypeCode": "INF"})
        return travelers or [{"passengerTypeCode": "ADT"}]

    # ------------------------------------------------------------------
    # Form interaction for cookie farming (selectors verified Mar 2026)
    # ------------------------------------------------------------------

    async def _dismiss_cookies(self, page) -> None:
        """Remove OneTrust cookie banner — click accept first, then JS cleanup."""
        try:
            for label in ["Accept All Cookies", "Accept all", "Accept"]:
                btn = page.get_by_role("button", name=label)
                if await btn.count() > 0:
                    await btn.first.click(timeout=3000)
                    await asyncio.sleep(0.5)
                    break
        except Exception:
            pass
        try:
            await page.evaluate("""() => {
                const ot = document.getElementById('onetrust-consent-sdk');
                if (ot) ot.remove();
                document.querySelectorAll('[class*="cookie"], [id*="cookie"], [class*="consent"]')
                    .forEach(el => { if (el.offsetHeight > 0) el.remove(); });
            }""")
        except Exception:
            pass

    async def _fill_search_form(self, page, req: FlightSearchRequest) -> None:
        """Fill the Norwegian homepage search form (one-way, airports only).
        Date is passed via URL params (?D_Day=...) so we skip date filling.
        """
        # Wait briefly for form to be interactive
        try:
            await page.locator("#flight__airport-select-outbound").wait_for(
                state="visible", timeout=5000
            )
        except Exception:
            logger.debug("Norwegian: airport input not found, trying anyway")

        # Select one-way — click the text label
        try:
            await page.get_by_text("One-way").click(timeout=2000)
            await asyncio.sleep(0.2)
        except Exception:
            pass

        # Fill From airport — fast path via ID
        await self._fill_airport_fast(page, "outbound", req.origin)
        await asyncio.sleep(0.3)

        # Fill To airport
        await self._fill_airport_fast(page, "inbound", req.destination)
        await asyncio.sleep(0.2)

        # Skip date — URL params (D_Day) handle it

    async def _fill_airport_fast(self, page, direction: str, iata: str) -> None:
        """Fill airport by ID for speed (homepage-specific)."""
        input_id = f"flight__airport-select-{direction}"
        try:
            field = page.locator(f"#{input_id}")
            await field.click(timeout=2000)
            await asyncio.sleep(0.2)
            await field.fill(iata)
            await asyncio.sleep(0.8)  # wait for autocomplete

            # Click the option containing (IATA)
            option = page.get_by_role("button", name=re.compile(
                rf"\({re.escape(iata)}\)", re.IGNORECASE
            )).first
            await option.click(timeout=3000)
            logger.info("Norwegian PW: filled %s = %s", direction, iata)
        except Exception as e:
            logger.warning("Norwegian PW: %s field error: %s", direction, e)

    async def _click_search(self, page) -> None:
        """Click the search button (Norwegian uses 'SearchButton' text on homepage)."""
        try:
            # Try SearchButton (homepage text) first
            btn = page.locator("button.nas-button--primary").filter(
                has_text=re.compile(r"SearchButton|Search and book", re.IGNORECASE)
            ).first
            await btn.click(timeout=5000)
        except Exception:
            try:
                await page.get_by_role("button", name="Search and book").click(timeout=3000)
            except Exception:
                try:
                    await page.locator("button[type='submit']").first.click(timeout=3000)
                except Exception:
                    await page.keyboard.press("Enter")

    # ------------------------------------------------------------------
    # Response parsing
    # ------------------------------------------------------------------

    def _parse_air_bounds(self, data: dict, req: FlightSearchRequest) -> list[FlightOffer]:
        """Parse Amadeus DES air-bounds response into FlightOffers."""
        offers: list[FlightOffer] = []
        groups = data.get("data", {}).get("airBoundGroups", [])
        booking_url = self._build_booking_url(req)

        for group in groups:
            bound_details = group.get("boundDetails", {})
            segments_raw = bound_details.get("segments", [])
            duration = bound_details.get("duration", 0)  # seconds

            # Parse segments from flightIds
            segments = self._parse_segments(segments_raw)
            if not segments:
                continue

            # Fix arrival times using bound duration
            self._fix_arrival_times(segments, duration)

            stopovers = max(len(segments) - 1, 0)

            route = FlightRoute(
                segments=segments,
                total_duration_seconds=max(duration, 0),
                stopovers=stopovers,
            )

            # Get cheapest fare from airBounds (LOWFARE < LOWPLUS < FLEX)
            for air_bound in group.get("airBounds", []):
                fare_family = air_bound.get("fareFamilyCode", "")
                if fare_family != "LOWFARE":
                    continue  # Only take cheapest fare family

                total_prices = air_bound.get("prices", {}).get("totalPrices", [])
                if not total_prices:
                    continue

                price_obj = total_prices[0]
                total_cents = price_obj.get("total", 0)
                currency = price_obj.get("currencyCode", "EUR")
                price = total_cents / 100.0  # Prices are in cents

                if price <= 0:
                    continue

                flight_ids = "_".join(s.get("flightId", "") for s in segments_raw)
                key = f"{flight_ids}_{fare_family}_{total_cents}"

                offer = FlightOffer(
                    id=f"dy_{hashlib.md5(key.encode()).hexdigest()[:12]}",
                    price=round(price, 2),
                    currency=currency,
                    price_formatted=f"{price:.2f} {currency}",
                    outbound=route,
                    inbound=None,
                    airlines=["Norwegian"],
                    owner_airline="DY",
                    booking_url=booking_url,
                    is_locked=False,
                    source="norwegian_api",
                    source_tier="free",
                )
                offers.append(offer)
                break  # Only one offer per group (cheapest)

        return offers

    def _parse_segments(self, segments_raw: list) -> list[FlightSegment]:
        """Parse segments from flightId strings.

        flightId format: SEG-DY1303-LGWOSL-2026-04-15-0920
        → carrier=DY, number=1303, origin=LGW, dest=OSL, date=2026-04-15, time=09:20
        """
        segments: list[FlightSegment] = []

        for seg_info in segments_raw:
            flight_id = seg_info.get("flightId", "")
            match = re.match(
                r"SEG-([A-Z0-9]{2})(\d+)-([A-Z]{3})([A-Z]{3})-(\d{4}-\d{2}-\d{2})-(\d{4})",
                flight_id,
            )
            if not match:
                logger.debug("Norwegian: could not parse flightId: %s", flight_id)
                continue

            carrier = match.group(1)
            number = match.group(2)
            origin = match.group(3)
            dest = match.group(4)
            date_str = match.group(5)
            time_str = match.group(6)

            dep_dt = datetime.strptime(
                f"{date_str} {time_str[:2]}:{time_str[2:]}", "%Y-%m-%d %H:%M"
            )

            segments.append(FlightSegment(
                airline=carrier,
                airline_name="Norwegian",
                flight_no=f"{carrier}{number}",
                origin=origin,
                destination=dest,
                departure=dep_dt,
                arrival=dep_dt,  # Placeholder — fixed by _fix_arrival_times
                cabin_class="M",
            ))

        return segments

    def _fix_arrival_times(self, segments: list[FlightSegment], duration_seconds: int) -> None:
        """Fix placeholder arrival times using total bound duration."""
        if len(segments) == 1 and duration_seconds > 0:
            segments[0] = FlightSegment(
                airline=segments[0].airline,
                airline_name=segments[0].airline_name,
                flight_no=segments[0].flight_no,
                origin=segments[0].origin,
                destination=segments[0].destination,
                departure=segments[0].departure,
                arrival=segments[0].departure + timedelta(seconds=duration_seconds),
                cabin_class=segments[0].cabin_class,
            )
        elif len(segments) > 1 and duration_seconds > 0:
            # For multi-segment: set last segment's arrival from total duration
            segments[-1] = FlightSegment(
                airline=segments[-1].airline,
                airline_name=segments[-1].airline_name,
                flight_no=segments[-1].flight_no,
                origin=segments[-1].origin,
                destination=segments[-1].destination,
                departure=segments[-1].departure,
                arrival=segments[0].departure + timedelta(seconds=duration_seconds),
                cabin_class=segments[-1].cabin_class,
            )

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    def _build_booking_url(self, req: FlightSearchRequest) -> str:
        date_str = req.date_from.strftime("%d/%m/%Y")
        return (
            f"https://www.norwegian.com/en/"
            f"?D_City={req.origin}&A_City={req.destination}"
            f"&TripType=1&D_Day={date_str}"
            f"&AdultCount={req.adults}"
            f"&ChildCount={req.children or 0}"
            f"&InfantCount={req.infants or 0}"
        )

    def _empty(self, req: FlightSearchRequest) -> FlightSearchResponse:
        search_hash = hashlib.md5(
            f"norwegian{req.origin}{req.destination}{req.date_from}".encode()
        ).hexdigest()[:12]
        return FlightSearchResponse(
            search_id=f"fs_{search_hash}",
            origin=req.origin,
            destination=req.destination,
            currency=req.currency,
            offers=[],
            total_results=0,
        )
