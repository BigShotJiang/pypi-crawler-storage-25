"""Scheduler Cron"""

from __future__ import annotations

import signal
import threading
from collections.abc import Callable
from datetime import datetime
from time import sleep

from dotflow.abc.scheduler import Scheduler
from dotflow.core.exception import ModuleNotFound
from dotflow.core.types.overlap import TypeOverlap
from dotflow.logging import logger


class SchedulerCron(Scheduler):
    """
    Import:
        You can import the **SchedulerCron** class with:

            from dotflow.providers import SchedulerCron

    Example:
        `class` dotflow.providers.scheduler_cron.SchedulerCron

            from dotflow import DotFlow, Config
            from dotflow.providers import SchedulerCron

            config = Config(
                scheduler=SchedulerCron(
                    cron="*/5 * * * *",
                    overlap="skip",
                )
            )

            workflow = DotFlow(config=config)
            workflow.task.add(step=extract)
            workflow.task.add(step=load)
            workflow.schedule()

    Args:
        cron (str): A cron expression defining the schedule
            (e.g. ``"*/5 * * * *"`` for every 5 minutes).

        overlap (str): Strategy when a previous run is still active.
            One of ``"skip"``, ``"queue"``, or ``"parallel"``.
            Defaults to ``"skip"``.

    Attributes:
        cron (str): The cron expression.

        overlap (str): The overlap strategy.

        running (bool): Whether the scheduler loop is active.
    """

    def __init__(
        self,
        cron: str,
        overlap: str = TypeOverlap.SKIP,
    ) -> None:
        try:
            from croniter import croniter  # noqa: F401
        except ImportError as err:
            raise ModuleNotFound(
                module="croniter", library="dotflow[scheduler]"
            ) from err

        try:
            croniter(cron, datetime.now())
        except (ValueError, KeyError) as err:
            raise ValueError(
                f"Invalid cron expression {cron!r}: {err}"
            ) from err

        valid_overlaps = {
            TypeOverlap.SKIP,
            TypeOverlap.QUEUE,
            TypeOverlap.PARALLEL,
        }
        if overlap not in valid_overlaps:
            raise ValueError(
                f"Invalid overlap {overlap!r}. "
                f"Must be one of: {sorted(valid_overlaps)}"
            )

        self.cron = cron
        self.overlap = overlap
        self.running = False
        self._executing = False
        self._lock = threading.Lock()
        self._queue_count = 0
        self._parallel_semaphore = threading.Semaphore(10)
        self._threads: list[threading.Thread] = []
        self._prev_sigint = None
        self._prev_sigterm = None

    def start(self, workflow: Callable, **kwargs) -> None:
        """Start the scheduler loop. Blocks the main thread.

        Args:
            workflow (Callable): The workflow start function to execute
                on each scheduled run.
            **kwargs: Additional keyword arguments passed to the workflow
                execution (e.g. mode, resume).
        """
        from croniter import croniter

        self.running = True
        self._register_signals()

        cron_iter = croniter(self.cron, datetime.now())

        while self.running:
            next_run = cron_iter.get_next(datetime)
            wait = (next_run - datetime.now()).total_seconds()

            while wait > 0 and self.running:
                step = min(wait, 1.0)
                sleep(step)
                wait -= step

            if not self.running:
                break

            self._dispatch(workflow=workflow, **kwargs)

    def stop(self, timeout: float | None = None) -> None:
        """Stop the scheduler loop and wait for in-flight threads.

        Args:
            timeout: Max seconds to wait for each thread. None = wait forever.
        """
        self.running = False
        self._restore_signals()
        with self._lock:
            threads, self._threads = self._threads, []
        for thread in threads:
            thread.join(timeout=timeout)

    def _dispatch(self, workflow: Callable, **kwargs) -> None:
        if self.overlap == TypeOverlap.SKIP:
            self._dispatch_skip(workflow=workflow, **kwargs)
        elif self.overlap == TypeOverlap.QUEUE:
            self._dispatch_queue(workflow=workflow, **kwargs)
        elif self.overlap == TypeOverlap.PARALLEL:
            self._dispatch_parallel(workflow=workflow, **kwargs)
        else:
            logger.error(
                "Unknown overlap strategy %r — workflow not dispatched",
                self.overlap,
            )

    def _track_thread(self, thread: threading.Thread) -> None:
        with self._lock:
            self._threads = [t for t in self._threads if t.is_alive()]
            self._threads.append(thread)

    def _dispatch_skip(self, workflow: Callable, **kwargs) -> None:
        with self._lock:
            if self._executing:
                return
            self._executing = True

        thread = threading.Thread(
            target=self._execute_and_reset,
            args=(workflow,),
            kwargs=kwargs,
        )
        self._track_thread(thread)
        thread.start()

    def _dispatch_queue(self, workflow: Callable, **kwargs) -> None:
        with self._lock:
            if self._executing:
                if self._queue_count == 0:
                    self._queue_count = 1
                return
            self._executing = True

        thread = threading.Thread(
            target=self._execute_queued,
            args=(workflow,),
            kwargs=kwargs,
        )
        self._track_thread(thread)
        thread.start()

    def _dispatch_parallel(self, workflow: Callable, **kwargs) -> None:
        if not self._parallel_semaphore.acquire(blocking=False):
            return

        thread = threading.Thread(
            target=self._execute_parallel,
            args=(workflow,),
            kwargs=kwargs,
        )
        self._track_thread(thread)
        thread.start()

    def _execute_parallel(self, workflow: Callable, **kwargs) -> None:
        try:
            workflow(**kwargs)
        except Exception:
            logger.exception("Scheduled workflow execution failed")
        finally:
            self._parallel_semaphore.release()

    def _execute_and_reset(self, workflow: Callable, **kwargs) -> None:
        try:
            workflow(**kwargs)
        except Exception:
            logger.exception("Scheduled workflow execution failed")
        finally:
            with self._lock:
                self._executing = False

    def _execute_queued(self, workflow: Callable, **kwargs) -> None:
        try:
            workflow(**kwargs)
        except Exception:
            logger.exception("Scheduled workflow execution failed")
        finally:
            with self._lock:
                if self._queue_count > 0:
                    self._queue_count = 0
                    next_thread = threading.Thread(
                        target=self._execute_queued,
                        args=(workflow,),
                        kwargs=kwargs,
                    )
                else:
                    self._executing = False
                    next_thread = None

            if next_thread is not None:
                self._track_thread(next_thread)
                next_thread.start()

    def _register_signals(self) -> None:
        if threading.current_thread() is not threading.main_thread():
            return
        self._prev_sigint = signal.signal(signal.SIGINT, self._handle_signal)
        self._prev_sigterm = signal.signal(signal.SIGTERM, self._handle_signal)

    def _restore_signals(self) -> None:
        if threading.current_thread() is not threading.main_thread():
            return
        if self._prev_sigint is not None:
            signal.signal(signal.SIGINT, self._prev_sigint)
            self._prev_sigint = None
        if self._prev_sigterm is not None:
            signal.signal(signal.SIGTERM, self._prev_sigterm)
            self._prev_sigterm = None

    def _handle_signal(self, signum, frame) -> None:
        self.stop()
