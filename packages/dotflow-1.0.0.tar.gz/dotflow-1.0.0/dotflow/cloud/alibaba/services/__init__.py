"""Alibaba Cloud services."""
