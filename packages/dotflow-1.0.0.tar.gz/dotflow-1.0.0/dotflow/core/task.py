"""Task module"""

from __future__ import annotations

import json
from collections.abc import Callable
from datetime import datetime
from typing import Any
from uuid import UUID

from ulid import ULID

from dotflow.core.action import Action
from dotflow.core.config import Config
from dotflow.core.context import Context
from dotflow.core.exception import (
    MissingActionDecorator,
    NotCallableObject,
    TaskError,
)
from dotflow.core.module import Module
from dotflow.core.serializers.task import SerializerTask
from dotflow.core.serializers.workflow import SerializerWorkflow
from dotflow.core.types.status import TypeStatus
from dotflow.utils import basic_callback


class TaskInstance:
    """
    from __future__ import annotations

        Import:
            You can import the **TaskInstance** class with:

                from dotflow.core.task import TaskInstance
    """

    def __init__(self, *args, **kwargs) -> None:
        self.task_id = None
        self.workflow_id = None
        self._step = None
        self._callback = None
        self._previous_context = None
        self._initial_context = None
        self._current_context = None
        self._duration = None
        self._status = None
        self._config = None
        self._errors = None
        self.group_name = None
        self.retry_count = 0


class Task(TaskInstance):
    """
    Import:
        You can import the **Task** class directly from dotflow:

            from dotflow import Task

    Example:
        `class` dotflow.core.task.Task

            task = Task(
                task_id="01ARZ3NDEKTSV4RRFFQ69G5FAV",
                step=my_step,
                callback=my_callback
            )

    Args:
        task_id (str): Task ID (ULID).

        step (Callable):
            A argument that receives an object of the callable type,
            which is basically a function. You can see in this
            [example](https://dotflow-io.github.io/dotflow/#3-task-function).

        callback (Callable):
            Any callable object that receives **args** or **kwargs**,
            which is basically a function. You can see in this
            [example](https://dotflow-io.github.io/dotflow/#2-callback-function).

        initial_context (Any): Any python object.

        workflow_id (UUID): Workflow ID.

        config (Config): Configuration class.

        group_name (str): Group name of tasks.
    """

    def __init__(
        self,
        task_id: str,
        step: Callable,
        callback: Callable = basic_callback,
        initial_context: Any = None,
        workflow_id: UUID = None,
        config: Config = None,
        group_name: str = "default",
    ) -> None:
        super().__init__(
            task_id,
            step,
            callback,
            initial_context,
            workflow_id,
            config,
            group_name,
        )
        self.config = config
        self.group_name = group_name
        self.task_id = task_id
        self.workflow_id = workflow_id
        self.step = step
        self.callback = callback
        self.initial_context = initial_context
        self.created_at = datetime.now()
        self.started_at = None
        self.finished_at = None
        self.status = TypeStatus.NOT_STARTED
        self.config.server.create_task(task=self)

    @property
    def step(self):
        return self._step

    @step.setter
    def step(self, value: Callable):
        new_step = value

        if isinstance(value, str):
            new_step = Module(value=value)

        if new_step.__module__ != Action.__module__:
            raise MissingActionDecorator()

        self._step = new_step

    @property
    def callback(self):
        return self._callback

    @callback.setter
    def callback(self, value: Callable):
        new_callback = value

        if isinstance(value, str):
            new_callback = Module(value=value)

        if not isinstance(new_callback, Callable):
            raise NotCallableObject(name=str(new_callback))

        self._callback = new_callback

    @property
    def previous_context(self):
        if not self._previous_context:
            return Context()
        return self._previous_context

    @previous_context.setter
    def previous_context(self, value: Context):
        self._previous_context = Context(value)

    @property
    def initial_context(self):
        if not self._initial_context:
            return Context()
        return self._initial_context

    @initial_context.setter
    def initial_context(self, value: Context):
        self._initial_context = Context(value)

    @property
    def current_context(self):
        if not self._current_context:
            return Context()
        return self._current_context

    @current_context.setter
    def current_context(self, value: Context):
        self._current_context = Context(
            task_id=self.task_id, workflow_id=self.workflow_id, storage=value
        )

        self.config.storage.post(
            key=self.config.storage.key(task=self),
            context=self.current_context,
        )

    @property
    def duration(self):
        return self._duration

    @duration.setter
    def duration(self, value: float):
        self._duration = value

    @property
    def errors(self):
        if self._errors is None:
            self._errors = []
        return self._errors

    @errors.setter
    def errors(self, value) -> None:
        if isinstance(value, list):
            self._errors = value
            return

        if self._errors is None:
            self._errors = []

        if isinstance(value, TaskError):
            self._errors.append(value)
        elif isinstance(value, Exception):
            self._errors.append(TaskError(value))

    @property
    def error(self):
        import warnings

        warnings.warn(
            "'error' is deprecated, use 'errors' instead. "
            "Note: 'TaskError.exception' is now a string "
            "(e.g. 'ValueError'), not an Exception object.",
            DeprecationWarning,
            stacklevel=2,
        )
        if not self.errors:
            return TaskError()
        return self.errors[-1]

    @error.setter
    def error(self, value) -> None:
        import warnings

        warnings.warn(
            "'error' is deprecated, use 'errors' instead. "
            "Note: 'TaskError.exception' is now a string "
            "(e.g. 'ValueError'), not an Exception object.",
            DeprecationWarning,
            stacklevel=2,
        )
        self.errors = value

    @property
    def status(self):
        if not self._status:
            return TypeStatus.NOT_STARTED
        return self._status

    @status.setter
    def status(self, value: TypeStatus) -> None:
        self._status = value

        self.config.notify.hook_status_task(task=self)

        if value == TypeStatus.FAILED:
            self.config.log.error(task=self)
            self.config.metrics.task_failed(task=self)
        elif value == TypeStatus.RETRY:
            self.config.log.warning(task=self)
            self.config.metrics.task_retried(task=self)
        elif value == TypeStatus.COMPLETED:
            self.config.log.info(task=self)
            self.config.metrics.task_completed(task=self)
        else:
            self.config.log.info(task=self)

    @property
    def config(self):
        if not self._config:
            return Config()
        return self._config

    @config.setter
    def config(self, value: Config):
        self._config = value

    def schema(self, max: int = None) -> SerializerTask:
        return SerializerTask(**self.__dict__, max=max)

    def result(self, max: int = None) -> SerializerWorkflow:
        item = self.schema(max=max).model_dump_json()
        return json.loads(item)


class TaskBuilder:
    """
    Import:
        You can import the **Task** class with:

            from dotflow.core.task import TaskBuilder

    Example:
        `class` dotflow.core.task.TaskBuilder

            from uuid import uuid4

            build = TaskBuilder(
                config=config
                workflow_id=uuid4()
            )

    Args:
        config (Config): Configuration class.
        workflow_id (UUID): Workflow ID.
    """

    def __init__(
        self,
        config: Config,
        workflow_id: UUID = None,
        workflow_name: str | None = None,
    ) -> None:
        self.queue: list[Callable] = []
        self.workflow_id = workflow_id
        self.workflow_name = workflow_name
        self.config = config

    def add(
        self,
        step: Callable,
        callback: Callable = basic_callback,
        initial_context: Any = None,
        group_name: str = "default",
    ) -> TaskBuilder:
        """
        Args:
            step (Callable):
                A argument that receives an object of the callable type,
                which is basically a function. You can see in this
                [example](https://dotflow-io.github.io/dotflow/#3-task-function).

            callback (Callable):
                Any callable object that receives **args** or **kwargs**,
                which is basically a function. You can see in this
                [example](https://dotflow-io.github.io/dotflow/#2-callback-function).

            initial_context (Context):
                The argument exists to include initial data in the execution
                of the workflow within the **function context**. This parameter
                can be accessed internally, for example: **initial_context**,
                to retrieve this information and manipulate it if necessary,
                according to the objective of the workflow.

            group_name (str): Group name of tasks.
        """
        if isinstance(step, list):
            for inside_step in step:
                self.add(
                    step=inside_step,
                    callback=callback,
                    initial_context=initial_context,
                    group_name=group_name,
                )
            return self

        task_id = str(ULID())

        self.queue.append(
            Task(
                task_id=task_id,
                step=step,
                callback=Module(value=callback),
                initial_context=initial_context,
                workflow_id=self.workflow_id,
                config=self.config,
                group_name=group_name,
            )
        )

        return self

    def count(self) -> int:
        return len(self.queue)

    def clear(self) -> None:
        self.queue.clear()

    def reverse(self) -> None:
        self.queue.reverse()

    def schema(self) -> SerializerWorkflow:
        return SerializerWorkflow(
            workflow_id=self.workflow_id,
            workflow_name=self.workflow_name,
            tasks=[item.schema() for item in self.queue],
        )

    def result(self) -> SerializerWorkflow:
        item = self.schema().model_dump_json()
        return json.loads(item)
