# config.py

import os
import json

# Assume binaries are in $HOME/bin.
DEFAULT_CONFIG = {
    "DEBUG": False,
    "TIMEOUT": 300,
    "ToolInvocation": "gpmc -mode=1",
    "D4ToolInvocation": "maxT_static",
    "GetResult": "exact.double.prec-sci.(.+?)\\\\nc s",
    "FPE"       : 1e-12,
    "Precision" : 50
}

def load_config():
    config_path = os.getenv("QUOKKA_CONFIG", None)
    
    if config_path and os.path.isfile(config_path):
        try:
            with open(config_path, "r") as f:
                user_config = json.load(f)
                return {**DEFAULT_CONFIG, **user_config}
        except Exception as e:
            raise RuntimeError(f"Failed to load config file: {e}")
    
    return DEFAULT_CONFIG

CONFIG = load_config()

def reload_config():
    """
    Reload CONFIG from `config_path` (if provided) or from env var QUOKKA_CONFIG.
    Returns the updated CONFIG dict.
    """
    global CONFIG
    CONFIG = load_config()
    return CONFIG
