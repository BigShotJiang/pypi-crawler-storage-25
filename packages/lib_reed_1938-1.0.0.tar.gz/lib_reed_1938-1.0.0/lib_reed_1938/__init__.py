"""Vale Weekly Rack"""
__version__ = "1.0.0"
