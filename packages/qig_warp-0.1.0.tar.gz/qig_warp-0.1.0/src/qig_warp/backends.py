"""LLM backends for the warp bubble.

Supports Ollama (local, zero dependencies) and OpenAI-compatible APIs.
"""

from __future__ import annotations

import json
import re
import urllib.request
from abc import ABC, abstractmethod
from typing import Optional


class Backend(ABC):
    """Abstract backend for text generation."""

    @abstractmethod
    def generate(self, prompt: str, temperature: float = 0.0,
                 max_tokens: int = 100) -> str:
        """Generate text from a prompt. Returns the generated text."""
        ...

    @property
    @abstractmethod
    def name(self) -> str:
        """Human-readable backend name."""
        ...


class OllamaBackend(Backend):
    """Local Ollama backend. Zero external dependencies."""

    def __init__(self, model: str = "granite4",
                 base_url: str = "http://localhost:11434",
                 raw: bool = True):
        self.model = model
        self.base_url = base_url.rstrip("/")
        self.raw = raw

    def generate(self, prompt: str, temperature: float = 0.0,
                 max_tokens: int = 100) -> str:
        payload = json.dumps({
            "model": self.model,
            "prompt": prompt,
            "stream": False,
            "raw": self.raw,
            "options": {
                "num_predict": max_tokens,
                "temperature": temperature,
            },
        }).encode()
        req = urllib.request.Request(
            f"{self.base_url}/api/generate",
            data=payload,
            headers={"Content-Type": "application/json"},
        )
        resp = urllib.request.urlopen(req, timeout=120)
        data = json.loads(resp.read())
        text = data.get("response", "")
        # Strip thinking model tags
        text = re.sub(r"<think>.*?</think>", "", text, flags=re.DOTALL).strip()
        return text

    @property
    def name(self) -> str:
        return f"ollama:{self.model}"


class OpenAIBackend(Backend):
    """OpenAI-compatible API backend (works with any compatible server)."""

    def __init__(self, model: str = "gpt-4o-mini",
                 api_key: Optional[str] = None,
                 base_url: str = "https://api.openai.com/v1"):
        self.model = model
        self.base_url = base_url.rstrip("/")
        if api_key is None:
            import os
            api_key = os.environ.get("OPENAI_API_KEY", "")
        self.api_key = api_key

    def generate(self, prompt: str, temperature: float = 0.0,
                 max_tokens: int = 100) -> str:
        payload = json.dumps({
            "model": self.model,
            "messages": [{"role": "user", "content": prompt}],
            "temperature": temperature,
            "max_tokens": max_tokens,
        }).encode()
        req = urllib.request.Request(
            f"{self.base_url}/chat/completions",
            data=payload,
            headers={
                "Content-Type": "application/json",
                "Authorization": f"Bearer {self.api_key}",
            },
        )
        resp = urllib.request.urlopen(req, timeout=120)
        data = json.loads(resp.read())
        return data["choices"][0]["message"]["content"].strip()

    @property
    def name(self) -> str:
        return f"openai:{self.model}"
