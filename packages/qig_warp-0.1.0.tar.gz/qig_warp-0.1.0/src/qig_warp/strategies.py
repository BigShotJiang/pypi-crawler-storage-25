"""Warp bubble strategies — structured time dilation for LLM inference.

Each strategy generates multiple samples from different geometric basins
on the probability simplex, then coarse-grains them into one answer
via self-consistency filtering.
"""

from __future__ import annotations

from collections import Counter
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from qig_warp.backends import Backend


# ═══════════════════════════════════════════════════════════
# Priming Templates
# ═══════════════════════════════════════════════════════════

MATH_PRIMES = [
    "Multiply carefully: 11*11=121, 12*12=144, 13*13=169. Now: {question}",
    "Math: 5*20=100, 6*30=180, 7*40=280. Solve: {question}",
    "Step by step: 10*10=100, 20*20=400, 30*30=900. Calculate: {question}",
    "Quick math: 3*7=21, 6*8=48, 9*9=81. Answer: {question}",
    "Compute: 15*4=60, 25*4=100, 35*4=140. Result of {question}",
]

REASONING_FRAMINGS = [
    "Think carefully and logically. {question}",
    "A mathematician would answer: {question}",
    "Common mistake warning — think twice. {question}",
    "Answer in one word or number. {question}",
    "This is a trick question. Be careful. {question}",
    "Explain your reasoning briefly, then give the answer. {question}",
    "Consider this from multiple angles. {question}",
    "What would a careful expert say? {question}",
]


# ═══════════════════════════════════════════════════════════
# Strategy Functions
# ═══════════════════════════════════════════════════════════

def adversarial(question: str, backend: "Backend", n_samples: int = 12,
                framings: list[str] | None = None,
                max_tokens: int = 100) -> list[str]:
    """Sample the same question from multiple reasoning perspectives.

    Each framing activates a different geometric basin on the probability
    simplex. Self-consistency across framings selects the answer that
    survives multiple perspectives.
    """
    if framings is None:
        framings = REASONING_FRAMINGS

    temps = [0.3, 0.5, 0.7, 1.0]
    answers = []

    for i in range(n_samples):
        framing = framings[i % len(framings)]
        prompt = framing.format(question=question)
        temp = temps[i % len(temps)]
        text = backend.generate(prompt, temperature=temp, max_tokens=max_tokens)
        answers.append(text)

    return answers


def self_prime(question: str, backend: "Backend", n_samples: int = 12,
               max_tokens: int = 150) -> list[str]:
    """Model generates its own examples, then uses them to solve.

    Bootstraps the coupling landscape — no external priming needed.
    """
    meta_prompt = (
        "Give 3 simple examples related to this type of problem, "
        "then solve it.\n\n"
        f"Problem: {question}\n\n"
        "Examples and solution:"
    )
    temps = [0.3, 0.5, 0.7, 1.0]
    answers = []

    for i in range(n_samples):
        temp = temps[i % len(temps)]
        text = backend.generate(meta_prompt, temperature=temp,
                                max_tokens=max_tokens)
        answers.append(text)

    return answers


def decompose(question: str, backend: "Backend", n_samples: int = 12,
              max_tokens: int = 150) -> list[str]:
    """Break question into steps, solve each, compose."""
    prompt = (
        "Break this into steps, then give the final answer.\n\n"
        f"Question: {question}\n\n"
        "Step-by-step:"
    )
    temps = [0.3, 0.5, 0.7, 1.0]
    answers = []

    for i in range(n_samples):
        temp = temps[i % len(temps)]
        text = backend.generate(prompt, temperature=temp,
                                max_tokens=max_tokens)
        answers.append(text)

    return answers


def primed(question: str, backend: "Backend", n_samples: int = 12,
           templates: list[str] | None = None,
           max_tokens: int = 80) -> list[str]:
    """Sample with rotating few-shot priming templates.

    Best for arithmetic and pattern-completion tasks.
    """
    if templates is None:
        templates = MATH_PRIMES

    temps = [0.3, 0.7, 1.0]
    answers = []

    for i in range(n_samples):
        template = templates[i % len(templates)]
        prompt = template.format(question=question)
        temp = temps[i % len(temps)]
        text = backend.generate(prompt, temperature=temp,
                                max_tokens=max_tokens)
        answers.append(text)

    return answers
