"""The warp bubble — core orchestrator.

Runs multiple strategies, coarse-grains via self-consistency,
returns the best answer.
"""

from __future__ import annotations

import re
from collections import Counter
from typing import TYPE_CHECKING, Optional

from qig_warp.backends import Backend, OllamaBackend
from qig_warp.strategies import adversarial, self_prime, decompose, primed

if TYPE_CHECKING:
    pass


def extract_answer(text: str) -> str:
    """Extract the most likely answer from generated text.

    Tries number first, then first meaningful word.
    """
    text = text.strip()
    # Look for a number (common for math/logic)
    num = re.search(r'(?:^|[=:]\s*)(-?\d+(?:\.\d+)?)', text)
    if num:
        return num.group(1)
    # First word after stripping meta
    clean = re.sub(r'^(Answer|Result|Solution|The answer is)[:\s]*',
                   '', text, flags=re.IGNORECASE).strip()
    words = clean.split()
    if words:
        return words[0].rstrip(".,;:!?")
    return text[:50]


def coarse_grain(answers: list[str], extract_fn=extract_answer,
                 min_consistency: int = 2) -> tuple[str, float, dict]:
    """Coarse-grain multiple answers via self-consistency.

    Returns (best_answer, confidence, vote_counts).

    Confidence = fraction of samples that agree on the best answer.
    Self-consistency filter: prefer answers appearing min_consistency+ times.
    """
    extracted = [extract_fn(a) for a in answers if a.strip()]
    if not extracted:
        return "", 0.0, {}

    counts = Counter(extracted)

    # Prefer answers with min_consistency+ votes
    consistent = {k: v for k, v in counts.items() if v >= min_consistency}
    if consistent:
        best = max(consistent, key=consistent.get)
    else:
        best = counts.most_common(1)[0][0]

    confidence = counts[best] / len(extracted)
    return best, confidence, dict(counts.most_common(10))


class WarpBubble:
    """Configurable warp bubble for structured time dilation.

    Args:
        backend: LLM backend (Ollama, OpenAI, etc.)
        n_samples: Number of samples per strategy (default 12)
        strategies: Which strategies to use (default: all)
        max_tokens: Max tokens per generation
        min_consistency: Minimum votes for self-consistency filter
    """

    def __init__(self, backend: Optional[Backend] = None,
                 n_samples: int = 12,
                 strategies: list[str] | None = None,
                 max_tokens: int = 100,
                 min_consistency: int = 2):
        self.backend = backend or OllamaBackend()
        self.n_samples = n_samples
        self.strategies = strategies or ["adversarial", "decompose", "self_prime"]
        self.max_tokens = max_tokens
        self.min_consistency = min_consistency

    def solve(self, question: str,
              extract_fn=extract_answer) -> dict:
        """Run the warp bubble on a question.

        Returns dict with:
            answer: best coarse-grained answer
            confidence: fraction of samples agreeing
            votes: vote counts for top answers
            per_strategy: results from each strategy
            n_total_samples: total forward passes used
        """
        all_answers = []
        per_strategy = {}
        strategy_fns = {
            "adversarial": adversarial,
            "self_prime": self_prime,
            "decompose": decompose,
            "primed": primed,
        }

        for name in self.strategies:
            fn = strategy_fns.get(name)
            if fn is None:
                continue
            answers = fn(question, self.backend,
                         n_samples=self.n_samples,
                         max_tokens=self.max_tokens)
            best, conf, votes = coarse_grain(answers, extract_fn,
                                              self.min_consistency)
            per_strategy[name] = {
                "answer": best,
                "confidence": round(conf, 4),
                "votes": votes,
                "n_samples": len(answers),
            }
            all_answers.extend(answers)

        # Final coarse-graining across all strategies
        final_answer, final_conf, final_votes = coarse_grain(
            all_answers, extract_fn, self.min_consistency)

        return {
            "answer": final_answer,
            "confidence": round(final_conf, 4),
            "votes": final_votes,
            "per_strategy": per_strategy,
            "n_total_samples": len(all_answers),
            "backend": self.backend.name,
        }


def warp(question: str,
         model: str = "granite4",
         base_url: str = "http://localhost:11434",
         n_samples: int = 12,
         strategies: list[str] | None = None,
         max_tokens: int = 100,
         backend: Optional[Backend] = None) -> str:
    """One-line warp bubble. Returns the best answer as a string.

    Args:
        question: The question to answer.
        model: Ollama model name (ignored if backend is provided).
        base_url: Ollama server URL (ignored if backend is provided).
        n_samples: Samples per strategy (more = better but slower).
        strategies: Which strategies to use. Default: all three.
        max_tokens: Max tokens per generation.
        backend: Custom backend (overrides model/base_url).

    Returns:
        The coarse-grained best answer.

    Example:
        >>> from qig_warp import warp
        >>> warp("What is 73 * 45?")
        '3285'
    """
    if backend is None:
        backend = OllamaBackend(model=model, base_url=base_url)

    bubble = WarpBubble(backend=backend, n_samples=n_samples,
                         strategies=strategies, max_tokens=max_tokens)
    result = bubble.solve(question)
    return result["answer"]
