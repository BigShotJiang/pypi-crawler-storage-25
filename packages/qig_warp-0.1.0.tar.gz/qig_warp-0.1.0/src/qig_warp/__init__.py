"""QIG Warp Bubble — structured time dilation for LLM inference.

A 2.1B model achieves 100% on problems it normally gets 60% right.
Same model, same compute budget, structured differently.

Usage:
    from qig_warp import warp

    answer = warp("What is 73 * 45?", model="granite4")
    # Returns "3285" with high confidence

    # With custom backend
    from qig_warp.backends import OllamaBackend
    backend = OllamaBackend(model="llama3", base_url="http://localhost:11434")
    answer = warp("Solve: 48 * 52", backend=backend)
"""

from qig_warp.bubble import warp, WarpBubble
from qig_warp.strategies import adversarial, self_prime, decompose

__version__ = "0.1.0"
__all__ = ["warp", "WarpBubble", "adversarial", "self_prime", "decompose"]
