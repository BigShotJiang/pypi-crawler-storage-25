"""
Test package for TinyComp
""" 