from importlib.metadata import PackageNotFoundError, version

try:
    __version__ = version("dynamaxsys")
except PackageNotFoundError:
    __version__ = "unknown"

from .base import (
    Dynamics,
    ControlAffineDynamics,
    ControlDisturbanceAffineDynamics,
    LinearControlDynamics,
    LinearControlDisturbanceDynamics,
    get_discrete_time_dynamics,
    get_linearized_dynamics_control,
    get_linearized_dynamics_control_disturbance,
)
from .integrators import (
    IntegratorND,
    DoubleIntegrator2D,
    DoubleIntegrator1D,
    SingleIntegrator2D,
    SingleIntegrator1D,
    TwoPlayerRelativeIntegratorND,
    ParametricIntegratorND,
)
from .simplecar import (
    SimpleCar,
    DynamicallyExtendedSimpleCar,
    RelativeSimpleCar,
    RelativeDynamicallyExtendedSimpleCar,
    ParametricDynamicallyExtendedSimpleCar,
    ParametricRelativeDynamicallyExtendedSimpleCar,
)
from .unicycle import (
    Unicycle,
    DynamicallyExtendedUnicycle,
    RelativeUnicycle,
    RelativeDynamicallyExtendedUnicycle,
    ParametricUnicycle,
    ParametricDynamicallyExtendedUnicycle,
    ParametricRelativeUnicycle,
    ParametricRelativeDynamicallyExtendedUnicycle,
)

from .parametric import (
    ParametricControlAffineDynamics,
    ParametricControlDisturbanceAffineDynamics,
)

from .utils import linearize


__all__ = [
    "Dynamics",
    "ControlAffineDynamics",
    "ControlDisturbanceAffineDynamics",
    "LinearControlDynamics",
    "LinearControlDisturbanceDynamics",
    "get_discrete_time_dynamics",
    "get_linearized_dynamics_control",
    "get_linearized_dynamics_control_disturbance",
    "IntegratorND",
    "DoubleIntegrator2D",
    "DoubleIntegrator1D",
    "SingleIntegrator2D",
    "SingleIntegrator1D",
    "TwoPlayerRelativeIntegratorND",
    "SimpleCar",
    "DynamicallyExtendedSimpleCar",
    "RelativeSimpleCar",
    "RelativeDynamicallyExtendedSimpleCar",
    "Unicycle",
    "DynamicallyExtendedUnicycle",
    "RelativeUnicycle",
    "RelativeDynamicallyExtendedUnicycle",
    "ParametricIntegratorND",
    "ParametricControlAffineDynamics",
    "ParametricControlDisturbanceAffineDynamics",
    "ParametricDynamicallyExtendedSimpleCar",
    "ParametricRelativeDynamicallyExtendedSimpleCar",
    "ParametricUnicycle",
    "ParametricDynamicallyExtendedUnicycle",
    "ParametricRelativeUnicycle",
    "ParametricRelativeDynamicallyExtendedUnicycle",
    "linearize",
]
# Add any public symbols from utils.py here if you want to be explicit
