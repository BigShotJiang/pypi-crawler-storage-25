"""
JARVIS Backend Server

FastAPI server with WebSocket support for live token streaming
and REST endpoints for memory management.
"""

from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from pathlib import Path

from loguru import logger


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Lifespan context for startup and shutdown events."""
    from brain.agent import ReActAgent
    from brain.router import CommandRouter
    from memory import MemoryManager
    from core.config import load_config
    from core.hardware import detect_hardware
    from brain.tools import create_tools_registry
    
    # Startup: create shared instances
    logger.info("Creating shared agent...")
    try:
        app.state.agent = ReActAgent(tool_registry=create_tools_registry())
    except Exception as e:
        logger.error(f"Failed to create agent: {e}")
        app.state.agent = ReActAgent()  # Fallback without tools
    
    logger.info("Creating shared memory manager...")
    try:
        config = load_config(detect_hardware().vram_total_mb)
        app.state.memory = MemoryManager(config)
    except Exception as e:
        logger.error(f"Failed to create memory manager: {e}")
        app.state.memory = None
    
    logger.info("Creating shared router...")
    tool_registry = getattr(app.state.agent, 'tools', None)
    app.state.router = CommandRouter(tool_registry=tool_registry) if tool_registry else None
    
    logger.info("JARVIS backend server started with shared state")
    yield
    
    # Shutdown
    logger.info("Shutting down JARVIS backend server...")


def create_app() -> FastAPI:
    """Create and configure the FastAPI application."""
    app = FastAPI(
        title="JARVIS Backend",
        description="FastAPI backend with WebSocket support for JARVIS AI Assistant",
        version="1.0.0",
        lifespan=lifespan,
    )
    
    # Configure CORS - allow specific origins for local development
    app.add_middleware(
        CORSMiddleware,
        allow_origins=[
            "http://localhost:5173",  # Vite dev server
            "http://localhost:3000",  # React dev server
            "http://127.0.0.1:5173",
            "http://127.0.0.1:3000",
        ],
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )
    
    # Import and include routers
    from backend.api.routes import chat, memory, stats, learn, chains
    
    app.include_router(chat.router, tags=["chat"])
    app.include_router(memory.router, prefix="/api", tags=["memory"])
    app.include_router(stats.router, prefix="/api", tags=["stats"])
    app.include_router(learn.router, prefix="/api", tags=["learn"])
    app.include_router(chains.router, prefix="/api", tags=["chains"])
    
    # Define JSON endpoints BEFORE StaticFiles mount
    # This ensures root and health endpoints work correctly
    @app.get("/")
    async def root():
        """Root endpoint returning server status."""
        return {
            "status": "online",
            "service": "JARVIS Backend",
            "version": "1.0.0",
        }
    
    @app.get("/health")
    async def health():
        """Health check endpoint."""
        return {"status": "healthy"}
    
    # Serve UI static files - mounted AFTER JSON endpoints
    # This ensures JSON endpoints are registered first and take precedence
    ui_path = Path(__file__).parent.parent / "ui" / "dist"
    if ui_path.exists():
        app.mount("/", StaticFiles(directory=str(ui_path), html=True), name="ui")
        logger.info(f"Serving UI from: {ui_path}")
    
    return app


# Create the app instance
app = create_app()


if __name__ == "__main__":
    import uvicorn
    
    uvicorn.run(
        "backend.main:app",
        host="0.0.0.0",
        port=8000,
        reload=True,
    )
