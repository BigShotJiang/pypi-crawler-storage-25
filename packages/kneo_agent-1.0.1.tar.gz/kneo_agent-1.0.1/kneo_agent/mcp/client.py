"""
kneo_agent.mcp.client
~~~~~~~~~~~~~~~~~~~~~
Minimal MCP client support for importing remote tools into Kneo Agent.

The implementation intentionally treats MCP servers as tool providers:
their advertised tools are converted into ``ToolDefinition`` objects and
their tool invocations are exposed as Python callables that can be fed
through the existing ``ToolRegistry``/``Skill`` flow.
"""

from __future__ import annotations

import asyncio
from contextlib import suppress
from dataclasses import dataclass, field
import json
import os
from pathlib import Path
import threading
from typing import Any
from urllib.error import HTTPError, URLError
from urllib.parse import urljoin
from urllib.request import Request, urlopen

from ..core.exceptions import ConfigurationError
from ..core.types import ToolDefinition


@dataclass(frozen=True)
class MCPServerConfig:
    """Connection details for one MCP server."""

    name: str
    transport: str
    command: str | None = None
    args: tuple[str, ...] = ()
    env: dict[str, str] = field(default_factory=dict)
    cwd: str | None = None
    url: str | None = None
    sse_url: str | None = None
    headers: dict[str, str] = field(default_factory=dict)
    timeout: float = 30.0

    @classmethod
    def stdio(
        cls,
        *,
        name: str,
        command: str,
        args: list[str] | tuple[str, ...] | None = None,
        env: dict[str, str] | None = None,
        cwd: str | None = None,
    ) -> "MCPServerConfig":
        return cls(
            name=name,
            transport="stdio",
            command=command,
            args=tuple(args or ()),
            env=dict(env or {}),
            cwd=cwd,
        )

    @classmethod
    def http(
        cls,
        *,
        name: str,
        url: str,
        headers: dict[str, str] | None = None,
        timeout: float = 30.0,
        sse_url: str | None = None,
    ) -> "MCPServerConfig":
        return cls(
            name=name,
            transport="http",
            url=url,
            sse_url=sse_url,
            headers=dict(headers or {}),
            timeout=timeout,
        )

    @classmethod
    def sse(
        cls,
        *,
        name: str,
        sse_url: str,
        message_url: str | None = None,
        headers: dict[str, str] | None = None,
        timeout: float = 30.0,
    ) -> "MCPServerConfig":
        return cls(
            name=name,
            transport="sse",
            url=message_url,
            sse_url=sse_url,
            headers=dict(headers or {}),
            timeout=timeout,
        )


@dataclass(frozen=True)
class MCPTool:
    """Lightweight tool description returned by an MCP server."""

    name: str
    description: str
    input_schema: dict[str, Any]

    def to_tool_definition(self, *, local_name: str | None = None) -> ToolDefinition:
        return ToolDefinition(
            name=local_name or self.name,
            description=self.description,
            parameters=self.input_schema,
        )


class MCPClientSession:
    """
    Async MCP session with enough protocol coverage for tools/list and tools/call.

    The session supports subprocess stdio transports plus HTTP/SSE style
    transports backed by JSON-RPC 2.0 messages.
    """

    def __init__(self, config: MCPServerConfig) -> None:
        self._config = config
        self._request_id = 0
        self._write_lock = asyncio.Lock()
        self._response_futures: dict[int, asyncio.Future[dict[str, Any]]] = {}
        self._initialized = False

        self._proc: asyncio.subprocess.Process | None = None
        self._reader_task: asyncio.Task[None] | None = None

        self._sse_task: asyncio.Task[None] | None = None
        self._message_url: str | None = config.url
        self._endpoint_ready = asyncio.Event()
        if self._message_url:
            self._endpoint_ready.set()

    @property
    def server_name(self) -> str:
        return self._config.name

    async def connect(self) -> "MCPClientSession":
        if self._initialized:
            return self

        if self._config.transport == "stdio":
            await self._connect_stdio()
        elif self._config.transport in {"http", "sse"}:
            await self._connect_http()
        else:
            raise ConfigurationError(f"Unsupported MCP transport {self._config.transport!r}.")

        await self._initialize()
        self._initialized = True
        return self

    async def aclose(self) -> None:
        if self._reader_task is not None:
            self._reader_task.cancel()
            with suppress(asyncio.CancelledError):
                await self._reader_task
            self._reader_task = None

        if self._sse_task is not None:
            self._sse_task.cancel()
            with suppress(asyncio.CancelledError):
                await self._sse_task
            self._sse_task = None

        for future in self._response_futures.values():
            if not future.done():
                future.cancel()
        self._response_futures.clear()

        if self._proc is not None:
            self._proc.terminate()
            try:
                await asyncio.wait_for(self._proc.wait(), timeout=2.0)
            except asyncio.TimeoutError:
                self._proc.kill()
                await self._proc.wait()
            self._proc = None

    async def list_tools(self) -> list[MCPTool]:
        payload = await self._request("tools/list", {})
        tools = payload.get("tools", [])
        if not isinstance(tools, list):
            raise ConfigurationError("MCP tools/list response did not contain a tool list.")
        result: list[MCPTool] = []
        for item in tools:
            if not isinstance(item, dict):
                continue
            result.append(
                MCPTool(
                    name=str(item.get("name", "")),
                    description=str(item.get("description", "")),
                    input_schema=dict(item.get("inputSchema") or {"type": "object"}),
                )
            )
        return result

    async def call_tool(self, name: str, arguments: dict[str, Any] | None = None) -> Any:
        payload = await self._request(
            "tools/call",
            {"name": name, "arguments": dict(arguments or {})},
        )
        return self._coerce_tool_result(payload)

    async def _initialize(self) -> None:
        await self._request(
            "initialize",
            {
                "protocolVersion": "2024-11-05",
                "capabilities": {"tools": {}},
                "clientInfo": {"name": "kneo-agent", "version": "1.0.1"},
            },
        )
        try:
            await asyncio.wait_for(
                self._notify("notifications/initialized", {}),
                timeout=min(self._config.timeout, 2.0),
            )
        except (asyncio.TimeoutError, ConfigurationError):
            # Some servers ignore or poorly implement the follow-up notification.
            # Tool discovery remains possible after a successful initialize call.
            return

    async def _connect_stdio(self) -> None:
        if not self._config.command:
            raise ConfigurationError("MCP stdio transport requires a command.")

        env = os.environ.copy()
        env.update(self._config.env)
        self._proc = await asyncio.create_subprocess_exec(
            self._config.command,
            *self._config.args,
            cwd=self._config.cwd,
            env=env,
            stdin=asyncio.subprocess.PIPE,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        self._reader_task = asyncio.create_task(self._stdio_reader())

    async def _connect_http(self) -> None:
        if self._config.transport == "http" and self._config.sse_url:
            self._sse_task = asyncio.create_task(self._sse_reader(self._config.sse_url))
        elif self._config.transport == "sse":
            if not self._config.sse_url:
                raise ConfigurationError("MCP SSE transport requires an sse_url.")
            self._sse_task = asyncio.create_task(self._sse_reader(self._config.sse_url))

    async def _request(self, method: str, params: dict[str, Any]) -> dict[str, Any]:
        self._request_id += 1
        request_id = self._request_id
        future: asyncio.Future[dict[str, Any]] = asyncio.get_running_loop().create_future()
        self._response_futures[request_id] = future
        payload = {
            "jsonrpc": "2.0",
            "id": request_id,
            "method": method,
            "params": params,
        }
        try:
            await self._send_payload(payload)
            response = await asyncio.wait_for(future, timeout=self._config.timeout)
        finally:
            self._response_futures.pop(request_id, None)

        if "error" in response:
            raise ConfigurationError(f"MCP request {method!r} failed: {response['error']}")
        result = response.get("result", {})
        if not isinstance(result, dict):
            return {"value": result}
        return result

    async def _notify(self, method: str, params: dict[str, Any]) -> None:
        await self._send_payload(
            {
                "jsonrpc": "2.0",
                "method": method,
                "params": params,
            }
        )

    async def _send_payload(self, payload: dict[str, Any]) -> None:
        async with self._write_lock:
            if self._config.transport == "stdio":
                assert self._proc is not None and self._proc.stdin is not None
                self._proc.stdin.write((json.dumps(payload) + "\n").encode("utf-8"))
                await self._proc.stdin.drain()
                return

            await self._endpoint_ready.wait()
            assert self._message_url is not None
            response = await asyncio.to_thread(self._http_post_json, self._message_url, payload)
            if "id" in response and isinstance(response["id"], int):
                self._dispatch_response(response)

    async def _stdio_reader(self) -> None:
        assert self._proc is not None and self._proc.stdout is not None
        while True:
            line = await self._proc.stdout.readline()
            if not line:
                break
            message = json.loads(line.decode("utf-8"))
            self._dispatch_response(message)

    async def _sse_reader(self, url: str) -> None:
        loop = asyncio.get_running_loop()
        queue: asyncio.Queue[dict[str, str] | None] = asyncio.Queue()

        def worker() -> None:
            try:
                request = Request(url, headers=self._http_headers())
                with urlopen(request, timeout=self._config.timeout) as response:
                    event_name = "message"
                    data_parts: list[str] = []
                    for raw_line in response:
                        line = raw_line.decode("utf-8").rstrip("\r\n")
                        if not line:
                            if data_parts:
                                loop.call_soon_threadsafe(
                                    queue.put_nowait,
                                    {"event": event_name, "data": "\n".join(data_parts)},
                                )
                                data_parts = []
                                event_name = "message"
                            continue
                        if line.startswith(":"):
                            continue
                        field, _, value = line.partition(":")
                        value = value.lstrip(" ")
                        if field == "event":
                            event_name = value or "message"
                        elif field == "data":
                            data_parts.append(value)
            except Exception:
                loop.call_soon_threadsafe(queue.put_nowait, None)
            else:
                loop.call_soon_threadsafe(queue.put_nowait, None)

        thread = threading.Thread(target=worker, daemon=True)
        thread.start()

        while True:
            event = await queue.get()
            if event is None:
                break
            self._handle_sse_event(event)

    def _handle_sse_event(self, event: dict[str, str]) -> None:
        event_name = event.get("event", "message")
        data = event.get("data", "")
        if event_name == "endpoint":
            base = self._config.sse_url or self._config.url or ""
            self._message_url = urljoin(base, data)
            self._endpoint_ready.set()
            return

        try:
            payload = json.loads(data)
        except json.JSONDecodeError:
            return
        if isinstance(payload, dict):
            self._dispatch_response(payload)

    def _dispatch_response(self, payload: dict[str, Any]) -> None:
        raw_id = payload.get("id")
        if not isinstance(raw_id, int):
            return
        future = self._response_futures.get(raw_id)
        if future is not None and not future.done():
            future.set_result(payload)

    def _http_post_json(self, url: str, payload: dict[str, Any]) -> dict[str, Any]:
        request = Request(
            url,
            data=json.dumps(payload).encode("utf-8"),
            headers=self._http_headers(content_type="application/json"),
            method="POST",
        )
        try:
            with urlopen(request, timeout=self._config.timeout) as response:
                body = response.read().decode("utf-8").strip()
        except HTTPError as exc:
            body = exc.read().decode("utf-8", errors="replace")
            raise ConfigurationError(
                f"MCP HTTP request failed with status {exc.code}: {body}"
            ) from exc
        except URLError as exc:
            raise ConfigurationError(f"Could not reach MCP server {url!r}: {exc}") from exc

        if not body:
            return {}
        parsed = json.loads(body)
        if not isinstance(parsed, dict):
            raise ConfigurationError("MCP HTTP response was not a JSON object.")
        return parsed

    def _http_headers(self, *, content_type: str | None = None) -> dict[str, str]:
        headers = {
            "Accept": "application/json, text/event-stream",
            **self._config.headers,
        }
        if content_type is not None:
            headers["Content-Type"] = content_type
        return headers

    @staticmethod
    def _coerce_tool_result(payload: dict[str, Any]) -> Any:
        if "structuredContent" in payload:
            return payload["structuredContent"]

        content = payload.get("content")
        if isinstance(content, list):
            text_parts = [
                item.get("text", "")
                for item in content
                if isinstance(item, dict) and item.get("type") == "text"
            ]
            if text_parts and len(text_parts) == len(content):
                return "\n".join(part for part in text_parts if part)
        if "text" in payload and isinstance(payload["text"], str):
            return payload["text"]
        return payload
