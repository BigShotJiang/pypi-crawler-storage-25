"""
kneo_agent.workflows.handoff_workflow
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Selector-driven handoff workflow runtime.
"""

from __future__ import annotations

import time

from ..core.agent import Agent
from ..core.types import AgentRuntime, Message, RunConfig, RunResult, StreamChunk, ToolResult
from ._base import (
    FunctionStep,
    HumanInTheLoopStep,
    HandoffSelector,
    OrchestrationBase,
    WorkflowComponent,
)


class HandoffWorkflow(OrchestrationBase):
    """Dynamic specialist routing based on a selector callback."""

    def __init__(
        self,
        participants: list[Agent | AgentRuntime | WorkflowComponent | FunctionStep | HumanInTheLoopStep],
        selector: HandoffSelector,
        *,
        name: str = "handoff-workflow",
        description: str = "",
    ) -> None:
        self._name = name
        self._description = description
        self.init_participants(
            participants,
            empty_error="HandoffWorkflow requires at least one participant.",
        )
        self._participants_by_name = {
            participant.name: participant for participant in self.participants
        }
        self._selector = selector

    async def run(
        self,
        messages: list[Message],
        config: RunConfig,
    ) -> RunResult:
        started = time.monotonic()
        current = list(messages)
        tool_results: list[ToolResult] = []
        iterations = 0
        path: list[str] = []

        for index in range(max(config.max_iterations, 1)):
            selected = self._selector(list(current), config, index)
            if selected is None:
                break
            participant = self._participants_by_name.get(selected)
            if participant is None:
                raise ValueError(f"Unknown handoff participant {selected!r}.")
            result = await participant.run(current, config)
            current = list(result.messages) if result.messages else list(current)
            tool_results.extend(result.tool_calls_performed)
            iterations += max(result.iterations, 1)
            path.append(selected)

        return self.build_run_result(
            messages=current,
            iterations=iterations or 1,
            duration_ms=(time.monotonic() - started) * 1000,
            tool_results=tool_results,
            workflow_type="handoff",
            metadata={
                "workflow_steps": path,
            },
        )

    async def stream(self, messages: list[Message], config: RunConfig):
        async for chunk in self.stream_final_result(messages, config):
            yield chunk

    def supports_streaming(self) -> bool:
        return False
