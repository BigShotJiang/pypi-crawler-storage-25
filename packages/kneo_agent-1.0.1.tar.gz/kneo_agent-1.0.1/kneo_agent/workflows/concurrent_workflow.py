"""
kneo_agent.workflows.concurrent_workflow
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Concurrent fan-out workflow runtime.
"""

from __future__ import annotations

import asyncio
import time

from ..core.agent import Agent
from ..core.types import AgentRuntime, Message, RunConfig, RunResult, StreamChunk, ToolResult
from ._base import (
    FunctionStep,
    HumanInTheLoopStep,
    OrchestrationBase,
    WorkflowComponent,
    result_delta,
)


class ConcurrentWorkflow(OrchestrationBase):
    """Run all participants against the same input snapshot in parallel."""

    def __init__(
        self,
        participants: list[Agent | AgentRuntime | WorkflowComponent | FunctionStep | HumanInTheLoopStep],
        *,
        name: str = "concurrent-workflow",
        description: str = "",
    ) -> None:
        self._name = name
        self._description = description
        self.init_participants(participants, empty_error="ConcurrentWorkflow requires at least one participant.")

    async def run(
        self,
        messages: list[Message],
        config: RunConfig,
    ) -> RunResult:
        started = time.monotonic()
        snapshot = list(messages)
        results = await asyncio.gather(*[participant.run(snapshot, config) for participant in self._participants])
        current = list(snapshot)
        tool_results: list[ToolResult] = []
        iterations = 0
        step_names: list[str] = []

        for participant, result in zip(self._participants, results):
            current.extend(result_delta(snapshot, result.messages))
            tool_results.extend(result.tool_calls_performed)
            iterations += max(result.iterations, 1)
            step_names.append(participant.name)

        return self.build_run_result(
            messages=current,
            iterations=iterations,
            duration_ms=(time.monotonic() - started) * 1000,
            tool_results=tool_results,
            workflow_type="concurrent",
            metadata={
                "workflow_steps": step_names,
            },
        )

    async def stream(self, messages: list[Message], config: RunConfig):
        async for chunk in self.stream_final_result(messages, config):
            yield chunk

    def supports_streaming(self) -> bool:
        return False
