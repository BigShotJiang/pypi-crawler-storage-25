"""
kneo_agent.workflows.sequential_workflow
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Sequential composite workflow runtime.
"""

from __future__ import annotations

import time

from ..core.agent import Agent
from ..core.types import AgentRuntime, Message, RunConfig, RunResult, StreamChunk, ToolResult
from ._base import FunctionStep, HumanInTheLoopStep, OrchestrationBase, WorkflowComponent


class SequentialWorkflow(OrchestrationBase):
    """
    Default orchestration runtime that runs participants in order.

    The workflow itself satisfies both ``AgentRuntime`` and
    ``WorkflowComponent`` so it can be nested inside another workflow or
    used directly as an agent runtime.
    """

    def __init__(
        self,
        participants: list[Agent | AgentRuntime | WorkflowComponent | FunctionStep | HumanInTheLoopStep],
        *,
        name: str = "sequential-workflow",
        description: str = "",
    ) -> None:
        self._name = name
        self._description = description
        self.init_participants(participants, empty_error="SequentialWorkflow requires at least one participant.")

    async def run(
        self,
        messages: list[Message],
        config: RunConfig,
    ) -> RunResult:
        started = time.monotonic()
        current = list(messages)
        tool_results: list[ToolResult] = []
        iterations = 0
        step_names: list[str] = []

        for participant in self._participants:
            result = await participant.run(current, config)
            current = list(result.messages) if result.messages else list(current)
            tool_results.extend(result.tool_calls_performed)
            iterations += max(result.iterations, 1)
            step_names.append(participant.name)

        return self.build_run_result(
            messages=current,
            iterations=iterations,
            duration_ms=(time.monotonic() - started) * 1000,
            tool_results=tool_results,
            workflow_type="sequential",
            metadata={
                "workflow_steps": step_names,
            },
        )

    async def stream(
        self,
        messages: list[Message],
        config: RunConfig,
    ):
        if not self.supports_streaming():
            raise NotImplementedError(
                f'Workflow "{self._name}" does not support streaming because one or more '
                "participants are non-streaming."
            )

        current = list(messages)
        for participant in self._participants:
            buffer: list[str] = []
            async for chunk in participant.stream(current, config):  # type: ignore[attr-defined]
                if chunk.type == "text" and chunk.content:
                    buffer.append(chunk.content)
                if chunk.type != "done":
                    yield chunk
            if buffer:
                current.append(Message(role="assistant", content="".join(buffer), name=participant.name))
        yield StreamChunk(type="done")

    def supports_streaming(self) -> bool:
        return all(participant.supports_streaming() for participant in self._participants)
