"""
kneo_agent.workflows.group_chat_workflow
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Round-robin group chat workflow runtime.
"""

from __future__ import annotations

import time

from ..core.agent import Agent
from ..core.types import AgentRuntime, Message, RunConfig, RunResult, StreamChunk, ToolResult
from ._base import FunctionStep, HumanInTheLoopStep, OrchestrationBase, WorkflowComponent


class GroupChatWorkflow(OrchestrationBase):
    """Round-robin shared-conversation orchestration."""

    def __init__(
        self,
        participants: list[Agent | AgentRuntime | WorkflowComponent | FunctionStep | HumanInTheLoopStep],
        *,
        rounds: int = 1,
        name: str = "group-chat-workflow",
        description: str = "",
    ) -> None:
        if rounds < 1:
            raise ValueError("GroupChatWorkflow rounds must be >= 1.")
        self._name = name
        self._description = description
        self.init_participants(participants, empty_error="GroupChatWorkflow requires at least one participant.")
        self._rounds = rounds

    async def run(
        self,
        messages: list[Message],
        config: RunConfig,
    ) -> RunResult:
        started = time.monotonic()
        current = list(messages)
        tool_results: list[ToolResult] = []
        iterations = 0
        path: list[str] = []

        for _ in range(self._rounds):
            for participant in self._participants:
                result = await participant.run(current, config)
                current = list(result.messages) if result.messages else list(current)
                tool_results.extend(result.tool_calls_performed)
                iterations += max(result.iterations, 1)
                path.append(participant.name)

        return self.build_run_result(
            messages=current,
            iterations=iterations,
            duration_ms=(time.monotonic() - started) * 1000,
            tool_results=tool_results,
            workflow_type="group-chat",
            metadata={
                "workflow_steps": path,
                "workflow_rounds": self._rounds,
            },
        )

    async def stream(self, messages: list[Message], config: RunConfig):
        async for chunk in self.stream_final_result(messages, config):
            yield chunk

    def supports_streaming(self) -> bool:
        return False
