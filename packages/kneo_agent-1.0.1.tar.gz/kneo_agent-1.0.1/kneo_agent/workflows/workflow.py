"""
kneo_agent.workflows.workflow
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Graph workflow runtime with explicit executors and edges.
"""

from __future__ import annotations

import asyncio
import time
from typing import Any

from ..core.types import Message, RunConfig, RunResult, StreamChunk, ToolResult
from ._base import (
    WorkflowComponent,
    WorkflowEdge,
    WorkflowRuntimeBase,
    dedupe_preserve,
    last_assistant_content,
    result_delta,
)


class Workflow(WorkflowRuntimeBase):
    """
    General graph workflow with explicit executors and edges.

    Execution follows supersteps:
    1. invoke all pending executors for the current step
    2. merge their output into the shared conversation
    3. route to downstream executors via matching edges
    """

    def __init__(
        self,
        executors: dict[str, WorkflowComponent],
        *,
        start_executor_ids: list[str],
        edges: list[WorkflowEdge] | None = None,
        name: str = "workflow",
        description: str = "",
    ) -> None:
        if not executors:
            raise ValueError("Workflow requires at least one executor.")
        if not start_executor_ids:
            raise ValueError("Workflow requires at least one start executor.")
        unknown = [executor_id for executor_id in start_executor_ids if executor_id not in executors]
        if unknown:
            raise ValueError(f"Unknown start executor(s): {unknown}")
        self._executors = dict(executors)
        self._start_executor_ids = list(start_executor_ids)
        self._edges = list(edges or [])
        self._name = name
        self._description = description

    @property
    def executors(self) -> dict[str, WorkflowComponent]:
        return dict(self._executors)

    @property
    def edges(self) -> list[WorkflowEdge]:
        return list(self._edges)

    async def run(
        self,
        messages: list[Message],
        config: RunConfig,
    ) -> RunResult:
        started = time.monotonic()
        current = list(messages)
        pending = list(self._start_executor_ids)
        route_supersteps: list[list[str]] = []
        all_tool_results: list[ToolResult] = []
        iterations = 0
        stopped_by_limit = False

        for _superstep in range(1, max(config.max_iterations, 1) + 1):
            if not pending:
                break
            snapshot = list(current)
            pending = dedupe_preserve(pending)
            executors = [self._executors[executor_id] for executor_id in pending]
            results = await asyncio.gather(*[executor.run(snapshot, config) for executor in executors])

            next_pending: list[str] = []
            route_supersteps.append(list(pending))
            for executor_id, result in zip(pending, results):
                delta = result_delta(snapshot, result.messages)
                current.extend(delta)
                all_tool_results.extend(result.tool_calls_performed)
                iterations += max(result.iterations, 1)
                outgoing = [edge for edge in self._edges if edge.source == executor_id]
                for edge in outgoing:
                    if edge.condition is None or edge.condition(result, current, config):
                        next_pending.append(edge.target)
            pending = next_pending
        else:
            if pending:
                stopped_by_limit = True

        metadata: dict[str, Any] = {
            "workflow": self._name,
            "workflow_description": self._description,
            "workflow_supersteps": route_supersteps,
            "workflow_steps": [step for superstep in route_supersteps for step in superstep],
            "workflow_type": "graph",
        }
        if stopped_by_limit:
            metadata["stopped_by_max_iterations"] = True

        return RunResult(
            final_message=last_assistant_content(current),
            messages=current,
            iterations=iterations or len(route_supersteps) or 1,
            tool_calls_performed=all_tool_results,
            duration_ms=(time.monotonic() - started) * 1000,
            metadata=metadata,
        )

    async def stream(
        self,
        messages: list[Message],
        config: RunConfig,
    ):
        result = await self.run(messages, config)
        if result.final_message:
            yield StreamChunk(type="text", content=result.final_message)
        yield StreamChunk(type="done")

    def supports_streaming(self) -> bool:
        return False
