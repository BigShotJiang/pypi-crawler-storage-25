"""
kneo_agent.workflows._base
~~~~~~~~~~~~~~~~~~~~~~~~~~
Shared workflow protocols, helpers, and lightweight building blocks.
"""

from __future__ import annotations

import inspect
import time
from dataclasses import dataclass, field
from typing import Any, Awaitable, Callable, Protocol, runtime_checkable

from ..core.agent import Agent
from ..core.exceptions import HumanInterventionRequiredError
from ..core.types import AgentRuntime, Message, RunConfig, RunResult, StreamChunk, ToolResult

WorkflowReturn = RunResult | Message | list[Message] | str | None
WorkflowHandler = Callable[[list[Message], RunConfig], WorkflowReturn | Awaitable[WorkflowReturn]]
RouteCondition = Callable[[RunResult, list[Message], RunConfig], bool]
HandoffSelector = Callable[[list[Message], RunConfig, int], str | None]
HumanPromptBuilder = Callable[[list[Message], RunConfig], str | Awaitable[str]]
HumanResolver = Callable[
    ["HumanInterventionRequest"],
    WorkflowReturn | Awaitable[WorkflowReturn],
]


def last_assistant_content(messages: list[Message]) -> str:
    return next((m.content for m in reversed(messages) if m.role == "assistant"), "")


def dedupe_preserve(items: list[str]) -> list[str]:
    seen: set[str] = set()
    result: list[str] = []
    for item in items:
        if item in seen:
            continue
        seen.add(item)
        result.append(item)
    return result


def result_delta(input_messages: list[Message], result_messages: list[Message]) -> list[Message]:
    if len(result_messages) >= len(input_messages) and result_messages[: len(input_messages)] == input_messages:
        return list(result_messages[len(input_messages) :])
    return list(result_messages)


@runtime_checkable
class WorkflowComponent(Protocol):
    """A workflow node that consumes full conversation history."""

    @property
    def name(self) -> str:
        ...

    async def run(
        self,
        messages: list[Message],
        config: RunConfig,
    ) -> RunResult:
        ...

    def supports_streaming(self) -> bool:
        ...


@dataclass(frozen=True)
class WorkflowEdge:
    """Graph edge between two workflow executors."""

    source: str
    target: str
    condition: RouteCondition | None = None
    label: str = ""


@dataclass
class FunctionStep:
    """
    Leaf workflow participant backed by a Python callable.

    The handler receives the full message history and current ``RunConfig``.
    It may return:

    - ``RunResult`` for full control
    - ``Message`` or ``list[Message]`` to append to the conversation
    - ``str`` to append as an assistant message
    - ``None`` to leave the conversation unchanged
    """

    step_name: str
    handler: WorkflowHandler
    description: str = ""

    @property
    def name(self) -> str:
        return self.step_name

    async def run(
        self,
        messages: list[Message],
        config: RunConfig,
    ) -> RunResult:
        started = time.monotonic()
        output = self.handler(list(messages), config)
        if inspect.isawaitable(output):
            output = await output
        return coerce_step_output(
            name=self.step_name,
            input_messages=messages,
            output=output,
            duration_ms=(time.monotonic() - started) * 1000,
        )

    def supports_streaming(self) -> bool:
        return False


FunctionExecutor = FunctionStep


@dataclass(frozen=True)
class HumanInterventionRequest:
    """Structured request emitted when a workflow needs human input."""

    step_name: str
    prompt: str
    messages: list[Message] = field(default_factory=list)
    config: RunConfig | None = None
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class HumanInTheLoopStep:
    """
    Workflow participant that requests explicit human input.

    If ``resolver`` is not provided, or returns ``None``, the step raises
    ``HumanInterventionRequiredError`` with a structured request payload so
    the host application can pause and resume out-of-band.
    """

    step_name: str
    prompt: str | HumanPromptBuilder
    resolver: HumanResolver | None = None
    description: str = ""
    response_role: str = "user"
    metadata: dict[str, Any] = field(default_factory=dict)

    @property
    def name(self) -> str:
        return self.step_name

    async def run(
        self,
        messages: list[Message],
        config: RunConfig,
    ) -> RunResult:
        started = time.monotonic()
        prompt = self.prompt(list(messages), config) if callable(self.prompt) else self.prompt
        if inspect.isawaitable(prompt):
            prompt = await prompt
        request = HumanInterventionRequest(
            step_name=self.step_name,
            prompt=prompt,
            messages=list(messages),
            config=config,
            metadata=dict(self.metadata),
        )

        if self.resolver is None:
            raise self._build_pause(request)

        output = self.resolver(request)
        if inspect.isawaitable(output):
            output = await output
        if output is None:
            raise self._build_pause(request)

        result = coerce_human_output(
            name=self.step_name,
            input_messages=messages,
            output=output,
            duration_ms=(time.monotonic() - started) * 1000,
            response_role=self.response_role,
        )
        result.metadata = {
            **result.metadata,
            "human_in_the_loop": True,
            "human_step": self.step_name,
            "human_prompt": prompt,
            **self.metadata,
        }
        return result

    def supports_streaming(self) -> bool:
        return False

    @staticmethod
    def _build_pause(request: HumanInterventionRequest) -> HumanInterventionRequiredError:
        return HumanInterventionRequiredError(
            step_name=request.step_name,
            prompt=request.prompt,
            request={
                "step_name": request.step_name,
                "prompt": request.prompt,
                "messages": request.messages,
                "metadata": request.metadata,
            },
        )


class WorkflowRuntimeBase:
    """Shared workflow runtime helpers."""

    _name: str
    _description: str

    @property
    def name(self) -> str:
        return self._name

    @property
    def description(self) -> str:
        return self._description

    def supports_tools(self) -> bool:
        return True

    def as_agent(
        self,
        *,
        name: str | None = None,
        description: str = "",
        system_prompt: str | None = None,
    ) -> Agent:
        from ..core.config import AgentBuilder

        builder = (
            AgentBuilder()
            .with_name(name or self._name)
            .with_description(description or self._description)
            .use_runtime(self)  # type: ignore[arg-type]
        )
        if system_prompt:
            builder = builder.with_system_prompt(system_prompt)
        return builder.build()

    def build_run_result(
        self,
        *,
        messages: list[Message],
        iterations: int,
        tool_results: list[ToolResult],
        duration_ms: float,
        workflow_type: str,
        metadata: dict[str, Any] | None = None,
    ) -> RunResult:
        combined_metadata = {
            "workflow": self._name,
            "workflow_description": self._description,
            "workflow_type": workflow_type,
        }
        if metadata:
            combined_metadata.update(metadata)
        return RunResult(
            final_message=last_assistant_content(messages),
            messages=messages,
            iterations=iterations,
            tool_calls_performed=tool_results,
            duration_ms=duration_ms,
            metadata=combined_metadata,
        )

    async def stream_final_result(
        self,
        messages: list[Message],
        config: RunConfig,
    ):
        result = await self.run(messages, config)  # type: ignore[attr-defined]
        if result.final_message:
            yield StreamChunk(type="text", content=result.final_message)
        yield StreamChunk(type="done")


class OrchestrationBase(WorkflowRuntimeBase):
    """Common setup for orchestrations backed by an ordered participant list."""

    def init_participants(
        self,
        participants: list[Agent | AgentRuntime | WorkflowComponent | FunctionStep],
        *,
        empty_error: str,
    ) -> None:
        if not participants:
            raise ValueError(empty_error)
        self._participants = [coerce_component(participant) for participant in participants]

    @property
    def participants(self) -> list[WorkflowComponent]:
        return list(self._participants)


class AgentStep:
    """Adapter that lets an ``Agent`` participate in a workflow."""

    def __init__(self, agent: Agent) -> None:
        self._agent = agent

    @property
    def name(self) -> str:
        return self._agent.agent_name

    async def run(
        self,
        messages: list[Message],
        config: RunConfig,
    ) -> RunResult:
        merged = self._agent._build_run_config(config, {}, skills=None)  # type: ignore[attr-defined]
        return await self._agent._runtime.run(list(messages), merged)  # type: ignore[attr-defined]

    def supports_streaming(self) -> bool:
        return self._agent._runtime.supports_streaming()  # type: ignore[attr-defined]

    async def stream(
        self,
        messages: list[Message],
        config: RunConfig,
    ):
        async for chunk in self._agent._runtime.stream(messages, config):  # type: ignore[attr-defined]
            yield chunk


def component_name(
    participant: Agent | AgentRuntime | WorkflowComponent | FunctionStep | str,
) -> str:
    if isinstance(participant, str):
        return participant
    if isinstance(participant, Agent):
        return participant.agent_name
    return participant.name


def coerce_component(
    participant: Agent | AgentRuntime | WorkflowComponent | FunctionStep | HumanInTheLoopStep,
) -> WorkflowComponent:
    if isinstance(participant, Agent):
        return AgentStep(participant)
    if isinstance(participant, (FunctionStep, HumanInTheLoopStep)):
        return participant
    if isinstance(participant, WorkflowComponent):
        return participant
    if isinstance(participant, AgentRuntime):
        return participant
    raise TypeError(
        "Workflow participants must be Agent, AgentRuntime, Workflow-compatible, "
        "or FunctionStep instances."
    )


def coerce_step_output(
    *,
    name: str,
    input_messages: list[Message],
    output: WorkflowReturn,
    duration_ms: float,
) -> RunResult:
    if isinstance(output, RunResult):
        return output

    appended: list[Message]
    if output is None:
        appended = []
    elif isinstance(output, Message):
        appended = [output]
    elif isinstance(output, str):
        appended = [Message(role="assistant", content=output, name=name)]
    elif isinstance(output, list):
        appended = list(output)
    else:
        raise TypeError(
            "FunctionStep handlers must return RunResult, Message, list[Message], str, or None."
        )

    messages = [*input_messages, *appended]
    return RunResult(
        final_message=last_assistant_content(messages),
        messages=messages,
        iterations=1,
        tool_calls_performed=[],
        duration_ms=duration_ms,
        metadata={"workflow_step": name},
    )


def coerce_human_output(
    *,
    name: str,
    input_messages: list[Message],
    output: WorkflowReturn,
    duration_ms: float,
    response_role: str,
) -> RunResult:
    if isinstance(output, str):
        output = Message(role=response_role, content=output, name=name)
    return coerce_step_output(
        name=name,
        input_messages=input_messages,
        output=output,
        duration_ms=duration_ms,
    )
