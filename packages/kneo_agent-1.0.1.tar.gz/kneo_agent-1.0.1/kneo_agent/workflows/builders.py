"""
kneo_agent.workflows.builders
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Workflow builders and convenience factory helpers.
"""

from __future__ import annotations

from ..core.agent import Agent
from ..core.types import AgentRuntime
from ._base import (
    FunctionStep,
    HumanInTheLoopStep,
    HumanPromptBuilder,
    HumanResolver,
    HandoffSelector,
    RouteCondition,
    WorkflowComponent,
    WorkflowEdge,
    WorkflowHandler,
    coerce_component,
    component_name,
)
from .concurrent_workflow import ConcurrentWorkflow
from .group_chat_workflow import GroupChatWorkflow
from .handoff_workflow import HandoffWorkflow
from .sequential_workflow import SequentialWorkflow
from .workflow import Workflow


class WorkflowBuilder:
    """Builder for graph workflows plus convenience factory helpers."""

    def __init__(
        self,
        start_executor: Agent | AgentRuntime | WorkflowComponent | FunctionStep | HumanInTheLoopStep,
        *,
        name: str = "workflow",
        description: str = "",
    ) -> None:
        component = coerce_component(start_executor)
        self._executors: dict[str, WorkflowComponent] = {component.name: component}
        self._start_executor_ids = [component.name]
        self._edges: list[WorkflowEdge] = []
        self._name = name
        self._description = description

    def add_executor(
        self,
        executor: Agent | AgentRuntime | WorkflowComponent | FunctionStep | HumanInTheLoopStep,
    ) -> "WorkflowBuilder":
        component = coerce_component(executor)
        self._executors[component.name] = component
        return self

    def add_edge(
        self,
        source: Agent | AgentRuntime | WorkflowComponent | FunctionStep | HumanInTheLoopStep | str,
        target: Agent | AgentRuntime | WorkflowComponent | FunctionStep | HumanInTheLoopStep | str,
        *,
        condition: RouteCondition | None = None,
        label: str = "",
    ) -> "WorkflowBuilder":
        source_name = component_name(source)
        target_name = component_name(target)
        if source_name not in self._executors:
            raise ValueError(f"Unknown source executor {source_name!r}.")
        if target_name not in self._executors:
            raise ValueError(f"Unknown target executor {target_name!r}.")
        self._edges.append(WorkflowEdge(source=source_name, target=target_name, condition=condition, label=label))
        return self

    def build(self) -> Workflow:
        return Workflow(
            self._executors,
            start_executor_ids=self._start_executor_ids,
            edges=self._edges,
            name=self._name,
            description=self._description,
        )

    @staticmethod
    def step(name: str, handler: WorkflowHandler, *, description: str = "") -> FunctionStep:
        return FunctionStep(step_name=name, handler=handler, description=description)

    @staticmethod
    def human_step(
        name: str,
        prompt: str | HumanPromptBuilder,
        *,
        resolver: HumanResolver | None = None,
        description: str = "",
        response_role: str = "user",
        metadata: dict[str, object] | None = None,
    ) -> HumanInTheLoopStep:
        return HumanInTheLoopStep(
            step_name=name,
            prompt=prompt,
            resolver=resolver,
            description=description,
            response_role=response_role,
            metadata=dict(metadata or {}),
        )

    @staticmethod
    def sequential(
        participants: list[Agent | AgentRuntime | WorkflowComponent | FunctionStep | HumanInTheLoopStep],
        *,
        name: str = "sequential-workflow",
        description: str = "",
    ) -> SequentialWorkflow:
        return SequentialWorkflow(participants, name=name, description=description)

    @staticmethod
    def concurrent(
        participants: list[Agent | AgentRuntime | WorkflowComponent | FunctionStep | HumanInTheLoopStep],
        *,
        name: str = "concurrent-workflow",
        description: str = "",
    ) -> ConcurrentWorkflow:
        return ConcurrentWorkflow(participants, name=name, description=description)


class SequentialBuilder:
    """Builder for the default sequential orchestration runtime."""

    def __init__(
        self,
        participants: list[Agent | AgentRuntime | WorkflowComponent | FunctionStep | HumanInTheLoopStep],
        *,
        name: str = "sequential-workflow",
        description: str = "",
    ) -> None:
        self._participants = list(participants)
        self._name = name
        self._description = description

    def build(self) -> SequentialWorkflow:
        return SequentialWorkflow(self._participants, name=self._name, description=self._description)


class ConcurrentBuilder:
    """Builder for concurrent orchestration."""

    def __init__(
        self,
        participants: list[Agent | AgentRuntime | WorkflowComponent | FunctionStep | HumanInTheLoopStep],
        *,
        name: str = "concurrent-workflow",
        description: str = "",
    ) -> None:
        self._participants = list(participants)
        self._name = name
        self._description = description

    def build(self) -> ConcurrentWorkflow:
        return ConcurrentWorkflow(self._participants, name=self._name, description=self._description)


class HandoffBuilder:
    """Builder for handoff orchestration."""

    def __init__(
        self,
        participants: list[Agent | AgentRuntime | WorkflowComponent | FunctionStep | HumanInTheLoopStep],
        selector: HandoffSelector,
        *,
        name: str = "handoff-workflow",
        description: str = "",
    ) -> None:
        self._participants = list(participants)
        self._selector = selector
        self._name = name
        self._description = description

    def build(self) -> HandoffWorkflow:
        return HandoffWorkflow(
            self._participants,
            self._selector,
            name=self._name,
            description=self._description,
        )


class GroupChatBuilder:
    """Builder for round-robin shared-conversation orchestration."""

    def __init__(
        self,
        participants: list[Agent | AgentRuntime | WorkflowComponent | FunctionStep],
        *,
        rounds: int = 1,
        name: str = "group-chat-workflow",
        description: str = "",
    ) -> None:
        self._participants = list(participants)
        self._rounds = rounds
        self._name = name
        self._description = description

    def build(self) -> GroupChatWorkflow:
        return GroupChatWorkflow(
            self._participants,
            rounds=self._rounds,
            name=self._name,
            description=self._description,
        )
