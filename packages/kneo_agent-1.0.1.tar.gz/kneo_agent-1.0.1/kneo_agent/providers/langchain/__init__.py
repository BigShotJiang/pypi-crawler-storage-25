"""
kneo_agent.providers.langchain
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
LangChain provider — Bridge RuntimeImpl.
"""

from .impl import LangChainImpl

__all__ = ["LangChainImpl"]
