"""
kneo_agent.providers.langchain.impl
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Bridge ``RuntimeImpl`` for LangChain chat models.

Works with any ``BaseChatModel`` subclass (``ChatOpenAI``, ``ChatAnthropic``,
``ChatGoogleGenerativeAI``, …).  Tool handlers are registered in a plain
``dict`` — no ``StructuredTool`` wrapping required.

Install dependency::

    pip install kneo-agent[langchain]
"""

from __future__ import annotations

import asyncio
import json
import logging
from typing import Any, AsyncGenerator, Callable

from ...core.types import Message, RunConfig, ToolCall, ToolDefinition

logger = logging.getLogger(__name__)

ToolHandler = Callable[[dict[str, Any]], Any]


class LangChainImpl:
    """
    Concrete RuntimeImpl wrapping a LangChain ``BaseChatModel``.

    Bridge usage::

        from langchain_openai import ChatOpenAI
        impl = LangChainImpl(ChatOpenAI(model="gpt-4o"))
        impl.register_tool("get_weather", my_weather_fn)
        runtime = ReActAgentExecutor(impl)

    Tools are registered as plain callables; LangChain's ``StructuredTool``
    machinery is not required at this layer.
    """

    platform_name = "langchain"

    def __init__(
        self,
        chat_model: Any,
        tool_registry: dict[str, ToolHandler] | None = None,
    ) -> None:
        self._model = chat_model
        self._registry: dict[str, ToolHandler] = tool_registry or {}

    # ── Tool registration ──────────────────────────────────────

    def register_tool(self, name: str, handler: ToolHandler) -> None:
        """Register a callable for the given tool name."""
        self._registry[name] = handler

    # ── RuntimeImpl protocol ───────────────────────────────────

    async def complete(
        self, messages: list[Message], config: RunConfig
    ) -> tuple[str, list[ToolCall]]:
        lc_msgs = self._to_lc_messages(messages, config.system_prompt)

        if config.tools and hasattr(self._model, "bind_tools"):
            lc_tools = [self._to_lc_tool(t) for t in config.tools]
            model = self._model.bind_tools(lc_tools)
        else:
            model = self._model

        logger.debug("LangChainImpl.complete → %d messages.", len(lc_msgs))
        response = await model.ainvoke(lc_msgs)

        if isinstance(response.content, str):
            text = response.content
        else:
            text = "".join(
                b.get("text", "")
                for b in response.content
                if isinstance(b, dict)
            )

        tool_calls = [
            ToolCall(id=tc["id"], name=tc["name"], arguments=tc["args"])
            for tc in (getattr(response, "tool_calls", None) or [])
        ]
        return text, tool_calls

    async def execute_tool(self, call: ToolCall, config: RunConfig) -> str:
        handler = self._registry.get(call.name)
        if handler is None:
            handler = (config.extra.get("tool_handlers") or {}).get(call.name)
        if not handler:
            logger.error("Tool '%s' not registered.", call.name)
            return json.dumps({"error": f'Tool "{call.name}" not registered.'})
        result = handler(call.arguments)
        if asyncio.iscoroutine(result):
            result = await result
        return result if isinstance(result, str) else json.dumps(result)

    async def stream_tokens(
        self, messages: list[Message], config: RunConfig
    ) -> AsyncGenerator[str, None]:
        lc_msgs = self._to_lc_messages(messages, config.system_prompt)
        async for chunk in self._model.astream(lc_msgs):
            if chunk.content:
                yield chunk.content

    def supports_tools(self) -> bool:
        return True

    def supports_streaming(self) -> bool:
        return hasattr(self._model, "astream")

    # ── Private helpers ────────────────────────────────────────

    def _to_lc_messages(
        self, messages: list[Message], system_prompt: str | None
    ) -> list[Any]:
        try:
            from langchain_core.messages import (
                AIMessage, HumanMessage, SystemMessage, ToolMessage,
            )
        except ImportError:
            # Fallback dicts for testing without langchain installed
            def HumanMessage(content):   return {"type": "human",  "content": content}  # noqa
            def AIMessage(content):      return {"type": "ai",     "content": content}  # noqa
            def SystemMessage(content):  return {"type": "system", "content": content}  # noqa
            def ToolMessage(content, tool_call_id, name):  # noqa
                return {"type": "tool", "content": content, "tool_call_id": tool_call_id}

        result = []
        if system_prompt:
            result.append(SystemMessage(content=system_prompt))
        for m in messages:
            if m.role == "user":
                result.append(HumanMessage(content=m.content))
            elif m.role == "assistant":
                result.append(AIMessage(content=m.content))
            elif m.role == "tool":
                result.append(ToolMessage(
                    content=m.content,
                    tool_call_id=m.tool_call_id,
                    name=m.name,
                ))
            elif m.role == "system":
                result.append(SystemMessage(content=m.content))
        return result

    @staticmethod
    def _to_lc_tool(t: ToolDefinition) -> dict:
        return {
            "type": "function",
            "name": t.name,
            "description": t.description,
            "parameters": t.parameters,
        }
