"""
kneo_agent.providers
~~~~~~~~~~~~~~~~~~~~~
Platform-specific provider runtimes.

Each sub-package isolates one provider's optional dependencies so that
installing ``kneo-agent`` without any extras still works — providers are
imported only when their sub-package is explicitly used.

Sub-packages
------------
``google_adk``
    ``GoogleADKImpl`` — compatibility translation over ADK-shaped payloads.
``openai_agents``
    ``OpenAIAgentsImpl`` — wraps the OpenAI Agents SDK runner.
``langchain``
    ``LangChainImpl`` — wraps any ``langchain_core`` ``BaseChatModel``.
"""

from .google_adk import GoogleADKImpl
from .langchain import LangChainImpl
from .openai_agents import OpenAIAgentsImpl

__all__ = ["GoogleADKImpl", "LangChainImpl", "OpenAIAgentsImpl"]
