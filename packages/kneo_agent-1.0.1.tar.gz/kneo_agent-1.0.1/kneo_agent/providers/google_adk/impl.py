"""
kneo_agent.providers.google_adk.impl
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Compatibility ``RuntimeImpl`` for Google ADK.

Translates between Kneo Agent's ``list[Message]`` / ``RunConfig`` and the
Google ADK ``Content`` / ``GenerationConfig`` wire format.

This is not a native ADK runtime. Kneo Agent still owns the loop strategy
when this class is used via the Bridge pattern. For the real ADK-owned loop,
use ``GoogleADKAdapter`` instead.

Install dependency::

    pip install kneo-agent[google-adk]
"""

from __future__ import annotations

import asyncio
import json
import logging
from typing import Any, AsyncGenerator

from ...core.types import Message, RunConfig, ToolCall

logger = logging.getLogger(__name__)


class GoogleADKImpl:
    """
    Concrete compatibility RuntimeImpl for Google ADK.

    Injected into any ``AgentExecutor`` subclass via the Bridge pattern::

        impl = GoogleADKImpl(adk_runner, session_id="s-001")
        runtime = ReActAgentExecutor(impl)

    This preserves Kneo's strategy-swapping API, but it does so by translating
    Kneo messages to ADK-shaped payloads. It does not hand loop ownership to
    the Google ADK runtime itself.
    """

    platform_name = "google-adk"

    def __init__(self, adk_runner: Any, session_id: str) -> None:
        """
        Parameters
        ----------
        adk_runner:
            A ``google.adk.runners.InMemoryRunner`` (or compatible) instance.
        session_id:
            The ADK session identifier for this conversation.
        """
        self._runner = adk_runner
        self._session_id = session_id

    # ── RuntimeImpl protocol ───────────────────────────────────

    async def complete(
        self, messages: list[Message], config: RunConfig
    ) -> tuple[str, list[ToolCall]]:
        payload = self._build_payload(messages, config)
        logger.debug("GoogleADKImpl.complete → session=%s", self._session_id)
        response: dict = await self._runner.run(self._session_id, payload)

        parts: list[dict] = (
            response.get("candidates", [{}])[0]
            .get("content", {})
            .get("parts", [])
        )
        text = "".join(p.get("text", "") for p in parts if "text" in p)
        tool_calls = [
            ToolCall(
                id=p["functionCall"]["id"],
                name=p["functionCall"]["name"],
                arguments=p["functionCall"]["args"],
            )
            for p in parts
            if "functionCall" in p
        ]
        return text, tool_calls

    async def execute_tool(self, call: ToolCall, config: RunConfig) -> str:
        # ADK dispatches tools through its own FunctionTool registry.
        # This fallback covers manual tool execution outside ADK's pipeline.
        logger.debug("GoogleADKImpl.execute_tool → %s", call.name)
        handlers = config.extra.get("tool_handlers") or {}
        handler = handlers.get(call.name)
        if handler is not None:
            result = handler(call.arguments)
            if asyncio.iscoroutine(result):
                result = await result
            return result if isinstance(result, str) else json.dumps(result)
        return json.dumps({
            "status": "executed",
            "tool": call.name,
            "args": call.arguments,
        })

    async def stream_tokens(
        self, messages: list[Message], config: RunConfig
    ) -> AsyncGenerator[str, None]:
        # Real ADK streaming uses Server-Sent Events from runner.stream_run().
        # This implementation word-tokenises the complete() output as a
        # simulation; replace with runner.stream_run() in production.
        text, _ = await self.complete(messages, config)
        for word in text.split(" "):
            yield word + " "
            await asyncio.sleep(0)   # yield control each word

    def supports_tools(self) -> bool:
        return True

    def supports_streaming(self) -> bool:
        return True

    # ── Private helpers ────────────────────────────────────────

    def _build_payload(self, messages: list[Message], config: RunConfig) -> dict:
        return {
            "contents": [self._message_to_content(m) for m in messages],
            "tools": [
                {
                    "functionDeclarations": [{
                        "name": t.name,
                        "description": t.description,
                        "parameters": t.parameters,
                    }]
                }
                for t in config.tools
            ],
            "generationConfig": {
                "temperature": config.temperature,
                **(config.extra or {}),
            },
            "systemInstruction": (
                {"parts": [{"text": config.system_prompt}]}
                if config.system_prompt else None
            ),
        }

    @staticmethod
    def _message_to_content(message: Message) -> dict[str, Any]:
        if message.role == "assistant":
            parts: list[dict[str, Any]] = []
            if message.content:
                parts.append({"text": message.content})
            parts.extend(
                {
                    "functionCall": {
                        "id": tc.id,
                        "name": tc.name,
                        "args": tc.arguments,
                    }
                }
                for tc in message.tool_calls
            )
            return {"role": "model", "parts": parts or [{"text": ""}]}

        if message.role == "tool":
            function_response: dict[str, Any] = {
                "name": message.name or "tool",
                "response": {"result": message.content},
            }
            if message.tool_call_id is not None:
                function_response["id"] = message.tool_call_id
            return {
                "role": "user",
                "parts": [{"functionResponse": function_response}],
            }

        return {"role": "user", "parts": [{"text": message.content}]}
