"""
kneo_agent.providers.google_adk
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Google ADK provider — Bridge RuntimeImpl + convenience factory.
"""

from .impl import GoogleADKImpl

__all__ = ["GoogleADKImpl"]
