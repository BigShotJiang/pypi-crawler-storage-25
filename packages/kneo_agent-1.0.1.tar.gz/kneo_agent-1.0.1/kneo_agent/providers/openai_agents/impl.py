"""
kneo_agent.providers.openai_agents.impl
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
OpenAI Agents SDK-backed runtime.

This runtime uses the OpenAI Agents SDK directly rather than translating
through the Chat Completions API. The SDK owns the tool loop for OpenAI
executions, while Kneo Agent preserves its public AgentRuntime surface.

Install dependency::

    pip install kneo-agent[openai]
"""

from __future__ import annotations

import inspect
import json
import logging
import time
from typing import Any, AsyncGenerator

from ...core.types import AgentRuntime, Message, RunConfig, RunResult, StreamChunk, ToolCall, ToolResult

logger = logging.getLogger(__name__)


class OpenAIAgentsImpl:
    """
    OpenAI Agents SDK-backed AgentRuntime.

    The OpenAI Agents SDK owns its own tool loop, so this class exposes the
    high-level ``AgentRuntime`` interface directly instead of implementing the
    lower-level Bridge ``RuntimeImpl`` contract.
    """

    PLANNING_SUFFIX = (
        "\n\nBefore acting, output a numbered list of the steps you will take. "
        "Do NOT execute any steps yet - plan only."
    )

    def __init__(
        self,
        openai_client: Any | None = None,
        model: str = "gpt-4o",
        strategy: str = "react",
        runner: Any | None = None,
    ) -> None:
        self._client = openai_client
        self._model = model
        self._strategy = strategy
        self._runner = runner

    @property
    def name(self) -> str:
        return f"{self._strategy}@openai-agents"

    async def run(
        self,
        messages: list[Message],
        config: RunConfig,
    ) -> RunResult:
        if self._strategy == "plan-act":
            return await self._run_plan_act(messages, config)

        with_tools = self._strategy != "simple"
        start = time.monotonic()
        sdk_result = await self._run_agent(
            messages,
            config,
            instructions=config.system_prompt,
            with_tools=with_tools,
        )
        return self._result_from_sdk(
            messages,
            sdk_result,
            duration_ms=(time.monotonic() - start) * 1000,
        )

    async def stream(
        self,
        messages: list[Message],
        config: RunConfig,
    ) -> AsyncGenerator[StreamChunk, None]:
        if self._strategy == "plan-act":
            result = await self.run(messages, config)
            if result.final_message:
                yield StreamChunk(type="text", content=result.final_message)
            yield StreamChunk(type="done")
            return

        runner = self._resolve_runner()
        agent = self._build_agent(
            config=config,
            instructions=config.system_prompt,
            with_tools=(self._strategy != "simple"),
        )
        input_text = self._build_input(messages)
        streamed = runner.run_streamed(
            starting_agent=agent,
            input=input_text,
            max_turns=config.max_iterations,
        )
        if inspect.isawaitable(streamed):
            streamed = await streamed

        tool_names: dict[str, str] = {}
        saw_text = False

        async for event in streamed.stream_events():
            event_type = self._value(event, "type")
            if event_type == "raw_response_event":
                delta = self._extract_raw_text_delta(self._value(event, "data"))
                if delta:
                    saw_text = True
                    yield StreamChunk(type="text", content=delta)
                continue

            if event_type != "run_item_stream_event":
                continue

            item = self._value(event, "item")
            event_name = self._value(event, "name")
            if event_name == "tool_called":
                tool_call = self._tool_call_from_item(item)
                if tool_call is not None:
                    tool_names[tool_call.id] = tool_call.name
                    yield StreamChunk(type="tool_call", tool_call=tool_call)
            elif event_name == "tool_output":
                tool_result = self._tool_result_from_item(item, tool_names)
                if tool_result is not None:
                    yield StreamChunk(type="tool_result", tool_result=tool_result)

        if not saw_text:
            final_text = self._extract_final_text(streamed)
            if final_text:
                yield StreamChunk(type="text", content=final_text)
        yield StreamChunk(type="done")

    def supports_streaming(self) -> bool:
        return True

    def supports_tools(self) -> bool:
        return True

    async def _run_plan_act(
        self,
        messages: list[Message],
        config: RunConfig,
    ) -> RunResult:
        start = time.monotonic()
        plan_result = await self._run_agent(
            messages,
            config,
            instructions=(config.system_prompt or "") + self.PLANNING_SUFFIX,
            with_tools=False,
        )
        plan_text = self._extract_final_text(plan_result)
        execution_messages = [*messages, Message(role="assistant", content=f"Plan:\n{plan_text}")]
        execution_result = await self._run_agent(
            execution_messages,
            config,
            instructions=config.system_prompt,
            with_tools=True,
        )
        return self._result_from_sdk(
            messages,
            execution_result,
            duration_ms=(time.monotonic() - start) * 1000,
            metadata={"plan": plan_text},
        )

    async def _run_agent(
        self,
        messages: list[Message],
        config: RunConfig,
        *,
        instructions: str | None,
        with_tools: bool,
    ) -> Any:
        runner = self._resolve_runner()
        agent = self._build_agent(
            config=config,
            instructions=instructions,
            with_tools=with_tools,
        )
        return await runner.run(
            starting_agent=agent,
            input=self._build_input(messages),
            max_turns=config.max_iterations,
        )

    def _build_agent(
        self,
        *,
        config: RunConfig,
        instructions: str | None,
        with_tools: bool,
    ) -> Any:
        from agents import Agent

        return Agent(
            name="Kneo OpenAI Agent",
            instructions=instructions,
            model=self._build_model(),
            tools=self._build_tools(config) if with_tools else [],
            tool_use_behavior="run_llm_again",
        )

    def _build_model(self) -> Any:
        if self._client is None:
            return self._model

        from agents.models.openai_chatcompletions import OpenAIChatCompletionsModel

        return OpenAIChatCompletionsModel(self._model, self._client)

    def _build_tools(self, config: RunConfig) -> list[Any]:
        from agents.tool import FunctionTool

        handlers: dict[str, Any] = config.extra.get("tool_handlers", {})
        tools = []
        for tool in config.tools:
            tools.append(
                FunctionTool(
                    name=tool.name,
                    description=tool.description,
                    params_json_schema=tool.parameters,
                    on_invoke_tool=self._make_tool_invoker(tool.name, handlers),
                )
            )
        return tools

    @staticmethod
    def _make_tool_invoker(name: str, handlers: dict[str, Any]) -> Any:
        async def invoke(_ctx: Any, raw_args: str) -> Any:
            handler = handlers.get(name)
            if handler is None:
                logger.warning("No handler for tool '%s'; returning error result.", name)
                return json.dumps({"error": f'No handler registered for tool "{name}".'})

            args = json.loads(raw_args) if raw_args else {}
            result = handler(args)
            if inspect.isawaitable(result):
                result = await result
            return result if isinstance(result, str) else json.dumps(result)

        return invoke

    @staticmethod
    def _build_input(messages: list[Message]) -> str:
        lines: list[str] = []
        for message in messages:
            if message.role == "user":
                lines.append(f"User: {message.content}")
            elif message.role == "assistant":
                lines.append(f"Assistant: {message.content}")
            elif message.role == "tool":
                tool_name = message.name or "tool"
                lines.append(f"Tool {tool_name} ({message.tool_call_id or 'unknown'}): {message.content}")
            elif message.role == "system":
                lines.append(f"System: {message.content}")
        return "\n\n".join(lines)

    def _result_from_sdk(
        self,
        messages: list[Message],
        sdk_result: Any,
        *,
        duration_ms: float,
        metadata: dict[str, Any] | None = None,
    ) -> RunResult:
        final_text = self._extract_final_text(sdk_result)
        return RunResult(
            final_message=final_text,
            messages=[*messages, Message(role="assistant", content=final_text)],
            iterations=len(getattr(sdk_result, "raw_responses", []) or []) or 1,
            tool_calls_performed=self._extract_tool_results(getattr(sdk_result, "new_items", []) or []),
            duration_ms=duration_ms,
            metadata=metadata or {},
        )

    def _extract_final_text(self, sdk_result: Any) -> str:
        final_output = getattr(sdk_result, "final_output", None)
        if isinstance(final_output, str):
            return final_output

        try:
            from agents.items import ItemHelpers

            text = ItemHelpers.text_message_outputs(getattr(sdk_result, "new_items", []) or [])
            if text:
                return text
        except ImportError:
            pass

        if final_output is None:
            return ""
        return str(final_output)

    def _extract_tool_results(self, items: list[Any]) -> list[ToolResult]:
        call_names: dict[str, str] = {}
        results: list[ToolResult] = []
        for item in items:
            item_type = self._value(item, "type")
            if item_type == "tool_call_item":
                tool_call = self._tool_call_from_item(item)
                if tool_call is not None:
                    call_names[tool_call.id] = tool_call.name
            elif item_type == "tool_call_output_item":
                tool_result = self._tool_result_from_item(item, call_names)
                if tool_result is not None:
                    results.append(tool_result)
        return results

    def _tool_call_from_item(self, item: Any) -> ToolCall | None:
        raw_item = self._value(item, "raw_item")
        if raw_item is None:
            return None

        raw_args = self._value(raw_item, "arguments")
        arguments: dict[str, Any]
        if isinstance(raw_args, str):
            arguments = json.loads(raw_args) if raw_args else {}
        elif isinstance(raw_args, dict):
            arguments = raw_args
        else:
            arguments = {}

        call_id = self._value(raw_item, "call_id") or self._value(raw_item, "id") or "unknown"
        name = self._value(raw_item, "name") or "unknown"
        return ToolCall(id=call_id, name=name, arguments=arguments)

    def _tool_result_from_item(
        self,
        item: Any,
        call_names: dict[str, str],
    ) -> ToolResult | None:
        raw_item = self._value(item, "raw_item")
        if raw_item is None:
            return None

        call_id = self._value(raw_item, "call_id") or self._value(raw_item, "id") or "unknown"
        name = call_names.get(call_id, self._value(raw_item, "name") or "unknown")
        output = self._value(item, "output")
        if output is None:
            output = self._value(raw_item, "output")
        if not isinstance(output, str):
            output = json.dumps(output)
        return ToolResult(tool_call_id=call_id, name=name, result=output)

    @staticmethod
    def _extract_raw_text_delta(data: Any) -> str | None:
        event_type = OpenAIAgentsImpl._value(data, "type")
        if event_type in {"response.output_text.delta", "output_text.delta"}:
            delta = OpenAIAgentsImpl._value(data, "delta")
            if isinstance(delta, str):
                return delta
        return None

    @staticmethod
    def _value(obj: Any, name: str) -> Any:
        if isinstance(obj, dict):
            return obj.get(name)
        return getattr(obj, name, None)

    def _resolve_runner(self) -> Any:
        if self._runner is not None:
            return self._runner

        from agents import Runner

        return Runner
