"""
kneo_agent.providers.openai_agents
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
OpenAI Agents SDK-backed native runtime.
"""

from .impl import OpenAIAgentsImpl

__all__ = ["OpenAIAgentsImpl"]
