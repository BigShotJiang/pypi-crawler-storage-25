"""
Kneo Agent
~~~~~~~~~~
A production-grade, framework-agnostic Python Agent SDK.

Kneo Agent lets you build AI agents that run on any LLM platform
(Google ADK, OpenAI Agents SDK, LangChain) using two well-known
structural design patterns:

Bridge pattern
    Decouples the agentic *loop strategy* (ReAct, Plan-Act, Simple)
    from the *platform implementation* (Google ADK, OpenAI, LangChain).
    Both sides vary independently; adding a new strategy or a new
    platform requires touching only one class.

Adapter pattern
    Wraps an *existing* platform object (a running LangChain
    ``AgentExecutor``, an OpenAI Agents SDK ``Runner``, …) and exposes
    the ``AgentRuntime`` interface that ``Agent`` expects.

Native runtime
    Hands loop ownership to the platform SDK/runtime itself while still
    exposing the ``AgentRuntime`` interface.

Quick start::

    import asyncio
    from kneo_agent import Agent, AgentBuilder, RunConfig, ToolDefinition
    from kneo_agent.patterns import NativeRuntimeFactory

    runtime = NativeRuntimeFactory.for_openai(model="gpt-4o", strategy="react")

    agent = (
        AgentBuilder()
        .with_name("My Assistant")
        .with_system_prompt("You are a helpful assistant.")
        .use_bridge(runtime)
        .build()
    )

    async def main():
        reply = await agent.chat("What is 2 + 2?")
        print(reply)

    asyncio.run(main())
"""

from .core import (
    Agent,
    AgentBuilder,
    AgentConfig,
    AgentMiddleware,
    AgentTool,
    AgentRunContext,
    BaseAgentMiddleware,
    AgentRuntime,
    ConfigurationError,
    HumanInterventionRequiredError,
    KneoAgentError,
    MaxIterationsReachedError,
    Message,
    ModelCallContext,
    ModelResponse,
    ProviderError,
    Role,
    RunConfig,
    RunResult,
    SKILL_STANDARD_URL,
    Skill,
    SkillCatalogEntry,
    StreamContext,
    RuntimeNotConfiguredError,
    StreamChunk,
    StreamingNotSupportedError,
    ToolCall,
    ToolDefinition,
    ToolCallContext,
    ToolNotFoundError,
    ToolResult,
    discover_default_skills,
    discover_skills,
    load_skill,
)
from .patterns import AdapterAgentFactory, BridgeAgentFactory, BridgeStrategy, NativeRuntimeFactory
from .providers import GoogleADKImpl, LangChainImpl, OpenAIAgentsImpl
from .mcp import MCPClientSession, MCPServerConfig, MCPTool
from .runtime import (
    AgentExecutor,
    GoogleADKAdapter,
    GoogleADKRuntime,
    LangChainAdapter,
    OpenAIAgentsAdapter,
    OpenAIAgentsRuntime,
    PlanActAgentExecutor,
    ReActAgentExecutor,
    RuntimeImpl,
    SimpleAgentExecutor,
)
from .utils import ToolRegistry, configure_logging, get_logger
from .workflows import (
    ConcurrentBuilder,
    ConcurrentWorkflow,
    FunctionExecutor,
    FunctionStep,
    GroupChatBuilder,
    GroupChatWorkflow,
    HandoffBuilder,
    HandoffWorkflow,
    SequentialBuilder,
    SequentialWorkflow,
    Workflow,
    WorkflowBuilder,
    WorkflowComponent,
    WorkflowEdge,
)

__version__ = "1.0.1"
__author__ = "Kneo Agent Contributors"
__license__ = "MIT"

__all__ = [
    # Version
    "__version__",
    # Core — Agent
    "Agent",
    "AgentTool",
    "AgentBuilder",
    "AgentConfig",
    "AgentMiddleware",
    "AgentRunContext",
    "BaseAgentMiddleware",
    "SKILL_STANDARD_URL",
    "ModelCallContext",
    "ModelResponse",
    "Skill",
    "SkillCatalogEntry",
    "StreamContext",
    # Core — Types
    "AgentRuntime",
    "Message",
    "Role",
    "RunConfig",
    "RunResult",
    "StreamChunk",
    "ToolCall",
    "ToolCallContext",
    "ToolDefinition",
    "ToolResult",
    "discover_default_skills",
    "discover_skills",
    "load_skill",
    "MCPClientSession",
    "MCPServerConfig",
    "MCPTool",
    # Core — Exceptions
    "KneoAgentError",
    "ConfigurationError",
    "HumanInterventionRequiredError",
    "MaxIterationsReachedError",
    "ProviderError",
    "RuntimeNotConfiguredError",
    "StreamingNotSupportedError",
    "ToolNotFoundError",
    # Patterns
    "AdapterAgentFactory",
    "BridgeAgentFactory",
    "BridgeStrategy",
    "NativeRuntimeFactory",
    # Providers (Bridge Implementors)
    "GoogleADKImpl",
    "LangChainImpl",
    "OpenAIAgentsImpl",
    # Runtime — Native
    "GoogleADKRuntime",
    "OpenAIAgentsRuntime",
    # Runtime — Bridge executors
    "AgentExecutor",
    "PlanActAgentExecutor",
    "ReActAgentExecutor",
    "RuntimeImpl",
    "SimpleAgentExecutor",
    # Runtime — Adapters
    "GoogleADKAdapter",
    "LangChainAdapter",
    "OpenAIAgentsAdapter",
    # Workflows
    "FunctionStep",
    "FunctionExecutor",
    "Workflow",
    "SequentialWorkflow",
    "SequentialBuilder",
    "ConcurrentWorkflow",
    "ConcurrentBuilder",
    "HandoffWorkflow",
    "HandoffBuilder",
    "GroupChatWorkflow",
    "GroupChatBuilder",
    "WorkflowBuilder",
    "WorkflowComponent",
    "WorkflowEdge",
    # Utils
    "ToolRegistry",
    "configure_logging",
    "get_logger",
]
