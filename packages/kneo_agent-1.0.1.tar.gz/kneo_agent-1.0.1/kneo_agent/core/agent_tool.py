"""
kneo_agent.core.agent_tool
~~~~~~~~~~~~~~~~~~~~~~~~~~
First-class tool wrapper for exposing an Agent as a tool.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Awaitable, Callable

from .types import ToolDefinition

ToolHandler = Callable[[dict[str, Any]], Any | Awaitable[Any]]


@dataclass(frozen=True)
class AgentTool:
    """A ToolDefinition paired with a callable that delegates to an Agent."""

    definition: ToolDefinition
    handler: ToolHandler
    agent_name: str

    @property
    def name(self) -> str:
        return self.definition.name

    @property
    def description(self) -> str:
        return self.definition.description

    @property
    def parameters(self) -> dict[str, Any]:
        return self.definition.parameters

    def __call__(self, args: dict[str, Any]) -> Any | Awaitable[Any]:
        return self.handler(args)
