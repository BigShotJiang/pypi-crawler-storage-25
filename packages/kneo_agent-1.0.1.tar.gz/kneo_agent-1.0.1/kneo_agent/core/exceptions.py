"""
kneo_agent.core.exceptions
~~~~~~~~~~~~~~~~~~~~~~~~~~
Kneo Agent exception hierarchy.

All public exceptions inherit from ``KneoAgentError`` so callers can
catch the entire family with a single except clause.
"""

from __future__ import annotations

from typing import Any


class KneoAgentError(Exception):
    """Base class for all Kneo Agent errors."""


class ConfigurationError(KneoAgentError):
    """Raised when an Agent or runtime is misconfigured."""


class RuntimeNotConfiguredError(ConfigurationError):
    """Raised when ``AgentBuilder.build()`` is called without a runtime."""


class StreamingNotSupportedError(KneoAgentError):
    """Raised when streaming is requested on a runtime that does not support it."""


class ToolNotFoundError(KneoAgentError):
    """Raised when a model requests a tool that has no registered handler."""

    def __init__(self, tool_name: str) -> None:
        self.tool_name = tool_name
        super().__init__(f'No handler registered for tool "{tool_name}".')


class MaxIterationsReachedError(KneoAgentError):
    """Raised (optionally) when the agent loop hits max_iterations."""


class HumanInterventionRequiredError(KneoAgentError):
    """Raised when a workflow pauses for explicit human input."""

    def __init__(
        self,
        step_name: str,
        prompt: str,
        request: dict[str, Any] | None = None,
    ) -> None:
        self.step_name = step_name
        self.prompt = prompt
        self.request = dict(request or {})
        super().__init__(f'Human input required for workflow step "{step_name}".')


class ProviderError(KneoAgentError):
    """Wraps errors surfaced by an underlying LLM provider."""

    def __init__(self, provider: str, message: str, cause: Exception | None = None) -> None:
        self.provider = provider
        self.cause = cause
        super().__init__(f"[{provider}] {message}")
