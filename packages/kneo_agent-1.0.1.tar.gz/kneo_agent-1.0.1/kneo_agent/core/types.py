"""
kneo_agent.core.types
~~~~~~~~~~~~~~~~~~~~~
Canonical dataclasses, type aliases, and runtime-checkable Protocols
that every other sub-package depends on.  Nothing in this module may
import from any other kneo_agent sub-package to avoid circular imports.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, AsyncGenerator, Literal, Protocol, runtime_checkable

# ---------------------------------------------------------------------------
# Primitive aliases
# ---------------------------------------------------------------------------

Role = Literal["user", "assistant", "system", "tool"]
"""Valid values for Message.role."""


# ---------------------------------------------------------------------------
# Value objects (immutable-ish dataclasses)
# ---------------------------------------------------------------------------

@dataclass
class Message:
    """A single turn in an agent conversation."""
    role: Role
    content: str
    name: str | None = None           # populated for tool-result messages
    tool_call_id: str | None = None   # links a tool result to its call
    tool_calls: list["ToolCall"] = field(default_factory=list)
    """Assistant tool calls that must be replayed before tool results."""


@dataclass
class ToolDefinition:
    """
    Declares a tool the agent may call.
    ``parameters`` must be a valid JSON Schema object.
    """
    name: str
    description: str
    parameters: dict[str, Any]


@dataclass
class ToolCall:
    """A tool invocation requested by the model."""
    id: str
    name: str
    arguments: dict[str, Any]


@dataclass
class ToolResult:
    """The result of executing a ToolCall."""
    tool_call_id: str
    name: str
    result: str


# ---------------------------------------------------------------------------
# Run configuration
# ---------------------------------------------------------------------------

@dataclass
class RunConfig:
    """
    Per-run configuration passed through every layer of the stack.

    Defaults are intentionally conservative.  Callers override only the
    fields they care about; the rest cascade from AgentConfig defaults.
    """
    max_iterations: int = 10
    temperature: float = 0.7
    system_prompt: str | None = None
    tools: list[ToolDefinition] = field(default_factory=list)
    middlewares: list[Any] = field(default_factory=list)
    extra: dict[str, Any] = field(default_factory=dict)
    """Provider-specific key/value pairs forwarded verbatim."""


# ---------------------------------------------------------------------------
# Run output
# ---------------------------------------------------------------------------

@dataclass
class RunResult:
    """Everything produced by a completed agent run."""
    final_message: str
    messages: list[Message]
    iterations: int
    tool_calls_performed: list[ToolResult]
    duration_ms: float
    metadata: dict[str, Any] = field(default_factory=dict)


# ---------------------------------------------------------------------------
# Streaming
# ---------------------------------------------------------------------------

@dataclass
class StreamChunk:
    """
    A single unit emitted by a streaming agent run.

    Consumers should check ``chunk.type`` before accessing optional fields.
    """
    type: Literal["text", "tool_call", "tool_result", "done"]
    content: str | None = None
    tool_call: ToolCall | None = None
    tool_result: ToolResult | None = None


# ---------------------------------------------------------------------------
# Core protocol — every runtime must satisfy this
# ---------------------------------------------------------------------------

@runtime_checkable
class AgentRuntime(Protocol):
    """
    The single interface that both Bridge executors and Adapter wrappers
    must satisfy.  The ``Agent`` class depends *only* on this protocol —
    it never imports a concrete runtime directly.
    """

    @property
    def name(self) -> str:
        """Human-readable identifier, e.g. ``"react@openai-agents"``."""
        ...

    async def run(
        self,
        messages: list[Message],
        config: RunConfig,
    ) -> RunResult:
        """Execute a full (possibly multi-turn) agent run."""
        ...

    async def stream(
        self,
        messages: list[Message],
        config: RunConfig,
    ) -> AsyncGenerator[StreamChunk, None]:
        """Stream chunks from an agent run."""
        ...

    def supports_streaming(self) -> bool: ...
    def supports_tools(self) -> bool: ...
