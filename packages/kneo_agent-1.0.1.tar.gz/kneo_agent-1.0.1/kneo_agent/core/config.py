"""
kneo_agent.core.config
~~~~~~~~~~~~~~~~~~~~~~
``AgentConfig`` holds static agent metadata; ``AgentBuilder`` provides a
fluent API for constructing ``Agent`` instances.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any

from .exceptions import RuntimeNotConfiguredError
from .middleware import AgentMiddleware
from .skills import Skill
from .types import AgentRuntime, RunConfig, ToolDefinition

if TYPE_CHECKING:
    from .agent import Agent
    from ..utils.tools import ToolRegistry


@dataclass
class AgentConfig:
    """
    Static configuration for an Agent.

    This is separated from ``RunConfig`` deliberately: AgentConfig describes
    *what the agent is*, RunConfig describes *how a particular run behaves*.
    """
    name: str
    description: str = ""
    version: str = "1.0.1"
    system_prompt: str | None = None
    tools: list[ToolDefinition] = field(default_factory=list)
    skills: list[Skill] = field(default_factory=list)
    middlewares: list[AgentMiddleware] = field(default_factory=list)
    default_run_config: dict[str, Any] = field(default_factory=dict)
    tags: list[str] = field(default_factory=list)
    """Arbitrary labels for grouping/filtering agents in a registry."""


class AgentBuilder:
    """
    Fluent builder for ``Agent`` instances.

    Usage::

        agent = (
            AgentBuilder()
            .with_name("Research Agent")
            .with_system_prompt("You are a helpful research assistant.")
            .with_tools([search_tool])
            .use_bridge(BridgeAgentFactory.for_openai(client, strategy="react"))
            .build()
        )
    """

    def __init__(self) -> None:
        self._name: str = "unnamed-agent"
        self._description: str = ""
        self._version: str = "1.0.1"
        self._system_prompt: str | None = None
        self._tools: list[ToolDefinition] = []
        self._skills: list[Skill] = []
        self._middlewares: list[AgentMiddleware] = []
        self._default_run_config: dict[str, Any] = {}
        self._tags: list[str] = []
        self._runtime: AgentRuntime | None = None

    # ── Identity ──────────────────────────────────────────────

    def with_name(self, name: str) -> "AgentBuilder":
        self._name = name
        return self

    def with_description(self, description: str) -> "AgentBuilder":
        self._description = description
        return self

    def with_version(self, version: str) -> "AgentBuilder":
        self._version = version
        return self

    def with_tags(self, *tags: str) -> "AgentBuilder":
        self._tags = list(tags)
        return self

    # ── Behaviour ─────────────────────────────────────────────

    def with_system_prompt(self, prompt: str) -> "AgentBuilder":
        self._system_prompt = prompt
        return self

    def with_tools(self, tools: list[ToolDefinition]) -> "AgentBuilder":
        self._tools = list(tools)
        return self

    def with_tool_registry(
        self,
        registry: "ToolRegistry",
        *,
        skill_name: str = "tool-registry",
        description: str = "Tool handlers supplied by a ToolRegistry.",
    ) -> "AgentBuilder":
        """
        Attach all registry tools plus their handlers through an implicit skill.

        This is especially useful for dynamic tool sources such as MCP servers:
        the builder can keep its existing synchronous API while the registry
        carries the handler callables via ``Skill.extra.tool_handlers``.
        """
        self._tools = list(registry.definitions)
        self._skills.append(
            registry.to_skill(
                skill_name,
                description=description,
            )
        )
        return self

    def add_tool(self, tool: ToolDefinition) -> "AgentBuilder":
        self._tools.append(tool)
        return self

    def with_skills(self, skills: list[Skill]) -> "AgentBuilder":
        self._skills = list(skills)
        return self

    def add_skill(self, skill: Skill) -> "AgentBuilder":
        self._skills.append(skill)
        return self

    def with_middlewares(self, middlewares: list[AgentMiddleware]) -> "AgentBuilder":
        self._middlewares = list(middlewares)
        return self

    def add_middleware(self, middleware: AgentMiddleware) -> "AgentBuilder":
        self._middlewares.append(middleware)
        return self

    def with_defaults(self, **kwargs: Any) -> "AgentBuilder":
        """Override default RunConfig fields by name."""
        self._default_run_config.update(kwargs)
        return self

    # ── Runtime wiring ────────────────────────────────────────

    def use_bridge(self, runtime: AgentRuntime) -> "AgentBuilder":
        """Attach a Bridge-pattern runtime (AgentExecutor subclass)."""
        self._runtime = runtime
        return self

    def use_adapter(self, runtime: AgentRuntime) -> "AgentBuilder":
        """Attach an Adapter-pattern runtime."""
        self._runtime = runtime
        return self

    def use_runtime(self, runtime: AgentRuntime) -> "AgentBuilder":
        """Attach any AgentRuntime directly."""
        self._runtime = runtime
        return self

    # ── Build ─────────────────────────────────────────────────

    def build(self) -> "Agent":
        from .agent import Agent  # local import avoids circularity

        if self._runtime is None:
            raise RuntimeNotConfiguredError(
                "No runtime configured. Call use_bridge(), use_adapter(), "
                "or use_runtime() before build()."
            )

        config = AgentConfig(
            name=self._name,
            description=self._description,
            version=self._version,
            system_prompt=self._system_prompt,
            tools=self._tools,
            skills=self._skills,
            middlewares=self._middlewares,
            default_run_config=self._default_run_config,
            tags=self._tags,
        )
        return Agent(config, self._runtime)
