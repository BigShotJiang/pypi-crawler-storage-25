"""
kneo_agent.core.agent
~~~~~~~~~~~~~~~~~~~~~
The framework-agnostic ``Agent`` class.

``Agent`` is the only object most application code needs to import.
It holds conversation history, exposes ``run`` / ``stream`` / ``chat``
and delegates all LLM work to an injected ``AgentRuntime``.
"""

from __future__ import annotations

import json
import logging
from typing import Any, AsyncGenerator

from .agent_tool import AgentTool
from .config import AgentConfig
from .exceptions import StreamingNotSupportedError
from .middleware import AgentRunContext, StreamContext, dispatch_run_middleware, dispatch_stream_middleware
from .skills import Skill, build_run_config
from .types import AgentRuntime, Message, RunConfig, RunResult, StreamChunk, ToolDefinition

logger = logging.getLogger(__name__)


class Agent:
    """
    A stateful, framework-agnostic conversational agent.

    The ``Agent`` knows nothing about Google ADK, OpenAI Agents SDK, or
    LangChain.  All platform knowledge lives in the injected runtime,
    which may be a Bridge executor or an Adapter wrapper — the Agent
    cannot tell the difference and does not need to.

    Attributes
    ----------
    config:
        Static metadata (name, description, system prompt, tools …).
    runtime_name:
        The ``name`` property of the injected ``AgentRuntime``.
    history:
        A snapshot of the current conversation as an immutable list.
    """

    def __init__(self, config: AgentConfig, runtime: AgentRuntime) -> None:
        self._config = config
        self._runtime = runtime
        self._history: list[Message] = []
        logger.debug(
            "Agent '%s' created with runtime '%s'.",
            config.name,
            runtime.name,
        )

    # ── Properties ────────────────────────────────────────────

    @property
    def config(self) -> AgentConfig:
        return self._config

    @property
    def agent_name(self) -> str:
        """Convenience alias for ``config.name``."""
        return self._config.name

    @property
    def runtime_name(self) -> str:
        return self._runtime.name

    @property
    def history(self) -> list[Message]:
        """Return a shallow copy so callers cannot mutate internal state."""
        return list(self._history)

    # ── Single-turn run ───────────────────────────────────────

    async def run(
        self,
        user_message: str,
        *,
        run_config: RunConfig | None = None,
        skills: list[Skill] | None = None,
        **extra: Any,
    ) -> RunResult:
        """
        Send ``user_message`` to the agent and return a full ``RunResult``.

        Parameters
        ----------
        user_message:
            The text to send as a user turn.
        run_config:
            Optional per-call overrides.  Merged on top of the agent's
            ``default_run_config``.
        **extra:
            Convenience shortcuts forwarded into ``RunConfig.extra``.
        """
        config = self._build_run_config(run_config, extra, skills)
        messages = [*self._history, Message(role="user", content=user_message)]
        context = AgentRunContext(
            agent_name=self._config.name,
            runtime_name=self._runtime.name,
            user_message=user_message,
            messages=messages,
            run_config=config,
        )
        logger.debug(
            "Agent '%s' running via '%s'.", self._config.name, self._runtime.name
        )
        result = await dispatch_run_middleware(
            config.middlewares,
            context,
            lambda ctx: self._runtime.run(ctx.messages, ctx.run_config),
        )
        if result.messages:
            self._history = list(result.messages)
        else:
            self._history = [*context.messages, Message(role="assistant", content=result.final_message)]
        logger.debug(
            "Agent '%s' completed in %.1f ms (%d iteration(s)).",
            self._config.name,
            result.duration_ms,
            result.iterations,
        )
        return result

    # ── Streaming run ─────────────────────────────────────────

    async def stream(
        self,
        user_message: str,
        *,
        run_config: RunConfig | None = None,
        skills: list[Skill] | None = None,
        **extra: Any,
    ) -> AsyncGenerator[StreamChunk, None]:
        """
        Stream chunks from the agent.

        Raises ``StreamingNotSupportedError`` if the runtime does not
        support streaming.  Otherwise yields ``StreamChunk`` objects until
        a chunk with ``type == "done"`` is emitted.
        """
        if not self._runtime.supports_streaming():
            raise StreamingNotSupportedError(
                f'Runtime "{self._runtime.name}" does not support streaming.'
            )
        config = self._build_run_config(run_config, extra, skills)
        messages = [*self._history, Message(role="user", content=user_message)]
        context = StreamContext(
            agent_name=self._config.name,
            runtime_name=self._runtime.name,
            user_message=user_message,
            messages=messages,
            run_config=config,
        )

        async def _terminal_stream(ctx: StreamContext) -> AsyncGenerator[StreamChunk, None]:
            async def _stream() -> AsyncGenerator[StreamChunk, None]:
                assistant_parts: list[str] = []
                async for chunk in self._runtime.stream(ctx.messages, ctx.run_config):
                    if chunk.type == "text" and chunk.content:
                        assistant_parts.append(chunk.content)
                    yield chunk
                self._history = [
                    *ctx.messages,
                    Message(role="assistant", content="".join(assistant_parts)),
                ]

            return _stream()

        return await dispatch_stream_middleware(
            config.middlewares,
            context,
            _terminal_stream,
        )

    # ── Multi-turn convenience ────────────────────────────────

    async def chat(self, user_message: str, **kwargs: Any) -> str:
        """
        Like ``run()``, but returns only the final text string.

        A convenience wrapper for simple chat-style interactions where
        the full ``RunResult`` is not needed.
        """
        result = await self.run(user_message, **kwargs)
        return result.final_message

    # ── History management ────────────────────────────────────

    def clear_history(self) -> None:
        """Reset the conversation to a clean slate."""
        self._history.clear()

    def inject_history(self, messages: list[Message]) -> None:
        """Seed the conversation with pre-existing messages (e.g. from a DB)."""
        self._history = list(messages)

    # ── Tool helpers ──────────────────────────────────────────

    def add_tool(self, tool: ToolDefinition) -> None:
        """Dynamically register a tool after construction."""
        self._config.tools.append(tool)

    def as_tool(
        self,
        *,
        name: str | None = None,
        description: str | None = None,
        parameters: dict[str, Any] | None = None,
        arg_name: str = "input",
        run_config: RunConfig | None = None,
        skills: list[Skill] | None = None,
        include_history: bool = False,
    ) -> AgentTool:
        """
        Expose this agent as a first-class tool without mutating its history.

        By default the generated tool accepts a single string argument named
        ``input`` and runs the agent against an isolated message list. Set
        ``include_history=True`` to seed the tool invocation with the agent's
        current conversation history.
        """
        tool_name = name or self._config.name.lower().replace(" ", "_")
        tool_description = description or self._config.description or (
            f"Delegate work to the {self._config.name} agent."
        )
        tool_parameters = parameters or {
            "type": "object",
            "properties": {
                arg_name: {
                    "type": "string",
                    "description": f"Input passed to the {self._config.name} agent.",
                }
            },
            "required": [arg_name],
        }

        async def handler(args: dict[str, Any]) -> str:
            payload = self._coerce_tool_payload(args, arg_name)
            config = self._build_run_config(run_config, {}, skills)
            messages = list(self._history) if include_history else []
            messages.append(Message(role="user", content=payload))
            result = await self._runtime.run(messages, config)
            return result.final_message

        return AgentTool(
            definition=ToolDefinition(
                name=tool_name,
                description=tool_description,
                parameters=tool_parameters,
            ),
            handler=handler,
            agent_name=self._config.name,
        )

    def add_skill(self, skill: Skill) -> None:
        """Dynamically register a skill after construction."""
        self._config.skills.append(skill)

    def disable_skill(self, name: str) -> None:
        """Remove a skill by name if present."""
        self._config.skills = [skill for skill in self._config.skills if skill.name != name]

    # ── Representation ────────────────────────────────────────

    def __repr__(self) -> str:  # pragma: no cover
        return (
            f"<Agent name={self._config.name!r} "
            f"runtime={self._runtime.name!r} "
            f"turns={len(self._history)}>"
        )

    # ── Private helpers ───────────────────────────────────────

    def _build_run_config(
        self,
        override: RunConfig | None,
        extra: dict[str, Any],
        skills: list[Skill] | None = None,
    ) -> RunConfig:
        """Resolve skills and merge agent defaults → per-call override → extra kwargs."""
        return build_run_config(
            agent_system_prompt=self._config.system_prompt,
            agent_tools=list(self._config.tools),
            agent_middlewares=list(self._config.middlewares),
            agent_defaults=self._config.default_run_config,
            agent_skills=list(self._config.skills) + list(skills or []),
            override=override,
            inline_extra=extra,
        )

    @staticmethod
    def _coerce_tool_payload(args: dict[str, Any], arg_name: str) -> str:
        if arg_name in args:
            payload = args[arg_name]
        elif "input" in args:
            payload = args["input"]
        elif len(args) == 1:
            payload = next(iter(args.values()))
        else:
            return json.dumps(args)
        return payload if isinstance(payload, str) else json.dumps(payload)
