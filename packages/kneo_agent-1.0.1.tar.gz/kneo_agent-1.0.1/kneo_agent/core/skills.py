"""
kneo_agent.core.skills
~~~~~~~~~~~~~~~~~~~~~~
Skill definitions and config resolution helpers.

Skills are capability bundles that compile down to the existing
``RunConfig`` contract so runtimes and providers remain unchanged.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
import re
from typing import Any

import yaml

from .exceptions import ConfigurationError
from .types import RunConfig, ToolDefinition

SKILL_STANDARD_URL = "https://agentskills.io/specification"
_SKILL_NAME_RE = re.compile(r"^[a-z0-9]+(?:-[a-z0-9]+)*$")
_DEFAULT_SKILL_DISCOVERY_DIRS = (".agents/skills", ".claude/skills")


@dataclass(frozen=True)
class SkillCatalogEntry:
    """Lightweight startup-time metadata for skill discovery."""

    name: str
    description: str
    path: str


@dataclass
class Skill:
    """
    Reusable capability bundle for an agent.

    A skill may contribute prompt instructions, tools, default run
    configuration, provider-specific extras, and tags.
    """

    name: str
    description: str = ""
    system_prompt: str | None = None
    tools: list[ToolDefinition] = field(default_factory=list)
    defaults: dict[str, Any] = field(default_factory=dict)
    extra: dict[str, Any] = field(default_factory=dict)
    tags: list[str] = field(default_factory=list)
    license: str | None = None
    compatibility: str | None = None
    metadata: dict[str, str] = field(default_factory=dict)
    allowed_tools: str | None = None
    source_path: str | None = None

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "Skill":
        """Construct a ``Skill`` from parsed Agent Skills frontmatter metadata."""
        name = data.get("name")
        if not isinstance(name, str) or not name.strip():
            raise ConfigurationError("Skill definition must contain a non-empty 'name'.")
        if len(name) > 64 or not _SKILL_NAME_RE.fullmatch(name):
            raise ConfigurationError(
                "Skill 'name' must match the Agent Skills format: lowercase letters, "
                "numbers, and single hyphens only, max 64 characters."
            )

        description = data.get("description")
        if not isinstance(description, str) or not description.strip():
            raise ConfigurationError(
                "Skill definition must contain a non-empty 'description'."
            )
        if len(description) > 1024:
            raise ConfigurationError("Skill 'description' must be 1024 characters or fewer.")

        tools_data = data.get("tools", [])
        if not isinstance(tools_data, list):
            raise ConfigurationError("'tools' must be a list in a skill definition.")

        tools: list[ToolDefinition] = []
        for raw_tool in tools_data:
            if not isinstance(raw_tool, dict):
                raise ConfigurationError("Each skill tool definition must be an object.")
            try:
                tools.append(
                    ToolDefinition(
                        name=raw_tool["name"],
                        description=raw_tool["description"],
                        parameters=raw_tool["parameters"],
                    )
                )
            except KeyError as exc:
                raise ConfigurationError(
                    f"Skill tool definition is missing required key {exc.args[0]!r}."
                ) from exc

        defaults = data.get("defaults", {})
        extra = data.get("extra", {})
        tags = data.get("tags", [])
        metadata = data.get("metadata", {})
        allowed_tools = data.get("allowed-tools")
        if not isinstance(defaults, dict):
            raise ConfigurationError("'defaults' must be an object in a skill definition.")
        if not isinstance(extra, dict):
            raise ConfigurationError("'extra' must be an object in a skill definition.")
        if not isinstance(tags, list):
            raise ConfigurationError("'tags' must be a list in a skill definition.")
        if not isinstance(metadata, dict):
            raise ConfigurationError("'metadata' must be an object in a skill definition.")
        if allowed_tools is not None and not isinstance(allowed_tools, str):
            raise ConfigurationError("'allowed-tools' must be a string in a skill definition.")

        return cls(
            name=name,
            description=description,
            system_prompt=data.get("system_prompt"),
            tools=tools,
            defaults=dict(defaults),
            extra=dict(extra),
            tags=[str(tag) for tag in tags],
            license=data.get("license"),
            compatibility=data.get("compatibility"),
            metadata={str(key): str(value) for key, value in metadata.items()},
            allowed_tools=allowed_tools,
        )

    @classmethod
    def from_markdown_file(cls, path: str | Path) -> "Skill":
        """Load an Agent Skills ``SKILL.md`` file."""
        skill_path = Path(path)
        try:
            text = skill_path.read_text(encoding="utf-8")
        except FileNotFoundError as exc:
            raise ConfigurationError(f"Skill file not found: {skill_path}") from exc

        frontmatter, body = _parse_skill_markdown(text, skill_path)
        skill = cls.from_dict(frontmatter)
        parent_name = skill_path.parent.name
        if parent_name and parent_name != skill.name:
            raise ConfigurationError(
                f"Skill name {skill.name!r} must match parent directory {parent_name!r}."
            )

        skill.system_prompt = body or None
        skill.source_path = str(skill_path)
        return skill

    @classmethod
    def from_path(cls, path: str | Path) -> "Skill":
        """Load a skill from either a skill directory or a ``SKILL.md`` file."""
        skill_path = Path(path)
        if skill_path.is_dir():
            skill_path = skill_path / "SKILL.md"
        return cls.from_markdown_file(skill_path)

    def with_extra(self, extra: dict[str, Any]) -> "Skill":
        """Return a copy of the skill with merged ``extra`` values."""
        return Skill(
            name=self.name,
            description=self.description,
            system_prompt=self.system_prompt,
            tools=list(self.tools),
            defaults=dict(self.defaults),
            extra=merge_run_extras(self.extra, extra),
            tags=list(self.tags),
            license=self.license,
            compatibility=self.compatibility,
            metadata=dict(self.metadata),
            allowed_tools=self.allowed_tools,
            source_path=self.source_path,
        )

    def with_tool_handlers(self, handlers: dict[str, Any]) -> "Skill":
        """Return a copy of the skill with ``tool_handlers`` merged into ``extra``."""
        return self.with_extra({"tool_handlers": handlers})

    @property
    def root_dir(self) -> Path | None:
        """Return the skill root directory when loaded from disk."""
        if self.source_path is None:
            return None
        return Path(self.source_path).parent

    def resource_paths(self) -> list[str]:
        """List bundled skill resources relative to the skill root."""
        root = self.root_dir
        if root is None:
            return []

        resources: list[str] = []
        for folder in ("references", "scripts", "assets"):
            directory = root / folder
            if not directory.is_dir():
                continue
            for child in sorted(p for p in directory.rglob("*") if p.is_file()):
                resources.append(child.relative_to(root).as_posix())
        return resources

    def read_resource(self, relative_path: str) -> str:
        """Read a bundled resource file by path relative to the skill root."""
        root = self.root_dir
        if root is None:
            raise ConfigurationError("This skill was not loaded from disk.")
        path = _resolve_skill_relative_path(root, relative_path)
        if not path.is_file():
            raise ConfigurationError(
                f"Skill resource {relative_path!r} was not found under {root}."
            )
        return path.read_text(encoding="utf-8")

    def activation_prompt(self) -> str:
        """
        Return a structured skill activation payload suitable for prompt injection.
        """
        body = self.system_prompt or ""
        lines = [f'<skill_content name="{self.name}">', body]
        if self.source_path:
            lines.append("")
            lines.append(f"Skill directory: {Path(self.source_path).parent}")
            lines.append("Relative paths in this skill are relative to the skill directory.")
        resources = self.resource_paths()
        if resources:
            lines.append("")
            lines.append("<skill_resources>")
            for resource in resources:
                lines.append(f"  <file>{resource}</file>")
            lines.append("</skill_resources>")
        lines.append("</skill_content>")
        return "\n".join(lines).strip()


def load_skill(path: str | Path) -> Skill:
    """Load one Agent Skills-compatible skill directory or ``SKILL.md`` file."""
    return Skill.from_path(path)


def discover_skills(
    roots: list[str | Path],
    *,
    max_depth: int = 4,
) -> list[SkillCatalogEntry]:
    """
    Discover Agent Skills directories under one or more roots.

    Only lightweight catalog metadata is loaded.
    """
    entries: dict[str, SkillCatalogEntry] = {}
    for root in roots:
        root_path = Path(root)
        if not root_path.exists():
            continue
        for skill_file in _iter_skill_files(root_path, max_depth=max_depth):
            skill = Skill.from_markdown_file(skill_file)
            entries[skill.name] = SkillCatalogEntry(
                name=skill.name,
                description=skill.description,
                path=str(skill_file.parent),
            )
    return list(entries.values())


def discover_default_skills(
    *,
    project_root: str | Path | None = None,
    user_home: str | Path | None = None,
    max_depth: int = 4,
) -> list[SkillCatalogEntry]:
    """
    Discover skills from conventional project and user locations.
    """
    roots: list[Path] = []
    if project_root is not None:
        project_path = Path(project_root)
        roots.extend(project_path / rel for rel in _DEFAULT_SKILL_DISCOVERY_DIRS)
    if user_home is not None:
        home_path = Path(user_home)
        roots.extend(home_path / rel for rel in _DEFAULT_SKILL_DISCOVERY_DIRS)
    return discover_skills(roots, max_depth=max_depth)


def _parse_skill_markdown(text: str, path: Path) -> tuple[dict[str, Any], str]:
    if not text.startswith("---\n"):
        raise ConfigurationError(
            f"Skill file {path} must start with YAML frontmatter delimited by '---'."
        )

    try:
        _, remainder = text.split("---\n", 1)
        frontmatter_text, body = remainder.split("\n---\n", 1)
    except ValueError as exc:
        raise ConfigurationError(
            f"Skill file {path} must contain closing YAML frontmatter delimiter '---'."
        ) from exc

    try:
        frontmatter = yaml.safe_load(frontmatter_text) or {}
    except yaml.YAMLError as exc:
        raise ConfigurationError(f"Invalid YAML in skill file {path}: {exc}") from exc

    if not isinstance(frontmatter, dict):
        raise ConfigurationError(
            f"YAML frontmatter in skill file {path} must be a mapping."
        )
    return frontmatter, body.strip()


def _iter_skill_files(root: Path, *, max_depth: int) -> list[Path]:
    files: list[Path] = []
    root_depth = len(root.parts)
    for path in root.rglob("SKILL.md"):
        if any(part in {".git", "node_modules", "__pycache__"} for part in path.parts):
            continue
        if len(path.parts) - root_depth > max_depth + 1:
            continue
        files.append(path)
    return sorted(files)


def _resolve_skill_relative_path(root: Path, relative_path: str) -> Path:
    path = (root / relative_path).resolve()
    root_resolved = root.resolve()
    try:
        path.relative_to(root_resolved)
    except ValueError as exc:
        raise ConfigurationError(
            f"Skill resource path {relative_path!r} escapes the skill directory."
        ) from exc
    return path


def merge_run_extras(*extras: dict[str, Any]) -> dict[str, Any]:
    """Deep-merge ``RunConfig.extra`` dictionaries."""
    merged: dict[str, Any] = {}
    for extra in extras:
        _merge_dict_into(merged, extra)
    return merged


def build_run_config(
    *,
    agent_system_prompt: str | None,
    agent_tools: list[ToolDefinition],
    agent_middlewares: list[Any],
    agent_defaults: dict[str, Any],
    agent_skills: list[Skill],
    override: RunConfig | None,
    inline_extra: dict[str, Any],
) -> RunConfig:
    """
    Resolve agent config, skills, and per-run overrides into ``RunConfig``.

    Merge order:
    1. Base ``RunConfig`` defaults
    2. Agent defaults
    3. Skill defaults and extras
    4. Per-run override
    5. Inline ``**extra`` convenience kwargs
    """
    system_prompt = _merge_system_prompt(
        agent_system_prompt,
        [skill.system_prompt for skill in agent_skills if skill.system_prompt],
    )
    tools = _merge_tools(agent_tools, *(skill.tools for skill in agent_skills))
    merged_defaults = dict(agent_defaults)
    merged_extra = merge_run_extras(*(skill.extra for skill in agent_skills))
    merged_tags = _merge_tags(*(skill.tags for skill in agent_skills))

    for skill in agent_skills:
        merged_defaults.update(skill.defaults)

    base = RunConfig(
        system_prompt=system_prompt,
        tools=tools,
        middlewares=list(agent_middlewares),
    )
    for key, value in merged_defaults.items():
        if hasattr(base, key):
            setattr(base, key, value)

    if merged_tags:
        merged_extra = merge_run_extras({"skill_tags": merged_tags}, merged_extra)

    base.extra = merged_extra

    if override:
        base.max_iterations = override.max_iterations
        base.temperature = override.temperature
        if override.system_prompt is not None:
            base.system_prompt = override.system_prompt
        base.tools = list(override.tools)
        base.middlewares = [*base.middlewares, *override.middlewares]
        base.extra = merge_run_extras(base.extra, override.extra)

    base.extra = merge_run_extras(base.extra, inline_extra)
    return base


def _merge_system_prompt(
    agent_prompt: str | None,
    skill_prompts: list[str],
) -> str | None:
    parts = [part.strip() for part in [agent_prompt, *skill_prompts] if part and part.strip()]
    return "\n\n".join(parts) if parts else None


def _merge_tools(
    base_tools: list[ToolDefinition],
    *tool_groups: list[ToolDefinition],
) -> list[ToolDefinition]:
    merged: list[ToolDefinition] = []
    seen: dict[str, ToolDefinition] = {}

    for tool in [*base_tools, *(tool for group in tool_groups for tool in group)]:
        existing = seen.get(tool.name)
        if existing is not None and existing != tool:
            raise ConfigurationError(
                f"Duplicate tool definition for {tool.name!r} while resolving skills."
            )
        if existing is None:
            seen[tool.name] = tool
            merged.append(tool)
    return merged


def _merge_tags(*tag_groups: list[str]) -> list[str]:
    merged: list[str] = []
    for group in tag_groups:
        for tag in group:
            if tag not in merged:
                merged.append(tag)
    return merged


def _merge_dict_into(target: dict[str, Any], incoming: dict[str, Any]) -> None:
    for key, value in incoming.items():
        if (
            key in target
            and isinstance(target[key], dict)
            and isinstance(value, dict)
        ):
            _merge_dict_into(target[key], value)
        else:
            target[key] = value
