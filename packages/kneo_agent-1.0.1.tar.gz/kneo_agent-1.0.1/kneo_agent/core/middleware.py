"""
kneo_agent.core.middleware
~~~~~~~~~~~~~~~~~~~~~~~~~~
Composable middleware for agent runs, model calls, tool execution, and streaming.

The middleware layer uses shared mutable context objects and stage-specific
hooks around the agent loop.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, AsyncGenerator, Awaitable, Callable, Protocol, Sequence

from .types import Message, RunConfig, RunResult, StreamChunk, ToolCall, ToolResult


@dataclass
class ModelResponse:
    """Normalized result for one model invocation inside an agent loop."""

    text: str
    tool_calls: list[ToolCall] = field(default_factory=list)


@dataclass
class AgentRunContext:
    """Context shared across a single agent run."""

    agent_name: str
    runtime_name: str
    user_message: str | None
    messages: list[Message]
    run_config: RunConfig
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class StreamContext:
    """Context shared across a single agent stream."""

    agent_name: str
    runtime_name: str
    user_message: str | None
    messages: list[Message]
    run_config: RunConfig
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class ModelCallContext:
    """Context for one model call within a bridge executor."""

    executor_name: str
    runtime_name: str
    iteration: int
    messages: list[Message]
    run_config: RunConfig
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class ToolCallContext:
    """Context for one tool execution within a bridge executor."""

    executor_name: str
    runtime_name: str
    iteration: int
    messages: list[Message]
    run_config: RunConfig
    tool_call: ToolCall
    metadata: dict[str, Any] = field(default_factory=dict)


AgentRunHandler = Callable[[AgentRunContext], Awaitable[RunResult]]
StreamHandler = Callable[[StreamContext], Awaitable[AsyncGenerator[StreamChunk, None]]]
ModelCallHandler = Callable[[ModelCallContext], Awaitable[ModelResponse]]
ToolCallHandler = Callable[[ToolCallContext], Awaitable[ToolResult]]


class AgentMiddleware(Protocol):
    """Stage-specific middleware hooks with safe pass-through defaults."""

    async def wrap_run(
        self,
        context: AgentRunContext,
        handler: AgentRunHandler,
    ) -> RunResult:
        ...

    async def wrap_stream(
        self,
        context: StreamContext,
        handler: StreamHandler,
    ) -> AsyncGenerator[StreamChunk, None]:
        ...

    async def wrap_model_call(
        self,
        context: ModelCallContext,
        handler: ModelCallHandler,
    ) -> ModelResponse:
        ...

    async def wrap_tool_call(
        self,
        context: ToolCallContext,
        handler: ToolCallHandler,
    ) -> ToolResult:
        ...


class BaseAgentMiddleware:
    """Convenience base class for implementing only the hooks you need."""

    async def wrap_run(
        self,
        context: AgentRunContext,
        handler: AgentRunHandler,
    ) -> RunResult:
        return await handler(context)

    async def wrap_stream(
        self,
        context: StreamContext,
        handler: StreamHandler,
    ) -> AsyncGenerator[StreamChunk, None]:
        return await handler(context)

    async def wrap_model_call(
        self,
        context: ModelCallContext,
        handler: ModelCallHandler,
    ) -> ModelResponse:
        return await handler(context)

    async def wrap_tool_call(
        self,
        context: ToolCallContext,
        handler: ToolCallHandler,
    ) -> ToolResult:
        return await handler(context)


async def dispatch_run_middleware(
    middlewares: Sequence[AgentMiddleware],
    context: AgentRunContext,
    terminal: AgentRunHandler,
) -> RunResult:
    async def _call(index: int, current: AgentRunContext) -> RunResult:
        if index >= len(middlewares):
            return await terminal(current)
        return await middlewares[index].wrap_run(
            current,
            lambda next_context: _call(index + 1, next_context),
        )

    return await _call(0, context)


async def dispatch_stream_middleware(
    middlewares: Sequence[AgentMiddleware],
    context: StreamContext,
    terminal: StreamHandler,
) -> AsyncGenerator[StreamChunk, None]:
    async def _call(index: int, current: StreamContext) -> AsyncGenerator[StreamChunk, None]:
        if index >= len(middlewares):
            return await terminal(current)
        return await middlewares[index].wrap_stream(
            current,
            lambda next_context: _call(index + 1, next_context),
        )

    return await _call(0, context)


async def dispatch_model_middleware(
    middlewares: Sequence[AgentMiddleware],
    context: ModelCallContext,
    terminal: ModelCallHandler,
) -> ModelResponse:
    async def _call(index: int, current: ModelCallContext) -> ModelResponse:
        if index >= len(middlewares):
            return await terminal(current)
        return await middlewares[index].wrap_model_call(
            current,
            lambda next_context: _call(index + 1, next_context),
        )

    return await _call(0, context)


async def dispatch_tool_middleware(
    middlewares: Sequence[AgentMiddleware],
    context: ToolCallContext,
    terminal: ToolCallHandler,
) -> ToolResult:
    async def _call(index: int, current: ToolCallContext) -> ToolResult:
        if index >= len(middlewares):
            return await terminal(current)
        return await middlewares[index].wrap_tool_call(
            current,
            lambda next_context: _call(index + 1, next_context),
        )

    return await _call(0, context)
