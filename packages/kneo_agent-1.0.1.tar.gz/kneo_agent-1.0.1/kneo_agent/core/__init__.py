"""
kneo_agent.core
~~~~~~~~~~~~~~~
Fundamental types, protocols, configuration, and the Agent class.

All other sub-packages import from here; nothing here imports from
sibling sub-packages.
"""

from .agent import Agent
from .agent_tool import AgentTool
from .config import AgentBuilder, AgentConfig
from .exceptions import (
    ConfigurationError,
    HumanInterventionRequiredError,
    KneoAgentError,
    MaxIterationsReachedError,
    ProviderError,
    RuntimeNotConfiguredError,
    StreamingNotSupportedError,
    ToolNotFoundError,
)
from .middleware import (
    AgentMiddleware,
    AgentRunContext,
    BaseAgentMiddleware,
    ModelCallContext,
    ModelResponse,
    StreamContext,
    ToolCallContext,
)
from .types import (
    AgentRuntime,
    Message,
    Role,
    RunConfig,
    RunResult,
    StreamChunk,
    ToolCall,
    ToolDefinition,
    ToolResult,
)
from .skills import (
    SKILL_STANDARD_URL,
    Skill,
    SkillCatalogEntry,
    discover_default_skills,
    discover_skills,
    load_skill,
)
from ..mcp import MCPClientSession, MCPServerConfig, MCPTool

__all__ = [
    # Agent
    "Agent",
    "AgentTool",
    "AgentBuilder",
    "AgentConfig",
    "AgentMiddleware",
    "AgentRunContext",
    "BaseAgentMiddleware",
    "SKILL_STANDARD_URL",
    "ModelCallContext",
    "ModelResponse",
    "Skill",
    "SkillCatalogEntry",
    "StreamContext",
    "ToolCallContext",
    "discover_default_skills",
    "discover_skills",
    "load_skill",
    "MCPClientSession",
    "MCPServerConfig",
    "MCPTool",
    # Types
    "AgentRuntime",
    "Message",
    "Role",
    "RunConfig",
    "RunResult",
    "StreamChunk",
    "ToolCall",
    "ToolDefinition",
    "ToolResult",
    # Exceptions
    "KneoAgentError",
    "ConfigurationError",
    "HumanInterventionRequiredError",
    "MaxIterationsReachedError",
    "ProviderError",
    "RuntimeNotConfiguredError",
    "StreamingNotSupportedError",
    "ToolNotFoundError",
]
