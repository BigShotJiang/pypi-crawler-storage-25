"""
kneo_agent.patterns.factory
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
High-level factory functions for constructing runtimes using either the
Bridge or Adapter pattern.

These factories are thin convenience wrappers; all real wiring happens in
``kneo_agent.runtime`` and ``kneo_agent.providers``.  Application code
that wants fine-grained control can bypass the factories entirely and
compose ``AgentExecutor`` + ``RuntimeImpl`` directly.
"""

from __future__ import annotations

import warnings
from typing import Any, Callable, Literal

from ..core.types import AgentRuntime
from ..providers.google_adk import GoogleADKImpl
from ..providers.langchain import LangChainImpl
from ..providers.openai_agents import OpenAIAgentsImpl
from ..runtime.adapters import GoogleADKAdapter, LangChainAdapter, OpenAIAgentsAdapter
from ..runtime.bridge import (
    AgentExecutor,
    PlanActAgentExecutor,
    ReActAgentExecutor,
    RuntimeImpl,
    SimpleAgentExecutor,
)
from ..runtime.native import GoogleADKRuntime, OpenAIAgentsRuntime

BridgeStrategy = Literal["simple", "react", "plan-act"]
"""
Loop strategy for Bridge-pattern runtimes.

``"simple"``
    One-shot completion — no tool calls, no loop.
``"react"``
    Reason → Act → Observe loop (default).
``"plan-act"``
    Generate an explicit plan first, then execute with tools.
"""


# ---------------------------------------------------------------------------
# Bridge factory
# ---------------------------------------------------------------------------

class BridgeAgentFactory:
    """
    Construct Bridge-pattern ``AgentRuntime`` instances.

    The *Bridge* pattern decouples the agentic loop strategy from the
    platform implementation.  You choose strategy and platform
    independently; they can be swapped without touching each other.

    Strategy × Platform combinations
    ---------------------------------
    ::

        3 strategies  ×  3 platforms  →  9 runtime variants
        from only 3 + 3 = 6 classes (not 9).

    Example::

        # ReAct on OpenAI — swap to "plan-act" with zero OpenAI changes
        runtime = BridgeAgentFactory.for_openai(client, strategy="react")

        # Same strategy, different platform — zero loop-code changes
        runtime = BridgeAgentFactory.for_langchain(model, strategy="react")
    """

    @staticmethod
    def for_google_adk(
        adk_runner: Any,
        session_id: str,
        strategy: BridgeStrategy = "react",
    ) -> AgentRuntime:
        """
        Parameters
        ----------
        adk_runner:
            A ``google.adk.runners.InMemoryRunner`` (or compatible) instance.
        session_id:
            ADK session identifier.
        strategy:
            Agentic loop strategy (default ``"react"``).

        Notes
        -----
        This is a compatibility bridge over an ADK-shaped request/response
        payload. It is not the ADK-native execution path. For real Google ADK
        loop ownership, prefer ``AdapterAgentFactory.for_google_adk(...)``.
        """
        warnings.warn(
            "BridgeAgentFactory.for_google_adk() uses a Kneo compatibility "
            "bridge over ADK-shaped payloads. For native Google ADK loop "
            "ownership, prefer AdapterAgentFactory.for_google_adk().",
            stacklevel=2,
        )
        impl = GoogleADKImpl(adk_runner, session_id)
        return BridgeAgentFactory._executor(strategy, impl)

    @staticmethod
    def for_openai(
        openai_client: Any | None = None,
        model: str = "gpt-4o",
        strategy: BridgeStrategy = "react",
        runner: Any | None = None,
    ) -> AgentRuntime:
        """
        Parameters
        ----------
        openai_client:
            Optional ``openai.AsyncOpenAI`` client used to build an OpenAI
            Agents SDK chat-completions model wrapper.
        model:
            Model identifier (default ``"gpt-4o"``).
        strategy:
            Agentic loop strategy (default ``"react"``).
        runner:
            Optional OpenAI Agents SDK runner override. Mainly useful for tests.
        """
        warnings.warn(
            "BridgeAgentFactory.for_openai() now returns a platform-owned "
            "OpenAI Agents SDK runtime. Prefer NativeRuntimeFactory.for_openai() "
            "to make that explicit.",
            stacklevel=2,
        )
        return NativeRuntimeFactory.for_openai(
            openai_client=openai_client,
            model=model,
            strategy=strategy,
            runner=runner,
        )

    @staticmethod
    def for_langchain(
        chat_model: Any,
        tool_registry: dict[str, Callable[[dict], Any]] | None = None,
        strategy: BridgeStrategy = "react",
    ) -> AgentRuntime:
        """
        Parameters
        ----------
        chat_model:
            Any ``langchain_core.language_models.BaseChatModel`` subclass.
        tool_registry:
            Optional mapping of tool name → callable.  Tools can also be
            registered after construction via ``LangChainImpl.register_tool``.
        strategy:
            Agentic loop strategy (default ``"react"``).
        """
        impl = LangChainImpl(chat_model, tool_registry)
        return BridgeAgentFactory._executor(strategy, impl)

    @staticmethod
    def custom(
        impl: RuntimeImpl,
        strategy: BridgeStrategy = "react",
    ) -> AgentRuntime:
        """
        Bridge a custom ``RuntimeImpl`` with any strategy.

        Use this to plug in a provider not natively supported by Kneo Agent.
        """
        return BridgeAgentFactory._executor(strategy, impl)

    # ── Internal ────────────────────────────────────────────────

    @staticmethod
    def _executor(strategy: BridgeStrategy, impl: RuntimeImpl) -> AgentExecutor:
        match strategy:
            case "simple":
                return SimpleAgentExecutor(impl)
            case "react":
                return ReActAgentExecutor(impl)
            case "plan-act":
                return PlanActAgentExecutor(impl)
            case _:
                raise ValueError(
                    f"Unknown strategy {strategy!r}. "
                    "Choose from 'simple', 'react', or 'plan-act'."
                )


# ---------------------------------------------------------------------------
# Adapter factory
# ---------------------------------------------------------------------------

class AdapterAgentFactory:
    """
    Construct Adapter-pattern ``AgentRuntime`` instances.

    The *Adapter* pattern wraps an *existing*, fixed-interface platform
    object and translates its API to what ``Agent`` expects.  The platform
    manages its own agentic loop; no strategy choice is possible or needed.

    Use the Adapter when
    ---------------------
    - You already have a running ``google.adk`` / ``@openai/agents`` /
      ``langchain`` ``AgentExecutor`` instance and want to drive it from
      Kneo Agent without changing how it works.
    - You are migrating an existing application incrementally.

    Example::

        executor = create_langchain_agent(...)   # existing LC executor
        runtime  = AdapterAgentFactory.for_langchain(executor)
        agent    = AgentBuilder().use_adapter(runtime).build()
    """

    @staticmethod
    def for_google_adk(
        adk_runner: Any,
        app_name: str,
        user_id: str,
        session_id: str,
    ) -> GoogleADKAdapter:
        """
        Wrap an existing Google ADK runner.

        Parameters
        ----------
        adk_runner:
            ADK runner with a ``run_async`` async-generator method.
        app_name:
            ADK application name.
        user_id:
            ADK user identifier.
        session_id:
            ADK session identifier.
        """
        return GoogleADKAdapter(adk_runner, app_name, user_id, session_id)

    @staticmethod
    def for_openai(
        runner: Any,
        agent_definition: dict[str, Any],
    ) -> OpenAIAgentsAdapter:
        """
        Wrap an existing OpenAI Agents SDK ``Runner``.

        Parameters
        ----------
        runner:
            An ``@openai/agents`` ``Runner`` with ``run`` / ``stream`` methods.
        agent_definition:
            Dict with at minimum ``{"name": ..., "instructions": ...}``.
        """
        return OpenAIAgentsAdapter(runner, agent_definition)

    @staticmethod
    def for_langchain(agent_executor: Any) -> LangChainAdapter:
        """
        Wrap an existing LangChain ``AgentExecutor``.

        Parameters
        ----------
        agent_executor:
            A LangChain ``AgentExecutor`` (or ``CompiledGraph``) with
            ``ainvoke`` and optionally ``astream``.
        """
        return LangChainAdapter(agent_executor)


class NativeRuntimeFactory:
    """
    Construct platform-owned runtimes.

    Native runtimes hand loop ownership to the platform itself. Unlike
    Bridge runtimes, these do not rely on ``AgentExecutor`` subclasses to
    drive the core execution loop.
    """

    @staticmethod
    def for_openai(
        openai_client: Any | None = None,
        model: str = "gpt-4o",
        strategy: BridgeStrategy = "react",
        runner: Any | None = None,
    ) -> OpenAIAgentsRuntime:
        return OpenAIAgentsRuntime(
            openai_client=openai_client,
            model=model,
            strategy=strategy,
            runner=runner,
        )

    @staticmethod
    def for_google_adk(
        adk_runner: Any,
        app_name: str,
        user_id: str,
        session_id: str,
    ) -> GoogleADKRuntime:
        return GoogleADKRuntime(adk_runner, app_name, user_id, session_id)
