"""
kneo_agent.patterns
~~~~~~~~~~~~~~~~~~~~
Design-pattern helpers: Bridge, Native, and Adapter runtime factories.
"""

from .factory import AdapterAgentFactory, BridgeAgentFactory, BridgeStrategy, NativeRuntimeFactory

__all__ = ["AdapterAgentFactory", "BridgeAgentFactory", "BridgeStrategy", "NativeRuntimeFactory"]
