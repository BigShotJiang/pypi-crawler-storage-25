"""
kneo_agent.runtime.bridge
~~~~~~~~~~~~~~~~~~~~~~~~~
Bridge pattern runtime sub-package.

Exports the Abstraction hierarchy (AgentExecutor and its subclasses)
and the RuntimeImpl protocol.  Concrete implementors live in
``kneo_agent.providers.*``.
"""

from .executor import AgentExecutor, PlanActAgentExecutor, ReActAgentExecutor, SimpleAgentExecutor
from .impl import RuntimeImpl

__all__ = [
    "AgentExecutor",
    "PlanActAgentExecutor",
    "ReActAgentExecutor",
    "RuntimeImpl",
    "SimpleAgentExecutor",
]
