"""
kneo_agent.runtime.bridge.executor
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Bridge Pattern — Abstraction side.

``AgentExecutor`` is the *Abstraction*. It owns the high-level agentic
loop logic (simple, ReAct, Plan-Act) while delegating every platform
call to the injected ``RuntimeImpl`` (the *Implementor*).

Hierarchy
---------
::

    AgentExecutor  (abstract — Abstraction)
    ├── SimpleAgentExecutor    one-shot completion
    ├── ReActAgentExecutor     Reason → Act → Observe loop
    └── PlanActAgentExecutor   Plan first, then execute

Each subclass is a *Refined Abstraction*.  Adding a new strategy (e.g.
``MonteCarloAgentExecutor``) requires only a new subclass here — the
three ``RuntimeImpl`` classes are untouched.
"""

from __future__ import annotations

import asyncio
import logging
import time
from abc import ABC, abstractmethod
from typing import AsyncGenerator

from ...core.exceptions import ToolNotFoundError
from ...core.middleware import (
    ModelCallContext,
    ModelResponse,
    ToolCallContext,
    dispatch_model_middleware,
    dispatch_tool_middleware,
)
from ...core.types import (
    AgentRuntime,
    Message,
    RunConfig,
    RunResult,
    StreamChunk,
    ToolCall,
    ToolResult,
)
from .impl import RuntimeImpl

logger = logging.getLogger(__name__)


class AgentExecutor(ABC):
    """
    Abstract Abstraction in the Bridge pattern.

    Subclasses define *how* the agent loop runs; ``RuntimeImpl`` defines
    *how* each platform call is made.  The two hierarchies vary independently.

    Also satisfies ``AgentRuntime`` so the ``Agent`` class can use it
    transparently alongside Adapter-pattern runtimes.
    """

    def __init__(self, impl: RuntimeImpl) -> None:
        self._impl = impl

    # ── AgentRuntime protocol ──────────────────────────────────

    @property
    def name(self) -> str:
        return f"{self._strategy_name}@{self._impl.platform_name}"

    @abstractmethod
    async def run(
        self, messages: list[Message], config: RunConfig
    ) -> RunResult:
        """Subclasses define the loop strategy here."""
        ...

    async def stream(
        self, messages: list[Message], config: RunConfig
    ) -> AsyncGenerator[StreamChunk, None]:
        """Default streaming: forward raw tokens from the impl."""
        if not self._impl.supports_streaming():
            raise NotImplementedError(
                f"{self._impl.platform_name} does not support streaming."
            )
        async for token in self._impl.stream_tokens(messages, config):
            yield StreamChunk(type="text", content=token)
        yield StreamChunk(type="done")

    def supports_streaming(self) -> bool:
        return self._impl.supports_streaming()

    def supports_tools(self) -> bool:
        return self._impl.supports_tools()

    # ── Shared helpers ─────────────────────────────────────────

    @property
    @abstractmethod
    def _strategy_name(self) -> str:
        """Short label used in ``name`` (e.g. ``"react"``)."""
        ...

    async def _call_tool(
        self,
        call: ToolCall,
        config: RunConfig,
        *,
        messages: list[Message],
        iteration: int,
    ) -> ToolResult:
        """Execute one tool call and return a ``ToolResult``."""
        logger.debug("Executing tool '%s' (id=%s).", call.name, call.id)
        context = ToolCallContext(
            executor_name=self.name,
            runtime_name=self._impl.platform_name,
            iteration=iteration,
            messages=messages,
            run_config=config,
            tool_call=call,
        )
        return await dispatch_tool_middleware(
            config.middlewares,
            context,
            self._execute_tool_terminal,
        )

    async def _execute_tool_terminal(self, context: ToolCallContext) -> ToolResult:
        result = await self._impl.execute_tool(context.tool_call, context.run_config)
        return ToolResult(
            tool_call_id=context.tool_call.id,
            name=context.tool_call.name,
            result=result,
        )

    @staticmethod
    def _append_tool_results(
        messages: list[Message], results: list[ToolResult]
    ) -> None:
        for r in results:
            messages.append(
                Message(
                    role="tool",
                    content=r.result,
                    name=r.name,
                    tool_call_id=r.tool_call_id,
                )
            )

    @staticmethod
    def _last_assistant(messages: list[Message]) -> str:
        return next(
            (m.content for m in reversed(messages) if m.role == "assistant"), ""
        )

    async def _complete(
        self,
        messages: list[Message],
        config: RunConfig,
        *,
        iteration: int,
    ) -> ModelResponse:
        context = ModelCallContext(
            executor_name=self.name,
            runtime_name=self._impl.platform_name,
            iteration=iteration,
            messages=messages,
            run_config=config,
        )
        return await dispatch_model_middleware(
            config.middlewares,
            context,
            self._complete_terminal,
        )

    async def _complete_terminal(self, context: ModelCallContext) -> ModelResponse:
        text, tool_calls = await self._impl.complete(context.messages, context.run_config)
        return ModelResponse(text=text, tool_calls=list(tool_calls))


# ---------------------------------------------------------------------------
# Refined Abstraction 1 — Simple (one-shot)
# ---------------------------------------------------------------------------

class SimpleAgentExecutor(AgentExecutor):
    """
    Single completion with no agentic loop.

    Useful when the model never needs to call tools or when the caller
    manages the loop externally.
    """

    @property
    def _strategy_name(self) -> str:
        return "simple"

    async def run(
        self, messages: list[Message], config: RunConfig
    ) -> RunResult:
        start = time.monotonic()
        response = await self._complete(messages, config, iteration=1)
        return RunResult(
            final_message=response.text,
            messages=[*messages, Message(role="assistant", content=response.text)],
            iterations=1,
            tool_calls_performed=[],
            duration_ms=(time.monotonic() - start) * 1000,
        )


# ---------------------------------------------------------------------------
# Refined Abstraction 2 — ReAct (Reason + Act)
# ---------------------------------------------------------------------------

class ReActAgentExecutor(AgentExecutor):
    """
    Implements the ReAct (Reason → Act → Observe) agentic loop.

    Each iteration:
      1. Calls ``complete`` to get a response and optional tool calls.
      2. If no tool calls, returns the response as the final answer.
      3. Otherwise executes all tool calls concurrently, appends results
         to the message history, and repeats.

    The loop terminates naturally when the model stops requesting tools,
    or forcibly when ``config.max_iterations`` is reached.
    """

    @property
    def _strategy_name(self) -> str:
        return "react"

    async def run(
        self, messages: list[Message], config: RunConfig
    ) -> RunResult:
        start = time.monotonic()
        msgs = list(messages)
        all_results: list[ToolResult] = []

        for iteration in range(1, config.max_iterations + 1):
            logger.debug("ReAct iteration %d/%d.", iteration, config.max_iterations)
            response = await self._complete(msgs, config, iteration=iteration)
            msgs.append(
                Message(
                    role="assistant",
                    content=response.text,
                    tool_calls=list(response.tool_calls),
                )
            )

            if not response.tool_calls:
                return RunResult(
                    final_message=response.text,
                    messages=msgs,
                    iterations=iteration,
                    tool_calls_performed=all_results,
                    duration_ms=(time.monotonic() - start) * 1000,
                )

            results = await asyncio.gather(
                *[
                    self._call_tool(tc, config, messages=msgs, iteration=iteration)
                    for tc in response.tool_calls
                ]
            )
            all_results.extend(results)
            self._append_tool_results(msgs, list(results))

        return RunResult(
            final_message=self._last_assistant(msgs),
            messages=msgs,
            iterations=config.max_iterations,
            tool_calls_performed=all_results,
            duration_ms=(time.monotonic() - start) * 1000,
            metadata={"stopped_by_max_iterations": True},
        )


# ---------------------------------------------------------------------------
# Refined Abstraction 3 — Plan-Act
# ---------------------------------------------------------------------------

class PlanActAgentExecutor(AgentExecutor):
    """
    Two-phase strategy: generate an explicit plan, then execute it.

    Phase 1 — Planning:
        Calls ``complete`` with tools disabled and an injected planning
        instruction appended to the system prompt.  The model produces a
        numbered list of steps.

    Phase 2 — Execution:
        Runs a ReAct-style loop with tools enabled, guided by the plan
        that was prepended to the context.

    This strategy trades latency for predictability on complex, multi-step
    tasks where an implicit loop tends to lose track of sub-goals.
    """

    PLANNING_SUFFIX = (
        "\n\nBefore acting, output a numbered list of the steps you will take. "
        "Do NOT execute any steps yet — plan only."
    )

    @property
    def _strategy_name(self) -> str:
        return "plan-act"

    async def run(
        self, messages: list[Message], config: RunConfig
    ) -> RunResult:
        start = time.monotonic()
        msgs = list(messages)
        all_results: list[ToolResult] = []

        # ── Phase 1: Plan ──────────────────────────────────────
        plan_config = RunConfig(
            system_prompt=(config.system_prompt or "") + self.PLANNING_SUFFIX,
            tools=[],
            middlewares=list(config.middlewares),
            temperature=config.temperature,
            max_iterations=config.max_iterations,
            extra=config.extra,
        )
        plan_response = await self._complete(msgs, plan_config, iteration=0)
        plan_text = plan_response.text
        logger.debug("Plan generated (%d chars).", len(plan_text))
        msgs.append(Message(role="assistant", content=f"Plan:\n{plan_text}"))

        # ── Phase 2: Execute ───────────────────────────────────
        for iteration in range(1, config.max_iterations):
            response = await self._complete(msgs, config, iteration=iteration)
            msgs.append(
                Message(
                    role="assistant",
                    content=response.text,
                    tool_calls=list(response.tool_calls),
                )
            )

            if not response.tool_calls:
                return RunResult(
                    final_message=response.text,
                    messages=msgs,
                    iterations=iteration + 1,
                    tool_calls_performed=all_results,
                    duration_ms=(time.monotonic() - start) * 1000,
                    metadata={"plan": plan_text},
                )

            results = await asyncio.gather(
                *[
                    self._call_tool(tc, config, messages=msgs, iteration=iteration)
                    for tc in response.tool_calls
                ]
            )
            all_results.extend(results)
            self._append_tool_results(msgs, list(results))

        return RunResult(
            final_message=self._last_assistant(msgs),
            messages=msgs,
            iterations=config.max_iterations,
            tool_calls_performed=all_results,
            duration_ms=(time.monotonic() - start) * 1000,
            metadata={"plan": plan_text, "stopped_by_max_iterations": True},
        )
