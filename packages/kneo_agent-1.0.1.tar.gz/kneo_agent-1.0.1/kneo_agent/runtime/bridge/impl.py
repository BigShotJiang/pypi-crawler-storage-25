"""
kneo_agent.runtime.bridge.impl
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Bridge Pattern — Implementor interface.

``RuntimeImpl`` is the *Implementor* Protocol.  Every concrete platform
class (``GoogleADKImpl``, ``OpenAIAgentsImpl``, ``LangChainImpl``) must
satisfy this interface.

Concrete implementors live in ``kneo_agent.providers.*`` so that each
provider's optional dependencies stay isolated.
"""

from __future__ import annotations

from typing import AsyncGenerator, Protocol, runtime_checkable

from ...core.types import Message, RunConfig, ToolCall


@runtime_checkable
class RuntimeImpl(Protocol):
    """
    Low-level plumbing interface for a specific LLM platform.

    Speaks in raw platform primitives; the agentic loop logic lives
    entirely in ``AgentExecutor`` subclasses above this layer.
    """

    @property
    def platform_name(self) -> str:
        """Short identifier, e.g. ``"openai-agents"``."""
        ...

    async def complete(
        self,
        messages: list[Message],
        config: RunConfig,
    ) -> tuple[str, list[ToolCall]]:
        """
        Send one completion request.

        Returns a ``(response_text, tool_calls)`` pair.
        ``tool_calls`` is empty when the model chose not to call any tools.
        """
        ...

    async def execute_tool(
        self,
        call: ToolCall,
        config: RunConfig,
    ) -> str:
        """
        Dispatch a tool call and return its result as a string.

        The implementation may call a local function, an HTTP endpoint,
        or delegate to the platform's own tool-dispatch mechanism.
        """
        ...

    async def stream_tokens(
        self,
        messages: list[Message],
        config: RunConfig,
    ) -> AsyncGenerator[str, None]:
        """Yield raw text tokens as they arrive from the model."""
        ...

    def supports_tools(self) -> bool: ...
    def supports_streaming(self) -> bool: ...
