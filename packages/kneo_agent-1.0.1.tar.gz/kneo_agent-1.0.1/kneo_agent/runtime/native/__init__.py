"""
kneo_agent.runtime.native
~~~~~~~~~~~~~~~~~~~~~~~~~
Platform-owned runtimes.

These runtimes expose ``AgentRuntime`` while delegating loop ownership to the
underlying platform SDK/runtime rather than to Kneo bridge executors.
"""

from ...providers.openai_agents.impl import OpenAIAgentsImpl as OpenAIAgentsRuntime
from ..adapters.base import GoogleADKAdapter


class GoogleADKRuntime(GoogleADKAdapter):
    """Native Google ADK runtime backed by ``runner.run_async(...)``."""

    name = "google-adk-native"


__all__ = ["GoogleADKRuntime", "OpenAIAgentsRuntime"]
