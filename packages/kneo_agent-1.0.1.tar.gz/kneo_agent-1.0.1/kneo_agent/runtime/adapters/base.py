"""
kneo_agent.runtime.adapters.base
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Adapter Pattern — one adapter class per supported platform.

Each ``*Adapter`` class wraps an *existing*, fixed-interface platform
object (the *Adaptee*) and exposes the ``AgentRuntime`` protocol that
``Agent`` expects (the *Target*).

Unlike the Bridge pattern, each Adapter is a single, flat class — it
does not split into two hierarchies.  The platform owns its own agentic
loop; the Adapter's only job is interface translation.

Adapters
--------
``GoogleADKAdapter``
    Wraps ``google.adk`` ``InMemoryRunner`` / ``Runner``.
    ADK emits an async event stream; the adapter reassembles it into
    ``RunResult`` / ``StreamChunk`` objects.

``OpenAIAgentsAdapter``
    Wraps ``@openai/agents`` ``Runner``.
    The SDK accepts a single ``input`` string and returns ``RunResult``
    in one call; the adapter translates the SDK message list into that
    string and maps ``new_items`` back to ``ToolResult[]``.

``LangChainAdapter``
    Wraps ``langchain`` ``AgentExecutor``.
    LangChain uses ``(input, chat_history)`` tuples; the adapter builds
    those from the SDK message list and maps ``intermediate_steps`` back
    to ``ToolResult[]``.
"""

from __future__ import annotations

import json
import logging
import time
from typing import Any, AsyncGenerator

from ...core.types import (
    Message,
    RunConfig,
    RunResult,
    StreamChunk,
    ToolCall,
    ToolResult,
)

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Google ADK Adapter
# ---------------------------------------------------------------------------

class GoogleADKAdapter:
    """
    Adapts a Google ADK Runner → ``AgentRuntime``.

    Adaptee interface (google.adk)::

        runner.run_async(app_name, user_id, session_id, new_message)
            → AsyncGenerator[Event, None]

    ADK manages its own agentic loop (tool dispatch, multi-turn) internally.
    The adapter subscribes to the event stream and reassembles text parts
    and function-call events into SDK types.
    """

    name = "google-adk-adapter"

    def __init__(
        self,
        adk_runner: Any,
        app_name: str,
        user_id: str,
        session_id: str,
    ) -> None:
        self._runner = adk_runner
        self._app_name = app_name
        self._user_id = user_id
        self._session_id = session_id

    # ── AgentRuntime protocol ──────────────────────────────────

    async def run(
        self, messages: list[Message], config: RunConfig
    ) -> RunResult:
        start = time.monotonic()
        last_user = self._last_user(messages)
        msgs = list(messages)
        tool_results: list[ToolResult] = []
        final_text = ""

        async for event in self._event_stream(last_user):
            parts = event.get("content", {}).get("parts", [])
            for part in parts:
                if "text" in part and event.get("author") != "user":
                    final_text += part["text"]
                if "functionCall" in part:
                    fc = part["functionCall"]
                    tool_results.append(ToolResult(
                        tool_call_id=fc.get("id", "unknown"),
                        name=fc["name"],
                        result="dispatched-by-adk",
                    ))

        msgs.append(Message(role="assistant", content=final_text))
        return RunResult(
            final_message=final_text,
            messages=msgs,
            iterations=1,          # ADK manages iterations internally
            tool_calls_performed=tool_results,
            duration_ms=(time.monotonic() - start) * 1000,
        )

    async def stream(
        self, messages: list[Message], config: RunConfig
    ) -> AsyncGenerator[StreamChunk, None]:
        last_user = self._last_user(messages)
        async for event in self._event_stream(last_user):
            parts = event.get("content", {}).get("parts", [])
            for part in parts:
                if "text" in part and event.get("author") != "user":
                    yield StreamChunk(type="text", content=part["text"])
                if "functionCall" in part:
                    fc = part["functionCall"]
                    yield StreamChunk(
                        type="tool_call",
                        tool_call=ToolCall(
                            id=fc.get("id", "unknown"),
                            name=fc["name"],
                            arguments=fc.get("args", {}),
                        ),
                    )
        yield StreamChunk(type="done")

    def supports_streaming(self) -> bool:
        return True

    def supports_tools(self) -> bool:
        return True

    # ── Private helpers ────────────────────────────────────────

    @staticmethod
    def _last_user(messages: list[Message]) -> str:
        msg = next((m for m in reversed(messages) if m.role == "user"), None)
        if not msg:
            raise ValueError("No user message found in history.")
        return msg.content

    async def _event_stream(self, user_text: str) -> AsyncGenerator[dict, None]:
        gen = self._runner.run_async(
            app_name=self._app_name,
            user_id=self._user_id,
            session_id=self._session_id,
            new_message={"role": "user", "parts": [{"text": user_text}]},
        )
        # run_async may be an async generator or a coroutine that returns one
        if not hasattr(gen, "__aiter__"):
            gen = await gen
        async for event in gen:
            yield event


# ---------------------------------------------------------------------------
# OpenAI Agents SDK Adapter
# ---------------------------------------------------------------------------

class OpenAIAgentsAdapter:
    """
    Adapts an OpenAI Agents SDK ``Runner`` → ``AgentRuntime``.

    Adaptee interface (@openai/agents)::

        runner.run(agent, input, max_turns) → RunResult
        runner.stream(agent, input) → AsyncIterable[StreamEvent]

    The SDK accepts a single ``input: str`` per call. This adapter
    concatenates the SDK message list into a conversational string and
    maps the runner's ``new_items`` list back to ``ToolResult`` objects.
    """

    name = "openai-agents-adapter"

    def __init__(
        self,
        runner: Any,
        agent_definition: dict[str, Any],
    ) -> None:
        self._runner = runner
        self._agent_def = agent_definition

    async def run(
        self, messages: list[Message], config: RunConfig
    ) -> RunResult:
        start = time.monotonic()
        agent = self._merge_agent_def(config)
        input_text = self._build_input(messages)

        result = await self._runner.run(
            agent=agent,
            input=input_text,
            max_turns=config.max_iterations,
        )
        tool_results = [
            ToolResult(
                tool_call_id=item.get("call_id", "unknown"),
                name=item.get("tool_name", "unknown"),
                result=json.dumps(item),
            )
            for item in (result.get("new_items") or [])
            if item.get("type") == "tool_call_output_item"
        ]
        final = result.get("final_output", "")
        return RunResult(
            final_message=final,
            messages=[*messages, Message(role="assistant", content=final)],
            iterations=sum(
                1 for i in (result.get("new_items") or [])
                if i.get("type") == "message_output_item"
            ) or 1,
            tool_calls_performed=tool_results,
            duration_ms=(time.monotonic() - start) * 1000,
        )

    async def stream(
        self, messages: list[Message], config: RunConfig
    ) -> AsyncGenerator[StreamChunk, None]:
        input_text = self._build_input(messages)
        async for event in self._runner.stream(
            agent=self._agent_def, input=input_text
        ):
            if event.get("type") == "raw_response_event" and event.get("delta"):
                yield StreamChunk(type="text", content=event["delta"])
            elif event.get("type") == "run_item_stream_event":
                item = event.get("item", {})
                if item.get("type") == "tool_call_item":
                    yield StreamChunk(
                        type="tool_call",
                        tool_call=ToolCall(
                            id=item.get("id", "unknown"),
                            name=item.get("name", "unknown"),
                            arguments=item.get("arguments", {}),
                        ),
                    )
        yield StreamChunk(type="done")

    def supports_streaming(self) -> bool:
        return True

    def supports_tools(self) -> bool:
        return True

    def _merge_agent_def(self, config: RunConfig) -> dict[str, Any]:
        agent = dict(self._agent_def)
        if config.system_prompt:
            agent["instructions"] = config.system_prompt
        if config.tools:
            agent["tools"] = [
                {"type": "function", "name": t.name,
                 "description": t.description, "parameters": t.parameters}
                for t in config.tools
            ]
        return agent

    @staticmethod
    def _build_input(messages: list[Message]) -> str:
        lines = []
        for m in messages:
            if m.role == "user":
                lines.append(f"User: {m.content}")
            elif m.role == "assistant":
                lines.append(f"Assistant: {m.content}")
        return "\n\n".join(lines)


# ---------------------------------------------------------------------------
# LangChain Deep Agents Adapter
# ---------------------------------------------------------------------------

class LangChainAdapter:
    """
    Adapts a LangChain ``AgentExecutor`` → ``AgentRuntime``.

    Adaptee interface (langchain)::

        executor.ainvoke({"input": str, "chat_history": list}) → dict
        executor.astream({"input": str}) → AsyncIterable[dict]

    LangChain's AgentExecutor uses ``(input, chat_history)`` tuples while
    Kneo Agent uses a flat ``list[Message]``.  ``_extract_input_and_history``
    performs the translation — this is the core job of the Adapter.
    """

    name = "langchain-adapter"

    def __init__(self, agent_executor: Any) -> None:
        self._executor = agent_executor

    async def run(
        self, messages: list[Message], config: RunConfig
    ) -> RunResult:
        start = time.monotonic()
        input_text, chat_history = self._extract_input_and_history(messages)

        result = await self._executor.ainvoke(
            {"input": input_text, "chat_history": chat_history},
            config={"tags": ["kneo-agent"]},
        )
        tool_results = [
            ToolResult(
                tool_call_id=f"lc-step-{i}",
                name=step["action"]["tool"],
                result=step["observation"],
            )
            for i, step in enumerate(result.get("intermediate_steps") or [])
        ]
        output = result.get("output", "")
        return RunResult(
            final_message=output,
            messages=[*messages, Message(role="assistant", content=output)],
            iterations=len(result.get("intermediate_steps") or []) + 1,
            tool_calls_performed=tool_results,
            duration_ms=(time.monotonic() - start) * 1000,
        )

    async def stream(
        self, messages: list[Message], config: RunConfig
    ) -> AsyncGenerator[StreamChunk, None]:
        if not hasattr(self._executor, "astream"):
            raise NotImplementedError(
                "LangChain AgentExecutor does not support streaming."
            )
        input_text, _ = self._extract_input_and_history(messages)
        async for chunk in self._executor.astream({"input": input_text}):
            if chunk.get("output"):
                yield StreamChunk(type="text", content=chunk["output"])
            for step in chunk.get("steps") or []:
                yield StreamChunk(
                    type="tool_result",
                    tool_result=ToolResult(
                        tool_call_id=f"lc-{step['action']['tool']}",
                        name=step["action"]["tool"],
                        result=step["observation"],
                    ),
                )
        yield StreamChunk(type="done")

    def supports_streaming(self) -> bool:
        return hasattr(self._executor, "astream")

    def supports_tools(self) -> bool:
        return True

    # ── Core adapter translation ──────────────────────────────

    def _extract_input_and_history(
        self, messages: list[Message]
    ) -> tuple[str, list[tuple[str, str]]]:
        """
        Convert SDK ``list[Message]`` → LangChain ``(input, chat_history)``.

        This method is the heart of the Adapter: it maps one vocabulary
        (SDK messages) to another (LangChain tuples) without altering
        any behaviour.
        """
        conv = [m for m in messages if m.role in ("user", "assistant")]
        pairs: list[tuple[str, str]] = []

        for i in range(0, len(conv) - 1, 2):
            human, ai = conv[i], conv[i + 1] if i + 1 < len(conv) else None
            if human.role == "user" and ai and ai.role == "assistant":
                pairs.append((human.content, ai.content))

        last = conv[-1] if conv else None
        input_text = last.content if last and last.role == "user" else ""
        return input_text, pairs
