"""
kneo_agent.runtime
~~~~~~~~~~~~~~~~~~
Runtime sub-package: Kneo-owned Bridge executors, platform-owned native
runtimes, Adapter wrappers, and the ``RuntimeImpl`` protocol that Bridge
providers must satisfy.
"""

from .adapters import GoogleADKAdapter, LangChainAdapter, OpenAIAgentsAdapter
from .bridge import (
    AgentExecutor,
    PlanActAgentExecutor,
    ReActAgentExecutor,
    RuntimeImpl,
    SimpleAgentExecutor,
)
from .native import GoogleADKRuntime, OpenAIAgentsRuntime

__all__ = [
    # Bridge
    "AgentExecutor",
    "PlanActAgentExecutor",
    "ReActAgentExecutor",
    "RuntimeImpl",
    "SimpleAgentExecutor",
    # Native
    "GoogleADKRuntime",
    "OpenAIAgentsRuntime",
    # Adapters
    "GoogleADKAdapter",
    "LangChainAdapter",
    "OpenAIAgentsAdapter",
]
