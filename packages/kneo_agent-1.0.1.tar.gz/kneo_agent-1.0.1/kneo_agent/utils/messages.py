"""
kneo_agent.utils.messages
~~~~~~~~~~~~~~~~~~~~~~~~~~
Convenience constructors for ``Message`` objects and helpers for
inspecting / slicing conversation histories.
"""

from __future__ import annotations

from ..core.types import Message, ToolCall


# ---------------------------------------------------------------------------
# Constructors
# ---------------------------------------------------------------------------

def user(content: str) -> Message:
    """Create a user-role message."""
    return Message(role="user", content=content)


def assistant(content: str) -> Message:
    """Create an assistant-role message."""
    return Message(role="assistant", content=content)


def system(content: str) -> Message:
    """Create a system-role message."""
    return Message(role="system", content=content)


def tool_result(
    content: str,
    *,
    tool_call_id: str,
    name: str | None = None,
) -> Message:
    """Create a tool-result message."""
    return Message(
        role="tool",
        content=content,
        tool_call_id=tool_call_id,
        name=name,
    )


# ---------------------------------------------------------------------------
# Inspection helpers
# ---------------------------------------------------------------------------

def last_user_message(messages: list[Message]) -> Message | None:
    """Return the most recent user message, or ``None``."""
    return next((m for m in reversed(messages) if m.role == "user"), None)


def last_assistant_message(messages: list[Message]) -> Message | None:
    """Return the most recent assistant message, or ``None``."""
    return next((m for m in reversed(messages) if m.role == "assistant"), None)


def filter_by_role(messages: list[Message], role: str) -> list[Message]:
    """Return all messages with the given role."""
    return [m for m in messages if m.role == role]


def to_dict_list(messages: list[Message]) -> list[dict]:
    """
    Serialise a message list to plain dicts (e.g. for JSON storage).

    Only non-None fields are included.
    """
    result = []
    for m in messages:
        d: dict = {"role": m.role, "content": m.content}
        if m.name is not None:
            d["name"] = m.name
        if m.tool_call_id is not None:
            d["tool_call_id"] = m.tool_call_id
        if m.tool_calls:
            d["tool_calls"] = [
                {
                    "id": tc.id,
                    "name": tc.name,
                    "arguments": tc.arguments,
                }
                for tc in m.tool_calls
            ]
        result.append(d)
    return result


def from_dict_list(data: list[dict]) -> list[Message]:
    """Deserialise plain dicts back to ``Message`` objects."""
    return [
        Message(
            role=d["role"],
            content=d["content"],
            name=d.get("name"),
            tool_call_id=d.get("tool_call_id"),
            tool_calls=[
                ToolCall(
                    id=tc["id"],
                    name=tc["name"],
                    arguments=tc["arguments"],
                )
                for tc in d.get("tool_calls", [])
            ],
        )
        for d in data
    ]
