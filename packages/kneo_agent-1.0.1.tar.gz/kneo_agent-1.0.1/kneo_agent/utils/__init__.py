"""
kneo_agent.utils
~~~~~~~~~~~~~~~~~
Utility helpers: logging, tool registry, message constructors.
"""

from .logging import configure_logging, get_logger
from .messages import (
    assistant,
    filter_by_role,
    from_dict_list,
    last_assistant_message,
    last_user_message,
    system,
    to_dict_list,
    tool_result,
    user,
)
from .tools import ToolRegistry
from ..mcp import MCPClientSession, MCPServerConfig, MCPTool

__all__ = [
    # Logging
    "configure_logging",
    "get_logger",
    # Messages
    "assistant",
    "filter_by_role",
    "from_dict_list",
    "last_assistant_message",
    "last_user_message",
    "system",
    "to_dict_list",
    "tool_result",
    "user",
    # Tools
    "ToolRegistry",
    # MCP
    "MCPClientSession",
    "MCPServerConfig",
    "MCPTool",
]
