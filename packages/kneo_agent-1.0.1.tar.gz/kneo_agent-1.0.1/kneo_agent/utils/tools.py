"""
kneo_agent.utils.tools
~~~~~~~~~~~~~~~~~~~~~~~
``ToolRegistry`` — a lightweight registry that pairs ``ToolDefinition``
objects with their Python handler callables.

Using a registry keeps tool metadata and implementation together and
makes it trivial to pass the right tools to ``RunConfig`` while also
giving the provider's ``execute_tool`` method a callable to dispatch to.

Example::

    from kneo_agent.utils.tools import ToolRegistry
    from kneo_agent.core import ToolDefinition

    registry = ToolRegistry()

    @registry.tool(
        name="get_weather",
        description="Return current weather for a city.",
        parameters={
            "type": "object",
            "properties": {"city": {"type": "string"}},
            "required": ["city"],
        },
    )
    def get_weather(args: dict) -> str:
        return f"Weather in {args['city']}: 22 °C, sunny."

    # Pass definitions to RunConfig / AgentConfig
    config = RunConfig(tools=registry.definitions)

    # Dispatch a ToolCall at runtime
    result = registry.call(tool_call)
"""

from __future__ import annotations

import asyncio
import inspect
import json
import logging
from typing import TYPE_CHECKING, Any, Callable

from ..core.skills import Skill, merge_run_extras
from ..core.types import ToolCall, ToolDefinition
from ..mcp import MCPClientSession, MCPServerConfig

logger = logging.getLogger(__name__)

ToolHandler = Callable[[dict[str, Any]], Any]

if TYPE_CHECKING:
    from ..core import Agent, AgentTool


class ToolRegistry:
    """
    Maps tool names to ``(ToolDefinition, handler)`` pairs.

    Thread-safe for reads; writes should happen during initialisation
    before the registry is shared across tasks.
    """

    def __init__(self) -> None:
        self._tools: dict[str, tuple[ToolDefinition, ToolHandler]] = {}
        self._cleanup_callbacks: list[Callable[[], Any]] = []

    # ── Registration ──────────────────────────────────────────

    def register(
        self,
        definition: ToolDefinition,
        handler: ToolHandler,
    ) -> None:
        """Register a tool definition and its handler callable."""
        if definition.name in self._tools:
            logger.warning(
                "Tool '%s' is already registered and will be overwritten.",
                definition.name,
            )
        self._tools[definition.name] = (definition, handler)

    async def register_mcp_server(
        self,
        server: MCPServerConfig,
        *,
        prefix: str | None = None,
    ) -> list[ToolDefinition]:
        """
        Discover tools from an MCP server and register proxy handlers for them.

        ``prefix`` can be used to namespace remote tool names locally.
        """
        session = await MCPClientSession(server).connect()
        self._cleanup_callbacks.append(session.aclose)

        definitions: list[ToolDefinition] = []
        for tool in await session.list_tools():
            local_name = f"{prefix}{tool.name}" if prefix else tool.name

            async def handler(
                args: dict[str, Any],
                *,
                _session: MCPClientSession = session,
                _remote_name: str = tool.name,
            ) -> Any:
                return await _session.call_tool(_remote_name, args)

            definition = tool.to_tool_definition(local_name=local_name)
            self.register(definition, handler)
            definitions.append(definition)
        return definitions

    def register_agent_tool(self, tool: "AgentTool") -> None:
        """Register an ``AgentTool`` returned by ``Agent.as_tool()``."""
        self.register(tool.definition, tool.handler)

    def add_agent(self, agent: "Agent", **kwargs: Any) -> "AgentTool":
        """Create and register a tool that delegates to ``agent``."""
        tool = agent.as_tool(**kwargs)
        self.register_agent_tool(tool)
        return tool

    def tool(
        self,
        name: str,
        description: str,
        parameters: dict[str, Any],
    ) -> Callable[[ToolHandler], ToolHandler]:
        """
        Decorator that registers the decorated function as a tool.

        Example::

            @registry.tool(
                name="add",
                description="Add two integers.",
                parameters={
                    "type": "object",
                    "properties": {
                        "a": {"type": "integer"},
                        "b": {"type": "integer"},
                    },
                    "required": ["a", "b"],
                },
            )
            def add(args: dict) -> str:
                return str(args["a"] + args["b"])
        """
        def decorator(fn: ToolHandler) -> ToolHandler:
            self.register(ToolDefinition(name, description, parameters), fn)
            return fn
        return decorator

    # ── Dispatch ──────────────────────────────────────────────

    async def call(self, tool_call: ToolCall) -> str:
        """
        Dispatch a ``ToolCall`` to its registered handler.

        Both sync and async handlers are supported.
        Returns the handler's return value coerced to a JSON string.

        Raises
        ------
        KeyError
            If no handler is registered for ``tool_call.name``.
        """
        if tool_call.name not in self._tools:
            raise KeyError(f'No handler registered for tool "{tool_call.name}".')

        _, handler = self._tools[tool_call.name]
        logger.debug("Dispatching tool '%s'.", tool_call.name)
        result = handler(tool_call.arguments)
        if asyncio.iscoroutine(result):
            result = await result
        return result if isinstance(result, str) else json.dumps(result)

    def call_sync(self, tool_call: ToolCall) -> str:
        """
        Synchronous variant of ``call`` (for non-async contexts).

        Raises
        ------
        RuntimeError
            If the handler is a coroutine function.
        """
        if tool_call.name not in self._tools:
            raise KeyError(f'No handler registered for tool "{tool_call.name}".')
        _, handler = self._tools[tool_call.name]
        if inspect.iscoroutinefunction(handler):
            raise RuntimeError(
                f"Tool '{tool_call.name}' is async; use 'await registry.call()' instead."
            )
        result = handler(tool_call.arguments)
        return result if isinstance(result, str) else json.dumps(result)

    # ── Accessors ─────────────────────────────────────────────

    @property
    def definitions(self) -> list[ToolDefinition]:
        """Return all registered ``ToolDefinition`` objects."""
        return [defn for defn, _ in self._tools.values()]

    @property
    def names(self) -> list[str]:
        """Return all registered tool names."""
        return list(self._tools)

    def __len__(self) -> int:
        return len(self._tools)

    def __contains__(self, name: str) -> bool:
        return name in self._tools

    def __repr__(self) -> str:  # pragma: no cover
        return f"<ToolRegistry tools={self.names!r}>"

    async def aclose(self) -> None:
        """Close any background resources owned by the registry."""
        callbacks = list(self._cleanup_callbacks)
        self._cleanup_callbacks.clear()
        for callback in callbacks:
            result = callback()
            if inspect.isawaitable(result):
                await result

    def to_skill(
        self,
        name: str,
        *,
        description: str = "",
        system_prompt: str | None = None,
        defaults: dict[str, Any] | None = None,
        extra: dict[str, Any] | None = None,
        tags: list[str] | None = None,
    ) -> Skill:
        """
        Package the registry as a ``Skill`` with both definitions and handlers.
        """
        handlers = {tool_name: handler for tool_name, (_, handler) in self._tools.items()}
        return Skill(
            name=name,
            description=description,
            system_prompt=system_prompt,
            tools=self.definitions,
            defaults=dict(defaults or {}),
            extra=merge_run_extras(extra or {}, {"tool_handlers": handlers}),
            tags=list(tags or []),
        )
