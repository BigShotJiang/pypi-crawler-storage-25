"""
kneo_agent.utils.logging
~~~~~~~~~~~~~~~~~~~~~~~~~
Logging configuration helpers for Kneo Agent.

Kneo Agent uses Python's standard ``logging`` module throughout.
All loggers are named under the ``kneo_agent.*`` hierarchy so that
application code can control verbosity with a single call::

    import logging
    logging.getLogger("kneo_agent").setLevel(logging.DEBUG)

This module provides convenience helpers for common setups.
"""

from __future__ import annotations

import logging
import sys
from typing import Literal

LogLevel = Literal["DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"]

_FORMATTER = logging.Formatter(
    fmt="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    datefmt="%H:%M:%S",
)

_ROOT_LOGGER = "kneo_agent"


def configure_logging(
    level: LogLevel | int = "INFO",
    stream: object = sys.stderr,
) -> None:
    """
    Configure a ``StreamHandler`` on the root ``kneo_agent`` logger.

    Call once at application startup.  Subsequent calls are idempotent
    (the handler is not added twice).

    Parameters
    ----------
    level:
        Log level name (e.g. ``"DEBUG"``) or integer constant.
    stream:
        Output stream (default ``sys.stderr``).

    Example::

        from kneo_agent.utils.logging import configure_logging
        configure_logging("DEBUG")
    """
    logger = logging.getLogger(_ROOT_LOGGER)
    numeric = (
        getattr(logging, level) if isinstance(level, str) else level
    )
    logger.setLevel(numeric)

    if not any(
        isinstance(h, logging.StreamHandler) and h.stream is stream
        for h in logger.handlers
    ):
        handler = logging.StreamHandler(stream)  # type: ignore[arg-type]
        handler.setFormatter(_FORMATTER)
        logger.addHandler(handler)


def get_logger(name: str) -> logging.Logger:
    """
    Return a child logger under the ``kneo_agent`` namespace.

    Parameters
    ----------
    name:
        Dotted suffix, e.g. ``"my_app.agent"``.
        The returned logger is named ``"kneo_agent.my_app.agent"``.
    """
    return logging.getLogger(f"{_ROOT_LOGGER}.{name}")
