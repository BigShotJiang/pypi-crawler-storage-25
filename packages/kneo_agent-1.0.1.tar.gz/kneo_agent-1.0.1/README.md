# Kneo Agent

Kneo Agent is a Python SDK for building LLM-powered agents across multiple providers with one consistent API.

It supports:

- bridge-style runtimes where Kneo owns the execution loop
- native runtimes backed by provider SDK behavior
- adapter-style wrappers around existing provider objects
- workflows for orchestrating multi-step or multi-agent runs

## Requirements

- Python 3.12+

## Installation

Install the core package from PyPI:

```bash
pip install kneo-agent
```

Install with optional provider extras when needed:

```bash
pip install "kneo-agent[openai]"
pip install "kneo-agent[langchain]"
pip install "kneo-agent[google-adk]"
pip install "kneo-agent[all]"
```

## Quick Start

```python
import asyncio

from kneo_agent import AgentBuilder
from kneo_agent.patterns import BridgeAgentFactory


runtime = BridgeAgentFactory.for_openai(model="gpt-4o", strategy="react")

agent = (
    AgentBuilder()
    .with_name("Assistant")
    .with_system_prompt("You are a helpful assistant.")
    .use_bridge(runtime)
    .build()
)


async def main() -> None:
    reply = await agent.chat("What is 2 + 2?")
    print(reply)


asyncio.run(main())
```

## Optional Features

- `openai`: OpenAI Agents integration
- `langchain`: LangChain integration
- `google-adk`: Google ADK integration
- `all`: all optional provider integrations

## Package Contents

The published distribution contains the `kneo_agent` package and typed package metadata for downstream users.
