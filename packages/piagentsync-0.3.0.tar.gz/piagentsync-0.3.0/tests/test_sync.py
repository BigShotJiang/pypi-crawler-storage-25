"""Tests for sync functions."""

from pathlib import Path

from piagentsync.config import Settings
from piagentsync.models import EntryKind, ProjectManifest, SyncEntry
from piagentsync.sync import (
    collect_entries,
    collect_global_entries,
    collect_push_entries,
    collect_push_global_entries,
    sync_entries,
)


def test_collect_entries_returns_all_md_files(
    vault_with_supernova: Path, tmp_path: Path
) -> None:
    """Returns all .md files from agents, skills, and AGENTS.md."""
    vault_root = vault_with_supernova
    workspace = tmp_path / "workspace" / "supernova"
    manifest = ProjectManifest(project="supernova", workspace=workspace)
    settings = Settings(vault_path=vault_root)

    entries = collect_entries(manifest, settings)

    names = {e.name for e in entries}
    assert names == {"proxmox-vm-manager", "flux-app-deployer", "debug-flux", "AGENTS"}
    kinds = {e.name: e.kind for e in entries}
    assert kinds["proxmox-vm-manager"] == EntryKind.AGENT
    assert kinds["flux-app-deployer"] == EntryKind.AGENT
    assert kinds["debug-flux"] == EntryKind.SKILL
    assert kinds["AGENTS"] == EntryKind.CONTEXT_FILE


def test_collect_entries_ignores_non_md_files(
    vault_with_supernova: Path, tmp_path: Path
) -> None:
    """Ignores files with other extensions."""
    # Add a .txt file in agents
    agents_dir = vault_with_supernova / "projects" / "supernova" / "agents"
    (agents_dir / "readme.txt").write_text("ignore me")
    manifest = ProjectManifest(project="supernova", workspace=tmp_path / "ws")
    settings = Settings(vault_path=vault_with_supernova)
    entries = collect_entries(manifest, settings)
    assert all(e.name != "readme.txt" for e in entries)


def test_collect_entries_empty_when_dirs_missing(
    vault_path: Path, tmp_path: Path
) -> None:
    """No error when project directories are missing; returns empty list."""
    # vault_path is empty
    manifest = ProjectManifest(project="nonexistent", workspace=tmp_path / "ws")
    settings = Settings(vault_path=vault_path)
    entries = collect_entries(manifest, settings)
    assert entries == []


def test_collect_global_entries(vault_with_global_agents: Path, tmp_path: Path) -> None:
    """Finds agents under vault/agents/global/."""
    vault_root = vault_with_global_agents
    global_base = tmp_path / "global" / "opencode"
    settings = Settings(vault_path=vault_root, global_opencode_path=global_base)
    entries = collect_global_entries(settings)

    assert len(entries) == 1
    entry = entries[0]
    assert entry.name == "chief-pm"
    assert entry.kind == EntryKind.AGENT
    assert entry.source == vault_root / "agents" / "global" / "chief-pm.md"
    assert entry.destination == global_base / "agents" / "chief-pm.md"


def test_sync_writes_missing_file(vault_with_supernova: Path, tmp_path: Path) -> None:
    """File absent in dest → written, in result.written."""
    vault_root = vault_with_supernova
    workspace = tmp_path / "workspace" / "supernova"
    workspace.mkdir(parents=True)
    manifest = ProjectManifest(project="supernova", workspace=workspace)
    settings = Settings(vault_path=vault_root)
    entries = collect_entries(manifest, settings)
    # Pick one entry
    agent_entry = next(e for e in entries if e.kind == EntryKind.AGENT)
    result = sync_entries([agent_entry], dry_run=False)
    assert len(result.written) == 1
    assert agent_entry in result.written
    assert agent_entry.destination.exists()
    assert agent_entry.destination.read_text() == agent_entry.source.read_text()


def test_sync_skips_identical_file(vault_with_supernova: Path, tmp_path: Path) -> None:
    """Same content → result.skipped."""
    vault_root = vault_with_supernova
    workspace = tmp_path / "workspace" / "supernova"
    workspace.mkdir(parents=True)
    manifest = ProjectManifest(project="supernova", workspace=workspace)
    settings = Settings(vault_path=vault_root)
    entries = collect_entries(manifest, settings)
    agent_entry = next(e for e in entries if e.kind == EntryKind.AGENT)
    # Write the same content to destination first
    agent_entry.destination.parent.mkdir(parents=True, exist_ok=True)
    agent_entry.destination.write_bytes(agent_entry.source.read_bytes())
    result = sync_entries([agent_entry], dry_run=False)
    assert len(result.skipped) == 1
    assert agent_entry in result.skipped
    assert len(result.written) == 0


def test_sync_overwrites_changed_file(
    vault_with_supernova: Path, tmp_path: Path
) -> None:
    """Different content → overwrite (vault wins)."""
    vault_root = vault_with_supernova
    workspace = tmp_path / "workspace" / "supernova"
    workspace.mkdir(parents=True)
    manifest = ProjectManifest(project="supernova", workspace=workspace)
    settings = Settings(vault_path=vault_root)
    entries = collect_entries(manifest, settings)
    agent_entry = next(e for e in entries if e.kind == EntryKind.AGENT)
    # Write different content to destination
    agent_entry.destination.parent.mkdir(parents=True, exist_ok=True)
    agent_entry.destination.write_text("old content")
    result = sync_entries([agent_entry], dry_run=False)
    assert len(result.written) == 1
    assert agent_entry in result.written
    assert agent_entry.destination.read_text() == agent_entry.source.read_text()


def test_sync_creates_parent_dirs(vault_with_supernova: Path, tmp_path: Path) -> None:
    """Creates destination parent directories."""
    vault_root = vault_with_supernova
    workspace = tmp_path / "deep" / "nested" / "workspace"
    manifest = ProjectManifest(project="supernova", workspace=workspace)
    settings = Settings(vault_path=vault_root)
    entries = collect_entries(manifest, settings)
    agent_entry = next(e for e in entries if e.name == "proxmox-vm-manager")
    sync_entries([agent_entry], dry_run=False)
    assert agent_entry.destination.exists()
    assert agent_entry.destination.parent.exists()


def test_sync_dry_run_does_not_write(
    vault_with_supernova: Path, tmp_path: Path
) -> None:
    """dry_run=True → never writes."""
    vault_root = vault_with_supernova
    workspace = tmp_path / "workspace" / "dry"
    workspace.mkdir(parents=True)
    manifest = ProjectManifest(project="supernova", workspace=workspace)
    settings = Settings(vault_path=vault_root)
    entries = collect_entries(manifest, settings)
    agent_entry = next(e for e in entries if e.kind == EntryKind.AGENT)
    result = sync_entries([agent_entry], dry_run=True)
    assert len(result.written) == 1
    assert not agent_entry.destination.exists()


def test_sync_dry_run_reports_would_write(
    vault_with_supernova: Path, tmp_path: Path
) -> None:
    """dry_run still classifies as written/skipped."""
    vault_root = vault_with_supernova
    workspace = tmp_path / "workspace" / "dry2"
    workspace.mkdir(parents=True)
    manifest = ProjectManifest(project="supernova", workspace=workspace)
    settings = Settings(vault_path=vault_root)
    entries = collect_entries(manifest, settings)
    # For all entries, since dest doesn't exist, should be marked as written in dry run
    result = sync_entries(entries, dry_run=True)
    total_entries = len(entries)
    assert result.total == total_entries
    assert len(result.written) == total_entries
    assert len(result.skipped) == 0
    assert len(result.errors) == 0


def test_sync_continues_on_error(vault_with_supernova: Path, tmp_path: Path) -> None:
    """One unreadable file → continues, error in result.errors."""
    vault_root = vault_with_supernova
    workspace = tmp_path / "workspace" / "err"
    workspace.mkdir(parents=True)
    manifest = ProjectManifest(project="supernova", workspace=workspace)
    settings = Settings(vault_path=vault_root)
    entries = collect_entries(manifest, settings)
    # Create an entry where source is a directory to cause error
    invalid_entry = SyncEntry(
        name="bad",
        source=workspace,  # a directory, not a file
        destination=workspace / "bad.md",
        kind=EntryKind.AGENT,
    )
    modified_entries = [invalid_entry] + entries
    result = sync_entries(modified_entries, dry_run=False)
    # invalid_entry should be in errors
    assert any(entry.name == "bad" for (entry, _) in result.errors)
    # The valid entries should have been processed (written or skipped)
    # Ensure we didn't crash and result includes both error and some progress
    assert result.total == len(modified_entries)


def test_sync_result_summary_line() -> None:
    """summary_line returns correct string."""
    result = sync_entries(
        [], dry_run=False
    )  # but sync_entries expects entries; we can test SyncResult directly if accessible, but it's not imported here. Instead test via result.
    # Actually we can test directly on SyncResult by importing.
    from piagentsync.models import SyncResult, SyncEntry, EntryKind

    result = SyncResult(written=[], skipped=[], errors=[])
    assert "0 written" in result.summary_line
    assert "0 skipped" in result.summary_line
    assert "0 errors" in result.summary_line
    e = SyncEntry(
        name="e", source=Path("/s"), destination=Path("/d"), kind=EntryKind.AGENT
    )
    result2 = SyncResult(written=[e], skipped=[e], errors=[(e, "oops")])
    assert result2.summary_line == "1 written · 1 skipped · 1 errors"


def test_sync_result_has_errors_false() -> None:
    """has_errors is False when no errors."""
    result = sync_entries([], dry_run=False)  # empty result
    assert not result.has_errors
    # or use SyncResult directly
    from piagentsync.models import SyncResult

    result2 = SyncResult(written=[], skipped=[], errors=[])
    assert not result2.has_errors


def test_sync_result_has_errors_true() -> None:
    """has_errors is True when there are errors."""
    from piagentsync.models import SyncResult, SyncEntry, EntryKind

    e = SyncEntry(
        name="e", source=Path("/s"), destination=Path("/d"), kind=EntryKind.AGENT
    )
    result = SyncResult(written=[], skipped=[], errors=[(e, "boom")])
    assert result.has_errors


# Tests for push functions
def test_collect_push_entries_returns_all_md_files(
    vault_path: Path, workspace_with_supernova: Path
) -> None:
    """Returns all .md files from workspace .opencode/ to vault destinations."""
    workspace = workspace_with_supernova
    manifest = ProjectManifest(project="supernova", workspace=workspace)
    settings = Settings(vault_path=vault_path)

    entries = collect_push_entries(manifest, settings)

    names = {e.name for e in entries}
    assert names == {"proxmox-vm-manager", "flux-app-deployer", "debug-flux", "AGENTS"}
    kinds = {e.name: e.kind for e in entries}
    assert kinds["proxmox-vm-manager"] == EntryKind.AGENT
    assert kinds["flux-app-deployer"] == EntryKind.AGENT
    assert kinds["debug-flux"] == EntryKind.SKILL
    assert kinds["AGENTS"] == EntryKind.CONTEXT_FILE

    # Verify source/destination orientation (workspace → vault)
    for entry in entries:
        assert str(entry.source).startswith(str(workspace))
        assert str(entry.destination).startswith(str(vault_path))


def test_collect_push_entries_ignores_non_md_files(
    vault_path: Path, workspace_with_supernova: Path
) -> None:
    """Ignores files with other extensions in workspace."""
    workspace = workspace_with_supernova
    agents_dir = workspace / ".opencode" / "agents"
    (agents_dir / "readme.txt").write_text("ignore me")

    manifest = ProjectManifest(project="supernova", workspace=workspace)
    settings = Settings(vault_path=vault_path)
    entries = collect_push_entries(manifest, settings)
    assert all(e.name != "readme.txt" for e in entries)


def test_collect_push_entries_empty_when_workspace_dirs_missing(
    vault_path: Path, tmp_path: Path
) -> None:
    """Empty list when .opencode/ dirs missing in workspace."""
    workspace = tmp_path / "missing" / "ws"
    manifest = ProjectManifest(project="test", workspace=workspace)
    settings = Settings(vault_path=vault_path)
    entries = collect_push_entries(manifest, settings)
    assert entries == []


def test_collect_push_global_entries(
    vault_path: Path, global_opencode_with_agents: Path
) -> None:
    """Pushes global agents from global workspace to vault."""
    global_ws = global_opencode_with_agents
    settings = Settings(vault_path=vault_path, global_opencode_path=global_ws)

    entries = collect_push_global_entries(settings)

    assert len(entries) == 1
    entry = entries[0]
    assert entry.name == "chief-pm"
    assert entry.kind == EntryKind.AGENT
    assert entry.source == global_ws / "agents" / "chief-pm.md"
    assert entry.destination == vault_path / "agents" / "global" / "chief-pm.md"


def test_collect_push_global_entries_empty_when_missing(
    vault_path: Path, tmp_path: Path
) -> None:
    """Empty list when global workspace agents dir missing."""
    global_ws = tmp_path / "empty" / "opencode"
    settings = Settings(vault_path=vault_path, global_opencode_path=global_ws)
    entries = collect_push_global_entries(settings)
    assert entries == []
