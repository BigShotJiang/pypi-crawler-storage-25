"""Data models for piagentsync."""

from pathlib import Path

from pydantic import BaseModel, ConfigDict, Field, field_validator


class EntryKind:
    """Enum-like class for sync entry kinds."""

    AGENT = "agent"
    SKILL = "skill"
    CONTEXT_FILE = "context_file"


class ProjectManifest(BaseModel):
    """Manifest parsed from AGENTS.md frontmatter."""

    model_config = ConfigDict(frozen=True)

    project: str = Field(..., min_length=1, description="Project slug")
    workspace: Path = Field(..., description="Workspace directory path")
    notion_board_id: str | None = Field(
        default=None, description="Optional Notion DB ID"
    )
    notion_project_filter: str | None = Field(
        default=None, description="Optional Notion project filter"
    )

    @field_validator("project")
    @classmethod
    def validate_project_slug(cls, v: str) -> str:
        """Project slug must be lowercase alphanumeric with hyphens."""
        import re

        if not re.match(r"^[a-z0-9-]+$", v):
            raise ValueError("project must be lowercase letters, numbers, and hyphens")
        return v

    @field_validator("workspace", mode="after")
    @classmethod
    def expand_workspace(cls, v: Path) -> Path:
        """Expand and resolve workspace path."""
        return v.expanduser().resolve()


class SyncEntry(BaseModel):
    """Represents a single file to sync."""

    model_config = ConfigDict(frozen=True)

    name: str = Field(..., description="Filename stem (without extension)")
    source: Path = Field(..., description="Absolute source path in vault")
    destination: Path = Field(..., description="Absolute destination path in workspace")
    kind: str = Field(..., description="Entry kind: agent, skill, or context_file")


class SyncResult(BaseModel):
    """Result of a sync operation."""

    model_config = ConfigDict(frozen=True)

    written: list[SyncEntry] = Field(default_factory=list, description="Files written")
    skipped: list[SyncEntry] = Field(
        default_factory=list, description="Files skipped (unchanged)"
    )
    errors: list[tuple[SyncEntry, str]] = Field(
        default_factory=list, description="(entry, error message) pairs"
    )

    @property
    def total(self) -> int:
        """Total entries processed (written + skipped + errors)."""
        return len(self.written) + len(self.skipped) + len(self.errors)

    @property
    def has_errors(self) -> bool:
        """True if any errors occurred during sync."""
        return len(self.errors) > 0

    @property
    def summary_line(self) -> str:
        """One-line summary: 'N written · N skipped · N errors'."""
        return f"{len(self.written)} written · {len(self.skipped)} skipped · {len(self.errors)} errors"
