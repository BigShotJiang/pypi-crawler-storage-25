"""CLI entry point for piagentsync."""

import hashlib
import json
import subprocess
from pathlib import Path

import typer
from pydantic import ValidationError
from rich.console import Console
from rich.table import Table

from . import __version__
from .config import Settings, ensure_vault_exists, get_settings
from .errors import (
    ManifestNotFoundError,
    ManifestParseError,
    PiAgentSyncError,
    VaultNotFoundError,
)
from .manifest import parse_manifest
from .models import ProjectManifest, SyncEntry, SyncResult
from .sync import (
    collect_entries,
    collect_global_entries,
    collect_push_entries,
    collect_push_global_entries,
    copy_file_sync,
    sync_entries,
)

app = typer.Typer()
console = Console()


@app.callback(invoke_without_command=True)
def main(
    ctx: typer.Context,
    version: bool = typer.Option(False, "--version", help="Print version and exit"),
) -> None:
    if version:
        console.print(f"piagentsync {__version__}")
        raise typer.Exit(0)


@app.command()
def pull(
    project: str | None = typer.Argument(None, help="Project name"),
    dry_run: bool = typer.Option(
        False, "--dry-run", "--no-dry-run", help="Preview changes without writing"
    ),
    global_sync: bool = typer.Option(
        False, "--global", "--no-global", help="Also sync global agents"
    ),
    all_projects: bool = typer.Option(
        False, "--all", "--no-all", help="Sync all discovered projects"
    ),
) -> None:
    """Sync projects from vault to workspace."""
    if project is None and not all_projects:
        console.print("[red]Error:[/] Must specify a project name or use --all flag")
        raise typer.Exit(1)
    if project is not None and all_projects:
        console.print("[red]Error:[/] Cannot specify both project and --all")
        raise typer.Exit(1)

    settings = get_settings()
    try:
        ensure_vault_exists(settings)
    except VaultNotFoundError as e:
        console.print(f"[red]{e}[/]")
        raise typer.Exit(1)

    if all_projects:
        projects_dir = settings.vault_path / "projects"
        if not projects_dir.exists():
            console.print("[yellow]No projects found (directory missing)[/]")
            raise typer.Exit(0)
        project_names = [p.name for p in projects_dir.iterdir() if p.is_dir()]
        any_errors = False
        for proj_name in project_names:
            try:
                _sync_single_project(proj_name, dry_run, global_sync, settings)
            except typer.Exit:
                any_errors = True
        if any_errors:
            raise typer.Exit(1)
    else:
        assert project is not None  # project is guaranteed by earlier check
        _sync_single_project(project, dry_run, global_sync, settings)


@app.command()
def push(
    project: str | None = typer.Argument(None, help="Project name"),
    dry_run: bool = typer.Option(
        False, "--dry-run", "--no-dry-run", help="Preview changes without writing"
    ),
    global_sync: bool = typer.Option(
        False, "--global", "--no-global", help="Also push global agents"
    ),
    all_projects: bool = typer.Option(
        False, "--all", "--no-all", help="Push all discovered projects"
    ),
) -> None:
    """Sync projects from workspace to vault.

    Pushes workspace .opencode/ directories back to vault.
    After push, commit changes manually: cd ~/vault && git add -A && git commit
    """
    if project is None and not all_projects:
        console.print("[red]Error:[/] Must specify a project name or use --all flag")
        raise typer.Exit(1)
    if project is not None and all_projects:
        console.print("[red]Error:[/] Cannot specify both project and --all")
        raise typer.Exit(1)

    settings = get_settings()
    try:
        ensure_vault_exists(settings)
    except VaultNotFoundError as e:
        console.print(f"[red]{e}[/]")
        raise typer.Exit(1)

    if all_projects:
        projects_dir = settings.vault_path / "projects"
        if not projects_dir.exists():
            console.print("[yellow]No projects found (directory missing)[/]")
            raise typer.Exit(0)
        project_names = [p.name for p in projects_dir.iterdir() if p.is_dir()]
        any_errors = False
        for proj_name in project_names:
            try:
                _push_single_project(proj_name, dry_run, global_sync, settings)
            except typer.Exit:
                any_errors = True
        if any_errors:
            raise typer.Exit(1)
    else:
        assert project is not None  # project is guaranteed by earlier check
        _push_single_project(project, dry_run, global_sync, settings)


def _sync_single_project(
    project: str, dry_run: bool, global_sync: bool, settings: Settings
) -> None:
    manifest_path = settings.vault_path / "projects" / project / "AGENTS.md"
    try:
        manifest = parse_manifest(manifest_path)
    except ManifestNotFoundError:
        console.print(f"[red]Manifest not found for project:[/] {project}")
        raise typer.Exit(1)
    except ManifestParseError as e:
        console.print(f"[red]Failed to parse manifest for project {project}:[/] {e}")
        raise typer.Exit(1)

    entries = collect_entries(manifest, settings)
    if global_sync:
        try:
            global_entries = collect_global_entries(settings)
            entries.extend(global_entries)
        except Exception as e:
            console.print(f"[yellow]Warning:[/] Failed to collect global agents: {e}")

    result = sync_entries(entries, dry_run=dry_run)
    if dry_run:
        console.print("[yellow]Dry run enabled; no files were written.[/]")
    _print_sync_result(result)
    if result.has_errors:
        raise typer.Exit(1)


def _push_single_project(
    project: str, dry_run: bool, global_sync: bool, settings: Settings
) -> None:
    """Push a single project from workspace to vault.

    Args:
        project: Project name.
        dry_run: If True, preview without writing.
        global_sync: If True, also push global agents.
        settings: Settings with vault and workspace paths.
    """
    manifest_path = settings.vault_path / "projects" / project / "AGENTS.md"
    try:
        manifest = parse_manifest(manifest_path)
    except ManifestNotFoundError:
        console.print(f"[red]Manifest not found for project:[/] {project}")
        raise typer.Exit(1)
    except ManifestParseError as e:
        console.print(f"[red]Failed to parse manifest for project {project}:[/] {e}")
        raise typer.Exit(1)

    entries = collect_push_entries(manifest, settings)
    if global_sync:
        try:
            global_entries = collect_push_global_entries(settings)
            entries.extend(global_entries)
        except Exception as e:
            console.print(f"[yellow]Warning:[/] Failed to collect global agents: {e}")

    result = sync_entries(entries, dry_run=dry_run)
    if dry_run:
        console.print("[yellow]Dry run enabled; no files were written.[/]")
    _print_sync_result(result)
    console.print(
        "\n[green]Done.[/] Commit the vault to persist:\n"
        "  cd ~/vault && git add -A && git commit && git push"
    )
    if result.has_errors:
        raise typer.Exit(1)


def _print_sync_result(result: SyncResult) -> None:
    table = Table()
    table.add_column("Name")
    table.add_column("Kind")
    table.add_column("Status")
    for entry in result.written:
        table.add_row(entry.name, entry.kind, "written")
    for entry in result.skipped:
        table.add_row(entry.name, entry.kind, "skipped")
    for entry, error_msg in result.errors:
        table.add_row(entry.name, entry.kind, f"error: {error_msg}")
    console.print(table)
    console.print(result.summary_line)


@app.command()
def status(
    project: str | None = typer.Argument(None, help="Project name (optional)"),
) -> None:
    """Show sync status without writing."""
    settings = get_settings()
    try:
        ensure_vault_exists(settings)
    except VaultNotFoundError as e:
        console.print(f"[red]{e}[/]")
        raise typer.Exit(1)

    if project is None:
        projects_dir = settings.vault_path / "projects"
        if not projects_dir.exists():
            console.print("[yellow]No projects found[/]")
            return
        project_names = [p.name for p in projects_dir.iterdir() if p.is_dir()]
        all_entries: list[tuple[str, SyncEntry]] = []
        for proj_name in project_names:
            try:
                manifest = parse_manifest(projects_dir / proj_name / "AGENTS.md")
                entries = collect_entries(manifest, settings)
                all_entries.extend([(proj_name, e) for e in entries])
            except PiAgentSyncError as e:
                console.print(f"[red]Error loading project {proj_name}:[/] {e}")
        _display_status(all_entries)
    else:
        manifest_path = settings.vault_path / "projects" / project / "AGENTS.md"
        try:
            manifest = parse_manifest(manifest_path)
        except ManifestNotFoundError:
            console.print(f"[red]Manifest not found for project:[/] {project}")
            raise typer.Exit(1)
        except ManifestParseError as e:
            console.print(f"[red]Failed to parse manifest:[/] {e}")
            raise typer.Exit(1)
        entries = collect_entries(manifest, settings)
        _display_status([(project, e) for e in entries])


def _display_status(entries_with_project: list[tuple[str, SyncEntry]]) -> None:
    table = Table()
    table.add_column("Project")
    table.add_column("Name")
    table.add_column("Kind")
    table.add_column("Local")
    table.add_column("Vault")
    table.add_column("State")
    for proj, entry in entries_with_project:
        # Determine state and local presence
        dest = entry.destination
        if dest.exists():
            try:
                with open(entry.source, "rb") as f:
                    src_hash = hashlib.sha256(f.read()).hexdigest()
                with open(dest, "rb") as f:
                    dst_hash = hashlib.sha256(f.read()).hexdigest()
                if src_hash == dst_hash:
                    state = "in sync"
                else:
                    state = "differs"
                local_desc = "present"
            except OSError as e:
                state = f"error: {e}"
                local_desc = "present?"
        else:
            state = "needs pull"
            local_desc = "missing"
        vault_desc = "present"
        table.add_row(proj, entry.name, entry.kind, local_desc, vault_desc, state)
    console.print(table)


@app.command()
def init(
    project: str = typer.Argument(..., help="Project slug"),
    workspace: Path = typer.Option(
        ..., "--workspace", "-w", help="Workspace directory"
    ),
    notion_board_id: str | None = typer.Option(
        None, "--notion-board-id", help="Notion board ID"
    ),
    notion_project_filter: str | None = typer.Option(
        None,
        "--notion-project-filter",
        help="Notion project filter (defaults to project slug)",
    ),
) -> None:
    """Scaffold a new project in the vault."""
    # Validate project slug early using ProjectManifest
    try:
        manifest = ProjectManifest(
            project=project,
            workspace=workspace,
            notion_board_id=notion_board_id,
            notion_project_filter=notion_project_filter or project,
        )
    except ValidationError as e:
        console.print(f"[red]Invalid project slug:[/] {e}")
        raise typer.Exit(1)

    settings = get_settings()
    try:
        ensure_vault_exists(settings)
    except VaultNotFoundError as e:
        console.print(f"[red]{e}[/]")
        raise typer.Exit(1)

    project_dir = settings.vault_path / "projects" / project
    if project_dir.exists():
        console.print(f"[red]Project directory already exists:[/] {project_dir}")
        raise typer.Exit(1)

    try:
        project_dir.mkdir(parents=True, exist_ok=False)
        (project_dir / "agents").mkdir()
        (project_dir / "skills").mkdir()
        (project_dir / "context.md").write_text("")
        (project_dir / "decisions.md").write_text("")
    except OSError as e:
        console.print(f"[red]Failed to create project directories:[/] {e}")
        raise typer.Exit(1)

    # Build AGENTS.md content
    frontmatter = [
        "---",
        f"project: {manifest.project}",
        f"workspace: {workspace}",
    ]
    if manifest.notion_board_id:
        frontmatter.append(f"notion_board_id: {manifest.notion_board_id}")
    if manifest.notion_project_filter:
        frontmatter.append(f"notion_project_filter: {manifest.notion_project_filter}")
    frontmatter.append("---")
    frontmatter_body = "\n".join(frontmatter)

    body = f"""# {project} — agent routing

## Stack

_Fill in the tech stack._

## Agent routing

| Task | Agent |
|------|-------|
| _example_ | _example-agent_ |
"""
    agents_md_content = frontmatter_body + "\n\n" + body
    try:
        (project_dir / "AGENTS.md").write_text(agents_md_content)
        # Add .gitkeep files
        (project_dir / "agents" / ".gitkeep").write_text("")
        (project_dir / "skills" / ".gitkeep").write_text("")
    except OSError as e:
        console.print(f"[red]Failed to write manifest files:[/] {e}")
        raise typer.Exit(1)

    console.print(f"[green]Project initialized:[/] {project}")
    console.print(f"Next step: piagentsync pull {project}")


def merge_opencode_json(settings: Settings, force: bool) -> str:
    """Merge MCP configuration into existing opencode.json.

    Returns:
        "created"  – file did not exist, wrote full default
        "merged"   – file existed, MCP block was added/updated
        "skipped"  – file existed and MCP block already correct (no write)
        "error:<msg>" – failed to read/write
    """
    config_path = settings.global_opencode_path / "opencode.json"
    default_mcp: dict[str, dict[str, object]] = {
        "mcp": {
            "notion": {
                "type": "remote",
                "url": "https://mcp.notion.com/mcp",
                "enabled": True,
            },
            "obsidian": {
                "type": "local",
                "command": ["sh", "-c", "npx @bitbonsai/mcpvault@latest $HOME/vault"],
                "enabled": True,
            },
        },
        "tools": {
            "notion_*": False,
            "obsidian_*": False,
        },
    }

    try:
        if not config_path.exists():
            config_path.parent.mkdir(parents=True, exist_ok=True)
            with open(config_path, "w") as f:
                json.dump(default_mcp, f, indent=2)
            return "created"

        # Read existing config
        with open(config_path, "r") as f:
            config = json.load(f)

        # Check if MCP+tools already match defaults
        mcp_dict = config.get("mcp", {})
        assert isinstance(mcp_dict, dict)
        tools_dict = config.get("tools", {})
        assert isinstance(tools_dict, dict)

        mcp_notion = mcp_dict.get("notion")
        mcp_obsidian = mcp_dict.get("obsidian")
        tools_notion = tools_dict.get("notion_*")
        tools_obsidian = tools_dict.get("obsidian_*")

        mcp_correct = (
            mcp_notion == default_mcp["mcp"]["notion"]
            and mcp_obsidian == default_mcp["mcp"]["obsidian"]
            and tools_notion == default_mcp["tools"]["notion_*"]
            and tools_obsidian == default_mcp["tools"]["obsidian_*"]
        )
        if mcp_correct and not force:
            return "skipped"

        # Merge: ensure mcp and tools dicts exist, then update
        if "mcp" not in config:
            config["mcp"] = {}
        config["mcp"].update(default_mcp["mcp"])
        if "tools" not in config:
            config["tools"] = {}
        config["tools"].update(default_mcp["tools"])

        # Write back
        with open(config_path, "w") as f:
            json.dump(config, f, indent=2)
        return "merged"
    except (OSError, json.JSONDecodeError) as e:
        return f"error:{e}"


@app.command()
def bootstrap(
    force: bool = typer.Option(
        False, "--force", help="Overwrite MCP configuration if present"
    ),
) -> None:
    """Bootstrap machine from vault (install global config and agents)."""
    settings = get_settings()

    # Step 1: ensure vault exists
    try:
        ensure_vault_exists(settings)
    except VaultNotFoundError as e:
        console.print(f"[red]{e}[/]")
        raise typer.Exit(1)

    # Step 2: merge/write opencode.json
    opencode_config_path = settings.global_opencode_path / "opencode.json"
    status = merge_opencode_json(settings, force)
    if status == "created":
        console.print(f"[green]Created[/] {opencode_config_path}")
    elif status == "merged":
        console.print(
            f"[green]Updated[/] {opencode_config_path} (MCP configuration merged)"
        )
    elif status == "skipped":
        console.print("[dim]opencode.json already has MCP configured[/]")
    else:
        console.print(f"[red]Failed to update opencode.json:[/] {status}")
        raise typer.Exit(1)

    # Step 3: run opencode mcp auth notion (only if MCP was added/updated)
    if status in ("created", "merged"):
        console.print("\n[bold]Next:[/] Running Notion MCP authentication...")
        console.print(
            "This will open a browser window. Follow the prompts to authenticate."
        )
        try:
            result = subprocess.run(
                ["opencode", "mcp", "auth", "notion"],
                check=False,
            )
            if result.returncode != 0:
                console.print(
                    "[yellow]Warning:[/] auth command exited with non-zero status. You may need to run 'opencode mcp auth notion' manually."
                )
        except FileNotFoundError:
            console.print(
                "[yellow]Warning:[/] 'opencode' command not found on PATH. Please install OpenCode and run 'opencode mcp auth notion' manually."
            )
    else:
        console.print("\n[dim]Skipping auth (MCP already configured).[/]")

    # Step 4: install global agent chief-pm
    console.print("\n[bold]Installing global agent[/] chief-pm...")
    src_chief = settings.vault_path / "agents" / "global" / "chief-pm.md"
    dst_chief = settings.global_opencode_path / "agents" / "chief-pm.md"
    status = copy_file_sync(src_chief, dst_chief)
    if status == "copied":
        console.print(f"[green]Copied[/] chief-pm to {dst_chief}")
    elif status == "updated":
        console.print(f"[green]Updated[/] chief-pm at {dst_chief}")
    elif status == "skipped":
        console.print("[dim]chief-pm already in sync[/]")
    elif status == "missing":
        console.print(
            "[yellow]Warning:[/] vault/agents/global/chief-pm.md not found, skipping"
        )
    else:
        console.print(f"[yellow]Warning:[/] failed to copy chief-pm: {status}")

    console.print("\n[green]Bootstrap complete![/]")
