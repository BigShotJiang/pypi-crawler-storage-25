"""Core synchronization logic."""

import hashlib
from pathlib import Path

from .config import Settings
from .models import EntryKind, ProjectManifest, SyncEntry, SyncResult


def collect_entries(manifest: ProjectManifest, settings: Settings) -> list[SyncEntry]:
    """Collect all syncable entries for a project."""
    vault = settings.vault_path
    project_dir = vault / "projects" / manifest.project
    entries: list[SyncEntry] = []

    # Agents
    agents_dir = project_dir / "agents"
    if agents_dir.is_dir():
        for file in agents_dir.iterdir():
            if file.is_file() and file.suffix.lower() == ".md":
                dest = manifest.workspace / ".opencode" / "agents" / file.name
                entries.append(
                    SyncEntry(
                        name=file.stem,
                        source=file.resolve(),
                        destination=dest,
                        kind=EntryKind.AGENT,
                    )
                )

    # Skills
    skills_dir = project_dir / "skills"
    if skills_dir.is_dir():
        for file in skills_dir.iterdir():
            if file.is_file() and file.suffix.lower() == ".md":
                dest = manifest.workspace / ".opencode" / "skills" / file.name
                entries.append(
                    SyncEntry(
                        name=file.stem,
                        source=file.resolve(),
                        destination=dest,
                        kind=EntryKind.SKILL,
                    )
                )

    # AGENTS.md (context file)
    agents_md = project_dir / "AGENTS.md"
    if agents_md.is_file():
        dest = manifest.workspace / ".opencode" / "AGENTS.md"
        entries.append(
            SyncEntry(
                name=agents_md.stem,
                source=agents_md.resolve(),
                destination=dest,
                kind=EntryKind.CONTEXT_FILE,
            )
        )

    return entries


def collect_global_entries(settings: Settings) -> list[SyncEntry]:
    """Collect all global agent entries."""
    vault = settings.vault_path
    global_dir = vault / "agents" / "global"
    entries: list[SyncEntry] = []
    if global_dir.is_dir():
        dest_dir = settings.global_opencode_path / "agents"
        for file in global_dir.iterdir():
            if file.is_file() and file.suffix.lower() == ".md":
                dest = dest_dir / file.name
                entries.append(
                    SyncEntry(
                        name=file.stem,
                        source=file.resolve(),
                        destination=dest,
                        kind=EntryKind.AGENT,
                    )
                )
    return entries


def collect_push_entries(
    manifest: ProjectManifest, settings: Settings
) -> list[SyncEntry]:
    """Collect all syncable entries to push from workspace to vault.

    Inverse of collect_entries: workspace .opencode/ → vault/projects/{project}/.

    Args:
        manifest: Project manifest with workspace path.
        settings: Settings with vault path.

    Returns:
        List of SyncEntry objects with source=workspace, destination=vault.
    """
    vault = settings.vault_path
    workspace = manifest.workspace
    entries: list[SyncEntry] = []

    # Agents: workspace/.opencode/agents/*.md → vault/projects/{project}/agents/
    agents_src_dir = workspace / ".opencode" / "agents"
    if agents_src_dir.is_dir():
        for file in agents_src_dir.iterdir():
            if file.is_file() and file.suffix.lower() == ".md":
                dest = vault / "projects" / manifest.project / "agents" / file.name
                entries.append(
                    SyncEntry(
                        name=file.stem,
                        source=file.resolve(),
                        destination=dest,
                        kind=EntryKind.AGENT,
                    )
                )

    # Skills: workspace/.opencode/skills/*.md → vault/projects/{project}/skills/
    skills_src_dir = workspace / ".opencode" / "skills"
    if skills_src_dir.is_dir():
        for file in skills_src_dir.iterdir():
            if file.is_file() and file.suffix.lower() == ".md":
                dest = vault / "projects" / manifest.project / "skills" / file.name
                entries.append(
                    SyncEntry(
                        name=file.stem,
                        source=file.resolve(),
                        destination=dest,
                        kind=EntryKind.SKILL,
                    )
                )

    # AGENTS.md: workspace/.opencode/AGENTS.md → vault/projects/{project}/AGENTS.md
    agents_md_src = workspace / ".opencode" / "AGENTS.md"
    if agents_md_src.is_file():
        dest = vault / "projects" / manifest.project / "AGENTS.md"
        entries.append(
            SyncEntry(
                name=agents_md_src.stem,
                source=agents_md_src.resolve(),
                destination=dest,
                kind=EntryKind.CONTEXT_FILE,
            )
        )

    return entries


def collect_push_global_entries(settings: Settings) -> list[SyncEntry]:
    """Collect global agents to push from workspace to vault.

    Inverse of collect_global_entries:
    {global_opencode_path}/agents/*.md → vault/agents/global/

    Args:
        settings: Settings with vault path and global_opencode_path.

    Returns:
        List of SyncEntry objects with source=global workspace, destination=vault.
    """
    vault = settings.vault_path
    global_src_dir = settings.global_opencode_path / "agents"
    entries: list[SyncEntry] = []

    if global_src_dir.is_dir():
        dest_dir = vault / "agents" / "global"
        for file in global_src_dir.iterdir():
            if file.is_file() and file.suffix.lower() == ".md":
                dest = dest_dir / file.name
                entries.append(
                    SyncEntry(
                        name=file.stem,
                        source=file.resolve(),
                        destination=dest,
                        kind=EntryKind.AGENT,
                    )
                )

    return entries


def sync_entries(entries: list[SyncEntry], dry_run: bool = False) -> SyncResult:
    """Synchronize entries from source to destination."""
    written: list[SyncEntry] = []
    skipped: list[SyncEntry] = []
    errors: list[tuple[SyncEntry, str]] = []

    for entry in entries:
        try:
            if not entry.source.exists():
                raise FileNotFoundError(f"Source file not found: {entry.source}")

            with open(entry.source, "rb") as f:
                src_content = f.read()
            src_hash = hashlib.sha256(src_content).hexdigest()

            dest = entry.destination
            if dest.exists():
                with open(dest, "rb") as f:
                    dest_content = f.read()
                dest_hash = hashlib.sha256(dest_content).hexdigest()
                if src_hash == dest_hash:
                    skipped.append(entry)
                    continue

            if not dry_run:
                dest.parent.mkdir(parents=True, exist_ok=True)
                with open(dest, "wb") as f:
                    f.write(src_content)

            written.append(entry)

        except OSError as e:
            errors.append((entry, str(e)))

    return SyncResult(written=written, skipped=skipped, errors=errors)


def copy_file_sync(src: Path, dst: Path) -> str:
    """Copy a single file with hash-based deduplication.

    Returns:
        "copied" – file did not exist, written now
        "updated" – file existed, content differed, overwritten
        "skipped" – file existed, content identical
        "missing" – source file does not exist
        "error:<msg>" – an OSError occurred
    """
    try:
        if not src.exists():
            return "missing"
        with open(src, "rb") as f:
            src_bytes = f.read()
        src_hash = hashlib.sha256(src_bytes).hexdigest()
        dst_parent = dst.parent
        if not dst_parent.exists():
            dst_parent.mkdir(parents=True, exist_ok=True)
        if dst.exists():
            with open(dst, "rb") as f:
                dst_hash = hashlib.sha256(f.read()).hexdigest()
            if src_hash == dst_hash:
                return "skipped"
            dst.write_bytes(src_bytes)
            return "updated"
        else:
            dst.write_bytes(src_bytes)
            return "copied"
    except OSError as e:
        return f"error:{e}"
