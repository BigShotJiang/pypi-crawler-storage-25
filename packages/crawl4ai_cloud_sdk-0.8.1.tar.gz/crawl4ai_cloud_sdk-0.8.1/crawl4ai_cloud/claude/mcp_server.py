"""MCP server for Crawl4AI Claude Code plugin."""
from __future__ import annotations

import json
from typing import List, Optional

from mcp.server.fastmcp import FastMCP

from . import core

mcp = FastMCP("crawl4ai")


def _json(data: dict) -> str:
    return json.dumps(data, indent=2, default=str)


@mcp.tool()
async def crawl(
    url: str,
    deep_crawl: bool = False,
    strategy: str = "bfs",
    max_depth: int = 2,
    max_pages: int = 50,
    include_patterns: Optional[List[str]] = None,
    exclude_patterns: Optional[List[str]] = None,
    css_selector: Optional[str] = None,
    word_count_threshold: int = 200,
    bypass_cache: bool = False,
    crawler_config: Optional[dict] = None,
    browser_config: Optional[dict] = None,
) -> str:
    """Crawl a web page and return its content as markdown.

    For a single page, returns markdown text, metadata, and links.
    Set deep_crawl=True for multi-page crawling -- returns a job_id immediately.

    For full /v1/crawl power, pass crawler_config and/or browser_config dicts:
    - crawler_config: {"extraction_strategy": {...}, "js_code": "...", "wait_for": "...", "screenshot": true}
    - browser_config: {"headers": {...}, "cookies": [...], "profile_id": "..."}
    """
    result = await core.crawl(
        url, deep_crawl=deep_crawl, strategy=strategy,
        max_depth=max_depth, max_pages=max_pages,
        include_patterns=include_patterns, exclude_patterns=exclude_patterns,
        css_selector=css_selector, word_count_threshold=word_count_threshold,
        bypass_cache=bypass_cache,
        crawler_config=crawler_config, browser_config=browser_config,
    )
    return _json(result)


@mcp.tool()
async def extract(
    url: str,
    query: Optional[str] = None,
    schema: Optional[dict] = None,
    method: str = "auto",
) -> str:
    """Extract structured data from a web page.

    Three modes:
    - AUTO (default): system picks CSS Schema or LLM based on page structure
    - query only: "extract all products with title and price" (uses LLM)
    - schema: provide a CSS schema with name, baseSelector, fields[] (deterministic, no LLM)

    Returns extracted data as a list of JSON objects.
    """
    result = await core.extract(url, query=query, schema=schema, method=method)
    return _json(result)


@mcp.tool()
async def map(
    url: str,
    source: str = "sitemap",
    pattern: str = "*",
    max_urls: int = 100,
    query: Optional[str] = None,
    score_threshold: Optional[float] = None,
) -> str:
    """Discover URLs on a domain via sitemap, Common Crawl, or both.

    Sources: "sitemap", "cc" (Common Crawl), "sitemap+cc".
    Use query for BM25 relevance filtering.
    """
    result = await core.map_urls(
        url, source=source, pattern=pattern,
        max_urls=max_urls, query=query, score_threshold=score_threshold,
    )
    return _json(result)


@mcp.tool()
async def screenshot(
    url: str,
    wait_for: Optional[str] = None,
    css_selector: Optional[str] = None,
    full_page: bool = True,
) -> str:
    """Take a screenshot of a web page. Returns base64-encoded PNG.

    Use wait_for to wait for a CSS selector or JS expression before capture.
    Use css_selector to screenshot a specific element.
    """
    result = await core.screenshot(
        url, wait_for=wait_for, css_selector=css_selector, full_page=full_page,
    )
    return _json(result)


@mcp.tool()
async def schema(
    query: str,
    url: Optional[str] = None,
    html: Optional[str] = None,
    schema_type: str = "css",
) -> str:
    """Generate a CSS/XPath extraction schema from a page using AI.

    Provide either a url or raw html, plus a natural language query
    describing what data to extract. Returns a reusable schema for the extract tool.
    """
    result = await core.schema(query=query, url=url, html=html, schema_type=schema_type)
    return _json(result)


@mcp.tool()
async def job_status(job_id: str) -> str:
    """Check the status of a deep crawl job.

    Returns current status, progress, and download_url when the job is complete.
    Use the download_url with the fetch tool to retrieve results.
    For scan jobs (scan_*), may return a crawl_job_id to track next.
    """
    result = await core.job_status(job_id)
    return _json(result)


@mcp.tool()
async def fetch(download_url: str, save_to: Optional[str] = None) -> str:
    """Download and parse crawl results from a presigned S3 URL.

    Use this after a deep crawl job completes and job_status returns a download_url.
    Downloads the results ZIP, parses each page, and returns structured data.

    IMPORTANT: Always set save_to to a file path (e.g. "/tmp/crawl_results.json")
    for deep crawls. Results are often too large to return inline.
    When save_to is set, full results are written to the file and a summary is returned.
    """
    result = await core.fetch_results(download_url)
    if not result.get("success") or not save_to:
        return _json(result)

    # Save full results to file, return summary
    import os
    os.makedirs(os.path.dirname(save_to) if os.path.dirname(save_to) else ".", exist_ok=True)
    with open(save_to, "w") as f:
        json.dump(result["data"], f, indent=2, default=str)

    pages = result["data"].get("results", [])
    summary = {
        "success": True,
        "data": {
            "pages_crawled": result["data"].get("pages_crawled", len(pages)),
            "saved_to": save_to,
            "pages": [
                {
                    "url": p.get("url", ""),
                    "markdown_length": len(p.get("markdown", "") or ""),
                    "status_code": p.get("status_code"),
                }
                for p in pages
            ],
            "message": f"Full results saved to {save_to}. Read the file to access page content.",
        },
    }
    return _json(summary)


@mcp.tool()
async def profile_list() -> str:
    """List available browser profiles.

    In cloud mode, profiles are managed via the dashboard/CLI.
    In local mode, lists profiles from ~/.crawl4ai/profiles/.
    """
    result = await core.profile_list()
    return _json(result)


@mcp.tool()
async def profile_create(
    profile_name: Optional[str] = None,
) -> str:
    """Create a new browser profile for authenticated crawling.

    Opens a browser window to log in to sites. The session is saved
    and can be reused in future crawls for auth-gated content.
    """
    result = await core.profile_create(profile_name=profile_name)
    return _json(result)


def main():
    mcp.run(transport="stdio")


if __name__ == "__main__":
    main()
