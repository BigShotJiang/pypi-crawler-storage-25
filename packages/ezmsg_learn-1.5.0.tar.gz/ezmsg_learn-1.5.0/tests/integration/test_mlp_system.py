import os
import tempfile
from pathlib import Path

import ezmsg.core as ez
from ezmsg.util.messagecodec import message_log
from ezmsg.util.messagelogger import MessageLogger, MessageLoggerSettings
from ezmsg.util.messages.axisarray import AxisArray
from ezmsg.util.terminate import TerminateOnTotal, TerminateOnTotalSettings

from ezmsg.learn.process.torch import TorchModelUnit
from tests.integration.conftest import NoiseSrc, NoiseSrcSettings


def test_torch_model_unit_system():
    fs = 10.0
    block_size = 4
    duration = 2.0  # seconds
    input_size = 3
    output_size = 2

    test_filename = Path(tempfile.gettempdir())
    test_filename = test_filename / Path("test_mlp_system.txt")
    with open(test_filename, "w"):
        pass
    ez.logger.info(f"Logging to {test_filename}")

    comps = {
        "SRC": NoiseSrc(NoiseSrcSettings(fs=fs, n_ch=input_size, n_time=block_size, dispatch_rate=duration)),
        "MODEL": TorchModelUnit(
            model_class="ezmsg.learn.model.mlp.MLP",
            model_kwargs={
                "input_size": input_size,
                "hidden_size": [5, output_size],
            },
            device="cpu",
        ),
        "LOG": MessageLogger(MessageLoggerSettings(output=test_filename)),
        "TERM": TerminateOnTotal(TerminateOnTotalSettings(total=int(duration * fs / block_size))),
    }

    conns = (
        (comps["SRC"].OUTPUT_SIGNAL, comps["MODEL"].INPUT_SIGNAL),
        (comps["MODEL"].OUTPUT_SIGNAL, comps["LOG"].INPUT_MESSAGE),
        (comps["LOG"].OUTPUT_MESSAGE, comps["TERM"].INPUT_MESSAGE),
    )

    ez.run(components=comps, connections=conns)

    # Read from message log
    messages: list[AxisArray] = [_ for _ in message_log(test_filename)]
    os.remove(test_filename)

    # Check basic structure
    assert all(msg.data.shape[-1] == output_size for msg in messages)
    assert all("time" in msg.dims and "ch" in msg.dims for msg in messages)
    assert all("ch" in msg.axes for msg in messages)
    assert messages[0].axes["ch"].data.shape[0] == output_size
