# Status

**v0.0.1 - Planning stage.** This package is under active design.
