"""git-recall: Git-native, Merkle-rooted multi-agent shared memory with GraphRAG."""

__version__ = "0.0.1"
