"""Shared Rich-powered UI helpers for CLI commands.

Central place for the Console singletons, color palette, banner, spinners,
and progress bars. Respects ``--no-color`` and the ``NO_COLOR`` env var,
and falls back to plain text when stdout isn't a TTY.
"""

from __future__ import annotations

from contextlib import contextmanager
from typing import Iterator

from rich.console import Console
from rich.progress import (
    BarColumn,
    MofNCompleteColumn,
    Progress,
    SpinnerColumn,
    TextColumn,
    TimeElapsedColumn,
)
from rich.theme import Theme

_THEME = Theme(
    {
        "brand": "bold cyan",
        "success": "bold green",
        "warn": "yellow",
        "error": "bold red",
        "dim": "dim",
        "heading": "bold cyan",
        "muted": "grey62",
    }
)

_BANNER = r"""
       _
   ___| |_   _
  / __| | | | |
 | (__| | |_| |
  \___|_|\__,_|
"""

console: Console = Console(theme=_THEME)
err_console: Console = Console(theme=_THEME, stderr=True)


def configure(*, no_color: bool) -> None:
    """Reconfigure the shared consoles. Call once from the root command."""
    global console, err_console
    console = Console(theme=_THEME, no_color=no_color)
    err_console = Console(theme=_THEME, stderr=True, no_color=no_color)


def banner(tagline: str | None = None) -> None:
    """Print the clu ASCII banner (skipped when not a TTY)."""
    if not console.is_terminal:
        return
    console.print(_BANNER, style="brand", highlight=False)
    if tagline:
        console.print(f"  {tagline}", style="muted", highlight=False)
    console.print()


def success(message: str) -> None:
    console.print(f"[success]✓[/success] {message}", highlight=False)


def warn(message: str) -> None:
    err_console.print(f"[warn]![/warn] {message}", highlight=False)


def error(message: str) -> None:
    err_console.print(f"[error]✗[/error] {message}", highlight=False)


def info(message: str) -> None:
    console.print(message, highlight=False)


def dim(message: str) -> None:
    console.print(message, style="dim", highlight=False)


def heading(message: str) -> None:
    console.print(message, style="heading", highlight=False)


@contextmanager
def spinner(label: str) -> Iterator[None]:
    """Context manager showing a spinner during a blocking operation.

    Falls back to a single status line when stdout isn't a TTY.
    """
    if not console.is_terminal:
        console.print(label, highlight=False)
        yield
        return
    with console.status(label, spinner="dots"):
        yield


def make_progress() -> Progress:
    """Build a Progress instance tuned for flush-style phase tracking."""
    return Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        BarColumn(),
        MofNCompleteColumn(),
        TimeElapsedColumn(),
        console=console,
        transient=False,
    )


def confetti(message: str) -> None:
    """Small celebratory flourish on successful completions."""
    if console.is_terminal:
        console.print(f"[success]✨ {message} ✨[/success]", highlight=False)
    else:
        console.print(message, highlight=False)
