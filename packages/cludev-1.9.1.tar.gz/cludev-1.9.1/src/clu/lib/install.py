"""Installation services."""


import os
import sys
from dataclasses import dataclass
from typing import Iterator

from clu import config as cfg_mod
from clu.adapter import detect_adapters, get_adapter


@dataclass(frozen=True)
class ConfigReady:
    directory: str


@dataclass(frozen=True)
class AgentsDetected:
    agents: list[str]


@dataclass(frozen=True)
class InstallingHooks:
    agent: str


@dataclass(frozen=True)
class Installed:
    agent: str


InstallEvent = ConfigReady | AgentsDetected | InstallingHooks | Installed


def stream_install(*, global_: bool, agent: str) -> Iterator[InstallEvent]:
    """Initialize config and install agent hooks, yielding step events."""
    directory = cfg_mod.ensure_dir()
    config = cfg_mod.load()
    cfg_mod.save(cfg=config)
    yield ConfigReady(directory=str(directory))

    detected = detect_adapters()
    yield AgentsDetected(agents=[a.name() for a in detected])

    selected_agent = agent
    if not selected_agent:
        if not detected:
            raise RuntimeError("no agents detected and --agent not specified")
        if len(detected) > 1:
            raise RuntimeError("multiple agents detected; pass --agent explicitly")
        selected_agent = detected[0].name()

    yield InstallingHooks(agent=selected_agent)

    adapter = get_adapter(selected_agent)
    adapter.install_hooks(
        project_dir=os.getcwd(),
        global_=global_,
        clu_binary=os.path.abspath(sys.argv[0]),
    )

    yield Installed(agent=selected_agent)
