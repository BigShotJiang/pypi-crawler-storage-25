"""Session flushing service."""


from dataclasses import dataclass
from typing import Iterator

from clu.api import SyncClient
from clu.store import Store


@dataclass(frozen=True)
class NothingToFlush:
    pass


@dataclass(frozen=True)
class DryRun:
    session_count: int


@dataclass(frozen=True)
class PhaseStart:
    total: int


@dataclass(frozen=True)
class SessionFlushed:
    session_id: str


@dataclass(frozen=True)
class Done:
    flushed: int


FlushEvent = NothingToFlush | DryRun | PhaseStart | SessionFlushed | Done


def stream_flush(*, limit: int, dry_run: bool) -> Iterator[FlushEvent]:
    """Flush dirty sessions and their messages, yielding progress events.

    For each dirty session, session metadata is upserted via the
    ``/sessions`` endpoint, then its messages are pushed in batches to
    the ``/session-messages`` endpoint.
    """
    db = Store.open()
    with db:
        dirty_sessions = db.sessions.list_dirty(limit=limit)

        if not dirty_sessions:
            yield NothingToFlush()
            return

        if dry_run:
            yield DryRun(session_count=len(dirty_sessions))
            return

        yield PhaseStart(total=len(dirty_sessions))

        sync_client = SyncClient()
        flushed = 0

        for session in dirty_sessions:
            messages = db.messages.list_for_session(
                session_id=session.id,
            )
            if not messages:
                yield SessionFlushed(session_id=session.id)
                continue

            sync_client.ingest_session(
                session=session,
                messages=messages,
            )
            flushed += 1
            yield SessionFlushed(session_id=session.id)

        session_ids = [s.id for s in dirty_sessions]
        db.sessions.mark_clean(session_ids=session_ids)
        db.messages.mark_clean_for_sessions(session_ids=session_ids)

        yield Done(flushed=flushed)
