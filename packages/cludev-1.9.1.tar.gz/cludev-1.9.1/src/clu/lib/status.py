"""Status reporting services."""


from dataclasses import dataclass

from clu.models.session import Session
from clu.store import Store


@dataclass(frozen=True)
class StatusReport:
    sessions: list[Session]
    pending_sessions: int
    pending_messages: int


def get_status() -> StatusReport:
    """Read install state, active sessions, and pending work from SQLite."""
    db = Store.open()
    with db:
        sessions = db.sessions.active_all()
        pending_sessions = db.sessions.dirty_count()
        pending_messages = db.messages.dirty_count()
    return StatusReport(
        sessions=sessions,
        pending_sessions=pending_sessions,
        pending_messages=pending_messages,
    )
