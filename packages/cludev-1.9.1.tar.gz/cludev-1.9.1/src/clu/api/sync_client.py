"""Backend sync client for session ingestion."""


from clu.api.base_client import BaseApiClient
from clu.models.session import Session
from clu.models.session_message import SessionMessage

# Bulk uploads larger than this are split into multiple requests so a
# single edge-function call stays well under the gateway body limit.
DEFAULT_MESSAGE_BATCH_SIZE = 250


class SyncClient(BaseApiClient):
    """Client for syncing local session data to the backend."""

    def upsert_session(self, *, session: Session) -> str:
        """POST session metadata to the ``sessions`` edge function.

        Returns the backend ``session_id`` (UUID) for the upserted row.
        """
        payload = {
            "external_session_id": session.id,
            "agent": session.agent,
            "path": session.path,
            "is_git_repo": session.is_git_repo,
            "git_remote_url": session.git_remote_url,
            "start_time": session.start_time,
            "end_time": session.end_time,
            "active": session.active,
        }

        response = self.send_authenticated_request(
            method="POST",
            url=f"{self._base_url}/functions/v1/sessions",
            json_body=payload,
        )
        if response.status_code not in (200, 201, 204):
            raise RuntimeError(
                f"session upsert returned {response.status_code}: {response.text}",
            )
        return str(response.json().get("session_id", ""))

    def upload_session_messages(
        self,
        *,
        external_session_id: str,
        messages: list[SessionMessage],
        batch_size: int = DEFAULT_MESSAGE_BATCH_SIZE,
    ) -> None:
        """POST messages to the ``session-messages`` bulk endpoint.

        Splits ``messages`` into chunks of ``batch_size`` so each request
        body stays bounded.
        """
        if not messages:
            return
        for start in range(0, len(messages), batch_size):
            chunk = messages[start : start + batch_size]
            payload = {
                "external_session_id": external_session_id,
                "messages": [
                    msg.model_dump(
                        mode="json",
                        exclude={"session_id", "dirty"},
                    )
                    for msg in chunk
                ],
            }
            response = self.send_authenticated_request(
                method="POST",
                url=f"{self._base_url}/functions/v1/session-messages",
                json_body=payload,
            )
            if response.status_code not in (200, 201, 204):
                raise RuntimeError(
                    f"session-messages upload returned {response.status_code}: {response.text}",
                )

    def ingest_session(
        self,
        *,
        session: Session,
        messages: list[SessionMessage],
    ) -> None:
        """Upsert the session, then bulk-upload its messages.

        Two separate edge-function calls back the single session sync.
        """
        self.upsert_session(session=session)
        self.upload_session_messages(
            external_session_id=session.id,
            messages=messages,
        )
