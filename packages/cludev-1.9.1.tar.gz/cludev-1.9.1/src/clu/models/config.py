"""Configuration models for ``~/.clu/config.toml``."""


from pydantic import BaseModel, Field


class OAuthSession(BaseModel):
    """OAuth session tokens persisted after ``clu auth login``.

    Attributes:
        access_token: Short-lived JWT for API requests.
        refresh_token: Long-lived token used to obtain new access tokens.
        token_type: Token type string, usually ``bearer``.
        expires_at: Unix epoch when the access token expires.
        user_id: Supabase Auth user UUID.
        user_email: Email address for the authenticated user.
    """

    access_token: str = ""
    refresh_token: str = ""
    token_type: str = ""
    expires_at: int = 0
    user_id: str = ""
    user_email: str = ""


class AuthConfig(BaseModel):
    """Authentication settings for the CLI.

    Attributes:
        supabase_url: Base URL of the Supabase project.
        supabase_anon_key: Public anonymous API key.
        github_app_install_url: Browser URL where the user can install the GitHub App.
        session: Active OAuth session data.
    """

    supabase_url: str = ""
    supabase_anon_key: str = ""
    github_app_install_url: str = ""
    session: OAuthSession = OAuthSession()


class OrgConfig(BaseModel):
    """Organisation assignment for the authenticated user.

    Attributes:
        id: Backend UUID of the organisation.
        name: Human-readable organisation name.
        kind: Workspace kind (`organization` or `personal`).
    """

    id: str = ""
    name: str = ""
    kind: str = ""


class AgentsConfig(BaseModel):
    """Enabled agent adapter settings.

    Attributes:
        enabled: Adapter names that clu should activate.
    """

    enabled: list[str] = Field(default_factory=lambda: ["claude-code"])


class Config(BaseModel):
    """Root configuration for ``~/.clu/config.toml``.

    Attributes:
        auth: Authentication and session settings.
        org: Organisation assignment.
        agents: Agent adapter settings.
    """

    auth: AuthConfig = Field(default_factory=AuthConfig)
    org: OrgConfig = Field(default_factory=OrgConfig)
    agents: AgentsConfig = Field(default_factory=AgentsConfig)
