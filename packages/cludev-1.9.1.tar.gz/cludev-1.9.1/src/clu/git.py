"""Helpers for interacting with git repositories."""


import subprocess


def _run_git(repo_path: str, *args: str) -> str:
    """Execute a git command inside `repo_path` and return stdout."""
    result = subprocess.run(
        ["git", *args],
        cwd=repo_path,
        capture_output=True,
        text=True,
    )
    if result.returncode != 0:
        raise RuntimeError(f"git {' '.join(args)}: {result.stderr.strip()}")
    return result.stdout


def current_branch(*, repo_path: str) -> str:
    """Return the currently checked-out branch name."""
    return _run_git(repo_path, "rev-parse", "--abbrev-ref", "HEAD").strip()


def is_repo(*, path: str) -> bool:
    """Check whether `path` is inside a git working tree."""
    try:
        _run_git(path, "rev-parse", "--is-inside-work-tree")
        return True
    except RuntimeError:
        return False


def repo_root(*, path: str) -> str:
    """Return the absolute path to the repository root."""
    return _run_git(path, "rev-parse", "--show-toplevel").strip()


def remote_url(*, path: str) -> str:
    """Return the `origin` remote URL, or empty string if unavailable."""
    try:
        return _run_git(path, "remote", "get-url", "origin").strip()
    except RuntimeError:
        return ""
