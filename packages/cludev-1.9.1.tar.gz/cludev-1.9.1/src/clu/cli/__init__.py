"""CLI commands for clu, built with Click."""


import click

from clu import __version__, ui


@click.group()
@click.version_option(__version__, prog_name="clu")
@click.option(
    "--no-color",
    is_flag=True,
    default=False,
    help="Disable ANSI colors and styling.",
)
def cli(no_color: bool) -> None:
    """Local session capture and backend sync for AI-assisted development.

    clu captures local agent sessions and transcript messages,
    stores them in SQLite, and syncs them to the backend for later
    correlation with GitHub activity.

    The developer installs clu once. After that, their existing AI agent
    workflow stays untouched — clu works invisibly in the background.
    """
    ui.configure(no_color=no_color)


# Import and register subcommands.
from clu.cli.append import append  # noqa: E402
from clu.cli.auth import auth  # noqa: E402
from clu.cli.flush import flush  # noqa: E402
from clu.cli.install import install  # noqa: E402
from clu.cli.status import status  # noqa: E402

cli.add_command(auth)
cli.add_command(install)
cli.add_command(append)
cli.add_command(flush)
cli.add_command(status)
