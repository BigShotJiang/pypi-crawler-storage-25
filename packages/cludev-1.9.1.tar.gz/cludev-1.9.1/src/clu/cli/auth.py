"""auth login / auth status commands."""


import click

from clu import ui
from clu.lib.auth_login import run_auth_login
from clu.lib.auth_status import get_auth_status


@click.group()
def auth() -> None:
    """Authenticate clu against the configured backend."""


@auth.command()
@click.option("--supabase-url", default="", help="Supabase project URL")
@click.option("--anon-key", default="", help="Supabase anon key")
@click.option("--github-app-install-url", default="", help="GitHub App installation URL")
@click.option("--provider", default="github", help="OAuth provider to use")
@click.option("--listen-addr", default="localhost:3000", help="Local callback address")
@click.option("--no-browser", is_flag=True, help="Print the login URL instead of opening a browser")
def login(
    supabase_url: str,
    anon_key: str,
    github_app_install_url: str,
    provider: str,
    listen_addr: str,
    no_browser: bool,
) -> None:
    """Run a local browser-based OAuth flow and persist the session."""
    ui.banner("Signing you in")

    try:
        result = run_auth_login(
            supabase_url=supabase_url,
            anon_key=anon_key,
            github_app_install_url=github_app_install_url,
            provider=provider,
            listen_addr=listen_addr,
            no_browser=no_browser,
            on_wait=None if no_browser else lambda: ui.spinner("Waiting for browser login…"),
        )
    except RuntimeError as error:
        raise click.ClickException(str(error)) from error

    if no_browser:
        ui.info(f"Starting local login flow at [brand]{result}[/brand]")
        ui.dim(f"Open this URL in your browser:\n{result}")
        return

    ui.confetti(f"Logged in as {result}")


@auth.command()
def status() -> None:
    """Verify the current auth session and print the active user."""
    try:
        auth_status = get_auth_status()
    except RuntimeError as error:
        raise click.ClickException(str(error)) from error
    ui.console.print_json(auth_status.model_dump_json())
