"""flush command — push sessions and messages to the backend."""


import click

from clu import ui
from clu.lib.flush import (
    Done,
    DryRun,
    NothingToFlush,
    PhaseStart,
    SessionFlushed,
    stream_flush,
)


@click.command()
@click.option("--limit", default=500, help="Max sessions/messages to flush per invocation")
@click.option("--dry-run", is_flag=True, help="Show what would be flushed without sending")
def flush(limit: int, dry_run: bool) -> None:
    """Push pending sessions and messages to the backend."""
    try:
        events = stream_flush(limit=limit, dry_run=dry_run)
    except Exception as error:
        raise click.ClickException(f"opening state db: {error}") from error

    progress = None
    task_id = None
    try:
        for event in events:
            if isinstance(event, NothingToFlush):
                ui.dim("No pending sessions or messages to flush.")
                return
            if isinstance(event, DryRun):
                ui.info(f"Would flush [brand]{event.session_count}[/brand] sessions.")
                return
            if isinstance(event, PhaseStart):
                progress = ui.make_progress()
                progress.start()
                task_id = progress.add_task("Uploading sessions", total=event.total)
                continue
            if isinstance(event, SessionFlushed):
                if progress is not None and task_id is not None:
                    progress.update(task_id, advance=1)
                continue
            if isinstance(event, Done):
                if progress is not None:
                    progress.stop()
                    progress = None
                ui.confetti(f"Flushed {event.flushed} sessions")
                return
    finally:
        if progress is not None:
            progress.stop()
