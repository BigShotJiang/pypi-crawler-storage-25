"""install command."""


import click

from clu import ui
from clu.lib.install import (
    AgentsDetected,
    ConfigReady,
    Installed,
    InstallingHooks,
    stream_install,
)


@click.command()
@click.option("--global", "global_", is_flag=True, help="Install hooks in user-level agent config")
@click.option("--agent", default="", help="Agent to install for (e.g. claude-code)")
def install(global_: bool, agent: str) -> None:
    """One-time setup: initialize config and install agent event hooks."""
    ui.banner("Setting up clu")

    try:
        for event in stream_install(global_=global_, agent=agent):
            if isinstance(event, ConfigReady):
                ui.success(f"Config directory ready at [brand]{event.directory}[/brand]")
                continue
            if isinstance(event, AgentsDetected):
                if not event.agents:
                    ui.warn("No supported AI agents detected.")
                else:
                    agents_list = ", ".join(f"[brand]{name}[/brand]" for name in event.agents)
                    ui.success(f"Detected agents: {agents_list}")
                continue
            if isinstance(event, InstallingHooks):
                # Inline spinner-style line; the hook install is fast and synchronous.
                ui.dim(f"Installing {event.agent} event hooks…")
                continue
            if isinstance(event, Installed):
                ui.success(f"{event.agent} event hooks installed.")
                continue
    except RuntimeError as error:
        raise click.ClickException(str(error)) from error

    ui.info("")
    ui.confetti("clu installed successfully")
    ui.dim("Run `clu auth login` to authenticate with the backend.")
