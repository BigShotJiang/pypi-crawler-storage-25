"""status command — show install state, sessions, and pending work."""


import time

import click
from rich import box
from rich.table import Table

from clu import ui
from clu.lib.status import get_status


@click.command()
def status() -> None:
    """Show install state, active sessions, and pending sync work."""
    try:
        report = get_status()
    except Exception as error:
        ui.warn(f"cannot read state: {error}")
        return

    ui.console.print()
    ui.heading(f"Active sessions ({len(report.sessions)})")
    if not report.sessions:
        ui.dim("  (none)")
    else:
        table = Table(
            show_header=True,
            header_style="heading",
            box=box.SIMPLE,
            pad_edge=False,
            padding=(0, 1),
        )
        table.add_column("ID", style="brand", no_wrap=True)
        table.add_column("Agent", style="muted", no_wrap=True)
        table.add_column("Path", overflow="fold")
        table.add_column("Started", style="muted", no_wrap=True)
        for session in report.sessions:
            table.add_row(
                session.id[:8],
                session.agent,
                session.path,
                _relative_time_ms(session.start_time),
            )
        ui.console.print(table)

    ui.console.print()
    if report.pending_sessions == 0 and report.pending_messages == 0:
        ui.success("All synced")
        return

    ui.heading("Pending sync")
    ui.console.print(
        f"  sessions: [warn]{report.pending_sessions}[/warn]",
        highlight=False,
    )
    ui.console.print(
        f"  messages: [warn]{report.pending_messages}[/warn]",
        highlight=False,
    )
    ui.dim("  Run `clu flush` to sync.")


def _relative_time_ms(ts_ms: int) -> str:
    if ts_ms <= 0:
        return "—"
    delta = int(time.time()) - ts_ms // 1000
    if delta < 0:
        return "just now"
    if delta < 60:
        return f"{delta}s ago"
    if delta < 3600:
        return f"{delta // 60}m ago"
    if delta < 86400:
        return f"{delta // 3600}h ago"
    return f"{delta // 86400}d ago"
