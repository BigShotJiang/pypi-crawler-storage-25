"""AI agent adapter interface and registry."""


from abc import ABC, abstractmethod
from typing import Dict, List, Tuple

from clu.adapter.events import AdapterEvent
from clu.models.session_message import SessionMessage


class Adapter(ABC):
    """Interface every AI agent adapter must implement."""

    @abstractmethod
    def name(self) -> str:
        """Return the adapter identifier (e.g. 'claude-code')."""

    @abstractmethod
    def detect(self) -> bool:
        """Return True if the agent is installed on this system."""

    @abstractmethod
    def install_hooks(self, project_dir: str, global_: bool, clu_binary: str) -> None:
        """Write clu event hook entries into the agent's settings."""

    @abstractmethod
    def uninstall_hooks(self, project_dir: str, global_: bool) -> None:
        """Remove clu event hook entries from the agent's settings."""

    @abstractmethod
    def parse_hook_payload(self, raw_payload: str) -> Tuple[str, AdapterEvent]:
        """Parse raw hook JSON into an internal lifecycle event.

        Returns:
            A tuple of (native_event_type, event).  *native_event_type* is the
            agent's own name for the hook (logged for debugging).  *event* is
            the :class:`AdapterEvent` that drives session lifecycle.
        """

    @abstractmethod
    def parse_transcript(
        self,
        *,
        path: str,
        session_id: str,
        cwd: str,
        watermark: int,
        turn_offset: int,
        last_known_model: str = "",
    ) -> Tuple[list[SessionMessage], int]:
        """Parse new transcript turns since *watermark*.

        Each adapter owns its transcript file format — JSONL for Claude Code,
        SQLite for Cursor, markdown for others, etc.

        *last_known_model* is the most recent non-empty model already recorded
        for this session; adapters may use it to enrich rows that lack a model
        in the raw transcript (e.g. tool_result user turns in Claude Code).

        Returns:
            A tuple of (new_messages, new_watermark).
        """


def _build_adapters() -> Dict[str, Adapter]:
    """Return the dict of all shipped adapters, keyed by name."""
    from clu.adapter.claude import ClaudeAdapter

    claude = ClaudeAdapter()
    return {claude.name(): claude}


def get_adapter(name: str) -> Adapter:
    """Look up an adapter by name.

    Raises:
        KeyError: If no adapter with *name* is registered.
    """
    adapters = _build_adapters()
    if name not in adapters:
        raise KeyError(f"unknown agent adapter: {name}")
    return adapters[name]


def all_adapters() -> List[Adapter]:
    """Return all shipped adapters."""
    return list(_build_adapters().values())


def detect_adapters() -> List[Adapter]:
    """Return only the adapters whose agent is installed locally."""
    return [a for a in all_adapters() if a.detect()]
