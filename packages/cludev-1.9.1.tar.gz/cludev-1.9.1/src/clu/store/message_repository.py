"""Session message persistence helpers."""


import sqlite3

from clu.models.session_message import SessionMessage


def _row_to_message(row: sqlite3.Row) -> SessionMessage:
    """Convert a SQLite row into a session message model."""
    return SessionMessage(
        uuid=str(row["uuid"]),
        parent_uuid=str(row["parent_uuid"] or ""),
        session_id=str(row["session_id"]),
        turn_index=int(row["turn_index"]),
        role=str(row["role"]),
        content=str(row["content"] or ""),
        tool_calls=str(row["tool_calls"] or ""),
        tool_results=str(row["tool_results"] or ""),
        model=str(row["model"] or ""),
        timestamp=int(row["timestamp"] or 0),
        cwd=str(row["cwd"] or ""),
        input_tokens=int(row["input_tokens"] or 0),
        output_tokens=int(row["output_tokens"] or 0),
        cache_read_tokens=int(row["cache_read_tokens"] or 0),
        cache_write_tokens=int(row["cache_write_tokens"] or 0),
        dirty=bool(row["dirty"]) if row["dirty"] is not None else True,
    )


_INSERT_COLS = (
    "uuid, parent_uuid, session_id, turn_index, role, content,"
    " tool_calls, tool_results, model, timestamp, cwd,"
    " input_tokens, output_tokens, cache_read_tokens, cache_write_tokens, dirty"
)

_SELECT_MESSAGE = (
    "SELECT uuid, parent_uuid, session_id, turn_index, role, content,"
    " tool_calls, tool_results, model, timestamp, cwd,"
    " input_tokens, output_tokens, cache_read_tokens, cache_write_tokens, dirty"
    " FROM session_messages"
)


class MessageRepository:
    """Repository for persisted session messages."""

    def __init__(self, db: sqlite3.Connection) -> None:
        """Bind the repository to an open SQLite connection."""
        self._db = db

    def insert_many(self, *, messages: list[SessionMessage]) -> None:
        """Insert session messages."""
        self._db.executemany(
            f"INSERT OR IGNORE INTO session_messages ({_INSERT_COLS})"
            " VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
            [
                (
                    m.uuid,
                    m.parent_uuid,
                    m.session_id,
                    m.turn_index,
                    m.role,
                    m.content,
                    m.tool_calls,
                    m.tool_results,
                    m.model,
                    m.timestamp,
                    m.cwd,
                    m.input_tokens,
                    m.output_tokens,
                    m.cache_read_tokens,
                    m.cache_write_tokens,
                    int(m.dirty),
                )
                for m in messages
            ],
        )

    def count_for_session(self, *, session_id: str) -> int:
        """Return the number of messages for a session."""
        row = self._db.execute(
            "SELECT COUNT(*) FROM session_messages WHERE session_id = ?",
            (session_id,),
        ).fetchone()
        return int(row[0]) if row else 0

    def last_model_for_session(self, *, session_id: str) -> str:
        """Return the most recent non-empty model recorded for a session."""
        row = self._db.execute(
            "SELECT model FROM session_messages"
            " WHERE session_id = ? AND model != ''"
            " ORDER BY turn_index DESC LIMIT 1",
            (session_id,),
        ).fetchone()
        return str(row[0]) if row else ""

    def list_for_session(self, *, session_id: str) -> list[SessionMessage]:
        """Return all messages for a session, ordered by turn index."""
        rows = self._db.execute(
            _SELECT_MESSAGE
            + " WHERE session_id = ? ORDER BY turn_index",
            (session_id,),
        ).fetchall()
        return [_row_to_message(row) for row in rows]

    def list_dirty(self, *, limit: int = 0) -> list[SessionMessage]:
        """Return dirty messages that need to be synced."""
        query = _SELECT_MESSAGE + " WHERE dirty = 1 ORDER BY session_id, turn_index"
        if limit > 0:
            query += f" LIMIT {limit}"
        rows = self._db.execute(query).fetchall()
        return [_row_to_message(row) for row in rows]

    def mark_clean(self, *, message_ids: list[str]) -> None:
        """Mark synced messages as clean."""
        if not message_ids:
            return
        placeholders = ",".join("?" for _ in message_ids)
        self._db.execute(
            f"UPDATE session_messages SET dirty = 0 WHERE uuid IN ({placeholders})",
            message_ids,
        )

    def mark_clean_for_sessions(self, *, session_ids: list[str]) -> None:
        """Mark all messages for the given sessions as clean."""
        if not session_ids:
            return
        placeholders = ",".join("?" for _ in session_ids)
        self._db.execute(
            "UPDATE session_messages SET dirty = 0"
            f" WHERE session_id IN ({placeholders})",
            session_ids,
        )

    def dirty_count(self) -> int:
        """Return the number of dirty messages."""
        row = self._db.execute(
            "SELECT COUNT(*) FROM session_messages WHERE dirty = 1"
        ).fetchone()
        return int(row[0]) if row else 0
