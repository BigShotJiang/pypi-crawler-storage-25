def doc():
  print(r"""
| Function | Description |
|:--------:|-------------|
| p1() | TSP(Brute, NN), 8-Puzzle(Simple, Steepest-Ascent) |
| p2() | 0/1 knapsack GA |
| p3() | Symmetric TSP using GA |
| p4() | Document Clustering using GA |
| p5() | Symmetric TSP using ANT |
| p6() | Document Clustering using ANT |
| p7() | Membership functions for fuzzy set |
| p8() | Fuzzy C Means Algorithm) |
| p9() | PSO |

""")

def p1():
    print(r"""
          
----------------------TSP BRUTE----------------------
#include <bits/stdc++.h>
using namespace std;

long long bruteForceTSP(const vector<vector<int>> &dist, int n)
{
    vector<int> cities;
    for (int i = 1; i < n; i++)
        cities.push_back(i);

    long long best = LLONG_MAX;

    do
    {
        long long curr = 0;
        int prev = 0;

        for (int c : cities)
        {
            curr += dist[prev][c];
            prev = c;
        }

        curr += dist[prev][0];

        best = min(best, curr);

    } while (next_permutation(cities.begin(), cities.end()));

    return best;
}

int main()
{
    srand(time(0));

    ofstream csvFile("tsp_bruteforce_results.csv");
    csvFile << "number_of_nodes,duration,best_cost\n";

    for (int n = 2; n <= 13; n++)
    {
        vector<vector<int>> dist(n, vector<int>(n));

        for (int i = 0; i < n; i++)
        {
            for (int j = 0; j < n; j++)
            {
                if (i == j)
                    dist[i][j] = 0;
                else
                    dist[i][j] = rand() % 100 + 1;
            }
        }

        using Clock = chrono::high_resolution_clock;
        auto start_time = Clock::now();

        long long best = bruteForceTSP(dist, n);

        auto end_time = Clock::now();
        auto duration = chrono::duration_cast<chrono::microseconds>(end_time - start_time);

        csvFile << n << "," << duration.count() << "," << best << "\n";
    }

    csvFile.close();
    return 0;
}


-----------------------------TSP NN---------------------------------
#include <iostream>
#include <vector>
#include <climits>
#include <cstdlib>
#include <ctime>
#include <chrono>
#include <string>
#include <fstream>

using namespace std;

int rec(int start, int node, int n, vector<vector<pair<int, int>>> &adj, vector<bool> &visited)
{

    visited[node] = true;
    int cost = 0;
    int minNode = -1;
    int minDist = INT_MAX;
    for (auto it : adj[node])
    {
        if (!visited[it.first] && it.second < minDist)
        {
            minNode = it.first;
            minDist = it.second;
        }
    }
    if (minNode == -1)
        return adj[node][start].second;
    cost += (minDist + rec(start, minNode, n, adj, visited));
    return cost;
}

int main()
{
    srand(time(0));

    ofstream csvFile("tsp_nn_results.csv");
    csvFile << "number_of_nodes,duration\n";

    for (int i = 2; i <= 10000; i++)
    {
        int n = i;
        vector<vector<pair<int, int>>> adj(n);
        for (int i = 0; i < n; i++)
        {
            for (int j = 0; j < n; j++)
            {
                if (i != j)
                {
                    int weight = rand() % 100 + 1;
                    adj[i].push_back({j, weight});
                }
            }
        }

        vector<bool> visited(n, false);
        using Clock = std::chrono::high_resolution_clock;
        using std::chrono::milliseconds;
        auto start_time = Clock::now();

        int cost = rec(0, 0, n - 1, adj, visited);

        auto end_time = Clock::now();
        auto duration_native = end_time - start_time;
        csvFile << n << "," << duration_native.count() << "\n";
    }
    csvFile.close();

    return 0;
}

-----------------------------8-Puzzle-Simple------------------------
#include <iostream>
#include <vector>
#include <map>
#include <utility>
#include <chrono>
#include <thread>

using namespace std;

void printBoard(const vector<vector<int>> &arr)
{
    for (auto &row : arr)
    {
        for (auto &x : row)
        {
            if (x == -1)
                cout << "  ";
            else
                cout << x << " ";
        }
        cout << endl;
    }
    cout << endl;
}

int misplacedTiles(vector<vector<int>> &arr, vector<vector<int>> &goal)
{
    int cnt = 0;
    int m = arr.size();
    int n = arr[0].size();
    map<int, pair<int, int>> mpp;

    for (int i = 0; i < m; i++)
    {
        for (int j = 0; j < n; j++)
        {
            mpp[goal[i][j]] = {i, j};
        }
    }
    for (int i = 0; i < m; i++)
    {
        for (int j = 0; j < n; j++)
        {
            if (arr[i][j] != -1 && (mpp[arr[i][j]].first != i || mpp[arr[i][j]].second != j))
            {
                cnt++;
            }
        }
    }
    return cnt;
}

int manhattan(vector<vector<int>> &arr, vector<vector<int>> &goal)
{
    map<int, pair<int, int>> mpp;
    int m = arr.size();
    int dist = 0;
    int n = arr[0].size();
    for (int i = 0; i < m; i++)
    {
        for (int j = 0; j < n; j++)
        {
            mpp[goal[i][j]] = {i, j};
        }
    }
    for (int i = 0; i < m; i++)
    {
        for (int j = 0; j < n; j++)
        {
            if (arr[i][j] != -1)
            {
                dist += abs(i - mpp[arr[i][j]].first) + abs(j - mpp[arr[i][j]].second);
            }
        }
    }
    return dist;
}

bool recTiles(int row, int col, vector<vector<int>> &arr, vector<vector<int>> &goal, string &str)
{
    if (arr == goal)
        return true;
    vector<int> drow = {-1, 0, 1, 0};
    vector<int> dcol = {0, 1, 0, -1};
    int currMisplacedTiles = misplacedTiles(arr, goal);
    for (int i = 0; i < 4; i++)
    {
        int nrow = row + drow[i];
        int ncol = col + dcol[i];
        if (nrow >= 0 && nrow < 3 && ncol >= 0 && ncol < 3)
        {
            char move;
            if (i == 0)
            {
                move = 'U';
            }
            else if (i == 1)
            {
                move = 'R';
            }
            else if (i == 2)
            {
                move = 'D';
            }
            else
            {
                move = 'L';
            }
            swap(arr[row][col], arr[nrow][ncol]);
            int newMisplacedTiles = misplacedTiles(arr, goal);
            if (newMisplacedTiles < currMisplacedTiles)
            {
                str.push_back(move);
                if (recTiles(nrow, ncol, arr, goal, str))
                    return true;
                str.pop_back();
            }
            swap(arr[row][col], arr[nrow][ncol]);
        }
    }
    return false;
}

bool recDist(int row, int col, vector<vector<int>> &arr, vector<vector<int>> &goal, string &str)
{
    if (arr == goal)
        return true;
    vector<int> drow = {-1, 0, 1, 0};
    vector<int> dcol = {0, 1, 0, -1};
    int currDistance = manhattan(arr, goal);
    for (int i = 0; i < 4; i++)
    {
        int nrow = row + drow[i];
        int ncol = col + dcol[i];
        if (nrow >= 0 && nrow < 3 && ncol >= 0 && ncol < 3)
        {
            char move;
            if (i == 0)
            {
                move = 'U';
            }
            else if (i == 1)
            {
                move = 'R';
            }
            else if (i == 2)
            {
                move = 'D';
            }
            else
            {
                move = 'L';
            }
            swap(arr[row][col], arr[nrow][ncol]);
            int newDistance = manhattan(arr, goal);
            if (newDistance < currDistance)
            {
                str.push_back(move);

                // system("cls");
                // printBoard(arr);
                // std::this_thread::sleep_for(std::chrono::milliseconds(400));

                if (recDist(nrow, ncol, arr, goal, str))
                    return true;

                str.pop_back();
            }

            swap(arr[row][col], arr[nrow][ncol]);
        }
    }
    return false;
}

int main()
{
    vector<vector<int>> arr(3, vector<int>(3));
    vector<vector<int>> goal(3, vector<int>(3));

    cout << "Enter Your Start Puzzle" << endl;
    for (int i = 0; i < 3; i++)
        for (int j = 0; j < 3; j++)
            cin >> arr[i][j];

    cout << "Enter Your Solved Puzzle" << endl;
    for (int i = 0; i < 3; i++)
        for (int j = 0; j < 3; j++)
            cin >> goal[i][j];
    int choice;
    cout << "Enter Your Choice\n'1' -> Manhattan Distance\n'2' -> Number of Misplaced Tiles" << endl;
    cin >> choice;
    string str;

    int br = -1, bc = -1;
    for (int i = 0; i < 3; i++)
        for (int j = 0; j < 3; j++)
            if (arr[i][j] == -1)
            {
                br = i;
                bc = j;
            }

    if (choice == 1)
    {
        recDist(br, bc, arr, goal, str);
        cout << str;
    }
    else if (choice == 2)
    {
        recTiles(br, bc, arr, goal, str);
        cout << str;
    }
    else
    {
        cout << "Enter valid choice";
    }

    return 0;
}

// arr = {{1, 2, 3}, {4, -1, 6}, {7, 5, 8}}
// goal = {{1, 2, 3}, {4, 5, 6}, {7, 8, -1}}

-------------------8-Puzzle-Steepest-Ascent------------------------
#include <bits/stdc++.h>

using namespace std;
int misplacedTiles(vector<vector<int>> &arr, vector<vector<int>> &goal)
{
    int cnt = 0;
    int m = arr.size();
    int n = arr[0].size();
    map<int, pair<int, int>> mpp;

    for (int i = 0; i < m; i++)
    {
        for (int j = 0; j < n; j++)
        {
            mpp[goal[i][j]] = {i, j};
        }
    }
    for (int i = 0; i < m; i++)
    {
        for (int j = 0; j < n; j++)
        {
            if (arr[i][j] != -1 && (mpp[arr[i][j]].first != i || mpp[arr[i][j]].second != j))
            {
                cnt++;
            }
        }
    }
    return cnt;
}

int manhattan(vector<vector<int>> &arr, vector<vector<int>> &goal)
{
    map<int, pair<int, int>> mpp;
    int m = arr.size();
    int dist = 0;
    int n = arr[0].size();
    for (int i = 0; i < m; i++)
    {
        for (int j = 0; j < n; j++)
        {
            mpp[goal[i][j]] = {i, j};
        }
    }
    for (int i = 0; i < m; i++)
    {
        for (int j = 0; j < n; j++)
        {
            if (arr[i][j] != -1)
            {
                dist += abs(i - mpp[arr[i][j]].first) + abs(j - mpp[arr[i][j]].second);
            }
        }
    }
    return dist;
}

bool recTiles(int row, int col, vector<vector<int>> &arr, vector<vector<int>> &goal, string &str)
{
    if (arr == goal)
        return true;

    vector<int> drow = {-1, 0, 1, 0};
    vector<int> dcol = {0, 1, 0, -1};

    int currTiles = misplacedTiles(arr, goal);
    int minTiles = INT_MAX;

    char optMove;
    int optNrow = -1, optNcol = -1;

    bool foundBetter = false;
    bool foundEqual = false;

    for (int i = 0; i < 4; i++)
    {
        int nrow = row + drow[i];
        int ncol = col + dcol[i];

        if (nrow >= 0 && nrow < 3 && ncol >= 0 && ncol < 3)
        {
            swap(arr[nrow][ncol], arr[row][col]);
            int newTiles = misplacedTiles(arr, goal);

            if (newTiles < currTiles)
            {
                foundBetter = true;
            }
            else if (newTiles == currTiles)
            {
                foundEqual = true;
            }

            if (newTiles < minTiles)
            {
                minTiles = newTiles;
                optMove = (i == 0 ? 'U' : i == 1 ? 'R'
                                      : i == 2   ? 'D'
                                                 : 'L');
                optNrow = nrow;
                optNcol = ncol;
            }

            swap(arr[nrow][ncol], arr[row][col]);
        }
    }

    if (!foundBetter)
    {
        if (foundEqual)
            cout << "Plateau detected\n";
        else
            cout << "Local maxima detected\n";
        return false;
    }

    swap(arr[row][col], arr[optNrow][optNcol]);
    str.push_back(optMove);

    if (recTiles(optNrow, optNcol, arr, goal, str))
        return true;

    str.pop_back();
    swap(arr[row][col], arr[optNrow][optNcol]);

    return false;
}

bool recDist(int row, int col, vector<vector<int>> &arr, vector<vector<int>> &goal, string &str)
{
    if (arr == goal)
        return true;

    vector<int> drow = {-1, 0, 1, 0};
    vector<int> dcol = {0, 1, 0, -1};

    int currDistance = manhattan(arr, goal);
    int minDistance = INT_MAX;

    char optMove;
    int optNrow = -1, optNcol = -1;

    bool foundBetter = false;
    bool foundEqual = false;

    for (int i = 0; i < 4; i++)
    {
        int nrow = row + drow[i];
        int ncol = col + dcol[i];

        if (nrow >= 0 && nrow < 3 && ncol >= 0 && ncol < 3)
        {
            swap(arr[nrow][ncol], arr[row][col]);
            int newDist = manhattan(arr, goal);

            if (newDist < currDistance)
            {
                foundBetter = true;
            }
            else if (newDist == currDistance)
            {
                foundEqual = true;
            }

            if (newDist < minDistance)
            {
                minDistance = newDist;
                optMove = (i == 0 ? 'U' : i == 1 ? 'R'
                                      : i == 2   ? 'D'
                                                 : 'L');
                optNrow = nrow;
                optNcol = ncol;
            }

            swap(arr[nrow][ncol], arr[row][col]);
        }
    }

    if (!foundBetter)
    {
        if (foundEqual)
            cout << "Plateau detected\n";
        else
            cout << "Local maxima detected\n";
        return false;
    }

    swap(arr[row][col], arr[optNrow][optNcol]);
    str.push_back(optMove);

    if (recDist(optNrow, optNcol, arr, goal, str))
        return true;

    str.pop_back();
    swap(arr[row][col], arr[optNrow][optNcol]);

    return false;
}

int main()
{
    vector<vector<int>> arr(3, vector<int>(3));
    vector<vector<int>> goal(3, vector<int>(3));

    cout << "Enter Your Start Puzzle" << endl;
    for (int i = 0; i < 3; i++)
        for (int j = 0; j < 3; j++)
            cin >> arr[i][j];

    cout << "Enter Your Solved Puzzle" << endl;
    for (int i = 0; i < 3; i++)
        for (int j = 0; j < 3; j++)
            cin >> goal[i][j];
    int choice;
    cout << "Enter Your Choice\n'1' -> Manhattan Distance\n'2' -> Number of Misplaced Tiles";
    cout << endl;
    cin >> choice;
    string str;

    int br = -1, bc = -1;
    for (int i = 0; i < 3; i++)
        for (int j = 0; j < 3; j++)
            if (arr[i][j] == -1)
            {
                br = i;
                bc = j;
            }

    if (choice == 1)
    {
        recDist(br, bc, arr, goal, str);
        cout << str;
    }
    else if (choice == 2)
    {
        recTiles(br, bc, arr, goal, str);
        cout << str;
    }
    else
    {
        cout << "Enter valid choice";
    }

    return 0;
}
""")

def p2():
    print("""
---------------------------Genetic Algorithm-------------------------
#include <bits/stdc++.h>
using namespace std;

int n;
int capacity;
vector<int> weight, value;

const int POP_SIZE = 10;
const int GENERATIONS = 200;

mt19937 rng(time(0));

vector<int> randomChromosome()
{
    vector<int> ch(n);
    for (int i = 0; i < n; i++)
    {
        ch[i] = rng() % 2;
    }
    return ch;
}

int fitness(const vector<int> &ch)
{
    int totalW = 0, totalV = 0;
    for (int i = 0; i < n; i++)
    {
        if (ch[i])
        {
            totalW += weight[i];
            totalV += value[i];
        }
    }
    if (totalW > capacity)
        return 0;
    return totalV;
}

vector<int> rouletteSelect(const vector<vector<int>> &population,
                           const vector<int> &fit)
{
    int sum = accumulate(fit.begin(), fit.end(), 0);

    if (sum == 0)
    {
        return population[rng() % POP_SIZE];
    }

    int r = rng() % sum;
    int curr = 0;
    for (int i = 0; i < POP_SIZE; i++)
    {
        curr += fit[i];
        if (curr > r)
        {
            return population[i];
        }
    }
    return population.back();
}

pair<vector<int>, vector<int>> crossover(const vector<int> &p1,
                                         const vector<int> &p2)
{
    vector<int> c1 = p1, c2 = p2;

    int point = rng() % n;

    for (int i = point; i < n; i++)
    {
        swap(c1[i], c2[i]);
    }

    return {c1, c2};
}

pair<vector<int>, vector<int>> kPointCrossover(const vector<int> &p1,
                                               const vector<int> &p2,
                                               int k)
{
    int n = p1.size();
    vector<int> c1 = p1, c2 = p2;

    if (k > 0)
    {
        k = min(k, n - 1);

        vector<int> points;
        unordered_set<int> used;

        while ((int)points.size() < k)
        {
            int pt = rng() % (n - 1) + 1;
            if (!used.count(pt))
            {
                used.insert(pt);
                points.push_back(pt);
            }
        }

        sort(points.begin(), points.end());

        bool takeFromP1 = true;
        int prev = 0;

        for (int cut : points)
        {
            for (int i = prev; i < cut; i++)
            {
                if (!takeFromP1)
                    swap(c1[i], c2[i]);
            }
            takeFromP1 = !takeFromP1;
            prev = cut;
        }

        for (int i = prev; i < n; i++)
        {
            if (!takeFromP1)
                swap(c1[i], c2[i]);
        }
    }

    return {c1, c2};
}

void mutateOneBit(vector<int> &ch)
{
    int idx = rng() % n;
    ch[idx] = 1 - ch[idx];
}

int main()
{
    cout << "Enter number of items: ";
    cin >> n;

    weight.resize(n);
    value.resize(n);

    cout << "Enter weights:\n";
    for (int i = 0; i < n; i++)
        cin >> weight[i];

    cout << "Enter values:\n";
    for (int i = 0; i < n; i++)
        cin >> value[i];

    cout << "Enter knapsack capacity: ";
    cin >> capacity;

    vector<vector<int>> population;
    for (int i = 0; i < POP_SIZE; i++)
    {
        population.push_back(randomChromosome());
    }

    vector<int> bestEver;
    int bestFitness = 0;

    for (int gen = 0; gen < GENERATIONS; gen++)
    {
        vector<int> fit(POP_SIZE);
        for (int i = 0; i < POP_SIZE; i++)
        {
            fit[i] = fitness(population[i]);
            if (fit[i] > bestFitness)
            {
                bestFitness = fit[i];
                bestEver = population[i];
            }
        }

        vector<vector<int>> newPop;

        while ((int)newPop.size() < POP_SIZE)
        {
            vector<int> p1 = rouletteSelect(population, fit);
            vector<int> p2 = rouletteSelect(population, fit);

            auto [c1, c2] = crossover(p1, p2);

            mutateOneBit(c1);
            mutateOneBit(c2);

            newPop.push_back(c1);
            if ((int)newPop.size() < POP_SIZE)
                newPop.push_back(c2);
        }

        population = newPop;
    }

    cout << "\nBest solution found:\n";
    cout << "Chromosome: ";
    for (int b : bestEver)
        cout << b << " ";
    cout << "\nMaximum Value: " << bestFitness << "\n";

    int finalWeight = 0;
    for (int i = 0; i < n; i++)
    {
        if (bestEver[i])
            finalWeight += weight[i];
    }
    cout << "Total Weight: " << finalWeight << "\n";

    return 0;
}

""")

def p3():
    print("""
-------------------------TSP-Genetic-------------------------------
import random
import math
import matplotlib.pyplot as plt
          
dist_matrix = [
    [0, 29, 20, 21, 16, 31, 100, 12, 4, 31],
    [29, 0, 15, 29, 28, 40, 72, 21, 29, 41],
    [20, 15, 0, 15, 14, 25, 81, 9, 23, 27],
    [21, 29, 15, 0, 4, 12, 92, 12, 25, 13],
    [16, 28, 14, 4, 0, 16, 94, 9, 20, 16],
    [31, 40, 25, 12, 16, 0, 95, 24, 36, 3],
    [100, 72, 81, 92, 94, 95, 0, 90, 101, 99],
    [12, 21, 9, 12, 9, 24, 90, 0, 15, 25],
    [4, 29, 23, 25, 20, 36, 101, 15, 0, 35],
    [31, 41, 27, 13, 16, 3, 99, 25, 35, 0]
]

N_CITIES = len(dist_matrix)
          
def route_cost(route):
    cost = 0
    for i in range(len(route)):
        cost += dist_matrix[route[i]][route[(i+1) % len(route)]]
    return cost
          
def create_population(pop_size):
    population = []
    for _ in range(pop_size):
        route = list(range(N_CITIES))
        random.shuffle(route)
        population.append(route)
    return population
        
def fitness(route):
    return 1 / route_cost(route)
          
def random_selection(population):
    return random.choice(population)
          
def roulette_selection(population):
    fitnesses = [fitness(r) for r in population]
    total_fitness = sum(fitnesses)
    probs = [f / total_fitness for f in fitnesses]
    return population[random.choices(range(len(population)), probs)[0]]

def tournament_selection(population, k=5):
    tournament_candidates = random.sample(population, k)
    winner = max(tournament_candidates, key=fitness)
    return winner
          
def order_crossover(p1, p2):
    size = len(p1)
    a, b = sorted(random.sample(range(size), 2))

    child = [-1] * size
    child[a:b] = p1[a:b]

    ptr = b
    for gene in p2:
        if gene not in child:
            if ptr >= size:
                ptr = 0
            child[ptr] = gene
            ptr += 1

    return child

def inversion_mutation(route, mutation_rate=0.1):
    if random.random() < mutation_rate:
        a, b = sorted(random.sample(range(len(route)), 2))
        route[a:b] = reversed(route[a:b])
          
def genetic_algorithm(selection_type="roulette", pop_size=50, generations=200):
    population = create_population(pop_size)
    best_costs = []

    for gen in range(generations):
        new_population = []

        for _ in range(pop_size // 2):
            if selection_type == "roulette":
                p1 = roulette_selection(population)
                p2 = roulette_selection(population)
            elif selection_type == "tournament":
                p1 = tournament_selection(population)
                p2 = tournament_selection(population)
            else:
                p1 = random_selection(population)
                p2 = random_selection(population)

            c1 = order_crossover(p1, p2)
            c2 = order_crossover(p2, p1)

            inversion_mutation(c1)
            inversion_mutation(c2)

            new_population.extend([c1, c2])

        population = new_population

        best_route = min(population, key=route_cost)
        best_costs.append(route_cost(best_route))

    return best_route, best_costs
          

best_route_roulette, cost_roulette = genetic_algorithm("roulette")
best_route_tournament, cost_tournament = genetic_algorithm("tournament")
best_route_random, cost_random = genetic_algorithm("random")

print("Best Route (Roulette):", best_route_roulette)
print("Cost:", route_cost(best_route_roulette))

print("\nBest Route (tournament):", best_route_tournament)
print("Cost:", route_cost(best_route_tournament))

print("\nBest Route (Random):", best_route_random)
print("Cost:", route_cost(best_route_random))

""")

def p4():
    print("""
# =========================================================
# PRACTICAL 4: CLUSTERING USING GENETIC ALGORITHM
# Tournament Selection + Elitism Selection + Convergence Graph
    
import os
import random
import numpy as np
from collections import defaultdict
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
import matplotlib.pyplot as plt


# ===================== LOAD DOCUMENTS =====================

documents = []
file_names = []

for file in sorted(os.listdir("dataset")):
    file_names.append(file)
    with open(os.path.join("dataset", file), "r") as f:
        documents.append(f.read())

print("Total documents loaded:", len(documents))

vectorizer = TfidfVectorizer(stop_words="english")
tfidf_matrix = vectorizer.fit_transform(documents)

print("TF-IDF Matrix Shape:", tfidf_matrix.shape)


# ===================== PARAMETERS =====================

NUM_DOCS = 25
NUM_CLUSTERS = 5
POP_SIZE = 20
GENERATIONS = 30
MUTATION_RATE = 0.1


# ===================== DISTANCE =====================

def cosine_distance(v1, v2):
    return 1 - cosine_similarity(v1, v2)[0][0]


# ===================== FITNESS =====================

def fitness(chromosome):
    total_distance = 0
    count = 0

    for cluster in range(NUM_CLUSTERS):
        indices = [i for i in range(NUM_DOCS) if chromosome[i] == cluster]

        for i in range(len(indices)):
            for j in range(i + 1, len(indices)):
                total_distance += cosine_distance(
                    tfidf_matrix[indices[i]],
                    tfidf_matrix[indices[j]]
                )
                count += 1

    return total_distance / count if count > 0 else float("inf")


# ===================== INITIAL POPULATION =====================

def initialize_population():
    return [
        [random.randint(0, NUM_CLUSTERS - 1) for _ in range(NUM_DOCS)]
        for _ in range(POP_SIZE)
    ]


# ===================== SELECTION METHODS =====================

def tournament_selection(population):
    a, b = random.sample(population, 2)
    return a if fitness(a) < fitness(b) else b


def elitism_selection(population):
    sorted_pop = sorted(population, key=lambda ch: fitness(ch))
    elite = sorted_pop[:POP_SIZE // 2]
    return random.choice(elite)


# ===================== GA OPERATORS =====================

def crossover(parent1, parent2):
    point = random.randint(1, NUM_DOCS - 2)
    return parent1[:point] + parent2[point:]


def mutation(chromosome):
    for i in range(NUM_DOCS):
        if random.random() < MUTATION_RATE:
            chromosome[i] = random.randint(0, NUM_CLUSTERS - 1)
    return chromosome


# ===================== GA RUNNER =====================

def run_ga(method):
    population = initialize_population()
    best_solution = None
    best_fitness = float("inf")
    convergence = []

    print(f"\nRUNNING GA USING {method.upper()} SELECTION\n")

    for gen in range(GENERATIONS):
        new_population = []

        for _ in range(POP_SIZE):
            if method == "tournament":
                p1 = tournament_selection(population)
                p2 = tournament_selection(population)
            else:
                p1 = elitism_selection(population)
                p2 = elitism_selection(population)

            child = crossover(p1, p2)
            child = mutation(child)
            new_population.append(child)

        population = new_population

        gen_best = min([fitness(ind) for ind in population])
        convergence.append(gen_best)

        if gen_best < best_fitness:
            best_fitness = gen_best
            best_solution = population[np.argmin([fitness(ind) for ind in population])]

        print(f"Generation {gen+1}: Best Fitness = {best_fitness:.4f}")

    return best_solution, convergence


# ===================== RUN BOTH METHODS =====================

best_tournament, tournament_curve = run_ga("tournament")
best_elite, elite_curve = run_ga("elitism")


# ===================== CONVERGENCE GRAPH =====================

plt.figure()
plt.plot(tournament_curve, label="Tournament Selection")
plt.plot(elite_curve, label="Elitism Selection")
plt.xlabel("Generations")
plt.ylabel("Best Fitness")
plt.title("GA Clustering Convergence Comparison")
plt.legend()
plt.grid(True)
plt.show()


# ===================== FINAL CLUSTERS (TOURNAMENT) =====================

clusters = defaultdict(list)

for i, cid in enumerate(best_tournament):
    clusters[cid].append(file_names[i])

print("\nFINAL CLUSTER ASSIGNMENT (TOURNAMENT)\n")

for cid in sorted(clusters):
    print(f"Cluster-{cid}:")
    for file in clusters[cid]:
        print(" ", file)
    print()


# ===================== RANGE BASED SELECTION =====================

def compute_centroid(indices):
    return np.mean(tfidf_matrix[indices].toarray(), axis=0).reshape(1, -1)

def document_distances(indices):
    centroid = compute_centroid(indices)
    return {idx: cosine_distance(tfidf_matrix[idx], centroid) for idx in indices}

def cluster_range(distances):
    vals = list(distances.values())
    mean = np.mean(vals)
    std = np.std(vals)
    return mean, std, mean - std, mean + std

clusters_index = defaultdict(list)

for i, cid in enumerate(best_tournament):
    clusters_index[cid].append(i)

print("\nCLUSTER-WISE RANGE BASED SELECTION\n")

for cid in sorted(clusters_index):
    indices = clusters_index[cid]
    print(f"Cluster-{cid}:")

    distances = document_distances(indices)
    mean, std, low, high = cluster_range(distances)

    print(f" Distance Range: [{low:.4f}, {high:.4f}]")

    for idx, dist in distances.items():
        status = "SELECTED" if low <= dist <= high else "OUTLIER"
        print(f" {file_names[idx]} -> {dist:.4f} ({status})")

    print()

""")

def p5():
    print("""
--------------------Symmetric TSP using ANT-------------------------
# with pheramon evaporation
import numpy as np
import random
import matplotlib.pyplot as plt

num_cities = 10

mat = np.array([
[0,29,20,21,16,31,100,12,4,31],
[29,0,15,29,28,40,72,21,29,41],
[20,15,0,15,14,25,81,9,23,27],
[21,29,15,0,4,12,92,12,25,13],
[16,28,14,4,0,16,94,9,20,16],
[31,40,25,12,16,0,95,24,36,3],
[100,72,81,92,94,95,0,90,101,99],
[12,21,9,12,9,24,90,0,15,25],
[4,29,23,25,20,36,101,15,0,35],
[31,41,27,13,16,3,99,25,35,0]
])

coords = np.random.rand(num_cities,2)*100


def compute_length(route):
    total = 0
    for i in range(len(route)-1):
        total += mat[route[i]][route[i+1]]
    total += mat[route[-1]][route[0]]
    return total


def next_city(current_city, unvisited, pheromone, alpha, beta):

    probs = []

    for city in unvisited:
        pheromone_factor = pheromone[current_city][city] ** alpha
        heuristic_factor = (1 / mat[current_city][city]) ** beta
        probs.append(pheromone_factor * heuristic_factor)

    probs = np.array(probs)
    probs = probs / probs.sum()

    return random.choices(unvisited, weights=probs)[0]


def ant_col(num_ants=10, gens=100, alpha=1, beta=2, evap_rate=0.5, Q=100):

    pheromone = np.ones((num_cities, num_cities))

    best_route = None
    best_dist = float('inf')

    conv_hist = []

    for gen in range(gens):

        routes = []
        route_lengths = []

        for ant in range(num_ants):

            start = random.randint(0, num_cities-1)

            route = [start]

            unvisited = list(range(num_cities))
            unvisited.remove(start)

            while unvisited:

                current = route[-1]

                nxt = next_city(current, unvisited, pheromone, alpha, beta)

                route.append(nxt)
                unvisited.remove(nxt)

            length = compute_length(route)

            routes.append(route)
            route_lengths.append(length)

            if length < best_dist:
                best_dist = length
                best_route = route

        pheromone *= (1 - evap_rate)

        for route, length in zip(routes, route_lengths):

            for i in range(len(route)-1):

                a = route[i]
                b = route[i+1]

                pheromone[a][b] += Q / length
                pheromone[b][a] += Q / length

            pheromone[route[-1]][route[0]] += Q / length
            pheromone[route[0]][route[-1]] += Q / length

        conv_hist.append(min(route_lengths))

    return best_route, best_dist, conv_hist


def pretty_print(route, distance):

    print("ANT COLONY OPTIMIZATION RESULT")

    print("\nBest Route :")
    print(" -> ".join(map(str, route)) + f" -> {route[0]}")

    print("\nBest Distance :", distance)


def plot_convergence(history):

    iterations = list(range(1, len(history)+1))

    plt.figure()
    plt.plot(iterations, history, marker='o')

    plt.xlabel("Iteration")
    plt.ylabel("Tour Length")
    plt.title("Tour Length vs Iteration (ACO)")
    plt.grid(True)

    plt.show()


best_route, best_dist, history = ant_col()

pretty_print(best_route, best_dist)

plot_convergence(history)


ant_values = [10,30,50]

comparison_results = []

for ants in ant_values:

    route, dist_value, hist = ant_col(num_ants=ants)

    comparison_results.append((ants, dist_value))


print("\nAnts + Best Distance")

for ants, dist_val in comparison_results:
    print(f"{ants} - {dist_val}")
""")

def p6():
    print("""
------------------Document Clusterng using ANT--------------------
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import random

from sklearn.datasets import load_iris

# Load the dataset from scikit-learn
iris = load_iris()

# Create a DataFrame using the data and feature names
iris_df = pd.DataFrame(data=iris.data, columns=iris.feature_names)

# Add the target species column
iris_df['species'] = iris.target_names[iris.target]

# Save the DataFrame to a local CSV file
iris_df.to_csv("iris_sklearn_dataset.csv", index=False)
          ------------------------------------------------------
df = pd.read_csv('iris_sklearn_dataset.csv')

# Features (first 4 columns)
features = df.iloc[:, :-1].values

# Normalize features (0 to 1)
features = (features - features.min(axis=0)) / (features.max(axis=0) - features.min(axis=0))

# Labels
labels = df['species'].values
n_items = len(features)

# Convert species to numeric
species_map = {'setosa': 0, 'versicolor': 1, 'virginica': 2}
numeric_labels = np.array([species_map[label] for label in labels])
          ----------------------------------------------------------------------

GRID_SIZE = 40
N_ITERATIONS = 50000
N_ANTS = 20

GAMMA = 0.5
GAMMA1 = 0.1
GAMMA2 = 0.3
RADIUS = 1
          
grid = np.full((GRID_SIZE, GRID_SIZE), -1, dtype=int)

for i in range(n_items):
    while True:
        x, y = random.randint(0, GRID_SIZE - 1), random.randint(0, GRID_SIZE - 1)
        if grid[x, y] == -1:
            grid[x, y] = i
            break

initial_grid = grid.copy()
          
-------------------------------
ants = []
occupied_positions = set()

for _ in range(N_ANTS):
    while True:
        x, y = random.randint(0, GRID_SIZE - 1), random.randint(0, GRID_SIZE - 1)
        if (x, y) not in occupied_positions:
            occupied_positions.add((x, y))
            ants.append({'pos': [x, y], 'cargo': -1})
            break
          
----------------------
          
for step in range(N_ITERATIONS):
    for ant in ants:
        x, y = ant['pos']
        cargo = ant['cargo']

        neighbor_items = []
        for dx in range(-RADIUS, RADIUS + 1):
            for dy in range(-RADIUS, RADIUS + 1):
                if dx == 0 and dy == 0:
                    continue
                nx, ny = (x + dx) % GRID_SIZE, (y + dy) % GRID_SIZE
                if grid[nx, ny] != -1:
                    neighbor_items.append(grid[nx, ny])

        target_item_idx = cargo if cargo != -1 else grid[x, y]

        density = 0.0
        if target_item_idx != -1:
            sum_similarity = 0.0
            for neighbor_idx in neighbor_items:
                dist = np.linalg.norm(features[target_item_idx] - features[neighbor_idx])
                sum_similarity += max(0, 1 - (dist / GAMMA))

            density = sum_similarity / max(1, len(neighbor_items))

        if cargo == -1:
            if grid[x, y] != -1:
                p_pick = (GAMMA1 / (GAMMA1 + density))**2
                if random.random() < p_pick:
                    ant['cargo'] = grid[x, y]
                    grid[x, y] = -1

        else:
            if grid[x, y] == -1:
                if density >= GAMMA2:
                    p_drop = 1.0
                else:
                    p_drop = 2 * density

                if random.random() < p_drop:
                    grid[x, y] = ant['cargo']
                    ant['cargo'] = -1

        occupied_positions.remove((x, y))

        moves = [(-1,-1), (-1,0), (-1,1),
                 (0,-1),         (0,1),
                 (1,-1),  (1,0), (1,1)]

        random.shuffle(moves)

        moved = False
        for dx, dy in moves:
            nx, ny = (x + dx) % GRID_SIZE, (y + dy) % GRID_SIZE
            if (nx, ny) not in occupied_positions:
                ant['pos'] = [nx, ny]
                occupied_positions.add((nx, ny))
                moved = True
                break

        if not moved:
            occupied_positions.add((x, y))

    if step % 10000 == 0:
        print(f"Step {step}")
          
-------------------------------------------
def plot_grid(grid_data, title):
    plt.figure(figsize=(8, 8))

    colors = ['red', 'green', 'blue']
    markers = ['o', 's', '^']

    for r in range(GRID_SIZE):
        for c in range(GRID_SIZE):
            item_idx = grid_data[r, c]
            if item_idx != -1:
                species = numeric_labels[item_idx]
                plt.scatter(c, r, color=colors[species], marker=markers[species], s=25)

    plt.title(title)
    plt.xlim(-1, GRID_SIZE)
    plt.ylim(-1, GRID_SIZE)
    plt.gca().invert_yaxis()
    plt.show()
          
plot_grid(initial_grid, "Before Clustering")
plot_grid(grid, "After Clustering")
          
""")

def p7():
    print("""
----------------------MEMBERSHIP FUNCTIONS FOR FUZZY SETS-----------
import numpy as np
import matplotlib.pyplot as plt

def triangular(x, a, b, c):
    return np.maximum(np.minimum((x - a) / (b - a), (c - x) / (c - b)), 0)

def trapezoidal(x, a, b, c, d):
    return np.maximum(np.minimum(np.minimum((x - a) / (b - a), 1), (d - x) / (d - c)), 0)

def gaussian(x, c, sigma):
    return np.exp(-((x - c) ** 2) / (2 * sigma ** 2))

def bell(x, a, b, c):
    return 1 / (1 + np.abs((x - c) / a) ** (2 * b))

def sigmoid(x, a, c):
    return 1 / (1 + np.exp(-a * (x - c)))

x = np.linspace(0, 10, 200)

tri = triangular(x, 2, 5, 8)
trap = trapezoidal(x, 1, 3, 7, 9)
gauss = gaussian(x, 5, 1)
bell_mf = bell(x, 1, 2, 5)
sig = sigmoid(x, 1, 5)

plt.plot(x, tri, label='Triangular')
plt.plot(x, trap, label='Trapezoidal')
plt.plot(x, gauss, label='Gaussian')
plt.plot(x, bell_mf, label='Bell')
plt.plot(x, sig, label='Sigmoid')

plt.legend()
plt.xlabel('x')
plt.ylabel('Membership Value')
plt.title('Fuzzy Membership Functions')
plt.grid()

plt.show()
""")

def p8():
    print("""
-------------------FUZZY C MEANS ALGORITHM-------------------------
import random
import math

class FuzzyCMeans:
    def __init__(self, data, k, m=2, maxIter=100, eps=1e-5):
        self.data = data
        self.k = k
        self.m = m
        self.maxIter = maxIter
        self.eps = eps

        self.n = len(data)
        self.dim = len(data[0])

        self.U = [[random.random() for _ in range(k)] for _ in range(self.n)]
        for i in range(self.n):
            s = sum(self.U[i])
            self.U[i] = [x/s for x in self.U[i]]

        self.centers = [[0]*self.dim for _ in range(k)]

    def dist(self, a, b):
        return math.sqrt(sum((a[i]-b[i])**2 for i in range(self.dim)))

    def update_centers(self):
        for j in range(self.k):
            num = [0]*self.dim
            den = 0

            for i in range(self.n):
                u = self.U[i][j]**self.m
                for d in range(self.dim):
                    num[d] += u*self.data[i][d]
                den += u

            self.centers[j] = [num[d]/den for d in range(self.dim)]

    def update_U(self):
        for i in range(self.n):
            for j in range(self.k):
                d_ij = self.dist(self.data[i], self.centers[j])
                s = 0

                for k in range(self.k):
                    d_ik = self.dist(self.data[i], self.centers[k]) or 1e-10
                    s += (d_ij/d_ik)**(2/(self.m-1))

                self.U[i][j] = 1/s

    def run(self):
        for _ in range(self.maxIter):
            old = [row[:] for row in self.U]

            self.update_centers()
            self.update_U()

            diff = max(abs(old[i][j]-self.U[i][j]) for i in range(self.n) for j in range(self.k))
            if diff < self.eps:
                break

    def print_result(self):
        print("Centers:")
        for c in self.centers:
            print(c)

        print("
Membership:")
        for row in self.U:
            print(row)


data = [
    [1,2], [1.5,1.8], [5,8],
    [8,8], [1,0.6], [9,11]
]

fcm = FuzzyCMeans(data, 2)
fcm.run()
fcm.print_result()
""")
    
def p9():
    print("""import numpy as np

def fitness(X, centers):
    total = 0
    for x in X:
        dists = np.linalg.norm(x - centers, axis=1)
        total += np.min(dists)
    return total

def pso_clustering(X, n_clusters=2, n_particles=20, max_iter=100):
    n_samples, dim = X.shape

    particles = np.random.rand(n_particles, n_clusters * dim)
    velocities = np.zeros_like(particles)

    pbest = particles.copy()
    pbest_scores = np.array([
        fitness(X, p.reshape(n_clusters, dim)) for p in particles
    ])

    gbest = pbest[np.argmin(pbest_scores)]
    gbest_score = np.min(pbest_scores)

    w = 0.7
    c1 = 1.5
    c2 = 1.5

    for _ in range(max_iter):
        for i in range(n_particles):
            r1 = np.random.rand()
            r2 = np.random.rand()

            velocities[i] = (
                w * velocities[i]
                + c1 * r1 * (pbest[i] - particles[i])
                + c2 * r2 * (gbest - particles[i])
            )

            particles[i] += velocities[i]

            score = fitness(X, particles[i].reshape(n_clusters, dim))

            if score < pbest_scores[i]:
                pbest[i] = particles[i]
                pbest_scores[i] = score

        gbest = pbest[np.argmin(pbest_scores)]
        gbest_score = np.min(pbest_scores)

    centers = gbest.reshape(n_clusters, dim)

    labels = []
    for x in X:
        dists = np.linalg.norm(x - centers, axis=1)
        labels.append(np.argmin(dists))

    return centers, np.array(labels)


if __name__ == "__main__":
    X = np.array([
        [1, 2], [2, 3], [3, 4],
        [8, 8], [9, 9], [10, 10]
    ])

    centers, labels = pso_clustering(X, n_clusters=2)

    print(centers)
    print(labels)
    
""")
    
def p10():
    print("""------------------PSO FOR DOCUMENT CLUSTERING----------------------
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from scipy.optimize import differential_evolution
from sklearn.metrics.pairwise import euclidean_distances

documents = [
    "I love machine learning and artificial intelligence.",
    "Deep learning is a subset of machine learning.",
    "I like baking cakes and making pastries.",
    "Chocolate chip cookies are my favorite baked good."
]

vectorizer = TfidfVectorizer(stop_words='english')
X = vectorizer.fit_transform(documents).toarray()
num_docs, num_features = X.shape

k = 2

#DE algorithms require a 1D array, so we reshape it back into 
#a 2D matrix representing our cluster centroids.
def objective_function(flat_centroids):
    centroids = flat_centroids.reshape((k, num_features))
    distances = euclidean_distances(X, centroids)
    min_distances = np.min(distances, axis=1)
    sse = np.sum(min_distances ** 2)
    return sse

bounds = [(0, 1) for _ in range(k * num_features)]

print("Running Differential Evolution...")
result = differential_evolution(objective_function, bounds, maxiter=50, popsize=10, seed=42)

best_centroids = result.x.reshape((k, num_features))
final_distances = euclidean_distances(X, best_centroids)

cluster_labels = np.argmin(final_distances, axis=1)

print("\n--- Final Clustering Results ---")
for cluster_id in range(k):
    print(f"\nCluster {cluster_id}:")
    for i, label in enumerate(cluster_labels):
        if label == cluster_id:
            print(f" - {documents[i]}")
          
""")