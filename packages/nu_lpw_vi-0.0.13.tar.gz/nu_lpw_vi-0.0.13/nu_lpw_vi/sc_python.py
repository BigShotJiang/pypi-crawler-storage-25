def doc():
  print(r"""
| Function | Description |
|:--------:|-------------|
| p1() | TSP(Brute, NN), 8-Puzzle(Simple, Steepest-Ascent) |
| p2() | 0/1 knapsack GA |
| p3() | Symmetric TSP using GA |
| p4() | Document Clustering using GA |
| p5() | Symmetric TSP using ANT |
| p6() | Document Clustering using ANT |
| p7() | Membership functions for fuzzy set |
| p8() | Fuzzy C Means Algorithm) |

""")

def p1():
    print(r"""
          
import random
import time
import itertools
import csv

# ---------------------- TSP BRUTE ----------------------

def bruteForceTSP(dist, n):
    cities = list(range(1, n))
    best = float('inf')

    for perm in itertools.permutations(cities):
        curr = 0
        prev = 0

        for c in perm:
            curr += dist[prev][c]
            prev = c

        curr += dist[prev][0]
        best = min(best, curr)

    return best


def run_tsp_bruteforce():
    with open("tsp_bruteforce_results.csv", "w", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(["number_of_nodes", "duration", "best_cost"])

        for n in range(2, 14):
            dist = [[0 if i == j else random.randint(1, 100) for j in range(n)] for i in range(n)]

            start = time.time()
            best = bruteForceTSP(dist, n)
            duration = (time.time() - start) * 1e6

            writer.writerow([n, int(duration), best])


# ---------------------- TSP NEAREST NEIGHBOR ----------------------

def tsp_nn(start, node, n, adj, visited):
    visited[node] = True
    cost = 0

    min_node = -1
    min_dist = float('inf')

    for nxt, w in adj[node]:
        if not visited[nxt] and w < min_dist:
            min_node = nxt
            min_dist = w

    if min_node == -1:
        return next(w for v, w in adj[node] if v == start)

    return min_dist + tsp_nn(start, min_node, n, adj, visited)


def run_tsp_nn():
    with open("tsp_nn_results.csv", "w", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(["number_of_nodes", "duration"])

        for n in range(2, 100):
            adj = [[] for _ in range(n)]

            for i in range(n):
                for j in range(n):
                    if i != j:
                        adj[i].append((j, random.randint(1, 100)))

            visited = [False] * n

            start = time.time()
            tsp_nn(0, 0, n, adj, visited)
            duration = time.time() - start

            writer.writerow([n, duration])


# ---------------------- 8 PUZZLE ----------------------

def misplaced_tiles(arr, goal):
    pos = {}
    for i in range(3):
        for j in range(3):
            pos[goal[i][j]] = (i, j)

    cnt = 0
    for i in range(3):
        for j in range(3):
            if arr[i][j] != -1:
                if pos[arr[i][j]] != (i, j):
                    cnt += 1
    return cnt


def manhattan(arr, goal):
    pos = {}
    for i in range(3):
        for j in range(3):
            pos[goal[i][j]] = (i, j)

    dist = 0
    for i in range(3):
        for j in range(3):
            if arr[i][j] != -1:
                x, y = pos[arr[i][j]]
                dist += abs(i - x) + abs(j - y)
    return dist


def rec_dist(row, col, arr, goal, path):
    if arr == goal:
        return True

    moves = [(-1,0,'U'), (0,1,'R'), (1,0,'D'), (0,-1,'L')]
    curr = manhattan(arr, goal)

    for dr, dc, mv in moves:
        nr, nc = row + dr, col + dc
        if 0 <= nr < 3 and 0 <= nc < 3:
            arr[row][col], arr[nr][nc] = arr[nr][nc], arr[row][col]
            new = manhattan(arr, goal)

            if new < curr:
                path.append(mv)
                if rec_dist(nr, nc, arr, goal, path):
                    return True
                path.pop()

            arr[row][col], arr[nr][nc] = arr[nr][nc], arr[row][col]

    return False
""")

def p2():
    print("""
import random

POP_SIZE = 10
GENERATIONS = 200

def randomChromosome(n):
    return [random.randint(0,1) for _ in range(n)]

def fitness(ch, weight, value, capacity):
    totalW = sum(w for i, w in enumerate(weight) if ch[i])
    totalV = sum(value[i] for i in range(len(ch)) if ch[i])
    return totalV if totalW <= capacity else 0

def rouletteSelect(population, fit):
    total = sum(fit)
    if total == 0:
        return random.choice(population)

    r = random.randint(0, total-1)
    curr = 0

    for i in range(len(population)):
        curr += fit[i]
        if curr > r:
            return population[i]

    return population[-1]

def crossover(p1, p2):
    point = random.randint(0, len(p1)-1)
    return p1[:point] + p2[point:], p2[:point] + p1[point:]

def mutate(ch):
    idx = random.randint(0, len(ch)-1)
    ch[idx] ^= 1

def genetic_knapsack(n, weight, value, capacity):
    population = [randomChromosome(n) for _ in range(POP_SIZE)]

    best, bestFit = None, 0

    for _ in range(GENERATIONS):
        fit = [fitness(ch, weight, value, capacity) for ch in population]

        for i in range(POP_SIZE):
            if fit[i] > bestFit:
                bestFit = fit[i]
                best = population[i]

        newPop = []
        while len(newPop) < POP_SIZE:
            p1 = rouletteSelect(population, fit)
            p2 = rouletteSelect(population, fit)

            c1, c2 = crossover(p1, p2)
            mutate(c1)
            mutate(c2)

            newPop.extend([c1, c2])

        population = newPop[:POP_SIZE]

    return best, bestFit
""")

def p3():
    print("""
import random
import itertools

def tsp_ga():
    arr = list(range(1, 11))
    allPerms = list(itertools.permutations(arr))

    population = random.sample(allPerms, 10)

    cost = [...]  # same matrix

    best = None
    bestFitness = float('inf')

    for _ in range(200):
        fit = []

        for p in population:
            curr = sum(cost[p[i]-1][p[i+1]-1] for i in range(9))
            curr += cost[p[-1]-1][p[0]-1]
            fit.append(curr)

            if curr < bestFitness:
                bestFitness = curr
                best = p

        newPop = []
        while len(newPop) < 10:
            weights = [max(fit)-f+1 for f in fit]
            p1 = random.choices(population, weights)[0]
            p2 = random.choices(population, weights)[0]

            cut = random.randint(0, 9)
            child = list(p1[:cut])

            for x in p2:
                if x not in child:
                    child.append(x)

            newPop.append(tuple(child))

        population = newPop

    return best, bestFitness
""")

def p4():
    print("""
import numpy as np
import random
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

documents = [
    "Artificial intelligence and machine learning",
    "Deep learning and neural networks",
    "Football and cricket are popular sports",
    "Sports like football and basketball",
    "AI is transforming the world",
    "Cricket is a famous sport"
]

vectorizer = TfidfVectorizer()
X = vectorizer.fit_transform(documents).toarray()

num_docs = len(documents)

num_clusters = 2
population_size = 10
generations = 50
mutation_rate = 0.1


def create_chromosome():
    return [random.randint(0, num_clusters - 1) for _ in range(num_docs)]


def fitness(chromosome):
    similarity_matrix = cosine_similarity(X)

    intra_sim = inter_sim = 0
    intra_count = inter_count = 0

    for i in range(num_docs):
        for j in range(i + 1, num_docs):
            if chromosome[i] == chromosome[j]:
                intra_sim += similarity_matrix[i][j]
                intra_count += 1
            else:
                inter_sim += similarity_matrix[i][j]
                inter_count += 1

    if intra_count == 0 or inter_count == 0:
        return 0

    return (intra_sim / intra_count) - (inter_sim / inter_count)


def initialize_population():
    return [create_chromosome() for _ in range(population_size)]


def selection(population):
    tournament = random.sample(population, 3)
    tournament.sort(key=lambda x: fitness(x), reverse=True)
    return tournament[0]


def crossover(p1, p2):
    point = random.randint(1, num_docs - 2)
    return p1[:point] + p2[point:]


def mutate(ch):
    for i in range(num_docs):
        if random.random() < mutation_rate:
            ch[i] = random.randint(0, num_clusters - 1)
    return ch


def genetic_algorithm():
    population = initialize_population()
    best_solution = None
    best_fitness = float('-inf')

    for gen in range(generations):
        new_pop = []

        for _ in range(population_size):
            p1 = selection(population)
            p2 = selection(population)

            child = crossover(p1, p2)
            child = mutate(child)

            new_pop.append(child)

        population = new_pop

        for chrom in population:
            f = fitness(chrom)
            if f > best_fitness:
                best_fitness = f
                best_solution = chrom

        print(f"Generation {gen+1}, Best Fitness: {best_fitness:.4f}")

    return best_solution


best = genetic_algorithm()

clusters = {i: [] for i in range(num_clusters)}

for i, c in enumerate(best):
    clusters[c].append(documents[i])

for k, v in clusters.items():
    print(f"\nCluster {k}:")
    for doc in v:
        print("-", doc)

""")

def p5():
    print("""
import random
import math

class AntColonyTSP:
    def __init__(self, dist, ants, iterations):
        self.dist = dist
        self.n = len(dist)
        self.ants = ants
        self.iterations = iterations

        self.alpha = 1.0
        self.beta = 5.0
        self.evap = 0.5
        self.Q = 100

        self.pheromone = [[1.0]*self.n for _ in range(self.n)]

    def tour_length(self, tour):
        return sum(self.dist[tour[i]][tour[i+1]] for i in range(self.n-1)) + self.dist[tour[-1]][tour[0]]

    def select_next(self, curr, visited):
        probs = []
        total = 0

        for j in range(self.n):
            if not visited[j]:
                tau = self.pheromone[curr][j] ** self.alpha
                eta = (1 / self.dist[curr][j]) ** self.beta
                val = tau * eta
                probs.append((j, val))
                total += val

        r = random.uniform(0, total)
        s = 0
        for node, p in probs:
            s += p
            if s >= r:
                return node

        return probs[-1][0]

    def construct_tour(self, start):
        visited = [False]*self.n
        tour = [start]
        visited[start] = True

        curr = start
        for _ in range(self.n-1):
            nxt = self.select_next(curr, visited)
            tour.append(nxt)
            visited[nxt] = True
            curr = nxt

        return tour

    def update_pheromones(self, tours, lengths):
        for i in range(self.n):
            for j in range(self.n):
                self.pheromone[i][j] *= (1 - self.evap)

        for k in range(len(tours)):
            contrib = self.Q / lengths[k]
            tour = tours[k]

            for i in range(self.n-1):
                u, v = tour[i], tour[i+1]
                self.pheromone[u][v] += contrib
                self.pheromone[v][u] += contrib

            self.pheromone[tour[-1]][tour[0]] += contrib
            self.pheromone[tour[0]][tour[-1]] += contrib

    def solve(self):
        best, best_len = None, float('inf')

        for _ in range(self.iterations):
            tours, lengths = [], []

            for k in range(self.ants):
                t = self.construct_tour(k % self.n)
                l = self.tour_length(t)

                tours.append(t)
                lengths.append(l)

                if l < best_len:
                    best, best_len = t, l

            self.update_pheromones(tours, lengths)

        return best, best_len


dist = [
    [0,10,15,20],
    [10,0,35,25],
    [15,35,0,30],
    [20,25,30,0]
]

solver = AntColonyTSP(dist, 10, 100)
print(solver.solve())
""")

def p6():
    print("""
import random
import math

class Document:
    def __init__(self, id, features):
        self.id = id
        self.features = features

class Ant:
    def __init__(self, x, y):
        self.x = x
        self.y = y
        self.carrying = False
        self.doc = None


class AntClustering:
    def __init__(self, gridSize, numAnts, steps):
        self.gridSize = gridSize
        self.numAnts = numAnts
        self.steps = steps
        self.grid = [[None]*gridSize for _ in range(gridSize)]
        self.ants = []

    def distance(self, a, b):
        return math.sqrt(sum((a[i]-b[i])**2 for i in range(len(a))))

    def local_similarity(self, x, y, doc):
        total, count = 0, 0

        for dx in [-1,0,1]:
            for dy in [-1,0,1]:
                nx = (x+dx)%self.gridSize
                ny = (y+dy)%self.gridSize

                if self.grid[nx][ny]:
                    d = self.distance(doc.features, self.grid[nx][ny].features)
                    total += max(0, 1-d)
                    count += 1

        return total/count if count else 0

    def simulate(self):
        for _ in range(self.steps):
            for ant in self.ants:
                x, y = ant.x, ant.y

                if not ant.carrying and self.grid[x][y]:
                    f = self.local_similarity(x,y,self.grid[x][y])
                    if random.random() < (0.1/(0.1+f))**2:
                        ant.doc = self.grid[x][y]
                        ant.carrying = True
                        self.grid[x][y] = None

                elif ant.carrying and not self.grid[x][y]:
                    f = self.local_similarity(x,y,ant.doc)
                    if random.random() < (2*f if f<0.3 else 1):
                        self.grid[x][y] = ant.doc
                        ant.carrying = False

                ant.x = (x + random.choice([-1,0,1])) % self.gridSize
                ant.y = (y + random.choice([-1,0,1])) % self.gridSize
""")

def p7():
    print("""
import math

def triangular(x, a, b, c):
    if x <= a or x >= c: return 0
    if x == b: return 1
    if x < b: return (x-a)/(b-a)
    return (c-x)/(c-b)

def trapezoidal(x, a, b, c, d):
    if x <= a or x >= d: return 0
    if b <= x <= c: return 1
    if x < b: return (x-a)/(b-a)
    return (d-x)/(d-c)

def gaussian(x, mean, sigma):
    return math.exp(-((x-mean)**2)/(2*sigma**2))

def sigmoid(x, a, c):
    return 1/(1+math.exp(-a*(x-c)))

def bell(x, a, b, c):
    return 1/(1 + abs((x-c)/a)**(2*b))


for x in range(11):
    print(x,
          triangular(x,0,5,10),
          trapezoidal(x,0,3,7,10),
          gaussian(x,5,2),
          sigmoid(x,1,5),
          bell(x,2,4,5))
""")

def p8():
    print("""
import random
import math

class FuzzyCMeans:
    def __init__(self, data, k, m=2, maxIter=100, eps=1e-5):
        self.data = data
        self.k = k
        self.m = m
        self.maxIter = maxIter
        self.eps = eps

        self.n = len(data)
        self.dim = len(data[0])

        self.U = [[random.random() for _ in range(k)] for _ in range(self.n)]
        for i in range(self.n):
            s = sum(self.U[i])
            self.U[i] = [x/s for x in self.U[i]]

        self.centers = [[0]*self.dim for _ in range(k)]

    def dist(self, a, b):
        return math.sqrt(sum((a[i]-b[i])**2 for i in range(self.dim)))

    def update_centers(self):
        for j in range(self.k):
            num = [0]*self.dim
            den = 0

            for i in range(self.n):
                u = self.U[i][j]**self.m
                for d in range(self.dim):
                    num[d] += u*self.data[i][d]
                den += u

            self.centers[j] = [num[d]/den for d in range(self.dim)]

    def update_U(self):
        for i in range(self.n):
            for j in range(self.k):
                d_ij = self.dist(self.data[i], self.centers[j])
                s = 0

                for k in range(self.k):
                    d_ik = self.dist(self.data[i], self.centers[k]) or 1e-10
                    s += (d_ij/d_ik)**(2/(self.m-1))

                self.U[i][j] = 1/s

    def run(self):
        for _ in range(self.maxIter):
            old = [row[:] for row in self.U]

            self.update_centers()
            self.update_U()

            diff = max(abs(old[i][j]-self.U[i][j]) for i in range(self.n) for j in range(self.k))
            if diff < self.eps:
                break

    def print_result(self):
        print("Centers:")
        for c in self.centers:
            print(c)

        print("\nMembership:")
        for row in self.U:
            print(row)


data = [
    [1,2], [1.5,1.8], [5,8],
    [8,8], [1,0.6], [9,11]
]

fcm = FuzzyCMeans(data, 2)
fcm.run()
fcm.print_result()
""")