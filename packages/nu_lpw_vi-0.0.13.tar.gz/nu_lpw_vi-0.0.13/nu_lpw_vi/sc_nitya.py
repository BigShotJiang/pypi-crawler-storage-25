def doc():
  print(r"""
| Function | Description |
|:--------:|-------------|
| p1() | TSP(Brute, NN), 8-Puzzle(Simple, Steepest-Ascent) |
| p2() | 0/1 knapsack GA |
| p3() | Symmetric TSP using GA |
| p4() | Document Clustering using GA |
| p5() | Symmetric TSP using ANT |
| p6() | Document Clustering using ANT |
| p7() | Membership functions for fuzzy set |
| p8() | Fuzzy C Means Algorithm) |
| p9() | PSO |

""")

def p1():
    print(r"""
          
import random
import time
import itertools
import csv

# ---------------------- TSP BRUTE ----------------------
dist_mat = np.zeros(shape=(n,n))
for i in range(n):
    for j in range(i):
        dist_mat[i,j] = np.random.randint(10,200)
        dist_mat[j,i] = dist_mat[i,j] 
        if i==j:
            dist_mat[i,j] = 1e9
citys = [i for i in range(n)]
obj=itertools.permutations(citys,n)
i = 0
mincost = 10000000
path = []
for iterations in obj:
    cost = 0
    lis=list(iterations)
    lis.append(0)
    for j  in range(n):
        cost+=dist_mat[lis[j],lis[j+1]]
        
    if mincost > cost:
        path = lis
    mincost = min(mincost , cost)
    print("For path ",lis , " cost is ",cost)
    i+=1
    if i==24:
        break
        
print("Minimum cost Path is",path , " cost is ",mincost)


no_of_city = int(input("Enter number of City?"))
time_taken_brute  = []
for n in range(2,no_of_city):
    start = time.time_ns()
    dist_mat = np.zeros(shape=(n,n))
    for i in range(n):
        for j in range(i):
            dist_mat[i,j] = np.random.randint(10,200)
            dist_mat[j,i] = dist_mat[i,j] 
            if i==j:
                dist_mat[i,j] = 1e9
    
    
    citys = [i for i in range(n)]
    obj=itertools.permutations(citys,n)
    i = 0
    mincost = 10000000
    path = []
    for iterations in obj:
        cost = 0
        lis=list(iterations)
        lis.append(0)
        for j  in range(n):
            cost+=dist_mat[lis[j],lis[j+1]]
            
        if mincost > cost:
            path = lis
        mincost = min(mincost , cost)
        # print("For path ",lis , " cost is ",cost)
        i+=1
        if i==math.factorial(n-1):
            break
    duration = time.time_ns()-start
    time_taken_brute.append(duration)
    print("Minimum cost Path is",path , " cost is ",mincost)
print(time_taken_brute) 





# ---------------------- TSP NEAREST NEIGHBOR ----------------------

import numpy as np
import time

no_of_city = int(input("Enter number of City?"))
time_taken = []

for n in range(2, no_of_city):
    start = time.time_ns()

    dist_mat = np.zeros((n, n))
    for i in range(n):
        for j in range(i):
            dist_mat[i, j] = np.random.randint(10, 200)
            dist_mat[j, i] = dist_mat[i, j]
        dist_mat[i, i] = 1e9  
    
    visited = [False] * n
    path = [0]              
    visited[0] = True
    curr_city = 0
    mincost = 0
  
    for _ in range(n - 1):
        nearest_city = -1
        nearest_dist = 1e18
        for j in range(n):
            if not visited[j] and dist_mat[curr_city][j] < nearest_dist:
                nearest_dist = dist_mat[curr_city][j]
                nearest_city = j
        
        visited[nearest_city] = True
        path.append(nearest_city)
        mincost += nearest_dist
        curr_city = nearest_city
    mincost += dist_mat[curr_city][0]
    path.append(0)
    
    duration = time.time_ns() - start
    time_taken.append(duration)
    
    print("Greedy NN Path is", path, " cost is ", mincost)

print("Time taken:", time_taken)
plt.plot(time_taken)

# ---------------------- 8 PUZZLE ----------------------

# 8 Puzzle using DFS with step printing

GOAL = (
    (0, 1, 2),
    (3, 4, 5),
    (6, 7, 8)
)

# Directions with names
DIRS = [
    (-1, 0, "UP"),
    (1, 0, "DOWN"),
    (0, -1, "LEFT"),
    (0, 1, "RIGHT")
]

def print_state(state):
    for row in state:
        print(row)
    print()

def find_zero(state):
    for i in range(3):
        for j in range(3):
            if state[i][j] == 0:
                return i, j

def is_valid(x, y):
    return 0 <= x < 3 and 0 <= y < 3

def dfs(state, depth, max_depth, visited, path):
    if state == GOAL:
        print(" GOAL REACHED!\n")
        print("Steps Applied:\n")
        for step, board in path:
            print(f"Move: {step}")
            print_state(board)
        return True

    if depth == max_depth:
        return False

    visited.add(state)
    x, y = find_zero(state)

    for dx, dy, move in DIRS:
        nx, ny = x + dx, y + dy

        if is_valid(nx, ny):
            new_state = [list(row) for row in state]
            new_state[x][y], new_state[nx][ny] = new_state[nx][ny], new_state[x][y]
            new_state = tuple(tuple(row) for row in new_state)

            if new_state not in visited:
                path.append((move, new_state))
                if dfs(new_state, depth + 1, max_depth, visited, path):
                    return True

    return False

def solve_8_puzzle(start_state, max_depth=20):
    print("Initial State:\n")
    print_state(start_state)

    visited = set()
    path = [("START", start_state)]

    if not dfs(start_state, 0, max_depth, visited, path):
        print("Solution not found within depth limit")

# Example Start State
start = (
    (1, 0, 2),
    (3, 4, 5),
    (6, 7, 8)
)

solve_8_puzzle(start)





# Hill Climbing

GOAL = (
    (1, 2, 3),
    (8, 0, 4),
    (7, 6, 5)
)

DIRS = [
    (-1, 0, "UP"),
    (1, 0, "DOWN"),
    (0, -1, "LEFT"),
    (0, 1, "RIGHT")
]
goal_pos = {}
for i in range(3):
    for j in range(3):
        if GOAL[i][j] != 0:
            goal_pos[GOAL[i][j]] = (i, j)


def print_state(state):
    for row in state:
        print(row)
    print()

def find_zero(state):
    for i in range(3):
        for j in range(3):
            if state[i][j] == 0:
                return i, j

def heuristic(state):
    cnt = 0
    for i in range(3):
        for j in range(3):
            if state[i][j] != 0 and state[i][j] != GOAL[i][j]:
                cnt += 1
    return cnt
def manhattan_distance(state):
    dist = 0
    for i in range(3):
        for j in range(3):
            val = state[i][j]
            if val != 0:
                gi, gj = goal_pos[val]
                dist += abs(i - gi) + abs(j - gj)
    return dist

        
def is_valid(x, y):
    return 0 <= x < 3 and 0 <= y < 3

def steepest_hill_climbing(start_state, max_steps=50):
    current = start_state
    current_h = heuristic(current)

    print("Initial State:")
    print_state(current)

    for step in range(max_steps):
        if current == GOAL:
            print("GOAL REACHED!")
            return

        x, y = find_zero(current)
        best_state = None
        best_h = current_h

        for dx, dy, move in DIRS:
            nx, ny = x + dx, y + dy
            if is_valid(nx, ny):
                new_state = [list(row) for row in current]
                new_state[x][y], new_state[nx][ny] = new_state[nx][ny], new_state[x][y]
                new_state = tuple(tuple(row) for row in new_state)

                h = heuristic(new_state)

                if h < best_h:   
                    best_h = h
                    best_state = new_state
                    best_move = move
                    

        if best_state is None:
            print(" Stuck at local minimum")
            return

        print(f"Move: {best_move} | Heuristic: {best_h}")
        print_state(best_state)

        current = best_state
        current_h = best_h

    print("Max steps reached")


def steepest_hill_climbing_with_manhattan_distance(start_state, max_steps=50):
    current = start_state
    current_h = manhattan_distance(current)

    print(f"Initial State:" + " " + "Heuristic :",current_h)
    print_state(current)

    for step in range(max_steps):
        if current == GOAL:
            print(" GOAL REACHED!")
            return

        x, y = find_zero(current)
        best_state = None
        best_h = current_h

        for dx, dy, move in DIRS:
            nx, ny = x + dx, y + dy
            if is_valid(nx, ny):
                new_state = [list(row) for row in current]
                new_state[x][y], new_state[nx][ny] = new_state[nx][ny], new_state[x][y]
                new_state = tuple(tuple(row) for row in new_state)

                h = manhattan_distance(new_state)

                if h < best_h:   
                    best_h = h
                    best_state = new_state
                    best_move = move
                    

        if best_state is None:
            print(" Stuck at local minimum")
            return

        print(f"Move: {best_move} | Heuristic: {best_h}")
        print_state(best_state)

        current = best_state
        current_h = best_h

    print("Max steps reached")
    
def simple_hill_climbing(start_state, max_steps=50):
    current = start_state
    current_h = heuristic(current)

    print("Initial State:")
    print_state(current)

    for step in range(max_steps):
        if current == GOAL:
            print("🎯 GOAL REACHED!")
            return

        x, y = find_zero(current)
        moved = False

        for dx, dy, move in DIRS:
            nx, ny = x + dx, y + dy
            if is_valid(nx, ny):
                new_state = [list(row) for row in current]
                new_state[x][y], new_state[nx][ny] = new_state[nx][ny], new_state[x][y]
                new_state = tuple(tuple(row) for row in new_state)

                h = heuristic(new_state)
                

                if h < current_h:
                    print(f"Move: {move} | Heuristic: {h}")
                    print_state(new_state)
                    current = new_state
                    current_h = h
                    moved = True
                    break
        if not moved:
            print(" Stuck at local minimum")
            return

        

    print("Max steps reached")
def simple_hill_climbing_with_manhattan(start_state, max_steps=50):
    current = start_state
    current_h = manhattan_distance(current)

    print("Initial State:")
    print_state(current)

    for step in range(max_steps):
        if current == GOAL:
            print("🎯 GOAL REACHED!")
            return

        x, y = find_zero(current)
        moved = False
        

        for dx, dy, move in DIRS:
            nx, ny = x + dx, y + dy
            if is_valid(nx, ny):
                new_state = [list(row) for row in current]
                new_state[x][y], new_state[nx][ny] = new_state[nx][ny], new_state[x][y]
                new_state = tuple(tuple(row) for row in new_state)

                h = manhattan_distance(new_state)
                

                if h < current_h:
                    print(f"Move: {move} | Heuristic: {h}")
                    print_state(new_state)
                    current = new_state
                    current_h = h
                    moved = True
                    break
        if not moved:
            print(" Stuck at local minimum")
            return

        

    print("Max steps reached")


# Example Start State
start = (
    (2, 8, 3),
    (1, 6, 4),
    (7, 0, 5)
)

# simple_hill_climbing(start)
# simple_hill_climbing_with_manhattan(start)
# steepest_hill_climbing(start)
# steepest_hill_climbing_with_manhattan_distance(start)
print("\nChoose Algorithm:")
print("1. Simple Hill Climbing (Misplaced Tiles)")
print("2. Simple Hill Climbing (Manhattan Distance)")
print("3. Steepest Hill Climbing (Misplaced Tiles)")
print("4. Steepest Hill Climbing (Manhattan Distance)")

choice = int(input("Enter your choice (1-4): "))
match choice:
    case 1:
        simple_hill_climbing(start)
    case 2:
        simple_hill_climbing_with_manhattan(start)
    case 3:
        steepest_hill_climbing(start)
    case 4:
        steepest_hill_climbing_with_manhattan_distance(start)
    case _:
        print("Invalid choice")



""")

def p2():
    print("""
# %%
import random


weights = [2, 3, 4, 5, 9, 7, 6, 1, 8, 10]   
values  = [6, 8,7,12,20,15,14,3,18,22]
capacity = 25

NUM_ITEMS = 10
POP_SIZE = 10
NUM_CHILDREN = 5

# %%
def random_chromosome():
    return [random.randint(0, 1) for _ in range(NUM_ITEMS)]

# %%
def fitness(chromosome):
    total_weight = 0
    total_value = 0
    
    for i in range(NUM_ITEMS):
        if chromosome[i] == 1:
            total_weight += weights[i]
            total_value += values[i]
    
    if total_weight > capacity:
        return 0
    
    return total_value

# %%
import random

def roulette_selection(population, fitnesses):

    total_fitness = sum(fitnesses)
    if total_fitness == 0:
        return random.choice(population)
    r = random.uniform(0, total_fitness)
    cumulative_sum = 0

    for i in range(len(population)):
        cumulative_sum += fitnesses[i]
        if cumulative_sum >= r:
            return population[i]


# %%
def crossover(parent1, parent2):
    point = random.randint(1, NUM_ITEMS - 1)
    child = parent1[:point] + parent2[point:]
    return child

# %%

def multipoint_crossover(parent1, parent2):
    n = len(parent1)
    p1 = random.randint(1, n-2)
    p2 = random.randint(p1+1, n-1)

    # child: P1 | P2 | P1
    child = parent1[:p1] + parent2[p1:p2] + parent1[p2:]
    return child

# %%
def k_point_crossover(parent1, parent2, k=3):
    n = len(parent1)
    points = sorted(random.sample(range(1, n), k))
    points = [0] + points + [n]
    child = []
    take_from_p1 = True
    for i in range(len(points)-1):
        start = points[i]
        end = points[i+1]
        if take_from_p1:
            child += parent1[start:end]
        else:
            child += parent2[start:end]
        take_from_p1 = not take_from_p1

    return child

# %%

population = [random_chromosome() for _ in range(POP_SIZE)]

print("Initial Population:")
for i, ch in enumerate(population):
    print(f"P{i}:", ch)


# %%
maxi = 0
fitnesses = [fitness(ch) for ch in population]

print("\nFitness of Population:")
for i, f in enumerate(fitnesses):
    maxi = max(maxi,f)
    print(f"P{i} Fitness:", f)

# %%
children = []

for i in range(NUM_CHILDREN):
    parent1 = roulette_selection(population, fitnesses)
    parent2 = roulette_selection(population, fitnesses)
    
    child = crossover(parent1, parent2)
    child_1 = k_point_crossover(parent1,parent2,3)
    children.append(child)
    children.append(child_1)

    print(f"\nChild {i+1}")
    print("Parent1:", parent1)
    print("Parent2:", parent2)
    print("Child  :", child)
    print("Child (MultiPoint CrossOver) :", child_1)

# %%
print("\nGenerated 5 New Solutions:")
for i, ch in enumerate(children):
    
    print(f"Child{i+1}:", ch)


# %%
fitnesses = [fitness(ch) for ch in children]

print("\nFitness of Population:")
for i, f in enumerate(fitnesses):
    maxi= max(maxi,f)
    print(f"P{i} Fitness:", f)

# %%
print("Maximum fitness",maxi)

# %%
import random

def mutate(chromosome):
    index = random.randint(0, len(chromosome) - 1)
    chromosome[index] = 1 - chromosome[index]
    return chromosome


# %%
num_to_mutate = random.choice([2, 3])
indexes = random.sample(range(len(children)), num_to_mutate)

print("Indexes selected for mutation:", indexes)


# %%
mutated_children = []

for i in range(200):
    
    for idx in indexes:
        original = children[idx].copy()
        mutated = mutate(children[idx].copy())
        mutated_children.append(mutated)

        print("\nOriginal :", original)
        print("Mutated  :", mutated)


# %%
print("\nFitness of Mutated Children:")
for i, ch in enumerate(mutated_children):
    f = fitness(ch)
    maxi = max(maxi,f)
    print(f"Mutated Child {i+1} Fitness:", f)
maxi

""")

def p3():
    print("""
# %%
import itertools
import time
import numpy as np
# import matplotlib.pyplot as plt

# %%
dist_mat = [
    [0, 29, 20, 21, 16, 31, 100, 12, 4, 31],
    [29, 0, 15, 29, 28, 40, 72, 21, 29, 41],
    [20, 15, 0, 15, 14, 25, 81, 9, 23, 27],
    [21, 29, 15, 0, 4, 12, 92, 12, 25, 13],
    [16, 28, 14, 4, 0, 16, 94, 9, 20, 16],
    [31, 40, 25, 12, 16, 0, 95, 24, 36, 3],
    [100, 72, 81, 92, 94, 95, 0, 90, 101, 99],
    [12, 21, 9, 12, 9, 24, 90, 0, 15, 25],
    [4, 29, 23, 25, 20, 36, 101, 15, 0, 35],
    [31, 41, 27, 13, 16, 3, 99, 25, 35, 0]
]


# %%
cities = [i for i in range(10)]

# %%
cities

# %%
import random
population = random.sample(list(itertools.permutations(cities)), 10)
population

# %%
population = []
for _ in range(10):
    route = cities[:]
    random.shuffle(route)
    population.append(route)
population

# %%
def route_cost(route, dist):
    cost = 0
    for i in range(len(route)-1):
        cost += dist[route[i]][route[i+1]]
    
    cost += dist[route[-1]][route[0]]
    return cost


# %%
path = []
min_cost = 1000000
for r in population:
    print(r, "Cost:", route_cost(r, dist_mat),"Fitness:",1/route_cost(r, dist_mat))
    cost = route_cost(r,dist_mat)
    if(cost < min_cost):
        path = r
        min_cost = cost
print("Path : ",path,"Minimum_cost :" , min_cost )
    


# %%
fitness = []
for r in population:
    cost = route_cost(r, dist_mat)
    fitness.append(1 / cost)


# %%
import random

def roulette_selection(population, fitnesses):

    total_fitness = sum(fitnesses)
    if total_fitness == 0:
        return random.choice(population)
    r = random.uniform(0, total_fitness)
    cumulative_sum = 0

    for i in range(len(population)):
        cumulative_sum += fitnesses[i]
        if cumulative_sum >= r:
            return population[i]

# %%

def tournament_selection(population, fitness, k=3):
    n = len(population)

    best_index = random.randint(0, n-1)

    for _ in range(k-1):
        i = random.randint(0, n-1)
        if fitness[i] > fitness[best_index]:
            best_index = i

    return population[best_index]

# %%


# %%
import random

def rank_selection(population, fitness):
    n = len(population)

    idx = list(range(n))

    for i in range(n):
        for j in range(i+1, n):
            if fitness[idx[i]] > fitness[idx[j]]:
                idx[i], idx[j] = idx[j], idx[i]

    total_rank = n * (n + 1) // 2
    r = random.randint(1, total_rank)

    current = 0
    for rank in range(1, n+1):
        current += rank
        if current >= r:
            return population[idx[rank-1]]


# %%
def sus_multiple(population, fitness, num_select):
    n = len(population)
    total_fitness = sum(fitness)

    if total_fitness == 0:
        return random.sample(population, num_select)

    step = total_fitness / num_select
    start = random.uniform(0, step)

    pointers = []
    for i in range(num_select):
        pointers.append(start + i * step)

    parents = []
    cumulative = 0
    idx = 0

    for p in pointers:
        while cumulative < p:
            cumulative += fitness[idx]
            idx += 1
        parents.append(population[idx-1])

    return parents


# %%
import random

def single_point_crossover(parent1, parent2):
    n = len(parent1)

    cut = random.randint(1, n-1)

    child = parent1[:cut]

    for city in parent2:
        if city not in child:
            child.append(city)

    return child


# %%
for i in range(5):
    parent1 = roulette_selection(population, fitness)
    parent2 = roulette_selection(population, fitness)

    print("Parent 1:", parent1)
    print("Parent 2:", parent2)
    child = single_point_crossover(parent1, parent2)
    cost = route_cost(child,dist_mat)
    if(cost < min_cost):
        path = child
        min_cost = cost
    print("Child:",child ,"Cost :",cost )
print("Path : ",path,"Minimum_cost :" , min_cost )


# %%
for i in range(5):
    parent1 = tournament_selection(population, fitness)
    parent2 = tournament_selection(population, fitness)

    print("Parent 1:", parent1)
    print("Parent 2:", parent2)
    child = single_point_crossover(parent1, parent2)
    cost = route_cost(child,dist_mat)
    if(cost < min_cost):
        path = child
        min_cost = cost
    print("Child:",child ,"Cost :",cost )
print("Path : ",path,"Minimum_cost :" , min_cost )


# %%
for i in range(5):
    parent1 = rank_selection(population, fitness)
    parent2 = rank_selection(population, fitness)

    print("Parent 1:", parent1)
    print("Parent 2:", parent2)
    child = single_point_crossover(parent1, parent2)
    cost = route_cost(child,dist_mat)
    if(cost < min_cost):
        path = child
        min_cost = cost
    print("Child:",child ,"Cost :",cost )
print("Path : ",path,"Minimum_cost :" , min_cost )


# %%
for i in range(5):
    parents = sus_multiple(population,fitness,2)
    parent1= parents[0]
    parent2= parents[1]
    print("Parent 1:", parent1)
    print("Parent 2:", parent2)
    child = single_point_crossover(parent1, parent2)
    cost = route_cost(child,dist_mat)
    if(cost < min_cost):
        path = child
        min_cost = cost
    print("Child:",child ,"Cost :",cost )
print("Path : ",path,"Minimum_cost :" , min_cost )


# %%




""")

def p4():
    print("""
# %%
import random
import math
from sklearn.feature_extraction.text import TfidfVectorizer


# %%
documents = [

    # ================= TECHNOLOGY =================

    "Artificial intelligence and machine learning are advanced technologies used in computer science to build intelligent systems capable of automation, data analysis, pattern recognition, and smart decision making in real world applications",

    "Machine learning algorithms such as supervised learning, unsupervised learning, and deep learning help computers automatically learn from large datasets and improve prediction accuracy without explicit programming",

    "Cybersecurity focuses on protecting computer systems, networks, and sensitive digital information from cyber attacks, hacking, malware, phishing, and unauthorized access using encryption and security protocols",

    "Software development involves designing, programming, coding, testing, debugging, and deploying software applications using programming languages such as Python, Java, C++, and modern development frameworks",

    "Cloud computing provides scalable computing infrastructure, virtual machines, storage, and software services over the internet, enabling organizations to efficiently manage data and applications remotely",


    # ================= SPORTS =================

    "Football is a globally popular team sport where players use their physical strength, passing skills, and strategic teamwork to score goals by kicking the ball into the opponent goalpost",

    "Cricket is a competitive outdoor sport where players use a bat and ball, and teams score runs by hitting the ball and running between wickets while bowlers attempt to dismiss batsmen",

    "Basketball is played on a rectangular court where players dribble, pass, and shoot the ball into a basket to score points using coordination, agility, and teamwork",

    "Athletes follow structured physical training programs, fitness exercises, and endurance workouts to improve strength, speed, stamina, and overall sports performance",

    "Olympic games are international sports events where professional athletes from different countries compete in running, swimming, gymnastics, athletics, and various competitive sports disciplines",


    # ================= MEDICAL =================

    "Doctors diagnose diseases and medical conditions by analyzing symptoms, conducting clinical examinations, and using medical equipment to provide proper healthcare treatment to patients",

    "Vaccines strengthen the immune system and protect the human body from infectious diseases, viruses, and harmful pathogens by improving immunity and preventing illness",

    "Hospitals provide essential healthcare services including medical treatment, surgery, emergency care, patient monitoring, and specialized healthcare support",

    "Medical research focuses on studying human diseases, developing new medicines, improving treatments, and advancing healthcare technology to enhance patient recovery",

    "Healthy lifestyle practices including proper nutrition, regular exercise, and preventive medical care help maintain physical health, mental well being, and disease prevention",


    # ================= FINANCE =================

    "Banks provide financial services such as savings accounts, loans, credit facilities, money transfers, and secure financial transactions for individuals and businesses",

    "Investing in stock markets, mutual funds, bonds, and financial assets helps individuals grow wealth, generate returns, and achieve long term financial stability",

    "Stock market allows investors to buy and sell company shares, analyze financial performance, and earn profits based on market trends and investment strategies",

    "Financial planning involves managing personal income, expenses, savings, investments, and financial risks to achieve financial security and economic stability",

    "Financial institutions provide secure systems for money storage, digital payments, online banking, and financial management services",


    # ================= EDUCATION =================

    "Education helps students acquire knowledge, develop intellectual abilities, critical thinking skills, and professional competencies through academic learning",

    "Teachers play an important role in providing instruction, explaining concepts, guiding students, and improving their academic performance and learning outcomes",

    "Schools, colleges, and universities provide structured educational programs, academic courses, and degree qualifications for student career development",

    "Higher education institutions focus on advanced learning, professional training, academic research, and career preparation for students",

    "Online learning platforms provide digital education, virtual classrooms, interactive courses, and flexible learning opportunities using internet technology"
]


# %%
vectorizer = TfidfVectorizer()

tfidf_matrix = vectorizer.fit_transform(documents)

data = tfidf_matrix.toarray()

num_docs = len(data)

num_clusters = 5



# %%
from gensim.models import Word2Vec
import numpy as np

# tokenize documents
tokenized_docs = [doc.lower().split() for doc in documents]

# train Word2Vec model
model = Word2Vec(tokenized_docs, vector_size=100, window=5)

# convert document to vector
def document_vector(doc):

    words = doc.lower().split()

    vectors = []

    for word in words:
        vectors.append(model.wv[word])

    return np.mean(vectors, axis=0)

# create document vectors
data = []

for doc in documents:
    data.append(document_vector(doc))

data = np.array(data)

print(data.shape)


# %%


# %%
from sentence_transformers import SentenceTransformer

model = SentenceTransformer('all-MiniLM-L6-v2')

data = model.encode(documents)

print(data.shape)


# %%
!python --version


# %%
def distance(v1, v2):

    sum = 0

    for i in range(len(v1)):
        sum += (v1[i] - v2[i])**2

    return math.sqrt(sum)


# %%
def create_chromosome():

    chromosome = []

    for i in range(num_docs):
        chromosome.append(random.randint(0, num_clusters-1))

    return chromosome


# %%
population_size = 10

def create_population():

    population = []

    for i in range(population_size):
        population.append(create_chromosome())

    return population


# %%
def centroid(cluster_docs):

    length = len(cluster_docs[0])

    center = [0]*length

    for doc in cluster_docs:
        for i in range(length):
            center[i] += doc[i]

    for i in range(length):
        center[i] /= len(cluster_docs)

    return center


# %%
def fitness(chromosome):

    total_distance = 0

    for cluster in range(num_clusters):

        cluster_docs = []

        for i in range(num_docs):

            if chromosome[i] == cluster:
                cluster_docs.append(data[i])

        if len(cluster_docs) == 0:
            continue

        center = centroid(cluster_docs)

        for doc in cluster_docs:
            total_distance += distance(doc, center)

    if total_distance == 0:
        return 999999

    return 1 / total_distance


# %%
def selection(population):

    population.sort(key=lambda x: fitness(x), reverse=True)

    return population[0], population[1]


# %%
def crossover(parent1, parent2):

    point = random.randint(1, num_docs-1)

    child = parent1[:point] + parent2[point:]

    return child


# %%

def mutation(chromosome):

    new = chromosome.copy()

    for i in range(num_docs):

        new[i] = random.randint(0, num_clusters-1)

    return new


# %%
generations = 100

population = create_population()

for gen in range(generations):

    parent1, parent2 = selection(population)

    new_population = [parent1, parent2]

    while len(new_population) < population_size:

        child = crossover(parent1, parent2)

        child = mutation(child)

        new_population.append(child)

    population = new_population
    best = selection(population)[0]

    print("Generation:", gen, "Fitness:", fitness(parent1))


# %%
best = selection(population)[0]

print("\nFinal Clusters:\n")

for cluster in range(num_clusters):

    print("Cluster", cluster, ":")

    for i in range(num_docs):

        if best[i] == cluster:
            print("-", documents[i])

    print()


# %%


# %%




""")

def p5():
    print("""
# %%
import numpy as np
import random

# Number of cities
n = 6

# Create symmetric distance matrix
dist_mat = np.zeros((n, n))

for i in range(n):
    for j in range(i):
        rnd = np.random.randint(10, 200)
        dist_mat[i, j] = rnd
        dist_mat[j, i] = rnd

# Make diagonal very large (no self-loop)
for i in range(n):
    dist_mat[i, i] = 1e9

print("Distance Matrix:\n", dist_mat)

# %%
num_ants = 10
num_iterations = 50
alpha = 1          
rho = 0.5          

pheromone = np.random.rand(n, n) * 0.1

# %%
def select_next_city(current_city, visited):
    probabilities = []
    
    for j in range(n):
        if j not in visited:
            prob = pheromone[current_city, j] ** alpha
        else:
            prob = 0
        probabilities.append(prob)

    probabilities = np.array(probabilities)

    if probabilities.sum() == 0:
        return random.choice([city for city in range(n) if city not in visited])

    probabilities = probabilities / probabilities.sum()

    return np.random.choice(range(n), p=probabilities)

# %%
def construct_solution():
    all_paths = []
    all_lengths = []

    for k in range(num_ants):
        start = random.randint(0, n-1)
        path = [start]
        visited = set(path)

        while len(path) < n:
            current = path[-1]
            next_city = select_next_city(current, visited)
            path.append(next_city)
            visited.add(next_city)

        # Return to start (TSP)
        path.append(start)

        # Compute length
        length = 0
        for i in range(len(path)-1):
            length += dist_mat[path[i], path[i+1]]

        all_paths.append(path)
        all_lengths.append(length)

    return all_paths, all_lengths

# %%
def evaporate_pheromone():
    global pheromone
    pheromone = (1 - rho) * pheromone

# %%
def deposit_pheromone(paths, lengths):
    global pheromone

    for k in range(num_ants):
        path = paths[k]
        length = lengths[k]

        for i in range(len(path)-1):
            a = path[i]
            b = path[i+1]

            pheromone[a, b] += 1.0 / length
            pheromone[b, a] += 1.0 / length

# %%
best_path = None
best_length = float('inf')

for iteration in range(num_iterations):

    paths, lengths = construct_solution()

    # Update best solution
    min_length = min(lengths)
    if min_length < best_length:
        best_length = min_length
        best_path = paths[lengths.index(min_length)]

    evaporate_pheromone()
    deposit_pheromone(paths, lengths)

    print(f"Iteration {iteration+1}, Best Length: {best_length}")

print("\nFinal Best Path:", best_path)
print("Final Best Length:", best_length)

# %%




""")

def p6():
    print("""
# %%
import numpy as np
import random
from sklearn.datasets import load_iris
from sklearn.preprocessing import MinMaxScaler

# %%
iris = load_iris()
data = iris.data   
labels = iris.target


scaler = MinMaxScaler()
data = scaler.fit_transform(data)

items = [
    {
        "id": i,
        "features": data[i],
        "label": labels[i]
    }
    for i in range(len(data))
]

# %%
GRID_SIZE = 24

grid = [[None for _ in range(GRID_SIZE)] for _ in range(GRID_SIZE)]

# %%
positions = [(i, j) for i in range(GRID_SIZE) for j in range(GRID_SIZE)]
random.shuffle(positions)

for idx in range(len(items)):
    item = items[idx]
    x, y = positions[idx]
    grid[x][y] = item

# %%
initial_positions = {}

for i in range(GRID_SIZE):
    for j in range(GRID_SIZE):
        if grid[i][j] is not None:
            initial_positions[grid[i][j]["id"]] = (i, j)

# %%
class Ant:
    def __init__(self, grid_size):
        self.x = random.randint(0, grid_size - 1)
        self.y = random.randint(0, grid_size - 1)
        self.carrying = None

# %%
NUM_ANTS = 15
ants = [Ant(GRID_SIZE) for _ in range(NUM_ANTS)]

# %%
PATCH_SIZE = 7
ALPHA = 1.0   # scaling constant
def distance(a, b):
    return np.linalg.norm(a - b)

# %%
def compute_lambda(grid, x, y):
    item = grid[x][y]
    if item is None:
        return 0

    features_a = item["features"]

    half = PATCH_SIZE // 2
    neighbors = []

    for i in range(x - half, x + half + 1):
        for j in range(y - half, y + half + 1):
            if 0 <= i < GRID_SIZE and 0 <= j < GRID_SIZE:
                if grid[i][j] is not None:
                    neighbors.append(grid[i][j]["features"])

    if len(neighbors) == 0:
        return 0

    total = 0
    for nb in neighbors:
        d = distance(features_a, nb)
        total += max(0, 1 - d / ALPHA)

    return total / (PATCH_SIZE * PATCH_SIZE)

# %%
GAMMA1 = 0.05   # pickup threshold
GAMMA2 = 0.5    # drop threshold
def pickup_prob(lmbda):
    return (GAMMA1 / (GAMMA1 + lmbda)) ** 2


def drop_prob(lmbda):
    if lmbda < GAMMA2:
        return 2 * lmbda
    else:
        return 1

# %%
def move_ant(ant):
    dx, dy = random.choice([
        (-1, 0), (1, 0),     # up, down
        (0, -1), (0, 1),     # left, right
        (-1, -1), (-1, 1),   # diagonals
        (1, -1), (1, 1)
    ])

    ant.x = (ant.x + dx) % GRID_SIZE
    ant.y = (ant.y + dy) % GRID_SIZE

# %%
ITERATIONS = 50000

for t in range(ITERATIONS):
    for ant in ants:

        x, y = ant.x, ant.y
        cell_item = grid[x][y]

        if ant.carrying is None and cell_item is not None:
            lmbda = compute_lambda(grid, x, y)
            if random.random() < pickup_prob(lmbda):
                ant.carrying = cell_item
                grid[x][y] = None

        elif ant.carrying is not None and cell_item is None:
            grid[x][y] = ant.carrying
            lmbda = compute_lambda(grid, x, y)
            grid[x][y] = None

            if random.random() < drop_prob(lmbda):
                grid[x][y] = ant.carrying
                ant.carrying = None

        move_ant(ant)


# %%
final_positions = {}

for i in range(GRID_SIZE):
    for j in range(GRID_SIZE):
        if grid[i][j] is not None:
            final_positions[grid[i][j]["id"]] = (i, j)


# %%
initial_grid = np.full((GRID_SIZE, GRID_SIZE), -1)
for item_id, (x, y) in initial_positions.items():
    initial_grid[x][y] = labels[item_id]

final_grid = np.full((GRID_SIZE, GRID_SIZE), -1)
for i in range(GRID_SIZE):
    for j in range(GRID_SIZE):
        if grid[i][j] is not None:
            final_grid[i][j] = grid[i][j]["label"]

# %%
import matplotlib.pyplot as plt

plt.figure(figsize=(12, 5))

plt.subplot(1, 2, 1)
plt.imshow(initial_grid, cmap='viridis')
plt.title("Initial Positions")
plt.colorbar()

plt.subplot(1, 2, 2)
plt.imshow(final_grid, cmap='viridis')
plt.title("Final Clusters")
plt.colorbar()

plt.show()


# %%



""")

def p7():
    print("""
import math

def triangular(x, a, b, c):
    if x <= a or x >= c: return 0
    if x == b: return 1
    if x < b: return (x-a)/(b-a)
    return (c-x)/(c-b)

def trapezoidal(x, a, b, c, d):
    if x <= a or x >= d: return 0
    if b <= x <= c: return 1
    if x < b: return (x-a)/(b-a)
    return (d-x)/(d-c)

def gaussian(x, mean, sigma):
    return math.exp(-((x-mean)**2)/(2*sigma**2))

def sigmoid(x, a, c):
    return 1/(1+math.exp(-a*(x-c)))

def bell(x, a, b, c):
    return 1/(1 + abs((x-c)/a)**(2*b))


for x in range(11):
    print(x,
          triangular(x,0,5,10),
          trapezoidal(x,0,3,7,10),
          gaussian(x,5,2),
          sigmoid(x,1,5),
          bell(x,2,4,5))
""")

def p8():
    print("""
import numpy as np

def initialize_membership(n_samples, n_clusters):
    U = np.random.rand(n_samples, n_clusters)

    # Normalize each row using loops so memberships sum to 1
    for i in range(n_samples):
        row_sum = 0.0
        for j in range(n_clusters):
            row_sum += U[i][j]

        if row_sum == 0:
            for j in range(n_clusters):
                U[i][j] = 1.0 / n_clusters
        else:
            for j in range(n_clusters):
                U[i][j] = U[i][j] / row_sum

    return U

def compute_centers(X, U, m):
    n_samples = X.shape[0]
    n_features = X.shape[1]
    n_clusters = U.shape[1]

    centers = np.zeros((n_clusters, n_features))

    for j in range(n_clusters):
        numerator = np.zeros(n_features)
        denominator = 0.0

        for i in range(n_samples):
            weight = U[i][j] ** m
            denominator += weight
            for f in range(n_features):
                numerator[f] += weight * X[i][f]

        if denominator != 0:
            for f in range(n_features):
                centers[j][f] = numerator[f] / denominator

    return centers

def update_membership(X, centers, m):
    n = X.shape[0]
    c = centers.shape[0]
    U = np.zeros((n, c))

    for i in range(n):
        for j in range(c):
            denom = 0
            for k in range(c):
                dist_ratio = np.linalg.norm(X[i] - centers[j]) / (np.linalg.norm(X[i] - centers[k]) + 1e-10)
                denom += dist_ratio ** (2 / (m - 1))
            U[i][j] = 1 / denom

    return U

def membership_change(U_new, U_old):
    total = 0.0
    rows, cols = U_new.shape
    for i in range(rows):
        for j in range(cols):
            diff = U_new[i][j] - U_old[i][j]
            total += diff * diff
    return total ** 0.5

def fuzzy_c_means(X, n_clusters=3, m=2, max_iter=100, tol=1e-5):
    n_samples = X.shape[0]
    U = initialize_membership(n_samples, n_clusters)

    for iteration in range(max_iter):
        U_old = U.copy()

        centers = compute_centers(X, U, m)
        U = update_membership(X, centers, m)

        if membership_change(U, U_old) < tol:
            break

    return centers, U

# ===========================
# Example usage
# ===========================
if __name__ == "__main__":
    X = np.array([
        [1, 2], [2, 3], [3, 4],
        [8, 8], [9, 9], [10, 10]
    ])

    centers, U = fuzzy_c_means(X, n_clusters=2)

    print("Cluster Centers:\n", centers)
    print("\nMembership Matrix:\n", U)
""")
    
def p9():
    print("""import numpy as np

def fitness(X, centers):
    total = 0
    for x in X:
        dists = np.linalg.norm(x - centers, axis=1)
        total += np.min(dists)
    return total

def pso_clustering(X, n_clusters=2, n_particles=20, max_iter=100):
    n_samples, dim = X.shape

    particles = np.random.rand(n_particles, n_clusters * dim)
    velocities = np.zeros_like(particles)

    pbest = particles.copy()
    pbest_scores = np.array([
        fitness(X, p.reshape(n_clusters, dim)) for p in particles
    ])

    gbest = pbest[np.argmin(pbest_scores)]
    gbest_score = np.min(pbest_scores)

    w = 0.7
    c1 = 1.5
    c2 = 1.5

    for _ in range(max_iter):
        for i in range(n_particles):
            r1 = np.random.rand()
            r2 = np.random.rand()

            velocities[i] = (
                w * velocities[i]
                + c1 * r1 * (pbest[i] - particles[i])
                + c2 * r2 * (gbest - particles[i])
            )

            particles[i] += velocities[i]

            score = fitness(X, particles[i].reshape(n_clusters, dim))

            if score < pbest_scores[i]:
                pbest[i] = particles[i]
                pbest_scores[i] = score

        gbest = pbest[np.argmin(pbest_scores)]
        gbest_score = np.min(pbest_scores)

    centers = gbest.reshape(n_clusters, dim)

    labels = []
    for x in X:
        dists = np.linalg.norm(x - centers, axis=1)
        labels.append(np.argmin(dists))

    return centers, np.array(labels)


if __name__ == "__main__":
    X = np.array([
        [1, 2], [2, 3], [3, 4],
        [8, 8], [9, 9], [10, 10]
    ])

    centers, labels = pso_clustering(X, n_clusters=2)

    print(centers)
    print(labels)
    
    """)