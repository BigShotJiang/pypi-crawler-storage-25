# governor-core

The engine package — detection rules, solution generation, ADK agents, shadow validation, dbt uv-runner, GCP / GitHub clients, ORM models for all engine-owned tables.

Pure library. No FastAPI, no Typer, no HTTP, no CLI, no authentication. Imported by `governor-web` and `governor-cli`.

See [specs/120-monorepo-split/contracts/package-boundaries.md](../../specs/120-monorepo-split/contracts/package-boundaries.md) for the public import surface.
