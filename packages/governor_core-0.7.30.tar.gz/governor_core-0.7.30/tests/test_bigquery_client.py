"""Tests for BigQuery client functions in app/gcp/clients.py"""

from __future__ import annotations

from datetime import datetime
from unittest.mock import MagicMock, patch

import pytest
from google.api_core.exceptions import GoogleAPIError

from governor_core.gcp.clients import (
    GCPCredentialsError,
    dry_run_partition_cluster_ddl,
    get_bigquery_client,
    query_information_schema_jobs,
    query_table_storage,
)


def test_get_bigquery_client_success():
    """Test successful BigQuery client creation with valid credentials."""
    with patch("governor_core.gcp.clients.google.auth.default") as mock_default:
        mock_default.return_value = ("mock_creds", "mock_project")
        with patch("google.cloud.bigquery.Client") as mock_client_cls:
            client = get_bigquery_client()
            mock_client_cls.assert_called_once_with(
                credentials="mock_creds", project="mock_project", location=None
            )
            assert client == mock_client_cls.return_value


def test_get_bigquery_client_with_explicit_project():
    """Test BigQuery client creation with explicitly provided project."""
    with patch("governor_core.gcp.clients.google.auth.default") as mock_default:
        mock_default.return_value = ("mock_creds", "default_project")
        with patch("google.cloud.bigquery.Client") as mock_client_cls:
            client = get_bigquery_client(project_id="explicit_project")
            # Explicit project should override default
            mock_client_cls.assert_called_once_with(
                credentials="mock_creds", project="explicit_project", location=None
            )
            assert client == mock_client_cls.return_value


def test_get_bigquery_client_with_location():
    """Spec 136: location is forwarded to the BigQuery client so queries
    default to the right region (australia-southeast1, etc.)."""
    with patch("governor_core.gcp.clients.google.auth.default") as mock_default:
        mock_default.return_value = ("mock_creds", "mock_project")
        with patch("google.cloud.bigquery.Client") as mock_client_cls:
            get_bigquery_client(location="australia-southeast1")
            mock_client_cls.assert_called_once_with(
                credentials="mock_creds",
                project="mock_project",
                location="australia-southeast1",
            )


def test_get_bigquery_client_missing_credentials():
    """Test BigQuery client creation fails with missing credentials."""
    with patch("governor_core.gcp.clients.google.auth.default") as mock_default:
        from google.auth.exceptions import DefaultCredentialsError

        mock_default.side_effect = DefaultCredentialsError("no creds")
        with pytest.raises(GCPCredentialsError, match="GCP credentials not configured"):
            get_bigquery_client()


def test_query_information_schema_jobs_with_dbt_filter():
    """Test querying INFORMATION_SCHEMA with dbt table filtering."""
    # Mock BigQuery client
    with patch("governor_core.gcp.clients.get_bigquery_client") as mock_get_client:
        mock_client = MagicMock()
        mock_get_client.return_value = mock_client

        # Mock query results
        mock_row = {
            "job_id": "project:us.job_123",
            "user_email": "analyst@example.com",
            "query": "SELECT * FROM dbt_table",
            "creation_time": datetime(2026, 1, 15, 10, 0, 0),
            "start_time": datetime(2026, 1, 15, 10, 0, 5),
            "end_time": datetime(2026, 1, 15, 10, 0, 10),
            "duration_ms": 5000,
            "total_slot_ms": 10000,
            "total_bytes_processed": 1024000,
            "total_bytes_billed": 10240000,
            "total_cost": 0.05,
            "cache_hit": False,
            "destination_table": "project.dataset.result",
            "referenced_tables": ["project.dataset.dbt_table"],
            "statement_type": "SELECT",
            "job_type": "QUERY",
            "job_state": "DONE",
            "error_result": None,
            "performance_insights": None,
            "query_hashes": None,
            "timeline": None,
            "bi_engine_mode": "DISABLED",
            "bi_engine_reasons": None,
            "total_modified_partitions": None,
        }

        mock_result = MagicMock()
        mock_result.__iter__.return_value = [MagicMock(items=lambda: mock_row.items())]

        mock_query_job = MagicMock()
        mock_query_job.result.return_value = mock_result
        mock_client.query.return_value = mock_query_job

        # Execute query
        dbt_tables = ["project.dataset.dbt_table"]
        jobs = query_information_schema_jobs("test-project", dbt_tables)

        # Verify get_bigquery_client was called with the project_id
        mock_get_client.assert_called_once_with(project_id="test-project")

        # Verify results
        assert len(jobs) == 1
        assert jobs[0]["job_id"] == "project:us.job_123"
        assert jobs[0]["user_email"] == "analyst@example.com"
        assert jobs[0]["destination_table"] == "project.dataset.result"


def test_query_information_schema_jobs_180_day_default():
    """Test querying with 180-day default when no timestamp provided."""
    with patch("governor_core.gcp.clients.get_bigquery_client") as mock_get_client:
        mock_client = MagicMock()
        mock_get_client.return_value = mock_client

        mock_result = MagicMock()
        mock_result.__iter__.return_value = []
        mock_query_job = MagicMock()
        mock_query_job.result.return_value = mock_result
        mock_client.query.return_value = mock_query_job

        # Execute query without timestamp
        dbt_tables = ["project.dataset.table1"]
        jobs = query_information_schema_jobs("test-project", dbt_tables, None)

        # Verify query contains 180 day interval
        call_args = mock_client.query.call_args
        query_sql = call_args[0][0]
        assert "INTERVAL 180 DAY" in query_sql
        assert len(jobs) == 0


def test_query_information_schema_jobs_incremental_with_timestamp():
    """Test incremental sync with last_sync_timestamp."""
    with patch("governor_core.gcp.clients.get_bigquery_client") as mock_get_client:
        mock_client = MagicMock()
        mock_get_client.return_value = mock_client

        mock_result = MagicMock()
        mock_result.__iter__.return_value = []
        mock_query_job = MagicMock()
        mock_query_job.result.return_value = mock_result
        mock_client.query.return_value = mock_query_job

        # Execute query with timestamp
        last_sync = datetime(2026, 1, 1, 12, 0, 0)
        dbt_tables = ["project.dataset.table1"]
        query_information_schema_jobs("test-project", dbt_tables, last_sync)

        # Verify query uses timestamp filter
        call_args = mock_client.query.call_args
        query_sql = call_args[0][0]
        assert "2026-01-01" in query_sql
        assert "INTERVAL 180 DAY" not in query_sql


def test_query_information_schema_jobs_uses_configured_region():
    """Test region is configurable and not hardcoded to region-us."""
    with patch("governor_core.gcp.clients.get_bigquery_client") as mock_get_client:
        mock_client = MagicMock()
        mock_get_client.return_value = mock_client

        mock_result = MagicMock()
        mock_result.__iter__.return_value = []
        mock_query_job = MagicMock()
        mock_query_job.result.return_value = mock_result
        mock_client.query.return_value = mock_query_job

        query_information_schema_jobs(
            "test-project",
            ["project.dataset.table1"],
            region="europe-west2",
        )

        query_sql = mock_client.query.call_args[0][0]
        # Spec 136: backticks now wrap just the region-qualifier, not the full
        # dotted path — so the hyphenated region (europe-west2) parses as a
        # single identifier instead of colliding with dotted-path tokenisation.
        assert "`region-europe-west2`.INFORMATION_SCHEMA.JOBS" in query_sql

        # Spec 136: the query must also set location= so BigQuery routes to the
        # requested region rather than defaulting to US.
        assert mock_client.query.call_args.kwargs.get("location") == "europe-west2"


def test_query_information_schema_jobs_keeps_null_destination_rows():
    """Test destination_table NULL rows are retained for referenced_tables matching."""
    with patch("governor_core.gcp.clients.get_bigquery_client") as mock_get_client:
        mock_client = MagicMock()
        mock_get_client.return_value = mock_client

        mock_result = MagicMock()
        mock_result.__iter__.return_value = []
        mock_query_job = MagicMock()
        mock_query_job.result.return_value = mock_result
        mock_client.query.return_value = mock_query_job

        query_information_schema_jobs("test-project", ["project.dataset.table1"])

        query_sql = mock_client.query.call_args[0][0]
        assert "destination_table IS NULL" in query_sql
        assert "NOT STARTS_WITH(destination_table.dataset_id, '_')" in query_sql


def test_query_information_schema_jobs_invalid_region():
    """Test invalid region strings are rejected before query execution."""
    with pytest.raises(ValueError, match="Invalid BigQuery region"):
        query_information_schema_jobs(
            "test-project",
            ["project.dataset.table1"],
            region="us`; DROP TABLE x; --",
        )


def test_query_information_schema_jobs_empty_dbt_tables():
    """Test query returns empty list when no dbt tables provided (FR-013)."""
    # No need to mock client since function returns early
    jobs = query_information_schema_jobs("test-project", [], None)
    assert jobs == []


def test_query_information_schema_jobs_api_error():
    """Test handling of BigQuery API errors."""
    with patch("governor_core.gcp.clients.get_bigquery_client") as mock_get_client:
        mock_client = MagicMock()
        mock_get_client.return_value = mock_client

        # Simulate API error
        mock_client.query.side_effect = GoogleAPIError("BigQuery API error")

        dbt_tables = ["project.dataset.table1"]
        with pytest.raises(GoogleAPIError, match="BigQuery API error"):
            query_information_schema_jobs("test-project", dbt_tables)


def test_query_table_storage_keeps_deleted_physical_bytes():
    """Deleted rows can carry time-travel/fail-safe physical bytes."""
    with patch("governor_core.gcp.clients.get_bigquery_client") as mock_get_client:
        mock_client = MagicMock()
        mock_get_client.return_value = mock_client

        mock_result = MagicMock()
        mock_result.__iter__.return_value = []
        mock_query_job = MagicMock()
        mock_query_job.result.return_value = mock_result
        mock_client.query.return_value = mock_query_job

        rows = query_table_storage("test-project", region="europe-west2")

        query_sql = mock_client.query.call_args[0][0]
        assert rows == []
        assert (
            "`test-project`.`region-europe-west2`.INFORMATION_SCHEMA.TABLE_STORAGE"
            in query_sql
        )
        assert (
            "SUM(IF(deleted = false, active_logical_bytes, 0)) AS active_logical_bytes"
            in query_sql
        )
        assert "SUM(fail_safe_physical_bytes) AS fail_safe_physical_bytes" in query_sql
        assert "GROUP BY project_id, table_schema, table_name, table_type" in query_sql
        assert "OR total_physical_bytes + fail_safe_physical_bytes > 0" in query_sql
        assert "WHERE deleted = false" not in query_sql


@patch("governor_core.gcp.clients.dry_run_query")
def test_dry_run_partition_cluster_ddl_strips_multiline_config_blocks(mock_dry_run):
    mock_dry_run.return_value = MagicMock(valid=True)

    select_sql = """{{ config(
    materialized='table',
    cluster_by=['user_id']
) }}

select user_id
from `proj.ds.table`"""

    dry_run_partition_cluster_ddl(
        project_id="proj",
        dataset="analytics",
        select_sql=select_sql,
        partition_by=None,
        cluster_by=["user_id"],
    )

    ddl = mock_dry_run.call_args.args[1]
    assert "materialized" not in ddl.lower()
    assert "cluster_by=['user_id']" not in ddl
    assert "CLUSTER BY user_id" in ddl
    assert "from `proj.ds.table`" in ddl


@patch("governor_core.gcp.clients.dry_run_query")
def test_dry_run_partition_cluster_ddl_rejects_uncompiled_jinja(mock_dry_run):
    result = dry_run_partition_cluster_ddl(
        project_id="proj",
        dataset="analytics",
        select_sql="select * from {{ source('pkg', 'table') }}",
        partition_by=None,
        cluster_by=["user_id"],
    )

    assert result.valid is False
    assert "uncompiled dbt SQL" in (result.error or "")
    mock_dry_run.assert_not_called()
