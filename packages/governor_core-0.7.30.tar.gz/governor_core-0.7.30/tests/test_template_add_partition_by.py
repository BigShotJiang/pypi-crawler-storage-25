"""Unit tests for app/solutions/templates/add_partition_by.py."""

from types import SimpleNamespace
from unittest.mock import patch

from governor_core.solutions.templates.add_partition_by import AddPartitionByTemplate
from governor_core.solutions.templates.base import TemplateResult


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_opportunity(
    opp_type: str = "partition_pruning",
    evidence: dict | None = None,
):
    return SimpleNamespace(
        id="opp-1",
        opportunity_type=opp_type,
        evidence_snapshot=evidence or {},
        dbt_model_name="my_model",
        affected_table="project.dataset.my_model",
    )


# ---------------------------------------------------------------------------
# SQL Fixtures
# ---------------------------------------------------------------------------

SQL_WITH_CONFIG = """\
{{ config(
    materialized='table'
) }}

SELECT id, name, created_at
FROM {{ ref('raw_orders') }}
"""

SQL_WITH_PARTITION = """\
{{ config(
    materialized='table',
    partition_by={"field": "created_at", "data_type": "date"}
) }}

SELECT id, name, created_at
FROM {{ ref('raw_orders') }}
"""

_METADATA = {"original_file_path": "models/my_model.sql"}


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


class TestAddPartitionByTemplate:
    def setup_method(self):
        self.template = AddPartitionByTemplate()

    def test_matches_partition_pruning_with_params(self):
        """Matches when type is partition_pruning and evidence has a partition column."""
        opp = _make_opportunity(
            evidence={
                "recommended_partition_column": "created_at",
                "partition_data_type": "DATE",
            },
        )
        source_files = {"models/my_model.sql": SQL_WITH_CONFIG}
        assert self.template.matches(opp, source_files, _METADATA) is True

    def test_no_match_wrong_type(self):
        """Does not match when opportunity_type is not partition_pruning."""
        opp = _make_opportunity(
            opp_type="shuffle_spill",
            evidence={"recommended_partition_column": "created_at"},
        )
        source_files = {"models/my_model.sql": SQL_WITH_CONFIG}
        assert self.template.matches(opp, source_files, _METADATA) is False

    def test_no_match_already_partitioned(self):
        """Does not match when SQL already has partition_by."""
        opp = _make_opportunity(
            evidence={"recommended_partition_column": "created_at"},
        )
        source_files = {"models/my_model.sql": SQL_WITH_PARTITION}
        assert self.template.matches(opp, source_files, _METADATA) is False

    def test_no_match_no_column_in_evidence(self):
        """Does not match when evidence has no partition column."""
        opp = _make_opportunity(evidence={})
        source_files = {"models/my_model.sql": SQL_WITH_CONFIG}
        assert self.template.matches(opp, source_files, _METADATA) is False

    def test_apply_inserts_partition_by_date(self):
        """Apply inserts partition_by for a DATE column (no granularity)."""
        opp = _make_opportunity(
            evidence={
                "recommended_partition_column": "created_at",
                "partition_data_type": "DATE",
            },
        )
        source_files = {"models/my_model.sql": SQL_WITH_CONFIG}
        result = self.template.apply(opp, source_files, _METADATA)

        assert result is not None
        assert isinstance(result, TemplateResult)
        assert result.template_id == "add_partition_by"
        assert result.file_path == "models/my_model.sql"
        assert result.before_content == SQL_WITH_CONFIG
        assert "partition_by" in result.after_content
        assert "created_at" in result.after_content
        assert result.change_type == "project_config_change"
        assert result.policy_tags == ["dbt_config_change"]
        assert result.parameters["column"] == "created_at"
        assert result.parameters["data_type"] == "date"
        assert "granularity" not in result.parameters

    @patch(
        "governor_core.dbt.column_lookup.resolve_bq_partition_data_type",
        return_value=("timestamp", "day"),
    )
    def test_apply_inserts_partition_by_timestamp_with_granularity(self, mock_resolve):
        """Apply inserts partition_by for TIMESTAMP with granularity='day'."""
        opp = _make_opportunity(
            evidence={
                "recommended_partition_column": "event_time",
                "partition_data_type": "TIMESTAMP",
            },
        )
        source_files = {"models/my_model.sql": SQL_WITH_CONFIG}
        result = self.template.apply(opp, source_files, _METADATA)

        assert result is not None
        assert "partition_by" in result.after_content
        assert "event_time" in result.after_content
        assert "timestamp" in result.after_content
        assert "granularity" in result.after_content
        assert result.parameters["column"] == "event_time"
        assert result.parameters["data_type"] == "timestamp"
        assert result.parameters["granularity"] == "day"
        mock_resolve.assert_called_once_with("TIMESTAMP")

    def test_apply_returns_none_if_already_partitioned(self):
        """Apply returns None when partition_by already exists."""
        opp = _make_opportunity(
            evidence={
                "recommended_partition_column": "created_at",
                "partition_data_type": "DATE",
            },
        )
        source_files = {"models/my_model.sql": SQL_WITH_PARTITION}
        result = self.template.apply(opp, source_files, _METADATA)

        assert result is None

    def test_extract_params_uses_recommended_column(self):
        """Uses recommended_partition_column from evidence."""
        opp = _make_opportunity(
            evidence={
                "recommended_partition_column": "recommended_col",
                "partition_column": "fallback_col",
            },
        )
        source_files = {"models/my_model.sql": SQL_WITH_CONFIG}
        result = self.template.apply(opp, source_files, _METADATA)

        assert result is not None
        assert result.parameters["column"] == "recommended_col"

    def test_extract_params_fallback_to_partition_column(self):
        """Falls back to partition_column when recommended_partition_column is absent."""
        opp = _make_opportunity(
            evidence={"partition_column": "fallback_col"},
        )
        source_files = {"models/my_model.sql": SQL_WITH_CONFIG}
        result = self.template.apply(opp, source_files, _METADATA)

        assert result is not None
        assert result.parameters["column"] == "fallback_col"
        # No partition_data_type => defaults to "date"
        assert result.parameters["data_type"] == "date"
