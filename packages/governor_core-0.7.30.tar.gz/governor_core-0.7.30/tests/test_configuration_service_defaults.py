"""Spec 130: ConfigurationService default-resolution tests.

Tests the spec-130 helper that computes the "new row default" for
``auto_shadow_validate_safe_solutions`` + ``shadow_validation_enabled``
kwargs. The helper is the surgical seam; exercising the full
``create_configuration`` path requires mocking GCS + project-name
resolution, which is covered by web-layer integration tests.
"""

from __future__ import annotations

from governor_core.configurations.service import (
    _resolve_auto_shadow_create_defaults,
)


class TestResolveAutoShadowCreateDefaults:
    def test_explicit_true_sets_both_flags(self, monkeypatch):
        # Mode irrelevant when explicit.
        monkeypatch.delenv("GOVERNOR_LOCAL_MODE", raising=False)
        assert _resolve_auto_shadow_create_defaults(True) == {
            "auto_shadow_validate_safe_solutions": True,
            "shadow_validation_enabled": True,
        }

    def test_explicit_false_sets_only_auto_shadow(self, monkeypatch):
        # Mode irrelevant when explicit.
        monkeypatch.setenv("GOVERNOR_LOCAL_MODE", "true")
        assert _resolve_auto_shadow_create_defaults(False) == {
            "auto_shadow_validate_safe_solutions": False
        }

    def test_unspecified_in_local_mode_defaults_true(self, monkeypatch):
        monkeypatch.setenv("GOVERNOR_LOCAL_MODE", "true")
        import importlib

        import governor_core.core.config as config_module

        importlib.reload(config_module)
        # Re-import the helper so its closure over is_local_mode picks up
        # the reloaded module (module-level import at function call time).
        assert _resolve_auto_shadow_create_defaults(None) == {
            "auto_shadow_validate_safe_solutions": True,
            "shadow_validation_enabled": True,
        }

    def test_unspecified_in_cloud_mode_returns_empty(self, monkeypatch):
        monkeypatch.delenv("GOVERNOR_LOCAL_MODE", raising=False)
        import importlib

        import governor_core.core.config as config_module

        importlib.reload(config_module)
        # Empty dict → column-level default (False) takes effect at insert time.
        assert _resolve_auto_shadow_create_defaults(None) == {}

    def test_mode_detection_error_falls_back_to_cloud(self, monkeypatch):
        """Spec 130 FR-007: fail-closed on the safer side."""
        import governor_core.configurations.service as service_mod

        def _raise(*_a, **_k):  # pragma: no cover — trivial stub
            raise RuntimeError("simulated mode detection failure")

        # Patch the local import site inside the helper.
        monkeypatch.setattr(
            "governor_core.core.config.is_local_mode", _raise, raising=True
        )
        assert _resolve_auto_shadow_create_defaults(None) == {}
