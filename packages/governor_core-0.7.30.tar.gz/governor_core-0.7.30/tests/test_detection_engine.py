from __future__ import annotations

from types import SimpleNamespace
from unittest.mock import patch

from governor_core.opportunities.detector import DetectionEngine, select_rules_for_config


def test_select_rules_for_config_inherited_uses_all_enabled_rules():
    engine = DetectionEngine()

    selected = select_rules_for_config(
        engine.get_enabled_rules(),
        SimpleNamespace(watched_rule_types=None),
    )

    assert selected.mode == "all"
    assert set(selected.effective_rule_types) == {
        rule.rule_type for rule in engine.get_enabled_rules()
    }
    assert {rule.rule_type for rule in selected.effective_rules} == set(
        selected.effective_rule_types
    )


def test_select_rules_for_config_custom_narrows_rule_list():
    engine = DetectionEngine()

    selected = select_rules_for_config(
        engine.get_enabled_rules(),
        SimpleNamespace(watched_rule_types=["shuffle_spill"]),
    )

    assert selected.mode == "custom"
    assert selected.effective_rule_types == ["shuffle_spill"]
    assert [rule.rule_type for rule in selected.effective_rules] == ["shuffle_spill"]


def test_select_rules_for_config_explicit_empty_returns_zero_rules():
    engine = DetectionEngine()

    selected = select_rules_for_config(
        engine.get_enabled_rules(),
        SimpleNamespace(watched_rule_types=[]),
    )

    assert selected.mode == "custom"
    assert selected.effective_rule_types == []
    assert selected.effective_rules == []


def test_select_rules_for_config_excludes_globally_disabled_rule():
    engine = DetectionEngine()

    with patch(
        "governor_core.opportunities.catalog.is_rule_enabled",
        side_effect=lambda rule_type: rule_type != "shuffle_spill",
    ):
        selected = select_rules_for_config(
            engine.get_enabled_rules(),
            SimpleNamespace(watched_rule_types=["shuffle_spill", "slot_contention"]),
        )

    assert selected.mode == "custom"
    assert selected.unavailable_rule_types == ["shuffle_spill"]
    assert selected.effective_rule_types == ["slot_contention"]
    assert [rule.rule_type for rule in selected.effective_rules] == ["slot_contention"]
