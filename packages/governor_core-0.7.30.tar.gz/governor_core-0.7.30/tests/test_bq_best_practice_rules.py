"""Unit tests for the BigQuery best-practices detection rules added by
spec 142. Each rule gets a positive test (offending query → 1 candidate)
and a negative test (clean query → 0 candidates) to catch over-firing.

``order_by_without_limit``, ``date_sharded_table``, and
``oversharded_source`` were removed from the catalog in v0.0.18 — too
noisy for the value they delivered. Their tests are deleted alongside
the rule files.
"""

from __future__ import annotations

from decimal import Decimal
from types import SimpleNamespace

from governor_core.opportunities.rules.cross_join_unaggregated import (
    CrossJoinUnaggregatedRule,
)
from governor_core.opportunities.rules.select_star import SelectStarRule
from governor_core.opportunities.rules.self_join_anti_pattern import (
    SelfJoinAntiPatternRule,
)


def _job(query: str, *, dest: str = "proj.ds.tbl", cost: float = 5.0) -> SimpleNamespace:
    """Minimal duck-typed BigQueryJob — the rules only read the fields
    we set here, so SimpleNamespace is enough."""
    return SimpleNamespace(
        query=query,
        destination_table=dest,
        total_cost=Decimal(str(cost)),
        total_bytes_processed=10**9,
        total_bytes_billed=10**9,
        job_id="job-1",
    )


# ── select_star ─────────────────────────────────────────────────────────


def test_select_star_fires_on_outer_star():
    rule = SelectStarRule()
    candidates = rule.detect(
        [_job("SELECT * FROM proj.ds.wide_table")], None, rule.default_thresholds
    )
    assert len(candidates) == 1
    c = candidates[0]
    assert c.opportunity_type == "select_star"
    assert c.severity_score >= 1
    assert c.evidence_snapshot["has_select_star"] is True
    assert c.expected_savings == 0  # audit doesn't claim a savings number without dry-run evidence
    assert "explicit column list" in c.explanation.lower() or "select * except" in c.explanation.lower()


def test_select_star_does_not_fire_on_explicit_columns():
    rule = SelectStarRule()
    candidates = rule.detect(
        [_job("SELECT col1, col2 FROM proj.ds.wide_table")], None, rule.default_thresholds
    )
    assert candidates == []


def test_select_star_inside_cte_only_does_not_fire():
    """Inner CTE with SELECT * is fine when the outer projection narrows."""
    rule = SelectStarRule()
    q = "WITH base AS (SELECT * FROM proj.ds.t) SELECT col1 FROM base"
    candidates = rule.detect([_job(q)], None, rule.default_thresholds)
    assert candidates == []


# ── cross_join_unaggregated ─────────────────────────────────────────────


def test_cross_join_fires():
    rule = CrossJoinUnaggregatedRule()
    candidates = rule.detect(
        [_job("SELECT a.x, b.y FROM proj.ds.a CROSS JOIN proj.ds.b")],
        None,
        rule.default_thresholds,
    )
    assert len(candidates) == 1
    assert candidates[0].evidence_snapshot["cross_join_count"] >= 1


def test_inner_join_does_not_fire():
    rule = CrossJoinUnaggregatedRule()
    candidates = rule.detect(
        [_job("SELECT a.x FROM proj.ds.a JOIN proj.ds.b USING (x)")],
        None,
        rule.default_thresholds,
    )
    assert candidates == []


def test_cross_join_with_group_by_does_not_fire():
    """Pre-aggregated cross join is intentional and not flagged."""
    rule = CrossJoinUnaggregatedRule()
    q = "SELECT COUNT(*) FROM proj.ds.a CROSS JOIN proj.ds.b GROUP BY a.x"
    candidates = rule.detect([_job(q)], None, rule.default_thresholds)
    assert candidates == []


# ── self_join_anti_pattern ──────────────────────────────────────────────


def test_self_join_with_inequality_fires():
    rule = SelfJoinAntiPatternRule()
    q = (
        "SELECT a.user_id FROM proj.ds.events a "
        "JOIN proj.ds.events b ON a.user_id = b.user_id AND a.ts < b.ts"
    )
    candidates = rule.detect([_job(q)], None, rule.default_thresholds)
    assert len(candidates) == 1
    assert candidates[0].evidence_snapshot["self_join_count"] == 1


def test_join_to_different_table_does_not_fire():
    rule = SelfJoinAntiPatternRule()
    q = "SELECT a.user_id FROM proj.ds.events a JOIN proj.ds.users b ON a.user_id = b.id"
    candidates = rule.detect([_job(q)], None, rule.default_thresholds)
    assert candidates == []


def test_self_join_pure_equality_does_not_fire():
    """A self-join on pure equality is not the window-replaceable shape."""
    rule = SelfJoinAntiPatternRule()
    q = "SELECT a.user_id FROM proj.ds.events a JOIN proj.ds.events b ON a.user_id = b.user_id"
    candidates = rule.detect([_job(q)], None, rule.default_thresholds)
    assert candidates == []


# ── catalog registration ────────────────────────────────────────────────


def test_remaining_best_practice_rules_registered_in_catalog():
    from governor_core.opportunities.catalog import get_detection_rule_catalog

    catalog = get_detection_rule_catalog()
    rule_types = {entry.rule_type for entry in catalog}
    expected = {
        "select_star",
        "cross_join_unaggregated",
        "self_join_anti_pattern",
    }
    assert expected.issubset(rule_types), f"missing: {expected - rule_types}"

    # The three removed rules must NOT be registered.
    removed = {"order_by_without_limit", "date_sharded_table", "oversharded_source"}
    assert not (removed & rule_types), (
        f"removed rules still in catalog: {removed & rule_types}"
    )
