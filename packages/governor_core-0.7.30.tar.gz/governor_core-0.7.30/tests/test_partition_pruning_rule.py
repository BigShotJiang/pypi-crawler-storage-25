"""
Unit tests for PartitionPruningRule.

Tests partition pruning detection (placeholder - signal rarely populated).
"""

from decimal import Decimal
from unittest.mock import MagicMock


from governor_core.opportunities.rules.partition_pruning import PartitionPruningRule


class TestPartitionPruningRule:
    """Tests for partition pruning detection."""

    def test_rule_type(self):
        """Test rule type identifier."""
        rule = PartitionPruningRule()
        assert rule.rule_type == "partition_pruning"

    def test_default_thresholds(self):
        """Test default threshold configuration."""
        rule = PartitionPruningRule()
        thresholds = rule.default_thresholds

        assert thresholds["min_job_cost_usd"] == Decimal("0")
        assert thresholds["enabled"] is True

    def test_detect_with_partition_skew(self):
        """Test detection when partition_skew is present."""
        rule = PartitionPruningRule()

        job = MagicMock()
        job.destination_table = "project.dataset.test_table"
        job.total_cost = Decimal("5.00")
        job.total_bytes_processed = 10 * 1024 * 1024 * 1024  # 10GB
        job.job_id = "job-123"
        job.performance_insights = {
            "stage_performance_standalone_insights": [
                {
                    "stage_id": 1,
                    "partition_skew": {"skew_detected": True, "skew_factor": 2.5},
                }
            ]
        }

        candidates = rule.detect([job], None, rule.default_thresholds)

        assert len(candidates) == 1
        candidate = candidates[0]
        assert candidate.opportunity_type == "partition_pruning"
        assert candidate.affected_table == "project.dataset.test_table"
        assert candidate.evidence_snapshot["partition_skew_detected"] is True
        assert candidate.confidence == 0.7  # Medium confidence

    def test_detect_graceful_when_null(self):
        """Test graceful handling when partition_skew is null."""
        rule = PartitionPruningRule()

        job = MagicMock()
        job.destination_table = "project.dataset.test_table"
        job.total_cost = Decimal("5.00")
        job.total_bytes_processed = 10 * 1024 * 1024 * 1024
        job.job_id = "job-123"
        job.performance_insights = {
            "stage_performance_standalone_insights": [
                {
                    "stage_id": 1,
                    "partition_skew": None,  # Signal is null
                }
            ]
        }

        candidates = rule.detect([job], None, rule.default_thresholds)

        # Should return empty list gracefully
        assert len(candidates) == 0

    def test_detect_graceful_without_insights(self):
        """Test graceful handling when no performance_insights."""
        rule = PartitionPruningRule()

        job = MagicMock()
        job.destination_table = "project.dataset.test_table"
        job.total_cost = Decimal("5.00")
        job.total_bytes_processed = 10 * 1024 * 1024 * 1024
        job.job_id = "job-123"
        job.performance_insights = None

        candidates = rule.detect([job], None, rule.default_thresholds)
        assert len(candidates) == 0

    def test_detect_graceful_with_empty_stages(self):
        """Test graceful handling with empty stages array."""
        rule = PartitionPruningRule()

        job = MagicMock()
        job.destination_table = "project.dataset.test_table"
        job.total_cost = Decimal("5.00")
        job.total_bytes_processed = 10 * 1024 * 1024 * 1024
        job.job_id = "job-123"
        job.performance_insights = {"stage_performance_standalone_insights": []}

        candidates = rule.detect([job], None, rule.default_thresholds)
        assert len(candidates) == 0

    def test_can_be_disabled(self):
        """Test rule can be disabled via thresholds."""
        rule = PartitionPruningRule()

        job = MagicMock()
        job.destination_table = "project.dataset.test_table"
        job.total_cost = Decimal("5.00")
        job.total_bytes_processed = 10 * 1024 * 1024 * 1024
        job.job_id = "job-123"
        job.performance_insights = {
            "stage_performance_standalone_insights": [
                {"stage_id": 1, "partition_skew": {"skew_detected": True}}
            ]
        }

        # Disable the rule
        thresholds = rule.default_thresholds.copy()
        thresholds["enabled"] = False

        candidates = rule.detect([job], thresholds, thresholds)
        assert len(candidates) == 0

    def test_explanation_is_actionable(self):
        """Test that explanation includes actionable guidance."""
        rule = PartitionPruningRule()

        job = MagicMock()
        job.destination_table = "project.dataset.test_table"
        job.total_cost = Decimal("5.00")
        job.total_bytes_processed = 10 * 1024 * 1024 * 1024
        job.job_id = "job-123"
        job.performance_insights = {
            "stage_performance_standalone_insights": [
                {"stage_id": 1, "partition_skew": {"skew_detected": True}}
            ]
        }

        candidates = rule.detect([job], None, rule.default_thresholds)

        assert len(candidates) == 1
        explanation = candidates[0].explanation

        # Check for actionable content
        assert "partition" in explanation.lower()
        assert "filter" in explanation.lower()
        assert (
            "direct comparisons" in explanation.lower()
            or "date =" in explanation.lower()
        )

    def test_medium_confidence_severity(self):
        """Test that severity reflects medium confidence."""
        rule = PartitionPruningRule()

        job = MagicMock()
        job.destination_table = "project.dataset.test_table"
        job.total_cost = Decimal("100.00")  # High cost
        job.total_bytes_processed = 100 * 1024 * 1024 * 1024  # 100GB
        job.job_id = "job-123"
        job.performance_insights = {
            "stage_performance_standalone_insights": [
                {"stage_id": 1, "partition_skew": {"skew_detected": True}}
            ]
        }

        candidates = rule.detect([job], None, rule.default_thresholds)

        assert len(candidates) == 1
        # With medium confidence (0.7), severity should be adjusted down
        # compared to a rule with 1.0 confidence
        assert candidates[0].confidence == 0.7
        assert 1 <= candidates[0].severity_score <= 100
