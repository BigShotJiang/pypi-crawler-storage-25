"""Regression tests for the SQLite ``DateTime(timezone=True)`` round-trip.

Production runs Postgres (which natively returns tz-aware datetimes); the
CLI and the test harness run SQLite, which drops tzinfo on read. Without
the ``_TZAwareDateTime`` shim, code that subtracts two columns or
compares against ``datetime.now(timezone.utc)`` after a session
expiration raises ``TypeError: can't subtract offset-naive and
offset-aware datetimes`` — the spec-141 shadow-validation crash.

These tests reproduce that exact failure surface and assert the shim
fixes it without regressing PostgreSQL behaviour.
"""

from __future__ import annotations

from datetime import datetime, timezone

import pytest
from sqlalchemy import Column, DateTime, MetaData, String, Table, create_engine
from sqlalchemy.orm import Session, declarative_base

from governor_core.db.sqlite_compat import (
    _TZAwareDateTime,
    apply_sqlite_compat,
)


def _now_utc() -> datetime:
    return datetime.now(timezone.utc)


def test_tzaware_datetime_bind_normalises_naive_to_utc():
    decorator = _TZAwareDateTime()
    naive = datetime(2026, 4, 28, 12, 0, 0)
    bound = decorator.process_bind_param(naive, dialect=None)
    assert bound.tzinfo is timezone.utc


def test_tzaware_datetime_bind_normalises_aware_to_utc():
    decorator = _TZAwareDateTime()
    from datetime import timedelta

    nzst = timezone(timedelta(hours=12))
    aware_other = datetime(2026, 4, 28, 12, 0, 0, tzinfo=nzst)
    bound = decorator.process_bind_param(aware_other, dialect=None)
    assert bound.tzinfo is timezone.utc
    assert bound == aware_other  # same instant, different zone


def test_tzaware_datetime_result_reattaches_utc_when_naive():
    decorator = _TZAwareDateTime()
    naive = datetime(2026, 4, 28, 12, 0, 0)
    result = decorator.process_result_value(naive, dialect=None)
    assert result.tzinfo is timezone.utc


def test_tzaware_datetime_passes_none_through():
    decorator = _TZAwareDateTime()
    assert decorator.process_bind_param(None, dialect=None) is None
    assert decorator.process_result_value(None, dialect=None) is None


def test_apply_sqlite_compat_substitutes_datetime_timezone_columns():
    """``DateTime(timezone=True)`` columns must be wrapped after compat applies."""
    metadata = MetaData()
    Table(
        "shadow_run_stub",
        metadata,
        Column("id", String, primary_key=True),
        Column("started_at", DateTime(timezone=True), nullable=True),
        Column("naive_at", DateTime(timezone=False), nullable=True),
    )

    apply_sqlite_compat(metadata)

    cols = {c.name: c for c in metadata.tables["shadow_run_stub"].columns}
    assert isinstance(cols["started_at"].type, _TZAwareDateTime)
    # Non-tz columns must be left alone — the bug only affects tz-aware ones.
    assert not isinstance(cols["naive_at"].type, _TZAwareDateTime)


def test_apply_sqlite_compat_is_idempotent():
    """Calling apply_sqlite_compat twice must not double-wrap."""
    metadata = MetaData()
    Table(
        "shadow_run_stub2",
        metadata,
        Column("id", String, primary_key=True),
        Column("started_at", DateTime(timezone=True), nullable=True),
    )
    apply_sqlite_compat(metadata)
    type_after_first = type(metadata.tables["shadow_run_stub2"].c.started_at.type)
    apply_sqlite_compat(metadata)
    type_after_second = type(metadata.tables["shadow_run_stub2"].c.started_at.type)
    assert type_after_first is type_after_second is _TZAwareDateTime


def test_subtraction_after_roundtrip_does_not_raise_typeerror():
    """The exact spec-141 shadow-validation crash, in miniature.

    Without the shim:
      1. assign tz-aware datetime to ``started_at``
      2. commit + expire (SQLAlchemy default after commit)
      3. read ``started_at`` back → tz-naive (SQLite has no tzinfo)
      4. assign fresh tz-aware datetime to ``completed_at``
      5. ``completed_at - started_at`` → ``TypeError``
    """
    Base = declarative_base()

    class _Run(Base):
        __tablename__ = "_run"
        id = Column(String, primary_key=True)
        started_at = Column(DateTime(timezone=True), nullable=True)
        completed_at = Column(DateTime(timezone=True), nullable=True)

    apply_sqlite_compat(Base.metadata)

    engine = create_engine("sqlite:///:memory:")
    Base.metadata.create_all(engine)

    with Session(engine) as session:
        run = _Run(id="r1", started_at=_now_utc())
        session.add(run)
        session.commit()
        # Default expire-on-commit forces a re-read on next access.
        run.completed_at = _now_utc()
        # The line that used to raise.
        delta = (run.completed_at - run.started_at).total_seconds()
        assert delta >= 0
        assert run.started_at.tzinfo is timezone.utc
        assert run.completed_at.tzinfo is timezone.utc


def test_naive_bind_value_round_trips_as_utc_aware():
    """Some legacy tests pass ``datetime.now()`` (naive) on tz-aware columns.
    The shim must accept that input without raising and round-trip it as UTC.
    """
    Base = declarative_base()

    class _Event(Base):
        __tablename__ = "_event"
        id = Column(String, primary_key=True)
        at = Column(DateTime(timezone=True), nullable=False)

    apply_sqlite_compat(Base.metadata)

    engine = create_engine("sqlite:///:memory:")
    Base.metadata.create_all(engine)

    with Session(engine) as session:
        # Naive datetime — what some test fixtures hand in.
        session.add(_Event(id="e1", at=datetime(2026, 4, 28, 12, 0, 0)))
        session.commit()
        loaded = session.query(_Event).filter_by(id="e1").one()
        assert loaded.at.tzinfo is timezone.utc
        assert loaded.at == datetime(2026, 4, 28, 12, 0, 0, tzinfo=timezone.utc)


@pytest.mark.parametrize("postgres_only", [True])
def test_postgres_dialect_unaffected(postgres_only):
    """Sanity check: the shim is only wired in by ``apply_sqlite_compat``;
    metadata that never gets that call (i.e. production Postgres) keeps
    the native ``DateTime(timezone=True)`` and is untouched."""
    metadata = MetaData()
    Table(
        "pg_run",
        metadata,
        Column("id", String, primary_key=True),
        Column("started_at", DateTime(timezone=True), nullable=True),
    )
    # No apply_sqlite_compat() call — simulates Postgres path.
    col = metadata.tables["pg_run"].c.started_at
    assert isinstance(col.type, DateTime)
    assert not isinstance(col.type, _TZAwareDateTime)
    assert col.type.timezone is True
