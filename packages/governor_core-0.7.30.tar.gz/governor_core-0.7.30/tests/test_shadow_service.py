"""End-to-end unit tests for the shadow service orchestrator (mocked IO)."""

from __future__ import annotations

from datetime import datetime, timezone

from governor_core.shadow.builder import BuildResult
from governor_core.shadow.diff import ModelMetric
from governor_core.shadow.service import run_shadow_validation


def _ok_builder(*, phase, cascade, run_id):  # noqa: ARG001
    return BuildResult(
        phase=phase,
        started_at=datetime.now(timezone.utc),
        completed_at=datetime.now(timezone.utc),
        success=True,
    )


def _failing_builder(*, phase, cascade, run_id):  # noqa: ARG001
    return BuildResult(
        phase=phase,
        started_at=datetime.now(timezone.utc),
        completed_at=datetime.now(timezone.utc),
        success=False,
        error_message="simulated baseline failure",
    )


class _MetricsStubEvenSavings:
    """Callable: first call returns baseline metrics, second returns cheaper shadow."""

    def __init__(self):
        self._calls = 0

    def __call__(self, *, run_results, expected_models):  # noqa: ARG002
        self._calls += 1
        factor = 1.0 if self._calls == 1 else 0.7
        return [
            ModelMetric(
                model_name=m,
                bytes_processed=int(10_000_000 * factor),
                slot_ms=int(5_000 * factor),
                row_count=1_000,
            )
            for m in expected_models
        ]


class _MetricsStubRowMismatch:
    def __init__(self):
        self._calls = 0

    def __call__(self, *, run_results, expected_models):  # noqa: ARG002
        self._calls += 1
        rows = 1_000 if self._calls == 1 else 950
        return [
            ModelMetric(
                model_name=m,
                bytes_processed=5_000_000,
                slot_ms=3_000,
                row_count=rows,
            )
            for m in expected_models
        ]


def _seed_solution_and_config(db):
    from tests.fixtures.factories import OpportunityFactory, SolutionFactory

    opp = OpportunityFactory.create()
    solution = SolutionFactory.create(
        solution_job__opportunity=opp,
        file_path="models/marts/fct_orders.sql",
    )
    return solution, opp.configuration


_MANIFEST = {
    "child_map": {
        "model.p.fct_orders": ["model.p.daily_revenue"],
        "model.p.daily_revenue": [],
    },
    "metadata": {"project_name": "p"},
}


def test_succeeded_run_records_executions_and_links_solution(db):
    solution, config = _seed_solution_and_config(db)
    output = run_shadow_validation(
        db,
        solution=solution,
        configuration=config,
        manifest_content=_MANIFEST,
        target_node_id="model.p.fct_orders",
        builder_fn=_ok_builder,
        metrics_fn=_MetricsStubEvenSavings(),
    )
    assert not output.skipped
    assert output.run.status == "succeeded"
    assert output.diff is not None
    assert output.diff.total_shadow_bytes < output.diff.total_baseline_bytes
    assert solution.shadow_validation_run_id == output.run.id
    # 2 models * 2 phases = 4 execution rows
    assert len(output.run.executions) == 4


def test_baseline_failure_marks_run_failed(db):
    solution, config = _seed_solution_and_config(db)
    output = run_shadow_validation(
        db,
        solution=solution,
        configuration=config,
        manifest_content=_MANIFEST,
        target_node_id="model.p.fct_orders",
        builder_fn=_failing_builder,
        metrics_fn=_MetricsStubEvenSavings(),
    )
    assert output.run.status == "baseline_failed"
    assert output.run.failure_reason == "baseline_failed"


def test_row_count_mismatch_marks_shadow_failed(db):
    solution, config = _seed_solution_and_config(db)
    output = run_shadow_validation(
        db,
        solution=solution,
        configuration=config,
        manifest_content=_MANIFEST,
        target_node_id="model.p.fct_orders",
        builder_fn=_ok_builder,
        metrics_fn=_MetricsStubRowMismatch(),
    )
    assert output.run.status == "shadow_failed"
    assert output.run.failure_reason == "row_count_mismatch"


def test_cascade_too_large_is_skipped(db):
    solution, config = _seed_solution_and_config(db)
    config.shadow_cascade_cap = 1  # target + 1 child already exceeds cap
    db.flush()
    output = run_shadow_validation(
        db,
        solution=solution,
        configuration=config,
        manifest_content=_MANIFEST,
        target_node_id="model.p.fct_orders",
        builder_fn=_ok_builder,
        metrics_fn=_MetricsStubEvenSavings(),
    )
    assert output.skipped
    assert output.run.status == "skipped"
    assert output.run.skipped_reason == "cascade_too_large"
