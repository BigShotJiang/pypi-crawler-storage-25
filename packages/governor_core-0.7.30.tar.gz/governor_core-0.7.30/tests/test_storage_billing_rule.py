"""Tests for StorageBillingRule detection rule."""

from __future__ import annotations

from decimal import Decimal
from types import SimpleNamespace

from governor_core.db import base as _force_core_metadata_init  # noqa: F401
from governor_core.opportunities.rules.storage_billing import (
    StorageBillingRule,
    _severity_from_savings,
)
from governor_core.opportunities.rules.storage_pricing import BYTES_PER_GB


def _make_metric(
    project_id: str = "test-project",
    dataset_name: str = "analytics",
    table_name: str = "events",
    billing_model: str = "LOGICAL",
    active_logical_bytes: int = 700_000_000,
    long_term_logical_bytes: int = 300_000_000,
    active_physical_bytes: int = 150_000_000,
    long_term_physical_bytes: int = 100_000_000,
    time_travel_physical_bytes: int = 25_000_000,
    fail_safe_physical_bytes: int = 12_500_000,
) -> SimpleNamespace:
    """Create a mock TableStorageMetric-like object."""
    total_logical = active_logical_bytes + long_term_logical_bytes
    total_physical = active_physical_bytes + long_term_physical_bytes
    return SimpleNamespace(
        project_id=project_id,
        dataset_name=dataset_name,
        table_name=table_name,
        billing_model=billing_model,
        total_logical_bytes=total_logical,
        active_logical_bytes=active_logical_bytes,
        long_term_logical_bytes=long_term_logical_bytes,
        total_physical_bytes=total_physical,
        active_physical_bytes=active_physical_bytes,
        long_term_physical_bytes=long_term_physical_bytes,
        time_travel_physical_bytes=time_travel_physical_bytes,
        fail_safe_physical_bytes=fail_safe_physical_bytes,
        total_rows=1_000_000,
    )


class TestStorageBillingRule:
    """Tests for the StorageBillingRule detection rule."""

    def test_rule_type(self):
        rule = StorageBillingRule()
        assert rule.rule_type == "storage_billing_optimization"

    def test_detects_savings_opportunity(self):
        """Single table in a dataset generates one dataset-level opportunity."""
        rule = StorageBillingRule()
        metrics = [
            _make_metric(
                dataset_name="analytics",
                table_name="events",
                active_logical_bytes=700_000_000_000,
                long_term_logical_bytes=300_000_000_000,
                active_physical_bytes=150_000_000_000,
                long_term_physical_bytes=100_000_000_000,
                time_travel_physical_bytes=25_000_000_000,
                fail_safe_physical_bytes=12_500_000_000,
            ),
        ]

        thresholds = rule.get_thresholds()
        thresholds["_storage_metrics"] = metrics
        candidates = rule.detect([], None, thresholds)

        assert len(candidates) == 1
        c = candidates[0]
        assert c.opportunity_type == "storage_billing_optimization"
        assert c.affected_table == "test-project.analytics"
        assert c.expected_savings > 0
        assert c.dbt_model_name is None
        assert c.evidence_snapshot["compression_ratio"] > 2.0
        assert c.evidence_snapshot["monthly_savings"] > 0
        assert c.evidence_snapshot["table_count"] == 1
        assert len(c.evidence_snapshot["tables"]) == 1
        assert c.evidence_snapshot["tables"][0]["table_name"] == "events"

    def test_physical_cost_does_not_double_count_time_travel(self):
        """ACTIVE_PHYSICAL_BYTES already includes time-travel bytes."""
        rule = StorageBillingRule()
        metrics = [
            _make_metric(
                active_logical_bytes=150 * BYTES_PER_GB,
                long_term_logical_bytes=0,
                active_physical_bytes=40 * BYTES_PER_GB,
                long_term_physical_bytes=0,
                time_travel_physical_bytes=30 * BYTES_PER_GB,
                fail_safe_physical_bytes=10 * BYTES_PER_GB,
            ),
        ]

        thresholds = rule.get_thresholds()
        thresholds["_storage_metrics"] = metrics
        candidates = rule.detect([], None, thresholds)

        assert len(candidates) == 1
        ev = candidates[0].evidence_snapshot
        assert ev["logical_cost_monthly"] == 3.0
        assert ev["physical_cost_monthly"] == 2.0
        assert ev["monthly_savings"] == 1.0

    def test_no_savings_when_physical_more_expensive(self):
        """Low compression + high time travel means physical costs more."""
        rule = StorageBillingRule()
        metrics = [
            _make_metric(
                active_logical_bytes=100_000_000,
                long_term_logical_bytes=0,
                active_physical_bytes=90_000_000,
                long_term_physical_bytes=0,
                time_travel_physical_bytes=50_000_000,
                fail_safe_physical_bytes=50_000_000,
            ),
        ]

        thresholds = rule.get_thresholds()
        thresholds["_storage_metrics"] = metrics
        candidates = rule.detect([], None, thresholds)

        assert len(candidates) == 0

    def test_skips_already_physical(self):
        """Tables already on physical billing are skipped."""
        rule = StorageBillingRule()
        metrics = [
            _make_metric(billing_model="PHYSICAL"),
        ]

        thresholds = rule.get_thresholds()
        thresholds["_storage_metrics"] = metrics
        candidates = rule.detect([], None, thresholds)

        assert len(candidates) == 0

    def test_no_savings_skipped(self):
        """Tables with no savings (physical more expensive) are skipped."""
        rule = StorageBillingRule()
        metrics = [
            _make_metric(
                active_logical_bytes=1_000_000,
                long_term_logical_bytes=0,
                active_physical_bytes=2_000_000,
                long_term_physical_bytes=0,
                time_travel_physical_bytes=500_000,
                fail_safe_physical_bytes=500_000,
            ),
        ]

        thresholds = rule.get_thresholds()
        thresholds["_storage_metrics"] = metrics
        candidates = rule.detect([], None, thresholds)

        assert len(candidates) == 0

    def test_different_datasets_separate_opportunities(self):
        """Tables in different datasets produce separate opportunities."""
        rule = StorageBillingRule()
        metrics = [
            _make_metric(
                dataset_name="ds1",
                table_name="t1",
                active_logical_bytes=500_000_000_000,
                long_term_logical_bytes=200_000_000_000,
                active_physical_bytes=100_000_000_000,
                long_term_physical_bytes=50_000_000_000,
                time_travel_physical_bytes=10_000_000_000,
                fail_safe_physical_bytes=5_000_000_000,
            ),
            _make_metric(
                dataset_name="ds2",
                table_name="t2",
                active_logical_bytes=300_000_000_000,
                long_term_logical_bytes=100_000_000_000,
                active_physical_bytes=60_000_000_000,
                long_term_physical_bytes=20_000_000_000,
                time_travel_physical_bytes=8_000_000_000,
                fail_safe_physical_bytes=4_000_000_000,
            ),
        ]

        thresholds = rule.get_thresholds()
        thresholds["_storage_metrics"] = metrics
        candidates = rule.detect([], None, thresholds)

        assert len(candidates) == 2
        affected = {c.affected_table for c in candidates}
        assert "test-project.ds1" in affected
        assert "test-project.ds2" in affected

    def test_multiple_tables_same_dataset_single_opportunity(self):
        """Multiple tables in one dataset produce a single aggregated opportunity."""
        rule = StorageBillingRule()
        metrics = [
            _make_metric(
                dataset_name="analytics",
                table_name="events",
                active_logical_bytes=400_000_000_000,
                long_term_logical_bytes=100_000_000_000,
                active_physical_bytes=80_000_000_000,
                long_term_physical_bytes=20_000_000_000,
                time_travel_physical_bytes=10_000_000_000,
                fail_safe_physical_bytes=5_000_000_000,
            ),
            _make_metric(
                dataset_name="analytics",
                table_name="users",
                active_logical_bytes=200_000_000_000,
                long_term_logical_bytes=50_000_000_000,
                active_physical_bytes=40_000_000_000,
                long_term_physical_bytes=10_000_000_000,
                time_travel_physical_bytes=5_000_000_000,
                fail_safe_physical_bytes=2_500_000_000,
            ),
        ]

        thresholds = rule.get_thresholds()
        thresholds["_storage_metrics"] = metrics
        candidates = rule.detect([], None, thresholds)

        assert len(candidates) == 1
        c = candidates[0]
        assert c.affected_table == "test-project.analytics"
        assert c.evidence_snapshot["table_count"] == 2
        assert len(c.evidence_snapshot["tables"]) == 2
        table_names = {t["table_name"] for t in c.evidence_snapshot["tables"]}
        assert table_names == {"events", "users"}
        # Savings should be aggregated (greater than either table alone)
        assert c.expected_savings > 0

    def test_empty_metrics_returns_empty(self):
        """No storage metrics produces no opportunities."""
        rule = StorageBillingRule()
        thresholds = rule.get_thresholds()
        thresholds["_storage_metrics"] = []
        candidates = rule.detect([], None, thresholds)
        assert len(candidates) == 0

    def test_no_storage_metrics_key(self):
        """Missing _storage_metrics key returns empty."""
        rule = StorageBillingRule()
        thresholds = rule.get_thresholds()
        candidates = rule.detect([], None, thresholds)
        assert len(candidates) == 0

    def test_evidence_snapshot_structure(self):
        """Evidence snapshot contains all required fields."""
        rule = StorageBillingRule()
        metrics = [
            _make_metric(
                active_logical_bytes=500_000_000_000,
                long_term_logical_bytes=200_000_000_000,
                active_physical_bytes=100_000_000_000,
                long_term_physical_bytes=50_000_000_000,
                time_travel_physical_bytes=10_000_000_000,
                fail_safe_physical_bytes=5_000_000_000,
            ),
        ]

        thresholds = rule.get_thresholds()
        thresholds["_storage_metrics"] = metrics
        candidates = rule.detect([], None, thresholds)

        assert len(candidates) == 1
        ev = candidates[0].evidence_snapshot

        # Required fields
        assert "dataset" in ev
        assert "dataset_name" in ev
        assert "table_count" in ev
        assert "tables" in ev
        assert "current_billing_model" in ev
        assert "compression_ratio" in ev
        assert "logical_cost_monthly" in ev
        assert "physical_cost_monthly" in ev
        assert "monthly_savings" in ev
        assert "annual_savings" in ev
        assert "savings_percentage" in ev
        assert "pricing" in ev
        assert ev["current_billing_model"] == "LOGICAL"
        assert ev["annual_savings"] == round(ev["monthly_savings"] * 12, 2)
        assert ev["table_count"] == 1
        assert isinstance(ev["tables"], list)

    def test_manifest_does_not_filter_dataset_level_billing(self):
        """Storage billing is dataset-level, so all dataset tables count."""
        rule = StorageBillingRule()
        metrics = [
            _make_metric(
                dataset_name="analytics",
                table_name="events",
                active_logical_bytes=500_000_000_000,
                long_term_logical_bytes=200_000_000_000,
                active_physical_bytes=100_000_000_000,
                long_term_physical_bytes=50_000_000_000,
                time_travel_physical_bytes=10_000_000_000,
                fail_safe_physical_bytes=5_000_000_000,
            ),
            _make_metric(
                dataset_name="analytics",
                table_name="not_in_manifest",
                active_logical_bytes=500_000_000_000,
                long_term_logical_bytes=200_000_000_000,
                active_physical_bytes=100_000_000_000,
                long_term_physical_bytes=50_000_000_000,
                time_travel_physical_bytes=10_000_000_000,
                fail_safe_physical_bytes=5_000_000_000,
            ),
        ]

        manifest = {
            "nodes": {
                "model.project.events": {
                    "name": "events",
                    "schema": "analytics",
                    "identifier": "events",
                    "database": "test-project",
                },
            }
        }

        thresholds = rule.get_thresholds()
        thresholds["_storage_metrics"] = metrics
        candidates = rule.detect([], manifest, thresholds)

        assert len(candidates) == 1
        assert candidates[0].affected_table == "test-project.analytics"
        assert candidates[0].evidence_snapshot["table_count"] == 2

    def test_no_manifest_passes_all(self):
        """Without manifest, all tables pass through."""
        rule = StorageBillingRule()
        metrics = [
            _make_metric(
                dataset_name="analytics",
                table_name="events",
                active_logical_bytes=500_000_000_000,
                long_term_logical_bytes=200_000_000_000,
                active_physical_bytes=100_000_000_000,
                long_term_physical_bytes=50_000_000_000,
                time_travel_physical_bytes=10_000_000_000,
                fail_safe_physical_bytes=5_000_000_000,
            ),
        ]

        thresholds = rule.get_thresholds()
        thresholds["_storage_metrics"] = metrics
        candidates = rule.detect([], None, thresholds)

        assert len(candidates) == 1

    def test_severity_tiers(self):
        """Severity maps correctly based on savings amount."""
        assert _severity_from_savings(Decimal("0.50")) == 20
        assert _severity_from_savings(Decimal("5.00")) == 20
        assert _severity_from_savings(Decimal("15.00")) == 40
        assert _severity_from_savings(Decimal("150.00")) == 60
        assert _severity_from_savings(Decimal("1500.00")) == 80
        assert _severity_from_savings(Decimal("15000.00")) == 100

    def test_dbt_model_name_is_none_for_dataset(self):
        """Dataset-level opportunities have dbt_model_name=None."""
        rule = StorageBillingRule()
        metrics = [
            _make_metric(
                active_logical_bytes=500_000_000_000,
                long_term_logical_bytes=200_000_000_000,
                active_physical_bytes=100_000_000_000,
                long_term_physical_bytes=50_000_000_000,
                time_travel_physical_bytes=10_000_000_000,
                fail_safe_physical_bytes=5_000_000_000,
            ),
        ]
        thresholds = rule.get_thresholds()
        thresholds["_storage_metrics"] = metrics
        candidates = rule.detect([], None, thresholds)

        assert len(candidates) == 1
        assert candidates[0].dbt_model_name is None
