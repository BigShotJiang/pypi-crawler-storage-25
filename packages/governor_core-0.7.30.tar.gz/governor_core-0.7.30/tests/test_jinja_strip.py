"""Unit tests for Jinja2 pre-processor."""

from governor_core.solutions.validation.jinja_strip import strip_jinja


class TestStripJinja:
    """Tests for strip_jinja()."""

    def test_ref_replacement(self):
        sql = "SELECT * FROM {{ ref('orders') }}"
        result = strip_jinja(sql)
        assert "orders" in result.sql
        assert "{{" not in result.sql
        assert result.expressions_replaced >= 1
        assert result.success is True

    def test_ref_double_quotes(self):
        sql = 'SELECT * FROM {{ ref("orders") }}'
        result = strip_jinja(sql)
        assert "orders" in result.sql
        assert "{{" not in result.sql

    def test_source_replacement(self):
        sql = "SELECT * FROM {{ source('raw', 'customers') }}"
        result = strip_jinja(sql)
        assert "customers" in result.sql
        assert "{{" not in result.sql

    def test_config_removal(self):
        sql = '{{ config(materialized="table") }}\nSELECT 1'
        result = strip_jinja(sql)
        assert "config" not in result.sql
        assert "SELECT 1" in result.sql

    def test_multiline_config_removal(self):
        sql = """\
{{ config(
    materialized="table",
    cluster_by=["customer_id"]
) }}

SELECT * FROM orders
"""
        result = strip_jinja(sql)
        assert "config" not in result.sql
        assert "SELECT * FROM orders" in result.sql

    def test_block_tag_removal(self):
        sql = """\
SELECT
    {% if target.name == 'prod' %}
    production_col
    {% else %}
    dev_col
    {% endif %}
FROM table
"""
        result = strip_jinja(sql)
        assert "{%" not in result.sql
        assert result.unparseable_blocks >= 1
        assert result.success is False  # Control flow detected

    def test_remaining_expression_replacement(self):
        sql = "SELECT {{ some_macro() }} FROM table"
        result = strip_jinja(sql)
        assert "__jinja_expr__" in result.sql
        assert "{{" not in result.sql

    def test_plain_sql_unchanged(self):
        sql = "SELECT id, name FROM users WHERE active = true"
        result = strip_jinja(sql)
        assert result.sql == sql
        assert result.expressions_replaced == 0
        assert result.success is True

    def test_mixed_jinja(self):
        sql = """\
{{ config(materialized="table") }}

SELECT
    id,
    {{ ref('customers') }}.name,
    {{ source('raw', 'orders') }}.total
FROM {{ ref('customers') }}
JOIN {{ source('raw', 'orders') }} ON id = customer_id
"""
        result = strip_jinja(sql)
        assert "{{" not in result.sql
        assert "customers" in result.sql
        assert "orders" in result.sql
        assert result.success is True

    def test_for_loop_marks_unparseable(self):
        sql = """\
SELECT
    {% for col in columns %}
    {{ col }},
    {% endfor %}
    id
FROM table
"""
        result = strip_jinja(sql)
        assert result.unparseable_blocks >= 1
        assert result.success is False

    def test_whitespace_control(self):
        sql = "SELECT * FROM {%- if true %} table {%- endif %}"
        result = strip_jinja(sql)
        assert "{%" not in result.sql

    def test_empty_sql(self):
        result = strip_jinja("")
        assert result.sql == ""
        assert result.success is True
