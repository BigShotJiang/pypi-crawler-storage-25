"""Unit tests for app/solutions/templates/remove_unused_joins.py."""

from types import SimpleNamespace

from governor_core.solutions.templates.remove_unused_joins import (
    RemoveUnusedJoinsTemplate,
    _remove_join_from_cte,
)


def _make_opportunity(evidence: dict | None = None):
    return SimpleNamespace(
        id="opp-1",
        opportunity_type="unused_join",
        evidence_snapshot=evidence or {},
        dbt_model_name="my_model",
        affected_table="project.dataset.my_model",
    )


class TestRemoveJoinFromCte:
    def test_removes_unused_left_join(self):
        sql = (
            "WITH\n"
            "  rhs AS (\n"
            "    SELECT customer_id FROM raw_customers GROUP BY customer_id\n"
            "  ),\n"
            "  base AS (\n"
            "    SELECT\n"
            "      o.order_id\n"
            "    FROM raw_orders o\n"
            "    LEFT JOIN rhs r ON o.customer_id = r.customer_id\n"
            "    WHERE o.order_id > 10\n"
            "  )\n"
            "SELECT order_id FROM base\n"
        )

        result = _remove_join_from_cte(sql, "base", "r")

        assert result is not None
        assert "LEFT JOIN rhs r" not in result
        assert "WHERE o.order_id > 10" in result
        assert "FROM raw_orders o" in result

    def test_unknown_alias_returns_none(self):
        sql = (
            "WITH base AS (\n"
            "  SELECT o.order_id FROM raw_orders o\n"
            "  LEFT JOIN rhs r ON o.customer_id = r.customer_id\n"
            ")\n"
            "SELECT order_id FROM base\n"
        )

        assert _remove_join_from_cte(sql, "base", "missing") is None


class TestRemoveUnusedJoinsTemplate:
    def test_matches_requires_joins_and_source_file(self):
        template = RemoveUnusedJoinsTemplate()
        opp = _make_opportunity(
            {
                "unused_joins": [
                    {
                        "cte_name": "base",
                        "join_alias": "r",
                        "joined_source_name": "rhs",
                        "join_keys": ["customer_id"],
                    }
                ]
            }
        )

        assert (
            template.matches(
                opp,
                {"models/marts/test.sql": "select 1"},
                {"original_file_path": "models/marts/test.sql"},
            )
            is True
        )

    def test_apply_removes_unused_join(self):
        template = RemoveUnusedJoinsTemplate()
        sql = (
            "WITH\n"
            "  rhs AS (\n"
            "    SELECT customer_id FROM raw_customers GROUP BY customer_id\n"
            "  ),\n"
            "  base AS (\n"
            "    SELECT\n"
            "      o.order_id\n"
            "    FROM raw_orders o\n"
            "    LEFT JOIN rhs r ON o.customer_id = r.customer_id\n"
            "    WHERE o.order_id > 10\n"
            "  )\n"
            "SELECT order_id FROM base\n"
        )
        opp = _make_opportunity(
            {
                "unused_joins": [
                    {
                        "cte_name": "base",
                        "join_alias": "r",
                        "joined_source_name": "rhs",
                        "join_keys": ["customer_id"],
                    }
                ]
            }
        )

        result = template.apply(
            opp,
            {"models/marts/test.sql": sql},
            {"original_file_path": "models/marts/test.sql", "name": "test"},
        )

        assert result is not None
        assert result.template_id == "remove_unused_joins"
        assert "LEFT JOIN rhs r" not in result.after_content
        assert "WHERE o.order_id > 10" in result.after_content
        assert result.parameters["unused_joins"][0]["join_alias"] == "r"
