"""Spec 124: auto-shadow-validation worker-hook unit tests.

Exercises ``Worker._maybe_auto_shadow_validate``'s four-clause gate:

    config.auto_shadow_validate_safe_solutions
    AND config.shadow_validation_enabled
    AND config.local_project_path
    AND solution.risk_level == 'low'

Six cases mock `run_shadow_validation` to assert call/no-call. One more
case invokes the real validator end-to-end (with builder/metrics stubs
like test_shadow_service.py) to confirm ``triggered_by='auto'`` persists.
"""

from __future__ import annotations

from datetime import datetime, timezone
from unittest.mock import MagicMock, patch

import pytest

from governor_core.shadow.builder import BuildResult
from governor_core.shadow.diff import ModelMetric
from governor_core.shadow.models import ShadowValidationRun
from governor_core.sync.worker import Worker

from tests.fixtures.factories import SolutionFactory


_MANIFEST_CONTENT = {
    "child_map": {
        "model.p.fct_orders": [],
    },
    "nodes": {
        "model.p.fct_orders": {
            "original_file_path": "models/staging/stg_orders.sql",
        },
    },
    "metadata": {"project_name": "p"},
}


def _ok_builder(*, phase, cascade, run_id):  # noqa: ARG001
    return BuildResult(
        phase=phase,
        started_at=datetime.now(timezone.utc),
        completed_at=datetime.now(timezone.utc),
        success=True,
    )


class _SavingsMetrics:
    def __init__(self):
        self._calls = 0

    def __call__(self, *, run_results, expected_models):  # noqa: ARG002
        self._calls += 1
        factor = 1.0 if self._calls == 1 else 0.7
        return [
            ModelMetric(
                model_name=m,
                bytes_processed=int(10_000_000 * factor),
                slot_ms=int(5_000 * factor),
                row_count=1_000,
            )
            for m in expected_models
        ]


def _seed(
    db,
    *,
    risk_level: str = "low",
    auto_on: bool = True,
    shadow_on: bool = True,
    local_path: str = "/tmp/x",
):
    """Seed a completed solution_job + manifest + single Solution row.

    Returns (solution_job, config, solution).
    """
    solution = SolutionFactory.create(
        risk_level=risk_level,
        file_path="models/staging/stg_orders.sql",
    )
    job = solution.solution_job
    config = solution.solution_job.opportunity.configuration
    manifest_version = solution.solution_job.opportunity.manifest_version

    manifest_version.content = _MANIFEST_CONTENT
    config.auto_shadow_validate_safe_solutions = auto_on
    config.shadow_validation_enabled = shadow_on
    config.local_project_path = local_path
    config.shadow_budget_usd = 10.0
    config.shadow_cascade_cap = 20
    config.shadow_timeout_seconds = 1800
    db.flush()
    return job, config, solution


def _count_runs(db):
    return db.query(ShadowValidationRun).count()


# --------------------------------------------------------------------------
# Mocked-validator gate cases (T007 + T008)
# --------------------------------------------------------------------------


def test_safe_solution_with_toggle_on_triggers_auto_validation(db):
    job, config, _sol = _seed(db)
    worker = Worker(MagicMock())

    with patch(
        "governor_core.shadow.service.run_shadow_validation"
    ) as mock_run:
        worker._maybe_auto_shadow_validate(job, config, db)

    assert mock_run.call_count == 1
    _, kwargs = mock_run.call_args
    assert kwargs["triggered_by"] == "auto"


def test_safe_solution_with_toggle_off_does_not_trigger(db):
    job, config, _sol = _seed(db, auto_on=False)
    worker = Worker(MagicMock())

    with patch(
        "governor_core.shadow.service.run_shadow_validation"
    ) as mock_run:
        worker._maybe_auto_shadow_validate(job, config, db)

    assert mock_run.call_count == 0


@pytest.mark.xfail(
    strict=True,
    reason=(
        "spec 129: asserts risk-level gating that was removed. The worker's "
        "auto-shadow-validate log line now reads 'all risk levels', i.e. the "
        "filter on review/high-risk was deliberately dropped. Rewrite against "
        "the current gating model (or delete if the gate is gone for good) in "
        "a follow-up."
    ),
)
def test_review_tier_solution_is_skipped(db):
    job, config, _sol = _seed(db, risk_level="medium")
    worker = Worker(MagicMock())

    with patch(
        "governor_core.shadow.service.run_shadow_validation"
    ) as mock_run:
        worker._maybe_auto_shadow_validate(job, config, db)

    assert mock_run.call_count == 0


@pytest.mark.xfail(
    strict=True,
    reason=(
        "spec 129: asserts risk-level gating that was removed. See "
        "test_review_tier_solution_is_skipped for rationale."
    ),
)
def test_high_risk_solution_is_skipped(db):
    job, config, _sol = _seed(db, risk_level="high")
    worker = Worker(MagicMock())

    with patch(
        "governor_core.shadow.service.run_shadow_validation"
    ) as mock_run:
        worker._maybe_auto_shadow_validate(job, config, db)

    assert mock_run.call_count == 0


def test_shadow_validation_disabled_blocks_auto(db):
    job, config, _sol = _seed(db, shadow_on=False)
    worker = Worker(MagicMock())

    with patch(
        "governor_core.shadow.service.run_shadow_validation"
    ) as mock_run:
        worker._maybe_auto_shadow_validate(job, config, db)

    assert mock_run.call_count == 0


def test_missing_local_project_path_blocks_auto(db):
    job, config, _sol = _seed(db, local_path="")
    worker = Worker(MagicMock())

    with patch(
        "governor_core.shadow.service.run_shadow_validation"
    ) as mock_run:
        worker._maybe_auto_shadow_validate(job, config, db)

    assert mock_run.call_count == 0


# --------------------------------------------------------------------------
# End-to-end: real validator writes a run row with triggered_by='auto' (T009)
# --------------------------------------------------------------------------


def test_auto_trigger_persists_triggered_by_auto(db):
    """Let the real validator run with stub builder/metrics and confirm
    the resulting ShadowValidationRun row has ``triggered_by='auto'``."""
    job, config, sol = _seed(db)
    worker = Worker(MagicMock())

    before = _count_runs(db)
    # Patch builder/metrics at the shadow.builder + shadow.metrics entry
    # points so the validator ORM-write path runs end-to-end.
    with patch(
        "governor_core.shadow.builder.run_dbt_cascade",
        side_effect=_ok_builder,
    ), patch(
        "governor_core.shadow.metrics.metrics_from_run_results",
        side_effect=_SavingsMetrics(),
    ):
        worker._maybe_auto_shadow_validate(job, config, db)

    assert _count_runs(db) == before + 1
    run = (
        db.query(ShadowValidationRun)
        .filter(ShadowValidationRun.solution_id == sol.id)
        .one()
    )
    assert run.triggered_by == "auto"
