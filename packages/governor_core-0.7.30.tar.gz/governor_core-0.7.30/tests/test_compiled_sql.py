"""Unit tests for manifest-backed optimized SQL synthesis."""

from __future__ import annotations

from governor_core.utils.compiled_sql import apply_diff_to_compiled


def test_apply_diff_to_compiled_handles_pure_line_deletion():
    before = "\n".join(
        [
            "select",
            "  date,",
            "  avg_block_time,",
            "  min_block_time,",
            "  max_block_time",
            "from block_health",
        ]
    )
    after = "\n".join(
        [
            "select",
            "  date,",
            "  avg_block_time,",
            "  max_block_time",
            "from block_health",
        ]
    )
    compiled = before

    result = apply_diff_to_compiled(before, after, compiled)

    assert result == after


def test_apply_diff_to_compiled_ignores_config_only_changes():
    before = "{{ config(materialized='view') }}\nselect 1 as id"
    after = "{{ config(materialized='table') }}\nselect 1 as id"
    compiled = "select 1 as id"

    result = apply_diff_to_compiled(before, after, compiled)

    assert result == compiled


def test_apply_diff_to_compiled_ignores_multiline_config_changes():
    before = """{{ config(
    materialized='view',
    partition_by={'field': 'event_date', 'data_type': 'date'}
) }}

select id
from orders"""
    after = """{{ config(
    materialized='table',
    partition_by={'field': 'event_date', 'data_type': 'date'},
    cluster_by=['id']
) }}

select id
from orders"""
    compiled = "select id\nfrom orders"

    result = apply_diff_to_compiled(before, after, compiled)

    assert result == compiled


def test_apply_diff_to_compiled_handles_multiline_config_and_sql_changes():
    before = """{{ config(
    materialized='view',
    partition_by={'field': 'event_date', 'data_type': 'date'}
) }}

select id
from orders"""
    after = """{{ config(
    materialized='table',
    partition_by={'field': 'event_date', 'data_type': 'date'},
    cluster_by=['id']
) }}

select id, customer_id
from orders"""
    compiled = "select id\nfrom orders"

    result = apply_diff_to_compiled(before, after, compiled)

    assert result == "select id, customer_id\nfrom orders"
