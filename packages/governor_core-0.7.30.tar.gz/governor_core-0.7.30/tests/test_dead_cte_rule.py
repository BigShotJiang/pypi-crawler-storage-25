"""Unit tests for app/opportunities/rules/dead_cte.py."""

from decimal import Decimal
from types import SimpleNamespace

import pytest

from governor_core.opportunities.rules.dead_cte import DeadCteRule


def _node(name: str, sql: str, materialized: str = "table") -> dict:
    return {
        "name": name,
        "unique_id": f"model.proj.{name}",
        "database": "my-project",
        "schema": "dbt_prod",
        "identifier": name,
        "config": {"materialized": materialized},
        "raw_code": sql,
        "compiled_code": sql,
    }


def _manifest() -> dict:
    sql = """
WITH
  used_stage AS (SELECT id, amount FROM raw_orders),
  unused_stage AS (SELECT customer_id, order_id FROM raw_customers),
  final AS (SELECT id, amount FROM used_stage)
SELECT id, amount FROM final
"""
    return {
        "nodes": {"model.proj.fct_orders": _node("fct_orders", sql)},
        "child_map": {"model.proj.fct_orders": []},
    }


def test_rule_type():
    assert DeadCteRule().rule_type == "dead_cte"


def test_default_thresholds():
    thresholds = DeadCteRule().default_thresholds
    assert thresholds["min_dead_ctes"] == 1


def test_detect_none_manifest():
    assert DeadCteRule().detect(jobs=[], manifest_content=None, thresholds={}) == []


def test_detect_returns_dead_cte_candidate():
    rule = DeadCteRule()
    results = rule.detect(jobs=[], manifest_content=_manifest(), thresholds={})

    assert len(results) == 1
    candidate = results[0]
    assert candidate.opportunity_type == "dead_cte"
    assert candidate.dbt_model_name == "fct_orders"
    assert candidate.evidence_snapshot["dead_ctes"] == ["unused_stage"]
    assert candidate.evidence_snapshot["dead_cte_count"] == 1
    assert candidate.confidence == pytest.approx(0.55)


def test_detect_no_job_data_zero_savings():
    results = DeadCteRule().detect(jobs=[], manifest_content=_manifest(), thresholds={})

    assert len(results) == 1
    assert results[0].expected_savings == Decimal("0")
    assert results[0].current_cost_estimate == Decimal("0")


def test_detect_uses_tib_pricing_for_average_cost_per_run():
    results = DeadCteRule().detect(
        jobs=[
            SimpleNamespace(
                destination_table="my-project.dbt_prod.fct_orders",
                total_bytes_processed=1024**4,
                job_id="job-1",
            )
        ],
        manifest_content=_manifest(),
        thresholds={},
    )

    assert len(results) == 1
    assert results[0].current_cost_estimate == Decimal("6.25")


def test_detect_min_dead_ctes_threshold():
    results = DeadCteRule().detect(
        jobs=[],
        manifest_content=_manifest(),
        thresholds={"min_dead_ctes": 2},
    )

    assert results == []


def test_detect_includes_suppressed_lower_priority_findings():
    sql = """
WITH
  rhs AS (
    SELECT customer_id
    FROM raw_customers
    GROUP BY customer_id
  ),
  dead_ordered AS (
    SELECT order_id, created_at
    FROM raw_orders
    ORDER BY created_at DESC
  ),
  dead_window AS (
    SELECT
      id,
      ROW_NUMBER() OVER (PARTITION BY id ORDER BY ts) AS rn
    FROM raw_events
  ),
  dead_agg AS (
    SELECT
      customer_id,
      SUM(amount) AS total_amount
    FROM raw_orders
    GROUP BY customer_id
  ),
  dead_join AS (
    SELECT o.order_id
    FROM raw_orders o
    LEFT JOIN rhs r ON o.customer_id = r.customer_id
  ),
  final AS (
    SELECT 1 AS sentinel
  )
SELECT sentinel FROM final
"""
    manifest = {
        "nodes": {"model.proj.fct_orders": _node("fct_orders", sql)},
        "child_map": {"model.proj.fct_orders": []},
    }

    results = DeadCteRule().detect(jobs=[], manifest_content=manifest, thresholds={})

    assert len(results) == 1
    suppressed = results[0].evidence_snapshot["suppressed_findings"]
    assert {item["rule_type"] for item in suppressed} == {
        "dead_column",
        "dead_window_expression",
        "unused_aggregation_output",
        "redundant_order_by",
        "unused_join",
    }
