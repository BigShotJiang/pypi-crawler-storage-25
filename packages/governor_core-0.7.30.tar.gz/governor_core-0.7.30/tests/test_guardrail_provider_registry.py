"""Spec 132: interface-validation tests for the ``GuardrailProvider`` registry.

These tests exist to prove the generalisation is honest: a new guardrail
can register by instantiating a provider and calling ``register_provider``,
with zero edits to pipeline code. The whole spec 132 payoff depends on that
invariant holding.
"""

from __future__ import annotations

from dataclasses import dataclass
from unittest.mock import MagicMock

import pytest

from governor_core.agents.downstream_patch.providers import (
    GuardrailProvider,
    _REGISTRY,
    get_provider,
    register_provider,
    registered_template_ids,
)
from governor_core.shadow.failure_analysis import DownstreamFailure, DownstreamPatch


@dataclass(frozen=True)
class _StubContext:
    """Intentionally different shape from ``UpstreamPartitionContext`` so the
    test proves the pipeline treats context objects opaquely."""

    arbitrary_field: str
    another_field: int
    source_shadow_run_id: str


class _StubProvider(GuardrailProvider):
    template_id = "test_guardrail_stub"

    def build_upstream_context(
        self, solution, manifest_content, shadow_run_id
    ) -> _StubContext:
        return _StubContext(
            arbitrary_field="stub-ok",
            another_field=42,
            source_shadow_run_id=str(shadow_run_id),
        )

    async def propose_patch(
        self, failure, context, *, llm_provider
    ) -> DownstreamPatch:
        # Assert the pipeline handed us the context we built, unchanged.
        assert isinstance(context, _StubContext)
        assert context.arbitrary_field == "stub-ok"
        return DownstreamPatch(
            file_path=failure.original_file_path,
            before_content="-- before",
            after_content="-- after via stub",
            proposal_meta={
                "status": "proposed",
                "change_type": "stub_patch",
                "source_shadow_run_id": context.source_shadow_run_id,
            },
            status="proposed",
        )


@pytest.fixture
def _with_stub_registered(monkeypatch):
    """Register the stub and unregister on teardown."""
    stub = _StubProvider()
    register_provider(stub)
    try:
        yield stub
    finally:
        # Direct dict deletion — registry is a module-level dict.
        _REGISTRY.pop(stub.template_id, None)


class TestRegistryPrimitives:
    def test_require_partition_filter_provider_is_registered(self):
        """Spec 132 baseline: the reference provider is present."""
        assert "add_require_partition_filter" in registered_template_ids()
        provider = get_provider("add_require_partition_filter")
        assert provider is not None
        assert provider.template_id == "add_require_partition_filter"

    def test_get_provider_returns_none_for_unregistered_template_id(self):
        """FR-009: silent no-op for solutions whose template_id is unknown."""
        assert get_provider("not_a_real_template") is None
        assert get_provider("") is None
        assert get_provider(None) is None

    def test_duplicate_registration_raises(self):
        """FR-002: determinism over last-write-wins."""
        dup = _StubProvider()
        register_provider(dup)
        try:
            with pytest.raises(ValueError, match="duplicate"):
                register_provider(_StubProvider())
        finally:
            _REGISTRY.pop("test_guardrail_stub", None)


class TestPipelineDispatchesViaRegistry:
    """Story 2 Acceptance Scenarios — dispatch happens through the registry,
    not through any hard-coded string."""

    def test_registered_stub_is_retrievable_with_opaque_context(
        self, _with_stub_registered
    ):
        """Scenario 1 + 3: the pipeline can look up a stub provider whose
        context dataclass carries different fields than the reference."""
        provider = get_provider("test_guardrail_stub")
        assert provider is _with_stub_registered
        context = provider.build_upstream_context(
            solution=MagicMock(), manifest_content={}, shadow_run_id="run-42"
        )
        # The pipeline holds this object opaquely — it never inspects its
        # fields. We only assert the provider-specific shape here.
        assert context.arbitrary_field == "stub-ok"
        assert context.another_field == 42

    def test_stub_propose_patch_runs_without_pipeline_edits(
        self, _with_stub_registered
    ):
        """Scenario 1: a failing downstream dispatched to the stub yields a
        DownstreamPatch with the stub's content — no pipeline code was
        edited to support it, only the registry lookup."""
        import asyncio

        provider = get_provider("test_guardrail_stub")
        failure = DownstreamFailure(
            node_id="model.p.m",
            model_name="m",
            original_file_path="models/m.sql",
            package_name="p",
            error_type="compile_error",
            error_message=None,
            is_in_project=True,
            compiled_sql="select 1",
        )
        context = provider.build_upstream_context(
            solution=MagicMock(), manifest_content={}, shadow_run_id="run-7"
        )
        patch = asyncio.run(
            provider.propose_patch(failure, context, llm_provider=MagicMock())
        )
        assert patch.status == "proposed"
        assert patch.after_content == "-- after via stub"
        assert patch.proposal_meta["change_type"] == "stub_patch"
        assert patch.proposal_meta["source_shadow_run_id"] == "run-7"

    def test_unregistered_template_id_yields_none(self):
        """Scenario 2: solutions with unregistered template_id get None,
        which the pipeline treats as a silent no-op."""
        assert get_provider("literally_not_registered") is None
