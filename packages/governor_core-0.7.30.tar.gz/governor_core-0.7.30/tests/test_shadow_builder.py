"""Unit tests for builder overlay helpers (no dbt subprocess)."""

from __future__ import annotations

import uuid
from pathlib import Path

import pytest
import yaml

from governor_core.shadow.builder import (
    _alias_overlay_yaml,
    _apply_shadow_file_change,
    _copy_project_to_workspace,
    _merge_overlay_into_project_yml,
    _phase_suffix,
)


def test_phase_suffix_shape():
    sid = "550e8400-e29b-41d4-a716-446655440000"
    assert _phase_suffix(sid, "baseline") == "__governor_550e8400e29b_baseline"
    assert _phase_suffix(sid, "shadow") == "__governor_550e8400e29b_shadow"


def test_alias_overlay_shape_flat_fallback():
    """Without manifest content, overlay falls back to flat nesting."""
    overlay = _alias_overlay_yaml(
        ["model.p.fct_orders", "model.p.daily_revenue"],
        project_name="p",
        suffix="__governor_abc123_shadow",
    )
    models = overlay["models"]["p"]
    assert models["fct_orders"]["+alias"] == "fct_orders__governor_abc123_shadow"
    assert (
        models["daily_revenue"]["+alias"]
        == "daily_revenue__governor_abc123_shadow"
    )


def test_alias_overlay_uses_fqn_from_manifest():
    """With manifest content, overlay nests at the full fqn path —
    critical because dbt silently ignores configs at wrong paths and
    would then materialise into production tables."""
    manifest = {
        "nodes": {
            "model.p.rpt_storm_correlation": {
                "fqn": ["p", "marts", "rpt_storm_correlation"],
            },
            "model.p.stg_weather": {
                "fqn": ["p", "staging", "stg_weather"],
            },
        }
    }
    overlay = _alias_overlay_yaml(
        ["model.p.rpt_storm_correlation", "model.p.stg_weather"],
        project_name="p",
        suffix="__governor_abc_shadow",
        manifest_content=manifest,
    )
    assert (
        overlay["models"]["p"]["marts"]["rpt_storm_correlation"]["+alias"]
        == "rpt_storm_correlation__governor_abc_shadow"
    )
    assert (
        overlay["models"]["p"]["staging"]["stg_weather"]["+alias"]
        == "stg_weather__governor_abc_shadow"
    )


def test_merge_overlay_preserves_existing_yaml(tmp_path):
    project_yml = tmp_path / "dbt_project.yml"
    project_yml.write_text(
        yaml.safe_dump(
            {
                "name": "p",
                "version": "1.0",
                "models": {"p": {"fct_orders": {"+materialized": "table"}}},
            }
        )
    )
    _merge_overlay_into_project_yml(
        tmp_path,
        {"models": {"p": {"fct_orders": {"+alias": "fct_orders__governor_x"}}}},
    )
    merged = yaml.safe_load(project_yml.read_text())
    orders = merged["models"]["p"]["fct_orders"]
    assert orders["+materialized"] == "table"
    assert orders["+alias"] == "fct_orders__governor_x"
    assert merged["name"] == "p"


def test_copy_project_ignores_transient_dirs(tmp_path):
    src = tmp_path / "src"
    dst = tmp_path / "dst"
    src.mkdir()
    (src / "models").mkdir()
    (src / "models" / "a.sql").write_text("select 1")
    (src / "target").mkdir()
    (src / "target" / "compiled.sql").write_text("compiled")
    (src / ".git").mkdir()
    (src / ".git" / "HEAD").write_text("ref")

    _copy_project_to_workspace(src, dst)

    assert (dst / "models" / "a.sql").exists()
    assert not (dst / "target").exists()
    assert not (dst / ".git").exists()


def test_apply_shadow_file_change(tmp_path):
    (tmp_path / "models").mkdir()
    target = tmp_path / "models" / "a.sql"
    target.write_text("select 1")

    _apply_shadow_file_change(tmp_path, "models/a.sql", "select 2")
    assert target.read_text() == "select 2"


def test_apply_shadow_file_change_missing_file_raises(tmp_path):
    with pytest.raises(FileNotFoundError):
        _apply_shadow_file_change(tmp_path, "models/missing.sql", "x")
