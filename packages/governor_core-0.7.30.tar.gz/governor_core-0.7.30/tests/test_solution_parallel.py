"""Tests for parallel solution generation in the Worker.

Verifies that the Worker uses a ThreadPoolExecutor to process solution
jobs concurrently, and that shutdown waits for in-flight jobs.
"""

from __future__ import annotations

import threading
from concurrent.futures import Future
from unittest.mock import MagicMock, patch

from governor_core.sync.worker import Worker


def _mock_settings(**overrides):
    defaults = {
        "solution_concurrency_limit": 4,
    }
    defaults.update(overrides)
    mock = MagicMock()
    for k, v in defaults.items():
        setattr(mock, k, v)
    return mock


class TestWorkerParallelSolutions:
    """Tests for parallel solution job execution in the Worker."""

    @patch("governor_core.core.config.get_settings", return_value=_mock_settings())
    def test_worker_initialises_with_concurrency_settings(self, _mock_settings):
        """Worker should store concurrency limit from settings."""
        worker = Worker(MagicMock())
        assert worker._solution_max_workers == 4
        # Executor lazily created, not at init
        assert worker._solution_executor is None
        assert worker._solution_futures == set()

    @patch(
        "governor_core.core.config.get_settings",
        return_value=_mock_settings(solution_concurrency_limit=2),
    )
    def test_worker_respects_custom_concurrency_limit(self, _mock_settings):
        """Worker should respect SOLUTION_CONCURRENCY_LIMIT setting."""
        worker = Worker(MagicMock())
        assert worker._solution_max_workers == 2

    @patch("governor_core.core.config.get_settings", return_value=_mock_settings())
    def test_run_submits_solution_jobs_to_thread_pool(self, _mock_settings):
        """Worker.run() should submit claimed solution jobs to executor."""
        worker = Worker(MagicMock())

        # Track calls
        jobs_claimed = []
        jobs_processed = []

        # Create mock solution jobs
        mock_job_1 = MagicMock(id="job-1", opportunity_id="opp-1")
        mock_job_2 = MagicMock(id="job-2", opportunity_id="opp-2")

        # poll_and_claim_solution_task returns jobs then None
        claim_results = [mock_job_1, mock_job_2, None]
        claim_idx = [0]

        def mock_claim():
            idx = claim_idx[0]
            if idx < len(claim_results):
                claim_idx[0] += 1
                result = claim_results[idx]
                if result:
                    jobs_claimed.append(result)
                return result
            return None

        # No sync or detection tasks
        worker.poll_and_claim_task = MagicMock(return_value=None)
        worker.poll_and_claim_detection_task = MagicMock(return_value=None)
        worker.poll_and_claim_verification_task = MagicMock(return_value=None)
        worker.poll_and_claim_solution_task = mock_claim

        # Track process_solution calls
        worker.process_solution = lambda job: jobs_processed.append(job)

        # Stop after one full cycle (sync check + detection check + solution fill + idle)
        stop = threading.Event()
        call_count = [0]
        original_wait = stop.wait

        def stop_after_iterations(timeout):
            call_count[0] += 1
            if call_count[0] >= 2:
                stop.set()
            return original_wait(0.01)

        stop.wait = stop_after_iterations

        worker.run(stop)

        # Should have claimed and submitted both jobs
        assert len(jobs_claimed) == 2
        # Executor should have been created
        assert worker._solution_executor is not None
        # Jobs should have been processed (via the thread pool)
        # Since we mocked process_solution, the futures complete immediately
        assert worker._solution_executor._shutdown is True  # shutdown was called

    @patch("governor_core.core.config.get_settings", return_value=_mock_settings())
    def test_completed_futures_are_cleaned_up(self, _mock_settings):
        """Completed futures should be removed from tracking set."""
        worker = Worker(MagicMock())

        # Simulate completed futures
        done_future = Future()
        done_future.set_result(None)
        worker._solution_futures = {done_future}

        # Create executor so the cleanup code path runs
        from concurrent.futures import ThreadPoolExecutor

        worker._solution_executor = ThreadPoolExecutor(max_workers=1)

        # No tasks available
        worker.poll_and_claim_task = MagicMock(return_value=None)
        worker.poll_and_claim_detection_task = MagicMock(return_value=None)
        worker.poll_and_claim_verification_task = MagicMock(return_value=None)
        worker.poll_and_claim_solution_task = MagicMock(return_value=None)

        stop = threading.Event()
        call_count = [0]

        def stop_after_one(timeout):
            call_count[0] += 1
            if call_count[0] >= 1:
                stop.set()
            return stop.wait(0.01) if not stop.is_set() else True

        stop.wait = stop_after_one

        worker.run(stop)

        # Completed future should have been cleaned up
        assert done_future not in worker._solution_futures

    @patch("governor_core.core.config.get_settings", return_value=_mock_settings())
    def test_failed_future_is_logged_and_cleaned(self, _mock_settings):
        """Futures that raised should be logged and cleaned up."""
        worker = Worker(MagicMock())

        # Simulate a failed future
        failed_future = Future()
        failed_future.set_exception(RuntimeError("boom"))
        worker._solution_futures = {failed_future}

        from concurrent.futures import ThreadPoolExecutor

        worker._solution_executor = ThreadPoolExecutor(max_workers=1)

        worker.poll_and_claim_task = MagicMock(return_value=None)
        worker.poll_and_claim_detection_task = MagicMock(return_value=None)
        worker.poll_and_claim_verification_task = MagicMock(return_value=None)
        worker.poll_and_claim_solution_task = MagicMock(return_value=None)

        stop = threading.Event()
        call_count = [0]

        def stop_after_one(timeout):
            call_count[0] += 1
            if call_count[0] >= 1:
                stop.set()
            return stop.wait(0.01) if not stop.is_set() else True

        stop.wait = stop_after_one

        worker.run(stop)

        # Failed future should be cleaned up
        assert failed_future not in worker._solution_futures
