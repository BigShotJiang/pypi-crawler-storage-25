from __future__ import annotations

from decimal import Decimal
from types import SimpleNamespace

from governor_core.opportunities.run_results_heuristics import build_run_results_job_index

from governor_core.opportunities.rules.partition_pruning import PartitionPruningRule
from governor_core.opportunities.rules.shuffle_spill import ShuffleSpillRule


def _manifest_node(
    *,
    unique_id: str,
    model_name: str,
    relation_name: str,
    compiled_code: str,
    config: dict | None = None,
) -> dict:
    return {
        "metadata": {"project_name": "local_project"},
        "nodes": {
            unique_id: {
                "unique_id": unique_id,
                "name": model_name,
                "resource_type": "model",
                "package_name": "local_project",
                "relation_name": relation_name,
                "database": relation_name.split(".")[0],
                "schema": relation_name.split(".")[1],
                "alias": relation_name.split(".")[2],
                "compiled_code": compiled_code,
                "config": {"materialized": "table", **(config or {})},
            }
        },
    }


def _column_row(
    *,
    project_id: str,
    dataset_name: str,
    table_name: str,
    column_name: str,
    data_type: str,
):
    return SimpleNamespace(
        project_id=project_id,
        dataset_name=dataset_name,
        table_name=table_name,
        column_name=column_name,
        data_type=data_type,
    )


def _job(
    *,
    job_id: str,
    destination_table: str | None = None,
    referenced_tables: list[str] | None = None,
    query: str | None = None,
    total_cost: Decimal | None = None,
    total_bytes_processed: int | None = None,
    performance_insights: dict | None = None,
    total_slot_ms: int | None = None,
):
    return SimpleNamespace(
        job_id=job_id,
        destination_table=destination_table,
        referenced_tables=referenced_tables,
        query=query,
        total_cost=total_cost,
        total_bytes_processed=total_bytes_processed,
        performance_insights=performance_insights,
        total_slot_ms=total_slot_ms,
    )


def test_partition_rule_creates_run_results_partition_candidate():
    rule = PartitionPruningRule()
    manifest = _manifest_node(
        unique_id="model.local_project.fct_events",
        model_name="fct_events",
        relation_name="project.analytics.fct_events",
        compiled_code="SELECT event_date, user_id FROM raw.events",
    )
    thresholds = {
        **rule.default_thresholds,
        "_run_results": {
            "results": [
                {
                    "unique_id": "model.local_project.fct_events",
                    "status": "success",
                    "execution_time": 121.5,
                }
            ]
        },
        "_table_columns": [
            _column_row(
                project_id="project",
                dataset_name="analytics",
                table_name="fct_events",
                column_name="event_date",
                data_type="DATE",
            ),
            _column_row(
                project_id="project",
                dataset_name="analytics",
                table_name="fct_events",
                column_name="user_id",
                data_type="STRING",
            ),
        ],
    }
    jobs = [
        _job(
            job_id="job-1",
            referenced_tables=["project.analytics.fct_events"],
            query=(
                "SELECT * FROM project.analytics.fct_events "
                "WHERE event_date = '2026-04-01'"
            ),
            total_cost=Decimal("8.40"),
            total_bytes_processed=25 * 1024**3,
        )
    ]

    candidates = rule.detect(jobs, manifest, thresholds)

    assert len(candidates) == 1
    candidate = candidates[0]
    assert candidate.opportunity_type == "partition_pruning"
    assert candidate.evidence_snapshot["evidence_source"] == "run_results"
    assert candidate.evidence_snapshot["recommended_partition_column"] == "event_date"
    assert (
        candidate.evidence_snapshot["partition_heuristic_reason"] == "predicate_usage"
    )
    assert candidate.related_job_ids == ["job-1"]


def test_partition_rule_recommends_require_partition_filter_for_hot_partitioned_model():
    rule = PartitionPruningRule()
    manifest = _manifest_node(
        unique_id="model.local_project.fct_events",
        model_name="fct_events",
        relation_name="project.analytics.fct_events",
        compiled_code="SELECT event_date, user_id FROM raw.events",
        config={"partition_by": {"field": "event_date", "data_type": "date"}},
    )
    thresholds = {
        **rule.default_thresholds,
        "_run_results": {
            "results": [
                {
                    "unique_id": "model.local_project.fct_events",
                    "status": "success",
                    "execution_time": 92.0,
                }
            ]
        },
        "_table_columns": [
            _column_row(
                project_id="project",
                dataset_name="analytics",
                table_name="fct_events",
                column_name="event_date",
                data_type="DATE",
            )
        ],
    }

    candidates = rule.detect([], manifest, thresholds)

    assert len(candidates) == 1
    candidate = candidates[0]
    assert candidate.evidence_snapshot["recommended_require_partition_filter"] is True
    assert candidate.evidence_snapshot["current_partition_column"] == "event_date"
    assert candidate.evidence_snapshot["partition_already_configured"] is True


def test_partition_rule_can_infer_temporal_column_from_compiled_sql_without_table_metadata():
    rule = PartitionPruningRule()
    manifest = _manifest_node(
        unique_id="model.local_project.stg_bitcoin_outputs",
        model_name="stg_bitcoin_outputs",
        relation_name="project.analytics.stg_bitcoin_outputs",
        compiled_code=(
            "SELECT * FROM raw.outputs "
            "WHERE block_timestamp BETWEEN TIMESTAMP('2026-01-01') "
            "AND TIMESTAMP('2026-01-31')"
        ),
    )
    thresholds = {
        **rule.default_thresholds,
        "_run_results": {
            "results": [
                {
                    "unique_id": "model.local_project.stg_bitcoin_outputs",
                    "status": "error",
                    "execution_time": 314.37,
                    "compiled_code": (
                        "SELECT * FROM raw.outputs "
                        "WHERE block_timestamp BETWEEN TIMESTAMP('2026-01-01') "
                        "AND TIMESTAMP('2026-01-31')"
                    ),
                }
            ]
        },
        "_table_columns": [],
    }

    candidates = rule.detect([], manifest, thresholds)

    assert len(candidates) == 1
    candidate = candidates[0]
    assert (
        candidate.evidence_snapshot["recommended_partition_column"] == "block_timestamp"
    )
    assert candidate.evidence_snapshot["partition_data_type"] == "TIMESTAMP"
    assert (
        candidate.evidence_snapshot["partition_heuristic_reason"]
        == "sql_temporal_predicate"
    )


def test_partition_rule_merges_jobs_and_run_results_evidence():
    rule = PartitionPruningRule()
    manifest = _manifest_node(
        unique_id="model.local_project.fct_events",
        model_name="fct_events",
        relation_name="project.analytics.fct_events",
        compiled_code="SELECT event_date, user_id FROM raw.events",
    )
    thresholds = {
        **rule.default_thresholds,
        "_run_results": {
            "results": [
                {
                    "unique_id": "model.local_project.fct_events",
                    "status": "success",
                    "execution_time": 135.0,
                }
            ]
        },
        "_table_columns": [
            _column_row(
                project_id="project",
                dataset_name="analytics",
                table_name="fct_events",
                column_name="event_date",
                data_type="DATE",
            )
        ],
    }
    jobs = [
        _job(
            job_id="job-1",
            destination_table="project.analytics.fct_events",
            query="SELECT * FROM project.analytics.fct_events",
            total_cost=Decimal("12.00"),
            total_bytes_processed=30 * 1024**3,
            performance_insights={
                "stage_performance_standalone_insights": [
                    {"stage_id": 1, "partition_skew": {"skew_detected": True}}
                ]
            },
        )
    ]

    candidates = rule.detect(jobs, manifest, thresholds)

    assert len(candidates) == 1
    candidate = candidates[0]
    assert (
        candidate.evidence_snapshot["evidence_source"]
        == "jobs_insights_and_run_results"
    )
    assert candidate.evidence_snapshot["run_results_detection"] is True


def test_shuffle_rule_creates_run_results_cluster_candidate():
    rule = ShuffleSpillRule()
    manifest = _manifest_node(
        unique_id="model.local_project.fct_orders",
        model_name="fct_orders",
        relation_name="project.analytics.fct_orders",
        compiled_code=(
            "SELECT customer_id, order_date, SUM(amount) AS amount "
            "FROM raw.orders "
            "JOIN raw.customers USING (customer_id) "
            "GROUP BY customer_id, order_date"
        ),
    )
    thresholds = {
        **rule.default_thresholds,
        "_run_results": {
            "results": [
                {
                    "unique_id": "model.local_project.fct_orders",
                    "status": "success",
                    "execution_time": 88.0,
                }
            ]
        },
        "_table_columns": [
            _column_row(
                project_id="project",
                dataset_name="analytics",
                table_name="fct_orders",
                column_name="customer_id",
                data_type="STRING",
            ),
            _column_row(
                project_id="project",
                dataset_name="analytics",
                table_name="fct_orders",
                column_name="order_date",
                data_type="DATE",
            ),
        ],
    }
    jobs = [
        _job(
            job_id="job-2",
            destination_table="project.analytics.fct_orders",
            total_cost=Decimal("14.50"),
            total_bytes_processed=40 * 1024**3,
            query="SELECT customer_id FROM project.analytics.fct_orders",
        )
    ]

    candidates = rule.detect(jobs, manifest, thresholds)

    assert len(candidates) == 1
    candidate = candidates[0]
    assert candidate.opportunity_type == "shuffle_spill"
    assert candidate.evidence_snapshot["evidence_source"] == "run_results"
    assert candidate.evidence_snapshot["recommended_cluster_columns"] == [
        "customer_id",
        "order_date",
    ]


# ---------------------------------------------------------------------------
# build_run_results_job_index tests
# ---------------------------------------------------------------------------


def _fake_bq_job(job_id: str, total_cost: float = 0.05) -> SimpleNamespace:
    return SimpleNamespace(job_id=job_id, total_cost=Decimal(str(total_cost)))


def _run_result_entry(
    unique_id: str, job_id: str, compiled_code: str = ""
) -> dict:
    return {
        "unique_id": unique_id,
        "status": "success",
        "execution_time": 60.0,
        "compiled_code": compiled_code,
        "adapter_response": {"job_id": job_id},
    }


class TestBuildRunResultsJobIndex:
    def test_happy_path_maps_model_to_job(self):
        rr = {
            "results": [
                _run_result_entry("model.proj.stg_orders", "job-111"),
                _run_result_entry("model.proj.int_pairs", "job-222"),
            ]
        }
        jobs = [_fake_bq_job("job-111", 1.50), _fake_bq_job("job-222", 0.33)]
        index = build_run_results_job_index(rr, jobs)

        assert "stg_orders" in index
        assert "int_pairs" in index
        result_entry, bq_job = index["stg_orders"]
        assert bq_job.job_id == "job-111"
        assert bq_job.total_cost == Decimal("1.50")
        assert result_entry["adapter_response"]["job_id"] == "job-111"

    def test_missing_job_id_in_adapter_response_skips_entry(self):
        rr = {
            "results": [
                {
                    "unique_id": "model.proj.stg_missing",
                    "status": "success",
                    "adapter_response": {},
                },
                _run_result_entry("model.proj.stg_ok", "job-333"),
            ]
        }
        jobs = [_fake_bq_job("job-333")]
        index = build_run_results_job_index(rr, jobs)

        assert "stg_missing" not in index
        assert "stg_ok" in index

    def test_unmatched_job_id_skips_entry(self):
        rr = {
            "results": [
                _run_result_entry("model.proj.stg_orphan", "job-does-not-exist"),
                _run_result_entry("model.proj.stg_ok", "job-444"),
            ]
        }
        jobs = [_fake_bq_job("job-444")]
        index = build_run_results_job_index(rr, jobs)

        assert "stg_orphan" not in index
        assert "stg_ok" in index

    def test_empty_run_results_returns_empty(self):
        assert build_run_results_job_index(None, []) == {}
        assert build_run_results_job_index({}, []) == {}
        assert build_run_results_job_index({"results": []}, [_fake_bq_job("j")]) == {}

    def test_empty_synced_jobs_returns_empty(self):
        rr = {"results": [_run_result_entry("model.proj.stg_x", "job-1")]}
        assert build_run_results_job_index(rr, []) == {}

    def test_duplicate_model_name_keeps_first(self):
        rr = {
            "results": [
                _run_result_entry("model.proj.stg_dup", "job-first"),
                _run_result_entry("model.other.stg_dup", "job-second"),
            ]
        }
        jobs = [_fake_bq_job("job-first"), _fake_bq_job("job-second")]
        index = build_run_results_job_index(rr, jobs)

        assert len(index) == 1
        _, bq_job = index["stg_dup"]
        assert bq_job.job_id == "job-first"
