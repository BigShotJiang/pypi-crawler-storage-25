"""Unit tests for SQL AST structural comparison validator."""

import pytest

from governor_core.solutions.validation.ast_validator import (
    ParseError,
    StructuralComparison,
    compare_sql,
)


class TestIdenticalSQL:
    """Identical SQL should produce an empty comparison."""

    def test_identical_simple_select(self):
        sql = "SELECT id, name FROM users"
        result = compare_sql(sql, sql)
        assert result.columns_added == []
        assert result.columns_removed == []
        assert result.columns_modified == []
        assert result.ctes_added == []
        assert result.ctes_removed == []
        assert result.joins_added == []
        assert result.joins_removed == []
        assert result.where_changed is False
        assert result.group_by_changed is False
        assert result.order_by_changed is False
        assert result.config_changes == []

    def test_identical_complex_query(self):
        sql = """\
WITH base AS (
    SELECT id, name, total FROM orders WHERE status = 'active'
)
SELECT id, name, SUM(total) AS total_sum
FROM base
JOIN users ON base.id = users.id
WHERE name IS NOT NULL
GROUP BY id, name
ORDER BY total_sum DESC
"""
        result = compare_sql(sql, sql)
        assert result == StructuralComparison()


class TestColumnsAdded:
    """Adding columns to SELECT should populate columns_added."""

    def test_add_single_column(self):
        before = "SELECT id FROM users"
        after = "SELECT id, name FROM users"
        result = compare_sql(before, after)
        assert "name" in result.columns_added
        assert result.columns_removed == []

    def test_add_aliased_column(self):
        before = "SELECT id FROM users"
        after = "SELECT id, email AS user_email FROM users"
        result = compare_sql(before, after)
        assert "user_email" in result.columns_added

    def test_add_multiple_columns(self):
        before = "SELECT id FROM users"
        after = "SELECT id, name, email FROM users"
        result = compare_sql(before, after)
        assert sorted(result.columns_added) == ["email", "name"]


class TestColumnsRemoved:
    """Removing columns from SELECT should populate columns_removed."""

    def test_remove_single_column(self):
        before = "SELECT id, name FROM users"
        after = "SELECT id FROM users"
        result = compare_sql(before, after)
        assert "name" in result.columns_removed
        assert result.columns_added == []

    def test_remove_aliased_column(self):
        before = "SELECT id, email AS user_email FROM users"
        after = "SELECT id FROM users"
        result = compare_sql(before, after)
        assert "user_email" in result.columns_removed


class TestColumnsModified:
    """Changing a column's expression but keeping its alias should detect modification."""

    def test_modify_column_expression(self):
        before = "SELECT UPPER(name) AS display_name FROM users"
        after = "SELECT LOWER(name) AS display_name FROM users"
        result = compare_sql(before, after)
        assert "display_name" in result.columns_modified
        assert result.columns_added == []
        assert result.columns_removed == []


class TestCTEsAdded:
    """Adding a CTE should populate ctes_added."""

    def test_add_cte(self):
        before = "SELECT id FROM users"
        after = """\
WITH active_users AS (
    SELECT id FROM users WHERE active = true
)
SELECT id FROM active_users
"""
        result = compare_sql(before, after)
        assert "active_users" in result.ctes_added

    def test_add_second_cte(self):
        before = """\
WITH base AS (SELECT id FROM users)
SELECT id FROM base
"""
        after = """\
WITH base AS (SELECT id FROM users),
extra AS (SELECT id FROM orders)
SELECT id FROM base
"""
        result = compare_sql(before, after)
        assert "extra" in result.ctes_added
        assert result.ctes_removed == []


class TestCTEsRemoved:
    """Removing a CTE should populate ctes_removed."""

    def test_remove_cte(self):
        before = """\
WITH active_users AS (
    SELECT id FROM users WHERE active = true
)
SELECT id FROM active_users
"""
        after = "SELECT id FROM users"
        result = compare_sql(before, after)
        assert "active_users" in result.ctes_removed


class TestJoinsAdded:
    """Adding a JOIN should populate joins_added."""

    def test_add_join(self):
        before = "SELECT id FROM users"
        after = "SELECT id FROM users JOIN orders ON users.id = orders.user_id"
        result = compare_sql(before, after)
        assert len(result.joins_added) == 1
        assert "orders" in result.joins_added[0]

    def test_add_aliased_join(self):
        before = "SELECT id FROM users"
        after = "SELECT id FROM users JOIN orders AS o ON users.id = o.user_id"
        result = compare_sql(before, after)
        assert len(result.joins_added) == 1
        assert "orders" in result.joins_added[0]
        assert "o" in result.joins_added[0]


class TestJoinsRemoved:
    """Removing a JOIN should populate joins_removed."""

    def test_remove_join(self):
        before = "SELECT id FROM users JOIN orders ON users.id = orders.user_id"
        after = "SELECT id FROM users"
        result = compare_sql(before, after)
        assert len(result.joins_removed) == 1
        assert "orders" in result.joins_removed[0]


class TestWhereChanged:
    """Changes to WHERE clause should set where_changed=True."""

    def test_modify_where(self):
        before = "SELECT id FROM users WHERE active = true"
        after = "SELECT id FROM users WHERE active = false"
        result = compare_sql(before, after)
        assert result.where_changed is True

    def test_add_where(self):
        before = "SELECT id FROM users"
        after = "SELECT id FROM users WHERE active = true"
        result = compare_sql(before, after)
        assert result.where_changed is True

    def test_remove_where(self):
        before = "SELECT id FROM users WHERE active = true"
        after = "SELECT id FROM users"
        result = compare_sql(before, after)
        assert result.where_changed is True

    def test_same_where_unchanged(self):
        before = "SELECT id FROM users WHERE active = true"
        after = "SELECT id FROM users WHERE active = true"
        result = compare_sql(before, after)
        assert result.where_changed is False


class TestGroupByChanged:
    """Changes to GROUP BY should set group_by_changed=True."""

    def test_modify_group_by(self):
        before = "SELECT department, COUNT(*) AS cnt FROM users GROUP BY department"
        after = "SELECT department, role, COUNT(*) AS cnt FROM users GROUP BY department, role"
        result = compare_sql(before, after)
        assert result.group_by_changed is True

    def test_add_group_by(self):
        before = "SELECT department FROM users"
        after = "SELECT department, COUNT(*) AS cnt FROM users GROUP BY department"
        result = compare_sql(before, after)
        assert result.group_by_changed is True


class TestOrderByChanged:
    """Changes to ORDER BY should set order_by_changed=True."""

    def test_modify_order_by(self):
        before = "SELECT id FROM users ORDER BY id ASC"
        after = "SELECT id FROM users ORDER BY id DESC"
        result = compare_sql(before, after)
        assert result.order_by_changed is True

    def test_add_order_by(self):
        before = "SELECT id FROM users"
        after = "SELECT id FROM users ORDER BY id"
        result = compare_sql(before, after)
        assert result.order_by_changed is True


class TestConfigOnlyChanges:
    """When SQL body is identical but Jinja config differs, config_changes is populated."""

    def test_config_block_added(self):
        before = "SELECT id FROM users"
        after = '{{ config(materialized="table") }}\nSELECT id FROM users'
        result = compare_sql(before, after)
        # SQL bodies are the same after stripping, but raw inputs differ
        assert "config_only_change" in result.config_changes
        # No structural SQL changes
        assert result.columns_added == []
        assert result.where_changed is False

    def test_config_block_changed(self):
        before = '{{ config(materialized="view") }}\nSELECT id FROM users'
        after = '{{ config(materialized="table") }}\nSELECT id FROM users'
        result = compare_sql(before, after)
        assert "config_only_change" in result.config_changes

    def test_jinja_config_block_changed_detected(self):
        """When expressions_replaced count changes, jinja_config_block_changed is set."""
        before = "SELECT id FROM users"
        after = '{{ config(materialized="table") }}\nSELECT id FROM users'
        result = compare_sql(before, after)
        # before has 0 expressions replaced, after has 1
        assert "jinja_config_block_changed" in result.config_changes


class TestBigQuerySyntax:
    """BigQuery-specific syntax should parse correctly."""

    def test_backtick_table_name(self):
        before = "SELECT id FROM `project.dataset.table`"
        after = "SELECT id, name FROM `project.dataset.table`"
        result = compare_sql(before, after)
        assert "name" in result.columns_added

    def test_struct_column(self):
        before = "SELECT id FROM users"
        after = "SELECT id, STRUCT(name, email) AS user_info FROM users"
        result = compare_sql(before, after)
        assert "user_info" in result.columns_added

    def test_array_agg_function(self):
        before = "SELECT id FROM users"
        after = "SELECT id, ARRAY_AGG(score) AS scores FROM users GROUP BY id"
        result = compare_sql(before, after)
        assert "scores" in result.columns_added
        assert result.group_by_changed is True


class TestParseError:
    """Invalid SQL should raise ParseError."""

    def test_invalid_sql_before(self):
        with pytest.raises(ParseError):
            compare_sql("NOT VALID SQL AT ALL ??? {{{{", "SELECT 1")

    def test_invalid_sql_after(self):
        with pytest.raises(ParseError):
            compare_sql("SELECT 1", "NOT VALID SQL AT ALL ??? {{{{")

    def test_completely_broken_sql(self):
        with pytest.raises(ParseError):
            compare_sql(")))((( GARBAGE", "SELECT 1")


class TestComplexJinja:
    """Complex Jinja2 with control flow that can't be cleanly stripped raises ParseError."""

    def test_if_block_prevents_parsing(self):
        sql_with_control_flow = """\
SELECT
    {% if target.name == 'prod' %}
    production_col
    {% else %}
    dev_col
    {% endif %}
FROM table
"""
        with pytest.raises(ParseError, match="Complex Jinja2"):
            compare_sql(sql_with_control_flow, "SELECT id FROM table")

    def test_for_loop_prevents_parsing(self):
        sql_with_loop = """\
SELECT
    {% for col in columns %}
    {{ col }},
    {% endfor %}
    id
FROM table
"""
        with pytest.raises(ParseError, match="Complex Jinja2"):
            compare_sql(sql_with_loop, "SELECT id FROM table")


class TestMultipleChanges:
    """Multiple structural changes detected simultaneously."""

    def test_added_column_and_cte(self):
        before = "SELECT id FROM users"
        after = """\
WITH filtered AS (SELECT id, name FROM users WHERE active = true)
SELECT id, name FROM filtered
"""
        result = compare_sql(before, after)
        assert "name" in result.columns_added
        assert "filtered" in result.ctes_added

    def test_added_column_join_and_where(self):
        before = "SELECT id FROM users"
        after = """\
SELECT id, o.total
FROM users
JOIN orders AS o ON users.id = o.user_id
WHERE o.total > 100
"""
        result = compare_sql(before, after)
        assert len(result.columns_added) > 0
        assert len(result.joins_added) > 0
        assert result.where_changed is True

    def test_remove_column_and_add_cte(self):
        before = "SELECT id, name, email FROM users"
        after = """\
WITH base AS (SELECT id, name FROM users)
SELECT id, name FROM base
"""
        result = compare_sql(before, after)
        assert "email" in result.columns_removed
        assert "base" in result.ctes_added


class TestJoinConditionChanged:
    """Changing a JOIN condition should detect the modification."""

    def test_change_join_table(self):
        before = "SELECT id FROM users JOIN orders ON users.id = orders.user_id"
        after = "SELECT id FROM users JOIN payments ON users.id = payments.user_id"
        result = compare_sql(before, after)
        # The old join table is removed and a new one is added
        assert len(result.joins_removed) > 0
        assert len(result.joins_added) > 0
        # Verify table names
        assert any("orders" in j for j in result.joins_removed)
        assert any("payments" in j for j in result.joins_added)


class TestEmptySQL:
    """Edge case: empty SQL strings."""

    def test_both_empty(self):
        result = compare_sql("", "")
        assert result == StructuralComparison()

    def test_empty_before_valid_after(self):
        # Empty string after stripping might not parse as valid SQL
        # but since both are empty or one is, the behavior depends on
        # whether sqlglot can parse empty strings
        with pytest.raises(ParseError):
            compare_sql("", "SELECT 1")


class TestJinjaRefStripping:
    """SQL with Jinja ref() calls that get stripped before comparison."""

    def test_ref_calls_stripped_identical_sql(self):
        before = "SELECT id FROM {{ ref('orders') }}"
        after = "SELECT id FROM {{ ref('orders') }}"
        result = compare_sql(before, after)
        assert result.columns_added == []
        assert result.columns_removed == []

    def test_ref_calls_with_column_change(self):
        before = "SELECT id FROM {{ ref('orders') }}"
        after = "SELECT id, total FROM {{ ref('orders') }}"
        result = compare_sql(before, after)
        assert "total" in result.columns_added

    def test_different_ref_model_detected(self):
        before = "SELECT id FROM {{ ref('orders') }}"
        after = "SELECT id FROM {{ ref('customers') }}"
        result = compare_sql(before, after)
        # The ref calls resolve to different table names, so comparison
        # should detect the difference (orders vs customers table change)
        # Though column names are the same, the FROM clause differs structurally.
        # The validator doesn't track FROM table changes explicitly,
        # but the SQL is different so it won't short-circuit.
        # columns are the same though
        assert result.columns_added == []
        assert result.columns_removed == []

    def test_source_calls_stripped(self):
        before = "SELECT id FROM {{ source('raw', 'orders') }}"
        after = "SELECT id, name FROM {{ source('raw', 'orders') }}"
        result = compare_sql(before, after)
        assert "name" in result.columns_added


class TestStructuralComparisonDefaults:
    """Verify StructuralComparison dataclass defaults."""

    def test_default_values(self):
        sc = StructuralComparison()
        assert sc.columns_added == []
        assert sc.columns_removed == []
        assert sc.columns_modified == []
        assert sc.ctes_added == []
        assert sc.ctes_removed == []
        assert sc.joins_added == []
        assert sc.joins_removed == []
        assert sc.where_changed is False
        assert sc.group_by_changed is False
        assert sc.order_by_changed is False
        assert sc.config_changes == []


class TestWhitespaceAndFormatting:
    """Whitespace and formatting differences should not affect comparison."""

    def test_different_whitespace_same_query(self):
        before = "SELECT   id,   name   FROM   users"
        after = "SELECT id, name FROM users"
        result = compare_sql(before, after)
        assert result.columns_added == []
        assert result.columns_removed == []
        assert result.where_changed is False

    def test_multiline_vs_single_line(self):
        before = "SELECT id, name FROM users WHERE active = true"
        after = """\
SELECT
    id,
    name
FROM users
WHERE active = true
"""
        result = compare_sql(before, after)
        assert result.columns_added == []
        assert result.columns_removed == []
        assert result.where_changed is False


class TestStarSelect:
    """SELECT * handling."""

    def test_star_to_explicit_columns(self):
        before = "SELECT * FROM users"
        after = "SELECT id, name FROM users"
        result = compare_sql(before, after)
        assert "*" in result.columns_removed
        assert "id" in result.columns_added
        assert "name" in result.columns_added


class TestDialectParameter:
    """Verify the dialect parameter is used."""

    def test_bigquery_is_default(self):
        # BigQuery backtick syntax should work by default
        sql = "SELECT id FROM `project.dataset.table`"
        result = compare_sql(sql, sql)
        assert result == StructuralComparison()
