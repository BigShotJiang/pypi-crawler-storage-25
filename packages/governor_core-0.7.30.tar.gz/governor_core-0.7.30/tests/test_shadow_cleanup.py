"""Unit tests for shadow artifact cleanup."""

from __future__ import annotations

import uuid

from governor_core.shadow.cleanup import cleanup_run
from governor_core.shadow.naming import mint_shadow_name


class _FakeBq:
    def __init__(self, existing_tables: list[str], fail_on: set[str] | None = None):
        self._tables = list(existing_tables)
        self._fail_on = fail_on or set()
        self.dropped: list[str] = []

    def list_tables(self, dataset):  # noqa: ARG002
        return list(self._tables)

    def drop_table(self, dataset, name):  # noqa: ARG002
        if name in self._fail_on:
            raise RuntimeError(f"simulated drop failure: {name}")
        self._tables.remove(name)
        self.dropped.append(name)


def test_cleanup_drops_only_this_solutions_artifacts():
    sid = str(uuid.uuid4())
    other_sid = str(uuid.uuid4())
    tables = [
        mint_shadow_name("fct_orders", sid),
        mint_shadow_name("daily_revenue", sid),
        mint_shadow_name("fct_invoices", other_sid),  # different solution
        "fct_orders",  # non-shadow
        "production_table",  # non-shadow
    ]
    bq = _FakeBq(tables)
    result = cleanup_run(solution_id=sid, dataset="d", bq=bq)
    assert len(result.deleted) == 2
    assert len(result.failed) == 0
    # Non-shadow tables and other solution's artifact must remain
    assert mint_shadow_name("fct_invoices", other_sid) in bq._tables
    assert "fct_orders" in bq._tables
    assert "production_table" in bq._tables


def test_cleanup_records_failures_without_raising():
    sid = str(uuid.uuid4())
    name_a = mint_shadow_name("a", sid)
    name_b = mint_shadow_name("b", sid)
    bq = _FakeBq([name_a, name_b], fail_on={name_b})
    result = cleanup_run(solution_id=sid, dataset="d", bq=bq)
    assert result.deleted == [name_a]
    assert result.failed == [(name_b, "simulated drop failure: " + name_b)]


def test_cleanup_empty_dataset_is_noop():
    sid = str(uuid.uuid4())
    bq = _FakeBq([])
    result = cleanup_run(solution_id=sid, dataset="d", bq=bq)
    assert result.deleted == []
    assert result.failed == []
