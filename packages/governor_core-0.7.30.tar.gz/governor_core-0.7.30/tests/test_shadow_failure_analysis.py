"""Tests for shadow/failure_analysis.identify_failing_downstreams (spec 128, T005-T006)."""

from __future__ import annotations

import uuid

import pytest

from governor_core.shadow.failure_analysis import identify_failing_downstreams
from governor_core.shadow.models import ShadowModelExecution
from tests.fixtures.factories import ShadowValidationRunFactory


@pytest.fixture
def shadow_run(db):
    run = ShadowValidationRunFactory.create(status="shadow_failed")
    db.flush()
    return run


def _add_execution(db, run_id, model_name, phase="shadow", error_type=None, error_message=None):
    ex = ShadowModelExecution(
        id=str(uuid.uuid4()),
        shadow_run_id=run_id,
        phase=phase,
        model_name=model_name,
        materialized_table_name=f"proj.ds.{model_name}",
        error_type=error_type,
        error_message=error_message,
    )
    db.add(ex)
    db.flush()


MANIFEST = {
    "metadata": {"project_name": "my_project"},
    "nodes": {
        "model.my_project.events_summary": {
            "package_name": "my_project",
            "original_file_path": "models/marts/events_summary.sql",
            "compiled_code": "select count(*) from events",
        },
        "model.my_project.events_daily": {
            "package_name": "my_project",
            "original_file_path": "models/marts/events_daily.sql",
        },
        "model.dbt_utils.pivot_helper": {
            "package_name": "dbt_utils",
            "original_file_path": "macros/pivot_helper.sql",
        },
    },
}


class TestIdentifyFailingDownstreams:
    def test_in_project_failure_classified(self, db, shadow_run):
        _add_execution(db, shadow_run.id, "events_summary", error_type="compile_error", error_message="missing partition filter")
        _add_execution(db, shadow_run.id, "events_daily")  # succeeded, no error_type

        failures = identify_failing_downstreams(db, shadow_run.id, MANIFEST)
        assert len(failures) == 1
        f = failures[0]
        assert f.model_name == "events_summary"
        assert f.is_in_project is True
        assert f.original_file_path == "models/marts/events_summary.sql"
        assert f.compiled_sql == "select count(*) from events"

    def test_vendor_package_failure_classified_external(self, db, shadow_run):
        _add_execution(db, shadow_run.id, "pivot_helper", error_type="compile_error")

        failures = identify_failing_downstreams(db, shadow_run.id, MANIFEST)
        assert len(failures) == 1
        assert failures[0].is_in_project is False
        assert failures[0].package_name == "dbt_utils"

    def test_unknown_model_returns_external_with_blank_file_path(self, db, shadow_run):
        _add_execution(db, shadow_run.id, "ghost_model", error_type="compile_error")

        failures = identify_failing_downstreams(db, shadow_run.id, MANIFEST)
        assert len(failures) == 1
        assert failures[0].is_in_project is False
        assert failures[0].original_file_path == ""

    def test_no_failures_returns_empty(self, db, shadow_run):
        _add_execution(db, shadow_run.id, "events_summary")  # no error_type

        assert identify_failing_downstreams(db, shadow_run.id, MANIFEST) == []

    def test_baseline_phase_failures_ignored(self, db, shadow_run):
        _add_execution(db, shadow_run.id, "events_summary", phase="baseline", error_type="compile_error")

        assert identify_failing_downstreams(db, shadow_run.id, MANIFEST) == []
