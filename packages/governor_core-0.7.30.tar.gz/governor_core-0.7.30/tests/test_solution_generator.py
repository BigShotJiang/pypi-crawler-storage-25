"""Unit tests for the solution generator orchestrator."""

from __future__ import annotations

from unittest.mock import MagicMock

import pytest

from governor_core.llm.schemas import (
    FileChange,
    LLMMetadata,
    SettingRecommendation,
    SolutionResponse,
)
from governor_core.solutions.exceptions import (
    GitHubRetrievalError,
    LLMResponseValidationError,
)
from governor_core.llm.schemas import VerificationResult
from governor_core.solutions.generator import (
    SolutionGenerator,
    _extract_relevant_files,
    _infer_change_type,
    _infer_resolution_category,
    _validate_response,
)
from governor_core.solutions.policy import build_effective_solution_policy


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _mock_opportunity(**overrides):
    """Create a mock Opportunity object."""
    opp = MagicMock()
    opp.opportunity_type = "shuffle_spill"
    opp.affected_table = "project.dataset.table1"
    opp.severity_score = 75
    opp.evidence_snapshot = {"spill_bytes": 1_000_000}
    opp.explanation = "High shuffle spill detected"
    opp.dbt_model_name = "stg_orders"
    for k, v in overrides.items():
        setattr(opp, k, v)
    return opp


def _mock_config(**overrides):
    """Create a mock ManifestConfiguration object."""
    config = MagicMock()
    config.github_repo = "owner/repo"
    for k, v in overrides.items():
        setattr(config, k, v)
    return config


def _mock_manifest_version(**overrides):
    """Create a mock ManifestVersion object."""
    mv = MagicMock()
    mv.commit_sha = "abc123"
    mv.content = None
    for k, v in overrides.items():
        setattr(mv, k, v)
    return mv


# Source file content that contains the before_content snippet.
# Uses explicit column list so that the after_content (which adds a column)
# is classified as additive rather than destructive by AST validation.
_SOURCE_FILE = (
    "-- stg_orders model\nSELECT id, status FROM raw.orders\n-- end of file\n"
)


def _dbt_response() -> SolutionResponse:
    return SolutionResponse(
        resolution_category="dbt_project_change",
        explanation="Add clustering key column to avoid shuffle spill",
        risk_level="low",
        risk_justification="Simple column addition for clustering",
        file_changes=[
            FileChange(
                file_path="models/stg_orders.sql",
                change_type="sql_change",
                before_content="SELECT id, status FROM raw.orders",
                after_content="SELECT id, status, created_at FROM raw.orders",
            )
        ],
    )


def _bq_response() -> SolutionResponse:
    return SolutionResponse(
        resolution_category="bigquery_infrastructure",
        explanation="Increase slot reservation",
        risk_level="medium",
        risk_justification="Requires capacity planning",
        setting_recommendation=SettingRecommendation(
            current_value="100",
            recommended_value="200",
            affected_resource="project.reservation",
        ),
    )


def _llm_metadata() -> LLMMetadata:
    return LLMMetadata(
        provider="gemini",
        model="gemini-3-pro-preview",
        prompt_tokens=100,
        completion_tokens=200,
        total_tokens=300,
        latency_ms=1500,
    )


# ---------------------------------------------------------------------------
# SolutionGenerator.generate tests
# ---------------------------------------------------------------------------


class TestSolutionGeneratorDBTChange:
    """Test full generation workflow for dbt project changes."""

    def test_generate_dbt_project_change(self):
        """Full workflow: before_content is the real GitHub file."""
        mock_llm = MagicMock()
        mock_llm.generate.return_value = (_dbt_response(), _llm_metadata())

        mock_github = MagicMock()
        mock_github.get_file_content.return_value = _SOURCE_FILE

        generator = SolutionGenerator(llm_provider=mock_llm, github_client=mock_github)

        opp = _mock_opportunity()
        config = _mock_config()
        mv = _mock_manifest_version(
            content={
                "nodes": {
                    "model.proj.stg_orders": {
                        "name": "stg_orders",
                        "original_file_path": "models/stg_orders.sql",
                        "resource_type": "model",
                    }
                }
            }
        )

        result = generator.generate(opp, config, mv)

        assert result.resolution_category == "dbt_project_change"
        assert len(result.solutions) == 1
        assert result.solutions[0].file_path == "models/stg_orders.sql"
        # before_content = real GitHub file, NOT from LLM
        assert result.solutions[0].before_content == _SOURCE_FILE
        assert (
            result.solutions[0].after_content
            == "SELECT id, status, created_at FROM raw.orders"
        )
        assert result.solutions[0].repository == "owner/repo"
        assert result.metadata.provider == "gemini"


class TestSolutionGeneratorBQInfrastructure:
    """Test full generation workflow for BigQuery infrastructure changes."""

    def test_generate_bq_infrastructure_no_github(self):
        """BigQuery infrastructure change doesn't call GitHub."""
        mock_llm = MagicMock()
        mock_llm.generate.return_value = (_bq_response(), _llm_metadata())

        generator = SolutionGenerator(llm_provider=mock_llm, github_client=None)

        opp = _mock_opportunity(dbt_model_name=None)
        config = _mock_config(github_repo=None)

        result = generator.generate(opp, config)

        assert result.resolution_category == "bigquery_infrastructure"
        assert len(result.solutions) == 1
        assert result.solutions[0].current_setting_value == "100"
        assert result.solutions[0].recommended_setting_value == "200"
        assert result.solutions[0].affected_resource == "project.reservation"


class TestSolutionGeneratorErrors:
    """Test error handling in SolutionGenerator."""

    def test_github_retrieval_failure(self):
        """GitHub retrieval failure raises GitHubRetrievalError."""
        mock_llm = MagicMock()

        mock_github = MagicMock()
        mock_github.get_file_content.side_effect = RuntimeError("Network error")

        generator = SolutionGenerator(llm_provider=mock_llm, github_client=mock_github)

        opp = _mock_opportunity()
        config = _mock_config()
        mv = _mock_manifest_version(
            content={
                "nodes": {
                    "model.proj.stg_orders": {
                        "name": "stg_orders",
                        "original_file_path": "models/stg_orders.sql",
                        "resource_type": "model",
                    }
                }
            }
        )

        with pytest.raises(GitHubRetrievalError):
            generator.generate(opp, config, mv)


# ---------------------------------------------------------------------------
# Source fidelity tests
# ---------------------------------------------------------------------------


class TestSourceFidelity:
    """Test that before_content comes from GitHub, not LLM."""

    def test_unknown_file_path_skipped_when_not_in_repo(self):
        """LLM file_path not in source_files AND not in repo is skipped."""
        from governor_core.github.client import GitHubFileNotFoundError as GHNotFound

        mock_llm = MagicMock()
        response = SolutionResponse(
            resolution_category="dbt_project_change",
            explanation="Fix query",
            risk_level="low",
            risk_justification="Simple fix",
            file_changes=[
                FileChange(
                    file_path="models/unknown_model.sql",
                    change_type="sql_change",
                    after_content="SELECT 2",
                )
            ],
        )
        mock_llm.generate.return_value = (response, _llm_metadata())

        mock_github = MagicMock()

        def _get_file(repo, path, ref=None):
            if "unknown_model" in path:
                raise GHNotFound(f"File not found: {path}")
            return _SOURCE_FILE

        mock_github.get_file_content.side_effect = _get_file

        generator = SolutionGenerator(llm_provider=mock_llm, github_client=mock_github)

        opp = _mock_opportunity()
        config = _mock_config()
        mv = _mock_manifest_version(
            content={
                "nodes": {
                    "model.proj.stg_orders": {
                        "name": "stg_orders",
                        "original_file_path": "models/stg_orders.sql",
                        "resource_type": "model",
                    }
                }
            }
        )

        result = generator.generate(opp, config, mv)

        assert len(result.solutions) == 0

    def test_unknown_file_path_fetched_on_demand(self):
        """LLM file_path not in initial source_files is fetched on demand from GitHub."""
        mock_llm = MagicMock()
        response = SolutionResponse(
            resolution_category="dbt_project_change",
            explanation="Fix query",
            risk_level="low",
            risk_justification="Simple fix",
            file_changes=[
                FileChange(
                    file_path="models/other_model.sql",
                    change_type="sql_change",
                    after_content="SELECT 2",
                )
            ],
        )
        mock_llm.generate.return_value = (response, _llm_metadata())
        mock_llm.verify.return_value = VerificationResult(safe=True, issues=[])

        mock_github = MagicMock()
        mock_github.get_file_content.return_value = _SOURCE_FILE

        generator = SolutionGenerator(llm_provider=mock_llm, github_client=mock_github)

        opp = _mock_opportunity()
        config = _mock_config()
        mv = _mock_manifest_version(
            content={
                "nodes": {
                    "model.proj.stg_orders": {
                        "name": "stg_orders",
                        "original_file_path": "models/stg_orders.sql",
                        "resource_type": "model",
                    }
                }
            }
        )

        result = generator.generate(opp, config, mv)

        # On-demand fetch should succeed and produce a solution
        assert len(result.solutions) >= 1

    def test_no_op_skipped(self):
        """LLM after_content identical to real file is skipped."""
        mock_llm = MagicMock()
        response = SolutionResponse(
            resolution_category="dbt_project_change",
            explanation="No change needed",
            risk_level="low",
            risk_justification="No risk",
            file_changes=[
                FileChange(
                    file_path="models/stg_orders.sql",
                    change_type="sql_change",
                    # after_content == the real GitHub file = no-op
                    after_content=_SOURCE_FILE,
                )
            ],
        )
        mock_llm.generate.return_value = (response, _llm_metadata())

        mock_github = MagicMock()
        mock_github.get_file_content.return_value = _SOURCE_FILE

        generator = SolutionGenerator(llm_provider=mock_llm, github_client=mock_github)

        opp = _mock_opportunity()
        config = _mock_config()
        mv = _mock_manifest_version(
            content={
                "nodes": {
                    "model.proj.stg_orders": {
                        "name": "stg_orders",
                        "original_file_path": "models/stg_orders.sql",
                        "resource_type": "model",
                    }
                }
            }
        )

        result = generator.generate(opp, config, mv)

        assert len(result.solutions) == 0


# ---------------------------------------------------------------------------
# _validate_response tests
# ---------------------------------------------------------------------------


class TestValidateResponse:
    """Test response validation logic."""

    def test_valid_dbt_response_passes(self):
        """Valid dbt project change response passes validation."""
        _validate_response(_dbt_response())

    def test_valid_dbt_response_without_before_content_passes(self):
        """dbt response with optional before_content passes validation."""
        response = SolutionResponse(
            resolution_category="dbt_project_change",
            explanation="Fix query",
            risk_level="low",
            risk_justification="Simple fix",
            file_changes=[
                FileChange(
                    file_path="models/stg_orders.sql",
                    change_type="sql_change",
                    after_content="SELECT id FROM raw.orders",
                )
            ],
        )
        _validate_response(response)

    def test_valid_bq_response_passes(self):
        """Valid BigQuery infrastructure response passes validation."""
        _validate_response(_bq_response())

    def test_dbt_missing_file_changes_raises(self):
        """dbt_project_change without file_changes raises error."""
        response = SolutionResponse(
            resolution_category="dbt_project_change",
            explanation="test",
            risk_level="low",
            risk_justification="test",
            file_changes=None,
        )
        with pytest.raises(LLMResponseValidationError, match="file_changes"):
            _validate_response(response)

    def test_dbt_empty_file_changes_raises(self):
        """dbt_project_change with empty file_changes raises error."""
        response = SolutionResponse(
            resolution_category="dbt_project_change",
            explanation="test",
            risk_level="low",
            risk_justification="test",
            file_changes=[],
        )
        with pytest.raises(LLMResponseValidationError, match="file_changes"):
            _validate_response(response)

    def test_dbt_missing_after_content_raises(self):
        """dbt_project_change with empty after_content raises error."""
        response = SolutionResponse(
            resolution_category="dbt_project_change",
            explanation="test",
            risk_level="low",
            risk_justification="test",
            file_changes=[
                FileChange(
                    file_path="test.sql",
                    change_type="sql_change",
                    after_content="",
                )
            ],
        )
        with pytest.raises(LLMResponseValidationError, match="after_content"):
            _validate_response(response)

    def test_bq_missing_setting_recommendation_raises(self):
        """bigquery_infrastructure without setting_recommendation raises error."""
        response = SolutionResponse(
            resolution_category="bigquery_infrastructure",
            explanation="test",
            risk_level="low",
            risk_justification="test",
            setting_recommendation=None,
        )
        with pytest.raises(LLMResponseValidationError, match="setting_recommendation"):
            _validate_response(response)

    def test_missing_explanation_raises(self):
        """Response without explanation raises validation error."""
        response = SolutionResponse(
            resolution_category="bigquery_infrastructure",
            explanation="",
            risk_level="low",
            risk_justification="test",
            setting_recommendation=SettingRecommendation(
                current_value="100",
                recommended_value="200",
                affected_resource="resource",
            ),
        )
        with pytest.raises(LLMResponseValidationError, match="explanation"):
            _validate_response(response)


# ---------------------------------------------------------------------------
# _extract_relevant_files tests
# ---------------------------------------------------------------------------


class TestExtractRelevantFiles:
    """Test manifest file extraction."""

    def test_extracts_original_file_path(self):
        """Extracts the model's original file path."""
        opp = _mock_opportunity()
        manifest = {
            "nodes": {
                "model.proj.stg_orders": {
                    "name": "stg_orders",
                    "original_file_path": "models/staging/stg_orders.sql",
                    "resource_type": "model",
                }
            }
        }
        files = _extract_relevant_files(opp, manifest)
        assert "models/staging/stg_orders.sql" in files

    def test_extracts_patch_path(self):
        """Extracts the schema YAML patch path."""
        opp = _mock_opportunity()
        manifest = {
            "nodes": {
                "model.proj.stg_orders": {
                    "name": "stg_orders",
                    "original_file_path": "models/stg_orders.sql",
                    "patch_path": "proj://models/schema.yml",
                    "resource_type": "model",
                }
            }
        }
        files = _extract_relevant_files(opp, manifest)
        assert "models/schema.yml" in files

    def test_includes_dbt_project_yml(self):
        """Always includes dbt_project.yml."""
        opp = _mock_opportunity()
        manifest = {
            "nodes": {
                "model.proj.stg_orders": {
                    "name": "stg_orders",
                    "original_file_path": "models/stg_orders.sql",
                    "resource_type": "model",
                }
            }
        }
        files = _extract_relevant_files(opp, manifest)
        assert "dbt_project.yml" in files

    def test_no_model_name_returns_empty(self):
        """Returns empty list when no dbt_model_name."""
        opp = _mock_opportunity(dbt_model_name=None)
        files = _extract_relevant_files(opp, {"nodes": {}})
        assert files == []

    def test_model_not_in_manifest_returns_empty(self):
        """Returns empty list when model not found in manifest."""
        opp = _mock_opportunity(dbt_model_name="nonexistent")
        manifest = {
            "nodes": {
                "model.proj.other": {
                    "name": "other",
                    "original_file_path": "models/other.sql",
                }
            }
        }
        files = _extract_relevant_files(opp, manifest)
        assert files == []

    def test_extracts_macro_references(self):
        """Extracts referenced macro file paths."""
        opp = _mock_opportunity()
        manifest = {
            "nodes": {
                "model.proj.stg_orders": {
                    "name": "stg_orders",
                    "original_file_path": "models/stg_orders.sql",
                    "resource_type": "model",
                    "depends_on": {"macros": ["macro.proj.generate_schema"]},
                }
            },
            "macros": {
                "macro.proj.generate_schema": {
                    "original_file_path": "macros/generate_schema.sql"
                }
            },
        }
        files = _extract_relevant_files(opp, manifest)
        assert "macros/generate_schema.sql" in files


# ---------------------------------------------------------------------------
# _infer_resolution_category tests
# ---------------------------------------------------------------------------


class TestInferResolutionCategory:
    """Test deterministic resolution_category inference."""

    def test_shuffle_spill_with_source_returns_dbt(self):
        assert _infer_resolution_category("shuffle_spill", True) == "dbt_project_change"

    def test_join_explosion_with_source_returns_dbt(self):
        assert (
            _infer_resolution_category("join_explosion", True) == "dbt_project_change"
        )

    def test_partition_pruning_with_source_returns_dbt(self):
        assert (
            _infer_resolution_category("partition_pruning", True)
            == "dbt_project_change"
        )

    @pytest.mark.parametrize(
        "opportunity_type",
        [
            "dead_cte",
            "dead_column",
            "dead_window_expression",
            "unused_aggregation_output",
            "redundant_order_by",
            "unused_join",
        ],
    )
    def test_new_dbt_change_rules_with_source_return_dbt(self, opportunity_type):
        assert (
            _infer_resolution_category(opportunity_type, True) == "dbt_project_change"
        )

    def test_shuffle_spill_without_source_returns_none(self):
        """Without source code, LLM should decide (could be infra advice)."""
        assert _infer_resolution_category("shuffle_spill", False) is None

    def test_slot_contention_returns_none(self):
        """slot_contention is ambiguous — LLM should decide."""
        assert _infer_resolution_category("slot_contention", True) is None
        assert _infer_resolution_category("slot_contention", False) is None

    def test_unknown_type_returns_none(self):
        assert _infer_resolution_category("unknown_type", True) is None


# ---------------------------------------------------------------------------
# _infer_change_type tests
# ---------------------------------------------------------------------------


class TestInferChangeType:
    """Test deterministic change_type inference from file extension."""

    def test_sql_file(self):
        assert _infer_change_type("models/stg_orders.sql") == "sql_change"

    def test_dbt_project_yml(self):
        assert _infer_change_type("dbt_project.yml") == "project_config_change"

    def test_packages_yml(self):
        assert _infer_change_type("packages.yml") == "project_config_change"

    def test_schema_yml(self):
        assert _infer_change_type("models/schema.yml") == "schema_change"

    def test_schema_yaml(self):
        assert _infer_change_type("models/sources.yaml") == "schema_change"

    def test_prefixed_sql_file(self):
        assert _infer_change_type("dbt-project/models/stg_orders.sql") == "sql_change"

    def test_prefixed_dbt_project_yml(self):
        assert (
            _infer_change_type("dbt-project/dbt_project.yml") == "project_config_change"
        )

    def test_unknown_extension_defaults_to_sql(self):
        assert _infer_change_type("some_file.txt") == "sql_change"


# ---------------------------------------------------------------------------
# dbt prefix post-processing tests
# ---------------------------------------------------------------------------


class TestDBTPrefixPostProcessing:
    """Test that dbt subdirectory prefix is applied to LLM file paths."""

    def test_prefix_applied_when_llm_omits_it(self):
        """LLM returns 'models/stg.sql', prefix is 'dbt-project' → 'dbt-project/models/stg.sql'."""
        mock_llm = MagicMock()
        mock_llm.generate.return_value = (_dbt_response(), _llm_metadata())

        mock_github = MagicMock()

        # _detect_dbt_prefix: root dbt_project.yml not found, found in 'dbt-project/'
        from governor_core.github.client import GitHubFileNotFoundError as GHNotFound

        def get_file_content(repo, path, ref=None):
            if path == "dbt_project.yml":
                raise GHNotFound("not found")
            if path == "dbt-project/dbt_project.yml":
                return "name: project"
            # Source file retrieval
            return "SELECT id, status FROM raw.orders"

        mock_github.get_file_content.side_effect = get_file_content
        mock_github.get_directory_listing.return_value = ["dbt-project", "README.md"]

        generator = SolutionGenerator(llm_provider=mock_llm, github_client=mock_github)

        opp = _mock_opportunity()
        config = _mock_config()
        mv = _mock_manifest_version(
            content={
                "nodes": {
                    "model.proj.stg_orders": {
                        "name": "stg_orders",
                        "original_file_path": "models/stg_orders.sql",
                        "resource_type": "model",
                    }
                }
            }
        )

        result = generator.generate(opp, config, mv)

        assert result.solutions[0].file_path == "dbt-project/models/stg_orders.sql"

    def test_no_double_prefix(self):
        """If LLM already includes the prefix, don't prepend it again."""
        mock_llm = MagicMock()
        # LLM response already has the prefix in file_path
        resp = SolutionResponse(
            resolution_category="dbt_project_change",
            explanation="Fix",
            risk_level="low",
            risk_justification="Safe",
            file_changes=[
                FileChange(
                    file_path="dbt-project/models/stg_orders.sql",
                    change_type="sql_change",
                    before_content="SELECT id, status FROM raw.orders",
                    after_content="SELECT id, status, created_at FROM raw.orders",
                )
            ],
        )
        mock_llm.generate.return_value = (resp, _llm_metadata())

        mock_github = MagicMock()
        from governor_core.github.client import GitHubFileNotFoundError as GHNotFound

        def get_file_content(repo, path, ref=None):
            if path == "dbt_project.yml":
                raise GHNotFound("not found")
            if path == "dbt-project/dbt_project.yml":
                return "name: project"
            return "SELECT id, status FROM raw.orders"

        mock_github.get_file_content.side_effect = get_file_content
        mock_github.get_directory_listing.return_value = ["dbt-project"]

        generator = SolutionGenerator(llm_provider=mock_llm, github_client=mock_github)
        opp = _mock_opportunity()
        config = _mock_config()
        mv = _mock_manifest_version(
            content={
                "nodes": {
                    "model.proj.stg_orders": {
                        "name": "stg_orders",
                        "original_file_path": "models/stg_orders.sql",
                        "resource_type": "model",
                    }
                }
            }
        )

        result = generator.generate(opp, config, mv)

        # Should NOT be "dbt-project/dbt-project/models/stg_orders.sql"
        assert result.solutions[0].file_path == "dbt-project/models/stg_orders.sql"

    def test_before_content_uses_github_when_llm_returns_prefixed_path(self):
        """When LLM returns file_path with dbt prefix, before_content should
        still be resolved from source_files (which uses un-prefixed keys)."""
        mock_llm = MagicMock()
        # LLM returns prefixed path + slightly different before_content
        resp = SolutionResponse(
            resolution_category="dbt_project_change",
            explanation="Fix",
            risk_level="low",
            risk_justification="Safe",
            file_changes=[
                FileChange(
                    file_path="dbt-project/models/stg_orders.sql",
                    change_type="sql_change",
                    before_content="SELECT id, status\nFROM raw.orders",  # LLM's copy (wrong)
                    after_content="SELECT id, status, created_at\nFROM raw.orders",
                )
            ],
        )
        mock_llm.generate.return_value = (resp, _llm_metadata())

        mock_github = MagicMock()
        from governor_core.github.client import GitHubFileNotFoundError as GHNotFound

        actual_github_content = (
            "SELECT id, status\nFROM raw.orders\n"  # actual file (trailing newline)
        )

        def get_file_content(repo, path, ref=None):
            if path == "dbt_project.yml":
                raise GHNotFound("not found")
            if path == "dbt-project/dbt_project.yml":
                return "name: project"
            return actual_github_content

        mock_github.get_file_content.side_effect = get_file_content
        mock_github.get_directory_listing.return_value = ["dbt-project"]

        generator = SolutionGenerator(llm_provider=mock_llm, github_client=mock_github)
        opp = _mock_opportunity()
        config = _mock_config()
        mv = _mock_manifest_version(
            content={
                "nodes": {
                    "model.proj.stg_orders": {
                        "name": "stg_orders",
                        "original_file_path": "models/stg_orders.sql",
                        "resource_type": "model",
                    }
                }
            }
        )

        result = generator.generate(opp, config, mv)

        # before_content should be the actual GitHub content, not the LLM's copy
        assert result.solutions[0].before_content == actual_github_content


# ---------------------------------------------------------------------------
# resolution_category override tests
# ---------------------------------------------------------------------------


class TestResolutionCategoryOverride:
    """Test that resolution_category is overridden for known opportunity types."""

    def test_shuffle_spill_overrides_wrong_category(self):
        """If LLM says bigquery_infrastructure for shuffle_spill with source, override."""
        mock_llm = MagicMock()
        # LLM incorrectly says bigquery_infrastructure, but has file_changes
        resp = SolutionResponse(
            resolution_category="bigquery_infrastructure",
            explanation="Increase slots",
            risk_level="medium",
            risk_justification="Requires planning",
            setting_recommendation=None,
            file_changes=[
                FileChange(
                    file_path="models/stg_orders.sql",
                    change_type="sql_change",
                    before_content="SELECT id, status FROM raw.orders",
                    after_content="SELECT id, status, created_at FROM raw.orders",
                )
            ],
        )
        mock_llm.generate.return_value = (resp, _llm_metadata())

        mock_github = MagicMock()
        mock_github.get_file_content.return_value = "SELECT id, status FROM raw.orders"

        generator = SolutionGenerator(llm_provider=mock_llm, github_client=mock_github)
        opp = _mock_opportunity(opportunity_type="shuffle_spill")
        config = _mock_config()
        mv = _mock_manifest_version(
            content={
                "nodes": {
                    "model.proj.stg_orders": {
                        "name": "stg_orders",
                        "original_file_path": "models/stg_orders.sql",
                        "resource_type": "model",
                    }
                }
            }
        )

        result = generator.generate(opp, config, mv)

        assert result.resolution_category == "dbt_project_change"
        assert result.solutions[0].resolution_category == "dbt_project_change"

    def test_slot_contention_not_overridden(self):
        """slot_contention category is NOT overridden — LLM decides."""
        mock_llm = MagicMock()
        mock_llm.generate.return_value = (_bq_response(), _llm_metadata())

        generator = SolutionGenerator(llm_provider=mock_llm, github_client=None)
        opp = _mock_opportunity(opportunity_type="slot_contention", dbt_model_name=None)
        config = _mock_config(github_repo=None)

        result = generator.generate(opp, config)

        assert result.resolution_category == "bigquery_infrastructure"


# ---------------------------------------------------------------------------
# Verification agent tests
# ---------------------------------------------------------------------------


class TestVerificationAgent:
    """Test that the verification agent reviews file changes."""

    def test_safe_change_passes_verification(self):
        """Verification agent says safe=True — solution is kept."""
        mock_llm = MagicMock()
        mock_llm.generate.return_value = (_dbt_response(), _llm_metadata())
        mock_llm.verify.return_value = VerificationResult(safe=True, issues=[])

        mock_github = MagicMock()
        mock_github.get_file_content.return_value = _SOURCE_FILE

        generator = SolutionGenerator(llm_provider=mock_llm, github_client=mock_github)

        opp = _mock_opportunity()
        config = _mock_config()
        mv = _mock_manifest_version(
            content={
                "nodes": {
                    "model.proj.stg_orders": {
                        "name": "stg_orders",
                        "original_file_path": "models/stg_orders.sql",
                        "resource_type": "model",
                    }
                }
            }
        )

        result = generator.generate(opp, config, mv)

        assert len(result.solutions) == 1
        mock_llm.verify.assert_called_once()

    def test_unsafe_change_rejected(self):
        """Verification agent says safe=False — solution is rejected."""
        mock_llm = MagicMock()
        mock_llm.generate.return_value = (_dbt_response(), _llm_metadata())
        mock_llm.verify.return_value = VerificationResult(
            safe=False,
            issues=[
                "The modified file is missing the fee_analysis CTE",
                "Business logic for fee categories was removed",
            ],
        )

        mock_github = MagicMock()
        mock_github.get_file_content.return_value = _SOURCE_FILE

        generator = SolutionGenerator(llm_provider=mock_llm, github_client=mock_github)

        opp = _mock_opportunity()
        config = _mock_config()
        mv = _mock_manifest_version(
            content={
                "nodes": {
                    "model.proj.stg_orders": {
                        "name": "stg_orders",
                        "original_file_path": "models/stg_orders.sql",
                        "resource_type": "model",
                    }
                }
            }
        )

        result = generator.generate(opp, config, mv)

        # Solution should be rejected by verification
        assert len(result.solutions) == 0
        mock_llm.verify.assert_called_once()

    def test_verification_exception_retries_then_rejects(self):
        """If verification call fails, retries up to 3 times then rejects."""
        mock_llm = MagicMock()
        mock_llm.generate.return_value = (_dbt_response(), _llm_metadata())
        mock_llm.verify.side_effect = RuntimeError("API timeout")

        mock_github = MagicMock()
        mock_github.get_file_content.return_value = _SOURCE_FILE

        generator = SolutionGenerator(llm_provider=mock_llm, github_client=mock_github)

        opp = _mock_opportunity()
        config = _mock_config()
        mv = _mock_manifest_version(
            content={
                "nodes": {
                    "model.proj.stg_orders": {
                        "name": "stg_orders",
                        "original_file_path": "models/stg_orders.sql",
                        "resource_type": "model",
                    }
                }
            }
        )

        result = generator.generate(opp, config, mv)

        # Fail closed: solution rejected after all retries exhausted
        assert len(result.solutions) == 0
        # Should have attempted 3 times (initial + 2 retries)
        assert mock_llm.verify.call_count == 3

    def test_verification_succeeds_on_retry(self):
        """If verification fails once then succeeds, solution is kept."""
        mock_llm = MagicMock()
        mock_llm.generate.return_value = (_dbt_response(), _llm_metadata())
        # First call fails, second call succeeds
        mock_llm.verify.side_effect = [
            RuntimeError("transient error"),
            VerificationResult(safe=True, issues=[]),
        ]

        mock_github = MagicMock()
        mock_github.get_file_content.return_value = _SOURCE_FILE

        generator = SolutionGenerator(llm_provider=mock_llm, github_client=mock_github)

        opp = _mock_opportunity()
        config = _mock_config()
        mv = _mock_manifest_version(
            content={
                "nodes": {
                    "model.proj.stg_orders": {
                        "name": "stg_orders",
                        "original_file_path": "models/stg_orders.sql",
                        "resource_type": "model",
                    }
                }
            }
        )

        result = generator.generate(opp, config, mv)

        # Solution should be kept — verification succeeded on retry
        assert len(result.solutions) == 1
        assert mock_llm.verify.call_count == 2

    def test_bq_infrastructure_skips_verification(self):
        """BigQuery infrastructure solutions (no file changes) skip verification."""
        mock_llm = MagicMock()
        mock_llm.generate.return_value = (_bq_response(), _llm_metadata())

        generator = SolutionGenerator(llm_provider=mock_llm, github_client=None)

        opp = _mock_opportunity(dbt_model_name=None)
        config = _mock_config(github_repo=None)

        result = generator.generate(opp, config)

        assert len(result.solutions) == 1
        # verify should NOT be called for infra solutions
        mock_llm.verify.assert_not_called()

    def test_verification_receives_correct_args(self):
        """Verify is called with correct file_path, before, after, context."""
        mock_llm = MagicMock()
        mock_llm.generate.return_value = (_dbt_response(), _llm_metadata())
        mock_llm.verify.return_value = VerificationResult(safe=True, issues=[])

        mock_github = MagicMock()
        mock_github.get_file_content.return_value = _SOURCE_FILE

        generator = SolutionGenerator(llm_provider=mock_llm, github_client=mock_github)

        opp = _mock_opportunity()
        config = _mock_config()
        mv = _mock_manifest_version(
            content={
                "nodes": {
                    "model.proj.stg_orders": {
                        "name": "stg_orders",
                        "original_file_path": "models/stg_orders.sql",
                        "resource_type": "model",
                    }
                }
            }
        )

        generator.generate(opp, config, mv)

        # Check verify was called with correct arguments
        call_kwargs = mock_llm.verify.call_args
        assert call_kwargs.kwargs["file_path"] == "models/stg_orders.sql"
        assert call_kwargs.kwargs["before_content"] == _SOURCE_FILE
        assert (
            call_kwargs.kwargs["after_content"]
            == "SELECT id, status, created_at FROM raw.orders"
        )
        assert call_kwargs.kwargs["change_context"] == opp.explanation


class TestSolutionGuardrails:
    def test_filter_solutions_by_guardrails_blocks_materialization_change(self):
        generator = SolutionGenerator(llm_provider=MagicMock(), github_client=None)
        effective_policy = build_effective_solution_policy(["sql_change"])
        solution = generator._response_to_solution_data(
            SolutionResponse(
                resolution_category="dbt_project_change",
                explanation="Switch model to incremental",
                risk_level="medium",
                risk_justification="Changes materialization",
                file_changes=[
                    FileChange(
                        file_path="models/stg_orders.sql",
                        change_type="project_config_change",
                        before_content='{{ config(materialized="table") }}\nselect 1',
                        after_content='{{ config(materialized="incremental") }}\nselect 1',
                    )
                ],
            ),
            repository="owner/repo",
            commit_sha="abc123",
        )[0]

        allowed, blocked = generator._filter_solutions_by_guardrails(
            [solution],
            effective_policy,
        )

        assert allowed == []
        assert len(blocked) == 1
        assert blocked[0].blocked_policy_tags == [
            "dbt_config_change",
            "materialization_change",
        ]

    def test_filter_solutions_by_guardrails_keeps_sql_change_and_tags_report(self):
        generator = SolutionGenerator(llm_provider=MagicMock(), github_client=None)
        effective_policy = build_effective_solution_policy(["sql_change"])
        solution = generator._response_to_solution_data(
            SolutionResponse(
                resolution_category="dbt_project_change",
                explanation="Remove unused columns",
                risk_level="low",
                risk_justification="Pure SQL edit",
                file_changes=[
                    FileChange(
                        file_path="models/stg_orders.sql",
                        change_type="sql_change",
                        before_content="select id, status from raw.orders",
                        after_content="select id from raw.orders",
                    )
                ],
            ),
            repository="owner/repo",
            commit_sha="abc123",
        )[0]

        allowed, blocked = generator._filter_solutions_by_guardrails(
            [solution],
            effective_policy,
        )

        assert len(allowed) == 1
        assert blocked == []
        assert allowed[0].policy_tags == ["sql_change"]
        assert allowed[0].guardrail_report["allowed"] is True
