"""Unit tests for shadow gating."""

from __future__ import annotations

import pytest

from governor_core.shadow.exceptions import ShadowSkipped
from governor_core.shadow.gating import evaluate_gates
from tests.fixtures.factories import (
    OpportunityFactory,
    ShadowValidationRunFactory,
    SolutionFactory,
)

_MANIFEST_SIMPLE = {
    "child_map": {
        "model.p.fct_orders": ["model.p.daily_revenue"],
        "model.p.daily_revenue": [],
    },
    "metadata": {"project_name": "p"},
}


def _seed(db, **config_overrides):
    opp = OpportunityFactory.create()
    sol = SolutionFactory.create(solution_job__opportunity=opp)
    config = opp.configuration
    for k, v in config_overrides.items():
        setattr(config, k, v)
    db.flush()
    return sol, config


def test_disabled_config_skips(db):
    sol, config = _seed(db, shadow_validation_enabled=False)
    with pytest.raises(ShadowSkipped) as exc:
        evaluate_gates(
            db,
            solution=sol,
            configuration=config,
            manifest_content=_MANIFEST_SIMPLE,
            target_node_id="model.p.fct_orders",
        )
    assert exc.value.reason == "disabled"


def test_cascade_over_cap_skips(db):
    sol, config = _seed(db, shadow_validation_enabled=True, shadow_cascade_cap=1)
    with pytest.raises(ShadowSkipped) as exc:
        evaluate_gates(
            db,
            solution=sol,
            configuration=config,
            manifest_content=_MANIFEST_SIMPLE,
            target_node_id="model.p.fct_orders",
        )
    assert exc.value.reason == "cascade_too_large"


def test_budget_over_cap_skips(db):
    sol, config = _seed(
        db, shadow_validation_enabled=True, shadow_budget_usd=0.001
    )

    def dry_run(*, model_node_ids, manifest_content):  # noqa: ARG001
        return 10 * 1024**4  # 10 TiB → ~$62.50

    with pytest.raises(ShadowSkipped) as exc:
        evaluate_gates(
            db,
            solution=sol,
            configuration=config,
            manifest_content=_MANIFEST_SIMPLE,
            target_node_id="model.p.fct_orders",
            dry_run_fn=dry_run,
        )
    assert exc.value.reason == "budget_exceeded"


def test_concurrent_run_skips(db):
    sol, config = _seed(db, shadow_validation_enabled=True)
    # Seed an unrelated running shadow run bound to this same config
    ShadowValidationRunFactory.create(
        config_id=config.id,
        status="running",
    )
    with pytest.raises(ShadowSkipped) as exc:
        evaluate_gates(
            db,
            solution=sol,
            configuration=config,
            manifest_content=_MANIFEST_SIMPLE,
            target_node_id="model.p.fct_orders",
        )
    assert exc.value.reason == "concurrent_run_in_flight"


def test_unsupported_materialization_skips(db):
    sol, config = _seed(db, shadow_validation_enabled=True)
    manifest = {
        **_MANIFEST_SIMPLE,
        "nodes": {
            "model.p.fct_orders": {
                "config": {"materialized": "materialized_view"},
            }
        },
    }
    with pytest.raises(ShadowSkipped) as exc:
        evaluate_gates(
            db,
            solution=sol,
            configuration=config,
            manifest_content=manifest,
            target_node_id="model.p.fct_orders",
        )
    assert exc.value.reason == "materialization_unsupported"


def test_all_gates_pass_returns_cascade(db):
    sol, config = _seed(db, shadow_validation_enabled=True)
    cascade = evaluate_gates(
        db,
        solution=sol,
        configuration=config,
        manifest_content=_MANIFEST_SIMPLE,
        target_node_id="model.p.fct_orders",
    )
    assert cascade == ["model.p.fct_orders", "model.p.daily_revenue"]
