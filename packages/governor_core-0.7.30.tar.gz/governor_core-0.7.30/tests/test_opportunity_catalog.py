from governor_core.opportunities.catalog import (
    get_detection_analysis_surfaces,
    get_detection_rule_catalog,
    get_grouped_detection_rule_catalog,
)


def test_detection_analysis_surface_catalog_exposes_three_surfaces():
    surfaces = get_detection_analysis_surfaces()

    assert [surface.key for surface in surfaces] == [
        "build",
        "consumption",
        "ingestion",
    ]
    assert [surface.title for surface in surfaces] == [
        "Build",
        "Consumption",
        "Ingestion",
    ]


def test_detection_rule_catalog_entries_include_surface_metadata():
    catalog = get_detection_rule_catalog()

    assert catalog
    for entry in catalog:
        assert entry.analysis_surface in {"build", "consumption", "ingestion"}
        assert entry.analysis_surface_title
        assert entry.analysis_surface_description

    storage_entry = next(
        entry for entry in catalog if entry.rule_type == "storage_billing_optimization"
    )
    assert storage_entry.analysis_surface == "ingestion"
    assert storage_entry.analysis_surface_title == "Ingestion"


def test_grouped_catalog_includes_surface_summaries():
    groups = get_grouped_detection_rule_catalog()

    performance_group = next(group for group in groups if group.key == "performance")
    storage_group = next(group for group in groups if group.key == "storage")

    assert any(
        summary.key == "build" and summary.count > 0
        for summary in performance_group.analysis_surface_summaries
    )
    assert len(storage_group.analysis_surface_summaries) == 1
    assert storage_group.analysis_surface_summaries[0].key == "ingestion"
    assert storage_group.analysis_surface_summaries[0].title == "Ingestion"
