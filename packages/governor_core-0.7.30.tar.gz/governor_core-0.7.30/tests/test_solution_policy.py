from __future__ import annotations

from governor_core.solutions.policy import (
    build_effective_solution_policy,
    classify_solution_policy_tags,
    evaluate_solution_policy,
    get_default_solution_policy_tags,
)


_SQL_WITH_CONFIG = """\
{{ config(
    materialized="table"
) }}

select id from source_table
"""

_SQL_WITH_CLUSTER = """\
{{ config(
    materialized="table",
    cluster_by=["customer_id"]
) }}

select id from source_table
"""

_SQL_WITH_VIEW = """\
{{ config(
    materialized="view"
) }}

select id from source_table
"""


def test_build_effective_solution_policy_inherits_all_tags():
    policy = build_effective_solution_policy(None)

    assert policy.mode == "all"
    assert policy.effective_policy_tags == get_default_solution_policy_tags()
    assert policy.unknown_policy_tags == []


def test_classify_solution_policy_tags_for_config_only_sql_change():
    tags = classify_solution_policy_tags(
        resolution_category="dbt_project_change",
        change_type="project_config_change",
        file_path="models/my_model.sql",
        before_content=_SQL_WITH_CONFIG,
        after_content=_SQL_WITH_CLUSTER,
    )

    assert tags == {"dbt_config_change"}


def test_classify_solution_policy_tags_for_materialization_change():
    tags = classify_solution_policy_tags(
        resolution_category="dbt_project_change",
        change_type="project_config_change",
        file_path="models/my_model.sql",
        before_content=_SQL_WITH_CONFIG,
        after_content=_SQL_WITH_VIEW,
    )

    assert tags == {"dbt_config_change", "materialization_change"}


def test_classify_solution_policy_tags_for_sql_body_change():
    tags = classify_solution_policy_tags(
        resolution_category="dbt_project_change",
        change_type="sql_change",
        file_path="models/my_model.sql",
        before_content="select id from source_table",
        after_content="select id, customer_id from source_table",
    )

    assert tags == {"sql_change"}


def test_evaluate_solution_policy_blocks_disallowed_tags():
    policy = build_effective_solution_policy(["sql_change"])

    evaluation = evaluate_solution_policy(
        {"dbt_config_change", "materialization_change"},
        configured_policy_tags=["sql_change"],
        effective_policy=policy,
    )

    assert evaluation.allowed is False
    assert evaluation.blocked_policy_tags == [
        "dbt_config_change",
        "materialization_change",
    ]
    assert evaluation.reason == "configuration_disallows_policy_tags"


def test_evaluate_solution_policy_allows_bigquery_infrastructure():
    policy = build_effective_solution_policy(["bigquery_infrastructure"])

    evaluation = evaluate_solution_policy(
        {"bigquery_infrastructure"},
        configured_policy_tags=["bigquery_infrastructure"],
        effective_policy=policy,
    )

    assert evaluation.allowed is True
    assert evaluation.blocked_policy_tags == []
