"""Tests for PaginationContext (spec 008, T015)."""

from governor_core.utils.pagination import PaginationContext


class TestPaginationContext:
    def test_page_1_of_1(self):
        p = PaginationContext(page=1, page_size=25, total_items=10)
        assert p.total_pages == 1
        assert p.has_prev is False
        assert p.has_next is False
        assert p.start_index == 1
        assert p.end_index == 10

    def test_page_1_of_10(self):
        p = PaginationContext(page=1, page_size=25, total_items=250)
        assert p.total_pages == 10
        assert p.has_prev is False
        assert p.has_next is True
        assert p.start_index == 1
        assert p.end_index == 25

    def test_last_page(self):
        p = PaginationContext(page=4, page_size=25, total_items=90)
        assert p.total_pages == 4
        assert p.has_prev is True
        assert p.has_next is False
        assert p.start_index == 76
        assert p.end_index == 90

    def test_page_range_window(self):
        p = PaginationContext(page=5, page_size=25, total_items=250)
        assert p.page_range(2) == [3, 4, 5, 6, 7]

    def test_page_range_at_start(self):
        p = PaginationContext(page=1, page_size=25, total_items=250)
        assert p.page_range(2) == [1, 2, 3]

    def test_page_range_at_end(self):
        p = PaginationContext(page=10, page_size=25, total_items=250)
        assert p.page_range(2) == [8, 9, 10]

    def test_has_prev_has_next_middle_page(self):
        p = PaginationContext(page=3, page_size=25, total_items=100)
        assert p.has_prev is True
        assert p.has_next is True

    def test_start_end_index_middle(self):
        p = PaginationContext(page=2, page_size=25, total_items=100)
        assert p.start_index == 26
        assert p.end_index == 50

    def test_total_items_zero(self):
        p = PaginationContext(page=1, page_size=25, total_items=0)
        assert p.total_pages == 1
        assert p.has_prev is False
        assert p.has_next is False
        assert p.start_index == 0
        assert p.end_index == 0

    def test_exact_page_boundary(self):
        p = PaginationContext(page=2, page_size=25, total_items=50)
        assert p.total_pages == 2
        assert p.start_index == 26
        assert p.end_index == 50
