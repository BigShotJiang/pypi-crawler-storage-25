"""Unit tests for app/opportunities/rules/dead_column.py."""

from decimal import Decimal

import pytest

from governor_core.opportunities.rules.dead_column import DeadColumnRule


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _node(name: str, sql: str, materialized: str = "table") -> dict:
    return {
        "name": name,
        "unique_id": f"model.proj.{name}",
        "database": "my-project",
        "schema": "dbt_prod",
        "identifier": name,
        "config": {"materialized": materialized},
        "raw_code": sql,
        "compiled_code": sql,
    }


def _simple_manifest() -> dict:
    """Model with a CTE that has 2 dead columns (elevation, country_code)."""
    sql = """
WITH
  base AS (
    SELECT station_id, name, elevation, country_code FROM raw_stations
  ),
  final AS (
    SELECT station_id, name FROM base
  )
SELECT station_id, name FROM final
"""
    nodes = {"model.proj.stg_stations": _node("stg_stations", sql)}
    child_map = {"model.proj.stg_stations": []}
    return {"nodes": nodes, "child_map": child_map}


# ---------------------------------------------------------------------------
# rule_type and default_thresholds
# ---------------------------------------------------------------------------


def test_rule_type():
    rule = DeadColumnRule()
    assert rule.rule_type == "dead_column"


def test_default_thresholds():
    rule = DeadColumnRule()
    thresholds = rule.default_thresholds
    assert "min_dead_columns" in thresholds
    assert "min_column_count" in thresholds
    assert "excluded_column_patterns" in thresholds
    assert thresholds["min_dead_columns"] == 1
    assert thresholds["min_column_count"] == 3
    assert thresholds["excluded_column_patterns"] == []


# ---------------------------------------------------------------------------
# detect() — None / empty manifest
# ---------------------------------------------------------------------------


def test_detect_none_manifest():
    rule = DeadColumnRule()
    results = rule.detect(jobs=[], manifest_content=None, thresholds={})
    assert results == []


def test_detect_empty_manifest():
    rule = DeadColumnRule()
    results = rule.detect(jobs=[], manifest_content={}, thresholds={})
    assert results == []


def test_detect_manifest_without_nodes():
    rule = DeadColumnRule()
    results = rule.detect(
        jobs=[],
        manifest_content={"nodes": {}, "child_map": {}},
        thresholds={},
    )
    assert results == []


# ---------------------------------------------------------------------------
# detect() — basic dead column opportunity
# ---------------------------------------------------------------------------


def test_detect_returns_candidate_for_dead_columns():
    rule = DeadColumnRule()
    thresholds = rule.get_thresholds()
    thresholds["min_dead_columns"] = 1

    results = rule.detect(
        jobs=[],
        manifest_content=_simple_manifest(),
        thresholds=thresholds,
    )
    assert len(results) == 1
    candidate = results[0]
    assert candidate.opportunity_type == "dead_column"
    assert candidate.dbt_model_name == "stg_stations"
    assert set(candidate.evidence_snapshot["dead_columns"]) == {
        "elevation",
        "country_code",
    }
    assert candidate.evidence_snapshot["dead_count"] == 2
    assert candidate.confidence == pytest.approx(0.65)


def test_detect_evidence_snapshot_structure():
    rule = DeadColumnRule()
    thresholds = rule.get_thresholds()
    thresholds["min_dead_columns"] = 1

    results = rule.detect(
        jobs=[],
        manifest_content=_simple_manifest(),
        thresholds=thresholds,
    )
    assert len(results) == 1
    ev = results[0].evidence_snapshot
    assert "dead_columns" in ev
    assert "cte_dead_columns" in ev
    assert "total_columns" in ev
    assert "dead_count" in ev
    assert "model_cte_count" in ev
    assert "estimated_bytes_saved_per_run" in ev
    assert "sample_job_count" in ev
    assert ev["sample_job_count"] == 0  # no jobs passed

    # cte_dead_columns must be a list of dicts with required keys
    cte_dead = ev["cte_dead_columns"]
    assert isinstance(cte_dead, list)
    assert len(cte_dead) >= 1
    first = cte_dead[0]
    assert "cte_name" in first
    assert "dead_columns" in first
    assert "all_columns" in first


# ---------------------------------------------------------------------------
# detect() — no job data → zero savings
# ---------------------------------------------------------------------------


def test_detect_no_job_data_zero_savings():
    rule = DeadColumnRule()
    thresholds = rule.get_thresholds()
    thresholds["min_dead_columns"] = 1

    results = rule.detect(
        jobs=[],
        manifest_content=_simple_manifest(),
        thresholds=thresholds,
    )
    assert len(results) == 1
    assert results[0].expected_savings == Decimal("0")
    assert results[0].current_cost_estimate == Decimal("0")


# ---------------------------------------------------------------------------
# detect() — min_dead_columns threshold
# ---------------------------------------------------------------------------


def test_detect_min_dead_columns_suppresses_single_dead_col():
    """Only 1 dead column; threshold requires 3 → suppressed."""
    sql = """
WITH
  base AS (SELECT a, b, c FROM raw),
  final AS (SELECT a, b FROM base)
SELECT a, b FROM final
"""
    nodes = {"model.proj.m": _node("m", sql)}
    manifest = {"nodes": nodes, "child_map": {"model.proj.m": []}}

    rule = DeadColumnRule()
    thresholds = rule.get_thresholds()
    thresholds["min_dead_columns"] = 3  # require 3+ dead columns

    results = rule.detect(jobs=[], manifest_content=manifest, thresholds=thresholds)
    assert results == []


# ---------------------------------------------------------------------------
# detect() — explanation text
# ---------------------------------------------------------------------------


def test_detect_explanation_mentions_model_and_dead_cols():
    rule = DeadColumnRule()
    thresholds = rule.get_thresholds()
    thresholds["min_dead_columns"] = 1

    results = rule.detect(
        jobs=[],
        manifest_content=_simple_manifest(),
        thresholds=thresholds,
    )
    assert len(results) == 1
    explanation = results[0].explanation
    assert "stg_stations" in explanation
    assert "elevation" in explanation or "country_code" in explanation
    assert "0.65" in explanation  # confidence stated


# ---------------------------------------------------------------------------
# detect() — related_job_ids is a list
# ---------------------------------------------------------------------------


def test_detect_related_job_ids_is_list():
    rule = DeadColumnRule()
    thresholds = rule.get_thresholds()
    thresholds["min_dead_columns"] = 1

    results = rule.detect(
        jobs=[],
        manifest_content=_simple_manifest(),
        thresholds=thresholds,
    )
    assert len(results) == 1
    assert isinstance(results[0].related_job_ids, list)


def test_detect_skips_window_outputs_owned_by_typed_rule():
    sql = """
WITH
  base AS (
    SELECT
      id,
      ROW_NUMBER() OVER (PARTITION BY id ORDER BY created_at) AS rn
    FROM raw_events
  ),
  final AS (
    SELECT id FROM base
  )
SELECT id FROM final
"""
    nodes = {"model.proj.m": _node("m", sql)}
    manifest = {"nodes": nodes, "child_map": {"model.proj.m": []}}

    rule = DeadColumnRule()
    results = rule.detect(jobs=[], manifest_content=manifest, thresholds={})

    assert results == []


def test_detect_skips_aggregate_outputs_owned_by_typed_rule():
    sql = """
WITH
  base AS (
    SELECT
      id,
      SUM(amount) AS total_amount
    FROM raw_orders
    GROUP BY id
  ),
  final AS (
    SELECT id FROM base
  )
SELECT id FROM final
"""
    nodes = {"model.proj.m": _node("m", sql)}
    manifest = {"nodes": nodes, "child_map": {"model.proj.m": []}}

    rule = DeadColumnRule()
    results = rule.detect(jobs=[], manifest_content=manifest, thresholds={})

    assert results == []


def test_detect_skips_dead_columns_inside_dead_cte():
    sql = """
WITH
  dead_stage AS (
    SELECT id, unused_col FROM raw_orders
  )
SELECT 1 AS sentinel
"""
    nodes = {"model.proj.m": _node("m", sql)}
    manifest = {"nodes": nodes, "child_map": {"model.proj.m": []}}

    rule = DeadColumnRule()
    results = rule.detect(jobs=[], manifest_content=manifest, thresholds={})

    assert results == []


# ---------------------------------------------------------------------------
# detect() — model without CTEs returns nothing
# ---------------------------------------------------------------------------


def test_detect_model_without_ctes_returns_nothing():
    """A model that is just SELECT col1, col2 FROM t has no CTEs to analyse."""
    sql = "SELECT station_id, name, elevation FROM raw_stations"
    nodes = {"model.proj.m": _node("m", sql)}
    manifest = {"nodes": nodes, "child_map": {"model.proj.m": []}}

    rule = DeadColumnRule()
    results = rule.detect(jobs=[], manifest_content=manifest, thresholds={})
    assert results == []


# ---------------------------------------------------------------------------
# detect() — CTE with SELECT * not flagged
# ---------------------------------------------------------------------------


def test_detect_cte_with_star_not_flagged():
    sql = """
WITH base AS (SELECT * FROM raw)
SELECT a FROM base
"""
    nodes = {"model.proj.m": _node("m", sql)}
    manifest = {"nodes": nodes, "child_map": {"model.proj.m": []}}

    rule = DeadColumnRule()
    results = rule.detect(jobs=[], manifest_content=manifest, thresholds={})
    assert results == []
