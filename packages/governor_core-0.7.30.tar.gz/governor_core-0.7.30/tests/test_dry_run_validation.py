"""Unit tests for dry-run validation in solution generation (spec 050, US3)."""

from __future__ import annotations

from dataclasses import dataclass
from unittest.mock import MagicMock, patch


from governor_core.solutions.generator import (
    SolutionData,
    SolutionGenerator,
    _extract_dataset_name,
    _parse_dbt_config_literal,
)
from governor_core.solutions.dry_run_policy import (
    solution_is_config_only_change,
    solution_supports_optimized_dry_run,
)


@dataclass
class _FakeDryRunResult:
    """Minimal DryRunResult stand-in for testing."""

    valid: bool = True
    total_bytes_processed: int = 0
    estimated_cost_usd: float = 0.0
    referenced_tables: list | None = None
    error: str | None = None

    def to_dict(self):
        return {
            "valid": self.valid,
            "total_bytes_processed": self.total_bytes_processed,
            "estimated_cost_usd": self.estimated_cost_usd,
            "referenced_tables": self.referenced_tables,
            "error": self.error,
        }


# --- T029: Pre-generation dry-run tests ---


class TestPreGenerationDryRun:
    """Tests for pre-generation dry-run (baseline) in the generator."""

    @patch("governor_core.solutions.generator.get_settings")
    @patch("governor_core.solutions.generator.dry_run_query")
    def test_baseline_dry_run_populates_dry_run_original(
        self, mock_dry_run, mock_settings
    ):
        """Pre-gen dry-run result should be passed as dry_run_baseline to SolutionRequest."""
        mock_settings.return_value = MagicMock(
            dbt_compile_enabled=False,
            dry_run_validation_enabled=True,
        )
        mock_dry_run.return_value = _FakeDryRunResult(
            valid=True,
            total_bytes_processed=1_000_000_000,
            estimated_cost_usd=6.25,
        )

        generator = SolutionGenerator(llm_provider=MagicMock(), github_client=None)

        # Call the pre-gen dry-run helper directly
        baseline = generator._pre_generation_dry_run(
            compiled_sql="SELECT * FROM `proj.ds.table`",
            gcp_project="test-project",
        )

        assert baseline is not None
        assert baseline["valid"] is True
        assert baseline["estimated_cost_usd"] == 6.25
        mock_dry_run.assert_called_once_with(
            "test-project", "SELECT * FROM `proj.ds.table`"
        )

    @patch("governor_core.solutions.generator.get_settings")
    @patch("governor_core.solutions.generator.dry_run_query")
    def test_dry_run_failure_does_not_block_generation(
        self, mock_dry_run, mock_settings
    ):
        """When dry-run fails, should return None (not raise)."""
        mock_settings.return_value = MagicMock(
            dbt_compile_enabled=False,
            dry_run_validation_enabled=True,
        )
        mock_dry_run.return_value = _FakeDryRunResult(
            valid=False,
            error="Access Denied: user@example.com",
        )

        generator = SolutionGenerator(llm_provider=MagicMock(), github_client=None)
        baseline = generator._pre_generation_dry_run(
            compiled_sql="SELECT * FROM `proj.ds.table`",
            gcp_project="test-project",
        )

        # Should return the result (with valid=False) for storage, not None
        assert baseline is not None
        assert baseline["valid"] is False

    @patch("governor_core.solutions.generator.get_settings")
    def test_dry_run_skipped_when_no_compiled_sql(self, mock_settings):
        """Should return None when there's no compiled SQL to dry-run."""
        mock_settings.return_value = MagicMock(
            dry_run_validation_enabled=True,
        )

        generator = SolutionGenerator(llm_provider=MagicMock(), github_client=None)
        baseline = generator._pre_generation_dry_run(
            compiled_sql=None,
            gcp_project="test-project",
        )

        assert baseline is None

    @patch("governor_core.solutions.generator.get_settings")
    def test_dry_run_skipped_when_disabled(self, mock_settings):
        """Should return None when dry_run_validation_enabled is False."""
        mock_settings.return_value = MagicMock(
            dry_run_validation_enabled=False,
        )

        generator = SolutionGenerator(llm_provider=MagicMock(), github_client=None)
        baseline = generator._pre_generation_dry_run(
            compiled_sql="SELECT 1",
            gcp_project="test-project",
        )

        assert baseline is None

    @patch("governor_core.solutions.generator.get_settings")
    @patch("governor_core.solutions.generator.dry_run_query")
    def test_dry_run_exception_returns_none(self, mock_dry_run, mock_settings):
        """Should return None when dry_run_query raises an exception."""
        mock_settings.return_value = MagicMock(
            dry_run_validation_enabled=True,
        )
        mock_dry_run.side_effect = RuntimeError("Network error")

        generator = SolutionGenerator(llm_provider=MagicMock(), github_client=None)
        baseline = generator._pre_generation_dry_run(
            compiled_sql="SELECT 1",
            gcp_project="test-project",
        )

        assert baseline is None


# --- T030: Post-generation dry-run tests ---


class TestPostGenerationDryRun:
    """Tests for post-generation dry-run on Docker-compiled modified SQL."""

    @patch("governor_core.solutions.generator.get_settings")
    @patch("governor_core.solutions.generator.dry_run_query")
    def test_post_dry_run_populates_dry_run_modified(self, mock_dry_run, mock_settings):
        """Post-gen dry-run should populate solution's dry_run_modified."""
        mock_settings.return_value = MagicMock(
            dry_run_validation_enabled=True,
        )
        mock_dry_run.return_value = _FakeDryRunResult(
            valid=True,
            total_bytes_processed=500_000_000,
            estimated_cost_usd=3.13,
        )

        sol = SolutionData(
            resolution_category="dbt_project_change",
            explanation="Optimize query",
            risk_level="low",
            risk_justification="Safe change",
            file_path="models/staging/stg_orders.sql",
            after_content="SELECT id FROM table",
        )

        generator = SolutionGenerator(llm_provider=MagicMock(), github_client=None)
        compiled_map = {"models/staging/stg_orders.sql": "SELECT id FROM `p.d.table`"}

        generator._post_generation_dry_run(
            solutions=[sol],
            compiled_modified_sql_map=compiled_map,
            gcp_project="test-project",
            dry_run_original={"valid": True, "estimated_cost_usd": 6.25},
        )

        assert sol.dry_run_modified is not None
        assert sol.dry_run_modified["valid"] is True
        assert sol.dry_run_modified["estimated_cost_usd"] == 3.13

    @patch("governor_core.solutions.generator.get_settings")
    @patch("governor_core.solutions.generator.dry_run_query")
    def test_post_dry_run_failure_does_not_set_trust_tier(
        self, mock_dry_run, mock_settings
    ):
        """When post-gen dry-run fails, solution still gets dry_run_modified with valid=False."""
        mock_settings.return_value = MagicMock(
            dry_run_validation_enabled=True,
        )
        mock_dry_run.return_value = _FakeDryRunResult(
            valid=False,
            error="Syntax error in SQL",
        )

        sol = SolutionData(
            resolution_category="dbt_project_change",
            explanation="Optimize query",
            risk_level="low",
            risk_justification="Safe change",
            file_path="models/staging/stg_orders.sql",
            trust_tier="validated",
        )

        generator = SolutionGenerator(llm_provider=MagicMock(), github_client=None)
        compiled_map = {
            "models/staging/stg_orders.sql": "SELECT invalid FROM `p.d.table`"
        }

        generator._post_generation_dry_run(
            solutions=[sol],
            compiled_modified_sql_map=compiled_map,
            gcp_project="test-project",
            dry_run_original=None,
        )

        assert sol.dry_run_modified is not None
        assert sol.dry_run_modified["valid"] is False

    @patch("governor_core.solutions.generator.get_settings")
    @patch("governor_core.solutions.generator.dry_run_query")
    def test_verified_savings_calculation(self, mock_dry_run, mock_settings):
        """When both dry-runs succeed, verified savings should be correct."""
        mock_settings.return_value = MagicMock(
            dry_run_validation_enabled=True,
        )
        mock_dry_run.return_value = _FakeDryRunResult(
            valid=True,
            total_bytes_processed=500_000_000,
            estimated_cost_usd=3.13,
        )

        sol = SolutionData(
            resolution_category="dbt_project_change",
            explanation="Optimize query",
            risk_level="low",
            risk_justification="Safe change",
            file_path="models/staging/stg_orders.sql",
        )

        dry_run_original = {
            "valid": True,
            "total_bytes_processed": 1_000_000_000,
            "estimated_cost_usd": 6.25,
        }

        generator = SolutionGenerator(llm_provider=MagicMock(), github_client=None)
        compiled_map = {"models/staging/stg_orders.sql": "SELECT id FROM `p.d.table`"}

        generator._post_generation_dry_run(
            solutions=[sol],
            compiled_modified_sql_map=compiled_map,
            gcp_project="test-project",
            dry_run_original=dry_run_original,
        )

        # Savings = original cost - modified cost = 6.25 - 3.13 = 3.12
        assert sol.dry_run_original is not None
        assert sol.dry_run_original["estimated_cost_usd"] == 6.25
        assert sol.dry_run_modified["estimated_cost_usd"] == 3.13

    @patch("governor_core.solutions.generator.get_settings")
    def test_post_dry_run_skipped_when_disabled(self, mock_settings):
        """Should not modify solutions when dry_run_validation_enabled is False."""
        mock_settings.return_value = MagicMock(
            dry_run_validation_enabled=False,
        )

        sol = SolutionData(
            resolution_category="dbt_project_change",
            explanation="Optimize",
            risk_level="low",
            risk_justification="Safe",
            file_path="models/stg.sql",
        )

        generator = SolutionGenerator(llm_provider=MagicMock(), github_client=None)
        generator._post_generation_dry_run(
            solutions=[sol],
            compiled_modified_sql_map={"models/stg.sql": "SELECT 1"},
            gcp_project="test-project",
            dry_run_original=None,
        )

        assert sol.dry_run_original is None
        assert sol.dry_run_modified is None

    @patch("governor_core.solutions.generator.get_settings")
    def test_post_dry_run_skipped_when_no_compiled_map(self, mock_settings):
        """Should not modify solutions when compiled_modified_sql_map is empty."""
        mock_settings.return_value = MagicMock(
            dry_run_validation_enabled=True,
        )

        sol = SolutionData(
            resolution_category="dbt_project_change",
            explanation="Optimize",
            risk_level="low",
            risk_justification="Safe",
            file_path="models/stg.sql",
        )

        generator = SolutionGenerator(llm_provider=MagicMock(), github_client=None)
        generator._post_generation_dry_run(
            solutions=[sol],
            compiled_modified_sql_map={},
            gcp_project="test-project",
            dry_run_original=None,
        )

        assert sol.dry_run_modified is None

    @patch("governor_core.solutions.generator.get_settings")
    @patch("governor_core.solutions.generator.dry_run_query")
    def test_post_dry_run_skips_project_config_changes(
        self, mock_dry_run, mock_settings
    ):
        """Config-only changes should not produce optimized dry-run results."""
        mock_settings.return_value = MagicMock(
            dry_run_validation_enabled=True,
        )

        sol = SolutionData(
            resolution_category="dbt_project_change",
            explanation="Add cluster_by",
            risk_level="low",
            risk_justification="Safe config change",
            file_path="models/stg.sql",
            change_type="project_config_change",
        )

        generator = SolutionGenerator(llm_provider=MagicMock(), github_client=None)
        generator._post_generation_dry_run(
            solutions=[sol],
            compiled_modified_sql_map={"models/stg.sql": "cluster_by=['id']"},
            gcp_project="test-project",
            dry_run_original={"valid": True, "estimated_cost_usd": 6.25},
        )

        assert sol.dry_run_original is not None
        assert sol.dry_run_modified is None
        mock_dry_run.assert_not_called()

    @patch("governor_core.solutions.generator.get_settings")
    @patch("governor_core.solutions.generator.dry_run_query")
    def test_post_dry_run_skips_structural_config_only_change_even_if_mislabeled(
        self, mock_dry_run, mock_settings
    ):
        mock_settings.return_value = MagicMock(
            dry_run_validation_enabled=True,
        )

        sol = SolutionData(
            resolution_category="dbt_project_change",
            explanation="Add partitioning",
            risk_level="low",
            risk_justification="Safe config change",
            file_path="models/stg.sql",
            change_type="sql_change",
            before_content=(
                "{{ config(materialized='table') }}\n"
                "select * from {{ source('pkg', 'table') }}\n"
            ),
            after_content=(
                "{{ config(materialized='table', cluster_by=['id']) }}\n"
                "select * from {{ source('pkg', 'table') }}\n"
            ),
        )

        generator = SolutionGenerator(llm_provider=MagicMock(), github_client=None)
        generator._post_generation_dry_run(
            solutions=[sol],
            compiled_modified_sql_map={"models/stg.sql": "select * from `p.d.table`"},
            gcp_project="test-project",
            dry_run_original={"valid": True, "estimated_cost_usd": 6.25},
        )

        assert sol.dry_run_modified is None
        mock_dry_run.assert_not_called()

    @patch("governor_core.solutions.generator.get_settings")
    @patch("governor_core.solutions.generator.dry_run_query")
    def test_post_dry_run_skips_sql_with_jinja_markers(
        self, mock_dry_run, mock_settings
    ):
        mock_settings.return_value = MagicMock(
            dry_run_validation_enabled=True,
        )

        sol = SolutionData(
            resolution_category="dbt_project_change",
            explanation="Optimize query",
            risk_level="low",
            risk_justification="Safe change",
            file_path="models/stg.sql",
            change_type="sql_change",
            before_content="select id from orders",
            after_content="select id, customer_id from orders",
        )

        generator = SolutionGenerator(llm_provider=MagicMock(), github_client=None)
        generator._post_generation_dry_run(
            solutions=[sol],
            compiled_modified_sql_map={
                "models/stg.sql": "select * from {{ source('pkg', 'table') }}"
            },
            gcp_project="test-project",
            dry_run_original=None,
        )

        assert sol.dry_run_modified is None
        mock_dry_run.assert_not_called()


def test_extract_dataset_name_uses_dataset_segment():
    assert _extract_dataset_name("project.analytics.fact_orders") == "analytics"
    assert _extract_dataset_name("analytics.fact_orders") == "analytics"
    assert _extract_dataset_name("`project.analytics.fact_orders`") == "analytics"
    assert _extract_dataset_name("fact_orders") == ""


def test_parse_dbt_config_literal_handles_python_style_literals():
    assert _parse_dbt_config_literal(
        "{'field': 'event_ts', 'data_type': 'timestamp'}"
    ) == {
        "field": "event_ts",
        "data_type": "timestamp",
    }
    assert _parse_dbt_config_literal("['customer_id', 'order_id']") == [
        "customer_id",
        "order_id",
    ]


def test_solution_is_config_only_change_detects_unchanged_sql_body():
    solution = SolutionData(
        resolution_category="dbt_project_change",
        explanation="Add clustering",
        risk_level="low",
        risk_justification="Safe",
        file_path="models/stg.sql",
        change_type="sql_change",
        before_content=(
            "{{ config(materialized='table') }}\n"
            "select * from {{ source('pkg', 'table') }}\n"
        ),
        after_content=(
            "{{ config(materialized='table', cluster_by=['customer_id']) }}\n"
            "select * from {{ source('pkg', 'table') }}\n"
        ),
    )

    assert solution_is_config_only_change(solution) is True


def test_solution_supports_optimized_dry_run_rejects_jinja_sql():
    solution = SolutionData(
        resolution_category="dbt_project_change",
        explanation="Optimize query",
        risk_level="low",
        risk_justification="Safe",
        file_path="models/stg.sql",
        change_type="sql_change",
        compiled_after_sql="select * from {{ source('pkg', 'table') }}",
    )

    assert solution_supports_optimized_dry_run(solution) is False
