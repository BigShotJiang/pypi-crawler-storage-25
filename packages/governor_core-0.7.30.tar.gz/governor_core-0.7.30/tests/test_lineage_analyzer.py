"""Unit tests for lineage-aware upstream model analysis (spec 051)."""

from types import SimpleNamespace


from governor_core.dbt.lineage_analyzer import (
    LineageResult,
    UpstreamCandidate,
    analyze_upstream,
)
from governor_core.solutions.templates import match_upstream_template


# ---------------------------------------------------------------------------
# Manifest fixtures
# ---------------------------------------------------------------------------


def _make_manifest(
    nodes: dict | None = None,
    project_name: str = "my_project",
) -> dict:
    """Build a minimal manifest dict."""
    return {
        "metadata": {"project_name": project_name},
        "nodes": nodes or {},
    }


def _make_node(
    name: str,
    unique_id: str | None = None,
    materialized: str = "table",
    package_name: str = "my_project",
    depends_on_nodes: list[str] | None = None,
    cluster_by: list[str] | None = None,
    partition_by: dict | None = None,
    columns: dict | None = None,
    original_file_path: str | None = None,
    compiled_code: str | None = None,
) -> dict:
    uid = unique_id or f"model.my_project.{name}"
    return {
        "name": name,
        "unique_id": uid,
        "resource_type": "model",
        "package_name": package_name,
        "original_file_path": original_file_path or f"models/{name}.sql",
        "config": {
            "materialized": materialized,
            **({"cluster_by": cluster_by} if cluster_by else {}),
            **({"partition_by": partition_by} if partition_by else {}),
        },
        "depends_on": {"nodes": depends_on_nodes or []},
        "columns": columns or {},
        **({"compiled_code": compiled_code} if compiled_code else {}),
    }


def _make_opportunity(
    opp_type: str = "join_explosion", model_name: str = "int_order_pairs"
):
    return SimpleNamespace(
        id="opp-1",
        opportunity_type=opp_type,
        evidence_snapshot={},
        dbt_model_name=model_name,
        affected_table=f"project.dataset.{model_name}",
    )


# ---------------------------------------------------------------------------
# Basic DAG traversal tests
# ---------------------------------------------------------------------------


class TestAnalyzeUpstream:
    """Test the analyze_upstream DAG traversal."""

    def test_finds_direct_upstream_materialized_model(self):
        """BFS should find a direct materialized upstream model."""
        nodes = {
            "model.my_project.stg_orders": _make_node(
                "stg_orders", materialized="table"
            ),
            "model.my_project.int_order_pairs": _make_node(
                "int_order_pairs",
                materialized="table",
                depends_on_nodes=["model.my_project.stg_orders"],
            ),
        }
        manifest = _make_manifest(nodes)

        compiled_sql = (
            "SELECT a.id, b.id "
            "FROM stg_orders a JOIN stg_orders b ON a.order_id = b.order_id"
        )

        result = analyze_upstream(
            manifest, "int_order_pairs", "join_explosion", compiled_sql=compiled_sql
        )

        assert len(result.candidates) >= 1
        assert result.candidates[0].name == "stg_orders"
        assert "order_id" in result.candidates[0].suggested_cluster_columns

    def test_skips_view_traverses_deeper(self):
        """If direct parent is a view, traverse deeper to find materialized ancestor."""
        nodes = {
            "model.my_project.stg_orders": _make_node(
                "stg_orders", materialized="table"
            ),
            "model.my_project.int_orders_view": _make_node(
                "int_orders_view",
                materialized="view",
                depends_on_nodes=["model.my_project.stg_orders"],
            ),
            "model.my_project.fct_orders": _make_node(
                "fct_orders",
                materialized="table",
                depends_on_nodes=["model.my_project.int_orders_view"],
            ),
        }
        manifest = _make_manifest(nodes)

        compiled_sql = (
            "SELECT o.id FROM int_orders_view o "
            "JOIN products p ON o.product_id = p.product_id"
        )

        result = analyze_upstream(
            manifest, "fct_orders", "join_explosion", compiled_sql=compiled_sql
        )

        # stg_orders should be found (skipping the view)
        names = [c.name for c in result.candidates]
        assert "stg_orders" in names
        # The view should be mentioned in analysis notes
        notes_text = " ".join(result.analysis_notes)
        assert "int_orders_view" in notes_text

    def test_skips_ephemeral_traverses_deeper(self):
        """Ephemeral models should be traversed through."""
        nodes = {
            "model.my_project.stg_raw": _make_node("stg_raw", materialized="table"),
            "model.my_project.int_ephemeral": _make_node(
                "int_ephemeral",
                materialized="ephemeral",
                depends_on_nodes=["model.my_project.stg_raw"],
            ),
            "model.my_project.fct_report": _make_node(
                "fct_report",
                materialized="table",
                depends_on_nodes=["model.my_project.int_ephemeral"],
            ),
        }
        manifest = _make_manifest(nodes)

        compiled_sql = "SELECT region, SUM(amount) FROM stg_raw GROUP BY region"

        result = analyze_upstream(
            manifest, "fct_report", "shuffle_spill", compiled_sql=compiled_sql
        )

        names = [c.name for c in result.candidates]
        assert "stg_raw" in names

    def test_skips_external_packages(self):
        """Models from external packages should be skipped."""
        nodes = {
            "model.dbt_utils.generate_series": _make_node(
                "generate_series",
                unique_id="model.dbt_utils.generate_series",
                materialized="table",
                package_name="dbt_utils",
            ),
            "model.my_project.fct_events": _make_node(
                "fct_events",
                materialized="table",
                depends_on_nodes=["model.dbt_utils.generate_series"],
            ),
        }
        manifest = _make_manifest(nodes)

        result = analyze_upstream(
            manifest, "fct_events", "join_explosion", compiled_sql=None
        )

        assert len(result.candidates) == 0
        notes_text = " ".join(result.analysis_notes)
        assert "external package" in notes_text

    def test_model_not_found(self):
        """Should return empty result with a note when model is not in manifest."""
        manifest = _make_manifest({})

        result = analyze_upstream(manifest, "nonexistent_model", "join_explosion")

        assert len(result.candidates) == 0
        assert any("not found" in n for n in result.analysis_notes)

    def test_respects_max_depth(self):
        """Should not traverse beyond max_depth."""
        compiled_sql = "SELECT region, SUM(amount) FROM level3 GROUP BY region"
        nodes = {
            "model.my_project.level3": _make_node("level3", materialized="table"),
            "model.my_project.level2": _make_node(
                "level2",
                materialized="view",
                depends_on_nodes=["model.my_project.level3"],
            ),
            "model.my_project.level1": _make_node(
                "level1",
                materialized="view",
                depends_on_nodes=["model.my_project.level2"],
            ),
            "model.my_project.target": _make_node(
                "target",
                materialized="table",
                depends_on_nodes=["model.my_project.level1"],
            ),
        }
        manifest = _make_manifest(nodes)

        # With max_depth=2, should NOT reach level3 (depth 1=level1, depth 2=level2, depth 3=level3)
        result = analyze_upstream(
            manifest, "target", "shuffle_spill", compiled_sql=compiled_sql, max_depth=2
        )
        names = [c.name for c in result.candidates]
        assert "level3" not in names

        # With max_depth=3, should find level3
        result = analyze_upstream(
            manifest, "target", "shuffle_spill", compiled_sql=compiled_sql, max_depth=3
        )
        names = [c.name for c in result.candidates]
        assert "level3" in names

    def test_skips_already_fully_clustered(self):
        """If upstream already has cluster_by with all relevant columns, skip it."""
        nodes = {
            "model.my_project.stg_orders": _make_node(
                "stg_orders",
                materialized="table",
                cluster_by=["order_id"],
            ),
            "model.my_project.int_orders": _make_node(
                "int_orders",
                materialized="table",
                depends_on_nodes=["model.my_project.stg_orders"],
            ),
        }
        manifest = _make_manifest(nodes)

        compiled_sql = (
            "SELECT * FROM stg_orders a JOIN stg_orders b ON a.order_id = b.order_id"
        )

        result = analyze_upstream(
            manifest, "int_orders", "join_explosion", compiled_sql=compiled_sql
        )

        # stg_orders already has cluster_by=["order_id"] and the only join column is order_id
        assert len(result.candidates) == 0

    def test_suggests_missing_columns_only(self):
        """Should only suggest columns not already in cluster_by."""
        nodes = {
            "model.my_project.stg_orders": _make_node(
                "stg_orders",
                materialized="table",
                cluster_by=["customer_id"],
            ),
            "model.my_project.int_orders": _make_node(
                "int_orders",
                materialized="table",
                depends_on_nodes=["model.my_project.stg_orders"],
            ),
        }
        manifest = _make_manifest(nodes)

        compiled_sql = (
            "SELECT * FROM stg_orders a "
            "JOIN customers c ON a.customer_id = c.customer_id AND a.order_id = c.order_id"
        )

        result = analyze_upstream(
            manifest, "int_orders", "join_explosion", compiled_sql=compiled_sql
        )

        assert len(result.candidates) >= 1
        suggested = result.candidates[0].suggested_cluster_columns
        # customer_id already in cluster_by, only order_id should be suggested
        assert "order_id" in suggested
        assert "customer_id" not in suggested

    def test_respects_4_column_bigquery_limit(self):
        """Should not suggest more than 4 total cluster columns."""
        nodes = {
            "model.my_project.stg_orders": _make_node(
                "stg_orders",
                materialized="table",
                cluster_by=["col_a", "col_b", "col_c"],
            ),
            "model.my_project.int_orders": _make_node(
                "int_orders",
                materialized="table",
                depends_on_nodes=["model.my_project.stg_orders"],
            ),
        }
        manifest = _make_manifest(nodes)

        compiled_sql = (
            "SELECT * FROM stg_orders a "
            "JOIN x ON a.col_d = x.col_d AND a.col_e = x.col_e"
        )

        result = analyze_upstream(
            manifest, "int_orders", "join_explosion", compiled_sql=compiled_sql
        )

        if result.candidates:
            candidate = result.candidates[0]
            total = len(candidate.current_cluster_by or []) + len(
                candidate.suggested_cluster_columns
            )
            assert total <= 4

    def test_ranking_direct_deps_first(self):
        """Direct dependencies should rank higher than deeper ancestors."""
        nodes = {
            "model.my_project.stg_deep": _make_node("stg_deep", materialized="table"),
            "model.my_project.stg_direct": _make_node(
                "stg_direct",
                materialized="table",
                depends_on_nodes=["model.my_project.stg_deep"],
            ),
            "model.my_project.target": _make_node(
                "target",
                materialized="table",
                depends_on_nodes=[
                    "model.my_project.stg_direct",
                    "model.my_project.stg_deep",
                ],
            ),
        }
        manifest = _make_manifest(nodes)

        result = analyze_upstream(
            manifest, "target", "shuffle_spill", compiled_sql=None
        )

        if len(result.candidates) >= 2:
            # stg_direct and stg_deep are both direct deps here
            # Both should be found
            names = [c.name for c in result.candidates]
            assert "stg_direct" in names
            assert "stg_deep" in names

    def test_skips_non_model_refs(self):
        """Should skip source and seed references."""
        nodes = {
            "source.my_project.raw.orders": {
                "name": "orders",
                "unique_id": "source.my_project.raw.orders",
                "resource_type": "source",
                "package_name": "my_project",
                "config": {},
                "depends_on": {"nodes": []},
            },
            "model.my_project.stg_orders": _make_node(
                "stg_orders",
                materialized="table",
                depends_on_nodes=["source.my_project.raw.orders"],
            ),
        }
        manifest = _make_manifest(nodes)

        result = analyze_upstream(
            manifest, "stg_orders", "join_explosion", compiled_sql=None
        )

        # No candidates since the only upstream is a source, not a model
        assert len(result.candidates) == 0


# ---------------------------------------------------------------------------
# Column extraction tests
# ---------------------------------------------------------------------------


class TestExtractColumns:
    """Test column extraction from compiled SQL."""

    def test_extracts_join_columns(self):
        compiled_sql = (
            "SELECT a.id, b.name "
            "FROM orders a JOIN customers b ON a.customer_id = b.customer_id"
        )
        nodes = {
            "model.my_project.stg_orders": _make_node(
                "stg_orders", materialized="table"
            ),
            "model.my_project.target": _make_node(
                "target",
                materialized="table",
                depends_on_nodes=["model.my_project.stg_orders"],
            ),
        }
        manifest = _make_manifest(nodes)

        result = analyze_upstream(
            manifest, "target", "join_explosion", compiled_sql=compiled_sql
        )

        assert any("customer_id" in n for n in result.analysis_notes)

    def test_extracts_group_by_for_shuffle_spill(self):
        compiled_sql = "SELECT region, SUM(amount) FROM orders GROUP BY region"
        nodes = {
            "model.my_project.stg_orders": _make_node(
                "stg_orders", materialized="table"
            ),
            "model.my_project.target": _make_node(
                "target",
                materialized="table",
                depends_on_nodes=["model.my_project.stg_orders"],
            ),
        }
        manifest = _make_manifest(nodes)

        result = analyze_upstream(
            manifest, "target", "shuffle_spill", compiled_sql=compiled_sql
        )

        assert any("region" in n for n in result.analysis_notes)

    def test_no_compiled_sql(self):
        """Should handle None compiled SQL gracefully."""
        nodes = {
            "model.my_project.stg_orders": _make_node(
                "stg_orders", materialized="table"
            ),
            "model.my_project.target": _make_node(
                "target",
                materialized="table",
                depends_on_nodes=["model.my_project.stg_orders"],
            ),
        }
        manifest = _make_manifest(nodes)

        result = analyze_upstream(
            manifest, "target", "join_explosion", compiled_sql=None
        )

        # Should still work, just no column suggestions
        assert isinstance(result, LineageResult)


# ---------------------------------------------------------------------------
# Upstream template matching tests
# ---------------------------------------------------------------------------


class TestMatchUpstreamTemplate:
    """Test match_upstream_template() for upstream config changes."""

    def test_adds_cluster_by_to_unclustered_model(self):
        """Should insert cluster_by into a model with no existing clustering."""
        opp = _make_opportunity("join_explosion")
        candidate = UpstreamCandidate(
            name="stg_orders",
            unique_id="model.my_project.stg_orders",
            original_file_path="models/staging/stg_orders.sql",
            materialized="table",
            current_cluster_by=None,
            current_partition_by=None,
            suggested_cluster_columns=["order_id"],
            reason="Join key column for downstream join_explosion",
        )
        source_files = {
            "models/staging/stg_orders.sql": (
                "{{ config(\n"
                '    materialized="table"\n'
                ") }}\n\n"
                "SELECT id, order_id, customer_id\n"
                "FROM {{ ref('raw_orders') }}\n"
            ),
        }

        result = match_upstream_template(opp, candidate, source_files)

        assert result is not None
        assert result.template_id == "upstream_cluster_by"
        assert result.file_path == "models/staging/stg_orders.sql"
        assert "cluster_by" in result.after_content
        assert '"order_id"' in result.after_content
        assert "stg_orders" in result.explanation

    def test_merges_into_existing_cluster_by(self):
        """Should merge new columns into existing cluster_by."""
        opp = _make_opportunity("join_explosion")
        candidate = UpstreamCandidate(
            name="stg_orders",
            unique_id="model.my_project.stg_orders",
            original_file_path="models/staging/stg_orders.sql",
            materialized="table",
            current_cluster_by=["customer_id"],
            current_partition_by=None,
            suggested_cluster_columns=["order_id"],
            reason="Join key column",
        )
        source_files = {
            "models/staging/stg_orders.sql": (
                "{{ config(\n"
                '    materialized="table",\n'
                '    cluster_by=["customer_id"]\n'
                ") }}\n\n"
                "SELECT id, order_id, customer_id\n"
                "FROM {{ ref('raw_orders') }}\n"
            ),
        }

        result = match_upstream_template(opp, candidate, source_files)

        assert result is not None
        assert "customer_id" in result.after_content
        assert "order_id" in result.after_content

    def test_returns_none_when_all_columns_present(self):
        """Should return None if all suggested columns already in cluster_by."""
        opp = _make_opportunity("join_explosion")
        candidate = UpstreamCandidate(
            name="stg_orders",
            unique_id="model.my_project.stg_orders",
            original_file_path="models/staging/stg_orders.sql",
            materialized="table",
            current_cluster_by=["order_id"],
            current_partition_by=None,
            suggested_cluster_columns=["order_id"],
            reason="Already clustered",
        )
        source_files = {
            "models/staging/stg_orders.sql": (
                "{{ config(\n"
                '    materialized="table",\n'
                '    cluster_by=["order_id"]\n'
                ") }}\n\n"
                "SELECT id, order_id FROM source\n"
            ),
        }

        result = match_upstream_template(opp, candidate, source_files)

        assert result is None

    def test_returns_none_when_file_missing(self):
        """Should return None if upstream file not in source files."""
        opp = _make_opportunity("join_explosion")
        candidate = UpstreamCandidate(
            name="stg_orders",
            unique_id="model.my_project.stg_orders",
            original_file_path="models/staging/stg_orders.sql",
            materialized="table",
            current_cluster_by=None,
            current_partition_by=None,
            suggested_cluster_columns=["order_id"],
            reason="",
        )

        result = match_upstream_template(opp, candidate, {})

        assert result is None

    def test_returns_none_when_no_suggested_columns(self):
        """Should return None if candidate has no suggested columns."""
        opp = _make_opportunity("join_explosion")
        candidate = UpstreamCandidate(
            name="stg_orders",
            unique_id="model.my_project.stg_orders",
            original_file_path="models/staging/stg_orders.sql",
            materialized="table",
            current_cluster_by=None,
            current_partition_by=None,
            suggested_cluster_columns=[],
            reason="",
        )
        source_files = {
            "models/staging/stg_orders.sql": (
                '{{ config(materialized="table") }}\nSELECT 1\n'
            ),
        }

        result = match_upstream_template(opp, candidate, source_files)

        assert result is None

    def test_template_result_fields(self):
        """Verify TemplateResult has correct metadata fields."""
        opp = _make_opportunity("shuffle_spill", model_name="fct_daily_revenue")
        candidate = UpstreamCandidate(
            name="int_revenue",
            unique_id="model.my_project.int_revenue",
            original_file_path="models/int/int_revenue.sql",
            materialized="incremental",
            current_cluster_by=None,
            current_partition_by=None,
            suggested_cluster_columns=["product_id", "region"],
            reason="Shuffle spill fix",
        )
        source_files = {
            "models/int/int_revenue.sql": (
                "{{ config(\n"
                '    materialized="incremental"\n'
                ") }}\n\n"
                "SELECT product_id, region, SUM(amount) as total\n"
                "FROM {{ ref('raw_sales') }}\n"
                "GROUP BY 1, 2\n"
            ),
        }

        result = match_upstream_template(opp, candidate, source_files)

        assert result is not None
        assert result.change_type == "project_config_change"
        assert result.parameters["columns"] == ["product_id", "region"]
        assert result.parameters["upstream_model"] == "int_revenue"
        assert result.parameters["affected_model"] == "fct_daily_revenue"
        assert "shuffle_spill" in result.explanation
        assert result.rollback  # Has rollback instructions

    def test_template_result_includes_column_quality_metadata(self):
        """Upstream template should preserve quality details for auditability."""
        opp = _make_opportunity("join_explosion", model_name="dim_stations_unified")
        candidate = UpstreamCandidate(
            name="stg_gsod_stations",
            unique_id="model.my_project.stg_gsod_stations",
            original_file_path="models/staging/stg_gsod_stations.sql",
            materialized="table",
            current_cluster_by=None,
            current_partition_by=None,
            suggested_cluster_columns=["country"],
            reason="Join key column",
            column_quality={
                "country": {
                    "classification": "good",
                    "reason": "good cardinality and low NULL ratio",
                },
                "climate_zone": {
                    "classification": "poor",
                    "reason": "top value 'unknown' covers 91% of rows",
                },
            },
        )
        source_files = {
            "models/staging/stg_gsod_stations.sql": (
                '{{ config(materialized="table") }}\n'
                "SELECT country, climate_zone FROM {{ ref('raw_stations') }}\n"
            ),
        }

        result = match_upstream_template(opp, candidate, source_files)

        assert result is not None
        assert (
            result.parameters["column_quality"]["climate_zone"]["classification"]
            == "poor"
        )
        assert result.parameters["excluded_columns"] == ["climate_zone"]
        assert "Excluded poor-quality join keys" in result.explanation


# ---------------------------------------------------------------------------
# Integration: analyze_upstream → match_upstream_template
# ---------------------------------------------------------------------------


class TestEndToEnd:
    """End-to-end: lineage analysis produces candidates that templates can apply."""

    def test_join_explosion_upstream_fix(self):
        """Full flow: detect join_explosion → find upstream → apply cluster_by."""
        nodes = {
            "model.my_project.stg_orders": _make_node(
                "stg_orders",
                materialized="table",
                original_file_path="models/staging/stg_orders.sql",
            ),
            "model.my_project.int_order_pairs": _make_node(
                "int_order_pairs",
                materialized="table",
                depends_on_nodes=["model.my_project.stg_orders"],
            ),
        }
        manifest = _make_manifest(nodes)

        compiled_sql = (
            "SELECT a.id, b.id "
            "FROM `project`.`dataset`.`stg_orders` a "
            "JOIN `project`.`dataset`.`stg_orders` b "
            "ON a.order_id = b.order_id"
        )

        # Step 1: Lineage analysis
        lineage = analyze_upstream(
            manifest, "int_order_pairs", "join_explosion", compiled_sql=compiled_sql
        )
        assert len(lineage.candidates) >= 1

        # Step 2: Apply template to first candidate
        candidate = lineage.candidates[0]
        source_files = {
            candidate.original_file_path: (
                "{{ config(\n"
                '    materialized="table"\n'
                ") }}\n\n"
                "SELECT id, order_id, customer_id\n"
                "FROM {{ ref('raw_orders') }}\n"
            ),
        }
        opp = _make_opportunity("join_explosion", "int_order_pairs")
        result = match_upstream_template(opp, candidate, source_files)

        assert result is not None
        assert "cluster_by" in result.after_content
        assert "order_id" in result.after_content


# ---------------------------------------------------------------------------
# Spec 131: upstream partition_by proposal + template
# ---------------------------------------------------------------------------

from governor_core.solutions.templates import match_upstream_partition_template  # noqa: E402


def _partition_pruning_manifest(
    upstream_columns: dict[str, str] | None = None,
    include_downstream: bool = True,
) -> dict:
    """Minimal manifest: upstream `stg_events` + downstream `mart_events`.

    ``upstream_columns`` maps column name → data_type. Defaults to a simple
    DATE column so the happy path fires.
    """
    columns = upstream_columns if upstream_columns is not None else {
        "event_date": "DATE",
        "event_type": "STRING",
    }
    stg_cols = {
        name: {"name": name, "data_type": dtype}
        for name, dtype in columns.items()
    }
    manifest = {
        "metadata": {"project_name": "my_project"},
        "nodes": {
            "model.my_project.stg_events": {
                "name": "stg_events",
                "unique_id": "model.my_project.stg_events",
                "original_file_path": "models/staging/stg_events.sql",
                "package_name": "my_project",
                "config": {"materialized": "table"},
                "columns": stg_cols,
                "depends_on": {"nodes": []},
            },
        },
    }
    if include_downstream:
        manifest["nodes"]["model.my_project.mart_events"] = {
            "name": "mart_events",
            "unique_id": "model.my_project.mart_events",
            "original_file_path": "models/marts/mart_events.sql",
            "package_name": "my_project",
            "config": {"materialized": "table"},
            "depends_on": {"nodes": ["model.my_project.stg_events"]},
        }
    return manifest


_DOWNSTREAM_SQL_WITH_DATE_FILTER = (
    "SELECT event_date, COUNT(*) "
    "FROM `project`.`dataset`.`stg_events` "
    "WHERE event_date >= '2026-01-01' "
    "GROUP BY event_date"
)


class TestAnalyzerPartitionProposal:
    def test_date_column_with_name_pattern_and_downstream_usage_proposes_partition(self):
        manifest = _partition_pruning_manifest()
        result = analyze_upstream(
            manifest,
            "mart_events",
            "partition_pruning",
            compiled_sql=_DOWNSTREAM_SQL_WITH_DATE_FILTER,
        )
        assert result.candidates, "expected a candidate for stg_events"
        candidate = result.candidates[0]
        assert candidate.name == "stg_events"
        assert candidate.suggested_partition_by == {
            "field": "event_date",
            "data_type": "date",
        }
        assert candidate.partition_reason
        assert "event_date" in candidate.partition_reason

    def test_timestamp_column_proposed_with_timestamp_data_type(self):
        manifest = _partition_pruning_manifest(
            upstream_columns={"created_at": "TIMESTAMP", "user_id": "STRING"}
        )
        compiled_sql = (
            "SELECT user_id, COUNT(*) "
            "FROM `project`.`dataset`.`stg_events` "
            "WHERE created_at > TIMESTAMP '2026-01-01' "
            "GROUP BY user_id"
        )
        result = analyze_upstream(
            manifest, "mart_events", "partition_pruning", compiled_sql=compiled_sql
        )
        assert result.candidates
        assert result.candidates[0].suggested_partition_by == {
            "field": "created_at",
            "data_type": "timestamp",
        }

    def test_downstream_does_not_filter_the_column_no_proposal(self):
        """Abstention = no candidate emitted. Keeps analyzer output clean."""
        manifest = _partition_pruning_manifest()
        compiled_sql_no_filter = (
            "SELECT event_type, COUNT(*) "
            "FROM `project`.`dataset`.`stg_events` "
            "GROUP BY event_type"
        )
        result = analyze_upstream(
            manifest,
            "mart_events",
            "partition_pruning",
            compiled_sql=compiled_sql_no_filter,
        )
        assert result.candidates == []

    def test_no_temporal_column_abstains(self):
        manifest = _partition_pruning_manifest(
            upstream_columns={"user_id": "STRING", "display_name": "STRING"}
        )
        compiled_sql = (
            "SELECT * FROM `project`.`dataset`.`stg_events` WHERE user_id = 'abc'"
        )
        result = analyze_upstream(
            manifest, "mart_events", "partition_pruning", compiled_sql=compiled_sql
        )
        assert result.candidates == []

    def test_int64_without_bucket_pattern_abstains(self):
        manifest = _partition_pruning_manifest(
            upstream_columns={"row_count": "INT64"}
        )
        compiled_sql = (
            "SELECT * FROM `project`.`dataset`.`stg_events` WHERE row_count > 0"
        )
        result = analyze_upstream(
            manifest, "mart_events", "partition_pruning", compiled_sql=compiled_sql
        )
        assert result.candidates == []

    def test_int64_with_bucket_pattern_emits_placeholder(self):
        manifest = _partition_pruning_manifest(
            upstream_columns={"bucket_id": "INT64", "payload": "STRING"}
        )
        compiled_sql = (
            "SELECT payload FROM `project`.`dataset`.`stg_events` "
            "WHERE bucket_id = 42"
        )
        result = analyze_upstream(
            manifest, "mart_events", "partition_pruning", compiled_sql=compiled_sql
        )
        assert result.candidates
        proposal = result.candidates[0].suggested_partition_by
        assert proposal is not None
        assert proposal["field"] == "bucket_id"
        assert proposal["data_type"] == "int64"
        assert proposal.get("placeholder") is True
        assert "range" in proposal
        assert "manual" in result.candidates[0].partition_reason.lower()

    def test_already_partitioned_upstream_leaves_suggestion_none(self):
        manifest = _partition_pruning_manifest()
        manifest["nodes"]["model.my_project.stg_events"]["config"]["partition_by"] = {
            "field": "event_date",
            "data_type": "date",
        }
        result = analyze_upstream(
            manifest,
            "mart_events",
            "partition_pruning",
            compiled_sql=_DOWNSTREAM_SQL_WITH_DATE_FILTER,
        )
        assert result.candidates
        # current_partition_by populated → analyzer refuses to propose over it
        assert result.candidates[0].current_partition_by is not None
        assert result.candidates[0].suggested_partition_by is None

    def test_ambiguous_multiple_date_columns_chooses_downstream_usage(self):
        manifest = _partition_pruning_manifest(
            upstream_columns={
                "created_at": "TIMESTAMP",
                "event_date": "DATE",
                "payload": "STRING",
            }
        )
        # Downstream filters only on event_date.
        result = analyze_upstream(
            manifest,
            "mart_events",
            "partition_pruning",
            compiled_sql=_DOWNSTREAM_SQL_WITH_DATE_FILTER,
        )
        assert result.candidates
        proposal = result.candidates[0].suggested_partition_by
        assert proposal is not None
        assert proposal["field"] == "event_date"


class TestMatchUpstreamPartitionTemplate:
    def _source_files_unpartitioned(self):
        return {
            "models/staging/stg_events.sql": (
                '{{ config(\n    materialized="table"\n) }}\n\n'
                "SELECT event_date, event_type FROM {{ source('raw', 'events') }}\n"
            ),
        }

    def _candidate(self, **overrides):
        base = UpstreamCandidate(
            name="stg_events",
            unique_id="model.my_project.stg_events",
            original_file_path="models/staging/stg_events.sql",
            materialized="table",
            current_cluster_by=None,
            current_partition_by=None,
            suggested_cluster_columns=[],
            reason="",
            suggested_partition_by={"field": "event_date", "data_type": "date"},
            partition_reason="event_date DATE filtered downstream.",
        )
        for k, v in overrides.items():
            setattr(base, k, v)
        return base

    def test_adds_partition_by_to_unpartitioned_model(self):
        opp = _make_opportunity("partition_pruning", "mart_events")
        candidate = self._candidate()
        result = match_upstream_partition_template(
            opp, candidate, self._source_files_unpartitioned()
        )
        assert result is not None
        assert result.template_id == "upstream_partition_by"
        assert result.change_type == "project_config_change"
        assert "dbt_config_change" in result.policy_tags
        assert "partition_by" in result.after_content
        assert '"field": "event_date"' in result.after_content
        assert '"data_type": "date"' in result.after_content

    def test_refuses_when_model_already_partitioned(self):
        opp = _make_opportunity("partition_pruning", "mart_events")
        candidate = self._candidate(
            current_partition_by={"field": "x", "data_type": "date"}
        )
        result = match_upstream_partition_template(
            opp, candidate, self._source_files_unpartitioned()
        )
        assert result is None

    def test_refuses_when_suggested_partition_by_is_none(self):
        opp = _make_opportunity("partition_pruning", "mart_events")
        candidate = self._candidate(suggested_partition_by=None, partition_reason=None)
        result = match_upstream_partition_template(
            opp, candidate, self._source_files_unpartitioned()
        )
        assert result is None

    def test_refuses_when_source_file_missing(self):
        opp = _make_opportunity("partition_pruning", "mart_events")
        candidate = self._candidate()
        result = match_upstream_partition_template(opp, candidate, {})
        assert result is None

    def test_placeholder_proposal_carries_manual_required_flag(self):
        opp = _make_opportunity("partition_pruning", "mart_events")
        candidate = self._candidate(
            suggested_partition_by={
                "field": "bucket_id",
                "data_type": "int64",
                "placeholder": True,
                "range": {"start": "TODO", "end": "TODO", "interval": "TODO"},
            }
        )
        source_files = {
            "models/staging/stg_events.sql": (
                '{{ config(\n    materialized="table"\n) }}\n\n'
                "SELECT bucket_id, payload FROM {{ source('raw', 'events') }}\n"
            ),
        }
        result = match_upstream_partition_template(opp, candidate, source_files)
        assert result is not None
        assert result.parameters.get("manual_required") is True
        assert "TODO" in result.after_content
