"""Unit tests for shadow diff computation."""

from __future__ import annotations

from decimal import Decimal

from governor_core.shadow.diff import ModelMetric, compute_deltas


def _m(name, bytes_=1_000_000, slot_ms=5_000, rows=1_000, error=None):
    return ModelMetric(
        model_name=name,
        bytes_processed=bytes_,
        slot_ms=slot_ms,
        row_count=rows,
        error_type=error,
    )


def test_happy_path_savings():
    baseline = [_m("a", bytes_=10_000_000), _m("b", bytes_=20_000_000)]
    shadow = [_m("a", bytes_=6_000_000), _m("b", bytes_=14_000_000)]
    d = compute_deltas(baseline, shadow)
    assert d.total_baseline_bytes == 30_000_000
    assert d.total_shadow_bytes == 20_000_000
    assert d.bytes_delta_pct is not None
    assert d.bytes_delta_pct < 0
    assert d.cost_delta_usd < 0
    assert not d.any_row_count_mismatch
    assert not d.regressed_models


def test_row_count_mismatch_flagged():
    baseline = [_m("a", rows=1_000)]
    shadow = [_m("a", rows=950)]
    d = compute_deltas(baseline, shadow)
    assert d.any_row_count_mismatch
    assert d.mismatched_models == ["a"]


def test_row_count_parity_waived():
    baseline = [_m("a", rows=1_000)]
    shadow = [_m("a", rows=950)]
    d = compute_deltas(baseline, shadow, parity_waived_models={"a"})
    assert not d.any_row_count_mismatch


def test_regression_flagged_per_model():
    baseline = [_m("a", bytes_=1_000), _m("b", bytes_=100)]
    shadow = [_m("a", bytes_=500), _m("b", bytes_=200)]  # b regressed
    d = compute_deltas(baseline, shadow)
    assert d.regressed_models == ["b"]


def test_shadow_only_error_flagged():
    baseline = [_m("a")]
    shadow = [_m("a", error="SyntaxError")]
    d = compute_deltas(baseline, shadow)
    assert d.errored_in_shadow_only == ["a"]


def test_model_in_shadow_only():
    baseline = []
    shadow = [_m("a")]
    d = compute_deltas(baseline, shadow)
    assert len(d.per_model) == 1


def test_bytes_delta_pct_on_zero_baseline():
    baseline = [_m("a", bytes_=0)]
    shadow = [_m("a", bytes_=1_000)]
    d = compute_deltas(baseline, shadow)
    assert d.bytes_delta_pct is None
