"""
Unit tests for ShuffleSpillRule.

Tests shuffle spill detection from BigQuery performance_insights.
"""

from decimal import Decimal
from unittest.mock import MagicMock


from governor_core.opportunities.rules.shuffle_spill import ShuffleSpillRule


class TestShuffleSpillRule:
    """Tests for shuffle spill detection."""

    def test_rule_type(self):
        """Test rule type identifier."""
        rule = ShuffleSpillRule()
        assert rule.rule_type == "shuffle_spill"

    def test_default_thresholds(self):
        """Test default threshold configuration."""
        rule = ShuffleSpillRule()
        thresholds = rule.default_thresholds

        assert "min_job_cost_usd" in thresholds
        assert thresholds["min_job_cost_usd"] == Decimal("0")

    def test_detect_with_shuffle_spill(self):
        """Test detection of shuffle spill signal."""
        rule = ShuffleSpillRule()

        # Create job with shuffle spill signal
        job = MagicMock()
        job.destination_table = "project.dataset.test_table"
        job.total_cost = Decimal("1.50")
        job.total_bytes_processed = 1024 * 1024 * 1024  # 1GB
        job.total_slot_ms = 500000
        job.job_id = "job-123"
        job.performance_insights = {
            "stage_performance_standalone_insights": [
                {
                    "stage_id": 3,
                    "slot_contention": False,
                    "insufficient_shuffle_quota": True,
                }
            ]
        }

        candidates = rule.detect([job], None, rule.default_thresholds)

        assert len(candidates) == 1
        candidate = candidates[0]
        assert candidate.opportunity_type == "shuffle_spill"
        assert candidate.affected_table == "project.dataset.test_table"
        assert candidate.evidence_snapshot["insufficient_shuffle_quota"] is True
        assert candidate.confidence == 1.0

    def test_detect_no_shuffle_spill(self):
        """Test no detection when signal is false."""
        rule = ShuffleSpillRule()

        job = MagicMock()
        job.destination_table = "project.dataset.test_table"
        job.total_cost = Decimal("1.50")
        job.total_bytes_processed = 1024 * 1024 * 1024
        job.total_slot_ms = 500000
        job.job_id = "job-123"
        job.performance_insights = {
            "stage_performance_standalone_insights": [
                {
                    "stage_id": 3,
                    "slot_contention": False,
                    "insufficient_shuffle_quota": False,
                }
            ]
        }

        candidates = rule.detect([job], None, rule.default_thresholds)
        assert len(candidates) == 0

    def test_detect_ignores_null_cost_jobs(self):
        """Test that jobs with null cost are ignored."""
        rule = ShuffleSpillRule()

        job = MagicMock()
        job.destination_table = "project.dataset.test_table"
        job.total_cost = None  # No cost data
        job.total_bytes_processed = 1024 * 1024
        job.total_slot_ms = 1000
        job.job_id = "job-123"
        job.performance_insights = {
            "stage_performance_standalone_insights": [
                {"stage_id": 1, "insufficient_shuffle_quota": True}
            ]
        }

        candidates = rule.detect([job], None, rule.default_thresholds)
        assert len(candidates) == 0

    def test_detect_ignores_jobs_without_destination(self):
        """Test that jobs without destination table are ignored."""
        rule = ShuffleSpillRule()

        job = MagicMock()
        job.destination_table = None  # No destination
        job.total_cost = Decimal("1.50")
        job.job_id = "job-123"
        job.performance_insights = {
            "stage_performance_standalone_insights": [
                {"stage_id": 1, "insufficient_shuffle_quota": True}
            ]
        }

        candidates = rule.detect([job], None, rule.default_thresholds)
        assert len(candidates) == 0

    def test_detect_groups_by_table(self):
        """Test that multiple jobs for same table create one opportunity."""
        rule = ShuffleSpillRule()

        # Two jobs for same table
        job1 = MagicMock()
        job1.destination_table = "project.dataset.test_table"
        job1.total_cost = Decimal("1.00")
        job1.total_bytes_processed = 1024 * 1024 * 1024
        job1.total_slot_ms = 300000
        job1.job_id = "job-1"
        job1.performance_insights = {
            "stage_performance_standalone_insights": [
                {"stage_id": 1, "insufficient_shuffle_quota": True}
            ]
        }

        job2 = MagicMock()
        job2.destination_table = "project.dataset.test_table"
        job2.total_cost = Decimal("2.00")
        job2.total_bytes_processed = 2 * 1024 * 1024 * 1024
        job2.total_slot_ms = 600000
        job2.job_id = "job-2"
        job2.performance_insights = {
            "stage_performance_standalone_insights": [
                {"stage_id": 2, "insufficient_shuffle_quota": True}
            ]
        }

        candidates = rule.detect([job1, job2], None, rule.default_thresholds)

        assert len(candidates) == 1
        candidate = candidates[0]
        assert candidate.affected_table == "project.dataset.test_table"
        assert len(candidate.related_job_ids) == 2
        # Cost should be aggregated
        assert float(candidate.current_cost_estimate) == 3.0

    def test_explanation_is_actionable(self):
        """Test that explanation includes actionable guidance."""
        rule = ShuffleSpillRule()

        job = MagicMock()
        job.destination_table = "project.dataset.test_table"
        job.total_cost = Decimal("1.50")
        job.total_bytes_processed = 1024 * 1024 * 1024
        job.total_slot_ms = 500000
        job.job_id = "job-123"
        job.performance_insights = {
            "stage_performance_standalone_insights": [
                {"stage_id": 3, "insufficient_shuffle_quota": True}
            ]
        }

        candidates = rule.detect([job], None, rule.default_thresholds)

        assert len(candidates) == 1
        explanation = candidates[0].explanation

        # Check for actionable content
        assert "shuffle spill" in explanation.lower()
        assert "Consider:" in explanation
        assert (
            "reducing data" in explanation.lower() or "filters" in explanation.lower()
        )

    def test_correlates_dbt_model(self):
        """Test dbt model correlation when manifest provided."""
        rule = ShuffleSpillRule()

        job = MagicMock()
        job.destination_table = "myproject.analytics.test_table"
        job.total_cost = Decimal("1.50")
        job.total_bytes_processed = 1024 * 1024 * 1024
        job.total_slot_ms = 500000
        job.job_id = "job-123"
        job.performance_insights = {
            "stage_performance_standalone_insights": [
                {"stage_id": 3, "insufficient_shuffle_quota": True}
            ]
        }

        manifest = {
            "nodes": {
                "model.my_project.test_model": {
                    "name": "test_model",
                    "relation_name": "myproject.analytics.test_table",
                    "database": "myproject",
                    "schema": "analytics",
                    "identifier": "test_table",
                }
            }
        }

        candidates = rule.detect([job], manifest, rule.default_thresholds)

        assert len(candidates) == 1
        assert candidates[0].dbt_model_name == "test_model"
