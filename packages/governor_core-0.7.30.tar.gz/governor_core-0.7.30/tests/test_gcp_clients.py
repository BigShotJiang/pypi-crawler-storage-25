from __future__ import annotations

from unittest.mock import patch

import pytest

from governor_core.gcp.clients import GCPCredentialsError, get_resource_manager_client


def test_get_resource_manager_client_success():
    with patch("governor_core.gcp.clients.google.auth.default") as mock_default:
        mock_default.return_value = ("mock_creds", "mock_project")
        with patch("governor_core.gcp.clients.ProjectsClient") as mock_client_cls:
            client = get_resource_manager_client()
            mock_client_cls.assert_called_once_with(credentials="mock_creds")
            assert client == mock_client_cls.return_value


def test_get_resource_manager_client_missing_credentials():
    with patch("governor_core.gcp.clients.google.auth.default") as mock_default:
        from google.auth.exceptions import DefaultCredentialsError

        mock_default.side_effect = DefaultCredentialsError("no creds")
        with pytest.raises(GCPCredentialsError, match="GCP credentials not configured"):
            get_resource_manager_client()
