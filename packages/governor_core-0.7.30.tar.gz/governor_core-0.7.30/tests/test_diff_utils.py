"""Tests for diff utility (spec 008, T014)."""

from governor_core.utils.diff import generate_code_diff


class TestGenerateCodeDiff:
    def test_identical_content_returns_empty(self):
        result = generate_code_diff("SELECT 1", "SELECT 1")
        assert result == []

    def test_single_line_change(self):
        before = "SELECT * FROM orders"
        after = "SELECT id, status FROM orders"
        result = generate_code_diff(before, after)
        types = [r["type"] for r in result]
        assert "hunk" in types
        assert "delete" in types
        assert "add" in types

    def test_multi_line_change_with_context(self):
        before = "line1\nline2\nline3\nline4\nline5"
        after = "line1\nline2\nchanged3\nline4\nline5"
        result = generate_code_diff(before, after, context_lines=1)
        types = [r["type"] for r in result]
        assert "context" in types
        assert "delete" in types
        assert "add" in types

    def test_added_lines_only(self):
        before = "line1\nline2\n"
        after = "line1\nline2\nline3\nline4\n"
        result = generate_code_diff(before, after)
        add_lines = [r for r in result if r["type"] == "add"]
        assert len(add_lines) == 2

    def test_deleted_lines_only(self):
        before = "line1\nline2\nline3\n"
        after = "line1\n"
        result = generate_code_diff(before, after)
        delete_lines = [r for r in result if r["type"] == "delete"]
        assert len(delete_lines) == 2

    def test_empty_before_all_adds(self):
        result = generate_code_diff("", "new line 1\nnew line 2")
        add_lines = [r for r in result if r["type"] == "add"]
        assert len(add_lines) >= 2

    def test_hunk_headers_present(self):
        before = "a\nb\nc\nd\ne\nf\ng\nh"
        after = "a\nb\nX\nd\ne\nf\nY\nh"
        result = generate_code_diff(before, after, context_lines=1)
        hunk_lines = [r for r in result if r["type"] == "hunk"]
        assert len(hunk_lines) >= 1
        assert any("@@" in h["content"] for h in hunk_lines)

    def test_diff_content_stripped(self):
        before = "SELECT *\nFROM orders"
        after = "SELECT id\nFROM orders"
        result = generate_code_diff(before, after)
        # Content should not have leading +/- prefixes
        for line in result:
            if line["type"] in ("add", "delete", "context"):
                assert not line["content"].startswith("+")
                assert not line["content"].startswith("-")
