"""Unit tests for ContextBuilder in app/dbt/context_builder.py."""

from __future__ import annotations

from unittest.mock import MagicMock

from sqlalchemy.exc import SQLAlchemyError

from governor_core.dbt.context_builder import (
    _extract_downstream_dependents,
    _extract_job_samples,
    _extract_macro_summary,
    _extract_upstream_models,
    build_enriched_context,
)


# --- Fixtures ---


def _make_manifest(
    nodes: dict | None = None,
    macros: dict | None = None,
    child_map: dict | None = None,
    project_name: str = "my_project",
) -> dict:
    """Build a minimal manifest structure for testing."""
    return {
        "metadata": {"project_name": project_name},
        "nodes": nodes or {},
        "macros": macros or {},
        "child_map": child_map or {},
    }


def _make_node(
    name: str,
    unique_id: str | None = None,
    compiled_code: str | None = None,
    raw_code: str | None = None,
    materialized: str = "table",
    partition_by: dict | None = None,
    cluster_by: list[str] | None = None,
    depends_on_nodes: list[str] | None = None,
    columns: dict | None = None,
    package_name: str = "my_project",
) -> dict:
    """Build a minimal manifest node."""
    node = {
        "name": name,
        "unique_id": unique_id or f"model.{package_name}.{name}",
        "resource_type": "model",
        "package_name": package_name,
        "config": {
            "materialized": materialized,
        },
        "depends_on": {
            "nodes": depends_on_nodes or [],
            "macros": [],
        },
        "columns": columns or {},
    }
    if compiled_code:
        node["compiled_code"] = compiled_code
    if raw_code:
        node["raw_code"] = raw_code
    if partition_by:
        node["config"]["partition_by"] = partition_by
    if cluster_by:
        node["config"]["cluster_by"] = cluster_by
    return node


# --- T009: build_enriched_context tests ---


class TestBuildEnrichedContext:
    """Tests for build_enriched_context()."""

    def test_returns_empty_context_when_no_manifest_version_id(self):
        db = MagicMock()
        result = build_enriched_context(db, None, "model_name", "config_id", "project")
        assert result.compiled_sql is None
        assert result.upstream_models == []
        assert result.downstream_dependents == []

    def test_returns_empty_context_when_no_dbt_model_name(self):
        db = MagicMock()
        result = build_enriched_context(db, "mv_id", None, "config_id", "project")
        assert result.compiled_sql is None

    def test_returns_empty_context_when_manifest_not_found(self):
        db = MagicMock()
        db.query.return_value.filter.return_value.one_or_none.return_value = None
        result = build_enriched_context(
            db, "mv_id", "model_name", "config_id", "project"
        )
        assert result.compiled_sql is None

    def test_extracts_compiled_sql_from_manifest(self):
        """Should extract compiled_code from the matching manifest node."""
        target_node = _make_node(
            "stg_orders", compiled_code="SELECT * FROM `project.dataset.raw_orders`"
        )
        nodes = {target_node["unique_id"]: target_node}
        manifest = _make_manifest(nodes=nodes)

        mv = MagicMock()
        mv.content = manifest

        db = MagicMock()
        db.query.return_value.filter.return_value.one_or_none.return_value = mv

        result = build_enriched_context(db, "mv_id", "stg_orders", None, None)
        assert result.compiled_sql == "SELECT * FROM `project.dataset.raw_orders`"

    def test_model_not_found_returns_none_compiled_sql(self):
        """If target model isn't in the manifest, compiled_sql should be None."""
        nodes = {
            "model.proj.other": _make_node("other_model"),
        }
        manifest = _make_manifest(nodes=nodes)
        mv = MagicMock()
        mv.content = manifest

        db = MagicMock()
        db.query.return_value.filter.return_value.one_or_none.return_value = mv

        result = build_enriched_context(db, "mv_id", "stg_orders", None, None)
        assert result.compiled_sql is None


# --- T010: upstream/downstream extraction tests ---


class TestExtractUpstreamModels:
    """Tests for _extract_upstream_models()."""

    def test_extracts_direct_parents(self):
        """Should return only direct parents (1 level)."""
        parent_node = _make_node(
            "raw_orders",
            compiled_code="SELECT id FROM `raw.orders`",
            raw_code="SELECT id FROM {{ source('raw', 'orders') }}",
            materialized="view",
        )
        target_node = _make_node(
            "stg_orders",
            depends_on_nodes=["model.my_project.raw_orders"],
        )
        nodes = {
            "model.my_project.raw_orders": parent_node,
            "model.my_project.stg_orders": target_node,
        }
        manifest = _make_manifest(nodes=nodes)

        upstreams = _extract_upstream_models(nodes, target_node, manifest)
        assert len(upstreams) == 1
        assert upstreams[0].name == "raw_orders"
        assert upstreams[0].materialized == "view"
        assert upstreams[0].compiled_sql == "SELECT id FROM `raw.orders`"
        assert upstreams[0].raw_sql == "SELECT id FROM {{ source('raw', 'orders') }}"

    def test_skips_non_model_refs(self):
        """Should skip source/seed references in depends_on.nodes."""
        target_node = _make_node(
            "stg_orders",
            depends_on_nodes=["source.proj.raw.orders", "model.proj.dim_dates"],
        )
        dim_dates = _make_node("dim_dates", unique_id="model.proj.dim_dates")
        nodes = {
            "model.proj.stg_orders": target_node,
            "model.proj.dim_dates": dim_dates,
        }

        upstreams = _extract_upstream_models(
            nodes, target_node, _make_manifest(nodes=nodes)
        )
        assert len(upstreams) == 1
        assert upstreams[0].name == "dim_dates"

    def test_enforces_50kb_cap(self):
        """Should cap upstream SQL at 50KB total."""
        # Create a parent with very large SQL
        large_sql = "SELECT " + ", ".join([f"col_{i}" for i in range(5000)])
        parent_a = _make_node("parent_a", raw_code=large_sql, compiled_code=large_sql)
        parent_b = _make_node("parent_b", raw_code="SELECT 1", compiled_code="SELECT 1")

        target = _make_node(
            "target",
            depends_on_nodes=["model.my_project.parent_a", "model.my_project.parent_b"],
        )
        nodes = {
            "model.my_project.parent_a": parent_a,
            "model.my_project.parent_b": parent_b,
            "model.my_project.target": target,
        }

        upstreams = _extract_upstream_models(nodes, target, _make_manifest(nodes=nodes))
        # Should still include both models but second may have SQL omitted
        assert len(upstreams) >= 1

    def test_depth_limited_to_one_level(self):
        """Should NOT include grandparent models."""
        grandparent = _make_node("grandparent")
        parent = _make_node(
            "parent",
            depends_on_nodes=["model.my_project.grandparent"],
        )
        target = _make_node(
            "target",
            depends_on_nodes=["model.my_project.parent"],
        )
        nodes = {
            "model.my_project.grandparent": grandparent,
            "model.my_project.parent": parent,
            "model.my_project.target": target,
        }

        upstreams = _extract_upstream_models(nodes, target, _make_manifest(nodes=nodes))
        assert len(upstreams) == 1
        assert upstreams[0].name == "parent"

    def test_empty_depends_on(self):
        """Should return empty list when no upstream models."""
        target = _make_node("target", depends_on_nodes=[])
        nodes = {"model.my_project.target": target}
        upstreams = _extract_upstream_models(nodes, target, _make_manifest(nodes=nodes))
        assert upstreams == []


class TestExtractDownstreamDependents:
    """Tests for _extract_downstream_dependents()."""

    def test_finds_children_via_child_map(self):
        """Should find downstream models using manifest child_map."""
        target = _make_node("stg_orders")
        child_a = _make_node("fct_revenue", materialized="incremental")
        child_b = _make_node("rpt_daily_sales", materialized="table")

        nodes = {
            "model.my_project.stg_orders": target,
            "model.my_project.fct_revenue": child_a,
            "model.my_project.rpt_daily_sales": child_b,
        }
        child_map = {
            "model.my_project.stg_orders": [
                "model.my_project.fct_revenue",
                "model.my_project.rpt_daily_sales",
            ],
        }
        manifest = _make_manifest(nodes=nodes, child_map=child_map)

        dependents = _extract_downstream_dependents(nodes, target, manifest)
        assert len(dependents) == 2
        names = {d.name for d in dependents}
        assert "fct_revenue" in names
        assert "rpt_daily_sales" in names

    def test_returns_names_and_configs_only(self):
        """Should return only metadata, no SQL content."""
        target = _make_node("stg_orders")
        child = _make_node(
            "fct_revenue",
            materialized="incremental",
            partition_by={"field": "event_date", "data_type": "date"},
            cluster_by=["customer_id"],
            compiled_code="SELECT * FROM orders",
        )
        nodes = {
            "model.my_project.stg_orders": target,
            "model.my_project.fct_revenue": child,
        }
        child_map = {
            "model.my_project.stg_orders": ["model.my_project.fct_revenue"],
        }
        manifest = _make_manifest(nodes=nodes, child_map=child_map)

        dependents = _extract_downstream_dependents(nodes, target, manifest)
        assert len(dependents) == 1
        d = dependents[0]
        assert d.materialized == "incremental"
        assert d.partition_by == {"field": "event_date", "data_type": "date"}
        assert d.cluster_by == ["customer_id"]
        # DownstreamDependent should NOT have SQL attributes

    def test_fallback_to_scanning_depends_on(self):
        """When child_map is empty, should scan all nodes for reverse references."""
        target = _make_node("stg_orders")
        child = _make_node(
            "fct_revenue",
            depends_on_nodes=["model.my_project.stg_orders"],
        )
        nodes = {
            "model.my_project.stg_orders": target,
            "model.my_project.fct_revenue": child,
        }
        manifest = _make_manifest(nodes=nodes)  # no child_map

        dependents = _extract_downstream_dependents(nodes, target, manifest)
        assert len(dependents) == 1
        assert dependents[0].name == "fct_revenue"


# --- T011: job samples extraction tests ---


class TestExtractJobSamples:
    """Tests for _extract_job_samples()."""

    def test_returns_max_5_jobs(self):
        """Should limit results to 5 jobs."""
        mock_jobs = []
        for i in range(10):
            j = MagicMock()
            j.total_bytes_processed = 1000 * (i + 1)
            j.total_slot_ms = 500 * (i + 1)
            j.total_cost = None
            j.creation_time.isoformat.return_value = f"2024-01-{i + 1:02d}T00:00:00"
            j.cache_hit = False
            mock_jobs.append(j)

        db = MagicMock()
        db.query.return_value.filter.return_value.order_by.return_value.limit.return_value.all.return_value = mock_jobs[
            :5
        ]

        samples = _extract_job_samples(db, "config_123", "stg_orders")
        assert len(samples) == 5

    def test_returns_empty_list_for_no_jobs(self):
        """Should return empty list when no matching jobs found."""
        db = MagicMock()
        db.query.return_value.filter.return_value.order_by.return_value.limit.return_value.all.return_value = []

        samples = _extract_job_samples(db, "config_123", "stg_orders")
        assert samples == []

    def test_returns_correct_fields(self):
        """Should include expected fields in each job sample."""
        j = MagicMock()
        j.total_bytes_processed = 999999
        j.total_slot_ms = 50000
        j.total_cost = 1.23
        j.creation_time.isoformat.return_value = "2024-06-15T10:00:00"
        j.cache_hit = True

        db = MagicMock()
        db.query.return_value.filter.return_value.order_by.return_value.limit.return_value.all.return_value = [
            j
        ]

        samples = _extract_job_samples(db, "config_123", "stg_orders")
        assert len(samples) == 1
        s = samples[0]
        assert s["total_bytes_processed"] == 999999
        assert s["total_slot_ms"] == 50000
        assert s["query_cost"] == 1.23
        assert s["creation_time"] == "2024-06-15T10:00:00"
        assert s["cache_hit"] is True

    def test_handles_db_exception(self):
        """Should return empty list on database errors."""
        db = MagicMock()
        db.query.side_effect = SQLAlchemyError("DB error")

        samples = _extract_job_samples(db, "config_123", "stg_orders")
        assert samples == []


# --- T041: macro extraction tests ---


class TestExtractMacroSummary:
    """Tests for _extract_macro_summary()."""

    def test_returns_project_local_macros_only(self):
        """Should filter out dbt-core and package macros."""
        macros = {
            "macro.my_project.my_macro": {
                "name": "my_macro",
                "package_name": "my_project",
                "arguments": [{"name": "column_name"}],
            },
            "macro.dbt.ref": {
                "name": "ref",
                "package_name": "dbt",
                "arguments": [{"name": "model_name"}],
            },
            "macro.dbt_utils.star": {
                "name": "star",
                "package_name": "dbt_utils",
                "arguments": [],
            },
        }
        manifest = _make_manifest(macros=macros)

        summaries = _extract_macro_summary(manifest)
        assert len(summaries) == 1
        assert summaries[0].name == "my_macro"
        assert summaries[0].package_name == "my_project"

    def test_max_50_macros(self):
        """Should limit to 50 macros."""
        macros = {}
        for i in range(60):
            key = f"macro.my_project.macro_{i:03d}"
            macros[key] = {
                "name": f"macro_{i:03d}",
                "package_name": "my_project",
                "arguments": [],
            }
        manifest = _make_manifest(macros=macros)

        summaries = _extract_macro_summary(manifest)
        assert len(summaries) == 50

    def test_sorted_alphabetically(self):
        """Should sort macros by name."""
        macros = {
            "macro.my_project.z_macro": {
                "name": "z_macro",
                "package_name": "my_project",
                "arguments": [],
            },
            "macro.my_project.a_macro": {
                "name": "a_macro",
                "package_name": "my_project",
                "arguments": [],
            },
        }
        manifest = _make_manifest(macros=macros)

        summaries = _extract_macro_summary(manifest)
        assert summaries[0].name == "a_macro"
        assert summaries[1].name == "z_macro"

    def test_extracts_argument_names(self):
        """Should extract argument names from macro definition."""
        macros = {
            "macro.my_project.generate_schema_name": {
                "name": "generate_schema_name",
                "package_name": "my_project",
                "arguments": [
                    {"name": "custom_schema_name"},
                    {"name": "node"},
                ],
            },
        }
        manifest = _make_manifest(macros=macros)

        summaries = _extract_macro_summary(manifest)
        assert len(summaries) == 1
        assert summaries[0].arguments == ["custom_schema_name", "node"]

    def test_empty_macros_section(self):
        """Should return empty list when no macros in manifest."""
        manifest = _make_manifest(macros={})
        summaries = _extract_macro_summary(manifest)
        assert summaries == []
