"""Unit tests for workload classification helpers."""

from governor_core.sync.service import (
    WORKLOAD_KIND_BUILD,
    WORKLOAD_KIND_CONSUMPTION,
    build_manifest_table_set,
    classify_bigquery_job_workload,
    extract_dbt_tables,
)


def test_classify_prefers_build_when_destination_matches_manifest():
    manifest_tables = build_manifest_table_set(["proj.analytics.fct_orders"])

    result = classify_bigquery_job_workload(
        destination_table="proj.analytics.fct_orders",
        referenced_tables=["proj.analytics.stg_orders"],
        manifest_tables=manifest_tables,
    )

    assert result == WORKLOAD_KIND_BUILD


def test_classify_returns_consumption_for_manifest_reads_without_manifest_write():
    manifest_tables = build_manifest_table_set(["proj.analytics.fct_orders"])

    result = classify_bigquery_job_workload(
        destination_table="proj.scratch.tmp_orders",
        referenced_tables=["proj.analytics.fct_orders"],
        manifest_tables=manifest_tables,
    )

    assert result == WORKLOAD_KIND_CONSUMPTION


def test_classify_normalizes_case_and_backticks():
    manifest_tables = build_manifest_table_set(["proj.analytics.fct_orders"])

    result = classify_bigquery_job_workload(
        destination_table="`PROJ.ANALYTICS.FCT_ORDERS`",
        referenced_tables=[],
        manifest_tables=manifest_tables,
    )

    assert result == WORKLOAD_KIND_BUILD


def test_extract_dbt_tables_prefers_identifier_over_name():
    manifest = {
        "nodes": {
            "model.my_project.orders": {
                "resource_type": "model",
                "database": "proj",
                "schema": "analytics",
                "name": "orders",
                "identifier": "fct_orders",
            }
        }
    }

    tables = extract_dbt_tables(manifest)

    assert tables == ["proj.analytics.fct_orders"]
