"""Unit tests for app/solutions/templates/add_require_partition_filter.py."""

from types import SimpleNamespace

from governor_core.solutions.templates.add_require_partition_filter import (
    AddRequirePartitionFilterTemplate,
)
from governor_core.solutions.templates.base import TemplateResult


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_opportunity(
    opp_type: str = "partition_pruning",
    evidence: dict | None = None,
):
    return SimpleNamespace(
        id="opp-1",
        opportunity_type=opp_type,
        evidence_snapshot=evidence or {},
        dbt_model_name="my_model",
        affected_table="project.dataset.my_model",
    )


# ---------------------------------------------------------------------------
# SQL Fixtures
# ---------------------------------------------------------------------------

SQL_WITH_CONFIG = """\
{{ config(
    materialized='table'
) }}

SELECT id, name, created_at
FROM {{ ref('raw_orders') }}
"""

SQL_WITH_PARTITION = """\
{{ config(
    materialized='table',
    partition_by={"field": "created_at", "data_type": "date"}
) }}

SELECT id, name, created_at
FROM {{ ref('raw_orders') }}
"""

SQL_WITH_PARTITION_AND_FILTER = """\
{{ config(
    materialized='table',
    partition_by={"field": "created_at", "data_type": "date"},
    require_partition_filter=true
) }}

SELECT id, name, created_at
FROM {{ ref('raw_orders') }}
"""

SQL_WITH_PARTITION_AND_FILTER_FALSE = """\
{{ config(
    materialized='table',
    partition_by={"field": "created_at", "data_type": "date"},
    require_partition_filter=false
) }}

SELECT id, name, created_at
FROM {{ ref('raw_orders') }}
"""

_METADATA = {"original_file_path": "models/my_model.sql"}


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


class TestAddRequirePartitionFilterTemplate:
    def setup_method(self):
        self.template = AddRequirePartitionFilterTemplate()

    def test_matches_partitioned_without_filter(self):
        """Matches when SQL has partition_by but no require_partition_filter."""
        opp = _make_opportunity()
        source_files = {"models/my_model.sql": SQL_WITH_PARTITION}
        assert self.template.matches(opp, source_files, _METADATA) is True

    def test_no_match_wrong_type(self):
        """Does not match when opportunity_type is not partition_pruning."""
        opp = _make_opportunity(opp_type="shuffle_spill")
        source_files = {"models/my_model.sql": SQL_WITH_PARTITION}
        assert self.template.matches(opp, source_files, _METADATA) is False

    def test_no_match_not_partitioned(self):
        """Does not match when SQL has no partition_by."""
        opp = _make_opportunity()
        source_files = {"models/my_model.sql": SQL_WITH_CONFIG}
        assert self.template.matches(opp, source_files, _METADATA) is False

    def test_no_match_already_has_filter_true(self):
        """Does not match when require_partition_filter=true is already set."""
        opp = _make_opportunity()
        source_files = {"models/my_model.sql": SQL_WITH_PARTITION_AND_FILTER}
        assert self.template.matches(opp, source_files, _METADATA) is False

    def test_no_match_filter_explicitly_false(self):
        """Does not match when require_partition_filter=false (defers to LLM)."""
        opp = _make_opportunity()
        source_files = {"models/my_model.sql": SQL_WITH_PARTITION_AND_FILTER_FALSE}
        assert self.template.matches(opp, source_files, _METADATA) is False

    def test_apply_inserts_require_partition_filter(self):
        """Apply inserts require_partition_filter=true into existing config."""
        opp = _make_opportunity()
        source_files = {"models/my_model.sql": SQL_WITH_PARTITION}
        result = self.template.apply(opp, source_files, _METADATA)

        assert result is not None
        assert isinstance(result, TemplateResult)
        assert result.template_id == "add_require_partition_filter"
        assert result.file_path == "models/my_model.sql"
        assert result.before_content == SQL_WITH_PARTITION
        assert "require_partition_filter" in result.after_content
        assert "true" in result.after_content
        assert result.change_type == "project_config_change"
        assert result.parameters == {}
        assert "partition_by" in result.after_content  # existing config preserved
        assert "materialized" in result.after_content  # existing config preserved

    def test_result_has_correct_policy_tags(self):
        """Result policy_tags should be ['dbt_config_change']."""
        opp = _make_opportunity()
        source_files = {"models/my_model.sql": SQL_WITH_PARTITION}
        result = self.template.apply(opp, source_files, _METADATA)

        assert result is not None
        assert result.policy_tags == ["dbt_config_change"]

    def test_explanation_conveys_breaking_change_intent(self):
        """Spec 127 FR-005: explanation text must travel with the solution and
        convey (a) what the change does, (b) that it is a guardrail, (c) that
        unfiltered queries will be rejected — even without the UI warning."""
        opp = _make_opportunity()
        source_files = {"models/my_model.sql": SQL_WITH_PARTITION}
        result = self.template.apply(opp, source_files, _METADATA)

        assert result is not None
        explanation = result.explanation.lower()
        # (a) what it does
        assert "require_partition_filter" in explanation
        # (b) guardrail framing, not a silent optimization
        assert "guardrail" in explanation
        # (c) rejection / breaking semantics
        assert "reject" in explanation or "error" in explanation
