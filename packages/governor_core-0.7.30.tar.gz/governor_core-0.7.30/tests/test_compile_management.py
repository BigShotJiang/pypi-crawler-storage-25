"""Unit tests for dbt compile management (spec 050, US4).

Tests feature flags, error storage, and structured logging for
dbt compile/parse operations via uv venv.
"""

from __future__ import annotations

from pathlib import Path
from types import SimpleNamespace
from unittest.mock import MagicMock, patch

import pytest

from governor_core.solutions.generator import CompileAttemptData, SolutionData, SolutionGenerator


def _mock_settings(**overrides):
    """Create mock settings with uv defaults."""
    defaults = {
        "dbt_compile_timeout": 120,
        "dbt_compile_enabled": True,
        "dry_run_validation_enabled": True,
        "dbt_default_version": "1.9.0",
        "dbt_venv_base_dir": "/tmp/test-dbt-venvs",
        "dbt_profiles_dir": None,
        "dbt_target_name": None,
    }
    defaults.update(overrides)
    mock = MagicMock()
    for k, v in defaults.items():
        setattr(mock, k, v)
    return mock


# --- Feature flag behavior tests ---


class TestFeatureFlags:
    """Tests for DBT_COMPILE_ENABLED and DRY_RUN_VALIDATION_ENABLED flags."""

    def test_compile_disabled_skips_compile(self):
        """DBT_COMPILE_ENABLED=false should skip dbt compile entirely."""
        with patch("governor_core.solutions.generator.get_settings") as mock_settings:
            mock_settings.return_value = _mock_settings(dbt_compile_enabled=False)

            generator = SolutionGenerator(llm_provider=MagicMock(), github_client=None)

            sol = SolutionData(
                resolution_category="dbt_project_change",
                explanation="Test",
                risk_level="low",
                risk_justification="Safe",
                file_path="models/stg_orders.sql",
                after_content="SELECT 1",
            )

            result = generator._compile_solutions(
                solutions=[sol],
                config=MagicMock(),
                manifest_version=MagicMock(),
                dbt_prefix="",
            )

            assert result == {}

    def test_dry_run_disabled_skips_pre_gen(self):
        """DRY_RUN_VALIDATION_ENABLED=false should skip pre-gen dry-run."""
        with patch("governor_core.solutions.generator.get_settings") as mock_settings:
            mock_settings.return_value = _mock_settings(
                dry_run_validation_enabled=False
            )

            generator = SolutionGenerator(llm_provider=MagicMock(), github_client=None)
            result = generator._pre_generation_dry_run(
                compiled_sql="SELECT 1",
                gcp_project="test-project",
            )

            assert result is None

    def test_dry_run_disabled_skips_post_gen(self):
        """DRY_RUN_VALIDATION_ENABLED=false should skip post-gen dry-run."""
        with patch("governor_core.solutions.generator.get_settings") as mock_settings:
            mock_settings.return_value = _mock_settings(
                dry_run_validation_enabled=False
            )

            generator = SolutionGenerator(llm_provider=MagicMock(), github_client=None)

            sol = SolutionData(
                resolution_category="dbt_project_change",
                explanation="Test",
                risk_level="low",
                risk_justification="Safe",
                file_path="models/stg.sql",
            )

            generator._post_generation_dry_run(
                solutions=[sol],
                compiled_modified_sql_map={"models/stg.sql": "SELECT 1"},
                gcp_project="test-project",
                dry_run_original=None,
            )

            assert sol.dry_run_modified is None

    def test_both_disabled_preserves_pre_spec_050_behavior(self):
        """When both flags are off, no compile or dry-run operations occur."""
        with patch("governor_core.solutions.generator.get_settings") as mock_settings:
            mock_settings.return_value = _mock_settings(
                dbt_compile_enabled=False,
                dry_run_validation_enabled=False,
            )

            generator = SolutionGenerator(llm_provider=MagicMock(), github_client=None)

            # Compile should return empty
            compile_result = generator._compile_solutions(
                solutions=[],
                config=MagicMock(),
                manifest_version=MagicMock(),
                dbt_prefix="",
            )
            assert compile_result == {}

            # Pre-gen dry-run should return None
            pre_result = generator._pre_generation_dry_run(
                compiled_sql="SELECT 1",
                gcp_project="test-project",
            )
            assert pre_result is None


# --- Error storage tests ---


class TestErrorStorage:
    """Tests for compile error storage in solution.validation_report."""

    def test_compile_stderr_stored_in_validation_report(self):
        """Compile stderr should be stored in solution's validation_report."""
        sol = SolutionData(
            resolution_category="dbt_project_change",
            explanation="Test",
            risk_level="low",
            risk_justification="Safe",
            file_path="models/stg.sql",
            validation_report={"steps": []},
        )

        # Simulate adding compile result to validation report
        compile_result = {
            "success": False,
            "duration_ms": 1500,
            "exit_code": 1,
            "fallback_used": True,
            "stderr": "Compilation Error: invalid ref stg_missing",
        }

        if sol.validation_report is None:
            sol.validation_report = {}
        sol.validation_report["dbt_compile"] = compile_result

        assert sol.validation_report["dbt_compile"]["success"] is False
        assert "invalid ref" in sol.validation_report["dbt_compile"]["stderr"]

    def test_stderr_truncated_to_10kb(self):
        """Compile stderr should be truncated to 10KB before storage."""
        large_stderr = "x" * 20000  # 20KB

        # The truncation logic in the generator
        truncated = large_stderr[:10240]

        assert len(truncated) <= 10240


class TestManifestSourceReconstruction:
    """Tests for rebuilding source YAML files from manifest data."""

    def test_compile_solutions_preserves_safe_tier_when_parse_succeeds(self):
        """Successful dbt parse should not downgrade a deterministic solution."""
        generator = SolutionGenerator(
            llm_provider=MagicMock(),
            github_client=MagicMock(),
        )

        sol = SolutionData(
            resolution_category="dbt_project_change",
            explanation="Test",
            risk_level="low",
            risk_justification="Safe",
            file_path="models/staging/stg_gsod_weather.sql",
            after_content="select 1\n",
            validation_report={},
        )
        config = MagicMock(github_repo="owner/repo")
        manifest_version = MagicMock(content={"metadata": {"dbt_version": "1.10.8"}})

        with (
            patch("governor_core.solutions.generator.get_settings") as mock_settings,
            patch(
                "governor_core.dbt.uv_runner.DbtUvRunner.is_available",
                return_value=True,
            ),
            patch.object(
                generator,
                "_compile_single",
                return_value=CompileAttemptData(
                    compiled_sql="SELECT 1",
                    parse_report={
                        "success": True,
                        "exit_code": 0,
                        "duration_ms": 28,
                        "manifest_available": True,
                        "optimized_sql_source": "manifest_diff",
                        "optimized_sql_available": True,
                    },
                ),
            ),
        ):
            mock_settings.return_value = _mock_settings()
            compiled = generator._compile_solutions(
                solutions=[sol],
                config=config,
                manifest_version=manifest_version,
                dbt_prefix="",
            )

        assert compiled == {"models/staging/stg_gsod_weather.sql": "SELECT 1"}
        assert sol.compiled_after_sql == "SELECT 1"
        assert sol.trust_tier is None
        assert "dbt_compile" not in sol.validation_report
        assert sol.validation_report["dbt_parse"]["success"] is True
        assert sol.validation_report["dbt_parse"]["manifest_available"] is True
        assert any(
            step["type"] == "dbt_parse" and step["result"] == "success"
            for step in sol.validation_report["steps"]
        )

    @pytest.mark.xfail(
        reason="Pre-existing drift: test expects parse-first flow that was never implemented in "
        "_compile_single (main uses compile_model directly). Fails identically on main. "
        "Refactor tracked for a follow-up spec."
    )
    def test_compile_single_writes_source_yaml_before_parse(self, tmp_path):
        """Temp dbt project should include manifest-backed source definitions."""
        generator = SolutionGenerator(
            llm_provider=MagicMock(),
            github_client=MagicMock(),
        )
        generator._github.get_file_content.return_value = (
            "name: governor_weather\nprofile: default\n"
        )

        manifest = {
            "metadata": {
                "project_name": "governor_weather",
            },
            "nodes": {
                "model.governor_weather.stg_lightning_strikes": {
                    "name": "stg_lightning_strikes",
                    "resource_type": "model",
                    "package_name": "governor_weather",
                    "original_file_path": "models/staging/stg_lightning_strikes.sql",
                    "raw_code": (
                        "{{ config(materialized='table') }}\n"
                        "select * from {{ source('noaa_lightning', 'lightning_strikes') }}\n"
                    ),
                    "compiled_code": "select * from `bigquery-public-data.noaa_lightning.lightning_strikes`\n",
                }
            },
            "sources": {
                "source.governor_weather.noaa_lightning.lightning_strikes": {
                    "package_name": "governor_weather",
                    "original_file_path": "models/staging/sources.yml",
                    "source_name": "noaa_lightning",
                    "name": "lightning_strikes",
                    "database": "bigquery-public-data",
                    "schema": "noaa_lightning",
                    "identifier": "lightning_strikes",
                    "source_description": "Lightning strikes source",
                    "columns": {},
                }
            },
        }

        sol = SolutionData(
            resolution_category="dbt_project_change",
            explanation="Test",
            risk_level="low",
            risk_justification="Safe",
            file_path="models/staging/stg_lightning_strikes.sql",
            after_content="select 1\n",
        )
        config = MagicMock(github_repo="owner/repo", gcp_project_id="test-project")
        manifest_version = MagicMock(content=manifest)
        runner = MagicMock()

        def _parse_project(*, project_dir, **kwargs):
            source_file = Path(project_dir) / "models/staging/sources.yml"
            assert source_file.exists()
            source_yaml = source_file.read_text()
            assert "noaa_lightning" in source_yaml
            assert "lightning_strikes" in source_yaml
            assert "bigquery-public-data" in source_yaml
            return SimpleNamespace(
                success=True,
                duration_ms=12,
                exit_code=0,
                stderr="",
                manifest={"nodes": {}},
            )

        runner.parse_project.side_effect = _parse_project

        with patch("shutil.rmtree", return_value=None):
            compiled_sql = generator._compile_single(
                runner=runner,
                sol=sol,
                config=config,
                manifest_version=manifest_version,
                dbt_prefix="",
                dbt_version="1.10.8",
            )

        assert compiled_sql.compiled_sql is None
        assert compiled_sql.compile_report is None
        assert compiled_sql.parse_report["success"] is True
        assert compiled_sql.parse_report["optimized_sql_source"] == "manifest_diff"
        assert compiled_sql.parse_report["optimized_sql_available"] is False

    def test_fallback_compile_single_uses_manifest_compiled_sql_for_config_only_change(
        self,
    ):
        """Config-only model edits should reuse compiled manifest SQL unchanged."""
        generator = SolutionGenerator(
            llm_provider=MagicMock(),
            github_client=MagicMock(),
        )

        manifest = {
            "metadata": {"project_name": "governor_weather"},
            "nodes": {
                "model.governor_weather.stg_lightning_strikes": {
                    "name": "stg_lightning_strikes",
                    "resource_type": "model",
                    "package_name": "governor_weather",
                    "original_file_path": "models/staging/stg_lightning_strikes.sql",
                    "raw_code": (
                        "{{ config(materialized='table') }}\n"
                        "select * from {{ source('noaa_lightning', 'lightning_strikes') }}\n"
                    ),
                    "compiled_code": (
                        "select * from "
                        "`bigquery-public-data.noaa_lightning.lightning_strikes`\n"
                    ),
                }
            },
        }

        sol = SolutionData(
            resolution_category="dbt_project_change",
            explanation="Add partitioning",
            risk_level="low",
            risk_justification="Safe",
            file_path="models/staging/stg_lightning_strikes.sql",
            after_content=(
                "{{ config(\n"
                "    materialized='table',\n"
                '    partition_by={"field": "date", "data_type": "date"}\n'
                ") }}\n"
                "select * from {{ source('noaa_lightning', 'lightning_strikes') }}\n"
            ),
        )

        compiled_sql = generator._fallback_compile_single(
            sol,
            config=MagicMock(),
            manifest_version=MagicMock(content=manifest),
        )

        assert (
            compiled_sql
            == "select * from `bigquery-public-data.noaa_lightning.lightning_strikes`\n"
        )

    @pytest.mark.xfail(
        reason="Pre-existing drift: test expects parse-first flow that was never implemented in "
        "_compile_single (main uses compile_model directly). Fails identically on main. "
        "Refactor tracked for a follow-up spec."
    )
    def test_compile_single_uses_parse_and_manifest_diff_for_optimized_sql(self):
        """Optimized SQL should come from manifest diff after successful parse."""
        generator = SolutionGenerator(
            llm_provider=MagicMock(),
            github_client=MagicMock(),
        )
        generator._github.get_file_content.return_value = (
            "name: governor_weather\nprofile: governor_weather\n"
        )

        manifest = {
            "metadata": {
                "project_name": "governor_weather",
            },
            "nodes": {
                "model.governor_weather.stg_gsod_weather": {
                    "name": "stg_gsod_weather",
                    "resource_type": "model",
                    "package_name": "governor_weather",
                    "original_file_path": "models/staging/stg_gsod_weather.sql",
                    "raw_code": "select 1 as id\n",
                    "compiled_code": "select 1 as id\n",
                }
            },
            "sources": {},
        }

        sol = SolutionData(
            resolution_category="dbt_project_change",
            explanation="Test",
            risk_level="low",
            risk_justification="Safe",
            file_path="models/staging/stg_gsod_weather.sql",
            before_content="select 1 as id\n",
            after_content="select 2 as id\n",
        )
        config = MagicMock(github_repo="owner/repo")
        manifest_version = MagicMock(content=manifest)
        runner = MagicMock()
        runner.parse_project.return_value = SimpleNamespace(
            success=True,
            exit_code=0,
            duration_ms=34,
            stderr="",
            manifest={"nodes": {}},
        )

        with patch("shutil.rmtree", return_value=None):
            attempt = generator._compile_single(
                runner=runner,
                sol=sol,
                config=config,
                manifest_version=manifest_version,
                dbt_prefix="",
                dbt_version="1.10.8",
            )

        runner.parse_project.assert_called_once()
        assert attempt.compiled_sql == "select 2 as id"
        assert attempt.compile_report is None
        assert attempt.parse_report["success"] is True
        assert attempt.parse_report["manifest_available"] is True
        assert attempt.parse_report["optimized_sql_available"] is True


# --- Custom schema extraction tests ---


class TestExtractDefaultDataset:
    """Tests for _extract_default_dataset() target schema extraction.

    dbt manifest nodes store the *resolved* schema (after generate_schema_name).
    The method must extract the original target schema, not the resolved one,
    to avoid double-application when dbt compile runs generate_schema_name again.
    """

    def test_model_without_custom_schema_returns_target(self):
        """Node with no config.schema → node.schema IS the target schema."""
        manifest = {
            "nodes": {
                "model.proj.dim_users": {
                    "resource_type": "model",
                    "schema": "governor_demo",
                    "config": {},
                }
            }
        }
        assert SolutionGenerator._extract_default_dataset(manifest) == "governor_demo"

    def test_mixed_nodes_prefers_no_custom_schema(self):
        """When some nodes lack custom schema, prefer those for target extraction."""
        manifest = {
            "nodes": {
                "model.proj.fct_daily": {
                    "resource_type": "model",
                    "schema": "governor_demo_marts",
                    "config": {"schema": "marts"},
                },
                "model.proj.stg_raw": {
                    "resource_type": "model",
                    "schema": "governor_demo",
                    "config": {},
                },
            }
        }
        assert SolutionGenerator._extract_default_dataset(manifest) == "governor_demo"

    def test_all_custom_schemas_reverse_engineers_target(self):
        """When every model has a custom schema, strip the suffix to find target."""
        manifest = {
            "nodes": {
                "model.proj.fct_daily": {
                    "resource_type": "model",
                    "schema": "governor_demo_marts",
                    "config": {"schema": "marts"},
                },
                "model.proj.int_fees": {
                    "resource_type": "model",
                    "schema": "governor_demo_intermediate",
                    "config": {"schema": "intermediate"},
                },
            }
        }
        assert SolutionGenerator._extract_default_dataset(manifest) == "governor_demo"

    def test_empty_nodes_returns_fallback(self):
        """No model nodes → returns default_dataset."""
        manifest = {"nodes": {}}
        assert SolutionGenerator._extract_default_dataset(manifest) == "default_dataset"

    def test_non_model_nodes_ignored(self):
        """Test and source nodes should not be used for schema extraction."""
        manifest = {
            "nodes": {
                "test.proj.unique_id": {
                    "resource_type": "test",
                    "schema": "dbt_test__audit",
                    "config": {},
                },
                "model.proj.dim_users": {
                    "resource_type": "model",
                    "schema": "analytics",
                    "config": {},
                },
            }
        }
        assert SolutionGenerator._extract_default_dataset(manifest) == "analytics"

    def test_config_schema_none_treated_as_no_custom(self):
        """Explicit config.schema = None should be treated same as missing."""
        manifest = {
            "nodes": {
                "model.proj.dim_users": {
                    "resource_type": "model",
                    "schema": "my_target",
                    "config": {"schema": None},
                }
            }
        }
        assert SolutionGenerator._extract_default_dataset(manifest) == "my_target"

    def test_config_missing_entirely(self):
        """Node with no config key at all → schema is the target."""
        manifest = {
            "nodes": {
                "model.proj.dim_users": {
                    "resource_type": "model",
                    "schema": "prod_analytics",
                }
            }
        }
        assert SolutionGenerator._extract_default_dataset(manifest) == "prod_analytics"

    def test_case_insensitive_suffix_stripping(self):
        """Suffix stripping should be case-insensitive."""
        manifest = {
            "nodes": {
                "model.proj.fct_orders": {
                    "resource_type": "model",
                    "schema": "Governor_Demo_Marts",
                    "config": {"schema": "marts"},
                },
            }
        }
        assert SolutionGenerator._extract_default_dataset(manifest) == "Governor_Demo"

    def test_real_world_governor_demo_scenario(self):
        """Reproduce the exact bug: governor_demo_marts should NOT be used as target.

        Original: governor_demo_marts, governor_demo_intermediate
        Bug:      governor_demo_marts_marts, governor_demo_marts_intermediate
        Fix:      Extract 'governor_demo' as target schema.
        """
        manifest = {
            "nodes": {
                "model.governor_demo.fct_bitcoin_daily_metrics": {
                    "resource_type": "model",
                    "schema": "governor_demo_marts",
                    "config": {"schema": "marts"},
                },
                "model.governor_demo.int_fee_percentiles": {
                    "resource_type": "model",
                    "schema": "governor_demo_intermediate",
                    "config": {"schema": "intermediate"},
                },
                "model.governor_demo.rpt_executive_summary": {
                    "resource_type": "model",
                    "schema": "governor_demo_marts",
                    "config": {"schema": "marts"},
                },
            }
        }
        result = SolutionGenerator._extract_default_dataset(manifest)
        assert result == "governor_demo", (
            f"Expected 'governor_demo' but got '{result}'. "
            "Using resolved schema as target causes double-application of "
            "generate_schema_name: governor_demo_marts_marts"
        )
