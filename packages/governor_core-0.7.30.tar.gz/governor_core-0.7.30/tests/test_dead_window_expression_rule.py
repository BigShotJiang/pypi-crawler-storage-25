"""Unit tests for app/opportunities/rules/dead_window_expression.py."""

import pytest

from governor_core.opportunities.rules.dead_window_expression import DeadWindowExpressionRule


def _manifest() -> dict:
    sql = """
WITH
  base AS (
    SELECT
      id,
      ROW_NUMBER() OVER (PARTITION BY id ORDER BY ts) AS rn,
      created_at
    FROM raw_events
  ),
  final AS (
    SELECT id, created_at FROM base
  )
SELECT id, created_at FROM final
"""
    return {
        "nodes": {
            "model.proj.fct_events": {
                "name": "fct_events",
                "unique_id": "model.proj.fct_events",
                "database": "my-project",
                "schema": "dbt_prod",
                "identifier": "fct_events",
                "config": {"materialized": "table"},
                "raw_code": sql,
                "compiled_code": sql,
            }
        },
        "child_map": {"model.proj.fct_events": []},
    }


def test_rule_type():
    assert DeadWindowExpressionRule().rule_type == "dead_window_expression"


def test_detect_returns_candidate():
    results = DeadWindowExpressionRule().detect(
        jobs=[],
        manifest_content=_manifest(),
        thresholds={},
    )

    assert len(results) == 1
    candidate = results[0]
    assert candidate.opportunity_type == "dead_window_expression"
    assert candidate.evidence_snapshot["dead_window_expressions"] == ["rn"]
    assert candidate.evidence_snapshot["dead_columns"] == ["rn"]
    assert candidate.evidence_snapshot["suppressed_findings"] == [
        {
            "rule_type": "dead_column",
            "display_name": "Dead Column",
            "count": 1,
            "reason": (
                "Hidden because Dead Window Expression is the more specific rule "
                "for these unused window outputs."
            ),
            "items": ["base.rn"],
            "ctes": ["base"],
        }
    ]
    assert candidate.confidence == pytest.approx(0.7)
