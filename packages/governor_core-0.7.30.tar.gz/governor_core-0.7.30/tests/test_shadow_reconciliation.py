"""Unit tests for shadow reconciliation sweeper."""

from __future__ import annotations

from datetime import datetime, timedelta, timezone

from governor_core.shadow.reconciliation import reconcile
from tests.fixtures.factories import (
    ManifestConfigurationFactory,
    ShadowValidationRunFactory,
)


class _FakeBq:
    def __init__(self, tables: list[str]):
        self._tables = list(tables)
        self.dropped: list[str] = []

    def list_tables(self, dataset):  # noqa: ARG002
        return list(self._tables)

    def drop_table(self, dataset, name):  # noqa: ARG002
        self._tables.remove(name)
        self.dropped.append(name)


def test_unbound_artifact_is_deleted(db):
    config = ManifestConfigurationFactory.create()
    bq = _FakeBq(["fct_orders__governor_abcdef012345"])
    report = reconcile(db, configuration=config, dataset="d", bq=bq)
    assert "fct_orders__governor_abcdef012345" in report.deleted


def test_active_run_artifact_retained(db):
    config = ManifestConfigurationFactory.create()
    # Create a running shadow run whose hex12 matches the artifact
    run = ShadowValidationRunFactory.create(
        config_id=config.id, status="running", solution_id_hex12="abcdef012345"
    )
    assert run.solution_id_hex12 == "abcdef012345"
    bq = _FakeBq(["fct_orders__governor_abcdef012345"])
    report = reconcile(db, configuration=config, dataset="d", bq=bq)
    assert report.deleted == []
    assert report.retained == ["fct_orders__governor_abcdef012345"]


def test_terminal_fresh_run_retained(db):
    config = ManifestConfigurationFactory.create(
        shadow_reconciliation_threshold_hours=24
    )
    run = ShadowValidationRunFactory.create(
        config_id=config.id, status="succeeded", solution_id_hex12="abcdef012345"
    )
    run.updated_at = datetime.now(timezone.utc) - timedelta(hours=1)  # fresh
    db.flush()
    bq = _FakeBq(["fct_orders__governor_abcdef012345"])
    report = reconcile(db, configuration=config, dataset="d", bq=bq)
    assert report.retained == ["fct_orders__governor_abcdef012345"]


def test_terminal_aged_run_deleted(db):
    config = ManifestConfigurationFactory.create(
        shadow_reconciliation_threshold_hours=24
    )
    run = ShadowValidationRunFactory.create(
        config_id=config.id, status="succeeded", solution_id_hex12="abcdef012345"
    )
    run.updated_at = datetime.now(timezone.utc) - timedelta(hours=48)
    db.flush()
    bq = _FakeBq(["fct_orders__governor_abcdef012345"])
    report = reconcile(db, configuration=config, dataset="d", bq=bq)
    assert report.deleted == ["fct_orders__governor_abcdef012345"]


def test_non_shadow_tables_ignored(db):
    config = ManifestConfigurationFactory.create()
    bq = _FakeBq(["fct_orders", "dim_customers", "raw_events"])
    report = reconcile(db, configuration=config, dataset="d", bq=bq)
    assert report.deleted == []
    assert report.retained == []
