"""Unit tests for app/opportunities/rules/redundant_order_by.py."""

from decimal import Decimal

import pytest

from governor_core.opportunities.rules.redundant_order_by import RedundantOrderByRule


def _node(name: str, sql: str, materialized: str = "table") -> dict:
    return {
        "name": name,
        "unique_id": f"model.proj.{name}",
        "database": "my-project",
        "schema": "dbt_prod",
        "identifier": name,
        "config": {"materialized": materialized},
        "raw_code": sql,
        "compiled_code": sql,
    }


def _manifest() -> dict:
    sql = """
WITH
  base AS (
    SELECT id, created_at
    FROM raw_events
    ORDER BY created_at DESC
  ),
  final AS (
    SELECT id FROM base
  )
SELECT id FROM final
"""
    return {
        "nodes": {"model.proj.fct_events": _node("fct_events", sql)},
        "child_map": {"model.proj.fct_events": []},
    }


def test_rule_type():
    assert RedundantOrderByRule().rule_type == "redundant_order_by"


def test_default_thresholds():
    thresholds = RedundantOrderByRule().default_thresholds
    assert thresholds["min_redundant_order_bys"] == 1


def test_detect_none_manifest():
    assert (
        RedundantOrderByRule().detect(jobs=[], manifest_content=None, thresholds={})
        == []
    )


def test_detect_returns_candidate():
    results = RedundantOrderByRule().detect(
        jobs=[],
        manifest_content=_manifest(),
        thresholds={},
    )

    assert len(results) == 1
    candidate = results[0]
    assert candidate.opportunity_type == "redundant_order_by"
    assert candidate.dbt_model_name == "fct_events"
    assert candidate.evidence_snapshot["redundant_order_bys"] == ["base"]
    assert candidate.evidence_snapshot["redundant_order_by_count"] == 1
    assert candidate.confidence == pytest.approx(0.72)


def test_detect_no_job_data_zero_savings():
    results = RedundantOrderByRule().detect(
        jobs=[],
        manifest_content=_manifest(),
        thresholds={},
    )

    assert len(results) == 1
    assert results[0].expected_savings == Decimal("0")
    assert results[0].current_cost_estimate == Decimal("0")


def test_detect_min_threshold():
    results = RedundantOrderByRule().detect(
        jobs=[],
        manifest_content=_manifest(),
        thresholds={"min_redundant_order_bys": 2},
    )

    assert results == []
