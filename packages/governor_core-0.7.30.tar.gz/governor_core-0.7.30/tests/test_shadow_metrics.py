"""Unit tests for metrics_from_run_results."""

from __future__ import annotations

from governor_core.shadow.metrics import metrics_from_run_results


def test_extract_from_success_result():
    rr = {
        "results": [
            {
                "unique_id": "model.p.fct_orders",
                "status": "success",
                "execution_time": 2.5,
                "adapter_response": {
                    "bytes_processed": 10_000_000,
                    "slot_ms": 5_000,
                    "rows_affected": 1_000,
                },
            }
        ]
    }
    metrics = metrics_from_run_results(
        run_results=rr, expected_models=["fct_orders"]
    )
    assert len(metrics) == 1
    m = metrics[0]
    assert m.bytes_processed == 10_000_000
    assert m.slot_ms == 5_000
    assert m.row_count == 1_000
    assert m.duration_ms == 2_500
    assert m.error_type is None


def test_expected_model_missing_returns_empty_metric():
    rr = {"results": []}
    metrics = metrics_from_run_results(
        run_results=rr, expected_models=["fct_orders"]
    )
    assert len(metrics) == 1
    assert metrics[0].bytes_processed is None
    assert metrics[0].error_type is None


def test_failed_result_captures_error():
    rr = {
        "results": [
            {
                "unique_id": "model.p.fct_orders",
                "status": "error",
                "execution_time": 0.0,
                "message": "syntax error at line 3",
                "adapter_response": {},
            }
        ]
    }
    metrics = metrics_from_run_results(
        run_results=rr, expected_models=["fct_orders"]
    )
    assert metrics[0].error_type == "error"
    assert metrics[0].error_message == "syntax error at line 3"


def test_multiple_models_preserves_order():
    rr = {
        "results": [
            {
                "unique_id": "model.p.b",
                "status": "success",
                "execution_time": 1.0,
                "adapter_response": {"bytes_processed": 20, "rows_affected": 2},
            },
            {
                "unique_id": "model.p.a",
                "status": "success",
                "execution_time": 1.0,
                "adapter_response": {"bytes_processed": 10, "rows_affected": 1},
            },
        ]
    }
    metrics = metrics_from_run_results(run_results=rr, expected_models=["a", "b"])
    assert metrics[0].model_name == "a"
    assert metrics[0].bytes_processed == 10
    assert metrics[1].model_name == "b"
    assert metrics[1].bytes_processed == 20
