"""Tests for spec 128 apply_bundle_atomically (US3, T032-T034)."""

from __future__ import annotations

import os
import stat
from pathlib import Path

import pytest

from governor_core.solutions.service import (
    PartialApplyError,
    apply_bundle_atomically,
)


def _bundle(project_path: Path, files: list[tuple[str, str]]) -> list[dict]:
    """Build a file_changes bundle from (relative_path, after_content) tuples.
    Creates the parent directories and writes dummy before-content to each
    target so we can detect whether the target was modified by apply."""
    out = []
    for rel, after in files:
        target = project_path / rel
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(f"-- before: {rel}\n", encoding="utf-8")
        out.append(
            {
                "file_path": rel,
                "before_content": f"-- before: {rel}\n",
                "after_content": after,
            }
        )
    return out


class TestAtomicApplyHappyPath:
    def test_three_file_bundle_lands_atomically(self, tmp_path: Path):
        bundle = _bundle(
            tmp_path,
            [
                ("models/marts/events.sql", "-- guarded upstream\n"),
                ("models/marts/events_summary.sql", "-- filtered\nwhere x = 1\n"),
                ("models/marts/events_today.sql", "-- filtered\nwhere x = 1\n"),
            ],
        )
        written = apply_bundle_atomically(str(tmp_path), bundle, solution_id="sol-1")
        assert len(written) == 3
        # Every target has the new content.
        for entry in bundle:
            actual = (tmp_path / entry["file_path"]).read_text()
            assert actual == entry["after_content"]
        # No tmp files or marker files left behind.
        for p in tmp_path.rglob("*"):
            assert not p.name.endswith("-tmp"), f"leaked tmp: {p}"
        assert not (tmp_path / ".governor-bundle-state.sol-1").exists()

    def test_empty_bundle_is_noop(self, tmp_path: Path):
        assert apply_bundle_atomically(str(tmp_path), [], solution_id="sol-x") == []

    def test_nested_directories_created(self, tmp_path: Path):
        bundle = [
            {
                "file_path": "new/deeper/here/a.sql",
                "before_content": "",
                "after_content": "select 1\n",
            }
        ]
        apply_bundle_atomically(str(tmp_path), bundle, solution_id="sol-nest")
        assert (tmp_path / "new/deeper/here/a.sql").read_text() == "select 1\n"


class TestAtomicApplyWritePhaseFailure:
    def test_failing_write_rolls_back_all_tmps_and_no_target_modified(
        self, tmp_path: Path
    ):
        bundle = _bundle(
            tmp_path,
            [
                ("a.sql", "new-a\n"),
                ("b.sql", "new-b\n"),
                ("c.sql", "new-c\n"),
            ],
        )

        # Make the second target's parent dir read-only so the .tmp write fails.
        parent = tmp_path
        parent.chmod(0o555)
        try:
            # With the project dir read-only we cannot even create the first
            # tmp file — but that is fine, we assert the all-or-none contract.
            with pytest.raises(RuntimeError):
                apply_bundle_atomically(str(tmp_path), bundle, solution_id="sol-2")
        finally:
            parent.chmod(0o755)  # restore so the test cleanup can remove files

        # Every target still has before-content — nothing was modified.
        for entry in bundle:
            actual = (tmp_path / entry["file_path"]).read_text()
            assert actual.startswith("-- before:"), (
                f"{entry['file_path']} was partially modified: {actual!r}"
            )

    def test_path_traversal_is_rejected(self, tmp_path: Path):
        bundle = [
            {
                "file_path": "../outside.sql",
                "before_content": "",
                "after_content": "oops",
            }
        ]
        with pytest.raises(ValueError, match="escapes project"):
            apply_bundle_atomically(str(tmp_path), bundle, solution_id="sol-3")

    def test_missing_after_content_rejected(self, tmp_path: Path):
        bundle = [{"file_path": "a.sql"}]
        with pytest.raises(ValueError):
            apply_bundle_atomically(str(tmp_path), bundle, solution_id="sol-4")


class TestAtomicApplyMidRenameFailure:
    def test_mid_sequence_rename_failure_writes_marker(self, tmp_path: Path, monkeypatch):
        bundle = _bundle(
            tmp_path,
            [
                ("a.sql", "new-a\n"),
                ("b.sql", "new-b\n"),
                ("c.sql", "new-c\n"),
            ],
        )

        # Monkeypatch os.replace to fail on the second invocation.
        real_replace = os.replace
        call_count = {"n": 0}

        def flaky_replace(src, dst):
            call_count["n"] += 1
            if call_count["n"] == 2:
                raise OSError("simulated mid-rename failure")
            return real_replace(src, dst)

        monkeypatch.setattr("os.replace", flaky_replace)

        with pytest.raises(PartialApplyError):
            apply_bundle_atomically(str(tmp_path), bundle, solution_id="sol-5")

        # Marker file exists and names the failure.
        marker = tmp_path / ".governor-bundle-state.sol-5"
        assert marker.exists()
        marker_text = marker.read_text()
        assert "Successfully renamed" in marker_text
        assert "simulated mid-rename failure" in marker_text

        # Clean up the marker so tmp_path teardown is clean.
        marker.unlink()
