"""Unit tests for app/dbt/column_analyzer.py.

Tests cover:
  - Basic dead column detection (cross-model, US1)
  - No dead columns when all are used (US1)
  - Leaf model skip (US1)
  - Ephemeral model skip (US1)
  - SELECT * in upstream (US2)
  - SELECT * in downstream (US2)
  - Fan-out: column used by one of N children (US3)
  - Fan-out: some columns left uncovered (US3)
  - Missing downstream compiled_code (US3 conservative)
  - Alias resolution: aliased column referenced by downstream (US4)
  - Alias resolution: aliased column not referenced by downstream (US4)
  - excluded_column_patterns (Polish)
  - min_column_count threshold (Polish)
  - Parse failure in upstream SQL (Polish)
  - Parse failure in downstream SQL — conservative (Polish)
  - Intra-model dead column analysis (analyze_all_intra_model)
"""

from governor_core.dbt.column_analyzer import (
    _collect_col_refs,
    _extract_cte_output_columns,
    _extract_downstream_references,
    _extract_model_output_columns,
    _is_cte_star_consumed,
    _is_leaf_model,
    _matches_excluded,
    _resolve_table_name,
    analyze_all_dead_ctes,
    analyze_all_intra_model,
    analyze_intra_model_dead_outputs_by_category,
    analyze_redundant_order_bys,
    analyze_unused_joins,
    analyze_manifest,
)
import sqlglot
from sqlglot import exp


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _node(
    name: str,
    compiled: str,
    raw: str | None = None,
    materialized: str = "table",
    database: str = "proj",
    schema: str = "dbt",
    identifier: str | None = None,
) -> dict:
    return {
        "name": name,
        "unique_id": f"model.proj.{name}",
        "database": database,
        "schema": schema,
        "identifier": identifier or name,
        "config": {"materialized": materialized},
        "compiled_code": compiled,
        "raw_code": raw or compiled,
    }


def _manifest(nodes: dict, child_map: dict) -> dict:
    return {"nodes": nodes, "child_map": child_map}


# ---------------------------------------------------------------------------
# _resolve_table_name
# ---------------------------------------------------------------------------


def test_resolve_table_name_basic():
    node = {"database": "my-proj", "schema": "dbt_prod", "identifier": "stg_orders"}
    assert _resolve_table_name(node) == "my-proj.dbt_prod.stg_orders"


def test_resolve_table_name_falls_back_to_name():
    node = {"database": "p", "schema": "s", "name": "fallback"}
    assert _resolve_table_name(node) == "p.s.fallback"


# ---------------------------------------------------------------------------
# _is_leaf_model
# ---------------------------------------------------------------------------


def test_is_leaf_model_no_children():
    child_map = {"model.proj.stg_a": []}
    assert _is_leaf_model("model.proj.stg_a", child_map) is True


def test_is_leaf_model_only_exposure_children():
    child_map = {"model.proj.fct_a": ["exposure.proj.dashboard"]}
    assert _is_leaf_model("model.proj.fct_a", child_map) is True


def test_is_leaf_model_has_model_child():
    child_map = {"model.proj.stg_a": ["model.proj.int_a"]}
    assert _is_leaf_model("model.proj.stg_a", child_map) is False


def test_is_leaf_model_mixed_children():
    child_map = {
        "model.proj.stg_a": ["exposure.proj.dash", "model.proj.int_a", "test.proj.t"]
    }
    assert _is_leaf_model("model.proj.stg_a", child_map) is False


# ---------------------------------------------------------------------------
# _extract_model_output_columns
# ---------------------------------------------------------------------------


def test_extract_output_columns_basic():
    sql = "SELECT station_id, name, elevation FROM raw_stations"
    cols, alias_map, star = _extract_model_output_columns(sql)
    assert cols == ["station_id", "name", "elevation"]
    assert alias_map == {}
    assert star is False


def test_extract_output_columns_with_alias():
    sql = "SELECT station_id AS id, name FROM raw_stations"
    cols, alias_map, star = _extract_model_output_columns(sql)
    assert "station_id" in cols
    assert alias_map.get("id") == "station_id"
    assert star is False


def test_extract_output_columns_star():
    sql = "SELECT * FROM raw_stations"
    cols, alias_map, star = _extract_model_output_columns(sql)
    assert star is True
    assert cols == []


def test_extract_output_columns_cte_outermost_star():
    sql = """
    WITH base AS (SELECT station_id, name FROM raw_stations)
    SELECT * FROM base
    """
    _, _, star = _extract_model_output_columns(sql)
    assert star is True


def test_extract_output_columns_parse_failure_returns_safe():
    cols, alias_map, star = _extract_model_output_columns("NOT VALID SQL !!!")
    assert cols == []
    assert alias_map == {}
    assert star is False


def test_extract_output_columns_empty_sql():
    cols, alias_map, star = _extract_model_output_columns("")
    assert cols == []
    assert star is False


# ---------------------------------------------------------------------------
# _extract_downstream_references
# ---------------------------------------------------------------------------


def test_extract_downstream_refs_explicit_columns():
    sql = "SELECT s.station_id, s.name FROM stg_stations s"
    refs, star = _extract_downstream_references(sql, "stg_stations")
    assert "station_id" in refs
    assert "name" in refs
    assert star is False


def test_extract_downstream_refs_select_star():
    sql = "SELECT * FROM stg_stations"
    refs, star = _extract_downstream_references(sql, "stg_stations")
    assert star is True


def test_extract_downstream_refs_table_dot_star():
    sql = "SELECT s.* FROM stg_stations s"
    refs, star = _extract_downstream_references(sql, "stg_stations")
    assert star is True


def test_extract_downstream_refs_unparseable_sql_does_not_raise():
    """sqlglot may partially parse invalid SQL. Function must not raise."""
    refs, star = _extract_downstream_references("!!! GARBAGE !!!", "stg_stations")
    assert isinstance(refs, set)
    assert isinstance(star, bool)


# ---------------------------------------------------------------------------
# _matches_excluded
# ---------------------------------------------------------------------------


def test_matches_excluded_simple_pattern():
    assert _matches_excluded("_dbt_source_relation", ["^_dbt_"]) is True


def test_matches_excluded_no_match():
    assert _matches_excluded("station_id", ["^_dbt_"]) is False


def test_matches_excluded_empty_patterns():
    assert _matches_excluded("any_column", []) is False


# ---------------------------------------------------------------------------
# analyze_manifest — US1: Basic dead column detection
# ---------------------------------------------------------------------------


def _simple_manifest() -> dict:
    """Two-model manifest: stg_stations → int_ref. int_ref uses 2 of 4 cols."""
    nodes = {
        "model.proj.stg_stations": _node(
            "stg_stations",
            "SELECT station_id, name, elevation, country_code FROM raw_stations",
        ),
        "model.proj.int_ref": _node(
            "int_ref",
            "SELECT s.station_id, s.name FROM stg_stations s",
        ),
    }
    child_map = {
        "model.proj.stg_stations": ["model.proj.int_ref"],
        "model.proj.int_ref": [],
    }
    return _manifest(nodes, child_map)


def test_analyze_manifest_basic_dead_columns():
    results = analyze_manifest(_simple_manifest(), min_column_count=1)
    assert len(results) == 1
    analysis = results[0]
    assert analysis.model_name == "stg_stations"
    assert set(analysis.dead_columns) == {"elevation", "country_code"}
    assert "int_ref" in analysis.downstream_models


def test_analyze_manifest_no_dead_columns_when_all_used():
    nodes = {
        "model.proj.stg_stations": _node(
            "stg_stations",
            "SELECT station_id, name FROM raw_stations",
        ),
        "model.proj.int_ref": _node(
            "int_ref",
            "SELECT s.station_id, s.name FROM stg_stations s",
        ),
    }
    child_map = {
        "model.proj.stg_stations": ["model.proj.int_ref"],
        "model.proj.int_ref": [],
    }
    results = analyze_manifest(_manifest(nodes, child_map), min_column_count=1)
    assert results == []


def test_analyze_manifest_leaf_model_skipped():
    """fct_summary has no model children — should not appear in results."""
    nodes = {
        "model.proj.fct_summary": _node(
            "fct_summary",
            "SELECT a, b, c FROM some_table",
        ),
    }
    child_map = {"model.proj.fct_summary": []}
    results = analyze_manifest(_manifest(nodes, child_map), min_column_count=1)
    assert results == []


def test_analyze_manifest_ephemeral_model_skipped():
    nodes = {
        "model.proj.stg_ephemeral": _node(
            "stg_ephemeral",
            "SELECT a, b, c FROM raw",
            materialized="ephemeral",
        ),
        "model.proj.int_ref": _node(
            "int_ref",
            "SELECT a FROM stg_ephemeral",
        ),
    }
    child_map = {
        "model.proj.stg_ephemeral": ["model.proj.int_ref"],
        "model.proj.int_ref": [],
    }
    results = analyze_manifest(_manifest(nodes, child_map), min_column_count=1)
    # Only int_ref (non-ephemeral) might appear if it has dead cols and children
    # stg_ephemeral must NOT appear
    model_names = [r.model_name for r in results]
    assert "stg_ephemeral" not in model_names


def test_analyze_manifest_min_column_count_threshold():
    """Model with 2 cols skipped when min_column_count=3."""
    nodes = {
        "model.proj.stg_small": _node(
            "stg_small",
            "SELECT a, b FROM raw",
        ),
        "model.proj.int_ref": _node(
            "int_ref",
            "SELECT a FROM stg_small",
        ),
    }
    child_map = {
        "model.proj.stg_small": ["model.proj.int_ref"],
        "model.proj.int_ref": [],
    }
    results = analyze_manifest(_manifest(nodes, child_map), min_column_count=3)
    assert results == []


def test_analyze_manifest_missing_compiled_code_skipped():
    nodes = {
        "model.proj.stg_a": {
            "name": "stg_a",
            "unique_id": "model.proj.stg_a",
            "database": "p",
            "schema": "s",
            "identifier": "stg_a",
            "config": {"materialized": "table"},
            "compiled_code": "",  # empty
            "raw_code": "",
        },
        "model.proj.int_ref": _node("int_ref", "SELECT a FROM stg_a"),
    }
    child_map = {
        "model.proj.stg_a": ["model.proj.int_ref"],
        "model.proj.int_ref": [],
    }
    results = analyze_manifest(_manifest(nodes, child_map), min_column_count=1)
    assert results == []


# ---------------------------------------------------------------------------
# US2: SELECT * safety guard
# ---------------------------------------------------------------------------


def test_analyze_manifest_upstream_star_skipped():
    """Upstream does SELECT * — cannot determine output columns, skip."""
    nodes = {
        "model.proj.stg_orders": _node(
            "stg_orders",
            "SELECT * FROM raw_orders",
        ),
        "model.proj.int_orders": _node(
            "int_orders",
            "SELECT order_id FROM stg_orders",
        ),
    }
    child_map = {
        "model.proj.stg_orders": ["model.proj.int_orders"],
        "model.proj.int_orders": [],
    }
    results = analyze_manifest(_manifest(nodes, child_map), min_column_count=1)
    assert results == []


def test_analyze_manifest_downstream_star_suppresses_opportunity():
    """Downstream SELECT * → upstream not flagged even if it has 'dead' columns."""
    nodes = {
        "model.proj.stg_stations": _node(
            "stg_stations",
            "SELECT station_id, name, elevation FROM raw",
        ),
        "model.proj.int_passthrough": _node(
            "int_passthrough",
            "SELECT * FROM stg_stations",
        ),
    }
    child_map = {
        "model.proj.stg_stations": ["model.proj.int_passthrough"],
        "model.proj.int_passthrough": [],
    }
    results = analyze_manifest(_manifest(nodes, child_map), min_column_count=1)
    assert results == []


def test_analyze_manifest_one_star_child_suppresses_all():
    """Even if one of two children uses SELECT *, the upstream is not flagged."""
    nodes = {
        "model.proj.stg_a": _node(
            "stg_a",
            "SELECT col1, col2, col3 FROM raw",
        ),
        "model.proj.int_explicit": _node(
            "int_explicit",
            "SELECT col1 FROM stg_a",
        ),
        "model.proj.int_star": _node(
            "int_star",
            "SELECT * FROM stg_a",
        ),
    }
    child_map = {
        "model.proj.stg_a": ["model.proj.int_explicit", "model.proj.int_star"],
        "model.proj.int_explicit": [],
        "model.proj.int_star": [],
    }
    results = analyze_manifest(_manifest(nodes, child_map), min_column_count=1)
    assert results == []


# ---------------------------------------------------------------------------
# US3: Fan-out correctness
# ---------------------------------------------------------------------------


def test_analyze_manifest_fanout_union_covers_all():
    """5 children collectively use all columns — no dead columns."""
    nodes = {
        "model.proj.stg_a": _node(
            "stg_a",
            "SELECT col1, col2, col3, col4, col5 FROM raw",
        ),
        **{
            f"model.proj.int_{i}": _node(f"int_{i}", f"SELECT col{i} FROM stg_a")
            for i in range(1, 6)
        },
    }
    child_map = {
        "model.proj.stg_a": [f"model.proj.int_{i}" for i in range(1, 6)],
        **{f"model.proj.int_{i}": [] for i in range(1, 6)},
    }
    results = analyze_manifest(_manifest(nodes, child_map), min_column_count=1)
    assert results == []


def test_analyze_manifest_fanout_leaves_columns_dead():
    """3 children collectively leave col3 and col4 unused."""
    nodes = {
        "model.proj.stg_a": _node(
            "stg_a",
            "SELECT col1, col2, col3, col4 FROM raw",
        ),
        "model.proj.int_1": _node("int_1", "SELECT col1 FROM stg_a"),
        "model.proj.int_2": _node("int_2", "SELECT col2 FROM stg_a"),
        "model.proj.int_3": _node("int_3", "SELECT col1, col2 FROM stg_a"),
    }
    child_map = {
        "model.proj.stg_a": [
            "model.proj.int_1",
            "model.proj.int_2",
            "model.proj.int_3",
        ],
        "model.proj.int_1": [],
        "model.proj.int_2": [],
        "model.proj.int_3": [],
    }
    results = analyze_manifest(_manifest(nodes, child_map), min_column_count=1)
    assert len(results) == 1
    assert set(results[0].dead_columns) == {"col3", "col4"}


def test_analyze_manifest_child_missing_compiled_code_is_conservative():
    """Child with no compiled_code → upstream treated conservatively (not flagged)."""
    nodes = {
        "model.proj.stg_a": _node(
            "stg_a",
            "SELECT col1, col2, col3 FROM raw",
        ),
        "model.proj.int_ref": {
            "name": "int_ref",
            "unique_id": "model.proj.int_ref",
            "database": "p",
            "schema": "s",
            "identifier": "int_ref",
            "config": {"materialized": "table"},
            "compiled_code": "",  # empty — unknown
            "raw_code": "",
        },
    }
    child_map = {
        "model.proj.stg_a": ["model.proj.int_ref"],
        "model.proj.int_ref": [],
    }
    results = analyze_manifest(_manifest(nodes, child_map), min_column_count=1)
    assert results == []


# ---------------------------------------------------------------------------
# US4: Alias resolution
# ---------------------------------------------------------------------------


def test_analyze_manifest_alias_not_flagged_when_downstream_uses_alias():
    """station_id AS id — downstream uses 'id' → station_id should NOT be dead."""
    nodes = {
        "model.proj.stg_stations": _node(
            "stg_stations",
            "SELECT station_id AS id, name, elevation FROM raw",
        ),
        "model.proj.int_ref": _node(
            "int_ref",
            "SELECT s.id, s.name FROM stg_stations s",
        ),
    }
    child_map = {
        "model.proj.stg_stations": ["model.proj.int_ref"],
        "model.proj.int_ref": [],
    }
    results = analyze_manifest(_manifest(nodes, child_map), min_column_count=1)
    # Only 'elevation' should be dead; station_id is aliased to 'id' and used
    if results:
        assert "station_id" not in results[0].dead_columns
        assert "elevation" in results[0].dead_columns


def test_analyze_manifest_alias_flagged_when_downstream_uses_neither():
    """station_id AS id — downstream uses neither 'id' nor 'station_id' → dead."""
    nodes = {
        "model.proj.stg_stations": _node(
            "stg_stations",
            "SELECT station_id AS id, name FROM raw",
        ),
        "model.proj.int_ref": _node(
            "int_ref",
            "SELECT s.name FROM stg_stations s",
        ),
    }
    child_map = {
        "model.proj.stg_stations": ["model.proj.int_ref"],
        "model.proj.int_ref": [],
    }
    results = analyze_manifest(_manifest(nodes, child_map), min_column_count=1)
    assert len(results) == 1
    assert "station_id" in results[0].dead_columns


def test_analyze_manifest_downstream_uses_source_name_directly():
    """Downstream uses the source name directly (not the alias) → still treated as used."""
    nodes = {
        "model.proj.stg_a": _node(
            "stg_a",
            "SELECT col1 AS alias1, col2 FROM raw",
        ),
        "model.proj.int_ref": _node(
            "int_ref",
            "SELECT a.col1, a.col2 FROM stg_a a",
        ),
    }
    child_map = {
        "model.proj.stg_a": ["model.proj.int_ref"],
        "model.proj.int_ref": [],
    }
    results = analyze_manifest(_manifest(nodes, child_map), min_column_count=1)
    # col1 used by source name → not dead; col2 used → not dead
    assert results == []


# ---------------------------------------------------------------------------
# Polish: excluded_column_patterns
# ---------------------------------------------------------------------------


def test_analyze_manifest_excluded_pattern_not_flagged():
    nodes = {
        "model.proj.stg_a": _node(
            "stg_a",
            "SELECT col1, _dbt_source_relation, col2 FROM raw",
        ),
        "model.proj.int_ref": _node(
            "int_ref",
            "SELECT col1, col2 FROM stg_a",
        ),
    }
    child_map = {
        "model.proj.stg_a": ["model.proj.int_ref"],
        "model.proj.int_ref": [],
    }
    results = analyze_manifest(
        _manifest(nodes, child_map),
        min_column_count=1,
        excluded_patterns=["^_dbt_"],
    )
    assert results == []  # _dbt_source_relation excluded, col1+col2 both used


def test_analyze_manifest_excluded_pattern_column_not_in_dead():
    nodes = {
        "model.proj.stg_a": _node(
            "stg_a",
            "SELECT col1, _loaded_at, dead_col FROM raw",
        ),
        "model.proj.int_ref": _node(
            "int_ref",
            "SELECT col1 FROM stg_a",
        ),
    }
    child_map = {
        "model.proj.stg_a": ["model.proj.int_ref"],
        "model.proj.int_ref": [],
    }
    results = analyze_manifest(
        _manifest(nodes, child_map),
        min_column_count=1,
        excluded_patterns=["^_loaded_at$"],
    )
    assert len(results) == 1
    assert "_loaded_at" not in results[0].dead_columns
    assert "dead_col" in results[0].dead_columns


# ---------------------------------------------------------------------------
# Intra-model analysis helpers
# ---------------------------------------------------------------------------


def _parse_cte_select(sql: str) -> exp.Select:
    """Helper: parse a bare SELECT clause into a sqlglot Select node."""
    ast = sqlglot.parse_one(sql, dialect="bigquery")
    assert isinstance(ast, exp.Select)
    return ast


def _parse_with_sql(sql: str) -> tuple[list, exp.Select]:
    """Helper: parse a WITH ... SELECT statement and return (cte_list, outer_select)."""
    ast = sqlglot.parse_one(sql, dialect="bigquery")
    assert isinstance(ast, exp.Select)
    with_clause = ast.args.get("with_")
    assert with_clause is not None, "SQL must have a WITH clause"
    return list(with_clause.expressions), ast


# ---------------------------------------------------------------------------
# _extract_cte_output_columns
# ---------------------------------------------------------------------------


def test_extract_cte_output_columns_basic():
    sel = _parse_cte_select("SELECT a, b, c FROM t")
    cols, star = _extract_cte_output_columns(sel)
    assert cols == ["a", "b", "c"]
    assert star is False


def test_extract_cte_output_columns_alias_used():
    """Alias is the visible name — should be returned, not source name."""
    sel = _parse_cte_select("SELECT station_id AS id, name FROM t")
    cols, star = _extract_cte_output_columns(sel)
    assert "id" in cols
    assert "station_id" not in cols
    assert "name" in cols
    assert star is False


def test_extract_cte_output_columns_star():
    sel = _parse_cte_select("SELECT * FROM t")
    cols, star = _extract_cte_output_columns(sel)
    assert star is True
    assert cols == []


def test_extract_cte_output_columns_table_star():
    sel = _parse_cte_select("SELECT t.* FROM t")
    cols, star = _extract_cte_output_columns(sel)
    assert star is True


# ---------------------------------------------------------------------------
# _is_cte_star_consumed
# ---------------------------------------------------------------------------


def test_is_cte_star_consumed_outer_select_star():
    """Outer SELECT * FROM cte → star consumed."""
    cte_list, outer = _parse_with_sql(
        "WITH base AS (SELECT a, b FROM raw) SELECT * FROM base"
    )
    assert _is_cte_star_consumed("base", [], outer) is True


def test_is_cte_star_consumed_outer_select_explicit():
    """Outer SELECT a, b FROM cte → NOT star consumed."""
    cte_list, outer = _parse_with_sql(
        "WITH base AS (SELECT a, b FROM raw) SELECT a, b FROM base"
    )
    assert _is_cte_star_consumed("base", [], outer) is False


def test_is_cte_star_consumed_subsequent_cte_star():
    """Subsequent CTE does SELECT * FROM our CTE → star consumed."""
    cte_list, outer = _parse_with_sql(
        "WITH "
        "base AS (SELECT a, b FROM raw), "
        "passthrough AS (SELECT * FROM base) "
        "SELECT a FROM passthrough"
    )
    # base is at index 0; passthrough is at index 1
    subsequent = cte_list[1:]
    assert _is_cte_star_consumed("base", subsequent, outer) is True


def test_is_cte_star_consumed_star_of_different_cte():
    """Outer SELECT * FROM other_cte — does NOT consume our CTE."""
    cte_list, outer = _parse_with_sql(
        "WITH "
        "base AS (SELECT a, b FROM raw), "
        "final AS (SELECT a FROM base) "
        "SELECT * FROM final"
    )
    # base at index 0, subsequent = [final_cte], outer has SELECT * FROM final
    subsequent = cte_list[1:]
    # star is from 'final', not 'base' → base is NOT star-consumed
    assert _is_cte_star_consumed("base", subsequent, outer) is False


def test_is_cte_star_consumed_table_dot_star_with_alias():
    """Subsequent CTE uses SELECT alias.* FROM base alias → star consumed."""
    cte_list, outer = _parse_with_sql(
        "WITH "
        "base AS (SELECT a, b FROM raw), "
        "next AS (SELECT b.* FROM base b) "
        "SELECT a FROM next"
    )
    subsequent = cte_list[1:]
    assert _is_cte_star_consumed("base", subsequent, outer) is True


# ---------------------------------------------------------------------------
# _collect_col_refs
# ---------------------------------------------------------------------------


def test_collect_col_refs_basic():
    ast = sqlglot.parse_one("SELECT x.a, x.b FROM base x WHERE x.c = 1")
    refs = _collect_col_refs(ast)
    assert {"a", "b", "c"}.issubset(refs)


def test_collect_col_refs_excludes_star():
    ast = sqlglot.parse_one("SELECT * FROM t")
    refs = _collect_col_refs(ast)
    assert "*" not in refs


# ---------------------------------------------------------------------------
# analyze_all_intra_model — end-to-end
# ---------------------------------------------------------------------------


def _intra_node(name: str, sql: str, materialized: str = "table") -> dict:
    return {
        "name": name,
        "unique_id": f"model.proj.{name}",
        "database": "proj",
        "schema": "dbt",
        "identifier": name,
        "config": {"materialized": materialized},
        "raw_code": sql,
        "compiled_code": sql,
    }


def _intra_manifest(nodes: dict) -> dict:
    child_map = {uid: [] for uid in nodes}
    return {"nodes": nodes, "child_map": child_map}


def test_analyze_intra_model_basic_dead_columns():
    """base CTE selects 4 cols; final only uses 2 → 2 dead in base."""
    sql = """
WITH
  base AS (
    SELECT station_id, name, elevation, country_code FROM raw_stations
  ),
  final AS (
    SELECT station_id, name FROM base
  )
SELECT station_id, name FROM final
"""
    manifest = _intra_manifest({"model.proj.stg": _intra_node("stg", sql)})
    results = analyze_all_intra_model(manifest, min_dead_columns=1)
    assert len(results) == 1
    result = results[0]
    assert result.model_name == "stg"
    assert len(result.cte_dead_columns) == 1
    cte = result.cte_dead_columns[0]
    assert cte.cte_name == "base"
    assert set(cte.dead_columns) == {"elevation", "country_code"}


def test_analyze_intra_model_all_columns_used():
    """All CTE columns are referenced — no dead columns."""
    sql = """
WITH
  base AS (SELECT a, b FROM raw)
SELECT a, b FROM base
"""
    manifest = _intra_manifest({"model.proj.m": _intra_node("m", sql)})
    results = analyze_all_intra_model(manifest, min_dead_columns=1)
    assert results == []


def test_analyze_intra_model_no_ctes():
    """Model without CTEs — no intra-model dead columns."""
    sql = "SELECT a, b, c FROM raw_table"
    manifest = _intra_manifest({"model.proj.m": _intra_node("m", sql)})
    results = analyze_all_intra_model(manifest, min_dead_columns=1)
    assert results == []


def test_analyze_intra_model_star_in_cte_skips():
    """CTE with SELECT * is skipped (can't determine its output columns)."""
    sql = """
WITH
  base AS (SELECT * FROM raw),
  final AS (SELECT a FROM base)
SELECT a FROM final
"""
    manifest = _intra_manifest({"model.proj.m": _intra_node("m", sql)})
    results = analyze_all_intra_model(manifest, min_dead_columns=1)
    assert results == []


def test_analyze_intra_model_star_consumed_skips():
    """Subsequent CTE does SELECT * FROM base → base is not flagged."""
    sql = """
WITH
  base AS (SELECT a, b, c FROM raw),
  passthrough AS (SELECT * FROM base)
SELECT a FROM passthrough
"""
    manifest = _intra_manifest({"model.proj.m": _intra_node("m", sql)})
    results = analyze_all_intra_model(manifest, min_dead_columns=1)
    assert results == []


def test_analyze_intra_model_outer_star_consumed_skips():
    """Outer SELECT * FROM cte → that CTE is not flagged for dead columns."""
    sql = """
WITH
  base AS (SELECT a, b, c FROM raw)
SELECT * FROM base
"""
    manifest = _intra_manifest({"model.proj.m": _intra_node("m", sql)})
    results = analyze_all_intra_model(manifest, min_dead_columns=1)
    assert results == []


def test_analyze_intra_model_multiple_ctes_multiple_dead():
    """Two CTEs both have dead columns."""
    sql = """
WITH
  step1 AS (SELECT a, b, dead1 FROM raw),
  step2 AS (SELECT a, b, dead2 FROM step1),
  final AS (SELECT a, b FROM step2)
SELECT a, b FROM final
"""
    manifest = _intra_manifest({"model.proj.m": _intra_node("m", sql)})
    results = analyze_all_intra_model(manifest, min_dead_columns=1)
    assert len(results) == 1
    cte_names = {c.cte_name for c in results[0].cte_dead_columns}
    # step1 selects dead1 which step2 never references
    # step2 selects dead2 which final never references
    assert "step1" in cte_names
    assert "step2" in cte_names


def test_analyze_intra_model_ephemeral_skipped():
    sql = """
WITH base AS (SELECT a, b, c FROM raw)
SELECT a FROM base
"""
    manifest = _intra_manifest(
        {"model.proj.eph": _intra_node("eph", sql, materialized="ephemeral")}
    )
    results = analyze_all_intra_model(manifest, min_dead_columns=1)
    assert results == []


def test_analyze_intra_model_excluded_pattern():
    sql = """
WITH base AS (SELECT a, _loaded_at, dead_col FROM raw)
SELECT a FROM base
"""
    manifest = _intra_manifest({"model.proj.m": _intra_node("m", sql)})
    results = analyze_all_intra_model(
        manifest, min_dead_columns=1, excluded_patterns=["^_loaded_at$"]
    )
    assert len(results) == 1
    dead = results[0].cte_dead_columns[0].dead_columns
    assert "_loaded_at" not in dead
    assert "dead_col" in dead


def test_analyze_intra_model_alias_is_visible_name():
    """Subsequent CTE uses the alias name, not the source column name."""
    sql = """
WITH
  base AS (SELECT station_id AS sid, name FROM raw),
  final AS (SELECT sid, name FROM base)
SELECT sid, name FROM final
"""
    manifest = _intra_manifest({"model.proj.m": _intra_node("m", sql)})
    results = analyze_all_intra_model(manifest, min_dead_columns=1)
    # Both alias 'sid' and 'name' are referenced → no dead columns
    assert results == []


def test_analyze_intra_model_alias_dead_when_not_referenced():
    """Alias 'sid' is never referenced downstream → dead."""
    sql = """
WITH
  base AS (SELECT station_id AS sid, name FROM raw),
  final AS (SELECT name FROM base)
SELECT name FROM final
"""
    manifest = _intra_manifest({"model.proj.m": _intra_node("m", sql)})
    results = analyze_all_intra_model(manifest, min_dead_columns=1)
    assert len(results) == 1
    assert "sid" in results[0].cte_dead_columns[0].dead_columns


def test_analyze_intra_model_min_dead_columns_threshold():
    """min_dead_columns=2: a CTE with only 1 dead column is suppressed."""
    sql = """
WITH
  base AS (SELECT a, b, dead1 FROM raw)
SELECT a, b FROM base
"""
    manifest = _intra_manifest({"model.proj.m": _intra_node("m", sql)})
    results = analyze_all_intra_model(manifest, min_dead_columns=2)
    assert results == []


# ---------------------------------------------------------------------------
# analyze_all_dead_ctes — end-to-end
# ---------------------------------------------------------------------------


def test_analyze_dead_ctes_basic():
    sql = """
WITH
  used_stage AS (SELECT id, amount FROM raw_orders),
  unused_stage AS (SELECT customer_id, order_id FROM raw_customers),
  final AS (SELECT id, amount FROM used_stage)
SELECT id, amount FROM final
"""
    manifest = _intra_manifest({"model.proj.m": _intra_node("m", sql)})

    results = analyze_all_dead_ctes(manifest, min_dead_ctes=1)

    assert len(results) == 1
    assert results[0].dead_ctes == ["unused_stage"]
    assert results[0].total_cte_count == 3


def test_analyze_dead_ctes_marks_transitive_dead_chain():
    sql = """
WITH
  dead_base AS (SELECT id FROM raw_orders),
  dead_mid AS (SELECT id FROM dead_base)
SELECT 1 AS sentinel
"""
    manifest = _intra_manifest({"model.proj.m": _intra_node("m", sql)})

    results = analyze_all_dead_ctes(manifest, min_dead_ctes=1)

    assert len(results) == 1
    assert results[0].dead_ctes == ["dead_base", "dead_mid"]


def test_analyze_dead_ctes_skips_when_all_ctes_reachable():
    sql = """
WITH
  base AS (SELECT id FROM raw_orders),
  final AS (SELECT id FROM base)
SELECT id FROM final
"""
    manifest = _intra_manifest({"model.proj.m": _intra_node("m", sql)})

    results = analyze_all_dead_ctes(manifest, min_dead_ctes=1)

    assert results == []


def test_analyze_intra_model_skips_dead_columns_inside_dead_cte():
    sql = """
WITH
  dead_stage AS (
    SELECT id, unused_col FROM raw_orders
  )
SELECT 1 AS sentinel
"""
    manifest = _intra_manifest({"model.proj.m": _intra_node("m", sql)})

    results = analyze_all_intra_model(manifest, min_dead_columns=1)

    assert results == []


def test_analyze_dead_window_outputs_by_category():
    sql = """
WITH
  base AS (
    SELECT
      id,
      ROW_NUMBER() OVER (PARTITION BY id ORDER BY ts) AS rn,
      created_at
    FROM raw_events
  ),
  final AS (
    SELECT id, created_at FROM base
  )
SELECT id, created_at FROM final
"""
    manifest = _intra_manifest({"model.proj.m": _intra_node("m", sql)})
    results = analyze_intra_model_dead_outputs_by_category(
        manifest,
        target_category="window",
        min_dead_columns=1,
    )

    assert len(results) == 1
    assert results[0].cte_dead_columns[0].dead_columns == ["rn"]
    assert results[0].cte_dead_columns[0].dead_column_categories["rn"] == "window"


def test_analyze_unused_aggregation_outputs_by_category():
    sql = """
WITH
  base AS (
    SELECT
      id,
      SUM(amount) AS total_amount,
      COUNT(*) AS row_count
    FROM raw_orders
    GROUP BY id
  ),
  final AS (
    SELECT id FROM base
  )
SELECT id FROM final
"""
    manifest = _intra_manifest({"model.proj.m": _intra_node("m", sql)})
    results = analyze_intra_model_dead_outputs_by_category(
        manifest,
        target_category="aggregate",
        min_dead_columns=1,
    )

    assert len(results) == 1
    assert set(results[0].cte_dead_columns[0].dead_columns) == {
        "total_amount",
        "row_count",
    }


def test_analyze_redundant_order_bys_skips_dead_cte():
    sql = """
WITH
  dead_stage AS (
    SELECT id
    FROM raw_events
    ORDER BY created_at DESC
  )
SELECT 1 AS sentinel
"""
    manifest = _intra_manifest({"model.proj.m": _intra_node("m", sql)})

    results = analyze_redundant_order_bys(manifest, min_redundant_order_bys=1)

    assert results == []


def test_analyze_redundant_order_bys_basic():
    sql = """
WITH
  base AS (
    SELECT id, created_at
    FROM raw_events
    ORDER BY created_at DESC
  ),
  final AS (
    SELECT id FROM base
  )
SELECT id FROM final
"""
    manifest = _intra_manifest({"model.proj.m": _intra_node("m", sql)})

    results = analyze_redundant_order_bys(manifest, min_redundant_order_bys=1)

    assert len(results) == 1
    assert results[0].redundant_order_bys == ["base"]
    assert results[0].total_cte_count == 2


def test_analyze_redundant_order_bys_skips_limit_order_pair():
    sql = """
WITH
  base AS (
    SELECT id, created_at
    FROM raw_events
    ORDER BY created_at DESC
    LIMIT 10
  )
SELECT id FROM base
"""
    manifest = _intra_manifest({"model.proj.m": _intra_node("m", sql)})

    results = analyze_redundant_order_bys(manifest, min_redundant_order_bys=1)

    assert results == []


def test_analyze_unused_joins_basic():
    sql = """
WITH
  rhs AS (
    SELECT customer_id
    FROM raw_customers
    GROUP BY customer_id
  ),
  base AS (
    SELECT
      o.order_id
    FROM raw_orders o
    LEFT JOIN rhs r ON o.customer_id = r.customer_id
  ),
  final AS (
    SELECT order_id FROM base
  )
SELECT order_id FROM final
"""
    manifest = _intra_manifest({"model.proj.m": _intra_node("m", sql)})

    results = analyze_unused_joins(manifest, min_unused_joins=1)

    assert len(results) == 1
    assert results[0].total_join_count == 1
    assert len(results[0].unused_joins) == 1
    unused = results[0].unused_joins[0]
    assert unused.cte_name == "base"
    assert unused.join_alias == "r"
    assert unused.joined_source_name == "rhs"
    assert unused.join_keys == ["customer_id"]


def test_analyze_unused_joins_skips_when_rhs_is_referenced():
    sql = """
WITH
  rhs AS (
    SELECT customer_id
    FROM raw_customers
    GROUP BY customer_id
  ),
  base AS (
    SELECT
      o.order_id,
      r.customer_id
    FROM raw_orders o
    LEFT JOIN rhs r ON o.customer_id = r.customer_id
  )
SELECT order_id FROM base
"""
    manifest = _intra_manifest({"model.proj.m": _intra_node("m", sql)})

    results = analyze_unused_joins(manifest, min_unused_joins=1)

    assert results == []


def test_analyze_unused_joins_skips_unqualified_column_usage():
    sql = """
WITH
  rhs AS (
    SELECT customer_id
    FROM raw_customers
    GROUP BY customer_id
  ),
  base AS (
    SELECT
      order_id
    FROM raw_orders o
    LEFT JOIN rhs r ON o.customer_id = r.customer_id
  )
SELECT order_id FROM base
"""
    manifest = _intra_manifest({"model.proj.m": _intra_node("m", sql)})

    results = analyze_unused_joins(manifest, min_unused_joins=1)

    assert results == []


def test_analyze_unused_joins_skips_dead_cte():
    sql = """
WITH
  rhs AS (
    SELECT customer_id
    FROM raw_customers
    GROUP BY customer_id
  ),
  dead_stage AS (
    SELECT
      o.order_id
    FROM raw_orders o
    LEFT JOIN rhs r ON o.customer_id = r.customer_id
  )
SELECT 1 AS sentinel
"""
    manifest = _intra_manifest({"model.proj.m": _intra_node("m", sql)})

    results = analyze_unused_joins(manifest, min_unused_joins=1)

    assert results == []
