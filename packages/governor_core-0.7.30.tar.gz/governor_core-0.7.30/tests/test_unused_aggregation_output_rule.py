"""Unit tests for app/opportunities/rules/unused_aggregation_output.py."""

import pytest

from governor_core.opportunities.rules.unused_aggregation_output import (
    UnusedAggregationOutputRule,
)


def _manifest() -> dict:
    sql = """
WITH
  base AS (
    SELECT
      id,
      SUM(amount) AS total_amount,
      COUNT(*) AS row_count
    FROM raw_orders
    GROUP BY id
  ),
  final AS (
    SELECT id FROM base
  )
SELECT id FROM final
"""
    return {
        "nodes": {
            "model.proj.fct_orders": {
                "name": "fct_orders",
                "unique_id": "model.proj.fct_orders",
                "database": "my-project",
                "schema": "dbt_prod",
                "identifier": "fct_orders",
                "config": {"materialized": "table"},
                "raw_code": sql,
                "compiled_code": sql,
            }
        },
        "child_map": {"model.proj.fct_orders": []},
    }


def test_rule_type():
    assert UnusedAggregationOutputRule().rule_type == "unused_aggregation_output"


def test_detect_returns_candidate():
    results = UnusedAggregationOutputRule().detect(
        jobs=[],
        manifest_content=_manifest(),
        thresholds={},
    )

    assert len(results) == 1
    candidate = results[0]
    assert candidate.opportunity_type == "unused_aggregation_output"
    assert set(candidate.evidence_snapshot["unused_aggregation_outputs"]) == {
        "total_amount",
        "row_count",
    }
    assert candidate.evidence_snapshot["suppressed_findings"] == [
        {
            "rule_type": "dead_column",
            "display_name": "Dead Column",
            "count": 2,
            "reason": (
                "Hidden because Unused Aggregation Output is the more specific "
                "rule for these unused aggregate expressions."
            ),
            "items": ["base.total_amount", "base.row_count"],
            "ctes": ["base"],
        }
    ]
    assert candidate.confidence == pytest.approx(0.68)
