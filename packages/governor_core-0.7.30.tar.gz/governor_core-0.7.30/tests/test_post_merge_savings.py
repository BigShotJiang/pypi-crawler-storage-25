"""Unit tests for post-merge savings calculator (spec 068)."""

from __future__ import annotations

import uuid
from datetime import datetime, timedelta, timezone
from decimal import Decimal

from governor_core.pullrequests.savings import (
    calculate_verified_savings,
    recalculate_all_pending,
)
from tests.helpers import _create_test_pr_record, _create_test_prereqs


def _create_bq_job(
    db,
    config_id: str,
    sync_id: str,
    destination_table: str,
    creation_time: datetime,
    total_bytes_billed: int,
    cache_hit: bool = False,
):
    """Create a BigQueryJob record for testing."""
    from governor_core.sync.models import BigQueryJob

    job = BigQueryJob(
        id=str(uuid.uuid4()),
        config_id=config_id,
        sync_id=sync_id,
        job_id=f"job_{uuid.uuid4().hex[:16]}",
        user_email="test@test.com",
        creation_time=creation_time,
        job_state="DONE",
        total_bytes_billed=total_bytes_billed,
        cache_hit=cache_hit,
        destination_table=destination_table,
    )
    db.add(job)
    return job


class TestCalculateVerifiedSavings:
    """Tests for calculate_verified_savings()."""

    def test_no_pr_record_returns_insufficient_data(self, client, db):
        """Opportunity with no PR record → insufficient_data."""
        prereqs = _create_test_prereqs(db)
        opp = prereqs["opportunity"]

        status = calculate_verified_savings(db, opp)

        assert status == "insufficient_data"
        assert opp.verified_savings_status == "insufficient_data"

    def test_pr_not_merged_returns_insufficient_data(self, client, db):
        """PR exists but not merged → insufficient_data."""
        prereqs = _create_test_prereqs(db)
        opp = prereqs["opportunity"]
        _create_test_pr_record(db, prereqs, status="open")
        # merged_at is None by default

        status = calculate_verified_savings(db, opp)

        assert status == "insufficient_data"

    def test_insufficient_baseline_data(self, client, db):
        """Not enough pre-merge jobs → insufficient_data."""
        prereqs = _create_test_prereqs(db)
        opp = prereqs["opportunity"]
        merged_at = datetime.now(timezone.utc) - timedelta(days=20)
        _create_test_pr_record(db, prereqs, status="merged", merged_at=merged_at)

        # Only 1 pre-merge job (need MIN_JOBS_FOR_BASELINE=3)
        _create_bq_job(
            db,
            config_id=opp.config_id,
            sync_id=prereqs["sync_op"].id,
            destination_table=opp.affected_table,
            creation_time=merged_at - timedelta(days=5),
            total_bytes_billed=1_000_000_000,
        )
        db.commit()

        status = calculate_verified_savings(db, opp)

        assert status == "insufficient_data"
        assert opp.verified_savings is None

    def test_collecting_status_when_not_enough_post_merge_jobs(self, client, db):
        """Enough pre-merge but not enough post-merge within window → collecting."""
        prereqs = _create_test_prereqs(db)
        opp = prereqs["opportunity"]
        merged_at = datetime.now(timezone.utc) - timedelta(days=5)
        _create_test_pr_record(db, prereqs, status="merged", merged_at=merged_at)

        # 3 pre-merge jobs
        for i in range(3):
            _create_bq_job(
                db,
                config_id=opp.config_id,
                sync_id=prereqs["sync_op"].id,
                destination_table=opp.affected_table,
                creation_time=merged_at - timedelta(days=i + 1),
                total_bytes_billed=1_000_000_000,
            )
        # Only 1 post-merge job
        _create_bq_job(
            db,
            config_id=opp.config_id,
            sync_id=prereqs["sync_op"].id,
            destination_table=opp.affected_table,
            creation_time=merged_at + timedelta(days=1),
            total_bytes_billed=500_000_000,
        )
        db.commit()

        status = calculate_verified_savings(db, opp)

        assert status == "collecting"
        assert opp.verified_savings is None
        assert opp.pre_merge_job_count == 3

    def test_confirmed_savings(self, client, db):
        """Both windows have enough data and costs dropped → confirmed."""
        prereqs = _create_test_prereqs(db)
        opp = prereqs["opportunity"]
        merged_at = datetime.now(timezone.utc) - timedelta(days=20)
        _create_test_pr_record(db, prereqs, status="merged", merged_at=merged_at)

        # 3 pre-merge jobs at 10 GiB each
        pre_bytes = 10 * (1024**3)  # 10 GiB
        for i in range(3):
            _create_bq_job(
                db,
                config_id=opp.config_id,
                sync_id=prereqs["sync_op"].id,
                destination_table=opp.affected_table,
                creation_time=merged_at - timedelta(days=i + 1),
                total_bytes_billed=pre_bytes,
            )

        # 3 post-merge jobs at 2 GiB each (cost reduction)
        post_bytes = 2 * (1024**3)  # 2 GiB
        for i in range(3):
            _create_bq_job(
                db,
                config_id=opp.config_id,
                sync_id=prereqs["sync_op"].id,
                destination_table=opp.affected_table,
                creation_time=merged_at + timedelta(days=i + 1),
                total_bytes_billed=post_bytes,
            )
        db.commit()

        status = calculate_verified_savings(db, opp)

        assert status == "confirmed"
        assert opp.verified_savings is not None
        assert opp.verified_savings > Decimal("0")
        assert opp.pre_merge_job_count == 3
        assert opp.post_merge_job_count == 3
        assert opp.pre_merge_avg_cost > opp.post_merge_avg_cost

    def test_negative_savings(self, client, db):
        """Costs increased after merge → negative."""
        prereqs = _create_test_prereqs(db)
        opp = prereqs["opportunity"]
        merged_at = datetime.now(timezone.utc) - timedelta(days=20)
        _create_test_pr_record(db, prereqs, status="merged", merged_at=merged_at)

        # 3 pre-merge jobs at 2 GiB each
        pre_bytes = 2 * (1024**3)
        for i in range(3):
            _create_bq_job(
                db,
                config_id=opp.config_id,
                sync_id=prereqs["sync_op"].id,
                destination_table=opp.affected_table,
                creation_time=merged_at - timedelta(days=i + 1),
                total_bytes_billed=pre_bytes,
            )

        # 3 post-merge jobs at 10 GiB each (cost increased!)
        post_bytes = 10 * (1024**3)
        for i in range(3):
            _create_bq_job(
                db,
                config_id=opp.config_id,
                sync_id=prereqs["sync_op"].id,
                destination_table=opp.affected_table,
                creation_time=merged_at + timedelta(days=i + 1),
                total_bytes_billed=post_bytes,
            )
        db.commit()

        status = calculate_verified_savings(db, opp)

        assert status == "negative"
        assert opp.verified_savings < Decimal("0")

    def test_cache_hits_excluded(self, client, db):
        """Cache-hit jobs are excluded from cost calculation."""
        prereqs = _create_test_prereqs(db)
        opp = prereqs["opportunity"]
        merged_at = datetime.now(timezone.utc) - timedelta(days=20)
        _create_test_pr_record(db, prereqs, status="merged", merged_at=merged_at)

        # 3 pre-merge jobs + 2 cache hits
        for i in range(3):
            _create_bq_job(
                db,
                config_id=opp.config_id,
                sync_id=prereqs["sync_op"].id,
                destination_table=opp.affected_table,
                creation_time=merged_at - timedelta(days=i + 1),
                total_bytes_billed=10 * (1024**3),
            )
        for i in range(2):
            _create_bq_job(
                db,
                config_id=opp.config_id,
                sync_id=prereqs["sync_op"].id,
                destination_table=opp.affected_table,
                creation_time=merged_at - timedelta(days=i + 1, hours=1),
                total_bytes_billed=0,
                cache_hit=True,
            )

        # 3 post-merge jobs
        for i in range(3):
            _create_bq_job(
                db,
                config_id=opp.config_id,
                sync_id=prereqs["sync_op"].id,
                destination_table=opp.affected_table,
                creation_time=merged_at + timedelta(days=i + 1),
                total_bytes_billed=2 * (1024**3),
            )
        db.commit()

        status = calculate_verified_savings(db, opp)

        # Cache hits shouldn't affect the count
        assert opp.pre_merge_job_count == 3
        assert status == "confirmed"


class TestRecalculateAllPending:
    """Tests for recalculate_all_pending()."""

    def test_no_pending_opportunities(self, client, db):
        """No pending/collecting opportunities → zero counts."""
        result = recalculate_all_pending(db)

        assert result["processed"] == 0

    def test_processes_pending_opportunity(self, client, db):
        """Pending opportunity gets processed."""
        prereqs = _create_test_prereqs(db)
        opp = prereqs["opportunity"]
        opp.verified_savings_status = "pending"
        db.commit()

        result = recalculate_all_pending(db)

        assert result["processed"] == 1
        # Will be insufficient_data since there's no PR
        assert result["insufficient_data"] == 1

    def test_processes_collecting_opportunity(self, client, db):
        """Collecting opportunity gets reprocessed."""
        prereqs = _create_test_prereqs(db)
        opp = prereqs["opportunity"]
        opp.verified_savings_status = "collecting"
        db.commit()

        result = recalculate_all_pending(db)

        assert result["processed"] == 1

    def test_skips_confirmed_opportunity(self, client, db):
        """Already confirmed opportunities are not reprocessed."""
        prereqs = _create_test_prereqs(db)
        opp = prereqs["opportunity"]
        opp.verified_savings_status = "confirmed"
        opp.verified_savings = Decimal("1.50")
        db.commit()

        result = recalculate_all_pending(db)

        assert result["processed"] == 0
