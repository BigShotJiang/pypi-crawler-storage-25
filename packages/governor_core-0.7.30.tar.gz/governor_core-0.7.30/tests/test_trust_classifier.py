"""Tests for change classifier and allowlists.

Covers:
- app/solutions/validation/classifier.py (classify_change, classify_yaml_change, classification_to_trust_tier)
- app/solutions/validation/allowlists.py (ALLOWLISTS, ChangeCategory)
"""

from __future__ import annotations

from governor_core.solutions.validation.allowlists import ALLOWLISTS, ChangeCategory
from governor_core.solutions.validation.ast_validator import StructuralComparison
from governor_core.solutions.validation.classifier import (
    ChangeClassification,
    classification_to_trust_tier,
    classify_change,
    classify_yaml_change,
)
from governor_core.solutions.validation.yaml_validator import YamlComparison


# ---------------------------------------------------------------------------
# Helper: build a StructuralComparison with specific overrides
# ---------------------------------------------------------------------------


def _comparison(**overrides) -> StructuralComparison:
    """Create a StructuralComparison with sensible defaults and overrides."""
    return StructuralComparison(**overrides)


# ===========================================================================
# classify_change tests
# ===========================================================================


class TestClassifyChangeDestructive:
    """Any removal in the StructuralComparison yields DESTRUCTIVE."""

    def test_columns_removed_is_destructive(self):
        comp = _comparison(columns_removed=["col_a"])
        result = classify_change(comp, "shuffle_spill")
        assert result == ChangeClassification.DESTRUCTIVE

    def test_ctes_removed_is_destructive(self):
        comp = _comparison(ctes_removed=["cte_deduped"])
        result = classify_change(comp, "shuffle_spill")
        assert result == ChangeClassification.DESTRUCTIVE

    def test_joins_removed_is_destructive(self):
        comp = _comparison(joins_removed=["dim_users"])
        result = classify_change(comp, "slot_contention")
        assert result == ChangeClassification.DESTRUCTIVE


class TestClassifyChangeModification:
    """Modifications (without removals) yield MODIFICATION."""

    def test_where_changed_is_modification(self):
        comp = _comparison(where_changed=True)
        result = classify_change(comp, "shuffle_spill")
        assert result == ChangeClassification.MODIFICATION

    def test_group_by_changed_is_modification(self):
        comp = _comparison(group_by_changed=True)
        result = classify_change(comp, "partition_pruning")
        assert result == ChangeClassification.MODIFICATION

    def test_order_by_changed_is_modification(self):
        comp = _comparison(order_by_changed=True)
        result = classify_change(comp, "shuffle_spill")
        assert result == ChangeClassification.MODIFICATION

    def test_columns_modified_is_modification(self):
        comp = _comparison(columns_modified=["total_amount"])
        result = classify_change(comp, "join_explosion")
        assert result == ChangeClassification.MODIFICATION


class TestClassifyChangeAdditiveAllowlisted:
    """Additive changes within the opportunity-type allowlist yield ADDITIVE_ALLOWLISTED."""

    def test_config_changes_for_shuffle_spill(self):
        # shuffle_spill allowlist: {CONFIG_PROPERTY_ADDITION}
        comp = _comparison(config_changes=["config_only_change"])
        result = classify_change(comp, "shuffle_spill")
        assert result == ChangeClassification.ADDITIVE_ALLOWLISTED

    def test_config_changes_for_slot_contention(self):
        # slot_contention allowlist: {CONFIG_PROPERTY_ADDITION, FILTER_ADDITION}
        comp = _comparison(config_changes=["jinja_config_block_changed"])
        result = classify_change(comp, "slot_contention")
        assert result == ChangeClassification.ADDITIVE_ALLOWLISTED

    def test_config_changes_for_partition_pruning(self):
        # partition_pruning allowlist: {CONFIG_PROPERTY_ADDITION, FILTER_ADDITION}
        comp = _comparison(config_changes=["config_only_change"])
        result = classify_change(comp, "partition_pruning")
        assert result == ChangeClassification.ADDITIVE_ALLOWLISTED


class TestClassifyChangeAdditiveNotAllowlisted:
    """Additive changes NOT on the opportunity-type allowlist yield ADDITIVE_NOT_ALLOWLISTED."""

    def test_joins_added_for_shuffle_spill(self):
        # shuffle_spill allowlist has only CONFIG_PROPERTY_ADDITION
        # JOIN_ADDITION is not in the allowlist
        comp = _comparison(joins_added=["fact_orders"])
        result = classify_change(comp, "shuffle_spill")
        assert result == ChangeClassification.ADDITIVE_NOT_ALLOWLISTED

    def test_columns_added_for_shuffle_spill(self):
        # COLUMN_ADDITION is not in shuffle_spill's allowlist
        comp = _comparison(columns_added=["new_col"])
        result = classify_change(comp, "shuffle_spill")
        assert result == ChangeClassification.ADDITIVE_NOT_ALLOWLISTED

    def test_ctes_added_for_join_explosion(self):
        # join_explosion allowlist: {FILTER_ADDITION}
        # CTE_ADDITION is not in the allowlist
        comp = _comparison(ctes_added=["cte_filtered"])
        result = classify_change(comp, "join_explosion")
        assert result == ChangeClassification.ADDITIVE_NOT_ALLOWLISTED

    def test_joins_added_for_partition_pruning(self):
        # partition_pruning allowlist: {CONFIG_PROPERTY_ADDITION, FILTER_ADDITION}
        # JOIN_ADDITION is not in the allowlist
        comp = _comparison(joins_added=["dim_dates"])
        result = classify_change(comp, "partition_pruning")
        assert result == ChangeClassification.ADDITIVE_NOT_ALLOWLISTED


class TestClassifyChangeNoChanges:
    """No changes at all yields ADDITIVE_ALLOWLISTED (no-op is safe)."""

    def test_empty_comparison_is_allowlisted(self):
        comp = _comparison()
        result = classify_change(comp, "shuffle_spill")
        assert result == ChangeClassification.ADDITIVE_ALLOWLISTED

    def test_empty_comparison_unknown_type_is_allowlisted(self):
        # Even for an unknown opportunity type, no-op is safe
        comp = _comparison()
        result = classify_change(comp, "unknown_type")
        assert result == ChangeClassification.ADDITIVE_ALLOWLISTED


class TestClassifyChangePriorityOrder:
    """Destructive takes priority over modification, modification over additive."""

    def test_destructive_overrides_modification(self):
        comp = _comparison(
            columns_removed=["dropped_col"],
            where_changed=True,
        )
        result = classify_change(comp, "shuffle_spill")
        assert result == ChangeClassification.DESTRUCTIVE

    def test_modification_overrides_additive(self):
        comp = _comparison(
            where_changed=True,
            config_changes=["config_only_change"],
        )
        result = classify_change(comp, "shuffle_spill")
        assert result == ChangeClassification.MODIFICATION


class TestClassifyChangeUnknownOpportunityType:
    """Unknown opportunity type has empty allowlist (default deny)."""

    def test_unknown_type_with_additions_is_not_allowlisted(self):
        comp = _comparison(config_changes=["config_only_change"])
        result = classify_change(comp, "nonexistent_opportunity_type")
        assert result == ChangeClassification.ADDITIVE_NOT_ALLOWLISTED


# ===========================================================================
# classify_yaml_change tests
# ===========================================================================


class TestClassifyYamlChange:
    """YAML classification is simpler: removals -> DESTRUCTIVE, modifications -> MODIFICATION,
    additions -> ADDITIVE_NOT_ALLOWLISTED (always requires review), no changes -> ADDITIVE_ALLOWLISTED."""

    def test_yaml_removals_are_destructive(self):
        comp = YamlComparison(keys_removed=["models.my_model"])
        result = classify_yaml_change(comp)
        assert result == ChangeClassification.DESTRUCTIVE

    def test_yaml_modifications_are_modification(self):
        comp = YamlComparison(keys_modified=["models.my_model.description"])
        result = classify_yaml_change(comp)
        assert result == ChangeClassification.MODIFICATION

    def test_yaml_additions_are_not_allowlisted(self):
        comp = YamlComparison(keys_added=["models.new_model"])
        result = classify_yaml_change(comp)
        assert result == ChangeClassification.ADDITIVE_NOT_ALLOWLISTED

    def test_yaml_no_changes_is_allowlisted(self):
        comp = YamlComparison()
        result = classify_yaml_change(comp)
        assert result == ChangeClassification.ADDITIVE_ALLOWLISTED

    def test_yaml_removal_overrides_modification(self):
        comp = YamlComparison(
            keys_removed=["models.old"],
            keys_modified=["models.changed"],
        )
        result = classify_yaml_change(comp)
        assert result == ChangeClassification.DESTRUCTIVE

    def test_yaml_modification_overrides_addition(self):
        comp = YamlComparison(
            keys_modified=["models.changed"],
            keys_added=["models.new"],
        )
        result = classify_yaml_change(comp)
        assert result == ChangeClassification.MODIFICATION


# ===========================================================================
# classification_to_trust_tier tests
# ===========================================================================


class TestClassificationToTrustTier:
    """Verify trust tier mapping for each classification value."""

    def test_additive_allowlisted_maps_to_validated(self):
        assert (
            classification_to_trust_tier(ChangeClassification.ADDITIVE_ALLOWLISTED)
            == "validated"
        )

    def test_additive_not_allowlisted_maps_to_requires_review(self):
        assert (
            classification_to_trust_tier(ChangeClassification.ADDITIVE_NOT_ALLOWLISTED)
            == "requires_review"
        )

    def test_modification_maps_to_requires_review(self):
        assert (
            classification_to_trust_tier(ChangeClassification.MODIFICATION)
            == "requires_review"
        )

    def test_destructive_maps_to_requires_review(self):
        # DESTRUCTIVE maps to requires_review at tier level; blocking is
        # handled at the caller level.
        assert (
            classification_to_trust_tier(ChangeClassification.DESTRUCTIVE)
            == "requires_review"
        )


# ===========================================================================
# ALLOWLISTS tests (app/solutions/validation/allowlists.py)
# ===========================================================================


class TestAllowlistShufflespill:
    """shuffle_spill allows CONFIG_PROPERTY_ADDITION only."""

    def test_shuffle_spill_allowlist(self):
        allowed = ALLOWLISTS["shuffle_spill"]
        assert allowed == {ChangeCategory.CONFIG_PROPERTY_ADDITION}

    def test_shuffle_spill_does_not_allow_filter(self):
        assert ChangeCategory.FILTER_ADDITION not in ALLOWLISTS["shuffle_spill"]

    def test_shuffle_spill_does_not_allow_join(self):
        assert ChangeCategory.JOIN_ADDITION not in ALLOWLISTS["shuffle_spill"]


class TestAllowlistSlotContention:
    """slot_contention allows CONFIG_PROPERTY_ADDITION + FILTER_ADDITION."""

    def test_slot_contention_allowlist(self):
        allowed = ALLOWLISTS["slot_contention"]
        assert allowed == {
            ChangeCategory.CONFIG_PROPERTY_ADDITION,
            ChangeCategory.FILTER_ADDITION,
        }


class TestAllowlistJoinExplosion:
    """join_explosion allows CONFIG_PROPERTY_ADDITION + FILTER_ADDITION."""

    def test_join_explosion_allowlist(self):
        allowed = ALLOWLISTS["join_explosion"]
        assert allowed == {
            ChangeCategory.CONFIG_PROPERTY_ADDITION,
            ChangeCategory.FILTER_ADDITION,
        }

    def test_join_explosion_allows_config(self):
        assert ChangeCategory.CONFIG_PROPERTY_ADDITION in ALLOWLISTS["join_explosion"]


class TestAllowlistPartitionPruning:
    """partition_pruning allows CONFIG_PROPERTY_ADDITION + FILTER_ADDITION."""

    def test_partition_pruning_allowlist(self):
        allowed = ALLOWLISTS["partition_pruning"]
        assert allowed == {
            ChangeCategory.CONFIG_PROPERTY_ADDITION,
            ChangeCategory.FILTER_ADDITION,
        }


class TestAllowlistUnknownType:
    """Unknown opportunity types get an empty allowlist (default deny)."""

    def test_unknown_type_returns_empty_set(self):
        allowed = ALLOWLISTS.get("totally_unknown_type", set())
        assert allowed == set()

    def test_missing_key_not_in_allowlists(self):
        assert "totally_unknown_type" not in ALLOWLISTS
