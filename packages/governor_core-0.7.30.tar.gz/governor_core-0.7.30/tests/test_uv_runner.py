"""Unit tests for DbtUvRunner (app/dbt/uv_runner.py).

Tests uv venv management, dbt compile via subprocess, and dbt parse
for the spec 050 Docker → uv migration.
"""

from __future__ import annotations

import subprocess
import threading
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

from governor_core.dbt.uv_runner import CompileResult, DbtUvRunner, ParseResult


def _mock_settings(**overrides):
    """Create mock settings with uv defaults."""
    defaults = {
        "dbt_compile_timeout": 120,
        "dbt_compile_enabled": True,
        "dry_run_validation_enabled": True,
        "dbt_default_version": "1.9.0",
        "dbt_venv_base_dir": "/tmp/test-dbt-venvs",
    }
    defaults.update(overrides)
    mock = MagicMock()
    for k, v in defaults.items():
        setattr(mock, k, v)
    return mock


# --- is_available() tests ---


class TestIsAvailable:
    """Tests for DbtUvRunner.is_available()."""

    @patch("governor_core.dbt.uv_runner.subprocess")
    @patch("governor_core.dbt.uv_runner.get_settings")
    def test_returns_true_when_uv_responds(self, mock_settings, mock_subprocess):
        """Should return True when uv --version succeeds."""
        mock_settings.return_value = _mock_settings()
        mock_subprocess.run.return_value = MagicMock(returncode=0)
        mock_subprocess.TimeoutExpired = subprocess.TimeoutExpired

        runner = DbtUvRunner(venv_base_dir="/tmp/test-venvs")
        assert runner.is_available() is True

    @patch("governor_core.dbt.uv_runner.subprocess")
    @patch("governor_core.dbt.uv_runner.get_settings")
    def test_returns_false_when_uv_not_installed(self, mock_settings, mock_subprocess):
        """Should return False when uv is not found."""
        mock_settings.return_value = _mock_settings()
        mock_subprocess.run.side_effect = FileNotFoundError("uv not found")
        mock_subprocess.TimeoutExpired = subprocess.TimeoutExpired

        runner = DbtUvRunner(venv_base_dir="/tmp/test-venvs")
        assert runner.is_available() is False

    @patch("governor_core.dbt.uv_runner.subprocess")
    @patch("governor_core.dbt.uv_runner.get_settings")
    def test_returns_false_when_uv_times_out(self, mock_settings, mock_subprocess):
        """Should return False when uv --version times out."""
        mock_settings.return_value = _mock_settings()
        mock_subprocess.run.side_effect = subprocess.TimeoutExpired(cmd="uv", timeout=5)
        mock_subprocess.TimeoutExpired = subprocess.TimeoutExpired

        runner = DbtUvRunner(venv_base_dir="/tmp/test-venvs")
        assert runner.is_available() is False

    @patch("governor_core.dbt.uv_runner.subprocess")
    @patch("governor_core.dbt.uv_runner.get_settings")
    def test_never_raises(self, mock_settings, mock_subprocess):
        """is_available() should never raise, even on unexpected errors."""
        mock_settings.return_value = _mock_settings()
        mock_subprocess.run.side_effect = OSError("unexpected error")
        mock_subprocess.TimeoutExpired = subprocess.TimeoutExpired

        runner = DbtUvRunner(venv_base_dir="/tmp/test-venvs")
        result = runner.is_available()
        assert result is False


# --- ensure_venv() tests ---


class TestEnsureVenv:
    """Tests for DbtUvRunner.ensure_venv()."""

    @patch("governor_core.dbt.uv_runner.subprocess")
    @patch("governor_core.dbt.uv_runner.get_settings")
    def test_returns_existing_venv_when_marker_exists(
        self, mock_settings, mock_subprocess, tmp_path
    ):
        """Should return existing venv path when .governor-ready marker exists."""
        mock_settings.return_value = _mock_settings()
        venv_dir = tmp_path / "1.9.0"
        venv_dir.mkdir()
        (venv_dir / ".governor-ready").write_text("1.9.0")

        runner = DbtUvRunner(venv_base_dir=str(tmp_path))
        result = runner.ensure_venv("1.9.0")

        assert result == venv_dir
        mock_subprocess.run.assert_not_called()

    @patch("governor_core.dbt.uv_runner.subprocess")
    @patch("governor_core.dbt.uv_runner.get_settings")
    def test_creates_new_venv_when_marker_missing(
        self, mock_settings, mock_subprocess, tmp_path
    ):
        """Should create venv and install dbt when no marker exists."""
        mock_settings.return_value = _mock_settings()
        mock_subprocess.run.return_value = MagicMock(returncode=0)
        mock_subprocess.CalledProcessError = subprocess.CalledProcessError
        mock_subprocess.TimeoutExpired = subprocess.TimeoutExpired

        runner = DbtUvRunner(venv_base_dir=str(tmp_path))
        runner.ensure_venv("1.9.0")

        # Should have called uv venv and uv pip install
        assert mock_subprocess.run.call_count == 2

        # First call: uv venv
        first_call = mock_subprocess.run.call_args_list[0]
        assert "uv" in first_call.args[0][0]
        assert "venv" in first_call.args[0][1]

        # Second call: uv pip install dbt-core=={version} dbt-bigquery
        second_call = mock_subprocess.run.call_args_list[1]
        assert "pip" in second_call.args[0][1]
        assert "dbt-core==1.9.0" in second_call.args[0]
        assert "dbt-bigquery" in second_call.args[0]

        # Marker file should exist
        marker = tmp_path / "1.9.0" / ".governor-ready"
        assert marker.exists()

    @patch("governor_core.dbt.uv_runner.subprocess")
    @patch("governor_core.dbt.uv_runner.get_settings")
    def test_raises_on_venv_creation_failure(
        self, mock_settings, mock_subprocess, tmp_path
    ):
        """Should raise RuntimeError when uv venv fails."""
        mock_settings.return_value = _mock_settings()
        mock_subprocess.run.side_effect = subprocess.CalledProcessError(
            1, "uv venv", stderr=b"Python 3.12 not found"
        )
        mock_subprocess.CalledProcessError = subprocess.CalledProcessError
        mock_subprocess.TimeoutExpired = subprocess.TimeoutExpired

        runner = DbtUvRunner(venv_base_dir=str(tmp_path))
        with pytest.raises(RuntimeError, match="Failed to create dbt venv"):
            runner.ensure_venv("1.9.0")

    @patch("governor_core.dbt.uv_runner.subprocess")
    @patch("governor_core.dbt.uv_runner.get_settings")
    def test_raises_on_install_timeout(self, mock_settings, mock_subprocess, tmp_path):
        """Should raise RuntimeError when dbt install times out."""
        mock_settings.return_value = _mock_settings()
        # First call (venv creation) succeeds, second call (pip install) times out
        mock_subprocess.run.side_effect = [
            MagicMock(returncode=0),
            subprocess.TimeoutExpired(cmd="uv pip install", timeout=300),
        ]
        mock_subprocess.CalledProcessError = subprocess.CalledProcessError
        mock_subprocess.TimeoutExpired = subprocess.TimeoutExpired

        runner = DbtUvRunner(venv_base_dir=str(tmp_path))
        with pytest.raises(RuntimeError, match="Timed out"):
            runner.ensure_venv("1.9.0")

    @patch("governor_core.dbt.uv_runner.subprocess")
    @patch("governor_core.dbt.uv_runner.get_settings")
    def test_concurrent_ensure_venv_creates_once(
        self, mock_settings, mock_subprocess, tmp_path
    ):
        """Concurrent ensure_venv calls should create the venv only once."""
        mock_settings.return_value = _mock_settings()
        mock_subprocess.CalledProcessError = subprocess.CalledProcessError
        mock_subprocess.TimeoutExpired = subprocess.TimeoutExpired
        mock_subprocess.run.return_value = MagicMock(returncode=0)

        runner = DbtUvRunner(venv_base_dir=str(tmp_path))
        results: list[Path] = []
        errors: list[Exception] = []

        def call_ensure():
            try:
                results.append(runner.ensure_venv("1.9.0"))
            except Exception as exc:
                errors.append(exc)

        threads = [threading.Thread(target=call_ensure) for _ in range(4)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()

        assert not errors
        assert len(results) == 4
        # All threads should get the same path
        assert all(r == results[0] for r in results)
        # Marker should exist
        assert (tmp_path / "1.9.0" / ".governor-ready").exists()


# --- compile_model() tests ---


class TestCompileModel:
    """Tests for DbtUvRunner.compile_model()."""

    @patch("governor_core.dbt.uv_runner.get_settings")
    def test_happy_path_returns_compiled_sql(self, mock_settings):
        """Should return CompileResult with compiled_sql on success."""
        mock_settings.return_value = _mock_settings()

        runner = DbtUvRunner(venv_base_dir="/tmp/test-venvs")

        with (
            patch.object(runner, "ensure_venv") as mock_ensure,
            patch("governor_core.dbt.uv_runner.subprocess") as mock_subprocess,
            patch.object(
                runner,
                "_find_compiled_sql",
                return_value="SELECT 1 FROM `proj.ds.table`",
            ),
        ):
            mock_ensure.return_value = Path("/tmp/test-venvs/1.9.0")
            mock_result = MagicMock()
            mock_result.returncode = 0
            mock_result.stdout = "compiled output"
            mock_result.stderr = ""
            mock_subprocess.run.return_value = mock_result
            mock_subprocess.TimeoutExpired = subprocess.TimeoutExpired

            result = runner.compile_model(
                project_dir="/tmp/project",
                model_name="stg_orders",
                dbt_version="1.9.0",
                profiles_dir="/tmp/profiles",
            )

        assert result.success is True
        assert result.compiled_sql == "SELECT 1 FROM `proj.ds.table`"
        assert result.exit_code == 0
        assert result.duration_ms >= 0

    @patch("governor_core.dbt.uv_runner.get_settings")
    def test_target_name_is_passed_to_dbt_compile(self, mock_settings):
        """Should append --target when target_name is provided."""
        mock_settings.return_value = _mock_settings()

        runner = DbtUvRunner(venv_base_dir="/tmp/test-venvs")

        with (
            patch.object(runner, "ensure_venv") as mock_ensure,
            patch("governor_core.dbt.uv_runner.subprocess") as mock_subprocess,
            patch.object(runner, "_find_compiled_sql", return_value="SELECT 1"),
        ):
            mock_ensure.return_value = Path("/tmp/test-venvs/1.9.0")
            mock_result = MagicMock(returncode=0, stdout="", stderr="")
            mock_subprocess.run.return_value = mock_result
            mock_subprocess.TimeoutExpired = subprocess.TimeoutExpired

            runner.compile_model(
                project_dir="/tmp/project",
                model_name="stg_orders",
                dbt_version="1.9.0",
                profiles_dir="/tmp/profiles",
                target_name="dev",
            )

        cmd = mock_subprocess.run.call_args.args[0]
        assert "--target" in cmd
        assert "dev" in cmd

    @patch("governor_core.dbt.uv_runner.get_settings")
    def test_compile_failure_returns_error(self, mock_settings):
        """Should return CompileResult(success=False) when dbt compile fails."""
        mock_settings.return_value = _mock_settings()

        runner = DbtUvRunner(venv_base_dir="/tmp/test-venvs")

        with (
            patch.object(runner, "ensure_venv") as mock_ensure,
            patch("governor_core.dbt.uv_runner.subprocess") as mock_subprocess,
            patch.object(runner, "_find_compiled_sql", return_value=None),
        ):
            mock_ensure.return_value = Path("/tmp/test-venvs/1.9.0")
            mock_result = MagicMock()
            mock_result.returncode = 1
            mock_result.stdout = ""
            mock_result.stderr = "Compilation Error: invalid ref stg_missing"
            mock_subprocess.run.return_value = mock_result
            mock_subprocess.TimeoutExpired = subprocess.TimeoutExpired

            result = runner.compile_model(
                project_dir="/tmp/project",
                model_name="stg_orders",
                dbt_version="1.9.0",
                profiles_dir="/tmp/profiles",
            )

        assert result.success is False
        assert result.exit_code == 1
        assert "Compilation Error" in result.stderr

    @patch("governor_core.dbt.uv_runner.get_settings")
    def test_timeout_returns_failure(self, mock_settings):
        """Should return CompileResult(success=False) on timeout."""
        mock_settings.return_value = _mock_settings()

        runner = DbtUvRunner(venv_base_dir="/tmp/test-venvs")

        with (
            patch.object(runner, "ensure_venv") as mock_ensure,
            patch("governor_core.dbt.uv_runner.subprocess") as mock_subprocess,
        ):
            mock_ensure.return_value = Path("/tmp/test-venvs/1.9.0")
            mock_subprocess.run.side_effect = subprocess.TimeoutExpired(
                cmd="dbt", timeout=120
            )
            mock_subprocess.TimeoutExpired = subprocess.TimeoutExpired

            result = runner.compile_model(
                project_dir="/tmp/project",
                model_name="stg_orders",
                dbt_version="1.9.0",
                profiles_dir="/tmp/profiles",
            )

        assert result.success is False
        assert "timed out" in result.stderr

    @patch("governor_core.dbt.uv_runner.get_settings")
    def test_exception_returns_failure(self, mock_settings):
        """Should capture unexpected exceptions in CompileResult."""
        mock_settings.return_value = _mock_settings()

        runner = DbtUvRunner(venv_base_dir="/tmp/test-venvs")

        with (
            patch.object(
                runner, "ensure_venv", side_effect=RuntimeError("venv broken")
            ),
        ):
            result = runner.compile_model(
                project_dir="/tmp/project",
                model_name="stg_orders",
                dbt_version="1.9.0",
                profiles_dir="/tmp/profiles",
            )

        assert result.success is False
        assert result.exit_code == -1
        assert "venv broken" in result.stderr

    @patch("governor_core.dbt.uv_runner.get_settings")
    def test_stderr_truncated_to_10kb(self, mock_settings):
        """Should truncate stderr to 10KB."""
        mock_settings.return_value = _mock_settings()

        runner = DbtUvRunner(venv_base_dir="/tmp/test-venvs")

        with (
            patch.object(runner, "ensure_venv") as mock_ensure,
            patch("governor_core.dbt.uv_runner.subprocess") as mock_subprocess,
            patch.object(runner, "_find_compiled_sql", return_value=None),
        ):
            mock_ensure.return_value = Path("/tmp/test-venvs/1.9.0")
            mock_result = MagicMock()
            mock_result.returncode = 1
            mock_result.stdout = ""
            mock_result.stderr = "x" * 20000
            mock_subprocess.run.return_value = mock_result
            mock_subprocess.TimeoutExpired = subprocess.TimeoutExpired

            result = runner.compile_model(
                project_dir="/tmp/project",
                model_name="stg_orders",
                dbt_version="1.9.0",
                profiles_dir="/tmp/profiles",
            )

        assert len(result.stderr) <= 10240


# --- parse_project() tests ---


class TestParseProject:
    """Tests for DbtUvRunner.parse_project()."""

    @patch("governor_core.dbt.uv_runner.get_settings")
    def test_happy_path_returns_manifest(self, mock_settings):
        """Should return ParseResult with manifest dict on success."""
        mock_settings.return_value = _mock_settings()

        runner = DbtUvRunner(venv_base_dir="/tmp/test-venvs")

        with (
            patch.object(runner, "ensure_venv") as mock_ensure,
            patch("governor_core.dbt.uv_runner.subprocess") as mock_subprocess,
            patch.object(runner, "_read_manifest", return_value={"nodes": {}}),
            patch("governor_core.dbt.uv_runner.ProfilesGenerator") as mock_profiles,
        ):
            mock_ensure.return_value = Path("/tmp/test-venvs/1.9.0")
            mock_profiles.generate_parse_profiles.return_value = "/tmp/profiles"
            mock_result = MagicMock()
            mock_result.returncode = 0
            mock_result.stderr = ""
            mock_subprocess.run.return_value = mock_result
            mock_subprocess.TimeoutExpired = subprocess.TimeoutExpired

            result = runner.parse_project(
                project_dir="/tmp/project",
                dbt_version="1.9.0",
                profile_name="my_project",
            )

        assert result.success is True
        assert result.manifest == {"nodes": {}}
        assert result.exit_code == 0

    @patch("governor_core.dbt.uv_runner.get_settings")
    def test_parse_failure_returns_error(self, mock_settings):
        """Should return ParseResult(success=False) when dbt parse fails."""
        mock_settings.return_value = _mock_settings()

        runner = DbtUvRunner(venv_base_dir="/tmp/test-venvs")

        with (
            patch.object(runner, "ensure_venv") as mock_ensure,
            patch("governor_core.dbt.uv_runner.subprocess") as mock_subprocess,
            patch.object(runner, "_read_manifest", return_value=None),
            patch("governor_core.dbt.uv_runner.ProfilesGenerator") as mock_profiles,
        ):
            mock_ensure.return_value = Path("/tmp/test-venvs/1.9.0")
            mock_profiles.generate_parse_profiles.return_value = "/tmp/profiles"
            mock_result = MagicMock()
            mock_result.returncode = 1
            mock_result.stderr = "Parse error"
            mock_subprocess.run.return_value = mock_result
            mock_subprocess.TimeoutExpired = subprocess.TimeoutExpired

            result = runner.parse_project(
                project_dir="/tmp/project",
                dbt_version="1.9.0",
                profile_name="my_project",
            )

        assert result.success is False
        assert result.exit_code == 1

    @patch("governor_core.dbt.uv_runner.get_settings")
    def test_parse_timeout_returns_failure(self, mock_settings):
        """Should return ParseResult(success=False) on timeout."""
        mock_settings.return_value = _mock_settings()

        runner = DbtUvRunner(venv_base_dir="/tmp/test-venvs")

        with (
            patch.object(runner, "ensure_venv") as mock_ensure,
            patch("governor_core.dbt.uv_runner.subprocess") as mock_subprocess,
            patch("governor_core.dbt.uv_runner.ProfilesGenerator") as mock_profiles,
        ):
            mock_ensure.return_value = Path("/tmp/test-venvs/1.9.0")
            mock_profiles.generate_parse_profiles.return_value = "/tmp/profiles"
            mock_subprocess.run.side_effect = subprocess.TimeoutExpired(
                cmd="dbt", timeout=120
            )
            mock_subprocess.TimeoutExpired = subprocess.TimeoutExpired

            result = runner.parse_project(
                project_dir="/tmp/project",
                dbt_version="1.9.0",
                profile_name="my_project",
            )

        assert result.success is False
        assert "timed out" in result.stderr


# --- Dataclass tests ---


class TestDataclasses:
    """Tests for CompileResult and ParseResult dataclasses."""

    def test_compile_result_defaults(self):
        result = CompileResult()
        assert result.compiled_sql is None
        assert result.success is False
        assert result.exit_code == -1
        assert result.stdout == ""
        assert result.stderr == ""
        assert result.duration_ms == 0

    def test_parse_result_defaults(self):
        result = ParseResult()
        assert result.manifest is None
        assert result.success is False
        assert result.exit_code == -1
        assert result.stderr == ""
        assert result.duration_ms == 0
