"""Unit tests for app/solutions/templates/remove_dead_ctes.py."""

from types import SimpleNamespace

from governor_core.solutions.templates.remove_dead_ctes import (
    RemoveDeadCtesTemplate,
    _find_cte_segment,
    _remove_cte_from_sql,
)


def _make_opportunity(evidence: dict | None = None):
    return SimpleNamespace(
        id="opp-1",
        opportunity_type="dead_cte",
        evidence_snapshot=evidence or {},
        dbt_model_name="my_model",
        affected_table="project.dataset.my_model",
    )


class TestFindCteSegment:
    def test_finds_middle_cte(self):
        sql = (
            "WITH\n"
            "  used_stage AS (SELECT id FROM raw_orders),\n"
            "  dead_stage AS (SELECT customer_id FROM raw_customers),\n"
            "  final AS (SELECT id FROM used_stage)\n"
            "SELECT id FROM final\n"
        )

        segment = _find_cte_segment(sql, "dead_stage")

        assert segment is not None
        assert "dead_stage AS" in sql[segment[0] : segment[1]]


class TestRemoveCteFromSql:
    def test_removes_middle_cte(self):
        sql = (
            "WITH\n"
            "  used_stage AS (SELECT id FROM raw_orders),\n"
            "  dead_stage AS (SELECT customer_id FROM raw_customers),\n"
            "  final AS (SELECT id FROM used_stage)\n"
            "SELECT id FROM final\n"
        )

        result = _remove_cte_from_sql(sql, "dead_stage")

        assert result is not None
        assert "dead_stage AS" not in result
        assert "used_stage AS" in result
        assert "final AS" in result

    def test_removes_only_cte_and_cleans_with_keyword(self):
        sql = "WITH dead_stage AS (SELECT id FROM raw_orders)\nSELECT 1 AS sentinel\n"

        result = _remove_cte_from_sql(sql, "dead_stage")

        assert result == "SELECT 1 AS sentinel\n"


class TestRemoveDeadCtesTemplate:
    def test_matches_requires_dead_ctes_and_source_file(self):
        template = RemoveDeadCtesTemplate()
        opp = _make_opportunity({"dead_ctes": ["dead_stage"]})

        assert (
            template.matches(
                opp,
                {"models/marts/test.sql": "select 1"},
                {"original_file_path": "models/marts/test.sql"},
            )
            is True
        )

    def test_apply_removes_dead_ctes(self):
        template = RemoveDeadCtesTemplate()
        sql = (
            "WITH\n"
            "  used_stage AS (SELECT id FROM raw_orders),\n"
            "  dead_stage AS (SELECT customer_id FROM raw_customers),\n"
            "  final AS (SELECT id FROM used_stage)\n"
            "SELECT id FROM final\n"
        )
        opp = _make_opportunity({"dead_ctes": ["dead_stage"]})

        result = template.apply(
            opp,
            {"models/marts/test.sql": sql},
            {"original_file_path": "models/marts/test.sql", "name": "test"},
        )

        assert result is not None
        assert result.template_id == "remove_dead_ctes"
        assert "dead_stage AS" not in result.after_content
        assert "used_stage AS" in result.after_content
        assert result.parameters["dead_ctes"] == ["dead_stage"]
