"""Regression tests for the shadow-savings sign convention.

``ShadowValidationRun.cost_delta_usd`` is ``shadow_cost - baseline_cost``
(see ``governor_core.shadow.diff.Diff.cost_delta_usd``). A cheaper shadow
therefore produces a NEGATIVE delta, and the displayed savings are
``-delta``. ``get_latest_shadow_savings_map`` must flip the sign and
clamp proposals that made the build more expensive (positive delta) to
zero.
"""

from __future__ import annotations

from decimal import Decimal

from governor_core.opportunities.savings import get_latest_shadow_savings_map
from tests.fixtures.factories import (
    OpportunityFactory,
    ShadowValidationRunFactory,
    SolutionFactory,
)


def test_negative_delta_becomes_positive_savings(db):
    opp = OpportunityFactory.create()
    sol = SolutionFactory.create(solution_job__opportunity=opp)
    ShadowValidationRunFactory.create(
        _solution=sol,
        status="succeeded",
        cost_delta_usd=Decimal("-13.9180"),
    )

    mapping = get_latest_shadow_savings_map(db, [opp.id])

    assert mapping[opp.id] == Decimal("13.9180")


def test_positive_delta_clamps_to_zero(db):
    """Shadow made the build MORE expensive — savings should be $0."""
    opp = OpportunityFactory.create()
    sol = SolutionFactory.create(solution_job__opportunity=opp)
    ShadowValidationRunFactory.create(
        _solution=sol,
        status="succeeded",
        cost_delta_usd=Decimal("5.00"),
    )

    mapping = get_latest_shadow_savings_map(db, [opp.id])

    assert mapping[opp.id] == Decimal("0")


def test_no_succeeded_run_returns_empty(db):
    opp = OpportunityFactory.create()
    sol = SolutionFactory.create(solution_job__opportunity=opp)
    ShadowValidationRunFactory.create(
        _solution=sol,
        status="baseline_failed",
        cost_delta_usd=Decimal("-10.00"),
    )

    mapping = get_latest_shadow_savings_map(db, [opp.id])

    assert opp.id not in mapping


def test_only_latest_succeeded_run_per_opportunity(db):
    """When multiple succeeded runs exist, the most recent wins."""
    import time

    opp = OpportunityFactory.create()
    sol = SolutionFactory.create(solution_job__opportunity=opp)
    older = ShadowValidationRunFactory.create(
        _solution=sol,
        status="succeeded",
        cost_delta_usd=Decimal("-1.00"),
    )
    # Ensure the second row's updated_at is strictly later than the first
    time.sleep(0.01)
    newer = ShadowValidationRunFactory.create(
        _solution=sol,
        status="succeeded",
        cost_delta_usd=Decimal("-7.50"),
    )
    db.flush()

    mapping = get_latest_shadow_savings_map(db, [opp.id])

    # Latest run wins — $7.50 savings, not $1.00
    assert mapping[opp.id] == Decimal("7.50")
    assert older.id != newer.id
