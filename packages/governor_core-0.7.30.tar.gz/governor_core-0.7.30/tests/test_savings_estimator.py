"""Unit tests for the workload-based savings estimation engine."""

from decimal import Decimal

from governor_core.opportunities.savings_models import (
    ColumnStats,
    PartitionInfo,
    PartitionStats,
    Predicate,
    SavingsRecommendation,
    TableStats,
)
from governor_core.opportunities.savings_estimator import (
    _bytes_to_usd,
    _compute_confidence,
    _partition_id_from_value,
    estimate_cluster_savings,
    estimate_opportunity_savings,
    estimate_partition_savings,
    estimate_partition_savings_without_metadata,
    extract_table_predicates,
)


# ---------------------------------------------------------------------------
# Predicate Extraction Tests
# ---------------------------------------------------------------------------


class TestExtractTablePredicates:
    """Tests for SQL predicate extraction using sqlglot."""

    def test_simple_equality(self):
        sql = "SELECT * FROM my_table WHERE created_date = '2026-01-15'"
        preds = extract_table_predicates(sql, "my_table", ["created_date"])
        assert len(preds) >= 1
        p = preds[0]
        assert p.column == "created_date"
        assert p.operator == "eq"
        assert p.values == ["2026-01-15"]
        assert p.is_partition_compatible is True

    def test_range_filter(self):
        sql = "SELECT * FROM my_table WHERE created_date >= '2026-01-01'"
        preds = extract_table_predicates(sql, "my_table", ["created_date"])
        assert len(preds) >= 1
        assert preds[0].operator == "gte"

    def test_between_filter(self):
        sql = "SELECT * FROM my_table WHERE created_date BETWEEN '2026-01-01' AND '2026-01-31'"
        preds = extract_table_predicates(sql, "my_table", ["created_date"])
        assert len(preds) >= 1
        p = preds[0]
        assert p.operator == "between"
        assert len(p.values) == 2

    def test_in_filter(self):
        sql = "SELECT * FROM my_table WHERE user_id IN (1, 2, 3)"
        preds = extract_table_predicates(sql, "my_table", ["user_id"])
        assert len(preds) >= 1
        p = preds[0]
        assert p.operator == "in"
        assert len(p.values) == 3

    def test_function_wrapped_column(self):
        sql = "SELECT * FROM my_table WHERE DATE(created_at) = '2026-01-15'"
        preds = extract_table_predicates(sql, "my_table", ["created_at"])
        assert len(preds) >= 1
        assert preds[0].is_partition_compatible is False

    def test_no_filter_on_target_column(self):
        sql = "SELECT * FROM my_table WHERE other_col = 5"
        preds = extract_table_predicates(sql, "my_table", ["created_date"])
        assert len(preds) == 0

    def test_table_not_referenced(self):
        sql = "SELECT * FROM other_table WHERE created_date = '2026-01-01'"
        preds = extract_table_predicates(sql, "my_table", ["created_date"])
        assert len(preds) == 0

    def test_aliased_table(self):
        sql = "SELECT * FROM my_table t WHERE t.created_date = '2026-01-15'"
        preds = extract_table_predicates(sql, "my_table", ["created_date"])
        assert len(preds) >= 1
        assert preds[0].column == "created_date"

    def test_join_predicate(self):
        sql = """
        SELECT a.*, b.name
        FROM orders a
        JOIN customers b ON a.customer_id = b.id
        WHERE a.order_date = '2026-01-15'
        """
        preds = extract_table_predicates(sql, "orders", ["order_date", "customer_id"])
        # Should find at least the WHERE predicate on order_date
        order_date_preds = [p for p in preds if p.column == "order_date"]
        assert len(order_date_preds) >= 1

    def test_empty_sql(self):
        preds = extract_table_predicates("", "my_table", ["col"])
        assert preds == []

    def test_empty_columns(self):
        preds = extract_table_predicates("SELECT * FROM t", "t", [])
        assert preds == []

    def test_malformed_sql(self):
        preds = extract_table_predicates("NOT VALID SQL @@@ !!!", "t", ["col"])
        assert preds == []

    def test_compound_where_and(self):
        sql = "SELECT * FROM t WHERE col1 = '2026-01-01' AND col2 > 100"
        preds = extract_table_predicates(sql, "t", ["col1", "col2"])
        assert len(preds) >= 2

    def test_qualified_table_name(self):
        sql = "SELECT * FROM `project.dataset.my_table` WHERE dt = '2026-01-01'"
        preds = extract_table_predicates(sql, "project.dataset.my_table", ["dt"])
        assert len(preds) >= 1


# ---------------------------------------------------------------------------
# Partition ID Conversion Tests
# ---------------------------------------------------------------------------


class TestPartitionIdFromValue:
    def test_date_string_to_day(self):
        assert _partition_id_from_value("2026-01-15", "DAY") == "20260115"

    def test_date_string_to_month(self):
        assert _partition_id_from_value("2026-01-15", "MONTH") == "202601"

    def test_date_string_to_year(self):
        assert _partition_id_from_value("2026-01-15", "YEAR") == "2026"

    def test_invalid_value(self):
        assert _partition_id_from_value("not-a-date", "DAY") is None

    def test_numeric_value(self):
        result = _partition_id_from_value("20260115", "DAY")
        assert result == "20260115"


# ---------------------------------------------------------------------------
# Partition Pruning Tests
# ---------------------------------------------------------------------------


def _make_partition_stats(num_days: int = 90) -> PartitionStats:
    """Create partition stats for a table with daily partitions."""
    partitions = {}
    bytes_per_partition = 1_000_000_000  # 1 GB per partition
    for i in range(num_days):
        pid = f"2026{(i // 30 + 1):02d}{(i % 30 + 1):02d}"
        partitions[pid] = PartitionInfo(
            partition_id=pid,
            total_rows=100_000,
            total_logical_bytes=bytes_per_partition,
        )
    return PartitionStats(
        partition_column="created_date",
        partition_type="DAY",
        partitions=partitions,
        total_rows=100_000 * num_days,
        total_bytes=bytes_per_partition * num_days,
    )


class TestEstimatePartitionSavings:
    def test_single_day_equality(self):
        stats = _make_partition_stats(90)
        preds = [Predicate(column="created_date", operator="eq", values=["2026-01-15"])]
        result = estimate_partition_savings(preds, "created_date", stats)
        assert result.filter_found is True
        assert result.partition_compatible is True
        # Should prune ~89/90 partitions
        assert result.pruned_fraction > 0.95

    def test_no_filter(self):
        stats = _make_partition_stats(90)
        preds = []
        result = estimate_partition_savings(preds, "created_date", stats)
        assert result.filter_found is False
        assert result.pruned_fraction == 0.0

    def test_function_wrapped_filter(self):
        stats = _make_partition_stats(90)
        preds = [
            Predicate(
                column="created_date",
                operator="eq",
                values=["2026-01-15"],
                is_partition_compatible=False,
            )
        ]
        result = estimate_partition_savings(preds, "created_date", stats)
        assert result.filter_found is True
        assert result.partition_compatible is False
        assert result.pruned_fraction == 0.0

    def test_range_filter(self):
        stats = _make_partition_stats(90)
        # Filter: >= 2026-03-01 (last ~30 of 90 partitions)
        preds = [
            Predicate(column="created_date", operator="gte", values=["2026-03-01"])
        ]
        result = estimate_partition_savings(preds, "created_date", stats)
        assert result.filter_found is True
        # Should prune some partitions (those before March)
        assert result.pruned_fraction > 0.0

    def test_in_filter(self):
        stats = _make_partition_stats(90)
        preds = [
            Predicate(
                column="created_date",
                operator="in",
                values=["2026-01-15", "2026-01-16"],
            )
        ]
        result = estimate_partition_savings(preds, "created_date", stats)
        assert result.filter_found is True
        # Should prune 88/90 partitions
        assert result.pruned_fraction > 0.9

    def test_empty_partition_stats(self):
        stats = PartitionStats(
            partition_column="dt",
            partition_type="DAY",
            total_rows=0,
            total_bytes=0,
        )
        preds = [Predicate(column="dt", operator="eq", values=["2026-01-01"])]
        result = estimate_partition_savings(preds, "dt", stats)
        assert result.pruned_fraction == 0.0

    def test_heuristic_without_metadata(self):
        preds = [Predicate(column="created_date", operator="eq", values=["2026-01-15"])]
        result = estimate_partition_savings_without_metadata(
            preds,
            "created_date",
            total_bytes=1_000_000_000,
        )
        assert result.filter_found is True
        assert result.partition_compatible is True
        assert result.pruned_fraction >= 0.80


# ---------------------------------------------------------------------------
# Cluster Pruning Tests
# ---------------------------------------------------------------------------


class TestEstimateClusterSavings:
    def test_high_cardinality_equality(self):
        table_stats = TableStats(
            project_id="p",
            dataset="d",
            table_name="t",
            total_rows=1_000_000,
            total_logical_bytes=10_000_000_000,
            total_billable_bytes=10_000_000_000,
        )
        col_stats = {
            "user_id": ColumnStats(column_name="user_id", approx_distinct=500_000)
        }
        preds = [Predicate(column="user_id", operator="eq", values=["12345"])]
        result = estimate_cluster_savings(
            preds, ["user_id"], table_stats, column_stats=col_stats
        )
        assert result.filter_found is True
        assert result.pruned_fraction >= 0.90

    def test_low_cardinality_equality(self):
        table_stats = TableStats(
            project_id="p",
            dataset="d",
            table_name="t",
            total_rows=1_000_000,
            total_logical_bytes=10_000_000_000,
            total_billable_bytes=10_000_000_000,
        )
        col_stats = {"status": ColumnStats(column_name="status", approx_distinct=5)}
        preds = [Predicate(column="status", operator="eq", values=["active"])]
        result = estimate_cluster_savings(
            preds, ["status"], table_stats, column_stats=col_stats
        )
        assert result.filter_found is True
        # Low cardinality = low pruning
        assert result.pruned_fraction <= 0.50

    def test_no_filter_on_cluster_columns(self):
        table_stats = TableStats(
            project_id="p",
            dataset="d",
            table_name="t",
            total_rows=1_000_000,
            total_logical_bytes=10_000_000_000,
            total_billable_bytes=10_000_000_000,
        )
        preds = [Predicate(column="other_col", operator="eq", values=["x"])]
        result = estimate_cluster_savings(preds, ["user_id"], table_stats)
        assert result.filter_found is False
        assert result.pruned_fraction == 0.0

    def test_remaining_bytes_used(self):
        table_stats = TableStats(
            project_id="p",
            dataset="d",
            table_name="t",
            total_rows=1_000_000,
            total_logical_bytes=10_000_000_000,
            total_billable_bytes=10_000_000_000,
        )
        preds = [Predicate(column="user_id", operator="eq", values=["12345"])]
        # After partition pruning, only 1GB remains
        result = estimate_cluster_savings(
            preds,
            ["user_id"],
            table_stats,
            remaining_bytes=1_000_000_000,
        )
        assert result.total_bytes == 1_000_000_000

    def test_second_cluster_column_reduced(self):
        table_stats = TableStats(
            project_id="p",
            dataset="d",
            table_name="t",
            total_rows=1_000_000,
            total_logical_bytes=10_000_000_000,
            total_billable_bytes=10_000_000_000,
        )
        col_stats = {"col2": ColumnStats(column_name="col2", approx_distinct=1000)}
        # Filter only on second column (col1 has no filter)
        preds = [Predicate(column="col2", operator="eq", values=["x"])]
        result = estimate_cluster_savings(
            preds,
            ["col1", "col2"],
            table_stats,
            column_stats=col_stats,
        )
        # Second column gets 50% reduction → 90% * 0.5 = 45%
        assert result.filter_found is True
        assert result.pruned_fraction < 0.50

    def test_empty_cluster_columns(self):
        result = estimate_cluster_savings([], [], None)
        assert result.pruned_fraction == 0.0

    def test_missing_stats_defaults_are_conservative(self):
        table_stats = TableStats(
            project_id="p",
            dataset="d",
            table_name="t",
            total_rows=1_000_000,
            total_logical_bytes=10_000_000_000,
            total_billable_bytes=10_000_000_000,
        )
        preds = [Predicate(column="user_id", operator="eq", values=["12345"])]
        result = estimate_cluster_savings(preds, ["user_id"], table_stats)
        assert result.filter_found is True
        assert result.pruned_fraction <= 0.35

    def test_existing_cluster_offset_reduces_incremental_benefit(self):
        table_stats = TableStats(
            project_id="p",
            dataset="d",
            table_name="t",
            total_rows=1_000_000,
            total_logical_bytes=10_000_000_000,
            total_billable_bytes=10_000_000_000,
        )
        col_stats = {
            "user_id": ColumnStats(column_name="user_id", approx_distinct=500_000)
        }
        preds = [Predicate(column="user_id", operator="eq", values=["12345"])]
        base = estimate_cluster_savings(
            preds,
            ["user_id"],
            table_stats,
            column_stats=col_stats,
        )
        offset = estimate_cluster_savings(
            preds,
            ["user_id"],
            table_stats,
            column_stats=col_stats,
            cluster_position_offset=1,
        )
        assert offset.pruned_fraction < base.pruned_fraction


# ---------------------------------------------------------------------------
# Opportunity Aggregation Tests
# ---------------------------------------------------------------------------


def _make_jobs(count: int, bytes_billed: int = 1_000_000_000, cost: float = 6.25):
    """Create mock job dicts."""
    return [
        {
            "job_id": f"job_{i}",
            "query": "SELECT * FROM my_table WHERE created_date = '2026-01-15'",
            "total_bytes_billed": bytes_billed,
            "total_cost": cost,
        }
        for i in range(count)
    ]


class TestEstimateOpportunitySavings:
    def test_basic_partition_estimate(self):
        stats = _make_partition_stats(90)
        recommendation = SavingsRecommendation(
            partition_column="created_date", partition_type="DAY"
        )
        jobs = _make_jobs(10)
        result = estimate_opportunity_savings(
            opportunity_id="opp_1",
            recommendation=recommendation,
            jobs=jobs,
            target_table="my_table",
            partition_stats=stats,
            table_stats=None,
            observation_days=30,
        )
        assert result.jobs_analyzed == 10
        assert result.total_cost_saved > Decimal("0")
        assert result.per_run_savings > Decimal("0")
        assert result.monthly_projection > Decimal("0")

    def test_cluster_only_estimate(self):
        table_stats = TableStats(
            project_id="p",
            dataset="d",
            table_name="t",
            total_rows=1_000_000,
            total_logical_bytes=10_000_000_000,
            total_billable_bytes=10_000_000_000,
        )
        recommendation = SavingsRecommendation(cluster_columns=["created_date"])
        jobs = _make_jobs(5)
        result = estimate_opportunity_savings(
            opportunity_id="opp_2",
            recommendation=recommendation,
            jobs=jobs,
            target_table="my_table",
            partition_stats=None,
            table_stats=table_stats,
            observation_days=30,
        )
        assert result.recommendation_type == "cluster"
        assert result.jobs_analyzed == 5

    def test_zero_jobs(self):
        recommendation = SavingsRecommendation(partition_column="dt")
        result = estimate_opportunity_savings(
            opportunity_id="opp_3",
            recommendation=recommendation,
            jobs=[],
            target_table="t",
            partition_stats=None,
            table_stats=None,
        )
        assert result.jobs_analyzed == 0
        assert result.total_cost_saved == Decimal("0")
        assert result.confidence == "low"

    def test_sanity_cap(self):
        """Savings should never exceed job cost."""
        stats = _make_partition_stats(365)
        recommendation = SavingsRecommendation(
            partition_column="created_date", partition_type="DAY"
        )
        # Job costs $0.01 but processes 1TB — savings would be more than cost
        jobs = [
            {
                "job_id": "job_cap",
                "query": "SELECT * FROM my_table WHERE created_date = '2026-01-15'",
                "total_bytes_billed": 1_000_000_000_000,  # 1 TB
                "total_cost": 0.01,
            }
        ]
        result = estimate_opportunity_savings(
            opportunity_id="opp_cap",
            recommendation=recommendation,
            jobs=jobs,
            target_table="my_table",
            partition_stats=stats,
            table_stats=None,
        )
        assert result.total_cost_saved <= Decimal("0.01")

    def test_no_recommendation(self):
        recommendation = SavingsRecommendation()  # No columns
        result = estimate_opportunity_savings(
            opportunity_id="opp_empty",
            recommendation=recommendation,
            jobs=_make_jobs(5),
            target_table="t",
            partition_stats=None,
            table_stats=None,
        )
        assert result.jobs_analyzed == 0

    def test_partition_rec_type_preserved_without_partition_stats(self):
        recommendation = SavingsRecommendation(partition_column="created_date")
        jobs = _make_jobs(25)
        result = estimate_opportunity_savings(
            opportunity_id="opp_partition_fallback",
            recommendation=recommendation,
            jobs=jobs,
            target_table="my_table",
            partition_stats=None,
            table_stats=None,
            observation_days=30,
        )
        assert result.recommendation_type == "partition"
        assert result.total_cost_saved > Decimal("0")
        assert result.confidence != "high"

    def test_sampling_scales_back_to_full_population(self):
        recommendation = SavingsRecommendation(partition_column="created_date")
        jobs = _make_jobs(1001, bytes_billed=1_000, cost=0.10)
        result = estimate_opportunity_savings(
            opportunity_id="opp_sampling",
            recommendation=recommendation,
            jobs=jobs,
            target_table="my_table",
            partition_stats=None,
            table_stats=None,
            observation_days=30,
        )
        assert result.jobs_analyzed == 1000
        assert result.total_bytes_scanned == 1_001_000


# ---------------------------------------------------------------------------
# Confidence Tests
# ---------------------------------------------------------------------------


class TestComputeConfidence:
    def test_high_confidence(self):
        assert _compute_confidence(25, 22) == "high"

    def test_medium_confidence(self):
        assert _compute_confidence(10, 6) == "medium"

    def test_low_confidence_few_jobs(self):
        assert _compute_confidence(3, 3) == "low"

    def test_low_confidence_low_coverage(self):
        assert _compute_confidence(20, 5) == "low"

    def test_zero_jobs(self):
        assert _compute_confidence(0, 0) == "low"


# ---------------------------------------------------------------------------
# Bytes to USD Tests
# ---------------------------------------------------------------------------


class TestBytesToUsd:
    def test_one_tb(self):
        one_tb = 1024**4
        result = _bytes_to_usd(one_tb)
        assert abs(result - Decimal("6.25")) < Decimal("0.01")

    def test_zero_bytes(self):
        assert _bytes_to_usd(0) == Decimal("0")
