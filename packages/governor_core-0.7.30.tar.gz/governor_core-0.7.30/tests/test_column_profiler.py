"""Unit tests for join key quality analysis (spec 065).

Tests:
1. build_profile_query() generates correct SQL
2. classify_column() returns correct classifications
3. Lineage analyzer filters poor-quality columns
4. Lineage analyzer keeps candidates with quality context when all columns poor
"""

from __future__ import annotations

from governor_core.dbt.column_profiler import (
    ColumnQuality,
    build_profile_query,
    classify_column,
)
from governor_core.dbt.lineage_analyzer import analyze_upstream


# ---------------------------------------------------------------------------
# build_profile_query tests
# ---------------------------------------------------------------------------


def test_build_profile_query_single_column():
    sql = build_profile_query("proj", "ds", "tbl", ["country"])
    assert "COUNT(*) AS total_rows" in sql
    assert "COUNTIF(`country` IS NULL) AS `country__nulls`" in sql
    assert "APPROX_COUNT_DISTINCT(`country`) AS `country__distinct`" in sql
    assert "country__top_value" in sql
    assert "country__top_count" in sql
    assert "`proj`.`ds`.`tbl`" in sql


def test_build_profile_query_multiple_columns():
    sql = build_profile_query("proj", "ds", "tbl", ["country", "climate_zone", "sid"])
    assert "country__nulls" in sql
    assert "climate_zone__nulls" in sql
    assert "sid__nulls" in sql
    assert "country__distinct" in sql
    assert "climate_zone__distinct" in sql
    assert "sid__distinct" in sql


def test_build_profile_query_rejects_empty_columns():
    try:
        build_profile_query("proj", "ds", "tbl", [])
        assert False, "Should have raised ValueError"
    except ValueError as e:
        assert "empty" in str(e).lower()


def test_build_profile_query_rejects_invalid_identifier():
    try:
        build_profile_query("proj", "ds", "tbl", ["country; DROP TABLE--"])
        assert False, "Should have raised ValueError"
    except ValueError:
        pass


# ---------------------------------------------------------------------------
# classify_column tests
# ---------------------------------------------------------------------------


def test_classify_good_column():
    """High cardinality, low NULL ratio → good."""
    cq = classify_column(
        "station_id", null_count=0, approx_distinct=12000, total_rows=1_000_000
    )
    assert cq.classification == "good"
    assert cq.null_ratio == 0.0


def test_classify_poor_null_ratio():
    """73% NULL → poor."""
    cq = classify_column(
        "country", null_count=730_000, approx_distinct=4, total_rows=1_000_000
    )
    assert cq.classification == "poor"
    assert "NULL" in cq.reason
    assert cq.null_ratio > 0.5


def test_classify_poor_low_cardinality():
    """Only 3 distinct values across 1M rows → poor."""
    cq = classify_column(
        "climate_zone", null_count=0, approx_distinct=3, total_rows=1_000_000
    )
    assert cq.classification == "poor"
    assert "distinct" in cq.reason.lower()


def test_classify_marginal_null_ratio():
    """25% NULL → marginal."""
    cq = classify_column(
        "region", null_count=250_000, approx_distinct=500, total_rows=1_000_000
    )
    assert cq.classification == "marginal"


def test_classify_marginal_cardinality():
    """50 distinct values across 1M rows → marginal."""
    cq = classify_column(
        "category", null_count=0, approx_distinct=50, total_rows=1_000_000
    )
    assert cq.classification == "marginal"


def test_classify_skips_cardinality_for_small_tables():
    """Tables < 100K rows: don't penalize low cardinality."""
    cq = classify_column("status", null_count=0, approx_distinct=3, total_rows=50_000)
    assert cq.classification == "good"


def test_classify_both_poor_null_and_cardinality():
    """Both high NULL and low cardinality → poor with both reasons."""
    cq = classify_column(
        "bad_col", null_count=800_000, approx_distinct=2, total_rows=1_000_000
    )
    assert cq.classification == "poor"
    assert "NULL" in cq.reason
    assert "distinct" in cq.reason.lower()


def test_classify_zero_rows():
    """Empty table → good (no data to judge)."""
    cq = classify_column("col", null_count=0, approx_distinct=0, total_rows=0)
    assert cq.classification == "good"
    assert cq.null_ratio == 0.0


def test_classify_poor_dominant_placeholder_value():
    """A dominant placeholder value should make a low-cardinality column poor."""
    cq = classify_column(
        "climate_zone",
        null_count=0,
        approx_distinct=7,
        total_rows=29_590,
        dominant_value="unknown",
        dominant_count=27_000,
    )
    assert cq.classification == "poor"
    assert cq.dominant_ratio is not None
    assert cq.dominant_ratio > 0.8
    assert "unknown" in cq.reason.lower()


# ---------------------------------------------------------------------------
# Lineage analyzer integration with column quality
# ---------------------------------------------------------------------------


def _make_manifest(nodes=None, project_name="my_project"):
    return {
        "metadata": {"project_name": project_name},
        "nodes": nodes or {},
    }


def _make_node(
    name,
    unique_id=None,
    materialized="table",
    package_name="my_project",
    depends_on_nodes=None,
    cluster_by=None,
    schema="dataset",
):
    uid = unique_id or f"model.my_project.{name}"
    return {
        "name": name,
        "unique_id": uid,
        "resource_type": "model",
        "package_name": package_name,
        "original_file_path": f"models/{name}.sql",
        "config": {
            "materialized": materialized,
            **({"cluster_by": cluster_by} if cluster_by else {}),
        },
        "depends_on": {"nodes": depends_on_nodes or []},
        "columns": {},
        "schema": schema,
    }


def _make_quality_lookup(quality_map):
    """Create a mock column_quality_lookup callable.

    quality_map: dict of (table_name, col_name) → ColumnQuality
    """

    def lookup(node, columns):
        table = node.get("alias") or node.get("name", "")
        result = {}
        for col in columns:
            key = (table.lower(), col.lower())
            if key in quality_map:
                result[col] = quality_map[key]
        return result if result else None

    return lookup


def test_lineage_filters_poor_quality_columns():
    """Poor-quality columns should be removed from suggested_cluster_columns."""
    upstream = _make_node("stg_stations", depends_on_nodes=[])
    downstream = _make_node(
        "fct_readings",
        depends_on_nodes=["model.my_project.stg_stations"],
    )
    manifest = _make_manifest(
        {
            "model.my_project.stg_stations": upstream,
            "model.my_project.fct_readings": downstream,
        }
    )

    # country is poor, station_id is good
    quality_map = {
        ("stg_stations", "country"): ColumnQuality(
            column_name="country",
            total_rows=1_000_000,
            null_count=730_000,
            null_ratio=0.73,
            approx_distinct=4,
            classification="poor",
            reason="73% NULL",
        ),
        ("stg_stations", "station_id"): ColumnQuality(
            column_name="station_id",
            total_rows=1_000_000,
            null_count=0,
            null_ratio=0.0,
            approx_distinct=12000,
            classification="good",
            reason="good cardinality",
        ),
    }

    compiled_sql = """
    SELECT * FROM stg_stations s
    JOIN dim_countries c ON s.country = c.country AND s.station_id = c.station_id
    """

    result = analyze_upstream(
        manifest_content=manifest,
        affected_model_name="fct_readings",
        opportunity_type="join_explosion",
        compiled_sql=compiled_sql,
        column_quality_lookup=_make_quality_lookup(quality_map),
    )

    # Should have one candidate with only station_id (country filtered out)
    assert len(result.candidates) == 1
    candidate = result.candidates[0]
    assert "station_id" in candidate.suggested_cluster_columns
    assert "country" not in candidate.suggested_cluster_columns
    # Quality data should be attached
    assert candidate.column_quality is not None


def test_lineage_filters_dominant_low_cardinality_column():
    """Dominant placeholder values should be excluded from cluster_by."""
    upstream = _make_node("stg_stations", depends_on_nodes=[])
    downstream = _make_node(
        "fct_readings",
        depends_on_nodes=["model.my_project.stg_stations"],
    )
    manifest = _make_manifest(
        {
            "model.my_project.stg_stations": upstream,
            "model.my_project.fct_readings": downstream,
        }
    )

    quality_map = {
        ("stg_stations", "country"): ColumnQuality(
            column_name="country",
            total_rows=29_590,
            null_count=895,
            null_ratio=0.03,
            approx_distinct=252,
            dominant_value="NO",
            dominant_count=3_100,
            dominant_ratio=0.10,
            classification="good",
            reason="good cardinality and low NULL ratio",
        ),
        ("stg_stations", "climate_zone"): ColumnQuality(
            column_name="climate_zone",
            total_rows=29_590,
            null_count=0,
            null_ratio=0.0,
            approx_distinct=7,
            dominant_value="unknown",
            dominant_count=27_000,
            dominant_ratio=0.91,
            classification="poor",
            reason="top value 'unknown' covers 91% of rows",
        ),
    }

    compiled_sql = """
    SELECT * FROM stg_stations s
    JOIN dim_countries c ON s.country = c.country AND s.climate_zone = c.climate_zone
    """

    result = analyze_upstream(
        manifest_content=manifest,
        affected_model_name="fct_readings",
        opportunity_type="join_explosion",
        compiled_sql=compiled_sql,
        column_quality_lookup=_make_quality_lookup(quality_map),
    )

    assert len(result.candidates) == 1
    candidate = result.candidates[0]
    assert candidate.suggested_cluster_columns == ["country"]
    assert "climate_zone" not in candidate.suggested_cluster_columns


def test_lineage_all_columns_poor_adds_candidate_with_empty_suggestions():
    """When all columns are poor, candidate should have empty suggestions but quality data."""
    upstream = _make_node("stg_stations", depends_on_nodes=[])
    downstream = _make_node(
        "fct_readings",
        depends_on_nodes=["model.my_project.stg_stations"],
    )
    manifest = _make_manifest(
        {
            "model.my_project.stg_stations": upstream,
            "model.my_project.fct_readings": downstream,
        }
    )

    quality_map = {
        ("stg_stations", "country"): ColumnQuality(
            column_name="country",
            total_rows=1_000_000,
            null_count=730_000,
            null_ratio=0.73,
            approx_distinct=4,
            classification="poor",
            reason="73% NULL",
        ),
        ("stg_stations", "climate_zone"): ColumnQuality(
            column_name="climate_zone",
            total_rows=1_000_000,
            null_count=0,
            null_ratio=0.0,
            approx_distinct=3,
            classification="poor",
            reason="only 3 distinct values",
        ),
    }

    compiled_sql = """
    SELECT * FROM stg_stations s
    JOIN dim_countries c ON s.country = c.country AND s.climate_zone = c.climate_zone
    """

    result = analyze_upstream(
        manifest_content=manifest,
        affected_model_name="fct_readings",
        opportunity_type="join_explosion",
        compiled_sql=compiled_sql,
        column_quality_lookup=_make_quality_lookup(quality_map),
    )

    # Should still have a candidate (for ADK to suggest root-cause fix)
    assert len(result.candidates) == 1
    candidate = result.candidates[0]
    assert candidate.suggested_cluster_columns == []
    assert candidate.column_quality is not None
    # Analysis notes should explain why
    quality_notes = [
        n
        for n in result.analysis_notes
        if "poor quality" in n.lower() or "excluded" in n.lower()
    ]
    assert len(quality_notes) > 0


def test_lineage_no_quality_lookup_passes_through():
    """Without column_quality_lookup, behavior is unchanged (backward compatible)."""
    upstream = _make_node("stg_stations", depends_on_nodes=[])
    downstream = _make_node(
        "fct_readings",
        depends_on_nodes=["model.my_project.stg_stations"],
    )
    manifest = _make_manifest(
        {
            "model.my_project.stg_stations": upstream,
            "model.my_project.fct_readings": downstream,
        }
    )

    compiled_sql = """
    SELECT * FROM stg_stations s
    JOIN dim_countries c ON s.country = c.country
    """

    result = analyze_upstream(
        manifest_content=manifest,
        affected_model_name="fct_readings",
        opportunity_type="join_explosion",
        compiled_sql=compiled_sql,
        column_quality_lookup=None,
    )

    # Without quality lookup, all columns pass through
    assert len(result.candidates) == 1
    assert "country" in result.candidates[0].suggested_cluster_columns


def test_lineage_quality_lookup_failure_falls_back():
    """If quality lookup raises, columns pass through unchanged."""
    upstream = _make_node("stg_stations", depends_on_nodes=[])
    downstream = _make_node(
        "fct_readings",
        depends_on_nodes=["model.my_project.stg_stations"],
    )
    manifest = _make_manifest(
        {
            "model.my_project.stg_stations": upstream,
            "model.my_project.fct_readings": downstream,
        }
    )

    def failing_lookup(node, columns):
        raise ValueError("BigQuery timeout")

    compiled_sql = """
    SELECT * FROM stg_stations s
    JOIN dim_countries c ON s.country = c.country
    """

    result = analyze_upstream(
        manifest_content=manifest,
        affected_model_name="fct_readings",
        opportunity_type="join_explosion",
        compiled_sql=compiled_sql,
        column_quality_lookup=failing_lookup,
    )

    # Should still work, just without quality filtering
    assert len(result.candidates) == 1
    assert "country" in result.candidates[0].suggested_cluster_columns
