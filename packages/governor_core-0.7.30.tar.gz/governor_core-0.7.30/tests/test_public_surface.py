"""SC-002 / SC-003: core imports, no forbidden deps, public surface intact."""

from __future__ import annotations

import importlib


def test_public_surface_is_importable() -> None:
    api = importlib.import_module("governor_core.api")
    assert len(api.__all__) > 20  # sanity check
    for name in api.__all__:
        assert hasattr(api, name), f"public surface missing {name!r}"


def test_core_code_does_not_import_web_stack() -> None:
    """SC-002: no module *in* governor_core has an ``import fastapi`` etc.

    The AST-based ``scripts/import_boundary_check.py`` is authoritative; this
    test re-asserts the invariant at the Python import layer by looking only
    at modules whose names start with ``governor_core.`` and inspecting their
    source. Transitive third-party imports (e.g. google-api-core pulling
    ``bcrypt`` via authentication helpers) are not our concern.
    """
    import sys
    import ast

    import governor_core.api  # noqa: F401

    FORBIDDEN = {
        "fastapi",
        "starlette",
        "jinja2",
        "datastar_py",
        "apscheduler",
        "bcrypt",
        "smtplib",
    }

    offending: list[str] = []
    for name, module in list(sys.modules.items()):
        if not name.startswith("governor_core"):
            continue
        path = getattr(module, "__file__", None)
        if not path or not path.endswith(".py"):
            continue
        try:
            tree = ast.parse(open(path, "r", encoding="utf-8").read(), filename=path)
        except (OSError, SyntaxError):
            continue
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                for alias in node.names:
                    if alias.name.split(".", 1)[0] in FORBIDDEN:
                        offending.append(f"{name}: import {alias.name}")
            elif isinstance(node, ast.ImportFrom) and node.module:
                if node.module.split(".", 1)[0] in FORBIDDEN:
                    offending.append(f"{name}: from {node.module}")
    assert not offending, "governor_core source imports web-stack libs:\n" + "\n".join(offending)
