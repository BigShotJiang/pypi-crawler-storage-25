"""Tests for PR clearing status logic."""

from __future__ import annotations

import uuid
from datetime import datetime, timedelta, timezone
from unittest.mock import MagicMock, patch

from governor_core.github.client import GitHubConnectionError
from governor_core.pullrequests.clearing import (
    _expire_clearing,
    _find_downstream_models,
    apply_clearing_status,
)


class TestExpireClearing:
    """Tests for _expire_clearing."""

    def test_expires_past_clearing(self, db):
        """Opportunities past their clearing_until date revert to active."""
        from tests.helpers import _create_test_prereqs

        prereqs = _create_test_prereqs(db)
        opp = prereqs["opportunity"]
        opp.status = "clearing"
        opp.clearing_until = datetime.now(timezone.utc) - timedelta(hours=1)
        opp.clearing_pr_number = 42
        opp.clearing_repository = "org/repo"
        db.commit()

        count = _expire_clearing(db)
        db.flush()

        assert count == 1
        db.refresh(opp)
        assert opp.status == "active"
        assert opp.clearing_until is None
        assert opp.clearing_pr_number is None
        assert opp.clearing_repository is None

    def test_does_not_expire_future_clearing(self, db):
        """Opportunities with future clearing_until stay in clearing."""
        from tests.helpers import _create_test_prereqs

        prereqs = _create_test_prereqs(db)
        opp = prereqs["opportunity"]
        opp.status = "clearing"
        opp.clearing_until = datetime.now(timezone.utc) + timedelta(days=5)
        opp.clearing_pr_number = 42
        db.commit()

        count = _expire_clearing(db)

        assert count == 0
        db.refresh(opp)
        assert opp.status == "clearing"

    def test_does_not_touch_non_clearing(self, db):
        """Active opportunities are not affected by expiry."""
        from tests.helpers import _create_test_prereqs

        prereqs = _create_test_prereqs(db)
        opp = prereqs["opportunity"]
        assert opp.status == "active"

        count = _expire_clearing(db)
        assert count == 0


class TestApplyClearingStatus:
    """Tests for apply_clearing_status."""

    def test_sets_clearing_on_matching_opportunity(self, db):
        """A merged PR that changes a .sql file matching an opportunity model sets clearing."""
        from tests.helpers import _create_test_prereqs

        prereqs = _create_test_prereqs(db)
        opp = prereqs["opportunity"]
        model_name = "test_model"
        opp.dbt_model_name = model_name
        db.commit()

        # Create a merged PR record
        from governor_core.pullrequests.models import PullRequestRecord

        pr = PullRequestRecord(
            id=str(uuid.uuid4()),
            repository="org/repo",
            branch_name="governor/test",
            pr_number=99,
            pr_url="https://github.com/org/repo/pull/99",
            commit_sha="a" * 40,
            base_branch="main",
            status="merged",
            merged_at=datetime.now(timezone.utc) - timedelta(days=2),
        )
        db.add(pr)
        db.commit()

        # Mock GitHub client
        gh = MagicMock()
        gh.get_pull_request_files.return_value = [
            {"filename": f"models/staging/{model_name}.sql", "patch": "+test"}
        ]

        with patch(
            "governor_core.pullrequests.clearing._find_downstream_models", return_value=set()
        ):
            result = apply_clearing_status(db, gh)

        assert result["cleared"] == 1
        db.refresh(opp)
        assert opp.status == "clearing"
        assert opp.clearing_pr_number == 99
        assert opp.clearing_repository == "org/repo"
        assert opp.clearing_until is not None

    def test_skips_old_merged_prs(self, db):
        """Merged PRs older than CLEARING_WINDOW_DAYS are skipped."""
        from tests.helpers import _create_test_prereqs

        prereqs = _create_test_prereqs(db)
        opp = prereqs["opportunity"]
        opp.dbt_model_name = "old_model"
        db.commit()

        from governor_core.pullrequests.models import PullRequestRecord

        pr = PullRequestRecord(
            id=str(uuid.uuid4()),
            repository="org/repo",
            branch_name="governor/old",
            pr_number=50,
            pr_url="https://github.com/org/repo/pull/50",
            commit_sha="b" * 40,
            base_branch="main",
            status="merged",
            merged_at=datetime.now(timezone.utc) - timedelta(days=20),
        )
        db.add(pr)
        db.commit()

        gh = MagicMock()
        result = apply_clearing_status(db, gh)

        # Should not even call GitHub API — PR is outside window
        gh.get_pull_request_files.assert_not_called()
        assert result["cleared"] == 0
        db.refresh(opp)
        assert opp.status == "active"

    def test_skips_non_sql_files(self, db):
        """PR with only non-.sql files does not set clearing."""
        from tests.helpers import _create_test_prereqs

        prereqs = _create_test_prereqs(db)
        opp = prereqs["opportunity"]
        opp.dbt_model_name = "some_model"
        db.commit()

        from governor_core.pullrequests.models import PullRequestRecord

        pr = PullRequestRecord(
            id=str(uuid.uuid4()),
            repository="org/repo",
            branch_name="governor/readme",
            pr_number=77,
            pr_url="https://github.com/org/repo/pull/77",
            commit_sha="c" * 40,
            base_branch="main",
            status="merged",
            merged_at=datetime.now(timezone.utc) - timedelta(days=1),
        )
        db.add(pr)
        db.commit()

        gh = MagicMock()
        gh.get_pull_request_files.return_value = [
            {"filename": "README.md", "patch": "+update"},
            {"filename": "dbt_project.yml", "patch": "+config"},
        ]

        with patch(
            "governor_core.pullrequests.clearing._find_downstream_models", return_value=set()
        ):
            result = apply_clearing_status(db, gh)

        assert result["cleared"] == 0

    def test_includes_downstream_models(self, db):
        """Downstream models in the DAG also get clearing status."""
        from tests.helpers import _create_test_prereqs

        prereqs = _create_test_prereqs(db)
        opp = prereqs["opportunity"]
        opp.dbt_model_name = "downstream_model"
        db.commit()

        from governor_core.pullrequests.models import PullRequestRecord

        pr = PullRequestRecord(
            id=str(uuid.uuid4()),
            repository="org/repo",
            branch_name="governor/upstream",
            pr_number=88,
            pr_url="https://github.com/org/repo/pull/88",
            commit_sha="d" * 40,
            base_branch="main",
            status="merged",
            merged_at=datetime.now(timezone.utc) - timedelta(days=3),
        )
        db.add(pr)
        db.commit()

        gh = MagicMock()
        gh.get_pull_request_files.return_value = [
            {"filename": "models/staging/upstream_model.sql", "patch": "+fix"}
        ]

        # Mock downstream discovery to return the opportunity's model
        with patch(
            "governor_core.pullrequests.clearing._find_downstream_models",
            return_value={"downstream_model"},
        ):
            result = apply_clearing_status(db, gh)

        assert result["cleared"] == 1
        db.refresh(opp)
        assert opp.status == "clearing"

    def test_handles_github_error_gracefully(self, db):
        """GitHub API errors are counted but don't crash the process."""
        from governor_core.pullrequests.models import PullRequestRecord

        pr = PullRequestRecord(
            id=str(uuid.uuid4()),
            repository="org/repo",
            branch_name="governor/test",
            pr_number=66,
            pr_url="https://github.com/org/repo/pull/66",
            commit_sha="e" * 40,
            base_branch="main",
            status="merged",
            merged_at=datetime.now(timezone.utc) - timedelta(days=1),
        )
        db.add(pr)
        db.commit()

        gh = MagicMock()
        gh.get_pull_request_files.side_effect = GitHubConnectionError("API error")

        result = apply_clearing_status(db, gh)

        assert result["errors"] == 1


class TestFindDownstreamModels:
    """Tests for _find_downstream_models using manifest child_map."""

    def test_finds_direct_children(self, db):
        """Direct children in child_map are returned."""
        from tests.helpers import _create_test_prereqs

        prereqs = _create_test_prereqs(db)
        config = prereqs["config"]

        # Create a manifest version with child_map
        from governor_core.sync.models import ManifestVersion

        mv = ManifestVersion(
            id=str(uuid.uuid4()),
            config_id=config.id,
            sync_id=prereqs["sync_op"].id,
            content_hash="abc123",
            retrieved_at=datetime.now(timezone.utc),
            content={
                "nodes": {
                    "model.proj.stg_orders": {
                        "name": "stg_orders",
                        "unique_id": "model.proj.stg_orders",
                    },
                    "model.proj.fct_orders": {
                        "name": "fct_orders",
                        "unique_id": "model.proj.fct_orders",
                    },
                    "model.proj.rpt_revenue": {
                        "name": "rpt_revenue",
                        "unique_id": "model.proj.rpt_revenue",
                    },
                },
                "child_map": {
                    "model.proj.stg_orders": [
                        "model.proj.fct_orders",
                    ],
                    "model.proj.fct_orders": [
                        "model.proj.rpt_revenue",
                    ],
                },
            },
        )
        db.add(mv)
        db.commit()

        result = _find_downstream_models(
            db, config.github_repo, {"stg_orders"}
        )

        assert "fct_orders" in result
        assert "rpt_revenue" in result
        assert "stg_orders" not in result

    def test_no_manifest_returns_empty(self, db):
        """Missing manifest returns empty set."""
        result = _find_downstream_models(db, "nonexistent/repo", {"model"})
        assert result == set()

    def test_no_child_map_returns_empty(self, db):
        """Manifest without child_map returns empty set."""
        from tests.helpers import _create_test_prereqs

        prereqs = _create_test_prereqs(db)
        config = prereqs["config"]

        from governor_core.sync.models import ManifestVersion

        mv = ManifestVersion(
            id=str(uuid.uuid4()),
            config_id=config.id,
            sync_id=prereqs["sync_op"].id,
            content_hash="def456",
            retrieved_at=datetime.now(timezone.utc),
            content={
                "nodes": {
                    "model.proj.stg_orders": {
                        "name": "stg_orders",
                        "unique_id": "model.proj.stg_orders",
                    },
                },
            },
        )
        db.add(mv)
        db.commit()

        result = _find_downstream_models(
            db, config.github_repo, {"stg_orders"}
        )
        assert result == set()
