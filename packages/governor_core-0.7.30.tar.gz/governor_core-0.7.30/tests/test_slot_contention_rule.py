"""
Unit tests for SlotContentionRule.

Tests slot contention detection from BigQuery performance_insights and queue time.
"""

from datetime import datetime, timedelta, timezone
from decimal import Decimal
from unittest.mock import MagicMock

import pytest

from governor_core.opportunities.rules.slot_contention import SlotContentionRule


class TestSlotContentionRule:
    """Tests for slot contention detection."""

    def test_rule_type(self):
        """Test rule type identifier."""
        rule = SlotContentionRule()
        assert rule.rule_type == "slot_contention"

    def test_default_thresholds(self):
        """Test default threshold configuration."""
        rule = SlotContentionRule()
        thresholds = rule.default_thresholds

        assert thresholds["queue_time_ratio_threshold"] == 0.30
        assert thresholds["min_duration_seconds"] == 60
        assert thresholds["min_job_cost_usd"] == Decimal("0")

    def test_detect_with_slot_contention_flag(self):
        """Test detection via slot_contention flag."""
        rule = SlotContentionRule()

        now = datetime.now(timezone.utc)
        job = MagicMock()
        job.destination_table = "project.dataset.test_table"
        job.total_cost = Decimal("1.50")
        job.duration_ms = 120000  # 2 minutes
        job.total_slot_ms = 500000
        job.job_id = "job-123"
        job.creation_time = now - timedelta(minutes=5)
        job.start_time = now - timedelta(minutes=3)
        job.end_time = now
        job.performance_insights = {
            "stage_performance_standalone_insights": [
                {"stage_id": 1, "slot_contention": True}
            ]
        }

        candidates = rule.detect([job], None, rule.default_thresholds)

        assert len(candidates) == 1
        candidate = candidates[0]
        assert candidate.opportunity_type == "slot_contention"
        assert candidate.evidence_snapshot["slot_contention_flag"] is True
        assert candidate.confidence == 1.0

    def test_detect_with_high_queue_ratio(self):
        """Test detection via high queue time ratio."""
        rule = SlotContentionRule()

        now = datetime.now(timezone.utc)
        job = MagicMock()
        job.destination_table = "project.dataset.test_table"
        job.total_cost = Decimal("1.50")
        job.duration_ms = 120000
        job.total_slot_ms = 500000
        job.job_id = "job-123"
        # Queue time: 60s out of 150s total = 40%
        job.creation_time = now - timedelta(seconds=150)
        job.start_time = now - timedelta(seconds=90)
        job.end_time = now
        job.performance_insights = {
            "stage_performance_standalone_insights": [
                {"stage_id": 1, "slot_contention": False}
            ]
        }

        candidates = rule.detect([job], None, rule.default_thresholds)

        assert len(candidates) == 1
        candidate = candidates[0]
        assert candidate.opportunity_type == "slot_contention"
        assert candidate.evidence_snapshot["queue_ratio_percent"] == 40.0
        assert candidate.confidence == 0.9  # Secondary signal

    def test_detect_no_contention(self):
        """Test no detection when queue ratio is low."""
        rule = SlotContentionRule()

        now = datetime.now(timezone.utc)
        job = MagicMock()
        job.destination_table = "project.dataset.test_table"
        job.total_cost = Decimal("1.50")
        job.duration_ms = 120000
        job.total_slot_ms = 500000
        job.job_id = "job-123"
        # Queue time: 10s out of 130s = ~8% (below 30% threshold)
        job.creation_time = now - timedelta(seconds=130)
        job.start_time = now - timedelta(seconds=120)
        job.end_time = now
        job.performance_insights = {
            "stage_performance_standalone_insights": [
                {"stage_id": 1, "slot_contention": False}
            ]
        }

        candidates = rule.detect([job], None, rule.default_thresholds)
        assert len(candidates) == 0

    def test_detect_ignores_short_queries(self):
        """Test that short queries are ignored."""
        rule = SlotContentionRule()

        now = datetime.now(timezone.utc)
        job = MagicMock()
        job.destination_table = "project.dataset.test_table"
        job.total_cost = Decimal("1.50")
        job.duration_ms = 5000  # 5 seconds (below 60s threshold)
        job.total_slot_ms = 50000
        job.job_id = "job-123"
        job.creation_time = now - timedelta(seconds=50)
        job.start_time = now - timedelta(seconds=30)
        job.end_time = now
        job.performance_insights = {
            "stage_performance_standalone_insights": [
                {"stage_id": 1, "slot_contention": True}
            ]
        }

        candidates = rule.detect([job], None, rule.default_thresholds)
        assert len(candidates) == 0

    def test_queue_time_ratio_calculation(self):
        """Test queue time ratio is calculated correctly."""
        rule = SlotContentionRule()

        now = datetime.now(timezone.utc)
        job = MagicMock()
        # Total time: 100s, Queue time: 35s, Ratio: 35%
        job.creation_time = now - timedelta(seconds=100)
        job.start_time = now - timedelta(seconds=65)
        job.end_time = now

        ratio = rule._calculate_queue_ratio(job)
        assert ratio == pytest.approx(0.35, rel=0.01)

    def test_explanation_is_actionable(self):
        """Test that explanation includes actionable guidance."""
        rule = SlotContentionRule()

        now = datetime.now(timezone.utc)
        job = MagicMock()
        job.destination_table = "project.dataset.test_table"
        job.total_cost = Decimal("1.50")
        job.duration_ms = 120000
        job.total_slot_ms = 500000
        job.job_id = "job-123"
        job.creation_time = now - timedelta(seconds=150)
        job.start_time = now - timedelta(seconds=90)
        job.end_time = now
        job.performance_insights = {
            "stage_performance_standalone_insights": [
                {"stage_id": 1, "slot_contention": True}
            ]
        }

        candidates = rule.detect([job], None, rule.default_thresholds)

        assert len(candidates) == 1
        explanation = candidates[0].explanation

        # Check for actionable content
        assert "slot contention" in explanation.lower()
        assert "Consider:" in explanation
        assert "off-peak" in explanation.lower() or "scheduling" in explanation.lower()
