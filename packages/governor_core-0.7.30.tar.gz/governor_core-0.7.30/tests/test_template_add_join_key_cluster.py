"""Unit tests for app/solutions/templates/add_join_key_cluster.py."""

from types import SimpleNamespace

from governor_core.solutions.templates.add_join_key_cluster import AddJoinKeyClusterTemplate
from governor_core.solutions.templates.base import TemplateResult


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_opportunity(
    opp_type: str = "join_explosion",
    evidence: dict | None = None,
):
    return SimpleNamespace(
        id="opp-1",
        opportunity_type=opp_type,
        evidence_snapshot=evidence or {},
        dbt_model_name="my_model",
        affected_table="project.dataset.my_model",
    )


# ---------------------------------------------------------------------------
# SQL Fixtures
# ---------------------------------------------------------------------------

SQL_WITH_CONFIG = """\
{{ config(
    materialized='table'
) }}

SELECT id, name, created_at
FROM {{ ref('raw_orders') }}
"""

SQL_WITH_CLUSTER = """\
{{ config(
    materialized='table',
    cluster_by=["existing_col"]
) }}

SELECT id, name, created_at
FROM {{ ref('raw_orders') }}
"""

SQL_WITH_JOIN = """\
{{ config(
    materialized='table'
) }}

SELECT o.id, o.name, c.email
FROM {{ ref('orders') }} o
JOIN {{ ref('customers') }} c ON o.customer_id = c.id
"""

SQL_WITH_MULTIPLE_JOINS = """\
{{ config(
    materialized='table'
) }}

SELECT o.id, c.name, p.title
FROM {{ ref('orders') }} o
JOIN {{ ref('customers') }} c ON o.customer_id = c.id
JOIN {{ ref('products') }} p ON o.product_id = p.id
"""

SQL_WITH_JOIN_AND_CLUSTER = """\
{{ config(
    materialized='table',
    cluster_by=["customer_id"]
) }}

SELECT o.id, o.name, c.email
FROM {{ ref('orders') }} o
JOIN {{ ref('customers') }} c ON o.customer_id = c.id
"""

_METADATA = {"original_file_path": "models/my_model.sql"}


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


class TestAddJoinKeyClusterTemplate:
    def setup_method(self):
        self.template = AddJoinKeyClusterTemplate()

    def test_matches_join_explosion_with_join_sql(self):
        """Matches when opportunity_type is join_explosion and SQL has JOIN ON clause."""
        opp = _make_opportunity()
        source_files = {"models/my_model.sql": SQL_WITH_JOIN}
        assert self.template.matches(opp, source_files, _METADATA) is True

    def test_no_match_wrong_type(self):
        """Does not match when opportunity_type is not join_explosion."""
        opp = _make_opportunity(opp_type="shuffle_spill")
        source_files = {"models/my_model.sql": SQL_WITH_JOIN}
        assert self.template.matches(opp, source_files, _METADATA) is False

    def test_no_match_no_joins_in_sql(self):
        """Does not match when SQL has no JOIN clause."""
        opp = _make_opportunity()
        source_files = {"models/my_model.sql": SQL_WITH_CONFIG}
        assert self.template.matches(opp, source_files, _METADATA) is False

    def test_apply_inserts_cluster_by_from_join_keys(self):
        """Apply extracts join key columns and inserts cluster_by."""
        opp = _make_opportunity()
        source_files = {"models/my_model.sql": SQL_WITH_JOIN}
        result = self.template.apply(opp, source_files, _METADATA)

        assert result is not None
        assert isinstance(result, TemplateResult)
        assert result.template_id == "add_join_key_cluster"
        assert result.file_path == "models/my_model.sql"
        assert result.before_content == SQL_WITH_JOIN
        assert "cluster_by" in result.after_content
        assert result.change_type == "project_config_change"
        assert result.policy_tags == ["dbt_config_change"]
        # Should extract customer_id and id from ON o.customer_id = c.id
        assert "customer_id" in result.parameters["columns"]
        assert "id" in result.parameters["columns"]

    def test_apply_merges_with_existing_cluster_by(self):
        """When cluster_by already exists, new join key columns are merged in."""
        opp = _make_opportunity()
        source_files = {"models/my_model.sql": SQL_WITH_JOIN_AND_CLUSTER}
        result = self.template.apply(opp, source_files, _METADATA)

        assert result is not None
        # Should have the original "customer_id" and new "id" from join
        assert "customer_id" in result.after_content
        assert "id" in result.after_content

    def test_extract_join_columns_multiple_joins(self):
        """Extracts columns from multiple JOIN ON clauses."""
        opp = _make_opportunity()
        source_files = {"models/my_model.sql": SQL_WITH_MULTIPLE_JOINS}
        result = self.template.apply(opp, source_files, _METADATA)

        assert result is not None
        columns = result.parameters["columns"]
        assert "customer_id" in columns
        assert "product_id" in columns
        assert "id" in columns

    def test_extract_join_columns_max_4(self):
        """Respects _MAX_CLUSTER_COLUMNS limit of 4."""
        sql = """\
{{ config(materialized="table") }}

SELECT a.x FROM t a
JOIN t1 ON a.c1 = t1.d1
JOIN t2 ON a.c2 = t2.d2
JOIN t3 ON a.c3 = t3.d3
JOIN t4 ON a.c4 = t4.d4
JOIN t5 ON a.c5 = t5.d5
"""
        opp = _make_opportunity()
        source_files = {"models/my_model.sql": sql}
        result = self.template.apply(opp, source_files, _METADATA)

        assert result is not None
        assert len(result.parameters["columns"]) <= 4

    def test_extract_join_columns_handles_parse_failure(self):
        """Malformed SQL returns no columns and does not match."""
        malformed_sql = """\
{{ config(materialized="table") }}

SELECT ??? FROM !!INVALID!! JOIN ON = =
"""
        opp = _make_opportunity()
        source_files = {"models/my_model.sql": malformed_sql}
        # Should not match because no columns could be extracted
        assert self.template.matches(opp, source_files, _METADATA) is False
