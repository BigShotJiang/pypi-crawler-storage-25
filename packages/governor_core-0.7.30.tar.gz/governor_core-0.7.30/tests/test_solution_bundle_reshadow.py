"""Tests for solutions/reshadow.kick_off_reshadow (spec 128 US2, T021-T022)."""

from __future__ import annotations

from datetime import datetime, timezone

import pytest

from governor_core.solutions.reshadow import kick_off_reshadow
from tests.fixtures.factories import ShadowValidationRunFactory, SolutionFactory


class TestKickOffReshadow:
    def test_queues_a_new_run(self, db):
        solution = SolutionFactory.create()
        db.flush()
        new_run = kick_off_reshadow(db, solution)
        db.flush()
        assert new_run.solution_id == solution.id
        assert new_run.status == "queued"
        assert new_run.triggered_by == "manual"

    def test_supersedes_in_flight_run(self, db):
        solution = SolutionFactory.create()
        db.flush()
        prior = ShadowValidationRunFactory.create(
            _solution=solution, status="running"
        )
        db.flush()
        new_run = kick_off_reshadow(db, solution)
        db.flush()
        db.refresh(prior)
        assert prior.status == "superseded"
        assert new_run.id != prior.id
        assert new_run.status == "queued"

    def test_does_not_supersede_finished_runs(self, db):
        solution = SolutionFactory.create()
        db.flush()
        done = ShadowValidationRunFactory.create(
            _solution=solution, status="shadow_succeeded"
        )
        db.flush()
        kick_off_reshadow(db, solution)
        db.flush()
        db.refresh(done)
        assert done.status == "shadow_succeeded"
