"""Unit tests for the Gemini LLM provider and LLM configuration helpers."""

from __future__ import annotations

import json
from unittest.mock import MagicMock, patch

import pytest

from governor_core.core.config import get_settings
from governor_core.llm.schemas import SolutionRequest


# ---------------------------------------------------------------------------
# Fixtures / helpers
# ---------------------------------------------------------------------------


def _make_request(**overrides) -> SolutionRequest:
    defaults = {
        "opportunity_type": "shuffle_spill",
        "affected_table": "project.dataset.table1",
        "severity_score": 75,
        "evidence_snapshot": {"spill_bytes": 1_000_000},
        "explanation": "High shuffle spill detected",
        "dbt_model_name": "stg_orders",
        "source_files": {"models/stg_orders.sql": "SELECT * FROM raw.orders"},
    }
    defaults.update(overrides)
    return SolutionRequest(**defaults)


def _mock_response_text(resolution_category: str = "dbt_project_change") -> str:
    """Return a valid SolutionResponse JSON string."""
    if resolution_category == "dbt_project_change":
        data = {
            "resolution_category": "dbt_project_change",
            "explanation": "Reduce selected columns to avoid shuffle spill",
            "risk_level": "low",
            "risk_justification": "Simple column pruning",
            "file_changes": [
                {
                    "file_path": "models/stg_orders.sql",
                    "change_type": "sql_change",
                    "before_content": "SELECT * FROM raw.orders",
                    "after_content": "SELECT id, status FROM raw.orders",
                }
            ],
            "setting_recommendation": None,
        }
    else:
        data = {
            "resolution_category": "bigquery_infrastructure",
            "explanation": "Increase slot reservation",
            "risk_level": "medium",
            "risk_justification": "Requires capacity planning",
            "file_changes": None,
            "setting_recommendation": {
                "current_value": "100",
                "recommended_value": "200",
                "affected_resource": "project.reservation",
            },
        }
    return json.dumps(data)


def _mock_genai_response(
    text: str, prompt_tokens=100, completion_tokens=200, total_tokens=300
):
    """Create a mock Gemini response object."""
    response = MagicMock()
    response.text = text
    response.usage_metadata = MagicMock()
    response.usage_metadata.prompt_token_count = prompt_tokens
    response.usage_metadata.candidates_token_count = completion_tokens
    response.usage_metadata.total_token_count = total_tokens
    return response


def _create_provider_with_mock_client():
    """Create a GeminiProvider with a mocked genai.Client."""
    with patch("google.genai.Client") as mock_client_cls:
        mock_client = MagicMock()
        mock_client_cls.return_value = mock_client
        from governor_core.llm.gemini import GeminiProvider

        provider = GeminiProvider(api_key="test-key")
        return provider, mock_client, mock_client_cls


# ---------------------------------------------------------------------------
# GeminiProvider tests
# ---------------------------------------------------------------------------


class TestGeminiProviderCreation:
    """Test Gemini provider instantiation."""

    def test_provider_created_with_valid_config(self, client):
        """GeminiProvider can be created when API key is provided."""
        provider, mock_client, mock_client_cls = _create_provider_with_mock_client()
        assert provider is not None
        mock_client_cls.assert_called_once_with(api_key="test-key")

    def test_provider_uses_settings_defaults(self, client):
        """GeminiProvider falls back to settings for unspecified parameters."""
        provider, _, _ = _create_provider_with_mock_client()
        settings = get_settings()
        assert provider._model == settings.llm_model
        assert provider._temperature == settings.llm_temperature
        assert provider._max_tokens == settings.llm_max_tokens

    def test_provider_uses_custom_params(self, client):
        """GeminiProvider uses explicitly provided parameters."""
        with patch("google.genai.Client"):
            from governor_core.llm.gemini import GeminiProvider

            provider = GeminiProvider(
                api_key="test-key",
                model="gemini-2.5-pro",
                temperature=0.5,
                max_tokens=8192,
            )
            assert provider._model == "gemini-2.5-pro"
            assert provider._temperature == 0.5
            assert provider._max_tokens == 8192


class TestGeminiProviderGenerate:
    """Test Gemini provider generate() method."""

    def test_generate_applies_http_timeout(self, client):
        """generate() passes the configured timeout through to the SDK request config."""
        response_text = _mock_response_text("dbt_project_change")
        mock_response = _mock_genai_response(response_text)

        provider, mock_client, _ = _create_provider_with_mock_client()
        mock_client.models.generate_content.return_value = mock_response

        with patch("google.genai.types") as mock_types:
            mock_types.HttpOptions.return_value = MagicMock()
            mock_types.GenerateContentConfig.return_value = MagicMock()
            provider.generate(_make_request())

        mock_types.HttpOptions.assert_called_once_with(timeout=provider._timeout_ms)
        assert (
            mock_types.GenerateContentConfig.call_args.kwargs["http_options"]
            == mock_types.HttpOptions.return_value
        )

    def test_generate_dbt_project_change(self, client):
        """generate() returns SolutionResponse for dbt project change."""
        response_text = _mock_response_text("dbt_project_change")
        mock_response = _mock_genai_response(response_text)

        provider, mock_client, _ = _create_provider_with_mock_client()
        mock_client.models.generate_content.return_value = mock_response

        with patch("google.genai.types") as mock_types:
            mock_types.GenerateContentConfig.return_value = MagicMock()
            request = _make_request()
            solution, metadata = provider.generate(request)

        assert solution.resolution_category == "dbt_project_change"
        assert solution.file_changes is not None
        assert len(solution.file_changes) == 1
        assert solution.risk_level == "low"
        assert metadata.provider == "gemini"
        assert metadata.prompt_tokens == 100
        assert metadata.completion_tokens == 200

    def test_generate_bigquery_infrastructure(self, client):
        """generate() returns SolutionResponse for BigQuery infrastructure."""
        response_text = _mock_response_text("bigquery_infrastructure")
        mock_response = _mock_genai_response(response_text)

        provider, mock_client, _ = _create_provider_with_mock_client()
        mock_client.models.generate_content.return_value = mock_response

        with patch("google.genai.types") as mock_types:
            mock_types.GenerateContentConfig.return_value = MagicMock()
            request = _make_request()
            solution, metadata = provider.generate(request)

        assert solution.resolution_category == "bigquery_infrastructure"
        assert solution.setting_recommendation is not None
        assert solution.setting_recommendation.recommended_value == "200"

    def test_generate_empty_response_raises(self, client):
        """generate() raises LLMResponseValidationError on empty text."""
        mock_response = MagicMock()
        mock_response.text = ""
        mock_response.usage_metadata = None

        provider, mock_client, _ = _create_provider_with_mock_client()
        mock_client.models.generate_content.return_value = mock_response

        from governor_core.solutions.exceptions import LLMResponseValidationError

        with patch("google.genai.types") as mock_types:
            mock_types.GenerateContentConfig.return_value = MagicMock()
            with pytest.raises(LLMResponseValidationError, match="empty response"):
                provider.generate(_make_request())

    def test_generate_invalid_json_raises(self, client):
        """generate() raises LLMResponseValidationError on malformed JSON."""
        mock_response = MagicMock()
        mock_response.text = "not valid json"
        mock_response.usage_metadata = None

        provider, mock_client, _ = _create_provider_with_mock_client()
        mock_client.models.generate_content.return_value = mock_response

        from governor_core.solutions.exceptions import LLMResponseValidationError

        with patch("google.genai.types") as mock_types:
            mock_types.GenerateContentConfig.return_value = MagicMock()
            with pytest.raises(LLMResponseValidationError, match="Failed to parse"):
                provider.generate(_make_request())


# ---------------------------------------------------------------------------
# is_llm_configured / get_llm_provider tests
# ---------------------------------------------------------------------------


class TestLLMConfiguration:
    """Test LLM configuration helpers."""

    def test_is_llm_configured_returns_true_when_key_present(self, client):
        """is_llm_configured() returns True when LLM_API_KEY is set."""
        import os

        os.environ["LLM_API_KEY"] = "test-key"
        get_settings.cache_clear()
        try:
            from governor_core.llm import is_llm_configured

            assert is_llm_configured() is True
        finally:
            del os.environ["LLM_API_KEY"]
            get_settings.cache_clear()

    def test_is_llm_configured_returns_false_when_key_absent(self, client):
        """is_llm_configured() returns False when LLM_API_KEY is not set."""
        import os

        os.environ.pop("LLM_API_KEY", None)
        get_settings.cache_clear()
        try:
            from governor_core.llm import is_llm_configured

            assert is_llm_configured() is False
        finally:
            get_settings.cache_clear()

    def test_get_llm_provider_returns_none_without_key(self, client):
        """get_llm_provider() returns None and logs warning when key absent."""
        import os

        os.environ.pop("LLM_API_KEY", None)
        get_settings.cache_clear()
        try:
            from governor_core.llm import get_llm_provider

            provider = get_llm_provider()
            assert provider is None
        finally:
            get_settings.cache_clear()

    def test_get_llm_provider_returns_gemini_with_key(self, client):
        """get_llm_provider() returns GeminiProvider when key is set."""
        import os

        os.environ["LLM_API_KEY"] = "test-key"
        os.environ["LLM_PROVIDER"] = "gemini"
        get_settings.cache_clear()
        try:
            with patch("google.genai.Client"):
                from governor_core.llm import get_llm_provider
                from governor_core.llm.gemini import GeminiProvider

                provider = get_llm_provider()
                assert isinstance(provider, GeminiProvider)
        finally:
            del os.environ["LLM_API_KEY"]
            os.environ.pop("LLM_PROVIDER", None)
            get_settings.cache_clear()

    def test_get_llm_provider_unsupported_type_returns_none(self, client):
        """get_llm_provider() returns None for unsupported provider type."""
        import os

        os.environ["LLM_API_KEY"] = "test-key"
        os.environ["LLM_PROVIDER"] = "openai"
        get_settings.cache_clear()
        try:
            from governor_core.llm import get_llm_provider

            provider = get_llm_provider()
            assert provider is None
        finally:
            del os.environ["LLM_API_KEY"]
            del os.environ["LLM_PROVIDER"]
            get_settings.cache_clear()
