"""
Unit tests for OpportunityService.

Tests CRUD operations, deduplication, and lifecycle management.
Updated for model flattening: ManifestLocation removed, Opportunity.config_id
points directly to ManifestConfiguration.
"""

from datetime import datetime, timedelta, timezone
from decimal import Decimal
from unittest.mock import MagicMock, patch

import pytest

from governor_core.opportunities.exceptions import (
    ActiveDetectionJobExistsError,
    DetectionJobExistsError,
    LatestCompletedSyncNotFoundError,
    SyncNotCompletedError,
)
from governor_core.opportunities.models import (
    DetectionJob,
    Opportunity,
    OpportunityDetectionHistory,
)
from governor_core.opportunities.rules.base import OpportunityCandidate
from governor_core.opportunities.service import OpportunityService


class TestDetectionJobManagement:
    """Tests for detection job CRUD operations."""

    def test_create_detection_job_success(self, db_session):
        """Test creating a detection job for completed sync."""
        from governor_core.sync.models import SyncOperation

        sync = MagicMock(spec=SyncOperation)
        sync.id = "sync-123"
        sync.status = "completed"

        with patch.object(db_session, "get", return_value=sync):
            with patch.object(db_session, "execute") as mock_execute:
                mock_execute.return_value.scalar_one_or_none.return_value = None

                service = OpportunityService(db_session)
                job = service.create_detection_job(
                    config_id="config-123",
                    sync_id="sync-123",
                )

                assert job.config_id == "config-123"
                assert job.sync_id == "sync-123"
                assert job.status == "queued"

    def test_create_detection_job_sync_not_completed(self, db_session):
        """Test error when sync is not completed."""
        from governor_core.sync.models import SyncOperation

        sync = MagicMock(spec=SyncOperation)
        sync.id = "sync-123"
        sync.status = "in_progress"

        with patch.object(db_session, "get", return_value=sync):
            service = OpportunityService(db_session)

            with pytest.raises(SyncNotCompletedError) as exc_info:
                service.create_detection_job(
                    config_id="config-123",
                    sync_id="sync-123",
                )

            assert exc_info.value.sync_id == "sync-123"
            assert exc_info.value.status == "in_progress"

    def test_create_detection_job_already_exists(self, db_session):
        """Test error when detection job already exists for sync."""
        from governor_core.sync.models import SyncOperation

        sync = MagicMock(spec=SyncOperation)
        sync.id = "sync-123"
        sync.status = "completed"

        existing_job = MagicMock(spec=DetectionJob)
        existing_job.id = "job-456"

        with patch.object(db_session, "get", return_value=sync):
            with patch.object(db_session, "execute") as mock_execute:
                mock_execute.return_value.scalar_one_or_none.return_value = existing_job

                service = OpportunityService(db_session)

                with pytest.raises(DetectionJobExistsError) as exc_info:
                    service.create_detection_job(
                        config_id="config-123",
                        sync_id="sync-123",
                    )

                assert exc_info.value.sync_id == "sync-123"

    def test_queue_detection_rerun_for_latest_sync_without_completed_sync(
        self, db_session
    ):
        service = OpportunityService(db_session)

        with patch.object(service, "get_latest_completed_sync", return_value=None):
            with pytest.raises(LatestCompletedSyncNotFoundError) as exc_info:
                service.queue_detection_rerun_for_latest_sync("config-123")

        assert exc_info.value.config_id == "config-123"

    def test_create_detection_rerun_job_rejects_active_same_sync(self, db_session):
        from governor_core.sync.models import SyncOperation

        sync = MagicMock(spec=SyncOperation)
        sync.id = "sync-123"
        sync.status = "completed"

        active_job = DetectionJob(
            id="job-123",
            config_id="config-123",
            sync_id="sync-123",
            status="queued",
        )

        with patch.object(db_session, "get", return_value=sync):
            with patch.object(db_session, "execute") as mock_execute:
                mock_execute.return_value.scalar_one_or_none.return_value = active_job

                service = OpportunityService(db_session)
                with pytest.raises(ActiveDetectionJobExistsError) as exc_info:
                    service.create_detection_rerun_job("config-123", "sync-123")

        assert exc_info.value.config_id == "config-123"
        assert exc_info.value.sync_id == "sync-123"

    def test_get_pending_detection_job(self, db_session):
        """Test getting the next queued job."""
        job = MagicMock(spec=DetectionJob)
        job.id = "job-123"
        job.status = "queued"

        with patch.object(db_session, "execute") as mock_execute:
            mock_execute.return_value.scalar_one_or_none.return_value = job

            service = OpportunityService(db_session)
            result = service.get_pending_detection_job()

            assert result == job

    def test_claim_detection_job_success(self, db_session):
        """Test claiming a detection job."""
        with patch.object(db_session, "execute") as mock_execute:
            mock_execute.return_value.rowcount = 1

            service = OpportunityService(db_session)
            result = service.claim_detection_job("job-123")

            assert result is True

    def test_claim_detection_job_already_claimed(self, db_session):
        """Test claiming an already claimed job."""
        with patch.object(db_session, "execute") as mock_execute:
            mock_execute.return_value.rowcount = 0

            service = OpportunityService(db_session)
            result = service.claim_detection_job("job-123")

            assert result is False

    def test_complete_detection_job(self, db_session):
        """Test completing a detection job."""
        job = DetectionJob(
            id="job-123",
            config_id="config-123",
            sync_id="sync-123",
            status="in_progress",
        )

        with patch.object(db_session, "get", return_value=job):
            service = OpportunityService(db_session)
            result = service.complete_detection_job(
                detection_job_id="job-123",
                found_count=5,
                updated_count=3,
                resolved_count=2,
            )

            assert result.status == "completed"
            assert result.opportunities_found_count == 5
            assert result.opportunities_updated_count == 3
            assert result.opportunities_resolved_count == 2
            assert result.completed_at is not None

    def test_fail_detection_job_with_retry(self, db_session):
        """Test failing a job that can be retried."""
        job = DetectionJob(
            id="job-123",
            config_id="config-123",
            sync_id="sync-123",
            status="in_progress",
            retry_count=1,
        )

        with patch.object(db_session, "get", return_value=job):
            service = OpportunityService(db_session)
            result = service.fail_detection_job(
                detection_job_id="job-123",
                error_message="Test error",
            )

            assert result.status == "queued"  # Back to queued for retry
            assert result.retry_count == 2
            assert result.error_message == "Test error"

    def test_fail_detection_job_permanent(self, db_session):
        """Test permanently failing a job after max retries."""
        job = DetectionJob(
            id="job-123",
            config_id="config-123",
            sync_id="sync-123",
            status="in_progress",
            retry_count=2,  # Already retried twice
        )

        with patch.object(db_session, "get", return_value=job):
            service = OpportunityService(db_session)
            result = service.fail_detection_job(
                detection_job_id="job-123",
                error_message="Test error",
            )

            assert result.status == "failed"  # Permanently failed
            assert result.retry_count == 3
            assert result.completed_at is not None


class TestOpportunityPersistence:
    """Tests for opportunity persistence and deduplication (manifest-scoped)."""

    def test_persist_opportunity_creates_new(self, db_session):
        """Test creating a new opportunity with manifest association."""
        candidate = OpportunityCandidate(
            opportunity_type="shuffle_spill",
            affected_table="project.dataset.table1",
            severity_score=65,
            evidence_snapshot={"test": "data"},
            current_cost_estimate=Decimal("10.00"),
            expected_savings=Decimal("2.50"),
            explanation="Test explanation",
            related_job_ids=["job-1", "job-2"],
            dbt_model_name="model_a",
        )

        with patch.object(db_session, "execute") as mock_execute:
            mock_execute.return_value.scalar_one_or_none.return_value = None

            service = OpportunityService(db_session)
            opp, action = service.persist_opportunity(
                config_id="manifest-loc-123",
                manifest_version_id="manifest-ver-456",
                detection_job_id="detection-123",
                candidate=candidate,
            )

            assert action == "created"
            assert opp.opportunity_type == "shuffle_spill"
            assert opp.affected_table == "project.dataset.table1"
            assert opp.config_id == "manifest-loc-123"
            assert opp.manifest_version_id == "manifest-ver-456"
            assert opp.first_detection_job_id == "detection-123"

    def test_persist_opportunity_updates_existing(self, db_session):
        """Test updating an existing active opportunity."""
        existing = Opportunity(
            id="opp-123",
            config_id="manifest-loc-123",
            manifest_version_id="manifest-ver-old",
            opportunity_type="shuffle_spill",
            affected_table="project.dataset.table1",
            status="active",
            severity_score=50,
            evidence_snapshot={},
            current_cost_estimate=Decimal("5.00"),
            expected_savings=Decimal("1.00"),
            explanation="Old explanation",
            related_job_ids=[],
            first_detection_job_id="old-detection",
        )

        candidate = OpportunityCandidate(
            opportunity_type="shuffle_spill",
            affected_table="project.dataset.table1",
            severity_score=65,
            evidence_snapshot={"new": "data"},
            current_cost_estimate=Decimal("10.00"),
            expected_savings=Decimal("2.50"),
            explanation="New explanation",
            related_job_ids=["job-1"],
        )

        with patch.object(db_session, "execute") as mock_execute:
            mock_execute.return_value.scalar_one_or_none.return_value = existing

            service = OpportunityService(db_session)
            opp, action = service.persist_opportunity(
                config_id="manifest-loc-123",
                manifest_version_id="manifest-ver-new",
                detection_job_id="detection-456",
                candidate=candidate,
            )

            assert action == "updated"
            assert opp.severity_score == 65
            assert opp.explanation == "New explanation"
            assert opp.manifest_version_id == "manifest-ver-new"
            assert opp.first_detection_job_id == "old-detection"  # Preserved
            assert opp.last_detection_job_id == "detection-456"  # Updated

    def test_persist_opportunity_reactivates_resolved(self, db_session):
        """Test reactivating a resolved opportunity."""
        existing = Opportunity(
            id="opp-123",
            config_id="manifest-loc-123",
            manifest_version_id="manifest-ver-old",
            opportunity_type="shuffle_spill",
            affected_table="project.dataset.table1",
            status="resolved",
            resolved_at=datetime.now(timezone.utc),
            severity_score=50,
            evidence_snapshot={},
            current_cost_estimate=Decimal("5.00"),
            expected_savings=Decimal("1.00"),
            explanation="Old explanation",
            related_job_ids=[],
            first_detection_job_id="old-detection",
        )

        candidate = OpportunityCandidate(
            opportunity_type="shuffle_spill",
            affected_table="project.dataset.table1",
            severity_score=65,
            evidence_snapshot={"new": "data"},
            current_cost_estimate=Decimal("10.00"),
            expected_savings=Decimal("2.50"),
            explanation="New explanation",
            related_job_ids=["job-1"],
        )

        with patch.object(db_session, "execute") as mock_execute:
            mock_execute.return_value.scalar_one_or_none.return_value = existing

            service = OpportunityService(db_session)
            opp, action = service.persist_opportunity(
                config_id="manifest-loc-123",
                manifest_version_id="manifest-ver-new",
                detection_job_id="detection-456",
                candidate=candidate,
            )

            assert action == "reactivated"
            assert opp.status == "active"
            assert opp.resolved_at is None

    def test_multiple_opportunity_types_per_table(self, db_session):
        """Test that a table can have multiple opportunity types."""
        candidate1 = OpportunityCandidate(
            opportunity_type="shuffle_spill",
            affected_table="project.dataset.table1",
            severity_score=50,
            evidence_snapshot={},
            current_cost_estimate=Decimal("10.00"),
            expected_savings=Decimal("2.00"),
            explanation="Shuffle spill",
            related_job_ids=["job-1"],
        )

        candidate2 = OpportunityCandidate(
            opportunity_type="join_explosion",
            affected_table="project.dataset.table1",
            severity_score=70,
            evidence_snapshot={},
            current_cost_estimate=Decimal("20.00"),
            expected_savings=Decimal("5.00"),
            explanation="Join explosion",
            related_job_ids=["job-2"],
        )

        with patch.object(db_session, "execute") as mock_execute:
            mock_execute.return_value.scalar_one_or_none.return_value = None

            service = OpportunityService(db_session)

            opp1, action1 = service.persist_opportunity(
                config_id="manifest-loc-123",
                manifest_version_id="manifest-ver-456",
                detection_job_id="detection-123",
                candidate=candidate1,
            )

            opp2, action2 = service.persist_opportunity(
                config_id="manifest-loc-123",
                manifest_version_id="manifest-ver-456",
                detection_job_id="detection-123",
                candidate=candidate2,
            )

            assert action1 == "created"
            assert action2 == "created"
            assert opp1.opportunity_type == "shuffle_spill"
            assert opp2.opportunity_type == "join_explosion"
            assert opp1.affected_table == opp2.affected_table


class TestDeduplicationScoping:
    """Tests for manifest-scoped deduplication (US3)."""

    def test_same_type_table_different_manifests_creates_distinct(self, db_session):
        """Two manifests, same opportunity type+table -> two distinct records."""
        candidate = OpportunityCandidate(
            opportunity_type="shuffle_spill",
            affected_table="project.dataset.table1",
            severity_score=50,
            evidence_snapshot={},
            current_cost_estimate=Decimal("10.00"),
            expected_savings=Decimal("2.00"),
            explanation="Test",
            related_job_ids=["job-1"],
        )

        with patch.object(db_session, "execute") as mock_execute:
            mock_execute.return_value.scalar_one_or_none.return_value = None

            service = OpportunityService(db_session)

            opp_a, action_a = service.persist_opportunity(
                config_id="manifest-A",
                manifest_version_id="ver-A",
                detection_job_id="det-1",
                candidate=candidate,
            )

            opp_b, action_b = service.persist_opportunity(
                config_id="manifest-B",
                manifest_version_id="ver-B",
                detection_job_id="det-1",
                candidate=candidate,
            )

            assert action_a == "created"
            assert action_b == "created"
            assert opp_a.config_id == "manifest-A"
            assert opp_b.config_id == "manifest-B"

    def test_same_manifest_same_type_updates_not_duplicates(self, db_session):
        """Same manifest, same type+table detected twice -> single record updated."""
        existing = Opportunity(
            id="opp-existing",
            config_id="manifest-A",
            manifest_version_id="ver-A-old",
            opportunity_type="shuffle_spill",
            affected_table="project.dataset.table1",
            status="active",
            severity_score=50,
            evidence_snapshot={},
            current_cost_estimate=Decimal("5.00"),
            expected_savings=Decimal("1.00"),
            explanation="Old",
            related_job_ids=[],
            first_detection_job_id="det-old",
        )

        candidate = OpportunityCandidate(
            opportunity_type="shuffle_spill",
            affected_table="project.dataset.table1",
            severity_score=65,
            evidence_snapshot={"new": True},
            current_cost_estimate=Decimal("10.00"),
            expected_savings=Decimal("2.00"),
            explanation="New",
            related_job_ids=["job-1"],
        )

        with patch.object(db_session, "execute") as mock_execute:
            mock_execute.return_value.scalar_one_or_none.return_value = existing

            service = OpportunityService(db_session)
            opp, action = service.persist_opportunity(
                config_id="manifest-A",
                manifest_version_id="ver-A-new",
                detection_job_id="det-new",
                candidate=candidate,
            )

            assert action == "updated"
            assert opp.id == "opp-existing"
            assert opp.severity_score == 65
            assert opp.manifest_version_id == "ver-A-new"

    def test_opportunity_under_manifest_a_unaffected_by_manifest_b(self, db_session):
        """Opportunity exists under manifest A, detect same under manifest B -> A unaffected."""
        with patch.object(db_session, "execute") as mock_execute:
            mock_execute.return_value.scalar_one_or_none.return_value = None

            candidate = OpportunityCandidate(
                opportunity_type="shuffle_spill",
                affected_table="project.dataset.table1",
                severity_score=50,
                evidence_snapshot={},
                current_cost_estimate=Decimal("10.00"),
                expected_savings=Decimal("2.00"),
                explanation="Test",
                related_job_ids=["job-1"],
            )

            service = OpportunityService(db_session)
            opp_b, action = service.persist_opportunity(
                config_id="manifest-B",
                manifest_version_id="ver-B",
                detection_job_id="det-1",
                candidate=candidate,
            )

            assert action == "created"
            assert opp_b.config_id == "manifest-B"


class TestResolutionScoping:
    """Tests for manifest-scoped resolution using evaluate_resolution (updated from mark_resolved)."""

    def test_evaluate_resolution_manifest_a_does_not_affect_manifest_b(
        self, db_session
    ):
        """evaluate_resolution for manifest A does not affect manifest B's opportunities."""
        opp_a = MagicMock(spec=Opportunity)
        opp_a.opportunity_type = "shuffle_spill"
        opp_a.affected_table = "table1"
        opp_a.status = "active"
        opp_a.last_detected_at = datetime.now(timezone.utc) - timedelta(days=15)
        opp_a.consecutive_clean_days = 0

        with patch.object(db_session, "execute") as mock_execute:
            mock_execute.return_value.scalars.return_value.all.return_value = [opp_a]

            service = OpportunityService(db_session)
            count = service.evaluate_resolution(
                config_id="manifest-A",
                detected_keys=set(),
                resolution_period_days=10,
            )

            assert count == 1
            assert opp_a.status == "resolved"
            assert opp_a.resolved_at is not None

    def test_evaluate_resolution_only_undetected_under_manifest(self, db_session):
        """evaluate_resolution for manifest A resolves only undetected opportunities under A."""
        opp1 = MagicMock(spec=Opportunity)
        opp1.opportunity_type = "shuffle_spill"
        opp1.affected_table = "table1"
        opp1.status = "active"
        opp1.last_detected_at = datetime.now(timezone.utc) - timedelta(days=15)
        opp1.consecutive_clean_days = 0

        opp2 = MagicMock(spec=Opportunity)
        opp2.opportunity_type = "slot_contention"
        opp2.affected_table = "table2"
        opp2.status = "active"
        opp2.last_detected_at = datetime.now(timezone.utc) - timedelta(days=15)
        opp2.consecutive_clean_days = 0

        with patch.object(db_session, "execute") as mock_execute:
            mock_execute.return_value.scalars.return_value.all.return_value = [
                opp1,
                opp2,
            ]

            service = OpportunityService(db_session)
            detected_keys = {("shuffle_spill", "table1")}
            count = service.evaluate_resolution(
                config_id="manifest-A",
                detected_keys=detected_keys,
                resolution_period_days=10,
            )

            assert count == 1
            assert opp2.status == "resolved"
            assert opp2.resolved_at is not None

    def test_evaluate_resolution_empty_detected_keys_resolves_past_threshold(
        self, db_session
    ):
        """evaluate_resolution with empty detected_keys resolves opportunities past threshold."""
        opp1 = MagicMock(spec=Opportunity)
        opp1.opportunity_type = "shuffle_spill"
        opp1.affected_table = "table1"
        opp1.status = "active"
        opp1.last_detected_at = datetime.now(timezone.utc) - timedelta(days=15)
        opp1.consecutive_clean_days = 0

        opp2 = MagicMock(spec=Opportunity)
        opp2.opportunity_type = "slot_contention"
        opp2.affected_table = "table2"
        opp2.status = "active"
        opp2.last_detected_at = datetime.now(timezone.utc) - timedelta(days=15)
        opp2.consecutive_clean_days = 0

        with patch.object(db_session, "execute") as mock_execute:
            mock_execute.return_value.scalars.return_value.all.return_value = [
                opp1,
                opp2,
            ]

            service = OpportunityService(db_session)
            count = service.evaluate_resolution(
                config_id="manifest-A",
                detected_keys=set(),
                resolution_period_days=10,
            )

            assert count == 2
            assert opp1.status == "resolved"
            assert opp2.status == "resolved"


class TestOpportunityLifecycle:
    """Tests for opportunity lifecycle management."""

    def test_evaluate_resolution_threshold(self, db_session):
        """Test evaluating opportunities for resolution using threshold-based logic."""
        opp1 = MagicMock(spec=Opportunity)
        opp1.opportunity_type = "shuffle_spill"
        opp1.affected_table = "table1"
        opp1.status = "active"
        opp1.last_detected_at = datetime.now(timezone.utc) - timedelta(days=15)
        opp1.consecutive_clean_days = 0

        opp2 = MagicMock(spec=Opportunity)
        opp2.opportunity_type = "slot_contention"
        opp2.affected_table = "table2"
        opp2.status = "active"
        opp2.last_detected_at = datetime.now(timezone.utc) - timedelta(days=15)
        opp2.consecutive_clean_days = 0

        with patch.object(db_session, "execute") as mock_execute:
            mock_execute.return_value.scalars.return_value.all.return_value = [
                opp1,
                opp2,
            ]

            service = OpportunityService(db_session)
            detected_keys = {("shuffle_spill", "table1")}
            count = service.evaluate_resolution(
                config_id="manifest-loc-123",
                detected_keys=detected_keys,
                resolution_period_days=10,
            )

            assert count == 1
            assert opp2.status == "resolved"
            assert opp2.resolved_at is not None

    def test_purge_resolved(self, db_session):
        """Test purging old resolved opportunities."""
        old_opp = MagicMock(spec=Opportunity)
        old_opp.id = "opp-old"
        old_opp.status = "resolved"
        old_opp.resolved_at = datetime.now(timezone.utc) - timedelta(days=100)

        with patch.object(db_session, "execute") as mock_execute:
            mock_execute.return_value.scalars.return_value.all.return_value = [old_opp]

            service = OpportunityService(db_session)
            count = service.purge_resolved(retention_days=90)

            assert count == 1
            db_session.delete.assert_called_once_with(old_opp)


class TestPerConfigQueries:
    """Tests for per-config opportunity queries (US2)."""

    def test_get_opportunities_for_config(self, db_session):
        """get_opportunities_for_config returns only that config's opportunities."""
        opp = MagicMock(spec=Opportunity)
        opp.config_id = "config-A"

        with patch.object(db_session, "execute") as mock_execute:
            mock_execute.return_value.scalars.return_value.all.return_value = [opp]

            service = OpportunityService(db_session)
            result = service.get_opportunities_for_config(
                config_id="config-A",
            )

            assert len(result) == 1
            assert result[0].config_id == "config-A"

    def test_get_opportunities_for_config_with_status_filter(self, db_session):
        """get_opportunities_for_config with status filter."""
        opp = MagicMock(spec=Opportunity)
        opp.status = "active"

        with patch.object(db_session, "execute") as mock_execute:
            mock_execute.return_value.scalars.return_value.all.return_value = [opp]

            service = OpportunityService(db_session)
            result = service.get_opportunities_for_config(
                config_id="config-A",
                status="active",
            )

            assert len(result) == 1

    def test_get_opportunities_for_config_empty(self, db_session):
        """get_opportunities_for_config returns empty list for config with no opps."""
        with patch.object(db_session, "execute") as mock_execute:
            mock_execute.return_value.scalars.return_value.all.return_value = []

            service = OpportunityService(db_session)
            result = service.get_opportunities_for_config(
                config_id="config-empty",
            )

            assert result == []

    def test_get_opportunities_count_for_config(self, db_session):
        """get_opportunities_count_for_config returns correct count."""
        with patch.object(db_session, "execute") as mock_execute:
            mock_execute.return_value.scalar_one.return_value = 3

            service = OpportunityService(db_session)
            count = service.get_opportunities_count_for_config(
                config_id="config-A",
            )

            assert count == 3


class TestDetectionHistoryModel:
    """Tests for OpportunityDetectionHistory model (US5 - T005)."""

    def test_create_detection_history_entry(self, db_session):
        """Creating a detection history entry links opportunity and detection job."""
        entry = OpportunityDetectionHistory(
            opportunity_id="opp-123",
            detection_job_id="job-456",
            detected_at=datetime.now(timezone.utc),
        )

        assert entry.opportunity_id == "opp-123"
        assert entry.detection_job_id == "job-456"
        assert entry.detected_at is not None

    def test_history_entries_scoped_to_opportunity(self, db_session):
        """Querying history for an opportunity returns only that opportunity's entries."""
        entry1 = OpportunityDetectionHistory(
            opportunity_id="opp-A",
            detection_job_id="job-1",
            detected_at=datetime.now(timezone.utc),
        )
        entry2 = OpportunityDetectionHistory(
            opportunity_id="opp-B",
            detection_job_id="job-1",
            detected_at=datetime.now(timezone.utc),
        )

        assert entry1.opportunity_id == "opp-A"
        assert entry2.opportunity_id == "opp-B"
        assert entry1.opportunity_id != entry2.opportunity_id

    def test_multiple_history_entries_per_opportunity(self, db_session):
        """Multiple history entries can exist for the same opportunity."""
        now = datetime.now(timezone.utc)
        entries = [
            OpportunityDetectionHistory(
                opportunity_id="opp-A",
                detection_job_id=f"job-{i}",
                detected_at=now + timedelta(days=i),
            )
            for i in range(3)
        ]

        assert len(entries) == 3
        assert all(e.opportunity_id == "opp-A" for e in entries)

    def test_multiple_entries_same_calendar_day(self, db_session):
        """Multiple entries on the same calendar day are stored without deduplication."""
        noon_utc = datetime(2026, 6, 15, 12, 0, 0, tzinfo=timezone.utc)
        entry1 = OpportunityDetectionHistory(
            opportunity_id="opp-A",
            detection_job_id="job-1",
            detected_at=noon_utc,
        )
        entry2 = OpportunityDetectionHistory(
            opportunity_id="opp-A",
            detection_job_id="job-2",
            detected_at=noon_utc + timedelta(hours=2),
        )

        assert entry1.detected_at.date() == entry2.detected_at.date()
        assert entry1.detection_job_id != entry2.detection_job_id


class TestPurgeDetectionHistory:
    """Tests for purge_detection_history() (US5 - T008)."""

    def test_entries_older_than_90_days_deleted(self, db_session):
        """Entries older than 90 days are deleted."""
        old_entry = MagicMock(spec=OpportunityDetectionHistory)
        old_entry.detected_at = datetime.now(timezone.utc) - timedelta(days=100)

        with patch.object(db_session, "execute") as mock_execute:
            mock_execute.return_value.scalars.return_value.all.return_value = [
                old_entry
            ]

            service = OpportunityService(db_session)
            count = service.purge_detection_history(retention_days=90)

            assert count == 1
            db_session.delete.assert_called_once_with(old_entry)

    def test_entries_within_90_days_retained(self, db_session):
        """Entries within 90 days are retained."""
        with patch.object(db_session, "execute") as mock_execute:
            mock_execute.return_value.scalars.return_value.all.return_value = []

            service = OpportunityService(db_session)
            count = service.purge_detection_history(retention_days=90)

            assert count == 0
            db_session.delete.assert_not_called()

    def test_custom_retention_days(self, db_session):
        """Custom retention_days parameter works."""
        old_entry = MagicMock(spec=OpportunityDetectionHistory)
        old_entry.detected_at = datetime.now(timezone.utc) - timedelta(days=40)

        with patch.object(db_session, "execute") as mock_execute:
            mock_execute.return_value.scalars.return_value.all.return_value = [
                old_entry
            ]

            service = OpportunityService(db_session)
            count = service.purge_detection_history(retention_days=30)

            assert count == 1

    def test_returns_count_of_purged_entries(self, db_session):
        """Returns count of purged entries."""
        entries = [MagicMock(spec=OpportunityDetectionHistory) for _ in range(5)]

        with patch.object(db_session, "execute") as mock_execute:
            mock_execute.return_value.scalars.return_value.all.return_value = entries

            service = OpportunityService(db_session)
            count = service.purge_detection_history(retention_days=90)

            assert count == 5


class TestEvaluateResolution:
    """Tests for evaluate_resolution() (US1 - T009)."""

    def test_opportunity_5_days_old_moves_to_clearing(self, db_session):
        """Opportunity with last_detected_at 5 days ago transitions active → clearing."""
        opp = MagicMock(spec=Opportunity)
        opp.opportunity_type = "shuffle_spill"
        opp.affected_table = "table1"
        opp.status = "active"
        opp.last_detected_at = datetime.now(timezone.utc) - timedelta(days=5)
        opp.consecutive_clean_days = 0

        with patch.object(db_session, "execute") as mock_execute:
            mock_execute.return_value.scalars.return_value.all.return_value = [opp]

            service = OpportunityService(db_session)
            count = service.evaluate_resolution(
                config_id="config-A",
                detected_keys=set(),
                resolution_period_days=10,
            )

            assert count == 0
            assert opp.status == "clearing"
            assert opp.consecutive_clean_days == 5

    def test_opportunity_10_days_old_resolved(self, db_session):
        """Opportunity with last_detected_at 10 days ago and resolution_period_days=10 is resolved."""
        opp = MagicMock(spec=Opportunity)
        opp.opportunity_type = "shuffle_spill"
        opp.affected_table = "table1"
        opp.status = "active"
        opp.last_detected_at = datetime.now(timezone.utc) - timedelta(days=10)
        opp.consecutive_clean_days = 0

        with patch.object(db_session, "execute") as mock_execute:
            mock_execute.return_value.scalars.return_value.all.return_value = [opp]

            service = OpportunityService(db_session)
            count = service.evaluate_resolution(
                config_id="config-A",
                detected_keys=set(),
                resolution_period_days=10,
            )

            assert count == 1
            assert opp.status == "resolved"
            assert opp.resolved_at is not None

    def test_opportunity_10_days_old_with_15_day_period_moves_to_clearing(
        self, db_session
    ):
        """Opportunity with last_detected_at 10 days ago and resolution_period_days=15 moves to clearing."""
        opp = MagicMock(spec=Opportunity)
        opp.opportunity_type = "shuffle_spill"
        opp.affected_table = "table1"
        opp.status = "active"
        opp.last_detected_at = datetime.now(timezone.utc) - timedelta(days=10)
        opp.consecutive_clean_days = 0

        with patch.object(db_session, "execute") as mock_execute:
            mock_execute.return_value.scalars.return_value.all.return_value = [opp]

            service = OpportunityService(db_session)
            count = service.evaluate_resolution(
                config_id="config-A",
                detected_keys=set(),
                resolution_period_days=15,
            )

            assert count == 0
            assert opp.status == "clearing"
            assert opp.consecutive_clean_days == 10

    def test_clearing_opportunity_reactivated_when_re_detected(self, db_session):
        """Detection-based clearing opportunity moves back to active when re-detected."""
        opp = MagicMock(spec=Opportunity)
        opp.opportunity_type = "shuffle_spill"
        opp.affected_table = "table1"
        opp.status = "clearing"
        opp.clearing_until = None  # detection-based clearing, no PR window
        opp.last_detected_at = datetime.now(timezone.utc) - timedelta(days=5)
        opp.consecutive_clean_days = 5

        with patch.object(db_session, "execute") as mock_execute:
            mock_execute.return_value.scalars.return_value.all.return_value = [opp]

            service = OpportunityService(db_session)
            count = service.evaluate_resolution(
                config_id="config-A",
                detected_keys={("shuffle_spill", "table1")},
                resolution_period_days=15,
            )

            assert count == 0
            assert opp.status == "active"
            assert opp.consecutive_clean_days == 0

    def test_pr_clearing_opportunity_not_reactivated_when_re_detected(self, db_session):
        """PR-based clearing (clearing_until set) must NOT be reactivated by re-detection."""
        opp = MagicMock(spec=Opportunity)
        opp.opportunity_type = "shuffle_spill"
        opp.affected_table = "table1"
        opp.status = "clearing"
        opp.clearing_until = datetime.now(timezone.utc) + timedelta(days=10)
        opp.last_detected_at = datetime.now(timezone.utc) - timedelta(days=2)
        opp.consecutive_clean_days = 2

        with patch.object(db_session, "execute") as mock_execute:
            mock_execute.return_value.scalars.return_value.all.return_value = [opp]

            service = OpportunityService(db_session)
            count = service.evaluate_resolution(
                config_id="config-A",
                detected_keys={("shuffle_spill", "table1")},
                resolution_period_days=15,
            )

            assert count == 0
            assert opp.status == "clearing"  # stays clearing

    def test_clearing_opportunity_resolved_after_period(self, db_session):
        """Clearing opportunity resolves after resolution_period_days."""
        opp = MagicMock(spec=Opportunity)
        opp.opportunity_type = "shuffle_spill"
        opp.affected_table = "table1"
        opp.status = "clearing"
        opp.last_detected_at = datetime.now(timezone.utc) - timedelta(days=15)
        opp.consecutive_clean_days = 10

        with patch.object(db_session, "execute") as mock_execute:
            mock_execute.return_value.scalars.return_value.all.return_value = [opp]

            service = OpportunityService(db_session)
            count = service.evaluate_resolution(
                config_id="config-A",
                detected_keys=set(),
                resolution_period_days=15,
            )

            assert count == 1
            assert opp.status == "resolved"
            assert opp.resolved_at is not None

    def test_detected_opportunity_skipped(self, db_session):
        """Opportunity in detected_keys is skipped (not evaluated for resolution)."""
        opp = MagicMock(spec=Opportunity)
        opp.opportunity_type = "shuffle_spill"
        opp.affected_table = "table1"
        opp.status = "active"
        opp.last_detected_at = datetime.now(timezone.utc) - timedelta(days=20)
        opp.consecutive_clean_days = 0

        with patch.object(db_session, "execute") as mock_execute:
            mock_execute.return_value.scalars.return_value.all.return_value = [opp]

            service = OpportunityService(db_session)
            count = service.evaluate_resolution(
                config_id="config-A",
                detected_keys={("shuffle_spill", "table1")},
                resolution_period_days=10,
            )

            assert count == 0
            assert opp.status == "active"

    def test_null_last_detected_at_not_resolved(self, db_session):
        """Opportunity with NULL last_detected_at is not resolved (safety)."""
        opp = MagicMock(spec=Opportunity)
        opp.opportunity_type = "shuffle_spill"
        opp.affected_table = "table1"
        opp.status = "active"
        opp.last_detected_at = None
        opp.consecutive_clean_days = 0

        with patch.object(db_session, "execute") as mock_execute:
            mock_execute.return_value.scalars.return_value.all.return_value = [opp]

            service = OpportunityService(db_session)
            count = service.evaluate_resolution(
                config_id="config-A",
                detected_keys=set(),
                resolution_period_days=10,
            )

            assert count == 0
            assert opp.status == "active"

    def test_returns_count_of_resolved(self, db_session):
        """Returns count of resolved opportunities."""
        opps = []
        for i in range(3):
            opp = MagicMock(spec=Opportunity)
            opp.opportunity_type = f"type_{i}"
            opp.affected_table = f"table_{i}"
            opp.status = "active"
            opp.last_detected_at = datetime.now(timezone.utc) - timedelta(days=15)
            opp.consecutive_clean_days = 0
            opps.append(opp)

        with patch.object(db_session, "execute") as mock_execute:
            mock_execute.return_value.scalars.return_value.all.return_value = opps

            service = OpportunityService(db_session)
            count = service.evaluate_resolution(
                config_id="config-A",
                detected_keys=set(),
                resolution_period_days=10,
            )

            assert count == 3


class TestClearingSolutionCleanup:
    """Tests for solution cleanup when opportunities enter clearing status."""

    def test_clearing_deletes_solutions_and_cancels_jobs(self, db_session):
        """When opportunity transitions to clearing, solutions are deleted and jobs cancelled."""
        opp = MagicMock(spec=Opportunity)
        opp.id = "opp-clearing-1"
        opp.opportunity_type = "shuffle_spill"
        opp.affected_table = "table1"
        opp.status = "active"
        opp.last_detected_at = datetime.now(timezone.utc) - timedelta(days=5)
        opp.consecutive_clean_days = 0

        with patch.object(db_session, "execute") as mock_execute:
            mock_execute.return_value.scalars.return_value.all.return_value = [opp]

            service = OpportunityService(db_session)
            with patch.object(
                service, "_clear_solutions_for_opportunity"
            ) as mock_clear:
                count = service.evaluate_resolution(
                    config_id="config-A",
                    detected_keys=set(),
                    resolution_period_days=15,
                )

                assert count == 0
                assert opp.status == "clearing"
                mock_clear.assert_called_once_with("opp-clearing-1")
                assert opp.latest_solution_dry_run_original_cost is None
                assert opp.latest_solution_dry_run_modified_cost is None

    def test_clearing_does_not_clear_solutions_on_reactivation(self, db_session):
        """When a clearing opportunity is re-detected, solutions are NOT cleared."""
        opp = MagicMock(spec=Opportunity)
        opp.id = "opp-reactivate-1"
        opp.opportunity_type = "shuffle_spill"
        opp.affected_table = "table1"
        opp.status = "clearing"
        opp.clearing_until = None  # detection-based clearing
        opp.last_detected_at = datetime.now(timezone.utc) - timedelta(days=5)
        opp.consecutive_clean_days = 5

        with patch.object(db_session, "execute") as mock_execute:
            mock_execute.return_value.scalars.return_value.all.return_value = [opp]

            service = OpportunityService(db_session)
            with patch.object(
                service, "_clear_solutions_for_opportunity"
            ) as mock_clear:
                service.evaluate_resolution(
                    config_id="config-A",
                    detected_keys={("shuffle_spill", "table1")},
                    resolution_period_days=15,
                )

                assert opp.status == "active"
                mock_clear.assert_not_called()


class TestConsecutiveDayCounterReset:
    """Tests for consecutive-day counter reset (US2 - T010)."""

    def test_redetected_after_7_clean_days_resets_counter(self, db_session):
        """Opportunity re-detected after 7 consecutive clean days resets counter."""
        existing = Opportunity(
            id="opp-123",
            config_id="config-A",
            opportunity_type="shuffle_spill",
            affected_table="table1",
            status="active",
            severity_score=50,
            evidence_snapshot={},
            current_cost_estimate=Decimal("10.00"),
            expected_savings=Decimal("2.00"),
            explanation="Test",
            related_job_ids=["job-1"],
            first_detection_job_id="det-old",
            last_detected_at=datetime.now(timezone.utc) - timedelta(days=7),
            consecutive_clean_days=7,
        )

        candidate = OpportunityCandidate(
            opportunity_type="shuffle_spill",
            affected_table="table1",
            severity_score=50,
            evidence_snapshot={},
            current_cost_estimate=Decimal("10.00"),
            expected_savings=Decimal("2.00"),
            explanation="Test",
            related_job_ids=["job-1"],
        )

        with patch.object(db_session, "execute") as mock_execute:
            mock_execute.return_value.scalar_one_or_none.return_value = existing

            with patch.object(
                OpportunityService, "recalculate_occurrence_count", return_value=1
            ):
                service = OpportunityService(db_session)
                opp, action = service.persist_opportunity(
                    config_id="config-A",
                    manifest_version_id="ver-1",
                    detection_job_id="det-new",
                    candidate=candidate,
                )

                assert opp.consecutive_clean_days == 0
                assert opp.last_detected_at is not None

    def test_not_detected_day_9_of_10_moves_to_clearing(self, db_session):
        """Active opportunity not detected for 9 days transitions to clearing (not yet resolved)."""
        opp = MagicMock(spec=Opportunity)
        opp.opportunity_type = "shuffle_spill"
        opp.affected_table = "table1"
        opp.status = "active"
        opp.last_detected_at = datetime.now(timezone.utc) - timedelta(days=9)
        opp.consecutive_clean_days = 9

        with patch.object(db_session, "execute") as mock_execute:
            mock_execute.return_value.scalars.return_value.all.return_value = [opp]

            service = OpportunityService(db_session)
            count = service.evaluate_resolution(
                config_id="config-A",
                detected_keys=set(),
                resolution_period_days=10,
            )

            assert count == 0
            assert opp.status == "clearing"
            assert opp.consecutive_clean_days == 9

    def test_resolution_period_1_day(self, db_session):
        """With resolution_period_days=1, an opportunity not detected for 1 day is resolved."""
        opp = MagicMock(spec=Opportunity)
        opp.opportunity_type = "shuffle_spill"
        opp.affected_table = "table1"
        opp.status = "active"
        opp.last_detected_at = datetime.now(timezone.utc) - timedelta(days=1)
        opp.consecutive_clean_days = 0

        with patch.object(db_session, "execute") as mock_execute:
            mock_execute.return_value.scalars.return_value.all.return_value = [opp]

            service = OpportunityService(db_session)
            count = service.evaluate_resolution(
                config_id="config-A",
                detected_keys=set(),
                resolution_period_days=1,
            )

            assert count == 1
            assert opp.status == "resolved"

    def test_15_day_gap_counts_as_15_clean_days(self, db_session):
        """Calendar-day semantics: 15-day gap counts as 15 consecutive clean days."""
        opp = MagicMock(spec=Opportunity)
        opp.opportunity_type = "shuffle_spill"
        opp.affected_table = "table1"
        opp.status = "active"
        opp.last_detected_at = datetime.now(timezone.utc) - timedelta(days=15)
        opp.consecutive_clean_days = 0

        with patch.object(db_session, "execute") as mock_execute:
            mock_execute.return_value.scalars.return_value.all.return_value = [opp]

            service = OpportunityService(db_session)
            count = service.evaluate_resolution(
                config_id="config-A",
                detected_keys=set(),
                resolution_period_days=10,
            )

            assert count == 1
            assert opp.consecutive_clean_days == 15


class TestOccurrenceFrequency:
    """Tests for recalculate_occurrence_count() (US3 - T019)."""

    def test_five_entries_five_days_returns_five(self, db_session):
        """recalculate_occurrence_count with 5 history entries across 5 different days returns 5."""
        opp = MagicMock(spec=Opportunity)
        opp.occurrence_count = 0

        with patch.object(db_session, "execute") as mock_execute:
            mock_execute.return_value.scalar_one.return_value = 5

            with patch.object(db_session, "get", return_value=opp):
                service = OpportunityService(db_session)
                count = service.recalculate_occurrence_count("opp-123", 30)

                assert count == 5
                assert opp.occurrence_count == 5

    def test_same_day_entries_count_as_one(self, db_session):
        """Multiple entries on same calendar day count as 1 day."""
        opp = MagicMock(spec=Opportunity)
        opp.occurrence_count = 0

        with patch.object(db_session, "execute") as mock_execute:
            mock_execute.return_value.scalar_one.return_value = 1

            with patch.object(db_session, "get", return_value=opp):
                service = OpportunityService(db_session)
                count = service.recalculate_occurrence_count("opp-123", 30)

                assert count == 1

    def test_entries_outside_window_excluded(self, db_session):
        """Entries outside the lookback window are excluded."""
        opp = MagicMock(spec=Opportunity)
        opp.occurrence_count = 0

        with patch.object(db_session, "execute") as mock_execute:
            mock_execute.return_value.scalar_one.return_value = 3

            with patch.object(db_session, "get", return_value=opp):
                service = OpportunityService(db_session)
                count = service.recalculate_occurrence_count("opp-123", 14)

                assert count == 3

    def test_empty_history_returns_zero(self, db_session):
        """Empty history returns 0."""
        opp = MagicMock(spec=Opportunity)
        opp.occurrence_count = 0

        with patch.object(db_session, "execute") as mock_execute:
            mock_execute.return_value.scalar_one.return_value = 0

            with patch.object(db_session, "get", return_value=opp):
                service = OpportunityService(db_session)
                count = service.recalculate_occurrence_count("opp-123", 30)

                assert count == 0
                assert opp.occurrence_count == 0

    def test_changing_window_recalculates(self, db_session):
        """Changing lookback window from 30 to 14 days recalculates correctly."""
        opp = MagicMock(spec=Opportunity)
        opp.occurrence_count = 0

        with patch.object(db_session, "execute") as mock_execute:
            # First call with 30 days returns 10
            mock_execute.return_value.scalar_one.return_value = 10

            with patch.object(db_session, "get", return_value=opp):
                service = OpportunityService(db_session)
                count_30 = service.recalculate_occurrence_count("opp-123", 30)
                assert count_30 == 10

        with patch.object(db_session, "execute") as mock_execute:
            # Second call with 14 days returns 5
            mock_execute.return_value.scalar_one.return_value = 5

            with patch.object(db_session, "get", return_value=opp):
                service = OpportunityService(db_session)
                count_14 = service.recalculate_occurrence_count("opp-123", 14)
                assert count_14 == 5


class TestWatchedRuleReconciliation:
    """Tests for watched-rule reconciliation helpers."""

    def test_resolve_opportunities_for_rule_types_resolves_matching_active(
        self, db_session
    ):
        opportunity = MagicMock(spec=Opportunity)
        opportunity.status = "active"
        opportunity.opportunity_type = "shuffle_spill"
        opportunity.affected_table = "project.dataset.table1"
        opportunity.resolved_at = None

        with patch.object(db_session, "execute") as mock_execute:
            mock_execute.return_value.scalars.return_value.all.return_value = [
                opportunity
            ]

            service = OpportunityService(db_session)
            count = service.resolve_opportunities_for_rule_types(
                "config-123", {"shuffle_spill"}
            )

            assert count == 1
            assert opportunity.status == "resolved"
            assert opportunity.resolved_at is not None

    def test_backfill_detection_history_uses_selected_rules(self, db_session):
        historical_job = MagicMock()
        historical_job.creation_time = datetime.now(timezone.utc) - timedelta(days=1)
        historical_job.destination_table = "project.dataset.table1"

        config = MagicMock()
        config.manifest_versions = []
        config.watched_rule_types = ["dead_column"]

        selected_rule = MagicMock()
        selected_rule.rule_type = "dead_column"
        selected_rule.get_thresholds.return_value = {}
        selected_rule.detect.return_value = []

        skipped_rule = MagicMock()
        skipped_rule.rule_type = "shuffle_spill"
        skipped_rule.detect.return_value = []

        jobs_result = MagicMock()
        jobs_result.scalars.return_value.all.return_value = [historical_job]

        selected_rules = MagicMock(
            mode="custom",
            configured_rule_types=["dead_column"],
            unknown_rule_types=[],
            unavailable_rule_types=[],
            effective_rule_types=["dead_column"],
            effective_rules=[selected_rule],
        )

        with (
            patch.object(db_session, "execute", return_value=jobs_result),
            patch.object(db_session, "get", return_value=config),
            patch(
                "governor_core.opportunities.detector.DetectionEngine"
            ) as mock_detection_engine,
            patch(
                "governor_core.opportunities.detector.select_rules_for_config",
                return_value=selected_rules,
            ),
        ):
            mock_detection_engine.return_value.get_enabled_rules.return_value = [
                skipped_rule,
                selected_rule,
            ]

            service = OpportunityService(db_session)
            count = service.backfill_detection_history("config-123", "det-123")

            assert count == 0
            selected_rule.detect.assert_called_once()
            skipped_rule.detect.assert_not_called()


class TestFormatOccurrenceFrequency:
    """Tests for format_occurrence_frequency() (US3 - T021)."""

    def test_normal_case(self):
        """Normal case: 'detected in 3 of the last 30 days'."""
        from governor_core.opportunities.schemas import format_occurrence_frequency

        result = format_occurrence_frequency(3, 30)
        assert result == "detected in 3 of the last 30 days"

    def test_count_zero(self):
        """Count=0: 'not detected in the last 30 days'."""
        from governor_core.opportunities.schemas import format_occurrence_frequency

        result = format_occurrence_frequency(0, 30)
        assert result == "not detected in the last 30 days"

    def test_count_one_custom_window(self):
        """Count=1 with custom window: 'detected in 1 of the last 14 days'."""
        from governor_core.opportunities.schemas import format_occurrence_frequency

        result = format_occurrence_frequency(1, 14)
        assert result == "detected in 1 of the last 14 days"

    def test_count_equals_window(self):
        """Count equals window: 'detected in 30 of the last 30 days'."""
        from governor_core.opportunities.schemas import format_occurrence_frequency

        result = format_occurrence_frequency(30, 30)
        assert result == "detected in 30 of the last 30 days"


@pytest.fixture
def db_session():
    """Create a mock database session."""
    session = MagicMock()
    session.add = MagicMock()
    session.flush = MagicMock()
    session.delete = MagicMock()
    return session
