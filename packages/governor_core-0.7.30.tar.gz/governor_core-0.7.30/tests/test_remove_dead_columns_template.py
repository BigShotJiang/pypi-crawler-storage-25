"""Unit tests for app/solutions/templates/remove_dead_columns.py."""

from types import SimpleNamespace

from governor_core.solutions.templates.remove_dead_columns import (
    RemoveDeadColumnsTemplate,
    _find_cte_boundaries,
    _rebuild_cte_in_sql,
    _remove_dead_col_line,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_opportunity(evidence: dict | None = None):
    return SimpleNamespace(
        id="opp-1",
        opportunity_type="dead_column",
        evidence_snapshot=evidence or {},
        dbt_model_name="my_model",
        affected_table="project.dataset.my_model",
    )


# ---------------------------------------------------------------------------
# _find_cte_boundaries
# ---------------------------------------------------------------------------


class TestFindCteBoundaries:
    def test_simple_cte(self):
        sql = "WITH base AS (\n  SELECT a, b FROM t\n)\nSELECT a FROM base"
        result = _find_cte_boundaries(sql, "base")
        assert result is not None
        body_start, body_end = result
        body = sql[body_start:body_end]
        assert "SELECT a, b FROM t" in body
        assert "(" not in body[0]  # excludes the opening paren
        assert ")" not in body[-1]  # excludes the closing paren

    def test_case_insensitive_cte_name(self):
        sql = "WITH Base AS (\n  SELECT a FROM t\n)\nSELECT a FROM Base"
        assert _find_cte_boundaries(sql, "base") is not None
        assert _find_cte_boundaries(sql, "BASE") is not None

    def test_cte_not_found_returns_none(self):
        sql = "WITH foo AS (SELECT a FROM t)\nSELECT a FROM foo"
        assert _find_cte_boundaries(sql, "bar") is None

    def test_nested_parens_handled(self):
        """CTE body containing nested function calls with parens."""
        sql = (
            "WITH agg AS (\n"
            "  SELECT COALESCE(SUM(amount), 0) AS total\n"
            "  FROM t\n"
            ")\n"
            "SELECT total FROM agg"
        )
        result = _find_cte_boundaries(sql, "agg")
        assert result is not None
        body = sql[result[0] : result[1]]
        assert "COALESCE(SUM(amount), 0)" in body

    def test_multiple_ctes_finds_correct_one(self):
        sql = (
            "WITH\n"
            "  first AS (SELECT a, b FROM t),\n"
            "  second AS (SELECT b, c FROM first)\n"
            "SELECT b, c FROM second"
        )
        result_first = _find_cte_boundaries(sql, "first")
        result_second = _find_cte_boundaries(sql, "second")
        assert result_first is not None
        assert result_second is not None
        body_first = sql[result_first[0] : result_first[1]]
        body_second = sql[result_second[0] : result_second[1]]
        assert "SELECT a, b FROM t" in body_first
        assert "SELECT b, c FROM first" in body_second
        # The bodies should not overlap
        assert result_first[1] < result_second[0]


# ---------------------------------------------------------------------------
# _remove_dead_col_line
# ---------------------------------------------------------------------------


class TestRemoveDeadColLine:
    def test_removes_alias_column(self):
        body = "\n  SELECT\n    id,\n    name,\n    expr AS dead_col\n  FROM t\n"
        result = _remove_dead_col_line(body, "dead_col")
        assert result is not None
        assert "dead_col" not in result
        # Trailing comma on 'name' should be removed since dead_col was last
        assert "name\n" in result or "name,\n" not in result

    def test_removes_bare_column_with_trailing_comma(self):
        body = "\n  SELECT\n    id,\n    dead_col,\n    name\n  FROM t\n"
        result = _remove_dead_col_line(body, "dead_col")
        assert result is not None
        assert "dead_col" not in result
        # Comma on dead_col removed; preceding line (id,) unchanged
        assert "id," in result

    def test_removes_last_column_strips_prev_comma(self):
        """When the last column is removed, the preceding line's comma is stripped."""
        body = "\n  SELECT\n    id,\n    name,\n    dead_col\n  FROM t\n"
        result = _remove_dead_col_line(body, "dead_col")
        assert result is not None
        assert "dead_col" not in result
        # 'name' should no longer have a trailing comma
        assert "name,\n" not in result
        assert "name\n" in result

    def test_removes_table_qualified_column(self):
        body = "\n  SELECT\n    t.id,\n    t.dead_col,\n    t.name\n  FROM t\n"
        result = _remove_dead_col_line(body, "dead_col")
        assert result is not None
        assert "dead_col" not in result

    def test_column_not_found_returns_none(self):
        body = "\n  SELECT\n    id,\n    name\n  FROM t\n"
        result = _remove_dead_col_line(body, "nonexistent")
        assert result is None

    def test_multiline_expression_skipped(self):
        """Multi-line CASE expression should NOT be partially removed."""
        body_unbalanced = (
            "\n  SELECT\n"
            "    id,\n"
            "    CASE WHEN (x >\n"
            "      0) THEN 'yes' ELSE 'no'\n"
            "    END AS dead_col,\n"
            "    name\n"
            "  FROM t\n"
        )
        # The line "    END AS dead_col," has prefix "    END " which has balanced parens,
        # so it should be removed. But the line "      0) THEN..." starts with unbalanced `)`.
        # The alias_re only matches on the END AS line which has balanced parens.
        result = _remove_dead_col_line(body_unbalanced, "dead_col")
        # The alias line "    END AS dead_col," - prefix is "    END " which has 0 open, 0 close
        # so it IS matched and removed (this is intended behaviour for single-line END AS aliases)
        assert result is not None

    def test_case_insensitive_alias(self):
        body = "\n  SELECT\n    id,\n    expr AS DEAD_COL\n  FROM t\n"
        result = _remove_dead_col_line(body, "dead_col")
        assert result is not None
        assert "DEAD_COL" not in result

    def test_preserves_other_lines_exactly(self):
        """All non-removed lines must be byte-for-byte identical."""
        body = "\n  SELECT\n    id,\n    name,\n    dead_col\n  FROM t\n"
        result = _remove_dead_col_line(body, "dead_col")
        assert result is not None
        # After stripping trailing comma from 'name', filter to non-comma-adjusted lines
        assert "  FROM t\n" in result
        assert "    id,\n" in result


# ---------------------------------------------------------------------------
# _rebuild_cte_in_sql
# ---------------------------------------------------------------------------


class TestRebuildCteInSql:
    _SQL = (
        "WITH\n"
        "  base AS (\n"
        "    SELECT\n"
        "      station_id,\n"
        "      name,\n"
        "      elevation,\n"
        "      country_code\n"
        "    FROM raw_stations\n"
        "  ),\n"
        "  final AS (\n"
        "    SELECT station_id, name FROM base\n"
        "  )\n"
        "SELECT station_id, name FROM final\n"
    )

    def test_removes_single_dead_column(self):
        result = _rebuild_cte_in_sql(self._SQL, "base", {"elevation"})
        assert result is not None
        assert "elevation" not in result
        # Other columns still present
        assert "station_id" in result
        assert "country_code" in result

    def test_removes_multiple_dead_columns(self):
        result = _rebuild_cte_in_sql(self._SQL, "base", {"elevation", "country_code"})
        assert result is not None
        assert "elevation" not in result
        assert "country_code" not in result
        assert "station_id" in result

    def test_unknown_cte_returns_none(self):
        result = _rebuild_cte_in_sql(self._SQL, "nonexistent", {"elevation"})
        assert result is None

    def test_all_cols_unknown_returns_none(self):
        result = _rebuild_cte_in_sql(self._SQL, "base", {"totally_fake_column"})
        assert result is None

    def test_surrounding_sql_untouched(self):
        result = _rebuild_cte_in_sql(self._SQL, "base", {"elevation"})
        assert result is not None
        # The final CTE and outer SELECT must be identical
        assert "  final AS (\n    SELECT station_id, name FROM base\n  )" in result
        assert "SELECT station_id, name FROM final\n" in result

    def test_jinja_preserved(self):
        sql = (
            "WITH base AS (\n"
            "  SELECT\n"
            "    id,\n"
            "    dead_col,\n"
            "    name\n"
            "  FROM {{ ref('raw') }}\n"
            ")\n"
            "SELECT id, name FROM base\n"
        )
        result = _rebuild_cte_in_sql(sql, "base", {"dead_col"})
        assert result is not None
        assert "{{ ref('raw') }}" in result
        assert "dead_col" not in result


# ---------------------------------------------------------------------------
# RemoveDeadColumnsTemplate.matches()
# ---------------------------------------------------------------------------


class TestRemoveDeadColumnsTemplateMatches:
    _FILE = "models/stg_stations.sql"
    _SQL = "WITH base AS (\n  SELECT a, b FROM t\n)\nSELECT a FROM base\n"

    def _opp(self, evidence=None):
        return _make_opportunity(
            evidence
            or {
                "cte_dead_columns": [
                    {
                        "cte_name": "base",
                        "dead_columns": ["b"],
                        "all_columns": ["a", "b"],
                    }
                ],
                "dead_columns": ["b"],
                "dead_count": 1,
            }
        )

    def _meta(self, path=None):
        return {"original_file_path": path or self._FILE, "name": "stg_stations"}

    def test_matches_valid_opportunity(self):
        tmpl = RemoveDeadColumnsTemplate()
        assert tmpl.matches(self._opp(), {self._FILE: self._SQL}, self._meta())

    def test_no_cte_dead_columns_key_returns_false(self):
        tmpl = RemoveDeadColumnsTemplate()
        opp = _make_opportunity({"dead_columns": ["b"]})  # missing cte_dead_columns
        assert not tmpl.matches(opp, {self._FILE: self._SQL}, self._meta())

    def test_empty_cte_dead_columns_returns_false(self):
        tmpl = RemoveDeadColumnsTemplate()
        opp = _make_opportunity({"cte_dead_columns": []})
        assert not tmpl.matches(opp, {self._FILE: self._SQL}, self._meta())

    def test_missing_file_path_returns_false(self):
        tmpl = RemoveDeadColumnsTemplate()
        assert not tmpl.matches(
            self._opp(), {self._FILE: self._SQL}, {"name": "stg_stations"}
        )

    def test_missing_source_file_returns_false(self):
        tmpl = RemoveDeadColumnsTemplate()
        assert not tmpl.matches(self._opp(), {}, self._meta())

    def test_matches_dead_window_expression_type(self):
        tmpl = RemoveDeadColumnsTemplate()
        opp = SimpleNamespace(
            id="opp-1",
            opportunity_type="dead_window_expression",
            evidence_snapshot={
                "cte_dead_columns": [
                    {
                        "cte_name": "base",
                        "dead_columns": ["rn"],
                        "all_columns": ["id", "rn"],
                    }
                ],
                "dead_columns": ["rn"],
            },
            dbt_model_name="my_model",
            affected_table="project.dataset.my_model",
        )
        assert tmpl.matches(opp, {self._FILE: self._SQL}, self._meta())


# ---------------------------------------------------------------------------
# RemoveDeadColumnsTemplate.apply()
# ---------------------------------------------------------------------------


class TestRemoveDeadColumnsTemplateApply:
    _FILE = "models/stg_stations.sql"
    _SQL = (
        "WITH\n"
        "  base AS (\n"
        "    SELECT\n"
        "      station_id,\n"
        "      name,\n"
        "      elevation,\n"
        "      country_code\n"
        "    FROM raw_stations\n"
        "  ),\n"
        "  final AS (\n"
        "    SELECT station_id, name FROM base\n"
        "  )\n"
        "SELECT station_id, name FROM final\n"
    )

    def _opp(self, dead_cols=None, cte_name="base"):
        cols = dead_cols or ["elevation", "country_code"]
        return _make_opportunity(
            {
                "dead_columns": cols,
                "cte_dead_columns": [
                    {
                        "cte_name": cte_name,
                        "dead_columns": cols,
                        "all_columns": ["station_id", "name"] + cols,
                    }
                ],
                "dead_count": len(cols),
            }
        )

    def _meta(self, name="stg_stations"):
        return {"original_file_path": self._FILE, "name": name}

    def test_apply_returns_template_result(self):
        tmpl = RemoveDeadColumnsTemplate()
        result = tmpl.apply(self._opp(), {self._FILE: self._SQL}, self._meta())
        assert result is not None

    def test_apply_removes_dead_columns(self):
        tmpl = RemoveDeadColumnsTemplate()
        result = tmpl.apply(self._opp(), {self._FILE: self._SQL}, self._meta())
        assert result is not None
        assert "elevation" not in result.after_content
        assert "country_code" not in result.after_content

    def test_apply_preserves_used_columns(self):
        tmpl = RemoveDeadColumnsTemplate()
        result = tmpl.apply(self._opp(), {self._FILE: self._SQL}, self._meta())
        assert result is not None
        assert "station_id" in result.after_content
        assert "name" in result.after_content

    def test_apply_before_content_unchanged(self):
        tmpl = RemoveDeadColumnsTemplate()
        result = tmpl.apply(self._opp(), {self._FILE: self._SQL}, self._meta())
        assert result is not None
        assert result.before_content == self._SQL

    def test_apply_file_path_set(self):
        tmpl = RemoveDeadColumnsTemplate()
        result = tmpl.apply(self._opp(), {self._FILE: self._SQL}, self._meta())
        assert result is not None
        assert result.file_path == self._FILE

    def test_apply_change_type_is_sql_change(self):
        tmpl = RemoveDeadColumnsTemplate()
        result = tmpl.apply(self._opp(), {self._FILE: self._SQL}, self._meta())
        assert result is not None
        assert result.change_type == "sql_change"

    def test_apply_sets_solution_policy_tags(self):
        tmpl = RemoveDeadColumnsTemplate()
        result = tmpl.apply(self._opp(), {self._FILE: self._SQL}, self._meta())
        assert result is not None
        assert result.policy_tags == ["sql_change"]

    def test_apply_explanation_mentions_model_and_columns(self):
        tmpl = RemoveDeadColumnsTemplate()
        result = tmpl.apply(self._opp(), {self._FILE: self._SQL}, self._meta())
        assert result is not None
        assert "stg_stations" in result.explanation
        assert "base" in result.explanation

    def test_apply_parameters_contain_expected_keys(self):
        tmpl = RemoveDeadColumnsTemplate()
        result = tmpl.apply(self._opp(), {self._FILE: self._SQL}, self._meta())
        assert result is not None
        params = result.parameters
        assert "dead_columns" in params
        assert "modified_ctes" in params
        assert "model_name" in params
        assert "cte_dead_columns" in params
        assert "base" in params["modified_ctes"]

    def test_apply_no_match_returns_none(self):
        """If the dead column isn't found in the SQL, apply returns None."""
        tmpl = RemoveDeadColumnsTemplate()
        opp = _make_opportunity(
            {
                "dead_columns": ["nonexistent_col"],
                "cte_dead_columns": [
                    {
                        "cte_name": "base",
                        "dead_columns": ["nonexistent_col"],
                        "all_columns": ["station_id", "nonexistent_col"],
                    }
                ],
                "dead_count": 1,
            }
        )
        result = tmpl.apply(opp, {self._FILE: self._SQL}, self._meta())
        assert result is None

    def test_apply_multiple_ctes(self):
        """Two CTEs each with a dead column."""
        sql = (
            "WITH\n"
            "  a AS (\n"
            "    SELECT\n"
            "      id,\n"
            "      dead_a\n"
            "    FROM raw_a\n"
            "  ),\n"
            "  b AS (\n"
            "    SELECT\n"
            "      id,\n"
            "      dead_b\n"
            "    FROM a\n"
            "  )\n"
            "SELECT id FROM b\n"
        )
        opp = _make_opportunity(
            {
                "dead_columns": ["dead_a", "dead_b"],
                "cte_dead_columns": [
                    {
                        "cte_name": "a",
                        "dead_columns": ["dead_a"],
                        "all_columns": ["id", "dead_a"],
                    },
                    {
                        "cte_name": "b",
                        "dead_columns": ["dead_b"],
                        "all_columns": ["id", "dead_b"],
                    },
                ],
                "dead_count": 2,
            }
        )
        tmpl = RemoveDeadColumnsTemplate()
        result = tmpl.apply(opp, {self._FILE: sql}, self._meta())
        assert result is not None
        assert "dead_a" not in result.after_content
        assert "dead_b" not in result.after_content
        assert "id" in result.after_content
        assert set(result.parameters["modified_ctes"]) == {"a", "b"}

    def test_apply_preserves_jinja(self):
        sql = (
            "WITH base AS (\n"
            "  SELECT\n"
            "    id,\n"
            "    dead_col,\n"
            "    name\n"
            "  FROM {{ ref('raw') }}\n"
            ")\n"
            "SELECT id, name FROM base\n"
        )
        opp = _make_opportunity(
            {
                "dead_columns": ["dead_col"],
                "cte_dead_columns": [
                    {
                        "cte_name": "base",
                        "dead_columns": ["dead_col"],
                        "all_columns": ["id", "dead_col", "name"],
                    }
                ],
                "dead_count": 1,
            }
        )
        tmpl = RemoveDeadColumnsTemplate()
        result = tmpl.apply(opp, {self._FILE: sql}, self._meta())
        assert result is not None
        assert "{{ ref('raw') }}" in result.after_content
        assert "dead_col" not in result.after_content

    def test_apply_empty_evidence_returns_none(self):
        tmpl = RemoveDeadColumnsTemplate()
        opp = _make_opportunity({})
        result = tmpl.apply(opp, {self._FILE: self._SQL}, self._meta())
        assert result is None

    def test_rollback_instructions(self):
        tmpl = RemoveDeadColumnsTemplate()
        assert "CTE" in tmpl.rollback_instructions()
