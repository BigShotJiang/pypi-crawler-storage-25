"""Regression tests for ``ExpandSelectStarTemplate`` over the
dbt-bigquery CTAS-with-OPTIONS shape.

Pre-fix bug: the template's parse helper unwrapped only one
``args["expression"]`` level, missing the ``Subquery`` that wraps the
SELECT inside ``CREATE … AS (…)``; and its regex required paren-depth
0 for the outer ``SELECT *``, but the wrapper puts the outer SELECT at
depth 1. Either bug alone caused the template to silently return None,
which made detection drop the suggestion as template-less. This test
asserts both paths now light up for a real-world dbt-bigquery query.
"""

from __future__ import annotations

from types import SimpleNamespace

from governor_core.solutions.templates.expand_select_star import (
    ExpandSelectStarTemplate,
    _ctas_baseline_paren_depth,
    _outer_select_star_span,
    _outer_select_uses_star,
)


# Trimmed from the actual failing dbt model — preserves the wrapper
# shape that triggered the bug. The outer projection is `select * from
# enriched`, materialised through `CREATE OR REPLACE TABLE … OPTIONS()
# AS (…)`. The inner CTE has its own `select *,` which the rule does
# not flag (by design — only the outer level matters for materialised
# rows).
_CTAS_WITH_OPTIONS = """\
/* {"app": "dbt", "node_id": "model.governor_weather.stg_lightning_strikes"} */

create or replace table `sm-dev-447100`.`governor_weather_staging`.`stg_lightning_strikes`
  partition by timestamp_trunc(strike_date, day)
  cluster by geographic_region, intensity_class
  OPTIONS()
  as (

with raw_lightning as (
    select
        *,
        EXTRACT(YEAR FROM date) as source_year
    from `bigquery-public-data`.`noaa_lightning`.`lightning_strikes`
    where date >= '2024-01-01'
),
enriched as (
    select
        date as strike_date,
        number_of_strikes,
        center_point_geom,
        source_year
    from raw_lightning
)

select * from enriched
);
"""


_PLAIN_SELECT_STAR = "SELECT * FROM `proj.dataset.tbl`"


_NESTED_SELECT_STAR_NO_OUTER = (
    "SELECT id, name FROM (SELECT * FROM `proj.dataset.tbl`)"
)


def _make_opp():
    return SimpleNamespace(
        id="opp-1",
        opportunity_type="select_star",
        evidence_snapshot={},
        dbt_model_name="stg_lightning_strikes",
        affected_table="sm-dev-447100.governor_weather_staging.stg_lightning_strikes",
    )


# --------------------------------------------------------------------
# _ctas_baseline_paren_depth — detects the wrapper shape that pushes the
# outer SELECT to depth 1.
# --------------------------------------------------------------------


def test_ctas_baseline_depth_detects_create_or_replace_table_as_options():
    assert _ctas_baseline_paren_depth(_CTAS_WITH_OPTIONS) == 1


def test_ctas_baseline_depth_detects_create_table_as_no_options():
    sql = (
        "create or replace table `proj.ds.t` partition by d "
        "as ( select * from `proj.ds.src` )"
    )
    assert _ctas_baseline_paren_depth(sql) == 1


def test_ctas_baseline_depth_detects_create_view_as():
    sql = "create or replace view `proj.ds.v` as ( select * from `proj.ds.src` )"
    assert _ctas_baseline_paren_depth(sql) == 1


def test_ctas_baseline_depth_detects_materialized_view():
    sql = (
        "create or replace materialized view `proj.ds.mv` as "
        "( select * from `proj.ds.src` )"
    )
    assert _ctas_baseline_paren_depth(sql) == 1


def test_ctas_baseline_depth_returns_zero_for_plain_select():
    assert _ctas_baseline_paren_depth(_PLAIN_SELECT_STAR) == 0


# --------------------------------------------------------------------
# _outer_select_star_span — locates the outer "*" token in the original
# text, accounting for the CTAS wrapper depth.
# --------------------------------------------------------------------


def test_outer_select_star_span_locates_star_inside_ctas_wrapper():
    span = _outer_select_star_span(_CTAS_WITH_OPTIONS)
    assert span is not None, "must locate the outer '*' inside CREATE … AS (…)"
    start, end = span
    # The captured span must point at the literal '*' character.
    assert _CTAS_WITH_OPTIONS[start:end] == "*"
    # And specifically the OUTER 'select * from enriched', not the inner
    # 'select *,' inside the raw_lightning CTE.
    preceding = _CTAS_WITH_OPTIONS[:start].rstrip()
    assert preceding.endswith("select"), (
        "captured '*' must immediately follow the outer 'select' keyword"
    )
    following = _CTAS_WITH_OPTIONS[end:].lstrip()
    assert following.startswith("from enriched"), (
        "captured '*' must precede 'from enriched' (the outer projection)"
    )


def test_outer_select_star_span_locates_star_in_plain_select():
    span = _outer_select_star_span(_PLAIN_SELECT_STAR)
    assert span is not None
    start, end = span
    assert _PLAIN_SELECT_STAR[start:end] == "*"


def test_outer_select_star_span_returns_none_when_only_inner_star():
    """When the outer SELECT projects explicit columns and only an
    inner subquery has SELECT *, the template must NOT splice anything
    — the outer level is fine."""
    assert _outer_select_star_span(_NESTED_SELECT_STAR_NO_OUTER) is None


# --------------------------------------------------------------------
# _outer_select_uses_star — sqlglot-side check now uses _outermost_select
# so it descends through Create → Subquery → Select.
# --------------------------------------------------------------------


def test_outer_select_uses_star_true_for_ctas_with_options():
    assert _outer_select_uses_star(_CTAS_WITH_OPTIONS) is True


def test_outer_select_uses_star_true_for_plain_select():
    assert _outer_select_uses_star(_PLAIN_SELECT_STAR) is True


def test_outer_select_uses_star_false_when_outer_has_explicit_columns():
    assert _outer_select_uses_star(_NESTED_SELECT_STAR_NO_OUTER) is False


# --------------------------------------------------------------------
# End-to-end: the template runs the full match → apply path and emits a
# TemplateResult whose after_content has the column list spliced in
# place of the outer '*' inside the CTAS wrapper.
# --------------------------------------------------------------------


def test_template_apply_rewrites_outer_star_inside_ctas_wrapper():
    template = ExpandSelectStarTemplate()
    columns = [
        "strike_date",
        "number_of_strikes",
        "geographic_region",
        "intensity_class",
        "latitude",
        "longitude",
    ]
    file_path = "audit://q/test.sql"
    source_files = {file_path: _CTAS_WITH_OPTIONS}
    manifest_metadata = {
        "original_file_path": file_path,
        "available_columns": columns,
        "database": "sm-dev-447100",
        "schema": "governor_weather_staging",
        "identifier": "stg_lightning_strikes",
    }

    assert template.matches(_make_opp(), source_files, manifest_metadata) is True

    result = template.apply(_make_opp(), source_files, manifest_metadata)
    assert result is not None, "template must emit a diff for CTAS-with-OPTIONS"
    assert result.before_content == _CTAS_WITH_OPTIONS
    assert result.after_content != _CTAS_WITH_OPTIONS

    # The outer '*' must be gone.
    assert "select * from enriched" not in result.after_content.lower()

    # Every column must be present in the rewritten SQL exactly once.
    for col in columns:
        assert col in result.after_content

    # The CTAS wrapper, partition / cluster clauses, and the inner
    # 'select *,' inside raw_lightning must be preserved.
    assert "create or replace table" in result.after_content.lower()
    assert "partition by timestamp_trunc(strike_date, day)" in result.after_content
    assert "cluster by geographic_region, intensity_class" in result.after_content
    assert "select\n        *,\n        EXTRACT(YEAR FROM date)" in result.after_content


def test_template_skips_when_no_columns_available():
    template = ExpandSelectStarTemplate()
    file_path = "audit://q/test.sql"
    source_files = {file_path: _CTAS_WITH_OPTIONS}
    manifest_metadata = {
        "original_file_path": file_path,
        "available_columns": [],
        "database": "sm-dev-447100",
        "schema": "governor_weather_staging",
        "identifier": "stg_lightning_strikes",
    }
    assert template.matches(_make_opp(), source_files, manifest_metadata) is False


def test_template_skips_when_outer_select_is_explicit_columns():
    template = ExpandSelectStarTemplate()
    file_path = "audit://q/test.sql"
    source_files = {file_path: _NESTED_SELECT_STAR_NO_OUTER}
    manifest_metadata = {
        "original_file_path": file_path,
        "available_columns": ["id", "name"],
        "database": "proj",
        "schema": "dataset",
        "identifier": "tbl",
    }
    assert template.apply(_make_opp(), source_files, manifest_metadata) is None
