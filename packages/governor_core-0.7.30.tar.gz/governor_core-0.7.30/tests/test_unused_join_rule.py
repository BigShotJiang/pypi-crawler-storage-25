"""Unit tests for app/opportunities/rules/unused_join.py."""

from decimal import Decimal

import pytest

from governor_core.opportunities.rules.unused_join import UnusedJoinRule


def _node(name: str, sql: str, materialized: str = "table") -> dict:
    return {
        "name": name,
        "unique_id": f"model.proj.{name}",
        "database": "my-project",
        "schema": "dbt_prod",
        "identifier": name,
        "config": {"materialized": materialized},
        "raw_code": sql,
        "compiled_code": sql,
    }


def _manifest() -> dict:
    sql = """
WITH
  rhs AS (
    SELECT customer_id
    FROM raw_customers
    GROUP BY customer_id
  ),
  base AS (
    SELECT
      o.order_id
    FROM raw_orders o
    LEFT JOIN rhs r ON o.customer_id = r.customer_id
  ),
  final AS (
    SELECT order_id FROM base
  )
SELECT order_id FROM final
"""
    return {
        "nodes": {"model.proj.fct_orders": _node("fct_orders", sql)},
        "child_map": {"model.proj.fct_orders": []},
    }


def test_rule_type():
    assert UnusedJoinRule().rule_type == "unused_join"


def test_default_thresholds():
    thresholds = UnusedJoinRule().default_thresholds
    assert thresholds["min_unused_joins"] == 1


def test_detect_none_manifest():
    assert UnusedJoinRule().detect(jobs=[], manifest_content=None, thresholds={}) == []


def test_detect_returns_candidate():
    results = UnusedJoinRule().detect(
        jobs=[],
        manifest_content=_manifest(),
        thresholds={},
    )

    assert len(results) == 1
    candidate = results[0]
    assert candidate.opportunity_type == "unused_join"
    assert candidate.dbt_model_name == "fct_orders"
    assert candidate.evidence_snapshot["unused_join_count"] == 1
    assert candidate.evidence_snapshot["unused_joins"] == [
        {
            "cte_name": "base",
            "join_alias": "r",
            "joined_source_name": "rhs",
            "join_keys": ["customer_id"],
        }
    ]
    assert candidate.confidence == pytest.approx(0.58)


def test_detect_no_job_data_zero_savings():
    results = UnusedJoinRule().detect(
        jobs=[],
        manifest_content=_manifest(),
        thresholds={},
    )

    assert len(results) == 1
    assert results[0].expected_savings == Decimal("0")
    assert results[0].current_cost_estimate == Decimal("0")


def test_detect_min_threshold():
    results = UnusedJoinRule().detect(
        jobs=[],
        manifest_content=_manifest(),
        thresholds={"min_unused_joins": 2},
    )

    assert results == []
