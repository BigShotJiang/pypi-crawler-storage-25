"""Unit tests for INFORMATION_SCHEMA column validation (spec 064).

Tests:
1. query_table_columns() GCP client function
2. _suggest_cluster_columns() with valid_columns parameter
3. analyze_upstream() with column_lookup integration
4. make_column_lookup() helper
"""

from __future__ import annotations

from unittest.mock import MagicMock, patch

from governor_core.dbt.lineage_analyzer import (
    analyze_upstream,
    _suggest_cluster_columns,
)


# ---------------------------------------------------------------------------
# Manifest fixtures (reused from test_lineage_analyzer.py pattern)
# ---------------------------------------------------------------------------


def _make_manifest(nodes: dict | None = None, project_name: str = "my_project") -> dict:
    return {
        "metadata": {"project_name": project_name},
        "nodes": nodes or {},
    }


def _make_node(
    name: str,
    unique_id: str | None = None,
    materialized: str = "table",
    package_name: str = "my_project",
    depends_on_nodes: list[str] | None = None,
    cluster_by: list[str] | None = None,
    columns: dict | None = None,
    compiled_code: str | None = None,
    schema: str = "dataset",
    alias: str | None = None,
) -> dict:
    uid = unique_id or f"model.my_project.{name}"
    return {
        "name": name,
        "unique_id": uid,
        "resource_type": "model",
        "package_name": package_name,
        "original_file_path": f"models/{name}.sql",
        "config": {
            "materialized": materialized,
            **({"cluster_by": cluster_by} if cluster_by else {}),
        },
        "depends_on": {"nodes": depends_on_nodes or []},
        "columns": columns or {},
        "schema": schema,
        **({"alias": alias} if alias else {}),
        **({"compiled_code": compiled_code} if compiled_code else {}),
    }


# ---------------------------------------------------------------------------
# Tests for _suggest_cluster_columns with valid_columns
# ---------------------------------------------------------------------------


class TestSuggestClusterColumnsWithValidation:
    """Test column validation via valid_columns parameter."""

    def test_filters_hallucinated_columns(self):
        """Columns not in valid_columns should be filtered out."""
        node = _make_node("upstream")
        result = _suggest_cluster_columns(
            relevant_columns=["station_id", "station_name", "station_country", "sid"],
            existing_cluster=[],
            upstream_node=node,
            opportunity_type="shuffle_spill",
            valid_columns={"sid", "name", "basin", "season"},
        )
        # Only "sid" exists in valid_columns
        assert result == ["sid"]

    def test_all_columns_valid(self):
        """All suggested columns exist — nothing filtered."""
        node = _make_node("upstream")
        result = _suggest_cluster_columns(
            relevant_columns=["sid", "basin", "season"],
            existing_cluster=[],
            upstream_node=node,
            opportunity_type="shuffle_spill",
            valid_columns={"sid", "basin", "season", "name"},
        )
        assert result == ["sid", "basin", "season"]

    def test_case_insensitive_matching(self):
        """Column matching should be case-insensitive."""
        node = _make_node("upstream")
        result = _suggest_cluster_columns(
            relevant_columns=["SID", "Basin"],
            existing_cluster=[],
            upstream_node=node,
            opportunity_type="shuffle_spill",
            valid_columns={"sid", "basin", "season"},
        )
        assert result == ["SID", "Basin"]

    def test_no_valid_columns_falls_back_to_manifest(self):
        """When valid_columns is None, fall back to manifest columns."""
        node = _make_node(
            "upstream",
            columns={
                "sid": {"name": "sid", "description": "Storm ID"},
                "basin": {"name": "basin", "description": "Basin"},
            },
        )
        result = _suggest_cluster_columns(
            relevant_columns=["sid", "station_id"],
            existing_cluster=[],
            upstream_node=node,
            opportunity_type="shuffle_spill",
            valid_columns=None,
        )
        # station_id not in manifest columns, should be filtered
        assert result == ["sid"]

    def test_no_valid_columns_and_no_manifest_passes_through(self):
        """When neither source has columns, suggestions pass through unvalidated."""
        node = _make_node("upstream")
        result = _suggest_cluster_columns(
            relevant_columns=["station_id", "sid"],
            existing_cluster=[],
            upstream_node=node,
            opportunity_type="shuffle_spill",
            valid_columns=None,
        )
        # No validation data — all pass through
        assert result == ["station_id", "sid"]

    def test_empty_valid_columns_filters_everything(self):
        """Empty set means table exists but has no matching columns."""
        node = _make_node("upstream")
        result = _suggest_cluster_columns(
            relevant_columns=["station_id", "sid"],
            existing_cluster=[],
            upstream_node=node,
            opportunity_type="shuffle_spill",
            valid_columns=set(),
        )
        assert result == []

    def test_already_clustered_columns_excluded(self):
        """Columns already in cluster_by should not be suggested again."""
        node = _make_node("upstream")
        result = _suggest_cluster_columns(
            relevant_columns=["sid", "basin", "season"],
            existing_cluster=["sid"],
            upstream_node=node,
            opportunity_type="shuffle_spill",
            valid_columns={"sid", "basin", "season"},
        )
        assert "sid" not in result
        assert result == ["basin", "season"]

    def test_max_4_columns_limit(self):
        """BigQuery cluster_by limit of 4 columns is respected."""
        node = _make_node("upstream")
        result = _suggest_cluster_columns(
            relevant_columns=["a", "b", "c", "d", "e"],
            existing_cluster=[],
            upstream_node=node,
            opportunity_type="shuffle_spill",
            valid_columns={"a", "b", "c", "d", "e"},
        )
        assert len(result) <= 4


# ---------------------------------------------------------------------------
# Tests for analyze_upstream with column_lookup
# ---------------------------------------------------------------------------


class TestAnalyzeUpstreamWithColumnLookup:
    """Test that analyze_upstream passes column_lookup through correctly."""

    def test_column_lookup_filters_suggestions(self):
        """Suggested columns should be filtered by column_lookup."""
        upstream = _make_node(
            "stg_orders",
            depends_on_nodes=[],
            schema="analytics",
        )
        downstream = _make_node(
            "int_metrics",
            depends_on_nodes=["model.my_project.stg_orders"],
        )
        manifest = _make_manifest(
            nodes={
                "model.my_project.stg_orders": upstream,
                "model.my_project.int_metrics": downstream,
            }
        )

        # Compiled SQL references columns that don't exist in stg_orders
        compiled_sql = """
        SELECT o.order_id, o.customer_id, o.station_id
        FROM analytics.stg_orders o
        JOIN analytics.dim_customers c ON o.customer_id = c.customer_id
        GROUP BY o.order_id, o.customer_id, o.station_id
        """

        # column_lookup returns only columns that exist in stg_orders
        def mock_lookup(node: dict) -> set[str] | None:
            if node.get("name") == "stg_orders":
                return {"order_id", "customer_id", "amount", "created_at"}
            return None

        result = analyze_upstream(
            manifest_content=manifest,
            affected_model_name="int_metrics",
            opportunity_type="shuffle_spill",
            compiled_sql=compiled_sql,
            column_lookup=mock_lookup,
        )

        assert len(result.candidates) == 1
        candidate = result.candidates[0]
        # station_id should be filtered out — not in stg_orders
        assert "station_id" not in candidate.suggested_cluster_columns
        # customer_id and order_id should remain
        for col in candidate.suggested_cluster_columns:
            assert col.lower() in {"customer_id", "order_id"}

    def test_column_lookup_none_falls_back(self):
        """When column_lookup returns None, no filtering happens."""
        upstream = _make_node("stg_orders", depends_on_nodes=[])
        downstream = _make_node(
            "int_metrics",
            depends_on_nodes=["model.my_project.stg_orders"],
        )
        manifest = _make_manifest(
            nodes={
                "model.my_project.stg_orders": upstream,
                "model.my_project.int_metrics": downstream,
            }
        )

        compiled_sql = """
        SELECT o.order_id, o.station_id
        FROM analytics.stg_orders o
        JOIN analytics.dim_x x ON o.station_id = x.station_id
        """

        def mock_lookup(node: dict) -> set[str] | None:
            return None  # No column data available

        result = analyze_upstream(
            manifest_content=manifest,
            affected_model_name="int_metrics",
            opportunity_type="shuffle_spill",
            compiled_sql=compiled_sql,
            column_lookup=mock_lookup,
        )

        # No filtering — station_id passes through
        assert len(result.candidates) == 1
        assert "station_id" in result.candidates[0].suggested_cluster_columns

    def test_no_column_lookup_backward_compatible(self):
        """Without column_lookup parameter, behavior is unchanged."""
        upstream = _make_node("stg_orders", depends_on_nodes=[])
        downstream = _make_node(
            "int_metrics",
            depends_on_nodes=["model.my_project.stg_orders"],
        )
        manifest = _make_manifest(
            nodes={
                "model.my_project.stg_orders": upstream,
                "model.my_project.int_metrics": downstream,
            }
        )

        compiled_sql = """
        SELECT o.order_id, o.station_id
        FROM analytics.stg_orders o
        JOIN analytics.dim_x x ON o.station_id = x.station_id
        """

        result = analyze_upstream(
            manifest_content=manifest,
            affected_model_name="int_metrics",
            opportunity_type="shuffle_spill",
            compiled_sql=compiled_sql,
            # No column_lookup — backward compatible
        )

        assert len(result.candidates) == 1
        # Without validation, all columns pass through
        assert "station_id" in result.candidates[0].suggested_cluster_columns


# ---------------------------------------------------------------------------
# Tests for query_table_columns GCP client
# ---------------------------------------------------------------------------


class TestQueryTableColumns:
    """Test the INFORMATION_SCHEMA.COLUMNS query function."""

    def test_query_returns_column_rows(self):
        with patch("governor_core.gcp.clients.get_bigquery_client") as mock_get_client:
            mock_client = MagicMock()
            mock_get_client.return_value = mock_client

            mock_row1 = MagicMock()
            mock_row1.items.return_value = [
                ("dataset_name", "analytics"),
                ("table_name", "orders"),
                ("column_name", "order_id"),
                ("data_type", "STRING"),
                ("ordinal_position", 1),
            ]
            mock_row2 = MagicMock()
            mock_row2.items.return_value = [
                ("dataset_name", "analytics"),
                ("table_name", "orders"),
                ("column_name", "amount"),
                ("data_type", "FLOAT64"),
                ("ordinal_position", 2),
            ]

            mock_query_job = MagicMock()
            mock_query_job.result.return_value = [mock_row1, mock_row2]
            mock_client.query.return_value = mock_query_job

            from governor_core.gcp.clients import query_table_columns

            rows = query_table_columns("my-project", region="us")

            assert len(rows) == 2
            assert rows[0]["column_name"] == "order_id"
            assert rows[1]["data_type"] == "FLOAT64"

            # Verify SQL query uses correct INFORMATION_SCHEMA path
            query_sql = mock_client.query.call_args[0][0]
            assert "INFORMATION_SCHEMA.COLUMNS" in query_sql
            assert "region-us" in query_sql

    def test_query_filters_system_datasets(self):
        with patch("governor_core.gcp.clients.get_bigquery_client") as mock_get_client:
            mock_client = MagicMock()
            mock_get_client.return_value = mock_client

            mock_query_job = MagicMock()
            mock_query_job.result.return_value = []
            mock_client.query.return_value = mock_query_job

            from governor_core.gcp.clients import query_table_columns

            query_table_columns("my-project")

            query_sql = mock_client.query.call_args[0][0]
            # Should filter out system datasets starting with _
            assert "NOT STARTS_WITH" in query_sql
