"""Unit tests for PullRequestService."""

from __future__ import annotations

from unittest.mock import MagicMock

import pytest

from tests.helpers import (
    _create_test_prereqs,
    _create_test_solution,
    _create_test_solution_job,
)


class TestPullRequestServiceCreatePR:
    """Tests for PullRequestService.create_pr()."""

    def _make_service(self, db, **github_overrides):
        """Create a PullRequestService with a mock GitHub client."""
        from governor_core.pullrequests.service import PullRequestService

        mock_github = MagicMock()
        mock_github.get_default_branch.return_value = "main"
        mock_github.get_branch_head_sha.return_value = "head-sha-123"
        mock_github.create_branch.return_value = "branch-sha"
        mock_github.create_file_commit.return_value = "commit-sha-456"
        mock_github.create_pull_request.return_value = {
            "number": 42,
            "url": "https://api.github.com/repos/owner/repo/pulls/42",
            "html_url": "https://github.com/owner/repo/pull/42",
        }
        # get_file_content returns the same before_content (no drift)
        mock_github.get_file_content.return_value = "SELECT * FROM raw.orders"

        for key, value in github_overrides.items():
            setattr(mock_github, key, value)

        return PullRequestService(db, mock_github), mock_github

    def test_successful_pr_creation(self, client, db):
        """Successfully creates a PR and updates opportunity status."""
        prereqs = _create_test_prereqs(db)
        job = _create_test_solution_job(db, prereqs, status="completed")
        solution = _create_test_solution(db, job, prereqs)

        service, mock_gh = self._make_service(db)
        pr_record = service.create_pr(
            opportunity_id=prereqs["opportunity"].id,
            solution_id=solution.id,
            user_id=prereqs["user"].id,
        )

        assert pr_record.pr_number == 42
        assert pr_record.pr_url == "https://github.com/owner/repo/pull/42"
        assert pr_record.repository == "owner/repo"
        assert pr_record.base_branch == "main"
        assert pr_record.status == "open"
        assert pr_record.commit_sha == "commit-sha-456"

        # Opportunity should now be pr_pending
        db.refresh(prereqs["opportunity"])
        assert prereqs["opportunity"].status == "pr_pending"

        # Verify GitHub calls
        mock_gh.get_default_branch.assert_called_once_with("owner/repo")
        mock_gh.get_branch_head_sha.assert_called_once_with("owner/repo", "main")
        # Called twice: once in _resolve_repo_paths, once in drift check
        assert mock_gh.get_file_content.call_count == 2
        mock_gh.create_branch.assert_called_once()
        mock_gh.create_file_commit.assert_called_once()
        mock_gh.create_pull_request.assert_called_once()

        # Verify draft=False (non-draft for notifications)
        _, kwargs = mock_gh.create_pull_request.call_args
        assert kwargs["draft"] is False

    def test_opportunity_not_found(self, client, db):
        """Raises PRCreationError when opportunity doesn't exist."""
        from governor_core.pullrequests.exceptions import PRCreationError

        service, _ = self._make_service(db)
        with pytest.raises(PRCreationError, match="Opportunity not found"):
            service.create_pr("nonexistent-id", "sol-id", "user-id")

    def test_opportunity_not_active(self, client, db):
        """Raises PRCreationError when opportunity is resolved."""
        from governor_core.pullrequests.exceptions import PRCreationError

        prereqs = _create_test_prereqs(db)
        opp = prereqs["opportunity"]
        opp.status = "resolved"
        db.commit()

        service, _ = self._make_service(db)
        with pytest.raises(PRCreationError, match="not in active state"):
            service.create_pr(opp.id, "sol-id", prereqs["user"].id)

    def test_duplicate_pr_rejected(self, client, db):
        """Raises DuplicatePRError when PR already exists."""
        from governor_core.pullrequests.exceptions import DuplicatePRError

        prereqs = _create_test_prereqs(db)
        job = _create_test_solution_job(db, prereqs, status="completed")
        solution = _create_test_solution(db, job, prereqs)

        # Create first PR
        service, _ = self._make_service(db)
        service.create_pr(prereqs["opportunity"].id, solution.id, prereqs["user"].id)

        # Reset opportunity status for second attempt
        prereqs["opportunity"].status = "active"
        db.commit()

        # Second attempt should fail
        service2, _ = self._make_service(db)
        with pytest.raises(DuplicatePRError, match="already exists"):
            service2.create_pr(
                prereqs["opportunity"].id, solution.id, prereqs["user"].id
            )

    def test_solution_not_dbt_rejected(self, client, db):
        """Raises PRCreationError for bigquery_infrastructure solutions."""
        from governor_core.pullrequests.exceptions import PRCreationError

        prereqs = _create_test_prereqs(db)
        job = _create_test_solution_job(db, prereqs, status="completed")
        solution = _create_test_solution(
            db,
            job,
            prereqs,
            resolution_category="bigquery_infrastructure",
            file_path=None,
            change_type=None,
            before_content=None,
            after_content=None,
            current_setting_value="1000",
            recommended_setting_value="2000",
            affected_resource="project.reservation",
        )

        service, _ = self._make_service(db)
        with pytest.raises(PRCreationError, match="dbt project changes"):
            service.create_pr(
                prereqs["opportunity"].id, solution.id, prereqs["user"].id
            )

    def test_missing_repository_rejected(self, client, db):
        """Raises PRCreationError when solution has no repository."""
        from governor_core.pullrequests.exceptions import PRCreationError

        prereqs = _create_test_prereqs(db)
        job = _create_test_solution_job(db, prereqs, status="completed")
        solution = _create_test_solution(db, job, prereqs, repository=None)

        service, _ = self._make_service(db)
        with pytest.raises(PRCreationError, match="target repository"):
            service.create_pr(
                prereqs["opportunity"].id, solution.id, prereqs["user"].id
            )

    def test_file_drift_detected(self, client, db):
        """Raises FileDriftError when file has changed since solution was generated."""
        from governor_core.pullrequests.exceptions import FileDriftError

        prereqs = _create_test_prereqs(db)
        job = _create_test_solution_job(db, prereqs, status="completed")
        solution = _create_test_solution(db, job, prereqs)

        # GitHub file content differs from before_content
        mock_get_file = MagicMock(return_value="DIFFERENT CONTENT")
        service, _ = self._make_service(db, get_file_content=mock_get_file)

        with pytest.raises(FileDriftError, match="has changed"):
            service.create_pr(
                prereqs["opportunity"].id, solution.id, prereqs["user"].id
            )

        # Opportunity should still be active
        db.refresh(prereqs["opportunity"])
        assert prereqs["opportunity"].status == "active"

    def test_github_auth_error_leaves_opportunity_active(self, client, db):
        """GitHub auth error leaves opportunity in active state."""
        from governor_core.github.client import GitHubAuthenticationError

        prereqs = _create_test_prereqs(db)
        job = _create_test_solution_job(db, prereqs, status="completed")
        solution = _create_test_solution(db, job, prereqs)

        mock_get_default = MagicMock(
            side_effect=GitHubAuthenticationError("auth failed")
        )
        service, _ = self._make_service(db, get_default_branch=mock_get_default)

        with pytest.raises(GitHubAuthenticationError):
            service.create_pr(
                prereqs["opportunity"].id, solution.id, prereqs["user"].id
            )

        db.refresh(prereqs["opportunity"])
        assert prereqs["opportunity"].status == "active"

    def test_github_connection_error_leaves_opportunity_active(self, client, db):
        """GitHub connection error leaves opportunity in active state."""
        from governor_core.github.client import GitHubConnectionError

        prereqs = _create_test_prereqs(db)
        job = _create_test_solution_job(db, prereqs, status="completed")
        solution = _create_test_solution(db, job, prereqs)

        mock_create_branch = MagicMock(
            side_effect=GitHubConnectionError("network error")
        )
        service, _ = self._make_service(db, create_branch=mock_create_branch)

        with pytest.raises(GitHubConnectionError):
            service.create_pr(
                prereqs["opportunity"].id, solution.id, prereqs["user"].id
            )

        db.refresh(prereqs["opportunity"])
        assert prereqs["opportunity"].status == "active"

    def test_branch_conflict_retries_with_new_name(self, client, db):
        """Branch creation conflict retries once with a new name."""
        from governor_core.github.client import GitHubConnectionError

        prereqs = _create_test_prereqs(db)
        job = _create_test_solution_job(db, prereqs, status="completed")
        solution = _create_test_solution(db, job, prereqs)

        # First call raises conflict, second succeeds
        mock_create_branch = MagicMock(
            side_effect=[GitHubConnectionError("Reference already exists"), "retry-sha"]
        )
        service, mock_gh = self._make_service(db, create_branch=mock_create_branch)
        pr_record = service.create_pr(
            prereqs["opportunity"].id, solution.id, prereqs["user"].id
        )

        assert pr_record.pr_number == 42
        assert mock_create_branch.call_count == 2


class TestBuildCommitMessage:
    """Tests for _build_commit_message()."""

    def test_conventional_commits_format(self, client, db):
        """Commit message follows Conventional Commits format."""
        from governor_core.pullrequests.service import _build_commit_message

        prereqs = _create_test_prereqs(db)
        job = _create_test_solution_job(db, prereqs, status="completed")
        solution = _create_test_solution(db, job, prereqs)

        msg = _build_commit_message(prereqs["opportunity"], [solution])

        # First line: type(scope): description
        first_line = msg.split("\n")[0]
        assert first_line.startswith("perf(")
        assert ":" in first_line

    def test_contains_all_sections(self, client, db):
        """Commit message contains all five required sections."""
        from governor_core.pullrequests.service import _build_commit_message

        prereqs = _create_test_prereqs(db)
        job = _create_test_solution_job(db, prereqs, status="completed")
        solution = _create_test_solution(db, job, prereqs)

        msg = _build_commit_message(prereqs["opportunity"], [solution])

        assert "Problem:" in msg
        assert "Solution:" in msg
        assert "Rationale:" in msg
        assert "Expected outcome:" in msg
        assert "Risk:" in msg

    def test_contains_governor_footer(self, client, db):
        """Commit message contains Governor-Opportunity footer."""
        from governor_core.pullrequests.service import _build_commit_message

        prereqs = _create_test_prereqs(db)
        job = _create_test_solution_job(db, prereqs, status="completed")
        solution = _create_test_solution(db, job, prereqs)

        msg = _build_commit_message(prereqs["opportunity"], [solution])

        assert f"Governor-Opportunity: {prereqs['opportunity'].id}" in msg


class TestBuildPRDescription:
    """Tests for _build_pr_description()."""

    def test_contains_auto_generation_notice(self, client, db):
        """PR description includes auto-generation and review notice."""
        from governor_core.pullrequests.service import _build_pr_description

        prereqs = _create_test_prereqs(db)
        job = _create_test_solution_job(db, prereqs, status="completed")
        solution = _create_test_solution(db, job, prereqs)

        body = _build_pr_description(prereqs["opportunity"], [solution])

        assert "auto-generated by Governor" in body
        assert "human review" in body

    def test_contains_opportunity_details(self, client, db):
        """PR description includes opportunity type, table, severity, savings."""
        from governor_core.pullrequests.service import _build_pr_description

        prereqs = _create_test_prereqs(db)
        job = _create_test_solution_job(db, prereqs, status="completed")
        solution = _create_test_solution(db, job, prereqs)

        body = _build_pr_description(prereqs["opportunity"], [solution])

        assert "shuffle_spill" in body
        assert "project.dataset.table1" in body
        assert "75/100" in body


class TestGenerateBranchName:
    """Tests for _generate_branch_name()."""

    def test_branch_name_format(self, client, db):
        """Branch name follows governor/{type}/{table}-{uuid} format."""
        from governor_core.pullrequests.service import _generate_branch_name

        prereqs = _create_test_prereqs(db)
        name = _generate_branch_name(prereqs["opportunity"])

        assert name.startswith("governor/")
        parts = name.split("/")
        assert len(parts) == 3
        # Last part should have a hyphen before the UUID suffix
        assert "-" in parts[2]

    def test_branch_name_uniqueness(self, client, db):
        """Each call produces a unique branch name."""
        from governor_core.pullrequests.service import _generate_branch_name

        prereqs = _create_test_prereqs(db)
        name1 = _generate_branch_name(prereqs["opportunity"])
        name2 = _generate_branch_name(prereqs["opportunity"])

        assert name1 != name2


class TestBuildPRDescriptionTrustTier:
    """Tests for trust tier section in PR descriptions (spec 030)."""

    def test_guaranteed_safe_includes_trust_section(self, client, db):
        """Guaranteed safe PR description includes trust verification without warning."""
        from governor_core.pullrequests.service import _build_pr_description

        prereqs = _create_test_prereqs(db)
        job = _create_test_solution_job(db, prereqs, status="completed")
        solution = _create_test_solution(db, job, prereqs, trust_tier="guaranteed_safe")

        body = _build_pr_description(prereqs["opportunity"], [solution])

        assert "Trust Verification" in body
        assert "Guaranteed Safe" in body
        assert "Template-based deterministic change" in body
        assert "Warning" not in body

    def test_validated_includes_trust_section(self, client, db):
        """Validated PR description includes trust verification without warning."""
        from governor_core.pullrequests.service import _build_pr_description

        prereqs = _create_test_prereqs(db)
        job = _create_test_solution_job(db, prereqs, status="completed")
        solution = _create_test_solution(db, job, prereqs, trust_tier="validated")

        body = _build_pr_description(prereqs["opportunity"], [solution])

        assert "Trust Verification" in body
        assert "Validated" in body
        assert "Structural analysis confirms additive-only" in body
        assert "Warning" not in body

    def test_requires_review_includes_warning(self, client, db):
        """Requires review PR description includes prominent warning block."""
        from governor_core.pullrequests.service import _build_pr_description

        prereqs = _create_test_prereqs(db)
        job = _create_test_solution_job(db, prereqs, status="completed")
        solution = _create_test_solution(db, job, prereqs, trust_tier="requires_review")

        body = _build_pr_description(prereqs["opportunity"], [solution])

        assert "Trust Verification" in body
        assert "Requires Review" in body
        assert "Warning" in body
        assert "review all changes carefully" in body

    def test_none_trust_tier_treated_as_requires_review(self, client, db):
        """None trust_tier (pre-existing solutions) treated as requires_review."""
        from governor_core.pullrequests.service import _build_pr_description

        prereqs = _create_test_prereqs(db)
        job = _create_test_solution_job(db, prereqs, status="completed")
        solution = _create_test_solution(db, job, prereqs)
        # trust_tier defaults to None

        body = _build_pr_description(prereqs["opportunity"], [solution])

        assert "Trust Verification" in body
        assert "Requires Review" in body
        assert "Warning" in body

    def test_requires_review_forces_draft(self, client, db):
        """Requires review solution forces draft status on PR."""
        from governor_core.pullrequests.service import _is_requires_review

        prereqs = _create_test_prereqs(db)
        job = _create_test_solution_job(db, prereqs, status="completed")
        solution = _create_test_solution(db, job, prereqs, trust_tier="requires_review")

        assert _is_requires_review([solution]) is True

    def test_guaranteed_safe_not_requires_review(self, client, db):
        """Guaranteed safe solution does not force requires_review."""
        from governor_core.pullrequests.service import _is_requires_review

        prereqs = _create_test_prereqs(db)
        job = _create_test_solution_job(db, prereqs, status="completed")
        solution = _create_test_solution(db, job, prereqs, trust_tier="guaranteed_safe")

        assert _is_requires_review([solution]) is False

    def test_mixed_tiers_uses_most_cautious(self, client, db):
        """Mixed trust tiers uses the most cautious (requires_review wins)."""
        from governor_core.pullrequests.service import _get_trust_tier

        prereqs = _create_test_prereqs(db)
        job = _create_test_solution_job(db, prereqs, status="completed")
        sol1 = _create_test_solution(
            db,
            job,
            prereqs,
            trust_tier="guaranteed_safe",
            file_path="models/a.sql",
        )
        sol2 = _create_test_solution(
            db,
            job,
            prereqs,
            trust_tier="requires_review",
            file_path="models/b.sql",
            version_number=2,
        )

        assert _get_trust_tier([sol1, sol2]) == "requires_review"
