"""Unit tests for app.pullrequests.lineage_impact."""

from __future__ import annotations

from decimal import Decimal

import pytest

from governor_core.pullrequests.lineage_impact import (
    DownstreamLineageAnalyzer,
    build_summary,
    build_summary_from_results,
)


# ── Manifest fixture helpers ──────────────────────────────────────────────────

def _node(name: str, relation: str, compiled_sql: str = "") -> dict:
    return {
        "name": name,
        "relation_name": relation,
        "compiled_code": compiled_sql,
        "package_name": "my_project",
    }


def _manifest(nodes: dict, child_map: dict) -> dict:
    return {"nodes": nodes, "child_map": child_map}


def _sql_with_filter(table: str, column: str) -> str:
    return (
        f"SELECT * FROM `{table}` AS t "
        f"WHERE t.{column} = '2024-01-01'"
    )


def _sql_without_filter(table: str) -> str:
    return f"SELECT * FROM `{table}` AS t"


def _no_jobs(_relation: str) -> list[dict]:
    return []


def _jobs_with_filter(parent_relation: str, column: str):
    """Return a callable that yields jobs with SQL filtering on column."""
    from datetime import datetime, timezone, timedelta

    def query(relation: str) -> list[dict]:
        now = datetime.now(timezone.utc)
        return [
            {
                "job_id": f"job_{i}",
                "query": (
                    f"SELECT * FROM `{parent_relation}` AS t "
                    f"WHERE t.{column} = '2024-01-{i:02d}'"
                ),
                "total_bytes_billed": 1_000_000_000,  # 1 GB
                "total_cost": 0.006,
                "creation_time": now - timedelta(days=i),
            }
            for i in range(1, 31)
        ]

    return query


# ── BFS traversal tests ───────────────────────────────────────────────────────

def test_bfs_traverses_3_level_chain():
    nodes = {
        "model.p.stg_events": _node("stg_events", "proj.ds.stg_events"),
        "model.p.int_sessions": _node(
            "int_sessions",
            "proj.ds.int_sessions",
            _sql_with_filter("proj.ds.stg_events", "event_date"),
        ),
        "model.p.fct_revenue": _node(
            "fct_revenue",
            "proj.ds.fct_revenue",
            _sql_with_filter("proj.ds.int_sessions", "event_date"),
        ),
    }
    child_map = {
        "model.p.stg_events": ["model.p.int_sessions"],
        "model.p.int_sessions": ["model.p.fct_revenue"],
        "model.p.fct_revenue": [],
    }
    manifest = _manifest(nodes, child_map)
    analyzer = DownstreamLineageAnalyzer(
        manifest_content=manifest,
        bigquery_jobs_query=_jobs_with_filter("proj.ds.stg_events", "event_date"),
    )
    results = analyzer.compute("stg_events", "event_date", "partition")

    model_names = [r.model_name for r in results]
    assert "int_sessions" in model_names
    assert "fct_revenue" in model_names
    assert len(results) == 2


def test_diamond_dependency_deduplication():
    # stg → A, stg → B, A → C, B → C  (diamond — C seen twice)
    nodes = {
        "model.p.stg": _node("stg", "proj.ds.stg"),
        "model.p.a": _node("a", "proj.ds.a", _sql_with_filter("proj.ds.stg", "dt")),
        "model.p.b": _node("b", "proj.ds.b", _sql_with_filter("proj.ds.stg", "dt")),
        "model.p.c": _node("c", "proj.ds.c", _sql_with_filter("proj.ds.a", "dt")),
    }
    child_map = {
        "model.p.stg": ["model.p.a", "model.p.b"],
        "model.p.a": ["model.p.c"],
        "model.p.b": ["model.p.c"],
        "model.p.c": [],
    }
    manifest = _manifest(nodes, child_map)
    analyzer = DownstreamLineageAnalyzer(
        manifest_content=manifest,
        bigquery_jobs_query=_no_jobs,
    )
    results = analyzer.compute("stg", "dt", "partition")

    names = [r.model_name for r in results]
    # C should appear only once
    assert names.count("c") == 1


def test_model_with_predicate_is_included():
    nodes = {
        "model.p.root": _node("root", "proj.ds.root"),
        "model.p.child": _node(
            "child",
            "proj.ds.child",
            _sql_with_filter("proj.ds.root", "event_date"),
        ),
    }
    child_map = {
        "model.p.root": ["model.p.child"],
        "model.p.child": [],
    }
    manifest = _manifest(nodes, child_map)
    analyzer = DownstreamLineageAnalyzer(
        manifest_content=manifest,
        bigquery_jobs_query=_jobs_with_filter("proj.ds.root", "event_date"),
    )
    results = analyzer.compute("root", "event_date", "partition")

    assert len(results) == 1
    result = results[0]
    assert result.model_name == "child"
    assert result.included is True
    assert result.estimated_monthly_cost_usd is not None
    assert result.estimated_monthly_cost_usd > Decimal("0")


def test_model_without_predicate_is_excluded_with_reason():
    nodes = {
        "model.p.root": _node("root", "proj.ds.root"),
        "model.p.child": _node(
            "child",
            "proj.ds.child",
            _sql_without_filter("proj.ds.root"),
        ),
    }
    child_map = {
        "model.p.root": ["model.p.child"],
        "model.p.child": [],
    }
    manifest = _manifest(nodes, child_map)
    analyzer = DownstreamLineageAnalyzer(
        manifest_content=manifest,
        bigquery_jobs_query=_no_jobs,
    )
    results = analyzer.compute("root", "event_date", "partition")

    assert len(results) == 1
    result = results[0]
    assert result.included is False
    assert "event_date" in result.inclusion_reason


def test_model_with_filter_but_no_job_history():
    nodes = {
        "model.p.root": _node("root", "proj.ds.root"),
        "model.p.child": _node(
            "child",
            "proj.ds.child",
            _sql_with_filter("proj.ds.root", "event_date"),
        ),
    }
    child_map = {
        "model.p.root": ["model.p.child"],
        "model.p.child": [],
    }
    manifest = _manifest(nodes, child_map)
    analyzer = DownstreamLineageAnalyzer(
        manifest_content=manifest,
        bigquery_jobs_query=_no_jobs,  # no history
    )
    results = analyzer.compute("root", "event_date", "partition")

    assert len(results) == 1
    result = results[0]
    # Has filter but no job history → shown in tree, excluded from savings total
    assert result.included is False
    assert "no job history" in result.inclusion_reason.lower()
    assert result.estimated_monthly_cost_usd is None


def test_root_with_no_children_returns_empty_list():
    nodes = {
        "model.p.lonely": _node("lonely", "proj.ds.lonely"),
    }
    child_map = {
        "model.p.lonely": [],
    }
    manifest = _manifest(nodes, child_map)
    analyzer = DownstreamLineageAnalyzer(
        manifest_content=manifest,
        bigquery_jobs_query=_no_jobs,
    )
    results = analyzer.compute("lonely", "event_date", "partition")
    assert results == []


def test_manifest_without_child_map_returns_empty_list():
    nodes = {"model.p.root": _node("root", "proj.ds.root")}
    manifest = {"nodes": nodes}  # no child_map key
    analyzer = DownstreamLineageAnalyzer(
        manifest_content=manifest,
        bigquery_jobs_query=_no_jobs,
    )
    results = analyzer.compute("root", "event_date", "partition")
    assert results == []


def test_empty_manifest_returns_empty_list():
    analyzer = DownstreamLineageAnalyzer(
        manifest_content={},
        bigquery_jobs_query=_no_jobs,
    )
    results = analyzer.compute("root", "event_date", "partition")
    assert results == []


def test_unknown_root_model_returns_empty_list():
    nodes = {"model.p.other": _node("other", "proj.ds.other")}
    child_map = {"model.p.other": []}
    manifest = _manifest(nodes, child_map)
    analyzer = DownstreamLineageAnalyzer(
        manifest_content=manifest,
        bigquery_jobs_query=_no_jobs,
    )
    results = analyzer.compute("nonexistent_model", "event_date", "partition")
    assert results == []


def test_dependency_path_populated_correctly():
    nodes = {
        "model.p.stg": _node("stg", "proj.ds.stg"),
        "model.p.int": _node(
            "int",
            "proj.ds.int",
            _sql_with_filter("proj.ds.stg", "event_date"),
        ),
        "model.p.fct": _node(
            "fct",
            "proj.ds.fct",
            _sql_with_filter("proj.ds.int", "event_date"),
        ),
    }
    child_map = {
        "model.p.stg": ["model.p.int"],
        "model.p.int": ["model.p.fct"],
        "model.p.fct": [],
    }
    manifest = _manifest(nodes, child_map)
    analyzer = DownstreamLineageAnalyzer(
        manifest_content=manifest,
        bigquery_jobs_query=_no_jobs,
    )
    results = analyzer.compute("stg", "event_date", "partition")
    results_by_name = {r.model_name: r for r in results}

    assert results_by_name["int"].dependency_path == ["stg", "int"]
    assert results_by_name["fct"].dependency_path == ["stg", "int", "fct"]


def test_results_sorted_beneficiaries_first():
    nodes = {
        "model.p.root": _node("root", "proj.ds.root"),
        "model.p.a": _node(
            "a",
            "proj.ds.a",
            _sql_with_filter("proj.ds.root", "event_date"),
        ),
        "model.p.b": _node("b", "proj.ds.b", _sql_without_filter("proj.ds.root")),
    }
    child_map = {
        "model.p.root": ["model.p.a", "model.p.b"],
        "model.p.a": [],
        "model.p.b": [],
    }
    manifest = _manifest(nodes, child_map)
    analyzer = DownstreamLineageAnalyzer(
        manifest_content=manifest,
        bigquery_jobs_query=_jobs_with_filter("proj.ds.root", "event_date"),
    )
    results = analyzer.compute("root", "event_date", "partition")

    # Beneficiaries first
    assert results[0].model_name == "a"
    assert results[1].model_name == "b"


def test_non_model_children_skipped():
    # Seeds, sources, tests start with seed., source., test. — not model.
    nodes = {
        "model.p.root": _node("root", "proj.ds.root"),
    }
    child_map = {
        "model.p.root": [
            "seed.p.some_seed",
            "source.p.some_source",
            "test.p.some_test",
        ],
    }
    manifest = _manifest(nodes, child_map)
    analyzer = DownstreamLineageAnalyzer(
        manifest_content=manifest,
        bigquery_jobs_query=_no_jobs,
    )
    results = analyzer.compute("root", "event_date", "partition")
    assert results == []


# ── build_summary helpers ─────────────────────────────────────────────────────

class _FakePR:
    def __init__(self, status: str = "merged"):
        self.id = "pr-123"
        self.status = status


class _FakeManifestVersion:
    id = "mv-456"


def test_build_summary_from_results_open_pr_is_projected():
    pr = _FakePR(status="open")
    mv = _FakeManifestVersion()
    summary = build_summary_from_results(
        pr=pr,
        manifest_version=mv,
        results=[],
        affected_column="event_date",
        change_type="partition",
        root_model_name="stg_events",
    )
    assert summary.is_projected is True
    assert summary.beneficiary_count == 0
    assert summary.total_estimated_savings == Decimal("0")


def test_build_summary_from_results_merged_pr_not_projected():
    pr = _FakePR(status="merged")
    mv = _FakeManifestVersion()
    summary = build_summary_from_results(
        pr=pr,
        manifest_version=mv,
        results=[],
        affected_column="event_date",
        change_type="partition",
        root_model_name="stg_events",
    )
    assert summary.is_projected is False


def test_build_summary_from_cached():
    from governor_core.pullrequests.lineage_impact import build_summary

    class FakeCached:
        affected_model_name = "stg_events"
        affected_column = "event_date"
        change_type = "partition"
        total_estimated_savings = Decimal("42.00")
        beneficiary_count = 2
        total_downstream_count = 5
        impact_results = [
            {
                "model_name": "fct_revenue",
                "relation_name": "proj.ds.fct_revenue",
                "dependency_path": ["stg_events", "fct_revenue"],
                "depth": 1,
                "included": True,
                "inclusion_reason": "WHERE on `event_date`",
                "expression_type": "WHERE",
                "estimated_bytes_saved_per_run": 1000000,
                "estimated_monthly_cost_usd": 42.0,
                "confidence": "high",
                "jobs_analyzed": 30,
                "run_frequency_per_day": 2.0,
            }
        ]

    pr = _FakePR(status="merged")
    summary = build_summary(cached=FakeCached(), pr=pr)

    assert summary.pr_id == "pr-123"
    assert summary.beneficiary_count == 2
    assert summary.total_estimated_savings == Decimal("42.00")
    assert len(summary.results) == 1
    assert summary.results[0].model_name == "fct_revenue"
    assert summary.results[0].estimated_monthly_cost_usd == Decimal("42.0")
    assert summary.is_projected is False
