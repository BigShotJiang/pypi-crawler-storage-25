"""Unit tests for recommendation state resolution (spec 105)."""

from governor_core.opportunities.recommendation_state import resolve_state


class TestResolveState:
    """Tests for resolve_state() covering all 5 states and precedence."""

    def test_ready_when_has_solutions(self):
        result = resolve_state(
            opportunity_status="active",
            cascade_status=None,
            solution_job_status=None,
            has_solutions=True,
            has_pr=False,
            job_permanently_failed=False,
        )
        assert result.key == "ready"

    def test_ready_when_has_pr(self):
        result = resolve_state(
            opportunity_status="active",
            cascade_status=None,
            solution_job_status=None,
            has_solutions=False,
            has_pr=True,
            job_permanently_failed=False,
        )
        assert result.key == "ready"

    def test_generating_when_queued(self):
        result = resolve_state(
            opportunity_status="active",
            cascade_status=None,
            solution_job_status="queued",
            has_solutions=False,
            has_pr=False,
            job_permanently_failed=False,
        )
        assert result.key == "generating"
        assert result.pulse is True

    def test_generating_when_in_progress(self):
        result = resolve_state(
            opportunity_status="active",
            cascade_status=None,
            solution_job_status="in_progress",
            has_solutions=False,
            has_pr=False,
            job_permanently_failed=False,
        )
        assert result.key == "generating"

    def test_upstream_fix_when_delegated(self):
        result = resolve_state(
            opportunity_status="active",
            cascade_status="delegated",
            solution_job_status=None,
            has_solutions=False,
            has_pr=False,
            job_permanently_failed=False,
        )
        assert result.key == "upstream_fix"
        assert result.label == "Upstream fix"
        assert result.dot_color == "amber"

    def test_failed_when_permanently_failed(self):
        result = resolve_state(
            opportunity_status="active",
            cascade_status=None,
            solution_job_status=None,
            has_solutions=False,
            has_pr=False,
            job_permanently_failed=True,
        )
        assert result.key == "failed"
        assert result.dot_color == "red"

    def test_awaiting_default(self):
        result = resolve_state(
            opportunity_status="active",
            cascade_status=None,
            solution_job_status=None,
            has_solutions=False,
            has_pr=False,
            job_permanently_failed=False,
        )
        assert result.key == "awaiting"
        assert result.label == "Awaiting"

    # --- Precedence tests ---

    def test_ready_beats_generating(self):
        """If solutions exist, state is ready even with active job."""
        result = resolve_state(
            opportunity_status="active",
            cascade_status=None,
            solution_job_status="in_progress",
            has_solutions=True,
            has_pr=False,
            job_permanently_failed=False,
        )
        assert result.key == "ready"

    def test_generating_beats_upstream_fix(self):
        """Active generation takes priority over cascade delegation."""
        result = resolve_state(
            opportunity_status="active",
            cascade_status="delegated",
            solution_job_status="queued",
            has_solutions=False,
            has_pr=False,
            job_permanently_failed=False,
        )
        assert result.key == "generating"

    def test_upstream_fix_beats_failed(self):
        """Cascade delegation takes priority over failed status."""
        result = resolve_state(
            opportunity_status="active",
            cascade_status="delegated",
            solution_job_status=None,
            has_solutions=False,
            has_pr=False,
            job_permanently_failed=True,
        )
        assert result.key == "upstream_fix"

    def test_clearing_status_returns_ready(self):
        """Clearing has its own UI — resolve_state returns ready sentinel."""
        result = resolve_state(
            opportunity_status="clearing",
            cascade_status=None,
            solution_job_status=None,
            has_solutions=False,
            has_pr=False,
            job_permanently_failed=False,
        )
        assert result.key == "ready"

    def test_cascade_root_status_not_delegated(self):
        """Root opportunity (cascade_status='root') is NOT delegated."""
        result = resolve_state(
            opportunity_status="active",
            cascade_status="root",
            solution_job_status=None,
            has_solutions=False,
            has_pr=False,
            job_permanently_failed=False,
        )
        assert result.key == "awaiting"

    def test_state_info_is_frozen(self):
        """StateInfo instances should be immutable."""
        result = resolve_state(
            opportunity_status="active",
            cascade_status=None,
            solution_job_status=None,
            has_solutions=False,
            has_pr=False,
            job_permanently_failed=False,
        )
        try:
            result.key = "hacked"
            assert False, "Should not be able to modify frozen dataclass"
        except AttributeError:
            pass  # Expected — frozen dataclass
