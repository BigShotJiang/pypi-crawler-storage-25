"""Unit tests for app/solutions/templates/remove_redundant_order_bys.py."""

from types import SimpleNamespace

from governor_core.solutions.templates.remove_redundant_order_bys import (
    RemoveRedundantOrderBysTemplate,
    _remove_order_by_from_cte,
)


def _make_opportunity(evidence: dict | None = None):
    return SimpleNamespace(
        id="opp-1",
        opportunity_type="redundant_order_by",
        evidence_snapshot=evidence or {},
        dbt_model_name="my_model",
        affected_table="project.dataset.my_model",
    )


class TestRemoveOrderByFromCte:
    def test_removes_top_level_order_by(self):
        sql = (
            "WITH\n"
            "  base AS (\n"
            "    SELECT id, created_at\n"
            "    FROM raw_events\n"
            "    ORDER BY created_at DESC\n"
            "  ),\n"
            "  final AS (\n"
            "    SELECT id FROM base\n"
            "  )\n"
            "SELECT id FROM final\n"
        )

        result = _remove_order_by_from_cte(sql, "base")

        assert result is not None
        assert "ORDER BY created_at DESC" not in result
        assert "FROM raw_events" in result
        assert "final AS" in result

    def test_unknown_cte_returns_none(self):
        sql = "WITH base AS (SELECT id FROM raw_events) SELECT id FROM base"

        assert _remove_order_by_from_cte(sql, "missing") is None


class TestRemoveRedundantOrderBysTemplate:
    def test_matches_requires_ctes_and_source_file(self):
        template = RemoveRedundantOrderBysTemplate()
        opp = _make_opportunity({"redundant_order_bys": ["base"]})

        assert (
            template.matches(
                opp,
                {"models/marts/test.sql": "select 1"},
                {"original_file_path": "models/marts/test.sql"},
            )
            is True
        )

    def test_apply_removes_redundant_order_by(self):
        template = RemoveRedundantOrderBysTemplate()
        sql = (
            "WITH\n"
            "  base AS (\n"
            "    SELECT id, created_at\n"
            "    FROM raw_events\n"
            "    ORDER BY created_at DESC\n"
            "  ),\n"
            "  final AS (\n"
            "    SELECT id FROM base\n"
            "  )\n"
            "SELECT id FROM final\n"
        )
        opp = _make_opportunity({"redundant_order_bys": ["base"]})

        result = template.apply(
            opp,
            {"models/marts/test.sql": sql},
            {"original_file_path": "models/marts/test.sql", "name": "test"},
        )

        assert result is not None
        assert result.template_id == "remove_redundant_order_bys"
        assert "ORDER BY" not in result.after_content
        assert "SELECT id FROM final" in result.after_content
        assert result.parameters["redundant_order_bys"] == ["base"]
