"""Unit tests for shadow terminal rendering."""

from __future__ import annotations

from governor_core.shadow.diff import ModelMetric, compute_deltas
from governor_core.shadow.terminal import (
    render_comparison,
    render_failure_message,
    render_skip_message,
)


def test_render_comparison_contains_totals_and_parity():
    baseline = [
        ModelMetric("a", bytes_processed=10_000_000, slot_ms=5_000, row_count=100)
    ]
    shadow = [
        ModelMetric("a", bytes_processed=6_000_000, slot_ms=3_000, row_count=100)
    ]
    diff = compute_deltas(baseline, shadow)
    out = render_comparison(diff)
    assert "a" in out
    assert "baseline" in out
    assert "shadow" in out
    assert "Total" in out
    assert "Delta" in out
    assert "✓" in out  # parity marker


def test_render_skip_message():
    out = render_skip_message("cascade_too_large", "45 > 20")
    assert "cascade_too_large" in out
    assert "45 > 20" in out


def test_render_failure_message():
    out = render_failure_message("row_count_mismatch", "dim_customers")
    assert "FAILED" in out
    assert "row_count_mismatch" in out
    assert "dim_customers" in out
