"""Tests for TTL cache utility (spec 107)."""

from __future__ import annotations

import time

from governor_core.core.cache import TTLCache


def test_get_returns_none_for_missing_key():
    cache = TTLCache(default_ttl=60)
    assert cache.get("missing") is None


def test_set_and_get():
    cache = TTLCache(default_ttl=60)
    cache.set("key", "value")
    assert cache.get("key") == "value"


def test_ttl_expiry():
    cache = TTLCache(default_ttl=1)
    cache.set("key", "value", ttl=0)
    # TTL of 0 means already expired
    time.sleep(0.05)
    assert cache.get("key") is None


def test_invalidate():
    cache = TTLCache(default_ttl=60)
    cache.set("key", "value")
    cache.invalidate("key")
    assert cache.get("key") is None


def test_invalidate_prefix():
    cache = TTLCache(default_ttl=60)
    cache.set("dashboard:summary", "data1")
    cache.set("dashboard:charts", "data2")
    cache.set("config:list", "data3")
    cache.invalidate_prefix("dashboard:")
    assert cache.get("dashboard:summary") is None
    assert cache.get("dashboard:charts") is None
    assert cache.get("config:list") == "data3"


def test_get_or_set():
    cache = TTLCache(default_ttl=60)
    call_count = 0

    def factory():
        nonlocal call_count
        call_count += 1
        return "computed"

    result1 = cache.get_or_set("key", factory)
    result2 = cache.get_or_set("key", factory)
    assert result1 == "computed"
    assert result2 == "computed"
    assert call_count == 1  # Factory called only once


def test_disabled_cache_always_misses():
    cache = TTLCache(default_ttl=60, enabled=False)
    cache.set("key", "value")
    assert cache.get("key") is None


def test_clear():
    cache = TTLCache(default_ttl=60)
    cache.set("a", 1)
    cache.set("b", 2)
    cache.clear()
    assert cache.get("a") is None
    assert cache.get("b") is None
