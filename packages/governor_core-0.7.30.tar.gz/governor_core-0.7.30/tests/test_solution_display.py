"""Unit tests for solution display logic (spec 050, US3 T031).

Tests the verified vs estimated savings display decisions
independently of Jinja template rendering.
"""

from __future__ import annotations


def _verified_savings_label(
    dry_run_original: dict | None, dry_run_modified: dict | None
) -> str | None:
    """Replicate the template logic for savings display.

    Returns "verified", "estimated", or None.
    """
    if (
        dry_run_original
        and dry_run_modified
        and dry_run_original.get("valid")
        and dry_run_modified.get("valid")
    ):
        savings = (
            dry_run_original["estimated_cost_usd"]
            - dry_run_modified["estimated_cost_usd"]
        )
        if savings > 0:
            return "verified"
    elif dry_run_modified and not dry_run_modified.get("valid"):
        return "estimated"
    return None


class TestSavingsDisplayLogic:
    """Tests for 'Verified Savings' vs 'Estimated Savings' display logic."""

    def test_verified_savings_when_both_dry_runs_succeed(self):
        """Should show 'Verified Savings' when both dry-runs are valid and savings > 0."""
        original = {
            "valid": True,
            "estimated_cost_usd": 14.38,
            "total_bytes_processed": 2_300_000_000_000,
        }
        modified = {
            "valid": True,
            "estimated_cost_usd": 3.21,
            "total_bytes_processed": 513_000_000_000,
        }

        assert _verified_savings_label(original, modified) == "verified"

    def test_estimated_savings_when_dry_run_fails(self):
        """Should show 'Estimated Savings' when dry-run modified is invalid."""
        modified = {"valid": False, "error": "Access Denied"}

        assert _verified_savings_label(None, modified) == "estimated"

    def test_no_label_when_no_dry_run_data(self):
        """Should show nothing when no dry-run data is available."""
        assert _verified_savings_label(None, None) is None

    def test_no_label_when_no_savings(self):
        """Should show nothing when modified cost >= original cost."""
        original = {
            "valid": True,
            "estimated_cost_usd": 3.21,
            "total_bytes_processed": 500_000_000_000,
        }
        modified = {
            "valid": True,
            "estimated_cost_usd": 5.00,
            "total_bytes_processed": 800_000_000_000,
        }

        assert _verified_savings_label(original, modified) is None

    def test_no_label_when_original_invalid(self):
        """Should not show 'Verified' when original dry-run failed."""
        original = {"valid": False, "error": "Permission denied"}
        modified = {
            "valid": True,
            "estimated_cost_usd": 3.21,
            "total_bytes_processed": 500_000_000_000,
        }

        assert _verified_savings_label(original, modified) is None

    def test_verified_savings_calculation(self):
        """Savings should be original_cost - modified_cost."""
        original = {
            "valid": True,
            "estimated_cost_usd": 14.38,
            "total_bytes_processed": 0,
        }
        modified = {
            "valid": True,
            "estimated_cost_usd": 3.21,
            "total_bytes_processed": 0,
        }

        # Verify the calculation: 14.38 - 3.21 = 11.17
        savings = original["estimated_cost_usd"] - modified["estimated_cost_usd"]
        assert abs(savings - 11.17) < 0.01

    def test_estimated_label_when_modified_has_error(self):
        """Should show estimated when modified SQL is invalid (compilation error)."""
        original = {
            "valid": True,
            "estimated_cost_usd": 10.0,
            "total_bytes_processed": 0,
        }
        modified = {"valid": False, "error": "Syntax error at position 42"}

        assert _verified_savings_label(original, modified) == "estimated"
