from decimal import Decimal

from governor_core.opportunities.scoring import estimate_cost_from_bytes_processed


def test_estimate_cost_from_bytes_processed_uses_tib_pricing():
    assert estimate_cost_from_bytes_processed(1024**4) == Decimal("6.25")
