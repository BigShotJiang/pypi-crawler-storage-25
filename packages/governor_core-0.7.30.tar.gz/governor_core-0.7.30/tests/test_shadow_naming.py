"""Unit tests for shadow naming invariant."""

from __future__ import annotations

import uuid

import pytest

from governor_core.shadow.exceptions import ShadowInvariantViolation
from governor_core.shadow.naming import (
    enforce_shadow_name,
    mint_shadow_name,
    mint_shadow_suffix,
)


def test_suffix_is_twelve_hex_chars_after_marker():
    suffix = mint_shadow_suffix("550e8400-e29b-41d4-a716-446655440000")
    assert suffix == "__governor_550e8400e29b"
    assert len(suffix) == len("__governor_") + 12


def test_suffix_is_deterministic():
    sid = str(uuid.uuid4())
    assert mint_shadow_suffix(sid) == mint_shadow_suffix(sid)


def test_suffix_is_unique_per_solution():
    a = mint_shadow_suffix(str(uuid.uuid4()))
    b = mint_shadow_suffix(str(uuid.uuid4()))
    assert a != b


def test_mint_name_appends_suffix():
    sid = "550e8400-e29b-41d4-a716-446655440000"
    assert (
        mint_shadow_name("fct_orders", sid)
        == "fct_orders__governor_550e8400e29b"
    )


def test_mint_name_truncates_long_base():
    sid = "550e8400-e29b-41d4-a716-446655440000"
    very_long = "a" * 300
    result = mint_shadow_name(very_long, sid)
    assert result.endswith("__governor_550e8400e29b")
    assert len(result) <= 240


def test_enforce_accepts_name_with_suffix():
    sid = "550e8400-e29b-41d4-a716-446655440000"
    # Should not raise
    enforce_shadow_name("fct_orders__governor_550e8400e29b", sid)
    enforce_shadow_name("x__governor_550e8400e29b_tmp", sid)


def test_enforce_rejects_name_without_suffix():
    sid = "550e8400-e29b-41d4-a716-446655440000"
    with pytest.raises(ShadowInvariantViolation):
        enforce_shadow_name("fct_orders", sid)


def test_enforce_rejects_wrong_solution_suffix():
    sid = "550e8400-e29b-41d4-a716-446655440000"
    other = "999e8400-e29b-41d4-a716-446655440000"
    # Shadow name minted for `other` must not be accepted under `sid`'s guard
    wrong = mint_shadow_name("fct_orders", other)
    with pytest.raises(ShadowInvariantViolation):
        enforce_shadow_name(wrong, sid)
