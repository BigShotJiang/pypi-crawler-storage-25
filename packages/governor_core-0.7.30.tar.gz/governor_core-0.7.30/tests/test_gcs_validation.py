from __future__ import annotations

from unittest.mock import MagicMock, patch

import pytest
from google.cloud.exceptions import GoogleCloudError

from governor_core.gcp.clients import (
    GCPCredentialsError,
    get_storage_client,
    list_gcp_projects,
    validate_gcs_manifest,
)


# --- list_gcp_projects ---


def test_list_gcp_projects_success():
    mock_project = MagicMock()
    mock_project.project_id = "proj-1"
    mock_project.display_name = "Project One"

    mock_client = MagicMock()
    mock_client.search_projects.return_value = [mock_project]

    with patch("governor_core.gcp.clients.get_resource_manager_client", return_value=mock_client):
        result = list_gcp_projects()

    assert result == [{"project_id": "proj-1", "display_name": "Project One"}]


def test_list_gcp_projects_empty():
    mock_client = MagicMock()
    mock_client.search_projects.return_value = []

    with patch("governor_core.gcp.clients.get_resource_manager_client", return_value=mock_client):
        result = list_gcp_projects()

    assert result == []


def test_list_gcp_projects_empty_display_name():
    mock_project = MagicMock()
    mock_project.project_id = "proj-2"
    mock_project.display_name = ""

    mock_client = MagicMock()
    mock_client.search_projects.return_value = [mock_project]

    with patch("governor_core.gcp.clients.get_resource_manager_client", return_value=mock_client):
        result = list_gcp_projects()

    assert result == [{"project_id": "proj-2", "display_name": ""}]


def test_list_gcp_projects_credentials_error():
    with patch(
        "governor_core.gcp.clients.get_resource_manager_client",
        side_effect=GCPCredentialsError("no creds"),
    ):
        with pytest.raises(GCPCredentialsError):
            list_gcp_projects()


def test_list_gcp_projects_permission_denied():
    from google.api_core.exceptions import PermissionDenied

    mock_client = MagicMock()
    mock_client.search_projects.side_effect = PermissionDenied("forbidden")

    with patch("governor_core.gcp.clients.get_resource_manager_client", return_value=mock_client):
        with pytest.raises(PermissionDenied):
            list_gcp_projects()


# --- get_storage_client ---


def test_get_storage_client_success():
    with patch("governor_core.gcp.clients.google.auth.default") as mock_default:
        mock_default.return_value = ("mock_creds", "mock_project")
        with patch("google.cloud.storage.Client") as mock_client_cls:
            client = get_storage_client()
            mock_client_cls.assert_called_once_with(credentials="mock_creds")
            assert client == mock_client_cls.return_value


def test_get_storage_client_missing_credentials():
    from google.auth.exceptions import DefaultCredentialsError

    with patch("governor_core.gcp.clients.google.auth.default") as mock_default:
        mock_default.side_effect = DefaultCredentialsError("no creds")
        with pytest.raises(GCPCredentialsError, match="GCP credentials not configured"):
            get_storage_client()


# --- validate_gcs_manifest ---


def test_validate_gcs_manifest_success():
    mock_bucket = MagicMock()
    mock_bucket.exists.return_value = True
    mock_blob = MagicMock()
    mock_blob.exists.return_value = True
    mock_bucket.blob.return_value = mock_blob

    mock_client = MagicMock()
    mock_client.bucket.return_value = mock_bucket

    with patch("governor_core.gcp.clients.get_storage_client", return_value=mock_client):
        result = validate_gcs_manifest("my-bucket", "", "manifest.json")

    assert result.valid is True
    assert result.error is None


def test_validate_gcs_manifest_with_path_prefix():
    mock_bucket = MagicMock()
    mock_bucket.exists.return_value = True
    mock_blob = MagicMock()
    mock_blob.exists.return_value = True
    mock_bucket.blob.return_value = mock_blob

    mock_client = MagicMock()
    mock_client.bucket.return_value = mock_bucket

    with patch("governor_core.gcp.clients.get_storage_client", return_value=mock_client):
        result = validate_gcs_manifest("my-bucket", "path/to", "manifest.json")

    assert result.valid is True
    mock_bucket.blob.assert_called_once_with("path/to/manifest.json")


def test_validate_gcs_manifest_bucket_not_found():
    mock_bucket = MagicMock()
    mock_bucket.exists.return_value = False

    mock_client = MagicMock()
    mock_client.bucket.return_value = mock_bucket

    with patch("governor_core.gcp.clients.get_storage_client", return_value=mock_client):
        result = validate_gcs_manifest("nonexistent-bucket", "", "manifest.json")

    assert result.valid is False
    assert "does not exist" in result.error


def test_validate_gcs_manifest_bucket_access_error():
    mock_bucket = MagicMock()
    mock_bucket.exists.side_effect = GoogleCloudError("access denied")

    mock_client = MagicMock()
    mock_client.bucket.return_value = mock_bucket

    with patch("governor_core.gcp.clients.get_storage_client", return_value=mock_client):
        result = validate_gcs_manifest("bad-bucket", "", "manifest.json")

    assert result.valid is False
    assert "Cannot access bucket" in result.error


def test_validate_gcs_manifest_file_not_found():
    mock_bucket = MagicMock()
    mock_bucket.exists.return_value = True
    mock_blob = MagicMock()
    mock_blob.exists.return_value = False
    mock_bucket.blob.return_value = mock_blob

    mock_client = MagicMock()
    mock_client.bucket.return_value = mock_bucket

    with patch("governor_core.gcp.clients.get_storage_client", return_value=mock_client):
        result = validate_gcs_manifest("my-bucket", "", "manifest.json")

    assert result.valid is False
    assert "not found" in result.error


def test_validate_gcs_manifest_credentials_error():
    with patch(
        "governor_core.gcp.clients.get_storage_client",
        side_effect=GCPCredentialsError("no creds"),
    ):
        result = validate_gcs_manifest("my-bucket", "", "manifest.json")

    assert result.valid is False
    assert "credentials" in result.error.lower()
