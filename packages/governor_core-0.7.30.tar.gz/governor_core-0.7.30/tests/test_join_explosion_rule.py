"""
Unit tests for JoinExplosionRule.

Tests join explosion detection from BigQuery high_cardinality_joins.
"""

from decimal import Decimal
from unittest.mock import MagicMock


from governor_core.opportunities.rules.join_explosion import JoinExplosionRule


class TestJoinExplosionRule:
    """Tests for join explosion detection."""

    def test_rule_type(self):
        """Test rule type identifier."""
        rule = JoinExplosionRule()
        assert rule.rule_type == "join_explosion"

    def test_default_thresholds(self):
        """Test default threshold configuration."""
        rule = JoinExplosionRule()
        thresholds = rule.default_thresholds

        assert thresholds["row_multiplication_threshold"] == 10
        assert thresholds["min_job_cost_usd"] == Decimal("0")
        assert thresholds["min_output_rows"] == 100000

    def test_detect_with_high_cardinality_join(self):
        """Test detection of high cardinality join."""
        rule = JoinExplosionRule()

        job = MagicMock()
        job.destination_table = "project.dataset.test_table"
        job.total_cost = Decimal("5.00")
        job.job_id = "job-123"
        job.performance_insights = {
            "stage_performance_standalone_insights": [
                {
                    "stage_id": 6,
                    "high_cardinality_joins": [
                        {
                            "left_rows": 100000,
                            "right_rows": 50000,
                            "output_rows": 5000000,  # 50x multiplication
                            "step_index": 5,
                        }
                    ],
                }
            ]
        }

        candidates = rule.detect([job], None, rule.default_thresholds)

        assert len(candidates) == 1
        candidate = candidates[0]
        assert candidate.opportunity_type == "join_explosion"
        assert candidate.affected_table == "project.dataset.test_table"
        assert candidate.evidence_snapshot["left_rows"] == 100000
        assert candidate.evidence_snapshot["right_rows"] == 50000
        assert candidate.evidence_snapshot["output_rows"] == 5000000
        assert candidate.evidence_snapshot["multiplication_ratio"] == 50.0
        assert candidate.confidence == 1.0

    def test_detect_no_explosion_below_threshold(self):
        """Test no detection when ratio is below threshold."""
        rule = JoinExplosionRule()

        job = MagicMock()
        job.destination_table = "project.dataset.test_table"
        job.total_cost = Decimal("1.00")
        job.job_id = "job-123"
        job.performance_insights = {
            "stage_performance_standalone_insights": [
                {
                    "stage_id": 1,
                    "high_cardinality_joins": [
                        {
                            "left_rows": 100000,
                            "right_rows": 50000,
                            "output_rows": 500000,  # 5x multiplication (below 10x)
                            "step_index": 1,
                        }
                    ],
                }
            ]
        }

        candidates = rule.detect([job], None, rule.default_thresholds)
        assert len(candidates) == 0

    def test_detect_ignores_small_result_sets(self):
        """Test that small result sets are ignored."""
        rule = JoinExplosionRule()

        job = MagicMock()
        job.destination_table = "project.dataset.test_table"
        job.total_cost = Decimal("1.00")
        job.job_id = "job-123"
        job.performance_insights = {
            "stage_performance_standalone_insights": [
                {
                    "stage_id": 1,
                    "high_cardinality_joins": [
                        {
                            "left_rows": 1000,
                            "right_rows": 500,
                            "output_rows": 50000,  # 50x but only 50K rows
                            "step_index": 1,
                        }
                    ],
                }
            ]
        }

        candidates = rule.detect([job], None, rule.default_thresholds)
        assert len(candidates) == 0

    def test_detect_picks_worst_join(self):
        """Test that worst join (highest ratio) is reported."""
        rule = JoinExplosionRule()

        job = MagicMock()
        job.destination_table = "project.dataset.test_table"
        job.total_cost = Decimal("5.00")
        job.job_id = "job-123"
        job.performance_insights = {
            "stage_performance_standalone_insights": [
                {
                    "stage_id": 1,
                    "high_cardinality_joins": [
                        {
                            "left_rows": 100000,
                            "right_rows": 50000,
                            "output_rows": 2000000,  # 20x
                            "step_index": 1,
                        }
                    ],
                },
                {
                    "stage_id": 2,
                    "high_cardinality_joins": [
                        {
                            "left_rows": 100000,
                            "right_rows": 50000,
                            "output_rows": 10000000,  # 100x (worst)
                            "step_index": 2,
                        }
                    ],
                },
            ]
        }

        candidates = rule.detect([job], None, rule.default_thresholds)

        assert len(candidates) == 1
        candidate = candidates[0]
        # Should report the 100x join, not the 20x one
        assert candidate.evidence_snapshot["multiplication_ratio"] == 100.0
        assert candidate.evidence_snapshot["output_rows"] == 10000000

    def test_explanation_is_actionable(self):
        """Test that explanation includes actionable guidance."""
        rule = JoinExplosionRule()

        job = MagicMock()
        job.destination_table = "project.dataset.test_table"
        job.total_cost = Decimal("5.00")
        job.job_id = "job-123"
        job.performance_insights = {
            "stage_performance_standalone_insights": [
                {
                    "stage_id": 1,
                    "high_cardinality_joins": [
                        {
                            "left_rows": 100000,
                            "right_rows": 50000,
                            "output_rows": 5000000,
                            "step_index": 1,
                        }
                    ],
                }
            ]
        }

        candidates = rule.detect([job], None, rule.default_thresholds)

        assert len(candidates) == 1
        explanation = candidates[0].explanation

        # Check for actionable content
        assert "100,000" in explanation  # Formatted numbers
        assert "50,000" in explanation
        assert "5,000,000" in explanation
        assert "join condition" in explanation.lower()
        assert "duplicate" in explanation.lower() or "cross join" in explanation.lower()

    def test_row_multiplication_ratio_calculation(self):
        """Test ratio calculation for row multiplication."""
        rule = JoinExplosionRule()

        job = MagicMock()
        job.destination_table = "project.dataset.test_table"
        job.total_cost = Decimal("5.00")
        job.job_id = "job-123"
        job.performance_insights = {
            "stage_performance_standalone_insights": [
                {
                    "stage_id": 1,
                    "high_cardinality_joins": [
                        {
                            "left_rows": 50000,  # Use smaller left_rows
                            "right_rows": 100000,
                            "output_rows": 2500000,  # 50x the left_rows
                            "step_index": 1,
                        }
                    ],
                }
            ]
        }

        candidates = rule.detect([job], None, rule.default_thresholds)

        assert len(candidates) == 1
        # Ratio should be output_rows / left_rows = 2500000 / 50000 = 50
        assert candidates[0].evidence_snapshot["multiplication_ratio"] == 50.0
