from __future__ import annotations

import subprocess
from unittest.mock import patch

import pytest

from governor_core.workspace.picker import (
    FolderPickerCancelledError,
    FolderPickerError,
    FolderPickerUnsupportedError,
    pick_local_project_folder,
)


def test_pick_local_project_folder_uses_macos_osascript():
    completed = subprocess.CompletedProcess(
        args=["osascript"],
        returncode=0,
        stdout="/Users/test/src/my-dbt-project/\n",
        stderr="",
    )

    with (
        patch("governor_core.workspace.picker.platform.system", return_value="Darwin"),
        patch(
            "governor_core.workspace.picker.subprocess.run", return_value=completed
        ) as mock_run,
    ):
        selected = pick_local_project_folder()

    assert selected == "/Users/test/src/my-dbt-project"
    command = mock_run.call_args.args[0]
    assert command[0] == "osascript"
    assert "choose folder" in command[-1]


def test_pick_local_project_folder_uses_windows_powershell():
    completed = subprocess.CompletedProcess(
        args=["powershell.exe"],
        returncode=0,
        stdout="C:\\Users\\test\\src\\my-dbt-project\r\n",
        stderr="",
    )

    with (
        patch("governor_core.workspace.picker.platform.system", return_value="Windows"),
        patch(
            "governor_core.workspace.picker.subprocess.run", return_value=completed
        ) as mock_run,
    ):
        selected = pick_local_project_folder()

    assert selected == "C:\\Users\\test\\src\\my-dbt-project"
    command = mock_run.call_args.args[0]
    assert command[0] == "powershell.exe"
    assert "-STA" in command


def test_pick_local_project_folder_rejects_unsupported_platform():
    with patch("governor_core.workspace.picker.platform.system", return_value="Linux"):
        with pytest.raises(FolderPickerUnsupportedError, match="not supported"):
            pick_local_project_folder()


def test_pick_local_project_folder_maps_cancelled_picker():
    completed = subprocess.CompletedProcess(
        args=["osascript"],
        returncode=1,
        stdout="",
        stderr="User canceled.",
    )

    with (
        patch("governor_core.workspace.picker.platform.system", return_value="Darwin"),
        patch("governor_core.workspace.picker.subprocess.run", return_value=completed),
    ):
        with pytest.raises(
            FolderPickerCancelledError,
            match="Folder selection was cancelled",
        ):
            pick_local_project_folder()


def test_pick_local_project_folder_maps_missing_native_binary():
    with (
        patch("governor_core.workspace.picker.platform.system", return_value="Darwin"),
        patch(
            "governor_core.workspace.picker.subprocess.run",
            side_effect=FileNotFoundError("osascript not found"),
        ),
    ):
        with pytest.raises(FolderPickerError, match="unavailable"):
            pick_local_project_folder()
