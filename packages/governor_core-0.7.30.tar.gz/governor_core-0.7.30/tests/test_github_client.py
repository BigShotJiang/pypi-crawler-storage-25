"""Unit tests for GitHub App client."""

from __future__ import annotations

from unittest.mock import MagicMock, patch

import pytest

from governor_core.github.client import (
    GitHubAppClient,
    GitHubAppInfo,
    GitHubAppSuspendedError,
    GitHubAuthenticationError,
    GitHubConfigurationError,
    GitHubConnectionError,
    GitHubFileNotFoundError,
    GitHubRateLimitError,
)


class TestGitHubAppClientInit:
    """Tests for GitHubAppClient initialization."""

    def test_init_success(self):
        """Client initializes with valid credentials."""
        valid_key = """-----BEGIN RSA PRIVATE KEY-----
MIIEpAIBAAKCAQEA0Z3VS5JJcds3xfn/ygWyF8PbnGy0AHB7MmE
-----END RSA PRIVATE KEY-----"""
        with patch("github.Auth.AppAuth") as mock_auth:
            with patch("github.GithubIntegration") as mock_integration:
                client = GitHubAppClient(
                    app_id="123456",
                    private_key=valid_key,
                    installation_id="789",
                )
                mock_auth.assert_called_once_with(123456, valid_key)
                mock_integration.assert_called_once()
                assert client._app_id == "123456"
                assert client._installation_id == "789"

    def test_init_malformed_key_no_pem_header(self):
        """Client raises error for key without PEM header."""
        invalid_key = "not a valid key"
        with pytest.raises(GitHubConfigurationError, match="private key is malformed"):
            GitHubAppClient(
                app_id="123456",
                private_key=invalid_key,
                installation_id="789",
            )

    def test_init_key_validation_error(self):
        """Client raises error when PyGithub rejects the key."""
        valid_looking_key = """-----BEGIN RSA PRIVATE KEY-----
invalid base64 content that will fail parsing
-----END RSA PRIVATE KEY-----"""
        with patch("github.Auth.AppAuth") as mock_auth:
            mock_auth.side_effect = ValueError("Invalid key format")
            with pytest.raises(GitHubConfigurationError, match="malformed"):
                GitHubAppClient(
                    app_id="123456",
                    private_key=valid_looking_key,
                    installation_id="789",
                )


class TestVerifyAppConnectivity:
    """Tests for verify_app_connectivity method."""

    def _create_client(self):
        """Create a client with mocked initialization."""
        valid_key = """-----BEGIN RSA PRIVATE KEY-----
MIIEpAIBAAKCAQEA0Z3VS5JJcds3xfn/ygWyF8PbnGy0AHB7MmE
-----END RSA PRIVATE KEY-----"""
        with patch("github.Auth.AppAuth"):
            with patch("github.GithubIntegration") as mock_integration:
                client = GitHubAppClient(
                    app_id="123456",
                    private_key=valid_key,
                    installation_id="789",
                )
                # Return the mock so tests can configure it
                return client, mock_integration.return_value

    def test_verify_success(self):
        """Successfully verifies app connectivity and returns app info."""
        client, mock_integration = self._create_client()

        mock_app = MagicMock()
        mock_app.id = 123456
        mock_app.name = "Governor Test App"
        mock_app.slug = "governor-test-app"
        mock_app.owner.login = "test-org"
        mock_integration.get_app.return_value = mock_app

        result = client.verify_app_connectivity()

        assert isinstance(result, GitHubAppInfo)
        assert result.id == 123456
        assert result.name == "Governor Test App"
        assert result.slug == "governor-test-app"
        assert result.owner == "test-org"

    def test_verify_success_no_owner(self):
        """Handles app with no owner gracefully."""
        client, mock_integration = self._create_client()

        mock_app = MagicMock()
        mock_app.id = 123456
        mock_app.name = "Governor Test App"
        mock_app.slug = "governor-test-app"
        mock_app.owner = None
        mock_integration.get_app.return_value = mock_app

        result = client.verify_app_connectivity()

        assert result.owner == ""

    def test_verify_bad_credentials(self):
        """Raises authentication error on bad credentials."""
        from github import BadCredentialsException

        client, mock_integration = self._create_client()
        mock_integration.get_app.side_effect = BadCredentialsException(
            status=401, data={"message": "Bad credentials"}
        )

        with pytest.raises(GitHubAuthenticationError, match="authentication failed"):
            client.verify_app_connectivity()

    def test_verify_rate_limited(self):
        """Raises rate limit error when rate limited."""
        from github import RateLimitExceededException

        client, mock_integration = self._create_client()
        mock_integration.get_app.side_effect = RateLimitExceededException(
            status=403, data={"message": "API rate limit exceeded"}
        )

        with pytest.raises(GitHubRateLimitError, match="rate limit exceeded"):
            client.verify_app_connectivity()

    def test_verify_app_suspended(self):
        """Raises suspended error when app is suspended."""
        from github import GithubException

        client, mock_integration = self._create_client()
        mock_integration.get_app.side_effect = GithubException(
            status=403, data={"message": "This GitHub App has been suspended"}
        )

        with pytest.raises(GitHubAppSuspendedError, match="suspended"):
            client.verify_app_connectivity()

    def test_verify_generic_403(self):
        """Raises authentication error on generic 403."""
        from github import GithubException

        client, mock_integration = self._create_client()
        mock_integration.get_app.side_effect = GithubException(
            status=403, data={"message": "Forbidden"}
        )

        with pytest.raises(GitHubAuthenticationError, match="access denied"):
            client.verify_app_connectivity()

    def test_verify_network_error(self):
        """Raises connection error on network failure."""
        from urllib.error import URLError

        client, mock_integration = self._create_client()
        mock_integration.get_app.side_effect = URLError("Network unreachable")

        with pytest.raises(GitHubConnectionError, match="Unable to connect"):
            client.verify_app_connectivity()

    def test_verify_timeout_error(self):
        """Raises connection error on timeout."""
        import socket

        client, mock_integration = self._create_client()
        mock_integration.get_app.side_effect = socket.timeout("Connection timed out")

        with pytest.raises(GitHubConnectionError, match="Unable to connect"):
            client.verify_app_connectivity()

    def test_verify_other_github_exception(self):
        """Raises connection error on other GitHub exceptions."""
        from github import GithubException

        client, mock_integration = self._create_client()
        mock_integration.get_app.side_effect = GithubException(
            status=500, data={"message": "Internal Server Error"}
        )

        with pytest.raises(GitHubConnectionError, match="GitHub API error"):
            client.verify_app_connectivity()


class TestGetFileContent:
    """Tests for get_file_content method."""

    def _create_client(self):
        """Create a client with mocked initialization."""
        valid_key = """-----BEGIN RSA PRIVATE KEY-----
MIIEpAIBAAKCAQEA0Z3VS5JJcds3xfn/ygWyF8PbnGy0AHB7MmE
-----END RSA PRIVATE KEY-----"""
        with patch("github.Auth.AppAuth"):
            with patch("github.GithubIntegration") as mock_integration:
                client = GitHubAppClient(
                    app_id="123456",
                    private_key=valid_key,
                    installation_id="789",
                )
                return client, mock_integration.return_value

    def test_get_file_content_returns_decoded_content(self):
        """get_file_content returns decoded file content."""
        client, mock_integration = self._create_client()

        mock_content = MagicMock()
        mock_content.decoded_content = b"SELECT * FROM orders"

        mock_repo = MagicMock()
        mock_repo.get_contents.return_value = mock_content
        mock_gh = MagicMock()
        mock_gh.get_repo.return_value = mock_repo
        mock_integration.get_github_for_installation.return_value = mock_gh

        result = client.get_file_content("owner/repo", "models/orders.sql")
        assert result == "SELECT * FROM orders"
        mock_repo.get_contents.assert_called_once_with("models/orders.sql")

    def test_get_file_content_with_ref(self):
        """get_file_content passes ref to API."""
        client, mock_integration = self._create_client()

        mock_content = MagicMock()
        mock_content.decoded_content = b"content at ref"

        mock_repo = MagicMock()
        mock_repo.get_contents.return_value = mock_content
        mock_gh = MagicMock()
        mock_gh.get_repo.return_value = mock_repo
        mock_integration.get_github_for_installation.return_value = mock_gh

        result = client.get_file_content("owner/repo", "file.sql", ref="abc123")
        assert result == "content at ref"
        mock_repo.get_contents.assert_called_once_with("file.sql", ref="abc123")

    def test_get_file_content_not_found(self):
        """get_file_content raises GitHubFileNotFoundError for missing file."""
        from github import UnknownObjectException

        client, mock_integration = self._create_client()

        mock_repo = MagicMock()
        mock_repo.get_contents.side_effect = UnknownObjectException(
            status=404, data={"message": "Not Found"}
        )
        mock_gh = MagicMock()
        mock_gh.get_repo.return_value = mock_repo
        mock_integration.get_github_for_installation.return_value = mock_gh

        with pytest.raises(GitHubFileNotFoundError, match="not found"):
            client.get_file_content("owner/repo", "missing.sql")

    def test_get_file_content_directory_raises(self):
        """get_file_content raises error when path is a directory."""
        client, mock_integration = self._create_client()

        mock_repo = MagicMock()
        # get_contents returns a list for directories
        mock_repo.get_contents.return_value = [MagicMock(), MagicMock()]
        mock_gh = MagicMock()
        mock_gh.get_repo.return_value = mock_repo
        mock_integration.get_github_for_installation.return_value = mock_gh

        with pytest.raises(GitHubFileNotFoundError, match="directory"):
            client.get_file_content("owner/repo", "models/")

    def test_get_file_content_rate_limited(self):
        """get_file_content raises GitHubRateLimitError on rate limit."""
        from github import RateLimitExceededException

        client, mock_integration = self._create_client()

        mock_repo = MagicMock()
        mock_repo.get_contents.side_effect = RateLimitExceededException(
            status=403, data={"message": "rate limit"}
        )
        mock_gh = MagicMock()
        mock_gh.get_repo.return_value = mock_repo
        mock_integration.get_github_for_installation.return_value = mock_gh

        with pytest.raises(GitHubRateLimitError):
            client.get_file_content("owner/repo", "file.sql")


class TestGetDirectoryListing:
    """Tests for get_directory_listing method."""

    def _create_client(self):
        """Create a client with mocked initialization."""
        valid_key = """-----BEGIN RSA PRIVATE KEY-----
MIIEpAIBAAKCAQEA0Z3VS5JJcds3xfn/ygWyF8PbnGy0AHB7MmE
-----END RSA PRIVATE KEY-----"""
        with patch("github.Auth.AppAuth"):
            with patch("github.GithubIntegration") as mock_integration:
                client = GitHubAppClient(
                    app_id="123456",
                    private_key=valid_key,
                    installation_id="789",
                )
                return client, mock_integration.return_value

    def test_get_directory_listing_returns_file_paths(self):
        """get_directory_listing returns list of file paths."""
        client, mock_integration = self._create_client()

        mock_items = [MagicMock(path="models/a.sql"), MagicMock(path="models/b.sql")]

        mock_repo = MagicMock()
        mock_repo.get_contents.return_value = mock_items
        mock_gh = MagicMock()
        mock_gh.get_repo.return_value = mock_repo
        mock_integration.get_github_for_installation.return_value = mock_gh

        result = client.get_directory_listing("owner/repo", "models/")
        assert result == ["models/a.sql", "models/b.sql"]

    def test_get_directory_listing_single_file(self):
        """get_directory_listing returns single path if path is a file."""
        client, mock_integration = self._create_client()

        mock_content = MagicMock(path="models/single.sql")

        mock_repo = MagicMock()
        mock_repo.get_contents.return_value = mock_content
        mock_gh = MagicMock()
        mock_gh.get_repo.return_value = mock_repo
        mock_integration.get_github_for_installation.return_value = mock_gh

        result = client.get_directory_listing("owner/repo", "models/single.sql")
        assert result == ["models/single.sql"]

    def test_get_directory_listing_not_found(self):
        """get_directory_listing raises GitHubFileNotFoundError."""
        from github import UnknownObjectException

        client, mock_integration = self._create_client()

        mock_repo = MagicMock()
        mock_repo.get_contents.side_effect = UnknownObjectException(
            status=404, data={"message": "Not Found"}
        )
        mock_gh = MagicMock()
        mock_gh.get_repo.return_value = mock_repo
        mock_integration.get_github_for_installation.return_value = mock_gh

        with pytest.raises(GitHubFileNotFoundError, match="not found"):
            client.get_directory_listing("owner/repo", "missing/")


# ---------------------------------------------------------------------------
# Helper for PR-related tests
# ---------------------------------------------------------------------------


def _make_client():
    """Create a GitHubAppClient with mocked init + installation GitHub."""
    valid_key = """-----BEGIN RSA PRIVATE KEY-----
MIIEpAIBAAKCAQEA0Z3VS5JJcds3xfn/ygWyF8PbnGy0AHB7MmE
-----END RSA PRIVATE KEY-----"""
    with patch("github.Auth.AppAuth"):
        with patch("github.GithubIntegration") as mock_integration:
            client = GitHubAppClient(
                app_id="123456",
                private_key=valid_key,
                installation_id="789",
            )
            mock_gh = MagicMock()
            mock_integration.return_value.get_github_for_installation.return_value = (
                mock_gh
            )
            mock_repo = MagicMock()
            mock_gh.get_repo.return_value = mock_repo
            return client, mock_repo


class TestGetDefaultBranch:
    """Tests for get_default_branch method."""

    def test_returns_default_branch(self):
        client, mock_repo = _make_client()
        mock_repo.default_branch = "main"
        assert client.get_default_branch("owner/repo") == "main"

    def test_returns_master_branch(self):
        client, mock_repo = _make_client()
        mock_repo.default_branch = "master"
        assert client.get_default_branch("owner/repo") == "master"

    def test_auth_error(self):
        from github import BadCredentialsException

        client, mock_repo = _make_client()
        type(mock_repo).default_branch = property(
            lambda self: (_ for _ in ()).throw(
                BadCredentialsException(status=401, data={"message": "Bad"})
            )
        )
        with pytest.raises(GitHubAuthenticationError):
            client.get_default_branch("owner/repo")

    def test_connection_error(self):
        from github import GithubException

        client, mock_repo = _make_client()
        type(mock_repo).default_branch = property(
            lambda self: (_ for _ in ()).throw(
                GithubException(status=500, data={"message": "Error"})
            )
        )
        with pytest.raises(GitHubConnectionError):
            client.get_default_branch("owner/repo")


class TestGetBranchHeadSha:
    """Tests for get_branch_head_sha method."""

    def test_returns_sha(self):
        client, mock_repo = _make_client()
        mock_branch = MagicMock()
        mock_branch.commit.sha = "abc123def456"
        mock_repo.get_branch.return_value = mock_branch
        assert client.get_branch_head_sha("owner/repo", "main") == "abc123def456"
        mock_repo.get_branch.assert_called_once_with("main")

    def test_connection_error(self):
        from github import GithubException

        client, mock_repo = _make_client()
        mock_repo.get_branch.side_effect = GithubException(
            status=500, data={"message": "Error"}
        )
        with pytest.raises(GitHubConnectionError, match="branch HEAD"):
            client.get_branch_head_sha("owner/repo", "main")


class TestCreateBranch:
    """Tests for create_branch method."""

    def test_creates_branch(self):
        client, mock_repo = _make_client()
        mock_ref = MagicMock()
        mock_ref.object.sha = "new-sha-123"
        mock_repo.create_git_ref.return_value = mock_ref

        result = client.create_branch("owner/repo", "governor/test", "base-sha")
        assert result == "new-sha-123"
        mock_repo.create_git_ref.assert_called_once_with(
            ref="refs/heads/governor/test",
            sha="base-sha",
        )

    def test_auth_error(self):
        from github import BadCredentialsException

        client, mock_repo = _make_client()
        mock_repo.create_git_ref.side_effect = BadCredentialsException(
            status=401, data={"message": "Bad"}
        )
        with pytest.raises(GitHubAuthenticationError):
            client.create_branch("owner/repo", "governor/test", "sha")

    def test_connection_error_on_conflict(self):
        from github import GithubException

        client, mock_repo = _make_client()
        mock_repo.create_git_ref.side_effect = GithubException(
            status=422, data={"message": "Reference already exists"}
        )
        with pytest.raises(GitHubConnectionError, match="creating branch"):
            client.create_branch("owner/repo", "governor/test", "sha")


class TestCreateFileCommit:
    """Tests for create_file_commit method."""

    def test_creates_commit(self):
        client, mock_repo = _make_client()

        mock_ref = MagicMock()
        mock_ref.object.sha = "old-sha"
        mock_repo.get_git_ref.return_value = mock_ref

        mock_base_commit = MagicMock()
        mock_base_commit.tree = MagicMock()
        mock_repo.get_git_commit.return_value = mock_base_commit

        mock_new_tree = MagicMock()
        mock_repo.create_git_tree.return_value = mock_new_tree

        mock_new_commit = MagicMock()
        mock_new_commit.sha = "new-commit-sha"
        mock_repo.create_git_commit.return_value = mock_new_commit

        result = client.create_file_commit(
            repo="owner/repo",
            branch="governor/test",
            file_changes=[
                {"path": "models/a.sql", "content": "SELECT 1"},
                {"path": "models/b.sql", "content": "SELECT 2"},
            ],
            message="perf: optimize queries",
        )

        assert result == "new-commit-sha"
        mock_repo.get_git_ref.assert_called_once_with("heads/governor/test")
        mock_repo.create_git_tree.assert_called_once()
        mock_repo.create_git_commit.assert_called_once_with(
            message="perf: optimize queries",
            tree=mock_new_tree,
            parents=[mock_base_commit],
        )
        mock_ref.edit.assert_called_once_with(sha="new-commit-sha")

    def test_auth_error(self):
        from github import BadCredentialsException

        client, mock_repo = _make_client()
        mock_repo.get_git_ref.side_effect = BadCredentialsException(
            status=401, data={"message": "Bad"}
        )
        with pytest.raises(GitHubAuthenticationError):
            client.create_file_commit(
                "owner/repo", "branch", [{"path": "f", "content": "c"}], "msg"
            )


class TestCreatePullRequest:
    """Tests for create_pull_request method."""

    def test_creates_non_draft_pr_by_default(self):
        client, mock_repo = _make_client()
        mock_pr = MagicMock()
        mock_pr.number = 42
        mock_pr.url = "https://api.github.com/repos/owner/repo/pulls/42"
        mock_pr.html_url = "https://github.com/owner/repo/pull/42"
        mock_repo.create_pull.return_value = mock_pr

        result = client.create_pull_request(
            repo="owner/repo",
            head="governor/test",
            base="main",
            title="perf: optimize",
            body="## Description",
        )

        assert result == {
            "number": 42,
            "url": "https://api.github.com/repos/owner/repo/pulls/42",
            "html_url": "https://github.com/owner/repo/pull/42",
        }
        mock_repo.create_pull.assert_called_once_with(
            title="perf: optimize",
            body="## Description",
            base="main",
            head="governor/test",
            draft=False,
        )

    def test_creates_non_draft_pr(self):
        client, mock_repo = _make_client()
        mock_pr = MagicMock()
        mock_pr.number = 1
        mock_pr.url = "url"
        mock_pr.html_url = "html_url"
        mock_repo.create_pull.return_value = mock_pr

        client.create_pull_request(
            "owner/repo", "head", "base", "title", "body", draft=False
        )
        mock_repo.create_pull.assert_called_once_with(
            title="title",
            body="body",
            base="base",
            head="head",
            draft=False,
        )

    def test_connection_error(self):
        from github import GithubException

        client, mock_repo = _make_client()
        mock_repo.create_pull.side_effect = GithubException(
            status=500, data={"message": "Error"}
        )
        with pytest.raises(GitHubConnectionError, match="creating pull request"):
            client.create_pull_request("owner/repo", "head", "base", "title", "body")
