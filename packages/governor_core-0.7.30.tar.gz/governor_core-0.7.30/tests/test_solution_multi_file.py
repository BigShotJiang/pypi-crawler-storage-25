"""Tests for ``Solution.normalized_file_changes`` — the canonical view over
both the new ``file_changes`` JSONB column and the legacy single-file
columns.

The helper must return the same shape (list of dicts) regardless of
whether the row was written by the multi-file path (new JSONB column),
the legacy cloud path (single-file columns only), or is a
bigquery_infrastructure row with no file content at all.
"""

from __future__ import annotations

from tests.fixtures.factories import OpportunityFactory, SolutionFactory


def test_jsonb_preferred_when_present(db):
    sol = SolutionFactory.create(
        solution_job__opportunity=OpportunityFactory.create(),
        file_changes=[
            {
                "file_path": "models/staging/stg_x.sql",
                "change_type": "sql_change",
                "before_content": "SELECT 1",
                "after_content": "SELECT 2",
            },
            {
                "file_path": "models/intermediate/int_x.sql",
                "change_type": "sql_change",
                "before_content": "SELECT a FROM x",
                "after_content": "SELECT a FROM x WHERE dt >= '2024-01-01'",
            },
        ],
        file_path="models/staging/stg_x.sql",
        before_content="SELECT 1",
        after_content="SELECT 2",
    )

    entries = sol.normalized_file_changes

    assert len(entries) == 2
    assert entries[0]["file_path"] == "models/staging/stg_x.sql"
    assert entries[1]["file_path"] == "models/intermediate/int_x.sql"


def test_legacy_single_file_reconstructs_one_entry(db):
    sol = SolutionFactory.create(
        solution_job__opportunity=OpportunityFactory.create(),
        file_changes=None,
        file_path="models/legacy.sql",
        change_type="sql_change",
        before_content="SELECT 1",
        after_content="SELECT 2",
    )

    entries = sol.normalized_file_changes

    assert entries == [
        {
            "file_path": "models/legacy.sql",
            "change_type": "sql_change",
            "before_content": "SELECT 1",
            "after_content": "SELECT 2",
        }
    ]


def test_empty_returns_empty_list(db):
    """bigquery_infrastructure row or truly empty row returns []."""
    sol = SolutionFactory.create(
        solution_job__opportunity=OpportunityFactory.create(),
        file_changes=None,
        file_path=None,
        after_content=None,
        resolution_category="bigquery_infrastructure",
    )

    assert sol.normalized_file_changes == []
