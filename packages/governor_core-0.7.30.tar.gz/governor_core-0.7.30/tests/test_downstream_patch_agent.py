"""Tests for agents/downstream_patch/agent.propose_patch (spec 128, T007-T009)."""

from __future__ import annotations

import asyncio
from unittest.mock import MagicMock

import pytest

from governor_core.agents.downstream_patch import UpstreamPartitionContext, propose_patch
from governor_core.agents.downstream_patch.prompts.downstream_partition_filter import (
    DEFAULT_TEMPORAL_FILTER_DAYS,
    default_filter_expression,
)
from governor_core.llm.schemas import DownstreamPatchResponse, LLMMetadata
from governor_core.shadow.failure_analysis import DownstreamFailure


def _failure(compiled="select count(*) from {{ ref('events') }}"):
    return DownstreamFailure(
        node_id="model.p.events_summary",
        model_name="events_summary",
        original_file_path="models/marts/events_summary.sql",
        package_name="p",
        error_type="compile_error",
        error_message="missing partition filter",
        is_in_project=True,
        compiled_sql=compiled,
    )


def _ctx(data_type="date"):
    return UpstreamPartitionContext(
        upstream_model_name="events",
        upstream_table_fqn="proj.ds.events",
        partition_column="event_date",
        partition_data_type=data_type,
        source_shadow_run_id="run-1",
    )


def _llm(response: DownstreamPatchResponse):
    m = MagicMock()
    m.propose_downstream_patch.return_value = (
        response,
        LLMMetadata(provider="test", model="stub", prompt_tokens=0),
    )
    return m


class TestDefaultFilterExpression:
    def test_date_partition_uses_30_day_window(self):
        expr = default_filter_expression("event_date", "date")
        assert expr is not None
        assert "event_date >= CURRENT_DATE()" in expr
        assert f"INTERVAL {DEFAULT_TEMPORAL_FILTER_DAYS} DAY" in expr

    def test_timestamp_partition(self):
        assert default_filter_expression("ts", "timestamp") is not None

    def test_integer_partition_returns_none(self):
        assert default_filter_expression("bucket", "int64") is None

    def test_unknown_type_returns_none(self):
        assert default_filter_expression("x", "weird_type") is None


class TestProposePatchHappyPath:
    def test_patched_response_produces_proposed_patch(self):
        after = (
            "select count(*) from {{ ref('events') }} "
            "where event_date >= CURRENT_DATE() - INTERVAL 30 DAY"
        )
        llm = _llm(
            DownstreamPatchResponse(
                status="patched",
                after_content=after,
                filter_expression="event_date >= CURRENT_DATE() - INTERVAL 30 DAY",
                explanation="Added 30-day window.",
            )
        )

        patch = asyncio.run(propose_patch(_failure(), _ctx(), llm_provider=llm))

        assert patch.status == "proposed"
        assert "WHERE" in patch.after_content.upper()
        assert patch.proposal_meta["status"] == "proposed"
        assert patch.proposal_meta["partition_column"] == "event_date"
        assert patch.proposal_meta["source_shadow_run_id"] == "run-1"

    def test_diff_adds_where_only(self):
        before = "select count(*) from {{ ref('events') }}"
        after = before + " where event_date >= CURRENT_DATE() - INTERVAL 30 DAY"
        llm = _llm(
            DownstreamPatchResponse(status="patched", after_content=after, filter_expression="...")
        )
        patch = asyncio.run(
            propose_patch(_failure(compiled=before), _ctx(), llm_provider=llm)
        )
        # Before-content seeded from compiled SQL; after content only adds WHERE.
        assert patch.after_content.startswith("select count(*)")


class TestProposePatchAbstention:
    def test_llm_abstain_becomes_manual_required(self):
        llm = _llm(
            DownstreamPatchResponse(
                status="abstain",
                abstain_reason="downstream computes year-to-date aggregate",
            )
        )
        patch = asyncio.run(propose_patch(_failure(), _ctx(), llm_provider=llm))
        assert patch.status == "manual_required"
        assert (
            "year-to-date" in patch.proposal_meta["abstain_reason"]
        )

    def test_empty_after_content_becomes_manual_required(self):
        llm = _llm(DownstreamPatchResponse(status="patched", after_content=""))
        patch = asyncio.run(propose_patch(_failure(), _ctx(), llm_provider=llm))
        assert patch.status == "manual_required"

    def test_llm_exception_becomes_manual_required(self):
        llm = MagicMock()
        llm.propose_downstream_patch.side_effect = RuntimeError("transient network")
        patch = asyncio.run(propose_patch(_failure(), _ctx(), llm_provider=llm))
        assert patch.status == "manual_required"
        assert "transient network" in patch.proposal_meta["abstain_reason"]


class TestProposePatchPartitionTypeBranching:
    def test_int_partition_abstains_without_llm_call(self):
        llm = MagicMock()  # should not be invoked
        patch = asyncio.run(
            propose_patch(_failure(), _ctx(data_type="int64"), llm_provider=llm)
        )
        assert patch.status == "manual_required"
        llm.propose_downstream_patch.assert_not_called()
        assert "int64" in patch.proposal_meta["abstain_reason"]
