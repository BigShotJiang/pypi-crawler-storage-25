from __future__ import annotations

from governor_core.opportunities.catalog import (
    build_effective_rule_selection,
    get_detection_rule_catalog,
    get_grouped_detection_rule_catalog,
    get_detection_rule_map,
)


def test_catalog_contains_expected_builtin_rules():
    rule_types = {entry.rule_type for entry in get_detection_rule_catalog()}

    assert {
        "shuffle_spill",
        "slot_contention",
        "join_explosion",
        "partition_pruning",
        "storage_billing_optimization",
        "dead_cte",
        "dead_column",
        "dead_window_expression",
        "unused_aggregation_output",
        "redundant_order_by",
        "unused_join",
    }.issubset(rule_types)


def test_catalog_entries_have_ui_metadata():
    for entry in get_detection_rule_catalog():
        assert entry.display_name
        assert entry.description
        assert entry.group_key
        assert entry.group_title
        assert entry.group_description
        assert entry.rule_class is not None


def test_detection_rule_map_keys_match_catalog():
    catalog = get_detection_rule_catalog()
    rule_map = get_detection_rule_map()

    assert set(rule_map) == {entry.rule_type for entry in catalog}


def test_effective_rule_selection_marks_disabled_and_unknown_custom_rules():
    selection = build_effective_rule_selection(
        ["dead_column", "retired_rule", "dead_column"]
    )

    assert selection.mode == "custom"
    assert selection.configured_rule_types == ["dead_column"]
    assert selection.unknown_rule_types == ["retired_rule"]
    assert selection.unavailable_rule_types == ["dead_column"]
    assert selection.effective_rule_types == []


def test_grouped_detection_rule_catalog_organizes_rules():
    groups = get_grouped_detection_rule_catalog()

    assert [group.key for group in groups] == [
        "performance",
        "storage",
        "dead_code",
        "sql_cleanup",
    ]
    assert {rule.rule_type for rule in groups[0].rules} == {
        "shuffle_spill",
        "slot_contention",
        "join_explosion",
        "partition_pruning",
    }
    assert {rule.rule_type for rule in groups[2].rules} == {
        "dead_cte",
        "dead_column",
        "dead_window_expression",
        "unused_aggregation_output",
    }
