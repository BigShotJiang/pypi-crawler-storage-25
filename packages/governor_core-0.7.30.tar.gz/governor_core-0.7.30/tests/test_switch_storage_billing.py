"""Tests for SwitchStorageBillingTemplate."""

from __future__ import annotations

from types import SimpleNamespace

from governor_core.solutions.templates.switch_storage_billing import SwitchStorageBillingTemplate


def _make_opportunity(
    opportunity_type: str = "storage_billing_optimization",
    affected_table: str = "test-project.analytics",
    evidence: dict | None = None,
) -> SimpleNamespace:
    """Create a mock opportunity."""
    if evidence is None:
        evidence = {
            "dataset": "test-project.analytics",
            "current_billing_model": "LOGICAL",
            "table_count": 42,
            "compression_ratio": 4.0,
            "logical_cost_monthly": 21.51,
            "physical_cost_monthly": 12.80,
            "monthly_savings": 8.71,
            "annual_savings": 104.52,
            "savings_percentage": 40.5,
        }
    return SimpleNamespace(
        id="opp-123",
        opportunity_type=opportunity_type,
        affected_table=affected_table,
        evidence_snapshot=evidence,
    )


class TestSwitchStorageBillingTemplate:
    """Tests for the SwitchStorageBillingTemplate."""

    def test_template_id(self):
        t = SwitchStorageBillingTemplate()
        assert t.template_id == "switch_storage_billing"
        assert "storage_billing_optimization" in t.applicable_types

    def test_matches_storage_billing(self):
        """Matches opportunities with storage_billing_optimization type."""
        t = SwitchStorageBillingTemplate()
        opp = _make_opportunity()
        assert t.matches(opp, {}, None) is True

    def test_does_not_match_other_types(self):
        """Does not match non-storage opportunity types."""
        t = SwitchStorageBillingTemplate()
        opp = _make_opportunity(opportunity_type="shuffle_spill")
        assert t.matches(opp, {}, None) is False

    def test_apply_generates_ddl(self):
        """Apply generates correct ALTER SCHEMA DDL."""
        t = SwitchStorageBillingTemplate()
        opp = _make_opportunity()
        result = t.apply(opp, {}, None)

        assert result is not None
        assert result.template_id == "switch_storage_billing"
        assert "ALTER SCHEMA" in result.explanation
        assert "`analytics`" in result.explanation
        assert "PHYSICAL" in result.explanation

    def test_apply_parameters_contain_ddl(self):
        """Parameters contain DDL and infrastructure metadata."""
        t = SwitchStorageBillingTemplate()
        opp = _make_opportunity()
        result = t.apply(opp, {}, None)

        params = result.parameters
        assert params["resolution_category"] == "bigquery_infrastructure"
        assert "ALTER SCHEMA" in params["ddl"]
        assert "PHYSICAL" in params["ddl"]
        assert params["current_setting_value"] == "LOGICAL"
        assert params["recommended_setting_value"] == "PHYSICAL"
        assert params["affected_resource"] == "test-project.analytics"

    def test_apply_sets_solution_policy_tags(self):
        """Infrastructure template declares its policy tag explicitly."""
        t = SwitchStorageBillingTemplate()
        opp = _make_opportunity()
        result = t.apply(opp, {}, None)

        assert result.policy_tags == ["bigquery_infrastructure"]

    def test_apply_rollback_ddl(self):
        """Rollback DDL switches back to LOGICAL."""
        t = SwitchStorageBillingTemplate()
        opp = _make_opportunity()
        result = t.apply(opp, {}, None)

        assert "LOGICAL" in result.rollback
        assert "ALTER SCHEMA" in result.rollback

    def test_apply_explanation_contains_costs(self):
        """Explanation includes cost comparison and table count."""
        t = SwitchStorageBillingTemplate()
        opp = _make_opportunity()
        result = t.apply(opp, {}, None)

        assert "$21.51" in result.explanation
        assert "$12.8" in result.explanation
        assert "$8.71" in result.explanation
        assert "(42 tables)" in result.explanation

    def test_apply_no_file_path(self):
        """Infrastructure templates have empty file_path."""
        t = SwitchStorageBillingTemplate()
        opp = _make_opportunity()
        result = t.apply(opp, {}, None)

        assert result.file_path == ""
        assert result.before_content == ""
        assert result.after_content == ""

    def test_rollback_instructions(self):
        """Rollback instructions are useful."""
        t = SwitchStorageBillingTemplate()
        instructions = t.rollback_instructions()
        assert "LOGICAL" in instructions
        assert "ALTER SCHEMA" in instructions

    def test_match_template_integration(self):
        """match_template() returns result for storage_billing_optimization."""
        from governor_core.solutions.templates import match_template

        opp = _make_opportunity()
        result = match_template(opp, None, None)

        assert result is not None
        assert result.template_id == "switch_storage_billing"
