"""Unit tests for app.dbt.affected_column."""

import pytest

from governor_core.dbt.affected_column import extract_affected_partition_cluster_column


# ── Helpers ──────────────────────────────────────────────────────────────────

def _dbt_sql(config_block: str, body: str = "SELECT 1") -> str:
    return f"{{{{{ config_block }}}}}\n{body}"


def _partition_config(field: str, data_type: str = "date") -> str:
    return f'config(partition_by={{"field": "{field}", "data_type": "{data_type}"}}, materialized="table")'


def _cluster_config(cols: list[str]) -> str:
    cols_str = ", ".join(f'"{c}"' for c in cols)
    return f"config(cluster_by=[{cols_str}], materialized='table')"


# ── Partition tests ───────────────────────────────────────────────────────────

def test_new_partition_by_added():
    before = "SELECT id, event_date FROM source"
    after = _dbt_sql(_partition_config("event_date"), "SELECT id, event_date FROM source")
    result = extract_affected_partition_cluster_column(before, after)
    assert result == ("event_date", "partition")


def test_partition_column_changed():
    before = _dbt_sql(_partition_config("created_at"), "SELECT * FROM source")
    after = _dbt_sql(_partition_config("event_date"), "SELECT * FROM source")
    result = extract_affected_partition_cluster_column(before, after)
    assert result == ("event_date", "partition")


def test_partition_column_unchanged_returns_none():
    sql = _dbt_sql(_partition_config("event_date"), "SELECT * FROM source")
    result = extract_affected_partition_cluster_column(sql, sql)
    assert result is None


def test_no_partition_in_either_returns_none():
    before = "SELECT * FROM source"
    after = "SELECT *, extra_col FROM source"
    result = extract_affected_partition_cluster_column(before, after)
    assert result is None


# ── Cluster tests ─────────────────────────────────────────────────────────────

def test_new_cluster_by_added():
    before = "SELECT id, user_id FROM source"
    after = _dbt_sql(_cluster_config(["user_id"]), "SELECT id, user_id FROM source")
    result = extract_affected_partition_cluster_column(before, after)
    assert result == ("user_id", "cluster")


def test_cluster_column_added_to_existing():
    before = _dbt_sql(_cluster_config(["user_id"]), "SELECT * FROM source")
    after = _dbt_sql(_cluster_config(["user_id", "event_type"]), "SELECT * FROM source")
    result = extract_affected_partition_cluster_column(before, after)
    assert result == ("event_type", "cluster")


def test_cluster_unchanged_returns_none():
    sql = _dbt_sql(_cluster_config(["user_id"]), "SELECT * FROM source")
    result = extract_affected_partition_cluster_column(sql, sql)
    assert result is None


# ── Edge cases ────────────────────────────────────────────────────────────────

def test_empty_strings_return_none():
    assert extract_affected_partition_cluster_column("", "") is None


def test_none_like_empty_strings_return_none():
    assert extract_affected_partition_cluster_column("", "SELECT 1") is None


def test_malformed_sql_returns_none():
    # Malformed Jinja / broken braces — should not raise
    before = "{{ config(partition_by=BROKEN_NO_CLOSING"
    after = "{{ config(partition_by=BROKEN_TOO"
    result = extract_affected_partition_cluster_column(before, after)
    assert result is None


def test_partition_removed_returns_none():
    # Removing a partition is not detected as a new change (no "after" partition)
    before = _dbt_sql(_partition_config("event_date"), "SELECT * FROM source")
    after = "SELECT * FROM source"
    result = extract_affected_partition_cluster_column(before, after)
    assert result is None


def test_partition_takes_priority_over_cluster():
    # If both partition and cluster change, partition is returned
    before = "SELECT * FROM source"
    combined_config = (
        'config(partition_by={"field": "event_date"}, cluster_by=["user_id"])'
    )
    after = f"{{{{ {combined_config} }}}}\nSELECT * FROM source"
    result = extract_affected_partition_cluster_column(before, after)
    assert result == ("event_date", "partition")


def test_column_names_lowercased():
    before = "SELECT * FROM source"
    after = _dbt_sql(_partition_config("EventDate"), "SELECT * FROM source")
    result = extract_affected_partition_cluster_column(before, after)
    assert result == ("eventdate", "partition")
