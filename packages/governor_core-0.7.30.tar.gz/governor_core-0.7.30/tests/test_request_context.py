from __future__ import annotations

from fastapi.testclient import TestClient

from governor_core.core.logging import (
    client_ip_var,
    request_id_var,
    request_method_var,
    request_path_var,
)


def test_request_context_is_cleared_after_exception(client):
    test_client, _ = client
    app = test_client.app

    @app.get("/__test/boom")
    def _boom():
        raise RuntimeError("boom")

    exception_client = TestClient(app, raise_server_exceptions=False)
    response = exception_client.get("/__test/boom")

    assert response.status_code == 500
    assert request_id_var.get() is None
    assert request_path_var.get() is None
    assert request_method_var.get() is None
    assert client_ip_var.get() is None
