"""Smoke tests — every factory produces a persisted instance with a non-null id.

Introduced by spec 109 to validate the factory-boy registry before migrating
test files away from the handwritten `_create_test_*` helpers.
"""

from __future__ import annotations

from tests.fixtures.factories import (
    AdminUserFactory,
    BigQueryJobFactory,
    DetectionJobFactory,
    ManifestConfigurationFactory,
    ManifestVersionFactory,
    OpportunityFactory,
    PullRequestRecordFactory,
    RoleFactory,
    SessionFactory,
    ShadowModelExecutionFactory,
    ShadowValidationRunFactory,
    SolutionFactory,
    SolutionJobFactory,
    SyncOperationFactory,
    UserFactory,
)


def test_user_factory(db):
    user = UserFactory.create()
    assert user.id
    assert user.email.endswith("@test.com")


def test_role_factory(db):
    role = RoleFactory.create()
    assert role.id
    assert role.name.startswith("role-")


def test_admin_user_factory_assigns_admin_role(db):
    admin = AdminUserFactory.create()
    assert admin.id
    assert any(r.name == "admin" for r in admin.roles)


def test_session_factory(db):
    sess = SessionFactory.create()
    assert sess.id
    assert sess.user_id


def test_manifest_configuration_factory(db):
    config = ManifestConfigurationFactory.create()
    assert config.id
    assert config.created_by_id == config.updated_by_id


def test_sync_operation_factory(db):
    sync_op = SyncOperationFactory.create()
    assert sync_op.id
    assert sync_op.status == "completed"


def test_manifest_version_factory(db):
    mv = ManifestVersionFactory.create()
    assert mv.id
    assert mv.config_id == mv.sync_operation.config_id


def test_bigquery_job_factory(db):
    job = BigQueryJobFactory.create()
    assert job.id
    assert job.job_state == "DONE"


def test_detection_job_factory(db):
    dj = DetectionJobFactory.create()
    assert dj.id
    assert dj.status == "completed"


def test_opportunity_factory(db):
    opp = OpportunityFactory.create()
    assert opp.id
    assert opp.config_id
    assert opp.manifest_version_id
    assert opp.first_detection_job_id


def test_solution_job_factory(db):
    job = SolutionJobFactory.create()
    assert job.id
    assert job.opportunity_id
    assert job.config_id


def test_solution_factory(db):
    sol = SolutionFactory.create()
    assert sol.id
    assert sol.solution_job_id
    assert sol.opportunity_id


def test_pull_request_record_factory(db):
    pr = PullRequestRecordFactory.create()
    assert pr.id
    assert pr.solution_id
    assert pr.opportunity_id


def test_shadow_validation_run_factory(db):
    run = ShadowValidationRunFactory.create()
    assert run.id
    assert run.solution_id
    assert run.status == "queued"
    assert len(run.solution_id_hex12) == 12


def test_shadow_model_execution_factory(db):
    ex = ShadowModelExecutionFactory.create()
    assert ex.id
    assert ex.shadow_run_id
    assert ex.phase == "baseline"
    assert ex.bytes_processed == 1_000_000


# ---------------------------------------------------------------------------
# Auth fixtures smoke
# ---------------------------------------------------------------------------


def test_test_user_fixture(test_user):
    assert test_user.id
    assert test_user.email.endswith("@test.com")


def test_admin_user_fixture(admin_user):
    assert admin_user.id
    assert any(r.name == "admin" for r in admin_user.roles)


def test_authed_client_fixture_sets_session_cookie(authed_client):
    from governor_web.core.config import get_settings

    cookie_name = get_settings().session_cookie_name
    assert cookie_name in authed_client.cookies
