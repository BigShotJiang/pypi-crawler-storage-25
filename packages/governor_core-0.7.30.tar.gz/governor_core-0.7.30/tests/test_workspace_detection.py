"""Tests for local workspace detection (spec 084)."""

from __future__ import annotations

from pathlib import Path

from governor_core.workspace.detection import (
    _parse_github_remote,
    detect_workspace,
    read_local_file,
    read_local_manifest,
    read_local_run_results,
    write_local_file,
)


class TestDetectWorkspace:
    def test_detects_dbt_project(self, tmp_path):
        """Finds dbt_project.yml and target/manifest.json."""
        (tmp_path / "dbt_project.yml").write_text("name: my_project\nversion: 1.0.0\n")
        (tmp_path / "target").mkdir()
        (tmp_path / "target" / "manifest.json").write_text('{"nodes": {}}')

        info = detect_workspace(tmp_path)
        assert info.project_path == str(tmp_path)
        assert info.dbt_project_name == "my_project"
        assert info.has_manifest is True

    def test_detects_run_results(self, tmp_path):
        (tmp_path / "dbt_project.yml").write_text("name: test\n")
        (tmp_path / "target").mkdir()
        (tmp_path / "target" / "manifest.json").write_text("{}")
        (tmp_path / "target" / "run_results.json").write_text('{"results": []}')

        info = detect_workspace(tmp_path)
        assert info.has_run_results is True

    def test_no_dbt_project(self, tmp_path):
        info = detect_workspace(tmp_path)
        assert info.project_path is None
        assert len(info.errors) > 0

    def test_no_manifest(self, tmp_path):
        (tmp_path / "dbt_project.yml").write_text("name: test\n")

        info = detect_workspace(tmp_path)
        assert info.project_path is not None
        assert info.has_manifest is False
        assert any("manifest" in e.lower() for e in info.errors)

    def test_finds_project_in_parent(self, tmp_path):
        """If CWD is a subdirectory, find dbt_project.yml in parent."""
        (tmp_path / "dbt_project.yml").write_text("name: parent_project\n")
        (tmp_path / "target").mkdir()
        (tmp_path / "target" / "manifest.json").write_text("{}")
        subdir = tmp_path / "models" / "staging"
        subdir.mkdir(parents=True)

        info = detect_workspace(subdir)
        assert info.project_path == str(tmp_path)
        assert info.dbt_project_name == "parent_project"

    def test_nonexistent_path(self):
        info = detect_workspace("/nonexistent/path/nowhere")
        assert info.project_path is None


class TestGitRemoteParsing:
    def test_https_url(self):
        assert _parse_github_remote("https://github.com/owner/repo.git") == "owner/repo"

    def test_https_no_git_suffix(self):
        assert _parse_github_remote("https://github.com/owner/repo") == "owner/repo"

    def test_ssh_url(self):
        assert _parse_github_remote("git@github.com:owner/repo.git") == "owner/repo"

    def test_ssh_no_git_suffix(self):
        assert _parse_github_remote("git@github.com:owner/repo") == "owner/repo"

    def test_non_github_returns_none(self):
        assert _parse_github_remote("https://gitlab.com/owner/repo.git") is None

    def test_empty_string(self):
        assert _parse_github_remote("") is None


class TestReadLocalFile:
    def test_reads_existing_file(self, tmp_path):
        (tmp_path / "models").mkdir()
        (tmp_path / "models" / "test.sql").write_text("SELECT 1")

        content = read_local_file(str(tmp_path), "models/test.sql")
        assert content == "SELECT 1"

    def test_returns_none_for_missing(self, tmp_path):
        assert read_local_file(str(tmp_path), "nonexistent.sql") is None

    def test_rejects_path_traversal(self, tmp_path):
        import pytest

        with pytest.raises(ValueError, match="Path traversal"):
            read_local_file(str(tmp_path), "../../etc/passwd")


class TestWriteLocalFile:
    def test_writes_file(self, tmp_path):
        result = write_local_file(str(tmp_path), "models/test.sql", "SELECT 1")
        assert Path(result).exists()
        assert Path(result).read_text() == "SELECT 1"

    def test_creates_directories(self, tmp_path):
        write_local_file(str(tmp_path), "models/staging/deep/test.sql", "SELECT 1")
        assert (tmp_path / "models" / "staging" / "deep" / "test.sql").exists()

    def test_rejects_path_traversal(self, tmp_path):
        import pytest

        with pytest.raises(ValueError, match="Path traversal"):
            write_local_file(str(tmp_path), "../../evil.sql", "DROP TABLE")


class TestReadLocalManifest:
    def test_reads_manifest(self, tmp_path):
        (tmp_path / "target").mkdir()
        (tmp_path / "target" / "manifest.json").write_text('{"nodes": {}}')

        data = read_local_manifest(str(tmp_path))
        assert data is not None
        assert b"nodes" in data

    def test_returns_none_when_missing(self, tmp_path):
        assert read_local_manifest(str(tmp_path)) is None


class TestReadLocalRunResults:
    def test_reads_run_results(self, tmp_path):
        (tmp_path / "target").mkdir()
        (tmp_path / "target" / "run_results.json").write_text(
            '{"results": [{"status": "pass"}]}'
        )

        data = read_local_run_results(str(tmp_path))
        assert data is not None
        assert "results" in data

    def test_returns_none_when_missing(self, tmp_path):
        assert read_local_run_results(str(tmp_path)) is None

    def test_returns_none_on_invalid_json(self, tmp_path):
        (tmp_path / "target").mkdir()
        (tmp_path / "target" / "run_results.json").write_text("not json")

        assert read_local_run_results(str(tmp_path)) is None


class TestInferBigqueryLocationFromRunResults:
    """Spec 136: derive BigQuery region from dbt run_results.json
    (adapter_response.location), the authoritative source."""

    def _fn(self):
        from governor_core.workspace.detection import (
            infer_bigquery_location_from_run_results,
        )

        return infer_bigquery_location_from_run_results

    def test_returns_location_when_present(self):
        rr = {
            "results": [
                {"adapter_response": {"location": "australia-southeast1"}},
                {"adapter_response": {"location": "australia-southeast1"}},
            ]
        }
        assert self._fn()(rr) == "australia-southeast1"

    def test_normalises_to_lowercase(self):
        rr = {"results": [{"adapter_response": {"location": "US"}}]}
        assert self._fn()(rr) == "us"

    def test_picks_most_common_when_mixed(self):
        rr = {
            "results": [
                {"adapter_response": {"location": "US"}},
                {"adapter_response": {"location": "US"}},
                {"adapter_response": {"location": "europe-west2"}},
            ]
        }
        assert self._fn()(rr) == "us"

    def test_skips_results_with_no_adapter_response(self):
        rr = {
            "results": [
                {"adapter_response": {}},
                {"adapter_response": {"location": "eu"}},
                {},
            ]
        }
        assert self._fn()(rr) == "eu"

    def test_returns_none_when_empty(self):
        assert self._fn()({}) is None
        assert self._fn()({"results": []}) is None
        assert self._fn()(None) is None

    def test_returns_none_when_no_location_fields(self):
        rr = {"results": [{"adapter_response": {"job_id": "x"}}]}
        assert self._fn()(rr) is None


class TestInferGcpProjectFromRunResults:
    """Spec 138: derive GCP project from dbt run_results.json
    (adapter_response.project_id), matching the region-helper pattern."""

    def _fn(self):
        from governor_core.workspace.detection import (
            infer_gcp_project_from_run_results,
        )

        return infer_gcp_project_from_run_results

    def test_returns_project_when_present(self):
        rr = {
            "results": [
                {"adapter_response": {"project_id": "sm-dev-447100"}},
                {"adapter_response": {"project_id": "sm-dev-447100"}},
            ]
        }
        assert self._fn()(rr) == "sm-dev-447100"

    def test_picks_most_common_when_mixed(self):
        rr = {
            "results": [
                {"adapter_response": {"project_id": "proj-a"}},
                {"adapter_response": {"project_id": "proj-a"}},
                {"adapter_response": {"project_id": "proj-b"}},
            ]
        }
        assert self._fn()(rr) == "proj-a"

    def test_returns_none_when_empty(self):
        assert self._fn()({}) is None
        assert self._fn()({"results": []}) is None
        assert self._fn()(None) is None

    def test_deterministic_tie_break(self):
        rr = {
            "results": [
                {"adapter_response": {"project_id": "proj-b"}},
                {"adapter_response": {"project_id": "proj-a"}},
            ]
        }
        # Tie → alphabetical winner.
        assert self._fn()(rr) == "proj-a"

    def test_skips_results_with_no_project_id(self):
        rr = {
            "results": [
                {"adapter_response": {}},
                {"adapter_response": {"project_id": "proj-x"}},
                {},
            ]
        }
        assert self._fn()(rr) == "proj-x"
