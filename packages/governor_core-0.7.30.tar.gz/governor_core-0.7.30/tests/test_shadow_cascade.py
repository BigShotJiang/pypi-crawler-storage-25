"""Unit tests for shadow cascade discovery."""

from __future__ import annotations

from governor_core.shadow.cascade import discover_cascade, node_id_to_model_name


def test_empty_child_map_returns_only_target():
    manifest = {"child_map": {}}
    assert discover_cascade(manifest, "model.p.fct_orders") == [
        "model.p.fct_orders"
    ]


def test_linear_chain():
    manifest = {
        "child_map": {
            "model.p.a": ["model.p.b"],
            "model.p.b": ["model.p.c"],
            "model.p.c": [],
        }
    }
    assert discover_cascade(manifest, "model.p.a") == [
        "model.p.a",
        "model.p.b",
        "model.p.c",
    ]


def test_diamond():
    manifest = {
        "child_map": {
            "model.p.a": ["model.p.b", "model.p.c"],
            "model.p.b": ["model.p.d"],
            "model.p.c": ["model.p.d"],
            "model.p.d": [],
        }
    }
    result = discover_cascade(manifest, "model.p.a")
    # d is visited once, despite two paths
    assert result == ["model.p.a", "model.p.b", "model.p.c", "model.p.d"]


def test_non_model_children_filtered():
    manifest = {
        "child_map": {
            "model.p.a": ["test.p.not_null_a", "model.p.b"],
            "model.p.b": [],
        }
    }
    assert discover_cascade(manifest, "model.p.a") == [
        "model.p.a",
        "model.p.b",
    ]


def test_non_model_target_returns_empty():
    manifest = {"child_map": {}}
    assert discover_cascade(manifest, "source.p.raw_orders") == []


def test_max_size_truncates_cascade():
    manifest = {
        "child_map": {
            "model.p.a": ["model.p.b", "model.p.c", "model.p.d"],
            "model.p.b": [],
            "model.p.c": [],
            "model.p.d": [],
        }
    }
    result = discover_cascade(manifest, "model.p.a", max_size=2)
    assert len(result) == 2


def test_node_id_to_model_name():
    assert node_id_to_model_name("model.my_project.fct_orders") == "fct_orders"
    assert node_id_to_model_name("fct_orders") == "fct_orders"
    assert node_id_to_model_name("") == ""
