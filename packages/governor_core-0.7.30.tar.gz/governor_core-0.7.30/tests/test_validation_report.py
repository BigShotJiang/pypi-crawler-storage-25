"""Unit tests for validation report helpers."""

from __future__ import annotations

from governor_core.solutions.validation.report import (
    build_validation_report,
    extract_template_id,
    has_blocking_dbt_verification_issue,
    make_step,
)


def test_build_validation_report_adds_ui_fields():
    report = build_validation_report(
        steps=[
            make_step(
                "template_match",
                "matched",
                template_id="remove_dead_columns",
            )
        ],
        tier="guaranteed_safe",
    )

    assert report["tier"] == "guaranteed_safe"
    assert report["overall_tier"] == "guaranteed_safe"
    assert report["template_id"] == "remove_dead_columns"
    assert isinstance(report["timestamp"], str)


def test_extract_template_id_falls_back_to_step_parameters():
    report = {
        "steps": [
            {
                "type": "upstream_template_match",
                "result": "matched",
                "parameters": {
                    "template_id": "upstream_cluster_by",
                },
            }
        ]
    }

    assert extract_template_id(report) == "upstream_cluster_by"


def test_has_blocking_dbt_verification_issue_prefers_parse_when_available():
    assert has_blocking_dbt_verification_issue(None) is False
    assert (
        has_blocking_dbt_verification_issue({"dbt_compile": {"success": True}}) is False
    )
    assert (
        has_blocking_dbt_verification_issue({"dbt_parse": {"success": True}}) is False
    )
    assert (
        has_blocking_dbt_verification_issue(
            {"dbt_compile": {"success": False, "reason": "compile_failed"}}
        )
        is True
    )
    assert (
        has_blocking_dbt_verification_issue({"dbt_parse": {"success": False}}) is True
    )
    assert (
        has_blocking_dbt_verification_issue(
            {
                "dbt_compile": {"success": False, "reason": "legacy_failure"},
                "dbt_parse": {"success": True},
            }
        )
        is False
    )
