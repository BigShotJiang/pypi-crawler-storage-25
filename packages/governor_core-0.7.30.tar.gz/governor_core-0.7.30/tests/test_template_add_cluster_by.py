"""Unit tests for app/solutions/templates/add_cluster_by.py."""

from types import SimpleNamespace

from governor_core.solutions.templates.add_cluster_by import AddClusterByTemplate
from governor_core.solutions.templates.base import TemplateResult


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_opportunity(
    opp_type: str = "shuffle_spill",
    evidence: dict | None = None,
):
    return SimpleNamespace(
        id="opp-1",
        opportunity_type=opp_type,
        evidence_snapshot=evidence or {},
        dbt_model_name="my_model",
        affected_table="project.dataset.my_model",
    )


# ---------------------------------------------------------------------------
# SQL Fixtures
# ---------------------------------------------------------------------------

SQL_WITH_CONFIG = """\
{{ config(
    materialized='table'
) }}

SELECT id, name, created_at
FROM {{ ref('raw_orders') }}
"""

SQL_WITH_CLUSTER = """\
{{ config(
    materialized='table',
    cluster_by=["existing_col"]
) }}

SELECT id, name, created_at
FROM {{ ref('raw_orders') }}
"""

_METADATA = {"original_file_path": "models/my_model.sql"}


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


class TestAddClusterByTemplate:
    def setup_method(self):
        self.template = AddClusterByTemplate()

    def test_matches_shuffle_spill_with_columns(self):
        """Matches when opportunity_type is shuffle_spill with recommended columns and .sql files."""
        opp = _make_opportunity(
            evidence={"recommended_cluster_columns": ["customer_id", "order_date"]},
        )
        source_files = {"models/my_model.sql": SQL_WITH_CONFIG}
        assert self.template.matches(opp, source_files, _METADATA) is True

    def test_no_match_wrong_type(self):
        """Does not match when opportunity_type is not shuffle_spill."""
        opp = _make_opportunity(
            opp_type="dead_column",
            evidence={"recommended_cluster_columns": ["customer_id"]},
        )
        source_files = {"models/my_model.sql": SQL_WITH_CONFIG}
        assert self.template.matches(opp, source_files, _METADATA) is False

    def test_no_match_no_source_files(self):
        """Does not match with empty source_files."""
        opp = _make_opportunity(
            evidence={"recommended_cluster_columns": ["customer_id"]},
        )
        assert self.template.matches(opp, {}, _METADATA) is False

    def test_no_match_no_columns(self):
        """Does not match when evidence has no clustering columns."""
        opp = _make_opportunity(evidence={})
        source_files = {"models/my_model.sql": SQL_WITH_CONFIG}
        assert self.template.matches(opp, source_files, _METADATA) is False

    def test_apply_inserts_cluster_by(self):
        """Apply inserts cluster_by into config block and returns correct TemplateResult."""
        opp = _make_opportunity(
            evidence={"recommended_cluster_columns": ["customer_id", "order_date"]},
        )
        source_files = {"models/my_model.sql": SQL_WITH_CONFIG}
        result = self.template.apply(opp, source_files, _METADATA)

        assert result is not None
        assert isinstance(result, TemplateResult)
        assert result.template_id == "add_cluster_by"
        assert result.file_path == "models/my_model.sql"
        assert result.before_content == SQL_WITH_CONFIG
        assert "cluster_by" in result.after_content
        assert "customer_id" in result.after_content
        assert "order_date" in result.after_content
        assert result.change_type == "project_config_change"
        assert result.policy_tags == ["dbt_config_change"]
        assert result.parameters == {"columns": ["customer_id", "order_date"]}
        assert "materialized" in result.after_content  # existing config preserved

    def test_apply_merges_existing_cluster_by(self):
        """When cluster_by already exists, new columns are merged in."""
        opp = _make_opportunity(
            evidence={"recommended_cluster_columns": ["existing_col", "new_col"]},
        )
        source_files = {"models/my_model.sql": SQL_WITH_CLUSTER}
        result = self.template.apply(opp, source_files, _METADATA)

        assert result is not None
        assert "existing_col" in result.after_content
        assert "new_col" in result.after_content

    def test_apply_returns_none_when_all_columns_present(self):
        """Returns None when all recommended columns are already in cluster_by."""
        opp = _make_opportunity(
            evidence={"recommended_cluster_columns": ["existing_col"]},
        )
        source_files = {"models/my_model.sql": SQL_WITH_CLUSTER}
        result = self.template.apply(opp, source_files, _METADATA)

        assert result is None

    def test_extract_columns_fallback_to_shuffle_keys(self):
        """Falls back to top_shuffle_keys when no recommended_cluster_columns, max 4."""
        opp = _make_opportunity(
            evidence={
                "top_shuffle_keys": ["col_a", "col_b", "col_c", "col_d", "col_e"],
            },
        )
        source_files = {"models/my_model.sql": SQL_WITH_CONFIG}
        result = self.template.apply(opp, source_files, _METADATA)

        assert result is not None
        # Should take only first 4 (BigQuery limit)
        assert result.parameters["columns"] == ["col_a", "col_b", "col_c", "col_d"]
        assert "col_e" not in result.after_content

    def test_find_model_path_from_metadata(self):
        """Uses manifest_metadata.original_file_path when available."""
        opp = _make_opportunity(
            evidence={"recommended_cluster_columns": ["id"]},
        )
        metadata = {"original_file_path": "models/specific_model.sql"}
        source_files = {
            "models/specific_model.sql": SQL_WITH_CONFIG,
            "models/other.sql": SQL_WITH_CONFIG,
        }
        result = self.template.apply(opp, source_files, metadata)

        assert result is not None
        assert result.file_path == "models/specific_model.sql"

    def test_find_model_path_fallback_to_sql(self):
        """Falls back to first .sql file when no metadata."""
        opp = _make_opportunity(
            evidence={"recommended_cluster_columns": ["id"]},
        )
        source_files = {"models/my_model.sql": SQL_WITH_CONFIG}
        result = self.template.apply(opp, source_files, None)

        assert result is not None
        assert result.file_path == "models/my_model.sql"
