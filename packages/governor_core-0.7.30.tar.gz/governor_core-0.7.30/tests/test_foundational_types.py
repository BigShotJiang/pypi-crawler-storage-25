"""Tests for spec 128 foundational dataclasses (T004)."""

from __future__ import annotations

import dataclasses

from governor_core.shadow.failure_analysis import (
    DownstreamFailure,
    DownstreamPatch,
)


class TestDownstreamFailure:
    def test_hashable_and_frozen(self):
        f = DownstreamFailure(
            node_id="model.p.m",
            model_name="m",
            original_file_path="models/m.sql",
            package_name="p",
            error_type="compile_error",
            error_message=None,
            is_in_project=True,
            compiled_sql=None,
        )
        {f}  # must be hashable
        assert dataclasses.is_dataclass(f)

    def test_asdict_roundtrip(self):
        f = DownstreamFailure(
            node_id="model.p.m",
            model_name="m",
            original_file_path="models/m.sql",
            package_name="p",
            error_type="compile_error",
            error_message="boom",
            is_in_project=True,
            compiled_sql="select 1",
        )
        d = dataclasses.asdict(f)
        assert d["node_id"] == "model.p.m"
        assert d["compiled_sql"] == "select 1"


class TestDownstreamPatch:
    def _fresh(self) -> DownstreamPatch:
        return DownstreamPatch(
            file_path="models/d.sql",
            before_content="select 1",
            after_content="select 1 where x = 1",
            proposal_meta={"status": "proposed"},
            status="proposed",
        )

    def test_frozen_normal_assignment_raises(self):
        p = self._fresh()
        import pytest

        with pytest.raises(dataclasses.FrozenInstanceError):
            p.file_path = "other"  # type: ignore[misc]

    def test_asdict_roundtrip(self):
        p = self._fresh()
        d = dataclasses.asdict(p)
        assert d["file_path"] == "models/d.sql"
        assert d["proposal_meta"]["status"] == "proposed"
