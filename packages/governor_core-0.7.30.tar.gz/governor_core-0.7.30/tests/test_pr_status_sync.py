"""Unit tests for PR status sync (spec 038)."""

from __future__ import annotations

from unittest.mock import MagicMock


from governor_core.github.client import GitHubConnectionError
from governor_core.pullrequests.sync import sync_open_prs
from tests.helpers import _create_test_pr_record, _create_test_prereqs


class TestSyncOpenPRs:
    """Tests for sync_open_prs()."""

    def test_merged_pr_updates_status(self, client, db):
        """When GitHub says PR is merged, record status → merged."""
        prereqs = _create_test_prereqs(db)
        prereqs["opportunity"].status = "pr_pending"
        db.commit()
        pr_record = _create_test_pr_record(db, prereqs, status="open")

        mock_gh = MagicMock()
        mock_gh.get_pull_request.return_value = {
            "state": "closed",
            "merged": True,
            "merged_at": "2026-02-20T12:00:00",
        }

        result = sync_open_prs(db, mock_gh)

        db.refresh(pr_record)
        assert pr_record.status == "merged"
        assert pr_record.merged_at is not None
        assert result["merged"] == 1
        assert result["closed"] == 0

        # Opportunity transitions to resolved with cost tracking initiated
        db.refresh(prereqs["opportunity"])
        assert prereqs["opportunity"].status == "resolved"
        assert prereqs["opportunity"].resolved_at is not None
        assert prereqs["opportunity"].verified_savings_status == "pending"

    def test_closed_pr_reverts_opportunity(self, client, db):
        """When GitHub says PR is closed (not merged), opportunity → active."""
        prereqs = _create_test_prereqs(db)
        prereqs["opportunity"].status = "pr_pending"
        db.commit()
        pr_record = _create_test_pr_record(db, prereqs, status="open")

        mock_gh = MagicMock()
        mock_gh.get_pull_request.return_value = {
            "state": "closed",
            "merged": False,
            "merged_at": None,
        }

        result = sync_open_prs(db, mock_gh)

        db.refresh(pr_record)
        assert pr_record.status == "closed"
        assert result["closed"] == 1

        # Opportunity reverts to active
        db.refresh(prereqs["opportunity"])
        assert prereqs["opportunity"].status == "active"

    def test_still_open_pr_no_change(self, client, db):
        """When GitHub says PR is still open, nothing changes."""
        prereqs = _create_test_prereqs(db)
        prereqs["opportunity"].status = "pr_pending"
        db.commit()
        pr_record = _create_test_pr_record(db, prereqs, status="open")

        mock_gh = MagicMock()
        mock_gh.get_pull_request.return_value = {
            "state": "open",
            "merged": False,
            "merged_at": None,
        }

        result = sync_open_prs(db, mock_gh)

        db.refresh(pr_record)
        assert pr_record.status == "open"
        assert result["checked"] == 1
        assert result["merged"] == 0
        assert result["closed"] == 0

    def test_github_error_isolated(self, client, db):
        """GitHub API errors don't crash the sync — counted as errors."""
        prereqs = _create_test_prereqs(db)
        prereqs["opportunity"].status = "pr_pending"
        db.commit()
        pr_record = _create_test_pr_record(db, prereqs, status="open")

        mock_gh = MagicMock()
        mock_gh.get_pull_request.side_effect = GitHubConnectionError("timeout")

        result = sync_open_prs(db, mock_gh)

        db.refresh(pr_record)
        assert pr_record.status == "open"  # unchanged
        assert result["errors"] == 1

    def test_no_open_prs_returns_zero(self, client, db):
        """When there are no open PR records, nothing happens."""
        mock_gh = MagicMock()

        result = sync_open_prs(db, mock_gh)

        assert result == {"checked": 0, "merged": 0, "closed": 0, "errors": 0}
        mock_gh.get_pull_request.assert_not_called()

    def test_closed_pr_already_active_opportunity(self, client, db):
        """Closing a PR for an already-active opportunity doesn't break."""
        prereqs = _create_test_prereqs(db)
        # Opportunity is already active (not pr_pending)
        prereqs["opportunity"].status = "active"
        db.commit()
        pr_record = _create_test_pr_record(db, prereqs, status="open")

        mock_gh = MagicMock()
        mock_gh.get_pull_request.return_value = {
            "state": "closed",
            "merged": False,
            "merged_at": None,
        }

        result = sync_open_prs(db, mock_gh)

        db.refresh(pr_record)
        assert pr_record.status == "closed"
        # Opportunity stays active (was already active)
        db.refresh(prereqs["opportunity"])
        assert prereqs["opportunity"].status == "active"
        assert result["closed"] == 1


class TestDownstreamSolutionClearing:
    """Tests for downstream solution clearing when a PR merges."""

    def test_merged_pr_clears_sibling_solutions(self, client, db):
        """When a PR merges, solutions for sibling opportunities in same config are deleted."""
        import uuid

        from governor_core.solutions.models import Solution, SolutionJob

        prereqs = _create_test_prereqs(db)
        config = prereqs["config"]
        upstream_opp = prereqs["opportunity"]
        upstream_opp.status = "pr_pending"

        # Create a downstream sibling opportunity with a solution
        from decimal import Decimal

        from governor_core.opportunities.models import Opportunity

        downstream_opp = Opportunity(
            id=str(uuid.uuid4()),
            config_id=config.id,
            first_detection_job_id=prereqs["detection_job"].id,
            manifest_version_id=prereqs["manifest_version"].id,
            opportunity_type="slot_contention",
            affected_table="project.dataset.int_downstream_model",
            severity_score=50,
            evidence_snapshot={},
            current_cost_estimate=Decimal("10.00"),
            expected_savings=Decimal("3.00"),
            explanation="Downstream issue caused by upstream model",
            related_job_ids=["job-1"],
            status="active",
        )
        db.add(downstream_opp)
        db.flush()

        # Add a solution for the downstream opportunity
        sol_job = SolutionJob(
            id=str(uuid.uuid4()),
            opportunity_id=downstream_opp.id,
            config_id=config.id,
            status="completed",
        )
        db.add(sol_job)
        db.flush()
        sol = Solution(
            id=str(uuid.uuid4()),
            opportunity_id=downstream_opp.id,
            solution_job_id=sol_job.id,
            manifest_version_id=prereqs["manifest_version"].id,
            resolution_category="dbt_project_change",
            version_number=1,
            file_path="models/int/int_downstream.sql",
            change_type="sql_change",
            before_content="SELECT * FROM stg",
            after_content="SELECT id FROM stg",
            repository="owner/repo",
            explanation="Fix downstream",
            risk_level="low",
            risk_justification="Test",
        )
        db.add(sol)
        db.commit()

        _create_test_pr_record(db, prereqs, status="open")

        mock_gh = MagicMock()
        mock_gh.get_pull_request.return_value = {
            "state": "closed",
            "merged": True,
            "merged_at": "2026-02-20T12:00:00",
        }

        sync_open_prs(db, mock_gh)

        # Downstream solution should be deleted
        remaining = (
            db.query(Solution)
            .filter(Solution.opportunity_id == downstream_opp.id)
            .count()
        )
        assert remaining == 0

        # Downstream dry-run costs should be cleared
        db.refresh(downstream_opp)
        assert downstream_opp.latest_solution_dry_run_original_cost is None
        assert downstream_opp.latest_solution_dry_run_modified_cost is None


class TestGetPullRequest:
    """Tests for GitHubAppClient.get_pull_request()."""

    def test_get_pull_request_returns_state(self):
        """Verifies the method signature and return shape."""
        from unittest.mock import patch

        from governor_core.github.client import GitHubAppClient

        client = GitHubAppClient.__new__(GitHubAppClient)

        mock_pr = MagicMock()
        mock_pr.state = "closed"
        mock_pr.merged = True
        mock_pr.merged_at = None

        mock_repo = MagicMock()
        mock_repo.get_pull.return_value = mock_pr

        mock_gh = MagicMock()
        mock_gh.get_repo.return_value = mock_repo

        with patch.object(client, "_get_installation_github", return_value=mock_gh):
            result = client.get_pull_request("owner/repo", 42)

        assert result["state"] == "closed"
        assert result["merged"] is True
        mock_repo.get_pull.assert_called_once_with(42)
