"""Unit tests for safe change templates (US1)."""

from types import SimpleNamespace

from governor_core.solutions.templates import get_registry, match_template
from governor_core.solutions.templates.add_cluster_by import AddClusterByTemplate
from governor_core.solutions.templates.add_join_key_cluster import AddJoinKeyClusterTemplate
from governor_core.solutions.templates.add_partition_by import AddPartitionByTemplate
from governor_core.solutions.templates.add_require_partition_filter import (
    AddRequirePartitionFilterTemplate,
)
from governor_core.solutions.templates.base import TemplateResult


def _make_opportunity(opp_type: str, evidence: dict | None = None):
    """Create a mock opportunity object."""
    return SimpleNamespace(
        id="opp-1",
        opportunity_type=opp_type,
        evidence_snapshot=evidence or {},
        dbt_model_name="my_model",
        affected_table="project.dataset.my_model",
    )


_BASIC_SQL = """\
{{ config(
    materialized="table"
) }}

SELECT
    id,
    name
FROM {{ ref('source_table') }}
"""

_SQL_WITH_CLUSTER = """\
{{ config(
    materialized="table",
    cluster_by=["customer_id"]
) }}

SELECT id FROM source
"""

_SQL_WITH_PARTITION = """\
{{ config(
    materialized="table",
    partition_by={"field": "created_at", "data_type": "date"}
) }}

SELECT id, created_at FROM source
"""

_SQL_WITH_JOIN = """\
{{ config(
    materialized="table"
) }}

SELECT
    o.id,
    o.customer_id,
    li.product_id,
    li.amount
FROM {{ ref('orders') }} o
JOIN {{ ref('line_items') }} li ON o.id = li.order_id
"""

_SQL_WITH_MULTIPLE_JOINS = """\
{{ config(
    materialized="table"
) }}

SELECT
    o.id,
    c.name,
    p.title
FROM {{ ref('orders') }} o
JOIN {{ ref('customers') }} c ON o.customer_id = c.id
JOIN {{ ref('products') }} p ON o.product_id = p.id
"""

_SQL_WITH_JOIN_AND_CLUSTER = """\
{{ config(
    materialized="table",
    cluster_by=["id"]
) }}

SELECT o.id, li.amount
FROM orders o
JOIN line_items li ON o.id = li.order_id
"""

_SQL_CROSS_JOIN = """\
{{ config(
    materialized="table"
) }}

SELECT a.id, b.val
FROM table_a a
CROSS JOIN table_b b
"""

_PLAIN_SQL = "SELECT id, name FROM source"

_METADATA = {"original_file_path": "models/my_model.sql"}


# ===== AddClusterByTemplate Tests =====


class TestAddClusterByTemplate:
    def setup_method(self):
        self.template = AddClusterByTemplate()

    def test_basic_application_no_existing_config(self):
        opp = _make_opportunity(
            "shuffle_spill",
            {"recommended_cluster_columns": ["customer_id", "order_date"]},
        )
        source_files = {"models/my_model.sql": _PLAIN_SQL}
        result = self.template.apply(opp, source_files, _METADATA)
        assert result is not None
        assert isinstance(result, TemplateResult)
        assert "cluster_by" in result.after_content
        assert "customer_id" in result.after_content
        assert "order_date" in result.after_content
        assert result.template_id == "add_cluster_by"
        assert result.change_type == "project_config_change"

    def test_existing_config_block_inserts_property(self):
        opp = _make_opportunity(
            "shuffle_spill",
            {"recommended_cluster_columns": ["customer_id"]},
        )
        source_files = {"models/my_model.sql": _BASIC_SQL}
        result = self.template.apply(opp, source_files, _METADATA)
        assert result is not None
        assert "cluster_by" in result.after_content
        assert "materialized" in result.after_content  # Preserves existing

    def test_existing_cluster_by_merges_columns(self):
        opp = _make_opportunity(
            "shuffle_spill",
            {"recommended_cluster_columns": ["customer_id", "order_date"]},
        )
        source_files = {"models/my_model.sql": _SQL_WITH_CLUSTER}
        result = self.template.apply(opp, source_files, _METADATA)
        assert result is not None
        assert "order_date" in result.after_content
        assert "customer_id" in result.after_content

    def test_missing_evidence_columns_returns_none(self):
        opp = _make_opportunity("shuffle_spill", {})
        source_files = {"models/my_model.sql": _BASIC_SQL}
        assert self.template.matches(opp, source_files, _METADATA) is False

    def test_idempotent_same_columns_returns_none(self):
        opp = _make_opportunity(
            "shuffle_spill",
            {"recommended_cluster_columns": ["customer_id"]},
        )
        source_files = {"models/my_model.sql": _SQL_WITH_CLUSTER}
        result = self.template.apply(opp, source_files, _METADATA)
        assert result is None  # Already has the same column

    def test_rollback_instructions(self):
        instructions = self.template.rollback_instructions()
        assert "cluster_by" in instructions.lower()

    def test_wrong_opportunity_type(self):
        opp = _make_opportunity(
            "join_explosion",
            {"recommended_cluster_columns": ["id"]},
        )
        source_files = {"models/my_model.sql": _BASIC_SQL}
        assert self.template.matches(opp, source_files, _METADATA) is False

    def test_no_source_files(self):
        opp = _make_opportunity(
            "shuffle_spill",
            {"recommended_cluster_columns": ["id"]},
        )
        assert self.template.matches(opp, {}, _METADATA) is False

    def test_top_shuffle_keys_fallback(self):
        opp = _make_opportunity(
            "shuffle_spill",
            {"top_shuffle_keys": ["col_a", "col_b"]},
        )
        source_files = {"models/my_model.sql": _BASIC_SQL}
        result = self.template.apply(opp, source_files, _METADATA)
        assert result is not None
        assert "col_a" in result.after_content


# ===== AddPartitionByTemplate Tests =====


class TestAddPartitionByTemplate:
    def setup_method(self):
        self.template = AddPartitionByTemplate()

    def test_basic_application(self):
        opp = _make_opportunity(
            "partition_pruning",
            {
                "recommended_partition_column": "created_at",
                "partition_data_type": "date",
            },
        )
        source_files = {"models/my_model.sql": _BASIC_SQL}
        result = self.template.apply(opp, source_files, _METADATA)
        assert result is not None
        assert "partition_by" in result.after_content
        assert "created_at" in result.after_content
        assert result.template_id == "add_partition_by"

    def test_existing_config_block(self):
        opp = _make_opportunity(
            "partition_pruning",
            {"recommended_partition_column": "created_at"},
        )
        source_files = {"models/my_model.sql": _BASIC_SQL}
        result = self.template.apply(opp, source_files, _METADATA)
        assert result is not None
        assert "materialized" in result.after_content  # Preserves existing

    def test_existing_partition_same_column_skips(self):
        opp = _make_opportunity(
            "partition_pruning",
            {"recommended_partition_column": "created_at"},
        )
        source_files = {"models/my_model.sql": _SQL_WITH_PARTITION}
        assert self.template.matches(opp, source_files, _METADATA) is False

    def test_existing_partition_different_column_skips(self):
        opp = _make_opportunity(
            "partition_pruning",
            {"recommended_partition_column": "updated_at"},
        )
        source_files = {"models/my_model.sql": _SQL_WITH_PARTITION}
        assert self.template.matches(opp, source_files, _METADATA) is False

    def test_missing_partition_column_returns_false(self):
        opp = _make_opportunity("partition_pruning", {})
        source_files = {"models/my_model.sql": _BASIC_SQL}
        assert self.template.matches(opp, source_files, _METADATA) is False

    def test_rollback_instructions(self):
        instructions = self.template.rollback_instructions()
        assert "partition_by" in instructions.lower()


# ===== AddRequirePartitionFilterTemplate Tests =====


class TestAddRequirePartitionFilterTemplate:
    def setup_method(self):
        self.template = AddRequirePartitionFilterTemplate()

    def test_basic_application(self):
        opp = _make_opportunity("partition_pruning", {})
        source_files = {"models/my_model.sql": _SQL_WITH_PARTITION}
        result = self.template.apply(opp, source_files, _METADATA)
        assert result is not None
        assert "require_partition_filter" in result.after_content
        assert result.template_id == "add_require_partition_filter"

    def test_already_true_skips(self):
        sql = """\
{{ config(
    materialized="table",
    partition_by={"field": "created_at", "data_type": "date"},
    require_partition_filter=true
) }}

SELECT id FROM source
"""
        opp = _make_opportunity("partition_pruning", {})
        source_files = {"models/my_model.sql": sql}
        assert self.template.matches(opp, source_files, _METADATA) is False

    def test_already_false_skips(self):
        sql = """\
{{ config(
    materialized="table",
    partition_by={"field": "created_at", "data_type": "date"},
    require_partition_filter=false
) }}

SELECT id FROM source
"""
        opp = _make_opportunity("partition_pruning", {})
        source_files = {"models/my_model.sql": sql}
        assert self.template.matches(opp, source_files, _METADATA) is False

    def test_no_partition_by_skips(self):
        opp = _make_opportunity("partition_pruning", {})
        source_files = {"models/my_model.sql": _BASIC_SQL}
        assert self.template.matches(opp, source_files, _METADATA) is False

    def test_no_config_block_skips(self):
        opp = _make_opportunity("partition_pruning", {})
        source_files = {"models/my_model.sql": _PLAIN_SQL}
        assert self.template.matches(opp, source_files, _METADATA) is False

    def test_rollback_instructions(self):
        instructions = self.template.rollback_instructions()
        assert "require_partition_filter" in instructions.lower()


# ===== Template Registry Tests =====


class TestTemplateRegistry:
    def test_registry_has_builtin_templates(self):
        registry = get_registry()
        template_ids = [t.template_id for t in registry]
        # Cluster templates disabled (spec 039) — pending data lineage analysis
        assert "add_cluster_by" not in template_ids
        assert "add_join_key_cluster" not in template_ids
        # partition_by self-targeting template disabled (spec 047)
        assert "add_partition_by" not in template_ids
        # Storage billing template remains active
        assert "switch_storage_billing" in template_ids
        assert "remove_redundant_order_bys" in template_ids
        assert "remove_unused_joins" in template_ids
        # add_require_partition_filter is gated on GOVERNOR_LOCAL_MODE (spec 127).
        # Presence in the registry tracks the mode the test process was
        # imported under — verified explicitly in test_require_partition_filter_mode_gating.

    def test_require_partition_filter_mode_gating(self, monkeypatch):
        """Spec 127: template registers only in local/CLI mode."""
        import importlib

        import governor_core.core.config as config_module
        import governor_core.solutions.templates as templates_module

        # Local mode → template is registered.
        monkeypatch.setenv("GOVERNOR_LOCAL_MODE", "true")
        importlib.reload(config_module)
        reloaded = importlib.reload(templates_module)
        local_ids = [t.template_id for t in reloaded.get_registry()]
        assert "add_require_partition_filter" in local_ids

        # Cloud/default mode → template is absent.
        monkeypatch.delenv("GOVERNOR_LOCAL_MODE", raising=False)
        importlib.reload(config_module)
        reloaded = importlib.reload(templates_module)
        cloud_ids = [t.template_id for t in reloaded.get_registry()]
        assert "add_require_partition_filter" not in cloud_ids

    def test_no_match_shuffle_spill(self):
        """shuffle_spill no longer matches — cluster template disabled (spec 039)."""
        opp = _make_opportunity(
            "shuffle_spill",
            {"recommended_cluster_columns": ["id"]},
        )
        source_files = {"models/my_model.sql": _BASIC_SQL}
        result = match_template(opp, source_files, _METADATA)
        assert result is None

    def test_match_partition_pruning_no_partition(self):
        """partition_pruning without partition_by: no template matches — neither
        add_partition_by (disabled, spec 047) nor add_require_partition_filter
        (requires partition_by to already be set)."""
        opp = _make_opportunity(
            "partition_pruning",
            {"recommended_partition_column": "created_at"},
        )
        source_files = {"models/my_model.sql": _BASIC_SQL}
        result = match_template(opp, source_files, _METADATA)
        assert result is None

    def test_match_partition_pruning_has_partition_local_mode(self, monkeypatch):
        """Spec 127: partition_pruning on a partitioned model matches
        add_require_partition_filter in local/CLI mode."""
        import importlib

        import governor_core.core.config as config_module
        import governor_core.solutions.templates as templates_module

        monkeypatch.setenv("GOVERNOR_LOCAL_MODE", "true")
        importlib.reload(config_module)
        reloaded = importlib.reload(templates_module)

        opp = _make_opportunity("partition_pruning", {})
        source_files = {"models/my_model.sql": _SQL_WITH_PARTITION}
        result = reloaded.match_template(opp, source_files, _METADATA)

        assert result is not None
        assert result.template_id == "add_require_partition_filter"
        assert "require_partition_filter" in result.after_content

    def test_match_partition_pruning_has_partition_cloud_mode(self, monkeypatch):
        """Spec 127: in cloud/PR mode the template stays inert."""
        import importlib

        import governor_core.core.config as config_module
        import governor_core.solutions.templates as templates_module

        monkeypatch.delenv("GOVERNOR_LOCAL_MODE", raising=False)
        importlib.reload(config_module)
        reloaded = importlib.reload(templates_module)

        opp = _make_opportunity("partition_pruning", {})
        source_files = {"models/my_model.sql": _SQL_WITH_PARTITION}
        result = reloaded.match_template(opp, source_files, _METADATA)

        assert result is None

    def test_no_match_join_explosion_no_joins(self):
        """join_explosion with SQL that has no JOINs → no template match."""
        opp = _make_opportunity("join_explosion", {})
        source_files = {"models/my_model.sql": _BASIC_SQL}
        result = match_template(opp, source_files, _METADATA)
        assert result is None

    def test_no_match_join_explosion_with_joins(self):
        """join_explosion with JOINs no longer matches — cluster template disabled (spec 039)."""
        opp = _make_opportunity("join_explosion", {})
        source_files = {"models/my_model.sql": _SQL_WITH_JOIN}
        result = match_template(opp, source_files, _METADATA)
        assert result is None

    def test_no_match_no_source_files(self):
        opp = _make_opportunity(
            "partition_pruning",
            {"recommended_partition_column": "created_at"},
        )
        result = match_template(opp, None, _METADATA)
        assert result is None

    def test_template_result_dataclass_fields(self):
        """TemplateResult from the only active template has expected fields."""
        opp = _make_opportunity(
            "storage_billing_optimization",
            {
                "dataset": "project.my_dataset",
                "compression_ratio": 2.5,
                "monthly_savings": 50,
            },
        )
        source_files = {}
        result = match_template(opp, source_files, _METADATA)
        assert result is not None
        assert result.template_id == "switch_storage_billing"
        assert result.explanation
        assert isinstance(result.parameters, dict)
        assert isinstance(result.rollback, str)
        assert "my_dataset" in result.rollback

    def test_registry_no_join_key_cluster(self):
        """join_key_cluster not in registry — disabled (spec 039)."""
        registry = get_registry()
        template_ids = [t.template_id for t in registry]
        assert "add_join_key_cluster" not in template_ids


# ===== AddJoinKeyClusterTemplate Tests =====


class TestAddJoinKeyClusterTemplate:
    def setup_method(self):
        self.template = AddJoinKeyClusterTemplate()

    def test_basic_join_extracts_columns(self):
        opp = _make_opportunity("join_explosion", {})
        source_files = {"models/my_model.sql": _SQL_WITH_JOIN}
        result = self.template.apply(opp, source_files, _METADATA)
        assert result is not None
        assert isinstance(result, TemplateResult)
        assert "cluster_by" in result.after_content
        assert result.template_id == "add_join_key_cluster"
        assert result.change_type == "project_config_change"
        # Should extract columns from ON o.id = li.order_id
        assert "id" in result.parameters["columns"]
        assert "order_id" in result.parameters["columns"]

    def test_multiple_joins(self):
        opp = _make_opportunity("join_explosion", {})
        source_files = {"models/my_model.sql": _SQL_WITH_MULTIPLE_JOINS}
        result = self.template.apply(opp, source_files, _METADATA)
        assert result is not None
        params = result.parameters["columns"]
        # Should find columns from both JOINs
        assert "customer_id" in params
        assert "product_id" in params

    def test_max_four_columns(self):
        sql = """\
{{ config(materialized="table") }}

SELECT a.x FROM t a
JOIN t1 ON a.c1 = t1.c1
JOIN t2 ON a.c2 = t2.c2
JOIN t3 ON a.c3 = t3.c3
JOIN t4 ON a.c4 = t4.c4
JOIN t5 ON a.c5 = t5.c5
"""
        opp = _make_opportunity("join_explosion", {})
        source_files = {"models/my_model.sql": sql}
        result = self.template.apply(opp, source_files, _METADATA)
        assert result is not None
        assert len(result.parameters["columns"]) <= 4

    def test_existing_cluster_by_merges(self):
        opp = _make_opportunity("join_explosion", {})
        source_files = {"models/my_model.sql": _SQL_WITH_JOIN_AND_CLUSTER}
        result = self.template.apply(opp, source_files, _METADATA)
        assert result is not None
        # Should have original "id" plus new "order_id"
        assert "order_id" in result.after_content
        assert "id" in result.after_content

    def test_idempotent_same_columns(self):
        # cluster_by already has "id", JOIN key is also "id" + "order_id"
        # After first apply, apply again with same SQL
        opp = _make_opportunity("join_explosion", {})
        source_files = {"models/my_model.sql": _SQL_WITH_JOIN_AND_CLUSTER}
        result = self.template.apply(opp, source_files, _METADATA)
        assert result is not None
        # Now apply again with the result
        source_files2 = {"models/my_model.sql": result.after_content}
        result2 = self.template.apply(opp, source_files2, _METADATA)
        assert result2 is None  # No change needed

    def test_no_joins_skips(self):
        opp = _make_opportunity("join_explosion", {})
        source_files = {"models/my_model.sql": _BASIC_SQL}
        assert self.template.matches(opp, source_files, _METADATA) is False

    def test_cross_join_no_on_skips(self):
        opp = _make_opportunity("join_explosion", {})
        source_files = {"models/my_model.sql": _SQL_CROSS_JOIN}
        assert self.template.matches(opp, source_files, _METADATA) is False

    def test_wrong_opportunity_type(self):
        opp = _make_opportunity("shuffle_spill", {})
        source_files = {"models/my_model.sql": _SQL_WITH_JOIN}
        assert self.template.matches(opp, source_files, _METADATA) is False

    def test_no_source_files(self):
        opp = _make_opportunity("join_explosion", {})
        assert self.template.matches(opp, {}, _METADATA) is False

    def test_rollback_instructions(self):
        instructions = self.template.rollback_instructions()
        assert "cluster_by" in instructions.lower()

    def test_plain_sql_without_config_block(self):
        sql = "SELECT o.id FROM orders o JOIN items i ON o.id = i.order_id"
        opp = _make_opportunity("join_explosion", {})
        source_files = {"models/my_model.sql": sql}
        result = self.template.apply(opp, source_files, _METADATA)
        assert result is not None
        assert "config" in result.after_content
        assert "cluster_by" in result.after_content
