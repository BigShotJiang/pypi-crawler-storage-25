"""Unit tests for app/solutions/templates/switch_storage_billing.py."""

from types import SimpleNamespace

from governor_core.solutions.templates.base import TemplateResult
from governor_core.solutions.templates.switch_storage_billing import SwitchStorageBillingTemplate


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_opportunity(
    opp_type: str = "storage_billing_optimization",
    evidence: dict | None = None,
):
    return SimpleNamespace(
        id="opp-1",
        opportunity_type=opp_type,
        evidence_snapshot=evidence or {},
        dbt_model_name="my_model",
        affected_table="project.dataset.my_dataset",
    )


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


class TestSwitchStorageBillingTemplate:
    def setup_method(self):
        self.template = SwitchStorageBillingTemplate()

    def test_matches_storage_billing_type(self):
        """Matches when opportunity_type is storage_billing_optimization."""
        opp = _make_opportunity()
        assert self.template.matches(opp, {}, None) is True

    def test_no_match_wrong_type(self):
        """Does not match when opportunity_type is different."""
        opp = _make_opportunity(opp_type="shuffle_spill")
        assert self.template.matches(opp, {}, None) is False

    def test_apply_generates_ddl(self):
        """Apply generates ALTER SCHEMA DDL in explanation."""
        opp = _make_opportunity(
            evidence={
                "dataset": "my_dataset",
                "compression_ratio": 2.5,
                "logical_cost_monthly": 100,
                "physical_cost_monthly": 40,
                "monthly_savings": 60,
                "annual_savings": 720,
                "savings_percentage": 60,
            },
        )
        result = self.template.apply(opp, {}, None)

        assert result is not None
        assert isinstance(result, TemplateResult)
        assert result.template_id == "switch_storage_billing"
        assert "ALTER SCHEMA" in result.explanation
        assert "my_dataset" in result.explanation
        assert "PHYSICAL" in result.explanation

    def test_apply_strips_project_prefix(self):
        """Dataset 'project.my_dataset' is stripped to 'my_dataset' in DDL."""
        opp = _make_opportunity(
            evidence={"dataset": "project.my_dataset"},
        )
        result = self.template.apply(opp, {}, None)

        assert result is not None
        assert result.parameters["dataset_short"] == "my_dataset"
        assert "ALTER SCHEMA `my_dataset`" in result.parameters["ddl"]

    def test_apply_parameters_contain_ddl_and_rollback(self):
        """Result parameters include DDL, rollback DDL, and resource info."""
        opp = _make_opportunity(
            evidence={"dataset": "analytics"},
        )
        result = self.template.apply(opp, {}, None)

        assert result is not None
        params = result.parameters
        assert "ddl" in params
        assert "rollback_ddl" in params
        assert "PHYSICAL" in params["ddl"]
        assert "LOGICAL" in params["rollback_ddl"]
        assert params["resolution_category"] == "bigquery_infrastructure"
        assert params["current_setting_value"] == "LOGICAL"
        assert params["recommended_setting_value"] == "PHYSICAL"
        assert params["affected_resource"] == "analytics"
        assert params["dataset"] == "analytics"
        assert params["dataset_short"] == "analytics"

    def test_apply_uses_evidence_fields(self):
        """Explanation includes compression_ratio, costs, and savings from evidence."""
        opp = _make_opportunity(
            evidence={
                "dataset": "billing_data",
                "compression_ratio": 3.2,
                "logical_cost_monthly": 200,
                "physical_cost_monthly": 62.5,
                "monthly_savings": 137.5,
                "annual_savings": 1650,
                "savings_percentage": 68.75,
            },
        )
        result = self.template.apply(opp, {}, None)

        assert result is not None
        assert "3.2" in result.explanation  # compression_ratio
        assert "200" in result.explanation  # logical_cost
        assert "62.5" in result.explanation  # physical_cost
        assert "137.5" in result.explanation  # monthly_savings
        assert "1650" in result.explanation  # annual_savings
        assert "68.75" in result.explanation  # savings_percentage

    def test_result_policy_tags_bigquery_infrastructure(self):
        """Result policy_tags should be ['bigquery_infrastructure']."""
        opp = _make_opportunity(evidence={"dataset": "ds"})
        result = self.template.apply(opp, {}, None)

        assert result is not None
        assert result.policy_tags == ["bigquery_infrastructure"]

    def test_rollback_instructions(self):
        """Rollback DDL reverts to LOGICAL billing."""
        opp = _make_opportunity(
            evidence={"dataset": "my_dataset"},
        )
        result = self.template.apply(opp, {}, None)

        assert result is not None
        assert "LOGICAL" in result.rollback
        assert "my_dataset" in result.rollback

    def test_result_empty_file_fields(self):
        """Infrastructure change has empty file_path and content fields."""
        opp = _make_opportunity(evidence={"dataset": "ds"})
        result = self.template.apply(opp, {}, None)

        assert result is not None
        assert result.file_path == ""
        assert result.before_content == ""
        assert result.after_content == ""

    def test_apply_fallback_to_affected_table(self):
        """When evidence has no dataset, falls back to opportunity.affected_table."""
        opp = _make_opportunity(evidence={})
        result = self.template.apply(opp, {}, None)

        assert result is not None
        # affected_table = "project.dataset.my_dataset" -> stripped to "my_dataset"
        assert result.parameters["dataset_short"] == "my_dataset"

    def test_apply_table_count_in_explanation(self):
        """When table_count is present in evidence, it appears in the explanation."""
        opp = _make_opportunity(
            evidence={"dataset": "analytics", "table_count": 42},
        )
        result = self.template.apply(opp, {}, None)

        assert result is not None
        assert "42 tables" in result.explanation
