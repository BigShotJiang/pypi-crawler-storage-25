"""Unit tests for enriched prompt sections in app/solutions/prompts.py."""

from __future__ import annotations


from governor_core.solutions.prompts import build_prompt


def _base_kwargs():
    """Return minimal required kwargs for build_prompt()."""
    return {
        "opportunity_type": "partition_pruning",
        "affected_table": "project.dataset.orders",
        "severity_score": 75,
        "explanation": "Query scans all partitions",
        "evidence_snapshot": {"signal": "full_scan"},
    }


class TestEnrichedPromptSections:
    """Tests for enriched context sections in build_prompt()."""

    def test_includes_compiled_sql_section(self):
        """Should include ## Compiled SQL section when compiled_sql is provided."""
        prompt = build_prompt(
            **_base_kwargs(),
            compiled_sql="SELECT * FROM `project.dataset.raw_orders`",
        )
        assert "## Compiled SQL (What BigQuery Actually Executes)" in prompt
        assert "SELECT * FROM `project.dataset.raw_orders`" in prompt

    def test_omits_compiled_sql_when_none(self):
        """Should not include ## Compiled SQL section when compiled_sql is None."""
        prompt = build_prompt(**_base_kwargs())
        assert "## Compiled SQL" not in prompt

    def test_includes_upstream_models_section(self):
        """Should include ## Upstream Models section with model details."""
        upstreams = [
            {
                "name": "raw_orders",
                "materialized": "view",
                "raw_sql": "SELECT id FROM raw.orders",
                "compiled_sql": "SELECT id FROM `project.dataset.raw_orders`",
                "partition_by": {"field": "order_date"},
                "cluster_by": ["customer_id"],
            }
        ]
        prompt = build_prompt(**_base_kwargs(), upstream_models=upstreams)
        assert "## Upstream Models (Direct Dependencies)" in prompt
        assert "model: raw_orders" in prompt
        assert "materialized: view" in prompt
        assert "partitioned: order_date" in prompt
        assert "clustered: customer_id" in prompt

    def test_omits_upstream_when_none(self):
        """Should not include ## Upstream Models when upstream_models is None."""
        prompt = build_prompt(**_base_kwargs())
        assert "## Upstream Models" not in prompt

    def test_includes_downstream_dependents_section(self):
        """Should include ## Downstream Dependents section."""
        dependents = [
            {
                "name": "fct_revenue",
                "materialized": "incremental",
                "partition_by": {"field": "event_date"},
            },
            {"name": "rpt_daily_sales", "materialized": "table"},
        ]
        prompt = build_prompt(**_base_kwargs(), downstream_dependents=dependents)
        assert "## Downstream Dependents" in prompt
        assert "fct_revenue" in prompt
        assert "rpt_daily_sales" in prompt
        assert "materialized: incremental" in prompt

    def test_omits_downstream_when_none(self):
        """Should not include ## Downstream Dependents when None."""
        prompt = build_prompt(**_base_kwargs())
        assert "## Downstream Dependents" not in prompt

    def test_includes_dry_run_baseline_section(self):
        """Should include ## Dry-Run Baseline section."""
        baseline = {"total_bytes_processed": 2341567890, "estimated_cost_usd": 14.63}
        prompt = build_prompt(**_base_kwargs(), dry_run_baseline=baseline)
        assert "## Dry-Run Baseline" in prompt
        assert "2,341,567,890 bytes" in prompt
        assert "$14.63" in prompt

    def test_omits_dry_run_baseline_when_none(self):
        prompt = build_prompt(**_base_kwargs())
        assert "## Dry-Run Baseline" not in prompt

    def test_includes_macro_summary_section(self):
        """Should include ## Available Project Macros section."""
        macros = [
            {
                "name": "generate_schema_name",
                "arguments": ["custom_schema_name", "node"],
            },
            {"name": "cents_to_dollars", "arguments": ["column_name"]},
        ]
        prompt = build_prompt(**_base_kwargs(), macro_summary=macros)
        assert "## Available Project Macros" in prompt
        assert "generate_schema_name(custom_schema_name, node)" in prompt
        assert "cents_to_dollars(column_name)" in prompt

    def test_omits_macros_when_none(self):
        prompt = build_prompt(**_base_kwargs())
        assert "## Available Project Macros" not in prompt

    def test_all_enriched_sections_together(self):
        """Should include all enriched sections when all are provided."""
        prompt = build_prompt(
            **_base_kwargs(),
            compiled_sql="SELECT 1",
            upstream_models=[{"name": "parent", "materialized": "table"}],
            downstream_dependents=[{"name": "child", "materialized": "view"}],
            dry_run_baseline={
                "total_bytes_processed": 1000,
                "estimated_cost_usd": 0.01,
            },
            macro_summary=[{"name": "my_macro", "arguments": ["arg1"]}],
        )
        assert "## Compiled SQL" in prompt
        assert "## Upstream Models" in prompt
        assert "## Downstream Dependents" in prompt
        assert "## Dry-Run Baseline" in prompt
        assert "## Available Project Macros" in prompt

    def test_enriched_sections_appear_before_instructions(self):
        """Enriched sections should appear before the ## Instructions section."""
        prompt = build_prompt(
            **_base_kwargs(),
            source_files={"model.sql": "SELECT 1"},
            compiled_sql="SELECT 1",
        )
        compiled_idx = prompt.index("## Compiled SQL")
        instructions_idx = prompt.index("## Instructions")
        assert compiled_idx < instructions_idx
