"""Unit tests for ProfilesGenerator in app/dbt/profiles.py."""

from __future__ import annotations

import shutil
from pathlib import Path

import pytest
import yaml

from governor_core.dbt.profiles import ProfilesGenerator


class TestGenerateCompileProfiles:
    """Tests for generate_compile_profiles()."""

    def test_creates_profiles_yml_with_real_credentials(self):
        """profiles.yml should contain bigquery config with service-account method."""
        tmpdir = ProfilesGenerator.generate_compile_profiles(
            profile_name="my_project",
            gcp_project="test-gcp-project",
            dataset="analytics",
            keyfile_path="/path/to/service-account.json",
        )
        try:
            profiles_path = Path(tmpdir) / "profiles.yml"
            assert profiles_path.exists()

            content = yaml.safe_load(profiles_path.read_text())
            assert "my_project" in content

            output = content["my_project"]["outputs"]["governor"]
            assert output["type"] == "bigquery"
            assert output["method"] == "service-account"
            assert output["project"] == "test-gcp-project"
            assert output["dataset"] == "analytics"
            assert output["keyfile"] == "/path/to/service-account.json"
            assert output["threads"] == 1
        finally:
            shutil.rmtree(tmpdir, ignore_errors=True)

    def test_custom_keyfile_path(self):
        """Should respect custom keyfile_path."""
        tmpdir = ProfilesGenerator.generate_compile_profiles(
            profile_name="proj",
            gcp_project="proj-id",
            dataset="ds",
            keyfile_path="/custom/key.json",
        )
        try:
            content = yaml.safe_load((Path(tmpdir) / "profiles.yml").read_text())
            assert (
                content["proj"]["outputs"]["governor"]["keyfile"] == "/custom/key.json"
            )
        finally:
            shutil.rmtree(tmpdir, ignore_errors=True)

    def test_target_is_governor(self):
        """Target should always be 'governor'."""
        tmpdir = ProfilesGenerator.generate_compile_profiles(
            profile_name="test",
            gcp_project="p",
            dataset="d",
        )
        try:
            content = yaml.safe_load((Path(tmpdir) / "profiles.yml").read_text())
            assert content["test"]["target"] == "governor"
        finally:
            shutil.rmtree(tmpdir, ignore_errors=True)


class TestGenerateParseProfiles:
    """Tests for generate_parse_profiles()."""

    def test_creates_stub_profiles(self):
        """Parse profiles should use oauth method with stub project."""
        tmpdir = ProfilesGenerator.generate_parse_profiles(
            profile_name="my_project",
        )
        try:
            profiles_path = Path(tmpdir) / "profiles.yml"
            assert profiles_path.exists()

            content = yaml.safe_load(profiles_path.read_text())
            output = content["my_project"]["outputs"]["governor"]
            assert output["type"] == "bigquery"
            assert output["method"] == "oauth"
            assert output["project"] == "stub-project"
            assert output["dataset"] == "stub_dataset"
        finally:
            shutil.rmtree(tmpdir, ignore_errors=True)

    def test_no_keyfile_in_parse_profiles(self):
        """Parse profiles should not contain keyfile."""
        tmpdir = ProfilesGenerator.generate_parse_profiles(
            profile_name="test",
        )
        try:
            content = yaml.safe_load((Path(tmpdir) / "profiles.yml").read_text())
            output = content["test"]["outputs"]["governor"]
            assert "keyfile" not in output
        finally:
            shutil.rmtree(tmpdir, ignore_errors=True)


class TestExtractProfileName:
    """Tests for extract_profile_name()."""

    def test_extracts_profile_from_valid_yml(self):
        """Should return the profile name from dbt_project.yml."""
        content = "name: my_project\nversion: '1.0.0'\nprofile: 'my_dbt_profile'\n"
        assert ProfilesGenerator.extract_profile_name(content) == "my_dbt_profile"

    def test_raises_on_missing_profile_key(self):
        """Should raise ValueError when 'profile' key is missing."""
        content = "name: my_project\nversion: '1.0.0'\n"
        with pytest.raises(ValueError, match="'profile' key not found"):
            ProfilesGenerator.extract_profile_name(content)

    def test_raises_on_invalid_yaml(self):
        """Should raise ValueError when content is not a YAML mapping."""
        with pytest.raises(ValueError, match="not a valid YAML mapping"):
            ProfilesGenerator.extract_profile_name("just a string")

    def test_extracts_unquoted_profile(self):
        """Should handle unquoted profile names."""
        content = "name: proj\nprofile: my_profile\n"
        assert ProfilesGenerator.extract_profile_name(content) == "my_profile"
