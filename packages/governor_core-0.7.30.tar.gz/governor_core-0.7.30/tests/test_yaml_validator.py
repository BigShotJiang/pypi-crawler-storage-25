"""Tests for YAML structural comparison (app/solutions/validation/yaml_validator.py)."""

from __future__ import annotations

import pytest

from governor_core.solutions.validation.ast_validator import ParseError
from governor_core.solutions.validation.yaml_validator import compare_yaml


class TestIdenticalYaml:
    """Identical YAML documents produce an empty comparison."""

    def test_identical_yaml_returns_empty_comparison(self):
        yaml_content = """\
version: 2
models:
  - name: my_model
    columns:
      - name: id
        tests:
          - not_null
"""
        result = compare_yaml(yaml_content, yaml_content)

        assert result.keys_added == []
        assert result.keys_removed == []
        assert result.keys_modified == []


class TestColumnAddition:
    """Adding a column to a dbt model reports it in keys_added."""

    def test_added_column_detected(self):
        before = """\
version: 2
models:
  - name: my_model
    columns:
      - name: id
        tests:
          - not_null
"""
        after = """\
version: 2
models:
  - name: my_model
    columns:
      - name: id
        tests:
          - not_null
      - name: email
        tests:
          - unique
"""
        result = compare_yaml(before, after)

        # The named-list comparison matches by 'name', so the new
        # column 'email' is reported as added under the columns path.
        assert any("email" in k for k in result.keys_added)
        assert result.keys_removed == []
        assert result.keys_modified == []


class TestColumnRemoval:
    """Removing a column from a dbt model reports it in keys_removed."""

    def test_removed_column_detected(self):
        before = """\
version: 2
models:
  - name: my_model
    columns:
      - name: id
      - name: email
"""
        after = """\
version: 2
models:
  - name: my_model
    columns:
      - name: id
"""
        result = compare_yaml(before, after)

        assert any("email" in k for k in result.keys_removed)
        assert result.keys_added == []
        assert result.keys_modified == []


class TestTestValueChanged:
    """Changing a test value reports it in keys_modified."""

    def test_changed_test_value_detected(self):
        before = """\
version: 2
models:
  - name: my_model
    columns:
      - name: id
        tests:
          - not_null
"""
        after = """\
version: 2
models:
  - name: my_model
    columns:
      - name: id
        tests:
          - unique
"""
        result = compare_yaml(before, after)

        # The test list items changed (positional comparison since
        # they are scalars, not named dicts).
        assert len(result.keys_modified) > 0
        assert result.keys_added == []
        assert result.keys_removed == []


class TestModelEntryAdded:
    """Adding a new model entry reports it in keys_added."""

    def test_added_model_detected(self):
        before = """\
version: 2
models:
  - name: model_a
    columns:
      - name: id
"""
        after = """\
version: 2
models:
  - name: model_a
    columns:
      - name: id
  - name: model_b
    columns:
      - name: id
"""
        result = compare_yaml(before, after)

        assert any("model_b" in k for k in result.keys_added)
        assert result.keys_removed == []


class TestModelEntryRemoved:
    """Removing a model entry reports it in keys_removed."""

    def test_removed_model_detected(self):
        before = """\
version: 2
models:
  - name: model_a
    columns:
      - name: id
  - name: model_b
    columns:
      - name: id
"""
        after = """\
version: 2
models:
  - name: model_a
    columns:
      - name: id
"""
        result = compare_yaml(before, after)

        assert any("model_b" in k for k in result.keys_removed)
        assert result.keys_added == []


class TestInvalidYaml:
    """Invalid YAML raises ParseError (imported from ast_validator)."""

    def test_invalid_before_yaml_raises_parse_error(self):
        invalid_yaml = "{ invalid: yaml: [unclosed"
        valid_yaml = "key: value\n"

        with pytest.raises(ParseError, match="before"):
            compare_yaml(invalid_yaml, valid_yaml)

    def test_invalid_after_yaml_raises_parse_error(self):
        valid_yaml = "key: value\n"
        invalid_yaml = "{ invalid: yaml: [unclosed"

        with pytest.raises(ParseError, match="after"):
            compare_yaml(valid_yaml, invalid_yaml)


class TestEmptyYamlStrings:
    """Empty YAML strings are treated as empty dicts."""

    def test_both_empty_returns_empty_comparison(self):
        result = compare_yaml("", "")

        assert result.keys_added == []
        assert result.keys_removed == []
        assert result.keys_modified == []

    def test_empty_before_with_content_after(self):
        result = compare_yaml("", "key: value\n")

        assert "key" in result.keys_added
        assert result.keys_removed == []

    def test_content_before_with_empty_after(self):
        result = compare_yaml("key: value\n", "")

        assert "key" in result.keys_removed
        assert result.keys_added == []


class TestNestedChanges:
    """Nested structural changes are reported with dot-separated paths."""

    def test_nested_key_addition(self):
        before = """\
top:
  nested:
    existing: true
"""
        after = """\
top:
  nested:
    existing: true
    new_key: hello
"""
        result = compare_yaml(before, after)

        assert "top.nested.new_key" in result.keys_added
        assert result.keys_removed == []
        assert result.keys_modified == []

    def test_nested_key_removal(self):
        before = """\
top:
  nested:
    keep: true
    remove_me: gone
"""
        after = """\
top:
  nested:
    keep: true
"""
        result = compare_yaml(before, after)

        assert "top.nested.remove_me" in result.keys_removed
        assert result.keys_added == []

    def test_nested_value_modification(self):
        before = """\
top:
  nested:
    value: old
"""
        after = """\
top:
  nested:
    value: new
"""
        result = compare_yaml(before, after)

        assert "top.nested.value" in result.keys_modified
        assert result.keys_added == []
        assert result.keys_removed == []

    def test_deeply_nested_mixed_changes(self):
        before = """\
level1:
  level2:
    level3:
      keep: original
      remove: old
"""
        after = """\
level1:
  level2:
    level3:
      keep: changed
      add: new
"""
        result = compare_yaml(before, after)

        assert "level1.level2.level3.add" in result.keys_added
        assert "level1.level2.level3.remove" in result.keys_removed
        assert "level1.level2.level3.keep" in result.keys_modified
