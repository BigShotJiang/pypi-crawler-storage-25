"""CROSS JOIN without pre-aggregation detection rule.

Flags `CROSS JOIN` clauses (or comma-joins with no `ON`) where neither
side is an aggregation/distinct result. Such joins typically produce
cartesian-product output and are a flagged anti-pattern in Google's
"Optimize query computation" guide (Avoid cross joins).
"""

from __future__ import annotations

from decimal import Decimal
from typing import TYPE_CHECKING, Any

import sqlglot
from sqlglot import exp

from governor_core.opportunities.rules.base import BaseDetectionRule, OpportunityCandidate
from governor_core.opportunities.scoring import (
    calculate_severity,
    estimate_cost_from_bytes_processed,
)

if TYPE_CHECKING:
    from governor_core.sync.models import BigQueryJob


_CONFIDENCE = 0.80


class CrossJoinUnaggregatedRule(BaseDetectionRule):
    """Flag jobs that CROSS JOIN raw inputs without pre-aggregation."""

    @property
    def rule_type(self) -> str:
        return "cross_join_unaggregated"

    @property
    def display_name(self) -> str:
        return "CROSS JOIN without pre-aggregation"

    @property
    def description(self) -> str:
        return (
            "CROSS JOIN over raw inputs produces a cartesian product. Pre-aggregate "
            "one side with GROUP BY, or replace with a window function, to avoid "
            "blowing up the join output."
        )

    @property
    def default_thresholds(self) -> dict[str, Any]:
        return {"enabled": True}

    def detect(
        self,
        jobs: list[BigQueryJob],
        manifest_content: dict | None,
        thresholds: dict[str, Any],
    ) -> list[OpportunityCandidate]:
        candidates: list[OpportunityCandidate] = []
        for job in jobs:
            if not job.query or not job.destination_table:
                continue
            cross_count = _count_unaggregated_cross_joins(job.query)
            if cross_count <= 0:
                continue
            current_cost = _job_cost(job)
            evidence = {
                "cross_join_count": cross_count,
            }
            severity = calculate_severity(current_cost, _CONFIDENCE)
            candidates.append(
                OpportunityCandidate(
                    opportunity_type=self.rule_type,
                    affected_table=job.destination_table,
                    severity_score=severity,
                    evidence_snapshot=evidence,
                    current_cost_estimate=current_cost,
                    expected_savings=Decimal("0"),
                    explanation=(
                        f"Found {cross_count} CROSS JOIN(s) over un-aggregated "
                        f"inputs. Pre-aggregate one side with GROUP BY, or replace "
                        f"the cross-join with a window function over the larger side."
                    ),
                    related_job_ids=[job.job_id] if job.job_id else [],
                    dbt_model_name=self.correlate_dbt_model(
                        job.destination_table, manifest_content
                    ),
                    confidence=_CONFIDENCE,
                )
            )
        return candidates


def _count_unaggregated_cross_joins(query: str) -> int:
    """Count CROSS JOIN clauses where neither side is aggregated.

    sqlglot represents CROSS JOIN as a Join node with kind="CROSS".
    Comma joins (FROM a, b without ON) parse the same way.
    """
    try:
        tree = sqlglot.parse_one(query, dialect="bigquery")
    except Exception:  # noqa: BLE001
        return 0
    if tree is None:
        return 0
    count = 0
    for join in tree.find_all(exp.Join):
        if (join.kind or "").upper() != "CROSS":
            continue
        # If either side is aggregated, the cross join is intentional
        # (often "scaffolding" + aggregated dimensional join).
        parent_select = join.find_ancestor(exp.Select)
        if parent_select is not None and (
            parent_select.args.get("group") is not None
            or parent_select.args.get("distinct") is not None
        ):
            continue
        count += 1
    return count


def _job_cost(job: BigQueryJob) -> Decimal:
    if job.total_cost is not None:
        return Decimal(str(job.total_cost))
    if job.total_bytes_billed is not None:
        return estimate_cost_from_bytes_processed(job.total_bytes_billed)
    if job.total_bytes_processed is not None:
        return estimate_cost_from_bytes_processed(job.total_bytes_processed)
    return Decimal("0")


__all__ = ["CrossJoinUnaggregatedRule"]
