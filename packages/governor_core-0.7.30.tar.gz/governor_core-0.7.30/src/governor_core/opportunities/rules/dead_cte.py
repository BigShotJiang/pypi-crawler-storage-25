"""Dead CTE detection rule."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from governor_core.dbt.column_analyzer import (
    DeadCteAnalysis,
    analyze_all_dead_ctes,
    analyze_dead_cte_suppressed_findings,
)
from governor_core.opportunities.rules.base import BaseDetectionRule, OpportunityCandidate
from governor_core.opportunities.scoring import (
    calculate_severity,
    estimate_cost_from_bytes_processed,
)

if TYPE_CHECKING:
    from governor_core.sync.models import BigQueryJob

_CONFIDENCE = 0.55


class DeadCteRule(BaseDetectionRule):
    """Detect unused CTE definitions inside a dbt model."""

    @property
    def rule_type(self) -> str:
        return "dead_cte"

    @property
    def display_name(self) -> str:
        return "Dead CTE"

    @property
    def description(self) -> str:
        return "Detect CTEs in dbt models that are defined but never referenced downstream in the model."

    @property
    def default_thresholds(self) -> dict[str, Any]:
        return {
            "enabled": True,
            "min_dead_ctes": 1,
        }

    def detect(
        self,
        jobs: list[BigQueryJob],
        manifest_content: dict | None,
        thresholds: dict[str, Any],
    ) -> list[OpportunityCandidate]:
        if not manifest_content:
            return []

        min_dead_ctes = thresholds.get("min_dead_ctes", 1)
        jobs_by_table: dict[str, list[BigQueryJob]] = {}
        for job in jobs:
            if job.destination_table:
                jobs_by_table.setdefault(job.destination_table, []).append(job)

        analyses = analyze_all_dead_ctes(
            manifest_content=manifest_content,
            min_dead_ctes=min_dead_ctes,
        )
        return [
            candidate
            for analysis in analyses
            if (candidate := self._build_candidate(analysis, jobs_by_table)) is not None
        ]

    def _build_candidate(
        self,
        analysis: DeadCteAnalysis,
        jobs_by_table: dict[str, list[BigQueryJob]],
    ) -> OpportunityCandidate | None:
        table_jobs = jobs_by_table.get(analysis.affected_table, [])
        byte_samples = [
            job.total_bytes_processed
            for job in table_jobs
            if job.total_bytes_processed is not None
        ]
        avg_bytes = sum(byte_samples) / len(byte_samples) if byte_samples else 0.0
        dead_fraction = len(analysis.dead_ctes) / max(analysis.total_cte_count, 1)

        avg_cost_per_run = estimate_cost_from_bytes_processed(avg_bytes)
        cost_saved = estimate_cost_from_bytes_processed(avg_bytes * dead_fraction)
        severity = calculate_severity(
            estimated_savings=cost_saved,
            confidence=_CONFIDENCE,
            frequency=len(table_jobs),
        )

        explanation = (
            f"Model '{analysis.model_name}' defines {len(analysis.dead_ctes)} CTE(s) "
            f"that are never referenced by any later CTE or the final SELECT: "
            f"{', '.join(f'`{cte}`' for cte in analysis.dead_ctes)}. Removing them "
            "eliminates wasted computation inside the model. Savings estimate uses the "
            "fraction of dead CTEs as a rough proxy for wasted work "
            f"(confidence: {_CONFIDENCE:.2f})."
        )

        evidence: dict[str, Any] = {
            "dead_ctes": analysis.dead_ctes,
            "dead_cte_count": len(analysis.dead_ctes),
            "total_cte_count": analysis.total_cte_count,
            "estimated_bytes_saved_per_run": round(avg_bytes * dead_fraction),
            "sample_job_count": len(table_jobs),
            "sample_job_count_with_bytes": len(byte_samples),
        }
        suppressed_findings = analyze_dead_cte_suppressed_findings(analysis.raw_code)
        if suppressed_findings:
            evidence["suppressed_findings"] = suppressed_findings

        return OpportunityCandidate(
            opportunity_type=self.rule_type,
            affected_table=analysis.affected_table,
            severity_score=severity,
            evidence_snapshot=evidence,
            current_cost_estimate=avg_cost_per_run,
            expected_savings=cost_saved,
            explanation=explanation,
            related_job_ids=[job.job_id for job in table_jobs[:10]],
            dbt_model_name=analysis.model_name,
            confidence=_CONFIDENCE,
        )
