"""Redundant ORDER BY detection rule."""

from __future__ import annotations

from decimal import Decimal
from typing import TYPE_CHECKING, Any

from governor_core.dbt.column_analyzer import (
    RedundantOrderByAnalysis,
    analyze_redundant_order_bys,
)
from governor_core.opportunities.rules.base import BaseDetectionRule, OpportunityCandidate
from governor_core.opportunities.scoring import (
    calculate_severity,
    estimate_cost_from_bytes_processed,
)

if TYPE_CHECKING:
    from governor_core.sync.models import BigQueryJob

_CONFIDENCE = 0.72


class RedundantOrderByRule(BaseDetectionRule):
    """Detect top-level ORDER BY clauses inside CTEs that can be removed."""

    @property
    def rule_type(self) -> str:
        return "redundant_order_by"

    @property
    def display_name(self) -> str:
        return "Redundant Order By"

    @property
    def description(self) -> str:
        return "Detect ORDER BY clauses inside dbt model CTEs that add sort work without affecting downstream semantics."

    @property
    def default_thresholds(self) -> dict[str, Any]:
        return {"enabled": True, "min_redundant_order_bys": 1}

    def detect(
        self,
        jobs: list[BigQueryJob],
        manifest_content: dict | None,
        thresholds: dict[str, Any],
    ) -> list[OpportunityCandidate]:
        if not manifest_content:
            return []

        min_redundant = thresholds.get("min_redundant_order_bys", 1)
        jobs_by_table: dict[str, list[BigQueryJob]] = {}
        for job in jobs:
            if job.destination_table:
                jobs_by_table.setdefault(job.destination_table, []).append(job)

        analyses = analyze_redundant_order_bys(
            manifest_content=manifest_content,
            min_redundant_order_bys=min_redundant,
        )
        candidates: list[OpportunityCandidate] = []
        for analysis in analyses:
            candidate = self._build_candidate(analysis, jobs_by_table)
            if candidate is not None:
                candidates.append(candidate)
        return candidates

    def _build_candidate(
        self,
        analysis: RedundantOrderByAnalysis,
        jobs_by_table: dict[str, list[BigQueryJob]],
    ) -> OpportunityCandidate | None:
        table_jobs = jobs_by_table.get(analysis.affected_table, [])
        byte_samples = [
            job.total_bytes_processed
            for job in table_jobs
            if job.total_bytes_processed is not None
        ]
        avg_bytes = sum(byte_samples) / len(byte_samples) if byte_samples else 0.0
        redundant_fraction = len(analysis.redundant_order_bys) / max(
            analysis.total_cte_count, 1
        )

        avg_cost_per_run = estimate_cost_from_bytes_processed(avg_bytes)
        cost_saved = estimate_cost_from_bytes_processed(
            avg_bytes * redundant_fraction
        ) * Decimal("0.35")
        severity = calculate_severity(
            estimated_savings=cost_saved,
            confidence=_CONFIDENCE,
            frequency=len(table_jobs),
        )

        evidence: dict[str, Any] = {
            "redundant_order_bys": analysis.redundant_order_bys,
            "redundant_order_by_count": len(analysis.redundant_order_bys),
            "total_cte_count": analysis.total_cte_count,
            "estimated_bytes_saved_per_run": round(
                avg_bytes * redundant_fraction * 0.35
            ),
            "sample_job_count": len(table_jobs),
            "sample_job_count_with_bytes": len(byte_samples),
        }

        explanation = (
            f"Model '{analysis.model_name}' contains top-level ORDER BY clauses in "
            f"CTE(s) that are not paired with LIMIT/OFFSET and do not affect "
            f"downstream query semantics: {', '.join(f'`{cte}`' for cte in analysis.redundant_order_bys)}. "
            "Removing them avoids unnecessary sort work inside the model "
            f"(confidence: {_CONFIDENCE:.2f})."
        )

        return OpportunityCandidate(
            opportunity_type=self.rule_type,
            affected_table=analysis.affected_table,
            severity_score=severity,
            evidence_snapshot=evidence,
            current_cost_estimate=avg_cost_per_run,
            expected_savings=cost_saved,
            explanation=explanation,
            related_job_ids=[job.job_id for job in table_jobs[:10]],
            dbt_model_name=analysis.model_name,
            confidence=_CONFIDENCE,
        )
