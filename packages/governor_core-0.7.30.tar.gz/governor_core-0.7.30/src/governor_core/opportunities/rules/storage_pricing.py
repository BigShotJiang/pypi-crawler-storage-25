"""BigQuery storage pricing constants.

US multi-region defaults (per GiB-month). These can be overridden via
settings when regional pricing differs.
"""

from decimal import Decimal

# Logical billing (uncompressed)
LOGICAL_ACTIVE_PRICE_PER_GB = Decimal("0.02")
LOGICAL_LONG_TERM_PRICE_PER_GB = Decimal("0.01")

# Physical billing (compressed). Time travel is charged at the active
# physical rate, but INFORMATION_SCHEMA.ACTIVE_PHYSICAL_BYTES already
# includes time-travel bytes.
PHYSICAL_ACTIVE_PRICE_PER_GB = Decimal("0.04")
PHYSICAL_LONG_TERM_PRICE_PER_GB = Decimal("0.02")
PHYSICAL_TIME_TRAVEL_PRICE_PER_GB = Decimal("0.04")  # Same as active rate
PHYSICAL_FAIL_SAFE_PRICE_PER_GB = Decimal("0.04")  # Same as active rate

BYTES_PER_GB = 1024**3

# Minimum monthly savings to create an opportunity
MATERIALITY_THRESHOLD_USD = Decimal("0.00")
