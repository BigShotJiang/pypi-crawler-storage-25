"""Self-join anti-pattern detection rule.

Flags JOINs where both sides resolve to the same physical table after
alias resolution AND the ON clause has both an equality predicate
(partition key) and an inequality predicate (order key) — the typical
"self-join to compare adjacent rows" shape that's better expressed as a
window function. Sourced from Google's "Optimize query computation"
guide (Avoid self joins).
"""

from __future__ import annotations

from decimal import Decimal
from typing import TYPE_CHECKING, Any

import sqlglot
from sqlglot import exp

from governor_core.opportunities.rules.base import BaseDetectionRule, OpportunityCandidate
from governor_core.opportunities.scoring import (
    calculate_severity,
    estimate_cost_from_bytes_processed,
)

if TYPE_CHECKING:
    from governor_core.sync.models import BigQueryJob


_CONFIDENCE = 0.55

_INEQUALITY_OPS: tuple[type, ...] = (exp.LT, exp.LTE, exp.GT, exp.GTE)


class SelfJoinAntiPatternRule(BaseDetectionRule):
    """Flag self-joins that look like they should be window functions."""

    @property
    def rule_type(self) -> str:
        return "self_join_anti_pattern"

    @property
    def display_name(self) -> str:
        return "Self-join anti-pattern"

    @property
    def description(self) -> str:
        return (
            "JOIN of a table to itself with a key-equality + ordering inequality "
            "(`a.k = b.k AND a.t < b.t`) typically scans the table twice. The "
            "window-function form (LAG/LEAD/RANK OVER PARTITION BY) scans once."
        )

    @property
    def default_thresholds(self) -> dict[str, Any]:
        return {"enabled": True}

    def detect(
        self,
        jobs: list[BigQueryJob],
        manifest_content: dict | None,
        thresholds: dict[str, Any],
    ) -> list[OpportunityCandidate]:
        candidates: list[OpportunityCandidate] = []
        for job in jobs:
            if not job.query or not job.destination_table:
                continue
            matches = _find_self_joins(job.query)
            if not matches:
                continue
            current_cost = _job_cost(job)
            evidence = {
                "self_join_count": len(matches),
                "tables": sorted({m["table"] for m in matches}),
            }
            severity = calculate_severity(current_cost, _CONFIDENCE)
            candidates.append(
                OpportunityCandidate(
                    opportunity_type=self.rule_type,
                    affected_table=job.destination_table,
                    severity_score=severity,
                    evidence_snapshot=evidence,
                    current_cost_estimate=current_cost,
                    expected_savings=Decimal("0"),
                    explanation=(
                        f"Found {len(matches)} self-join(s) with key-equality + "
                        f"ordering inequality. Replace with LAG/LEAD/RANK over "
                        f"PARTITION BY to scan the table once."
                    ),
                    related_job_ids=[job.job_id] if job.job_id else [],
                    dbt_model_name=self.correlate_dbt_model(
                        job.destination_table, manifest_content
                    ),
                    confidence=_CONFIDENCE,
                )
            )
        return candidates


def _find_self_joins(query: str) -> list[dict[str, Any]]:
    try:
        tree = sqlglot.parse_one(query, dialect="bigquery")
    except Exception:  # noqa: BLE001
        return []
    if tree is None:
        return []
    matches: list[dict[str, Any]] = []
    for select in tree.find_all(exp.Select):
        from_clause = select.find(exp.From)
        joins = list(select.args.get("joins") or [])
        if from_clause is None or not joins:
            continue
        from_table = _table_name(from_clause.this)
        if from_table is None:
            continue
        for join in joins:
            join_table = _table_name(join.this)
            if join_table != from_table:
                continue
            on = join.args.get("on")
            if on is None or not _has_eq_and_inequality(on):
                continue
            matches.append({"table": from_table})
    return matches


def _table_name(node: exp.Expression | None) -> str | None:
    """Resolve the physical table name from a FROM / JOIN inner node."""
    if node is None:
        return None
    if isinstance(node, exp.Table):
        return node.name
    if isinstance(node, exp.Alias):
        target = node.this
        if isinstance(target, exp.Table):
            return target.name
    return None


def _has_eq_and_inequality(predicate: exp.Expression) -> bool:
    """True iff the predicate AST contains both an EQ and an inequality op."""
    nodes = list(predicate.walk())
    # Predicate.walk() yields each node directly (not tuples).
    has_eq = any(isinstance(node, exp.EQ) for node in nodes)
    has_ineq = any(isinstance(node, _INEQUALITY_OPS) for node in nodes)
    return has_eq and has_ineq


def _job_cost(job: BigQueryJob) -> Decimal:
    if job.total_cost is not None:
        return Decimal(str(job.total_cost))
    if job.total_bytes_billed is not None:
        return estimate_cost_from_bytes_processed(job.total_bytes_billed)
    if job.total_bytes_processed is not None:
        return estimate_cost_from_bytes_processed(job.total_bytes_processed)
    return Decimal("0")


__all__ = ["SelfJoinAntiPatternRule"]
