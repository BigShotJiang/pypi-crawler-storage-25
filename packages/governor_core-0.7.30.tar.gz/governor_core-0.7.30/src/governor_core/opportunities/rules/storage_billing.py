"""Storage Billing Optimization Detection Rule.

Detects datasets where switching from logical to physical storage billing
would reduce costs, based on synced TABLE_STORAGE metrics.
"""

from __future__ import annotations

from collections import defaultdict
from decimal import Decimal
from typing import TYPE_CHECKING, Any

from governor_core.opportunities.rules.base import (
    BaseDetectionRule,
    OpportunityCandidate,
)
from governor_core.opportunities.rules.storage_pricing import (
    BYTES_PER_GB,
    LOGICAL_ACTIVE_PRICE_PER_GB,
    LOGICAL_LONG_TERM_PRICE_PER_GB,
    MATERIALITY_THRESHOLD_USD,
    PHYSICAL_ACTIVE_PRICE_PER_GB,
    PHYSICAL_FAIL_SAFE_PRICE_PER_GB,
    PHYSICAL_LONG_TERM_PRICE_PER_GB,
)

if TYPE_CHECKING:
    from governor_core.sync.models import BigQueryJob


def _bytes_to_gb(b: int) -> Decimal:
    """Convert bytes to GB as Decimal."""
    return Decimal(str(b)) / Decimal(str(BYTES_PER_GB))


def _severity_from_savings(monthly_savings: Decimal) -> int:
    """Map monthly savings to severity score (1-100)."""
    if monthly_savings >= 10_000:
        return 100
    if monthly_savings >= 1_000:
        return 80
    if monthly_savings >= 100:
        return 60
    if monthly_savings >= 10:
        return 40
    return 20


class StorageBillingRule(BaseDetectionRule):
    """Detects storage billing optimization opportunities per dataset.

    Analyzes table_storage_metrics to find datasets on logical billing
    where switching to physical billing would save money. BigQuery
    billing model is a dataset-level setting, so one opportunity is
    created per dataset aggregating all stored tables within it.
    """

    @property
    def rule_type(self) -> str:
        return "storage_billing_optimization"

    @property
    def display_name(self) -> str:
        return "Storage Billing"

    @property
    def description(self) -> str:
        return "Detect datasets where physical billing would reduce storage costs."

    @property
    def analysis_surface(self) -> str:
        return "ingestion"

    @property
    def default_thresholds(self) -> dict[str, Any]:
        return {
            "min_monthly_savings_usd": MATERIALITY_THRESHOLD_USD,
        }

    def detect(
        self,
        jobs: list[BigQueryJob],
        manifest_content: dict | None,
        thresholds: dict[str, Any],
    ) -> list[OpportunityCandidate]:
        """Analyze storage metrics and return per-dataset billing opportunities.

        Expects thresholds["_storage_metrics"] to contain list of
        TableStorageMetric ORM objects. Removes PHYSICAL-billing tables,
        groups by dataset, and creates one opportunity per dataset where
        physical billing saves money.
        """
        del jobs, manifest_content
        storage_metrics = thresholds.get("_storage_metrics", [])
        if not storage_metrics:
            return []

        min_savings = thresholds.get(
            "min_monthly_savings_usd", MATERIALITY_THRESHOLD_USD
        )

        # Remove tables already on physical billing
        storage_metrics = [m for m in storage_metrics if m.billing_model != "PHYSICAL"]

        # Group remaining metrics by (project_id, dataset_name)
        dataset_groups: dict[tuple[str, str], list] = defaultdict(list)
        for metric in storage_metrics:
            dataset_groups[(metric.project_id, metric.dataset_name)].append(metric)

        candidates: list[OpportunityCandidate] = []

        for (project_id, dataset_name), ds_metrics in dataset_groups.items():
            # Aggregate byte totals across all tables in this dataset
            active_logical = sum(m.active_logical_bytes for m in ds_metrics)
            lt_logical = sum(m.long_term_logical_bytes for m in ds_metrics)
            active_physical = sum(m.active_physical_bytes for m in ds_metrics)
            lt_physical = sum(m.long_term_physical_bytes for m in ds_metrics)
            tt_physical = sum(m.time_travel_physical_bytes for m in ds_metrics)
            fs_physical = sum(m.fail_safe_physical_bytes for m in ds_metrics)
            total_logical = sum(m.total_logical_bytes for m in ds_metrics)
            total_physical = sum(m.total_physical_bytes for m in ds_metrics)
            billable_physical = active_physical + lt_physical + fs_physical
            compressed_current_physical = max(active_physical - tt_physical, 0) + (
                lt_physical
            )
            if billable_physical <= 0:
                continue

            # Calculate dataset-level costs
            logical_cost = (
                _bytes_to_gb(active_logical) * LOGICAL_ACTIVE_PRICE_PER_GB
                + _bytes_to_gb(lt_logical) * LOGICAL_LONG_TERM_PRICE_PER_GB
            )
            physical_cost = (
                _bytes_to_gb(active_physical) * PHYSICAL_ACTIVE_PRICE_PER_GB
                + _bytes_to_gb(lt_physical) * PHYSICAL_LONG_TERM_PRICE_PER_GB
                + _bytes_to_gb(fs_physical) * PHYSICAL_FAIL_SAFE_PRICE_PER_GB
            )

            monthly_savings = logical_cost - physical_cost

            if monthly_savings <= 0 or monthly_savings < min_savings:
                continue

            compression_ratio = (
                round(float(total_logical) / float(compressed_current_physical), 1)
                if compressed_current_physical > 0
                else 0.0
            )

            savings_pct = (
                round(float(monthly_savings / logical_cost) * 100, 1)
                if logical_cost > 0
                else 0.0
            )
            monthly_savings_display = round(float(monthly_savings), 2)

            affected_table = f"{project_id}.{dataset_name}"
            table_count = len(ds_metrics)
            severity = _severity_from_savings(monthly_savings)

            # Per-table breakdown for evidence
            table_details = []
            for m in ds_metrics:
                t_logical = m.total_logical_bytes
                t_physical = m.total_physical_bytes
                t_compressed_current_physical = (
                    max(m.active_physical_bytes - m.time_travel_physical_bytes, 0)
                    + m.long_term_physical_bytes
                )
                t_logical_cost = (
                    _bytes_to_gb(m.active_logical_bytes) * LOGICAL_ACTIVE_PRICE_PER_GB
                    + _bytes_to_gb(m.long_term_logical_bytes)
                    * LOGICAL_LONG_TERM_PRICE_PER_GB
                )
                t_physical_cost = (
                    _bytes_to_gb(m.active_physical_bytes) * PHYSICAL_ACTIVE_PRICE_PER_GB
                    + _bytes_to_gb(m.long_term_physical_bytes)
                    * PHYSICAL_LONG_TERM_PRICE_PER_GB
                    + _bytes_to_gb(m.fail_safe_physical_bytes)
                    * PHYSICAL_FAIL_SAFE_PRICE_PER_GB
                )
                t_savings = t_logical_cost - t_physical_cost
                t_comp = (
                    round(float(t_logical) / float(t_compressed_current_physical), 1)
                    if t_compressed_current_physical > 0
                    else 0.0
                )
                table_details.append(
                    {
                        "table_name": m.table_name,
                        "total_logical_gb": round(float(_bytes_to_gb(t_logical)), 2),
                        "total_physical_gb": round(float(_bytes_to_gb(t_physical)), 2),
                        "compression_ratio": t_comp,
                        "monthly_savings": round(float(t_savings), 2),
                    }
                )

            evidence = {
                "dataset_name": dataset_name,
                "dataset": f"{project_id}.{dataset_name}",
                "current_billing_model": "LOGICAL",
                "table_count": table_count,
                "tables": table_details,
                "total_logical_gb": round(float(_bytes_to_gb(total_logical)), 2),
                "total_physical_gb": round(float(_bytes_to_gb(total_physical)), 2),
                "compression_ratio": compression_ratio,
                "active_logical_gb": round(float(_bytes_to_gb(active_logical)), 2),
                "long_term_logical_gb": round(float(_bytes_to_gb(lt_logical)), 2),
                "active_physical_gb": round(float(_bytes_to_gb(active_physical)), 2),
                "long_term_physical_gb": round(float(_bytes_to_gb(lt_physical)), 2),
                "time_travel_physical_gb": round(float(_bytes_to_gb(tt_physical)), 2),
                "fail_safe_physical_gb": round(float(_bytes_to_gb(fs_physical)), 2),
                "logical_cost_monthly": round(float(logical_cost), 2),
                "physical_cost_monthly": round(float(physical_cost), 2),
                "monthly_savings": monthly_savings_display,
                "annual_savings": round(monthly_savings_display * 12, 2),
                "savings_percentage": savings_pct,
                "pricing": {
                    "logical_active_per_gb": float(LOGICAL_ACTIVE_PRICE_PER_GB),
                    "logical_long_term_per_gb": float(LOGICAL_LONG_TERM_PRICE_PER_GB),
                    "physical_active_per_gb": float(PHYSICAL_ACTIVE_PRICE_PER_GB),
                    "physical_long_term_per_gb": float(PHYSICAL_LONG_TERM_PRICE_PER_GB),
                },
            }

            table_word = "table" if table_count == 1 else "tables"
            explanation = (
                f"Dataset '{dataset_name}' contains {table_count} stored "
                f"{table_word} using logical billing with an overall "
                f"{compression_ratio}:1 compression. Switching to physical billing "
                f"would save ${round(float(monthly_savings), 2)}/month "
                f"(${round(float(monthly_savings * 12), 2)}/year), "
                f"a {savings_pct}% reduction in storage costs."
            )

            candidates.append(
                OpportunityCandidate(
                    opportunity_type=self.rule_type,
                    affected_table=affected_table,
                    severity_score=severity,
                    evidence_snapshot=evidence,
                    current_cost_estimate=logical_cost,
                    expected_savings=monthly_savings,
                    explanation=explanation,
                    related_job_ids=[],
                    dbt_model_name=None,
                    confidence=1.0,
                )
            )

        return candidates
