"""SELECT * detection rule.

Flags persisted queries whose outermost projection is `SELECT *`. Inside
CTEs / subqueries `SELECT *` can be fine (the outer projection narrows
columns later), so we only flag the outer level — that's what actually
ends up materialised. Sourced from Google's "Optimize query computation"
guide (Avoid SELECT *).
"""

from __future__ import annotations

from decimal import Decimal
from typing import TYPE_CHECKING, Any

import sqlglot
from sqlglot import exp

from governor_core.opportunities.rules.base import BaseDetectionRule, OpportunityCandidate
from governor_core.opportunities.scoring import (
    calculate_severity,
    estimate_cost_from_bytes_processed,
)

if TYPE_CHECKING:
    from governor_core.sync.models import BigQueryJob


_CONFIDENCE = 0.85


class SelectStarRule(BaseDetectionRule):
    """Flag jobs whose outermost SELECT projects `*`."""

    @property
    def rule_type(self) -> str:
        return "select_star"

    @property
    def display_name(self) -> str:
        return "SELECT *"

    @property
    def description(self) -> str:
        return (
            "Persisted queries projecting every column with `SELECT *` materialise "
            "more bytes than the consumer needs. Replace with an explicit column "
            "list or `SELECT * EXCEPT (...)` to drop unused columns."
        )

    @property
    def default_thresholds(self) -> dict[str, Any]:
        return {"enabled": True}

    def detect(
        self,
        jobs: list[BigQueryJob],
        manifest_content: dict | None,
        thresholds: dict[str, Any],
    ) -> list[OpportunityCandidate]:
        candidates: list[OpportunityCandidate] = []
        for job in jobs:
            if not job.query or not job.destination_table:
                continue
            if not _outer_select_is_star(job.query):
                continue
            current_cost = _job_cost(job)
            evidence = {
                "has_select_star": True,
                "destination_table": job.destination_table,
            }
            # Severity is derived from current cost + detection confidence —
            # NOT from a hardcoded "savings fraction". Audit doesn't run
            # dry-runs, so we don't claim a savings number we can't justify.
            severity = calculate_severity(current_cost, _CONFIDENCE)
            candidates.append(
                OpportunityCandidate(
                    opportunity_type=self.rule_type,
                    affected_table=job.destination_table,
                    severity_score=severity,
                    evidence_snapshot=evidence,
                    current_cost_estimate=current_cost,
                    expected_savings=Decimal("0"),
                    explanation=(
                        "Outer projection is `SELECT *`. Replace with an "
                        "explicit column list or `SELECT * EXCEPT (...)` to "
                        "drop columns the consumer never reads."
                    ),
                    related_job_ids=[job.job_id] if job.job_id else [],
                    dbt_model_name=self.correlate_dbt_model(
                        job.destination_table, manifest_content
                    ),
                    confidence=_CONFIDENCE,
                )
            )
        return candidates


def _outer_select_is_star(query: str) -> bool:
    """True iff the outermost SELECT in the query projects only `*`.

    Conservative: we parse with sqlglot in BigQuery dialect, find the
    top-level SELECT (skipping CTEs, which sit in the WITH clause), and
    check whether any of its expressions is a Star. We only fire when
    the top-level `SELECT` has exactly `*` (or `t.*`) — a SELECT list
    that mixes `*` with explicit columns is an obvious projection
    intent and not flagged here.
    """
    try:
        tree = sqlglot.parse_one(query, dialect="bigquery")
    except Exception:  # noqa: BLE001
        return False
    if tree is None:
        return False
    # Drill down to the outermost SELECT — sqlglot wraps INSERT / CREATE
    # TABLE AS in their own nodes whose .args["expression"] is the SELECT.
    select = _outermost_select(tree)
    if select is None:
        return False
    expressions = select.expressions or []
    if not expressions:
        return False
    return all(isinstance(e, (exp.Star, exp.Column)) and _is_star(e) for e in expressions)


def _outermost_select(tree: exp.Expression) -> exp.Select | None:
    """Walk past INSERT / CREATE wrappers (and any Subquery the CTAS body
    is parsed into for ``CREATE OR REPLACE TABLE … OPTIONS() AS (…)``)
    to reach the innermost SELECT that BigQuery actually materialises."""
    if isinstance(tree, exp.Select):
        return tree
    # CREATE/INSERT/UPDATE wrap their body in ``args["expression"]``.
    inner = tree.args.get("expression")
    if isinstance(inner, exp.Select):
        return inner
    if isinstance(inner, exp.Expression):
        return _outermost_select(inner)
    # A parenthesised CTAS body parses as ``Subquery``, which wraps its
    # SELECT in ``args["this"]`` rather than ``args["expression"]``.
    inner = tree.args.get("this")
    if isinstance(inner, exp.Select):
        return inner
    if isinstance(inner, exp.Expression) and not isinstance(inner, exp.Identifier):
        return _outermost_select(inner)
    return None


def _is_star(node: exp.Expression) -> bool:
    if isinstance(node, exp.Star):
        return True
    if isinstance(node, exp.Column) and isinstance(node.this, exp.Star):
        return True
    return False


def _job_cost(job: BigQueryJob) -> Decimal:
    if job.total_cost is not None:
        return Decimal(str(job.total_cost))
    if job.total_bytes_billed is not None:
        return estimate_cost_from_bytes_processed(job.total_bytes_billed)
    if job.total_bytes_processed is not None:
        return estimate_cost_from_bytes_processed(job.total_bytes_processed)
    return Decimal("0")


__all__ = ["SelectStarRule"]
