"""
Threshold configuration for detection rules.

Provides centralized threshold management with support for:
- Default thresholds per rule type
- Configuration overrides from settings
- Runtime threshold customization
"""

from __future__ import annotations

import logging
from decimal import Decimal
from typing import Any

from governor_core.core.config import get_settings

logger = logging.getLogger(__name__)

# Default thresholds for each rule type
# These are the baseline values used when no override is configured
DEFAULT_THRESHOLDS: dict[str, dict[str, Any]] = {
    "shuffle_spill": {
        "enabled": True,
        "min_job_cost_usd": Decimal("0.10"),
        "description": "Detect queries with shuffle spill to disk",
    },
    "slot_contention": {
        "enabled": True,
        "min_job_cost_usd": Decimal("0.10"),
        "queue_time_ratio_threshold": Decimal("0.30"),  # 30% of total time in queue
        "min_duration_seconds": 60,  # Minimum 1 minute total duration
        "description": "Detect queries experiencing slot contention or queue delays",
    },
    "join_explosion": {
        "enabled": True,
        "min_job_cost_usd": Decimal("0.10"),
        "row_multiplication_threshold": 10,  # 10x row increase
        "description": "Detect queries with excessive row multiplication from joins",
    },
    "partition_pruning": {
        "enabled": True,
        "min_job_cost_usd": Decimal("0.10"),
        "description": "Detect queries not using partition filters effectively",
    },
    # Each of these has a deterministic template in
    # governor_core.solutions.templates that emits real before/after
    # diffs (no LLM, no manifest, no GitHub) — they're safe to enable
    # by default. Operators can still disable individual rules via
    # /admin/settings/detection-rules.
    "dead_cte": {
        "enabled": True,
        "description": "Detect CTEs defined but never referenced downstream",
    },
    "dead_column": {
        "enabled": True,
        "description": "Detect projected columns never referenced downstream",
    },
    "dead_window_expression": {
        "enabled": True,
        "description": "Detect window-function outputs never referenced downstream",
    },
    "unused_aggregation_output": {
        "enabled": True,
        "description": "Detect aggregate expressions never referenced downstream",
    },
    "redundant_order_by": {
        "enabled": True,
        "description": "Detect ORDER BY inside CTEs that has no downstream effect",
    },
    "unused_join": {
        "enabled": True,
        "description": "Detect LEFT JOINs whose right side is unused",
    },
    "storage_billing_optimization": {
        "enabled": True,
        "description": "Detect datasets where physical billing would reduce costs",
    },
}


def get_rule_thresholds(rule_type: str) -> dict[str, Any]:
    """
    Get thresholds for a specific rule type.

    Merges default thresholds with any configured overrides from settings.

    Args:
        rule_type: The rule type identifier (e.g., 'shuffle_spill')

    Returns:
        Dictionary of threshold values for the rule
    """
    # Start with defaults
    defaults = DEFAULT_THRESHOLDS.get(rule_type, {})

    # Get overrides from settings if available
    settings = get_settings()
    overrides = _get_threshold_overrides(settings, rule_type)

    # Merge defaults with overrides (overrides win)
    thresholds = {**defaults, **overrides}

    logger.debug(f"Thresholds for {rule_type}: {thresholds}")
    return thresholds


_ENV_TRUE_VALUES = frozenset({"1", "true", "yes", "on"})
_ENV_FALSE_VALUES = frozenset({"0", "false", "no", "off"})


def _parse_env_bool(value: str | None) -> bool | None:
    """Parse a boolean env var. Returns ``None`` if unset or unrecognised."""
    if value is None:
        return None
    normalised = value.strip().lower()
    if normalised in _ENV_TRUE_VALUES:
        return True
    if normalised in _ENV_FALSE_VALUES:
        return False
    return None


def _get_threshold_overrides(settings: Any, rule_type: str) -> dict[str, Any]:
    """
    Extract threshold overrides for a single rule, in priority order:

      1. Environment variable ``OPPORTUNITY_<RULE>_ENABLED``
         (highest priority — emergency override / CI / incident response)
      2. Runtime-cached admin setting from
         ``governor_core.setup.runtime.get_runtime_detection_rule_override``
         (persisted in ``OrganisationSettingsService``, loaded into
         ``RuntimeSetupState`` at startup, refreshed on admin save)
      3. ``Settings.opportunity_<rule>_min_cost`` env var override for
         the per-rule minimum job cost gate

    Anything not overridden falls through to the hardcoded
    ``DEFAULT_THRESHOLDS`` value at the call site.

    Args:
        settings: Application settings object
        rule_type: The rule type identifier

    Returns:
        Dictionary of override values
    """
    import os

    overrides: dict[str, Any] = {}

    # Layer 1: env-var enable override — highest priority.
    env_var = f"OPPORTUNITY_{rule_type.upper()}_ENABLED"
    env_enabled = _parse_env_bool(os.environ.get(env_var))
    if env_enabled is not None:
        overrides["enabled"] = env_enabled
    else:
        # Layer 2: admin-set persisted override (cached in runtime state).
        from governor_core.setup.runtime import get_runtime_detection_rule_override

        runtime_enabled = get_runtime_detection_rule_override(rule_type)
        if runtime_enabled is not None:
            overrides["enabled"] = runtime_enabled

    # Layer 3: per-rule min_cost env-var override (legacy path; orthogonal
    # to enable/disable). Looked up on Settings via attribute style for
    # forwards compatibility — declaring ``opportunity_<rule>_min_cost``
    # fields on Settings will Just Work.
    prefix = f"opportunity_{rule_type}_"
    min_cost_attr = f"{prefix}min_cost"
    if hasattr(settings, min_cost_attr):
        value = getattr(settings, min_cost_attr, None)
        if value is not None:
            overrides["min_job_cost_usd"] = Decimal(str(value))

    return overrides


def get_all_rule_thresholds() -> dict[str, dict[str, Any]]:
    """
    Get thresholds for all registered rule types.

    Returns:
        Dictionary mapping rule_type -> thresholds
    """
    return {
        rule_type: get_rule_thresholds(rule_type) for rule_type in DEFAULT_THRESHOLDS
    }


def is_rule_enabled(rule_type: str) -> bool:
    """
    Check if a rule is enabled.

    Args:
        rule_type: The rule type identifier

    Returns:
        True if rule is enabled, False otherwise
    """
    thresholds = get_rule_thresholds(rule_type)
    return thresholds.get("enabled", True)


def update_default_thresholds(rule_type: str, thresholds: dict[str, Any]) -> None:
    """
    Update default thresholds for a rule type at runtime.

    This is primarily useful for testing or dynamic configuration.

    Args:
        rule_type: The rule type identifier
        thresholds: New threshold values to merge with existing defaults
    """
    if rule_type not in DEFAULT_THRESHOLDS:
        DEFAULT_THRESHOLDS[rule_type] = {}

    DEFAULT_THRESHOLDS[rule_type].update(thresholds)
    logger.info(f"Updated default thresholds for {rule_type}: {thresholds}")


def register_rule_thresholds(rule_type: str, thresholds: dict[str, Any]) -> None:
    """
    Register thresholds for a new rule type.

    Used when adding new detection rules dynamically.

    Args:
        rule_type: Unique rule type identifier
        thresholds: Default threshold configuration

    Raises:
        ValueError: If rule_type already exists
    """
    if rule_type in DEFAULT_THRESHOLDS:
        raise ValueError(f"Rule type '{rule_type}' already registered")

    DEFAULT_THRESHOLDS[rule_type] = thresholds
    logger.info(f"Registered thresholds for new rule: {rule_type}")
