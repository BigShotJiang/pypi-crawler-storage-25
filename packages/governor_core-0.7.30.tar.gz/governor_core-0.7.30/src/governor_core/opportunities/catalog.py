"""
Shared detection rule catalog and selection helpers.

Provides a single source of truth for:
- built-in and dynamically registered detection rule classes
- UI-facing rule metadata
- config-aware watched-rule selection semantics
"""

from __future__ import annotations

import logging
from collections import Counter
from dataclasses import dataclass
from typing import Literal

from governor_core.opportunities.rules.base import AnalysisSurface, BaseDetectionRule
from governor_core.opportunities.thresholds import is_rule_enabled, register_rule_thresholds

logger = logging.getLogger(__name__)

_REGISTERED_RULES: list[type[BaseDetectionRule]] = []


@dataclass(frozen=True)
class DetectionRuleAnalysisSurface:
    key: AnalysisSurface
    title: str
    description: str


@dataclass(frozen=True)
class DetectionRuleCatalogSurfaceSummary:
    key: AnalysisSurface
    title: str
    count: int


@dataclass(frozen=True)
class DetectionRuleCatalogEntry:
    rule_type: str
    display_name: str
    description: str
    group_key: str
    group_title: str
    group_description: str
    analysis_surface: AnalysisSurface
    analysis_surface_title: str
    analysis_surface_description: str
    enabled: bool
    rule_class: type[BaseDetectionRule]


@dataclass(frozen=True)
class DetectionRuleCatalogGroup:
    key: str
    title: str
    description: str
    analysis_surface_summaries: list[DetectionRuleCatalogSurfaceSummary]
    rules: list[DetectionRuleCatalogEntry]


@dataclass(frozen=True)
class EffectiveRuleSelection:
    mode: Literal["all", "custom"]
    configured_rule_types: list[str]
    unknown_rule_types: list[str]
    unavailable_rule_types: list[str]
    effective_rule_types: list[str]


def _dedupe_rule_types(rule_types: list[str] | None) -> list[str]:
    if not rule_types:
        return []
    deduped: list[str] = []
    seen: set[str] = set()
    for rule_type in rule_types:
        value = str(rule_type).strip()
        if not value or value in seen:
            continue
        deduped.append(value)
        seen.add(value)
    return deduped


def get_builtin_rule_classes() -> list[type[BaseDetectionRule]]:
    # Imported lazily to avoid circular imports at module load time.
    from governor_core.opportunities.rules.cross_join_unaggregated import (
        CrossJoinUnaggregatedRule,
    )
    from governor_core.opportunities.rules.dead_cte import DeadCteRule
    from governor_core.opportunities.rules.dead_column import DeadColumnRule
    from governor_core.opportunities.rules.dead_window_expression import (
        DeadWindowExpressionRule,
    )
    from governor_core.opportunities.rules.join_explosion import JoinExplosionRule
    from governor_core.opportunities.rules.partition_pruning import PartitionPruningRule
    from governor_core.opportunities.rules.redundant_order_by import RedundantOrderByRule
    from governor_core.opportunities.rules.select_star import SelectStarRule
    from governor_core.opportunities.rules.self_join_anti_pattern import (
        SelfJoinAntiPatternRule,
    )
    from governor_core.opportunities.rules.shuffle_spill import ShuffleSpillRule
    from governor_core.opportunities.rules.slot_contention import SlotContentionRule
    from governor_core.opportunities.rules.storage_billing import StorageBillingRule
    from governor_core.opportunities.rules.unused_join import UnusedJoinRule
    from governor_core.opportunities.rules.unused_aggregation_output import (
        UnusedAggregationOutputRule,
    )

    return [
        ShuffleSpillRule,
        SlotContentionRule,
        JoinExplosionRule,
        PartitionPruningRule,
        StorageBillingRule,
        DeadCteRule,
        DeadColumnRule,
        DeadWindowExpressionRule,
        UnusedAggregationOutputRule,
        RedundantOrderByRule,
        UnusedJoinRule,
        # BigQuery best-practices rules (spec 142) — sourced from
        # Google's "Optimize query computation" guide.
        SelectStarRule,
        CrossJoinUnaggregatedRule,
        SelfJoinAntiPatternRule,
    ]


def get_registered_rule_classes() -> list[type[BaseDetectionRule]]:
    return list(_REGISTERED_RULES)


def get_all_rule_classes() -> list[type[BaseDetectionRule]]:
    return get_builtin_rule_classes() + get_registered_rule_classes()


_RULE_GROUPS: tuple[tuple[str, str, str], ...] = (
    (
        "performance",
        "Execution Performance",
        "Runtime inefficiencies observed in BigQuery execution behavior.",
    ),
    (
        "storage",
        "Storage Optimization",
        "Dataset-level billing and storage configuration opportunities.",
    ),
    (
        "dead_code",
        "Dead / Unused Logic",
        "Unreferenced dbt SQL structures that can be removed without affecting output.",
    ),
    (
        "sql_cleanup",
        "SQL Cleanup",
        "Reachable SQL patterns that add unnecessary work and can be simplified.",
    ),
    (
        "other",
        "Other Rules",
        "Additional detection rules.",
    ),
)

_RULE_GROUP_BY_TYPE: dict[str, str] = {
    "shuffle_spill": "performance",
    "slot_contention": "performance",
    "join_explosion": "performance",
    "partition_pruning": "performance",
    "storage_billing_optimization": "storage",
    "dead_cte": "dead_code",
    "dead_column": "dead_code",
    "dead_window_expression": "dead_code",
    "unused_aggregation_output": "dead_code",
    "redundant_order_by": "sql_cleanup",
    "unused_join": "sql_cleanup",
    # Spec 142 — BigQuery best-practices rules.
    "select_star": "sql_cleanup",
    "cross_join_unaggregated": "sql_cleanup",
    "self_join_anti_pattern": "sql_cleanup",
}

_ANALYSIS_SURFACES: tuple[DetectionRuleAnalysisSurface, ...] = (
    DetectionRuleAnalysisSurface(
        key="build",
        title="Build",
        description="dbt-managed model builds, warehouse execution, and SQL authored inside the transformation layer.",
    ),
    DetectionRuleAnalysisSurface(
        key="consumption",
        title="Consumption",
        description="Downstream reads, BI queries, notebooks, and other expensive consumers of modeled warehouse data.",
    ),
    DetectionRuleAnalysisSurface(
        key="ingestion",
        title="Ingestion",
        description="Raw-landed objects, ingestion/storage layout, and upstream pipeline strategy before data reaches the build layer.",
    ),
)


def _get_rule_group_metadata(rule_type: str) -> tuple[str, str, str]:
    """Return UI grouping metadata for a rule type."""
    group_key = _RULE_GROUP_BY_TYPE.get(rule_type, "other")
    for key, title, description in _RULE_GROUPS:
        if key == group_key:
            return key, title, description
    return "other", "Other Rules", "Additional detection rules."


def get_detection_analysis_surfaces() -> list[DetectionRuleAnalysisSurface]:
    return list(_ANALYSIS_SURFACES)


def _get_analysis_surface_metadata(
    surface: AnalysisSurface,
) -> DetectionRuleAnalysisSurface:
    for metadata in _ANALYSIS_SURFACES:
        if metadata.key == surface:
            return metadata
    return _ANALYSIS_SURFACES[0]


def _build_surface_summaries(
    rules: list[DetectionRuleCatalogEntry],
) -> list[DetectionRuleCatalogSurfaceSummary]:
    counts = Counter(rule.analysis_surface for rule in rules)
    summaries: list[DetectionRuleCatalogSurfaceSummary] = []
    for surface in _ANALYSIS_SURFACES:
        count = counts.get(surface.key, 0)
        if count <= 0:
            continue
        summaries.append(
            DetectionRuleCatalogSurfaceSummary(
                key=surface.key,
                title=surface.title,
                count=count,
            )
        )
    return summaries


def get_detection_rule_catalog() -> list[DetectionRuleCatalogEntry]:
    catalog: list[DetectionRuleCatalogEntry] = []
    for rule_class in get_all_rule_classes():
        rule = rule_class()
        group_key, group_title, group_description = _get_rule_group_metadata(
            rule.rule_type
        )
        surface_metadata = _get_analysis_surface_metadata(rule.analysis_surface)
        catalog.append(
            DetectionRuleCatalogEntry(
                rule_type=rule.rule_type,
                display_name=rule.display_name,
                description=rule.description,
                group_key=group_key,
                group_title=group_title,
                group_description=group_description,
                analysis_surface=surface_metadata.key,
                analysis_surface_title=surface_metadata.title,
                analysis_surface_description=surface_metadata.description,
                enabled=is_rule_enabled(rule.rule_type),
                rule_class=rule_class,
            )
        )
    return catalog


def get_grouped_detection_rule_catalog(
    catalog: list[DetectionRuleCatalogEntry] | None = None,
) -> list[DetectionRuleCatalogGroup]:
    """Return the detection rule catalog grouped for configuration UIs."""
    catalog = catalog or get_detection_rule_catalog()
    grouped: dict[str, list[DetectionRuleCatalogEntry]] = {}
    metadata: dict[str, tuple[str, str]] = {}

    for entry in catalog:
        grouped.setdefault(entry.group_key, []).append(entry)
        metadata[entry.group_key] = (entry.group_title, entry.group_description)

    ordered_groups: list[DetectionRuleCatalogGroup] = []
    for key, title, description in _RULE_GROUPS:
        rules = grouped.get(key, [])
        if not rules:
            continue
        ordered_groups.append(
            DetectionRuleCatalogGroup(
                key=key,
                title=title,
                description=description,
                analysis_surface_summaries=_build_surface_summaries(rules),
                rules=rules,
            )
        )

    for key, rules in grouped.items():
        if any(group.key == key for group in ordered_groups):
            continue
        title, description = metadata.get(
            key, ("Other Rules", "Additional detection rules.")
        )
        ordered_groups.append(
            DetectionRuleCatalogGroup(
                key=key,
                title=title,
                description=description,
                analysis_surface_summaries=_build_surface_summaries(rules),
                rules=rules,
            )
        )

    return ordered_groups


def get_detection_rule_map() -> dict[str, DetectionRuleCatalogEntry]:
    return {entry.rule_type: entry for entry in get_detection_rule_catalog()}


def build_effective_rule_selection(
    watched_rule_types: list[str] | None,
    catalog: list[DetectionRuleCatalogEntry] | None = None,
) -> EffectiveRuleSelection:
    catalog = catalog or get_detection_rule_catalog()
    catalog_map = {entry.rule_type: entry for entry in catalog}

    if watched_rule_types is None:
        configured_rule_types = [entry.rule_type for entry in catalog]
        effective_rule_types = [entry.rule_type for entry in catalog if entry.enabled]
        unavailable_rule_types = [
            entry.rule_type for entry in catalog if not entry.enabled
        ]
        return EffectiveRuleSelection(
            mode="all",
            configured_rule_types=configured_rule_types,
            unknown_rule_types=[],
            unavailable_rule_types=unavailable_rule_types,
            effective_rule_types=effective_rule_types,
        )

    deduped_rule_types = _dedupe_rule_types(watched_rule_types)
    configured_rule_types: list[str] = []
    unknown_rule_types: list[str] = []
    unavailable_rule_types: list[str] = []
    effective_rule_types: list[str] = []

    for rule_type in deduped_rule_types:
        entry = catalog_map.get(rule_type)
        if entry is None:
            unknown_rule_types.append(rule_type)
            continue
        configured_rule_types.append(rule_type)
        if entry.enabled:
            effective_rule_types.append(rule_type)
        else:
            unavailable_rule_types.append(rule_type)

    return EffectiveRuleSelection(
        mode="custom",
        configured_rule_types=configured_rule_types,
        unknown_rule_types=unknown_rule_types,
        unavailable_rule_types=unavailable_rule_types,
        effective_rule_types=effective_rule_types,
    )


def register_detection_rule_class(
    rule_class: type[BaseDetectionRule],
    default_thresholds: dict | None = None,
) -> None:
    if not issubclass(rule_class, BaseDetectionRule):
        raise TypeError(
            f"Rule class must extend BaseDetectionRule, got {rule_class.__name__}"
        )

    temp_instance = rule_class()
    existing_types = {
        existing_rule().rule_type for existing_rule in get_all_rule_classes()
    }
    if temp_instance.rule_type in existing_types:
        raise ValueError(f"Rule type '{temp_instance.rule_type}' is already registered")

    thresholds = default_thresholds or temp_instance.default_thresholds
    try:
        register_rule_thresholds(temp_instance.rule_type, thresholds)
    except ValueError:
        pass

    _REGISTERED_RULES.append(rule_class)
    logger.info("Registered custom detection rule: %s", temp_instance.rule_type)


def unregister_detection_rule_class(rule_type: str) -> bool:
    for index, rule_class in enumerate(_REGISTERED_RULES):
        if rule_class().rule_type == rule_type:
            _REGISTERED_RULES.pop(index)
            logger.info("Unregistered detection rule: %s", rule_type)
            return True
    return False


def get_registered_rule_types() -> list[str]:
    return [rule_class().rule_type for rule_class in _REGISTERED_RULES]


def clear_registered_rule_classes() -> None:
    _REGISTERED_RULES.clear()
    logger.debug("Cleared all registered detection rules")
