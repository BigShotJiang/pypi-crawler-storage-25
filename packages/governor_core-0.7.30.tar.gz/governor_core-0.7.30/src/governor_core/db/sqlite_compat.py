"""SQLite compatibility shim — promoted from tests/unit/fixtures/database.py.

Governor's production deployment runs Postgres; the CLI defaults to SQLite.
Several SQLAlchemy column types used in engine-owned models are Postgres-only
at the dialect level (``JSONB``, ``ARRAY``, native ``UUID``). This shim
transparently substitutes SQLite-compatible equivalents when an engine is
created against a ``sqlite:`` URL so the same ORM definitions work on both
backends.

Importing this module has no effect until ``apply_sqlite_compat()`` is called
against a bound metadata object.
"""

from __future__ import annotations

import logging
from datetime import datetime, timezone

from sqlalchemy import JSON, DateTime, MetaData, event
from sqlalchemy.dialects.postgresql import ARRAY, JSONB
from sqlalchemy.engine import Engine
from sqlalchemy.types import TypeDecorator

logger = logging.getLogger(__name__)


class _TZAwareDateTime(TypeDecorator):
    """Round-trip ``DateTime(timezone=True)`` values as UTC-aware on SQLite.

    SQLite stores datetimes as ISO strings without timezone information, so
    a value bound as tz-aware comes back tz-naive — and any subsequent
    subtraction/comparison against an aware ``datetime`` raises
    ``TypeError: can't subtract offset-naive and offset-aware datetimes``
    (the spec-141 shadow-validation crash). This decorator normalises both
    directions: bind values that lack tzinfo are assumed UTC, and result
    values without tzinfo get UTC re-attached on read.

    The substitution only happens when ``apply_sqlite_compat`` runs against
    a SQLite-bound metadata; PostgreSQL keeps the native ``DateTime
    WITH TIME ZONE`` behaviour and never sees this type.
    """

    impl = DateTime
    cache_ok = True

    def process_bind_param(self, value: datetime | None, dialect):  # noqa: ARG002
        if value is None:
            return None
        if value.tzinfo is None:
            return value.replace(tzinfo=timezone.utc)
        return value.astimezone(timezone.utc)

    def process_result_value(self, value: datetime | None, dialect):  # noqa: ARG002
        if value is None:
            return None
        if value.tzinfo is None:
            return value.replace(tzinfo=timezone.utc)
        return value


def apply_sqlite_compat(metadata: MetaData) -> None:
    """Substitute PG-only column types with SQLite-compatible ones.

    Must be called AFTER all models have registered with the metadata but
    BEFORE the first create_all()/migration call. Idempotent.
    """
    for table in metadata.sorted_tables:
        for column in table.columns:
            if isinstance(column.type, JSONB):
                column.type = JSON()
            elif isinstance(column.type, ARRAY):
                # SQLite has no native array; JSON is the pragmatic substitute.
                column.type = JSON()
            elif (
                isinstance(column.type, DateTime)
                and not isinstance(column.type, _TZAwareDateTime)
                and column.type.timezone
            ):
                # SQLite drops tzinfo on read; wrap so values round-trip as UTC.
                column.type = _TZAwareDateTime()


def declare_web_stub_tables(metadata: MetaData) -> None:
    """Register minimal stub definitions for web-owned tables that core FKs to.

    Core-owned ORM models declare foreign keys like ``ForeignKey("users.id")``.
    Running core Alembic alone (e.g., from the CLI) requires the referenced
    tables to exist in ``Base.metadata`` for schema sorting to succeed. These
    stubs provide the minimum shape SQLAlchemy needs — the full columns are
    created by web Alembic migrations in cloud deployments.

    Skipped entirely if ``governor_web`` is already imported (its User / other
    web models have the authoritative definitions). This makes the function
    safe to call from the CLI even in a workspace where both packages are
    installed side-by-side.
    """
    import sys

    if "governor_web" in sys.modules:
        return

    from sqlalchemy import Column, String, Table

    web_stub_tables = (
        ("users", [Column("id", String(36), primary_key=True)]),
        ("verification_runs", [Column("id", String(36), primary_key=True)]),
    )
    for name, columns in web_stub_tables:
        if name in metadata.tables:
            continue
        Table(name, metadata, *columns)


def attach_sqlite_pragmas(engine: Engine) -> None:
    """Set runtime PRAGMAs for SQLite engines.

    - ``foreign_keys=ON`` — enable FK enforcement (off by default on SQLite).
    - ``journal_mode=WAL`` — better concurrency for a single-writer CLI.
    - Bump ``SQLITE_LIMIT_VARIABLE_NUMBER`` to 100_000 so ``WHERE col IN
      (?, ?, …)`` queries past the default 999-cap don't raise
      ``OperationalError: too many SQL variables``. Audit against busy
      warehouses routinely produces > 999 jobs over 24h, and several
      ``BigQueryJob.job_id.in_(…)`` call sites in ``governor_core`` are
      not chunked; bumping the cap once at connect-time covers them all.
    """
    if engine.dialect.name != "sqlite":
        return

    # SQLite category constant for max IN-clause / bound-parameter count.
    # The ``setlimit`` helper landed in Python 3.11 and clamps to the
    # build's compile-time ``SQLITE_MAX_VARIABLE_NUMBER`` (250_000 on
    # SQLite >= 3.32, 999 below) so 100_000 is safe to ask for unconditionally.
    _SQLITE_LIMIT_VARIABLE_NUMBER = 9
    _TARGET_VARIABLE_LIMIT = 100_000

    @event.listens_for(engine, "connect")
    def _set_sqlite_pragma(dbapi_connection, _connection_record):
        cursor = dbapi_connection.cursor()
        cursor.execute("PRAGMA foreign_keys=ON")
        cursor.execute("PRAGMA journal_mode=WAL")
        cursor.close()
        try:
            dbapi_connection.setlimit(
                _SQLITE_LIMIT_VARIABLE_NUMBER, _TARGET_VARIABLE_LIMIT
            )
        except Exception:  # noqa: BLE001
            pass
