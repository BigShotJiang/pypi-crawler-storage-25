"""Deterministic ``SELECT *`` → explicit column list rewriter.

Replaces the outermost ``SELECT *`` with a comma-separated list of
columns drawn from ``manifest_metadata["available_columns"]``. Skips
the rewrite cleanly (returns None) when:

  * the column list is missing or empty (e.g. no
    ``INFORMATION_SCHEMA.COLUMNS`` data has been synced for the table);
  * the SQL doesn't actually have an outer ``SELECT *`` (the rule may
    fire on edge cases the rewriter can't handle);
  * sqlglot can't parse the SQL.

Non-outer ``SELECT *`` (inside CTEs / subqueries / UNION arms) is left
alone — narrowing those is harder to do safely without column-flow
analysis. A future spec can extend this template with CTE-aware
rewrites.
"""

from __future__ import annotations

import logging
import re
from typing import Any

import sqlglot
from sqlglot import exp

from governor_core.solutions.templates.base import BaseTemplate, TemplateResult

logger = logging.getLogger("app.solutions.templates.expand_select_star")


_CTAS_PREAMBLE_RE = re.compile(
    r"\bcreate\s+(?:or\s+replace\s+)?(?:table|view|materialized\s+view)\b",
    re.IGNORECASE,
)
_AS_OPEN_PAREN_RE = re.compile(r"\bas\s*\(", re.IGNORECASE)


def _ctas_baseline_paren_depth(sql: str) -> int:
    """Return the paren-depth at which the outermost SELECT body lives.

    Standalone queries: the outer SELECT lives at depth 0. dbt-bigquery
    materialisations wrap the body in ``CREATE OR REPLACE TABLE … AS (
    … )`` (or with ``OPTIONS()`` and other clauses between the relation
    and ``AS``), so the outer SELECT inside that wrapper sits at depth
    1.

    Detection: locate the ``CREATE … TABLE/VIEW/MATERIALIZED VIEW``
    preamble, then the first ``AS (`` token after it. Both must be
    present for the wrapper to apply. ``OPTIONS()`` between the two is
    common (dbt-bigquery adapter emits it on every model) so we can't
    require ``[^()]`` in the gap.

    Conservative — anything we can't classify falls back to depth 0,
    matching the pre-fix behaviour for plain SELECTs.
    """
    create_match = _CTAS_PREAMBLE_RE.search(sql)
    if create_match is None:
        return 0
    as_match = _AS_OPEN_PAREN_RE.search(sql, pos=create_match.end())
    if as_match is None:
        return 0
    return 1


def _outermost_select(tree: exp.Expression) -> exp.Select | None:
    """Walk past INSERT / CREATE wrappers (and any Subquery the CTAS
    body is parsed into for ``CREATE OR REPLACE TABLE … OPTIONS() AS
    (…)``) to reach the innermost SELECT that BigQuery actually
    materialises.

    Kept in sync with the identically-named helper in
    ``governor_core.opportunities.rules.select_star``. Both this
    template and the rule must agree on what "outer SELECT" means;
    drift between them silently drops suggestions.
    """
    if isinstance(tree, exp.Select):
        return tree
    inner = tree.args.get("expression")
    if isinstance(inner, exp.Select):
        return inner
    if isinstance(inner, exp.Expression):
        return _outermost_select(inner)
    inner = tree.args.get("this")
    if isinstance(inner, exp.Select):
        return inner
    if isinstance(inner, exp.Expression) and not isinstance(inner, exp.Identifier):
        return _outermost_select(inner)
    return None


def _outer_select_star_span(sql: str) -> tuple[int, int] | None:
    """Return the (start, end) index of the outer ``SELECT *`` token in
    the original SQL, or None if it can't be located unambiguously.

    sqlglot parses + re-emits SQL but loses original whitespace and
    comments. To preserve those we identify the offending span via a
    case-insensitive regex over the original text and verify it's the
    OUTER-level ``*``: count parens at the position so we know we're
    not inside a CTE / subquery. For dbt-bigquery CTAS wrappers
    (``CREATE … AS ( … )``) the outer SELECT sits at paren-depth 1,
    not 0 — see ``_ctas_baseline_paren_depth``.
    """
    target_depth = _ctas_baseline_paren_depth(sql)
    pattern = re.compile(r"\bselect\s+(\*)(?=[\s,]|$)", re.IGNORECASE)
    for match in pattern.finditer(sql):
        star_start = match.start(1)
        # Count unbalanced opening parens to the left of the star.
        depth = 0
        for ch in sql[:star_start]:
            if ch == "(":
                depth += 1
            elif ch == ")":
                depth -= 1
        if depth == target_depth:
            return star_start, star_start + 1  # span of the literal "*"
    return None


def _outer_select_uses_star(sql: str) -> bool:
    """Belt-and-suspenders: confirm via sqlglot that the outer SELECT
    really is just a ``*`` (or ``t.*``) projection."""
    try:
        tree = sqlglot.parse_one(sql, dialect="bigquery")
    except Exception:  # noqa: BLE001
        return False
    if tree is None:
        return False
    select = _outermost_select(tree)
    if select is None:
        return False
    expressions = select.expressions or []
    if not expressions:
        return False
    return all(
        isinstance(e, exp.Star)
        or (isinstance(e, exp.Column) and isinstance(e.this, exp.Star))
        for e in expressions
    )


class ExpandSelectStarTemplate(BaseTemplate):
    """Replace outer ``SELECT *`` with the explicit column list."""

    template_id = "expand_select_star"
    applicable_types = {"select_star"}

    def matches(
        self,
        opportunity,
        source_files: dict[str, str],
        manifest_metadata: dict[str, Any] | None,
    ) -> bool:
        if opportunity.opportunity_type not in self.applicable_types:
            return False
        meta = manifest_metadata or {}
        file_path = meta.get("original_file_path", "")
        if not file_path or not source_files.get(file_path):
            return False
        columns = meta.get("available_columns") or []
        return bool(columns)

    def apply(
        self,
        opportunity,
        source_files: dict[str, str],
        manifest_metadata: dict[str, Any] | None,
    ) -> TemplateResult | None:
        meta = manifest_metadata or {}
        file_path = meta.get("original_file_path", "")
        before_content = source_files.get(file_path, "")
        columns: list[str] = list(meta.get("available_columns") or [])
        if not before_content or not columns:
            return None

        if not _outer_select_uses_star(before_content):
            return None

        span = _outer_select_star_span(before_content)
        if span is None:
            return None
        start, end = span

        column_list = ",\n  ".join(columns)
        # Indent the list by 2 spaces to match the surrounding "select"
        # block visually. The user can run gofmt-equivalent later.
        replacement = column_list
        after_content = before_content[:start] + replacement + before_content[end:]

        if after_content == before_content:
            return None

        explanation = (
            f"Expanded outer `SELECT *` into the explicit column list "
            f"({len(columns)} columns) so BigQuery materialises only the "
            f"columns the consumer reads. Source list pulled from "
            f"`INFORMATION_SCHEMA.COLUMNS` for "
            f"`{meta.get('database', '?')}.{meta.get('schema', '?')}."
            f"{meta.get('identifier', '?')}`."
        )

        return TemplateResult(
            template_id=self.template_id,
            file_path=file_path,
            before_content=before_content,
            after_content=after_content,
            change_type="sql_change",
            explanation=explanation,
            policy_tags=["sql_change"],
            parameters={"columns_count": len(columns)},
            rollback=(
                "Replace the explicit column list back with `*` if you "
                "intentionally need every column the source table emits."
            ),
        )

    def rollback_instructions(self) -> str:
        return "Replace the explicit column list back with `*`."


__all__ = ["ExpandSelectStarTemplate"]
