"""Scrub setup_state.github_private_key when env-var fallback is set.

Revision ID: p_scrub_github_key
Revises: p126_solution_file_changes
Create Date: 2026-04-30

For non-local-dev installs that have ``GITHUB_APP_ID`` /
``GITHUB_APP_PRIVATE_KEY`` / ``GITHUB_APP_INSTALLATION_ID`` already set in
the environment, drop the persisted ``github_private_key`` from
``setup_state``. The runtime resolver in
``governor_core.setup.runtime.resolve_github_configuration`` already falls
back to ``Settings`` for cloud installs, so removing the column value is
safe — the env var becomes the source of truth.

Local-dev rows are left untouched: their resolver branch does not consult
env vars, and scrubbing would break GitHub for that install.

Rows are also left untouched if any of the three env vars is unset; the
operator must set them and re-run this migration (or do it by hand) to
get the security benefit.
"""

from __future__ import annotations

import logging
import os

import sqlalchemy as sa
from alembic import op

revision = "p_scrub_github_key"
down_revision = "p126_solution_file_changes"
branch_labels = None
depends_on = None

logger = logging.getLogger("alembic.runtime.migration")


def _env_fallback_present() -> bool:
    return all(
        os.environ.get(name)
        for name in (
            "GITHUB_APP_ID",
            "GITHUB_APP_PRIVATE_KEY",
            "GITHUB_APP_INSTALLATION_ID",
        )
    )


def upgrade() -> None:
    if not _env_fallback_present():
        logger.warning(
            "p_scrub_github_key: GITHUB_APP_* env vars not all set — "
            "leaving setup_state.github_private_key in place. "
            "Set the env vars and re-run to scrub."
        )
        return

    result = op.get_bind().execute(
        sa.text(
            "UPDATE setup_state SET github_private_key = NULL "
            "WHERE installation_mode != 'local_dev' "
            "AND github_auth_mode = 'app' "
            "AND github_private_key IS NOT NULL"
        )
    )
    logger.info(
        "p_scrub_github_key: scrubbed %s setup_state row(s)", result.rowcount
    )


def downgrade() -> None:
    # The original key value cannot be restored — operators that need to
    # roll this back must re-enter the key via the wizard or settings UI.
    pass
