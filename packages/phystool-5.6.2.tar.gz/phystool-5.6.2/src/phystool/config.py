import datetime
import locale
import re
import sys

from configparser import ConfigParser, SectionProxy
from logging import critical
from logging.config import dictConfig
from pathlib import Path
from typing import Any
from uuid import UUID, uuid4


try:
    locale.setlocale(locale.LC_ALL, "fr_CH.UTF-8")
except locale.Error:  # NOTE: readthedocs isn't happy with this call
    pass


class ConfigurationError(ValueError):
    _config_error = "ConfigurationError"

    def __init__(self, *args) -> None:
        super().__init__(self._config_error.format(*args))


class CEMissingConf(ConfigurationError):
    _config_error = "Main configuration file not found"


class CEUndefinedDb(ConfigurationError):
    _config_error = "Undefined default database ({})"


class CEDbDirNotFound(ConfigurationError):
    _config_error = "Database {}: {} not found"

    def __init__(self, db_name: str, db_dir: Path) -> None:
        self.db_name = db_name
        super().__init__(db_name, db_dir)


class CEDbConfNotFound(ConfigurationError):
    _config_error = "Database {}: {} not found"


class CEGitClone(ConfigurationError):
    _config_error = "Git clone failed ({})"


class CEKey(ConfigurationError):
    _config_error = "Database {}: missing key ({})"


class CEPdbType(ConfigurationError):
    _config_error = "Database {}: undefined PDBType"


class CEDocumentclass(ConfigurationError):
    _config_error = "Database {}: undefined documentclass"


class MyConfigParser(ConfigParser):
    _DELTA_THEME_COMMON = (
        " --file-decoration-style 'darkgoldenrod overline'"
        " --file-style 'darkgoldenrod bold'"
        " --file-added-label '[+]'"
        " --file-copied-label '[C]'"
        " --file-modified-label '[*]'"
        " --file-removed-label '[-]'"
        " --file-renamed-label '[→]'"
        " --line-numbers"
        " --line-numbers-left-format '{nm:>1}┊'"
        " --line-numbers-right-format '{np:>1}┊'"
        " --no-gitconfig"
        " --side-by-side"
        " --width 200"
        " --zero-style 'syntax'"
    )
    _DELTA_THEME_LIGHT = (
        " --light"
        " --hunk-header-decoration-style 'none'"
        " --hunk-header-file-style 'darkgoldenrod'"
        " --hunk-header-line-number-style 'orange'"
        " --hunk-header-style 'file line-number purple'"
        " --line-numbers-left-style 'darkgrey'"
        " --line-numbers-minus-style 'red'"
        " --line-numbers-plus-style 'green'"
        " --line-numbers-right-style 'orange'"
        " --line-numbers-zero-style 'darkgray'"
        " --minus-emph-style 'black tomato underline'"
        " --minus-empty-line-marker-style 'normal orangered'"
        " --minus-style 'syntax lightpink'"
        " --plus-emph-style 'black limegreen underline'"
        " --plus-empty-line-marker-style 'normal forestgreen'"
        " --plus-style 'syntax lightgreen'"
        " --syntax-theme 'Coldark-Cold'"
        " --whitespace-error-style 'black white'"
    )
    _DELTA_THEME_DARK = (
        " --dark"
        " --hunk-header-style 'syntax bold italic 237'"
        " --line-numbers-left-style 'red'"
        " --line-numbers-minus-style 'red bold'"
        " --line-numbers-plus-style 'green bold'"
        " --line-numbers-right-style 'green'"
        " --line-numbers-zero-style '\"#545474\" italic'"
        " --minus-emph-style 'normal \"#80002a\"'"
        " --minus-style 'normal \"#5e0000\"'"
        " --plus-emph-style 'syntax bold \"#007e5e\"'"
        " --plus-style 'syntax \"#003500\"'"
        " --syntax-theme 'OneHalfDark'"
        " --whitespace-error-style '\"#80002a\" reverse'"
    )

    def __init__(self) -> None:
        super().__init__(default_section="general")

    def load(self) -> None:
        self.EDITOR_CMD = self["general"]["editor"].split(" ")
        match theme := self["general"].get("delta", "dark"):
            case "dark":
                self.DELTA_THEME = self._DELTA_THEME_DARK + self._DELTA_THEME_COMMON
            case "light":
                self.DELTA_THEME = self._DELTA_THEME_LIGHT + self._DELTA_THEME_COMMON
            case _:
                self.DELTA_THEME = theme

        self._dbs_config = {
            section_name[3:]: self[section_name]
            for section_name in self.sections()
            if section_name.startswith("db=")
        }
        self.db: DatabaseConfig
        self.setup_db(self["general"]["db"])

    def setup_db(self, db_name: str) -> None:
        if conf := self._dbs_config.get(db_name, None):
            self.db = DatabaseConfig(db_name, conf)
        else:
            raise CEUndefinedDb(db_name)

    def get_db_list(self) -> list[str]:
        return list(self._dbs_config.keys())

    def new_pdb_filename(self) -> str:
        return str((self.db.DB_DIR / str(uuid4())).with_suffix(".tex"))


class DatabaseConfig:
    def __init__(self, name: str, conf: SectionProxy):
        self.NAME = name
        self.REMOTE_URL = conf["repo"]
        self.DB_DIR = Path(conf["path"]).expanduser()
        self.PHYSTEX = self.DB_DIR / "phystex"
        if not self.DB_DIR.exists():
            raise CEDbDirNotFound(self.NAME, self.DB_DIR)
        conf_file = self.DB_DIR / "0_physdb.conf"
        if not conf_file.exists():
            raise CEDbConfNotFound(self.NAME, conf_file)

        try:
            db_conf = ConfigParser()
            db_conf.read(conf_file)
            self.PDB_TYPES = {
                section_name[9:]: (
                    re.compile(db_conf[section_name]["pattern"]),
                    db_conf[section_name].getboolean("standalone", fallback=False),
                )
                for section_name in sorted(db_conf.sections())
                if section_name.startswith("pdb-type=")
            }
            if not self.PDB_TYPES:
                raise CEPdbType(self.NAME)

            documentclass = db_conf["phystool"]["auto_latex"]
            if not (self.PHYSTEX / f"{documentclass}.cls").exists():
                raise CEDocumentclass(self.NAME)

            self._template = (
                f"\\documentclass{{{{{documentclass}}}}}\n"
                f"\\PdbSetDBPath{{{{{self.DB_DIR}/}}}}\n"
                "\\begin{{document}}\n"
                "    \\PdbInclude{{{uuid}}}\n"
                "\\end{{document}}"
            )
        except KeyError as e:
            raise CEKey(self.NAME, str(e))

    def template(self, uuid: UUID) -> str:
        return self._template.format(uuid=uuid)


class GeneralConfig:
    def __init__(self) -> None:
        # NOTE: The initialisation should be as light and fast as possible.
        # Should not raise any exceptions as they won't be caught. Any
        # exceptions should be raised by MyConfigParser or DatabaseConfig.
        self._conf: MyConfigParser | None = None
        _today = datetime.date.today()
        if _today.month > 7:
            self.CURRENT_SCOLAR_YEAR = _today.year
        else:
            self.CURRENT_SCOLAR_YEAR = _today.year - 1
        if (Path(__file__).parents[2] / "pyproject.toml").exists():
            self.LOGLEVEL = "DEBUG"
            self.CONF_DIR = Path(__file__).parents[1] / "dev"
        else:
            self.LOGLEVEL = "INFO"
            self.CONF_DIR = Path.home() / ".phystool"
        self.CONF_FILE = self.CONF_DIR / "phystool.conf"
        self.AUX_DIR = self.CONF_DIR / "texaux"
        if not self.AUX_DIR.exists():
            self.AUX_DIR.mkdir(parents=True)
        self.LOGFILE = self.CONF_DIR / "phystool.log"
        self.EVALUATION_PATH = self.CONF_DIR / "evaluation.json"

    def __getattr__(self, key: str) -> Any:
        if key in self.__dict__:
            return self.__dict__[key]
        if self._conf is None:
            self.reload()
        return getattr(self._conf, key)

    def reload(self) -> None:
        if not self.CONF_FILE.exists():
            raise CEMissingConf
        self._conf = MyConfigParser()
        self._conf.read(self.CONF_FILE)
        self._conf.load()


config = GeneralConfig()


########################################################################
# LOGGER ###############################################################
def _handle_uncaught_exception(exc_type, exc_value, exc_traceback):
    if issubclass(exc_type, KeyboardInterrupt):
        sys.__excepthook__(exc_type, exc_value, exc_traceback)
        return

    critical("Uncaught exception", exc_info=(exc_type, exc_value, exc_traceback))


sys.excepthook = _handle_uncaught_exception

LOGGER_BOTH = {
    "handlers": ["default", "file_handler"],
    "level": config.LOGLEVEL,
    "propagate": False,
}
LOGGER_FILE = {
    "handlers": ["file_handler"],
    "level": config.LOGLEVEL,
    "propagate": False,
}
LOGGER_ALCHEMY = {
    "handlers": ["file_handler"],
    "level": "WARN",
    "propagate": False,
}
LOGGING_CONFIG = {
    "version": 1,
    "disable_existing_loggers": True,
    "formatters": {
        "standard": {
            "format": "%(asctime)s [%(levelname)s] %(name)s %(lineno)d: %(message)s"
        },
        "minimal": {"format": "%(levelname)-.3s| %(message)s"},
    },
    "handlers": {
        "default": {
            "level": config.LOGLEVEL,
            "formatter": "minimal",
            "class": "logging.StreamHandler",
            "stream": "ext://sys.stderr",
        },
        "file_handler": {
            "level": "DEBUG",
            "formatter": "standard",
            "class": "logging.handlers.RotatingFileHandler",
            "filename": config.LOGFILE,
            "mode": "a",
            "maxBytes": 200000,
            "backupCount": 2,
        },
    },
    "loggers": {
        "__main__": LOGGER_BOTH,
        "helper": LOGGER_BOTH,
        "latex": LOGGER_BOTH,
        "pdbfile": LOGGER_BOTH,
        "physgit": LOGGER_BOTH,
        "physql": LOGGER_FILE,
        "phystool": LOGGER_BOTH,
        "qt": LOGGER_BOTH,
        "sqlalchemy": LOGGER_ALCHEMY,
        "tags": LOGGER_BOTH,
    },
}

# TODO : fix sql log verbosity in production
dictConfig(LOGGING_CONFIG)
