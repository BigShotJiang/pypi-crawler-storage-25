from logging import getLogger

from PySide6.QtCore import Slot, Qt
from PySide6.QtPdf import QPdfDocument
from PySide6.QtPdfWidgets import QPdfView
from PySide6.QtGui import QWheelEvent

from phystool.pdbfile import PDBFile

logger = getLogger(__name__)


class PdfWidget(QPdfView):
    def __init__(self) -> None:
        super().__init__()
        self.setPageMode(QPdfView.PageMode.MultiPage)
        self.setZoomMode(QPdfView.ZoomMode.FitInView)
        self.hbar = self.horizontalScrollBar()
        self.vbar = self.verticalScrollBar()
        self.doc: QPdfDocument | None = None

    @Slot(PDBFile)
    def display(self, pdb_file: PDBFile) -> None:
        self.doc = QPdfDocument(self)
        self.setDocument(self.doc)
        self.doc.load(str(pdb_file.tex_file.with_suffix(".pdf")))

    @Slot()
    def toggle_zoom_mode(self) -> None:
        self.setZoomMode(
            QPdfView.ZoomMode.FitToWidth
            if self.zoomMode() == QPdfView.ZoomMode.FitInView
            else QPdfView.ZoomMode.FitInView
        )

    def wheelEvent(self, arg__1: QWheelEvent) -> None:
        if arg__1.modifiers() & Qt.KeyboardModifier.ControlModifier:
            if self.zoomMode() != QPdfView.ZoomMode.Custom:
                self.setZoomMode(QPdfView.ZoomMode.Custom)

            pos = arg__1.position()

            x = self.hbar.value() + pos.x()
            y = self.vbar.value() + pos.y()

            oz = self.zoomFactor()
            nz = (
                min(5.0, oz * 1.02)
                if arg__1.angleDelta().y() > 0
                else max(0.2, oz / 1.02)
            )
            self.setZoomFactor(nz)

            scale = nz / oz
            self.hbar.setValue(int(x * scale - pos.x()))
            self.vbar.setValue(int(y * scale - pos.y()))

            arg__1.accept()
        else:
            super().wheelEvent(arg__1)

    def close(self):
        # Detach document from view first
        if self.doc is not None:
            self.doc.close()
            self.doc.deleteLater()
            self.doc = None
        return super().close()
