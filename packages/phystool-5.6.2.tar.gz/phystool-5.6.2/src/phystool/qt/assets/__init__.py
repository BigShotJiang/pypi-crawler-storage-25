import phystool.qt.assets.resources

from pathlib import Path
from PySide6.QtCore import QFile
from PySide6.QtGui import QIcon

qicon = QIcon(":/physnoob.svg")

_DESKTOP = """
[Desktop Entry]
Name=Physnoob
Exec=physnoob
Type=Application
Icon=physnoob
Categories=Utility;Science;Education;
"""


def save_assets(save_desktop: bool, save_icon: bool) -> None:
    home = Path.home()
    desktop_file = home / ".local/share/applications/Physnoob.desktop"
    icon_file = home / ".local/share/icons/hicolor/scalable/apps/physnoob.svg"
    if save_desktop:
        desktop_file.parent.mkdir(parents=True, exist_ok=True)
        desktop_file.write_text(_DESKTOP)
    else:
        desktop_file.unlink(missing_ok=True)

    if save_icon:
        icon_file.parent.mkdir(parents=True, exist_ok=True)
        f = QFile(":/physnoob.svg")
        if f.open(QFile.OpenModeFlag.ReadOnly):
            with icon_file.open("wb") as out:
                out.write(f.readAll().data())
            f.close()
    else:
        icon_file.unlink()


__all__ = ["qicon", "save_assets"]
