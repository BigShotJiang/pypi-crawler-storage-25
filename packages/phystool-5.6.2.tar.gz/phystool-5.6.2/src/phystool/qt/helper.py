from collections.abc import Callable
from logging import getLogger
from typing import Any, Iterator, cast

from PySide6.QtCore import (
    QSettings,
    Signal,
    Slot,
    QObject,
    Qt,
    QRunnable,
    QThreadPool,
)
from PySide6.QtWidgets import QHBoxLayout, QListWidget, QProgressDialog, QWidget

from phystool.tags import Tags
from phystool.config import config

logger = getLogger(__name__)


class WorkerSignals(QObject):
    finished = Signal(str)


class Worker(QRunnable):
    # https://www.pythonguis.com/tutorials/multithreading-pyside6-applications-qthreadpool/

    def __init__(self, fn: Callable[[], str]) -> None:
        super().__init__()
        self.fn = fn
        self.signals = WorkerSignals()

    def run(self):
        try:
            msg = self.fn()
        except Exception as e:
            msg = str(e)
        self.signals.finished.emit(msg)


class QBusyDialog(QProgressDialog):
    def __init__(self, parent: QWidget, label: str):
        super().__init__(label, "", 0, 0, parent)
        self.setCancelButton(None)
        self.setWindowModality(Qt.WindowModality.WindowModal)

    @Slot(str)
    def _finished(self, msg: str) -> None:
        self.setCancelButtonText("Ok")
        self.setLabelText(msg)

    def run(self, task: Callable[[], Any]) -> None:
        self.show()
        worker = Worker(task)
        worker.signals.finished.connect(self._finished)
        QThreadPool.globalInstance().start(worker)


class QStepProgressDialog(QProgressDialog):
    def __init__(self, label: str, parent: QWidget):
        super().__init__(label, "Annuler", 0, 1, parent)
        self.setAutoClose(False)
        self.setAutoReset(False)
        self.setWindowModality(Qt.WindowModality.WindowModal)
        self.setMinimumDuration(0)
        self.setValue(1)

    def run(self, f: Callable[[], Iterator[tuple[int, int, str]]]) -> None:
        _message = ""
        _n = 0
        for i, n, message in f():
            if self.wasCanceled():
                return
            if _n != n:
                _n = n
                self.setMaximum(n)
            if _message != message:
                _message = message
                self.setLabelText(message)
            self.setValue(i)

        self.setCancelButtonText("Ok")


class MultipleSelectionWidget(QWidget):
    def __init__(self, left_labels: list[str], right_labels: list[str]):
        super().__init__()
        self.left = QListWidget()
        self.left.itemDoubleClicked.connect(self.move_to_right)
        self.left.setSortingEnabled(True)
        self.left.addItems(left_labels)

        self.right = QListWidget()
        self.right.itemDoubleClicked.connect(self.move_to_left)
        self.right.setSortingEnabled(True)
        self.right.addItems(right_labels)

        layout = QHBoxLayout(self)
        layout.addWidget(self.left)
        layout.addWidget(self.right)

    def _swap(self, a, b, item):
        row = a.row(item)
        a.takeItem(row)
        b.insertItem(0, item.text())

    @Slot()
    def move_to_right(self):
        self._swap(self.left, self.right, self.left.currentItem())

    @Slot()
    def move_to_left(self):
        self._swap(self.right, self.left, self.right.currentItem())

    def get_right_values(self) -> set[str]:
        return {self.right.item(i).text() for i in range(self.right.count())}


class MyQSettings(QSettings):
    def _get_list(self, name: str) -> list:
        return cast(list, self.value(name, type=list) or [])

    def get_tags(self, name: str) -> Tags:
        try:
            return Tags.manager.from_ids(
                {int(tag_id) for tag_id in self._get_list(f"{config.db.NAME}/{name}")}
            )
        except Exception as e:
            logger.exception(e)
            logger.error(f"Reading stettings failed {name}, using defaults")
            return Tags({})

    def get_pdb_types(self, name: str) -> set[str]:
        try:
            return {
                pdb_type
                for pdb_type in self._get_list(f"{config.db.NAME}/{name}")
                if pdb_type in config.db.PDB_TYPES
            }
        except Exception as e:
            logger.exception(e)
            logger.error(f"Reading stettings failed {name}, using defaults")
            return set()

    def save_tags(self, name: str, tags: Tags) -> None:
        self.setValue(f"{config.db.NAME}/{name}", list(tags.as_ids()))

    def save_pdb_types(self, name: str, pdb_types: set[str]) -> None:
        self.setValue(f"{config.db.NAME}/{name}", list(pdb_types))
