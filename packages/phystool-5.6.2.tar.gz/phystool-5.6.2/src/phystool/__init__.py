from logging import getLogger

logger = getLogger(__name__)


def phystool() -> None:
    """Run the command line interface"""
    from phystool.cli import get_parser

    args = get_parser(color=True).parse_args()
    args.func(args)


def physnoob() -> None:
    """Run the graphical user interface"""
    from phystool.qt import PhysNoob

    phys_noob = PhysNoob()
    phys_noob.exec()
