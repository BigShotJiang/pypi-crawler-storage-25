"""
Default settings configuration module.

This module contains the default settings and configuration values used throughout
the JohnSnowLabs endpoints application. It defines constants for model locations,
directory paths, package information, and platform-specific configurations.
"""

import os

from endpoints import Platform

MODEL_LOCATION = os.environ.get("MODEL_LOCATION", "/opt/ml/model")
HOME_DIR = os.path.expanduser("~")

DEFAULT_JOHNSNOWLABS_VERSION = "6.2.0"
JSL_DOWNLOAD_PACKAGES = os.environ.get("JSL_DOWNLOAD_PACKAGES", True)
JSL_CACHE_PRETRAINED_DIR = os.path.join(HOME_DIR, "cache_pretrained")

ROOT_DIR = os.path.dirname(os.path.abspath(__file__))
PACKAGE_NAME = "ksh-jsl-inference"

DEFAULT_IMAGE_REPOSITORY_NAME = "jsl_inference"

TARGET_PLATFORM = Platform(os.environ.get("PLATFORM", "sagemaker"))

os.environ.setdefault("TF_CPP_MIN_LOG_LEVEL", "3")
