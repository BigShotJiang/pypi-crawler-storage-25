"""JSL Inference Module"""

from enum import Enum


class ModelType(str, Enum):
    LOCAL = "local"
    PRETRAINED_HEALTHCARE = "pretrained_healthcare"
    PRETRAINED_VISUAL = "pretrained_visual"
    CHROMADB_RESOLVER = "chromadb_resolver"


class Platform(str, Enum):
    SAGEMAKER = "sagemaker"
    SNOWFLAKE = "snowflake"
    LOCAL = "local"

    def get_python_requirements(self):
        if self == Platform.SNOWFLAKE or Platform.LOCAL:
            return ["snowflake.core"]
        return []


class JslInferenceException(Exception):
    """Exception for JSL Inference errors"""

    pass
