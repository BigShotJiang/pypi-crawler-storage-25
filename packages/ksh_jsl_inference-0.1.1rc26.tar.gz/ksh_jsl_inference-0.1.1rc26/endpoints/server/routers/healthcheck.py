from fastapi import APIRouter

router = APIRouter()


@router.get("/ping")
async def readiness_probe():
    """Return readiness status for health checks.

    Returns:
        str: Readiness message for the service.
    """
    return "Ready"
