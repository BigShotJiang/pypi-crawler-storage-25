import json
import logging
import os
from pathlib import Path

import boto3
from botocore.client import Config
from custom_logging import logger


def suppress_external_loggers():
    """Suppress logging from external libraries"""
    for logger_name in [
        "boto3",
        "botocore",
        "s3transfer",
        "urllib3",
    ]:
        logging.getLogger(logger_name).setLevel(logging.WARNING)
        logging.getLogger(logger_name).propagate = False


suppress_external_loggers()

S3_BUCKET_NAME = "medllms.johnsnowlabs.com"
_s3_client = None


def get_s3_client(aws_creds=None):
    """
    Returns a singleton S3 client instance.

    Args:
        aws_creds: Optional dictionary containing AWS credentials
    """
    global _s3_client
    if _s3_client is None:
        config = Config(
            connect_timeout=5,
            retries={"max_attempts": 3},
        )

        if aws_creds:
            _s3_client = boto3.client(
                "s3",
                aws_access_key_id=aws_creds["accessKeyId"],
                aws_secret_access_key=aws_creds["secretAccessKey"],
                aws_session_token=aws_creds["sessionToken"],
                config=config,
            )
        else:
            _s3_client = boto3.client("s3", config=config)

    return _s3_client


def download_model_from_s3(
    s3_client, local_model_dir, s3_model_folder, tensor_parallel_size
):
    """
    Downloads the model files from S3.

    Parameters:
        s3_client: boto3 S3 client
        local_model_dir (str): The local directory name to save files to
        s3_model_folder (str): The S3 folder name to download from
        tensor_parallel_size (int): Number of GPUs for tensor parallelism
    """
    model_local_dir = Path(local_model_dir)
    tmp_dir = Path("/tmp")

    model_local_dir.mkdir(parents=True, exist_ok=True)

    model_prefix = f"models/tensorized/{s3_model_folder}/model_files/"

    try:
        paginator = s3_client.get_paginator("list_objects_v2")
        for page in paginator.paginate(Bucket=S3_BUCKET_NAME, Prefix=model_prefix):
            for obj in page.get("Contents", []):
                if obj["Key"].endswith("/"):
                    continue

                file_name = os.path.basename(obj["Key"])
                local_file_path = model_local_dir / file_name

                try:
                    s3_client.download_file(
                        S3_BUCKET_NAME, obj["Key"], str(local_file_path)
                    )
                except Exception as e:
                    error_msg = f"Failed to download {file_name}: {str(e)}"
                    logger.error(error_msg)
                    raise

        key_filename = f"encryption-tp{tensor_parallel_size}.key"
        key_s3_path = (
            f"models/tensorized/{s3_model_folder}/encryption_keyfile/{key_filename}"
        )
        key_local_path = tmp_dir / "encryption.key"
        s3_client.download_file(S3_BUCKET_NAME, key_s3_path, str(key_local_path))

        message = "Model files download completed successfully"
        logger.info(message)
        return str(model_local_dir)

    except Exception as e:
        raise


def get_medllm_config(s3_client, model_name: str) -> dict:
    """
    Gets complete model configuration including versions.

    Args:
        s3_client: boto3 S3 client
        model_name: Name of the model

    Returns:
        dict: Model configuration containing:
            - versions: Dict of available versions with their model names and TP sizes

    Raises:
        ValueError: If model isn't supported
    """
    try:
        response = s3_client.get_object(
            Bucket=S3_BUCKET_NAME, Key="models/tensorized/medllm_config.json"
        )
        model_configs = json.loads(response["Body"].read().decode("utf-8"))

        if model_name not in model_configs:
            error_message = f"Unsupported Model: {model_name}. Available models: {', '.join(sorted(model_configs.keys()))}"
            raise ValueError(error_message)

        model_config = model_configs[model_name]
        return model_config

    except Exception as e:
        error_message = f"Error loading model configuration: {e}"
        logger.error(error_message)
        raise


def resolve_model_version(
    model_config: dict, model_name: str, version: str
) -> tuple[str, list]:
    """
    Resolves the actual S3 folder name and supported TP sizes for a given model and version.

    Args:
        model_config: Model configuration dictionary (from get_medllm_config)
        model_name: Name of the model (e.g., "Medical-LLM-8B") - used for error messages
        version: Version to resolve (e.g., "latest", "v1", "v2")

    Returns:
        tuple: (The actual S3 folder name, List of supported TP sizes for this version)

    Raises:
        ValueError: If version is not supported
    """
    try:
        versions = model_config["versions"]

        if version not in versions:
            actual_versions = [v for v in sorted(versions.keys()) if v != "latest"]
            available_versions = ", ".join(actual_versions)
            error_message = f"Unsupported version '{version}' for model '{model_name}'. Available versions: {available_versions} (or use 'latest' for the most recent)"
            raise ValueError(error_message)

        version_config = versions[version]
        s3_model_folder = version_config["model"]
        supported_tp_sizes = version_config["supported_tp_sizes"]

        return s3_model_folder, supported_tp_sizes

    except Exception as e:
        error_message = f"Error resolving model version: {e}"
        logger.error(error_message)
        raise


def ensure_model(
    model_ref: str, handler, tensor_parallel_size: int, version: str = "latest"
) -> tuple[list, str]:
    """
    Ensures model availability and configuration requirements are met.
    Args:
        model_ref: Model name/reference to validate and download
        handler: LicenseHandler instance for AWS credentials
        tensor_parallel_size: Number of GPUs for tensor parallelism
        version: Version of the model to use (default: "latest")

    Returns:
        tuple: (License scopes derived from model_ref, Actual S3 folder name)

    Raises:
        ValueError: If model configuration is invalid or tensor parallel size not supported
        SystemExit: If AWS credentials setup fails
    """
    message = f"Validating model configuration for {model_ref} version {version}..."
    logger.info(message)

    try:
        aws_creds = handler.lv.get_aws_credentials()
        s3_client = get_s3_client(aws_creds)

        model_config = get_medllm_config(s3_client, model_ref)

        s3_model_folder, version_tp_sizes = resolve_model_version(
            model_config, model_ref, version
        )

        if tensor_parallel_size not in version_tp_sizes:
            error_msg = f"Unsupported tensor parallel size: {tensor_parallel_size}. Supported sizes for {model_ref} version {version} are: {version_tp_sizes}"
            raise ValueError(error_msg)

        download_model_from_s3(
            s3_client, model_ref, s3_model_folder, tensor_parallel_size
        )
        return [model_ref], s3_model_folder

    except Exception as e:
        raise


def get_tensorizer_uri(model_folder_name, tensor_parallel_size):
    """
    Gets the S3 URI for the tensorized model file.
    Handles both single and tensor-parallel (sharded) models.

    Parameters:
        model_folder_name (str): The actual model folder name in S3 (e.g., "JSL-Qwen3-8B")
        tensor_parallel_size (int): Number of GPUs for tensor parallelism

    Returns:
        str: S3 URI for the tensorized model file
    """
    try:
        model_name = os.path.basename(model_folder_name)

        if tensor_parallel_size > 1:
            base_path = (
                f"models/tensorized/{model_name}/tensorized/{tensor_parallel_size}gpu"
            )
            tensor_path = f"{base_path}/model-rank-%03d.tensors"
        else:
            base_path = f"models/tensorized/{model_name}/tensorized/1gpu"
            tensor_path = f"{base_path}/model.tensors"

        return f"s3://{S3_BUCKET_NAME}/{tensor_path}"

    except Exception as e:
        error_msg = f"Error determining tensorizer URI: {e}"
        logger.error(error_msg)
        raise


def get_spark_nlp_license():
    """
    Recursively searches for license.json file in /app and /opt directories.
    Returns the SPARK_NLP_LICENSE value if found, None otherwise.
    """
    base_paths = [Path("/app"), Path("/opt")]

    for base_path in base_paths:
        if not base_path.exists():
            continue

        try:
            for path in base_path.glob("**/license.json"):
                try:
                    with open(path) as f:
                        license_data = json.load(f)
                        if "SPARK_NLP_LICENSE" in license_data:
                            message = f"Found license file at: {path}"
                            logger.info(message)
                            return license_data["SPARK_NLP_LICENSE"]
                except Exception as e:
                    continue
        except Exception as e:
            continue

    return None


def is_marketplace() -> bool:
    """Check if the application is running in marketplace mode (AWS or Azure)."""
    return (
        os.environ.get("JSL_AWS_PLATFORM") == "1"
        or os.environ.get("JSL_AZURE_PLATFORM") == "1"
    )
