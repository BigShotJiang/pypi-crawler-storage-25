import glob
import os
from dataclasses import dataclass
from typing import Dict, List, Optional

import cloudpickle

from endpoints import ModelType
from endpoints.core.exceptions import ModelRegistryException
from endpoints.core.models import BaseModel
from endpoints.johnsnowlabs.models import (
    ChromaDbResolverModel,
    DeidentificationModel,
    MedNlpModel,
)
from endpoints.logging import logger
from endpoints.settings import HOME_DIR
from endpoints.utils import validate_artifacts_path


@dataclass
class ModelInfo:
    """Data class for storing information about a registered model.

    Attributes:
        id (str): Unique identifier for the model
        model (BaseModel): The model instance that handles inference
        language (str): Language code for the model (default: "en")
        model_type (ModelType): The type for this model (default: ModelType.HEALTHCARE_NLP)
        artifacts_path (Optional[str]): Path to model artifacts, only used when model_type is ModelType.LOCAL

    Examples:
        ```python
        from endpoints.core.model_registry import ModelInfo
        from endpoints.johnsnowlabs.models import MedNlpModel
        from endpoints import ModelType

        # Create a ModelInfo instance for a medical NLP model
        model_info = ModelInfo(
            id="medical_ner_model",
            model=MedNlpModel(),
            language="en",
            model_type=ModelType.HEALTHCARE_NLP
        )

        print(f"Model ID: {model_info.id}")
        print(f"Model key: {model_info.key}")
        ```
    """

    id: str
    model: BaseModel
    language: str = "en"  # en, de, gr
    model_type: ModelType = ModelType.PRETRAINED_HEALTHCARE
    # artifacts_path only used when model_type is ModelType.LOCAL
    artifacts_path: Optional[str] = None

    @staticmethod
    def generate_key(model_id: str, language: str) -> str:
        """Generate a key from model_id and language.

        Args:
            model_id: The model identifier
            language: The language code

        Returns:
            The key for the model info

        """
        import base64

        # Use base64 encoding to make it safe for S3 keys
        key_string = f"{model_id}##{language}"
        return base64.b64encode(key_string.encode("utf-8")).decode("ascii")

    @property
    def key(self) -> str:
        """Get the unique key for this model instance.

        Returns:
            str: The unique key for the model instance

        """
        return self.generate_key(self.id, self.language)


class ModelRegistry:
    """Global registry for managing all available ModelInfo instances.

    Examples:
        ```python
        from endpoints.core.model_registry import ModelRegistry
        from endpoints import ModelType

        # Register a new model
        model_info = ModelRegistry.register("my_model", language="en")

        # Find a registered model
        found_model = ModelRegistry.find("my_model", "en")

        # Get all models
        all_models = ModelRegistry.get_all()

        # Get models by model_type
        nlp_models = ModelRegistry.get_by_model_type(ModelType.HEALTHCARE_NLP)

        # Check registry size
        count = ModelRegistry.count()
        print(f"Registry contains {count} models")
        ```
    """

    _key_to_models: Dict[str, ModelInfo] = {}
    _default_medical_nlp_provider = MedNlpModel()
    _model_registry_persist_dir = os.path.join(
        HOME_DIR, ".jsl_inference", "model_registry"
    )

    @staticmethod
    def get_persisted_dir() -> str:
        """Get the directory path where ModelInfo objects are persisted.

        Creates the directory if it doesn't exist.

        Returns:
            str: The path to the model registry persistence directory

        """
        dir = ModelRegistry._model_registry_persist_dir
        # Make sure directory exists
        os.makedirs(dir, exist_ok=True)
        return dir

    @staticmethod
    def persist(model_info: ModelInfo):
        """Persist a ModelInfo object to disk using cloudpickle serialization.

        This method serializes the given ModelInfo object and saves it as a pickle file
        in the model registry persistence directory. The inference provider's module
        is modified to __main__ to ensure proper serialization by cloudpickle.

        Args:
            model_info (ModelInfo): The ModelInfo object to persist to disk.

        """
        # Make sure for persisted model info, their model are in the __main__ module, so that
        # cloudpickle can serialize it by value
        model_info.model.__class__.__module__ = "__main__"

        serialized = cloudpickle.dumps(model_info)
        path = ModelRegistry._model_registry_persist_dir
        # Make sure path exists
        os.makedirs(path, exist_ok=True)
        with open(os.path.join(path, f"{model_info.key}.pkl"), "wb") as file:
            file.write(serialized)

    @staticmethod
    def remove(model_info: ModelInfo):
        """Remove a ModelInfo object from the registry and optionally from disk.

        This method removes the given ModelInfo object from the in-memory registry
        using its key. If a persisted file exists for this model, it will also be
        removed from disk.

        Args:
            model_info (ModelInfo): The ModelInfo object to remove from the registry.

        """
        # Remove from in-memory registry
        if model_info.key in ModelRegistry._key_to_models:
            del ModelRegistry._key_to_models[model_info.key]

        # Remove persisted file if it exists
        persisted_file_path = os.path.join(
            ModelRegistry._model_registry_persist_dir, f"{model_info.key}.pkl"
        )
        if os.path.exists(persisted_file_path):
            try:
                os.remove(persisted_file_path)
                logger.info(f"Removed persisted model file: {persisted_file_path}")
            except OSError as e:
                logger.warning(
                    f"Failed to remove persisted model file {persisted_file_path}: {e}"
                )

    @staticmethod
    def register(
        model_id: str,
        language: str = "en",
        model: Optional[BaseModel] = None,
        model_type: ModelType = ModelType.PRETRAINED_HEALTHCARE,
        artifacts_path: Optional[str] = None,
        persist: bool = False,  # Warning. Only set persist=True, when building docker images
    ) -> ModelInfo:
        """Register a new ModelInfo instance in the registry.

        Args:
            model_id (str): The unique identifier for the model
            language (str, optional): The language code for the model. Defaults to "en"
            model (Optional[BaseModel], optional): The model instance. If None, uses the default medical NLP provider
            model_type (ModelType, optional): The model_type type for this model. Defaults to ModelType.HEALTHCARE_NLP
            artifacts_path (Optional[str]): Path to model artifacts, only used when model_type is ModelType.LOCAL
            persist (bool, optional): Whether to persist the model to disk. Defaults to False.

                Warning: Only set persist=True when building docker images

        Returns:
            ModelInfo: The registered ModelInfo instance

        """
        validated_path = artifacts_path
        if artifacts_path:
            validated_path = validate_artifacts_path(artifacts_path)

        if model is not None and not isinstance(model, BaseModel):
            raise ModelRegistryException(
                "model must be an instance of a BaseModel subclass"
            )

        model_info = ModelInfo(
            id=model_id,
            language=language,
            model=model or ModelRegistry._default_medical_nlp_provider,
            artifacts_path=validated_path,
            model_type=model_type,
        )
        ModelRegistry._key_to_models[model_info.key] = model_info

        if persist:
            ModelRegistry.persist(model_info)
        return model_info

    @staticmethod
    def load_persisted() -> List[ModelInfo]:
        """Load all persisted ModelInfo objects from disk.

        Scans the persistence directory for .pkl files and attempts to deserialize
        them into ModelInfo objects using cloudpickle. If deserialization fails
        for any file, a warning is logged and that file is skipped.

        Returns:
            List[ModelInfo]: A list of successfully loaded ModelInfo objects

        """
        persisted_files = glob.glob(
            f"{ModelRegistry._model_registry_persist_dir}/*.pkl"
        )
        model_infos: List[ModelInfo] = []
        for file_path in persisted_files:
            with open(file_path, "rb") as f:
                content = f.read()
                try:
                    model_infos.append(cloudpickle.loads(content))
                except:
                    logger.warning(f"Failed loading persisted model: {file_path}")
        return model_infos

    @staticmethod
    def get_by_key(key: str) -> ModelInfo:
        """Retrieve a ModelInfo instance by its unique key.

        Args:
            key (str): The unique key for the ModelInfo instance

        Returns:
            ModelInfo: The ModelInfo instance associated with the key

        Raises:
            KeyError: If no ModelInfo is found for the given key

        """
        return ModelRegistry._key_to_models[key]

    @staticmethod
    def find(model_id: str, language: str = "en") -> ModelInfo:
        """Retrieve a ModelInfo by its ID.

        Args:
            model_id: The ID of the model to retrieve
            language: The language code (default: "en")

        Returns:
            The ModelInfo instance if found

        Raises:
            ModelRegistryException: If the requested model is not registered

        """
        key = ModelInfo.generate_key(model_id, language)
        try:
            return ModelRegistry.get_by_key(key)
        except KeyError:
            raise ModelRegistryException(f"The requested model is not registered.")

    @staticmethod
    def get_by_type(model_type: ModelType) -> List[ModelInfo]:
        """Retrieve all ModelInfo instances for a specific model_type.

        Args:
            model_type: The ModelType to filter by

        Returns:
            List of ModelInfo instances matching the model_type

        """
        return [
            model
            for model in ModelRegistry._key_to_models.values()
            if model.model_type == model_type
        ]

    @staticmethod
    def get_all() -> List[ModelInfo]:
        """Get all registered ModelInfo instances.

        Returns:
            List of all registered ModelInfo instances

        """
        return list(ModelRegistry._key_to_models.values())

    @staticmethod
    def count() -> int:
        """Get the number of registered models.

        Returns:
            The number of registered ModelInfo instances

        """
        return len(ModelRegistry._key_to_models)

    @staticmethod
    def clear() -> bool:
        """Clear all registered models from the registry.

        Returns:
            True if the registry was successfully cleared

        """
        ModelRegistry._key_to_models.clear()
        return True

    @staticmethod
    def register_persisted():
        """Load and register all persisted models from disk into the registry.

        This method reads all .pkl files from the model registry persist directory,
        deserializes them into ModelInfo objects, and registers them in the in-memory
        registry using their keys. If loading fails, a warning is logged.

        """

        for model_info in ModelRegistry.load_persisted():
            ModelRegistry._key_to_models[model_info.key] = model_info

    @staticmethod
    def clear_persisted() -> bool:
        """Clear all persisted model files from disk.

        This method removes all .pkl files from the model registry persist directory.
        It does not affect models that are currently loaded in memory.

        Returns:
            bool: True if operation completed successfully, False if there was an error

        """
        try:
            persisted_files = glob.glob(
                f"{ModelRegistry._model_registry_persist_dir}/*.pkl"
            )

            for file_path in persisted_files:
                try:
                    os.remove(file_path)
                except OSError as e:
                    logger.warning(
                        f"Failed to remove persisted model file {file_path}: {e}"
                    )
                    return False

            logger.info(f"Cleared {len(persisted_files)} persisted model files.")
            return True

        except Exception as e:
            logger.warning(f"Failed to clear persisted models: {e}")
            return False


BASE_MEDICAL_NLP_INFERENCE = MedNlpModel()

HEALTHCARE_MODELS = []
for model in HEALTHCARE_MODELS:
    ModelRegistry.register(
        model_id=model,
        language="en",
    )


# Clinical Deidentification
ModelRegistry.register(
    model_id="clinical_deidentification_docwise_wip",
    language="en",
    model=DeidentificationModel("en"),
)

ModelRegistry.register(
    model_id="clinical_deidentification_docwise_wip",
    language="de",
    model=DeidentificationModel("de"),
)

ModelRegistry.register(
    model_id="clinical_deidentification",
    language="it",
    model=DeidentificationModel("it"),
)

ModelRegistry.register(
    model_id="clinical_deidentification",
    language="ar",
    model=DeidentificationModel("ar"),
)

ModelRegistry.register(
    model_id="clinical_deidentification",
    language="es",
    model=DeidentificationModel("es"),
)

ModelRegistry.register(
    model_id="clinical_deidentification",
    language="fr",
    model=DeidentificationModel("fr"),
)

ModelRegistry.register(
    model_id="clinical_deidentification",
    language="pt",
    model=DeidentificationModel("pt"),
)

ModelRegistry.register(
    model_id="clinical_deidentification",
    language="ro",
    model=DeidentificationModel("ro"),
)


# Chroma VDB Resolvers
ModelRegistry.register(
    model_id="rxnorm",
    language="en",
    model=ChromaDbResolverModel(),
    model_type=ModelType.CHROMADB_RESOLVER,
)


# Load Persisted Model so that it takes priority
ModelRegistry.register_persisted()
