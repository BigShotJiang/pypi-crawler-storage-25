import multiprocessing

from sparknlp.pretrained import LightPipeline, PretrainedPipeline

from endpoints.johnsnowlabs.spark_session import spark
from endpoints.logging import logger
from endpoints.settings import MODEL_LOCATION

spark = spark


class ModelLoader:
    _model = None

    @classmethod
    def load_model(cls):
        if cls._model is None:
            try:
                logger.info(f"Loading model from {MODEL_LOCATION}")
                cls._model = PretrainedPipeline.from_disk(MODEL_LOCATION)
                logger.info("Model loaded successfully")
            except Exception as e:
                logger.error(
                    f"Error loading model: {e}. Please make sure you have downloaded the model and placed it on {MODEL_LOCATION}"
                )
                raise
        return LightPipeline(cls._model.model)


logger.debug(f"vCPU Count: {multiprocessing.cpu_count()}")
light_pipeline = ModelLoader.load_model()
