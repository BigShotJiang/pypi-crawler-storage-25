import json
from typing import Dict, List

from pyspark.sql.dataframe import DataFrame
from pyspark.sql.functions import col

from endpoints.core.models.schema import Schema, SchemaCollection
from endpoints.utils import get_attr_or_key

from .med_nlp import MedNlpModel

_LANG_CONFIG = {
    "en": {
        "masked_col": "mask_entity",
        "sentence_col": "document",
        "policies": ["masked", "obfuscated"],
    },
    "de": {
        "masked_col": "masked",
        "sentence_col": "document",
        "policies": ["masked", "obfuscated"],
    },
    "it": {
        "masked_col": "masked",
        "sentence_col": "sentence",
        "policies": [
            "masked",
            "obfuscated",
            "masked_with_chars",
            "masked_fixed_length_chars",
        ],
    },
    "ar": {
        "masked_col": "masked_with_entity",
        "sentence_col": "sentence",
        "policies": [
            "masked",
            "obfuscated",
            "masked_with_chars",
            "masked_fixed_length_chars",
        ],
    },
    "es": {
        "masked_col": "masked",
        "sentence_col": "sentence",
        "policies": [
            "masked",
            "obfuscated",
            "masked_with_chars",
            "masked_fixed_length_chars",
        ],
    },
    "fr": {
        "masked_col": "masked",
        "sentence_col": "sentence",
        "policies": [
            "masked",
            "obfuscated",
            "masked_with_chars",
            "masked_fixed_length_chars",
        ],
    },
    "pt": {
        "masked_col": "masked",
        "sentence_col": "sentence",
        "policies": [
            "masked",
            "obfuscated",
            "masked_with_chars",
            "masked_fixed_length_chars",
        ],
    },
    "ro": {
        "masked_col": "masked",
        "sentence_col": "sentence",
        "policies": [
            "masked",
            "obfuscated",
            "masked_with_chars",
            "masked_fixed_length_chars",
        ],
    },
}

_CORE_POLICIES = {"masked", "obfuscated"}


class DeidentificationModel(MedNlpModel):
    def __init__(self, language: str = "en") -> None:
        super().__init__()
        config = _LANG_CONFIG[language]
        self._masked_col = config["masked_col"]
        self._sentence_col = config["sentence_col"]
        self._policies = config["policies"]
        # policies beyond the core two — column name matches policy name for all supported pipelines
        self._extra_cols = [p for p in self._policies if p not in _CORE_POLICIES]

        self._input_params = SchemaCollection(
            [
                Schema(
                    field="masking_policy",
                    typing=str,
                    required=False,
                    dtypes=self._policies,
                    default="masked",
                ),
            ]
        )
        self._output = Schema(field="predictions", typing=str)

    def _process_output(self, deid_res, text: str):
        sentences = deid_res.get(self._sentence_col, [])
        obfuscateds = deid_res.get("obfuscated", [])
        mask_entities = deid_res.get(self._masked_col, [])

        extra_lists = {c: deid_res.get(c, []) for c in self._extra_cols}
        extra_strs = {c: "" for c in self._extra_cols}

        sentence_begin = 0
        obfuscated_str = ""
        masked_str = ""

        for index, sent in enumerate(sentences):
            begin = get_attr_or_key(sent, "begin")
            end = get_attr_or_key(sent, "end")

            obfuscated_str += text[sentence_begin:begin] + get_attr_or_key(
                obfuscateds[index], "result"
            )
            masked_str += text[sentence_begin:begin] + get_attr_or_key(
                mask_entities[index], "result"
            )

            for c in self._extra_cols:
                extra_strs[c] += text[sentence_begin:begin] + get_attr_or_key(
                    extra_lists[c][index], "result"
                )

            sentence_begin = end + 1

        result = {"masked": masked_str.strip(), "obfuscated": obfuscated_str.strip()}
        result.update({c: s.strip() for c, s in extra_strs.items()})
        return result

    def process_pretrained_pipeline_results(
        self, inputs: List[str], results: DataFrame, params: Dict
    ):
        cols_to_select = [
            col(self._sentence_col).alias(self._sentence_col),
            col(self._masked_col).alias(self._masked_col),
            col("obfuscated").alias("obfuscated"),
        ]
        for c in self._extra_cols:
            cols_to_select.append(col(c).alias(c))

        output_df = results.select(*cols_to_select)
        json_result = output_df.toJSON().collect()
        prediction_results = list(map(json.loads, json_result))
        return [
            self._process_output(res, text)[param["masking_policy"]]
            for res, text, param in zip(prediction_results, inputs, params)
        ]

    def process_light_pipeline_results(
        self, inputs: List[str], results: List, params: Dict
    ):
        return [
            self._process_output(res, text)[param["masking_policy"]]
            for res, text, param in zip(results, inputs, params)
        ]
