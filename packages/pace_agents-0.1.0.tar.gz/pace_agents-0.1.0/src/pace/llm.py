"""OpenAI-compatible LLM HTTP client for PACE."""
from __future__ import annotations

import json
import urllib.error
import urllib.request
from typing import Any

from pace.config import PaceConfig
from pace.exceptions import LLMError


class LLMClient:
    """Sends chat completion requests to an OpenAI-compatible endpoint."""

    def __init__(self, config: PaceConfig, timeout: float = 30.0) -> None:
        self._config = config
        self._timeout = timeout

    def chat(self, messages: list[dict[str, Any]]) -> str:
        """Send *messages* to the configured endpoint and return the reply content.

        Raises:
            LLMError: on HTTP 4xx/5xx or any network/connection failure.
        """
        url = f"{self._config.llm_endpoint}/chat/completions"
        payload: dict[str, Any] = {
            "model": self._config.llm_model,
            "messages": messages,
            "stream": False,
        }
        body = json.dumps(payload).encode()
        req = urllib.request.Request(
            url,
            data=body,
            headers={
                "Content-Type": "application/json",
                "Authorization": f"Bearer {self._config.llm_api_key}",
            },
            method="POST",
        )
        try:
            with urllib.request.urlopen(req, timeout=self._timeout) as resp:
                raw = resp.read()
        except urllib.error.HTTPError as exc:
            raise LLMError(
                f"LLM request failed with HTTP {exc.code}: {exc.reason}"
            ) from exc
        except (urllib.error.URLError, OSError) as exc:
            raise LLMError(f"LLM connection error: {exc}") from exc

        try:
            data: dict[str, Any] = json.loads(raw)
            return str(data["choices"][0]["message"]["content"])
        except (KeyError, IndexError, json.JSONDecodeError) as exc:
            raise LLMError(f"Unexpected LLM response format: {exc}") from exc
