"""Custom exceptions for the PACE audit CLI."""
from __future__ import annotations


class LLMError(Exception):
    """Raised when the LLM client encounters an HTTP or network error."""


class PaceError(Exception):
    """Raised for user-facing PACE operational errors (missing deps, bad config, etc.)."""
