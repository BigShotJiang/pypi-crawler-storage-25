"""Browser-based OAuth login flow and credentials management for pace.watch."""
from __future__ import annotations

import os
import secrets
import socket
import stat
import threading
import time
import tomllib
import webbrowser
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path
from typing import Any
from urllib.parse import parse_qs, urlparse

import httpx
import tomli_w
from pydantic import BaseModel

PACE_API_BASE = os.environ.get("PACE_API_URL", "https://api.pace.watch")
PACE_WEB_BASE = os.environ.get("PACE_WEB_URL", "https://pace.watch")
PACE_DIR = Path.home() / ".pace"
CREDENTIALS_PATH = PACE_DIR / "credentials"
TOKEN_CACHE_TTL_SECONDS = 86_400  # 24 hours


class TokenRevokedError(Exception):
    """Raised when the server explicitly rejects a token (HTTP 401 or 403)."""


class Credentials(BaseModel):
    """Validated credentials stored in ~/.pace/credentials."""

    email: str
    api_token: str
    tier: str  # "community" | "pro" | "enterprise"
    licensed_profiles: list[str] = []
    expires_at: str = ""
    last_validated_at: float = 0.0


def _ensure_pace_dir() -> None:
    PACE_DIR.mkdir(parents=True, exist_ok=True)
    PACE_DIR.chmod(0o700)


def write_credentials(creds: Credentials) -> None:
    """Write credentials to ~/.pace/credentials as TOML with mode 600."""
    _ensure_pace_dir()
    data: dict[str, Any] = creds.model_dump()
    CREDENTIALS_PATH.write_text(tomli_w.dumps(data))
    CREDENTIALS_PATH.chmod(stat.S_IRUSR | stat.S_IWUSR)  # 0o600


def read_credentials() -> Credentials | None:
    """Read credentials from ~/.pace/credentials. Returns None if absent or invalid."""
    if not CREDENTIALS_PATH.exists():
        return None
    try:
        with open(CREDENTIALS_PATH, "rb") as f:
            data = tomllib.load(f)
        return Credentials.model_validate(data)
    except Exception:
        return None


def is_authenticated() -> bool:
    """Return True if valid credentials exist on disk."""
    creds = read_credentials()
    return creds is not None and bool(creds.api_token)


def logout() -> None:
    """Delete stored credentials."""
    if CREDENTIALS_PATH.exists():
        CREDENTIALS_PATH.unlink()


def validate_token_remote(api_token: str) -> Credentials | None:
    """Validate *api_token* against the pace.watch API.

    Returns:
        Credentials on success (HTTP 200).
        None on network errors or unexpected non-auth failures — caller may fall
        back to cached credentials.

    Raises:
        TokenRevokedError: on HTTP 401 or 403 — the server explicitly rejected
            the token. Caller must not fall back to cached credentials.
    """
    try:
        with httpx.Client(timeout=10.0) as client:
            resp = client.get(
                f"{PACE_API_BASE}/v1/auth/validate",
                headers={"Authorization": f"Bearer {api_token}"},
            )
        if resp.status_code in (401, 403):
            raise TokenRevokedError(
                f"Token rejected by server (HTTP {resp.status_code}). "
                "Run `pace auth login` to sign in again."
            )
        if resp.status_code != 200:
            return None  # unexpected error — treat as transient network issue
        data = resp.json()
        return Credentials(
            email=data["email"],
            api_token=api_token,
            tier=data["tier"],
            licensed_profiles=data.get("licensed_profiles", []),
            expires_at=data.get("expires_at", ""),
            last_validated_at=time.time(),
        )
    except TokenRevokedError:
        raise
    except (httpx.HTTPError, KeyError, ValueError):
        return None  # network error — caller decides whether to fall back


def get_credentials() -> Credentials | None:
    """Return credentials, re-validating against the API if the local cache is stale (>24h).

    Returns None if:
    - No credentials file exists.
    - The stored token has been explicitly revoked/rejected by the server (logout performed).

    Returns cached credentials without re-validating if the network is unreachable
    and the token is not known to be revoked (offline-friendly behaviour).
    """
    creds = read_credentials()
    if creds is None:
        return None
    age = time.time() - creds.last_validated_at
    if age > TOKEN_CACHE_TTL_SECONDS:
        try:
            refreshed = validate_token_remote(creds.api_token)
        except TokenRevokedError:
            # Token explicitly rejected — remove credentials and force re-login
            logout()
            return None
        if refreshed:
            write_credentials(refreshed)
            return refreshed
        # Network failed (validate_token_remote returned None) — use cached creds
    return creds


def _find_free_port() -> int:
    """Bind to port 0 to get a free ephemeral port from the OS."""
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(("127.0.0.1", 0))
        return int(s.getsockname()[1])


def login() -> Credentials:
    """Run the browser-based OAuth login flow.

    Opens pace.watch/cli-auth in the default browser, starts a local HTTP server
    to receive the callback, and writes the resulting credentials to disk.

    Raises:
        TimeoutError: if the browser callback is not received within 120 seconds.
        ValueError: if the callback contains no API token or an invalid state token.
    """
    state = secrets.token_urlsafe(24)
    port = _find_free_port()
    redirect_uri = f"http://127.0.0.1:{port}/callback"

    result: dict[str, str] = {}
    server_done = threading.Event()

    class _CallbackHandler(BaseHTTPRequestHandler):
        def do_GET(self) -> None:
            parsed = urlparse(self.path)
            if parsed.path != "/callback":
                self.send_response(404)
                self.end_headers()
                return

            params = parse_qs(parsed.query)

            # Validate CSRF state token
            received_state = params.get("state", [""])[0]
            if received_state != state:
                body = (
                    b"<html><body style='font-family:sans-serif;padding:2rem'>"
                    b"<h2>Invalid state token.</h2>"
                    b"<p>The authentication request may have been tampered with. "
                    b"Please run <code>pace auth login</code> again.</p>"
                    b"</body></html>"
                )
                self.send_response(400)
                self.send_header("Content-Type", "text/html")
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)
                return

            result["api_token"] = params.get("api_token", [""])[0]
            result["email"] = params.get("email", [""])[0]
            result["tier"] = params.get("tier", ["community"])[0]
            result["licensed_profiles"] = params.get("licensed_profiles", [""])[0]

            body = (
                b"<html><body style='font-family:sans-serif;padding:2rem'>"
                b"<h2>Authentication successful.</h2>"
                b"<p>You may now close this browser tab and return to your terminal.</p>"
                b"</body></html>"
            )
            self.send_response(200)
            self.send_header("Content-Type", "text/html")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
            server_done.set()

        def log_message(self, format: str, *args: object) -> None:  # noqa: A002
            pass  # suppress request logging to stdout

    server = HTTPServer(("127.0.0.1", port), _CallbackHandler)

    def _serve() -> None:
        # Loop until the callback sets server_done so that spurious browser
        # requests (favicon, prefetch) do not close the server prematurely.
        while not server_done.is_set():
            server.handle_request()
        server.server_close()

    thread = threading.Thread(target=_serve, daemon=True)
    thread.start()

    auth_url = (
        f"{PACE_WEB_BASE}/cli-auth"
        f"?state={state}"
        f"&redirect_uri={redirect_uri}"
    )
    webbrowser.open(auth_url)

    if not server_done.wait(timeout=120):
        raise TimeoutError(
            "Authentication timed out — no browser callback received within 120 seconds."
        )

    api_token = result.get("api_token", "")
    if not api_token:
        raise ValueError("Authentication failed — no API token received from browser callback.")

    licensed = [p for p in result.get("licensed_profiles", "").split(",") if p]
    creds = Credentials(
        email=result.get("email", ""),
        api_token=api_token,
        tier=result.get("tier", "community"),
        licensed_profiles=licensed,
        last_validated_at=time.time(),
    )
    write_credentials(creds)
    return creds
