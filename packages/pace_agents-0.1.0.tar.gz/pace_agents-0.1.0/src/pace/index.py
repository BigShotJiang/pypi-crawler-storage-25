"""Code index reader — queries the codeindex SQLite database."""
from __future__ import annotations

import shutil
import sqlite3
from dataclasses import dataclass
from pathlib import Path
from types import TracebackType

from pace.exceptions import PaceError

CODEINDEX_INSTALL_HINT: str = (
    "brew install 01x-in/tap/codeindex  or visit https://codeindex.cc"
)

# Default DB location produced by codeindex: <repo-root>/.codeindex/graph.db
DEFAULT_DB_PATH: Path = Path(".codeindex") / "graph.db"

_REQUIRED_TABLES: frozenset[str] = frozenset(
    {"nodes", "edges", "file_metadata", "index_metadata"}
)
_REQUIRED_NODE_COLUMNS: frozenset[str] = frozenset(
    {
        "name",
        "kind",
        "file_path",
        "line_start",
        "line_end",
        "col_start",
        "col_end",
        "scope",
        "signature",
        "exported",
        "language",
    }
)


def resolve_db_path(index_path: Path | None = None) -> Path:
    """Return the codeindex database path.

    If *index_path* is provided it is used as-is.
    Otherwise returns the default location: ``.codeindex/graph.db``
    relative to the current working directory.
    """
    if index_path is not None:
        return index_path
    return DEFAULT_DB_PATH


@dataclass(frozen=True, init=False)
class FunctionRecord:
    name: str
    kind: str
    file_path: str
    line_start: int
    line_end: int
    source: str
    col_start: int | None = None
    col_end: int | None = None
    scope: str | None = None
    signature: str | None = None
    exported: bool | None = None
    language: str | None = None

    def __init__(
        self,
        *,
        name: str,
        file_path: str,
        source: str,
        line_start: int | None = None,
        line_end: int | None = None,
        start_line: int | None = None,
        end_line: int | None = None,
        kind: str = "function",
        col_start: int | None = None,
        col_end: int | None = None,
        scope: str | None = None,
        signature: str | None = None,
        exported: bool | None = None,
        language: str | None = None,
    ) -> None:
        resolved_line_start = line_start if line_start is not None else start_line
        resolved_line_end = line_end if line_end is not None else end_line
        if resolved_line_start is None or resolved_line_end is None:
            raise ValueError(
                "FunctionRecord requires line_start/line_end or start_line/end_line"
            )

        object.__setattr__(self, "name", name)
        object.__setattr__(self, "kind", kind)
        object.__setattr__(self, "file_path", file_path)
        object.__setattr__(self, "line_start", int(resolved_line_start))
        object.__setattr__(self, "line_end", int(resolved_line_end))
        object.__setattr__(self, "source", source)
        object.__setattr__(self, "col_start", col_start)
        object.__setattr__(self, "col_end", col_end)
        object.__setattr__(self, "scope", scope)
        object.__setattr__(self, "signature", signature)
        object.__setattr__(self, "exported", exported)
        object.__setattr__(self, "language", language)

    @property
    def start_line(self) -> int:
        return self.line_start

    @property
    def end_line(self) -> int:
        return self.line_end


@dataclass(frozen=True)
class IndexStats:
    function_count: int
    file_count: int


class CodeIndexReader:
    """Read-only reader for the codeindex SQLite database."""

    def __init__(self, db_path: Path) -> None:
        self._db_path = db_path.resolve()
        self._project_root = (
            self._db_path.parent.parent
            if self._db_path.parent.name == ".codeindex"
            else self._db_path.parent
        )
        uri = f"file:{self._db_path}?mode=ro"
        self._conn: sqlite3.Connection = sqlite3.connect(uri, uri=True)
        self._conn.row_factory = sqlite3.Row
        self._validate_schema()

    # ------------------------------------------------------------------
    # Context manager support
    # ------------------------------------------------------------------

    def __enter__(self) -> CodeIndexReader:
        return self

    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: TracebackType | None,
    ) -> None:
        self._conn.close()

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def get_functions(self) -> list[FunctionRecord]:
        """Return all function-type nodes from the index."""
        cur = self._conn.execute(
            "SELECT name, kind, file_path, line_start, line_end, "
            "col_start, col_end, scope, signature, exported, language "
            "FROM nodes WHERE kind = 'function'"
        )
        return [
            FunctionRecord(
                name=row["name"],
                kind=row["kind"],
                file_path=row["file_path"],
                source=self._read_source(
                    row["file_path"],
                    row["line_start"],
                    row["line_end"],
                ),
                line_start=row["line_start"],
                line_end=row["line_end"],
                col_start=row["col_start"],
                col_end=row["col_end"],
                scope=row["scope"],
                signature=row["signature"],
                exported=(
                    None if row["exported"] is None else bool(row["exported"])
                ),
                language=row["language"],
            )
            for row in cur.fetchall()
        ]

    def get_stats(self) -> IndexStats:
        """Return aggregate stats about the index."""
        (function_count,) = self._conn.execute(
            "SELECT COUNT(*) FROM nodes WHERE kind = 'function'"
        ).fetchone()
        (file_count,) = self._conn.execute(
            "SELECT COUNT(*) FROM file_metadata"
        ).fetchone()
        return IndexStats(function_count=int(function_count), file_count=int(file_count))

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _validate_schema(self) -> None:
        """Raise PaceError if any required tables are missing."""
        cur = self._conn.execute(
            "SELECT name FROM sqlite_master WHERE type='table'"
        )
        present = {row[0] for row in cur.fetchall()}
        missing = _REQUIRED_TABLES - present
        if missing:
            missing_list = ", ".join(sorted(missing))
            raise PaceError(
                f"Code index schema is invalid — missing tables: {missing_list}. "
                "Re-run codeindex to rebuild the database."
            )

        cur = self._conn.execute("PRAGMA table_info(nodes)")
        node_columns = {row[1] for row in cur.fetchall()}
        missing_node_columns = _REQUIRED_NODE_COLUMNS - node_columns
        if missing_node_columns:
            missing_list = ", ".join(sorted(missing_node_columns))
            raise PaceError(
                f"Code index schema is invalid — missing nodes columns: {missing_list}. "
                "Re-run codeindex to rebuild the database."
            )

    def _resolve_source_path(self, file_path: str) -> Path:
        """Resolve *file_path* against the project root or current working directory."""
        path = Path(file_path)
        if path.is_absolute():
            return path

        project_path = self._project_root / path
        if project_path.exists():
            return project_path

        cwd_path = Path.cwd() / path
        if cwd_path.exists():
            return cwd_path

        return project_path

    def _read_source(self, file_path: str, line_start: int, line_end: int) -> str:
        """Read the source snippet for a function from the file on disk."""
        if line_start is None or line_end is None:
            raise PaceError(
                f"Code index row for '{file_path}' is missing line range information."
            )

        source_path = self._resolve_source_path(file_path)
        try:
            text = source_path.read_text(encoding="utf-8", errors="replace")
        except OSError as exc:
            raise PaceError(
                f"Could not read source for '{file_path}' from '{source_path}': {exc}"
            ) from exc

        lines = text.splitlines(keepends=True)
        start_index = max(int(line_start) - 1, 0)
        end_index = max(int(line_end), start_index)
        return "".join(lines[start_index:end_index])


def check_codeindex_deps(db_path: Path) -> None:
    """Check that the codeindex binary and DB file are available.

    Raises PaceError with actionable instructions on any failure.
    """
    if shutil.which("codeindex") is None:
        raise PaceError(
            f"Error: codeindex not found. Install with: {CODEINDEX_INSTALL_HINT}"
        )

    if not db_path.exists():
        raise PaceError(
            f"Error: code index database not found at '{db_path}'. "
            "Run codeindex in your project root first."
        )

    if db_path.stat().st_size == 0:
        raise PaceError(
            "Error: code index is empty — re-run codeindex to rebuild"
        )
