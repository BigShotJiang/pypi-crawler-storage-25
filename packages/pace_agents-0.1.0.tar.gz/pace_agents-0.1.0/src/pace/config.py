"""PaceConfig — Pydantic v2 model for pace.toml validation."""
from __future__ import annotations

import tomllib
from pathlib import Path
from typing import Literal

from pydantic import BaseModel

ProfileChoice = Literal["hipaa", "soc2", "pci-dss", "all"]

# "project" → .pace/rulesets/<profile>/ (committed to repo, team-shared)
# "global"  → ~/.pace/rulesets/<profile>/ (machine-wide, user-personal)
RulesetScope = Literal["project", "global"]


class PaceConfig(BaseModel):
    """Validated configuration loaded from pace.toml."""

    profile: ProfileChoice
    llm_endpoint: str
    llm_model: str
    llm_api_key: str
    test_command: str
    ruleset_scope: RulesetScope = "project"
    """Where to look for installed ruleset packs.

    - "project" (default): .pace/rulesets/<profile>/ — committed to repo, shared with team.
    - "global": ~/.pace/rulesets/<profile>/ — machine-wide, personal install.

    Project-local always takes precedence over global when both are present.
    Falls back to the legacy rules/<profile>/ directory if neither is found.
    """

    @classmethod
    def from_toml(cls, path: Path = Path("pace.toml")) -> PaceConfig:
        """Load and validate pace.toml from *path*."""
        with open(path, "rb") as f:
            data = tomllib.load(f)
        return cls.model_validate(data)
