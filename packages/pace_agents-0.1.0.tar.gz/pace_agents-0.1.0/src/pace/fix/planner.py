"""Planner agent — STORY-203.

Reads audit state, sorts open findings by severity, groups related findings
by file/module, and produces an ordered FixQueue.
"""
from __future__ import annotations

from collections.abc import Iterator
from dataclasses import dataclass, field

from pace.audit_state import AuditState, get_open_findings
from pace.rules import Finding, Severity

# Severity ordering: lower number → higher priority
_SEVERITY_RANK: dict[str, int] = {
    Severity.CRITICAL: 0,
    Severity.HIGH: 1,
    Severity.MEDIUM: 2,
    Severity.LOW: 3,
}


@dataclass
class FixQueueItem:
    """A single finding scheduled for the fix loop."""

    finding: Finding


@dataclass
class FixQueue:
    """Ordered list of findings to fix."""

    items: list[FixQueueItem] = field(default_factory=list)

    def __len__(self) -> int:
        return len(self.items)

    def __iter__(self) -> Iterator[FixQueueItem]:
        return iter(self.items)


class PlannerAgent:
    """Reads audit state, returns an ordered FixQueue for `pace fix`."""

    def plan(self, state: AuditState) -> FixQueue:
        """Return an ordered FixQueue from open findings in *state*.

        Ordering strategy:
        1. Sort by severity descending (CRITICAL → LOW).
        2. Within the same severity level, group by file path so related
           findings appear consecutively.
        """
        open_findings = get_open_findings(state)
        if not open_findings:
            return FixQueue()

        # Sort: primary key = severity rank, secondary key = file_path
        sorted_findings = sorted(
            open_findings,
            key=lambda f: (_SEVERITY_RANK.get(f.severity, 99), f.file_path),
        )

        return FixQueue(items=[FixQueueItem(finding=f) for f in sorted_findings])
