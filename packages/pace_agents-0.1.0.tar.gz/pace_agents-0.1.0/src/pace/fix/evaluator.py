"""Evaluator agent and retry loop — STORY-206.

Re-runs Pass 1 on the patched file, verifies the original finding is gone
and no new findings were introduced. On failure, cycles back to Author with
failure context. Caps at 3 retries then marks the finding as `blocked`.
On success, marks finding as `fixed` in audit state.
"""
from __future__ import annotations

import logging
from dataclasses import dataclass, field
from pathlib import Path

from pace.audit_state import AuditState, FindingStatus
from pace.fix.author import AuthorAgent
from pace.fix.coder import CoderAgent, CoderResult
from pace.rules import Finding, Rule, RuleMatcher

logger = logging.getLogger(__name__)


@dataclass
class EvaluatorResult:
    """Result of evaluating a single patch attempt."""

    finding_id: str
    finding_resolved: bool  # True if original finding ID gone from re-scan
    new_violations: list[Finding] = field(default_factory=list)


@dataclass
class FixLoopResult:
    """Result of the full fix loop for one finding."""

    finding_id: str
    final_status: FindingStatus
    attempts: int
    last_coder_result: CoderResult | None = None
    last_evaluator_result: EvaluatorResult | None = None
    patch: str = ""  # the Author's patch that was accepted (empty if not fixed)


class EvaluatorAgent:
    """Re-runs Pass 1 on the patched function source to validate a fix."""

    def __init__(self, matcher: RuleMatcher) -> None:
        self._matcher = matcher

    def evaluate(
        self,
        finding: Finding,
        rule: Rule,
        patched_source: str,
        coder_result: CoderResult,
    ) -> EvaluatorResult:
        """Scan *patched_source* and assess whether the fix is valid.

        - ``finding_resolved``: True if the original finding ID is absent from
          the re-scan results.
        - ``new_violations``: findings in the re-scan whose IDs differ from the
          original finding ID (new violations introduced by the patch).
        """
        new_findings = self._matcher.match(
            patched_source, finding.function_name, finding.file_path
        )
        original_still_present = any(f.finding_id == finding.finding_id for f in new_findings)
        new_violations = [f for f in new_findings if f.finding_id != finding.finding_id]

        return EvaluatorResult(
            finding_id=finding.finding_id,
            finding_resolved=not original_still_present,
            new_violations=new_violations,
        )


class FixLoop:
    """Orchestrates the Planner → Author → Coder → Evaluator cycle per finding."""

    def __init__(
        self,
        author: AuthorAgent,
        coder: CoderAgent,
        evaluator: EvaluatorAgent,
        rules: list[Rule],
        journal_context: str,
        max_retries: int = 3,
        project_root: Path | None = None,
    ) -> None:
        self._author = author
        self._coder = coder
        self._evaluator = evaluator
        self._rules_by_id: dict[str, Rule] = {r.id: r for r in rules}
        self._journal_context = journal_context
        self._max_retries = max_retries
        self._project_root = project_root or Path.cwd()

    def fix_finding(self, finding: Finding, state: AuditState) -> FixLoopResult:
        """Run the fix loop for a single finding.

        Returns a FixLoopResult with final_status = FIXED or BLOCKED.
        The caller is responsible for persisting the updated status to audit state.
        """
        rule = self._rules_by_id.get(finding.rule_id)
        if rule is None:
            logger.warning("No rule found for rule_id=%s; skipping fix", finding.rule_id)
            return FixLoopResult(
                finding_id=finding.finding_id,
                final_status=FindingStatus.BLOCKED,
                attempts=0,
            )

        prior_failure: str | None = None
        last_coder: CoderResult | None = None
        last_eval: EvaluatorResult | None = None

        for attempt in range(1, self._max_retries + 1):
            logger.info(
                "fix_finding attempt %d/%d for finding %s",
                attempt,
                self._max_retries,
                finding.finding_id,
            )

            # --- Author: propose patch ---
            # Read current function source from disk (pre-patch on this attempt)
            function_source = self._read_file_source(finding.file_path)
            author_result = self._author.propose_fix(
                finding,
                rule,
                function_source,
                self._journal_context,
                prior_failure=prior_failure,
            )

            if author_result.patch is None:
                prior_failure = "Author could not produce a patch."
                logger.warning("Author returned no patch (attempt %d)", attempt)
                continue

            # --- Coder: apply patch and run tests ---
            coder_result = self._coder.apply_patch(finding.finding_id, author_result.patch)
            last_coder = coder_result

            if not coder_result.patch_applied:
                prior_failure = f"git apply failed: {coder_result.test_output}"
                logger.warning("Patch did not apply (attempt %d)", attempt)
                continue

            if not coder_result.tests_passed:
                prior_failure = f"Tests failed after applying patch:\n{coder_result.test_output}"
                logger.warning("Tests failed after patch (attempt %d)", attempt)
                # Evaluator still needs to run to check if violation is resolved
                eval_result = EvaluatorResult(
                    finding_id=finding.finding_id,
                    finding_resolved=False,
                    new_violations=[],
                )
                last_eval = eval_result
                continue

            # --- Evaluator: re-run Pass 1 on the patched file ---
            # Read the file from disk; Coder stays on the fix branch after
            # a successful apply+commit, so the file reflects the patch.
            patched_source = self._read_file_source(finding.file_path)
            eval_result = self._evaluator.evaluate(
                finding=finding,
                rule=rule,
                patched_source=patched_source,
                coder_result=coder_result,
            )
            last_eval = eval_result

            if not eval_result.finding_resolved:
                prior_failure = "Original finding still present after patch."
                logger.warning("Finding not resolved (attempt %d)", attempt)
                continue

            if eval_result.new_violations:
                vids = ", ".join(v.finding_id for v in eval_result.new_violations)
                prior_failure = f"Patch introduced new violations: {vids}"
                logger.warning("New violations introduced (attempt %d): %s", attempt, vids)
                continue

            # Success
            return FixLoopResult(
                finding_id=finding.finding_id,
                final_status=FindingStatus.FIXED,
                attempts=attempt,
                last_coder_result=coder_result,
                last_evaluator_result=eval_result,
                patch=author_result.patch or "",
            )

        # Exhausted retries
        return FixLoopResult(
            finding_id=finding.finding_id,
            final_status=FindingStatus.BLOCKED,
            attempts=self._max_retries,
            last_coder_result=last_coder,
            last_evaluator_result=last_eval,
        )

    def _read_file_source(self, relative_path: str) -> str:
        """Read file content from *relative_path* under project root.

        Returns empty string if the file does not exist (e.g. deleted by patch).
        """
        full_path = self._project_root / relative_path
        try:
            return full_path.read_text(encoding="utf-8", errors="replace")
        except FileNotFoundError:
            logger.warning("File not found for source read: %s", full_path)
            return ""
