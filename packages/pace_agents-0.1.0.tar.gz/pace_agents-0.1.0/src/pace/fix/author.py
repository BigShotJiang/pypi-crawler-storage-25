"""Author agent — STORY-204.

Takes one finding from the fix queue, reads rule-specific fix strategy hints
from the YAML rule, reads journal context, and proposes a unified diff patch.
"""
from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Any

from pace.rules import Finding, Rule

_DIFF_FENCE_RE = re.compile(r"```diff\s*(.*?)\s*```", re.DOTALL)


@dataclass
class AuthorResult:
    """Result of an Author agent patch proposal."""

    finding_id: str
    patch: str | None  # Unified diff string, or None if LLM could not produce one
    raw_response: str


class AuthorAgent:
    """Proposes a unified diff patch for a single finding."""

    def __init__(self, llm: Any) -> None:  # duck-typed for testability
        self._llm = llm

    def propose_fix(
        self,
        finding: Finding,
        rule: Rule,
        function_source: str,
        journal_context: str,
        *,
        prior_failure: str | None = None,
    ) -> AuthorResult:
        """Ask the LLM to produce a unified diff patch for *finding*.

        Args:
            finding: The finding to fix.
            rule: The rule that produced the finding (provides fix_strategy_hint).
            function_source: Current source of the affected function.
            journal_context: Compressed audit journal for context.
            prior_failure: Optional failure message from a previous attempt.
        """
        messages = self._build_prompt(
            finding, rule, function_source, journal_context, prior_failure
        )
        response = self._llm.chat(messages)
        patch = self._extract_patch(response)
        return AuthorResult(finding_id=finding.finding_id, patch=patch, raw_response=response)

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _build_prompt(
        self,
        finding: Finding,
        rule: Rule,
        function_source: str,
        journal_context: str,
        prior_failure: str | None,
    ) -> list[dict[str, Any]]:
        prior_context = journal_context or "(No prior audit context.)"
        failure_section = (
            f"\n## Previous Attempt Failed\n{prior_failure}\n" if prior_failure else ""
        )
        user_content = (
            "You are a HIPAA compliance engineer. Your task is to produce a minimal "
            "unified diff patch that fixes the compliance violation described below.\n\n"
            "## Audit Context\n"
            + prior_context
            + "\n\n"
            "## Finding\n"
            f"- File: {finding.file_path}\n"
            f"- Function: {finding.function_name}\n"
            f"- Rule: {finding.rule_id}\n"
            f"- Description: {finding.description}\n\n"
            "## Fix Strategy\n"
            + rule.fix_strategy_hint
            + failure_section
            + "\n\n## Current Function Source\n"
            "```python\n"
            + function_source
            + "\n```\n\n"
            "## Instructions\n"
            "Produce a unified diff patch that fixes the violation. The patch must:\n"
            "- Be in standard unified diff format (--- a/... +++ b/...)\n"
            "- Be minimal — only change what is necessary to fix the violation\n"
            "- Not introduce new violations\n\n"
            "Return the patch inside a fenced code block marked ```diff. "
            "If you cannot produce a patch, explain why (no code block)."
        )
        return [
            {
                "role": "system",
                "content": "You are a HIPAA compliance engineer producing code patches.",
            },
            {"role": "user", "content": user_content},
        ]

    @staticmethod
    def _extract_patch(response: str) -> str | None:
        match = _DIFF_FENCE_RE.search(response)
        if not match:
            return None
        return match.group(1).strip()
