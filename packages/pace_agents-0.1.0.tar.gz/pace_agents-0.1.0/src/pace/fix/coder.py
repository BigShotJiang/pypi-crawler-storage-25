"""Coder agent — STORY-205.

Applies the Author's patch to a `pace/fix-<timestamp>` git branch using
`git apply`, runs the project's test command, and reports pass/fail.
"""
from __future__ import annotations

import subprocess
import tempfile
from dataclasses import dataclass
from datetime import UTC, datetime
from pathlib import Path

from pace.exceptions import PaceError


@dataclass
class CoderResult:
    """Result of the Coder agent's apply-and-test cycle."""

    finding_id: str
    branch_name: str
    original_branch: str
    patch_applied: bool
    tests_passed: bool
    test_output: str
    commit_sha: str  # empty string if patch was not applied


class CoderAgent:
    """Applies a patch to an isolated git branch and runs tests."""

    def __init__(self, project_root: Path, test_command: str) -> None:
        self._root = project_root
        self._test_command = test_command

    def apply_patch(self, finding_id: str, patch: str) -> CoderResult:
        """Apply *patch* to a new branch and run the test suite.

        Steps:
        1. Read current branch name.
        2. Create a new `pace/fix-<timestamp>` branch.
        3. Write patch to a temp file and run `git apply`.
        4. If apply fails: switch back to original branch, return failure.
        5. Commit the change.
        6. Run the test command.
        7. Return result (always switch back to original branch on failure).
        """
        ts = datetime.now(tz=UTC).strftime("%Y%m%dT%H%M%S")
        branch_name = f"pace/fix-{ts}"
        try:
            original_branch = self._current_branch()
        except subprocess.CalledProcessError as exc:
            raise PaceError(
                "Error: not a git repository. Run `git init` first."
            ) from exc

        # Create fix branch
        checkout_result = self._git(["checkout", "-b", branch_name])
        if checkout_result.returncode != 0:
            return CoderResult(
                finding_id=finding_id,
                branch_name=branch_name,
                original_branch=original_branch,
                patch_applied=False,
                tests_passed=False,
                test_output=checkout_result.stderr.decode(errors="replace"),
                commit_sha="",
            )

        # Apply patch via temp file
        with tempfile.NamedTemporaryFile(
            mode="w", suffix=".patch", delete=False, dir=self._root
        ) as tmp:
            tmp.write(patch)
            tmp_path = tmp.name

        try:
            apply_result = subprocess.run(
                ["git", "apply", tmp_path],
                capture_output=True,
                cwd=self._root,
            )
        finally:
            Path(tmp_path).unlink(missing_ok=True)

        if apply_result.returncode != 0:
            # Switch back to original branch before returning
            self._git(["checkout", original_branch])
            return CoderResult(
                finding_id=finding_id,
                branch_name=branch_name,
                original_branch=original_branch,
                patch_applied=False,
                tests_passed=False,
                test_output=apply_result.stderr.decode(errors="replace"),
                commit_sha="",
            )

        # Commit the fix
        self._git(["add", "-A"])
        commit_result = self._git(["commit", "-m", f"fix: auto-patch for finding {finding_id}"])
        if commit_result.returncode != 0:
            self._git(["checkout", original_branch])
            return CoderResult(
                finding_id=finding_id,
                branch_name=branch_name,
                original_branch=original_branch,
                patch_applied=True,
                tests_passed=False,
                test_output=commit_result.stderr.decode(errors="replace"),
                commit_sha="",
            )
        commit_sha = self._get_head_sha()

        # Run tests
        test_result = subprocess.run(
            self._test_command,
            shell=True,
            capture_output=True,
            cwd=self._root,
        )
        test_output = (
            test_result.stdout.decode(errors="replace")
            + test_result.stderr.decode(errors="replace")
        )
        # Keep last 50 lines of output
        test_output_snippet = "\n".join(test_output.splitlines()[-50:])

        tests_passed = test_result.returncode == 0

        if not tests_passed:
            # Switch back to original branch on test failure
            self._git(["checkout", original_branch])

        return CoderResult(
            finding_id=finding_id,
            branch_name=branch_name,
            original_branch=original_branch,
            patch_applied=True,
            tests_passed=tests_passed,
            test_output=test_output_snippet,
            commit_sha=commit_sha,
        )

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _current_branch(self) -> str:
        result = subprocess.check_output(
            ["git", "rev-parse", "--abbrev-ref", "HEAD"],
            cwd=self._root,
        )
        return result.decode().strip()

    def _get_head_sha(self) -> str:
        result = subprocess.check_output(
            ["git", "rev-parse", "HEAD"],
            cwd=self._root,
        )
        return result.decode().strip()

    def _git(self, args: list[str]) -> subprocess.CompletedProcess:  # type: ignore[type-arg]
        return subprocess.run(
            ["git"] + args,
            capture_output=True,
            cwd=self._root,
        )
