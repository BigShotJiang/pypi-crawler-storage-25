"""Evidence report generation — STORY-302 and STORY-303.

Reads audit-state.json and audit-journal.json, renders a timestamped
markdown, JSON, and HTML evidence artifact ready for auditor review.
"""
from __future__ import annotations

import html as _html
from typing import Any

from pydantic import BaseModel

# ---------------------------------------------------------------------------
# Data models
# ---------------------------------------------------------------------------


class FindingReport(BaseModel):
    """Evidence data for a single finding."""

    finding_id: str
    rule_id: str
    control_ref: str
    severity: str
    file_path: str
    function_name: str
    description: str
    status: str  # open | fixed | accepted-risk | false-positive | blocked
    diff: str  # unified diff or empty string if not available
    test_result: str  # passed | failed | n/a
    evaluator_verdict: str = ""  # Evaluator output when available


class EvidenceReport(BaseModel):
    """Top-level evidence artifact."""

    scan_timestamp: str  # ISO 8601
    profile: str
    findings: list[FindingReport]

    def summary_table(self) -> dict[str, int]:
        """Return counts of findings grouped by status."""
        counts: dict[str, int] = {}
        for f in self.findings:
            counts[f.status] = counts.get(f.status, 0) + 1
        return counts


# ---------------------------------------------------------------------------
# Markdown rendering
# ---------------------------------------------------------------------------

_SEVERITY_EMOJI: dict[str, str] = {
    "critical": "🔴",
    "high": "🟠",
    "medium": "🟡",
    "low": "🔵",
}


def render_markdown(report: EvidenceReport) -> str:
    """Render *report* as a Markdown evidence document."""
    lines: list[str] = []

    # Header
    lines.append("# PACE Evidence Report")
    lines.append("")
    lines.append(f"**Scan timestamp:** {report.scan_timestamp}")
    lines.append(f"**Profile:** {report.profile}")
    lines.append(f"**Total findings:** {len(report.findings)}")
    lines.append("")

    # Summary table
    lines.append("## Summary")
    lines.append("")
    lines.append("| Status | Count |")
    lines.append("|--------|-------|")
    for status, count in sorted(report.summary_table().items()):
        lines.append(f"| {status} | {count} |")
    lines.append("")

    # Per-finding sections
    lines.append("## Findings")
    lines.append("")

    for i, fr in enumerate(report.findings, start=1):
        sev_icon = _SEVERITY_EMOJI.get(fr.severity, "")
        lines.append(f"### Finding {i}: {fr.rule_id} — {sev_icon} {fr.severity.upper()}")
        lines.append("")
        lines.append(f"- **Finding ID:** `{fr.finding_id}`")
        lines.append(f"- **HIPAA Control:** {fr.control_ref}")
        lines.append(f"- **File:** `{fr.file_path}`")
        lines.append(f"- **Function:** `{fr.function_name}`")
        lines.append(f"- **Severity:** {fr.severity}")
        lines.append(f"- **Status:** {fr.status}")
        lines.append(f"- **Test result:** {fr.test_result}")
        lines.append("")
        lines.append(f"**Description:** {fr.description}")
        lines.append("")

        if fr.diff:
            lines.append("**Before / After diff:**")
            lines.append("")
            lines.append("```diff")
            lines.append(fr.diff.rstrip())
            lines.append("```")
            lines.append("")

        if fr.evaluator_verdict:
            lines.append(f"**Evaluator verdict:** {fr.evaluator_verdict}")
            lines.append("")

        lines.append("---")
        lines.append("")

    return "\n".join(lines)


# ---------------------------------------------------------------------------
# JSON rendering
# ---------------------------------------------------------------------------


def render_json_report(report: EvidenceReport) -> dict[str, Any]:
    """Render *report* as a machine-readable dict (for JSON serialisation)."""
    return {
        "scan_timestamp": report.scan_timestamp,
        "profile": report.profile,
        "summary": report.summary_table(),
        "findings": [
            {
                "finding_id": fr.finding_id,
                "rule_id": fr.rule_id,
                "control_ref": fr.control_ref,
                "severity": fr.severity,
                "file_path": fr.file_path,
                "function_name": fr.function_name,
                "description": fr.description,
                "status": fr.status,
                "diff": fr.diff,
                "test_result": fr.test_result,
                "evaluator_verdict": fr.evaluator_verdict,
            }
            for fr in report.findings
        ],
    }


# ---------------------------------------------------------------------------
# HTML rendering
# ---------------------------------------------------------------------------

_SEVERITY_COLOR: dict[str, str] = {
    "critical": "#c0392b",
    "high":     "#e67e22",
    "medium":   "#f39c12",
    "low":      "#2980b9",
}

_STATUS_COLOR: dict[str, str] = {
    "fixed":           "#27ae60",
    "open":            "#e67e22",
    "blocked":         "#c0392b",
    "accepted-risk":   "#7f8c8d",
    "false-positive":  "#7f8c8d",
}

_CSS = """
* { box-sizing: border-box; margin: 0; padding: 0; }
body {
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, monospace;
    font-size: 14px;
    background: #f5f6fa;
    color: #2c3e50;
    padding: 32px 16px;
}
.container { max-width: 960px; margin: 0 auto; }
h1 { font-size: 22px; font-weight: 700; margin-bottom: 4px; }
.meta { color: #7f8c8d; font-size: 13px; margin-bottom: 24px; }
.meta span { margin-right: 20px; }

/* Summary */
.summary { background: #fff; border-radius: 6px; padding: 20px 24px;
           margin-bottom: 28px; border: 1px solid #dfe6e9; }
.summary h2 { font-size: 15px; font-weight: 600; margin-bottom: 14px; }
.summary table { border-collapse: collapse; width: auto; }
.summary td { padding: 4px 24px 4px 0; font-size: 13px; }
.summary td:last-child { font-weight: 600; }

/* Finding cards */
.finding { background: #fff; border-radius: 6px; border: 1px solid #dfe6e9;
           margin-bottom: 16px; overflow: hidden; }
.finding-header { display: flex; align-items: center; gap: 10px;
                  padding: 14px 20px; border-bottom: 1px solid #f0f0f0; }
.finding-header h3 { font-size: 14px; font-weight: 600; flex: 1; }
.badge { display: inline-block; padding: 2px 9px; border-radius: 3px;
         font-size: 11px; font-weight: 700; color: #fff; white-space: nowrap; }
.finding-body { padding: 16px 20px; }
.meta-grid { display: grid; grid-template-columns: 140px 1fr; gap: 5px 0;
             font-size: 13px; margin-bottom: 14px; }
.meta-grid .label { color: #7f8c8d; }
.meta-grid .value { font-family: monospace; font-size: 12px; }
.description { font-size: 13px; margin-bottom: 14px; line-height: 1.5; }

/* Diff */
.diff-block { margin-bottom: 14px; }
.diff-block p { font-size: 12px; font-weight: 600; color: #7f8c8d;
                margin-bottom: 6px; text-transform: uppercase; letter-spacing: .04em; }
.diff-block pre { background: #1e1e2e; color: #cdd6f4; border-radius: 4px;
                  padding: 14px; font-size: 12px; line-height: 1.6;
                  overflow-x: auto; white-space: pre; }
.diff-block pre .add { color: #a6e3a1; }
.diff-block pre .rem { color: #f38ba8; }
.diff-block pre .meta { color: #89b4fa; }

/* Verdict */
.verdict { font-size: 13px; color: #555; background: #f8f9fa;
           border-left: 3px solid #27ae60; padding: 8px 12px;
           border-radius: 0 4px 4px 0; }
"""


def _diff_to_html(diff: str) -> str:
    """Convert a unified diff string to HTML with per-line colour spans."""
    lines: list[str] = []
    for line in diff.splitlines():
        escaped = _html.escape(line)
        if line.startswith("+"):
            lines.append(f'<span class="add">{escaped}</span>')
        elif line.startswith("-"):
            lines.append(f'<span class="rem">{escaped}</span>')
        elif line.startswith("@@"):
            lines.append(f'<span class="meta">{escaped}</span>')
        else:
            lines.append(escaped)
    return "\n".join(lines)


def render_html(report: EvidenceReport) -> str:
    """Render *report* as a self-contained HTML evidence document."""
    e = _html.escape
    parts: list[str] = []

    parts.append(
        f'<!DOCTYPE html><html lang="en"><head>'
        f'<meta charset="UTF-8">'
        f'<meta name="viewport" content="width=device-width,initial-scale=1">'
        f'<title>PACE Evidence Report — {e(report.profile.upper())}</title>'
        f'<style>{_CSS}</style>'
        f'</head><body><div class="container">'
    )

    # Header
    total = len(report.findings)
    parts.append(
        f'<h1>PACE Evidence Report</h1>'
        f'<div class="meta">'
        f'<span>Profile: <strong>{e(report.profile.upper())}</strong></span>'
        f'<span>Scanned: <strong>{e(report.scan_timestamp)}</strong></span>'
        f'<span>Findings: <strong>{total}</strong></span>'
        f'</div>'
    )

    # Summary table
    parts.append('<div class="summary"><h2>Summary</h2><table>')
    for status, count in sorted(report.summary_table().items()):
        color = _STATUS_COLOR.get(status, "#7f8c8d")
        parts.append(
            f'<tr><td><span class="badge" style="background:{color}">'
            f'{e(status)}</span></td><td>{count}</td></tr>'
        )
    parts.append('</table></div>')

    # Findings
    parts.append('<div class="findings">')
    for i, fr in enumerate(report.findings, start=1):
        sev_color = _SEVERITY_COLOR.get(fr.severity, "#7f8c8d")
        sta_color = _STATUS_COLOR.get(fr.status, "#7f8c8d")

        parts.append(
            f'<div class="finding">'
            f'<div class="finding-header">'
            f'<h3>#{i} &nbsp;{e(fr.rule_id)}</h3>'
            f'<span class="badge" style="background:{sev_color}">{e(fr.severity.upper())}</span>'
            f'<span class="badge" style="background:{sta_color}">{e(fr.status)}</span>'
            f'</div>'
            f'<div class="finding-body">'
        )

        # Metadata grid
        parts.append(
            f'<div class="meta-grid">'
            f'<span class="label">Finding ID</span>'
            f'<span class="value">{e(fr.finding_id)}</span>'
            f'<span class="label">Control</span>'
            f'<span class="value">{e(fr.control_ref)}</span>'
            f'<span class="label">File</span>'
            f'<span class="value">{e(fr.file_path)}</span>'
            f'<span class="label">Function</span>'
            f'<span class="value">{e(fr.function_name)}</span>'
            f'<span class="label">Test result</span>'
            f'<span class="value">{e(fr.test_result)}</span>'
            f'</div>'
        )

        parts.append(f'<p class="description">{e(fr.description)}</p>')

        if fr.diff:
            parts.append(
                f'<div class="diff-block">'
                f'<p>Before / After diff</p>'
                f'<pre>{_diff_to_html(fr.diff.rstrip())}</pre>'
                f'</div>'
            )

        if fr.evaluator_verdict:
            parts.append(
                f'<div class="verdict">Evaluator: {e(fr.evaluator_verdict)}</div>'
            )

        parts.append('</div></div>')  # finding-body, finding

    parts.append('</div></div></body></html>')
    return "".join(parts)
