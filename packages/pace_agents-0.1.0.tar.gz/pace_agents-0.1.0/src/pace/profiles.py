"""Custom user-defined compliance profiles stored in ~/.pace/profiles/."""
from __future__ import annotations

import tomllib
from pathlib import Path
from typing import Any

import tomli_w
from pydantic import BaseModel

from pace.auth import PACE_DIR

PROFILES_DIR = PACE_DIR / "profiles"


class ProfileConfig(BaseModel):
    """A user-defined compliance profile linking a name to one or more rulesets."""

    name: str
    display_name: str = ""
    rulesets: list[str]  # e.g. ["hipaa:pro", "soc2:community", "custom/internal"]

    @property
    def label(self) -> str:
        return self.display_name or self.name


def _ensure_profiles_dir() -> None:
    PROFILES_DIR.mkdir(parents=True, exist_ok=True)


def save_profile(profile: ProfileConfig) -> Path:
    """Write *profile* to ``~/.pace/profiles/<name>.toml``.

    Returns the path written.
    """
    _ensure_profiles_dir()
    path = PROFILES_DIR / f"{profile.name}.toml"
    data: dict[str, Any] = profile.model_dump()
    path.write_text(tomli_w.dumps(data))
    return path


def load_profile(name: str) -> ProfileConfig | None:
    """Load profile *name* from ``~/.pace/profiles/<name>.toml``.

    Returns None if the profile does not exist or cannot be parsed.
    """
    path = PROFILES_DIR / f"{name}.toml"
    if not path.exists():
        return None
    try:
        with open(path, "rb") as f:
            data = tomllib.load(f)
        return ProfileConfig.model_validate(data)
    except Exception:
        return None


def list_profiles() -> list[ProfileConfig]:
    """Return all valid profiles found in ``~/.pace/profiles/``."""
    if not PROFILES_DIR.exists():
        return []
    profiles: list[ProfileConfig] = []
    for path in sorted(PROFILES_DIR.glob("*.toml")):
        try:
            with open(path, "rb") as f:
                data = tomllib.load(f)
            profiles.append(ProfileConfig.model_validate(data))
        except Exception:
            continue
    return profiles


def delete_profile(name: str) -> bool:
    """Delete profile *name*. Returns True if deleted, False if it did not exist."""
    path = PROFILES_DIR / f"{name}.toml"
    if path.exists():
        path.unlink()
        return True
    return False
