"""Documented exit codes for the PACE CLI — STORY-501."""
from __future__ import annotations

# ---------------------------------------------------------------------------
# STORY-501 exit code scheme (UNIX-aligned)
# ---------------------------------------------------------------------------

EXIT_OK: int = 0
"""Normal exit — no errors."""

EXIT_RUNTIME_ERROR: int = 1
"""Unrecoverable runtime error (misconfiguration, missing dependency, I/O failure)."""

EXIT_USAGE_ERROR: int = 2
"""Usage error (invalid flags, unknown profile) — mirrors UNIX convention."""

EXIT_NEW_VIOLATIONS: int = 3
"""pace scan --diff specific — new violations detected (CI block signal).
Intentionally distinct from EXIT_RUNTIME_ERROR so CI pipelines can distinguish
'PACE itself failed' from 'PACE ran fine but found violations'.
"""

EXIT_INTERRUPTED: int = 130
"""Keyboard interrupt (Ctrl+C) — SIGINT convention."""

# ---------------------------------------------------------------------------
# Symbol-preserved names from the pre-STORY-501 scheme.
#
# WARNING — INTEGER VALUES CHANGED (breaking change for raw-integer consumers):
#   EXIT_CONFIG_ERROR: was 1, now 1  (unchanged)
#   EXIT_INDEX_ERROR:  was 2, now 1  ← CHANGED
#   EXIT_LLM_ERROR:    was 3, now 1  ← CHANGED
#   EXIT_GIT_ERROR:    was 4, now 1  ← CHANGED
#   EXIT_RULE_ERROR:   was 5, now 1  ← CHANGED
#
# Python code that imports these symbols and compares against the symbol name
# (e.g. `result.exit_code == EXIT_INDEX_ERROR`) will continue to work.
# Shell scripts, CI pipelines, or tests that check the raw integer (e.g.
# `exit $? -eq 2`) must be updated to use the new UNIX-aligned scheme above.
# ---------------------------------------------------------------------------

EXIT_CONFIG_ERROR: int = EXIT_RUNTIME_ERROR
"""Configuration error — symbol alias for EXIT_RUNTIME_ERROR (= 1)."""

EXIT_INDEX_ERROR: int = EXIT_RUNTIME_ERROR
"""Code index error — symbol alias for EXIT_RUNTIME_ERROR (= 1). Was 2 pre-STORY-501."""

EXIT_LLM_ERROR: int = EXIT_RUNTIME_ERROR
"""LLM communication error — symbol alias for EXIT_RUNTIME_ERROR (= 1). Was 3 pre-STORY-501."""

EXIT_GIT_ERROR: int = EXIT_RUNTIME_ERROR
"""Git error — symbol alias for EXIT_RUNTIME_ERROR (= 1). Was 4 pre-STORY-501."""

EXIT_RULE_ERROR: int = EXIT_RUNTIME_ERROR
"""Rule definition error — symbol alias for EXIT_RUNTIME_ERROR (= 1). Was 5 pre-STORY-501."""
