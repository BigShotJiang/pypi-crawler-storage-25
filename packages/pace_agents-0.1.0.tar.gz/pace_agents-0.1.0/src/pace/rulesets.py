"""Ruleset resolution, download, and caching for pace.watch rule packs."""
from __future__ import annotations

import hashlib
import re
import tarfile
import time
from pathlib import Path
from typing import Literal

import httpx

from pace.auth import PACE_API_BASE, PACE_DIR, get_credentials

# TODO(security): implement ECDSA P-256 signature verification before production.
# Until the pace.watch signing infrastructure is set up, pack integrity relies
# solely on the SHA-256 checksum supplied by the API.  A compromised server can
# supply a malicious pack with a matching checksum.  Track:
# https://github.com/01x-in/pace-agents/issues — add ECDSA sig verify issue.

RulesetScope = Literal["project", "global"]

_GLOBAL_RULESETS_DIR = PACE_DIR / "rulesets"

# Tiers in descending priority order — highest-quality rules win when multiple are installed.
_TIER_PRIORITY = ["enterprise", "pro", "community"]

# Safe profile/name regex — prevents path traversal in CLI args that flow into Path joins.
_SAFE_NAME_RE = re.compile(r"^[A-Za-z0-9_-]+$")

# Known rulesets available on pace.watch — used by `pace rules ls` to show what can be installed.
# Replace with an API call once pace.watch exposes a /rulesets catalog endpoint.
AVAILABLE_RULESETS: list[dict[str, str]] = [
    {
        "profile": "hipaa",
        "description": "HIPAA Security Rule — ePHI exposure, encryption, access control",
    },
    {
        "profile": "soc2",
        "description": "SOC 2 Type II — availability, confidentiality, change management",
    },
    {
        "profile": "pci-dss",
        "description": "PCI DSS v4.0 — cardholder data, transmission security, authentication",
    },
    {
        "profile": "gdpr",
        "description": "GDPR — personal data exposure, consent signals, data minimisation",
    },
    {
        "profile": "nist",
        "description": "NIST CSF — identify, protect, detect, respond, recover controls",
    },
    {
        "profile": "iso27001",
        "description": "ISO 27001 — information security management system controls",
    },
]

# Safe version regex — allows dots for semver (e.g. "1.2.3", "v1.2.3") while still
# blocking path-traversal characters like "/" and "..".
_SAFE_VERSION_RE = re.compile(r"^v?[A-Za-z0-9_.+-]+$")


def _validate_name(name: str, label: str = "name") -> None:
    """Raise ValueError if *name* contains unsafe path characters."""
    if not _SAFE_NAME_RE.fullmatch(name):
        raise ValueError(
            f"Invalid {label} {name!r}: only alphanumeric characters, hyphens, and "
            "underscores are allowed."
        )


def _validate_version(version: str) -> None:
    """Raise ValueError if *version* is unsafe for use in a Path join.

    Allows dots and plus signs for semver (e.g. "1.2.3", "v1.2.3", "1.0.0+build.1")
    while rejecting slashes and sequences that could escape the target directory.
    """
    if not _SAFE_VERSION_RE.fullmatch(version) or ".." in version:
        raise ValueError(
            f"Invalid version {version!r}: must be a safe semver string "
            "(alphanumeric, dots, hyphens, underscores, plus signs; no path separators)."
        )


def _parse_semver(ver: str) -> tuple[int, int, int]:
    """Parse a semver string into a (major, minor, patch) tuple for correct comparison.

    Handles common prefixes like 'v1.2.3'. Non-numeric components default to 0.
    """
    parts = ver.lstrip("v").split(".")
    try:
        major = int(parts[0]) if len(parts) > 0 else 0
        minor = int(parts[1]) if len(parts) > 1 else 0
        patch = int(parts[2]) if len(parts) > 2 else 0
        return (major, minor, patch)
    except ValueError:
        return (0, 0, 0)


def _sorted_version_dirs(tier_dir: Path) -> list[Path]:
    """Return version subdirectories of *tier_dir* sorted by semver, descending."""
    return sorted(
        [d for d in tier_dir.iterdir() if d.is_dir()],
        key=lambda d: _parse_semver(d.name),
        reverse=True,
    )


def _tier_dirs_in_priority(base: Path) -> list[Path]:
    """Return tier subdirectories of *base* in enterprise → pro → community order.

    Known tiers are returned first in priority order; any unknown tiers are appended
    in sorted order afterwards.
    """
    result: list[Path] = []
    for tier_name in _TIER_PRIORITY:
        td = base / tier_name
        if td.exists() and td.is_dir():
            result.append(td)
    # Append any unknown tier directories (future-proofing)
    for td in sorted(base.iterdir()):
        if td.is_dir() and td.name not in _TIER_PRIORITY and td not in result:
            result.append(td)
    return result


def _global_ruleset_dir(profile: str) -> Path:
    return _GLOBAL_RULESETS_DIR / profile


def _project_ruleset_dir(profile: str) -> Path:
    return Path(".pace") / "rulesets" / profile


def _safe_tar_members(
    tar: tarfile.TarFile, dest: Path
) -> list[tarfile.TarInfo]:
    """Return only tarball members that extract within *dest*, skipping zip-slip entries.

    Checks both the member name and, for symlinks/hardlinks, the link target so that a
    malicious archive cannot create a symlink with a safe filename but an out-of-bounds
    target (e.g. ``safe/link -> ../../etc/passwd``).
    """
    dest_resolved = dest.resolve()
    safe: list[tarfile.TarInfo] = []
    for member in tar.getmembers():
        member_path = (dest / member.name).resolve()
        try:
            member_path.relative_to(dest_resolved)
        except ValueError:
            continue  # name escapes dest — zip-slip attempt
        # Also check symlink / hardlink targets.
        # Symlink linkname is relative to the symlink's containing directory.
        # Hardlink linkname is relative to the archive extraction root (dest).
        if member.linkname:
            if member.issym():
                link_target = (member_path.parent / member.linkname).resolve()
            elif member.islnk():
                link_target = (dest / member.linkname).resolve()
            else:
                link_target = None
            if link_target is not None:
                try:
                    link_target.relative_to(dest_resolved)
                except ValueError:
                    continue  # link target escapes dest — skip
        safe.append(member)
    return safe


def resolve_rules_dir(
    profile: str,
    scope: RulesetScope = "project",
) -> Path:
    """Return the directory containing YAML rules for *profile*.

    Resolution order (project-local takes precedence over global):
      1. .pace/rulesets/<profile>/   (project-local, highest-priority tier first)
      2. ~/.pace/rulesets/<profile>/ (global, highest-priority tier first)
      3. rules/<profile>/            (legacy project-root location, backward-compat)

    Within each scope the tier priority is enterprise > pro > community.
    Within each tier the latest semver version is selected.

    The first directory that contains at least one .yaml file is returned.
    If none is found, falls back to ``rules/<profile>`` so existing projects
    keep working without any changes.
    """
    _validate_name(profile, "profile")
    candidates: list[Path] = []

    if scope == "project":
        candidates.append(_project_ruleset_dir(profile))

    # Always include global as a fallback (project-local takes precedence)
    candidates.append(_global_ruleset_dir(profile))

    for base in candidates:
        if not base.exists():
            continue
        # Flat layout — .yaml files directly in the profile dir (no tier/version subdirs)
        if list(base.glob("*.yaml")):
            return base
        # Tiered layout: iterate enterprise → pro → community
        for tier_dir in _tier_dirs_in_priority(base):
            if not list(tier_dir.rglob("*.yaml")):
                continue
            # Pick the latest semver version within this tier
            for vdir in _sorted_version_dirs(tier_dir):
                if list(vdir.glob("*.yaml")):
                    return vdir
            # No version subdirs — return the tier dir itself
            return tier_dir

    # Backward-compat fallback: project-root rules/ directory
    return Path("rules") / profile


def _best_installed_tier(profile: str, scope: RulesetScope) -> tuple[Path, str] | None:
    """Return (rules_dir, tier) for the best available installed pack, or None."""
    _validate_name(profile, "profile")
    base_dirs: list[Path] = []
    if scope == "project":
        base_dirs.append(_project_ruleset_dir(profile))
    base_dirs.append(_global_ruleset_dir(profile))

    for base in base_dirs:
        if not base.exists():
            continue
        for tier in _TIER_PRIORITY:
            tier_dir = base / tier
            if not tier_dir.exists():
                continue
            for vdir in _sorted_version_dirs(tier_dir):
                if list(vdir.glob("*.yaml")):
                    return vdir, tier
    return None


def download_ruleset(
    profile: str,
    scope: RulesetScope = "project",
    *,
    force: bool = False,
) -> Path:
    """Download the latest ruleset pack for *profile* from pace.watch.

    Requires valid credentials. The pack is extracted to either
    ``.pace/rulesets/<profile>/`` (project scope) or
    ``~/.pace/rulesets/<profile>/`` (global scope).

    Args:
        profile: Compliance profile name (e.g. "hipaa", "soc2").
        scope: Where to install — "project" or "global".
        force: Re-download even if a cached version exists.

    Returns:
        Path to the installed rules directory.

    Raises:
        RuntimeError: if not authenticated, network error, or checksum mismatch.
    """
    _validate_name(profile, "profile")
    creds = get_credentials()
    if creds is None:
        raise RuntimeError(
            "Not authenticated. Run `pace auth login` to sign in to pace.watch."
        )

    # Fetch pack metadata from API
    try:
        with httpx.Client(timeout=15.0) as client:
            resp = client.get(
                f"{PACE_API_BASE}/v1/rulesets/{profile}",
                headers={"Authorization": f"Bearer {creds.api_token}"},
            )
    except httpx.HTTPError as exc:
        raise RuntimeError(f"Failed to reach pace.watch API: {exc}") from exc

    if resp.status_code == 401:
        raise RuntimeError("Authentication expired. Run `pace auth login` again.")
    if resp.status_code == 403:
        raise RuntimeError(
            f"Your current tier ({creds.tier!r}) does not include the {profile!r} ruleset. "
            "Visit pace.watch to upgrade."
        )
    if resp.status_code != 200:
        raise RuntimeError(
            f"Unexpected API response {resp.status_code} when fetching {profile!r} metadata."
        )

    meta = resp.json()
    version: str = meta["version"]
    sha256_checksum: str = meta["sha256_checksum"]
    download_url: str = meta["download_url"]
    tier: str = meta.get("tier", "community")

    # Validate API-supplied tier/version before using them in Path joins.
    _validate_name(tier, "tier")
    _validate_version(version)

    # Determine install destination
    if scope == "global":
        dest_base = _global_ruleset_dir(profile) / tier / version
    else:
        dest_base = _project_ruleset_dir(profile) / tier / version

    if not force and dest_base.exists() and list(dest_base.glob("*.yaml")):
        return dest_base  # already cached

    dest_base.mkdir(parents=True, exist_ok=True)

    # Download the tarball
    try:
        with httpx.Client(timeout=60.0) as client:
            dl_resp = client.get(download_url)
        dl_resp.raise_for_status()
    except httpx.HTTPError as exc:
        raise RuntimeError(f"Failed to download ruleset pack: {exc}") from exc

    pack_bytes = dl_resp.content

    # Verify SHA-256 checksum
    actual = hashlib.sha256(pack_bytes).hexdigest()
    if actual != sha256_checksum:
        raise RuntimeError(
            f"Checksum mismatch for {profile!r} pack — "
            f"expected {sha256_checksum}, got {actual}. "
            "The download may be corrupted."
        )

    # Extract the tarball — filter members to prevent zip-slip path traversal
    archive_path = dest_base / f"{profile}-{version}.tar.gz"
    archive_path.write_bytes(pack_bytes)
    with tarfile.open(archive_path, "r:gz") as tar:
        safe_members = _safe_tar_members(tar, dest_base)
        tar.extractall(dest_base, members=safe_members)
    archive_path.unlink()  # remove the tarball after extraction

    # Write a simple manifest
    manifest = dest_base / "manifest.json"
    import json
    manifest.write_text(
        json.dumps(
            {
                "profile": profile,
                "tier": tier,
                "version": version,
                "sha256": sha256_checksum,
                "installed_at": time.time(),
            },
            indent=2,
        )
    )

    return dest_base


def list_installed(profile: str | None = None) -> list[dict[str, str]]:
    """Return a list of installed ruleset packs across both scopes.

    Each entry has keys: profile, tier, version, scope, path.
    """
    if profile is not None:
        _validate_name(profile, "profile")
    results: list[dict[str, str]] = []

    def _scan_base(base: Path, scope_label: str) -> None:
        if not base.exists():
            return
        for prof_dir in sorted(base.iterdir()):
            if not prof_dir.is_dir():
                continue
            if profile and prof_dir.name != profile:
                continue
            for tier_dir in sorted(prof_dir.iterdir()):
                if not tier_dir.is_dir():
                    continue
                for ver_dir in sorted(tier_dir.iterdir()):
                    if ver_dir.is_dir() and list(ver_dir.glob("*.yaml")):
                        results.append(
                            {
                                "profile": prof_dir.name,
                                "tier": tier_dir.name,
                                "version": ver_dir.name,
                                "scope": scope_label,
                                "path": str(ver_dir),
                            }
                        )

    _scan_base(_GLOBAL_RULESETS_DIR, "global")
    _scan_base(Path(".pace") / "rulesets", "project")
    return results
