"""HIPAA rule library and Pass 1 AST pattern matcher — STORY-103."""
from __future__ import annotations

import logging
import re
from enum import StrEnum
from pathlib import Path

import yaml
from pydantic import BaseModel, ConfigDict, ValidationError

from pace.finding_id import compute_finding_id

logger = logging.getLogger(__name__)


class Severity(StrEnum):
    CRITICAL = "critical"
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"


class RuleCategory(StrEnum):
    SENSITIVE_DATA_EXPOSURE = "sensitive-data-exposure"
    ENCRYPTION = "encryption"
    SECRETS_CREDENTIALS = "secrets-credentials"
    AUTHENTICATION = "authentication-access-control"
    AUDIT_LOGGING = "audit-logging"
    INTEGRITY = "integrity"
    SUPPLY_CHAIN = "supply-chain"


class Rule(BaseModel):
    """A single HIPAA compliance rule loaded from a YAML file."""

    model_config = ConfigDict(extra="ignore")

    id: str
    name: str
    severity: Severity
    description: str
    pattern: str | list[str]
    fix_strategy_hint: str
    control_ref: str  # HIPAA control reference, e.g. "HIPAA §164.312(a)(1)"

    # Extended fields — optional for backwards compatibility with existing rules
    category: RuleCategory | None = None
    tags: list[str] = []
    detection_layer: str | None = None  # "pass1" | "pass2" | "both"
    detection_note: str | None = None
    false_positive_note: str | None = None


class Finding(BaseModel):
    """A pattern-match finding produced by RuleMatcher.match()."""

    finding_id: str  # stable content-hash ID — see pace.finding_id
    rule_id: str
    rule_name: str
    file_path: str
    function_name: str
    severity: Severity
    description: str
    content_hash: str  # sha256 of the function source string
    control_ref: str = ""  # inherited from the rule; empty for legacy state files


def load_rules(profile_dir: Path) -> list[Rule]:
    """Load all YAML rule files from *profile_dir*.

    - Empty directory returns [] with a warning.
    - Invalid YAML syntax: file is skipped with a warning.
    - Files may contain one rule, multiple YAML documents, or a YAML list of rules.
    - Missing required fields: rule is skipped with a warning.
    """
    yaml_files = sorted(profile_dir.glob("*.yaml"))
    if not yaml_files:
        logger.warning("load_rules: no YAML files found in %s", profile_dir)
        return []

    rules: list[Rule] = []
    for path in yaml_files:
        try:
            docs = list(yaml.safe_load_all(path.read_text()))
        except yaml.YAMLError as exc:
            logger.warning("load_rules: skipping %s — invalid YAML: %s", path.name, exc)
            continue

        for raw_doc in docs:
            raw_rules = raw_doc if isinstance(raw_doc, list) else [raw_doc]
            for raw in raw_rules:
                if not isinstance(raw, dict):
                    continue

                try:
                    rule = Rule.model_validate(raw)
                    rules.append(rule)
                except ValidationError as exc:
                    logger.warning(
                        "load_rules: skipping rule in %s — validation error: %s",
                        path.name,
                        exc,
                    )

    return rules


class RuleMatcher:
    """Applies a list of Rule patterns to a function's source string."""

    def __init__(self, rules: list[Rule]) -> None:
        self._rules = rules

    def match(
        self,
        function_source: str,
        function_name: str,
        file_path: str,
    ) -> list[Finding]:
        """Return all findings for *function_source* against the loaded rules.

        No LLM calls are made here — pure regex matching only.
        """
        import hashlib
        content_hash = hashlib.sha256(function_source.encode()).hexdigest()
        findings: list[Finding] = []

        for rule in self._rules:
            patterns: list[str] = (
                rule.pattern if isinstance(rule.pattern, list) else [rule.pattern]
            )
            matched = any(
                re.search(p, function_source, re.IGNORECASE) for p in patterns
            )
            if matched:
                findings.append(
                    Finding(
                        finding_id=compute_finding_id(rule.id, file_path, function_source),
                        rule_id=rule.id,
                        rule_name=rule.name,
                        file_path=file_path,
                        function_name=function_name,
                        severity=rule.severity,
                        description=rule.description,
                        content_hash=content_hash,
                        control_ref=rule.control_ref,
                    )
                )

        return findings
