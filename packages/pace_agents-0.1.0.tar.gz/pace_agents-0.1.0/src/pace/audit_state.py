"""Audit state file — STORY-202.

Manages `.pace/audit-state.json` which persists findings with their status
across multiple `pace scan` and `pace fix` invocations.
"""
from __future__ import annotations

import json
from datetime import UTC, datetime
from enum import StrEnum
from pathlib import Path

from pydantic import BaseModel, Field, ValidationError

from pace.rules import Finding


class FindingStatus(StrEnum):
    OPEN = "open"
    FIXED = "fixed"
    ACCEPTED_RISK = "accepted-risk"
    FALSE_POSITIVE = "false-positive"
    BLOCKED = "blocked"


class FixEvidence(BaseModel):
    """Evidence produced by a successful fix loop run for one finding."""

    branch_name: str
    commit_sha: str
    diff: str        # unified diff / patch applied by the Author
    test_output: str
    tests_passed: bool
    evaluator_verdict: str  # human-readable outcome from the Evaluator


class AuditState(BaseModel):
    """Schema-validated representation of `.pace/audit-state.json`."""

    version: str
    project_root: str
    last_scan_at: str  # ISO 8601
    profile: list[str]
    findings: list[Finding]
    statuses: dict[str, FindingStatus]  # finding_id → status
    fix_evidence: dict[str, FixEvidence] = Field(default_factory=dict)  # finding_id → evidence


def load_audit_state(path: Path) -> AuditState | None:
    """Load and validate audit state from *path*.

    Returns ``None`` if the file does not exist.
    Raises ``ValueError`` if the file exists but fails validation.
    """
    if not path.exists():
        return None
    raw = json.loads(path.read_text())
    try:
        return AuditState.model_validate(raw)
    except ValidationError as exc:
        raise ValueError(f"Invalid audit state at {path}: {exc}") from exc


def save_audit_state(state: AuditState, path: Path) -> None:
    """Write *state* to *path* as indented JSON.

    Creates parent directories as needed.
    """
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(state.model_dump(), indent=2))


def merge_findings(state: AuditState, new_findings: list[Finding]) -> AuditState:
    """Merge *new_findings* from a fresh scan into *state*.

    Rules:
    - New finding IDs not in current state are added with status OPEN.
    - Findings already in state with status FIXED, ACCEPTED_RISK, or
      FALSE_POSITIVE keep their existing status (not reset to OPEN).
    - Findings already OPEN stay OPEN.
    - The ``last_scan_at`` timestamp is updated.
    """
    existing_by_id: dict[str, Finding] = {f.finding_id: f for f in state.findings}
    existing_statuses = dict(state.statuses)

    for finding in new_findings:
        fid = finding.finding_id
        if fid not in existing_by_id:
            existing_by_id[fid] = finding
            existing_statuses[fid] = FindingStatus.OPEN
        # If already present: preserve existing status (do not override).

    return AuditState(
        version=state.version,
        project_root=state.project_root,
        last_scan_at=datetime.now(tz=UTC).isoformat(),
        profile=state.profile,
        findings=list(existing_by_id.values()),
        statuses=existing_statuses,
        fix_evidence=dict(state.fix_evidence),
    )


def get_open_findings(state: AuditState) -> list[Finding]:
    """Return findings whose status is OPEN."""
    return [
        f for f in state.findings
        if state.statuses.get(f.finding_id) == FindingStatus.OPEN
    ]
