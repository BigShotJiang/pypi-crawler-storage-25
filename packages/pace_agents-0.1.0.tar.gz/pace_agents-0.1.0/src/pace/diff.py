"""Delta audit helpers — STORY-304.

Provides get_changed_files() to resolve which source files changed
between the current HEAD and a given git ref (e.g. HEAD~1).
"""
from __future__ import annotations

import subprocess
from pathlib import Path


def get_changed_files(git_ref: str, cwd: Path | None = None) -> list[Path]:
    """Return the list of files changed between *git_ref* and HEAD.

    Runs ``git diff --name-only <git_ref>`` in *cwd* (or the current
    working directory if *cwd* is None).

    Raises ``RuntimeError`` if the git command exits with a non-zero code.
    """
    result = subprocess.run(
        ["git", "diff", "--name-only", git_ref],
        capture_output=True,
        text=True,
        cwd=cwd,
    )
    if result.returncode != 0:
        raise RuntimeError(
            f"git diff --name-only {git_ref} failed with exit code {result.returncode}: "
            f"{result.stdout}{result.stderr}"
        )

    lines = [line.strip() for line in result.stdout.splitlines() if line.strip()]
    return [Path(line) for line in lines]
