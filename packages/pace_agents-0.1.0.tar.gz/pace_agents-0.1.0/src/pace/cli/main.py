"""PACE CLI entrypoint."""
from __future__ import annotations

import json
import os
import sys
from datetime import UTC, datetime
from pathlib import Path
from typing import Annotated

import typer

from pace.audit import AuditLoop
from pace.audit_state import (
    AuditState,
    FindingStatus,
    FixEvidence,
    get_open_findings,
    load_audit_state,
    merge_findings,
    save_audit_state,
)
from pace.auth import (
    get_credentials,
    is_authenticated,
    login,
    logout,
    read_credentials,
)
from pace.config import PaceConfig, ProfileChoice
from pace.diff import get_changed_files
from pace.exceptions import PaceError
from pace.exit_codes import (
    EXIT_CONFIG_ERROR,
    EXIT_GIT_ERROR,
    EXIT_INDEX_ERROR,
    EXIT_NEW_VIOLATIONS,
    EXIT_OK,
    EXIT_USAGE_ERROR,
)
from pace.fix.author import AuthorAgent
from pace.fix.coder import CoderAgent, CoderResult
from pace.fix.evaluator import EvaluatorAgent, FixLoop
from pace.fix.planner import PlannerAgent
from pace.index import CodeIndexReader, check_codeindex_deps, resolve_db_path
from pace.llm import LLMClient
from pace.profiles import ProfileConfig, list_profiles, save_profile
from pace.report import (
    EvidenceReport,
    FindingReport,
    render_html,
    render_json_report,
    render_markdown,
)
from pace.rules import Finding, RuleMatcher, Severity, load_rules
from pace.rulesets import (
    AVAILABLE_RULESETS,
    RulesetScope,
    download_ruleset,
    list_installed,
    resolve_rules_dir,
)

app: typer.Typer = typer.Typer(help="P.A.C.E — A compliance audit CLI", rich_markup_mode="rich")

# ---------------------------------------------------------------------------
# Subcommand groups — registered after the main app is defined
# ---------------------------------------------------------------------------

auth_app: typer.Typer = typer.Typer(
    help="Manage P.A.C.E authentication.", rich_markup_mode="rich"
)
rules_app: typer.Typer = typer.Typer(
    help="Manage P.A.C.E ruleset packs.", rich_markup_mode="rich"
)
profile_app: typer.Typer = typer.Typer(
    help="Manage P.A.C.E compliance profiles.", rich_markup_mode="rich"
)

_TOML_TEMPLATE = """\
profile = "{profile}"
llm_endpoint = "https://openrouter.ai/api/v1"
llm_model = "openai/gpt-4o"
llm_api_key = "<your-api-key>"
test_command = "pytest"
"""

# ---------------------------------------------------------------------------
# Color state — mutable, set by _init_color() at command invocation time
# ---------------------------------------------------------------------------

_use_color: bool = False
# Tracks whether stdout is a real TTY — controls in-place progress updates (\r).
# Intentionally separate from _use_color: --no-color disables ANSI codes but
# should not revert TTY progress to line-per-function output.
_is_tty: bool = False

# Fixed-width severity labels for non-TTY alignment (width = len("CRITICAL") = 8).
_SEVERITY_LABELS: dict[Severity, str] = {
    Severity.CRITICAL: "[CRITICAL]",
    Severity.HIGH:     "[HIGH    ]",
    Severity.MEDIUM:   "[MEDIUM  ]",
    Severity.LOW:      "[LOW     ]",
}

_SEVERITY_COLORS: dict[Severity, str] = {
    Severity.CRITICAL: typer.colors.RED,
    Severity.HIGH:     typer.colors.YELLOW,
    Severity.MEDIUM:   typer.colors.CYAN,
    Severity.LOW:      typer.colors.WHITE,
}


def _init_color(no_color: bool) -> None:
    """Set global color and TTY state.

    _is_tty  — whether stdout is a real interactive terminal (controls \r progress).
    _use_color — whether ANSI color codes should be emitted.

    --no-color suppresses color but does NOT disable in-place TTY progress updates,
    so large scans in a terminal with --no-color still get single-line updates.
    """
    global _use_color, _is_tty
    _is_tty = sys.stdout.isatty() and os.environ.get("TERM") != "dumb"
    _use_color = not no_color and _is_tty


# ---------------------------------------------------------------------------
# App-level callback — handles --no-color and no-subcommand case
# ---------------------------------------------------------------------------


@app.callback(invoke_without_command=True)
def main_callback(
    ctx: typer.Context,
    no_color: Annotated[
        bool,
        typer.Option("--no-color", help="Disable ANSI color output regardless of TTY status."),
    ] = False,
) -> None:
    """PACE — A compliance audit CLI."""
    _init_color(no_color)
    if ctx.invoked_subcommand is None:
        typer.echo(ctx.get_help())
        raise typer.Exit(code=EXIT_USAGE_ERROR)


# ---------------------------------------------------------------------------
# Output helpers
# ---------------------------------------------------------------------------


def _color(text: str, color: str) -> str:
    if not _use_color:
        return text
    return typer.style(text, fg=color)


def _print_finding(finding: Finding) -> None:
    """Print one finding in padded-severity format."""
    label = _SEVERITY_LABELS.get(finding.severity, f"[{finding.severity.upper():<8}]")
    color = _SEVERITY_COLORS.get(finding.severity, typer.colors.WHITE)

    if _use_color:
        header = _color(label, color) + f"[{finding.rule_id}]: {finding.description}"
    else:
        header = f"{label}[{finding.rule_id}]: {finding.description}"

    location = f"  --> {finding.file_path}:{finding.function_name}"
    hint = f"  = help: {finding.rule_name}"

    typer.echo(header)
    typer.echo(location)
    typer.echo(hint)
    typer.echo("")


def _print_progress(
    label: str, func_name: str, file_path: str, index: int, total: int, extra: str = ""
) -> None:
    """Print a single-line progress update, overwriting in TTY mode.

    Uses _is_tty (not _use_color) so that --no-color does not revert to
    line-per-function output in a real terminal.
    """
    suffix = f" — {extra}" if extra else ""
    line = f"[{label}] Scanning {file_path}:{func_name} ({index}/{total}){suffix}"
    if _is_tty:
        sys.stdout.write(f"\r{line}")
        sys.stdout.flush()
    else:
        typer.echo(line)


def _deduplicate(pass1: list[Finding], pass2: list[Finding]) -> list[Finding]:
    """Merge pass1 and pass2 findings. Pass2 wins on (rule_id, function_name, file_path)."""
    pass2_keys: set[tuple[str, str, str]] = {
        (f.rule_id, f.function_name, f.file_path) for f in pass2
    }
    merged: list[Finding] = [
        f for f in pass1 if (f.rule_id, f.function_name, f.file_path) not in pass2_keys
    ]
    merged.extend(pass2)
    return merged


# ---------------------------------------------------------------------------
# Commands
# ---------------------------------------------------------------------------


@app.command()
def init(
    profile: Annotated[
        ProfileChoice,
        typer.Option(
            "--profile",
            help="Compliance profile to scaffold.",
            case_sensitive=True,
        ),
    ],
) -> None:
    """Scaffold a pace.toml for the selected compliance profile."""
    toml_path = Path("pace.toml")
    if toml_path.exists():
        typer.echo("Error: pace.toml already exists. Refusing to overwrite.", err=True)
        raise typer.Exit(code=EXIT_CONFIG_ERROR)

    toml_path.write_text(_TOML_TEMPLATE.format(profile=profile))
    typer.echo(f"Created pace.toml with profile={profile}")

    # Auth check — non-blocking CTA
    creds = read_credentials()
    if creds is None:
        typer.echo("")
        typer.echo("  [pace.watch] Sign up for expert-curated rule packs:")
        typer.echo("    https://pace.watch/signup")
        typer.echo("  Already have an account? Run: pace auth login")
        typer.echo("  Using legacy local rules — run `pace rules install` after signing up.")
    elif creds.tier == "community" and profile not in (creds.licensed_profiles or []):
        typer.echo("")
        typer.echo(
            f"  [pace.watch] Upgrade to unlock the {profile!r} Pro ruleset:"
        )
        typer.echo("    https://pace.watch/pricing")
        typer.echo(f"  Or install community rules: pace rules install {profile}")
    else:
        typer.echo(f"  Signed in as {creds.email} ({creds.tier})")
        typer.echo(f"  To download the latest {profile!r} rules: pace rules install {profile}")


@app.command()
def scan(
    pass1_only: Annotated[
        bool,
        typer.Option("--pass1-only", help="Run Pass 1 (AST matching) only — no LLM calls."),
    ] = False,
    pass2_only: Annotated[
        bool,
        typer.Option("--pass2-only", help="Run Pass 2 (LLM audit) only — stub for M2."),
    ] = False,
    profile: Annotated[
        ProfileChoice | None,
        typer.Option("--profile", help="Override the compliance profile from pace.toml."),
    ] = None,
    diff: Annotated[
        str | None,
        typer.Option(
            "--diff",
            help="Limit scan to files changed since <git-ref> (e.g. HEAD~1). "
                 "Exits 3 if new violations are found.",
        ),
    ] = None,
    quiet: Annotated[
        bool,
        typer.Option("--quiet", "-q", help="Suppress per-function progress output (for CI use)."),
    ] = False,
    index_path: Annotated[
        Path | None,
        typer.Option(
            "--index-path",
            help="Path to the codeindex database (default: .codeindex/graph.db).",
        ),
    ] = None,
) -> None:
    """Scan the codebase for compliance issues."""
    # 1. Load config
    try:
        config = PaceConfig.from_toml(Path("pace.toml"))
    except Exception as exc:
        typer.echo(f"Error: could not load pace.toml — {exc}", err=True)
        raise typer.Exit(code=EXIT_CONFIG_ERROR) from exc

    effective_profile: ProfileChoice = profile or config.profile
    pace_dir = Path(".pace")
    db_path = resolve_db_path(index_path)

    # 2. Resolve changed files for --diff mode
    changed_files: set[Path] | None = None
    if diff is not None:
        try:
            changed_files = set(get_changed_files(diff))
        except RuntimeError as exc:
            typer.echo(f"Error: {exc}", err=True)
            raise typer.Exit(code=EXIT_GIT_ERROR) from exc
        if not changed_files:
            typer.echo("[diff] No changed files detected — nothing to scan.")
            raise typer.Exit(code=EXIT_OK)
        if not quiet:
            typer.echo(f"[diff] Scanning {len(changed_files)} changed file(s) against {diff}")

    # 3. Check deps
    try:
        check_codeindex_deps(db_path)
    except PaceError as exc:
        typer.echo(str(exc), err=True)
        raise typer.Exit(code=EXIT_INDEX_ERROR) from exc

    # 4. Read index
    with CodeIndexReader(db_path) as reader:
        all_functions = reader.get_functions()
        stats = reader.get_stats()

    # Filter to changed files in --diff mode.
    if changed_files is not None:
        cwd = Path.cwd()
        resolved_changed = {(cwd / p).resolve() for p in changed_files}
        functions = [
            f for f in all_functions if Path(f.file_path).resolve() in resolved_changed
        ]
        if not functions:
            typer.echo(
                "[diff] Warning: changed files not found in code index — "
                "run codeindex to rebuild the index."
            )
    else:
        functions = all_functions

    if not quiet:
        typer.echo(
            f"[index] Code index found — {stats.function_count} functions, "
            f"{stats.file_count} files"
        )

    # 5. Load rules
    rules_dir = resolve_rules_dir(effective_profile, config.ruleset_scope)
    rules = load_rules(rules_dir)

    # 5. Pass 1 — AST pattern matching
    pass1_findings: list[Finding] = []
    if not pass2_only:
        matcher = RuleMatcher(rules)
        total = len(functions)
        for i, fn in enumerate(functions, start=1):
            if not quiet:
                _print_progress("pass1", fn.name, fn.file_path, i, total)
            matches = matcher.match(fn.source, fn.name, fn.file_path)
            pass1_findings.extend(matches)
        if not quiet and _is_tty and total > 0:
            sys.stdout.write("\n")
            sys.stdout.flush()

    # Print Pass 1 findings
    for finding in pass1_findings:
        _print_finding(finding)

    # 6. Pass 2 — LLM audit loop (unless --pass1-only)
    pass2_findings: list[Finding] = []
    if not pass1_only and not pass2_only:
        llm = LLMClient(config)
        total_fns = len(functions)
        start_time = datetime.now(tz=UTC)

        def _on_progress(current: int, total: int) -> None:
            if quiet:
                return
            elapsed = (datetime.now(tz=UTC) - start_time).seconds
            _print_progress("pass2", "", "", current, total, extra=f"{elapsed}s elapsed")

        audit = AuditLoop(
            llm=llm,
            functions=functions,
            rules=rules,
            pace_dir=pace_dir,
        )
        pass2_findings = audit.run(on_progress=_on_progress if total_fns > 0 else None)
        if not quiet and _is_tty and total_fns > 0:
            sys.stdout.write("\n")
            sys.stdout.flush()
    elif pass2_only:
        # Stub: M2 will load state from audit-state.json
        if not quiet:
            typer.echo("[pass2] --pass2-only: not yet implemented (M2)")

    # 7. Merge and deduplicate
    all_findings = _deduplicate(pass1_findings, pass2_findings)

    # 8. Write journal (if pass1-only, write a minimal journal ourselves)
    if pass1_only:
        pace_dir.mkdir(parents=True, exist_ok=True)
        journal_path = pace_dir / "audit-journal.json"
        payload = {
            "reviewed": len(functions),
            "findings": [f.model_dump() for f in all_findings],
            "journal_entries": [],
            "last_updated": datetime.now(tz=UTC).isoformat(),
        }
        journal_path.write_text(json.dumps(payload, indent=2))

    # 9. Persist audit state
    state_path = pace_dir / "audit-state.json"
    existing_state = load_audit_state(state_path)
    if existing_state is None:
        existing_state = AuditState(
            version="1.0",
            project_root=str(Path.cwd()),
            last_scan_at=datetime.now(tz=UTC).isoformat(),
            profile=[effective_profile],
            findings=[],
            statuses={},
        )
    updated_state = merge_findings(existing_state, all_findings)
    save_audit_state(updated_state, state_path)

    # 10. Print summary
    counts: dict[str, int] = {"critical": 0, "high": 0, "medium": 0, "low": 0}
    for f in all_findings:
        counts[f.severity] = counts.get(f.severity, 0) + 1

    total_count = len(all_findings)
    typer.echo(
        f"Scan complete — {total_count} findings "
        f"({counts['critical']} critical, {counts['high']} high, "
        f"{counts['medium']} medium, {counts['low']} low)"
    )

    # In --diff mode: exit 3 if any new violations found (CI gate — STORY-501)
    if diff is not None and total_count > 0:
        raise typer.Exit(code=EXIT_NEW_VIOLATIONS)
    raise typer.Exit(code=EXIT_OK)


@app.command()
def fix() -> None:
    """Apply auto-patches for all open findings via the fix loop."""
    # 1. Load config
    try:
        config = PaceConfig.from_toml(Path("pace.toml"))
    except Exception as exc:
        typer.echo(f"Error: could not load pace.toml — {exc}", err=True)
        raise typer.Exit(code=EXIT_CONFIG_ERROR) from exc

    pace_dir = Path(".pace")
    state_path = pace_dir / "audit-state.json"

    state = load_audit_state(state_path)
    if state is None:
        typer.echo("Error: no audit state found. Run `pace scan` first.", err=True)
        raise typer.Exit(code=EXIT_CONFIG_ERROR)

    open_findings = get_open_findings(state)
    if not open_findings:
        typer.echo("No open findings to fix.")
        raise typer.Exit(code=EXIT_OK)

    # 2. Load rules
    rules_dir = resolve_rules_dir(config.profile, config.ruleset_scope)
    rules = load_rules(rules_dir)

    # 3. Build agents
    llm = LLMClient(config)
    matcher = RuleMatcher(rules)
    planner = PlannerAgent()
    author = AuthorAgent(llm)
    try:
        coder = CoderAgent(project_root=Path.cwd(), test_command=config.test_command)
    except PaceError as exc:
        typer.echo(str(exc), err=True)
        raise typer.Exit(code=EXIT_GIT_ERROR) from exc
    evaluator = EvaluatorAgent(matcher)

    # 4. Plan
    queue = planner.plan(state)
    typer.echo(f"[fix] {len(queue)} open finding(s) queued for fix.")

    # 5. Fix loop — process each finding
    fix_loop = FixLoop(
        author=author,
        coder=coder,
        evaluator=evaluator,
        rules=rules,
        journal_context="",
        max_retries=3,
        project_root=Path.cwd(),
    )

    fixed = 0
    blocked = 0

    for item in queue:
        finding = item.finding
        typer.echo(f"[fix] Processing {finding.finding_id} ({finding.rule_id}) ...")
        result = fix_loop.fix_finding(finding, state)

        # Update state
        state.statuses[finding.finding_id] = result.final_status

        if result.final_status == FindingStatus.FIXED and result.last_coder_result:
            coder_result: CoderResult = result.last_coder_result
            ev = result.last_evaluator_result
            if ev and ev.finding_resolved and not ev.new_violations:
                verdict = "violation removed, no new findings"
            elif ev and ev.finding_resolved:
                vids = ", ".join(v.finding_id for v in ev.new_violations)
                verdict = f"violation removed; new violations introduced: {vids}"
            else:
                verdict = "finding not resolved"
            state.fix_evidence[finding.finding_id] = FixEvidence(
                branch_name=coder_result.branch_name,
                commit_sha=coder_result.commit_sha,
                diff=result.patch,
                test_output=coder_result.test_output,
                tests_passed=coder_result.tests_passed,
                evaluator_verdict=verdict,
            )

        status_label = "fixed" if result.final_status == FindingStatus.FIXED else "blocked"
        typer.echo(
            f"  [{status_label}] {finding.finding_id} — {result.attempts} attempt(s)"
        )
        if result.final_status == FindingStatus.FIXED:
            fixed += 1
            if result.last_coder_result:
                typer.echo(f"  Branch: {result.last_coder_result.branch_name}")
        else:
            blocked += 1

    # 6. Persist updated state
    save_audit_state(state, state_path)

    typer.echo(f"\nFix complete — {fixed} fixed, {blocked} blocked.")
    raise typer.Exit(code=EXIT_OK)


@app.command()
def report() -> None:
    """Generate a timestamped evidence report from audit state and journal."""
    pace_dir = Path(".pace")
    state_path = pace_dir / "audit-state.json"

    # 1. Load audit state
    state = load_audit_state(state_path)
    if state is None:
        typer.echo("Error: no audit state found. Run `pace scan` first.", err=True)
        raise typer.Exit(code=EXIT_CONFIG_ERROR)

    # 2. Journal loaded for future use (best-effort, currently unused in rendering)

    # 3. Build FindingReport list
    profile = state.profile[0] if state.profile else "hipaa"
    finding_reports: list[FindingReport] = []
    for finding in state.findings:
        status = state.statuses.get(finding.finding_id, FindingStatus.OPEN)
        fix_ev = state.fix_evidence.get(finding.finding_id)
        finding_reports.append(
            FindingReport(
                finding_id=finding.finding_id,
                rule_id=finding.rule_id,
                control_ref=finding.control_ref,
                severity=str(finding.severity),
                file_path=finding.file_path,
                function_name=finding.function_name,
                description=finding.description,
                status=str(status),
                diff=fix_ev.diff if fix_ev else "",
                test_result=(
                    ("passed" if fix_ev.tests_passed else "failed") if fix_ev else "n/a"
                ),
                evaluator_verdict=fix_ev.evaluator_verdict if fix_ev else "",
            )
        )

    # 4. Build EvidenceReport
    evidence = EvidenceReport(
        scan_timestamp=state.last_scan_at,
        profile=profile,
        findings=finding_reports,
    )

    # 5. Render and write files
    ts = datetime.now(tz=UTC).strftime("%Y%m%dT%H%M%S")
    md_path = pace_dir / f"report-{ts}.md"
    json_path = pace_dir / f"report-{ts}.json"
    html_path = pace_dir / f"report-{ts}.html"

    md_path.write_text(render_markdown(evidence))
    json_path.write_text(json.dumps(render_json_report(evidence), indent=2))
    html_path.write_text(render_html(evidence))

    # 6. Print summary
    table = evidence.summary_table()
    total = len(finding_reports)
    typer.echo(f"Report written — {total} finding(s)")
    for status_label, count in sorted(table.items()):
        typer.echo(f"  {status_label}: {count}")
    typer.echo(f"  Markdown: {md_path}")
    typer.echo(f"  JSON:     {json_path}")
    typer.echo(f"  HTML:     {html_path}")
    raise typer.Exit(code=EXIT_OK)


@app.command()
def status() -> None:
    """Print current audit state summary: findings, counts, last scan, profile, endpoint."""
    # 1. Load config
    try:
        config = PaceConfig.from_toml(Path("pace.toml"))
    except Exception as exc:
        typer.echo(f"Error: could not load pace.toml — {exc}", err=True)
        raise typer.Exit(code=EXIT_CONFIG_ERROR) from exc

    # 2. Load audit state
    pace_dir = Path(".pace")
    state_path = pace_dir / "audit-state.json"
    state = load_audit_state(state_path)

    if state is None:
        typer.echo("No scan has been run yet. Run `pace scan` first.")
        raise typer.Exit(code=EXIT_OK)

    # 3. Count findings by status
    total = len(state.findings)
    open_count = sum(
        1
        for f in state.findings
        if state.statuses.get(f.finding_id, FindingStatus.OPEN) == FindingStatus.OPEN
    )
    fixed_count = sum(
        1
        for f in state.findings
        if state.statuses.get(f.finding_id, FindingStatus.OPEN) == FindingStatus.FIXED
    )
    other_count = total - open_count - fixed_count

    # 4. Count by severity
    sev_counts: dict[str, int] = {"critical": 0, "high": 0, "medium": 0, "low": 0}
    for f in state.findings:
        sev_counts[str(f.severity)] = sev_counts.get(str(f.severity), 0) + 1

    # 5. Redact API key — show only the endpoint URL
    profile_str = ", ".join(state.profile) if state.profile else config.profile

    typer.echo("PACE Audit Status")
    typer.echo("─" * 40)
    typer.echo(f"Profile:      {profile_str}")
    typer.echo(f"LLM endpoint: {config.llm_endpoint}")
    typer.echo(f"Last scan:    {state.last_scan_at}")
    typer.echo("─" * 40)
    typer.echo(f"Total:        {total}")
    typer.echo(f"  Open:       {open_count}")
    typer.echo(f"  Fixed:      {fixed_count}")
    if other_count:
        typer.echo(f"  Other:      {other_count}")
    typer.echo("─" * 40)
    typer.echo(
        f"Severity:     critical={sev_counts['critical']}  high={sev_counts['high']}  "
        f"medium={sev_counts['medium']}  low={sev_counts['low']}"
    )
    raise typer.Exit(code=EXIT_OK)


# ---------------------------------------------------------------------------
# auth subcommands
# ---------------------------------------------------------------------------


@auth_app.command("login")
def auth_login() -> None:
    """Sign in to pace.watch via browser and save credentials locally."""
    typer.echo("Opening pace.watch in your browser...")
    try:
        creds = login()
    except TimeoutError as exc:
        typer.echo(f"Error: {exc}", err=True)
        raise typer.Exit(code=EXIT_CONFIG_ERROR) from exc
    except ValueError as exc:
        typer.echo(f"Error: {exc}", err=True)
        raise typer.Exit(code=EXIT_CONFIG_ERROR) from exc
    typer.echo(f"Authenticated as {creds.email} ({creds.tier})")
    if creds.licensed_profiles:
        typer.echo(f"Licensed profiles: {', '.join(creds.licensed_profiles)}")
    raise typer.Exit(code=EXIT_OK)


@auth_app.command("logout")
def auth_logout() -> None:
    """Remove stored credentials."""
    if not is_authenticated():
        typer.echo("Not currently authenticated.")
        raise typer.Exit(code=EXIT_OK)
    logout()
    typer.echo("Logged out — credentials removed.")
    raise typer.Exit(code=EXIT_OK)


@auth_app.command("status")
def auth_status() -> None:
    """Show current authentication status."""
    from pace.cli.rich_utils import print_panel
    creds = get_credentials()
    if creds is None:
        typer.echo("Not authenticated. Run `pace auth login` to sign in.")
        raise typer.Exit(code=EXIT_OK)
    rows: list[tuple[str, str]] = [("Email", creds.email), ("Tier", creds.tier)]
    if creds.licensed_profiles:
        rows.append(("Profiles", ", ".join(creds.licensed_profiles)))
    if creds.expires_at:
        rows.append(("Expires", creds.expires_at))
    print_panel(rows, title="Authentication")
    raise typer.Exit(code=EXIT_OK)


# ---------------------------------------------------------------------------
# rules subcommands
# ---------------------------------------------------------------------------


@rules_app.command("ls")
def rules_ls(
    profile_filter: Annotated[
        str | None,
        typer.Option("--profile", help="Filter to a specific profile."),
    ] = None,
) -> None:
    """List installed ruleset packs and available packs from pace.watch."""
    installed = list_installed(profile_filter)
    installed_profiles = {e["profile"] for e in installed}

    # --- Installed ---
    if installed:
        typer.echo("Installed packs")
        typer.echo("─" * 80)
        typer.echo(f"  {'PROFILE':<12} {'TIER':<12} {'VERSION':<10} {'SCOPE':<10} PATH")
        for entry in installed:
            typer.echo(
                f"  {entry['profile']:<12} {entry['tier']:<12} {entry['version']:<10} "
                f"{entry['scope']:<10} {entry['path']}"
            )
    else:
        typer.echo("No ruleset packs installed.")

    # --- Available ---
    available = [
        r for r in AVAILABLE_RULESETS
        if profile_filter is None or r["profile"] == profile_filter
    ]
    not_installed = [r for r in available if r["profile"] not in installed_profiles]
    if not_installed:
        typer.echo("")
        typer.echo("Available packs")
        typer.echo("─" * 80)
        typer.echo(f"  {'PROFILE':<12} DESCRIPTION")
        for r in not_installed:
            typer.echo(f"  {r['profile']:<12} {r['description']}")
        typer.echo("")
        typer.echo("  Run `pace rules install <profile>` to download a pack.")

    typer.echo("")
    typer.echo(
        "  Visit pace.watch/rules for expert-reviewed rulesets — "
        "HIPAA, SOC2, GDPR and more."
    )
    raise typer.Exit(code=EXIT_OK)


@rules_app.command("install")
def rules_install(
    profile: Annotated[str, typer.Argument(help="Compliance profile to install (e.g. hipaa).")],
    global_install: Annotated[
        bool,
        typer.Option("--global", help="Install to ~/.pace/rulesets/ instead of .pace/rulesets/."),
    ] = False,
    force: Annotated[
        bool,
        typer.Option("--force", help="Re-download even if a cached version exists."),
    ] = False,
) -> None:
    """Download and cache a ruleset pack from pace.watch."""
    scope: RulesetScope = "global" if global_install else "project"
    typer.echo(f"Downloading {profile!r} ruleset pack ({scope} install)...")
    try:
        dest = download_ruleset(profile, scope, force=force)
    except RuntimeError as exc:
        typer.echo(f"Error: {exc}", err=True)
        raise typer.Exit(code=EXIT_CONFIG_ERROR) from exc
    typer.echo(f"Installed {profile!r} rules to {dest}")
    raise typer.Exit(code=EXIT_OK)


@rules_app.command("update")
def rules_update(
    profile: Annotated[
        str | None,
        typer.Argument(help="Profile to update (omit to update all installed packs)."),
    ] = None,
    global_install: Annotated[
        bool,
        typer.Option("--global", help="Update global install."),
    ] = False,
) -> None:
    """Update installed ruleset packs to the latest version."""
    scope: RulesetScope = "global" if global_install else "project"
    targets = list_installed(profile)
    if not targets:
        msg = (
            f"No installed packs found for {profile!r}."
            if profile
            else "No installed packs found."
        )
        typer.echo(msg)
        raise typer.Exit(code=EXIT_OK)
    for entry in targets:
        typer.echo(f"Updating {entry['profile']!r} ({entry['tier']})...")
        try:
            dest = download_ruleset(entry["profile"], scope, force=True)
            typer.echo(f"  Updated to {dest}")
        except RuntimeError as exc:
            typer.echo(f"  Error: {exc}", err=True)
    raise typer.Exit(code=EXIT_OK)


@rules_app.command("remove")
def rules_remove(
    profile: Annotated[str, typer.Argument(help="Profile pack to remove.")],
    global_install: Annotated[
        bool,
        typer.Option("--global", help="Remove from global install."),
    ] = False,
) -> None:
    """Remove an installed ruleset pack."""
    import shutil

    from pace.rulesets import (
        _GLOBAL_RULESETS_DIR,
        _SAFE_NAME_RE,
        _global_ruleset_dir,
        _project_ruleset_dir,
    )

    # Validate profile name before using it in a path operation
    if not _SAFE_NAME_RE.fullmatch(profile):
        typer.echo(
            "Error: invalid profile name — only alphanumeric characters, hyphens, and "
            "underscores are allowed.",
            err=True,
        )
        raise typer.Exit(code=EXIT_USAGE_ERROR)

    scope: RulesetScope = "global" if global_install else "project"
    target = _global_ruleset_dir(profile) if scope == "global" else _project_ruleset_dir(profile)

    # Verify the resolved path stays within the expected rulesets root (defense-in-depth)
    expected_root = (
        _GLOBAL_RULESETS_DIR if scope == "global" else Path(".pace") / "rulesets"
    )
    try:
        target.resolve().relative_to(expected_root.resolve())
    except ValueError as exc:
        typer.echo("Error: resolved path escapes the rulesets directory.", err=True)
        raise typer.Exit(code=EXIT_USAGE_ERROR) from exc

    if not target.exists():
        typer.echo(f"No {scope} install found for {profile!r}.")
        raise typer.Exit(code=EXIT_OK)
    shutil.rmtree(target)
    typer.echo(f"Removed {profile!r} ruleset pack ({scope}).")
    raise typer.Exit(code=EXIT_OK)


# ---------------------------------------------------------------------------
# profile subcommands
# ---------------------------------------------------------------------------


@profile_app.command("ls")
def profile_ls() -> None:
    """List custom compliance profiles."""
    profiles = list_profiles()
    if not profiles:
        typer.echo("No custom profiles defined.")
        typer.echo("Run `pace profile create <name>` to create one.")
        raise typer.Exit(code=EXIT_OK)
    for p in profiles:
        label = f"{p.name}" + (f" ({p.display_name})" if p.display_name else "")
        typer.echo(f"  {label}")
        for rs in p.rulesets:
            typer.echo(f"    - {rs}")
    raise typer.Exit(code=EXIT_OK)


@profile_app.command("create")
def profile_create(
    name: Annotated[str, typer.Argument(help="Profile name (alphanumeric, hyphens).")],
    display_name: Annotated[
        str,
        typer.Option("--display-name", help="Human-readable label."),
    ] = "",
    rulesets: Annotated[
        list[str],
        typer.Option("--ruleset", help="Ruleset reference (e.g. hipaa:pro). Repeatable."),
    ] = [],  # noqa: B006
) -> None:
    """Create a new custom compliance profile."""
    from pace.rulesets import _SAFE_NAME_RE

    if not _SAFE_NAME_RE.fullmatch(name):
        typer.echo(
            "Error: invalid profile name — only alphanumeric characters, hyphens, and "
            "underscores are allowed.",
            err=True,
        )
        raise typer.Exit(code=EXIT_USAGE_ERROR)
    if not rulesets:
        typer.echo("Error: at least one --ruleset is required.", err=True)
        raise typer.Exit(code=EXIT_USAGE_ERROR)
    p = ProfileConfig(name=name, display_name=display_name, rulesets=rulesets)
    path = save_profile(p)
    typer.echo(f"Profile {name!r} saved to {path}")
    raise typer.Exit(code=EXIT_OK)


@profile_app.command("edit")
def profile_edit(
    name: Annotated[str, typer.Argument(help="Profile to edit.")],
) -> None:
    """Open a custom profile in $EDITOR."""
    import subprocess

    from pace.auth import PACE_DIR
    from pace.rulesets import _SAFE_NAME_RE

    if not _SAFE_NAME_RE.fullmatch(name):
        typer.echo(
            "Error: invalid profile name — only alphanumeric characters, hyphens, and "
            "underscores are allowed.",
            err=True,
        )
        raise typer.Exit(code=EXIT_USAGE_ERROR)
    path = PACE_DIR / "profiles" / f"{name}.toml"
    if not path.exists():
        typer.echo(f"Error: profile {name!r} not found.", err=True)
        raise typer.Exit(code=EXIT_CONFIG_ERROR)
    editor = os.environ.get("EDITOR", "vi")
    subprocess.run([editor, str(path)], check=False)
    raise typer.Exit(code=EXIT_OK)


@profile_app.command("delete")
def profile_delete(
    name: Annotated[str, typer.Argument(help="Profile to delete.")],
) -> None:
    """Delete a custom profile."""
    from pace.rulesets import _SAFE_NAME_RE

    if not _SAFE_NAME_RE.fullmatch(name):
        typer.echo(
            "Error: invalid profile name — only alphanumeric characters, hyphens, and "
            "underscores are allowed.",
            err=True,
        )
        raise typer.Exit(code=EXIT_USAGE_ERROR)
    from pace.profiles import delete_profile as _delete

    removed = _delete(name)
    if removed:
        typer.echo(f"Profile {name!r} deleted.")
    else:
        typer.echo(f"Profile {name!r} not found.")
    raise typer.Exit(code=EXIT_OK)


# Register subcommand groups
app.add_typer(auth_app, name="auth")
app.add_typer(rules_app, name="rules")
app.add_typer(profile_app, name="profile")


if __name__ == "__main__":
    app()
