"""Shared rich output helpers for all pace CLI commands."""
from __future__ import annotations

from collections.abc import Sequence

from rich.console import Console
from rich.panel import Panel
from rich.table import Table


def print_panel(rows: Sequence[tuple[str, str]], title: str) -> None:
    """Print key/value rows inside a titled panel, matching the help-box style."""
    table = Table.grid(padding=(0, 2))
    table.add_column(style="cyan")
    table.add_column()
    for label, value in rows:
        table.add_row(label, value)
    Console().print(Panel(table, title=title, title_align="left"))
