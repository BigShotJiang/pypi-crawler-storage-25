"""Stable finding ID scheme — STORY-201.

A finding ID is defined as:
    sha256(rule_id + file_path + normalize_source(function_source))[:16]

Normalization strips comments, blank lines, and per-line leading/trailing
whitespace so that cosmetic edits (adding comments, shifting line numbers)
do not change the ID.
"""
from __future__ import annotations

import hashlib
import io
import tokenize


def normalize_source(source: str) -> str:
    """Return a normalized representation of *source* for ID computation.

    Transformations applied:
    - Strip Python comments (# …) using the tokenize module so that hash
      characters inside string literals are preserved.
    - Strip blank lines.
    - Strip leading and trailing whitespace from every line.
    """
    try:
        lines = _strip_comments(source)
    except (tokenize.TokenError, SyntaxError):
        lines = _strip_comments_fallback(source)

    cleaned = [line.strip() for line in lines if line.strip()]
    return "\n".join(cleaned)


def _strip_comments(source: str) -> list[str]:
    """Return source lines with comment tokens removed, preserving spacing."""
    tokens = list(tokenize.generate_tokens(io.StringIO(source).readline))

    # Build a map from line number → column offsets of comment tokens to remove.
    comment_cols: dict[int, int] = {}
    for tok_type, _tok_string, tok_start, _tok_end, _tok_line in tokens:
        if tok_type == tokenize.COMMENT:
            lineno, col = tok_start
            comment_cols[lineno] = col

    result: list[str] = []
    for lineno, line in enumerate(source.splitlines(), start=1):
        if lineno in comment_cols:
            col = comment_cols[lineno]
            line = line[:col]
        result.append(line)

    return result


def _strip_comments_fallback(source: str) -> list[str]:
    """Regex-based fallback: strip # comments naively (no string-literal awareness)."""
    import re
    result: list[str] = []
    for line in source.splitlines():
        stripped = re.sub(r"\s*#.*$", "", line)
        result.append(stripped)
    return result


def compute_finding_id(rule_id: str, file_path: str, function_source: str) -> str:
    """Return the stable 16-character hex finding ID.

    The ID is the first 16 hex characters of:
        sha256(rule_id + file_path + normalize_source(function_source))
    """
    normalized = normalize_source(function_source)
    raw = (rule_id + file_path + normalized).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()[:16]
