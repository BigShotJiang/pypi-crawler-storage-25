"""codeindex CLI runner — subprocess wrapper for codeindex query commands.

All ``query`` subcommands emit JSON to stdout and can be called directly via
shell with no server setup required.

**Stale-index handling**

Object-returning commands (:func:`query_file_structure`, :func:`query_callers`,
:func:`query_subgraph`, :func:`status` with *as_json=True*) include a
top-level ``stale`` boolean flag and ``metadata.stale_files``.  Use
:func:`is_stale` on their results and call :func:`reindex` when ``True``.

List-returning commands (:func:`query_find_symbol`, :func:`query_references`)
return plain arrays — :func:`is_stale` does not apply to them.  If you need
freshness guarantees before a symbol search, call :func:`status` first.

Typical agent usage::

    from pace.codeindex import query_callers, is_stale, reindex

    result = query_callers("handle_request", depth=2)
    if is_stale(result):
        reindex()
        result = query_callers("handle_request", depth=2)
"""
from __future__ import annotations

import json
import subprocess
from pathlib import Path
from typing import Literal, cast

from pace.exceptions import PaceError
from pace.index import CODEINDEX_INSTALL_HINT

# ---------------------------------------------------------------------------
# Public type aliases
# ---------------------------------------------------------------------------

JsonObject = dict[str, object]
JsonList = list[object]

#: Valid values for the ``--kind`` flag of :func:`query_find_symbol`.
SymbolKind = Literal["fn", "class", "type", "interface", "var"]


# ---------------------------------------------------------------------------
# Internal subprocess helpers
# ---------------------------------------------------------------------------


def _run(
    *args: str,
    cwd: Path | None = None,
    check: bool = True,
    timeout: int = 60,
) -> subprocess.CompletedProcess[str]:
    """Run ``codeindex <args>`` and return the completed process.

    Raises :class:`~pace.exceptions.PaceError` when:

    * the binary is not on PATH (guides the user to install),
    * the command times out, or
    * the exit code is non-zero and *check* is ``True``.
    """
    cmd = ["codeindex", *args]
    try:
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            cwd=cwd,
            timeout=timeout,
        )
    except FileNotFoundError as exc:
        raise PaceError(
            f"codeindex binary not found. Install with: {CODEINDEX_INSTALL_HINT}"
        ) from exc
    except subprocess.TimeoutExpired as exc:
        raise PaceError(
            f"codeindex {' '.join(args)} timed out after {timeout}s"
        ) from exc

    if check and result.returncode != 0:
        detail = result.stderr.strip() or result.stdout.strip()
        raise PaceError(
            f"codeindex {' '.join(args)} failed (exit {result.returncode}): {detail}"
        )
    return result


def _parse_object(stdout: str, cmd_desc: str) -> JsonObject:
    """Parse *stdout* as a JSON object; raise :class:`PaceError` on failure."""
    try:
        raw = json.loads(stdout)
    except json.JSONDecodeError as exc:
        raise PaceError(
            f"codeindex {cmd_desc} returned non-JSON: {stdout[:200]!r}"
        ) from exc
    if not isinstance(raw, dict):
        raise PaceError(
            f"codeindex {cmd_desc} returned {type(raw).__name__}, expected object"
        )
    return cast(JsonObject, raw)


def _parse_list(stdout: str, cmd_desc: str) -> JsonList:
    """Parse *stdout* as a JSON array; raise :class:`PaceError` on failure."""
    try:
        raw = json.loads(stdout)
    except json.JSONDecodeError as exc:
        raise PaceError(
            f"codeindex {cmd_desc} returned non-JSON: {stdout[:200]!r}"
        ) from exc
    if not isinstance(raw, list):
        raise PaceError(
            f"codeindex {cmd_desc} returned {type(raw).__name__}, expected array"
        )
    return cast(JsonList, raw)


# ---------------------------------------------------------------------------
# Staleness helper
# ---------------------------------------------------------------------------


def is_stale(response: JsonObject) -> bool:
    """Return ``True`` if the codeindex response indicates the index is behind HEAD.

    All ``query`` responses carry a top-level ``stale`` flag.  When it is
    ``True`` the agent should call :func:`reindex` then retry the query.
    """
    return bool(response.get("stale"))


# ---------------------------------------------------------------------------
# Maintenance commands
# ---------------------------------------------------------------------------


def init(yes: bool = False, cwd: Path | None = None) -> None:
    """Auto-detect languages and create/update the codeindex config.

    Pass *yes=True* to accept all prompts without interaction.
    """
    args = ["init"]
    if yes:
        args.append("--yes")
    _run(*args, cwd=cwd)


def reindex(
    path: Path | None = None,
    cwd: Path | None = None,
    timeout: int = 300,
) -> None:
    """Re-index *path* (or the whole repo when *path* is ``None``).

    *timeout* defaults to 300 seconds — full-repo indexing can take several
    minutes on large codebases.  Increase it if your repo consistently exceeds
    the default.
    """
    args = ["reindex"]
    if path is not None:
        args.append(str(path))
    _run(*args, cwd=cwd, timeout=timeout)


def status(as_json: bool = False, cwd: Path | None = None) -> str | JsonObject:
    """Return the index health summary.

    When *as_json* is ``True`` the response is parsed and returned as a dict
    that includes the ``stale`` flag and ``metadata.stale_files``.
    Otherwise the raw text output is returned.
    """
    args = ["status"]
    if as_json:
        args.append("--json")
        result = _run(*args, cwd=cwd)
        return _parse_object(result.stdout, "status --json")
    return _run(*args, cwd=cwd).stdout


def version(cwd: Path | None = None) -> str:
    """Return the installed codeindex version string."""
    return _run("version", cwd=cwd).stdout.strip()


# ---------------------------------------------------------------------------
# Query commands — all return JSON with a top-level ``stale`` flag
# ---------------------------------------------------------------------------


def query_file_structure(path: Path, cwd: Path | None = None) -> JsonObject:
    """Structural skeleton of *path*: exports, functions, classes, types.

    Agents use this to understand a file's shape before navigating its
    symbols.  Check :func:`is_stale` on the result and call
    :func:`reindex` when ``True``.
    """
    result = _run("query", "file-structure", str(path), cwd=cwd)
    return _parse_object(result.stdout, f"query file-structure {path}")


def query_find_symbol(
    name: str,
    kind: SymbolKind | None = None,
    cwd: Path | None = None,
) -> JsonList:
    """Locate where *name* is defined across the codebase.

    *kind* narrows the search: ``"fn"``, ``"class"``, ``"type"``,
    ``"interface"``, or ``"var"``.

    Returns a list of definition objects (file, line, kind, …).
    """
    args = ["query", "find-symbol", name]
    if kind is not None:
        args += ["--kind", kind]
    result = _run(*args, cwd=cwd)
    return _parse_list(result.stdout, f"query find-symbol {name}")


def query_references(symbol: str, cwd: Path | None = None) -> JsonList:
    """Every file and line that uses *symbol*.

    Returns a list of reference objects, each with ``file``, ``line``, and
    surrounding context.
    """
    result = _run("query", "references", symbol, cwd=cwd)
    return _parse_list(result.stdout, f"query references {symbol}")


def query_callers(
    symbol: str,
    depth: int | None = None,
    cwd: Path | None = None,
) -> JsonObject:
    """Trace the upstream call graph from *symbol*.

    *depth* limits how many hops to follow (the binary decides the default).
    Response includes ``stale`` and ``metadata.stale_files``.
    """
    args = ["query", "callers", symbol]
    if depth is not None:
        args += ["--depth", str(depth)]
    result = _run(*args, cwd=cwd)
    return _parse_object(result.stdout, f"query callers {symbol}")


def query_subgraph(
    symbol: str,
    depth: int | None = None,
    edge_kinds: list[str] | None = None,
    cwd: Path | None = None,
) -> JsonObject:
    """Bounded graph neighborhood around *symbol* — up to *depth* hops.

    *edge_kinds* restricts which relationship types are traversed
    (e.g. ``["calls", "imports"]``).
    Response includes ``stale`` and ``metadata.stale_files``.
    """
    args = ["query", "subgraph", symbol]
    if depth is not None:
        args += ["--depth", str(depth)]
    if edge_kinds:
        args += ["--edge-kinds", ",".join(edge_kinds)]
    result = _run(*args, cwd=cwd)
    return _parse_object(result.stdout, f"query subgraph {symbol}")
