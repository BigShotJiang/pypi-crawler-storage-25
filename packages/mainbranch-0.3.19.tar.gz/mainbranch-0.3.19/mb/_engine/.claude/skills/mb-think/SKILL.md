---
name: mb-think
description: "Combined research, decision, and codification workflow. Use when: (1) Exploring a question before committing (2) Making a decision that needs documentation (3) User says research, decide, figure out, explore, codify, enrich, sharpen this offer, improve the offer, add context, keyword gate, analyze this VSL, extract the pitch, script teardown, objection mining, or sales video research (4) Updating reference files based on decisions (5) User wants to add testimonials, angles, proof, mechanisms, objections, guarantees, or pitch context. Supports modes: full flow, research-only, keyword-gate, decide-only, codify."
loops: [sense, decide, ship]
---

# Think

Research, decide, and codify knowledge into reference files.

---

## Don't Overthink Think

This skill is for: **"I don't know what happens next. I just need to start."**

Something came your way — a video, a voice memo, a vague feeling, a problem to solve. You don't need a plan. Just start. The skill finds the overlap between your interest and your offer.

**Re-invoke often.** Saying `/mb-think` again is normal. It reloads context. Do it after:
- Reading a large transcript (burns tokens)
- Compaction (context window reset)
- Switching focus
- Anytime you feel lost

**Save progress at natural boundaries.** After a research batch, accepted
decision, codify pass, or major reference-file update, ask whether to save a
checkpoint before moving to the next phase. Run `mb checkpoint --plan --json`,
show the proposed message, changed files, and blockers, then ask whether to save
it. Validate the final message with `mb checkpoint --validate "..." --json`;
after operator approval, run `mb checkpoint --message "..." --yes`. Do not save
hidden checkpoints.

When research identifies a reusable growth mechanic such as a comment-keyword,
DM-keyword, public reply/link, resource delivery, provider setup recipe, or
approval gate, route the durable plan into
`pushes/<YYYY-MM-DD-slug>/playbooks/<playbook>.md` with `type: playbook`.
Playbooks are plans, approval records, safe provider-state notes, validation
evidence, and outcome hooks. They are not provider execution.

When the operator asks for a researched brief, site brief, launch brief, or
research meant to feed `/mb-ads`, `/mb-site`, or push playbooks, support:

```text
/mb-think --brief-format=grok-8 <topic>
```

Load [references/grok-8-brief-format.md](references/grok-8-brief-format.md).
This mode structures findings across eight categories: business/offering, ICP,
journey, competitive landscape, brand story, technical requirements, content
assets, and metrics/constraints. Use it as an opt-in format, not the default
unless the operator chooses it.

---

## Two Modes of Work

Before diving in, know which mode you're in:

| Mode | You're doing | Examples |
|------|--------------|----------|
| **Enriching the core** | Pulling insights → reference files | Mining videos, making decisions, updating offer.md, **building content-strategy.md** |
| **Creating for the world** | Reference files → output | Ads, scripts, courses, code, posts |

`/mb-think` is for **enriching the core**. When you're ready to create, use `/mb-ads`, `/mb-organic`, `/mb-site`, or just ask.

Both are work. Enriching the core levels up everything downstream.

---

## Pull Latest Updates

See **[references/pull-engine-updates.md](references/pull-engine-updates.md)** for the standard Main Branch update check. Run it at the start of every /mb-think invocation.

---

## CLI Facts First

Provider readiness comes from `mb` first. Run or reuse:

```bash
mb status --json --peek
mb connect doctor --json
```

Use those facts for GitHub, Google/Workspace, Meta Ads, Apify, and other
provider repair language. Runtime-local tool checks happen only after a
selected research path needs them and `mb` cannot inspect the tool directly.

**Quick gist:** On first `/mb-think` invocation, read status/connect facts. When
the user's intent needs a runtime-local tool, check only that tool, cache
session knowledge, and offer the `mb connect` repair command or a fallback.
Surface a missing-tool option once per session per tool.

See **[references/tool-detection.md](references/tool-detection.md)** for the full status-value table, staleness rules, per-tool detection methods (Apify, Gemini, Grok, whisper, Nano Banana, Meta ad account context, document tools), required config-update format, and the intent-based tool surfacing matrix.

For self-healing semantics (stale false handling, status-change messaging, true-tool degradation), see [tool-status-self-healing.md](references/tool-status-self-healing.md).

---

## Offer Context Resolution

Before loading reference files, resolve the active offer and target file type
with `.claude/reference/business-primitives/offer-bet-push-proof.md`:

1. If a future `mb` JSON field exposes active offer state, use it.
2. Do not treat `.vip/local.yaml` as the source of truth for active-offer
   state. If legacy state exists, confirm the offer with the user instead of
   silently routing.
3. If an offer is selected and `core/offers/[offer]/offer.md` exists, load it as the active offer.
4. If no offer is selected AND `core/offers/` exists: ask which offer.
5. If no `core/offers/` folder: use `core/offer.md` (single-offer mode)
6. Legacy fallback: if the repo does not have `core/`, read the old
   `reference/core/` and `reference/offers/` paths.

In current repos, `reference/core` and `reference/offers` are compatibility
bridges to `core/` and `core/offers/`. Treat them as aliases, not duplicate
files: write once to the current `core/` path and never ask the user to edit
both.

**Always-core files:** `soul.md`, `voice.md`, `content-strategy.md`. See [codify-phase.md](references/codify-phase.md) for content strategy layers.
**Offer-aware files:** `offer.md`, `audience.md`
**Proof files:** company-wide proof uses `core/proof/testimonials.md`,
`core/proof/typicality.md`, and `core/proof/angles/`; offer-specific proof
uses matching files under `core/offers/<slug>/proof/`.
When codifying proof, make permission, offer-link, outcome, timeframe, metric, and typicality facts explicit so `money_path.objects.proof.quality` can see them.

For a live idea, ask whether it is something to keep selling or something to
test before deciding. Use `bets/` for the time-boxed wager, offer files for
durable sellable truth, `pushes/` for coordinated execution, and `decisions/`
for accepted rationale that changes durable truth.

---

## Where Files Go

All files save to YOUR business repo, not the Main Branch engine.

```
your-business-repo/          <- Files saved here
├── research/                 <- Research output
├── decisions/                <- Decision output
├── core/                     <- Brand-level codify updates
│   ├── offers/               <- Per-offer codify updates
│   ├── proof/                <- Testimonials, typicality, angles
│   ├── brand/                <- Visual identity and brand systems
│   └── operations/           <- Fulfillment, classroom, funnel, membership notes

mainbranch/ (engine)          <- Never modified
```

---

## Route by Intent

Detect mode from user's natural language:

| User Says | Mode | Reference |
|-----------|------|-----------|
| "figure out", "explore", "I'm trying to..." | Full Flow | - |
| "research", "investigate", "what do we know about" | Research | [research-phase.md](references/research-phase.md) |
| "--brief-format=grok-8", "researched brief", "site brief", "launch brief" | Research Brief | [grok-8-brief-format.md](references/grok-8-brief-format.md) |
| "sharpen this offer", "improve the offer", "make this offer convert", "pressure-test this offer" | Full Flow | `.claude/reference/conversion/offer-sharpening.md` |
| "what are people saying", "sentiment", "X/Twitter", "trending" | Research (Grok) | [grok-social.md](references/grok-social.md) |
| "analyze this VSL", "extract the pitch", "script teardown", "objection mining" | Research | [sales-video-research.md](references/sales-video-research.md) |
| "winning ads", "review mining", "customer language", "competitor ads", "comment mining" | Research | [winning-ad-research.md](references/winning-ad-research.md) |
| "keyword gate", "kill or build this offer", "search demand", "buyer intent", "validate paid traffic demand" | Keyword Gate Research | [keyword-gate.md](references/keyword-gate.md) |
| "decide", "we chose", "document decision" | Decide | [decide-phase.md](references/decide-phase.md) |
| "codify", "apply", "update reference files" | Codify | [codify-phase.md](references/codify-phase.md) |
| "add context", "enrich", "I have new info" | Codify | [codify-phase.md](references/codify-phase.md) |
| "content strategy", "pillars", "what platforms", "content plan", "cadence", "channel strategy", "account strategy", "founder voice", "weekly content plan" | Full Flow (codify to the right content strategy layer) | [codify-phase.md](references/codify-phase.md) |
| "where was I", "continue", "pick up" | Recovery | [recovery.md](references/recovery.md) |
| "here's a PDF", "ingest this", "convert this document", file path (.pdf/.docx/.pptx) | Document Ingestion | [document-ingestion.md](references/document-ingestion.md) |

If unclear, ask: "Are you exploring a question, documenting a decision, or updating reference files?"

---

## Research Routing by Intent

When routing to research mode, detect research TYPE from user intent:

| User Intent | Trigger Phrases | Primary Tool | Fallback |
|-------------|-----------------|--------------|----------|
| YouTube research | YouTube URL, "transcribe video", "what does [creator] say" | Apify | Ask for manual transcript |
| X/Twitter sentiment | "what are people saying", "sentiment on X", "Twitter discourse" | Grok | WebSearch site:x.com |
| Deep web research | "deep research", "comprehensive analysis", "research everything" | Gemini | Multi-source WebSearch |
| Local transcription | Local file path (.mp4, .m4a), "transcribe my recording" | whisper | CLI mlx_whisper or whisper-cli |
| Instagram mining | Instagram handle, "mine [handle]", "competitor posts" | Apify | Manual screenshots |
| Ad account research | "ad performance", "what's working", "check CPA", "audit my ads" | Verified Meta ad account context | Manual Ads Manager check |
| Winning-ad research | "customer language", "competitor ads", "review mining", "script teardown", "comment mining" | WebSearch + Apify/Grok when configured | Manual exports, screenshots, pasted transcripts |
| Keyword gate | "keyword gate", "kill or build", "search demand", "buyer intent", "paid traffic demand" | SERP/search sidecar + Keyword Planner CSV when available | WebSearch + operator-provided exports |
| General research | Default, "research [topic]", "what do we know" | WebSearch + codebase | Always available |

**Multiple types needed at once?** Spawn them as parallel Task agents in a single message. Example: user says "research what [creator] says on YouTube and what people think on X" — spawn one agent for YouTube transcript mining and another for X/Twitter sentiment simultaneously. Each saves its own research file; main conversation synthesizes when both return.

### Routing Logic

```
1. Parse user message for intent triggers
2. Check if preferred tool is available (from session cache)
3. If multiple sources needed → spawn parallel Task agents (one per source)
4. If single source → use preferred tool directly
5. If not available → offer setup ONCE, then use fallback
6. Never block on missing optional tools
```

### Fallback Examples

**YouTube without Apify:**
> "YouTube transcript mining needs Apify MCP. Options:
> 1. Set up Apify now (5 min)
> 2. Paste transcript manually
> 3. Skip this video"

**X/Twitter without Grok:**
> "X sentiment research is best with Grok, but I can use web search instead. Results will be less real-time. Proceed with web search?"

**Deep research without Gemini:**
> "Running comprehensive research using Claude Code web search. This may take longer than Gemini deep research."

**Local file without whisper:**
> "Local transcription needs a whisper variant. Check: `which mlx_whisper` or `which whisper-cli`. Or upload to a transcription service and paste the result."

**Ad account data without connection:**
> "Ad account research works best with live Meta ad account context. It is optional and only available after `mb connect` reports the official Meta path ready. Options:
> 1. Run `mb connect plan`
> 2. Check Ads Manager manually and paste what you find
> 3. Skip account data, research from reference files only"

**Winning-ad research without optional tools:**
> "Winning-ad research can still run from manual exports, screenshots, pasted
> reviews, or transcripts. Apify/Grok can speed up public comment and X research
> when configured, but they are optional."

### Key Principle

**Never block on missing tools.** WebSearch + codebase search are ALWAYS available. External tools enhance but don't gate research.

---

## Active Guidance (Your Job)

**Don't just provide templates. Actively move people through the cycle.**

On every `/mb-think` invocation, detect state and guide the next step:

```bash
# Check for continuity and rationale state
ls -lt research/*.md 2>/dev/null | head -3
grep -l "status: proposed\|status: accepted" decisions/*.md 2>/dev/null
# Also check content strategy state
ls core/content-strategy.md 2>/dev/null
```

| If you find... | Then... |
|----------------|---------|
| Recent research, no decision | "You have research on [topic]. Ready to make a decision?" |
| Proposed decision | "Decision [topic] is proposed. Ready to accept it?" |
| Accepted decision (not yet codified) | "Decision [topic] is accepted. Ready to codify the changes into reference files?" |
| content-strategy.md exists but empty/thin | "Your content strategy file is a skeleton. Want to fill it in? We can define the known-for target, pillars, asset jobs, and distribution links from your offer, audience, proof, and voice." |
| content-strategy.md missing (community biz) | "You don't have a content strategy yet. Want to build one? It'll define what you want to be known for, your pillars, asset jobs, and distribution layers." |
| skool-surfaces.md missing (community biz with live Skool) | "Your Skool about page and pricing card copy aren't in reference yet. Want to add them? Skills check this for congruence." |
| `core/offers/` exists | Multi-offer repo. Use a future `mb` JSON active-offer field if present. Otherwise ask which offer this research/decision is about; do not silently route from `.vip/local.yaml`. |
| Nothing in progress | "What are you trying to figure out?" |

**The goal is reference files.** Research and decisions are waypoints. Keep asking: "What needs to happen to get this into reference?"

---

## Full Flow (Default)

```
Research -> Checkpoint -> Decide -> Checkpoint -> Codify
```

### 1. Define Question

> "What specifically are you trying to figure out?"

### 2. Research

Gather from codebase, web, user input, local recordings.

**When research involves 2+ sources** (e.g., YouTube + web, X/Twitter + codebase, competitor mining + deep research), spawn parallel Task agents in a single message — one agent per source. Use `subagent_type: "general-purpose"` (has Write, Edit, Bash, MCP access). Each agent:
- Gets a focused prompt: one source, one research question
- Writes its own dated file (e.g., `research/YYYY-MM-DD-topic-yt-mining.md`)
- **Verifies the write:** checks the file exists after writing (use Read or ls)
- Returns: file path + write status + 5-bullet summary
- If write failed: returns the **full research content** so main conversation can write it
- Does NOT need the full business context — just the research question and source instructions

**After all agents return:** Check that files landed on disk. If any agent reported a write failure or the file doesn't exist, write it from the returned content. Then synthesize across summaries. This keeps heavy content out of your main context window while recovering gracefully from the known Claude Code subagent write persistence bug.

**Do NOT run research agents in background** (`run_in_background: true`) — background agents cannot access MCP tools (Apify, etc.) and cannot prompt for permissions.

**Mining sources:**

| Source | How | Output suffix |
|--------|-----|---------------|
| YouTube videos | Apify transcript MCP | `-yt-mining.md` |
| X/Twitter sentiment | Grok X Insights MCP ([grok-social.md](references/grok-social.md)) | `-x-social.md` |
| Local video/audio | whisper-cpp ([local-transcription.md](references/local-transcription.md)) | `-local-mining.md` |
| Voice memos | whisper-cpp | `-voice-mining.md` |
| Instagram mining | Apify or manual | `-ig-mining.md` |
| Ad account data | Verified Meta Ads account context | `-ad-account.md` |
| Competitor sites | Browser MCP or web fetch | `-competitor-mining.md` |
| Keyword gate | SERP/search sidecar, planner CSV, or WebSearch | `-keyword-gate.md` |
| Your own emails/DMs | Paste into conversation | `-internal-mining.md` |
| Deep research | Build prompt → Gemini/GPT | `-gemini.md` or `-gpt.md` |
| Codebase exploration | Grep, read, subagents | `-claude-code.md` |
| Documents (PDF, DOCX, PPTX) | markitdown / pandoc / marker ([document-ingestion.md](references/document-ingestion.md)) | `-doc-extraction.md` |

### 3. Synthesize (Required)

Every research output needs:
- One-sentence summary (20 words max)
- Key findings (5-10 bullets)
- Implications for reference files
- Open questions

Synthesis works best when the main conversation is clean — which is exactly what subagents provide. Heavy raw content (transcripts, mined posts) lives in the subagent context windows, and only distilled summaries return to main.

**For content mining specifically:** AI shows WHAT worked. You must judge WHY.

Extract three dimensions from mined content:
- **Visual** — Format, production style, patterns
- **Audible** — Energy, pacing, delivery
- **Emotional** — Primary emotion, identity play

**Framework extraction is human judgment work.** AI surfaces the data; you interpret the frameworks. This methodology comes from Koston Williams (6M view video) — the skill isn't copying, it's framework transfer. A competitor's content worked for THEM. Your job is to:

1. See the framework beneath the content
2. Judge whether it transfers to YOUR context
3. Adapt it to YOUR voice and audience
4. Codify what you learned into reference files

Don't skip to content generation. Mining → Human Synthesis → Reference Update → THEN Create.

### 4. Checkpoint

> "Ready to make a decision, or need more research?"

### 5. Decide

Present options with pros/cons. Document choice and rationale.

### 6. What Changes

Describe what reference files are affected in the decision file:

```markdown
## What Changes

offer.md gets a guarantee section after pricing. A new angle file (risk-reversal.md) captures the guarantee messaging.
```

See [decide-phase.md](references/decide-phase.md) for format details.

### 7. Checkpoint

> "Ready to update reference files now, or save for later?"

### 8. Codify

Apply changes described in `## What Changes` to reference files. Mark decision as codified.

**Codify targets include:** `core/*.md`, active offer/audience files, proof files, `core/content-strategy.md`, `core/marketing/...`, `core/people/...`, `core/operations/funnel/skool-surfaces.md`, `core/product-ladder.md`, and `bets/` only when updating the live wager or verdict. See [codify-phase.md](references/codify-phase.md) for layer-specific rules.

---

## Research Mode

```
/mb-think research "topic"
```

Output: `research/YYYY-MM-DD-topic-claude-code.md`

See [references/research-phase.md](references/research-phase.md) for full workflow.

For ad, customer, review, competitor, and social-comment mining, use
[references/winning-ad-research.md](references/winning-ad-research.md) to keep
the research structured before handing off to `/mb-ads` or `/mb-organic`.
For broad researched briefs that should feed ads, sites, organic content, or a
push playbook, use
[references/grok-8-brief-format.md](references/grok-8-brief-format.md) and set
`brief_format: grok-8` in frontmatter.

For offer-launch demand validation, use
[references/keyword-gate.md](references/keyword-gate.md). It writes a dated
keyword-gate research file with a Build / Build with caution / Kill verdict,
recommended lander cluster, ready-to-buy terms, and negative keyword seeds for
`/mb-site` and `/mb-ads`.

---

## Decide Mode

```
/mb-think decide "topic"
```

Output: `decisions/YYYY-MM-DD-topic.md`

See [references/decide-phase.md](references/decide-phase.md) for full workflow.

---

## Codify Mode

```
/mb-think codify decisions/YYYY-MM-DD-topic.md
```

Or: "/mb-think add new testimonials to my files"

See [references/codify-phase.md](references/codify-phase.md) for full workflow.

---

## Work Continuity Layers

| Layer | Scope | Use For |
|-------|-------|---------|
| **Claude tasks** | Session | Local execution steps and tool progress |
| **Decision files** | Durable | Rationale, options, chosen direction, what changes |
| **GitHub issues** | Durable | Work threads that need cross-session or team visibility |

Decision status is rationale maturity, not a general work-progress board:
`proposed` means a direction is drafted, `accepted` means the operator chose
it, and `codified` means the rationale has been integrated into durable
business or engine truth.

See [decide-phase.md](references/decide-phase.md) for decision lifecycle patterns.
See [recovery.md](references/recovery.md) for resuming sessions.

---

## Recovery

If conversation compacted, check multiple sources:

**1. Claude tasks (current session):**
```
TaskList
```

**2. Recent files and rationale state:**
```bash
ls -lt research/*.md 2>/dev/null | head -5
grep -l "status: proposed\|status: accepted" decisions/*.md 2>/dev/null
```

**3. GitHub issues (when durable work threads are needed):**
```bash
gh issue list --assignee @me --state open
```

Then confirm: "I see you were working on [topic]. Continue from here?"

See [references/recovery.md](references/recovery.md) for details.

---

## Templates

- [references/templates/research-template.md](references/templates/research-template.md)
- [references/grok-8-brief-format.md](references/grok-8-brief-format.md)
- [references/templates/decision-template.md](references/templates/decision-template.md)

---

## When NOT to Use

- Quick factual questions (just ask)
- Simple file edits (just edit)
- Generating content (use `/mb-ads`, `/mb-site`, `/mb-organic`)

Use `/mb-think` when the answer requires investigation and the choice needs documentation.

---

## Why This Matters

The repo is a precision instrument. The think cycle exists to filter — not to cram everything in. Research gets synthesized, decisions get distilled, and only the sharpest insights survive into reference. Curation over collection.

Reference files aren't just documentation. They're how you stay connected to why you do this.

Angles evolve. Each research session may surface a new emotional entry point, a new enemy to name, a new lifestyle aspiration. The angle library in `core/proof/angles/` is additive — it grows as understanding deepens. Treating angles as locked is an anti-pattern.

When AI makes information infinite, curation is the moat. The think cycle is curation in action — filtering signal from noise, codifying what matters, discarding what doesn't. Every reference file update is a curation decision.

The act of researching, deciding, and codifying forces you to articulate:
- **Why you do this** — Not the marketing reason. The real reason.
- **Who actually benefits** — Not demographics. Real people whose lives change.
- **What transformation you enable** — Not features. The before/after.

Research and decisions go stale. Reference files compound. Every update makes all downstream content better.

If the overlaps between your interests and your offer don't make sense, maybe you have the wrong offer. The think cycle should feel like pull, not push.
