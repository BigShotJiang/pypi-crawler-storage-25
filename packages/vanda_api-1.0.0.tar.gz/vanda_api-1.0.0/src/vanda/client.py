from typing import Optional

from vanda._base.base_client import BaseClient
from vanda.services.aggregates import AggregatesAPI
from vanda.services.series import SeriesAPI
from vanda.utils.deprecation import deprecated


class VandaClient(BaseClient):
    """
    Synchronous client for Vanda Analytics API.

    Example:
        with VandaClient(token="YOUR_TOKEN_HERE") as client:
            data = client.get_timeseries("TSLA", "2025-12-01", "2025-12-31", ["retail_net_turnover"])
    """
    def __init__(
        self,
        token: Optional[str] = None,
        email: Optional[str] = None,
        password: Optional[str] = None,
        base_url: str = "https://api.vanda-analytics.com",
        timeout: float = 600.0,
        max_retries: int = 3,
        cache_file: Optional[str] = None,
    ):
        """
        Initialize Vanda client.

        Args:
            token: API token. If None, reads from VANDA_API_TOKEN environment variable.
            email: Email for basic auth. If None, reads from VANDA_LOGIN_EMAIL environment variable.
            password: Password for basic auth. If None, reads from VANDA_PASSWORD environment variable.
            base_url: API base URL.
            timeout: Request timeout in seconds.
            max_retries: Maximum retry attempts.
            cache_file: Path to token cache file.

        Raises:
            AuthError: If token is not provided.
        """
        super().__init__(
            token,
            email,
            password,
            base_url,
            timeout,
            max_retries,
            cache_file,
        )

        self.series = SeriesAPI(self)
        self.aggregates = AggregatesAPI(self)


    def get_timeseries(self, *args, **kwargs):
        deprecated("client.get_timeseries", "client.series.get_timeseries")
        return self.series.get_timeseries(*args, **kwargs)

    def get_timeseries_many(self, *args, **kwargs):
        deprecated("client.get_timeseries_many", "client.series.get_timeseries_many")
        return self.series.get_timeseries_many(*args, **kwargs)

    def get_leaderboard(self, *args, **kwargs):
        deprecated("client.get_leaderboard", "client.series.get_leaderboard")
        return self.series.get_leaderboard(*args, **kwargs)

    def create_bulk_securities_job(self, *args, **kwargs):
        deprecated(
            "client.create_bulk_securities_job",
            "client.series.create_bulk_securities_job",
        )
        return self.series.create_bulk_securities_job(*args, **kwargs)

    def bulk_securities(self, *args, **kwargs):
        deprecated("client.bulk_securities", "client.series.bulk_securities")
        return self.series.bulk_securities(*args, **kwargs)

    def get_daily_snapshot(self, *args, **kwargs):
        deprecated("client.get_daily_snapshot", "client.series.get_daily_snapshot")
        return self.series.get_daily_snapshot(*args, **kwargs)

    def get_job(self, *args, **kwargs):
        deprecated("client.get_job", "client.series.get_job")
        return self.series.get_job(*args, **kwargs)

    def get_job_status(self, *args, **kwargs):
        deprecated("client.get_job_status", "client.series.get_job_status")
        return self.series.get_job_status(*args, **kwargs)

    def poll_job(self, *args, **kwargs):
        deprecated("client.poll_job", "client.series.poll_job")
        return self.series.poll_job(*args, **kwargs)

    def wait_for_job(self, *args, **kwargs):
        deprecated("client.wait_for_job", "client.series.wait_for_job")
        return self.series.wait_for_job(*args, **kwargs)

    def export_job_result(self, *args, **kwargs):
        deprecated("client.export_job_result", "client.series.export_job_result")
        return self.series.export_job_result(*args, **kwargs)

    def stream_job_result(self, *args, **kwargs):
        deprecated("client.stream_job_result", "client.series.stream_job_result")
        return self.series.stream_job_result(*args, **kwargs)

    def export_timeseries(self, *args, **kwargs):
        deprecated("client.export_timeseries", "client.series.export_timeseries")
        return self.series.export_timeseries(*args, **kwargs)

    def list_fields(self, *args, **kwargs):
        deprecated("client.list_fields", "client.series.list_fields")
        return self.series.list_fields(*args, **kwargs)

    def list_intervals(self, *args, **kwargs):
        deprecated("client.list_intervals", "client.series.list_intervals")
        return self.series.list_intervals(*args, **kwargs)

    def list_securities(self, *args, **kwargs):
        deprecated("client.list_securities", "client.series.list_securities")
        return self.series.list_securities(*args, **kwargs)
