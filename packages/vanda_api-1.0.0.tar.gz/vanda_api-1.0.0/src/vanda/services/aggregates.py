import logging
from datetime import date, datetime
from typing import Any, Union

from vanda.utils.dates import format_date, validate_date_range
from vanda.utils.normalize import normalize_result

logger = logging.getLogger(__name__)

class AggregatesAPI:

    def __init__(self, client):
        self._client = client

    def get_timeseries(
        self,
        aggregate_ids: str,
        start_date: Union[str, date, datetime],
        end_date: Union[str, date, datetime],
        interval: str = "1d",
        asset_class: str = "cash",
        records_per_page: int = 2000,
        page_number: int = 1,
        order: str = "asc",
        options_type: str = "ALL",
        options_notional: str = "ALL",
        options_moneyness: str = "TOTAL",
        options_size: str = "TOTAL",
    ) -> list[dict[str, Any]]:
        """
        Get timeseries data for a symbol.

        Args:
            aggregate_ids: Comma Seperated Aggregate ID's.
            start_date: Start date (YYYY-MM-DD or date object).
            end_date: End date (YYYY-MM-DD or date object).
            interval: Time interval (1d, 1w, 1m, etc).
            asset_class: "cash" or "options".
            records_per_page: Records per page (max 2000).
            page_number: Page number.
            order: "asc" or "desc".
            options_type: Options filter (ALL, CALL, PUT).
            options_notional: Options notional filter.
            options_moneyness: Options moneyness filter.
            options_size: Options size filter.

        Returns:
            List of records.

        Raises:
            ValidationError: If parameters are invalid.
        """
        if start_date:
            start_str = format_date(start_date)
        if end_date:
            end_str = format_date(end_date)

        if start_date and end_date:
            validate_date_range(start_str, end_str)

        params: dict[str, Any] = {
            "aggregate_ids": aggregate_ids,
            "interval": interval,
            "start_date": start_str,
            "end_date": end_str,
            "asset_class": asset_class,
            "records_per_page": records_per_page,
            "page_number": page_number,
            "order": order,
        }

        if asset_class == "options":
            params.update(
                {
                    "type": options_type,
                    "notional": options_notional,
                    "moneyness": options_moneyness,
                    "size": options_size,
                }
            )

        data = self._client._request("GET", "/aggregates/timeseries", params=params)

        return normalize_result(data)

    def get_constituents(self, vanda_id: str) -> list[dict[str, Any]]:
        """
        List available securities.

        Args:
            vanda_id: Vanda identifier

        Returns:
            List of constituents.
        """

        data = self._client._request("GET", f"/aggregates/reference/{vanda_id}/constituents")
        return normalize_result(data)
