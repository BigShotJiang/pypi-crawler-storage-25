import logging

import httpx

from vanda.auth import Auth
from vanda.errors import (
    AuthError,
)

logger = logging.getLogger(__name__)

class AsyncAuth(Auth):
    """Async-compatible authentication wrapper."""

    async def _check_entitlement_async(self, token: str) -> None:
        """
        Check token entitlement asynchronously.

        Args:
            token: Access token to check.

        Raises:
            AuthError: If entitlement check fails.
        """
        url = f"{self.base_url}/auth/get-entitlement"
        headers = {"Authorization": f"Bearer {token}"}

        try:
            async with httpx.AsyncClient(timeout=30.0) as client:
                response = await client.get(url, headers=headers)
                response.raise_for_status()
        except httpx.HTTPStatusError as e:
            if e.response.status_code == 401:
                raise AuthError("Invalid credentials") from e
            raise AuthError(f"Entitlement check failed: {e}") from e
        except Exception as e:
            raise AuthError(f"Entitlement check failed: {e}") from e

    async def _fetch_token_async(self) -> str:
        """
        Fetch token using basic authentication asynchronously.

        Returns:
            Access token.

        Raises:
            AuthError: If token fetch fails.
        """
        url = f"{self.base_url}/auth/basic"
        payload = {"email": self._email, "password": self._password}

        try:
            async with httpx.AsyncClient(timeout=30.0) as client:
                response = await client.post(url, json=payload)
                response.raise_for_status()
                data = response.json()

                access_token = data.get("access_token")
                expires_in = data.get("expires_in", 86400)

                if not access_token:
                    raise AuthError("No access token in response")

                # Check entitlement before caching
                await self._check_entitlement_async(access_token)

                self._token_cache.save(access_token, expires_in)
                return access_token

        except httpx.HTTPStatusError as e:
            if e.response.status_code == 401:
                raise AuthError("Invalid credentials") from e
            raise AuthError(f"Token fetch failed: {e}") from e
        except Exception as e:
            raise AuthError(f"Token fetch failed: {e}") from e

    async def get_token_async(self) -> str:
        """
        Get valid token asynchronously, refreshing if needed.

        Returns:
            Valid access token.
        """
        if self._auth_mode == "basic":
            cached_token = self._token_cache.load()
            if cached_token:
                self._token = cached_token
            else:
                self._token = await self._fetch_token_async()

        return self._token
