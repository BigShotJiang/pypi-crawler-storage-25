from typing import Optional

from vanda._base.async_base_client import AsyncBaseClient
from vanda.services.async_aggregates import AsyncAggregatesAPI
from vanda.services.async_series import AsyncSeriesAPI
from vanda.utils.deprecation import deprecated


class AsyncVandaClient(AsyncBaseClient):

    def __init__(
        self,
        token: Optional[str] = None,
        email: Optional[str] = None,
        password: Optional[str] = None,
        base_url: str = "https://api.vanda-analytics.com",
        timeout: float = 600.0,
        max_retries: int = 3,
        cache_file: Optional[str] = None,
    ):

        super().__init__(
            token,
            email,
            password,
            base_url,
            timeout,
            max_retries,
            cache_file,
        )

        self.series = AsyncSeriesAPI(self)
        self.aggregates = AsyncAggregatesAPI(self)

    async def get_timeseries(self, *args, **kwargs):
        deprecated("client.get_timeseries", "client.series.get_timeseries")
        return await self.series.get_timeseries(*args, **kwargs)

    async def get_timeseries_many(self, *args, **kwargs):
        deprecated("client.get_timeseries_many", "client.series.get_timeseries_many")
        return await self.series.get_timeseries_many(*args, **kwargs)

    async def get_leaderboard(self, *args, **kwargs):
        deprecated("client.get_leaderboard", "client.series.get_leaderboard")
        return await self.series.get_leaderboard(*args, **kwargs)

    async def create_bulk_securities_job(self, *args, **kwargs):
        deprecated(
            "client.create_bulk_securities_job",
            "client.series.create_bulk_securities_job",
        )
        return await self.series.create_bulk_securities_job(*args, **kwargs)

    async def bulk_securities(self, *args, **kwargs):
        deprecated("client.bulk_securities", "client.series.bulk_securities")
        return await self.series.bulk_securities(*args, **kwargs)

    async def get_daily_snapshot(self, *args, **kwargs):
        deprecated("client.get_daily_snapshot", "client.series.get_daily_snapshot")
        return await self.series.get_daily_snapshot(*args, **kwargs)

    async def get_job(self, *args, **kwargs):
        deprecated("client.get_job", "client.series.get_job")
        return await self.series.get_job(*args, **kwargs)

    async def get_job_status(self, *args, **kwargs):
        deprecated("client.get_job_status", "client.series.get_job_status")
        return await self.series.get_job_status(*args, **kwargs)

    async def poll_job(self, *args, **kwargs):
        deprecated("client.poll_job", "client.series.poll_job")
        return await self.series.poll_job(*args, **kwargs)

    async def wait_for_job(self, *args, **kwargs):
        deprecated("client.wait_for_job", "client.series.wait_for_job")
        return await self.series.wait_for_job(*args, **kwargs)

    async def export_job_result(self, *args, **kwargs):
        deprecated("client.export_job_result", "client.series.export_job_result")
        return await self.series.export_job_result(*args, **kwargs)

    async def stream_job_result(self, *args, **kwargs):
        deprecated("client.stream_job_result", "client.series.stream_job_result")
        return await self.series.stream_job_result(*args, **kwargs)

    async def export_timeseries(self, *args, **kwargs):
        deprecated("client.export_timeseries", "client.series.export_timeseries")
        return await self.series.export_timeseries(*args, **kwargs)

    async def list_fields(self, *args, **kwargs):
        deprecated("client.list_fields", "client.series.list_fields")
        return await self.series.list_fields(*args, **kwargs)

    async def list_intervals(self, *args, **kwargs):
        deprecated("client.list_intervals", "client.series.list_intervals")
        return await self.series.list_intervals(*args, **kwargs)

    async def list_securities(self, *args, **kwargs):
        deprecated("client.list_securities", "client.series.list_securities")
        return await self.series.list_securities(*args, **kwargs)
