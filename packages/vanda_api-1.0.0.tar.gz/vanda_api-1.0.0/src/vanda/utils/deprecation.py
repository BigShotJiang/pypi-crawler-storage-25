import logging
import warnings


def deprecated(old: str, new: str):

    message = f"{old}() is deprecated. Use {new}() instead."
    logging.getLogger(__name__).warning(message)
    warnings.warn(message, DeprecationWarning, stacklevel=2)
