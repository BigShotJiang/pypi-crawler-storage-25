import logging
import time
from typing import Any, Optional

import httpx

from vanda.async_auth import AsyncAuth
from vanda.errors import (
    AuthError,
    NotFoundError,
    RateLimitError,
    ServerError,
    ValidationError,
    VandaError,
)
from vanda.retry import async_retry_request

logger = logging.getLogger(__name__)

class AsyncBaseClient:

    def __init__(
        self,
        token: Optional[str] = None,
        email: Optional[str] = None,
        password: Optional[str] = None,
        base_url: str = "https://api.vanda-analytics.com",
        timeout: float = 600.0,
        max_retries: int = 3,
        cache_file: Optional[str] = None,
    ):
        """
        Initialize async base client.

        Args:
            token: API token. If None, reads from VANDA_API_TOKEN environment variable.
            email: Email for basic auth. If None, reads from VANDA_LOGIN_EMAIL environment variable.
            password: Password for basic auth. If None, reads from VANDA_PASSWORD environment variable.
            base_url: API base URL.
            timeout: Request timeout in seconds.
            max_retries: Maximum retry attempts.
            cache_file: Path to token cache file.

        Raises:
            AuthError: If token is not provided.
        """

        self.auth = AsyncAuth(
            token=token, email=email, password=password, base_url=base_url, cache_file=cache_file
        )
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        self.max_retries = max_retries
        self._client: Optional[httpx.AsyncClient] = None

    async def __aenter__(self):
        """Async context manager entry."""
        self._client = httpx.AsyncClient(
            base_url=self.base_url,
            headers=self.auth.get_headers(),
            timeout=self.timeout,
        )

        return self

    async def __aexit__(self, *args):
        """Async context manager exit."""
        await self.close()

    async def close(self):

        if self._client:
            await self._client.aclose()

    @property
    def client(self):
        """Get HTTP client, creating if necessary."""
        if self._client is None:

            self._client = httpx.AsyncClient(
                base_url=self.base_url,
                headers=self.auth.get_headers(),
                timeout=self.timeout,
            )

        return self._client
    async def _refresh_client_headers(self) -> None:
        """Refresh client headers with updated token."""
        if self._client:
            token = await self.auth.get_token_async()
            self._client.headers.update({"Authorization": f"Bearer {token}"})

    async def _request(
        self,
        method: str,
        path: str,
        params: Optional[dict[str, Any]] = None,
        json: Optional[dict[str, Any]] = None,
    ) -> Any:

        """
        Make async HTTP request with retry logic.

        Args:
            method: HTTP method.
            path: Request path.
            params: Query parameters.
            json: JSON body.

        Returns:
            Response JSON data.

        Raises:
            VandaError: On error.
        """

        start_time = time.time()
        await self._refresh_client_headers()

        async def _do_request() -> Any:
            logger.debug(
                "http_request method=%s path=%s headers=%s",
                method,
                path,
                self.auth.get_headers_safe(),
            )
            response = await self.client.request(method, path, params=params, json=json)
            if response.status_code >= 400:
                response.raise_for_status()
            return response

        try:
            response = await async_retry_request(_do_request, max_retries=self.max_retries)
            latency = time.time() - start_time
            logger.info(
                "http_success method=%s path=%s status=%d latency=%.3f",
                method,
                path,
                response.status_code,
                latency,
            )
            return response.json()
        except httpx.HTTPStatusError as e:
            latency = time.time() - start_time
            logger.error(
                "http_error method=%s path=%s status=%d latency=%.3f",
                method,
                path,
                e.response.status_code,
                latency,
            )
            self._handle_error(e.response)

    async def _request_stream(
        self,
        method: str,
        path: str,
        params: Optional[dict[str, Any]] = None,
    ) -> bytes:
        """
        Make async streaming HTTP request.

        Args:
            method: HTTP method.
            path: Request path.
            params: Query parameters.

        Returns:
            Response content as bytes.

        Raises:
            VandaError: On error.
        """
        start_time = time.time()
        await self._refresh_client_headers()

        async def _do_request() -> httpx.Response:
            response = await self.client.request(method, path, params=params)
            if response.status_code >= 400:
                response.raise_for_status()
            return response

        try:
            response = await async_retry_request(_do_request, max_retries=self.max_retries)
            latency = time.time() - start_time
            logger.info(
                "http_stream_success method=%s path=%s status=%d latency=%.3f size_kb=%.2f",
                method,
                path,
                response.status_code,
                latency,
                len(response.content) / 1024,
            )
            return response.content
        except httpx.HTTPStatusError as e:
            latency = time.time() - start_time
            logger.error(
                "http_error method=%s path=%s status=%d latency=%.3f",
                method,
                path,
                e.response.status_code,
                latency,
            )
            self._handle_error(e.response)
            raise

    def _handle_error(self, response: httpx.Response):
        """
        Handle HTTP error responses.

        Args:
            response: HTTP response.

        Raises:
            VandaError: Appropriate exception based on status code.
        """
        status_code = response.status_code
        request_id = response.headers.get("x-request-id")

        try:
            body = response.json()
            detail = body.get("detail", response.text)
        except Exception:
            detail = response.text
            body = None

        if status_code in (401, 403):
            raise AuthError(
                f"Authentication failed: {detail}",
                status_code=status_code,
                request_id=request_id,
                response_body=body,
            )

        if status_code == 404:
            raise NotFoundError(
                f"Resource not found: {detail}",
                status_code=status_code,
                request_id=request_id,
                response_body=body,
            )

        if status_code == 422:
            raise ValidationError(
                f"Validation error: {detail}",
                status_code=status_code,
                request_id=request_id,
                response_body=body,
            )

        if status_code == 429:
            retry_after = response.headers.get("retry-after")
            retry_after_int = int(retry_after) if retry_after else None
            raise RateLimitError(
                f"Rate limit exceeded: {detail}",
                retry_after=retry_after_int,
                status_code=status_code,
                request_id=request_id,
                response_body=body,
            )

        if status_code >= 500:
            raise ServerError(
                f"Server error: {detail}",
                status_code=status_code,
                request_id=request_id,
                response_body=body,
            )

        raise VandaError(
                f"HTTP {status_code}: {detail}",
                status_code=status_code,
                request_id=request_id,
                response_body=body,
            )
