
import httpx
import pytest
import respx

from vanda import AsyncVandaClient, AuthError


@pytest.fixture
async def client() -> AsyncVandaClient:
    """Create test async client."""
    return AsyncVandaClient(token="test_token", base_url="https://api.test.com")


@pytest.mark.asyncio
@respx.mock
async def test_get_timeseries_success(client: AsyncVandaClient) -> None:
    """Test successful async timeseries request."""
    mock_data = {"data": [{"ts": "2025-12-01", "id": 2000001}]}
    respx.get("https://api.test.com/aggregates/timeseries").mock(
        return_value=httpx.Response(200, json=mock_data)
    )

    result = await client.aggregates.get_timeseries(
        "2000001", "2025-12-01", "2025-12-31"
    )
    assert len(result) == 1
    assert result[0]["ts"] == "2025-12-01"


@pytest.mark.asyncio
@respx.mock
async def test_get_timeseries_auth_error(client: AsyncVandaClient) -> None:
    """Test auth error in async client."""
    respx.get("https://api.test.com/aggregates/timeseries").mock(
        return_value=httpx.Response(401, json={"detail": "Unauthorized"})
    )

    with pytest.raises(AuthError):
        await client.aggregates.get_timeseries("2000001", "2025-12-01", "2025-12-31")


@pytest.mark.asyncio
@respx.mock
async def test_get_constituents(client: AsyncVandaClient) -> None:
    """Test async get constituents."""
    mock_data = {"aggregate_id": 2000001,"vanda_id": "VNDA2000001","constituent_ids": [1014028],"count": 1}
    respx.get("https://api.test.com/aggregates/reference/VNDA2000001/constituents").mock(
        return_value=httpx.Response(200, json=mock_data)
    )

    result = await client.aggregates.get_constituents("VNDA2000001")
    assert len(result) == 1
