
import httpx
import pytest
import respx

from vanda import AuthError, ValidationError, VandaClient


@pytest.fixture
def client() -> VandaClient:
    """Create test client."""
    return VandaClient(token="test_token", base_url="https://api.test.com")


@respx.mock
def test_get_timeseries_success(client: VandaClient) -> None:
    """Test successful timeseries request."""
    mock_data = {"data": [{"ts": "2025-12-01", "id": 2000001}]}
    respx.get("https://api.test.com/aggregates/timeseries").mock(
        return_value=httpx.Response(200, json=mock_data)
    )

    result = client.aggregates.get_timeseries(
        "2000001", "2025-12-01", "2025-12-31"
    )
    assert len(result) == 1
    assert result[0]["ts"] == "2025-12-01"


@respx.mock
def test_get_timeseries_validation_error(client: VandaClient) -> None:
    """Test validation error."""
    with pytest.raises(ValidationError):
        client.aggregates.get_timeseries("2000001", "2025-12-31", "2025-12-01")


@respx.mock
def test_get_timeseries_auth_error(client: VandaClient) -> None:
    """Test auth error."""
    respx.get("https://api.test.com/aggregates/timeseries").mock(
        return_value=httpx.Response(401, json={"detail": "Unauthorized"})
    )

    with pytest.raises(AuthError):
        client.aggregates.get_timeseries("2000001", "2025-12-01", "2025-12-31")


@respx.mock
def test_get_constituents(client: VandaClient) -> None:
    """Test async get constituents."""
    mock_data = {"aggregate_id": 2000001,"vanda_id": "VNDA2000001","constituent_ids": [1014028],"count": 1}
    respx.get("https://api.test.com/aggregates/reference/VNDA2000001/constituents").mock(
        return_value=httpx.Response(200, json=mock_data)
    )

    result = client.aggregates.get_constituents("VNDA2000001")
    assert len(result) == 1
