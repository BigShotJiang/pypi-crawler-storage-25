# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [1.0.0] - 2026-03-26

### Added

- Moved API methods under namespaces: 
    - client.get_timeseries() to client.series.get_timeseries()
    - client.get_timeseries_many to client.series.get_timeseries_many()
    - client.get_leaderboard to client.series.get_leaderboard()
    - client.create_bulk_securities_job to client.series.create_bulk_securities_job()
    - client.bulk_securities to client.series.bulk_securities()
    - client.get_daily_snapshot to client.series.get_daily_snapshot()
    - client.get_job to client.series.get_job()
    - client.get_job_status to client.series.get_job_status()
    - client.poll_job to client.series.poll_job()
    - client.wait_for_job to client.series.wait_for_job()
    - client.export_job_result to client.series.export_job_result()
    - client.stream_job_result to client.series.stream_job_result()
    - client.export_timeseries to client.series.export_timeseries()
    - client.list_fields to client.series.list_fields()
    - client.list_intervals to client.series.list_intervals()
    - client.list_securities to client.series.list_securities()
- Old methods still work but are deprecated.
- Added new endpoints for aggregates timeseries and constituents
- Refactored code to make use of common functions in series and aggregates endpoints
- Updated unit test cases with new changes for calling the endpoints
- Updated examples file to use series and aggregates endpoints


## [0.1.1] - 2026-02-20

### Added

- Email/password authentication support with automatic token caching
- Token cache with expiration management in `~/.vanda/token_cache.json`
- Entitlement validation on authentication
- Support for `VANDA_LOGIN_EMAIL` and `VANDA_PASSWORD` environment variables
- Async authentication methods in `AsyncAuth` class

### Fixed

- Fixed `asset_class` parameter format in bulk operations (now sent as list)
- Fixed async authentication to include entitlement check

## [0.1.0] - 2024-02-06

### Added

- Initial release
- Synchronous VandaClient
- Asynchronous AsyncVandaClient
- All 12 API endpoints implemented
- Retry logic with exponential backoff
- Comprehensive error handling
- Job polling utilities
- CSV/JSONL export support
- Optional pandas support
- Type hints throughout
- Full test coverage
- CI/CD with GitHub Actions
