"""Gedeelde classes voor zowel de POEMA als OHS import."""

from collections import defaultdict
from datetime import datetime
from enum import auto
from pathlib import Path
from uuid import UUID, uuid4

import openpyxl
import raplan
from beartype.typing import Any, Generator
from openpyxl.cell.cell import Cell
from openpyxl.workbook.workbook import Workbook
from openpyxl.worksheet.worksheet import Worksheet
from raplan.excel import (
    _CELL_VALUE_CONVERSION,
    _decode_uuid,
    _empty_workbook,
    _encode_uuid,
    _resolve_value,
    _set_auto_width,
    _set_table_style,
)
from raplan.utils import (
    gen_dataclass_columns,
    gen_dataclass_types,
    gen_dataclass_values,
)
from serde import InternalTagging, field, serde
from strenum import PascalCaseStrEnum

from raplan_rws.utils import extract_comp_code, extract_disk_code


@serde(tagging=InternalTagging("type"))
class BeheerObject:
    """Gegevens met betrekking op een beheerobject van Rijkswaterstaat."""

    code: str
    """Beheerobject code."""

    naam: str
    """Beheerobject naam."""

    def __post_init__(self) -> None:
        self.code = extract_disk_code(self.code) or self.code

    def __hash__(self) -> int:
        return hash((self.code, self.naam))

    @property
    def complex_code(self) -> str:
        """Complex code, i.e. de eerste twee delen van de DISK code."""
        return extract_comp_code(self.code)


class Discipline(PascalCaseStrEnum):
    """Disciplines die betrokken is bij de uitvoering van een maatregel of maatregelpakket."""

    Algemeen = auto()
    Civiel = auto()
    Elektrotechniek = auto()
    Werktuigbouw = auto()
    IndustriëleAutomatisering = auto()
    CyberSecurity = auto()

    def __hash__(self) -> int:
        return hash(str(self))

    @classmethod
    def auto(cls, string: str) -> "set[Discipline]":
        try:
            dis = {Discipline(string.replace(" ", ""))}
        except ValueError:
            dis = set()
            for s in string.split("-"):
                s = s.lower().strip()
                if s == "geen faalwijzen":
                    continue
                if s == "elektro":
                    dis.add(Discipline.Elektrotechniek)
                elif "indust" in s or "auto" in s or s == "ia":
                    dis.add(Discipline.IndustriëleAutomatisering)
                else:
                    dis.add(Discipline(s.capitalize()))
        return dis

    @classmethod
    def van_element_bouwdeel(cls, element_bouwdeel: "ElementBouwdeel") -> "set[Discipline]":
        dis = set()
        element = element_bouwdeel.element.lower()
        bouwdeel = element_bouwdeel.bouwdeel.lower()

        if "hydraulisch aggregaat" in bouwdeel:
            dis.add(Discipline.Elektrotechniek)
            dis.add(Discipline.Werktuigbouw)

        elif (
            "pomp" in element
            or "ijsbestrijdingssysteem" in element
            or bouwdeel == "afdrukwielen"
            or bouwdeel == "vangdeur"
            or bouwdeel == "pompinstallatie"
            or "brandblus" in bouwdeel
        ):
            dis.add(Discipline.Werktuigbouw)

        elif (
            "aandrijving" in element
            or "aandrijving" in bouwdeel
            or "bewegingswerk" in element
            or "bewegingswerk" in bouwdeel
        ):
            if (
                "elektro" in element
                or "elektro" in bouwdeel
                or "frequentieomvormer" in bouwdeel
                or "frequentieregeling" in bouwdeel
                or "schakelaar" in bouwdeel
                or "scheefstand" in bouwdeel
                or "detectie" in bouwdeel
            ):
                dis.add(Discipline.Elektrotechniek)
            else:
                dis.add(Discipline.Werktuigbouw)

        elif (
            "spanning" in element
            or "spanning" in bouwdeel
            or "aarding" in element
            or "aarding" in bouwdeel
            or "bedienings- en besturingssysteem" in element
            or "verlichting" in element
            or "verlichting" in bouwdeel
            or "bedieningslessenaar" in bouwdeel
            or "armatuur" in bouwdeel
            or "bekabeling" in bouwdeel
            or "cctv" in element
            or "cctv" in bouwdeel
            or "marifoon" in element
            or "marifoon" in bouwdeel
            or "niveaumeetinstallatie" in element
            or "opnemer" in bouwdeel
            or "noodstroom" in element
            or "noodstroom" in bouwdeel
            or "installatie" in element
            or "installatie" in bouwdeel
            or "generator" in element
            or "generator" in bouwdeel
            or "beseining" in element
            or "beseining" in bouwdeel
        ):
            dis.add(Discipline.Elektrotechniek)

        elif (
            "gebouw" in element
            or "gebouw" in bouwdeel
            or "afmeervoorziening" in element
            or ("heftoren" in element and "algemeen" in bouwdeel)
            or ("deur" in element and "hefdeur" in bouwdeel)
            or ("kolk" in element and "wand" in bouwdeel)
            or ("geleiderail" in element and "geleiderail" in bouwdeel)
            or ("voegovergang" in element and "algemeen" in bouwdeel)
            or ("hoofddraagconstructie" in element and "algemeen" in bouwdeel)
            or "deurgeleiding" in bouwdeel
            or "ladder" in element
            or "ladder" in bouwdeel
            or "leuning" in element
            or "leuning" in bouwdeel
            or "constructie" in element
            or "constructie" in bouwdeel
            or "slijtlaag" in element
            or "slijtlaag" in bouwdeel
            or "hekwerk" in element
            or "oplegging" in element
            or "wegtype" in element
            or "wegtype" in bouwdeel
            or "steunpunt" in element
            or "steunpunt" in bouwdeel
            or "doorlaatkoker" in element
            or "doorlaatkoker" in bouwdeel
            or "bodembescherming" in element
            or "bodembescherming" in bouwdeel
            or "hemelwater" in element
            or "hemelwater" in bouwdeel
            or "sluiswand" in element
            or "sluiswand" in bouwdeel
            or "schamp" in element
            or "schamp" in bouwdeel
            or "gebouw" in element
            or "gebouw" in bouwdeel
            or "oplegging" in element
            or "oplegging" in bouwdeel
            or "hekwerk" in element
            or "hekwerk" in bouwdeel
            or "redding" in element
            or "redding" in bouwdeel
            or "voegovergang" in element
            or "voegovergang" in bouwdeel
        ):
            dis.add(Discipline.Civiel)

        elif (
            "algemeen" in element
            or "algemeen" in bouwdeel
            or "inspectie" in element
            or "inspectie" in bouwdeel
        ):
            dis.add(Discipline.Algemeen)

        if (
            "bediening" in element
            or "bediening" in bouwdeel
            or "besturing" in element
            or "besturing" in bouwdeel
        ):
            dis.add(Discipline.IndustriëleAutomatisering)

        if not dis:
            raise ValueError(
                "Kon geen disciplines afleiden van element naam "
                f"{element_bouwdeel.element} - {element_bouwdeel.bouwdeel}"
            )

        return dis


@serde(tagging=InternalTagging("type"))
class ElementBouwdeel:
    """Gegevens met betrekking op een element/bouwdeel van een beheerobject van Rijkswaterstaat."""

    element: str
    """Naam van het element."""

    bouwdeel: str
    """Naam van het bouwdeel van het element."""

    def __str__(self) -> str:
        return f"{self.element} - {self.bouwdeel}"

    def __eq__(self, other) -> bool:
        if not isinstance(other, ElementBouwdeel):
            return NotImplemented
        return self.element == other.element and self.bouwdeel == other.bouwdeel

    def __hash__(self) -> int:
        return hash((self.element, self.bouwdeel))

    def __lt__(self, other) -> bool:
        if not isinstance(other, ElementBouwdeel):
            return NotImplemented
        return (self.element, self.bouwdeel) < (other.element, other.bouwdeel)


@serde(tagging=InternalTagging("type"))
class FunctieImpact:
    """Beschrijving van de betrokkenheid van een element-bouwdeel op één van de objectfuncties."""

    faciliteren_vaarweg_verkeer: bool
    """Faciliteren vaarwegverkeer en kruisen omgeving (functie)."""

    hoogwater_afvoeren: bool
    """Hoogwater afvoeren op meren en kanalen (functie)."""

    faciliteren_wegverkeer: bool
    """Faciliteren wegverkeeer (functie)."""

    water_keren: bool
    """Water keren (functie)."""

    vgm: bool
    """Of de maatregel leidt tot een beperking van de risico's wat betreft
    Veiligheid, Gezondheid en Milieu."""

    secundaire_functies: bool
    """Of de maatregel impact heeft op de secundaire functies van het object."""

    def __add__(self, other: "FunctieImpact") -> "FunctieImpact":
        return FunctieImpact(
            faciliteren_vaarweg_verkeer=self.faciliteren_vaarweg_verkeer
            or other.faciliteren_vaarweg_verkeer,
            faciliteren_wegverkeer=self.faciliteren_wegverkeer or other.faciliteren_wegverkeer,
            hoogwater_afvoeren=self.hoogwater_afvoeren or other.hoogwater_afvoeren,
            water_keren=self.water_keren or other.water_keren,
            vgm=self.vgm or other.vgm,
            secundaire_functies=self.secundaire_functies or other.secundaire_functies,
        )

    def __iadd__(self, other: "FunctieImpact") -> "FunctieImpact":
        self.faciliteren_vaarweg_verkeer = (
            self.faciliteren_vaarweg_verkeer or other.faciliteren_vaarweg_verkeer
        )
        self.hoogwater_afvoeren = self.hoogwater_afvoeren or other.hoogwater_afvoeren
        self.faciliteren_wegverkeer = self.faciliteren_wegverkeer or other.faciliteren_wegverkeer
        self.water_keren = self.water_keren or other.water_keren
        self.vgm = self.vgm or other.vgm
        self.secundaire_functies = self.secundaire_functies or other.secundaire_functies
        return self

    @classmethod
    def geen(cls) -> "FunctieImpact":
        """Maak een lege functie impact aan."""
        return FunctieImpact(False, False, False, False, False, False)


@serde(tagging=InternalTagging("type"))
class FunctieVerlies:
    """Beschrijving van het functieverlies van een maatregel in [0.0-1.0] waarbij 1.0 staat
    voor 100% functieverlies."""

    faciliteren_vaarweg_verkeer: float
    """Faciliteren vaarwegverkeer en kruisen omgeving (functie)."""

    hoogwater_afvoeren: float
    """Hoogwater afvoeren op meren en kanalen (functie)."""

    faciliteren_wegverkeer: float
    """Faciliteren wegverkeeer (functie)."""

    water_keren: float
    """Water keren (functie)."""

    vgm: float
    """Of de maatregel leidt tot een beperking van de risico's wat betreft
    Veiligheid, Gezondheid en Milieu."""

    secundaire_functies: float
    """Of de maatregel impact heeft op de secundaire functies van het object."""

    @classmethod
    def volledig(cls, impact: FunctieImpact) -> "FunctieVerlies":
        """Maak een volledig functieverlies aan op basis van de impact van het betreffende
        element-bouwdeel van het onderhoud."""
        return cls(
            faciliteren_vaarweg_verkeer=float(impact.faciliteren_vaarweg_verkeer),
            hoogwater_afvoeren=float(impact.hoogwater_afvoeren),
            faciliteren_wegverkeer=float(impact.faciliteren_wegverkeer),
            water_keren=float(impact.water_keren),
            vgm=float(impact.vgm),
            secundaire_functies=float(impact.secundaire_functies),
        )

    @classmethod
    def geen(cls) -> "FunctieVerlies":
        """Maak een lege functie impact aan."""
        return FunctieVerlies(0.0, 0.0, 0.0, 0.0, 0.0, 0.0)


@serde(tagging=InternalTagging("type"))
class ObjectStructuur:
    """Structuur van beheerobjecten: hun bouwdelen/elementen.

    Attributes:
        element_bouwdelen: Set van element-bouwdelen in een object.
        disciplines: Set van herkende disciplines per element-bouwdeel in een object.
        impacts: De element-functie mapping voor een object.
    """

    element_bouwdelen: set[ElementBouwdeel] = field(default_factory=set)
    disciplines: defaultdict[ElementBouwdeel, set[Discipline]] = field(
        default_factory=lambda: defaultdict(set)
    )
    impacts: defaultdict[ElementBouwdeel, FunctieImpact] = field(
        default_factory=lambda: defaultdict(FunctieImpact.geen)
    )


@serde(tagging=InternalTagging("type"))
class GeplandeMaatregel:
    """Geplande maatregel inclusief origine."""

    referentie_nummer: str
    """POEMA referentie nummer."""

    beheerobject: BeheerObject
    """Beheerobject waarop deze maatregel van toepassing is."""

    element: str
    """Element waarop deze maatregel van toepassing is."""

    bouwdeel: str
    """Buwdeel waarop deze maatregel van toepassing is."""

    pakket_id: str | None
    """Identificatie voor een maatregelpakket."""

    maatregel: str
    """Naam van de maatregel."""

    disciplines: set[Discipline]
    """Disciplines met betrekking op het element."""

    gepland_uitvoeringsjaar: int
    """Het geprogrammeerd uitvoeringsjaar op basis van maakbaarheid van de geclusterde maatregelen
    en maatregelpakketten."""

    gepland_uitvoeringsjaar_reden: str
    """De reden voor de laatst gemaakte planningswijziging."""

    gewenst_uitvoeringsjaar: int
    """Gewenst uitvoeringsjaar op basis van logische clustering van de maatregelen."""

    advies_plan_jaar: int
    """Het optimale vervangjaar van de specifieke maatregel volgens het ingeladen scenario."""

    uiterst_advies_jaar: int
    """Het uiterste vervangjaar van de specifieke maatregel volgens het ingeladen scenario."""

    kan_later_dan_uiterst: bool
    """Of het uiterste advies jaar kan worden overschreden."""

    impact: FunctieImpact
    """Beschrijving van de betrokkenheid van een element-bouwdeel op één van de objectfuncties."""

    verlies: FunctieVerlies
    """Beschrijving van het functieverlies van een maatregel in [0.0-1.0]."""

    raming_incl: float
    """Raming incl. BTW (gebaseerd op expert judgement, DISK, kosten vanuit vorige projecten, hulp
    van de kostenpool etc.)"""

    periode: float | None
    """Lengte van de periode voor deze maatregel indien het een herhalende preventieve
    maatregel betreft."""

    uuid: UUID = field(default_factory=uuid4)
    """RaPlan-RWS unieke identifier."""

    @property
    def element_bouwdeel(self) -> ElementBouwdeel:
        """Element-bouwdeel combi waar deze maatregel van toepassing op is."""
        return ElementBouwdeel(element=self.element, bouwdeel=self.bouwdeel)

    def frequentie(self) -> float:
        """Frequentie van deze maatregel (1.0 / periode) in keren per jaar.

        Omgekeerd evenredig afhankelijk van de herhalingsperiode van gepland onderhoud.
        Wanneer het onderhoud geen periode heeft of een periode van 0, dan is defrequentie ook nul.
        """
        if self.periode is None or self.periode == 0.0:
            return 0.0
        return 1.0 / self.periode

    def time(self, start: int) -> int:
        """Geplande tijd van deze maatregel t.o.v. de horizon start."""
        return self.gepland_uitvoeringsjaar - start

    def window(
        self,
        start: int,
        vervroeging_factor: float = 0.25,
        later_dan_uiterst_bonus: int = 1,
        bevries_verleden: bool = True,
    ) -> raplan.Window:
        """Het afgeleide window in de tijd waarin deze maatregel mag worden gepland.

        Arguments:
            start: Startjaar van de planningshorizon. Alle latere jaartallen zijn delta's
                ten opzichte van deze waarde.
            vervroeging_factor: Hoeveel eerder een taak naar voren mag worden gehaald t.o.v. de
                afstand tussen het advies plan jaar en het uiterst advies jaar.
            later_dan_uiterst_bonus: Hoeveel jaar het uitstel mag worden opgerekt als
                het `kan_later_dan_uiterst` veld waar is.
            bevries_verleden: Of in het verleden geplande maatregelen moeten worden vastgezet.

        Returns:
            Window met de gevonden begrenzingen.

        Note:
            Het wordt als volgt berekend:

            - Het `advies_plan_jaar` wordt als `initial` gebruikt voor het `Window`.
            - Het regulier uitstel wordt berekend als de maximale waarde van `advies_plan_jaar` of
              `uiterst_advies_jaar` minus het `advies_plan_jaar`.
            - De maximale vervroeging `max_rush` wordt als *de helft* van dit regulier uitstel
              aangenomen.
            - Het maximale uitstel `max_post` is het regulier uitstel plus een bonus factor als die
              mag worden toegekend op basis van `kan_later_dan_uiterst`.
        """
        if bevries_verleden and self.gepland_uitvoeringsjaar < 0:
            return raplan.Window.new_immovable(self.gepland_uitvoeringsjaar)

        advies = self.advies_plan_jaar - start

        # Reguliere "laatste" tijd.
        laatst: int = max(self.advies_plan_jaar, self.uiterst_advies_jaar) - start
        uitstel = laatst - advies
        vervroeging = int(vervroeging_factor * uitstel)

        bonus = self.kan_later_dan_uiterst * later_dan_uiterst_bonus

        return raplan.Window(
            initial=advies,
            max_rush=vervroeging,
            max_post=uitstel + bonus,
        )

    def valt_binnen_horizon(self, horizon: raplan.Horizon) -> bool:
        """Of deze maatregel (deels) binnen de horizon valt."""
        return (
            horizon.is_satisfied_by(self.advies_plan_jaar)
            or horizon.is_satisfied_by(self.uiterst_advies_jaar)
            or horizon.is_satisfied_by(self.gepland_uitvoeringsjaar)
            or horizon.is_satisfied_by(self.gewenst_uitvoeringsjaar)
        )


@serde(tagging=InternalTagging("type"))
class MaatregelPlanning:
    """Geplande maatregelen over de tijd."""

    maatregelen: list[GeplandeMaatregel] = field(default_factory=list)
    """Lijst van geplande maatregelen."""

    def __len__(self) -> int:
        return len(self.maatregelen)

    def __iter__(self) -> Generator[GeplandeMaatregel, None, None]:
        yield from self.maatregelen

    def naar_excel_bestand(self, path: str | Path | None = None) -> Workbook:
        """Convert this to an Excel workbook."""
        wb = _maak_maatregelplanning_excel(self)
        if path is not None:
            wb.save(path)
        return wb

    def horizon(self) -> raplan.Horizon:
        """Leidt een horizon af van de maatregelen in de planning of maak een horizon op alleen dit
        jaar.
        """
        if self.maatregelen:
            first = self.maatregelen[0]
            start, end = first.gepland_uitvoeringsjaar, first.gepland_uitvoeringsjaar + 1

            for m in self.maatregelen[1:]:
                start = min(start, m.gepland_uitvoeringsjaar)
                end = max(end, m.gepland_uitvoeringsjaar + 1)
        else:
            start = datetime.today().year
            end = None
        return raplan.Horizon(start, end)

    def pas_horizon_toe(self, horizon: raplan.Horizon):
        """Pas een horizon filtering toe op deze planning."""
        self.maatregelen: list[GeplandeMaatregel] = [
            m for m in self.maatregelen if m.valt_binnen_horizon(horizon)
        ]

    def objecten_structuren(self) -> dict[str, tuple[BeheerObject, ObjectStructuur]]:
        """Leid een dictionary af van DISK code naar beheerobject-omschrijvingen en hun
        objectstructuren.
        """
        result: dict[str, tuple[BeheerObject, ObjectStructuur]] = dict()

        for m in self.maatregelen:
            disk = m.beheerobject.code
            if m.beheerobject.code not in result:
                result[disk] = (m.beheerobject, ObjectStructuur())
            structuur: ObjectStructuur = result[disk][1]
            eb = m.element_bouwdeel
            structuur.element_bouwdelen.add(eb)
            structuur.disciplines[eb].update(m.disciplines)
            structuur.impacts[eb] += m.impact

        return result

    @classmethod
    def van_excel_bestand(cls, path: str | Path) -> "MaatregelPlanning":
        """Laad een maatregel planning terug in vanaf een Excelbestand."""
        wb: Workbook = openpyxl.load_workbook(path)
        ws = wb.worksheets[0]
        assert isinstance(ws, Worksheet)

        maatregelen = []

        kolommen = {_resolve_value(wb, c): i for i, c in enumerate(ws[1]) if isinstance(c, Cell)}
        types = {k: v for k, v in gen_dataclass_types(GeplandeMaatregel)}
        discipline_kolommen = {d: f"disciplines_{d.lower()}" for d in Discipline}
        impact_kolommen = {k[7:]: k for k in kolommen if k.startswith("impact_")}
        conversions = {
            k: _CELL_VALUE_CONVERSION.get(v, lambda x: x)
            for k, v in types.items()
            if k not in discipline_kolommen and k not in impact_kolommen
        }

        def extract(
            row: tuple[Cell, ...],
            key: str,
            is_uuid: bool = False,
            is_bool: bool = False,
            default: Any = None,
        ) -> Any:
            try:
                kolom = kolommen[key]
            except KeyError:
                return default

            try:
                cell = row[kolom]
            except IndexError:
                return default

            value = _resolve_value(wb, cell)

            if is_uuid:
                return _decode_uuid(value)

            if is_bool:
                if isinstance(value, bool):
                    return value
                elif isinstance(value, str):
                    return value.upper().strip() == "TRUE" or value.upper().strip() == "X"
                else:
                    return bool(value)

            if not value:
                return default

            try:
                return conversions[key](value)
            except KeyError:
                return default

        for r in range(2, ws.max_row + 1):
            row: tuple[Cell, ...] = ws[r]

            beheerobject = BeheerObject(
                code=extract(row, "beheerobject_code"),
                naam=extract(row, "beheerobject_naam"),
            )

            disciplines = set()
            for d, key in discipline_kolommen.items():
                if extract(row, key, is_bool=True, default=False):
                    disciplines.add(d)

            impact = FunctieImpact.geen()
            for i, key in impact_kolommen.items():
                if extract(row, key, is_bool=True, default=False):
                    setattr(impact, i, True)

            maatregelen.append(
                GeplandeMaatregel(
                    uuid=extract(row, "uuid", is_uuid=True, default=uuid4()),
                    referentie_nummer=extract(row, "referentie_nummer"),
                    beheerobject=beheerobject,
                    element=extract(row, "element"),
                    bouwdeel=extract(row, "bouwdeel"),
                    pakket_id=extract(row, "pakket_id"),
                    maatregel=extract(row, "maatregel"),
                    disciplines=disciplines,
                    gepland_uitvoeringsjaar=extract(row, "gepland_uitvoeringsjaar", default=0),
                    gepland_uitvoeringsjaar_reden=extract(row, "gepland_uitvoeringsjaar_reden"),
                    gewenst_uitvoeringsjaar=extract(row, "gewenst_uitvoeringsjaar"),
                    advies_plan_jaar=extract(row, "advies_plan_jaar", default=0),
                    uiterst_advies_jaar=extract(row, "uiterst_advies_jaar", default=0),
                    kan_later_dan_uiterst=extract(
                        row, "kan_later_dan_uiterst", is_bool=True, default=False
                    ),
                    impact=impact,
                    verlies=FunctieVerlies.volledig(impact),
                    raming_incl=float(extract(row, "raming_incl", default=0.0)),
                    periode=float(extract(row, "periode", default=float("inf"))),
                )
            )

        return MaatregelPlanning(maatregelen)


def _maak_maatregelplanning_excel(
    planning: MaatregelPlanning, path: Path | str | None = None
) -> Workbook:
    """Excel format voor geplande maatregelen voor Rijkswaterstaat.

    Arguments:
        planning: Maatregelplanning om te converteren naar Excel.

    Returns:
        Excel Workbook met een maatregelenplanning als tabblad.
    """
    wb = _empty_workbook()

    _vul_maatregelplanning_worksheet(wb.worksheets[0], planning)

    if path:
        wb.save(str(Path(path)))

    return wb


def _vul_maatregelplanning_worksheet(ws: Worksheet, planning: MaatregelPlanning) -> None:
    """Maak een Excel worksheet met een maatregelplanning.

    Arguments:
        ws: Worksheet om te vullen met de maatregelplanning.
        planning: Maatregelplanning om het tabblad (worksheet) mee te vullen.
    """
    ws.title = "Maatregelplanning"
    ws.append(list(gen_dataclass_columns(GeplandeMaatregel)))

    for mr in planning.maatregelen:
        ws.append(
            _encode_uuid(value) if isinstance(value, UUID) else value
            for value in gen_dataclass_values(mr)
        )

    _set_table_style(ws)
    _set_auto_width(ws)
