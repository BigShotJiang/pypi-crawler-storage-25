"""OHS sheet readout module."""

import re
from collections import defaultdict
from pathlib import Path

import openpyxl
from beartype.typing import Generator, Never
from openpyxl.workbook import Workbook
from openpyxl.worksheet.worksheet import Worksheet
from raplan import logger
from serde import InternalTagging, SerdeError, field, serde

from raplan_rws.shared import (
    BeheerObject,
    Discipline,
    ElementBouwdeel,
    FunctieImpact,
    ObjectStructuur,
)
from raplan_rws.utils import extract_comp_code, extract_disk_code

_OHS_BD_LONG_PAT = re.compile(r"(.*) - (.*) - (.*)")
_OHS_BD_PAT = re.compile(r"(.*) - (.*)")


def _parse_element_bouwdeel(element_bouwdeel: str) -> ElementBouwdeel:
    long = _OHS_BD_LONG_PAT.match(element_bouwdeel)
    if long is not None:
        _, element, bouwdeel = long.groups()
        assert isinstance(element, str), "Element zou altijd moeten matchen."
        assert isinstance(bouwdeel, str), "Bouwdeel zou altijd moeten matchen."
        return ElementBouwdeel(
            element=element.strip(),
            bouwdeel=bouwdeel.strip(),
        )
    match = _OHS_BD_PAT.match(element_bouwdeel)
    if match is None:
        splits = element_bouwdeel.split(", ")
        if len(splits) == 2:
            return ElementBouwdeel(element=splits[1], bouwdeel=splits[0])
        logger.warning(
            f"'{element_bouwdeel}' is geen OHS Element - Bouwdeel combi. "
            "Die zou normaliter twee delen moeten matchen. "
            "Bouwdeel en element krijgen beiden de input als waarde."
        )
        return ElementBouwdeel(element=element_bouwdeel, bouwdeel=element_bouwdeel)

    element, bouwdeel = match.groups()
    assert isinstance(element, str), "Element zou altijd moeten matchen."
    assert isinstance(bouwdeel, str), "Bouwdeel zou altijd moeten matchen."
    return ElementBouwdeel(
        element=element.strip(),
        bouwdeel=bouwdeel.strip(),
    )


@serde(tagging=InternalTagging("type"))
class OhsInstellingen:
    """Importeer-instellingen voor de OHS Excel workbook.

    Attributes:
        vast_beheerobject: Één vast beheerobject welke geldt voor het in te laden OHS-sheet.
            Gaat meestal gepaard met `disk_in_objectnaam` en `element_in_objectkolom=True`.
        object_naar_disk_override: Een dictionary mapping van OHS waardes in de "object" kolom naar
            de bijbehorende DISK code.
        disk_in_objectnaam: Of de DISK code kan worden afgeleid uit de waarden in de "object" kolom
            in de BEP- en Element-Functie sheets.
        element_in_objectkolom: Of het element in de "object" kolom is geplaatst in plaats van het
            beheerobject. Gaat meestal gepaard met een `vaste_disk_code` en
            `disk_in_objectnaam=False`.
    """

    vast_beheerobject: BeheerObject | None = None
    object_naar_disk_override: dict[str, str] = field(default_factory=dict)
    disk_in_objectnaam: bool = True
    element_in_object_kolom: bool = False

    def beheer_object(self, object: str) -> BeheerObject:
        """Leidt de DISK code af met behulp van deze instellingen."""
        if object in self.object_naar_disk_override:
            return BeheerObject(self.object_naar_disk_override[object], object)

        if self.vast_beheerobject is not None:
            return self.vast_beheerobject

        value: str | None
        if self.disk_in_objectnaam:
            value = extract_disk_code(object)

        if value is None:
            logger.warning(f"Kon geen DISK code afleiden voor '{object}'.")
            return BeheerObject(object, object)
        return BeheerObject(value, object)

    def element_bouwdeel(self, object: str, element_bouwdeel: str) -> ElementBouwdeel:
        """Importeer de Element/Bouwdeel combinatie."""
        if self.element_in_object_kolom:
            return ElementBouwdeel(object, element_bouwdeel)
        return _parse_element_bouwdeel(element_bouwdeel)


@serde(tagging=InternalTagging("type"))
class OhsBepRow:
    """Rij in het OHS BEP (Beheer en Exploitatieplan) sheet.

    Attributes:
        beheer_object: Objectnaam. Kan DISK code bevatten maar hoeft niet altijd.
        element_bouwdeel: Element / bouwdeel benaming.
        discipline: Betrokken discipline(s). Staat als 'Type' in de BEP Excel-sheet.
    """

    beheer_object: BeheerObject
    element_bouwdeel: ElementBouwdeel
    discipline: set[Discipline]

    @classmethod
    def van_kolomwaarden(
        cls,
        beheer_object: str,
        element_bouwdeel: str,
        discipline: str,
        instellingen: OhsInstellingen,
    ) -> "OhsBepRow":
        bo = instellingen.beheer_object(beheer_object)
        eb = instellingen.element_bouwdeel(beheer_object, element_bouwdeel)
        dis = Discipline.auto(discipline)
        if not dis:
            try:
                dis = Discipline.van_element_bouwdeel(eb)
            except ValueError as e:
                logger.warning(str(e))

        return cls(
            bo,
            eb,
            dis,
        )


@serde(tagging=InternalTagging("type"))
class OhsBepData:
    """OHS BEP sheet data."""

    rijen: list[OhsBepRow] = field(default_factory=list)

    def __getitem__(self, key: int) -> OhsBepRow:
        return self.rijen[key]

    def __len__(self) -> int:
        return len(self.rijen)

    def __iter__(self) -> Generator[OhsBepRow, Never, None]:
        yield from self.rijen

    def __add__(self, other: "OhsBepData") -> "OhsBepData":
        return OhsBepData(rijen=self.rijen + other.rijen)

    def __iadd__(self, other: "OhsBepData") -> "OhsBepData":
        self.rijen += other.rijen
        return self

    @classmethod
    def van_excel_bestand(cls, path: str | Path, instellingen: OhsInstellingen) -> "OhsBepData":
        """Importeer de BEP data uit een OHS Excel-bestand."""
        wb: openpyxl.Workbook = openpyxl.open(path)
        ws = wb["BEP"]
        assert isinstance(ws, Worksheet)
        return cls.van_excel_worksheet(ws, instellingen=instellingen)

    @classmethod
    def van_excel_worksheet(cls, ws: Worksheet, instellingen: OhsInstellingen) -> "OhsBepData":
        """Importeer de BEP data uit het BEP sheet uit een OHS Excel-bestand."""
        data = OhsBepData()

        class_fields = ["beheer_object", "element_bouwdeel", "discipline"]

        header_row: int | None = None
        for candidate, cell in enumerate(ws["A:A"]):
            if str(cell.value).lower().replace(" ", "_") == "object":
                header_row = candidate
                break

        assert header_row is not None, (
            "OHS BEP sheet moet altijd een 'object' kolom hebben ergens in kolom A."
        )

        header: dict[str, int] = {
            str(col[header_row].value).lower().replace(" ", "_"): index
            for index, col in enumerate(ws.iter_cols())
        }
        rename = dict(
            beheer_object="object", element_bouwdeel="element_/_bouwdeel", discipline="type"
        )
        for want, old in rename.items():
            header[want] = header.pop(old)

        field_to_index: dict[str, int] = dict()
        for f in class_fields:
            if f in header:
                field_to_index[f] = header[f]

        # Excel rows are 1-based and we are one past the header row.
        for row in ws.iter_rows(min_row=header_row + 2):
            params = {f: row[index].value for f, index in field_to_index.items()}
            if not params["beheer_object"] or not params["element_bouwdeel"]:
                continue
            if (
                "kosten" in params["element_bouwdeel"].lower()
                or "kosten" in params["beheer_object"].lower()
            ):
                continue
            try:
                new = OhsBepRow.van_kolomwaarden(**params, instellingen=instellingen)
                data.rijen.append(new)
            except SerdeError as e:
                logger.warning(f"Kan '{params}' niet inladen als OHS-BEP rij: {e}")
            except ValueError as e:
                logger.warning(f"Kan '{params}' niet inladen als OHS-BEP rij: {e}")

        return data


@serde(tagging=InternalTagging("type"))
class OhsElementFunctieRow:
    """Rij in het OHS Element-Functie sheet.

    Attributes:
        beheer_object: Naam voor het beheerobject. Kan DISK code bevatten maar hoeft niet altijd.
        element_bouwdeel: Naam voor het element/bouwdeel.
        schutten: Of het element/bouwdeel bijdraagt aan de functie schutten.
        spuien: Of het element/bouwdeel bijdraagt aan de functie spuien.
        kruisen: Of het element/bouwdeel bijdraagt aan de functie kruisen.
        keren: Of het element/bouwdeel bijdraagt aan de functie keren.
        vgm: Of het element/bouwdeel bijdraagt aan de functie VGM.
        secundair: Of het element/bouwdeel secundair bijdraagt.
        code: DISK code op basis van de beheerobjectnaam.
    """

    beheer_object: BeheerObject
    element_bouwdeel: ElementBouwdeel
    impact: FunctieImpact

    @classmethod
    def van_kolomwaarden(
        cls,
        beheer_object: str,
        element_bouwdeel: str,
        schutten: bool,
        spuien: bool,
        kruisen: bool,
        keren: bool,
        vgm: bool,
        secundair: bool,
        instellingen: OhsInstellingen,
    ) -> "OhsElementFunctieRow":
        bo = instellingen.beheer_object(beheer_object)
        eb = instellingen.element_bouwdeel(beheer_object, element_bouwdeel)
        imp = FunctieImpact(
            faciliteren_vaarweg_verkeer=schutten,
            hoogwater_afvoeren=spuien,
            faciliteren_wegverkeer=kruisen,
            water_keren=keren,
            vgm=vgm,
            secundaire_functies=secundair,
        )
        return cls(bo, eb, imp)


@serde(tagging=InternalTagging("type"))
class OhsElementFunctieData:
    rijen: list[OhsElementFunctieRow] = field(default_factory=list)

    def __getitem__(self, key: int) -> OhsElementFunctieRow:
        return self.rijen[key]

    def __len__(self) -> int:
        return len(self.rijen)

    def __iter__(self) -> Generator[OhsElementFunctieRow, None, None]:
        yield from self.rijen

    def __add__(self, other: "OhsElementFunctieData") -> "OhsElementFunctieData":
        return OhsElementFunctieData(rijen=self.rijen + other.rijen)

    def __iadd__(self, other: "OhsElementFunctieData") -> "OhsElementFunctieData":
        self.rijen += other.rijen
        return self

    @classmethod
    def van_excel_bestand(
        cls, path: str | Path, instellingen: OhsInstellingen
    ) -> "OhsElementFunctieData":
        """Importeer de Element-Functie data uit een OHS Excel-bestand."""
        wb: openpyxl.Workbook = openpyxl.open(path)
        ws = wb["Element-Functie"]
        assert isinstance(ws, Worksheet)
        return cls.van_excel_worksheet(ws, instellingen=instellingen)

    @classmethod
    def van_excel_worksheet(
        cls, ws: Worksheet, instellingen: OhsInstellingen
    ) -> "OhsElementFunctieData":
        """Importeer de Element-Functie data uit het Element-Functie sheet uit een OHS
        Excel-bestand.
        """
        data = OhsElementFunctieData()
        class_fields = [
            "beheer_object",
            "element_bouwdeel",
            "schutten",
            "spuien",
            "kruisen",
            "keren",
            "vgm",
            "secundair",
        ]

        header_row: int | None = None
        for candidate, cell in enumerate(ws["A:A"]):
            if str(cell.value).lower().replace(" ", "_") == "beheer_object":
                header_row = candidate
                break

        assert header_row is not None

        header: dict[str, int] = {
            str(col[header_row].value).lower().replace(" ", "_"): index
            for index, col in enumerate(ws.iter_cols())
        }
        rename = {"element_bouwdeel": "element_-_bouwdeel_naam"}
        for want, old in rename.items():
            header[want] = header.pop(old)

        # Excel rows are 1-based and we are one past the header row.
        beheer_object: str | None = None
        for row in ws.iter_rows(min_row=header_row + 2):
            params = {f: row[header[f]].value for f in class_fields}
            # Object doesn't have an entry in each row, only when it changes.
            nieuw_object = params.pop("beheer_object")
            if nieuw_object:
                candi = str(nieuw_object).strip()
                if candi:
                    beheer_object = candi

            if isinstance(beheer_object, str) and "kosten" in beheer_object.lower():
                continue

            if params["element_bouwdeel"] is None or "kosten" in params["element_bouwdeel"].lower():
                continue

            for k, v in params.items():
                if k in {"schutten", "spuien", "kruisen", "keren", "vgm", "secundair"}:
                    params[k] = str(v).strip().lower() == "x"
            try:
                new = OhsElementFunctieRow.van_kolomwaarden(
                    **params,
                    beheer_object=beheer_object,  # type: ignore
                    instellingen=instellingen,
                )
                data.rijen.append(new)
            except SerdeError as e:
                logger.warning(f"Kan {params} niet inladen als Element-Functie rij: {e}")
            except ValueError as e:
                logger.warning(f"Kan {params} niet inladen als Element-Functie rij: {e}")

        return data


@serde(tagging=InternalTagging("type"))
class OhsData:
    """OHS sheet data. Zie de `van_excel_bestand` functie om deze data in te laden.

    Attributes:
        bep: Beheer- en Exploïtatieplan sheet data.
        element_functie: Element-Functie mapping.
    """

    bep: OhsBepData = field(default_factory=OhsBepData)
    element_functie: OhsElementFunctieData = field(default_factory=OhsElementFunctieData)

    def __add__(self, other: "OhsData") -> "OhsData":
        return OhsData(
            bep=self.bep + other.bep, element_functie=self.element_functie + other.element_functie
        )

    def __iadd__(self, other: "OhsData") -> "OhsData":
        self.bep += other.bep
        self.element_functie += other.element_functie
        return self

    @classmethod
    def van_excel_bestand(cls, path: str | Path, instellingen: OhsInstellingen) -> "OhsData":
        """Importeer de relevante data uit een OHS Excel-bestand."""
        wb: openpyxl.Workbook = openpyxl.open(path)
        return cls.van_excel_workbook(wb, instellingen=instellingen)

    @classmethod
    def van_excel_workbook(cls, wb: Workbook, instellingen: OhsInstellingen) -> "OhsData":
        """Importeer de relevante data uit een ingeladen OHS Excel-workbook."""
        bep_sheet = wb["BEP"]
        assert isinstance(bep_sheet, Worksheet)
        bep = OhsBepData.van_excel_worksheet(bep_sheet, instellingen=instellingen)

        element_functie_sheet = wb["Element-Functie"]
        assert isinstance(element_functie_sheet, Worksheet)
        element_functie = OhsElementFunctieData.van_excel_worksheet(
            element_functie_sheet, instellingen=instellingen
        )

        return OhsData(bep=bep, element_functie=element_functie)

    def verwerk(self) -> "VerwerkteOhsData":
        """Verwerk deze rauwe data tot een verwerkt data object met beheerobjecten en structuren."""
        result = VerwerkteOhsData()
        result.verwerk_data(self)
        return result


@serde(tagging=InternalTagging("type"))
class VerwerkteOhsData:
    """Verwerkte OHS data."""

    objecten: dict[str, BeheerObject] = field(default_factory=dict)
    structuren: defaultdict[str, ObjectStructuur] = field(
        default_factory=lambda: defaultdict(ObjectStructuur)
    )

    def verwerk_data(self, data: OhsData):
        """Verwerk extra OHS data in dit object."""
        self.verwerk_bep(data.bep)
        self.verwerk_element_functie(data.element_functie)
        self.leid_missende_disciplines_af()
        self.migreer_complex()
        self.zoek_binnen_complex()

    def verwerk_bep(self, bep: OhsBepData):
        """Verwerk BEP sheet data."""
        for rij in bep:
            disk = rij.beheer_object.code
            if disk not in self.objecten:
                self.objecten[disk] = rij.beheer_object

            structuur: ObjectStructuur = self.structuren[disk]
            eb: ElementBouwdeel = rij.element_bouwdeel
            structuur.element_bouwdelen.add(eb)
            structuur.disciplines[eb].update(rij.discipline)

    def verwerk_element_functie(self, element_functie: OhsElementFunctieData):
        """Verwerk Element-Functie sheet data."""
        for rij in element_functie:
            disk = rij.beheer_object.code
            if disk not in self.objecten:
                self.objecten[disk] = rij.beheer_object

            structuur: ObjectStructuur = self.structuren[disk]
            eb: ElementBouwdeel = rij.element_bouwdeel
            structuur.element_bouwdelen.add(eb)
            structuur.impacts[eb] += rij.impact

    def leid_missende_disciplines_af(self):
        """Probeer missende discipline data af te leiden uit element-bouwdeel namen."""
        for disk, s in self.structuren.items():
            for eb in s.element_bouwdelen:
                if not s.disciplines[eb]:
                    try:
                        s.disciplines[eb].update(Discipline.van_element_bouwdeel(eb))
                    except ValueError as e:
                        logger.warning(f"OHS {disk}: {e}")

    def migreer_complex(self):
        """Combineer alle data naar een 'complex' object met afgekorte DISK code."""

        mig = VerwerkteOhsData()

        for obj in self.objecten.values():
            complex = extract_comp_code(obj.code)
            mig.objecten[complex] = BeheerObject(complex, "COMPLEX")

        for obj, obj_structuur in self.structuren.items():
            complex = extract_comp_code(obj)
            structuur = mig.structuren[complex]
            structuur.element_bouwdelen.update(obj_structuur.element_bouwdelen)
            for eb, dis in obj_structuur.disciplines.items():
                structuur.disciplines[eb].update(dis)
            for eb, imp in obj_structuur.impacts.items():
                structuur.impacts[eb] += imp

        self.objecten.update(mig.objecten)
        for code, structuur in mig.structuren.items():
            te_vullen = self.structuren[code]
            te_vullen.element_bouwdelen.update(structuur.element_bouwdelen)
            for eb, dis in structuur.disciplines.items():
                te_vullen.disciplines[eb].update(dis)
            for eb, imp in structuur.impacts.items():
                te_vullen.impacts[eb] += imp

    def zoek_binnen_complex(self):
        """Doe een poging om missende waarden te vullen vanuit de gedeelde complex waarden."""
        for obj in self.objecten.values():
            if obj.naam == "COMPLEX":
                continue

            obj_structuur = self.structuren[obj.code]
            complex = extract_comp_code(obj.code)
            comp_structuur = self.structuren[complex]

            for eb in obj_structuur.element_bouwdelen:
                if not obj_structuur.disciplines[eb]:
                    if eb in comp_structuur.disciplines:
                        obj_structuur.disciplines[eb].update(comp_structuur.disciplines[eb])
                        logger.warning(
                            "OHS migratie van disciplines van complexniveau naar "
                            f"{obj.code}: {eb.element} - {eb.bouwdeel}"
                        )
                if eb not in obj_structuur.impacts:
                    if eb in comp_structuur.impacts:
                        obj_structuur.impacts[eb] = comp_structuur.impacts[eb]
                        logger.warning(
                            "OHS migratie van impact van complexniveau naar "
                            f"{obj.code}: {eb.element} - {eb.bouwdeel}"
                        )
