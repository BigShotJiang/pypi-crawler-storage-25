"""Specific planning logic pertaining to Rijkswaterstaat."""

from logging import getLogger

logger = getLogger("RaPlan-RWS")
