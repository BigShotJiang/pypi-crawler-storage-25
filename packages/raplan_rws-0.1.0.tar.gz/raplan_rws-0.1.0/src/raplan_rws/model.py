"""Modelinstellingen voor het RWS project die worden vertaald naar instellingen voor de
Mixed-Integer Linear Programming (MILP) solver in RaPlan.
"""

from uuid import UUID

import raplan
from beartype.typing import Callable
from serde import InternalTagging, field, serde

from raplan_rws.shared import BeheerObject, Discipline, ElementBouwdeel, GeplandeMaatregel


@serde(tagging=InternalTagging("type"))
class MaatregelVerschuiving:
    """Doelfunctie instellingen voor het verschuiven van een maatregel in de tijd.

    Attributes:
        gratis_naar_voren: Naar voren halen wordt gratis.
        vaste_factor: Vaste verschuivingskosten of het nu een jaar naar voor of achter is.
        kosten_per_jaar_factor: Hoe zwaar de maatregelkosten per jaar van de herhalingsperiode moet
            worden meegenomen.
        frequentie_factor: Hoe zwaar puur de frequentie (zonder kosten) moet worden meegenomen.

    Note:
        De niet-specifieke kostenfactoren worden vermenigvuldigd met de absolute waarde van de
        delta. Het is mogelijk om een verschil aan te brengen door een tuple op te geven in de vorm
        van de wegingen (naar_voor, naar_achter) voor de verschillende factoren.
    """

    gratis_naar_voren: bool = True
    vaste_factor: int | float | tuple[int | float, int | float] = 0
    kosten_per_jaar_factor: int | float | tuple[int | float, int | float] = 0
    frequentie_factor: int | float | tuple[int | float, int | float] = 0

    def dynamische_functie(
        self,
        maintenance_naar_geplande_maatregel: dict[UUID, GeplandeMaatregel],
        specifieke_fn: Callable[[UUID, float], int | float | None] = lambda _id, _delta: None,
    ) -> Callable[[UUID, float], int | float | None]:
        """Maak een dynamische verschuivingsfunctie op basis van de instellingen en het project."""

        def verschuiving(maintenance_id: UUID, delta: float) -> int | float | None:
            specifiek = specifieke_fn(maintenance_id, delta)
            if specifiek is not None:
                return specifiek

            naar_voren = delta < 0
            if naar_voren and self.gratis_naar_voren:
                return 0
            naar_achter = int(not naar_voren)  # 1 voor naar achter, anders 0

            afstand = abs(delta)

            if isinstance(self.vaste_factor, (int, float)):
                kosten = afstand * self.vaste_factor
            else:
                factor = self.vaste_factor[naar_achter]
                kosten = afstand * factor

            if self.kosten_per_jaar_factor != 0:
                if isinstance(self.kosten_per_jaar_factor, (int, float)):
                    factor = self.kosten_per_jaar_factor
                else:
                    factor = self.kosten_per_jaar_factor[naar_achter]
                maatregel = maintenance_naar_geplande_maatregel[maintenance_id]
                kosten += afstand * factor * maatregel.frequentie() * maatregel.raming_incl

            if self.frequentie_factor != 0:
                if isinstance(self.frequentie_factor, (int, float)):
                    factor = self.frequentie_factor
                else:
                    factor = self.frequentie_factor[naar_achter]
                kosten += afstand * factor * maatregel.frequentie()

            return kosten

        return verschuiving


@serde(tagging=InternalTagging("type"))
class MaatregelSynchronisatie:
    """Instellingen voor het bundelen van maatregelen w.b. doelfunctie-bijdragen en
    randvoorwaarden. Bijdragen <0 zijn beloningen, >0 zijn kosten.

    Attributes:
        forceer_gelijk_starten: Stel dat maatregelen geforceerd gelijktijdig moeten beginnen en
            niet deels mogen overlappen in een ingreep.
        verbied_duplicatie: Geeft aan dat een taak met dezelfde omschrijving op hetzelfde object en
            element-bouwdeel nooit op hetzelfde moment mag worden gepland. Staat standaard aan.
        jaar_samenvallen: Doelfunctiebijdrage van het samenvallen van taken in de meest generiek
            zin. Dit getal wordt vermenigvuldigd met N-1 taken die samenvallen. Standaard op 1.
        zelfde_discipline: Doelfunctiebijdrage bij het samenvallen van eenzelfde
            discipline (ongeacht welke) gedurende één jaar en opzichte van de som van de raming van
            beide taken. Standaard op -0.1 (10% korting).
        discipline_combis: Doelfunctiebijdrage voor specifieke combinaties van
            disciplines gedurende één jaar tussen twee maatregelen. De beste bijdrage tussen de
            "zelfde discipline" en deze wordt gebruikt in het model. Standaard op -0.05 (5%
            korting).
    """

    forceer_gelijk_starten: bool = False
    verbied_duplicatie: bool = True
    jaar_samenvallen: int | float = 1
    zelfde_discipline: int | float = -0.1
    discipline_combis: dict[frozenset[Discipline], int | float] = field(
        default_factory=lambda: {
            frozenset((Discipline.Werktuigbouw, Discipline.Elektrotechniek)): -0.05,
            frozenset((Discipline.Werktuigbouw, Discipline.IndustriëleAutomatisering)): -0.05,
            frozenset((Discipline.Elektrotechniek, Discipline.IndustriëleAutomatisering)): -0.05,
            frozenset((Discipline.IndustriëleAutomatisering, Discipline.CyberSecurity)): -0.05,
            frozenset((Discipline.Civiel, Discipline.Algemeen)): -0.05,
        }
    )

    def dynamische_combi(
        self,
        maintenance_naar_geplande_maatregel: dict[UUID, GeplandeMaatregel],
        specifieke_combi_fn: Callable[[frozenset[UUID]], int | float | None] = lambda _id_pair: (
            None
        ),
    ) -> Callable[[frozenset[UUID]], int | float | None]:
        """Maak een dynamische maatregel-combinatie beloningsfunctie op basis van deze instellingen
        en het project.
        """

        def maatregel_combi(uuids: frozenset[UUID]) -> int | float | None:
            """Een dynamische maatregel-combinatie belongingsfunctie."""
            result = specifieke_combi_fn(uuids)
            if result is not None:
                return result
            beste: int | float = 0
            volgorde = sorted(uuids)
            kosten_totaal: int | float = 0.0
            for i, a in enumerate(volgorde):
                gma: GeplandeMaatregel = maintenance_naar_geplande_maatregel[a]
                kosten_totaal += gma.raming_incl
                for b in volgorde[i + 1 :]:
                    gmb: GeplandeMaatregel = maintenance_naar_geplande_maatregel[b]

                    # neem steeds het minimum omdat negatievere penalties beter zijn!
                    for dis_a in gma.disciplines:
                        for dis_b in gmb.disciplines:
                            if dis_a == dis_b:
                                beste = min(beste, self.zelfde_discipline)
                            try:
                                combi: frozenset[Discipline] = frozenset((dis_a, dis_b))
                                score: float | int = self.discipline_combis[combi]
                                beste = min(beste, score)
                            except KeyError:
                                continue

            return None if beste == 0 else beste * kosten_totaal

        return maatregel_combi

    def dynamische_uitsluiting(
        self,
        maintenance_naar_geplande_maatregel: dict[UUID, GeplandeMaatregel],
        specifieke_uitsluiting_fn: Callable[[frozenset[UUID]], bool | None] = lambda _id_pair: None,
    ) -> Callable[[frozenset[UUID]], bool]:
        """Maak een dynamische uitsluitfunctie op basis van deze instellingen en het project."""

        def maatregel_excl(uuids: frozenset[UUID]) -> bool:
            """Een dynamische uitsluitfunctie voor combinaties van maatregelen."""
            specifiek = specifieke_uitsluiting_fn(uuids)
            if specifiek is not None:
                return specifiek

            if not self.verbied_duplicatie:
                return False

            taken: set[tuple[BeheerObject, ElementBouwdeel, str]] = set()
            for uuid in uuids:
                gm: GeplandeMaatregel = maintenance_naar_geplande_maatregel[uuid]
                taak = (gm.beheerobject, gm.element_bouwdeel, gm.maatregel)

                if taak in taken:
                    return True
                else:
                    taken.add(taak)

            return False

        return maatregel_excl


@serde(tagging=InternalTagging("type"))
class IngreepInstellingen:
    """Instellingen voor het schuiven van ingrepen in de tijd.
    Besparingsbijdragen zijn <0, kosten >0.

    Attributes:
        jaar_zelfde_complex: Doelfunctiebijdrage voor het uitvoeren van gebundelde
            werkzaamheden aan hetzelfde complex. Factor maal de opgetelde kosten van de ingreep.
        verbied_zelfde_complex: Of ingrepen aan hetzelfde complex moeten worden verboden.
            Geeft een grote kans dat het model niet kan worden opgelost.
    """

    jaar_zelfde_complex: int | float = 1.0
    verbied_zelfde_complex: bool = False

    def dynamische_combi(
        self,
        ingrepen: dict[UUID, raplan.Procedure],
        maintenance_naar_geplande_maatregel: dict[UUID, GeplandeMaatregel],
        specifieke_combi_fn: Callable[[frozenset[UUID]], int | float | None] = lambda _ids: None,
    ) -> Callable[[frozenset[UUID]], int | float | None]:
        """Maak een dynamische combi-functie voor het belonen/straffen van samenvallende ingrepen
        op basis van deze instellingen en het project.
        """

        def ingreep_combi(uuids: frozenset[UUID]) -> int | float | None:
            """Dynamische combi-functie voor het belonen/afstraffen van samenvallende ingrepen."""
            result = specifieke_combi_fn(uuids)
            if result is not None:
                return result

            score: int | float | None = None
            volgorde = sorted(uuids)
            zelfde_complex = self.jaar_zelfde_complex
            for i, a in enumerate(volgorde):
                iga: raplan.Procedure = ingrepen[a]
                ma: raplan.Maintenance = iga.maintenance[0]
                gma: GeplandeMaatregel = maintenance_naar_geplande_maatregel[ma.uuid]
                boa: BeheerObject = gma.beheerobject
                for b in volgorde[i + 1 :]:
                    igb: raplan.Procedure = ingrepen[b]
                    mb: raplan.Maintenance = igb.maintenance[0]
                    gmb: GeplandeMaatregel = maintenance_naar_geplande_maatregel[mb.uuid]
                    bob: BeheerObject = gmb.beheerobject

                    # TODO: implement netwerkanalyse hier.

                    if (
                        zelfde_complex is not None
                        and boa.complex_code
                        and bob.complex_code
                        and boa.complex_code == bob.complex_code
                    ):
                        score = zelfde_complex if score is None else score + zelfde_complex

            return score

        return ingreep_combi

    def dynamische_uitsluiting(
        self,
        ingrepen: dict[UUID, raplan.Procedure],
        maintenance_naar_geplande_maatregel: dict[UUID, GeplandeMaatregel],
        specifieke_uitsluiting_fn: Callable[[frozenset[UUID]], bool | None] = lambda _ids: None,
    ) -> Callable[[frozenset[UUID]], bool]:
        """Maak een dynamische uitsluitfunctie voor ingrepen op basis van deze instellingen en het
        project."""

        def ingreep_excl(uuids: frozenset[UUID]) -> bool:
            """Een dynamische uitsluitfunctie voor ingrepen."""
            result = specifieke_uitsluiting_fn(uuids)
            if result is not None:
                return result

            volgorde = sorted(uuids)
            verbieding = self.verbied_zelfde_complex
            for i, a in enumerate(volgorde):
                iga: raplan.Procedure = ingrepen[a]
                ma: raplan.Maintenance = iga.maintenance[0]
                gma: GeplandeMaatregel = maintenance_naar_geplande_maatregel[ma.uuid]
                boa: BeheerObject = gma.beheerobject
                for b in volgorde[i + 1 :]:
                    igb: raplan.Procedure = ingrepen[b]
                    mb: raplan.Maintenance = igb.maintenance[0]
                    gmb: GeplandeMaatregel = maintenance_naar_geplande_maatregel[mb.uuid]
                    bob: BeheerObject = gmb.beheerobject

                    # TODO: implement netwerkanalyse hier.

                    # Zelfde complex uitsluiten.
                    if (
                        verbieding
                        and boa.complex_code
                        and bob.complex_code
                        and boa.complex_code == bob.complex_code
                    ):
                        return True

            return False

        return ingreep_excl


@serde(tagging=InternalTagging("type"))
class ModelInstellingen:
    """Instellingen voor het bundelen van maatregelen.

    Attributes:
        maatregel_verschuiving: Instellingen voor verschuivingskosten van een maatregel.
        maatregel_synchronisatie: Instellingen voor de onderlinge afstemming van maatregelen.
        ingreep_instellingen: Instellingen voor het onderlinge afstemmen van ingrepen.
        tijdsduur_naar_jaar: Omrekenfactor van de tijdsduur van maatregelen naar hele
            jaren zodat tijdsduur*factor == jaren.
        segmenten_per_jaar: Aantal segmenten om ieder jaar in op te delen. Voor een planning
            op jaarniveau mag deze op 1 blijven staan.
        score_precisie: Nauwkeurigheid waarop de doelfunctie moet worden berekend.
            Staat standaard op 1.
        model_output: Of de modeloutput moet worden weergegeven.
            Ziet er technisch uit, maar geeft inzage in de voortgang.
    """

    maatregel_verschuiving: MaatregelVerschuiving = field(default_factory=MaatregelVerschuiving)
    maatregel_synchronisatie: MaatregelSynchronisatie = field(
        default_factory=MaatregelSynchronisatie
    )
    ingreep_instellingen: IngreepInstellingen = field(default_factory=IngreepInstellingen)
    tijdsduur_naar_jaar: int | float = 1
    segmenten_per_jaar: int = 1
    score_precisie: int | float = 1
    model_output: bool = False
