"""POEMA Excel data import."""

import re
from collections import defaultdict
from datetime import datetime
from pathlib import Path
from uuid import UUID
from warnings import warn

import openpyxl
from beartype.typing import Generator, Never
from openpyxl.worksheet.worksheet import Worksheet
from raplan.classes import Horizon
from serde import InternalTagging, SerdeError, field, serde

from raplan_rws import logger
from raplan_rws.ohs import VerwerkteOhsData
from raplan_rws.shared import (
    BeheerObject,
    Discipline,
    ElementBouwdeel,
    FunctieImpact,
    FunctieVerlies,
    GeplandeMaatregel,
    MaatregelPlanning,
    ObjectStructuur,
)
from raplan_rws.utils import extract_comp_code, is_truey

_POEMA_BD_PAT = re.compile(r"Bouwdeel (.*) onderdeel van (.*)")
"""Matcher voor de Element-Bouwdeel combi vanuit POEMA."""

_POEMA_PERIODE_PAT = re.compile(r"Maatregel eens per (\d+) jaar uitvoeren")
"""Matcher voor de periode van gepland onderhoud uit de POEMA regels."""


@serde(tagging=InternalTagging("type"))
class PoemaRij:
    """Rij in het POEMA Excel export data format.

    Attributes:
        referentie_nummer: Specifiek referentienummer voor de maatregel.
        netwerk_code: Netwerkcode zoals "HWVN".
        dienst_code: Dienstcode zoals "RWS MN".
        maatregel_type: Type maatregel zoals "Variabel onderhoud".
        kan_later_dan_uiterst: Of de maatregel nog later mag dan het uiterst adviesjaar.
        is_vernieuwing: Of het vervanging betreft: j/n
        bron: Bron van de maatregel zoals "P-IHP".
        maatregel_naam: Korte omschrijving van de maatregel.
        maatregel_omschrijving: Toelichting Bouwdeel en eventuele specificaties van aantallen en/of
            locatie.
        object_code: DISK code van het object/de sluiskolk.
        ih_onderdeel: Instandhoudingsonderdeel.
        advies_plan_jaar: Advies planjaar vanuit de bron.
        uiterst_advies_jaar: Laatst toegestaan uitvoeringsjaar op basis van techniek.
        uitvoerings_kosten: Kosten in kEur.
        frequentie_tekst: Indicatie frequentie in tekst zoals
            "Maatregel eens per XX jaar uitvoeren."
        bronbestand: Bronbestand waar data vandaan komt zoals:
            "RCM_Irenesluis_2024_202407091330_PM.xlsx"
    """

    referentie_nummer: str
    netwerk_code: str | None
    dienst_code: str | None
    maatregel_type: str | None
    bron: str
    maatregel_naam: str
    maatregel_omschrijving: str
    object_code: str
    ih_onderdeel: str
    advies_plan_jaar: int | float
    uiterst_advies_jaar: int | float
    uitvoerings_kosten: int | float
    frequentie_tekst: str
    bronbestand: str
    kan_later_dan_uiterst: str | None = None
    is_vernieuwing: str | None = None

    def referentie_uuid(self) -> UUID:
        """Haal het UUID uit het referentienummer veld."""
        ref = self.referentie_nummer
        idx = 1
        n_dash = 0
        while n_dash < 2:
            if ref[idx] == "-":
                n_dash += 1
            idx += 1
        return UUID(ref[idx : idx + 36])

    def element_bouwdeel(self) -> ElementBouwdeel:
        """Leidt het `ElementBouwdeel` af van het `maatregel_omschrijving` veld."""
        match = _POEMA_BD_PAT.match(self.maatregel_omschrijving)
        if match is None:
            logger.warning(
                "POEMA Element/Bouwdeel zou altijd moeten matchen. "
                f"Gefaald op: {self.maatregel_omschrijving}"
            )
            return ElementBouwdeel(
                element=self.maatregel_omschrijving, bouwdeel=self.maatregel_omschrijving
            )
        bouwdeel, element = match.groups()
        assert isinstance(element, str), "Element zou altijd moeten matchen."
        assert isinstance(bouwdeel, str), "Bouwdeel zou altijd moeten matchen."
        return ElementBouwdeel(
            element=element.strip(),
            bouwdeel=bouwdeel.strip(),
        )

    def periode(self) -> float | None:
        """Lengte van de periode voor deze maatregel indien het een herhalende
        preventieve maatregel betreft."""
        match = _POEMA_PERIODE_PAT.match(self.frequentie_tekst)
        if match is None:
            return None

        return float(match.groups()[0])

    def vernieuwing(self) -> bool:
        """Of deze maatregel vernieuwing beschrijft. Wanneer de data niet beschikbaar is, wordt
        aangenomen van wel."""
        return is_truey(self.is_vernieuwing, default=True)


@serde(tagging=InternalTagging("type"))
class PoemaData:
    rows: list[PoemaRij] = field(default_factory=list)

    def __getitem__(self, key: int) -> PoemaRij:
        return self.rows[key]

    def __len__(self) -> int:
        return len(self.rows)

    def __iter__(self) -> Generator[PoemaRij, Never, None]:
        yield from self.rows

    def __add__(self, other: "PoemaData") -> "PoemaData":
        return PoemaData(rows=self.rows + other.rows)

    def __iadd__(self, other: "PoemaData") -> "PoemaData":
        self.rows += other.rows
        return self

    @classmethod
    def van_excel_bestand(cls, path: str | Path) -> "PoemaData":
        wb: openpyxl.Workbook = openpyxl.open(path)
        ws = wb.active
        assert isinstance(ws, Worksheet)
        return cls.van_excel_worksheet(ws)

    @classmethod
    def van_excel_worksheet(cls, ws: Worksheet) -> "PoemaData":
        data = PoemaData()

        class_fields = [
            "referentie_nummer",
            "netwerk_code",
            "dienst_code",
            "maatregel_type",
            "bron",
            "maatregel_naam",
            "maatregel_omschrijving",
            "object_code",
            "ih_onderdeel",
            "advies_plan_jaar",
            "uiterst_advies_jaar",
            "uitvoerings_kosten",
            "frequentie_tekst",
            "bronbestand",
            "kan_later_dan_uiterst",
            "is_vernieuwing",
        ]

        header_row: int | None = None
        for header_row, cell in enumerate(ws["A:A"]):
            if str(cell.value).lower().replace(" ", "_") == "referentie_nummer":
                break

        assert header_row is not None, (
            "POEMA export moet altijd een 'referentie_nummer' kolom hebben ergens in kolom A."
        )

        header: dict[str, int] = {
            str(col[header_row].value).lower().replace(" ", "_"): index
            for index, col in enumerate(ws.iter_cols())
        }
        rename: dict[str, str] = dict(bronbestand="kenmerk2", frequentie_tekst="kenmerk_1")
        for want, old in rename.items():
            header[want] = header.pop(old)

        field_to_index: dict[str, int] = dict()
        for f in class_fields:
            if f in header:
                field_to_index[f] = header[f]

        # Excel rows are 1-based and we are one past the header row.
        for row in ws.iter_rows(min_row=header_row + 2):
            params = {f: row[index].value for f, index in field_to_index.items()}
            if params["referentie_nummer"] is None:
                continue
            try:
                new = PoemaRij(**params)
                data.rows.append(new)
            except SerdeError as e:
                warn(f"Kan '{params}' niet inladen als POEMA rij: {e}")

        return data

    def verwerk(
        self,
        ohs: VerwerkteOhsData | None = None,
        horizon: Horizon | None = None,
        negeer_verleden: bool = True,
        negeer_toekomst: bool = True,
        minimale_periode: int = 2,
    ) -> "VerwerktePoemaData":
        """Verwerk de POEMA data - eventueel aangevuld/gematcht met verwerkte OHS data."""
        result = VerwerktePoemaData()
        diagnostiek = result.verwerk(
            self,
            ohs=ohs,
            horizon=horizon,
            negeer_verleden=negeer_verleden,
            negeer_toekomst=negeer_toekomst,
            minimale_periode=minimale_periode,
        )
        diagnostiek.rapporteer()
        return result


@serde(tagging=InternalTagging("type"))
class PoemaDiagnostiek:
    """Diagnostiek tijdens het inladen en matchen van POEMA data."""

    missende_ohs_objecten: set[str] = field(default_factory=set)
    missende_ohs_element_bouwdelen: set[tuple[str, ElementBouwdeel]] = field(default_factory=set)
    missende_impact: set[tuple[str, ElementBouwdeel]] = field(default_factory=set)
    missende_disciplines: set[tuple[str, ElementBouwdeel]] = field(default_factory=set)
    afgeleide_disciplines: set[tuple[str, ElementBouwdeel, tuple[Discipline, ...]]] = field(
        default_factory=set
    )

    def rapporteer(self):
        """Rapporteer de diagnostieke bevindingen van een POEMA/OHS import."""
        for obj in self.missende_ohs_objecten:
            logger.warning(f"Missend OHS object {obj}")

        for obj, eb in self.missende_impact:
            if obj in self.missende_ohs_objecten:
                continue
            logger.warning(f"Mist OHS functie-impact {obj}: {eb.element} - {eb.bouwdeel}")

        for obj, eb in self.missende_disciplines:
            if obj in self.missende_ohs_objecten:
                continue
            logger.warning(f"Mist OHS disciplines {obj}: {eb.element} - {eb.bouwdeel}")

        for obj, eb, dis in self.afgeleide_disciplines:
            if obj in self.missende_ohs_objecten:
                continue
            logger.warning(
                "Disciplines afgeleid van object/bouwdeel "
                f"{obj}: {eb.element} - {eb.bouwdeel}: "
                f"{'-'.join(s for s in dis)} | "
            )


@serde(tagging=InternalTagging("type"))
class VerwerktePoemaData:
    """Verwerkte POEMA data.

    Attributes:
        planning: Maatregelplanning op basis van POEMA rijen.
        objecten: Dictionary van DISK codes naar beheerobjecten en complexen.
        structuren: Dictionary van DISK codes naar extra informatie w.b. element-bouwdelen en
            bijbehorende disciplines en functie-impact.
        horizon: Opgegeven of geobserveerde tijdshorizon.
    """

    planning: MaatregelPlanning = field(default_factory=MaatregelPlanning)
    objecten: dict[str, BeheerObject] = field(default_factory=dict)
    structuren: defaultdict[str, ObjectStructuur] = field(
        default_factory=lambda: defaultdict(ObjectStructuur)
    )
    horizon: Horizon = field(default_factory=lambda: Horizon(datetime.today().year, end=None))

    def verwerk(
        self,
        poema: PoemaData,
        ohs: VerwerkteOhsData | None = None,
        horizon: Horizon | None = None,
        negeer_verleden: bool = True,
        negeer_toekomst: bool = True,
        minimale_periode: int = 2,
    ) -> PoemaDiagnostiek:
        """Verwerk POEMA data, eventueel aangevuld met te matchen verwerkte OHS data."""
        diag = PoemaDiagnostiek()

        if ohs is not None:
            self.objecten = ohs.objecten
            self.structuren = ohs.structuren

        for rij in poema:
            if horizon is not None and self.is_overbodig(
                rij, horizon, negeer_verleden, negeer_toekomst, minimale_periode
            ):
                continue

            disk: str = rij.object_code
            complex: str = extract_comp_code(disk)

            obj: BeheerObject = self.check_object(disk, diag)
            eb: ElementBouwdeel = rij.element_bouwdeel()
            dis, imp = self.check_element_bouwdeel(disk, complex, eb, diag)

            kan_later_dan_uiterst: bool = is_truey(
                str(rij.kan_later_dan_uiterst),
                default=False,
            )

            gmr = GeplandeMaatregel(
                referentie_nummer=rij.referentie_nummer,
                beheerobject=obj,
                element=eb.element,
                bouwdeel=eb.bouwdeel,
                pakket_id=None,
                maatregel=rij.maatregel_naam,
                disciplines=dis,
                gepland_uitvoeringsjaar=int(rij.advies_plan_jaar),
                gepland_uitvoeringsjaar_reden="adviesplanjaar",
                gewenst_uitvoeringsjaar=int(rij.advies_plan_jaar),
                advies_plan_jaar=int(rij.advies_plan_jaar),
                uiterst_advies_jaar=int(rij.uiterst_advies_jaar),
                kan_later_dan_uiterst=kan_later_dan_uiterst,
                impact=imp,
                verlies=FunctieVerlies.volledig(imp),
                raming_incl=float(rij.uitvoerings_kosten),
                periode=rij.periode(),
            )

            if horizon is None:
                start = min(gmr.advies_plan_jaar, gmr.uiterst_advies_jaar)
                self.horizon.start = min(self.horizon.start, start)
                end = start + 1
                self.horizon.end = end if self.horizon.end is None else max(self.horizon.end, end)

            self.planning.maatregelen.append(gmr)

        if horizon is not None:
            self.horizon = horizon

        return diag

    def is_overbodig(
        self,
        rij: PoemaRij,
        horizon: Horizon,
        negeer_verleden: bool,
        negeer_toekomst: bool,
        minimale_periode: int,
    ) -> bool:
        """Check of een POEMA rij binnen de horizon valt, inachtnemend de filters."""

        if negeer_verleden:
            if rij.advies_plan_jaar < horizon.start and rij.uiterst_advies_jaar < horizon.start:
                return True
        if negeer_toekomst and horizon.end is not None:
            if rij.advies_plan_jaar > horizon.end and rij.uiterst_advies_jaar > horizon.end:
                return True

        periode = rij.periode()
        if periode is not None and periode < minimale_periode:
            return True

        return False

    def check_object(self, disk: str, diag: PoemaDiagnostiek) -> BeheerObject:
        """Check of het object bestaat en maak het aan als dat niet zo is."""
        try:
            obj = self.objecten[disk]
        except KeyError:
            diag.missende_ohs_objecten.add(disk)
            obj = BeheerObject(disk, disk)
            self.objecten[disk] = obj
        finally:
            return obj

    def check_element_bouwdeel(
        self, disk: str, complex: str, eb: ElementBouwdeel, diag: PoemaDiagnostiek
    ) -> tuple[set[Discipline], FunctieImpact]:
        """Check of het bouwdeel bestaat voor de opgegeven DISK code."""
        obj_struct = self.structuren[disk]
        comp_struct = self.structuren[complex]

        if eb not in obj_struct.element_bouwdelen:
            diag.missende_ohs_element_bouwdelen.add((disk, eb))
            obj_struct.element_bouwdelen.add(eb)
            obj_struct.disciplines[eb].update(comp_struct.disciplines[eb])
            if eb in comp_struct.impacts:
                obj_struct.impacts[eb] += comp_struct.impacts[eb]
            else:
                diag.missende_impact.add((disk, eb))

        dis = obj_struct.disciplines[eb]
        if not dis:
            try:
                dis = Discipline.van_element_bouwdeel(eb)
                obj_struct.disciplines[eb] = dis
                diag.afgeleide_disciplines.add((disk, eb, tuple(dis)))
            except ValueError as _:
                diag.missende_disciplines.add((disk, eb))

        imp = obj_struct.impacts[eb]

        return dis, imp
