"""Various utilities for RWS applications."""

import re

DISK = re.compile(r"\b([A-Z\d]{2,3})-\b([A-Z\d]{2,3})(-\b([A-Z\d]{2,3}))?\b")


def extract_disk_code(input: str) -> str | None:
    """Attempt to extract a DISK code from a string such as '39B-002-02'."""
    match = re.search(DISK, input.upper())
    if match is None:
        return None
    groups = match.groups()
    if len(groups) == 2:
        return "-".join(groups)
    else:
        if groups[3] == "XX" or groups[3] is None:
            return "-".join((groups[0], groups[1]))
        else:
            return "-".join((groups[0], groups[1], groups[3]))


def extract_comp_code(disk: str) -> str:
    """Extract the complex code from a DISK code."""
    parts: list[str] = disk.split("-")
    return "-".join(parts[:2])


def is_truey(input: bool | str | int | None, default: bool = False) -> bool:
    """Whether this is a True-ish value."""
    if input is None:
        return default

    match input:
        case str():
            input = input.strip().lower()
            if input:
                return "j" in input or "y" in input or "x" in input or input == "true"
            else:
                return default
        case bool():
            return input
        case int():
            return bool(input)
