"""Rijkswaterstaat project Python raplan."""

from collections import defaultdict
from copy import deepcopy
from pathlib import Path
from uuid import NAMESPACE_DNS, UUID, uuid4, uuid5

import raplan
from beartype.typing import Generator, Never
from highspy import HighsModelStatus
from openpyxl import Workbook
from raplan import Horizon
from raplan.milp import LpBuilder, LpProcedureProject, LpSyncProject, LpSyncSystem
from serde import InternalTagging, field, serde

from raplan_rws import logger
from raplan_rws.model import ModelInstellingen
from raplan_rws.ohs import OhsData, OhsInstellingen
from raplan_rws.poema import PoemaData, VerwerktePoemaData
from raplan_rws.shared import (
    BeheerObject,
    ElementBouwdeel,
    GeplandeMaatregel,
    MaatregelPlanning,
    ObjectStructuur,
)


@serde(tagging=InternalTagging("type"))
class RwsProject:
    """Data voor een RWS project.

    Attributes:
        naam: Optionele projectnaam.
        planning: Het hart van de data, de maatregelplanning.
        objecten: Alle beheerobject-namen en code per DISK code.
        structuren: Alle beheerobject-structuren bestaande uit de element-bouwdelen en de daarbij
            betrokken disciplines en functie-impact per element-bouwdeel.
        horizon: Opgegeven of geobserveerde horizon.
        vervroeging_factor: Hoeveel jaar een taak naar voren mag worden gehaald t.o.v. de
                afstand tussen het advies plan jaar en het uiterst advies jaar (standaard 25%).
        later_dan_uiterst: Maximale uitloop voor maatregelen die later dan hun uiterste advies plan
            jaar worden gepland wanneer dat is toegestaan door het veld `kan_later_dan_uiterst`.

        project: RaPlan project dat correspondeert met de RWS data.
        component_naar_disk_eb: Mapping van Component UUID's uit het RaPlan project naar
            element-bouwdelen uit de RWS wereld.
        disk_eb_naar_component: Mapping van een DISK code en ElementBouwdeel naar een RaPlan
            project Component.
        maintenance_naar_geplande_maatregel: Mapping van Maintenance UUID's uit het RaPlan project
            naar geplande maatregelen in de RWS planning.
        geplande_maatregel_naar_maintenance: Mapping van een geplande maatregel naar de
            bijbehorende RaPlan Maintenance.
        system_naar_structuur: Mapping van System UUID's uit het RaPlan project naar beheerobject
            structuren in de RWS wereld.
    """

    naam: str | None = None
    planning: MaatregelPlanning = field(default_factory=MaatregelPlanning)
    horizon: Horizon | None = field(default=None)
    vervroeging_factor: float = 0.25
    later_dan_uiterst: int = 0

    # POST INIT ATTRIBUTES
    objecten: dict[str, BeheerObject] = field(default_factory=dict, init=False)
    structuren: defaultdict[str, ObjectStructuur] = field(
        default_factory=lambda: defaultdict(ObjectStructuur), init=False
    )
    project: raplan.Project = field(init=False)
    disk_naar_system: dict[str, raplan.System] = field(default_factory=dict, init=False)
    system_naar_structuur: dict[UUID, ObjectStructuur] = field(default_factory=dict, init=False)
    component_naar_disk_eb: dict[UUID, tuple[str, ElementBouwdeel]] = field(
        default_factory=dict, init=False
    )
    disk_eb_naar_component: dict[tuple[str, ElementBouwdeel], raplan.Component] = field(
        default_factory=dict, init=False
    )
    maintenance_naar_geplande_maatregel: dict[UUID, GeplandeMaatregel] = field(
        default_factory=dict, init=False
    )
    geplande_maatregel_naar_maintenance: dict[str, raplan.Maintenance] = field(
        default_factory=dict, init=False
    )

    def __str__(self) -> str:
        return (
            f"RwsProject(naam='{self.naam}', "
            f"planning=MaatregelPlanning(..{len(self.planning)}), "
            f"horizon={self.horizon}), "
            f"later_dan_uiterst={self.later_dan_uiterst})"
        )

    def __repr__(self) -> str:
        return self.__str__()

    def __post_init__(self) -> None:
        if self.horizon is None:
            self.horizon: Horizon = self.planning.horizon()
        self.herbouw_project()

    def _herbouw_structuur(self):
        """Leid de objectstructuur af van wat er in de maatregelplanning staat.
        Herbouwt ook het RaPlan Project.
        """
        for disk, (obj, structuur) in self.planning.objecten_structuren().items():
            self.objecten[disk] = obj
            self.structuren[disk] = structuur

    def _clear_mappings(self):
        self.disk_naar_system.clear()
        self.system_naar_structuur.clear()
        self.component_naar_disk_eb.clear()
        self.disk_eb_naar_component.clear()
        self.maintenance_naar_geplande_maatregel.clear()
        self.geplande_maatregel_naar_maintenance.clear()

    def herbouw_project(self):
        """Herbouw het intern opgeslagen RaPlan project en update de mapping dictionaries."""
        if self.horizon is None:
            self.horizon: Horizon = self.planning.horizon()
        horizon: Horizon = self.horizon
        self.project = raplan.Project(name=self.naam, horizon=horizon)
        self._herbouw_structuur()
        self.planning.pas_horizon_toe(horizon)
        self._clear_mappings()
        start = int(horizon.start)

        for m in self.planning:
            if not m.valt_binnen_horizon(horizon):
                logger.debug(
                    f"Maatregel '{m.referentie_nummer}' valt buiten horizon "
                    f"'{horizon.start}-{horizon.end}'"
                )
                continue
            self._registreer_maatregel(m, start)

    def _registreer_maatregel(self, m: GeplandeMaatregel, start: int):
        disk = m.beheerobject.code

        try:
            system: raplan.System = self.disk_naar_system[disk]
        except KeyError:
            system: raplan.System = raplan.System(name=m.beheerobject.code)
            self.project.systems.append(system)
            self.disk_naar_system[disk] = system

        try:
            structuur: ObjectStructuur = self.system_naar_structuur[system.uuid]
        except KeyError:
            structuur = self.structuren[disk]
            self.system_naar_structuur[system.uuid] = structuur

        eb = m.element_bouwdeel
        disk_eb: tuple[str, ElementBouwdeel] = (disk, eb)
        try:
            component: raplan.Component = self.disk_eb_naar_component[disk_eb]
        except KeyError:
            component = raplan.Component(name=str(eb))
            self.disk_eb_naar_component[disk_eb] = component
            self.component_naar_disk_eb[component.uuid] = disk_eb
            system.components.append(component)

        structuur.element_bouwdelen.add(eb)
        structuur.disciplines[eb].update(m.disciplines)
        structuur.impacts[eb] += m.impact

        # Populate rescheduling.
        rescheduling: list[raplan.Rescheduling] = [
            raplan.Rescheduling(time=m.advies_plan_jaar - start, reason="advies plan jaar")
        ]
        if m.gewenst_uitvoeringsjaar != m.advies_plan_jaar:
            rescheduling.append(
                raplan.Rescheduling(
                    time=m.gewenst_uitvoeringsjaar - start, reason="gewenst uitvoeringsjaar"
                )
            )
        if (
            m.gepland_uitvoeringsjaar != m.advies_plan_jaar
            and m.gepland_uitvoeringsjaar != m.gewenst_uitvoeringsjaar
        ):
            rescheduling.append(
                raplan.Rescheduling(
                    m.gepland_uitvoeringsjaar - start, reason=m.gepland_uitvoeringsjaar_reden
                )
            )

        time: int = m.time(start=start)
        window: raplan.Window = m.window(
            start=start,
            later_dan_uiterst_bonus=self.later_dan_uiterst,
            vervroeging_factor=self.vervroeging_factor,
        )
        maintenance = raplan.Maintenance(
            name=m.maatregel,
            task=raplan.Task(
                m.maatregel,
                cost=m.raming_incl,
                duration=1,
                rejuvenation=1.0,
            ),
            time=float(time),
            rescheduling=rescheduling,
            window=window,
        )
        component.maintenance.append(maintenance)
        self.maintenance_naar_geplande_maatregel[maintenance.uuid] = m
        self.geplande_maatregel_naar_maintenance[m.uuid] = maintenance

    @classmethod
    def van_poema_ohs_bestanden(
        cls,
        poema: list[str | Path],
        ohs: list[tuple[str | Path, OhsInstellingen]],
        horizon: Horizon | None = None,
        negeer_verleden: bool = True,
        negeer_toekomst: bool = True,
        minimale_periode: int = 2,
        naam: str | None = None,
        later_dan_uiterst: int = 0,
    ) -> "RwsProject":
        """Maak een RWS project gebaseerd op POEMA en OHS bestanden/instellingen."""
        ohs_data = OhsData()
        for bestand, instellingen in ohs:
            ohs_data += OhsData.van_excel_bestand(bestand, instellingen)
        ohs_verwerkt = ohs_data.verwerk()

        poema_data = PoemaData()
        for bestand in poema:
            poema_data += PoemaData.van_excel_bestand(bestand)

        data = poema_data.verwerk(
            ohs=ohs_verwerkt,
            horizon=horizon,
            negeer_verleden=negeer_verleden,
            negeer_toekomst=negeer_toekomst,
            minimale_periode=minimale_periode,
        )

        return cls.van_poema_data(
            data, naam=naam, horizon=horizon, later_dan_uiterst=later_dan_uiterst
        )

    @classmethod
    def van_poema_data(
        cls,
        data: VerwerktePoemaData,
        naam: str | None = None,
        horizon: Horizon | None = None,
        later_dan_uiterst: int = 0,
    ) -> "RwsProject":
        """Maak een RWS project gebaseerd op verwerkte POEMA data."""
        return cls(
            naam=naam,
            planning=data.planning,
            horizon=horizon or data.horizon,
            later_dan_uiterst=later_dan_uiterst,
        )

    def naar_excel_bestand(self, path: str | Path | None = None) -> Workbook:
        """Schrijf de planning weg naar een Excelbestand."""
        return self.planning.naar_excel_bestand(path=path)

    @classmethod
    def van_excel_bestand(
        cls,
        path: str | Path,
        naam: str | None = None,
        horizon: Horizon | None = None,
        later_dan_uiterst: int = 0,
    ) -> "RwsProject":
        """Laad een RWS project in vanaf en Excelbestand."""
        planning: MaatregelPlanning = MaatregelPlanning.van_excel_bestand(path)
        return cls.van_maatregel_planning(
            planning, naam=naam, horizon=horizon, later_dan_uiterst=later_dan_uiterst
        )

    @classmethod
    def van_maatregel_planning(
        cls,
        planning: MaatregelPlanning,
        naam: str | None = None,
        horizon: Horizon | None = None,
        later_dan_uiterst: int = 0,
    ):
        objecten: dict[str, BeheerObject] = dict()
        structuren: dict[str, ObjectStructuur] = defaultdict(ObjectStructuur)

        for mr in planning:
            disk = mr.beheerobject.code

            if disk not in objecten:
                objecten[disk] = mr.beheerobject

            if disk not in structuren:
                structuren[disk] = ObjectStructuur()

            structuur: ObjectStructuur = structuren[disk]

            eb = mr.element_bouwdeel
            structuur.element_bouwdelen.add(eb)

            if eb not in structuur.disciplines:
                structuur.disciplines[eb] = mr.disciplines

            if eb not in structuur.impacts:
                structuur.impacts[eb] = mr.impact

        return RwsProject(
            naam=naam,
            planning=planning,
            horizon=horizon,
            later_dan_uiterst=later_dan_uiterst,
        )

    def bundel_maatregelen_ineens(
        self,
        instellingen: ModelInstellingen | None = None,
        uitvoeren: bool = True,
        direct_doorvoeren: bool = False,
    ) -> LpSyncProject:
        """Maak een synchronisatiemodel van de maatregelplanning."""
        settings: ModelInstellingen = instellingen or ModelInstellingen()

        builder = LpBuilder(
            duration_scale=settings.tijdsduur_naar_jaar,
            force_sync=settings.maatregel_synchronisatie.forceer_gelijk_starten,
            movement_objective=0,
            dynamic_movement_objective=settings.maatregel_verschuiving.dynamische_functie(
                self.maintenance_naar_geplande_maatregel
            ),
            concurrent_objective=settings.maatregel_synchronisatie.jaar_samenvallen,
            pair_objective=settings.maatregel_synchronisatie.dynamische_combi(
                self.maintenance_naar_geplande_maatregel
            ),
            pair_exclusions=settings.maatregel_synchronisatie.dynamische_uitsluiting(
                self.maintenance_naar_geplande_maatregel
            ),
            only_positive=False,
            silent=not settings.model_output,
        )
        builder.lp.setOptionValue("kkt_tolerance", settings.score_precisie)

        lp_sync = LpSyncProject.build(builder, self.project)

        if uitvoeren:
            lp_sync.run()

            if direct_doorvoeren:
                if lp_sync.model_status == HighsModelStatus.kOptimal:
                    self.voer_bundeling_door(lp_sync, new=False)
                else:
                    raise RuntimeError("Model heeft geen optimale oplossing kunnen vinden.")

        return lp_sync

    def bundel_maatregelen_per_kolk(
        self,
        instellingen: ModelInstellingen | None = None,
        uitvoeren: bool = True,
        direct_doorvoeren: bool = False,
    ) -> dict[UUID, LpSyncProject]:
        """Maak een synchronisatiemodel van de maatregelplanning."""
        settings: ModelInstellingen = instellingen or ModelInstellingen()

        builder = LpBuilder(
            duration_scale=settings.tijdsduur_naar_jaar,
            force_sync=settings.maatregel_synchronisatie.forceer_gelijk_starten,
            movement_objective=0,
            dynamic_movement_objective=settings.maatregel_verschuiving.dynamische_functie(
                self.maintenance_naar_geplande_maatregel
            ),
            concurrent_objective=settings.maatregel_synchronisatie.jaar_samenvallen,
            pair_objective=settings.maatregel_synchronisatie.dynamische_combi(
                self.maintenance_naar_geplande_maatregel
            ),
            pair_exclusions=settings.maatregel_synchronisatie.dynamische_uitsluiting(
                self.maintenance_naar_geplande_maatregel
            ),
            only_positive=False,
            silent=not settings.model_output,
        )
        builder.lp.setOptionValue("kkt_tolerance", settings.score_precisie)

        lp_syncs: dict[UUID, LpSyncProject] = dict()

        logger.info(f"Optimalisatie voor {len(self.project.systems)} beheerobjecten")
        for sys in self.project.systems:
            lp_sync = LpSyncProject(
                builder, uuid=self.project.uuid, systems=[LpSyncSystem.build(builder, sys)]
            )
            logger.info(
                f"'{sys.name}' Maatregelen ter optimalisatie: "
                f"{len(sys.get_unordered_maintenance())}"
            )

            if uitvoeren:
                logger.info(f"'{sys.name}' Model voor wordt uitgevoerd...")

                lp_sync.run()
                score_na = lp_sync.objective
                logger.info(f"'{sys.name}' Score: {score_na}")

                if direct_doorvoeren:
                    logger.info(f"'{sys.name}' Bundeling wordt doorgevoerd...")
                    if lp_sync.model_status == HighsModelStatus.kOptimal:
                        self.voer_bundeling_door(lp_sync, new=False)
                    else:
                        logger.warning(
                            f"Model voor '{sys.name}' heeft geen optimale oplossing kunnen vinden."
                        )
            lp_syncs[sys.uuid] = lp_sync

        return lp_syncs

    def gen_ingreep_procedures(self) -> Generator[raplan.Procedure, Never, None]:
        """Genereer de RaPlan `Procedure` objecten voor alle ingrepen op objecten."""
        for proc in self.project.gen_procedures(uuid_fn=lambda _: uuid4()):
            yield proc

    def pakket_id(self, maintenance: list[raplan.Maintenance]) -> UUID:
        """Bereken een stabiel pakket UUID op basis van de maatregel-inhoud."""

        result = b""
        for m in maintenance:
            maatregel = self.maintenance_naar_geplande_maatregel[m.uuid]
            uuid = UUID(maatregel.uuid)
            result += uuid.bytes
        return uuid5(NAMESPACE_DNS, result.hex())

    def voer_bundeling_door(self, lp_sync: LpSyncProject, new: bool = True) -> "RwsProject":
        """Voer de bundeling door in het interne RaPlan project en wijzig de maatregelplanning."""

        rws = deepcopy(self) if new else self
        start = rws.project.horizon.start
        lp_sync.apply_to(rws.project, new=False)  # Handled by deepcopy above.

        for proc in rws.gen_ingreep_procedures():
            ingreep_id = str(proc.uuid) if len(proc.maintenance) > 1 else None
            for m in proc.maintenance:
                gep: GeplandeMaatregel = rws.maintenance_naar_geplande_maatregel[m.uuid]
                gep.pakket_id = ingreep_id

                jaar = int(m.time + start)
                if jaar != gep.gewenst_uitvoeringsjaar:
                    gep.gewenst_uitvoeringsjaar = jaar
                    gep.gepland_uitvoeringsjaar = jaar
                    gep.gepland_uitvoeringsjaar_reden = "bundeling"

        return rws

    def plan_ingrepen(
        self,
        instellingen: ModelInstellingen | None = None,
        uitvoeren: bool = True,
        direct_doorvoeren: bool = False,
    ) -> LpProcedureProject:
        """Maak een optimalisatiemodel voor de ingrepen (gebundelde maatregelen)."""

        settings: ModelInstellingen = instellingen or ModelInstellingen()

        ingrepen: dict[UUID, raplan.Procedure] = {p.uuid: p for p in self.gen_ingreep_procedures()}

        builder = LpBuilder(
            duration_scale=settings.tijdsduur_naar_jaar,
            force_sync=False,
            movement_objective=0,
            dynamic_movement_objective=settings.maatregel_verschuiving.dynamische_functie(
                self.maintenance_naar_geplande_maatregel
            ),
            concurrent_objective=settings.maatregel_synchronisatie.jaar_samenvallen,
            pair_objective=settings.ingreep_instellingen.dynamische_combi(
                ingrepen,
                self.maintenance_naar_geplande_maatregel,
            ),
            pair_exclusions=settings.ingreep_instellingen.dynamische_uitsluiting(
                ingrepen, self.maintenance_naar_geplande_maatregel
            ),
            only_positive=False,
            silent=not settings.model_output,
        )
        builder.lp.setOptionValue("kkt_tolerance", settings.score_precisie)

        lp_proj = LpProcedureProject.build(builder, self.project)

        if uitvoeren:
            lp_proj.run()

            if direct_doorvoeren:
                if lp_proj.model_status == HighsModelStatus.kOptimal:
                    lp_proj.apply_to(self.project)

                else:
                    raise RuntimeError("Model heeft geen optimale oplossing kunnen vinden.")

        return lp_proj

    def voer_ingreep_herplanning(
        self, lp_proc: LpProcedureProject, new: bool = True
    ) -> "RwsProject":
        """Voer een optimalisatie door van de ingrepen/procedures."""
        rws = deepcopy(self) if new else self
        start = rws.project.horizon.start
        lp_proc.apply_to(rws.project, new=False)  # Handled by deepcopy above.

        for m in rws.project.gen_maintenance():
            gep: GeplandeMaatregel = rws.maintenance_naar_geplande_maatregel[m.uuid]
            jaar = int(m.time + start)
            if jaar != gep.gewenst_uitvoeringsjaar:
                gep.gewenst_uitvoeringsjaar = jaar
                gep.gepland_uitvoeringsjaar = jaar
                gep.gepland_uitvoeringsjaar_reden = "kolkoverstijdend"

        return rws
