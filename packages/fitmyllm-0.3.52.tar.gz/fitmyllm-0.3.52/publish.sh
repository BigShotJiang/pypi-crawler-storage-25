#!/bin/bash
# Auto-bump patch version, build, and upload to PyPI.
# Called by Claude Code hook after git push, or manually.
set -e

CLI_DIR="$(cd "$(dirname "$0")" && pwd)"
PYPROJECT="$CLI_DIR/pyproject.toml"
MAIN_PY="$CLI_DIR/fitmyllm/__main__.py"

# Guard: skip if last commit is already a version bump
LAST_MSG=$(git log -1 --pretty=%s 2>/dev/null || echo "")
if [[ "$LAST_MSG" == chore\(cli\):\ bump* ]]; then
    echo '{"suppressOutput": true}'
    exit 0
fi

# Read current version
CURRENT=$(grep -oP 'version = "\K[0-9]+\.[0-9]+\.[0-9]+' "$PYPROJECT")
if [ -z "$CURRENT" ]; then
    echo "Cannot read version from $PYPROJECT" >&2
    exit 1
fi

# Bump patch
IFS='.' read -r MAJOR MINOR PATCH <<< "$CURRENT"
PATCH=$((PATCH + 1))
NEW="$MAJOR.$MINOR.$PATCH"

# Update both files
sed -i "s/version = \"$CURRENT\"/version = \"$NEW\"/" "$PYPROJECT"
sed -i "s/__version__ = \"$CURRENT\"/__version__ = \"$NEW\"/" "$MAIN_PY"

# Commit and push the version bump
cd "$CLI_DIR/.."
git add "$PYPROJECT" "$MAIN_PY"
git -c commit.gpgsign=false commit -m "chore(cli): bump version to $NEW"
git push origin main

# Build and upload
cd "$CLI_DIR"
rm -rf dist/
python -m build
twine upload dist/fitmyllm-${NEW}*

echo "{\"systemMessage\": \"Published fitmyllm $NEW to PyPI\"}"
