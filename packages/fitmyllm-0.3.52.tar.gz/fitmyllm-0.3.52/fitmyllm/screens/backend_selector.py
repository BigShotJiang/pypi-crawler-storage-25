"""Backend selector screen — choose which inference engine to use."""

from __future__ import annotations

from textual.app import ComposeResult
from textual.screen import Screen
from textual.widgets import Header, Footer, Static, DataTable
from textual.binding import Binding
from textual import work

from .. import config
from ..backends.registry import _KNOWN_BACKENDS, detect_backends


class BackendSelectorScreen(Screen):
    """Let the user pick their preferred inference backend."""

    DEFAULT_CSS = "BackendSelectorScreen { layout: vertical; }"

    BINDINGS = [
        Binding("escape", "app.pop_screen", "Back", show=True),
    ]

    def __init__(self) -> None:
        super().__init__()
        self._backends: list[dict] = []

    def compose(self) -> ComposeResult:
        yield Header(show_clock=False)
        yield Static(
            "\n  [bold]Backend Selector[/]  [dim]Detecting engines...[/]\n",
            id="bs-header",
        )
        yield DataTable(id="bs-table", cursor_type="row")
        yield Static("", id="bs-hint")
        yield Footer()

    def on_mount(self) -> None:
        table = self.query_one("#bs-table", DataTable)
        table.add_columns("", "Engine", "URL", "Models")
        self._detect()

    @work(thread=True)
    def _detect(self) -> None:
        """Probe all known backends and build the table."""
        preferred = config.get_preferred_backend()
        available = detect_backends()
        available_names = {b.name for b in available}

        entries: list[dict] = []
        for name, url, _cls in _KNOWN_BACKENDS:
            is_up = name in available_names
            model_count = ""
            if is_up:
                for b in available:
                    if b.name == name:
                        try:
                            model_count = str(len(b.list_models()))
                        except Exception:
                            model_count = "?"
                        break

            entries.append({
                "name": name,
                "url": url,
                "up": is_up,
                "models": model_count,
                "preferred": name == preferred,
            })

        self._backends = entries
        self.app.call_from_thread(self._populate, preferred)

    def _populate(self, preferred: str | None) -> None:
        table = self.query_one("#bs-table", DataTable)
        table.clear()

        n_up = sum(1 for e in self._backends if e["up"])
        self.query_one("#bs-header", Static).update(
            f"\n  [bold]Backend Selector[/]  "
            f"[dim]{n_up}/{len(self._backends)} engines online · "
            f"Enter=select · Esc=back[/]\n"
        )

        for e in self._backends:
            if e["preferred"]:
                marker = "[bold cyan]*[/]"
            elif e["up"]:
                marker = "[green]✓[/]"
            else:
                marker = "[dim]-[/]"

            name_style = "bold" if e["up"] else "dim"
            models = e["models"] if e["up"] else "[dim]offline[/]"
            url_text = e["url"] if e["up"] else f"[dim]{e['url']}[/]"

            table.add_row(
                marker,
                f"[{name_style}]{e['name']}[/]",
                url_text,
                models,
            )

        hint = "  [dim]* = preferred   ✓ = online   - = offline[/]"
        if preferred:
            hint += f"   [dim]Current: [bold]{preferred}[/][/]"
        self.query_one("#bs-hint", Static).update(hint)
        table.focus()

    def on_data_table_row_selected(self, event: DataTable.RowSelected) -> None:
        if not self._backends or event.cursor_row >= len(self._backends):
            return
        entry = self._backends[event.cursor_row]
        name = entry["name"]

        if not entry["up"]:
            self.notify(
                f"{name} is offline — start it first, then select it here",
                severity="warning",
                timeout=3,
            )
            return

        config.save_preferred_backend(name)
        self.notify(f"Backend set to {name}", timeout=3)
        self.app.pop_screen()
