"""Enterprise input screen — concurrent users, usage pattern, multi-model."""

from textual.app import ComposeResult
from textual.screen import Screen
from textual.widgets import Header, Footer, Static, Input, Label, Select, DataTable
from textual.containers import VerticalScroll
from textual.binding import Binding
from textual import work

from .. import api
from ..widgets import get_key

USAGE_PATTERNS = [
    ("24/7 Sustained", "sustained"),
    ("Business Hours (8h/day)", "business"),
    ("Bursty Peaks", "bursty"),
]

BPW_OPTIONS = [
    ("Q4 (4.5)", "4.5"), ("Q6 (6.5)", "6.5"), ("Q8 (8.5)", "8.5"), ("FP16 (16)", "16"),
]


class EnterpriseInputScreen(Screen):
    DEFAULT_CSS = "EnterpriseInputScreen { layout: vertical; }"

    BINDINGS = [
        Binding("enter", "submit", "Go", show=True),
        Binding("a", "add_model", "Add Model", show=True),
        Binding("d", "remove_model", "Remove", show=True),
        Binding("escape", "app.pop_screen", "Back"),
    ]

    def __init__(self, model_id: str, model_name: str):
        super().__init__()
        self.model_id = model_id
        self.model_name = model_name
        self._additional_models: list[dict] = []

    def compose(self) -> ComposeResult:
        yield Header(show_clock=False)
        yield Static(f"\n  [bold]Enterprise — {self.model_name}[/]  [dim](primary model)[/]\n")
        yield Label("  Concurrent users:")
        yield Input(value="10", id="inp-users", type="integer")
        yield Label("\n  Usage pattern:")
        yield Select(USAGE_PATTERNS, value="sustained", id="sel-pattern", allow_blank=False)
        yield Label("\n  GPU override (optional):")
        yield Input(placeholder="e.g. H100, A100, RTX 4090", id="inp-gpu")
        yield Static("\n  ─── [bold cyan]Multi-Model Serving[/] ───")
        yield Static("  [dim]Press [bold]a[/bold] to add models, [bold]d[/bold] to remove[/]")
        yield DataTable(id="multi-model-table", cursor_type="row")
        yield Static("\n  [dim]Add model name below, then press [bold]a[/bold]:[/]")
        yield Input(placeholder="Model name to co-host (e.g. llama3.2:3b)", id="inp-add-model")
        yield Static("\n  [dim]Press Enter to size infrastructure[/]")
        yield Footer()

    def on_mount(self) -> None:
        table = self.query_one("#multi-model-table", DataTable)
        table.add_columns("Model", "Params", "Quant", "Traffic %")
        self.query_one("#inp-users", Input).focus()

    def action_add_model(self) -> None:
        """Add an additional model for multi-model serving."""
        inp = self.query_one("#inp-add-model", Input)
        query = inp.value.strip()
        if not query:
            self.notify("Type a model name first", severity="warning")
            inp.focus()
            return
        self._search_and_add(query)

    @work(thread=True)
    def _search_and_add(self, query: str) -> None:
        key = get_key()
        if not key:
            return
        try:
            results = api.search_models(key, query)
            if results:
                m = results[0]
                # Default: equal traffic share
                n = len(self._additional_models) + 2  # +1 primary +1 new
                share = round(1.0 / n, 2)
                self._additional_models.append({
                    "model_name": m["id"],
                    "name": m["name"],
                    "params_b": m["params_b"],
                    "bpw": 4.5,
                    "traffic_share": share,
                })
                # Normalize shares
                total_extra = sum(am["traffic_share"] for am in self._additional_models)
                if total_extra > 0.9:
                    for am in self._additional_models:
                        am["traffic_share"] = round(0.9 / len(self._additional_models), 2)
                self.app.call_from_thread(self._refresh_table)
                self.app.call_from_thread(self._clear_input)
            else:
                self.app.call_from_thread(self.notify, f'Model "{query}" not found', severity="warning")
        except Exception as e:
            self.app.call_from_thread(self.notify, str(e), severity="error")

    def _clear_input(self) -> None:
        self.query_one("#inp-add-model", Input).value = ""

    def _refresh_table(self) -> None:
        table = self.query_one("#multi-model-table", DataTable)
        table.clear()
        primary_share = max(0.1, 1.0 - sum(am["traffic_share"] for am in self._additional_models))
        table.add_row(
            f"[bold]{self.model_name}[/] [dim](primary)[/]",
            "", "", f"{int(primary_share * 100)}%",
        )
        for am in self._additional_models:
            table.add_row(
                am["name"],
                f'{am["params_b"]}B',
                f'Q4 ({am["bpw"]} bpw)',
                f'{int(am["traffic_share"] * 100)}%',
            )

    def action_remove_model(self) -> None:
        """Remove the last additional model."""
        if self._additional_models:
            self._additional_models.pop()
            self._refresh_table()

    def action_submit(self) -> None:
        try:
            users = int(self.query_one("#inp-users", Input).value)
        except (ValueError, Exception):
            users = 10
        try:
            pattern = str(self.query_one("#sel-pattern", Select).value)
        except Exception:
            pattern = "sustained"

        additional = [
            {"model_name": am["model_name"], "bpw": am["bpw"], "traffic_share": am["traffic_share"]}
            for am in self._additional_models
        ] if self._additional_models else None

        from .enterprise import EnterpriseScreen
        self.app.push_screen(EnterpriseScreen(
            self.model_id, self.model_name, users, pattern, additional
        ))

    def on_input_submitted(self, event: Input.Submitted) -> None:
        if event.input.id == "inp-add-model":
            self.action_add_model()
        else:
            self.action_submit()
