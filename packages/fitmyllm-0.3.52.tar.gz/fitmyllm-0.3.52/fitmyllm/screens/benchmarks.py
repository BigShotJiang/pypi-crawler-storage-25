"""Benchmark leaderboard screen — browse model benchmarks."""

from textual.app import ComposeResult
from textual.screen import Screen
from textual.widgets import Header, Footer, Static, DataTable, Select, Label
from textual.containers import Horizontal, Vertical, VerticalScroll
from textual.binding import Binding
from textual import work

from .. import api
from ..widgets import get_key

BENCH_SORT = [
    ("MMLU-PRO", "mmlu_pro"), ("MATH", "math"), ("HumanEval", "humaneval"),
    ("MBPP", "mbpp"), ("IFEval", "ifeval"), ("BBH", "bbh"),
    ("GPQA", "gpqa"), ("Arena ELO", "arena_elo"),
    ("LiveCodeBench", "livecodebench"), ("AIME", "aime"),
]


def _fmt(val) -> str:
    if val is None:
        return "—"
    if isinstance(val, float):
        return f"{val:.1f}"
    return str(val)


class BenchmarkScreen(Screen):
    DEFAULT_CSS = "BenchmarkScreen { layout: vertical; }"

    BINDINGS = [
        Binding("escape", "app.pop_screen", "Back"),
    ]

    def __init__(self):
        super().__init__()
        self._models: list[dict] = []
        self._loaded = False

    def compose(self) -> ComposeResult:
        yield Header(show_clock=False)
        yield Static("\n  [bold]Benchmark Leaderboard[/]  [dim]Loading models...[/]\n", id="bench-header")
        yield DataTable(id="bench-table", cursor_type="row")
        yield Footer()

    def on_mount(self) -> None:
        table = self.query_one("#bench-table", DataTable)
        table.add_columns("#", "Model", "Params", "MMLU", "MATH", "Human", "MBPP", "IFEval", "BBH", "GPQA", "ELO")
        self._load()

    @work(thread=True)
    def _load(self) -> None:
        key = get_key()
        if not key:
            return
        try:
            models = api.get_all_models(key)
            with_bench = [m for m in models if m.get("benchmarks") and
                          any(v is not None for v in m.get("benchmarks", {}).values())]
            self._models = with_bench
            self._loaded = True
            self.app.call_from_thread(self._refresh_table, "mmlu_pro")
        except Exception as e:
            self.app.call_from_thread(self.notify, str(e), severity="error")

    def on_select_changed(self, event: Select.Changed) -> None:
        if self._loaded:
            self._refresh_table(str(event.value))

    def _refresh_table(self, sort_key: str = "mmlu_pro") -> None:
        self.query_one("#bench-header", Static).update(
            f"\n  [bold]Benchmark Leaderboard[/]  [dim]{len(self._models)} models[/]\n"
        )

        sorted_models = sorted(
            self._models,
            key=lambda m: m.get("benchmarks", {}).get(sort_key) or 0,
            reverse=True,
        )

        table = self.query_one("#bench-table", DataTable)
        table.clear()
        for i, m in enumerate(sorted_models[:50]):
            b = m.get("benchmarks", {})
            table.add_row(
                str(i + 1),
                m.get("name", ""),
                f'{m.get("params_b", 0)}B',
                _fmt(b.get("mmlu_pro")),
                _fmt(b.get("math")),
                _fmt(b.get("humaneval")),
                _fmt(b.get("mbpp")),
                _fmt(b.get("ifeval")),
                _fmt(b.get("bbh")),
                _fmt(b.get("gpqa")),
                _fmt(b.get("arena_elo")),
            )
        table.focus()
