"""Ollama install screen — live progress for ollama pull."""

import subprocess
import re

from rich.markup import escape

from textual.app import ComposeResult
from textual.screen import Screen
from textual.widgets import Header, Footer, Static
from textual.containers import VerticalScroll
from textual.binding import Binding
from textual import work

# Strip ANSI escape sequences
_ANSI_RE = re.compile(r'\x1b\[[0-9;]*[a-zA-Z]|\x1b\[\?[0-9;]*[a-zA-Z]')


def _clean(line: str) -> str:
    """Remove ANSI escapes and control chars from ollama output."""
    return _ANSI_RE.sub('', line).strip()


def _parse_progress(raw: str) -> tuple[str, str, int]:
    """Parse ollama pull output line. Returns (phase, detail, percent)."""
    line = _clean(raw)
    if not line:
        return ("", "", -1)

    # "pulling abc123...  45% ▕████     ▏ 1.2 GB/3.4 GB  22 MB/s  1m30s"
    m = re.search(r'(\d+)%', line)
    pct = int(m.group(1)) if m else -1

    if line.startswith("pulling manifest"):
        return ("manifest", "Fetching manifest...", -1)
    elif line.startswith("pulling"):
        # Extract size info if present
        size_m = re.search(r'([\d.]+\s*[GMKT]B)\s*/\s*([\d.]+\s*[GMKT]B)', line)
        if size_m:
            detail = f"{size_m.group(1)} / {size_m.group(2)}"
        else:
            detail = ""
        speed_m = re.search(r'(\d+\s*[GMKT]B/s)', line)
        speed = speed_m.group(1) if speed_m else ""
        eta_m = re.search(r'(\d+m\d+s|\d+s)', line)
        eta = eta_m.group(1) if eta_m else ""
        parts = [p for p in [detail, speed, eta] if p]
        return ("download", "  ".join(parts), pct)
    elif "verifying" in line.lower():
        return ("verify", "Verifying SHA256...", -1)
    elif "writing" in line.lower():
        return ("write", "Writing manifest...", -1)
    elif "success" in line.lower():
        return ("done", "Complete!", 100)
    else:
        return ("other", line, pct)


class OllamaInstallScreen(Screen):
    DEFAULT_CSS = "OllamaInstallScreen { layout: vertical; }"

    BINDINGS = [
        Binding("c", "start_chat", "Chat", show=True),
        Binding("escape", "app.pop_screen", "Back"),
    ]

    def __init__(self, command: str):
        super().__init__()
        self.command = command
        self._installed_tag: str | None = None

    def compose(self) -> ComposeResult:
        yield Header(show_clock=False)
        yield Static(
            f"\n  [bold]Installing:[/] [cyan]{escape(self.command.split()[-1])}[/]\n",
            id="install-title",
        )
        yield Static("  [dim]Connecting...[/]", id="install-phase")
        yield Static("", id="install-bar")
        yield Static("", id="install-detail")
        yield Footer()

    def on_mount(self) -> None:
        self._run_install()

    def _set_phase(self, text: str) -> None:
        try:
            self.query_one("#install-phase", Static).update(text)
        except Exception:
            pass

    def _set_bar(self, text: str) -> None:
        try:
            self.query_one("#install-bar", Static).update(text)
        except Exception:
            pass

    def _set_detail(self, text: str) -> None:
        try:
            self.query_one("#install-detail", Static).update(text)
        except Exception:
            pass

    def _render_bar(self, pct: int) -> str:
        if pct < 0:
            return ""
        w = 40
        filled = round(pct / 100 * w)
        bar = "█" * filled + "░" * (w - filled)
        color = "green" if pct >= 80 else "cyan" if pct >= 40 else "blue"
        return f"  [{color}]{bar}[/] [bold]{pct}%[/]"

    def action_start_chat(self) -> None:
        if not self._installed_tag:
            self.notify("Install a model first", severity="warning")
            return
        from .chat import ChatScreen
        self.app.push_screen(ChatScreen(self._installed_tag))

    @work(thread=True)
    def _run_install(self) -> None:
        try:
            proc = subprocess.Popen(
                self.command.split(),
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
            )

            last_phase = ""
            for raw_line in iter(proc.stdout.readline, ""):
                phase, detail, pct = _parse_progress(raw_line)
                if not phase:
                    continue

                if phase != last_phase:
                    last_phase = phase
                    phase_labels = {
                        "manifest": "  [dim]Fetching manifest...[/]",
                        "download": "  [cyan]Downloading model...[/]",
                        "verify": "  [yellow]Verifying integrity...[/]",
                        "write": "  [yellow]Writing to disk...[/]",
                        "done": "  [green]✓ Done![/]",
                    }
                    self.app.call_from_thread(
                        self._set_phase,
                        phase_labels.get(phase, f"  [dim]{escape(detail)}[/]"),
                    )

                if pct >= 0:
                    self.app.call_from_thread(self._set_bar, self._render_bar(pct))
                if detail and phase == "download":
                    self.app.call_from_thread(self._set_detail, f"  [dim]{escape(detail)}[/]")

            proc.wait()

            tag = self.command.split()[-1]
            if proc.returncode == 0:
                self._installed_tag = tag
                self.app.call_from_thread(self._set_phase, "  [green]✓ Installed successfully![/]")
                self.app.call_from_thread(self._set_bar, "")
                self.app.call_from_thread(
                    self._set_detail,
                    f"\n  Run: [cyan]ollama run {escape(tag)}[/]\n\n"
                    f"  [dim]Press [bold]c[/bold] to chat · [bold]escape[/bold] to go back[/]",
                )
            else:
                self.app.call_from_thread(
                    self._set_phase,
                    f"  [red]✗ Failed[/] (exit code {proc.returncode})",
                )
                self.app.call_from_thread(self._set_bar, "")
                self.app.call_from_thread(
                    self._set_detail,
                    f"\n  [dim]Try manually:[/] [cyan]{escape(self.command)}[/]",
                )

        except FileNotFoundError:
            self.app.call_from_thread(
                self._set_phase,
                "  [red]Ollama not found.[/] Install from https://ollama.com",
            )
        except Exception as e:
            self.app.call_from_thread(
                self._set_phase, f"  [red]Error:[/] {escape(str(e))}"
            )
