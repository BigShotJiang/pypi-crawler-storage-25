"""Install screen — choose quantization, then engine, then install."""

import shutil
import subprocess

from textual.app import ComposeResult
from textual.screen import Screen
from textual.widgets import Header, Footer, Static, DataTable
from textual.binding import Binding
from textual.css.query import NoMatches


def _get_installed_ollama_tags() -> set[str]:
    """Get set of locally installed ollama model tags."""
    try:
        result = subprocess.run(
            ["ollama", "list"], capture_output=True, text=True, timeout=5,
        )
        if result.returncode != 0:
            return set()
        tags = set()
        for line in result.stdout.strip().split("\n")[1:]:  # skip header
            parts = line.split()
            if parts:
                tags.add(parts[0].lower())
        return tags
    except Exception:
        return set()


class InstallScreen(Screen):
    """Step 1: Choose quantization from all available options."""

    DEFAULT_CSS = "InstallScreen { layout: vertical; }"

    BINDINGS = [
        Binding("escape", "app.pop_screen", "Back", show=True),
    ]

    def __init__(self, model: dict, rec: dict | None = None):
        super().__init__()
        self.model = model
        self.rec = rec

    def compose(self) -> ComposeResult:
        yield Header(show_clock=False)
        name = self.model.get("name", "")
        yield Static(f"\n  [bold]Install {name}[/]\n")

        quants = self.model.get("quantizations", [])
        if quants:
            # Check which are already installed
            installed = _get_installed_ollama_tags()

            yield Static("  [dim]Choose a quantization:[/]\n")
            table = DataTable(id="quant-table", cursor_type="row")
            table.add_columns("", "Quant", "BPW", "Size", "VRAM", "Quality", "Ollama Tag")
            rec_level = ""
            if self.rec:
                rec_level = self.rec.get("quant", {}).get("level", "")
            params_b = self.model.get("params_b", 0)
            for q in quants:
                level = q.get("level", "")
                bpw = q.get("bpw", 0)
                file_gb = params_b * bpw / 8
                vram_gb = q.get("vram_mb", 0) / 1024
                quality = int(q.get("quality", 0) * 100)
                tag = q.get("ollama_tag", "")

                # Status: installed, recommended, or empty
                is_installed = tag and tag.lower() in installed
                is_rec = level == rec_level
                if is_installed:
                    status = "[green]✓ installed[/]"
                elif is_rec:
                    status = "[cyan]★ recommended[/]"
                else:
                    status = ""

                table.add_row(
                    status,
                    level,
                    f"{bpw:.1f}",
                    f"{file_gb:.1f}GB",
                    f"{vram_gb:.1f}GB",
                    f"{quality}%",
                    tag if tag else "—",
                )
            yield table
            yield Static("\n  [dim]Select a quantization and press Enter[/]")

            # Count installed
            n_installed = sum(
                1 for q in quants
                if q.get("ollama_tag", "").lower() in installed
            )
            if n_installed:
                yield Static(f"  [green]{n_installed} quantization(s) already installed[/]")
        else:
            yield Static("  [dim]No quantization data available, using default[/]\n")
            tag = self.model.get("ollama_base", "")
            self._go_to_engine(tag, "default")

        yield Footer()

    def on_mount(self) -> None:
        try:
            table = self.query_one("#quant-table", DataTable)
            table.focus()
            rec_level = ""
            if self.rec:
                rec_level = self.rec.get("quant", {}).get("level", "")
            if rec_level:
                quants = self.model.get("quantizations", [])
                for i, q in enumerate(quants):
                    if q.get("level") == rec_level:
                        table.move_cursor(row=i)
                        break
        except NoMatches:
            pass

    def on_data_table_row_selected(self, event: DataTable.RowSelected) -> None:
        quants = self.model.get("quantizations", [])
        if not quants or event.cursor_row >= len(quants):
            return
        selected_quant = quants[event.cursor_row]
        self.app.push_screen(EngineSelectScreen(self.model, selected_quant))

    def _go_to_engine(self, tag: str, level: str) -> None:
        quant = {"level": level, "ollama_tag": tag, "vram_mb": 0, "bpw": 4.5, "quality": 0.9}
        self.app.push_screen(EngineSelectScreen(self.model, quant))


class EngineSelectScreen(Screen):
    """Step 2: Choose inference engine for the selected quantization."""

    DEFAULT_CSS = "EngineSelectScreen { layout: vertical; }"

    BINDINGS = [
        Binding("escape", "app.pop_screen", "Back", show=True),
    ]

    def __init__(self, model: dict, quant: dict):
        super().__init__()
        self.model = model
        self.quant = quant

    def compose(self) -> ComposeResult:
        yield Header(show_clock=False)
        name = self.model.get("name", "")
        level = self.quant.get("level", "")
        vram_gb = self.quant.get("vram_mb", 0) / 1024
        quality = int(self.quant.get("quality", 0) * 100)

        yield Static(
            f"\n  [bold]Install {name}[/]  [cyan]{level}[/]  "
            f"[dim]{vram_gb:.1f}GB  {quality}% quality[/]\n"
        )

        ollama_tag = self.quant.get("ollama_tag", "")
        ollama_base = self.model.get("ollama_base", "")
        hf_id = self.model.get("hf_id", "")
        gguf = self.model.get("gguf_sources", [])

        # Sanitize ollama tag
        if ollama_tag and ollama_tag.count(":") >= 2:
            parts = ollama_tag.split(":")
            ollama_tag = parts[0] + ":" + "-".join(parts[1:])

        # Check if already installed (local GGUF or Ollama)
        from ..models.store import get_inventory
        local_gguf = any(
            level.lower() in entry.get("quant_level", "").lower()
            and self.model.get("name", "").lower() in entry.get("name", "").lower()
            for entry in get_inventory()
        )
        installed = _get_installed_ollama_tags()
        is_installed = ollama_tag and ollama_tag.lower() in installed

        if local_gguf:
            yield Static(f"  [green]✓ Already downloaded as GGUF![/]\n")
        elif is_installed:
            yield Static(f"  [green]✓ Already installed in Ollama[/]\n")

        engines: list[tuple[str, str]] = []

        # --- Primary: direct GGUF download (no Ollama dependency) ---
        if gguf:
            engines.append(("Download GGUF", f"Download {level} from {gguf[0]['repo']}"))
        if shutil.which("llama-cli") and gguf:
            engines.append(("llama.cpp", f"llama-cli -m <{level}.gguf> -ngl 99 -c 4096"))

        # --- Secondary: other engines ---
        if shutil.which("vllm") and hf_id:
            engines.append(("vLLM", f"vllm serve {hf_id}"))
        if shutil.which("lms") and hf_id:
            engines.append(("LM Studio", f"lms load {hf_id}"))
        if shutil.which("koboldcpp") and gguf:
            engines.append(("KoboldCpp", f"koboldcpp <{level}.gguf> --gpulayers 99"))
        if shutil.which("jan") and hf_id:
            engines.append(("Jan", f"jan run {hf_id}"))
        if shutil.which("docker"):
            docker_tag = ollama_tag or ollama_base
            if docker_tag:
                engines.append(("Docker", f"docker model run {docker_tag}"))

        # --- Fallback: Ollama (last resort) ---
        if shutil.which("ollama"):
            if ollama_tag:
                if is_installed:
                    engines.append(("Ollama (run)", f"ollama run {ollama_tag}"))
                else:
                    engines.append(("Ollama", f"ollama pull {ollama_tag}"))
            elif ollama_base:
                engines.append(("Ollama", f"ollama pull {ollama_base}"))

        if not engines:
            yield Static("  [yellow]No download source or engine found.[/]\n")
            yield Static("  Install llama.cpp to run models directly:\n")
            yield Static("  [cyan]• llama.cpp[/]    → https://github.com/ggerganov/llama.cpp")
            yield Static("  [cyan]• LM Studio[/]    → https://lmstudio.ai")
            yield Static("  [cyan]• vLLM[/]         → pip install vllm")
            yield Static("  [cyan]• KoboldCpp[/]    → https://github.com/LostRuins/koboldcpp\n")
        else:
            table = DataTable(id="engine-table", cursor_type="row")
            table.add_columns("Engine", "Command")
            for eng, cmd in engines:
                table.add_row(eng, f"[cyan]{cmd}[/]")
            yield table
            yield Static("\n  [dim]Select and press Enter[/]")

        self._engines = engines
        self._ollama_tag = ollama_tag
        yield Footer()

    def on_mount(self) -> None:
        try:
            self.query_one("#engine-table", DataTable).focus()
        except NoMatches:
            pass

    def on_data_table_row_selected(self, event: DataTable.RowSelected) -> None:
        if not self._engines:
            return
        eng, cmd = self._engines[event.cursor_row]
        if "Ollama (run)" in eng:
            # Already installed — open chat
            from .chat import ChatScreen
            self.app.push_screen(ChatScreen(self._ollama_tag))
        elif eng == "Ollama" and cmd.startswith("ollama pull"):
            from .ollama_install import OllamaInstallScreen
            self.app.push_screen(OllamaInstallScreen(cmd))
        elif eng == "Download GGUF":
            self._start_gguf_download()
        elif eng.startswith("  "):
            self.notify(f"Open: {cmd}", timeout=10)
        else:
            self.notify(f"Run: {cmd}", timeout=10)

    def _start_gguf_download(self) -> None:
        """Resolve GGUF URL and start download."""
        from ..models.download import resolve_gguf_url
        from .gguf_install import GGUFInstallScreen

        gguf_sources = self.model.get("gguf_sources", [])
        if not gguf_sources:
            self.notify("No GGUF source available", severity="warning")
            return

        repo = gguf_sources[0].get("repo", "")
        level = self.quant.get("level", "Q4_K_M")

        url = resolve_gguf_url(repo, level)
        if not url:
            self.notify(f"No {level} GGUF found in {repo}", severity="warning")
            return

        self.app.push_screen(GGUFInstallScreen(
            url=url,
            model_id=self.model.get("id", ""),
            model_name=self.model.get("name", ""),
            quant_level=level,
            repo=repo,
        ))
