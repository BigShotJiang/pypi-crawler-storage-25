"""Compare screen — side-by-side model comparison."""

from textual.app import ComposeResult
from textual.screen import Screen
from textual.widgets import Header, Footer, Static, DataTable
from textual.containers import VerticalScroll
from textual.binding import Binding

from ..widgets import bar, vbar, FIT_COLORS


class CompareScreen(Screen):
    """Compare 2-4 models side by side."""
    DEFAULT_CSS = "CompareScreen { layout: vertical; }"

    BINDINGS = [
        Binding("escape", "app.pop_screen", "Back", show=True),
    ]

    def __init__(self, models: list[dict]):
        """models: list of recommendation dicts from FindModelsScreen.recs"""
        super().__init__()
        self.models = models[:4]  # max 4

    def compose(self) -> ComposeResult:
        yield Header(show_clock=False)
        yield Static(f"\n  [bold]Compare Models[/]  [dim]({len(self.models)} models)[/]\n")
        yield VerticalScroll(Static("", id="compare-content"))
        yield Footer()

    def on_mount(self) -> None:
        self._refresh_content()

    def _refresh_content(self) -> None:
        models = self.models
        if not models:
            self.query_one("#compare-content", Static).update("  [dim]No models to compare[/]")
            return

        # Column widths
        label_w = 18
        col_w = 24
        n = len(models)

        def row(label: str, values: list[str]) -> str:
            cols = "".join(f"{v:<{col_w}}" for v in values)
            return f"  [dim]{label:<{label_w}}[/]{cols}\n"

        def header_row(values: list[str]) -> str:
            cols = "".join(f"[bold]{v:<{col_w}}[/]" for v in values)
            return f"  {'':>{label_w}}{cols}\n"

        lines = ""

        # Model names
        lines += header_row([r["model"]["name"] for r in models])
        lines += "  " + "─" * (label_w + col_w * n) + "\n"

        # Basic info
        lines += row("Provider", [r["model"]["provider"] for r in models])
        lines += row("Parameters", [f'{r["model"]["params_b"]}B' for r in models])
        lines += row("Architecture", [r["model"]["architecture"] for r in models])
        lines += row("Family", [r["model"].get("family", "—") for r in models])
        lines += "\n"

        # Quantization
        lines += row("Quantization", [r["quant"]["level"] for r in models])
        lines += row("Quality", [f'{int(r["quant"]["quality"] * 100)}%' for r in models])
        lines += row("VRAM (quant)", [f'{r["quant"]["vram_mb"] / 1024:.1f}GB' for r in models])
        lines += "\n"

        # Performance
        lines += "  ─── [bold cyan]Performance[/] ───\n"
        lines += row("Score", [
            f'{r["score"]}' for r in models
        ])
        lines += row("Speed", [
            f'~{r["speed_toks"]} tok/s' if r["speed_toks"] else "—"
            for r in models
        ])
        lines += row("Prefill", [
            f'~{r["prefill_tps"]} tok/s' if r.get("prefill_tps") else "—"
            for r in models
        ])
        lines += row("TTFT", [
            f'{r["ttft_ms"]}ms' if r.get("ttft_ms") else "—"
            for r in models
        ])
        lines += row("Load Time", [
            f'~{r["load_time_s"]}s' if r.get("load_time_s") else "—"
            for r in models
        ])
        lines += "\n"

        # VRAM
        lines += "  ─── [bold cyan]Memory[/] ───\n"
        lines += row("VRAM %", [f'{r["vram_percent"]}%' for r in models])
        lines += row("Total VRAM", [
            f'{r["vram_gb"]:.1f}GB' if r.get("vram_gb") else "—"
            for r in models
        ])
        lines += row("Model weights", [
            f'{r["model_vram_gb"]:.1f}GB' if r.get("model_vram_gb") else "—"
            for r in models
        ])
        lines += row("KV cache", [
            f'{r["kv_cache_gb"]:.1f}GB' if r.get("kv_cache_gb") else "—"
            for r in models
        ])
        lines += row("Mode", [r.get("inference_mode", "—") for r in models])
        lines += row("Fit", [
            f'[{FIT_COLORS.get(r.get("fit", ""), "")}]{r.get("fit", "—")}[/]'
            for r in models
        ])
        lines += "\n"

        # Warnings
        any_warnings = any(r.get("warnings") for r in models)
        if any_warnings:
            lines += "  ─── [bold cyan]Warnings[/] ───\n"
            for r in models:
                ws = r.get("warnings", [])
                name = r["model"]["name"]
                if ws:
                    for w in ws:
                        lines += f"  [yellow]⚠ {name}: {w}[/]\n"
            lines += "\n"

        # Visual bars
        lines += "  ─── [bold cyan]Visual Comparison[/] ───\n"
        lines += row("Score", [
            f'{bar(r["score"], 15)} {r["score"]}'
            for r in models
        ])
        lines += row("Speed", [
            f'{bar(min(100, (r["speed_toks"] or 0) * 1.2), 15)} {r["speed_toks"] or "—"}'
            for r in models
        ])
        lines += row("VRAM", [
            f'{vbar(r["vram_percent"], 15)} {r["vram_percent"]}%'
            for r in models
        ])

        lines += "\n  [dim]Press escape to go back[/]"

        self.query_one("#compare-content", Static).update(lines)
