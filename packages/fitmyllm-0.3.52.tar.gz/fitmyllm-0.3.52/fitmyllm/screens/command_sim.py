"""Command Simulator — interactive parameter tuning for inference commands."""

from textual.app import ComposeResult
from textual.screen import Screen
from textual.widgets import Header, Footer, Static, Select, Label, Input
from textual.containers import VerticalScroll, Horizontal, Vertical
from textual.binding import Binding

CONTEXT_OPTIONS = [
    ("2K", "2048"), ("4K", "4096"), ("8K", "8192"),
    ("16K", "16384"), ("32K", "32768"), ("64K", "65536"),
]

KV_QUANT_OPTIONS = [
    ("FP16", "fp16"), ("INT8 (Q8_0)", "q8_0"), ("INT4 (Q4_0)", "q4_0"),
]

BATCH_OPTIONS = [
    ("512", "512"), ("1024", "1024"), ("2048", "2048"), ("4096", "4096"),
]


class CommandSimScreen(Screen):
    """Interactive command builder with parameter tuning."""

    DEFAULT_CSS = "CommandSimScreen { layout: vertical; }"

    BINDINGS = [
        Binding("escape", "app.pop_screen", "Back", show=True),
    ]

    def __init__(self, model: dict, rec: dict | None = None):
        super().__init__()
        self.model = model
        self.rec = rec

    def compose(self) -> ComposeResult:
        yield Header(show_clock=False)
        name = self.model.get("name", "")
        yield Static(f"\n  [bold]Command Simulator — {name}[/]\n")

        with Horizontal():
            with VerticalScroll(id="sim-params"):
                yield Label("CONTEXT LENGTH")
                yield Select(CONTEXT_OPTIONS, value="4096", id="sim-context", allow_blank=False)
                yield Label("GPU LAYERS")
                yield Input(value="99", id="sim-ngl", placeholder="99 = all")
                yield Label("KV CACHE QUANT")
                yield Select(KV_QUANT_OPTIONS, value="fp16", id="sim-kvquant", allow_blank=False)
                yield Label("BATCH SIZE")
                yield Select(BATCH_OPTIONS, value="2048", id="sim-batch", allow_blank=False)
                yield Label("THREADS")
                yield Input(value="", id="sim-threads", placeholder="auto")
                yield Label("FLASH ATTENTION")
                yield Select([("Auto", "auto"), ("On", "on"), ("Off", "off")], value="auto", id="sim-flash", allow_blank=False)

            with Vertical():
                yield VerticalScroll(Static("", id="sim-output"))

        yield Footer()

    def on_mount(self) -> None:
        self._update_commands()

    def on_select_changed(self, event: Select.Changed) -> None:
        self._update_commands()

    def on_input_changed(self, event: Input.Changed) -> None:
        self._update_commands()

    def _update_commands(self) -> None:
        """Regenerate commands based on current parameters."""
        def val(sel_id: str, default: str = "") -> str:
            try:
                return str(self.query_one(f"#{sel_id}", Select).value)
            except Exception:
                return default

        def inp(inp_id: str, default: str = "") -> str:
            try:
                v = self.query_one(f"#{inp_id}", Input).value
                return v if v else default
            except Exception:
                return default

        ctx = val("sim-context", "4096")
        ngl = inp("sim-ngl", "99")
        kv_quant = val("sim-kvquant", "fp16")
        batch = val("sim-batch", "2048")
        threads = inp("sim-threads", "")
        flash = val("sim-flash", "auto")

        ollama_base = self.model.get("ollama_base", "")
        hf_id = self.model.get("hf_id", "")
        tag = ""
        if self.rec:
            tag = self.rec.get("quant", {}).get("ollama_tag", "")
        if not tag:
            tag = ollama_base

        # Build flags
        thread_flag = f" -t {threads}" if threads else ""
        fa_flag = " -fa" if flash == "on" else ""

        lines = "  ─── [bold cyan]Generated Commands[/] ───\n\n"

        # Ollama
        if tag:
            ollama_opts = []
            if ctx != "4096":
                ollama_opts.append(f"num_ctx {ctx}")
            if ngl != "99":
                ollama_opts.append(f"num_gpu {ngl}")
            if threads:
                ollama_opts.append(f"num_thread {threads}")

            lines += f"  [bold]Ollama[/]\n"
            lines += f"  [cyan]ollama run {tag}[/]\n"
            if ollama_opts:
                lines += f"  [dim]# Set in /set parameter or Modelfile:[/]\n"
                for opt in ollama_opts:
                    lines += f"  [dim]#   PARAMETER {opt}[/]\n"
            lines += "\n"

        # llama.cpp
        lines += f"  [bold]llama.cpp[/]\n"
        lines += (
            f"  [cyan]llama-cli -m <model.gguf> "
            f"-ngl {ngl} -c {ctx} -b {batch}"
            f"{thread_flag}{fa_flag}"
            f" --mlock -cnv[/]\n\n"
        )

        # vLLM
        if hf_id:
            vllm_args = f"--max-model-len {ctx} --gpu-memory-utilization 0.9"
            if kv_quant != "fp16":
                vllm_args += f" --kv-cache-dtype {kv_quant}"

            lines += f"  [bold]vLLM[/]\n"
            lines += f"  [cyan]vllm serve {hf_id} {vllm_args}[/]\n\n"

        # LM Studio
        if hf_id:
            lines += f"  [bold]LM Studio[/]\n"
            lines += f"  [cyan]lms load {hf_id} --gpu-layers {ngl} --context-length {ctx}[/]\n\n"

        # KoboldCpp
        lines += f"  [bold]KoboldCpp[/]\n"
        lines += (
            f"  [cyan]koboldcpp <model.gguf> "
            f"--gpulayers {ngl} --contextsize {ctx} "
            f"--blasbatchsize {batch}"
            f"{thread_flag}[/]\n\n"
        )

        # Docker
        if tag:
            lines += f"  [bold]Docker Model Runner[/]\n"
            lines += f"  [cyan]docker model run {tag}[/]\n\n"

        # Performance estimate
        if self.rec:
            speed = self.rec.get("speed_toks")
            vram = self.rec.get("vram_percent", 0)
            if speed:
                # Rough estimate: speed scales inversely with context
                base_ctx = 4096
                ctx_int = int(ctx)
                scale = base_ctx / ctx_int if ctx_int > base_ctx else 1.0
                est_speed = int(speed * min(1.0, scale + 0.3))
                lines += (
                    f"  ─── [bold cyan]Estimates[/] ───\n"
                    f"  [dim]Speed (est.)[/]   ~{est_speed} tok/s at {int(ctx)//1024}K context\n"
                    f"  [dim]VRAM[/]           ~{vram}% (may vary with context)\n"
                )

        self.query_one("#sim-output", Static).update(lines)
