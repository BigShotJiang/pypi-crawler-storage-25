"""Enterprise deployment screen — sizing, cost, latency, risk, TCO."""

from textual.app import ComposeResult
from textual.screen import Screen
from textual.widgets import Header, Footer, Static, LoadingIndicator, TabbedContent, TabPane
from textual.containers import VerticalScroll
from textual.binding import Binding
from textual.css.query import NoMatches
from textual import work

from .. import api
from ..widgets import get_key, bar


class EnterpriseScreen(Screen):
    DEFAULT_CSS = "EnterpriseScreen { layout: vertical; }"

    BINDINGS = [
        Binding("escape", "app.pop_screen", "Back"),
        Binding("q", "quit", "Quit"),
    ]

    def __init__(self, model_id: str, model_name: str, users: int = 10,
                 pattern: str = "sustained", additional_models: list[dict] | None = None):
        super().__init__()
        self.model_id = model_id
        self.model_name = model_name
        self.users = users
        self.pattern = pattern
        self.additional_models = additional_models

    def compose(self) -> ComposeResult:
        yield Header(show_clock=False)
        yield Static(f"  [bold]{self.model_name}[/]  [dim]sizing for {self.users} users...[/]", id="ent-header")
        yield LoadingIndicator()
        with TabbedContent(id="ent-tabs"):
            with TabPane("Overview", id="tab-overview"):
                yield VerticalScroll(Static("", id="overview-content"))
            with TabPane("Risk", id="tab-risk"):
                yield VerticalScroll(Static("", id="risk-content"))
            with TabPane("Checklist", id="tab-checklist"):
                yield VerticalScroll(Static("", id="checklist-content"))
            with TabPane("TCO", id="tab-tco"):
                yield VerticalScroll(Static("", id="tco-content"))
            with TabPane("Scaling", id="tab-scaling"):
                yield VerticalScroll(Static("", id="scaling-content"))
            with TabPane("SLA", id="tab-sla"):
                yield VerticalScroll(Static("", id="sla-content"))
            with TabPane("GPUs", id="tab-gpus"):
                yield VerticalScroll(Static("", id="gpu-matrix-content"))
            with TabPane("Perf", id="tab-perf"):
                yield VerticalScroll(Static("", id="perf-content"))
            with TabPane("FT", id="tab-ft"):
                yield VerticalScroll(Static("", id="ft-content"))
            with TabPane("Arch", id="tab-arch"):
                yield VerticalScroll(Static("", id="arch-content"))
        yield Footer()

    def on_mount(self) -> None:
        self._load()

    @work(thread=True)
    def _load(self) -> None:
        key = get_key()
        if not key:
            return
        try:
            # Build kwargs for enterprise API
            kwargs: dict = {"include": ["all"]}
            if self.additional_models:
                kwargs["additional_models"] = self.additional_models
            data = api.enterprise(key, self.model_id, self.users, **kwargs)
            self.app.call_from_thread(self._show, data)
        except Exception as e:
            self.app.call_from_thread(self.notify, str(e), severity="error")

    def _show(self, data: dict) -> None:
        try:
            self.query_one(LoadingIndicator).remove()
        except NoMatches:
            pass

        m = data.get("model", {})
        self.query_one("#ent-header", Static).update(
            f"  [bold]{m.get('name', '')}[/]  [dim]{m.get('params_b', '')}B · {data.get('concurrent_users', 0)} users[/]"
        )

        self._render_overview(data)
        self._render_risk(data)
        self._render_checklist(data)
        self._render_tco(data)
        self._render_scaling(data)
        self._render_sla(data)
        self._render_gpu_matrix(data)
        self._render_perf(data)
        self._render_fine_tuning(data)
        self._render_architecture(data)

    def _render_overview(self, data: dict) -> None:
        p95ok = data.get("p95_ttft_ms", 999) < 500
        p95s = "green" if p95ok else "yellow"

        cost = ""
        cloud_cost = data.get("monthly_cloud_cost")
        if cloud_cost is not None:
            cost += f"  [dim]Cloud GPU[/]      [bold]${int(cloud_cost):,}/mo[/]\n"
        prem_up = data.get("on_prem_upfront")
        if prem_up is not None:
            prem_mo = int(data.get("on_prem_monthly") or 0)
            cost += f"  [dim]On-prem[/]        ${int(prem_up):,} upfront + ${prem_mo:,}/mo\n"
        be = data.get("break_even_months")
        if be is not None:
            cost += f"  [dim]Break-even[/]     {be} months\n"
        if not cost:
            cost = "  [dim]Cost data not available[/]\n"

        # Insights
        insights = data.get("insights", [])
        insights_str = ""
        if insights:
            insights_str = "\n  ─── [bold cyan]Insights[/] ───\n"
            for ins in insights[:6]:
                insights_str += f"  [dim]•[/] {ins}\n"

        # Capacity
        cap = data.get("capacity", {})
        cap_str = ""
        if cap:
            status_colors = {"safe": "green", "near_saturation": "yellow", "sla_risk": "red"}
            sc = status_colors.get(cap.get("status", ""), "")
            util = float(cap.get('utilizationPercent') or 0)
            headroom = float(cap.get('headroomPercent') or 0)
            burst = float(cap.get('burstTolerancePercent') or 0)
            cap_str = (
                f"\n  ─── [bold cyan]Capacity[/] ───\n"
                f"  [dim]Utilization[/]    {bar(util, 20)} [bold]{util:.0f}%[/]\n"
                f"  [dim]Headroom[/]       {headroom:.0f}%\n"
                f"  [dim]Burst tolerance[/] {burst:.0f}%\n"
                f"  [dim]Status[/]         [{sc}]{cap.get('statusLabel', '')}[/]\n"
            )

        # Readiness
        ready = data.get("readiness", {})
        ready_str = ""
        if ready:
            ha_colors = {"ha_ready": "green", "partial_ha": "yellow", "spof_present": "red"}
            hc = ha_colors.get(ready.get("haStatus", ""), "")
            ready_str = (
                f"\n  ─── [bold cyan]Production Readiness[/] ───\n"
                f"  [dim]HA Status[/]      [{hc}]{ready.get('haLabel', '')}[/]\n"
                f"  [dim]N+1 Ready[/]      {'[green]Yes[/]' if ready.get('nPlusOneReady') else '[red]No[/]'}\n"
                f"  [dim]Capacity after failure[/] {float(ready.get('capacityAfterFailure') or 0):.0f}%\n"
                f"  [dim]Recovery time[/]  {ready.get('recoveryTimeEstimate', '—')}\n"
            )
            spofs = ready.get("spofs", [])
            if spofs:
                for sp in spofs:
                    ready_str += f"  [yellow]⚠ {sp}[/]\n"

        self.query_one("#overview-content", Static).update(
            f"\n  ─── [bold cyan]Infrastructure[/] ───\n"
            f"  [dim]GPU[/]            [bold]{data.get('recommended_gpu', '')}[/]\n"
            f"  [dim]Per replica[/]     {data.get('gpu_count', 0)} GPU(s)\n"
            f"  [dim]Replicas[/]       {data.get('replicas', 0)}\n"
            f"  [dim]Total GPUs[/]     [bold]{data.get('total_gpus', 0)}[/]\n"
            f"  [dim]VRAM[/]           {data.get('vram_usage_pct', 0)}%\n\n"
            f"  ─── [bold cyan]Performance[/] ───\n"
            f"  [dim]Throughput[/]     [bold]{data.get('throughput_rpm', 0)} req/min[/]\n"
            f"  [dim]Decode[/]         {data.get('decode_tps', 0)} tok/s per user\n"
            f"  [dim]TTFT[/]           {data.get('ttft_ms', 0)}ms\n"
            f"  [dim]P95 TTFT[/]       [{p95s}]{data.get('p95_ttft_ms', 0)}ms[/]  "
            f"{'[green]✓ SLA OK[/]' if p95ok else '[yellow]⚠ High[/]'}\n\n"
            f"  ─── [bold cyan]Cost[/] ───\n{cost}"
            f"{insights_str}{cap_str}{ready_str}"
        )

        # Append multi-model info if present
        mm = data.get("multi_model")
        if mm:
            mm_lines = "\n  ─── [bold cyan]Multi-Model Serving[/] ───\n"
            mm_lines += f"  [dim]Total VRAM[/]     {mm.get('total_vram_gb', 0)}GB\n"
            mm_lines += f"  [dim]Fits single GPU[/] {'[green]Yes[/]' if mm.get('fits_single_gpu') else '[yellow]No[/]'}\n\n"
            for m in mm.get("models", []):
                share_pct = int(m.get("traffic_share", 0) * 100)
                mm_lines += (
                    f"  [bold]{m['name']}[/]  {m['params_b']}B  Q{int(m['bpw'])}  "
                    f"{m['vram_gb']}GB  [cyan]{share_pct}% traffic[/]\n"
                )
            content = self.query_one("#overview-content", Static)
            content.update(f"{content.renderable}\n{mm_lines}")

    def _render_risk(self, data: dict) -> None:
        risk = data.get("risk", {})
        if not risk:
            self.query_one("#risk-content", Static).update("  [dim]Risk data not available[/]")
            return

        severity_colors = {"high": "red", "medium": "yellow", "low": "green"}
        lines = (
            f"\n  [bold]{risk.get('highCount', 0)}[/] [red]High[/]  "
            f"[bold]{risk.get('mediumCount', 0)}[/] [yellow]Medium[/]  "
            f"[bold]{risk.get('lowCount', 0)}[/] [green]Low[/]\n\n"
        )

        for item in risk.get("risks", []):
            sev = item.get("severity", "")
            sc = severity_colors.get(sev, "")
            lines += (
                f"  [{sc}]●[/] [{sc}][bold]{item.get('title', '')}[/][/]  "
                f"[dim]{item.get('category', '')}[/]\n"
                f"    [dim]{item.get('description', '')}[/]\n"
                f"    [cyan]→ {item.get('mitigation', '')}[/]\n\n"
            )

        self.query_one("#risk-content", Static).update(lines)

    def _render_checklist(self, data: dict) -> None:
        cl = data.get("checklist", {})
        if not cl:
            self.query_one("#checklist-content", Static).update("  [dim]Checklist not available[/]")
            return

        score = float(cl.get("readinessScore") or 0)
        total = int(cl.get("totalCount") or 0)
        passed = int(cl.get("passCount") or 0)

        lines = (
            f"\n  [bold]Readiness Score:[/] {bar(score, 25)} [bold]{score:.0f}%[/]  "
            f"({passed}/{total} passed)\n\n"
        )

        status_icons = {"pass": "[green]✓[/]", "warn": "[yellow]⚠[/]", "fail": "[red]✗[/]", "info": "[blue]ℹ[/]"}

        for item in cl.get("items", []):
            icon = status_icons.get(item.get("status", ""), "?")
            lines += (
                f"  {icon} [bold]{item.get('label', '')}[/]  [dim]{item.get('category', '')}[/]\n"
            )
            rec = item.get("recommendation", "")
            if rec:
                lines += f"    [dim]{rec}[/]\n"

        self.query_one("#checklist-content", Static).update(lines)

    def _render_tco(self, data: dict) -> None:
        tco = data.get("tco", {})
        if not tco:
            self.query_one("#tco-content", Static).update("  [dim]TCO data not available[/]")
            return

        lines = "\n"

        def tco_row(label: str, row: dict | None) -> str:
            if not row:
                return f"  [dim]{label:14s}[/] —\n"
            y1 = int(row.get("year1") or 0)
            y2 = int(row.get("year2") or 0)
            y3 = int(row.get("year3") or 0)
            total = int(row.get("total") or 0)
            return (
                f"  [dim]{label:14s}[/] "
                f"Y1: ${y1:>10,}  Y2: ${y2:>10,}  Y3: ${y3:>10,}  "
                f"[bold]Total: ${total:>10,}[/]\n"
            )

        lines += "  ─── [bold cyan]3-Year TCO Comparison[/] ───\n\n"
        lines += f"  {'':14s} {'Year 1':>14s}  {'Year 2':>14s}  {'Year 3':>14s}  {'Total':>16s}\n"
        lines += "  " + "─" * 80 + "\n"
        lines += tco_row("Cloud GPU", tco.get("cloud"))
        lines += tco_row("On-premises", tco.get("onPrem"))
        lines += tco_row("API", tco.get("api"))
        lines += "\n"

        cheapest = tco.get("cheapestOption", "")
        savings = float(tco.get("savingsVsCloud3yr") or 0)
        if cheapest:
            lines += f"  [green]Cheapest:[/] [bold]{cheapest}[/]"
            if savings:
                lines += f"  ({savings:.0f}% savings vs cloud)"
            lines += "\n"

        # Quant what-if
        qw = data.get("quant_whatif", {})
        if qw:
            lines += "\n  ─── [bold cyan]Quantization Impact[/] ───\n\n"
            lines += f"  {'Quant':8s} {'BPW':>5s} {'Quality':>8s} {'VRAM':>8s} {'Speed':>10s} {'Fits':>5s}\n"
            lines += "  " + "─" * 50 + "\n"
            current = qw.get("currentQuant", "")
            for row in qw.get("rows", []):
                marker = " ←" if row.get("quant", "") == current else ""
                fits_color = "green" if row.get("fits") else "red"
                lines += (
                    f"  {row.get('quant', ''):8s} {row.get('bpw', 0):5.1f} "
                    f"{row.get('qualityPct', 0):7.0f}% {row.get('vramGb', 0):7.1f}GB "
                    f"{row.get('speedTokPerSec', 0):9.0f}  "
                    f"[{fits_color}]{'Yes' if row.get('fits') else 'No':>4s}[/]"
                    f"[cyan]{marker}[/]\n"
                )
            rec = qw.get("recommendedQuant", "")
            if rec:
                lines += f"\n  [dim]Recommended:[/] [bold]{rec}[/]\n"

        self.query_one("#tco-content", Static).update(lines)

    def _render_scaling(self, data: dict) -> None:
        sc = data.get("scaling", {})
        if not sc:
            self.query_one("#scaling-content", Static).update("  [dim]Scaling data not available[/]")
            return

        lines = "\n  ─── [bold cyan]Scaling Simulation[/] ───\n\n"
        lines += (
            f"  {'Users':>8s} {'Replicas':>9s} {'GPUs':>6s} {'Cost/mo':>10s} "
            f"{'P95 TTFT':>10s} {'Util%':>7s}\n"
        )
        lines += "  " + "─" * 55 + "\n"

        for pt in sc.get("dataPoints", []):
            util = float(pt.get("utilizationPercent") or 0)
            uc = "green" if util < 70 else "yellow" if util < 90 else "red"
            p95 = int(pt.get("p95TtftMs") or 0)
            pc = "green" if p95 < 200 else "yellow" if p95 < 500 else "red"
            users = int(pt.get("users") or 0)
            repl = int(pt.get("replicas") or 0)
            tgpus = int(pt.get("totalGpus") or 0)
            mcost = int(pt.get("monthlyCost") or 0)
            lines += (
                f"  {users:>8d} {repl:>9d} "
                f"{tgpus:>6d} ${mcost:>9,} "
                f"[{pc}]{p95:>9d}ms[/] [{uc}]{util:>6.0f}%[/]\n"
            )

        sat = sc.get("saturationPoint")
        if sat:
            lines += f"\n  [yellow]Saturation point:[/] [bold]{sat} users[/]\n"
        cpu = sc.get("costPerUserAtScale")
        if cpu:
            lines += f"  [dim]Cost per user at scale:[/] ${float(cpu):.2f}/mo\n"

        self.query_one("#scaling-content", Static).update(lines)

    def _render_sla(self, data: dict) -> None:
        sla = data.get("sla", [])
        if not sla:
            self.query_one("#sla-content", Static).update("  [dim]SLA data not available[/]")
            return

        lines = "\n  ─── [bold cyan]SLA Replica Requirements[/] ───\n\n"
        lines += (
            f"  {'Target P95':>11s} {'Replicas':>9s} {'GPUs':>6s} {'Cost/mo':>10s} "
            f"{'Achieved':>10s} {'Meets':>6s}\n"
        )
        lines += "  " + "─" * 55 + "\n"

        for s in sla:
            meets = s.get("meetsTarget", False)
            mc = "green" if meets else "red"
            tgt = int(s.get("targetMs") or 0)
            repl = int(s.get("replicasNeeded") or 0)
            tgpu = int(s.get("totalGpus") or 0)
            mcost = int(s.get("monthlyCost") or 0)
            achieved = int(s.get("achievedP95Ms") or 0)
            lines += (
                f"  {tgt:>10d}ms {repl:>9d} "
                f"{tgpu:>6d} ${mcost:>9,} "
                f"{achieved:>9d}ms "
                f"[{mc}]{'✓ Yes' if meets else '✗ No':>6s}[/]\n"
            )

        self.query_one("#sla-content", Static).update(lines)

    def _render_gpu_matrix(self, data: dict) -> None:
        matrix = data.get("gpu_matrix", {})
        if not matrix:
            self.query_one("#gpu-matrix-content", Static).update("  [dim]GPU matrix not available[/]")
            return

        lines = "\n  ─── [bold cyan]GPU Decision Matrix[/] ───\n\n"
        lines += (
            f"  {'#':>2s} {'GPU':20s} {'GPUs':>5s} {'Repl':>5s} {'RPM':>6s} "
            f"{'tok/s':>7s} {'P95':>7s} {'Cost/mo':>9s} {'3yr TCO':>10s} {'Best For':16s}\n"
        )
        lines += "  " + "─" * 95 + "\n"

        for row in matrix.get("rows", []):
            rank = int(row.get("rank") or 0)
            gcnt = int(row.get("gpuCount") or 0)
            repl = int(row.get("replicas") or 0)
            rpm = int(row.get("throughputRpm") or 0)
            dtps = int(row.get("decodePerUserTps") or 0)
            p95 = int(row.get("p95TtftMs") or 0)
            mcc = int(row.get("monthlyCloudCost") or 0)
            tco = int(row.get("tco3Year") or 0)
            lines += (
                f"  {rank:>2d} {row.get('gpuName', ''):20s} "
                f"{gcnt:>5d} {repl:>5d} "
                f"{rpm:>6d} {dtps:>7d} "
                f"{p95:>6d}ms ${mcc:>8,} "
                f"${tco:>9,} "
                f"[cyan]{row.get('bestFor', ''):16s}[/]\n"
            )

        best = matrix.get("bestOverall", "")
        budget = matrix.get("bestBudget", "")
        perf = matrix.get("bestPerformance", "")
        if best or budget or perf:
            lines += f"\n  [green]Best overall:[/] [bold]{best}[/]"
            if budget:
                lines += f"  [green]Budget:[/] [bold]{budget}[/]"
            if perf:
                lines += f"  [green]Performance:[/] [bold]{perf}[/]"
            lines += "\n"

        # Cost providers
        providers = data.get("cost_providers", [])
        if providers:
            lines += "\n  ─── [bold cyan]Cloud Provider Pricing[/] ───\n\n"
            lines += f"  {'Provider':12s} {'GPU':25s} {'$/hr':>7s} {'$/mo':>9s}\n"
            lines += "  " + "─" * 55 + "\n"
            for p in providers:
                hr = p.get("price_hr")
                mo = p.get("monthly")
                hr_str = f"${float(hr):.2f}" if hr else "—"
                mo_str = f"${int(mo):,}" if mo else "—"
                lines += (
                    f"  {p.get('provider', ''):12s} {p.get('gpu', ''):25s} "
                    f"{hr_str:>7s} {mo_str:>9s}\n"
                )

        self.query_one("#gpu-matrix-content", Static).update(lines)

    def _render_perf(self, data: dict) -> None:
        td = data.get("throughput_detail", {})
        ld = data.get("latency_detail", {})
        tp = data.get("tensor_parallelism", [])

        if not td and not ld:
            self.query_one("#perf-content", Static).update("  [dim]Performance data not available[/]")
            return

        lines = ""

        if td:
            lines += "\n  ─── [bold cyan]Throughput Modeling[/] ───\n\n"
            lines += f"  [dim]Decode (total)[/]     [bold]{td.get('decode_total_tps', 0)} tok/s[/]  [dim]({td.get('decode_bound', 'bandwidth')}-bound)[/]\n"
            lines += f"  [dim]Decode (per user)[/]  [bold]{td.get('decode_per_user_tps', 0)} tok/s[/]\n"
            lines += f"  [dim]Prefill[/]            [dim]{td.get('prefill_bound', 'compute')}-bound[/]\n"
            lines += f"  [dim]Max batch size[/]     {td.get('max_batch_size', 0)}\n"
            lines += f"  [dim]Users per replica[/]  {td.get('users_per_replica', 0)}\n"
            lines += f"  [dim]Bottleneck[/]         [yellow]{td.get('bottleneck', '—')}[/]\n"

        if ld:
            lines += "\n  ─── [bold cyan]Latency Profiling[/] ───\n\n"
            ttft = ld.get("ttft_ms", 0)
            p95 = ld.get("p95_ttft_ms", 0)
            itl = ld.get("inter_token_ms")
            util = ld.get("utilization_pct", 0)

            tc = "green" if ttft < 200 else "yellow" if ttft < 500 else "red"
            pc = "green" if p95 < 200 else "yellow" if p95 < 500 else "red"
            uc = "green" if util < 70 else "yellow" if util < 90 else "red"

            lines += f"  [dim]TTFT[/]               [{tc}][bold]{ttft}ms[/][/]\n"
            lines += f"  [dim]P95 TTFT[/]           [{pc}][bold]{p95}ms[/][/]  {'[green]✓ SLA OK[/]' if p95 < 500 else '[yellow]⚠ High[/]'}\n"
            if itl:
                lines += f"  [dim]Inter-token[/]        {itl}ms\n"
            lines += f"  [dim]Utilization[/]        [{uc}]{util}%[/]\n"

        if tp:
            lines += "\n  ─── [bold cyan]Tensor Parallelism[/] ───\n\n"
            lines += f"  {'GPUs':>5s} {'Efficiency':>11s} {'Speedup':>8s}\n"
            lines += "  " + "─" * 28 + "\n"
            for t in tp:
                eff = t.get("efficiency", 0)
                ec = "green" if eff >= 80 else "yellow" if eff >= 60 else "red"
                lines += (
                    f"  {t.get('gpus', 0):>5d} [{ec}]{eff:>10d}%[/] "
                    f"{t.get('speedup', 0):>7.1f}x\n"
                )
            lines += "\n  [dim]Efficiency decreases with more GPUs due to communication overhead[/]\n"

        self.query_one("#perf-content", Static).update(lines)

    def _render_fine_tuning(self, data: dict) -> None:
        ft = data.get("fine_tuning", {})
        if not ft:
            self.query_one("#ft-content", Static).update("  [dim]Fine-tuning data not available[/]")
            return

        methods = ft.get("methods", {})
        rec = ft.get("recommended", "")
        cost_hr = ft.get("cloud_cost_per_hour", 0)

        lines = "\n  ─── [bold cyan]Fine-tuning Cost Estimator[/] ───\n\n"
        lines += f"  {'Method':8s} {'VRAM':>8s} {'Trainable':>10s} {'Time/epoch':>11s} {'Cloud cost':>11s}\n"
        lines += "  " + "─" * 55 + "\n"

        for name, label in [("qlora", "QLoRA"), ("lora", "LoRA"), ("full", "Full FT")]:
            m = methods.get(name, {})
            vram = float(m.get("vram_gb") or 0)
            pct = float(m.get("trainable_pct") or 0)
            hrs = float(m.get("hours_per_epoch") or 0)
            cost = hrs * cost_hr if cost_hr else 0
            marker = " [cyan]← recommended[/]" if name == rec else ""
            cost_str = f"${cost:.0f}" if cost else "—"
            lines += (
                f"  {label:8s} {vram:>7.1f}GB {pct:>9.1f}% "
                f"{hrs:>10.1f}h {cost_str:>11s}{marker}\n"
            )

        lines += f"\n  [dim]Based on 100K samples x 512 tokens, GPU: ${float(cost_hr):.2f}/hr[/]\n"

        # Break-even visualization
        be = data.get("break_even_months")
        cloud_mo = data.get("monthly_cloud_cost")
        prem_mo = data.get("on_prem_monthly")
        upfront = data.get("on_prem_upfront")
        if be and cloud_mo and upfront:
            lines += "\n  ─── [bold cyan]Break-even Timeline[/] ───\n\n"
            for month in [3, 6, 12, 18, 24]:
                ct = int(cloud_mo) * month
                pt = int(upfront) + int(prem_mo or 0) * month
                cheaper = "[green]on-prem[/]" if pt < ct else "[yellow]cloud[/]"
                marker = " [bold]← break-even[/]" if month == be else ""
                lines += (
                    f"  {month:>2d}mo  Cloud: ${ct:>10,}  On-prem: ${pt:>10,}  {cheaper}{marker}\n"
                )

        self.query_one("#ft-content", Static).update(lines)

    def _render_architecture(self, data: dict) -> None:
        arch = data.get("architecture", {})
        if not arch:
            self.query_one("#arch-content", Static).update("  [dim]Architecture data not available[/]")
            return

        # Component descriptions
        engine_desc = {
            "vllm": "High-throughput serving with continuous batching",
            "ollama": "Simple deployment, great for single-GPU setups",
            "trt-llm": "NVIDIA-optimized, maximum throughput on NVIDIA GPUs",
            "sglang": "Fast serving with RadixAttention prefix caching",
            "llamacpp": "CPU+GPU hybrid, lightweight deployment",
        }
        gateway_desc = {
            "kong": "Full API gateway with plugins, auth, rate limiting",
            "nginx": "High-performance reverse proxy and load balancer",
            "caddy": "Simple HTTPS server with automatic certificates",
            "envoy": "Cloud-native proxy, gRPC support, observability",
            "traefik": "Dynamic routing, Docker/K8s native",
            "none": "Direct access (development only)",
        }
        monitor_desc = {
            "prometheus": "Prometheus + Grafana — open-source metrics & dashboards",
            "datadog": "Cloud-hosted APM with AI monitoring",
            "cloudwatch": "AWS-native monitoring and alerting",
            "newrelic": "Full-stack observability platform",
            "none": "No monitoring",
        }
        storage_desc = {
            "nvme4": "NVMe Gen4 — ~7 GB/s, fastest model loading",
            "nvme3": "NVMe Gen3 — ~3.5 GB/s, good performance",
            "ssd": "SATA SSD — ~0.5 GB/s, budget option",
            "nfs": "Shared NFS — multi-node model sharing",
            "s3": "S3/Object Storage — cold storage, slow loading",
        }
        cache_desc = {
            "redis_prefix": "Redis + Prefix caching — fastest repeated prompts",
            "redis": "Redis — response caching for identical queries",
            "prefix": "Prefix caching only — KV cache reuse in engine",
            "none": "No caching",
        }
        network_desc = {
            "nvlink": "NVLink — 900 GB/s GPU-to-GPU, tensor parallelism",
            "infiniband": "InfiniBand 400Gb/s — datacenter multi-node",
            "25gbe": "25GbE — high-throughput rack networking",
            "10gbe": "10GbE — multi-replica load balancing",
            "standard": "1GbE — single-node development",
        }

        replicas = data.get("replicas", 1)
        gpu_count = data.get("gpu_count", 1)
        total_gpus = data.get("total_gpus", 1)
        gpu_name = data.get("recommended_gpu", "GPU")

        # ASCII Architecture diagram
        lines = "\n  ─── [bold cyan]Infrastructure Architecture[/] ───\n\n"

        # Clients tier
        users = data.get("concurrent_users", 0)
        lines += f"  [bold]Clients[/]  ({users} concurrent users)\n"
        lines += f"      │\n"

        # Gateway tier
        gw = arch.get("api_gateway", "caddy")
        lines += f"  ┌───┴───────────────────────────────┐\n"
        lines += f"  │  [cyan]{gw.upper():^35s}[/]  │\n"
        lines += f"  │  [dim]{gateway_desc.get(gw, ''):^35s}[/]  │\n"
        lines += f"  └───┬───────────────────────────────┘\n"

        if replicas > 1:
            lines += f"      │ [dim]Load Balancer[/]\n"
            branches = "──┬──" * min(replicas, 4)
            if replicas > 4:
                branches += f"··({replicas})"
            lines += f"  ┌───┴{branches}┐\n"
        else:
            lines += f"      │\n"

        # Inference tier (show up to 3 replicas)
        eng = arch.get("inference_engine", "ollama")
        for r in range(min(replicas, 3)):
            gpu_str = f"{gpu_count}× {gpu_name}" if gpu_count > 1 else gpu_name
            lines += f"  │ [green]Replica {r+1}[/]: {eng} on {gpu_str}  │\n"
        if replicas > 3:
            lines += f"  │ [dim]... +{replicas - 3} more replicas[/]            │\n"
        lines += f"  └─────────────────────────────────────┘\n\n"

        # Stack components
        lines += "  ─── [bold cyan]Stack Components[/] ───\n\n"

        components = [
            ("Inference Engine", eng, engine_desc.get(eng, ""), "green"),
            ("API Gateway", gw, gateway_desc.get(gw, ""), "cyan"),
            ("Monitoring", arch.get("monitoring", ""), monitor_desc.get(arch.get("monitoring", ""), ""), "yellow"),
            ("Storage", arch.get("storage", ""), storage_desc.get(arch.get("storage", ""), ""), "blue"),
            ("Caching", arch.get("caching", ""), cache_desc.get(arch.get("caching", ""), ""), "cyan"),
            ("Networking", arch.get("networking", ""), network_desc.get(arch.get("networking", ""), ""), "red"),
        ]

        for label, value, desc, color in components:
            lines += f"  [{color}]●[/] [bold]{label:18s}[/] [{color}]{value}[/]\n"
            if desc:
                lines += f"    [dim]{desc}[/]\n"

        lines += (
            f"\n  ─── [bold cyan]Summary[/] ───\n"
            f"  [dim]Total GPUs[/]    {total_gpus}\n"
            f"  [dim]Replicas[/]      {replicas}\n"
            f"  [dim]GPUs/replica[/]  {gpu_count}\n"
        )

        self.query_one("#arch-content", Static).update(lines)
