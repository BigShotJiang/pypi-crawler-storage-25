"""Find GPU screen — GPU recommendations for a model."""

from textual.app import ComposeResult
from textual.screen import Screen
from textual.widgets import Header, Footer, Static, DataTable, LoadingIndicator, Select, Label
from textual.containers import VerticalScroll, Horizontal, Vertical
from textual.binding import Binding
from textual.css.query import NoMatches
from textual import work

from .. import api
from ..widgets import get_key

BUDGET_OPTIONS = [
    ("Any budget", "0"), ("≤$500", "500"), ("≤$1000", "1000"),
    ("≤$1500", "1500"), ("≤$2000", "2000"), ("≤$3000", "3000"), ("≤$5000", "5000"),
]

SPEED_OPTIONS = [
    ("≥10 tok/s", "10"), ("≥20 tok/s", "20"), ("≥30 tok/s", "30"), ("≥50 tok/s", "50"),
]

VENDOR_OPTIONS = [
    ("All vendors", "all"), ("NVIDIA", "nvidia"), ("AMD", "amd"), ("Intel", "intel"),
]

QUANT_BPW_OPTIONS = [
    ("Q4 (4.5 bpw)", "4.5"), ("Q3 (3.5 bpw)", "3.5"), ("Q5 (5.5 bpw)", "5.5"),
    ("Q6 (6.5 bpw)", "6.5"), ("Q8 (8.5 bpw)", "8.5"), ("FP16 (16 bpw)", "16"),
]

MULTI_GPU_OPTIONS = [
    ("Single GPU", "1"), ("2x GPU", "2"), ("4x GPU", "4"), ("8x GPU", "8"),
]

RUN_MODE_OPTIONS = [
    ("Any mode", "any"), ("GPU Only", "gpu"), ("GPU+Offload", "offload"), ("CPU Only", "cpu"),
]


class FindGpuScreen(Screen):
    DEFAULT_CSS = "FindGpuScreen { layout: vertical; }"

    BINDINGS = [
        Binding("f", "toggle_filters", "Filters", show=True),
        Binding("c", "compare_gpus", "Compare", show=True),
        Binding("escape", "app.pop_screen", "Back"),
        Binding("q", "quit", "Quit"),
    ]

    def __init__(self, model_id: str, model_name: str):
        super().__init__()
        self.model_id = model_id
        self.model_name = model_name
        self._loading = False
        self._all_options: list[dict] = []

    def compose(self) -> ComposeResult:
        yield Header(show_clock=False)
        yield Static(f"  [bold]{self.model_name}[/]  [dim]loading...[/]", id="gpu-header")

        with Horizontal():
            with VerticalScroll(id="gpu-filters-panel"):
                yield Label("BUDGET")
                yield Select(BUDGET_OPTIONS, value="0", id="sel-budget", allow_blank=False)
                yield Label("MIN SPEED")
                yield Select(SPEED_OPTIONS, value="10", id="sel-min-speed", allow_blank=False)
                yield Label("GPU VENDOR")
                yield Select(VENDOR_OPTIONS, value="all", id="sel-vendor", allow_blank=False)
                yield Label("QUANTIZATION")
                yield Select(QUANT_BPW_OPTIONS, value="4.5", id="sel-bpw", allow_blank=False)
                yield Label("MULTI-GPU")
                yield Select(MULTI_GPU_OPTIONS, value="1", id="sel-multigpu", allow_blank=False)
                yield Label("RUN MODE")
                yield Select(RUN_MODE_OPTIONS, value="any", id="sel-runmode", allow_blank=False)
                yield Label("CONTEXT")
                yield Select([
                    ("Model default", "0"), ("4K", "4096"), ("8K", "8192"),
                    ("16K", "16384"), ("32K", "32768"), ("64K", "65536"),
                ], value="0", id="sel-context-override", allow_blank=False)

            with Vertical():
                yield LoadingIndicator()
                with VerticalScroll():
                    yield Static("", id="builds-panel")
                    yield DataTable(id="gpu-table", cursor_type="row")
                    yield Static("", id="cloud-panel")
                    yield Static("", id="sysreq-panel")

        yield Footer()

    def on_mount(self) -> None:
        self.query_one("#gpu-table", DataTable).add_columns(
            "#", "GPU", "Vendor", "GPUs", "VRAM", "Speed", "Price", "Tier"
        )
        # Hide filter panel by default (compact view)
        self.query_one("#gpu-filters-panel").display = False
        self._load()

    def action_toggle_filters(self) -> None:
        panel = self.query_one("#gpu-filters-panel")
        panel.display = not panel.display

    def on_select_changed(self, event: Select.Changed) -> None:
        if not self._loading:
            self._load()

    def _get_params(self) -> dict:
        """Collect filter values for hardware recipe."""
        def val(sel_id: str, default: str = "") -> str:
            try:
                return str(self.query_one(f"#{sel_id}", Select).value)
            except Exception:
                return default

        params: dict = {}
        bpw = val("sel-bpw", "4.5")
        if bpw:
            params["bpw"] = float(bpw)
        min_tps = val("sel-min-speed", "10")
        if min_tps:
            params["min_tps"] = int(min_tps)
        budget = val("sel-budget", "0")
        if budget and int(budget) > 0:
            params["max_budget"] = int(budget)
        vendor = val("sel-vendor", "all")
        if vendor and vendor != "all":
            params["gpu_vendor"] = vendor
        ctx = val("sel-context-override", "0")
        if ctx and int(ctx) > 0:
            params["context_override"] = int(ctx)
        return params

    @work(thread=True)
    def _load(self) -> None:
        self._loading = True
        key = get_key()
        if not key:
            self._loading = False
            return
        try:
            params = self.app.call_from_thread(self._get_params)
            data = api.hardware_recipe(key, self.model_id, **params)
            self.app.call_from_thread(self._show, data)
        except Exception as e:
            self.app.call_from_thread(self.notify, str(e), severity="error")
        finally:
            self._loading = False

    def _show(self, data: dict) -> None:
        try:
            self.query_one(LoadingIndicator).remove()
        except NoMatches:
            pass

        m = data.get("model", {})
        vq = data.get("vram_by_quant", {})
        self.query_one("#gpu-header", Static).update(
            f"  [bold]{m.get('name', '')}[/]  [dim]{m.get('params_b', '')}B[/]\n"
            f"  [dim]VRAM:[/] [cyan]{data.get('vram_required_gb', 0):.1f}GB[/] Q4  "
            f"[dim]Q6:[/] {vq.get('q6', 0):.1f}  [dim]Q8:[/] {vq.get('q8', 0):.1f}  [dim]FP16:[/] {vq.get('fp16', 0):.1f}GB  "
            f"[dim]|[/]  [dim]Min GPUs:[/] {data.get('min_gpus_needed', '?')}  "
            f"[dim]Single GPU:[/] {'[green]Yes[/]' if data.get('can_run_single_gpu') else '[yellow]No[/]'}  "
            f"[dim](press [bold]f[/bold] for filters)[/]"
        )

        builds = ""
        for label, k, style in [("💰 Budget", "budget", "green"), ("⭐ Best Value", "recommended", "cyan"), ("🚀 Fastest", "premium", "yellow")]:
            b = data.get(k)
            if b:
                price = f"${b.get('price', 0)}" if b.get("price") else "—"
                multi = f" {b.get('gpu_count', 1)}x" if b.get("gpu_count", 1) > 1 else ""
                reason = f"  [dim]{b.get('reason', '')}[/]" if b.get("reason") else ""
                builds += f"  [{style}]{label}[/]{multi} [bold]{b.get('gpu', '?')}[/]  [dim]~{b.get('speed_toks', 0)} tok/s  {price}[/]{reason}\n"
        self.query_one("#builds-panel", Static).update(builds)

        self._all_options = data.get("all_options", [])

        table = self.query_one("#gpu-table", DataTable)
        table.clear()
        for i, o in enumerate(self._all_options):
            ts = {"budget": "green", "recommended": "cyan", "premium": "yellow"}.get(o.get("tier", ""), "")
            table.add_row(
                str(i + 1),
                o.get("gpu", "?"),
                o.get("vendor", ""),
                f'{o.get("gpu_count", 1)}x',
                f'{o.get("total_vram_gb", 0):.0f}GB',
                f'~{o.get("speed_toks", 0)} tok/s',
                f'${o["price"]}' if o.get("price") else "—",
                f'[{ts}]{o.get("tier", "")}[/]',
            )
        if data.get("all_options"):
            table.focus()

        cloud = data.get("cloud_options", [])
        if cloud:
            ct = "\n  [dim]Cloud alternatives:[/]\n"
            for c in cloud[:3]:
                gpu_name = c.get("gpu", "GPU")
                multi = f" {c.get('gpu_count', 1)}x" if c.get("gpu_count", 1) > 1 else ""
                price_hr = c.get("price_per_hour", 0)
                price_mo = c.get("monthly_cost", 0)
                ct += f"    [dim]{c.get('provider', '')}[/]{multi} {gpu_name} [dim]${price_hr}/hr (${price_mo}/mo)[/]\n"
            self.query_one("#cloud-panel", Static).update(ct)

        sr = data.get("system_requirements", {})
        notes = sr.get("notes", [])
        notes_str = "  " + "  ".join(notes) if notes else ""
        self.query_one("#sysreq-panel", Static).update(
            f"\n  ─── [bold cyan]System Requirements[/] ───\n"
            f"  [dim]RAM[/]    {sr.get('minRamGb', 0)}GB minimum\n"
            f"  [dim]PSU[/]    {sr.get('minPsuWatts', 0)}W\n"
            f"  [dim]PCIe[/]   {sr.get('pcieSlotsNeeded', 1)} slot(s)\n"
            f"{notes_str}"
        )

    def action_compare_gpus(self) -> None:
        """Open GPU compare screen with all options."""
        if not self._all_options:
            self.notify("No GPU options to compare", severity="warning")
            return
        from .gpu_compare import GpuCompareScreen
        self.app.push_screen(GpuCompareScreen(self.model_id, self.model_name, self._all_options))
