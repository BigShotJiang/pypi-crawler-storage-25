"""Charts screen — ASCII visualizations of model recommendations."""

from textual.app import ComposeResult
from textual.screen import Screen
from textual.widgets import Header, Footer, Static
from textual.containers import VerticalScroll
from textual.binding import Binding

from ..widgets import bar, vbar


class ChartsScreen(Screen):
    """ASCII charts for model comparison."""

    DEFAULT_CSS = "ChartsScreen { layout: vertical; }"

    BINDINGS = [
        Binding("escape", "app.pop_screen", "Back", show=True),
    ]

    def __init__(self, recs: list[dict], gpu_name: str = ""):
        super().__init__()
        self.recs = recs[:20]  # top 20
        self.gpu_name = gpu_name

    def compose(self) -> ComposeResult:
        yield Header(show_clock=False)
        yield Static(f"\n  [bold]Charts — {self.gpu_name}[/]  [dim]({len(self.recs)} models)[/]\n")
        yield VerticalScroll(Static("", id="charts-content"))
        yield Footer()

    def on_mount(self) -> None:
        self._refresh_content()

    def _refresh_content(self) -> None:
        recs = self.recs
        if not recs:
            self.query_one("#charts-content", Static).update("  [dim]No data[/]")
            return

        lines = ""

        # Score chart
        lines += "  ─── [bold cyan]Score Ranking[/] ───\n\n"
        max_name = max(len(r["model"]["name"]) for r in recs)
        for r in recs:
            name = r["model"]["name"]
            score = r["score"]
            lines += f"  {name:<{max_name}s}  {bar(score, 30)} {score}\n"
        lines += "\n"

        # Speed chart
        lines += "  ─── [bold cyan]Speed (tok/s)[/] ───\n\n"
        max_speed = max((r["speed_toks"] or 0) for r in recs) or 1
        for r in recs:
            name = r["model"]["name"]
            speed = r["speed_toks"] or 0
            pct = (speed / max_speed) * 100
            lines += f"  {name:<{max_name}s}  {bar(pct, 30)} ~{speed}\n"
        lines += "\n"

        # VRAM usage chart
        lines += "  ─── [bold cyan]VRAM Usage[/] ───\n\n"
        for r in recs:
            name = r["model"]["name"]
            vram_pct = r["vram_percent"]
            lines += f"  {name:<{max_name}s}  {vbar(vram_pct, 30)} {vram_pct}%\n"
        lines += "\n"

        # Quality vs Speed scatter (ASCII)
        lines += "  ─── [bold cyan]Quality vs Speed[/] ───\n\n"
        lines += "  Speed (tok/s)\n"
        lines += "    ▲\n"
        max_sp = max((r["speed_toks"] or 0) for r in recs) or 1
        max_sc = max(r["score"] for r in recs) or 1
        grid_h, grid_w = 12, 50
        grid = [[" " for _ in range(grid_w)] for _ in range(grid_h)]

        for i, r in enumerate(recs):
            sp = r["speed_toks"] or 0
            sc = r["score"]
            y = min(grid_h - 1, int((sp / max_sp) * (grid_h - 1)))
            x = min(grid_w - 1, int((sc / max_sc) * (grid_w - 1)))
            label = str(i + 1)
            grid[grid_h - 1 - y][x] = label[0] if len(label) == 1 else label

        for row in grid:
            lines += f"    │{''.join(row)}\n"
        lines += f"    └{'─' * grid_w}▶ Score\n"
        lines += "\n"

        # Legend
        lines += "  [dim]Legend:[/]\n"
        for i, r in enumerate(recs[:10]):
            lines += f"  [dim]{i+1}=[/]{r['model']['name']}  "
            if (i + 1) % 3 == 0:
                lines += "\n"
        lines += "\n"

        self.query_one("#charts-content", Static).update(lines)
