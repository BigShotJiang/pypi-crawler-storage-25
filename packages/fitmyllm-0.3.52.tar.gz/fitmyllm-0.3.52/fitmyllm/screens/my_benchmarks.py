"""My Benchmarks screen — view submitted benchmark results."""

from __future__ import annotations

from rich.markup import escape

from textual.app import ComposeResult
from textual.screen import Screen
from textual.widgets import Header, Footer, Static, DataTable
from textual.containers import VerticalScroll
from textual.binding import Binding
from textual import work

from .. import api
from ..widgets import get_key


class MyBenchmarksScreen(Screen):
    DEFAULT_CSS = "MyBenchmarksScreen { layout: vertical; }"

    BINDINGS = [
        Binding("escape", "app.pop_screen", "Back", show=True),
    ]

    def compose(self) -> ComposeResult:
        yield Header(show_clock=False)
        yield Static(
            "\n  [bold]My Benchmarks[/]  [dim]Loading...[/]\n",
            id="mybench-header",
        )
        yield DataTable(id="mybench-table", cursor_type="row")
        yield VerticalScroll(Static("", id="mybench-detail"))
        yield Footer()

    def on_mount(self) -> None:
        table = self.query_one("#mybench-table", DataTable)
        table.add_columns("Model", "Quant", "GPU", "Speed", "TTFT", "Runtime", "Date")
        self._load()

    @work(thread=True)
    def _load(self) -> None:
        key = get_key()
        if not key:
            self.app.call_from_thread(
                self.query_one("#mybench-header", Static).update,
                "\n  [bold]My Benchmarks[/]  [yellow]No API key — run fitmyllm setup[/]\n",
            )
            return

        try:
            benchmarks = api.my_benchmarks(key)
            self.app.call_from_thread(self._show, benchmarks)
        except Exception as e:
            self.app.call_from_thread(
                self.query_one("#mybench-header", Static).update,
                f"\n  [bold]My Benchmarks[/]  [red]{escape(str(e))}[/]\n",
            )

    def _show(self, benchmarks: list[dict]) -> None:
        header = self.query_one("#mybench-header", Static)
        table = self.query_one("#mybench-table", DataTable)
        table.clear()

        if not benchmarks:
            header.update(
                "\n  [bold]My Benchmarks[/]  "
                "[dim]No benchmarks yet — run a benchmark with [bold]Run Benchmark[/bold][/]\n"
            )
            return

        header.update(
            f"\n  [bold]My Benchmarks[/]  "
            f"[dim]{len(benchmarks)} submissions[/]\n"
        )

        for b in benchmarks:
            tps = b.get("tokens_per_second", 0)
            ttft = b.get("time_to_first_token_ms")
            date = (b.get("created_at") or "")[:10]
            notes = b.get("notes", "")
            source = "telemetry" if notes and "telemetry" in notes else "benchmark"

            table.add_row(
                b.get("model_id", "?"),
                b.get("quant_level", "?"),
                b.get("gpu_name", "?"),
                f"[bold]{tps:.1f}[/] tok/s",
                f"{ttft:.0f}ms" if ttft else "—",
                b.get("runtime", "?"),
                f"[dim]{date}[/]",
            )

        table.focus()

    def on_data_table_row_highlighted(self, event: DataTable.RowHighlighted) -> None:
        pass  # Could add detail view later
