"""GPU Prices screen — browse GPU pricing and specs."""

from textual.app import ComposeResult
from textual.screen import Screen
from textual.widgets import Header, Footer, Static, DataTable, Input, Select, LoadingIndicator, Label
from textual.containers import Horizontal
from textual.binding import Binding
from textual.css.query import NoMatches
from textual import work

from .. import api
from ..widgets import get_key

VENDOR_OPTIONS = [
    ("All vendors", ""), ("NVIDIA", "nvidia"), ("AMD", "amd"), ("Intel", "intel"),
]


class GpuPricesScreen(Screen):
    DEFAULT_CSS = "GpuPricesScreen { layout: vertical; }"

    BINDINGS = [
        Binding("escape", "app.pop_screen", "Back"),
    ]

    def __init__(self):
        super().__init__()
        self._vendor = ""

    def compose(self) -> ComposeResult:
        yield Header(show_clock=False)
        yield Static("\n  [bold]GPU Prices[/]  [dim]Search and compare GPU pricing[/]\n")
        with Horizontal():
            yield Input(placeholder="Search GPU (e.g. RTX 4060, RX 7900)...", id="gpu-price-search")
            yield Select(VENDOR_OPTIONS, value="", id="sel-gpu-vendor", allow_blank=False)
        yield LoadingIndicator()
        yield DataTable(id="gpu-price-table", cursor_type="row")
        yield Footer()

    def on_mount(self) -> None:
        table = self.query_one("#gpu-price-table", DataTable)
        table.add_columns("GPU", "Vendor", "VRAM", "BW", "TDP", "Price", "Arch")
        self._do_search("RTX")

    def on_input_submitted(self, event: Input.Submitted) -> None:
        if event.input.id == "gpu-price-search":
            self._do_search(event.value.strip() or "RTX")

    def on_select_changed(self, event: Select.Changed) -> None:
        self._vendor = str(event.value) if str(event.value) != "Select.BLANK" else ""
        try:
            query = self.query_one("#gpu-price-search", Input).value
        except Exception:
            query = ""
        self._do_search(query or "RTX")

    @work(thread=True)
    def _do_search(self, query: str) -> None:
        key = get_key()
        if not key:
            return
        try:
            vendor = self._vendor if self._vendor else None
            results = api.search_gpus(key, query, vendor)
            self.app.call_from_thread(self._show, results)
        except Exception as e:
            self.app.call_from_thread(self.notify, str(e), severity="error")

    def _show(self, gpus: list[dict]) -> None:
        try:
            self.query_one(LoadingIndicator).remove()
        except NoMatches:
            pass

        # Sort by price (cheapest first), then by VRAM
        gpus_with_price = [g for g in gpus if g.get("price_usd")]
        gpus_no_price = [g for g in gpus if not g.get("price_usd")]
        gpus_with_price.sort(key=lambda g: g.get("price_usd", 99999))
        sorted_gpus = gpus_with_price + gpus_no_price

        table = self.query_one("#gpu-price-table", DataTable)
        table.clear()
        for g in sorted_gpus[:50]:
            price = f'${g["price_usd"]}' if g.get("price_usd") else "—"
            vram = f'{g.get("vram_mb", 0) // 1024}GB'
            bw = f'{g.get("bandwidth_gbps", 0)} GB/s'
            tdp = f'{g.get("tdp_watts", 0)}W' if g.get("tdp_watts") else "—"
            table.add_row(
                g.get("name", ""),
                g.get("vendor", ""),
                vram, bw, tdp, price,
                g.get("architecture", "—"),
            )
        table.focus()
