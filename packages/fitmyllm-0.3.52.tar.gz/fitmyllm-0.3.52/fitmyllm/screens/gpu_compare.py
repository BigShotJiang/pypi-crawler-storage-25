"""GPU Compare screen — compare GPU options for a model side by side."""

from textual.app import ComposeResult
from textual.screen import Screen
from textual.widgets import Header, Footer, Static, DataTable, Input, LoadingIndicator
from textual.containers import VerticalScroll
from textual.binding import Binding
from textual.css.query import NoMatches
from textual import work

from .. import api
from ..widgets import get_key, bar


class GpuCompareScreen(Screen):
    """Compare GPUs for a specific model from hardware recipe results."""

    DEFAULT_CSS = "GpuCompareScreen { layout: vertical; }"

    BINDINGS = [
        Binding("escape", "app.pop_screen", "Back", show=True),
    ]

    def __init__(self, model_id: str, model_name: str, options: list[dict]):
        """options: list of GPU option dicts from hardware_recipe all_options."""
        super().__init__()
        self.model_id = model_id
        self.model_name = model_name
        self.options = options[:6]  # max 6

    def compose(self) -> ComposeResult:
        yield Header(show_clock=False)
        yield Static(f"\n  [bold]GPU Compare — {self.model_name}[/]  [dim]({len(self.options)} GPUs)[/]\n")
        yield VerticalScroll(Static("", id="gpu-compare-content"))
        yield Footer()

    def on_mount(self) -> None:
        self._refresh_content()

    def _refresh_content(self) -> None:
        opts = self.options
        if not opts:
            self.query_one("#gpu-compare-content", Static).update("  [dim]No GPUs to compare[/]")
            return

        label_w = 16
        col_w = 22
        n = len(opts)

        def row(label: str, values: list[str]) -> str:
            cols = "".join(f"{v:<{col_w}}" for v in values)
            return f"  [dim]{label:<{label_w}}[/]{cols}\n"

        def header_row(values: list[str]) -> str:
            cols = "".join(f"[bold]{v:<{col_w}}[/]" for v in values)
            return f"  {'':>{label_w}}{cols}\n"

        lines = ""
        lines += header_row([o["gpu"] for o in opts])
        lines += "  " + "─" * (label_w + col_w * n) + "\n"

        lines += row("Vendor", [o.get("vendor", "—") for o in opts])
        lines += row("GPU Count", [f'{o["gpu_count"]}x' for o in opts])
        lines += row("Total VRAM", [f'{o["total_vram_gb"]:.0f}GB' for o in opts])
        lines += row("VRAM Usage", [f'{o.get("vram_usage", 0):.0f}%' for o in opts])
        lines += "\n"

        lines += row("Speed", [f'~{o["speed_toks"]} tok/s' for o in opts])
        lines += row("Price", [f'${o["price"]}' if o.get("price") else "—" for o in opts])
        lines += row("Tier", [o.get("tier", "—") for o in opts])
        lines += "\n"

        # Value score: speed per dollar
        lines += "  ─── [bold cyan]Value Analysis[/] ───\n"
        for o in opts:
            price = o.get("price") or 0
            speed = o.get("speed_toks", 0)
            value = speed / price if price > 0 else 0
            lines += (
                f"  [bold]{o['gpu']:20s}[/] "
                f"{bar(min(100, speed * 1.2), 15)} ~{speed} tok/s  "
            )
            if price:
                lines += f"[dim]${price}[/]  [cyan]{value:.2f} tok/s/$[/]"
            lines += "\n"

        lines += "\n  [dim]Press escape to go back[/]"

        self.query_one("#gpu-compare-content", Static).update(lines)
