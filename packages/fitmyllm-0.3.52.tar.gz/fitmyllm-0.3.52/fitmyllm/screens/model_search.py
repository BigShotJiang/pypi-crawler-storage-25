"""Model search screen — used by Find GPU and Enterprise flows."""

from textual.app import ComposeResult
from textual.screen import Screen
from textual.widgets import Header, Footer, Static, DataTable, Input
from textual.binding import Binding
from textual import work

from .. import api
from ..widgets import get_key


class ModelSearchScreen(Screen):
    DEFAULT_CSS = "ModelSearchScreen { layout: vertical; }"

    BINDINGS = [Binding("escape", "app.pop_screen", "Back")]

    def __init__(self, mode: str = "gpu"):
        super().__init__()
        self.mode = mode
        self._results: list[dict] = []

    def compose(self) -> ComposeResult:
        yield Header(show_clock=False)
        title = "Find GPU" if self.mode == "gpu" else "Enterprise"
        yield Static(f"\n  [bold]{title}[/] — search for a model\n")
        yield Input(placeholder="Type model name and press Enter (e.g. llama 70b, qwen 27b)...", id="model-search-input")
        yield DataTable(id="search-results", cursor_type="row")
        yield Footer()

    def on_mount(self) -> None:
        table = self.query_one("#search-results", DataTable)
        table.add_columns("Model", "Params", "Arch", "Provider")
        self.query_one("#model-search-input", Input).focus()

    def on_input_submitted(self, event: Input.Submitted) -> None:
        if event.value.strip():
            self._do_search(event.value.strip())

    @work(thread=True)
    def _do_search(self, query: str) -> None:
        key = get_key()
        if not key:
            return
        try:
            results = api.search_models(key, query)
            self.app.call_from_thread(self._show_results, results)
        except Exception as e:
            self.app.call_from_thread(self.notify, str(e), severity="error")

    def _show_results(self, results: list[dict]) -> None:
        self._results = results
        table = self.query_one("#search-results", DataTable)
        table.clear()
        for r in results:
            table.add_row(r["name"], f'{r["params_b"]}B', r["architecture"], r["provider"])
        if results:
            table.focus()

    def on_data_table_row_selected(self, event: DataTable.RowSelected) -> None:
        if not self._results:
            return
        m = self._results[event.cursor_row]
        if self.mode == "gpu":
            from .find_gpu import FindGpuScreen
            self.app.push_screen(FindGpuScreen(m["id"], m["name"]))
        else:
            from .enterprise_input import EnterpriseInputScreen
            self.app.push_screen(EnterpriseInputScreen(m["id"], m["name"]))
