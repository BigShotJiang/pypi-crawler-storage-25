"""Model Library screen — manage all installed models across backends and local GGUF."""

from __future__ import annotations

from rich.markup import escape

from textual.app import ComposeResult
from textual.screen import Screen
from textual.widgets import Header, Footer, Static, DataTable
from textual.containers import VerticalScroll
from textual.binding import Binding
from textual.css.query import NoMatches
from textual import work

from ..backends import detect_backends, get_backend, is_server_running, get_managed_port
from ..backends.openai_compat import OpenAICompatBackend
from ..models.store import get_inventory, remove_model, disk_usage, get_model_path


def _fmt_size(b: int) -> str:
    if b >= 1_073_741_824:
        return f"{b / 1_073_741_824:.1f} GB"
    if b >= 1_048_576:
        return f"{b / 1_048_576:.0f} MB"
    return f"{b / 1024:.0f} KB"


class ModelLibraryScreen(Screen):
    """Browse and manage installed models from all sources."""

    DEFAULT_CSS = "ModelLibraryScreen { layout: vertical; }"

    BINDINGS = [
        Binding("c", "chat_model", "Chat", show=True),
        Binding("d", "delete_model", "Delete", show=True),
        Binding("r", "refresh", "Refresh", show=True),
        Binding("escape", "app.pop_screen", "Back", show=True),
    ]

    def __init__(self) -> None:
        super().__init__()
        self._models: list[dict] = []  # [{name, source, tag, backend_name, filename, size}]

    def compose(self) -> ComposeResult:
        yield Header(show_clock=False)
        yield Static(
            "\n  [bold]Model Library[/]  [dim]Loading...[/]\n",
            id="lib-header",
        )
        yield DataTable(id="lib-table", cursor_type="row")
        yield Static("", id="lib-footer-info")
        yield Footer()

    def on_mount(self) -> None:
        table = self.query_one("#lib-table", DataTable)
        table.add_columns("Source", "Model", "Quant", "Size")
        self._load_models()

    def action_refresh(self) -> None:
        self._load_models()

    @work(thread=True)
    def _load_models(self) -> None:
        models: list[dict] = []
        inventory = get_inventory()
        seen_filenames: set[str] = set()

        # 1. Models from running backends (Ollama, llama-server, etc.)
        backends = detect_backends()
        for backend in backends:
            try:
                for m in backend.list_models():
                    name = m.get("name", "")

                    # llama-server returns full path; extract filename
                    display = name
                    basename = ""
                    if "/" in name or "\\" in name:
                        from pathlib import PurePosixPath
                        basename = PurePosixPath(name.replace("\\", "/")).name
                        display = basename.replace(".gguf", "")

                    # Match to a local GGUF file
                    matched_filename = None
                    for entry in inventory:
                        fname = entry.get("filename", "")
                        if basename and fname == basename:
                            matched_filename = fname
                            seen_filenames.add(fname)
                            break
                        if display.lower() in fname.lower().replace(".gguf", ""):
                            matched_filename = fname
                            seen_filenames.add(fname)
                            break

                    models.append({
                        "name": display,
                        "source": backend.name,
                        "tag": name,
                        "backend_name": backend.name,
                        "filename": matched_filename,
                        "size": m.get("size"),
                        "quant": "",
                    })
            except Exception:
                pass

        # 2. Local GGUF files from inventory (skip already-listed ones)
        for entry in inventory:
            filename = entry.get("filename", "")
            if filename in seen_filenames:
                continue
            path = get_model_path(filename)
            size = path.stat().st_size if path else entry.get("size_bytes", 0)
            models.append({
                "name": entry.get("name", filename),
                "source": "local GGUF",
                "tag": filename.replace(".gguf", ""),
                "backend_name": None,
                "filename": filename,
                "size": size,
                "quant": entry.get("quant_level", ""),
            })

        self._models = models
        self.app.call_from_thread(self._populate_table)

    def _populate_table(self) -> None:
        header = self.query_one("#lib-header", Static)
        table = self.query_one("#lib-table", DataTable)
        table.clear()

        if not self._models:
            header.update(
                "\n  [bold]Model Library[/]  [yellow]No models found[/]\n"
                "  [dim]Install models via Find Models or Quick Run[/]\n"
            )
            return

        header.update(
            f"\n  [bold]Model Library[/]  "
            f"[dim]{len(self._models)} models · "
            f"[bold]c[/bold]=chat · [bold]d[/bold]=delete · [bold]r[/bold]=refresh[/]\n"
        )

        for m in self._models:
            size_str = _fmt_size(m["size"]) if m.get("size") else "—"
            table.add_row(
                f"[dim]{m['source']}[/]",
                f"[bold]{escape(m['name'])}[/]",
                m.get("quant", ""),
                size_str,
            )

        # Disk usage footer
        usage = disk_usage()
        if usage["total_bytes"] > 0:
            total = _fmt_size(usage["total_bytes"])
            n = len(usage["models"])
            self.query_one("#lib-footer-info", Static).update(
                f"\n  [dim]Local GGUF storage: {total} ({n} files)[/]"
            )

        table.focus()

    def action_chat_model(self) -> None:
        """Open chat with the selected model."""
        try:
            table = self.query_one("#lib-table", DataTable)
        except NoMatches:
            return

        row = table.cursor_row
        if row >= len(self._models):
            return

        model = self._models[row]
        tag = model["tag"]
        backend_name = model.get("backend_name")
        filename = model.get("filename")

        from .chat import ChatScreen

        backend = None
        if backend_name:
            backend = get_backend(backend_name)
        elif filename:
            # Local GGUF — need llama-server
            path = get_model_path(filename)
            if not path:
                self.notify("GGUF file not found", severity="error")
                return

            # Check if llama-server is already managed
            port = get_managed_port()
            if port:
                backend = OpenAICompatBackend(
                    base_url=f"http://localhost:{port}",
                    name="llama-server",
                )
            else:
                self.notify(
                    "Start llama-server first, or use Quick Run for auto-setup",
                    severity="warning",
                )
                return

        self.app.push_screen(ChatScreen(tag, backend=backend))

    def action_delete_model(self) -> None:
        """Delete the selected model (local GGUF or Ollama)."""
        try:
            table = self.query_one("#lib-table", DataTable)
        except NoMatches:
            return

        row = table.cursor_row
        if row >= len(self._models):
            return

        model = self._models[row]
        filename = model.get("filename")
        backend_name = model.get("backend_name")

        if filename:
            # Local GGUF
            if remove_model(filename):
                self.notify(f"Deleted {filename}", timeout=3)
                self._load_models()
            else:
                self.notify(f"File not found: {filename}", severity="warning")
        elif backend_name == "ollama":
            # Ollama model — use ollama rm
            self._delete_ollama(model["tag"])
        else:
            self.notify(
                f"Cannot delete {model['name']} — managed by {model['source']}",
                severity="warning",
            )

    @work(thread=True)
    def _delete_ollama(self, tag: str) -> None:
        """Delete an Ollama model via 'ollama rm'."""
        import subprocess
        try:
            result = subprocess.run(
                ["ollama", "rm", tag],
                capture_output=True, text=True, timeout=30,
            )
            if result.returncode == 0:
                self.app.call_from_thread(self.notify, f"Deleted {tag} from Ollama", timeout=3)
                self._load_models()
            else:
                err = result.stderr.strip() or result.stdout.strip()
                self.app.call_from_thread(
                    self.notify, f"Failed: {err}", severity="error", timeout=5
                )
        except Exception as e:
            self.app.call_from_thread(
                self.notify, f"Error: {e}", severity="error", timeout=5
            )
