"""Tier list screen — models AND GPUs ranked S-F, mirrors website's Tier List tab."""

from textual.app import ComposeResult
from textual.screen import Screen
from textual.widgets import Header, Footer, Static, Select, DataTable
from textual.containers import VerticalScroll
from textual.binding import Binding
from textual import work

from .. import api
from ..widgets import get_key, bar
from ..detect import detect_gpu

MODEL_TIERS = [
    ("S", 90, 101, "bold green"),
    ("A", 75, 90, "bold cyan"),
    ("B", 60, 75, "bold blue"),
    ("C", 45, 60, "yellow"),
    ("D", 30, 45, "red"),
    ("F", 0, 30, "dim red"),
]

GPU_TIERS = [
    ("S", 80, 101, "bold green"),
    ("A", 60, 80, "bold cyan"),
    ("B", 40, 60, "bold blue"),
    ("C", 25, 40, "yellow"),
    ("D", 15, 25, "red"),
    ("F", 0, 15, "dim red"),
]


class TierListScreen(Screen):
    DEFAULT_CSS = "TierListScreen { layout: vertical; }"

    BINDINGS = [
        Binding("escape", "app.pop_screen", "Back"),
    ]

    def __init__(self, gpu_name: str | None = None):
        super().__init__()
        self.gpu_name = gpu_name
        self._tab = "models"

    def compose(self) -> ComposeResult:
        yield Header(show_clock=False)
        yield Static("\n  [bold]Tier List[/]", id="tier-title")
        yield Select(
            [("Models", "models"), ("GPUs", "gpus")],
            value="models", id="sel-tier-tab", allow_blank=False,
        )
        yield VerticalScroll(Static("  [dim]Loading...[/]", id="tier-content"), id="tier-scroll")
        yield Footer()

    def on_mount(self) -> None:
        self._load_models()

    def on_select_changed(self, event: Select.Changed) -> None:
        self._tab = str(event.value)
        if self._tab == "gpus":
            self._load_gpus()
        else:
            self._load_models()

    def _scroll_top(self) -> None:
        try:
            self.query_one("#tier-scroll", VerticalScroll).scroll_home(animate=False)
        except Exception:
            pass

    @work(thread=True)
    def _load_models(self) -> None:
        if not self.gpu_name:
            gpu = detect_gpu()
            if gpu:
                self.gpu_name = gpu["name"]
            else:
                self.app.call_from_thread(
                    self.query_one("#tier-content", Static).update,
                    "  [yellow]GPU not detected. Cannot generate model tier list.[/]"
                )
                return

        key = get_key()
        if not key:
            return
        try:
            data = api.recommend(key, self.gpu_name, use_case="chat", context_length=4096)
            self.app.call_from_thread(self._show_models, data)
        except Exception as e:
            self.app.call_from_thread(self.notify, str(e), severity="error")

    def _show_models(self, data: dict) -> None:
        recs = data.get("recommendations", [])
        gpu = data.get("gpu", {})

        lines = f"  [dim]GPU: {gpu.get('name', '?')} · {len(recs)} models ranked[/]\n\n"

        for tier_name, min_score, max_score, style in MODEL_TIERS:
            tier_models = [r for r in recs if min_score <= r["score"] < max_score]
            if not tier_models:
                continue

            lines += f"  [{style}]━━━ {tier_name} Tier ━━━[/]  [dim]({len(tier_models)} models)[/]\n"
            for r in tier_models:
                score = int(r["score"])
                speed = r.get("speed_toks")
                speed_str = f"~{speed} tok/s" if speed else "—"
                vram_pct = r.get("vram_percent", 0)
                lines += (
                    f"    [{style}]{score:>3}[/]  "
                    f"[bold]{r['model']['name']}[/]  "
                    f"[dim]{r['model']['params_b']}B {r['quant']['level']}[/]  "
                    f"[dim]{speed_str}  {vram_pct}% VRAM[/]\n"
                )
            lines += "\n"

        if not recs:
            lines += "  [dim]No models available[/]\n"

        self.query_one("#tier-content", Static).update(lines)
        self._scroll_top()

    @work(thread=True)
    def _load_gpus(self) -> None:
        key = get_key()
        if not key:
            return
        self.app.call_from_thread(
            self.query_one("#tier-content", Static).update,
            "  [dim]Loading GPU data...[/]"
        )
        try:
            # Fetch popular GPUs by searching common names
            all_gpus = []
            for query in ["RTX", "RX ", "Arc ", "M1", "M2", "M3", "M4", "A100", "H100", "L40", "Tesla"]:
                try:
                    results = api.search_gpus(key, query)
                    all_gpus.extend(results)
                except Exception:
                    pass
            # Deduplicate by name
            seen = set()
            unique = []
            for g in all_gpus:
                if g.get("name") not in seen:
                    seen.add(g["name"])
                    unique.append(g)
            self.app.call_from_thread(self._show_gpus, unique)
        except Exception as e:
            self.app.call_from_thread(self.notify, str(e), severity="error")

    def _show_gpus(self, gpus: list[dict]) -> None:
        scored = []
        for g in gpus:
            vram_mb = g.get("vram_mb", 0)
            bw = g.get("bandwidth_gbps", 0)
            if vram_mb < 2048 or bw <= 0:
                continue

            vram_gb = vram_mb / 1024
            fp16 = g.get("fp16_tflops") or 0

            vram_score = min(100, (vram_gb / 48) * 100)
            bw_score = min(100, (bw / 2000) * 100)
            tflops_score = min(100, (fp16 / 300) * 100) if fp16 else bw_score * 0.5

            fit_count = 0
            for params in [3, 7, 8, 13, 14, 27, 34, 70]:
                q4_vram = params * 4.5 / 8 * 1024 + 500
                if q4_vram <= vram_mb * 0.9:
                    fit_count += 1
            fit_score = min(100, (fit_count / 8) * 100)

            total = vram_score * 0.40 + bw_score * 0.30 + fit_score * 0.20 + tflops_score * 0.10

            vendor = g.get("vendor", "")
            eff = {"nvidia": 0.45, "amd": 0.50, "intel": 0.18, "apple": 0.50}.get(vendor, 0.35)
            speed_7b = round(bw / (7 * 4.5 / 8) * eff) if bw > 0 else 0

            if total >= 80: tier = "S"
            elif total >= 60: tier = "A"
            elif total >= 40: tier = "B"
            elif total >= 25: tier = "C"
            elif total >= 15: tier = "D"
            else: tier = "F"

            scored.append({
                **g, "vram_gb": round(vram_gb), "total_score": round(total),
                "tier": tier, "speed_7b": speed_7b, "fit_count": fit_count,
            })

        scored.sort(key=lambda x: x["total_score"], reverse=True)

        lines = f"  [dim]{len(scored)} GPUs ranked[/]\n\n"

        for tier_name, min_score, max_score, style in GPU_TIERS:
            tier_gpus = [g for g in scored if min_score <= g["total_score"] < max_score]
            if not tier_gpus:
                continue

            lines += f"  [{style}]━━━ {tier_name} Tier ━━━[/]  [dim]({len(tier_gpus)} GPUs)[/]\n"
            for g in tier_gpus[:12]:
                score = g["total_score"]
                price = f"${g['price_usd']}" if g.get("price_usd") else "—"
                speed = g["speed_7b"]
                lines += (
                    f"    [{style}]{score:>3}[/]  "
                    f"[bold]{g['name']}[/]  "
                    f"[dim]{g['vram_gb']}GB {g.get('memory_type', '')}[/]  "
                    f"[dim]{g.get('bandwidth_gbps', 0)} GB/s  ~{speed} tok/s (7B)  {price}[/]\n"
                )
            if len(tier_gpus) > 12:
                lines += f"    [dim]... +{len(tier_gpus) - 12} more[/]\n"
            lines += "\n"

        # Cloud alternatives
        lines += "  ─── [bold cyan]Cloud GPU Alternatives[/] ───\n\n"
        cloud_gpus = [
            ("RunPod", "H100 80GB SXM", 80, 3351, "$3.50/hr"),
            ("RunPod", "A100 80GB", 80, 2039, "$2.20/hr"),
            ("RunPod", "RTX 4090", 24, 1008, "$0.69/hr"),
            ("Vast.ai", "RTX 4090", 24, 1008, "$0.40/hr"),
            ("Vast.ai", "RTX 3090", 24, 936, "$0.20/hr"),
            ("Lambda", "H100 80GB", 80, 3351, "$2.49/hr"),
            ("Lambda", "A100 40GB", 40, 1555, "$1.10/hr"),
        ]
        lines += f"  {'Provider':10s} {'GPU':20s} {'VRAM':>6s} {'BW':>8s} {'Price':>10s}\n"
        lines += "  " + "─" * 58 + "\n"
        for provider, gpu, vram, bw, price in cloud_gpus:
            lines += f"  {provider:10s} {gpu:20s} {vram:>4}GB {bw:>5} GB/s {price:>10s}\n"

        self.query_one("#tier-content", Static).update(lines)
        self._scroll_top()
