"""Anonymous speed telemetry — collects tok/s during chat sessions."""

from __future__ import annotations

import statistics
import threading
import time

import httpx

from . import config
from .detect import detect_gpu
from .widgets import get_key

# Quant suffixes used to extract quantization from model tags/filenames
_QUANT_SUFFIXES = [
    "Q8_0", "Q4_K_M", "Q5_K_M", "Q6_K", "Q3_K_M", "Q4_K_S",
    "Q5_K_S", "Q6_K_L", "Q2_K", "Q3_K_S", "Q3_K_L", "IQ4_XS",
    "FP16", "F16", "BF16",
]


def _extract_model_info(tag: str) -> tuple[str, str]:
    """Extract (model_id, quant_level) from a model tag or filename.

    Returns cleaned model_id and quant_level (or empty string if unknown).
    """
    from pathlib import PurePosixPath

    name = tag
    if "/" in name or "\\" in name:
        name = PurePosixPath(name.replace("\\", "/")).name
    if name.endswith(".gguf"):
        name = name[:-5]

    quant = ""
    for qs in _QUANT_SUFFIXES:
        if name.endswith(f"-{qs}") or name.endswith(f"-{qs.lower()}"):
            quant = qs
            name = name[:-(len(qs) + 1)]
            break

    return name, quant


class SessionCollector:
    """Collects per-message speed metrics during a chat session.

    Usage::

        collector = SessionCollector(model_tag="Qwen3.5-4B-Q8_0",
                                      backend_name="llama-server")
        # after each streamed response:
        collector.record(token_count=142, elapsed=3.8, ttft_ms=210)
        # when session ends:
        collector.flush()  # uploads aggregated data in background
    """

    MIN_TOKENS = 5       # ignore very short responses
    MIN_SAMPLES = 2      # need at least 2 messages to report

    def __init__(
        self,
        model_tag: str,
        backend_name: str,
        quant_level: str = "",
    ) -> None:
        self.model_tag = model_tag
        self.backend_name = backend_name
        self._quant_override = quant_level
        self._samples: list[dict] = []

        # Detect GPU once at session start
        gpu = detect_gpu()
        self.gpu_name = gpu["name"] if gpu else "Unknown"
        self.gpu_vram_mb = gpu.get("vram_mb") if gpu else None

    def has_data(self) -> bool:
        """Check if there are enough samples to upload."""
        return len(self._samples) >= self.MIN_SAMPLES

    def record(self, token_count: int, elapsed: float, ttft_ms: float) -> None:
        """Record metrics for a single response."""
        if token_count < self.MIN_TOKENS or elapsed <= 0:
            return
        self._samples.append({
            "tps": token_count / elapsed,
            "ttft_ms": ttft_ms,
            "tokens": token_count,
        })

    def flush(self) -> None:
        """Upload aggregated session metrics in a background thread."""
        if not config.is_telemetry_enabled():
            return
        if len(self._samples) < self.MIN_SAMPLES:
            return

        # Snapshot and clear
        samples = self._samples.copy()
        self._samples.clear()

        thread = threading.Thread(
            target=self._upload, args=(samples,), daemon=True,
        )
        thread.start()

    def _upload(self, samples: list[dict]) -> None:
        """Aggregate and send telemetry to the API."""
        key = get_key()
        if not key:
            return

        tps_values = [s["tps"] for s in samples]
        ttft_values = [s["ttft_ms"] for s in samples if s["ttft_ms"] > 0]

        # Use median to reduce outlier noise
        median_tps = statistics.median(tps_values)
        median_ttft = statistics.median(ttft_values) if ttft_values else None
        total_tokens = sum(s["tokens"] for s in samples)

        model_id, quant = _extract_model_info(self.model_tag)
        quant = self._quant_override or quant or "unknown"

        # Map backend to runtime
        runtime_map = {
            "llama-server": "llama.cpp",
            "ollama": "ollama",
            "vllm": "vllm",
            "lm-studio": "llama.cpp",
            "koboldcpp": "llama.cpp",
        }
        runtime = runtime_map.get(self.backend_name, "other")

        payload = {
            "model_id": model_id,
            "quant_level": quant,
            "gpu_name": self.gpu_name,
            "gpu_vram_mb": self.gpu_vram_mb,
            "tokens_per_second": round(median_tps, 2),
            "time_to_first_token_ms": round(median_ttft) if median_ttft else None,
            "context_length": 4096,
            "runtime": runtime,
            "sample_count": len(samples),
            "total_tokens": total_tokens,
            "source": "telemetry",
        }

        try:
            base = config.get_api_base()
            httpx.post(
                f"{base}/benchmarks/telemetry",
                json=payload,
                headers={
                    "Authorization": f"Bearer {key}",
                    "User-Agent": "fitmyllm-cli/0.3",
                },
                timeout=10.0,
            )
        except Exception:
            pass  # telemetry is best-effort, never fail loudly
