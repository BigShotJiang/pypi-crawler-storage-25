"""FitMyLLM — Find the best local AI model for your GPU."""
__version__ = "0.1.0"
