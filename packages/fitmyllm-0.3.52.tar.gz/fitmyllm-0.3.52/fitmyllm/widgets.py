"""Shared widget helpers for FitMyLLM TUI."""

from .config import get_api_key, get_api_base


def get_key() -> str | None:
    """Get API key, allowing 'dev' for localhost."""
    return get_api_key() or ("dev" if "localhost" in get_api_base() else None)


def bar(pct: float, w: int) -> str:
    """Render a colored progress bar (green/yellow/red by value)."""
    f = round((min(100, max(0, pct)) / 100) * w)
    c = "green" if pct >= 70 else "yellow" if pct >= 50 else "red"
    return f"[{c}]{'█' * f}[/][dim]{'░' * (w - f)}[/]"


def vbar(pct: float, w: int) -> str:
    """Render a colored VRAM usage bar (green=low, red=high)."""
    f = round((min(100, pct) / 100) * w)
    c = "green" if pct <= 60 else "blue" if pct <= 80 else "yellow" if pct <= 95 else "red"
    return f"[{c}]{'█' * f}[/][dim]{'░' * (w - f)}[/]"


FIT_COLORS = {
    "excellent": "green",
    "good": "blue",
    "tight": "yellow",
    "offload": "red",
}
