"""GGUF model inventory — track downloaded models in ~/.fitmyllm/models/."""

from __future__ import annotations

import json
from pathlib import Path

from ..config import get_models_dir


def _inventory_path() -> Path:
    return get_models_dir() / "inventory.json"


def _load_inventory() -> list[dict]:
    path = _inventory_path()
    if path.exists():
        try:
            return json.loads(path.read_text())
        except Exception:
            pass
    return []


def _save_inventory(entries: list[dict]) -> None:
    path = _inventory_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(entries, indent=2) + "\n")


def get_inventory() -> list[dict]:
    """Return all downloaded models.

    Each entry: {id, name, filename, size_bytes, quant_level, repo, downloaded_at}
    """
    return _load_inventory()


def add_to_inventory(entry: dict) -> None:
    """Add a model to the inventory after download."""
    entries = _load_inventory()
    # Replace if same filename exists
    entries = [e for e in entries if e.get("filename") != entry.get("filename")]
    entries.append(entry)
    _save_inventory(entries)


def remove_model(filename: str) -> bool:
    """Delete a GGUF file and remove from inventory. Returns True if found."""
    models_dir = get_models_dir()
    path = models_dir / filename
    if path.exists():
        path.unlink()

    entries = _load_inventory()
    before = len(entries)
    entries = [e for e in entries if e.get("filename") != filename]
    if len(entries) < before:
        _save_inventory(entries)
        return True
    return False


def get_model_path(filename: str) -> Path | None:
    """Return full path to a GGUF file if it exists."""
    path = get_models_dir() / filename
    return path if path.exists() else None


def disk_usage() -> dict:
    """Return disk usage info.

    Returns: {total_bytes: int, models: [{filename, size_bytes}]}
    """
    models_dir = get_models_dir()
    result: dict = {"total_bytes": 0, "models": []}

    if not models_dir.exists():
        return result

    for entry in get_inventory():
        filename = entry.get("filename", "")
        path = models_dir / filename
        if path.exists():
            size = path.stat().st_size
            result["models"].append({"filename": filename, "size_bytes": size})
            result["total_bytes"] += size

    return result
