"""GGUF download — resolves via FitMyLLM registry, falls back to HuggingFace."""

from __future__ import annotations

import os
from pathlib import Path
from typing import Callable

import httpx

from ..config import get_api_base, get_models_dir
from ..widgets import get_key

DL_HEADERS = {"User-Agent": "fitmyllm/0.3 (https://fitmyllm.com)"}


def _get_hf_headers() -> dict:
    """Build HuggingFace headers with optional token."""
    headers = dict(DL_HEADERS)
    hf_token = os.environ.get("HF_TOKEN") or os.environ.get("HUGGING_FACE_HUB_TOKEN")
    if not hf_token:
        token_path = Path.home() / ".cache" / "huggingface" / "token"
        if token_path.exists():
            hf_token = token_path.read_text().strip()
    if hf_token:
        headers["Authorization"] = f"Bearer {hf_token}"
    return headers


def resolve_gguf_url(repo: str, quant_level: str, model_id: str = "") -> str | None:
    """Find the GGUF download URL. Tries FitMyLLM registry first, then HuggingFace.

    Args:
        repo: HuggingFace repo ID, e.g. "bartowski/Llama-3.2-3B-Instruct-GGUF"
        quant_level: e.g. "Q4_K_M", "Q5_K_M", "Q8_0"
        model_id: FitMyLLM model ID for registry lookup (optional).

    Returns:
        Direct download URL or None if not found.
    """
    # 1. Try FitMyLLM registry (no HF auth needed, server-side caching)
    url = _resolve_via_registry(model_id or repo, quant_level)
    if url:
        return url

    # 2. Fallback: query HuggingFace API directly
    if repo:
        url = _resolve_via_huggingface(repo, quant_level)
        if url:
            return url

    # 3. Last resort: construct URL directly (common naming convention)
    if repo:
        # Most GGUF repos follow: {ModelName}-{QuantLevel}.gguf
        model_part = repo.split("/")[-1].replace("-GGUF", "")
        guess = f"https://huggingface.co/{repo}/resolve/main/{model_part}-{quant_level}.gguf"
        try:
            resp = httpx.head(guess, follow_redirects=True, headers=_get_hf_headers(), timeout=10.0)
            if resp.status_code == 200:
                return guess
        except Exception:
            pass

    return None


def _resolve_via_registry(model_query: str, quant_level: str) -> str | None:
    """Resolve GGUF URL via FitMyLLM registry API."""
    key = get_key()
    if not key:
        return None

    try:
        base = get_api_base()
        resp = httpx.get(
            f"{base}/registry/resolve",
            params={"model": model_query, "quant": quant_level},
            headers={"Authorization": f"Bearer {key}", **DL_HEADERS},
            timeout=10.0,
        )
        if resp.status_code == 200:
            data = resp.json()
            return data.get("url")
    except Exception:
        pass

    return None


def _resolve_via_huggingface(repo: str, quant_level: str) -> str | None:
    """Resolve GGUF URL directly from HuggingFace API."""
    try:
        resp = httpx.get(
            f"https://huggingface.co/api/models/{repo}",
            headers=_get_hf_headers(),
            timeout=30.0,
        )
        resp.raise_for_status()
        data = resp.json()
    except httpx.HTTPStatusError as e:
        if e.response.status_code in (401, 403):
            # Don't crash — return None so the fallback (direct URL) can try
            return None
        if e.response.status_code == 404:
            return None
        return None
    except Exception:
        return None

    siblings = data.get("siblings", [])
    quant_lower = quant_level.lower()

    candidates = []
    for s in siblings:
        fname = s.get("rfilename", "")
        if not fname.endswith(".gguf"):
            continue
        if quant_lower in fname.lower():
            candidates.append(fname)

    if not candidates:
        return None

    candidates.sort(key=len)
    return f"https://huggingface.co/{repo}/resolve/main/{candidates[0]}"


def download_gguf(
    url: str,
    filename: str | None = None,
    progress_callback: Callable[[int, int], None] | None = None,
) -> Path:
    """Download a GGUF file to the models directory.

    Supports resume if a partial download (.part file) exists.
    """
    models_dir = get_models_dir()
    models_dir.mkdir(parents=True, exist_ok=True)

    if filename is None:
        filename = url.split("/")[-1].split("?")[0]

    dest = models_dir / filename
    part = dest.with_suffix(dest.suffix + ".part")

    resume_from = 0
    if part.exists():
        resume_from = part.stat().st_size

    headers = _get_hf_headers()

    # Try primary URL, then HF mirror as fallback
    urls_to_try = [url]
    if "huggingface.co" in url:
        urls_to_try.append(url.replace("huggingface.co", "hf-mirror.com"))

    last_error = ""
    for try_url in urls_to_try:
        try:
            _download_stream(try_url, part, headers, resume_from, progress_callback)
            # Success — rename and return
            part.rename(dest)
            return dest
        except RuntimeError as e:
            last_error = str(e)
            # Reset for next attempt
            if part.exists() and resume_from == 0:
                part.unlink(missing_ok=True)
            continue

    raise RuntimeError(last_error)

    # Unreachable — but satisfies type checker
    raise RuntimeError("Download failed")


def _download_stream(
    url: str,
    part: Path,
    headers: dict,
    resume_from: int,
    progress_callback: Callable[[int, int], None] | None,
) -> None:
    """Stream download a URL to a .part file."""
    dl_headers = dict(headers)
    if resume_from > 0:
        dl_headers["Range"] = f"bytes={resume_from}-"

    try:
        with httpx.stream(
            "GET", url,
            headers=dl_headers,
            follow_redirects=True,
            timeout=httpx.Timeout(connect=30.0, read=120.0, write=60.0, pool=30.0),
        ) as resp:
            if resp.status_code in (401, 403):
                raise RuntimeError(
                    "This model requires authentication.\n"
                    "  Set token: export HF_TOKEN=hf_xxxxx"
                )
            resp.raise_for_status()

            if resp.status_code == 206:
                total = resume_from + int(resp.headers.get("content-length", 0))
                downloaded = resume_from
                mode = "ab"
            else:
                total = int(resp.headers.get("content-length", 0))
                downloaded = 0
                mode = "wb"

            with open(part, mode) as f:
                for chunk in resp.iter_bytes(chunk_size=1024 * 1024):
                    f.write(chunk)
                    downloaded += len(chunk)
                    if progress_callback:
                        progress_callback(downloaded, total)

    except RuntimeError:
        raise
    except httpx.ConnectError:
        raise RuntimeError(f"Cannot connect to {url.split('/')[2]}")
    except httpx.TimeoutException:
        if part.exists() and part.stat().st_size > 0:
            size_mb = part.stat().st_size // (1024 * 1024)
            raise RuntimeError(f"Timeout ({size_mb}MB downloaded). Run again to resume.")
        raise RuntimeError("Connection timed out.")
    except Exception as e:
        raise RuntimeError(f"Download error: {e}")
