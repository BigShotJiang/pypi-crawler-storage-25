"""Shared constants for FitMyLLM TUI."""

USE_CASES = ["chat", "coding", "reasoning", "creative", "vision", "roleplay", "agentic", "embedding"]

CONTEXT_OPTIONS = [
    ("4K", "4096"), ("8K", "8192"), ("16K", "16384"),
    ("32K", "32768"), ("64K", "65536"), ("128K", "131072"),
]

SORT_OPTIONS = [
    ("Score", "score"), ("Speed", "speed"), ("Quality", "quality"),
    ("VRAM (lowest)", "vram"), ("Params (smallest)", "params"),
]

BENCHMARK_SORT_OPTIONS = [
    ("IFEval", "bench_ifeval"),
    ("MMLU-PRO", "bench_mmlu_pro"),
    ("MATH", "bench_math"),
    ("BBH", "bench_bbh"),
    ("GPQA", "bench_gpqa"),
    ("MUSR", "bench_musr"),
    ("HumanEval", "bench_humaneval"),
    ("BigCodeBench", "bench_bigcodebench"),
    ("LiveCodeBench", "bench_livecodebench"),
    ("SWE-bench", "bench_swe_bench"),
    ("AIME", "bench_aime"),
    ("MATH-500", "bench_math500"),
    ("GPQA Diamond", "bench_gpqa_diamond"),
    ("HLE", "bench_hle"),
]

SIZE_OPTIONS = [
    ("All sizes", "all"), ("Small ≤7B", "small"), ("Medium 8-13B", "medium"),
    ("Large 14-34B", "large"), ("XL 35B+", "xlarge"),
]

ARCH_OPTIONS = [("All", "all"), ("Dense only", "dense"), ("MoE only", "moe")]

SPEED_OPTIONS = [
    ("Any speed", "0"), ("≥5 tok/s", "5"), ("≥10 tok/s", "10"),
    ("≥20 tok/s", "20"), ("≥30 tok/s", "30"), ("≥50 tok/s", "50"),
    ("≥80 tok/s", "80"), ("≥100 tok/s", "100"),
]

KV_QUANT_OPTIONS = [
    ("FP16 (default)", "fp16"), ("FP8 (-50% KV)", "fp8"),
    ("INT8 (-50% KV)", "int8"), ("INT4 (-75% KV)", "int4"),
]

FAMILY_OPTIONS = [
    ("All families", "all"),
    ("Llama", "llama"), ("Qwen", "qwen"), ("Mistral", "mistral"),
    ("DeepSeek", "deepseek"), ("Gemma", "gemma"), ("Phi", "phi"),
    ("Command", "command"), ("GLM", "glm"), ("Yi", "yi"),
    ("Falcon", "falcon"), ("Nemotron", "nemotron"), ("Granite", "granite"),
    ("EXAONE", "exaone"), ("OLMo", "olmo"), ("Jamba", "jamba"),
    ("Kimi", "kimi"), ("MiniMax", "minimax"), ("MIMO", "mimo"),
    ("StarCoder", "starcoder"), ("InternLM", "internlm"),
    ("BLOOM", "bloom"), ("StableLM", "stablelm"),
    ("ERNIE", "ernie"), ("Zephyr", "zephyr"),
]

QUANT_OPTIONS = [
    ("All quants", "all"),
    ("Q3 (3-bit)", "q3"), ("Q4 (4-bit)", "q4"), ("Q5 (5-bit)", "q5"),
    ("Q6 (6-bit)", "q6"), ("Q8 (8-bit)", "q8"), ("FP16", "fp16"),
]

# Map quant filter selection to actual quant level strings
QUANT_LEVEL_MAP = {
    "q3": ["IQ3_XXS", "IQ3_XS", "Q3_K_S", "IQ3_M", "Q3_K_M", "Q3_K_L"],
    "q4": ["IQ4_XS", "Q4_K_S", "Q4_K_M"],
    "q5": ["Q5_K_S", "Q5_K_M"],
    "q6": ["Q6_K"],
    "q8": ["Q8_0"],
    "fp16": ["FP16"],
}

GPU_COUNT_OPTIONS = [
    ("1x GPU", "1"), ("2x GPU", "2"), ("4x GPU", "4"), ("8x GPU", "8"),
]

CAPABILITY_OPTIONS = [
    ("Multilingual", "multilingual"),
    ("Vision", "vision"),
    ("Tool Use", "tool_use"),
    ("Coding", "coding"),
    ("Reasoning", "reasoning"),
    ("Math", "math"),
    ("Embedding", "embedding"),
]

BENCHMARK_MIN_FIELDS = [
    ("IFEval", "min_ifeval"),
    ("MMLU-PRO", "min_mmlu"),
    ("MATH", "min_math"),
    ("Coding", "min_coding"),
    ("BBH", "min_bbh"),
    ("GPQA", "min_gpqa"),
    ("HumanEval", "min_humaneval"),
    ("MBPP", "min_mbpp"),
    ("GPQA Diamond", "min_gpqa_diamond"),
    ("LiveCodeBench", "min_livecodebench"),
    ("AIME", "min_aime"),
    ("MATH-500", "min_math500"),
    ("HLE", "min_hle"),
    ("SWE-bench", "min_swe_bench"),
]

ENGINES = {
    "ollama": {"check": "ollama", "cmd": "ollama pull {tag}", "run": "ollama run {tag}"},
    "llama-server": {"check": "llama-server", "cmd": "llama-server -m {gguf} -ngl {ngl} -c {ctx} --port 8080", "run": "llama-server -m {gguf} -ngl {ngl} -c {ctx} --port 8080"},
    "llama.cpp": {"check": "llama-cli", "cmd": "llama-cli -m {gguf} -ngl 99 -c 4096", "run": "llama-cli -m {gguf} -ngl 99 -c 4096 -cnv"},
    "vllm": {"check": "vllm", "cmd": "vllm serve {hf_id}", "run": "vllm serve {hf_id}"},
    "lm-studio": {"check": "lms", "cmd": "lms load {hf_id}", "run": "lms run {hf_id}"},
    "koboldcpp": {"check": "koboldcpp", "cmd": "koboldcpp {gguf} --gpulayers 99", "run": "koboldcpp {gguf} --gpulayers 99"},
    "jan": {"check": "jan", "cmd": "jan run {hf_id}", "run": "jan run {hf_id}"},
    "docker": {"check": "docker", "cmd": "docker model run {hf_id}", "run": "docker model run {hf_id}"},
}
