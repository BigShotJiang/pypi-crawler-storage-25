"""CSS styles for FitMyLLM TUI."""

CSS = """
Screen { background: $surface; }

#gpu-bar {
    dock: top;
    height: auto;
    max-height: 4;
    padding: 0 2;
    background: $primary-background;
}

#filters-panel {
    width: 34;
    padding: 1;
    background: $surface;
    border-right: solid $primary-darken-2;
}
#filters-panel Label {
    margin-top: 1;
    color: $text-muted;
    text-style: bold;
}
#filters-panel Select {
    width: 100%;
}
#filters-panel Input {
    width: 100%;
}

#gpu-search-input {
    dock: top;
    margin: 0 2;
}

.switch-label {
    padding: 0 0 0 1;
    height: 1;
}

#filters-panel Switch {
    height: 1;
    min-width: 8;
}

#detail-panel {
    dock: bottom;
    height: auto;
    max-height: 6;
    padding: 0 2;
    background: $panel;
    border-top: solid $primary-darken-2;
}

#gpu-filters-panel {
    width: 28;
    padding: 1;
    background: $surface;
    border-right: solid $primary-darken-2;
}
#gpu-filters-panel Label {
    margin-top: 1;
    color: $text-muted;
    text-style: bold;
}
#gpu-filters-panel Select {
    width: 100%;
}

#sim-params {
    width: 28;
    padding: 1;
    background: $surface;
    border-right: solid $primary-darken-2;
}
#sim-params Label {
    margin-top: 1;
    color: $text-muted;
    text-style: bold;
}
#sim-params Select {
    width: 100%;
}
#sim-params Input {
    width: 100%;
}

DataTable { height: 1fr; }

LoadingIndicator { height: 3; }

#search-results { height: 1fr; }
"""
