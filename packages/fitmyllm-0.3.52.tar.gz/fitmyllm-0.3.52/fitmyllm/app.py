"""FitMyLLM TUI — Textual app."""

from textual.app import App
from textual.binding import Binding

from .styles import CSS
from .screens.menu import MenuScreen


class FitMyLLMApp(App):
    TITLE = "fitmyllm"
    SUB_TITLE = "Find the best local AI model"
    CSS = CSS
    BINDINGS = [Binding("q", "quit", "Quit", show=False)]

    def __init__(self, direct_screen: str | None = None,
                 direct_args: dict | None = None, **kwargs):
        super().__init__(**kwargs)
        self._direct_screen = direct_screen
        self._direct_args = direct_args or {}

    def on_mount(self) -> None:
        if self._direct_screen == "chat":
            from .screens.chat import ChatScreen
            self.push_screen(ChatScreen(**self._direct_args))
        elif self._direct_screen == "benchmark":
            from .screens.bench_submit import BenchSubmitScreen
            self.push_screen(BenchSubmitScreen())
        elif self._direct_screen == "my-benchmarks":
            from .screens.my_benchmarks import MyBenchmarksScreen
            self.push_screen(MyBenchmarksScreen())
        else:
            self.push_screen(MenuScreen())
