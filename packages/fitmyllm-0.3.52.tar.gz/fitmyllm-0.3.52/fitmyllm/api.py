"""FitMyLLM API client with offline cache support."""
import hashlib
import json
import time
from pathlib import Path

import httpx
from .config import get_api_base

TIMEOUT = 30.0
CACHE_DIR = Path.home() / ".fitmyllm" / "cache"
CACHE_TTL = 86400  # 24 hours


def _cache_key(method: str, url: str, body: dict | None = None) -> str:
    """Generate a cache key from request parameters."""
    raw = f"{method}:{url}:{json.dumps(body, sort_keys=True) if body else ''}"
    return hashlib.md5(raw.encode()).hexdigest()


def _get_cache(key: str) -> dict | list | None:
    """Read from cache if fresh."""
    path = CACHE_DIR / f"{key}.json"
    if path.exists():
        try:
            data = json.loads(path.read_text())
            if time.time() - data.get("_ts", 0) < CACHE_TTL:
                return data.get("_data")
        except Exception:
            pass
    return None


def _set_cache(key: str, data) -> None:
    """Write response to cache."""
    try:
        CACHE_DIR.mkdir(parents=True, exist_ok=True)
        path = CACHE_DIR / f"{key}.json"
        path.write_text(json.dumps({"_ts": time.time(), "_data": data}))
    except Exception:
        pass

def _headers(api_key: str) -> dict:
    return {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json",
        "User-Agent": "fitmyllm-cli/0.1.0",
    }

def _handle_error(resp: httpx.Response) -> None:
    if resp.status_code == 401:
        raise Exception("Invalid API key. Get one at https://www.fitmyllm.com/?tab=mcp")
    if resp.status_code == 404:
        data = resp.json()
        raise Exception(data.get("error", "Not found"))
    if resp.status_code == 429:
        raise Exception("Rate limit exceeded (30/min). Wait and retry.")
    if not resp.is_success:
        raise Exception(f"API error ({resp.status_code})")

def recommend(api_key: str, gpu_name: str, use_case: str = "chat",
              context_length: int = 4096, ram_gb: int | None = None,
              sort_by: str = "score", size_ranges: list[str] | None = None,
              architectures: list[str] | None = None, families: list[str] | None = None,
              min_speed: int | None = None, kv_cache_quant: str = "fp16",
              only_fits_vram: bool = False, show_offload: bool = True,
              show_cpu_only: bool = True,
              quant_levels: list[str] | None = None,
              benchmark_mins: dict[str, float] | None = None,
              custom_benchmark_weights: dict[str, float] | None = None,
              gpu_count: int | None = None,
              nvlink: bool = False,
              capabilities: list[str] | None = None) -> dict:
    """Get model recommendations for a GPU with full filter support."""
    body: dict = {
        "gpu_name": gpu_name,
        "use_case": use_case,
        "context_length": context_length,
        "sort_by": sort_by,
        "kv_cache_quant": kv_cache_quant,
        "only_fits_vram": only_fits_vram,
        "show_offload": show_offload,
        "show_cpu_only": show_cpu_only,
    }
    if ram_gb is not None:
        body["ram_gb"] = ram_gb
    if size_ranges:
        body["size_ranges"] = size_ranges
    if architectures:
        body["architectures"] = architectures
    if families:
        body["families"] = families
    if min_speed is not None:
        body["min_speed"] = min_speed
    if quant_levels:
        body["quant_levels"] = quant_levels
    if benchmark_mins:
        body.update(benchmark_mins)
    if custom_benchmark_weights:
        body["custom_benchmark_weights"] = custom_benchmark_weights
    if gpu_count and gpu_count > 1:
        body["gpu_count"] = gpu_count
        body["nvlink"] = nvlink
    if capabilities:
        body["capabilities"] = capabilities

    url = f"{get_api_base()}/recommend"
    cache_k = _cache_key("POST", url, body)
    try:
        resp = httpx.post(url, headers=_headers(api_key), json=body, timeout=TIMEOUT)
        _handle_error(resp)
        result = resp.json()
        _set_cache(cache_k, result)
        return result
    except (httpx.ConnectError, httpx.TimeoutException):
        cached = _get_cache(cache_k)
        if cached:
            return cached
        raise Exception("Offline and no cached data available")

def get_model(api_key: str, model_id: str) -> dict:
    """Get full model details."""
    resp = httpx.get(
        f"{get_api_base()}/models/{model_id}",
        headers=_headers(api_key),
        timeout=TIMEOUT,
    )
    _handle_error(resp)
    return resp.json()

def hardware_recipe(api_key: str, model_name: str, **kwargs) -> dict:
    """Get GPU recommendations for a model."""
    url = f"{get_api_base()}/hardware-recipe"
    body = {"model_name": model_name, **kwargs}
    cache_k = _cache_key("POST", url, body)
    try:
        resp = httpx.post(url, headers=_headers(api_key), json=body, timeout=TIMEOUT)
        _handle_error(resp)
        result = resp.json()
        _set_cache(cache_k, result)
        return result
    except (httpx.ConnectError, httpx.TimeoutException):
        cached = _get_cache(cache_k)
        if cached:
            return cached
        raise Exception("Offline and no cached data available")

def search_models(api_key: str, query: str) -> list[dict]:
    """Search models by name."""
    resp = httpx.get(
        f"{get_api_base()}/models/search",
        params={"q": query},
        headers=_headers(api_key),
        timeout=TIMEOUT,
    )
    _handle_error(resp)
    return resp.json().get("results", [])

def search_gpus(api_key: str, query: str, vendor: str | None = None) -> list[dict]:
    """Search GPUs by name."""
    params: dict = {"q": query}
    if vendor:
        params["vendor"] = vendor
    resp = httpx.get(
        f"{get_api_base()}/gpus/search",
        params=params,
        headers=_headers(api_key),
        timeout=TIMEOUT,
    )
    _handle_error(resp)
    return resp.json()


def get_all_models(api_key: str) -> list[dict]:
    """Fetch all models with benchmarks via v1 data endpoint."""
    # Get models in batches
    all_models = []
    for page in range(0, 15):  # max 750 models
        url = f"{get_api_base()}/data/models?page={page}&limit=50"
        cache_k = _cache_key("GET", url)
        try:
            resp = httpx.get(url, headers=_headers(api_key), timeout=TIMEOUT)
            if not resp.is_success:
                break
            batch = resp.json()
            if not batch:
                break
            all_models.extend(batch)
            _set_cache(cache_k, batch)
        except (httpx.ConnectError, httpx.TimeoutException):
            cached = _get_cache(cache_k)
            if cached:
                all_models.extend(cached)
            break
    return all_models


def fetch_hf_readme(api_key: str, hf_id: str) -> str:
    """Fetch HuggingFace model README via v1 endpoint."""
    resp = httpx.get(
        f"{get_api_base()}/hf-readme",
        params={"id": hf_id},
        headers=_headers(api_key),
        timeout=15.0,
    )
    if resp.is_success:
        data = resp.json()
        return data.get("readme", data.get("content", ""))
    return ""


def benchmark_stats(api_key: str, gpu_name: str, model_id: str | None = None) -> list[dict]:
    """Get aggregated community speed stats for a GPU (and optionally a model)."""
    params: dict = {"gpu_name": gpu_name}
    if model_id:
        params["model_id"] = model_id
    url = f"{get_api_base()}/benchmarks/stats"
    cache_k = _cache_key("GET", url + str(params))
    try:
        resp = httpx.get(url, params=params, headers=_headers(api_key), timeout=10.0)
        if resp.is_success:
            result = resp.json().get("stats", [])
            _set_cache(cache_k, result)
            return result
        return []
    except (httpx.ConnectError, httpx.TimeoutException):
        cached = _get_cache(cache_k)
        return cached if cached else []


def my_benchmarks(api_key: str) -> list[dict]:
    """Fetch the user's own submitted benchmarks."""
    resp = httpx.get(
        f"{get_api_base()}/benchmarks/mine",
        headers=_headers(api_key),
        timeout=10.0,
    )
    if resp.is_success:
        return resp.json().get("benchmarks", [])
    return []


def enterprise(api_key: str, model_name: str, concurrent_users: int = 10,
               include: list[str] | None = None,
               additional_models: list[dict] | None = None,
               architecture: dict | None = None) -> dict:
    """Get enterprise deployment sizing with optional expanded sections."""
    url = f"{get_api_base()}/enterprise"
    body: dict = {"model_name": model_name, "concurrent_users": concurrent_users}
    if include:
        body["include"] = include
    if additional_models:
        body["additional_models"] = additional_models
    if architecture:
        body["architecture"] = architecture
    cache_k = _cache_key("POST", url, body)
    try:
        resp = httpx.post(url, headers=_headers(api_key), json=body, timeout=TIMEOUT)
        _handle_error(resp)
        result = resp.json()
        _set_cache(cache_k, result)
        return result
    except (httpx.ConnectError, httpx.TimeoutException):
        cached = _get_cache(cache_k)
        if cached:
            return cached
        raise Exception("Offline and no cached data available")
