"""Backend registry — detect running backends and select the best one."""

from __future__ import annotations

from .base import InferenceBackend
from .ollama import OllamaBackend, DEFAULT_OLLAMA_URL
from .openai_compat import OpenAICompatBackend, DEFAULT_LLAMA_SERVER_URL

# Well-known backends to probe (order = priority: autonomous first, Ollama last)
_KNOWN_BACKENDS: list[tuple[str, str, type]] = [
    ("llama-server", DEFAULT_LLAMA_SERVER_URL, OpenAICompatBackend),
    ("vllm", "http://localhost:8000", OpenAICompatBackend),
    ("lm-studio", "http://localhost:1234", OpenAICompatBackend),
    ("koboldcpp", "http://localhost:5001", OpenAICompatBackend),
    ("ollama", DEFAULT_OLLAMA_URL, OllamaBackend),
]


def detect_backends() -> list[InferenceBackend]:
    """Probe known ports and return all reachable backends."""
    available: list[InferenceBackend] = []
    for name, url, cls in _KNOWN_BACKENDS:
        if cls is OpenAICompatBackend:
            backend = cls(base_url=url, name=name)
        else:
            backend = cls(base_url=url)
        if backend.is_available():
            available.append(backend)
    return available


def get_backend(preference: str | None = None) -> InferenceBackend | None:
    """Get a backend, preferring the user's choice.

    Args:
        preference: Backend name to prefer ("llama-server", "vllm", "lm-studio", "ollama").
                    If None, reads from config. Falls back to first available.
    """
    if preference is None:
        from .. import config
        preference = config.get_preferred_backend()

    backends = detect_backends()
    if not backends:
        return None

    if preference:
        for b in backends:
            if b.name == preference:
                return b

    # Default: first available (llama-server first, Ollama last)
    return backends[0]
