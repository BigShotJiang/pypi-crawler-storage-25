"""Base protocol and data types for inference backends."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Iterator, Protocol, runtime_checkable


@dataclass
class StreamChunk:
    """A single chunk from a streaming chat response."""

    content: str  # token text
    done: bool  # is this the final chunk?


@runtime_checkable
class InferenceBackend(Protocol):
    """Protocol for inference backends (Ollama, llama-server, etc.)."""

    name: str
    base_url: str

    def is_available(self) -> bool:
        """Check if this backend is reachable (health check)."""
        ...

    def list_models(self) -> list[dict]:
        """Return loaded/available models.

        Each dict has at least: {"name": str, "size": int | None}
        """
        ...

    def stream_chat(
        self,
        model: str,
        messages: list[dict],
        timeout: float = 120.0,
    ) -> Iterator[StreamChunk]:
        """Yield streaming chat tokens.

        This is a blocking generator meant to be called from a worker thread.
        """
        ...
