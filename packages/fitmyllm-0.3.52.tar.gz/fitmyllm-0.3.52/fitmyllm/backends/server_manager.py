"""Server lifecycle manager — start/stop llama-server as a child process."""

from __future__ import annotations

import atexit
import os
import signal
import subprocess
import time
from pathlib import Path
from typing import Callable

import httpx

from .params import build_server_args
from .llama_cpp_installer import get_llama_server_path, install_llama_server

# Module-level singleton: the managed server process
_managed_server: subprocess.Popen | None = None
_managed_port: int | None = None


def is_llama_server_installed() -> bool:
    """Check if llama-server binary is available (system or ~/.fitmyllm/bin/)."""
    return get_llama_server_path() is not None


def ensure_llama_server(
    progress_callback: Callable[[int, int, str], None] | None = None,
) -> Path:
    """Get llama-server path, auto-installing from GitHub if not found.

    Args:
        progress_callback: Called with (downloaded, total, phase_text).

    Returns:
        Path to the llama-server binary.
    """
    path = get_llama_server_path()
    if path:
        return path

    # Auto-install
    return install_llama_server(progress_callback=progress_callback)


def start_server(
    gguf_path: str | Path,
    params: dict,
    port: int = 8080,
    progress_callback: Callable[[int, int, str], None] | None = None,
) -> int:
    """Start llama-server with the given parameters.

    Auto-installs llama-server from GitHub Releases if not found.
    Tries ports 8080, 8081, 8082 if the preferred port is busy.

    Args:
        gguf_path: Path to the GGUF model file.
        params: Dict from calculate_params().
        port: Preferred port (will try +1, +2 on conflict).
        progress_callback: For install progress if llama-server needs downloading.

    Returns:
        The port the server is running on.

    Raises:
        RuntimeError: If the server fails to start on any port.
    """
    global _managed_server, _managed_port

    # Ensure llama-server is available (auto-install if needed)
    server_bin = ensure_llama_server(progress_callback=progress_callback)

    # Stop any existing managed server
    stop_server()

    # Try up to 3 ports
    last_error = None
    for offset in range(3):
        try_port = port + offset
        if _port_in_use(try_port):
            continue

        args = build_server_args(str(gguf_path), params, port=try_port)
        cmd = [str(server_bin)] + args

        # Set LD_LIBRARY_PATH so llama-server finds its .so files
        env = dict(os.environ)
        bin_dir = str(server_bin.parent)
        env["LD_LIBRARY_PATH"] = bin_dir + ":" + env.get("LD_LIBRARY_PATH", "")

        try:
            if progress_callback:
                progress_callback(0, 0, f"Starting llama-server on port {try_port}...")

            proc = subprocess.Popen(
                cmd,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.PIPE,
                text=True,
                env=env,
            )

            # Wait for the server to become ready
            if _wait_for_ready_or_crash(proc, try_port, timeout=60.0, progress_callback=progress_callback):
                _managed_server = proc
                _managed_port = try_port
                atexit.register(stop_server)
                return try_port

            # Server started but didn't become ready — check if crashed
            if proc.poll() is not None:
                stderr = proc.stderr.read() if proc.stderr else ""
                last_error = f"Server crashed (exit {proc.returncode}): {stderr[:200]}"
            else:
                proc.kill()
                proc.wait()
                last_error = "Server started but health check timed out after 60s"

        except Exception as e:
            last_error = str(e)

    raise RuntimeError(
        f"Failed to start llama-server: {last_error}. "
        f"Tried ports {port}-{port + 2}"
    )


def stop_server() -> None:
    """Stop the managed llama-server if running."""
    global _managed_server, _managed_port

    if _managed_server is None:
        return

    try:
        _managed_server.send_signal(signal.SIGTERM)
        try:
            _managed_server.wait(timeout=5)
        except subprocess.TimeoutExpired:
            _managed_server.kill()
            _managed_server.wait(timeout=3)
    except Exception:
        pass

    _managed_server = None
    _managed_port = None


def _wait_for_ready_or_crash(
    proc: subprocess.Popen,
    port: int,
    timeout: float = 60.0,
    progress_callback: Callable[[int, int, str], None] | None = None,
) -> bool:
    """Poll health endpoint, but bail early if the process dies."""
    deadline = time.time() + timeout
    url = f"http://localhost:{port}/health"
    elapsed = 0

    while time.time() < deadline:
        # Check if process crashed
        if proc.poll() is not None:
            return False

        if progress_callback:
            progress_callback(0, 0, f"Loading model... ({elapsed}s)")

        try:
            resp = httpx.get(url, timeout=2.0)
            if resp.status_code == 200:
                if progress_callback:
                    progress_callback(0, 0, "Server ready")
                return True
        except (httpx.ConnectError, httpx.TimeoutException):
            pass
        time.sleep(0.5)
        elapsed += 1

    return False


def wait_for_ready(port: int, timeout: float = 60.0) -> bool:
    """Poll the health endpoint until the server responds."""
    deadline = time.time() + timeout
    url = f"http://localhost:{port}/health"

    while time.time() < deadline:
        try:
            resp = httpx.get(url, timeout=2.0)
            if resp.status_code == 200:
                return True
        except (httpx.ConnectError, httpx.TimeoutException):
            pass
        time.sleep(0.5)

    return False


def get_managed_port() -> int | None:
    """Return the port of the currently managed server, or None."""
    if _managed_server is not None and _managed_server.poll() is None:
        return _managed_port
    return None


def is_server_running() -> bool:
    """Check if the managed server is still running."""
    return _managed_server is not None and _managed_server.poll() is None


def _port_in_use(port: int) -> bool:
    """Check if a port is already in use."""
    try:
        resp = httpx.get(f"http://localhost:{port}/health", timeout=1.0)
        return True
    except (httpx.ConnectError, httpx.TimeoutException):
        return False
