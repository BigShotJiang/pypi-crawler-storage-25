"""OpenAI-compatible backend — llama-server, vLLM, LM Studio, etc."""

from __future__ import annotations

import json
from typing import Iterator

import httpx

from .base import InferenceBackend, StreamChunk

DEFAULT_LLAMA_SERVER_URL = "http://localhost:8080"


class OpenAICompatBackend:
    """InferenceBackend for any OpenAI-compatible server (llama-server, vLLM, LM Studio)."""

    def __init__(
        self,
        base_url: str = DEFAULT_LLAMA_SERVER_URL,
        name: str = "llama-server",
    ) -> None:
        self.base_url = base_url.rstrip("/")
        self.name = name

    def is_available(self) -> bool:
        try:
            resp = httpx.get(f"{self.base_url}/v1/models", timeout=2.0)
            return resp.status_code == 200
        except (httpx.ConnectError, httpx.TimeoutException):
            return False

    def list_models(self) -> list[dict]:
        try:
            resp = httpx.get(f"{self.base_url}/v1/models", timeout=5.0)
            resp.raise_for_status()
            data = resp.json()
            return [
                {
                    "name": m.get("id", ""),
                    "size": None,
                    "model": m.get("id", ""),
                }
                for m in data.get("data", [])
            ]
        except (httpx.HTTPError, Exception):
            return []

    def stream_chat(
        self,
        model: str,
        messages: list[dict],
        timeout: float = 120.0,
    ) -> Iterator[StreamChunk]:
        with httpx.stream(
            "POST",
            f"{self.base_url}/v1/chat/completions",
            json={
                "model": model,
                "messages": messages,
                "stream": True,
            },
            timeout=timeout,
        ) as resp:
            if resp.status_code != 200:
                err = resp.read().decode()
                raise RuntimeError(f"{self.name} error {resp.status_code}: {err}")

            for line in resp.iter_lines():
                # SSE format: "data: {...}" or "data: [DONE]"
                if not line:
                    continue

                if line.startswith("data: "):
                    payload = line[6:]
                else:
                    payload = line

                if payload.strip() == "[DONE]":
                    yield StreamChunk(content="", done=True)
                    return

                try:
                    chunk = json.loads(payload)
                except json.JSONDecodeError:
                    continue

                choices = chunk.get("choices", [])
                if not choices:
                    continue

                delta = choices[0].get("delta", {})
                token = delta.get("content", "")
                finish = choices[0].get("finish_reason")

                if token or finish:
                    yield StreamChunk(
                        content=token,
                        done=finish is not None,
                    )

                if finish:
                    return

    def __repr__(self) -> str:
        return f"OpenAICompatBackend({self.name}, {self.base_url})"
