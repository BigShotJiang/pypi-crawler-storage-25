"""Auto-install llama-server — build from source with CUDA, or download pre-built."""

from __future__ import annotations

import os
import platform
import shutil
import stat
import subprocess
import tarfile
import zipfile
from pathlib import Path

import httpx

from ..config import CONFIG_DIR

BIN_DIR = CONFIG_DIR / "bin"
GITHUB_API = "https://api.github.com/repos/ggml-org/llama.cpp/releases/latest"
LLAMA_CPP_REPO = "https://github.com/ggerganov/llama.cpp.git"


def get_llama_server_path() -> Path | None:
    """Return path to llama-server if installed (system or local)."""
    system = shutil.which("llama-server")
    if system:
        return Path(system)

    local = BIN_DIR / "llama-server"
    if local.exists() and os.access(local, os.X_OK):
        return local

    return None


def is_installed() -> bool:
    return get_llama_server_path() is not None


def _has_nvidia() -> bool:
    try:
        result = subprocess.run(["nvidia-smi"], capture_output=True, timeout=3)
        return result.returncode == 0
    except Exception:
        return False


def _has_nvcc() -> bool:
    return shutil.which("nvcc") is not None


def _has_cmake() -> bool:
    return shutil.which("cmake") is not None


def _has_amd() -> bool:
    try:
        result = subprocess.run(
            ["rocm-smi", "--showproductname"], capture_output=True, timeout=3,
        )
        return result.returncode == 0
    except Exception:
        return False


def _should_build_from_source() -> bool:
    """Check if we should build from source (NVIDIA Linux with CUDA toolkit)."""
    if platform.system() != "Linux":
        return False
    return _has_nvidia() and _has_nvcc() and _has_cmake()


def install_llama_server(
    progress_callback: callable | None = None,
) -> Path:
    """Install llama-server to ~/.fitmyllm/bin/.

    Strategy:
    - Linux + NVIDIA + nvcc + cmake → build from source with CUDA
    - Everything else → download pre-built binary from GitHub Releases
    """
    BIN_DIR.mkdir(parents=True, exist_ok=True)

    if _should_build_from_source():
        return _build_from_source(progress_callback)

    return _download_prebuilt(progress_callback)


# ── Build from source (CUDA) ────────────────────────────────────────────


def _build_from_source(
    progress_callback: callable | None = None,
) -> Path:
    """Clone llama.cpp and build with CUDA support."""
    build_dir = CONFIG_DIR / "llama-cpp-build"

    # Clean previous builds
    if build_dir.exists():
        shutil.rmtree(build_dir)

    if progress_callback:
        progress_callback(0, 0, "Cloning llama.cpp...")

    # 1. Clone (shallow)
    result = subprocess.run(
        ["git", "clone", "--depth", "1", LLAMA_CPP_REPO, str(build_dir)],
        capture_output=True, text=True, timeout=120,
    )
    if result.returncode != 0:
        raise RuntimeError(f"Git clone failed: {result.stderr[:200]}")

    if progress_callback:
        progress_callback(0, 0, "Configuring with CUDA...")

    # 2. CMake configure
    cmake_build = build_dir / "build"
    result = subprocess.run(
        ["cmake", "-B", str(cmake_build), "-DGGML_CUDA=ON",
         "-DCMAKE_BUILD_TYPE=Release"],
        cwd=str(build_dir),
        capture_output=True, text=True, timeout=60,
    )
    if result.returncode != 0:
        _cleanup_build(build_dir)
        raise RuntimeError(f"CMake configure failed: {result.stderr[:300]}")

    if progress_callback:
        progress_callback(0, 0, "Building llama-server with CUDA (this may take a few minutes)...")

    # 3. Build
    nproc = os.cpu_count() or 4
    result = subprocess.run(
        ["cmake", "--build", str(cmake_build), "--config", "Release",
         "-j", str(nproc), "--target", "llama-server"],
        cwd=str(build_dir),
        capture_output=True, text=True, timeout=600,
    )
    if result.returncode != 0:
        _cleanup_build(build_dir)
        raise RuntimeError(f"Build failed: {result.stderr[:300]}")

    if progress_callback:
        progress_callback(0, 0, "Installing llama-server...")

    # 4. Copy binary and libraries to BIN_DIR
    server_src = cmake_build / "bin" / "llama-server"
    if not server_src.exists():
        _cleanup_build(build_dir)
        raise RuntimeError("llama-server binary not found after build")

    server_dst = BIN_DIR / "llama-server"
    shutil.copy2(str(server_src), str(server_dst))
    server_dst.chmod(server_dst.stat().st_mode | stat.S_IEXEC)

    # Copy shared libraries
    for so in (cmake_build / "bin").glob("*.so*"):
        shutil.copy2(str(so), str(BIN_DIR / so.name))
    for so in (cmake_build / "src").glob("*.so*"):
        shutil.copy2(str(so), str(BIN_DIR / so.name))
    for so in (cmake_build / "ggml" / "src").glob("*.so*"):
        shutil.copy2(str(so), str(BIN_DIR / so.name))
    # Recursively find all .so files in build directory
    for so in cmake_build.rglob("*.so*"):
        dest = BIN_DIR / so.name
        if not dest.exists():
            shutil.copy2(str(so), str(dest))

    # 5. Cleanup build dir
    _cleanup_build(build_dir)

    if progress_callback:
        progress_callback(0, 0, "Installed llama-server (CUDA build)")

    return server_dst


def _cleanup_build(build_dir: Path) -> None:
    try:
        shutil.rmtree(build_dir, ignore_errors=True)
    except Exception:
        pass


# ── Download pre-built binary ────────────────────────────────────────────


def _detect_cuda_version() -> str | None:
    """Detect installed CUDA version from nvidia-smi."""
    try:
        result = subprocess.run(
            ["nvidia-smi", "--query-gpu=driver_version", "--format=csv,noheader"],
            capture_output=True, text=True, timeout=5,
        )
        if result.returncode != 0:
            return None
        # nvidia-smi shows max supported CUDA in header; parse it
        result2 = subprocess.run(
            ["nvidia-smi"], capture_output=True, text=True, timeout=5,
        )
        for line in result2.stdout.split("\n"):
            if "CUDA Version" in line:
                # e.g. "CUDA Version: 12.4"
                parts = line.split("CUDA Version:")
                if len(parts) >= 2:
                    ver = parts[1].strip().split()[0]
                    return ver
    except Exception:
        pass
    return None


def _detect_asset_name() -> str | list[str]:
    """Pick the right release asset(s) for this platform.

    Returns a string or a list of strings to try in order (first match wins).
    """
    system = platform.system()
    machine = platform.machine().lower()

    if system == "Darwin":
        if machine in ("arm64", "aarch64"):
            return "bin-macos-arm64"
        return "bin-macos-x64"

    if system == "Windows":
        if _has_nvidia():
            cuda_ver = _detect_cuda_version()
            # Try matching CUDA version, fall back to 12.4
            candidates = []
            if cuda_ver:
                major = cuda_ver.split(".")[0]
                candidates.append(f"bin-win-cuda-{cuda_ver}-x64")
                if major >= "13":
                    candidates.append("bin-win-cuda-13")
                candidates.append("bin-win-cuda-12")
            else:
                candidates.append("bin-win-cuda-12")
            return candidates
        return "bin-win-cpu-x64"

    # Linux (pre-built, no CUDA available)
    if machine in ("aarch64", "arm64"):
        return "bin-ubuntu-arm64"
    if _has_amd():
        return "bin-ubuntu-vulkan-x64"

    return "bin-ubuntu-x64"  # CPU fallback


def _download_prebuilt(
    progress_callback: callable | None = None,
) -> Path:
    """Download pre-built binary from GitHub Releases."""
    if progress_callback:
        progress_callback(0, 0, "Finding latest llama.cpp release...")

    try:
        resp = httpx.get(GITHUB_API, timeout=10.0, follow_redirects=True)
        resp.raise_for_status()
        release = resp.json()
    except Exception as e:
        raise RuntimeError(f"Cannot fetch release info: {e}")

    tag = release.get("tag_name", "unknown")
    asset_patterns = _detect_asset_name()
    if isinstance(asset_patterns, str):
        asset_patterns = [asset_patterns]

    asset = None
    for pattern in asset_patterns:
        for a in release.get("assets", []):
            name = a.get("name", "")
            # Skip cudart-only bundles (no llama-server inside)
            if name.startswith("cudart-"):
                continue
            if pattern in name:
                asset = a
                break
        if asset:
            break

    if not asset:
        raise RuntimeError(
            f"No binary found for this platform ({asset_patterns}). "
            f"Install cmake + CUDA toolkit to build from source."
        )

    url = asset["browser_download_url"]
    filename = asset["name"]
    total_size = asset.get("size", 0)

    if progress_callback:
        progress_callback(0, total_size, f"Downloading {filename}...")

    tmp_path = BIN_DIR / filename
    try:
        with httpx.stream("GET", url, follow_redirects=True, timeout=600.0) as resp:
            resp.raise_for_status()
            downloaded = 0
            with open(tmp_path, "wb") as f:
                for chunk in resp.iter_bytes(chunk_size=1024 * 1024):
                    f.write(chunk)
                    downloaded += len(chunk)
                    if progress_callback:
                        progress_callback(downloaded, total_size, f"Downloading {filename}...")
    except Exception as e:
        tmp_path.unlink(missing_ok=True)
        raise RuntimeError(f"Download failed: {e}")

    if progress_callback:
        progress_callback(total_size, total_size, "Extracting llama-server...")

    server_binary = None
    try:
        if filename.endswith(".tar.gz"):
            with tarfile.open(tmp_path, "r:gz") as tar:
                for member in tar.getmembers():
                    if member.isdir():
                        continue
                    basename = Path(member.name).name
                    if not basename:
                        continue
                    member.name = basename
                    tar.extract(member, BIN_DIR)
                    if basename == "llama-server":
                        server_binary = BIN_DIR / basename
        elif filename.endswith(".zip"):
            with zipfile.ZipFile(tmp_path) as zf:
                for name in zf.namelist():
                    basename = Path(name).name
                    if not basename:
                        continue
                    data = zf.read(name)
                    dest = BIN_DIR / basename
                    dest.write_bytes(data)
                    if basename in ("llama-server", "llama-server.exe"):
                        server_binary = dest
    except Exception as e:
        raise RuntimeError(f"Extraction failed: {e}")
    finally:
        tmp_path.unlink(missing_ok=True)

    if not server_binary or not server_binary.exists():
        raise RuntimeError("llama-server binary not found in archive")

    server_binary.chmod(server_binary.stat().st_mode | stat.S_IEXEC | stat.S_IXGRP | stat.S_IXOTH)
    for f in BIN_DIR.glob("*.so*"):
        f.chmod(f.stat().st_mode | stat.S_IEXEC | stat.S_IXGRP | stat.S_IXOTH)

    if progress_callback:
        progress_callback(total_size, total_size, f"Installed llama-server ({tag})")

    return server_binary
