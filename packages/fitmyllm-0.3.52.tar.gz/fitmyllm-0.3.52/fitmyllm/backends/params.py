"""Optimal parameter calculator — determine ngl, ctx, batch based on hardware + model."""

from __future__ import annotations

import os


def calculate_params(
    vram_mb: int | None,
    model_size_gb: float,
    context_length: int = 4096,
) -> dict:
    """Calculate optimal llama-server parameters.

    Args:
        vram_mb: Available GPU VRAM in MB (None = CPU only).
        model_size_gb: Model file size in GB (weights at chosen quantization).
        context_length: Desired context length.

    Returns:
        Dict with keys: ngl, ctx, batch, threads, flash_attn, mode.
    """
    model_size_mb = model_size_gb * 1024
    # Rough KV cache estimate: ~0.5MB per 1K context per 1B params
    # For a 7B model at 4K ctx: ~14MB. At 32K: ~112MB
    params_b_approx = model_size_gb / 0.5  # rough: Q4 ~0.5GB per 1B
    kv_cache_mb = params_b_approx * (context_length / 1024) * 0.5
    overhead_mb = 300  # framework overhead

    total_needed_mb = model_size_mb + kv_cache_mb + overhead_mb

    # Detect CPU threads
    try:
        threads = len(os.sched_getaffinity(0))
    except AttributeError:
        threads = os.cpu_count() or 4
    # Use physical cores (rough: half of logical)
    threads = max(1, threads // 2)

    if vram_mb is None or vram_mb < 512:
        # CPU only
        return {
            "ngl": 0,
            "ctx": min(context_length, 4096),
            "batch": 512,
            "threads": threads,
            "flash_attn": False,
            "mode": "cpu_only",
        }

    available_mb = vram_mb - overhead_mb

    if total_needed_mb <= vram_mb:
        # Full GPU — everything fits
        return {
            "ngl": 99,
            "ctx": context_length,
            "batch": 2048,
            "threads": threads,
            "flash_attn": True,
            "mode": "gpu_full",
        }

    if model_size_mb <= available_mb:
        # Model fits, but KV cache might not — reduce context
        remaining = available_mb - model_size_mb
        max_ctx = int(remaining / (params_b_approx * 0.5) * 1024)
        max_ctx = max(2048, min(context_length, max_ctx))
        return {
            "ngl": 99,
            "ctx": max_ctx,
            "batch": 2048,
            "threads": threads,
            "flash_attn": True,
            "mode": "gpu_full",
        }

    # Partial offload — calculate how many layers fit
    # Rough: ngl proportional to how much of the model fits in VRAM
    ratio = available_mb / model_size_mb
    ngl = max(1, int(ratio * 40))  # assume ~40 layers typical

    return {
        "ngl": ngl,
        "ctx": min(context_length, 4096),
        "batch": 512,
        "threads": threads,
        "flash_attn": False,
        "mode": "gpu_offload",
    }


def build_server_args(
    gguf_path: str,
    params: dict,
    port: int = 8080,
) -> list[str]:
    """Build llama-server command-line arguments from calculated params.

    Returns:
        List of args suitable for subprocess (without the 'llama-server' binary itself).
    """
    args = [
        "-m", str(gguf_path),
        "-ngl", str(params["ngl"]),
        "-c", str(params["ctx"]),
        "-b", str(params["batch"]),
        "--port", str(port),
    ]

    if params.get("threads"):
        args.extend(["-t", str(params["threads"])])

    # Note: -fa (flash attention) removed — not supported on all builds

    return args
