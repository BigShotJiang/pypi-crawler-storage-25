"""Ollama backend — talks to the Ollama HTTP API on localhost:11434."""

from __future__ import annotations

import json
from typing import Iterator

import httpx

from .base import InferenceBackend, StreamChunk

DEFAULT_OLLAMA_URL = "http://localhost:11434"


class OllamaBackend:
    """InferenceBackend implementation for Ollama."""

    name: str = "ollama"

    def __init__(self, base_url: str = DEFAULT_OLLAMA_URL) -> None:
        self.base_url = base_url

    def is_available(self) -> bool:
        try:
            resp = httpx.get(f"{self.base_url}/api/tags", timeout=2.0)
            return resp.status_code == 200
        except (httpx.ConnectError, httpx.TimeoutException):
            return False

    def list_models(self) -> list[dict]:
        try:
            resp = httpx.get(f"{self.base_url}/api/tags", timeout=5.0)
            resp.raise_for_status()
            data = resp.json()
            return [
                {
                    "name": m.get("name", ""),
                    "size": m.get("size"),
                    "model": m.get("model", m.get("name", "")),
                }
                for m in data.get("models", [])
            ]
        except (httpx.HTTPError, Exception):
            return []

    def stream_chat(
        self,
        model: str,
        messages: list[dict],
        timeout: float = 120.0,
    ) -> Iterator[StreamChunk]:
        with httpx.stream(
            "POST",
            f"{self.base_url}/api/chat",
            json={"model": model, "messages": messages, "stream": True},
            timeout=timeout,
        ) as resp:
            if resp.status_code != 200:
                err = resp.read().decode()
                raise RuntimeError(f"Ollama error {resp.status_code}: {err}")

            for line in resp.iter_lines():
                if not line:
                    continue
                try:
                    chunk = json.loads(line)
                except json.JSONDecodeError:
                    continue

                token = chunk.get("message", {}).get("content", "")
                done = chunk.get("done", False)

                if token or done:
                    yield StreamChunk(content=token, done=done)

                if done:
                    return

    def __repr__(self) -> str:
        return f"OllamaBackend({self.base_url})"
