"""GPU auto-detection."""
import subprocess
import platform

def _run(cmd: str) -> str | None:
    try:
        result = subprocess.run(cmd, shell=True, capture_output=True, text=True, timeout=5)
        return result.stdout.strip() if result.returncode == 0 else None
    except Exception:
        return None

def detect_gpu() -> dict | None:
    """Detect GPU. Returns {"name": str, "vram_mb": int | None} or None."""
    if platform.system() == "Darwin":
        return _detect_apple()
    gpu = _detect_nvidia()
    if gpu:
        return gpu
    gpu = _detect_amd()
    if gpu:
        return gpu
    return _detect_fallback()

def _detect_nvidia() -> dict | None:
    out = _run("nvidia-smi --query-gpu=name,memory.total --format=csv,noheader,nounits")
    if not out:
        return None
    parts = out.split("\n")[0].split(",")
    name = parts[0].strip()
    vram = int(parts[1].strip()) if len(parts) > 1 else None
    return {"name": name, "vram_mb": vram}

def _detect_amd() -> dict | None:
    out = _run("rocm-smi --showproductname")
    if out:
        for line in out.split("\n"):
            if "card" in line.lower():
                parts = line.split(":")
                if len(parts) > 1:
                    return {"name": parts[1].strip(), "vram_mb": None}
    out = _run("lspci 2>/dev/null | grep -i 'vga\\|3d\\|display'")
    if out:
        for line in out.split("\n"):
            if "amd" in line.lower() or "radeon" in line.lower():
                import re
                m = re.search(r'\[(.+?)\]', line)
                if m:
                    return {"name": m.group(1), "vram_mb": None}
    return None

def _detect_apple() -> dict | None:
    out = _run("system_profiler SPDisplaysDataType 2>/dev/null")
    if not out:
        return None
    import re
    m = re.search(r'Chip(?:set)? Model:\s+(.+)', out, re.IGNORECASE)
    if not m:
        return None
    chip = m.group(1).strip()
    mem = _run("sysctl -n hw.memsize 2>/dev/null")
    if mem:
        gb = round(int(mem) / (1024**3))
        return {"name": f"{chip} {gb}GB", "vram_mb": gb * 1024}
    return {"name": chip, "vram_mb": None}

def _detect_fallback() -> dict | None:
    out = _run("lspci 2>/dev/null | grep -i 'vga\\|3d\\|display'")
    if not out:
        return None
    import re
    m = re.search(r'\[(.+?)\]', out.split("\n")[0])
    if m:
        return {"name": m.group(1), "vram_mb": None}
    return None
