import httpx
from Crypto.PublicKey.RSA import RsaKey
from typing import ClassVar, Generic
from uuid import UUID
from nexo.crypto.hash.enums import Mode
from nexo.crypto.hash.sha256 import hash
from nexo.crypto.signature import verify
from nexo.database.enums import CacheOrigin, CacheLayer
from nexo.database.handlers import RedisHandler
from nexo.enums.connection import Header
from nexo.logging.logger import Client
from nexo.schemas.application import ApplicationSettings
from nexo.schemas.error.enums import ErrorCode
from nexo.schemas.google import ListOfPublisherHandlers
from nexo.schemas.operation.context import generate
from nexo.schemas.operation.enums import Origin, Layer, Target
from nexo.schemas.resource import Resource, AggregateField
from nexo.types.string import ManyStrs
from .http import HTTPClientManager
from .config import ClientConfigT
from .constants import MANDATORY_RESPONSE_HEADERS


class ClientService(Generic[ClientConfigT]):
    _resource: ClassVar[Resource]

    def __init__(
        self,
        config: ClientConfigT,
        http_client_manager: HTTPClientManager,
        *,
        settings: ApplicationSettings,
        logger: Client,
        private_key: RsaKey,
        cache: RedisHandler,
        publishers: ListOfPublisherHandlers = [],
    ):
        self._config = config
        self._http_client_manager = http_client_manager
        self._settings = settings
        self._logger = logger
        self._private_key = private_key
        self._cache = cache
        self._namespace = self._cache.config.build_namespace(
            self._resource.aggregate(AggregateField.KEY, sep=":"),
            client=self._config.key,
            origin=CacheOrigin.CLIENT,
            layer=CacheLayer.SERVICE,
        )
        self._publishers = publishers

        self._operation_context = generate(
            origin=Origin.CLIENT, layer=Layer.SERVICE, target=Target.INTERNAL
        )

    def validate_response(self, response: httpx.Response):
        header_keys = list(response.headers.keys())
        if any((header not in header_keys for header in MANDATORY_RESPONSE_HEADERS)):
            raise RuntimeError(
                ErrorCode.INTERNAL_SERVER_ERROR,
                "Some or all mandatory response headers did not exist in the response",
            )

        server_id = UUID(response.headers.get(Header.X_SERVER_ID.value))
        if server_id != self._config.id:
            raise ValueError(
                f"Server ID '{server_id}' in header did not match Client ID '{self._config.id}' in config"
            )

        client_id = UUID(response.headers.get(Header.X_CLIENT_ID.value))
        if client_id != self._settings.CLIENT_ID:
            raise ValueError(
                f"Client ID '{client_id}' in header did not match Client ID '{self._settings.CLIENT_ID}' in settings"
            )

        operation_id = response.headers.get(Header.X_OPERATION_ID.value)
        connection_id = response.headers.get(Header.X_CONNECTION_ID.value)

        executed_at = response.headers.get(Header.X_EXECUTED_AT.value)
        completed_at = response.headers.get(Header.X_COMPLETED_AT.value)
        duration = response.headers.get(Header.X_DURATION.value)

        content_type = response.headers.get(Header.CONTENT_TYPE.value, "")

        if "application/json" not in content_type:
            body_hash = "UNHASHABLE-PAYLOAD"
        elif not response.content:
            body_hash = "EMPTY-PAYLOAD"
        else:
            body_hash = hash(Mode.DIGEST, message=response.content).hex()

        signature = str(response.headers.get(Header.X_SIGNATURE.value))

        payload_components: ManyStrs = (
            operation_id,
            connection_id,
            executed_at,
            completed_at,
            duration,
            str(response.status_code),
            body_hash,
            str(self._settings.CLIENT_SECRET),
        )
        payload = "|".join(payload_components)

        is_valid = verify(self._config.public_key, payload, signature)
        if not is_valid:
            raise ValueError("Invalid response signature")
