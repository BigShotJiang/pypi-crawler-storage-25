from abc import ABC, abstractmethod
from Crypto.PublicKey.RSA import RsaKey
from typing import Generic
from nexo.database.handlers import RedisHandler
from nexo.logging.config import LogConfig
from nexo.logging.logger import Client
from nexo.schemas.application import ApplicationSettings
from nexo.schemas.google import ListOfPublisherHandlers
from .http import HTTPClientManager
from .config import ClientConfigT


class ClientManager(ABC, Generic[ClientConfigT]):
    def __init__(
        self,
        config: ClientConfigT,
        *,
        settings: ApplicationSettings,
        log_config: LogConfig,
        private_key: RsaKey,
        cache: RedisHandler,
        publishers: ListOfPublisherHandlers = [],
    ):
        self._config = config
        self._http_client_manager = HTTPClientManager(
            self._config.timeout.httpx_timeout
        )

        self._settings = settings
        self._log_config = log_config

        self._key = self._config.key
        self._name = self._config.name

        self._logger = Client(
            environment=self._settings.ENVIRONMENT,
            service_key=self._settings.SERVICE_KEY,
            client_key=self._key,
            config=log_config,
        )

        self._private_key = private_key
        self._cache = cache
        self._publishers = publishers

        self.initalize_services()
        self._logger.info(f"{self._name} client manager initialized successfully")

    @abstractmethod
    def initalize_services(self):
        """Initialize all services of this client"""
