import httpx
from Crypto.PublicKey.RSA import RsaKey
from pydantic import BaseModel, Field
from typing import Annotated, Generic, TypeVar
from uuid import UUID
from nexo.crypto.key.rsa.enums import KeyType
from nexo.crypto.key.rsa.loader import with_pycryptodome
from nexo.schemas.mixins.identity import UUIDId, Key, Name


class Timeout(BaseModel):
    connect: Annotated[float, Field(5.0, description="Connect Timeout", ge=0.0)] = 5.0
    read: Annotated[float, Field(15.0, description="Read Timeout", ge=0.0)] = 15.0
    write: Annotated[float, Field(5.0, description="Write Timeout", ge=0.0)] = 5.0
    pool: Annotated[float, Field(5.0, description="Pool Timeout", ge=0.0)] = 5.0

    @property
    def httpx_timeout(self) -> httpx.Timeout:
        return httpx.Timeout(
            connect=self.connect,
            read=self.read,
            write=self.write,
            pool=self.pool,
        )


DEFAULT_TIMEOUT = Timeout()


class ClientConfig(
    Name[str],
    Key[str],
    UUIDId[UUID],
):
    url: Annotated[str, Field(..., description="Client's URL")]
    public_key: Annotated[str, Field(..., description="Client's Public Key")]

    @property
    def public_key_rsa(self) -> RsaKey:
        return with_pycryptodome(KeyType.PUBLIC, extern_key=self.public_key)

    timeout: Annotated[
        Timeout, Field(DEFAULT_TIMEOUT, description="HTTPX's Timeout")
    ] = DEFAULT_TIMEOUT


ClientConfigT = TypeVar("ClientConfigT", bound=ClientConfig)


class ClientConfigs(BaseModel):
    pass


OptClientConfigs = ClientConfigs | None
OptClientConfigsT = TypeVar("OptClientConfigsT", bound=OptClientConfigs)


class ClientConfigsMixin(BaseModel, Generic[OptClientConfigsT]):
    clients: OptClientConfigsT = Field(..., description="Client config")
