from nexo.enums.connection import Header
from nexo.types.string import ManyStrs


MANDATORY_RESPONSE_HEADERS: ManyStrs = (
    Header.X_SERVER_ID.value,
    Header.X_CLIENT_ID.value,
    Header.X_OPERATION_ID.value,
    Header.X_CONNECTION_ID.value,
    Header.X_EXECUTED_AT.value,
    Header.X_COMPLETED_AT.value,
    Header.X_DURATION.value,
    Header.X_SIGNATURE.value,
)
