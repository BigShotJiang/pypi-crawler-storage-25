# easycert

Simplified X.509 certificate generation and verification toolkit.

## Features

- Generate RSA key pairs
- Create self-signed X.509 certificates
- Verify certificate signatures
- Check certificate validity periods
- Object-oriented verification interface
- Detailed error handling

## Installation

```bash
pip install .
```

## Dependencies

- cryptography
- pycryptodome

## Usage

### Generate self-signed certificate

```python
import easycert

# Generate self-signed certificate
private_key_pem, cert = easycert.generate_self_signed_certificate(
    common_name="example.com",
    valid_days=365
)

# Save to files
easycert.save_key_pair(private_key_pem, private_key_pem, "private.pem", "public.pem")
easycert.save_certificate(cert, "cert.crt")
```

### Verify certificate

```python
import easycert

# Using functional interface
result = easycert.verify_certificate_from_file("cert.crt")
easycert.print_verification_result(result)

# Using object-oriented interface
verifier = easycert.Verify("cert.crt")
verifier.print_info()
verifier.print_result()
print(f"Certificate valid: {verifier.is_valid}")
```

## API Reference

### Generation Module

- `generate_key_pair(key_size=2048)`: Generate RSA key pair
- `generate_certificate(private_key_pem, common_name="localhost", valid_days=365)`: Generate X.509 certificate
- `generate_self_signed_certificate(common_name="localhost", key_size=2048, valid_days=365)`: Generate self-signed certificate
- `save_key_pair(private_key_pem, public_key_pem, private_key_path, public_key_path)`: Save key pair to files
- `load_key_pair(private_key_path, public_key_path)`: Load key pair from files
- `save_certificate(cert, cert_path)`: Save certificate to file
- `load_certificate(cert_path)`: Load certificate from file

### Verification Module

- `verify_certificate_signature(cert)`: Verify certificate signature
- `verify_certificate_validity(cert, check_time=None)`: Verify certificate validity period
- `verify_certificate(cert, check_time=None)`: Complete certificate verification
- `verify_certificate_from_file(cert_path, check_time=None)`: Load and verify certificate from file
- `print_certificate_info(cert)`: Print certificate information
- `print_verification_result(result)`: Print verification result

### Verify Class

- `Verify(cert_input)`: Initialize verifier with certificate file path or object
- `verify_signature()`: Verify certificate signature
- `verify_validity(check_time=None)`: Verify certificate validity period
- `verify(check_time=None)`: Complete certificate verification
- `print_info()`: Print certificate information
- `print_result(check_time=None)`: Print verification result
- Properties: `subject`, `issuer`, `serial_number`, `not_valid_before`, `not_valid_after`, `is_valid`, `certificate`

## Exceptions

- `CertificateValidationError`: Base exception for certificate validation errors
- `CertificateSignatureError`: Certificate signature verification failed
- `CertificateExpiredError`: Certificate has expired
- `CertificateNotYetValidError`: Certificate is not yet valid

## License

MIT License
