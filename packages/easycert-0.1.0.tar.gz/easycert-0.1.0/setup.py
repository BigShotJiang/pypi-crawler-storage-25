from setuptools import setup, find_packages

setup(
    name="easycert",
    version="0.1.0",
    description="Simplified X.509 certificate generation and verification toolkit",
    author="lsh101123",
    author_email="lsh101123@163.com",
    packages=find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.8",
    install_requires=[
        "cryptography>=42.0.0",
        "pycryptodome>=3.20.0"
    ]
)
