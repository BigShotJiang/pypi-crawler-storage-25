from Crypto.PublicKey import RSA
from cryptography.hazmat.primitives import serialization
from cryptography import x509
from cryptography.x509.oid import NameOID
from cryptography.hazmat.primitives import hashes
import datetime
from typing import Optional, Tuple


def generate_key_pair(key_size: int = 2048) -> Tuple[bytes, bytes]:
    """
    Generate RSA key pair
    
    Args:
        key_size: Key size in bits, default is 2048
        
    Returns:
        (private_key_pem, public_key_pem) Private and public keys in PEM format
    """
    rsa_key = RSA.generate(key_size)
    private_key_pem = rsa_key.export_key()
    public_key_pem = rsa_key.publickey().export_key()
    return private_key_pem, public_key_pem


def load_private_key(private_key_pem: bytes, password: Optional[bytes] = None):
    """
    Load private key in PEM format
    
    Args:
        private_key_pem: Private key in PEM format
        password: Private key password (if any)
        
    Returns:
        Loaded private key object
    """
    return serialization.load_pem_private_key(private_key_pem, password=password)


def generate_certificate(
    private_key_pem: bytes,
    common_name: str = "localhost",
    valid_days: int = 365,
    custom_subject: Optional[x509.Name] = None,
    custom_issuer: Optional[x509.Name] = None
) -> x509.Certificate:
    """
    Generate X.509 certificate
    
    Args:
        private_key_pem: Private key in PEM format
        common_name: Certificate common name, default is localhost
        valid_days: Certificate validity period in days, default is 365 days
        custom_subject: Custom subject information
        custom_issuer: Custom issuer information
        
    Returns:
        Generated X.509 certificate object
    """
    private_key = load_private_key(private_key_pem)
    
    # Use custom subject or default subject
    if custom_subject:
        subject = custom_subject
    else:
        subject = x509.Name([
            x509.NameAttribute(NameOID.COMMON_NAME, common_name),
        ])
    
    # Use custom issuer or default issuer (self-signed)
    issuer = custom_issuer if custom_issuer else subject
    
    # Build certificate
    cert = x509.CertificateBuilder().subject_name(
        subject
    ).issuer_name(
        issuer
    ).public_key(
        private_key.public_key()
    ).serial_number(
        x509.random_serial_number()
    ).not_valid_before(
        datetime.datetime.now(datetime.UTC)
    ).not_valid_after(
        datetime.datetime.now(datetime.UTC) + datetime.timedelta(days=valid_days)
    ).sign(private_key, hashes.SHA256())
    
    return cert


def save_key_pair(private_key_pem: bytes, public_key_pem: bytes, 
                  private_key_path: str, 
                  public_key_path: str) -> None:
    """
    Save key pair to files
    
    Args:
        private_key_pem: Private key in PEM format
        public_key_pem: Public key in PEM format
        private_key_path: Private key save path
        public_key_path: Public key save path
    """
    with open(private_key_path, "wb") as f:
        f.write(private_key_pem)
    with open(public_key_path, "wb") as f:
        f.write(public_key_pem)


def load_key_pair(private_key_path: str,
                  public_key_path: str) -> Tuple[bytes, bytes]:
    """
    Load key pair from files
    
    Args:
        private_key_path: Private key file path
        public_key_path: Public key file path
        
    Returns:
        (private_key_pem, public_key_pem) Private and public keys in PEM format
    """
    with open(private_key_path, "rb") as f:
        private_key_pem = f.read()
    with open(public_key_path, "rb") as f:
        public_key_pem = f.read()
    return private_key_pem, public_key_pem


def save_certificate(cert: x509.Certificate, cert_path: str) -> None:
    """
    Save certificate to file
    
    Args:
        cert: X.509 certificate object
        cert_path: Certificate save path
    """
    with open(cert_path, "wb") as f:
        f.write(cert.public_bytes(serialization.Encoding.PEM))


def load_certificate(cert_path: str) -> x509.Certificate:
    """
    Load certificate from file
    
    Args:
        cert_path: Certificate file path
        
    Returns:
        X.509 certificate object
    """
    with open(cert_path, "rb") as f:
        cert = x509.load_pem_x509_certificate(f.read())
    return cert


def generate_self_signed_certificate(
    common_name: str = "localhost",
    key_size: int = 2048,
    valid_days: int = 365
) -> Tuple[bytes, x509.Certificate]:
    """
    Generate self-signed certificate (includes key generation)
    
    Args:
        common_name: Certificate common name
        key_size: Key size in bits
        valid_days: Certificate validity period in days
        
    Returns:
        (private_key_pem, certificate) Private key and certificate
    """
    private_key_pem, _ = generate_key_pair(key_size)
    cert = generate_certificate(private_key_pem, common_name, valid_days)
    return private_key_pem, cert
