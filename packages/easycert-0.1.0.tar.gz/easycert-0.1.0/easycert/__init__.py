"""
easycert - Simplified X.509 certificate generation and verification toolkit
"""

from .generate import (
    generate_key_pair,
    load_private_key,
    generate_certificate,
    save_key_pair,
    load_key_pair,
    save_certificate,
    load_certificate,
    generate_self_signed_certificate,
)

from .verify import (
    CertificateValidationError,
    CertificateSignatureError,
    CertificateExpiredError,
    CertificateNotYetValidError,
    Verify,
    verify_certificate_signature,
    verify_certificate_validity,
    verify_certificate,
    verify_certificate_from_file,
    print_certificate_info,
    print_verification_result,
)

__version__ = "0.1.0"

__all__ = [
    # Generation module
    "generate_key_pair",
    "load_private_key",
    "generate_certificate",
    "save_key_pair",
    "load_key_pair",
    "save_certificate",
    "load_certificate",
    "generate_self_signed_certificate",
    # Verification module
    "CertificateValidationError",
    "CertificateSignatureError",
    "CertificateExpiredError",
    "CertificateNotYetValidError",
    "Verify",
    "verify_certificate_signature",
    "verify_certificate_validity",
    "verify_certificate",
    "verify_certificate_from_file",
    "print_certificate_info",
    "print_verification_result",
]
