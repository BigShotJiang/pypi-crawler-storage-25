from cryptography import x509
from cryptography.hazmat.primitives.asymmetric import padding
from cryptography.exceptions import InvalidSignature
import datetime
from typing import Dict, Any, Optional


class CertificateValidationError(Exception):
    """Base exception for certificate validation errors"""
    pass


class CertificateSignatureError(CertificateValidationError):
    """Certificate signature verification failed"""
    pass


class CertificateExpiredError(CertificateValidationError):
    """Certificate has expired"""
    pass


class CertificateNotYetValidError(CertificateValidationError):
    """Certificate is not yet valid"""
    pass


def verify_certificate_signature(cert: x509.Certificate) -> bool:
    """
    Verify certificate signature
    
    Args:
        cert: X.509 certificate object
        
    Returns:
        Whether the signature is valid
        
    Raises:
        CertificateSignatureError: Signature verification failed
    """
    try:
        cert.public_key().verify(
            cert.signature,
            cert.tbs_certificate_bytes,
            padding.PKCS1v15(),
            cert.signature_hash_algorithm
        )
        return True
    except InvalidSignature as e:
        raise CertificateSignatureError("Certificate signature is invalid") from e


def verify_certificate_validity(cert: x509.Certificate, 
                                  check_time: Optional[datetime.datetime] = None) -> bool:
    """
    Verify certificate validity period
    
    Args:
        cert: X.509 certificate object
        check_time: Check time, default is current time
        
    Returns:
        Whether the certificate is within validity period
        
    Raises:
        CertificateNotYetValidError: Certificate is not yet valid
        CertificateExpiredError: Certificate has expired
    """
    if check_time is None:
        check_time = datetime.datetime.now(datetime.UTC)
    
    if cert.not_valid_before_utc > check_time:
        raise CertificateNotYetValidError("Certificate is not yet valid")
    
    if cert.not_valid_after_utc < check_time:
        raise CertificateExpiredError("Certificate has expired")
    
    return True


def verify_certificate(cert: x509.Certificate, 
                       check_time: Optional[datetime.datetime] = None) -> Dict[str, Any]:
    """
    Complete certificate verification (signature + validity)
    
    Args:
        cert: X.509 certificate object
        check_time: Check time, default is current time
        
    Returns:
        Verification result dictionary containing valid status and detailed information
        
    Raises:
        CertificateValidationError: Certificate verification failed
    """
    result = {
        "valid": False,
        "signature_valid": False,
        "validity_valid": False,
        "not_valid_before": cert.not_valid_before_utc.isoformat(),
        "not_valid_after": cert.not_valid_after_utc.isoformat(),
        "subject": cert.subject.rfc4514_string(),
        "issuer": cert.issuer.rfc4514_string(),
        "serial_number": str(cert.serial_number),
        "errors": []
    }
    
    # Verify signature
    try:
        verify_certificate_signature(cert)
        result["signature_valid"] = True
    except CertificateValidationError as e:
        result["errors"].append(str(e))
    
    # Verify validity
    try:
        verify_certificate_validity(cert, check_time)
        result["validity_valid"] = True
    except CertificateValidationError as e:
        result["errors"].append(str(e))
    
    # Overall validity
    result["valid"] = result["signature_valid"] and result["validity_valid"]
    
    return result


def verify_certificate_from_file(cert_path: str, 
                                  check_time: Optional[datetime.datetime] = None) -> Dict[str, Any]:
    """
    Load certificate from file and verify it
    
    Args:
        cert_path: Certificate file path
        check_time: Check time, default is current time
        
    Returns:
        Verification result dictionary
    """
    with open(cert_path, "rb") as f:
        cert = x509.load_pem_x509_certificate(f.read())
    return verify_certificate(cert, check_time)


def print_certificate_info(cert: x509.Certificate) -> None:
    """
    Print certificate basic information
    
    Args:
        cert: X.509 certificate object
    """
    print(f"Subject: {cert.subject.rfc4514_string()}")
    print(f"Issuer: {cert.issuer.rfc4514_string()}")
    print(f"Serial Number: {cert.serial_number}")
    print(f"Valid From: {cert.not_valid_before_utc}")
    print(f"Valid To: {cert.not_valid_after_utc}")
    print(f"Signature Algorithm: {cert.signature_algorithm_oid._name}")


def print_verification_result(result: Dict[str, Any]) -> None:
    """
    Print verification result
    
    Args:
        result: Result dictionary returned by verify_certificate
    """
    if result["valid"]:
        print("Certificate is fully valid (signature and validity are both normal)")
    else:
        print("Certificate is invalid")
        for error in result["errors"]:
            print(f"   - {error}")
    
    print(f"\nDetailed Information:")
    print(f"  Subject: {result['subject']}")
    print(f"  Issuer: {result['issuer']}")
    print(f"  Serial Number: {result['serial_number']}")
    print(f"  Valid From: {result['not_valid_before']}")
    print(f"  Valid To: {result['not_valid_after']}")
    print(f"  Signature Verification: {'Passed' if result['signature_valid'] else 'Failed'}")
    print(f"  Validity Verification: {'Passed' if result['validity_valid'] else 'Failed'}")


class Verify:
    """
    Certificate verification class with object-oriented interface
    
    Example:
        verifier = Verify("cert.crt")
        verifier.verify()
        verifier.print_info()
    """
    
    def __init__(self, cert_input: str | x509.Certificate):
        """
        Initialize verifier with certificate file path or certificate object
        
        Args:
            cert_input: Certificate file path or x509.Certificate object
        """
        if isinstance(cert_input, str):
            with open(cert_input, "rb") as f:
                self.cert = x509.load_pem_x509_certificate(f.read())
        elif isinstance(cert_input, x509.Certificate):
            self.cert = cert_input
        else:
            raise TypeError("cert_input must be a file path (str) or x509.Certificate object")
    
    def verify_signature(self) -> bool:
        """
        Verify certificate signature
        
        Returns:
            True if signature is valid
            
        Raises:
            CertificateSignatureError: Signature verification failed
        """
        return verify_certificate_signature(self.cert)
    
    def verify_validity(self, check_time: Optional[datetime.datetime] = None) -> bool:
        """
        Verify certificate validity period
        
        Args:
            check_time: Check time, default is current time
            
        Returns:
            True if certificate is within validity period
            
        Raises:
            CertificateNotYetValidError: Certificate is not yet valid
            CertificateExpiredError: Certificate has expired
        """
        return verify_certificate_validity(self.cert, check_time)
    
    def verify(self, check_time: Optional[datetime.datetime] = None) -> Dict[str, Any]:
        """
        Complete certificate verification (signature + validity)
        
        Args:
            check_time: Check time, default is current time
            
        Returns:
            Verification result dictionary containing valid status and detailed information
        """
        return verify_certificate(self.cert, check_time)
    
    def print_info(self) -> None:
        """Print certificate basic information"""
        print_certificate_info(self.cert)
    
    def print_result(self, check_time: Optional[datetime.datetime] = None) -> None:
        """
        Print verification result
        
        Args:
            check_time: Check time, default is current time
        """
        result = self.verify(check_time)
        print_verification_result(result)
    
    @property
    def subject(self) -> str:
        """Get certificate subject"""
        return self.cert.subject.rfc4514_string()
    
    @property
    def issuer(self) -> str:
        """Get certificate issuer"""
        return self.cert.issuer.rfc4514_string()
    
    @property
    def serial_number(self) -> int:
        """Get certificate serial number"""
        return self.cert.serial_number
    
    @property
    def not_valid_before(self) -> datetime.datetime:
        """Get certificate validity start time"""
        return self.cert.not_valid_before_utc
    
    @property
    def not_valid_after(self) -> datetime.datetime:
        """Get certificate validity end time"""
        return self.cert.not_valid_after_utc
    
    @property
    def is_valid(self) -> bool:
        """Check if certificate is currently valid (signature + validity)"""
        try:
            result = self.verify()
            return result["valid"]
        except CertificateValidationError:
            return False
    
    @property
    def certificate(self) -> x509.Certificate:
        """Get the underlying certificate object"""
        return self.cert
