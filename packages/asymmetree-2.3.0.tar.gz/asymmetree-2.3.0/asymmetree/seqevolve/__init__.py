"""Subpackage for evolving sequences along trees.

The subpackage contains modules for the simulation of nucleotide or amino acid sequences along a
phylogenetic tree using time-continuous Markov chains, as usually applied for this purpose (for
textbooks, see e.g. [1], [2], and [3]).

These models typically take a substitution-rate matrix and the equilibrium frequencies of the states
(i.e. the nucleotides or amino acids) as input. Moreover, insertions and deletions (indels) and
heterogeneity among the sites can be simulated.

References:
   1. J. Felsenstein. Inferring Phylogenies. Sinauer Associates, Sunderland, Mass, 2004.
      ISBN 978-0-87893-177-4.
   2. Z. Yang. Computational molecular evolution. Oxford series in ecology and evolution.
      Oxford University Press, 2006. ISBN 978-0-19-856699-1 978-0-19-856702-8.
   3. Z. Yang. Molecular Evolution: A Statistical Approach. Oxford University Press, Oxford,
      United Kingdom; New York, NY, United States of America, First edition, 2014.
      ISBN 978-0-19-960261-2 978-0-19-960260-5.
"""

from __future__ import annotations

from asymmetree.seqevolve.evolver import Evolver as Evolver
from asymmetree.seqevolve.substitution import SubstModel as SubstModel
from asymmetree.seqevolve.indels import IndelModel as IndelModel
from asymmetree.seqevolve.heterogeneity import HetModel as HetModel
from asymmetree.seqevolve.alignment import AlignmentBuilder as AlignmentBuilder
from asymmetree.seqevolve.evolving_sequence import EvoSeq as EvoSeq
