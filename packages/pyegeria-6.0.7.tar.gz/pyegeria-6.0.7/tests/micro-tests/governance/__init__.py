"""Governance-focused micro-tests."""

