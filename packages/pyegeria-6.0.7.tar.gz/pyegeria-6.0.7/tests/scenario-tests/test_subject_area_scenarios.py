"""
PDX-License-Identifier: Apache-2.0
Copyright Contributors to the ODPi Egeria project.

Scenario tests for SubjectArea.
"""
import time
from datetime import datetime
from typing import List, Optional
from dataclasses import dataclass

from rich import print as rprint
from rich.console import Console
from rich.table import Table

from pyegeria.omvs.subject_area import SubjectArea
from pyegeria.core._exceptions import PyegeriaException, PyegeriaTimeoutException

VIEW_SERVER = "qs-view-server"
PLATFORM_URL = "https://localhost:9443"
USER_ID = "peterprofile"
USER_PWD = "secret"

console = Console(width=200)


@dataclass
class TestResult:
    scenario_name: str
    status: str
    duration: float
    message: str = ""


class SubjectAreaScenarioTester:
    def __init__(self):
        self.client: Optional[SubjectArea] = None
        self.results: List[TestResult] = []

    def setup(self) -> bool:
        try:
            self.client = SubjectArea(VIEW_SERVER, PLATFORM_URL, USER_ID, USER_PWD)
            self.client.create_egeria_bearer_token(USER_ID, USER_PWD)
            return True
        except Exception:
            return False

    def teardown(self):
        if self.client:
            self.client.close_session()

    def scenario_subject_area_hierarchy(self) -> TestResult:
        name = "Subject Area Hierarchy"
        start_time = time.perf_counter()
        try:
            # 1. Create parent subject area
            parent_body = {
                "class": "NewElementRequestBody",
                "properties": {
                    "class": "SubjectAreaProperties",
                    "qualifiedName": f"SubjectArea::Parent::{datetime.now().timestamp()}",
                    "displayName": "Parent Subject Area",
                }
            }
            response = self.client.create_subject_area(parent_body)
            parent_guid = response.get("guid") if isinstance(response, dict) else response

            # 2. Create child subject area
            child_body = {
                "class": "NewElementRequestBody",
                "properties": {
                    "class": "SubjectAreaProperties",
                    "qualifiedName": f"SubjectArea::Child::{datetime.now().timestamp()}",
                    "displayName": "Child Subject Area",
                }
            }
            response = self.client.create_subject_area(child_body)
            child_guid = response.get("guid") if isinstance(response, dict) else response

            # 3. Link them
            link_body = {"class": "NewRelationshipRequestBody", "properties": {"class": "SubjectAreaHierarchyProperties"}}
            self.client.link_subject_area_hierarchy(parent_guid, child_guid, link_body)
            
            return TestResult(name, "PASSED", time.perf_counter() - start_time, f"Linked {parent_guid} to {child_guid}")
        except PyegeriaTimeoutException as e:
            rprint(f"[bold yellow]Timeout in {name}; continuing.[/bold yellow]")
            return TestResult(name, "WARNING", time.perf_counter() - start_time, f"Timeout: {e}")
        except PyegeriaException as e:
            return TestResult(name, "FAILED", time.perf_counter() - start_time, str(e))
        except Exception as e:
            return TestResult(name, "FAILED", time.perf_counter() - start_time, f"Unexpected error: {e}")

    def run_all_scenarios(self):
        if not self.setup():
            rprint("[bold red]Setup failed, skipping scenarios[/bold red]")
            return
        
        self.results.append(self.scenario_subject_area_hierarchy())
        self.teardown()
        self.print_results_summary()

    def print_results_summary(self):
        table = Table(title="Subject Area Scenario Results")
        table.add_column("Scenario", style="cyan")
        table.add_column("Status", justify="center")
        table.add_column("Duration (s)", justify="right")
        table.add_column("Message")
        for res in self.results:
            if res.status == "PASSED":
                style = "green"
            elif res.status == "WARNING":
                style = "yellow"
            else:
                style = "red"
            table.add_row(res.scenario_name, f"[{style}]{res.status}[/{style}]", f"{res.duration:.2f}", res.message)
        console.print(table)


def test_subject_area_scenarios():
    tester = SubjectAreaScenarioTester()
    tester.run_all_scenarios()


if __name__ == "__main__":
    test_subject_area_scenarios()
