#!/bin/bash

# Author details
## Script name: update_repo_mike2.sh
## Purpose of the script: 
## Author(s): Jyotirmoy Das, Ph.D.
## Date Created: 2025-08-25
## Date Last Modified: 2025-08-25
## Copyright statement: GNU3 open license
## Contact information: jyotirmoy.das@liu.se
## Please cite:
## @article{}
## Notes:
## Please read the manual/tutorial file for the sample preparation of the analysis.

# update_repo_mike2.sh
# chmod +x update_repo_mike2.sh
# ./update_repo_mike2.sh
# =============================
# Fully Automatic Repo Rename + MkDocs/Mike Update
# =============================
set -e

OLD_NAME="TwistMethNext"
NEW_NAME="TwistMethylFlow"
USER="JD2112"

echo "=== Step 1: Updating Git remote (after repo is renamed on GitHub UI) ==="
git remote set-url origin git@github.com:$USER/$NEW_NAME.git

echo "=== Step 2: Backing up and updating README.md ==="
cp README.md README.md.bak
sed -i "s|$OLD_NAME|$NEW_NAME|g" README.md

echo "=== Step 3: Backing up and updating mkdocs.yml ==="
cp mkdocs.yml mkdocs.yml.bak
sed -i "s|$OLD_NAME|$NEW_NAME|g" mkdocs.yml

echo "=== Step 4: Updating all MkDocs content files ==="
for f in docs/*.md; do
  cp "$f" "$f.bak"
  sed -i "s|$OLD_NAME|$NEW_NAME|g" "$f"
  sed -i "s|$USER.github.io/$OLD_NAME|$USER.github.io/$NEW_NAME|g" "$f"
  sed -i "s|github.com/$USER/$OLD_NAME|github.com/$USER/$NEW_NAME|g" "$f"
done

echo "=== Step 5: Commit changes ==="
git add README.md mkdocs.yml docs/*.md
git commit -m "auto-rename: $OLD_NAME → $NEW_NAME (docs, README, remote updated)"

echo "=== Done! ==="
echo "Repo has been renamed to $NEW_NAME."
echo "Remember: first rename the repo on GitHub via Settings → Repository name."
