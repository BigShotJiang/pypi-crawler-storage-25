#!/bin/bash
# Author details
## Script name: git_repo_migration.sh
## Purpose of the script: 
## Author(s): Jyotirmoy Das, Ph.D.
## Date Created: 2025-08-25
## Date Last Modified: 2025-08-25
## Copyright statement: GNU3 open license
## Contact information: jyotirmoy.das@liu.se
## Please cite:
## @article{}
## Notes:
## Please read the manual/tutorial file for the sample preparation of the analysis.

# Usage:
# chmod +x sync_tags_releases.sh
# ./sync_tags_releases.sh
# The script will ask you for:
# Old repo name (full GitHub repo path)
# New repo name (full GitHub repo path)
# Local path to the new repo clone

set -e

echo "=== GitHub Tags & Releases Migrator ==="

# Interactive input for repositories
read -p "Enter OLD repository (e.g., JD2112/ShinyOlink): " OLD_REPO
read -p "Enter NEW repository (e.g., JD2112/olinkWrapper): " NEW_REPO

echo "Old repo: $OLD_REPO"
echo "New repo: $NEW_REPO"

# Step 1: Fetch all tags from old repo
echo "Step 1: Fetching all tags from old repo..."
gh repo clone "$OLD_REPO" temp_old_repo -- --quiet || true
cd temp_old_repo
git fetch --tags
OLD_TAGS=$(git tag)

# Step 2: Push missing tags to new repo
echo "Step 2: Pushing missing tags to new repo..."
cd ..
read -p "Enter path to local clone of NEW_REPO: " NEW_REPO_PATH
cd "$NEW_REPO_PATH"
git fetch --tags

for TAG in $OLD_TAGS; do
    if ! git rev-parse "$TAG" >/dev/null 2>&1; then
        echo "Tag $TAG missing locally, fetching..."
        git fetch ../temp_old_repo "refs/tags/$TAG:refs/tags/$TAG"
    fi

    if ! git ls-remote --tags origin | grep -q "refs/tags/$TAG"; then
        echo "Pushing missing tag $TAG to new repo..."
        git push origin "refs/tags/$TAG"
    fi
done

# Step 3: Migrate releases from old repo
echo "Step 3: Migrating releases from old repo..."
RELEASE_TAGS=$(gh release list -R "$OLD_REPO" --limit 1000 --json tagName --jq '.[].tagName')

for TAG in $RELEASE_TAGS; do
    echo "Migrating release for tag $TAG..."
    
    if gh release view "$TAG" --repo "$NEW_REPO" >/dev/null 2>&1; then
        echo "Release $TAG already exists in $NEW_REPO, skipping."
        continue
    fi

    TITLE=$(gh release view "$TAG" -R "$OLD_REPO" --json name --jq '.name')
    NOTES=$(gh release view "$TAG" -R "$OLD_REPO" --json body --jq '.body')

    gh release create "$TAG" \
        --repo "$NEW_REPO" \
        --title "${TITLE:-$TAG}" \
        --notes "${NOTES:-"Migrated release from $OLD_REPO"}"

    echo "Release $TAG migrated!"
done

# Step 4: Create releases for tags without a release yet
echo "Step 4: Creating releases for tags without releases..."
for TAG in $OLD_TAGS; do
    if ! gh release view "$TAG" --repo "$NEW_REPO" >/dev/null 2>&1; then
        echo "Creating release for tag $TAG..."
        gh release create "$TAG" \
            --repo "$NEW_REPO" \
            --title "$TAG" \
            --notes "Automatically created release for tag $TAG"
        echo "Release for tag $TAG created!"
    fi
done

echo "All tags and releases are now synced!"
rm -rf temp_old_repo
