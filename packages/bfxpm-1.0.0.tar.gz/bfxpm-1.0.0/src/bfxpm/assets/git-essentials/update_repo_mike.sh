#!/bin/bash

# Author details
## Script name: Untitled-2
## Purpose of the script: 
## Author(s): Jyotirmoy Das, Ph.D.
## Date Created: 2025-08-25
## Date Last Modified: 2025-08-25
## Copyright statement: GNU3 open license
## Contact information: jyotirmoy.das@liu.se
## Please cite:
## @article{}
## Notes:
## Please read the manual/tutorial file for the sample preparation of the analysis.


# update_repo_mike.sh
# chmod +x update_repo_mike.sh
# ./update_repo_mike.sh


# =============================
# Fully Automatic Repo Rename + MkDocs/Mike Update
# =============================

# -----------------------------
# Config
# -----------------------------
OLD_REPO="TwistMethNext"
NEW_REPO="TwistMethylFlow"
GITHUB_USER="JD2112"
MKDOCS_SITE_DIR="./docs"      # path to docs folder
MKDOCS_YML="mkdocs.yml"
MIKE_VERSION="latest"         # version/alias for Mike deployment
CHAPTERS=("index.md" "overview.md" "usage.md" "credits.md" "references.md")

# -----------------------------
# Step 1: Update Git remote
# -----------------------------
echo "[1/5] Updating Git remote..."
git remote set-url origin "https://github.com/$GITHUB_USER/$NEW_REPO.git"
git fetch origin
echo "Git remote updated to $NEW_REPO"

# -----------------------------
# Step 2: Update README.md
# -----------------------------
echo "[2/5] Updating README.md links..."
grep -rl "$OLD_REPO" README.md | xargs sed -i.bak "s|$OLD_REPO|$NEW_REPO|g"

# -----------------------------
# Step 3: Update mkdocs.yml
# -----------------------------
echo "[3/5] Updating mkdocs.yml..."
grep -rl "$OLD_REPO" $MKDOCS_YML | xargs sed -i.bak "s|$OLD_REPO|$NEW_REPO|g"

# -----------------------------
# Step 4: Update chapters and cross-links
# -----------------------------
echo "[4/5] Updating chapters and cross-links..."
for file in "${CHAPTERS[@]}"; do
    FILE_PATH="$MKDOCS_SITE_DIR/$file"
    if [[ -f "$FILE_PATH" ]]; then
        # Replace old repo name with new
        sed -i.bak "s|$OLD_REPO|$NEW_REPO|g" "$FILE_PATH"

        # Update GitHub Pages links (e.g., .../TwistMethNext/latest/... -> .../TwistMethylFlow/latest/...)
        sed -i.bak "s|$OLD_REPO/latest|$NEW_REPO/latest|g" "$FILE_PATH"

        # Update cross-links between chapters
        for target in "${CHAPTERS[@]}"; do
            TARGET_BASENAME=$(basename "$target")
            sed -i.bak "s|$OLD_REPO/$TARGET_BASENAME|$NEW_REPO/$TARGET_BASENAME|g" "$FILE_PATH"
        done
        echo "Updated $FILE_PATH"
    else
        echo "Warning: $FILE_PATH not found"
    fi
done

# -----------------------------
# Step 5: Deploy with Mike
# -----------------------------
echo "[5/5] Deploying site with Mike..."
mike deploy $MIKE_VERSION latest --push
echo "Deployment completed successfully!"

echo "==============================="
echo "All done! Your repo has been renamed and docs updated."
echo "Remember: .bak backup files are kept in the repo."
echo "Your local git is now pointing to https://github.com/$GITHUB_USER/$NEW_REPO.git"
echo "==============================="
