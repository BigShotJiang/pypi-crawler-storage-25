#!/bin/bash

# === CONFIGURATION ===
OLD_REPO="JD2112/ShinyOlink"
NEW_REPO="JD2112/olinkWrapper"

set -e

echo "Fetching all tags from old repo..."
gh repo clone "$OLD_REPO" temp_old_repo -- --quiet || true
cd temp_old_repo

git fetch --tags

echo "Switching back to your new repo..."
cd ..
cd olinkWrapper  # replace with path to your new repo

# Push any tags missing in new repo
echo "Pushing missing tags to new repo..."
for TAG in $(git ls-remote --tags origin | awk '{print $2}' | sed 's#refs/tags/##'); do
    if ! git ls-remote --tags origin | grep -q "refs/tags/$TAG"; then
        echo "Pushing tag $TAG..."
        git push origin "refs/tags/$TAG"
    fi
done

echo "Fetching releases from old repo..."
TAGS=$(gh release list -R "$OLD_REPO" --limit 1000 --json tagName --jq '.[].tagName')

for TAG in $TAGS; do
    echo "Migrating release for tag $TAG..."

    # Skip if release already exists
    if gh release view "$TAG" --repo "$NEW_REPO" >/dev/null 2>&1; then
        echo "Release $TAG already exists in $NEW_REPO, skipping."
        continue
    fi

    TITLE=$(gh release view "$TAG" -R "$OLD_REPO" --json name --jq '.name')
    NOTES=$(gh release view "$TAG" -R "$OLD_REPO" --json body --jq '.body')

    gh release create "$TAG" \
        --repo "$NEW_REPO" \
        --title "$TITLE" \
        --notes "$NOTES"

    echo "Release $TAG migrated!"
done

echo "All releases migrated successfully!"
rm -rf temp_old_repo
