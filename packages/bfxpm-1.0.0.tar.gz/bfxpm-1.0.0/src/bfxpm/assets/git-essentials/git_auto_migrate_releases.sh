#!/bin/bash

# Source and target repositories
SOURCE_REPO="JD2112/ShinyOlink"
TARGET_REPO="JD2112/olinkWrapper"

# Fetch all releases from source repo
releases=$(gh release list -R $SOURCE_REPO --limit 1000 --json tagName,name,body,draft,prerelease)

# Loop through releases
echo "$releases" | jq -c '.[]' | while read release; do
    TAG=$(echo "$release" | jq -r '.tagName')
    NAME=$(echo "$release" | jq -r '.name')
    BODY=$(echo "$release" | jq -r '.body')
    DRAFT=$(echo "$release" | jq -r '.draft')
    PRE=$(echo "$release" | jq -r '.prerelease')

    echo "Processing release: $TAG ($NAME)"

    # Skip if release already exists in target repo
    if gh release view "$TAG" -R $TARGET_REPO &> /dev/null; then
        echo "Release $TAG already exists in target repo. Skipping..."
        continue
    fi

    # Create release in target repo
    gh release create "$TAG" \
        --title "$NAME" \
        --notes "$BODY" \
        $( [ "$DRAFT" = "true" ] && echo "--draft" ) \
        $( [ "$PRE" = "true" ] && echo "--prerelease" ) \
        -R $TARGET_REPO

    echo "Release $TAG migrated."
done

echo "All releases migrated successfully!"
