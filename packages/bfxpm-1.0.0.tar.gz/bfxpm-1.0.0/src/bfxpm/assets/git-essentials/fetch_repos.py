import requests

GITHUB_USERNAME = 'JD2112'
TOKEN = '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'

BASE_URL = "https://api.github.com/user/repos"
headers = {
    'Authorization': f'token {TOKEN}'
}

# Initialize variables
repos = []
page = 1

while True:
    # Make the API request with pagination
    response = requests.get(f"{BASE_URL}?per_page=100&page={page}", headers=headers)
    
    if response.status_code != 200:
        print(f"Error: Unable to fetch repositories (status code {response.status_code})")
        print(response.json())
        break
    
    # Parse the JSON response
    page_repos = response.json()
    if not page_repos:  # No more repositories
        break
    
    repos.extend(page_repos)
    page += 1  # Move to the next page

# Save all repositories to a file
output_file = 'my_github_repos.txt'
with open(output_file, 'w') as file:
    for repo in repos:
        repo_name = repo['name']
        repo_url = repo['html_url']
        file.write(f"{repo_name}: {repo_url}\n")

print(f"Extracted {len(repos)} repositories. Saved to {output_file}.")

# Save all repositories to an HTML file
output_file = 'my_github_repos.html'
with open(output_file, 'w') as file:
    # Start the HTML structure
    file.write("<html>\n<head><title>My GitHub Repositories</title></head>\n<body>\n")
    file.write("<h1>My GitHub Repositories</h1>\n<ul>\n")
    
    # Add repositories as clickable links
    for repo in repos:
        repo_name = repo['name']
        repo_url = repo['html_url']
        file.write(f"<li><a href='{repo_url}' target='_blank'>{repo_name}</a></li>\n")
    
    # Close the HTML structure
    file.write("</ul>\n</body>\n</html>")

print(f"Extracted {len(repos)} repositories. Saved to {output_file}.")

# Save all repositories to a Quarto Markdown file
output_file = 'my_github_repos.qmd'
with open(output_file, 'w') as file:
    # Start the markdown content
    file.write("# My GitHub Repositories\n\n")
    
    # Add repositories as clickable links using Quarto markdown syntax
    for repo in repos:
        repo_name = repo['name']
        repo_url = repo['html_url']
        file.write(f"- [{repo_name}]({repo_url}){{.external target='_blank'}}\n")

print(f"Extracted {len(repos)} repositories. Saved to {output_file}.")