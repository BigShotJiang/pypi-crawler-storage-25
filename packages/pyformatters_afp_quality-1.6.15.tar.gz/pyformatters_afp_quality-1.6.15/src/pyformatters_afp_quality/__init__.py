"""Sherpa AFP Quality formatter"""

__version__ = "1.6.15"
