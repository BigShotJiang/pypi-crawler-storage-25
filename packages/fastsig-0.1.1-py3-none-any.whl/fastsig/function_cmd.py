#!/usr/bin/env python3
"""Gene-set (`function`) and gene-body (`gene`) heatmap subcommands.

Both delegate the actual rendering to ``fastsig.plot.heatmap_box`` so users get
the same publication heatmap + boxplot as the standalone tool.

`function`:
    Take one or more gene-set files (GMT or one-gene-per-line text), filter a
    gene BED (or extract one from a GTF) by gene symbol, and run a
    scale-regions matrix + heatmap + boxplot. Each gene set becomes one row
    group in the heatmap.

`gene`:
    Run a scale-regions matrix + heatmap + boxplot directly on a gene-body BED
    (or one extracted from a GTF). Optionally sample the top-N largest
    transcripts to keep the matrix tractable.
"""

from __future__ import annotations

import argparse
import os
import re
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path
from typing import Iterable

# Reuse pipeline helpers
from .pipeline import find_binary, run, ensure_dir, safe_label  # type: ignore


# ---------------------------------------------------------------------------
# Gene-set parsing
# ---------------------------------------------------------------------------


def parse_gene_sets(files: list[str]) -> list[tuple[str, list[str]]]:
    """Parse a mix of .gmt and plain text files.

    Returns a list of (set_name, [gene_name, ...]) tuples preserving input
    order. .gmt files contribute one set per line; text files contribute one
    set named after the file stem.
    """
    sets: list[tuple[str, list[str]]] = []
    for f in files:
        path = Path(f)
        if not path.exists():
            sys.exit(f"--genes file not found: {path}")
        if path.suffix.lower() == ".gmt":
            with open(path) as fh:
                for line in fh:
                    line = line.rstrip("\r\n")
                    if not line or line.startswith("#"):
                        continue
                    parts = line.split("\t")
                    if len(parts) < 3:
                        continue
                    name = parts[0].strip()
                    genes = [g.strip() for g in parts[2:] if g.strip()]
                    if name and genes:
                        sets.append((name, genes))
        else:
            genes: list[str] = []
            with open(path) as fh:
                for line in fh:
                    g = line.strip().split("\t", 1)[0].strip()
                    if g and not g.startswith("#"):
                        genes.append(g)
            if genes:
                sets.append((path.stem, genes))
    return sets


# ---------------------------------------------------------------------------
# Gene BED filtering
# ---------------------------------------------------------------------------


def filter_gene_bed(
    gene_bed: str | os.PathLike,
    names: Iterable[str],
    name_col: int = 4,
    ignore_case: bool = True,
) -> tuple[list[str], int, int]:
    """Return ``(matching_lines, matched_n, requested_n)``.

    ``name_col`` is 1-based; default 4 matches a standard gene BED.
    Duplicates in the BED are kept; duplicate gene names from input are
    deduplicated before lookup.
    """
    requested = list(dict.fromkeys(g for g in names if g))
    if not requested:
        return [], 0, 0

    target = (
        {g.upper() for g in requested} if ignore_case else set(requested)
    )

    matched_names: set[str] = set()
    out_lines: list[str] = []
    idx = name_col - 1
    with open(gene_bed) as fh:
        for raw in fh:
            if not raw or raw.startswith("#") or raw.startswith("track "):
                continue
            cols = raw.rstrip("\r\n").split("\t")
            if len(cols) <= idx:
                continue
            name = cols[idx]
            key = name.upper() if ignore_case else name
            if key in target:
                out_lines.append(raw if raw.endswith("\n") else raw + "\n")
                matched_names.add(key)
    return out_lines, len(matched_names), len(requested)


# ---------------------------------------------------------------------------
# GTF → gene BED via the bundled Rust binary
# ---------------------------------------------------------------------------


def gtf_to_gene_bed(gtf: str, out_bed: Path, name_attr: str = "gene_name") -> None:
    bin_path = find_binary("gtf_to_bed")
    cmd = [
        bin_path,
        "--gtf",
        str(gtf),
        "--output",
        str(out_bed),
        "--feature",
        "gene",
        "--name_attr",
        name_attr,
    ]
    print(f"[fastsig] gtf_to_bed: {gtf} → {out_bed}")
    proc = subprocess.run(cmd)
    if proc.returncode != 0:
        sys.exit(proc.returncode)


# ---------------------------------------------------------------------------
# Shared plot delegation
# ---------------------------------------------------------------------------


def _call_heatmap_box(
    *,
    bed_files: list[str],
    bigwigs: list[str],
    region_labels: list[str],
    sample_labels: list[str] | None,
    output_dir: Path,
    base_name: str,
    mode: str,  # "region" or "center"
    args: argparse.Namespace,
) -> None:
    """Invoke the plot_heatmap_box CLI in a subprocess so its argparse
    handles all the remaining knobs uniformly with the standalone tool."""
    here = Path(__file__).resolve().parent
    box_script = here / "plot" / "heatmap_box.py"
    pkg_root = str(here.parent)  # parent of fastsig/

    cmd: list[str] = [
        sys.executable,
        str(box_script),
        mode,
        "--input_bed",
        *bed_files,
        "--input_bigwig",
        *bigwigs,
        "--output_path",
        str(output_dir),
        "--base_name",
        base_name,
        "--threads",
        str(args.processors),
        "--colormap",
        args.colormap,
        "--sort",
        args.sort,
        "--ylabel",
        args.ylabel,
        "--palette",
        args.palette,
        "--stat_test",
        args.stat_test,
        "--dpi",
        str(args.dpi),
    ]
    if args.title:
        cmd += ["--title", args.title]
    if region_labels:
        cmd += ["--regions", *region_labels]
    if sample_labels:
        cmd += ["--samples", *sample_labels]
    if args.vmin is not None:
        cmd += ["--vmin", str(args.vmin)]
    if args.vmax is not None:
        cmd += ["--vmax", str(args.vmax)]
    if args.profile_colors:
        cmd += ["--profile_colors", *args.profile_colors]
    if args.stat_pairs:
        cmd += ["--stat_pairs", *args.stat_pairs]
    if getattr(args, "matrix_engine", None):
        cmd += ["--matrix_engine", args.matrix_engine]
        if args.matrix_engine == "rust":
            try:
                cmd += ["--rust_bin", find_binary("compute_matrix")]
            except FileNotFoundError:
                pass

    env = os.environ.copy()
    env["PYTHONPATH"] = pkg_root + os.pathsep + env.get("PYTHONPATH", "")
    print(f"[fastsig] {' '.join(str(c) for c in cmd)}")
    proc = subprocess.run(cmd, env=env)
    if proc.returncode != 0:
        sys.exit(proc.returncode)


# ---------------------------------------------------------------------------
# Argument parsers — shared knobs
# ---------------------------------------------------------------------------


def _add_common_signal_args(p: argparse.ArgumentParser) -> None:
    p.add_argument("--inputs", nargs="+", required=True,
                   help="bigWig (or BAM, but BAM not supported here yet) "
                        "score files.")
    p.add_argument("--groups", nargs="+", default=None,
                   help="Per-input sample-group label (forwarded to "
                        "plot_heatmap_box --groups for grouped panels).")
    p.add_argument("--labels", nargs="+", default=None,
                   help="Display label per --inputs (default: file stem).")
    p.add_argument("--output_dir", required=True, help="Output directory.")
    p.add_argument("-p", "--processors", type=int, default=4,
                   help="Threads for compute_matrix.")
    p.add_argument("--matrix_engine", choices=["python", "rust"],
                   default="rust",
                   help="Engine used by plot_heatmap_box for computeMatrix.")
    p.add_argument("--title", default=None, help="Figure title + base name.")

    # plotting knobs forwarded to heatmap_box
    p.add_argument("--colormap", default="Oranges")
    p.add_argument("--vmin", default=None)
    p.add_argument("--vmax", default=None)
    p.add_argument("--profile_colors", nargs="+", default=None)
    p.add_argument("--sort", choices=["descending", "ascending", "keep"],
                   default="descending")
    p.add_argument("--ylabel", default="Signal")
    p.add_argument("--palette", default="orange")
    p.add_argument("--stat_pairs", nargs="+", default=None)
    p.add_argument("--stat_test", default="Mann-Whitney",
                   choices=["Mann-Whitney", "t-test_ind", "t-test_welch",
                            "Wilcoxon", "Brunner-Munzel", "Levene", "Kruskal"])
    p.add_argument("--dpi", type=int, default=300)


def _add_gene_source_args(p: argparse.ArgumentParser) -> None:
    g = p.add_mutually_exclusive_group(required=True)
    g.add_argument("--gene_bed", default=None,
                   help="Pre-extracted gene BED (col 4 = gene name).")
    g.add_argument("--gtf", default=None,
                   help="GTF or GTF.gz; auto-extracted via gtf_to_bed.")
    p.add_argument("--name_attr", default="gene_name",
                   help="GTF attribute used as BED col 4 (default: gene_name).")
    p.add_argument("--name_col", type=int, default=4,
                   help="1-based BED column to match gene names against.")


# ---------------------------------------------------------------------------
# fastsig function
# ---------------------------------------------------------------------------


def function_main() -> int:
    p = argparse.ArgumentParser(
        prog="fastsig function",
        description=(
            "Gene-set heatmap: parse one or more GMT/text files, filter a "
            "gene BED by gene symbol (case-insensitive by default), and run "
            "scale-regions matrix + heatmap + boxplot."
        ),
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )
    p.add_argument("--genes", nargs="+", required=True,
                   help="Gene-set files (.gmt or one-gene-per-line text). "
                        "Each .gmt line contributes one set; each text file "
                        "contributes one set named by file stem.")
    p.add_argument("--case_sensitive", action="store_true",
                   help="Disable case-insensitive matching "
                        "(default: ignore case so 'Gata4' matches 'GATA4').")
    p.add_argument("--min_match_ratio", type=float, default=0.05,
                   help="Warn (do not abort) if matched/requested ratio is "
                        "below this for any set.")
    _add_gene_source_args(p)
    _add_common_signal_args(p)
    args = p.parse_args()

    if args.groups and len(args.groups) != len(args.inputs):
        sys.exit("--groups must have the same length as --inputs (or be omitted).")
    labels = args.labels or [Path(s).stem for s in args.inputs]
    if len(labels) != len(args.inputs):
        sys.exit("--labels must match --inputs in length.")

    out_dir = ensure_dir(Path(args.output_dir))
    base_name = safe_label(args.title or "fastsig_function")

    # Resolve gene BED
    if args.gene_bed:
        gene_bed_path = Path(args.gene_bed)
    else:
        gene_bed_path = out_dir / "_gene_bed_from_gtf.bed"
        if not gene_bed_path.exists():
            gtf_to_gene_bed(args.gtf, gene_bed_path, name_attr=args.name_attr)

    # Parse gene sets
    sets = parse_gene_sets(args.genes)
    if not sets:
        sys.exit("No gene sets parsed from --genes inputs.")

    # Per-set BED files, in declaration order
    sets_dir = ensure_dir(out_dir / "gene_sets")
    bed_files: list[str] = []
    region_labels: list[str] = []
    summary: list[tuple[str, int, int]] = []
    for set_name, genes in sets:
        lines, matched, requested = filter_gene_bed(
            gene_bed_path, genes,
            name_col=args.name_col,
            ignore_case=not args.case_sensitive,
        )
        ratio = matched / max(requested, 1)
        msg = f"[fastsig] gene set '{set_name}': matched {matched}/{requested} ({ratio:.0%})"
        if ratio < args.min_match_ratio:
            msg += "  ⚠ below --min_match_ratio"
        print(msg)
        summary.append((set_name, matched, requested))

        if not lines:
            print(f"[fastsig]   skipping '{set_name}' — no rows matched")
            continue
        safe = re.sub(r"\W+", "_", set_name) or "set"
        bed_path = sets_dir / f"{safe}.bed"
        bed_path.write_text("".join(lines))
        bed_files.append(str(bed_path))
        region_labels.append(set_name)

    if not bed_files:
        sys.exit("No gene sets produced any matching regions; aborting.")

    # Write summary
    with open(out_dir / "gene_set_match_summary.tsv", "w") as fh:
        fh.write("set\tmatched\trequested\tratio\n")
        for name, m, r in summary:
            fh.write(f"{name}\t{m}\t{r}\t{m / max(r, 1):.4f}\n")

    # Render heatmap + boxplot using region (scale-regions) mode
    _call_heatmap_box(
        bed_files=bed_files,
        bigwigs=list(args.inputs),
        region_labels=region_labels,
        sample_labels=labels,
        output_dir=out_dir,
        base_name=base_name,
        mode="region",
        args=args,
    )
    print(f"[fastsig] Done. Outputs in {out_dir}")
    return 0


# ---------------------------------------------------------------------------
# fastsig gene
# ---------------------------------------------------------------------------


def gene_main() -> int:
    p = argparse.ArgumentParser(
        prog="fastsig gene",
        description=(
            "Gene-body heatmap: use every record in --gene_bed (or a BED "
            "auto-extracted from --gtf) as a region, then scale-regions "
            "matrix + heatmap + boxplot."
        ),
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )
    p.add_argument("--top_n", type=int, default=None,
                   help="Optional cap: keep only the top-N largest regions "
                        "(by length) to avoid huge matrices.")
    p.add_argument("--region_label", default="Genes",
                   help="Heatmap row group label.")
    _add_gene_source_args(p)
    _add_common_signal_args(p)
    args = p.parse_args()

    labels = args.labels or [Path(s).stem for s in args.inputs]
    if len(labels) != len(args.inputs):
        sys.exit("--labels must match --inputs in length.")

    out_dir = ensure_dir(Path(args.output_dir))
    base_name = safe_label(args.title or "fastsig_gene")

    # Resolve gene BED
    if args.gene_bed:
        src_bed = Path(args.gene_bed)
    else:
        src_bed = out_dir / "_gene_bed_from_gtf.bed"
        if not src_bed.exists():
            gtf_to_gene_bed(args.gtf, src_bed, name_attr=args.name_attr)

    # Optionally restrict to top-N
    if args.top_n:
        top_bed = out_dir / f"_top{args.top_n}.bed"
        rows: list[tuple[int, str]] = []
        with open(src_bed) as fh:
            for line in fh:
                if not line or line.startswith("#"):
                    continue
                cols = line.rstrip("\r\n").split("\t")
                if len(cols) < 3:
                    continue
                try:
                    span = int(cols[2]) - int(cols[1])
                except ValueError:
                    continue
                rows.append((span, line if line.endswith("\n") else line + "\n"))
        rows.sort(key=lambda x: -x[0])
        with open(top_bed, "w") as fh:
            for _span, raw in rows[: args.top_n]:
                fh.write(raw)
        regions_bed = top_bed
        print(f"[fastsig] kept top {args.top_n} regions by length → {regions_bed}")
    else:
        regions_bed = src_bed

    _call_heatmap_box(
        bed_files=[str(regions_bed)],
        bigwigs=list(args.inputs),
        region_labels=[args.region_label],
        sample_labels=labels,
        output_dir=out_dir,
        base_name=base_name,
        mode="region",
        args=args,
    )
    print(f"[fastsig] Done. Outputs in {out_dir}")
    return 0


if __name__ == "__main__":
    raise SystemExit(function_main())
