"""Local stub for the `zlbio` namespace. See `zlbio.plot`."""
