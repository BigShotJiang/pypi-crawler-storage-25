"""Seaborn-based boxplot wrapper compatible with the zlbio.plot.boxplot API."""

from __future__ import annotations

import matplotlib.pyplot as plt
import seaborn as sns


def _stylize_black_borders(ax, linewidth: float = 1.0):
    for line in ax.lines:
        line.set_color("black")
        line.set_linewidth(linewidth)
    for patch in ax.artists:
        patch.set_edgecolor("black")
        patch.set_linewidth(linewidth)
    for patch in ax.patches:
        try:
            patch.set_edgecolor("black")
            patch.set_linewidth(linewidth)
        except Exception:
            pass


def _expand_pairs_for_hue(pairs, data, x, hue):
    """Expand flat (a, b) string pairs to ((a, hue), (b, hue)) per hue value."""
    if not hue:
        return pairs
    hue_vals = list(dict.fromkeys(data[hue].dropna().tolist()))

    expanded = []
    for p in pairs:
        if not (isinstance(p, (tuple, list)) and len(p) == 2):
            expanded.append(p)
            continue
        a, b = p
        a_t = isinstance(a, (tuple, list))
        b_t = isinstance(b, (tuple, list))
        if a_t and b_t:
            expanded.append((tuple(a), tuple(b)))
            continue
        for h in hue_vals:
            expanded.append(((a, h), (b, h)))
    return expanded


def boxplot(data, x, y, order=None, hue=None, palette=None, stat=None,
            figsize=(3.0, 4.5), edge_color="black", linewidth=1.0, **kwargs):
    fig, ax = plt.subplots(figsize=figsize)
    sns.boxplot(
        data=data, x=x, y=y, order=order, hue=hue,
        palette=palette, ax=ax,
        fliersize=0, linewidth=linewidth,
        boxprops=dict(edgecolor=edge_color),
        whiskerprops=dict(color=edge_color, linewidth=linewidth),
        capprops=dict(color=edge_color, linewidth=linewidth),
        medianprops=dict(color=edge_color, linewidth=linewidth),
    )
    _stylize_black_borders(ax, linewidth=linewidth)
    sns.despine(ax=ax)

    if stat:
        try:
            from statannotations.Annotator import Annotator
            pairs = stat.get("pairs") or []
            test = stat.get("test", "Mann-Whitney")
            text_format = stat.get("text_format", "star")
            loc = stat.get("loc", "inside")
            order_ = stat.get("order", order)

            pairs = _expand_pairs_for_hue(pairs, data, x, hue)
            if not pairs:
                return ax

            print(f"[INFO] statannotations: test={test}, pairs={pairs}")
            annot = Annotator(ax, pairs, data=data, x=x, y=y,
                              order=order_, hue=hue)
            annot.configure(test=test, text_format=text_format,
                            loc=loc, verbose=1)
            annot.apply_and_annotate()
        except Exception as exc:
            print(f"[WARN] statannotations failed: {exc}")

    return ax
