#!/usr/bin/env python3
"""Local stub for `plot_intersect_venn.py`. Generates a 2-set Venn diagram
and writes per-region BED files (only-A, only-B, shared) using bedtools.

Usage:
    plot_intersect_venn.py -a A.bed -b B.bed --labels LA LB \
        --output_path OUT --title TITLE
"""

from __future__ import annotations

import argparse
import os
import re
import shutil
import subprocess
import sys

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib_venn import venn2


def _safe(label: str) -> str:
    for ch in ['\n', '\\n', '(', ')', ']', '[', ' ', '/', '\\',
              ':', '*', '?', '"', '<', '>', '|', '&']:
        label = label.replace(ch, '_')
    return label


def _count_lines(path):
    n = 0
    with open(path) as fh:
        for _ in fh:
            n += 1
    return n


def main():
    p = argparse.ArgumentParser()
    p.add_argument("-a", required=True)
    p.add_argument("-b", required=True)
    p.add_argument("--labels", nargs=2, required=True)
    p.add_argument("--output_path", required=True)
    p.add_argument("--title", default="")
    args = p.parse_args()

    if not shutil.which("bedtools"):
        sys.exit("[ERROR] bedtools not found on PATH")

    la, lb = _safe(args.labels[0]), _safe(args.labels[1])
    sub = os.path.join(args.output_path, f"{la}_vs_{lb}")
    bed_dir = os.path.join(sub, "bed")
    os.makedirs(bed_dir, exist_ok=True)

    only_a = os.path.join(bed_dir, f"10_only_{la}.bed")
    only_b = os.path.join(bed_dir, f"01_only_{lb}.bed")
    shared = os.path.join(bed_dir, f"11_{la}_vs_{lb}.bed")

    subprocess.run(f"bedtools intersect -a {args.a} -b {args.b} -v > {only_a}",
                   shell=True, check=True)
    subprocess.run(f"bedtools intersect -a {args.b} -b {args.a} -v > {only_b}",
                   shell=True, check=True)
    subprocess.run(f"bedtools intersect -a {args.a} -b {args.b} -u > {shared}",
                   shell=True, check=True)

    n_only_a, n_only_b, n_shared = (_count_lines(only_a),
                                    _count_lines(only_b),
                                    _count_lines(shared))

    fig, ax = plt.subplots(figsize=(4, 4))
    venn2(subsets=(n_only_a, n_only_b, n_shared),
          set_labels=(args.labels[0], args.labels[1]), ax=ax)
    if args.title:
        ax.set_title(args.title)
    out_pdf = os.path.join(sub, f"venn_{la}_vs_{lb}.pdf")
    out_png = os.path.join(sub, f"venn_{la}_vs_{lb}.png")
    plt.tight_layout()
    plt.savefig(out_pdf, bbox_inches="tight")
    plt.savefig(out_png, bbox_inches="tight", dpi=300)
    print(f"[INFO] Venn → {out_pdf}")
    print(f"[INFO] only-A {n_only_a} | shared {n_shared} | only-B {n_only_b}")


if __name__ == "__main__":
    main()
