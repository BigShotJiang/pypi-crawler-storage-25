#!/usr/bin/env python3
"""
Publication-quality heatmap from deeptools .mat.gz files.

Usage:
    python plot_mat_heatmap.py \
        --input Peak.mat.gz \
        --output output_prefix \
        --title "H3K27ac" \
        --sample_labels "WT ATAC" "Y591* ATAC" \
        --group_labels "Increased" "Decreased" \
        --colormap Oranges \
        --vmax auto \
        --dpi 300
"""

import argparse
import gzip
import json
import sys

import matplotlib as mpl
import matplotlib.lines
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
import matplotlib.colors as mcolors
import numpy as np
from matplotlib.ticker import MaxNLocator

try:
    import seaborn as sns
    HAS_SEABORN = True
except ImportError:
    HAS_SEABORN = False

mpl.rcParams.update({
    "font.family": "Arial",
    "font.size": 10,
    "axes.linewidth": 1.2,
    "xtick.major.width": 1.2,
    "ytick.major.width": 1.2,
    "pdf.fonttype": 42,
    "ps.fonttype": 42,
})


def nice_ceil(value):
    """Round value up to a 'nice' number that scales with its magnitude.

    Avoids np.ceil collapsing small floats (e.g. 0.04 -> 1.0) which makes
    heatmap/profile color scales too wide and the signal invisible.
    """
    if value is None or not np.isfinite(value) or value <= 0:
        return 1.0
    exp = np.floor(np.log10(value))
    step = 10 ** exp
    return float(np.ceil(value / step) * step)


def resolve_colormap(name):
    """Resolve a colormap name. Supports matplotlib and seaborn palettes.

    For seaborn palettes, prefix with 'sns:' e.g. 'sns:rocket', 'sns:mako'.
    """
    if name.startswith("sns:") and HAS_SEABORN:
        palette_name = name[4:]
        return sns.color_palette(palette_name, as_cmap=True)
    return plt.get_cmap(name)


def resolve_profile_colors(colors, n_groups):
    """Resolve profile line colors.

    Accepts hex colors or a seaborn palette name prefixed with 'sns:'.
    e.g. --profile_colors "sns:Set2" or --profile_colors "#E24A33" "#348ABD"
    """
    if colors is None:
        default_colors = [
            "#E24A33", "#348ABD", "#56A968", "#8B6DAF",
            "#FFC857", "#E76F51", "#2A9D8F", "#264653",
        ]
        return default_colors[:n_groups]
    # single value starting with sns: => seaborn palette
    if len(colors) == 1 and colors[0].startswith("sns:") and HAS_SEABORN:
        palette_name = colors[0][4:]
        return [mcolors.to_hex(c) for c in sns.color_palette(palette_name, n_groups)]
    return colors[:n_groups]


# ── helpers ──────────────────────────────────────────────────
def load_matrix(mat_path):
    """Load deeptools computeMatrix .mat.gz file.

    Returns
    -------
    meta : dict   – header metadata
    data : ndarray – shape (n_regions, n_bins_total)  (NaN‑filled)
    """
    with gzip.open(mat_path, "rt") as fh:
        header = fh.readline().strip()
        meta = json.loads(header.lstrip("@"))
        rows = []
        for line in fh:
            if line.startswith("#"):
                continue
            parts = line.strip().split("\t")
            vals = [float(v) if v not in ("", "nan", "NA") else np.nan for v in parts[6:]]
            rows.append(vals)
    data = np.array(rows)
    # replace nan with 0 for cleaner visualisation
    data = np.nan_to_num(data, nan=0.0)
    return meta, data


def split_groups_samples(data, meta):
    """Split the flat data matrix into per‑(group, sample) sub‑matrices.

    Returns
    -------
    matrices : dict[(gi, si)] -> ndarray  (n_regions_in_group, n_bins)
    """
    gb = meta["group_boundaries"]
    sb = meta["sample_boundaries"]
    matrices = {}
    for gi in range(len(gb) - 1):
        row_start, row_end = gb[gi], gb[gi + 1]
        for si in range(len(sb) - 1):
            col_start, col_end = sb[si], sb[si + 1]
            matrices[(gi, si)] = data[row_start:row_end, col_start:col_end]
    return matrices


def compute_profile(mat):
    """Mean signal across regions (columns) – ignoring NaN."""
    return np.nanmean(mat, axis=0)


def make_xticks(n_bins, upstream, downstream, body=0):
    """Generate positions and labels for the x axis.

    For center mode (body==0): 3 ticks at [-upstream, 0, +downstream]
    For region mode (body>0):  4 ticks at [-upstream, TSS, TES, +downstream]
    """
    up_kb = upstream / 1000
    dn_kb = downstream / 1000
    if body > 0:
        # region mode: upstream_bins | body_bins | downstream_bins
        bin_size = (upstream + body + downstream) / n_bins
        up_bins = int(upstream / bin_size)
        body_bins = int(body / bin_size)
        positions = [0, up_bins, up_bins + body_bins, n_bins - 1]
        labels = [f"-{up_kb:.0f}", "S", "E", f"+{dn_kb:.0f}"]
    else:
        # center mode
        mid = n_bins // 2
        positions = [0, mid, n_bins - 1]
        labels = [f"-{up_kb:.0f}", "0", f"+{dn_kb:.0f}"]
    return positions, labels


# ── main plotting ────────────────────────────────────────────
def plot_heatmap(
    mat_path,
    output_prefix,
    title=None,
    sample_labels=None,
    group_labels=None,
    colormap="Oranges",
    vmin=None,
    vmax=None,
    profile_colors=None,
    dpi=300,
    fig_width=None,
    sort_order="descending",
):
    meta, data = load_matrix(mat_path)

    n_groups = len(meta["group_boundaries"]) - 1
    n_samples = len(meta["sample_boundaries"]) - 1
    gb = meta["group_boundaries"]
    sb = meta["sample_boundaries"]

    if sample_labels is None:
        sample_labels = meta["sample_labels"]
    if group_labels is None:
        group_labels = meta["group_labels"]

    # bins per sample
    n_bins = sb[1] - sb[0]
    upstream = meta["upstream"][0]
    downstream = meta["downstream"][0]
    body = meta["body"][0]

    matrices = split_groups_samples(data, meta)

    # ── compute profile max (used for both y-axis and heatmap) ─
    tmp_matrices = split_groups_samples(data, meta)
    profile_ymax = 0.0
    for si in range(n_samples):
        for gi in range(n_groups):
            p = compute_profile(tmp_matrices[(gi, si)])
            profile_ymax = max(profile_ymax, float(np.nanmax(p)))
    # round up to a nice number (magnitude-aware so small values aren't
    # blown up to 1.0 by np.ceil)
    profile_ymax = nice_ceil(profile_ymax)

    # ── colour limits ────────────────────────────────────────
    if vmax is None or vmax == "auto":
        # use profile max so heatmap and profile share the same scale
        vmax = profile_ymax
    else:
        vmax = float(vmax)
    if vmin is None:
        vmin = 0.0
    else:
        vmin = float(vmin)

    # ── sort each group by mean signal (descending) ──────────
    for gi in range(n_groups):
        # gather row‑wise mean across ALL samples for this group
        row_means = np.zeros(gb[gi + 1] - gb[gi])
        for si in range(n_samples):
            row_means += np.nanmean(matrices[(gi, si)], axis=1)
        if sort_order == "descending":
            order = np.argsort(-row_means)
        elif sort_order == "ascending":
            order = np.argsort(row_means)
        else:
            order = np.arange(len(row_means))
        for si in range(n_samples):
            matrices[(gi, si)] = matrices[(gi, si)][order]

    # ── profile colours ──────────────────────────────────────
    profile_colors = resolve_profile_colors(profile_colors, n_groups)

    # ── figure layout ────────────────────────────────────────
    # Each sample column width (narrower); profile is square
    col_w = 1.2 if fig_width is None else fig_width / n_samples
    profile_h = col_w  # square profile
    cbar_w = 0.25
    left_margin = 0.55
    right_margin = 0.25
    inner_gap = 0.15  # small gap between sample columns
    total_w = left_margin + col_w * n_samples + inner_gap * (n_samples - 1) + right_margin + cbar_w

    # Height: profile + sum of group heatmaps
    group_counts = [gb[gi + 1] - gb[gi] for gi in range(n_groups)]
    total_regions = sum(group_counts)
    heatmap_total_h = 5.0  # total heatmap height
    group_heights = [heatmap_total_h * (gc / total_regions) for gc in group_counts]
    # minimum height 0.8
    group_heights = [max(h, 0.8) for h in group_heights]
    heatmap_total_h = sum(group_heights)
    legend_h = 0.55  # space for bottom legend
    total_h = profile_h + heatmap_total_h + 3.0 + legend_h

    fig = plt.figure(figsize=(total_w, total_h))

    # Calculate fractional margins
    l_frac = left_margin / total_w
    r_frac = 1.0 - (right_margin + cbar_w) / total_w

    # Outer grid: profile row | heatmap rows (one per group)
    height_ratios = [profile_h] + group_heights
    # wspace as fraction of column width
    ws_frac = inner_gap / col_w
    outer = gridspec.GridSpec(
        1 + n_groups,
        1,
        figure=fig,
        height_ratios=height_ratios,
        hspace=0.05,
        left=l_frac,
        right=r_frac,
        top=0.88,
        bottom=0.12 + legend_h / total_h,
    )

    # ── x‑ticks ─────────────────────────────────────────────
    xtick_pos, xtick_lab = make_xticks(n_bins, upstream, downstream, body=body)

    cmap = resolve_colormap(colormap)
    norm = mcolors.Normalize(vmin=vmin, vmax=vmax)

    # ── profile row ──────────────────────────────────────────
    profile_gs = gridspec.GridSpecFromSubplotSpec(
        1, n_samples, subplot_spec=outer[0], wspace=ws_frac
    )

    x = np.arange(n_bins)
    profile_axes = []
    for si in range(n_samples):
        ax = fig.add_subplot(profile_gs[0, si])
        profile_axes.append(ax)
        for gi in range(n_groups):
            profile = compute_profile(matrices[(gi, si)])
            ax.plot(x, profile, color=profile_colors[gi], linewidth=1.8,
                    label=group_labels[gi])
        ax.set_xlim(0, n_bins - 1)
        ax.set_ylim(0, profile_ymax)
        ax.set_xticks(xtick_pos)
        ax.set_xticklabels([])  # no x labels on profile
        ax.set_ylabel("")
        ax.yaxis.set_major_locator(MaxNLocator(nbins=3, integer=False))
        # only show Y-axis tick labels on the first (leftmost) sample
        if si > 0:
            ax.set_yticklabels([])
        ax.tick_params(labelsize=13)
        # keep all 4 borders
        for spine in ax.spines.values():
            spine.set_visible(True)
            spine.set_edgecolor("black")
            spine.set_linewidth(1.5)
        ax.set_title(sample_labels[si], fontsize=14, fontweight="bold", pad=8)
        # dashed vertical lines at reference points
        if body > 0:
            # region mode: mark TSS and TES
            bin_size = (upstream + body + downstream) / n_bins
            tss_bin = int(upstream / bin_size)
            tes_bin = tss_bin + int(body / bin_size)
            ax.axvline(tss_bin, color="grey", ls="--", lw=0.7, alpha=0.6)
            ax.axvline(tes_bin, color="grey", ls="--", lw=0.7, alpha=0.6)
        else:
            ax.axvline(n_bins // 2, color="grey", ls="--", lw=0.7, alpha=0.6)
        # force square aspect for profile
        ax.set_aspect("auto")
        ax.set_box_aspect(1.0)

    # ── build G-labels ───────────────────────────────────────
    g_labels_short = [f"G{gi+1}" for gi in range(n_groups)]

    # ── heatmap rows ─────────────────────────────────────────
    for gi in range(n_groups):
        heat_gs = gridspec.GridSpecFromSubplotSpec(
            1, n_samples, subplot_spec=outer[1 + gi], wspace=ws_frac
        )
        for si in range(n_samples):
            ax = fig.add_subplot(heat_gs[0, si])
            mat = matrices[(gi, si)]
            ax.imshow(
                mat,
                aspect="auto",
                cmap=cmap,
                norm=norm,
                interpolation="bilinear",
                origin="upper",
            )
            # border
            for spine in ax.spines.values():
                spine.set_edgecolor("black")
                spine.set_linewidth(1.5)

            ax.set_xticks(xtick_pos)
            # only show x tick labels on last group
            if gi == n_groups - 1:
                labels = ax.set_xticklabels(xtick_lab, fontsize=13)
                # shift first tick label right, last tick label left
                labels[0].set_ha("left")
                labels[-1].set_ha("right")
            else:
                ax.set_xticklabels([])

            ax.set_yticks([])
            ax.tick_params(labelsize=13, length=0 if gi < n_groups - 1 else 4)
            # group label on leftmost column: use G1, G2, ...
            if si == 0:
                ax.set_ylabel(
                    g_labels_short[gi],
                    fontsize=14,
                    fontweight="bold",
                    rotation=0,
                    labelpad=25,
                    va="center",
                )

    # ── shared x-axis label (centered across all samples) ───
    # position just below the heatmap x tick labels
    bottom_frac = 0.12 + legend_h / total_h
    xlabel_y = bottom_frac - 0.04
    fig.text(
        (l_frac + r_frac) / 2, xlabel_y,
        "Distance (kb)", ha="center", va="top", fontsize=14,
    )

    # ── horizontal colour bar (below x-label, above legend) ─
    cbar_w_frac = (r_frac - l_frac) * 0.30
    cbar_x = (l_frac + r_frac) / 2 - cbar_w_frac / 2
    cbar_y = xlabel_y - 0.07
    cbar_ax = fig.add_axes([cbar_x, cbar_y, cbar_w_frac, 0.012])
    sm = plt.cm.ScalarMappable(cmap=cmap, norm=norm)
    sm.set_array([])
    cbar = fig.colorbar(sm, cax=cbar_ax, orientation="horizontal")
    cbar.ax.tick_params(labelsize=10)
    cbar.outline.set_linewidth(1.0)

    # ── legend at the bottom ─────────────────────────────────
    # Show G1: label (n=count), G2: label (n=count), ...
    handles = []
    for gi in range(n_groups):
        n_reg = gb[gi + 1] - gb[gi]
        handles.append(
            mpl.lines.Line2D([0], [0], color=profile_colors[gi], lw=2.5,
                             label=f"G{gi+1}: {group_labels[gi]} (n={n_reg:,})")
        )
    fig.legend(
        handles=handles,
        loc="lower center",
        ncol=min(n_groups, 4),
        fontsize=12,
        frameon=False,
        handlelength=1.5,
        handletextpad=0.5,
        columnspacing=1.5,
        bbox_to_anchor=(0.5, -0.01),
    )

    # ── super‑title ──────────────────────────────────────────
    if title:
        fig.suptitle(title, fontsize=15, fontweight="bold", y=0.96)

    # ── save ─────────────────────────────────────────────────
    for ext in ("pdf", "png"):
        out = f"{output_prefix}.{ext}"
        fig.savefig(out, dpi=dpi, bbox_inches="tight")
        print(f"Saved {out}")
    plt.close(fig)


# ── default colormaps for sample groups ──────────────────────
DEFAULT_GROUP_CMAPS = ["Oranges", "Blues", "Greens", "Purples", "Reds", "Greys"]


def plot_heatmap_grouped(
    mat_path,
    output_prefix,
    sample_groups,
    title=None,
    sample_labels=None,
    group_labels=None,
    group_colormaps=None,
    profile_colors=None,
    dpi=300,
    sort_order="descending",
):
    """Publication-quality heatmap with samples organized into visual panels.

    Each panel (sample group) gets its own colormap, color scale, and colorbar.

    Parameters
    ----------
    sample_groups : dict
        Ordered dict mapping group_name -> list of 0-based sample indices.
        E.g. {"ATAC": [0, 1], "H2AK119ub": [2, 3]}
    group_colormaps : list[str] or None
        Colormap per sample group. Defaults to DEFAULT_GROUP_CMAPS.
    """
    meta, data = load_matrix(mat_path)
    n_rg = len(meta["group_boundaries"]) - 1
    n_samples_total = len(meta["sample_boundaries"]) - 1
    gb = meta["group_boundaries"]
    sb = meta["sample_boundaries"]

    if sample_labels is None:
        sample_labels = meta["sample_labels"]
    if group_labels is None:
        group_labels = meta["group_labels"]

    n_bins = sb[1] - sb[0]
    upstream = meta["upstream"][0]
    downstream = meta["downstream"][0]
    body = meta["body"][0]

    matrices = split_groups_samples(data, meta)

    # sort each region group by mean signal across ALL samples
    for gi in range(n_rg):
        row_means = np.zeros(gb[gi + 1] - gb[gi])
        for si in range(n_samples_total):
            row_means += np.nanmean(matrices[(gi, si)], axis=1)
        if sort_order == "descending":
            order = np.argsort(-row_means)
        elif sort_order == "ascending":
            order = np.argsort(row_means)
        else:
            order = np.arange(len(row_means))
        for si in range(n_samples_total):
            matrices[(gi, si)] = matrices[(gi, si)][order]

    profile_colors = resolve_profile_colors(profile_colors, n_rg)

    # ── sample group info ────────────────────────────────────
    sg_names = list(sample_groups.keys())
    n_sg = len(sg_names)
    sg_indices = [sample_groups[name] for name in sg_names]
    sg_sizes = [len(idx) for idx in sg_indices]

    if group_colormaps is None:
        group_colormaps = [DEFAULT_GROUP_CMAPS[i % len(DEFAULT_GROUP_CMAPS)]
                           for i in range(n_sg)]

    # per-group profile ymax (also used as heatmap vmax)
    sg_ymax = []
    for sgi, si_list in enumerate(sg_indices):
        ymax = 0.0
        for si in si_list:
            for gi in range(n_rg):
                p = compute_profile(matrices[(gi, si)])
                ymax = max(ymax, float(np.nanmax(p)))
        sg_ymax.append(nice_ceil(ymax))

    xtick_pos, xtick_lab = make_xticks(n_bins, upstream, downstream, body=body)

    # ── figure dimensions ────────────────────────────────────
    col_w = 1.2
    inner_gap = 0.15
    group_gap_w = 0.5
    left_margin = 0.55
    right_margin = 0.25

    sg_widths = [col_w * k + inner_gap * max(k - 1, 0) for k in sg_sizes]
    total_w = (left_margin + sum(sg_widths)
               + group_gap_w * (n_sg - 1) + right_margin)

    profile_h = col_w
    group_counts = [gb[gi + 1] - gb[gi] for gi in range(n_rg)]
    total_regions = sum(group_counts)
    heatmap_total_h = 5.0
    region_heights = [max(heatmap_total_h * (gc / total_regions), 0.8)
                      for gc in group_counts]
    heatmap_total_h = sum(region_heights)
    legend_h = 0.55
    total_h = profile_h + heatmap_total_h + 3.5 + legend_h

    fig = plt.figure(figsize=(total_w, total_h))

    l_frac = left_margin / total_w
    r_frac = 1.0 - right_margin / total_w

    height_ratios = [profile_h] + region_heights
    ws_sg = group_gap_w / np.mean(sg_widths) if np.mean(sg_widths) > 0 else 0.3

    outer = gridspec.GridSpec(
        1 + n_rg, n_sg,
        figure=fig,
        height_ratios=height_ratios,
        width_ratios=sg_widths,
        hspace=0.05,
        wspace=ws_sg,
        left=l_frac, right=r_frac,
        top=0.88,
        bottom=0.15 + legend_h / total_h,
    )

    cmaps = [resolve_colormap(c) for c in group_colormaps]
    norms = [mcolors.Normalize(vmin=0.0, vmax=sg_ymax[sgi])
             for sgi in range(n_sg)]

    # ── plot each sample group ───────────────────────────────
    g_labels_short = [f"G{gi+1}" for gi in range(n_rg)]

    for sgi in range(n_sg):
        si_list = sg_indices[sgi]
        k = len(si_list)
        cmap = cmaps[sgi]
        norm = norms[sgi]
        ws_inner = inner_gap / col_w

        # ── profiles ─────────────────────────────────────────
        prof_gs = gridspec.GridSpecFromSubplotSpec(
            1, k, subplot_spec=outer[0, sgi], wspace=ws_inner)
        for j, si in enumerate(si_list):
            ax = fig.add_subplot(prof_gs[0, j])
            for gi in range(n_rg):
                profile = compute_profile(matrices[(gi, si)])
                ax.plot(np.arange(n_bins), profile,
                        color=profile_colors[gi], linewidth=1.8)
            ax.set_xlim(0, n_bins - 1)
            ax.set_ylim(0, sg_ymax[sgi])
            ax.set_xticks(xtick_pos)
            ax.set_xticklabels([])
            ax.yaxis.set_major_locator(MaxNLocator(nbins=3, integer=False))
            if j > 0:
                ax.set_yticklabels([])
            ax.tick_params(labelsize=11)
            for spine in ax.spines.values():
                spine.set_visible(True)
                spine.set_edgecolor("black")
                spine.set_linewidth(1.5)
            ax.set_title(sample_labels[si], fontsize=11,
                         fontweight="bold", pad=8)
            if body > 0:
                bin_sz = (upstream + body + downstream) / n_bins
                tss = int(upstream / bin_sz)
                tes = tss + int(body / bin_sz)
                ax.axvline(tss, color="grey", ls="--", lw=0.7, alpha=0.6)
                ax.axvline(tes, color="grey", ls="--", lw=0.7, alpha=0.6)
            else:
                ax.axvline(n_bins // 2, color="grey", ls="--",
                           lw=0.7, alpha=0.6)
            ax.set_box_aspect(1.0)

        # ── heatmaps ─────────────────────────────────────────
        for gi in range(n_rg):
            heat_gs = gridspec.GridSpecFromSubplotSpec(
                1, k, subplot_spec=outer[1 + gi, sgi], wspace=ws_inner)
            for j, si in enumerate(si_list):
                ax = fig.add_subplot(heat_gs[0, j])
                ax.imshow(matrices[(gi, si)], aspect="auto", cmap=cmap,
                          norm=norm, interpolation="bilinear",
                          origin="upper")
                for spine in ax.spines.values():
                    spine.set_edgecolor("black")
                    spine.set_linewidth(1.5)
                ax.set_xticks(xtick_pos)
                if gi == n_rg - 1:
                    xlabels = ax.set_xticklabels(xtick_lab, fontsize=11)
                    xlabels[0].set_ha("left")
                    xlabels[-1].set_ha("right")
                else:
                    ax.set_xticklabels([])
                ax.set_yticks([])
                ax.tick_params(labelsize=11,
                               length=0 if gi < n_rg - 1 else 4)
                if sgi == 0 and j == 0:
                    ax.set_ylabel(
                        g_labels_short[gi], fontsize=14,
                        fontweight="bold", rotation=0,
                        labelpad=25, va="center")

    # ── x-axis label ─────────────────────────────────────────
    bottom_frac = 0.15 + legend_h / total_h
    xlabel_y = bottom_frac - 0.04
    fig.text((l_frac + r_frac) / 2, xlabel_y, "Distance (kb)",
             ha="center", va="top", fontsize=14)

    # ── per-group colorbars + group name ─────────────────────
    cbar_y = xlabel_y - 0.07
    for sgi in range(n_sg):
        pos = outer[n_rg, sgi].get_position(fig)
        sg_center = (pos.x0 + pos.x1) / 2
        cbar_w_frac = (pos.x1 - pos.x0) * 0.6
        cbar_x = sg_center - cbar_w_frac / 2

        cbar_ax = fig.add_axes([cbar_x, cbar_y, cbar_w_frac, 0.012])
        sm = plt.cm.ScalarMappable(cmap=cmaps[sgi], norm=norms[sgi])
        sm.set_array([])
        cbar = fig.colorbar(sm, cax=cbar_ax, orientation="horizontal")
        cbar.ax.tick_params(labelsize=9)
        cbar.outline.set_linewidth(1.0)
        fig.text(sg_center, cbar_y - 0.03, sg_names[sgi],
                 ha="center", va="top", fontsize=11, fontweight="bold")

    # ── legend ───────────────────────────────────────────────
    handles = []
    for gi in range(n_rg):
        n_reg = gb[gi + 1] - gb[gi]
        handles.append(
            mpl.lines.Line2D(
                [0], [0], color=profile_colors[gi], lw=2.5,
                label=f"G{gi+1}: {group_labels[gi]} (n={n_reg:,})"))
    fig.legend(
        handles=handles, loc="lower center",
        ncol=min(n_rg, 4), fontsize=12, frameon=False,
        handlelength=1.5, handletextpad=0.5, columnspacing=1.5,
        bbox_to_anchor=(0.5, -0.01))

    if title:
        fig.suptitle(title, fontsize=15, fontweight="bold", y=0.96)

    for ext in ("pdf", "png"):
        out = f"{output_prefix}.{ext}"
        fig.savefig(out, dpi=dpi, bbox_inches="tight")
        print(f"Saved {out}")
    plt.close(fig)


# ── CLI ──────────────────────────────────────────────────────
def parse_args():
    p = argparse.ArgumentParser(
        description="Publication‑quality heatmap from deeptools .mat.gz"
    )
    p.add_argument("--input", "-i", required=True, help=".mat.gz file")
    p.add_argument("--output", "-o", required=True, help="Output prefix (no extension)")
    p.add_argument("--title", "-t", default=None, help="Figure title")
    p.add_argument("--sample_labels", nargs="+", default=None,
                   help="Override sample labels")
    p.add_argument("--group_labels", nargs="+", default=None,
                   help="Override group/region labels")
    p.add_argument("--colormap", default="Oranges",
                   help="Matplotlib/seaborn colormap (prefix 'sns:' for seaborn, e.g. sns:rocket)")
    p.add_argument("--vmin", type=float, default=None, help="Heatmap color min")
    p.add_argument("--vmax", default=None,
                   help="Heatmap color max ('auto' or float)")
    p.add_argument("--profile_colors", nargs="+", default=None,
                   help="Colors for profile lines (hex per group, or 'sns:palette_name')")
    p.add_argument("--dpi", type=int, default=300)
    p.add_argument("--fig_width", type=float, default=None,
                   help="Total figure width in inches")
    p.add_argument("--sort", choices=["descending", "ascending", "keep"],
                   default="descending", help="Sort regions within groups")
    return p.parse_args()


if __name__ == "__main__":
    args = parse_args()
    try:
        vmax_val = float(args.vmax) if args.vmax and args.vmax != "auto" else args.vmax
    except ValueError:
        vmax_val = args.vmax

    plot_heatmap(
        mat_path=args.input,
        output_prefix=args.output,
        title=args.title,
        sample_labels=args.sample_labels,
        group_labels=args.group_labels,
        colormap=args.colormap,
        vmin=args.vmin,
        vmax=vmax_val,
        profile_colors=args.profile_colors,
        dpi=args.dpi,
        fig_width=args.fig_width,
        sort_order=args.sort,
    )
