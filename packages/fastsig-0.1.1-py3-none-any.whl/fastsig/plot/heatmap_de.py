#!/usr/bin/env python3
"""
Integrated pipeline: BED regions → Venn / EXP / DE / raw heatmap + boxplot.

Methods (--method):
    raw       : use --beds directly as region groups for heatmap + boxplot
    intersect : Venn diagram between exactly 2 BED files
    exp       : extract EXP_LABEL categories from --de_tsv → heatmap + boxplot
    de        : extract DE_LABEL categories from --de_tsv → heatmap + boxplot

Usage:
    python pipeline_de_heatmap.py \\
        --beds WT_merge.bed Y591_merge.bed \\
        --labels WT Y591 \\
        --method raw intersect de exp \\
        --de_tsv /path/to/de_merged.tsv \\
        --bigwig WT_ATAC.bw Y591_ATAC.bw \\
        --samples "WT ATAC" "Y591* ATAC" \\
        --mode center --output_path ./output --threads 36
"""

import argparse
import logging
import os
import subprocess
import sys
from datetime import datetime

import pandas as pd


# ─────────────────────────────────────────────────────────────
# Step 0: Parse DESeq2 TSV and extract BED files
# ─────────────────────────────────────────────────────────────
def find_label_columns(columns):
    """Auto-detect EXP_LABEL and DE_LABEL columns from TSV header.

    Returns
    -------
    exp_cols : list of (col_name, display_prefix)
        e.g. [("DOT1L_Y591_siCtrl_EXP_LABEL", "Y591"),
              ("DOT1L_WT_siCtrl_EXP_LABEL",   "WT")]
    de_col   : str or None
    """
    exp_cols = []
    de_col = None
    for c in columns:
        if c == "DE_LABEL":
            de_col = c
        elif c.endswith("_EXP_LABEL"):
            # Extract a short prefix: strip trailing _EXP_LABEL
            prefix = c.replace("_EXP_LABEL", "")
            # Further shorten: take last meaningful token(s)
            # e.g. "DOT1L_Y591_siCtrl" -> keep as-is for uniqueness
            exp_cols.append((c, prefix))
    return exp_cols, de_col


EXP_VALUES = ["High", "Medium", "Low"]  # skip "Non Exp"
DE_VALUES_MAP = {"Up": "Increased", "Down": "Decreased"}  # skip "NS"


def format_label(label: str) -> str:
    """Sanitise a label for use in file/directory names (mirrors plot_intersect_venn.py)."""
    for ch in ['\n', '\\n', '(', ')', ']', '[', ' ', '/', '\\',
               ':', '*', '?', '"', '<', '>', '|', '&']:
        label = label.replace(ch, '_')
    return label


def extract_beds(de_tsv, output_dir):
    """Read DESeq2 merged TSV and extract BED files per label category.

    Returns
    -------
    exp_beds : dict[prefix] -> dict[label] -> bed_path
    de_beds  : dict[label] -> bed_path  (keyed by display names like "Increased")
    """
    df = pd.read_csv(de_tsv, sep="\t")
    # Drop rows with missing coordinates, then ensure integers (avoid 8187040.0)
    df = df.dropna(subset=["chr", "start", "end"])
    df["start"] = df["start"].astype(int)
    df["end"] = df["end"].astype(int)
    exp_cols, de_col = find_label_columns(df.columns.tolist())

    os.makedirs(output_dir, exist_ok=True)

    # --- EXP_LABEL beds ---
    exp_beds = {}
    for col_name, prefix in exp_cols:
        exp_beds[prefix] = {}
        for val in EXP_VALUES:
            sub = df.loc[df[col_name] == val, ["chr", "start", "end"]]
            bed_path = os.path.join(output_dir, f"{prefix}_EXP_{val}.bed")
            sub.to_csv(bed_path, sep="\t", header=False, index=False)
            exp_beds[prefix][val] = bed_path
            logging.info(f"  {prefix} EXP {val}: {len(sub):,} regions -> {bed_path}")

    # --- DE_LABEL beds ---
    de_beds = {}
    if de_col:
        for raw_val, display in DE_VALUES_MAP.items():
            sub = df.loc[df[de_col] == raw_val, ["chr", "start", "end"]]
            bed_path = os.path.join(output_dir, f"DE_{raw_val}.bed")
            sub.to_csv(bed_path, sep="\t", header=False, index=False)
            de_beds[display] = bed_path
            logging.info(f"  DE {raw_val} ({display}): {len(sub):,} regions -> {bed_path}")

    return exp_beds, de_beds


# ─────────────────────────────────────────────────────────────
# Step: Venn diagram (exactly 2 beds)
# ─────────────────────────────────────────────────────────────
def run_venn(beds, labels, output_path, title):
    """Run plot_intersect_venn.py on exactly 2 BED files."""
    if len(beds) != 2:
        logging.warning("intersect requires exactly 2 --beds; skipping "
                        f"(got {len(beds)})")
        return
    venn_dir = os.path.join(output_path, "intersect")
    os.makedirs(venn_dir, exist_ok=True)
    cmd = [
        "plot_intersect_venn.py",
        "-a", beds[0],
        "-b", beds[1],
        "--labels", labels[0], labels[1],
        "--output_path", venn_dir,
        "--title", title,
    ]
    logging.info(f"Venn diagram: {labels[0]} vs {labels[1]}")
    logging.info(f"[CMD] {' '.join(cmd)}")
    subprocess.run(cmd, check=True)


# ─────────────────────────────────────────────────────────────
# Step 2 & 3: Heatmap + Boxplot (calls plot_heatmap_box.py)
# ─────────────────────────────────────────────────────────────
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))


def run_heatmap_box(mode, bed_files, region_labels, bigwigs, sample_labels,
                    groups, output_path, base_name, title, threads,
                    species="hg38", stat_pairs=None, stat_test="Mann-Whitney",
                    group_colormaps=None,
                    sort="descending", colormap="Oranges", palette="orange",
                    ylabel="Signal", matrix_engine="python", rust_bin=None):
    """Run plot_heatmap_box.py as subprocess."""
    heatmap_box_script = os.path.join(SCRIPT_DIR, "plot_heatmap_box.py")
    cmd = [
        sys.executable, heatmap_box_script, mode,
        "--input_bed", *bed_files,
        "--input_bigwig", *bigwigs,
        "--regions", *region_labels,
        "--samples", *sample_labels,
        "--base_name", base_name,
        "--output_path", output_path,
        "--threads", str(threads),
        "--sort", sort,
        "--colormap", colormap,
        "--palette", palette,
        "--ylabel", ylabel,
        "--matrix_engine", matrix_engine,
        "--stat_test", stat_test,
    ]
    if rust_bin:
        cmd += ["--rust_bin", rust_bin]
    if title:
        cmd += ["--title", title]
    if groups:
        cmd += ["--groups", *groups]
    if group_colormaps:
        cmd += ["--group_colormaps", *group_colormaps]
    if stat_pairs:
        cmd += ["--stat_pairs", *stat_pairs]
    if mode == "gene":
        cmd += ["--species", species]

    logging.info(f"[CMD] {' '.join(cmd)}")
    subprocess.run(cmd, check=True)


# ─────────────────────────────────────────────────────────────
# Logging setup
# ─────────────────────────────────────────────────────────────
def setup_logging(output_path):
    """Configure logging to both console and a log file."""
    os.makedirs(output_path, exist_ok=True)
    log_file = os.path.join(output_path, "pipeline.log")

    fmt = "%(asctime)s [%(levelname)s] %(message)s"
    datefmt = "%Y-%m-%d %H:%M:%S"

    root = logging.getLogger()
    root.setLevel(logging.INFO)
    # clear existing handlers
    root.handlers.clear()

    # console
    ch = logging.StreamHandler(sys.stdout)
    ch.setFormatter(logging.Formatter(fmt, datefmt=datefmt))
    root.addHandler(ch)

    # file
    fh = logging.FileHandler(log_file, mode="w")
    fh.setFormatter(logging.Formatter(fmt, datefmt=datefmt))
    root.addHandler(fh)

    logging.info(f"Log file: {log_file}")
    return log_file


# ─────────────────────────────────────────────────────────────
# Main
# ─────────────────────────────────────────────────────────────
def main():
    p = argparse.ArgumentParser(
        description="Integrated pipeline: BED → Venn / EXP / DE / raw heatmap + boxplot",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )

    # ── input ────────────────────────────────────────────────
    p.add_argument("--beds", nargs="+", required=True,
                   help="Input BED file(s) (1 or more)")
    p.add_argument("--labels", nargs="+", required=True,
                   help="Labels for --beds (same count, same order)")
    p.add_argument("--de_tsv", default=None,
                   help="DESeq2 merged TSV (required for exp/de methods)")

    # ── method selection ─────────────────────────────────────
    p.add_argument("--method", nargs="+",
                   choices=["raw", "intersect", "exp", "de"],
                   default=["raw"],
                   help="Methods to run (default: raw). "
                        "raw: use --beds directly; "
                        "intersect: Venn diagram (needs 2 beds); "
                        "exp: EXP_LABEL heatmaps; "
                        "de: DE_LABEL heatmaps")

    # ── bigwig / sample definition ───────────────────────────
    p.add_argument("--bigwig", nargs="+", required=True,
                   help="Bigwig files (same order as --samples)")
    p.add_argument("--samples", nargs="+", required=True,
                   help="Display sample labels (e.g. 'WT ATAC' 'Y591* ATAC')")
    p.add_argument("--groups", nargs="+", default=None,
                   help="Sample group labels, one per bigwig "
                        "(e.g. ATAC ATAC H2AK119ub H2AK119ub)")
    p.add_argument("--group_colormaps", nargs="+", default=None,
                   help="Colormap per sample group "
                        "(default: Oranges Blues Greens Purples ...)")

    # ── mode ─────────────────────────────────────────────────
    p.add_argument("--mode", choices=["center", "region", "gene"],
                   default="center",
                   help="center: reference-point at peak center; "
                        "region: scale-regions; "
                        "gene: intersect with gene BED then scale-regions")
    p.add_argument("--species", default="hg38",
                   help="Species for gene mode (hg38/mm10)")

    # ── output ───────────────────────────────────────────────
    p.add_argument("--output_path", required=True,
                   help="Top-level output directory")
    p.add_argument("--sample_name", default=None,
                   help="Short name for this comparison "
                        "(defaults to first two labels joined by ' vs ')")
    p.add_argument("--threads", type=int, default=24)

    # ── matrix engine ────────────────────────────────────────
    p.add_argument("--matrix_engine", choices=["python", "rust", "both"],
                   default="python",
                   help="computeMatrix engine. 'both' runs python and rust "
                        "into sibling output dirs <output_path>_python and "
                        "<output_path>_rust for direct comparison.")
    p.add_argument("--rust_bin", default=None,
                   help="Path to Rust compute_matrix binary "
                        "(default: $RUST_COMPUTE_MATRIX or 'compute_matrix' on PATH)")

    # ── heatmap / boxplot tuning ─────────────────────────────
    p.add_argument("--sort", default="descending",
                   choices=["descending", "ascending", "keep"])
    p.add_argument("--colormap", default="Oranges")
    p.add_argument("--palette", default="orange")
    p.add_argument("--stat_pairs", nargs="+", default=None,
                   help="Stat comparison pairs for boxplot (e.g. 'Increased:Decreased')")
    p.add_argument("--stat_test", default="Mann-Whitney",
                   choices=["Mann-Whitney", "t-test_ind", "t-test_welch",
                            "Wilcoxon", "Brunner-Munzel", "Levene", "Kruskal"],
                   help="Statistical test for boxplot annotations "
                        "(default: Mann-Whitney; rank-based, robust to outliers).")

    args = p.parse_args()

    # ── validation ───────────────────────────────────────────
    if len(args.beds) != len(args.labels):
        p.error(f"--beds ({len(args.beds)}) and --labels ({len(args.labels)}) "
                "must have the same count")
    if ("exp" in args.method or "de" in args.method) and args.de_tsv is None:
        p.error("--de_tsv is required when using method 'exp' or 'de'")

    methods = set(args.method)
    sample_name = args.sample_name or " vs ".join(args.labels[:2])
    safe_name = sample_name.replace(" ", "_")

    # Resolve which engines to run for heatmap/boxplot.
    if args.matrix_engine == "both":
        engines = ["python", "rust"]
    else:
        engines = [args.matrix_engine]

    def hb(out_dir, **kw):
        """Run heatmap+boxplot once per requested engine; suffix out_dir by engine
        when multiple engines are requested so the comparison artifacts coexist."""
        kw.setdefault("stat_test", args.stat_test)
        for eng in engines:
            target = (out_dir + f"_{eng}") if len(engines) > 1 else out_dir
            run_heatmap_box(output_path=target, matrix_engine=eng,
                            rust_bin=args.rust_bin, **kw)

    # ── logging ──────────────────────────────────────────────
    setup_logging(args.output_path)
    logging.info(f"Pipeline started: {datetime.now()}")
    logging.info(f"Methods: {args.method}")
    logging.info(f"Beds: {args.beds}")
    logging.info(f"Labels: {args.labels}")
    logging.info(f"Sample name: {sample_name}")

    # ── method: intersect ────────────────────────────────────
    if "intersect" in methods:
        logging.info("=" * 60)
        logging.info("[METHOD intersect] Venn diagram + heatmap + boxplot")
        logging.info("=" * 60)

        # Separate "random" (control) beds from real beds for venn
        real_beds, real_labels = [], []
        ctrl_beds, ctrl_labels = [], []
        for b, l in zip(args.beds, args.labels):
            if l.lower() == "random":
                ctrl_beds.append(b)
                ctrl_labels.append(l)
            else:
                real_beds.append(b)
                real_labels.append(l)

        if ctrl_beds:
            logging.info(f"Intersect: skipping control beds for Venn: {ctrl_labels}")

        run_venn(
            beds=real_beds,
            labels=real_labels,
            output_path=args.output_path,
            title=sample_name,
        )

        # Locate the 3 BED files produced by plot_intersect_venn.py
        if len(real_labels) >= 2:
            la, lb = format_label(real_labels[0]), format_label(real_labels[1])
            venn_bed_dir = os.path.join(
                args.output_path, "intersect", f"{la}_vs_{lb}", "bed"
            )
            bed_a_only = os.path.join(venn_bed_dir, f"10_only_{la}.bed")
            bed_b_only = os.path.join(venn_bed_dir, f"01_only_{lb}.bed")
            bed_shared = os.path.join(venn_bed_dir, f"11_{la}_vs_{lb}.bed")

            if all(os.path.isfile(f) for f in [bed_a_only, bed_b_only, bed_shared]):
                isect_beds = [bed_a_only, bed_shared, bed_b_only]
                isect_labels = [
                    f"{real_labels[0]} only",
                    "Shared",
                    f"{real_labels[1]} only",
                ]
                isect_stat_pairs = [
                    f"{isect_labels[0]}:{isect_labels[1]}",
                    f"{isect_labels[1]}:{isect_labels[2]}",
                ]

                # Append control beds (e.g. random) at the end
                if ctrl_beds:
                    isect_beds.extend(ctrl_beds)
                    isect_labels.extend(ctrl_labels)

                base = f"ISECT_{safe_name}"
                out_dir = os.path.join(args.output_path, "intersect_heatmap", base)
                logging.info(f"Intersect heatmap: {isect_labels}")
                hb(
                    out_dir,
                    mode=args.mode,
                    bed_files=isect_beds,
                    region_labels=isect_labels,
                    bigwigs=args.bigwig,
                    sample_labels=args.samples,
                    groups=args.groups,
                    base_name=base,
                    title=f"{sample_name} Intersect",
                    threads=args.threads,
                    species=args.species,
                    stat_pairs=isect_stat_pairs,
                    group_colormaps=args.group_colormaps,
                    sort=args.sort,
                    colormap=args.colormap,
                    palette=args.palette,
                    ylabel="Signal",
                )
            else:
                logging.warning("Venn BED files not found, skipping intersect heatmap")

    # ── method: exp ──────────────────────────────────────────
    if "exp" in methods:
        bed_dir = os.path.join(args.output_path, "extracted_bed")
        logging.info("=" * 60)
        logging.info(f"[METHOD exp] Extracting EXP_LABEL BEDs from {args.de_tsv}")
        logging.info("=" * 60)
        exp_beds, _ = extract_beds(args.de_tsv, bed_dir)

        for prefix, beds_by_val in exp_beds.items():
            bed_files = [beds_by_val[v] for v in EXP_VALUES if v in beds_by_val]
            region_labels = [v for v in EXP_VALUES if v in beds_by_val]
            if not bed_files:
                continue

            exp_stat_pairs = [f"{region_labels[i]}:{region_labels[i+1]}"
                              for i in range(len(region_labels) - 1)]

            base = f"EXP_{prefix}"
            out_dir = os.path.join(args.output_path, "exp_heatmap", base)
            logging.info(f"EXP_LABEL heatmap: {prefix}")
            hb(
                out_dir,
                mode=args.mode,
                bed_files=bed_files,
                region_labels=region_labels,
                bigwigs=args.bigwig,
                sample_labels=args.samples,
                groups=args.groups,
                base_name=base,
                title=f"{prefix} by EXP level",
                threads=args.threads,
                species=args.species,
                stat_pairs=exp_stat_pairs,
                group_colormaps=args.group_colormaps,
                sort=args.sort,
                colormap=args.colormap,
                palette=args.palette,
                ylabel="Signal",
            )

    # ── method: de ───────────────────────────────────────────
    if "de" in methods:
        bed_dir = os.path.join(args.output_path, "extracted_bed")
        logging.info("=" * 60)
        logging.info(f"[METHOD de] Extracting DE_LABEL BEDs from {args.de_tsv}")
        logging.info("=" * 60)
        _, de_beds = extract_beds(args.de_tsv, bed_dir)

        if de_beds:
            bed_files = list(de_beds.values())
            region_labels = list(de_beds.keys())

            de_stat_pairs = args.stat_pairs or (
                [f"{region_labels[0]}:{region_labels[1]}"]
                if len(region_labels) >= 2 else None
            )

            base = f"DE_{safe_name}"
            out_dir = os.path.join(args.output_path, "de_heatmap", base)
            logging.info(f"DE_LABEL heatmap: {sample_name}")
            hb(
                out_dir,
                mode=args.mode,
                bed_files=bed_files,
                region_labels=region_labels,
                bigwigs=args.bigwig,
                sample_labels=args.samples,
                groups=args.groups,
                base_name=base,
                title=f"{sample_name} by DE",
                threads=args.threads,
                species=args.species,
                stat_pairs=de_stat_pairs,
                group_colormaps=args.group_colormaps,
                sort=args.sort,
                colormap=args.colormap,
                palette=args.palette,
                ylabel="Signal",
            )

    # ── method: raw ──────────────────────────────────────────
    if "raw" in methods:
        logging.info("=" * 60)
        logging.info("[METHOD raw] Using --beds directly as regions")
        logging.info("=" * 60)

        # raw regions come from --labels, so derive stat_pairs from labels
        # (--stat_pairs is for DE labels like Increased:Decreased)
        raw_stat_pairs = (
            [f"{args.labels[i]}:{args.labels[i+1]}"
             for i in range(len(args.labels) - 1)]
            if len(args.labels) >= 2 else None
        )

        base = f"RAW_{safe_name}"
        out_dir = os.path.join(args.output_path, "raw_heatmap", base)
        hb(
            out_dir,
            mode=args.mode,
            bed_files=args.beds,
            region_labels=args.labels,
            bigwigs=args.bigwig,
            sample_labels=args.samples,
            groups=args.groups,
            base_name=base,
            title=f"{sample_name}",
            threads=args.threads,
            species=args.species,
            stat_pairs=raw_stat_pairs,
            group_colormaps=args.group_colormaps,
            sort=args.sort,
            colormap=args.colormap,
            palette=args.palette,
            ylabel="Signal",
        )

    logging.info("=" * 60)
    logging.info(f"[DONE] All outputs in: {args.output_path}")
    logging.info(f"Pipeline finished: {datetime.now()}")
    logging.info("=" * 60)


if __name__ == "__main__":
    main()
