#!/usr/bin/env python3
"""
Combined pipeline: deeptools computeMatrix + publication heatmap + boxplot.

Steps:
    1. computeMatrix (center or region) → .mat.gz
    2. Publication-quality heatmap (plot_mat_heatmap.py)
    3. Boxplot with statistical comparisons

Usage:
    python plot_heatmap_box.py center \
        --input_bed Up.bed Down.bed \
        --input_bigwig WT.bw Y591.bw \
        --title "DOT1L peaks by DE (ATAC signals)" \
        --regions "Increased" "Decreased" \
        --samples "WT ATAC" "Y591* ATAC" \
        --base_name Peak_DOT1L_DE_with_ATAC_signals \
        --output_path ./peak_heatmap/Peak_DOT1L_DE_with_ATAC_signals \
        --ylabel "ATAC signals" \
        --stat_pairs "Increased:Decreased" \
        --threads 36
"""

import argparse
import gzip
import json
import os
import re
import subprocess

import numpy as np
import pandas as pd
import matplotlib
import matplotlib.pyplot as plt

# ── handle seaborn/matplotlib colormap name conflicts ────────
try:
    unregister = matplotlib.colormaps.unregister
except AttributeError:
    import matplotlib.cm as cm
    unregister = cm.unregister_cmap

for _name in ["rocket", "mako", "flare", "crest", "vlag", "icefire", "Spectral"]:
    try:
        unregister(_name)
        unregister(_name + "_r")
    except Exception:
        pass

import seaborn as sns
from fastsig.plot.zlbio import plot as zlp
from fastsig.plot.heatmap import plot_heatmap as plot_pub_heatmap
from fastsig.plot.heatmap import plot_heatmap_grouped as plot_pub_heatmap_grouped

# ── Reference gene BED lookup ────────────────────────────────
GENE_BED = {
    "hg38": "/data/user/leizheng/reference/Homo_sapiens/GENCODE/GRCh38/annotation/hg38.gene.bed",
    "mm10": "/data/user/leizheng/references/Mus_musculus/GENCODE/GRCm38/annotation/feature/gene.bed",
}


def intersect_bed_with_genes(input_beds, region_names, gene_bed, output_path):
    """For each input BED, intersect with gene_bed and deduplicate.

    Returns list of gene-intersected BED paths.
    """
    intersect_dir = os.path.join(output_path, "gene_intersect")
    os.makedirs(intersect_dir, exist_ok=True)
    gene_beds = []
    for i, bed in enumerate(input_beds):
        safe_name = re.sub(r'\W+', '_', region_names[i]) if region_names else f"group{i}"
        out_bed = os.path.join(intersect_dir, f"gene_intersect_{safe_name}.bed")
        tmp_bed = out_bed + ".tmp"
        print(f"[INFO] bedtools intersect: {region_names[i] if region_names else bed}")
        subprocess.run(
            f"bedtools intersect -a {gene_bed} -b {bed} -wa > {tmp_bed}",
            shell=True, check=True,
        )
        subprocess.run(
            f"sort -k1,1 -k2,2n {tmp_bed} | uniq > {out_bed}",
            shell=True, check=True,
        )
        os.remove(tmp_bed)
        n = sum(1 for _ in open(out_bed))
        print(f"         → {n} genes in {out_bed}")
        gene_beds.append(out_bed)
    return gene_beds


# ═════════════════════════════════════════════════════════════
# Step 1: computeMatrix → .mat.gz
# ═════════════════════════════════════════════════════════════
def run_compute_matrix(input_bed, input_bigwig, compute_type, output_path,
                       base_name, threads, engine="python", rust_bin=None):
    """Run computeMatrix only. Returns path to .mat.gz.

    engine = "python": use deeptools `computeMatrix`
    engine = "rust"  : use Rust `compute_matrix` binary (must be on PATH or
                       provided via rust_bin). The Rust binary accepts the same
                       deeptools-style long flags.
    """
    os.makedirs(output_path, exist_ok=True)
    matrix_out = os.path.join(output_path, f"{base_name}.mat.gz")
    log_file = os.path.join(output_path, f"{base_name}.log")

    if engine == "rust":
        binary = rust_bin or os.environ.get("RUST_COMPUTE_MATRIX")
        if not binary:
            # Auto-discover the binary bundled with the fastsig wheel.
            try:
                from importlib.resources import files as _ir_files  # py3.9+
                cand = _ir_files("fastsig") / "_bin" / "compute_matrix"
                if cand.is_file():
                    binary = str(cand)
            except Exception:
                pass
        if not binary:
            binary = "compute_matrix"
        prog = [binary]
    else:
        prog = ["computeMatrix"]

    if compute_type == "center":
        cmd = prog + [
            "reference-point",
            "--referencePoint", "center",
            "--regionsFileName", *input_bed,
            "--scoreFileName", *input_bigwig,
            "--numberOfProcessors", str(threads),
            "--skipZeros", "--missingDataAsZero",
            "--binSize", "100",
            "--sortRegions", "keep",
            "--sortUsing", "mean",
            "--averageTypeBins", "mean",
            "-b", "2000", "-a", "2000",
            "--smartLabels",
            "-o", matrix_out,
        ]
    else:  # region
        cmd = prog + [
            "scale-regions",
            "--beforeRegionStartLength", "3000",
            "--regionBodyLength", "5000",
            "--afterRegionStartLength", "3000",
            "--skipZeros", "--missingDataAsZero",
            "--regionsFileName", *input_bed,
            "--scoreFileName", *input_bigwig,
            "--numberOfProcessors", str(threads),
            "--smartLabels",
            "--outFileName", matrix_out,
        ]

    # Check for existing matrix: verify integrity, delete if corrupt
    if os.path.exists(matrix_out):
        try:
            with gzip.open(matrix_out, "rt") as fh:
                header = fh.readline()
                if not header.startswith("@"):
                    raise ValueError("Missing JSON header")
            print(f"[INFO] Matrix {matrix_out} exists, skipping computeMatrix.")
        except (EOFError, OSError, ValueError) as exc:
            print(f"[WARN] Corrupt matrix {matrix_out} ({exc}), regenerating.")
            os.remove(matrix_out)

    if not os.path.exists(matrix_out):
        print(f"[INFO] computeMatrix ...")
        print(f"[CMD]  {' '.join(cmd)}")
        with open(log_file, "w") as log_f:
            subprocess.run(cmd, stdout=log_f, stderr=log_f, check=True)

    return matrix_out


# ═════════════════════════════════════════════════════════════
# Step 2: Publication-quality heatmap (plot_mat_heatmap)
# ═════════════════════════════════════════════════════════════
def run_pub_heatmap(mat_file, output_path, base_name, title,
                    sample_labels, group_labels, colormap, sort_order,
                    profile_colors=None, vmin=None, vmax=None, dpi=300,
                    sample_groups=None, group_colormaps=None):
    """Generate publication-quality heatmap + profile from .mat.gz."""
    output_prefix = os.path.join(output_path, f"{base_name}_pub")
    print(f"[INFO] Publication heatmap ...")
    if sample_groups is not None:
        plot_pub_heatmap_grouped(
            mat_path=mat_file,
            output_prefix=output_prefix,
            sample_groups=sample_groups,
            title=title,
            sample_labels=sample_labels,
            group_labels=group_labels,
            group_colormaps=group_colormaps,
            profile_colors=profile_colors,
            dpi=dpi,
            sort_order=sort_order,
        )
    else:
        plot_pub_heatmap(
            mat_path=mat_file,
            output_prefix=output_prefix,
            title=title,
            sample_labels=sample_labels,
            group_labels=group_labels,
            colormap=colormap,
            vmin=vmin,
            vmax=vmax,
            profile_colors=profile_colors,
            dpi=dpi,
            sort_order=sort_order,
        )
    return output_prefix


# ═════════════════════════════════════════════════════════════
# Step 4: Boxplot
# ═════════════════════════════════════════════════════════════
def _load_matrix(mat_path):
    """Load .mat.gz by parsing JSON header + tab matrix directly (no deeptools)."""
    with gzip.open(mat_path, "rt") as fh:
        header = fh.readline().strip()
        meta = json.loads(header.lstrip("@"))
        rows = []
        regions = []
        for line in fh:
            if line.startswith("#"):
                continue
            parts = line.strip().split("\t")
            # columns: chr, start, end, name, score, strand, vals...
            if len(parts) > 6:
                chrom, start, end = parts[0], parts[1], parts[2]
                regions.append(f"{chrom}:{start}-{end}")
                vals = [float(v) if v not in ("", "nan", "NA") else np.nan
                        for v in parts[6:]]
                rows.append(vals)
    mat = np.array(rows, dtype=float)

    sample_labels = meta.get("sample_labels", [])
    sb = meta.get("sample_boundaries", [])
    gb = meta.get("group_boundaries", [])
    group_labels = meta.get("group_labels", [])

    return {
        "matrix": mat,
        "sample_labels": list(sample_labels),
        "sample_blocks": list(zip(sb[:-1], sb[1:])),
        "group_labels": list(group_labels),
        "group_blocks": list(zip(gb[:-1], gb[1:])),
        "n_regions": mat.shape[0],
        "regions_linear": regions,
    }


def _build_long_df(mat_info):
    """Build long-form DataFrame: region_idx | group | sample | value."""
    mat = mat_info["matrix"]
    sample_labels = mat_info["sample_labels"]
    sample_blocks = mat_info["sample_blocks"]
    group_labels = mat_info["group_labels"]
    group_blocks = mat_info["group_blocks"]
    n_regions = mat_info["n_regions"]

    region_to_group = np.empty(n_regions, dtype=object)
    for gi, (r0, r1) in enumerate(group_blocks):
        region_to_group[r0:r1] = group_labels[gi]

    region_names = mat_info.get("regions_linear")
    records = []
    for si, (c0, c1) in enumerate(sample_blocks):
        sample = sample_labels[si]
        row_means = np.nanmean(mat[:, c0:c1], axis=1)
        for ridx, val in enumerate(row_means):
            rec = {
                "region_idx": ridx,
                "group": region_to_group[ridx],
                "sample": sample,
                "value": float(val),
            }
            if region_names:
                rec["region"] = region_names[ridx]
            records.append(rec)

    df = pd.DataFrame.from_records(records)
    df["group"] = pd.Categorical(df["group"],
                                 categories=group_labels, ordered=True)
    return df


def _resolve_palette(palette, n_colors):
    """Resolve named palette to seaborn color list."""
    named = {
        "blue": "Blues", "red": "Reds", "green": "Greens",
        "purple": "Purples", "orange": "Oranges", "gray": "Greys",
    }
    if palette in named:
        return sns.color_palette(named[palette],
                                 n_colors=n_colors)[::-1][1:]
    if palette == "":
        return sns.color_palette("coolwarm",
                                 n_colors=n_colors)[::-1][1:]
    return sns.color_palette(palette, n_colors=n_colors)[:-1]


def _format_m6A(label):
    """Render m6A as LaTeX superscript."""
    return label.replace("m6A", "m$^6$A")


def run_boxplot(matrix_file, labels, raw_samples, sample_labels,
                output_path, basename, ylabel, palette,
                stat_pairs=None, stat_test="Mann-Whitney", figsize=None):
    """Generate boxplot from .mat.gz."""
    os.makedirs(output_path, exist_ok=True)
    print(f"[INFO] Loading matrix for boxplot ...")

    mat_info = _load_matrix(matrix_file)
    df = _build_long_df(mat_info)

    # filter to requested samples
    plot_df = df[df["sample"].isin(raw_samples)].copy()
    plot_df["value"] = plot_df["value"].astype(float)

    # format m6A in labels
    labels = [_format_m6A(l) for l in labels]

    # palette
    n_colors = max(len(labels), len(raw_samples)) + 1
    current_palette = _resolve_palette(palette, n_colors)

    # remap group labels
    group_unique = list(plot_df["group"].unique())
    group_map = dict(zip(group_unique, labels))
    print("Group mapping:")
    for k, v in group_map.items():
        print(f"  {k} -> {v}")
    plot_df["group"] = plot_df["group"].map(group_map)
    plot_df["group"] = pd.Categorical(plot_df["group"],
                                      categories=labels, ordered=True)

    # remap sample labels
    if sample_labels and len(sample_labels) == len(raw_samples):
        sample_map = dict(zip(raw_samples, sample_labels))
        print("Sample mapping:")
        for k, v in sample_map.items():
            print(f"  {k} -> {v}")
        plot_df["sample"] = plot_df["sample"].map(sample_map)

    order = labels
    current_figsize = tuple(figsize) if figsize else (3, 4.5)

    print("Plotting boxplot ...")
    if stat_pairs:
        # format m6A in stat_pairs too
        fmt_pairs = [
            _format_m6A(p.split(":")[0]) + ":" + _format_m6A(p.split(":")[1])
            for p in stat_pairs
        ]
        parsed = []
        for p in fmt_pairs:
            a, b = p.split(":", 1)
            parsed.append((a.strip(), b.strip()))
        stat_config = {
            "pairs": parsed, "x": "group", "y": "value", "order": order,
            "test": stat_test,
        }
        zlp.boxplot(
            data=plot_df, x="group", y="value", order=order,
            hue="sample" if len(raw_samples) > 1 else None,
            stat=stat_config, palette=current_palette,
            figsize=current_figsize,
        )
    else:
        zlp.boxplot(
            data=plot_df, x="group", y="value", order=order,
            hue="sample" if len(raw_samples) > 1 else None,
            palette=current_palette, figsize=current_figsize,
        )

    if len(raw_samples) > 1:
        plt.legend(bbox_to_anchor=(0.5, 1.15), loc="upper center",
                   ncol=len(raw_samples))

    plt.ylabel(ylabel)
    plt.xlabel("")
    plt.xticks(rotation=45, fontsize=11)

    # ── save ─────────────────────────────────────────────────
    pdf_p = os.path.join(output_path, f"{basename}.pdf")
    png_p = os.path.join(output_path, f"{basename}.png")
    data_p = os.path.join(output_path, f"{basename}_data.tsv.gz")
    tbl_p = os.path.join(output_path, f"{basename}_table.tsv")

    plot_df.to_csv(data_p, sep="\t", index=False, compression="gzip")
    print(f"[INFO] Data saved: {data_p}")

    stats = []
    for g in order:
        gd = plot_df[plot_df["group"] == g]["value"].dropna()
        if len(gd):
            stats.append({
                "Group": g, "Min": gd.min(),
                "Q1": gd.quantile(0.25), "Median": gd.median(),
                "Q3": gd.quantile(0.75), "Max": gd.max(),
            })
    pd.DataFrame(stats).to_csv(tbl_p, sep="\t", index=False)
    print(f"[INFO] Stats saved: {tbl_p}")

    plt.savefig(pdf_p, format="pdf", bbox_inches="tight", dpi=300)
    plt.savefig(png_p, bbox_inches="tight", dpi=300)
    print(f"[INFO] Boxplot saved: {pdf_p}")
    plt.close()


# ═════════════════════════════════════════════════════════════
# CLI
# ═════════════════════════════════════════════════════════════
def main():
    p = argparse.ArgumentParser(
        description="Combined deeptools heatmap + boxplot pipeline",
    )

    # ── mode ─────────────────────────────────────────────────
    p.add_argument("mode", choices=["center", "region", "gene"],
                   help="center: reference-point at peak center; "
                        "region: scale-regions on input BED; "
                        "gene: intersect input BED with reference gene BED, "
                        "then scale-regions")
    p.add_argument("--species", default="hg38",
                   help="Species for gene mode (hg38 or mm10)")

    # ── computeMatrix parameters ─────────────────────────────
    p.add_argument("--input_bed", nargs="+", required=True,
                   help="Input BED file(s)")
    p.add_argument("--input_bigwig", nargs="+", required=True,
                   help="Input bigWig file(s)")
    p.add_argument("--output_path", required=True,
                   help="Output directory")
    p.add_argument("--base_name", required=True,
                   help="Base name for output files")
    p.add_argument("--threads", type=int, default=24)

    # ── matrix engine ────────────────────────────────────────
    p.add_argument("--matrix_engine", choices=["python", "rust"],
                   default="python",
                   help="computeMatrix engine: deeptools (python) or Rust port")
    p.add_argument("--rust_bin", default=None,
                   help="Path to Rust compute_matrix binary "
                        "(default: $RUST_COMPUTE_MATRIX or 'compute_matrix' on PATH)")

    # ── shared labels ────────────────────────────────────────
    p.add_argument("--title", default=None, help="Plot title")
    p.add_argument("--regions", nargs="+", default=None,
                   help="Group/region labels (e.g. Increased Decreased)")
    p.add_argument("--samples", nargs="+", default=None,
                   help="Display sample labels (e.g. 'WT ATAC' 'Y591* ATAC')")

    # ── heatmap ──────────────────────────────────────────────
    p.add_argument("--colormap", default="Oranges",
                   help="Heatmap colormap (matplotlib/seaborn, e.g. Oranges, sns:rocket)")
    p.add_argument("--sort", choices=["descending", "ascending", "keep"],
                   default="descending",
                   help="Sort order for heatmap rows")
    p.add_argument("--profile_colors", nargs="+", default=None,
                   help="Profile line colors (hex per group, or 'sns:palette')")
    p.add_argument("--vmin", type=float, default=None,
                   help="Heatmap color min")
    p.add_argument("--vmax", default=None,
                   help="Heatmap color max ('auto' or float)")
    p.add_argument("--dpi", type=int, default=300)

    # ── boxplot ──────────────────────────────────────────────
    p.add_argument("--ylabel", default="Signal",
                   help="Y-axis label for boxplot")
    p.add_argument("--palette", default="orange",
                   help="Boxplot color palette (blue/red/green/purple/orange/gray)")
    p.add_argument("--stat_pairs", nargs="+", default=None,
                   help="Stat comparison pairs, e.g. 'Increased:Decreased'")
    p.add_argument("--stat_test", default="Mann-Whitney",
                   choices=["Mann-Whitney", "t-test_ind", "t-test_welch",
                            "Wilcoxon", "Brunner-Munzel", "Levene",
                            "Kruskal"],
                   help="Statistical test for boxplot annotations "
                        "(default: Mann-Whitney; rank-based, robust to outliers).")
    p.add_argument("--figsize", nargs=2, type=float, default=None,
                   help="Boxplot figure size: width height")

    # ── sample grouping ──────────────────────────────────────
    p.add_argument("--groups", nargs="+", default=None,
                   help="Sample group labels, one per bigwig (e.g. "
                        "'ATAC' 'ATAC' 'H2AK119ub' 'H2AK119ub'). "
                        "Groups share scale & colormap.")
    p.add_argument("--group_colormaps", nargs="+", default=None,
                   help="One colormap per sample group "
                        "(default: Oranges Blues Greens Purples ...)")

    args = p.parse_args()

    # ── resolve mode ──────────────────────────────────────────
    bed_files = args.input_bed
    compute_type = args.mode  # center or region
    if args.mode == "gene":
        compute_type = "region"
        if args.species not in GENE_BED:
            print(f"[ERROR] Unknown species '{args.species}'. "
                  f"Available: {list(GENE_BED.keys())}")
            exit(1)
        gene_bed = GENE_BED[args.species]
        if not os.path.exists(gene_bed):
            print(f"[ERROR] Gene BED not found: {gene_bed}")
            exit(1)
        bed_files = intersect_bed_with_genes(
            input_beds=args.input_bed,
            region_names=args.regions,
            gene_bed=gene_bed,
            output_path=args.output_path,
        )

    # ── 1) computeMatrix ─────────────────────────────────────
    mat_file = run_compute_matrix(
        input_bed=bed_files,
        input_bigwig=args.input_bigwig,
        compute_type=compute_type,
        output_path=args.output_path,
        base_name=args.base_name,
        threads=args.threads,
        engine=args.matrix_engine,
        rust_bin=args.rust_bin,
    )

    # ── read raw sample names from matrix ────────────────────
    with gzip.open(mat_file, "rt") as fh:
        meta = json.loads(fh.readline().strip().lstrip("@"))
    raw_samples = meta["sample_labels"]

    # ── parse --groups into OrderedDict ──────────────────────
    sample_groups = None
    if args.groups:
        from collections import OrderedDict
        sample_groups = OrderedDict()
        for i, g in enumerate(args.groups):
            sample_groups.setdefault(g, []).append(i)

    # ── 2) publication-quality heatmap ────────────────────────
    run_pub_heatmap(
        mat_file=mat_file,
        output_path=args.output_path,
        base_name=args.base_name,
        title=args.title,
        sample_labels=args.samples,
        group_labels=args.regions,
        colormap=args.colormap,
        sort_order=args.sort,
        profile_colors=args.profile_colors,
        vmin=args.vmin,
        vmax=args.vmax,
        dpi=args.dpi,
        sample_groups=sample_groups,
        group_colormaps=args.group_colormaps,
    )

    # ── 3) boxplot ───────────────────────────────────────────
    if sample_groups:
        for sg_name, si_list in sample_groups.items():
            sg_raw = [raw_samples[i] for i in si_list]
            sg_labels = ([args.samples[i] for i in si_list]
                         if args.samples else None)
            box_dir = os.path.join(args.output_path, "box", sg_name)
            run_boxplot(
                matrix_file=mat_file,
                labels=args.regions or meta["group_labels"],
                raw_samples=sg_raw,
                sample_labels=sg_labels,
                output_path=box_dir,
                basename=f"{args.base_name}_{sg_name}_boxplot",
                ylabel=f"{sg_name} signals",
                palette=args.palette,
                stat_pairs=args.stat_pairs,
                stat_test=args.stat_test,
                figsize=args.figsize,
            )
    else:
        box_dir = os.path.join(args.output_path, "box")
        run_boxplot(
            matrix_file=mat_file,
            labels=args.regions or meta["group_labels"],
            raw_samples=raw_samples,
            sample_labels=args.samples,
            output_path=box_dir,
            basename=f"{args.base_name}_boxplot",
            ylabel=args.ylabel,
            palette=args.palette,
            stat_pairs=args.stat_pairs,
            stat_test=args.stat_test,
            figsize=args.figsize,
        )


if __name__ == "__main__":
    main()
