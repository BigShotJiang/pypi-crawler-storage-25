"""Empty marker so fastsig.plot is importable as a package."""
