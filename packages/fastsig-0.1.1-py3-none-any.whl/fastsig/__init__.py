"""fastsig — fast publication-quality signal heatmaps + boxplots."""

__version__ = "0.1.1"
