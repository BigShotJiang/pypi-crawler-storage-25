#!/usr/bin/env python3
"""
ferrotools_pipeline.py — end-to-end driver for the ferrotools suite.

Steps:
  1. (optional) bam_coverage   : convert each BAM input to a normalized bigWig
  2. (optional) bigwig_compare : pairwise compare two groups (--compare_group A B)
  3. compute_matrix            : build a per-region score matrix (.mat.gz)
  4. plot_heatmap_box.py       : publication heatmap + boxplot

Inputs may freely mix BAM and bigWig. BAM extensions trigger step 1; bigWigs
pass through. If --compare_group is set, the matrix is built from the compare
output bigWigs; otherwise it is built from every per-input bigWig.

The plotting step delegates to plot_heatmap/plot_heatmap_box.py, which under
the hood calls plot_mat_heatmap.plot_heatmap() for the figure and adds a
boxplot of mean-per-region signal across groups (with optional statistical
annotations). Examples are documented in README.md.
"""

from __future__ import annotations

import argparse
import os
import shutil
import subprocess
import sys
import time
from pathlib import Path
from typing import Iterable


BAM_SUFFIXES = {".bam"}
BW_SUFFIXES = {".bw", ".bigwig"}


# ─────────────────────────────────────────────────────────────────────────────
# Binary / script discovery
# ─────────────────────────────────────────────────────────────────────────────

def find_binary(name: str) -> str:
    """Locate a Rust binary. Prefers binaries bundled inside the wheel
    (`fastsig/_bin/`), then falls back to dev locations and `$PATH`.
    """
    here = Path(__file__).resolve().parent
    exe = ".exe" if os.name == "nt" else ""
    candidates = [
        here / "_bin" / f"{name}{exe}",
        here.parent.parent.parent / "target" / "release" / f"{name}{exe}",
        Path("/root/cm_target/release") / f"{name}{exe}",
        Path("/usr/local/bin") / f"{name}{exe}",
    ]
    for c in candidates:
        if c.exists() and os.access(c, os.X_OK):
            return str(c)
    found = shutil.which(name)
    if found:
        return found
    raise FileNotFoundError(
        f"Binary '{name}' not found.\n"
        f"  Build with: cargo build --release -p {name}\n"
        f"  Searched: {[str(c) for c in candidates]} and PATH"
    )


def find_plot_box_script() -> str:
    """Locate the heatmap_box module file inside fastsig."""
    here = Path(__file__).resolve().parent
    candidate = here / "plot" / "heatmap_box.py"
    if candidate.exists():
        return str(candidate)
    raise FileNotFoundError(
        f"fastsig.plot.heatmap_box not found at {candidate}"
    )


# ─────────────────────────────────────────────────────────────────────────────
# Argument parsing
# ─────────────────────────────────────────────────────────────────────────────

def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="ferrotools_pipeline.py",
        description="Run the full ferrotools BAM→bigWig→matrix→heatmap+boxplot pipeline.",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )

    # Inputs / grouping
    p.add_argument("--inputs", nargs="+", required=True,
                   help="BAM and/or bigWig files (auto-detected by extension).")
    p.add_argument("--groups", nargs="+", required=True,
                   help="Group name per input (parallel to --inputs).")
    p.add_argument("--labels", nargs="+", default=None,
                   help="Display label per input (default: file stem).")
    p.add_argument("--regions", nargs="+", required=False,
                   help="BED/GTF region files.")
    p.add_argument("--region_labels", nargs="+", default=None,
                   help="Display label per --regions file (heatmap row label).")

    # bigwig_compare options
    p.add_argument("--compare_group", nargs=2, metavar=("A", "B"), default=None,
                   help="Run bigwig_compare between groups A and B.")
    p.add_argument("--compare_operation", default="log2",
                   choices=["log2", "ratio", "subtract", "add", "mean",
                            "reciprocal_ratio", "first", "second"],
                   help="Operation for bigwig_compare.")
    p.add_argument("--compare_pseudocount", type=float, default=1.0,
                   help="Pseudocount for ratio-style operations.")
    p.add_argument("--compare_scale_factors", default=None,
                   help="A:B scale factors passed to bigwig_compare --scaleFactors.")
    p.add_argument("--compare_skip_zero_over_zero", action="store_true",
                   help="Pass --skipZeroOverZero to bigwig_compare.")

    # compute_matrix options
    p.add_argument("--mode", choices=["reference-point", "scale-regions"],
                   default="reference-point",
                   help="compute_matrix subcommand.")
    p.add_argument("--reference_point", choices=["TSS", "TES", "center"],
                   default="center",
                   help="reference-point only.")
    p.add_argument("--upstream", type=int, default=2000,
                   help="bp upstream (-b for compute_matrix).")
    p.add_argument("--downstream", type=int, default=2000,
                   help="bp downstream (-a for compute_matrix).")
    p.add_argument("--body_length", type=int, default=1000,
                   help="scale-regions only (-m).")
    p.add_argument("--bin_size", type=int, default=10,
                   help="compute_matrix --binSize.")
    p.add_argument("--skip_zeros", action="store_true",
                   help="Pass --skipZeros to compute_matrix.")
    p.add_argument("--missing_data_as_zero", action="store_true",
                   help="Pass --missingDataAsZero to compute_matrix.")

    # bam_coverage options
    p.add_argument("--bam_bin_size", type=int, default=50,
                   help="bam_coverage --binSize.")
    p.add_argument("--normalize", default="RPKM",
                   choices=["None", "RPKM", "CPM", "BPM", "RPGC"],
                   help="bam_coverage --normalizeUsing.")
    p.add_argument("--effective_genome_size", type=int, default=None,
                   help="bam_coverage --effectiveGenomeSize (required for RPGC).")
    p.add_argument("--extend_reads", type=int, default=None,
                   help="bam_coverage --extendReads (single-end).")
    p.add_argument("--min_mapping_quality", type=int, default=None,
                   help="bam_coverage --minMappingQuality.")
    p.add_argument("--ignore_duplicates", action="store_true",
                   help="bam_coverage --ignoreDuplicates.")
    p.add_argument("--blacklist", default=None,
                   help="BED file passed to both bam_coverage and compute_matrix.")

    # Plotting options forwarded to plot_heatmap_box.py
    p.add_argument("--colormap", default="Oranges",
                   help="Heatmap colormap (matplotlib or sns:rocket / sns:mako).")
    p.add_argument("--vmin", default=None, help="Heatmap color min.")
    p.add_argument("--vmax", default=None,
                   help="Heatmap color max (numeric or 'auto').")
    p.add_argument("--profile_colors", nargs="+", default=None,
                   help="Profile line colors (hex per group, or single sns:Set2).")
    p.add_argument("--sort", choices=["descending", "ascending", "keep"],
                   default="descending",
                   help="Heatmap row sort order.")
    p.add_argument("--title", default=None,
                   help="Figure title (also basename for matrix/plot output).")
    p.add_argument("--dpi", type=int, default=300, help="Plot DPI.")
    p.add_argument("--sample_groups", nargs="+", default=None,
                   help="Per-bigWig sample-group label for grouped multi-panel heatmaps.")
    p.add_argument("--group_colormaps", nargs="+", default=None,
                   help="One colormap per --sample_groups bucket.")

    # Boxplot options forwarded to plot_heatmap_box.py
    p.add_argument("--ylabel", default="Signal", help="Boxplot Y-axis label.")
    p.add_argument("--palette", default="orange",
                   help="Boxplot palette (blue/red/green/purple/orange/gray).")
    p.add_argument("--stat_pairs", nargs="+", default=None,
                   help="Boxplot stat-comparison pairs, e.g. 'Increased:Decreased'.")
    p.add_argument("--stat_test", default="Mann-Whitney",
                   choices=["Mann-Whitney", "t-test_ind", "t-test_welch",
                            "Wilcoxon", "Brunner-Munzel", "Levene", "Kruskal"],
                   help="Boxplot statistical test.")

    # Pipeline / runtime
    p.add_argument("-p", "--processors", type=int, default=4,
                   help="Threads for every step.")
    p.add_argument("--output_dir", default="./ferrotools_out",
                   help="Output directory.")
    p.add_argument("--skip_existing", action="store_true",
                   help="Skip steps whose outputs already exist.")
    p.add_argument("--matrix_file", default=None,
                   help="Use an existing .mat.gz; skip steps 1-3.")
    p.add_argument("--python", default=sys.executable,
                   help="Python interpreter for plot_heatmap_box.py.")
    p.add_argument("--dry_run", action="store_true",
                   help="Print commands without executing.")

    return p


# ─────────────────────────────────────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────────────────────────────────────

def detect_kind(path: str) -> str:
    suf = Path(path).suffix.lower()
    if suf in BAM_SUFFIXES:
        return "bam"
    if suf in BW_SUFFIXES:
        return "bigwig"
    raise ValueError(f"Unsupported input extension: {path!r}. Expected .bam / .bw / .bigwig")


def shquote(parts: Iterable[str]) -> str:
    import shlex
    return " ".join(shlex.quote(str(x)) for x in parts)


def run(cmd: list, *, dry_run: bool, label: str, env: dict | None = None) -> float:
    print(f"\n[ferrotools] >>> {label}")
    print(f"  $ {shquote(cmd)}")
    if dry_run:
        return 0.0
    t0 = time.time()
    proc = subprocess.run([str(c) for c in cmd], env=env)
    dt = time.time() - t0
    if proc.returncode != 0:
        print(f"[ferrotools] !!! {label} failed (exit {proc.returncode})", file=sys.stderr)
        sys.exit(proc.returncode)
    print(f"[ferrotools] <<< {label} done in {dt:.2f}s")
    return dt


def ensure_dir(path: Path) -> Path:
    path.mkdir(parents=True, exist_ok=True)
    return path


def safe_label(s: str) -> str:
    return "".join(c if c.isalnum() or c in "-_." else "_" for c in s)


# ─────────────────────────────────────────────────────────────────────────────
# Pipeline steps
# ─────────────────────────────────────────────────────────────────────────────

def step_bam_coverage(*, bam_path, out_bw, args, bam_coverage_bin):
    if args.skip_existing and out_bw.exists():
        print(f"[ferrotools] Skipping bam_coverage (exists): {out_bw}")
        return
    cmd = [
        bam_coverage_bin,
        "--bam", bam_path,
        "--outFileName", str(out_bw),
        "--outFileFormat", "bigwig",
        "--binSize", str(args.bam_bin_size),
        "--numberOfProcessors", str(args.processors),
        "--normalizeUsing", args.normalize,
    ]
    if args.effective_genome_size is not None:
        cmd += ["--effectiveGenomeSize", str(args.effective_genome_size)]
    if args.extend_reads is not None:
        cmd += ["--extendReads", str(args.extend_reads)]
    if args.min_mapping_quality is not None:
        cmd += ["--minMappingQuality", str(args.min_mapping_quality)]
    if args.ignore_duplicates:
        cmd += ["--ignoreDuplicates"]
    if args.blacklist:
        cmd += ["--blackListFileName", args.blacklist]
    run(cmd, dry_run=args.dry_run,
        label=f"bam_coverage  {Path(bam_path).name} → {out_bw.name}")


def step_bigwig_compare(*, bw_a, bw_b, out_bw, args, bigwig_compare_bin):
    if args.skip_existing and out_bw.exists():
        print(f"[ferrotools] Skipping bigwig_compare (exists): {out_bw}")
        return
    cmd = [
        bigwig_compare_bin,
        "--bigwig1", bw_a,
        "--bigwig2", bw_b,
        "--outFileName", str(out_bw),
        "--outFileFormat", "bigwig",
        "--operation", args.compare_operation,
        "--binSize", str(args.bam_bin_size),
        "--pseudocount", str(args.compare_pseudocount),
        "--numberOfProcessors", str(args.processors),
    ]
    if args.compare_scale_factors:
        cmd += ["--scaleFactors", args.compare_scale_factors]
    if args.compare_skip_zero_over_zero:
        cmd += ["--skipZeroOverZero"]
    run(cmd, dry_run=args.dry_run,
        label=f"bigwig_compare  {Path(bw_a).name} vs {Path(bw_b).name} → {out_bw.name}")


def step_compute_matrix(*, score_files, score_labels, regions, out_matrix,
                        args, compute_matrix_bin):
    if args.skip_existing and out_matrix.exists():
        print(f"[ferrotools] Skipping compute_matrix (exists): {out_matrix}")
        return
    cmd = [compute_matrix_bin, args.mode]
    cmd += ["-S", *score_files]
    cmd += ["-R", *regions]
    cmd += ["-o", str(out_matrix)]
    cmd += ["-b", str(args.upstream), "-a", str(args.downstream)]
    cmd += ["--binSize", str(args.bin_size)]
    cmd += ["--numberOfProcessors", str(args.processors)]
    if args.mode == "reference-point":
        cmd += ["--referencePoint", args.reference_point]
    else:
        cmd += ["--regionBodyLength", str(args.body_length)]
    if args.skip_zeros:
        cmd += ["--skipZeros"]
    if args.missing_data_as_zero:
        cmd += ["--missingDataAsZero"]
    if args.blacklist:
        cmd += ["--blackListFileName", args.blacklist]
    if score_labels:
        cmd += ["--samplesLabel", *score_labels]
    run(cmd, dry_run=args.dry_run, label=f"compute_matrix → {out_matrix.name}")


def step_plot_heatmap_box(*, score_files, score_labels, region_files, region_labels,
                          base_name, out_dir, args, plot_box_script):
    """Delegate heatmap + boxplot to plot_heatmap_box.py.

    plot_heatmap_box checks for an existing {out_dir}/{base_name}.mat.gz and
    skips its own computeMatrix step when present, so we get heatmap+boxplot
    out of the same matrix that step_compute_matrix already produced.
    """
    box_mode = "center" if args.mode == "reference-point" else "region"
    cmd = [
        args.python, plot_box_script, box_mode,
        "--input_bed", *region_files,
        "--input_bigwig", *score_files,
        "--output_path", str(out_dir),
        "--base_name", base_name,
        "--threads", str(args.processors),
        "--colormap", args.colormap,
        "--sort", args.sort,
        "--ylabel", args.ylabel,
        "--palette", args.palette,
        "--stat_test", args.stat_test,
        "--dpi", str(args.dpi),
    ]
    if args.title:
        cmd += ["--title", args.title]
    if region_labels:
        cmd += ["--regions", *region_labels]
    if score_labels:
        cmd += ["--samples", *score_labels]
    if args.vmin is not None:
        cmd += ["--vmin", str(args.vmin)]
    if args.vmax is not None:
        cmd += ["--vmax", str(args.vmax)]
    if args.profile_colors:
        cmd += ["--profile_colors", *args.profile_colors]
    if args.sample_groups:
        cmd += ["--groups", *args.sample_groups]
    if args.group_colormaps:
        cmd += ["--group_colormaps", *args.group_colormaps]
    if args.stat_pairs:
        cmd += ["--stat_pairs", *args.stat_pairs]

    # heatmap_box now lives inside the fastsig package; ensure the parent of
    # the package directory is on PYTHONPATH so `import fastsig.plot.*` works.
    env = os.environ.copy()
    pkg_root = str(Path(plot_box_script).resolve().parents[2])
    env["PYTHONPATH"] = pkg_root + os.pathsep + env.get("PYTHONPATH", "")
    run(cmd, dry_run=args.dry_run,
        label=f"plot_heatmap_box → {base_name}_pub.png/pdf  +  box/", env=env)


# ─────────────────────────────────────────────────────────────────────────────
# Pairing logic for --compare_group
# ─────────────────────────────────────────────────────────────────────────────

def pair_compare_groups(bw_paths_a, labels_a, bw_paths_b, labels_b):
    na, nb = len(bw_paths_a), len(bw_paths_b)
    if na == 0 or nb == 0:
        raise ValueError("Both compare groups must contain at least one file.")
    if na == nb:
        return list(zip(bw_paths_a, bw_paths_b, labels_a, labels_b))
    if na == 1:
        return [(bw_paths_a[0], b, labels_a[0], lb) for b, lb in zip(bw_paths_b, labels_b)]
    if nb == 1:
        return [(a, bw_paths_b[0], la, labels_b[0]) for a, la in zip(bw_paths_a, labels_a)]
    raise ValueError(
        f"--compare_group sizes incompatible: A has {na}, B has {nb}. "
        f"Expected equal sizes or one side to be 1."
    )


# ─────────────────────────────────────────────────────────────────────────────
# Main
# ─────────────────────────────────────────────────────────────────────────────

def main() -> int:
    args = build_parser().parse_args()

    if len(args.inputs) != len(args.groups):
        sys.exit(f"--inputs ({len(args.inputs)}) and --groups ({len(args.groups)}) must have equal length.")
    if args.labels and len(args.labels) != len(args.inputs):
        sys.exit(f"--labels ({len(args.labels)}) must equal --inputs ({len(args.inputs)}) if provided.")
    if args.matrix_file is None and not args.regions:
        sys.exit("--regions is required unless --matrix_file is provided.")

    labels = args.labels or [Path(p).stem for p in args.inputs]
    output_dir = ensure_dir(Path(args.output_dir))
    base_name = safe_label(args.title or "ferrotools")
    plot_box_script = find_plot_box_script()

    # Fast-path: pre-existing matrix
    if args.matrix_file:
        target = output_dir / f"{base_name}.mat.gz"
        src = Path(args.matrix_file)
        if not src.exists() and not args.dry_run:
            sys.exit(f"--matrix_file does not exist: {src}")
        if not args.dry_run and str(src.resolve()) != str(target.resolve()):
            shutil.copyfile(src, target)
            print(f"[ferrotools] staged matrix: {src} → {target}")
        step_plot_heatmap_box(
            score_files=labels, score_labels=labels,
            region_files=args.regions or ["__placeholder__"],
            region_labels=args.region_labels,
            base_name=base_name, out_dir=output_dir,
            args=args, plot_box_script=plot_box_script,
        )
        return 0

    # Step 1: BAM → bigWig
    bam_bw_dir = ensure_dir(output_dir / "bam_bw")
    bw_per_input: list[str] = []
    bam_coverage_bin = None
    for inp, _grp, _lab in zip(args.inputs, args.groups, labels):
        kind = detect_kind(inp)
        if kind == "bam":
            if bam_coverage_bin is None:
                bam_coverage_bin = find_binary("bam_coverage")
            out_bw = bam_bw_dir / f"{Path(inp).stem}.bw"
            step_bam_coverage(
                bam_path=inp, out_bw=out_bw, args=args,
                bam_coverage_bin=bam_coverage_bin,
            )
            bw_per_input.append(str(out_bw))
        else:
            bw_per_input.append(inp)

    # Step 2: bigwig_compare
    if args.compare_group:
        a_name, b_name = args.compare_group
        groups_seen = set(args.groups)
        for g in (a_name, b_name):
            if g not in groups_seen:
                sys.exit(f"--compare_group references unknown group: {g!r} "
                         f"(known: {sorted(groups_seen)})")
        bw_a = [bw for bw, g in zip(bw_per_input, args.groups) if g == a_name]
        bw_b = [bw for bw, g in zip(bw_per_input, args.groups) if g == b_name]
        lab_a = [lb for lb, g in zip(labels, args.groups) if g == a_name]
        lab_b = [lb for lb, g in zip(labels, args.groups) if g == b_name]
        pairs = pair_compare_groups(bw_a, lab_a, bw_b, lab_b)
        bigwig_compare_bin = find_binary("bigwig_compare")
        compare_dir = ensure_dir(output_dir / "compare")
        score_files: list[str] = []
        score_labels: list[str] = []
        for fa, fb, la, lb in pairs:
            out_bw = compare_dir / f"{safe_label(la)}_vs_{safe_label(lb)}.bw"
            step_bigwig_compare(
                bw_a=fa, bw_b=fb, out_bw=out_bw, args=args,
                bigwig_compare_bin=bigwig_compare_bin,
            )
            score_files.append(str(out_bw))
            score_labels.append(f"{la} {args.compare_operation} {lb}")
    else:
        score_files = bw_per_input
        score_labels = labels

    # Step 3: compute_matrix
    compute_matrix_bin = find_binary("compute_matrix")
    matrix_path = output_dir / f"{base_name}.mat.gz"
    step_compute_matrix(
        score_files=score_files, score_labels=score_labels,
        regions=args.regions, out_matrix=matrix_path,
        args=args, compute_matrix_bin=compute_matrix_bin,
    )

    # Step 4: heatmap + boxplot via plot_heatmap_box.py
    step_plot_heatmap_box(
        score_files=score_files, score_labels=score_labels,
        region_files=args.regions, region_labels=args.region_labels,
        base_name=base_name, out_dir=output_dir,
        args=args, plot_box_script=plot_box_script,
    )

    print("\n[ferrotools] Pipeline finished.")
    print(f"  Output dir : {output_dir}")
    print(f"  Matrix     : {matrix_path}")
    print(f"  Heatmap    : {output_dir / (base_name + '_pub.png')}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
