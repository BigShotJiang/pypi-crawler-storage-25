"""fastsig CLI dispatcher.

Subcommands:
  pipeline         End-to-end BAM/bigWig → matrix → heatmap + boxplot driver
  function         Gene-set heatmap + boxplot from one or more GMT/text files
  gene             Gene-body heatmap + boxplot from a GTF or gene BED
  plot-heatmap-box Compute a signal matrix then render heatmap + boxplot
  bam-coverage     Convert BAM to normalized bigWig/bedGraph coverage
  bigwig-compare   Combine two bigWigs (log2/ratio/subtract/add/mean) into one
  compute-matrix   Build per-region signal matrices from bigWigs (.mat.gz)
  gtf-to-bed       Extract genes or transcripts from GTF(.gz) to BED6
"""

from __future__ import annotations

import os
import sys
from pathlib import Path

from . import __version__


# Subcommands implemented by exec'ing a Rust binary bundled at fastsig/_bin/.
RUST_SUBCOMMANDS = {
    "bam-coverage": "bam_coverage",
    "bigwig-compare": "bigwig_compare",
    "compute-matrix": "compute_matrix",
    "gtf-to-bed": "gtf_to_bed",
}

# Subcommands implemented in Python.
PY_SUBCOMMANDS = {
    "pipeline": ("fastsig.pipeline", "main"),
    "function": ("fastsig.function_cmd", "function_main"),
    "gene": ("fastsig.function_cmd", "gene_main"),
    "plot-heatmap-box": ("fastsig.plot.heatmap_box", "main"),
}

ALL_SUBCOMMANDS = list(PY_SUBCOMMANDS.keys()) + list(RUST_SUBCOMMANDS.keys())


def _print_help() -> None:
    print("fastsig — fast signal heatmaps + boxplots")
    print(f"version: {__version__}\n")
    print("Usage: fastsig <subcommand> [args...]")
    print("       fastsig <subcommand> --help\n")
    print("Subcommands:")
    print("  pipeline          End-to-end BAM/bigWig → matrix → heatmap + boxplot driver")
    print("  function          Gene-set heatmap + boxplot from one or more GMT/text files")
    print("  gene              Gene-body heatmap + boxplot from a GTF or gene BED")
    print("  plot-heatmap-box  Compute a signal matrix then render heatmap + boxplot")
    print("  bam-coverage      Convert BAM to normalized bigWig/bedGraph coverage")
    print("  bigwig-compare    Combine two bigWigs (log2/ratio/subtract/add/mean) into one")
    print("  compute-matrix    Build per-region signal matrices from bigWigs (.mat.gz)")
    print("  gtf-to-bed        Extract genes or transcripts from GTF(.gz) to BED6")


def _exec_rust(name: str, argv: list) -> int:
    """Locate <pkg>/_bin/<name> and execv into it."""
    here = Path(__file__).resolve().parent
    exe = ".exe" if os.name == "nt" else ""
    bundled = here / "_bin" / f"{name}{exe}"
    candidates = [bundled]
    # Dev fallback paths
    candidates.append(here.parent.parent.parent / "target" / "release" / f"{name}{exe}")
    candidates.append(Path("/root/cm_target/release") / f"{name}{exe}")
    for cand in candidates:
        if cand.exists() and os.access(cand, os.X_OK):
            args = [str(cand)] + argv
            os.execv(str(cand), args)
            # unreachable
    print(
        f"fastsig: bundled binary {name!r} not found. Searched:\n  "
        + "\n  ".join(str(c) for c in candidates),
        file=sys.stderr,
    )
    return 127


def _run_py(module: str, func: str, argv: list) -> int:
    """Import module and invoke its main(), passing argv via sys.argv."""
    import importlib

    saved_argv = sys.argv
    sys.argv = [f"fastsig {module.split('.')[-1]}"] + argv
    try:
        mod = importlib.import_module(module)
        result = getattr(mod, func)()
        return int(result) if isinstance(result, int) else 0
    finally:
        sys.argv = saved_argv


def main() -> int:
    argv = sys.argv[1:]
    if not argv or argv[0] in ("-h", "--help", "help"):
        _print_help()
        return 0
    if argv[0] in ("-V", "--version", "version"):
        print(f"fastsig {__version__}")
        return 0

    sub = argv[0]
    rest = argv[1:]

    if sub in RUST_SUBCOMMANDS:
        return _exec_rust(RUST_SUBCOMMANDS[sub], rest)
    if sub in PY_SUBCOMMANDS:
        module, func = PY_SUBCOMMANDS[sub]
        return _run_py(module, func, rest)

    print(f"fastsig: unknown subcommand {sub!r}\n", file=sys.stderr)
    _print_help()
    return 2


if __name__ == "__main__":
    sys.exit(main())
