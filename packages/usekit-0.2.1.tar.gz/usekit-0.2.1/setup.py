# Minimal shim — all config lives in pyproject.toml.
# Kept for editable installs on older pip (<21.3).
from setuptools import setup
setup()
