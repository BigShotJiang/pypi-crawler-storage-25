class RemoteOps:
    @staticmethod
    def get_camera_cmd(os_type):
        """Returns the command to take a photo based on OS."""
        if "termux" in os_type.lower():
            return "termux-camera-photo -c 0 output.jpg"
        elif "linux" in os_type.lower():
            return "fswebcam --no-banner output.jpg"
        return "echo 'Camera not supported on this architecture via CLI.'"

    @staticmethod
    def get_gps_cmd(os_type):
        """Returns the command to get GPS coordinates."""
        if "termux" in os_type.lower():
            return "termux-location"
        elif "linux" in os_type.lower():
            return "nmcli device wifi list --rescan yes" # Wi-Fi based location
        return "echo 'GPS not supported on this architecture.'"

    @staticmethod
    def get_info_cmd():
        """Returns a generic broadcast info command."""
        return "uname -a; uptime; df -h"
