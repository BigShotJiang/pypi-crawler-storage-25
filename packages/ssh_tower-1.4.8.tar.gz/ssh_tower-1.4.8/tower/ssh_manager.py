import time
import paramiko
import logging
import sys
import os
import socket
import select, secrets
import shutil  # NEW: Used to get your exact terminal screen dimensions
from datetime import datetime

class SSHSession:
    def __init__(self, sec_mgr):
        self.client = paramiko.SSHClient()
        self.client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        self.sec_mgr = sec_mgr
        self.connected = False
        self.start_time = None
        self.current_ip = None
        self.current_name = None
        self.current_user = None

    def connect(self, name, profile):
        from tower.notifier import Notifier # Import here to avoid circular logic
        
        target_ip = profile["ip"]
        target_user = profile["user"]
        now = datetime.now().strftime("%H:%M:%S")

        # 1. NOTIFICATION: Starting
        Notifier.send("Tower: Connecting", f"Initiating link to {target_user}@{target_ip}...")

        try:
            password = self.sec_mgr.decrypt(profile["password"]) if "password" in profile else None
            key_path = profile.get("key_path")
            
            if key_path:
                self.client.connect(target_ip, port=profile.get("port", 22), 
                                    username=target_user, key_filename=key_path)
            else:
                self.client.connect(target_ip, port=profile.get("port", 22), 
                                    username=target_user, password=password)

            self.token = "TOWER_AUTHORIZED_CLIENT_V1"
            self.connected = True
            self.start_time = time.time()
            self.current_ip = target_ip
            self.current_name = name
            self.current_user = target_user

            # 2. NOTIFICATION: Success
            Notifier.send("Tower: Connected ✅", f"Linked to {target_user}@{target_ip}\nTime: {now}")
            
            return True, "Authenticated"
            
        except Exception as e:
            Notifier.send("Tower: Failed ❌", f"Could not connect to {target_ip}\nError: {str(e)}")
            return False, str(e)

    def interactive_shell(self):
        """Opens a live, fully interactive SSH PTY shell with Tower Token injection."""
        if not self.connected: return "Not connected."
        old_handler = signal.getsignal(signal.SIGINT)
        signal.signal(signal.SIGINT, signal.SIG_DFL)

        try:
            # 1. Grab terminal dimensions and type
            cols, rows = shutil.get_terminal_size((80, 24))
            term_type = os.environ.get("TERM", "xterm-256color")

            # --- NEW: Low-level channel configuration ---
            # Instead of calling self.client.invoke_shell() directly, we build the session manually
            channel = self.client.get_transport().open_session()
            
            # 2. Inject the secret TOWER_TOKEN
            # This 'token' must have been generated and saved to self.token during the connect() method
            token = getattr(self, 'token', 'NO_TOKEN')
            try:
                # We send the token as an environment variable
                channel.set_environment_variable('TOWER_TOKEN', token)
            except Exception as e:
                # Some SSH servers reject set_environment_variable by default
                logging.warning(f"Could not set TOWER_TOKEN: {e}")

            # 3. Request a Pseudo-Terminal (PTY) with our dimensions
            channel.get_pty(term=term_type, width=cols, height=rows)

            # 4. Now invoke the shell on this specific channel
            channel.invoke_shell()
            # --------------------------------------------

            print("\n\033[92m[!] Entering Live SSH Terminal. Type 'exit' or press Ctrl+D to return to the menu.\033[0m\n")

            try:
                import termios
                import tty
                has_termios = True
            except ImportError:
                has_termios = False

            if has_termios:
                oldtty = termios.tcgetattr(sys.stdin)
                try:
                    tty.setraw(sys.stdin.fileno())
                    tty.setcbreak(sys.stdin.fileno())
                    channel.settimeout(0.0)

                    while True:
                        r, w, e = select.select([channel, sys.stdin], [], [])

                        if channel in r:
                            try:
                                x = channel.recv(1024)
                                if len(x) == 0:
                                    break
                                sys.stdout.buffer.write(x)
                                sys.stdout.flush()
                            except socket.timeout:
                                pass

                        if sys.stdin in r:
                            x = os.read(sys.stdin.fileno(), 1)
                            if len(x) == 0:
                                break
                            channel.send(x)
                finally:
                    signal.signal(signal.SIGINT, old_handler)
                    termios.tcsetattr(sys.stdin, termios.TCSADRAIN, oldtty)
                    print("\r\n\033[93m[!] Exited Live Terminal.\033[0m\r\n")
            else:
                print("Live interactive shell requires a POSIX terminal (Linux/Termux).")

        except Exception as e:
            print(f"\r\n\033[91m[Error] Terminal dropped: {e}\033[0m\r\n")

    def execute(self, command):
        """Standard single-command execution with Tower Token bypass."""
        if not self.connected: return "Not connected."
        
        try:
            channel = self.client.get_transport().open_session()
            
            # Inject token to bypass gatekeeper
            token = getattr(self, 'token', 'NO_TOKEN')
            try:
                channel.set_environment_variable('TOWER_TOKEN', token)
            except: pass
            
            channel.exec_command(command)
            
            # Read output streams
            stdout = channel.makefile('r', -1).read()
            stderr = channel.makefile_stderr('r', -1).read()
            return stdout + stderr
        except Exception as e:
            return f"Command execution failed: {e}"

    def freeze_device(self):
        return self.execute('nohup python3 -c "while True: pass" > /dev/null 2>&1 & echo $!')

    def disconnect(self):
        if self.connected:
            duration = round(time.time() - self.start_time, 2)
            self.client.close()
            self.connected = False
            self.sec_mgr.log_connection(self.current_name, self.current_ip, f"{duration}s")

    def get_sftp(self):
        """Returns an SFTP client for file operations."""
        if not self.connected: return None
        return self.client.open_sftp()

    def download_file(self, remote_path, local_path):
        """Downloads a file from the remote device."""
        try:
            sftp = self.get_sftp()
            sftp.get(remote_path, local_path)
            sftp.close()
            return True, f"Downloaded to {local_path}"
        except Exception as e:
            return False, str(e)

    def upload_file(self, local_path, remote_path):
        """Uploads a file to the remote device."""
        try:
            sftp = self.get_sftp()
            sftp.put(local_path, remote_path)
            sftp.close()
            return True, f"Uploaded to {remote_path}"
        except Exception as e:
            return False, str(e)
