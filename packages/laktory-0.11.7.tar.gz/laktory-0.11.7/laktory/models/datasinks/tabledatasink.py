import os
import re
import shutil
from pathlib import Path
from typing import Any
from typing import Literal

from pydantic import Field
from pydantic import model_validator

from laktory._logger import get_logger
from laktory.enums import DataFrameBackends
from laktory.models.datasinks.basedatasink import BaseDataSink
from laktory.models.datasinks.tabledatasinkmetadata import TableDataSinkMetadata
from laktory.models.datasources.tabledatasource import TableDataSource

logger = get_logger(__name__)


class TableDataSink(BaseDataSink):
    catalog_name: str | None = Field(
        None,
        description="Sink table catalog name",
    )
    format: Literal["PARQUET", "DELTA"] = Field(
        "DELTA", description="Storage format for data table."
    )
    schema_name: str | None = Field(
        None,
        description="Sink table schema name",
    )
    metadata: TableDataSinkMetadata = Field(
        None, description="Table and columns metadata."
    )
    table_name: str = Field(
        ...,
        description="""
        Sink table name. Also supports fully qualified name (`{catalog}.{schema}.{table}`). 
        In this case, `catalog_name` and `schema_name` arguments are ignored.
        """,
    )
    table_type: Literal["TABLE", "VIEW"] = Field(
        "TABLE",
        description="Type of table. 'TABLE' and 'VIEW' are currently supported.",
    )

    @model_validator(mode="after")
    def validate_backend(self) -> Any:
        if self.dataframe_backend == DataFrameBackends.POLARS:
            raise ValueError(
                "Table data sink does not support the Polars backend. "
                "Use FileDataSink with DELTA format for Polars file-based writes."
            )
        return self

    @model_validator(mode="after")
    def validate_table_full_name(self) -> Any:
        name = self.table_name
        if name is None:
            return

        # names = re.findall(r"\$\{vars\.[^}]+\}|[^.]+", name)
        names = re.split(r"\.(?![^{}]*})", name)

        self._setattr("table_name", names[-1])
        if len(names) > 1:
            self._setattr("schema_name", names[-2])
        if len(names) > 2:
            self._setattr("catalog_name", names[-3])

        return self

    @model_validator(mode="after")
    def set_qm_table(self):
        if self.databricks_quality_monitor is None:
            return self
        self.databricks_quality_monitor._table = self
        return self

    # ----------------------------------------------------------------------- #
    # Properties                                                              #
    # ----------------------------------------------------------------------- #

    @property
    def is_sql_expressible(self) -> bool:
        if self.merge_cdc_options is not None:
            return False
        if self.custom_writer is not None:
            return False
        return self.mode in (None, "OVERWRITE", "APPEND")

    @property
    def full_name(self) -> str:
        """Table full name {catalog_name}.{schema_name}.{table_name}"""
        if self.table_name is None:
            return None

        name = ""
        if self.catalog_name is not None:
            name = self.catalog_name

        if self.schema_name is not None:
            if name == "":
                name = self.schema_name
            else:
                name += f".{self.schema_name}"

        if name == "":
            name = self.table_name
        else:
            name += f".{self.table_name}"

        return name

    @property
    def _id(self) -> str:
        return self.full_name

    # ----------------------------------------------------------------------- #
    # Children                                                                #
    # ----------------------------------------------------------------------- #

    @property
    def children_names(self):
        return [
            "metadata",
        ]

    # ----------------------------------------------------------------------- #
    # Create                                                                  #
    # ----------------------------------------------------------------------- #

    def create(self, df=None) -> bool:
        """
        Creates an empty table with the expected schema if it does not already exist.

        Returns True if the table was created, False otherwise.
        Schema is taken from `schema_definition` if set, otherwise inferred from `df`.
        """
        logger.info(f"Table '{self.full_name}' creation initiated.")

        # Skip for views
        if self.table_type == "VIEW":
            logger.info("Table is view. Skipping.")
            return False

        if self.exists():
            logger.info("Table exists. Skipping.")
            return False

        self._update_backend_from_df(df)
        schema = self._get_create_schema(df)

        if schema is None:
            logger.info("Schema is empty and `df` is None. Skipping table.")
            return False

        logger.info(f"Creating empty table '{self.full_name}'.")
        if self.dataframe_backend == DataFrameBackends.PYSPARK:
            from laktory import get_spark_session

            spark = get_spark_session()

            kwargs = {}
            path = self.writer_kwargs.get("path", None)
            if path:
                kwargs["path"] = path

            df_empty = spark.createDataFrame(data=[], schema=schema)
            df_empty.write.format(self.format.lower()).mode("ignore").options(
                **kwargs
            ).saveAsTable(self.full_name)

        else:
            raise NotImplementedError(
                f"Table Data Sink for '{self.dataframe_backend}' is not yet supported."
            )

        logger.info(f"Table '{self.full_name}' creation completed.")

        return True

    # ----------------------------------------------------------------------- #
    # Write                                                                   #
    # ----------------------------------------------------------------------- #

    def _write_spark(self, df, mode) -> None:
        df = df.to_native()

        # Format
        methods = self._get_spark_writer_methods(mode=mode, is_streaming=df.isStreaming)

        if df.isStreaming:
            logger.info(
                f"Writing df to {self.full_name} with writeStream.{'.'.join([m.as_string for m in methods])}"
            )

            writer = df.writeStream
            for m in methods:
                writer = getattr(writer, m.name)(*m.args, **m.kwargs)

            query = writer.toTable(self.full_name)
            query.awaitTermination()

        else:
            logger.info(
                f"Writing df to {self.full_name} with write.{'.'.join([m.as_string for m in methods])}"
            )
            writer = df.write
            for m in methods:
                writer = getattr(writer, m.name)(*m.args, **m.kwargs)

            writer.saveAsTable(self.full_name)

    def _write_spark_view(self, view_definition) -> None:
        from laktory import get_spark_session

        spark = get_spark_session()

        logger.info(f"Creating view {self.full_name} AS {view_definition.expr}")

        _view = view_definition.to_sql()
        df = spark.sql(f"CREATE OR REPLACE VIEW {self.full_name} AS {_view}")
        if self.parent_pipeline_node:
            self.parent_pipeline_node._output_df = df

    # ----------------------------------------------------------------------- #
    # Purge                                                                   #
    # ----------------------------------------------------------------------- #

    def exists(self):
        if self.dataframe_backend == DataFrameBackends.PYSPARK:
            from laktory import get_spark_session

            spark = get_spark_session()

            return spark.catalog.tableExists(self.full_name)

        else:
            raise NotImplementedError()

    def purge(self):
        """
        Delete sink data and checkpoints
        """

        if self.dataframe_backend == DataFrameBackends.PYSPARK:
            from laktory import get_spark_session

            spark = get_spark_session()

            # Remove Data
            logger.info(
                f"Dropping {self.table_type} {self.full_name}",
            )
            spark.sql(f"DROP {self.table_type} IF EXISTS {self.full_name}")

            path = self.writer_kwargs.get("path", None)
            if path:
                path = Path(path)
                if path.exists():
                    is_dir = path.is_dir()
                    if is_dir:
                        logger.info(f"Deleting data dir {path}")
                        shutil.rmtree(path)
                    else:
                        logger.info(f"Deleting data file {path}")
                        os.remove(path)

            # Remove Checkpoint
            self._purge_checkpoint()

        else:
            raise TypeError(
                f"DataFrame backend {self.dataframe_backend} is not supported."
            )

    # ----------------------------------------------------------------------- #
    # Source                                                                  #
    # ----------------------------------------------------------------------- #

    def as_source(
        self, as_stream=None, reader_kwargs=None, reader_methods=None
    ) -> TableDataSource:
        """
        Generate a table data source with the same properties as the sink.

        Parameters
        ----------
        as_stream:
            If `True`, sink will be read as stream.
        reader_kwargs:
            Keyword arguments passed to the dataframe backend reader.
        reader_methods:
            DataFrame backend reader methods.

        Returns
        -------
        :
            Table Data Source
        """
        source = TableDataSource(
            catalog_name=self.catalog_name,
            table_name=self.table_name,
            schema_name=self.schema_name,
            type=self.type,
            dataframe_backend=self.dataframe_backend,
        )

        if as_stream:
            source.as_stream = as_stream
        if reader_kwargs:
            source.reader_kwargs.update(reader_kwargs)
        if reader_methods:
            source.reader_methods.extend(reader_methods)

        if self.dataframe_backend_:
            source.dataframe_backend_ = self.dataframe_backend_
        source.parent = self.parent

        return source

    # ----------------------------------------------------------------------- #
    # Lakeflow Declarative Pipelines DLT                                      #
    # ----------------------------------------------------------------------- #

    @property
    def dlt_table_or_view_name(self) -> str:
        if self.catalog_name:
            # Unity catalog is used only when catalog is defined. In this case
            # DLT allows full name specification
            return self.full_name

        # If catalog is not defined, table is written to Hive Metastore and only table
        # name is allowed
        return self.table_name

    @property
    def dlt_table_or_view_kwargs(self):
        kwargs = {"name": self.dlt_table_or_view_name}
        if self.metadata:
            if self.metadata.comment:
                kwargs["comment"] = self.metadata.comment
            if self.metadata.properties:
                kwargs["table_properties"] = self.metadata.properties
        return kwargs

    @property
    def dlt_warning_expectations(self):
        e = {}
        if not self.is_quarantine:
            e = self.parent_pipeline_node.dlt_warning_expectations
        return e

    @property
    def dlt_drop_expectations(self):
        e = {}
        if not self.is_quarantine:
            e = self.parent_pipeline_node.dlt_drop_expectations
        return e

    @property
    def dlt_fail_expectations(self):
        e = {}
        if not self.is_quarantine:
            e = self.parent_pipeline_node.dlt_fail_expectations
        return e
