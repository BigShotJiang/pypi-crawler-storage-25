from pathlib import Path
from typing import Any

from pydantic import AliasChoices
from pydantic import Field
from pydantic import computed_field
from pydantic import model_validator

from laktory._settings import settings
from laktory.models.resources.databricks.accesscontrol import AccessControl
from laktory.models.resources.databricks.alert_base import *  # NOQA: F403 required for documentation
from laktory.models.resources.databricks.alert_base import AlertBase
from laktory.models.resources.databricks.permissions import Permissions


class Alert(AlertBase):
    """
    Databricks SQL Alert

    Examples
    --------
    ```py
    import io

    from laktory import models

    alert_yaml = '''
    display_name: high-stock-price
    parent_path: /alerts
    query_id: ${resources.query-stock-prices.id}
    condition:
      op: GREATER_THAN
      operand:
        column:
          name: close
      threshold:
        value:
          double_value: 500.0
    access_controls:
    - group_name: account users
      permission_level: CAN_VIEW
    '''
    alert = models.resources.databricks.Alert.model_validate_yaml(
        io.StringIO(alert_yaml)
    )
    ```

    References
    ----------

    * [Databricks SQL Alert](https://docs.databricks.com/api/workspace/alerts/create)
    """

    access_controls: list[AccessControl] = Field(
        [], description="SQL Alert access controls"
    )
    name_prefix: str = Field(None, description="Prefix added to the alert display name")
    name_suffix: str = Field(None, description="Suffix added to the alert display name")
    parent_path_: str | None = Field(
        None,
        description="""
        The path to a workspace folder (inside laktory root) containing the alert. If changed, the query will be
        recreated.
        """,
        validation_alias=AliasChoices("parent_path", "dirpath", "parent_path_"),
        exclude=True,
    )

    @computed_field(description="parent_path")
    @property
    def parent_path(self) -> str:
        if self.parent_path_ is None:
            self.parent_path_ = ""
        if self.parent_path_.startswith("/"):
            self.parent_path_ = self.parent_path_[1:]

        parent_path = Path(settings.workspace_root) / self.parent_path_
        return parent_path.as_posix()

    @model_validator(mode="after")
    def update_name(self) -> Any:
        if self.name_prefix:
            self._setattr("display_name", self.name_prefix + self.display_name)
            self._setattr("name_prefix", "")
        if self.name_suffix:
            self._setattr("display_name", self.display_name + self.name_suffix)
            self._setattr("name_suffix", "")
        return self

    # ----------------------------------------------------------------------- #
    # Resource Properties                                                     #
    # ----------------------------------------------------------------------- #

    @property
    def resource_key(self) -> str:
        return self.display_name.replace(" ", "_")

    @property
    def additional_core_resources(self) -> list:
        """
        - permissions
        """
        resources = []
        if self.access_controls:
            resources += [
                Permissions(
                    resource_options={"name": f"permissions-{self.resource_name}"},
                    access_controls=self.access_controls,
                    sql_alert_id=f"${{resources.{self.resource_name}.id}}",
                )
            ]

        return resources

    # ----------------------------------------------------------------------- #
    # Terraform Properties                                                    #
    # ----------------------------------------------------------------------- #

    @property
    def terraform_excludes(self) -> list[str] | dict[str, bool]:
        return ["access_controls", "dirpath", "name_prefix", "name_suffix"]
