import os
from pathlib import Path

from pydantic import AliasChoices
from pydantic import Field
from pydantic import computed_field

from laktory.models.resources.baseresource import ResourceLookup
from laktory.models.resources.databricks.accesscontrol import AccessControl
from laktory.models.resources.databricks.dbfsfile_base import *  # NOQA: F403 required for documentation
from laktory.models.resources.databricks.dbfsfile_base import DbfsFileBase
from laktory.models.resources.databricks.permissions import Permissions


class DbfsFileLookup(ResourceLookup):
    path: str = Field(
        serialization_alias="id",
        description="Path on DBFS for the file from which to get content.",
    )
    limit_file_size: bool = Field(
        True, description="Do not load content for files larger than 4MB."
    )


class DbfsFile(DbfsFileBase):
    """
    Databricks DBFS File

    Examples
    --------
    ```py
    import io

    from laktory import models

    file_yaml = '''
    source: ./data/stock_prices/prices.json
    dirpath: stock_prices/
    '''
    file = models.resources.databricks.DbfsFile.model_validate_yaml(
        io.StringIO(file_yaml)
    )
    print(file.path)
    # > /stock_prices/prices.json
    ```

    References
    ----------

    * [Databricks DBFS File](https://registry.terraform.io/providers/databricks/databricks/latest/docs/resources/dbfs_file)
    """

    access_controls: list[AccessControl] = Field(
        [], description="List of file access controls"
    )
    dirpath: str = Field(
        None,
        description="""
    Workspace directory inside rootpath in which the DBFS file is deployed. Used only if `path` is not specified.
    """,
    )
    lookup_existing: DbfsFileLookup = Field(
        None,
        exclude=True,
        description="Import a pre-existing DBFS file by `path` instead of creating it. The file becomes available for cross-referencing; its own field values are not written to the existing resource.",
    )
    path_: str = Field(
        None,
        description="DBFS filepath for the file. Overwrite `dirpath`.",
        validation_alias=AliasChoices("path", "path_"),
        exclude=True,
    )

    @computed_field(description="path")
    @property
    def path(self) -> str | None:
        if self.path_:
            return self.path_

        # dir
        if self.dirpath is None:
            self.dirpath = ""
        if self.dirpath.startswith("/"):
            self.dirpath = self.dirpath[1:]

        path = Path("/") / self.dirpath / self.filename
        return path.as_posix()

    @classmethod
    def lookup_defaults(cls) -> dict:
        return {"path": ""}

    @property
    def filename(self) -> str:
        """File filename"""
        return os.path.basename(self.source)

    # ----------------------------------------------------------------------- #
    # Resource Properties                                                     #
    # ----------------------------------------------------------------------- #

    @property
    def resource_key(self) -> str:
        return self.path

    @property
    def additional_core_resources(self) -> list:
        resources = []
        if self.access_controls:
            resources += [
                Permissions(
                    resource_options={"name": f"permissions-{self.resource_name}"},
                    access_controls=self.access_controls,
                    workspace_file_path=f"${{resources.{self.resource_name}.path}}",
                )
            ]
        return resources

    # ----------------------------------------------------------------------- #
    # Terraform Properties                                                    #
    # ----------------------------------------------------------------------- #

    @property
    def terraform_excludes(self) -> list[str] | dict[str, bool]:
        return ["access_controls", "dirpath"]
