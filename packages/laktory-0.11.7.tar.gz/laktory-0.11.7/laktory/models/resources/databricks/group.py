from pydantic import Field

from laktory.models.resources.baseresource import ResourceLookup
from laktory.models.resources.databricks.group_base import *  # NOQA: F403 required for documentation
from laktory.models.resources.databricks.group_base import GroupBase
from laktory.models.resources.databricks.groupmember import GroupMember
from laktory.models.resources.databricks.mwspermissionassignment import (
    MwsPermissionAssignment,
)


class GroupLookup(ResourceLookup):
    id: str = Field(None, description="Id of the group.")
    display_name: str = Field(
        None,
        description="Display name of the group. Only support when using Terraform backend",
    )


class Group(GroupBase):
    """
    Databricks group

    Examples
    --------
    ```py
    import io

    from laktory import models

    group_yaml = '''
    display_name: role-engineers
    member_ids:
    - ${resources.user-john.id}
    - ${resources.sp-neptune.id}
    '''
    group = models.resources.databricks.Group.model_validate_yaml(
        io.StringIO(group_yaml)
    )
    ```

    References
    ----------

    * [Databricks Group](https://docs.databricks.com/en/administration-guide/users-groups/groups.html)
    """

    lookup_existing: GroupLookup = Field(
        None,
        exclude=True,
        description="Import a pre-existing Group by `id` or `display_name` instead of creating it. The group becomes available for cross-referencing and child resource deployment (grants, etc.); its own field values are not written to the existing resource.",
    )
    member_ids: list[str] = Field(
        [],
        description="A list of all member ids of the group. Can be users, groups or service principals",
    )
    workspace_permission_assignments: list[MwsPermissionAssignment] = Field(
        None, description="Workspace access privileges"
    )

    # ----------------------------------------------------------------------- #
    # Resource Properties                                                     #
    # ----------------------------------------------------------------------- #

    @property
    def resource_key(self) -> str:
        """display name or id"""
        lookup_display_name = (
            self.lookup_existing.display_name if self.lookup_existing else None
        )
        lookup_id = self.lookup_existing.id if self.lookup_existing else None
        return next(
            (
                attr
                for attr in (
                    self.display_name,
                    self.external_id,
                    lookup_display_name,
                    lookup_id,
                )
                if attr is not None
            ),
            "",
        )

    @property
    def additional_core_resources(self) -> list:
        """
        - workspace permission assignments
        """
        resources = []

        # Group Members
        for member_id in self.member_ids:
            resources += [
                GroupMember(
                    group_id=f"${{resources.{self.resource_name}.id}}",
                    member_id=member_id,
                )
            ]

        if self.workspace_permission_assignments:
            for a in self.workspace_permission_assignments:
                if a.principal_id is None:
                    a.principal_id = f"${{resources.{self.resource_name}.id}}"
                resources += [a]
        return resources

    # ----------------------------------------------------------------------- #
    # Terraform Properties                                                    #
    # ----------------------------------------------------------------------- #

    @property
    def terraform_excludes(self) -> list[str] | dict[str, bool]:
        return ["member_ids", "workspace_permission_assignments"]
