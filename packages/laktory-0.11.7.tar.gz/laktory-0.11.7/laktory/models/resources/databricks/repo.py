from pydantic import Field

from laktory.models.basemodel import BaseModel
from laktory.models.resources.databricks.accesscontrol import AccessControl
from laktory.models.resources.databricks.permissions import Permissions
from laktory.models.resources.databricks.repo_base import *  # NOQA: F403 required for documentation
from laktory.models.resources.databricks.repo_base import RepoBase


class RepoSparseCheckout(BaseModel):
    patterns: list[str] = Field(
        ...,
        description="""
    array of paths (directories) that will be used for sparse checkout. List of patterns could be updated in-place. 
    Addition or removal of the `sparse_checkout` configuration block will lead to recreation of the Git folder.
    """,
    )


class Repo(RepoBase):
    """
    Databricks Repo

    Examples
    --------
    ```py
    import io

    from laktory import models

    repo_yaml = '''
    url: https://github.com/okube-ai/laktory
    path: /Users/olivier.soucy@okube.ai/laktory-repo
    branch: main
    access_controls:
    - group_name: account users
      permission_level: CAN_READ
    '''
    repo = models.resources.databricks.Repo.model_validate_yaml(io.StringIO(repo_yaml))
    ```

    References
    ----------

    * [Databricks Repo](https://www.databricks.com/product/repos)

    """

    access_controls: list[AccessControl] = Field(
        [], description="List of access controls"
    )

    # ----------------------------------------------------------------------- #
    # Resource Properties                                                     #
    # ----------------------------------------------------------------------- #

    @property
    def additional_core_resources(self) -> list:
        """
        - permissions
        """
        resources = []
        if self.access_controls:
            resources += [
                Permissions(
                    resource_options={"name": f"permissions-{self.resource_name}"},
                    access_controls=self.access_controls,
                    repo_id=f"${{resources.{self.resource_name}.id}}",
                )
            ]
        return resources

    # ----------------------------------------------------------------------- #
    # Terraform Properties                                                    #
    # ----------------------------------------------------------------------- #

    @property
    def terraform_excludes(self) -> list[str] | dict[str, bool]:
        return ["access_controls"]
