from pydantic import Field

from laktory.models.basemodel import BaseModel
from laktory.models.resources.baseresource import ResourceLookup
from laktory.models.resources.databricks.accesscontrol import AccessControl
from laktory.models.resources.databricks.mlflowmodel_base import *  # NOQA: F403 required for documentation
from laktory.models.resources.databricks.mlflowmodel_base import MlflowModelBase
from laktory.models.resources.databricks.permissions import Permissions


class MlflowModelTag(BaseModel):
    key: str = Field(..., description="")
    value: str = Field(..., description="")


class MLflowModelLookup(ResourceLookup):
    name: str = Field(description="Name of the MLflow registered model")


class MLflowModel(MlflowModelBase):
    """
    MLflow Model

    Examples
    --------
    ```py
    import io

    from laktory import models

    model_yaml = '''
    name: my-mlflow-model
    description: My MLflow model description
    tags:
    - key: key1
      value: value1
    - key: key2
      value: value2
    access_controls:
    - group_name: account users
      permission_level: CAN_MANAGE_PRODUCTION_VERSIONS
    '''
    mlmodel = models.resources.databricks.MLflowModel.model_validate_yaml(
        io.StringIO(model_yaml)
    )
    ```

    References
    ----------

    * [MLflow Model Registry](https://mlflow.org/docs/latest/model-registry.html)
    """

    access_controls: list[AccessControl] = Field([], description="Access controls list")
    lookup_existing: MLflowModelLookup = Field(
        None,
        exclude=True,
        description="Import a pre-existing MLflow Model by `name` instead of creating it. The model becomes available for cross-referencing; its own field values are not written to the existing resource.",
    )

    # ----------------------------------------------------------------------- #
    # Resource Properties                                                     #
    # ----------------------------------------------------------------------- #

    @property
    def resource_key(self) -> str:
        return self.name

    @property
    def additional_core_resources(self) -> list:
        """
        - permissions
        """
        resources = []
        if self.access_controls:
            resources += [
                Permissions(
                    resource_options={"name": f"permissions-{self.resource_name}"},
                    access_controls=self.access_controls,
                    registered_model_id=f"${{resources.{self.resource_name}.registered_model_id}}",
                )
            ]

        return resources

    # ----------------------------------------------------------------------- #
    # Terraform Properties                                                    #
    # ----------------------------------------------------------------------- #

    @property
    def terraform_excludes(self) -> list[str] | dict[str, bool]:
        return ["access_controls"]
