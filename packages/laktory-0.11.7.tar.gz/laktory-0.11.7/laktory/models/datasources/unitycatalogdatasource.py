from typing import Any
from typing import Literal

from pydantic import Field
from pydantic import model_validator

from laktory._logger import get_logger
from laktory.enums import DataFrameBackends
from laktory.models.datasources.tabledatasource import TableDataSource

logger = get_logger(__name__)


# class Connection(BaseModel):
#     workspace_url: str
#     bearer_token: str = "auto"
#     require_https: bool = True


class UnityCatalogDataSource(TableDataSource):
    """
    Data source using a Unity Catalog data table.

    Examples
    ---------
    ```python
    from laktory import models

    source = models.UnityCatalogDataSource(
        catalog_name="dev",
        schema_name="finance",
        table_name="brz_stock_prices",
        selects=["symbol", "open", "close"],
        filter="symbol='AAPL'",
        as_stream=True,
    )
    # df = source.read()
    ```
    References
    ----------
    * [Data Sources and Sinks](https://www.laktory.ai/concepts/sourcessinks/)
    """

    # connection: Connection = None
    type: Literal["UNITY_CATALOG"] = Field(
        "UNITY_CATALOG", frozen=True, description="Source Type"
    )

    @model_validator(mode="after")
    def validate_backend(self) -> Any:
        if self.dataframe_backend == DataFrameBackends.POLARS:
            raise ValueError(
                "Unity Catalog data source does not support the Polars backend."
            )
        return self
