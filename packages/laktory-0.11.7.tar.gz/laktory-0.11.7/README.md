# Laktory

[![pypi](https://img.shields.io/pypi/v/laktory.svg)](https://pypi.org/project/laktory/)
[![test](https://github.com/okube-ai/laktory/actions/workflows/test.yml/badge.svg)](https://github.com/okube-ai/laktory/actions/workflows/test.yml)
[![downloads](https://static.pepy.tech/badge/laktory/month)](https://pepy.tech/project/laktory)
[![versions](https://img.shields.io/pypi/pyversions/laktory.svg)](https://github.com/okube-ai/laktory)
[![license](https://img.shields.io/github/license/okube-ai/laktory.svg)](https://github.com/okube-ai/laktory/blob/main/LICENSE)

An open-source DataOps and dataframe-centric ETL framework for building lakehouses.
Use it standalone or extend your existing DABs setup with it.

<img src="docs/images/logos/laktory_logo_sg.png" alt="laktory logo" width="85"/>

Laktory is an all-in-one solution for defining both data transformations and Databricks
resources. Imagine if Declarative Automation Bundles (DAB) supported any Databricks resources
and offered a declarative approach to data transformations, that's essentially
Laktory.

Deploy it standalone as your full Databricks DataOps platform, or add it alongside
your existing DAB setup to manage pipeline definitions
and the resources DAB doesn't cover.

This open-source framework streamlines the creation, deployment, and execution
of data pipelines while adhering to essential DevOps practices such as version
control, code reviews, and CI/CD integration. Powered by Narwhals, Laktory
enables seamless transitions between Apache Spark, Polars, and other frameworks
to perform data transformations reliably and at scale. Its modular and flexible
design allows you to effortlessly combine SQL statements with DataFrame
operations, reducing complexity and enhancing productivity.

<img src="docs/images/diagrams/laktory_diagram.png" alt="what is laktory" width="800"/>

Since Laktory pipelines are built on top of Narwhals, they can run in
any environment that supports Python, from your local machine to a Kubernetes 
cluster. Pipelines can be orchestrated using tools like Apache Airflow or
deployed directly as Databricks Jobs or
[Declarative Pipelines](https://www.databricks.com/product/data-engineering/lakeflow-declarative-pipelines),
offering both flexible and fully managed execution options.

But Laktory goes beyond data pipelines. It empowers you to define and deploy your entire
Databricks data platform, from Unity Catalog and access grants to compute and quality
monitoring. This empowers your data team to take full ownership of the solution,
eliminating the need to juggle multiple technologies.

No more splitting ownership between Terraform for infrastructure and DAB for
workflows. With Laktory, the team that builds the pipelines can own the stack
end to end.

<img src="docs/images/diagrams/why_simplicity.png" alt="dataops" width="500"/>

## Help
See [documentation](https://www.laktory.ai/) for more details.

## Installation
Install using 
```commandline
pip install laktory
```

For more installation options,
see the [Install](https://www.laktory.ai/install/) section in the documentation.

## A Basic Example
```py
from laktory import models


node_brz = models.PipelineNode(
    name="brz_stock_prices",
    source={
        "format": "PARQUET",
        "path": "./data/brz_stock_prices/"
    },
    transformer={
        "nodes": []
    }
)

node_slv = models.PipelineNode(
    name="slv_stock_prices",
    source={
        "node_name": "brz_stock_prices"
    },
    sinks=[{
        "path": "./data/slv_stock_prices",
        "mode": "OVERWRITE",
        "format": "PARQUET",
    }],
    transformer={
        "nodes": [
            
            # SQL Transformation
            {
                "expr": """
                    SELECT
                      data.created_at AS created_at,
                      data.symbol AS symbol,
                      data.open AS open,
                      data.close AS close,
                      data.high AS high,
                      data.low AS low,
                      data.volume AS volume
                    FROM
                      {df}
                """   
            },
            
            # Spark Transformation
            {
                "func_name": "drop_duplicates",
                "func_kwargs": {
                    "subset": ["created_at", "symbol"]
                }
            },
        ]
    }
)

pipeline = models.Pipeline(
    name="stock_prices",
    nodes=[node_brz, node_slv],
)

pipeline.execute(spark=spark)
```

To get started with a more useful example, jump into the [Quickstart](https://www.laktory.ai/quickstart/).

## Get Involved
Laktory is growing rapidly, and we'd love for you to be part of our journey! Here's how 
you can get involved:
- **Join the Community**: Connect with fellow Laktory users and contributors on our [Slack](http://okube.slack.com/). Share ideas, ask questions, and collaborate!
- **Suggest Features or Report Issues**: Have an idea for a new feature or encountering an issue? Let us know on [GitHub Issues](https://github.com/okube-ai/laktory/issues). Your feedback helps shape the future of Laktory!
- **Contribute to Laktory**: Check out our [contributing guide](CONTRIBUTING.md) to learn how you can tackle issues and add value to the project.

## A Lakehouse DataOps Template
A comprehensive template on how to deploy a lakehouse as code using Laktory is maintained here:
https://github.com/okube-ai/lakehouse-as-code

In this template, 4 stacks are used to:
- `{cloud_provider}_infra`: Deploy the required resources on your cloud provider
- `unity-catalog`: Setup users, groups, catalogs, schemas and manage grants
- `workspace`: Setup secrets, clusters and warehouses and common files/notebooks
- `workflows`: The data workflows to build your lakehouse

## Okube Company
<img src="docs/images/logos/okube_logo.png" alt="okube logo" width="85"/>

[Okube](https://www.okube.ai) is dedicated to building open source frameworks, known as the *kubes*, empowering businesses to build, deploy and operate highly scalable data platforms and AI models.

