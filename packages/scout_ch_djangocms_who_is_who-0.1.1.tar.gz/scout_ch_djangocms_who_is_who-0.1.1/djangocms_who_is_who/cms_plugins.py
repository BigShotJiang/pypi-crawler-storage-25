import requests
from cms.plugin_base import CMSPluginBase
from cms.plugin_pool import plugin_pool
from django.utils.html import mark_safe
from django.utils.translation import gettext as _
from requests.auth import HTTPBasicAuth
from urllib3.util import Retry
from requests.adapters import HTTPAdapter

from .forms import WhoIsWhoPluginForm
from .models import WhoIsWhoPluginModel


@plugin_pool.register_plugin
class WhoIsWhoPublisher(CMSPluginBase):
    model = WhoIsWhoPluginModel
    form = WhoIsWhoPluginForm
    module = _("WhoIsWho")
    name = _("WhoIsWho Plugin")
    render_template = "djangocms_who_is_who/djangocms_who_is_who.html.jinja"


    def render(self, context, instance, placeholder):
        self.update_content(context, instance)

        context.update({
            "html_content": mark_safe(instance.cached_html),
            "stylesheet": mark_safe(instance.cached_stylesheet),
            "script": mark_safe(instance.cached_script),
        })

        return context

    def update_content(self, context, instance):
        session = requests.Session()
        retries = Retry(
            total=3,
            backoff_factor=0.1,
            status_forcelist=[502, 503, 504],
            allowed_methods={'POST'},
        )
        session.mount('https://', HTTPAdapter(max_retries=retries))
        errors = []
        if instance.use_auth:
            session.auth = HTTPBasicAuth(instance.auth_user, instance.auth_password)

        try:
            html_content = self.get_content(
                instance, session, route=f"html/{instance.locale}/{instance.midata_group_index}"
            )
            # Link images to api host and update the instance versions for html, css, js
            instance.cached_html = html_content.replace(
                "/api/image", instance.who_is_who_url + "image"
            )
        except Exception as e:
            errors.append(str(e))

        try:
            instance.cached_stylesheet = self.get_content(instance, session, "/static/styles.css")
        except Exception as e:
            errors.append(str(e))

        try:
            instance.cached_script = self.get_content(instance, session, "/static/script.js")
        except Exception as e:
            errors.append(str(e))

        context.update({"error": str('\n'.join(errors))})

    def get_content(self, instance, session: Session, route="", backend_prefix="/api"):
        url = self.construct_url(instance.who_is_who_url, route, backend_prefix)
        res = session.get(url)
        res.raise_for_status()
        return res.text

    def construct_url(self, url, route, prefix):
        # Ensure that the host URL does not end with a slash which would result in an invalid address
        if url[-1] == "/":
            url = url[:-1]
        return url + prefix + route
