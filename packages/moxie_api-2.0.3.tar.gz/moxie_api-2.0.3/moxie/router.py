from typing import Any, Callable, Dict, List, Optional, Sequence, Union
from moxie.routing.matcher import CompiledRouter
from moxie.guards.base import Guard

class Route:
    __slots__ = (
        "path", 
        "methods", 
        "handler", 
        "name", 
        "tags", 
        "guards",
        "summary",
        "description",
        "operation_id",
        "deprecated",
        "include_in_schema",
        "responses",
    )
    
    def __init__(
        self,
        path: str,
        handler: Callable[..., Any],
        methods: List[str],
        name: Optional[str] = None,
        tags: Optional[List[str]] = None,
        guards: Optional[List[Guard]] = None,
        summary: Optional[str] = None,
        description: Optional[str] = None,
        operation_id: Optional[str] = None,
        deprecated: bool = False,
        include_in_schema: bool = True,
        responses: Optional[Dict[Union[int, str], Dict[str, Any]]] = None,
    ) -> None:
        self.path = path
        self.handler = handler
        self.methods = methods
        self.name = name or handler.__name__
        self.tags = tags or []
        self.guards = guards or []
        self.summary = summary
        self.description = description
        self.operation_id = operation_id or self.name
        self.deprecated = deprecated
        self.include_in_schema = include_in_schema
        self.responses = responses or {}

class WebSocketRoute(Route):
    def __init__(
        self,
        path: str,
        handler: Callable[..., Any],
        name: Optional[str] = None,
        tags: Optional[List[str]] = None,
        guards: Optional[List[Guard]] = None,
    ) -> None:
        super().__init__(
            path, 
            handler, 
            methods=["WS"], 
            name=name, 
            tags=tags, 
            guards=guards,
            include_in_schema=True
        )

class Router:
    def __init__(self, prefix: str = "", guards: Optional[List[Guard]] = None) -> None:
        self.prefix = prefix
        self.routes: List[Union[Route, WebSocketRoute]] = []
        self.guards = guards or []
        self._compiled_router: Optional[CompiledRouter] = None

    def add_route(
        self,
        path: str,
        handler: Callable[..., Any],
        methods: List[str],
        name: Optional[str] = None,
        tags: Optional[List[str]] = None,
        guards: Optional[List[Guard]] = None,
        **openapi_kwargs: Any,
    ) -> None:
        full_path = self.prefix + path
        all_guards = self.guards + (guards or [])
        
        route = Route(
            full_path, 
            handler, 
            [m.upper() for m in methods], 
            name=name, 
            tags=tags, 
            guards=all_guards,
            **openapi_kwargs
        )
        self.routes.append(route)
        self._compiled_router = None

    def add_ws_route(
        self,
        path: str,
        handler: Callable[..., Any],
        name: Optional[str] = None,
        tags: Optional[List[str]] = None,
        guards: Optional[List[Guard]] = None,
    ) -> None:
        full_path = self.prefix + path
        all_guards = self.guards + (guards or [])
        self.routes.append(WebSocketRoute(full_path, handler, name, tags, all_guards))
        self._compiled_router = None

    def ws(self, path: str, **kwargs: Any) -> Callable[[Callable[..., Any]], Callable[..., Any]]:
        def decorator(handler: Callable[..., Any]) -> Callable[..., Any]:
            self.add_ws_route(path, handler, **kwargs)
            return handler
        return decorator

    def get(self, path: str, **kwargs: Any) -> Callable[[Callable[..., Any]], Callable[..., Any]]:
        return self._add_method_route(path, ["GET"], **kwargs)

    def post(self, path: str, **kwargs: Any) -> Callable[[Callable[..., Any]], Callable[..., Any]]:
        return self._add_method_route(path, ["POST"], **kwargs)

    def put(self, path: str, **kwargs: Any) -> Callable[[Callable[..., Any]], Callable[..., Any]]:
        return self._add_method_route(path, ["PUT"], **kwargs)

    def delete(self, path: str, **kwargs: Any) -> Callable[[Callable[..., Any]], Callable[..., Any]]:
        return self._add_method_route(path, ["DELETE"], **kwargs)

    def patch(self, path: str, **kwargs: Any) -> Callable[[Callable[..., Any]], Callable[..., Any]]:
        return self._add_method_route(path, ["PATCH"], **kwargs)

    def _add_method_route(
        self, path: str, methods: List[str], **kwargs: Any
    ) -> Callable[[Callable[..., Any]], Callable[..., Any]]:
        def decorator(handler: Callable[..., Any]) -> Callable[..., Any]:
            self.add_route(path, handler, methods, **kwargs)
            return handler
        return decorator

    def mount(self, router: "Router") -> None:
        for route in router.routes:
            self.routes.append(route)
            self._compiled_router = None

    @property
    def compiled_router(self) -> CompiledRouter:
        if self._compiled_router is None:
            self._compiled_router = CompiledRouter()
            for route in self.routes:
                self._compiled_router.add_route(route)
        return self._compiled_router
