from __future__ import annotations
import errno
import os
import re
import select
import subprocess
import threading
import time
import typing as t
from contextlib import suppress
from pathlib import Path

from rich.console import Console as RichConsole
from rich.live import Live

from crackerjack.models.protocols import ConsoleInterface

from .test_progress import TestProgress


class TestExecutor:
    __test__ = False

    def __init__(self, console: RichConsole, pkg_path: Path) -> None:
        self.console = console
        self.pkg_path = pkg_path

    def _detect_target_project_dir(self, cmd: list[str]) -> Path:
        test_start_idx = self._find_pytest_index(cmd)

        if test_start_idx > 0 and test_start_idx < len(cmd):
            return self._find_project_from_test_args(cmd[test_start_idx:])

        return self.pkg_path

    def _find_pytest_index(self, cmd: list[str]) -> int:
        for i, arg in enumerate(cmd):
            if arg == "pytest":
                return i + 1
        return -1

    def _find_project_from_test_args(self, test_args: list[str]) -> Path:
        for arg in test_args:
            if arg.startswith("-"):
                continue

            test_path = Path(arg)
            if test_path.exists():
                return self._get_project_dir_from_path(test_path)

        return self.pkg_path

    def _get_project_dir_from_path(self, test_path: Path) -> Path:
        if test_path.is_dir():
            return test_path.parent
        if test_path.is_file():
            return test_path.parent.parent
        return test_path.parent

    def execute_with_progress(
        self,
        cmd: list[str],
        timeout: int = 1800,
    ) -> subprocess.CompletedProcess[str]:

        total_tests = self._pre_collect_tests(cmd)
        progress = self._initialize_progress()
        if total_tests > 0:
            progress.update(total_tests=total_tests)

            progress.collection_status = (
                f"Pre-collected {total_tests} tests, starting execution..."
            )

        return self._execute_with_live_progress(cmd, timeout, progress=progress)

    def execute_with_ai_progress(
        self,
        cmd: list[str],
        progress_callback: t.Callable[[dict[str, t.Any]], None],
        timeout: int = 1800,
    ) -> subprocess.CompletedProcess[str]:

        total_tests = self._pre_collect_tests(cmd)
        progress = self._initialize_progress()
        if total_tests > 0:
            progress.update(total_tests=total_tests)

            progress.collection_status = (
                f"Pre-collected {total_tests} tests, starting execution..."
            )

        return self._run_test_command_with_ai_progress(
            cmd,
            progress_callback,
            timeout,
            progress=progress,
        )

    def _pre_collect_tests(self, original_cmd: list[str]) -> int:
        return 0

    def _execute_with_live_progress(
        self,
        cmd: list[str],
        timeout: int,
        progress: TestProgress | None = None,
    ) -> subprocess.CompletedProcess[str]:
        if progress is None:
            progress = self._initialize_progress()

        if self._should_try_xdist_fallback(cmd):
            return self._run_with_xdist_fallback(cmd, progress, None, timeout)

        with Live(
            progress.format_progress(),
            console=self.console,
            transient=True,
        ) as live:
            env = self._setup_test_environment()

            process = subprocess.Popen(
                cmd,
                cwd=self._detect_target_project_dir(cmd),
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                bufsize=1,
                universal_newlines=True,
                env=env,
            )

            stdout_thread, stderr_thread, monitor_thread = self._start_reader_threads(
                process,
                progress,
                live,
            )

            try:
                process.wait(timeout=timeout)
            except subprocess.TimeoutExpired:
                self._handle_progress_error(
                    process,
                    progress,
                    "Test execution timed out",
                )

            self._cleanup_threads([stdout_thread, stderr_thread, monitor_thread])

            stdout_str = progress.get_stdout()
            stderr_str = progress.get_stderr()
            return subprocess.CompletedProcess(
                cmd,
                process.returncode,
                stdout_str,
                stderr_str,
            )

    def _run_test_command_with_ai_progress(
        self,
        cmd: list[str],
        progress_callback: t.Callable[[dict[str, t.Any]], None],
        timeout: int = 600,
        progress: TestProgress | None = None,
    ) -> subprocess.CompletedProcess[str]:
        if progress is None:
            progress = self._initialize_progress()

        if self._should_try_xdist_fallback(cmd):
            return self._run_with_xdist_fallback(
                cmd, progress, progress_callback, timeout
            )

        env = self._setup_coverage_env()
        return self._execute_test_process_with_progress(
            cmd,
            env,
            progress,
            progress_callback,
            timeout,
        )

    def _should_try_xdist_fallback(self, cmd: list[str]) -> bool:
        try:
            from crackerjack.config import load_settings
            from crackerjack.config.settings import CrackerjackSettings

            settings = load_settings(CrackerjackSettings)
            has_n_flag = "-n" in cmd
            worker_count = (
                self._get_optimal_worker_count_from_cmd(cmd) if has_n_flag else 1
            )

            self.console.print(
                f"[dim]DEBUG: xdist_fallback_to_sequential={settings.testing.xdist_fallback_to_sequential}, "
                f"has_n_flag={has_n_flag}, worker_count={worker_count}[/dim]"
            )

            return (
                settings.testing.xdist_fallback_to_sequential
                and has_n_flag
                and worker_count > 1
            )
        except Exception as e:
            self.console.print(
                f"[yellow]DEBUG: Exception in _should_try_xdist_fallback: {e}[/yellow]"
            )
            return False

    def _get_optimal_worker_count_from_cmd(self, cmd: list[str]) -> int:
        from contextlib import suppress

        with suppress(Exception):
            if "-n" in cmd:
                idx = cmd.index("-n")
                if idx + 1 < len(cmd):
                    workers_arg = cmd[idx + 1]
                    if workers_arg == "auto":
                        return 4
                    with suppress(ValueError):
                        return int(workers_arg)
        return 1

    def _run_with_xdist_fallback(
        self,
        cmd: list[str],
        progress: TestProgress,
        progress_callback: t.Callable[[dict[str, t.Any]], None],
        timeout: int,
    ) -> subprocess.CompletedProcess[str]:
        from crackerjack.config import load_settings
        from crackerjack.config.settings import CrackerjackSettings

        settings = load_settings(CrackerjackSettings)
        xdist_timeout = settings.testing.xdist_timeout_seconds

        self.console.print(
            f"[dim]Trying parallel execution with {xdist_timeout}s timeout (will fall back to sequential if xdist hangs)...[/dim]",
        )

        env = self._setup_coverage_env()
        parallel_result = self._execute_test_process_with_progress(
            cmd,
            env,
            progress,
            progress_callback,
            xdist_timeout,
        )

        self.console.print(
            f"[dim]DEBUG: parallel_result.returncode={parallel_result.returncode}, "
            f"_did_xdist_timeout={self._did_xdist_timeout(parallel_result, progress)}[/dim]"
        )

        if parallel_result.returncode < 0 or self._did_xdist_timeout(
            parallel_result, progress
        ):
            self.console.print(
                "[yellow]⚠️ Parallel execution timed out or failed, falling back to sequential...[/yellow]",
            )

            sequential_cmd = self._remove_xdist_from_cmd(cmd)
            self.console.print(f"[dim]DEBUG: sequential_cmd={sequential_cmd}[/dim]")
            return self._execute_test_process_with_progress(
                sequential_cmd,
                env,
                progress,
                progress_callback,
                timeout,
            )

        return parallel_result

    def _did_xdist_timeout(
        self,
        result: subprocess.CompletedProcess,
        progress: TestProgress,
    ) -> bool:

        if result.returncode < 0:
            completed = (
                progress.passed + progress.failed + progress.skipped + progress.errors
            )
            if completed == 0:
                return True

        error_indicators = [
            "worker crashed",
            "workers did not finish",
            "xdist",
            "timeout",
            "hung",
        ]

        combined_output = (result.stdout or "") + (result.stderr or "")
        combined_lower = combined_output.lower()

        return any(indicator in combined_lower for indicator in error_indicators)

    def _remove_xdist_from_cmd(self, cmd: list[str]) -> list[str]:
        new_cmd = []
        skip_next = False

        for arg in cmd:
            if skip_next:
                skip_next = False
                continue

            if arg == "-n":
                skip_next = True
                continue

            if arg.startswith("--dist="):
                continue

            new_cmd.append(arg)

        return new_cmd

    def _initialize_progress(self) -> TestProgress:
        progress = TestProgress()
        progress.start_time = time.time()
        return progress

    def _setup_test_environment(self) -> dict[str, str]:
        import os

        cache_dir = Path.home() / ".cache" / "crackerjack" / "coverage"
        cache_dir.mkdir(parents=True, exist_ok=True)

        env = os.environ.copy()
        env["COVERAGE_FILE"] = str(cache_dir / ".coverage")
        env["PYTEST_CURRENT_TEST"] = ""
        return env

    def _setup_coverage_env(self) -> dict[str, str]:
        import os
        from pathlib import Path

        cache_dir = Path.home() / ".cache" / "crackerjack" / "coverage"
        cache_dir.mkdir(parents=True, exist_ok=True)

        env = os.environ.copy()
        env["COVERAGE_FILE"] = str(cache_dir / ".coverage")
        return env

    def _start_reader_threads(
        self,
        process: subprocess.Popen[str],
        progress: TestProgress,
        live: Live,
    ) -> tuple[threading.Thread, threading.Thread, threading.Thread]:
        stdout_thread = self._create_stdout_reader(process, progress, live)
        stderr_thread = self._create_stderr_reader(process, progress, live)
        monitor_thread = self._create_monitor_thread(progress)

        stdout_thread.start()
        stderr_thread.start()
        monitor_thread.start()

        return stdout_thread, stderr_thread, monitor_thread

    def _create_stdout_reader(
        self,
        process: subprocess.Popen[str],
        progress: TestProgress,
        live: Live,
    ) -> threading.Thread:
        def read_output() -> None:
            if process.stdout:
                for line in iter(process.stdout.readline, ""):
                    progress.append_stdout(line)
                    if line.strip():
                        self._process_test_output_line(line.strip(), progress)
                        self._update_display_if_needed(progress, live)
                    if progress.is_complete:
                        break

        return threading.Thread(target=read_output, daemon=True)

    def _create_stderr_reader(
        self,
        process: subprocess.Popen[str],
        progress: TestProgress,
        live: Live,
    ) -> threading.Thread:
        def read_stderr() -> None:
            if process.stderr:
                for line in iter(process.stderr.readline, ""):
                    progress.append_stderr(line)
                    if line.strip() and "warning" not in line.lower():
                        progress.update(current_test=f"⚠️ {line.strip()}")
                        self._update_display_if_needed(progress, live)

        return threading.Thread(target=read_stderr, daemon=True)

    def _create_monitor_thread(self, progress: TestProgress) -> threading.Thread:
        def monitor_stuck_tests() -> None:
            last_update = time.time()
            last_test = ""

            while not progress.is_complete:
                time.sleep(5)
                current_time = time.time()

                if (
                    progress.current_test == last_test
                    and current_time - last_update > 30
                ):
                    self._mark_test_as_stuck(progress, progress.current_test)
                    last_update = current_time
                elif progress.current_test != last_test:
                    last_test = progress.current_test
                    last_update = current_time

        return threading.Thread(target=monitor_stuck_tests, daemon=True)

    def _process_test_output_line(self, line: str, progress: TestProgress) -> None:
        self._parse_test_line(line, progress)

    def _parse_test_line(self, line: str, progress: TestProgress) -> None:
        if self._handle_collection_completion(line, progress):
            return

        if self._handle_session_events(line, progress):
            return

        if self._handle_collection_progress(line, progress):
            return

        if self._handle_test_execution(line, progress):
            return

    def _handle_collection_completion(self, line: str, progress: TestProgress) -> bool:

        if "collected" in line and ("item" in line or "test" in line):
            match = re.search(
                r"(?:collected\s+)?(\d+)\s+(?:item|test)s?(?:\s+collected)?", line
            )
            if match:
                if "::" not in line and not line.strip().endswith(">"):
                    progress.update(
                        total_tests=int(match.group(1)),
                        is_collecting=False,
                        collection_status="Collection complete",
                    )
                    return True
        return False

    def _handle_session_events(self, line: str, progress: TestProgress) -> bool:
        if "session starts" in line and progress.collection_status != "Session started":
            progress.update(collection_status="Session started")
            return True
        if (
            "test session starts" in line
            and progress.collection_status != "Test collection started"
        ):
            progress.update(collection_status="Test collection started")
            return True
        return False

    def _handle_collection_progress(self, line: str, progress: TestProgress) -> bool:
        if progress.is_collecting:
            if line.endswith(".py") and ("test_" in line or "_test.py" in line):
                with progress._lock:
                    if line not in progress._seen_files:
                        progress._seen_files.add(line)
                        progress.files_discovered += 1
                        progress.collection_status = (
                            f"Found {progress.files_discovered} test files..."
                        )
                return True
        return False

    def _handle_test_execution(self, line: str, progress: TestProgress) -> bool:
        if " PASSED " in line:
            progress.update(passed=progress.passed + 1)
            self._extract_current_test(line, progress)
            return True
        if " FAILED " in line:
            progress.update(failed=progress.failed + 1)
            self._extract_current_test(line, progress)
            return True
        if " SKIPPED " in line:
            progress.update(skipped=progress.skipped + 1)
            self._extract_current_test(line, progress)
            return True
        if " ERROR " in line:
            progress.update(errors=progress.errors + 1)
            self._extract_current_test(line, progress)
            return True
        if ":: " in line and any(x in line for x in ("RUNNING", "test_")):
            self._handle_running_test(line, progress)
            return True

        return False

    def _handle_running_test(self, line: str, progress: TestProgress) -> None:
        if ":: " in line:
            test_parts = line.split(":: ")
            if len(test_parts) >= 2:
                test_name = ":: ".join(test_parts[-2:])
                progress.update(current_test=test_name)

    def _extract_current_test(self, line: str, progress: TestProgress) -> None:
        if ":: " in line:
            parts = line.split(" ")
            for part in parts:
                if ":: " in part:
                    progress.update(current_test=part)
                    break

    def _update_display_if_needed(self, progress: TestProgress, live: Live) -> None:
        if self._should_refresh_display(progress):
            live.update(progress.format_progress())

    def _should_refresh_display(self, progress: TestProgress) -> bool:
        return bool(
            progress.is_complete or progress.total_tests > 0 or progress.current_test
        )

    def _mark_test_as_stuck(self, progress: TestProgress, test_name: str) -> None:
        if test_name:
            progress.update(current_test=f"🐌 {test_name} (slow)")

    def _cleanup_threads(self, threads: list[threading.Thread]) -> None:
        for thread in threads:
            if thread.is_alive():
                thread.join(timeout=1.0)

    def _handle_progress_error(
        self,
        process: subprocess.Popen[str],
        progress: TestProgress,
        error_msg: str,
    ) -> None:
        process.terminate()
        progress.update(is_complete=True, current_test=f"❌ {error_msg}")

    def _execute_test_process_with_progress(
        self,
        cmd: list[str],
        env: dict[str, str],
        progress: TestProgress,
        progress_callback: t.Callable[[dict[str, t.Any]], None],
        timeout: int = 1800,
    ) -> subprocess.CompletedProcess[str]:
        process = subprocess.Popen(
            cmd,
            cwd=self._detect_target_project_dir(cmd),
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            env=env,
        )

        stdout_lines = self._read_stdout_with_progress(
            process,
            progress,
            progress_callback,
            timeout,
        )
        stderr_lines = self._read_stderr_lines(process, timeout)

        return_code = self._wait_for_process_completion(process, timeout)

        return subprocess.CompletedProcess(
            cmd,
            return_code,
            "\n".join(stdout_lines),
            "\n".join(stderr_lines),
        )

    def _read_stdout_with_progress(
        self,
        process: subprocess.Popen[str],
        progress: TestProgress,
        progress_callback: t.Callable[[dict[str, t.Any]], None],
        timeout: int = 60,
    ) -> list[str]:
        stdout_lines: list[str] = []
        start_time = time.time()
        last_output_time = time.time()

        if not process.stdout:
            return stdout_lines

        if not self._setup_nonblocking_io(process.stdout):  # type: ignore[arg-type]
            return self._read_stdout_blocking(process, start_time, last_output_time, timeout)

        return self._read_stdout_loop(process, stdout_lines, progress, progress_callback, start_time, last_output_time, timeout)

    def _setup_nonblocking_io(self, stream: t.TextIO) -> bool:
        """Setup non-blocking I/O on a stream. Returns True if successful."""
        import fcntl
        try:
            fd = stream.fileno()
            fl = fcntl.fcntl(fd, fcntl.F_GETFL)
            fcntl.fcntl(fd, fcntl.F_SETFL, fl | os.O_NONBLOCK)
            return True
        except (AttributeError, OSError):
            return False

    def _read_stdout_blocking(
        self,
        process: subprocess.Popen[str],
        start_time: float,
        last_output_time: float,
        timeout: int,
    ) -> list[str]:
        """Fallback blocking read when non-blocking setup fails."""
        stdout_lines: list[str] = []
        for line in iter(process.stdout.readline, ""):
            if not line:
                break
            line = line.strip()
            if line:
                stdout_lines.append(line)
                self._process_test_output_line(line, None)
                self._emit_ai_progress(None, None)
            if time.time() - last_output_time > timeout:
                self.console.print(
                    f"[yellow]No output for {timeout}s, terminating hung process[/yellow]"
                )
                process.terminate()
                break
        return stdout_lines

    def _read_stdout_loop(
        self,
        process: subprocess.Popen[str],
        stdout_lines: list[str],
        progress: TestProgress,
        progress_callback: t.Callable[[dict[str, t.Any]], None],
        start_time: float,
        last_output_time: float,
        timeout: int,
    ) -> list[str]:
        """Main loop for reading stdout with non-blocking I/O."""
        while True:
            if self._process_has_terminated(process):
                self._read_remaining_output(process.stdout, stdout_lines, progress, progress_callback)  # type: ignore[arg-type]
                break

            if not self._wait_for_readable_stdout(process, timeout, start_time, last_output_time):
                break

            line = self._read_line_with_timeout(process.stdout, timeout)  # type: ignore[arg-type]
            if not line:
                break
            self._process_line(line, stdout_lines, progress, progress_callback, last_output_time)

        return stdout_lines

    def _process_has_terminated(self, process: subprocess.Popen[str]) -> bool:
        return process.poll() is not None

    def _read_remaining_output(
        self,
        stdout: t.TextIO,
        stdout_lines: list[str],
        progress: TestProgress,
        progress_callback: t.Callable[[dict[str, t.Any]], None],
    ) -> None:
        with suppress(Exception):
            remaining = stdout.read()
            if remaining:
                for line in remaining.splitlines():
                    line = line.strip()
                    if line:
                        stdout_lines.append(line)
                        self._process_test_output_line(line, progress)
                        self._emit_ai_progress(progress, progress_callback)

    def _wait_for_readable_stdout(
        self,
        process: subprocess.Popen[str],
        timeout: int,
        start_time: float,
        last_output_time: float,
    ) -> bool:
        try:
            readable, _, _ = select.select([process.stdout], [], [], 1.0)
        except (ValueError, select.error):
            return False

        if not readable:
            elapsed_since_output = time.time() - last_output_time
            if elapsed_since_output > timeout:
                self.console.print(
                    f"[yellow]No stdout output for {timeout}s, "
                    f"process may be hung (total elapsed: {time.time() - start_time:.1f}s)[/yellow]"
                )
                process.terminate()
                return False
        return True

    def _read_line_with_timeout(self, stdout: t.TextIO, timeout: int) -> str:
        try:
            return stdout.readline()
        except IOError as e:
            if e.errno == errno.EAGAIN:
                time.sleep(0.1)
                return ""
            raise

    def _process_line(
        self,
        line: str,
        stdout_lines: list[str],
        progress: TestProgress,
        progress_callback: t.Callable[[dict[str, t.Any]], None],
        last_output_time: float,
    ) -> None:
        line = line.strip()
        if line:
            stdout_lines.append(line)
            self._process_test_output_line(line, progress)
            self._emit_ai_progress(progress, progress_callback)
            last_output_time = time.time()

    def _read_stderr_lines(
        self, process: subprocess.Popen[str], timeout: int = 60
    ) -> list[str]:
        stderr_lines: list[str] = []
        start_time = time.time()
        last_output_time = time.time()

        if not process.stderr:
            return stderr_lines

        if not self._setup_nonblocking_io(process.stderr):  # type: ignore[arg-type]
            return self._read_stderr_blocking(process, start_time, last_output_time, timeout)

        return self._read_stderr_loop(process, stderr_lines, start_time, last_output_time, timeout)  # type: ignore[arg-type]

    def _read_stderr_blocking(
        self,
        process: subprocess.Popen[str],
        start_time: float,
        last_output_time: float,
        timeout: int,
    ) -> list[str]:
        """Fallback blocking read when non-blocking setup fails."""
        stderr_lines: list[str] = []
        for line in iter(process.stderr.readline, ""):
            if not line:
                break
            line = line.strip()
            if line:
                stderr_lines.append(line)
            if time.time() - last_output_time > timeout:
                break
        return stderr_lines

    def _read_stderr_loop(
        self,
        process: subprocess.Popen[str],
        stderr_lines: list[str],
        start_time: float,
        last_output_time: float,
        timeout: int,
    ) -> list[str]:
        """Main loop for reading stderr with non-blocking I/O."""
        while True:
            if process.poll() is not None:
                self._read_remaining_stderr(process.stderr, stderr_lines)  # type: ignore[arg-type]
                break

            if not self._wait_for_readable_stderr(process, last_output_time, timeout):
                break

            line = self._read_stderr_line(process.stderr)  # type: ignore[arg-type]
            if not line:
                break
            stderr_lines.append(line)
            last_output_time = time.time()

        return stderr_lines

    def _read_remaining_stderr(self, stderr: t.TextIO, stderr_lines: list[str]) -> None:
        with suppress(Exception):
            remaining = stderr.read()
            if remaining:
                for line in remaining.splitlines():
                    line = line.strip()
                    if line:
                        stderr_lines.append(line)

    def _wait_for_readable_stderr(
        self,
        process: subprocess.Popen[str],
        last_output_time: float,
        timeout: int,
    ) -> bool:
        try:
            readable, _, _ = select.select([process.stderr], [], [], 1.0)
        except (ValueError, select.error):
            return False

        if not readable:
            elapsed_since_output = time.time() - last_output_time
            if elapsed_since_output > timeout:
                self.console.print(
                    f"[yellow]No stderr output for {timeout}s, terminating[/yellow]"
                )
                process.terminate()
                return False
        return True

    def _read_stderr_line(self, stderr: t.TextIO) -> str:
        try:
            line = stderr.readline()
            if not line:
                return ""
            return line.strip()
        except IOError as e:
            if e.errno == errno.EAGAIN:
                time.sleep(0.1)
                return ""
            return ""

    def _wait_for_process_completion(
        self,
        process: subprocess.Popen[str],
        timeout: int,
    ) -> int:
        try:
            process.wait(timeout=timeout)
            return process.returncode
        except subprocess.TimeoutExpired:
            process.terminate()
            return -1

    def _emit_ai_progress(
        self,
        progress: TestProgress,
        progress_callback: t.Callable[[dict[str, t.Any]], None],
    ) -> None:
        progress_data = {
            "type": "test_progress",
            "total_tests": progress.total_tests,
            "completed": progress.completed,
            "passed": progress.passed,
            "failed": progress.failed,
            "skipped": progress.skipped,
            "errors": progress.errors,
            "current_test": progress.current_test,
            "elapsed_time": progress.elapsed_time,
            "is_collecting": progress.is_collecting,
            "is_complete": progress.is_complete,
            "collection_status": progress.collection_status,
        }

        if progress.eta_seconds:
            progress_data["eta_seconds"] = progress.eta_seconds

        from contextlib import suppress

        with suppress(Exception):
            progress_callback(progress_data)
