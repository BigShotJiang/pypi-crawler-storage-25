from __future__ import annotations

from contextlib import suppress
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path

from crackerjack.config.tool_commands import get_tool_command


class HookStage(Enum):
    FAST = "fast"
    COMPREHENSIVE = "comprehensive"


class RetryPolicy(Enum):
    NONE = "none"
    FORMATTING_ONLY = "formatting_only"
    ALL_HOOKS = "all_hooks"


class SecurityLevel(Enum):
    CRITICAL = "critical"
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"


@dataclass
class HookDefinition:
    name: str
    command: list[str] = field(default_factory=list)
    timeout: int = 60
    stage: HookStage = HookStage.FAST
    description: str | None = None
    retry_on_failure: bool = False
    is_formatting: bool = False
    manual_stage: bool = False
    config_path: Path | None = None
    security_level: SecurityLevel = SecurityLevel.MEDIUM
    accepts_file_paths: bool = False
    disabled: bool = False
    run_schedule: str | None = None
    _direct_cmd_cache: list[str] | None = field(default=None, init=False, repr=False)

    def get_command(self) -> list[str]:
        if self.command:
            return self.command

        if self._direct_cmd_cache is None:
            try:
                self._direct_cmd_cache = get_tool_command(
                    self.name,
                    pkg_path=Path.cwd(),
                )
            except KeyError as exc:
                msg = f"Hook '{self.name}' is not registered for direct execution."
                raise ValueError(msg) from exc

        return self._direct_cmd_cache

    def build_command(self, files: list[Path] | None = None) -> list[str]:
        base_cmd = ["uv", "run", "zuban", "check"]

        if files and self.accepts_file_paths:
            base_cmd.extend([str(f) for f in files])
        else:
            # Use explicit path to avoid panic when running from parent directory
            base_cmd.append("crackerjack/")

        return base_cmd


@dataclass
class HookStrategy:
    name: str
    hooks: list[HookDefinition]
    timeout: int = 300
    retry_policy: RetryPolicy = RetryPolicy.NONE
    parallel: bool = False
    max_workers: int = 3


FAST_HOOKS = [
    HookDefinition(
        name="validate-regex-patterns",
        command=[],
        is_formatting=True,
        timeout=120,
        retry_on_failure=True,
        security_level=SecurityLevel.HIGH,
    ),
    HookDefinition(
        name="trailing-whitespace",
        command=[],
        is_formatting=True,
        timeout=120,
        retry_on_failure=True,
        security_level=SecurityLevel.LOW,
        accepts_file_paths=True,
    ),
    HookDefinition(
        name="end-of-file-fixer",
        command=[],
        is_formatting=True,
        timeout=120,
        retry_on_failure=True,
        security_level=SecurityLevel.LOW,
        accepts_file_paths=True,
    ),
    HookDefinition(
        name="check-yaml",
        command=[],
        timeout=60,
        security_level=SecurityLevel.MEDIUM,
        accepts_file_paths=True,
    ),
    HookDefinition(
        name="check-toml",
        command=[],
        timeout=150,
        security_level=SecurityLevel.MEDIUM,
        accepts_file_paths=True,
    ),
    HookDefinition(
        name="check-json",
        command=[],
        timeout=90,
        security_level=SecurityLevel.MEDIUM,
        accepts_file_paths=True,
    ),
    HookDefinition(
        name="check-ast",
        command=[],
        timeout=90,
        security_level=SecurityLevel.HIGH,
        accepts_file_paths=True,
    ),
    HookDefinition(
        name="format-json",
        command=[],
        is_formatting=True,
        timeout=120,
        retry_on_failure=True,
        security_level=SecurityLevel.LOW,
        accepts_file_paths=True,
    ),
    HookDefinition(
        name="check-added-large-files",
        command=[],
        timeout=90,
        security_level=SecurityLevel.HIGH,
    ),
    HookDefinition(
        name="uv-lock",
        command=[],
        timeout=60,
        security_level=SecurityLevel.HIGH,
    ),
    HookDefinition(
        name="codespell",
        command=[],
        is_formatting=True,
        timeout=150,
        retry_on_failure=True,
        security_level=SecurityLevel.LOW,
        accepts_file_paths=True,
    ),
    HookDefinition(
        name="ruff-check",
        command=[],
        is_formatting=True,
        timeout=240,
        retry_on_failure=True,
        security_level=SecurityLevel.MEDIUM,
        accepts_file_paths=True,
    ),
    HookDefinition(
        name="ruff-format",
        command=[],
        is_formatting=True,
        timeout=240,
        retry_on_failure=True,
        security_level=SecurityLevel.LOW,
        accepts_file_paths=True,
    ),
    HookDefinition(
        name="mdformat",
        command=[],
        is_formatting=True,
        timeout=180,
        retry_on_failure=True,
        security_level=SecurityLevel.LOW,
        accepts_file_paths=True,
    ),
    HookDefinition(
        name="check-local-links",
        command=[],
        timeout=60,
        security_level=SecurityLevel.LOW,
        accepts_file_paths=True,
        description="Fast local link validation (file references and anchors only)",
    ),
    HookDefinition(
        name="pip-audit",
        command=[],
        timeout=180,
        retry_on_failure=True,
        security_level=SecurityLevel.CRITICAL,
        accepts_file_paths=False,
        description="Dependency vulnerability scanning with auto-fix",
    ),
]

COMPREHENSIVE_HOOKS = [
    HookDefinition(
        name="zuban",
        command=[],
        timeout=60,
        stage=HookStage.COMPREHENSIVE,
        manual_stage=True,
        security_level=SecurityLevel.HIGH,
        accepts_file_paths=True,
    ),
    HookDefinition(
        name="semgrep",
        command=[],
        timeout=480,
        stage=HookStage.COMPREHENSIVE,
        manual_stage=True,
        security_level=SecurityLevel.CRITICAL,
        accepts_file_paths=True,
    ),
    HookDefinition(
        name="pyscn",
        command=[],
        timeout=300,
        stage=HookStage.COMPREHENSIVE,
        manual_stage=True,
        security_level=SecurityLevel.HIGH,
        accepts_file_paths=True,
    ),
    HookDefinition(
        name="gitleaks",
        command=[],
        timeout=180,
        stage=HookStage.COMPREHENSIVE,
        manual_stage=True,
        security_level=SecurityLevel.CRITICAL,
    ),
    HookDefinition(
        name="skylos",
        command=[],
        timeout=900,
        stage=HookStage.COMPREHENSIVE,
        manual_stage=True,
        security_level=SecurityLevel.MEDIUM,
        accepts_file_paths=True,
        disabled=True,
        run_schedule="weekly",
        description="Dead code detection (disabled by default due to 7+ min runtime)",
    ),
    HookDefinition(
        name="refurb",
        command=[],
        timeout=300,
        stage=HookStage.COMPREHENSIVE,
        manual_stage=True,
        security_level=SecurityLevel.MEDIUM,
        accepts_file_paths=True,
    ),
    HookDefinition(
        name="creosote",
        command=[],
        timeout=600,
        stage=HookStage.COMPREHENSIVE,
        manual_stage=True,
        security_level=SecurityLevel.HIGH,
    ),
    HookDefinition(
        name="complexipy",
        command=[],
        timeout=900,
        stage=HookStage.COMPREHENSIVE,
        manual_stage=True,
        security_level=SecurityLevel.MEDIUM,
        accepts_file_paths=True,
        disabled=True,
        run_schedule="weekly",
        description="Cognitive complexity analysis (disabled by default)",
    ),
    HookDefinition(
        name="check-jsonschema",
        command=[],
        timeout=180,
        stage=HookStage.COMPREHENSIVE,
        manual_stage=True,
        security_level=SecurityLevel.HIGH,
        accepts_file_paths=True,
    ),
    HookDefinition(
        name="linkcheckmd",
        command=[],
        timeout=300,
        stage=HookStage.COMPREHENSIVE,
        manual_stage=True,
        security_level=SecurityLevel.LOW,
        accepts_file_paths=False,
        description="Comprehensive link validation (local + external URLs)",
    ),
    HookDefinition(
        name="lychee",
        command=[],
        timeout=300,
        stage=HookStage.COMPREHENSIVE,
        manual_stage=True,
        security_level=SecurityLevel.LOW,
        accepts_file_paths=False,
        description="Comprehensive async link checker (Markdown, HTML, reStructuredText, text files with URLs)",
    ),
]


def _build_opt_in_type_hooks() -> list[HookDefinition]:
    optional_hooks: list[HookDefinition] = []

    with suppress(Exception):
        from crackerjack.config import CrackerjackSettings, load_settings

        settings = load_settings(CrackerjackSettings)
        adapter_timeouts = getattr(settings, "adapter_timeouts", None)

        if getattr(settings.hooks, "enable_ty", False):
            optional_hooks.append(
                HookDefinition(
                    name="ty",
                    command=[],
                    timeout=getattr(adapter_timeouts, "ty_timeout", 120),
                    stage=HookStage.COMPREHENSIVE,
                    manual_stage=True,
                    security_level=SecurityLevel.HIGH,
                    accepts_file_paths=True,
                    description="Opt-in Ty type checking",
                )
            )

        if getattr(settings.hooks, "enable_pyrefly", False):
            optional_hooks.append(
                HookDefinition(
                    name="pyrefly",
                    command=[],
                    timeout=getattr(adapter_timeouts, "pyrefly_timeout", 120),
                    stage=HookStage.COMPREHENSIVE,
                    manual_stage=True,
                    security_level=SecurityLevel.HIGH,
                    accepts_file_paths=True,
                    description="Opt-in Pyrefly type checking",
                )
            )

    return optional_hooks


def _build_comprehensive_hooks() -> list[HookDefinition]:
    hooks = COMPREHENSIVE_HOOKS.copy()
    hooks.extend(_build_opt_in_type_hooks())
    return hooks


FAST_STRATEGY = HookStrategy(
    name="fast",
    hooks=FAST_HOOKS,
    timeout=300,
    retry_policy=RetryPolicy.NONE,
    parallel=True,
    max_workers=6,
)

COMPREHENSIVE_STRATEGY = HookStrategy(
    name="comprehensive",
    hooks=COMPREHENSIVE_HOOKS,
    timeout=1800,
    retry_policy=RetryPolicy.NONE,
    parallel=True,
    max_workers=6,
)


def _update_hook_timeouts_from_settings(hooks: list[HookDefinition]) -> None:
    with suppress(Exception):
        from crackerjack.config import CrackerjackSettings, load_settings

        settings = load_settings(CrackerjackSettings)

        for hook in hooks:
            timeout_attr = f"{hook.name}_timeout"
            if hasattr(settings.adapter_timeouts, timeout_attr):
                configured_timeout = getattr(settings.adapter_timeouts, timeout_attr)
                hook.timeout = configured_timeout


class HookConfigLoader:
    @staticmethod
    def load_strategy(name: str, _: Path | None = None) -> HookStrategy:
        if name == "fast":
            _update_hook_timeouts_from_settings(FAST_HOOKS)
            return FAST_STRATEGY
        if name == "comprehensive":
            hooks = _build_comprehensive_hooks()
            _update_hook_timeouts_from_settings(hooks)
            return HookStrategy(
                name="comprehensive",
                hooks=hooks,
                timeout=1800,
                retry_policy=RetryPolicy.NONE,
                parallel=True,
                max_workers=6,
            )
        msg = f"Unknown hook strategy: {name}"
        raise ValueError(msg)
