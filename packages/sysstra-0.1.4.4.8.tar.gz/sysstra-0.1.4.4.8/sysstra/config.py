config = {
    "api_key": None,
    "orders_url": "https://orders.api.sysstra.com/",
    "data_url": "https://api.data.sysstra.com/",
    # "orders_url": "http://127.0.0.1:5001/",
    # "data_url": "http://127.0.0.1:5001/"
    }