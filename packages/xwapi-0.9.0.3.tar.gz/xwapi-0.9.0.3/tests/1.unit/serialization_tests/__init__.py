#exonware/xwapi/tests/1.unit/serialization_tests/__init__.py
"""
Unit tests for xwapi serialization module.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
Version: 0.0.1.0
"""
