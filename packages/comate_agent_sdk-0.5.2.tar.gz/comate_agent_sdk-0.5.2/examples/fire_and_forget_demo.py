"""
Fire-and-forget 模式演示

对比三种方式：
1. 同步执行 — 必须等完成
2. await — 异步但还是等完成
3. fire-and-forget — 发出去不等，继续干活
"""

import asyncio
import time


async def slow_job(name: str, seconds: float) -> str:
    """模拟一个耗时操作（比如发邮件、写日志、预热缓存）"""
    print(f"  [{name}] 开始，预计 {seconds}s")
    await asyncio.sleep(seconds)
    print(f"  [{name}] 完成!")
    return f"{name} 的结果"


async def demo_sync():
    """方式 1：同步风格，一个个等"""
    print("=== 1. 同步等待（总耗时 ≈ 3s）===")
    t0 = time.perf_counter()

    await slow_job("任务A", 1.0)
    await slow_job("任务B", 1.0)
    await slow_job("任务C", 1.0)

    print(f"  总耗时: {time.perf_counter() - t0:.1f}s\n")


async def demo_await_gathered():
    """方式 2：gather 并发，但还是等全部完成才往下走"""
    print("=== 2. gather 并发（总耗时 ≈ 1s，但仍然等待）===")
    t0 = time.perf_counter()

    results = await asyncio.gather(
        slow_job("任务A", 1.0),
        slow_job("任务B", 1.0),
        slow_job("任务C", 1.0),
    )
    print(f"  拿到结果: {results}")
    print(f"  总耗时: {time.perf_counter() - t0:.1f}s\n")


async def demo_fire_and_forget():
    """方式 3：fire-and-forget，发出去不等"""
    print("=== 3. Fire-and-forget（立即继续，不阻塞）===")
    t0 = time.perf_counter()

    # fire — 扔进事件循环，不 await
    asyncio.create_task(slow_job("后台任务A", 1.5))
    asyncio.create_task(slow_job("后台任务B", 2.0))

    print("  主流程继续干活，不等待后台任务...")
    await asyncio.sleep(0.3)  # 模拟主流程做一些别的事
    print(f"  主流程干完了! 耗时: {time.perf_counter() - t0:.1f}s")

    # 如果不给事件循环时间，后台任务还没跑完程序就退出了
    # 这也体现了 fire-and-forget 的特点：你根本不关心它什么时候完成
    print("  (等待后台任务跑完以便演示...)")
    await asyncio.sleep(2.0)
    print(f"  全部耗时: {time.perf_counter() - t0:.1f}s\n")


async def demo_fire_and_check_later():
    """方式 4：fire-and-check-later，发出去之后回头看看"""
    print("=== 4. Fire-and-check-later（回头看看做完了没）===")
    t0 = time.perf_counter()

    # fire
    task = asyncio.create_task(slow_job("预取任务", 1.0))

    print("  主流程继续干活...")
    await asyncio.sleep(0.5)

    # check later
    if task.done():
        print(f"  任务已完成，结果: {task.result()}")
    else:
        print("  任务还没完成，先不堵在这里")

    print(f"  当前耗时: {time.perf_counter() - t0:.1f}s")

    # 再干点别的，回头再看
    await asyncio.sleep(0.6)
    if task.done():
        print(f"  这次完成了! 结果: {task.result()}")

    print(f"  全部耗时: {time.perf_counter() - t0:.1f}s\n")


async def main():
    await demo_sync()
    await demo_await_gathered()
    await demo_fire_and_forget()
    await demo_fire_and_check_later()


if __name__ == "__main__":
    asyncio.run(main())
