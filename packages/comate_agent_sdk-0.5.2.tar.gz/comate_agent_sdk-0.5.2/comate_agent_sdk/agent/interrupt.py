from __future__ import annotations

import asyncio
import logging
import threading
import weakref
from dataclasses import dataclass, field
from typing import Callable


logger = logging.getLogger(__name__)


@dataclass
class SessionRunController:
    """Session-scoped controller for cooperative interruption."""

    _lock: threading.Lock = field(default_factory=threading.Lock, init=False, repr=False)
    _interrupted: bool = field(default=False, init=False, repr=False)
    _reason: str = field(default="", init=False, repr=False)
    _interrupt_count: int = field(default=0, init=False, repr=False)
    _callbacks: dict[int, Callable[[str, int], None]] = field(
        default_factory=dict,
        init=False,
        repr=False,
    )
    _next_callback_id: int = field(default=1, init=False, repr=False)
    _parent_unregister: Callable[[], None] | None = field(default=None, init=False, repr=False)

    def interrupt(self, reason: str = "user") -> None:
        normalized_reason = reason.strip() if isinstance(reason, str) else "user"
        if not normalized_reason:
            normalized_reason = "user"
        with self._lock:
            self._interrupted = True
            self._reason = normalized_reason
            self._interrupt_count += 1
            interrupt_count = self._interrupt_count
            callbacks = list(self._callbacks.values())

        for callback in callbacks:
            try:
                callback(normalized_reason, interrupt_count)
            except Exception as exc:
                logger.warning(f"interrupt callback failed: {exc}", exc_info=True)

    def clear(self) -> None:
        with self._lock:
            self._interrupted = False
            self._reason = ""
            self._interrupt_count = 0

    def register_interrupt_callback(
        self,
        callback: Callable[[str, int], None],
    ) -> Callable[[], None]:
        with self._lock:
            callback_id = self._next_callback_id
            self._next_callback_id += 1
            self._callbacks[callback_id] = callback

        def _unregister() -> None:
            with self._lock:
                self._callbacks.pop(callback_id, None)

        return _unregister

    def create_child(self) -> "SessionRunController":
        """Create a child controller. Parent interrupt cascades to child automatically."""
        child = SessionRunController()

        weak_child = weakref.ref(child)

        def _propagate(reason: str, count: int) -> None:
            c = weak_child()
            if c is not None:
                c.interrupt(reason)

        unregister = self.register_interrupt_callback(_propagate)
        child._parent_unregister = unregister

        # Fast path: parent already interrupted
        if self.is_interrupted:
            child.interrupt(self.reason or "user")

        return child

    def dispose(self) -> None:
        """Break the parent-child link. After dispose, parent interrupt no longer cascades."""
        if self._parent_unregister:
            self._parent_unregister()
            self._parent_unregister = None

    @property
    def is_interrupted(self) -> bool:
        with self._lock:
            return self._interrupted

    @property
    def reason(self) -> str | None:
        with self._lock:
            if not self._interrupted:
                return None
            return self._reason or "user"

    @property
    def interrupt_count(self) -> int:
        with self._lock:
            return self._interrupt_count


def bridge_to_event(
    controller: SessionRunController,
) -> tuple[asyncio.Event, Callable[[], None]]:
    """Bridge a controller's interrupt signal to an asyncio.Event.

    Returns (event, cleanup). Caller MUST call cleanup() in a finally block.
    Thread-safe: asyncio.Event.set() is thread-safe in Python 3.12+.
    """
    event = asyncio.Event()
    unregister = controller.register_interrupt_callback(
        lambda r, c: event.set()
    )
    if controller.is_interrupted:
        event.set()
    return event, unregister


def create_combined_controller(
    *sources: SessionRunController,
    timeout_s: float | None = None,
) -> tuple[SessionRunController, Callable[[], None]]:
    """Merge multiple cancellation sources into one controller.

    Any source interrupt or timeout -> combined is interrupted.
    Returns (combined, cleanup). Caller MUST call cleanup() in a finally block.

    When timeout_s is not None, MUST be called within an asyncio event loop context.
    """
    combined = SessionRunController()
    cleanups: list[Callable[[], None]] = []

    for source in sources:
        unreg = source.register_interrupt_callback(
            lambda r, c, _combined=combined: _combined.interrupt(r)
        )
        cleanups.append(unreg)

    timer_handle: asyncio.TimerHandle | None = None
    if timeout_s is not None:
        loop = asyncio.get_running_loop()
        timer_handle = loop.call_later(
            timeout_s,
            lambda: combined.interrupt("timeout"),
        )

    # Fast path: any source already interrupted
    for source in sources:
        if source.is_interrupted:
            combined.interrupt(source.reason or "user")
            break

    def cleanup() -> None:
        for fn in cleanups:
            fn()
        if timer_handle is not None:
            timer_handle.cancel()

    return combined, cleanup
