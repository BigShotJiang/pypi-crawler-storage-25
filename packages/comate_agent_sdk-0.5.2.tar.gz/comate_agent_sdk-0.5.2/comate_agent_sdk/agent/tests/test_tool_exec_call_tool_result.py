import pytest
from unittest.mock import MagicMock
from mcp.types import CallToolResult, TextContent

from comate_agent_sdk.agent.tool_exec import _build_tool_result_message


def _make_tool(ephemeral=False):
    t = MagicMock()
    t.ephemeral = ephemeral
    return t


def test_call_tool_result_reads_content():
    """CallToolResult.content is converted to SDK internal format."""
    result = CallToolResult(
        content=[TextContent(type="text", text="hello")]
    )
    msg = _build_tool_result_message(
        tool=_make_tool(),
        tool_name="test",
        tool_call_id="id1",
        result=result,
    )
    assert msg.text == "hello"
    assert msg.is_error is False


def test_call_tool_result_reads_is_error():
    """CallToolResult.isError=True is preserved."""
    result = CallToolResult(
        content=[TextContent(type="text", text="fail")],
        isError=True,
    )
    msg = _build_tool_result_message(
        tool=_make_tool(),
        tool_name="test",
        tool_call_id="id1",
        result=result,
    )
    assert msg.is_error is True


def test_envelope_still_works():
    """System tool envelope path unchanged."""
    from unittest.mock import patch, MagicMock
    mock_formatted = MagicMock()
    mock_formatted.text = '{"count": 5}'
    mock_formatted.meta.to_dict.return_value = {}
    mock_formatted.meta.truncation = None
    mock_formatted.meta.status = "ok"
    with patch("comate_agent_sdk.agent.tool_exec.OutputFormatter") as mock_fmt:
        mock_fmt.format.return_value = mock_formatted
        result = {"ok": True, "data": {"count": 5}}
        msg = _build_tool_result_message(
            tool=_make_tool(),
            tool_name="Glob",
            tool_call_id="id2",
            result=result,
        )
        assert msg.is_error is False
