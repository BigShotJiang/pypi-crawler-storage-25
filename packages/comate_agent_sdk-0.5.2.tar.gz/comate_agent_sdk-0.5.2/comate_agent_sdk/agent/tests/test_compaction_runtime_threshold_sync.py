import tempfile
import unittest
from pathlib import Path

from comate_agent_sdk.agent import Agent, AgentConfig
from comate_agent_sdk.agent.compaction.models import CompactionConfig


class _FakeLLM:
    def __init__(self) -> None:
        self.model = "fake:model"
        self.provider = "fake"

    @property
    def name(self) -> str:
        return self.model

    def get_context_window(self) -> int:
        return 32000

    async def ainvoke(self, messages, tools=None, tool_choice=None, **kwargs):  # type: ignore[no-untyped-def]
        raise AssertionError("ainvoke should not be called in this test")


class TestCompactionRuntimeThresholdSync(unittest.TestCase):
    def test_runtime_syncs_compaction_ratio_to_tracker_and_budget(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            template = Agent(
                llm=_FakeLLM(),
                config=AgentConfig(
                    compaction=CompactionConfig(threshold_ratio=0.72),
                    offload_enabled=False,
                    setting_sources=None,
                    cwd=Path(tmp),
                ),
            )

            runtime = template.create_runtime()

        self.assertEqual(runtime._compaction_service.config.threshold_ratio, 0.72)
        self.assertEqual(runtime._context_usage_tracker.threshold_ratio, 0.72)
        self.assertEqual(runtime._context.budget.compact_threshold_ratio, 0.72)


if __name__ == "__main__":
    unittest.main()
