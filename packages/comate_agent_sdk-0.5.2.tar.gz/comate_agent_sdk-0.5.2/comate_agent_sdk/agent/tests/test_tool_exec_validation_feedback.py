"""Tests for ValidationError corrective feedback in tool execution."""

import json
import unittest
from pathlib import Path
from types import SimpleNamespace

from pydantic import ValidationError

from comate_agent_sdk.agent.tool_exec import (
    _build_validation_error_feedback,
    execute_tool_call,
)
from comate_agent_sdk.llm.messages import Function, ToolCall
from comate_agent_sdk.system_tools.tools import Read as BuiltinRead


class _FakeAgent:
    def __init__(self, tool_obj) -> None:
        self._tool_map = {tool_obj.name: tool_obj}
        self.config = SimpleNamespace(
            dependency_overrides={},
            permission_mode="default",
            tool_approval_callback=None,
            disallowed_tools=None,
            add_dirs=None,
            env=None,
        )
        self._runtime_state = SimpleNamespace(
            cwd=Path.cwd(),
            llm_levels=None,
            tool_approval_callback=None,
            skills=None,
        )
        self._session_id = "s_test"
        self.name = None
        self._is_subagent = False
        self._subagent_source_prefix = None
        self._token_cost = None
        self._context = None

    async def run_hook_event(self, event_name: str, **kwargs):
        return None

    def add_hidden_user_message(self, content: str) -> None:
        _ = content


# ── Unit tests for _build_validation_error_feedback ──


class TestBuildValidationErrorFeedback(unittest.TestCase):
    def _make_extra_forbidden_exc(self, extra_fields: dict) -> ValidationError:
        """构造一个带 extra_forbidden 错误的 ValidationError。"""
        from comate_agent_sdk.system_tools.tools import ReadInput

        try:
            ReadInput(file_path="test.py", **extra_fields)
        except ValidationError as exc:
            return exc
        self.fail("Expected ValidationError was not raised")

    def test_shows_invalid_field_names(self) -> None:
        exc = self._make_extra_forbidden_exc({"args": ["python3", "-c", "import os"]})
        msg = _build_validation_error_feedback("Read", exc, BuiltinRead.definition.parameters)
        self.assertIn("does not accept parameter(s): args", msg)

    def test_shows_accepted_parameters(self) -> None:
        exc = self._make_extra_forbidden_exc({"args": "hello"})
        msg = _build_validation_error_feedback("Read", exc, BuiltinRead.definition.parameters)
        self.assertIn("Accepted parameters:", msg)
        self.assertIn("file_path (required)", msg)
        self.assertIn("offset_line (optional)", msg)
        self.assertIn("limit_lines (optional)", msg)

    def test_multiple_invalid_fields(self) -> None:
        exc = self._make_extra_forbidden_exc({"args": "x", "command": "y"})
        msg = _build_validation_error_feedback("Read", exc, BuiltinRead.definition.parameters)
        self.assertIn("args", msg)
        self.assertIn("command", msg)


# ── Integration test: ValidationError through execute_tool_call ──


class TestExecuteToolCallValidationFeedback(unittest.IsolatedAsyncioTestCase):
    async def test_extra_param_returns_corrective_error(self) -> None:
        agent = _FakeAgent(BuiltinRead)

        tool_call = ToolCall(
            id="tc_bad_read",
            function=Function(
                name="Read",
                arguments=json.dumps({
                    "file_path": "pyproject.toml",
                    "args": ["python3", "-c", "import comate_agent_sdk"],
                }),
            ),
        )

        message = await execute_tool_call(agent, tool_call)

        self.assertTrue(message.is_error)
        self.assertIn("does not accept parameter(s): args", message.text)
        self.assertIn("Accepted parameters:", message.text)
        self.assertIn("file_path (required)", message.text)
