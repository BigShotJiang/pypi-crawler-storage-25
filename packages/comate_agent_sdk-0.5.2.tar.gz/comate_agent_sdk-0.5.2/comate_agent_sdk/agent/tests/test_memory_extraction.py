from __future__ import annotations

import asyncio
import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import AsyncMock, patch

from comate_agent_sdk.agent import Agent, AgentConfig, StopEvent
from comate_agent_sdk.agent.memory_extract import start_background_memory_extraction
from comate_agent_sdk.llm.messages import AssistantMessage, Function, ToolCall, ToolMessage, UserMessage
from comate_agent_sdk.llm.views import ChatInvokeCompletion


class _StaticChatModel:
    def __init__(self, *, content: str = "done") -> None:
        self.content = content
        self.model = "fake:model"
        self.calls: list[list[object]] = []

    @property
    def provider(self) -> str:
        return "fake"

    @property
    def name(self) -> str:
        return self.model

    async def ainvoke(self, messages, tools=None, tool_choice=None, output_format=None, **kwargs):  # type: ignore[no-untyped-def]
        del tools, tool_choice, output_format, kwargs
        self.calls.append(list(messages))
        return ChatInvokeCompletion(content=self.content)


def _write_tool_call(*, tool_call_id: str, file_path: str, content: str = "memory") -> ToolCall:
    return ToolCall(
        id=tool_call_id,
        function=Function(
            name="Write",
            arguments=json.dumps(
                {"file_path": file_path, "content": content},
                ensure_ascii=False,
            ),
        ),
    )


async def _await_background_idle(runtime) -> None:  # type: ignore[no-untyped-def]
    while True:
        state = getattr(runtime, "_memory_extraction_state", None)
        task = getattr(state, "active_task", None) if state is not None else None
        if task is None:
            return
        await task
        await asyncio.sleep(0)


class TestMemoryExtraction(unittest.IsolatedAsyncioTestCase):
    def _build_runtime(self) -> tuple[tempfile.TemporaryDirectory[str], object]:
        tmp = tempfile.TemporaryDirectory()
        template = Agent(
            llm=_StaticChatModel(),  # type: ignore[arg-type]
            config=AgentConfig(
                tools=(),
                agents=(),
                offload_enabled=False,
                setting_sources=None,
            ),
        )
        runtime = template.create_runtime(cwd=Path(tmp.name), session_id="s1")
        return tmp, runtime

    async def test_start_background_memory_extraction_skips_when_main_agent_wrote_memory(self) -> None:
        tmp, runtime = self._build_runtime()
        self.addCleanup(tmp.cleanup)

        runtime._context.add_message(UserMessage(content="Remember that I prefer terse responses."))
        runtime._context.add_message(
            AssistantMessage(
                content="Saving this preference now.",
                tool_calls=[_write_tool_call(tool_call_id="tc-memory-write", file_path="memory/user_pref.md")],
            )
        )
        runtime._context.add_message(
            ToolMessage(
                tool_call_id="tc-memory-write",
                tool_name="Write",
                content="saved",
                is_error=False,
            )
        )
        runtime._context.add_message(AssistantMessage(content="Saved.", tool_calls=None))

        with patch("comate_agent_sdk.agent.memory_extract.run_forked_agent", new=AsyncMock()) as mocked_run:
            start_background_memory_extraction(runtime)
            await asyncio.sleep(0)

        state = runtime._memory_extraction_state
        self.assertIsNotNone(state)
        self.assertEqual(state.last_cursor_message_id, runtime._context.conversation.items[-1].id)
        self.assertIsNone(state.active_task)
        mocked_run.assert_not_called()

    async def test_start_background_memory_extraction_advances_cursor_on_success(self) -> None:
        tmp, runtime = self._build_runtime()
        self.addCleanup(tmp.cleanup)

        runtime._context.add_message(UserMessage(content="I prefer concise status updates."))
        runtime._context.add_message(AssistantMessage(content="Understood.", tool_calls=None))

        with patch(
            "comate_agent_sdk.agent.memory_extract.run_forked_agent",
            new=AsyncMock(return_value="memory saved"),
        ) as mocked_run:
            start_background_memory_extraction(runtime)
            await _await_background_idle(runtime)

        state = runtime._memory_extraction_state
        self.assertEqual(state.last_cursor_message_id, runtime._context.conversation.items[-1].id)
        self.assertIsNone(state.pending_request)
        mocked_run.assert_awaited_once()

    async def test_start_background_memory_extraction_runs_trailing_pending_snapshot(self) -> None:
        tmp, runtime = self._build_runtime()
        self.addCleanup(tmp.cleanup)

        runtime._context.add_message(UserMessage(content="First preference: summarize diffs tersely."))
        runtime._context.add_message(AssistantMessage(content="Captured first preference.", tool_calls=None))

        release_first = asyncio.Event()
        prompts: list[str] = []

        async def _fake_run(*args, **kwargs):  # type: ignore[no-untyped-def]
            prompts.append(kwargs["prompt"])
            if len(prompts) == 1:
                await release_first.wait()
            return "ok"

        with patch("comate_agent_sdk.agent.memory_extract.run_forked_agent", side_effect=_fake_run):
            start_background_memory_extraction(runtime)

            state = runtime._memory_extraction_state
            self.assertIsNotNone(state.active_task)

            runtime._context.add_message(UserMessage(content="Second preference: avoid long recaps."))
            runtime._context.add_message(AssistantMessage(content="Captured second preference.", tool_calls=None))

            start_background_memory_extraction(runtime)
            self.assertIsNotNone(state.pending_request)

            release_first.set()
            await _await_background_idle(runtime)

        self.assertEqual(len(prompts), 2)
        self.assertIn("Second preference: avoid long recaps.", prompts[1])
        self.assertNotIn("First preference: summarize diffs tersely.", prompts[1])
        self.assertEqual(runtime._memory_extraction_state.last_cursor_message_id, runtime._context.conversation.items[-1].id)

    async def test_start_background_memory_extraction_defaults_to_current_llm_even_with_low_level(self) -> None:
        """配置了 LOW level 时，记忆提取仍使用主 agent 模型（不再自动降级）。"""
        tmp = tempfile.TemporaryDirectory()
        self.addCleanup(tmp.cleanup)
        main_llm = _StaticChatModel()
        low_llm = _StaticChatModel()
        template = Agent(
            llm=main_llm,  # type: ignore[arg-type]
            config=AgentConfig(
                tools=(),
                agents=(),
                offload_enabled=False,
                setting_sources=None,
                llm_levels={"LOW": low_llm},  # type: ignore[arg-type]
            ),
        )
        runtime = template.create_runtime(cwd=Path(tmp.name), session_id="s1")
        runtime._context.add_message(UserMessage(content="I prefer concise status updates."))
        runtime._context.add_message(AssistantMessage(content="Understood.", tool_calls=None))

        with patch(
            "comate_agent_sdk.agent.memory_extract.run_forked_agent",
            new=AsyncMock(return_value="memory saved"),
        ) as mocked_run:
            start_background_memory_extraction(runtime)
            await _await_background_idle(runtime)

        mocked_run.assert_awaited_once()
        self.assertNotIn("llm", mocked_run.await_args.kwargs)
        self.assertNotIn("level", mocked_run.await_args.kwargs)

    async def test_start_background_memory_extraction_ignores_env_level_override(self) -> None:
        """memory extraction 始终跟随主 agent 模型，不受 memory recall env override 影响。"""
        tmp = tempfile.TemporaryDirectory()
        self.addCleanup(tmp.cleanup)
        main_llm = _StaticChatModel()
        low_llm = _StaticChatModel()
        template = Agent(
            llm=main_llm,  # type: ignore[arg-type]
            config=AgentConfig(
                tools=(),
                agents=(),
                offload_enabled=False,
                setting_sources=None,
                llm_levels={"LOW": low_llm},  # type: ignore[arg-type]
                env={"COMATE_AGENT_SDK_MEMORY_LLM_LEVEL": "low"},
            ),
        )
        runtime = template.create_runtime(cwd=Path(tmp.name), session_id="s1")
        runtime._context.add_message(UserMessage(content="I prefer concise status updates."))
        runtime._context.add_message(AssistantMessage(content="Understood.", tool_calls=None))

        with patch(
            "comate_agent_sdk.agent.memory_extract.run_forked_agent",
            new=AsyncMock(return_value="memory saved"),
        ) as mocked_run:
            start_background_memory_extraction(runtime)
            await _await_background_idle(runtime)

        mocked_run.assert_awaited_once()
        self.assertNotIn("llm", mocked_run.await_args.kwargs)
        self.assertNotIn("level", mocked_run.await_args.kwargs)

    async def test_start_background_memory_extraction_falls_back_to_current_llm_without_low_level(self) -> None:
        tmp, runtime = self._build_runtime()
        self.addCleanup(tmp.cleanup)
        runtime._runtime_state.llm_levels = None
        runtime._context.add_message(UserMessage(content="I prefer concise status updates."))
        runtime._context.add_message(AssistantMessage(content="Understood.", tool_calls=None))

        with patch(
            "comate_agent_sdk.agent.memory_extract.run_forked_agent",
            new=AsyncMock(return_value="memory saved"),
        ) as mocked_run:
            start_background_memory_extraction(runtime)
            await _await_background_idle(runtime)

        mocked_run.assert_awaited_once()
        self.assertNotIn("llm", mocked_run.await_args.kwargs)
        self.assertNotIn("level", mocked_run.await_args.kwargs)

    async def test_query_stream_triggers_background_memory_extraction_after_completed_turn(self) -> None:
        tmp, runtime = self._build_runtime()
        self.addCleanup(tmp.cleanup)

        with patch(
            "comate_agent_sdk.agent.runner_engine.query_stream.start_background_memory_extraction"
        ) as mocked_start:
            events = [event async for event in runtime.query_stream("hello")]

        self.assertEqual([event.reason for event in events if isinstance(event, StopEvent)], ["completed"])
        mocked_start.assert_called_once_with(runtime)


if __name__ == "__main__":
    unittest.main(verbosity=2)
