from __future__ import annotations

import unittest

from comate_agent_sdk.agent.runner_engine.projection.tool_result_projection import (
    extract_read_metadata,
    extract_task_snapshot,
)
from comate_agent_sdk.llm.messages import ToolMessage
from comate_agent_sdk.system_tools.tool_result import err, ok


class TestToolResultProjection(unittest.TestCase):
    def test_extract_read_metadata_returns_pagination_fields(self) -> None:
        message = ToolMessage(
            tool_call_id="tc_read",
            tool_name="Read",
            content="ok",
            is_error=False,
            raw_envelope=ok(
                data={
                    "total_lines": 937,
                    "lines_returned": 437,
                    "has_more": False,
                },
                meta={
                    "offset_line": 500,
                    "limit_lines": 500,
                },
            ),
        )

        metadata = extract_read_metadata("Read", message)

        self.assertEqual(
            metadata,
            {
                "offset_line": 500,
                "limit_lines": 500,
                "lines_returned": 437,
                "total_lines": 937,
                "has_more": False,
                "start_line": 501,
                "end_line": 937,
            },
        )

    def test_extract_read_metadata_includes_next_offset_when_present(self) -> None:
        message = ToolMessage(
            tool_call_id="tc_read_more",
            tool_name="Read",
            content="ok",
            is_error=False,
            raw_envelope=ok(
                data={
                    "total_lines": 1200,
                    "lines_returned": 500,
                    "has_more": True,
                    "next_offset_line": 500,
                },
                meta={
                    "offset_line": 0,
                    "limit_lines": 500,
                },
            ),
        )

        metadata = extract_read_metadata("Read", message)

        self.assertEqual(metadata["next_offset_line"], 500)
        self.assertEqual(metadata["start_line"], 1)
        self.assertEqual(metadata["end_line"], 500)

    def test_extract_read_metadata_rejects_errors_and_non_read_tools(self) -> None:
        error_message = ToolMessage(
            tool_call_id="tc_read_error",
            tool_name="Read",
            content="error",
            is_error=True,
            raw_envelope=err("NOT_FOUND", "missing"),
        )
        task_message = ToolMessage(
            tool_call_id="tc_task_list",
            tool_name="TaskList",
            content="ok",
            is_error=False,
            raw_envelope=ok(data={"tasks": []}),
        )

        self.assertIsNone(extract_read_metadata("Read", error_message))
        self.assertIsNone(extract_read_metadata("TaskList", task_message))

    def test_extract_task_snapshot_accepts_task_list_snapshot_tools(self) -> None:
        message = ToolMessage(
            tool_call_id="tc_task_list",
            tool_name="TaskList",
            content="ok",
            is_error=False,
            raw_envelope=ok(
                data={
                    "list_id": "shared",
                    "tasks": [
                        {"id": "1", "subject": "task-a", "status": "pending"},
                        "ignored",
                    ],
                }
            ),
        )

        snapshot = extract_task_snapshot("TaskList", message)

        self.assertEqual(
            snapshot,
            ("shared", [{"id": "1", "subject": "task-a", "status": "pending"}]),
        )

    def test_extract_task_snapshot_rejects_task_get(self) -> None:
        message = ToolMessage(
            tool_call_id="tc_task_get",
            tool_name="TaskGet",
            content="ok",
            is_error=False,
            raw_envelope=ok(
                data={
                    "list_id": "shared",
                    "tasks": [
                        {"id": "1", "subject": "task-a", "status": "pending"},
                    ],
                }
            ),
        )

        snapshot = extract_task_snapshot("TaskGet", message)

        self.assertIsNone(snapshot)

    def test_extract_task_snapshot_rejects_error_or_invalid_tasks(self) -> None:
        error_message = ToolMessage(
            tool_call_id="tc_task_update_error",
            tool_name="TaskUpdate",
            content="error",
            is_error=True,
            raw_envelope=err("CONFLICT", "busy"),
        )
        invalid_tasks_message = ToolMessage(
            tool_call_id="tc_task_update_invalid",
            tool_name="TaskUpdate",
            content="ok",
            is_error=False,
            raw_envelope=ok(data={"list_id": "shared", "tasks": "invalid"}),
        )

        self.assertIsNone(extract_task_snapshot("TaskUpdate", error_message))
        self.assertIsNone(extract_task_snapshot("TaskUpdate", invalid_tasks_message))

    def test_extract_task_snapshot_accepts_empty_task_list_to_clear_state(self) -> None:
        message = ToolMessage(
            tool_call_id="tc_task_list_empty",
            tool_name="TaskList",
            content="ok",
            is_error=False,
            raw_envelope=ok(data={"list_id": "shared", "tasks": []}),
        )

        snapshot = extract_task_snapshot("TaskList", message)

        self.assertEqual(snapshot, ("shared", []))


if __name__ == "__main__":
    unittest.main(verbosity=2)
