import tempfile
import unittest
from pathlib import Path
import json

from comate_agent_sdk.agent import Agent, AgentConfig
from comate_agent_sdk.agent.events import StopEvent, TextEvent
from comate_agent_sdk.llm.messages import Function, ToolCall
from comate_agent_sdk.llm.views import ChatInvokeCompletion
from comate_agent_sdk.system_tools.team.inbox_transport import TeamInboxEnvelope
from comate_agent_sdk.system_tools.tools import AskUserQuestion


class _FakeChatModel:
    def __init__(self, completions: list[ChatInvokeCompletion]):
        self._completions = completions
        self._idx = 0
        self.calls = 0
        self.model = "fake:model"

    @property
    def provider(self) -> str:
        return "fake"

    @property
    def name(self) -> str:
        return self.model

    async def ainvoke(self, messages, tools=None, tool_choice=None, **kwargs):  # type: ignore[no-untyped-def]
        del messages, tools, tool_choice, kwargs
        self.calls += 1
        if self._idx >= len(self._completions):
            raise AssertionError(f"Unexpected ainvoke call #{self._idx + 1}")
        completion = self._completions[self._idx]
        self._idx += 1
        return completion


def _make_inbox_event(*, key: str, message_type: str, content: str) -> TeamInboxEnvelope:
    return TeamInboxEnvelope(
        key=key,
        from_agent="worker-1",
        message_type=message_type,
        content=content,
        timestamp="2026-03-11T00:00:00+00:00",
        raw_envelope={},
    )


class TestRunnerStreamTeamContinuation(unittest.IsolatedAsyncioTestCase):
    async def test_team_continuation_appends_follow_up_turn_without_intermediate_stop(self) -> None:
        llm = _FakeChatModel(
            [
                ChatInvokeCompletion(content="first turn"),
                ChatInvokeCompletion(content="follow-up turn"),
            ]
        )

        with tempfile.TemporaryDirectory() as td:
            runtime = Agent(
                llm=llm,  # type: ignore[arg-type]
                config=AgentConfig(
                    tools=(),
                    agents=(),
                    offload_enabled=False,
                    setting_sources=None,
                    cwd=Path(td),
                ),
            ).create_runtime(
                name="captain",
                team_name="review-team",
                task_namespace="review-team",
            )
            runtime._team.suppress_idle_notification = True
            completed_turns: list[str] = []
            runtime._team.turn_complete_callback = lambda: completed_turns.append("done")
            runtime._team.pending_inbox_events.append(
                _make_inbox_event(
                    key="msg-1",
                    message_type="message",
                    content="please continue",
                )
            )
            runtime._team.pending_inbox_keys.add("msg-1")

            events: list[object] = []
            async for event in runtime.query_stream("hello"):
                events.append(event)

        texts = [event.content for event in events if isinstance(event, TextEvent)]
        stop_reasons = [event.reason for event in events if isinstance(event, StopEvent)]

        self.assertEqual(texts, ["first turn", "follow-up turn"])
        self.assertEqual(stop_reasons, ["completed"])
        self.assertEqual(completed_turns, ["done"])
        self.assertEqual(llm.calls, 2)

    async def test_shutdown_request_preempts_buffered_continuation_turn(self) -> None:
        llm = _FakeChatModel(
            [
                ChatInvokeCompletion(content="first turn"),
                ChatInvokeCompletion(content="should not run"),
            ]
        )

        with tempfile.TemporaryDirectory() as td:
            runtime = Agent(
                llm=llm,  # type: ignore[arg-type]
                config=AgentConfig(
                    tools=(),
                    agents=(),
                    offload_enabled=False,
                    setting_sources=None,
                    cwd=Path(td),
                ),
            ).create_runtime(
                name="captain",
                team_name="review-team",
                task_namespace="review-team",
            )
            runtime._team.suppress_idle_notification = True

            def _queue_shutdown_request() -> None:
                runtime._team.pending_inbox_events.append(
                    _make_inbox_event(
                        key="shutdown-1",
                        message_type="shutdown_request",
                        content="stop now",
                    )
                )
                runtime._team.pending_inbox_keys.add("shutdown-1")

            runtime._team.turn_complete_callback = _queue_shutdown_request
            runtime._team.pending_inbox_events.append(
                _make_inbox_event(
                    key="msg-1",
                    message_type="message",
                    content="please continue",
                )
            )
            runtime._team.pending_inbox_keys.add("msg-1")

            events: list[object] = []
            async for event in runtime.query_stream("hello"):
                events.append(event)

        texts = [event.content for event in events if isinstance(event, TextEvent)]
        stop_reasons = [event.reason for event in events if isinstance(event, StopEvent)]

        self.assertEqual(texts, ["first turn"])
        self.assertEqual(stop_reasons, ["shutdown_request"])
        self.assertEqual(llm.calls, 1)

    async def test_team_continuation_acknowledges_inbox_when_follow_up_waits_for_input(self) -> None:
        llm = _FakeChatModel(
            [
                ChatInvokeCompletion(content="first turn"),
                ChatInvokeCompletion(
                    tool_calls=[
                        ToolCall(
                            id="tc_ask_1",
                            function=Function(
                                name="AskUserQuestion",
                                arguments=json.dumps(
                                    {
                                        "questions": [
                                            {
                                                "question": "Need input?",
                                                "header": "Input",
                                                "options": [
                                                    {"label": "A", "description": "a"},
                                                    {"label": "B", "description": "b"},
                                                ],
                                                "multiSelect": False,
                                            }
                                        ]
                                    },
                                    ensure_ascii=False,
                                ),
                            ),
                        )
                    ]
                ),
            ]
        )

        with tempfile.TemporaryDirectory() as td:
            runtime = Agent(
                llm=llm,  # type: ignore[arg-type]
                config=AgentConfig(
                    tools=(AskUserQuestion,),
                    agents=(),
                    offload_enabled=False,
                    setting_sources=None,
                    cwd=Path(td),
                ),
            ).create_runtime(
                name="captain",
                team_name="review-team",
                task_namespace="review-team",
            )
            runtime._team.suppress_idle_notification = True
            acked_keys: list[str] = []
            runtime.ack_pending_inbox_events = lambda keys: acked_keys.extend(keys)  # type: ignore[method-assign]
            runtime._team.pending_inbox_events.append(
                _make_inbox_event(
                    key="msg-1",
                    message_type="message",
                    content="please continue",
                )
            )
            runtime._team.pending_inbox_keys.add("msg-1")

            events: list[object] = []
            async for event in runtime.query_stream("hello"):
                events.append(event)

        stop_reasons = [event.reason for event in events if isinstance(event, StopEvent)]
        self.assertEqual(stop_reasons, ["waiting_for_input"])
        self.assertEqual(acked_keys, ["msg-1"])
        self.assertEqual(llm.calls, 2)


class TestQueryStreamNoneMessage(unittest.IsolatedAsyncioTestCase):
    async def test_query_stream_none_drains_external_turns_only(self) -> None:
        """query_stream(None) should process pending external turns without a user message."""
        llm = _FakeChatModel(
            [
                ChatInvokeCompletion(content="processed external turn"),
            ]
        )

        with tempfile.TemporaryDirectory() as td:
            from comate_agent_sdk.agent.chat_session import ChatSession

            template = Agent(
                llm=llm,  # type: ignore[arg-type]
                config=AgentConfig(
                    tools=(),
                    agents=(),
                    offload_enabled=False,
                    setting_sources=None,
                    cwd=Path(td),
                ),
            )
            runtime = template.create_runtime(
                name="captain",
                team_name="test-team",
                task_namespace="test-team",
            )
            runtime._team.suppress_idle_notification = True
            session = ChatSession(template, runtime=runtime)

            # 预先注入 external turn 到 scheduler
            from comate_agent_sdk.agent.external_turns import ExternalTurn

            await session.enqueue_external_turn(
                ExternalTurn(
                    turn_id="test-turn-1",
                    source="team_inbox",
                    source_event_id="msg-1",
                    dedupe_key="test-turn-1",
                    received_at="2026-03-21T00:00:00+00:00",
                    payload={
                        "messages": [
                            {
                                "from_agent": "worker",
                                "content": "result",
                                "message_type": "message",
                                "timestamp": "2026-03-21T00:00:00+00:00",
                                "key": "msg-1",
                            }
                        ]
                    },
                    can_auto_consume=True,
                    retry_count=0,
                    preview="result",
                )
            )

            self.assertTrue(session.has_pending_external_turns())

            events: list[object] = []
            async for event in session.query_stream(None):
                events.append(event)

            texts = [e.content for e in events if isinstance(e, TextEvent)]
            stops = [e.reason for e in events if isinstance(e, StopEvent)]
            self.assertEqual(texts, ["processed external turn"])
            self.assertEqual(stops, ["completed"])
            self.assertEqual(llm.calls, 1)

    async def test_query_stream_none_with_empty_scheduler_returns_no_events(self) -> None:
        """query_stream(None) with empty scheduler should return immediately with no events."""
        llm = _FakeChatModel([])

        with tempfile.TemporaryDirectory() as td:
            from comate_agent_sdk.agent.chat_session import ChatSession

            template = Agent(
                llm=llm,  # type: ignore[arg-type]
                config=AgentConfig(
                    tools=(),
                    agents=(),
                    offload_enabled=False,
                    setting_sources=None,
                    cwd=Path(td),
                ),
            )
            runtime = template.create_runtime(
                name="captain",
                team_name="test-team",
                task_namespace="test-team",
            )
            session = ChatSession(template, runtime=runtime)

            events: list[object] = []
            async for event in session.query_stream(None):
                events.append(event)

            non_init = [e for e in events if not type(e).__name__.startswith("SessionInit")]
            self.assertEqual(non_init, [])
            self.assertEqual(llm.calls, 0)


class TestChatSessionHasPendingExternalTurns(unittest.IsolatedAsyncioTestCase):
    async def test_has_pending_external_turns_reflects_scheduler_state(self) -> None:
        """ChatSession.has_pending_external_turns() should reflect scheduler queue state."""
        from comate_agent_sdk.agent.chat_session import ChatSession
        from comate_agent_sdk.agent.external_turns import ExternalTurn

        with tempfile.TemporaryDirectory() as td:
            template = Agent(
                llm=_FakeChatModel([]),  # type: ignore[arg-type]
                config=AgentConfig(
                    tools=(),
                    agents=(),
                    offload_enabled=False,
                    setting_sources=None,
                    cwd=Path(td),
                ),
            )
            runtime = template.create_runtime(
                name="captain",
                team_name="test-team",
                task_namespace="test-team",
            )
            session = ChatSession(template, runtime=runtime)

            # Initial state: no pending turns
            self.assertFalse(session.has_pending_external_turns())

            # Enqueue an external turn
            await session.enqueue_external_turn(
                ExternalTurn(
                    turn_id="test-turn-1",
                    source="team_inbox",
                    source_event_id="msg-1",
                    dedupe_key="test-turn-1",
                    received_at="2026-03-21T00:00:00+00:00",
                    payload={
                        "messages": [
                            {
                                "from_agent": "worker",
                                "content": "result",
                                "message_type": "message",
                                "timestamp": "2026-03-21T00:00:00+00:00",
                                "key": "msg-1",
                            }
                        ]
                    },
                    can_auto_consume=True,
                    retry_count=0,
                    preview="result",
                )
            )

            # Now has pending turns
            self.assertTrue(session.has_pending_external_turns())
