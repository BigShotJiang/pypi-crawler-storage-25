import json
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest import mock

from comate_agent_sdk.agent.tool_exec import execute_tool_call
from comate_agent_sdk.llm.messages import Function, ToolCall
from comate_agent_sdk.system_tools.tools import LS as BuiltinLS
from comate_agent_sdk.system_tools.tools import Read as BuiltinRead
from comate_agent_sdk.system_tools.tool_result import err, ok
from comate_agent_sdk.tools import tool
from comate_agent_sdk.tools.system_context import get_system_tool_context


class _FakeAgent:
    def __init__(self, tool_obj) -> None:
        self._tool_map = {tool_obj.name: tool_obj}
        self.config = SimpleNamespace(
            dependency_overrides={},
            permission_mode="default",
            tool_approval_callback=None,
        )
        self._runtime_state = SimpleNamespace(
            cwd=Path.cwd(),
            llm_levels=None,
            tool_approval_callback=None,
            skills=None,
        )
        self._session_id = "s_test"
        self.name = None
        self._is_subagent = False
        self._subagent_source_prefix = None
        self._token_cost = None
        self._context = None

    async def run_hook_event(self, event_name: str, **kwargs):  # type: ignore[no-untyped-def]
        return None

    def add_hidden_user_message(self, content: str) -> None:
        _ = content


class TestToolExecFormatterIntegration(unittest.IsolatedAsyncioTestCase):
    async def test_execute_tool_call_formats_envelope_result(self) -> None:
        @tool("Read tool for testing", name="Read")
        async def Read(file_path: str, offset_line: int = 0, limit_lines: int = 2) -> dict:
            return ok(
                data={
                    "content": "     1\ta\n     2\tb",
                    "total_lines": 100,
                    "lines_returned": 2,
                    "has_more": True,
                    "next_offset_line": 2,
                    "truncated": True,
                },
                meta={
                    "file_path": file_path,
                    "offset_line": offset_line,
                    "limit_lines": limit_lines,
                },
            )

        agent = _FakeAgent(Read)
        tool_call = ToolCall(
            id="tc_read",
            function=Function(
                name="Read",
                arguments=json.dumps(
                    {"file_path": "src/main.py", "offset_line": 0, "limit_lines": 2},
                    ensure_ascii=False,
                ),
            ),
        )

        message = await execute_tool_call(agent, tool_call)
        self.assertFalse(message.is_error)
        self.assertIsNotNone(message.raw_envelope)
        self.assertIsNotNone(message.execution_meta)
        self.assertIsNotNone(message.truncation_record)
        self.assertEqual(message.execution_meta.get("status"), "ok")
        self.assertTrue(message.execution_meta.get("truncation", {}).get("formatter_truncated"))
        self.assertIn("# Read: src/main.py", message.text)
        self.assertIn("Recommended next step", message.text)

    async def test_execute_tool_call_formats_error_envelope(self) -> None:
        @tool("Grep tool for testing", name="Grep")
        async def Grep(pattern: str) -> dict:
            return err(
                "INVALID_ARGUMENT",
                f"invalid pattern: {pattern}",
                field_errors=[{"field": "pattern", "message": "invalid regex"}],
            )

        agent = _FakeAgent(Grep)
        tool_call = ToolCall(
            id="tc_grep",
            function=Function(
                name="Grep",
                arguments=json.dumps({"pattern": "["}, ensure_ascii=False),
            ),
        )

        message = await execute_tool_call(agent, tool_call)
        self.assertTrue(message.is_error)
        self.assertIsNotNone(message.raw_envelope)
        self.assertEqual(message.execution_meta.get("status"), "error")
        self.assertEqual(message.execution_meta.get("error_code"), "INVALID_ARGUMENT")
        self.assertIn("# Grep Error", message.text)

    async def test_execute_tool_call_keeps_plain_string_result(self) -> None:
        @tool("Plain tool for testing", name="PlainTool")
        async def PlainTool(value: str) -> str:
            return f"plain:{value}"

        agent = _FakeAgent(PlainTool)
        tool_call = ToolCall(
            id="tc_plain",
            function=Function(
                name="PlainTool",
                arguments=json.dumps({"value": "ok"}, ensure_ascii=False),
            ),
        )

        message = await execute_tool_call(agent, tool_call)
        self.assertFalse(message.is_error)
        self.assertEqual(message.text, "plain:ok")
        self.assertIsNone(message.raw_envelope)
        self.assertIsNone(message.execution_meta)

    async def test_execute_tool_call_merges_runtime_extra_write_roots(self) -> None:
        @tool("Capture extra_write_roots from tool context", name="CaptureRoots")
        async def CaptureRoots() -> str:
            ctx = get_system_tool_context()
            return "|".join(str(path) for path in ctx.extra_write_roots)

        agent = _FakeAgent(CaptureRoots)
        agent._active_mode_snapshot = "plan"
        with tempfile.TemporaryDirectory() as tmpdir:
            custom_root = Path(tmpdir) / "custom-write-root"
            agent._extra_write_roots = ("~/.agent/plans", str(custom_root))

            tool_call = ToolCall(
                id="tc_capture_roots",
                function=Function(
                    name="CaptureRoots",
                    arguments=json.dumps({}, ensure_ascii=False),
                ),
            )

            message = await execute_tool_call(agent, tool_call)

        roots = [Path(text).resolve() for text in message.text.split("|") if text]
        plans_root = (Path.home() / ".agent" / "plans").expanduser().resolve()
        self.assertEqual(roots.count(plans_root), 1)
        self.assertIn(custom_root.resolve(), roots)

    async def test_execute_tool_call_read_can_access_custom_team_root_from_env(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td).resolve()
            project_root = root / "project"
            team_root = root / "custom-teams"
            team_config = team_root / "review-team" / "config.json"
            project_root.mkdir(parents=True, exist_ok=True)
            team_config.parent.mkdir(parents=True, exist_ok=True)
            team_config.write_text('{"team_name":"review-team","members":[]}\n', encoding="utf-8")

            agent = _FakeAgent(BuiltinRead)
            agent._runtime_state.cwd = project_root

            tool_call = ToolCall(
                id="tc_read_team_config",
                function=Function(
                    name="Read",
                    arguments=json.dumps(
                        {"file_path": str(team_config)},
                        ensure_ascii=False,
                    ),
                ),
            )

            with mock.patch.dict("os.environ", {"COMATE_TEAMS_DIR": str(team_root)}, clear=False):
                message = await execute_tool_call(agent, tool_call)

        self.assertFalse(message.is_error)
        self.assertIsNotNone(message.raw_envelope)
        self.assertEqual(message.execution_meta.get("status"), "ok")
        self.assertIn("review-team", message.text)

    async def test_execute_tool_call_ls_can_access_custom_team_root_from_env(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td).resolve()
            project_root = root / "project"
            team_root = root / "custom-teams"
            team_dir = team_root / "review-team"
            inbox_dir = team_dir / "inboxes"
            project_root.mkdir(parents=True, exist_ok=True)
            inbox_dir.mkdir(parents=True, exist_ok=True)
            (team_dir / "config.json").write_text('{"team_name":"review-team","members":[]}\n', encoding="utf-8")
            (inbox_dir / "worker-1.json").write_text("[]\n", encoding="utf-8")

            agent = _FakeAgent(BuiltinLS)
            agent._runtime_state.cwd = project_root

            tool_call = ToolCall(
                id="tc_ls_team_dir",
                function=Function(
                    name="LS",
                    arguments=json.dumps(
                        {"path": str(team_dir), "include_hidden": True},
                        ensure_ascii=False,
                    ),
                ),
            )

            with mock.patch.dict("os.environ", {"COMATE_TEAMS_DIR": str(team_root)}, clear=False):
                message = await execute_tool_call(agent, tool_call)

        self.assertFalse(message.is_error)
        self.assertIsNotNone(message.raw_envelope)
        self.assertEqual(message.execution_meta.get("status"), "ok")
        self.assertIn("config.json", message.text)
        self.assertIn("inboxes", message.text)

    async def test_execute_tool_call_read_can_access_skill_directory(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td).resolve()
            project_root = root / "project"
            skill_dir = root / ".agent" / "skills" / "demo-skill"
            skill_script = skill_dir / "scripts" / "bootstrap.py"
            project_root.mkdir(parents=True, exist_ok=True)
            skill_script.parent.mkdir(parents=True, exist_ok=True)
            skill_script.write_text("import logging\n", encoding="utf-8")

            agent = _FakeAgent(BuiltinRead)
            agent._runtime_state.cwd = project_root
            agent._runtime_state.skills = [
                SimpleNamespace(
                    name="demo-skill",
                    base_dir=skill_dir,
                )
            ]

            tool_call = ToolCall(
                id="tc_read_skill_script",
                function=Function(
                    name="Read",
                    arguments=json.dumps(
                        {"file_path": str(skill_script)},
                        ensure_ascii=False,
                    ),
                ),
            )

            message = await execute_tool_call(agent, tool_call)

        self.assertFalse(message.is_error)
        self.assertIsNotNone(message.raw_envelope)
        self.assertEqual(message.execution_meta.get("status"), "ok")
        self.assertIn("import logging", message.text)


if __name__ == "__main__":
    unittest.main(verbosity=2)
