"""Tests for MCP tool cancel_event injection in execute_tool_call."""

from __future__ import annotations

import asyncio
from contextlib import contextmanager
from unittest.mock import AsyncMock, MagicMock, patch

from comate_agent_sdk.agent.tool_exec import execute_tool_call
from comate_agent_sdk.llm.messages import Function, ToolCall, ToolMessage
from comate_agent_sdk.mcp.manager import _MCP_TOOL_MARKER_ATTR, _MCP_TOOL_MARKER_VALUE


# ---------------------------------------------------------------------------
# helpers
# ---------------------------------------------------------------------------


def _make_tool_call(name: str = "mcp__test__echo", arguments: str = "{}") -> ToolCall:
    return ToolCall(id="call_1", type="function", function=Function(name=name, arguments=arguments))


def _make_agent(*, has_controller: bool = True) -> MagicMock:
    agent = MagicMock()
    agent.config.dependency_overrides = None
    agent.config.disallowed_tools = []
    agent._tool_map = {}
    agent.run_hook_event = AsyncMock()
    if has_controller:
        from comate_agent_sdk.agent.interrupt import SessionRunController

        agent._run_controller = SessionRunController()
    else:
        agent._run_controller = None
    return agent


def _make_mcp_tool(*, captured_kwargs: dict | None = None):
    """Create a mock MCP tool that captures kwargs passed to execute()."""
    tool = MagicMock()
    setattr(tool, _MCP_TOOL_MARKER_ATTR, _MCP_TOOL_MARKER_VALUE)
    tool.definition.parameters = {"type": "object", "properties": {}, "required": []}

    async def _execute(_overrides=None, **kwargs):
        if captured_kwargs is not None:
            captured_kwargs.update(kwargs)
        return "ok"

    tool.execute = _execute
    return tool


def _make_system_tool(*, captured_kwargs: dict | None = None):
    """Create a mock non-MCP system tool."""
    tool = MagicMock()
    # No MCP marker
    tool.definition.parameters = {"type": "object", "properties": {}, "required": []}

    async def _execute(_overrides=None, **kwargs):
        if captured_kwargs is not None:
            captured_kwargs.update(kwargs)
        return "ok"

    tool.execute = _execute
    return tool


@contextmanager
def _stub_tool_exec_internals():
    """Patch internal functions of execute_tool_call that are not under test."""
    dummy_msg = ToolMessage(tool_call_id="call_1", tool_name="t", content="ok", is_error=False)

    @contextmanager
    def _fake_bind(**_kw):
        yield

    with (
        patch("comate_agent_sdk.agent.tool_exec._resolve_system_tool_context_kwargs", return_value={"project_root": "/tmp"}),
        patch("comate_agent_sdk.tools.system_context.bind_system_tool_context", _fake_bind),
        patch("comate_agent_sdk.agent.tool_exec._run_pre_tool_pipeline", new_callable=AsyncMock, return_value=({}, None)),
        patch("comate_agent_sdk.agent.tool_exec._build_tool_result_message", return_value=dummy_msg),
        patch("comate_agent_sdk.agent.tool_exec._set_span_output"),
        patch("comate_agent_sdk.agent.tool_exec._record_tool_result"),
        patch("comate_agent_sdk.agent.tool_exec.Laminar", None),
    ):
        yield


# ---------------------------------------------------------------------------
# tests
# ---------------------------------------------------------------------------


def test_mcp_tool_receives_cancel_event() -> None:
    """When tool is MCP and controller exists, _cancel_event is injected."""
    captured: dict = {}

    async def _run() -> None:
        tool = _make_mcp_tool(captured_kwargs=captured)
        agent = _make_agent(has_controller=True)
        agent._tool_map = {"mcp__test__echo": tool}

        with _stub_tool_exec_internals():
            await execute_tool_call(agent, _make_tool_call("mcp__test__echo"))

    asyncio.run(_run())

    assert "_cancel_event" in captured
    assert isinstance(captured["_cancel_event"], asyncio.Event)


def test_non_mcp_tool_does_not_receive_cancel_event() -> None:
    """Non-MCP system tools must NOT receive _cancel_event."""
    captured: dict = {}

    async def _run() -> None:
        tool = _make_system_tool(captured_kwargs=captured)
        agent = _make_agent(has_controller=True)
        agent._tool_map = {"MyTool": tool}

        with _stub_tool_exec_internals():
            await execute_tool_call(agent, _make_tool_call("MyTool"))

    asyncio.run(_run())

    assert "_cancel_event" not in captured


def test_mcp_tool_cancel_cleanup_called_on_exception() -> None:
    """cancel_cleanup must be called even when tool.execute() raises."""

    async def _run() -> tuple:
        tool = MagicMock()
        setattr(tool, _MCP_TOOL_MARKER_ATTR, _MCP_TOOL_MARKER_VALUE)
        tool.definition.parameters = {"type": "object", "properties": {}, "required": []}

        async def _explode(_overrides=None, **kwargs):
            raise RuntimeError("boom")

        tool.execute = _explode

        agent = _make_agent(has_controller=True)
        agent._tool_map = {"mcp__test__bomb": tool}

        with _stub_tool_exec_internals():
            result = await execute_tool_call(agent, _make_tool_call("mcp__test__bomb"))

        return result, agent

    result, agent = asyncio.run(_run())

    # Should return error tool message, not propagate exception
    assert result.is_error
    # With a real SessionRunController, cleanup removes the registered callback.
    assert agent._run_controller._callbacks == {}
