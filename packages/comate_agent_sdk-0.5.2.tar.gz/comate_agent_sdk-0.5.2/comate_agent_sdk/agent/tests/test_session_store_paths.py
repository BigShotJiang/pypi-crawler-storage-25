from pathlib import Path

import pytest

from comate_agent_sdk.agent.session_store import (
    SessionStoreError,
    default_session_root,
    resolve_session_root,
)


def test_default_session_root_requires_cwd() -> None:
    with pytest.raises(SessionStoreError):
        default_session_root("s1", cwd=None)  # type: ignore[arg-type]


def test_resolve_session_root_requires_cwd() -> None:
    with pytest.raises(SessionStoreError):
        resolve_session_root(session_id="s1", cwd=None)  # type: ignore[arg-type]


def test_resolve_session_root_fallback_to_default() -> None:
    cwd = Path("/tmp/my-project")
    resolved = resolve_session_root(session_id="s1", cwd=cwd)
    assert resolved == default_session_root("s1", cwd=cwd)
