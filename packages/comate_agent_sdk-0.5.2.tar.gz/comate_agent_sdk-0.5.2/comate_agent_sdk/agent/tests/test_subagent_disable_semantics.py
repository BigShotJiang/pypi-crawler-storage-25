import contextlib
import asyncio
import json
import subprocess
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import MagicMock, patch

from comate_agent_sdk.agent import Agent, AgentConfig, ChatSession
from comate_agent_sdk.agent.events import SessionInitEvent, StopEvent, ToolResultEvent
from comate_agent_sdk.agent.setup import resolve_auto_memory_dir
from comate_agent_sdk.context.items import ItemType
from comate_agent_sdk.llm.messages import Function, ToolCall
from comate_agent_sdk.llm.views import ChatInvokeCompletion
from comate_agent_sdk.subagent.models import AgentDefinition
from comate_agent_sdk.subagent.agent_tool import _register_team_members, create_agent_tool
from comate_agent_sdk.subagent.builtin.explorer import ExplorerAgent
from comate_agent_sdk.subagent.builtin.general_purpose import GeneralPurposeAgent
from comate_agent_sdk.subagent.builtin.plan import PlanAgent
from comate_agent_sdk.subagent.team_session import TeamSessionActor
from comate_agent_sdk.agent.runner_engine.team_coordination import (
    _send_team_shutdown_response,
)
from comate_agent_sdk.system_tools.team.config import TeamConfig
from comate_agent_sdk.system_tools.team.inbox import Inbox
from comate_agent_sdk.system_tools.team.inbox_transport import TeamInboxEnvelope
from comate_agent_sdk.tools.registry import ToolRegistry


def _init_git_repo(root: Path) -> None:
    subprocess.run(["git", "init"], cwd=root, check=True, capture_output=True)
    subprocess.run(["git", "config", "user.email", "test@example.com"], cwd=root, check=True)
    subprocess.run(["git", "config", "user.name", "Test User"], cwd=root, check=True)
    (root / "README.md").write_text("seed\n", encoding="utf-8")
    subprocess.run(["git", "add", "README.md"], cwd=root, check=True)
    subprocess.run(["git", "commit", "-m", "init"], cwd=root, check=True, capture_output=True)


def _list_worktree_dirs(root: Path) -> list[Path]:
    worktree_root = root / ".agent" / "worktrees"
    if not worktree_root.exists():
        return []
    return sorted(path for path in worktree_root.iterdir() if path.is_dir())


class _FakeChatModel:
    def __init__(self, content: str = "ok") -> None:
        self.model = "fake:model"
        self._content = content

    @property
    def provider(self) -> str:
        return "fake"

    @property
    def name(self) -> str:
        return self.model

    async def ainvoke(self, messages, tools=None, tool_choice=None, **kwargs):  # type: ignore[no-untyped-def]
        return ChatInvokeCompletion(content=self._content)


class _SequenceChatModel:
    def __init__(self, completions: list[ChatInvokeCompletion]) -> None:
        self._completions = completions
        self._index = 0
        self.model = "fake:model"

    @property
    def provider(self) -> str:
        return "fake"

    @property
    def name(self) -> str:
        return self.model

    async def ainvoke(self, messages, tools=None, tool_choice=None, **kwargs):  # type: ignore[no-untyped-def]
        del messages, tools, tool_choice, kwargs
        if self._index >= len(self._completions):
            raise AssertionError(f"Unexpected ainvoke call #{self._index + 1}")
        completion = self._completions[self._index]
        self._index += 1
        return completion


class _FakeSubagentRuntime:
    def __init__(self, content: str = "subagent ok") -> None:
        self._runtime_state = SimpleNamespace(skills=[])
        self._content = content
        self.closed = False
        self._suppress_team_idle_notification = False

    async def query(self, prompt: str) -> str:
        _ = prompt
        return self._content

    async def aclose(self) -> None:
        self.closed = True


class _ControllableBackgroundRuntime(_FakeSubagentRuntime):
    def __init__(self, content: str = "subagent ok") -> None:
        super().__init__(content=content)
        import asyncio

        self.started = asyncio.Event()
        self.release = asyncio.Event()

    async def query(self, prompt: str) -> str:
        _ = prompt
        self.started.set()
        await self.release.wait()
        return self._content


class TestSubagentDisableSemantics(unittest.TestCase):
    def test_default_keeps_builtin_subagents(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            template = Agent(
                llm=_FakeChatModel(),  # type: ignore[arg-type]
                config=AgentConfig(
                    tools=(),
                    offload_enabled=False,
                    setting_sources=None,
                    cwd=Path(tmp),
                ),
            )

            names = {a.name for a in (template.resolved_agents or ())}

        self.assertIn("Explorer", names)
        self.assertIn("Plan", names)

    def test_agents_empty_tuple_disables_all_subagents(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            template = Agent(
                llm=_FakeChatModel(),  # type: ignore[arg-type]
                config=AgentConfig(
                    tools=(),
                    agents=(),
                    offload_enabled=False,
                    setting_sources=None,
                    cwd=Path(tmp),
                ),
            )
            runtime = template.create_runtime()

        self.assertEqual(template.resolved_agents, ())
        self.assertEqual(runtime._runtime_state.agents, [])

    def test_team_session_actor_max_iterations_sends_status_without_idle(self) -> None:
        actor = TeamSessionActor(
            session=MagicMock(),
            runtime=SimpleNamespace(_suppress_team_idle_notification=True),
            parent_runtime=None,
            subagent_type="worker",
            team_name="review-team",
            agent_name="worker-1",
            initial_prompt="run task",
        )

        with patch(
            "comate_agent_sdk.subagent.team_session.send_team_session_status_message"
        ) as status_mock, patch(
            "comate_agent_sdk.agent.runner_engine.team_coordination._send_team_idle_notification"
        ) as idle_mock:
            actor._handle_turn_completed("max_iterations", "", False)

        status_mock.assert_called_once()
        idle_mock.assert_not_called()

    def test_team_session_actor_reads_turn_routing_from_tool_raw_envelope(self) -> None:
        class _StubSession:
            def __init__(self, events: list[object]) -> None:
                self._events = events
                self._queue = SimpleNamespace(put_nowait=lambda _value: None)

            async def events(self):
                for event in self._events:
                    yield event

            async def shutdown(self) -> None:
                return None

        runtime = SimpleNamespace(
            _context=SimpleNamespace(
                turn_number=1,
                conversation=SimpleNamespace(
                    items=[
                        SimpleNamespace(
                            item_type=ItemType.TOOL_RESULT,
                            is_tool_error=False,
                            tool_name="SendMessage",
                            metadata={
                                "tool_raw_envelope": {
                                    "data": {
                                        "to": "worker-2",
                                    }
                                }
                            },
                            created_turn=1,
                        ),
                        SimpleNamespace(
                            item_type=ItemType.TOOL_RESULT,
                            is_tool_error=False,
                            tool_name="YieldTurn",
                            metadata={
                                "tool_raw_envelope": {
                                    "data": {
                                        "yield_status": "waiting_for_teammate",
                                    }
                                }
                            },
                            created_turn=1,
                        ),
                    ]
                ),
            )
        )
        actor = TeamSessionActor(
            session=_StubSession(
                [
                    SessionInitEvent(session_id="session-1"),
                    ToolResultEvent(
                        tool="SendMessage",
                        result="# SendMessage\n\nmessage sent",
                        tool_call_id="tc-send",
                        is_error=False,
                    ),
                    ToolResultEvent(
                        tool="YieldTurn",
                        result="# YieldTurn\n\nYielded turn with status=waiting_for_teammate",
                        tool_call_id="tc-yield",
                        is_error=False,
                    ),
                    StopEvent(reason="yielded"),
                ]
            ),
            runtime=runtime,
            parent_runtime=None,
            subagent_type="worker",
            team_name="review-team",
            agent_name="worker-1",
            initial_prompt="run task",
        )

        runtime._suppress_team_idle_notification = True
        with patch(
            "comate_agent_sdk.agent.runner_engine.team_coordination._send_team_idle_notification"
        ) as idle_mock:
            asyncio.run(actor.run())

        idle_mock.assert_called_once_with(
            runtime,
            stop_reason="yielded",
            yield_status="waiting_for_teammate",
            last_send_to="worker-2",
        )


class TestTaskToolNoNestedSubagentError(unittest.IsolatedAsyncioTestCase):
    async def test_task_created_subagent_no_longer_hits_nested_agents_guard(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            with patch.dict("os.environ", {"HOME": td}):
                task_tool = create_agent_tool(
                    agents=[
                        AgentDefinition(
                            name="worker",
                            description="test worker",
                            prompt="You are a worker.",
                            tools=[],
                        )
                    ],
                    parent_tools=[],
                    tool_registry=ToolRegistry(),
                    parent_cwd=Path.cwd(),
                    parent_llm=_FakeChatModel(content="subagent ok"),  # type: ignore[arg-type]
                )

                result = await task_tool.execute(
                    subagent_type="worker",
                    prompt="run task",
                    description="run worker",
                )

        self.assertEqual(result, "subagent ok")
        self.assertNotIn("不能再定义 agents", result)

    async def test_task_injects_agent_definition_extra_write_roots(self) -> None:
        fake_runtime = _FakeSubagentRuntime(content="ok-non-stream")
        with patch(
            "comate_agent_sdk.agent.core.template.AgentTemplate.create_runtime",
            return_value=fake_runtime,
        ):
            task_tool = create_agent_tool(
                agents=[
                    AgentDefinition(
                        name="worker",
                        description="test worker",
                        prompt="You are a worker.",
                        tools=[],
                        extra_write_roots=("~/.agent/plans",),
                    )
                ],
                parent_tools=[],
                tool_registry=ToolRegistry(),
                parent_cwd=Path.cwd(),
                parent_llm=_FakeChatModel(content="parent"),  # type: ignore[arg-type]
            )

            result = await task_tool.execute(
                subagent_type="worker",
                prompt="run task",
                description="run worker",
            )

        self.assertEqual(result, "ok-non-stream")
        self.assertEqual(
            getattr(fake_runtime, "_extra_write_roots", ()),
            ("~/.agent/plans",),
        )


class TestGeneralPurposeSharedAutoMemory(unittest.IsolatedAsyncioTestCase):
    async def test_subagent_shared_auto_memory_only_injects_memory_usage_not_memory_body(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            with patch.dict("os.environ", {"HOME": td}):
                root = Path(td) / "project"
                root.mkdir()

                parent_runtime = Agent(
                    llm=_FakeChatModel(),  # type: ignore[arg-type]
                    config=AgentConfig(
                        offload_enabled=False,
                        setting_sources=None,
                        cwd=root,
                    ),
                ).create_runtime(name="captain")

                shared_memory_dir = resolve_auto_memory_dir(parent_runtime)
                shared_memory_file = shared_memory_dir / "MEMORY.md"
                shared_memory_file.parent.mkdir(parents=True, exist_ok=True)
                shared_memory_file.write_text("GENERAL_MEMORY", encoding="utf-8")

                task_tool = create_agent_tool(
                    agents=[GeneralPurposeAgent],
                    parent_tools=list(parent_runtime._runtime_state.tools or []),
                    tool_registry=parent_runtime._runtime_state.tool_registry,  # type: ignore[arg-type]
                    parent_cwd=root,
                    parent_llm=_FakeChatModel(content="parent"),  # type: ignore[arg-type]
                    parent_runtime=parent_runtime,
                    use_streaming_task=True,
                )

                create_runtime = getattr(task_tool, "_create_subagent_runtime")
                runtime, _ = await create_runtime("general-purpose", "tc_gp_memory")

        memory_usage_item = runtime._context.header.find_one_by_type(ItemType.MEMORY_USAGE)
        self.assertIsNotNone(memory_usage_item)
        self.assertIn(shared_memory_dir.resolve().as_posix(), memory_usage_item.content_text)
        self.assertFalse(hasattr(runtime._context, "memory"))
        lowered_user_text = "\n".join(
            str(message.content)
            for message in runtime._context.lower()
            if getattr(message, "role", "") == "user"
        )
        self.assertNotIn("GENERAL_MEMORY", lowered_user_text)
        self.assertNotIn("<memory>", lowered_user_text)
        self.assertEqual(
            getattr(runtime, "_shared_auto_memory_dir", None),
            shared_memory_dir.resolve(),
        )

    async def test_general_purpose_worktree_uses_parent_shared_memory_usage_without_memory_body(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            with patch.dict("os.environ", {"HOME": td}):
                root = Path(td) / "repo"
                root.mkdir()
                _init_git_repo(root)

                parent_runtime = Agent(
                    llm=_FakeChatModel(),  # type: ignore[arg-type]
                    config=AgentConfig(
                        offload_enabled=False,
                        setting_sources=None,
                        cwd=root,
                    ),
                ).create_runtime(name="captain")

                shared_memory_dir = resolve_auto_memory_dir(parent_runtime)
                shared_memory_file = shared_memory_dir / "MEMORY.md"
                shared_memory_file.parent.mkdir(parents=True, exist_ok=True)
                shared_memory_file.write_text("WORKTREE_SHARED_MEMORY", encoding="utf-8")

                task_tool = create_agent_tool(
                    agents=[GeneralPurposeAgent],
                    parent_tools=list(parent_runtime._runtime_state.tools or []),
                    tool_registry=parent_runtime._runtime_state.tool_registry,  # type: ignore[arg-type]
                    parent_cwd=root,
                    parent_llm=_FakeChatModel(content="parent"),  # type: ignore[arg-type]
                    parent_runtime=parent_runtime,
                    use_streaming_task=True,
                )

                create_runtime = getattr(task_tool, "_create_subagent_runtime")
                runtime, _ = await create_runtime(
                    "general-purpose",
                    "tc_gp_worktree",
                    isolation="worktree",
                )

        self.assertNotEqual(runtime._runtime_state.cwd, parent_runtime._runtime_state.cwd)
        memory_usage_item = runtime._context.header.find_one_by_type(ItemType.MEMORY_USAGE)
        self.assertIsNotNone(memory_usage_item)
        self.assertIn(shared_memory_dir.resolve().as_posix(), memory_usage_item.content_text)
        self.assertFalse(hasattr(runtime._context, "memory"))
        lowered_user_text = "\n".join(
            str(message.content)
            for message in runtime._context.lower()
            if getattr(message, "role", "") == "user"
        )
        self.assertNotIn("WORKTREE_SHARED_MEMORY", lowered_user_text)
        self.assertNotIn("<memory>", lowered_user_text)
        self.assertEqual(
            getattr(runtime, "_shared_auto_memory_dir", None),
            shared_memory_dir.resolve(),
        )

    async def test_general_purpose_clear_history_rebuilds_shared_memory_usage_only(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            with patch.dict("os.environ", {"HOME": td}):
                root = Path(td) / "project"
                root.mkdir()

                parent_runtime = Agent(
                    llm=_FakeChatModel(),  # type: ignore[arg-type]
                    config=AgentConfig(
                        offload_enabled=False,
                        setting_sources=None,
                        cwd=root,
                    ),
                ).create_runtime(name="captain")

                shared_memory_dir = resolve_auto_memory_dir(parent_runtime)
                shared_memory_file = shared_memory_dir / "MEMORY.md"
                shared_memory_file.parent.mkdir(parents=True, exist_ok=True)
                shared_memory_file.write_text("RESETTABLE_MEMORY", encoding="utf-8")

                task_tool = create_agent_tool(
                    agents=[GeneralPurposeAgent],
                    parent_tools=list(parent_runtime._runtime_state.tools or []),
                    tool_registry=parent_runtime._runtime_state.tool_registry,  # type: ignore[arg-type]
                    parent_cwd=root,
                    parent_llm=_FakeChatModel(content="parent"),  # type: ignore[arg-type]
                    parent_runtime=parent_runtime,
                    use_streaming_task=True,
                )

                create_runtime = getattr(task_tool, "_create_subagent_runtime")
                runtime, _ = await create_runtime("general-purpose", "tc_gp_reset")

                runtime.clear_history()

        memory_usage_item = runtime._context.header.find_one_by_type(ItemType.MEMORY_USAGE)
        self.assertIsNotNone(memory_usage_item)
        self.assertIn(shared_memory_dir.resolve().as_posix(), memory_usage_item.content_text)
        self.assertFalse(hasattr(runtime._context, "memory"))
        lowered_user_text = "\n".join(
            str(message.content)
            for message in runtime._context.lower()
            if getattr(message, "role", "") == "user"
        )
        self.assertNotIn("RESETTABLE_MEMORY", lowered_user_text)
        self.assertNotIn("<memory>", lowered_user_text)


class TestTeamSemantics(unittest.IsolatedAsyncioTestCase):
    def setUp(self) -> None:
        super().setUp()
        self._team_poll_patch = patch.dict(
            "os.environ",
            {"COMATE_TEAM_POLL_INTERVAL_SECONDS": "0.01"},
        )
        self._team_poll_patch.start()
        self.addCleanup(self._team_poll_patch.stop)

    async def _wait_for_team_session(
        self,
        runtime,
        *,
        team_name: str,
        name: str,
    ) -> None:
        for _ in range(50):
            if runtime.has_active_team_session(team_name=team_name, name=name):
                return
            await asyncio.sleep(0.01)
        self.fail(f"Timed out waiting for team session {team_name}/{name} to start")

    async def _shutdown_team_session(
        self,
        runtime,
        *,
        team_name: str,
        name: str,
    ) -> None:
        Inbox(team_name=team_name, agent_name=name).append_message(
            from_agent="captain",
            message_type="shutdown_request",
            content="stop",
        )
        for _ in range(50):
            if not runtime.has_active_team_session(team_name=team_name, name=name):
                return
            await asyncio.sleep(0.02)
        self.fail(f"Timed out waiting for team session {team_name}/{name} to stop")

    def test_register_team_members_uses_parent_runtime_name(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            with patch.dict("os.environ", {"COMATE_TEAMS_DIR": td}):
                parent_runtime = SimpleNamespace(name="captain")

                _register_team_members(
                    team_name="review-team",
                    parent_runtime=parent_runtime,
                    subagent_name="worker-1",
                    subagent_type="researcher",
                )

                members = TeamConfig(team_name="review-team").list_members()

        self.assertEqual(
            [(member["name"], member["agent_type"]) for member in members],
            [("captain", "leader"), ("worker-1", "researcher")],
        )

    async def test_shutdown_request_preempts_buffered_auto_inbox_turn(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            with patch.dict("os.environ", {"COMATE_TEAMS_DIR": td, "COMATE_TASK_STORE_DIR": td}):
                runtime = Agent(
                    llm=_FakeChatModel(),  # type: ignore[arg-type]
                    config=AgentConfig(
                        tools=(),
                        agents=(),
                        offload_enabled=False,
                        setting_sources=None,
                        cwd=Path(td),
                    ),
                ).create_runtime(
                    name="captain",
                    team_name="review-team",
                    task_namespace="review-team",
                )
                TeamConfig(team_name="review-team").register_member(
                    name="captain",
                    agent_type="leader",
                )
                runtime._team.pending_inbox_events.append(
                    TeamInboxEnvelope(
                        key="shutdown-1",
                        from_agent="worker-1",
                        message_type="shutdown_request",
                        content="stop",
                        timestamp="2026-03-11T00:00:00+00:00",
                        raw_envelope={},
                    )
                )
                runtime._team.pending_inbox_keys.add("shutdown-1")

                reasons: list[str] = []
                async for event in runtime.query_stream("hello"):
                    if isinstance(event, StopEvent):
                        reasons.append(event.reason)

        self.assertEqual(reasons, ["shutdown_request"])

    async def test_task_inherits_parent_task_namespace(self) -> None:
        fake_runtime = _FakeSubagentRuntime(content="ok-non-stream")

        # 创建 mock parent runtime（携带 task namespace）
        mock_parent = MagicMock()
        mock_parent._task_namespace = "shared-work"
        mock_parent._team_name = ""
        mock_parent.is_team_member = False

        with patch(
            "comate_agent_sdk.agent.core.template.AgentTemplate.create_runtime",
            return_value=fake_runtime,
        ) as create_runtime:
            task_tool = create_agent_tool(
                agents=[
                    AgentDefinition(
                        name="worker",
                        description="test worker",
                        prompt="You are a worker.",
                        tools=[],
                    )
                ],
                parent_tools=[],
                tool_registry=ToolRegistry(),
                parent_cwd=Path.cwd(),
                parent_llm=_FakeChatModel(content="parent"),  # type: ignore[arg-type]
                parent_runtime=mock_parent,
            )

            result = await task_tool.execute(
                subagent_type="worker",
                prompt="run task",
                description="run worker",
            )

        self.assertEqual(result, "ok-non-stream")
        _, kwargs = create_runtime.call_args
        self.assertEqual(kwargs["task_namespace"], "shared-work")

    async def test_streaming_task_injects_agent_definition_extra_write_roots(self) -> None:
        fake_runtime = _FakeSubagentRuntime(content="ok-stream")
        with patch(
            "comate_agent_sdk.agent.core.template.AgentTemplate.create_runtime",
            return_value=fake_runtime,
        ):
            task_tool = create_agent_tool(
                agents=[
                    AgentDefinition(
                        name="worker",
                        description="test worker",
                        prompt="You are a worker.",
                        tools=[],
                        extra_write_roots=("~/.agent/plans",),
                    )
                ],
                parent_tools=[],
                tool_registry=ToolRegistry(),
                parent_cwd=Path.cwd(),
                parent_llm=_FakeChatModel(content="parent"),  # type: ignore[arg-type]
                use_streaming_task=True,
            )

            create_runtime = getattr(task_tool, "_create_subagent_runtime")
            runtime, _ = await create_runtime("worker", "tc_stream")

        self.assertIs(runtime, fake_runtime)
        self.assertEqual(
            getattr(fake_runtime, "_extra_write_roots", ()),
            ("~/.agent/plans",),
        )

    async def test_team_subagent_system_prompt_keeps_instance_name_only(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            with patch.dict("os.environ", {"COMATE_TEAMS_DIR": td, "COMATE_TASK_STORE_DIR": td, "HOME": td}):
                parent_runtime = Agent(
                    llm=_FakeChatModel(),  # type: ignore[arg-type]
                    config=AgentConfig(
                        tools=(),
                        agents=(),
                        offload_enabled=False,
                        setting_sources=None,
                        cwd=Path(td),
                    ),
                ).create_runtime(
                    name="captain",
                    task_namespace="solo-work",
                )

                task_tool = create_agent_tool(
                    agents=[
                        AgentDefinition(
                            name="worker",
                            description="test worker",
                            prompt="You are a worker.",
                            tools=[],
                        )
                    ],
                    parent_tools=[],
                    tool_registry=ToolRegistry(),
                    parent_cwd=Path(td),
                    parent_llm=_FakeChatModel(content="parent"),  # type: ignore[arg-type]
                    parent_runtime=parent_runtime,
                    use_streaming_task=True,
                )

                # 必须先创建 team config（TeamCreate 的职责）
                from comate_agent_sdk.system_tools.team.config import TeamConfig
                team_cfg = TeamConfig(team_name="review-team")
                team_cfg.register_member(name="captain", agent_type="leader")

                create_runtime = getattr(task_tool, "_create_subagent_runtime")
                runtime, _ = await create_runtime(
                    "worker",
                    "tc_prompt",
                    team_name="review-team",
                    name="worker-1",
                )

        prompt_item = runtime._context.header.find_one_by_type(ItemType.SYSTEM_PROMPT)
        assert prompt_item is not None
        prompt_text = prompt_item.content_text
        self.assertIn("Your instance name: worker-1", prompt_text)
        self.assertNotIn("Team: review-team", prompt_text)
        self.assertNotIn("You share a task list with other agents in this team.", prompt_text)

    async def test_team_mode_can_append_coordination_tools_for_builtin_explorer(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            with patch.dict("os.environ", {"COMATE_TEAMS_DIR": td, "COMATE_TASK_STORE_DIR": td, "HOME": td}):
                parent_runtime = Agent(
                    llm=_FakeChatModel(),  # type: ignore[arg-type]
                    config=AgentConfig(
                        offload_enabled=False,
                        setting_sources=None,
                        cwd=Path(td),
                    ),
                ).create_runtime(
                    name="captain",
                    team_name="review-team",
                )
                TeamConfig(team_name="review-team").register_member(
                    name="captain",
                    agent_type="leader",
                )

                task_tool = create_agent_tool(
                    agents=[ExplorerAgent],
                    parent_tools=list(parent_runtime._runtime_state.tools or []),
                    tool_registry=parent_runtime._runtime_state.tool_registry,  # type: ignore[arg-type]
                    parent_cwd=Path(td),
                    parent_llm=_FakeChatModel(content="parent"),  # type: ignore[arg-type]
                    parent_runtime=parent_runtime,
                    use_streaming_task=True,
                )

                create_runtime = getattr(task_tool, "_create_subagent_runtime")
                runtime, _ = await create_runtime(
                    "Explorer",
                    "tc_explorer_team",
                    team_name="review-team",
                    name="explorer-1",
                )

        tool_names = {tool.name for tool in runtime._runtime_state.tools}
        self.assertTrue(
            {
                "TaskList",
                "TaskGet",
                "TaskUpdate",
                "SendMessage",
            }.issubset(tool_names)
        )
        self.assertNotIn("TaskCreate", tool_names)
        self.assertNotIn("Agent", tool_names)
        self.assertNotIn("AskUserQuestion", tool_names)

        schema_tool_names = {definition.name for definition in runtime.tool_definitions}
        self.assertIn("SendMessage", schema_tool_names)
        self.assertIn("TaskList", schema_tool_names)
        self.assertNotIn("TaskCreate", schema_tool_names)

        prompt_item = runtime._context.header.find_one_by_type(ItemType.SYSTEM_PROMPT)
        assert prompt_item is not None
        prompt_text = prompt_item.content_text
        self.assertIn(
            "MAY use TaskList, TaskGet, TaskUpdate, and SendMessage",
            prompt_text,
        )
        self.assertIn(
            "do NOT grant permission to modify project files or system state",
            prompt_text,
        )

    async def test_non_team_mode_builtin_plan_keeps_coordination_tools_hidden(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            with patch.dict("os.environ", {"HOME": td}):
                parent_runtime = Agent(
                    llm=_FakeChatModel(),  # type: ignore[arg-type]
                    config=AgentConfig(
                        offload_enabled=False,
                        setting_sources=None,
                        cwd=Path(td),
                    ),
                ).create_runtime(
                    name="captain",
                )

                task_tool = create_agent_tool(
                    agents=[PlanAgent],
                    parent_tools=list(parent_runtime._runtime_state.tools or []),
                    tool_registry=parent_runtime._runtime_state.tool_registry,  # type: ignore[arg-type]
                    parent_cwd=Path(td),
                    parent_llm=_FakeChatModel(content="parent"),  # type: ignore[arg-type]
                    parent_runtime=parent_runtime,
                    use_streaming_task=True,
                )

                create_runtime = getattr(task_tool, "_create_subagent_runtime")
                runtime, _ = await create_runtime(
                    "Plan",
                    "tc_plan_solo",
                    name="planner-1",
                )

        tool_names = {tool.name for tool in runtime._runtime_state.tools}
        self.assertFalse(
            {
                "TaskList",
                "TaskGet",
                "TaskUpdate",
                "SendMessage",
            }.intersection(tool_names)
        )

    async def test_team_mode_keeps_explicit_whitelist_for_subagents_without_coordination_flag(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            with patch.dict("os.environ", {"COMATE_TEAMS_DIR": td, "COMATE_TASK_STORE_DIR": td, "HOME": td}):
                parent_runtime = Agent(
                    llm=_FakeChatModel(),  # type: ignore[arg-type]
                    config=AgentConfig(
                        offload_enabled=False,
                        setting_sources=None,
                        cwd=Path(td),
                    ),
                ).create_runtime(
                    name="captain",
                    team_name="review-team",
                )
                TeamConfig(team_name="review-team").register_member(
                    name="captain",
                    agent_type="leader",
                )

                task_tool = create_agent_tool(
                    agents=[
                        AgentDefinition(
                            name="worker",
                            description="test worker",
                            prompt="You are a worker.",
                            tools=["Read"],
                        )
                    ],
                    parent_tools=list(parent_runtime._runtime_state.tools or []),
                    tool_registry=parent_runtime._runtime_state.tool_registry,  # type: ignore[arg-type]
                    parent_cwd=Path(td),
                    parent_llm=_FakeChatModel(content="parent"),  # type: ignore[arg-type]
                    parent_runtime=parent_runtime,
                    use_streaming_task=True,
                )

                create_runtime = getattr(task_tool, "_create_subagent_runtime")
                runtime, _ = await create_runtime(
                    "worker",
                    "tc_worker_team",
                    team_name="review-team",
                    name="worker-1",
                )

        tool_names = {tool.name for tool in runtime._runtime_state.tools}
        self.assertIn("Read", tool_names)
        self.assertFalse(
            {
                "TaskList",
                "TaskGet",
                "TaskUpdate",
                "SendMessage",
            }.intersection(tool_names)
        )

    async def test_team_session_requires_team_mode_matching_team_and_name(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            with patch.dict("os.environ", {"COMATE_TEAMS_DIR": td, "COMATE_TASK_STORE_DIR": td, "HOME": td}):
                parent_runtime = Agent(
                    llm=_FakeChatModel(),  # type: ignore[arg-type]
                    config=AgentConfig(
                        tools=(),
                        agents=(),
                        offload_enabled=False,
                        setting_sources=None,
                        cwd=Path(td),
                    ),
                ).create_runtime(
                    name="captain",
                    team_name="review-team",
                )
                TeamConfig(team_name="review-team").register_member(
                    name="captain",
                    agent_type="leader",
                )

                task_tool = create_agent_tool(
                    agents=[
                        AgentDefinition(
                            name="worker",
                            description="test worker",
                            prompt="You are a worker.",
                            tools=[],
                        )
                    ],
                    parent_tools=[],
                    tool_registry=ToolRegistry(),
                    parent_cwd=Path(td),
                    parent_llm=_FakeChatModel(content="parent"),  # type: ignore[arg-type]
                    parent_runtime=parent_runtime,
                )

                missing_name = await task_tool.execute(
                    subagent_type="worker",
                    prompt="run task",
                    team_name="review-team",
                )
                wrong_team = await task_tool.execute(
                    subagent_type="worker",
                    prompt="run task",
                    team_name="other-team",
                    name="worker-1",
                )

        self.assertEqual(missing_name, "Error: team_name requires a non-empty name.")
        self.assertIn("leader's current team", wrong_team)

    async def test_team_session_registration_rejects_duplicate_name(self) -> None:
        background_runtime = _ControllableBackgroundRuntime(content="background result")
        with tempfile.TemporaryDirectory() as td:
            with patch.dict("os.environ", {"COMATE_TEAMS_DIR": td, "COMATE_TASK_STORE_DIR": td, "HOME": td}):
                parent_runtime = Agent(
                    llm=_FakeChatModel(),  # type: ignore[arg-type]
                    config=AgentConfig(
                        tools=(),
                        agents=(),
                        offload_enabled=False,
                        setting_sources=None,
                        cwd=Path(td),
                    ),
                ).create_runtime(
                    name="captain",
                    team_name="review-team",
                )
                TeamConfig(team_name="review-team").register_member(
                    name="captain",
                    agent_type="leader",
                )

                async def _fake_team_session() -> None:
                    try:
                        await background_runtime.query("run task")
                    finally:
                        await background_runtime.aclose()

                with patch(
                    "comate_agent_sdk.agent.core.template.AgentTemplate.create_runtime",
                    return_value=background_runtime,
                ), patch(
                    "comate_agent_sdk.subagent.team_session.start_team_session",
                    return_value=asyncio.create_task(_fake_team_session()),
                ):
                    task_tool = create_agent_tool(
                        agents=[
                            AgentDefinition(
                                name="worker",
                                description="test worker",
                                prompt="You are a worker.",
                                tools=[],
                            )
                        ],
                        parent_tools=[],
                        tool_registry=ToolRegistry(),
                        parent_cwd=Path(td),
                        parent_llm=_FakeChatModel(content="parent"),  # type: ignore[arg-type]
                        parent_runtime=parent_runtime,
                    )

                    result = await task_tool.execute(
                        subagent_type="worker",
                        prompt="run task",
                        team_name="review-team",
                        name="worker-1",
                    )
                    await asyncio.wait_for(background_runtime.started.wait(), timeout=1.0)

                    duplicate = await task_tool.execute(
                        subagent_type="worker",
                        prompt="run task again",
                        team_name="review-team",
                        name="worker-1",
                    )

                    self.assertTrue(
                        parent_runtime.has_active_team_session(
                            team_name="review-team",
                            name="worker-1",
                        )
                    )

                    background_runtime.release.set()
                    await asyncio.wait_for(asyncio.sleep(0), timeout=1.0)

                    for _ in range(50):
                        if not parent_runtime.has_active_team_session(
                            team_name="review-team",
                            name="worker-1",
                        ):
                            break
                        await asyncio.sleep(0.01)

        self.assertIn("started working", result)
        self.assertIn("Use SendMessage for follow-up", duplicate)
        self.assertFalse(
            parent_runtime.has_active_team_session(
                team_name="review-team",
                name="worker-1",
            )
        )
        self.assertTrue(background_runtime.closed)

    async def test_team_session_followup_auto_forwards_final_text_to_leader(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            with patch.dict("os.environ", {"COMATE_TEAMS_DIR": td, "COMATE_TASK_STORE_DIR": td, "HOME": td}):
                parent_runtime = Agent(
                    llm=_FakeChatModel(),  # type: ignore[arg-type]
                    config=AgentConfig(
                        tools=(),
                        agents=(),
                        offload_enabled=False,
                        setting_sources=None,
                        cwd=Path(td),
                    ),
                ).create_runtime(
                    name="captain",
                    team_name="review-team",
                )
                TeamConfig(team_name="review-team").register_member(
                    name="captain",
                    agent_type="leader",
                )

                team_llm = _SequenceChatModel(
                    [
                        ChatInvokeCompletion(content="initial done"),
                        ChatInvokeCompletion(content="follow-up reply"),
                    ]
                )
                task_tool = create_agent_tool(
                    agents=[
                        AgentDefinition(
                            name="worker",
                            description="test worker",
                            prompt="You are a worker.",
                            tools=[],
                        )
                    ],
                    parent_tools=[],
                    tool_registry=ToolRegistry(),
                    parent_cwd=Path(td),
                    parent_llm=team_llm,  # type: ignore[arg-type]
                    parent_runtime=parent_runtime,
                )

                result = await task_tool.execute(
                    subagent_type="worker",
                    prompt="run task",
                    team_name="review-team",
                    name="worker-1",
                )

                await self._wait_for_team_session(
                    parent_runtime,
                    team_name="review-team",
                    name="worker-1",
                )

                leader_inbox = Inbox(team_name="review-team", agent_name="captain")
                for _ in range(50):
                    if leader_inbox.read_all():
                        break
                    await asyncio.sleep(0.01)

                worker_inbox = Inbox(team_name="review-team", agent_name="worker-1")
                worker_inbox.append_message(
                    from_agent="captain",
                    content="hello follow-up",
                )

                all_messages: list[dict] = []
                for _ in range(100):
                    all_messages = leader_inbox.read_all()
                    payloads = [json.loads(message["text"]) for message in all_messages]
                    idle_count = sum(
                        1
                        for payload in payloads
                        if payload.get("type") == "idle_notification"
                    )
                    has_reply = any(
                        payload.get("type") == "message"
                        and payload.get("content") == "follow-up reply"
                        for payload in payloads
                    )
                    if idle_count >= 2 and has_reply:
                        break
                    await asyncio.sleep(0.02)

                worker_messages = worker_inbox.read_all()
                await self._shutdown_team_session(
                    parent_runtime,
                    team_name="review-team",
                    name="worker-1",
                )

        self.assertIn("started working", result)
        payloads = [json.loads(message["text"]) for message in all_messages]
        self.assertTrue(
            any(
                payload.get("type") == "message"
                and payload.get("content") == "follow-up reply"
                for payload in payloads
            )
        )
        self.assertGreaterEqual(
            sum(1 for payload in payloads if payload.get("type") == "idle_notification"),
            2,
        )
        self.assertTrue(worker_messages)
        self.assertEqual(json.loads(worker_messages[-1]["text"])["content"], "hello follow-up")
        self.assertTrue(worker_messages[-1]["read"])

    async def test_team_session_initial_turn_auto_forwards_final_text_before_idle(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            with patch.dict("os.environ", {"COMATE_TEAMS_DIR": td, "COMATE_TASK_STORE_DIR": td, "HOME": td}):
                parent_runtime = Agent(
                    llm=_FakeChatModel(),  # type: ignore[arg-type]
                    config=AgentConfig(
                        agents=(),
                        offload_enabled=False,
                        setting_sources=None,
                        cwd=Path(td),
                    ),
                ).create_runtime(
                    name="captain",
                    team_name="review-team",
                )
                TeamConfig(team_name="review-team").register_member(
                    name="captain",
                    agent_type="leader",
                )

                team_llm = _SequenceChatModel(
                    [ChatInvokeCompletion(content="initial delivery")]
                )
                task_tool = create_agent_tool(
                    agents=[
                        AgentDefinition(
                            name="worker",
                            description="test worker",
                            prompt="You are a worker.",
                            tools=[],
                        )
                    ],
                    parent_tools=[],
                    tool_registry=ToolRegistry(),
                    parent_cwd=Path(td),
                    parent_llm=team_llm,  # type: ignore[arg-type]
                    parent_runtime=parent_runtime,
                )

                await task_tool.execute(
                    subagent_type="worker",
                    prompt="run task",
                    team_name="review-team",
                    name="worker-1",
                )

                await self._wait_for_team_session(
                    parent_runtime,
                    team_name="review-team",
                    name="worker-1",
                )

                leader_inbox = Inbox(team_name="review-team", agent_name="captain")
                all_messages: list[dict] = []
                for _ in range(100):
                    all_messages = leader_inbox.read_all()
                    payloads = [json.loads(message["text"]) for message in all_messages]
                    has_delivery = any(
                        payload.get("type") == "message"
                        and payload.get("content") == "initial delivery"
                        for payload in payloads
                    )
                    has_idle = any(
                        payload.get("type") == "idle_notification"
                        for payload in payloads
                    )
                    if has_delivery and has_idle:
                        break
                    await asyncio.sleep(0.02)

                await self._shutdown_team_session(
                    parent_runtime,
                    team_name="review-team",
                    name="worker-1",
                )

        payloads = [json.loads(message["text"]) for message in all_messages]
        self.assertTrue(
            any(
                payload.get("type") == "message"
                and payload.get("content") == "initial delivery"
                for payload in payloads
            )
        )
        self.assertTrue(any(payload.get("type") == "idle_notification" for payload in payloads))
        initial_index = next(
            index
            for index, payload in enumerate(payloads)
            if payload.get("type") == "message" and payload.get("content") == "initial delivery"
        )
        idle_index = next(
            index
            for index, payload in enumerate(payloads)
            if payload.get("type") == "idle_notification"
        )
        self.assertLess(initial_index, idle_index)
        self.assertIn("idle_reason: completed", payloads[idle_index]["content"])

    async def test_team_session_followup_sendmessage_success_suppresses_auto_forward(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            with patch.dict("os.environ", {"COMATE_TEAMS_DIR": td, "COMATE_TASK_STORE_DIR": td, "HOME": td}):
                parent_runtime = Agent(
                    llm=_FakeChatModel(),  # type: ignore[arg-type]
                    config=AgentConfig(
                        agents=(),
                        offload_enabled=False,
                        setting_sources=None,
                        cwd=Path(td),
                    ),
                ).create_runtime(
                    name="captain",
                    team_name="review-team",
                )
                TeamConfig(team_name="review-team").register_member(
                    name="captain",
                    agent_type="leader",
                )

                team_llm = _SequenceChatModel(
                    [
                        ChatInvokeCompletion(content="initial done"),
                        ChatInvokeCompletion(
                            tool_calls=[
                                ToolCall(
                                    id="tc_send_ok",
                                    function=Function(
                                        name="SendMessage",
                                        arguments=json.dumps(
                                            {
                                                "to": "captain",
                                                "content": "explicit message",
                                                "type": "message",
                                            },
                                            ensure_ascii=False,
                                        ),
                                    ),
                                )
                            ]
                        ),
                        ChatInvokeCompletion(content="internal final summary"),
                    ]
                )
                task_tool = create_agent_tool(
                    agents=[
                        AgentDefinition(
                            name="worker",
                            description="test worker",
                            prompt="You are a worker.",
                            tools=None,
                        )
                    ],
                    parent_tools=list(parent_runtime._runtime_state.tools or []),
                    tool_registry=parent_runtime._runtime_state.tool_registry,  # type: ignore[arg-type]
                    parent_cwd=Path(td),
                    parent_llm=team_llm,  # type: ignore[arg-type]
                    parent_runtime=parent_runtime,
                )

                await task_tool.execute(
                    subagent_type="worker",
                    prompt="run task",
                    team_name="review-team",
                    name="worker-1",
                )

                await self._wait_for_team_session(
                    parent_runtime,
                    team_name="review-team",
                    name="worker-1",
                )

                leader_inbox = Inbox(team_name="review-team", agent_name="captain")
                for _ in range(50):
                    if leader_inbox.read_all():
                        break
                    await asyncio.sleep(0.01)

                Inbox(team_name="review-team", agent_name="worker-1").append_message(
                    from_agent="captain",
                    content="hello follow-up",
                )

                all_messages: list[dict] = []
                for _ in range(100):
                    all_messages = leader_inbox.read_all()
                    payloads = [json.loads(message["text"]) for message in all_messages]
                    if any(
                        payload.get("type") == "message"
                        and payload.get("content") == "explicit message"
                        for payload in payloads
                    ):
                        if sum(
                            1
                            for payload in payloads
                            if payload.get("type") == "idle_notification"
                        ) >= 2:
                            break
                    await asyncio.sleep(0.02)

                await self._shutdown_team_session(
                    parent_runtime,
                    team_name="review-team",
                    name="worker-1",
                )

        payloads = [json.loads(message["text"]) for message in all_messages]
        self.assertEqual(
            sum(
                1
                for payload in payloads
                if payload.get("type") == "message"
                and payload.get("content") == "explicit message"
            ),
            1,
        )
        self.assertFalse(
            any(
                payload.get("type") == "message"
                and payload.get("content") == "internal final summary"
                for payload in payloads
            )
        )

    async def test_team_session_followup_sendmessage_then_waiting_for_teammate_stays_quiet(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            with patch.dict("os.environ", {"COMATE_TEAMS_DIR": td, "COMATE_TASK_STORE_DIR": td, "HOME": td}):
                parent_runtime = Agent(
                    llm=_FakeChatModel(),  # type: ignore[arg-type]
                    config=AgentConfig(
                        agents=(),
                        offload_enabled=False,
                        setting_sources=None,
                        cwd=Path(td),
                    ),
                ).create_runtime(
                    name="captain",
                    team_name="review-team",
                )
                TeamConfig(team_name="review-team").register_member(
                    name="captain",
                    agent_type="leader",
                )

                team_llm = _SequenceChatModel(
                    [
                        ChatInvokeCompletion(content="initial done"),
                        ChatInvokeCompletion(
                            tool_calls=[
                                ToolCall(
                                    id="tc_send_ok",
                                    function=Function(
                                        name="SendMessage",
                                        arguments=json.dumps(
                                            {
                                                "to": "captain",
                                                "content": "explicit message",
                                                "type": "message",
                                            },
                                            ensure_ascii=False,
                                        ),
                                    ),
                                )
                            ]
                        ),
                        ChatInvokeCompletion(
                            tool_calls=[
                                ToolCall(
                                    id="tc_yield_followup",
                                    function=Function(
                                        name="YieldTurn",
                                        arguments=json.dumps(
                                            {"status": "waiting_for_teammate"},
                                            ensure_ascii=False,
                                        ),
                                    ),
                                )
                            ]
                        ),
                    ]
                )
                task_tool = create_agent_tool(
                    agents=[
                        AgentDefinition(
                            name="worker",
                            description="test worker",
                            prompt="You are a worker.",
                            tools=None,
                        )
                    ],
                    parent_tools=list(parent_runtime._runtime_state.tools or []),
                    tool_registry=parent_runtime._runtime_state.tool_registry,  # type: ignore[arg-type]
                    parent_cwd=Path(td),
                    parent_llm=team_llm,  # type: ignore[arg-type]
                    parent_runtime=parent_runtime,
                )

                await task_tool.execute(
                    subagent_type="worker",
                    prompt="run task",
                    team_name="review-team",
                    name="worker-1",
                )

                await self._wait_for_team_session(
                    parent_runtime,
                    team_name="review-team",
                    name="worker-1",
                )

                leader_inbox = Inbox(team_name="review-team", agent_name="captain")
                for _ in range(50):
                    if leader_inbox.read_all():
                        break
                    await asyncio.sleep(0.01)

                Inbox(team_name="review-team", agent_name="worker-1").append_message(
                    from_agent="captain",
                    content="hello follow-up",
                )

                all_messages: list[dict] = []
                for _ in range(100):
                    all_messages = leader_inbox.read_all()
                    payloads = [json.loads(message["text"]) for message in all_messages]
                    explicit_count = sum(
                        1
                        for payload in payloads
                        if payload.get("type") == "message"
                        and payload.get("content") == "explicit message"
                    )
                    idle_count = sum(
                        1
                        for payload in payloads
                        if payload.get("type") == "idle_notification"
                    )
                    if explicit_count == 1 and idle_count >= 1:
                        break
                    await asyncio.sleep(0.02)

                await asyncio.sleep(0.1)
                all_messages = leader_inbox.read_all()
                await self._shutdown_team_session(
                    parent_runtime,
                    team_name="review-team",
                    name="worker-1",
                )

        payloads = [json.loads(message["text"]) for message in all_messages]
        self.assertEqual(
            sum(
                1
                for payload in payloads
                if payload.get("type") == "message"
                and payload.get("content") == "explicit message"
            ),
            1,
        )
        self.assertFalse(
            any(
                payload.get("type") == "message"
                and payload.get("content") == "internal final summary"
                for payload in payloads
            )
        )
        idle_payloads = [
            payload
            for payload in payloads
            if payload.get("type") == "idle_notification"
        ]
        self.assertEqual(
            len(idle_payloads),
            1,
        )
        self.assertTrue(
            all(
                "idle_reason: yielded" not in str(payload.get("content", ""))
                for payload in idle_payloads
            )
        )

    async def test_team_session_followup_sendmessage_failure_falls_back_to_auto_forward(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            with patch.dict("os.environ", {"COMATE_TEAMS_DIR": td, "COMATE_TASK_STORE_DIR": td, "HOME": td}):
                parent_runtime = Agent(
                    llm=_FakeChatModel(),  # type: ignore[arg-type]
                    config=AgentConfig(
                        agents=(),
                        offload_enabled=False,
                        setting_sources=None,
                        cwd=Path(td),
                    ),
                ).create_runtime(
                    name="captain",
                    team_name="review-team",
                )
                TeamConfig(team_name="review-team").register_member(
                    name="captain",
                    agent_type="leader",
                )

                team_llm = _SequenceChatModel(
                    [
                        ChatInvokeCompletion(content="initial done"),
                        ChatInvokeCompletion(
                            tool_calls=[
                                ToolCall(
                                    id="tc_send_fail",
                                    function=Function(
                                        name="SendMessage",
                                        arguments=json.dumps(
                                            {
                                                "to": "captain",
                                                "content": "will fail",
                                                "type": "invalid-type",
                                            },
                                            ensure_ascii=False,
                                        ),
                                    ),
                                )
                            ]
                        ),
                        ChatInvokeCompletion(content="fallback final summary"),
                    ]
                )
                task_tool = create_agent_tool(
                    agents=[
                        AgentDefinition(
                            name="worker",
                            description="test worker",
                            prompt="You are a worker.",
                            tools=None,
                        )
                    ],
                    parent_tools=list(parent_runtime._runtime_state.tools or []),
                    tool_registry=parent_runtime._runtime_state.tool_registry,  # type: ignore[arg-type]
                    parent_cwd=Path(td),
                    parent_llm=team_llm,  # type: ignore[arg-type]
                    parent_runtime=parent_runtime,
                )

                await task_tool.execute(
                    subagent_type="worker",
                    prompt="run task",
                    team_name="review-team",
                    name="worker-1",
                )

                await self._wait_for_team_session(
                    parent_runtime,
                    team_name="review-team",
                    name="worker-1",
                )

                leader_inbox = Inbox(team_name="review-team", agent_name="captain")
                for _ in range(50):
                    if leader_inbox.read_all():
                        break
                    await asyncio.sleep(0.01)

                Inbox(team_name="review-team", agent_name="worker-1").append_message(
                    from_agent="captain",
                    content="hello follow-up",
                )

                all_messages: list[dict] = []
                for _ in range(100):
                    all_messages = leader_inbox.read_all()
                    payloads = [json.loads(message["text"]) for message in all_messages]
                    if any(
                        payload.get("type") == "message"
                        and payload.get("content") == "fallback final summary"
                        for payload in payloads
                    ):
                        break
                    await asyncio.sleep(0.02)

                await self._shutdown_team_session(
                    parent_runtime,
                    team_name="review-team",
                    name="worker-1",
                )

        payloads = [json.loads(message["text"]) for message in all_messages]
        self.assertTrue(
            any(
                payload.get("type") == "message"
                and payload.get("content") == "fallback final summary"
                for payload in payloads
            )
        )
        self.assertFalse(
            any(
                payload.get("type") == "message"
                and payload.get("content") == "will fail"
                for payload in payloads
            )
        )

    async def test_real_team_session_stays_alive_after_idle_and_shutdown_via_inbox(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            with patch.dict("os.environ", {"COMATE_TEAMS_DIR": td, "COMATE_TASK_STORE_DIR": td, "HOME": td}):
                parent_runtime = Agent(
                    llm=_FakeChatModel(),  # type: ignore[arg-type]
                    config=AgentConfig(
                        tools=(),
                        agents=(),
                        offload_enabled=False,
                        setting_sources=None,
                        cwd=Path(td),
                    ),
                ).create_runtime(
                    name="captain",
                    team_name="review-team",
                )
                TeamConfig(team_name="review-team").register_member(
                    name="captain",
                    agent_type="leader",
                )

                task_tool = create_agent_tool(
                    agents=[
                        AgentDefinition(
                            name="worker",
                            description="test worker",
                            prompt="You are a worker.",
                            tools=[],
                        )
                    ],
                    parent_tools=[],
                    tool_registry=ToolRegistry(),
                    parent_cwd=Path(td),
                    parent_llm=_FakeChatModel(content="parent"),  # type: ignore[arg-type]
                    parent_runtime=parent_runtime,
                )

                result = await task_tool.execute(
                    subagent_type="worker",
                    prompt="run task",
                    team_name="review-team",
                    name="worker-1",
                )

                for _ in range(50):
                    if parent_runtime.has_active_team_session(
                        team_name="review-team",
                        name="worker-1",
                    ):
                        break
                    await asyncio.sleep(0.01)

                leader_inbox = Inbox(team_name="review-team", agent_name="captain")
                idle_messages: list[dict] = []
                for _ in range(50):
                    idle_messages = leader_inbox.read_all()
                    if idle_messages:
                        break
                    await asyncio.sleep(0.01)
                Inbox(team_name="review-team", agent_name="worker-1").append_message(
                    from_agent="captain",
                    message_type="shutdown_request",
                    content="stop",
                )

                for _ in range(50):
                    if not parent_runtime.has_active_team_session(
                        team_name="review-team",
                        name="worker-1",
                    ):
                        break
                    await asyncio.sleep(0.01)

                all_messages = leader_inbox.read_all()

        self.assertIn("started working", result)
        self.assertTrue(idle_messages)
        idle_payloads = [json.loads(message["text"]) for message in idle_messages]
        self.assertTrue(
            any(payload["type"] == "idle_notification" for payload in idle_payloads)
        )
        self.assertFalse(
            parent_runtime.has_active_team_session(
                team_name="review-team",
                name="worker-1",
            )
        )
        all_payloads = [json.loads(message["text"]) for message in all_messages]
        self.assertTrue(
            any(payload["type"] == "shutdown_response" for payload in all_payloads)
        )

    async def test_team_session_parent_callback_emits_shutdown_response_once(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            with patch.dict("os.environ", {"COMATE_TEAMS_DIR": td, "COMATE_TASK_STORE_DIR": td, "HOME": td}):
                agent = Agent(
                    llm=_FakeChatModel(),  # type: ignore[arg-type]
                    config=AgentConfig(
                        tools=(),
                        agents=(),
                        offload_enabled=False,
                        setting_sources=None,
                        cwd=Path(td),
                    ),
                )
                parent_runtime = agent.create_runtime(
                    name="captain",
                    team_name="review-team",
                )
                TeamConfig(team_name="review-team").register_member(
                    name="captain",
                    agent_type="leader",
                )
                session = ChatSession(agent, runtime=parent_runtime, cwd=Path(td))
                callback_events: list[tuple[str, str, str, str]] = []

                def _record_team_message(event) -> None:  # type: ignore[no-untyped-def]
                    callback_events.append(
                        (
                            str(event.agent_name),
                            str(event.from_agent),
                            str(event.message_type),
                            str(event.timestamp),
                        )
                    )

                session._agent._team.team_message_event_callback = _record_team_message

                async def _consume_events() -> None:
                    async for _ in session.events():
                        await asyncio.sleep(0)

                consumer = asyncio.create_task(_consume_events())
                try:
                    task_tool = create_agent_tool(
                        agents=[
                            AgentDefinition(
                                name="worker",
                                description="test worker",
                                prompt="You are a worker.",
                                tools=[],
                            )
                        ],
                        parent_tools=[],
                        tool_registry=ToolRegistry(),
                        parent_cwd=Path(td),
                        parent_llm=_FakeChatModel(content="parent"),  # type: ignore[arg-type]
                        parent_runtime=parent_runtime,
                    )

                    await task_tool.execute(
                        subagent_type="worker",
                        prompt="run task",
                        team_name="review-team",
                        name="worker-1",
                    )
                    await asyncio.sleep(0.3)

                    Inbox(team_name="review-team", agent_name="worker-1").append_message(
                        from_agent="captain",
                        message_type="shutdown_request",
                        content="stop",
                    )

                    for _ in range(100):
                        shutdown_events = [
                            item for item in callback_events if item[2] == "shutdown_response"
                        ]
                        if len(shutdown_events) >= 1 and not parent_runtime.has_active_team_session(
                            team_name="review-team",
                            name="worker-1",
                        ):
                            break
                        await asyncio.sleep(0.02)

                    leader_payloads = [
                        json.loads(message["text"])
                        for message in Inbox(
                            team_name="review-team",
                            agent_name="captain",
                        ).read_all()
                    ]
                finally:
                    consumer.cancel()
                    with contextlib.suppress(asyncio.CancelledError):
                        await consumer
                    await session.shutdown()

        shutdown_callback_events = [
            item for item in callback_events if item[2] == "shutdown_response"
        ]
        self.assertEqual(len(shutdown_callback_events), 1)
        shutdown_payloads = [
            payload for payload in leader_payloads if payload["type"] == "shutdown_response"
        ]
        self.assertEqual(len(shutdown_payloads), 1)
        self.assertEqual(shutdown_callback_events[0][0], "captain")
        self.assertEqual(shutdown_callback_events[0][1], "worker-1")

    async def test_team_session_worktree_cleanup_without_changes_on_shutdown(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            _init_git_repo(root)
            with patch.dict("os.environ", {"COMATE_TEAMS_DIR": td, "COMATE_TASK_STORE_DIR": td, "HOME": td}):
                parent_runtime = Agent(
                    llm=_FakeChatModel(),  # type: ignore[arg-type]
                    config=AgentConfig(
                        tools=(),
                        agents=(),
                        offload_enabled=False,
                        setting_sources=None,
                        cwd=root,
                    ),
                ).create_runtime(
                    name="captain",
                    team_name="review-team",
                )
                TeamConfig(team_name="review-team").register_member(
                    name="captain",
                    agent_type="leader",
                )

                task_tool = create_agent_tool(
                    agents=[
                        AgentDefinition(
                            name="worker",
                            description="test worker",
                            prompt="You are a worker.",
                            tools=[],
                        )
                    ],
                    parent_tools=[],
                    tool_registry=ToolRegistry(),
                    parent_cwd=root,
                    parent_llm=_FakeChatModel(content="parent"),  # type: ignore[arg-type]
                    parent_runtime=parent_runtime,
                )

                result = await task_tool.execute(
                    subagent_type="worker",
                    prompt="run task",
                    team_name="review-team",
                    name="worker-1",
                    isolation="worktree",
                )

                for _ in range(50):
                    if parent_runtime.has_active_team_session(
                        team_name="review-team",
                        name="worker-1",
                    ):
                        break
                    await asyncio.sleep(0.01)

                worktree_dirs = _list_worktree_dirs(root)
                self.assertEqual(len(worktree_dirs), 1)
                Inbox(team_name="review-team", agent_name="worker-1").append_message(
                    from_agent="captain",
                    message_type="shutdown_request",
                    content="stop",
                )

                for _ in range(100):
                    if not parent_runtime.has_active_team_session(
                        team_name="review-team",
                        name="worker-1",
                    ):
                        break
                    await asyncio.sleep(0.01)

                remaining_worktrees = _list_worktree_dirs(root)
                branch_output = subprocess.run(
                    ["git", "branch", "--list"],
                    cwd=root,
                    check=True,
                    capture_output=True,
                    text=True,
                ).stdout

        self.assertIn("started working", result)
        self.assertFalse(remaining_worktrees)
        self.assertNotIn("worktree/subagent-", branch_output)

    async def test_team_session_worktree_preserves_changes_and_reports_path_on_shutdown(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            _init_git_repo(root)
            with patch.dict("os.environ", {"COMATE_TEAMS_DIR": td, "COMATE_TASK_STORE_DIR": td, "HOME": td}):
                parent_runtime = Agent(
                    llm=_FakeChatModel(),  # type: ignore[arg-type]
                    config=AgentConfig(
                        tools=(),
                        agents=(),
                        offload_enabled=False,
                        setting_sources=None,
                        cwd=root,
                    ),
                ).create_runtime(
                    name="captain",
                    team_name="review-team",
                )
                TeamConfig(team_name="review-team").register_member(
                    name="captain",
                    agent_type="leader",
                )

                task_tool = create_agent_tool(
                    agents=[
                        AgentDefinition(
                            name="worker",
                            description="test worker",
                            prompt="You are a worker.",
                            tools=[],
                        )
                    ],
                    parent_tools=[],
                    tool_registry=ToolRegistry(),
                    parent_cwd=root,
                    parent_llm=_FakeChatModel(content="parent"),  # type: ignore[arg-type]
                    parent_runtime=parent_runtime,
                )

                leader_inbox = Inbox(team_name="review-team", agent_name="captain")
                result = await task_tool.execute(
                    subagent_type="worker",
                    prompt="run task",
                    team_name="review-team",
                    name="worker-1",
                    isolation="worktree",
                )

                for _ in range(50):
                    worktree_dirs = _list_worktree_dirs(root)
                    if worktree_dirs:
                        break
                    await asyncio.sleep(0.01)
                self.assertEqual(len(worktree_dirs), 1)
                worktree_dir = worktree_dirs[0]
                (worktree_dir / "README.md").write_text("changed\n", encoding="utf-8")

                Inbox(team_name="review-team", agent_name="worker-1").append_message(
                    from_agent="captain",
                    message_type="shutdown_request",
                    content="stop",
                )

                for _ in range(100):
                    if not parent_runtime.has_active_team_session(
                        team_name="review-team",
                        name="worker-1",
                    ):
                        break
                    await asyncio.sleep(0.01)

                leader_messages = leader_inbox.read_all()
                preserved_worktree_exists = worktree_dir.exists()
                branch_output = subprocess.run(
                    ["git", "branch", "--list"],
                    cwd=root,
                    check=True,
                    capture_output=True,
                    text=True,
                ).stdout

        self.assertIn("started working", result)
        self.assertTrue(preserved_worktree_exists)
        self.assertIn("worktree/subagent-", branch_output)
        shutdown_payloads = [json.loads(message["text"]) for message in leader_messages]
        shutdown_responses = [
            payload
            for payload in shutdown_payloads
            if payload["type"] == "shutdown_response"
        ]
        self.assertTrue(shutdown_responses)
        self.assertIn("worktree_path:", shutdown_responses[-1]["content"])
        self.assertIn(str(worktree_dir), shutdown_responses[-1]["content"])
