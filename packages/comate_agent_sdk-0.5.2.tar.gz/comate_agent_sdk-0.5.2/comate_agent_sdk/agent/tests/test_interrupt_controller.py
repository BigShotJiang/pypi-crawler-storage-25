import asyncio
import gc
import unittest
import weakref

from comate_agent_sdk.agent.interrupt import (
    SessionRunController,
    bridge_to_event,
    create_combined_controller,
)


class TestSessionRunControllerInterruptCallbacks(unittest.TestCase):
    def test_interrupt_invokes_registered_callbacks_with_reason_and_count(self) -> None:
        controller = SessionRunController()
        observed: list[tuple[str, int]] = []

        controller.register_interrupt_callback(
            lambda reason, count: observed.append((reason, count))
        )

        controller.interrupt("user")
        controller.interrupt("user_force")

        self.assertEqual(observed, [("user", 1), ("user_force", 2)])

    def test_unregister_interrupt_callback_stops_future_notifications(self) -> None:
        controller = SessionRunController()
        observed: list[tuple[str, int]] = []

        unregister = controller.register_interrupt_callback(
            lambda reason, count: observed.append((reason, count))
        )
        controller.interrupt("user")
        unregister()
        controller.interrupt("user_force")

        self.assertEqual(observed, [("user", 1)])


class TestSessionRunControllerCreateChild:

    def test_create_child_propagates_interrupt(self) -> None:
        parent = SessionRunController()
        child = parent.create_child()
        parent.interrupt("user")
        assert child.is_interrupted
        assert child.reason == "user"

    def test_create_child_isolation_child_does_not_affect_parent(self) -> None:
        parent = SessionRunController()
        child = parent.create_child()
        child.interrupt("child_reason")
        assert not parent.is_interrupted

    def test_create_child_fast_path_parent_already_interrupted(self) -> None:
        parent = SessionRunController()
        parent.interrupt("early")
        child = parent.create_child()
        assert child.is_interrupted
        assert child.reason == "early"

    def test_dispose_breaks_parent_link(self) -> None:
        parent = SessionRunController()
        child = parent.create_child()
        child.dispose()
        parent.interrupt("after_dispose")
        assert not child.is_interrupted

    def test_weakref_gc_parent_callback_is_noop(self) -> None:
        parent = SessionRunController()
        child = parent.create_child()
        child_ref = weakref.ref(child)
        del child
        gc.collect()
        assert child_ref() is None
        # Should not raise
        parent.interrupt("after_gc")
        assert parent.is_interrupted


class TestBridgeToEvent:

    def test_bridge_sets_event_on_interrupt(self) -> None:
        controller = SessionRunController()
        event, cleanup = bridge_to_event(controller)
        try:
            assert not event.is_set()
            controller.interrupt("user")
            assert event.is_set()
        finally:
            cleanup()

    def test_bridge_fast_path_already_interrupted(self) -> None:
        controller = SessionRunController()
        controller.interrupt("early")
        event, cleanup = bridge_to_event(controller)
        try:
            assert event.is_set()
        finally:
            cleanup()

    def test_bridge_cleanup_unregisters(self) -> None:
        controller = SessionRunController()
        event, cleanup = bridge_to_event(controller)
        cleanup()
        controller.interrupt("after_cleanup")
        assert not event.is_set()


class TestCreateCombinedController:

    def test_any_source_interrupt_propagates(self) -> None:
        src_a = SessionRunController()
        src_b = SessionRunController()
        combined, cleanup = create_combined_controller(src_a, src_b)
        try:
            src_b.interrupt("from_b")
            assert combined.is_interrupted
            assert combined.reason == "from_b"
        finally:
            cleanup()

    def test_timeout_triggers_interrupt(self) -> None:
        async def _run() -> None:
            src = SessionRunController()
            combined, cleanup = create_combined_controller(src, timeout_s=0.05)
            try:
                assert not combined.is_interrupted
                await asyncio.sleep(0.1)
                assert combined.is_interrupted
                assert combined.reason == "timeout"
            finally:
                cleanup()

        asyncio.run(_run())

    def test_cleanup_stops_propagation(self) -> None:
        src = SessionRunController()
        combined, cleanup = create_combined_controller(src)
        cleanup()
        src.interrupt("after_cleanup")
        assert not combined.is_interrupted

    def test_cleanup_cancels_timer(self) -> None:
        async def _run() -> None:
            src = SessionRunController()
            combined, cleanup = create_combined_controller(src, timeout_s=0.05)
            cleanup()  # Cancel timer before it fires
            await asyncio.sleep(0.1)
            assert not combined.is_interrupted

        asyncio.run(_run())

    def test_fast_path_source_already_interrupted(self) -> None:
        src = SessionRunController()
        src.interrupt("early")
        combined, cleanup = create_combined_controller(src)
        try:
            assert combined.is_interrupted
            assert combined.reason == "early"
        finally:
            cleanup()


if __name__ == "__main__":
    unittest.main()
