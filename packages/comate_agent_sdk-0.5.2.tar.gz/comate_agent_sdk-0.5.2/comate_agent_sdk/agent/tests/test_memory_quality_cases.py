from __future__ import annotations

from pathlib import Path

from comate_agent_sdk.agent.memory_extract import render_memory_extraction_prompt
from comate_agent_sdk.agent.system_prompt import resolve_memory_usage_prompt


def test_memory_usage_prompt_marks_topic_files_as_canonical_memory() -> None:
    prompt = resolve_memory_usage_prompt("/tmp/project-memory")

    assert "Topic files in this directory are the canonical memory records." in prompt
    assert "The `description` field is critical" in prompt
    assert "Background extraction only creates or updates topic files." in prompt


def test_memory_extraction_prompt_includes_quality_guardrails() -> None:
    prompt = render_memory_extraction_prompt(
        memory_dir=Path("/tmp/project-memory"),
        conversation_slice="USER: The user prefers terse responses.\nASSISTANT: Acknowledged.",
        existing_memories="- [feedback] feedback_style.md (2026-04-14T00:00:00Z): user prefers terse responses",
    )

    assert "Update an existing topic file instead of creating a duplicate." in prompt
    assert "External system locations belong in `reference` memory." in prompt
    assert "Do not save code structure, file paths, or architecture snapshots." in prompt
    assert "If the slice is vague or low-value, do not write any memory." in prompt
