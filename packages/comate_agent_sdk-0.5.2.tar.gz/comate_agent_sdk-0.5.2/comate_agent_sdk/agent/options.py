from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from types import MappingProxyType
from typing import Any, Literal, Mapping

from comate_agent_sdk.agent.compaction import CompactionConfig
from comate_agent_sdk.agent.llm_levels import LLMLevel
from comate_agent_sdk.agent.system_prompt import SystemPromptType
from comate_agent_sdk.context.env import EnvOptions
from comate_agent_sdk.context.offload import OffloadPolicy
from comate_agent_sdk.llm.base import BaseChatModel, ToolChoice
from comate_agent_sdk.tools.decorator import Tool
from comate_agent_sdk.utils.paths import PathInput


def _freeze_value(value: Any) -> Any:
    if isinstance(value, Mapping):
        return MappingProxyType({k: _freeze_value(v) for k, v in value.items()})
    if isinstance(value, list):
        return tuple(_freeze_value(v) for v in value)
    if isinstance(value, tuple):
        return tuple(_freeze_value(v) for v in value)
    if isinstance(value, set):
        return frozenset(_freeze_value(v) for v in value)
    if isinstance(value, frozenset):
        return frozenset(_freeze_value(v) for v in value)
    return value


@dataclass(frozen=True, slots=True)
class AgentConfig:
    """不可变 Agent 配置（Template 层）。"""

    # LLM/tool/system prompt
    tools: tuple[Tool | str, ...] | None = None
    system_prompt: SystemPromptType = None
    max_iterations: int = 200
    tool_choice: ToolChoice = "auto"
    compaction: CompactionConfig | None = None
    include_cost: bool = False
    emit_compaction_meta_events: bool = False
    dependency_overrides: Mapping[str, Any] | None = None

    # Ephemeral
    ephemeral_keep_recent: int | None = None

    # Context FileSystem / offload
    offload_enabled: bool = True
    offload_token_threshold: int = 2000
    offload_policy: OffloadPolicy | None = None

    # LLM retries
    llm_max_retries: int = 5
    llm_retry_base_delay: float = 1.0
    llm_retry_max_delay: float = 60.0
    llm_retryable_status_codes: frozenset[int] = field(
        default_factory=lambda: frozenset({429, 500, 502, 503, 504})
    )

    # Subagent
    agents: tuple[Any, ...] | None = None  # tuple[AgentDefinition, ...]
    cwd: PathInput = field(default_factory=lambda: Path.cwd().expanduser().resolve())

    # Agent (subagent) 并行执行配置
    task_parallel_enabled: bool = True
    task_parallel_max_concurrency: int = 4
    use_streaming_task: bool = False
    """是否使用流式 Agent（发射 SubagentToolCallEvent 等子事件，用于实时 UI 显示）"""

    # Skills / user instruction
    skills: tuple[Any, ...] | None = None  # tuple[SkillDefinition, ...]
    user_instruction: object | None = None  # UserInstructionConfig

    # Settings / env
    setting_sources: tuple[Literal["user", "project", "local"], ...] | None = (
        "user",
        "project",
        "local",
    )
    permission_mode: str = "default"
    tool_approval_callback: Any | None = None
    env_options: EnvOptions | None = None
    env: Mapping[str, str] | None = None
    memory_background_enabled: bool | None = None
    add_dirs: tuple[Path, ...] | None = None
    disallowed_tools: tuple[str, ...] | None = None
    output_format: Mapping[str, Any] | None = None
    structured_output_max_retries: int = 3

    # MCP
    mcp_enabled: bool = True
    mcp_servers: Any = None

    # LLM levels + session
    llm_levels: Mapping[LLMLevel, BaseChatModel | str] | None = None
    session_id: str | None = None
    task_namespace: str | None = None
    role: str | None = None
    permission_rules_allow: tuple[str, ...] | None = None
    permission_rules_deny: tuple[str, ...] | None = None

    def __post_init__(self) -> None:
        from comate_agent_sdk.agent.session_store import normalize_cwd

        object.__setattr__(self, "tools", _freeze_value(self.tools))
        object.__setattr__(self, "dependency_overrides", _freeze_value(self.dependency_overrides))
        object.__setattr__(self, "llm_retryable_status_codes", frozenset(self.llm_retryable_status_codes))
        object.__setattr__(self, "agents", _freeze_value(self.agents))
        object.__setattr__(self, "skills", _freeze_value(self.skills))
        object.__setattr__(self, "mcp_servers", _freeze_value(self.mcp_servers))
        object.__setattr__(self, "llm_levels", _freeze_value(self.llm_levels))
        object.__setattr__(self, "permission_rules_allow", _freeze_value(self.permission_rules_allow))
        object.__setattr__(self, "permission_rules_deny", _freeze_value(self.permission_rules_deny))
        object.__setattr__(self, "env", _freeze_value(self.env))
        object.__setattr__(self, "disallowed_tools", _freeze_value(self.disallowed_tools))
        object.__setattr__(self, "output_format", _freeze_value(self.output_format))
        if self.add_dirs is not None:
            object.__setattr__(
                self,
                "add_dirs",
                tuple(Path(p).expanduser().resolve() for p in self.add_dirs),
            )
        object.__setattr__(self, "cwd", normalize_cwd(self.cwd))


@dataclass
class RuntimeState:
    """运行时解析输入 + 可变状态。"""

    tools: list[Tool | str] | None = None
    tool_registry: object | None = None
    agents: list | None = None
    skills: list | None = None
    user_instruction: object | None = None
    llm_levels: dict[LLMLevel, BaseChatModel] | None = None
    cwd: Path | None = None
    session_id: str | None = None
    task_namespace: str | None = None
    team_name: str = ""
    plan_mode_prompt_template: str | None = None
    permission_rules_allow: list[str] | None = None
    permission_rules_deny: list[str] | None = None
    offload_policy: OffloadPolicy | None = None
    tool_approval_callback: Any | None = None
    settings_env: dict[str, str] | None = None


def _thaw_mapping(value: Mapping[str, Any] | None) -> dict[str, Any] | None:
    if value is None:
        return None
    return {k: v for k, v in value.items()}


def build_runtime_state(
    *,
    config: AgentConfig,
    resolved_agents: tuple[Any, ...] | None,
    resolved_skills: tuple[Any, ...] | None,
    resolved_user_instruction: object | None,
    resolved_llm_levels: Mapping[LLMLevel, BaseChatModel] | None,
    cwd: PathInput | None,
    session_id: str | None,
    task_namespace: str | None,
    team_name: str = "",
    resolved_settings: object | None = None,
) -> RuntimeState:
    from comate_agent_sdk.agent.session_store import normalize_cwd

    settings_allow: list[str] | None = None
    settings_deny: list[str] | None = None
    settings_env: dict[str, str] | None = None
    if resolved_settings is not None:
        settings_allow = list(getattr(resolved_settings, "permissions_allow", None) or []) or None
        settings_deny = list(getattr(resolved_settings, "permissions_deny", None) or []) or None
        settings_env = dict(getattr(resolved_settings, "env", None) or {}) or None

    resolved_cwd = normalize_cwd(cwd if cwd is not None else config.cwd)

    return RuntimeState(
        tools=list(config.tools) if config.tools is not None else None,
        offload_policy=config.offload_policy,
        agents=list(resolved_agents) if resolved_agents is not None else None,
        tool_registry=None,
        cwd=resolved_cwd,
        skills=list(resolved_skills) if resolved_skills is not None else None,
        user_instruction=resolved_user_instruction,
        llm_levels=dict(resolved_llm_levels) if resolved_llm_levels is not None else None,
        session_id=session_id,
        task_namespace=task_namespace,
        team_name=team_name,
        permission_rules_allow=(
            list(config.permission_rules_allow)
            if config.permission_rules_allow is not None
            else settings_allow
        ),
        permission_rules_deny=(
            list(config.permission_rules_deny)
            if config.permission_rules_deny is not None
            else settings_deny
        ),
        settings_env=settings_env,
    )

