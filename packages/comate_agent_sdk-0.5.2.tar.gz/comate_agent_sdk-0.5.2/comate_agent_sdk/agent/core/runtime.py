from __future__ import annotations

import asyncio
import logging
from collections.abc import AsyncIterator
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Literal

logger = logging.getLogger(__name__)

from comate_agent_sdk.agent.compaction import CompactionService
from comate_agent_sdk.agent.llm_levels import LLMLevel
from comate_agent_sdk.agent.options import AgentConfig, RuntimeState
from comate_agent_sdk.agent.plan_artifact import build_plan_artifact_path
from comate_agent_sdk.context import ContextIR
from comate_agent_sdk.context.fs import ContextFileSystem
from comate_agent_sdk.context.usage_tracker import ContextUsageTracker
from comate_agent_sdk.llm.base import BaseChatModel
from comate_agent_sdk.llm.messages import ContentPartImageParam, ContentPartTextParam
from comate_agent_sdk.system_tools.team.polling import resolve_team_poll_interval_seconds
from comate_agent_sdk.tokens import TokenCost
from comate_agent_sdk.tools.decorator import Tool

from . import runtime_context, runtime_hooks, runtime_mcp, team_state as _team_ops
from .team_state import TeamCoordinationState


@dataclass
class AgentRuntime:
    """运行态 Agent（会话/任务独占，可变）。"""

    llm: BaseChatModel | None = None
    level: LLMLevel | None = None
    config: AgentConfig = field(default_factory=AgentConfig)
    _runtime_state: RuntimeState = field(default_factory=RuntimeState, repr=False)
    name: str | None = None
    template: "AgentTemplate | None" = field(default=None, repr=False)
    header_snapshot: dict[str, Any] | None = field(default=None, repr=False)
    _is_subagent: bool = field(default=False, repr=False)
    _parent_token_cost: TokenCost | None = field(default=None, repr=False)
    _subagent_run_id: str | None = field(default=None, repr=False)
    _subagent_source_prefix: str | None = field(default=None, repr=False, init=False)
    _shared_auto_memory_dir: Path | None = field(default=None, repr=False, init=False)

    _context: ContextIR = field(default=None, repr=False, init=False)  # type: ignore[assignment]
    _task_store: Any | None = field(default=None, repr=False, init=False)
    _tool_map: dict[str, Tool] = field(default_factory=dict, repr=False, init=False)
    _compaction_service: CompactionService | None = field(default=None, repr=False, init=False)
    _token_cost: TokenCost = field(default=None, repr=False, init=False)  # type: ignore[assignment]
    _context_usage_tracker: ContextUsageTracker = field(default=None, repr=False, init=False)  # type: ignore[assignment]
    _context_fs: ContextFileSystem | None = field(default=None, repr=False, init=False)
    _session_id_value: str = field(default="", repr=False, init=False)
    _team: TeamCoordinationState = field(default_factory=TeamCoordinationState, repr=False, init=False)
    _run_controller: "SessionRunController | None" = field(default=None, repr=False, init=False)
    _hook_engine: Any | None = field(default=None, repr=False, init=False)
    _pending_hidden_user_messages: list[str] = field(default_factory=list, repr=False, init=False)
    _hooks_session_started: bool = field(default=False, repr=False, init=False)
    _hooks_session_ended: bool = field(default=False, repr=False, init=False)
    _stop_hook_block_count: int = field(default=0, repr=False, init=False)
    _stop_hook_block_limit: int = field(default=3, repr=False, init=False)

    _mcp_manager: Any | None = field(default=None, repr=False, init=False)
    _mcp_loaded: bool = field(default=False, repr=False, init=False)
    _mcp_dirty: bool = field(default=False, repr=False, init=False)
    _mcp_generation: int = field(default=0, repr=False, init=False)
    _mcp_pending_tool_names: list[str] = field(default_factory=list, repr=False, init=False)
    _mcp_preload_task: asyncio.Task[None] | None = field(default=None, repr=False, init=False)
    _mcp_load_lock: asyncio.Lock = field(default_factory=asyncio.Lock, repr=False, init=False)
    _mcp_tools_hash: str = field(default="", repr=False, init=False)
    _lock_header_from_snapshot: bool = field(default=False, repr=False, init=False)
    _tools_allowlist_mode: bool = field(default=False, repr=False, init=False)
    _requested_tool_names: list[str] = field(default_factory=list, repr=False, init=False)
    _mode: Literal["act", "plan"] = field(default="act", repr=False, init=False)
    _active_mode_snapshot: Literal["act", "plan"] | None = field(default=None, repr=False, init=False)
    _pending_plan_approval: dict[str, str] | None = field(default=None, repr=False, init=False)
    _active_plan_path: str | None = field(default=None, repr=False, init=False)
    _memory_extraction_state: Any | None = field(default=None, repr=False, init=False)
    _memory_extraction_enabled: bool = field(default=True, repr=False, init=False)
    _relevant_memory_prefetch_enabled: bool = field(default=True, repr=False, init=False)

    def __post_init__(self) -> None:
        if not isinstance(self.config, AgentConfig):
            raise TypeError(
                f"config 必须是 AgentConfig，收到：{type(self.config).__name__}"
            )
        if not isinstance(self._runtime_state, RuntimeState):
            raise TypeError(
                f"_runtime_state 必须是 RuntimeState，收到：{type(self._runtime_state).__name__}"
            )

        from comate_agent_sdk.agent.init import init_runtime_from_template

        init_runtime_from_template(self)
        self._team.poll_interval_seconds = resolve_team_poll_interval_seconds()

    @property
    def _task_namespace(self) -> str:
        return str(self._runtime_state.task_namespace or "")

    @_task_namespace.setter
    def _task_namespace(self, value: str) -> None:
        self._runtime_state.task_namespace = str(value or "").strip()

    @property
    def _session_id(self) -> str:
        return self._session_id_value

    @_session_id.setter
    def _session_id(self, value: str) -> None:
        normalized = str(value or "").strip()
        self._session_id_value = normalized
        self._runtime_state.session_id = normalized or None

    @property
    def _team_name(self) -> str:
        return str(self._team.team_name or "")

    @_team_name.setter
    def _team_name(self, value: str) -> None:
        self._team.team_name = str(value or "").strip()
        self._runtime_state.team_name = self._team.team_name

    @property
    def tool_definitions(self):
        return runtime_context.get_tool_definitions(self)

    @property
    def messages(self):
        return runtime_context.get_messages(self)

    @property
    def token_cost(self) -> TokenCost:
        return runtime_context.get_token_cost(self)

    @property
    def _effective_level(self) -> LLMLevel | None:
        return runtime_context.get_effective_level(self)

    async def get_usage(
        self,
        *,
        model: str | None = None,
        source_prefix: str | None = None,
    ):
        return await runtime_context.get_usage(
            self,
            model=model,
            source_prefix=source_prefix,
        )

    async def get_context_info(self):
        return await runtime_context.get_context_info(self)

    def add_hidden_user_message(self, content: str) -> None:
        runtime_context.add_hidden_user_message(self, content)

    def add_hidden_system_reminder(
        self,
        content: str,
        *,
        metadata: dict[str, Any] | None = None,
    ) -> None:
        runtime_context.add_hidden_system_reminder(self, content, metadata=metadata)

    def add_hook_hidden_user_message(
        self,
        content: str,
        *,
        hook_name: str | None = None,
        related_tool_call_id: str | None = None,
    ) -> None:
        runtime_context.add_hook_hidden_user_message(
            self,
            content,
            hook_name=hook_name,
            related_tool_call_id=related_tool_call_id,
        )

    def drain_hidden_user_messages(self) -> list[str]:
        return runtime_context.drain_hidden_user_messages(self)

    def _resolve_system_prompt(self) -> str:
        return runtime_context.resolve_system_prompt_text(self)

    def _resolve_memory_usage_prompt(self) -> str:
        return runtime_context.resolve_memory_usage_prompt_text(self)

    def clear_history(self):
        runtime_context.clear_history(self)

    def load_history(self, messages) -> None:
        runtime_context.load_history(self, messages)

    def set_plan_mode(self, enabled: bool) -> None:
        runtime_context.set_plan_mode(self, enabled)

    def build_hook_input(self, event_name: str, **kwargs: Any):
        return runtime_hooks.build_hook_input(self, event_name, **kwargs)

    async def run_hook_event(self, event_name: str, **kwargs: Any):
        return await runtime_hooks.run_hook_event(self, event_name, **kwargs)

    def register_python_hook(
        self,
        *,
        event_name: str,
        callback: Any,
        matcher: str = "*",
        order: int = 0,
        name: str | None = None,
    ) -> None:
        runtime_hooks.register_python_hook(
            self,
            event_name=event_name,
            callback=callback,
            matcher=matcher,
            order=order,
            name=name,
        )

    def reset_stop_hook_state(self) -> None:
        runtime_hooks.reset_stop_hook_state(self)

    def mark_stop_blocked_once(self) -> bool:
        return runtime_hooks.mark_stop_blocked_once(self)

    def invalidate_mcp_tools(self, *, reason: str = "") -> None:
        runtime_mcp.invalidate_mcp_tools(self, reason=reason)

    def start_mcp_preload(
        self,
        *,
        force: bool = False,
    ) -> asyncio.Task[None] | None:
        return runtime_mcp.start_mcp_preload(self, force=force)

    async def ensure_mcp_tools_loaded(self, *, force: bool = False) -> None:
        await runtime_mcp.ensure_mcp_tools_loaded(self, force=force)

    async def _await_existing_mcp_preload(self, *, force: bool) -> None:
        await runtime_mcp.await_existing_mcp_preload(self, force=force)

    async def _load_mcp_tools(self, *, force: bool = False) -> None:
        await runtime_mcp.load_mcp_tools(self, force=force)

    def _remove_mcp_tools_from_agent(self) -> None:
        runtime_mcp.remove_mcp_tools_from_agent(self)

    def _apply_mcp_tools_to_agent(self, mcp_tools: list[Tool]) -> None:
        runtime_mcp.apply_mcp_tools_to_agent(self, mcp_tools)

    async def retry_mcp_server(self, alias: str) -> bool:
        """Retry a failed MCP server connection."""
        return await runtime_mcp.retry_mcp_server(self, alias)

    async def aclose(self) -> None:
        """Gracefully close runtime-owned resources.

        Keep this method idempotent so callers can safely invoke it during
        nested/duplicated shutdown paths.
        """
        memory_extraction_state = getattr(self, "_memory_extraction_state", None)
        memory_extraction_task = getattr(memory_extraction_state, "active_task", None)
        if memory_extraction_task is not None:
            memory_extraction_state.pending_request = None
            memory_extraction_task.cancel()
            await asyncio.gather(memory_extraction_task, return_exceptions=True)

        await self._team.cancel_all_sessions()

        await self._stop_inbox_poll_task_async()

        preload_task = self._mcp_preload_task
        self._mcp_preload_task = None
        if preload_task is not None:
            preload_task.cancel()
            await asyncio.gather(preload_task, return_exceptions=True)

        async with self._mcp_load_lock:
            manager = self._mcp_manager
            if manager is not None:
                try:
                    await manager.aclose()
                except Exception as exc:
                    logger.warning(f"关闭 MCP manager 失败（忽略）：{exc}", exc_info=True)
                finally:
                    self._mcp_manager = None

            self._remove_mcp_tools_from_agent()
            self._mcp_loaded = False
            self._mcp_dirty = False
            self._mcp_pending_tool_names = []

    def _should_poll_team_inbox(self) -> bool:
        return _team_ops.resolve_team_inbox_delivery_mode(self) == "external_turn"

    def _can_legacy_poll_team_inbox(self) -> bool:
        return _team_ops.resolve_team_inbox_delivery_mode(self) == "legacy_buffer"

    def _resolve_team_inbox_delivery_mode(self) -> Literal["disabled", "external_turn", "legacy_buffer"]:
        return _team_ops.resolve_team_inbox_delivery_mode(self)

    async def _poll_team_inbox_once(self) -> Literal["event", "idle", "skip"]:
        return await _team_ops.poll_team_inbox_once(self)

    async def _run_inbox_poll_loop(self) -> None:
        await _team_ops.run_inbox_poll_loop(self)

    async def _stop_inbox_poll_task_async(self) -> None:
        await _team_ops.stop_inbox_poll_task_async(self)

    def _stop_inbox_poll_task(self) -> None:
        _team_ops.stop_inbox_poll_task(self)

    def _start_inbox_poll_task(self) -> None:
        _team_ops.start_inbox_poll_task(self)

    def _sync_inbox_poll_task(self) -> None:
        _team_ops.sync_inbox_poll_task(self)

    def drain_pending_inbox_events(self) -> list:
        return self._team.drain_pending_events()

    def ack_pending_inbox_events(self, keys: list[str]) -> None:
        _team_ops.ack_pending_inbox_events(self, keys)

    def discard_team_coordination_backlog(self) -> int:
        """Invalidate team inbox state and drop any queued team turns."""
        return self._team.discard_backlog()

    def has_active_team_session(self, *, team_name: str, name: str) -> bool:
        return self._team.has_active_team_session(team_name=team_name, name=name)

    def register_team_session(self, *, team_name: str, name: str, task: asyncio.Task[None]) -> None:
        self._team.register_team_session(team_name=team_name, name=name, task=task)

    def list_active_team_session_names(self, *, team_name: str) -> list[str]:
        return self._team.list_active_team_session_names(team_name=team_name)

    @property
    def is_team_member(self) -> bool:
        """当前 agent 是否处于 Team 模式（有 team_name）。"""
        return self._team.is_active

    def get_mode(self) -> Literal["act", "plan"]:
        return self._mode

    def set_mode(self, mode: Literal["act", "plan"] | str) -> None:
        normalized = str(mode).strip().lower()
        if normalized not in {"act", "plan"}:
            raise ValueError(f"Unsupported mode: {mode}")
        previous_mode = self._mode
        self._mode = normalized  # type: ignore[assignment]
        if previous_mode != "plan" and self._mode == "plan":
            try:
                self._active_plan_path = str(build_plan_artifact_path())
                logger.debug(f"set_mode: allocated active plan path: {self._active_plan_path}")
            except Exception as exc:
                logger.warning(f"set_mode: failed to allocate active plan path: {exc}", exc_info=True)
                self._active_plan_path = None
        elif self._mode != "plan":
            self._active_plan_path = None
        self._context.set_plan_mode(self._mode == "plan")

    def cycle_mode(self) -> Literal["act", "plan"]:
        next_mode: Literal["act", "plan"] = "plan" if self._mode == "act" else "act"
        self.set_mode(next_mode)
        return next_mode

    def get_active_plan_path(self) -> str | None:
        value = str(self._active_plan_path or "").strip()
        return value or None

    def arm_plan_approval(
        self,
        *,
        plan_path: str,
        summary: str,
        execution_prompt: str,
    ) -> None:
        self._pending_plan_approval = {
            "plan_path": plan_path,
            "summary": summary,
            "execution_prompt": execution_prompt,
        }

    def has_pending_plan_approval(self) -> bool:
        return self._pending_plan_approval is not None

    def pending_plan_approval(self) -> dict[str, str] | None:
        if self._pending_plan_approval is None:
            return None
        return dict(self._pending_plan_approval)

    def approve_plan(self, *, clear_context: bool = False) -> str:
        pending = self._pending_plan_approval
        self._pending_plan_approval = None
        self.set_mode("act")
        if pending is None:
            return "I have approved the plan. Please continue to execute the plan."

        if clear_context:
            self._context.clear_conversation()
            logger.debug("approve_plan: conversation cleared")

        plan_path = str(pending.get("plan_path", "")).strip()
        if plan_path:
            try:
                from pathlib import Path
                from comate_agent_sdk.llm.messages import UserMessage
                plan_markdown = Path(plan_path).read_text(encoding="utf-8").strip()
                if plan_markdown:
                    injection = f"<approved-plan>\n{plan_markdown}\n</approved-plan>"
                    self._context.add_message(UserMessage(content=injection, is_meta=True))
                    logger.debug(f"approve_plan: injected plan from {plan_path}")
            except Exception as exc:
                logger.warning(f"approve_plan: failed to read plan file: {exc}")

        execution_prompt = str(pending.get("execution_prompt", "")).strip()
        return execution_prompt or "I have approved the plan. Please continue to execute the plan."

    def reject_plan(self) -> None:
        self._pending_plan_approval = None
        self.set_mode("plan")

    async def compact_context_manual(self) -> "ManualCompactionResult":
        from comate_agent_sdk.agent.runner_engine import manual_compact_context

        return await manual_compact_context(self)

    async def query(self, message: str) -> str:
        from comate_agent_sdk.agent.runner_engine import run_query

        # 在公开异步入口自动触发 MCP 预热，避免调用方额外记住 prepare/preload。
        self.start_mcp_preload()
        return await run_query(self, message)

    async def query_stream(
        self,
        message: str | list[ContentPartTextParam | ContentPartImageParam],
    ) -> AsyncIterator["AgentEvent"]:
        from comate_agent_sdk.agent.runner_engine import run_query_stream

        # stream 入口同样自动触发 MCP 预热；真实加载仍由 ensure_mcp_tools_loaded() 兜底。
        self.start_mcp_preload()
        async for event in run_query_stream(self, message):
            yield event


from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from comate_agent_sdk.agent.compaction.models import ManualCompactionResult
    from comate_agent_sdk.agent.core.template import AgentTemplate
    from comate_agent_sdk.agent.events import AgentEvent
    from comate_agent_sdk.agent.interrupt import SessionRunController
    from comate_agent_sdk.llm.views import ChatInvokeCompletion
