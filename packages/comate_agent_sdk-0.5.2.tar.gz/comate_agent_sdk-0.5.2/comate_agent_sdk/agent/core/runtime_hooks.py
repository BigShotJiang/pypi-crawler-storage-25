from __future__ import annotations

from typing import TYPE_CHECKING, Any

from comate_agent_sdk.agent.session_store import normalize_cwd

if TYPE_CHECKING:
    from comate_agent_sdk.agent.core.runtime import AgentRuntime
    from comate_agent_sdk.agent.hooks.models import AggregatedHookOutcome, HookInput


def build_hook_input(agent: "AgentRuntime", event_name: str, **kwargs: Any) -> "HookInput":
    from comate_agent_sdk.agent.hooks.models import HookInput

    cwd = str(normalize_cwd(agent._runtime_state.cwd))
    return HookInput(
        session_id=agent._session_id,
        cwd=cwd,
        permission_mode=str(agent.config.permission_mode or "default"),
        hook_event_name=event_name,
        **kwargs,
    )


async def run_hook_event(
    agent: "AgentRuntime",
    event_name: str,
    **kwargs: Any,
) -> "AggregatedHookOutcome | None":
    if agent._hook_engine is None:
        return None
    hook_input = build_hook_input(agent, event_name, **kwargs)
    return await agent._hook_engine.run_event(event_name, hook_input)


def register_python_hook(
    agent: "AgentRuntime",
    *,
    event_name: str,
    callback: Any,
    matcher: str = "*",
    order: int = 0,
    name: str | None = None,
) -> None:
    if agent._hook_engine is None:
        raise ValueError("Hook engine is not initialized")
    agent._hook_engine.register_python_hook(
        event_name=event_name,
        callback=callback,
        matcher=matcher,
        order=order,
        name=name,
    )


def reset_stop_hook_state(agent: "AgentRuntime") -> None:
    agent._stop_hook_block_count = 0


def mark_stop_blocked_once(agent: "AgentRuntime") -> bool:
    agent._stop_hook_block_count += 1
    return agent._stop_hook_block_count <= agent._stop_hook_block_limit
