"""Session query — read-only API for listing sessions and reading messages.

Symmetric to session_store.py (write-side). This module only reads
persisted session data; it never modifies files.
"""

from __future__ import annotations

import json
import logging
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Literal

from comate_agent_sdk.agent.session_store import (
    PERSISTENCE_SCHEMA_VERSION,
    default_session_root,
    default_sessions_dir,
    load_session_metadata,
    replay_session_events,
)
from comate_agent_sdk.context.items import ContextItem, ItemType
from comate_agent_sdk.llm.messages import AssistantMessage
from comate_agent_sdk.utils.paths import normalize_path_input

logger = logging.getLogger(__name__)

_FIRST_PROMPT_MAX_LEN = 200


@dataclass(slots=True)
class SessionInfo:
    """轻量 session 元数据，用于列表展示。"""

    session_id: str
    cwd: str | None
    last_modified: float
    file_size: int
    first_prompt: str | None
    team_name: str | None


@dataclass(slots=True)
class SessionMessage:
    """单条会话消息，面向展示。"""

    id: str
    type: Literal["user", "assistant", "tool_use", "tool_result", "team_message"]
    content: str
    timestamp: float
    tool_name: str | None = None
    is_error: bool = False
    team_from: str | None = None
    team_to: str | None = None
    team_message_type: str | None = None


def list_sessions(
    *,
    cwd: str | Path,
    limit: int | None = None,
) -> list[SessionInfo]:
    """列出指定 cwd 下的所有 session，按 last_modified 降序排列。"""
    cwd_path = normalize_path_input(cwd, field_name="cwd")
    sessions_dir = default_sessions_dir(cwd_path)

    if not sessions_dir.exists():
        return []

    results: list[SessionInfo] = []
    for entry in sessions_dir.iterdir():
        if not entry.is_dir():
            continue

        # 读取 session.json
        meta = load_session_metadata(entry)
        if meta is None:
            continue

        # 检查 context.jsonl 存在
        context_jsonl = entry / "context.jsonl"
        if not context_jsonl.exists():
            continue

        stat = context_jsonl.stat()
        first_prompt = _extract_first_prompt(context_jsonl)

        results.append(SessionInfo(
            session_id=meta["session_id"],
            cwd=meta.get("cwd") or None,
            last_modified=stat.st_mtime,
            file_size=stat.st_size,
            first_prompt=first_prompt,
            team_name=meta.get("team_name") or None,
        ))

    results.sort(key=lambda s: s.last_modified, reverse=True)

    if limit is not None and limit > 0:
        results = results[:limit]

    return results


_TEAM_EVENTS_FILENAME = "team_events.jsonl"

_VISIBLE_ITEM_TYPES = {
    ItemType.USER_MESSAGE,
    ItemType.ASSISTANT_MESSAGE,
    ItemType.TOOL_RESULT,
}


def get_session_messages(
    session_id: str,
    *,
    cwd: str | Path,
    limit: int | None = None,
    offset: int | None = None,
) -> list[SessionMessage]:
    """读取指定 session 的消息（对话 + 团队消息），按时间升序排列。"""
    cwd_path = normalize_path_input(cwd, field_name="cwd")
    session_root = default_session_root(session_id, cwd=cwd_path)

    context_jsonl = session_root / "context.jsonl"
    if not context_jsonl.exists():
        logger.warning("Session %s not found at %s", session_id, session_root)
        return []

    offload_root = session_root / "offload"

    # 1. Replay conversation
    _, items, _ = replay_session_events(
        path=context_jsonl,
        offload_root=offload_root,
    )

    # 2. Map conversation items to SessionMessages
    messages: list[SessionMessage] = []
    for item in items:
        if item.destroyed:
            continue
        if item.item_type not in _VISIBLE_ITEM_TYPES:
            continue
        messages.extend(_item_to_session_messages(item))

    # 3. Load team events
    team_events_path = session_root / _TEAM_EVENTS_FILENAME
    if team_events_path.exists():
        messages.extend(_load_team_events(team_events_path))

    # 4. Sort by timestamp
    messages.sort(key=lambda m: m.timestamp)

    # 5. Apply offset/limit
    if offset is not None and offset > 0:
        messages = messages[offset:]
    if limit is not None and limit > 0:
        messages = messages[:limit]

    return messages


def _item_to_session_messages(item: ContextItem) -> list[SessionMessage]:
    """将单个 ContextItem 映射为一或多条 SessionMessage。"""
    results: list[SessionMessage] = []

    if item.item_type == ItemType.USER_MESSAGE:
        results.append(SessionMessage(
            id=item.id,
            type="user",
            content=item.content_text or "",
            timestamp=item.created_at,
        ))

    elif item.item_type == ItemType.ASSISTANT_MESSAGE:
        msg = item.message
        # 提取文本部分
        text_content = ""
        if isinstance(msg, AssistantMessage):
            text_content = msg.text or ""
        else:
            text_content = item.content_text or ""

        if text_content.strip():
            results.append(SessionMessage(
                id=f"{item.id}-text",
                type="assistant",
                content=text_content,
                timestamp=item.created_at,
            ))

        # 提取 tool_calls
        if isinstance(msg, AssistantMessage) and msg.tool_calls:
            for tc in msg.tool_calls:
                results.append(SessionMessage(
                    id=f"{item.id}-tc-{tc.id}",
                    type="tool_use",
                    content=tc.function.arguments,
                    timestamp=item.created_at,
                    tool_name=tc.function.name,
                ))

    elif item.item_type == ItemType.TOOL_RESULT:
        content = item.content_text or ""
        if item.offloaded:
            content = "[content offloaded]"
        results.append(SessionMessage(
            id=item.id,
            type="tool_result",
            content=content,
            timestamp=item.created_at,
            tool_name=item.tool_name,
            is_error=item.is_tool_error,
        ))

    return results


def _load_team_events(path: Path) -> list[SessionMessage]:
    """从 team_events.jsonl 加载团队通信消息。"""
    results: list[SessionMessage] = []
    try:
        with path.open("r", encoding="utf-8") as f:
            for line in f:
                raw = line.strip()
                if not raw:
                    continue
                try:
                    data = json.loads(raw)
                except Exception:
                    continue

                ts_str = data.get("timestamp", "")
                try:
                    ts = datetime.fromisoformat(ts_str).timestamp()
                except Exception:
                    ts = 0.0

                results.append(SessionMessage(
                    id=data.get("message_id", ""),
                    type="team_message",
                    content=data.get("content", ""),
                    timestamp=ts,
                    team_from=data.get("from_agent"),
                    team_to=data.get("to_agent"),
                    team_message_type=data.get("message_type"),
                ))
    except Exception:
        logger.warning("Failed to load team events from %s", path, exc_info=True)
    return results


_MAX_SCAN_LINES = 50


def _extract_first_prompt(context_jsonl: Path) -> str | None:
    """从 context.jsonl 前几行提取首条用户消息文本（轻量解析）。

    最多扫描前 _MAX_SCAN_LINES 行，避免对大型 session 文件做全量读取。
    """
    try:
        with context_jsonl.open("r", encoding="utf-8") as f:
            for line_no, line in enumerate(f, 1):
                if line_no > _MAX_SCAN_LINES:
                    break
                raw = line.strip()
                if not raw:
                    continue
                try:
                    data = json.loads(raw)
                except Exception:
                    continue

                if data.get("schema_version") != PERSISTENCE_SCHEMA_VERSION:
                    continue

                op = data.get("op")
                if op not in ("conversation_delta", "conversation_reset"):
                    continue

                convo = data.get("conversation") or {}

                # conversation_delta: 查看 adds；conversation_reset: 查看 items
                items = convo.get("adds") or convo.get("items") or []
                for item in items:
                    if item.get("item_type") == "user_message":
                        text = str(item.get("content_text", "")).strip()
                        if text:
                            if len(text) > _FIRST_PROMPT_MAX_LEN:
                                return text[:_FIRST_PROMPT_MAX_LEN] + "..."
                            return text
    except Exception:
        logger.warning(
            "Failed to extract first prompt from %s", context_jsonl,
            exc_info=True,
        )
    return None
