from __future__ import annotations

import asyncio
import logging
import re
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import TYPE_CHECKING

import json_repair
from pydantic import BaseModel, Field

from comate_agent_sdk.agent.memory_store import (
    MAX_SURFACED_MEMORY_BYTES,
    MemoryHeader,
    SurfacedMemoryDocument,
    format_memory_manifest,
    read_memory_document_for_surface,
    scan_memory_headers,
)
from comate_agent_sdk.llm.messages import (
    AssistantMessage,
    ContentPartTextParam,
    UserMessage,
)
from comate_agent_sdk.llm.side_query import SideQueryError, side_query
from comate_agent_sdk.prompts import load_prompt

from comate_agent_sdk.agent.llm_levels import resolve_memory_llm_override_from_env

if TYPE_CHECKING:
    from comate_agent_sdk.agent.core import AgentRuntime
    from comate_agent_sdk.agent.llm_levels import LLMLevel
    from comate_agent_sdk.context.ir import ContextIR
    from comate_agent_sdk.llm.base import BaseChatModel

logger = logging.getLogger("comate_agent_sdk.agent.memory")

MAX_SELECTED_MEMORIES = 5
MAX_SESSION_SURFACED_BYTES = 60_000

# Matches any CJK character (Han, Hiragana/Katakana, Hangul).
_CJK_RE = re.compile(r"[\u4e00-\u9fff\u3400-\u4dbf\u3040-\u30ff\uac00-\ud7a3]")


class _RelevantMemorySelection(BaseModel):
    selected_memories: list[str] = Field(default_factory=list)


@dataclass(slots=True)
class RelevantMemoryPrefetch:
    task: asyncio.Task[list[SurfacedMemoryDocument]]
    consumed: bool = False

    def cancel(self) -> None:
        if not self.task.done():
            self.task.cancel()


def should_prefetch_relevant_memories(
    content: str | list[ContentPartTextParam] | list[object],
) -> bool:
    text = _coerce_turn_text(content)
    if not text:
        return False
    # Single-word prompts lack enough context for meaningful term extraction.
    # For CJK languages (no whitespace between words), fall back to char count.
    if _CJK_RE.search(text):
        return len(text.strip()) >= 4
    return len(text.split()) > 1


def collect_surfaced_relevant_memories(context: "ContextIR") -> tuple[set[str], int]:
    surfaced_paths: set[str] = set()
    total_bytes = 0
    deferred_items_getter = getattr(context, "get_deferred_items_snapshot", None)
    deferred_items = deferred_items_getter() if callable(deferred_items_getter) else []
    for item in [*context.conversation.items, *deferred_items]:
        if item.destroyed:
            continue
        if str((item.metadata or {}).get("origin", "")).strip() != "relevant_memory":
            continue

        for raw_path in item.metadata.get("memory_paths", []) or []:
            normalized = str(raw_path or "").strip()
            if normalized:
                surfaced_paths.add(normalized)
        try:
            total_bytes += int(item.metadata.get("memory_total_bytes", 0) or 0)
        except Exception:
            continue

    return surfaced_paths, total_bytes


def start_relevant_memory_prefetch(
    agent: "AgentRuntime",
    turn_content: str | list[object],
) -> RelevantMemoryPrefetch | None:
    if not bool(getattr(agent, "_relevant_memory_prefetch_enabled", True)):
        return None
    if bool(getattr(agent, "_is_subagent", False)):
        return None
    if agent.llm is None:
        return None
    if not should_prefetch_relevant_memories(turn_content):
        return None

    surfaced_paths, total_bytes = collect_surfaced_relevant_memories(agent._context)
    if total_bytes >= MAX_SESSION_SURFACED_BYTES:
        return None

    query_text = _coerce_turn_text(turn_content)
    if not query_text:
        return None

    task = asyncio.create_task(_prefetch_relevant_memories(agent, query_text, surfaced_paths))
    return RelevantMemoryPrefetch(task=task)


def consume_ready_relevant_memory_prefetch(
    agent: "AgentRuntime",
    prefetch: RelevantMemoryPrefetch | None,
) -> bool:
    if prefetch is None or prefetch.consumed or not prefetch.task.done():
        return False

    prefetch.consumed = True
    try:
        documents = prefetch.task.result()
    except asyncio.CancelledError:
        return False
    except Exception as exc:  # pragma: no cover - defensive log path
        logger.warning(f"Relevant memory prefetch failed: {exc}")
        return False

    if not documents:
        return False

    surfaced_paths, surfaced_total_bytes = collect_surfaced_relevant_memories(agent._context)
    remaining_budget = MAX_SESSION_SURFACED_BYTES - surfaced_total_bytes
    if remaining_budget <= 0:
        return False

    filtered: list[SurfacedMemoryDocument] = []
    consumed_bytes = 0
    for document in documents:
        normalized_path = document.path.as_posix()
        if normalized_path in surfaced_paths:
            continue
        if consumed_bytes + document.byte_count > remaining_budget:
            break
        filtered.append(document)
        consumed_bytes += document.byte_count

    if not filtered:
        return False

    reminder_text = _render_relevant_memory_reminder(filtered)
    item = agent._context.add_deferred_meta_message(
        reminder_text,
        metadata={
            "origin": "relevant_memory",
            "memory_paths": [document.path.as_posix() for document in filtered],
            "memory_total_bytes": consumed_bytes,
        },
    )
    return item is not None


async def _prefetch_relevant_memories(
    agent: "AgentRuntime",
    query_text: str,
    surfaced_paths: set[str],
) -> list[SurfacedMemoryDocument]:
    from comate_agent_sdk.agent.setup import resolve_auto_memory_dir

    memory_dir = resolve_auto_memory_dir(agent)
    headers = [
        header
        for header in scan_memory_headers(memory_dir)
        if header.path.as_posix() not in surfaced_paths
    ]
    if not headers:
        return []

    selector_llm, level = _resolve_memory_selector_llm(agent)
    manifest = format_memory_manifest(headers)
    if not manifest:
        return []
    recent_tools = _collect_recent_tool_names(agent._context)
    tools_section = (
        f"\n\nRecently used tools: {', '.join(recent_tools)}"
        if recent_tools
        else ""
    )

    try:
        response = await side_query(
            selector_llm,
            messages=[
                UserMessage(
                    content=(
                        f"Query:\n{query_text}\n\nAvailable memories:\n{manifest}{tools_section}"
                    )
                )
            ],
            source="side_query:memory_select",
            system=load_prompt("memory/select_relevant.md"),
            token_cost=agent._token_cost,
            level=level,
        )
    except SideQueryError as exc:
        logger.warning(f"Relevant memory side query failed: {exc}")
        return []

    selected_names = _parse_selected_memory_names(response.content or "")
    if not selected_names:
        return []

    selected_headers = _resolve_selected_headers(headers, selected_names)
    return [
        read_memory_document_for_surface(header.path, max_bytes=MAX_SURFACED_MEMORY_BYTES)
        for header in selected_headers
    ]


def _resolve_memory_selector_llm(
    agent: "AgentRuntime",
) -> tuple["BaseChatModel", "LLMLevel | None"]:
    override = resolve_memory_llm_override_from_env(
        settings_env=agent._runtime_state.settings_env,
        config_env=agent.config.env,
    )
    if override is not None:
        llm_levels = getattr(agent._runtime_state, "llm_levels", None)
        if llm_levels and override in llm_levels:
            return llm_levels[override], override
    return agent.llm, getattr(agent, "_effective_level", None)


def _parse_selected_memory_names(content: str) -> list[str]:
    try:
        payload = json_repair.loads(content or "{}")
        parsed = _RelevantMemorySelection.model_validate(payload)
    except Exception:
        return []

    selected: list[str] = []
    for raw_name in parsed.selected_memories[:MAX_SELECTED_MEMORIES]:
        name = str(raw_name or "").strip()
        if name:
            selected.append(name)
    return selected


def _resolve_selected_headers(
    headers: list[MemoryHeader],
    selected_names: list[str],
) -> list[MemoryHeader]:
    by_name = {header.filename: header for header in headers}
    selected_headers: list[MemoryHeader] = []
    for name in selected_names:
        header = by_name.get(name)
        if header is not None:
            selected_headers.append(header)
    return selected_headers[:MAX_SELECTED_MEMORIES]


def _collect_recent_tool_names(context: "ContextIR", *, limit: int = 8) -> list[str]:
    if limit <= 0:
        return []

    recent_tools: list[str] = []
    seen: set[str] = set()
    for item in reversed(context.conversation.items):
        if item.destroyed:
            continue
        message = item.message
        if not isinstance(message, AssistantMessage) or not message.tool_calls:
            continue
        for tool_call in message.tool_calls:
            tool_name = str(tool_call.function.name or "").strip()
            if not tool_name or tool_name in seen:
                continue
            seen.add(tool_name)
            recent_tools.append(tool_name)
            if len(recent_tools) >= limit:
                return recent_tools
    return recent_tools


def _render_relevant_memory_reminder(documents: list[SurfacedMemoryDocument]) -> str:
    sections: list[str] = []
    for document in documents:
        freshness = _memory_freshness_text(document)
        label = f"{_format_memory_label(document)}: {document.path.as_posix()}"
        header = f"{freshness}\n\n{label}" if freshness else label
        sections.append(f"{header}\n\n{document.content.strip()}")

    joined_sections = "\n\n".join(sections)
    return (
        "<system-reminder>\n"
        "Relevant memory surfaced for this turn:\n\n"
        f"{joined_sections}\n"
        "</system-reminder>"
    )


def _memory_age_days(mtime_ms: float) -> int:
    """计算 memory 的天龄。0=today, 1=yesterday, 2+=older。"""
    updated_at = datetime.fromtimestamp(mtime_ms / 1000, tz=timezone.utc)
    return max(0, int((datetime.now(timezone.utc) - updated_at).total_seconds() // 86_400))


def _memory_freshness_text(document: SurfacedMemoryDocument) -> str:
    """age_days >= 2 返回 staleness caveat，否则返回空字符串。"""
    age_days = _memory_age_days(document.mtime_ms)
    if age_days <= 1:
        return ""
    return (
        f"This memory is {age_days} days old. "
        "Memories are point-in-time observations, not live state — "
        "claims about code behavior or file:line citations may be outdated. "
        "Verify against current code before asserting as fact."
    )


def _format_memory_label(document: SurfacedMemoryDocument) -> str:
    age_days = _memory_age_days(document.mtime_ms)
    if age_days <= 0:
        return "Memory (saved today)"
    if age_days == 1:
        return "Memory (saved yesterday)"
    return f"Memory (saved {age_days} days ago)"


def _coerce_turn_text(content: str | list[object]) -> str:
    if isinstance(content, str):
        return content.strip()

    parts: list[str] = []
    for part in content:
        text = getattr(part, "text", None)
        if isinstance(text, str) and text.strip():
            parts.append(text.strip())
    return "\n".join(parts).strip()
