from __future__ import annotations

import logging
from typing import TYPE_CHECKING

from comate_agent_sdk.llm.messages import BaseMessage

logger = logging.getLogger("comate_agent_sdk.agent")

if TYPE_CHECKING:
    from comate_agent_sdk.agent.core import AgentRuntime


def clear_history(agent: "AgentRuntime") -> None:
    """清空 message history 与 token usage，并重建 ContextIR header。"""
    agent._context.clear()
    agent._token_cost.clear_history()

    from comate_agent_sdk.agent.setup import (
        setup_memory_usage,
        setup_project_context,
        setup_tool_strategy,
        setup_user_instruction,
    )

    # 重建 IR header 各独立段
    setup_project_context(agent)
    resolved_prompt = agent._resolve_system_prompt()
    if resolved_prompt:
        agent._context.set_system_prompt(resolved_prompt, cache=True)

    setup_memory_usage(agent)
    setup_tool_strategy(agent)

    # 重建 subagent_strategy（如果有 agents）
    if agent._runtime_state.agents:
        from comate_agent_sdk.subagent.prompts import generate_subagent_prompt

        agent._context.set_subagent_strategy(generate_subagent_prompt(agent._runtime_state.agents))

    # 重建 skill_strategy（如果有 skills）
    if agent._runtime_state.skills:
        from comate_agent_sdk.skill.prompts import generate_skill_prompt

        skill_prompt = generate_skill_prompt(agent._runtime_state.skills)
        if skill_prompt:
            agent._context.set_skill_strategy(skill_prompt)

    is_plan_subagent = bool(getattr(agent, "_is_subagent", False) and agent.name == "Plan")

    # 如果有 user_instruction，重新加载
    if agent._runtime_state.user_instruction and not is_plan_subagent:
        setup_user_instruction(agent)

    # 重建 session_state（env/mcp）
    from comate_agent_sdk.agent.init import (
        _setup_env_info,
        _setup_mcp_session_state,
    )

    _setup_env_info(agent)
    _setup_mcp_session_state(agent)


def load_history(agent: "AgentRuntime", messages: list[BaseMessage]) -> None:
    """加载 message history（保留 header），用于恢复对话。"""
    # 清空现有 conversation（保留 header）
    agent._context.clear_conversation()
    agent._token_cost.clear_history()

    # 逐条加载消息到 IR
    for msg in messages:
        agent._context.add_message(msg)
