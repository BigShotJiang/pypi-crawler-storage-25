from __future__ import annotations

from collections.abc import Iterable

from comate_agent_sdk.tools.decorator import Tool

# 所有 subagent 模式下永远隐藏：
# - Agent：避免嵌套 subagent 调度
# - AskUserQuestion：避免 subagent 直接向用户发问，保持交互收敛在主 agent
# - TeamCreate / TeamDelete：Team 生命周期管理仅主 agent 可用
# - TaskCreate：任务创建权 
_ALWAYS_HIDDEN = frozenset({
    "Agent",
    "AskUserQuestion",
    "TeamCreate",
    "TeamDelete",
    "TaskCreate"
})

# Team 模式下解锁，非 Team 模式仍隐藏：
# - TaskList / TaskGet / TaskUpdate：Team 模式下 teammate 允许查看与更新现有任务
# - SendMessage：仅 Team 模式下有意义

TEAM_COORDINATION_TOOL_NAMES = (
    "TaskList",
    "TaskGet",
    "TaskUpdate",
    "SendMessage",
)
_TEAM_UNLOCKED = frozenset(TEAM_COORDINATION_TOOL_NAMES)

# 向后兼容导出（等价于原来的完整隐藏集）
SUBAGENT_HIDDEN_TOOL_NAMES = _ALWAYS_HIDDEN | _TEAM_UNLOCKED


def _hidden_set(*, is_subagent: bool, is_team_member: bool) -> frozenset[str]:
    """计算当前上下文下应隐藏的工具名集合。"""
    if not is_subagent:
        return frozenset()
    if is_team_member:
        return _ALWAYS_HIDDEN
    return _ALWAYS_HIDDEN | _TEAM_UNLOCKED


def visible_tools(
    tools: Iterable[Tool | object],
    *,
    is_subagent: bool,
    is_team_member: bool = False,
) -> list[Tool]:
    """按 runtime 身份过滤可见工具列表。

    - 非 subagent：返回全部工具
    - subagent + 非 Team 模式：隐藏 _ALWAYS_HIDDEN | _TEAM_UNLOCKED
    - subagent + Team 模式：只隐藏 _ALWAYS_HIDDEN（Task* 和 SendMessage 可见）
    """
    normalized = [t for t in tools if isinstance(t, Tool)]
    hidden = _hidden_set(is_subagent=is_subagent, is_team_member=is_team_member)
    if not hidden:
        return normalized
    return [t for t in normalized if t.name not in hidden]


def hidden_tool_names(
    tools: Iterable[Tool | object],
    *,
    is_subagent: bool,
    is_team_member: bool = False,
) -> list[str]:
    """返回当前上下文下应隐藏且实际命中的工具名（去重+排序）。"""
    hidden = _hidden_set(is_subagent=is_subagent, is_team_member=is_team_member)
    if not hidden:
        return []
    names = {
        t.name
        for t in tools
        if isinstance(t, Tool) and t.name in hidden
    }
    return sorted(names)
