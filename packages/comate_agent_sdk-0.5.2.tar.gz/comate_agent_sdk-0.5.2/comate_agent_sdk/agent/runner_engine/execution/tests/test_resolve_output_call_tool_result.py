"""Baseline test: _resolve_tool_output works with CallToolResult path.

Task 7 of tool-result-enforcement plan. No code changes expected —
_resolve_tool_output reads from ToolMessage (not CallToolResult directly),
so it naturally produces correct CustomToolOutput after Task 6 wired
CallToolResult into _build_tool_result_message.
"""

from comate_agent_sdk.agent.runner_engine.execution.tool_execution import (
    _resolve_tool_output,
)
from comate_agent_sdk.llm.messages import ToolMessage
from comate_agent_sdk.tool_schemas.custom import CustomToolOutput


def _make_tool_message(*, content="hello", is_error=False):
    return ToolMessage(
        tool_call_id="t1",
        tool_name="test",
        content=content,
        is_error=is_error,
    )


def test_custom_tool_produces_custom_tool_output():
    """Non-registry tool with string content → CustomToolOutput."""
    msg = _make_tool_message(content="result text")
    output = _resolve_tool_output("my_custom_tool", msg, is_task=False)
    assert isinstance(output, CustomToolOutput)
    assert output.content == "result text"
    assert output.is_error is False


def test_custom_tool_error_propagated():
    """is_error on ToolMessage → CustomToolOutput.is_error."""
    msg = _make_tool_message(content="fail", is_error=True)
    output = _resolve_tool_output("my_custom_tool", msg, is_task=False)
    assert isinstance(output, CustomToolOutput)
    assert output.is_error is True
