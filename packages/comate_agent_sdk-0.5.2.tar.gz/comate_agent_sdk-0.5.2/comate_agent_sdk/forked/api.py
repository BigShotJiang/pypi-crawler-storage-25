from __future__ import annotations

import uuid
from typing import TYPE_CHECKING, Any, Callable

from comate_agent_sdk.agent.core.runtime import AgentRuntime
from comate_agent_sdk.forked.runtime import ForkedAgentRuntime
from comate_agent_sdk.forked.snapshot import clone_context_ir_for_fork

async def run_forked_agent(
    parent_runtime: AgentRuntime,
    prompt: str,
    *,
    allowed_tools: set[str],
    tool_use_validator: Callable[[str, dict[str, Any]], str | None] | None = None,
    max_turns: int = 5,
    source_tag: str = "forked",
) -> str:
    context_snapshot = clone_context_ir_for_fork(parent_runtime._context)
    runtime = ForkedAgentRuntime.from_parent(
        parent_runtime=parent_runtime,
        context_snapshot=context_snapshot,
        allowed_tools=set(allowed_tools),
        tool_use_validator=tool_use_validator,
        max_turns=max_turns,
        source_tag=source_tag,
        run_id=uuid.uuid4().hex[:8],
    )
    try:
        return await runtime.query(prompt)
    finally:
        await runtime.aclose()
