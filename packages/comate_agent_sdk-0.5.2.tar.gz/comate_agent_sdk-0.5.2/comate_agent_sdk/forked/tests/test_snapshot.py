from __future__ import annotations

from comate_agent_sdk.context.ir import ContextIR
from comate_agent_sdk.llm.messages import AssistantMessage, ToolMessage, UserMessage
from comate_agent_sdk.forked.snapshot import clone_context_ir_for_fork


def _build_context() -> ContextIR:
    ctx = ContextIR()
    ctx.set_system_prompt("SYSTEM", cache=False)
    ctx.set_memory_usage("MEMORY_USAGE", cache=False)
    ctx.set_tool_strategy("TOOL_STRATEGY")
    ctx.set_user_instruction("USER_INSTRUCTION", cache=False)
    ctx.set_system_env("<system_env>ENV_A</system_env>")
    ctx.set_output_style("<output_style>STYLE_A</output_style>")
    ctx.add_message(UserMessage(content="user-1"))
    ctx.add_message(AssistantMessage(content="assistant-1", tool_calls=None))
    ctx.add_message(
        ToolMessage(
            tool_call_id="tool-call-1",
            tool_name="Read",
            content="tool-result-1",
        )
    )
    return ctx


def test_clone_context_ir_for_fork_preserves_all_layers() -> None:
    parent = _build_context()

    clone = clone_context_ir_for_fork(parent)

    assert [item.content_text for item in clone.header.items] == [
        item.content_text for item in parent.header.items
    ]
    assert [item.content_text for item in clone.session_state.items] == [
        item.content_text for item in parent.session_state.items
    ]
    assert [item.content_text for item in clone.conversation.items] == [
        item.content_text for item in parent.conversation.items
    ]
    assert clone.turn_number == parent.turn_number


def test_clone_context_ir_for_fork_isolated_from_parent_mutation() -> None:
    parent = _build_context()

    clone = clone_context_ir_for_fork(parent)

    parent.add_message(UserMessage(content="user-2"))
    parent.set_system_env("<system_env>ENV_B</system_env>")

    assert [item.content_text for item in clone.conversation.items] == [
        "user-1",
        "assistant-1",
        "tool-result-1",
    ]
    assert clone.session_state.items[1].content_text == "<system_env>ENV_A</system_env>"


def test_clone_context_ir_for_fork_does_not_share_message_objects() -> None:
    parent = _build_context()

    clone = clone_context_ir_for_fork(parent)

    assert clone.conversation.items[0].message is not parent.conversation.items[0].message
    assert isinstance(clone.conversation.items[0].message, UserMessage)
    clone.conversation.items[0].message.content = "forked-user-updated"

    assert isinstance(parent.conversation.items[0].message, UserMessage)
    assert parent.conversation.items[0].message.content == "user-1"


def test_clone_context_ir_for_fork_preserves_total_tokens() -> None:
    parent = _build_context()

    clone = clone_context_ir_for_fork(parent)

    assert clone.total_tokens == parent.total_tokens
