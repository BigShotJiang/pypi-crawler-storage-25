from __future__ import annotations

import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from comate_agent_sdk.agent import Agent, AgentConfig
from comate_agent_sdk.forked.api import run_forked_agent
from comate_agent_sdk.llm.messages import AssistantMessage, Function, ToolCall, UserMessage
from comate_agent_sdk.llm.views import ChatInvokeCompletion, ChatInvokeUsage
from comate_agent_sdk.tools.decorator import tool


@tool("Read files for tests", name="Read")
async def _read_tool(file_path: str) -> str:
    return f"read:{file_path}"


@tool("Run shell for tests", name="Bash")
async def _bash_tool(command: str) -> str:
    return f"bash:{command}"


def _tool_call(*, tool_call_id: str, name: str, arguments: dict) -> ToolCall:
    return ToolCall(
        id=tool_call_id,
        function=Function(
            name=name,
            arguments=json.dumps(arguments, ensure_ascii=False),
        ),
    )


class _FakeChatModel:
    def __init__(self, completions: list[ChatInvokeCompletion]) -> None:
        self.model = "fake:model"
        self._completions = completions
        self._index = 0
        self.calls: list[list[object]] = []

    @property
    def provider(self) -> str:
        return "fake"

    @property
    def name(self) -> str:
        return self.model

    async def ainvoke(self, messages, tools=None, tool_choice=None, **kwargs):  # type: ignore[no-untyped-def]
        del tools, tool_choice, kwargs
        self.calls.append(list(messages))
        if self._index >= len(self._completions):
            raise AssertionError(f"Unexpected ainvoke call #{self._index + 1}")
        completion = self._completions[self._index]
        self._index += 1
        return completion


class TestRunForkedAgent(unittest.IsolatedAsyncioTestCase):
    def _build_parent_runtime(self, *, llm: _FakeChatModel) -> tuple[tempfile.TemporaryDirectory[str], object]:
        tmp = tempfile.TemporaryDirectory()
        template = Agent(
            llm=llm,  # type: ignore[arg-type]
            config=AgentConfig(
                tools=(_read_tool, _bash_tool),
                agents=(),
                offload_enabled=False,
                setting_sources=None,
                cwd=Path(tmp.name),
            ),
        )
        runtime = template.create_runtime()
        runtime._context.add_message(UserMessage(content="parent-user"))
        runtime._context.add_message(AssistantMessage(content="parent-assistant", tool_calls=None))
        return tmp, runtime

    async def test_run_forked_agent_returns_final_text_and_keeps_parent_context_unchanged(self) -> None:
        llm = _FakeChatModel(
            [
                ChatInvokeCompletion(
                    content="forked-result",
                    usage=ChatInvokeUsage(
                        prompt_tokens=10,
                        prompt_cached_tokens=None,
                        prompt_cache_creation_tokens=None,
                        prompt_image_tokens=None,
                        completion_tokens=4,
                        total_tokens=14,
                    ),
                )
            ]
        )
        tmp, parent = self._build_parent_runtime(llm=llm)
        self.addCleanup(tmp.cleanup)
        parent_messages_before = [message.model_dump(mode="json") for message in parent.messages]

        result = await run_forked_agent(
            parent,
            "child prompt",
            allowed_tools={"Read"},
            source_tag="memory",
        )

        self.assertEqual(result, "forked-result")
        self.assertEqual(
            [message.model_dump(mode="json") for message in parent.messages],
            parent_messages_before,
        )

    async def test_run_forked_agent_first_call_contains_parent_context_plus_child_prompt(self) -> None:
        llm = _FakeChatModel(
            [
                ChatInvokeCompletion(
                    content="done",
                    usage=ChatInvokeUsage(
                        prompt_tokens=8,
                        prompt_cached_tokens=None,
                        prompt_cache_creation_tokens=None,
                        prompt_image_tokens=None,
                        completion_tokens=3,
                        total_tokens=11,
                    ),
                )
            ]
        )
        tmp, parent = self._build_parent_runtime(llm=llm)
        self.addCleanup(tmp.cleanup)

        await run_forked_agent(parent, "child prompt", allowed_tools={"Read"})

        first_call_texts = [getattr(message, "text", "") for message in llm.calls[0]]
        self.assertIn("parent-user", first_call_texts)
        self.assertIn("parent-assistant", first_call_texts)
        self.assertEqual(first_call_texts[-1], "child prompt")

    async def test_run_forked_agent_shares_parent_token_cost_with_forked_source_prefix(self) -> None:
        llm = _FakeChatModel(
            [
                ChatInvokeCompletion(
                    content="done",
                    usage=ChatInvokeUsage(
                        prompt_tokens=9,
                        prompt_cached_tokens=None,
                        prompt_cache_creation_tokens=None,
                        prompt_image_tokens=None,
                        completion_tokens=2,
                        total_tokens=11,
                    ),
                )
            ]
        )
        tmp, parent = self._build_parent_runtime(llm=llm)
        self.addCleanup(tmp.cleanup)

        await run_forked_agent(
            parent,
            "child prompt",
            allowed_tools={"Read"},
            source_tag="memory",
        )

        sources = [entry.source for entry in parent.token_cost.usage_history if entry.source]
        self.assertEqual(len(sources), 1)
        self.assertTrue(sources[0].startswith("forked:memory:"))

    async def test_run_forked_agent_mounts_allowed_tools_and_enforces_execution_gate(self) -> None:
        llm = _FakeChatModel(
            [
                ChatInvokeCompletion(
                    tool_calls=[
                        _tool_call(
                            tool_call_id="tc-bash-1",
                            name="Bash",
                            arguments={"command": "echo hi"},
                        )
                    ]
                ),
                ChatInvokeCompletion(
                    content="handled disallowed tool",
                    usage=ChatInvokeUsage(
                        prompt_tokens=12,
                        prompt_cached_tokens=None,
                        prompt_cache_creation_tokens=None,
                        prompt_image_tokens=None,
                        completion_tokens=5,
                        total_tokens=17,
                    ),
                ),
            ]
        )
        tmp, parent = self._build_parent_runtime(llm=llm)
        self.addCleanup(tmp.cleanup)

        result = await run_forked_agent(
            parent,
            "child prompt",
            allowed_tools={"Read"},
        )

        self.assertEqual(result, "handled disallowed tool")
        second_call_texts = [getattr(message, "text", "") for message in llm.calls[1]]
        self.assertTrue(any("not allowed in this runtime" in text for text in second_call_texts))

    async def test_run_forked_agent_uses_default_max_turns(self) -> None:
        llm = _FakeChatModel(
            [
                ChatInvokeCompletion(
                    content="done",
                    usage=ChatInvokeUsage(
                        prompt_tokens=8,
                        prompt_cached_tokens=None,
                        prompt_cache_creation_tokens=None,
                        prompt_image_tokens=None,
                        completion_tokens=3,
                        total_tokens=11,
                    ),
                )
            ]
        )
        tmp, parent = self._build_parent_runtime(llm=llm)
        self.addCleanup(tmp.cleanup)
        captured: dict[str, int] = {}

        original = run_forked_agent.__globals__["ForkedAgentRuntime"].from_parent

        def _spy_from_parent(**kwargs):
            captured["max_turns"] = kwargs["max_turns"]
            return original(**kwargs)

        with patch("comate_agent_sdk.forked.api.ForkedAgentRuntime.from_parent", side_effect=_spy_from_parent):
            await run_forked_agent(parent, "child prompt", allowed_tools={"Read"})

        self.assertEqual(captured["max_turns"], 5)

    async def test_run_forked_agent_allows_explicit_max_turns_override(self) -> None:
        llm = _FakeChatModel(
            [
                ChatInvokeCompletion(
                    content="done",
                    usage=ChatInvokeUsage(
                        prompt_tokens=8,
                        prompt_cached_tokens=None,
                        prompt_cache_creation_tokens=None,
                        prompt_image_tokens=None,
                        completion_tokens=3,
                        total_tokens=11,
                    ),
                )
            ]
        )
        tmp, parent = self._build_parent_runtime(llm=llm)
        self.addCleanup(tmp.cleanup)
        captured: dict[str, int] = {}

        original = run_forked_agent.__globals__["ForkedAgentRuntime"].from_parent

        def _spy_from_parent(**kwargs):
            captured["max_turns"] = kwargs["max_turns"]
            return original(**kwargs)

        with patch("comate_agent_sdk.forked.api.ForkedAgentRuntime.from_parent", side_effect=_spy_from_parent):
            await run_forked_agent(
                parent,
                "child prompt",
                allowed_tools={"Read"},
                max_turns=3,
            )

        self.assertEqual(captured["max_turns"], 3)
