from __future__ import annotations

import json
import tempfile
import unittest
from pathlib import Path

from comate_agent_sdk.agent import Agent, AgentConfig
from comate_agent_sdk.agent.memory_extract import build_memory_write_tool_validator
from comate_agent_sdk.agent.setup import resolve_auto_memory_dir
from comate_agent_sdk.forked.api import run_forked_agent
from comate_agent_sdk.llm.messages import Function, ToolCall
from comate_agent_sdk.llm.views import ChatInvokeCompletion
from comate_agent_sdk.system_tools.tools import Write


def _tool_call(*, tool_call_id: str, name: str, arguments: dict) -> ToolCall:
    return ToolCall(
        id=tool_call_id,
        function=Function(
            name=name,
            arguments=json.dumps(arguments, ensure_ascii=False),
        ),
    )


class _FakeChatModel:
    def __init__(self, completions: list[ChatInvokeCompletion]) -> None:
        self.model = "fake:model"
        self._completions = completions
        self._index = 0
        self.calls: list[list[object]] = []

    @property
    def provider(self) -> str:
        return "fake"

    @property
    def name(self) -> str:
        return self.model

    async def ainvoke(self, messages, tools=None, tool_choice=None, **kwargs):  # type: ignore[no-untyped-def]
        del tools, tool_choice, kwargs
        self.calls.append(list(messages))
        if self._index >= len(self._completions):
            raise AssertionError(f"Unexpected ainvoke call #{self._index + 1}")
        completion = self._completions[self._index]
        self._index += 1
        return completion


class TestMemoryWriteGate(unittest.IsolatedAsyncioTestCase):
    async def test_run_forked_agent_validator_rejects_write_outside_memory_dir(self) -> None:
        llm = _FakeChatModel(
            [
                ChatInvokeCompletion(
                    tool_calls=[
                        _tool_call(
                            tool_call_id="tc-write-1",
                            name="Write",
                            arguments={"file_path": "notes.txt", "content": "blocked\n"},
                        )
                    ]
                ),
                ChatInvokeCompletion(content="validator handled"),
            ]
        )
        tmp = tempfile.TemporaryDirectory()
        self.addCleanup(tmp.cleanup)

        template = Agent(
            llm=llm,  # type: ignore[arg-type]
            config=AgentConfig(
                tools=(Write,),
                agents=(),
                offload_enabled=False,
                setting_sources=None,
                cwd=Path(tmp.name),
            ),
        )
        runtime = template.create_runtime()
        memory_dir = resolve_auto_memory_dir(runtime)
        validator = build_memory_write_tool_validator(memory_dir)

        result = await run_forked_agent(
            runtime,
            "child prompt",
            allowed_tools={"Write"},
            tool_use_validator=validator,
        )

        self.assertEqual(result, "validator handled")
        second_call_texts = [getattr(message, "text", "") for message in llm.calls[1]]
        self.assertTrue(any("memory directory" in text for text in second_call_texts))
        self.assertFalse((Path(tmp.name) / "notes.txt").exists())


if __name__ == "__main__":
    unittest.main(verbosity=2)
