from __future__ import annotations

import copy

from comate_agent_sdk.context.ir import ContextIR
from comate_agent_sdk.context.observer import ContextEventBus


def clone_context_ir_for_fork(parent: ContextIR) -> ContextIR:
    """Deep-clone a parent ContextIR for isolated forked runtime execution."""

    return ContextIR(
        header=copy.deepcopy(parent.header),
        session_state=copy.deepcopy(parent.session_state),
        conversation=copy.deepcopy(parent.conversation),
        budget=copy.deepcopy(parent.budget),
        token_counter=copy.deepcopy(parent.token_counter),
        event_bus=ContextEventBus(),
        _reminder_engine=copy.deepcopy(parent.reminder_engine),
        _pending_skill_items=copy.deepcopy(parent._pending_skill_items),
        _turn_number=parent.turn_number,
        _inflight_tool_call_ids=set(parent._inflight_tool_call_ids),
        _thinking_protected_assistant_ids=set(parent._thinking_protected_assistant_ids),
        _pending_hook_injections=copy.deepcopy(parent._pending_hook_injections),
        _flushed_hook_injection_texts=list(parent._flushed_hook_injection_texts),
    )
