from __future__ import annotations

from dataclasses import dataclass, field, replace
from typing import Any, Callable

from comate_agent_sdk.agent.compaction import CompactionConfig, CompactionService
from comate_agent_sdk.agent.core.runtime import AgentRuntime
from comate_agent_sdk.agent.core.team_state import TeamCoordinationState
from comate_agent_sdk.agent.options import RuntimeState
from comate_agent_sdk.context.ir import ContextIR
from comate_agent_sdk.context.usage_tracker import ContextUsageTracker
from comate_agent_sdk.llm.base import ToolDefinition
from comate_agent_sdk.mcp.manager import is_mcp_tool


def _clone_runtime_state_for_fork(parent_runtime: AgentRuntime) -> RuntimeState:
    parent_state = parent_runtime._runtime_state
    return RuntimeState(
        tools=list(parent_state.tools or []) if parent_state.tools is not None else None,
        tool_registry=parent_state.tool_registry,
        agents=list(parent_state.agents or []) if parent_state.agents is not None else None,
        skills=list(parent_state.skills or []) if parent_state.skills is not None else None,
        user_instruction=parent_state.user_instruction,
        llm_levels=dict(parent_state.llm_levels or {}) if parent_state.llm_levels is not None else None,
        cwd=parent_state.cwd,
        session_id=parent_state.session_id,
        task_namespace=parent_state.task_namespace,
        team_name="",
        plan_mode_prompt_template=parent_state.plan_mode_prompt_template,
        permission_rules_allow=list(parent_state.permission_rules_allow or []) if parent_state.permission_rules_allow is not None else None,
        permission_rules_deny=list(parent_state.permission_rules_deny or []) if parent_state.permission_rules_deny is not None else None,
        offload_policy=None,
        tool_approval_callback=parent_state.tool_approval_callback,
    )


@dataclass(kw_only=True)
class ForkedAgentRuntime(AgentRuntime):
    parent_runtime: AgentRuntime = field(repr=False)
    context_snapshot: ContextIR = field(repr=False)
    allowed_tools: set[str] = field(repr=False)
    tool_use_validator: Callable[[str, dict[str, Any]], str | None] | None = field(
        default=None,
        repr=False,
    )
    source_tag: str = field(repr=False, default="forked")
    run_id: str = field(repr=False, default="forked-run")
    _parent_tool_definitions: tuple[ToolDefinition, ...] = field(default_factory=tuple, init=False, repr=False)

    def __post_init__(self) -> None:
        usage_source = f"forked:{self.source_tag}:{self.run_id}"

        self._allowed_tools = frozenset(self.allowed_tools)
        self._parent_tool_definitions = tuple(
            definition.model_copy(deep=True) for definition in self.parent_runtime.tool_definitions
        )
        self._tool_map = {
            name: tool
            for name, tool in self.parent_runtime._tool_map.items()
            if not is_mcp_tool(tool)
        }
        self._token_cost = self.parent_runtime.token_cost
        self._context = self.context_snapshot
        self._task_store = self.parent_runtime._task_store
        self._context_fs = None
        self._hook_engine = None
        self._subagent_source_prefix = usage_source
        self._context_usage_tracker = ContextUsageTracker(threshold_ratio=0.8)
        self._compaction_service = CompactionService(
            config=CompactionConfig(enabled=False),
            llm=self.parent_runtime.llm,
            token_cost=self._token_cost,
            usage_source=f"{usage_source}:compaction",
        )
        self._session_id = self.parent_runtime._session_id
        self._task_namespace = self.parent_runtime._task_namespace
        self._team = TeamCoordinationState()
        self._mcp_manager = None
        self._mcp_loaded = False
        self._mcp_dirty = False
        self._mcp_pending_tool_names = []
        self._mcp_tools_hash = ""
        self._mode = self.parent_runtime.get_mode()
        self._active_mode_snapshot = None
        self._memory_extraction_enabled = False
        self._relevant_memory_prefetch_enabled = False
        self._context.set_plan_mode(self._mode == "plan")

    @classmethod
    def from_parent(
        cls,
        *,
        parent_runtime: AgentRuntime,
        context_snapshot: ContextIR,
        allowed_tools: set[str],
        max_turns: int,
        source_tag: str,
        run_id: str,
        tool_use_validator: Callable[[str, dict[str, Any]], str | None] | None = None,
    ) -> "ForkedAgentRuntime":
        config = replace(
            parent_runtime.config,
            max_iterations=max_turns,
            compaction=CompactionConfig(enabled=False),
            mcp_enabled=False,
            offload_enabled=False,
        )
        return cls(
            llm=parent_runtime.llm,
            level=parent_runtime.level,
            config=config,
            _runtime_state=_clone_runtime_state_for_fork(parent_runtime),
            name=parent_runtime.name,
            template=parent_runtime.template,
            _is_subagent=False,
            _parent_token_cost=parent_runtime.token_cost,
            parent_runtime=parent_runtime,
            context_snapshot=context_snapshot,
            allowed_tools=set(allowed_tools),
            tool_use_validator=tool_use_validator,
            source_tag=source_tag,
            run_id=run_id,
        )

    @property
    def tool_definitions(self) -> list[ToolDefinition]:
        return [definition.model_copy(deep=True) for definition in self._parent_tool_definitions]

    def start_mcp_preload(self, *, force: bool = False):
        del force
        return None

    async def ensure_mcp_tools_loaded(self, *, force: bool = False) -> None:
        del force
        return None

    async def run_hook_event(self, event_name: str, **kwargs):
        del event_name, kwargs
        return None
