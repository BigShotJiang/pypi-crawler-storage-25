import asyncio
import tempfile
from pathlib import Path
from unittest.mock import patch

from comate_agent_sdk.system_tools.artifact_store import ArtifactStore


def test_put_bytes_writes_file_and_updates_index():
    with tempfile.TemporaryDirectory() as td:
        store = ArtifactStore(Path(td))

        async def _run():
            return await store.put_bytes(
                namespace="test", payload=b"hello world", mime="text/plain"
            )

        artifact = asyncio.run(_run())

        assert artifact["bytes"] == 11
        assert artifact["mime"] == "text/plain"
        target = Path(td) / artifact["relpath"]
        assert target.read_bytes() == b"hello world"
        assert store.index_path.exists()


def test_put_bytes_uses_asyncio_to_thread():
    """put_bytes 必须通过 asyncio.to_thread offload 同步 I/O，不能阻塞 event loop。"""
    with tempfile.TemporaryDirectory() as td:
        store = ArtifactStore(Path(td))

        async def _run():
            with patch(
                "comate_agent_sdk.system_tools.artifact_store.asyncio.to_thread",
                wraps=asyncio.to_thread,
            ) as mock_to_thread:
                await store.put_bytes(
                    namespace="test", payload=b"data", mime="text/plain"
                )
                mock_to_thread.assert_called_once()
                call_args = mock_to_thread.call_args
                assert call_args[0][0] == store._put_bytes_sync, (
                    f"Expected _put_bytes_sync to be dispatched to thread, got {call_args[0][0]}"
                )

        asyncio.run(_run())


def test_put_bytes_append_index_method_removed():
    """_append_index 空壳已被删除，不应存在。"""
    store = ArtifactStore(Path("."))
    assert not hasattr(store, "_append_index"), (
        "_append_index async 空壳应已删除"
    )
