from comate_agent_sdk.system_tools.tools import MultiEdit


def test_multi_edit_edits_field_has_description() -> None:
    schema = MultiEdit.definition.parameters
    edits_schema = schema["properties"]["edits"]
    assert "description" in edits_schema
