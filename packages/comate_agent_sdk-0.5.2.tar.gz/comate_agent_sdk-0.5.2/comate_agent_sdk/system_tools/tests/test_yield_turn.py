from __future__ import annotations

import asyncio
import json
import tempfile
import unittest
from pathlib import Path

from comate_agent_sdk.system_tools.tools import YieldTurn
from comate_agent_sdk.tools.system_context import bind_system_tool_context


class TestYieldTurn(unittest.TestCase):
    def test_yield_turn_returns_yielded_status(self) -> None:
        async def _run() -> None:
            with tempfile.TemporaryDirectory() as td:
                root = Path(td).resolve()
                with bind_system_tool_context(project_root=root):
                    result = await YieldTurn.execute(status="waiting_for_teammate")

            payload = json.loads(result)
            self.assertTrue(payload["ok"])
            self.assertEqual(payload["data"]["status"], "yielded")
            self.assertEqual(payload["data"]["yield_status"], "waiting_for_teammate")
            self.assertEqual(payload["meta"]["status"], "yielded")

        asyncio.run(_run())


if __name__ == "__main__":
    unittest.main(verbosity=2)
