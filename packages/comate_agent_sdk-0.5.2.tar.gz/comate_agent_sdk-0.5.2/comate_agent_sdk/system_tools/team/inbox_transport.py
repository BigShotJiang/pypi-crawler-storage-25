from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass

from comate_agent_sdk.system_tools.team.inbox import Inbox


@dataclass(slots=True)
class TeamInboxEnvelope:
    key: str
    from_agent: str
    message_type: str
    content: str
    timestamp: str
    raw_envelope: dict


@dataclass(slots=True)
class BufferedInboxBatch:
    events: list[TeamInboxEnvelope]


class TeamInboxTransport:
    def __init__(self, *, team_name: str, agent_name: str) -> None:
        self._inbox = Inbox(team_name=team_name, agent_name=agent_name)

    def poll_new(self) -> BufferedInboxBatch:
        events: list[TeamInboxEnvelope] = []
        for envelope in self._inbox.read_all():
            if bool(envelope.get("read", False)):
                continue
            key = self._message_key(envelope)
            payload = self._parse_payload(envelope.get("text", ""))
            events.append(
                TeamInboxEnvelope(
                    key=key,
                    from_agent=str(envelope.get("from", "") or "").strip(),
                    message_type=str(payload.get("type", "message") or "message").strip(),
                    content=str(payload.get("content", "") or "").strip(),
                    timestamp=str(envelope.get("timestamp", "") or "").strip(),
                    raw_envelope=dict(envelope),
                )
            )
        return BufferedInboxBatch(events=events)

    def ack(self, keys: list[str]) -> None:
        key_set = {str(key).strip() for key in keys if str(key).strip()}
        if not key_set:
            return

        def _mutate(messages: list[dict]) -> None:
            for envelope in messages:
                key = self._message_key(envelope)
                if key in key_set:
                    envelope["read"] = True

        self._inbox._with_write(_mutate)

    @staticmethod
    def _parse_payload(raw_text: object) -> dict:
        try:
            payload = json.loads(str(raw_text or "{}"))
        except Exception:
            return {}
        if isinstance(payload, dict):
            return payload
        return {}

    @staticmethod
    def _fingerprint(envelope: dict) -> str:
        raw = json.dumps(
            {
                "from": envelope.get("from", ""),
                "text": envelope.get("text", ""),
                "timestamp": envelope.get("timestamp", ""),
            },
            ensure_ascii=False,
            sort_keys=True,
        )
        return hashlib.sha1(raw.encode("utf-8")).hexdigest()

    @classmethod
    def _message_key(cls, envelope: dict) -> str:
        message_id = str(envelope.get("message_id", "") or "").strip()
        if message_id:
            return message_id
        return f"legacy:{cls._fingerprint(envelope)}"
