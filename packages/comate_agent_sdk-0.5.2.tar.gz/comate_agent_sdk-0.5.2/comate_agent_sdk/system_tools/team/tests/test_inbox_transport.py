from __future__ import annotations

import json
import tempfile
import unittest
from unittest.mock import patch

from comate_agent_sdk.system_tools.team.inbox import Inbox, MessageType
from comate_agent_sdk.system_tools.team.inbox_transport import (
    BufferedInboxBatch,
    TeamInboxEnvelope,
    TeamInboxTransport,
)


class TestInboxTransport(unittest.TestCase):
    def test_poll_returns_unacked_messages_without_marking_read(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            with patch.dict("os.environ", {"COMATE_TEAMS_DIR": td}):
                inbox = Inbox(team_name="review-team", agent_name="captain")
                inbox.append_message(
                    from_agent="worker-1",
                    message_type=MessageType.MESSAGE,
                    content="done",
                )

                transport = TeamInboxTransport(team_name="review-team", agent_name="captain")
                batch = transport.poll_new()

                self.assertIsInstance(batch, BufferedInboxBatch)
                self.assertEqual(len(batch.events), 1)
                self.assertIsInstance(batch.events[0], TeamInboxEnvelope)
                self.assertEqual([event.message_type for event in batch.events], ["message"])
                stored = inbox.read_all()
                self.assertEqual(batch.events[0].key, stored[0]["message_id"])
                payload = json.loads(stored[0]["text"])
                self.assertEqual(payload["type"], "message")
                self.assertFalse(stored[0]["read"])

    def test_ack_marks_exact_messages_as_read(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            with patch.dict("os.environ", {"COMATE_TEAMS_DIR": td}):
                inbox = Inbox(team_name="review-team", agent_name="captain")
                inbox.append_message(from_agent="worker-1", content="one")
                inbox.append_message(from_agent="worker-2", content="two")

                transport = TeamInboxTransport(team_name="review-team", agent_name="captain")
                first = transport.poll_new()
                self.assertEqual(len(first.events), 2)

                transport.ack([first.events[0].key])

                all_messages = inbox.read_all()
                self.assertTrue(all_messages[0]["read"])
                self.assertFalse(all_messages[1]["read"])

    def test_repoll_returns_unacked_messages_until_ack(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            with patch.dict("os.environ", {"COMATE_TEAMS_DIR": td}):
                inbox = Inbox(team_name="review-team", agent_name="captain")
                inbox.append_message(from_agent="worker-1", content="same")

                transport = TeamInboxTransport(team_name="review-team", agent_name="captain")
                first = transport.poll_new()
                second = transport.poll_new()

                self.assertEqual(len(first.events), 1)
                self.assertEqual(len(second.events), 1)
                self.assertEqual(first.events[0].key, second.events[0].key)

                transport.ack([first.events[0].key])
                third = transport.poll_new()
                self.assertEqual(third.events, [])

    def test_poll_uses_legacy_fallback_key_when_message_id_missing(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            with patch.dict("os.environ", {"COMATE_TEAMS_DIR": td}):
                inbox = Inbox(team_name="review-team", agent_name="captain")
                inbox._with_write(
                    lambda messages: messages.append(
                        {
                            "from": "worker-1",
                            "text": json.dumps({"type": "message", "content": "legacy"}, ensure_ascii=False),
                            "timestamp": "2026-03-11T00:00:00+00:00",
                            "read": False,
                        }
                    )
                )

                transport = TeamInboxTransport(team_name="review-team", agent_name="captain")
                batch = transport.poll_new()

                self.assertEqual(len(batch.events), 1)
                self.assertTrue(batch.events[0].key.startswith("legacy:"))


if __name__ == "__main__":
    unittest.main(verbosity=2)
