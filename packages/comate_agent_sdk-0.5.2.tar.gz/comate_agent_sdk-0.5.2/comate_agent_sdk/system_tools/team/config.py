"""TeamConfig — 文件系统持久化的 Team 成员注册表。

路径: ~/.agent/teams/{team_name}/config.json
"""

from __future__ import annotations

import json
import logging
import os
import tempfile
from contextlib import contextmanager
from pathlib import Path
from typing import Iterator

from filelock import FileLock

logger = logging.getLogger(__name__)

_TEAMS_BASE_DIR_ENV = "COMATE_TEAMS_DIR"


def resolve_teams_base_dir(base_dir: Path | None = None) -> Path:
    if base_dir is not None:
        return base_dir.expanduser().resolve()
    raw = str(os.environ.get(_TEAMS_BASE_DIR_ENV, "")).strip()
    if raw:
        return Path(raw).expanduser().resolve()
    return (Path.home() / ".agent" / "teams").expanduser().resolve()


class TeamConfig:
    """基于文件的团队成员注册表。

    config.json 格式::

        {
          "team_name": "code-review",
          "description": "Reviewing the authentication refactor",
          "members": [
            {
              "name": "team-lead",
              "agent_type": "leader",
              "registered_at": "2026-03-09T..."
            }
          ]
        }
    """

    def __init__(
        self,
        team_name: str,
        base_dir: Path | None = None,
    ) -> None:
        if not team_name or not team_name.strip():
            raise ValueError("team_name 不能为空")
        self.team_name = team_name.strip()
        self.base_dir = resolve_teams_base_dir(base_dir)
        self.team_dir = (self.base_dir / self.team_name).resolve()
        self.path = (self.team_dir / "config.json").resolve()
        self.lock_path = (self.team_dir / "config.lock").resolve()

    # ── 公共 API ────────────────────────────────────────────────────────

    def register_member(self, name: str, agent_type: str) -> None:
        """注册（或更新）一个 team 成员。幂等操作。"""
        from datetime import datetime, timezone
        from comate_agent_sdk.system_tools.team.identity import normalize_agent_name

        normalized_name = normalize_agent_name(name)
        normalized_type = agent_type.strip()
        if not normalized_name:
            raise ValueError("member name 不能为空")

        def _mutate(data: dict) -> None:
            members: list[dict] = data.setdefault("members", [])
            for member in members:
                if member.get("name") == normalized_name:
                    member["agent_type"] = normalized_type
                    member["updated_at"] = datetime.now(timezone.utc).isoformat()
                    return
            members.append(
                {
                    "name": normalized_name,
                    "agent_type": normalized_type,
                    "registered_at": datetime.now(timezone.utc).isoformat(),
                }
            )

        self._with_write(_mutate)
        logger.debug(
            f"[TeamConfig] 注册成员: team={self.team_name!r} "
            f"name={normalized_name!r} type={normalized_type!r}"
        )

    def set_description(self, description: str) -> None:
        """设置 team 描述。属于 TeamConfig 顶层元数据，幂等操作。"""
        normalized_description = description.strip()

        def _mutate(data: dict) -> None:
            if normalized_description:
                data["description"] = normalized_description
            else:
                data.pop("description", None)

        self._with_write(_mutate)
        logger.debug(
            f"[TeamConfig] 设置描述: team={self.team_name!r} "
            f"description={normalized_description!r}"
        )

    def set_leader_session(self, session_id: str, session_root: str) -> None:
        """记录 leader 的 session 信息，供 teammate 写入 team_events.jsonl 使用。"""

        def _mutate(data: dict) -> None:
            data["leader_session_id"] = session_id
            data["leader_session_root"] = session_root

        self._with_write(_mutate)
        logger.debug(
            f"[TeamConfig] 设置 leader session: team={self.team_name!r} "
            f"session_id={session_id!r}"
        )

    def get_leader_session(self) -> tuple[str, str]:
        """返回 (leader_session_id, leader_session_root)。未设置时返回空字符串。"""
        data = self._load()
        return (
            data.get("leader_session_id", ""),
            data.get("leader_session_root", ""),
        )

    def unregister_member(self, name: str) -> bool:
        """注销一个成员。若不存在返回 False。"""
        normalized_name = name.strip()
        removed = False

        def _mutate(data: dict) -> None:
            nonlocal removed
            before = len(data.get("members", []))
            data["members"] = [
                m for m in data.get("members", []) if m.get("name") != normalized_name
            ]
            removed = len(data["members"]) < before

        self._with_write(_mutate)
        if removed:
            logger.debug(
                f"[TeamConfig] 注销成员: team={self.team_name!r} name={normalized_name!r}"
            )
        return removed

    def list_members(self) -> list[dict]:
        """返回当前所有成员的快照（副本）。"""
        data = self._load()
        return list(data.get("members", []))

    def get_member(self, name: str) -> dict | None:
        """按名称查找成员。"""
        normalized_name = name.strip()
        for member in self.list_members():
            if member.get("name") == normalized_name:
                return dict(member)
        return None

    # ── 内部工具 ────────────────────────────────────────────────────────

    def _load(self) -> dict:
        def _reader() -> dict:
            self.team_dir.mkdir(parents=True, exist_ok=True)
            if not self.path.exists():
                return {"team_name": self.team_name, "members": []}
            raw = self.path.read_text(encoding="utf-8").strip()
            if not raw:
                return {"team_name": self.team_name, "members": []}
            return json.loads(raw)

        with self._acquire_lock():
            return _reader()

    def _save(self, data: dict) -> None:
        self.team_dir.mkdir(parents=True, exist_ok=True)
        serialized = json.dumps(data, indent=2, ensure_ascii=False)
        with tempfile.NamedTemporaryFile(
            mode="w",
            encoding="utf-8",
            dir=str(self.team_dir),
            prefix=".config.",
            suffix=".tmp",
            delete=False,
        ) as tmp:
            tmp.write(serialized)
            tmp_path = Path(tmp.name)
        os.replace(tmp_path, self.path)

    def _load_unlocked(self) -> dict:
        self.team_dir.mkdir(parents=True, exist_ok=True)
        if not self.path.exists():
            return {"team_name": self.team_name, "members": []}
        raw = self.path.read_text(encoding="utf-8").strip()
        if not raw:
            return {"team_name": self.team_name, "members": []}
        return json.loads(raw)

    def _with_write(self, callback) -> None:
        with self._acquire_lock():
            data = self._load_unlocked()
            data["team_name"] = self.team_name
            callback(data)
            self._save(data)

    @contextmanager
    def _acquire_lock(self) -> Iterator[None]:
        self.team_dir.mkdir(parents=True, exist_ok=True)
        with FileLock(self.lock_path):
            yield
