"""Inbox — 基于文件的 Agent 收件箱。

路径: ~/.agent/teams/{team_name}/inboxes/{agent_name}.json
"""

from __future__ import annotations

import json
import logging
import os
import tempfile
import uuid
from contextlib import contextmanager
from datetime import datetime, timezone
from enum import Enum
from pathlib import Path
from typing import Iterator

from filelock import FileLock

from comate_agent_sdk.system_tools.team.config import resolve_teams_base_dir
from comate_agent_sdk.system_tools.team.identity import normalize_agent_name

logger = logging.getLogger(__name__)


class MessageType(str, Enum):
    TASK_ASSIGNMENT = "task_assignment"
    MESSAGE = "message"
    BROADCAST = "broadcast"
    SHUTDOWN_REQUEST = "shutdown_request"
    SHUTDOWN_RESPONSE = "shutdown_response"
    PLAN_APPROVAL_REQUEST = "plan_approval_request"
    PLAN_APPROVAL_RESPONSE = "plan_approval_response"
    IDLE_NOTIFICATION = "idle_notification"


def _utc_now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


class Inbox:
    """基于文件的 agent 收件箱。

    消息信封格式::

        {
          "from": "team-lead",
          "text": "{\"type\": \"message\", \"content\": \"...\"}",
          "timestamp": "2026-03-09T...",
          "read": false
        }

    所有写操作通过 filelock 保证跨进程安全。
    """

    def __init__(
        self,
        team_name: str,
        agent_name: str,
        base_dir: Path | None = None,
    ) -> None:
        if not team_name or not team_name.strip():
            raise ValueError("team_name 不能为空")
        if not agent_name or not agent_name.strip():
            raise ValueError("agent_name 不能为空")
        self.team_name = team_name.strip()
        self.agent_name = normalize_agent_name(agent_name)
        base = resolve_teams_base_dir(base_dir)
        self.inbox_dir = (base / self.team_name / "inboxes").resolve()
        self.path = (self.inbox_dir / f"{self.agent_name}.json").resolve()
        self.lock_path = (self.inbox_dir / f"{self.agent_name}.lock").resolve()

    # ── 公共 API ────────────────────────────────────────────────────────

    def append_message(
        self,
        *,
        from_agent: str,
        message_type: str | MessageType = MessageType.MESSAGE,
        content: str,
    ) -> None:
        """原子追加一条消息到收件箱。"""
        msg_type = MessageType(message_type) if isinstance(message_type, str) else message_type
        envelope = {
            "message_id": uuid.uuid4().hex,
            "from": from_agent.strip(),
            "text": json.dumps(
                {"type": msg_type.value, "content": content},
                ensure_ascii=False,
            ),
            "timestamp": _utc_now_iso(),
            "read": False,
        }

        def _mutate(messages: list) -> None:
            messages.append(envelope)

        self._with_write(_mutate)
        logger.debug(
            f"[Inbox] 消息已写入: to={self.agent_name!r} from={from_agent!r} "
            f"type={msg_type.value!r}"
        )

    def read_unread(self, *, mark_as_read: bool = True) -> list[dict]:
        """读取未读消息。默认标记为已读。"""
        unread: list[dict] = []

        def _mutate(messages: list) -> None:
            for msg in messages:
                if not msg.get("read", False):
                    unread.append(dict(msg))
                    if mark_as_read:
                        msg["read"] = True

        self._with_write(_mutate)
        return unread

    def read_all(self) -> list[dict]:
        """读取所有消息（含已读），不修改 read 标记。"""
        messages = self._load()
        return [dict(m) for m in messages]

    def count_unread(self) -> int:
        """快速返回未读数量（使用共享锁，不修改状态）。"""
        with self._acquire_lock():
            messages = self._load_unlocked()
        return sum(1 for m in messages if not m.get("read", False))

    # ── 内部工具 ────────────────────────────────────────────────────────

    def _load(self) -> list:
        with self._acquire_lock():
            return self._load_unlocked()

    def _load_unlocked(self) -> list:
        self.inbox_dir.mkdir(parents=True, exist_ok=True)
        if not self.path.exists():
            return []
        raw = self.path.read_text(encoding="utf-8").strip()
        if not raw:
            return []
        data = json.loads(raw)
        return data if isinstance(data, list) else []

    def _save(self, messages: list) -> None:
        self.inbox_dir.mkdir(parents=True, exist_ok=True)
        serialized = json.dumps(messages, indent=2, ensure_ascii=False)
        with tempfile.NamedTemporaryFile(
            mode="w",
            encoding="utf-8",
            dir=str(self.inbox_dir),
            prefix=f".{self.agent_name}.",
            suffix=".tmp",
            delete=False,
        ) as tmp:
            tmp.write(serialized)
            tmp_path = Path(tmp.name)
        os.replace(tmp_path, self.path)

    def _with_write(self, callback) -> None:
        with self._acquire_lock():
            messages = self._load_unlocked()
            callback(messages)
            self._save(messages)

    @contextmanager
    def _acquire_lock(self) -> Iterator[None]:
        self.inbox_dir.mkdir(parents=True, exist_ok=True)
        with FileLock(self.lock_path):
            yield


def get_all_inboxes(team_name: str, base_dir: Path | None = None) -> list[str]:
    """返回 team 下所有已创建收件箱的 agent 名称列表。"""
    base = resolve_teams_base_dir(base_dir)
    inbox_dir = (base / team_name.strip() / "inboxes").resolve()
    if not inbox_dir.exists():
        return []
    return [
        p.stem
        for p in sorted(inbox_dir.glob("*.json"))
        if not p.name.startswith(".")
    ]


_TEAM_EVENTS_SCHEMA_VERSION = "1.0"


def append_team_event(
    *,
    leader_session_id: str,
    leader_session_root: str,
    from_agent: str,
    to_agent: str,
    message_type: str,
    content: str,
    timestamp: str,
) -> None:
    """追加一条团队通信记录到 team_events.jsonl。

    Best-effort：写入失败时仅 warning，不影响调用方。
    leader_session_root 为空时静默跳过。
    """
    if not leader_session_root:
        return

    try:
        session_root = Path(leader_session_root)
        events_file = session_root / "team_events.jsonl"
        lock_file = session_root / "team_events.lock"

        record = json.dumps(
            {
                "schema_version": _TEAM_EVENTS_SCHEMA_VERSION,
                "session_id": leader_session_id,
                "message_id": uuid.uuid4().hex,
                "from_agent": from_agent,
                "to_agent": to_agent,
                "message_type": message_type,
                "content": content,
                "timestamp": timestamp,
            },
            ensure_ascii=False,
        )

        with FileLock(lock_file):
            with open(events_file, "a", encoding="utf-8") as f:
                f.write(record + "\n")

    except Exception:
        logger.warning(
            "[team_events] Failed to append team event",
            exc_info=True,
        )
