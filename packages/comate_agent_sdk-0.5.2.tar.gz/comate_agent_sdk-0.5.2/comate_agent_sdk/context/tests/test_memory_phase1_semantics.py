from __future__ import annotations

from comate_agent_sdk.context.ir import ContextIR
from comate_agent_sdk.llm.messages import SystemMessage, UserMessage


def test_lowering_order_without_memory() -> None:
    ctx = ContextIR()
    ctx.set_project_context("<project_context>\nworking_directory: /tmp/demo\n</project_context>")
    ctx.set_system_prompt("SYSTEM")
    ctx.set_memory_usage("<memory_usage>MEMORY_USAGE</memory_usage>")
    ctx.set_user_instruction("FOLLOW_USER_INSTRUCTION", cache=False)
    ctx.set_system_env("<system_env>ENV</system_env>")
    ctx.add_message(UserMessage(content="hello", is_meta=False))

    messages = ctx.lower()

    assert len(messages) == 4
    assert isinstance(messages[0], SystemMessage)
    assert "<project_context>" in str(messages[0].content)
    assert "<memory_usage>" in str(messages[0].content)

    assert isinstance(messages[1], UserMessage)
    assert bool(getattr(messages[1], "is_meta", False))
    assert "<user_instructions>" in str(messages[1].content)

    assert isinstance(messages[2], UserMessage)
    assert bool(getattr(messages[2], "is_meta", False))
    assert "<system_env>ENV</system_env>" in str(messages[2].content)

    assert isinstance(messages[3], UserMessage)
    assert not bool(getattr(messages[3], "is_meta", False))
    assert str(messages[3].content) == "hello"

    lowered_user_text = "\n".join(
        str(message.content)
        for message in messages
        if isinstance(message, UserMessage)
    )
    assert "<memory>" not in lowered_user_text


def test_context_ir_has_no_memory_field() -> None:
    ctx = ContextIR()
    legacy_attr = "_" + "memory"
    legacy_setter = "set_" + "auto_" + "memory"

    assert not hasattr(ctx, legacy_attr)
    assert not hasattr(ctx, "memory")
    assert not hasattr(ctx, legacy_setter)
