from __future__ import annotations

from comate_agent_sdk.context.reminder_engine import ReminderEngine


def test_task_get_does_not_mutate_task_snapshot_state() -> None:
    engine = ReminderEngine()
    engine.record_tool_event(
        tool_name="TaskCreate",
        turn=3,
        payload={
            "list_id": "shared",
            "tasks": [
                {"id": "1", "subject": "task-a", "status": "pending"},
            ],
        },
    )

    before_last_task_tool_turn = engine.state.last_task_tool_turn
    before_task_open_count = engine.state.task_open_count
    before_list_id = engine.task_state.list_id
    before_tasks = list(engine.task_state.tasks)

    engine.record_tool_event(
        tool_name="TaskGet",
        turn=4,
        payload={
            "list_id": "shared",
            "tasks": [],
        },
    )

    assert engine.state.last_task_tool_turn == before_last_task_tool_turn
    assert engine.state.task_open_count == before_task_open_count
    assert engine.task_state.list_id == before_list_id
    assert engine.task_state.tasks == before_tasks
