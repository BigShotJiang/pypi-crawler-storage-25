"""ReminderEngine 单元测试。"""

from comate_agent_sdk.context.ir import ContextIR
from comate_agent_sdk.context.reminder_engine import ReminderEngine
from comate_agent_sdk.llm.messages import UserMessage


def test_collect_due_reminders_empty_state() -> None:
    engine = ReminderEngine()
    reminders = engine.collect_due_reminders(turn=1)
    assert reminders == []


def test_plan_mode_forced_reminder() -> None:
    engine = ReminderEngine()
    engine.set_plan_mode(True)
    engine.set_plan_mode_reminder_template("plan reminder")
    reminders = engine.collect_due_reminders(turn=1)
    assert any(r.rule_id == "plan_mode_forced" for r in reminders)


def test_agent_gap_reminder_with_cooldown() -> None:
    engine = ReminderEngine()
    reminders = engine.collect_due_reminders(turn=10)
    assert any(r.rule_id == "agent_gap_reminder" for r in reminders)
    assert engine.state.last_agent_nudge_turn == 10

    reminders = engine.collect_due_reminders(turn=11)
    assert not any(r.rule_id == "agent_gap_reminder" for r in reminders)


def test_task_active_and_empty_reminder() -> None:
    engine = ReminderEngine()
    engine.update_task_state(open_count=2, turn=1, update_last_write_turn=True)
    reminders = engine.collect_due_reminders(turn=8)
    assert any(r.rule_id == "task_active_reminder" for r in reminders)

    engine.update_task_state(open_count=0, turn=9, update_last_write_turn=True)
    reminders = engine.collect_due_reminders(turn=9)
    assert any(r.rule_id == "task_empty_reminder" for r in reminders)

    reminders = engine.collect_due_reminders(turn=17)
    assert not any(r.rule_id == "task_empty_reminder" for r in reminders)


def test_context_ir_inject_and_purge_system_reminders() -> None:
    ctx = ContextIR()
    ctx.add_message(UserMessage(content="hello"))  # turn=1

    ctx.record_tool_event(tool_name="Agent")
    ctx.set_turn_number(9)
    item = ctx.inject_due_reminders()
    assert item is not None
    assert item.item_type.value == "system_reminder"
    assert item.metadata.get("origin") == "system_reminder"

    removed = ctx.purge_system_reminders()
    assert removed == 1


def test_context_ir_inject_deduplicates_same_turn_same_rules() -> None:
    ctx = ContextIR()
    ctx.add_message(UserMessage(content="hello"))  # turn=1

    ctx.record_tool_event(tool_name="Agent")
    ctx.set_turn_number(9)

    first = ctx.inject_due_reminders()
    second = ctx.inject_due_reminders()
    assert first is not None
    assert second is None


def test_rehydrate_suppresses_immediate_task_gap_reminder() -> None:
    ctx = ContextIR()
    ctx.set_turn_number(12)
    ctx.rehydrate_reminder_state_from_conversation(
        suppress_task_nudge_on_next_turn=True
    )

    item = ctx.inject_due_reminders()
    assert item is None


def test_plan_exit_reminder_not_fired_without_turn() -> None:
    """act→plan（不发消息）→act：不应触发 exit reminder。"""
    engine = ReminderEngine()
    engine.set_plan_exit_reminder_template("exited plan")
    engine.set_plan_mode(True)   # 进入 plan，未发消息
    engine.set_plan_mode(False)  # 退出 plan
    reminders = engine.collect_due_reminders(turn=1)
    assert len(reminders) == 0


def test_plan_exit_reminder_fired_after_turn() -> None:
    """act→plan→发消息→act：应触发 exit reminder。"""
    engine = ReminderEngine()
    engine.set_plan_exit_reminder_template("exited plan")
    engine.set_plan_mode(True)       # 进入 plan
    engine.mark_plan_mode_used()     # 模拟 turn 发生
    engine.set_plan_mode(False)      # 退出 plan
    reminders = engine.collect_due_reminders(turn=1)
    assert len(reminders) == 1
    assert reminders[0].rule_id == "plan_exit_reminder"


def test_tool_triggered_register_and_retrieve() -> None:
    engine = ReminderEngine()
    engine.register_tool_triggered_reminder(
        reminder_id="test_reminder",
        trigger_tool="TestTool",
        content="test content",
    )
    assert "test_reminder" in engine._tool_triggered
    r = engine._tool_triggered["test_reminder"]
    assert r.trigger_tool == "TestTool"
    assert r.content == "test content"
    assert r.fired is False
    assert r.pending is False


def test_tool_triggered_register_idempotent() -> None:
    engine = ReminderEngine()
    engine.register_tool_triggered_reminder(
        reminder_id="test_reminder",
        trigger_tool="TestTool",
        content="original",
    )
    engine._tool_triggered["test_reminder"].fired = True
    engine.register_tool_triggered_reminder(
        reminder_id="test_reminder",
        trigger_tool="TestTool",
        content="overwrite attempt",
    )
    assert engine._tool_triggered["test_reminder"].fired is True
    assert engine._tool_triggered["test_reminder"].content == "original"


def test_tool_triggered_reminder_fires_once() -> None:
    engine = ReminderEngine()
    engine.register_tool_triggered_reminder(
        reminder_id="guide",
        trigger_tool="TaskCreate",
        content="use subagents",
    )

    # First tool event: should set pending
    engine.record_tool_event(tool_name="TaskCreate", turn=5)
    assert engine._tool_triggered["guide"].pending is True
    assert engine._tool_triggered["guide"].fired is False

    # Collect: should produce reminder and mark fired
    reminders = engine.collect_due_reminders(turn=5)
    tool_triggered = [r for r in reminders if r.rule_id == "guide"]
    assert len(tool_triggered) == 1
    assert tool_triggered[0].tool_name == "TaskCreate"
    assert tool_triggered[0].content == "use subagents"
    assert engine._tool_triggered["guide"].fired is True
    assert engine._tool_triggered["guide"].pending is False

    # Second tool event: should NOT set pending again
    engine.record_tool_event(tool_name="TaskCreate", turn=10)
    assert engine._tool_triggered["guide"].pending is False
    reminders = engine.collect_due_reminders(turn=10)
    assert not any(r.rule_id == "guide" for r in reminders)


def test_tool_triggered_reminder_no_match() -> None:
    engine = ReminderEngine()
    engine.register_tool_triggered_reminder(
        reminder_id="guide",
        trigger_tool="TaskCreate",
        content="use subagents",
    )
    engine.record_tool_event(tool_name="Agent", turn=5)
    assert engine._tool_triggered["guide"].pending is False
    reminders = engine.collect_due_reminders(turn=5)
    assert not any(r.rule_id == "guide" for r in reminders)


def test_tool_triggered_not_registered_no_effect() -> None:
    engine = ReminderEngine()
    # No registrations — record_tool_event should not error
    engine.record_tool_event(tool_name="TaskCreate", turn=5)
    reminders = engine.collect_due_reminders(turn=5)
    assert not any(r.rule_id == "guide" for r in reminders)


def test_tool_triggered_survives_clear() -> None:
    engine = ReminderEngine()
    engine.register_tool_triggered_reminder(
        reminder_id="guide",
        trigger_tool="TaskCreate",
        content="use subagents",
    )
    engine.record_tool_event(tool_name="TaskCreate", turn=5)
    engine.collect_due_reminders(turn=5)
    assert engine._tool_triggered["guide"].fired is True

    engine.clear()

    # Registration and fired state survive clear
    assert "guide" in engine._tool_triggered
    assert engine._tool_triggered["guide"].fired is True

    # Should not fire again after clear
    engine.record_tool_event(tool_name="TaskCreate", turn=1)
    assert engine._tool_triggered["guide"].pending is False


def test_tool_triggered_pending_delayed_by_plan_mode() -> None:
    engine = ReminderEngine()
    engine.set_plan_mode_reminder_template("plan active")
    engine.register_tool_triggered_reminder(
        reminder_id="guide",
        trigger_tool="TaskCreate",
        content="use subagents",
    )

    # Tool event happens, then plan mode enters
    engine.record_tool_event(tool_name="TaskCreate", turn=5)
    assert engine._tool_triggered["guide"].pending is True

    engine.set_plan_mode(True)

    # During plan mode: collect returns plan reminder only, pending preserved
    reminders = engine.collect_due_reminders(turn=6)
    assert any(r.rule_id == "plan_mode_forced" for r in reminders)
    assert not any(r.rule_id == "guide" for r in reminders)
    assert engine._tool_triggered["guide"].pending is True
    assert engine._tool_triggered["guide"].fired is False

    # Exit plan mode
    engine.set_plan_mode(False)

    # Now tool-triggered reminder should fire
    reminders = engine.collect_due_reminders(turn=7)
    assert any(r.rule_id == "guide" for r in reminders)
    assert engine._tool_triggered["guide"].fired is True


def test_tool_triggered_rehydrate_marks_fired() -> None:
    from comate_agent_sdk.context.ir import ContextIR
    from comate_agent_sdk.llm.messages import UserMessage

    ctx = ContextIR()
    ctx._reminder_engine.register_tool_triggered_reminder(
        reminder_id="guide",
        trigger_tool="TaskCreate",
        content="use subagents",
    )

    # Simulate a previously injected reminder with this rule_id in conversation
    ctx.add_message(UserMessage(content="hello"))
    ctx.set_turn_number(5)
    metadata = {
        "origin": "system_reminder",
        "reminder_rule_ids": ["guide"],
        "reminder_tools": ["TaskCreate"],
        "reminder_turn": 5,
    }
    from comate_agent_sdk.context.items import ItemType
    ctx.add_message(
        UserMessage(content="<system-reminder>\nuse subagents\n</system-reminder>", is_meta=True),
        item_type=ItemType.SYSTEM_REMINDER,
        metadata=metadata,
    )

    # Before rehydrate: not fired
    assert ctx._reminder_engine._tool_triggered["guide"].fired is False

    ctx.set_turn_number(10)
    ctx.rehydrate_reminder_state_from_conversation()

    # After rehydrate: fired
    assert ctx._reminder_engine._tool_triggered["guide"].fired is True
    assert ctx._reminder_engine._tool_triggered["guide"].pending is False

    # Should not fire again
    ctx.record_tool_event(tool_name="TaskCreate")
    assert ctx._reminder_engine._tool_triggered["guide"].pending is False


def test_tool_triggered_multiple_reminders_fire_in_same_collect() -> None:
    """多个 pending 的 tool-triggered reminders 在同一次 collect 中全部产出。"""
    engine = ReminderEngine()
    engine.register_tool_triggered_reminder(
        reminder_id="guide_a",
        trigger_tool="TaskCreate",
        content="guidance A",
    )
    engine.register_tool_triggered_reminder(
        reminder_id="guide_b",
        trigger_tool="Agent",
        content="guidance B",
    )

    engine.record_tool_event(tool_name="TaskCreate", turn=5)
    engine.record_tool_event(tool_name="Agent", turn=5)

    reminders = engine.collect_due_reminders(turn=5)
    triggered_ids = {r.rule_id for r in reminders if r.rule_id in ("guide_a", "guide_b")}
    assert triggered_ids == {"guide_a", "guide_b"}
    assert engine._tool_triggered["guide_a"].fired is True
    assert engine._tool_triggered["guide_b"].fired is True


def test_tool_triggered_pending_delayed_by_plan_exit() -> None:
    """plan_exit_pending 也会延迟 tool-triggered reminder，下一轮才产出。"""
    engine = ReminderEngine()
    engine.set_plan_mode_reminder_template("plan active")
    engine.set_plan_exit_reminder_template("exited plan")
    engine.register_tool_triggered_reminder(
        reminder_id="guide",
        trigger_tool="TaskCreate",
        content="use subagents",
    )

    # 进入 plan mode，发消息，退出 → plan_exit_pending = True
    engine.set_plan_mode(True)
    engine.mark_plan_mode_used()
    engine.set_plan_mode(False)

    # 同时触发 tool event
    engine.record_tool_event(tool_name="TaskCreate", turn=5)
    assert engine._tool_triggered["guide"].pending is True

    # plan_exit 优先，tool-triggered 被延迟
    reminders = engine.collect_due_reminders(turn=5)
    assert any(r.rule_id == "plan_exit_reminder" for r in reminders)
    assert not any(r.rule_id == "guide" for r in reminders)
    assert engine._tool_triggered["guide"].pending is True

    # 下一轮 tool-triggered 产出
    reminders = engine.collect_due_reminders(turn=6)
    assert any(r.rule_id == "guide" for r in reminders)
    assert engine._tool_triggered["guide"].fired is True
