from __future__ import annotations

from comate_agent_sdk.agent.system_prompt import resolve_system_prompt
from comate_agent_sdk.context.ir import ContextIR
from comate_agent_sdk.llm.messages import SystemMessage


def _lowered_system_prompt(ctx: ContextIR) -> str:
    lowered = ctx.lower()
    system_messages = [message for message in lowered if isinstance(message, SystemMessage)]
    assert len(system_messages) == 1
    return str(system_messages[0].content)


def test_default_system_prompt_template_injects_dynamic_static_header_items() -> None:
    ctx = ContextIR()
    ctx.set_system_prompt(resolve_system_prompt(None), cache=False)
    ctx.set_memory_usage("<memory_usage>MEMORY</memory_usage>", cache=False)
    ctx.set_subagent_strategy("<subagent>- **Plan**: Planner</subagent>")
    ctx.set_skill_strategy(
        "<skills>- **demo**: demo skill</skills>\n\n<skill_use>- load on demand</skill_use>"
    )

    lowered_text = _lowered_system_prompt(ctx)

    assert "# Capabilities" in lowered_text
    assert "# Context" in lowered_text
    assert lowered_text.count("<memory_usage>") == 1
    assert lowered_text.count("<subagent>") == 1
    assert lowered_text.count("<skills>") == 1
    assert lowered_text.count("<skill_use>") == 1


def test_static_header_without_placeholders_keeps_legacy_append_order() -> None:
    ctx = ContextIR()
    ctx.set_system_prompt("SYSTEM", cache=False)
    ctx.set_memory_usage("MEMORY", cache=False)
    ctx.set_subagent_strategy("SUBAGENT")
    ctx.set_skill_strategy("SKILL")

    lowered_text = _lowered_system_prompt(ctx)

    assert lowered_text == "SYSTEM\nMEMORY\nSUBAGENT\nSKILL"


def test_tool_strategy_placeholder_still_supported_for_older_custom_prompts() -> None:
    ctx = ContextIR()
    ctx.set_system_prompt("SYSTEM\n{{TOOL_STRATEGY}}\nTAIL", cache=False)
    ctx.set_tool_strategy("TOOL_STRATEGY_BODY")

    lowered_text = _lowered_system_prompt(ctx)

    assert lowered_text == "SYSTEM\nTOOL_STRATEGY_BODY\nTAIL"


def test_project_context_lowered_before_system_prompt() -> None:
    """PROJECT_CONTEXT must appear before SYSTEM_PROMPT in lowered output."""
    from comate_agent_sdk.context.ir import ContextIR
    from comate_agent_sdk.context.lower import LoweringPipeline

    ctx = ContextIR()
    ctx.set_project_context("<project_context>\nworking_directory: /tmp\n</project_context>")
    ctx.set_system_prompt("You are a test agent.\n\n{{MEMORY_USAGE}}")
    ctx.set_memory_usage("<memory_usage>mem</memory_usage>")

    messages = LoweringPipeline.lower(ctx)
    system_msg = messages[0]
    text = system_msg.content

    pc_pos = text.index("<project_context>")
    sp_pos = text.index("You are a test agent.")
    assert pc_pos < sp_pos, f"project_context ({pc_pos}) must come before system_prompt ({sp_pos})"
    # MEMORY_USAGE was inlined via {{MEMORY_USAGE}} template substitution — must not be duplicated
    assert text.count("<memory_usage>") == 1
