from __future__ import annotations

import json
import os
import tempfile
from pathlib import Path
from typing import Any, Literal

from comate_agent_sdk.mcp.types import McpServerConfig
from comate_agent_sdk.utils.paths import PathInput, normalize_path_input

McpScope = Literal["user", "project"]


class McpConfigError(ValueError):
    """Raised when `.mcp.json` is malformed or violates MCP config contract."""


def user_mcp_path() -> Path:
    return Path.home() / ".agent" / ".mcp.json"


def project_mcp_path(project_root: PathInput | None) -> Path:
    root = normalize_path_input(
        project_root if project_root is not None else Path.cwd(),
        field_name="project_root",
    )
    return root / ".agent" / ".mcp.json"


def scope_mcp_path(*, scope: McpScope, project_root: PathInput | None) -> Path:
    if scope == "user":
        return user_mcp_path()
    return project_mcp_path(project_root)


def parse_mcp_json_object(data: Any, *, path: Path) -> dict[str, McpServerConfig]:
    if not isinstance(data, dict):
        raise McpConfigError(f".mcp.json 顶层必须是对象: {path}")

    if "mcpServers" not in data:
        if "servers" in data:
            raise McpConfigError(
                f".mcp.json 使用了旧格式 'servers'，当前只支持 'mcpServers': {path}"
            )
        raise McpConfigError(
            f".mcp.json 缺少 'mcpServers' 顶层字段: {path}"
        )

    servers = data.get("mcpServers")
    if not isinstance(servers, dict):
        raise McpConfigError(f".mcp.json 字段 'mcpServers' 必须是对象: {path}")

    result: dict[str, McpServerConfig] = {}
    for alias, cfg in servers.items():
        normalized_alias = str(alias).strip()
        if not normalized_alias:
            raise McpConfigError(f".mcp.json 存在空 server 名称: {path}")
        result[normalized_alias] = validate_server_config(
            alias=normalized_alias,
            cfg=cfg,
            path=path,
        )
    return result


def _ensure_dict(value: Any, *, field_name: str, alias: str, path: Path) -> dict[str, Any]:
    if value is None:
        return {}
    if not isinstance(value, dict):
        raise McpConfigError(
            f".mcp.json server '{alias}' 字段 '{field_name}' 必须是对象: {path}"
        )
    return value


def _ensure_list(value: Any, *, field_name: str, alias: str, path: Path) -> list[Any]:
    if value is None:
        return []
    if not isinstance(value, list):
        raise McpConfigError(
            f".mcp.json server '{alias}' 字段 '{field_name}' 必须是数组: {path}"
        )
    return value


def validate_server_config(*, alias: str, cfg: Any, path: Path) -> McpServerConfig:
    if not isinstance(cfg, dict):
        raise McpConfigError(f".mcp.json server '{alias}' 配置必须是对象: {path}")

    server_cfg = dict(cfg)
    server_type = str(server_cfg.get("type", "stdio")).strip().lower()
    if server_type == "sdk":
        raise McpConfigError(
            f".mcp.json server '{alias}' 不支持 type='sdk'（仅支持代码注入）: {path}"
        )
    if server_type not in {"stdio", "http", "sse"}:
        raise McpConfigError(
            f".mcp.json server '{alias}' type 非法: {server_type!r}（仅支持 stdio/http/sse）: {path}"
        )

    if server_type == "stdio":
        command = server_cfg.get("command")
        if not isinstance(command, str) or not command.strip():
            raise McpConfigError(
                f".mcp.json server '{alias}' 缺少有效 command: {path}"
            )

        args = _ensure_list(server_cfg.get("args"), field_name="args", alias=alias, path=path)
        if any(not isinstance(item, str) for item in args):
            raise McpConfigError(
                f".mcp.json server '{alias}' 字段 'args' 必须全是字符串: {path}"
            )

        env = _ensure_dict(server_cfg.get("env"), field_name="env", alias=alias, path=path)
        if any(not isinstance(k, str) or not isinstance(v, str) for k, v in env.items()):
            raise McpConfigError(
                f".mcp.json server '{alias}' 字段 'env' 必须是 string->string: {path}"
            )
        return server_cfg  # type: ignore[return-value]

    url = server_cfg.get("url")
    if not isinstance(url, str) or not url.strip():
        raise McpConfigError(
            f".mcp.json server '{alias}' 缺少有效 url: {path}"
        )

    headers = _ensure_dict(server_cfg.get("headers"), field_name="headers", alias=alias, path=path)
    if any(not isinstance(k, str) or not isinstance(v, str) for k, v in headers.items()):
        raise McpConfigError(
            f".mcp.json server '{alias}' 字段 'headers' 必须是 string->string: {path}"
        )

    return server_cfg  # type: ignore[return-value]


def load_mcp_servers_from_path(path: PathInput) -> dict[str, McpServerConfig]:
    resolved = normalize_path_input(path, field_name="path")
    if not resolved.exists():
        return {}
    if not resolved.is_file():
        raise McpConfigError(f".mcp.json 路径不是文件: {resolved}")

    try:
        raw = resolved.read_text(encoding="utf-8")
        data = json.loads(raw)
    except Exception as exc:
        raise McpConfigError(f"读取/解析 .mcp.json 失败: {resolved}: {exc}") from exc

    return parse_mcp_json_object(data, path=resolved)


def dump_mcp_json_object(servers: dict[str, McpServerConfig]) -> dict[str, Any]:
    return {"mcpServers": dict(servers)}


def write_mcp_servers_to_path(*, path: PathInput, servers: dict[str, McpServerConfig]) -> None:
    target = normalize_path_input(path, field_name="path")
    target.parent.mkdir(parents=True, exist_ok=True)
    payload = json.dumps(
        dump_mcp_json_object(servers),
        ensure_ascii=False,
        indent=2,
        sort_keys=True,
    ) + "\n"

    fd, tmp_name = tempfile.mkstemp(prefix=".tmp_", dir=str(target.parent))
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as handle:
            handle.write(payload)
        os.replace(tmp_name, target)
    finally:
        tmp_path = Path(tmp_name)
        if tmp_path.exists():
            tmp_path.unlink(missing_ok=True)


def load_scope_servers(*, scope: McpScope, project_root: PathInput | None) -> dict[str, McpServerConfig]:
    return load_mcp_servers_from_path(scope_mcp_path(scope=scope, project_root=project_root))


def load_effective_servers(*, project_root: PathInput | None) -> dict[str, McpServerConfig]:
    user_servers = load_scope_servers(scope="user", project_root=project_root)
    project_servers = load_scope_servers(scope="project", project_root=project_root)
    merged = dict(user_servers)
    merged.update(project_servers)
    return merged
