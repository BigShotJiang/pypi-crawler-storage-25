"""Shared ContentBlock → SDK ContentPart conversion.

Used by both McpManager (MCP external tools) and tool_exec.py (Facade @tool).
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

from mcp.types import AudioContent, ImageContent, TextContent

from comate_agent_sdk.llm.messages import (
    ContentPartImageParam,
    ContentPartTextParam,
    ImageURL,
)

if TYPE_CHECKING:
    from mcp.types import ContentBlock

logger = logging.getLogger(__name__)

SDKContent = str | list[ContentPartTextParam | ContentPartImageParam]


def convert_content_blocks(blocks: list[ContentBlock]) -> SDKContent:
    """Convert MCP ContentBlock list to SDK internal format.

    Returns:
        str if single text block (optimization), else list of ContentPart.
        Empty string for empty input.
    """
    if not blocks:
        return ""

    parts: list[ContentPartTextParam | ContentPartImageParam] = []
    for block in blocks:
        if isinstance(block, TextContent):
            parts.append(ContentPartTextParam(text=block.text))
        elif isinstance(block, ImageContent):
            mime = block.mimeType or "image/png"
            url = f"data:{mime};base64,{block.data}"
            parts.append(
                ContentPartImageParam(
                    image_url=ImageURL(url=url, media_type=mime)  # type: ignore[arg-type]
                )
            )
        elif isinstance(block, AudioContent):
            mime = block.mimeType or "audio/unknown"
            parts.append(
                ContentPartTextParam(text=f"[audio data omitted, mimeType={mime}]")
            )
        else:
            # EmbeddedResource, ResourceLink → degrade to text
            try:
                parts.append(ContentPartTextParam(text=block.model_dump_json()))
            except Exception:
                parts.append(ContentPartTextParam(text=str(block)))

    # Optimization: single text block → plain str
    if len(parts) == 1 and isinstance(parts[0], ContentPartTextParam):
        return parts[0].text
    return parts
