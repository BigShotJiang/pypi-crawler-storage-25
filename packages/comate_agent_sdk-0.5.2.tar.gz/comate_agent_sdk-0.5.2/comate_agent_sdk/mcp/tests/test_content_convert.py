import pytest
from mcp.types import TextContent, ImageContent, AudioContent

from comate_agent_sdk.mcp.content_convert import convert_content_blocks
from comate_agent_sdk.llm.messages import ContentPartTextParam, ContentPartImageParam


def test_single_text_returns_string():
    """Single TextContent → plain str (optimization)."""
    blocks = [TextContent(type="text", text="hello")]
    result = convert_content_blocks(blocks)
    assert result == "hello"


def test_multiple_text_returns_list():
    """Multiple TextContent → list of ContentPartTextParam."""
    blocks = [
        TextContent(type="text", text="a"),
        TextContent(type="text", text="b"),
    ]
    result = convert_content_blocks(blocks)
    assert isinstance(result, list)
    assert len(result) == 2
    assert result[0].text == "a"
    assert result[1].text == "b"


def test_image_content_conversion():
    """ImageContent → ContentPartImageParam with data URI."""
    blocks = [ImageContent(type="image", data="base64data", mimeType="image/png")]
    result = convert_content_blocks(blocks)
    assert isinstance(result, list)
    assert len(result) == 1
    part = result[0]
    assert isinstance(part, ContentPartImageParam)
    assert "base64data" in part.image_url.url


def test_mixed_text_and_image():
    """Mixed blocks → list preserving order."""
    blocks = [
        TextContent(type="text", text="caption"),
        ImageContent(type="image", data="abc", mimeType="image/jpeg"),
    ]
    result = convert_content_blocks(blocks)
    assert isinstance(result, list)
    assert len(result) == 2
    assert isinstance(result[0], ContentPartTextParam)
    assert isinstance(result[1], ContentPartImageParam)


def test_audio_content_omits_data():
    """AudioContent → text placeholder, data field NOT serialized."""
    blocks = [AudioContent(type="audio", data="huge_base64", mimeType="audio/mp3")]
    result = convert_content_blocks(blocks)
    assert isinstance(result, str)  # single block → str optimization
    assert "audio data omitted" in result
    assert "audio/mp3" in result
    assert "huge_base64" not in result


def test_embedded_resource_degrades_to_json():
    """EmbeddedResource → model_dump_json() text."""
    from mcp.types import EmbeddedResource, TextResourceContents
    blocks = [EmbeddedResource(
        type="resource",
        resource=TextResourceContents(uri="file:///x.txt", text="hello"),
    )]
    result = convert_content_blocks(blocks)
    assert isinstance(result, str)  # single block → str optimization
    assert "x.txt" in result or "hello" in result


def test_empty_blocks():
    """Empty list → empty string."""
    result = convert_content_blocks([])
    assert result == ""


def test_convert_matches_old_mcp_manager_behavior():
    """Regression: shared function produces same output as old inline code."""
    blocks = [
        TextContent(type="text", text="caption"),
        ImageContent(type="image", data="abc123", mimeType="image/jpeg"),
    ]
    result = convert_content_blocks(blocks)
    assert isinstance(result, list)
    assert len(result) == 2
    assert result[0].text == "caption"
    # ImageContent → data URI
    assert "abc123" in result[1].image_url.url
    assert "image/jpeg" in result[1].image_url.url
