"""MarketplaceManager -- git 仓库形式的 marketplace CRUD 操作。

职责：
- add()    克隆 marketplace 仓库，校验 .claude-plugin/marketplace.json，注册到 PluginRegistry
- update() 拉取最新变更并更新时间戳
- remove() 删除本地目录并从 registry 注销
- list_available_plugins()     解析单个 marketplace 的 marketplace.json
- list_all_available_plugins() 聚合所有已注册 marketplace 的插件列表
"""

from __future__ import annotations

import asyncio
import json
import logging
import shutil
from datetime import datetime, timezone
from pathlib import Path

from comate_agent_sdk.plugins.models import MarketplaceInfo, MarketplaceSource, PluginEntry, PluginSource
from comate_agent_sdk.plugins.registry import PluginRegistry

logger = logging.getLogger(__name__)


class MarketplaceManager:
    """Marketplace CRUD 操作 -- git clone/pull/remove, marketplace.json 解析。"""

    def __init__(self, registry: PluginRegistry) -> None:
        self._registry = registry

    # ── Git 操作 ──

    async def _git_clone(self, repo: str, dest: Path) -> None:
        """Run ``git clone --depth 1 https://github.com/{repo}.git {dest}``."""
        proc = await asyncio.create_subprocess_exec(
            "git", "clone", "--depth", "1",
            f"https://github.com/{repo}.git", str(dest),
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        _, stderr = await proc.communicate()
        if proc.returncode != 0:
            raise RuntimeError(f"git clone failed: {stderr.decode()}")

    async def _git_pull(self, repo_dir: Path) -> None:
        """Run ``git -C {repo_dir} pull``."""
        proc = await asyncio.create_subprocess_exec(
            "git", "-C", str(repo_dir), "pull",
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        _, stderr = await proc.communicate()
        if proc.returncode != 0:
            raise RuntimeError(f"git pull failed: {stderr.decode()}")

    # ── 公共 API ──

    async def add(self, repo: str) -> MarketplaceInfo:
        """克隆 marketplace 仓库，校验 marketplace.json，注册到 registry。

        Args:
            repo: GitHub 仓库路径，如 ``"owner/repo-name"``。

        Returns:
            注册后的 MarketplaceInfo。

        Raises:
            ValueError: 仓库中缺少 ``.claude-plugin/marketplace.json``。
            RuntimeError: git clone 失败。
        """
        name = repo.split("/")[-1]
        dest = self._registry.base_dir / "marketplaces" / name

        # 幂等：已注册且目录存在 → 直接返回，跳过 clone
        for info in self._registry.list_marketplaces().values():
            if info.source.repo == repo and info.install_location.exists():
                return info

        await self._git_clone(repo, dest)

        manifest_path = dest / ".claude-plugin" / "marketplace.json"
        if not manifest_path.exists():
            shutil.rmtree(dest, ignore_errors=True)
            raise ValueError(f"Invalid marketplace: {manifest_path} not found")

        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
        mkt_name = manifest.get("name", name)

        info = MarketplaceInfo(
            name=mkt_name,
            source=MarketplaceSource(source="github", repo=repo),
            install_location=dest,
            last_updated=datetime.now(timezone.utc).isoformat(),
        )
        self._registry.add_marketplace(mkt_name, info)
        return info

    async def update(self, name: str) -> MarketplaceInfo:
        """拉取 marketplace 最新变更并更新时间戳。

        Raises:
            ValueError: marketplace 未注册。
            RuntimeError: git pull 失败。
        """
        marketplaces = self._registry.list_marketplaces()
        if name not in marketplaces:
            raise ValueError(f"Marketplace '{name}' not found")

        info = marketplaces[name]
        await self._git_pull(info.install_location)
        self._registry.update_marketplace_timestamp(name)
        return self._registry.list_marketplaces()[name]

    async def remove(self, name: str) -> None:
        """删除 marketplace 本地目录并从 registry 注销。

        Raises:
            ValueError: marketplace 未注册，或仍有已安装插件依赖该 marketplace。
        """
        marketplaces = self._registry.list_marketplaces()
        if name not in marketplaces:
            raise ValueError(f"Marketplace '{name}' not found")

        # Check for installed plugins from this marketplace
        installed = self._registry.list_installed()
        dependent = [key for key in installed if key.endswith(f"@{name}")]
        if dependent:
            raise ValueError(
                f"Cannot remove marketplace '{name}': {len(dependent)} installed plugin(s) depend on it. "
                f"Uninstall them first: {', '.join(dependent)}"
            )

        info = marketplaces[name]
        shutil.rmtree(info.install_location, ignore_errors=True)
        self._registry.remove_marketplace(name)

    def list_available_plugins(self, name: str) -> list[PluginEntry]:
        """解析指定 marketplace 的 marketplace.json 返回插件条目列表。

        Raises:
            ValueError: marketplace 未注册或 marketplace.json 不存在。
        """
        marketplaces = self._registry.list_marketplaces()
        if name not in marketplaces:
            raise ValueError(f"Marketplace '{name}' not found")
        mkt_dir = marketplaces[name].install_location
        manifest_path = mkt_dir / ".claude-plugin" / "marketplace.json"
        if not manifest_path.exists():
            raise ValueError(f"marketplace.json not found at {manifest_path}")

        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
        return [
            PluginEntry(
                name=p["name"],
                description=p.get("description", ""),
                source=PluginSource.from_raw(p.get("source", "")),
                author=p.get("author"),
                tags=p.get("tags", []),
                homepage=p.get("homepage"),
            )
            for p in manifest.get("plugins", [])
        ]

    def list_all_available_plugins(self) -> dict[str, list[PluginEntry]]:
        """聚合所有已注册 marketplace 的可用插件列表。"""
        result: dict[str, list[PluginEntry]] = {}
        for name in self._registry.list_marketplaces():
            try:
                result[name] = self.list_available_plugins(name)
            except (ValueError, json.JSONDecodeError):
                logger.warning("skipping broken marketplace: %s", name)
        return result
