"""PluginRegistry — JSON 文件持久化的插件注册表。

管理三个 JSON 文件：
- known_marketplaces.json — 已注册的 marketplace 元数据
- installed_plugins.json — 已安装插件记录（按 scope 区分）
- blocklist.json — 黑名单（只读，外部管理）

所有读-改-写操作通过 filelock.FileLock 保证并发安全。
"""

from __future__ import annotations

import json
import logging
import os
import tempfile
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path
from typing import Iterator

from filelock import FileLock

from comate_agent_sdk.plugins.models import InstalledPlugin, MarketplaceInfo

logger = logging.getLogger(__name__)

_MARKETPLACES_FILE = "known_marketplaces.json"
_INSTALLED_FILE = "installed_plugins.json"
_BLOCKLIST_FILE = "blocklist.json"
_INSTALLED_VERSION = 2


class PluginRegistry:
    """JSON 文件持久化的插件注册表。"""

    def __init__(self, base_dir: Path) -> None:
        self._base_dir = base_dir

    @property
    def base_dir(self) -> Path:
        return self._base_dir

    # ── Marketplace 操作 ──

    def list_marketplaces(self) -> dict[str, MarketplaceInfo]:
        raw = self._read_json(_MARKETPLACES_FILE)
        if not raw:
            return {}
        return {
            name: MarketplaceInfo.from_dict(name, data)
            for name, data in raw.items()
        }

    def add_marketplace(self, name: str, info: MarketplaceInfo) -> None:
        with self._lock_file(_MARKETPLACES_FILE):
            raw = self._read_json(_MARKETPLACES_FILE)
            raw[name] = info.to_dict()
            self._write_json(_MARKETPLACES_FILE, raw)

    def remove_marketplace(self, name: str) -> None:
        with self._lock_file(_MARKETPLACES_FILE):
            raw = self._read_json(_MARKETPLACES_FILE)
            raw.pop(name, None)
            self._write_json(_MARKETPLACES_FILE, raw)

    def update_marketplace_timestamp(self, name: str) -> None:
        with self._lock_file(_MARKETPLACES_FILE):
            raw = self._read_json(_MARKETPLACES_FILE)
            if name not in raw:
                logger.warning("marketplace %s not found, skip timestamp update", name)
                return
            raw[name]["lastUpdated"] = datetime.now(timezone.utc).isoformat()
            self._write_json(_MARKETPLACES_FILE, raw)

    # ── Installed Plugins 操作 ──

    def list_installed(self) -> dict[str, list[InstalledPlugin]]:
        raw = self._read_json(_INSTALLED_FILE)
        plugins_raw = raw.get("plugins", {})
        result: dict[str, list[InstalledPlugin]] = {}
        for key, entries in plugins_raw.items():
            result[key] = [InstalledPlugin.from_dict(e) for e in entries]
        return result

    def add_installed(self, plugin_key: str, entry: InstalledPlugin) -> None:
        with self._lock_file(_INSTALLED_FILE):
            raw = self._read_json(_INSTALLED_FILE)
            if "version" not in raw:
                raw["version"] = _INSTALLED_VERSION
            plugins = raw.setdefault("plugins", {})
            plugins.setdefault(plugin_key, []).append(entry.to_dict())
            self._write_json(_INSTALLED_FILE, raw)

    def remove_installed(
        self,
        plugin_key: str,
        scope: str,
        project_path: Path | None,
    ) -> None:
        with self._lock_file(_INSTALLED_FILE):
            raw = self._read_json(_INSTALLED_FILE)
            plugins = raw.get("plugins", {})
            if plugin_key not in plugins:
                return
            entries = plugins[plugin_key]
            filtered = [
                e for e in entries
                if not self._matches_scope(e, scope, project_path)
            ]
            if filtered:
                plugins[plugin_key] = filtered
            else:
                del plugins[plugin_key]
            self._write_json(_INSTALLED_FILE, raw)

    def set_enabled(
        self,
        plugin_key: str,
        scope: str,
        enabled: bool,
        project_path: Path | None = None,
    ) -> None:
        with self._lock_file(_INSTALLED_FILE):
            raw = self._read_json(_INSTALLED_FILE)
            plugins = raw.get("plugins", {})
            if plugin_key not in plugins:
                logger.warning("plugin %s not found, skip set_enabled", plugin_key)
                return
            entries = plugins[plugin_key]
            for i, e in enumerate(entries):
                if self._matches_scope(e, scope, project_path):
                    entries[i] = {**e, "enabled": enabled}
            self._write_json(_INSTALLED_FILE, raw)

    # ── Blocklist 操作 ──

    def is_blocked(self, plugin_key: str) -> bool:
        raw = self._read_json(_BLOCKLIST_FILE)
        plugins = raw.get("plugins", [])
        return any(entry.get("plugin") == plugin_key for entry in plugins)

    # ── 内部 JSON I/O ──

    @contextmanager
    def _lock_file(self, filename: str) -> Iterator[None]:
        self._base_dir.mkdir(parents=True, exist_ok=True)
        lock_path = self._base_dir / f"{filename}.lock"
        with FileLock(str(lock_path)):
            yield

    def _read_json(self, filename: str) -> dict:
        path = self._base_dir / filename
        if not path.exists():
            return {}
        try:
            text = path.read_text(encoding="utf-8")
            return json.loads(text)
        except (json.JSONDecodeError, OSError) as exc:
            logger.warning("failed to read %s: %s", path, exc)
            return {}

    def _write_json(self, filename: str, data: dict) -> None:
        self._base_dir.mkdir(parents=True, exist_ok=True)
        path = self._base_dir / filename
        content = json.dumps(data, indent=2, ensure_ascii=False) + "\n"
        with tempfile.NamedTemporaryFile(
            mode="w",
            encoding="utf-8",
            dir=str(self._base_dir),
            prefix=f".{filename}.",
            suffix=".tmp",
            delete=False,
        ) as tmp:
            tmp.write(content)
            tmp_path = Path(tmp.name)
        os.replace(tmp_path, path)

    @staticmethod
    def _matches_scope(
        entry_dict: dict,
        scope: str,
        project_path: Path | None,
    ) -> bool:
        if entry_dict.get("scope") != scope:
            return False
        if scope == "local":
            entry_project = entry_dict.get("projectPath")
            return entry_project == (str(project_path) if project_path else None)
        return True
