"""Plugin 系统数据模型定义"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Literal

from comate_agent_sdk.skill.models import SkillDefinition
from comate_agent_sdk.subagent.models import AgentDefinition


@dataclass(frozen=True, slots=True)
class MarketplaceSource:
    """Marketplace 来源信息"""

    source: str  # "github"
    repo: str  # "EveryInc/compound-engineering-plugin"

    def to_dict(self) -> dict:
        return {"source": self.source, "repo": self.repo}

    @classmethod
    def from_dict(cls, data: dict) -> MarketplaceSource:
        return cls(source=data["source"], repo=data["repo"])


@dataclass(frozen=True, slots=True)
class MarketplaceInfo:
    """Marketplace 注册信息"""

    name: str
    source: MarketplaceSource
    install_location: Path
    last_updated: str  # ISO 8601

    def to_dict(self) -> dict:
        return {
            "source": self.source.to_dict(),
            "installLocation": str(self.install_location),
            "lastUpdated": self.last_updated,
        }

    @classmethod
    def from_dict(cls, name: str, data: dict) -> MarketplaceInfo:
        return cls(
            name=name,
            source=MarketplaceSource.from_dict(data["source"]),
            install_location=Path(data["installLocation"]),
            last_updated=data["lastUpdated"],
        )


@dataclass(frozen=True, slots=True)
class PluginSource:
    """插件来源（支持多种类型）。

    - local:     marketplace 仓库内的相对路径（如 ``"./plugins/xxx"``）
    - url:       任意 git URL
    - github:    GitHub 仓库（``"org/repo"``）
    - git:       通用 git URL（同 url，语义等价）
    - file:      本地 JSON 文件路径
    - directory: 本地目录路径
    """

    type: Literal["local", "url", "github", "git", "file", "directory"]
    path: str | None = None   # local / file / directory
    url: str | None = None    # url / git / github
    repo: str | None = None   # github
    ref: str | None = None    # git branch/tag
    sha: str | None = None    # pinned commit

    def to_dict(self) -> str | dict:
        """序列化：local 类型返回原始路径字符串，其余返回 dict。"""
        if self.type == "local":
            return self.path or ""
        d: dict = {"source": self.type}
        if self.url is not None:
            d["url"] = self.url
        if self.repo is not None:
            d["repo"] = self.repo
        if self.path is not None:
            d["path"] = self.path
        if self.ref is not None:
            d["ref"] = self.ref
        if self.sha is not None:
            d["sha"] = self.sha
        return d

    @classmethod
    def from_raw(cls, raw: str | dict) -> PluginSource:
        """从 marketplace.json 的 source 字段解析。

        - ``str`` → local 类型（相对路径）
        - ``dict`` → 按 ``raw["source"]`` 字段确定类型
        """
        if isinstance(raw, str):
            return cls(type="local", path=raw)
        source_type = raw.get("source", "url")
        return cls(
            type=source_type,
            path=raw.get("path"),
            url=raw.get("url"),
            repo=raw.get("repo"),
            ref=raw.get("ref"),
            sha=raw.get("sha"),
        )


@dataclass(frozen=True, slots=True)
class PluginEntry:
    """Marketplace 中的插件条目（registry.json 中的一条）"""

    name: str
    description: str
    source: PluginSource
    author: dict | None = None
    tags: list[str] = field(default_factory=list)
    homepage: str | None = None

    def to_dict(self) -> dict:
        d: dict = {
            "name": self.name,
            "description": self.description,
            "source": self.source.to_dict(),
        }
        if self.author is not None:
            d["author"] = self.author
        if self.tags:
            d["tags"] = self.tags
        if self.homepage is not None:
            d["homepage"] = self.homepage
        return d

    @classmethod
    def from_dict(cls, data: dict) -> PluginEntry:
        return cls(
            name=data["name"],
            description=data["description"],
            source=PluginSource.from_raw(data["source"]),
            author=data.get("author"),
            tags=data.get("tags", []),
            homepage=data.get("homepage"),
        )


@dataclass(frozen=True, slots=True)
class InstalledPlugin:
    """已安装插件的元数据"""

    scope: Literal["user", "local"]
    install_path: Path
    version: str
    installed_at: str  # ISO 8601
    last_updated: str  # ISO 8601
    git_commit_sha: str | None = None
    project_path: Path | None = None  # scope="local" 时有效
    enabled: bool = True

    def to_dict(self) -> dict:
        d: dict = {
            "scope": self.scope,
            "installPath": str(self.install_path),
            "version": self.version,
            "installedAt": self.installed_at,
            "lastUpdated": self.last_updated,
            "enabled": self.enabled,
        }
        if self.git_commit_sha is not None:
            d["gitCommitSha"] = self.git_commit_sha
        if self.project_path is not None:
            d["projectPath"] = str(self.project_path)
        return d

    @classmethod
    def from_dict(cls, data: dict) -> InstalledPlugin:
        project_path_raw = data.get("projectPath")
        return cls(
            scope=data["scope"],
            install_path=Path(data["installPath"]),
            version=data["version"],
            installed_at=data["installedAt"],
            last_updated=data["lastUpdated"],
            git_commit_sha=data.get("gitCommitSha"),
            project_path=Path(project_path_raw) if project_path_raw is not None else None,
            enabled=data.get("enabled", True),
        )


@dataclass(frozen=True, slots=True)
class PluginManifest:
    """插件清单（plugin.json）"""

    name: str
    version: str
    description: str
    author: dict | None = None
    mcp_servers: dict | None = None

    def to_dict(self) -> dict:
        d: dict = {
            "name": self.name,
            "version": self.version,
            "description": self.description,
        }
        if self.author is not None:
            d["author"] = self.author
        if self.mcp_servers is not None:
            d["mcpServers"] = self.mcp_servers
        return d

    @classmethod
    def from_dict(cls, data: dict) -> PluginManifest:
        return cls(
            name=data["name"],
            version=data["version"],
            description=data["description"],
            author=data.get("author"),
            mcp_servers=data.get("mcpServers"),
        )


@dataclass(frozen=True, slots=True)
class PluginError:
    """插件加载/运行错误记录"""

    error_id: str
    plugin_key: str
    error_type: Literal["load_failure", "manifest_error", "mcp_connection", "git_error"]
    message: str
    timestamp: str  # ISO 8601


@dataclass(frozen=True, slots=True)
class CommandEntry:
    """插件命令条目"""

    name: str
    description: str
    template: str
    source_path: Path
    argument_hint: str | None = None


@dataclass
class LoadedPlugin:
    """已加载的插件聚合体（可变，加载过程中逐步填充）"""

    name: str
    namespace: str
    path: Path
    manifest: PluginManifest
    source_type: Literal["registry", "local"]
    skills: list[SkillDefinition] = field(default_factory=list)
    commands: list[CommandEntry] = field(default_factory=list)
    agents: list[AgentDefinition] = field(default_factory=list)
    mcp_servers: dict = field(default_factory=dict)  # server_name -> config dict
    hooks: dict | None = None  # reserved for V2


@dataclass(frozen=True, slots=True)
class PluginConfig:
    """插件配置项（来自 settings / .agent.json）"""

    type: Literal["local", "marketplace"]
    path: str | Path | None = None
    name: str | None = None
