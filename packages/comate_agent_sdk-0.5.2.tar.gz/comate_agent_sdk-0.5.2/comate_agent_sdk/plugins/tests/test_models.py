# comate_agent_sdk/plugins/tests/test_models.py
import unittest
from pathlib import Path

from comate_agent_sdk.plugins.models import (
    MarketplaceSource,
    MarketplaceInfo,
    PluginEntry,
    PluginSource,
    InstalledPlugin,
    PluginManifest,
    PluginError,
    CommandEntry,
    LoadedPlugin,
    PluginConfig,
)


class TestMarketplaceSource(unittest.TestCase):
    def test_create(self) -> None:
        src = MarketplaceSource(source="github", repo="EveryInc/compound-engineering-plugin")
        self.assertEqual(src.source, "github")
        self.assertEqual(src.repo, "EveryInc/compound-engineering-plugin")

    def test_to_dict_camel_case(self) -> None:
        src = MarketplaceSource(source="github", repo="owner/repo")
        d = src.to_dict()
        self.assertEqual(d, {"source": "github", "repo": "owner/repo"})

    def test_from_dict_camel_case(self) -> None:
        src = MarketplaceSource.from_dict({"source": "github", "repo": "owner/repo"})
        self.assertEqual(src.source, "github")


class TestMarketplaceInfo(unittest.TestCase):
    def test_to_dict_uses_camel_case(self) -> None:
        info = MarketplaceInfo(
            name="test-mkt",
            source=MarketplaceSource(source="github", repo="owner/repo"),
            install_location=Path("/tmp/plugins/marketplaces/test-mkt"),
            last_updated="2026-03-31T00:00:00Z",
        )
        d = info.to_dict()
        self.assertIn("installLocation", d)
        self.assertIn("lastUpdated", d)
        self.assertNotIn("install_location", d)

    def test_from_dict_reads_camel_case(self) -> None:
        info = MarketplaceInfo.from_dict(
            "test-mkt",
            {
                "source": {"source": "github", "repo": "owner/repo"},
                "installLocation": "/tmp/test",
                "lastUpdated": "2026-03-31T00:00:00Z",
            },
        )
        self.assertEqual(info.name, "test-mkt")
        self.assertEqual(info.install_location, Path("/tmp/test"))


class TestPluginSource(unittest.TestCase):
    def test_from_raw_string_creates_local(self) -> None:
        src = PluginSource.from_raw("./plugins/my-plugin")
        self.assertEqual(src.type, "local")
        self.assertEqual(src.path, "./plugins/my-plugin")

    def test_from_raw_empty_string(self) -> None:
        src = PluginSource.from_raw("")
        self.assertEqual(src.type, "local")
        self.assertEqual(src.path, "")

    def test_from_raw_url_dict(self) -> None:
        src = PluginSource.from_raw({"source": "url", "url": "https://github.com/org/repo.git"})
        self.assertEqual(src.type, "url")
        self.assertEqual(src.url, "https://github.com/org/repo.git")

    def test_from_raw_github_dict(self) -> None:
        src = PluginSource.from_raw({"source": "github", "repo": "org/repo"})
        self.assertEqual(src.type, "github")
        self.assertEqual(src.repo, "org/repo")

    def test_from_raw_git_with_ref_and_sha(self) -> None:
        src = PluginSource.from_raw({
            "source": "git", "url": "https://gitlab.com/x.git",
            "ref": "main", "sha": "abc123",
        })
        self.assertEqual(src.type, "git")
        self.assertEqual(src.ref, "main")
        self.assertEqual(src.sha, "abc123")

    def test_from_raw_directory(self) -> None:
        src = PluginSource.from_raw({"source": "directory", "path": "/opt/plugins/foo"})
        self.assertEqual(src.type, "directory")
        self.assertEqual(src.path, "/opt/plugins/foo")

    def test_from_raw_file(self) -> None:
        src = PluginSource.from_raw({"source": "file", "path": "/tmp/manifest.json"})
        self.assertEqual(src.type, "file")
        self.assertEqual(src.path, "/tmp/manifest.json")

    def test_to_dict_local_returns_string(self) -> None:
        src = PluginSource(type="local", path="./plugins/x")
        self.assertEqual(src.to_dict(), "./plugins/x")

    def test_to_dict_url_returns_dict(self) -> None:
        src = PluginSource(type="url", url="https://example.com/repo.git", ref="v1")
        d = src.to_dict()
        self.assertEqual(d, {"source": "url", "url": "https://example.com/repo.git", "ref": "v1"})

    def test_roundtrip_url(self) -> None:
        raw = {"source": "url", "url": "https://github.com/obra/superpowers.git"}
        src = PluginSource.from_raw(raw)
        restored = src.to_dict()
        self.assertEqual(restored["source"], "url")
        self.assertEqual(restored["url"], raw["url"])


class TestInstalledPlugin(unittest.TestCase):
    def test_roundtrip_user_scope(self) -> None:
        entry = InstalledPlugin(
            scope="user",
            install_path=Path("/tmp/cache/mkt/plugin/1.0.0"),
            version="1.0.0",
            installed_at="2026-03-31T00:00:00Z",
            last_updated="2026-03-31T00:00:00Z",
            enabled=True,
        )
        d = entry.to_dict()
        restored = InstalledPlugin.from_dict(d)
        self.assertEqual(restored.scope, "user")
        self.assertIsNone(restored.project_path)
        self.assertTrue(restored.enabled)

    def test_roundtrip_local_scope(self) -> None:
        entry = InstalledPlugin(
            scope="local",
            install_path=Path("/tmp/cache/mkt/plugin/1.0.0"),
            version="1.0.0",
            installed_at="2026-03-31T00:00:00Z",
            last_updated="2026-03-31T00:00:00Z",
            project_path=Path("/home/user/project"),
            enabled=True,
        )
        d = entry.to_dict()
        self.assertEqual(d["projectPath"], "/home/user/project")
        restored = InstalledPlugin.from_dict(d)
        self.assertEqual(restored.project_path, Path("/home/user/project"))


class TestPluginManifest(unittest.TestCase):
    def test_from_dict(self) -> None:
        manifest = PluginManifest.from_dict({
            "name": "test-plugin",
            "version": "1.0.0",
            "description": "A test plugin",
            "mcpServers": {"ctx7": {"type": "http", "url": "https://example.com"}},
        })
        self.assertEqual(manifest.name, "test-plugin")
        self.assertEqual(manifest.mcp_servers, {"ctx7": {"type": "http", "url": "https://example.com"}})

    def test_from_dict_no_mcp(self) -> None:
        manifest = PluginManifest.from_dict({
            "name": "simple",
            "version": "0.1.0",
            "description": "Simple plugin",
        })
        self.assertIsNone(manifest.mcp_servers)


class TestPluginError(unittest.TestCase):
    def test_create(self) -> None:
        err = PluginError(
            error_id="abc-123",
            plugin_key="plugin@mkt",
            error_type="load_failure",
            message="Missing plugin.json",
            timestamp="2026-03-31T00:00:00Z",
        )
        self.assertEqual(err.error_type, "load_failure")


class TestPluginConfig(unittest.TestCase):
    def test_create_local(self) -> None:
        cfg = PluginConfig(type="local", path="./my-plugin")
        self.assertEqual(cfg.type, "local")
        self.assertEqual(cfg.path, "./my-plugin")

    def test_create_with_path_object(self) -> None:
        cfg = PluginConfig(type="local", path=Path("/abs/path"))
        self.assertEqual(cfg.path, Path("/abs/path"))


class TestAgentOptionsPluginField(unittest.TestCase):
    def test_agent_options_accepts_plugins(self) -> None:
        from comate_agent_sdk.facade.config.options import AgentOptions
        from comate_agent_sdk.plugins.models import PluginConfig
        opts = AgentOptions(
            plugins=[PluginConfig(type="local", path="./my-plugin")],
        )
        self.assertIsNotNone(opts.plugins)
        self.assertEqual(len(opts.plugins), 1)

    def test_agent_options_plugins_default_none(self) -> None:
        from comate_agent_sdk.facade.config.options import AgentOptions
        opts = AgentOptions()
        self.assertIsNone(opts.plugins)
