import json
import tempfile
import unittest
from pathlib import Path

from comate_agent_sdk.plugins.models import (
    InstalledPlugin,
    MarketplaceInfo,
    MarketplaceSource,
)
from comate_agent_sdk.plugins.registry import PluginRegistry


class TestPluginRegistry(unittest.TestCase):
    def setUp(self) -> None:
        self._tmpdir = tempfile.TemporaryDirectory()
        self.base_dir = Path(self._tmpdir.name)
        self.registry = PluginRegistry(self.base_dir)

    def tearDown(self) -> None:
        self._tmpdir.cleanup()

    # ── Marketplaces ──

    def test_list_marketplaces_empty(self) -> None:
        result = self.registry.list_marketplaces()
        self.assertEqual(result, {})

    def test_add_and_list_marketplace(self) -> None:
        info = MarketplaceInfo(
            name="test-mkt",
            source=MarketplaceSource(source="github", repo="owner/repo"),
            install_location=self.base_dir / "marketplaces" / "test-mkt",
            last_updated="2026-03-31T00:00:00Z",
        )
        self.registry.add_marketplace("test-mkt", info)
        result = self.registry.list_marketplaces()
        self.assertIn("test-mkt", result)
        self.assertEqual(result["test-mkt"].source.repo, "owner/repo")

    def test_remove_marketplace(self) -> None:
        info = MarketplaceInfo(
            name="test-mkt",
            source=MarketplaceSource(source="github", repo="owner/repo"),
            install_location=self.base_dir / "marketplaces" / "test-mkt",
            last_updated="2026-03-31T00:00:00Z",
        )
        self.registry.add_marketplace("test-mkt", info)
        self.registry.remove_marketplace("test-mkt")
        result = self.registry.list_marketplaces()
        self.assertNotIn("test-mkt", result)

    def test_update_marketplace_timestamp(self) -> None:
        info = MarketplaceInfo(
            name="test-mkt",
            source=MarketplaceSource(source="github", repo="owner/repo"),
            install_location=self.base_dir / "marketplaces" / "test-mkt",
            last_updated="2026-01-01T00:00:00Z",
        )
        self.registry.add_marketplace("test-mkt", info)
        self.registry.update_marketplace_timestamp("test-mkt")
        result = self.registry.list_marketplaces()
        self.assertNotEqual(result["test-mkt"].last_updated, "2026-01-01T00:00:00Z")

    # ── Installed Plugins ──

    def test_list_installed_empty(self) -> None:
        result = self.registry.list_installed()
        self.assertEqual(result, {})

    def test_add_and_list_installed(self) -> None:
        entry = InstalledPlugin(
            scope="user",
            install_path=Path("/tmp/cache/mkt/plugin/1.0"),
            version="1.0",
            installed_at="2026-03-31T00:00:00Z",
            last_updated="2026-03-31T00:00:00Z",
        )
        self.registry.add_installed("plugin@mkt", entry)
        result = self.registry.list_installed()
        self.assertIn("plugin@mkt", result)
        self.assertEqual(len(result["plugin@mkt"]), 1)

    def test_remove_installed_by_scope(self) -> None:
        entry = InstalledPlugin(
            scope="user",
            install_path=Path("/tmp/cache/mkt/plugin/1.0"),
            version="1.0",
            installed_at="2026-03-31T00:00:00Z",
            last_updated="2026-03-31T00:00:00Z",
        )
        self.registry.add_installed("plugin@mkt", entry)
        self.registry.remove_installed("plugin@mkt", scope="user", project_path=None)
        result = self.registry.list_installed()
        # Key removed when no entries left
        self.assertNotIn("plugin@mkt", result)

    def test_set_enabled(self) -> None:
        entry = InstalledPlugin(
            scope="user",
            install_path=Path("/tmp/cache/mkt/plugin/1.0"),
            version="1.0",
            installed_at="2026-03-31T00:00:00Z",
            last_updated="2026-03-31T00:00:00Z",
            enabled=True,
        )
        self.registry.add_installed("plugin@mkt", entry)
        self.registry.set_enabled("plugin@mkt", scope="user", enabled=False)
        result = self.registry.list_installed()
        self.assertFalse(result["plugin@mkt"][0].enabled)

    # ── Blocklist ──

    def test_is_blocked_false_when_empty(self) -> None:
        self.assertFalse(self.registry.is_blocked("plugin@mkt"))

    def test_is_blocked_true_after_manual_add(self) -> None:
        blocklist_path = self.base_dir / "blocklist.json"
        blocklist_path.write_text(json.dumps({
            "fetchedAt": "2026-03-31T00:00:00Z",
            "plugins": [{"plugin": "bad@mkt", "reason": "security", "added_at": "2026-03-31T00:00:00Z"}],
        }))
        self.assertTrue(self.registry.is_blocked("bad@mkt"))
        self.assertFalse(self.registry.is_blocked("good@mkt"))

    # ── File creation ──

    def test_creates_directories_on_first_write(self) -> None:
        info = MarketplaceInfo(
            name="test-mkt",
            source=MarketplaceSource(source="github", repo="owner/repo"),
            install_location=self.base_dir / "marketplaces" / "test-mkt",
            last_updated="2026-03-31T00:00:00Z",
        )
        self.registry.add_marketplace("test-mkt", info)
        self.assertTrue((self.base_dir / "known_marketplaces.json").exists())

    # ── Concurrency ──

    def test_concurrent_writes_dont_corrupt(self) -> None:
        """Verify file locking prevents corruption under concurrent writes."""
        import threading

        def add_marketplace(name: str) -> None:
            reg = PluginRegistry(self.base_dir)
            info = MarketplaceInfo(
                name=name,
                source=MarketplaceSource(source="github", repo=f"owner/{name}"),
                install_location=self.base_dir / "marketplaces" / name,
                last_updated="2026-03-31T00:00:00Z",
            )
            reg.add_marketplace(name, info)

        threads = [threading.Thread(target=add_marketplace, args=(f"mkt-{i}",)) for i in range(10)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()

        result = self.registry.list_marketplaces()
        self.assertEqual(len(result), 10)
