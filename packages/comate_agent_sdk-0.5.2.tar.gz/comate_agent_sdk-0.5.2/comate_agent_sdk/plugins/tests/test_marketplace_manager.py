import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import AsyncMock, patch

from comate_agent_sdk.plugins.marketplace_manager import MarketplaceManager
from comate_agent_sdk.plugins.registry import PluginRegistry


class TestMarketplaceManager(unittest.IsolatedAsyncioTestCase):
    def setUp(self) -> None:
        self._tmpdir = tempfile.TemporaryDirectory()
        self.base_dir = Path(self._tmpdir.name)
        self.registry = PluginRegistry(self.base_dir)
        self.manager = MarketplaceManager(self.registry)

    def tearDown(self) -> None:
        self._tmpdir.cleanup()

    def _create_marketplace_dir(self, name: str, marketplace_json: dict) -> Path:
        """Helper: create a fake marketplace directory with .claude-plugin/marketplace.json"""
        mkt_dir = self.base_dir / "marketplaces" / name
        plugin_dir = mkt_dir / ".claude-plugin"
        plugin_dir.mkdir(parents=True)
        (plugin_dir / "marketplace.json").write_text(json.dumps(marketplace_json))
        return mkt_dir

    async def test_add_clones_repo_and_registers(self) -> None:
        """Test that add() clones the repo and writes to known_marketplaces.json."""
        marketplace_json = {
            "name": "test-mkt",
            "metadata": {"description": "Test", "version": "1.0.0"},
            "plugins": [
                {"name": "plugin-a", "description": "Plugin A", "source": "./plugins/a"}
            ],
        }

        async def fake_clone(*args, **kwargs) -> None:
            # Simulate git clone by creating the directory
            self._create_marketplace_dir("test-mkt", marketplace_json)

        with patch.object(self.manager, "_git_clone", side_effect=fake_clone):
            info = await self.manager.add("owner/test-mkt")

        self.assertEqual(info.name, "test-mkt")
        self.assertIn("test-mkt", self.registry.list_marketplaces())

    async def test_add_rejects_missing_marketplace_json(self) -> None:
        """Test that add() raises when .claude-plugin/marketplace.json is missing."""
        async def fake_clone(*args, **kwargs) -> None:
            mkt_dir = self.base_dir / "marketplaces" / "bad-repo"
            mkt_dir.mkdir(parents=True)

        with patch.object(self.manager, "_git_clone", side_effect=fake_clone):
            with self.assertRaises(ValueError, msg="marketplace.json"):
                await self.manager.add("owner/bad-repo")

    def test_list_available_plugins(self) -> None:
        from comate_agent_sdk.plugins.models import MarketplaceInfo, MarketplaceSource
        marketplace_json = {
            "name": "test-mkt",
            "plugins": [
                {"name": "p1", "description": "D1", "source": "./plugins/p1"},
                {"name": "p2", "description": "D2", "source": "./plugins/p2"},
            ],
        }
        mkt_dir = self._create_marketplace_dir("test-mkt", marketplace_json)
        self.registry.add_marketplace("test-mkt", MarketplaceInfo(
            name="test-mkt",
            source=MarketplaceSource(source="github", repo="owner/test-mkt"),
            install_location=mkt_dir,
            last_updated="2026-03-31T00:00:00Z",
        ))
        plugins = self.manager.list_available_plugins("test-mkt")
        self.assertEqual(len(plugins), 2)
        self.assertEqual(plugins[0].name, "p1")

    async def test_remove_deletes_dir_and_unregisters(self) -> None:
        marketplace_json = {"name": "test-mkt", "plugins": []}
        mkt_dir = self._create_marketplace_dir("test-mkt", marketplace_json)
        # Manually register
        from comate_agent_sdk.plugins.models import MarketplaceInfo, MarketplaceSource
        self.registry.add_marketplace("test-mkt", MarketplaceInfo(
            name="test-mkt",
            source=MarketplaceSource(source="github", repo="owner/test-mkt"),
            install_location=mkt_dir,
            last_updated="2026-03-31T00:00:00Z",
        ))
        await self.manager.remove("test-mkt")
        self.assertNotIn("test-mkt", self.registry.list_marketplaces())
        self.assertFalse(mkt_dir.exists())

    async def test_update_runs_git_pull(self) -> None:
        marketplace_json = {"name": "test-mkt", "plugins": []}
        mkt_dir = self._create_marketplace_dir("test-mkt", marketplace_json)
        from comate_agent_sdk.plugins.models import MarketplaceInfo, MarketplaceSource
        self.registry.add_marketplace("test-mkt", MarketplaceInfo(
            name="test-mkt",
            source=MarketplaceSource(source="github", repo="owner/test-mkt"),
            install_location=mkt_dir,
            last_updated="2026-01-01T00:00:00Z",
        ))
        with patch.object(self.manager, "_git_pull", new_callable=AsyncMock) as mock_pull:
            await self.manager.update("test-mkt")
            mock_pull.assert_called_once()
        result = self.registry.list_marketplaces()
        self.assertNotEqual(result["test-mkt"].last_updated, "2026-01-01T00:00:00Z")

    def test_list_all_available_plugins(self) -> None:
        from comate_agent_sdk.plugins.models import MarketplaceInfo, MarketplaceSource
        for name, plugins in [("mkt1", [{"name": "p1", "description": "D", "source": "./p1"}]),
                               ("mkt2", [{"name": "p2", "description": "D", "source": "./p2"}])]:
            self._create_marketplace_dir(name, {"name": name, "plugins": plugins})
            self.registry.add_marketplace(name, MarketplaceInfo(
                name=name,
                source=MarketplaceSource(source="github", repo=f"owner/{name}"),
                install_location=self.base_dir / "marketplaces" / name,
                last_updated="2026-03-31T00:00:00Z",
            ))
        result = self.manager.list_all_available_plugins()
        self.assertIn("mkt1", result)
        self.assertIn("mkt2", result)
        self.assertEqual(len(result["mkt1"]), 1)
