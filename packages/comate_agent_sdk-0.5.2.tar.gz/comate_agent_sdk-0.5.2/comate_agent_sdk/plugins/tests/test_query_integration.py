import json
import tempfile
import unittest
from pathlib import Path

from comate_agent_sdk.facade.config.options import AgentOptions
from comate_agent_sdk.plugins.models import PluginConfig


class TestQueryPluginIntegration(unittest.IsolatedAsyncioTestCase):
    def setUp(self) -> None:
        self._tmpdir = tempfile.TemporaryDirectory()
        self.plugin_dir = Path(self._tmpdir.name) / "test-plugin"
        (self.plugin_dir / ".claude-plugin").mkdir(parents=True)
        (self.plugin_dir / ".claude-plugin" / "plugin.json").write_text(json.dumps({
            "name": "test-plugin",
            "version": "1.0.0",
            "description": "Test",
        }))

    def tearDown(self) -> None:
        self._tmpdir.cleanup()

    def test_agent_options_with_plugins_creates_plugin_configs(self) -> None:
        opts = AgentOptions(
            plugins=[PluginConfig(type="local", path=str(self.plugin_dir))],
        )
        self.assertEqual(len(opts.plugins), 1)
        self.assertEqual(opts.plugins[0].path, str(self.plugin_dir))

    def test_query_exported_from_top_level(self) -> None:
        """Verify query is importable from comate_agent_sdk."""
        from comate_agent_sdk import query
        self.assertTrue(callable(query))
