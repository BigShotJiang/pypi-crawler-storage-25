import json
import tempfile
import unittest
from pathlib import Path

from comate_agent_sdk.plugins.loader import PluginLoader
from comate_agent_sdk.plugins.models import InstalledPlugin, LoadedPlugin, PluginError
from comate_agent_sdk.plugins.registry import PluginRegistry


class TestPluginLoader(unittest.TestCase):
    def setUp(self) -> None:
        self._tmpdir = tempfile.TemporaryDirectory()
        self.base_dir = Path(self._tmpdir.name)
        self.loader = PluginLoader()

    def tearDown(self) -> None:
        self._tmpdir.cleanup()

    def _create_plugin_dir(self, name: str = "test-plugin", version: str = "1.0.0") -> Path:
        """Create a minimal valid plugin directory."""
        plugin_dir = self.base_dir / name
        (plugin_dir / ".claude-plugin").mkdir(parents=True)
        (plugin_dir / ".claude-plugin" / "plugin.json").write_text(json.dumps({
            "name": name,
            "version": version,
            "description": f"Test plugin {name}",
        }))
        return plugin_dir

    def _add_skill(self, plugin_dir: Path, skill_name: str) -> None:
        skill_dir = plugin_dir / "skills" / skill_name
        skill_dir.mkdir(parents=True)
        (skill_dir / "SKILL.md").write_text(
            f"---\nname: {skill_name}\ndescription: Test skill\n---\nSkill body"
        )

    def _add_command(self, plugin_dir: Path, cmd_name: str) -> None:
        cmd_dir = plugin_dir / "commands"
        cmd_dir.mkdir(parents=True, exist_ok=True)
        (cmd_dir / f"{cmd_name}.md").write_text(
            f"---\ndescription: Test command {cmd_name}\n---\nCommand template"
        )

    def _add_agent(self, plugin_dir: Path, agent_name: str) -> None:
        agent_dir = plugin_dir / "agents"
        agent_dir.mkdir(parents=True, exist_ok=True)
        (agent_dir / f"{agent_name}.md").write_text(
            f"---\nname: {agent_name}\ndescription: Test agent\n---\nAgent prompt"
        )

    def _add_mcp(self, plugin_dir: Path) -> None:
        (plugin_dir / ".mcp.json").write_text(json.dumps({
            "context7": {"type": "http", "url": "https://mcp.context7.com/mcp"}
        }))

    # ── load_from_path ──

    def test_load_minimal_plugin(self) -> None:
        plugin_dir = self._create_plugin_dir()
        loaded = self.loader.load_from_path(plugin_dir)
        self.assertEqual(loaded.name, "test-plugin")
        self.assertEqual(loaded.namespace, "test-plugin")
        self.assertEqual(loaded.manifest.version, "1.0.0")
        self.assertEqual(loaded.skills, [])
        self.assertEqual(loaded.commands, [])
        self.assertEqual(loaded.agents, [])
        self.assertEqual(loaded.mcp_servers, {})

    def test_load_plugin_with_skills(self) -> None:
        plugin_dir = self._create_plugin_dir()
        self._add_skill(plugin_dir, "my-skill")
        loaded = self.loader.load_from_path(plugin_dir)
        self.assertEqual(len(loaded.skills), 1)
        # Skill name should be namespaced
        self.assertEqual(loaded.skills[0].name, "test-plugin:my-skill")

    def test_load_plugin_with_commands(self) -> None:
        plugin_dir = self._create_plugin_dir()
        self._add_command(plugin_dir, "my-cmd")
        loaded = self.loader.load_from_path(plugin_dir)
        self.assertEqual(len(loaded.commands), 1)
        self.assertEqual(loaded.commands[0].name, "test-plugin:my-cmd")

    def test_load_plugin_with_agents(self) -> None:
        plugin_dir = self._create_plugin_dir()
        self._add_agent(plugin_dir, "my-agent")
        loaded = self.loader.load_from_path(plugin_dir)
        self.assertEqual(len(loaded.agents), 1)

    def test_load_plugin_with_mcp(self) -> None:
        plugin_dir = self._create_plugin_dir()
        self._add_mcp(plugin_dir)
        loaded = self.loader.load_from_path(plugin_dir)
        self.assertIn("test-plugin:context7", loaded.mcp_servers)

    def test_load_missing_plugin_json_raises(self) -> None:
        bad_dir = self.base_dir / "bad-plugin"
        bad_dir.mkdir()
        with self.assertRaises(ValueError):
            self.loader.load_from_path(bad_dir)

    # ── load_from_registry ──

    def test_load_from_registry_filters_by_scope(self) -> None:
        registry = PluginRegistry(self.base_dir / "plugins")
        plugin_dir = self._create_plugin_dir()
        entry = InstalledPlugin(
            scope="user",
            install_path=plugin_dir,
            version="1.0.0",
            installed_at="2026-03-31T00:00:00Z",
            last_updated="2026-03-31T00:00:00Z",
            enabled=True,
        )
        registry.add_installed("test-plugin@mkt", entry)
        loaded, errors = self.loader.load_from_registry(registry)
        self.assertEqual(len(loaded), 1)
        self.assertEqual(len(errors), 0)

    def test_load_from_registry_skips_disabled(self) -> None:
        registry = PluginRegistry(self.base_dir / "plugins")
        plugin_dir = self._create_plugin_dir()
        entry = InstalledPlugin(
            scope="user",
            install_path=plugin_dir,
            version="1.0.0",
            installed_at="2026-03-31T00:00:00Z",
            last_updated="2026-03-31T00:00:00Z",
            enabled=False,
        )
        registry.add_installed("test-plugin@mkt", entry)
        loaded, errors = self.loader.load_from_registry(registry)
        self.assertEqual(len(loaded), 0)

    def test_load_from_registry_collects_errors(self) -> None:
        registry = PluginRegistry(self.base_dir / "plugins")
        bad_dir = self.base_dir / "bad-plugin"
        bad_dir.mkdir()
        entry = InstalledPlugin(
            scope="user",
            install_path=bad_dir,
            version="1.0.0",
            installed_at="2026-03-31T00:00:00Z",
            last_updated="2026-03-31T00:00:00Z",
            enabled=True,
        )
        registry.add_installed("bad@mkt", entry)
        loaded, errors = self.loader.load_from_registry(registry)
        self.assertEqual(len(loaded), 0)
        self.assertEqual(len(errors), 1)
        self.assertEqual(errors[0].plugin_key, "bad@mkt")

    # ── load_all ──

    def test_load_all_merges_registry_and_local(self) -> None:
        registry = PluginRegistry(self.base_dir / "plugins")
        local_dir = self._create_plugin_dir("local-plugin")
        loaded, errors = self.loader.load_all(
            registry=registry,
            local_plugins=[local_dir],
        )
        self.assertEqual(len(loaded), 1)
        self.assertEqual(loaded[0].source_type, "local")
