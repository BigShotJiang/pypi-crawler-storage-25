import json
import tempfile
import unittest
from pathlib import Path

from comate_agent_sdk.plugins.marketplace_manager import MarketplaceManager
from comate_agent_sdk.plugins.models import MarketplaceInfo, MarketplaceSource
from comate_agent_sdk.plugins.plugin_manager import PluginManager
from comate_agent_sdk.plugins.registry import PluginRegistry


class TestPluginManager(unittest.IsolatedAsyncioTestCase):
    def setUp(self) -> None:
        self._tmpdir = tempfile.TemporaryDirectory()
        self.base_dir = Path(self._tmpdir.name)
        self.registry = PluginRegistry(self.base_dir)
        self.mkt_mgr = MarketplaceManager(self.registry)
        self.mgr = PluginManager(self.registry, self.mkt_mgr)
        self._setup_test_marketplace()

    def tearDown(self) -> None:
        self._tmpdir.cleanup()

    def _setup_test_marketplace(self) -> None:
        """Create a test marketplace with one plugin."""
        mkt_dir = self.base_dir / "marketplaces" / "test-mkt"
        plugin_src = mkt_dir / "plugins" / "test-plugin"
        claude_plugin = plugin_src / ".claude-plugin"
        claude_plugin.mkdir(parents=True)
        (claude_plugin / "plugin.json").write_text(json.dumps({
            "name": "test-plugin",
            "version": "1.0.0",
            "description": "A test plugin",
        }))
        # Also create marketplace.json
        mkt_claude = mkt_dir / ".claude-plugin"
        mkt_claude.mkdir(parents=True)
        (mkt_claude / "marketplace.json").write_text(json.dumps({
            "name": "test-mkt",
            "plugins": [{"name": "test-plugin", "description": "Test", "source": "./plugins/test-plugin"}],
        }))
        self.registry.add_marketplace("test-mkt", MarketplaceInfo(
            name="test-mkt",
            source=MarketplaceSource(source="github", repo="owner/test-mkt"),
            install_location=mkt_dir,
            last_updated="2026-03-31T00:00:00Z",
        ))

    async def test_install_user_scope(self) -> None:
        result = await self.mgr.install("test-plugin", scope="user")
        self.assertEqual(result.version, "1.0.0")
        self.assertEqual(result.scope, "user")
        # Verify cache directory created
        cache_dir = self.base_dir / "cache" / "test-mkt" / "test-plugin" / "1.0.0"
        self.assertTrue(cache_dir.exists())
        self.assertTrue((cache_dir / ".claude-plugin" / "plugin.json").exists())
        # Verify registry updated
        installed = self.registry.list_installed()
        self.assertIn("test-plugin@test-mkt", installed)

    async def test_install_local_scope(self) -> None:
        project_path = Path("/home/user/project")
        result = await self.mgr.install("test-plugin", scope="local", project_path=project_path)
        self.assertEqual(result.scope, "local")
        self.assertEqual(result.project_path, project_path)

    async def test_uninstall(self) -> None:
        await self.mgr.install("test-plugin", scope="user")
        await self.mgr.uninstall("test-plugin@test-mkt", scope="user")
        installed = self.registry.list_installed()
        self.assertNotIn("test-plugin@test-mkt", installed)

    async def test_install_not_found_raises(self) -> None:
        with self.assertRaises(ValueError, msg="not found"):
            await self.mgr.install("nonexistent-plugin")

    def test_resolve_plugin_first_match(self) -> None:
        mkt_name, entry = self.mgr.resolve_plugin("test-plugin")
        self.assertEqual(mkt_name, "test-mkt")
        self.assertEqual(entry.name, "test-plugin")

    async def test_enable_disable(self) -> None:
        await self.mgr.install("test-plugin", scope="user")
        self.mgr.disable("test-plugin@test-mkt", scope="user")
        installed = self.registry.list_installed()
        self.assertFalse(installed["test-plugin@test-mkt"][0].enabled)
        self.mgr.enable("test-plugin@test-mkt", scope="user")
        installed = self.registry.list_installed()
        self.assertTrue(installed["test-plugin@test-mkt"][0].enabled)

    def test_resolve_with_full_key(self) -> None:
        """Test resolving with plugin@marketplace syntax."""
        mkt_name, entry = self.mgr.resolve_plugin("test-plugin@test-mkt")
        self.assertEqual(mkt_name, "test-mkt")
