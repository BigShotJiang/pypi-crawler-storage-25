"""PluginLoader — 插件资源发现与加载。

从插件目录中加载 skills、commands、agents、MCP servers、hooks 等资源，
所有资源名称以 {plugin_name}: 为前缀（namespace）防止跨插件冲突。
"""

from __future__ import annotations

import json
import logging
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Literal

from comate_agent_sdk.plugins.models import (
    CommandEntry,
    LoadedPlugin,
    PluginError,
    PluginManifest,
)
from comate_agent_sdk.plugins.registry import PluginRegistry
from comate_agent_sdk.skill.models import SkillDefinition
from comate_agent_sdk.subagent.models import AgentDefinition
from comate_agent_sdk.utils.yaml_utils import safe_load_frontmatter

logger = logging.getLogger(__name__)


class PluginLoader:
    """插件资源发现 — 从插件目录加载 skills、commands、agents、MCP。"""

    def load_from_path(
        self,
        path: Path,
        source_type: Literal["registry", "local"] = "registry",
    ) -> LoadedPlugin:
        """从单个插件目录加载所有资源。

        Args:
            path: 插件根目录
            source_type: 来源类型

        Returns:
            LoadedPlugin 聚合体

        Raises:
            ValueError: plugin.json 缺失或格式错误
        """
        manifest = self._load_manifest(path)
        namespace = manifest.name

        skills = self._load_skills(path, namespace)
        commands = self._load_commands(path, namespace)
        agents = self._load_agents(path, namespace)
        mcp_servers = self._load_mcp_servers(path, namespace)
        hooks = self._load_hooks(path)

        return LoadedPlugin(
            name=manifest.name,
            namespace=namespace,
            path=path,
            manifest=manifest,
            source_type=source_type,
            skills=skills,
            commands=commands,
            agents=agents,
            mcp_servers=mcp_servers,
            hooks=hooks,
        )

    def load_from_registry(
        self,
        registry: PluginRegistry,
        project_path: Path | None = None,
    ) -> tuple[list[LoadedPlugin], list[PluginError]]:
        """从注册表加载所有已启用的插件。

        Args:
            registry: 插件注册表
            project_path: 当前项目路径（用于过滤 scope="local" 的插件）

        Returns:
            (loaded_plugins, errors) 元组
        """
        loaded: list[LoadedPlugin] = []
        errors: list[PluginError] = []

        installed = registry.list_installed()
        for plugin_key, entries in installed.items():
            if registry.is_blocked(plugin_key):
                logger.debug("skipping blocked plugin: %s", plugin_key)
                continue

            for entry in entries:
                if not entry.enabled:
                    logger.debug("skipping disabled plugin: %s", plugin_key)
                    continue

                if entry.scope == "local" and project_path != entry.project_path:
                    logger.debug(
                        "skipping local plugin %s: project_path mismatch", plugin_key
                    )
                    continue

                try:
                    plugin = self.load_from_path(entry.install_path, source_type="registry")
                    loaded.append(plugin)
                except Exception as exc:
                    error = PluginError(
                        error_id=str(uuid.uuid4()),
                        plugin_key=plugin_key,
                        error_type="load_failure",
                        message=str(exc),
                        timestamp=datetime.now(timezone.utc).isoformat(),
                    )
                    errors.append(error)
                    logger.warning("failed to load plugin %s: %s", plugin_key, exc)

        return loaded, errors

    def load_all(
        self,
        registry: PluginRegistry | None = None,
        local_plugins: list[Path] | None = None,
        project_path: Path | None = None,
    ) -> tuple[list[LoadedPlugin], list[PluginError]]:
        """合并加载注册表插件和本地插件。

        Args:
            registry: 插件注册表（None 时跳过注册表加载，仅加载本地插件）
            local_plugins: 本地插件目录列表
            project_path: 当前项目路径

        Returns:
            (all_loaded, all_errors) 元组
        """
        if registry is not None:
            all_loaded, all_errors = self.load_from_registry(registry, project_path)
        else:
            all_loaded, all_errors = [], []

        for local_path in local_plugins or []:
            try:
                plugin = self.load_from_path(local_path, source_type="local")
                all_loaded.append(plugin)
            except Exception as exc:
                error = PluginError(
                    error_id=str(uuid.uuid4()),
                    plugin_key=str(local_path),
                    error_type="load_failure",
                    message=str(exc),
                    timestamp=datetime.now(timezone.utc).isoformat(),
                )
                all_errors.append(error)
                logger.warning("failed to load local plugin %s: %s", local_path, exc)

        # Check namespace conflicts
        seen_namespaces: dict[str, Path] = {}
        deduplicated: list[LoadedPlugin] = []
        for plugin in all_loaded:
            if plugin.namespace in seen_namespaces:
                all_errors.append(PluginError(
                    error_id=str(uuid.uuid4()),
                    plugin_key=plugin.name,
                    error_type="load_failure",
                    message=f"Namespace conflict: '{plugin.namespace}' already claimed by plugin at {seen_namespaces[plugin.namespace]}",
                    timestamp=datetime.now(timezone.utc).isoformat(),
                ))
            else:
                seen_namespaces[plugin.namespace] = plugin.path
                deduplicated.append(plugin)

        return deduplicated, all_errors

    # ── 内部加载方法 ──

    def _load_manifest(self, path: Path) -> PluginManifest:
        """加载 .claude-plugin/plugin.json 清单。"""
        plugin_json = path / ".claude-plugin" / "plugin.json"
        if not plugin_json.exists():
            raise ValueError(f"Missing plugin.json: {plugin_json}")

        try:
            data = json.loads(plugin_json.read_text(encoding="utf-8"))
            return PluginManifest.from_dict(data)
        except (json.JSONDecodeError, KeyError) as exc:
            raise ValueError(f"Invalid plugin.json at {plugin_json}: {exc}") from exc

    def _load_skills(self, path: Path, namespace: str) -> list[SkillDefinition]:
        """扫描 skills/ 目录，加载含 SKILL.md 的子目录。"""
        skills_dir = path / "skills"
        if not skills_dir.is_dir():
            return []

        skills: list[SkillDefinition] = []
        for skill_dir in sorted(skills_dir.iterdir()):
            if not skill_dir.is_dir():
                continue
            skill_md = skill_dir / "SKILL.md"
            if not skill_md.exists():
                logger.debug("skipping skill dir without SKILL.md: %s", skill_dir)
                continue
            try:
                skill = SkillDefinition.from_directory(skill_dir, namespace=namespace)
                skills.append(skill)
            except Exception as exc:
                logger.warning("failed to load skill %s: %s", skill_dir.name, exc)

        return skills

    def _load_commands(self, path: Path, namespace: str) -> list[CommandEntry]:
        """扫描 commands/*.md 文件，解析 YAML frontmatter。"""
        commands_dir = path / "commands"
        if not commands_dir.is_dir():
            return []

        commands: list[CommandEntry] = []
        for md_file in sorted(commands_dir.glob("*.md")):
            try:
                cmd = self._parse_command_file(md_file, namespace)
                commands.append(cmd)
            except Exception as exc:
                logger.warning("failed to load command %s: %s", md_file.name, exc)

        return commands

    def _parse_command_file(self, path: Path, namespace: str) -> CommandEntry:
        """解析命令 .md 文件（YAML frontmatter + 模板内容）。"""
        content = path.read_text(encoding="utf-8")

        if not content.startswith("---"):
            raise ValueError(f"Command file missing YAML frontmatter: {path}")

        parts = content.split("---", 2)
        if len(parts) < 3:
            raise ValueError(f"Invalid command file format: {path}")

        frontmatter_text = parts[1]
        template = parts[2].strip()

        frontmatter = safe_load_frontmatter(frontmatter_text, source=str(path))

        stem = path.stem
        return CommandEntry(
            name=f"{namespace}:{stem}",
            description=frontmatter.get("description", ""),
            template=template,
            source_path=path,
            argument_hint=frontmatter.get("argument_hint"),
        )

    def _load_agents(self, path: Path, namespace: str) -> list[AgentDefinition]:
        """扫描 agents/*.md 文件。"""
        agents_dir = path / "agents"
        if not agents_dir.is_dir():
            return []

        agents: list[AgentDefinition] = []
        for md_file in sorted(agents_dir.glob("*.md")):
            try:
                agent = AgentDefinition.from_file(md_file, namespace=namespace)
                agents.append(agent)
            except Exception as exc:
                logger.warning("failed to load agent %s: %s", md_file.name, exc)

        return agents

    def _load_mcp_servers(self, path: Path, namespace: str) -> dict:
        """读取 .mcp.json，为每个 server key 加上命名空间前缀。"""
        mcp_json = path / ".mcp.json"
        if not mcp_json.exists():
            return {}

        try:
            data = json.loads(mcp_json.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError) as exc:
            logger.warning("failed to read .mcp.json at %s: %s", path, exc)
            return {}

        return {f"{namespace}:{key}": value for key, value in data.items()}

    def _load_hooks(self, path: Path) -> dict | None:
        """读取 hooks/hooks.json（V1 占位，仅存储原始 dict）。"""
        hooks_json = path / "hooks" / "hooks.json"
        if not hooks_json.exists():
            return None

        try:
            return json.loads(hooks_json.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError) as exc:
            logger.warning("failed to read hooks.json at %s: %s", path, exc)
            return None
