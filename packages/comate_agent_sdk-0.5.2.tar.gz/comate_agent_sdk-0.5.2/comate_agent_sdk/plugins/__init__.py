from pathlib import Path

from .loader import PluginLoader
from .marketplace_manager import MarketplaceManager
from .models import (
    CommandEntry,
    InstalledPlugin,
    LoadedPlugin,
    MarketplaceInfo,
    MarketplaceSource,
    PluginConfig,
    PluginEntry,
    PluginError,
    PluginManifest,
)
from .plugin_manager import PluginManager
from .registry import PluginRegistry

__all__ = [
    "CommandEntry",
    "InstalledPlugin",
    "LoadedPlugin",
    "MarketplaceInfo",
    "MarketplaceManager",
    "MarketplaceSource",
    "PluginConfig",
    "PluginEntry",
    "PluginError",
    "PluginLoader",
    "PluginManager",
    "PluginManifest",
    "PluginRegistry",
]


def get_default_plugin_dir() -> Path:
    return Path.home() / ".agent" / "plugins"


def create_plugin_registry(base_dir: Path | None = None) -> PluginRegistry:
    return PluginRegistry(base_dir or get_default_plugin_dir())


def create_plugin_manager(base_dir: Path | None = None) -> PluginManager:
    registry = create_plugin_registry(base_dir)
    mkt_mgr = MarketplaceManager(registry)
    return PluginManager(registry, mkt_mgr)
