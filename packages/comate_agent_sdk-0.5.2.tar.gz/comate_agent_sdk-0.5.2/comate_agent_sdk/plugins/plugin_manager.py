"""PluginManager -- 插件生命周期管理（install/uninstall/enable/disable）。

职责：
- resolve_plugin()  在已注册 marketplace 中按 first-match 查找插件
- install()         解析 → 拷贝到版本化 cache 目录 → 写入 registry
- uninstall()       从 registry 移除（cache 保留）
- enable/disable    切换 registry 中的 enabled 标志
"""

from __future__ import annotations

import asyncio
import json
import logging
import shutil
import time
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Literal

from comate_agent_sdk.plugins.marketplace_manager import MarketplaceManager
from comate_agent_sdk.plugins.models import InstalledPlugin, MarketplaceInfo, PluginEntry, PluginSource
from comate_agent_sdk.plugins.registry import PluginRegistry

logger = logging.getLogger(__name__)


class PluginManager:
    """插件生命周期管理 -- install/uninstall/enable/disable。"""

    def __init__(self, registry: PluginRegistry, marketplace_manager: MarketplaceManager) -> None:
        self._registry = registry
        self._mkt_mgr = marketplace_manager

    # ── Git 操作 ──

    async def _git_clone_plugin(
        self,
        url: str,
        dest: Path,
        *,
        ref: str | None = None,
        sha: str | None = None,
    ) -> None:
        """Shallow clone 插件仓库到 *dest*，支持 ref/sha pinning。"""
        if sha:
            # no-checkout clone → fetch sha → checkout
            proc = await asyncio.create_subprocess_exec(
                "git", "clone", "--depth", "1", "--recurse-submodules",
                "--shallow-submodules", "--no-checkout", url, str(dest),
                stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE,
            )
            _, stderr = await proc.communicate()
            if proc.returncode != 0:
                raise RuntimeError(f"git clone failed: {stderr.decode()}")
            proc = await asyncio.create_subprocess_exec(
                "git", "-C", str(dest), "fetch", "--depth", "1", "origin", sha,
                stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE,
            )
            _, stderr = await proc.communicate()
            if proc.returncode != 0:
                # fallback: unshallow + fetch
                proc2 = await asyncio.create_subprocess_exec(
                    "git", "-C", str(dest), "fetch", "--unshallow",
                    stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE,
                )
                await proc2.communicate()
            proc = await asyncio.create_subprocess_exec(
                "git", "-C", str(dest), "checkout", sha,
                stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE,
            )
            _, stderr = await proc.communicate()
            if proc.returncode != 0:
                raise RuntimeError(f"git checkout {sha} failed: {stderr.decode()}")
        else:
            cmd = [
                "git", "clone", "--depth", "1", "--recurse-submodules",
                "--shallow-submodules",
            ]
            if ref:
                cmd += ["--branch", ref]
            cmd += [url, str(dest)]
            proc = await asyncio.create_subprocess_exec(
                *cmd,
                stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE,
            )
            _, stderr = await proc.communicate()
            if proc.returncode != 0:
                raise RuntimeError(f"git clone failed: {stderr.decode()}")

    async def _resolve_plugin_source(
        self, mkt_info: MarketplaceInfo, source: PluginSource,
    ) -> tuple[Path, bool]:
        """按 source type 将插件源解析为本地目录。

        Returns:
            (source_dir, is_staging) — is_staging=True 表示 source_dir 是临时 clone
            目录，调用方用完后需要清理。
        """
        if source.type == "local":
            return mkt_info.install_location / (source.path or ""), False

        if source.type in ("url", "git"):
            url = source.url
            if not url:
                raise ValueError(f"Plugin source type '{source.type}' requires 'url'")
        elif source.type == "github":
            repo = source.repo or source.url  # 兼容 {"source":"github","url":"org/repo"}
            if not repo:
                raise ValueError("Plugin source type 'github' requires 'repo' or 'url'")
            url = f"https://github.com/{repo}.git" if "://" not in repo else repo
        elif source.type == "directory":
            path = source.path
            if not path:
                raise ValueError("Plugin source type 'directory' requires 'path'")
            return Path(path), False
        elif source.type == "file":
            path = source.path
            if not path:
                raise ValueError("Plugin source type 'file' requires 'path'")
            return Path(path).parent, False
        else:
            raise ValueError(f"Unsupported plugin source type: '{source.type}'")

        # Remote source → clone to staging
        staging_name = f"temp_{source.type}_{int(time.time())}_{uuid.uuid4().hex[:8]}"
        staging_dir = self._registry.base_dir / "staging" / staging_name
        staging_dir.parent.mkdir(parents=True, exist_ok=True)
        try:
            await self._git_clone_plugin(url, staging_dir, ref=source.ref, sha=source.sha)
        except Exception:
            if staging_dir.exists():
                shutil.rmtree(staging_dir, ignore_errors=True)
            raise
        return staging_dir, True

    # ── 解析 ──

    def resolve_plugin(self, plugin_name: str) -> tuple[str, PluginEntry]:
        """在已注册 marketplace 中查找插件。

        支持两种语法：
        - 裸名 ``"test-plugin"`` — 按注册顺序 first-match
        - 全限定名 ``"test-plugin@marketplace"`` — 只在指定 marketplace 中查找

        Raises:
            ValueError: 插件未找到。
        """
        if "@" in plugin_name:
            name, mkt_name = plugin_name.rsplit("@", 1)
            entries = self._mkt_mgr.list_available_plugins(mkt_name)
            for entry in entries:
                if entry.name == name:
                    return mkt_name, entry
            raise ValueError(f"Plugin '{name}' not found in marketplace '{mkt_name}'")

        all_plugins = self._mkt_mgr.list_all_available_plugins()
        for mkt_name, entries in all_plugins.items():
            for entry in entries:
                if entry.name == plugin_name:
                    return mkt_name, entry
        raise ValueError(f"Plugin '{plugin_name}' not found in any registered marketplace")

    # ── 安装 ──

    async def install(
        self,
        plugin_name: str,
        scope: Literal["user", "local"] = "user",
        project_path: Path | None = None,
    ) -> InstalledPlugin:
        """安装插件：解析 → 拷贝到版本化 cache → 写入 registry。

        Args:
            plugin_name: 插件名（裸名或 ``name@marketplace``）。
            scope: 安装范围（``"user"`` 或 ``"local"``）。
            project_path: ``scope="local"`` 时的项目路径。

        Returns:
            已安装插件的元数据。

        Raises:
            ValueError: 插件未找到。
        """
        mkt_name, entry = self.resolve_plugin(plugin_name)

        # 解析 source → 本地目录
        marketplaces = self._registry.list_marketplaces()
        mkt_info = marketplaces[mkt_name]
        source_dir, is_staging = await self._resolve_plugin_source(mkt_info, entry.source)

        try:
            # 读取 plugin.json 获取版本号
            try:
                manifest_path = source_dir / ".claude-plugin" / "plugin.json"
                manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
                version = manifest["version"]
            except FileNotFoundError:
                raise ValueError(
                    f"Plugin '{entry.name}' has no plugin.json at "
                    f"{source_dir / '.claude-plugin' / 'plugin.json'}"
                )
            except (json.JSONDecodeError, KeyError) as e:
                raise ValueError(f"Plugin '{entry.name}' has invalid plugin.json: {e}")

            # Blocklist check
            bare_name = entry.name
            plugin_key = f"{bare_name}@{mkt_name}"
            if self._registry.is_blocked(plugin_key):
                raise ValueError(f"Plugin '{plugin_key}' is blocked and cannot be installed")

            # Duplicate install guard: remove existing entry for same scope before re-installing
            installed = self._registry.list_installed()
            if plugin_key in installed:
                existing = [
                    e for e in installed[plugin_key]
                    if e.scope == scope and e.project_path == project_path
                ]
                if existing:
                    self._registry.remove_installed(plugin_key, scope=scope, project_path=project_path)

            # 拷贝到 cache 目录
            cache_dir = self._registry.base_dir / "cache" / mkt_name / bare_name / version
            if cache_dir.exists():
                shutil.rmtree(cache_dir)
            shutil.copytree(source_dir, cache_dir)
        finally:
            # 清理 staging 临时目录
            if is_staging and source_dir.exists():
                shutil.rmtree(source_dir, ignore_errors=True)

        now = datetime.now(timezone.utc).isoformat()
        installed = InstalledPlugin(
            scope=scope,
            install_path=cache_dir,
            version=version,
            installed_at=now,
            last_updated=now,
            project_path=project_path,
        )

        self._registry.add_installed(plugin_key, installed)
        logger.info("installed plugin %s (v%s, scope=%s)", plugin_key, version, scope)
        return installed

    # ── 卸载 ──

    async def uninstall(
        self,
        plugin_key: str,
        scope: Literal["user", "local"] = "user",
        project_path: Path | None = None,
    ) -> None:
        """从 registry 移除已安装插件（cache 目录保留以便重装）。"""
        self._registry.remove_installed(plugin_key, scope=scope, project_path=project_path)
        logger.info("uninstalled plugin %s (scope=%s)", plugin_key, scope)

    # ── 更新 ──

    async def update(self, plugin_key: str) -> InstalledPlugin:
        """Update an installed plugin to the latest version from its marketplace.

        Pulls the latest marketplace changes, then re-copies the plugin source
        to a new versioned cache directory.
        """
        installed = self._registry.list_installed()
        if plugin_key not in installed:
            raise ValueError(f"Plugin '{plugin_key}' is not installed")

        # Parse marketplace name from key
        parts = plugin_key.rsplit("@", 1)
        if len(parts) != 2:
            raise ValueError(f"Invalid plugin key: '{plugin_key}' (expected 'name@marketplace')")
        plugin_name, mkt_name = parts

        # Update marketplace first
        await self._mkt_mgr.update(mkt_name)

        # Re-resolve to get latest version
        mkt_info = self._registry.list_marketplaces().get(mkt_name)
        if not mkt_info:
            raise ValueError(f"Marketplace '{mkt_name}' not found")

        plugins = self._mkt_mgr.list_available_plugins(mkt_name)
        entry = next((p for p in plugins if p.name == plugin_name), None)
        if not entry:
            raise ValueError(
                f"Plugin '{plugin_name}' no longer available in marketplace '{mkt_name}'"
            )

        # 解析 source → 本地目录
        source_dir, is_staging = await self._resolve_plugin_source(mkt_info, entry.source)

        try:
            manifest_path = source_dir / ".claude-plugin" / "plugin.json"
            manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
            new_version = manifest["version"]

            # Copy to new cache dir
            cache_dir = self._registry.base_dir / "cache" / mkt_name / plugin_name / new_version
            if cache_dir.exists():
                shutil.rmtree(cache_dir)
            shutil.copytree(source_dir, cache_dir)
        finally:
            if is_staging and source_dir.exists():
                shutil.rmtree(source_dir, ignore_errors=True)

        # Update registry entries (for all scopes of this plugin)
        for old_entry in installed[plugin_key]:
            self._registry.remove_installed(
                plugin_key, scope=old_entry.scope, project_path=old_entry.project_path
            )
            new_entry = InstalledPlugin(
                scope=old_entry.scope,
                install_path=cache_dir,
                version=new_version,
                installed_at=old_entry.installed_at,
                last_updated=datetime.now(timezone.utc).isoformat(),
                project_path=old_entry.project_path,
                enabled=old_entry.enabled,
            )
            self._registry.add_installed(plugin_key, new_entry)

        logger.info("Updated plugin %s to version %s", plugin_key, new_version)
        # Return the first updated entry
        return self._registry.list_installed()[plugin_key][0]

    # ── 启用 / 禁用 ──

    def enable(
        self,
        plugin_key: str,
        scope: Literal["user", "local"] = "user",
        project_path: Path | None = None,
    ) -> None:
        """启用插件。"""
        self._registry.set_enabled(plugin_key, scope=scope, enabled=True, project_path=project_path)
        logger.info("enabled plugin %s (scope=%s)", plugin_key, scope)

    def disable(
        self,
        plugin_key: str,
        scope: Literal["user", "local"] = "user",
        project_path: Path | None = None,
    ) -> None:
        """禁用插件。"""
        self._registry.set_enabled(plugin_key, scope=scope, enabled=False, project_path=project_path)
        logger.info("disabled plugin %s (scope=%s)", plugin_key, scope)
