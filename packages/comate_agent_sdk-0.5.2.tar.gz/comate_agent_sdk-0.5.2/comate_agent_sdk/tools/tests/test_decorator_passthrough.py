import unittest

from mcp.types import CallToolResult, TextContent

from comate_agent_sdk.tools.decorator import tool


@tool("test tool")
async def passthrough_tool(x: int) -> CallToolResult:
    return CallToolResult(
        content=[TextContent(type="text", text=str(x))],
    )


@tool("error tool")
async def error_tool() -> CallToolResult:
    return CallToolResult(
        content=[TextContent(type="text", text="bad")],
        isError=True,
    )


@tool("legacy tool")
async def legacy_tool(x: int) -> str:
    return f"result: {x}"


class TestCallToolResultPassthrough(unittest.IsolatedAsyncioTestCase):
    async def test_call_tool_result_passes_through(self):
        """CallToolResult returned by handler is NOT serialized."""
        result = await passthrough_tool.execute(x=42)
        self.assertIsInstance(result, CallToolResult)
        self.assertEqual(result.content[0].text, "42")
        self.assertFalse(result.isError)

    async def test_call_tool_result_preserves_is_error(self):
        """isError=True passes through unchanged."""
        result = await error_tool.execute()
        self.assertIsInstance(result, CallToolResult)
        self.assertTrue(result.isError)

    async def test_legacy_return_still_serialized(self):
        """Non-CallToolResult returns still go through _serialize_result."""
        result = await legacy_tool.execute(x=1)
        self.assertIsInstance(result, str)
        self.assertEqual(result, "result: 1")
