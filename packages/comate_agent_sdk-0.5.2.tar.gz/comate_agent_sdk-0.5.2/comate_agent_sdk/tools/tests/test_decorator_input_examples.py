from comate_agent_sdk.tools.decorator import tool


def test_tool_decorator_passes_input_examples_to_definition() -> None:
    examples = [{"query": "hello"}, {"query": "world"}]

    @tool("Search", input_examples=examples)
    async def search(query: str) -> str:
        return query

    assert search.input_examples == examples
    defn = search.definition
    assert defn.input_examples == examples


def test_tool_decorator_no_examples_defaults_none() -> None:
    @tool("Search")
    async def search(query: str) -> str:
        return query

    assert search.input_examples is None
    assert search.definition.input_examples is None
