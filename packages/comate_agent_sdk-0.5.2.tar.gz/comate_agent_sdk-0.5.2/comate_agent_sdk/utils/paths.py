from __future__ import annotations

from os import PathLike
from pathlib import Path
from typing import TypeAlias

PathInput: TypeAlias = str | PathLike[str]


class PathInputError(ValueError):
    """Raised when a public path-like input cannot be normalized."""


def is_path_input(value: object) -> bool:
    return isinstance(value, (str, PathLike))


def normalize_path_input(
    value: PathInput | None,
    *,
    field_name: str = "path",
) -> Path:
    if value is None:
        raise PathInputError(f"{field_name} is required")

    if not is_path_input(value):
        raise PathInputError(
            f"invalid {field_name} type: expected str | os.PathLike, got {type(value).__name__}"
        )

    try:
        return Path(value).expanduser().resolve()
    except Exception as exc:
        raise PathInputError(f"invalid {field_name}: {value!r}") from exc
