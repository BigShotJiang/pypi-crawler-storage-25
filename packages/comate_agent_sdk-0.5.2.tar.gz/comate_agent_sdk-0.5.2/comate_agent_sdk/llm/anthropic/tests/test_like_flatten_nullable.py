"""ChatAnthropicLike 对弱模型的 anyOf nullable 扁平化测试。

MiniMax 等 Anthropic-like 模型无法正确处理 anyOf: [{real_type}, {type: null}] 模式，
总是 fallback 到 null。ChatAnthropicLike 的 _serialize_tools 应该将此模式扁平化为
纯 real_type，去掉 null variant 和 default: null。
"""

from comate_agent_sdk.llm.anthropic.like import ChatAnthropicLike
from comate_agent_sdk.llm.base import ToolDefinition


def _make_adapter() -> ChatAnthropicLike:
    adapter = ChatAnthropicLike(model="test")
    adapter.max_cached_tool_definitions = 0
    return adapter


def test_anyof_enum_null_flattened_to_enum() -> None:
    """anyOf: [{enum, type: string}, {type: null}] → {enum, type: string}"""
    tool = ToolDefinition(
        name="TaskUpdate",
        description="Update a task",
        parameters={
            "type": "object",
            "properties": {
                "task_id": {"type": "string", "description": "ID"},
                "status": {
                    "anyOf": [
                        {"enum": ["pending", "in_progress", "completed"], "type": "string"},
                        {"type": "null"},
                    ],
                    "default": None,
                    "description": "New status",
                },
            },
            "required": ["task_id"],
            "additionalProperties": False,
        },
    )
    result = _make_adapter()._serialize_tools([tool])
    status = result[0]["input_schema"]["properties"]["status"]

    # anyOf should be gone
    assert "anyOf" not in status
    # Should be flattened to the real type
    assert status["type"] == "string"
    assert status["enum"] == ["pending", "in_progress", "completed"]
    # default: null should be removed
    assert "default" not in status
    # description preserved
    assert status["description"] == "New status"


def test_anyof_string_null_flattened_to_string() -> None:
    """anyOf: [{type: string}, {type: null}] → {type: string}"""
    tool = ToolDefinition(
        name="Test",
        description="test",
        parameters={
            "type": "object",
            "properties": {
                "name": {
                    "anyOf": [{"type": "string"}, {"type": "null"}],
                    "default": None,
                    "description": "A name",
                },
            },
            "required": [],
        },
    )
    result = _make_adapter()._serialize_tools([tool])
    name = result[0]["input_schema"]["properties"]["name"]

    assert "anyOf" not in name
    assert name["type"] == "string"
    assert "default" not in name
    assert name["description"] == "A name"


def test_anyof_array_null_flattened_to_array() -> None:
    """anyOf: [{type: array, items: ...}, {type: null}] → {type: array, items: ...}"""
    tool = ToolDefinition(
        name="Test",
        description="test",
        parameters={
            "type": "object",
            "properties": {
                "tags": {
                    "anyOf": [
                        {"type": "array", "items": {"type": "string"}},
                        {"type": "null"},
                    ],
                    "default": None,
                },
            },
            "required": [],
        },
    )
    result = _make_adapter()._serialize_tools([tool])
    tags = result[0]["input_schema"]["properties"]["tags"]

    assert "anyOf" not in tags
    assert tags["type"] == "array"
    assert tags["items"] == {"type": "string"}
    assert "default" not in tags


def test_non_nullable_anyof_preserved() -> None:
    """anyOf with >2 variants or no null variant is NOT flattened."""
    tool = ToolDefinition(
        name="Test",
        description="test",
        parameters={
            "type": "object",
            "properties": {
                "value": {
                    "anyOf": [{"type": "string"}, {"type": "integer"}],
                    "description": "Union type",
                },
            },
            "required": ["value"],
        },
    )
    result = _make_adapter()._serialize_tools([tool])
    value = result[0]["input_schema"]["properties"]["value"]

    # Should be preserved as-is
    assert "anyOf" in value
    assert len(value["anyOf"]) == 2


def test_plain_type_unchanged() -> None:
    """Fields without anyOf are not affected."""
    tool = ToolDefinition(
        name="Test",
        description="test",
        parameters={
            "type": "object",
            "properties": {
                "id": {"type": "string", "description": "ID"},
                "count": {"type": "integer", "default": 0},
            },
            "required": ["id"],
        },
    )
    result = _make_adapter()._serialize_tools([tool])
    props = result[0]["input_schema"]["properties"]

    assert props["id"] == {"type": "string", "description": "ID"}
    assert props["count"] == {"type": "integer", "default": 0}


def test_real_anthropic_not_affected() -> None:
    """ChatAnthropic (real Claude) should NOT flatten anyOf."""
    from comate_agent_sdk.llm.anthropic.chat import ChatAnthropic

    adapter = ChatAnthropic(model="test")
    adapter.max_cached_tool_definitions = 0
    tool = ToolDefinition(
        name="Test",
        description="test",
        parameters={
            "type": "object",
            "properties": {
                "status": {
                    "anyOf": [
                        {"enum": ["a", "b"], "type": "string"},
                        {"type": "null"},
                    ],
                    "default": None,
                },
            },
            "required": [],
        },
    )
    result = adapter._serialize_tools([tool])
    status = result[0]["input_schema"]["properties"]["status"]

    # Real Claude keeps anyOf intact
    assert "anyOf" in status
    assert status["default"] is None
