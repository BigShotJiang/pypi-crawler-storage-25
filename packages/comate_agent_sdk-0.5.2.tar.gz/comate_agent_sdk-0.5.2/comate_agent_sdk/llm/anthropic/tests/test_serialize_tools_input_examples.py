from comate_agent_sdk.llm.base import ToolDefinition
from comate_agent_sdk.llm.anthropic.chat import ChatAnthropic


def test_serialize_tools_includes_input_examples() -> None:
    adapter = ChatAnthropic(model="test")
    adapter.max_cached_tool_definitions = 0

    examples = [{"task_id": "1", "status": "completed"}]
    tool = ToolDefinition(
        name="TaskUpdate",
        description="Update a task",
        parameters={"type": "object", "properties": {"task_id": {"type": "string"}}},
        input_examples=examples,
    )
    result = adapter._serialize_tools([tool])
    assert len(result) == 1
    assert result[0].get("input_examples") == examples


def test_serialize_tools_omits_input_examples_when_none() -> None:
    adapter = ChatAnthropic(model="test")
    adapter.max_cached_tool_definitions = 0

    tool = ToolDefinition(
        name="Read",
        description="Read a file",
        parameters={"type": "object", "properties": {"path": {"type": "string"}}},
    )
    result = adapter._serialize_tools([tool])
    assert len(result) == 1
    assert "input_examples" not in result[0]
