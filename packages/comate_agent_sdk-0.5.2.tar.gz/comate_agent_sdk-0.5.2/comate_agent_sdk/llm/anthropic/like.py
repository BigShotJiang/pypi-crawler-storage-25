from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from anthropic.types import ToolParam

from comate_agent_sdk.llm.anthropic.chat import ChatAnthropic
from comate_agent_sdk.llm.base import ToolDefinition


def _flatten_anyof_nullable(schema: dict[str, Any]) -> None:
    """递归扁平化 anyOf nullable 模式，适配不支持 anyOf 的弱模型。

    将 anyOf: [{real_type}, {type: null}] 简化为 real_type，
    同时移除 default: null（避免模型 fallback 到 null）。

    仅处理恰好两个 variant 且其中一个是 {type: null} 的 anyOf，
    其他 anyOf（union type 等）保持不变。
    """
    properties = schema.get("properties")
    if not isinstance(properties, dict):
        return

    for prop_schema in properties.values():
        if not isinstance(prop_schema, dict):
            continue

        any_of = prop_schema.get("anyOf")
        if isinstance(any_of, list) and len(any_of) == 2:
            null_variants = [v for v in any_of if isinstance(v, dict) and v.get("type") == "null"]
            real_variants = [v for v in any_of if isinstance(v, dict) and v.get("type") != "null"]

            if len(null_variants) == 1 and len(real_variants) == 1:
                real = real_variants[0]
                # 保留外层的 description 等字段，合并 real variant
                del prop_schema["anyOf"]
                prop_schema.pop("default", None)
                prop_schema.update(real)

        # 递归处理嵌套对象
        if prop_schema.get("type") == "object":
            _flatten_anyof_nullable(prop_schema)
        items = prop_schema.get("items")
        if isinstance(items, dict):
            _flatten_anyof_nullable(items)


@dataclass
class ChatAnthropicLike(ChatAnthropic):
    """Base class for providers using the Anthropic API protocol but not strict Claude.

    Analogous to ChatOpenAILike — a thin shell that acts as a protocol marker.
    Provider-specific quirks (e.g. missing signature, custom fields) belong
    in each concrete subclass, not here.

    Schema adaptation: overrides _serialize_tools to flatten anyOf nullable
    patterns that weaker models (MiniMax, etc.) cannot handle correctly.
    """

    model: str

    def _serialize_tools(self, tools: list[ToolDefinition]) -> list[ToolParam]:
        """Serialize tools with anyOf nullable flattening for weaker models."""
        result = super()._serialize_tools(tools)
        for tool_param in result:
            schema = tool_param.get("input_schema")
            if isinstance(schema, dict):
                _flatten_anyof_nullable(schema)
        return result
