from __future__ import annotations

import asyncio
import logging
import random
from collections.abc import Mapping
from typing import Any

from comate_agent_sdk.llm.base import BaseChatModel
from comate_agent_sdk.llm.exceptions import ModelProviderError, ModelRateLimitError
from comate_agent_sdk.llm.messages import BaseMessage, SystemMessage
from comate_agent_sdk.llm.views import ChatInvokeCompletion
from comate_agent_sdk.tokens.service import TokenCost

logger = logging.getLogger("comate_agent_sdk.llm.side_query")

_RETRYABLE_STATUS_CODES = frozenset({500, 502, 503, 504, 529})
_RETRY_BASE_DELAY_SECONDS = 1.0
_RETRY_MAX_DELAY_SECONDS = 60.0
_RETRY_JITTER_RATIO = 0.1


class SideQueryError(Exception):
    """Base exception for side query failures."""


class SideQueryCancelledError(SideQueryError):
    """Raised when a side query is cancelled via the provided cancel event."""


def _validate_source(source: str) -> str:
    normalized = str(source).strip()
    if not normalized:
        raise SideQueryError("side_query source must be a non-empty string")
    return normalized


def _build_messages(
    *,
    messages: list[BaseMessage],
    system: str | None,
) -> list[BaseMessage]:
    if system is None:
        return list(messages)
    return [SystemMessage(content=system), *messages]


def _compute_retry_delay(attempt: int) -> float:
    delay = min(_RETRY_BASE_DELAY_SECONDS * (2**attempt), _RETRY_MAX_DELAY_SECONDS)
    return delay + random.uniform(0, delay * _RETRY_JITTER_RATIO)


def _is_retryable_provider_error(error: ModelProviderError) -> bool:
    return error.status_code in _RETRYABLE_STATUS_CODES


def _is_retryable_transient_error(error: Exception) -> bool:
    if isinstance(error, (asyncio.TimeoutError, TimeoutError, ConnectionError)):
        return True
    error_message = str(error).lower()
    return "timeout" in error_message or "connection" in error_message or "connect" in error_message


def _raise_if_cancelled(cancel_event: asyncio.Event | None) -> None:
    if cancel_event is not None and cancel_event.is_set():
        raise SideQueryCancelledError("side query cancelled")


async def side_query(
    llm: BaseChatModel,
    *,
    messages: list[BaseMessage],
    source: str,
    system: str | None = None,
    output_format: Mapping[str, Any] | None = None,
    token_cost: TokenCost | None = None,
    level: str | None = None,
    cancel_event: asyncio.Event | None = None,
    max_retries: int = 2,
) -> ChatInvokeCompletion:
    """Run a narrow one-shot LLM transport for SDK-internal side queries.

    This primitive is intended for future memory-side classification/selection work.
    It does not build runtime/context state, does not execute tools, and does not
    own any parsing policy such as strict JSON validation or repair.
    """
    normalized_source = _validate_source(source)
    if max_retries < 0:
        raise SideQueryError("side_query max_retries must be >= 0")

    invoke_messages = _build_messages(messages=messages, system=system)
    total_attempts = max_retries + 1

    for attempt in range(total_attempts):
        _raise_if_cancelled(cancel_event)
        try:
            response = await llm.ainvoke(
                messages=invoke_messages,
                output_format=output_format,
                cancel_event=cancel_event,
            )
            if response.usage is not None and token_cost is not None:
                token_cost.add_usage(
                    str(llm.model),
                    response.usage,
                    level=level,
                    source=normalized_source,
                )
            return response
        except asyncio.CancelledError as exc:
            if cancel_event is not None or str(exc) == "llm_cancel":
                raise SideQueryCancelledError("side query cancelled") from exc
            raise
        except ModelRateLimitError as exc:
            if attempt >= total_attempts - 1:
                raise
            delay = _compute_retry_delay(attempt)
            logger.warning(
                "Side query hit rate limit; retrying in %.1fs (attempt %s/%s)",
                delay,
                attempt + 1,
                total_attempts,
            )
            await asyncio.sleep(delay)
        except ModelProviderError as exc:
            if not _is_retryable_provider_error(exc) or attempt >= total_attempts - 1:
                raise
            delay = _compute_retry_delay(attempt)
            logger.warning(
                "Side query hit retryable provider error %s; retrying in %.1fs (attempt %s/%s)",
                exc.status_code,
                delay,
                attempt + 1,
                total_attempts,
            )
            await asyncio.sleep(delay)
        except Exception as exc:
            if not _is_retryable_transient_error(exc) or attempt >= total_attempts - 1:
                raise
            delay = _compute_retry_delay(attempt)
            logger.warning(
                "Side query hit transient error; retrying in %.1fs (attempt %s/%s): %s",
                delay,
                attempt + 1,
                total_attempts,
                exc,
            )
            await asyncio.sleep(delay)

    raise RuntimeError("side_query retry loop exited without returning or raising")
