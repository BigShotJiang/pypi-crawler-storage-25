import re
from dataclasses import dataclass

from comate_agent_sdk.llm.anthropic.like import ChatAnthropicLike
from comate_agent_sdk.llm.messages import (
    ContentPartRedactedThinkingParam,
    ContentPartTextParam,
    ContentPartThinkingParam,
)
from comate_agent_sdk.llm.views import ChatInvokeUsage
from comate_agent_sdk.tokens.custom_pricing import (
    resolve_max_input_tokens_from_custom_pricing,
)

_MINIMAX_TOOL_CALL_BLOCK_RE = re.compile(
    r"<minimax:tool_call\b[^>]*>.*?</minimax:tool_call>",
    re.IGNORECASE | re.DOTALL,
)
_MINIMAX_TOOL_CALL_TAG_RE = re.compile(
    r"</?minimax:tool_call\b[^>]*>",
    re.IGNORECASE,
)
_MINIMAX_TOOL_CALL_TRAILING_FRAGMENT_RE = re.compile(
    r"(^|\n)\s*[A-Za-z_][A-Za-z0-9_:-]{0,31}\s*</minimax:tool_call>\s*(?=\n|$)",
    re.IGNORECASE,
)
_BLANK_LINE_RE = re.compile(r"\n{3,}")


@dataclass
class ChatMiniMax(ChatAnthropicLike):
    """MiniMax Anthropic-compatible provider.

    MiniMax-specific quirks vs standard Claude:
    - thinking blocks lack ``signature`` field → use duck-typing instead of isinstance
    - no prompt-caching beta header
    """

    prompt_cache_beta: str | None = None  # MiniMax 不支持 Anthropic prompt-caching beta

    @property
    def provider(self) -> str:
        return "minimax"

    def get_context_window(self) -> int | None:
        """Resolve MiniMax context window from custom pricing data."""
        return resolve_max_input_tokens_from_custom_pricing(str(self.model))

    def _extract_thinking(self, response):
        """MiniMax thinking blocks have no ``signature``, so isinstance(ThinkingBlock) fails.
        Duck-type via block.type instead."""
        thinking_parts, redacted_parts = [], []
        for block in response.content:
            t = getattr(block, "type", None)
            if t == "thinking":
                thinking_parts.append(getattr(block, "thinking", "") or "")
            elif t == "redacted_thinking":
                redacted_parts.append(getattr(block, "data", "") or "")
        return (
            "\n".join(thinking_parts) or None,
            "\n".join(redacted_parts) or None,
        )

    def _get_usage(self, response) -> ChatInvokeUsage | None:
        """MiniMax usage: true prompt = input + cache_read + cache_creation."""
        u = response.usage
        cache_read = getattr(u, "cache_read_input_tokens", None) or 0
        cache_creation = getattr(u, "cache_creation_input_tokens", None) or 0
        input_tokens = u.input_tokens
        output_tokens = u.output_tokens
        total_prompt = input_tokens + cache_read + cache_creation
        return ChatInvokeUsage(
            prompt_tokens=total_prompt,
            completion_tokens=output_tokens,
            total_tokens=total_prompt + output_tokens,
            prompt_cached_tokens=cache_read or None,
            prompt_cache_creation_tokens=cache_creation or None,
            prompt_image_tokens=None,
        )

    @staticmethod
    def _sanitize_text_fragment(text: str) -> str:
        """Remove MiniMax tool-call protocol residue that may leak into text blocks."""
        cleaned = str(text or "")
        if "minimax:tool_call" not in cleaned.lower():
            return cleaned

        cleaned = _MINIMAX_TOOL_CALL_BLOCK_RE.sub("", cleaned)
        cleaned = _MINIMAX_TOOL_CALL_TRAILING_FRAGMENT_RE.sub(r"\1", cleaned)
        cleaned = _MINIMAX_TOOL_CALL_TAG_RE.sub("", cleaned)
        cleaned = _BLANK_LINE_RE.sub("\n\n", cleaned)
        return cleaned.strip()

    def _extract_text_content(self, response) -> str | None:
        """MiniMax may leak XML-like tool protocol tags into text blocks."""
        if not getattr(response, "content", None):
            return None

        text_parts: list[str] = []
        for block in response.content:
            if getattr(block, "type", None) != "text":
                continue
            cleaned = self._sanitize_text_fragment(getattr(block, "text", "") or "")
            if cleaned:
                text_parts.append(cleaned)

        return "\n".join(text_parts) if text_parts else None

    @staticmethod
    def _build_structured_content(response):
        """Same duck-typing fix; fall back to empty string for missing ``signature``."""
        if not response.content:
            return None
        blocks = []
        for block in response.content:
            t = getattr(block, "type", None)
            if t == "text":
                cleaned = ChatMiniMax._sanitize_text_fragment(getattr(block, "text", "") or "")
                if cleaned:
                    blocks.append(ContentPartTextParam(text=cleaned))
            elif t == "thinking":
                blocks.append(
                    ContentPartThinkingParam(
                        thinking=getattr(block, "thinking", ""),
                        signature=getattr(block, "signature", "") or "",
                    )
                )
            elif t == "redacted_thinking":
                blocks.append(
                    ContentPartRedactedThinkingParam(data=getattr(block, "data", ""))
                )
        return blocks or None
