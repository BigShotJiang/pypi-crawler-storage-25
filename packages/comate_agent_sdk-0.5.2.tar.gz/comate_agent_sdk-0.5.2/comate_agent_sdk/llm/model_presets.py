"""Model-level presets: thinking/reasoning + generation parameters.

Maps model names to ModelPreset, which determines:
- whether the model should send thinking parameters to the API
- how to handle thinking blocks in message history
- optional generation parameter overrides (temperature, top_p, etc.)

Matching order (first match wins):
1. Exact match
2. Suffix match  (e.g. "*-thinking")
3. Prefix match  (e.g. "gemini-2.5-flash*")
4. Default       (supports_thinking=False, all generation params None)
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Literal


@dataclass(frozen=True)
class ModelPreset:
    supports_thinking: bool = False
    """Whether this model uses extended thinking/reasoning."""

    budget_tokens: int | None = None
    """Anthropic/Google: token budget to send in the thinking param.
    None  = do not send a thinking param (model self-thinks, e.g. MiniMax/DeepSeek).
    int   = send thinking={type:enabled, budget_tokens:X} (Claude -thinking series).
    0     = explicitly disable Google thinking (gemini-2.5-flash default)."""

    effort: Literal["low", "medium", "high"] | None = None
    """OpenAI: reasoning_effort level. None = not applicable."""

    openai_extra_body: dict | None = None
    """OpenAI-compatible providers: extra_body params merged into the request.
    Used for providers that enable thinking via non-standard extra_body fields
    (e.g. GLM-4.7: {"thinking": {"type": "enabled"}}).
    The dict is shallow-merged into extra_body alongside other cache params."""

    history_policy: Literal["preserve", "strip", "auto"] = "auto"
    """How to handle thinking blocks in serialized history.
    preserve = always keep (MiniMax-M2.5 — chain must not break).
    strip    = always remove (reserved; DeepSeek already handled by serializer).
    auto     = strip when supports_thinking=False, preserve otherwise."""

    drop_temperature_with_thinking: bool = True
    """Whether to drop temperature when thinking is enabled.
    True  = Anthropic Claude behavior (API error if temperature is sent with thinking).
    False = provider allows temperature alongside thinking (e.g. MiniMax-M2.5)."""

    # ── Generation parameter overrides ──────────────────────────────────────
    # None means "do not override; use Chat* class default".
    temperature: float | None = None
    top_p: float | None = None
    top_k: int | None = None
    frequency_penalty: float | None = None
    max_tokens: int | None = None


# ---------------------------------------------------------------------------
# Preset table
# ---------------------------------------------------------------------------
# Keys:
#   exact strings  → exact match
#   starts with "~" → suffix match (strip "~" prefix, match model ending)
#   starts with "^" → prefix match (strip "^" prefix, match model beginning)
# ---------------------------------------------------------------------------

_PRESETS: dict[str, ModelPreset] = {
    # ── Suffix: Claude -thinking virtual model names ────────────────────────
    "~-thinking": ModelPreset(
        supports_thinking=True,
        budget_tokens=4096,
        history_policy="auto",
    ),

    "gpt-5.2": ModelPreset(
        supports_thinking=True,
        effort="medium",
        history_policy="auto"
    ),
    # ── Exact: MiniMax ───────────────────────────────────────────────────────
    "MiniMax-M2.5": ModelPreset(
        supports_thinking=True,
        budget_tokens=8192,   # send thinking param; model returns thinking blocks
        history_policy="preserve",
        drop_temperature_with_thinking=False,  # MiniMax allows temperature with thinking
        temperature=1.0,
        top_p=0.95,
        top_k=40,  # note: ignored by MiniMax Anthropic-compat API, harmless
    ),

    "glm-4.7": ModelPreset(
        supports_thinking=True,
        budget_tokens=8192,          # Anthropic 协议: send thinking={type:enabled, budget_tokens:X}
        openai_extra_body={"thinking": {"type": "enabled"}},  # OpenAI 兼容协议: extra_body 注入
        history_policy="strip",
    ),

    "glm-5": ModelPreset(
        supports_thinking=True,
        budget_tokens=8192,          # Anthropic 协议: send thinking={type:enabled, budget_tokens:X}
        openai_extra_body={"thinking": {"type": "enabled"}},  # OpenAI 兼容协议: extra_body 注入
        history_policy="strip",
    ),

    # ── Prefix: Gemini flash (disable thinking by default) ──────────────────
    "^gemini-2.5-flash": ModelPreset(
        supports_thinking=False,
        budget_tokens=0,      # send thinking_budget=0 to explicitly disable
        history_policy="auto",
    ),
    # ── Prefix: Gemini Pro (enable thinking) ────────────────────────────────
    "^gemini-2.5-pro": ModelPreset(
        supports_thinking=True,
        budget_tokens=16_000,
        history_policy="auto",
    ),
    # ── Prefix: gemini-flash-latest / gemini-flash-lite-latest ──────────────
    "^gemini-flash": ModelPreset(
        supports_thinking=False,
        budget_tokens=0,
        history_policy="auto",
    ),
    # ── Exact: DeepSeek reasoner ─────────────────────────────────────────────
    "deepseek-reasoner": ModelPreset(
        supports_thinking=True,
        budget_tokens=None,
        history_policy="strip",  # serializer already handles; preserve as strip
    ),
    # ── Exact: OpenAI reasoning models ───────────────────────────────────────
    "o1": ModelPreset(supports_thinking=True, effort="medium", history_policy="auto"),
    "o1-pro": ModelPreset(supports_thinking=True, effort="medium", history_policy="auto"),
    "o3": ModelPreset(supports_thinking=True, effort="medium", history_policy="auto"),
    "o3-mini": ModelPreset(supports_thinking=True, effort="medium", history_policy="auto"),
    "o3-pro": ModelPreset(supports_thinking=True, effort="medium", history_policy="auto"),
    "o4-mini": ModelPreset(supports_thinking=True, effort="medium", history_policy="auto"),
}

_DEFAULT_PRESET = ModelPreset()  # supports_thinking=False, everything None/auto


def get_model_preset(model: str) -> ModelPreset:
    """Return the ModelPreset for *model*.

    Lookup order:
    1. Exact match in _PRESETS
    2. Suffix match  (~<suffix> keys)
    3. Prefix match  (^<prefix> keys)
    4. Default preset (supports_thinking=False)
    """
    # 1. Exact
    if model in _PRESETS:
        return _PRESETS[model]

    # 2. Suffix
    for key, preset in _PRESETS.items():
        if key.startswith("~") and model.endswith(key[1:]):
            return preset

    # 3. Prefix
    for key, preset in _PRESETS.items():
        if key.startswith("^") and model.startswith(key[1:]):
            return preset

    return _DEFAULT_PRESET


def resolve_api_model_name(model: str) -> str:
    """Strip virtual suffixes before sending model name to the API.

    Currently only strips the ``-thinking`` suffix used for Claude thinking
    variants (e.g. ``claude-sonnet-4-5-thinking`` → ``claude-sonnet-4-5``).
    """
    if model.endswith("-thinking"):
        return model[: -len("-thinking")]
    return model
