import asyncio
import inspect
import unittest
from collections.abc import Mapping
from unittest.mock import patch

from pydantic import BaseModel

from comate_agent_sdk.llm.exceptions import ModelProviderError, ModelRateLimitError
from comate_agent_sdk.llm.messages import BaseMessage, SystemMessage, UserMessage
from comate_agent_sdk.llm.side_query import (
    SideQueryCancelledError,
    SideQueryError,
    side_query,
)
from comate_agent_sdk.llm.views import ChatInvokeCompletion, ChatInvokeUsage
from comate_agent_sdk.tokens.service import TokenCost


class _SelectedMemories(BaseModel):
    ids: list[str]


class _FakeLLM:
    def __init__(self, responses: list[object]) -> None:
        self.model = "fake:model"
        self._responses = list(responses)
        self.calls: list[dict[str, object]] = []

    @property
    def provider(self) -> str:
        return "fake"

    @property
    def name(self) -> str:
        return self.model

    async def ainvoke(
        self,
        messages: list[BaseMessage],
        tools=None,
        tool_choice=None,
        **kwargs,
    ) -> ChatInvokeCompletion:
        self.calls.append(
            {
                "messages": list(messages),
                "tools": tools,
                "tool_choice": tool_choice,
                "kwargs": kwargs,
            }
        )
        result = self._responses.pop(0)
        if isinstance(result, Exception):
            raise result
        if isinstance(result, BaseException):
            raise result
        return result


class TestSideQuery(unittest.IsolatedAsyncioTestCase):
    async def test_raw_mode_returns_completion(self) -> None:
        llm = _FakeLLM([ChatInvokeCompletion(content="ok")])

        response = await side_query(
            llm,
            messages=[UserMessage(content="ping")],
            source="side_query:test",
        )

        self.assertIsInstance(response, ChatInvokeCompletion)
        self.assertEqual(response.content, "ok")

    async def test_system_param_prepends_system_message(self) -> None:
        llm = _FakeLLM([ChatInvokeCompletion(content="ok")])

        await side_query(
            llm,
            messages=[UserMessage(content="payload")],
            system="system prompt",
            source="side_query:test",
        )

        sent_messages = llm.calls[0]["messages"]
        assert isinstance(sent_messages, list)
        self.assertEqual(len(sent_messages), 2)
        self.assertIsInstance(sent_messages[0], SystemMessage)
        self.assertEqual(sent_messages[0].text, "system prompt")
        self.assertIsInstance(sent_messages[1], UserMessage)
        self.assertEqual(sent_messages[1].text, "payload")

    async def test_empty_source_raises_error(self) -> None:
        llm = _FakeLLM([ChatInvokeCompletion(content="ok")])

        with self.assertRaises(SideQueryError):
            await side_query(
                llm,
                messages=[UserMessage(content="payload")],
                source="  ",
            )

    async def test_output_format_passes_through_to_ainvoke(self) -> None:
        llm = _FakeLLM([ChatInvokeCompletion(content='{"ids":["m1"]}')])
        output_format = {
            "type": "json_schema",
            "schema": {"type": "object", "properties": {"ids": {"type": "array"}}},
        }

        await side_query(
            llm,
            messages=[UserMessage(content="payload")],
            output_format=output_format,
            source="side_query:memory_select",
        )

        kwargs = llm.calls[0]["kwargs"]
        assert isinstance(kwargs, dict)
        self.assertIs(kwargs["output_format"], output_format)

    async def test_retry_on_rate_limit(self) -> None:
        llm = _FakeLLM(
            [
                ModelRateLimitError("slow down"),
                ChatInvokeCompletion(content="ok"),
            ]
        )

        with patch("comate_agent_sdk.llm.side_query.asyncio.sleep") as sleep_mock:
            response = await side_query(
                llm,
                messages=[UserMessage(content="payload")],
                source="side_query:test",
            )

        self.assertEqual(response.content, "ok")
        self.assertEqual(len(llm.calls), 2)
        sleep_mock.assert_awaited_once()

    async def test_retry_on_retryable_provider_error(self) -> None:
        llm = _FakeLLM(
            [
                ModelProviderError("temporary", status_code=503),
                ChatInvokeCompletion(content="ok"),
            ]
        )

        with patch("comate_agent_sdk.llm.side_query.asyncio.sleep") as sleep_mock:
            response = await side_query(
                llm,
                messages=[UserMessage(content="payload")],
                source="side_query:test",
            )

        self.assertEqual(response.content, "ok")
        self.assertEqual(len(llm.calls), 2)
        sleep_mock.assert_awaited_once()

    async def test_retry_on_timeout_like_error(self) -> None:
        llm = _FakeLLM(
            [
                TimeoutError("request timeout"),
                ChatInvokeCompletion(content="ok"),
            ]
        )

        with patch("comate_agent_sdk.llm.side_query.asyncio.sleep") as sleep_mock:
            response = await side_query(
                llm,
                messages=[UserMessage(content="payload")],
                source="side_query:test",
            )

        self.assertEqual(response.content, "ok")
        self.assertEqual(len(llm.calls), 2)
        sleep_mock.assert_awaited_once()

    async def test_non_retryable_provider_error_bubbles(self) -> None:
        llm = _FakeLLM([ModelProviderError("bad request", status_code=400)])

        with self.assertRaises(ModelProviderError):
            await side_query(
                llm,
                messages=[UserMessage(content="payload")],
                source="side_query:test",
            )

        self.assertEqual(len(llm.calls), 1)

    async def test_cancel_event_pre_set_raises_cancelled_error(self) -> None:
        llm = _FakeLLM([ChatInvokeCompletion(content="ok")])
        cancel_event = asyncio.Event()
        cancel_event.set()

        with self.assertRaises(SideQueryCancelledError):
            await side_query(
                llm,
                messages=[UserMessage(content="payload")],
                source="side_query:test",
                cancel_event=cancel_event,
            )

        self.assertEqual(len(llm.calls), 0)

    async def test_cancelled_error_from_provider_maps_to_side_query_cancelled_error(
        self,
    ) -> None:
        llm = _FakeLLM([asyncio.CancelledError("llm_cancel")])
        cancel_event = asyncio.Event()

        with self.assertRaises(SideQueryCancelledError):
            await side_query(
                llm,
                messages=[UserMessage(content="payload")],
                source="side_query:test",
                cancel_event=cancel_event,
            )

    async def test_token_usage_records_exact_source_and_level(self) -> None:
        token_cost = TokenCost()
        llm = _FakeLLM(
            [
                ChatInvokeCompletion(
                    content="ok",
                    usage=ChatInvokeUsage(
                        prompt_tokens=10,
                        prompt_cached_tokens=0,
                        prompt_cache_creation_tokens=0,
                        prompt_image_tokens=0,
                        completion_tokens=5,
                        total_tokens=15,
                    ),
                )
            ]
        )

        await side_query(
            llm,
            messages=[UserMessage(content="payload")],
            source="side_query:memory_select",
            level="LOW",
            token_cost=token_cost,
        )

        self.assertEqual(len(token_cost.usage_history), 1)
        entry = token_cost.usage_history[0]
        self.assertEqual(entry.source, "side_query:memory_select")
        self.assertEqual(entry.level, "LOW")
        self.assertEqual(entry.usage.total_tokens, 15)

    def test_api_signature_stays_narrow(self) -> None:
        parameters = inspect.signature(side_query).parameters

        self.assertNotIn("tools", parameters)
        self.assertNotIn("tool_choice", parameters)
        self.assertNotIn("response_model", parameters)
        self.assertNotIn("max_tokens", parameters)
        self.assertNotIn("temperature", parameters)


class TestResponseFormatHelperContract(unittest.TestCase):
    def test_helper_is_available_for_side_query_callers(self) -> None:
        from comate_agent_sdk.llm.schema import build_response_format_from_model

        response_format = build_response_format_from_model(_SelectedMemories)

        self.assertIsInstance(response_format, Mapping)
        self.assertEqual(response_format["type"], "json_schema")
        schema = response_format["schema"]
        self.assertIn("ids", schema["properties"])
