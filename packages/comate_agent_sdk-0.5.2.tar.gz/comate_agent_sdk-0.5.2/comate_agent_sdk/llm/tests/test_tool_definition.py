from comate_agent_sdk.llm.base import ToolDefinition


def test_tool_definition_accepts_input_examples() -> None:
    defn = ToolDefinition(
        name="test",
        description="test tool",
        parameters={"type": "object", "properties": {}},
        input_examples=[{"key": "value"}],
    )
    assert defn.input_examples == [{"key": "value"}]


def test_tool_definition_input_examples_defaults_none() -> None:
    defn = ToolDefinition(
        name="test",
        description="test tool",
        parameters={"type": "object", "properties": {}},
    )
    assert defn.input_examples is None
