import unittest
from dataclasses import dataclass

from comate_agent_sdk.llm.messages import (
    ContentPartTextParam,
    ContentPartThinkingParam,
)
from comate_agent_sdk.llm.minimax.chat import ChatMiniMax


@dataclass
class _FakeBlock:
    type: str
    text: str = ""
    thinking: str = ""
    signature: str = ""
    data: str = ""


@dataclass
class _FakeResponse:
    content: list[_FakeBlock]


class TestChatMiniMax(unittest.TestCase):
    def setUp(self) -> None:
        self.chat = ChatMiniMax(model="MiniMax-M2.5")

    def test_extract_text_content_removes_tool_call_residue(self) -> None:
        response = _FakeResponse(
            content=[
                _FakeBlock(type="text", text="回答第一部分。\ncandidate  </minimax:tool_call>"),
                _FakeBlock(type="text", text="<minimax:tool_call>{\"name\":\"YieldTurn\"}</minimax:tool_call>"),
                _FakeBlock(type="text", text="继续补充第二部分。"),
            ]
        )

        content = self.chat._extract_text_content(response)

        self.assertEqual(content, "回答第一部分。\n继续补充第二部分。")
        self.assertNotIn("minimax:tool_call", content)
        self.assertNotIn("candidate", content)

    def test_extract_text_content_keeps_normal_text(self) -> None:
        response = _FakeResponse(
            content=[
                _FakeBlock(type="text", text="候选人回答得很好。"),
                _FakeBlock(type="text", text="问题2：请说明 asyncio 的使用方式。"),
            ]
        )

        content = self.chat._extract_text_content(response)

        self.assertEqual(content, "候选人回答得很好。\n问题2：请说明 asyncio 的使用方式。")

    def test_build_structured_content_sanitizes_text_blocks_only(self) -> None:
        response = _FakeResponse(
            content=[
                _FakeBlock(type="text", text="正常文本\ncandidate </minimax:tool_call>"),
                _FakeBlock(type="thinking", thinking="内部推理", signature=""),
            ]
        )

        blocks = self.chat._build_structured_content(response)

        self.assertIsNotNone(blocks)
        self.assertEqual(len(blocks), 2)
        self.assertIsInstance(blocks[0], ContentPartTextParam)
        self.assertEqual(blocks[0].text, "正常文本")
        self.assertIsInstance(blocks[1], ContentPartThinkingParam)
        self.assertEqual(blocks[1].thinking, "内部推理")


if __name__ == "__main__":
    unittest.main(verbosity=2)
