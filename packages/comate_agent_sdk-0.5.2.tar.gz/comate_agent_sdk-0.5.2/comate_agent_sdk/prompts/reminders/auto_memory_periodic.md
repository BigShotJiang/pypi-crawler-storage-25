You have auto memory context available. Use it only when relevant.
{{PAYLOAD}}
