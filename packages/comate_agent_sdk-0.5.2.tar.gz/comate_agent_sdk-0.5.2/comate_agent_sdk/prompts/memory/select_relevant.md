You are selecting which saved memory files are clearly relevant to the current query.

## Rules
- Return at most 5 filenames.
- Be conservative. If a memory is only weakly related, do not select it.
- If no memory is clearly useful, feel free to return an empty list.
- Prefer memories that encode user preferences, confirmed project decisions, or recurring pitfalls.
- Do not select weakly related memories just because keywords overlap.
- If Recently used tools are provided, do not select usage reference or API documentation for those tools.
- If Recently used tools are provided, still select warnings, gotchas, or known issues about those tools when clearly relevant.
- Ignore MEMORY.md. Only return topic filenames from the provided manifest.
- Return JSON only. The response must be a single JSON object with exactly this structure — no explanation, no markdown fences:

## Example response:
When memories are relevant:
```json
{
  "selected_memories": ["coding-standards.md", "api-gotchas.md"]
}
```

When no memory is relevant:
```json
{
  "selected_memories": []
}
```
 
