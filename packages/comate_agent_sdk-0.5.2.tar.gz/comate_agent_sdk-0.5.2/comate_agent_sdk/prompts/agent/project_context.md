<project_context>
working_directory: {{WORKING_DIRECTORY}}
is_git_repo: {{IS_GIT_REPO}}
All relative paths are resolved against this working directory.
</project_context>
