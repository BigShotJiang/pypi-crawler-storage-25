import asyncio
import pytest
from mcp.types import CallToolResult, TextContent

from comate_agent_sdk.facade.tools import tool, ToolResult


@tool("valid tool")
async def valid_tool(x: int) -> ToolResult:
    return ToolResult(content=[TextContent(type="text", text=str(x))])


@tool("bad tool")
async def bad_tool(x: int) -> str:
    return f"result: {x}"  # Wrong return type


@tool("error tool")
async def error_tool() -> ToolResult:
    return ToolResult(
        content=[TextContent(type="text", text="oops")],
        isError=True,
    )


def test_valid_return_passes():
    """ToolResult return passes validation."""
    result = asyncio.run(valid_tool.execute(x=42))
    assert isinstance(result, CallToolResult)
    assert result.content[0].text == "42"


def test_invalid_return_raises_type_error():
    """Non-ToolResult return raises TypeError."""
    with pytest.raises(TypeError, match="must return ToolResult"):
        asyncio.run(bad_tool.execute(x=1))


def test_error_return_preserved():
    """isError=True is preserved through validation."""
    result = asyncio.run(error_tool.execute())
    assert isinstance(result, CallToolResult)
    assert result.isError is True


def test_tool_schema_generation():
    """Facade @tool still generates correct JSON schema from function signature."""
    defn = valid_tool.definition
    assert defn.name == "valid_tool"
    props = defn.parameters.get("properties", {})
    assert "x" in props
    assert props["x"]["type"] == "integer"


def test_sync_function_rejected():
    """Sync function raises TypeError at decoration time."""
    with pytest.raises(TypeError, match="must be an async function"):
        @tool("sync tool")
        def sync_tool(x: int) -> ToolResult:
            pass
