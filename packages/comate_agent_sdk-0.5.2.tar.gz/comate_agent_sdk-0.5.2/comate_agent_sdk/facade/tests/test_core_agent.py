"""Agent 核心类单元测试"""
import unittest

import pytest
from comate_agent_sdk.facade.core import Agent


def test_agent_minimal_construction():
    """最小化构造"""
    agent = Agent(instructions="你是助手")
    assert agent.instructions == "你是助手"
    assert agent.tools == []
    assert agent.team_name is None
    assert agent.name is None


def test_agent_with_tools():
    """带工具的构造"""
    from comate_agent_sdk.tools import tool

    @tool
    def hello(name: str) -> str:
        """问好"""
        return f"Hello, {name}!"

    agent = Agent(instructions="你是助手", tools=[hello])
    assert agent.instructions == "你是助手"
    assert len(agent.tools) == 1


def test_agent_with_team():
    """Team mode 构造"""
    agent = Agent(
        instructions="你是代码审查员",
        team_name="my-team",
        name="reviewer-1"
    )
    assert agent.team_name == "my-team"
    assert agent.name == "reviewer-1"
    assert agent.instructions == "你是代码审查员"


def test_agent_with_options():
    """使用 options 参数"""
    from comate_agent_sdk.facade.config import AgentOptions

    opts = AgentOptions()
    agent = Agent(
        instructions="...",
        options=opts
    )
    assert agent.options is opts


def test_agent_session_id():
    """支持 session_id 参数"""
    agent = Agent(
        instructions="test",
        session_id="session-123"
    )
    assert agent.session_id == "session-123"


class TestTeamModeRunMessage(unittest.IsolatedAsyncioTestCase):
    async def test_team_mode_rejects_async_iterable_prompt(self):
        """Team Mode 应该拒绝 AsyncIterable prompt。"""
        from comate_agent_sdk.facade.errors import AgentExecutionError

        agent = Agent(
            team_name="my-team",
            name="leader",
        )

        async def fake_iterable():
            yield {"type": "user", "message": {"role": "user", "content": "hello"}}

        with self.assertRaisesRegex(AgentExecutionError, "Team Mode does not support AsyncIterable"):
            async for _ in agent.run_message(fake_iterable()):
                pass


class TestTeamContinuationLoop(unittest.IsolatedAsyncioTestCase):
    async def test_team_continuation_loop_yields_events_after_yield_event(self):
        """完整续轮流程：YieldEvent → 等待 inbox → query_stream(None) → StopEvent。"""
        import asyncio
        from unittest.mock import MagicMock, patch
        from comate_agent_sdk.facade.core.events import (
            TextEvent, YieldEvent, StopEvent,
        )

        agent = Agent(
            team_name="my-team",
            name="leader",
        )

        # Mock ChatSession:
        # 1st query_stream(prompt) → TextEvent (raw, will go through filter)
        # 2nd query_stream(None) → TextEvent (raw)
        call_count = 0

        async def fake_query_stream(message=None):
            nonlocal call_count
            call_count += 1
            if call_count == 1:
                assert message == "do task"
                yield TextEvent(content="contacting teammate")
            elif call_count == 2:
                assert message is None
                yield TextEvent(content="teammate replied")

        mock_session = MagicMock()
        mock_session.query_stream = fake_query_stream

        pending_turns = [False]
        mock_session.has_pending_external_turns = lambda: pending_turns[0]

        agent._chat_session = mock_session

        # Mock _filter_events_new: pass through + append terminal event
        first_call = True

        async def fake_filter(stream):
            nonlocal first_call
            async for event in stream:
                yield event
            if first_call:
                first_call = False
                yield YieldEvent(reason="waiting_for_teammate", metadata={})
            else:
                yield StopEvent(reason="completed")

        collected_events = []

        async def run_and_collect():
            with patch(
                "comate_agent_sdk.facade._internals.adapters._filter_events_new",
                fake_filter,
            ):
                async for event in agent.run_message("do task"):
                    collected_events.append(event)

        # Concurrent: run_message + simulate teammate reply after short delay
        async def simulate_teammate_reply():
            await asyncio.sleep(0.1)
            pending_turns[0] = True

        await asyncio.gather(
            run_and_collect(),
            simulate_teammate_reply(),
        )

        event_types = [type(e).__name__ for e in collected_events]
        assert "TextEvent" in event_types, f"Missing TextEvent, got {event_types}"
        assert "YieldEvent" in event_types, f"Missing YieldEvent, got {event_types}"
        assert "StopEvent" in event_types, f"Missing StopEvent, got {event_types}"
        assert call_count == 2, f"Expected 2 query_stream calls, got {call_count}"
