from __future__ import annotations

import pytest

from comate_agent_sdk.facade.config.hooks import HOOK_EVENTS, HookMatcher


class TestHookTypes:
    def test_hook_events_contains_expected_events(self) -> None:
        expected = {
            "PreToolUse", "PostToolUse", "PostToolUseFailure",
            "UserPromptSubmit", "Stop", "SessionStart", "SessionEnd",
            "SubagentStart", "SubagentStop",
        }
        assert HOOK_EVENTS == expected

    def test_hook_matcher_defaults(self) -> None:
        m = HookMatcher()
        assert m.matcher is None
        assert m.hooks == []
        assert m.timeout is None

    def test_hook_matcher_with_values(self) -> None:
        async def dummy(input_data, tool_use_id):
            return {}

        m = HookMatcher(matcher="^Bash$", hooks=[dummy], timeout=30)
        assert m.matcher == "^Bash$"
        assert len(m.hooks) == 1
        assert m.timeout == 30


import asyncio

from comate_agent_sdk.agent.hooks.models import HookInput


class TestWrapFacadeHookCallback:
    def test_wraps_async_callback_and_passes_input_dict(self) -> None:
        from comate_agent_sdk.facade._internals.adapters import _wrap_facade_hook_callback

        received_args: list = []

        async def my_callback(input_data, tool_use_id):
            received_args.append((input_data, tool_use_id))
            return {"permissionDecision": "deny", "reason": "test"}

        wrapped = _wrap_facade_hook_callback(my_callback)
        hook_input = HookInput(
            session_id="s1",
            cwd="/tmp",
            permission_mode="default",
            hook_event_name="PreToolUse",
            tool_name="Bash",
            tool_input={"command": "ls"},
            tool_call_id="tc_123",
        )
        result = asyncio.run(wrapped(hook_input))

        assert len(received_args) == 1
        input_data, tool_use_id = received_args[0]
        assert input_data["session_id"] == "s1"
        assert input_data["tool_name"] == "Bash"
        assert input_data["hook_event_name"] == "PreToolUse"
        assert tool_use_id == "tc_123"
        assert result == {"permissionDecision": "deny", "reason": "test"}

    def test_callback_returning_none(self) -> None:
        from comate_agent_sdk.facade._internals.adapters import _wrap_facade_hook_callback

        async def noop_callback(input_data, tool_use_id):
            return None

        wrapped = _wrap_facade_hook_callback(noop_callback)
        hook_input = HookInput(
            session_id="s1",
            cwd="/tmp",
            permission_mode="default",
            hook_event_name="Stop",
        )
        result = asyncio.run(wrapped(hook_input))
        assert result is None

    def test_callback_returning_empty_dict_becomes_none(self) -> None:
        from comate_agent_sdk.facade._internals.adapters import _wrap_facade_hook_callback

        async def empty_callback(input_data, tool_use_id):
            return {}

        wrapped = _wrap_facade_hook_callback(empty_callback)
        hook_input = HookInput(
            session_id="s1",
            cwd="/tmp",
            permission_mode="default",
            hook_event_name="Stop",
        )
        result = asyncio.run(wrapped(hook_input))
        assert result is None

    def test_non_tool_event_passes_none_tool_use_id(self) -> None:
        from comate_agent_sdk.facade._internals.adapters import _wrap_facade_hook_callback

        received_tool_use_id = object()  # sentinel

        async def capture_callback(input_data, tool_use_id):
            nonlocal received_tool_use_id
            received_tool_use_id = tool_use_id
            return None

        wrapped = _wrap_facade_hook_callback(capture_callback)
        hook_input = HookInput(
            session_id="s1",
            cwd="/tmp",
            permission_mode="default",
            hook_event_name="UserPromptSubmit",
            prompt="hello",
        )
        asyncio.run(wrapped(hook_input))
        assert received_tool_use_id is None


class TestMapFacadeHooks:
    def test_maps_single_event_single_matcher(self) -> None:
        from comate_agent_sdk.facade._internals.adapters import _map_facade_hooks

        async def my_hook(input_data, tool_use_id):
            return {}

        facade_hooks = {
            "PreToolUse": [HookMatcher(matcher="^Bash$", hooks=[my_hook], timeout=30)],
        }
        config = _map_facade_hooks(facade_hooks)

        groups = config.groups_for("PreToolUse")
        assert len(groups) == 1
        assert groups[0].matcher == "^Bash$"
        assert groups[0].source == "facade"
        assert len(groups[0].hooks) == 1
        assert groups[0].hooks[0].type == "python"
        assert groups[0].hooks[0].timeout == 30
        assert groups[0].hooks[0].source == "facade"
        assert groups[0].hooks[0].name == "my_hook"

    def test_none_matcher_becomes_wildcard(self) -> None:
        from comate_agent_sdk.facade._internals.adapters import _map_facade_hooks

        async def hook(input_data, tool_use_id):
            return None

        facade_hooks = {
            "PostToolUse": [HookMatcher(hooks=[hook])],
        }
        config = _map_facade_hooks(facade_hooks)
        groups = config.groups_for("PostToolUse")
        assert groups[0].matcher == "*"

    def test_none_timeout_uses_sdk_default(self) -> None:
        from comate_agent_sdk.facade._internals.adapters import _map_facade_hooks

        async def hook(input_data, tool_use_id):
            return None

        facade_hooks = {
            "Stop": [HookMatcher(hooks=[hook])],
        }
        config = _map_facade_hooks(facade_hooks)
        groups = config.groups_for("Stop")
        assert groups[0].hooks[0].timeout == 10  # SDK 默认值

    def test_multiple_events_and_matchers(self) -> None:
        from comate_agent_sdk.facade._internals.adapters import _map_facade_hooks

        async def hook_a(input_data, tool_use_id):
            return None

        async def hook_b(input_data, tool_use_id):
            return None

        facade_hooks = {
            "PreToolUse": [
                HookMatcher(matcher="^Bash$", hooks=[hook_a]),
                HookMatcher(hooks=[hook_b]),
            ],
            "SessionStart": [HookMatcher(hooks=[hook_a])],
        }
        config = _map_facade_hooks(facade_hooks)
        assert len(config.groups_for("PreToolUse")) == 2
        assert len(config.groups_for("SessionStart")) == 1
        assert len(config.groups_for("PostToolUse")) == 0

    def test_multiple_hooks_in_single_matcher(self) -> None:
        from comate_agent_sdk.facade._internals.adapters import _map_facade_hooks

        async def hook_a(input_data, tool_use_id):
            return None

        async def hook_b(input_data, tool_use_id):
            return None

        facade_hooks = {
            "PreToolUse": [HookMatcher(hooks=[hook_a, hook_b])],
        }
        config = _map_facade_hooks(facade_hooks)
        groups = config.groups_for("PreToolUse")
        assert len(groups) == 1
        assert len(groups[0].hooks) == 2


from comate_agent_sdk.facade.config.options import AgentOptions


class TestAgentOptionsHooks:
    def test_hooks_default_is_none(self) -> None:
        opts = AgentOptions()
        assert opts.hooks is None

    def test_hooks_accepts_dict(self) -> None:
        async def my_hook(input_data, tool_use_id):
            return None

        opts = AgentOptions(
            hooks={
                "PreToolUse": [HookMatcher(matcher="^Bash$", hooks=[my_hook])],
            }
        )
        assert opts.hooks is not None
        assert "PreToolUse" in opts.hooks
        assert len(opts.hooks["PreToolUse"]) == 1


class TestRegisterHook:
    def test_register_hook_stores_pending(self) -> None:
        from comate_agent_sdk.facade.core.agent import Agent

        async def my_hook(input_data, tool_use_id):
            return None

        agent = Agent()
        agent.register_hook("PreToolUse", my_hook, matcher="^Bash$", timeout=20)

        assert len(agent._pending_hooks) == 1
        event, cb, matcher, timeout = agent._pending_hooks[0]
        assert event == "PreToolUse"
        assert cb is my_hook
        assert matcher == "^Bash$"
        assert timeout == 20

    def test_register_hook_invalid_event_raises(self) -> None:
        from comate_agent_sdk.facade.core.agent import Agent

        async def my_hook(input_data, tool_use_id):
            return None

        agent = Agent()
        with pytest.raises(ValueError, match="Unknown hook event"):
            agent.register_hook("InvalidEvent", my_hook)

    def test_register_hook_after_init_raises(self) -> None:
        from comate_agent_sdk.facade.core.agent import Agent

        async def my_hook(input_data, tool_use_id):
            return None

        agent = Agent()
        agent._chat_session = object()  # type: ignore[assignment]

        with pytest.raises(RuntimeError, match="Cannot register hooks after"):
            agent.register_hook("PreToolUse", my_hook)


import asyncio
import json
import tempfile
from pathlib import Path


class TestHookInjection:
    def test_agent_options_hooks_injected_to_engine(self) -> None:
        """AgentOptions.hooks 在初始化后注入到 runtime._hook_engine。"""
        from comate_agent_sdk.facade.core.agent import Agent

        async def my_hook(input_data, tool_use_id):
            return None

        opts = AgentOptions(
            system_prompt="test",
            tools=None,
            setting_sources=None,
            hooks={
                "PreToolUse": [HookMatcher(hooks=[my_hook])],
            },
        )
        agent = Agent(options=opts)

        asyncio.run(agent._ensure_initialized())

        runtime = agent._chat_session._agent  # type: ignore[union-attr]
        engine = runtime._hook_engine
        assert engine is not None
        groups = engine._config.groups_for("PreToolUse")
        facade_groups = [g for g in groups if g.source == "facade"]
        assert len(facade_groups) >= 1

    def test_pending_hooks_injected_to_engine(self) -> None:
        """register_hook() 注册的 hook 在初始化后注入到 runtime._hook_engine._config。"""
        from comate_agent_sdk.facade.core.agent import Agent

        async def my_hook(input_data, tool_use_id):
            return None

        opts = AgentOptions(
            system_prompt="test",
            tools=None,
            setting_sources=None,
        )
        agent = Agent(options=opts)
        agent.register_hook("PostToolUse", my_hook, matcher="^Read$", timeout=25)

        asyncio.run(agent._ensure_initialized())

        runtime = agent._chat_session._agent  # type: ignore[union-attr]
        engine = runtime._hook_engine
        assert engine is not None
        groups = engine._config.groups_for("PostToolUse")
        facade_groups = [g for g in groups if g.source == "facade"]
        assert len(facade_groups) >= 1
        assert facade_groups[0].hooks[0].timeout == 25

    def test_options_hooks_and_register_hook_coexist(self) -> None:
        """两种注册方式的 hook 共存，都进入 _config。"""
        from comate_agent_sdk.facade.core.agent import Agent

        async def options_hook(input_data, tool_use_id):
            return None

        async def dynamic_hook(input_data, tool_use_id):
            return None

        opts = AgentOptions(
            system_prompt="test",
            tools=None,
            setting_sources=None,
            hooks={"PreToolUse": [HookMatcher(hooks=[options_hook])]},
        )
        agent = Agent(options=opts)
        agent.register_hook("PreToolUse", dynamic_hook, matcher="^Bash$")

        asyncio.run(agent._ensure_initialized())

        runtime = agent._chat_session._agent  # type: ignore[union-attr]
        engine = runtime._hook_engine

        facade_groups = [g for g in engine._config.groups_for("PreToolUse") if g.source == "facade"]
        assert len(facade_groups) >= 2

    def test_options_hooks_and_settings_file_coexist(self) -> None:
        """facade hooks 与配置文件 hooks 合并（extend），不互相覆盖。"""
        from comate_agent_sdk.facade.core.agent import Agent

        async def facade_hook(input_data, tool_use_id):
            return None

        with tempfile.TemporaryDirectory() as tmpdir:
            settings_dir = Path(tmpdir) / ".agent"
            settings_dir.mkdir()
            settings_file = settings_dir / "settings.json"
            settings_file.write_text(json.dumps({
                "hooks": {
                    "PreToolUse": [{
                        "matcher": "^Write$",
                        "hooks": [{"type": "command", "command": "echo ok"}],
                    }]
                }
            }))

            opts = AgentOptions(
                system_prompt="test",
                tools=None,
                cwd=tmpdir,
                setting_sources=["project"],
                hooks={"PreToolUse": [HookMatcher(hooks=[facade_hook])]},
            )
            agent = Agent(options=opts)
            asyncio.run(agent._ensure_initialized())

            runtime = agent._chat_session._agent  # type: ignore[union-attr]
            engine = runtime._hook_engine
            groups = engine._config.groups_for("PreToolUse")
            sources = {g.source for g in groups}
            assert "facade" in sources
            non_facade = [g for g in groups if g.source != "facade"]
            assert len(non_facade) >= 1

    def test_pending_hooks_cleared_after_init(self) -> None:
        """初始化后 _pending_hooks 被清空。"""
        from comate_agent_sdk.facade.core.agent import Agent

        async def my_hook(input_data, tool_use_id):
            return None

        opts = AgentOptions(
            system_prompt="test",
            tools=None,
            setting_sources=None,
        )
        agent = Agent(options=opts)
        agent.register_hook("PreToolUse", my_hook)

        asyncio.run(agent._ensure_initialized())
        assert agent._pending_hooks == []


class TestPublicExports:
    def test_import_from_facade(self) -> None:
        from comate_agent_sdk.facade import HookMatcher, HookCallback
        assert HookMatcher is not None
        assert HookCallback is not None

    def test_import_from_facade_config(self) -> None:
        from comate_agent_sdk.facade.config import HookMatcher, HookCallback
        assert HookMatcher is not None
        assert HookCallback is not None
