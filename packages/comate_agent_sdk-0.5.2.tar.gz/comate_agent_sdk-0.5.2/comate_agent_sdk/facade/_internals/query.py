from __future__ import annotations

import logging
from collections.abc import AsyncIterator
from dataclasses import replace
from pathlib import Path

from comate_agent_sdk.facade.client import AgentClient
from comate_agent_sdk.facade.core.events import Event
from comate_agent_sdk.facade.config.options import AgentOptions
from comate_agent_sdk.llm.base import BaseChatModel
from comate_agent_sdk.tools.decorator import Tool

logger = logging.getLogger(__name__)


def _resolve_options(
    *,
    options: AgentOptions | None,
    tools: list[Tool] | None,
) -> tuple[AgentOptions | None, list]:
    if tools is None and (options is None or not options.plugins):
        return options, []
    if options is None:
        options = AgentOptions(tools=tools) if tools else AgentOptions()
    elif tools is not None:
        options = replace(options, tools=tools)

    loaded: list = []

    # Process plugin configs if present
    if options.plugins:
        from comate_agent_sdk.plugins.loader import PluginLoader

        loader = PluginLoader()
        local_paths = [
            Path(str(p.path)) for p in options.plugins
            if p.type == "local" and p.path
        ]
        loaded, errors = loader.load_all(
            registry=None,  # No registry in query() context
            local_plugins=local_paths,
        )

        for error in errors:
            logger.warning(
                "plugin load error [%s]: %s", error.plugin_key, error.message
            )

        for plugin in loaded:
            logger.info(
                "loaded plugin '%s': %d skills, %d commands, %d agents",
                plugin.name,
                len(plugin.skills),
                len(plugin.commands),
                len(plugin.agents),
            )

    return options, loaded


async def query(
    prompt: str,
    *,
    llm: BaseChatModel,
    tools: list[Tool] | None = None,
    options: AgentOptions | None = None,
) -> AsyncIterator[Event]:
    options, loaded_plugins = _resolve_options(options=options, tools=tools)
    client = AgentClient(
        llm=llm,
        options=options,
        loaded_plugins=loaded_plugins or None,
    )
    async for event in client.chat(prompt):
        yield event
