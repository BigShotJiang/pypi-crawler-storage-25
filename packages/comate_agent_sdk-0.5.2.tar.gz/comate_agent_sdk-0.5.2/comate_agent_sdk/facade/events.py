from __future__ import annotations

from dataclasses import dataclass
from typing import Literal, TypeAlias

from comate_agent_sdk.agent.events import (
    StepCompleteEvent,
    StepStartEvent,
    TextEvent,
    ThinkingEvent,
    ToolResultEvent,
    UserQuestionEvent,
)
from comate_agent_sdk.facade.core.events import ToolUseEvent


@dataclass(slots=True)
class DoneEvent:
    reason: Literal["completed", "interrupted", "waiting_for_input"]

    def __str__(self) -> str:
        return f"✅ Done: {self.reason}"


Event: TypeAlias = (
    TextEvent
    | ThinkingEvent
    | ToolUseEvent
    | ToolResultEvent
    | StepStartEvent
    | StepCompleteEvent
    | UserQuestionEvent
    | DoneEvent
)

__all__ = [
    "Event",
    "TextEvent",
    "ThinkingEvent",
    "ToolUseEvent",
    "ToolResultEvent",
    "StepStartEvent",
    "StepCompleteEvent",
    "UserQuestionEvent",
    "DoneEvent",
]
