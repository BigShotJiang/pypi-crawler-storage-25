# comate_agent_sdk/facade/core/runner.py
from __future__ import annotations

import asyncio
import logging
from collections.abc import AsyncIterable, AsyncIterator, Iterator
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from comate_agent_sdk.facade.core.agent import Agent
    from comate_agent_sdk.facade.core.events import Event

logger = logging.getLogger(__name__)


def run_agent(
    agent: Agent,
    prompt: str | AsyncIterable[dict[str, Any]],
) -> Iterator[Event]:
    """
    同步运行 agent，返回事件流。

    适合新手：无需理解 async/await。
    内部使用事件循环处理异步逻辑。

    Args:
        agent: Agent 实例
        prompt: 用户消息（str）或消息迭代器（AsyncIterable[dict]）

    Yields:
        Event：事件流（TextEvent, ToolUseEvent, YieldEvent, StopEvent 等）

    Example:
        >>> from comate_agent_sdk.facade.config.options import AgentOptions
        >>> agent = Agent(options=AgentOptions(system_prompt="你是助手"))
        >>> for event in run_agent(agent, "你好"):
        ...     print(event)
    """
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    try:
        # 获取异步生成器
        async_gen = run_agent_async(agent, prompt)
        while True:
            try:
                event = loop.run_until_complete(async_gen.__anext__())
                yield event
            except StopAsyncIteration:
                break
    finally:
        try:
            loop.run_until_complete(agent.shutdown())
        finally:
            loop.close()


async def run_agent_async(
    agent: Agent,
    prompt: str | AsyncIterable[dict[str, Any]],
) -> AsyncIterator[Event]:
    """
    异步运行 agent，返回事件流。

    适合集成到异步框架（FastAPI 等）。

    Args:
        agent: Agent 实例
        prompt: 用户消息（str）或消息迭代器（AsyncIterable[dict]）

    Yields:
        Event：事件流

    Example:
        >>> from comate_agent_sdk.facade.config.options import AgentOptions
        >>> agent = Agent(options=AgentOptions(system_prompt="你是助手"))
        >>> async for event in run_agent_async(agent, "你好"):
        ...     print(event)
        >>> await agent.shutdown()
    """
    async for event in agent.run_message(prompt):  # type: ignore[attr-defined]
        yield event


__all__ = ["run_agent", "run_agent_async"]
