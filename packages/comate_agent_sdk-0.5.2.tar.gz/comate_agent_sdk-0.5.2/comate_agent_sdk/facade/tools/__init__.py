"""Tool Definition Facade with ToolResult enforcement.

User tools defined via this facade MUST return ToolResult.
"""

from comate_agent_sdk.facade.tools.decorators import tool
from mcp.types import CallToolResult as ToolResult
from mcp.types import (
    AudioContent,
    EmbeddedResource,
    ImageContent,
    TextContent,
)

__all__ = [
    "tool",
    "ToolResult",
    "TextContent",
    "ImageContent",
    "AudioContent",
    "EmbeddedResource",
]
