"""Facade @tool decorator with ToolResult return type enforcement.

Wraps the core @tool decorator, adding runtime validation that
the handler returns CallToolResult (ToolResult). System tools
use core @tool directly and are not affected.
"""

import functools
import inspect
from collections.abc import Awaitable, Callable
from typing import TYPE_CHECKING, ParamSpec, TypeVar

from mcp.types import CallToolResult

from comate_agent_sdk.tools.decorator import Tool
from comate_agent_sdk.tools.decorator import tool as _core_tool

if TYPE_CHECKING:
    from comate_agent_sdk.tools.registry import ToolRegistry

P = ParamSpec("P")
T = TypeVar("T")


def tool(
    description: str,
    *,
    name: str | None = None,
    registry: "ToolRegistry | None" = None,
    ephemeral: int | bool = False,
    usage_rules: str | None = None,
) -> Callable[[Callable[P, Awaitable[T]]], Tool]:
    """Facade @tool: same as core @tool but enforces ToolResult return type.

    User tool handlers MUST return ToolResult (CallToolResult).
    Returning any other type raises TypeError at runtime.
    """

    def decorator(func: Callable[P, Awaitable[T]]) -> Tool:
        if not inspect.iscoroutinefunction(func):
            raise TypeError(
                f"Tool '{func.__name__}' must be an async function. "
                f"Use 'async def {func.__name__}(...)' instead."
            )
        @functools.wraps(func)
        async def _validated(*args, **kwargs):
            result = await func(*args, **kwargs)
            if not isinstance(result, CallToolResult):
                raise TypeError(
                    f"Tool '{func.__name__}' must return ToolResult, "
                    f"got {type(result).__name__}. "
                    f"Use: return ToolResult(content=[TextContent(type='text', text='...')])"
                )
            return result

        # Preserve original signature for core @tool's schema introspection
        _validated.__signature__ = inspect.signature(func)  # type: ignore[attr-defined]
        _validated.__annotations__ = getattr(func, "__annotations__", {})

        return _core_tool(
            description,
            name=name,
            registry=registry,
            ephemeral=ephemeral,
            usage_rules=usage_rules,
        )(_validated)

    return decorator


__all__ = ["tool"]
