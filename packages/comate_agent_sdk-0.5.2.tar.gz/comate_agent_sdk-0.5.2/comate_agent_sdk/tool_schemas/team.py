from __future__ import annotations

from comate_agent_sdk.tool_schemas._base import ToolOutput


class TeamCreateOutput(ToolOutput):
    team_name: str
    config_path: str
    description: str = ""


class TeamDeleteOutput(ToolOutput):
    team_name: str
    cleaned: list[str] = []


class SendMessageOutput(ToolOutput):
    to: str
    type: str
    delivered_to: list[str]
