"""Generic output wrapper for custom @tool and MCP tools."""
from __future__ import annotations

from comate_agent_sdk.tool_schemas._base import ToolOutput


class CustomToolOutput(ToolOutput):
    """自定义工具 / MCP 工具的通用输出包装。

    当 TOOL_SCHEMA_REGISTRY 中没有对应工具的 schema 时，
    作为 ToolResultEvent.output 的 fallback 类型。
    """

    content: str | list[dict]
    """工具返回的内容。str 对应单文本结果；list[dict] 对应多模态结果。"""

    is_error: bool = False
    """工具是否报错。"""
