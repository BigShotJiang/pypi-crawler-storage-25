"""Tool schema registry: tool_name → (InputSchema | None, OutputSchema)."""
from __future__ import annotations

from pydantic import BaseModel

from comate_agent_sdk.tool_schemas._base import ToolOutput
from comate_agent_sdk.tool_schemas.bash import BashOutput
from comate_agent_sdk.tool_schemas.read import ReadOutput
from comate_agent_sdk.tool_schemas.write import WriteOutput
from comate_agent_sdk.tool_schemas.edit import EditOutput, MultiEditOutput
from comate_agent_sdk.tool_schemas.search import GlobOutput, GrepOutput, LSOutput
from comate_agent_sdk.tool_schemas.web import WebFetchOutput
from comate_agent_sdk.tool_schemas.task import TaskCreateOutput, TaskListOutput, TaskGetOutput, TaskUpdateOutput
from comate_agent_sdk.tool_schemas.team import TeamCreateOutput, TeamDeleteOutput, SendMessageOutput
from comate_agent_sdk.tool_schemas.misc import AskUserQuestionOutput, ExitPlanModeOutput, YieldTurnOutput

from comate_agent_sdk.system_tools.tools import (
    BashInput, ReadInput, WriteInput, EditInput, MultiEditInput,
    GlobInput, GrepInput, LSInput, WebFetchInput,
    AskUserQuestionInput, ExitPlanModeInput, YieldTurnInput,
)
from comate_agent_sdk.system_tools.task.tools import (
    TaskCreateInput, TaskListInput, TaskGetInput, TaskUpdateInput,
)
from comate_agent_sdk.system_tools.team.tools import TeamCreateInput, SendMessageInput

TOOL_SCHEMA_REGISTRY: dict[str, tuple[type[BaseModel] | None, type[ToolOutput]]] = {
    "Bash": (BashInput, BashOutput),
    "Read": (ReadInput, ReadOutput),
    "Write": (WriteInput, WriteOutput),
    "Edit": (EditInput, EditOutput),
    "MultiEdit": (MultiEditInput, MultiEditOutput),
    "Glob": (GlobInput, GlobOutput),
    "Grep": (GrepInput, GrepOutput),
    "LS": (LSInput, LSOutput),
    "WebFetch": (WebFetchInput, WebFetchOutput),
    "TaskCreate": (TaskCreateInput, TaskCreateOutput),
    "TaskList": (TaskListInput, TaskListOutput),
    "TaskGet": (TaskGetInput, TaskGetOutput),
    "TaskUpdate": (TaskUpdateInput, TaskUpdateOutput),
    "TeamCreate": (TeamCreateInput, TeamCreateOutput),
    "TeamDelete": (None, TeamDeleteOutput),
    "SendMessage": (SendMessageInput, SendMessageOutput),
    "AskUserQuestion": (AskUserQuestionInput, AskUserQuestionOutput),
    "ExitPlanMode": (ExitPlanModeInput, ExitPlanModeOutput),
    "YieldTurn": (YieldTurnInput, YieldTurnOutput),
}
