from __future__ import annotations

from comate_agent_sdk.tool_schemas._base import ToolOutput


class WriteOutput(ToolOutput):
    bytes_written: int
    lines_written: int
    file_bytes: int
    created: bool
    sha256: str
    relpath: str
