from __future__ import annotations

from typing import Any

from comate_agent_sdk.tool_schemas._base import ToolOutput


class TaskCreateOutput(ToolOutput):
    list_id: str
    task: dict[str, Any]
    tasks: list[dict[str, Any]]
    total: int
    by_status: dict[str, int]
    summary: str


class TaskListOutput(ToolOutput):
    list_id: str
    tasks: list[dict[str, Any]]
    total: int
    by_status: dict[str, int]
    summary: str


class TaskGetOutput(ToolOutput):
    list_id: str
    task: dict[str, Any]
    blocks_detail: list[dict[str, Any]] = []
    blocked_by_detail: list[dict[str, Any]] = []
    open_blocked_by: list[str] = []


class TaskUpdateOutput(ToolOutput):
    list_id: str
    task: dict[str, Any]
    tasks: list[dict[str, Any]]
    total: int
    by_status: dict[str, int]
    summary: str
