from __future__ import annotations

from comate_agent_sdk.tool_schemas._base import ToolOutput


class EditOutput(ToolOutput):
    replacements: int
    before_sha256: str
    after_sha256: str
    relpath: str
    diff: list[str]
    start_line: int
    end_line: int


class MultiEditOutput(ToolOutput):
    total_replacements: int
    created: bool
    before_sha256: str | None
    after_sha256: str
    bytes: int
    relpath: str
    diff: list[str]
    start_line: int
    end_line: int
