from __future__ import annotations

from typing import Any, Self

from comate_agent_sdk.tool_schemas._base import ToolOutput


class GlobOutput(ToolOutput):
    matches: list[str]
    count: int
    count_is_lower_bound: bool = False
    truncated: bool
    truncated_reason: str | None = None
    search_path: str = ""
    summary: dict[str, Any] | None = None
    artifact: dict[str, Any] | None = None
    read_hint: str | None = None


class GrepOutput(ToolOutput):
    total_matches: int
    truncated: bool
    files: list[str] | None = None
    counts: list[dict[str, Any]] | None = None
    matches_by_file: dict[str, Any] | None = None
    file_count: int | None = None
    truncated_reason: str | None = None
    total_matches_is_lower_bound: bool = False
    summary: dict[str, Any] | None = None
    artifact: dict[str, Any] | None = None
    read_hint: str | None = None

    @classmethod
    def from_envelope(cls, envelope: dict) -> Self:
        data = dict(envelope.get("data", {}))
        # files_with_matches 模式字段名归一化：count → total_matches
        if "count" in data and "total_matches" not in data:
            data["total_matches"] = data.pop("count")
        return cls.model_validate(data)


class LSOutput(ToolOutput):
    entries: list[dict[str, Any]]
    count: int
    truncated: bool
    truncated_reason: str | None = None
    path: str = ""
    artifact: dict[str, Any] | None = None
    read_hint: str | None = None
