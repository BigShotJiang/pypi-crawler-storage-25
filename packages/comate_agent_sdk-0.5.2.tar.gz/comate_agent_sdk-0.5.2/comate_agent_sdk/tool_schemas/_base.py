from __future__ import annotations

from typing import Self

from pydantic import BaseModel, ConfigDict


class ToolOutput(BaseModel):
    """所有 tool output schema 的基类。

    提供默认的 from_envelope() 投影：
    从 ok() 返回的 raw envelope 中提取 data 字段，
    通过 Pydantic model_validate 自动过滤掉未声明的内部字段。

    重要约束：调用方 MUST 先检查 envelope["ok"] 为 True 再调用此方法。
    """

    model_config = ConfigDict(extra="ignore")

    @classmethod
    def from_envelope(cls, envelope: dict) -> Self:
        data = envelope.get("data", {})
        return cls.model_validate(data)
