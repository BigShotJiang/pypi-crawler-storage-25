from __future__ import annotations

from typing import Any

from comate_agent_sdk.tool_schemas._base import ToolOutput


class AskUserQuestionOutput(ToolOutput):
    status: str
    questions: list[dict[str, Any]]


class ExitPlanModeOutput(ToolOutput):
    status: str
    plan_path: str
    summary: str
    execution_prompt: str = ""


class YieldTurnOutput(ToolOutput):
    status: str
    yield_status: str
