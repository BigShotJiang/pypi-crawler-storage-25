from __future__ import annotations

from typing import Any

from comate_agent_sdk.tool_schemas._base import ToolOutput


class WebFetchOutput(ToolOutput):
    final_url: str
    status: int
    cached: bool
    cache_fingerprint: str = ""
    fetch_time: int = 0
    summary_text: str
    model_used: str
    truncated_for_llm: bool
    markdown_tokens: str | None = None
    content_signal: str | None = None
    artifact: dict[str, Any] | None = None
    read_hint: str | None = None
