"""Projection helpers: raw envelope → typed Output, args dict → typed Input.

Called from tool_execution.py to populate ToolResultEvent.output and ToolCallEvent.input.
"""
from __future__ import annotations

import logging
from typing import Any

from pydantic import BaseModel

from comate_agent_sdk.tool_schemas._base import ToolOutput

logger = logging.getLogger(__name__)


def project_output(tool_name: str, envelope: Any) -> ToolOutput | None:
    """Project raw envelope to typed Output. Returns None on any failure."""
    if not isinstance(envelope, dict):
        return None
    if not envelope.get("ok", False):
        return None
    try:
        from comate_agent_sdk.tool_schemas._registry import TOOL_SCHEMA_REGISTRY
        entry = TOOL_SCHEMA_REGISTRY.get(tool_name)
        if entry is None:
            return None
        _, output_cls = entry
        return output_cls.from_envelope(envelope)
    except Exception:
        logger.debug("Failed to project output for tool %s", tool_name, exc_info=True)
        return None


def project_input(tool_name: str, args: dict[str, Any]) -> BaseModel | None:
    """Project args dict to typed Input. Returns None on any failure."""
    try:
        from comate_agent_sdk.tool_schemas._registry import TOOL_SCHEMA_REGISTRY
        entry = TOOL_SCHEMA_REGISTRY.get(tool_name)
        if entry is None:
            return None
        input_cls, _ = entry
        if input_cls is None:
            return None
        return input_cls.model_validate(args)
    except Exception:
        logger.debug("Failed to project input for tool %s", tool_name, exc_info=True)
        return None
