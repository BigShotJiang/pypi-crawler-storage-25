from __future__ import annotations

from comate_agent_sdk.tool_schemas._base import ToolOutput


class ReadOutput(ToolOutput):
    content: str
    total_lines: int
    lines_returned: int
    has_more: bool
    truncated: bool
    truncated_reason: str | None = None
    next_offset_line: int | None = None
