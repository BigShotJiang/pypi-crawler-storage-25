"""Agent 工具 - 用于启动 Subagent 的统一入口。"""

import asyncio
import logging
import subprocess
import uuid
from pathlib import Path
from typing import TYPE_CHECKING, Literal

from pydantic import BaseModel, Field

from comate_agent_sdk.llm.base import BaseChatModel
from comate_agent_sdk.llm.anthropic.chat import ChatAnthropic
from comate_agent_sdk.agent.llm_levels import LLMLevel
from comate_agent_sdk.subagent.models import AgentDefinition
from comate_agent_sdk.subagent.prompts import generate_subagent_prompt
from comate_agent_sdk.prompts import load_prompt, render_prompt
from comate_agent_sdk.system_tools.team.config import TeamConfig
from comate_agent_sdk.system_tools.team.identity import resolve_runtime_team_agent_name
from comate_agent_sdk.tokens import TokenCost
from comate_agent_sdk.tools.decorator import Tool, tool
from comate_agent_sdk.tools.depends import DependencyOverrides
from comate_agent_sdk.tools.registry import ToolRegistry

if TYPE_CHECKING:
    from comate_agent_sdk.agent.core.runtime import AgentRuntime

logger = logging.getLogger("comate_agent_sdk.subagent.agent_tool")

_INTERNAL_AGENT_TOOL_MARKER_ATTR = "_comate_agent_sdk_internal"
_INTERNAL_AGENT_TOOL_MARKER_VALUE = True

_TASK_USAGE_RULES = "Launch a subagent for complex, multi-step tasks. Subagent is stateless — write a detailed, self-contained prompt.\n\nTwo modes:\n1. Solo delegation: Agent(subagent_type, prompt) → returns one final result, not visible to user.\n2. Team member: Agent(subagent_type, prompt, team_name, name) → joins existing team, uses SendMessage for ongoing coordination.\n\nDo NOT use for simple Read/Grep/Glob operations (1-3 tool calls).\n\nAvailable subagent_type values: see <subagent> in system prompt."


class AgentToolInput(BaseModel):
    subagent_type: str = Field(
        description="Agent type: 'Explorer', 'Plan', 'general-purpose', or custom agent name"
    )
    prompt: str = Field(
        description="Complete task description. Must be self-contained - subagent has no prior context."
    )
    description: str = Field(
        default="",
        description="3-5 word task summary for display",
    )
    team_name: str = Field(
        default="",
        description="Join this team as a persistent teammate (requires prior TeamCreate)",
    )
    name: str = Field(
        default="",
        description="Teammate display name. Required when team_name is set.",
    )
    isolation: Literal["", "worktree"] = Field(
        default="",
        description="'' = share parent cwd; 'worktree' = isolated git worktree",
    )
    level: Literal["", "LOW", "MID", "HIGH"] = Field(
        default="",
        description=(
            "Model capability level for this subagent. "
            "Choose based on task complexity: "
            "LOW for simple, routine tasks (summarization, formatting); "
            "MID for moderate tasks (code generation, analysis); "
            "HIGH for complex tasks requiring deep reasoning (architecture design, debugging subtle issues). "
            "For Plan agents, always prefer HIGH to ensure thorough architectural thinking. "
            "Leave empty to use the subagent's default."
        ),
    )

    model_config = {"extra": "forbid"}


# ── Worktree 辅助函数（模块级，供 query_stream.py 复用） ──────────────────


def _create_worktree(parent_cwd: Path) -> tuple[Path, str]:
    """创建 git worktree，返回 (worktree_dir, branch_name)。"""
    short_id = uuid.uuid4().hex[:8]
    branch_name = f"worktree/subagent-{short_id}"
    worktree_dir = parent_cwd / ".agent" / "worktrees" / f"subagent-{short_id}"
    worktree_dir.parent.mkdir(parents=True, exist_ok=True)

    result = subprocess.run(
        ["git", "worktree", "add", "-b", branch_name, str(worktree_dir)],
        cwd=str(parent_cwd),
        capture_output=True,
        text=True,
        encoding="utf-8",
    )
    if result.returncode != 0:
        raise RuntimeError(
            f"Failed to create git worktree: {result.stderr.strip()}"
        )

    logger.info(f"Created git worktree at {worktree_dir} (branch: {branch_name})")
    return worktree_dir, branch_name


def _worktree_has_changes(worktree_dir: Path) -> bool:
    """检查 worktree 中是否有变更（包括 untracked files）。"""
    result = subprocess.run(
        ["git", "status", "--porcelain"],
        cwd=str(worktree_dir),
        capture_output=True,
        text=True,
        encoding="utf-8",
    )
    return bool(result.stdout.strip())


def _cleanup_worktree(
    worktree_dir: Path, parent_cwd: Path, branch_name: str
) -> None:
    """清理 worktree 和对应分支。"""
    subprocess.run(
        ["git", "worktree", "remove", "--force", str(worktree_dir)],
        cwd=str(parent_cwd),
        capture_output=True,
    )
    if branch_name:
        subprocess.run(
            ["git", "branch", "-D", branch_name],
            cwd=str(parent_cwd),
            capture_output=True,
        )
    logger.info(f"Cleaned up worktree {worktree_dir} (branch: {branch_name})")


def _cleanup_worktree_if_exists(
    worktree_dir: Path | None, parent_cwd: Path, branch_name: str
) -> None:
    """安全清理：仅在 worktree_dir 不为 None 时执行清理。"""
    if worktree_dir is not None:
        _cleanup_worktree(worktree_dir, parent_cwd, branch_name)


def finalize_worktree(
    result: str,
    worktree_dir: Path,
    parent_cwd: Path,
    branch_name: str,
) -> str:
    """检查 worktree 变更，有变更则保留并追加信息，无变更则清理。"""
    has_changes = _worktree_has_changes(worktree_dir)
    if has_changes:
        return (
            f"{result}\n\n---\n"
            f"[Worktree Result]\n"
            f"worktree_path: {worktree_dir}\n"
            f"worktree_branch: {branch_name}\n"
            f"has_changes: true"
        )
    else:
        _cleanup_worktree(worktree_dir, parent_cwd, branch_name)
        return result


# ── Team 模式辅助函数 ──────────────────────────────────────────────────────


def _switch_parent_to_team_namespace(runtime: "AgentRuntime", team_name: str) -> None:
    """A1: 首次进入 Team 模式时，切换主 agent 到 team task namespace。

    同时持久化到 session metadata，保证 resume 后仍在 team namespace。
    该切换绕过 COMATE_TASK_LIST_ID 的默认优先级（显式 team 优先）。
    """
    from comate_agent_sdk.system_tools.task.store import TaskStore

    old_ns = runtime._task_namespace
    old_team = runtime._team_name
    if old_team and old_team != team_name:
        runtime.discard_team_coordination_backlog()
    runtime._task_namespace = team_name
    runtime._team_name = team_name
    runtime._task_store = TaskStore(list_id=team_name)

    logger.info(
        f"[Team 模式] 主 agent task namespace 切换: {old_ns!r} → {team_name!r}"
    )

    # 持久化到 session metadata（绑定后必须做，保证 resume 后仍在 team）
    try:
        from comate_agent_sdk.agent.session_store import (
            write_session_metadata,
            resolve_session_root,
            normalize_cwd,
        )
        session_root = resolve_session_root(
            session_id=runtime._session_id,
            cwd=normalize_cwd(runtime._runtime_state.cwd),
        )
        write_session_metadata(
            session_root,
            session_id=runtime._session_id,
            task_namespace=team_name,
            team_name=team_name,
        )
        logger.debug(
            f"[Team 模式] session metadata 已更新 "
            f"task_namespace={team_name!r} team_name={team_name!r}"
        )
    except Exception as exc:
        logger.warning(f"[Team 模式] 持久化 session metadata 失败（忽略）: {exc}")

    sync_poll = getattr(runtime, "_sync_inbox_poll_task", None)
    if callable(sync_poll):
        sync_poll()


def _clear_team_namespace(runtime: "AgentRuntime") -> None:
    """退出 Team 模式，切换主 agent 回到 session-based task namespace。

    与 _switch_parent_to_team_namespace 对称：重置 team_name、task_namespace，
    重建 TaskStore，并持久化到 session metadata。
    """
    from comate_agent_sdk.system_tools.task.store import TaskStore

    old_ns = runtime._task_namespace
    old_team = runtime._team_name
    if old_team:
        runtime.discard_team_coordination_backlog()

    # 回到 session_id-based namespace
    session_ns = runtime._session_id or "default"
    runtime._task_namespace = session_ns
    runtime._team_name = ""
    runtime._task_store = TaskStore(list_id=session_ns)

    logger.info(
        f"[Team 模式] 主 agent 退出 team namespace: "
        f"{old_ns!r} → {session_ns!r}, team: {old_team!r} → ''"
    )

    # 持久化到 session metadata
    try:
        from comate_agent_sdk.agent.session_store import (
            write_session_metadata,
            resolve_session_root,
            normalize_cwd,
        )
        session_root = resolve_session_root(
            session_id=runtime._session_id,
            cwd=normalize_cwd(runtime._runtime_state.cwd),
        )
        write_session_metadata(
            session_root,
            session_id=runtime._session_id,
            task_namespace=session_ns,
            team_name="",
        )
        logger.debug(
            f"[Team 模式] session metadata 已更新 "
            f"task_namespace={session_ns!r} team_name=''"
        )
    except Exception as exc:
        logger.warning(f"[Team 模式] 持久化 session metadata 失败（忽略）: {exc}")

    sync_poll = getattr(runtime, "_sync_inbox_poll_task", None)
    if callable(sync_poll):
        sync_poll()


def _register_team_members(
    *,
    team_name: str,
    parent_runtime: "AgentRuntime | None",
    subagent_name: str,
    subagent_type: str,
) -> None:
    """B2: Team Config 成员注册。

    首次出现 team_name 时注册主 agent 为默认 team lead 名字，每个 subagent 启动时
    注册为 agent_type=subagent_type。
    """
    try:
        from comate_agent_sdk.system_tools.team.config import TeamConfig

        team_cfg = TeamConfig(team_name=team_name)
        # 注册主 agent（仅首次；幂等，重复注册无副作用）
        if parent_runtime is not None:
            parent_name = resolve_runtime_team_agent_name(
                runtime_name=getattr(parent_runtime, "name", None),
                is_subagent=False,
            )
            team_cfg.register_member(name=parent_name, agent_type="leader")
        # 注册 subagent
        team_cfg.register_member(name=subagent_name, agent_type=subagent_type)
    except Exception as exc:
        logger.warning(f"[TeamConfig] 注册成员失败（忽略）: {exc}")


def _refresh_parent_task_state(runtime: "AgentRuntime") -> None:
    """A7 非流式路径：subagent 结束后刷新父 agent 的 task 状态缓存。

    在 Team 模式下，subagent 可能调用了 TaskList/TaskUpdate，导致共享
    TaskStore 发生变化。非流式路径没有事件流，无法像流式路径那样转发
    TaskUpdatedEvent，因此在这里主动读取 TaskStore 并更新父侧 reminder 状态。
    """
    try:
        task_store = getattr(runtime, "_task_store", None)
        if task_store is None:
            return
        tasks = task_store.list_tasks()
        tasks_payload = [t.model_dump(mode="json") for t in tasks]
        list_id = task_store.list_id_value()
        ctx = getattr(runtime, "_context", None)
        record_tool_event = getattr(ctx, "record_tool_event", None)
        if callable(record_tool_event):
            record_tool_event(
                tool_name="TaskList",
                payload={"tasks": tasks_payload, "list_id": list_id},
            )
            logger.debug(
                f"[Team 模式] 父侧 task 状态已刷新: list_id={list_id!r}, "
                f"tasks={len(tasks_payload)}"
            )
    except Exception as exc:
        logger.debug(f"[Team 模式] 刷新父侧 task 状态失败（忽略）: {exc}")


# ── 核心工厂函数 ──────────────────────────────────────────────────────────


def create_agent_tool(
    agents: list[AgentDefinition],
    parent_tools: list[Tool],
    tool_registry: ToolRegistry,
    parent_cwd: Path,
    parent_llm: BaseChatModel,
    parent_dependency_overrides: DependencyOverrides | None = None,
    parent_llm_levels: dict[LLMLevel, BaseChatModel] | None = None,
    parent_token_cost: TokenCost | None = None,
    parent_runtime: "AgentRuntime | None" = None,
    use_streaming_task: bool = False,
    parent_user_instruction: object | None = None,
    parent_env_options: object | None = None,
) -> Tool:
    """创建 Agent 工具，用于启动 Subagent。

    Args:
        agents: AgentDefinition 列表
        parent_tools: 父 Agent 当前可见的工具列表（用于继承与动态工具解析）
        tool_registry: 全局工具注册表
        parent_llm: 父 Agent 的 LLM 实例
        parent_dependency_overrides: 父 Agent 的依赖覆盖（会继承给 Subagent）
        parent_llm_levels: 父 Agent 的三档模型池
        parent_token_cost: 父 Agent 的 token cost
        parent_runtime: 父 Agent runtime 引用（用于实时读取 task_namespace，避免闭包静态捕获）
        use_streaming_task: 是否使用流式 Agent（发射子事件，用于实时 UI 显示）

    Returns:
        Agent 工具实例
    """
    # 构建 subagent 名称映射
    agent_map = {a.name: a for a in agents}

    def _configure_shared_auto_memory(
        *,
        runtime: "AgentRuntime",
        agent_def: AgentDefinition,
    ) -> None:
        if not agent_def.shared_auto_memory:
            return
        if parent_runtime is None:
            logger.warning(
                f"Subagent '{agent_def.name}' requested shared auto memory but parent_runtime is missing"
            )
            return

        from comate_agent_sdk.agent.setup import resolve_auto_memory_dir, setup_memory_usage

        shared_auto_memory_dir = resolve_auto_memory_dir(parent_runtime)
        setattr(runtime, "_shared_auto_memory_dir", shared_auto_memory_dir)
        setup_memory_usage(runtime)

    def _resolve_subagent_tools(
        agent_def: AgentDefinition,
        *,
        in_team_mode: bool,
    ) -> tuple[list[Tool], list[str]]:
        """解析 subagent 可用工具列表。

        规则：
        - agent_def.tools is None：继承父 Agent 工具（排除永远隐藏的工具，Task* 可见性由 init.py 决定）
        - agent_def.tools 是列表：按名称解析（优先从 parent_tools 解析动态工具；再从 registry 解析）
        - 显式工具白名单 + allow_team_coordination=True + Team 模式：
          在白名单后补入协作工具（Task* / SendMessage）

        注意：这里只过滤 _ALWAYS_HIDDEN（包括 Agent / AskUserQuestion / TaskCreate）。
        TaskList / TaskGet / TaskUpdate 的可见性由 init.py 中的
        visible_tools(is_team_member=...) 统一处理，避免双重过滤。
        """
        from comate_agent_sdk.agent.tool_visibility import (
            TEAM_COORDINATION_TOOL_NAMES,
            _ALWAYS_HIDDEN,
        )

        parent_map = {t.name: t for t in parent_tools}

        if agent_def.tools is None:
            tools = [t for t in parent_tools if t.name not in _ALWAYS_HIDDEN]
            return tools, []

        resolved: list[Tool] = []
        missing: list[str] = []
        seen: set[str] = set()
        missing_seen: set[str] = set()

        def _append_tool(name: str) -> None:
            if name in _ALWAYS_HIDDEN:
                return
            if name in seen:
                return
            if name in parent_map:
                resolved.append(parent_map[name])
                seen.add(name)
                return
            if name in tool_registry:
                resolved.append(tool_registry.get(name))
                seen.add(name)
                return
            if name not in missing_seen:
                missing.append(name)
                missing_seen.add(name)

        for name in agent_def.tools or []:
            _append_tool(name)

        if in_team_mode and agent_def.allow_team_coordination:
            for name in TEAM_COORDINATION_TOOL_NAMES:
                _append_tool(name)

        return resolved, missing

    _resolved_model_names: dict[str, str] = {}

    async def _build_subagent_runtime(
        subagent_type: str,
        tool_call_id: str | None,
        *,
        team_name: str = "",
        name: str = "",
        isolation: str = "",
        level: str = "",
    ) -> tuple:
        """创建 subagent runtime。返回 (runtime, agent_def, worktree_dir)。

        统一处理：agent_map 查找、模型解析、工具解析、身份注入、worktree 创建、
        AgentTemplate 构建、Skills 筛选。
        """
        from comate_agent_sdk.agent import AgentConfig, AgentTemplate

        if subagent_type not in agent_map:
            available = ", ".join(agent_map.keys())
            raise ValueError(
                f"Unknown subagent '{subagent_type}'. Available: {available}"
            )

        agent_def = agent_map[subagent_type]

        # ── 参数处理 + sentinel 防御 ──
        from comate_agent_sdk.system_tools.team.tools import _TEAM_NAME_BLACKLIST

        effective_name = name.strip() or agent_def.name
        # name 参数的 sentinel 防御
        if effective_name.lower() in _TEAM_NAME_BLACKLIST:
            logger.warning(f"name sentinel 值 '{name}' 被过滤，使用 agent_def.name")
            effective_name = agent_def.name

        # team_name sentinel 防御
        effective_team_name = team_name.strip()
        if effective_team_name.lower() in _TEAM_NAME_BLACKLIST:
            logger.warning(
                f"team_name sentinel 值 '{team_name}' 被过滤为空"
            )
            effective_team_name = ""

        # Team 必须已通过 TeamCreate 创建
        if effective_team_name:
            team_cfg = TeamConfig(team_name=effective_team_name)
            if not team_cfg.path.exists():
                raise ValueError(
                    f"Team '{effective_team_name}' does not exist. "
                    f"Create it first with TeamCreate."
                )

        # 解析模型
        override = level if level else None
        llm = resolve_model(
            model=agent_def.model,
            level=agent_def.level,
            parent_llm=parent_llm,
            llm_levels=parent_llm_levels,
            override_level=override,
        )

        # 解析工具
        tools, missing_tools = _resolve_subagent_tools(
            agent_def,
            in_team_mode=bool(effective_team_name),
        )
        if missing_tools:
            logger.warning(
                f"Subagent '{subagent_type}' requested missing tool(s): {missing_tools}"
            )

        logger.info(
            f"Creating subagent runtime '{subagent_type}' with {len(tools)} tool(s): "
            f"{[t.name for t in tools]}"
        )

        # 实时读取父 runtime 的当前 task namespace（修复闭包静态捕获问题）
        parent_task_namespace = parent_runtime._task_namespace if parent_runtime else None
        effective_task_ns = effective_team_name or parent_task_namespace or ""

        # 身份上下文注入（追加到系统提示尾部）
        effective_prompt = agent_def.prompt
        if effective_name != agent_def.name:
            identity_prompt = render_prompt(
                load_prompt("subagent/identity_injection.md"),
                variables={"INSTANCE_NAME": effective_name},
                source="subagent/identity_injection.md",
            )
            effective_prompt = (
                f"{effective_prompt}\n\n"
                f"{identity_prompt}\n"
            )
        # Team 协调上下文通过 query_stream 中的 runtime coordination context
        # 动态注入，不再静态写入 system prompt。

        # Worktree 隔离
        worktree_dir: Path | None = None
        branch_name: str = ""
        effective_cwd = parent_cwd

        if isolation.strip().lower() == "worktree":
            worktree_dir, branch_name = _create_worktree(parent_cwd)
            effective_cwd = worktree_dir

        # 创建 SubagentTemplate + Runtime
        subagent_template = AgentTemplate(
            name=effective_name,
            llm=llm,
            config=AgentConfig(
                tools=tuple(tools),
                system_prompt=effective_prompt,
                max_iterations=agent_def.max_iterations,
                compaction=agent_def.compaction,
                dependency_overrides=parent_dependency_overrides,
                llm_levels=parent_llm_levels,
                agents=(),
                user_instruction=parent_user_instruction,
                env_options=parent_env_options,
            ),
        )
        subagent_runtime = subagent_template.create_runtime(
            cwd=effective_cwd,
            task_namespace=effective_task_ns,
            team_name=effective_team_name,
            parent_token_cost=parent_token_cost,
            is_subagent=True,
            name=effective_name,
            subagent_run_id=tool_call_id,
        )
        _configure_shared_auto_memory(
            runtime=subagent_runtime,
            agent_def=agent_def,
        )
        setattr(
            subagent_runtime,
            "_extra_write_roots",
            tuple(agent_def.extra_write_roots or ()),
        )

        # 挂载 worktree 信息到 runtime（供流式路径使用）
        setattr(subagent_runtime, "_worktree_dir", worktree_dir)
        setattr(subagent_runtime, "_worktree_branch", branch_name)
        setattr(subagent_runtime, "_worktree_parent_cwd", parent_cwd)

        # B2: Team Config 注册（仅注册 subagent，leader 已由 TeamCreate 完成）
        if effective_team_name:
            _register_team_members(
                team_name=effective_team_name,
                parent_runtime=None,  # 不再注册 parent 为 leader
                subagent_name=effective_name,
                subagent_type=subagent_type,
            )

        # Subagent Skills 筛选
        if agent_def.skills is not None and subagent_runtime._runtime_state.skills:
            allowed_skill_names = set(agent_def.skills)
            subagent_runtime._runtime_state.skills = [
                s
                for s in subagent_runtime._runtime_state.skills
                if s.name in allowed_skill_names
            ]
            from comate_agent_sdk.skill.execution import rebuild_skill_tool
            rebuild_skill_tool(subagent_runtime)
            logger.info(
                f"Filtered subagent '{subagent_type}' skills to: "
                f"{[s.name for s in subagent_runtime._runtime_state.skills]}"
            )

        return subagent_runtime, agent_def, worktree_dir

    async def _execute_subagent_task(
        subagent_type: str,
        prompt: str,
        *,
        team_name: str = "",
        name: str = "",
        isolation: str = "",
        level: str = "",
    ) -> str:
        """subagent 执行逻辑（非流式路径）。"""
        from comate_agent_sdk.tools.system_context import get_system_tool_context

        # 对于非流式路径，agent_map 查找错误直接返回字符串
        if subagent_type not in agent_map:
            available = ", ".join(agent_map.keys())
            return f"Error: Unknown subagent '{subagent_type}'. Available: {available}"

        tool_call_id: str | None = None
        try:
            tool_ctx = get_system_tool_context()
            tool_call_id = tool_ctx.tool_call_id
        except Exception:
            tool_call_id = None

        effective_team_name = team_name.strip()
        effective_name = name.strip()

        if effective_team_name:
            if not effective_team_name:
                return "Error: team_name cannot be empty in Team mode."
            if not effective_name:
                return "Error: team_name requires a non-empty name."
            if parent_runtime is None or not parent_runtime.is_team_member:
                return (
                    "Error: team_name is only available when the leader has "
                    "already entered Team mode."
                )

            parent_team_name = str(getattr(parent_runtime, "_team_name", "") or "").strip()
            if effective_team_name != parent_team_name:
                return (
                    "Error: team_name requires a value matching the "
                    f"leader's current team ('{parent_team_name}')."
                )
            if parent_runtime.has_active_team_session(
                team_name=effective_team_name,
                name=effective_name,
            ):
                return (
                    f"Error: Team session '{effective_name}' is already active "
                    f"in team '{effective_team_name}'. Use SendMessage for follow-up."
                )

        try:
            runtime, agent_def, worktree_dir = await _build_subagent_runtime(
                subagent_type,
                tool_call_id,
                team_name=team_name,
                name=name,
                isolation=isolation,
                level=level,
            )
        except (ValueError, RuntimeError) as e:
            return f"Error: {e}"

        if tool_call_id:
            _resolved_model_names[tool_call_id] = runtime.llm.model

        branch_name = getattr(runtime, "_worktree_branch", "")

        if effective_team_name:
            from comate_agent_sdk.subagent.team_session import start_team_session

            team_session_task = start_team_session(
                runtime=runtime,
                parent_runtime=parent_runtime,
                subagent_type=subagent_type,
                initial_prompt=prompt,
                timeout_seconds=agent_def.timeout,
            )
            try:
                parent_runtime.register_team_session(
                    team_name=effective_team_name,
                    name=effective_name,
                    task=team_session_task,
                )
            except ValueError as exc:
                team_session_task.cancel()
                runtime_aclose = getattr(runtime, "aclose", None)
                if callable(runtime_aclose):
                    await runtime_aclose()
                return f"Error: {exc}"

            return (
                f"'{effective_name}' ({subagent_type}) has joined team '{effective_team_name}' and started working. \n"
                "How team communication works: \n"
                " - Send messages via SendMessage tool. \n"
                " - Receive messages automatically — they appear as new turns when ready. \n"
                ' - No polling needed. If you are only waiting, call YieldTurn(status="waiting_for_teammate"). \n'
            )

        try:
            if agent_def.timeout:
                result = await asyncio.wait_for(
                    runtime.query(prompt), timeout=agent_def.timeout
                )
            else:
                result = await runtime.query(prompt)

            logger.info(f"Subagent '{subagent_type}' completed successfully")

            # worktree 结果处理
            if worktree_dir:
                result = finalize_worktree(
                    result, worktree_dir, parent_cwd, branch_name
                )

            # A7 非流式路径：Team 模式下刷新父侧 task 状态缓存
            if parent_runtime is not None and parent_runtime.is_team_member:
                _refresh_parent_task_state(parent_runtime)

            return result

        except asyncio.TimeoutError:
            _cleanup_worktree_if_exists(worktree_dir, parent_cwd, branch_name)
            error_msg = (
                f"Error: Subagent '{subagent_type}' timeout after {agent_def.timeout}s"
            )
            logger.error(error_msg)
            return error_msg
        except Exception as e:
            _cleanup_worktree_if_exists(worktree_dir, parent_cwd, branch_name)
            error_msg = f"Error in subagent '{subagent_type}': {e}"
            logger.error(error_msg, exc_info=True)
            return error_msg

    @tool(
        "Launch a subagent for complex, multi-step tasks.",
        usage_rules=_TASK_USAGE_RULES,
    )
    async def Agent(
        params: AgentToolInput,
    ) -> str:
        return await _execute_subagent_task(
            params.subagent_type,
            params.prompt,
            team_name=params.team_name,
            name=params.name,
            isolation=params.isolation,
            level=params.level,
        )

    # 标记 Agent 工具
    setattr(Agent, _INTERNAL_AGENT_TOOL_MARKER_ATTR, _INTERNAL_AGENT_TOOL_MARKER_VALUE)
    setattr(Agent, "_resolved_model_names", _resolved_model_names)

    # 如果启用流式 Agent，附加必要的方法和标记
    if use_streaming_task:
        async def _create_subagent_runtime_for_streaming(
            subagent_type: str,
            tool_call_id: str | None,
            *,
            team_name: str = "",
            name: str = "",
            isolation: str = "",
            level: str = "",
        ):
            """创建 subagent runtime（流式路径）。
            worktree 信息已挂载到 runtime 上（_worktree_dir/_worktree_branch），
            由 query_stream.py 在流结束后处理。
            """
            runtime, agent_def, _ = await _build_subagent_runtime(
                subagent_type,
                tool_call_id,
                team_name=team_name,
                name=name,
                isolation=isolation,
                level=level,
            )
            return runtime, agent_def

        setattr(Agent, "_is_streaming_task", True)
        setattr(Agent, "_create_subagent_runtime", _create_subagent_runtime_for_streaming)
        logger.info("Agent tool configured for streaming (with SubagentToolCallEvent support)")

    return Agent


def resolve_model(
    model: str | None,
    level: LLMLevel | None,
    parent_llm: BaseChatModel,
    llm_levels: dict[LLMLevel, BaseChatModel] | None = None,
    override_level: LLMLevel | None = None,
) -> BaseChatModel:
    """解析模型配置

    Args:
        model: 模型别名（仅支持 "sonnet"/"opus"/"haiku"/"inherit"）
        level: 档位（LOW/MID/HIGH）。当 model 未指定时优先生效。
        parent_llm: 父 Agent 的 LLM 实例
        llm_levels: 父 Agent 的三档模型池
        override_level: 调用时动态覆盖的档位，最高优先级

    Returns:
        解析后的 LLM 实例

    Notes:
        - model只支持别名："sonnet"/"opus"/"haiku"/"inherit"
        - 不支持的model会被忽略，回退到level或parent_llm
    """
    # 0) override_level（调用时动态覆盖，最高优先）
    if override_level is not None:
        if llm_levels and override_level in llm_levels:
            return llm_levels[override_level]
        if not llm_levels:
            raise ValueError(
                f"override_level='{override_level}' requested but no llm_levels configured"
            )
        raise ValueError(
            f"override_level='{override_level}' not found in llm_levels (available: {list(llm_levels.keys())})"
        )

    # 1) model= 非 None 且非 "inherit"
    if model and model.strip().lower() != "inherit":
        model = model.strip()

        # 别名映射（仅支持这三个）
        alias: dict[str, LLMLevel] = {
            "sonnet": "MID",
            "opus": "HIGH",
            "haiku": "LOW"
        }

        model_lower = model.lower()

        # 检查是否为支持的alias
        if model_lower in alias:
            pool_key = alias[model_lower]

            # 尝试从llm_levels池获取
            if llm_levels and pool_key in llm_levels:
                return llm_levels[pool_key]

            # 池不存在时，使用硬编码的Anthropic模型
            hard = {
                "sonnet": lambda: ChatAnthropic(model="claude-sonnet-4-5"),
                "opus": lambda: ChatAnthropic(model="claude-opus-4-5"),
                "haiku": lambda: ChatAnthropic(model="claude-haiku-4-5"),
            }
            return hard[model_lower]()
        else:
            # 不支持的model：记录警告并忽略
            logger.warning(
                f"不支持的model值 '{model}'。仅支持别名：sonnet/opus/haiku。"
                f"将回退到level或继承父agent的模型。"
            )
            # 继续检查level

    # 2) level= 从池取
    if level is not None:
        if llm_levels and level in llm_levels:
            return llm_levels[level]
        raise ValueError(f"level='{level}' 不在 llm_levels 中")

    # 3) 默认继承
    return parent_llm


def rebuild_agent_tool(agent: "AgentRuntime") -> None:
    """Plugin agents 变更后，重建 Agent tool（description + agent_map 刷新）。

    仿照 rebuild_skill_tool() 的三步模式：
    1. 移除旧 Agent tool
    2. 更新 subagent_strategy prompt
    3. 创建新 Agent tool
    """
    from comate_agent_sdk.agent.session_store import normalize_cwd

    # 1. 移除旧 Agent tool
    agent._runtime_state.tools[:] = [
        t for t in agent._runtime_state.tools if t.name != "Agent"
    ]
    agent._tool_map.pop("Agent", None)

    # 2. 更新 subagent_strategy prompt + 重建 Agent tool
    # 注意：不调用 remove_subagent_strategy()，因为 builtin agents 始终存在，
    # agents 列表永远非空，set_subagent_strategy() 幂等覆盖即可。
    # 这与 rebuild_skill_tool() 先 remove 再 set 的模式有意不同。
    if agent._runtime_state.agents:
        subagent_prompt = generate_subagent_prompt(agent._runtime_state.agents)
        agent._context.set_subagent_strategy(subagent_prompt)

        new_tool = create_agent_tool(
            agents=agent._runtime_state.agents,
            parent_tools=agent._runtime_state.tools,
            tool_registry=agent._runtime_state.tool_registry,
            parent_cwd=normalize_cwd(agent._runtime_state.cwd),
            parent_llm=agent.llm,
            parent_dependency_overrides=agent.config.dependency_overrides,
            parent_llm_levels=agent._runtime_state.llm_levels,
            parent_token_cost=agent._token_cost,
            parent_runtime=agent,
            use_streaming_task=agent.config.use_streaming_task,
            parent_user_instruction=agent._runtime_state.user_instruction,
            parent_env_options=agent.config.env_options,
        )
        agent._runtime_state.tools.append(new_tool)
        agent._tool_map["Agent"] = new_tool
        logger.debug(
            "Rebuilt Agent tool with %d agent(s)",
            len(agent._runtime_state.agents),
        )
    else:
        logger.debug("Removed Agent tool (no agents remaining)")
