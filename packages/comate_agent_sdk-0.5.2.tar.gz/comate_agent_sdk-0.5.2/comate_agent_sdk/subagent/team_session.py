from __future__ import annotations

import asyncio
import contextlib
import logging
import uuid
from dataclasses import dataclass
from pathlib import Path
from typing import TYPE_CHECKING

from comate_agent_sdk.agent.chat_session import ChatSession
from comate_agent_sdk.agent.events import ExternalTurnScheduledEvent, SessionInitEvent, StopEvent, TeamMessageEvent, TextEvent, ToolResultEvent
from comate_agent_sdk.context.items import ItemType
from comate_agent_sdk.system_tools.team.config import TeamConfig
from comate_agent_sdk.system_tools.team.identity import resolve_runtime_team_agent_name

if TYPE_CHECKING:
    from comate_agent_sdk.agent.core.runtime import AgentRuntime

logger = logging.getLogger("comate_agent_sdk.subagent.team_session")


def _truncate_message(text: str, *, max_chars: int = 1200) -> str:
    normalized = str(text or "").strip()
    if len(normalized) <= max_chars:
        return normalized
    return f"{normalized[:max_chars]}\n...(truncated)"


def _resolve_leader_recipients(team_name: str, sender_name: str) -> list[str]:
    try:
        from comate_agent_sdk.system_tools.team.inbox import get_all_inboxes

        team_cfg = TeamConfig(team_name=team_name)
        leaders = [
            str(member.get("name", "")).strip()
            for member in team_cfg.list_members()
            if member.get("agent_type") == "leader"
            and str(member.get("name", "")).strip()
            and str(member.get("name", "")).strip() != sender_name
        ]
        if leaders:
            return leaders
        return [
            recipient
            for recipient in get_all_inboxes(team_name)
            if recipient.strip() and recipient.strip() != sender_name
        ]
    except Exception as exc:
        logger.debug(f"[Team session] Failed to resolve leader recipients: {exc}")
        return []


def send_team_session_status_message(
    *,
    team_name: str,
    sender_name: str,
    subagent_type: str,
    status: str,
    content: str,
) -> None:
    try:
        from comate_agent_sdk.system_tools.team.inbox import Inbox, MessageType

        recipients = _resolve_leader_recipients(team_name, sender_name)
        if not recipients:
            logger.debug(
                f"[Team session] No leader recipient found: "
                f"team={team_name!r} sender={sender_name!r}"
            )
            return

        preview = _truncate_message(content)
        message = f"Team session '{sender_name}' ({subagent_type}) {status}."
        if preview:
            message = f"{message}\n\n{preview}"

        for recipient in recipients:
            inbox = Inbox(team_name=team_name, agent_name=recipient)
            inbox.append_message(
                from_agent=sender_name,
                message_type=MessageType.MESSAGE,
                content=message,
            )
    except Exception as exc:
        logger.warning(
            f"[Team session] Failed to send status message: "
            f"team={team_name!r} sender={sender_name!r} status={status!r}: {exc}",
            exc_info=True,
        )


def send_team_session_direct_message(
    *,
    team_name: str,
    sender_name: str,
    content: str,
) -> None:
    try:
        from comate_agent_sdk.system_tools.team.inbox import Inbox, MessageType

        normalized_content = str(content or "").strip()
        if not normalized_content:
            return

        recipients = _resolve_leader_recipients(team_name, sender_name)
        if not recipients:
            logger.debug(
                f"[Team session] No leader recipient found for direct reply: "
                f"team={team_name!r} sender={sender_name!r}"
            )
            return

        for recipient in recipients:
            inbox = Inbox(team_name=team_name, agent_name=recipient)
            inbox.append_message(
                from_agent=sender_name,
                message_type=MessageType.MESSAGE,
                content=normalized_content,
            )
    except Exception as exc:
        logger.warning(
            f"[Team session] Failed to send direct message: "
            f"team={team_name!r} sender={sender_name!r}: {exc}",
            exc_info=True,
        )


@dataclass(slots=True)
class TeamSessionActor:
    session: ChatSession
    runtime: "AgentRuntime"
    parent_runtime: "AgentRuntime | None"
    subagent_type: str
    team_name: str
    agent_name: str
    initial_prompt: str
    timeout_seconds: float | None = None

    async def run(self) -> None:
        terminal_status = ""
        terminal_content = ""
        shutdown_recipients: list[str] = []
        current_turn_text = ""
        current_turn_sent_message = False
        try:
            self.session._queue.put_nowait(self.initial_prompt)

            async for event in self.session.events():
                if isinstance(event, (ExternalTurnScheduledEvent, SessionInitEvent)):
                    current_turn_text = ""
                    current_turn_sent_message = False
                elif isinstance(event, TextEvent):
                    normalized = str(event.content or "").strip()
                    if normalized:
                        current_turn_text = normalized
                elif isinstance(event, ToolResultEvent) and not event.is_error:
                    if event.tool == "SendMessage":
                        current_turn_sent_message = True
                elif isinstance(event, StopEvent):
                    if event.reason == "shutdown_request":
                        shutdown_recipients = list(event.metadata.get("shutdown_recipients", []))
                        terminal_status = "shutdown"
                        break
                    last_yield_status = ""
                    last_send_to = ""
                    current_turn_number = max(0, int(self.runtime._context.turn_number or 0))
                    for item in reversed(self.runtime._context.conversation.items):
                        item_turn = max(0, int(getattr(item, "created_turn", 0) or 0))
                        if item_turn < current_turn_number:
                            break
                        if item_turn != current_turn_number:
                            continue
                        if item.item_type != ItemType.TOOL_RESULT or bool(item.is_tool_error):
                            continue
                        tool_name = str(item.tool_name or "").strip()
                        envelope = (item.metadata or {}).get("tool_raw_envelope")
                        if not isinstance(envelope, dict):
                            continue
                        data = envelope.get("data")
                        if not isinstance(data, dict):
                            continue
                        if tool_name == "YieldTurn" and not last_yield_status:
                            last_yield_status = str(data.get("yield_status", "") or "").strip()
                        elif tool_name == "SendMessage" and not last_send_to:
                            last_send_to = str(data.get("to", "") or "").strip()
                        if last_yield_status and last_send_to:
                            break
                    self._handle_turn_completed(
                        event.reason,
                        current_turn_text,
                        current_turn_sent_message,
                        last_yield_status,
                        last_send_to,
                    )
        except asyncio.TimeoutError:
            terminal_status = "timed out"
            terminal_content = (
                f"Turn timed out after {self.timeout_seconds}s. "
                "The session has been stopped."
            )
        except asyncio.CancelledError:
            terminal_status = "cancelled"
            raise
        except Exception as exc:
            terminal_status = "failed"
            terminal_content = f"Actor crashed: {exc}"
            logger.error(
                f"Team session actor failed: team={self.team_name!r} "
                f"agent={self.agent_name!r} error={exc}",
                exc_info=True,
            )
        finally:
            worktree_note = self._finalize_terminal_worktree_note()
            if terminal_status in ("failed", "timed out"):
                message = terminal_content
                if worktree_note:
                    message = f"{message}\n\n{worktree_note}"
                send_team_session_status_message(
                    team_name=self.team_name,
                    sender_name=self.agent_name,
                    subagent_type=self.subagent_type,
                    status=terminal_status,
                    content=message,
                )
            elif terminal_status == "shutdown" and shutdown_recipients:
                from comate_agent_sdk.agent.runner_engine.team_coordination import _send_team_shutdown_response

                _send_team_shutdown_response(
                    self.runtime,
                    recipients=shutdown_recipients,
                    extra_content=worktree_note,
                )
            elif terminal_status == "cancelled" and worktree_note:
                logger.info(
                    f"[Team session] Cancelled with preserved worktree: "
                    f"team={self.team_name!r} agent={self.agent_name!r}\n{worktree_note}"
                )
            with contextlib.suppress(Exception):
                await self.session.shutdown()

    def _handle_turn_completed(
        self,
        stop_reason: str,
        final_text: str,
        sent_message: bool,
        yield_status: str = "",
        last_send_to: str = "",
    ) -> None:
        self._refresh_parent_task_state()
        if stop_reason == "completed" and final_text and not sent_message:
            send_team_session_direct_message(
                team_name=self.team_name,
                sender_name=self.agent_name,
                content=final_text,
            )
        if stop_reason in {"waiting_for_input", "waiting_for_plan_approval"}:
            send_team_session_status_message(
                team_name=self.team_name,
                sender_name=self.agent_name,
                subagent_type=self.subagent_type,
                status="requires unsupported interaction",
                content=(
                    f"Turn stopped with reason={stop_reason!r}. "
                    "Team sessions must coordinate via SendMessage only."
                ),
            )
        elif stop_reason == "max_iterations":
            send_team_session_status_message(
                team_name=self.team_name,
                sender_name=self.agent_name,
                subagent_type=self.subagent_type,
                status="hit max iterations",
                content=(
                    "Turn reached max_iterations. "
                    "This requires leader attention before any follow-up work is assigned."
                ),
            )
        if stop_reason in {"completed", "yielded"}:
            from comate_agent_sdk.agent.runner_engine.team_coordination import _send_team_idle_notification

            _runtime_team = getattr(self.runtime, "_team", None)
            if _runtime_team is not None:
                _runtime_team.suppress_idle_notification = False
            try:
                _send_team_idle_notification(
                    self.runtime,
                    stop_reason=stop_reason,
                    yield_status=yield_status,
                    last_send_to=last_send_to,
                )
            finally:
                if _runtime_team is not None:
                    _runtime_team.suppress_idle_notification = True

    def _refresh_parent_task_state(self) -> None:
        if self.parent_runtime is None or not self.parent_runtime.is_team_member:
            return
        try:
            from comate_agent_sdk.subagent.agent_tool import _refresh_parent_task_state

            _refresh_parent_task_state(self.parent_runtime)
        except Exception as exc:
            logger.debug(
                f"[Team session] Failed to refresh parent task state: "
                f"team={self.team_name!r} agent={self.agent_name!r} error={exc}"
            )

    def _finalize_terminal_worktree_note(self) -> str:
        worktree_dir = getattr(self.runtime, "_worktree_dir", None)
        branch_name = str(getattr(self.runtime, "_worktree_branch", "") or "").strip()
        parent_cwd = getattr(self.runtime, "_worktree_parent_cwd", None)
        if not isinstance(worktree_dir, Path) or not isinstance(parent_cwd, Path):
            return ""

        from comate_agent_sdk.subagent.agent_tool import (
            _cleanup_worktree_if_exists,
            _worktree_has_changes,
        )

        if _worktree_has_changes(worktree_dir):
            return (
                "[Worktree Result]\n"
                f"worktree_path: {worktree_dir}\n"
                f"worktree_branch: {branch_name}\n"
                "has_changes: true"
            )

        _cleanup_worktree_if_exists(worktree_dir, parent_cwd, branch_name)
        return ""


def start_team_session(
    *,
    runtime: "AgentRuntime",
    parent_runtime: "AgentRuntime | None",
    subagent_type: str,
    initial_prompt: str,
    timeout_seconds: float | None,
) -> asyncio.Task[None]:
    _runtime_team = getattr(runtime, "_team", None)
    if _runtime_team is not None:
        _runtime_team.suppress_idle_notification = True

    # 若有 parent_runtime，为 subagent 的 inbox polling 注册转发回调，
    # 使 subagent 收到的 team 消息通过 parent_runtime 流入 leader 的 scrollback。
    if parent_runtime is not None:
        _parent_team = getattr(parent_runtime, "_team", None)

        def _forward_team_message(event: TeamMessageEvent) -> None:
            cb = _parent_team.team_message_event_callback if _parent_team is not None else None
            if callable(cb):
                cb(event)
        if _runtime_team is not None:
            _runtime_team.team_message_event_callback = _forward_team_message

    session_id = str(uuid.uuid4())
    runtime._session_id = session_id

    session = ChatSession(
        runtime.template,
        runtime=runtime,
        session_id=session_id,
        cwd=runtime._runtime_state.cwd,
        turn_timeout=timeout_seconds,
    )
    session._header_persisted = False
    session._persist_session_metadata(force=True)
    session._restore_task_state_from_task_store()
    agent_name = resolve_runtime_team_agent_name(
        runtime_name=runtime.name,
        is_subagent=bool(runtime._is_subagent),
    )
    actor = TeamSessionActor(
        session=session,
        runtime=runtime,
        parent_runtime=parent_runtime,
        subagent_type=subagent_type,
        team_name=runtime._team_name,
        agent_name=agent_name,
        initial_prompt=initial_prompt,
        timeout_seconds=timeout_seconds,
    )
    return asyncio.create_task(
        actor.run(),
        name=f"team-session:{runtime._team_name}:{agent_name}",
    )
