import unittest

from comate_agent_sdk.subagent.models import AgentDefinition
from comate_agent_sdk.subagent.prompts import generate_subagent_prompt


class TestSubagentPrompts(unittest.TestCase):
    def test_generate_subagent_prompt_renders_markdown_template(self) -> None:
        prompt = generate_subagent_prompt(
            [
                AgentDefinition(
                    name="plan",
                    description="Plan implementation",
                    prompt="You are a planner.",
                ),
                AgentDefinition(
                    name="explorer",
                    description="Explore codebase",
                    prompt="You are an explorer.",
                ),
            ]
        )

        self.assertIn("<subagent>", prompt)
        self.assertIn("- **plan**: Plan implementation", prompt)
        self.assertIn("- **explorer**: Explore codebase", prompt)
        self.assertIn("<subagent_use>", prompt)
        self.assertNotIn("{{Subagents}}", prompt)


if __name__ == "__main__":
    unittest.main(verbosity=2)
