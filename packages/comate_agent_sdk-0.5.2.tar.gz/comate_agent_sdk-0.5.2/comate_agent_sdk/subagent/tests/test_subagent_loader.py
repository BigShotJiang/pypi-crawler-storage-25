from __future__ import annotations

import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from comate_agent_sdk.subagent.loader import discover_subagents


class TestSubagentLoader(unittest.TestCase):
    def test_discover_subagents_accepts_str_project_root(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td) / "project"
            agents_dir = root / ".agent" / "agents"
            agents_dir.mkdir(parents=True)
            (agents_dir / "reviewer.md").write_text(
                "---\nname: reviewer\ndescription: review things\n---\nReview code.",
                encoding="utf-8",
            )

            with patch("comate_agent_sdk.subagent.loader.Path.home", return_value=Path(td) / "home"):
                agents = discover_subagents(project_root=str(root))

        self.assertEqual([agent.name for agent in agents], ["reviewer"])

    def test_discover_subagents_with_namespace(self) -> None:
        """子目录内的 .md 文件应以父目录名为 namespace"""
        with tempfile.TemporaryDirectory() as td:
            root = Path(td) / "project"
            ns_dir = root / ".agent" / "agents" / "superpowers"
            ns_dir.mkdir(parents=True)
            (ns_dir / "code-reviewer.md").write_text(
                "---\nname: code-reviewer\ndescription: review code\n---\nReview.",
                encoding="utf-8",
            )

            with patch("comate_agent_sdk.subagent.loader.Path.home", return_value=Path(td) / "home"):
                agents = discover_subagents(project_root=str(root))

        self.assertEqual(len(agents), 1)
        self.assertEqual(agents[0].name, "superpowers:code-reviewer")

    def test_discover_subagents_namespace_and_flat_coexist(self) -> None:
        """根目录 .md 和子目录 .md 应该共存"""
        with tempfile.TemporaryDirectory() as td:
            root = Path(td) / "project"
            agents_dir = root / ".agent" / "agents"
            agents_dir.mkdir(parents=True)

            (agents_dir / "explorer.md").write_text(
                "---\nname: explorer\ndescription: explore\n---\nExplore.",
                encoding="utf-8",
            )

            ns_dir = agents_dir / "mygroup"
            ns_dir.mkdir()
            (ns_dir / "reviewer.md").write_text(
                "---\nname: reviewer\ndescription: review\n---\nReview.",
                encoding="utf-8",
            )

            with patch("comate_agent_sdk.subagent.loader.Path.home", return_value=Path(td) / "home"):
                agents = discover_subagents(project_root=str(root))

        names = sorted(a.name for a in agents)
        self.assertEqual(names, ["explorer", "mygroup:reviewer"])

    def test_discover_subagents_namespace_only_project_still_wins(self) -> None:
        """project 只有 namespace 子目录（无根 .md）时仍走 project 路径"""
        with tempfile.TemporaryDirectory() as td:
            root = Path(td) / "project"
            home = Path(td) / "home"

            user_dir = home / ".agent" / "agents"
            user_dir.mkdir(parents=True)
            (user_dir / "user-agent.md").write_text(
                "---\nname: user-agent\ndescription: from user\n---\nUser.",
                encoding="utf-8",
            )

            proj_ns = root / ".agent" / "agents" / "grp"
            proj_ns.mkdir(parents=True)
            (proj_ns / "proj-agent.md").write_text(
                "---\nname: proj-agent\ndescription: from project\n---\nProject.",
                encoding="utf-8",
            )

            with patch("comate_agent_sdk.subagent.loader.Path.home", return_value=home):
                agents = discover_subagents(project_root=str(root))

        names = [a.name for a in agents]
        self.assertEqual(names, ["grp:proj-agent"])

    def test_discover_subagents_namespace_project_overrides_user(self) -> None:
        """project 和 user 都有 namespace agents 时只用 project"""
        with tempfile.TemporaryDirectory() as td:
            root = Path(td) / "project"
            home = Path(td) / "home"

            user_ns = home / ".agent" / "agents" / "grp"
            user_ns.mkdir(parents=True)
            (user_ns / "agent.md").write_text(
                "---\nname: shared-agent\ndescription: from user\n---\nUser.",
                encoding="utf-8",
            )

            proj_ns = root / ".agent" / "agents" / "grp"
            proj_ns.mkdir(parents=True)
            (proj_ns / "agent.md").write_text(
                "---\nname: shared-agent\ndescription: from project\n---\nProject.",
                encoding="utf-8",
            )

            with patch("comate_agent_sdk.subagent.loader.Path.home", return_value=home):
                agents = discover_subagents(project_root=str(root))

        self.assertEqual(len(agents), 1)
        self.assertEqual(agents[0].name, "grp:shared-agent")
        self.assertEqual(agents[0].description, "from project")

    def test_has_agent_definitions_boundary_cases(self) -> None:
        """_has_agent_definitions 的边界 case 覆盖"""
        from comate_agent_sdk.subagent.loader import _has_agent_definitions

        with tempfile.TemporaryDirectory() as td:
            base = Path(td)

            # 空目录 → False
            empty = base / "empty"
            empty.mkdir()
            self.assertFalse(_has_agent_definitions(empty))

            # 有子目录但子目录内无 .md → False
            has_subdir = base / "has_subdir"
            (has_subdir / "sub").mkdir(parents=True)
            self.assertFalse(_has_agent_definitions(has_subdir))

            # 根目录有 .md → True
            has_root_md = base / "has_root_md"
            has_root_md.mkdir()
            (has_root_md / "agent.md").write_text("test", encoding="utf-8")
            self.assertTrue(_has_agent_definitions(has_root_md))

            # 仅子目录有 .md → True
            only_sub_md = base / "only_sub_md"
            sub = only_sub_md / "group"
            sub.mkdir(parents=True)
            (sub / "agent.md").write_text("test", encoding="utf-8")
            self.assertTrue(_has_agent_definitions(only_sub_md))


if __name__ == "__main__":
    unittest.main(verbosity=2)
