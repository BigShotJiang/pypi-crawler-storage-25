import unittest

from comate_agent_sdk.subagent.builtin.explorer import ExplorerAgent
from comate_agent_sdk.subagent.builtin.general_purpose import GeneralPurposeAgent
from comate_agent_sdk.subagent.builtin.plan import PlanAgent


class TestBuiltinGeneralPurpose(unittest.TestCase):
    def test_general_purpose_prompt_is_rendered_from_template(self) -> None:
        self.assertIn("You are Comate CLI", GeneralPurposeAgent.prompt)
        self.assertIn("<tool_calling_rules>", GeneralPurposeAgent.prompt)
        self.assertNotIn("{{SYSTEM_ROLE}}", GeneralPurposeAgent.prompt)

    def test_explorer_prompt_is_loaded_from_template(self) -> None:
        self.assertIn("READ-ONLY exploration task", ExplorerAgent.prompt)
        self.assertIn("Return file paths as absolute paths", ExplorerAgent.prompt)

    def test_plan_prompt_is_loaded_from_template(self) -> None:
        self.assertIn("READ-ONLY planning task", PlanAgent.prompt)
        self.assertIn("### Critical Files for Implementation", PlanAgent.prompt)


if __name__ == "__main__":
    unittest.main(verbosity=2)
