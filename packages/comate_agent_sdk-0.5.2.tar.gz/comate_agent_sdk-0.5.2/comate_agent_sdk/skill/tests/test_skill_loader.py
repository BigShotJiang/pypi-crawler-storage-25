from __future__ import annotations

import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from comate_agent_sdk.skill.loader import discover_skills


class TestSkillLoader(unittest.TestCase):
    def test_discover_skills_accepts_str_project_root(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td) / "project"
            skill_dir = root / ".agent" / "skills" / "demo"
            skill_dir.mkdir(parents=True)
            (skill_dir / "SKILL.md").write_text(
                "---\nname: demo\ndescription: demo skill\n---\nUse demo.",
                encoding="utf-8",
            )

            with patch("comate_agent_sdk.skill.loader.Path.home", return_value=Path(td) / "home"):
                skills = discover_skills(project_root=str(root))

        self.assertEqual([skill.name for skill in skills], ["demo"])


    def test_discover_skills_with_namespace(self) -> None:
        """父目录无 SKILL.md 时应作为 namespace，扫描子目录"""
        with tempfile.TemporaryDirectory() as td:
            root = Path(td) / "project"
            ns_dir = root / ".agent" / "skills" / "superpowers"
            skill1 = ns_dir / "executing-plans"
            skill1.mkdir(parents=True)
            (skill1 / "SKILL.md").write_text(
                "---\ndescription: plan executor\n---\nExecute plans.",
                encoding="utf-8",
            )
            skill2 = ns_dir / "verification"
            skill2.mkdir(parents=True)
            (skill2 / "SKILL.md").write_text(
                "---\ndescription: verifier\n---\nVerify things.",
                encoding="utf-8",
            )

            with patch("comate_agent_sdk.skill.loader.Path.home", return_value=Path(td) / "home"):
                skills = discover_skills(project_root=str(root))

        names = sorted(s.name for s in skills)
        self.assertEqual(names, ["superpowers:executing-plans", "superpowers:verification"])

    def test_discover_skills_namespace_and_flat_coexist(self) -> None:
        """裸名 skill 和带 namespace 的 skill 应该共存"""
        with tempfile.TemporaryDirectory() as td:
            root = Path(td) / "project"
            skills_dir = root / ".agent" / "skills"

            flat = skills_dir / "my-skill"
            flat.mkdir(parents=True)
            (flat / "SKILL.md").write_text(
                "---\ndescription: flat skill\n---\nFlat.",
                encoding="utf-8",
            )

            ns_skill = skills_dir / "group" / "nested-skill"
            ns_skill.mkdir(parents=True)
            (ns_skill / "SKILL.md").write_text(
                "---\ndescription: nested skill\n---\nNested.",
                encoding="utf-8",
            )

            with patch("comate_agent_sdk.skill.loader.Path.home", return_value=Path(td) / "home"):
                skills = discover_skills(project_root=str(root))

        names = sorted(s.name for s in skills)
        self.assertEqual(names, ["group:nested-skill", "my-skill"])

    def test_discover_skills_namespace_frontmatter_overrides_short_name(self) -> None:
        """frontmatter name 只覆盖短名，namespace 由目录决定"""
        with tempfile.TemporaryDirectory() as td:
            root = Path(td) / "project"
            skill_dir = root / ".agent" / "skills" / "superpowers" / "exec-plans"
            skill_dir.mkdir(parents=True)
            (skill_dir / "SKILL.md").write_text(
                "---\nname: my-plan\ndescription: custom name\n---\nPlan.",
                encoding="utf-8",
            )

            with patch("comate_agent_sdk.skill.loader.Path.home", return_value=Path(td) / "home"):
                skills = discover_skills(project_root=str(root))

        self.assertEqual(skills[0].name, "superpowers:my-plan")

    def test_discover_skills_namespace_project_overrides_user(self) -> None:
        """project 级 namespace skill 覆盖同名 user 级 namespace skill"""
        with tempfile.TemporaryDirectory() as td:
            root = Path(td) / "project"
            home = Path(td) / "home"

            user_skill = home / ".agent" / "skills" / "grp" / "foo"
            user_skill.mkdir(parents=True)
            (user_skill / "SKILL.md").write_text(
                "---\ndescription: user version\n---\nUser.",
                encoding="utf-8",
            )

            proj_skill = root / ".agent" / "skills" / "grp" / "foo"
            proj_skill.mkdir(parents=True)
            (proj_skill / "SKILL.md").write_text(
                "---\ndescription: project version\n---\nProject.",
                encoding="utf-8",
            )

            with patch("comate_agent_sdk.skill.loader.Path.home", return_value=home):
                skills = discover_skills(project_root=str(root))

        self.assertEqual(len(skills), 1)
        self.assertEqual(skills[0].name, "grp:foo")
        self.assertEqual(skills[0].description, "project version")

    def test_discover_skills_dir_with_skill_md_not_treated_as_namespace(self) -> None:
        """目录内既有 SKILL.md 又有子目录时，视为 skill 目录而非 namespace"""
        with tempfile.TemporaryDirectory() as td:
            root = Path(td) / "project"
            skill_dir = root / ".agent" / "skills" / "hybrid"
            skill_dir.mkdir(parents=True)
            (skill_dir / "SKILL.md").write_text(
                "---\ndescription: hybrid skill\n---\nHybrid.",
                encoding="utf-8",
            )
            child = skill_dir / "child"
            child.mkdir()
            (child / "SKILL.md").write_text(
                "---\ndescription: child skill\n---\nChild.",
                encoding="utf-8",
            )

            with patch("comate_agent_sdk.skill.loader.Path.home", return_value=Path(td) / "home"):
                skills = discover_skills(project_root=str(root))

        names = [s.name for s in skills]
        self.assertEqual(names, ["hybrid"])

    def test_discover_skills_empty_namespace_dir_skipped(self) -> None:
        """namespace 目录内无合法 skill 时静默跳过"""
        with tempfile.TemporaryDirectory() as td:
            root = Path(td) / "project"
            empty_ns = root / ".agent" / "skills" / "empty-group"
            empty_ns.mkdir(parents=True)

            with patch("comate_agent_sdk.skill.loader.Path.home", return_value=Path(td) / "home"):
                skills = discover_skills(project_root=str(root))

        self.assertEqual(skills, [])


if __name__ == "__main__":
    unittest.main(verbosity=2)
