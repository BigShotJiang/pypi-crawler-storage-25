from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

from comate_agent_sdk.skill.models import SkillDefinition
from comate_agent_sdk.skill.prompts import generate_skill_prompt


class TestSkillPrompts(unittest.TestCase):
    def test_generate_skill_prompt_includes_skill_file_path_and_relative_path_rule(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            skill_dir = Path(td) / "demo-skill"
            prompt = generate_skill_prompt(
                [
                    SkillDefinition(
                        name="demo-skill",
                        description="Use the packaged script.",
                        prompt="Open the references file.",
                        base_dir=skill_dir,
                    )
                ]
            )

        self.assertIn(f"(file: {skill_dir / 'SKILL.md'})", prompt)
        self.assertIn("resolve them relative to the skill directory first", prompt)


if __name__ == "__main__":
    unittest.main(verbosity=2)
