"""Skill 自动发现和加载"""

import logging
from pathlib import Path

from comate_agent_sdk.skill.models import SkillDefinition
from comate_agent_sdk.utils.paths import PathInput, normalize_path_input

logger = logging.getLogger(__name__)


def discover_skills(project_root: PathInput | None = None) -> list[SkillDefinition]:
    """自动发现所有 Skill

    扫描路径（优先级从高到低）：
    1. {project_root}/.agent/skills/
    2. ~/.agent/skills/

    支持两种格式：
    - 单个目录（包含 SKILL.md + 可选的 scripts/references/assets）

    注意：
    - Project skills 会覆盖同名的 user skills（项目级优先）
    - 跳过 disable_model_invocation=True 的 skills（在 create_skill_tool 中过滤）
    """
    project_root = normalize_path_input(
        project_root if project_root is not None else Path.cwd(),
        field_name="project_root",
    )

    user_dir = Path.home() / ".agent" / "skills"
    project_dir = project_root / ".agent" / "skills"

    skills: list[SkillDefinition] = []
    seen_names: set[str] = set()

    # 优先加载 project skills（会覆盖同名 user skills）
    for skill_dir in [project_dir, user_dir]:
        if not skill_dir.exists():
            continue

        # 扫描所有子目录
        for item in sorted(skill_dir.iterdir()):
            if not item.is_dir():
                continue

            if (item / "SKILL.md").exists():
                # 直接是 skill 目录（无 namespace）
                try:
                    skill = SkillDefinition.from_directory(item)
                    if skill.name in seen_names:
                        logger.info(f"Skipping duplicate skill '{skill.name}' from {item}")
                        continue
                    skills.append(skill)
                    seen_names.add(skill.name)
                    logger.info(f"Loaded skill '{skill.name}' from {item}")
                except Exception as e:
                    logger.warning(f"Failed to load skill from {item}: {e}")
            else:
                # 当作 namespace 父目录，扫描一层子目录
                namespace = item.name
                for sub_item in sorted(item.iterdir()):
                    if not sub_item.is_dir():
                        continue
                    if not (sub_item / "SKILL.md").exists():
                        continue
                    try:
                        skill = SkillDefinition.from_directory(sub_item, namespace=namespace)
                        if skill.name in seen_names:
                            logger.info(f"Skipping duplicate skill '{skill.name}' from {sub_item}")
                            continue
                        skills.append(skill)
                        seen_names.add(skill.name)
                        logger.info(f"Loaded skill '{skill.name}' from {sub_item}")
                    except Exception as e:
                        logger.warning(f"Failed to load skill from {sub_item}: {e}")

    return skills
