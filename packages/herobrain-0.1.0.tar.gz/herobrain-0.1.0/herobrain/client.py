"""Sync and async HTTP clients for the HeroBrain Memory API.

Design mirrors the TypeScript SDK (sdk/src/client.ts) for feature parity,
using httpx for HTTP transport (pattern borrowed from mem0's Python client).
"""

from __future__ import annotations

import json
import os
from typing import Any, AsyncIterator, Dict, Iterator, List, Optional, Union
from urllib.parse import quote

import httpx

from herobrain.exceptions import HeroBrainError, HeroBrainRateLimitError, exception_from_response

_DEFAULT_BASE_URL = "https://herobrain-memory-v1-production.up.railway.app"
_TIMEOUT = 120


class HeroBrainMemory:
    """Synchronous HeroBrain Memory client."""

    def __init__(
        self,
        api_key: Optional[str] = None,
        base_url: Optional[str] = None,
        timeout: int = _TIMEOUT,
        client: Optional[httpx.Client] = None,
    ) -> None:
        self.api_key = api_key or os.getenv("HEROBRAIN_API_KEY", "")
        if not self.api_key:
            raise ValueError("api_key is required (or set HEROBRAIN_API_KEY)")
        self.base_url = (base_url or os.getenv("HEROBRAIN_BASE_URL", _DEFAULT_BASE_URL)).rstrip("/")
        if client is not None:
            self._client = client
            self._client.base_url = httpx.URL(self.base_url)
            self._client.headers.update(self._headers())
        else:
            self._client = httpx.Client(
                base_url=self.base_url,
                headers=self._headers(),
                timeout=timeout,
            )
        self._owns_client = client is None

    def close(self) -> None:
        if self._owns_client:
            self._client.close()

    def __enter__(self) -> "HeroBrainMemory":
        return self

    def __exit__(self, *_: Any) -> None:
        self.close()

    # ── Memory CRUD ─────────────────────────────────────────────

    def add(
        self,
        content: str,
        *,
        type: Optional[str] = None,
        importance: Optional[float] = None,
        metadata: Optional[Dict[str, Any]] = None,
        infer: Optional[bool] = None,
        agent_id: Optional[str] = None,
        session_id: Optional[str] = None,
        run_id: Optional[str] = None,
        expires_at: Optional[str] = None,
        async_mode: Optional[bool] = None,
    ) -> List[Dict[str, Any]]:
        body: Dict[str, Any] = {"content": content}
        if type is not None:
            body["type"] = type
        if importance is not None:
            body["importance"] = importance
        if metadata is not None:
            body["metadata"] = metadata
        if infer is not None:
            body["infer"] = infer
        if agent_id is not None:
            body["agent_id"] = agent_id
        if session_id is not None:
            body["session_id"] = session_id
        if run_id is not None:
            body["run_id"] = run_id
        if expires_at is not None:
            body["expires_at"] = expires_at
        if async_mode is not None:
            body["async"] = async_mode
        res = self._post("/api/v1/memories", body)
        if async_mode:
            return [res]
        return res.get("memories", [])

    def search(
        self,
        query: str,
        *,
        type: Optional[str] = None,
        limit: Optional[int] = None,
        threshold: Optional[float] = None,
        agent_id: Optional[str] = None,
        session_id: Optional[str] = None,
        run_id: Optional[str] = None,
    ) -> List[Dict[str, Any]]:
        body: Dict[str, Any] = {"query": query}
        if type is not None:
            body["type"] = type
        if limit is not None:
            body["limit"] = limit
        if threshold is not None:
            body["threshold"] = threshold
        if agent_id is not None:
            body["agent_id"] = agent_id
        if session_id is not None:
            body["session_id"] = session_id
        if run_id is not None:
            body["run_id"] = run_id
        return self._post("/api/v1/memories/search", body).get("results", [])

    def get(self, memory_id: str) -> Dict[str, Any]:
        return self._request("GET", f"/api/v1/memories/{quote(memory_id)}")

    def update(
        self,
        memory_id: str,
        *,
        content: Optional[str] = None,
        type: Optional[str] = None,
        importance: Optional[float] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        body: Dict[str, Any] = {}
        if content is not None:
            body["content"] = content
        if type is not None:
            body["type"] = type
        if importance is not None:
            body["importance"] = importance
        if metadata is not None:
            body["metadata"] = metadata
        return self._request("PUT", f"/api/v1/memories/{quote(memory_id)}", body)

    def delete(self, memory_id: str) -> None:
        self._request("DELETE", f"/api/v1/memories/{quote(memory_id)}")

    def list(
        self,
        *,
        type: Optional[str] = None,
        limit: Optional[int] = None,
        offset: Optional[int] = None,
        agent_id: Optional[str] = None,
        session_id: Optional[str] = None,
        run_id: Optional[str] = None,
    ) -> List[Dict[str, Any]]:
        params: Dict[str, str] = {}
        if type is not None:
            params["type"] = type
        if limit is not None:
            params["limit"] = str(limit)
        if offset is not None:
            params["offset"] = str(offset)
        if agent_id is not None:
            params["agent_id"] = agent_id
        if session_id is not None:
            params["session_id"] = session_id
        if run_id is not None:
            params["run_id"] = run_id
        qs = "&".join(f"{k}={v}" for k, v in params.items())
        path = f"/api/v1/memories?{qs}" if qs else "/api/v1/memories"
        return self._request("GET", path).get("memories", [])

    def history(self, memory_id: str) -> List[Dict[str, Any]]:
        return self._request("GET", f"/api/v1/memories/{quote(memory_id)}/history").get("history", [])

    # ── Chat ────────────────────────────────────────────────────

    def chat(
        self,
        message: str,
        *,
        conversation_id: Optional[str] = None,
        model: Optional[str] = None,
        agent_id: Optional[str] = None,
        session_id: Optional[str] = None,
        run_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        body: Dict[str, Any] = {"message": message}
        if conversation_id is not None:
            body["conversation_id"] = conversation_id
        if model is not None:
            body["model"] = model
        if agent_id is not None:
            body["agent_id"] = agent_id
        if session_id is not None:
            body["session_id"] = session_id
        if run_id is not None:
            body["run_id"] = run_id
        return self._post("/api/v1/chat", body)

    def chat_stream(
        self,
        message: str,
        *,
        conversation_id: Optional[str] = None,
        model: Optional[str] = None,
        agent_id: Optional[str] = None,
        session_id: Optional[str] = None,
        run_id: Optional[str] = None,
    ) -> Iterator[Dict[str, Any]]:
        body: Dict[str, Any] = {"message": message}
        if conversation_id is not None:
            body["conversation_id"] = conversation_id
        if model is not None:
            body["model"] = model
        if agent_id is not None:
            body["agent_id"] = agent_id
        if session_id is not None:
            body["session_id"] = session_id
        if run_id is not None:
            body["run_id"] = run_id
        with self._client.stream(
            "POST",
            "/api/v1/chat/stream",
            json=body,
            headers={**self._headers(), "Accept": "text/event-stream"},
        ) as resp:
            self._check(resp)
            for line in resp.iter_lines():
                if not line.startswith("data: "):
                    continue
                payload = line[6:]
                if payload == "[DONE]":
                    return
                try:
                    yield json.loads(payload)
                except json.JSONDecodeError:
                    pass

    # ── Conversations ───────────────────────────────────────────

    def create_conversation(self, *, title: Optional[str] = None) -> Dict[str, Any]:
        body: Dict[str, Any] = {}
        if title is not None:
            body["title"] = title
        return self._post("/api/v1/conversations", body)

    def conversations(self, limit: Optional[int] = None) -> List[Dict[str, Any]]:
        qs = f"?limit={limit}" if limit else ""
        return self._request("GET", f"/api/v1/conversations{qs}").get("conversations", [])

    def conversation(self, conversation_id: str) -> Dict[str, Any]:
        return self._request("GET", f"/api/v1/conversations/{quote(conversation_id)}")

    def delete_conversation(self, conversation_id: str) -> None:
        self._request("DELETE", f"/api/v1/conversations/{quote(conversation_id)}")

    # ── Graph ───────────────────────────────────────────────────

    def graph_search(self, query: str, limit: Optional[int] = None) -> List[Dict[str, Any]]:
        body: Dict[str, Any] = {"query": query}
        if limit is not None:
            body["limit"] = limit
        return self._post("/api/v1/graph/search", body).get("results", [])

    def graph(self, limit: Optional[int] = None) -> List[Dict[str, Any]]:
        qs = f"?limit={limit}" if limit else ""
        return self._request("GET", f"/api/v1/graph{qs}").get("results", [])

    # ── API Keys ────────────────────────────────────────────────

    def create_key(self, name: Optional[str] = None) -> Dict[str, Any]:
        body: Dict[str, Any] = {}
        if name is not None:
            body["name"] = name
        return self._post("/api/v1/keys", body)

    def keys(self) -> List[Dict[str, Any]]:
        return self._request("GET", "/api/v1/keys").get("keys", [])

    def revoke_key(self, key_id: str) -> None:
        self._request("DELETE", f"/api/v1/keys/{quote(key_id)}")

    # ── Stats & Health ──────────────────────────────────────────

    def stats(self) -> Dict[str, Any]:
        return self._request("GET", "/api/v1/stats")

    def health(self) -> Dict[str, Any]:
        return self._request("GET", "/api/health")

    # ── Integrations ────────────────────────────────────────────

    def connect(self, provider: str) -> Dict[str, Any]:
        return self._post("/api/v1/integrations/connect", {"provider": provider})

    def disconnect(self, provider: str) -> None:
        self._post(f"/api/v1/integrations/{quote(provider)}/disconnect", {})

    def sync_now(self, provider: str) -> Dict[str, Any]:
        return self._post(f"/api/v1/integrations/{quote(provider)}/sync", {})

    def integrations(self) -> List[Dict[str, Any]]:
        return self._request("GET", "/api/v1/integrations/status")

    # ── Billing ─────────────────────────────────────────────────

    def usage(self) -> Dict[str, Any]:
        return self._request("GET", "/api/v1/billing/usage")

    def plans(self) -> Dict[str, Any]:
        return self._request("GET", "/api/v1/billing/plans")

    # ── Internals ───────────────────────────────────────────────

    def _headers(self) -> Dict[str, str]:
        return {
            "Authorization": f"Bearer {self.api_key}",
            "Accept": "application/json",
        }

    def _post(self, path: str, body: Any) -> Any:
        return self._request("POST", path, body)

    def _request(self, method: str, path: str, body: Any = None) -> Any:
        kwargs: Dict[str, Any] = {}
        if body is not None:
            kwargs["json"] = body
            kwargs["headers"] = {"Content-Type": "application/json"}
        resp = self._client.request(method, path, **kwargs)
        self._check(resp)
        if resp.status_code == 204:
            return {}
        if resp.status_code == 202:
            return resp.json()
        return resp.json()

    @staticmethod
    def _check(resp: httpx.Response) -> None:
        if resp.status_code < 400:
            return
        body = None
        text = resp.text
        try:
            body = resp.json()
        except Exception:
            pass
        if resp.status_code == 429:
            retry = resp.headers.get("Retry-After")
            raise HeroBrainRateLimitError(
                text, resp.status_code, body,
                retry_after=int(retry) if retry else None,
            )
        raise exception_from_response(resp.status_code, text, body)


# ═══════════════════════════════════════════════════════════════
# Async client — same surface, async/await
# ═══════════════════════════════════════════════════════════════


class AsyncHeroBrainMemory:
    """Asynchronous HeroBrain Memory client."""

    def __init__(
        self,
        api_key: Optional[str] = None,
        base_url: Optional[str] = None,
        timeout: int = _TIMEOUT,
        client: Optional[httpx.AsyncClient] = None,
    ) -> None:
        self.api_key = api_key or os.getenv("HEROBRAIN_API_KEY", "")
        if not self.api_key:
            raise ValueError("api_key is required (or set HEROBRAIN_API_KEY)")
        self.base_url = (base_url or os.getenv("HEROBRAIN_BASE_URL", _DEFAULT_BASE_URL)).rstrip("/")
        if client is not None:
            self._client = client
            self._client.base_url = httpx.URL(self.base_url)
            self._client.headers.update(self._headers())
        else:
            self._client = httpx.AsyncClient(
                base_url=self.base_url,
                headers=self._headers(),
                timeout=timeout,
            )
        self._owns_client = client is None

    async def close(self) -> None:
        if self._owns_client:
            await self._client.aclose()

    async def __aenter__(self) -> "AsyncHeroBrainMemory":
        return self

    async def __aexit__(self, *_: Any) -> None:
        await self.close()

    # ── Memory CRUD ─────────────────────────────────────────────

    async def add(
        self,
        content: str,
        *,
        type: Optional[str] = None,
        importance: Optional[float] = None,
        metadata: Optional[Dict[str, Any]] = None,
        infer: Optional[bool] = None,
        agent_id: Optional[str] = None,
        session_id: Optional[str] = None,
        run_id: Optional[str] = None,
        expires_at: Optional[str] = None,
        async_mode: Optional[bool] = None,
    ) -> List[Dict[str, Any]]:
        body: Dict[str, Any] = {"content": content}
        if type is not None:
            body["type"] = type
        if importance is not None:
            body["importance"] = importance
        if metadata is not None:
            body["metadata"] = metadata
        if infer is not None:
            body["infer"] = infer
        if agent_id is not None:
            body["agent_id"] = agent_id
        if session_id is not None:
            body["session_id"] = session_id
        if run_id is not None:
            body["run_id"] = run_id
        if expires_at is not None:
            body["expires_at"] = expires_at
        if async_mode is not None:
            body["async"] = async_mode
        res = await self._post("/api/v1/memories", body)
        if async_mode:
            return [res]
        return res.get("memories", [])

    async def search(
        self,
        query: str,
        *,
        type: Optional[str] = None,
        limit: Optional[int] = None,
        threshold: Optional[float] = None,
        agent_id: Optional[str] = None,
        session_id: Optional[str] = None,
        run_id: Optional[str] = None,
    ) -> List[Dict[str, Any]]:
        body: Dict[str, Any] = {"query": query}
        if type is not None:
            body["type"] = type
        if limit is not None:
            body["limit"] = limit
        if threshold is not None:
            body["threshold"] = threshold
        if agent_id is not None:
            body["agent_id"] = agent_id
        if session_id is not None:
            body["session_id"] = session_id
        if run_id is not None:
            body["run_id"] = run_id
        return (await self._post("/api/v1/memories/search", body)).get("results", [])

    async def get(self, memory_id: str) -> Dict[str, Any]:
        return await self._request("GET", f"/api/v1/memories/{quote(memory_id)}")

    async def update(self, memory_id: str, **kwargs: Any) -> Dict[str, Any]:
        return await self._request("PUT", f"/api/v1/memories/{quote(memory_id)}", kwargs)

    async def delete(self, memory_id: str) -> None:
        await self._request("DELETE", f"/api/v1/memories/{quote(memory_id)}")

    async def list(self, **kwargs: Any) -> List[Dict[str, Any]]:
        params = {k: str(v) for k, v in kwargs.items() if v is not None}
        qs = "&".join(f"{k}={v}" for k, v in params.items())
        path = f"/api/v1/memories?{qs}" if qs else "/api/v1/memories"
        return (await self._request("GET", path)).get("memories", [])

    async def history(self, memory_id: str) -> List[Dict[str, Any]]:
        return (await self._request("GET", f"/api/v1/memories/{quote(memory_id)}/history")).get("history", [])

    # ── Chat ────────────────────────────────────────────────────

    async def chat(
        self,
        message: str,
        *,
        conversation_id: Optional[str] = None,
        model: Optional[str] = None,
        agent_id: Optional[str] = None,
        session_id: Optional[str] = None,
        run_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        body: Dict[str, Any] = {"message": message}
        if conversation_id is not None:
            body["conversation_id"] = conversation_id
        if model is not None:
            body["model"] = model
        if agent_id is not None:
            body["agent_id"] = agent_id
        if session_id is not None:
            body["session_id"] = session_id
        if run_id is not None:
            body["run_id"] = run_id
        return await self._post("/api/v1/chat", body)

    async def chat_stream(
        self,
        message: str,
        *,
        conversation_id: Optional[str] = None,
        model: Optional[str] = None,
        agent_id: Optional[str] = None,
        session_id: Optional[str] = None,
        run_id: Optional[str] = None,
    ) -> AsyncIterator[Dict[str, Any]]:
        body: Dict[str, Any] = {"message": message}
        if conversation_id is not None:
            body["conversation_id"] = conversation_id
        if model is not None:
            body["model"] = model
        if agent_id is not None:
            body["agent_id"] = agent_id
        if session_id is not None:
            body["session_id"] = session_id
        if run_id is not None:
            body["run_id"] = run_id
        async with self._client.stream(
            "POST", "/api/v1/chat/stream", json=body,
            headers={**self._headers(), "Accept": "text/event-stream"},
        ) as resp:
            self._check_sync(resp)
            async for line in resp.aiter_lines():
                if not line.startswith("data: "):
                    continue
                payload = line[6:]
                if payload == "[DONE]":
                    return
                try:
                    yield json.loads(payload)
                except json.JSONDecodeError:
                    pass

    # ── Conversations ───────────────────────────────────────────

    async def conversations(self, limit: Optional[int] = None) -> List[Dict[str, Any]]:
        qs = f"?limit={limit}" if limit else ""
        return (await self._request("GET", f"/api/v1/conversations{qs}")).get("conversations", [])

    async def conversation(self, cid: str) -> Dict[str, Any]:
        return await self._request("GET", f"/api/v1/conversations/{quote(cid)}")

    async def delete_conversation(self, cid: str) -> None:
        await self._request("DELETE", f"/api/v1/conversations/{quote(cid)}")

    # ── Graph ───────────────────────────────────────────────────

    async def graph_search(self, query: str, limit: Optional[int] = None) -> List[Dict[str, Any]]:
        body: Dict[str, Any] = {"query": query}
        if limit:
            body["limit"] = limit
        return (await self._post("/api/v1/graph/search", body)).get("results", [])

    async def graph(self, limit: Optional[int] = None) -> List[Dict[str, Any]]:
        qs = f"?limit={limit}" if limit else ""
        return (await self._request("GET", f"/api/v1/graph{qs}")).get("results", [])

    # ── Keys / Stats / Health / Integrations / Billing ──────────

    async def create_key(self, name: Optional[str] = None) -> Dict[str, Any]:
        return await self._post("/api/v1/keys", {"name": name} if name else {})

    async def keys(self) -> List[Dict[str, Any]]:
        return (await self._request("GET", "/api/v1/keys")).get("keys", [])

    async def revoke_key(self, key_id: str) -> None:
        await self._request("DELETE", f"/api/v1/keys/{quote(key_id)}")

    async def stats(self) -> Dict[str, Any]:
        return await self._request("GET", "/api/v1/stats")

    async def health(self) -> Dict[str, Any]:
        return await self._request("GET", "/api/health")

    async def usage(self) -> Dict[str, Any]:
        return await self._request("GET", "/api/v1/billing/usage")

    async def plans(self) -> Dict[str, Any]:
        return await self._request("GET", "/api/v1/billing/plans")

    # ── Internals ───────────────────────────────────────────────

    def _headers(self) -> Dict[str, str]:
        return {"Authorization": f"Bearer {self.api_key}", "Accept": "application/json"}

    async def _post(self, path: str, body: Any) -> Any:
        return await self._request("POST", path, body)

    async def _request(self, method: str, path: str, body: Any = None) -> Any:
        kwargs: Dict[str, Any] = {}
        if body is not None:
            kwargs["json"] = body
            kwargs["headers"] = {"Content-Type": "application/json"}
        resp = await self._client.request(method, path, **kwargs)
        self._check_sync(resp)
        if resp.status_code in (204, 202):
            try:
                return resp.json()
            except Exception:
                return {}
        return resp.json()

    @staticmethod
    def _check_sync(resp: httpx.Response) -> None:
        if resp.status_code < 400:
            return
        body = None
        text = resp.text
        try:
            body = resp.json()
        except Exception:
            pass
        if resp.status_code == 429:
            retry = resp.headers.get("Retry-After")
            raise HeroBrainRateLimitError(text, resp.status_code, body, retry_after=int(retry) if retry else None)
        raise exception_from_response(resp.status_code, text, body)
