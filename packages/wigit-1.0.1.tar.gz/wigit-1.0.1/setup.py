# -*- coding: utf-8 -*-
"""
WiGit - 下一代版本控制系统
基于Git协议，提供AI原生、实时协作、多模态版本控制等增强功能
"""

import os
import sys
from setuptools import setup, find_packages

# 读取README内容作为长描述
def read_readme():
    readme_path = os.path.join(os.path.dirname(__file__), "README.md")
    if os.path.exists(readme_path):
        with open(readme_path, "r", encoding="utf-8") as f:
            return f.read()
    return "WiGit - 下一代版本控制系统"

# 读取版本号
def get_version():
    version = "1.0.1"
    init_path = os.path.join(os.path.dirname(__file__), "wigit", "__init__.py")
    if os.path.exists(init_path):
        with open(init_path, "r", encoding="utf-8") as f:
            for line in f:
                if line.startswith("__version__"):
                    version = line.split("=")[1].strip().strip('"').strip("'")
                    break
    return version

# 检查Python版本
if sys.version_info < (3, 7):
    sys.exit("WiGit 需要 Python 3.7 或更高版本")

setup(
    # 基本信息
    name="wigit",
    version=get_version(),
    author="WiGit Team",
    author_email="wigit@example.com",
    description="下一代版本控制系统 - AI原生、实时协作、多模态版本控制",
    long_description=read_readme(),
    long_description_content_type="text/markdown",
    url="https://github.com/wigit/wigit",
    license="MIT",
    
    # 包配置
    packages=find_packages(),
    include_package_data=True,
    zip_safe=False,
    
    # Python版本要求
    python_requires=">=3.7",
    
    # 安装依赖
    install_requires=[
        "requests>=2.25.0",           # HTTP请求
        "websocket-client>=1.0.1",    # WebSocket实时协作
        "colorama>=0.4.4",            # 彩色终端输出
    ],
    
    # 可选依赖
    extras_require={
        "dev": [
            "pytest>=6.0.0",
            "pytest-cov>=2.0.0",
            "black>=21.0.0",
            "flake8>=3.9.0",
            "mypy>=0.910",
        ],
        "ai": [
            "openai>=0.27.0",         # OpenAI API支持
        ],
        "full": [
            "openai>=0.27.0",
            "numpy>=1.21.0",          # 数据分析
            "pillow>=9.0.0",          # 图像处理
        ],
    },
    
    # 控制台脚本入口
    entry_points={
        "console_scripts": [
            "wigit=wigit.cli:main",
            "wigit-cli=wigit.cli:main",
        ],
    },
    
    # 分类信息
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "Topic :: Software Development :: Version Control",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.7",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Operating System :: OS Independent",
    ],
    
    # 项目URL
    project_urls={
        "Bug Reports": "https://github.com/wigit/wigit/issues",
        "Source": "https://github.com/wigit/wigit",
        "Documentation": "https://github.com/wigit/wigit/wiki",
    },
    
    # 关键词
    keywords="git version-control ai collaboration nft blockchain web3",
)
