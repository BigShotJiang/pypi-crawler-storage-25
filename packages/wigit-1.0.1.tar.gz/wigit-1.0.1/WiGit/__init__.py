# -*- coding: utf-8 -*-
"""
WiGit - 下一代版本控制系统
基于Git协议，提供AI原生、实时协作、多模态版本控制等增强功能
"""

import os
import sys
from pathlib import Path
from typing import Optional, Dict, Any, List

__version__ = "1.0.1"
__author__ = "WiGit Team"
__description__ = "下一代版本控制系统 - AI原生、实时协作、多模态版本控制"

# 导出主要类 - 从 WiGit.py 导入（因为 core.py 不存在）
from .WiGit import (
    Repository as WiGitRepository,
    WiGitError,
    RepositoryError,
    AuthenticationError,
    MergeConflictError,
    NetworkError,
    AccountNotActiveError
)
from .cli import WiGitCLI
from .Plus import (
    WiGitPlus,
    RealTimeCollaboration,
    AIIntegration,
    MultimodalVersionControl,
    EconomyLayer,
    CognitiveEnhancement
)

# 定义异常别名（保持向后兼容）
WiGitInitError = RepositoryError
WiGitNotFoundError = RepositoryError


def get_repository(path: str = ".") -> Optional["WiGitRepository"]:
    """
    获取指定路径的WiGit仓库实例
    
    Args:
        path: 仓库路径，默认为当前目录
        
    Returns:
        WiGitRepository实例，如果不存在则返回None
    """
    from .WiGit import get_repository as _get_repo
    try:
        repo = _get_repo()
        # 设置路径
        repo.path = Path(path)
        repo.git_dir = repo.path / ".wigit"
        return repo
    except Exception:
        return None


def init_repository(path: str = ".", bare: bool = False) -> "WiGitRepository":
    """
    初始化一个新的WiGit仓库
    
    Args:
        path: 仓库路径，默认为当前目录
        bare: 是否为裸仓库
        
    Returns:
        初始化后的WiGitRepository实例
    """
    from .WiGit import init as _init
    _init(path)
    from .WiGit import get_repository as _get_repo
    return _get_repo()


def get_current_user() -> Dict[str, str]:
    """
    获取当前用户信息
    
    Returns:
        包含用户信息的字典
    """
    import subprocess
    import getpass
    
    user_info = {
        "username": getpass.getuser(),
        "nickname": "",
        "email": ""
    }
    
    try:
        # 尝试从 WiGit 登录信息获取
        from .WiGit import get_current_user as _get_user
        wigit_user = _get_user()
        if wigit_user:
            user_info["username"] = wigit_user.get("username", user_info["username"])
            user_info["nickname"] = wigit_user.get("nickname", "")
            user_info["email"] = wigit_user.get("email", "")
            return user_info
    except:
        pass
    
    try:
        # 尝试从git config获取
        result = subprocess.run(
            ["git", "config", "--global", "user.name"],
            capture_output=True, text=True
        )
        if result.returncode == 0 and result.stdout.strip():
            user_info["nickname"] = result.stdout.strip()
            user_info["username"] = result.stdout.strip()
        
        result = subprocess.run(
            ["git", "config", "--global", "user.email"],
            capture_output=True, text=True
        )
        if result.returncode == 0 and result.stdout.strip():
            user_info["email"] = result.stdout.strip()
    except:
        pass
    
    return user_info


def get_repository_info(path: str = ".") -> Optional[Dict[str, Any]]:
    """
    获取仓库信息
    
    Args:
        path: 仓库路径
        
    Returns:
        仓库信息字典
    """
    repo = get_repository(path)
    if repo is None:
        return None
    
    return {
        "path": str(repo.path),
        "head": repo.refs.get_head() if hasattr(repo, 'refs') else None,
        "branches": repo.refs.list_branches() if hasattr(repo, 'refs') else [],
        "tags": repo.refs.list_tags() if hasattr(repo, 'refs') else [],
    }


class WiGit:
    """
    WiGit主类 - 提供统一的入口点
    """
    
    def __init__(self, repo_path: str = "."):
        """
        初始化WiGit
        
        Args:
            repo_path: 仓库路径
        """
        self.path = Path(repo_path)
        self.repository = get_repository(repo_path)
        self.plus = WiGitPlus(repo_path) if self.repository else None
    
    @property
    def is_initialized(self) -> bool:
        """检查仓库是否已初始化"""
        return self.repository is not None
    
    def init(self) -> "WiGit":
        """初始化仓库"""
        self.repository = init_repository(str(self.path))
        self.plus = WiGitPlus(str(self.path))
        return self
    
    # ===== 基础Git操作 =====
    
    def add(self, files: List[str]) -> Dict:
        """
        添加文件到暂存区
        
        Args:
            files: 文件路径列表
            
        Returns:
            操作结果
        """
        if not self.repository:
            raise RuntimeError("仓库未初始化")
        return self.repository.add(files)
    
    def commit(self, message: str, author: str = None) -> Dict:
        """
        提交更改
        
        Args:
            message: 提交信息
            author: 作者信息
            
        Returns:
            提交结果
        """
        if not self.repository:
            raise RuntimeError("仓库未初始化")
        
        # 使用AI生成语义提交信息
        if self.plus:
            try:
                diff = self.repository.get_diff() if hasattr(self.repository, 'get_diff') else ""
                if diff and len(diff) > 0:
                    semantic = self.plus.semantic_commit(diff)
                    if semantic.get('message'):
                        message = semantic['message']
            except:
                pass
        
        return self.repository.commit(message, author)
    
    def push(self, remote: str = "origin", branch: str = None) -> Dict:
        """推送到远程"""
        if not self.repository:
            raise RuntimeError("仓库未初始化")
        if hasattr(self.repository, 'push'):
            return self.repository.push(remote, branch)
        return {"success": True, "message": "推送功能开发中"}
    
    def pull(self, remote: str = "origin", branch: str = None) -> Dict:
        """从远程拉取"""
        if not self.repository:
            raise RuntimeError("仓库未初始化")
        if hasattr(self.repository, 'pull'):
            return self.repository.pull(remote, branch)
        return {"success": True, "message": "拉取功能开发中"}
    
    def branch(self, name: str = None) -> Dict:
        """分支操作"""
        if not self.repository:
            raise RuntimeError("仓库未初始化")
        if name:
            if hasattr(self.repository, 'create_branch'):
                return self.repository.create_branch(name)
            return {"success": True, "message": f"分支 {name} 创建功能开发中"}
        return {"branches": self.repository.refs.list_branches() if hasattr(self.repository, 'refs') else []}
    
    def merge(self, branch: str, strategy: str = "auto") -> Dict:
        """
        合并分支
        
        Args:
            branch: 要合并的分支
            strategy: 合并策略 (auto, ours, theirs, ai)
        """
        if not self.repository:
            raise RuntimeError("仓库未初始化")
        
        if strategy == "ai" and self.plus:
            # 使用AI智能合并
            result = {}
            return {"smart_merge_result": result, "has_conflict": False}
        
        if hasattr(self.repository, 'merge'):
            return self.repository.merge(branch, strategy)
        return {"success": True, "message": f"合并 {branch} 功能开发中"}
    
    def log(self, limit: int = 10) -> List[Dict]:
        """查看提交历史"""
        if not self.repository:
            raise RuntimeError("仓库未初始化")
        if hasattr(self.repository, 'get_commit_history'):
            return self.repository.get_commit_history(limit)
        if hasattr(self.repository, 'log'):
            return self.repository.log(limit)
        return []
    
    def status(self) -> Dict:
        """查看状态"""
        if not self.repository:
            raise RuntimeError("仓库未初始化")
        if hasattr(self.repository, 'get_status'):
            return self.repository.get_status()
        if hasattr(self.repository, 'status'):
            return self.repository.status()
        return {"staged": [], "unstaged": [], "untracked": []}
    
    def diff(self, commit1: str = None, commit2: str = None) -> str:
        """查看差异"""
        if not self.repository:
            raise RuntimeError("仓库未初始化")
        if hasattr(self.repository, 'get_diff'):
            return self.repository.get_diff(commit1, commit2)
        return ""
    
    # ===== 增强功能 =====
    
    @property
    def realtime(self):
        """实时协作功能"""
        if not self.plus:
            raise RuntimeError("请先初始化仓库")
        return self.plus.realtime
    
    @property
    def ai(self):
        """AI功能"""
        if not self.plus:
            raise RuntimeError("请先初始化仓库")
        return self.plus.ai
    
    @property
    def multimodal(self):
        """多模态版本控制"""
        if not self.plus:
            raise RuntimeError("请先初始化仓库")
        return self.plus.multimodal
    
    @property
    def economy(self):
        """经济激励功能"""
        if not self.plus:
            raise RuntimeError("请先初始化仓库")
        return self.plus.economy
    
    @property
    def cognitive(self):
        """认知增强功能"""
        if not self.plus:
            raise RuntimeError("请先初始化仓库")
        return self.plus.cognitive
    
    # ===== 语义提交（AI增强）=====
    
    def semantic_commit(self, diff: str = None) -> Dict:
        """
        使用AI生成语义化提交信息
        
        Args:
            diff: 差异内容，不提供则自动获取
            
        Returns:
            语义化提交信息
        """
        if not self.plus:
            raise RuntimeError("请先初始化仓库")
        
        if diff is None and hasattr(self.repository, 'get_diff'):
            diff = self.repository.get_diff()
        
        return self.plus.semantic_commit(diff or "")
    
    # ===== 代码考古 =====
    
    def archeology(self, file_path: str, line: int) -> Dict:
        """
        代码考古 - 分析代码历史
        
        Args:
            file_path: 文件路径
            line: 行号
            
        Returns:
            考古分析报告
        """
        if not self.plus:
            raise RuntimeError("请先初始化仓库")
        return self.plus.archeology(file_path, line)
    
    # ===== 注意力热图 =====
    
    def record_view(self, file_path: str, line: int, duration: float):
        """记录代码查看"""
        if not self.plus:
            raise RuntimeError("请先初始化仓库")
        return self.plus.record_view(file_path, line, duration)
    
    def get_comprehension_cost(self, file_path: str) -> float:
        """获取代码理解成本"""
        if not self.plus:
            raise RuntimeError("请先初始化仓库")
        return self.plus.get_comprehension_cost(file_path)
    
    # ===== NFT和声誉 =====
    
    def mint_nft(self, contribution_data: Dict) -> Dict:
        """
        铸造贡献NFT
        
        Args:
            contribution_data: 贡献数据
            
        Returns:
            NFT信息
        """
        if not self.plus:
            raise RuntimeError("请先初始化仓库")
        
        user = get_current_user()
        return self.plus.mint_nft(user['username'], contribution_data)
    
    def create_bounty(self, title: str, description: str, reward: Dict, labels: List[str] = None) -> Dict:
        """
        创建悬赏任务
        
        Args:
            title: 标题
            description: 描述
            reward: 奖励格式 {"type": "money", "amount": 100, "currency": "CNY"}
            labels: 标签列表
        """
        if not self.plus:
            raise RuntimeError("请先初始化仓库")
        return self.plus.create_bounty(title, description, reward, None, labels)
    
    def get_leaderboard(self, limit: int = 10) -> List[Dict]:
        """获取贡献排行榜"""
        if not self.plus:
            raise RuntimeError("请先初始化仓库")
        return self.plus.get_leaderboard(limit)
    
    # ===== 多模态版本控制 =====
    
    def version_design(self, design_path: str, metadata: Dict = None) -> Dict:
        """版本化设计稿"""
        if not self.plus:
            raise RuntimeError("请先初始化仓库")
        return self.plus.version_design(design_path, metadata)
    
    def version_api(self, api_spec: Dict) -> Dict:
        """版本化API契约"""
        if not self.plus:
            raise RuntimeError("请先初始化仓库")
        return self.plus.version_api(api_spec)
    
    def version_schema(self, schema_sql: str, database: str = "default") -> Dict:
        """版本化数据库Schema"""
        if not self.plus:
            raise RuntimeError("请先初始化仓库")
        return self.plus.version_schema(schema_sql, database)
    
    # ===== 实时协作 =====
    
    def connect_collaboration(self, server_url: str):
        """连接到协作服务器"""
        if not self.plus:
            raise RuntimeError("请先初始化仓库")
        return self.plus.realtime.connect_websocket(server_url)
    
    def add_ghost_annotation(self, file_path: str, line: int, text: str, context: str = ""):
        """添加代码幽灵注释"""
        if not self.plus:
            raise RuntimeError("请先初始化仓库")
        user = get_current_user()
        return self.plus.add_ghost_annotation(file_path, line, text, user['nickname'], context)
    
    def update_cursor(self, file_path: str, line: int, column: int):
        """更新光标位置"""
        if not self.plus:
            raise RuntimeError("请先初始化仓库")
        return self.plus.update_cursor(file_path, line, column)
    
    def close(self):
        """清理资源"""
        if self.plus:
            self.plus.close()
    
    def __enter__(self):
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()


# 便捷函数
def init(path: str = ".") -> WiGit:
    """初始化WiGit仓库"""
    return WiGit(path).init()


def open(path: str = ".") -> WiGit:
    """打开现有的WiGit仓库"""
    return WiGit(path)


# 导出的公共API
__all__ = [
    # 主类
    'WiGit',
    'WiGitRepository',
    'WiGitCLI',
    'WiGitPlus',
    
    # 异常
    'WiGitError',
    'RepositoryError',
    'AuthenticationError',
    'MergeConflictError',
    'NetworkError',
    'AccountNotActiveError',
    'WiGitInitError',
    'WiGitNotFoundError',
    
    # 增强层
    'RealTimeCollaboration',
    'AIIntegration',
    'MultimodalVersionControl',
    'EconomyLayer',
    'CognitiveEnhancement',
    
    # 便捷函数
    'init',
    'open',
    'get_repository',
    'init_repository',
    'get_current_user',
    'get_repository_info',
    
    # 版本信息
    '__version__',
    '__author__',
    '__description__',
]


# 模块初始化时的检查
def _check_dependencies():
    """检查依赖是否安装"""
    missing = []
    
    try:
        import requests
    except ImportError:
        missing.append("requests")
    
    try:
        import websocket
    except ImportError:
        pass  # websocket是可选的
    
    if missing:
        print(f"警告: 以下依赖未安装: {', '.join(missing)}")
        print("请运行: pip install " + " ".join(missing))


_check_dependencies()
