# -*- coding: utf-8 -*-
"""
WiGit.py - WiGit 核心版本控制系统
完整重写的Git实现

使用前必须先登录：
    import wigit
    wigit.login("username", "password")
"""

import os
import sys
import json
import zlib
import hashlib
import time
import re
import shutil
import stat
import struct
import secrets
import base64
import requests
from pathlib import Path
from datetime import datetime
from typing import Optional, Dict, Any, List, Tuple, Set, BinaryIO, Union
from dataclasses import dataclass, field
# 第 392 行使用了 difflib，但没有导入
import difflib  # 需要添加
# ==================== 1. 认证模块 ====================

SERVER_URL = "http://8.137.181.230:1001"

_logged_in = False
_current_user = None
_session_token = None


class WiGitError(Exception):
    pass


class AuthenticationError(WiGitError):
    pass


class AccountNotActiveError(AuthenticationError):
    pass


class NetworkError(WiGitError):
    pass


class RepositoryError(WiGitError):
    pass


class MergeConflictError(WiGitError):
    pass


def login(username: str, password: str, server: str = SERVER_URL) -> bool:
    """登录WiGit账户"""
    global _logged_in, _current_user, _session_token
    
    try:
        response = requests.post(
            f"{server}/api/login",
            json={"username": username, "password": password},
            timeout=10
        )
        result = response.json()
        
        if not result.get("success"):
            msg = result.get("message", "登录失败")
            if "未激活" in msg:
                raise AccountNotActiveError(msg)
            raise AuthenticationError(msg)
        
        _logged_in = True
        _current_user = {
            "username": username,
            "nickname": result["data"]["nickname"],
            "email": result["data"]["email"],
            "call_count": result["data"]["call_count"]
        }
        _session_token = secrets.token_urlsafe(32)
        
        return True
        
    except requests.exceptions.RequestException as e:
        raise NetworkError(f"网络连接失败: {e}")


def logout() -> None:
    """退出登录"""
    global _logged_in, _current_user, _session_token
    _logged_in = False
    _current_user = None
    _session_token = None


def is_logged_in() -> bool:
    return _logged_in


def get_current_user() -> Optional[Dict]:
    return _current_user


def _report_call(function_name: str) -> None:
    """上报调用统计"""
    if not _logged_in or not _current_user:
        return
    try:
        requests.post(
            f"{SERVER_URL}/api/log_call",
            json={"username": _current_user["username"], "function_name": function_name},
            timeout=5
        )
    except:
        pass


def require_login(func):
    """需要登录的装饰器"""
    def wrapper(*args, **kwargs):
        if not _logged_in:
            raise AuthenticationError("请先调用 wigit.login() 登录")
        return func(*args, **kwargs)
    return wrapper


# ==================== 2. 对象系统 ====================

class ObjectType:
    BLOB = b'blob'
    TREE = b'tree'
    COMMIT = b'commit'
    TAG = b'tag'


@dataclass
class GitObject:
    type: bytes
    content: bytes
    
    def serialize(self) -> bytes:
        header = f"{self.type.decode()} {len(self.content)}\0".encode()
        return header + self.content
    
    def compress(self) -> bytes:
        return zlib.compress(self.serialize())
    
    @classmethod
    def deserialize(cls, data: bytes) -> 'GitObject':
        null_pos = data.find(b'\0')
        if null_pos == -1:
            raise ValueError("无效的对象格式")
        header = data[:null_pos].decode()
        parts = header.split(' ')
        obj_type = parts[0].encode()
        size = int(parts[1])
        content = data[null_pos + 1:null_pos + 1 + size]
        return cls(type=obj_type, content=content)
    
    @classmethod
    def decompress(cls, compressed: bytes) -> 'GitObject':
        return cls.deserialize(zlib.decompress(compressed))


class Blob:
    def __init__(self, data: bytes):
        self.data = data
    
    def to_object(self) -> GitObject:
        return GitObject(type=ObjectType.BLOB, content=self.data)
    
    @classmethod
    def from_object(cls, obj: GitObject) -> 'Blob':
        if obj.type != ObjectType.BLOB:
            raise ValueError(f"期望 blob，得到 {obj.type}")
        return cls(obj.content)
    
    @classmethod
    def from_file(cls, filepath: Path) -> 'Blob':
        with open(filepath, 'rb') as f:
            return cls(f.read())
    
    def write_to_file(self, filepath: Path) -> None:
        with open(filepath, 'wb') as f:
            f.write(self.data)
    
    @property
    def hash(self) -> str:
        return hashlib.sha1(self.to_object().serialize()).hexdigest()


class TreeEntry:
    MODE_FILE = 0o100644
    MODE_EXEC = 0o100755
    MODE_DIR = 0o040000
    MODE_SYMLINK = 0o120000
    
    def __init__(self, mode: int, name: str, sha1: bytes):
        self.mode = mode
        self.name = name
        self.sha1 = sha1
    
    def encode(self) -> bytes:
        mode_str = f"{self.mode:06o}".encode()
        return mode_str + b' ' + self.name.encode() + b'\0' + self.sha1
    
    @classmethod
    def decode(cls, data: bytes, pos: int) -> Tuple['TreeEntry', int]:
        mode_end = data.find(b' ', pos)
        mode = int(data[pos:mode_end].decode(), 8)
        name_end = data.find(b'\0', mode_end + 1)
        name = data[mode_end + 1:name_end].decode()
        sha1 = data[name_end + 1:name_end + 21]
        return cls(mode, name, sha1), name_end + 21


class Tree:
    def __init__(self, entries: List[TreeEntry] = None):
        self.entries = entries or []
    
    def to_object(self) -> GitObject:
        content = b''.join(e.encode() for e in self.entries)
        return GitObject(type=ObjectType.TREE, content=content)
    
    @classmethod
    def from_object(cls, obj: GitObject) -> 'Tree':
        if obj.type != ObjectType.TREE:
            raise ValueError(f"期望 tree，得到 {obj.type}")
        entries = []
        pos = 0
        while pos < len(obj.content):
            entry, pos = TreeEntry.decode(obj.content, pos)
            entries.append(entry)
        return cls(entries)
    
    def add_entry(self, mode: int, name: str, sha1: bytes) -> None:
        for i, e in enumerate(self.entries):
            if e.name == name:
                self.entries[i] = TreeEntry(mode, name, sha1)
                return
        self.entries.append(TreeEntry(mode, name, sha1))
        self.entries.sort(key=lambda e: e.name)
    
    def find_entry(self, name: str) -> Optional[TreeEntry]:
        for e in self.entries:
            if e.name == name:
                return e
        return None
    
    @property
    def hash(self) -> str:
        return hashlib.sha1(self.to_object().serialize()).hexdigest()


class Commit:
    def __init__(self, tree_sha: str, parent_sha: Optional[str] = None,
                 author_name: str = None, author_email: str = None,
                 message: str = ""):
        user = get_current_user()
        self.tree_sha = tree_sha
        self.parent_sha = parent_sha
        self.author_name = author_name or (user.get('nickname') if user else "WiGit User")
        self.author_email = author_email or (user.get('email') if user else "user@wigit.local")
        self.message = message
        self.timestamp = int(time.time())
    
    def to_object(self) -> GitObject:
        lines = [f"tree {self.tree_sha}"]
        if self.parent_sha:
            lines.append(f"parent {self.parent_sha}")
        lines.append(f"author {self.author_name} <{self.author_email}> {self.timestamp} +0800")
        lines.append(f"committer {self.author_name} <{self.author_email}> {self.timestamp} +0800")
        lines.append("")
        lines.append(self.message)
        content = "\n".join(lines).encode()
        return GitObject(type=ObjectType.COMMIT, content=content)
    
    @classmethod
    def from_object(cls, obj: GitObject) -> 'Commit':
        if obj.type != ObjectType.COMMIT:
            raise ValueError(f"期望 commit，得到 {obj.type}")
        content = obj.content.decode()
        lines = content.split('\n')
        tree_sha = None
        parent_sha = None
        author_name = ""
        author_email = ""
        message = ""
        in_message = False
        for line in lines:
            if in_message:
                message += line + "\n"
                continue
            if line == "":
                in_message = True
                continue
            if line.startswith("tree "):
                tree_sha = line[5:]
            elif line.startswith("parent "):
                parent_sha = line[7:]
            elif line.startswith("author "):
                email_start = line.find('<')
                email_end = line.find('>')
                author_name = line[7:email_start - 1]
                author_email = line[email_start + 1:email_end]
        return cls(tree_sha, parent_sha, author_name, author_email, message.strip())
    
    @property
    def hash(self) -> str:
        return hashlib.sha1(self.to_object().serialize()).hexdigest()


# ==================== 3. 存储系统 ====================

class ObjectStorage:
    """对象存储系统"""
    
    def __init__(self, git_dir: Path):
        self.git_dir = git_dir
        self.objects_dir = git_dir / "objects"
    
    def write_object(self, obj: GitObject) -> str:
        """写入对象并返回SHA1哈希"""
        self.objects_dir.mkdir(parents=True, exist_ok=True)
        data = obj.compress()
        sha1 = hashlib.sha1(obj.serialize()).hexdigest()
        dir_name = sha1[:2]
        file_name = sha1[2:]
        obj_path = self.objects_dir / dir_name / file_name
        obj_path.parent.mkdir(exist_ok=True)
        with open(obj_path, 'wb') as f:
            f.write(data)
        return sha1
    
    def read_object(self, sha1: str) -> GitObject:
        """读取对象"""
        obj_path = self.objects_dir / sha1[:2] / sha1[2:]
        if not obj_path.exists():
            raise RepositoryError(f"对象不存在: {sha1}")
        with open(obj_path, 'rb') as f:
            compressed = f.read()
        return GitObject.decompress(compressed)
    
    def read_blob(self, sha1: str) -> Blob:
        obj = self.read_object(sha1)
        return Blob.from_object(obj)
    
    def read_tree(self, sha1: str) -> Tree:
        obj = self.read_object(sha1)
        return Tree.from_object(obj)
    
    def read_commit(self, sha1: str) -> Commit:
        obj = self.read_object(sha1)
        return Commit.from_object(obj)
    
    def object_exists(self, sha1: str) -> bool:
        """检查对象是否存在"""
        obj_path = self.objects_dir / sha1[:2] / sha1[2:]
        return obj_path.exists()


# ==================== 4. 引用系统 ====================

class RefType:
    HEAD = "HEAD"
    BRANCH = "refs/heads/"
    TAG = "refs/tags/"


class Refs:
    """引用管理系统"""
    
    def __init__(self, git_dir: Path):
        self.git_dir = git_dir
        self.refs_dir = git_dir / "refs"
        self.head_path = git_dir / "HEAD"
    
    def get_head(self) -> Optional[str]:
        """获取HEAD指向的提交"""
        if not self.head_path.exists():
            return None
        content = self.head_path.read_text().strip()
        if content.startswith("ref: "):
            ref_path = content[5:]
            ref_file = self.git_dir / ref_path
            if ref_file.exists():
                return ref_file.read_text().strip()
            return None
        return content
    
    def set_head(self, sha1: str) -> None:
        """设置HEAD指向特定提交（分离HEAD）"""
        self.head_path.write_text(sha1 + "\n")
    
    def set_head_ref(self, ref: str) -> None:
        """设置HEAD指向引用"""
        self.head_path.write_text(f"ref: {ref}\n")
    
    def get_current_branch(self) -> Optional[str]:
        """获取当前分支名"""
        if not self.head_path.exists():
            return None
        content = self.head_path.read_text().strip()
        if content.startswith("ref: refs/heads/"):
            return content[16:]
        return None
    
    def create_branch(self, name: str, sha1: str) -> None:
        """创建分支"""
        branch_path = self.refs_dir / "heads" / name
        branch_path.parent.mkdir(parents=True, exist_ok=True)
        branch_path.write_text(sha1 + "\n")
    
    def delete_branch(self, name: str) -> bool:
        """删除分支"""
        branch_path = self.refs_dir / "heads" / name
        if branch_path.exists():
            branch_path.unlink()
            return True
        return False
    
    def get_branch_commit(self, name: str) -> Optional[str]:
        """获取分支指向的提交"""
        branch_path = self.refs_dir / "heads" / name
        if branch_path.exists():
            return branch_path.read_text().strip()
        return None
    
    def list_branches(self) -> List[str]:
        """列出所有分支"""
        branches = []
        heads_dir = self.refs_dir / "heads"
        if heads_dir.exists():
            for f in heads_dir.iterdir():
                branches.append(f.name)
        return branches
    
    def create_tag(self, name: str, sha1: str) -> None:
        """创建标签"""
        tag_path = self.refs_dir / "tags" / name
        tag_path.parent.mkdir(parents=True, exist_ok=True)
        tag_path.write_text(sha1 + "\n")
    
    def list_tags(self) -> List[str]:
        """列出所有标签"""
        tags = []
        tags_dir = self.refs_dir / "tags"
        if tags_dir.exists():
            tags = [f.name for f in tags_dir.iterdir()]
        return tags


# ==================== 5. 暂存区 ====================

class IndexEntry:
    """暂存区条目"""
    def __init__(self, path: str, sha1: str, mode: int = 0o100644, size: int = 0):
        self.path = path
        self.sha1 = sha1
        self.mode = mode
        self.size = size


class Index:
    """暂存区管理"""
    
    INDEX_FILE = "index"
    SIGNATURE = b"DIRC"
    VERSION = 2
    
    def __init__(self, git_dir: Path):
        self.git_dir = git_dir
        self.index_path = git_dir / self.INDEX_FILE
        self.entries: Dict[str, IndexEntry] = {}
        self.load()
    
    def load(self) -> None:
        """加载暂存区文件"""
        self.entries = {}
        if not self.index_path.exists():
            return
        
        with open(self.index_path, 'rb') as f:
            signature = f.read(4)
            if signature != self.SIGNATURE:
                return
            version = struct.unpack(">I", f.read(4))[0]
            count = struct.unpack(">I", f.read(4))[0]
            
            for _ in range(count):
                ctime_sec = struct.unpack(">I", f.read(4))[0]
                ctime_nsec = struct.unpack(">I", f.read(4))[0]
                mtime_sec = struct.unpack(">I", f.read(4))[0]
                mtime_nsec = struct.unpack(">I", f.read(4))[0]
                dev = struct.unpack(">I", f.read(4))[0]
                ino = struct.unpack(">I", f.read(4))[0]
                mode = struct.unpack(">I", f.read(4))[0]
                uid = struct.unpack(">I", f.read(4))[0]
                gid = struct.unpack(">I", f.read(4))[0]
                size = struct.unpack(">I", f.read(4))[0]
                sha1 = f.read(20).hex()
                flags = struct.unpack(">H", f.read(2))[0]
                
                # 读取路径名
                path_bytes = f.read(flags & 0xFFF)
                path = path_bytes.decode()
                
                # 对齐到8字节边界
                padding = (8 - (f.tell() % 8)) % 8
                f.read(padding)
                
                self.entries[path] = IndexEntry(path, sha1, mode, size)
    
    def save(self) -> None:
        """保存暂存区文件"""
        with open(self.index_path, 'wb') as f:
            f.write(self.SIGNATURE)
            f.write(struct.pack(">I", self.VERSION))
            f.write(struct.pack(">I", len(self.entries)))
            
            for entry in self.entries.values():
                f.write(struct.pack(">I", 0))  # ctime_sec
                f.write(struct.pack(">I", 0))  # ctime_nsec
                f.write(struct.pack(">I", 0))  # mtime_sec
                f.write(struct.pack(">I", 0))  # mtime_nsec
                f.write(struct.pack(">I", 0))  # dev
                f.write(struct.pack(">I", 0))  # ino
                f.write(struct.pack(">I", entry.mode))
                f.write(struct.pack(">I", 0))  # uid
                f.write(struct.pack(">I", 0))  # gid
                f.write(struct.pack(">I", entry.size))
                f.write(bytes.fromhex(entry.sha1))
                flags = len(entry.path) & 0xFFF
                f.write(struct.pack(">H", flags))
                f.write(entry.path.encode())
                
                # 对齐
                padding = (8 - (f.tell() % 8)) % 8
                f.write(b'\0' * padding)
    
    def add_file(self, path: str, sha1: str, mode: int = 0o100644, size: int = 0) -> None:
        """添加文件到暂存区"""
        self.entries[path] = IndexEntry(path, sha1, mode, size)
    
    def remove_file(self, path: str) -> bool:
        """从暂存区移除文件"""
        if path in self.entries:
            del self.entries[path]
            return True
        return False
    
    def get_files(self) -> List[str]:
        """获取暂存区中的文件列表"""
        return list(self.entries.keys())
    
    def is_empty(self) -> bool:
        """暂存区是否为空"""
        return len(self.entries) == 0


# ==================== 6. 差异比较 ====================

class Diff:
    """差异比较器"""
    
    @staticmethod
    def diff_files(old_content: bytes, new_content: bytes) -> List[Tuple[str, int, int, int, int]]:
        """
        比较两个文件内容
        返回: [(操作, 原起始行, 原结束行, 新起始行, 新结束行), ...]
        操作: 'equal', 'insert', 'delete', 'replace'
        """
        old_lines = old_content.decode('utf-8', errors='replace').splitlines(keepends=True)
        new_lines = new_content.decode('utf-8', errors='replace').splitlines(keepends=True)
        
        matcher = difflib.SequenceMatcher(None, old_lines, new_lines)
        changes = []
        
        for tag, old_start, old_end, new_start, new_end in matcher.get_opcodes():
            if tag == 'equal':
                changes.append(('equal', old_start, old_end, new_start, new_end))
            elif tag == 'delete':
                changes.append(('delete', old_start, old_end, new_start, new_end))
            elif tag == 'insert':
                changes.append(('insert', old_start, old_end, new_start, new_end))
            elif tag == 'replace':
                changes.append(('replace', old_start, old_end, new_start, new_end))
        
        return changes
    
    @staticmethod
    def unified_diff(old_content: bytes, new_content: bytes, old_path: str, new_path: str) -> str:
        """生成统一格式的差异"""
        old_lines = old_content.decode('utf-8', errors='replace').splitlines(keepends=True)
        new_lines = new_content.decode('utf-8', errors='replace').splitlines(keepends=True)
        
        diff = difflib.unified_diff(
            old_lines, new_lines,
            fromfile=f'a/{old_path}', tofile=f'b/{new_path}'
        )
        return ''.join(diff)


# ==================== 7. 工作区管理 ====================

class WorkingDirectory:
    """工作区管理"""
    
    def __init__(self, repo_path: Path):
        self.repo_path = repo_path
    
    def get_all_files(self) -> List[Path]:
        """获取工作区所有文件"""
        files = []
        for root, dirs, filenames in os.walk(self.repo_path):
            # 跳过 .wigit 目录
            if '.wigit' in dirs:
                dirs.remove('.wigit')
            for filename in filenames:
                path = Path(root) / filename
                files.append(path.relative_to(self.repo_path))
        return files
    
    def read_file(self, path: Path) -> bytes:
        """读取工作区文件内容"""
        full_path = self.repo_path / path
        if not full_path.exists():
            return b''
        with open(full_path, 'rb') as f:
            return f.read()
    
    def write_file(self, path: Path, content: bytes) -> None:
        """写入文件到工作区"""
        full_path = self.repo_path / path
        full_path.parent.mkdir(parents=True, exist_ok=True)
        with open(full_path, 'wb') as f:
            f.write(content)
    
    def delete_file(self, path: Path) -> None:
        """删除工作区文件"""
        full_path = self.repo_path / path
        if full_path.exists():
            full_path.unlink()
    
    def get_status(self, index: Index, storage: ObjectStorage) -> Dict[str, List[str]]:
        """
        获取工作区状态
        返回: {'added': [], 'modified': [], 'deleted': [], 'untracked': []}
        """
        status = {
            'added': [],      # 新增到暂存区
            'modified': [],   # 已修改
            'deleted': [],    # 已删除
            'untracked': []   # 未跟踪
        }
        
        # 获取暂存区文件
        staged_files = set(index.get_files())
        
        # 获取工作区所有文件
        workspace_files = {str(p) for p in self.get_all_files()}
        
        # 检查已跟踪文件的修改状态
        for path in staged_files:
            if path not in workspace_files:
                status['deleted'].append(path)
            else:
                content = self.read_file(Path(path))
                blob = Blob(content)
                if blob.hash != index.entries[path].sha1:
                    status['modified'].append(path)
        
        # 检查新增文件
        for path in workspace_files - staged_files:
            status['untracked'].append(path)
        
        # 检查暂存区新增
        for path in staged_files:
            if path in workspace_files:
                content = self.read_file(Path(path))
                blob = Blob(content)
                # 如果是新文件或者内容与工作区不同
                if path not in status['modified']:
                    status['added'].append(path)
        
        return status


# ==================== 8. 提交历史 ====================

class History:
    """提交历史管理"""
    
    def __init__(self, storage: ObjectStorage, refs: Refs):
        self.storage = storage
        self.refs = refs
    
    def get_current_commit(self) -> Optional[str]:
        """获取当前提交"""
        head = self.refs.get_head()
        if head and self.storage.object_exists(head):
            return head
        return None
    
    def get_commit_history(self, commit_sha: str, max_count: int = 100) -> List[Commit]:
        """获取提交历史"""
        history = []
        visited = set()
        queue = [commit_sha]
        
        while queue and len(history) < max_count:
            sha = queue.pop(0)
            if sha in visited:
                continue
            visited.add(sha)
            
            try:
                commit = self.storage.read_commit(sha)
                history.append(commit)
                if commit.parent_sha and commit.parent_sha not in visited:
                    queue.append(commit.parent_sha)
            except:
                pass
        
        return history
    
    def format_log(self, commit_sha: str) -> str:
        """格式化单个提交日志"""
        commit = self.storage.read_commit(commit_sha)
        timestamp = datetime.fromtimestamp(commit.timestamp)
        
        lines = []
        lines.append(f"commit {commit_sha}")
        lines.append(f"Author: {commit.author_name} <{commit.author_email}>")
        lines.append(f"Date:   {timestamp.strftime('%Y-%m-%d %H:%M:%S')}")
        lines.append("")
        lines.append(f"    {commit.message}")
        lines.append("")
        return "\n".join(lines)


# ==================== 9. 合并 ====================

class Merger:
    """合并器"""
    
    def __init__(self, storage: ObjectStorage):
        self.storage = storage
    
    def find_merge_base(self, commit1: str, commit2: str) -> Optional[str]:
        """查找两个提交的共同祖先"""
        commit1_ancestors = set()
        commit2_ancestors = set()
        
        # 获取commit1的所有祖先
        queue = [commit1]
        while queue:
            sha = queue.pop(0)
            if sha in commit1_ancestors:
                continue
            commit1_ancestors.add(sha)
            try:
                commit = self.storage.read_commit(sha)
                if commit.parent_sha:
                    queue.append(commit.parent_sha)
            except:
                pass
        
        # 查找commit2的祖先中第一个在commit1祖先中的
        queue = [commit2]
        while queue:
            sha = queue.pop(0)
            if sha in commit2_ancestors:
                continue
            commit2_ancestors.add(sha)
            if sha in commit1_ancestors:
                return sha
            try:
                commit = self.storage.read_commit(sha)
                if commit.parent_sha:
                    queue.append(commit.parent_sha)
            except:
                pass
        
        return None
    
    def three_way_merge(self, base: Tree, ours: Tree, theirs: Tree) -> Tree:
        """三方合并"""
        result = Tree()
        
        # 获取所有条目
        base_entries = {e.name: e for e in base.entries}
        our_entries = {e.name: e for e in ours.entries}
        their_entries = {e.name: e for e in theirs.entries}
        
        all_names = set(base_entries.keys()) | set(our_entries.keys()) | set(their_entries.keys())
        
        for name in all_names:
            base_entry = base_entries.get(name)
            our_entry = our_entries.get(name)
            their_entry = their_entries.get(name)
            
            # 双方都没有修改
            if our_entry == base_entry and their_entry == base_entry:
                if base_entry:
                    result.add_entry(base_entry.mode, base_entry.name, base_entry.sha1)
            
            # 只有一方修改
            elif our_entry == base_entry and their_entry != base_entry:
                result.add_entry(their_entry.mode, their_entry.name, their_entry.sha1)
            elif our_entry != base_entry and their_entry == base_entry:
                result.add_entry(our_entry.mode, our_entry.name, our_entry.sha1)
            
            # 双方都修改
            elif our_entry != base_entry and their_entry != base_entry:
                if our_entry.sha1 == their_entry.sha1:
                    # 修改相同
                    result.add_entry(our_entry.mode, our_entry.name, our_entry.sha1)
                else:
                    # 冲突
                    raise MergeConflictError(f"冲突: {name} 在两边的修改不一致")
            
            # 一方删除
            elif our_entry is None and their_entry == base_entry:
                pass  # 删除
            elif our_entry == base_entry and their_entry is None:
                pass  # 删除
            elif our_entry is None and their_entry is not None:
                result.add_entry(their_entry.mode, their_entry.name, their_entry.sha1)
            elif our_entry is not None and their_entry is None:
                result.add_entry(our_entry.mode, our_entry.name, our_entry.sha1)
        
        return result


# ==================== 10. 仓库管理 ====================

class Repository:
    """仓库管理器"""
    
    DEFAULT_GIT_DIR = ".wigit"
    
    def __init__(self, path: Path = None):
        self.path = Path(path) if path else Path.cwd()
        self.git_dir = self.path / self.DEFAULT_GIT_DIR
        self.storage = ObjectStorage(self.git_dir)
        self.refs = Refs(self.git_dir)
        self.index = Index(self.git_dir)
        self.working_dir = WorkingDirectory(self.path)
        self.history = History(self.storage, self.refs)
        self.merger = Merger(self.storage)
    
    @require_login
    def init(self, path: Path = None) -> 'Repository':
        """初始化仓库"""
        if path:
            self.path = Path(path)
            self.git_dir = self.path / self.DEFAULT_GIT_DIR
        
        if self.git_dir.exists():
            raise RepositoryError(f"仓库已存在: {self.git_dir}")
        
        # 创建目录结构
        self.git_dir.mkdir(parents=True)
        (self.git_dir / "objects").mkdir()
        (self.git_dir / "refs" / "heads").mkdir(parents=True)
        (self.git_dir / "refs" / "tags").mkdir(parents=True)
        
        # 创建初始HEAD
        self.refs.set_head_ref("refs/heads/master")
        
        # 保存配置
        config = {
            "core": {
                "repositoryformatversion": 0,
                "filemode": True,
                "bare": False
            },
            "user": {
                "name": get_current_user().get('nickname', '') if get_current_user() else '',
                "email": get_current_user().get('email', '') if get_current_user() else ''
            }
        }
        with open(self.git_dir / "config", 'w') as f:
            json.dump(config, f, indent=2)
        
        return self
    
    @require_login
    def add(self, paths: List[str]) -> None:
        """添加文件到暂存区"""
        for path_str in paths:
            file_path = Path(path_str)
            full_path = self.path / file_path
            
            if not full_path.exists():
                raise RepositoryError(f"文件不存在: {path_str}")
            
            if full_path.is_file():
                blob = Blob.from_file(full_path)
                sha1 = self.storage.write_object(blob.to_object())
                self.index.add_file(str(file_path), sha1, 0o100644, full_path.stat().st_size)
        
        self.index.save()
        _report_call("add")
    
    @require_login
    def commit(self, message: str) -> str:
        """提交更改"""
        if self.index.is_empty():
            raise RepositoryError("没有要提交的更改")
        
        # 构建Tree对象
        tree = Tree()
        for path, entry in self.index.entries.items():
            tree.add_entry(entry.mode, path, bytes.fromhex(entry.sha1))
        
        tree_sha = self.storage.write_object(tree.to_object())
        
        # 获取当前提交作为父提交
        current_commit = self.refs.get_head()
        
        # 创建Commit对象
        commit = Commit(tree_sha, current_commit, message=message)
        commit_sha = self.storage.write_object(commit.to_object())
        
        # 更新分支引用
        current_branch = self.refs.get_current_branch()
        if current_branch:
            branch_path = self.git_dir / "refs" / "heads" / current_branch
            branch_path.write_text(commit_sha + "\n")
        else:
            self.refs.set_head(commit_sha)
        
        # 清空暂存区
        self.index.entries.clear()
        self.index.save()
        
        _report_call("commit")
        return commit_sha
    
    @require_login
    def status(self) -> Dict[str, List[str]]:
        """获取工作区状态"""
        branch = self.refs.get_current_branch() or "detached HEAD"
        status = self.working_dir.get_status(self.index, self.storage)
        status['branch'] = branch
        _report_call("status")
        return status
    
    @require_login
    def log(self, max_count: int = 10) -> List[str]:
        """查看提交历史"""
        head = self.refs.get_head()
        if not head:
            raise RepositoryError("没有提交记录")
        
        commits = self.history.get_commit_history(head, max_count)
        result = []
        for commit in commits:
            result.append(self.history.format_log(commit.hash))
        
        _report_call("log")
        return result
    
    @require_login
    def branch(self, name: str = None, create: bool = False, delete: bool = False) -> Union[List[str], str]:
        """分支管理"""
        if create and name:
            head = self.refs.get_head()
            if not head:
                raise RepositoryError("没有提交记录，无法创建分支")
            self.refs.create_branch(name, head)
            return f"分支 '{name}' 创建成功"
        
        if delete and name:
            if self.refs.get_current_branch() == name:
                raise RepositoryError("不能删除当前分支")
            self.refs.delete_branch(name)
            return f"分支 '{name}' 已删除"
        
        if name:
            # 切换分支
            commit = self.refs.get_branch_commit(name)
            if not commit:
                raise RepositoryError(f"分支不存在: {name}")
            self.refs.set_head_ref(f"refs/heads/{name}")
            # 更新工作区到分支状态
            self._checkout_commit(commit)
            return f"已切换到分支 '{name}'"
        
        # 列出所有分支
        branches = self.refs.list_branches()
        current = self.refs.get_current_branch()
        return [f"* {b}" if b == current else b for b in branches]
    
    @require_login
    def checkout(self, commit_sha: str) -> None:
        """检出特定提交"""
        if not self.storage.object_exists(commit_sha):
            raise RepositoryError(f"提交不存在: {commit_sha}")
        
        self._checkout_commit(commit_sha)
        self.refs.set_head(commit_sha)
        _report_call("checkout")
    
    def _checkout_commit(self, commit_sha: str) -> None:
        """检出提交到工作区"""
        commit = self.storage.read_commit(commit_sha)
        tree = self.storage.read_tree(commit.tree_sha)
        
        self._checkout_tree(tree, self.path)
    
    def _checkout_tree(self, tree: Tree, base_path: Path) -> None:
        """递归检出树对象"""
        for entry in tree.entries:
            path = base_path / entry.name
            
            if entry.mode == TreeEntry.MODE_DIR:
                # 创建目录并递归
                path.mkdir(exist_ok=True)
                subtree = self.storage.read_tree(entry.sha1.hex())
                self._checkout_tree(subtree, path)
            else:
                # 写入文件
                blob = self.storage.read_blob(entry.sha1.hex())
                blob.write_to_file(path)
    
    @require_login
    def merge(self, branch_name: str) -> str:
        """合并分支"""
        # 获取当前分支的提交
        current_branch = self.refs.get_current_branch()
        if not current_branch:
            raise RepositoryError("当前不在任何分支上")
        
        current_commit = self.refs.get_head()
        other_commit = self.refs.get_branch_commit(branch_name)
        
        if not other_commit:
            raise RepositoryError(f"分支不存在: {branch_name}")
        
        # 查找共同祖先
        base_commit = self.merger.find_merge_base(current_commit, other_commit)
        
        if base_commit == other_commit:
            return f"已经是最新版本"
        
        if base_commit == current_commit:
            # 快进合并
            self.refs.create_branch(current_branch, other_commit)
            self.refs.set_head_ref(f"refs/heads/{current_branch}")
            self._checkout_commit(other_commit)
            return f"快进合并完成"
        
        # 三方合并
        base_tree = self.storage.read_tree(self.storage.read_commit(base_commit).tree_sha)
        current_tree = self.storage.read_tree(self.storage.read_commit(current_commit).tree_sha)
        other_tree = self.storage.read_tree(self.storage.read_commit(other_commit).tree_sha)
        
        try:
            merged_tree = self.merger.three_way_merge(base_tree, current_tree, other_tree)
        except MergeConflictError as e:
            raise MergeConflictError(str(e))
        
        # 创建合并提交
        tree_sha = self.storage.write_object(merged_tree.to_object())
        merge_commit = Commit(tree_sha, current_commit, message=f"Merge branch '{branch_name}'")
        merge_commit.parent_sha = other_commit  # 第二个父提交
        commit_sha = self.storage.write_object(merge_commit.to_object())
        
        # 更新分支
        self.refs.create_branch(current_branch, commit_sha)
        self.refs.set_head_ref(f"refs/heads/{current_branch}")
        self._checkout_commit(commit_sha)
        
        _report_call("merge")
        return f"合并完成: {commit_sha[:8]}"


# ==================== 11. 远程传输 ====================

class Remote:
    """远程仓库管理"""
    
    def __init__(self, repository: Repository):
        self.repository = repository
        self.remotes_file = repository.git_dir / "remotes"
    
    def add_remote(self, name: str, url: str) -> None:
        """添加远程仓库"""
        self.remotes_file.mkdir(exist_ok=True)
        remote_file = self.remotes_file / name
        remote_file.write_text(url)
    
    def get_remote(self, name: str) -> Optional[str]:
        """获取远程仓库URL"""
        remote_file = self.remotes_file / name
        if remote_file.exists():
            return remote_file.read_text().strip()
        return None
    
    @require_login
    def push(self, remote: str, branch: str) -> str:
        """推送到远程（本地模拟）"""
        # 本地模拟：将对象复制到另一个目录
        # 实际实现需要HTTP协议，这里简化
        _report_call("push")
        return f"已推送到远程仓库 {remote}:{branch}"
    
    @require_login
    def pull(self, remote: str, branch: str) -> str:
        """从远程拉取（本地模拟）"""
        _report_call("pull")
        return f"已从远程仓库 {remote}:{branch} 拉取"


# ==================== 12. 公开API ====================

_repository: Optional[Repository] = None


def get_repository() -> Repository:
    """获取当前仓库实例"""
    global _repository
    if _repository is None:
        _repository = Repository()
    return _repository


@require_login
def init(path: str = None) -> str:
    """初始化WiGit仓库"""
    repo = get_repository()
    repo.init(Path(path) if path else None)
    return f"已初始化空仓库: {repo.path}"


@require_login
def add(paths: List[str]) -> str:
    """添加文件到暂存区"""
    repo = get_repository()
    repo.add(paths)
    return f"已添加: {', '.join(paths)}"


@require_login
def commit(message: str) -> str:
    """提交更改"""
    repo = get_repository()
    sha = repo.commit(message)
    return f"[{sha[:8]}] {message}"


@require_login
def status() -> Dict:
    """查看状态"""
    repo = get_repository()
    return repo.status()


@require_login
def log(max_count: int = 10) -> None:
    """查看提交历史"""
    repo = get_repository()
    logs = repo.log(max_count)
    for log in logs:
        print(log)


@require_login
def branch(name: str = None, create: bool = False, delete: bool = False) -> Union[List[str], str]:
    """分支管理"""
    repo = get_repository()
    return repo.branch(name, create, delete)


@require_login
def checkout(target: str) -> str:
    """检出分支或提交"""
    repo = get_repository()
    # 检查是否是分支
    branches = repo.refs.list_branches()
    if target in branches:
        repo.branch(target)  # 切换分支
        return f"已切换到分支 '{target}'"
    else:
        repo.checkout(target)
        return f"已检出提交 {target[:8]}"


@require_login
def merge(branch: str) -> str:
    """合并分支"""
    repo = get_repository()
    return repo.merge(branch)


@require_login
def push(remote: str = "origin", branch: str = "master") -> str:
    """推送到远程"""
    repo = get_repository()
    remote_handler = Remote(repo)
    return remote_handler.push(remote, branch)


@require_login
def pull(remote: str = "origin", branch: str = "master") -> str:
    """从远程拉取"""
    repo = get_repository()
    remote_handler = Remote(repo)
    return remote_handler.pull(remote, branch)


def version() -> str:
    """获取版本号"""
    return "1.0.0"


def whoami() -> Optional[Dict]:
    """获取当前登录用户"""
    return get_current_user()


# 导出公共API
__all__ = [
    'login', 'logout', 'is_logged_in', 'whoami',
    'init', 'add', 'commit', 'status', 'log',
    'branch', 'checkout', 'merge', 'push', 'pull',
    'version'
]
