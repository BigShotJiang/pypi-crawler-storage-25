# -*- coding: utf-8 -*-
"""
Plus.py - WiGit 五大增强层
包含：实时协作、AI原生集成、多模态版本控制、经济激励、认知增强

使用前必须先登录并初始化仓库
"""

import os
import sys
import json
import time
import threading
import asyncio
import hashlib
import base64
import requests
import re
import difflib
import uuid
from pathlib import Path
from datetime import datetime
from typing import Optional, Dict, Any, List, Tuple, Set, Callable, Union
from dataclasses import dataclass, field
from collections import defaultdict
import sqlite3

# 尝试导入可选依赖
try:
    import openai
except ImportError:
    openai = None

try:
    from websocket import create_connection, WebSocketApp
except ImportError:
    WebSocketApp = None


# ==================== 辅助工具函数 ====================

def safe_json_parse(response: str, default: Dict = None) -> Dict:
    """安全解析JSON响应"""
    if default is None:
        default = {}
    try:
        json_start = response.find('{')
        json_end = response.rfind('}') + 1
        if json_start != -1 and json_end > json_start:
            return json.loads(response[json_start:json_end])
    except:
        pass
    return default


def get_current_user() -> str:
    """获取当前用户"""
    try:
        from wigit import get_current_user as _get_user
        user = _get_user()
        return user.get('nickname', user.get('username', 'anonymous')) if user else 'anonymous'
    except:
        return 'anonymous'


def get_current_branch() -> str:
    """获取当前分支"""
    try:
        from wigit import get_repository
        repo = get_repository()
        return repo.refs.get_current_branch() or "detached"
    except:
        return "unknown"


def get_current_commit() -> str:
    """获取当前commit"""
    try:
        from wigit import get_repository
        repo = get_repository()
        return repo.refs.get_head() or ''
    except:
        return ''


# ==================== 1. 实时协作层 ====================

class RealTimeCollaboration:
    """
    实时协作层 - 像Figma一样的实时编辑体验
    功能：操作流回放、光标同步、时间旅行调试、代码幽灵
    """
    
    def __init__(self, repo_path: str):
        self.repo_path = Path(repo_path)
        self.wigit_dir = self.repo_path / ".wigit"
        self.realtime_dir = self.wigit_dir / "realtime"
        self.realtime_dir.mkdir(parents=True, exist_ok=True)
        
        # WebSocket连接
        self.ws = None
        self.ws_thread = None
        self.connected = False
        self.session_id = self._generate_session_id()
        
        # 操作流
        self.operations: List[Dict] = []
        self.operation_file = self.realtime_dir / "operations.json"
        self.load_operations()
        
        # 光标位置
        self.cursors: Dict[str, Dict] = {}
        self.cursor_file = self.realtime_dir / "cursors.json"
        self.load_cursors()
        
        # 代码幽灵注释
        self.ghost_annotations: Dict[str, List[Dict]] = {}
        self.ghost_file = self.realtime_dir / "ghosts.json"
        self.load_ghosts()
        
        # 时间旅行快照
        self.snapshots: Dict[str, Dict] = {}
        self.snapshot_dir = self.realtime_dir / "snapshots"
        self.snapshot_dir.mkdir(exist_ok=True)
        
        # 操作回调
        self.operation_callbacks: List[Callable] = []
    
    def _generate_session_id(self) -> str:
        """生成会话ID"""
        return str(uuid.uuid4())
    
    def load_operations(self):
        """加载操作流"""
        if self.operation_file.exists():
            with open(self.operation_file, 'r', encoding='utf-8') as f:
                self.operations = json.load(f)
    
    def save_operations(self):
        """保存操作流"""
        with open(self.operation_file, 'w', encoding='utf-8') as f:
            json.dump(self.operations, f, ensure_ascii=False, indent=2)
    
    def load_cursors(self):
        """加载光标位置"""
        if self.cursor_file.exists():
            with open(self.cursor_file, 'r', encoding='utf-8') as f:
                self.cursors = json.load(f)
    
    def save_cursors(self):
        """保存光标位置"""
        # 转换set为list以便JSON序列化
        serializable_cursors = {}
        for sid, cursor in self.cursors.items():
            cursor_copy = cursor.copy()
            if 'viewers' in cursor_copy and isinstance(cursor_copy['viewers'], set):
                cursor_copy['viewers'] = list(cursor_copy['viewers'])
            serializable_cursors[sid] = cursor_copy
        with open(self.cursor_file, 'w', encoding='utf-8') as f:
            json.dump(serializable_cursors, f, ensure_ascii=False, indent=2)
    
    def load_ghosts(self):
        """加载代码幽灵注释"""
        if self.ghost_file.exists():
            with open(self.ghost_file, 'r', encoding='utf-8') as f:
                self.ghost_annotations = json.load(f)
    
    def save_ghosts(self):
        """保存代码幽灵注释"""
        with open(self.ghost_file, 'w', encoding='utf-8') as f:
            json.dump(self.ghost_annotations, f, ensure_ascii=False, indent=2)
    
    def register_callback(self, callback: Callable):
        """注册操作回调"""
        self.operation_callbacks.append(callback)
    
    def record_operation(self, op_type: str, file_path: str, data: Dict):
        """
        记录操作到操作流
        op_type: 'edit', 'cursor_move', 'add', 'delete', 'rename'
        """
        operation = {
            "id": str(uuid.uuid4()),
            "session_id": self.session_id,
            "timestamp": time.time(),
            "type": op_type,
            "file": file_path,
            "data": data,
            "user": get_current_user()
        }
        self.operations.append(operation)
        self.save_operations()
        
        # 触发回调
        for callback in self.operation_callbacks:
            try:
                callback(operation)
            except Exception as e:
                print(f"回调执行失败: {e}")
        
        # 实时广播（如果WebSocket连接）
        if self.connected and self.ws:
            try:
                self.ws.send(json.dumps(operation))
            except:
                pass
        
        return operation
    
    def replay_operations(self, start_time: float = None, end_time: float = None, speed: float = 1.0):
        """
        操作流回放 - 像视频一样回放代码编辑过程
        """
        ops = self.operations
        if start_time:
            ops = [op for op in ops if op['timestamp'] >= start_time]
        if end_time:
            ops = [op for op in ops if op['timestamp'] <= end_time]
        
        print(f"开始回放 {len(ops)} 个操作...")
        
        prev_time = None
        for op in ops:
            if prev_time is not None:
                delay = (op['timestamp'] - prev_time) / speed
                if delay > 0:
                    time.sleep(delay)
            
            self._apply_operation(op)
            print(f"[{op['type']}] {op['file']}: {op['data']}")
            prev_time = op['timestamp']
        
        print("回放结束")
        return {"replayed_count": len(ops), "duration": prev_time - (start_time or ops[0]['timestamp']) if ops else 0}
    
    def _apply_operation(self, operation: Dict):
        """应用单个操作（回放时使用）"""
        op_type = operation['type']
        file_path = operation['file']
        data = operation['data']
        
        if op_type == 'cursor_move':
            pass
        elif op_type == 'edit':
            full_path = self.repo_path / file_path
            if full_path.exists():
                content = full_path.read_text(encoding='utf-8')
                if 'line' in data and 'old_text' in data and 'new_text' in data:
                    lines = content.splitlines()
                    if 0 <= data['line'] < len(lines):
                        lines[data['line']] = lines[data['line']].replace(
                            data['old_text'], data['new_text']
                        )
                        full_path.write_text('\n'.join(lines), encoding='utf-8')
    
    def update_cursor(self, file_path: str, line: int, column: int):
        """更新光标位置（实时同步）"""
        self.cursors[self.session_id] = {
            "file": file_path,
            "line": line,
            "column": column,
            "timestamp": time.time(),
            "user": get_current_user()
        }
        self.save_cursors()
        self.record_operation("cursor_move", file_path, {"line": line, "column": column})
    
    def get_cursors(self) -> Dict:
        """获取所有协作者的光标位置"""
        now = time.time()
        expired = []
        for sid, cursor in self.cursors.items():
            if now - cursor.get('timestamp', 0) > 10:
                expired.append(sid)
        for sid in expired:
            del self.cursors[sid]
        return self.cursors
    
    def add_ghost_annotation(self, file_path: str, line: int, text: str, author: str = None, context: str = ""):
        """
        添加代码幽灵注释 - 显示"这段代码是谁写的、基于什么上下文、当时解决了什么问题"
        """
        if file_path not in self.ghost_annotations:
            self.ghost_annotations[file_path] = []
        
        annotation = {
            "id": str(uuid.uuid4()),
            "line": line,
            "text": text,
            "author": author or get_current_user(),
            "context": context,
            "timestamp": time.time(),
            "commit": get_current_commit()
        }
        self.ghost_annotations[file_path].append(annotation)
        self.save_ghosts()
        
        return annotation
    
    def get_ghost_annotations(self, file_path: str, line: int = None) -> List[Dict]:
        """获取代码幽灵注释"""
        annotations = self.ghost_annotations.get(file_path, [])
        if line is not None:
            annotations = [a for a in annotations if a['line'] == line]
        return annotations
    
    def remove_ghost_annotation(self, file_path: str, annotation_id: str) -> bool:
        """删除代码幽灵注释"""
        if file_path in self.ghost_annotations:
            original_len = len(self.ghost_annotations[file_path])
            self.ghost_annotations[file_path] = [
                a for a in self.ghost_annotations[file_path] 
                if a.get('id') != annotation_id
            ]
            if len(self.ghost_annotations[file_path]) != original_len:
                self.save_ghosts()
                return True
        return False
    
    def create_time_travel_snapshot(self, commit_sha: str):
        """
        创建时间旅行快照 - 在历史commit上启动可交互的运行时环境
        """
        snapshot = {
            "commit": commit_sha,
            "timestamp": time.time(),
            "files": {},
            "environment": self._capture_environment()
        }
        
        # 保存当前工作区快照
        for file_path in self.repo_path.rglob("*"):
            if file_path.is_file() and not str(file_path).startswith(str(self.wigit_dir)):
                try:
                    rel_path = str(file_path.relative_to(self.repo_path))
                    snapshot["files"][rel_path] = file_path.read_text(encoding='utf-8')
                except:
                    pass
        
        snapshot_path = self.snapshot_dir / f"{commit_sha}.json"
        with open(snapshot_path, 'w', encoding='utf-8') as f:
            json.dump(snapshot, f, ensure_ascii=False, indent=2)
        
        self.snapshots[commit_sha] = snapshot
        return snapshot
    
    def travel_to_snapshot(self, commit_sha: str, dry_run: bool = False):
        """
        时间旅行 - 跳转到指定快照
        """
        snapshot_path = self.snapshot_dir / f"{commit_sha}.json"
        if not snapshot_path.exists():
            raise ValueError(f"快照不存在: {commit_sha}")
        
        with open(snapshot_path, 'r', encoding='utf-8') as f:
            snapshot = json.load(f)
        
        print(f"正在跳转到提交 {commit_sha}...")
        print(f"快照时间: {datetime.fromtimestamp(snapshot['timestamp'])}")
        
        if not dry_run:
            # 备份当前状态
            backup_path = self.snapshot_dir / f"backup_{int(time.time())}.json"
            current_snapshot = {
                "timestamp": time.time(),
                "files": {}
            }
            for file_path in self.repo_path.rglob("*"):
                if file_path.is_file() and not str(file_path).startswith(str(self.wigit_dir)):
                    try:
                        rel_path = str(file_path.relative_to(self.repo_path))
                        current_snapshot["files"][rel_path] = file_path.read_text(encoding='utf-8')
                    except:
                        pass
            with open(backup_path, 'w', encoding='utf-8') as f:
                json.dump(current_snapshot, f, ensure_ascii=False, indent=2)
            
            # 恢复快照
            for file_path, content in snapshot['files'].items():
                full_path = self.repo_path / file_path
                full_path.parent.mkdir(parents=True, exist_ok=True)
                full_path.write_text(content, encoding='utf-8')
        
        return snapshot
    
    def _capture_environment(self) -> Dict:
        """捕获当前运行环境"""
        import sys, platform
        return {
            "python_version": sys.version,
            "platform": platform.platform(),
            "working_dir": str(self.repo_path),
            "timestamp": time.time()
        }
    
    def connect_websocket(self, server_url: str):
        """连接到WebSocket服务器进行实时协作"""
        if WebSocketApp is None:
            raise ImportError("需要安装 websocket-client: pip install websocket-client")
        
        def on_message(ws, message):
            data = json.loads(message)
            self._apply_operation(data)
            print(f"收到实时更新: {data}")
        
        def on_error(ws, error):
            print(f"WebSocket错误: {error}")
        
        def on_close(ws, close_status_code, close_msg):
            self.connected = False
            print("WebSocket连接已关闭")
        
        def on_open(ws):
            self.connected = True
            print("WebSocket连接已建立")
            ws.send(json.dumps({
                "type": "join",
                "session_id": self.session_id,
                "user": get_current_user()
            }))
        
        self.ws = WebSocketApp(
            server_url,
            on_open=on_open,
            on_message=on_message,
            on_error=on_error,
            on_close=on_close
        )
        
        self.ws_thread = threading.Thread(target=self.ws.run_forever, daemon=True)
        self.ws_thread.start()
    
    def disconnect_websocket(self):
        """断开WebSocket连接"""
        if self.ws:
            self.ws.close()
            self.connected = False
            self.ws = None


# ==================== 2. AI原生集成层 ====================

class AIIntegration:
    """
    AI原生集成层
    功能：语义提交、智能合并、知识图谱
    使用DeepSeek API
    """
    
    DEEPSEEK_API_URL = "https://api.deepseek.com/v1/chat/completions"
    DEEPSEEK_API_KEY = "sk-8f369fc4e4f44b3189cefb43cc5f505c"
    
    def __init__(self, repo_path: str):
        self.repo_path = Path(repo_path)
        self.wigit_dir = self.repo_path / ".wigit"
        self.ai_dir = self.wigit_dir / "ai"
        self.ai_dir.mkdir(parents=True, exist_ok=True)
        
        # 知识图谱数据库
        self.knowledge_db = self.ai_dir / "knowledge.db"
        self._init_knowledge_db()
        
        # API调用统计
        self.api_calls_file = self.ai_dir / "api_stats.json"
        self.api_stats = self._load_json(self.api_calls_file)
    
    def _load_json(self, file_path: Path) -> Dict:
        if file_path.exists():
            with open(file_path, 'r', encoding='utf-8') as f:
                return json.load(f)
        return {}
    
    def _save_json(self, data: Dict, file_path: Path):
        with open(file_path, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
    
    def _init_knowledge_db(self):
        """初始化知识图谱数据库"""
        self.conn = sqlite3.connect(str(self.knowledge_db))
        self.conn.execute('''
            CREATE TABLE IF NOT EXISTS entities (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                type TEXT NOT NULL,
                name TEXT NOT NULL,
                metadata TEXT,
                created_at REAL
            )
        ''')
        self.conn.execute('''
            CREATE TABLE IF NOT EXISTS relations (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                from_entity INTEGER,
                to_entity INTEGER,
                relation_type TEXT,
                weight REAL DEFAULT 1.0,
                FOREIGN KEY (from_entity) REFERENCES entities(id),
                FOREIGN KEY (to_entity) REFERENCES entities(id)
            )
        ''')
        self.conn.execute('CREATE INDEX IF NOT EXISTS idx_entity_name ON entities(name)')
        self.conn.execute('CREATE INDEX IF NOT EXISTS idx_entity_type ON entities(type)')
        self.conn.commit()
    
    def _call_deepseek(self, messages: List[Dict], temperature: float = 0.7) -> str:
        """调用DeepSeek API"""
        headers = {
            "Authorization": f"Bearer {self.DEEPSEEK_API_KEY}",
            "Content-Type": "application/json"
        }
        
        payload = {
            "model": "deepseek-chat",
            "messages": messages,
            "temperature": temperature,
            "max_tokens": 2000
        }
        
        # 更新统计
        self.api_stats['last_call'] = time.time()
        self.api_stats['total_calls'] = self.api_stats.get('total_calls', 0) + 1
        self._save_json(self.api_stats, self.api_calls_file)
        
        try:
            response = requests.post(
                self.DEEPSEEK_API_URL,
                headers=headers,
                json=payload,
                timeout=30
            )
            result = response.json()
            return result['choices'][0]['message']['content']
        except Exception as e:
            print(f"DeepSeek API调用失败: {e}")
            return ""
    
    def semantic_commit(self, diff_content: str) -> Dict:
        """
        语义提交 - AI自动理解改动意图，生成结构化commit
        """
        prompt = f"""
        分析以下代码变更，生成结构化的提交信息。
        
        代码变更:
        {diff_content[:3000]}
        
        请返回JSON格式：
        {{
            "message": "提交标题（格式：type: subject）",
            "impact_analysis": "影响面分析（50字以内）",
            "test_suggestions": ["测试建议1", "测试建议2"],
            "breaking_changes": false,
            "related_issues": []
        }}
        
        type可以是: feat, fix, docs, style, refactor, perf, test, chore
        """
        
        messages = [
            {"role": "system", "content": "你是一个代码分析专家，擅长分析代码变更并生成规范的提交信息。"},
            {"role": "user", "content": prompt}
        ]
        
        response = self._call_deepseek(messages)
        return safe_json_parse(response, {
            "message": "update: 代码更新",
            "impact_analysis": "常规代码变更",
            "test_suggestions": ["运行现有测试"],
            "breaking_changes": False,
            "related_issues": []
        })
    
    def smart_merge(self, base_content: str, ours_content: str, theirs_content: str, file_path: str) -> Dict:
        """
        智能合并 - 理解代码语义而非文本行，自动解决冲突并解释决策逻辑
        """
        prompt = f"""
        请智能合并以下三个版本的代码文件（{file_path}）。
        
        基础版本（base）:
        {base_content[:1000]}
        
        我们的版本（ours）:
        {ours_content[:1000]}
        
        他们的版本（theirs）:
        {theirs_content[:1000]}
        
        请分析语义差异，智能解决冲突。返回JSON：
        {{
            "merged_content": "完整的合并后代码",
            "resolutions": [
                {{"line": 行号, "decision": "使用我们的版本/他们的版本/自定义合并", "reason": "决策理由"}}
            ],
            "has_conflict": false
        }}
        """
        
        messages = [
            {"role": "system", "content": "你是一个代码合并专家，擅长语义级别的智能合并，能够理解代码逻辑而非简单的文本行对比。"},
            {"role": "user", "content": prompt}
        ]
        
        response = self._call_deepseek(messages, temperature=0.3)
        result = safe_json_parse(response, {
            "merged_content": ours_content,
            "resolutions": [],
            "has_conflict": False
        })
        
        # 确保merged_content不为空
        if not result.get('merged_content'):
            result['merged_content'] = ours_content
        
        return result
    
    def build_knowledge_graph(self, commits: List[Dict] = None, issues: List[Dict] = None, discussions: List[Dict] = None):
        """
        自动构建代码-需求-文档-讨论的知识图谱
        """
        commits = commits or []
        issues = issues or []
        discussions = discussions or []
        
        for commit in commits:
            self._add_entity("commit", commit.get('sha', ''), json.dumps(commit))
            for file in commit.get('files', []):
                self._add_entity("file", file, '')
                self._add_relation(commit.get('sha', ''), file, "modifies")
        
        for issue in issues:
            self._add_entity("issue", issue.get('id', ''), json.dumps(issue))
            if issue.get('commit'):
                self._add_relation(issue.get('id', ''), issue.get('commit'), "resolved_by")
        
        for discussion in discussions:
            self._add_entity("discussion", discussion.get('id', ''), json.dumps(discussion))
            if discussion.get('issue'):
                self._add_relation(discussion.get('id', ''), discussion.get('issue'), "related_to")
        
        return {"entities_added": len(commits) + len(issues) + len(discussions)}
    
    def _add_entity(self, entity_type: str, name: str, metadata: str):
        """添加知识图谱实体"""
        cursor = self.conn.cursor()
        cursor.execute(
            "INSERT OR IGNORE INTO entities (type, name, metadata, created_at) VALUES (?, ?, ?, ?)",
            (entity_type, name, metadata, time.time())
        )
        self.conn.commit()
    
    def _add_relation(self, from_name: str, to_name: str, relation_type: str):
        """添加关系"""
        cursor = self.conn.cursor()
        
        cursor.execute("SELECT id FROM entities WHERE name = ?", (from_name,))
        from_row = cursor.fetchone()
        cursor.execute("SELECT id FROM entities WHERE name = ?", (to_name,))
        to_row = cursor.fetchone()
        
        if from_row and to_row:
            cursor.execute(
                "INSERT OR IGNORE INTO relations (from_entity, to_entity, relation_type) VALUES (?, ?, ?)",
                (from_row[0], to_row[0], relation_type)
            )
            self.conn.commit()
    
    def query_knowledge_graph(self, query: str) -> List[Dict]:
        """
        查询知识图谱 - git log 变成可查询的知识库
        """
        cursor = self.conn.cursor()
        
        # 支持多种查询方式
        results = []
        
        # 按名称查询
        cursor.execute(
            "SELECT type, name, metadata FROM entities WHERE name LIKE ? LIMIT 50",
            (f'%{query}%',)
        )
        results.extend(cursor.fetchall())
        
        # 按元数据查询
        cursor.execute(
            "SELECT type, name, metadata FROM entities WHERE metadata LIKE ? LIMIT 50",
            (f'%{query}%',)
        )
        results.extend(cursor.fetchall())
        
        # 去重
        seen = set()
        unique_results = []
        for r in results:
            key = (r[0], r[1])
            if key not in seen:
                seen.add(key)
                unique_results.append(r)
        
        return [{"type": r[0], "name": r[1], "metadata": r[2]} for r in unique_results[:50]]
    
    def get_related_entities(self, entity_name: str, relation_type: str = None) -> List[Dict]:
        """获取相关实体"""
        cursor = self.conn.cursor()
        
        if relation_type:
            cursor.execute("""
                SELECT e.type, e.name, e.metadata, r.relation_type
                FROM relations r
                JOIN entities e ON r.to_entity = e.id
                JOIN entities e2 ON r.from_entity = e2.id
                WHERE e2.name = ? AND r.relation_type = ?
            """, (entity_name, relation_type))
        else:
            cursor.execute("""
                SELECT e.type, e.name, e.metadata, r.relation_type
                FROM relations r
                JOIN entities e ON r.to_entity = e.id
                JOIN entities e2 ON r.from_entity = e2.id
                WHERE e2.name = ?
            """, (entity_name,))
        
        return [{"type": r[0], "name": r[1], "metadata": r[2], "relation": r[3]} for r in cursor.fetchall()]
    
    def analyze_code_complexity(self, code_content: str) -> Dict:
        """
        AI分析代码复杂度
        """
        prompt = f"""
        分析以下代码的复杂度，返回JSON：
        
        代码：
        {code_content[:2000]}
        
        返回格式：
        {{
            "complexity_score": 0-100,
            "cognitive_load": "低/中/高",
            "suggestions": ["优化建议1", "优化建议2"],
            "readability": "优/良/中/差"
        }}
        """
        
        messages = [
            {"role": "system", "content": "你是一个代码质量分析专家。"},
            {"role": "user", "content": prompt}
        ]
        
        response = self._call_deepseek(messages, temperature=0.3)
        return safe_json_parse(response, {
            "complexity_score": 0,
            "cognitive_load": "未知",
            "suggestions": [],
            "readability": "良"
        })
    
    def generate_documentation(self, code_content: str, code_type: str = "function") -> str:
        """AI生成代码文档"""
        prompt = f"""
        请为以下{code_type}生成详细的文档注释：
        
        {code_content}
        
        请生成符合规范的文档注释，包括功能描述、参数说明、返回值说明、使用示例。
        """
        
        messages = [
            {"role": "system", "content": "你是一个技术文档专家，擅长生成清晰准确的代码文档。"},
            {"role": "user", "content": prompt}
        ]
        
        return self._call_deepseek(messages)
    
    def explain_code(self, code_content: str) -> str:
        """AI解释代码逻辑"""
        prompt = f"""
        请解释以下代码的功能和实现逻辑：
        
        {code_content[:2000]}
        
        请用通俗易懂的语言解释这段代码做了什么，以及为什么要这样实现。
        """
        
        messages = [
            {"role": "system", "content": "你是一个代码教学专家，擅长用简单语言解释复杂代码。"},
            {"role": "user", "content": prompt}
        ]
        
        return self._call_deepseek(messages)
    
    def review_code(self, code_content: str, file_path: str = "") -> Dict:
        """AI代码审查"""
        prompt = f"""
        请对以下代码进行全面的代码审查：
        
        文件: {file_path}
        代码:
        {code_content[:3000]}
        
        请返回JSON格式：
        {{
            "overall_score": 0-100,
            "issues": [
                {{"severity": "critical/major/minor", "line": 行号, "message": "问题描述", "suggestion": "改进建议"}}
            ],
            "strengths": ["优点1", "优点2"],
            "summary": "总结"
        }}
        """
        
        messages = [
            {"role": "system", "content": "你是一个资深代码审查专家，擅长发现代码问题和提供改进建议。"},
            {"role": "user", "content": prompt}
        ]
        
        response = self._call_deepseek(messages, temperature=0.3)
        return safe_json_parse(response, {
            "overall_score": 50,
            "issues": [],
            "strengths": [],
            "summary": "代码审查完成"
        })
    
    def close(self):
        """关闭数据库连接"""
        if hasattr(self, 'conn'):
            self.conn.close()


# ==================== 3. 多模态版本控制 ====================

class MultimodalVersionControl:
    """
    多模态版本控制
    功能：设计稿版本化、API契约版本化、数据库Schema版本化
    """
    
    def __init__(self, repo_path: str):
        self.repo_path = Path(repo_path)
        self.wigit_dir = self.repo_path / ".wigit"
        self.multimodal_dir = self.wigit_dir / "multimodal"
        self.multimodal_dir.mkdir(parents=True, exist_ok=True)
        
        # 设计稿版本记录
        self.design_versions_file = self.multimodal_dir / "design_versions.json"
        self.design_versions = self._load_json(self.design_versions_file)
        
        # API契约版本记录
        self.api_versions_file = self.multimodal_dir / "api_versions.json"
        self.api_versions = self._load_json(self.api_versions_file)
        
        # Schema版本记录
        self.schema_versions_file = self.multimodal_dir / "schema_versions.json"
        self.schema_versions = self._load_json(self.schema_versions_file)
        
        # 设计稿差异存储目录
        self.design_diff_dir = self.multimodal_dir / "design_diffs"
        self.design_diff_dir.mkdir(exist_ok=True)
    
    def _load_json(self, file_path: Path) -> Dict:
        if file_path.exists():
            with open(file_path, 'r', encoding='utf-8') as f:
                return json.load(f)
        return {}
    
    def _save_json(self, data: Dict, file_path: Path):
        with open(file_path, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
    
    # ===== 设计稿版本化 =====
    
    def version_design(self, design_path: str, metadata: Dict = None) -> Dict:
        """
        版本化设计稿（Figma/Sketch文件）
        """
        design_file = self.repo_path / design_path
        if not design_file.exists():
            raise FileNotFoundError(f"设计文件不存在: {design_path}")
        
        with open(design_file, 'rb') as f:
            file_hash = hashlib.sha256(f.read()).hexdigest()
        
        version_id = f"design_v{len(self.design_versions) + 1}"
        self.design_versions[version_id] = {
            "version_id": version_id,
            "file": design_path,
            "hash": file_hash,
            "timestamp": time.time(),
            "metadata": metadata or {},
            "branch": get_current_branch()
        }
        
        self._save_json(self.design_versions, self.design_versions_file)
        
        return {
            "version_id": version_id,
            "file": design_path,
            "hash": file_hash
        }
    
    def diff_design(self, version1: str, version2: str) -> Dict:
        """
        比较两个版本的设计稿
        """
        v1 = self.design_versions.get(version1)
        v2 = self.design_versions.get(version2)
        
        if not v1 or not v2:
            raise ValueError("版本不存在")
        
        return {
            "version1": version1,
            "version2": version2,
            "file": v1['file'],
            "hash_changed": v1['hash'] != v2['hash'],
            "timestamp_diff": v2['timestamp'] - v1['timestamp'],
            "v1_info": v1,
            "v2_info": v2
        }
    
    def list_design_versions(self, limit: int = 20) -> List[Dict]:
        """列出设计稿版本"""
        versions = list(self.design_versions.values())
        versions.sort(key=lambda x: x.get('timestamp', 0), reverse=True)
        return versions[:limit]
    
    # ===== API契约版本化 =====
    
    def version_api(self, api_spec: Dict, spec_type: str = "openapi") -> Dict:
        """
        版本化API契约（OpenAPI/Protobuf）
        """
        version_id = f"api_v{len(self.api_versions) + 1}"
        
        breaking_changes = self._detect_breaking_changes(api_spec, spec_type)
        
        self.api_versions[version_id] = {
            "version_id": version_id,
            "timestamp": time.time(),
            "spec": api_spec,
            "spec_type": spec_type,
            "breaking_changes": breaking_changes,
            "branch": get_current_branch()
        }
        
        self._save_json(self.api_versions, self.api_versions_file)
        
        return {
            "version_id": version_id,
            "breaking_changes": breaking_changes,
            "is_breaking": len(breaking_changes) > 0
        }
    
    def _detect_breaking_changes(self, new_spec: Dict, spec_type: str) -> List[Dict]:
        """
        检测API的breaking changes
        """
        changes = []
        
        if spec_type == "openapi" and self.api_versions:
            prev_version = list(self.api_versions.values())[-1] if self.api_versions else None
            if prev_version:
                prev_spec = prev_version.get('spec', {})
                
                prev_paths = set(prev_spec.get('paths', {}).keys())
                new_paths = set(new_spec.get('paths', {}).keys())
                
                removed_paths = prev_paths - new_paths
                for path in removed_paths:
                    changes.append({
                        "type": "endpoint_removed",
                        "path": path,
                        "severity": "breaking",
                        "description": f"端点 {path} 已被移除"
                    })
                
                added_paths = new_paths - prev_paths
                for path in added_paths:
                    changes.append({
                        "type": "endpoint_added",
                        "path": path,
                        "severity": "non-breaking",
                        "description": f"新增端点 {path}"
                    })
        
        return changes
    
    def list_api_versions(self, limit: int = 20) -> List[Dict]:
        """列出API版本"""
        versions = list(self.api_versions.values())
        versions.sort(key=lambda x: x.get('timestamp', 0), reverse=True)
        return versions[:limit]
    
    # ===== 数据库Schema版本化 =====
    
    def version_schema(self, schema_sql: str, database: str) -> Dict:
        """
        版本化数据库Schema
        """
        version_id = f"schema_v{len(self.schema_versions) + 1}"
        
        parsed_schema = self._parse_schema(schema_sql)
        compatibility = self._analyze_compatibility(parsed_schema)
        
        self.schema_versions[version_id] = {
            "version_id": version_id,
            "timestamp": time.time(),
            "database": database,
            "schema": schema_sql,
            "parsed": parsed_schema,
            "compatibility": compatibility
        }
        
        self._save_json(self.schema_versions, self.schema_versions_file)
        
        return {
            "version_id": version_id,
            "compatibility": compatibility,
            "is_compatible": compatibility.get('compatible', True)
        }
    
    def _parse_schema(self, schema_sql: str) -> Dict:
        """解析SQL Schema"""
        tables = re.findall(r'CREATE TABLE (\w+)', schema_sql, re.IGNORECASE)
        columns = re.findall(r'CREATE TABLE \w+\s*\((.*?)\)', schema_sql, re.IGNORECASE | re.DOTALL)
        
        return {
            "tables": tables,
            "table_count": len(tables),
            "raw_length": len(schema_sql)
        }
    
    def _analyze_compatibility(self, new_schema: Dict) -> Dict:
        """分析Schema兼容性"""
        if not self.schema_versions:
            return {"compatible": True, "issues": [], "level": "full"}
        
        prev_version = list(self.schema_versions.values())[-1]
        prev_parsed = prev_version.get('parsed', {})
        
        prev_tables = set(prev_parsed.get('tables', []))
        new_tables = set(new_schema.get('tables', []))
        
        removed_tables = prev_tables - new_tables
        added_tables = new_tables - prev_tables
        
        issues = []
        for table in removed_tables:
            issues.append({
                "type": "table_removed",
                "table": table,
                "severity": "breaking",
                "data_compatibility": "data_required_backup"
            })
        
        for table in added_tables:
            issues.append({
                "type": "table_added",
                "table": table,
                "severity": "non-breaking",
                "data_compatibility": "safe"
            })
        
        return {
            "compatible": len(removed_tables) == 0,
            "issues": issues,
            "added_tables": list(added_tables),
            "removed_tables": list(removed_tables)
        }
    
    def diff_schema(self, version1: str, version2: str) -> Dict:
        """
        比较两个版本的数据库Schema
        """
        v1 = self.schema_versions.get(version1)
        v2 = self.schema_versions.get(version2)
        
        if not v1 or not v2:
            raise ValueError("版本不存在")
        
        diff = difflib.unified_diff(
            v1['schema'].splitlines(),
            v2['schema'].splitlines(),
            fromfile=version1,
            tofile=version2
        )
        
        return {
            "version1": version1,
            "version2": version2,
            "database": v1['database'],
            "diff": '\n'.join(diff),
            "diff_lines": len(list(diff)),
            "compatibility_from": v1.get('compatibility', {}),
            "compatibility_to": v2.get('compatibility', {})
        }
    
    def list_schema_versions(self, limit: int = 20) -> List[Dict]:
        """列出Schema版本"""
        versions = list(self.schema_versions.values())
        versions.sort(key=lambda x: x.get('timestamp', 0), reverse=True)
        return versions[:limit]


# ==================== 4. 经济/激励层 ====================

class EconomyLayer:
    """
    经济/激励层（Web3思路但实用）
    功能：贡献度NFT、代码悬赏、声誉系统
    """
    
    def __init__(self, repo_path: str):
        self.repo_path = Path(repo_path)
        self.wigit_dir = self.repo_path / ".wigit"
        self.economy_dir = self.wigit_dir / "economy"
        self.economy_dir.mkdir(parents=True, exist_ok=True)
        
        self.nft_file = self.economy_dir / "nft.json"
        self.nfts = self._load_json(self.nft_file)
        
        self.bounty_file = self.economy_dir / "bounties.json"
        self.bounties = self._load_json(self.bounty_file)
        
        self.reputation_file = self.economy_dir / "reputation.json"
        self.reputations = self._load_json(self.reputation_file)
        
        self.transaction_file = self.economy_dir / "transactions.json"
        self.transactions = self._load_json(self.transaction_file)
    
    def _load_json(self, file_path: Path) -> Dict:
        if file_path.exists():
            with open(file_path, 'r', encoding='utf-8') as f:
                return json.load(f)
        return {}
    
    def _save_json(self, data: Dict, file_path: Path):
        with open(file_path, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
    
    def _record_transaction(self, tx_type: str, from_user: str, to_user: str, amount: Dict, description: str = ""):
        """记录交易"""
        tx_id = str(uuid.uuid4())
        transaction = {
            "id": tx_id,
            "type": tx_type,
            "from": from_user,
            "to": to_user,
            "amount": amount,
            "description": description,
            "timestamp": time.time()
        }
        if "transactions" not in self.transactions:
            self.transactions["transactions"] = []
        self.transactions["transactions"].append(transaction)
        self._save_json(self.transactions, self.transaction_file)
        return transaction
    
    # ===== 贡献度NFT =====
    
    def mint_contribution_nft(self, contributor: str, contribution_data: Dict) -> Dict:
        """
        铸造贡献度NFT
        """
        nft_id = str(uuid.uuid4())
        
        nft = {
            "id": nft_id,
            "contributor": contributor,
            "timestamp": time.time(),
            "data": contribution_data,
            "hash": hashlib.sha256(json.dumps(contribution_data).encode()).hexdigest()
        }
        
        self.nfts[nft_id] = nft
        self._save_json(self.nfts, self.nft_file)
        
        self._update_reputation(contributor, contribution_data)
        self._record_transaction("mint", "system", contributor, contribution_data.get("reward", {}), "铸造贡献NFT")
        
        return nft
    
    def get_nft(self, nft_id: str) -> Dict:
        return self.nfts.get(nft_id, {})
    
    def get_user_nfts(self, contributor: str) -> List[Dict]:
        return [nft for nft in self.nfts.values() if nft['contributor'] == contributor]
    
    def verify_nft(self, nft_id: str) -> bool:
        """验证NFT真实性"""
        nft = self.nfts.get(nft_id)
        if not nft:
            return False
        expected_hash = hashlib.sha256(json.dumps(nft['data']).encode()).hexdigest()
        return nft['hash'] == expected_hash
    
    # ===== 代码悬赏 =====
    
    def create_bounty(self, title: str, description: str, reward: Dict, target_commit: str = None, labels: List[str] = None) -> Dict:
        """
        创建代码悬赏
        """
        bounty_id = str(uuid.uuid4())
        
        bounty = {
            "id": bounty_id,
            "title": title,
            "description": description,
            "reward": reward,
            "labels": labels or [],
            "target_commit": target_commit or get_current_commit(),
            "creator": get_current_user(),
            "created_at": time.time(),
            "status": "open",
            "assignee": None,
            "solution_commit": None,
            "solution_sha": None,
            "completed_at": None
        }
        
        self.bounties[bounty_id] = bounty
        self._save_json(self.bounties, self.bounty_file)
        
        return bounty
    
    def claim_bounty(self, bounty_id: str, solution_commit: str) -> Dict:
        """
        认领并解决悬赏
        """
        bounty = self.bounties.get(bounty_id)
        if not bounty:
            raise ValueError("悬赏不存在")
        
        if bounty['status'] != 'open':
            raise ValueError("悬赏已被认领或已完成")
        
        bounty['status'] = 'completed'
        bounty['assignee'] = get_current_user()
        bounty['solution_commit'] = solution_commit
        bounty['completed_at'] = time.time()
        
        reward = bounty['reward']
        self._distribute_reward(bounty['assignee'], reward)
        self._record_transaction("bounty", bounty['creator'], bounty['assignee'], reward, f"悬赏完成: {bounty['title']}")
        
        self.mint_contribution_nft(bounty['assignee'], {
            "type": "bounty_completion",
            "bounty_id": bounty_id,
            "title": bounty['title'],
            "reward": reward
        })
        
        self._save_json(self.bounties, self.bounty_file)
        
        return bounty
    
    def cancel_bounty(self, bounty_id: str) -> Dict:
        """取消悬赏"""
        bounty = self.bounties.get(bounty_id)
        if not bounty:
            raise ValueError("悬赏不存在")
        
        if bounty['status'] != 'open':
            raise ValueError("只能取消未认领的悬赏")
        
        bounty['status'] = 'canceled'
        self._save_json(self.bounties, self.bounty_file)
        
        return bounty
    
    def list_bounties(self, status: str = "open", label: str = None) -> List[Dict]:
        """列出悬赏"""
        bounties = [b for b in self.bounties.values() if b['status'] == status]
        if label:
            bounties = [b for b in bounties if label in b.get('labels', [])]
        bounties.sort(key=lambda x: x.get('created_at', 0), reverse=True)
        return bounties
    
    # ===== 声誉系统 =====
    
    def _update_reputation(self, user: str, contribution: Dict):
        """更新用户声誉"""
        if user not in self.reputations:
            self.reputations[user] = {
                "score": 0,
                "level": "novice",
                "history": [],
                "last_updated": time.time(),
                "total_commits": 0,
                "total_reviews": 0,
                "total_bounties": 0
            }
        
        points = 0
        contrib_type = contribution.get('type', 'unknown')
        
        if contrib_type == 'commit':
            points = contribution.get('lines_added', 0) // 100 + 1
            self.reputations[user]['total_commits'] += 1
        elif contrib_type == 'code_review':
            points = 5
            self.reputations[user]['total_reviews'] += 1
        elif contrib_type == 'bounty_completion':
            points = 50
            self.reputations[user]['total_bounties'] += 1
        elif contrib_type == 'documentation':
            points = 10
        elif contrib_type == 'bug_fix':
            points = 20
        elif contrib_type == 'feature':
            points = 30
        
        self.reputations[user]['score'] += points
        self.reputations[user]['history'].append({
            "type": contrib_type,
            "points": points,
            "timestamp": time.time(),
            "details": contribution
        })
        
        score = self.reputations[user]['score']
        if score < 100:
            level = "novice"
        elif score < 500:
            level = "contributor"
        elif score < 2000:
            level = "expert"
        else:
            level = "master"
        
        self.reputations[user]['level'] = level
        self.reputations[user]['last_updated'] = time.time()
        
        self._save_json(self.reputations, self.reputation_file)
    
    def add_reputation(self, user: str, points: int, reason: str, contrib_type: str = "manual"):
        """手动添加声誉分"""
        self._update_reputation(user, {
            "type": contrib_type,
            "points": points,
            "reason": reason
        })
        return self.get_reputation(user)
    
    def get_reputation(self, user: str) -> Dict:
        return self.reputations.get(user, {
            "score": 0,
            "level": "novice",
            "history": [],
            "last_updated": time.time(),
            "total_commits": 0,
            "total_reviews": 0,
            "total_bounties": 0
        })
    
    def get_leaderboard(self, limit: int = 10, min_score: int = 0) -> List[Dict]:
        """获取声誉排行榜"""
        filtered = {u: d for u, d in self.reputations.items() if d['score'] >= min_score}
        sorted_users = sorted(
            filtered.items(),
            key=lambda x: x[1]['score'],
            reverse=True
        )
        return [{"user": u, "score": d['score'], "level": d['level']} 
                for u, d in sorted_users[:limit]]
    
    def _distribute_reward(self, user: str, reward: Dict):
        """发放奖励"""
        print(f"向 {user} 发放奖励: {reward}")
        # 可以对接实际的支付系统
        return True


# ==================== 5. 认知增强层 ====================

class CognitiveEnhancement:
    """
    认知增强层
    功能：注意力热图、认知负荷标签、代码考古工具
    """
    
    def __init__(self, repo_path: str):
        self.repo_path = Path(repo_path)
        self.wigit_dir = self.repo_path / ".wigit"
        self.cognitive_dir = self.wigit_dir / "cognitive"
        self.cognitive_dir.mkdir(parents=True, exist_ok=True)
        
        self.heatmap_file = self.cognitive_dir / "heatmap.json"
        self.heatmap_data = self._load_json(self.heatmap_file)
        
        self.complexity_file = self.cognitive_dir / "complexity.json"
        self.complexity_tags = self._load_json(self.complexity_file)
        
        self.archaeology_file = self.cognitive_dir / "archaeology.json"
        self.archaeology = self._load_json(self.archaeology_file)
        
        # AI集成（延迟初始化）
        self._ai = None
    
    def _get_ai(self):
        if self._ai is None:
            from .Plus import AIIntegration
            self._ai = AIIntegration(str(self.repo_path))
        return self._ai
    
    def _load_json(self, file_path: Path) -> Dict:
        if file_path.exists():
            with open(file_path, 'r', encoding='utf-8') as f:
                return json.load(f)
        return {}
    
    def _save_json(self, data: Dict, file_path: Path):
        # 转换set为list以便JSON序列化
        def convert_sets(obj):
            if isinstance(obj, set):
                return list(obj)
            elif isinstance(obj, dict):
                return {k: convert_sets(v) for k, v in obj.items()}
            elif isinstance(obj, list):
                return [convert_sets(i) for i in obj]
            return obj
        
        serializable_data = convert_sets(data)
        with open(file_path, 'w', encoding='utf-8') as f:
            json.dump(serializable_data, f, ensure_ascii=False, indent=2)
    
    # ===== 注意力热图 =====
    
    def record_view(self, file_path: str, line: int, duration: float):
        """
        记录开发者浏览代码的路径
        """
        if file_path not in self.heatmap_data:
            self.heatmap_data[file_path] = {}
        
        line_str = str(line)
        if line_str not in self.heatmap_data[file_path]:
            self.heatmap_data[file_path][line_str] = {
                "views": 0,
                "total_duration": 0,
                "last_viewed": 0,
                "viewers": set()
            }
        
        record = self.heatmap_data[file_path][line_str]
        record['views'] += 1
        record['total_duration'] += duration
        record['last_viewed'] = time.time()
        
        user = get_current_user()
        if isinstance(record['viewers'], set):
            record['viewers'].add(user)
        elif isinstance(record['viewers'], list):
            record['viewers'].append(user)
        
        self._save_json(self.heatmap_data, self.heatmap_file)
    
    def get_heatmap(self, file_path: str) -> Dict:
        return self.heatmap_data.get(file_path, {})
    
    def get_hot_lines(self, file_path: str, top_n: int = 10) -> List[Dict]:
        """获取最常查看的行"""
        file_data = self.heatmap_data.get(file_path, {})
        lines = []
        for line_str, data in file_data.items():
            lines.append({
                "line": int(line_str),
                "views": data.get('views', 0),
                "total_duration": data.get('total_duration', 0),
                "avg_duration": data.get('total_duration', 0) / max(data.get('views', 1), 1)
            })
        lines.sort(key=lambda x: x['views'], reverse=True)
        return lines[:top_n]
    
    def get_comprehension_cost(self, file_path: str) -> float:
        """
        计算理解成本指标（秒）
        """
        file_data = self.heatmap_data.get(file_path, {})
        if not file_data:
            return 0.0
        
        total_duration = 0
        total_views = 0
        for line_data in file_data.values():
            total_duration += line_data.get('total_duration', 0)
            total_views += line_data.get('views', 0)
        
        if total_views == 0:
            return 0.0
        
        # 平均浏览时间 / 1000 转换为秒
        avg_time_per_view = total_duration / total_views
        return round(avg_time_per_view / 1000, 2)
    
    # ===== 认知负荷标签 =====
    
    def analyze_complexity(self, commit_sha: str, file_path: str, content: str) -> Dict:
        """
        AI分析commit的复杂度
        """
        ai = self._get_ai()
        result = ai.analyze_code_complexity(content)
        
        tag = {
            "id": str(uuid.uuid4()),
            "commit": commit_sha,
            "file": file_path,
            "complexity_score": result.get('complexity_score', 0),
            "cognitive_load": result.get('cognitive_load', '未知'),
            "needs_context": result.get('complexity_score', 0) > 70,
            "needs_context_reason": result.get('suggestions', []),
            "readability": result.get('readability', '良'),
            "timestamp": time.time()
        }
        
        key = f"{commit_sha}:{file_path}"
        if key not in self.complexity_tags:
            self.complexity_tags[key] = []
        
        self.complexity_tags[key].append(tag)
        self._save_json(self.complexity_tags, self.complexity_file)
        
        return tag
    
    def get_complexity_tags(self, commit_sha: str = None, file_path: str = None) -> List[Dict]:
        """获取复杂度标签"""
        tags = []
        for key, tag_list in self.complexity_tags.items():
            for tag in tag_list:
                if commit_sha and tag.get('commit') != commit_sha:
                    continue
                if file_path and tag.get('file') != file_path:
                    continue
                tags.append(tag)
        tags.sort(key=lambda x: x.get('timestamp', 0), reverse=True)
        return tags
    
    def get_high_complexity_commits(self, threshold: int = 70) -> List[Dict]:
        """获取高复杂度的commits"""
        high_complexity = []
        for key, tag_list in self.complexity_tags.items():
            for tag in tag_list:
                if tag.get('complexity_score', 0) >= threshold:
                    high_complexity.append(tag)
        high_complexity.sort(key=lambda x: x.get('complexity_score', 0), reverse=True)
        return high_complexity
    
    # ===== 代码考古工具 =====
    
    def archeology(self, file_path: str, line: int, depth: int = 50) -> Dict:
        """
        代码考古工具 - 自动生成"为什么这样写"的叙事
        """
        archaeology_data = {
            "file": file_path,
            "line": line,
            "history": [],
            "related_issues": [],
            "related_discussions": [],
            "narrative": "",
            "authors": set(),
            "first_seen": None,
            "last_modified": None,
            "modification_count": 0
        }
        
        try:
            from wigit import get_repository
            repo = get_repository()
            
            head = get_current_commit()
            if head:
                # 获取commit历史
                try:
                    commits = repo.history.get_commit_history(head, depth)
                    
                    # 简单模拟历史记录
                    author_counts = {}
                    for i, commit in enumerate(commits):
                        commit_info = {
                            "commit": commit.get('hash', '') if isinstance(commit, dict) else str(commit),
                            "message": commit.get('message', '') if isinstance(commit, dict) else '',
                            "author": commit.get('author_name', '') if isinstance(commit, dict) else 'unknown',
                            "timestamp": commit.get('timestamp', time.time()) if isinstance(commit, dict) else time.time()
                        }
                        archaeology_data['history'].append(commit_info)
                        
                        author = commit_info['author']
                        author_counts[author] = author_counts.get(author, 0) + 1
                        
                        if archaeology_data['first_seen'] is None or commit_info['timestamp'] < archaeology_data['first_seen']:
                            archaeology_data['first_seen'] = commit_info['timestamp']
                        if archaeology_data['last_modified'] is None or commit_info['timestamp'] > archaeology_data['last_modified']:
                            archaeology_data['last_modified'] = commit_info['timestamp']
                    
                    archaeology_data['modification_count'] = len(commits)
                    archaeology_data['authors'] = list(author_counts.keys())
                    archaeology_data['top_author'] = max(author_counts.items(), key=lambda x: x[1])[0] if author_counts else None
                    
                except Exception as e:
                    archaeology_data['history'] = [{"error": str(e)}]
            
            archaeology_data['narrative'] = self._generate_narrative(archaeology_data, line)
            
        except Exception as e:
            archaeology_data['narrative'] = f"无法生成考古叙事: {e}"
            archaeology_data['error'] = str(e)
        
        key = f"{file_path}:{line}"
        self.archaeology[key] = archaeology_data
        
        # 转换set为list保存
        save_data = archaeology_data.copy()
        if 'authors' in save_data and isinstance(save_data['authors'], set):
            save_data['authors'] = list(save_data['authors'])
        self._save_json(self.archaeology, self.archaeology_file)
        
        return archaeology_data
    
    def _generate_narrative(self, data: Dict, line: int) -> str:
        """
        生成"为什么这样写"的叙事
        """
        history = data.get('history', [])
        if not history:
            return "没有找到相关历史记录"
        
        narrative = f"## 代码考古报告 - 第{line}行\n\n"
        narrative += f"### 统计信息\n\n"
        narrative += f"- 修改次数: {data.get('modification_count', 0)}\n"
        narrative += f"- 涉及作者: {', '.join(data.get('authors', []))}\n"
        narrative += f"- 主要维护者: {data.get('top_author', '未知')}\n"
        
        if data.get('first_seen'):
            narrative += f"- 首次出现: {datetime.fromtimestamp(data['first_seen']).strftime('%Y-%m-%d')}\n"
        if data.get('last_modified'):
            narrative += f"- 最近修改: {datetime.fromtimestamp(data['last_modified']).strftime('%Y-%m-%d')}\n"
        
        narrative += "\n### 修改历史\n\n"
        for i, commit in enumerate(history[:20], 1):
            timestamp = commit.get('timestamp', 0)
            date_str = datetime.fromtimestamp(timestamp).strftime('%Y-%m-%d') if timestamp else '未知日期'
            narrative += f"{i}. **{commit.get('commit', '')[:8]}** - {date_str}\n"
            narrative += f"   作者: {commit.get('author', '未知')}\n"
            narrative += f"   说明: {commit.get('message', '无说明')[:100]}\n\n"
        
        if len(history) > 20:
            narrative += f"\n... 还有 {len(history) - 20} 条历史记录\n"
        
        return narrative
    
    def get_archaeology(self, file_path: str, line: int = None) -> Union[Dict, List[Dict]]:
        """获取考古记录"""
        if line is not None:
            key = f"{file_path}:{line}"
            return self.archaeology.get(key, {})
        else:
            # 返回该文件的所有考古记录
            return {k: v for k, v in self.archaeology.items() if k.startswith(f"{file_path}:")}


# ==================== 6. 统一导出 ====================

class WiGitPlus:
    """
    WiGit增强层统一入口
    提供五大增强功能
    """
    
    def __init__(self, repo_path: str = "."):
        self.repo_path = repo_path
        self.realtime = RealTimeCollaboration(repo_path)
        self.ai = AIIntegration(repo_path)
        self.multimodal = MultimodalVersionControl(repo_path)
        self.economy = EconomyLayer(repo_path)
        self.cognitive = CognitiveEnhancement(repo_path)
    
    # 实时协作
    def record_operation(self, op_type: str, file_path: str, data: Dict):
        return self.realtime.record_operation(op_type, file_path, data)
    
    def replay_operations(self, start_time: float = None, end_time: float = None, speed: float = 1.0):
        return self.realtime.replay_operations(start_time, end_time, speed)
    
    def update_cursor(self, file_path: str, line: int, column: int):
        return self.realtime.update_cursor(file_path, line, column)
    
    def add_ghost_annotation(self, file_path: str, line: int, text: str, author: str = None, context: str = ""):
        return self.realtime.add_ghost_annotation(file_path, line, text, author, context)
    
    def get_ghost_annotations(self, file_path: str, line: int = None):
        return self.realtime.get_ghost_annotations(file_path, line)
    
    def create_snapshot(self, commit_sha: str):
        return self.realtime.create_time_travel_snapshot(commit_sha)
    
    # AI集成
    def semantic_commit(self, diff_content: str):
        return self.ai.semantic_commit(diff_content)
    
    def smart_merge(self, base_content: str, ours_content: str, theirs_content: str, file_path: str):
        return self.ai.smart_merge(base_content, ours_content, theirs_content, file_path)
    
    def query_knowledge_graph(self, query: str):
        return self.ai.query_knowledge_graph(query)
    
    def explain_code(self, code_content: str):
        return self.ai.explain_code(code_content)
    
    def review_code(self, code_content: str, file_path: str = ""):
        return self.ai.review_code(code_content, file_path)
    
    # 多模态版本控制
    def version_design(self, design_path: str, metadata: Dict = None):
        return self.multimodal.version_design(design_path, metadata)
    
    def version_api(self, api_spec: Dict, spec_type: str = "openapi"):
        return self.multimodal.version_api(api_spec, spec_type)
    
    def version_schema(self, schema_sql: str, database: str):
        return self.multimodal.version_schema(schema_sql, database)
    
    def diff_schema(self, version1: str, version2: str):
        return self.multimodal.diff_schema(version1, version2)
    
    def diff_design(self, version1: str, version2: str):
        return self.multimodal.diff_design(version1, version2)
    
    # 经济激励
    def mint_nft(self, contributor: str, contribution_data: Dict):
        return self.economy.mint_contribution_nft(contributor, contribution_data)
    
    def create_bounty(self, title: str, description: str, reward: Dict, target_commit: str = None, labels: List[str] = None):
        return self.economy.create_bounty(title, description, reward, target_commit, labels)
    
    def claim_bounty(self, bounty_id: str, solution_commit: str):
        return self.economy.claim_bounty(bounty_id, solution_commit)
    
    def list_bounties(self, status: str = "open"):
        return self.economy.list_bounties(status)
    
    def get_leaderboard(self, limit: int = 10):
        return self.economy.get_leaderboard(limit)
    
    def get_reputation(self, user: str):
        return self.economy.get_reputation(user)
    
    # 认知增强
    def record_view(self, file_path: str, line: int, duration: float):
        return self.cognitive.record_view(file_path, line, duration)
    
    def get_comprehension_cost(self, file_path: str):
        return self.cognitive.get_comprehension_cost(file_path)
    
    def get_hot_lines(self, file_path: str, top_n: int = 10):
        return self.cognitive.get_hot_lines(file_path, top_n)
    
    def archeology(self, file_path: str, line: int):
        return self.cognitive.archeology(file_path, line)
    
    def analyze_complexity(self, commit_sha: str, file_path: str, content: str):
        return self.cognitive.analyze_complexity(commit_sha, file_path, content)
    
    def get_complexity_tags(self, commit_sha: str = None, file_path: str = None):
        return self.cognitive.get_complexity_tags(commit_sha, file_path)
    
    def close(self):
        """清理资源"""
        if hasattr(self.ai, 'close'):
            self.ai.close()
        if hasattr(self.realtime, 'disconnect_websocket'):
            self.realtime.disconnect_websocket()


# 导出
__all__ = [
    'RealTimeCollaboration',
    'AIIntegration',
    'MultimodalVersionControl',
    'EconomyLayer',
    'CognitiveEnhancement',
    'WiGitPlus'
]
