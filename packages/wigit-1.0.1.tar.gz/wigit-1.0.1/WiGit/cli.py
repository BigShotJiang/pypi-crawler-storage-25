# -*- coding: utf-8 -*-
"""
WiGit CLI - 命令行接口
提供与Git类似的命令行体验，支持所有增强功能
"""

import argparse
import sys
import os
from pathlib import Path
from datetime import datetime
from typing import List, Optional, Dict, Any

# 尝试导入colorama用于彩色输出
try:
    from colorama import init, Fore, Style
    init()
    HAS_COLOR = True
except ImportError:
    HAS_COLOR = False
    # 定义简单的颜色常量
    class Fore:
        RED = ''
        GREEN = ''
        YELLOW = ''
        BLUE = ''
        CYAN = ''
        MAGENTA = ''
        WHITE = ''
        RESET = ''
    class Style:
        BRIGHT = ''
        DIM = ''
        RESET_ALL = ''


class WiGitCLI:
    """
    WiGit命令行接口
    """
    
    def __init__(self):
        self.parser = self._create_parser()
        self.wigit = None
    
    def _create_parser(self) -> argparse.ArgumentParser:
        """创建命令行解析器"""
        parser = argparse.ArgumentParser(
            prog="wigit",
            description="WiGit - 下一代版本控制系统",
            epilog="使用 'wigit <command> -h' 查看特定命令的帮助"
        )
        
        parser.add_argument(
            "--version", "-v",
            action="version",
            version=f"WiGit v1.0.0"
        )
        
        parser.add_argument(
            "--repo", "-C",
            dest="repo_path",
            default=".",
            help="指定仓库路径"
        )
        
        subparsers = parser.add_subparsers(dest="command", help="可用命令")
        
        # ===== 基础命令 =====
        
        # init
        init_parser = subparsers.add_parser("init", help="初始化新仓库")
        init_parser.add_argument("path", nargs="?", default=".", help="仓库路径")
        init_parser.add_argument("--bare", action="store_true", help="创建裸仓库")
        
        # add
        add_parser = subparsers.add_parser("add", help="添加文件到暂存区")
        add_parser.add_argument("files", nargs="+", help="要添加的文件")
        add_parser.add_argument("--all", "-A", action="store_true", help="添加所有更改")
        
        # commit
        commit_parser = subparsers.add_parser("commit", help="提交更改")
        commit_parser.add_argument("-m", "--message", help="提交信息")
        commit_parser.add_argument("--author", help="作者")
        commit_parser.add_argument("--semantic", "-s", action="store_true", help="使用AI生成语义化提交信息")
        commit_parser.add_argument("--amend", action="store_true", help="修改上一次提交")
        
        # status
        subparsers.add_parser("status", help="查看工作区状态")
        
        # log
        log_parser = subparsers.add_parser("log", help="查看提交历史")
        log_parser.add_argument("-n", "--limit", type=int, default=10, help="显示数量")
        log_parser.add_argument("--oneline", action="store_true", help="单行显示")
        log_parser.add_argument("--graph", action="store_true", help="显示分支图")
        
        # diff
        diff_parser = subparsers.add_parser("diff", help="查看差异")
        diff_parser.add_argument("commit1", nargs="?", help="第一个提交")
        diff_parser.add_argument("commit2", nargs="?", help="第二个提交")
        diff_parser.add_argument("--cached", action="store_true", help="查看暂存区差异")
        
        # branch
        branch_parser = subparsers.add_parser("branch", help="分支管理")
        branch_parser.add_argument("name", nargs="?", help="分支名称")
        branch_parser.add_argument("-d", "--delete", action="store_true", help="删除分支")
        branch_parser.add_argument("-D", "--force-delete", action="store_true", help="强制删除分支")
        branch_parser.add_argument("-m", "--move", nargs=2, metavar=('OLD', 'NEW'), help="重命名分支")
        branch_parser.add_argument("-a", "--all", action="store_true", help="列出所有分支")
        
        # checkout
        checkout_parser = subparsers.add_parser("checkout", help="切换分支或恢复文件")
        checkout_parser.add_argument("target", help="分支名或提交hash")
        checkout_parser.add_argument("-b", "--create", action="store_true", help="创建并切换新分支")
        
        # merge
        merge_parser = subparsers.add_parser("merge", help="合并分支")
        merge_parser.add_argument("branch", help="要合并的分支")
        merge_parser.add_argument("--strategy", choices=["auto", "ours", "theirs", "ai"], default="auto", help="合并策略")
        merge_parser.add_argument("--no-ff", action="store_true", help="禁用快进合并")
        
        # push
        push_parser = subparsers.add_parser("push", help="推送到远程")
        push_parser.add_argument("remote", nargs="?", default="origin", help="远程仓库名")
        push_parser.add_argument("branch", nargs="?", help="分支名")
        push_parser.add_argument("-u", "--set-upstream", action="store_true", help="设置上游")
        
        # pull
        pull_parser = subparsers.add_parser("pull", help="从远程拉取")
        pull_parser.add_argument("remote", nargs="?", default="origin", help="远程仓库名")
        pull_parser.add_argument("branch", nargs="?", help="分支名")
        pull_parser.add_argument("--rebase", action="store_true", help="使用rebase方式")
        
        # clone
        clone_parser = subparsers.add_parser("clone", help="克隆仓库")
        clone_parser.add_argument("url", help="仓库URL")
        clone_parser.add_argument("directory", nargs="?", help="目标目录")
        
        # remote
        remote_parser = subparsers.add_parser("remote", help="远程仓库管理")
        remote_parser.add_argument("action", choices=["add", "remove", "list"], help="操作")
        remote_parser.add_argument("name", nargs="?", help="远程仓库名")
        remote_parser.add_argument("url", nargs="?", help="远程仓库URL")
        
        # tag
        tag_parser = subparsers.add_parser("tag", help="标签管理")
        tag_parser.add_argument("name", nargs="?", help="标签名称")
        tag_parser.add_argument("-a", "--annotate", action="store_true", help="创建附注标签")
        tag_parser.add_argument("-m", "--message", help="标签信息")
        tag_parser.add_argument("-d", "--delete", help="删除标签")
        
        # reset
        reset_parser = subparsers.add_parser("reset", help="重置到指定提交")
        reset_parser.add_argument("commit", help="目标提交")
        reset_parser.add_argument("--hard", action="store_true", help="硬重置")
        reset_parser.add_argument("--soft", action="store_true", help="软重置")
        
        # revert
        revert_parser = subparsers.add_parser("revert", help="撤销提交")
        revert_parser.add_argument("commit", help="要撤销的提交")
        
        # ===== 增强功能命令 =====
        
        # semantic-commit (AI生成提交信息)
        semantic_parser = subparsers.add_parser("semantic", help="AI生成语义化提交信息")
        semantic_parser.add_argument("--diff", help="差异内容或文件路径")
        
        # smart-merge (AI智能合并)
        smart_merge_parser = subparsers.add_parser("smart-merge", help="AI智能合并")
        smart_merge_parser.add_argument("branch", help="要合并的分支")
        smart_merge_parser.add_argument("--file", help="指定文件")
        
        # knowledge (知识图谱)
        knowledge_parser = subparsers.add_parser("knowledge", help="知识图谱查询")
        knowledge_parser.add_argument("query", help="查询内容")
        knowledge_parser.add_argument("--build", action="store_true", help="构建知识图谱")
        
        # bounty (悬赏)
        bounty_parser = subparsers.add_parser("bounty", help="悬赏管理")
        bounty_subparsers = bounty_parser.add_subparsers(dest="bounty_action")
        
        bounty_create = bounty_subparsers.add_parser("create", help="创建悬赏")
        bounty_create.add_argument("title", help="标题")
        bounty_create.add_argument("description", help="描述")
        bounty_create.add_argument("--reward", "-r", required=True, help="奖励格式: type:amount:currency (如 money:100:CNY)")
        bounty_create.add_argument("--labels", "-l", nargs="+", help="标签")
        
        bounty_list = bounty_subparsers.add_parser("list", help="列出悬赏")
        bounty_list.add_argument("--status", default="open", choices=["open", "in_progress", "completed", "all"], help="状态过滤")
        
        bounty_claim = bounty_subparsers.add_parser("claim", help="认领悬赏")
        bounty_claim.add_argument("bounty_id", help="悬赏ID")
        bounty_claim.add_argument("--commit", help="解决方案的commit")
        
        bounty_cancel = bounty_subparsers.add_parser("cancel", help="取消悬赏")
        bounty_cancel.add_argument("bounty_id", help="悬赏ID")
        
        # nft (NFT管理)
        nft_parser = subparsers.add_parser("nft", help="NFT管理")
        nft_subparsers = nft_parser.add_subparsers(dest="nft_action")
        
        nft_mint = nft_subparsers.add_parser("mint", help="铸造贡献NFT")
        nft_mint.add_argument("--type", default="commit", choices=["commit", "review", "bounty", "documentation"], help="贡献类型")
        nft_mint.add_argument("--description", help="描述")
        
        nft_list = nft_subparsers.add_parser("list", help="列出NFT")
        nft_list.add_argument("--user", help="用户名")
        
        nft_verify = nft_subparsers.add_parser("verify", help="验证NFT")
        nft_verify.add_argument("nft_id", help="NFT ID")
        
        # leaderboard (排行榜)
        leaderboard_parser = subparsers.add_parser("leaderboard", help="贡献排行榜")
        leaderboard_parser.add_argument("-n", "--limit", type=int, default=10, help="显示数量")
        leaderboard_parser.add_argument("--min-score", type=int, default=0, help="最低分数")
        
        # reputation (声誉)
        rep_parser = subparsers.add_parser("reputation", help="查看声誉")
        rep_parser.add_argument("user", nargs="?", help="用户名")
        
        # heatmap (热图)
        heatmap_parser = subparsers.add_parser("heatmap", help="代码注意力热图")
        heatmap_parser.add_argument("file", help="文件路径")
        heatmap_parser.add_argument("--top", "-n", type=int, default=10, help="显示最热的行数")
        
        # complexity (复杂度分析)
        complexity_parser = subparsers.add_parser("complexity", help="代码复杂度分析")
        complexity_parser.add_argument("file", help="文件路径")
        complexity_parser.add_argument("--commit", help="指定commit")
        
        # archeology (代码考古)
        archeology_parser = subparsers.add_parser("archeology", help="代码考古")
        archeology_parser.add_argument("file", help="文件路径")
        archeology_parser.add_argument("line", type=int, help="行号")
        
        # design (设计稿版本化)
        design_parser = subparsers.add_parser("design", help="设计稿版本控制")
        design_subparsers = design_parser.add_subparsers(dest="design_action")
        
        design_version = design_subparsers.add_parser("version", help="版本化设计稿")
        design_version.add_argument("file", help="设计文件路径")
        design_version.add_argument("--metadata", help="元数据JSON")
        
        design_diff = design_subparsers.add_parser("diff", help="比较设计稿版本")
        design_diff.add_argument("version1", help="版本1")
        design_diff.add_argument("version2", help="版本2")
        
        design_list = design_subparsers.add_parser("list", help="列出设计稿版本")
        
        # api (API契约版本化)
        api_parser = subparsers.add_parser("api", help="API契约版本控制")
        api_subparsers = api_parser.add_subparsers(dest="api_action")
        
        api_version = api_subparsers.add_parser("version", help="版本化API契约")
        api_version.add_argument("file", help="API规范文件")
        api_version.add_argument("--type", default="openapi", choices=["openapi", "protobuf"], help="规范类型")
        
        api_diff = api_subparsers.add_parser("diff", help="比较API版本")
        api_diff.add_argument("version1", help="版本1")
        api_diff.add_argument("version2", help="版本2")
        
        # schema (数据库Schema版本化)
        schema_parser = subparsers.add_parser("schema", help="数据库Schema版本控制")
        schema_subparsers = schema_parser.add_subparsers(dest="schema_action")
        
        schema_version = schema_subparsers.add_parser("version", help="版本化Schema")
        schema_version.add_argument("file", help="SQL文件路径")
        schema_version.add_argument("--database", default="default", help="数据库名称")
        
        schema_diff = schema_subparsers.add_parser("diff", help="比较Schema版本")
        schema_diff.add_argument("version1", help="版本1")
        schema_diff.add_argument("version2", help="版本2")
        
        # ghost (代码幽灵注释)
        ghost_parser = subparsers.add_parser("ghost", help="代码幽灵注释")
        ghost_subparsers = ghost_parser.add_subparsers(dest="ghost_action")
        
        ghost_add = ghost_subparsers.add_parser("add", help="添加注释")
        ghost_add.add_argument("file", help="文件路径")
        ghost_add.add_argument("line", type=int, help="行号")
        ghost_add.add_argument("text", help="注释内容")
        ghost_add.add_argument("--context", help="上下文说明")
        
        ghost_list = ghost_subparsers.add_parser("list", help="列出注释")
        ghost_list.add_argument("file", help="文件路径")
        
        # cursor (光标同步)
        cursor_parser = subparsers.add_parser("cursor", help="光标同步")
        cursor_parser.add_argument("file", help="文件路径")
        cursor_parser.add_argument("line", type=int, help="行号")
        cursor_parser.add_argument("column", type=int, help="列号")
        
        # explain (代码解释)
        explain_parser = subparsers.add_parser("explain", help="AI解释代码")
        explain_parser.add_argument("file", help="文件路径")
        explain_parser.add_argument("--lines", help="行范围，如 10-20")
        
        # review (代码审查)
        review_parser = subparsers.add_parser("review", help="AI代码审查")
        review_parser.add_argument("file", help="文件路径")
        review_parser.add_argument("--commit", help="指定commit")
        
        return parser
    
    def _print_color(self, text: str, color: str = None, style: str = None):
        """彩色输出"""
        if HAS_COLOR:
            if style:
                print(f"{getattr(Style, style, '')}{getattr(Fore, color.upper(), '') if color else ''}{text}{Style.RESET_ALL}")
            else:
                print(f"{getattr(Fore, color.upper(), '') if color else ''}{text}{Style.RESET_ALL}")
        else:
            print(text)
    
    def _print_error(self, text: str):
        """打印错误信息"""
        self._print_color(f"错误: {text}", "red")
    
    def _print_success(self, text: str):
        """打印成功信息"""
        self._print_color(f"✓ {text}", "green")
    
    def _print_info(self, text: str):
        """打印信息"""
        self._print_color(text, "cyan")
    
    def _print_warning(self, text: str):
        """打印警告"""
        self._print_color(f"警告: {text}", "yellow")
    
    def _init_wigit(self, repo_path: str):
        """初始化WiGit实例"""
        try:
            from . import WiGit, get_repository
            self.wigit = WiGit(repo_path)
            return True
        except Exception as e:
            self._print_error(f"无法初始化仓库: {e}")
            return False
    
    def run(self, args: List[str] = None):
        """运行命令行"""
        if args is None:
            args = sys.argv[1:]
        
        parsed_args = self.parser.parse_args(args)
        
        if not parsed_args.command:
            self.parser.print_help()
            return
        
        # 对于init和clone命令，不需要先有仓库
        if parsed_args.command in ["init", "clone"]:
            getattr(self, f"_cmd_{parsed_args.command.replace('-', '_')}")(parsed_args)
            return
        
        # 其他命令需要先初始化仓库
        if not self._init_wigit(parsed_args.repo_path):
            return
        
        # 执行命令
        cmd_method = getattr(self, f"_cmd_{parsed_args.command.replace('-', '_')}", None)
        if cmd_method:
            cmd_method(parsed_args)
        else:
            self._print_error(f"未知命令: {parsed_args.command}")
    
    # ===== 基础命令实现 =====
    
    def _cmd_init(self, args):
        """初始化仓库"""
        try:
            from . import init_repository
            path = args.path
            repo = init_repository(path, args.bare)
            self._print_success(f"已初始化空仓库: {Path(path).absolute()}")
        except Exception as e:
            self._print_error(f"初始化失败: {e}")
    
    def _cmd_add(self, args):
        """添加文件"""
        try:
            result = self.wigit.add(args.files)
            self._print_success(f"已添加 {len(result.get('added', []))} 个文件")
        except Exception as e:
            self._print_error(f"添加失败: {e}")
    
    def _cmd_commit(self, args):
        """提交更改"""
        try:
            if args.semantic or not args.message:
                self._print_info("正在使用AI生成提交信息...")
                result = self.wigit.semantic_commit()
                if result and result.get('message'):
                    args.message = result['message']
                    self._print_info(f"AI生成的信息: {args.message}")
            
            if not args.message:
                self._print_error("请提供提交信息 (-m) 或使用 --semantic")
                return
            
            result = self.wigit.commit(args.message, args.author)
            self._print_success(f"已提交: {result.get('hash', '')[:8]}")
        except Exception as e:
            self._print_error(f"提交失败: {e}")
    
    def _cmd_status(self, args):
        """查看状态"""
        try:
            status = self.wigit.status()
            
            # 显示分支信息
            branch = status.get('branch', 'detached')
            self._print_info(f"位于分支 {branch}")
            
            # 显示待提交的更改
            staged = status.get('staged', [])
            if staged:
                self._print_color("\n要提交的变更:", "green")
                for f in staged:
                    print(f"  {f}")
            
            # 显示未暂存的更改
            unstaged = status.get('unstaged', [])
            if unstaged:
                self._print_color("\n未暂存的变更:", "red")
                for f in unstaged:
                    print(f"  {f}")
            
            # 显示未跟踪的文件
            untracked = status.get('untracked', [])
            if untracked:
                self._print_color("\n未跟踪的文件:", "yellow")
                for f in untracked:
                    print(f"  {f}")
            
            if not staged and not unstaged and not untracked:
                self._print_info("工作区干净，无待提交更改")
        except Exception as e:
            self._print_error(f"获取状态失败: {e}")
    
    def _cmd_log(self, args):
        """查看日志"""
        try:
            commits = self.wigit.log(args.limit)
            
            for i, commit in enumerate(commits):
                hash_str = commit.get('hash', '')[:8]
                author = commit.get('author', 'unknown')
                timestamp = commit.get('timestamp', 0)
                date = datetime.fromtimestamp(timestamp).strftime('%Y-%m-%d %H:%M') if timestamp else 'unknown'
                message = commit.get('message', '')
                
                if args.oneline:
                    self._print_color(f"{hash_str} - {message[:50]}", "cyan")
                else:
                    print(f"\n{Fore.CYAN if HAS_COLOR else ''}commit {hash_str}{Style.RESET_ALL if HAS_COLOR else ''}")
                    print(f"Author: {author}")
                    print(f"Date:   {date}")
                    print(f"\n    {message}\n")
        except Exception as e:
            self._print_error(f"获取日志失败: {e}")
    
    def _cmd_diff(self, args):
        """查看差异"""
        try:
            diff = self.wigit.diff(args.commit1, args.commit2)
            if diff:
                print(diff)
            else:
                self._print_info("无差异")
        except Exception as e:
            self._print_error(f"获取差异失败: {e}")
    
    def _cmd_branch(self, args):
        """分支管理"""
        try:
            if args.delete:
                # 删除分支
                result = self.wigit.repository.delete_branch(args.name)
                self._print_success(f"已删除分支 {args.name}")
            elif args.move:
                # 重命名分支
                result = self.wigit.repository.rename_branch(args.move[0], args.move[1])
                self._print_success(f"分支已重命名: {args.move[0]} -> {args.move[1]}")
            elif args.name:
                # 创建分支
                result = self.wigit.branch(args.name)
                self._print_success(f"已创建分支 {args.name}")
            else:
                # 列出分支
                branches = self.wigit.repository.refs.list_branches()
                current = self.wigit.repository.refs.get_current_branch()
                for branch in branches:
                    if branch == current:
                        self._print_color(f"* {branch}", "green")
                    else:
                        print(f"  {branch}")
        except Exception as e:
            self._print_error(f"分支操作失败: {e}")
    
    def _cmd_checkout(self, args):
        """切换分支"""
        try:
            if args.create:
                result = self.wigit.repository.create_branch(args.target, checkout=True)
                self._print_success(f"已创建并切换到分支 {args.target}")
            else:
                result = self.wigit.repository.checkout(args.target)
                self._print_success(f"已切换到 {args.target}")
        except Exception as e:
            self._print_error(f"切换失败: {e}")
    
    def _cmd_merge(self, args):
        """合并分支"""
        try:
            self._print_info(f"正在合并分支 {args.branch} (策略: {args.strategy})...")
            result = self.wigit.merge(args.branch, args.strategy)
            
            if result.get('has_conflict'):
                self._print_warning("合并存在冲突")
                if 'smart_merge_result' in result:
                    for file, merge_result in result['smart_merge_result'].items():
                        if merge_result.get('has_conflict'):
                            self._print_warning(f"  {file}: 需要手动解决冲突")
                        else:
                            self._print_success(f"  {file}: AI自动解决")
            else:
                self._print_success("合并成功")
        except Exception as e:
            self._print_error(f"合并失败: {e}")
    
    def _cmd_push(self, args):
        """推送"""
        try:
            result = self.wigit.push(args.remote, args.branch)
            self._print_success(f"已推送到 {args.remote}")
        except Exception as e:
            self._print_error(f"推送失败: {e}")
    
    def _cmd_pull(self, args):
        """拉取"""
        try:
            result = self.wigit.pull(args.remote, args.branch)
            self._print_success(f"已从 {args.remote} 拉取")
        except Exception as e:
            self._print_error(f"拉取失败: {e}")
    
    def _cmd_clone(self, args):
        """克隆仓库"""
        try:
            from . import WiGit
            target_dir = args.directory or Path(args.url).stem
            self._print_info(f"正在克隆 {args.url} 到 {target_dir}...")
            # 这里需要实现clone逻辑
            self._print_success(f"克隆完成")
        except Exception as e:
            self._print_error(f"克隆失败: {e}")
    
    def _cmd_remote(self, args):
        """远程仓库管理"""
        try:
            if args.action == "list":
                remotes = self.wigit.repository.remotes.list()
                for name, url in remotes.items():
                    print(f"{name}\t{url}")
            elif args.action == "add" and args.name and args.url:
                self.wigit.repository.remotes.add(args.name, args.url)
                self._print_success(f"已添加远程仓库 {args.name}")
            elif args.action == "remove" and args.name:
                self.wigit.repository.remotes.remove(args.name)
                self._print_success(f"已删除远程仓库 {args.name}")
        except Exception as e:
            self._print_error(f"远程操作失败: {e}")
    
    def _cmd_tag(self, args):
        """标签管理"""
        try:
            if args.delete:
                self.wigit.repository.tags.delete(args.delete)
                self._print_success(f"已删除标签 {args.delete}")
            elif args.name:
                if args.annotate:
                    self.wigit.repository.tags.create_annotated(args.name, args.message or "")
                    self._print_success(f"已创建附注标签 {args.name}")
                else:
                    self.wigit.repository.tags.create(args.name)
                    self._print_success(f"已创建标签 {args.name}")
            else:
                tags = self.wigit.repository.tags.list()
                for tag in tags:
                    print(tag)
        except Exception as e:
            self._print_error(f"标签操作失败: {e}")
    
    def _cmd_reset(self, args):
        """重置"""
        try:
            mode = "hard" if args.hard else ("soft" if args.soft else "mixed")
            self.wigit.repository.reset(args.commit, mode)
            self._print_success(f"已重置到 {args.commit}")
        except Exception as e:
            self._print_error(f"重置失败: {e}")
    
    def _cmd_revert(self, args):
        """撤销提交"""
        try:
            self.wigit.repository.revert(args.commit)
            self._print_success(f"已撤销提交 {args.commit}")
        except Exception as e:
            self._print_error(f"撤销失败: {e}")
    
    # ===== 增强功能命令实现 =====
    
    def _cmd_semantic(self, args):
        """AI生成语义化提交信息"""
        try:
            if args.diff:
                with open(args.diff, 'r', encoding='utf-8') as f:
                    diff = f.read()
            else:
                diff = self.wigit.repository.get_diff()
            
            if not diff:
                self._print_warning("无代码变更")
                return
            
            self._print_info("正在分析代码变更...")
            result = self.wigit.semantic_commit(diff)
            
            print(f"\n{Fore.GREEN if HAS_COLOR else ''}建议的提交信息:{Style.RESET_ALL if HAS_COLOR else ''}")
            print(f"  {result.get('message', '')}\n")
            print(f"影响分析: {result.get('impact_analysis', '')}\n")
            print("测试建议:")
            for suggestion in result.get('test_suggestions', []):
                print(f"  - {suggestion}")
        except Exception as e:
            self._print_error(f"生成失败: {e}")
    
    def _cmd_smart_merge(self, args):
        """AI智能合并"""
        try:
            self._print_info(f"正在使用AI智能合并分支 {args.branch}...")
            result = self.wigit.merge(args.branch, "ai")
            
            if result.get('has_conflict'):
                self._print_warning("部分文件需要手动解决冲突")
            else:
                self._print_success("AI已自动解决所有冲突")
            
            if 'smart_merge_result' in result:
                for file, merge_result in result['smart_merge_result'].items():
                    if merge_result.get('has_conflict'):
                        self._print_warning(f"\n{file}: 需要手动处理")
                    else:
                        self._print_success(f"\n{file}: 合并成功")
                        for resolution in merge_result.get('resolutions', []):
                            print(f"  行 {resolution.get('line')}: {resolution.get('decision')}")
                            print(f"    原因: {resolution.get('reason')}")
        except Exception as e:
            self._print_error(f"智能合并失败: {e}")
    
    def _cmd_knowledge(self, args):
        """知识图谱查询"""
        try:
            if args.build:
                self._print_info("正在构建知识图谱...")
                # 收集commits, issues等
                commits = self.wigit.log(100)
                result = self.wigit.ai.build_knowledge_graph(commits, [], [])
                self._print_success(f"已构建知识图谱，添加 {result.get('entities_added', 0)} 个实体")
            else:
                results = self.wigit.query_knowledge_graph(args.query)
                if results:
                    self._print_info(f"找到 {len(results)} 个相关结果:")
                    for r in results:
                        print(f"  [{r['type']}] {r['name']}")
                else:
                    self._print_warning("未找到相关结果")
        except Exception as e:
            self._print_error(f"知识图谱操作失败: {e}")
    
    def _cmd_bounty(self, args):
        """悬赏管理"""
        try:
            if args.bounty_action == "create":
                # 解析奖励
                parts = args.reward.split(':')
                reward = {"type": parts[0], "amount": float(parts[1]), "currency": parts[2] if len(parts) > 2 else "CNY"}
                
                bounty = self.wigit.create_bounty(args.title, args.description, reward, args.labels)
                self._print_success(f"已创建悬赏: {bounty['id']}")
                
            elif args.bounty_action == "list":
                bounties = self.wigit.list_bounties(args.status if args.status != "all" else None)
                if bounties:
                    self._print_info(f"悬赏列表 ({len(bounties)}):")
                    for b in bounties:
                        status_color = "green" if b['status'] == "open" else ("yellow" if b['status'] == "in_progress" else "red")
                        self._print_color(f"  [{b['id'][:8]}] {b['title']} - {b['reward']}", status_color)
                else:
                    self._print_warning("没有找到悬赏")
                    
            elif args.bounty_action == "claim":
                bounty = self.wigit.claim_bounty(args.bounty_id, args.commit)
                self._print_success(f"已认领并解决悬赏: {bounty['title']}")
                
            elif args.bounty_action == "cancel":
                bounty = self.wigit.economy.cancel_bounty(args.bounty_id)
                self._print_success(f"已取消悬赏: {bounty['title']}")
        except Exception as e:
            self._print_error(f"悬赏操作失败: {e}")
    
    def _cmd_nft(self, args):
        """NFT管理"""
        try:
            from . import get_current_user
            
            if args.nft_action == "mint":
                user = get_current_user()
                contribution = {
                    "type": args.type,
                    "description": args.description or f"{args.type} 贡献",
                    "timestamp": datetime.now().isoformat()
                }
                nft = self.wigit.mint_nft(contribution)
                self._print_success(f"已铸造NFT: {nft['id']}")
                
            elif args.nft_action == "list":
                user = args.user or get_current_user()['username']
                nfts = self.wigit.economy.get_user_nfts(user)
                if nfts:
                    self._print_info(f"用户 {user} 的NFT ({len(nfts)}):")
                    for n in nfts:
                        print(f"  [{n['id'][:8]}] {n['data'].get('type', 'unknown')} - {datetime.fromtimestamp(n['timestamp']).strftime('%Y-%m-%d')}")
                else:
                    self._print_warning("没有找到NFT")
                    
            elif args.nft_action == "verify":
                valid = self.wigit.economy.verify_nft(args.nft_id)
                if valid:
                    self._print_success(f"NFT {args.nft_id} 有效")
                else:
                    self._print_error(f"NFT {args.nft_id} 无效")
        except Exception as e:
            self._print_error(f"NFT操作失败: {e}")
    
    def _cmd_leaderboard(self, args):
        """排行榜"""
        try:
            leaders = self.wigit.get_leaderboard(args.limit, args.min_score)
            if leaders:
                self._print_info("贡献排行榜:")
                for i, leader in enumerate(leaders, 1):
                    level_color = "green" if leader['level'] == "master" else ("cyan" if leader['level'] == "expert" else "yellow")
                    self._print_color(f"  {i}. {leader['user']} - {leader['score']} 分 ({leader['level']})", level_color)
            else:
                self._print_warning("暂无数据")
        except Exception as e:
            self._print_error(f"获取排行榜失败: {e}")
    
    def _cmd_reputation(self, args):
        """查看声誉"""
        try:
            from . import get_current_user
            user = args.user or get_current_user()['username']
            rep = self.wigit.get_reputation(user)
            
            self._print_info(f"用户: {user}")
            self._print_color(f"等级: {rep.get('level', 'novice')}", "green")
            self._print_color(f"总分: {rep.get('score', 0)}", "cyan")
            print(f"总提交: {rep.get('total_commits', 0)}")
            print(f"总审查: {rep.get('total_reviews', 0)}")
            print(f"完成悬赏: {rep.get('total_bounties', 0)}")
        except Exception as e:
            self._print_error(f"获取声誉失败: {e}")
    
    def _cmd_heatmap(self, args):
        """热图"""
        try:
            lines = self.wigit.get_hot_lines(args.file, args.top)
            if lines:
                self._print_info(f"文件 {args.file} 的热点行:")
                for line in lines:
                    self._print_color(f"  行 {line['line']}: {line['views']} 次查看, 平均 {line['avg_duration']:.0f}ms", "yellow")
            else:
                self._print_warning("暂无热图数据")
        except Exception as e:
            self._print_error(f"获取热图失败: {e}")
    
    def _cmd_complexity(self, args):
        """复杂度分析"""
        try:
            with open(args.file, 'r', encoding='utf-8') as f:
                content = f.read()
            
            if args.commit:
                result = self.wigit.analyze_complexity(args.commit, args.file, content)
            else:
                result = self.wigit.ai.analyze_code_complexity(content)
            
            self._print_info(f"复杂度分析: {args.file}")
            print(f"  复杂度分数: {result.get('complexity_score', 0)}/100")
            print(f"  认知负荷: {result.get('cognitive_load', '未知')}")
            print(f"  可读性: {result.get('readability', '良')}")
            
            if result.get('suggestions'):
                print(f"\n  优化建议:")
                for s in result['suggestions']:
                    print(f"    - {s}")
        except Exception as e:
            self._print_error(f"复杂度分析失败: {e}")
    
    def _cmd_archeology(self, args):
        """代码考古"""
        try:
            self._print_info(f"正在分析 {args.file}:{args.line} 的历史...")
            result = self.wigit.archeology(args.file, args.line)
            
            print(result.get('narrative', '无法生成考古报告'))
            
            if result.get('modification_count', 0) > 0:
                self._print_info(f"\n主要维护者: {result.get('top_author', '未知')}")
                print(f"总修改次数: {result.get('modification_count', 0)}")
        except Exception as e:
            self._print_error(f"代码考古失败: {e}")
    
    def _cmd_design(self, args):
        """设计稿版本控制"""
        try:
            if args.design_action == "version":
                metadata = None
                if args.metadata:
                    import json
                    metadata = json.loads(args.metadata)
                result = self.wigit.version_design(args.file, metadata)
                self._print_success(f"已版本化设计稿: {result['version_id']}")
                
            elif args.design_action == "diff":
                result = self.wigit.diff_design(args.version1, args.version2)
                if result['hash_changed']:
                    self._print_warning(f"文件已更改，时间差: {result['timestamp_diff']:.0f}秒")
                else:
                    self._print_info("文件未更改")
                    
            elif args.design_action == "list":
                versions = self.wigit.multimodal.list_design_versions()
                if versions:
                    self._print_info("设计稿版本:")
                    for v in versions:
                        print(f"  {v['version_id']} - {datetime.fromtimestamp(v['timestamp']).strftime('%Y-%m-%d %H:%M')}")
                else:
                    self._print_warning("暂无版本")
        except Exception as e:
            self._print_error(f"设计稿操作失败: {e}")
    
    def _cmd_api(self, args):
        """API契约版本控制"""
        try:
            if args.api_action == "version":
                import json
                with open(args.file, 'r', encoding='utf-8') as f:
                    spec = json.load(f)
                result = self.wigit.version_api(spec)
                if result.get('is_breaking'):
                    self._print_warning(f"检测到破坏性变更! 版本: {result['version_id']}")
                else:
                    self._print_success(f"已版本化API契约: {result['version_id']}")
                    
            elif args.api_action == "diff":
                result = self.wigit.multimodal.diff_api(args.version1, args.version2)
                print(result.get('diff', '无差异'))
        except Exception as e:
            self._print_error(f"API操作失败: {e}")
    
    def _cmd_schema(self, args):
        """数据库Schema版本控制"""
        try:
            if args.schema_action == "version":
                with open(args.file, 'r', encoding='utf-8') as f:
                    sql = f.read()
                result = self.wigit.version_schema(sql, args.database)
                if result.get('is_compatible'):
                    self._print_success(f"已版本化Schema: {result['version_id']}")
                else:
                    self._print_warning(f"Schema不兼容! 版本: {result['version_id']}")
                    
            elif args.schema_action == "diff":
                result = self.wigit.diff_schema(args.version1, args.version2)
                print(result.get('diff', '无差异'))
                if result.get('compatibility_to', {}).get('issues'):
                    self._print_warning("存在兼容性问题")
        except Exception as e:
            self._print_error(f"Schema操作失败: {e}")
    
    def _cmd_ghost(self, args):
        """代码幽灵注释"""
        try:
            if args.ghost_action == "add":
                result = self.wigit.add_ghost_annotation(args.file, args.line, args.text, args.context)
                self._print_success("已添加代码幽灵注释")
                
            elif args.ghost_action == "list":
                annotations = self.wigit.get_ghost_annotations(args.file)
                if annotations:
                    self._print_info(f"文件 {args.file} 的代码幽灵注释:")
                    for a in annotations:
                        print(f"  行 {a['line']}: {a['text']}")
                        print(f"    作者: {a['author']}, 时间: {datetime.fromtimestamp(a['timestamp']).strftime('%Y-%m-%d')}")
                else:
                    self._print_warning("暂无代码幽灵注释")
        except Exception as e:
            self._print_error(f"幽灵注释操作失败: {e}")
    
    def _cmd_cursor(self, args):
        """光标同步"""
        try:
            self.wigit.update_cursor(args.file, args.line, args.column)
            cursors = self.wigit.realtime.get_cursors()
            if cursors:
                self._print_info("当前协作光标:")
                for sid, cursor in cursors.items():
                    if cursor.get('user') != self.wigit.realtime.session_id:
                        print(f"  {cursor.get('user', 'unknown')}: {cursor.get('file')}:{cursor.get('line')}")
        except Exception as e:
            self._print_error(f"光标同步失败: {e}")
    
    def _cmd_explain(self, args):
        """AI解释代码"""
        try:
            with open(args.file, 'r', encoding='utf-8') as f:
                content = f.read()
            
            if args.lines:
                start, end = map(int, args.lines.split('-'))
                lines = content.splitlines()
                content = '\n'.join(lines[start-1:end])
            
            self._print_info("AI正在分析代码...")
            explanation = self.wigit.ai.explain_code(content)
            print(explanation)
        except Exception as e:
            self._print_error(f"解释代码失败: {e}")
    
    def _cmd_review(self, args):
        """AI代码审查"""
        try:
            if args.commit:
                # 获取指定commit的文件内容
                content = self.wigit.repository.get_file_at_commit(args.file, args.commit)
            else:
                with open(args.file, 'r', encoding='utf-8') as f:
                    content = f.read()
            
            self._print_info("AI正在进行代码审查...")
            result = self.wigit.ai.review_code(content, args.file)
            
            score = result.get('overall_score', 50)
            score_color = "green" if score >= 80 else ("yellow" if score >= 60 else "red")
            self._print_color(f"总体评分: {score}/100", score_color)
            print(f"总结: {result.get('summary', '')}")
            
            if result.get('strengths'):
                self._print_info("\n优点:")
                for s in result['strengths']:
                    print(f"  ✓ {s}")
            
            if result.get('issues'):
                self._print_warning("\n问题:")
                for i in result['issues']:
                    severity_color = "red" if i['severity'] == "critical" else ("yellow" if i['severity'] == "major" else "cyan")
                    self._print_color(f"  [{i['severity']}] 行 {i.get('line', '?')}: {i['message']}", severity_color)
                    print(f"    建议: {i.get('suggestion', '')}")
        except Exception as e:
            self._print_error(f"代码审查失败: {e}")


def main():
    """主入口函数"""
    cli = WiGitCLI()
    cli.run()


if __name__ == "__main__":
    main()
