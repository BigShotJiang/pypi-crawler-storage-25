# WiGit - 下一代版本控制系统

<div align="center">

**基于Git协议的AI原生、实时协作、多模态版本控制系统**

[![Python](https://img.shields.io/badge/Python-3.7+-blue.svg)](https://python.org)
[![License](https://img.shields.io/badge/License-WEIZI%C2%AE%20Qumo%E2%84%A2-red.svg)](LICENSE)
[![Status](https://img.shields.io/badge/Status-Beta-yellow.svg)]()

</div>

---

## 📖 简介

WiGit 是一个革命性的版本控制系统，在完整实现 Git 核心协议的基础上，提供了五大增强功能层：

- 🔄 **实时协作** - 像 Figma 一样的实时编辑体验
- 🤖 **AI 原生集成** - 语义提交、智能合并、代码解释
- 🎨 **多模态版本控制** - 设计稿、API契约、数据库Schema版本化
- 💎 **经济激励层** - 贡献度NFT、代码悬赏、声誉系统
- 🧠 **认知增强** - 注意力热图、代码考古、复杂度分析

## 🚀 快速开始

### 安装

```bash
# 克隆仓库
git clone https://github.com/wigit/wigit.git
cd wigit

# 安装依赖
pip install -r requirements.txt

# 开发模式安装
pip install -e .
```

### 基础使用

```bash
# 登录账户
wigit login

# 初始化仓库
wigit init

# 添加文件
wigit add .

# 使用AI生成提交信息
wigit commit --semantic

# 查看状态
wigit status

# 查看历史
wigit log --graph
```

### 增强功能

```bash
# AI智能合并
wigit smart-merge feature-branch

# 代码考古
wigit archeology src/main.py 42

# 创建悬赏
wigit bounty create "修复登录Bug" "登录页面无法跳转" -r money:100:CNY

# 查看排行榜
wigit leaderboard

# AI代码审查
wigit review src/main.py

# 版本化设计稿
wigit design version design.figma

# 版本化API契约
wigit api version openapi.json

# 代码复杂度分析
wigit complexity src/main.py

# 查看代码热图
wigit heatmap src/main.py
```

## 📁 项目结构

```
wigit/
├── __init__.py          # 包入口
├── WiGit.py             # 核心业务逻辑（完整Git实现）
├── cli.py               # 命令行接口
├── Plus.py              # 五大增强层
├── setup.py             # 安装脚本
├── pyproject.toml       # 项目配置
└── README.md            # 说明文档
```

## 🔧 命令参考

### 基础命令

| 命令 | 说明 |
|------|------|
| `wigit init` | 初始化仓库 |
| `wigit add <files>` | 添加文件到暂存区 |
| `wigit commit -m <msg>` | 提交更改 |
| `wigit commit --semantic` | AI生成提交信息 |
| `wigit status` | 查看状态 |
| `wigit log` | 查看历史 |
| `wigit diff` | 查看差异 |
| `wigit branch` | 分支管理 |
| `wigit checkout <branch>` | 切换分支 |
| `wigit merge <branch>` | 合并分支 |
| `wigit push` | 推送到远程 |
| `wigit pull` | 从远程拉取 |

### AI增强命令

| 命令 | 说明 |
|------|------|
| `wigit semantic` | AI生成语义化提交信息 |
| `wigit smart-merge <branch>` | AI智能合并 |
| `wigit explain <file>` | AI解释代码 |
| `wigit review <file>` | AI代码审查 |
| `wigit knowledge <query>` | 知识图谱查询 |

### 经济激励命令

| 命令 | 说明 |
|------|------|
| `wigit bounty create` | 创建悬赏 |
| `wigit bounty list` | 列出悬赏 |
| `wigit bounty claim <id>` | 认领悬赏 |
| `wigit nft mint` | 铸造贡献NFT |
| `wigit nft list` | 列出NFT |
| `wigit leaderboard` | 贡献排行榜 |
| `wigit reputation` | 查看声誉 |

### 多模态命令

| 命令 | 说明 |
|------|------|
| `wigit design version <file>` | 版本化设计稿 |
| `wigit design diff <v1> <v2>` | 比较设计稿版本 |
| `wigit api version <file>` | 版本化API契约 |
| `wigit schema version <file>` | 版本化数据库Schema |

### 认知增强命令

| 命令 | 说明 |
|------|------|
| `wigit heatmap <file>` | 代码注意力热图 |
| `wigit complexity <file>` | 复杂度分析 |
| `wigit archeology <file> <line>` | 代码考古 |
| `wigit ghost add` | 添加代码幽灵注释 |
| `wigit ghost list` | 列出幽灵注释 |

## 🤝 贡献指南

欢迎贡献代码！请遵循以下流程：

1. Fork 本仓库
2. 创建特性分支 (`git checkout -b feature/AmazingFeature`)
3. 提交更改 (`git commit -m 'Add some AmazingFeature'`)
4. 推送到分支 (`git push origin feature/AmazingFeature`)
5. 开启 Pull Request

## 📝 许可证

```
╔═══════════════════════════════════════════════════════════════╗
║                                                               ║
║   WEIZI ® Qumo ™ ©'23 All rights reserved.                   ║
║                                                               ║
║   This software is provided for viewing purposes only.       ║
║                                                               ║
║   You may not:                                               ║
║   • Copy this software                                       ║
║   • Modify this software                                     ║
║   • Distribute this software                                 ║
║   • Sell this software                                       ║
║   • Use this code in any form without explicit written       ║
║     permission from the author                               ║
║                                                               ║
║   For licensing inquiries, contact: licensing@wigit.com      ║
║                                                               ║
╚═══════════════════════════════════════════════════════════════╝
```

## 📞 联系方式

- 作者: WEIZI ® Qumo ™
- 邮箱: contact@wigit.com
- 网站: https://wigit.com

## 🙏 致谢

- Git 社区 - 提供版本控制协议基础
- DeepSeek - 提供AI API支持
- 所有贡献者

---

<div align="center">
  <sub>Built with ❤️ by WEIZI ® Qumo ™</sub>
</div>
```

同时建议创建一个 `LICENSE` 文件：

```text
# LICENSE

WEIZI ® Qumo ™ ©'23 All rights reserved.

This software is provided for viewing purposes only.

You may not:
- Copy this software
- Modify this software
- Distribute this software
- Sell this software
- Use this code in any form without explicit written permission from the author

For licensing inquiries, contact: licensing@wigit.com

---

This software is protected by copyright law and international treaties. 
Unauthorized reproduction or distribution of this program, or any portion 
of it, may result in severe civil and criminal penalties, and will be 
prosecuted to the maximum extent possible under law.
