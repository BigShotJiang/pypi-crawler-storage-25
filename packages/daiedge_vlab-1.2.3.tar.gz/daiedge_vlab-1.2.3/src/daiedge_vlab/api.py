"""dAIEdge Vlab API Client Library"""

import logging
import requests
import yaml
import os
import io
import json
import hashlib
from pathlib import Path
from typing import Callable

from threading import Thread
from time import sleep
import time
from .config import OnDeviceTrainingConfig
from .fl import *

# Configure logging at the module level
logging.basicConfig(
    level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s"
)


def _sha256sum(path, chunk_size=8192):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(chunk_size), b""):
            h.update(chunk)
    return h.hexdigest()


class dAIEdgeVLabAPI:
    """Client library for interacting with the dAIEdge Vlab API."""

    def __init__(
        self,
        config_file: str | Path | None = None,
        url: str | None = None,
        port: int | None = None,
        base_path: str = "",
        ssl: bool = True,
        auto_refresh: bool = False,
    ):
        """
        Initialize the API client.

        This constructor allows you to instantiate the client either by providing a configuration file
        or by specifying the URL and port directly. The configuration file should include the API URL, port,
        user email, and password.

        Args
        ----
        config_file (str or Path, Optional)
            Path to the configuration file containing API connection details and user credentials.
        url (str, optional)
            API host address (if config_file is not provided).
        port (int, optional)
            API port (if config_file is not provided).
        base_path (str, optional)
            Base path for the API endpoints. Default is an empty string.
        ssl (bool, optional)
            Whether to use SSL for the connection. Default is True.
        auto_refresh (bool, optional)
            Whether to start the token refresh thread. Default is False.

        Raises
        ------
        RuntimeError
            If neither config_file nor url and port are provided, or if there is an error during login.
        ValueError
            If the configuration file is invalid or missing required fields.
        """

        self.token = None
        self.refresh_token = None
        self.refresh_is_running = False
        self.refresh_thread = None

        # Get a logger instance for this class
        self.logger = logging.getLogger(__name__)

        self.ssl = ssl
        self.auto_refresh = auto_refresh

        if config_file is None:
            if url is None or port is None:
                raise RuntimeError(
                    "Either config_file or url and port must be provided"
                )
            self.host = url
            self.port = port
            self.base_path = base_path
            self.__check_version()
            return

        else:
            with open(config_file, "r") as file:
                content = file.read()
            # Expand environment variables in the file content
            content = os.path.expandvars(content)
            config = yaml.safe_load(content)

            # Retrieve configuration values from the file
            self.host = config.get("api", {}).get("url", None)
            self.port = config.get("api", {}).get("port", None)
            self.base_path = config.get("api", {}).get("base_path", "")
            self.ssl = config.get("api", {}).get("ssl", True)
            self.username = config.get("user", {}).get("email", None)
            self.password = config.get("user", {}).get("password", None)

            if (
                self.host is None
                or self.port is None
                or self.username is None
                or self.password is None
            ):
                raise ValueError("Invalid config file")

            # Check if API version is supported before attempting login
            self.__check_version()
            status = self.login(auto_refresh=auto_refresh)

            if not status:
                raise RuntimeError("Error while logging in.")

    def __del__(self) -> None:
        """
        Destructor for the API client.

        This method ensures that the refresh thread is stopped and the access token is invalidated.
        """

        self.logout()

    def __build_endpoint(self) -> str:
        """
        Build the full URL for an API endpoint.
        This internal method constructs the full URL for a given API endpoint by combining
        the host, port, base path, and the specific endpoint.

        Returns
        -------
        The full URL for the API endpoint.
        """

        if self.ssl:
            protocol = "https"
        else:
            protocol = "http"

        if self.base_path != "" and self.base_path is not None:
            return f"{protocol}://{self.host}:{self.port}/{self.base_path.lstrip('/').rstrip('/')}"
        else:
            return f"{protocol}://{self.host}:{self.port}"

    def __build_url(self, endpoint: str) -> str:
        """
        Build the full URL for an API endpoint.
        This internal method constructs the full URL for a given API endpoint by combining
        the host, port, base path, and the specific endpoint.

        Args
        ----
        endpoint (str)
            The specific API endpoint (e.g., '/api/status').
        variables (dict)
            A dictionary of variables to format the endpoint string.

        Returns
        -------
        The full URL for the API endpoint.
        """

        base = self.__build_endpoint()
        return f"{base}/{endpoint.lstrip('/').rstrip('/')}"

    def __build_headers(self) -> dict:
        """
        Build the headers for API requests.

        This internal method constructs the headers required for API requests,
        including the Authorization header with the access token.

        Returns
        -------
        A dictionary containing the headers for API requests.
        """

        return (
            {"Authorization": f"Bearer {self.token}"} if self.token is not None else {}
        )

    def __check_version(self) -> None:
        """
        Check the API version and status.

        This internal method verifies that the API version is supported (must be '0.2.0')
        and that the API status is OK. It is called during initialization.

        Raises
        ------
        RuntimeError if the API version is not supported or if the API status is not OK.
        """

        r = self.getAPIStatus()
        # If version start with '0.2.', consider it compatible
        if not r["version"].startswith("1.") and not r["version"].startswith("dev"):
            raise RuntimeError("API version not supported, please update the client")
        if r["status"] != "OK":
            raise RuntimeError("API status not OK")

    def __refresh_token(self) -> None:
        """
        Refresh the access token every 10 minutes.

        This internal method is run on a separate thread to refresh the access token every 10 minutes.
        """

        self.refresh_is_running = True
        refresh_interval = 10 * 60  # seconds
        timestamp = time.time()
        while self.refresh_is_running:
            # Check if it's time to refresh
            if time.time() - timestamp > refresh_interval:
                try:
                    self.refresh()
                except Exception as e:
                    self.logger.error(f"Error during token refresh: {e}")
                    self.logger.info("Stopping token refresh thread...")
                    self.logger.info("Please log in again to continue using the API.")
                    self.refresh_is_running = False
                timestamp = time.time()
            sleep(1)  # Sleep to reduce CPU usage

    def __print_request_error(
        self, message: str, response: requests.Response | None
    ) -> None:
        """
        Print request error details.

        This internal method logs the details of a failed request.

        Args
        ----
        response (requests.Response)
            The response object from the failed request.
        """

        if response is None:
            self.logger.error(f"{message} No response received.")
        else:
            self.logger.error(
                f"{message} Status : {response.status_code}, {response.text}"
            )

    def __print_request_warning(
        self, message: str, response: requests.Response | None
    ) -> None:
        """
        Print request warning details.

        This internal method logs the details of a warning from a request.

        Args
        ----
        response (requests.Response)
            The response object from the request.
        """

        if response is None:
            self.logger.warning(f"{message} No response received.")
        else:
            self.logger.warning(
                f"{message} Status : {response.status_code}, {response.text}"
            )

    def __uploadDataset(self, filepath: str | Path, dataset_hash: str) -> str | None:
        """
        Upload a dataset file to the API.

        Args
        ----
        filepath (str or Path)
            The file path of the dataset to be uploaded.
        dataset_hash (str)
            The hash of the dataset file to be uploaded.

        Returns
        -------
        The base name of the uploaded file if successful, otherwise None.
        """

        filepath = Path(filepath) if isinstance(filepath, str) else filepath
        if not filepath.exists() or not filepath.is_file():
            raise FileNotFoundError(f"Dataset file {filepath} not found.")

        url = self.__build_url("/api/benchmarks/datasets/upload")
        headers = self.__build_headers()
        data = {"hash": dataset_hash}
        r = requests.post(
            url, headers=headers, files={"dataset": open(filepath, "rb")}, data=data
        )

        if r.status_code != 207:
            self.logger.error(
                f"Error while uploading dataset. Status : {r.status_code}, {r.raw}"
            )
            return None

        return filepath.name

    def login(
        self,
        username: str | None = None,
        password: str | None = None,
        auto_refresh: bool | None = None,
    ) -> bool:
        """
        Log in to the API and obtain an access token.

        You can optionally provide a username and password; otherwise, the ones stored during initialization will be used.
        Upon successful login, an access token is stored for future API requests.

        Args
        ----
        username (str, optional)
            User's email for login.
        password (str, optional)
            User's password for login.
        auto_refresh (bool, optional)
            Whether to start the token refresh thread. Default is None -> uses the instance setting.

        Returns
        -------
        True if login is successful, otherwise False.

        Raises
        ------
        RuntimeError if username or password is missing.
        """

        if username is not None:
            self.username = username
        if password is not None:
            self.password = password
        if self.username is None or self.password is None:
            raise RuntimeError("Username and password must be provided")

        url = self.__build_url("/api/users/login")
        r = requests.post(url, json={"email": self.username, "password": self.password})

        if r.status_code != 200:
            self.__print_request_error(
                "Error while logging in. Please verify your credentials or visit the API status page for more information.",
                r,
            )
            return False

        self.token = r.json()["access_token"]
        self.refresh_token = r.json()["refresh_token"]

        if auto_refresh is None:
            auto_refresh = self.auto_refresh

        if auto_refresh:
            self.refresh_thread = Thread(target=self.__refresh_token)
            self.refresh_thread.daemon = True
            self.refresh_thread.start()

        return True

    def logout(self) -> None:
        """
        Log out of the API. This method invalidates the access token and stops the refresh thread.
        """

        self.token = None
        self.refresh_token = None
        self.refresh_is_running = False
        if self.refresh_thread is not None:
            self.refresh_thread.join()

    def refresh(self) -> bool:
        """
        Refresh the access token.

        This method refreshes the access token using the refresh token obtained during login.
        The new access token is stored for future API requests.

        Returns:
            bool: True if the refresh is successful, otherwise False.
        """
        url = self.__build_url("/api/users/token/refresh")

        r = requests.post(url, json={"refresh": self.refresh_token})

        if r.status_code != 200:
            self.__print_request_error(
                "Error while refreshing token. Please verify your credentials or visit the API status page for more information.",
                r,
            )
            raise RuntimeError(
                "Error while refreshing token. Please verify your credentials or visit the API status page for more information."
            )

        self.token = r.json()["access"]
        return True

    def startBenchmark(
        self,
        target: str,
        runtime: str,
        model_path: Path | str,
        inference_number: int = 20,
        dataset: str | Path | None = None,
        callback: Callable | None = None,
        target_uids: list[str] | None = None,
    ) -> str | None:
        """
        Start a new benchmark job.

        This method submits a benchmark job to the API for the given target device and runtime.
        It uploads the model (and optionally a dataset) to be benchmarked. Optionally, a callback function
        can be provided, which will be executed on a separate thread when the benchmark completes.

        Args:
            target (str): The target device identifier.
            runtime (str): The runtime engine to be used.
            model_path (str): Path to the model file.
            inference_number (int, optional): The number of inferences to be performed for the benchmark. Default is 20.
            dataset (str or binary file, optional): Either a dataset name (string) or a binary file object path.
            target_uids (list of str, optional): List of target UIDs that can be used for the benchmark - if None, any available target will be used.
                Caution: This parameter can be overvritten by the server if the user lacks the permissions to use the specified targets or to use this feature.
                Caution: This parameter is under development and may not be fully supported by all API versions.
            callback (function, optional): A function to be called with the benchmark result upon completion.

        Returns:
            str: The ID of the created benchmark job.
            none: If there was an error starting the benchmark.

        Raises:
            Exception: If the dataset provided is neither a string nor a valid binary file.
        """

        url = self.__build_url("/api/benchmarks/run")
        headers = self.__build_headers()
        data = {
            "device": target,
            "engine": runtime,
            "target_uids": json.dumps(target_uids) if target_uids is not None else None,
            "nb_inference": inference_number,
        }

        if dataset is not None:
            if os.path.isfile(dataset):
                dataset_ref = self.uploadDataset(dataset)
                data.update({"dataset_name": dataset_ref})
                r = requests.post(
                    url,
                    headers=headers,
                    data=data,
                    files={"model": open(model_path, "rb")},
                )
            elif isinstance(dataset, str):
                datasets = self.getDatasets()

                if datasets is None:
                    self.__print_request_error(
                        "Error while retrieving datasets to check for existing uploads.",
                        None,
                    )
                    return None

                if dataset in datasets:
                    data.update({"dataset_name": dataset})
                    r = requests.post(
                        url,
                        headers=headers,
                        data=data,
                        files={"model": open(model_path, "rb")},
                    )
                else:
                    raise Exception(f"Dataset {dataset} not found on server.")
            else:
                raise Exception(
                    "Invalid dataset - must be a string or a dataset reference"
                )
        else:
            r = requests.post(
                url, headers=headers, data=data, files={"model": open(model_path, "rb")}
            )

        if r.status_code != 200:
            self.__print_request_error("Error while starting benchmark.", r)
            return None

        # If a callback is provided and the request is successful, start a thread to wait for the result.
        if callback is not None and r.status_code == 200:
            Thread(
                target=self.notifyOnBenchmarkResult, args=(r.json()["id"], callback)
            ).start()

        return r.json()["id"]

    def getDatasets(self) -> dict | None:
        """
        Retrieve the list of available datasets from the API.

        Returns:
            dict: A dictionary containing datasets information.
        """
        url = self.__build_url("/api/benchmarks/datasets")
        headers = self.__build_headers()
        r = requests.get(url, headers=headers)
        if r.status_code != 200:
            self.__print_request_error("Error while getting datasets.", r)
            return None
        return r.json()

    def notifyOnBenchmarkResult(self, id, callback) -> None:
        """
        Wait for the benchmark to complete and notify via callback.

        This method is intended to be run on a separate thread. It waits for the benchmark
        identified by 'id' to finish, then calls the provided callback function with the result.

        Args:
            id (str): The benchmark job ID.
            callback (function): The function to be called with the benchmark result.
        """
        result = self.waitBenchmarkResult(id, verbose=True)
        callback(result)

    def getBenchmarkStatus(self, id: str) -> dict | None:
        """
        Get the current status of a benchmark job.

        Args:
            id (str): The benchmark job ID.

        Returns:
            dict: A dictionary with the status details of the benchmark job.
        """
        url = self.__build_url(f"/api/benchmarks/{id}/status")
        headers = self.__build_headers()
        r = requests.get(url, headers=headers)
        if r.status_code != 200:
            self.__print_request_error("Error while getting benchmark status.", r)
            return None
        return r.json()

    def getBenchmarkResult(
        self, id: str, save_path: str | Path | None = None, model_name_only: bool = True
    ) -> dict:
        """
        Retrieve the complete benchmark result.

        This method aggregates the benchmark report, user log, error log, and raw binary output.

        Args:
            id (str): The benchmark job ID.
            save_path (str, optional): If provided, all the results will be saved to this path.
            model_name_only (bool, optional): If True, returns only the trained model name instead of the bytes that represent the model output.

        Returns:
            dict: A dictionary containing 'report', 'user_log', 'error_log', and 'raw_output'.
        """
        report = self.getBenchmarkReport(id, save_path)
        user_log = self.getInfoLog(id, save_path)
        error_log = self.getErrorLog(id, save_path)
        raw_output = self.getBinaryOutput(id, save_path)
        model_output = self.getModelOutput(id, save_path, model_name_only)

        return {
            "report": report,
            "user_log": user_log,
            "error_log": error_log,
            "raw_output": raw_output,
            "model_output": model_output,
        }

    def getBenchmarkReport(
        self, id: str, save_path: str | Path | None = None
    ) -> dict | None:
        """
        Retrieve the detailed benchmark report.

        Args:
            id (str): The benchmark job ID.
            save_path (str, Path, optional): If provided, the benchmark report will be saved to this path.

        Returns:
            A dictionary with the benchmark report details.
        """
        url = self.__build_url(f"/api/benchmarks/{id}/results")
        headers = self.__build_headers()
        r = requests.get(url, headers=headers)
        if r.status_code != 200:
            return None

        if save_path is not None:
            # Save the report to the specified path
            with open(os.path.join(save_path, f"{id}_benchmark_report.json"), "w") as f:
                json.dump(r.json(), f, indent=4)

        return r.json()

    def waitBenchmarkResult(
        self,
        id: str,
        save_path: str | Path | None = None,
        model_name_only: bool = True,
        interval: int = 2,
        verbose: bool = False,
    ) -> dict | None:
        """
        Wait until the benchmark job is complete.

        This method polls the benchmark status every 'interval' seconds until the status is either
        'success', 'canceled', or 'failed'. Optionally prints the status if verbose is True.

        Args:
            id (str): The benchmark job ID.
            save_path (str, optional): If provided, all the results will be saved to this path.
            model_name_only (bool, optional): If True, returns only the trained model name instead of the bytes that represent the model output.
            interval (int, optional): Polling interval in seconds. Default is 2.
            verbose (bool, optional): Whether to print status updates. Default is False.

        Returns:
            The complete benchmark result (aggregated report, logs, and raw output).
        """

        status = self.getBenchmarkStatus(id)
        if status is None:
            self.__print_request_error("Error while getting benchmark status.", None)
            return None

        while (
            status["status"] != "success"
            and status["status"] != "canceled"
            and status["status"] != "failed"
        ):
            status = self.getBenchmarkStatus(id)
            if verbose:
                self.logger.info(f"Benchmark status: {status['status']}")
            sleep(interval)

        return self.getBenchmarkResult(id, save_path, model_name_only)

    def getAvailableConfigurations(self, full: bool = False) -> dict | None:
        """
        Retrieve available benchmark runner configurations.

        Args:
            full (bool, optional): If True, retrieves the full configuration details. Default is False.

        Returns:
            dict: A dictionary containing the available configurations. Returns None if the request fails.
        """

        url = self.__build_url("/api/benchmarks/config")
        headers = self.__build_headers()

        r = requests.get(url, headers=headers, params={"full": full})

        if r.status_code != 200:
            self.__print_request_error(
                "Error while getting available configurations.", r
            )
            return None

        return r.json()

    def getAPIStatus(self) -> dict:
        """
        Retrieve the API status information.

        This includes details such as API version and overall status.

        Returns:
            dict: A dictionary containing the API status information.
        """

        url = self.__build_url("/api/benchmarks/status")
        r = requests.get(url)
        return r.json()

    def getBenchmarks(self) -> dict | None:
        """
        Retrieve all benchmarks for the authenticated user.

        Returns:
            dict: A dictionary containing all benchmark jobs. Returns None if the request fails.
        """

        url = self.__build_url("/api/benchmarks")
        headers = self.__build_headers()
        r = requests.get(url, headers=headers)
        if r.status_code != 200:
            self.__print_request_error("Error while getting benchmarks history.", r)
            return None
        return r.json()

    def getBenchmarkInfo(self, id: str) -> dict | None:
        """
        Get the general information of a benchmark job.

        Args:
            id (str): The benchmark job ID.

        Returns:
            dict: A dictionary with the information details of the benchmark job.
        """

        url = self.__build_url(f"/api/benchmarks/{id}")
        headers = self.__build_headers()
        r = requests.get(url, headers=headers)
        if r.status_code != 200:
            self.__print_request_error("Error while getting benchmark info.", r)
            return None
        return r.json()

    def getErrorLog(self, id: str, save_path: str | Path | None = None) -> str | None:
        """
        Retrieve the error log for a specific benchmark job.

        Args:
            id (str): The benchmark job ID.
            save_path (str, Path, optional): If provided, the error log will be saved to this path.

        Returns:
            str: The error log text if available, otherwise None.
        """

        url = self.__build_url(f"/api/benchmarks/{id}/error-log")
        headers = self.__build_headers()
        r = requests.get(url, headers=headers)

        if r.status_code == 204:
            return None
        elif r.status_code == 428:
            self.__print_request_warning(
                f"Error log for benchmark {id} is not yet available.", r
            )
            return None
        elif r.status_code != 200:
            self.__print_request_error(
                f"Error while getting error log for benchmark {id}.", r
            )
            return None

        if save_path is not None:
            save_path = Path(save_path) if isinstance(save_path, str) else save_path
            # Save the error log to the specified path
            with open(save_path / f"{id}_error_log.txt", "w") as f:
                f.write(r.text)

        return r.text

    def getInfoLog(self, id: str, save_path: str | Path | None = None) -> str | None:
        """
        Retrieve the user log for a specific benchmark job.

        Args:
            id (str): The benchmark job ID.
            save_path (str, Path, optional): If provided, the user log will be saved to this path.

        Returns:
            str: The user log text if available, otherwise None.
        """

        url = self.__build_url(f"/api/benchmarks/{id}/user-log")
        headers = self.__build_headers()
        r = requests.get(url, headers=headers)

        if r.status_code == 204:
            return None
        elif r.status_code == 428:
            self.__print_request_warning(
                f"User log for benchmark {id} is not yet available.", r
            )
            return None
        elif r.status_code != 200:
            self.__print_request_error(
                f"Error while getting user log for benchmark {id}.", r
            )
            return None

        if save_path is not None:
            save_path = Path(save_path) if isinstance(save_path, str) else save_path
            # Save the user log to the specified path
            with open(save_path / f"{id}_user_log.txt", "w") as f:
                f.write(r.text)

        return r.text

    def getBinaryOutput(
        self, id: str, save_path: str | Path | None = None
    ) -> bytes | None:
        """
        Retrieve the binary output of a benchmark job.

        Args:
            id (str): The benchmark job ID.
            save_path (str, Path, optional): If provided, the binary output will be saved to this path.

        Returns:
            bytes: The binary output data as bytes if available, otherwise None.
        """

        url = self.__build_url(f"/api/benchmarks/{id}/binary")
        headers = self.__build_headers()
        r = requests.get(url, headers=headers)

        if r.status_code == 204:
            return None
        elif r.status_code == 428:
            self.__print_request_warning(
                f"Binary file for benchmark {id} is not yet available.", r
            )
            return None
        elif r.status_code != 200:
            self.__print_request_error(
                f"Error while getting binary output for benchmark {id}.", r
            )
            return None

        if save_path is not None:
            save_path = Path(save_path) if isinstance(save_path, str) else save_path
            # Save the binary output to the specified path
            with open(save_path / f"{id}_output.bin", "wb") as f:
                f.write(r.content)

        return bytes(r.content)

    def getModelOutput(
        self, id: str, save_path: str | Path | None = None, name_only: bool = True
    ) -> bytes | str | None:
        """
        Retrieve the model output for a specific benchmark job.

        Args:
            id (str): The benchmark job ID.
            save_path (str, Path, optional): If provided, the model output will be saved to this path.
            name_only (bool, optional): If True, returns only the model name instead of the bytes that represent the model output.

        Returns:
            bytes or str: The model output as bytes if available and name_only is False, the model name if name_only is True, otherwise None.
        """
        url = self.__build_url(f"/api/benchmarks/{id}/trained-model")
        headers = self.__build_headers()
        r = requests.get(url, headers=headers)

        if r.status_code == 204:
            return None
        elif r.status_code == 428:
            self.__print_request_warning(
                f"Trained model for benchmark {id} is not yet available.", r
            )
            return None
        elif r.status_code != 200:
            self.__print_request_error(
                f"Error while getting model output for benchmark {id}.", r
            )
            return None

        content_disp = r.headers.get("Content-Disposition", "")
        model_name = None
        if "filename=" in content_disp:
            model_name = content_disp.split("filename=")[1].strip('"')
            # Fallback to using the ID if no filename is provided
            model_name = os.path.basename(model_name)
            model_name = f"{id}_{model_name}"

        if save_path is not None and model_name is not None:
            save_path = Path(save_path) if isinstance(save_path, str) else save_path
            # Save the model output to the specified path
            with open(save_path / model_name, "wb") as f:
                f.write(r.content)

        if name_only:
            # If name_only is True, return only the model name
            return model_name

        return bytes(r.content)

    def deleteDataset(self, name: str) -> bool:
        """
        Delete a dataset from the API.

        Args:
            name (str): The name of the dataset to be deleted.

        Returns:
            bool: True if the deletion is successful, otherwise False.
        """

        url = self.__build_url(f"/api/benchmarks/datasets/{name}")
        headers = self.__build_headers()
        r = requests.delete(url, headers=headers)
        return r.status_code == 200

    def deleteBenchmark(self, id: str) -> bool:
        """
        Delete a benchmark job from the API.

        Args:
            id (str): The ID of the benchmark job to be deleted.

        Returns:
            bool: True if the deletion is successful, otherwise False.
        """

        url = self.__build_url(f"/api/benchmarks/{id}")
        headers = self.__build_headers()
        r = requests.delete(url, headers=headers)
        return r.status_code == 200

    def uploadDataset(self, path: str | Path) -> str | None:
        """
        Upload a dataset file to the API if it is not already uploaded.

        Args:
            path (str, Path): The file path of the dataset to be uploaded.

        Returns:
            str: The base name of the uploaded file if successful, otherwise None.
        """

        path = Path(path) if isinstance(path, str) else path

        dataset_hash = _sha256sum(path)
        dataset_ref = path.name + "_" + dataset_hash
        datasets = self.getDatasets()

        if datasets is None:
            self.__print_request_error(
                "Error while retrieving datasets to check for existing uploads.", None
            )
            return None

        if dataset_ref in datasets:
            print(f"Dataset {path.name} already uploaded.")
            return dataset_ref
        else:
            self.logger.info(f"Dataset {path.name} not found, uploading...")
            try:
                self.__uploadDataset(path, dataset_hash)
            except FileNotFoundError as ex:
                self.logger.error(
                    f"Dataset file {path} not found. Please verify the file path and try again."
                )
                raise ex

            return dataset_ref

    def startOdtBenchmark(
        self,
        target: str,
        runtime: str,
        model_path: str | Path,
        config: OnDeviceTrainingConfig,
        target_uids: list[str] | None = None,
        callback: Callable | None = None,
    ) -> str | None:
        """
        Start a new benchmark job for ODT.

        This method submits a benchmark job to the API for the given target device and runtime.
        It uploads the model (and optionally a dataset) to be benchmarked. Optionally, a callback function
        can be provided, which will be executed on a separate thread when the benchmark completes.

        Args:
            target (str): The target device identifier.
            runtime (str): The runtime engine to be used.
            model_path (str, Path): Path to the model file.
            config (OnDeviceTrainingConfig): The configuration for on-device training.
            target_uids (list of str, optional): List of target UIDs that can be used for the benchmark - if None, any available target will be used.
                Caution: This parameter can be overvritten by the server if the user lacks the permissions to use the specified targets or to use this feature.
                Caution: This parameter is under development and may not be fully supported by all API versions
            callback (function, optional): A function to be called with the benchmark result upon completion.

        Returns:
            str: The ID of the created benchmark job.

        Raises:
            Exception: If the dataset provided is neither a string nor a valid binary file.
        """

        url = self.__build_url("/api/benchmarks/train")
        headers = self.__build_headers()
        data = {
            "device": target,
            "engine": runtime,
            "target_uids": json.dumps(target_uids) if target_uids is not None else None,
        }

        # Validate the configuration
        if not config.validate_config(config.config):
            raise ValueError("Configuration validation failed: see missing keys above")

        datasets = self.getDatasets()

        if datasets is None:
            self.__print_request_error(
                "Error while retrieving datasets to check for existing uploads.", None
            )
            return None

        # Upload the dataset if not already uploaded
        if config.config["input"]["train_file"] not in datasets:
            if os.path.isfile(config.input_spec["train_file"]):
                dataset_ref = self.uploadDataset(config.input_spec["train_file"])
                config.config["input"]["train_file"] = dataset_ref
                print(f"Dataset input.train_file {dataset_ref} uploaded.")
            else:
                raise Exception(
                    f"Input train file {config.input_spec['train_file']} not found and not uploaded"
                )

        if config.config["input"]["test_file"] not in datasets:
            if os.path.isfile(config.input_spec["test_file"]):
                dataset_ref = self.uploadDataset(config.input_spec["test_file"])
                config.config["input"]["test_file"] = dataset_ref
                print(f"Dataset input.test_file {dataset_ref} uploaded.")
            else:
                raise Exception(
                    f"Input test file {config.input_spec['test_file']} not found and not uploaded"
                )

        if config.output_spec["train_file"] not in datasets:
            if os.path.isfile(config.output_spec["train_file"]):
                dataset_ref = self.uploadDataset(config.output_spec["train_file"])
                config.config["output"]["train_file"] = dataset_ref
                print(f"Dataset output.train_file {dataset_ref} uploaded.")
            else:
                raise Exception(
                    f"Output train file {config.output_spec['train_file']} not found and not uploaded"
                )

        if config.output_spec["test_file"] not in datasets:
            if os.path.isfile(config.output_spec["test_file"]):
                dataset_ref = self.uploadDataset(config.output_spec["test_file"])
                config.config["output"]["test_file"] = dataset_ref
                print(f"Dataset output.test_file {dataset_ref} uploaded.")
            else:
                raise Exception(
                    f"Output test file {config.output_spec['test_file']} not found and not uploaded"
                )

        # Start ODT benchmark
        r = requests.post(
            url,
            headers=headers,
            data=data,
            files={"model": open(model_path, "rb"), "config": config.get_config_str()},
        )

        if r.status_code != 200:
            self.__print_request_error("Error while starting ODT benchmark.", r)
            return None

        # If a callback is provided and the request is successful, start a thread to wait for the result.
        if callback is not None and r.status_code == 200:
            Thread(
                target=self.notifyOnBenchmarkResult, args=(r.json()["id"], callback)
            ).start()

        return r.json()["id"]

    def startFLExperiment(self, fl_experiment: FlExperiment):
        """
        Start a new benchmark job for FL.

        This method submits a benchmark job to the API for the given target device and runtime.
        It uploads the model (and optionally a dataset) to be benchmarked. Optionally, a callback function
        can be provided, which will be executed on a separate thread when the benchmark completes.

        Args:
            fl_experiment (FlExperiment): The configuration for the FL experiment.
        Returns:
            str: The ID of the created benchmark job.
        """

        fl_experiment.export_experiment_config()
        fl_config_path = fl_experiment.upload_datasets(self)

        url = self.__build_url("/api/benchmarks/fl/run")
        headers = self.__build_headers()

        r = requests.post(
            url,
            headers=headers,
            data={},
            files={
                "model": open(fl_experiment.get_model_path(), "rb"),
                "fl_config": open(fl_config_path, "rb"),
            },
        )

        if r.status_code != 200:
            self.__print_request_error(
                "Error while starting FL experiment benchmark.", r
            )
            return None

        return r.json()["id"]
