from __future__ import annotations
import os
import json
from typing import Tuple, Any, Dict, List, TYPE_CHECKING
from enum import Enum
from abc import ABC, abstractmethod
import numpy as np
import shutil

from .config import OnDeviceTrainingConfig

if TYPE_CHECKING:
    from .api import dAIEdgeVLabAPI


def compute_round_window(
    start_round: int, stop_round: int | None = None, round_interval: int | None = None
) -> tuple[int, int]:
    if start_round < 1:
        raise ValueError("start_round must be >= 1")
    if stop_round is not None and round_interval is not None:
        raise ValueError("round_interval cannot be set if stop_round is set")
    if stop_round is not None:
        if stop_round < start_round:
            raise ValueError("stop_round must be >= start_round")
        return start_round, stop_round
    if round_interval is not None:
        return start_round, start_round + round_interval - 1
    return start_round, start_round


class ClientDataset:
    def __init__(
        self,
        train_data: Tuple[np.ndarray, np.ndarray],
        test_data: Tuple[np.ndarray, np.ndarray],
        unique_id: str = "",
    ):
        self.unique_id = unique_id
        self.train_data = train_data
        self.test_data = test_data
        self.input_type = str(train_data[0].dtype)
        self.output_type = str(train_data[1].dtype)
        self.num_train_samples = train_data[0].shape[0]
        self.num_test_samples = test_data[0].shape[0]

    def store_dataset_as_bin(self, base_name: str, path: str) -> None:
        train_input_path = os.path.join(
            path, f"{base_name}_train_input_d{self.unique_id}.bin"
        )
        train_target_path = os.path.join(
            path, f"{base_name}_train_target_d{self.unique_id}.bin"
        )
        test_input_path = os.path.join(
            path, f"{base_name}_test_input_d{self.unique_id}.bin"
        )
        test_target_path = os.path.join(
            path, f"{base_name}_test_target_d{self.unique_id}.bin"
        )

        self.train_data[0].tofile(train_input_path)
        self.train_data[1].tofile(train_target_path)
        self.test_data[0].tofile(test_input_path)
        self.test_data[1].tofile(test_target_path)

        config = OnDeviceTrainingConfig()
        config.set_input_config(
            name="input",
            shape=self.train_data[0].shape[1:],  # Exclude batch dimension
            dtype=self.input_type,
            test_file=os.path.basename(test_input_path),
            train_file=os.path.basename(train_input_path),
        )
        config.set_output_config(
            name="output",
            shape=self.train_data[1].shape[1:],  # Exclude batch dimension
            dtype=self.output_type,
            test_file=os.path.basename(test_target_path),
            train_file=os.path.basename(train_target_path),
        )
        return config


class ServerDataset:
    def __init__(self, data: Tuple[np.ndarray, np.ndarray], unique_id: str = ""):
        self.data = data
        self.unique_id = unique_id
        self.config = {}

    def store_dataset_as_bin(self, base_name: str, path: str) -> dict:
        input_path = os.path.join(path, f"{base_name}_eval_input_d{self.unique_id}.bin")
        target_path = os.path.join(
            path, f"{base_name}_eval_target_d{self.unique_id}.bin"
        )

        self.data[0].tofile(input_path)
        self.data[1].tofile(target_path)

        self.config = {
            "input": {
                "name": "input",
                "shape": self.data[0].shape[1:],  # Exclude batch dimension
                "dtype": str(self.data[0].dtype),
                "file": os.path.basename(input_path),
            },
            "output": {
                "name": "output",
                "shape": self.data[1].shape[1:],  # Exclude batch dimension
                "dtype": str(self.data[1].dtype),
                "file": os.path.basename(target_path),
            },
        }

        return self.config


class EventType(Enum):
    FAILURE = "failure"
    NETWORK_ISSUE = "network_issue"
    SLOW_RESPONSE = "slow_response"
    REDUCED_DATASET = "reduced_dataset"
    EPOCH_COMPLETION = "epoch_completion"
    DELAYED_RESPONSE = "delayed_response"
    UPDATED_STATUS = "updated_status"


class FLStatusUpdateType(Enum):
    POWER_STATUS = "power_status"
    TEMPERATURE_STATUS = "temperature_status"
    COST_STATUS = "cost_status"


class PowerType(Enum):
    BATTERY = "Battery"
    SOLAR = "Solar"
    AC = "AC"


class Event(ABC):

    @abstractmethod
    def get_event_type(self) -> EventType:
        pass

    @abstractmethod
    def get_event_list(self) -> List[Dict]:
        pass

    def test_start_stop_rounds(
        self, start_round: int, stop_round: int, interval: int = None
    ):
        if start_round < 1:
            raise ValueError("start_round must be greater than or equal to 1")
        self.start_round = start_round
        if interval != None and stop_round != None:
            raise ValueError("interval cannot be set if stop_round is set")
        if stop_round != None:
            if stop_round < start_round:
                raise ValueError(
                    "stop_round must be greater than or equal to start_round"
                )
            self.stop_round = stop_round
        elif interval != None:
            self.stop_round = start_round + interval - 1
        else:
            self.stop_round = start_round


class FLEventFailure(Event):
    def __init__(self, round: int):
        self.test_start_stop_rounds(round, None, None)
        self.description = f"Client failed at round {round}"

    def get_event_type(self) -> EventType:
        return EventType.FAILURE

    def get_event_list(self) -> List[Dict]:
        return [
            {
                "type": self.get_event_type().value,
                "round": self.start_round,
                "description": self.description,
            }
        ]


class FLEventNetworkIssue(Event):
    def __init__(
        self,
        start_round: int,
        stop_round: int = None,
        round_interval: int = None,
        roud_timeout_s: int = None,
        fail_fast: bool = False,
    ):
        self.test_start_stop_rounds(start_round, stop_round, round_interval)

        if roud_timeout_s is not None and fail_fast == True:
            print(
                "WARNING: roud_timeout_s is set but fail_fast is True. Ignoring roud_timeout_s."
            )
            self.roud_timeout_s = 0
        elif roud_timeout_s is None and fail_fast == False:
            print(
                "INFO: roud_timeout_s is not set but fail_fast is False. Setting network failure after training."
            )
            self.roud_timeout_s = 0
            self.fail_fast = True

        self.roud_timeout_s = roud_timeout_s
        self.fail_fast = fail_fast
        self.description = f"Network issues from round {self.start_round} to {self.stop_round}, timeout={self.roud_timeout_s}, fail_fast={self.fail_fast}"

    def get_event_type(self) -> EventType:
        return EventType.NETWORK_ISSUE

    def get_event_list(self) -> List[Dict]:
        events = []
        for round in range(self.start_round, self.stop_round + 1):
            events.append(
                {
                    "type": self.get_event_type().value,
                    "round": round,
                    "roud_timeout_s": self.roud_timeout_s,
                    "fail_fast": self.fail_fast,
                    "description": self.description,
                }
            )
        return events


class FLEventDelayedResponse(Event):
    def __init__(
        self,
        start_round: int,
        stop_round: int = None,
        round_interval: int = None,
        delay_seconds: int = 10,
    ):
        self.test_start_stop_rounds(start_round, stop_round, round_interval)
        self.delay_seconds = delay_seconds
        self.description = f"Delayed response (+{self.delay_seconds}s) from round {self.start_round} to {self.stop_round}"

    def get_event_type(self) -> EventType:
        return EventType.DELAYED_RESPONSE

    def get_event_list(self) -> List[Dict]:
        events = []
        for round in range(self.start_round, self.stop_round + 1):
            events.append(
                {
                    "type": self.get_event_type().value,
                    "round": round,
                    "delay_seconds": self.delay_seconds,
                    "description": self.description,
                }
            )
        return events


class FLEventSlowResponse(Event):
    def __init__(
        self,
        start_round: int,
        stop_round: int = None,
        round_interval: int = None,
        slow_factor: int = 1.1,
    ):
        self.test_start_stop_rounds(start_round, stop_round, round_interval)
        self.slow_factor = slow_factor
        self.description = f"Slow response (x{self.slow_factor}) from round {self.start_round} to {self.stop_round}"

    def get_event_type(self) -> EventType:
        return EventType.SLOW_RESPONSE

    def get_event_list(self) -> List[Dict]:
        events = []
        for round in range(self.start_round, self.stop_round + 1):
            events.append(
                {
                    "type": self.get_event_type().value,
                    "round": round,
                    "slow_factor": self.slow_factor,
                    "description": self.description,
                }
            )
        return events


class FLEventReducedDataset(Event):
    def __init__(
        self,
        start_round: int,
        stop_round: int = None,
        round_interval: int = None,
        new_size: int = 10,
        suffule: bool = True,
        seed: int = None,
    ):
        """Reduce dataset size to new_size by random sampling from start_round to stop_round."""
        """ Args:
            start_round (int): Round to start reducing dataset.
            stop_round (int): Round to stop reducing dataset.
            round_interval (int): Number of rounds to reduce dataset.
            new_size (int): New dataset size.
            suffule (bool): Whether to suffule dataset before sampling.
            seed (int): Random seed for sampling. None for random seed.
        """
        self.test_start_stop_rounds(start_round, stop_round, round_interval)
        self.new_size = new_size
        self.suffule = suffule
        self.seed = seed
        self.description = f"Dataset reduced to {self.new_size} samples from round {self.start_round} to {self.stop_round}, suffule={self.suffule}, seed={self.seed}"

    def get_event_type(self) -> EventType:
        return EventType.REDUCED_DATASET

    def get_event_list(self) -> List[Dict]:
        events = []
        for round in range(self.start_round, self.stop_round + 1):
            events.append(
                {
                    "type": self.get_event_type().value,
                    "round": round,
                    "new_size": self.new_size,
                    "suffule": self.suffule,
                    "seed": self.seed,
                    "description": self.description,
                }
            )
        return events


class FLEventEpochCompletion(Event):
    def __init__(
        self,
        start_round: int,
        stop_round: int = None,
        round_interval: int = None,
        epoch_number: int = 1,
    ):
        self.test_start_stop_rounds(start_round, stop_round, round_interval)
        self.epoch_number = epoch_number
        self.description = f"Epoch {self.epoch_number} completed from round {self.start_round} to {self.stop_round}"

    def get_event_type(self) -> EventType:
        return EventType.EPOCH_COMPLETION

    def get_event_list(self) -> List[Dict]:
        events = []
        for round in range(self.start_round, self.stop_round + 1):
            events.append(
                {
                    "type": self.get_event_type().value,
                    "round": round,
                    "epoch_number": self.epoch_number,
                    "description": self.description,
                }
            )
        return events


class FLEventUpdatedStatus(Event):
    def __init__(self, round: int, status_update: Dict[str, Any]):
        """
        status_update must contain at least:
          - "status_type": FLStatusUpdateType.value
          - type-specific fields (power, temperature, ...)
        """
        self.test_start_stop_rounds(round, None, None)

        if "status_type" not in status_update:
            raise ValueError("status_update must contain a 'status_type' field")

        self.status_update = status_update
        self.description = f"Status updated at round {round}: {self.status_update}"

    def get_event_type(self) -> EventType:
        return EventType.UPDATED_STATUS

    def get_event_list(self) -> List[Dict]:
        return [
            {
                "type": self.get_event_type().value,
                "round": self.start_round,
                "status_update": self.status_update,
                "description": self.description,
            }
        ]


class StatusProfile(ABC):
    def __init__(
        self,
        start_round: int,
        stop_round: int | None = None,
        round_interval: int | None = None,
    ):
        self.start_round, self.stop_round = compute_round_window(
            start_round, stop_round, round_interval
        )

    @abstractmethod
    def to_events(self) -> List[FLEventUpdatedStatus]:
        """Expand this profile into a list of per-round status events."""
        pass


class BatteryPowerProfile(StatusProfile):
    def __init__(
        self,
        start_round: int,
        stop_round: int | None = None,
        round_interval: int | None = None,
        *,
        initial_level_pct: float = 100.0,
        discharge_pct_per_round: float | None = None,
        discharge_pct_per_minute: float | None = None,
        is_charging: bool = False,
        min_level_pct: float = 0.0,
        max_level_pct: float = 100.0,
        profile_id: str | None = None,
    ):
        """
        Either discharge_pct_per_round or discharge_pct_per_minute must be provided.
        For charging, pass is_charging=True.
        """
        super().__init__(start_round, stop_round, round_interval)

        if discharge_pct_per_round is None and discharge_pct_per_minute is None:
            raise ValueError(
                "Either discharge_pct_per_round or discharge_pct_per_minute must be set"
            )

        if discharge_pct_per_round is not None and discharge_pct_per_minute is not None:
            raise ValueError(
                "Use either discharge_pct_per_round or discharge_pct_per_minute, not both"
            )

        self.initial_level_pct = initial_level_pct
        self.discharge_pct_per_round = discharge_pct_per_round
        # Convert to per-second rate for the client
        self.discharge_pct_per_second = (
            discharge_pct_per_minute / 60.0
            if discharge_pct_per_minute is not None
            else None
        )
        self.is_charging = is_charging
        self.min_level_pct = min_level_pct
        self.max_level_pct = max_level_pct
        self.profile_id = profile_id or f"battery_{self.start_round}_{self.stop_round}"

    def to_events(self) -> List[FLEventUpdatedStatus]:
        events: List[FLEventUpdatedStatus] = []

        for r in range(self.start_round, self.stop_round + 1):
            status_update: Dict[str, Any] = {
                "status_type": FLStatusUpdateType.POWER_STATUS.value,
                "power_source": PowerType.BATTERY.value,
                "profile_id": self.profile_id,
                "mode": "charging" if self.is_charging else "discharging",
                "bounds": {
                    "min_level_pct": self.min_level_pct,
                    "max_level_pct": self.max_level_pct,
                },
            }

            # Set base level only once, at the beginning of the profile.
            if r == self.start_round:
                status_update["initial_level_pct"] = self.initial_level_pct

            if self.discharge_pct_per_round is not None:
                status_update["discharge_pct_per_round"] = self.discharge_pct_per_round
            if self.discharge_pct_per_second is not None:
                status_update["discharge_pct_per_second"] = (
                    self.discharge_pct_per_second
                )

            events.append(FLEventUpdatedStatus(round=r, status_update=status_update))

        return events


class SolarPowerProfile(StatusProfile):
    def __init__(
        self,
        start_round: int,
        stop_round: int | None = None,
        round_interval: int | None = None,
        *,
        solar_intensity: float,
        profile_id: str | None = None,
    ):
        """
        solar_intensity: arbitrary unit (e.g. 0–1 or W/m^2). The client decides
        how to use it.
        """
        super().__init__(start_round, stop_round, round_interval)
        self.solar_intensity = solar_intensity
        self.profile_id = profile_id or f"solar_{self.start_round}_{self.stop_round}"

    def to_events(self) -> List[FLEventUpdatedStatus]:
        events: List[FLEventUpdatedStatus] = []

        for r in range(self.start_round, self.stop_round + 1):
            status_update = {
                "status_type": FLStatusUpdateType.POWER_STATUS.value,
                "power_source": PowerType.SOLAR.value,
                "profile_id": self.profile_id,
                "solar_intensity": self.solar_intensity,
            }
            events.append(FLEventUpdatedStatus(round=r, status_update=status_update))

        return events


class ACPowerProfile(StatusProfile):
    def __init__(
        self,
        start_round: int,
        stop_round: int | None = None,
        round_interval: int | None = None,
        *,
        profile_id: str | None = None,
    ):
        super().__init__(start_round, stop_round, round_interval)
        self.profile_id = profile_id or f"ac_{self.start_round}_{self.stop_round}"

    def to_events(self) -> List[FLEventUpdatedStatus]:
        events: List[FLEventUpdatedStatus] = []
        for r in range(self.start_round, self.stop_round + 1):
            status_update = {
                "status_type": FLStatusUpdateType.POWER_STATUS.value,
                "power_source": PowerType.AC.value,
                "profile_id": self.profile_id,
            }
            events.append(FLEventUpdatedStatus(round=r, status_update=status_update))
        return events


class TemperatureProfile(StatusProfile):
    def __init__(
        self,
        start_round: int,
        stop_round: int | None = None,
        round_interval: int | None = None,
        *,
        temperature_c: float,
        profile_id: str | None = None,
    ):
        super().__init__(start_round, stop_round, round_interval)
        self.temperature_c = temperature_c
        self.profile_id = profile_id or f"temp_{self.start_round}_{self.stop_round}"

    def to_events(self) -> List[FLEventUpdatedStatus]:
        events: List[FLEventUpdatedStatus] = []
        for r in range(self.start_round, self.stop_round + 1):
            status_update = {
                "status_type": FLStatusUpdateType.TEMPERATURE_STATUS.value,
                "profile_id": self.profile_id,
                "temperature_c": self.temperature_c,
            }
            events.append(FLEventUpdatedStatus(round=r, status_update=status_update))
        return events


class FlConfig:
    def __init__(
        self,
        rounds: int,
        aggregator: str = "FedAvg",
        model_controller: str = "Single",
        selection_strategy: str = "All",
        client_config_provider: str = None,
        server_dataset: ServerDataset = None,
        round_timeout_s: int = None,
    ):
        self.rounds = rounds
        self.server_dataset: ServerDataset = server_dataset
        self.min_fit_clients: int = 1
        self.min_available_clients: int = 1
        self.min_eval_clients: int = 1
        self.aggregator: str = aggregator
        self.model_controller: str = model_controller
        self.selection_strategy: str = selection_strategy
        self.client_config_provider: str = client_config_provider
        self.round_timeout_s: int = round_timeout_s
        self.dataset_config: dict = None

    def add_parameters_aggregator(self, **kwargs: Any):
        self.parameters_aggregator = kwargs

    def add_parameters_selector(self, **kwargs: Any):
        self.parameters_selector = kwargs

    def add_parameters_model_controller(self, **kwargs: Any):
        self.parameters_model_controller = kwargs

    def add_parameters_config_provider(self, **kwargs: Any):
        self.parameters_config_provider = kwargs

    def set_min_clients(self, min_fit: int, min_available: int, min_eval: int):
        self.min_fit_clients = min_fit
        self.min_available_clients = min_available
        self.min_eval_clients = min_eval

    def prepare_data(self, path: str = "./server"):
        if self.server_dataset is None:
            return
        self.dataset_config = self.server_dataset.store_dataset_as_bin(
            base_name="server", path=path
        )

    def get_config(self) -> dict:
        if self.dataset_config is None and self.server_dataset is not None:
            return ValueError("Server dataset not prepared. Call prepare_data() first.")
        return {
            "rounds": self.rounds,
            "aggregator": self.aggregator,
            "model_controller": self.model_controller,
            "selection_strategy": self.selection_strategy,
            "client_config_provider": self.client_config_provider,
            "min_fit_clients": self.min_fit_clients,
            "min_available_clients": self.min_available_clients,
            "min_eval_clients": self.min_eval_clients,
            "round_timeout_s": self.round_timeout_s,
            "server_dataset": self.dataset_config,
            "parameters_aggregator": getattr(self, "parameters_aggregator", {}),
            "parameters_selector": getattr(self, "parameters_selector", {}),
            "parameters_model_controller": getattr(
                self, "parameters_model_controller", {}
            ),
            "parameters_config_provider": getattr(
                self, "parameters_config_provider", {}
            ),
        }


class TrainingConfig:
    def __init__(
        self, epochs: int, batch_size: int, learning_rate: float, **kwargs: Any
    ):
        self.epochs = epochs
        self.batch_size = batch_size
        self.learning_rate = learning_rate
        self.extra_params = kwargs


class FlModel:
    def __init__(
        self,
        runtime: str,
        model_path: str,
        input_shape: Tuple[int, ...],
        output_shape: Tuple[int, ...],
    ):
        self.model_path = model_path
        self.runtime = runtime
        self.input_shape = input_shape
        self.output_shape = output_shape
        self.model_filename = os.path.basename(model_path)

    def get_model_config(self) -> dict:
        return {
            "path": self.model_path,
            "runtime": self.runtime,
            "input_shape": self.input_shape,
            "output_shape": self.output_shape,
            "model_filename": self.model_filename,
        }


class ClientConfig:
    def __init__(
        self,
        target: str,
        dataset: ClientDataset,
        training_config: TrainingConfig,
        join_at_round: int = 0,
    ):
        self.target = target
        self.dataset = dataset
        self.join_at_round = join_at_round
        self.client_id = None
        self.runtime = None
        self.model_filename = None
        self.training_config = training_config
        self.odt_config: OnDeviceTrainingConfig = None
        self.events: Dict[int, List[Event]] = {}

    def add_event(self, event: Event):
        events = event.get_event_list()
        for e in events:
            round_ = e["round"]
            if round_ < self.join_at_round:
                print(
                    f"[ClientConfig] Warning: Event round {round_} is before client join round {self.join_at_round}. Skipping event."
                )
                continue

            if e["type"] == EventType.UPDATED_STATUS.value and "status_update" in e:
                new_status = e["status_update"]
                status_kind = new_status.get(
                    "status_type"
                )  # e.g. "power_status", "temperature_status"
                power_source = new_status.get(
                    "power_source"
                )  # BATTERY/SOLAR/AC for power

                existing_round_events = self.events.get(round_, [])
                for existing in existing_round_events:
                    if existing["type"] != EventType.UPDATED_STATUS.value:
                        continue
                    ex_status = existing.get("status_update", {})
                    ex_kind = ex_status.get("status_type")
                    ex_power_source = ex_status.get("power_source")

                    # Rule 1: same status_type (POWER_STATUS / TEMPERATURE_STATUS) cannot be duplicated
                    if ex_kind == status_kind:
                        # For power, we can be even stricter if needed
                        if status_kind == FLStatusUpdateType.POWER_STATUS.value:
                            # Collision of power profile for same round
                            raise ValueError(
                                f"[ClientConfig] Conflicting power status for client {self.client_id} at round {round_}: "
                                f"{ex_power_source} vs {power_source}"
                            )
                        else:
                            # For temperature/cost, also forbid more than one status for same round
                            raise ValueError(
                                f"[ClientConfig] Conflicting status '{status_kind}' for client {self.client_id} at round {round_}"
                            )

            if round_ not in self.events:
                self.events[round_] = []
            self.events[round_].append(e)
        print(f"[ClientConfig] Events {self.events}")

    def add_battery_profile(self, **kwargs) -> None:
        profile = BatteryPowerProfile(**kwargs)
        for ev in profile.to_events():
            self.add_event(ev)

    def add_solar_profile(self, **kwargs) -> None:
        profile = SolarPowerProfile(**kwargs)
        for ev in profile.to_events():
            self.add_event(ev)

    def add_ac_profile(self, **kwargs) -> None:
        profile = ACPowerProfile(**kwargs)
        for ev in profile.to_events():
            self.add_event(ev)

    def add_temperature_profile(self, **kwargs) -> None:
        profile = TemperatureProfile(**kwargs)
        for ev in profile.to_events():
            self.add_event(ev)

    def set_client_id(self, index: int):
        self.client_id = f"client_{index}"

    def set_model_filename(self, filename: str):
        self.model_filename = filename

    def prepare_odt_config(
        self, dataset_path: str = "./", export=False
    ) -> OnDeviceTrainingConfig:
        if self.runtime is None:
            raise ValueError("Runtime must be set before preparing ODT config.")
        if self.client_id is None:
            raise ValueError("Client ID must be set before preparing ODT config.")

        self.odt_config = self.dataset.store_dataset_as_bin(
            self.client_id, dataset_path
        )
        self.odt_config.set_learning_parameters(
            batch_size=self.training_config.batch_size,
            epochs=self.training_config.epochs,
            **self.training_config.extra_params,
        )
        if export:
            self.odt_config_json = os.path.join(
                dataset_path, f"{self.client_id}_odt_config.json"
            )
            config = self.odt_config.get_config_str()
            with open(self.odt_config_json, "w") as f:
                f.write(config)
        return self.odt_config

    def get_client_config(self) -> dict:
        if self.odt_config is None:
            raise ValueError(
                "ODT config not prepared. Call prepare_odt_config() first."
            )
        return {
            "client_id": self.client_id,
            "target": self.target,
            "runtime": self.runtime,
            "odt_config": self.odt_config.config,
            "model_filename": self.model_filename,
            "join_at_round": self.join_at_round,
            "training_parameters": {
                "epochs": self.training_config.epochs,
                "batch_size": self.training_config.batch_size,
                "learning_rate": self.training_config.learning_rate,
                **self.training_config.extra_params,
            },
            "events": self.events,
        }

    def prepare_config(self, dataset_path: str = "./", export=False) -> dict:

        if not os.path.exists(dataset_path):
            os.makedirs(dataset_path)

        self.prepare_odt_config(dataset_path, False)
        client_config = self.get_client_config()
        if export:
            client_config["file_name"] = f"{self.client_id}_config.json"
            config_path = os.path.join(dataset_path, client_config["file_name"])
            with open(config_path, "w") as f:
                import json

                json.dump(client_config, f, indent=4)

        return client_config


class FLObjective(Enum):
    TARGET_ACCURACY = "time_to_acc"
    TARGET_LOSS = "time_to_loss"
    MAX_ROUNDS = "max_rounds"
    LOSS_AT_TIME = "loss_at_time"
    ACC_AT_TIME = "acc_at_time"


class FLObjectiveAbstract(ABC):
    # obastract properties
    id: str

    @abstractmethod
    def to_dict(self) -> dict:
        pass


class FLTargetAccuracyObjective(FLObjectiveAbstract):
    def __init__(self, target_accuracy: float):
        self.objective_type = FLObjective.TARGET_ACCURACY
        self.target_accuracy = target_accuracy
        self.id = None

    def to_dict(self) -> dict:
        return {
            "type": self.objective_type.value,
            "id": self.id,
            "target_accuracy": self.target_accuracy,
        }


class FLTargetLossObjective(FLObjectiveAbstract):
    def __init__(self, target_loss: float):
        self.objective_type = FLObjective.TARGET_LOSS
        self.target_loss = target_loss
        self.id = None

    def to_dict(self) -> dict:
        return {
            "type": self.objective_type.value,
            "id": self.id,
            "target_loss": self.target_loss,
        }


class FLMaxRoundsObjective(FLObjectiveAbstract):
    def __init__(self, max_rounds: int):
        self.objective_type = FLObjective.MAX_ROUNDS
        self.max_rounds = max_rounds
        self.id = None

    def to_dict(self) -> dict:
        return {
            "type": self.objective_type.value,
            "id": self.id,
            "max_rounds": self.max_rounds,
        }


class FLLossAtTimeObjective(FLObjectiveAbstract):
    def __init__(self, time_seconds: int):
        self.objective_type = FLObjective.LOSS_AT_TIME
        self.time_seconds = time_seconds
        self.id = None

    def to_dict(self) -> dict:
        return {
            "type": self.objective_type.value,
            "id": self.id,
            "time_seconds": self.time_seconds,
        }


class FLAccAtTimeObjective(FLObjectiveAbstract):
    def __init__(self, time_seconds: int):
        self.objective_type = FLObjective.ACC_AT_TIME
        self.time_seconds = time_seconds
        self.id = None

    def to_dict(self) -> dict:
        return {
            "type": self.objective_type.value,
            "id": self.id,
            "time_seconds": self.time_seconds,
        }


class FlExperiment:
    def __init__(
        self,
        fl_model: FlModel,
        fl_config: FlConfig,
        clients: list[ClientConfig] = [],
        output_path: str = "./fl_experiment",
        objective: FLObjectiveAbstract = None,
    ):

        self.fl_model = fl_model
        self.fl_config = fl_config
        self.clients_config = clients
        self.output_path = output_path
        self.client_count = 0
        self.objectives = [FLMaxRoundsObjective(max_rounds=self.fl_config.rounds)]

        if objective is not None:
            self.objectives.append(objective)

        self.server_directory = "./server"

        # Initialize directories
        if not os.path.exists(self.output_path):
            os.makedirs(self.output_path)
        if not os.path.exists(os.path.join(self.output_path, "logs")):
            os.makedirs(os.path.join(self.output_path, "logs"))
        if not os.path.exists(os.path.join(self.output_path, self.server_directory)):
            os.makedirs(os.path.join(self.output_path, self.server_directory))

        self.fl_config.prepare_data(
            path=os.path.join(self.output_path, self.server_directory)
        )
        self.server_config = fl_config.get_config()
        self.server_config["model_filename"] = self.fl_model.model_filename
        self.server_config["server_direcroy"] = self.server_directory

        self.experiment_config = {
            "experiment_path": self.output_path,
            "model": self.fl_model.get_model_config(),
            "config": self.server_config,
            "clients": [],
            "counters": {
                "total_clients": len(self.clients_config),
            },
        }

        # Initialize server directory
        shutil.copyfile(
            self.fl_model.model_path,
            os.path.join(
                self.output_path,
                self.server_directory,
                os.path.basename(self.fl_model.model_path),
            ),
        )

        # Initialize existing clients
        for client in self.clients_config:
            self._initialize_client(client)

    def add_experiment_objective(self, objective: FLObjectiveAbstract) -> None:
        self.objectives.append(objective)

    def add_client(self, client_config: ClientConfig, export: bool = True) -> None:
        config = self._initialize_client(client_config, export)
        self.clients_config.append(client_config)
        self.experiment_config["clients"].append(config)
        self.experiment_config["counters"]["total_clients"] = self.client_count

    def _initialize_client(self, client: ClientConfig, export: bool = False) -> dict:
        client.runtime = self.fl_model.runtime
        client.set_client_id(self.client_count)
        client.set_model_filename(os.path.basename(self.fl_model.model_path))

        client_path = os.path.join(self.output_path, f"client_{self.client_count}")
        if not os.path.exists(client_path):
            os.makedirs(client_path)

        config = client.prepare_config(client_path, export=export)
        if export:
            # copy model artifacts to client folder
            artifacts_dest = os.path.join(
                client_path, os.path.basename(self.fl_model.model_path)
            )
            if not os.path.exists(artifacts_dest):
                shutil.copyfile(self.fl_model.model_path, artifacts_dest)

        self.client_count += 1

        return config

    def get_initial_client_count(self) -> int:
        initial_count = 0
        for client in self.clients_config:
            if client.join_at_round == 1:
                initial_count += 1
        return initial_count

    def export_experiment_config(
        self, filename: str = "fl_experiment_config.json"
    ) -> str:
        config_path = os.path.join(self.output_path, filename)

        server_config = os.path.join(
            self.output_path, self.server_directory, "server_config.json"
        )

        for idx, obj in enumerate(self.objectives):
            obj.id = f"O{idx + 1}"

        self.experiment_config["config"]["objectives"] = [
            obj.to_dict() for obj in self.objectives
        ]
        self.experiment_config["config"]["initial_num_clients"] = self.client_count

        with open(config_path, "w") as f:
            json.dump(self.experiment_config, f, indent=4)

        with open(server_config, "w") as f:
            json.dump(self.experiment_config["config"], f, indent=4)

        return config_path

    def upload_datasets(self, api: dAIEdgeVLabAPI) -> List[Tuple[str, str]]:

        updated_config = self.experiment_config.copy()

        server_config = self.experiment_config.get("config", {})
        data = server_config.get("server_dataset", {})
        for section in ("input", "output"):
            for key in ("file",):
                if section in data and key in data[section]:
                    server_dataset_path = os.path.join(
                        self.output_path, self.server_directory, data[section][key]
                    )
                    ref = api.uploadDataset(server_dataset_path)
                    updated_config["config"]["server_dataset"][section][key] = ref

        for client in self.experiment_config.get("clients", []):
            data = client.get("odt_config", {})
            # Find the corresponding client in updated_config to update its dataset references
            for updated_client in updated_config["clients"]:
                if updated_client["client_id"] == client["client_id"]:
                    to_update_client = updated_client

            for section in ("input", "output"):
                for key in ("train_file", "test_file"):
                    if section in data and key in data[section]:
                        client_dataset_path = os.path.join(
                            self.output_path, client["client_id"], data[section][key]
                        )
                        ref = api.uploadDataset(os.path.join(client_dataset_path))
                        to_update_client["odt_config"][section][key] = ref

        # Save the updated_config
        updated_config_path = os.path.join(
            self.output_path, "fl_experiment_config_updated.json"
        )
        with open(updated_config_path, "w") as f:
            json.dump(updated_config, f, indent=4)
        return updated_config_path

    def get_model_path(self) -> str:
        return os.path.join(
            self.output_path,
            self.server_directory,
            os.path.basename(self.fl_model.model_path),
        )


__all__ = [
    "ClientDataset",
    "ServerDataset",
    "TrainingConfig",
    "FlExperiment",
    "FlModel",
    "FlConfig",
    "ClientConfig",
    "Event",
    "FLEventFailure",
    "FLEventNetworkIssue",
    "FLEventDelayedResponse",
    "FLEventSlowResponse",
    "FLEventReducedDataset",
    "FLEventEpochCompletion",
    "FLEventUpdatedStatus",
    "StatusProfile",
    "BatteryPowerProfile",
    "SolarPowerProfile",
    "ACPowerProfile",
    "TemperatureProfile",
    "FLObjectiveAbstract",
    "FLTargetAccuracyObjective",
    "FLTargetLossObjective",
    "FLMaxRoundsObjective",
    "FLLossAtTimeObjective",
    "FLAccAtTimeObjective",
]
