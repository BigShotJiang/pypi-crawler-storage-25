# Configuration file for the Sphinx documentation builder.
#
# For the full list of built-in configuration values, see the documentation:
# https://www.sphinx-doc.org/en/master/usage/configuration.html

# -- Project information -----------------------------------------------------
# https://www.sphinx-doc.org/en/master/usage/configuration.html#project-information

import datetime
from importlib.metadata import version as get_version

project = 'dAIEdge Vlab'
company = "HE-Arc"
copyright = f'{datetime.datetime.now().year}, {company}'
author = 'Baptiste Dupertuis'


version = ".".join(get_version('daiedge-vlab').split(".")[:2])  # Get major.minor version
release = get_version('daiedge-vlab')  # Full version with patch
print(f"Documentation version: {version}")


# -- General configuration ---------------------------------------------------
# https://www.sphinx-doc.org/en/master/usage/configuration.html#general-configuration

extensions = [
    "sphinx_copybutton",
    "sphinx.ext.viewcode",
    "autoapi.extension",
]

# Generate API documentation from the source code
autoapi_dirs = ['../../src/daiedge_vlab/']
autoapi_add_toctree_entry = True
autoapi_member_order = "groupwise"
autoapi_python_class_content = "both"
autoapi_own_page_level = "class"
autoapi_options = [
    "members",
    "special-members",
    "show-module-summary",
    "show-inheritance"
]

templates_path = ['_templates']
exclude_patterns = []



# -- Options for HTML output -------------------------------------------------
# https://www.sphinx-doc.org/en/master/usage/configuration.html#options-for-html-output

html_theme = 'sphinx_rtd_theme'
html_static_path = ['_static']
html_theme_options = {
    "collapse_navigation": False,
    "display_version": True,
    "version_selector": True,
}
html_css_files = ["style.css"]
html_logo = "_static/img/logo.svg"

language = 'en'
