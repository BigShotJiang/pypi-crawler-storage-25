.. dAIEdge Vlab documentation master file, created by
   sphinx-quickstart on Mon Apr 20 15:42:47 2026.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

dAIEdge Vlab documentation
==========================

This is the documentation for dAIEdge Vlab API client library, which provides an interface to interact with the dAIEdge Vlab server for benchmarking machine learning models on edge devices.

.. toctree::
   :maxdepth: 1
   :caption: Contents:

   