"""Tree-sitter AST analyzer.

Uses tree-sitter grammars to parse source code and run S-expression
queries against the AST. This is fundamentally more accurate than
regex for code understanding because it respects:

  * Comments (queries match nodes; comment nodes have a different type)
  * String literals (the parser knows what's code vs. data)
  * Scoping (function definitions, classes, blocks)
  * Operator precedence and grammatical structure

A rule that says "match calls to eval()" actually matches calls, not
text that looks like a call. `eval(x)` inside a string literal does
not fire. `safe_eval(x)` does not fire (different identifier). That
fixes the entire class of false positives the comment-edge-cases
fixture documented as "KNOWN LIMITATION (phase 4 fix)".

Tree-sitter is import-on-demand: if the user doesn't have a grammar
for a language, that language falls back to the regex analyzer
silently. This means tree-sitter is a soft dependency — VulnScan
keeps working without it.
"""
from __future__ import annotations
from collections.abc import Iterator
from dataclasses import dataclass
from typing import Any

from vulnscan._core.analyzers.base import Analyzer
from vulnscan._core.rules.loader import AstRule, load_ast_rules
from vulnscan._core.scanner.types import FileContext, Finding
from vulnscan._core.utils.logging import logger


# Lazy-imported tree_sitter symbols. Held in a dict so we can probe
# whether tree-sitter is available without raising on import.
_TS: dict[str, Any] = {}


def _tree_sitter_available() -> bool:
    """Try to import tree-sitter once. Returns True if it works."""
    if _TS:
        return _TS.get("ok", False)
    try:
        import tree_sitter
        _TS["tree_sitter"] = tree_sitter
        _TS["ok"] = True
    except ImportError:
        _TS["ok"] = False
        logger.info(
            "tree-sitter not installed; AST analyzer disabled. "
            "Install with: pip install tree-sitter tree-sitter-python "
            "tree-sitter-javascript"
        )
    return _TS["ok"]


# Grammar registry: language name → factory that returns a Language.
# Each factory is wrapped in a try/except so missing grammars don't
# break import.
def _grammar_for(language: str):
    """Return a tree_sitter.Language for the given language, or None.

    Imports the per-language grammar lazily, on first use.
    """
    if not _tree_sitter_available():
        return None
    cache = _TS.setdefault("grammars", {})
    if language in cache:
        return cache[language]

    Language = _TS["tree_sitter"].Language
    try:
        if language == "python":
            import tree_sitter_python as ts_lang
        elif language in ("javascript", "jsx"):
            import tree_sitter_javascript as ts_lang
        elif language in ("typescript", "tsx"):
            # tree-sitter-typescript ships TWO grammars in the same
            # package: language_typescript() and language_tsx(). The
            # CLI doesn't currently distinguish; we use TSX which is
            # a superset.
            try:
                import tree_sitter_typescript as ts_pkg
                ts_lang_obj = Language(ts_pkg.language_tsx())
                cache[language] = ts_lang_obj
                return ts_lang_obj
            except ImportError:
                cache[language] = None
                return None
        else:
            cache[language] = None
            return None
        ts_lang_obj = Language(ts_lang.language())
        cache[language] = ts_lang_obj
        return ts_lang_obj
    except ImportError:
        # Grammar package not installed; fall back to regex
        cache[language] = None
        return None


@dataclass
class _CompiledQuery:
    rule: AstRule
    query: Any   # tree_sitter.Query


class AstAnalyzer(Analyzer):
    """Runs tree-sitter AST queries against source files.

    Reads the AST rules at construction time, compiles each one
    against every supported language. Queries that fail to compile
    (typically because the rule was written against a different
    grammar version) are logged and skipped — they don't take down
    the whole analyzer.
    """

    name = "ast"

    def __init__(self):
        # rules grouped by language: language → [_CompiledQuery]
        self._compiled: dict[str, list[_CompiledQuery]] = {}
        if not _tree_sitter_available():
            return
        rules = load_ast_rules()
        for rule in rules:
            for lang, query_str in rule.queries.items():
                grammar = _grammar_for(lang)
                if grammar is None:
                    continue
                try:
                    Query = _TS["tree_sitter"].Query
                    q = Query(grammar, query_str)
                    self._compiled.setdefault(lang, []).append(
                        _CompiledQuery(rule=rule, query=q)
                    )
                except Exception as e:
                    logger.warning(
                        f"AST rule {rule.id} failed to compile for "
                        f"language {lang}: {e}"
                    )

    def supports(self, ctx: FileContext) -> bool:
        if not ctx.language:
            return False
        return ctx.language in self._compiled

    def analyze(self, ctx: FileContext) -> Iterator[Finding]:
        if not self.supports(ctx):
            return
        grammar = _grammar_for(ctx.language)
        if grammar is None:
            return

        # Honor the same `# vulnscan: ignore` directives the regex
        # analyzer does. file_ignored short-circuits the whole file.
        from vulnscan._core.scanner.suppression import parse as parse_suppression
        suppressions = parse_suppression(ctx.content)
        if suppressions.file_ignored:
            return

        # Test-path heuristic: findings in test files get downgraded
        # to needs_review. Imported lazily to avoid analyzer-level
        # circular imports.
        from vulnscan._core.analyzers.pattern_analyzer import _looks_like_test
        is_test = _looks_like_test(ctx.relative_path)

        Parser = _TS["tree_sitter"].Parser
        QueryCursor = _TS["tree_sitter"].QueryCursor

        parser = Parser(grammar)
        try:
            source_bytes = ctx.content.encode("utf-8", errors="replace")
            tree = parser.parse(source_bytes)
        except Exception as e:
            logger.warning(f"tree-sitter parse failed on {ctx.relative_path}: {e}")
            return

        for cq in self._compiled[ctx.language]:
            try:
                cursor = QueryCursor(cq.query)
                matches = cursor.matches(tree.root_node)
            except Exception as e:
                logger.warning(f"AST query {cq.rule.id} failed on {ctx.relative_path}: {e}")
                continue
            for _pattern_idx, captures in matches:
                yield from self._finding_from_match(
                    cq.rule, captures, ctx, source_bytes,
                    suppressions=suppressions, is_test=is_test,
                )

    def _finding_from_match(
        self, rule: AstRule, captures: dict, ctx: FileContext, source: bytes,
        *, suppressions=None, is_test: bool = False,
    ) -> Iterator[Finding]:
        """Convert a tree-sitter match into a Finding.

        Uses the @match capture if present, else falls back to the
        first capture in the dict. Multi-line matches set both
        line_number and line_end. Honors suppression directives and
        downgrades confidence on test files.
        """
        from vulnscan._core.scanner.types import Confidence
        if "match" in captures:
            nodes = captures["match"]
        else:
            nodes = next((v for v in captures.values() if v), [])
        for node in nodes:
            line = node.start_point[0] + 1
            line_end = node.end_point[0] + 1

            # Honor inline suppression for this line+rule combo.
            if suppressions is not None and suppressions.is_suppressed(line, rule.id):
                continue

            try:
                snippet = source[node.start_byte:node.end_byte].decode(
                    "utf-8", errors="replace")
            except Exception:
                snippet = ""

            confidence = rule.confidence
            needs_review = rule.needs_review
            if is_test:
                # Same downgrade the regex analyzer applies: test files
                # get a notch lower confidence and needs_review=True so
                # fixtures aren't reported as production bugs.
                needs_review = True
                if confidence == Confidence.HIGH:
                    confidence = Confidence.MEDIUM
                elif confidence == Confidence.MEDIUM:
                    confidence = Confidence.LOW

            yield Finding(
                rule_id=rule.id,
                title=rule.title,
                severity=rule.severity,
                category=rule.category,
                file_path=ctx.relative_path,
                line_number=line,
                line_end=line_end if line_end != line else None,
                code_snippet=snippet[:200],
                description=rule.description,
                recommendation=rule.recommendation,
                confidence=confidence,
                cwe=rule.cwe,
                needs_review=needs_review,
            )
