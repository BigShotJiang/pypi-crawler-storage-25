"""Dependency vulnerability analyzer.

Parses common manifest files (requirements.txt, package.json) and
flags dependencies with known vulnerable versions from a small
embedded advisory database.

LIMITATION: The advisory list shipped here is illustrative and not
exhaustive. A production deployment should periodically sync from
OSV.dev (https://osv.dev) or GitHub Advisory Database.
"""
from __future__ import annotations
import json
import re
from collections.abc import Iterable
from dataclasses import dataclass

from packaging.specifiers import SpecifierSet
from packaging.version import Version, InvalidVersion

from vulnscan._core.analyzers.base import Analyzer
from vulnscan._core.scanner.types import Finding, FileContext, Severity, Confidence


@dataclass(frozen=True)
class Advisory:
    ecosystem: str          # 'pypi' | 'npm'
    package: str
    vulnerable: str         # PEP 440 specifier, e.g. "<2.31.0"
    cve: str
    severity: Severity
    title: str
    recommendation: str


# A small built-in advisory set. In production, replace with an OSV sync.
ADVISORIES: list[Advisory] = [
    Advisory("pypi", "requests", "<2.32.0", "CVE-2024-35195",
             Severity.MEDIUM,
             "requests session verify bypass",
             "Upgrade to requests>=2.32.0."),
    Advisory("pypi", "django", "<4.2.15", "CVE-2024-41989",
             Severity.HIGH,
             "Django floatformat memory exhaustion",
             "Upgrade to Django>=4.2.15 (or >=5.0.8 / >=5.1)."),
    Advisory("pypi", "flask", "<2.3.2", "CVE-2023-30861",
             Severity.HIGH,
             "Flask cookie session leakage when proxied",
             "Upgrade to Flask>=2.3.2."),
    Advisory("pypi", "pyyaml", "<5.4", "CVE-2020-14343",
             Severity.CRITICAL,
             "PyYAML arbitrary code execution via FullLoader",
             "Upgrade to PyYAML>=5.4 and use yaml.safe_load."),
    Advisory("pypi", "jinja2", "<3.1.4", "CVE-2024-34064",
             Severity.MEDIUM,
             "Jinja2 xmlattr XSS via attribute keys",
             "Upgrade to Jinja2>=3.1.4."),
    Advisory("pypi", "cryptography", "<42.0.0", "CVE-2023-50782",
             Severity.HIGH,
             "Bleichenbacher timing oracle in RSA decryption",
             "Upgrade to cryptography>=42.0.0."),

    Advisory("npm", "lodash", "<4.17.21", "CVE-2021-23337",
             Severity.HIGH,
             "Lodash command injection via template",
             "Upgrade to lodash>=4.17.21."),
    Advisory("npm", "axios", "<1.7.4", "CVE-2024-39338",
             Severity.HIGH,
             "Axios SSRF via absolute URL in path",
             "Upgrade to axios>=1.7.4."),
    Advisory("npm", "express", "<4.20.0", "CVE-2024-43796",
             Severity.MEDIUM,
             "Express response.redirect XSS",
             "Upgrade to express>=4.20.0."),
    Advisory("npm", "minimatch", "<3.0.5", "CVE-2022-3517",
             Severity.HIGH,
             "minimatch ReDoS",
             "Upgrade to minimatch>=3.0.5."),
    Advisory("npm", "semver", "<7.5.2", "CVE-2022-25883",
             Severity.MEDIUM,
             "semver ReDoS in new Range()",
             "Upgrade to semver>=7.5.2."),
]


class DependencyAnalyzer(Analyzer):
    name = "dependency"
    description = "Detects known-vulnerable dependencies in manifest and lock files."

    _SUPPORTED = {
        "requirements.txt", "requirements-dev.txt", "requirements-test.txt",
        "package.json", "package-lock.json", "poetry.lock",
    }

    def supports(self, file: FileContext) -> bool:
        return file.relative_path.split("/")[-1].lower() in self._SUPPORTED

    def analyze(self, file: FileContext) -> Iterable[Finding]:
        name = file.relative_path.split("/")[-1].lower()
        if name.startswith("requirements"):
            yield from self._scan_requirements(file)
        elif name == "package.json":
            yield from self._scan_package_json(file)
        elif name == "package-lock.json":
            yield from self._scan_package_lock(file)
        elif name == "poetry.lock":
            yield from self._scan_poetry_lock(file)

    # ----- Python -----
    _REQ_LINE = re.compile(r'^\s*([A-Za-z0-9_.\-]+)\s*([=<>!~].+)?\s*$')

    def _scan_requirements(self, file: FileContext) -> Iterable[Finding]:
        for i, raw in enumerate(file.lines, start=1):
            line = raw.split("#", 1)[0].strip()
            if not line or line.startswith("-"):
                continue
            m = self._REQ_LINE.match(line)
            if not m:
                continue
            pkg = m.group(1).lower()
            spec = (m.group(2) or "").strip()
            yield from self._match_advisories("pypi", pkg, spec, file, i, raw.rstrip())

    # ----- Node -----
    def _scan_package_json(self, file: FileContext) -> Iterable[Finding]:
        try:
            data = json.loads(file.content)
        except json.JSONDecodeError:
            return
        deps: dict[str, str] = {}
        for key in ("dependencies", "devDependencies", "peerDependencies"):
            section = data.get(key) or {}
            if isinstance(section, dict):
                deps.update(section)
        for pkg, version in deps.items():
            line_no = self._find_line(file.lines, pkg)
            spec = _npm_to_pep440(version)
            yield from self._match_advisories(
                "npm", pkg.lower(), spec, file, line_no,
                f'  "{pkg}": "{version}"'
            )

    @staticmethod
    def _find_line(lines: list[str], pkg: str) -> int:
        needle = f'"{pkg}"'
        for i, ln in enumerate(lines, start=1):
            if needle in ln:
                return i
        return 1

    # ----- npm lockfile (package-lock.json) -----
    def _scan_package_lock(self, file: FileContext) -> Iterable[Finding]:
        """Parse package-lock.json. Supports v1 (legacy) and v2/v3 (modern)
        lockfile formats. Direct AND transitive dependencies are checked.
        """
        try:
            data = json.loads(file.content)
        except json.JSONDecodeError:
            return

        emitted: set[tuple[str, str]] = set()  # de-dup (pkg, version)
        # v2/v3: "packages" is the canonical resolved tree.
        packages = data.get("packages")
        if isinstance(packages, dict):
            for path, info in packages.items():
                if not isinstance(info, dict):
                    continue
                if path == "":
                    continue   # the root project itself
                pkg = info.get("name") or _name_from_lock_path(path)
                version = info.get("version")
                if not pkg or not version:
                    continue
                key = (pkg.lower(), version)
                if key in emitted:
                    continue
                emitted.add(key)
                yield from self._match_advisories(
                    "npm", pkg.lower(), f"=={version}",
                    file, 1, f'  "{pkg}": "{version}"  (transitive via lockfile)',
                )
            return

        # v1: "dependencies" tree, recursive.
        legacy = data.get("dependencies")
        if isinstance(legacy, dict):
            yield from self._walk_legacy_lock(legacy, file, emitted)

    def _walk_legacy_lock(
        self, deps: dict, file: FileContext, emitted: set,
    ) -> Iterable[Finding]:
        for pkg, info in deps.items():
            if not isinstance(info, dict):
                continue
            version = info.get("version")
            if version:
                key = (pkg.lower(), version)
                if key not in emitted:
                    emitted.add(key)
                    yield from self._match_advisories(
                        "npm", pkg.lower(), f"=={version}",
                        file, 1, f'  "{pkg}": "{version}"  (transitive via lockfile)',
                    )
            nested = info.get("dependencies")
            if isinstance(nested, dict):
                yield from self._walk_legacy_lock(nested, file, emitted)

    # ----- poetry.lock -----
    # poetry.lock is TOML. Each [[package]] block looks like:
    #   [[package]]
    #   name = "requests"
    #   version = "2.28.0"
    _POETRY_BLOCK = re.compile(
        r'\[\[package\]\]\s*\n((?:[^\[]+\n)+)', re.MULTILINE,
    )
    _POETRY_NAME = re.compile(r'^name\s*=\s*"([^"]+)"', re.MULTILINE)
    _POETRY_VERSION = re.compile(r'^version\s*=\s*"([^"]+)"', re.MULTILINE)

    def _scan_poetry_lock(self, file: FileContext) -> Iterable[Finding]:
        """Lightweight poetry.lock parser.

        We avoid pulling in a TOML dependency by scanning [[package]] blocks
        with regex. This is sufficient because poetry.lock has a stable,
        machine-generated format. If the format changes incompatibly the
        block regex will simply find nothing — never wrong matches.
        """
        emitted: set[tuple[str, str]] = set()
        for block_match in self._POETRY_BLOCK.finditer(file.content):
            block = block_match.group(1)
            name_m = self._POETRY_NAME.search(block)
            ver_m = self._POETRY_VERSION.search(block)
            if not name_m or not ver_m:
                continue
            pkg = name_m.group(1).lower()
            version = ver_m.group(1)
            key = (pkg, version)
            if key in emitted:
                continue
            emitted.add(key)
            line_no = file.content.count("\n", 0, block_match.start()) + 1
            yield from self._match_advisories(
                "pypi", pkg, f"=={version}",
                file, line_no, f'  name = "{pkg}", version = "{version}"',
            )

    def _match_advisories(
        self, ecosystem: str, pkg: str, declared_spec: str,
        file: FileContext, line_no: int, snippet_line: str,
    ) -> Iterable[Finding]:
        for adv in ADVISORIES:
            if adv.ecosystem != ecosystem or adv.package.lower() != pkg:
                continue
            if not _declared_overlaps_vuln(declared_spec, adv.vulnerable):
                continue
            yield Finding(
                rule_id=f"DEP-{adv.cve}",
                title=f"Vulnerable dependency: {adv.package} ({adv.cve})",
                severity=adv.severity,
                category="dependency",
                file_path=file.relative_path,
                line_number=line_no,
                code_snippet=snippet_line,
                description=(
                    f"{adv.title}. Declared range '{declared_spec or 'any'}' "
                    f"includes versions matching the vulnerable range '{adv.vulnerable}'."
                ),
                recommendation=adv.recommendation,
                confidence=Confidence.HIGH,
                cwe=None,
                needs_review=False,
            )


def _npm_to_pep440(spec: str) -> str:
    """Best-effort conversion of an npm version range to a PEP 440 specifier."""
    s = spec.strip()
    if not s or s in {"*", "latest"}:
        return ""
    # Strip leading ^ or ~ — treat as "this exact major/minor or higher".
    if s.startswith("^") or s.startswith("~"):
        s = s[1:]
        # Conservative: treat as ">=" of the pinned base.
        return f">={s}"
    if s[0] in "<>=":
        return s
    # Plain version pin "1.2.3"
    return f"=={s}"


def _declared_overlaps_vuln(declared: str, vulnerable: str) -> bool:
    """Return True if the declared range can resolve to a vulnerable version.

    Strategy: try a representative set of candidate versions and return True
    if any satisfies both specs. Candidates are derived from both ranges so a
    pinned declared version (e.g. ==5.3.1) is included. Conservative: when
    parse fails on the declared side, we flag.
    """
    try:
        vuln_spec = SpecifierSet(vulnerable)
    except Exception:
        return False
    try:
        decl_spec = SpecifierSet(declared) if declared else SpecifierSet("")
    except Exception:
        return True   # unparseable declared spec — be conservative

    candidates = _candidates_from_spec(vuln_spec) + _candidates_from_spec(decl_spec)
    for candidate in candidates:
        try:
            v = Version(candidate)
        except InvalidVersion:
            continue
        if v in vuln_spec and v in decl_spec:
            return True
    return False


def _candidates_from_spec(spec: SpecifierSet) -> list[str]:
    """Generate candidate versions from a SpecifierSet.

    For each specifier, we add its pinned version, a slightly-lower variant
    (handles strict-less-than), and several common majors so range overlap
    detection works for ranges like '<5.4' against declared '==5.3.1'.
    """
    out: list[str] = ["0.0.1", "0.1.0", "0.5.0", "1.0.0", "2.0.0", "3.0.0", "4.0.0", "5.0.0", "6.0.0"]
    for s in spec:
        v = s.version
        out.append(v)
        try:
            base = Version(v)
            # Synthesize a "just below" version for < / <= specs.
            if base.micro > 0:
                out.append(f"{base.major}.{base.minor}.{base.micro - 1}")
            elif base.minor > 0:
                out.append(f"{base.major}.{base.minor - 1}.99")
            elif base.major > 0:
                out.append(f"{base.major - 1}.99.99")
            out.append(f"{base.major}.{base.minor}.0")
        except InvalidVersion:
            pass
    return out


def _name_from_lock_path(path: str) -> str | None:
    """Extract package name from a package-lock.json v2 'packages' key.

    Keys look like 'node_modules/lodash' or 'node_modules/foo/node_modules/bar'.
    The package name is the segment after the last 'node_modules/'.
    Scoped packages keep their @scope prefix.
    """
    if "node_modules/" not in path:
        return None
    tail = path.rsplit("node_modules/", 1)[-1]
    if not tail:
        return None
    # Scoped package: @scope/name
    if tail.startswith("@"):
        parts = tail.split("/", 2)
        if len(parts) >= 2:
            return f"{parts[0]}/{parts[1]}"
    return tail.split("/", 1)[0]
