"""Pattern-based analyzer.

Walks each line of a file, applies all loaded regex rules whose
language list matches, and emits a Finding per match.

Accuracy improvements over the basic version:
  * Skips matches that fall inside single-line comments (e.g. `# eval(x)`)
  * Skips matches in lines suppressed by inline `# vulnscan: ignore` directives
  * Downgrades confidence for findings inside test files (often fixtures)

Limitations: this is still regex-based, so it cannot:
  * Tell whether a value reaching a sink is user-controlled
  * Recognize comment markers inside string literals as non-comments
  * Understand multi-line constructs (e.g. heredocs, block comments mid-line)
"""
from __future__ import annotations
from collections.abc import Iterable

from vulnscan._core.analyzers.base import Analyzer
from vulnscan._core.rules.loader import load_rules, PatternRule
from vulnscan._core.scanner.comments import is_in_line_comment
from vulnscan._core.scanner.suppression import SuppressionMap, parse as parse_suppression
from vulnscan._core.scanner.types import Confidence, Finding, FileContext


# Path components that strongly suggest test code where
# "findings" are usually intentional fixtures or examples.
_TEST_PATH_HINTS = ("/test/", "/tests/", "/__tests__/", "/spec/",
                    "test_", "_test.", ".test.", ".spec.")


def _looks_like_test(path: str) -> bool:
    p = path.lower().replace("\\", "/")
    if not p.startswith("/"):
        p = "/" + p
    return any(h in p for h in _TEST_PATH_HINTS)


def _downgrade(confidence: Confidence) -> Confidence:
    return {
        Confidence.HIGH: Confidence.MEDIUM,
        Confidence.MEDIUM: Confidence.LOW,
        Confidence.LOW: Confidence.LOW,
    }[confidence]


class PatternAnalyzer(Analyzer):
    name = "pattern"
    description = "Regex-based detection of common vulnerability patterns."

    def __init__(self) -> None:
        self._rules: list[PatternRule] = load_rules()
        # For each rule that ALSO has an AST query AND a grammar exists
        # for the language, record those rule+language combos. The regex
        # analyzer skips them to avoid double-flagging.
        #
        # Critical: we filter on grammars that ACTUALLY load. If a rule
        # claims `languages: [python, java]` in its AST section but no
        # Java grammar is wired up, we must STILL run the regex on Java
        # files — otherwise MD5 in a Java file would be silently missed.
        from vulnscan._core.rules.loader import load_ast_rules
        from vulnscan._core.analyzers.ast_analyzer import _grammar_for, _tree_sitter_available
        self._ast_rule_langs: dict[str, set[str]] = {}
        if _tree_sitter_available():
            for ar in load_ast_rules():
                covered = {lang for lang in ar.languages
                           if _grammar_for(lang) is not None}
                if covered:
                    self._ast_rule_langs[ar.id] = covered

    def analyze(self, file: FileContext) -> Iterable[Finding]:
        if not file.content:
            return
        suppressions: SuppressionMap = parse_suppression(file.content)
        if suppressions.file_ignored:
            return

        is_test = _looks_like_test(file.relative_path)

        for rule in self._rules:
            if rule.languages and file.language not in rule.languages:
                continue
            # If an AST rule with the same id covers this file's language,
            # skip the regex version — AST is more accurate.
            if file.language in self._ast_rule_langs.get(rule.id, set()):
                continue
            for match in rule.pattern.finditer(file.content):
                start = match.start()
                line_no = file.content.count("\n", 0, start) + 1
                line_start = file.content.rfind("\n", 0, start) + 1
                col = start - line_start
                line_text = file.lines[line_no - 1] if line_no - 1 < len(file.lines) else ""

                # Skip matches inside single-line comments.
                if is_in_line_comment(line_text, col, file.language):
                    continue

                # Skip if user opted out via inline directive.
                if suppressions.is_suppressed(line_no, rule.id):
                    continue

                snippet = _snippet(file.lines, line_no, context=2)

                # In test files, drop confidence one notch and force review.
                confidence = rule.confidence
                needs_review = rule.needs_review
                if is_test:
                    confidence = _downgrade(confidence)
                    needs_review = True

                yield Finding(
                    rule_id=rule.id,
                    title=rule.title,
                    severity=rule.severity,
                    category=rule.category,
                    file_path=file.relative_path,
                    line_number=line_no,
                    code_snippet=snippet,
                    description=rule.description,
                    recommendation=rule.recommendation,
                    confidence=confidence,
                    cwe=rule.cwe,
                    needs_review=needs_review,
                )


def _snippet(lines: list[str], line_no: int, context: int = 2) -> str:
    """Return a few lines of context around line_no (1-indexed)."""
    if not lines:
        return ""
    start = max(0, line_no - 1 - context)
    end = min(len(lines), line_no + context)
    out = []
    for i in range(start, end):
        marker = ">" if i + 1 == line_no else " "
        out.append(f"{marker} {i + 1:4d} | {lines[i]}")
    return "\n".join(out)
