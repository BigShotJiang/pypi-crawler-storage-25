"""Entropy-based secret detection.

Pattern matching catches known formats (AKIA..., -----BEGIN PRIV KEY-----).
This analyzer catches the rest: arbitrary high-entropy strings assigned
to variables that *look* like secrets. Marked needs_review=True because
false positives are inevitable (e.g. base64 fixtures in tests).
"""
from __future__ import annotations
import math
import re
from collections.abc import Iterable

from vulnscan._core.analyzers.base import Analyzer
from vulnscan._core.scanner.types import Finding, FileContext, Severity, Confidence

# variable name hints that suggest a secret
_SECRETY_NAME = re.compile(
    r'(?i)\b(secret|password|passwd|pwd|token|api[_-]?key|access[_-]?key|'
    r'auth[_-]?token|private[_-]?key|client[_-]?secret)\b'
)
# assigned string literal capture
_ASSIGN = re.compile(
    r'''(?P<name>[A-Za-z_][A-Za-z0-9_]*)\s*[:=]\s*['"](?P<val>[^'"\s]{20,200})['"]'''
)

_SHANNON_THRESHOLD = 4.0   # bits/char
_MIN_LEN = 24


def _entropy(s: str) -> float:
    if not s:
        return 0.0
    counts: dict[str, int] = {}
    for c in s:
        counts[c] = counts.get(c, 0) + 1
    n = len(s)
    return -sum((c / n) * math.log2(c / n) for c in counts.values())


# Strings that look high-entropy but aren't secrets
_DENYLIST_PATTERNS = [
    re.compile(r'^https?://'),       # URLs
    re.compile(r'^[a-f0-9]{32}$'),   # plain MD5 (often test fixture)
    re.compile(r'^/[A-Za-z0-9_/.-]+$'),  # paths
]


_LOCKFILE_NAMES = {
    "package-lock.json", "yarn.lock", "poetry.lock", "Pipfile.lock",
    "Cargo.lock", "Gemfile.lock", "composer.lock", "go.sum",
}
_MANIFEST_NAMES = {"package.json", "requirements.txt", "Pipfile", "pyproject.toml"}


class SecretsAnalyzer(Analyzer):
    name = "secrets"
    description = "High-entropy string detection for unknown-format secrets."

    def supports(self, file: FileContext) -> bool:
        # Lock and manifest files are full of long version pins and integrity
        # hashes that look high-entropy. We rely on the dependency analyzer
        # for those files instead.
        name = file.relative_path.split("/")[-1]
        if name in _LOCKFILE_NAMES or name in _MANIFEST_NAMES:
            return False
        return True

    def analyze(self, file: FileContext) -> Iterable[Finding]:
        if not file.content:
            return
        for line_idx, line in enumerate(file.lines, start=1):
            if len(line) > 500:           # skip minified/giant lines
                continue
            for m in _ASSIGN.finditer(line):
                name = m.group("name")
                val = m.group("val")
                if len(val) < _MIN_LEN:
                    continue
                if not _SECRETY_NAME.search(name):
                    continue
                if any(p.search(val) for p in _DENYLIST_PATTERNS):
                    continue
                if _entropy(val) < _SHANNON_THRESHOLD:
                    continue
                yield Finding(
                    rule_id="SECRET-ENTROPY",
                    title=f"High-entropy string assigned to '{name}'",
                    severity=Severity.HIGH,
                    category="secret",
                    file_path=file.relative_path,
                    line_number=line_idx,
                    code_snippet=_ctx(file.lines, line_idx),
                    description=(
                        f"Variable '{name}' is assigned a high-entropy string "
                        f"({len(val)} chars). This often indicates a hardcoded "
                        "credential, but may be a hash, token fixture, or random ID."
                    ),
                    recommendation=(
                        "If this is a real secret, move it to an environment "
                        "variable or secrets manager and rotate it. If it is "
                        "test data, mark the file or line to suppress this check."
                    ),
                    confidence=Confidence.MEDIUM,
                    cwe="CWE-798",
                    needs_review=True,
                )


def _ctx(lines: list[str], line_no: int, context: int = 2) -> str:
    if not lines:
        return ""
    start = max(0, line_no - 1 - context)
    end = min(len(lines), line_no + context)
    out = []
    for i in range(start, end):
        marker = ">" if i + 1 == line_no else " "
        out.append(f"{marker} {i + 1:4d} | {lines[i]}")
    return "\n".join(out)
