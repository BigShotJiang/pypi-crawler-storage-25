"""Base class for all analyzers.

An analyzer scans a single file and yields findings. Analyzers should
be stateless and side-effect free so they can be parallelized safely.
"""
from __future__ import annotations
from abc import ABC, abstractmethod
from collections.abc import Iterable

from vulnscan._core.scanner.types import Finding, FileContext


class Analyzer(ABC):
    """Base analyzer interface."""

    name: str = "base"
    description: str = ""
    # If non-empty, only files matching these languages are analyzed.
    # An empty tuple means "all files".
    languages: tuple[str, ...] = ()

    def supports(self, file: FileContext) -> bool:
        if not self.languages:
            return True
        return file.language in self.languages

    @abstractmethod
    def analyze(self, file: FileContext) -> Iterable[Finding]:
        """Yield findings for this file."""
        raise NotImplementedError
