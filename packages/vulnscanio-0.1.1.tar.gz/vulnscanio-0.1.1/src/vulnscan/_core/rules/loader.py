"""Loads YAML rules into typed objects.

Rules come in two flavors:

  * Regex rules:   `pattern:` field, language-agnostic
  * AST rules:     `query:` field, requires a tree-sitter grammar for
                   the rule's `languages:`

A rule may have either or both. When both are present, the AST rule
takes priority for files in `languages` that have a tree-sitter
grammar; the regex rule is the fallback for files in other languages.

This dual-loader exists so we can migrate rules from regex to AST one
at a time without breaking anything. Phase 4 starts the migration; over
time, `pattern:` becomes the exception (used only for non-grammar
languages and very simple rules) and `query:` becomes the norm.
"""
from __future__ import annotations
import re
from dataclasses import dataclass
from functools import lru_cache
from pathlib import Path
from typing import Pattern
from importlib.resources import files
import yaml

from vulnscan._core.scanner.types import Severity, Confidence

from vulnscan._core.scanner.types import Severity, Confidence

_RULES_PACKAGE = "vulnscan._core.rules"
@dataclass
class PatternRule:
    """A regex rule. Language-agnostic; matches against raw file content."""
    id: str
    title: str
    category: str
    severity: Severity
    confidence: Confidence
    pattern: Pattern[str]
    description: str
    recommendation: str
    languages: tuple[str, ...] = ()
    cwe: str | None = None
    needs_review: bool = False


@dataclass
class AstRule:
    """A tree-sitter AST rule. Requires a grammar for one of its languages.

    `queries` is a dict mapping language name → S-expression query string.
    Each language gets its own query because tree-sitter node types are
    grammar-specific (Python's `call` ≠ JS's `call_expression`).

    YAML schema (two equivalent forms):

        query: |              # single query, applied to ALL languages
          (call ...) @match   # in `languages:` (only useful when same
                              # node names work across grammars; rare)

        queries:              # per-language queries
          python: |
            (call ...) @match
          javascript: |
            (call_expression ...) @match

    The capture name "@match" is the canonical location reported as the
    finding's line number; if absent, the first capture is used.
    """
    id: str
    title: str
    category: str
    severity: Severity
    confidence: Confidence
    queries: dict[str, str]    # language → query string
    description: str
    recommendation: str
    languages: tuple[str, ...] = ()
    cwe: str | None = None
    needs_review: bool = False


_RULES_FILE = Path(__file__).parent / "patterns.yml"

from importlib.resources import files

_RULES_PACKAGE = "vulnscan._core.rules"

def _read_rules():
    return (files(_RULES_PACKAGE) / "patterns.yml").read_text()
@lru_cache(maxsize=1)
def load_rules() -> list[PatternRule]:
    """Load only the regex (pattern:) rules.

    AST rules are returned by load_ast_rules() instead so the regex
    analyzer never sees them. A rule with both pattern: and query:
    fields is loaded by both — the AST analyzer will fire on grammar-
    backed languages, the regex on others.
    """
    raw = yaml.safe_load(_RULES_FILE.read_text(encoding="utf-8"))
    rules: list[PatternRule] = []
    for r in raw.get("rules", []):
        if "pattern" not in r:
            continue   # AST-only rule; skip
        try:
            # MULTILINE so ^ and $ anchors match per-line. This matches
            # the line-oriented mental model rule authors use; without it,
            # `^FROM` would only match the very first line of a file.
            compiled = re.compile(r["pattern"], re.MULTILINE)
        except re.error as e:
            raise ValueError(f"Invalid regex in rule {r.get('id')}: {e}") from e
        rules.append(
            PatternRule(
                id=r["id"],
                title=r["title"],
                category=r["category"],
                severity=Severity(r["severity"]),
                confidence=Confidence(r.get("confidence", "medium")),
                pattern=compiled,
                description=r["description"],
                recommendation=r["recommendation"],
                languages=tuple(r.get("languages") or ()),
                cwe=r.get("cwe"),
                needs_review=bool(r.get("needs_review", False)),
            )
        )
    return rules


@lru_cache(maxsize=1)
def load_ast_rules() -> list[AstRule]:
    """Load only the AST rules. Used by AstAnalyzer.

    Accepts two YAML forms:

      `query: <string>` — one query applied to every language in
                          `languages:`. Useful only when the node
                          types are identical across grammars (rare;
                          most rules need per-language queries).

      `queries: {lang: <string>}` — per-language query strings.
                                    Required when grammars differ
                                    (e.g. Python `call` vs JS `call_expression`).
    """
    raw = yaml.safe_load(_RULES_FILE.read_text(encoding="utf-8"))
    rules: list[AstRule] = []
    for r in raw.get("rules", []):
        # Build the per-language query dict
        queries: dict[str, str] = {}
        if "queries" in r and isinstance(r["queries"], dict):
            queries = {lang: q for lang, q in r["queries"].items()}
        elif "query" in r:
            # Apply the same query to every listed language
            single = r["query"]
            for lang in r.get("languages") or ():
                queries[lang] = single
        else:
            continue   # not an AST rule

        if not queries:
            continue

        rules.append(
            AstRule(
                id=r["id"],
                title=r["title"],
                category=r["category"],
                severity=Severity(r["severity"]),
                confidence=Confidence(r.get("confidence", "medium")),
                queries=queries,
                description=r["description"],
                recommendation=r["recommendation"],
                languages=tuple(queries.keys()),
                cwe=r.get("cwe"),
                needs_review=bool(r.get("needs_review", False)),
            )
        )
    return rules


def ast_rule_ids() -> set[str]:
    """Returns rule_ids that are handled by the AST analyzer.

    The PatternAnalyzer skips these rules for files in matching
    languages so we don't double-flag the same vulnerability.
    """
    return {r.id for r in load_ast_rules()}
