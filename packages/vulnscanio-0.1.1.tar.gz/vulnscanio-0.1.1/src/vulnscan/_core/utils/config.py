"""Application configuration.

Uses pydantic-settings when available (the server's normal path: it
also loads .env files automatically). Falls back to a plain dataclass
that reads the same environment variables when pydantic-settings is
not installed — this keeps the CLI dependency-light.

Both code paths produce a `settings` object with the same fields and
the same defaults.
"""
from __future__ import annotations
import os
from pathlib import Path

try:
    from pydantic_settings import BaseSettings, SettingsConfigDict

    class _Settings(BaseSettings):
        model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8", extra="ignore")

        app_name: str = "VulnScan"
        app_version: str = "1.0.0"
        debug: bool = False

        # Storage
        data_dir: Path = Path("./data")
        repos_dir: Path = Path("./data/repos")
        db_url: str = "sqlite+aiosqlite:///./data/vulnscan.db"

        # Security
        secret_key: str = "change-me-in-production-use-secrets-token-urlsafe-32"
        api_key: str = "dev-api-key-change-in-production"

        # Scan limits
        max_repo_size_mb: int = 500
        max_file_size_kb: int = 1024
        scan_timeout_seconds: int = 600
        max_concurrent_scans: int = 3

        # CORS
        cors_origins: list[str] = ["http://localhost:5173", "http://localhost:3000"]

        def ensure_dirs(self) -> None:
            self.data_dir.mkdir(parents=True, exist_ok=True)
            self.repos_dir.mkdir(parents=True, exist_ok=True)

    settings: _Settings = _Settings()

except ImportError:
    # ---- Stdlib fallback for the CLI ----
    # Reads env vars directly. Doesn't load .env files (the CLI doesn't
    # need them). Same field names so callers don't change.
    from dataclasses import dataclass, field

    def _env(name: str, default: str) -> str:
        return os.environ.get(name.upper(), default)

    def _env_int(name: str, default: int) -> int:
        try:
            return int(os.environ.get(name.upper(), str(default)))
        except ValueError:
            return default

    def _env_bool(name: str, default: bool) -> bool:
        raw = os.environ.get(name.upper(), "")
        if not raw:
            return default
        return raw.lower() in ("1", "true", "yes", "on")

    @dataclass
    class _SettingsFallback:
        app_name: str = "VulnScan"
        app_version: str = "1.0.0"
        debug: bool = False
        data_dir: Path = field(default_factory=lambda: Path("./data"))
        repos_dir: Path = field(default_factory=lambda: Path("./data/repos"))
        db_url: str = "sqlite+aiosqlite:///./data/vulnscan.db"
        secret_key: str = "change-me-in-production-use-secrets-token-urlsafe-32"
        api_key: str = "dev-api-key-change-in-production"
        max_repo_size_mb: int = 500
        max_file_size_kb: int = 1024
        scan_timeout_seconds: int = 600
        max_concurrent_scans: int = 3
        cors_origins: list = field(default_factory=lambda: ["http://localhost:5173", "http://localhost:3000"])

        def ensure_dirs(self) -> None:
            # Best-effort; CLI runs may not have write access to cwd.
            try:
                self.data_dir.mkdir(parents=True, exist_ok=True)
                self.repos_dir.mkdir(parents=True, exist_ok=True)
            except OSError:
                pass

    settings = _SettingsFallback(
        app_name=_env("app_name", "VulnScan"),
        app_version=_env("app_version", "1.0.0"),
        debug=_env_bool("debug", False),
        data_dir=Path(_env("data_dir", "./data")),
        repos_dir=Path(_env("repos_dir", "./data/repos")),
        db_url=_env("db_url", "sqlite+aiosqlite:///./data/vulnscan.db"),
        secret_key=_env("secret_key", "change-me-in-production-use-secrets-token-urlsafe-32"),
        api_key=_env("api_key", "dev-api-key-change-in-production"),
        max_repo_size_mb=_env_int("max_repo_size_mb", 500),
        max_file_size_kb=_env_int("max_file_size_kb", 1024),
        scan_timeout_seconds=_env_int("scan_timeout_seconds", 600),
        max_concurrent_scans=_env_int("max_concurrent_scans", 3),
    )
