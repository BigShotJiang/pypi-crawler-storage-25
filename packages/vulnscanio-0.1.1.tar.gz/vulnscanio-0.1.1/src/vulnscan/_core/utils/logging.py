"""Centralized logging.

Uses loguru when available (better colors, structured output) and
falls back to stdlib logging when not. This keeps the CLI install
dependency-light: the server's `requirements.txt` declares loguru,
but the CLI's `pyproject.toml` does not need to.

The exported `logger` object exposes the methods used in this codebase:
  info, warning, error, exception
That's the entire surface area we depend on. Both backends provide it.
"""
from __future__ import annotations

try:
    from loguru import logger as _loguru_logger
    import sys as _sys
    _loguru_logger.remove()
    _loguru_logger.add(
        _sys.stderr,
        format=(
            "<green>{time:YYYY-MM-DD HH:mm:ss}</green> | "
            "<level>{level: <8}</level> | "
            "<cyan>{name}</cyan>:<cyan>{function}</cyan>:<cyan>{line}</cyan> - "
            "<level>{message}</level>"
        ),
        level="INFO",
    )
    logger = _loguru_logger
except ImportError:
    # stdlib fallback for environments (CLI) that don't ship loguru.
    import logging as _logging
    _logging.basicConfig(
        level=_logging.WARNING,  # CLI: stay quiet unless something is wrong
        format="%(asctime)s | %(levelname)-8s | %(name)s - %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )
    logger = _logging.getLogger("vulnscan")

__all__ = ["logger"]
