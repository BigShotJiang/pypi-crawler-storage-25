"""Scan orchestrator: walks repo, runs analyzers, deduplicates findings.

Phase 3 added two optimizations:

  1. Hash-based incremental cache. Files whose content+rules haven't
     changed return cached findings instantly. The cache lives at
     `<repo>/.vulnscan/cache.db` and is keyed on (file_hash, rules_hash).
     This is what turns a 30-second scan of a 1000-file repo into a
     2-second scan when only 3 files changed.

  2. ProcessPoolExecutor for the cache-miss path. Analyzer regex work
     is CPU-bound; threads can't help (GIL). Process workers can run
     in parallel and roughly linearly reduce scan time on multi-core
     machines.

Correctness rule for the cache: a hit must NEVER produce a wrong
result, only a slow one. The cache is a strict optimization. If the
hash key matches, the cached findings are exactly what re-analysis
would produce. test_cache_never_lies covers this property explicitly.
"""
from __future__ import annotations
import os
from collections.abc import Callable
from concurrent.futures import ProcessPoolExecutor
from dataclasses import dataclass
from pathlib import Path

from vulnscan._core.analyzers.ast_analyzer import AstAnalyzer
from vulnscan._core.analyzers.base import Analyzer
from vulnscan._core.analyzers.dependency_analyzer import DependencyAnalyzer
from vulnscan._core.analyzers.pattern_analyzer import PatternAnalyzer
from vulnscan._core.analyzers.secrets_analyzer import SecretsAnalyzer
from vulnscan._core.scanner.cache import ScanCache, hash_file, hash_rules
from vulnscan._core.scanner.types import Finding, FileContext
from vulnscan._core.scanner.walker import walk_repo
from vulnscan._core.utils.logging import logger


@dataclass
class ScanResult:
    findings: list[Finding]
    files_scanned: int
    files_skipped: list[tuple[str, str]] = None  # (path, reason)
    cache_hits: int = 0     # files whose findings came from the cache
    cache_misses: int = 0   # files that were re-analyzed

    def __post_init__(self):
        if self.files_skipped is None:
            self.files_skipped = []


ProgressCallback = Callable[[int, str], None]   # (percent 0..100, message)


def default_analyzers() -> list[Analyzer]:
    # AstAnalyzer first so AST findings come through cleanly; the
    # PatternAnalyzer skips AST-covered rule+language combinations.
    return [AstAnalyzer(), PatternAnalyzer(), SecretsAnalyzer(), DependencyAnalyzer()]


def run_scan(
    repo_root: Path,
    analyzers: list[Analyzer] | None = None,
    progress: ProgressCallback | None = None,
    *,
    use_cache: bool = True,
    max_workers: int | None = None,
) -> ScanResult:
    """Scan a repository.

    Parameters
    ----------
    use_cache:
        If True (the default), unchanged files (matched by content hash
        + rules hash) skip analysis and use cached findings. The cache
        lives at <repo_root>/.vulnscan/cache.db. Set to False in tests
        and benchmarks where you want to measure cold-path performance.
    max_workers:
        Number of parallel processes for the cache-miss path. Defaults
        to os.cpu_count(). Set to 1 to disable parallelism (e.g. for
        debugging or low-memory environments).
    """
    analyzers = analyzers or default_analyzers()
    skipped: list[tuple[str, str]] = []
    files = list(walk_repo(repo_root, on_skip=lambda p, r: skipped.append((p, r))))
    total = max(1, len(files))

    if progress:
        progress(0, f"Found {len(files)} files to analyze, {len(skipped)} skipped")
        if skipped:
            shown = skipped[:5]
            for path, reason in shown:
                progress(0, f"Skipped {path}: {reason}")
            if len(skipped) > len(shown):
                progress(0, f"... and {len(skipped) - len(shown)} more skipped files")

    cache: ScanCache | None = None
    rules_hash = ""
    if use_cache:
        try:
            cache = ScanCache(repo_root)
            rules_hash = hash_rules(_rules_dir())
        except (OSError, Exception) as e:
            # If the cache can't be opened (read-only fs, permission
            # error, etc.), fall back to no-cache. Slower but correct.
            logger.warning(f"cache disabled: {e}")
            cache = None

    findings: list[Finding] = []
    seen: set[tuple[str, str, int]] = set()
    cache_hits = 0
    miss_files: list[Path] = []
    miss_hashes: list[str] = []

    # Pass 1: hash every file and use cache when possible.
    # This is the FAST path. If everything's cached, we never start
    # a worker pool at all.
    for abs_path in files:
        if cache is None:
            miss_files.append(abs_path)
            miss_hashes.append("")
            continue
        fh = hash_file(abs_path)
        cached = cache.get(fh, rules_hash) if fh else None
        if cached is not None:
            cache_hits += 1
            # IMPORTANT: cached findings may have come from a DIFFERENT
            # file with identical content. Rewrite file_path to point
            # at THIS file so dedup keys are unique per file.
            try:
                rel = str(abs_path.relative_to(repo_root))
            except ValueError:
                rel = str(abs_path)
            for f in cached:
                if f.file_path != rel:
                    # Build a copy with corrected file_path
                    from dataclasses import replace
                    f = replace(f, file_path=rel)
                key = (f.rule_id, f.file_path, f.line_number)
                if key in seen:
                    continue
                seen.add(key)
                findings.append(f)
        else:
            miss_files.append(abs_path)
            miss_hashes.append(fh)

    # Pass 2: analyze cache-miss files (in parallel if more than a few).
    if miss_files:
        new_findings_per_file = _analyze_files(
            repo_root, miss_files, analyzers, progress=progress,
            base_offset=cache_hits, total=total, max_workers=max_workers,
        )
        # Cache the results, deduplicate, append.
        for path, fh, file_findings in zip(miss_files, miss_hashes, new_findings_per_file):
            if cache is not None and fh:
                cache.put(fh, rules_hash, file_findings)
            for f in file_findings:
                key = (f.rule_id, f.file_path, f.line_number)
                if key in seen:
                    continue
                seen.add(key)
                findings.append(f)

    # Vacuum opportunistically
    if cache is not None:
        try:
            cache.vacuum()
        except Exception:
            pass
        cache.close()

    if progress:
        progress(100,
                 f"Scan complete: {len(findings)} findings, "
                 f"{len(files)} files scanned ({cache_hits} cached), "
                 f"{len(skipped)} skipped")

    return ScanResult(
        findings=findings,
        files_scanned=len(files),
        files_skipped=skipped,
        cache_hits=cache_hits,
        cache_misses=len(miss_files),
    )


# ----------------------------------------------------------------------
# Cache-miss analysis path (with optional parallelism)
# ----------------------------------------------------------------------

def _analyze_files(
    repo_root: Path,
    files: list[Path],
    analyzers: list[Analyzer],
    *,
    progress: ProgressCallback | None = None,
    base_offset: int = 0,
    total: int = 0,
    max_workers: int | None = None,
) -> list[list[Finding]]:
    """Analyze each file; return findings grouped per-file in input order.

    Parallelizes via ProcessPoolExecutor when the workload is large
    enough to amortize fork+import overhead. For small batches (<8
    files) we stay serial — overhead wins.
    """
    workers = max_workers if max_workers is not None else (os.cpu_count() or 1)

    # ProcessPoolExecutor has substantial startup cost on Python:
    # ~100ms per worker for module imports, plus pickling overhead per
    # file. For small or medium workloads, serial wins. Only flip to
    # parallel when the workload is large enough to amortize fork+
    # import overhead. Empirically, 200+ files is the break-even.
    SERIAL_THRESHOLD = 200
    if workers <= 1 or len(files) < SERIAL_THRESHOLD:
        return _analyze_serial(
            repo_root, files, analyzers,
            progress=progress, base_offset=base_offset, total=total,
        )
    return _analyze_parallel(
        repo_root, files, analyzers, workers=workers,
        progress=progress, base_offset=base_offset, total=total,
    )


def _analyze_serial(
    repo_root: Path, files: list[Path], analyzers: list[Analyzer],
    *, progress, base_offset, total,
) -> list[list[Finding]]:
    out: list[list[Finding]] = []
    for i, abs_path in enumerate(files, start=1):
        out.append(_analyze_one(repo_root, abs_path, analyzers))
        if progress and (i % 10 == 0 or i == len(files)):
            done = base_offset + i
            pct = int(done * 100 / max(1, total))
            progress(pct, f"Scanned {done}/{total} files")
    return out


def _analyze_parallel(
    repo_root: Path, files: list[Path], analyzers: list[Analyzer],
    *, workers: int, progress, base_offset, total,
) -> list[list[Finding]]:
    """Run _analyze_one in a process pool.

    We pass `analyzers=None` to the worker so it constructs its own
    default analyzers. Pickling user-provided analyzers gets dicey
    because pattern_analyzer holds compiled regexes; better to let
    each worker re-construct them. Cost is ~50ms one-time per worker.
    """
    out: list[list[Finding]] = [[] for _ in files]
    args = [(repo_root, p) for p in files]
    completed = 0
    # Chunksize: give each worker a healthy batch so per-task pickling
    # overhead is amortized. At ~50 files/chunk and ~10ms/file we get
    # ~500ms per worker round-trip — matching pool startup cost.
    chunksize = max(20, len(files) // (workers * 4))
    with ProcessPoolExecutor(max_workers=workers) as pool:
        for idx, result in enumerate(pool.map(_analyze_worker, args, chunksize=chunksize)):
            out[idx] = result
            completed += 1
            if progress and (completed % 50 == 0 or completed == len(files)):
                done = base_offset + completed
                pct = int(done * 100 / max(1, total))
                progress(pct, f"Scanned {done}/{total} files")
    return out


def _analyze_worker(args: tuple[Path, Path]) -> list[Finding]:
    """Top-level so it's picklable. Reconstructs analyzers per worker."""
    repo_root, abs_path = args
    return _analyze_one(repo_root, abs_path, default_analyzers())


def _analyze_one(repo_root: Path, abs_path: Path, analyzers: list[Analyzer]) -> list[Finding]:
    """Run all analyzers on one file; return its findings (no dedup yet)."""
    out: list[Finding] = []
    try:
        ctx = FileContext.from_path(repo_root, abs_path)
    except Exception as e:
        logger.warning(f"failed to read {abs_path}: {e}")
        return out
    for analyzer in analyzers:
        if not analyzer.supports(ctx):
            continue
        try:
            for finding in analyzer.analyze(ctx):
                out.append(finding)
        except Exception as e:
            logger.exception(f"Analyzer {analyzer.name} failed on {ctx.relative_path}: {e}")
    return out


# ----------------------------------------------------------------------
# Helpers
# ----------------------------------------------------------------------

def _rules_dir() -> Path:
    """Locate the rules directory. Used for hashing into the cache key."""
    # rules/ is a sibling of scanner/
    return Path(__file__).resolve().parent.parent / "rules"


# ----------------------------------------------------------------------
from importlib.resources import files

_RULES_PACKAGE = "vulnscan._core.rules"

def _rules_files():
    return files(_RULES_PACKAGE)
