"""Inline suppression handling.

Two forms are supported, anywhere in a comment on the same line as a finding,
or on the immediately preceding line:

    # vulnscan: ignore                  -> suppresses any finding on that line
    # vulnscan: ignore RULE-ID          -> suppresses only that rule
    # vulnscan: ignore RULE-A,RULE-B    -> suppresses multiple rules

File-level suppressions placed near the top of the file:

    # vulnscan: ignore-file             -> skip this file entirely

Limitation: this is a textual mechanism, not semantic. It cannot tell whether
the comment is on the offending statement or somewhere unrelated. Keep
suppressions tight: one per line, immediately above the line being ignored.
"""
from __future__ import annotations
import re
from dataclasses import dataclass

# Match either # or // or -- style comments.
_SUPPRESS = re.compile(
    r"(?:#|//|--)\s*vulnscan:\s*ignore(?:-file)?(?:\s+([A-Z0-9_,\-\s]+))?",
    re.IGNORECASE,
)
_FILE_SUPPRESS = re.compile(r"(?:#|//|--)\s*vulnscan:\s*ignore-file\b", re.IGNORECASE)


@dataclass
class SuppressionMap:
    """Pre-computed suppression directives for a single file."""
    file_ignored: bool
    # line number -> set of rule IDs to suppress on that line.
    # An empty set means "suppress all rules on this line".
    by_line: dict[int, set[str]]

    def is_suppressed(self, line_number: int, rule_id: str) -> bool:
        if self.file_ignored:
            return True
        ignored = self.by_line.get(line_number)
        if ignored is None:
            return False
        if not ignored:        # empty set = ignore-all
            return True
        return rule_id in ignored


def parse(content: str) -> SuppressionMap:
    """Build a SuppressionMap by scanning the file's lines once.

    Semantics:
    * A directive on the same line as code suppresses *that* line only.
    * A directive on a comment-only line (no code on it) suppresses the
      *next* line. This avoids accidentally suppressing the line below
      a trailing comment.
    """
    by_line: dict[int, set[str]] = {}
    next_line_directive: dict[int, set[str]] = {}
    file_ignored = False

    # Only consider ignore-file in the first 5 lines (typical header location).
    head = content.splitlines()[:5]
    if any(_FILE_SUPPRESS.search(ln) for ln in head):
        file_ignored = True

    for i, line in enumerate(content.splitlines(), start=1):
        if _FILE_SUPPRESS.search(line):
            continue
        m = _SUPPRESS.search(line)
        if not m:
            continue

        rule_list = m.group(1)
        if not rule_list or not rule_list.strip():
            ids: set[str] = set()
        else:
            ids = {r.strip().upper() for r in rule_list.split(",") if r.strip()}

        # Is this a comment-only line, or a trailing comment after code?
        before_comment = line[:m.start()].strip()
        is_comment_only = before_comment == "" or before_comment in ("#", "//", "--")

        if is_comment_only:
            # Apply to the *following* line.
            next_line_directive[i + 1] = ids
        else:
            # Apply to *this* line only.
            by_line[i] = ids

    # Merge: next-line directives may have collided with same-line ones; the
    # explicit same-line directive wins.
    for line, ids in next_line_directive.items():
        by_line.setdefault(line, ids)

    return SuppressionMap(file_ignored=file_ignored, by_line=by_line)
