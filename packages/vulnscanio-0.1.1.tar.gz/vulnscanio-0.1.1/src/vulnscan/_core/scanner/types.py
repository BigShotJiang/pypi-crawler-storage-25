"""Scanner core: data classes shared by analyzers and orchestrator.

These dataclasses are decoupled from the database layer so analyzers
can be unit-tested in isolation.
"""
from __future__ import annotations
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path


class Severity(str, Enum):
    CRITICAL = "critical"
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"
    INFO = "info"


class Confidence(str, Enum):
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"


@dataclass
class Finding:
    """A single vulnerability finding produced by an analyzer."""
    rule_id: str
    title: str
    severity: Severity
    category: str
    file_path: str            # relative to repo root
    line_number: int
    code_snippet: str
    description: str
    recommendation: str
    confidence: Confidence = Confidence.HIGH
    cwe: str | None = None
    line_end: int | None = None
    needs_review: bool = False


@dataclass
class FileContext:
    """A single file being analyzed."""
    relative_path: str
    absolute_path: Path
    content: str
    lines: list[str] = field(default_factory=list)
    language: str | None = None  # e.g. 'python', 'javascript'

    @classmethod
    def from_path(cls, repo_root: Path, abs_path: Path) -> "FileContext":
        try:
            text = abs_path.read_text(encoding="utf-8", errors="replace")
        except Exception:
            text = ""
        return cls(
            relative_path=str(abs_path.relative_to(repo_root)),
            absolute_path=abs_path,
            content=text,
            lines=text.splitlines(),
            language=_detect_language(abs_path),
        )


def _detect_language(path: Path) -> str | None:
    name = path.name
    name_lower = name.lower()

    # Special filenames
    if name == "Dockerfile" or name_lower.startswith("dockerfile."):
        return "dockerfile"
    if name == ".env" or name.startswith(".env.") or name_lower.endswith(".env"):
        return "dotenv"
    if name == "Makefile" or name_lower == "makefile":
        return "makefile"

    suffix = path.suffix.lower()
    return {
        ".py": "python",
        ".js": "javascript", ".jsx": "javascript",
        ".ts": "typescript", ".tsx": "typescript",
        ".java": "java",
        ".go": "go",
        ".rb": "ruby",
        ".php": "php",
        ".cs": "csharp",
        ".rs": "rust",
        ".c": "c", ".h": "c",
        ".cpp": "cpp", ".cc": "cpp", ".hpp": "cpp",
        ".html": "html", ".htm": "html",
        ".sql": "sql",
        ".sh": "shell", ".bash": "shell",
        ".yml": "yaml", ".yaml": "yaml",
        ".json": "json",
        ".xml": "xml",
        ".tf": "terraform", ".tfvars": "terraform",
    }.get(suffix)
