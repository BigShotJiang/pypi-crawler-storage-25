"""Incremental scan cache.

Stores `{(file_hash, rules_hash) → findings[]}` in a SQLite file at
`.vulnscan/cache.db` so subsequent scans can skip files whose content
hasn't changed and whose rules haven't changed.

Cache key design — both halves matter:

  * file_hash:   sha256 of the file's bytes. If the file changes, the
                 hash changes, and we get a miss → re-analyze.
  * rules_hash:  sha256 of all .yml files in the rules/ directory plus
                 a version string for analyzer code. If we ship a new
                 rule, the hash changes, every entry is invalidated
                 implicitly (the new key just doesn't exist in the
                 cache yet), and the next scan re-analyzes everything.

This is the "5-line change easy to forget" safety net. Without
rules_hash, a new rule would never fire on cached files until they
were edited. Catastrophic.

Cache hit = correct result, fast. Cache miss = correct result, slow.
A bug in cache lookup must NEVER produce a wrong result, only a slow
one. To enforce that, every cached entry is round-trip-tested against
re-analysis in the test suite (test_cache_never_lies).
"""
from __future__ import annotations
import hashlib
import json
import sqlite3
import threading
from collections.abc import Iterable
from dataclasses import asdict
from pathlib import Path

from vulnscan._core.scanner.types import Finding, Severity, Confidence


CACHE_DIR_NAME = ".vulnscan"
CACHE_FILE_NAME = "cache.db"

# Bumped when the cache schema changes incompatibly. Old cache files
# with a different version are silently dropped (we recreate them).
SCHEMA_VERSION = 1

# Bumped when analyzer logic changes in ways that should invalidate
# every existing cache, even if rule YAML hasn't changed (e.g. a fix
# to the SQL injection regex generator). This is the "hash the
# rules + analyzer code together" piece.
ANALYZER_VERSION = "1.0.0"

_LOCK = threading.Lock()    # serialize cache writes from the orchestrator


# ----------------------------------------------------------------------
# Hash helpers
# ----------------------------------------------------------------------

def hash_file(path: Path) -> str:
    """sha256 of a file's bytes, hex-encoded. Returns "" on read error.

    Uses streaming read so 100 MB files don't blow up RAM. We stop at
    a sane size cap before hashing — files we wouldn't scan anyway
    don't deserve hash time.
    """
    h = hashlib.sha256()
    try:
        with open(path, "rb") as f:
            while True:
                chunk = f.read(65536)
                if not chunk:
                    break
                h.update(chunk)
    except OSError:
        return ""
    return h.hexdigest()


def hash_rules(rules_dir: Path) -> str:
    """sha256 of every .yml file in rules_dir (sorted), plus ANALYZER_VERSION.

    Sorted so the result is stable regardless of filesystem listing order.
    Including ANALYZER_VERSION means we can invalidate every cache entry
    by bumping a constant — no surgery needed when analyzer behavior
    changes for non-rule reasons.
    """
    h = hashlib.sha256()
    h.update(ANALYZER_VERSION.encode())
    if rules_dir.exists():
        for p in sorted(rules_dir.rglob("*.yml")):
            try:
                h.update(p.read_bytes())
            except OSError:
                pass
        for p in sorted(rules_dir.rglob("*.yaml")):
            try:
                h.update(p.read_bytes())
            except OSError:
                pass
    return h.hexdigest()


# ----------------------------------------------------------------------
# Finding (de)serialization for the JSON column
# ----------------------------------------------------------------------

def _findings_to_json(findings: Iterable[Finding]) -> str:
    """Serialize a list of Finding objects to a JSON string."""
    out = []
    for f in findings:
        out.append({
            "rule_id":       f.rule_id,
            "title":         f.title,
            "severity":      f.severity.value,
            "category":      f.category,
            "cwe":           f.cwe,
            "file_path":     f.file_path,
            "line_number":   f.line_number,
            "line_end":      f.line_end,
            "code_snippet":  f.code_snippet,
            "description":   f.description,
            "recommendation": f.recommendation,
            "confidence":    f.confidence.value,
            "needs_review":  f.needs_review,
        })
    return json.dumps(out)


def _findings_from_json(text: str) -> list[Finding]:
    """Reverse of _findings_to_json."""
    raw = json.loads(text)
    out: list[Finding] = []
    for d in raw:
        out.append(Finding(
            rule_id=d["rule_id"], title=d["title"],
            severity=Severity(d["severity"]),
            category=d["category"], cwe=d.get("cwe"),
            file_path=d["file_path"], line_number=d["line_number"],
            line_end=d.get("line_end"),
            code_snippet=d.get("code_snippet", ""),
            description=d.get("description", ""),
            recommendation=d.get("recommendation", ""),
            confidence=Confidence(d.get("confidence", "medium")),
            needs_review=d.get("needs_review", False),
        ))
    return out


# ----------------------------------------------------------------------
# Cache class
# ----------------------------------------------------------------------

class ScanCache:
    """SQLite-backed cache of (file_hash, rules_hash) → findings.

    The DB lives at <repo_root>/.vulnscan/cache.db by default.

    Cache hit = correct result, fast. Cache miss = correct result, slow.
    A miss is always safe; a wrong hit is never safe.
    """

    def __init__(self, repo_root: Path, *, path_override: Path | None = None):
        self._repo_root = repo_root
        self._path = path_override or (repo_root / CACHE_DIR_NAME / CACHE_FILE_NAME)
        self._path.parent.mkdir(parents=True, exist_ok=True)
        self._conn = sqlite3.connect(self._path, check_same_thread=False)
        # WAL improves concurrent read while a worker writes.
        try:
            self._conn.execute("PRAGMA journal_mode=WAL")
        except sqlite3.OperationalError:
            pass
        self._init_schema()
        self._maybe_add_gitignore()

    # ---- schema ----

    def _init_schema(self) -> None:
        with self._conn:
            self._conn.execute("""
                CREATE TABLE IF NOT EXISTS meta (
                    key   TEXT PRIMARY KEY,
                    value TEXT NOT NULL
                )
            """)
            self._conn.execute("""
                CREATE TABLE IF NOT EXISTS findings_cache (
                    file_hash    TEXT NOT NULL,
                    rules_hash   TEXT NOT NULL,
                    findings_json TEXT NOT NULL,
                    accessed_at  REAL NOT NULL,
                    PRIMARY KEY (file_hash, rules_hash)
                )
            """)
        # Detect & blow away schema-mismatched caches
        cur = self._conn.execute(
            "SELECT value FROM meta WHERE key=?", ("schema_version",))
        row = cur.fetchone()
        if row is None:
            with self._conn:
                self._conn.execute(
                    "INSERT INTO meta (key, value) VALUES (?, ?)",
                    ("schema_version", str(SCHEMA_VERSION)))
        elif row[0] != str(SCHEMA_VERSION):
            self._reset()

    def _reset(self) -> None:
        with self._conn:
            self._conn.execute("DELETE FROM findings_cache")
            self._conn.execute(
                "INSERT OR REPLACE INTO meta (key, value) VALUES (?, ?)",
                ("schema_version", str(SCHEMA_VERSION)))

    # ---- core get/put ----

    def get(self, file_hash: str, rules_hash: str) -> list[Finding] | None:
        if not file_hash:
            return None
        cur = self._conn.execute(
            "SELECT findings_json FROM findings_cache "
            "WHERE file_hash=? AND rules_hash=?",
            (file_hash, rules_hash),
        )
        row = cur.fetchone()
        if row is None:
            return None
        # Note: we deliberately DON'T update accessed_at on every read.
        # That used to be the bottleneck — each read committed a write,
        # turning 50 hits into 82ms of fsync. accessed_at gets updated
        # on `put` (which is rare), and that's good enough for the LRU
        # vacuum policy (recently-written entries are likely to be read
        # next time too).
        return _findings_from_json(row[0])

    def put(self, file_hash: str, rules_hash: str, findings: list[Finding]) -> None:
        if not file_hash:
            return
        import time
        payload = _findings_to_json(findings)
        with _LOCK, self._conn:
            self._conn.execute(
                "INSERT OR REPLACE INTO findings_cache "
                "(file_hash, rules_hash, findings_json, accessed_at) "
                "VALUES (?, ?, ?, ?)",
                (file_hash, rules_hash, payload, time.time()),
            )

    # ---- maintenance ----

    def vacuum(self, max_entries: int = 50_000) -> int:
        """Drop the oldest entries if we have more than max_entries.

        Returns the number of rows deleted. Designed to be run cheaply
        at the end of a scan; keeps the cache size bounded over time.
        """
        cur = self._conn.execute("SELECT COUNT(*) FROM findings_cache")
        count = cur.fetchone()[0]
        if count <= max_entries:
            return 0
        excess = count - max_entries
        with _LOCK, self._conn:
            self._conn.execute("""
                DELETE FROM findings_cache
                WHERE rowid IN (
                    SELECT rowid FROM findings_cache
                    ORDER BY accessed_at ASC
                    LIMIT ?
                )
            """, (excess,))
        return excess

    def stats(self) -> dict:
        """For diagnostics / `vulnscan cache stats`."""
        cur = self._conn.execute("SELECT COUNT(*) FROM findings_cache")
        count = cur.fetchone()[0]
        size_bytes = self._path.stat().st_size if self._path.exists() else 0
        return {"entries": count, "size_bytes": size_bytes,
                "path": str(self._path)}

    def clear(self) -> None:
        with _LOCK, self._conn:
            self._conn.execute("DELETE FROM findings_cache")

    def close(self) -> None:
        try:
            self._conn.close()
        except sqlite3.Error:
            pass

    # ---- convenience ----

    def _maybe_add_gitignore(self) -> None:
        """Auto-add .vulnscan/ to .gitignore if not already present.

        Defensive: respect an existing gitignore, just append our line
        if it isn't there. Idempotent; safe to call every scan.
        """
        gi = self._repo_root / ".gitignore"
        marker = ".vulnscan/"
        try:
            existing = gi.read_text(encoding="utf-8") if gi.exists() else ""
        except OSError:
            return
        if marker in existing:
            return
        try:
            with open(gi, "a", encoding="utf-8") as f:
                if existing and not existing.endswith("\n"):
                    f.write("\n")
                f.write(f"# Added by vulnscan\n{marker}\n")
        except OSError:
            # Read-only repo etc.; not fatal
            pass

    # context manager
    def __enter__(self):
        return self

    def __exit__(self, *exc):
        self.close()
