"""Repository file walker.

Skips binaries, vendored code, and common build artifacts. Limits per
file size to prevent OOM on giant generated files.

A SkipCallback can be passed in to surface what was skipped and why,
so users can verify nothing important was missed.
"""
from __future__ import annotations
from collections.abc import Callable, Iterator
from pathlib import Path

from vulnscan._core.utils.config import settings

# Directories never scanned
IGNORE_DIRS = {
    ".git", ".hg", ".svn", "node_modules", ".venv", "venv", "env",
    "__pycache__", ".pytest_cache", ".mypy_cache", "dist", "build",
    "target", ".next", ".nuxt", ".cache", "vendor", ".idea", ".vscode",
    "coverage", ".tox",
    ".vulnscan",   # our own cache directory; scanning it would recursively flag cached findings
}

# Files never scanned by content (binaries, lockfiles too large to be useful)
IGNORE_EXTENSIONS = {
    ".png", ".jpg", ".jpeg", ".gif", ".bmp", ".ico", ".svg", ".webp",
    ".pdf", ".zip", ".gz", ".tar", ".7z", ".rar", ".bz2",
    ".exe", ".dll", ".so", ".dylib", ".bin", ".class", ".jar",
    ".pyc", ".pyo", ".o", ".a",
    ".mp3", ".mp4", ".wav", ".mov", ".avi",
    ".woff", ".woff2", ".ttf", ".eot", ".otf",
    ".min.js", ".min.css",
}

# Lockfiles we treat specially: scanned by the dependency analyzer for
# transitive vulnerable versions, but not by the pattern analyzer (which
# would produce noise on hash-like strings). Currently we still skip
# yarn.lock and Pipfile.lock because their formats are not yet supported.
IGNORE_FILES = {"yarn.lock", "Pipfile.lock", ".gitignore", ".gitattributes",
                ".dockerignore", ".editorconfig", ".prettierrc", ".eslintignore"}


SkipCallback = Callable[[str, str], None]   # (relative_path, reason)


def walk_repo(
    root: Path,
    on_skip: SkipCallback | None = None,
) -> Iterator[Path]:
    """Yield absolute paths of files worth scanning.

    If `on_skip` is provided, it is called for each file that was visible
    but rejected by the size or extension filter. Files inside ignored
    directories (.git, node_modules, etc.) are *not* reported here — there
    are typically too many to be useful.
    """
    max_bytes = settings.max_file_size_kb * 1024
    for path in root.rglob("*"):
        if not path.is_file():
            continue
        if any(part in IGNORE_DIRS for part in path.parts):
            continue
        rel = str(path.relative_to(root))

        if path.name in IGNORE_FILES:
            if on_skip:
                on_skip(rel, f"unsupported lockfile format ({path.name})")
            continue
        name_lower = path.name.lower()
        ext_match = next((ext for ext in IGNORE_EXTENSIONS if name_lower.endswith(ext)), None)
        if ext_match:
            if on_skip:
                on_skip(rel, f"binary or non-source extension ({ext_match})")
            continue
        try:
            size = path.stat().st_size
        except OSError:
            continue
        if size > max_bytes:
            if on_skip:
                on_skip(rel, f"file too large ({size // 1024} KB > {settings.max_file_size_kb} KB limit)")
            continue
        yield path
