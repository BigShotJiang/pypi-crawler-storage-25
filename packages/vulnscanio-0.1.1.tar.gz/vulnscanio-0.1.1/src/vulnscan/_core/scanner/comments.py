"""Comment detection helpers.

These are intentionally simple. Full lexing per language would be more
accurate but expensive; for our regex pass it is enough to know whether
a match starts inside a single-line comment, which is where the bulk of
false positives come from in practice.
"""
from __future__ import annotations

# Per-language single-line comment markers we recognize.
_COMMENT_PREFIXES: dict[str, tuple[str, ...]] = {
    "python":     ("#",),
    "ruby":       ("#",),
    "shell":      ("#",),
    "yaml":       ("#",),
    "dockerfile": ("#",),
    "dotenv":     ("#",),
    "makefile":   ("#",),
    "terraform":  ("#",),
    "javascript": ("//",),
    "typescript": ("//",),
    "java":       ("//",),
    "c":          ("//",),
    "cpp":        ("//",),
    "csharp":     ("//",),
    "go":         ("//",),
    "rust":       ("//",),
    "php":        ("//", "#"),
    "sql":        ("--",),
}


def is_in_line_comment(line: str, col: int, language: str | None) -> bool:
    """Return True if column `col` (0-indexed) on `line` is inside a //-style comment.

    Conservative: ignores the case of comment markers appearing inside string
    literals (which would require real lexing). False positives from this
    are limited — strings containing `# eval(` are rare.
    """
    if not language:
        return False
    markers = _COMMENT_PREFIXES.get(language)
    if not markers:
        return False
    earliest = min(
        (line.find(m) for m in markers if line.find(m) != -1),
        default=-1,
    )
    if earliest == -1:
        return False
    return col >= earliest
