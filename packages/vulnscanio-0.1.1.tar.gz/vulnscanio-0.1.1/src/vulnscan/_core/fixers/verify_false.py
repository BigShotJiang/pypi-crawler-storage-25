r"""Fix TLS-PY-VERIFY-FALSE: remove the `verify=False` keyword argument.

DESIGN: AST-aware. We find the `verify=False` keyword argument node
and remove it, including its leading comma if present (or its trailing
comma if it's the first argument).

Why not regex on the line? Because of cases like:
    requests.get(url, headers={"X-verify": "False"}, verify=False)
A regex for `verify\s*=\s*False` would happily strip the inner header
value too.

LIMITATION: Removing `verify=False` defaults `verify` to True, which
is what we want — but in some environments (corporate CAs, internal
TLS-terminating proxies) this will break the request. The fix
explanation calls this out and recommends `verify=<path-to-ca-bundle>`
as the proper remediation when an internal CA is needed.
"""
from __future__ import annotations

from vulnscan._core.fixers.base import FixCandidate, Fixer
from vulnscan._core.scanner.types import Finding


class VerifyFalseFixer(Fixer):
    @property
    def rule_id(self) -> str:
        return "TLS-PY-VERIFY-FALSE"

    def propose(self, finding: Finding, file_content: str) -> FixCandidate | None:
        if not finding.file_path.endswith(".py"):
            return None
        new_text = _ast_remove_verify_false(file_content, finding.line_number)
        if new_text is None or new_text == file_content:
            return None
        return FixCandidate.build(
            finding=finding,
            original_text=file_content,
            fixed_text=new_text,
            explanation=(
                "Removed `verify=False` so TLS certificates are validated. "
                "If you need to trust an internal CA, use `verify='/path/to/ca-bundle.pem'` "
                "instead of disabling verification entirely."
            ),
            engine="deterministic",
        )


def _ast_remove_verify_false(content: str, target_line: int) -> str | None:
    """Find a keyword_argument `verify=False` on the target line and
    remove it from its argument list, fixing up commas as needed.
    """
    try:
        import tree_sitter
        import tree_sitter_python
    except ImportError:
        return None

    PY = tree_sitter.Language(tree_sitter_python.language())
    parser = tree_sitter.Parser(PY)
    source = content.encode("utf-8")
    try:
        tree = parser.parse(source)
    except Exception:
        return None

    # We need to find a `keyword_argument` node where:
    #   - name = "verify"
    #   - value = "False"
    #   - start_point[0] + 1 == target_line
    # Then we want the start byte of the kwarg AND the bounding commas.

    target = None
    parent_arglist = None

    def walk(node, parent=None) -> None:
        nonlocal target, parent_arglist
        if (node.type == "keyword_argument"
                and node.start_point[0] + 1 == target_line):
            name = node.child_by_field_name("name")
            value = node.child_by_field_name("value")
            if (name is not None and value is not None
                    and source[name.start_byte:name.end_byte] == b"verify"
                    and source[value.start_byte:value.end_byte] == b"False"):
                target = node
                parent_arglist = parent
                return
        for child in node.children:
            walk(child, node)
            if target is not None:
                return

    walk(tree.root_node)
    if target is None or parent_arglist is None:
        return None

    # Locate the comma to remove: prefer the one BEFORE the kwarg
    # (so a trailing kwarg becomes naturally last). If kwarg is the
    # first non-paren child, remove the comma AFTER it instead.
    children = parent_arglist.children
    target_idx = None
    for i, c in enumerate(children):
        if c.id == target.id:
            target_idx = i
            break
    if target_idx is None:
        return None

    # Find adjacent commas
    prev_comma_idx = None
    for j in range(target_idx - 1, -1, -1):
        if children[j].type == ",":
            prev_comma_idx = j
            break
        if children[j].type not in ("(",):
            break  # there's a real arg before us; no comma to remove leftward
    next_comma_idx = None
    if prev_comma_idx is None:
        for j in range(target_idx + 1, len(children)):
            if children[j].type == ",":
                next_comma_idx = j
                break
            if children[j].type not in (")",):
                break

    # Build the removal range: [start_byte_of_removal, end_byte_of_removal)
    if prev_comma_idx is not None:
        # Remove from start of previous comma through end of target
        start = children[prev_comma_idx].start_byte
        end = target.end_byte
    elif next_comma_idx is not None:
        # Remove from start of target through end of trailing comma
        start = target.start_byte
        end = children[next_comma_idx].end_byte
    else:
        # No commas at all (single-arg call). Just remove the kwarg.
        start = target.start_byte
        end = target.end_byte

    # Also gobble whitespace following the cut, up to the next non-space
    # character on the same line, so we don't leave double spaces.
    while end < len(source) and source[end:end+1] in (b" ", b"\t"):
        end += 1

    new_source = source[:start] + source[end:]
    return new_source.decode("utf-8")
