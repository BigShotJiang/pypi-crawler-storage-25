"""Registry: rule_id → Fixer instance.

The CLI/Action code asks the registry "do you have a fixer for
CRYPTO-WEAK-HASH-MD5?" and gets back either a Fixer or None. Adding
a new fixer is one line: import it and register it.
"""
from __future__ import annotations

from vulnscan._core.fixers.base import Fixer
from vulnscan._core.fixers.eval_literal import EvalLiteralFixer
from vulnscan._core.fixers.md5 import Md5Fixer
from vulnscan._core.fixers.sha1 import Sha1Fixer
from vulnscan._core.fixers.verify_false import VerifyFalseFixer


def _build_default_registry() -> dict[str, Fixer]:
    fixers: list[Fixer] = [
        Md5Fixer(),
        Sha1Fixer(),
        VerifyFalseFixer(),
        EvalLiteralFixer(),
    ]
    return {f.rule_id: f for f in fixers}


_REGISTRY: dict[str, Fixer] = _build_default_registry()


def get_fixer(rule_id: str) -> Fixer | None:
    """Return the fixer for the given rule_id, or None."""
    return _REGISTRY.get(rule_id)


def fixable_rule_ids() -> set[str]:
    """All rule_ids that have a registered fixer."""
    return set(_REGISTRY.keys())
