"""Fix CRYPTO-WEAK-HASH-MD5: rewrite hashlib.md5(...) → hashlib.sha256(...).

DESIGN: Deterministic, AST-aware. We use tree-sitter to find the
exact `hashlib.md5` call on the finding's line, then perform a
byte-precise substitution of `md5` → `sha256`. The retest gate
verifies the rule no longer fires after the rewrite.

Why not regex on the line text? Because someone might have written:
    h = hashlib.md5(b"data")  # log a md5 reminder for legacy
A naive regex on `md5` could replace both. AST gives us the exact
byte range of the `md5` identifier in the call.

Why not the LLM? An LLM would happily rename surrounding variables,
add unrelated imports, or refactor. For a one-character substitution
this would be a regression in trust. Deterministic wins here.

LIMITATION: We rewrite to sha256 unconditionally. There are uses of
md5 (e.g. cache key generation) where sha256 is fine but slightly
slower. Users who care can suppress the rule on those lines instead
of accepting the fix. We note this in the explanation.
"""
from __future__ import annotations

from vulnscan._core.fixers.base import FixCandidate, Fixer
from vulnscan._core.scanner.types import Finding


class Md5Fixer(Fixer):
    @property
    def rule_id(self) -> str:
        return "CRYPTO-WEAK-HASH-MD5"

    def propose(self, finding: Finding, file_content: str) -> FixCandidate | None:
        # Only handle Python files for now. JS uses a different idiom
        # (crypto.createHash("md5")) and would need its own fixer; out
        # of scope for the v1 batch since the JS fix has more
        # variations to consider.
        if not finding.file_path.endswith(".py"):
            return None

        # Tree-sitter is REQUIRED for safe fixing. Without it, we can't
        # distinguish `hashlib.md5(x)` (real call) from text inside a
        # string or comment that happens to read `hashlib.md5`. A regex
        # fallback would auto-rewrite "Avoid hashlib.md5 for passwords"
        # in a docstring, breaking the semantic meaning of the file.
        new_text = _ast_rewrite(file_content, finding.line_number)
        if new_text is None or new_text == file_content:
            return None

        return FixCandidate.build(
            finding=finding,
            original_text=file_content,
            fixed_text=new_text,
            explanation=(
                "Replaced `hashlib.md5(...)` with `hashlib.sha256(...)`. "
                "If MD5 was used for a non-security checksum (e.g. cache key), "
                "you can suppress the rule with `# vulnscan: ignore CRYPTO-WEAK-HASH-MD5` instead."
            ),
            engine="deterministic",
        )


def _ast_rewrite(content: str, target_line: int) -> str | None:
    """Use tree-sitter to find the `md5` identifier at target_line and
    rewrite it to `sha256`. Returns None if tree-sitter isn't available
    or the call wasn't found on that line.
    """
    try:
        import tree_sitter
        import tree_sitter_python
    except ImportError:
        return None

    PY = tree_sitter.Language(tree_sitter_python.language())
    parser = tree_sitter.Parser(PY)
    source = content.encode("utf-8")
    try:
        tree = parser.parse(source)
    except Exception:
        return None

    # Find every `hashlib.md5` attribute access on the target line.
    # An `attribute` node has children:
    #   identifier "hashlib", ".", identifier "md5"
    # We want the byte range of the trailing `md5` identifier.
    md5_ranges: list[tuple[int, int]] = []   # (start_byte, end_byte)

    def walk(node) -> None:
        if node.type == "attribute":
            obj = node.child_by_field_name("object")
            attr = node.child_by_field_name("attribute")
            if (obj is not None and attr is not None
                    and obj.type == "identifier"
                    and attr.type == "identifier"
                    and source[obj.start_byte:obj.end_byte] == b"hashlib"
                    and source[attr.start_byte:attr.end_byte] == b"md5"
                    and attr.start_point[0] + 1 == target_line):
                md5_ranges.append((attr.start_byte, attr.end_byte))
        for child in node.children:
            walk(child)

    walk(tree.root_node)
    if not md5_ranges:
        return None

    # Apply replacements right-to-left so earlier byte offsets stay valid.
    new_source = source
    for start, end in sorted(md5_ranges, reverse=True):
        new_source = new_source[:start] + b"sha256" + new_source[end:]
    return new_source.decode("utf-8")
