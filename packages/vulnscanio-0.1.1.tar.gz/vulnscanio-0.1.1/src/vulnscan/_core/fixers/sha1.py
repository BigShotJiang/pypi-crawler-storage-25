"""Fix CRYPTO-WEAK-HASH-SHA1: rewrite hashlib.sha1(...) → hashlib.sha256(...).

Same shape as the md5 fixer — see fixers/md5.py for design notes.
"""
from __future__ import annotations

from vulnscan._core.fixers.base import FixCandidate, Fixer
from vulnscan._core.scanner.types import Finding


class Sha1Fixer(Fixer):
    @property
    def rule_id(self) -> str:
        return "CRYPTO-WEAK-HASH-SHA1"

    def propose(self, finding: Finding, file_content: str) -> FixCandidate | None:
        if not finding.file_path.endswith(".py"):
            return None
        # Tree-sitter required (see fixers/md5.py for rationale).
        new_text = _ast_rewrite(file_content, finding.line_number)
        if new_text is None or new_text == file_content:
            return None
        return FixCandidate.build(
            finding=finding,
            original_text=file_content,
            fixed_text=new_text,
            explanation=(
                "Replaced `hashlib.sha1(...)` with `hashlib.sha256(...)`. "
                "If SHA-1 was used for a non-security purpose, you can "
                "suppress the rule with `# vulnscan: ignore CRYPTO-WEAK-HASH-SHA1` instead."
            ),
            engine="deterministic",
        )


def _ast_rewrite(content: str, target_line: int) -> str | None:
    try:
        import tree_sitter
        import tree_sitter_python
    except ImportError:
        return None

    PY = tree_sitter.Language(tree_sitter_python.language())
    parser = tree_sitter.Parser(PY)
    source = content.encode("utf-8")
    try:
        tree = parser.parse(source)
    except Exception:
        return None

    sha1_ranges: list[tuple[int, int]] = []

    def walk(node) -> None:
        if node.type == "attribute":
            obj = node.child_by_field_name("object")
            attr = node.child_by_field_name("attribute")
            if (obj is not None and attr is not None
                    and obj.type == "identifier"
                    and attr.type == "identifier"
                    and source[obj.start_byte:obj.end_byte] == b"hashlib"
                    and source[attr.start_byte:attr.end_byte] == b"sha1"
                    and attr.start_point[0] + 1 == target_line):
                sha1_ranges.append((attr.start_byte, attr.end_byte))
        for child in node.children:
            walk(child)

    walk(tree.root_node)
    if not sha1_ranges:
        return None
    new_source = source
    for start, end in sorted(sha1_ranges, reverse=True):
        new_source = new_source[:start] + b"sha256" + new_source[end:]
    return new_source.decode("utf-8")
