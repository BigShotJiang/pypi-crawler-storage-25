"""VulnScan auto-fix system (phase 5).

Public API:

    from fixers import propose_and_gate

    result = propose_and_gate(finding, file_content, all_findings_in_file)
    if result and result.accepted:
        print(result.candidate.diff)
"""
from __future__ import annotations

from vulnscan._core.fixers.apply import retest
from vulnscan._core.fixers.base import FixCandidate, Fixer, FixResult
from vulnscan._core.fixers.registry import fixable_rule_ids, get_fixer
from vulnscan._core.scanner.types import Finding


def propose_and_gate(
    finding: Finding,
    file_content: str,
    pre_existing_findings: list[Finding] | None = None,
) -> FixResult | None:
    """Generate a candidate fix and run it through the retest gate.

    Returns:
        None if no fixer is registered for this rule_id, OR if the
        fixer declines to propose a fix (returns None internally).
        Otherwise returns a FixResult — check .accepted to know
        whether the fix passed the gate.

    The retest gate is the moat: an accepted=True FixResult means
    the rescan confirmed the original finding is gone and no new
    equal-or-higher-severity findings appeared.
    """
    fixer = get_fixer(finding.rule_id)
    if fixer is None:
        return None
    candidate = fixer.propose(finding, file_content)
    if candidate is None:
        return None
    return retest(
        candidate,
        original_finding=finding,
        pre_existing_findings=pre_existing_findings,
    )


__all__ = [
    "FixCandidate",
    "Fixer",
    "FixResult",
    "fixable_rule_ids",
    "get_fixer",
    "propose_and_gate",
    "retest",
]
