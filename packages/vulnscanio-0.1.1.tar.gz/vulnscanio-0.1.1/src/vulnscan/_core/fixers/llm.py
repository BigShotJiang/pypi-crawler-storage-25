"""Provider-agnostic LLM wrapper for fixers that need judgment.

Most fixers in scope are deterministic — md5→sha256 doesn't need an
LLM. But some require judgment: e.g. picking a sensible env var name
when replacing a hardcoded URL. This wrapper provides a small surface
for those.

DESIGN:
  * Provider chosen via env var: VULNSCAN_LLM_PROVIDER=anthropic|openai
  * API key from env: ANTHROPIC_API_KEY / OPENAI_API_KEY
  * Imports are lazy so users without LLM extras installed (or without
    API keys) get a clean error message at call time, not at import.
  * `is_available()` lets callers decide whether to even attempt an
    LLM-based fix path.
  * Tests should NEVER actually call out to the LLM. The integration
    test is `skipif(not is_available())`.

Customers will have provider preferences and budget concerns, so we
deliberately don't pin a single provider. Adding a new provider is
~30 lines: implement `_call_<provider>`, register it in
`_PROVIDERS`, support its env var.
"""
from __future__ import annotations
import os
from dataclasses import dataclass


@dataclass
class LlmResponse:
    text: str
    provider: str
    model: str


class LlmError(Exception):
    """Raised when an LLM call fails (no provider, no key, API error)."""


def _provider_name() -> str:
    """Returns the configured provider name. Defaults to anthropic."""
    return os.environ.get("VULNSCAN_LLM_PROVIDER", "anthropic").lower()


def is_available() -> bool:
    """True if the configured provider has credentials and SDK installed.

    Cheap probe — doesn't make a network call. Useful for CI gating
    so tests skip cleanly when no API key is set.
    """
    provider = _provider_name()
    if provider == "anthropic":
        if not os.environ.get("ANTHROPIC_API_KEY"):
            return False
        try:
            import anthropic  # noqa: F401
            return True
        except ImportError:
            return False
    if provider == "openai":
        if not os.environ.get("OPENAI_API_KEY"):
            return False
        try:
            import openai  # noqa: F401
            return True
        except ImportError:
            return False
    return False


def complete(prompt: str, *, max_tokens: int = 512, system: str | None = None) -> LlmResponse:
    """Send a prompt to the configured LLM, return the response.

    Keep prompts focused: fixers should ask for a single, narrow piece
    of output (e.g. "suggest a sensible env var name for this URL").
    Don't ask the LLM to generate full code rewrites — that's what
    the deterministic fixers handle, and the retest gate would catch
    style drift.
    """
    provider = _provider_name()
    if provider == "anthropic":
        return _call_anthropic(prompt, max_tokens=max_tokens, system=system)
    if provider == "openai":
        return _call_openai(prompt, max_tokens=max_tokens, system=system)
    raise LlmError(f"Unknown VULNSCAN_LLM_PROVIDER: {provider!r}")


# ----------------------------------------------------------------------
# Per-provider implementations (lazy imports so missing SDK is a
# runtime error, not an import error).
# ----------------------------------------------------------------------

def _call_anthropic(prompt: str, *, max_tokens: int, system: str | None) -> LlmResponse:
    api_key = os.environ.get("ANTHROPIC_API_KEY")
    if not api_key:
        raise LlmError("ANTHROPIC_API_KEY not set")
    try:
        import anthropic
    except ImportError as e:
        raise LlmError("anthropic SDK not installed (pip install anthropic)") from e

    client = anthropic.Anthropic(api_key=api_key)
    model = os.environ.get("VULNSCAN_LLM_MODEL", "claude-sonnet-4-5")
    msg = client.messages.create(
        model=model,
        max_tokens=max_tokens,
        system=system or "",
        messages=[{"role": "user", "content": prompt}],
    )
    # Concatenate all text blocks
    parts = [b.text for b in msg.content if getattr(b, "type", "") == "text"]
    return LlmResponse(text="".join(parts), provider="anthropic", model=model)


def _call_openai(prompt: str, *, max_tokens: int, system: str | None) -> LlmResponse:
    api_key = os.environ.get("OPENAI_API_KEY")
    if not api_key:
        raise LlmError("OPENAI_API_KEY not set")
    try:
        import openai
    except ImportError as e:
        raise LlmError("openai SDK not installed (pip install openai)") from e

    client = openai.OpenAI(api_key=api_key)
    model = os.environ.get("VULNSCAN_LLM_MODEL", "gpt-4o-mini")
    messages: list[dict] = []
    if system:
        messages.append({"role": "system", "content": system})
    messages.append({"role": "user", "content": prompt})
    resp = client.chat.completions.create(
        model=model,
        max_tokens=max_tokens,
        messages=messages,
    )
    text = resp.choices[0].message.content or ""
    return LlmResponse(text=text, provider="openai", model=model)
