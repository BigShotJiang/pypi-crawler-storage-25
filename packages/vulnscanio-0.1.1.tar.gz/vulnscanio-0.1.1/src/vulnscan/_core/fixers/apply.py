"""The retest gate — phase 5's moat.

For every FixCandidate, this module:

  1. Writes the proposed fix to a temp directory (NEVER the user's repo)
  2. Runs the scanner against that copy with caching DISABLED
  3. Asserts the original finding is gone
  4. Asserts no new findings of equal-or-higher severity appeared
  5. (Python only) Asserts the file still parses

Only candidates that pass every check are returned as accepted=True.

WHY THIS MATTERS: "AI SAST" tools that ship un-retested fixes generate
confident-looking wrong code. The retest gate is what makes auto-fix
safe to ship. If there's ever a regression here, every fix downstream
becomes suspect — so this module is heavily tested.

WHY CACHE OFF: The cache is keyed on (file_hash, rules_hash). When we
modify a file, its hash changes — but during a retest we want absolute
certainty the scan reflects the new content, not stale entries that
might have leaked through. Cache off; correctness over speed.
"""
from __future__ import annotations
import ast as python_ast
import shutil
import tempfile
from dataclasses import dataclass
from pathlib import Path

from vulnscan._core.scanner.orchestrator import run_scan
from vulnscan._core.scanner.types import Finding, Severity

from vulnscan._core.fixers.base import FixCandidate, FixResult


# Severity ordering (worse → less worse).
_SEVERITY_RANK = {
    Severity.CRITICAL: 4,
    Severity.HIGH: 3,
    Severity.MEDIUM: 2,
    Severity.LOW: 1,
    Severity.INFO: 0,
}


def _python_parses(content: str) -> bool:
    """True if the proposed Python content is syntactically valid.

    A fix that breaks the parse tree is always rejected — even if the
    rescan happens to come back clean (which won't happen in practice
    since the scanner walks all rules over content that's already
    syntactically broken). Belt-and-suspenders for the most common
    failure mode.
    """
    try:
        python_ast.parse(content)
        return True
    except SyntaxError:
        return False


def _is_python(file_path: str) -> bool:
    return file_path.endswith(".py")


def _finding_signature(f: Finding) -> tuple[str, str, int]:
    """Strict identity tuple — used for "is the original gone?" check.

    The original finding's exact location must disappear after the fix.
    """
    return (f.rule_id, f.file_path, f.line_number)


def _finding_identity_for_dedup(f: Finding) -> tuple[str, str, str]:
    """Looser identity for "is this finding NEW?" check.

    When a fix inserts or removes lines (e.g. adding `import ast`),
    every finding below the change shifts. A strict line-number match
    would incorrectly flag those shifted findings as "new regressions."

    We match on (rule_id, file_path, normalized_offending_text). The
    offending text is extracted from the snippet — for the AST
    analyzer it's the matched expression directly; for the regex
    analyzer it's embedded in a multi-line "context" snippet marked
    with `>` on the offending line. We strip those formatting markers
    and normalize whitespace so the same vulnerability matches before
    and after a fix that only shifts line numbers.
    """
    snippet = f.code_snippet or ""
    # Pull out just the offending line if the snippet is a regex-style
    # context block. A regex snippet looks like:
    #     "     1 | preceding line\n>    2 | offending line\n     3 | ..."
    offending_lines = []
    for line in snippet.splitlines():
        if line.startswith(">"):
            # Extract the part after `> NN | `
            after = line.lstrip(">").lstrip()
            if "|" in after:
                after = after.split("|", 1)[1]
            offending_lines.append(after.strip())
    if offending_lines:
        body = " ".join(offending_lines)
    else:
        # AST snippet: just the matched expression
        body = snippet
    # Whitespace-normalize so trailing-space edits don't break the match
    body = " ".join(body.split())
    return (f.rule_id, f.file_path, body)


def retest(
    candidate: FixCandidate,
    original_finding: Finding,
    pre_existing_findings: list[Finding] | None = None,
) -> FixResult:
    """Run the candidate through the gate. Returns a FixResult.

    Args:
        candidate:           The fix to gate.
        original_finding:    The single finding the candidate is fixing.
        pre_existing_findings:
            All findings present in the file BEFORE the fix. Used to
            compute "new" findings correctly. If a file has 3 MD5 calls
            and we fix one, the other 2 should NOT count as "new"
            findings — they were there before. Defaults to just the
            single original_finding (correct for one-finding files).

    Steps:
      1. No-op check.
      2. (Python) Parse check.
      3. Apply to a temp dir.
      4. Rescan with cache disabled.
      5. Verify original finding is gone.
      6. Verify no NEW equal-or-higher-severity findings appeared
         (where "new" = not in pre_existing_findings).
    """
    if pre_existing_findings is None:
        pre_existing_findings = [original_finding]

    # Step 1: no-op
    if candidate.fixed_text == candidate.original_text:
        return FixResult(
            candidate=candidate, accepted=False,
            rejection_reason="fix produced no change",
        )

    # Step 2: parse check (Python only for now)
    if _is_python(candidate.file_path):
        if not _python_parses(candidate.fixed_text):
            return FixResult(
                candidate=candidate, accepted=False,
                rejection_reason="fix introduces a Python syntax error",
            )

    # Step 3: temp dir
    tmp = Path(tempfile.mkdtemp(prefix="vulnscan-retest-"))
    try:
        target = tmp / candidate.file_path
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(candidate.fixed_text, encoding="utf-8")

        # Step 4: rescan with cache off
        result = run_scan(tmp, use_cache=False)

        # Step 5: is the original finding gone?
        # Strategy depends on whether the original has a snippet:
        #   * With snippet → use loose identity (line-shift tolerant).
        #     This is the production path: orchestrator-produced findings
        #     always have snippets.
        #   * Without snippet → fall back to strict line match. This
        #     handles test-constructed findings and any unusual case
        #     where snippet is missing.
        original_loose = _finding_identity_for_dedup(original_finding)
        if original_loose[2]:   # non-empty snippet body
            post_loose = {_finding_identity_for_dedup(f) for f in result.findings}
            still_present = original_loose in post_loose
        else:
            original_strict = _finding_signature(original_finding)
            post_strict = {_finding_signature(f) for f in result.findings}
            still_present = original_strict in post_strict
        if still_present:
            return FixResult(
                candidate=candidate, accepted=False,
                rejection_reason="original finding still present after fix",
            )

        # Step 6: any NEW equal-or-higher-severity findings?
        # A finding is new only if its (rule_id, snippet) wasn't already
        # in the file. This is line-shift-tolerant.
        pre_existing_loose = {_finding_identity_for_dedup(f) for f in pre_existing_findings}
        original_rank = _SEVERITY_RANK.get(original_finding.severity, 0)
        regression: list[str] = []
        for f in result.findings:
            if _finding_identity_for_dedup(f) in pre_existing_loose:
                continue   # same vulnerability we already knew about
            rank = _SEVERITY_RANK.get(f.severity, 0)
            if rank >= original_rank:
                regression.append(
                    f"{f.rule_id} at line {f.line_number} ({f.severity.value})"
                )

        if regression:
            return FixResult(
                candidate=candidate, accepted=False,
                rejection_reason="fix introduced new equal-or-higher-severity findings",
                new_findings_introduced=regression,
            )

        return FixResult(candidate=candidate, accepted=True)

    finally:
        shutil.rmtree(tmp, ignore_errors=True)
