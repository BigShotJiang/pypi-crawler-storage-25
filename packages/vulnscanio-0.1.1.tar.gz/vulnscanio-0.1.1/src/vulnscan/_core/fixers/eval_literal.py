"""Fix EVAL-PY: rewrite eval(<safe-arg>) → ast.literal_eval(<safe-arg>).

DESIGN: This fixer is the most conservative of the batch. We only
propose a fix if the eval() argument is a literal-compatible
expression — i.e. something `ast.literal_eval` is documented to
accept: strings, numbers, tuples, lists, dicts, sets, booleans, and
None. For any other shape (bare identifier, function call, attribute
access, complex expression), we return None — those aren't
auto-fixable safely.

WHY THIS MATTERS: Replacing `eval(user_input)` with
`ast.literal_eval(user_input)` is the WRONG fix when user_input is
arbitrary code — `ast.literal_eval` will raise a `ValueError` at
runtime, breaking the program. We must only fix the cases where the
eval() is provably operating on a literal-shaped argument.

The retest gate is the second line of defense: even if our heuristic
were too aggressive, the gate's parse-check + rescan would catch a
broken file. But we want the heuristic itself to be conservative —
the gate is a backstop, not a license to be sloppy.

We also need to add `import ast` if it's not already imported. Done
via a quick scan; we don't try to be clever about reorganizing imports.
"""
from __future__ import annotations

from vulnscan._core.fixers.base import FixCandidate, Fixer
from vulnscan._core.scanner.types import Finding


# Tree-sitter node types that ast.literal_eval can safely evaluate.
# Anything else: bail.
_LITERAL_NODE_TYPES = {
    "string",        # "abc"
    "integer",       # 42
    "float",         # 1.5
    "true", "false", # True, False
    "none",          # None
    "list",          # [1, 2, 3]
    "tuple",         # (1, 2, 3)
    "dictionary",    # {"a": 1}
    "set",           # {1, 2, 3}
    "unary_operator",  # -1, +2, not False
}


class EvalLiteralFixer(Fixer):
    @property
    def rule_id(self) -> str:
        return "EVAL-PY"

    def propose(self, finding: Finding, file_content: str) -> FixCandidate | None:
        if not finding.file_path.endswith(".py"):
            return None
        new_text = _ast_rewrite_eval(file_content, finding.line_number)
        if new_text is None or new_text == file_content:
            return None
        return FixCandidate.build(
            finding=finding,
            original_text=file_content,
            fixed_text=new_text,
            explanation=(
                "Replaced `eval(<literal>)` with `ast.literal_eval(<literal>)`. "
                "`ast.literal_eval` only evaluates Python literal structures "
                "(strings, numbers, tuples, lists, dicts, sets, booleans, None) "
                "and is safe for untrusted input."
            ),
            engine="deterministic",
        )


def _ast_rewrite_eval(content: str, target_line: int) -> str | None:
    """Find an `eval()` call on the target line whose single argument
    is a literal-shaped expression. Replace `eval` with `ast.literal_eval`
    and add `import ast` if needed.
    """
    try:
        import tree_sitter
        import tree_sitter_python
    except ImportError:
        return None

    PY = tree_sitter.Language(tree_sitter_python.language())
    parser = tree_sitter.Parser(PY)
    source = content.encode("utf-8")
    try:
        tree = parser.parse(source)
    except Exception:
        return None

    target = None       # the `eval` identifier node we'll replace

    def walk(node) -> None:
        nonlocal target
        if (node.type == "call"
                and node.start_point[0] + 1 == target_line):
            fn = node.child_by_field_name("function")
            args = node.child_by_field_name("arguments")
            if (fn is not None
                    and fn.type == "identifier"
                    and source[fn.start_byte:fn.end_byte] == b"eval"
                    and args is not None
                    and args.type == "argument_list"):
                # Single positional argument that is a literal?
                positional = [c for c in args.children
                              if c.type not in ("(", ")", ",")]
                if len(positional) == 1:
                    arg = positional[0]
                    if arg.type in _LITERAL_NODE_TYPES:
                        target = fn
                        return
        for child in node.children:
            walk(child)
            if target is not None:
                return

    walk(tree.root_node)
    if target is None:
        return None

    # Replace `eval` with `ast.literal_eval`
    new_source = (source[:target.start_byte]
                  + b"ast.literal_eval"
                  + source[target.end_byte:])

    # Make sure `import ast` exists. Scan top-level statements.
    new_text = new_source.decode("utf-8")
    if not _has_import_ast(new_text):
        new_text = _prepend_import_ast(new_text)
    return new_text


def _has_import_ast(content: str) -> bool:
    """Cheap top-level scan for `import ast` or `from ast import ...`.

    Doesn't detect aliased imports (`import ast as _ast`) — but that's
    an obscure pattern and false-negative just means we add an
    `import ast` that the user can dedupe later, not a correctness bug.
    """
    for line in content.splitlines():
        stripped = line.strip()
        if stripped.startswith("import ast") and (
                len(stripped) == len("import ast")
                or stripped[len("import ast")] in (" ", ",", "\t")):
            return True
        if stripped.startswith("from ast "):
            return True
    return False


def _prepend_import_ast(content: str) -> str:
    """Insert `import ast` after the file's last existing import line.

    Strategy: find the last `import ...` or `from ... import ...` at
    module level, and insert `import ast\n` right after it. If no
    imports exist, fall through to inserting after any module docstring
    and leading comments.

    This produces stylistically clean output:

      Before:
        import hashlib
        import requests
        <blank>
        def f(): ...

      After:
        import hashlib
        import requests
        import ast              ← inserted right after last import
        <blank>
        def f(): ...
    """
    lines = content.splitlines(keepends=True)

    # Find the last top-level import line. We use a simple
    # column-zero check to avoid mis-detecting indented imports
    # inside functions.
    last_import_line = -1
    in_docstring = False
    docstring_quote = None
    for i, line in enumerate(lines):
        # Track a possibly-multi-line module docstring at the very top
        if last_import_line < 0:   # haven't seen any imports yet
            if in_docstring:
                if docstring_quote and docstring_quote in line:
                    in_docstring = False
                continue
            stripped = line.strip()
            if stripped.startswith('"""') or stripped.startswith("'''"):
                quote = stripped[:3]
                if stripped.count(quote) >= 2 and len(stripped) > 3:
                    continue   # single-line docstring
                in_docstring = True
                docstring_quote = quote
                continue
        # A top-level import is one that starts at column 0 with
        # `import` or `from ... import`.
        if line.startswith("import ") or line.startswith("from "):
            last_import_line = i

    if last_import_line >= 0:
        # Insert immediately after the last import
        lines.insert(last_import_line + 1, "import ast\n")
    else:
        # No imports at all — insert at the top, after any docstring/comments.
        insert_at = 0
        in_docstring = False
        docstring_quote = None
        for i, line in enumerate(lines):
            stripped = line.strip()
            if not stripped or stripped.startswith("#"):
                insert_at = i + 1
                continue
            if in_docstring:
                insert_at = i + 1
                if docstring_quote and docstring_quote in stripped:
                    in_docstring = False
                continue
            if stripped.startswith('"""') or stripped.startswith("'''"):
                quote = stripped[:3]
                if stripped.count(quote) >= 2 and len(stripped) > 3:
                    insert_at = i + 1
                    continue
                in_docstring = True
                docstring_quote = quote
                insert_at = i + 1
                continue
            break
        lines.insert(insert_at, "import ast\n")
    return "".join(lines)
