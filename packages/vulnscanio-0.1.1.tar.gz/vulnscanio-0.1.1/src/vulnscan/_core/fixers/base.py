"""Fixer abstractions for the AI Auto-Fix system (phase 5).

The fixers in this package each handle ONE rule_id. A fixer takes a
Finding plus the file's content and produces a FixCandidate (a diff +
some metadata). Whether the fix actually gets shown to the user is
gated by the retest harness in `apply.py` — every candidate must pass
through that gate.

DESIGN: Fixers are deterministic by default. For the rules in scope
(md5→sha256, verify=False removal, eval(literal)→ast.literal_eval,
sha1→sha256, hardcoded-localhost), the transformation is purely
mechanical and an LLM would only add style drift or unrelated changes.
Fixers that NEED judgment (e.g. choosing a sensible env var name)
delegate to the LLM wrapper in `llm.py` — but the retest gate treats
both kinds of output identically.

DESIGN: Fixers operate on file content as text and return a diff plus
the proposed new content. They DO NOT touch the file system. Mutation
is the retest harness's responsibility — fixers are pure functions.

This separation lets us test each fixer in isolation without spinning
up a temp dir or filesystem state.
"""
from __future__ import annotations
import difflib
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from pathlib import Path

from vulnscan._core.scanner.types import Finding


@dataclass
class FixCandidate:
    """A proposed fix produced by a Fixer, before retest gating.

    Attributes:
        rule_id:        The finding's rule_id this fix addresses.
        file_path:      The relative path being fixed (matches the finding).
        original_text:  The file content before the fix.
        fixed_text:     The file content after the fix.
        diff:           Unified diff (rendered for display).
        explanation:    1-2 sentence human-readable summary of the change.
        engine:         "deterministic" or "llm:<provider>" — for telemetry.
        line_number:    Line of the finding being fixed (for display).
    """
    rule_id: str
    file_path: str
    original_text: str
    fixed_text: str
    diff: str
    explanation: str
    engine: str
    line_number: int

    @classmethod
    def build(
        cls,
        finding: Finding,
        original_text: str,
        fixed_text: str,
        explanation: str,
        engine: str,
    ) -> "FixCandidate":
        """Construct a FixCandidate, rendering the diff from original→fixed."""
        diff = "".join(
            difflib.unified_diff(
                original_text.splitlines(keepends=True),
                fixed_text.splitlines(keepends=True),
                fromfile=f"a/{finding.file_path}",
                tofile=f"b/{finding.file_path}",
                n=3,
            )
        )
        return cls(
            rule_id=finding.rule_id,
            file_path=finding.file_path,
            original_text=original_text,
            fixed_text=fixed_text,
            diff=diff,
            explanation=explanation,
            engine=engine,
            line_number=finding.line_number,
        )


@dataclass
class FixResult:
    """Final result returned to the caller after retest gating.

    `accepted` is true if and only if the candidate passed every gate:
      * It produced an actual change (fixed_text != original_text)
      * The original finding is GONE in the rescan
      * No new findings of equal-or-higher severity appeared
      * The file still parses (Python: ast.parse succeeds)
    """
    candidate: FixCandidate
    accepted: bool
    rejection_reason: str | None = None
    new_findings_introduced: list[str] = field(default_factory=list)


class Fixer(ABC):
    """Base class for all fixers.

    A subclass implements `propose()` for one specific rule_id. The
    method receives the finding and the file content, and returns a
    FixCandidate or None if the fix doesn't apply (e.g. the eval()
    argument isn't a literal).

    Returning None is fine and expected. Many findings can't be
    auto-fixed safely — that's exactly the point of having a gate.
    """

    @property
    @abstractmethod
    def rule_id(self) -> str:
        """The rule_id this fixer handles. Used by the registry."""

    @abstractmethod
    def propose(
        self,
        finding: Finding,
        file_content: str,
    ) -> FixCandidate | None:
        """Generate a candidate fix, or None if no fix applies.

        Returning None is the safe default. A fix should only be
        produced when the fixer is highly confident the diff is
        correct AND minimal AND doesn't change semantics outside
        the targeted line.
        """
