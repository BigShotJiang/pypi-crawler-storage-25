"""Baseline support.

A baseline is a JSON file (.vulnscan-baseline.json) that records a
fingerprint of every finding present at a point in time. Subsequent
scans subtract these fingerprints from their results, so existing
issues stop being reported and only NEW findings show up.

This is the single feature that determines whether VulnScan can be
adopted on a legacy codebase. Without it, `vulnscan scan .` on a
five-year-old repo prints 800 findings and the developer turns it off.

Fingerprint design: hash(rule_id + file_path + line_text). Including
the line's actual text means that if a developer changes the line,
the fingerprint changes too, and the finding becomes "new" again — the
line was edited, so it deserves another look. This is intentional and
matches how SARIF's partialFingerprints behave.
"""
from __future__ import annotations
import hashlib
import json
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Iterable

# Local import — Finding lives in the scanner core
from vulnscan._core.scanner.types import Finding


BASELINE_FILENAME = ".vulnscan-baseline.json"
BASELINE_VERSION = 1


@dataclass
class Baseline:
    version: int
    created_at: str
    fingerprints: set[str] = field(default_factory=set)

    def contains(self, finding: Finding, repo_root: Path) -> bool:
        return fingerprint_for(finding, repo_root) in self.fingerprints

    def to_json(self) -> str:
        return json.dumps(
            {
                "version": self.version,
                "created_at": self.created_at,
                "fingerprints": sorted(self.fingerprints),
            },
            indent=2,
        )


def fingerprint_for(finding: Finding, repo_root: Path) -> str:
    """A stable hash for a finding.

    Includes:
      * rule_id   — change the rule, the fingerprint changes
      * file path — moving the file invalidates the fingerprint (intentional)
      * line text — editing the line invalidates the fingerprint (intentional)

    Does NOT include the line *number*, so simply moving code up or down
    in a file does not invalidate baselines. This matters: developers
    add and remove imports constantly and we don't want to flood them
    with "new" findings just because line numbers shifted.
    """
    line_text = _read_line(repo_root / finding.file_path, finding.line_number)
    payload = f"{finding.rule_id}|{finding.file_path}|{line_text.strip()}"
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()[:16]


def _read_line(path: Path, line_number: int) -> str:
    try:
        with open(path, encoding="utf-8", errors="replace") as f:
            for i, line in enumerate(f, start=1):
                if i == line_number:
                    return line
    except (FileNotFoundError, IsADirectoryError, PermissionError):
        pass
    return ""


def create(findings: Iterable[Finding], repo_root: Path) -> Baseline:
    fingerprints = {fingerprint_for(f, repo_root) for f in findings}
    return Baseline(
        version=BASELINE_VERSION,
        created_at=datetime.now(timezone.utc).isoformat(timespec="seconds"),
        fingerprints=fingerprints,
    )


def load(path: Path) -> Baseline | None:
    if not path.exists():
        return None
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return None
    return Baseline(
        version=data.get("version", BASELINE_VERSION),
        created_at=data.get("created_at", ""),
        fingerprints=set(data.get("fingerprints", [])),
    )


def filter_baselined(
    findings: list[Finding], baseline: Baseline | None, repo_root: Path,
) -> tuple[list[Finding], int]:
    """Split findings into (new findings, count of baselined findings)."""
    if baseline is None:
        return findings, 0
    kept: list[Finding] = []
    suppressed = 0
    for f in findings:
        if baseline.contains(f, repo_root):
            suppressed += 1
        else:
            kept.append(f)
    return kept, suppressed
