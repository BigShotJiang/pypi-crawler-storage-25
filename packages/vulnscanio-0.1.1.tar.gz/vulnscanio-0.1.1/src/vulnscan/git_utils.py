"""Git diff helpers for `vulnscan diff`.

Approach: shell out to `git diff --unified=0 BASE..HEAD` and parse the
hunk headers. This is more reliable than calling a Python git library
(GitPython, pygit2) because:

  1. No native dependency for the user to install
  2. Handles renames, submodules, and edge cases the way the user expects
  3. The user's local git config (line endings, attributes) is respected

We only need hunk headers ("@@ -A,B +C,D @@") to figure out which lines
changed in each file. We don't need actual diff content.
"""
from __future__ import annotations
import re
import subprocess
from dataclasses import dataclass, field
from pathlib import Path


_HUNK = re.compile(r'^@@ -\d+(?:,\d+)? \+(\d+)(?:,(\d+))? @@')
_DIFF_HEADER = re.compile(r'^diff --git a/(.+?) b/(.+?)$')
_NEW_FILE = re.compile(r'^\+\+\+ b/(.+)$')


@dataclass
class FileDiff:
    """Lines changed in a single file."""
    path: str
    changed_lines: set[int] = field(default_factory=set)


def changed_files_and_lines(
    repo_root: Path, base: str, head: str = "HEAD",
) -> dict[str, set[int]]:
    """Return {relative_path: set_of_changed_line_numbers}.

    Lines are NEW line numbers (i.e. line numbers in HEAD), so they
    align directly with the line_number field of a Finding.

    Raises RuntimeError if git is not available or the range is invalid.
    """
    rev_range = f"{base}..{head}" if head != "HEAD" else base
    cmd = ["git", "diff", "--unified=0", "--no-color", rev_range]
    try:
        proc = subprocess.run(
            cmd, cwd=repo_root, capture_output=True, text=True, check=False,
        )
    except FileNotFoundError as e:
        raise RuntimeError("git is not installed or not on PATH") from e
    if proc.returncode != 0:
        raise RuntimeError(f"git diff failed: {proc.stderr.strip()}")

    return _parse_diff(proc.stdout)


def _parse_diff(diff_text: str) -> dict[str, set[int]]:
    out: dict[str, set[int]] = {}
    current_path: str | None = None
    for line in diff_text.splitlines():
        m = _NEW_FILE.match(line)
        if m:
            path = m.group(1)
            if path == "/dev/null":
                current_path = None
            else:
                current_path = path
                out.setdefault(current_path, set())
            continue
        if current_path is None:
            continue
        h = _HUNK.match(line)
        if h:
            start = int(h.group(1))
            count = int(h.group(2)) if h.group(2) else 1
            if count == 0:
                # pure deletion — no new lines to flag
                continue
            for ln in range(start, start + count):
                out[current_path].add(ln)
    return out


def filter_findings_to_diff(
    findings, changed: dict[str, set[int]],
):
    """Return only findings whose (file, line) intersects the diff."""
    out = []
    for f in findings:
        lines = changed.get(f.file_path)
        if lines is None:
            continue
        if f.line_number in lines:
            out.append(f)
    return out
