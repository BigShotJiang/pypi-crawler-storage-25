"""VulnScan CLI entrypoint.

Usage:
    vulnscan scan [PATH]                    Full repo scan
    vulnscan diff BASE..HEAD [PATH]         Findings on changed lines only
    vulnscan baseline create [PATH]         Capture current findings as a baseline
    vulnscan baseline show [PATH]           Inspect a baseline
    vulnscan --version                      Print version and exit
"""
from __future__ import annotations
import argparse
import sys

# Bootstrap sys.path so scanner/* imports resolve. Side-effect of importing
# vulnscan/__init__.py.

from vulnscan import __version__
from vulnscan.cli.commands import baseline, diff, fix, scan


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="vulnscan",
        description="Fast static vulnerability scanning for code repositories.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=(
            "Examples:\n"
            "  vulnscan scan .\n"
            "  vulnscan scan . --format=sarif --output=results.sarif\n"
            "  vulnscan diff main..HEAD --format=github-pr\n"
            "  vulnscan baseline create\n"
            "\n"
            "Exit codes:\n"
            "  0  - no findings (or no findings above --fail-on threshold)\n"
            "  1  - findings reported above --fail-on threshold\n"
            "  2  - usage error or scan setup error\n"
        ),
    )
    parser.add_argument("--version", action="version", version=f"vulnscan {__version__}")

    sub = parser.add_subparsers(dest="command", required=True, metavar="COMMAND")
    scan.add_parser(sub)
    diff.add_parser(sub)
    baseline.add_parser(sub)
    fix.add_parser(sub)
    return parser


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    try:
        return args.func(args)
    except KeyboardInterrupt:
        print("\nInterrupted.", file=sys.stderr)
        return 130
    except BrokenPipeError:
        # User piped to head/less etc.; exit cleanly.
        return 0


if __name__ == "__main__":
    sys.exit(main())
