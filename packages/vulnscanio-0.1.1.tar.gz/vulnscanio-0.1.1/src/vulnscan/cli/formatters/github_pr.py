"""GitHub PR comment markdown.

Used by `vulnscan scan --format=github-pr`. Emits a markdown table
suitable for `gh pr comment` or the GitHub API. Designed to:

  * Lead with the count of NEW findings (the developer's question)
  * Use emoji for severity (rendered well in GitHub's markdown)
  * Show file:line so a click navigates to the diff
  * Stay under GitHub's 65,536-character comment limit even on
    very noisy PRs (truncates with a "...and N more" line)
"""
from __future__ import annotations
from collections.abc import Iterable

from vulnscan._core.scanner.types import Finding, Severity


_SEV_EMOJI = {
    Severity.CRITICAL: "🔴",
    Severity.HIGH: "🟠",
    Severity.MEDIUM: "🟡",
    Severity.LOW: "🔵",
    Severity.INFO: "⚪",
}

_MAX_ROWS = 50           # keep comments scannable
_MAX_LENGTH = 60_000     # well below GitHub's 65,536 limit


def render(
    findings: Iterable[Finding],
    *,
    diff_mode: bool = False,
    repo_url: str | None = None,
    commit_sha: str | None = None,
) -> str:
    findings = list(findings)
    if not findings:
        scope = "on changed lines" if diff_mode else ""
        return f"## 🛡️ VulnScan\n\n✅ **No new findings{(' ' + scope).rstrip()}.**"

    # Sort: severity first, then file/line
    sev_rank = {Severity.CRITICAL: 0, Severity.HIGH: 1, Severity.MEDIUM: 2,
                Severity.LOW: 3, Severity.INFO: 4}
    findings.sort(key=lambda f: (sev_rank[f.severity], f.file_path, f.line_number))

    lines: list[str] = []
    lines.append(f"## 🛡️ VulnScan: {len(findings)} finding{'s' if len(findings) != 1 else ''}"
                 + (" on changed lines" if diff_mode else ""))
    lines.append("")
    lines.append(_summary_line(findings))
    lines.append("")
    lines.append("| Severity | Finding | Location |")
    lines.append("|---|---|---|")

    truncated = 0
    for i, f in enumerate(findings):
        if i >= _MAX_ROWS:
            truncated = len(findings) - _MAX_ROWS
            break
        emoji = _SEV_EMOJI[f.severity]
        sev = f.severity.value.capitalize()
        review = " *(review)*" if f.needs_review else ""
        title = _escape_md(f.title)
        location = _format_location(f, repo_url, commit_sha)
        lines.append(f"| {emoji} {sev}{review} | {title} <br><sub>`{f.rule_id}`</sub> | {location} |")

    if truncated:
        lines.append(f"\n_... and {truncated} more findings (shown in full SARIF report)._")

    out = "\n".join(lines)
    if len(out) > _MAX_LENGTH:
        # Hard cap: very rare, but possible on huge PRs.
        out = out[:_MAX_LENGTH] + "\n\n_(truncated)_"
    return out


def _summary_line(findings: list[Finding]) -> str:
    counts = {sev: 0 for sev in Severity}
    for f in findings:
        counts[f.severity] += 1
    parts = []
    for sev in (Severity.CRITICAL, Severity.HIGH, Severity.MEDIUM, Severity.LOW):
        if counts[sev]:
            parts.append(f"{_SEV_EMOJI[sev]} **{counts[sev]}** {sev.value}")
    return " · ".join(parts)


def _format_location(f: Finding, repo_url: str | None, commit_sha: str | None) -> str:
    text = f"`{f.file_path}:{f.line_number}`"
    if repo_url and commit_sha:
        link = f"{repo_url}/blob/{commit_sha}/{f.file_path}#L{f.line_number}"
        return f"[{text}]({link})"
    return text


def _escape_md(s: str) -> str:
    # Minimal escaping: pipes break the table; backticks would be fine
    # but we keep them since they style the rule id. Newlines collapse
    # so a finding title can't break the row.
    return s.replace("|", "\\|").replace("\n", " ")
