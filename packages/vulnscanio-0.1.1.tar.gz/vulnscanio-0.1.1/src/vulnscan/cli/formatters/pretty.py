"""Pretty terminal formatter.

Designed for the default `vulnscan scan` output. Color-codes severity,
groups by file, and shows a one-line fix hint. Optimized for fast
visual scanning by a developer staring at a terminal.

ANSI colors are emitted only when stdout is a TTY *and* NO_COLOR is
unset, following the de-facto standard at https://no-color.org/.
"""
from __future__ import annotations
import os
import sys
from collections.abc import Iterable

from vulnscan._core.scanner.types import Finding, Severity


# ANSI color codes
class _C:
    RESET = "\x1b[0m"
    BOLD = "\x1b[1m"
    DIM = "\x1b[2m"
    RED = "\x1b[31m"
    GREEN = "\x1b[32m"
    YELLOW = "\x1b[33m"
    BLUE = "\x1b[34m"
    MAGENTA = "\x1b[35m"
    CYAN = "\x1b[36m"
    GRAY = "\x1b[90m"
    BR_RED = "\x1b[91m"
    BR_YELLOW = "\x1b[93m"


_SEV_COLOR = {
    Severity.CRITICAL: _C.BR_RED,
    Severity.HIGH: _C.RED,
    Severity.MEDIUM: _C.YELLOW,
    Severity.LOW: _C.BLUE,
    Severity.INFO: _C.GRAY,
}


def _use_color(stream) -> bool:
    if os.environ.get("NO_COLOR"):
        return False
    return getattr(stream, "isatty", lambda: False)()


def render(
    findings: Iterable[Finding],
    *,
    files_scanned: int,
    files_skipped: int,
    elapsed_seconds: float,
    baselined: int = 0,
    diff_mode: bool = False,
    stream=None,
) -> str:
    stream = stream if stream is not None else sys.stdout
    color = _use_color(stream)
    findings = list(findings)

    out: list[str] = []
    if not findings:
        out.append(_format_clean(
            files_scanned, files_skipped, elapsed_seconds, baselined,
            diff_mode, color,
        ))
        return "\n".join(out)

    # Sort by severity (most severe first), then file, then line
    sev_rank = {Severity.CRITICAL: 0, Severity.HIGH: 1, Severity.MEDIUM: 2,
                Severity.LOW: 3, Severity.INFO: 4}
    findings.sort(key=lambda f: (sev_rank[f.severity], f.file_path, f.line_number))

    out.append("")
    for f in findings:
        out.append(_format_finding(f, color))
        out.append("")

    out.append(_format_summary(
        findings, files_scanned, files_skipped, elapsed_seconds,
        baselined, diff_mode, color,
    ))
    return "\n".join(out)


def _format_finding(f: Finding, color: bool) -> str:
    sev = f.severity.value.upper()
    sev_colored = f"{_SEV_COLOR[f.severity]}{sev}{_C.RESET}" if color else sev
    location = f"{f.file_path}:{f.line_number}"
    location_styled = f"{_C.BOLD}{location}{_C.RESET}" if color else location
    rule = f"{_C.GRAY}{f.rule_id}{_C.RESET}" if color else f.rule_id
    review = ""
    if f.needs_review:
        tag = "[needs review]"
        review = f"  {_C.BR_YELLOW}{tag}{_C.RESET}" if color else f"  {tag}"

    arrow = f"{_C.GRAY}▸{_C.RESET}" if color else "▸"
    header = f"  {arrow} {location_styled}  {sev_colored:<22}  {rule}{review}"
    title = f"    {f.title}"
    fix = f"    {_C.DIM}Fix:{_C.RESET} {f.recommendation}" if color else f"    Fix: {f.recommendation}"
    return "\n".join([header, title, fix])


def _format_summary(
    findings: list[Finding],
    files_scanned: int,
    files_skipped: int,
    elapsed_seconds: float,
    baselined: int,
    diff_mode: bool,
    color: bool,
) -> str:
    counts: dict[Severity, int] = {}
    for f in findings:
        counts[f.severity] = counts.get(f.severity, 0) + 1

    parts: list[str] = []
    for sev in (Severity.CRITICAL, Severity.HIGH, Severity.MEDIUM, Severity.LOW):
        n = counts.get(sev, 0)
        if not n:
            continue
        label = f"{n} {sev.value}"
        if color:
            label = f"{_SEV_COLOR[sev]}{label}{_C.RESET}"
        parts.append(label)

    breakdown = " · ".join(parts) if parts else ""
    total = len(findings)
    suffix = f"in {elapsed_seconds:.1f}s across {files_scanned} file{'s' if files_scanned != 1 else ''}"
    if files_skipped:
        suffix += f" ({files_skipped} skipped)"

    main = f"  Found {total} finding{'s' if total != 1 else ''}"
    if breakdown:
        main += f" ({breakdown})"
    main += f" {suffix}."

    extra = []
    if baselined:
        extra.append(f"  {_C.GRAY}{baselined} existing finding{'s' if baselined != 1 else ''} suppressed by baseline.{_C.RESET}" if color
                     else f"  {baselined} existing finding{'s' if baselined != 1 else ''} suppressed by baseline.")
    if diff_mode:
        extra.append(f"  {_C.GRAY}Showing only findings on lines changed in this diff.{_C.RESET}" if color
                     else "  Showing only findings on lines changed in this diff.")

    return "\n".join([main] + extra)


def _format_clean(
    files_scanned: int, files_skipped: int, elapsed: float,
    baselined: int, diff_mode: bool, color: bool,
) -> str:
    check = f"{_C.GREEN}✓{_C.RESET}" if color else "✓"
    msg = f"\n  {check} No findings"
    if diff_mode:
        msg += " on changed lines"
    msg += f" in {elapsed:.1f}s across {files_scanned} file{'s' if files_scanned != 1 else ''}"
    if files_skipped:
        msg += f" ({files_skipped} skipped)"
    msg += "."
    if baselined:
        msg += f"\n  {baselined} existing finding{'s' if baselined != 1 else ''} ignored by baseline."
    return msg
