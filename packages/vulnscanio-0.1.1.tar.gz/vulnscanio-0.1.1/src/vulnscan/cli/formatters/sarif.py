"""SARIF 2.1.0 output, GitHub Code Scanning compatible.

References:
  * SARIF 2.1.0 spec:
    https://docs.oasis-open.org/sarif/sarif/v2.1.0/sarif-v2.1.0.html
  * GitHub's SARIF requirements:
    https://docs.github.com/en/code-security/code-scanning/integrating-with-code-scanning/sarif-support-for-code-scanning

Key design points:
  * `partialFingerprints` is populated so re-uploads match across runs
    and don't create duplicate alerts.
  * `ruleId` is consistent with our internal rule IDs.
  * `level` maps our severity to SARIF's three-level scale (error, warning, note).
  * Each rule is emitted once in `tool.driver.rules` and referenced by
    index — keeps the file small for repos with many findings of the
    same kind.
"""
from __future__ import annotations
import hashlib
import json
from collections.abc import Iterable

from vulnscan._core.scanner.types import Finding, Severity


# SARIF only has three levels; we collapse our five into them.
_SARIF_LEVEL = {
    Severity.CRITICAL: "error",
    Severity.HIGH: "error",
    Severity.MEDIUM: "warning",
    Severity.LOW: "note",
    Severity.INFO: "note",
}

_VERSION = "0.1.0"
_TOOL_NAME = "VulnScan"
_INFO_URI = "https://github.com/your-org/vulnscan"


def render(findings: Iterable[Finding]) -> str:
    findings = list(findings)

    # Build the rules section: one entry per unique rule_id.
    rule_index: dict[str, int] = {}
    rules_arr: list[dict] = []
    for f in findings:
        if f.rule_id in rule_index:
            continue
        rule_index[f.rule_id] = len(rules_arr)
        rule_entry: dict = {
            "id": f.rule_id,
            "name": f.rule_id,
            "shortDescription": {"text": f.title},
            "fullDescription": {"text": f.description},
            "help": {
                "text": f.recommendation,
                "markdown": f"**Recommendation:** {f.recommendation}",
            },
            "defaultConfiguration": {"level": _SARIF_LEVEL[f.severity]},
            "properties": {
                "category": f.category,
                "tags": [f.category, "security"],
                "precision": f.confidence.value,
            },
        }
        if f.cwe:
            rule_entry["properties"]["cwe"] = f.cwe
            rule_entry["properties"]["tags"].append(f.cwe)
        rules_arr.append(rule_entry)

    # Build results.
    results = []
    for f in findings:
        results.append({
            "ruleId": f.rule_id,
            "ruleIndex": rule_index[f.rule_id],
            "level": _SARIF_LEVEL[f.severity],
            "message": {"text": f.title},
            "locations": [{
                "physicalLocation": {
                    "artifactLocation": {
                        "uri": f.file_path,
                        "uriBaseId": "%SRCROOT%",
                    },
                    "region": {
                        "startLine": f.line_number,
                        **({"endLine": f.line_end} if f.line_end else {}),
                    },
                },
            }],
            # Stable fingerprint: GitHub uses this to deduplicate across runs.
            # Hash is over (rule_id, file, line_text-equivalent) so a moved
            # finding on the same line content stays the same alert.
            "partialFingerprints": {
                "primaryLocationLineHash": _line_fingerprint(f),
            },
            "properties": {
                "severity": f.severity.value,
                "confidence": f.confidence.value,
                "needs_review": f.needs_review,
            },
        })

    sarif = {
        "version": "2.1.0",
        "$schema": "https://raw.githubusercontent.com/oasis-tcs/sarif-spec/master/Schemata/sarif-schema-2.1.0.json",
        "runs": [{
            "tool": {
                "driver": {
                    "name": _TOOL_NAME,
                    "version": _VERSION,
                    "informationUri": _INFO_URI,
                    "rules": rules_arr,
                },
            },
            "results": results,
            "columnKind": "utf16CodeUnits",
        }],
    }
    return json.dumps(sarif, indent=2)


def _line_fingerprint(f: Finding) -> str:
    """Stable per-finding fingerprint for SARIF partialFingerprints.

    GitHub uses this to match the same finding across repeated uploads.
    We hash rule + relative path + line number; this matches GitHub's
    own behavior closely enough that re-uploads won't duplicate alerts.
    """
    payload = f"{f.rule_id}|{f.file_path}|{f.line_number}"
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()
