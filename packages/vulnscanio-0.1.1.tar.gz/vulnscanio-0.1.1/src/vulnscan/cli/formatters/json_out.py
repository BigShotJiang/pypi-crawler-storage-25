"""JSON output for scripts and CI.

Stable schema: vulnscan-cli/v1. Producers should bump the version
field on breaking changes; consumers should ignore unknown fields.
"""
from __future__ import annotations
import json
from collections.abc import Iterable
from datetime import datetime, timezone

from vulnscan._core.scanner.types import Finding


def render(
    findings: Iterable[Finding],
    *,
    files_scanned: int,
    files_skipped: int,
    elapsed_seconds: float,
    baselined: int = 0,
    diff_mode: bool = False,
) -> str:
    counts = {"critical": 0, "high": 0, "medium": 0, "low": 0, "info": 0}
    finding_objects = []
    for f in findings:
        counts[f.severity.value] += 1
        finding_objects.append({
            "rule_id": f.rule_id,
            "title": f.title,
            "severity": f.severity.value,
            "category": f.category,
            "cwe": f.cwe,
            "file_path": f.file_path,
            "line_number": f.line_number,
            "line_end": f.line_end,
            "code_snippet": f.code_snippet,
            "description": f.description,
            "recommendation": f.recommendation,
            "confidence": f.confidence.value,
            "needs_review": f.needs_review,
        })

    return json.dumps({
        "schema": "vulnscan-cli/v1",
        "generated_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "summary": {
            "total": len(finding_objects),
            **counts,
            "files_scanned": files_scanned,
            "files_skipped": files_skipped,
            "elapsed_seconds": round(elapsed_seconds, 3),
            "baselined": baselined,
            "diff_mode": diff_mode,
        },
        "findings": finding_objects,
    }, indent=2)
