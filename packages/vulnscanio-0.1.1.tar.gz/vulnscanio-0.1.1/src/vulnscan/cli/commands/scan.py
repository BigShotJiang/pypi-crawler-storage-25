"""`vulnscan scan PATH` — full repository scan."""
from __future__ import annotations
import argparse
import sys
import time
from pathlib import Path

from vulnscan._core.scanner.orchestrator import run_scan

from vulnscan import baseline as baseline_mod
from vulnscan.cli.formatters import github_pr, json_out, pretty, sarif


def add_parser(sub: argparse._SubParsersAction) -> None:
    p = sub.add_parser(
        "scan",
        help="Scan a directory tree for vulnerabilities.",
        description="Scan all source files under PATH and report findings.",
    )
    p.add_argument("path", nargs="?", default=".",
                   help="Directory to scan (default: current directory)")
    p.add_argument("--format", "-f", default="pretty",
                   choices=["pretty", "json", "sarif", "github-pr"],
                   help="Output format (default: pretty)")
    p.add_argument("--output", "-o",
                   help="Write output to this file instead of stdout")
    p.add_argument("--no-baseline", action="store_true",
                   help="Ignore .vulnscan-baseline.json and report all findings")
    p.add_argument("--severity", action="append", default=None,
                   choices=["critical", "high", "medium", "low", "info"],
                   help="Only report findings of these severities (repeatable)")
    p.add_argument("--fail-on", default=None,
                   choices=["critical", "high", "medium", "low", "any"],
                   help="Exit with status 1 if any finding of this severity or higher is reported")
    p.add_argument("--quiet", "-q", action="store_true",
                   help="Suppress progress output (errors still printed to stderr)")
    p.add_argument("--no-cache", action="store_true",
                   help="Disable the incremental scan cache. "
                        "Forces every file to be re-analyzed.")
    p.add_argument("--clear-cache", action="store_true",
                   help="Delete the cache before scanning. Useful when "
                        "the cache appears stale or corrupt.")
    p.set_defaults(func=run)


def run(args: argparse.Namespace) -> int:
    repo_root = Path(args.path).resolve()
    if not repo_root.exists():
        print(f"error: path does not exist: {repo_root}", file=sys.stderr)
        return 2
    if not repo_root.is_dir():
        print(f"error: path is not a directory: {repo_root}", file=sys.stderr)
        return 2

    # Optionally clear the cache before scanning
    if args.clear_cache:
        try:
            from vulnscan._core.scanner.cache import ScanCache
            with ScanCache(repo_root) as cache:
                cache.clear()
            if not args.quiet:
                print("Cache cleared.", file=sys.stderr)
        except Exception as e:
            print(f"warning: couldn't clear cache: {e}", file=sys.stderr)

    # Run the scanner
    start = time.perf_counter()
    progress = (lambda pct, msg: None) if args.quiet else _stderr_progress
    result = run_scan(repo_root, progress=progress, use_cache=not args.no_cache)
    elapsed = time.perf_counter() - start

    findings = result.findings

    # Severity filter
    if args.severity:
        wanted = set(args.severity)
        findings = [f for f in findings if f.severity.value in wanted]

    # Baseline filter
    baselined = 0
    if not args.no_baseline:
        baseline_path = repo_root / baseline_mod.BASELINE_FILENAME
        baseline = baseline_mod.load(baseline_path)
        findings, baselined = baseline_mod.filter_baselined(findings, baseline, repo_root)

    # Render
    output = _render(args.format, findings, result, elapsed, baselined)

    if args.output:
        Path(args.output).write_text(output, encoding="utf-8")
        if not args.quiet:
            print(f"Wrote {args.output}", file=sys.stderr)
    else:
        print(output)

    # Exit code
    return _exit_code(findings, args.fail_on)


def _render(fmt: str, findings, result, elapsed: float, baselined: int) -> str:
    if fmt == "json":
        return json_out.render(
            findings, files_scanned=result.files_scanned,
            files_skipped=len(result.files_skipped),
            elapsed_seconds=elapsed, baselined=baselined,
        )
    if fmt == "sarif":
        return sarif.render(findings)
    if fmt == "github-pr":
        return github_pr.render(findings)
    # pretty (default)
    return pretty.render(
        findings, files_scanned=result.files_scanned,
        files_skipped=len(result.files_skipped),
        elapsed_seconds=elapsed, baselined=baselined,
    )


def _exit_code(findings, fail_on: str | None) -> int:
    if not fail_on:
        return 0
    rank = {"critical": 0, "high": 1, "medium": 2, "low": 3, "any": 99}
    threshold = rank[fail_on]
    for f in findings:
        sev_rank = {"critical": 0, "high": 1, "medium": 2, "low": 3, "info": 4}[f.severity.value]
        if sev_rank <= threshold or fail_on == "any":
            return 1
    return 0


def _stderr_progress(pct: int, msg: str) -> None:
    # Minimal progress to stderr — won't pollute stdout output formats
    if pct in (0, 100) or pct % 25 == 0:
        print(f"  [{pct:3d}%] {msg}", file=sys.stderr)
