"""`vulnscan fix` — propose auto-fixes for findings, with retest gating.

Usage:
    vulnscan fix .                    # show all proposed fixes (dry run)
    vulnscan fix . --apply            # write accepted fixes to disk
    vulnscan fix . --rule EVAL-PY     # only fix this rule
    vulnscan fix path/to/file.py      # only this file

Exit codes:
    0 - all proposed fixes passed the retest gate
    1 - some fixes were rejected by the gate
    2 - usage / scan error
"""
from __future__ import annotations
import argparse
import sys
from pathlib import Path

from vulnscan._core.fixers import fixable_rule_ids, propose_and_gate
from vulnscan._core.scanner.orchestrator import run_scan
from vulnscan._core.scanner.types import Finding


def add_parser(sub: argparse._SubParsersAction) -> None:
    p = sub.add_parser(
        "fix",
        help="Propose auto-fixes for findings (dry-run by default).",
        description=(
            "Generate candidate fixes for findings and run each through "
            "the retest gate. By default, fixes are PRINTED only (dry run); "
            "pass --apply to write accepted fixes to disk."
        ),
    )
    p.add_argument("path", nargs="?", default=".",
                   help="Directory or file to scan and fix (default: current dir)")
    p.add_argument("--apply", action="store_true",
                   help="Write accepted fixes to disk. Without this, fix is a dry-run.")
    p.add_argument("--rule", action="append", default=None,
                   help="Only attempt to fix findings with this rule_id (repeatable).")
    p.add_argument("--quiet", "-q", action="store_true",
                   help="Suppress progress; print final fixes only.")
    p.set_defaults(func=run)


def run(args: argparse.Namespace) -> int:
    target = Path(args.path).resolve()
    if not target.exists():
        print(f"error: path does not exist: {target}", file=sys.stderr)
        return 2

    # The scanner walks directories; for a single file, scan its parent
    # and filter to that file.
    if target.is_file():
        scan_root = target.parent
        only_file = target
    else:
        scan_root = target
        only_file = None

    if not args.quiet:
        print(f"Scanning {scan_root}...", file=sys.stderr)
    result = run_scan(scan_root, use_cache=False)

    findings = result.findings
    if only_file is not None:
        rel = str(only_file.relative_to(scan_root))
        findings = [f for f in findings if f.file_path == rel]
    if args.rule:
        wanted = set(args.rule)
        findings = [f for f in findings if f.rule_id in wanted]

    fixable = fixable_rule_ids()
    candidates = [f for f in findings if f.rule_id in fixable]

    if not candidates:
        print("No fixable findings.", file=sys.stderr)
        return 0

    # Group findings by file so we can compute pre_existing once per file.
    by_file: dict[str, list[Finding]] = {}
    for f in result.findings:
        by_file.setdefault(f.file_path, []).append(f)

    accepted: list[tuple[Finding, str, str]] = []   # (finding, diff, fixed_text)
    rejected: list[tuple[Finding, str]] = []

    for finding in candidates:
        file_abs = scan_root / finding.file_path
        try:
            content = file_abs.read_text(encoding="utf-8")
        except OSError as e:
            rejected.append((finding, f"could not read file: {e}"))
            continue

        result_obj = propose_and_gate(
            finding, content,
            pre_existing_findings=by_file.get(finding.file_path),
        )
        if result_obj is None:
            rejected.append((finding, "fixer declined (no safe fix available)"))
            continue
        if result_obj.accepted:
            accepted.append((finding, result_obj.candidate.diff,
                             result_obj.candidate.fixed_text))
        else:
            rejected.append((finding, result_obj.rejection_reason or "rejected by gate"))

    # Print the accepted fixes
    for finding, diff, _ in accepted:
        print(f"\n{'─' * 60}")
        print(f"  {finding.rule_id} at {finding.file_path}:{finding.line_number}")
        print(f"  PASS — fix accepted by retest gate")
        print(f"{'─' * 60}")
        print(diff)

    # Print rejection summaries to stderr
    if rejected and not args.quiet:
        print(f"\n{len(rejected)} finding(s) could not be auto-fixed:", file=sys.stderr)
        for finding, reason in rejected:
            print(f"  {finding.rule_id} at {finding.file_path}:{finding.line_number} — {reason}",
                  file=sys.stderr)

    # Apply or summarize.
    #
    # NOTE on multi-fix application:
    #   Each fix candidate was generated against the ORIGINAL file
    #   content. If we wrote them all naively, the second fix's
    #   `fixed_text` would reset the file (clobbering the first fix).
    #
    #   So when --apply is set, we re-process each accepted candidate
    #   sequentially: read the file's CURRENT content, regenerate the
    #   fix against that, gate it again, and write. This is slower
    #   (one rescan per fix) but produces the correct cumulative diff
    #   and re-validates every fix in its actual post-fix context.
    if args.apply:
        applied = 0
        for finding, _, _ in accepted:
            file_abs = scan_root / finding.file_path
            try:
                current = file_abs.read_text(encoding="utf-8")
            except OSError as e:
                print(f"error: could not read {file_abs}: {e}", file=sys.stderr)
                continue

            # Re-scan to get the up-to-date pre-existing findings (other
            # fixes may have already been applied in this session).
            current_scan = run_scan(scan_root, use_cache=False)
            current_pre = [f for f in current_scan.findings
                           if f.file_path == finding.file_path]
            # Also: the original `finding` may have shifted lines after
            # earlier fixes. Find its current location by snippet match.
            current_target = _find_matching_finding(finding, current_pre)
            if current_target is None:
                # Already fixed (e.g. one fix happened to resolve another)
                continue

            result_obj = propose_and_gate(
                current_target, current,
                pre_existing_findings=current_pre,
            )
            if result_obj is None or not result_obj.accepted:
                # Fix didn't survive on the now-modified file; skip
                continue
            try:
                file_abs.write_text(result_obj.candidate.fixed_text, encoding="utf-8")
                applied += 1
            except OSError as e:
                print(f"error: could not write {file_abs}: {e}", file=sys.stderr)
                return 2
        print(f"\nApplied {applied} fix(es).", file=sys.stderr)
    else:
        print(f"\n{len(accepted)} fix(es) ready to apply. Re-run with --apply to write to disk.",
              file=sys.stderr)

    return 0 if not rejected else 1


def _find_matching_finding(target: Finding, candidates: list[Finding]) -> Finding | None:
    """After other fixes shift lines, find `target` in the new findings.

    Match priority:
      1. Exact (rule_id, line_number) — fastest path
      2. (rule_id, normalized offending text) — survives line shifts.
         Reuses the retest gate's identity logic so the regex
         analyzer's "context block" snippets and the AST analyzer's
         "matched expression" snippets both reduce to the same body.
      3. None — target finding has been resolved or vanished
    """
    # Exact line match
    for c in candidates:
        if c.rule_id == target.rule_id and c.line_number == target.line_number:
            return c
    # Loose match using the retest gate's identity logic
    from vulnscan._core.fixers.apply import _finding_identity_for_dedup
    target_id = _finding_identity_for_dedup(target)
    if target_id[2]:   # only meaningful if we have body text
        for c in candidates:
            if _finding_identity_for_dedup(c) == target_id:
                return c
    return None
