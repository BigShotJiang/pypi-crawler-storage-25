"""`vulnscan diff BASE..HEAD` — only findings on changed lines.

This is the killer feature for PR-based workflows. By scanning the
full repo but reporting only findings whose line was touched in the
diff, we answer the developer's actual question: "Did MY change
introduce something new?"
"""
from __future__ import annotations
import argparse
import sys
import time
from pathlib import Path

from vulnscan._core.scanner.orchestrator import run_scan

from vulnscan import baseline as baseline_mod
from vulnscan import git_utils
from vulnscan.cli.commands.scan import _exit_code, _stderr_progress, _render


def add_parser(sub: argparse._SubParsersAction) -> None:
    p = sub.add_parser(
        "diff",
        help="Scan a repo and show only findings on lines changed in a git range.",
        description="Run a scan, then filter to only findings whose line "
                    "was added or modified between BASE and HEAD.",
    )
    p.add_argument("range", help="Git range, e.g. 'main' or 'main..HEAD' or 'origin/main..feature-branch'")
    p.add_argument("path", nargs="?", default=".",
                   help="Directory to scan (default: current directory)")
    p.add_argument("--format", "-f", default="pretty",
                   choices=["pretty", "json", "sarif", "github-pr"],
                   help="Output format (default: pretty)")
    p.add_argument("--output", "-o", help="Write output to this file")
    p.add_argument("--no-baseline", action="store_true",
                   help="Ignore .vulnscan-baseline.json")
    p.add_argument("--fail-on", default=None,
                   choices=["critical", "high", "medium", "low", "any"],
                   help="Exit with status 1 if any finding meets this threshold")
    p.add_argument("--quiet", "-q", action="store_true")
    p.set_defaults(func=run)


def run(args: argparse.Namespace) -> int:
    repo_root = Path(args.path).resolve()
    if not repo_root.exists():
        print(f"error: path does not exist: {repo_root}", file=sys.stderr)
        return 2

    # Parse range
    if ".." in args.range:
        base, _, head = args.range.partition("..")
        head = head or "HEAD"
    else:
        base, head = args.range, "HEAD"

    try:
        changed = git_utils.changed_files_and_lines(repo_root, base, head)
    except RuntimeError as e:
        print(f"error: {e}", file=sys.stderr)
        return 2

    if not changed:
        if args.format == "pretty":
            print("\n  No files changed in this range.")
        elif args.format == "github-pr":
            print("## 🛡️ VulnScan\n\n_No files changed in this PR._")
        elif args.format == "json":
            print('{"schema":"vulnscan-cli/v1","summary":{"total":0},"findings":[]}')
        else:  # sarif
            print('{"version":"2.1.0","runs":[{"tool":{"driver":{"name":"VulnScan"}},"results":[]}]}')
        return 0

    # Scan, then filter
    start = time.perf_counter()
    progress = (lambda pct, msg: None) if args.quiet else _stderr_progress
    result = run_scan(repo_root, progress=progress)
    elapsed = time.perf_counter() - start

    findings = git_utils.filter_findings_to_diff(result.findings, changed)

    baselined = 0
    if not args.no_baseline:
        baseline_path = repo_root / baseline_mod.BASELINE_FILENAME
        bl = baseline_mod.load(baseline_path)
        findings, baselined = baseline_mod.filter_baselined(findings, bl, repo_root)

    # Custom render: pass diff_mode=True for pretty/github-pr
    output = _render_with_diff_mode(
        args.format, findings, result, elapsed, baselined,
    )

    if args.output:
        Path(args.output).write_text(output, encoding="utf-8")
    else:
        print(output)

    return _exit_code(findings, args.fail_on)


def _render_with_diff_mode(fmt, findings, result, elapsed, baselined):
    """Like scan._render, but signals diff_mode for the formatters that care."""
    from vulnscan.cli.formatters import github_pr, json_out, pretty, sarif
    if fmt == "json":
        return json_out.render(
            findings, files_scanned=result.files_scanned,
            files_skipped=len(result.files_skipped),
            elapsed_seconds=elapsed, baselined=baselined, diff_mode=True,
        )
    if fmt == "sarif":
        return sarif.render(findings)
    if fmt == "github-pr":
        return github_pr.render(findings, diff_mode=True)
    return pretty.render(
        findings, files_scanned=result.files_scanned,
        files_skipped=len(result.files_skipped),
        elapsed_seconds=elapsed, baselined=baselined, diff_mode=True,
    )
