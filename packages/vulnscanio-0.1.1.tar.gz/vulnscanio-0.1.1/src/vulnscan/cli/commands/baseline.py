"""`vulnscan baseline` — manage the baseline file."""
from __future__ import annotations
import argparse
import sys
from pathlib import Path

from vulnscan._core.scanner.orchestrator import run_scan

from vulnscan import baseline as baseline_mod


def add_parser(sub: argparse._SubParsersAction) -> None:
    p = sub.add_parser(
        "baseline",
        help="Create or inspect a baseline file.",
        description="A baseline records existing findings so they stop being "
                    "reported. Useful when adopting VulnScan on a legacy repo.",
    )
    bsub = p.add_subparsers(dest="action", required=True)

    create = bsub.add_parser("create", help="Run a scan and write a baseline.")
    create.add_argument("path", nargs="?", default=".",
                        help="Directory to scan (default: current)")
    create.add_argument("--output", default=None,
                        help=f"Path to write (default: <path>/{baseline_mod.BASELINE_FILENAME})")
    create.set_defaults(func=run_create)

    show = bsub.add_parser("show", help="Show a baseline file.")
    show.add_argument("path", nargs="?", default=".",
                      help="Repo root containing the baseline file")
    show.set_defaults(func=run_show)


def run_create(args: argparse.Namespace) -> int:
    repo_root = Path(args.path).resolve()
    out_path = Path(args.output) if args.output else repo_root / baseline_mod.BASELINE_FILENAME

    print(f"Scanning {repo_root} ...", file=sys.stderr)
    result = run_scan(repo_root)
    bl = baseline_mod.create(result.findings, repo_root)
    out_path.write_text(bl.to_json(), encoding="utf-8")

    print(
        f"\nWrote baseline: {out_path}\n"
        f"  {len(bl.fingerprints)} finding{'s' if len(bl.fingerprints) != 1 else ''} captured.\n"
        f"  These will be suppressed by `vulnscan scan` and `vulnscan diff` "
        f"unless --no-baseline is passed.",
        file=sys.stderr,
    )
    return 0


def run_show(args: argparse.Namespace) -> int:
    repo_root = Path(args.path).resolve()
    path = repo_root / baseline_mod.BASELINE_FILENAME
    bl = baseline_mod.load(path)
    if bl is None:
        print(f"No baseline file at {path}", file=sys.stderr)
        return 2
    print(f"Baseline: {path}")
    print(f"Created:  {bl.created_at}")
    print(f"Findings: {len(bl.fingerprints)}")
    return 0
