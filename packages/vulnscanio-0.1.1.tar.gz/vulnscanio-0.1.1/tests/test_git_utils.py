"""Tests for git diff parsing."""
from __future__ import annotations
import subprocess
import tempfile
from pathlib import Path

import pytest

import vulnscan_cli  # noqa: F401

from vulnscan_cli import git_utils
from vulnscan._core.scanner.types import Confidence, Finding, Severity


def _run(cmd: list[str], cwd: Path) -> None:
    subprocess.run(cmd, cwd=cwd, check=True, capture_output=True)


def _make_git_repo() -> Path:
    """Initialize a temporary git repo with two commits, second adds eval()."""
    tmp = Path(tempfile.mkdtemp())
    _run(["git", "init", "-q", "-b", "main"], tmp)
    _run(["git", "config", "user.email", "t@t"], tmp)
    _run(["git", "config", "user.name", "T"], tmp)

    (tmp / "app.py").write_text("x = 1\ny = 2\n")
    _run(["git", "add", "."], tmp)
    _run(["git", "commit", "-q", "-m", "initial"], tmp)

    (tmp / "app.py").write_text("x = 1\ny = 2\nresult = eval(input)\n")
    (tmp / "new.py").write_text("import os\nos.system(cmd)\n")
    _run(["git", "add", "."], tmp)
    _run(["git", "commit", "-q", "-m", "second"], tmp)
    return tmp


def test_changed_lines_includes_only_added_lines():
    repo = _make_git_repo()
    changed = git_utils.changed_files_and_lines(repo, "HEAD~1", "HEAD")

    # app.py: line 3 is the new eval line
    assert "app.py" in changed
    assert 3 in changed["app.py"]
    # Lines 1 and 2 weren't touched
    assert 1 not in changed["app.py"]
    assert 2 not in changed["app.py"]

    # new.py: every line is "new"
    assert "new.py" in changed
    assert 1 in changed["new.py"]
    assert 2 in changed["new.py"]


def test_filter_findings_only_includes_changed_lines():
    f_old = Finding(
        rule_id="A", title="old", severity=Severity.HIGH, category="x",
        file_path="app.py", line_number=1, code_snippet="", description="",
        recommendation="", confidence=Confidence.HIGH,
    )
    f_new = Finding(
        rule_id="B", title="new", severity=Severity.HIGH, category="x",
        file_path="app.py", line_number=3, code_snippet="", description="",
        recommendation="", confidence=Confidence.HIGH,
    )
    changed = {"app.py": {3}}
    out = git_utils.filter_findings_to_diff([f_old, f_new], changed)
    assert out == [f_new]


def test_filter_excludes_files_not_in_diff():
    f = Finding(
        rule_id="A", title="t", severity=Severity.HIGH, category="x",
        file_path="other.py", line_number=1, code_snippet="", description="",
        recommendation="", confidence=Confidence.HIGH,
    )
    out = git_utils.filter_findings_to_diff([f], {"app.py": {1, 2, 3}})
    assert out == []


def test_invalid_range_raises_runtime_error():
    repo = _make_git_repo()
    with pytest.raises(RuntimeError):
        git_utils.changed_files_and_lines(repo, "no-such-ref", "HEAD")
