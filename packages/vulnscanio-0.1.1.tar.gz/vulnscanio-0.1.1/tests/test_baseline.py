"""Tests for baseline file behavior."""
from __future__ import annotations
import json
import tempfile
from pathlib import Path

# This bootstrap import adds backend/ to sys.path
import vulnscan_cli  # noqa: F401

from vulnscan._core.scanner.types import Confidence, Finding, Severity
from vulnscan_cli import baseline


def _mk_finding(rule_id: str = "TEST-RULE", file: str = "a.py", line: int = 1) -> Finding:
    return Finding(
        rule_id=rule_id, title="t", severity=Severity.HIGH, category="injection",
        file_path=file, line_number=line, code_snippet="", description="d",
        recommendation="r", confidence=Confidence.HIGH,
    )


def test_create_and_load_roundtrip():
    with tempfile.TemporaryDirectory() as tmp:
        root = Path(tmp)
        (root / "a.py").write_text("eval(x)\n")
        f = _mk_finding(file="a.py", line=1)
        bl = baseline.create([f], root)

        # Write and reload
        target = root / baseline.BASELINE_FILENAME
        target.write_text(bl.to_json())
        loaded = baseline.load(target)

        assert loaded is not None
        assert loaded.fingerprints == bl.fingerprints
        assert loaded.contains(f, root)


def test_filter_baselined_separates_old_and_new():
    with tempfile.TemporaryDirectory() as tmp:
        root = Path(tmp)
        (root / "a.py").write_text("eval(x)\n")
        (root / "b.py").write_text("os.system(c)\n")
        old = _mk_finding(rule_id="EVAL-PY", file="a.py", line=1)
        new = _mk_finding(rule_id="CMDI-PY", file="b.py", line=1)
        bl = baseline.create([old], root)

        kept, suppressed = baseline.filter_baselined([old, new], bl, root)
        assert suppressed == 1
        assert kept == [new]


def test_load_returns_none_for_missing_file():
    with tempfile.TemporaryDirectory() as tmp:
        assert baseline.load(Path(tmp) / "does-not-exist.json") is None


def test_load_returns_none_for_corrupt_file():
    with tempfile.TemporaryDirectory() as tmp:
        path = Path(tmp) / "bl.json"
        path.write_text("{ not valid json")
        assert baseline.load(path) is None


def test_fingerprint_changes_when_line_text_changes():
    """Editing the offending line should make the fingerprint change,
    so the baseline no longer suppresses it (we want to re-flag edited code).
    """
    with tempfile.TemporaryDirectory() as tmp:
        root = Path(tmp)
        target = root / "a.py"
        target.write_text("eval(safe_value)\n")
        f = _mk_finding(file="a.py", line=1)
        fp1 = baseline.fingerprint_for(f, root)

        target.write_text("eval(user_input)\n")  # line text changed
        fp2 = baseline.fingerprint_for(f, root)

        assert fp1 != fp2


def test_fingerprint_stable_when_only_line_number_changes():
    """If a developer adds an import above, line numbers shift but
    fingerprint should stay the same — we don't re-flag the unchanged line.
    """
    with tempfile.TemporaryDirectory() as tmp:
        root = Path(tmp)
        target = root / "a.py"
        target.write_text("eval(user_input)\n")
        f1 = _mk_finding(file="a.py", line=1)
        fp_a = baseline.fingerprint_for(f1, root)

        # Add an import; same offending line is now on line 2
        target.write_text("import os\neval(user_input)\n")
        f2 = _mk_finding(file="a.py", line=2)
        fp_b = baseline.fingerprint_for(f2, root)

        assert fp_a == fp_b
