"""Tests for the four output formatters."""
from __future__ import annotations
import json

import vulnscan_cli  # noqa: F401

from vulnscan._core.scanner.types import Confidence, Finding, Severity
from vulnscan_cli.formatters import github_pr, json_out, pretty, sarif


def _f(**kw) -> Finding:
    base = dict(
        rule_id="EVAL-PY", title="Use of eval()", severity=Severity.HIGH,
        category="injection", file_path="src/app.py", line_number=42,
        code_snippet="> 42 | result = eval(x)",
        description="eval() runs arbitrary code.",
        recommendation="Avoid eval. Use ast.literal_eval.",
        confidence=Confidence.HIGH, cwe="CWE-95", needs_review=False,
    )
    base.update(kw)
    return Finding(**base)


# --- pretty ---

def test_pretty_no_findings_shows_clean_message():
    out = pretty.render([], files_scanned=10, files_skipped=0, elapsed_seconds=0.4)
    assert "No findings" in out
    assert "10 file" in out


def test_pretty_renders_finding_with_location_and_fix():
    out = pretty.render([_f()], files_scanned=10, files_skipped=0, elapsed_seconds=0.4)
    assert "src/app.py:42" in out
    assert "EVAL-PY" in out
    assert "HIGH" in out
    assert "ast.literal_eval" in out


def test_pretty_summary_mentions_severity_breakdown():
    out = pretty.render(
        [_f(), _f(severity=Severity.CRITICAL)],
        files_scanned=10, files_skipped=0, elapsed_seconds=0.5,
    )
    assert "1 critical" in out
    assert "1 high" in out


def test_pretty_summary_mentions_baselined():
    out = pretty.render(
        [_f()], files_scanned=10, files_skipped=0,
        elapsed_seconds=0.3, baselined=5,
    )
    assert "5 existing finding" in out
    assert "baseline" in out.lower()


def test_pretty_diff_mode_clean_message():
    out = pretty.render(
        [], files_scanned=2, files_skipped=0, elapsed_seconds=0.1, diff_mode=True,
    )
    assert "changed" in out.lower()


# --- json ---

def test_json_schema_and_summary():
    raw = json_out.render([_f()], files_scanned=10, files_skipped=0, elapsed_seconds=0.5)
    data = json.loads(raw)
    assert data["schema"] == "vulnscan-cli/v1"
    assert data["summary"]["total"] == 1
    assert data["summary"]["high"] == 1
    assert len(data["findings"]) == 1
    assert data["findings"][0]["rule_id"] == "EVAL-PY"


def test_json_empty_findings_still_valid():
    raw = json_out.render([], files_scanned=0, files_skipped=0, elapsed_seconds=0.0)
    data = json.loads(raw)
    assert data["summary"]["total"] == 0
    assert data["findings"] == []


# --- sarif ---

def test_sarif_is_valid_2_1_0():
    raw = sarif.render([_f()])
    data = json.loads(raw)
    assert data["version"] == "2.1.0"
    assert "$schema" in data
    runs = data["runs"]
    assert len(runs) == 1
    assert runs[0]["tool"]["driver"]["name"] == "VulnScan"


def test_sarif_results_carry_partial_fingerprints():
    """GitHub uses partialFingerprints to dedupe re-uploaded findings."""
    raw = sarif.render([_f()])
    data = json.loads(raw)
    result = data["runs"][0]["results"][0]
    assert "partialFingerprints" in result
    assert "primaryLocationLineHash" in result["partialFingerprints"]


def test_sarif_severity_maps_to_correct_level():
    """SARIF only has error/warning/note. Critical+High → error,
    Medium → warning, Low+Info → note."""
    raw = sarif.render([
        _f(severity=Severity.CRITICAL, rule_id="C"),
        _f(severity=Severity.HIGH, rule_id="H"),
        _f(severity=Severity.MEDIUM, rule_id="M"),
        _f(severity=Severity.LOW, rule_id="L"),
    ])
    data = json.loads(raw)
    levels = {r["ruleId"]: r["level"] for r in data["runs"][0]["results"]}
    assert levels["C"] == "error"
    assert levels["H"] == "error"
    assert levels["M"] == "warning"
    assert levels["L"] == "note"


def test_sarif_dedupes_rules_in_driver():
    """Two findings of the same rule produce ONE entry in tool.driver.rules."""
    raw = sarif.render([_f(line_number=1), _f(line_number=2), _f(line_number=3)])
    data = json.loads(raw)
    rules = data["runs"][0]["tool"]["driver"]["rules"]
    assert len(rules) == 1
    assert rules[0]["id"] == "EVAL-PY"


def test_sarif_uri_is_relative():
    """GitHub requires repo-relative paths."""
    raw = sarif.render([_f(file_path="src/auth.py")])
    data = json.loads(raw)
    loc = data["runs"][0]["results"][0]["locations"][0]["physicalLocation"]
    assert loc["artifactLocation"]["uri"] == "src/auth.py"
    assert loc["artifactLocation"]["uriBaseId"] == "%SRCROOT%"


# --- github-pr ---

def test_github_pr_no_findings_shows_check():
    out = github_pr.render([])
    assert "✅" in out
    assert "VulnScan" in out


def test_github_pr_table_contains_severity_emoji():
    out = github_pr.render([_f(severity=Severity.CRITICAL)])
    assert "🔴" in out
    assert "Critical" in out
    assert "src/app.py:42" in out


def test_github_pr_truncates_when_too_many_findings():
    many = [_f(line_number=i) for i in range(1, 100)]
    out = github_pr.render(many)
    assert "and" in out and "more" in out


def test_github_pr_diff_mode_in_header():
    out = github_pr.render([_f()], diff_mode=True)
    assert "changed lines" in out


def test_github_pr_escapes_pipe_in_title():
    out = github_pr.render([_f(title="A | B")])
    assert "A \\| B" in out


def test_github_pr_link_when_repo_url_provided():
    out = github_pr.render([_f()], repo_url="https://github.com/o/r", commit_sha="abc")
    assert "https://github.com/o/r/blob/abc/src/app.py#L42" in out
