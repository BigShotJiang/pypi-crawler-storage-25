"""End-to-end CLI tests.

Exercise the actual `main()` function with synthetic repos and assert
against captured stdout/stderr. These are slower than unit tests but
catch wiring bugs the unit tests miss.
"""
from __future__ import annotations
import json
import subprocess
import tempfile
from pathlib import Path

import pytest

import vulnscan_cli  # noqa: F401
from vulnscan_cli.main import main


def _seed_vuln_repo(root: Path) -> None:
    (root / "src").mkdir()
    (root / "src" / "auth.py").write_text(
        'AWS_KEY = "AKIAIOSFODNN7EXAMPLE"\n'
        'import os\n'
        'os.system(user_input)\n'
    )
    (root / "src" / "ok.py").write_text("x = 1\n")


def test_scan_pretty_default(capsys):
    with tempfile.TemporaryDirectory() as tmp:
        _seed_vuln_repo(Path(tmp))
        rc = main(["scan", tmp, "--quiet"])
        out = capsys.readouterr().out
    assert rc == 0
    assert "AKIAIOSFODNN7EXAMPLE" not in out  # we don't dump the secret
    assert "SECRET-AWS-AKID" in out
    assert "src/auth.py:1" in out
    assert "Found" in out


def test_scan_json_format_parses(capsys):
    with tempfile.TemporaryDirectory() as tmp:
        _seed_vuln_repo(Path(tmp))
        rc = main(["scan", tmp, "--format", "json", "--quiet"])
        out = capsys.readouterr().out
    assert rc == 0
    data = json.loads(out)
    assert data["schema"] == "vulnscan-cli/v1"
    assert data["summary"]["critical"] >= 1
    rule_ids = {f["rule_id"] for f in data["findings"]}
    assert "SECRET-AWS-AKID" in rule_ids


def test_scan_sarif_format_parses(capsys):
    with tempfile.TemporaryDirectory() as tmp:
        _seed_vuln_repo(Path(tmp))
        rc = main(["scan", tmp, "--format", "sarif", "--quiet"])
        out = capsys.readouterr().out
    assert rc == 0
    data = json.loads(out)
    assert data["version"] == "2.1.0"
    assert data["runs"][0]["tool"]["driver"]["name"] == "VulnScan"


def test_scan_github_pr_format_has_emoji(capsys):
    with tempfile.TemporaryDirectory() as tmp:
        _seed_vuln_repo(Path(tmp))
        rc = main(["scan", tmp, "--format", "github-pr", "--quiet"])
        out = capsys.readouterr().out
    assert rc == 0
    assert "VulnScan" in out
    assert "🔴" in out


def test_scan_severity_filter(capsys):
    with tempfile.TemporaryDirectory() as tmp:
        _seed_vuln_repo(Path(tmp))
        rc = main(["scan", tmp, "--severity", "critical", "--format", "json", "--quiet"])
        data = json.loads(capsys.readouterr().out)
    severities = {f["severity"] for f in data["findings"]}
    assert severities <= {"critical"}


def test_scan_fail_on_critical_returns_1(capsys):
    with tempfile.TemporaryDirectory() as tmp:
        _seed_vuln_repo(Path(tmp))
        rc = main(["scan", tmp, "--fail-on", "critical", "--quiet"])
    capsys.readouterr()
    assert rc == 1


def test_scan_fail_on_critical_returns_0_when_clean(capsys, tmp_path):
    (tmp_path / "ok.py").write_text("x = 1\n")
    rc = main(["scan", str(tmp_path), "--fail-on", "critical", "--quiet"])
    capsys.readouterr()
    assert rc == 0


def test_baseline_create_and_then_scan_suppresses(capsys, tmp_path):
    _seed_vuln_repo(tmp_path)

    rc = main(["baseline", "create", str(tmp_path)])
    capsys.readouterr()
    assert rc == 0
    assert (tmp_path / ".vulnscan-baseline.json").exists()

    # After baselining, scan should report 0 findings
    rc = main(["scan", str(tmp_path), "--format", "json", "--quiet"])
    out = capsys.readouterr().out
    data = json.loads(out)
    assert data["summary"]["total"] == 0
    assert data["summary"]["baselined"] >= 1


def test_baseline_show(capsys, tmp_path):
    _seed_vuln_repo(tmp_path)
    main(["baseline", "create", str(tmp_path)])
    capsys.readouterr()

    rc = main(["baseline", "show", str(tmp_path)])
    out = capsys.readouterr().out
    assert rc == 0
    assert "Findings:" in out


def test_no_baseline_flag_disables_suppression(capsys, tmp_path):
    _seed_vuln_repo(tmp_path)
    main(["baseline", "create", str(tmp_path)])
    capsys.readouterr()

    rc = main(["scan", str(tmp_path), "--no-baseline", "--format", "json", "--quiet"])
    data = json.loads(capsys.readouterr().out)
    assert data["summary"]["total"] >= 1


def test_scan_missing_path_returns_2(capsys):
    rc = main(["scan", "/no/such/dir/anywhere", "--quiet"])
    capsys.readouterr()
    assert rc == 2


def test_diff_command_e2e(capsys):
    """End-to-end: a real git repo, a real diff, and findings filtered to it."""
    with tempfile.TemporaryDirectory() as tmp:
        repo = Path(tmp)
        # init
        for cmd in (["git", "init", "-q", "-b", "main"],
                    ["git", "config", "user.email", "t@t"],
                    ["git", "config", "user.name", "T"]):
            subprocess.run(cmd, cwd=repo, check=True, capture_output=True)
        (repo / "old.py").write_text("x = 1\n")
        subprocess.run(["git", "add", "."], cwd=repo, check=True, capture_output=True)
        subprocess.run(["git", "commit", "-q", "-m", "init"], cwd=repo, check=True, capture_output=True)
        # second commit adds vulnerable code
        (repo / "new.py").write_text('AWS = "AKIAIOSFODNN7EXAMPLE"\n')
        subprocess.run(["git", "add", "."], cwd=repo, check=True, capture_output=True)
        subprocess.run(["git", "commit", "-q", "-m", "second"], cwd=repo, check=True, capture_output=True)

        rc = main(["diff", "HEAD~1..HEAD", str(repo), "--format", "json", "--quiet"])
        out = capsys.readouterr().out
    data = json.loads(out)
    rule_ids = [f["rule_id"] for f in data["findings"]]
    assert "SECRET-AWS-AKID" in rule_ids
    assert data["summary"]["diff_mode"] is True


def test_version_flag(capsys):
    with pytest.raises(SystemExit) as exc:
        main(["--version"])
    assert exc.value.code == 0
    out = capsys.readouterr().out
    assert "vulnscan" in out.lower()


# --- Phase 3: cache flags ---

def test_no_cache_flag_disables_cache(capsys, tmp_path):
    """--no-cache must skip the cache lookup entirely.

    Verified by checking that the .vulnscan directory isn't even
    created when --no-cache is set.
    """
    _seed_vuln_repo(tmp_path)
    rc = main(["scan", str(tmp_path), "--no-cache", "--format", "json", "--quiet"])
    capsys.readouterr()
    assert rc == 0
    # The cache directory should NOT exist
    assert not (tmp_path / ".vulnscan").exists(), \
        "--no-cache should not create the cache directory"


def test_cache_persists_across_invocations(capsys, tmp_path):
    """First scan creates the cache; second scan uses it."""
    _seed_vuln_repo(tmp_path)
    rc = main(["scan", str(tmp_path), "--format", "json", "--quiet"])
    capsys.readouterr()
    assert rc == 0
    # Cache db should exist after the first scan
    assert (tmp_path / ".vulnscan" / "cache.db").exists()
    # Second scan should still produce identical findings
    rc = main(["scan", str(tmp_path), "--format", "json", "--quiet"])
    out = capsys.readouterr().out
    data = json.loads(out)
    rule_ids = {f["rule_id"] for f in data["findings"]}
    assert "SECRET-AWS-AKID" in rule_ids


def test_clear_cache_flag(capsys, tmp_path):
    """--clear-cache empties the cache before scanning."""
    _seed_vuln_repo(tmp_path)
    main(["scan", str(tmp_path), "--quiet"])
    capsys.readouterr()
    assert (tmp_path / ".vulnscan" / "cache.db").exists()
    # Clear and rescan
    rc = main(["scan", str(tmp_path), "--clear-cache", "--format", "json", "--quiet"])
    out = capsys.readouterr().out
    assert rc == 0
    # Same findings reported
    data = json.loads(out)
    assert data["summary"]["total"] >= 1
