import numpy as np
import pandas as pd
from scipy.stats import chi2_contingency, ks_2samp


def population_stability_index(expected, actual, bins=10):
    """
    Calculate Population Stability Index for one numeric feature.
    """
    expected = pd.Series(expected).dropna()
    actual = pd.Series(actual).dropna()
    if expected.empty or actual.empty:
        return np.nan

    breakpoints = np.unique(np.quantile(expected, np.linspace(0, 1, bins + 1)))
    if len(breakpoints) <= 2:
        return np.nan

    expected_counts, _ = np.histogram(expected, bins=breakpoints)
    actual_counts, _ = np.histogram(actual, bins=breakpoints)
    expected_pct = np.maximum(expected_counts / expected_counts.sum(), 1e-6)
    actual_pct = np.maximum(actual_counts / actual_counts.sum(), 1e-6)
    return np.sum((actual_pct - expected_pct) * np.log(actual_pct / expected_pct))


def compare_train_test_distributions(train_df, test_df, categorical_threshold=20):
    """
    Compare train and test distributions with KS, chi-square, and PSI where appropriate.
    """
    rows = []
    common_columns = [col for col in train_df.columns if col in test_df.columns]

    for col in common_columns:
        train_col = train_df[col].dropna()
        test_col = test_df[col].dropna()
        is_numeric = pd.api.types.is_numeric_dtype(train_df[col])
        unique_count = pd.concat([train_col, test_col]).nunique(dropna=True)

        row = {
            "column": col,
            "dtype": str(train_df[col].dtype),
            "train_missing_pct": train_df[col].isna().mean(),
            "test_missing_pct": test_df[col].isna().mean(),
            "test": None,
            "statistic": np.nan,
            "p_value": np.nan,
            "psi": np.nan,
        }

        if is_numeric and unique_count > categorical_threshold:
            result = ks_2samp(train_col, test_col)
            row.update(
                {
                    "test": "ks_2samp",
                    "statistic": result.statistic,
                    "p_value": result.pvalue,
                    "psi": population_stability_index(train_col, test_col),
                }
            )
        else:
            contingency = pd.crosstab(
                pd.concat(
                    [
                        pd.Series("train", index=train_col.index),
                        pd.Series("test", index=test_col.index),
                    ]
                ),
                pd.concat([train_col, test_col]).astype(str),
            )
            if contingency.shape[1] > 1:
                chi2, p_value, _, _ = chi2_contingency(contingency)
                row.update({"test": "chi2", "statistic": chi2, "p_value": p_value})

        rows.append(row)

    return pd.DataFrame(rows).sort_values("p_value", na_position="last").reset_index(drop=True)
