import pandas as pd
from sklearn.cluster import KMeans
from sklearn.decomposition import PCA
from sklearn.metrics import calinski_harabasz_score, davies_bouldin_score, silhouette_score


def _numeric_without_missing(X):
    data = pd.DataFrame(X).select_dtypes(include="number")
    return data.fillna(data.median(numeric_only=True))


def evaluate_kmeans_clusters(X, k_range=range(2, 11), random_state=42):
    """Evaluate KMeans cluster quality across a range of k values."""
    X_ready = _numeric_without_missing(X)
    rows = []
    for k in k_range:
        model = KMeans(n_clusters=k, random_state=random_state, n_init="auto")
        labels = model.fit_predict(X_ready)
        rows.append(
            {
                "k": k,
                "inertia": model.inertia_,
                "silhouette": silhouette_score(X_ready, labels),
                "davies_bouldin": davies_bouldin_score(X_ready, labels),
                "calinski_harabasz": calinski_harabasz_score(X_ready, labels),
            }
        )
    return pd.DataFrame(rows)


def cluster_profile(df, labels, agg_funcs=("mean", "median", "count")):
    """Profile numeric columns by cluster label."""
    profiled = df.copy()
    profiled["cluster"] = labels
    return profiled.groupby("cluster").agg(agg_funcs)


def pca_cluster_projection(X, labels=None, n_components=2, random_state=42):
    """Return a PCA projection DataFrame for cluster visualization."""
    X_ready = _numeric_without_missing(X)
    pca = PCA(n_components=n_components, random_state=random_state)
    projected = pca.fit_transform(X_ready)
    columns = [f"pc_{i + 1}" for i in range(n_components)]
    result = pd.DataFrame(projected, columns=columns, index=getattr(X, "index", None))
    if labels is not None:
        result["cluster"] = labels
    result.attrs["explained_variance_ratio"] = pca.explained_variance_ratio_
    return result
