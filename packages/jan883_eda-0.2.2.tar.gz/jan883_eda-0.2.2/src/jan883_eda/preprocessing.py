import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler, MinMaxScaler, RobustScaler


def build_preprocessor(
    X,
    numeric_strategy="median",
    categorical_strategy="most_frequent",
    scaler="standard",
    handle_unknown="ignore",
):
    """
    Build a train-test safe preprocessing ColumnTransformer.

    The returned transformer should be fit on training data only and then reused
    for validation, test, or future data.
    """
    numeric_features = X.select_dtypes(include="number").columns.tolist()
    categorical_features = X.select_dtypes(exclude="number").columns.tolist()

    scaler_step = {
        "standard": StandardScaler(),
        "minmax": MinMaxScaler(),
        "robust": RobustScaler(),
        None: "passthrough",
    }.get(scaler)

    if scaler_step is None:
        raise ValueError("scaler must be one of 'standard', 'minmax', 'robust', or None")

    numeric_pipeline = Pipeline(
        steps=[
            ("imputer", SimpleImputer(strategy=numeric_strategy)),
            ("scaler", scaler_step),
        ]
    )
    categorical_pipeline = Pipeline(
        steps=[
            ("imputer", SimpleImputer(strategy=categorical_strategy)),
            ("encoder", OneHotEncoder(handle_unknown=handle_unknown, sparse_output=False)),
        ]
    )

    return ColumnTransformer(
        transformers=[
            ("numeric", numeric_pipeline, numeric_features),
            ("categorical", categorical_pipeline, categorical_features),
        ],
        remainder="drop",
        verbose_feature_names_out=False,
    )


def fit_transform_preprocessor(X_train, X_test=None, **kwargs):
    """
    Fit a safe preprocessor on X_train and optionally transform X_test.

    Returns:
        tuple: (preprocessor, transformed_train) or
        (preprocessor, transformed_train, transformed_test).
    """
    preprocessor = build_preprocessor(X_train, **kwargs)
    X_train_transformed = preprocessor.fit_transform(X_train)
    feature_names = preprocessor.get_feature_names_out()
    X_train_df = pd.DataFrame(X_train_transformed, columns=feature_names, index=X_train.index)

    if X_test is None:
        return preprocessor, X_train_df

    X_test_transformed = preprocessor.transform(X_test)
    X_test_df = pd.DataFrame(X_test_transformed, columns=feature_names, index=X_test.index)
    return preprocessor, X_train_df, X_test_df
