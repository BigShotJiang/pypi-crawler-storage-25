import joblib
import pandas as pd
from sklearn.pipeline import Pipeline

from .preprocessing import build_preprocessor


def build_model_pipeline(X, estimator, **preprocessor_kwargs):
    """Build a preprocessing + estimator pipeline."""
    preprocessor = build_preprocessor(X, **preprocessor_kwargs)
    return Pipeline([("preprocessor", preprocessor), ("model", estimator)])


def save_pipeline(pipeline, path):
    """Persist a fitted pipeline with joblib."""
    joblib.dump(pipeline, path)
    return path


def load_pipeline(path):
    """Load a fitted pipeline saved with save_pipeline."""
    return joblib.load(path)


def validate_prediction_columns(X, expected_columns, allow_extra=True):
    """
    Validate that prediction data contains the columns seen during training.

    Returns:
        pd.DataFrame: X ordered to expected_columns.
    """
    missing = [col for col in expected_columns if col not in X.columns]
    extra = [col for col in X.columns if col not in expected_columns]

    if missing:
        raise ValueError(f"Missing columns: {missing}")
    if extra and not allow_extra:
        raise ValueError(f"Unexpected columns: {extra}")

    return X.loc[:, expected_columns].copy()


def transformed_feature_names(pipeline):
    """Return transformed feature names from a fitted preprocessing pipeline."""
    preprocessor = pipeline.named_steps.get("preprocessor", pipeline)
    if hasattr(preprocessor, "get_feature_names_out"):
        return preprocessor.get_feature_names_out()
    raise ValueError("Pipeline does not expose get_feature_names_out().")
