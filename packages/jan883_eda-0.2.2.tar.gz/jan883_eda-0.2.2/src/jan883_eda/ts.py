import matplotlib.pyplot as plt
import pandas as pd
from statsmodels.tsa.stattools import adfuller
from statsmodels.tsa.stattools import kpss
from statsmodels.graphics.tsaplots import plot_acf, plot_pacf
from statsmodels.tsa.seasonal import seasonal_decompose

def analyze_stationarity(x, alpha=0.05, lags=15):
    """
    Performs ADF test for stationarity and plots ACF/PACF.
    Explains the results in plain English.
    """
    # 1. Run the ADF Test
    results = adfuller(x)
    p_value = results[1]

    # 2. Determine Stationarity Status
    is_stationary = p_value < alpha
    status = "Stationary" if is_stationary else "Non-Stationary"
    conclusion = "Reject" if is_stationary else "Fail to reject"

    # 3. Print the Explanation
    print(f"{'='*30}")
    print(f" STATIONARITY ANALYSIS ")
    print(f"{'='*30}")
    print(f"ADF P-Value: {p_value:.4f}")
    print(f"Conclusion:  {conclusion} the null hypothesis.")
    print(f"Result:      The series is {status.upper()}.")
    print(f"\n--- WHAT THIS MEANS ---")

    if is_stationary:
        print("A stationary series has a constant mean and variance over time.")
        print("This suggests you can proceed with ARMA/ARIMA models.")
    else:
        print("A non-stationary series has trends or seasonality that change over time.")
        print("You likely need to apply 'differencing' or a transformation before modeling.")

    # 4. Generate Plots
    fig, axes = plt.subplots(1, 2, figsize=(15, 5))

    plot_acf(x, lags=lags, ax=axes[0])
    axes[0].set_title(f"Autocorrelation (ACF)\n(Detects MA terms)")

    plot_pacf(x, lags=lags, ax=axes[1])
    axes[1].set_title(f"Partial Autocorrelation (PACF)\n(Detects AR terms)")

    plt.tight_layout()
    plt.show()

# Example Usage:
# data = ac.TotalWine.diff(4).dropna()
# analyze_stationarity(data)


def stationarity_report(x, alpha=0.05, regression="c"):
    """Run ADF and KPSS stationarity tests and return a compact report."""
    clean_x = pd.Series(x).dropna()
    adf_result = adfuller(clean_x)
    kpss_result = kpss(clean_x, regression=regression, nlags="auto")
    return pd.DataFrame(
        [
            {
                "test": "ADF",
                "statistic": adf_result[0],
                "p_value": adf_result[1],
                "stationary_at_alpha": adf_result[1] <= alpha,
                "null_hypothesis": "unit root / non-stationary",
            },
            {
                "test": "KPSS",
                "statistic": kpss_result[0],
                "p_value": kpss_result[1],
                "stationary_at_alpha": kpss_result[1] > alpha,
                "null_hypothesis": "stationary",
            },
        ]
    )


def plot_rolling_statistics(series, window=12):
    """Plot a series with rolling mean and standard deviation."""
    series = pd.Series(series).dropna()
    rolling_mean = series.rolling(window=window).mean()
    rolling_std = series.rolling(window=window).std()

    plt.figure(figsize=(12, 5))
    plt.plot(series, label="Original")
    plt.plot(rolling_mean, label=f"Rolling Mean ({window})")
    plt.plot(rolling_std, label=f"Rolling Std ({window})")
    plt.title("Rolling Statistics")
    plt.legend()
    plt.tight_layout()
    plt.show()
    return pd.DataFrame({"value": series, "rolling_mean": rolling_mean, "rolling_std": rolling_std})


def seasonal_decomposition_plot(series, period, model="additive"):
    """Run and plot seasonal decomposition."""
    result = seasonal_decompose(pd.Series(series).dropna(), period=period, model=model)
    result.plot()
    plt.tight_layout()
    plt.show()
    return result


def make_lag_features(series, lags=(1, 2, 3), rolling_windows=None, dropna=True):
    """Create lag and optional rolling mean features from a time series."""
    data = pd.DataFrame({"y": pd.Series(series)})
    for lag in lags:
        data[f"lag_{lag}"] = data["y"].shift(lag)

    for window in rolling_windows or []:
        data[f"rolling_mean_{window}"] = data["y"].shift(1).rolling(window=window).mean()

    return data.dropna() if dropna else data


def time_series_train_test_split(data, test_size=0.2):
    """Split ordered time-series data without shuffling."""
    split_index = int(len(data) * (1 - test_size))
    return data.iloc[:split_index].copy(), data.iloc[split_index:].copy()


def forecast_metrics(y_true, y_pred):
    """Return common forecasting metrics."""
    y_true = pd.Series(y_true).astype(float)
    y_pred = pd.Series(y_pred).astype(float)
    error = y_true - y_pred
    denominator = (y_true.abs() + y_pred.abs()).replace(0, pd.NA)
    return {
        "mae": error.abs().mean(),
        "rmse": (error.pow(2).mean()) ** 0.5,
        "mape": (error.abs() / y_true.replace(0, pd.NA).abs()).mean() * 100,
        "smape": (2 * error.abs() / denominator).mean() * 100,
    }
