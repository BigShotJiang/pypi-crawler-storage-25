import numpy as np
import pandas as pd
from sklearn.base import clone
from sklearn.dummy import DummyClassifier, DummyRegressor
from sklearn.ensemble import (
    AdaBoostClassifier,
    AdaBoostRegressor,
    GradientBoostingClassifier,
    GradientBoostingRegressor,
    RandomForestClassifier,
    RandomForestRegressor,
)
from sklearn.linear_model import ElasticNet, Lasso, LinearRegression, LogisticRegression, Ridge
from sklearn.metrics import get_scorer
from sklearn.model_selection import StratifiedKFold, KFold, cross_validate
from sklearn.neighbors import KNeighborsClassifier, KNeighborsRegressor
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC, SVR
from sklearn.tree import DecisionTreeClassifier, DecisionTreeRegressor


def default_classifiers(random_state=42):
    return {
        "Dummy": DummyClassifier(strategy="most_frequent"),
        "Logistic Regression": LogisticRegression(max_iter=1000),
        "Decision Tree": DecisionTreeClassifier(random_state=random_state),
        "Random Forest": RandomForestClassifier(random_state=random_state),
        "Gradient Boosting": GradientBoostingClassifier(random_state=random_state),
        "AdaBoost": AdaBoostClassifier(random_state=random_state),
        "SVC": SVC(probability=True, random_state=random_state),
        "KNN": KNeighborsClassifier(),
    }


def default_regressors(random_state=42):
    return {
        "Dummy": DummyRegressor(strategy="mean"),
        "Linear Regression": LinearRegression(),
        "Ridge": Ridge(),
        "Lasso": Lasso(),
        "ElasticNet": ElasticNet(),
        "Decision Tree": DecisionTreeRegressor(random_state=random_state),
        "Random Forest": RandomForestRegressor(random_state=random_state),
        "Gradient Boosting": GradientBoostingRegressor(random_state=random_state),
        "AdaBoost": AdaBoostRegressor(random_state=random_state),
        "SVR": SVR(),
        "KNN": KNeighborsRegressor(),
    }


def _compare_models_cv(models, X, y, cv, scoring, scale_data):
    scorer = get_scorer(scoring)
    rows = []

    for name, estimator in models.items():
        model = clone(estimator)
        if scale_data:
            model = Pipeline([("scaler", StandardScaler()), ("model", model)])

        scores = cross_validate(
            model,
            X,
            y,
            cv=cv,
            scoring=scorer,
            return_train_score=False,
            n_jobs=-1,
        )
        rows.append(
            {
                "model": name,
                "score_mean": np.nanmean(scores["test_score"]),
                "score_std": np.nanstd(scores["test_score"]),
                "fit_time_mean": np.nanmean(scores["fit_time"]),
                "score_time_mean": np.nanmean(scores["score_time"]),
            }
        )

    results = pd.DataFrame(rows).sort_values("score_mean", ascending=False).reset_index(drop=True)
    results.insert(0, "rank", range(1, len(results) + 1))
    results.attrs["scoring"] = scoring
    return results


def compare_classifiers_cv(
    X,
    y,
    models=None,
    cv=5,
    scoring="f1_weighted",
    scale_data=False,
    random_state=42,
):
    """
    Compare classifiers with cross-validation.
    """
    models = models or default_classifiers(random_state=random_state)
    cv_strategy = StratifiedKFold(n_splits=cv, shuffle=True, random_state=random_state)
    return _compare_models_cv(models, X, y, cv_strategy, scoring, scale_data)


def compare_regressors_cv(
    X,
    y,
    models=None,
    cv=5,
    scoring="r2",
    scale_data=False,
    random_state=42,
):
    """
    Compare regressors with cross-validation.
    """
    models = models or default_regressors(random_state=random_state)
    cv_strategy = KFold(n_splits=cv, shuffle=True, random_state=random_state)
    return _compare_models_cv(models, X, y, cv_strategy, scoring, scale_data)
