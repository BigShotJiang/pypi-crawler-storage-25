import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns
from sklearn.calibration import calibration_curve
from sklearn.metrics import (
    ConfusionMatrixDisplay,
    classification_report,
    confusion_matrix,
    mean_absolute_error,
    mean_squared_error,
    precision_recall_curve,
    r2_score,
)


def class_balance_report(y):
    """Return class counts and percentages."""
    counts = pd.Series(y).value_counts(dropna=False).rename("count")
    pct = (counts / counts.sum()).rename("pct")
    return pd.concat([counts, pct], axis=1).reset_index(names="class")


def classification_metrics_table(y_true, y_pred):
    """Return sklearn's classification report as a DataFrame."""
    return pd.DataFrame(classification_report(y_true, y_pred, output_dict=True)).T


def plot_confusion_matrix(y_true, y_pred, labels=None, normalize=None, cmap="Blues"):
    """Plot a confusion matrix from predictions."""
    matrix = confusion_matrix(y_true, y_pred, labels=labels, normalize=normalize)
    display = ConfusionMatrixDisplay(confusion_matrix=matrix, display_labels=labels)
    display.plot(cmap=cmap, values_format=".2f" if normalize else "d")
    plt.tight_layout()
    plt.show()
    return matrix


def plot_precision_recall(y_true, y_score):
    """Plot a binary precision-recall curve."""
    precision, recall, thresholds = precision_recall_curve(y_true, y_score)
    plt.figure(figsize=(7, 5))
    plt.plot(recall, precision)
    plt.xlabel("Recall")
    plt.ylabel("Precision")
    plt.title("Precision-Recall Curve")
    plt.grid(alpha=0.3)
    plt.tight_layout()
    plt.show()
    return precision, recall, thresholds


def plot_calibration(y_true, y_prob, n_bins=10):
    """Plot a binary classifier calibration curve."""
    prob_true, prob_pred = calibration_curve(y_true, y_prob, n_bins=n_bins)
    plt.figure(figsize=(6, 5))
    plt.plot(prob_pred, prob_true, marker="o", label="Model")
    plt.plot([0, 1], [0, 1], linestyle="--", color="gray", label="Perfect")
    plt.xlabel("Mean predicted probability")
    plt.ylabel("Fraction of positives")
    plt.title("Calibration Curve")
    plt.legend()
    plt.grid(alpha=0.3)
    plt.tight_layout()
    plt.show()
    return pd.DataFrame({"mean_predicted_probability": prob_pred, "fraction_positive": prob_true})


def regression_metrics(y_true, y_pred):
    """Return common regression metrics."""
    mse = mean_squared_error(y_true, y_pred)
    return {
        "mae": mean_absolute_error(y_true, y_pred),
        "mse": mse,
        "rmse": np.sqrt(mse),
        "r2": r2_score(y_true, y_pred),
    }


def plot_regression_diagnostics(y_true, y_pred):
    """Plot actual-vs-predicted, residual distribution, and residuals-vs-predicted."""
    residuals = np.asarray(y_true) - np.asarray(y_pred)
    fig, axes = plt.subplots(1, 3, figsize=(18, 5))

    axes[0].scatter(y_true, y_pred, alpha=0.7)
    min_val = min(np.min(y_true), np.min(y_pred))
    max_val = max(np.max(y_true), np.max(y_pred))
    axes[0].plot([min_val, max_val], [min_val, max_val], linestyle="--", color="gray")
    axes[0].set_title("Actual vs Predicted")
    axes[0].set_xlabel("Actual")
    axes[0].set_ylabel("Predicted")

    sns.histplot(residuals, kde=True, ax=axes[1])
    axes[1].set_title("Residual Distribution")

    axes[2].scatter(y_pred, residuals, alpha=0.7)
    axes[2].axhline(0, linestyle="--", color="gray")
    axes[2].set_title("Residuals vs Predicted")
    axes[2].set_xlabel("Predicted")
    axes[2].set_ylabel("Residual")

    plt.tight_layout()
    plt.show()
    return pd.Series(residuals, name="residual")
