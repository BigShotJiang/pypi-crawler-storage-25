import numpy as np
import pandas as pd
from sklearn.feature_selection import VarianceThreshold, mutual_info_classif, mutual_info_regression
from sklearn.inspection import permutation_importance


def _numeric_without_missing(X):
    numeric_X = X.select_dtypes(include="number")
    return numeric_X.fillna(numeric_X.median(numeric_only=True))


def low_variance_features(X, threshold=0.0):
    """Return features whose variance is at or below threshold."""
    numeric_X = _numeric_without_missing(X)
    selector = VarianceThreshold(threshold=threshold)
    selector.fit(numeric_X)
    keep_mask = selector.get_support()
    return numeric_X.columns[~keep_mask].tolist()


def correlation_prune(X, threshold=0.9):
    """
    Find numeric columns to drop so no retained pair exceeds the correlation threshold.
    """
    corr = X.select_dtypes(include="number").corr().abs()
    upper = corr.where(np.triu(np.ones(corr.shape), k=1).astype(bool))
    to_drop = [column for column in upper.columns if any(upper[column] > threshold)]
    return to_drop


def mutual_information_ranking(X, y, problem_type="classification", random_state=42):
    """Rank numeric features by mutual information with the target."""
    numeric_X = _numeric_without_missing(X)
    if problem_type == "classification":
        scores = mutual_info_classif(numeric_X, y, random_state=random_state)
    elif problem_type == "regression":
        scores = mutual_info_regression(numeric_X, y, random_state=random_state)
    else:
        raise ValueError("problem_type must be 'classification' or 'regression'")

    return (
        pd.DataFrame({"feature": numeric_X.columns, "mutual_information": scores})
        .sort_values("mutual_information", ascending=False)
        .reset_index(drop=True)
    )


def permutation_importance_table(model, X, y, n_repeats=10, random_state=42, scoring=None):
    """Return permutation importance as a sorted DataFrame."""
    result = permutation_importance(
        model,
        X,
        y,
        n_repeats=n_repeats,
        random_state=random_state,
        scoring=scoring,
    )
    return (
        pd.DataFrame(
            {
                "feature": X.columns,
                "importance_mean": result.importances_mean,
                "importance_std": result.importances_std,
            }
        )
        .sort_values("importance_mean", ascending=False)
        .reset_index(drop=True)
    )
