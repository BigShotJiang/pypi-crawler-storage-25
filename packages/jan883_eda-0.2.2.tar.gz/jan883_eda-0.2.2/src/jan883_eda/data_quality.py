import numpy as np
import pandas as pd


def data_quality_report(df, high_cardinality_threshold=50, near_constant_threshold=0.95):
    """
    Build a column-level data quality report.

    Parameters:
        df (pd.DataFrame): Data to inspect.
        high_cardinality_threshold (int): Unique-count threshold for categorical columns.
        near_constant_threshold (float): Top-value ratio threshold for near-constant columns.

    Returns:
        pd.DataFrame: One row per column with quality flags and suggested actions.
    """
    rows = []
    n_rows = len(df)

    for col in df.columns:
        series = df[col]
        non_null = series.dropna()
        value_counts = non_null.value_counts(dropna=False)
        top_ratio = value_counts.iloc[0] / len(non_null) if len(non_null) else np.nan
        unique_count = series.nunique(dropna=True)
        is_numeric = pd.api.types.is_numeric_dtype(series)
        is_categorical = pd.api.types.is_object_dtype(series) or pd.api.types.is_categorical_dtype(series)
        outlier_count = 0

        if is_numeric and len(non_null) > 0:
            q1 = non_null.quantile(0.25)
            q3 = non_null.quantile(0.75)
            iqr = q3 - q1
            if iqr > 0:
                outlier_count = int(((non_null < q1 - 1.5 * iqr) | (non_null > q3 + 1.5 * iqr)).sum())

        flags = []
        if series.isna().any():
            flags.append("missing")
        if unique_count == 1:
            flags.append("constant")
        elif pd.notna(top_ratio) and top_ratio >= near_constant_threshold:
            flags.append("near_constant")
        if is_categorical and unique_count >= high_cardinality_threshold:
            flags.append("high_cardinality")
        if outlier_count:
            flags.append("outliers")

        suggested_action = "review"
        if "constant" in flags:
            suggested_action = "drop"
        elif "missing" in flags and is_numeric:
            suggested_action = "impute_numeric"
        elif "missing" in flags:
            suggested_action = "impute_categorical"
        elif "high_cardinality" in flags:
            suggested_action = "encode_or_group_rare"
        elif "outliers" in flags:
            suggested_action = "inspect_outliers"

        rows.append(
            {
                "column": col,
                "dtype": str(series.dtype),
                "missing_count": int(series.isna().sum()),
                "missing_pct": series.isna().mean() if n_rows else 0,
                "unique_count": int(unique_count),
                "top_value_ratio": top_ratio,
                "outlier_count_iqr": outlier_count,
                "flags": ", ".join(flags),
                "suggested_action": suggested_action,
            }
        )

    return pd.DataFrame(rows)


def duplicate_summary(df, subset=None):
    """
    Summarize duplicate rows.

    Returns:
        dict: Duplicate count, duplicate percentage, and duplicated rows.
    """
    duplicated = df.duplicated(subset=subset, keep=False)
    return {
        "duplicate_count": int(duplicated.sum()),
        "duplicate_pct": float(duplicated.mean()) if len(df) else 0.0,
        "duplicates": df.loc[duplicated].copy(),
    }
