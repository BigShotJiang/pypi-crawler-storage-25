"""Public API for jan883_eda.

Names from ``eda`` are preferred when older compatibility modules define the
same helper. This keeps ``from jan883_eda import ...`` deterministic while
leaving the submodules importable for users who rely on them directly.
"""

from . import eda as _eda
from . import model_selection as _model_selection
from . import ts as _ts
from . import data_quality as _data_quality
from . import preprocessing as _preprocessing
from . import model_compare as _model_compare
from . import diagnostics as _diagnostics
from . import feature_selection as _feature_selection
from . import clustering as _clustering
from . import drift as _drift
from . import pipeline_utils as _pipeline_utils

__all__ = []

for _module in (
    _eda,
    _ts,
    _model_selection,
    _data_quality,
    _preprocessing,
    _model_compare,
    _diagnostics,
    _feature_selection,
    _clustering,
    _drift,
    _pipeline_utils,
):
    _public_names = getattr(_module, "__all__", None)
    if _public_names is None:
        _public_names = [
            _name
            for _name in dir(_module)
            if not _name.startswith("_")
            and callable(getattr(_module, _name))
            and getattr(getattr(_module, _name), "__module__", None) == _module.__name__
        ]

    for _name in _public_names:
        if _name.startswith("_") or _name in globals():
            continue
        globals()[_name] = getattr(_module, _name)
        __all__.append(_name)

del (
    _eda,
    _model_selection,
    _ts,
    _data_quality,
    _preprocessing,
    _model_compare,
    _diagnostics,
    _feature_selection,
    _clustering,
    _drift,
    _pipeline_utils,
    _module,
    _name,
    _public_names,
)
