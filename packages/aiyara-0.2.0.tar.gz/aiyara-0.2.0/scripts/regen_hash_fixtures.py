#!/usr/bin/env python
"""Regenerate ``sdk/tests/hash_fixtures.json`` — the parity contract between
the Python ``hash_system_prompt`` and the TS ``hashSystemPrompt`` polyfill.

Run once after the normalization rule is finalized; commit the output. The
committed JSON is the contract; re-running this script after a normalization
change is by definition a breaking change and will be caught by diff review.

Usage::

    uv run python sdk/scripts/regen_hash_fixtures.py
"""

from __future__ import annotations

import json
import sys
from pathlib import Path

# Allow running without install (test harness path).
SDK_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(SDK_ROOT))

from aiyara.hashing import hash_system_prompt  # noqa: E402


# Hand-picked inputs covering the edge cases the normalization rule MUST
# handle identically on Python and TypeScript. Any divergence here is a
# fatal wire-contract bug.
FIXTURE_INPUTS: list[str] = [
    # --- Boundary shapes ---
    "",                                              # 1. empty string
    " ",                                             # 2. single space
    "   \t\n  ",                                     # 3. all whitespace -> empty normalized
    "a",                                             # 4. single ASCII char
    "hello world",                                   # 5. canonical single-space
    # --- Whitespace normalization ---
    "  hello  world  ",                              # 6. leading/trailing + internal double
    "hello\tworld",                                  # 7. tab
    "hello\nworld",                                  # 8. newline
    "hello\r\nworld",                                # 9. CRLF
    "  hello\t\n\r world\n\n  ",                     # 10. mixed whitespace runs
    "hello\t\t\tworld\n\n\nfoo",                     # 11. long whitespace runs, multiple words
    # --- Unicode ---
    "尝试\ntest",                                     # 12. CJK + newline
    "café résumé",                                   # 13. combining accents
    "emoji: \U0001F4A9\U0001F680",                   # 14. emoji (poop + rocket)
    "combining: e\u0301",                            # 15. combining acute (é decomposed)
    "rtl: שלום עולם",                                # 16. Hebrew RTL
    # --- Realistic prompts ---
    "You are a helpful assistant.",                  # 17. short real prompt
    "You are a helpful assistant.\n\nFollow rules:\n- Be concise.\n- Cite sources.",  # 18. multi-line prompt
    # --- Scale ---
    "a" * 10_000,                                    # 19. 10k-char blob
    "word " * 2_000,                                 # 20. many words
]


def main() -> int:
    fixtures = [
        {"input": text, "expected": hash_system_prompt(text)}
        for text in FIXTURE_INPUTS
    ]
    out = SDK_ROOT / "tests" / "hash_fixtures.json"
    out.write_text(json.dumps(fixtures, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(f"Wrote {len(fixtures)} fixtures -> {out}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
