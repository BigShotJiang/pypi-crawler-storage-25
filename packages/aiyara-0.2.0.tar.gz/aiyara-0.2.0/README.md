# Aiyara — Agent Failure Monitoring SDK

[![PyPI version](https://img.shields.io/pypi/v/aiyara.svg)](https://pypi.org/project/aiyara/)
[![Python versions](https://img.shields.io/pypi/pyversions/aiyara.svg)](https://pypi.org/project/aiyara/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

**Aiyara is agent failure monitoring with system-prompt-driven constraint extraction.** Paste your system prompt at [app.aiyara-universe.com](https://app.aiyara-universe.com), we extract structural constraints (tool ordering, argument rules, cross-turn dependencies) as a deterministic policy, and every trace is checked against that policy plus pre-built harness detectors (doom loops, retry amplification, context overflow, cascades). Violations surface as issues with evidence, not LLM-judge guesses.

This Python SDK captures traces from your agent in production and ships them to the Aiyara ingest service for evaluation. Capture is non-blocking, batched, and PII is scrubbed client-side before any bytes leave your process.

## Quick start

```bash
pip install aiyara
```

```python
import aiyara

aiyara.init(api_key="ak_...", auto_instrument=True)
```

That's it. With `auto_instrument=True`, the SDK patches the supported client libraries below and every agent run is captured and sent to Aiyara automatically.

## Get an API key

1. Visit [app.aiyara-universe.com](https://app.aiyara-universe.com).
2. Sign up (Supabase auth — no card required for the free tier).
3. Paste your system prompt. The wizard extracts your policy rules and lets you review them.
4. Issue an `ak_*` API key for your project. Use it in `aiyara.init(api_key=...)`.

## Auto-instrumentation

Supported frameworks (patched on `aiyara.init(auto_instrument=True)`):

- `openai` — Chat Completions, Responses, tool calls
- `langgraph` — graph nodes, tool calls, state transitions
- `openai_agents` — Agents SDK runs

You can also drive capture manually:

```python
# Single capture
aiyara.capture(
    messages=[{"role": "user", "content": "Hello"}],
    tool_calls=[{"name": "search", "arguments": {"q": "test"}, "result": "ok"}],
    model="gpt-4",
)

# Context-managed trace
with aiyara.trace(session_id="user-123") as t:
    t.record_message(role="user", content="Find flights")
    t.record_tool_call(name="search_flights", arguments={}, result={})

aiyara.shutdown()  # flush pending traces
```

## PII scrubbing

PII scrubbing happens **client-side, before transport**. Raw user content never leaves your process unless explicitly opted in. The default scrubber redacts emails, phone numbers, and other common PII patterns; pass `pii_field_paths=[...]` to extend it.

```python
aiyara.init(
    api_key="ak_...",
    scrub_pii=True,                          # on by default
    pii_field_paths=["messages[*].content"], # extend default scrubbing
)
```

## What you get

- **Per-constraint verdicts.** Aiyara tells you which rule fired, on which step, with the trace evidence — not a number from a judge.
- **Cascade detection.** Root-cause violations are linked to their downstream failures via `depends_on` graphs.
- **Pre-built harness detectors.** Doom loops, context overflow, retry amplification, error cascades — zero configuration required.
- **Deterministic monitoring.** Pure-Python checks. Compile policy once, evaluate every trace, zero LLM calls on the hot path.

## License

MIT — see [LICENSE](https://github.com/Aiyara-Universe/Testbench/blob/main/LICENSE) for details.

## Links

- Homepage: [www.aiyara-universe.com](https://www.aiyara-universe.com)
- Dashboard: [app.aiyara-universe.com](https://app.aiyara-universe.com)
- Source: [github.com/Aiyara-Universe/Testbench](https://github.com/Aiyara-Universe/Testbench)
- Changelog: [sdk/CHANGELOG.md](https://github.com/Aiyara-Universe/Testbench/blob/main/sdk/CHANGELOG.md)
- Issues: [github.com/Aiyara-Universe/Testbench/issues](https://github.com/Aiyara-Universe/Testbench/issues)
