"""Tests for AiyaraClient, TraceContext, and module-level API.

All tests use a mock transport to avoid real HTTP calls.
"""

from __future__ import annotations

import io
import json
import logging
import urllib.error
from unittest.mock import MagicMock, patch

import pytest

from aiyara.client import AiyaraClient, TraceContext, _TraceContextManager
from aiyara.types import AiyaraTrace


# ---------------------------------------------------------------------------
# Helpers for /whoami mocking
# ---------------------------------------------------------------------------


class _FakeWhoAmIResponse:
    """Mimics ``urllib.request.urlopen``'s context-manager result."""

    def __init__(self, body: bytes, status: int = 200) -> None:
        self._body = body
        self.status = status

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        return False

    def read(self) -> bytes:
        return self._body


def _whoami_urlopen(project_id: str | None = "p-mock-test", status: int = 200):
    """Return a ``urlopen`` replacement that answers /whoami and nothing else.

    For any other URL, raises URLError — keeping tests hermetic.
    """
    body = json.dumps({"project_id": project_id, "tenant_id": "t1", "auth_method": "api_key"}).encode()

    def _fake_urlopen(req, timeout=None):
        url = req.full_url if hasattr(req, "full_url") else str(req)
        if "/api/v1/whoami" in url:
            return _FakeWhoAmIResponse(body, status=status)
        raise urllib.error.URLError("blocked in test")

    return _fake_urlopen


def _whoami_urlopen_error(exc: Exception):
    """``urlopen`` replacement that raises a fixed exception for any call."""
    def _fake(req, timeout=None):
        raise exc
    return _fake


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_client(**overrides) -> AiyaraClient:
    """Create a client with a mock transport for testing."""
    defaults = {
        "api_key": "test-key",
        "scrub_pii": False,  # Simplify tests unless testing PII
        "sample_rate": 1.0,
    }
    defaults.update(overrides)
    client = AiyaraClient(**defaults)
    # Replace transport with a mock
    client._transport = MagicMock()
    return client


def _sent_traces(client: AiyaraClient) -> list[dict]:
    """Extract all traces sent through the mock transport."""
    return [call.args[0] for call in client._transport.send.call_args_list]


# ---------------------------------------------------------------------------
# Module-level API (aiyara.init / aiyara.trace / aiyara.capture)
# ---------------------------------------------------------------------------


class TestModuleLevelAPI:
    """Test the aiyara.init(), aiyara.trace(), aiyara.capture() module API."""

    def test_trace_before_init_raises(self):
        """trace() raises RuntimeError if init() not called."""
        import aiyara as aiyara

        # Reset global client
        aiyara._client = None
        with pytest.raises(RuntimeError, match="Call aiyara.init"):
            aiyara.trace()

    def test_capture_before_init_raises(self):
        """capture() raises RuntimeError if init() not called."""
        import aiyara as aiyara

        aiyara._client = None
        with pytest.raises(RuntimeError, match="Call aiyara.init"):
            aiyara.capture(messages=[])

    def test_init_creates_client(self):
        """init() creates a global client and returns it."""
        import aiyara as aiyara

        aiyara._client = None
        client = aiyara.init(api_key="test-key")
        assert client is not None
        assert aiyara._client is client
        assert aiyara.get_client() is client
        # Cleanup
        aiyara._client = None

    def test_init_registers_atexit(self):
        """init() registers shutdown as atexit handler."""
        import aiyara as aiyara

        aiyara._client = None
        with patch("aiyara.atexit") as mock_atexit:
            aiyara.init(api_key="test-key")
            assert mock_atexit.register.called
        aiyara._client = None

    def test_trace_works_after_init(self):
        """trace() returns a context manager after init()."""
        import aiyara as aiyara

        aiyara._client = None
        client = aiyara.init(api_key="test-key")
        # Replace transport with mock
        client._transport = MagicMock()

        with aiyara.trace(session_id="test-session") as t:
            t.record_message(role="user", content="Hello")

        # Verify trace was sent
        assert client._transport.send.called
        aiyara._client = None

    def test_capture_works_after_init(self):
        """capture() sends a trace after init()."""
        import aiyara as aiyara

        aiyara._client = None
        client = aiyara.init(api_key="test-key")
        client._transport = MagicMock()

        aiyara.capture(
            messages=[{"role": "user", "content": "Hello"}],
            model="gpt-4",
        )

        assert client._transport.send.called
        sent = client._transport.send.call_args[0][0]
        assert sent["model"] == "gpt-4"
        assert len(sent["messages"]) == 1
        aiyara._client = None

    def test_shutdown_sets_client_to_none(self):
        """shutdown() sets global client to None."""
        import aiyara as aiyara

        aiyara._client = None
        client = aiyara.init(api_key="test-key")
        client._transport = MagicMock()
        aiyara.shutdown()
        assert aiyara._client is None

    def test_default_endpoint_resolves_to_fly(self, monkeypatch):
        """With no endpoint kwarg and no env override, init() uses DEFAULT_ENDPOINT."""
        import aiyara as aiyara

        monkeypatch.delenv("AIYARA_ENDPOINT", raising=False)
        aiyara._client = None
        try:
            client = aiyara.init(api_key="ak_test1234567")
            # Transport strips trailing slash; the default has none anyway.
            assert client._transport._endpoint == "https://aiyara-csim.fly.dev"
        finally:
            aiyara.shutdown()
            aiyara._client = None

    def test_init_reads_aiyara_endpoint_env(self, monkeypatch):
        """AIYARA_ENDPOINT env var overrides the default when no kwarg is passed."""
        import aiyara as aiyara

        monkeypatch.setenv("AIYARA_ENDPOINT", "https://custom.example.com")
        aiyara._client = None
        try:
            client = aiyara.init(api_key="ak_test1234567")
            assert client._transport._endpoint == "https://custom.example.com"
        finally:
            aiyara.shutdown()
            aiyara._client = None

    def test_init_kwarg_overrides_env(self, monkeypatch):
        """Explicit endpoint= kwarg wins over AIYARA_ENDPOINT env var."""
        import aiyara as aiyara

        monkeypatch.setenv("AIYARA_ENDPOINT", "https://env.example.com")
        aiyara._client = None
        try:
            client = aiyara.init(
                api_key="ak_test1234567",
                endpoint="https://kwarg.example.com",
            )
            assert client._transport._endpoint == "https://kwarg.example.com"
        finally:
            aiyara.shutdown()
            aiyara._client = None


# ---------------------------------------------------------------------------
# AiyaraClient
# ---------------------------------------------------------------------------


class TestAiyaraClient:
    """Test AiyaraClient trace/capture/shutdown methods."""

    def test_client_creation(self):
        """Client initializes with correct defaults."""
        client = AiyaraClient(api_key="ak_test123")
        assert client._api_key == "ak_test123"
        assert client._sample_rate == 1.0
        assert client._always_sample_failures is True

    def test_trace_decorator_no_args(self):
        """@client.trace captures the function execution."""
        client = _make_client()

        @client.trace
        def my_agent(msg: str) -> str:
            return f"Response to: {msg}"

        result = my_agent("Hello")
        assert result == "Response to: Hello"
        assert client._transport.send.call_count == 1

    def test_trace_decorator_with_args(self):
        """@client.trace(session_id='...') captures with metadata."""
        client = _make_client()

        @client.trace(session_id="user-123", tags={"env": "test"})
        def my_agent(msg: str) -> str:
            return "ok"

        result = my_agent("Hi")
        assert result == "ok"
        sent = _sent_traces(client)[0]
        assert sent["session_id"] == "user-123"
        assert sent["tags"]["env"] == "test"

    def test_trace_decorator_preserves_return_value(self):
        """Decorated function returns its original value."""
        client = _make_client()

        @client.trace
        def returns_dict() -> dict:
            return {"key": "value", "count": 42}

        result = returns_dict()
        assert result == {"key": "value", "count": 42}

    def test_trace_decorator_preserves_exception(self):
        """Decorated function re-raises exceptions and records failure."""
        client = _make_client()

        @client.trace
        def failing_agent():
            raise ValueError("Something went wrong")

        with pytest.raises(ValueError, match="Something went wrong"):
            failing_agent()

        # Trace should still be sent with failure outcome
        sent = _sent_traces(client)[0]
        assert sent["outcome"]["success"] is False
        assert "Something went wrong" in sent["outcome"]["reason"]

    def test_trace_context_manager(self):
        """Context manager records events and sends trace on exit."""
        client = _make_client()

        with client.trace(session_id="cm-test") as t:
            t.record_message(role="user", content="Hello agent")
            t.record_message(role="assistant", content="Hello user")
            t.record_tool_call(
                name="search",
                arguments={"query": "test"},
                result="found 3 results",
                duration_ms=150.0,
            )

        sent = _sent_traces(client)[0]
        assert sent["session_id"] == "cm-test"
        assert len(sent["messages"]) == 2
        assert sent["messages"][0]["role"] == "user"
        assert sent["messages"][0]["content"] == "Hello agent"
        assert sent["messages"][1]["role"] == "assistant"
        assert len(sent["tool_calls"]) == 1
        assert sent["tool_calls"][0]["name"] == "search"
        assert sent["tool_calls"][0]["result"] == "found 3 results"

    def test_trace_context_manager_exception_records_failure(self):
        """Context manager records failure outcome when exception occurs."""
        client = _make_client()

        with pytest.raises(RuntimeError, match="boom"):
            with client.trace() as t:
                t.record_message(role="user", content="cause failure")
                raise RuntimeError("boom")

        sent = _sent_traces(client)[0]
        assert sent["outcome"]["success"] is False
        assert "boom" in sent["outcome"]["reason"]

    def test_capture_manual(self):
        """Manual capture sends a trace with provided data."""
        client = _make_client()

        client.capture(
            messages=[
                {"role": "user", "content": "Find me a hotel"},
                {"role": "assistant", "content": "Let me search..."},
            ],
            tool_calls=[
                {
                    "name": "hotel_search",
                    "arguments": {"city": "SF"},
                    "result": "Found 5 hotels",
                }
            ],
            model="gpt-4o",
            session_id="manual-session",
        )

        sent = _sent_traces(client)[0]
        assert sent["model"] == "gpt-4o"
        assert sent["session_id"] == "manual-session"
        assert len(sent["messages"]) == 2
        assert len(sent["tool_calls"]) == 1
        assert sent["tool_calls"][0]["name"] == "hotel_search"

    def test_shutdown_calls_transport_shutdown(self):
        """shutdown() calls transport.shutdown()."""
        client = _make_client()
        client.shutdown(timeout=3.0)
        client._transport.shutdown.assert_called_once_with(timeout=3.0)


# ---------------------------------------------------------------------------
# /whoami resolution + agent_id precedence (Phase 77.1 Plan 01 — E2E Bug 7)
# ---------------------------------------------------------------------------


class TestAiyaraClientWhoami:
    """AiyaraClient calls /whoami at init and threads identity into transport.

    agent_id precedence: kwarg > AIYARA_PROJECT env > "default". Env-fallback
    path emits a one-time WARNING (explicit kwarg and no-env/no-kwarg are
    silent).
    """

    def test_init_fetches_whoami_and_wires_transport(self, monkeypatch):
        monkeypatch.delenv("AIYARA_PROJECT", raising=False)
        with patch("aiyara.client.urllib.request.urlopen", side_effect=_whoami_urlopen("p-abc")):
            client = AiyaraClient(api_key="ak_test")
        assert client._project_id == "p-abc"
        # Transport received the resolved identity via set_identity().
        assert client._transport._project_id == "p-abc"
        assert client._transport._agent_id == "default"

    def test_init_whoami_failure_is_soft_fail(self, monkeypatch):
        monkeypatch.delenv("AIYARA_PROJECT", raising=False)
        with patch(
            "aiyara.client.urllib.request.urlopen",
            side_effect=_whoami_urlopen_error(urllib.error.URLError("no route")),
        ):
            client = AiyaraClient(api_key="ak_test")  # must not raise
        assert client._project_id is None
        # Transport stays without identity — will warn at first send.
        assert client._transport._project_id is None

    def test_init_agent_id_priority_kwarg_over_env(self, monkeypatch):
        monkeypatch.setenv("AIYARA_PROJECT", "env-agent")
        with patch("aiyara.client.urllib.request.urlopen", side_effect=_whoami_urlopen("p-abc")):
            client = AiyaraClient(api_key="ak_test", agent_id="explicit-agent")
        assert client._agent_id == "explicit-agent"
        assert client._transport._agent_id == "explicit-agent"

    def test_init_agent_id_env_fallback(self, monkeypatch):
        monkeypatch.setenv("AIYARA_PROJECT", "env-agent")
        with patch("aiyara.client.urllib.request.urlopen", side_effect=_whoami_urlopen("p-abc")):
            client = AiyaraClient(api_key="ak_test")
        assert client._agent_id == "env-agent"
        assert client._transport._agent_id == "env-agent"

    def test_init_agent_id_default(self, monkeypatch):
        monkeypatch.delenv("AIYARA_PROJECT", raising=False)
        with patch("aiyara.client.urllib.request.urlopen", side_effect=_whoami_urlopen("p-abc")):
            client = AiyaraClient(api_key="ak_test")
        assert client._agent_id == "default"
        assert client._transport._agent_id == "default"

    def test_init_agent_id_env_fallback_emits_warning(self, monkeypatch, caplog):
        """Warning fires iff agent_id falls back to AIYARA_PROJECT env.

        Scenarios:
          1. env set + no kwarg  → WARNING (the operational-surprise path)
          2. env set + kwarg     → no warning
          3. no env + no kwarg   → no warning (default path)
        """
        # Scenario 1: env-fallback path — expect warning
        monkeypatch.setenv("AIYARA_PROJECT", "env-agent")
        with patch("aiyara.client.urllib.request.urlopen", side_effect=_whoami_urlopen("p1")):
            with caplog.at_level(logging.WARNING, logger="aiyara.sdk.client"):
                caplog.clear()
                AiyaraClient(api_key="ak_test1")
                warnings_1 = [
                    rec
                    for rec in caplog.records
                    if "AIYARA_PROJECT" in rec.message
                    and "falling back" in rec.message
                ]
                assert len(warnings_1) == 1, (
                    f"expected exactly one AIYARA_PROJECT fallback warning, got "
                    f"{len(warnings_1)}: {[r.message for r in caplog.records]}"
                )
                assert "env-agent" in warnings_1[0].message

        # Scenario 2: explicit kwarg — no fallback warning even with env set
        with patch("aiyara.client.urllib.request.urlopen", side_effect=_whoami_urlopen("p2")):
            with caplog.at_level(logging.WARNING, logger="aiyara.sdk.client"):
                caplog.clear()
                AiyaraClient(api_key="ak_test2", agent_id="explicit")
                warnings_2 = [
                    rec
                    for rec in caplog.records
                    if "AIYARA_PROJECT" in rec.message
                    and "falling back" in rec.message
                ]
                assert warnings_2 == [], (
                    f"explicit agent_id kwarg should silence the fallback warning, "
                    f"but got: {[r.message for r in warnings_2]}"
                )

        # Scenario 3: no env, no kwarg — default path is silent
        monkeypatch.delenv("AIYARA_PROJECT", raising=False)
        with patch("aiyara.client.urllib.request.urlopen", side_effect=_whoami_urlopen("p3")):
            with caplog.at_level(logging.WARNING, logger="aiyara.sdk.client"):
                caplog.clear()
                AiyaraClient(api_key="ak_test3")
                warnings_3 = [
                    rec
                    for rec in caplog.records
                    if "AIYARA_PROJECT" in rec.message
                    and "falling back" in rec.message
                ]
                assert warnings_3 == [], (
                    f"default fallback should be silent, got: "
                    f"{[r.message for r in warnings_3]}"
                )


# ---------------------------------------------------------------------------
# PII Scrubbing Integration
# ---------------------------------------------------------------------------


class TestPIIScrubbing:
    """Verify PII scrubbing is applied before sending."""

    def test_pii_scrubbed_before_transport(self):
        """PII in message content is replaced with tokens before sending."""
        client = _make_client(scrub_pii=True)

        with client.trace() as t:
            t.record_message(
                role="user",
                content="My email is user@example.com and SSN is 123-45-6789",
            )

        sent = _sent_traces(client)[0]
        content = sent["messages"][0]["content"]
        # Email and SSN should be scrubbed
        assert "user@example.com" not in content
        assert "123-45-6789" not in content
        assert "[PII:email:" in content
        assert "[PII:ssn:" in content

    def test_pii_scrubbing_disabled(self):
        """PII is preserved when scrubbing is disabled."""
        client = _make_client(scrub_pii=False)

        with client.trace() as t:
            t.record_message(role="user", content="Email: user@example.com")

        sent = _sent_traces(client)[0]
        assert "user@example.com" in sent["messages"][0]["content"]


# ---------------------------------------------------------------------------
# Sampling
# ---------------------------------------------------------------------------


class TestSampling:
    """Verify sampling behavior."""

    def test_sample_rate_zero_drops_all(self):
        """With sample_rate=0.0, no traces are sent."""
        client = _make_client(sample_rate=0.0, always_sample_failures=False)

        with client.trace() as t:
            t.record_message(role="user", content="test")

        assert client._transport.send.call_count == 0

    def test_sample_rate_one_sends_all(self):
        """With sample_rate=1.0, all traces are sent."""
        client = _make_client(sample_rate=1.0)

        for _ in range(5):
            with client.trace() as t:
                t.record_message(role="user", content="test")

        assert client._transport.send.call_count == 5

    def test_always_sample_failures(self):
        """Failed traces are always sent when always_sample_failures=True."""
        client = _make_client(sample_rate=0.0, always_sample_failures=True)

        with client.trace() as t:
            t.set_outcome(success=False, reason="tool error")

        assert client._transport.send.call_count == 1
        sent = _sent_traces(client)[0]
        assert sent["outcome"]["success"] is False

    def test_failures_dropped_when_always_sample_disabled(self):
        """Failed traces are dropped when always_sample_failures=False."""
        client = _make_client(sample_rate=0.0, always_sample_failures=False)

        with client.trace() as t:
            t.set_outcome(success=False, reason="tool error")

        assert client._transport.send.call_count == 0

    def test_partial_sampling(self):
        """sample_rate=0.5 sends approximately half of traces."""
        client = _make_client(sample_rate=0.5)

        # Send 100 traces, expect roughly 50 (but allow wide margin)
        for _ in range(100):
            with client.trace() as t:
                t.record_message(role="user", content="test")

        sent_count = client._transport.send.call_count
        # With 100 traces at 0.5, expect between 25 and 75
        assert 20 <= sent_count <= 80


# ---------------------------------------------------------------------------
# TraceContext
# ---------------------------------------------------------------------------


class TestTraceContext:
    """Test TraceContext event recording."""

    def test_record_message(self):
        """record_message stores messages with auto-incrementing index."""
        ctx = TraceContext()
        ctx.record_message(role="user", content="Hello")
        ctx.record_message(role="assistant", content="Hi")
        trace = ctx._build_trace()
        assert len(trace.messages) == 2
        assert trace.messages[0].index == 0
        assert trace.messages[0].role == "user"
        assert trace.messages[1].index == 1
        assert trace.messages[1].role == "assistant"

    def test_record_tool_call(self):
        """record_tool_call stores tool invocations."""
        ctx = TraceContext()
        ctx.record_tool_call(
            name="search",
            arguments={"q": "test"},
            result="3 results",
            duration_ms=100.0,
        )
        trace = ctx._build_trace()
        assert len(trace.tool_calls) == 1
        tc = trace.tool_calls[0]
        assert tc.name == "search"
        assert tc.arguments == {"q": "test"}
        assert tc.result == "3 results"
        assert tc.duration_ms == 100.0

    def test_record_tool_call_coerces_non_string_result(self):
        """Non-string results are converted to string."""
        ctx = TraceContext()
        ctx.record_tool_call(
            name="calc",
            arguments={"a": 1, "b": 2},
            result=42,
        )
        trace = ctx._build_trace()
        assert trace.tool_calls[0].result == "42"

    def test_set_outcome(self):
        """set_outcome records success/failure."""
        ctx = TraceContext()
        ctx.set_outcome(success=True, reason="completed")
        trace = ctx._build_trace()
        assert trace.outcome == {"success": True, "reason": "completed"}

    def test_set_metadata(self):
        """set_metadata records model, user_id, deploy_version."""
        ctx = TraceContext()
        ctx.set_metadata(model="gpt-4", user_id="u123", deploy_version="v1.2")
        trace = ctx._build_trace()
        assert trace.model == "gpt-4"
        assert trace.user_id == "u123"
        assert trace.deploy_version == "v1.2"

    def test_build_trace_includes_session_id(self):
        """Built trace includes session_id from constructor."""
        ctx = TraceContext(session_id="sess-abc")
        trace = ctx._build_trace()
        assert trace.session_id == "sess-abc"

    def test_build_trace_includes_tags(self):
        """Built trace includes tags from constructor."""
        ctx = TraceContext(tags={"env": "staging", "team": "ml"})
        trace = ctx._build_trace()
        assert trace.tags == {"env": "staging", "team": "ml"}

    def test_build_trace_has_timestamps(self):
        """Built trace has started_at and ended_at timestamps."""
        ctx = TraceContext()
        trace = ctx._build_trace()
        assert trace.started_at is not None
        assert trace.ended_at is not None
        assert trace.ended_at >= trace.started_at

    def test_build_trace_has_duration(self):
        """Built trace has non-negative duration_seconds."""
        ctx = TraceContext()
        trace = ctx._build_trace()
        assert trace.duration_seconds >= 0.0

    def test_build_trace_counts_steps(self):
        """num_steps equals number of tool calls."""
        ctx = TraceContext()
        ctx.record_tool_call(name="a", arguments={}, result="1")
        ctx.record_tool_call(name="b", arguments={}, result="2")
        trace = ctx._build_trace()
        assert trace.num_steps == 2


# ---------------------------------------------------------------------------
# _TraceContextManager
# ---------------------------------------------------------------------------


class TestTraceContextManager:
    """Test _TraceContextManager used as both context manager and decorator."""

    def test_used_as_context_manager(self):
        """_TraceContextManager yields TraceContext in with-block."""
        client = _make_client()
        cm = _TraceContextManager(client, session_id="cm-test")

        with cm as ctx:
            assert isinstance(ctx, TraceContext)
            ctx.record_message(role="user", content="test")

        assert client._transport.send.called

    def test_used_as_decorator_with_kwargs(self):
        """_TraceContextManager can be used as a decorator via __call__."""
        client = _make_client()

        @_TraceContextManager(client, session_id="dec-test")
        def my_func():
            return "result"

        result = my_func()
        assert result == "result"
        sent = _sent_traces(client)[0]
        assert sent["session_id"] == "dec-test"


# ---------------------------------------------------------------------------
# Phase 78.1 D11 — initial_context / entry_agent / domain kwargs + env fallback
# ---------------------------------------------------------------------------


class TestPhase78_1ContextFields:
    """SDK trace() / capture() forward initial_context / entry_agent / domain.

    Env-var fallbacks: AIYARA_ENTRY_AGENT, AIYARA_DOMAIN (explicit kwarg wins).
    initial_context has NO env fallback — always explicit.
    """

    def test_capture_forwards_kwargs(self, monkeypatch):
        monkeypatch.delenv("AIYARA_ENTRY_AGENT", raising=False)
        monkeypatch.delenv("AIYARA_DOMAIN", raising=False)
        client = _make_client()

        client.capture(
            messages=[{"role": "user", "content": "hi"}],
            entry_agent="billing",
            domain="medical",
            initial_context={"patient_id": "p123"},
        )

        sent = _sent_traces(client)[0]
        assert sent["entry_agent"] == "billing"
        assert sent["domain"] == "medical"
        assert sent["initial_context"] == {"patient_id": "p123"}

    def test_capture_reads_env_when_kwargs_unset(self, monkeypatch):
        monkeypatch.setenv("AIYARA_ENTRY_AGENT", "env-entry")
        monkeypatch.setenv("AIYARA_DOMAIN", "legal")
        client = _make_client()

        client.capture(messages=[{"role": "user", "content": "hi"}])

        sent = _sent_traces(client)[0]
        assert sent["entry_agent"] == "env-entry"
        assert sent["domain"] == "legal"
        # initial_context has no env fallback.
        assert sent["initial_context"] is None

    def test_capture_kwarg_beats_env(self, monkeypatch):
        monkeypatch.setenv("AIYARA_ENTRY_AGENT", "env-entry")
        monkeypatch.setenv("AIYARA_DOMAIN", "legal")
        client = _make_client()

        client.capture(
            messages=[{"role": "user", "content": "hi"}],
            entry_agent="kwarg-entry",
            domain="medical",
        )

        sent = _sent_traces(client)[0]
        assert sent["entry_agent"] == "kwarg-entry"
        assert sent["domain"] == "medical"

    def test_trace_context_manager_forwards_fields(self, monkeypatch):
        monkeypatch.delenv("AIYARA_ENTRY_AGENT", raising=False)
        monkeypatch.delenv("AIYARA_DOMAIN", raising=False)
        client = _make_client()

        with client.trace(
            session_id="s1",
            entry_agent="triage",
            domain="medical",
            initial_context={"patient_id": "p123"},
        ) as t:
            t.record_message(role="user", content="hi")

        sent = _sent_traces(client)[0]
        assert sent["entry_agent"] == "triage"
        assert sent["domain"] == "medical"
        assert sent["initial_context"] == {"patient_id": "p123"}

    def test_trace_context_manager_env_fallback(self, monkeypatch):
        monkeypatch.setenv("AIYARA_ENTRY_AGENT", "env-triage")
        monkeypatch.setenv("AIYARA_DOMAIN", "medical-env")
        client = _make_client()

        with client.trace(session_id="s1") as t:
            t.record_message(role="user", content="hi")

        sent = _sent_traces(client)[0]
        assert sent["entry_agent"] == "env-triage"
        assert sent["domain"] == "medical-env"

