"""Tests for PII detection patterns and scrubber engine."""

import time
from datetime import datetime, timezone

import pytest

from aiyara.pii.patterns import (
    DEFAULT_PATTERNS,
    PIIMatch,
    find_pii,
)
from aiyara.pii.scrubber import PIIScrubber
from aiyara.types import (
    AiyaraTrace,
    ContextSnapshot,
    ToolExecution,
    TraceMessage,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_trace(**overrides) -> AiyaraTrace:
    defaults = dict(
        trace_id="test-trace-001",
        started_at=datetime(2026, 4, 12, 10, 0, 0, tzinfo=timezone.utc),
    )
    defaults.update(overrides)
    return AiyaraTrace(**defaults)


# ---------------------------------------------------------------------------
# Pattern detection tests
# ---------------------------------------------------------------------------

class TestEmailPattern:
    def test_detects_standard_email(self):
        matches = find_pii("Contact us at user@example.com for details")
        names = [m.pattern_name for m in matches]
        assert "email" in names

    def test_detects_email_with_subdomain(self):
        matches = find_pii("Send to admin@mail.company.co.uk")
        names = [m.pattern_name for m in matches]
        assert "email" in names

    def test_no_false_positive_on_at_sign(self):
        matches = find_pii("Use @mention to tag someone")
        names = [m.pattern_name for m in matches]
        assert "email" not in names

    def test_no_false_positive_on_domain(self):
        matches = find_pii("Visit example.com for more")
        names = [m.pattern_name for m in matches]
        assert "email" not in names


class TestPhonePattern:
    def test_us_phone(self):
        matches = find_pii("Call +1 (650) 253-0000 now")
        names = [m.pattern_name for m in matches]
        assert "phone" in names

    def test_uk_phone(self):
        matches = find_pii("Ring +44 20 7946 0958")
        names = [m.pattern_name for m in matches]
        assert "phone" in names

    def test_german_phone(self):
        matches = find_pii("Anrufen +49 30 12345678")
        names = [m.pattern_name for m in matches]
        assert "phone" in names

    def test_japan_phone(self):
        matches = find_pii("Call +81 3-1234-5678")
        names = [m.pattern_name for m in matches]
        assert "phone" in names

    def test_no_false_positive_short_number(self):
        matches = find_pii("Order #12345")
        names = [m.pattern_name for m in matches]
        assert "phone" not in names


class TestSSNPattern:
    def test_detects_dash_separated(self):
        matches = find_pii("SSN: 123-45-6789")
        names = [m.pattern_name for m in matches]
        assert "ssn" in names

    def test_detects_space_separated(self):
        matches = find_pii("SSN: 123 45 6789")
        names = [m.pattern_name for m in matches]
        assert "ssn" in names

    def test_detects_dot_separated(self):
        matches = find_pii("SSN: 123.45.6789")
        names = [m.pattern_name for m in matches]
        assert "ssn" in names

    def test_rejects_mixed_delimiters(self):
        matches = find_pii("SSN: 123-45.6789")
        names = [m.pattern_name for m in matches]
        assert "ssn" not in names

    def test_rejects_invalid_area_000(self):
        matches = find_pii("SSN: 000-45-6789")
        names = [m.pattern_name for m in matches]
        assert "ssn" not in names

    def test_rejects_invalid_area_666(self):
        matches = find_pii("SSN: 666-45-6789")
        names = [m.pattern_name for m in matches]
        assert "ssn" not in names

    def test_rejects_invalid_area_900(self):
        matches = find_pii("SSN: 900-45-6789")
        names = [m.pattern_name for m in matches]
        assert "ssn" not in names

    def test_rejects_all_same_digit(self):
        matches = find_pii("SSN: 111-11-1111")
        names = [m.pattern_name for m in matches]
        assert "ssn" not in names

    def test_rejects_woolworth_ssn(self):
        matches = find_pii("SSN: 078-05-1120")
        names = [m.pattern_name for m in matches]
        assert "ssn" not in names

    def test_no_false_positive_on_date(self):
        matches = find_pii("Date: 2026-04-12")
        names = [m.pattern_name for m in matches]
        assert "ssn" not in names


class TestCreditCardPattern:
    def test_valid_visa(self):
        # Valid Luhn: 4111 1111 1111 1111
        matches = find_pii("Card: 4111 1111 1111 1111")
        names = [m.pattern_name for m in matches]
        assert "credit_card" in names

    def test_valid_mastercard(self):
        # Valid Luhn: 5500 0000 0000 0004
        matches = find_pii("Card: 5500 0000 0000 0004")
        names = [m.pattern_name for m in matches]
        assert "credit_card" in names

    def test_rejects_random_16_digits(self):
        # 1234 5678 9012 3456 does not pass Luhn
        matches = find_pii("Number: 1234 5678 9012 3456")
        names = [m.pattern_name for m in matches]
        assert "credit_card" not in names

    def test_with_dashes(self):
        matches = find_pii("Card: 4111-1111-1111-1111")
        names = [m.pattern_name for m in matches]
        assert "credit_card" in names


class TestIPAddressPattern:
    def test_valid_ipv4(self):
        matches = find_pii("Server at 192.168.1.100")
        names = [m.pattern_name for m in matches]
        assert "ip_address" in names

    def test_rejects_out_of_range(self):
        matches = find_pii("Not an IP: 999.999.999.999")
        names = [m.pattern_name for m in matches]
        assert "ip_address" not in names

    def test_loopback(self):
        matches = find_pii("Localhost: 127.0.0.1")
        names = [m.pattern_name for m in matches]
        assert "ip_address" in names

    def test_ipv4_cidr(self):
        matches = find_pii("Subnet: 10.0.0.0/24")
        names = [m.pattern_name for m in matches]
        assert "ip_address" in names

    def test_ipv6_full(self):
        matches = find_pii("Address: 2001:0db8:85a3:0000:0000:8a2e:0370:7334")
        names = [m.pattern_name for m in matches]
        assert "ip_address" in names

    def test_ipv6_compressed(self):
        matches = find_pii("Address: 2001:db8::1")
        names = [m.pattern_name for m in matches]
        assert "ip_address" in names

    def test_ipv6_loopback(self):
        matches = find_pii("Loopback: ::1")
        names = [m.pattern_name for m in matches]
        assert "ip_address" in names

    def test_ipv6_no_false_positive_on_colon_text(self):
        matches = find_pii("Time is 12:30:45")
        ip_matches = [m for m in matches if m.pattern_name == "ip_address"]
        assert len(ip_matches) == 0


class TestIBANPattern:
    def test_german_iban_compact(self):
        matches = find_pii("IBAN: DE89370400440532013000")
        names = [m.pattern_name for m in matches]
        assert "iban" in names

    def test_german_iban_spaced(self):
        matches = find_pii("IBAN: DE89 3704 0044 0532 0130 00")
        names = [m.pattern_name for m in matches]
        assert "iban" in names

    def test_german_iban_dashed(self):
        matches = find_pii("IBAN: DE89-3704-0044-0532-0130-00")
        names = [m.pattern_name for m in matches]
        assert "iban" in names

    def test_gb_iban(self):
        matches = find_pii("IBAN: GB29NWBK60161331926819")
        names = [m.pattern_name for m in matches]
        assert "iban" in names

    def test_rejects_random_string(self):
        matches = find_pii("Code: ABCDEFGHIJKLMNOP")
        names = [m.pattern_name for m in matches]
        assert "iban" not in names


class TestFindPII:
    def test_multiple_pii_in_one_string(self):
        text = "Email: user@test.com, SSN: 123-45-6789"
        matches = find_pii(text)
        names = {m.pattern_name for m in matches}
        assert "email" in names
        assert "ssn" in names

    def test_pii_match_has_span(self):
        matches = find_pii("test user@example.com end")
        email_match = [m for m in matches if m.pattern_name == "email"][0]
        assert email_match.start == 5
        assert email_match.end == 21

    def test_pii_in_json_value(self):
        text = '{"email": "user@example.com", "id": 42}'
        matches = find_pii(text)
        names = [m.pattern_name for m in matches]
        assert "email" in names

    def test_pii_at_string_boundaries(self):
        matches = find_pii("user@example.com")
        assert len(matches) >= 1
        assert matches[0].pattern_name == "email"

    def test_empty_string(self):
        assert find_pii("") == []

    def test_no_pii(self):
        assert find_pii("This is a normal sentence without PII.") == []


# ---------------------------------------------------------------------------
# Scrubber tests
# ---------------------------------------------------------------------------

class TestPIIScrubberHMAC:
    def test_same_email_same_session_same_token(self):
        scrubber = PIIScrubber(session_key=b"test-key-123")
        trace = _make_trace(
            messages=[
                TraceMessage(index=0, role="user", content="email: user@test.com"),
                TraceMessage(index=1, role="user", content="again: user@test.com"),
            ]
        )
        result = scrubber.scrub(trace)
        # Both should have the same replacement token
        assert result.messages[0].content == result.messages[1].content.replace("again: ", "email: ")

    def test_different_session_different_token(self):
        trace = _make_trace(
            messages=[TraceMessage(index=0, role="user", content="email: user@test.com")]
        )
        scrubber_a = PIIScrubber(session_key=b"key-aaa")
        scrubber_b = PIIScrubber(session_key=b"key-bbb")
        result_a = scrubber_a.scrub(trace)
        result_b = scrubber_b.scrub(trace)
        assert result_a.messages[0].content != result_b.messages[0].content

    def test_token_format(self):
        scrubber = PIIScrubber(session_key=b"test-key")
        trace = _make_trace(
            messages=[TraceMessage(index=0, role="user", content="user@test.com")]
        )
        result = scrubber.scrub(trace)
        content = result.messages[0].content
        assert content.startswith("[PII:email:")
        assert content.endswith("]")
        # Format: [PII:email:a1b2c3d4]
        parts = content.strip("[]").split(":")
        assert parts[0] == "PII"
        assert parts[1] == "email"
        assert len(parts[2]) == 8  # 8 hex chars


class TestPIIScrubberFieldPaths:
    def test_field_path_always_scrubbed(self):
        scrubber = PIIScrubber(
            session_key=b"test-key",
            field_paths=["user_email"],
        )
        trace = _make_trace(
            tags={"user_email": "not-an-email-but-should-be-scrubbed"},
        )
        result = scrubber.scrub(trace)
        assert result.tags["user_email"] != "not-an-email-but-should-be-scrubbed"
        assert "[PII:field:" in result.tags["user_email"]

    def test_nested_field_path_in_tool_args(self):
        scrubber = PIIScrubber(
            session_key=b"test-key",
            field_paths=["payment.card_number"],
        )
        trace = _make_trace(
            tool_calls=[
                ToolExecution(
                    index=0,
                    name="charge",
                    arguments={"payment": {"card_number": "secret-value"}},
                    result="ok",
                    duration_ms=10.0,
                    timestamp=datetime(2026, 4, 12, 10, 0, 1, tzinfo=timezone.utc),
                )
            ]
        )
        result = scrubber.scrub(trace)
        assert result.tool_calls[0].arguments["payment"]["card_number"] != "secret-value"


class TestPIIScrubberBeforeSend:
    def test_before_send_hook_called(self):
        def custom_hook(trace: AiyaraTrace) -> AiyaraTrace:
            # Custom scrubbing: replace all "SECRET" with "REDACTED"
            new_messages = []
            for msg in trace.messages:
                new_messages.append(
                    msg.model_copy(update={"content": msg.content.replace("SECRET", "REDACTED")})
                )
            return trace.model_copy(update={"messages": new_messages})

        scrubber = PIIScrubber(session_key=b"test-key", before_send=custom_hook)
        trace = _make_trace(
            messages=[TraceMessage(index=0, role="user", content="my SECRET data")]
        )
        result = scrubber.scrub(trace)
        assert "SECRET" not in result.messages[0].content
        assert "REDACTED" in result.messages[0].content


class TestPIIScrubberDisabled:
    def test_disabled_returns_unchanged(self):
        scrubber = PIIScrubber(enabled=False)
        trace = _make_trace(
            messages=[TraceMessage(index=0, role="user", content="user@test.com")]
        )
        result = scrubber.scrub(trace)
        assert result.messages[0].content == "user@test.com"


class TestPIIScrubberDeepCopy:
    def test_original_trace_unmodified(self):
        scrubber = PIIScrubber(session_key=b"test-key")
        trace = _make_trace(
            messages=[TraceMessage(index=0, role="user", content="user@test.com")]
        )
        original_content = trace.messages[0].content
        _result = scrubber.scrub(trace)
        assert trace.messages[0].content == original_content


class TestPIIScrubberNestedPII:
    def test_pii_in_tool_call_arguments(self):
        scrubber = PIIScrubber(session_key=b"test-key")
        trace = _make_trace(
            tool_calls=[
                ToolExecution(
                    index=0,
                    name="update_contact",
                    arguments={"email": "secret@company.com", "name": "John"},
                    result="updated",
                    duration_ms=10.0,
                    timestamp=datetime(2026, 4, 12, 10, 0, 1, tzinfo=timezone.utc),
                )
            ]
        )
        result = scrubber.scrub(trace)
        assert "secret@company.com" not in str(result.tool_calls[0].arguments)
        assert "[PII:email:" in str(result.tool_calls[0].arguments)

    def test_pii_in_tool_call_result(self):
        scrubber = PIIScrubber(session_key=b"test-key")
        trace = _make_trace(
            tool_calls=[
                ToolExecution(
                    index=0,
                    name="get_contact",
                    arguments={},
                    result='{"email": "user@company.com"}',
                    duration_ms=10.0,
                    timestamp=datetime(2026, 4, 12, 10, 0, 1, tzinfo=timezone.utc),
                )
            ]
        )
        result = scrubber.scrub(trace)
        assert "user@company.com" not in result.tool_calls[0].result
        assert "[PII:email:" in result.tool_calls[0].result


class TestPIIScrubberMaxPayload:
    def test_large_trace_truncated(self):
        # Create a trace with a huge result string (> 5MB)
        big_content = "x" * (6 * 1024 * 1024)  # 6MB
        scrubber = PIIScrubber(session_key=b"test-key")
        trace = _make_trace(
            tool_calls=[
                ToolExecution(
                    index=0,
                    name="big_tool",
                    arguments={},
                    result=big_content,
                    duration_ms=10.0,
                    timestamp=datetime(2026, 4, 12, 10, 0, 1, tzinfo=timezone.utc),
                )
            ]
        )
        result = scrubber.scrub(trace)
        # The result field should be truncated, not the full 6MB
        assert len(result.tool_calls[0].result) <= 100 * 1024 + 100  # max_field_bytes + margin


class TestPIIScrubberPerformance:
    def test_50_field_scrub_under_10ms(self):
        scrubber = PIIScrubber(session_key=b"perf-test-key")
        messages = [
            TraceMessage(
                index=i,
                role="user",
                content=f"Contact user{i}@example.com for order {i}",
            )
            for i in range(25)
        ]
        tools = [
            ToolExecution(
                index=i,
                name=f"tool_{i}",
                arguments={"email": f"agent{i}@corp.com"},
                result=f'{{"phone": "+1 555-{i:04d}"}}',
                duration_ms=1.0,
                timestamp=datetime(2026, 4, 12, 10, 0, i, tzinfo=timezone.utc),
            )
            for i in range(25)
        ]
        trace = _make_trace(messages=messages, tool_calls=tools)

        start = time.perf_counter()
        _result = scrubber.scrub(trace)
        elapsed_ms = (time.perf_counter() - start) * 1000

        assert elapsed_ms < 10, f"Scrubbing took {elapsed_ms:.2f}ms, expected < 10ms"


class TestPIIScrubberAutoSessionKey:
    def test_auto_generates_session_key(self):
        """If no session_key provided, auto-generate one."""
        scrubber = PIIScrubber()
        trace = _make_trace(
            messages=[TraceMessage(index=0, role="user", content="user@test.com")]
        )
        result = scrubber.scrub(trace)
        assert "user@test.com" not in result.messages[0].content
        assert "[PII:email:" in result.messages[0].content


class TestPIIScrubberExtraPatterns:
    def test_extra_pattern_applied(self):
        import re
        custom = [("custom_id", re.compile(r"CUST-\d{6}"))]
        scrubber = PIIScrubber(session_key=b"test-key", extra_patterns=custom)
        trace = _make_trace(
            messages=[TraceMessage(index=0, role="user", content="Customer CUST-123456")]
        )
        result = scrubber.scrub(trace)
        assert "CUST-123456" not in result.messages[0].content
        assert "[PII:custom_id:" in result.messages[0].content
