"""Tests for TraceBuffer — bounded in-memory buffer with FIFO eviction."""

import pytest

from aiyara.buffer import TraceBuffer


class TestTraceBufferBasic:
    """Core buffer operations."""

    def test_add_single_event(self):
        buf = TraceBuffer(max_size=10)
        result = buf.add({"trace_id": "t1"})
        assert result is True
        assert buf.size == 1
        assert not buf.is_empty

    def test_add_multiple_events_preserves_order(self):
        buf = TraceBuffer(max_size=10)
        for i in range(5):
            buf.add({"index": i})
        events = buf.drain(5)
        assert [e["index"] for e in events] == [0, 1, 2, 3, 4]

    def test_add_up_to_max_size_all_retained(self):
        buf = TraceBuffer(max_size=5)
        for i in range(5):
            assert buf.add({"index": i}) is True
        assert buf.size == 5
        assert buf.is_full
        assert buf.dropped_count == 0

    def test_empty_buffer_properties(self):
        buf = TraceBuffer(max_size=10)
        assert buf.is_empty is True
        assert buf.is_full is False
        assert buf.size == 0
        assert buf.dropped_count == 0


class TestTraceBufferOverflow:
    """Overflow eviction behavior."""

    def test_overflow_evicts_oldest(self):
        buf = TraceBuffer(max_size=3)
        buf.add({"index": 0})
        buf.add({"index": 1})
        buf.add({"index": 2})
        # This should evict index 0
        buf.add({"index": 3})
        assert buf.size == 3
        events = buf.drain(3)
        assert [e["index"] for e in events] == [1, 2, 3]

    def test_overflow_increments_dropped_count(self):
        buf = TraceBuffer(max_size=2)
        buf.add({"index": 0})
        buf.add({"index": 1})
        result = buf.add({"index": 2})
        assert result is False
        assert buf.dropped_count == 1

    def test_multiple_overflows_accumulate_dropped_count(self):
        buf = TraceBuffer(max_size=2)
        for i in range(10):
            buf.add({"index": i})
        assert buf.dropped_count == 8
        assert buf.size == 2
        events = buf.drain(2)
        assert [e["index"] for e in events] == [8, 9]


class TestTraceBufferDrain:
    """Drain removes events from the front."""

    def test_drain_returns_batch_size_events(self):
        buf = TraceBuffer(max_size=10)
        for i in range(10):
            buf.add({"index": i})
        events = buf.drain(3)
        assert len(events) == 3
        assert buf.size == 7

    def test_drain_returns_all_if_less_than_batch_size(self):
        buf = TraceBuffer(max_size=10)
        buf.add({"index": 0})
        buf.add({"index": 1})
        events = buf.drain(5)
        assert len(events) == 2
        assert buf.is_empty

    def test_drain_empty_buffer_returns_empty_list(self):
        buf = TraceBuffer(max_size=10)
        events = buf.drain(5)
        assert events == []

    def test_drain_removes_events(self):
        buf = TraceBuffer(max_size=10)
        for i in range(5):
            buf.add({"index": i})
        buf.drain(3)
        remaining = buf.drain(10)
        assert [e["index"] for e in remaining] == [3, 4]


class TestTraceBufferPeek:
    """Peek returns events without removing them."""

    def test_peek_returns_events_without_removing(self):
        buf = TraceBuffer(max_size=10)
        for i in range(5):
            buf.add({"index": i})
        peeked = buf.peek(3)
        assert len(peeked) == 3
        assert buf.size == 5  # unchanged

    def test_peek_returns_front_events(self):
        buf = TraceBuffer(max_size=10)
        for i in range(5):
            buf.add({"index": i})
        peeked = buf.peek(2)
        assert [e["index"] for e in peeked] == [0, 1]


class TestTraceBufferRequeue:
    """Requeue puts events back at the front."""

    def test_requeue_puts_events_at_front(self):
        buf = TraceBuffer(max_size=10)
        buf.add({"index": 3})
        buf.add({"index": 4})
        buf.requeue([{"index": 1}, {"index": 2}])
        events = buf.drain(10)
        assert [e["index"] for e in events] == [1, 2, 3, 4]

    def test_requeue_respects_max_size(self):
        buf = TraceBuffer(max_size=3)
        buf.add({"index": 3})
        buf.add({"index": 4})
        buf.add({"index": 5})
        # Requeue 2 events into a full buffer — oldest should be evicted
        buf.requeue([{"index": 1}, {"index": 2}])
        assert buf.size == 3
        events = buf.drain(10)
        # Requeued events go to front, tail gets evicted
        assert [e["index"] for e in events] == [1, 2, 3]
