"""Tests for framework instrumentors (OpenAI, LangGraph, OpenAI Agents SDK).

Uses mock modules and objects since the real frameworks are heavy dependencies
not included in the SDK's dev requirements.
"""

from __future__ import annotations

import importlib.util
import sys
import types
from unittest.mock import MagicMock, patch

import pytest

from aiyara.client import AiyaraClient


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_client(**overrides) -> AiyaraClient:
    """Create a client with a mock transport for testing."""
    defaults = {
        "api_key": "test-key",
        "scrub_pii": False,
        "sample_rate": 1.0,
    }
    defaults.update(overrides)
    client = AiyaraClient(**defaults)
    client._transport = MagicMock()
    return client


def _sent_traces(client: AiyaraClient) -> list[dict]:
    """Extract all traces sent through the mock transport."""
    return [call.args[0] for call in client._transport.send.call_args_list]


# ---------------------------------------------------------------------------
# OpenAI Instrumentor
# ---------------------------------------------------------------------------


class TestOpenAIInstrumentor:
    """Test OpenAI client monkey-patching."""

    def test_is_available_false_when_not_installed(self):
        """is_available returns False when openai not importable."""
        from aiyara.instrumentors.openai_instrumentor import OpenAIInstrumentor

        client = _make_client()
        inst = OpenAIInstrumentor(client)

        with patch.object(importlib.util, "find_spec", return_value=None):
            assert inst.is_available is False

    def test_instrument_noop_when_unavailable(self):
        """instrument() does nothing when openai not installed."""
        from aiyara.instrumentors.openai_instrumentor import OpenAIInstrumentor

        client = _make_client()
        inst = OpenAIInstrumentor(client)

        with patch.object(importlib.util, "find_spec", return_value=None):
            inst.instrument()
            assert not inst._patched

    def test_patches_create_and_captures_trace(self):
        """Instrumentor patches Completions.create and captures trace data."""
        from aiyara.instrumentors.openai_instrumentor import OpenAIInstrumentor

        client = _make_client()
        inst = OpenAIInstrumentor(client)

        # Create a mock completions module with a Completions class
        mock_mod = types.ModuleType("mock_completions")

        class MockCompletions:
            def create(self, **kwargs):
                response = MagicMock()
                response.model = "gpt-4o"
                response.choices = [MagicMock()]
                response.choices[0].message.tool_calls = None
                response.usage = MagicMock(total_tokens=150)
                return response

        mock_mod.Completions = MockCompletions

        with patch("importlib.util.find_spec", return_value=True):
            with patch.object(inst, "_import_completions_module", return_value=mock_mod):
                inst.instrument()
                assert inst._patched

                # Call the patched create
                comp = MockCompletions()
                comp.create(
                    model="gpt-4o",
                    messages=[
                        {"role": "system", "content": "You are helpful"},
                        {"role": "user", "content": "Hello"},
                    ],
                )

                # Verify trace was captured
                assert client._transport.send.called
                sent = _sent_traces(client)[0]
                assert sent["model"] == "gpt-4o"
                assert len(sent["messages"]) == 2

    def test_captures_tool_calls_from_response(self):
        """Instrumentor captures tool calls from assistant's response."""
        from aiyara.instrumentors.openai_instrumentor import OpenAIInstrumentor

        client = _make_client()
        inst = OpenAIInstrumentor(client)

        mock_mod = types.ModuleType("mock_completions")

        class MockCompletions:
            def create(self, **kwargs):
                response = MagicMock()
                response.model = "gpt-4o"

                # Simulate tool call in response
                tool_call = MagicMock()
                tool_call.id = "tc_001"
                tool_call.function.name = "search"
                tool_call.function.arguments = '{"query": "flights to SF"}'

                response.choices = [MagicMock()]
                response.choices[0].message.tool_calls = [tool_call]
                response.usage = MagicMock(total_tokens=200)
                return response

        mock_mod.Completions = MockCompletions

        with patch("importlib.util.find_spec", return_value=True):
            with patch.object(inst, "_import_completions_module", return_value=mock_mod):
                inst.instrument()

                comp = MockCompletions()
                comp.create(
                    model="gpt-4o",
                    messages=[{"role": "user", "content": "Find flights"}],
                )

                sent = _sent_traces(client)[0]
                assert len(sent["tool_calls"]) == 1
                assert sent["tool_calls"][0]["name"] == "search"
                assert sent["tool_calls"][0]["arguments"]["query"] == "flights to SF"
                # First call: result is empty (pending)
                assert sent["tool_calls"][0]["result"] == ""

    def test_correlates_tool_results_across_calls(self):
        """Tool results from subsequent create() calls are matched to pending calls."""
        from aiyara.instrumentors.openai_instrumentor import OpenAIInstrumentor

        client = _make_client()
        inst = OpenAIInstrumentor(client)

        mock_mod = types.ModuleType("mock_completions")
        call_count = [0]

        class MockCompletions:
            def create(self, **kwargs):
                call_count[0] += 1
                response = MagicMock()
                response.model = "gpt-4o"
                response.usage = MagicMock(total_tokens=100)

                if call_count[0] == 1:
                    # First call: model requests a tool call
                    tc = MagicMock()
                    tc.id = "tc_abc"
                    tc.function.name = "search_flights"
                    tc.function.arguments = '{"from": "LAX", "to": "JFK"}'
                    response.choices = [MagicMock()]
                    response.choices[0].message.tool_calls = [tc]
                else:
                    # Second call: model gives final answer (no tool calls)
                    response.choices = [MagicMock()]
                    response.choices[0].message.tool_calls = None
                return response

        mock_mod.Completions = MockCompletions

        with patch("importlib.util.find_spec", return_value=True):
            with patch.object(inst, "_import_completions_module", return_value=mock_mod):
                inst.instrument()
                comp = MockCompletions()

                # Call 1: user message -> model requests tool
                comp.create(
                    model="gpt-4o",
                    messages=[{"role": "user", "content": "Find flights"}],
                )

                # Call 2: includes tool result message -> model gives answer
                comp.create(
                    model="gpt-4o",
                    messages=[
                        {"role": "user", "content": "Find flights"},
                        {"role": "assistant", "content": "", "tool_calls": [{"id": "tc_abc"}]},
                        {"role": "tool", "tool_call_id": "tc_abc", "content": '{"flights": [{"id": "F1", "price": 299}]}'},
                    ],
                )

                traces = _sent_traces(client)
                assert len(traces) == 2

                # First trace: pending tool call with empty result
                assert traces[0]["tool_calls"][0]["name"] == "search_flights"
                assert traces[0]["tool_calls"][0]["result"] == ""

                # Second trace: completed tool call WITH result
                completed = [tc for tc in traces[1]["tool_calls"] if tc["result"]]
                assert len(completed) == 1
                assert completed[0]["name"] == "search_flights"
                assert "F1" in completed[0]["result"]
                assert completed[0]["arguments"]["from"] == "LAX"

    def test_uninstrument_restores_original(self):
        """uninstrument() restores the original create method."""
        from aiyara.instrumentors.openai_instrumentor import OpenAIInstrumentor

        client = _make_client()
        inst = OpenAIInstrumentor(client)

        mock_mod = types.ModuleType("mock_completions")

        class MockCompletions:
            def create(self, **kwargs):
                return MagicMock()

        original_create = MockCompletions.create
        mock_mod.Completions = MockCompletions

        with patch("importlib.util.find_spec", return_value=True):
            with patch.object(inst, "_import_completions_module", return_value=mock_mod):
                inst.instrument()
                assert MockCompletions.create is not original_create

                inst.uninstrument()
                assert MockCompletions.create is original_create

    def test_error_reraises_and_captures_failure(self):
        """Instrumentor records failure but re-raises the exception."""
        from aiyara.instrumentors.openai_instrumentor import OpenAIInstrumentor

        client = _make_client()
        inst = OpenAIInstrumentor(client)

        mock_mod = types.ModuleType("mock_completions")

        class MockCompletions:
            def create(self, **kwargs):
                raise ConnectionError("API unreachable")

        mock_mod.Completions = MockCompletions

        with patch("importlib.util.find_spec", return_value=True):
            with patch.object(inst, "_import_completions_module", return_value=mock_mod):
                inst.instrument()

                comp = MockCompletions()
                with pytest.raises(ConnectionError, match="API unreachable"):
                    comp.create(model="gpt-4o", messages=[])

                # Failure trace should be captured
                sent = _sent_traces(client)[0]
                assert sent["outcome"]["success"] is False


# ---------------------------------------------------------------------------
# LangGraph Instrumentor
# ---------------------------------------------------------------------------


class TestLangGraphInstrumentor:
    """Test LangGraph graph wrapper."""

    def test_is_available_false_when_not_installed(self):
        """is_available returns False when langgraph not importable."""
        from aiyara.instrumentors.langgraph_instrumentor import (
            LangGraphInstrumentor,
        )

        client = _make_client()
        inst = LangGraphInstrumentor(client)

        with patch.object(importlib.util, "find_spec", return_value=None):
            assert inst.is_available is False

    def test_wrap_invoke_captures_trace(self):
        """wrap() patches invoke and captures trace on call."""
        from aiyara.instrumentors.langgraph_instrumentor import (
            LangGraphInstrumentor,
        )

        client = _make_client()
        inst = LangGraphInstrumentor(client)

        # Create fake compiled graph
        class FakeCompiledGraph:
            def invoke(self, input_data, **kwargs):
                return {"messages": [], "result": "done"}

        graph = FakeCompiledGraph()
        wrapped = inst.wrap(graph)

        result = wrapped.invoke({"input": "test"})
        assert result["result"] == "done"

        # Trace should be captured
        assert client._transport.send.called

    def test_wrap_is_idempotent(self):
        """Wrapping the same graph twice doesn't double-wrap."""
        from aiyara.instrumentors.langgraph_instrumentor import (
            LangGraphInstrumentor,
        )

        client = _make_client()
        inst = LangGraphInstrumentor(client)

        class FakeCompiledGraph:
            def invoke(self, input_data, **kwargs):
                return {}

        graph = FakeCompiledGraph()
        wrapped1 = inst.wrap(graph)
        wrapped2 = inst.wrap(wrapped1)
        assert wrapped1 is wrapped2

    def test_wrap_stream_captures_on_completion(self):
        """Wrapped stream captures trace when iterator completes."""
        from aiyara.instrumentors.langgraph_instrumentor import (
            LangGraphInstrumentor,
        )

        client = _make_client()
        inst = LangGraphInstrumentor(client)

        class FakeCompiledGraph:
            def invoke(self, input_data, **kwargs):
                return {}

            def stream(self, input_data, **kwargs):
                yield {"step": 1}
                yield {"step": 2}

        graph = FakeCompiledGraph()
        wrapped = inst.wrap(graph)

        results = list(wrapped.stream({"input": "test"}))
        assert len(results) == 2

        # Trace captured after iteration completes
        assert client._transport.send.called

    def test_wrap_invoke_error_captures_failure(self):
        """Wrapped invoke captures failure outcome on exception."""
        from aiyara.instrumentors.langgraph_instrumentor import (
            LangGraphInstrumentor,
        )

        client = _make_client()
        inst = LangGraphInstrumentor(client)

        class FakeCompiledGraph:
            def invoke(self, input_data, **kwargs):
                raise RuntimeError("graph failed")

        graph = FakeCompiledGraph()
        wrapped = inst.wrap(graph)

        with pytest.raises(RuntimeError, match="graph failed"):
            wrapped.invoke({"input": "test"})

        sent = _sent_traces(client)[0]
        assert sent["outcome"]["success"] is False

    def test_uninstrument_without_instrument_noop(self):
        """uninstrument() is safe to call without instrument()."""
        from aiyara.instrumentors.langgraph_instrumentor import (
            LangGraphInstrumentor,
        )

        client = _make_client()
        inst = LangGraphInstrumentor(client)
        inst.uninstrument()  # Should not raise


# ---------------------------------------------------------------------------
# OpenAI Agents SDK Instrumentor
# ---------------------------------------------------------------------------


class TestOpenAIAgentsInstrumentor:
    """Test OpenAI Agents SDK Runner patching."""

    def test_is_available_false_when_not_installed(self):
        """is_available returns False when agents not importable."""
        from aiyara.instrumentors.openai_agents_instrumentor import (
            OpenAIAgentsInstrumentor,
        )

        client = _make_client()
        inst = OpenAIAgentsInstrumentor(client)

        with patch.object(importlib.util, "find_spec", return_value=None):
            assert inst.is_available is False

    def test_patches_run_sync_and_captures(self):
        """Instrumentor patches Runner.run_sync and captures trace."""
        from aiyara.instrumentors.openai_agents_instrumentor import (
            OpenAIAgentsInstrumentor,
        )

        client = _make_client()
        inst = OpenAIAgentsInstrumentor(client)

        # Create mock agents module
        mock_agents_mod = types.ModuleType("agents")

        class MockRunResult:
            new_items = []

        class MockRunner:
            @staticmethod
            def run_sync(*args, **kwargs):
                return MockRunResult()

            @staticmethod
            async def run(*args, **kwargs):
                return MockRunResult()

        mock_agents_mod.Runner = MockRunner

        with patch.dict(sys.modules, {"agents": mock_agents_mod}):
            with patch.object(importlib.util, "find_spec", return_value=True):
                inst.instrument()
                assert inst._patched

                # Call patched run_sync
                result = MockRunner.run_sync(agent=MagicMock(), input="Hello")
                assert isinstance(result, MockRunResult)

                # Trace should be captured
                assert client._transport.send.called

    def test_captures_tool_calls_from_result(self):
        """Instrumentor extracts tool calls from RunResult.new_items."""
        from aiyara.instrumentors.openai_agents_instrumentor import (
            OpenAIAgentsInstrumentor,
        )

        client = _make_client()
        inst = OpenAIAgentsInstrumentor(client)

        mock_agents_mod = types.ModuleType("agents")

        class MockToolCallItem:
            """Simulates a tool call item in new_items."""

            def __init__(self):
                self.name = "search_flights"
                self.arguments = {"destination": "SF"}
                self.output = "Found 5 flights"

        # Name the class to match the instrumentor's type-name check
        MockToolCallItem.__name__ = "ToolCallItem"

        class MockRunResult:
            new_items = [MockToolCallItem()]

        class MockRunner:
            @staticmethod
            def run_sync(*args, **kwargs):
                return MockRunResult()

            @staticmethod
            async def run(*args, **kwargs):
                return MockRunResult()

        mock_agents_mod.Runner = MockRunner

        with patch.dict(sys.modules, {"agents": mock_agents_mod}):
            with patch.object(importlib.util, "find_spec", return_value=True):
                inst.instrument()

                MockRunner.run_sync(agent=MagicMock(), input="Find flights")

                sent = _sent_traces(client)[0]
                assert len(sent["tool_calls"]) == 1
                assert sent["tool_calls"][0]["name"] == "search_flights"

    def test_uninstrument_restores_original(self):
        """uninstrument() restores the original Runner methods."""
        from aiyara.instrumentors.openai_agents_instrumentor import (
            OpenAIAgentsInstrumentor,
        )

        client = _make_client()
        inst = OpenAIAgentsInstrumentor(client)

        mock_agents_mod = types.ModuleType("agents")

        class MockRunner:
            @staticmethod
            def run_sync(*args, **kwargs):
                return MagicMock()

            @staticmethod
            async def run(*args, **kwargs):
                return MagicMock()

        original_run = MockRunner.run
        original_run_sync = MockRunner.run_sync
        mock_agents_mod.Runner = MockRunner

        with patch.dict(sys.modules, {"agents": mock_agents_mod}):
            with patch.object(importlib.util, "find_spec", return_value=True):
                inst.instrument()
                assert MockRunner.run is not original_run

                inst.uninstrument()
                assert MockRunner.run is original_run
                assert MockRunner.run_sync is original_run_sync


# ---------------------------------------------------------------------------
# Auto-instrument Registry
# ---------------------------------------------------------------------------


class TestAutoInstrument:
    """Test the auto_instrument() registry function."""

    def test_returns_empty_when_nothing_available(self):
        """auto_instrument returns empty list when no frameworks installed."""
        from aiyara.instrumentors import auto_instrument

        client = _make_client()

        with patch.object(importlib.util, "find_spec", return_value=None):
            result = auto_instrument(client)
            assert result == []

    def test_instruments_available_frameworks(self):
        """auto_instrument discovers and instruments available frameworks."""
        from aiyara.instrumentors import INSTRUMENTORS, auto_instrument

        client = _make_client()

        # Mock all instrumentors as available and trackable
        mock_instrumentors = {}
        for name in INSTRUMENTORS:
            mock_inst = MagicMock()
            mock_inst.is_available = True
            mock_instrumentors[name] = mock_inst

        # lambda _c captures the mock correctly (ignores client arg)
        with patch.dict(
            INSTRUMENTORS,
            {name: (lambda _c, mi=mi: mi) for name, mi in mock_instrumentors.items()},
        ):
            result = auto_instrument(client)

        # Phase 86 demo-prep: anthropic added to the registry as a
        # first-class instrumentor — assert membership rather than a
        # frozen count so future framework adds don't break this test.
        assert set(result) >= {"openai", "anthropic", "langgraph", "openai_agents"}
        assert len(result) == len(INSTRUMENTORS)

    def test_skips_unavailable_frameworks(self):
        """auto_instrument skips frameworks that aren't installed."""
        from aiyara.instrumentors import INSTRUMENTORS, auto_instrument

        client = _make_client()

        # Only openai available
        mock_openai = MagicMock()
        mock_openai.is_available = True

        mock_langgraph = MagicMock()
        mock_langgraph.is_available = False

        mock_agents = MagicMock()
        mock_agents.is_available = False

        mocks = {
            "openai": lambda c: mock_openai,
            "langgraph": lambda c: mock_langgraph,
            "openai_agents": lambda c: mock_agents,
        }

        with patch.dict(INSTRUMENTORS, mocks):
            result = auto_instrument(client)

        assert result == ["openai"]
        mock_openai.instrument.assert_called_once()
        mock_langgraph.instrument.assert_not_called()
        mock_agents.instrument.assert_not_called()


# ---------------------------------------------------------------------------
# Anthropic Instrumentor (Phase 86 demo-prep — first-class)
# ---------------------------------------------------------------------------


class TestAnthropicInstrumentor:
    """Test Anthropic Messages.create monkey-patching."""

    def test_is_available_false_when_not_installed(self):
        from aiyara.instrumentors.anthropic_instrumentor import AnthropicInstrumentor

        client = _make_client()
        inst = AnthropicInstrumentor(client)

        with patch.object(importlib.util, "find_spec", return_value=None):
            assert inst.is_available is False

    def test_instrument_noop_when_unavailable(self):
        from aiyara.instrumentors.anthropic_instrumentor import AnthropicInstrumentor

        client = _make_client()
        inst = AnthropicInstrumentor(client)

        with patch.object(importlib.util, "find_spec", return_value=None):
            inst.instrument()
            assert not inst._patched

    def _build_mock_messages_module(self, response):
        """Build a mock anthropic.resources.messages.messages module."""
        mock_mod = types.ModuleType("mock_anthropic_messages")

        class MockMessages:
            def create(self, **kwargs):
                return response

        mock_mod.Messages = MockMessages
        # AsyncMessages intentionally omitted — we verify async wiring in
        # a separate test where it matters.
        return mock_mod, MockMessages

    def test_patches_create_and_captures_trace(self):
        """Patch Messages.create, verify a basic call lands a trace."""
        from aiyara.instrumentors.anthropic_instrumentor import AnthropicInstrumentor

        client = _make_client()
        inst = AnthropicInstrumentor(client)

        response = MagicMock()
        response.model = "claude-3-5-sonnet"
        response.content = []  # No tool_use blocks
        mock_mod, MockMessages = self._build_mock_messages_module(response)

        with patch("importlib.util.find_spec", return_value=True):
            with patch.object(inst, "_import_messages_module", return_value=mock_mod):
                inst.instrument()
                assert inst._patched

                msg = MockMessages()
                msg.create(
                    model="claude-3-5-sonnet",
                    system="You are a helpful agent.",
                    messages=[
                        {"role": "user", "content": "Hi"},
                    ],
                )

        sent = _sent_traces(client)
        assert len(sent) == 1
        assert sent[0]["model"] == "claude-3-5-sonnet"
        # System prompt is hoisted into the messages list as a system role.
        roles = [m["role"] for m in sent[0]["messages"]]
        assert "system" in roles
        assert "user" in roles

    def test_extracts_tool_use_blocks_from_response(self):
        """tool_use blocks in response.content normalize to tool_calls."""
        from aiyara.instrumentors.anthropic_instrumentor import AnthropicInstrumentor

        client = _make_client()
        inst = AnthropicInstrumentor(client)

        # Response carries one tool_use block.
        tool_block = MagicMock()
        tool_block.type = "tool_use"
        tool_block.id = "toolu_abc"
        tool_block.name = "get_weather"
        tool_block.input = {"city": "Tokyo"}

        response = MagicMock()
        response.model = "claude-3-5-sonnet"
        response.content = [tool_block]

        mock_mod, MockMessages = self._build_mock_messages_module(response)

        with patch("importlib.util.find_spec", return_value=True):
            with patch.object(inst, "_import_messages_module", return_value=mock_mod):
                inst.instrument()
                MockMessages().create(
                    model="claude-3-5-sonnet",
                    messages=[{"role": "user", "content": "What's the weather?"}],
                )

        sent = _sent_traces(client)[0]
        assert sent["tool_calls"] is not None
        assert len(sent["tool_calls"]) == 1
        assert sent["tool_calls"][0]["name"] == "get_weather"
        assert sent["tool_calls"][0]["arguments"] == {"city": "Tokyo"}

    def test_matches_tool_result_to_pending_tool_use(self):
        """A second call carrying tool_result blocks resolves the pending
        tool_use from the prior turn."""
        from aiyara.instrumentors.anthropic_instrumentor import AnthropicInstrumentor

        client = _make_client()
        inst = AnthropicInstrumentor(client)

        tool_block = MagicMock()
        tool_block.type = "tool_use"
        tool_block.id = "toolu_xyz"
        tool_block.name = "search"
        tool_block.input = {"q": "test"}

        first_response = MagicMock()
        first_response.model = "claude-3-5-sonnet"
        first_response.content = [tool_block]

        # Second call returns a plain text response with no new tool calls.
        second_response = MagicMock()
        second_response.model = "claude-3-5-sonnet"
        second_response.content = []

        responses = [first_response, second_response]
        mock_mod = types.ModuleType("mock_anthropic_messages_v2")

        class MockMessagesV2:
            def create(self, **kwargs):
                return responses.pop(0)

        mock_mod.Messages = MockMessagesV2

        with patch("importlib.util.find_spec", return_value=True):
            with patch.object(inst, "_import_messages_module", return_value=mock_mod):
                inst.instrument()
                m = MockMessagesV2()
                # First turn — assistant emits tool_use.
                m.create(
                    model="claude-3-5-sonnet",
                    messages=[{"role": "user", "content": "search test"}],
                )
                # Second turn — user submits tool_result. The instrumentor
                # should match it against the pending toolu_xyz.
                m.create(
                    model="claude-3-5-sonnet",
                    messages=[
                        {"role": "user", "content": "search test"},
                        {
                            "role": "assistant",
                            "content": [{"type": "tool_use", "id": "toolu_xyz", "name": "search", "input": {"q": "test"}}],
                        },
                        {
                            "role": "user",
                            "content": [
                                {"type": "tool_result", "tool_use_id": "toolu_xyz", "content": "result-payload"}
                            ],
                        },
                    ],
                )

        sent = _sent_traces(client)
        assert len(sent) == 2
        # Second trace's tool_calls includes the resolved one.
        resolved = sent[1]["tool_calls"]
        assert resolved is not None and len(resolved) == 1
        assert resolved[0]["name"] == "search"
        assert resolved[0]["result"] == "result-payload"

    def test_records_error_on_create_failure(self):
        """A raised exception lands a failure trace."""
        from aiyara.instrumentors.anthropic_instrumentor import AnthropicInstrumentor

        client = _make_client()
        inst = AnthropicInstrumentor(client)

        class _BoomMessages:
            def create(self, **kwargs):
                raise RuntimeError("upstream went sideways")

        mock_mod = types.ModuleType("mock_anthropic_messages_err")
        mock_mod.Messages = _BoomMessages

        with patch("importlib.util.find_spec", return_value=True):
            with patch.object(inst, "_import_messages_module", return_value=mock_mod):
                inst.instrument()
                with pytest.raises(RuntimeError, match="upstream"):
                    _BoomMessages().create(
                        model="claude-3-5-sonnet",
                        messages=[{"role": "user", "content": "boom"}],
                    )

        sent = _sent_traces(client)
        assert len(sent) == 1
        assert sent[0]["outcome"]["success"] is False
        assert "upstream went sideways" in sent[0]["outcome"]["reason"]

    def test_uninstrument_restores_original(self):
        from aiyara.instrumentors.anthropic_instrumentor import AnthropicInstrumentor

        client = _make_client()
        inst = AnthropicInstrumentor(client)

        response = MagicMock()
        response.model = "claude-3-5-sonnet"
        response.content = []
        mock_mod, MockMessages = self._build_mock_messages_module(response)
        original = MockMessages.create

        with patch("importlib.util.find_spec", return_value=True):
            with patch.object(inst, "_import_messages_module", return_value=mock_mod):
                inst.instrument()
                assert MockMessages.create is not original
                inst.uninstrument()
                assert MockMessages.create is original
                assert not inst._patched

    def test_registry_includes_anthropic(self):
        """The global INSTRUMENTORS dict picks up the new entry."""
        from aiyara.instrumentors import INSTRUMENTORS
        from aiyara.instrumentors.anthropic_instrumentor import AnthropicInstrumentor

        assert INSTRUMENTORS.get("anthropic") is AnthropicInstrumentor
