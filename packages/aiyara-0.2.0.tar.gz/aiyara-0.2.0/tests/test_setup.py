"""Tests for the aiyara setup CLI command."""

from __future__ import annotations

import io
import json
import urllib.error
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

from aiyara.cli.setup import (
    _whoami,
    _wait_for_trace,
    check_connection,
    register_setup_parser,
    setup_command,
    validate_api_key,
    validate_project_name,
    write_env_file,
)


def _parse_args(argv: list[str]):
    """Build + run the full `aiyara` parser (setup subcommand) for tests.

    The existing ``TestSetupCommand`` fixtures short-circuit via
    ``argparse.Namespace(...)`` which means they silently skip every new
    flag that gets added. Non-interactive tests exercise the real parser
    (flag parsing, defaults, store_true behaviour) so bugs there surface.
    """
    import argparse

    parser = argparse.ArgumentParser()
    sub = parser.add_subparsers(dest="command")
    register_setup_parser(sub)
    return parser.parse_args(argv)


# ---------------------------------------------------------------------------
# Project name validation
# ---------------------------------------------------------------------------


class TestProjectNameValidation:
    def test_valid_names(self):
        assert validate_project_name("my-agent") is None
        assert validate_project_name("project123") is None
        assert validate_project_name("MyAgent") is None
        assert validate_project_name("abc") is None
        assert validate_project_name("a" * 50) is None

    def test_too_short(self):
        err = validate_project_name("a")
        assert err is not None
        assert "at least 3" in err

    def test_too_long(self):
        err = validate_project_name("a" * 51)
        assert err is not None
        assert "at most 50" in err

    def test_invalid_chars(self):
        err = validate_project_name("my agent!!")
        assert err is not None
        assert "letters, numbers, and hyphens" in err

    def test_starts_with_hyphen(self):
        err = validate_project_name("-my-agent")
        assert err is not None

    def test_ends_with_hyphen(self):
        err = validate_project_name("my-agent-")
        assert err is not None


# ---------------------------------------------------------------------------
# API key validation
# ---------------------------------------------------------------------------


class TestApiKeyValidation:
    def test_valid_key(self):
        assert validate_api_key("ak_test1234567") is None
        assert validate_api_key("ak_abcdefghij") is None

    def test_missing_prefix(self):
        err = validate_api_key("invalid_key")
        assert err is not None
        assert "ak_" in err

    def test_too_short(self):
        err = validate_api_key("ak_short")
        assert err is not None
        assert "at least" in err

    def test_empty(self):
        err = validate_api_key("")
        assert err is not None


# ---------------------------------------------------------------------------
# .env file generation
# ---------------------------------------------------------------------------


class TestEnvFileGeneration:
    def test_writes_correct_format(self, tmp_path: Path):
        env_path = tmp_path / ".env"
        write_env_file(env_path, "my-agent", "ak_test123456", "https://aiyara-csim.fly.dev")

        content = env_path.read_text()
        assert "AIYARA_PROJECT=my-agent" in content
        assert "AIYARA_API_KEY=ak_test123456" in content
        assert "AIYARA_ENDPOINT=https://aiyara-csim.fly.dev/api/v1/traces" in content

    def test_all_three_variables_present(self, tmp_path: Path):
        env_path = tmp_path / ".env"
        write_env_file(env_path, "test", "ak_abcdefghij", "http://localhost:8321")

        content = env_path.read_text()
        lines = [l for l in content.strip().split("\n") if l.strip()]
        keys = [l.split("=")[0] for l in lines]
        assert "AIYARA_PROJECT" in keys
        assert "AIYARA_API_KEY" in keys
        assert "AIYARA_ENDPOINT" in keys

    def test_write_env_file_strips_trailing_slash(self, tmp_path: Path):
        """Trailing slash on endpoint must not produce // in the env file."""
        env_path = tmp_path / ".env"
        write_env_file(
            env_path,
            "my-agent",
            "ak_test123456",
            "https://aiyara-csim.fly.dev/",
        )
        content = env_path.read_text()
        # Exactly this line must be present (single slash between host + path)
        assert "AIYARA_ENDPOINT=https://aiyara-csim.fly.dev/api/v1/traces" in content
        assert "//api/v1/traces" not in content

        # And calling with no trailing slash yields the identical line.
        env_path2 = tmp_path / ".env2"
        write_env_file(
            env_path2,
            "my-agent",
            "ak_test123456",
            "https://aiyara-csim.fly.dev",
        )
        assert env_path.read_text() == env_path2.read_text()


# ---------------------------------------------------------------------------
# Connection test
# ---------------------------------------------------------------------------


class TestConnectionTest:
    def test_success_with_mock_server(self):
        """Test connection succeeds against mock server."""
        from aiyara.mock_server import MockIngestionServer

        server = MockIngestionServer(port=0)
        server.start()
        try:
            success, msg = check_connection(server.url)
            assert success is True
            assert "Connected" in msg
        finally:
            server.stop()

    def test_failure_unreachable(self):
        """Test connection fails with unreachable server."""
        success, msg = check_connection("http://127.0.0.1:19999", timeout=1.0)
        assert success is False
        assert "Connection" in msg or "refused" in msg.lower() or "error" in msg.lower()

    def test_check_connection_hits_v1_health_path(self):
        """check_connection GETs {endpoint}/api/v1/health, not /__health."""
        import io

        captured: dict[str, str] = {}

        class _Resp:
            status = 200

            def read(self):
                return b'{"status":"healthy","clickhouse":true,"r2":true,"postgres":true,"worker_enabled":true}'

            def __enter__(self):
                return self

            def __exit__(self, *a):
                return None

        def fake_urlopen(req, timeout=5.0):
            captured["url"] = req.full_url
            return _Resp()

        with patch("aiyara.cli.setup.urllib.request.urlopen", side_effect=fake_urlopen):
            success, msg = check_connection("https://aiyara-csim.fly.dev", "ak_test1234567")

        assert success is True
        assert "healthy" in msg.lower()
        assert captured["url"] == "https://aiyara-csim.fly.dev/api/v1/health"

    def test_check_connection_degraded_is_reachable(self):
        """200 + status=degraded is still 'reachable' — traces queue."""
        class _Resp:
            status = 200

            def read(self):
                return b'{"status":"degraded","clickhouse":false,"r2":true,"postgres":true,"worker_enabled":true}'

            def __enter__(self):
                return self

            def __exit__(self, *a):
                return None

        with patch(
            "aiyara.cli.setup.urllib.request.urlopen",
            return_value=_Resp(),
        ):
            success, msg = check_connection("https://aiyara-csim.fly.dev", "ak_test1234567")

        assert success is True
        assert "degraded" in msg.lower()

    def test_check_connection_503_is_failure(self):
        """503 from the ingest service is a failure with a specific hint."""
        import urllib.error

        err = urllib.error.HTTPError(
            url="https://aiyara-csim.fly.dev/api/v1/health",
            code=503,
            msg="Service Unavailable",
            hdrs=None,
            fp=None,
        )
        with patch(
            "aiyara.cli.setup.urllib.request.urlopen",
            side_effect=err,
        ):
            success, msg = check_connection("https://aiyara-csim.fly.dev", "ak_test1234567")

        assert success is False
        assert "503" in msg or "backends unavailable" in msg.lower()

    def test_check_connection_strips_trailing_slash(self):
        """A trailing slash on endpoint must not produce // in the probed URL."""
        captured: dict[str, str] = {}

        class _Resp:
            status = 200

            def read(self):
                return b'{"status":"healthy"}'

            def __enter__(self):
                return self

            def __exit__(self, *a):
                return None

        def fake_urlopen(req, timeout=5.0):
            captured["url"] = req.full_url
            return _Resp()

        with patch("aiyara.cli.setup.urllib.request.urlopen", side_effect=fake_urlopen):
            check_connection("https://aiyara-csim.fly.dev/", "ak_test1234567")

        assert captured["url"] == "https://aiyara-csim.fly.dev/api/v1/health"
        assert "//api/v1/health" not in captured["url"]


# ---------------------------------------------------------------------------
# Setup command (full flow, mocked I/O)
# ---------------------------------------------------------------------------


class TestSetupCommand:
    def test_basic_setup_with_mock_server(self, tmp_path: Path):
        """Full setup flow with --local flag."""
        import argparse

        args = argparse.Namespace(
            endpoint="https://aiyara-csim.fly.dev",
            local=True,
            env_file=str(tmp_path / ".env"),
        )
        output = io.StringIO()

        result = setup_command(
            args,
            input_fn=lambda prompt: "my-agent",
            output=output,
        )

        assert result == 0

        # Verify .env was written
        env_content = (tmp_path / ".env").read_text()
        assert "AIYARA_PROJECT=my-agent" in env_content
        assert "AIYARA_API_KEY=ak_local_dev" in env_content
        assert "127.0.0.1" in env_content

        # Verify output contains expected messages
        out_text = output.getvalue()
        assert "Aiyara Setup" in out_text
        assert "Mock server started" in out_text

    def test_setup_writes_env_with_api_key(self, tmp_path: Path):
        """Full setup with API key (mocked connection)."""
        import argparse

        args = argparse.Namespace(
            endpoint="https://aiyara-csim.fly.dev",
            local=False,
            env_file=str(tmp_path / ".env"),
        )
        output = io.StringIO()

        # Mock the connection test to succeed
        with patch("aiyara.cli.setup.check_connection", return_value=(True, "Connected successfully")):
            with patch("aiyara.cli.setup._wait_for_trace"):
                result = setup_command(
                    args,
                    input_fn=lambda prompt: "my-agent",
                    password_fn=lambda prompt: "ak_test1234567",
                    output=output,
                )

        assert result == 0
        env_content = (tmp_path / ".env").read_text()
        assert "AIYARA_API_KEY=ak_test1234567" in env_content
        assert "AIYARA_PROJECT=my-agent" in env_content

    def test_setup_connection_failure(self, tmp_path: Path):
        """Setup reports error when connection fails."""
        import argparse

        args = argparse.Namespace(
            endpoint="https://aiyara-csim.fly.dev",
            local=False,
            env_file=str(tmp_path / ".env"),
        )
        output = io.StringIO()

        with patch(
            "aiyara.cli.setup.check_connection",
            return_value=(False, "Connection refused"),
        ):
            result = setup_command(
                args,
                input_fn=lambda prompt: "my-agent",
                password_fn=lambda prompt: "ak_test1234567",
                output=output,
            )

        assert result == 1
        out_text = output.getvalue()
        assert "[error]" in out_text


# ---------------------------------------------------------------------------
# CLI parser registration
# ---------------------------------------------------------------------------


class TestSetupParser:
    def test_help_registered(self):
        """setup --help works."""
        import argparse

        parser = argparse.ArgumentParser()
        sub = parser.add_subparsers(dest="command")
        register_setup_parser(sub)

        args = parser.parse_args(["setup", "--local"])
        assert args.command == "setup"
        assert args.local is True

    def test_default_endpoint(self):
        import argparse

        parser = argparse.ArgumentParser()
        sub = parser.add_subparsers(dest="command")
        register_setup_parser(sub)

        args = parser.parse_args(["setup"])
        assert args.endpoint == "https://aiyara-csim.fly.dev"


# ---------------------------------------------------------------------------
# _whoami + _wait_for_trace
# ---------------------------------------------------------------------------


def _make_resp(body: bytes, status: int = 200):
    """Build a minimal context-manager response object for urlopen mocks."""

    class _Resp:
        def __init__(self, body: bytes, status: int) -> None:
            self._body = body
            self.status = status

        def read(self) -> bytes:
            return self._body

        def __enter__(self):
            return self

        def __exit__(self, *a):
            return None

    return _Resp(body, status)


class TestWhoami:
    def test_whoami_returns_project_id_on_success(self):
        resp = _make_resp(b'{"project_id":"p-abc","tenant_id":"t1","auth_method":"api_key"}')
        with patch("aiyara.cli.setup.urllib.request.urlopen", return_value=resp):
            result = _whoami("https://aiyara-csim.fly.dev", "ak_test1234567")
        assert result == "p-abc"

    def test_whoami_soft_fails_on_connection_error(self):
        """urlopen raising URLError must produce None, not bubble up."""
        with patch(
            "aiyara.cli.setup.urllib.request.urlopen",
            side_effect=urllib.error.URLError("unreachable"),
        ):
            result = _whoami("https://aiyara-csim.fly.dev", "ak_test1234567")
        assert result is None

    def test_whoami_soft_fails_on_null_project_id(self):
        """JWT callers get back project_id=null — treat same as missing for
        SDK install purposes (the SDK needs a usable id to poll)."""
        resp = _make_resp(b'{"project_id":null,"tenant_id":"t1","auth_method":"jwt"}')
        with patch("aiyara.cli.setup.urllib.request.urlopen", return_value=resp):
            result = _whoami("https://aiyara-csim.fly.dev", "ak_test1234567")
        assert result is None


class TestWaitForTrace:
    def test_wait_for_trace_hits_recent_traces_url(self):
        """_wait_for_trace must GET /api/v1/projects/{pid}/traces/recent."""
        captured: dict[str, str] = {}

        def fake_urlopen(req, timeout=5):
            captured["url"] = req.full_url
            # Match the Plan 04 Task 1 canonical schema shape: trace_id,
            # ingested_at ISO string, num_steps (NOT the legacy received_at /
            # event_count placeholders).
            return _make_resp(
                b'[{"trace_id":"t1","ingested_at":"2026-04-23T12:00:00.000","num_steps":3}]'
            )

        output = io.StringIO()

        def _print(*a, **kw):
            print(*a, file=output, **kw)

        with patch(
            "aiyara.cli.setup.urllib.request.urlopen", side_effect=fake_urlopen
        ):
            _wait_for_trace(
                "https://aiyara-csim.fly.dev",
                "ak_test1234567",
                "p-abc",
                _print,
                timeout=5.0,
                poll_interval=0.01,
            )

        assert (
            captured["url"]
            == "https://aiyara-csim.fly.dev/api/v1/projects/p-abc/traces/recent?limit=1"
        )
        assert "First trace received" in output.getvalue()

    def test_wait_for_trace_handles_empty_then_non_empty(self):
        """Two empty polls, then a hit — must keep polling and succeed."""
        calls = {"n": 0}

        def fake_urlopen(req, timeout=5):
            calls["n"] += 1
            if calls["n"] < 3:
                return _make_resp(b"[]")
            return _make_resp(
                b'[{"trace_id":"t1","ingested_at":"2026-04-23T12:00:00.000","num_steps":3}]'
            )

        output = io.StringIO()

        def _print(*a, **kw):
            print(*a, file=output, **kw)

        with patch(
            "aiyara.cli.setup.urllib.request.urlopen", side_effect=fake_urlopen
        ):
            _wait_for_trace(
                "https://aiyara-csim.fly.dev",
                "ak_test1234567",
                "p-abc",
                _print,
                timeout=5.0,
                poll_interval=0.01,
            )

        assert calls["n"] >= 3
        assert "First trace received" in output.getvalue()

    def test_wait_for_trace_bails_on_401(self):
        """401 must break immediately with an auth-error message."""
        err = urllib.error.HTTPError(
            url="https://aiyara-csim.fly.dev/api/v1/projects/p-abc/traces/recent",
            code=401,
            msg="Unauthorized",
            hdrs=None,
            fp=None,
        )

        output = io.StringIO()

        def _print(*a, **kw):
            print(*a, file=output, **kw)

        with patch(
            "aiyara.cli.setup.urllib.request.urlopen", side_effect=err
        ):
            _wait_for_trace(
                "https://aiyara-csim.fly.dev",
                "ak_bad_key",
                "p-abc",
                _print,
                timeout=5.0,
                poll_interval=0.01,
            )

        text = output.getvalue()
        assert "[error]" in text
        assert "Auth" in text or "auth" in text

    def test_wait_for_trace_handles_transient_connection_error(self):
        """URLError mid-poll must NOT bail; must keep trying."""
        calls = {"n": 0}

        def fake_urlopen(req, timeout=5):
            calls["n"] += 1
            if calls["n"] == 1:
                raise urllib.error.URLError("transient")
            return _make_resp(
                b'[{"trace_id":"t1","ingested_at":"2026-04-23T12:00:00.000","num_steps":3}]'
            )

        output = io.StringIO()

        def _print(*a, **kw):
            print(*a, file=output, **kw)

        with patch(
            "aiyara.cli.setup.urllib.request.urlopen", side_effect=fake_urlopen
        ):
            _wait_for_trace(
                "https://aiyara-csim.fly.dev",
                "ak_test1234567",
                "p-abc",
                _print,
                timeout=5.0,
                poll_interval=0.01,
            )

        assert calls["n"] >= 2
        assert "First trace received" in output.getvalue()


class TestSetupCommandWhoamiSoftFail:
    def test_setup_skips_probe_when_whoami_soft_fails(self, tmp_path: Path):
        """When _whoami returns None, setup_command prints 'Skipped first-trace
        probe' and exits 0 (not 1) — ``.env`` is already written."""
        import argparse

        args = argparse.Namespace(
            endpoint="https://aiyara-csim.fly.dev",
            local=False,
            env_file=str(tmp_path / ".env"),
        )
        output = io.StringIO()

        with patch(
            "aiyara.cli.setup.check_connection",
            return_value=(True, "Connected successfully"),
        ):
            with patch("aiyara.cli.setup._whoami", return_value=None):
                with patch(
                    "aiyara.cli.setup._wait_for_trace"
                ) as mock_wait:
                    result = setup_command(
                        args,
                        input_fn=lambda prompt: "my-agent",
                        password_fn=lambda prompt: "ak_test1234567",
                        output=output,
                    )

        assert result == 0
        assert "Skipped first-trace probe" in output.getvalue()
        mock_wait.assert_not_called()


# ---------------------------------------------------------------------------
# Non-interactive setup (Plan 77.1-03)
# ---------------------------------------------------------------------------


class TestNonInteractiveSetup:
    """`aiyara setup --non-interactive` — CI/piped-stdin safe path.

    Every test clears AIYARA_* env vars up-front (via monkeypatch.delenv) so
    a developer's actual shell env can't shadow the assertion under test.
    """

    def test_non_interactive_requires_project(
        self, tmp_path: Path, monkeypatch, capsys
    ):
        monkeypatch.delenv("AIYARA_PROJECT", raising=False)
        monkeypatch.delenv("AIYARA_API_KEY", raising=False)
        args = _parse_args(
            [
                "setup",
                "--non-interactive",
                "--api-key",
                "ak_" + "a" * 64,
                "--env-file",
                str(tmp_path / ".env"),
            ]
        )
        assert setup_command(args) == 1
        captured = capsys.readouterr()
        assert "Project name is required" in captured.out

    def test_non_interactive_requires_api_key(
        self, tmp_path: Path, monkeypatch, capsys
    ):
        monkeypatch.delenv("AIYARA_PROJECT", raising=False)
        monkeypatch.delenv("AIYARA_API_KEY", raising=False)
        args = _parse_args(
            [
                "setup",
                "--non-interactive",
                "--project",
                "test-proj",
                "--env-file",
                str(tmp_path / ".env"),
            ]
        )
        assert setup_command(args) == 1
        captured = capsys.readouterr()
        assert "API key is required" in captured.out

    def test_non_interactive_flag_wins_over_env(
        self, tmp_path: Path, monkeypatch
    ):
        """CLI flags override AIYARA_* env when both are supplied.

        A CI job might have AIYARA_API_KEY set at the workflow level AND
        pass --api-key for a per-job override; the flag MUST win.
        """
        monkeypatch.setenv("AIYARA_API_KEY", "ak_env_value_" + "a" * 50)
        monkeypatch.setenv("AIYARA_SETUP_SKIP_WAIT", "1")
        monkeypatch.setattr(
            "aiyara.cli.setup.check_connection", lambda *a, **k: (True, "ok")
        )
        env_path = tmp_path / ".env"
        args = _parse_args(
            [
                "setup",
                "--non-interactive",
                "--project",
                "t-proj",
                "--api-key",
                "ak_flag_value_" + "b" * 50,
                "--endpoint",
                "https://example.com",
                "--env-file",
                str(env_path),
            ]
        )
        assert setup_command(args) == 0
        contents = env_path.read_text()
        assert "ak_flag_value_" in contents
        assert "ak_env_value_" not in contents

    def test_non_interactive_env_fallback(self, tmp_path: Path, monkeypatch):
        """Env-only path: AIYARA_PROJECT + AIYARA_API_KEY, no CLI flags."""
        monkeypatch.setenv("AIYARA_PROJECT", "env-proj")
        monkeypatch.setenv("AIYARA_API_KEY", "ak_" + "c" * 64)
        monkeypatch.setenv("AIYARA_SETUP_SKIP_WAIT", "1")
        monkeypatch.setattr(
            "aiyara.cli.setup.check_connection", lambda *a, **k: (True, "ok")
        )
        env_path = tmp_path / ".env"
        args = _parse_args(
            [
                "setup",
                "--non-interactive",
                "--endpoint",
                "https://example.com",
                "--env-file",
                str(env_path),
            ]
        )
        assert setup_command(args) == 0
        assert "AIYARA_PROJECT=env-proj" in env_path.read_text()

    def test_non_interactive_does_not_invoke_getpass(
        self, tmp_path: Path, monkeypatch
    ):
        """Regression guard: --non-interactive MUST NOT call getpass.getpass.

        This is the actual Plan 08 E2E blocker — piped stdin + getpass raises
        EOFError. If a refactor ever reintroduces a getpass call on the
        non-interactive branch, this test fails.
        """
        import getpass

        called: list[int] = []
        monkeypatch.setattr(
            getpass, "getpass", lambda *a, **k: called.append(1) or ""
        )
        monkeypatch.setenv("AIYARA_PROJECT", "p-proj")
        monkeypatch.setenv("AIYARA_API_KEY", "ak_" + "d" * 64)
        monkeypatch.setenv("AIYARA_SETUP_SKIP_WAIT", "1")
        monkeypatch.setattr(
            "aiyara.cli.setup.check_connection", lambda *a, **k: (True, "ok")
        )
        args = _parse_args(
            [
                "setup",
                "--non-interactive",
                "--endpoint",
                "https://example.com",
                "--env-file",
                str(tmp_path / ".env"),
            ]
        )
        setup_command(args)
        assert called == []

    def test_non_interactive_skips_wait_for_trace_when_env_set(
        self, tmp_path: Path, monkeypatch
    ):
        """AIYARA_SETUP_SKIP_WAIT=1 short-circuits the first-trace probe."""
        monkeypatch.setenv("AIYARA_PROJECT", "p-proj")
        monkeypatch.setenv("AIYARA_API_KEY", "ak_" + "e" * 64)
        monkeypatch.setenv("AIYARA_SETUP_SKIP_WAIT", "1")
        monkeypatch.setattr(
            "aiyara.cli.setup.check_connection", lambda *a, **k: (True, "ok")
        )
        wait_called: list[int] = []
        monkeypatch.setattr(
            "aiyara.cli.setup._wait_for_trace",
            lambda *a, **k: wait_called.append(1),
        )
        args = _parse_args(
            [
                "setup",
                "--non-interactive",
                "--endpoint",
                "https://example.com",
                "--env-file",
                str(tmp_path / ".env"),
            ]
        )
        setup_command(args)
        assert wait_called == []
