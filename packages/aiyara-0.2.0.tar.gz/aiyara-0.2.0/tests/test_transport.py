"""Tests for AiyaraTransport — HTTP transport with batching, retry, and offline queuing."""

import json
import threading
import time
from http.server import HTTPServer, BaseHTTPRequestHandler
from unittest.mock import patch

import pytest

from aiyara.transport import DEFAULT_ENDPOINT, AiyaraTransport
from aiyara.buffer import TraceBuffer


def _find_free_port():
    """Find a free port for the test server."""
    import socket
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


class _TestHandler(BaseHTTPRequestHandler):
    """Configurable test HTTP handler."""

    def do_POST(self):
        content_length = int(self.headers.get("Content-Length", 0))
        body = self.rfile.read(content_length)

        # Store received data on the server
        self.server.received_requests.append({
            "path": self.path,
            "headers": dict(self.headers),
            "body": json.loads(body) if body else None,
        })

        status = self.server.response_status
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.end_headers()
        self.wfile.write(json.dumps({"status": "ok"}).encode())

    def log_message(self, format, *args):
        pass  # Suppress logging in tests


def _start_test_server(port, status=200):
    """Start a test HTTP server."""
    server = HTTPServer(("127.0.0.1", port), _TestHandler)
    server.received_requests = []
    server.response_status = status
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    return server


class TestTransportSuccessfulSend:
    """Successful trace delivery."""

    def test_send_and_flush_delivers_trace(self):
        port = _find_free_port()
        server = _start_test_server(port)
        try:
            transport = AiyaraTransport(
                endpoint=f"http://127.0.0.1:{port}",
                api_key="test-key",
                batch_size=10,
                flush_interval_seconds=60,  # long interval so we control flush
            )
            transport.send({"trace_id": "t1", "data": "hello"})
            sent = transport.flush()
            assert sent == 1
            assert len(server.received_requests) == 1
            req = server.received_requests[0]
            assert req["path"] == "/v1/traces"
            assert "Bearer test-key" in req["headers"].get("Authorization", "")
        finally:
            transport.shutdown(timeout=1)
            server.shutdown()

    def test_send_multiple_and_flush(self):
        port = _find_free_port()
        server = _start_test_server(port)
        try:
            transport = AiyaraTransport(
                endpoint=f"http://127.0.0.1:{port}",
                api_key="test-key",
                batch_size=50,
                flush_interval_seconds=60,
            )
            for i in range(5):
                transport.send({"trace_id": f"t{i}"})
            sent = transport.flush()
            assert sent == 5
            assert transport.pending_count == 0
        finally:
            transport.shutdown(timeout=1)
            server.shutdown()

    def test_stats_tracks_sent_count(self):
        port = _find_free_port()
        server = _start_test_server(port)
        try:
            transport = AiyaraTransport(
                endpoint=f"http://127.0.0.1:{port}",
                api_key="test-key",
                flush_interval_seconds=60,
            )
            transport.send({"trace_id": "t1"})
            transport.send({"trace_id": "t2"})
            transport.flush()
            stats = transport.stats
            assert stats["sent"] == 2
        finally:
            transport.shutdown(timeout=1)
            server.shutdown()


class TestTransportBatching:
    """Batch send behavior."""

    def test_batch_sends_multiple_events_in_one_request(self):
        port = _find_free_port()
        server = _start_test_server(port)
        try:
            transport = AiyaraTransport(
                endpoint=f"http://127.0.0.1:{port}",
                api_key="test-key",
                batch_size=5,
                flush_interval_seconds=60,
                project_id="p1",
                agent_id="a1",
            )
            for i in range(5):
                transport.send({"trace_id": f"t{i}"})
            transport.flush()
            # All 5 events should be sent in a single batch request, wrapped
            # in the TraceBatchRequest envelope.
            assert len(server.received_requests) == 1
            body = server.received_requests[0]["body"]
            assert isinstance(body, dict)
            assert len(body["traces"]) == 5
        finally:
            transport.shutdown(timeout=1)
            server.shutdown()

    def test_multiple_batches_for_large_queue(self):
        port = _find_free_port()
        server = _start_test_server(port)
        try:
            transport = AiyaraTransport(
                endpoint=f"http://127.0.0.1:{port}",
                api_key="test-key",
                batch_size=3,
                flush_interval_seconds=60,
            )
            for i in range(7):
                transport.send({"trace_id": f"t{i}"})
            transport.flush()
            # 7 events with batch_size=3 -> 3 requests (3+3+1)
            assert len(server.received_requests) == 3
        finally:
            transport.shutdown(timeout=1)
            server.shutdown()


class TestTransportRetry:
    """Retry with exponential backoff on server errors."""

    @patch("time.sleep")
    def test_retries_on_500_then_succeeds(self, mock_sleep):
        port = _find_free_port()
        server = _start_test_server(port, status=500)
        try:
            transport = AiyaraTransport(
                endpoint=f"http://127.0.0.1:{port}",
                api_key="test-key",
                batch_size=10,
                flush_interval_seconds=60,
                max_retries=3,
            )
            transport.send({"trace_id": "t1"})
            # After 2 failures, switch to 200
            def switch_after_2(*args, **kwargs):
                if len(server.received_requests) >= 2:
                    server.response_status = 200
            mock_sleep.side_effect = switch_after_2

            sent = transport.flush()
            assert sent == 1
            # Should have retried (at least 2 requests)
            assert len(server.received_requests) >= 2
        finally:
            transport.shutdown(timeout=1)
            server.shutdown()

    @patch("time.sleep")
    def test_buffers_after_all_retries_exhausted(self, mock_sleep):
        port = _find_free_port()
        server = _start_test_server(port, status=500)
        try:
            transport = AiyaraTransport(
                endpoint=f"http://127.0.0.1:{port}",
                api_key="test-key",
                batch_size=10,
                flush_interval_seconds=60,
                max_retries=2,
            )
            transport.send({"trace_id": "t1"})
            sent = transport.flush()
            assert sent == 0
            stats = transport.stats
            assert stats["failed"] >= 1
        finally:
            transport.shutdown(timeout=1)
            server.shutdown()


class TestTransportNoRetryOn4xx:
    """4xx errors are permanent failures — no retry."""

    @patch("time.sleep")
    def test_no_retry_on_400(self, mock_sleep):
        port = _find_free_port()
        server = _start_test_server(port, status=400)
        try:
            transport = AiyaraTransport(
                endpoint=f"http://127.0.0.1:{port}",
                api_key="test-key",
                batch_size=10,
                flush_interval_seconds=60,
                max_retries=3,
            )
            transport.send({"trace_id": "t1"})
            sent = transport.flush()
            assert sent == 0
            # Should only be 1 request — no retries on 4xx
            assert len(server.received_requests) == 1
            assert transport.stats["failed"] == 1
        finally:
            transport.shutdown(timeout=1)
            server.shutdown()


class TestTransportConnectionFailure:
    """Events buffered when endpoint unreachable."""

    @patch("time.sleep")
    def test_connection_refused_buffers_event(self, mock_sleep):
        # Use a port with no server
        port = _find_free_port()
        transport = AiyaraTransport(
            endpoint=f"http://127.0.0.1:{port}",
            api_key="test-key",
            batch_size=10,
            flush_interval_seconds=60,
            max_retries=1,
        )
        transport.send({"trace_id": "t1"})
        sent = transport.flush()
        assert sent == 0
        # Event should be back in buffer (requeued after failure)
        assert transport.pending_count == 1
        transport.shutdown(timeout=1)

    @patch("time.sleep")
    def test_recovery_flushes_buffered_events(self, mock_sleep):
        """When server comes back, previously buffered events are delivered."""
        port = _find_free_port()
        transport = AiyaraTransport(
            endpoint=f"http://127.0.0.1:{port}",
            api_key="test-key",
            batch_size=10,
            flush_interval_seconds=60,
            max_retries=1,
        )
        # Send while offline
        transport.send({"trace_id": "t1"})
        sent = transport.flush()
        assert sent == 0
        assert transport.pending_count == 1

        # Now start the server
        server = _start_test_server(port)
        try:
            sent = transport.flush()
            assert sent == 1
            assert transport.pending_count == 0
        finally:
            transport.shutdown(timeout=1)
            server.shutdown()


class TestTransportShutdown:
    """Graceful shutdown flushes remaining events."""

    def test_shutdown_flushes_pending(self):
        port = _find_free_port()
        server = _start_test_server(port)
        try:
            transport = AiyaraTransport(
                endpoint=f"http://127.0.0.1:{port}",
                api_key="test-key",
                batch_size=50,
                flush_interval_seconds=60,
            )
            transport.send({"trace_id": "t1"})
            transport.send({"trace_id": "t2"})
            transport.shutdown(timeout=2)
            assert len(server.received_requests) >= 1
        finally:
            server.shutdown()


class TestTransportOversizeTrace:
    """Oversize traces are dropped with a warning."""

    def test_oversize_trace_dropped(self):
        port = _find_free_port()
        transport = AiyaraTransport(
            endpoint=f"http://127.0.0.1:{port}",
            api_key="test-key",
            flush_interval_seconds=60,
            max_trace_bytes=100,  # 100 bytes max for test
        )
        # Create a trace larger than 100 bytes
        big_trace = {"trace_id": "t1", "data": "x" * 200}
        transport.send(big_trace)
        assert transport.pending_count == 0
        assert transport.stats["dropped_oversize"] == 1
        transport.shutdown(timeout=1)

    def test_normal_trace_not_dropped(self):
        port = _find_free_port()
        transport = AiyaraTransport(
            endpoint=f"http://127.0.0.1:{port}",
            api_key="test-key",
            flush_interval_seconds=60,
            max_trace_bytes=5 * 1024 * 1024,
        )
        transport.send({"trace_id": "t1"})
        assert transport.pending_count == 1
        assert transport.stats["dropped_oversize"] == 0
        transport.shutdown(timeout=1)


class TestTransportRateLimit:
    """Rate limiting drops excess traces."""

    def test_rate_limit_drops_excess(self):
        port = _find_free_port()
        transport = AiyaraTransport(
            endpoint=f"http://127.0.0.1:{port}",
            api_key="test-key",
            flush_interval_seconds=60,
            max_traces_per_minute=5,
        )
        for i in range(10):
            transport.send({"trace_id": f"t{i}"})
        assert transport.stats["rate_limited"] == 5
        assert transport.pending_count == 5
        transport.shutdown(timeout=1)


class TestTransportBatchSplitting:
    """Batch payload cap splits large batches."""

    def test_large_batch_split_into_smaller_requests(self):
        port = _find_free_port()
        server = _start_test_server(port)
        try:
            transport = AiyaraTransport(
                endpoint=f"http://127.0.0.1:{port}",
                api_key="test-key",
                batch_size=100,
                flush_interval_seconds=60,
                max_batch_bytes=500,  # very small cap for testing
                project_id="p1",
                agent_id="a1",
            )
            # Each trace is ~40 bytes JSON, 100 bytes with overhead
            for i in range(10):
                transport.send({"trace_id": f"t{i}", "data": "a" * 50})
            transport.flush()
            # Should have split into multiple requests
            assert len(server.received_requests) > 1
            # All events should have been delivered — sum across envelopes
            total_sent = sum(
                len(req["body"]["traces"]) for req in server.received_requests
            )
            assert total_sent == 10
        finally:
            transport.shutdown(timeout=1)
            server.shutdown()


class TestTransportDefaultEndpoint:
    """Default endpoint points at the deployed Fly app."""

    def test_default_endpoint_constant(self):
        """DEFAULT_ENDPOINT exposes the deployed Fly host."""
        assert DEFAULT_ENDPOINT == "https://aiyara-csim.fly.dev"

    def test_default_endpoint_resolves_to_fly(self):
        """AiyaraTransport() with no args uses the Fly host as its endpoint."""
        transport = AiyaraTransport()
        try:
            assert transport._endpoint == "https://aiyara-csim.fly.dev"
        finally:
            transport.shutdown(timeout=1)


class TestTransportWireShape:
    """Wire shape — _send_batch wraps `list[trace]` as TraceBatchRequest.

    Server expects `{project_id, agent_id, traces: [...]}`. These tests pin
    that contract at the SDK side; closing E2E Bug 7.
    """

    def test_send_batch_wraps_payload(self):
        """Outgoing body is an envelope, not a bare JSON array."""
        port = _find_free_port()
        server = _start_test_server(port)
        try:
            transport = AiyaraTransport(
                endpoint=f"http://127.0.0.1:{port}",
                api_key="test-key",
                batch_size=10,
                flush_interval_seconds=60,
                project_id="p1",
                agent_id="a1",
            )
            transport.send({"trace_id": "t1", "data": "hello"})
            transport.flush()
            assert len(server.received_requests) == 1
            body = server.received_requests[0]["body"]
            # Must be an object, not a bare array
            assert isinstance(body, dict), f"expected envelope, got {type(body).__name__}"
            assert body["project_id"] == "p1"
            assert body["agent_id"] == "a1"
            assert isinstance(body["traces"], list)
            assert len(body["traces"]) == 1
            assert body["traces"][0]["trace_id"] == "t1"
        finally:
            transport.shutdown(timeout=1)
            server.shutdown()

    def test_send_batch_without_identity_sends_empty_strings_and_logs_warning(self, caplog):
        """Missing identity — still wrap (empty strings), emit warning."""
        import logging
        port = _find_free_port()
        server = _start_test_server(port)
        try:
            transport = AiyaraTransport(
                endpoint=f"http://127.0.0.1:{port}",
                api_key="test-key",
                batch_size=10,
                flush_interval_seconds=60,
                # project_id / agent_id NOT set
            )
            transport.send({"trace_id": "t1"})
            with caplog.at_level(logging.WARNING, logger="aiyara.sdk.transport"):
                transport.flush()

            # Wire shape: still an envelope, with empty identity
            assert len(server.received_requests) == 1
            body = server.received_requests[0]["body"]
            assert isinstance(body, dict)
            assert body["project_id"] == ""
            assert body["agent_id"] == ""
            assert len(body["traces"]) == 1

            # Warning emitted
            assert any(
                "no project_id/agent_id" in rec.message
                for rec in caplog.records
            ), f"expected identity-missing warning; got: {[r.message for r in caplog.records]}"
        finally:
            transport.shutdown(timeout=1)
            server.shutdown()

    def test_set_identity_updates_mid_flight(self):
        """set_identity() updates the envelope for subsequent batches."""
        port = _find_free_port()
        server = _start_test_server(port)
        try:
            transport = AiyaraTransport(
                endpoint=f"http://127.0.0.1:{port}",
                api_key="test-key",
                batch_size=10,
                flush_interval_seconds=60,
                project_id="p1",
                agent_id="a1",
            )
            transport.send({"trace_id": "t1"})
            transport.flush()
            # Now swap identity
            transport.set_identity("p2", "a2")
            transport.send({"trace_id": "t2"})
            transport.flush()

            assert len(server.received_requests) == 2
            first = server.received_requests[0]["body"]
            second = server.received_requests[1]["body"]
            assert first["project_id"] == "p1" and first["agent_id"] == "a1"
            assert second["project_id"] == "p2" and second["agent_id"] == "a2"
            assert second["traces"][0]["trace_id"] == "t2"
        finally:
            transport.shutdown(timeout=1)
            server.shutdown()

    def test_existing_batch_split_still_works_on_wrapped_payload(self):
        """Each sub-batch (after split) carries its own envelope."""
        port = _find_free_port()
        server = _start_test_server(port)
        try:
            transport = AiyaraTransport(
                endpoint=f"http://127.0.0.1:{port}",
                api_key="test-key",
                batch_size=150,
                flush_interval_seconds=60,
                max_batch_bytes=800,  # force splits
                project_id="p1",
                agent_id="a1",
            )
            # 20 traces, each ~80 bytes serialized → exceeds 800 several times
            for i in range(20):
                transport.send({"trace_id": f"t{i}", "data": "x" * 40})
            transport.flush()
            # Multiple requests — each must be an envelope with matching identity
            assert len(server.received_requests) >= 2
            total_traces = 0
            for req in server.received_requests:
                body = req["body"]
                assert isinstance(body, dict), "each sub-batch must be wrapped"
                assert body["project_id"] == "p1"
                assert body["agent_id"] == "a1"
                assert isinstance(body["traces"], list)
                total_traces += len(body["traces"])
            assert total_traces == 20
        finally:
            transport.shutdown(timeout=1)
            server.shutdown()


class TestTransportHeaders:
    """HTTP headers are set correctly."""

    def test_authorization_header(self):
        port = _find_free_port()
        server = _start_test_server(port)
        try:
            transport = AiyaraTransport(
                endpoint=f"http://127.0.0.1:{port}",
                api_key="my-secret-key",
                flush_interval_seconds=60,
            )
            transport.send({"trace_id": "t1"})
            transport.flush()
            assert server.received_requests[0]["headers"]["Authorization"] == "Bearer my-secret-key"
        finally:
            transport.shutdown(timeout=1)
            server.shutdown()

    def test_content_type_json(self):
        port = _find_free_port()
        server = _start_test_server(port)
        try:
            transport = AiyaraTransport(
                endpoint=f"http://127.0.0.1:{port}",
                api_key="test-key",
                flush_interval_seconds=60,
            )
            transport.send({"trace_id": "t1"})
            transport.flush()
            assert server.received_requests[0]["headers"]["Content-Type"] == "application/json"
        finally:
            transport.shutdown(timeout=1)
            server.shutdown()

    def test_user_agent_header(self):
        port = _find_free_port()
        server = _start_test_server(port)
        try:
            transport = AiyaraTransport(
                endpoint=f"http://127.0.0.1:{port}",
                api_key="test-key",
                flush_interval_seconds=60,
            )
            transport.send({"trace_id": "t1"})
            transport.flush()
            ua = server.received_requests[0]["headers"].get("User-Agent", "")
            assert ua.startswith("aiyara-sdk-python/")
        finally:
            transport.shutdown(timeout=1)
            server.shutdown()
