"""Tests for SDK trace event data model."""

import json
from datetime import datetime, timezone

import pytest
from pydantic import ValidationError

from aiyara.types import (
    AiyaraTrace,
    ContextSnapshot,
    ToolExecution,
    TraceMessage,
)


def _make_trace(**overrides) -> AiyaraTrace:
    """Factory for a minimal valid trace."""
    defaults = dict(
        trace_id="abc-123",
        started_at=datetime(2026, 4, 12, 10, 0, 0, tzinfo=timezone.utc),
    )
    defaults.update(overrides)
    return AiyaraTrace(**defaults)


class TestTraceMessage:
    def test_basic_creation(self):
        msg = TraceMessage(index=0, role="user", content="hello")
        assert msg.role == "user"
        assert msg.content == "hello"
        assert msg.tool_calls is None

    def test_with_tool_calls(self):
        msg = TraceMessage(
            index=1,
            role="assistant",
            content="",
            tool_calls=[{"name": "search", "arguments": {"q": "test"}}],
        )
        assert len(msg.tool_calls) == 1


class TestToolExecution:
    def test_basic_creation(self):
        tool = ToolExecution(
            index=0,
            name="get_order",
            arguments={"order_id": "123"},
            result='{"status": "shipped"}',
            duration_ms=42.5,
            timestamp=datetime(2026, 4, 12, 10, 0, 1, tzinfo=timezone.utc),
        )
        assert tool.name == "get_order"
        assert tool.error is False
        assert tool.error_message is None

    def test_error_tool_execution(self):
        tool = ToolExecution(
            index=1,
            name="update_order",
            arguments={"order_id": "123"},
            result="",
            error=True,
            error_message="Order not found",
            duration_ms=15.0,
            timestamp=datetime(2026, 4, 12, 10, 0, 2, tzinfo=timezone.utc),
        )
        assert tool.error is True
        assert tool.error_message == "Order not found"


class TestContextSnapshot:
    def test_basic_creation(self):
        snap = ContextSnapshot(
            step=1,
            total_tokens=4000,
            system_tokens=1000,
            conversation_tokens=2500,
            available_tokens=4000,
            utilization=0.5,
        )
        assert snap.utilization == 0.5


class TestAiyaraTrace:
    def test_minimal_trace(self):
        trace = _make_trace()
        assert trace.trace_id == "abc-123"
        assert trace.messages == []
        assert trace.tool_calls == []
        assert trace.tags == {}

    def test_required_fields(self):
        """trace_id and started_at are required."""
        with pytest.raises(ValidationError):
            AiyaraTrace()  # type: ignore[call-arg]

    def test_full_trace(self):
        trace = _make_trace(
            session_id="sess-001",
            ended_at=datetime(2026, 4, 12, 10, 5, 0, tzinfo=timezone.utc),
            messages=[
                TraceMessage(index=0, role="user", content="hello"),
                TraceMessage(index=1, role="assistant", content="hi"),
            ],
            tool_calls=[
                ToolExecution(
                    index=0,
                    name="search",
                    arguments={"q": "test"},
                    result="found",
                    duration_ms=10.0,
                    timestamp=datetime(2026, 4, 12, 10, 0, 1, tzinfo=timezone.utc),
                )
            ],
            context_snapshots=[
                ContextSnapshot(
                    step=1,
                    total_tokens=4000,
                    system_tokens=1000,
                    conversation_tokens=2500,
                    available_tokens=4000,
                    utilization=0.5,
                )
            ],
            model="gpt-4o",
            total_tokens=4000,
            num_steps=2,
            duration_seconds=5.0,
            tags={"env": "test"},
        )
        assert len(trace.messages) == 2
        assert len(trace.tool_calls) == 1
        assert trace.model == "gpt-4o"

    def test_serialization_round_trip(self):
        """model_dump_json -> parse -> equal."""
        trace = _make_trace(
            session_id="sess-001",
            messages=[TraceMessage(index=0, role="user", content="hello")],
            tags={"env": "production"},
        )
        json_str = trace.model_dump_json()
        parsed = json.loads(json_str)
        assert parsed["trace_id"] == "abc-123"
        assert parsed["session_id"] == "sess-001"
        assert parsed["tags"]["env"] == "production"
        assert len(parsed["messages"]) == 1

        # Round-trip back to model
        restored = AiyaraTrace.model_validate_json(json_str)
        assert restored.trace_id == trace.trace_id
        assert restored.tags == trace.tags

    def test_model_dump_clean_json(self):
        """model_dump() produces dict suitable for JSON serialization."""
        trace = _make_trace()
        dumped = trace.model_dump()
        # Should be a plain dict, JSON-serializable
        json_str = json.dumps(dumped, default=str)
        assert "abc-123" in json_str

    def test_optional_fields_default_none(self):
        trace = _make_trace()
        assert trace.session_id is None
        assert trace.ended_at is None
        assert trace.model is None
        assert trace.system_prompt is None
        assert trace.system_prompt_hash is None
        assert trace.outcome is None
        assert trace.user_id is None
        assert trace.deploy_version is None


class TestAiyaraTracePhase78_1Context:
    """Phase 78.1 D11: initial_context / entry_agent / domain optional fields.

    Backward compat invariant (R7): older SDKs never shipped these three
    fields. Payloads from those SDKs must still parse — all three default
    to ``None``.
    """

    def test_context_fields_default_none(self):
        """Minimal trace (no context fields) — all three default to None."""
        trace = _make_trace()
        assert trace.initial_context is None
        assert trace.entry_agent is None
        assert trace.domain is None

    def test_old_fixture_without_context_fields_parses(self):
        """Older SDKs (pre-Phase-78.1) produce payloads with no context keys.

        Simulates the wire-level payload shape that would come from an older
        SDK by constructing a dict that has zero mention of the three new
        fields, then round-tripping through model_validate.
        """
        legacy_payload = {
            "trace_id": "legacy-trace",
            "started_at": "2026-01-01T00:00:00Z",
            "messages": [],
            "tool_calls": [],
        }
        trace = AiyaraTrace.model_validate(legacy_payload)
        assert trace.initial_context is None
        assert trace.entry_agent is None
        assert trace.domain is None

    def test_context_fields_round_trip(self):
        """All three fields populated — round-trip preserves values."""
        trace = _make_trace(
            initial_context={"patient_id": "p123"},
            entry_agent="triage",
            domain="medical",
        )
        assert trace.initial_context == {"patient_id": "p123"}
        assert trace.entry_agent == "triage"
        assert trace.domain == "medical"

        dumped = trace.model_dump()
        assert dumped["initial_context"] == {"patient_id": "p123"}
        assert dumped["entry_agent"] == "triage"
        assert dumped["domain"] == "medical"

        # Reconstruct and ensure fidelity.
        restored = AiyaraTrace(**dumped)
        assert restored.initial_context == {"patient_id": "p123"}
        assert restored.entry_agent == "triage"
        assert restored.domain == "medical"

    def test_context_fields_json_round_trip(self):
        """Full JSON round-trip preserves the three context fields."""
        trace = _make_trace(
            initial_context={"patient_id": "p123", "nested": {"k": "v"}},
            entry_agent="triage",
            domain="medical",
        )
        json_str = trace.model_dump_json()
        restored = AiyaraTrace.model_validate_json(json_str)
        assert restored.initial_context == {"patient_id": "p123", "nested": {"k": "v"}}
        assert restored.entry_agent == "triage"
        assert restored.domain == "medical"
