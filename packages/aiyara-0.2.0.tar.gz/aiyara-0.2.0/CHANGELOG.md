# Changelog

All notable changes to the Aiyara Python SDK.

## 0.2.0 — 2026-04-24

### Added

- AiyaraTrace supports optional `initial_context`, `entry_agent`, `domain` for
  Phase 78.1 constraint extraction context. Backward-compatible: all fields
  default to None; older server versions ignore them.
- `AIYARA_ENTRY_AGENT` / `AIYARA_DOMAIN` env-var fallbacks for `trace()` + `capture()`.
  Explicit kwargs win over env; no fallback for `initial_context` (request-scoped).

## 0.1.0 — earlier

- Initial release: trace capture, PII scrubbing, transport, CLI setup.
