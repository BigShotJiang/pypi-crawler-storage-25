"""Aiyara SDK client -- manages trace capture, PII scrubbing, and delivery.

The central client that ties together the trace model (types), PII scrubbing,
and HTTP transport. Provides three capture modes:

1. ``@client.trace`` decorator -- wraps a function, captures timing
2. ``with client.trace() as t:`` context manager -- manual event recording
3. ``client.capture(...)`` -- one-shot manual trace submission
"""

from __future__ import annotations

import atexit
import functools
import hashlib
import json
import logging
import os
import random
import time
import urllib.error
import urllib.request
import uuid
from contextlib import contextmanager
from datetime import datetime, timezone
from typing import Any, Callable

from aiyara.pii.scrubber import PIIScrubber
from aiyara.transport import DEFAULT_ENDPOINT, AiyaraTransport
from aiyara.types import AiyaraTrace, ContextSnapshot, ToolExecution, TraceMessage

logger = logging.getLogger("aiyara.sdk.client")


class TraceContext:
    """Active trace being recorded.

    Used inside a ``with client.trace() as t:`` block to record
    messages, tool calls, context snapshots, and outcome.
    """

    def __init__(
        self,
        trace_id: str | None = None,
        session_id: str | None = None,
        tags: dict[str, str] | None = None,
        initial_context: dict[str, Any] | None = None,
        entry_agent: str | None = None,
        domain: str | None = None,
    ) -> None:
        self._trace_id = trace_id or str(uuid.uuid4())
        self._session_id = session_id
        self._tags = tags or {}
        self._started_at = datetime.now(timezone.utc)
        self._messages: list[dict[str, Any]] = []
        self._tool_calls: list[dict[str, Any]] = []
        self._context_snapshots: list[dict[str, Any]] = []
        self._snapshot_index = 0
        self._outcome: dict[str, Any] | None = None
        self._model: str | None = None
        self._user_id: str | None = None
        self._deploy_version: str | None = None
        self._system_prompt: str | None = None
        self._msg_index = 0
        self._tool_index = 0
        # Phase 78.1 D11 — request-scoped context forwarded to AiyaraTrace.
        self._initial_context = initial_context
        self._entry_agent = entry_agent
        self._domain = domain

    def record_message(
        self,
        role: str,
        content: str,
        tool_calls: list[dict[str, Any]] | None = None,
    ) -> None:
        """Record a conversation message."""
        self._messages.append(
            {
                "index": self._msg_index,
                "role": role,
                "content": content,
                "tool_calls": tool_calls,
            }
        )
        self._msg_index += 1

    def record_tool_call(
        self,
        name: str,
        arguments: dict[str, Any],
        result: Any,
        error: bool = False,
        error_message: str | None = None,
        duration_ms: float = 0,
    ) -> None:
        """Record a tool invocation."""
        self._tool_calls.append(
            {
                "index": self._tool_index,
                "name": name,
                "arguments": arguments,
                "result": str(result) if not isinstance(result, str) else result,
                "error": error,
                "error_message": error_message,
                "duration_ms": duration_ms,
                "timestamp": datetime.now(timezone.utc),
            }
        )
        self._tool_index += 1

    def record_context_snapshot(
        self,
        total_tokens: int,
        system_tokens: int = 0,
        available_tokens: int = 0,
    ) -> None:
        """Record a context window snapshot."""
        utilization = total_tokens / (total_tokens + available_tokens) if (total_tokens + available_tokens) > 0 else 0.0
        self._context_snapshots.append({
            "step": self._snapshot_index,
            "total_tokens": total_tokens,
            "system_tokens": system_tokens,
            "conversation_tokens": total_tokens - system_tokens,
            "available_tokens": available_tokens,
            "utilization": round(utilization, 4),
        })
        self._snapshot_index += 1

    def set_outcome(self, success: bool, reason: str = "") -> None:
        """Set the trace outcome."""
        self._outcome = {"success": success, "reason": reason}

    def set_metadata(self, **kwargs: Any) -> None:
        """Set trace metadata (model, user_id, deploy_version, etc.)."""
        if "model" in kwargs:
            self._model = kwargs["model"]
        if "user_id" in kwargs:
            self._user_id = kwargs["user_id"]
        if "deploy_version" in kwargs:
            self._deploy_version = kwargs["deploy_version"]
        if "system_prompt" in kwargs:
            self._system_prompt = kwargs["system_prompt"]

    def _build_trace(self) -> AiyaraTrace:
        """Build an AiyaraTrace from recorded events."""
        ended_at = datetime.now(timezone.utc)
        messages = [TraceMessage(**m) for m in self._messages]
        tool_calls = [ToolExecution(**tc) for tc in self._tool_calls]
        snapshots = [ContextSnapshot(**s) for s in self._context_snapshots]
        duration = (ended_at - self._started_at).total_seconds()
        total_tokens = snapshots[-1].total_tokens if snapshots else 0

        return AiyaraTrace(
            trace_id=self._trace_id,
            session_id=self._session_id,
            started_at=self._started_at,
            ended_at=ended_at,
            messages=messages,
            tool_calls=tool_calls,
            context_snapshots=snapshots,
            total_tokens=total_tokens,
            model=self._model,
            system_prompt=self._system_prompt,
            outcome=self._outcome,
            user_id=self._user_id,
            deploy_version=self._deploy_version,
            tags=self._tags,
            num_steps=len(self._tool_calls),
            duration_seconds=duration,
            # Phase 78.1 D11.
            initial_context=self._initial_context,
            entry_agent=self._entry_agent,
            domain=self._domain,
        )


class AiyaraClient:
    """Aiyara SDK client -- manages trace capture, PII scrubbing, and delivery."""

    def __init__(
        self,
        api_key: str,
        endpoint: str = DEFAULT_ENDPOINT,
        auto_instrument: bool = False,
        capture_system_prompt: bool = True,
        capture_tool_results: bool = True,
        scrub_pii: bool = True,
        pii_field_paths: list[str] | None = None,
        before_send: Callable[[AiyaraTrace], AiyaraTrace] | None = None,
        sample_rate: float = 1.0,
        always_sample_failures: bool = True,
        batch_size: int = 50,
        flush_interval: float = 5.0,
        max_buffer_size: int = 1000,
        agent_id: str | None = None,
        prompt: str | None = None,
    ) -> None:
        """Construct an Aiyara SDK client.

        Identity resolution:

        * ``project_id`` — sourced from the server at init via a single
          ``GET /api/v1/whoami`` call. Soft-fail: if the server is
          unreachable, ``project_id`` stays ``None`` and outgoing batches
          POST with an empty string (server will reject, surfacing the
          misconfig in operator logs rather than silently dropping data).
        * ``agent_id`` — caller-labeled. Precedence: explicit ``agent_id=``
          kwarg > ``AIYARA_PROJECT`` env var > ``"default"``. The env
          fallback (kwarg omitted AND ``AIYARA_PROJECT`` set) emits a
          one-time WARNING because it's the "surprise" path — operators
          who forget the kwarg may accidentally mis-label traces when
          ``AIYARA_PROJECT`` leaks in from shell history / CI env.

        Note: ``AIYARA_PROJECT`` is the env var customers already set for
        the setup CLI; we reuse it for ``agent_id`` rather than introducing
        a second name — customers read the value as the "agent label this
        process produces traces for", which matches this use.
        """
        self._api_key = api_key
        self._endpoint = endpoint
        self._auto_instrument = auto_instrument
        self._capture_system_prompt = capture_system_prompt
        self._capture_tool_results = capture_tool_results
        self._sample_rate = sample_rate
        self._always_sample_failures = always_sample_failures

        # SHA256 of the agent's system prompt, computed once at init.
        # Attached to every outgoing trace as `system_prompt_hash` so the
        # ingest side can detect drift between deployed code and the
        # extracted policy. Empty string treated as no prompt.
        self._prompt_hash: str | None = (
            hashlib.sha256(prompt.encode("utf-8")).hexdigest() if prompt else None
        )

        # PII scrubber
        self._scrubber = PIIScrubber(
            field_paths=pii_field_paths,
            before_send=before_send,
            enabled=scrub_pii,
        )

        # Transport (strip trailing /api/v1/traces or legacy /v1/traces suffix --
        # transport appends /api/v1/traces itself).
        transport_endpoint = endpoint
        for suffix in ("/api/v1/traces", "/v1/traces"):
            if transport_endpoint.endswith(suffix):
                transport_endpoint = transport_endpoint[: -len(suffix)]
                break
        self._transport_endpoint = transport_endpoint
        self._transport = AiyaraTransport(
            endpoint=transport_endpoint,
            api_key=api_key,
            batch_size=batch_size,
            flush_interval_seconds=flush_interval,
            max_buffer_size=max_buffer_size,
        )

        # Resolve agent_id (kwarg > env > "default") with one-time warning
        # on the env-fallback path only.
        agent_id_from_env = os.environ.get("AIYARA_PROJECT")
        if agent_id is not None:
            resolved_agent_id = agent_id
            # Explicit kwarg — no warning.
        elif agent_id_from_env:
            resolved_agent_id = agent_id_from_env
            logger.warning(
                "agent_id was not explicitly set — falling back to "
                "AIYARA_PROJECT=%s for trace labeling. Pass "
                "agent_id=... to aiyara.init() to silence this warning "
                "and prevent accidental mis-labeling when AIYARA_PROJECT "
                "leaks in from shell history / CI env.",
                agent_id_from_env,
            )
        else:
            resolved_agent_id = "default"
            # Neither explicit nor env — no warning; "default" is the
            # documented fallback used in CI / local dev.

        # Resolve project_id from the server. Soft-fail to None.
        resolved_project_id = self._resolve_project_id()

        self._agent_id = resolved_agent_id
        self._project_id = resolved_project_id

        # Thread identity into the transport so _send_batch emits the
        # correct TraceBatchRequest wrapper. If project_id is None, we
        # deliberately skip wiring — transport's own missing-identity
        # warning fires on first send, reinforcing the signal.
        if resolved_project_id is not None:
            self._transport.set_identity(resolved_project_id, resolved_agent_id)

    def _resolve_project_id(self) -> str | None:
        """Resolve this client's project_id via ``GET /api/v1/whoami``.

        Soft-fails to ``None`` on any error (network, non-200, malformed
        body). Mirrors ``cli/setup.py:_whoami`` — we do not raise because
        an offline developer should still be able to import the SDK and
        run tests.
        """
        url = f"{self._transport_endpoint}/api/v1/whoami"
        try:
            req = urllib.request.Request(
                url,
                headers={"Authorization": f"Bearer {self._api_key}"},
                method="GET",
            )
            with urllib.request.urlopen(req, timeout=6.0) as resp:
                if resp.status != 200:
                    logger.warning(
                        "whoami returned HTTP %d; project_id unresolved. "
                        "Traces will be rejected by the server until "
                        "aiyara.init() succeeds.",
                        resp.status,
                    )
                    return None
                body = json.loads(resp.read())
        except (
            urllib.error.URLError,
            urllib.error.HTTPError,
            TimeoutError,
            OSError,
            ValueError,
            json.JSONDecodeError,
        ) as e:
            logger.warning(
                "whoami lookup failed (%s); project_id unresolved. "
                "Traces will be rejected by the server until "
                "aiyara.init() succeeds against a reachable endpoint.",
                e,
            )
            return None
        if not isinstance(body, dict):
            return None
        project_id = body.get("project_id")
        if not isinstance(project_id, str) or not project_id:
            return None
        return project_id

    def trace(
        self,
        fn: Callable | None = None,
        *,
        session_id: str | None = None,
        tags: dict[str, str] | None = None,
        initial_context: dict[str, Any] | None = None,
        entry_agent: str | None = None,
        domain: str | None = None,
    ) -> Any:
        """Use as decorator or context manager.

        As decorator (no args)::

            @client.trace
            def my_agent(msg): ...

        As decorator (with args)::

            @client.trace(session_id="user-123")
            def my_agent(msg): ...

        As context manager::

            with client.trace(session_id="user-123") as t:
                t.record_message(role="user", content=msg)

        Phase 78.1 D11: accepts optional ``initial_context``,
        ``entry_agent``, ``domain``. ``entry_agent`` / ``domain`` fall
        back to ``AIYARA_ENTRY_AGENT`` / ``AIYARA_DOMAIN`` env vars when
        not passed. ``initial_context`` has no env fallback.
        """
        # Phase 78.1 D11 env-var resolution (kwarg wins).
        resolved_entry_agent = entry_agent or os.environ.get("AIYARA_ENTRY_AGENT")
        resolved_domain = domain or os.environ.get("AIYARA_DOMAIN")

        if fn is not None:
            # Used as @client.trace (no parens) decorator
            return self._wrap_function(
                fn,
                session_id=session_id,
                tags=tags,
                initial_context=initial_context,
                entry_agent=resolved_entry_agent,
                domain=resolved_domain,
            )

        # Used as context manager or @client.trace(session_id=...) decorator
        return _TraceContextManager(
            self,
            session_id=session_id,
            tags=tags,
            initial_context=initial_context,
            entry_agent=resolved_entry_agent,
            domain=resolved_domain,
        )

    def capture(
        self,
        messages: list[dict[str, Any]] | None = None,
        tool_calls: list[dict[str, Any]] | None = None,
        model: str | None = None,
        session_id: str | None = None,
        outcome: dict[str, Any] | None = None,
        initial_context: dict[str, Any] | None = None,
        entry_agent: str | None = None,
        domain: str | None = None,
        **kwargs: Any,
    ) -> None:
        """Manual capture: one-shot trace submission.

        For frameworks that can't be auto-instrumented.

        Phase 78.1 D11: accepts optional ``initial_context``,
        ``entry_agent``, and ``domain`` that forward through to
        ``AiyaraTrace``. ``entry_agent`` and ``domain`` fall back to
        ``AIYARA_ENTRY_AGENT`` and ``AIYARA_DOMAIN`` env vars when not
        passed; ``initial_context`` has no env fallback (it's request-
        scoped data and belongs only in explicit caller code).
        """
        now = datetime.now(timezone.utc)
        trace_messages = []
        if messages:
            for i, m in enumerate(messages):
                trace_messages.append(
                    TraceMessage(
                        index=i,
                        role=m.get("role", "user"),
                        content=m.get("content", ""),
                        tool_calls=m.get("tool_calls"),
                    )
                )

        trace_tool_calls = []
        if tool_calls:
            for i, tc in enumerate(tool_calls):
                trace_tool_calls.append(
                    ToolExecution(
                        index=i,
                        name=tc.get("name", "unknown"),
                        arguments=tc.get("arguments", {}),
                        result=str(tc.get("result", "")),
                        error=tc.get("error", False),
                        error_message=tc.get("error_message"),
                        duration_ms=tc.get("duration_ms", 0),
                        timestamp=tc.get("timestamp", now),
                    )
                )

        # Phase 78.1 D11 resolution: explicit kwarg wins over env.
        resolved_entry_agent = entry_agent or os.environ.get("AIYARA_ENTRY_AGENT")
        resolved_domain = domain or os.environ.get("AIYARA_DOMAIN")

        trace = AiyaraTrace(
            trace_id=str(uuid.uuid4()),
            session_id=session_id,
            started_at=now,
            ended_at=now,
            messages=trace_messages,
            tool_calls=trace_tool_calls,
            model=model,
            outcome=outcome,
            initial_context=initial_context,
            entry_agent=resolved_entry_agent,
            domain=resolved_domain,
            **kwargs,
        )
        self._send_trace(trace)

    def shutdown(self, timeout: float = 5.0) -> None:
        """Flush pending traces and stop background threads."""
        self._transport.shutdown(timeout=timeout)

    # ------------------------------------------------------------------
    # Internal
    # ------------------------------------------------------------------

    def _send_trace(self, trace: AiyaraTrace) -> None:
        """Apply PII scrubbing, then sampling, then send via transport."""
        # 1. PII scrubbing (always before anything leaves process)
        scrubbed = self._scrubber.scrub(trace)

        # 2. Stamp prompt hash (single injection point covers every capture
        # path — capture(), TraceContext, instrumentors). Per-trace value
        # wins so callers can override for multi-prompt processes.
        if self._prompt_hash and not scrubbed.system_prompt_hash:
            scrubbed.system_prompt_hash = self._prompt_hash

        # 3. Sampling
        if not self._should_sample(scrubbed):
            return

        # 4. Send as dict
        self._transport.send(scrubbed.model_dump(mode="json"))

    def _should_sample(self, trace: AiyaraTrace) -> bool:
        """Determine whether to send this trace based on sampling config."""
        # Always send failures if configured
        if self._always_sample_failures and trace.outcome is not None:
            if trace.outcome.get("success") is False:
                return True

        # Rate-based sampling
        if self._sample_rate >= 1.0:
            return True
        if self._sample_rate <= 0.0:
            return False
        return random.random() < self._sample_rate

    def _wrap_function(
        self,
        fn: Callable,
        session_id: str | None = None,
        tags: dict[str, str] | None = None,
        initial_context: dict[str, Any] | None = None,
        entry_agent: str | None = None,
        domain: str | None = None,
    ) -> Callable:
        """Wrap a function to capture its execution as a trace."""

        @functools.wraps(fn)
        def wrapper(*args: Any, **kwargs: Any) -> Any:
            ctx = TraceContext(
                session_id=session_id,
                tags=tags,
                initial_context=initial_context,
                entry_agent=entry_agent,
                domain=domain,
            )
            try:
                result = fn(*args, **kwargs)
                return result
            except Exception as exc:
                ctx.set_outcome(success=False, reason=str(exc))
                raise
            finally:
                trace_obj = ctx._build_trace()
                self._send_trace(trace_obj)

        return wrapper


class _TraceContextManager:
    """Context manager and decorator for trace capture with keyword arguments.

    Supports both::

        with client.trace(session_id="..") as t: ...

        @client.trace(session_id="..")
        def my_func(): ...
    """

    def __init__(
        self,
        client: AiyaraClient,
        session_id: str | None = None,
        tags: dict[str, str] | None = None,
        initial_context: dict[str, Any] | None = None,
        entry_agent: str | None = None,
        domain: str | None = None,
    ) -> None:
        self._client = client
        self._session_id = session_id
        self._tags = tags
        self._initial_context = initial_context
        self._entry_agent = entry_agent
        self._domain = domain
        self._ctx: TraceContext | None = None

    def __enter__(self) -> TraceContext:
        self._ctx = TraceContext(
            session_id=self._session_id,
            tags=self._tags,
            initial_context=self._initial_context,
            entry_agent=self._entry_agent,
            domain=self._domain,
        )
        return self._ctx

    def __exit__(
        self,
        exc_type: type | None,
        exc_val: BaseException | None,
        exc_tb: Any,
    ) -> None:
        if self._ctx is not None:
            if exc_type is not None:
                self._ctx.set_outcome(success=False, reason=str(exc_val))
            trace_obj = self._ctx._build_trace()
            self._client._send_trace(trace_obj)
        return None  # Don't suppress exceptions

    def __call__(self, fn: Callable) -> Callable:
        """Allow use as a decorator with keyword arguments."""
        return self._client._wrap_function(
            fn,
            session_id=self._session_id,
            tags=self._tags,
            initial_context=self._initial_context,
            entry_agent=self._entry_agent,
            domain=self._domain,
        )
