"""Aiyara setup command -- interactive project configuration.

The first command a developer runs. Handles:
1. Project name and API key prompts
2. .env file generation
3. Connection test to ingestion endpoint
4. Local development mode (--local) with mock server

Usage:
    aiyara setup
    aiyara setup --local
    aiyara setup --endpoint https://custom-api.example.com
"""

from __future__ import annotations

import argparse
import getpass
import json
import os
import re
import sys
import time
import urllib.error
import urllib.request
from pathlib import Path
from typing import TextIO

from aiyara.transport import DEFAULT_ENDPOINT


# Validation
_PROJECT_NAME_RE = re.compile(r"^[a-zA-Z0-9][a-zA-Z0-9\-]{1,48}[a-zA-Z0-9]$")
_API_KEY_PREFIX = "ak_"
_MIN_API_KEY_LEN = 10

_LOCAL_PORT = 8321


def validate_project_name(name: str) -> str | None:
    """Validate project name. Returns error message or None if valid."""
    if len(name) < 3:
        return "Project name must be at least 3 characters"
    if len(name) > 50:
        return "Project name must be at most 50 characters"
    if not _PROJECT_NAME_RE.match(name):
        return "Project name must contain only letters, numbers, and hyphens"
    return None


def validate_api_key(key: str) -> str | None:
    """Validate API key format. Returns error message or None if valid."""
    if not key.startswith(_API_KEY_PREFIX):
        return f"API key must start with '{_API_KEY_PREFIX}'"
    if len(key) < _MIN_API_KEY_LEN:
        return f"API key must be at least {_MIN_API_KEY_LEN} characters"
    return None


def write_env_file(
    path: Path,
    project: str,
    api_key: str,
    endpoint: str,
) -> None:
    """Write .env config file.

    The written ``AIYARA_ENDPOINT`` value is always the base URL + ``/api/v1/traces``
    with exactly one slash between host and path — a trailing slash on the
    caller's ``endpoint`` is normalised first.
    """
    endpoint = endpoint.rstrip("/")
    lines = [
        f"AIYARA_PROJECT={project}",
        f"AIYARA_API_KEY={api_key}",
        f"AIYARA_ENDPOINT={endpoint}/api/v1/traces",
    ]
    path.write_text("\n".join(lines) + "\n")


def check_connection(
    endpoint: str, api_key: str = "", timeout: float = 5.0
) -> tuple[bool, str]:
    """Check connection to the ingestion endpoint via ``/api/v1/health``.

    The server response body distinguishes healthy from degraded backends —
    both are treated as "reachable" (traces queue + drain when backends
    recover), but the displayed message tells the user which case they hit.

    Returns (success, message) tuple.
    """
    endpoint = endpoint.rstrip("/")
    url = f"{endpoint}/api/v1/health"
    try:
        headers: dict[str, str] = {}
        if api_key:
            headers["Authorization"] = f"Bearer {api_key}"
        req = urllib.request.Request(url, headers=headers, method="GET")
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            if resp.status == 200:
                try:
                    body = json.loads(resp.read())
                except (ValueError, json.JSONDecodeError):
                    body = {}
                status = body.get("status") if isinstance(body, dict) else None
                if status == "healthy":
                    return True, "Connected — all backends healthy"
                if status == "degraded":
                    return True, (
                        "Connected — some backends degraded; traces will "
                        "queue until backends recover"
                    )
                # Unknown but 200 — treat as reachable, surface the shape
                return True, "Connected successfully"
            return False, f"Unexpected status: {resp.status}"
    except urllib.error.HTTPError as e:
        if e.code == 401:
            return False, (
                "Invalid API key. Get yours at https://app.aiyara.dev/settings"
            )
        if e.code == 503:
            return False, (
                "Ingest service reports backends unavailable (HTTP 503)"
            )
        return False, f"Server error (HTTP {e.code})"
    except urllib.error.URLError:
        return False, (
            "Connection refused. Is the ingestion server running? "
            "Try `aiyara setup --local` for local development."
        )
    except TimeoutError:
        return False, "Server reachable but slow. Try again later."
    except OSError as e:
        return False, f"Connection error: {e}"


def register_setup_parser(
    subparsers: argparse._SubParsersAction,
) -> argparse.ArgumentParser:
    """Register the 'setup' subcommand."""
    parser = subparsers.add_parser(
        "setup",
        help="Set up Aiyara for a new project",
        description="Interactive setup: project name, API key, connection test.",
    )
    parser.add_argument(
        "--endpoint",
        default=DEFAULT_ENDPOINT,
        help=f"Ingestion endpoint URL (default: {DEFAULT_ENDPOINT})",
    )
    parser.add_argument(
        "--local",
        action="store_true",
        help="Use local mock server for development (skips API key)",
    )
    parser.add_argument(
        "--env-file",
        default=".env",
        help="Path to .env file (default: .env)",
    )
    parser.add_argument(
        "--non-interactive",
        action="store_true",
        help=(
            "Skip prompts; read all required values from --project/--api-key "
            "flags or AIYARA_PROJECT/AIYARA_API_KEY env. For CI use."
        ),
    )
    parser.add_argument(
        "--project",
        default=None,
        help=(
            "Project name (non-interactive mode; also accepted via "
            "AIYARA_PROJECT env)."
        ),
    )
    parser.add_argument(
        "--api-key",
        default=None,
        help=(
            "API key (non-interactive mode; also accepted via "
            "AIYARA_API_KEY env). NEVER pass in shell history for prod — "
            "pipe via env instead."
        ),
    )
    return parser


def setup_command(
    args: argparse.Namespace,
    input_fn: callable = None,
    password_fn: callable = None,
    output: TextIO = None,
) -> int:
    """Execute the setup command.

    Args:
        args: Parsed CLI arguments.
        input_fn: Override for input() (for testing).
        password_fn: Override for getpass.getpass() (for testing).
        output: Override for sys.stdout (for testing).

    Returns:
        Exit code (0 for success, 1 for failure).
    """
    _input = input_fn or input
    _password = password_fn or getpass.getpass
    out = output or sys.stdout

    def _print(*a: object, **kw: object) -> None:
        print(*a, file=out, **kw)

    # Banner (ALWAYS runs — both modes)
    _print()
    _print("  Aiyara Setup")
    _print("  " + "-" * 17)
    _print()

    # Endpoint resolution (shared across both branches). --endpoint wins,
    # then AIYARA_ENDPOINT env, then DEFAULT_ENDPOINT. Trailing slash stripped
    # so downstream URL composition never produces '//'.
    endpoint = (
        args.endpoint
        or os.environ.get("AIYARA_ENDPOINT")
        or DEFAULT_ENDPOINT
    ).rstrip("/")
    api_key = ""

    # getattr fallbacks keep existing test fixtures (which build
    # argparse.Namespace with only the pre-Plan-77.1 attrs) working without
    # requiring every caller to list every new flag.
    non_interactive = getattr(args, "non_interactive", False)
    cli_project = getattr(args, "project", None)
    cli_api_key = getattr(args, "api_key", None)

    if non_interactive:
        # === NON-INTERACTIVE BRANCH ===
        # Read project/api_key from flags or env; validate; exit 1 on any
        # error. getpass and input() are NEVER called on this path — that's
        # the whole point of --non-interactive (CI / piped-stdin use).
        if args.local:
            _print(
                "  Error: --local and --non-interactive are mutually "
                "exclusive in this release."
            )
            return 1
        project = (cli_project or os.environ.get("AIYARA_PROJECT", "")).strip()
        api_key_candidate = (
            cli_api_key or os.environ.get("AIYARA_API_KEY", "")
        ).strip()
        err_project = (
            validate_project_name(project)
            if project
            else "Project name is required (use --project or AIYARA_PROJECT)"
        )
        err_api_key = (
            validate_api_key(api_key_candidate)
            if api_key_candidate
            else "API key is required (use --api-key or AIYARA_API_KEY)"
        )
        if err_project or err_api_key:
            _print("  Non-interactive setup failed:")
            if err_project:
                _print(f"    Error (project): {err_project}")
            if err_api_key:
                _print(f"    Error (api_key): {err_api_key}")
            return 1
        api_key = api_key_candidate
    else:
        # === INTERACTIVE BRANCH ===
        # Project name
        while True:
            project = _input("  Project name: ").strip()
            err = validate_project_name(project)
            if err is None:
                break
            _print(f"  Error: {err}")

        # API key (skip in local mode)
        if args.local:
            _print("  Local mode: skipping API key")
            # Start mock server
            from aiyara.mock_server import MockIngestionServer

            server = MockIngestionServer(port=_LOCAL_PORT)
            try:
                server.start()
            except OSError as e:
                _print(f"  Error starting mock server: {e}")
                _print(
                    f"  Port {_LOCAL_PORT} may be in use. "
                    "Try a different port."
                )
                return 1
            endpoint = server.url
            api_key = "ak_local_dev"
            _print(f"  Mock server started on {endpoint}")
        else:
            while True:
                api_key = _password(
                    "  API key (from https://app.aiyara.dev/settings): "
                )
                err = validate_api_key(api_key)
                if err is None:
                    break
                _print(f"  Error: {err}")

    # === SHARED POST-BRANCH (runs for BOTH interactive + non-interactive) ===
    # Write .env
    env_path = Path(args.env_file)
    _print()
    _print(f"  Writing config to {env_path}... ", end="")
    write_env_file(env_path, project, api_key, endpoint)
    _print("done")
    _print()

    # Test connection
    _print(f"  Testing connection to {endpoint}...")
    success, message = check_connection(endpoint, api_key)
    if success:
        _print(f"  [ok] {message}")
    else:
        _print(f"  [error] {message}")
        if not args.local:
            _print()
            _print("  Config saved. You can retry later with: aiyara setup")
            return 1

    # Next steps
    _print()
    _print("  Next steps:")
    _print("  1. Add to your agent code:")
    _print('     import aiyara')
    _print(f'     aiyara.init(api_key="{api_key}", auto_instrument=True)')
    _print()
    _print("  2. Run your agent -- traces will appear at:")
    _print(f"     https://app.aiyara.dev/projects/{project}")
    _print()

    # Post-setup first-trace probe — ONE selector shared across both branches.
    # Interactive budget: 120s (user is watching, can Ctrl+C).
    # Non-interactive budget: 30s (CI job time is precious).
    # AIYARA_SETUP_SKIP_WAIT=1 fully disables the probe (CI smoke tests).
    if args.local:
        _print("  Local mode: mock server running. Send traces to test.")
        # Mock server is a daemon thread; process exit cleans it up.
    elif os.environ.get("AIYARA_SETUP_SKIP_WAIT") == "1":
        _print("  Skipping first-trace probe (AIYARA_SETUP_SKIP_WAIT=1)")
    else:
        probe_timeout = 30.0 if non_interactive else 120.0
        # Learn this key's project_id from the server so the poll URL is
        # correct even when the user's display "project" name differs from
        # the server-side UUID (they always do — display names aren't IDs).
        resolved_project_id = _whoami(endpoint, api_key)
        if resolved_project_id is None:
            _print("  Skipped first-trace probe (whoami unavailable)")
        else:
            if non_interactive:
                _wait_for_trace(
                    endpoint,
                    api_key,
                    resolved_project_id,
                    _print,
                    timeout=probe_timeout,
                )
            else:
                _print("  Waiting for first trace... (Ctrl+C to skip)")
                try:
                    _wait_for_trace(
                        endpoint,
                        api_key,
                        resolved_project_id,
                        _print,
                        timeout=probe_timeout,
                    )
                except KeyboardInterrupt:
                    _print()
                    _print(
                        "  Skipped. Traces will appear when your agent runs."
                    )

    return 0


def _whoami(endpoint: str, api_key: str, timeout: float = 5.0) -> str | None:
    """Ask the ingest server who this API key belongs to.

    GETs ``{endpoint}/api/v1/whoami`` with ``Authorization: Bearer {api_key}``
    and returns the resolved ``project_id``. On any failure (network error,
    server misconfig, malformed body, missing ``project_id`` field) returns
    ``None`` — the caller treats this as a soft failure and skips the
    first-trace probe rather than failing the whole setup (``.env`` is
    already written by that point).
    """
    endpoint = endpoint.rstrip("/")
    url = f"{endpoint}/api/v1/whoami"
    try:
        req = urllib.request.Request(
            url,
            headers={"Authorization": f"Bearer {api_key}"},
            method="GET",
        )
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            if resp.status != 200:
                return None
            body = json.loads(resp.read())
    except (urllib.error.URLError, urllib.error.HTTPError, TimeoutError, OSError, ValueError, json.JSONDecodeError):
        return None
    if not isinstance(body, dict):
        return None
    project_id = body.get("project_id")
    if not isinstance(project_id, str) or not project_id:
        return None
    return project_id


def _wait_for_trace(
    endpoint: str,
    api_key: str,
    project_id: str,
    _print: callable,
    timeout: float = 120.0,
    poll_interval: float = 2.0,
) -> None:
    """Poll ``GET /api/v1/projects/{project_id}/traces/recent`` until a
    trace lands or ``timeout`` expires.

    * ``200`` + non-empty list → success, prints an [ok] line and returns.
    * ``200`` + empty list → keep polling (expected state pre-first-trace).
    * ``401``/``403`` → auth problem — break immediately; polling longer
      will not resolve a bad key.
    * Connection/timeout errors → transient; keep polling.
    """
    endpoint = endpoint.rstrip("/")
    url = f"{endpoint}/api/v1/projects/{project_id}/traces/recent?limit=1"
    start = time.monotonic()
    spinner = ["|", "/", "-", "\\"]
    i = 0

    while time.monotonic() - start < timeout:
        try:
            req = urllib.request.Request(
                url,
                headers={"Authorization": f"Bearer {api_key}"},
                method="GET",
            )
            with urllib.request.urlopen(req, timeout=5) as resp:
                if resp.status == 200:
                    data = json.loads(resp.read())
                    if isinstance(data, list) and len(data) > 0:
                        _print(
                            f"\r  [ok] First trace received! View at "
                            f"https://app.aiyara.dev/projects/{project_id}"
                        )
                        return
        except urllib.error.HTTPError as e:
            if e.code in (401, 403):
                _print(
                    "\r  [error] Auth failed: key may not belong to expected project"
                )
                return
            # Other HTTP errors (404, 5xx): transient, keep polling.
        except (urllib.error.URLError, TimeoutError, OSError, ValueError, json.JSONDecodeError):
            # Transient or malformed response — keep polling.
            pass

        _print(
            f"\r  {spinner[i % len(spinner)]} Waiting for first trace... "
            f"({int(time.monotonic() - start)}s)",
            end="",
        )
        i += 1
        time.sleep(poll_interval)

    _print(
        "\r  Timed out waiting for first trace. They'll appear when your agent runs."
    )
