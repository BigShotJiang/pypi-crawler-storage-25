"""Aiyara CLI entry point.

Usage:
    aiyara setup
    aiyara setup --local
"""

from __future__ import annotations

import argparse
import logging
import os
import sys
from importlib.metadata import version as pkg_version
from pathlib import Path


def _get_version() -> str:
    """Get package version from metadata, with fallback."""
    try:
        return pkg_version("aiyara")
    except Exception:
        return "0.1.0"


def _load_env() -> None:
    """Load .env file from project root.

    Walks up from CWD looking for .env file. Sets variables only if
    not already set in the environment (existing env vars take precedence).
    """
    search = Path.cwd()
    for _ in range(6):
        env_path = search / ".env"
        if env_path.exists():
            with open(env_path) as f:
                for line in f:
                    line = line.strip()
                    if line and not line.startswith("#") and "=" in line:
                        key, _, value = line.partition("=")
                        key = key.strip()
                        value = value.strip().strip('"').strip("'")
                        if key and key not in os.environ:
                            os.environ[key] = value
            return
        parent = search.parent
        if parent == search:
            break
        search = parent


def _build_parser() -> argparse.ArgumentParser:
    """Build the argument parser."""
    parser = argparse.ArgumentParser(
        prog="aiyara",
        description="Aiyara: agent failure monitoring SDK",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""\
Commands:
  setup     Set up Aiyara for a new project

Examples:
  aiyara setup
  aiyara setup --local
""",
    )

    parser.add_argument(
        "--version",
        action="version",
        version=f"%(prog)s {_get_version()}",
    )
    parser.add_argument(
        "--log-level",
        default="WARNING",
        choices=["DEBUG", "INFO", "WARNING", "ERROR"],
        help="Logging level (default: WARNING)",
    )

    subparsers = parser.add_subparsers(dest="command", help="Available commands")

    from aiyara.cli.setup import register_setup_parser

    register_setup_parser(subparsers)

    return parser


def main() -> int:
    """CLI entry point. Returns exit code."""
    _load_env()

    parser = _build_parser()
    args = parser.parse_args()

    logging.basicConfig(
        level=getattr(logging, args.log_level),
        format="%(asctime)s %(levelname)s %(name)s: %(message)s",
    )

    if args.command is None:
        parser.print_help()
        return 0

    if args.command == "setup":
        from aiyara.cli.setup import setup_command

        return setup_command(args)

    parser.print_help()
    return 0


def cli_main() -> None:
    """Entry point for console_scripts (no return value)."""
    sys.exit(main())
