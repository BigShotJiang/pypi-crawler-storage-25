"""PII scrubber with HMAC-based pseudonymization for Aiyara traces.

PII scrubbing is best-effort. Regex-based detection catches common formats
(emails, phone numbers, SSNs, credit cards, IPs, IBANs) but will NOT detect:
- Names, addresses, or other free-text PII (requires NER/ML models)
- Non-standard PII formats not covered by built-in patterns
- PII in binary/encoded data

For sensitive deployments, use field_paths to explicitly mark known PII fields,
and provide a before_send hook for domain-specific scrubbing. Do not rely solely
on pattern detection for regulatory compliance (GDPR, HIPAA, etc.).
"""

from __future__ import annotations

import hashlib
import hmac
import logging
import os
import re
from typing import Any, Callable

from aiyara.pii.patterns import DEFAULT_PATTERNS, Detector, find_pii, make_phone_detector
from aiyara.types import AiyaraTrace

logger = logging.getLogger(__name__)

# Defaults
_DEFAULT_MAX_TRACE_BYTES = 5 * 1024 * 1024  # 5 MB
_DEFAULT_MAX_FIELD_BYTES = 100 * 1024  # 100 KB


class PIIScrubber:
    """Client-side PII scrubber with HMAC-based pseudonymization.

    PII scrubbing is best-effort. Regex-based detection catches common formats
    (emails, phone numbers, SSNs, credit cards, IPs, IBANs) but will NOT detect:
    - Names, addresses, or other free-text PII (requires NER/ML models)
    - Non-standard PII formats not covered by built-in patterns
    - PII in binary/encoded data

    For sensitive deployments, use ``field_paths`` to explicitly mark known PII
    fields, and provide a ``before_send`` hook for domain-specific scrubbing.
    Do not rely solely on pattern detection for regulatory compliance
    (GDPR, HIPAA, etc.).

    Args:
        session_key: HMAC key for pseudonymization. Auto-generated per
            instance if ``None``.
        field_paths: Dot-notation paths to fields that should always be
            scrubbed regardless of content (e.g. ``["user.email"]``).
        before_send: Optional hook called before pattern-based scrubbing.
            Receives and returns an ``AiyaraTrace``.
        extra_patterns: Additional ``(name, pattern)`` tuples to detect.
        enabled: Set to ``False`` to disable scrubbing entirely.
        max_trace_bytes: Max serialized trace size before truncation (default 5MB).
        max_field_bytes: Max individual field size after truncation (default 100KB).
    """

    def __init__(
        self,
        session_key: bytes | None = None,
        field_paths: list[str] | None = None,
        before_send: Callable[[AiyaraTrace], AiyaraTrace] | None = None,
        extra_patterns: list[tuple[str, re.Pattern[str]]] | None = None,
        enabled: bool = True,
        max_trace_bytes: int = _DEFAULT_MAX_TRACE_BYTES,
        max_field_bytes: int = _DEFAULT_MAX_FIELD_BYTES,
        phone_region: str = "US",
    ) -> None:
        self._session_key = session_key or os.urandom(32)
        self._field_paths = field_paths or []
        self._before_send = before_send
        self._enabled = enabled
        self._max_trace_bytes = max_trace_bytes
        self._max_field_bytes = max_field_bytes

        # Build combined pattern list, replacing default phone detector if
        # a non-US region is specified
        self._patterns: list[tuple[str, Detector]] = []
        for name, detector in DEFAULT_PATTERNS:
            if name == "phone" and phone_region != "US":
                self._patterns.append(("phone", make_phone_detector(phone_region)))
            else:
                self._patterns.append((name, detector))
        if extra_patterns:
            for name, pat in extra_patterns:
                self._patterns.append((name, pat))

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def scrub(self, trace: AiyaraTrace) -> AiyaraTrace:
        """Apply PII scrubbing to a trace. Returns a new trace (immutable).

        Steps:
        1. Deep copy the trace
        2. Apply max payload guard (truncate large fields)
        3. Run before_send hook if provided
        4. Scrub field-path allowlists (always scrub regardless of content)
        5. Walk all string fields and apply pattern matchers
        6. Replace PII with HMAC tokens: ``[PII:type:a1b2c3d4]``
        """
        if not self._enabled:
            return trace

        # Deep copy via Pydantic
        working = trace.model_copy(deep=True)

        # Max payload guard
        working = self._apply_payload_guard(working)

        # before_send hook
        if self._before_send is not None:
            working = self._before_send(working)

        # Field-path scrubbing
        working = self._scrub_field_paths(working)

        # Pattern-based scrubbing on all string fields
        working = self._scrub_patterns(working)

        return working

    # ------------------------------------------------------------------
    # HMAC token generation
    # ------------------------------------------------------------------

    def _make_token(self, pii_type: str, value: str) -> str:
        """Generate a deterministic pseudonymized token.

        Format: ``[PII:{type}:{hmac_hex[:8]}]``
        """
        h = hmac.new(self._session_key, value.encode("utf-8"), hashlib.sha256)
        return f"[PII:{pii_type}:{h.hexdigest()[:8]}]"

    # ------------------------------------------------------------------
    # Payload guard
    # ------------------------------------------------------------------

    def _apply_payload_guard(self, trace: AiyaraTrace) -> AiyaraTrace:
        """Truncate large string fields if trace exceeds max size."""
        try:
            size = len(trace.model_dump_json().encode("utf-8"))
        except Exception:
            size = 0

        if size <= self._max_trace_bytes:
            return trace

        logger.warning(
            "Trace %s exceeds %d bytes (%d bytes), truncating large fields",
            trace.trace_id,
            self._max_trace_bytes,
            size,
        )

        # Truncate message content
        for msg in trace.messages:
            if len(msg.content) > self._max_field_bytes:
                msg.content = msg.content[: self._max_field_bytes] + "... [truncated]"

        # Truncate tool call results
        for tc in trace.tool_calls:
            if len(tc.result) > self._max_field_bytes:
                tc.result = tc.result[: self._max_field_bytes] + "... [truncated]"

        return trace

    # ------------------------------------------------------------------
    # Field-path scrubbing
    # ------------------------------------------------------------------

    def _scrub_field_paths(self, trace: AiyaraTrace) -> AiyaraTrace:
        """Scrub configured field paths regardless of content."""
        if not self._field_paths:
            return trace

        for path in self._field_paths:
            parts = path.split(".")

            # Check tags (flat key match on full path)
            if path in trace.tags:
                trace.tags[path] = self._make_token("field", trace.tags[path])

            # Check tool_call arguments (nested dict walk)
            for tc in trace.tool_calls:
                self._scrub_dict_path(tc.arguments, parts)

        return trace

    def _scrub_dict_path(self, d: dict[str, Any], parts: list[str]) -> None:
        """Walk a nested dict and scrub the leaf value at the given path."""
        for i, part in enumerate(parts):
            if part not in d:
                return
            if i == len(parts) - 1:
                # Leaf -- scrub it
                if isinstance(d[part], str):
                    d[part] = self._make_token("field", d[part])
            else:
                # Intermediate -- recurse
                if isinstance(d[part], dict):
                    d = d[part]
                else:
                    return

    # ------------------------------------------------------------------
    # Pattern-based scrubbing
    # ------------------------------------------------------------------

    def _scrub_patterns(self, trace: AiyaraTrace) -> AiyaraTrace:
        """Walk all string fields in the trace and replace PII matches."""
        # Messages
        for msg in trace.messages:
            msg.content = self._scrub_string(msg.content)

        # Tool calls
        for tc in trace.tool_calls:
            tc.result = self._scrub_string(tc.result)
            tc.arguments = self._scrub_dict_values(tc.arguments)

        # System prompt
        if trace.system_prompt:
            trace.system_prompt = self._scrub_string(trace.system_prompt)

        return trace

    def _scrub_string(self, text: str) -> str:
        """Replace all PII in a string with HMAC tokens."""
        if not text:
            return text

        matches = find_pii(text, self._patterns)
        if not matches:
            return text

        # Build result by replacing matches from end to start
        # (so indices stay valid)
        result = text
        for match in reversed(matches):
            token = self._make_token(match.pattern_name, match.matched_text)
            result = result[: match.start] + token + result[match.end :]

        return result

    def _scrub_dict_values(self, d: dict[str, Any]) -> dict[str, Any]:
        """Recursively scrub string values in a dict."""
        result: dict[str, Any] = {}
        for key, value in d.items():
            if isinstance(value, str):
                result[key] = self._scrub_string(value)
            elif isinstance(value, dict):
                result[key] = self._scrub_dict_values(value)
            elif isinstance(value, list):
                result[key] = self._scrub_list_values(value)
            else:
                result[key] = value
        return result

    def _scrub_list_values(self, lst: list[Any]) -> list[Any]:
        """Recursively scrub string values in a list."""
        result: list[Any] = []
        for item in lst:
            if isinstance(item, str):
                result.append(self._scrub_string(item))
            elif isinstance(item, dict):
                result.append(self._scrub_dict_values(item))
            elif isinstance(item, list):
                result.append(self._scrub_list_values(item))
            else:
                result.append(item)
        return result
