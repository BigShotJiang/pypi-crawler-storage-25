"""PII detection patterns for the Aiyara SDK.

Provides regex-based pattern matchers for common PII types: emails, phone
numbers, SSNs, credit card numbers (Luhn-validated), IP addresses (v4+v6),
and IBANs.

The phone number detector uses the ``phonenumbers`` library (google-libphonenumber
port) for reliable international format detection. All other patterns use
compiled stdlib ``re.Pattern`` objects.

Pattern sources:
- IP, SSN, credit card, IBAN patterns adapted from Microsoft Presidio's
  PatternRecognizer implementations (MIT license).
- IPv4/IPv6 validation uses Python stdlib ``ipaddress``.
- IBAN validation follows ISO 13616.
"""

from __future__ import annotations

import ipaddress
import re
from dataclasses import dataclass
from typing import Callable, Union

import phonenumbers


# ---------------------------------------------------------------------------
# PIIMatch result type
# ---------------------------------------------------------------------------

@dataclass(frozen=True, slots=True)
class PIIMatch:
    """A detected PII occurrence in text."""

    pattern_name: str
    start: int
    end: int
    matched_text: str


# ---------------------------------------------------------------------------
# Pattern type: either a compiled regex or a callable detector
# ---------------------------------------------------------------------------

Detector = Union[re.Pattern[str], Callable[[str], list[PIIMatch]]]


# ---------------------------------------------------------------------------
# Email pattern
# ---------------------------------------------------------------------------

EMAIL_PATTERN = re.compile(
    r"\b[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}\b"
)


# ---------------------------------------------------------------------------
# Phone detector (phonenumbers library)
# ---------------------------------------------------------------------------

def make_phone_detector(default_region: str = "US") -> callable:
    """Create a phone detector for the given default region.

    The default region is used for numbers without a country code prefix.
    Numbers with explicit country codes (e.g. +44, +81) are detected
    regardless of the default region.
    """

    def _detect_phones(text: str) -> list[PIIMatch]:
        results: list[PIIMatch] = []
        for match in phonenumbers.PhoneNumberMatcher(text, default_region):
            results.append(
                PIIMatch(
                    pattern_name="phone",
                    start=match.start,
                    end=match.end,
                    matched_text=match.raw_string,
                )
            )
        return results

    return _detect_phones


_detect_phones = make_phone_detector("US")


# ---------------------------------------------------------------------------
# SSN pattern
# Supports dash, space, and dot delimiters (Presidio SSN5 pattern).
# Rejects invalid area numbers (000, 666, 900-999), zero groups/serials,
# all-same-digit SSNs, and known invalid SSNs (Woolworth promotional).
# ---------------------------------------------------------------------------

_SSN_RAW = re.compile(r"\b(\d{3})[- .](\d{2})[- .](\d{4})\b")

_INVALID_AREA = {"000", "666"} | {str(n) for n in range(900, 1000)}

# Well-known invalid SSNs
_BLOCKLISTED_SSNS = {
    "078051120",  # Woolworth promotional SSN (1938)
    "219099999",  # Used in advertisement
}


def _detect_ssn(text: str) -> list[PIIMatch]:
    """Detect US Social Security Numbers with validation.

    Matches dash-separated (123-45-6789), space-separated (123 45 6789),
    and dot-separated (123.45.6789) formats. Rejects mixed delimiters.
    """
    results: list[PIIMatch] = []
    for m in _SSN_RAW.finditer(text):
        area = m.group(1)
        group = m.group(2)
        serial = m.group(3)
        raw = m.group(0)

        # Reject mixed delimiters (e.g., 123-45.6789)
        delimiters = set(c for c in raw if c in "-. ")
        if len(delimiters) > 1:
            continue

        if area in _INVALID_AREA:
            continue
        if group == "00" or serial == "0000":
            continue

        # Reject all-same-digit
        digits = area + group + serial
        if len(set(digits)) == 1:
            continue

        # Reject known invalid SSNs
        if digits in _BLOCKLISTED_SSNS:
            continue

        results.append(
            PIIMatch(
                pattern_name="ssn",
                start=m.start(),
                end=m.end(),
                matched_text=raw,
            )
        )
    return results


# ---------------------------------------------------------------------------
# Credit card pattern (Luhn validation)
# ---------------------------------------------------------------------------

_CC_RAW = re.compile(r"\b(\d[ \-]?){13,19}\b")


def _luhn_check(digits: str) -> bool:
    """Validate a digit string using the Luhn algorithm."""
    total = 0
    reverse = digits[::-1]
    for i, ch in enumerate(reverse):
        n = int(ch)
        if i % 2 == 1:
            n *= 2
            if n > 9:
                n -= 9
        total += n
    return total % 10 == 0


def _detect_credit_card(text: str) -> list[PIIMatch]:
    """Detect credit card numbers with Luhn checksum validation."""
    results: list[PIIMatch] = []
    for m in _CC_RAW.finditer(text):
        raw = m.group(0).strip()
        digits = re.sub(r"[\s\-]", "", raw)
        if len(digits) < 13 or len(digits) > 19:
            continue
        if not digits.isdigit():
            continue
        if _luhn_check(digits):
            results.append(
                PIIMatch(
                    pattern_name="credit_card",
                    start=m.start(),
                    end=m.end(),
                    matched_text=raw,
                )
            )
    return results


# ---------------------------------------------------------------------------
# IP address pattern (IPv4 + IPv6)
# Uses stdlib ipaddress for validation after regex candidate matching.
# IPv4 pattern from Presidio; IPv6 pattern covers full/compressed forms.
# ---------------------------------------------------------------------------

# IPv4: dotted-quad with in-regex range validation (Presidio-style)
_IPV4_OCTET = r"(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)"
_IPV4_RAW = re.compile(
    rf"\b{_IPV4_OCTET}\.{_IPV4_OCTET}\.{_IPV4_OCTET}\.{_IPV4_OCTET}"
    r"(?:/(?:[0-2]?\d|3[0-2]))?\b"
)

# IPv6: covers full, compressed (::), and zone ID (%eth0) forms.
# Adapted from Presidio's ip_recognizer.py patterns.
_IPV6_RAW = re.compile(
    r"(?<![\w:])"  # negative lookbehind: not preceded by word char or colon
    r"("
    # Full 8 groups
    r"(?:[0-9A-Fa-f]{1,4}:){7}[0-9A-Fa-f]{1,4}"
    r"|"
    # Compressed forms with ::
    r"(?:[0-9A-Fa-f]{1,4}:){1,7}:"
    r"|"
    r"(?:[0-9A-Fa-f]{1,4}:){1,6}:[0-9A-Fa-f]{1,4}"
    r"|"
    r"(?:[0-9A-Fa-f]{1,4}:){1,5}(?::[0-9A-Fa-f]{1,4}){1,2}"
    r"|"
    r"(?:[0-9A-Fa-f]{1,4}:){1,4}(?::[0-9A-Fa-f]{1,4}){1,3}"
    r"|"
    r"(?:[0-9A-Fa-f]{1,4}:){1,3}(?::[0-9A-Fa-f]{1,4}){1,4}"
    r"|"
    r"(?:[0-9A-Fa-f]{1,4}:){1,2}(?::[0-9A-Fa-f]{1,4}){1,5}"
    r"|"
    r"[0-9A-Fa-f]{1,4}:(?::[0-9A-Fa-f]{1,4}){1,6}"
    r"|"
    # :: alone or with trailing groups
    r":(?::[0-9A-Fa-f]{1,4}){1,7}"
    r"|"
    r"::(?:[Ff]{4}(?::0{1,4})?:)?"
    # IPv4-mapped suffix (::ffff:1.2.3.4)
    rf"(?:{_IPV4_OCTET}\.{_IPV4_OCTET}\.{_IPV4_OCTET}\.{_IPV4_OCTET})"
    r"|"
    # Link-local with zone ID
    r"[Ff][Ee]80:(?::[0-9A-Fa-f]{0,4}){0,4}%[0-9a-zA-Z]+"
    r")"
    r"(?:/(?:12[0-8]|1[01]\d|[1-9]?\d))?"  # optional CIDR prefix
    r"(?![\w:])"  # negative lookahead
)


def _detect_ip(text: str) -> list[PIIMatch]:
    """Detect IPv4 and IPv6 addresses with stdlib validation."""
    results: list[PIIMatch] = []

    # IPv4
    for m in _IPV4_RAW.finditer(text):
        raw = m.group(0)
        try:
            ipaddress.ip_interface(raw)
            results.append(PIIMatch("ip_address", m.start(), m.end(), raw))
        except ValueError:
            continue

    # IPv6
    for m in _IPV6_RAW.finditer(text):
        raw = m.group(0)
        # Strip zone ID for validation (ipaddress doesn't support %zone)
        clean = raw.split("%")[0]
        try:
            ipaddress.ip_interface(clean)
            results.append(PIIMatch("ip_address", m.start(), m.end(), raw))
        except ValueError:
            continue

    return results


# ---------------------------------------------------------------------------
# IBAN pattern (country code + check digits + BBAN)
# Supports spaced and dashed formatting (DE89 3704 0044 ...).
# ---------------------------------------------------------------------------

_IBAN_RAW = re.compile(
    r"(?<![A-Z0-9])"
    r"([A-Z]{2}[0-9]{2}(?:[ \-]?[A-Z0-9]{4}){2,7}(?:[ \-]?[A-Z0-9]{1,4})?)"
    r"(?![A-Z0-9])"
)


def _iban_check(iban: str) -> bool:
    """Validate IBAN using ISO 13616 mod-97 check."""
    # Move first 4 chars to end
    rearranged = iban[4:] + iban[:4]
    # Convert letters to numbers (A=10, B=11, ...)
    numeric = ""
    for ch in rearranged:
        if ch.isdigit():
            numeric += ch
        else:
            numeric += str(ord(ch) - ord("A") + 10)
    return int(numeric) % 97 == 1


def _detect_iban(text: str) -> list[PIIMatch]:
    """Detect IBANs with ISO 13616 mod-97 validation."""
    results: list[PIIMatch] = []
    for m in _IBAN_RAW.finditer(text):
        raw = m.group(1)
        # Strip spaces/dashes for validation
        clean = raw.replace(" ", "").replace("-", "").upper()
        if len(clean) < 15 or len(clean) > 34:
            continue
        if _iban_check(clean):
            results.append(
                PIIMatch(
                    pattern_name="iban",
                    start=m.start(),
                    end=m.end(),
                    matched_text=raw,
                )
            )
    return results


# ---------------------------------------------------------------------------
# Default patterns registry
# ---------------------------------------------------------------------------

DEFAULT_PATTERNS: list[tuple[str, Detector]] = [
    ("email", EMAIL_PATTERN),
    ("phone", _detect_phones),
    ("ssn", _detect_ssn),
    ("credit_card", _detect_credit_card),
    ("ip_address", _detect_ip),
    ("iban", _detect_iban),
]


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def find_pii(
    text: str,
    patterns: list[tuple[str, Detector]] | None = None,
) -> list[PIIMatch]:
    """Find all PII matches in ``text`` using the given patterns.

    Args:
        text: The string to scan for PII.
        patterns: List of ``(name, detector)`` tuples. Defaults to
            :data:`DEFAULT_PATTERNS`.

    Returns:
        List of :class:`PIIMatch` objects, sorted by start position.
    """
    if not text:
        return []

    if patterns is None:
        patterns = DEFAULT_PATTERNS

    matches: list[PIIMatch] = []
    for name, detector in patterns:
        if callable(detector) and not isinstance(detector, re.Pattern):
            # Callable detector (e.g. phonenumbers)
            matches.extend(detector(text))
        else:
            # Compiled regex
            assert isinstance(detector, re.Pattern)
            for m in detector.finditer(text):
                matches.append(
                    PIIMatch(
                        pattern_name=name,
                        start=m.start(),
                        end=m.end(),
                        matched_text=m.group(0),
                    )
                )

    matches.sort(key=lambda m: m.start)
    return matches
