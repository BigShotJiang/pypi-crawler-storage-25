"""OpenAI client auto-instrumentation.

Monkey-patches ``openai.resources.chat.completions.Completions.create`` (and
the async variant ``acreate``) to capture:

- Model name from request
- All messages (system, user, assistant)
- Tool calls from the response
- Token usage from ``response.usage``
- Duration of the API call

If the ``openai`` package is not installed, ``is_available`` returns False
and ``instrument()`` is a no-op.
"""

from __future__ import annotations

import importlib.util
import logging
import threading
import time
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from aiyara.client import AiyaraClient

logger = logging.getLogger("aiyara.sdk.instrumentors.openai")


class OpenAIInstrumentor:
    """Patches OpenAI client to capture chat completion requests/responses."""

    def __init__(self, client: AiyaraClient) -> None:
        self._client = client
        self._original_create: Any = None
        self._original_acreate: Any = None
        self._patched = False
        self._local = threading.local()

    @property
    def is_available(self) -> bool:
        """Check if the openai package is installed."""
        return importlib.util.find_spec("openai") is not None

    def _import_completions_module(self) -> Any:
        """Import the openai completions module. Separated for testability."""
        import openai.resources.chat.completions as completions_mod

        return completions_mod

    def instrument(self) -> None:
        """Apply monkey-patches to openai.resources.chat.completions."""
        if not self.is_available or self._patched:
            return

        try:
            completions_mod = self._import_completions_module()
            cls = completions_mod.Completions

            # Save originals
            self._original_create = cls.create
            self._completions_cls = cls

            # Patch synchronous create
            instrumentor = self

            def patched_create(self_completions: Any, *args: Any, **kwargs: Any) -> Any:
                return instrumentor._wrap_create(
                    instrumentor._original_create, self_completions, *args, **kwargs
                )

            cls.create = patched_create

            # Patch async create if available
            if hasattr(completions_mod, "AsyncCompletions"):
                async_cls = completions_mod.AsyncCompletions
                if hasattr(async_cls, "create"):
                    self._original_acreate = async_cls.create
                    self._async_completions_cls = async_cls

                    async def patched_acreate(
                        self_completions: Any, *args: Any, **kwargs: Any
                    ) -> Any:
                        return await instrumentor._wrap_acreate(
                            instrumentor._original_acreate,
                            self_completions,
                            *args,
                            **kwargs,
                        )

                    async_cls.create = patched_acreate

            self._patched = True
            logger.debug("OpenAI instrumentation applied")

        except Exception:
            logger.warning("Failed to instrument OpenAI — tracing will not capture OpenAI calls", exc_info=True)

    def uninstrument(self) -> None:
        """Remove monkey-patches, restoring original methods."""
        if not self._patched:
            return

        try:
            if self._original_create is not None:
                self._completions_cls.create = self._original_create

            if self._original_acreate is not None:
                self._async_completions_cls.create = self._original_acreate

            self._patched = False
            logger.debug("OpenAI instrumentation removed")
        except Exception:
            logger.exception("Failed to uninstrument OpenAI")

    def _wrap_create(
        self, original: Any, self_completions: Any, *args: Any, **kwargs: Any
    ) -> Any:
        """Wrap synchronous chat.completions.create."""
        start = time.monotonic()
        error_occurred = False
        response = None

        try:
            response = original(self_completions, *args, **kwargs)
            return response
        except Exception as exc:
            error_occurred = True
            self._record_error(kwargs, exc, time.monotonic() - start)
            raise
        finally:
            if not error_occurred and response is not None:
                duration_ms = (time.monotonic() - start) * 1000
                self._record_completion(kwargs, response, duration_ms)

    async def _wrap_acreate(
        self, original: Any, self_completions: Any, *args: Any, **kwargs: Any
    ) -> Any:
        """Wrap async chat.completions.create."""
        start = time.monotonic()
        error_occurred = False
        response = None

        try:
            response = await original(self_completions, *args, **kwargs)
            return response
        except Exception as exc:
            error_occurred = True
            self._record_error(kwargs, exc, time.monotonic() - start)
            raise
        finally:
            if not error_occurred and response is not None:
                duration_ms = (time.monotonic() - start) * 1000
                self._record_completion(kwargs, response, duration_ms)

    def _get_pending(self) -> dict[str, dict]:
        """Thread-local dict of pending tool calls awaiting results."""
        if not hasattr(self._local, "pending"):
            self._local.pending = {}
        return self._local.pending

    def _record_completion(
        self, request_kwargs: dict, response: Any, duration_ms: float
    ) -> None:
        """Record a successful completion as a trace."""
        try:
            model = request_kwargs.get("model", getattr(response, "model", None))
            messages = request_kwargs.get("messages", [])
            pending = self._get_pending()

            # Step 1: Match tool results from request messages to pending calls
            completed_tool_calls = []
            for m in messages:
                if isinstance(m, dict) and m.get("role") == "tool":
                    tc_id = m.get("tool_call_id")
                    if tc_id and tc_id in pending:
                        info = pending.pop(tc_id)
                        completed_tool_calls.append({
                            "name": info["name"],
                            "arguments": info["arguments"],
                            "result": m.get("content", ""),
                            "duration_ms": duration_ms,
                        })

            # Step 2: Extract new tool calls from response, store as pending
            new_tool_calls = []
            choices = getattr(response, "choices", [])
            if choices:
                msg = getattr(choices[0], "message", None)
                if msg and getattr(msg, "tool_calls", None):
                    for tc in msg.tool_calls:
                        func = getattr(tc, "function", None)
                        tc_id = getattr(tc, "id", None)
                        if func:
                            name = getattr(func, "name", "unknown")
                            arguments = _safe_parse_json(
                                getattr(func, "arguments", "{}")
                            )
                            new_tool_calls.append({
                                "name": name,
                                "arguments": arguments,
                                "result": "",
                                "duration_ms": 0,
                            })
                            if tc_id:
                                pending[tc_id] = {
                                    "name": name,
                                    "arguments": arguments,
                                }

            all_tool_calls = completed_tool_calls + new_tool_calls

            # Build trace messages
            trace_messages = []
            for m in messages:
                if isinstance(m, dict):
                    trace_messages.append({
                        "role": m.get("role", "user"),
                        "content": m.get("content", ""),
                    })

            self._client.capture(
                messages=trace_messages,
                tool_calls=all_tool_calls if all_tool_calls else None,
                model=model,
            )
        except Exception:
            logger.debug("Failed to record OpenAI completion", exc_info=True)

    def _record_error(
        self, request_kwargs: dict, exc: Exception, duration_s: float
    ) -> None:
        """Record a failed completion."""
        try:
            model = request_kwargs.get("model")
            self._client.capture(
                messages=[],
                model=model,
                outcome={"success": False, "reason": str(exc)},
            )
        except Exception:
            logger.debug("Failed to record OpenAI error", exc_info=True)


def _safe_parse_json(s: str) -> dict:
    """Parse a JSON string, returning empty dict on failure."""
    import json

    try:
        return json.loads(s)
    except (json.JSONDecodeError, TypeError):
        return {"_raw": s}
