"""Auto-instrumentation registry for supported frameworks.

Provides ``auto_instrument(client)`` which discovers and instruments all
available frameworks (OpenAI, LangGraph, OpenAI Agents SDK, Anthropic).

Instrumentors are optional -- if a framework isn't installed, it's skipped.
No hard dependency on any framework package.
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from aiyara.client import AiyaraClient

from aiyara.instrumentors.anthropic_instrumentor import AnthropicInstrumentor
from aiyara.instrumentors.langgraph_instrumentor import LangGraphInstrumentor
from aiyara.instrumentors.openai_agents_instrumentor import (
    OpenAIAgentsInstrumentor,
)
from aiyara.instrumentors.openai_instrumentor import OpenAIInstrumentor

logger = logging.getLogger("aiyara.sdk.instrumentors")

INSTRUMENTORS = {
    "openai": OpenAIInstrumentor,
    "anthropic": AnthropicInstrumentor,
    "langgraph": LangGraphInstrumentor,
    "openai_agents": OpenAIAgentsInstrumentor,
}


def auto_instrument(client: AiyaraClient) -> list[str]:
    """Instrument all available frameworks.

    Returns list of instrumented framework names.
    """
    instrumented: list[str] = []
    for name, cls in INSTRUMENTORS.items():
        inst = cls(client)
        if inst.is_available:
            inst.instrument()
            instrumented.append(name)
            logger.info("Instrumented %s", name)
        else:
            logger.debug("Skipping %s (not installed)", name)
    return instrumented
