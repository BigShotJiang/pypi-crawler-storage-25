"""OpenAI Agents SDK auto-instrumentation.

Patches ``agents.Runner.run`` and ``Runner.run_sync`` to capture tool calls
and messages from agent execution.

The OpenAI Agents SDK uses ``Runner.run(agent, input)`` which returns a
``RunResult`` with ``.new_items`` containing tool calls and messages.

If the ``openai-agents`` / ``agents`` package is not installed,
``is_available`` returns False and ``instrument()`` is a no-op.
"""

from __future__ import annotations

import importlib.util
import logging
import time
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from aiyara.client import AiyaraClient

logger = logging.getLogger("aiyara.sdk.instrumentors.openai_agents")


class OpenAIAgentsInstrumentor:
    """Patches OpenAI Agents SDK Runner to capture agent execution traces."""

    def __init__(self, client: AiyaraClient) -> None:
        self._client = client
        self._original_run: Any = None
        self._original_run_sync: Any = None
        self._runner_cls: Any = None
        self._patched = False

    @property
    def is_available(self) -> bool:
        """Check if the agents package is installed."""
        return importlib.util.find_spec("agents") is not None

    def instrument(self) -> None:
        """Patch Runner.run and Runner.run_sync."""
        if not self.is_available or self._patched:
            return

        try:
            from agents import Runner

            self._runner_cls = Runner
            self._original_run = Runner.run
            instrumentor = self

            # Patch async Runner.run
            original_run = self._original_run

            async def patched_run(*args: Any, **kwargs: Any) -> Any:
                return await instrumentor._wrap_run(original_run, *args, **kwargs)

            Runner.run = staticmethod(patched_run)

            # Patch sync Runner.run_sync if available
            if hasattr(Runner, "run_sync"):
                self._original_run_sync = Runner.run_sync
                original_run_sync = self._original_run_sync

                def patched_run_sync(*args: Any, **kwargs: Any) -> Any:
                    return instrumentor._wrap_run_sync(
                        original_run_sync, *args, **kwargs
                    )

                Runner.run_sync = staticmethod(patched_run_sync)

            self._patched = True
            logger.debug("OpenAI Agents SDK instrumentation applied")

        except Exception:
            logger.warning("Failed to instrument OpenAI Agents SDK — tracing will not capture agent runs", exc_info=True)

    def uninstrument(self) -> None:
        """Remove Runner patches, restoring originals."""
        if not self._patched or self._runner_cls is None:
            return

        try:
            if self._original_run is not None:
                self._runner_cls.run = self._original_run

            if self._original_run_sync is not None:
                self._runner_cls.run_sync = self._original_run_sync

            self._patched = False
            logger.debug("OpenAI Agents SDK instrumentation removed")
        except Exception:
            logger.exception("Failed to uninstrument OpenAI Agents SDK")

    async def _wrap_run(self, original: Any, *args: Any, **kwargs: Any) -> Any:
        """Wrap async Runner.run to capture trace."""
        start = time.monotonic()
        try:
            result = await original(*args, **kwargs)
            duration_ms = (time.monotonic() - start) * 1000
            self._record_result(result, duration_ms)
            return result
        except Exception as exc:
            self._client.capture(
                messages=[],
                outcome={"success": False, "reason": str(exc)},
            )
            raise

    def _wrap_run_sync(self, original: Any, *args: Any, **kwargs: Any) -> Any:
        """Wrap sync Runner.run_sync to capture trace."""
        start = time.monotonic()
        try:
            result = original(*args, **kwargs)
            duration_ms = (time.monotonic() - start) * 1000
            self._record_result(result, duration_ms)
            return result
        except Exception as exc:
            self._client.capture(
                messages=[],
                outcome={"success": False, "reason": str(exc)},
            )
            raise

    def _record_result(self, result: Any, duration_ms: float) -> None:
        """Extract trace data from a RunResult."""
        try:
            tool_calls = []
            messages = []

            # Extract new_items from RunResult
            items = getattr(result, "new_items", [])
            for item in items:
                item_type = type(item).__name__

                if "ToolCall" in item_type:
                    tool_calls.append({
                        "name": getattr(item, "name", getattr(item, "tool_name", "unknown")),
                        "arguments": getattr(item, "arguments", {}),
                        "result": str(getattr(item, "output", "")),
                        "duration_ms": duration_ms / max(len(items), 1),
                    })
                elif "Message" in item_type:
                    content = getattr(item, "content", "")
                    if isinstance(content, list):
                        # Handle structured content
                        content = " ".join(
                            str(getattr(c, "text", c)) for c in content
                        )
                    messages.append({
                        "role": getattr(item, "role", "assistant"),
                        "content": str(content),
                    })

            self._client.capture(
                messages=messages if messages else [],
                tool_calls=tool_calls if tool_calls else None,
            )
        except Exception:
            logger.debug("Failed to record Agents SDK result", exc_info=True)
