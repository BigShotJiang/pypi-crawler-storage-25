"""LangGraph auto-instrumentation.

Uses the **wrapper pattern** (not monkey-patching) since LangGraph's internals
change frequently. Wraps a compiled graph's ``invoke()`` and ``stream()``
methods to capture trace events.

Usage::

    from aiyara.instrumentors.langgraph_instrumentor import LangGraphInstrumentor

    instrumentor = LangGraphInstrumentor(aiyara_client)
    compiled_graph = instrumentor.wrap(compiled_graph)  # wraps invoke/stream

    # Or via the auto_instrument registry:
    aiyara.init(api_key="...", auto_instrument=True)
    # LangGraph graphs are wrapped when instrument() is called

If the ``langgraph`` package is not installed, ``is_available`` returns False
and ``instrument()`` is a no-op.
"""

from __future__ import annotations

import importlib.util
import logging
import time
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from aiyara.client import AiyaraClient

logger = logging.getLogger("aiyara.sdk.instrumentors.langgraph")


class LangGraphInstrumentor:
    """Wraps LangGraph compiled graphs to capture trace events."""

    def __init__(self, client: AiyaraClient) -> None:
        self._client = client
        self._original_compile: Any = None
        self._patched = False

    @property
    def is_available(self) -> bool:
        """Check if the langgraph package is installed."""
        return importlib.util.find_spec("langgraph") is not None

    def instrument(self) -> None:
        """Patch StateGraph.compile to auto-wrap compiled graphs.

        After instrumenting, any graph compiled via ``graph.compile()``
        will automatically have its ``invoke()`` wrapped with Aiyara tracing.
        """
        if not self.is_available or self._patched:
            return

        try:
            from langgraph.graph import StateGraph

            self._original_compile = StateGraph.compile
            instrumentor = self

            def patched_compile(self_graph: Any, *args: Any, **kwargs: Any) -> Any:
                compiled = instrumentor._original_compile(self_graph, *args, **kwargs)
                return instrumentor.wrap(compiled)

            StateGraph.compile = patched_compile
            self._state_graph_cls = StateGraph
            self._patched = True
            logger.debug("LangGraph instrumentation applied")

        except Exception:
            logger.warning("Failed to instrument LangGraph — tracing will not capture graph calls", exc_info=True)

    def uninstrument(self) -> None:
        """Remove the StateGraph.compile patch."""
        if not self._patched:
            return

        try:
            self._state_graph_cls.compile = self._original_compile
            self._patched = False
            logger.debug("LangGraph instrumentation removed")
        except Exception:
            logger.exception("Failed to uninstrument LangGraph")

    def wrap(self, compiled_graph: Any) -> Any:
        """Wrap a compiled LangGraph graph's invoke and stream methods.

        Args:
            compiled_graph: A compiled LangGraph graph (result of graph.compile()).

        Returns:
            The same graph object with instrumented invoke/stream.
        """
        if hasattr(compiled_graph, "_aiyara_wrapped"):
            return compiled_graph

        original_invoke = compiled_graph.invoke
        client = self._client

        def instrumented_invoke(*args: Any, **kwargs: Any) -> Any:
            start = time.monotonic()
            try:
                result = original_invoke(*args, **kwargs)
                duration_ms = (time.monotonic() - start) * 1000

                # Extract tool call info from result state if available
                tool_calls = _extract_tool_calls_from_state(result)

                client.capture(
                    messages=[],
                    tool_calls=tool_calls if tool_calls else None,
                )
                return result
            except Exception as exc:
                client.capture(
                    messages=[],
                    outcome={"success": False, "reason": str(exc)},
                )
                raise

        compiled_graph.invoke = instrumented_invoke

        # Wrap stream if available
        if hasattr(compiled_graph, "stream"):
            original_stream = compiled_graph.stream

            def instrumented_stream(*args: Any, **kwargs: Any) -> Any:
                start = time.monotonic()
                try:
                    result = original_stream(*args, **kwargs)
                    # Stream returns an iterator -- wrap it to capture on completion
                    return _TracingIterator(result, client, start)
                except Exception as exc:
                    client.capture(
                        messages=[],
                        outcome={"success": False, "reason": str(exc)},
                    )
                    raise

            compiled_graph.stream = instrumented_stream

        compiled_graph._aiyara_wrapped = True
        return compiled_graph


class _TracingIterator:
    """Iterator wrapper that captures trace on completion/error."""

    def __init__(self, inner: Any, client: AiyaraClient, start: float) -> None:
        self._inner = inner
        self._client = client
        self._start = start

    def __iter__(self) -> _TracingIterator:
        return self

    def __next__(self) -> Any:
        try:
            return next(self._inner)
        except StopIteration:
            # Stream completed normally
            duration_ms = (time.monotonic() - self._start) * 1000
            self._client.capture(messages=[])
            raise
        except Exception as exc:
            self._client.capture(
                messages=[],
                outcome={"success": False, "reason": str(exc)},
            )
            raise


def _extract_tool_calls_from_state(state: Any) -> list[dict]:
    """Best-effort extraction of tool calls from LangGraph state."""
    tool_calls: list[dict] = []

    if isinstance(state, dict):
        # Look for common LangGraph state keys
        messages = state.get("messages", [])
        for msg in messages:
            if hasattr(msg, "tool_calls"):
                for tc in msg.tool_calls:
                    if isinstance(tc, dict):
                        tool_calls.append({
                            "name": tc.get("name", "unknown"),
                            "arguments": tc.get("args", {}),
                            "result": "",
                        })

    return tool_calls
