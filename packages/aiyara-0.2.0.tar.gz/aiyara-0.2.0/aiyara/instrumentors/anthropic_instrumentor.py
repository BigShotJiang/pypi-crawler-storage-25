"""Anthropic client auto-instrumentation.

Monkey-patches ``anthropic.resources.messages.messages.Messages.create`` (and
the async variant on ``AsyncMessages``) to capture:

- Model name from request
- All messages (system, user, assistant)
- Tool calls from the response (tool_use content blocks)
- Tool results from the next request (tool_result content blocks),
  matched against pending tool_use ids — same pattern as the OpenAI
  instrumentor

Anthropic's tool-use shape differs from OpenAI's: tool calls are inline
content blocks (``{"type": "tool_use", "id": ..., "name": ..., "input": ...}``)
rather than a separate ``tool_calls`` array, and tool results are
``{"type": "tool_result", "tool_use_id": ..., "content": ...}`` content
blocks inside the next user message. We normalize both into the
``{name, arguments, result}`` shape ``client.capture()`` expects.

Streaming (``stream=True``) is not handled — same gap as the OpenAI
instrumentor. Streaming responses fall through unwrapped; non-streaming
ones are captured.

If the ``anthropic`` package is not installed, ``is_available`` returns
False and ``instrument()`` is a no-op.
"""

from __future__ import annotations

import importlib.util
import logging
import threading
import time
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from aiyara.client import AiyaraClient

logger = logging.getLogger("aiyara.sdk.instrumentors.anthropic")


class AnthropicInstrumentor:
    """Patches Anthropic client to capture Messages API requests/responses."""

    def __init__(self, client: AiyaraClient) -> None:
        self._client = client
        self._original_create: Any = None
        self._original_acreate: Any = None
        self._patched = False
        self._local = threading.local()

    @property
    def is_available(self) -> bool:
        """Check if the anthropic package is installed."""
        return importlib.util.find_spec("anthropic") is not None

    def _import_messages_module(self) -> Any:
        """Import the anthropic messages module. Separated for testability."""
        import anthropic.resources.messages.messages as messages_mod

        return messages_mod

    def instrument(self) -> None:
        """Apply monkey-patches to anthropic.resources.messages.messages."""
        if not self.is_available or self._patched:
            return

        try:
            messages_mod = self._import_messages_module()
            cls = messages_mod.Messages

            self._original_create = cls.create
            self._messages_cls = cls

            instrumentor = self

            def patched_create(self_messages: Any, *args: Any, **kwargs: Any) -> Any:
                return instrumentor._wrap_create(
                    instrumentor._original_create, self_messages, *args, **kwargs
                )

            cls.create = patched_create

            if hasattr(messages_mod, "AsyncMessages"):
                async_cls = messages_mod.AsyncMessages
                if hasattr(async_cls, "create"):
                    self._original_acreate = async_cls.create
                    self._async_messages_cls = async_cls

                    async def patched_acreate(
                        self_messages: Any, *args: Any, **kwargs: Any
                    ) -> Any:
                        return await instrumentor._wrap_acreate(
                            instrumentor._original_acreate,
                            self_messages,
                            *args,
                            **kwargs,
                        )

                    async_cls.create = patched_acreate

            self._patched = True
            logger.debug("Anthropic instrumentation applied")

        except Exception:
            logger.warning(
                "Failed to instrument Anthropic — tracing will not capture Anthropic calls",
                exc_info=True,
            )

    def uninstrument(self) -> None:
        """Remove monkey-patches, restoring original methods."""
        if not self._patched:
            return

        try:
            if self._original_create is not None:
                self._messages_cls.create = self._original_create

            if self._original_acreate is not None:
                self._async_messages_cls.create = self._original_acreate

            self._patched = False
            logger.debug("Anthropic instrumentation removed")
        except Exception:
            logger.exception("Failed to uninstrument Anthropic")

    def _wrap_create(
        self, original: Any, self_messages: Any, *args: Any, **kwargs: Any
    ) -> Any:
        """Wrap synchronous messages.create."""
        start = time.monotonic()
        error_occurred = False
        response = None

        try:
            response = original(self_messages, *args, **kwargs)
            return response
        except Exception as exc:
            error_occurred = True
            self._record_error(kwargs, exc, time.monotonic() - start)
            raise
        finally:
            if not error_occurred and response is not None:
                duration_ms = (time.monotonic() - start) * 1000
                self._record_completion(kwargs, response, duration_ms)

    async def _wrap_acreate(
        self, original: Any, self_messages: Any, *args: Any, **kwargs: Any
    ) -> Any:
        """Wrap async messages.create."""
        start = time.monotonic()
        error_occurred = False
        response = None

        try:
            response = await original(self_messages, *args, **kwargs)
            return response
        except Exception as exc:
            error_occurred = True
            self._record_error(kwargs, exc, time.monotonic() - start)
            raise
        finally:
            if not error_occurred and response is not None:
                duration_ms = (time.monotonic() - start) * 1000
                self._record_completion(kwargs, response, duration_ms)

    def _get_pending(self) -> dict[str, dict]:
        """Thread-local dict of pending tool_use blocks awaiting tool_result."""
        if not hasattr(self._local, "pending"):
            self._local.pending = {}
        return self._local.pending

    def _record_completion(
        self, request_kwargs: dict, response: Any, duration_ms: float
    ) -> None:
        """Record a successful Messages.create call as a trace."""
        try:
            model = request_kwargs.get("model", getattr(response, "model", None))
            messages = request_kwargs.get("messages", []) or []
            pending = self._get_pending()

            # Step 1: scan request messages for tool_result blocks and match
            # against pending tool_use ids from prior assistant turns.
            completed_tool_calls = []
            for m in messages:
                if not isinstance(m, dict):
                    continue
                content = m.get("content")
                if not isinstance(content, list):
                    continue
                for block in content:
                    if not isinstance(block, dict):
                        continue
                    if block.get("type") != "tool_result":
                        continue
                    tu_id = block.get("tool_use_id")
                    if tu_id and tu_id in pending:
                        info = pending.pop(tu_id)
                        completed_tool_calls.append({
                            "name": info["name"],
                            "arguments": info["arguments"],
                            "result": _stringify_tool_result(block.get("content", "")),
                            "duration_ms": duration_ms,
                        })

            # Step 2: extract new tool_use blocks from response, store as pending.
            new_tool_calls = []
            response_content = getattr(response, "content", None) or []
            for block in response_content:
                btype = getattr(block, "type", None) if not isinstance(block, dict) else block.get("type")
                if btype != "tool_use":
                    continue
                if isinstance(block, dict):
                    name = block.get("name", "unknown")
                    arguments = block.get("input", {}) or {}
                    tu_id = block.get("id")
                else:
                    name = getattr(block, "name", "unknown")
                    arguments = getattr(block, "input", {}) or {}
                    tu_id = getattr(block, "id", None)
                if not isinstance(arguments, dict):
                    arguments = {"_raw": arguments}
                new_tool_calls.append({
                    "name": name,
                    "arguments": arguments,
                    "result": "",
                    "duration_ms": 0,
                })
                if tu_id:
                    pending[tu_id] = {"name": name, "arguments": arguments}

            all_tool_calls = completed_tool_calls + new_tool_calls

            # Build trace messages. Anthropic's `system` lives outside the
            # messages list — surface it as an explicit system role for
            # parity with the OpenAI capture shape.
            trace_messages = []
            system = request_kwargs.get("system")
            if isinstance(system, str) and system:
                trace_messages.append({"role": "system", "content": system})
            for m in messages:
                if not isinstance(m, dict):
                    continue
                role = m.get("role", "user")
                content = m.get("content", "")
                # Anthropic content can be a list of blocks; flatten text
                # blocks for the trace string and drop tool_use/tool_result
                # blocks (they're already captured in tool_calls above).
                if isinstance(content, list):
                    text_parts = [
                        b.get("text", "")
                        for b in content
                        if isinstance(b, dict) and b.get("type") == "text"
                    ]
                    content = "\n".join(p for p in text_parts if p)
                trace_messages.append({"role": role, "content": content})

            self._client.capture(
                messages=trace_messages,
                tool_calls=all_tool_calls if all_tool_calls else None,
                model=model,
            )
        except Exception:
            logger.debug("Failed to record Anthropic completion", exc_info=True)

    def _record_error(
        self, request_kwargs: dict, exc: Exception, duration_s: float
    ) -> None:
        """Record a failed Messages.create call."""
        try:
            model = request_kwargs.get("model")
            self._client.capture(
                messages=[],
                model=model,
                outcome={"success": False, "reason": str(exc)},
            )
        except Exception:
            logger.debug("Failed to record Anthropic error", exc_info=True)


def _stringify_tool_result(content: Any) -> str:
    """Anthropic tool_result.content can be a string or list of blocks."""
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        parts = []
        for block in content:
            if isinstance(block, dict) and block.get("type") == "text":
                parts.append(block.get("text", ""))
            else:
                parts.append(str(block))
        return "\n".join(parts)
    return str(content)
