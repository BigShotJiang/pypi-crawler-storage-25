"""Aiyara Python SDK -- client-side trace capture and PII scrubbing.

Quick start::

    import aiyara

    aiyara.init(api_key="ak_...", auto_instrument=True)

    # Or manual capture:
    aiyara.capture(
        messages=[{"role": "user", "content": "Hello"}],
        tool_calls=[{"name": "search", "arguments": {"q": "test"}, "result": "ok"}],
        model="gpt-4",
    )

    # Or context manager:
    with aiyara.trace(session_id="user-123") as t:
        t.record_message(role="user", content="Find flights")
        t.record_tool_call(name="search_flights", arguments={}, result={})

    aiyara.shutdown()
"""

from __future__ import annotations

import atexit
import os
from importlib.metadata import PackageNotFoundError, version as _pkg_version
from typing import Any, Callable

from aiyara.client import AiyaraClient
from aiyara.transport import DEFAULT_ENDPOINT
from aiyara.verdicts import VERDICT_STRINGS, Verdict

# Version is the source of truth from the installed wheel's package metadata.
# Falls back to a literal for editable / source checkout without install.
# Phase 87-06 will bump all three locations (pyproject.toml, transport.py, this fallback) in lockstep.
try:
    __version__ = _pkg_version("aiyara")
except PackageNotFoundError:  # editable / source checkout without install
    __version__ = "0.2.0"

__all__ = [
    "AiyaraClient",
    "DEFAULT_ENDPOINT",
    "VERDICT_STRINGS",
    "Verdict",
    "__version__",
    "init",
    "trace",
    "capture",
    "shutdown",
    "get_client",
]

# Global client singleton
_client: AiyaraClient | None = None


def init(
    api_key: str,
    endpoint: str | None = None,
    auto_instrument: bool = False,
    scrub_pii: bool = True,
    pii_field_paths: list[str] | None = None,
    before_send: Callable | None = None,
    sample_rate: float = 1.0,
    flush_interval: float = 5.0,
    agent_id: str | None = None,
    prompt: str | None = None,
    **kwargs: Any,
) -> AiyaraClient:
    """Initialize the Aiyara SDK. Call once at startup.

    Endpoint resolution precedence:
        1. explicit ``endpoint=`` kwarg (if non-None)
        2. ``AIYARA_ENDPOINT`` env var
        3. ``aiyara.transport.DEFAULT_ENDPOINT`` (the deployed Fly app)

    ``agent_id`` is the trace label used by the server to bucket traces.
    Resolution precedence: explicit ``agent_id=`` kwarg > ``AIYARA_PROJECT``
    env var > ``"default"``. A one-time WARNING log fires when the env
    fallback is used with no explicit kwarg.

    ``prompt`` is the agent's system prompt. When passed, it is SHA256-hashed
    once at init and the hex digest is attached to every outgoing trace as
    ``system_prompt_hash``. The ingest side compares the hash against the
    extracted prompt's hash to flag drift between deployed code and the
    rules the policy was built from. The full prompt text is *not* sent.

    Returns the client instance for advanced use (decorator, context manager).
    """
    global _client
    resolved_endpoint = endpoint or os.environ.get("AIYARA_ENDPOINT") or DEFAULT_ENDPOINT
    _client = AiyaraClient(
        api_key=api_key,
        endpoint=resolved_endpoint,
        auto_instrument=auto_instrument,
        scrub_pii=scrub_pii,
        pii_field_paths=pii_field_paths,
        before_send=before_send,
        sample_rate=sample_rate,
        flush_interval=flush_interval,
        agent_id=agent_id,
        prompt=prompt,
        **kwargs,
    )
    atexit.register(lambda: shutdown())

    if auto_instrument:
        _auto_instrument()

    return _client


def trace(fn: Callable | None = None, **kwargs: Any) -> Any:
    """Decorator/context manager using the global client.

    Accepts ``session_id``, ``tags``, and Phase 78.1 D11 context kwargs
    (``initial_context``, ``entry_agent``, ``domain``) — forwarded
    verbatim to :py:meth:`AiyaraClient.trace`. ``entry_agent`` and
    ``domain`` fall back to ``AIYARA_ENTRY_AGENT`` /
    ``AIYARA_DOMAIN`` env vars when not passed.
    """
    if _client is None:
        raise RuntimeError("Call aiyara.init() before using aiyara.trace()")
    return _client.trace(fn, **kwargs)


def capture(**kwargs: Any) -> None:
    """Manual capture using the global client.

    Accepts Phase 78.1 D11 context kwargs (``initial_context``,
    ``entry_agent``, ``domain``) — forwarded to
    :py:meth:`AiyaraClient.capture`. ``entry_agent`` and ``domain``
    fall back to ``AIYARA_ENTRY_AGENT`` / ``AIYARA_DOMAIN`` env vars.
    """
    if _client is None:
        raise RuntimeError("Call aiyara.init() before using aiyara.capture()")
    _client.capture(**kwargs)


def shutdown(timeout: float = 5.0) -> None:
    """Shutdown the global client, flushing pending traces."""
    global _client
    if _client is not None:
        _client.shutdown(timeout)
        _client = None


def get_client() -> AiyaraClient | None:
    """Return the global client (or None if not initialized)."""
    return _client


def _auto_instrument() -> list[str]:
    """Instrument all available frameworks. Returns list of instrumented names."""
    from aiyara.instrumentors import auto_instrument

    assert _client is not None
    return auto_instrument(_client)
