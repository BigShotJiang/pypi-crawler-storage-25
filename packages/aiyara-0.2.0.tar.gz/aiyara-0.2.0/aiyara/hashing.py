"""Canonical system-prompt hashing — single source of truth for the normalization
rule + digest format used to dedupe and identify extraction runs.

Every caller (CSIM ingest, extraction seed scripts, portal wizard upload,
``find_by_prompt_hash`` consumers) routes through ``hash_system_prompt``.
The TypeScript polyfill at
``services/portal/src/lib/hashing/systemPrompt.ts`` MUST produce byte-identical
output for the same input — the parity contract is the shared fixture file
``sdk/tests/hash_fixtures.json`` which both languages read independently.

Per PLAN.md decision D13.
"""

from __future__ import annotations

import hashlib


def hash_system_prompt(text: str) -> str:
    """Return ``"sha256:<64hex>"`` for ``text`` after canonical normalization.

    Normalization: collapse any run of whitespace (spaces, tabs, newlines,
    and unicode whitespace per ``str.split()`` semantics) to a single ASCII
    space; strip leading and trailing whitespace.

    Equivalent TS: ``text.split(/\\s+/).filter(Boolean).join(" ")`` —
    verified byte-for-byte against ``sdk/tests/hash_fixtures.json``.

    Args:
        text: Raw system prompt string. Empty strings hash to the digest of
            the empty string (``"sha256:e3b0c44..."``), which is a
            deterministic sentinel rather than a failure mode.

    Returns:
        String of the form ``"sha256:<64 lowercase hex chars>"``.
    """
    normalized = " ".join(text.split())
    digest = hashlib.sha256(normalized.encode("utf-8")).hexdigest()
    return f"sha256:{digest}"
