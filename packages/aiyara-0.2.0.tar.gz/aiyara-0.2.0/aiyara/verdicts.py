"""Canonical verdict enum — single source of truth for the evaluation verdict set.

Every caller (SDK, CSIM bridge, portal TS via codegen) imports from here.
Adding or removing a verdict string is a wire-contract change that must be
accompanied by:

1. A ClickHouse migration if `evaluation_results.verdict` is stored (currently is).
2. A matching TypeScript literal in portal's codegen'd types (enforced by the
   CI drift workflow at ``.github/workflows/api-types-drift.yml`` plus the
   Wave 6 exhaustive ``switch(v: Verdict)`` test in
   ``services/portal/src/lib/api/__tests__/verdicts.test.ts``).

Per PLAN.md decision D1 this lives in the SDK namespace (not ``csim/types/``)
so the portal can import without a CSIM dep.
"""

from __future__ import annotations

from typing import Literal

Verdict = Literal[
    "pass",
    "violated",
    "not_applicable",
    "cascade_skipped",
    "checker_error",
]
"""Type alias for the five canonical verdict strings."""

VERDICT_STRINGS: tuple[str, ...] = (
    "pass",
    "violated",
    "not_applicable",
    "cascade_skipped",
    "checker_error",
)
"""Runtime tuple of the canonical verdict strings.

Exactly five entries. Kept in sync with ``Verdict`` literal above by
convention and enforced by the Wave 6 drift test.
"""
