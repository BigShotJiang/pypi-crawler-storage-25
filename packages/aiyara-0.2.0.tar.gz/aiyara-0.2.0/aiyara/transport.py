"""HTTP transport for trace delivery with batching, retry, and offline queuing.

Manages the network reliability bridge between the SDK (client-side) and the
ingestion endpoint. Never loses traces silently -- buffers locally when offline,
retries on server errors, and flushes when connectivity returns.
"""

from __future__ import annotations

import json
import logging
import threading
import time
import urllib.error
import urllib.request
from collections import deque

from aiyara.buffer import TraceBuffer

__version__ = "0.2.0"

logger = logging.getLogger("aiyara.sdk.transport")


# Base URL for the Aiyara ingest service. `/api/v1/traces` is appended in _send_batch.
# Override per-process via `AIYARA_ENDPOINT` env or the `endpoint=` kwarg to
# `aiyara.init()`.
DEFAULT_ENDPOINT = "https://aiyara-csim.fly.dev"


class AiyaraTransport:
    """Manages trace delivery to the ingestion endpoint.

    Features:
    - Batching: accumulates events, sends in configurable batch sizes
    - Retry: exponential backoff (1s, 2s, 4s) with max 3 attempts
    - Offline queuing: buffers locally when endpoint unreachable
    - Background flush: periodic flush thread sends buffered events
    - Max trace size guard: drops oversized traces with a warning
    - Rate limiting: drops traces beyond max_traces_per_minute
    - Batch payload cap: splits large batches to prevent HTTP timeouts
    """

    def __init__(
        self,
        endpoint: str = DEFAULT_ENDPOINT,
        api_key: str = "",
        batch_size: int = 50,
        flush_interval_seconds: float = 5.0,
        max_buffer_size: int = 1000,
        max_retries: int = 3,
        timeout_seconds: float = 10.0,
        max_trace_bytes: int = 5 * 1024 * 1024,  # 5MB
        max_traces_per_minute: int = 600,
        max_batch_bytes: int = 10 * 1024 * 1024,  # 10MB
        project_id: str | None = None,
        agent_id: str | None = None,
    ) -> None:
        self._endpoint = endpoint.rstrip("/")
        self._api_key = api_key
        self._batch_size = batch_size
        self._flush_interval = flush_interval_seconds
        self._max_retries = max_retries
        self._timeout_seconds = timeout_seconds
        self._max_trace_bytes = max_trace_bytes
        self._max_traces_per_minute = max_traces_per_minute
        self._max_batch_bytes = max_batch_bytes

        # Routing identity for the server-side ingest wrapper
        # ({project_id, agent_id, traces: [...]}). Populated at init OR updated
        # post-hoc via `set_identity()` once `AiyaraClient` resolves /whoami.
        self._project_id = project_id
        self._agent_id = agent_id

        self._buffer = TraceBuffer(max_size=max_buffer_size)

        # Stats
        self._sent_count = 0
        self._failed_count = 0
        self._dropped_oversize = 0
        self._rate_limited_count = 0
        self._stats_lock = threading.Lock()

        # Rate limiting: sliding window of send timestamps
        self._send_timestamps: deque[float] = deque()
        self._rate_lock = threading.Lock()

        # Background flush thread
        self._flush_thread: threading.Thread | None = None
        self._stop_event = threading.Event()
        self._started = False
        self._start_lock = threading.Lock()

    def send(self, trace_data: dict) -> None:
        """Queue a trace event for delivery. Non-blocking.

        Rejects traces exceeding max_trace_bytes (logs warning, increments dropped count).
        Rate-limited: drops traces beyond max_traces_per_minute (logs warning).
        """
        # Check size
        try:
            serialized = json.dumps(trace_data)
        except (TypeError, ValueError) as e:
            logger.warning("Cannot serialize trace: %s", e)
            with self._stats_lock:
                self._failed_count += 1
            return

        if len(serialized.encode("utf-8")) > self._max_trace_bytes:
            logger.warning(
                "Trace exceeds max size (%d bytes > %d), dropping",
                len(serialized.encode("utf-8")),
                self._max_trace_bytes,
            )
            with self._stats_lock:
                self._dropped_oversize += 1
            return

        # Check rate limit
        now = time.monotonic()
        with self._rate_lock:
            # Remove timestamps older than 60 seconds
            while self._send_timestamps and self._send_timestamps[0] < now - 60:
                self._send_timestamps.popleft()

            if len(self._send_timestamps) >= self._max_traces_per_minute:
                logger.warning("Rate limit exceeded (%d/min), dropping trace", self._max_traces_per_minute)
                with self._stats_lock:
                    self._rate_limited_count += 1
                return

            self._send_timestamps.append(now)

        self._buffer.add(trace_data)
        self._ensure_flush_thread()

    def flush(self) -> int:
        """Force flush buffered events. Returns number of events sent successfully."""
        total_sent = 0

        while not self._buffer.is_empty:
            batch = self._buffer.drain(self._batch_size)
            if not batch:
                break

            # Split batch if payload exceeds max_batch_bytes
            sub_batches = self._split_batch(batch)

            for sub_batch in sub_batches:
                success = self._send_batch(sub_batch)
                if success:
                    total_sent += len(sub_batch)
                    with self._stats_lock:
                        self._sent_count += len(sub_batch)
                else:
                    # Requeue failed batch for retry later
                    self._buffer.requeue(sub_batch)
                    with self._stats_lock:
                        self._failed_count += len(sub_batch)
                    # Stop flushing on failure -- we'll retry next time
                    return total_sent

        return total_sent

    def set_identity(self, project_id: str, agent_id: str) -> None:
        """Update the project_id/agent_id used to wrap outgoing batches.

        Called by ``AiyaraClient`` after it has resolved ``project_id`` from
        ``/whoami`` (client init is sync; whoami fetch happens before any
        ``send()`` is possible, so there is no race with the background flush
        thread — it has not been started yet at that point).
        """
        self._project_id = project_id
        self._agent_id = agent_id

    def shutdown(self, timeout: float = 5.0) -> None:
        """Graceful shutdown: flush remaining events, stop background thread."""
        self._stop_event.set()
        # Attempt final flush
        self.flush()
        if self._flush_thread and self._flush_thread.is_alive():
            self._flush_thread.join(timeout=timeout)

    @property
    def pending_count(self) -> int:
        """Number of events waiting to be sent."""
        return self._buffer.size

    @property
    def stats(self) -> dict:
        """Return delivery stats: sent, failed, dropped, rate_limited, pending."""
        with self._stats_lock:
            return {
                "sent": self._sent_count,
                "failed": self._failed_count,
                "dropped_oversize": self._dropped_oversize,
                "rate_limited": self._rate_limited_count,
                "dropped_buffer_overflow": self._buffer.dropped_count,
                "pending": self._buffer.size,
            }

    def _ensure_flush_thread(self) -> None:
        """Start the background flush thread if not already running."""
        if self._started:
            return
        with self._start_lock:
            if self._started:
                return
            self._started = True
            self._flush_thread = threading.Thread(
                target=self._flush_loop, daemon=True, name="aiyara-flush"
            )
            self._flush_thread.start()

    def _flush_loop(self) -> None:
        """Background loop that periodically flushes buffered events."""
        while not self._stop_event.is_set():
            self._stop_event.wait(timeout=self._flush_interval)
            if not self._stop_event.is_set():
                try:
                    self.flush()
                except Exception:
                    logger.exception("Error during background flush")

    def _split_batch(self, batch: list[dict]) -> list[list[dict]]:
        """Split a batch into sub-batches if the total payload exceeds max_batch_bytes."""
        serialized = json.dumps(batch).encode("utf-8")
        if len(serialized) <= self._max_batch_bytes:
            return [batch]

        # Split into roughly equal halves and recurse
        mid = len(batch) // 2
        if mid == 0:
            # Single item exceeds batch limit -- send it anyway (individual size
            # was already checked in send())
            return [batch]

        left = self._split_batch(batch[:mid])
        right = self._split_batch(batch[mid:])
        return left + right

    def _send_batch(self, batch: list[dict]) -> bool:
        """Send a batch of events via HTTP POST with retry on 5xx.

        Wraps the raw ``list[trace]`` in the server-expected envelope
        ``{project_id, agent_id, traces: [...]}`` (see
        ``services/csim/csim/api/ingest_models.py:TraceBatchRequest``).

        If identity is missing (client init failed to resolve /whoami and
        no explicit kwargs were passed), still send the wrapper with empty
        strings — the server will reject with 422, which the existing 4xx
        path treats as a permanent failure, surfacing the misconfiguration
        in operator logs rather than silently dropping the trace.

        Returns True if the batch was delivered successfully.
        """
        if self._project_id is None or self._agent_id is None:
            logger.warning(
                "Transport has no project_id/agent_id; batch of %d traces "
                "will be rejected by server (HTTP 422). Call aiyara.init() "
                "before logging traces.",
                len(batch),
            )
            envelope = {
                "project_id": self._project_id or "",
                "agent_id": self._agent_id or "",
                "traces": batch,
            }
        else:
            envelope = {
                "project_id": self._project_id,
                "agent_id": self._agent_id,
                "traces": batch,
            }
        payload = json.dumps(envelope).encode("utf-8")
        url = f"{self._endpoint}/api/v1/traces"

        for attempt in range(self._max_retries + 1):
            try:
                req = urllib.request.Request(
                    url,
                    data=payload,
                    headers={
                        "Content-Type": "application/json",
                        "Authorization": f"Bearer {self._api_key}",
                        "User-Agent": f"aiyara-sdk-python/{__version__}",
                    },
                    method="POST",
                )
                with urllib.request.urlopen(req, timeout=self._timeout_seconds) as resp:
                    if resp.status < 300:
                        return True
                    # Shouldn't reach here for non-error statuses, but be safe
                    return True
            except urllib.error.HTTPError as e:
                if 400 <= e.code < 500:
                    # Client error -- permanent failure, don't retry
                    logger.warning(
                        "Permanent failure (HTTP %d) sending batch of %d events",
                        e.code,
                        len(batch),
                    )
                    return False
                # 5xx -- retry with backoff
                if attempt < self._max_retries:
                    backoff = 2**attempt  # 1, 2, 4
                    logger.debug(
                        "Server error (HTTP %d), retrying in %ds (attempt %d/%d)",
                        e.code,
                        backoff,
                        attempt + 1,
                        self._max_retries,
                    )
                    time.sleep(backoff)
                else:
                    logger.warning(
                        "All %d retries exhausted for batch of %d events (last HTTP %d)",
                        self._max_retries,
                        len(batch),
                        e.code,
                    )
                    return False
            except (urllib.error.URLError, OSError, TimeoutError) as e:
                # Connection error -- retry with backoff
                if attempt < self._max_retries:
                    backoff = 2**attempt
                    logger.debug(
                        "Connection error (%s), retrying in %ds (attempt %d/%d)",
                        e,
                        backoff,
                        attempt + 1,
                        self._max_retries,
                    )
                    time.sleep(backoff)
                else:
                    logger.warning(
                        "All %d retries exhausted for batch of %d events: %s",
                        self._max_retries,
                        len(batch),
                        e,
                    )
                    return False

        return False
