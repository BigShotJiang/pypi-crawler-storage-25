"""Mock ingestion server for local SDK development and testing.

Usage:
    python -m aiyara.mock_server  # starts on localhost:8321
    # Or programmatically:
    server = MockIngestionServer(port=8321)
    server.start()  # non-blocking
    # ... send traces from SDK ...
    print(server.received_traces)
    server.stop()
"""

from __future__ import annotations

import json
import logging
import sys
import threading
from http.server import HTTPServer, BaseHTTPRequestHandler
from typing import Any

logger = logging.getLogger("aiyara.sdk.mock_server")


class _IngestionHandler(BaseHTTPRequestHandler):
    """HTTP handler for the mock ingestion endpoint."""

    def do_POST(self) -> None:
        if self.path == "/v1/traces":
            self._handle_traces()
        else:
            self.send_response(404)
            self.send_header("Content-Type", "application/json")
            self.end_headers()
            self.wfile.write(json.dumps({"error": "not found"}).encode())

    def do_GET(self) -> None:
        # `/__health` is the legacy mock-only path; `/api/v1/health` matches
        # the real ingest server so `aiyara setup --local` runs the same
        # probe code path as production.
        if self.path in ("/__health", "/api/v1/health"):
            self._handle_health()
        else:
            self.send_response(404)
            self.send_header("Content-Type", "application/json")
            self.end_headers()
            self.wfile.write(json.dumps({"error": "not found"}).encode())

    def _handle_traces(self) -> None:
        # Check Authorization header
        auth = self.headers.get("Authorization", "")
        if not auth:
            self.send_response(401)
            self.send_header("Content-Type", "application/json")
            self.end_headers()
            self.wfile.write(json.dumps({"error": "missing authorization header"}).encode())
            return

        # Parse body
        content_length = int(self.headers.get("Content-Length", 0))
        if content_length == 0:
            self.send_response(400)
            self.send_header("Content-Type", "application/json")
            self.end_headers()
            self.wfile.write(json.dumps({"error": "empty body"}).encode())
            return

        body = self.rfile.read(content_length)
        try:
            data = json.loads(body)
        except json.JSONDecodeError:
            self.send_response(400)
            self.send_header("Content-Type", "application/json")
            self.end_headers()
            self.wfile.write(json.dumps({"error": "malformed JSON"}).encode())
            return

        # Store received trace data
        server: MockIngestionServer = self.server  # type: ignore[assignment]
        with server._traces_lock:
            if isinstance(data, list):
                server._traces.extend(data)
            else:
                server._traces.append(data)

        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.end_headers()
        self.wfile.write(json.dumps({"status": "ok", "accepted": 1}).encode())

    def _handle_health(self) -> None:
        server: MockIngestionServer = self.server  # type: ignore[assignment]
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.end_headers()
        resp = {
            "status": "healthy",
            "received_count": len(server._traces),
        }
        self.wfile.write(json.dumps(resp).encode())

    def log_message(self, format: str, *args: Any) -> None:
        """Suppress default logging in test/embedded mode."""
        if getattr(self.server, "_verbose", False):
            logger.info(format, *args)


class MockIngestionServer(HTTPServer):
    """Simple HTTP server that accepts trace events and stores them in memory.

    Useful for:
    - Local development (see your traces without a real backend)
    - Integration testing (assert trace content after SDK operations)
    - ``aiyara setup`` connection test (validates SDK can reach an endpoint)
    """

    def __init__(self, host: str = "127.0.0.1", port: int = 8321) -> None:
        super().__init__((host, port), _IngestionHandler)
        self._traces: list[dict] = []
        self._traces_lock = threading.Lock()
        self._thread: threading.Thread | None = None
        self._verbose = False

    def start(self) -> None:
        """Start server in a background thread."""
        self._thread = threading.Thread(
            target=self.serve_forever, daemon=True, name="aiyara-mock-server"
        )
        self._thread.start()

    def stop(self) -> None:
        """Stop the server."""
        self.shutdown()
        if self._thread:
            self._thread.join(timeout=5)

    @property
    def received_traces(self) -> list[dict]:
        """All trace events received since start."""
        with self._traces_lock:
            return list(self._traces)

    def clear(self) -> None:
        """Clear received traces."""
        with self._traces_lock:
            self._traces.clear()

    @property
    def url(self) -> str:
        """Server URL (e.g., http://127.0.0.1:8321)."""
        host, port = self.server_address
        return f"http://{host}:{port}"


def main() -> None:
    """Run the mock server standalone."""
    port = int(sys.argv[1]) if len(sys.argv) > 1 else 8321
    server = MockIngestionServer(port=port)
    server._verbose = True
    print(f"Aiyara mock ingestion server listening on {server.url}")
    print(f"Received traces: {len(server.received_traces)}")
    print("^C to stop")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print(f"\nStopping. Total traces received: {len(server.received_traces)}")
        server.shutdown()


if __name__ == "__main__":
    main()
