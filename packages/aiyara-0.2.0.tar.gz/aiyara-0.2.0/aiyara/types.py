"""Aiyara SDK trace event data model.

These types define the contract between the SDK (client-side) and the
ingestion pipeline (server-side). All traces captured by the SDK are
serialized to JSON using these Pydantic models before transmission.
"""

from __future__ import annotations

from datetime import datetime
from typing import Any

from pydantic import BaseModel


class TraceMessage(BaseModel):
    """A single message in the agent conversation."""

    index: int
    role: str  # system, user, assistant, tool
    content: str
    tool_calls: list[dict[str, Any]] | None = None


class ToolExecution(BaseModel):
    """Record of a single tool invocation."""

    index: int
    name: str
    arguments: dict[str, Any]
    result: str
    error: bool = False
    error_message: str | None = None
    duration_ms: float
    timestamp: datetime


class ContextSnapshot(BaseModel):
    """Token usage snapshot at a point in the conversation."""

    step: int
    total_tokens: int
    system_tokens: int
    conversation_tokens: int
    available_tokens: int
    utilization: float  # 0.0-1.0


class AiyaraTrace(BaseModel):
    """Complete trace of an agent execution.

    This is the primary data structure captured by the SDK. It contains
    the full conversation, tool execution log, context window snapshots,
    and metadata needed for monitoring and evaluation.
    """

    trace_id: str  # uuid4
    session_id: str | None = None
    started_at: datetime
    ended_at: datetime | None = None

    # Conversation
    messages: list[TraceMessage] = []

    # Tool execution log
    tool_calls: list[ToolExecution] = []

    # Context window snapshots
    context_snapshots: list[ContextSnapshot] = []

    # Model info
    model: str | None = None
    system_prompt: str | None = None
    system_prompt_hash: str | None = None

    # Aggregated metrics
    total_tokens: int = 0
    total_cost_usd: float = 0.0
    num_steps: int = 0
    duration_seconds: float = 0.0

    # Developer-provided metadata
    outcome: dict[str, Any] | None = None  # {success: bool, reason: str}
    user_id: str | None = None
    deploy_version: str | None = None
    tags: dict[str, str] = {}

    # Phase 78.1 D11: optional context for constraint extraction + eval.
    # Defaults preserve wire compat with older SDKs (R7).
    initial_context: dict[str, Any] | None = None
    entry_agent: str | None = None
    domain: str | None = None

    # Schema versioning (CONTEXT.md Decision 6)
    schema_version: int = 1
