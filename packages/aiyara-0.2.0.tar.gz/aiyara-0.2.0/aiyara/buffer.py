"""Bounded in-memory buffer for trace events awaiting delivery.

When the buffer is full, oldest events are evicted (FIFO). This prevents
unbounded memory growth when the ingestion endpoint is unreachable.
"""

from __future__ import annotations

import threading
from collections import deque


class TraceBuffer:
    """Bounded in-memory buffer for trace events awaiting delivery.

    When buffer is full, oldest events are evicted (FIFO). This prevents
    unbounded memory growth when the ingestion endpoint is unreachable.
    """

    def __init__(self, max_size: int = 1000) -> None:
        self._max_size = max_size
        self._buffer: deque[dict] = deque()
        self._dropped_count = 0
        self._lock = threading.Lock()

    def add(self, event: dict) -> bool:
        """Add event to buffer. Returns False if an event was dropped due to overflow."""
        with self._lock:
            if len(self._buffer) >= self._max_size:
                # Evict oldest to make room
                self._buffer.popleft()
                self._dropped_count += 1
                self._buffer.append(event)
                return False
            self._buffer.append(event)
            return True

    def drain(self, batch_size: int = 50) -> list[dict]:
        """Remove and return up to batch_size events from the front of the buffer."""
        with self._lock:
            count = min(batch_size, len(self._buffer))
            result = []
            for _ in range(count):
                result.append(self._buffer.popleft())
            return result

    def peek(self, batch_size: int = 50) -> list[dict]:
        """Return up to batch_size events without removing them."""
        with self._lock:
            count = min(batch_size, len(self._buffer))
            return list(self._buffer)[:count]

    def requeue(self, events: list[dict]) -> None:
        """Put events back at the front of the buffer (for retry after partial failure).

        If requeuing would exceed max_size, events at the tail are evicted.
        """
        with self._lock:
            # Prepend events to the front
            for event in reversed(events):
                self._buffer.appendleft(event)
            # Trim from the tail if over max_size
            while len(self._buffer) > self._max_size:
                self._buffer.pop()
                self._dropped_count += 1

    @property
    def size(self) -> int:
        """Number of events currently in the buffer."""
        with self._lock:
            return len(self._buffer)

    @property
    def is_empty(self) -> bool:
        """True if buffer has no events."""
        with self._lock:
            return len(self._buffer) == 0

    @property
    def is_full(self) -> bool:
        """True if buffer is at max capacity."""
        with self._lock:
            return len(self._buffer) >= self._max_size

    @property
    def dropped_count(self) -> int:
        """Total number of events dropped due to buffer overflow."""
        with self._lock:
            return self._dropped_count
