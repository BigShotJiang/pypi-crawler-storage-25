"""
sandflare-langchain
~~~~~~~~~~~~~~~~~~~
LangChain tool for Sandflare Firecracker microVM sandboxes.

Usage:
    from sandflare_langchain import SandflareCodeInterpreter
    from langchain.agents import initialize_agent, AgentType
    from langchain_openai import ChatOpenAI

    tool = SandflareCodeInterpreter(api_key="pa_live_...")
    llm = ChatOpenAI(model="gpt-4o")
    agent = initialize_agent([tool], llm, agent=AgentType.OPENAI_FUNCTIONS)
    result = agent.run("Calculate the factorial of 20")
"""
from __future__ import annotations

from typing import Optional, Type

from langchain_core.tools import BaseTool
from pydantic import BaseModel, Field

try:
    from sandflare import Sandbox
except ImportError as e:
    raise ImportError(
        "sandflare package is required. Install with: pip install sandflare"
    ) from e


class _CodeInput(BaseModel):
    code: str = Field(description="Python code to execute in the sandbox")


class SandflareCodeInterpreter(BaseTool):
    """LangChain tool that executes Python code in an isolated Sandflare microVM sandbox.

    Each invocation creates a fresh sandbox, runs the code, and returns stdout+stderr.
    The sandbox is deleted after the call completes.

    For stateful multi-step execution (variables persist between calls), use
    SandflareKernelInterpreter instead.
    """

    name: str = "sandflare_code_interpreter"
    description: str = (
        "Execute Python code in an isolated Firecracker microVM sandbox. "
        "Use this to run calculations, data analysis, or any code that needs "
        "a safe execution environment. Returns stdout and stderr."
    )
    args_schema: Type[BaseModel] = _CodeInput

    api_key: Optional[str] = None
    template_id: str = ""

    def _run(self, code: str) -> str:
        sb = Sandbox.create(
            api_key=self.api_key,
            template_id=self.template_id,
        )
        try:
            sb.write_file("/tmp/_sf_code.py", code)
            result = sb.exec("python3 /tmp/_sf_code.py")
            output = ""
            if result.stdout:
                output += result.stdout
            if result.stderr:
                output += f"\n[stderr]\n{result.stderr}"
            if result.exit_code != 0:
                output += f"\n[exit code: {result.exit_code}]"
            return output.strip() or "(no output)"
        finally:
            sb.delete()

    async def _arun(self, code: str) -> str:
        return self._run(code)


class SandflareKernelInterpreter(BaseTool):
    """LangChain tool that executes Python code in a PERSISTENT stateful Jupyter kernel.

    State (variables, imports) is preserved between calls within the same sandbox.
    You must call .start() before use and .stop() when done.
    """

    name: str = "sandflare_kernel_interpreter"
    description: str = (
        "Execute Python code in a persistent stateful Jupyter kernel inside a "
        "Sandflare microVM. Variables and imports are preserved between calls. "
        "Ideal for multi-step data analysis where each step builds on the last."
    )
    args_schema: Type[BaseModel] = _CodeInput

    api_key: Optional[str] = None
    template_id: str = ""
    _sandbox: Optional[object] = None

    def start(self) -> "SandflareKernelInterpreter":
        self._sandbox = Sandbox.create(
            api_key=self.api_key,
            template_id=self.template_id,
        )
        return self

    def stop(self) -> None:
        if self._sandbox is not None:
            self._sandbox.delete()
            self._sandbox = None

    def _run(self, code: str) -> str:
        if self._sandbox is None:
            self.start()
        result = self._sandbox.run_code(code)  # type: ignore[union-attr]
        outputs = []
        for out in result.outputs or []:
            if hasattr(out, "text"):
                outputs.append(out.text)
            elif hasattr(out, "data"):
                outputs.append(str(out.data))
        return "\n".join(outputs) or "(no output)"

    async def _arun(self, code: str) -> str:
        return self._run(code)


__all__ = ["SandflareCodeInterpreter", "SandflareKernelInterpreter"]
