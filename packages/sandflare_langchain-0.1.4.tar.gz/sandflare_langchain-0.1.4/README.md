# sandflare-langchain

[LangChain](https://python.langchain.com/) tool integration for [Sandflare](https://sandflare.io) — run agent-generated code in isolated Firecracker microVM sandboxes.

## Installation

```bash
pip install sandflare-langchain
```

## Usage

```python
from langchain.agents import AgentExecutor, create_openai_tools_agent
from langchain_openai import ChatOpenAI
from sandflare_langchain import SandflareCodeInterpreter

tool = SandflareCodeInterpreter(api_key="sf-...")

llm = ChatOpenAI(model="gpt-4o")
agent = create_openai_tools_agent(llm, [tool], prompt)
executor = AgentExecutor(agent=agent, tools=[tool])

result = executor.invoke({"input": "Plot a sine wave and save it as plot.png"})
```

## How it works

Each tool call creates a fresh Sandflare microVM sandbox, executes the code, streams stdout/stderr back to LangChain, and auto-deletes the sandbox when done.

## Links

- [Sandflare docs](https://docs.sandflare.io)
- [sandflare Python SDK](https://pypi.org/project/sandflare/)
