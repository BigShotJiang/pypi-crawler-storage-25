"""LangChain integration for ForceField AI security.

Re-exports the ForceField callback handler for use in LangChain pipelines.

Usage::

    from langchain_forcefield import ForceFieldCallbackHandler

    handler = ForceFieldCallbackHandler(sensitivity="high")
    llm = ChatOpenAI(callbacks=[handler])
    llm.invoke("Hello")
"""

from forcefield.integrations.langchain import (
    ForceFieldCallbackHandler,
    PromptBlockedError,
)

__all__ = ["ForceFieldCallbackHandler", "PromptBlockedError"]
__version__ = "0.1.0"
