from __future__ import annotations

from collections import defaultdict
from datetime import datetime, timezone
from typing import Any
from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, Query, Response, status
from fastapi.security import OAuth2PasswordRequestForm
from pydantic import BaseModel, ConfigDict
from sqlalchemy import and_, func
from sqlmodel import select
from sqlmodel.ext.asyncio.session import AsyncSession

from .auth import create_access_token, hash_password, verify_password
from .database import get_session
from .deps import get_current_user
from .models import ConfigRecord, DbTable, User, WorkflowRun, WorkflowStatus


# ── camelCase base ────────────────────────────────────────────────────────────

def _to_camel(s: str) -> str:
    parts = s.split("_")
    return parts[0] + "".join(p.capitalize() for p in parts[1:])


class CamelModel(BaseModel):
    model_config = ConfigDict(alias_generator=_to_camel, populate_by_name=True)


# ── Response schemas ──────────────────────────────────────────────────────────

class WorkflowNodeRead(CamelModel):
    id: str
    name: str
    status: str
    inputs: dict[str, Any] = {}
    outputs: dict[str, Any] = {}
    duration_ms: int = 0
    logs: str | None = None


class WorkflowRunSummary(CamelModel):
    id: str
    name: str
    status: str
    triggered_by: str
    started_at: datetime | None
    finished_at: datetime | None
    created_at: datetime
    children: list[WorkflowRunSummary] = []


WorkflowRunSummary.model_rebuild()


class WorkflowRunRead(CamelModel):
    id: str
    name: str
    status: str
    triggered_by: str
    started_at: datetime | None
    finished_at: datetime | None
    created_at: datetime
    nodes: list[WorkflowNodeRead] = []
    children: list[WorkflowRunRead] = []


WorkflowRunRead.model_rebuild()


class WorkflowStats(CamelModel):
    counts: dict[str, int]
    active: list[WorkflowRunSummary]
    recent: list[WorkflowRunSummary]


class ConfigRead(CamelModel):
    id: str
    key: str
    value: str
    type: str
    select_options: list[str] | None = None
    description: str | None = None
    folder: str | None = None
    created_at: datetime
    updated_at: datetime


class ConfigCreate(CamelModel):
    key: str
    value: str
    type: str
    select_options: list[str] | None = None
    description: str | None = None
    folder: str | None = None


class ConfigUpdate(CamelModel):
    key: str | None = None
    value: str | None = None
    type: str | None = None
    select_options: list[str] | None = None
    description: str | None = None
    folder: str | None = None


class DbTableRead(CamelModel):
    id: str
    name: str
    description: str | None = None
    columns: list[dict[str, Any]] = []
    rows: list[dict[str, Any]] = []
    created_at: datetime
    updated_at: datetime


class DbTableCreate(CamelModel):
    name: str
    description: str | None = None
    columns: list[dict[str, Any]] = []
    rows: list[dict[str, Any]] = []


class DbTableUpdate(CamelModel):
    name: str | None = None
    description: str | None = None
    columns: list[dict[str, Any]] | None = None
    rows: list[dict[str, Any]] | None = None


# ── Tree helpers ──────────────────────────────────────────────────────────────

def _to_summary(run: WorkflowRun, cm: dict[UUID, list[WorkflowRun]]) -> WorkflowRunSummary:
    return WorkflowRunSummary(
        id=str(run.id), name=run.name,
        status=run.status.value,
        triggered_by=run.triggered_by,
        started_at=run.started_at, finished_at=run.finished_at, created_at=run.created_at,
        children=[_to_summary(c, cm) for c in cm.get(run.id, [])],
    )


def _build_summary_tree(runs: list[WorkflowRun]) -> list[WorkflowRunSummary]:
    cm: dict[UUID, list[WorkflowRun]] = defaultdict(list)
    roots: list[WorkflowRun] = []
    for r in runs:
        (cm[r.parent_id] if r.parent_id else roots.append(r) or cm[r.parent_id])
    # cleaner split:
    cm2: dict[UUID, list[WorkflowRun]] = defaultdict(list)
    roots2: list[WorkflowRun] = []
    for r in runs:
        if r.parent_id:
            cm2[r.parent_id].append(r)
        else:
            roots2.append(r)
    return [_to_summary(r, cm2) for r in roots2]


def _build_tree(runs: list[WorkflowRun]) -> list[WorkflowRunRead]:
    cm: dict[UUID, list[WorkflowRun]] = defaultdict(list)
    roots: list[WorkflowRun] = []
    for r in runs:
        if r.parent_id:
            cm[r.parent_id].append(r)
        else:
            roots.append(r)

    def to_read(run: WorkflowRun) -> WorkflowRunRead:
        return WorkflowRunRead(
            id=str(run.id), name=run.name,
            status=run.status.value,
            triggered_by=run.triggered_by,
            started_at=run.started_at, finished_at=run.finished_at, created_at=run.created_at,
            nodes=[WorkflowNodeRead(**n) for n in (run.nodes or [])],
            children=[to_read(c) for c in cm.get(run.id, [])],
        )

    return [to_read(r) for r in roots]


# ── Router factory ────────────────────────────────────────────────────────────

def create_router(secret: str, workflows: dict) -> APIRouter:
    router = APIRouter()

    # ── Auth ──────────────────────────────────────────────────────────────────

    @router.post("/auth/token", tags=["auth"])
    async def login(
        form: OAuth2PasswordRequestForm = Depends(),
        session: AsyncSession = Depends(get_session),
    ):
        user = await session.get(User, form.username)
        if not user or not verify_password(form.password, user.hashed_password):
            raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid credentials")
        return {"access_token": create_access_token(user.username), "token_type": "bearer"}

    @router.post("/auth/register", status_code=status.HTTP_201_CREATED, tags=["auth"])
    async def register(
        form: OAuth2PasswordRequestForm = Depends(),
        session: AsyncSession = Depends(get_session),
    ):
        if await session.get(User, form.username):
            raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail="Username already exists")
        session.add(User(username=form.username, hashed_password=hash_password(form.password)))
        await session.commit()
        return {"username": form.username}

    # ── Health ─────────────────────────────────────────────────────────────────

    @router.get("/health", tags=["system"])
    async def health():
        return {"status": "ok"}

    # ── Workflow runs ──────────────────────────────────────────────────────────

    @router.get("/workflow-runs/stats", response_model=WorkflowStats, response_model_by_alias=True, tags=["workflow-runs"])
    async def get_workflow_stats(
        session: AsyncSession = Depends(get_session),
        _: User = Depends(get_current_user),
    ):
        raw = await session.execute(
            select(WorkflowRun.status, func.count(WorkflowRun.id)).group_by(WorkflowRun.status)
        )
        counts: dict[str, int] = {
            (s.value if hasattr(s, "value") else str(s)): c for s, c in raw.all()
        }
        for s in ("pending", "running", "success", "failed"):
            counts.setdefault(s, 0)

        active = list((await session.exec(
            select(WorkflowRun).where(WorkflowRun.status == WorkflowStatus.running)
        )).all())

        recent = list((await session.exec(
            select(WorkflowRun)
            .where(WorkflowRun.status != WorkflowStatus.running)
            .order_by(WorkflowRun.started_at.desc())
            .limit(5)
        )).all())

        def _s(r: WorkflowRun) -> WorkflowRunSummary:
            return WorkflowRunSummary(
                id=str(r.id), name=r.name,
                status=r.status.value,
                triggered_by=r.triggered_by, started_at=r.started_at,
                finished_at=r.finished_at, created_at=r.created_at,
            )

        return WorkflowStats(counts=counts, active=[_s(r) for r in active], recent=[_s(r) for r in recent])

    @router.get("/workflow-runs", response_model=list[WorkflowRunSummary], response_model_by_alias=True, tags=["workflow-runs"])
    async def list_workflow_runs(
        fastapi_response: Response,
        offset: int = 0,
        limit: int = 50,
        search: str = "",
        status: str = "",
        date_from: datetime | None = None,
        date_to: datetime | None = None,
        session: AsyncSession = Depends(get_session),
        _: User = Depends(get_current_user),
    ):
        conds = [WorkflowRun.parent_id == None]  # noqa: E711
        if search:
            conds.append(WorkflowRun.name.ilike(f"%{search}%"))
        if status:
            conds.append(WorkflowRun.status == status)  # type: ignore[arg-type]
        if date_from:
            conds.append(WorkflowRun.started_at >= date_from)
        if date_to:
            conds.append(WorkflowRun.started_at <= date_to)
        where = and_(*conds)

        total = (await session.execute(select(func.count(WorkflowRun.id)).where(where))).scalar_one()
        fastapi_response.headers["X-Total-Count"] = str(total)

        roots = list((await session.exec(
            select(WorkflowRun).where(where)
            .order_by(WorkflowRun.started_at.desc(), WorkflowRun.id.desc())
            .offset(offset).limit(limit)
        )).all())

        if not roots:
            return []

        root_ids = [r.id for r in roots]
        children = list((await session.exec(
            select(WorkflowRun).where(WorkflowRun.parent_id.in_(root_ids))
        )).all())

        grandchildren: list[WorkflowRun] = []
        if children:
            child_ids = [c.id for c in children]
            grandchildren = list((await session.exec(
                select(WorkflowRun).where(WorkflowRun.parent_id.in_(child_ids))
            )).all())

        return _build_summary_tree(roots + children + grandchildren)

    @router.get("/workflow-runs/{id}", response_model=WorkflowRunRead, response_model_by_alias=True, tags=["workflow-runs"])
    async def get_workflow_run(
        id: UUID,
        session: AsyncSession = Depends(get_session),
        _: User = Depends(get_current_user),
    ):
        run = await session.get(WorkflowRun, id)
        if not run:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Workflow run not found")

        children = list((await session.exec(
            select(WorkflowRun).where(WorkflowRun.parent_id == id)
        )).all())
        grandchildren: list[WorkflowRun] = []
        if children:
            child_ids = [c.id for c in children]
            grandchildren = list((await session.exec(
                select(WorkflowRun).where(WorkflowRun.parent_id.in_(child_ids))
            )).all())

        return _build_tree([run] + children + grandchildren)[0]

    # ── Execution buckets ──────────────────────────────────────────────────────

    @router.get("/execution-buckets", response_model=list[dict], tags=["execution-buckets"])
    async def get_execution_buckets(
        from_ms: int = Query(..., alias="from"),
        to_ms: int = Query(..., alias="to"),
        step_ms: int = Query(..., alias="step"),
        session: AsyncSession = Depends(get_session),
        _: User = Depends(get_current_user),
    ):
        dt_from = datetime.fromtimestamp(from_ms / 1000, tz=timezone.utc)
        dt_to = datetime.fromtimestamp(to_ms / 1000, tz=timezone.utc)

        runs = (await session.exec(
            select(WorkflowRun).where(
                WorkflowRun.started_at >= dt_from,
                WorkflowRun.started_at <= dt_to,
            )
        )).all()

        buckets: dict[int, dict] = {}
        for run in runs:
            if run.started_at is None:
                continue
            slot = (int(run.started_at.timestamp() * 1000) // step_ms) * step_ms
            if slot not in buckets:
                buckets[slot] = {"x": slot, "y": 0, "hasFailed": False}
            buckets[slot]["y"] += 1
            if run.status == WorkflowStatus.failed:
                buckets[slot]["hasFailed"] = True

        output = []
        slot = (from_ms // step_ms) * step_ms
        last = (to_ms // step_ms) * step_ms
        while slot <= last:
            output.append(buckets.get(slot, {"x": slot, "y": 0, "hasFailed": False}))
            slot += step_ms
        return output

    # ── Configs ────────────────────────────────────────────────────────────────

    def _cfg_read(r: ConfigRecord) -> ConfigRead:
        return ConfigRead(
            id=str(r.id), key=r.key, value=r.value, type=r.type,
            select_options=r.select_options, description=r.description,
            folder=r.folder, created_at=r.created_at, updated_at=r.updated_at,
        )

    @router.get("/configs", response_model=list[ConfigRead], response_model_by_alias=True, tags=["configs"])
    async def list_configs(
        session: AsyncSession = Depends(get_session),
        _: User = Depends(get_current_user),
    ):
        return [_cfg_read(r) for r in (await session.exec(select(ConfigRecord))).all()]

    @router.post("/configs", response_model=ConfigRead, response_model_by_alias=True, status_code=status.HTTP_201_CREATED, tags=["configs"])
    async def create_config(
        body: ConfigCreate,
        session: AsyncSession = Depends(get_session),
        _: User = Depends(get_current_user),
    ):
        record = ConfigRecord(**body.model_dump(by_alias=False))
        session.add(record)
        await session.commit()
        await session.refresh(record)
        return _cfg_read(record)

    @router.patch("/configs/{id}", response_model=ConfigRead, response_model_by_alias=True, tags=["configs"])
    async def update_config(
        id: UUID,
        body: ConfigUpdate,
        session: AsyncSession = Depends(get_session),
        _: User = Depends(get_current_user),
    ):
        record = await session.get(ConfigRecord, id)
        if not record:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Config not found")
        for field, value in body.model_dump(exclude_unset=True, by_alias=False).items():
            setattr(record, field, value)
        record.updated_at = datetime.now(timezone.utc)
        session.add(record)
        await session.commit()
        await session.refresh(record)
        return _cfg_read(record)

    @router.delete("/configs/{id}", status_code=status.HTTP_204_NO_CONTENT, tags=["configs"])
    async def delete_config(
        id: UUID,
        session: AsyncSession = Depends(get_session),
        _: User = Depends(get_current_user),
    ):
        record = await session.get(ConfigRecord, id)
        if not record:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Config not found")
        await session.delete(record)
        await session.commit()

    # ── DB tables ──────────────────────────────────────────────────────────────

    def _tbl_read(t: DbTable) -> DbTableRead:
        return DbTableRead(
            id=str(t.id), name=t.name, description=t.description,
            columns=t.columns or [], rows=t.rows or [],
            created_at=t.created_at, updated_at=t.updated_at,
        )

    @router.get("/db-tables", response_model=list[DbTableRead], response_model_by_alias=True, tags=["db-tables"])
    async def list_db_tables(
        session: AsyncSession = Depends(get_session),
        _: User = Depends(get_current_user),
    ):
        return [_tbl_read(t) for t in (await session.exec(select(DbTable))).all()]

    @router.post("/db-tables", response_model=DbTableRead, response_model_by_alias=True, status_code=status.HTTP_201_CREATED, tags=["db-tables"])
    async def create_db_table(
        body: DbTableCreate,
        session: AsyncSession = Depends(get_session),
        _: User = Depends(get_current_user),
    ):
        t = DbTable(**body.model_dump(by_alias=False))
        session.add(t)
        await session.commit()
        await session.refresh(t)
        return _tbl_read(t)

    @router.patch("/db-tables/{id}", response_model=DbTableRead, response_model_by_alias=True, tags=["db-tables"])
    async def update_db_table(
        id: UUID,
        body: DbTableUpdate,
        session: AsyncSession = Depends(get_session),
        _: User = Depends(get_current_user),
    ):
        t = await session.get(DbTable, id)
        if not t:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Table not found")
        for field, value in body.model_dump(exclude_unset=True, by_alias=False).items():
            setattr(t, field, value)
        t.updated_at = datetime.now(timezone.utc)
        session.add(t)
        await session.commit()
        await session.refresh(t)
        return _tbl_read(t)

    @router.delete("/db-tables/{id}", status_code=status.HTTP_204_NO_CONTENT, tags=["db-tables"])
    async def delete_db_table(
        id: UUID,
        session: AsyncSession = Depends(get_session),
        _: User = Depends(get_current_user),
    ):
        t = await session.get(DbTable, id)
        if not t:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Table not found")
        await session.delete(t)
        await session.commit()

    # ── Registered workflows ───────────────────────────────────────────────────

    @router.get("/workflows", tags=["workflows"])
    async def list_workflows(_: User = Depends(get_current_user)):
        return [{"name": name, "doc": fn.__doc__} for name, fn in workflows.items()]

    return router

