from __future__ import annotations

import time
import uuid
import functools

from .database import _SessionLocal
from .models import WorkflowRun


def make_workflow_wrapper(fn):
    import functools

    @functools.wraps(fn)
    async def wrapper(inputs: dict, *, _trigger_type: str = "manual"):
        # Pass trigger_type through to run-capture logic.
        # The actual persistence layer should read _trigger_type when creating the run.
        # For now we store it on the function call context so router/core can use it.
        return await fn(inputs)

    wrapper._gtm_fn = fn
    return wrapper
