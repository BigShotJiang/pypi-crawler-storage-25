"""Convert workflow_runs.status from VARCHAR to workflowstatus ENUM.

Revision ID: 0003
Revises: 0002
Create Date: 2026-04-05
"""
from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op

revision: str = "0003"
down_revision: Union[str, None] = "0002"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None

_ENUM_NAME = "workflowstatus"
_VALUES = ("pending", "running", "success", "failed")


def upgrade() -> None:
    # Create the enum type in the DB
    workflowstatus = sa.Enum(*_VALUES, name=_ENUM_NAME)
    workflowstatus.create(op.get_bind())

    # Alter the column: cast existing VARCHAR values to the new enum type
    op.execute(
        f"ALTER TABLE workflow_runs "
        f"ALTER COLUMN status TYPE {_ENUM_NAME} "
        f"USING status::{_ENUM_NAME}"
    )
    op.execute(
        f"ALTER TABLE workflow_runs "
        f"ALTER COLUMN status SET DEFAULT 'pending'::{_ENUM_NAME}"
    )


def downgrade() -> None:
    op.execute(
        "ALTER TABLE workflow_runs "
        "ALTER COLUMN status TYPE VARCHAR USING status::VARCHAR"
    )
    op.execute(
        "ALTER TABLE workflow_runs ALTER COLUMN status SET DEFAULT 'pending'"
    )
    sa.Enum(name=_ENUM_NAME).drop(op.get_bind())
