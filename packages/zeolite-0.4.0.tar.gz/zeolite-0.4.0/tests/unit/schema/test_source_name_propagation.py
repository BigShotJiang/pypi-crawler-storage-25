"""Tests that schema stage errors carry the supplied source name."""

import polars as pl
import zeolite as z


def test_source_name_propagates_to_normalise_validate_and_filter_errors():
    source_name = "people.csv"

    normalise_schema = z.schema("people").columns(
        z.col.str("id"),
        z.col.int("age"),
    )
    normalised = normalise_schema.step_1_normalise_table_structure(
        pl.DataFrame({"id": ["001"]}),
        source_name=source_name,
    )

    assert normalised.reject is True
    assert any(error.error == "required_column" for error in normalised.errors)
    assert {error.source for error in normalised.errors} == {source_name}

    validate_schema = z.schema("people").columns(
        z.col.int("age").validations(z.Check.gte(0, warning="any")),
    )
    df = pl.DataFrame({"age": [-1, 10]})
    normalised = validate_schema.step_1_normalise_table_structure(
        df,
        source_name=source_name,
    )
    coerced = validate_schema.step_2_coerce_datatypes(
        normalised.data,
        source_name=source_name,
    )
    prepared = validate_schema.step_3_prepare_additional_columns(
        coerced.data,
        source_name=source_name,
    )
    validated = validate_schema.step_4_validate_columns(
        prepared.data,
        source_name=source_name,
    )

    assert validated.errors
    assert {error.source for error in validated.errors} == {source_name}

    filter_schema = (
        z.schema("people")
        .columns(
            z.col.int("age").validations(
                z.Check.gte(0, warning="any", remove_row_on_fail=True)
            ),
        )
        .table_validation(z.TableCheck.removed_rows(reject=0.25))
    )
    normalised = filter_schema.step_1_normalise_table_structure(
        df,
        source_name=source_name,
    )
    coerced = filter_schema.step_2_coerce_datatypes(
        normalised.data,
        source_name=source_name,
    )
    prepared = filter_schema.step_3_prepare_additional_columns(
        coerced.data,
        source_name=source_name,
    )
    validated = filter_schema.step_4_validate_columns(
        prepared.data,
        source_name=source_name,
    )
    filtered = filter_schema.step_5_validate_and_filter_table(
        validated.data,
        source_name=source_name,
    )

    assert filtered.reject is True
    assert any(error.error == "removed_rows" for error in filtered.errors)
    assert {error.source for error in filtered.errors} == {source_name}
