import polars as pl
import pytest

import zeolite as z
from zeolite._utils.serialise.common import (
    serialize_expr,
    deserialize_expr,
    encode_dtype,
    decode_dtype,
    encode_threshold,
    decode_threshold,
    encode_table_check,
    decode_table_check,
)
from zeolite.schema._utils.serialise.artifact import (
    encode_source_col_def,
    decode_source_col_def,
    encode_validation_rule,
    decode_validation_rule,
)
from zeolite.types import SourceColDef
from zeolite.types.validation.threshold import ThresholdLevel, Threshold
from zeolite.types.validation.validation_rule import ColumnValidationRule
from zeolite.schema.validation.variants import TableCheckRemovedRows, TableCheckMinRows


class TestExprSerialization:
    def test_round_trips_alias_expr(self):
        expr = pl.col("x").cast(pl.String).alias("y")
        result = deserialize_expr(serialize_expr(expr))
        assert result.meta.output_name() == "y"

    def test_round_trips_binary_expr(self):
        expr = (pl.col("price") * pl.col("qty")).alias("total")
        result = deserialize_expr(serialize_expr(expr))
        assert result.meta.output_name() == "total"

    def test_round_trips_not_empty_check_expr(self):
        schema = z.schema("test").columns(
            z.col.str("id").validations(z.Check.not_empty(error="any"))
        )
        expr = schema._params.compiled.pipeline_params.prepare_stages[0][0].expression

        result = deserialize_expr(serialize_expr(expr))

        assert result.meta.output_name() == "id___check__is_not_null"


class TestDtypeSerialization:
    @pytest.mark.parametrize(
        "dtype", [pl.String, pl.Int64, pl.Float64, pl.Boolean, pl.Date]
    )
    def test_round_trips(self, dtype):
        assert decode_dtype(encode_dtype(dtype)) == dtype

    def test_none_round_trips(self):
        assert encode_dtype(None) is None
        assert decode_dtype(None) is None

    @pytest.mark.parametrize(
        "dtype", [pl.Datetime("us", None), pl.Duration("us"), pl.Decimal(None, 2)]
    )
    def test_round_trips_parametrized(self, dtype):
        assert decode_dtype(encode_dtype(dtype)) == dtype


class TestThresholdSerialization:
    def test_round_trips_numeric(self):
        t = Threshold(warning=0.1, error=0.2, reject=0.5)
        decoded = decode_threshold(encode_threshold(t))
        assert decoded.warning == 0.1
        assert decoded.error == 0.2
        assert decoded.reject == 0.5

    def test_round_trips_string_literals(self):
        t = Threshold(warning="any", reject="all")
        decoded = decode_threshold(encode_threshold(t))
        assert decoded.warning == "any"
        assert decoded.reject == "all"


class TestSourceColDefSerialization:
    def test_round_trips(self):
        scd = SourceColDef(
            name="id",
            variants={"id", "user_id"},
            if_missing=ThresholdLevel.REJECT,
            is_meta=False,
            dtype=pl.String,
            coerce="default",
        )
        decoded = decode_source_col_def(encode_source_col_def(scd))
        assert decoded.name == "id"
        assert decoded.variants == {"id", "user_id"}
        assert decoded.if_missing == ThresholdLevel.REJECT
        assert decoded.dtype == pl.String
        assert decoded.coerce == "default"

    def test_none_dtype_round_trips(self):
        scd = SourceColDef(
            name="x", variants={"x"}, if_missing=ThresholdLevel.REJECT, is_meta=False
        )
        decoded = decode_source_col_def(encode_source_col_def(scd))
        assert decoded.dtype is None
        assert decoded.coerce is None


class TestTableCheckSerialization:
    def test_removed_rows_round_trips(self):
        check = TableCheckRemovedRows(warning=0.2, error=0.3, reject=0.5)
        decoded = decode_table_check(encode_table_check(check))
        assert decoded.method_id() == "removed_rows"
        assert decoded._params.thresholds.warning == 0.2
        assert decoded._params.thresholds.reject == 0.5

    def test_min_rows_round_trips(self):
        check = TableCheckMinRows(reject=10)
        decoded = decode_table_check(encode_table_check(check))
        assert decoded.method_id() == "min_rows"

    def test_min_rows_reject_1_round_trips(self):
        check = TableCheckMinRows(reject=1)
        decoded = decode_table_check(encode_table_check(check))
        assert decoded.method_id() == "min_rows"


class TestValidationRuleSerialization:
    def test_round_trips(self):
        rule = ColumnValidationRule(
            check_id="not_empty",
            thresholds=Threshold(warning="any", error=0.1),
            message="{{column}} has {{count}} empty values",
            source_column="id",
            check_column="id__check__not_empty",
            schema="test",
            remove_row_on_fail=False,
        )
        decoded = decode_validation_rule(encode_validation_rule(rule))
        assert decoded.check_id == "not_empty"
        assert decoded.source_column == "id"
        assert decoded.check_column == "id__check__not_empty"
        assert decoded.thresholds.warning == "any"
        assert decoded.thresholds.error == 0.1
        assert decoded.remove_row_on_fail is False
