import json
import re
import tempfile
from pathlib import Path

import polars as pl
import pytest

import zeolite as z
from zeolite.schema._spec import SchemaSpec


def _advanced_schema():
    price_col = z.col.float("price").clean(z.Clean.decimal(decimal_places=2))
    quantity_col = z.col.int("quantity").clean(z.Clean.int())
    return (
        z.schema("spec_test")
        .columns(
            z.col.str("id").validations(z.Check.not_empty(error="any")),
            z.col.str("name").optional(),
            z.col.int("age").optional(),
            price_col.temporary(),
            quantity_col.temporary(),
            z.col.derived("total", function=price_col.ref.col * quantity_col.ref.col),
        )
        .table_validation(z.TableCheck.removed_rows(warning=0.2))
    )


def _sample_df():
    return pl.DataFrame(
        {
            "id": ["a", "b", "c"],
            "name": ["Alice", None, "Bob"],
            "age": [25, 30, None],
            "price": [10.0, 20.0, 15.0],
            "quantity": [2, 1, 3],
        }
    )


class TestSchemaSpecFromSchema:
    def test_from_schema_returns_spec(self):
        spec = SchemaSpec.from_schema(_advanced_schema())
        assert isinstance(spec, SchemaSpec)

    def test_spec_has_expected_top_level_keys(self):
        data = SchemaSpec.from_schema(_advanced_schema()).to_dict()
        assert data["version"] == "1"
        assert data["name"] == "spec_test"
        assert "columns" in data
        assert "table_checks" in data

    def test_spec_columns_are_human_readable(self):
        data = SchemaSpec.from_schema(_advanced_schema()).to_dict()
        col_names = [c["name"] for c in data["columns"]]
        assert "id" in col_names
        assert "total" in col_names

    def test_source_column_has_validations(self):
        data = SchemaSpec.from_schema(_advanced_schema()).to_dict()
        id_col = next(c for c in data["columns"] if c["name"] == "id")
        assert id_col["kind"] == "source"
        assert len(id_col["validations"]) >= 1
        assert id_col["validations"][0]["check"] == "is_not_null"

    def test_derived_column_has_expression(self):
        data = SchemaSpec.from_schema(_advanced_schema()).to_dict()
        total_col = next(c for c in data["columns"] if c["name"] == "total")
        assert total_col["kind"] == "derived"
        assert "expression" in total_col

    def test_source_column_carries_coerce_and_if_missing(self):
        data = SchemaSpec.from_schema(_advanced_schema()).to_dict()
        id_col = next(c for c in data["columns"] if c["name"] == "id")
        name_col = next(c for c in data["columns"] if c["name"] == "name")
        assert id_col["if_missing"] == "reject"
        assert name_col["if_missing"] == "pass"
        assert "coerce" in id_col


class TestSchemaSpecSaveLoad:
    def test_save_produces_readable_json(self):
        spec = SchemaSpec.from_schema(_advanced_schema())
        with tempfile.NamedTemporaryFile(suffix=".json", delete=False) as f:
            path = Path(f.name)
        spec.save(path)
        data = json.loads(path.read_text())
        assert data["version"] == "1"

    def test_load_returns_same_dict(self):
        spec = SchemaSpec.from_schema(_advanced_schema())
        with tempfile.NamedTemporaryFile(suffix=".json", delete=False) as f:
            path = Path(f.name)
        spec.save(path)
        loaded = SchemaSpec.load(path)
        assert loaded.to_dict() == spec.to_dict()


class TestSchemaSpecCompile:
    def test_compile_returns_artifact(self):
        from zeolite.schema._artifact import SchemaArtifact

        spec = SchemaSpec.from_schema(_advanced_schema())
        artifact = spec.compile()
        assert isinstance(artifact, SchemaArtifact)

    def test_compile_artifact_produces_correct_output(self):
        schema = _advanced_schema()
        df = _sample_df()
        expected = schema.apply(df).data.collect()

        spec = SchemaSpec.from_schema(schema)
        actual = spec.compile().apply(df).data.collect()

        assert actual.equals(expected)


# ----------------------------------------------------------------------
# Per-variant capture tests — verify each variant's identifying fields
# round-trip through the spec dict.
# ----------------------------------------------------------------------


def _spec_for_col(col):
    schema = z.schema("variant_capture").columns(col)
    return SchemaSpec.from_schema(schema).to_dict()


def _first_clean_params(spec, name):
    src = next(c for c in spec["columns"] if c["name"] == name)
    return src["clean"], src["clean"]["params"]


def _first_check(spec, name, idx=0):
    src = next(c for c in spec["columns"] if c["name"] == name)
    return src["validations"][idx]


class TestCleanVariantCapture:
    def test_sanitised_string_records_sanitise_level(self):
        spec = _spec_for_col(
            z.col.str("x").clean(z.Clean.sanitised_string(sanitise="lowercase"))
        )
        clean, params = _first_clean_params(spec, "x")
        assert clean["method"] == "CleanSanitisedStringColumn"
        assert params["sanitise"] == "lowercase"
        assert "sanitise_join_char" in params

    def test_enum_records_enum_map_and_invalid_value(self):
        spec = _spec_for_col(
            z.col.str("status").clean(
                z.Clean.enum(
                    enum_map={"a": "active", "i": "inactive"},
                    invalid_value="?",
                    null_value="-",
                )
            )
        )
        clean, params = _first_clean_params(spec, "status")
        assert clean["method"] == "CleanEnumColumn"
        assert params["enum_map"] == {"a": "active", "i": "inactive"}
        assert params["invalid_value"] == "?"
        assert params["null_value"] == "-"

    def test_decimal_records_decimal_places(self):
        spec = _spec_for_col(z.col.float("p").clean(z.Clean.decimal(decimal_places=4)))
        _, params = _first_clean_params(spec, "p")
        assert params["decimal_places"] == 4

    def test_number_records_output_format_as_dtype_string(self):
        spec = _spec_for_col(z.col.float("p").clean(z.Clean.float()))
        _, params = _first_clean_params(spec, "p")
        assert params["output_format"] == "Float64"

    def test_integer_records_output_format(self):
        spec = _spec_for_col(z.col.int("q").clean(z.Clean.int()))
        _, params = _first_clean_params(spec, "q")
        assert "output_format" not in params

    def test_date_records_output_format_and_day_first(self):
        spec = _spec_for_col(
            z.col.date("d").clean(
                z.Clean.date(output_format=pl.Datetime, day_first=False)
            )
        )
        _, params = _first_clean_params(spec, "d")
        assert params["output_format"] == "Datetime"
        assert params["day_first"] is False

    def test_time_records_format(self):
        spec = _spec_for_col(
            z.col("t", data_type="time").clean(z.Clean.time(time_format="%H:%M"))
        )
        _, params = _first_clean_params(spec, "t")
        assert params["time_format"] == "%H:%M"

    def test_duration_records_units(self):
        spec = _spec_for_col(
            z.col("d", data_type="duration").clean(
                z.Clean.duration(input_unit="seconds", output_unit="ms")
            )
        )
        _, params = _first_clean_params(spec, "d")
        assert params["input_unit"] == "seconds"
        assert params["output_unit"] == "ms"

    def test_boolean_records_value_sets(self):
        spec = _spec_for_col(
            z.col.bool("flag").clean(
                z.Clean.boolean(true_values={"y"}, false_values={"n"})
            )
        )
        _, params = _first_clean_params(spec, "flag")
        assert params["true_values"] == ["y"]
        assert params["false_values"] == ["n"]
        # bool_map is derived from true/false values on decode; not on the wire.
        assert "bool_map" not in params

    def test_id_records_prefix_and_separator(self):
        spec = _spec_for_col(
            z.col("k", data_type="id").clean(z.Clean.id(prefix="ORG", separator="--"))
        )
        _, params = _first_clean_params(spec, "k")
        assert params["prefix"] == "ORG"
        assert params["separator"] == "--"


class TestCheckVariantCapture:
    def test_pattern_match_records_pattern_and_flags(self):
        spec = _spec_for_col(
            z.col.str("code").validations(
                z.Check.str_matches(
                    pattern=r"^[A-Z]{3}$", regex_flags=re.IGNORECASE, error="any"
                )
            )
        )
        c = _first_check(spec, "code")
        assert c["check"] == "is_matched_to"
        assert c["params"]["pattern"] == r"^[A-Z]{3}$"
        assert c["params"]["regex_flags"] == re.IGNORECASE
        assert c["params"]["nulls_valid"] is False

    def test_str_length_records_min_max(self):
        spec = _spec_for_col(
            z.col.str("name").validations(
                z.Check.str_length(min_length=2, max_length=10, error="any")
            )
        )
        c = _first_check(spec, "name")
        assert c["check"] == "is_length"
        assert c["params"]["min_length"] == 2
        assert c["params"]["max_length"] == 10
        assert "trim" in c["params"]

    def test_is_in_records_value_list(self):
        spec = _spec_for_col(
            z.col.str("status").validations(z.Check.is_in(["a", "b", "c"], error="any"))
        )
        c = _first_check(spec, "status")
        assert c["check"] == "is_in"
        assert c["params"]["allowed_values"] == ["a", "b", "c"]

    def test_between_records_bounds(self):
        spec = _spec_for_col(
            z.col.int("age").validations(z.Check.between(0, 120, error="any"))
        )
        c = _first_check(spec, "age")
        assert c["check"] == "is_between"
        assert c["params"]["min_value"] == 0
        assert c["params"]["max_value"] == 120

    def test_eq_records_value(self):
        spec = _spec_for_col(
            z.col.str("kind").validations(z.Check.eq("ok", error="any"))
        )
        c = _first_check(spec, "kind")
        assert c["check"] == "is_equal_to"
        assert c["params"]["value"] == "ok"

    def test_lt_records_value_and_inclusivity(self):
        spec = _spec_for_col(z.col.int("n").validations(z.Check.lt(10, error="any")))
        c = _first_check(spec, "n")
        assert c["check"] == "is_less_than"
        assert c["params"]["value"] == 10
        assert c["params"]["is_inclusive"] is False

    def test_is_null_records_treat_empty_strings(self):
        spec = _spec_for_col(
            z.col.str("x").validations(
                z.Check.is_null(treat_empty_strings_as_null=False, error="any")
            )
        )
        c = _first_check(spec, "x")
        assert c["check"] == "is_null"
        assert c["params"]["treat_empty_strings_as_null"] is False

    def test_custom_check_column_records_thresholds(self):
        schema = z.schema("t").columns(
            z.col.str("x"),
            z.col.custom_check(
                "valid_x",
                function=z.col.str("x").ref.col.is_null(),
                thresholds={"warning": 0.05},
            ),
        )
        data = SchemaSpec.from_schema(schema).to_dict()
        cv_col = next(c for c in data["columns"] if c["name"] == "valid_x")
        assert cv_col["custom_validation"]["thresholds"] == {"warning": 0.05}
        assert cv_col["custom_validation"]["remove_row_on_fail"] is False

    def test_compound_check_records_children(self):
        spec = _spec_for_col(
            z.col.str("x").validations(
                z.Check.any(
                    z.Check.eq("a"),
                    z.Check.eq("b"),
                    error="any",
                )
            )
        )
        c = _first_check(spec, "x")
        assert c["check"] == "or"
        assert "checks" in c["params"]
        assert len(c["params"]["checks"]) == 2
        child_values = [child["params"]["value"] for child in c["params"]["checks"]]
        assert child_values == ["a", "b"]


# ----------------------------------------------------------------------
# Kitchen-sink round-trip — encode every clean + check variant we can
# reach through the public API and confirm json.loads(json.dumps(spec))
# is identical to the original to_dict() output.
# ----------------------------------------------------------------------


def _kitchen_sink_schema():
    price = z.col.float("price").clean(z.Clean.decimal(decimal_places=2)).temporary()
    qty = z.col.int("quantity").clean(z.Clean.int()).temporary()
    return (
        z.schema("kitchen_sink")
        .columns(
            z.col.str("id")
            .clean(z.Clean.sanitised_string(sanitise="full"))
            .validations(
                z.Check.not_empty(error="any"),
                z.Check.unique(error="any"),
                z.Check.str_length(min_length=1, max_length=64, error="any"),
                z.Check.str_matches(pattern=r"^[a-z0-9_]+$", error="any"),
            ),
            z.col.str("status")
            .clean(z.Clean.enum(enum_map={"a": "active", "i": "inactive"}))
            .validations(z.Check.is_in(["active", "inactive"], error="any")),
            z.col.str("flag").clean(z.Clean.boolean()),
            z.col.str("dob").clean(z.Clean.date()),
            z.col.str("ts").clean(z.Clean.datetime()),
            z.col.str("d").clean(z.Clean.duration(input_unit="seconds")),
            z.col.str(
                "t",
            ).clean(z.Clean.time()),
            z.col.str("k").clean(z.Clean.id(prefix="X")),
            price,
            qty,
            z.col.int("age")
            .optional()
            .validations(
                z.Check.between(0, 130, error="any"),
                z.Check.any(
                    z.Check.lt(18),
                    z.Check.gte(65),
                    error="any",
                ),
            ),
            z.col.derived("total", function=price.ref.col * qty.ref.col),
        )
        .table_validation(z.TableCheck.removed_rows(warning=0.5))
        .table_validation(z.TableCheck.min_rows(reject=1))
    )


class TestSpecJsonRoundTrip:
    def test_kitchen_sink_round_trips_through_json(self):
        spec = SchemaSpec.from_schema(_kitchen_sink_schema())
        original = spec.to_dict()
        encoded = json.dumps(original)
        reloaded = json.loads(encoded)
        assert reloaded == original

    @pytest.mark.parametrize(
        "method,column",
        [
            ("CleanSanitisedStringColumn", "id"),
            ("CleanEnumColumn", "status"),
            ("CleanBooleanColumn", "flag"),
            ("CleanDateColumn", "dob"),
            ("CleanDatetimeColumn", "ts"),
            ("CleanDurationColumn", "d"),
            ("CleanTimeColumn", "t"),
            ("CleanIdColumn", "k"),
            ("CleanDecimalColumn", "price"),
            ("CleanIntegerColumn", "quantity"),
        ],
    )
    def test_kitchen_sink_includes_clean_variant(self, method, column):
        spec = SchemaSpec.from_schema(_kitchen_sink_schema()).to_dict()
        col_spec = next(c for c in spec["columns"] if c["name"] == column)
        assert col_spec["clean"]["method"] == method
        assert col_spec["clean"]["params"] is not None


# ----------------------------------------------------------------------
# Decoder tests — load → compile → apply must equal the original
# schema's output. Plus per-clean / per-check round-trip parity at the
# params-dataclass level.
# ----------------------------------------------------------------------


def _round_trip_through_disk(schema):
    spec = SchemaSpec.from_schema(schema)
    with tempfile.NamedTemporaryFile(suffix=".json", delete=False) as f:
        path = Path(f.name)
    spec.save(path)
    return SchemaSpec.load(path)


class TestSchemaSpecLoadCompile:
    def test_loaded_compile_apply_matches_original_advanced(self):
        schema = _advanced_schema()
        df = _sample_df()
        expected = schema.apply(df).data.collect()

        actual = _round_trip_through_disk(schema).compile().apply(df).data.collect()
        assert actual.equals(expected)

    def test_loaded_compile_apply_matches_original_kitchen_sink(self):
        schema = _kitchen_sink_schema()
        df = pl.DataFrame(
            {
                "id": ["a", "b", "c"],
                "status": ["a", "i", "a"],
                "flag": ["yes", "no", "yes"],
                "dob": ["2000-01-01", "1990-06-15", "1985-12-31"],
                "ts": [
                    "2024-01-01 12:00:00",
                    "2024-02-02 09:30:00",
                    "2024-03-03 18:45:00",
                ],
                "d": [10, 20, 30],
                "t": ["08:00:00", "12:30:00", "18:00:00"],
                "k": ["X1", "X2", "X3"],
                "price": [10.0, 20.0, 15.0],
                "quantity": [2, 1, 3],
                "age": [25, 70, 17],
            }
        )
        expected = schema.apply(df).data.collect()
        actual = _round_trip_through_disk(schema).compile().apply(df).data.collect()
        assert actual.equals(expected)

    def test_to_table_schema_re_encodes_to_identical_dict(self):
        schema = _kitchen_sink_schema()
        original = SchemaSpec.from_schema(schema).to_dict()
        decoded = SchemaSpec.from_schema(
            SchemaSpec.from_schema(schema).to_table_schema()
        ).to_dict()
        assert decoded == original

    def test_compile_caches_decoded_schema(self):
        loaded = _round_trip_through_disk(_advanced_schema())
        assert loaded._schema_ref is None
        loaded.compile()
        assert loaded._schema_ref is not None

    def test_callable_function_in_spec_raises(self):
        from zeolite.exceptions import SchemaConfigurationError
        from zeolite.schema._utils.serialise.spec import decode_check

        with pytest.raises(SchemaConfigurationError, match="Custom Python callables"):
            decode_check(
                {
                    "check": "is_custom",
                    "alias": None,
                    "temporary": True,
                    "remove_row_on_fail": False,
                    "message": None,
                    "check_on_cleaned": False,
                    "params": {"function": "not-a-dict"},
                    "label": "x",
                }
            )


class TestVariantRoundTrip:
    """Per-variant params-dataclass parity for encode → decode → encode."""

    @pytest.mark.parametrize(
        "column_name",
        ["id", "status", "flag", "dob", "ts", "d", "t", "k", "price", "quantity"],
    )
    def test_clean_round_trip(self, column_name):
        from zeolite.schema._utils.serialise.spec import decode_clean, encode_clean

        schema = _kitchen_sink_schema()
        original_col = next(
            c for c in schema._params.columns if c.ref.base_name == column_name
        )
        original_clean = original_col.params.clean
        round_tripped = decode_clean(encode_clean(original_clean))
        assert encode_clean(round_tripped) == encode_clean(original_clean)

    def test_check_round_trip_for_every_validation(self):
        from zeolite.schema._utils.serialise.spec import decode_check, encode_check

        schema = _kitchen_sink_schema()
        for col in schema._params.columns:
            for check in col.params.validations:
                encoded = encode_check(check)
                round_tripped = decode_check(encoded)
                assert encode_check(round_tripped) == encoded
