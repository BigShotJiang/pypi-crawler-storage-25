import polars as pl

import zeolite as z
from zeolite.types.sensitivity import Sensitivity
from zeolite.types.validation.threshold import ThresholdLevel


class TestSchemaInspection:
    def test_input_columns_expose_public_metadata(self):
        schema = z.schema("people").columns(
            z.col.str("name", variants={"Full Name"})
            .optional("warning")
            .coerce("strict"),
            z.col.meta("source_file", data_type="string"),
        )

        sources = {source.name: source for source in schema.input_columns}

        assert sources["name"].variants == frozenset({"name", "full_name"})
        assert sources["name"].if_missing == ThresholdLevel.WARNING
        assert sources["name"].is_meta is False
        assert sources["name"].dtype == pl.String
        assert sources["name"].coerce == "strict"
        assert sources["meta___source_file"].is_meta is True

    def test_output_columns_expose_final_output_metadata(self):
        schema = z.schema("sales").columns(
            z.col.float("price")
            .sensitivity(Sensitivity.CONFIDENTIAL)
            .clean(z.Clean.decimal(decimal_places=2)),
            z.col.int("quantity").temporary(),
            z.col.str("status").clean(
                z.Clean.enum(
                    enum_map={"a": "active", "i": "inactive"},
                    invalid_value="invalid",
                    null_value="missing",
                )
            ),
            z.col.derived(
                "total",
                function=pl.col("price___clean") * pl.col("quantity"),
                data_type="float",
            ),
        )

        outputs = {column.name: column for column in schema.output_columns}

        assert set(outputs) == {"price", "total", "status"}
        assert outputs["price"].source_name == "price___clean"
        assert outputs["price"].dtype == "decimal"
        assert outputs["price"].sensitivity == Sensitivity.CONFIDENTIAL
        assert outputs["price"].column_type == "cleaned"
        assert outputs["total"].source_name == "derived___total"
        assert outputs["status"].dtype == "enum"
        assert outputs["status"].source_name == "status___clean"
        assert outputs["status"].column_type == "cleaned"
        assert outputs["status"].meta.enum_values == frozenset(
            {"active", "inactive", "invalid", "missing"}
        )

    # def test_lineage_is_dependency_inspection_surface(self):
    #     schema = z.schema("people").columns(
    #         z.col.str("name").clean(z.Clean.string()),
    #         z.col.derived(
    #             "name_len",
    #             function=z.ref("name").clean().col.str.len_chars(),
    #             data_type="integer",
    #         ),
    #     )
    #
    #     output = next(
    #         column for column in schema.output_columns if column.name == "name_len"
    #     )
    #     lineage = schema.lineage()
    #     registry_nodes = {node.name: node for node in schema.registry_nodes()}
    #
    #     assert not hasattr(output, "parent_columns")
    #     assert registry_nodes["derived___name_len"].parent_columns == frozenset(
    #         {"name___clean"}
    #     )
    #     assert any(edge["target"] == output.id for edge in lineage["edges"])
