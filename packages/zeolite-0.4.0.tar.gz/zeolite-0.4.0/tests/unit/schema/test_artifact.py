import json
import tempfile
from pathlib import Path
import polars as pl
from polars.testing import assert_frame_equal
import zeolite as z
from zeolite.schema._artifact import SchemaArtifact


def _advanced_schema():
    price_col = z.col.float("price").clean(z.Clean.decimal(decimal_places=2))
    quantity_col = z.col.int("quantity").clean(z.Clean.int())
    return (
        z.schema("test_artifact")
        .columns(
            z.col.str("id").validations(z.Check.not_empty(error="any")),
            z.col.str("name").optional(),
            z.col.int("age").optional(),
            price_col.temporary(),
            quantity_col.temporary(),
            z.col.derived("total", function=price_col.ref.col * quantity_col.ref.col),
        )
        .table_validation(z.TableCheck.removed_rows(warning=0.2))
    )


def _sample_df():
    return pl.DataFrame(
        {
            "id": ["a", "b", "c"],
            "name": ["Alice", None, "Bob"],
            "age": [25, 30, None],
            "price": [10.0, 20.0, 15.0],
            "quantity": [2, 1, 3],
        }
    )


class TestSchemaArtifactFromSchema:
    def test_from_schema_returns_artifact(self):
        schema = _advanced_schema()
        artifact = SchemaArtifact.from_schema(schema)
        assert isinstance(artifact, SchemaArtifact)

    def test_artifact_apply_matches_schema_apply(self):
        schema = _advanced_schema()
        artifact = SchemaArtifact.from_schema(schema)
        df = _sample_df()

        expected = schema.apply(df).data.collect()
        actual = artifact.apply(df).data.collect()

        assert_frame_equal(actual, expected)

    def test_artifact_apply_returns_success(self):
        schema = _advanced_schema()
        artifact = SchemaArtifact.from_schema(schema)
        result = artifact.apply(_sample_df())
        assert result.success


class TestSchemaArtifactSaveLoad:
    def test_save_produces_valid_json(self):
        artifact = SchemaArtifact.from_schema(_advanced_schema())
        with tempfile.NamedTemporaryFile(suffix=".zeo", delete=False) as f:
            path = Path(f.name)
        artifact.save(path)
        data = json.loads(path.read_text())
        assert data["version"] == "1"
        assert "source_columns" in data
        assert "prepare_stages" in data
        assert "validation_rules" in data
        assert "table_checks" in data
        assert "refined_columns" in data

    def test_load_apply_matches_original(self):
        schema = _advanced_schema()
        artifact = SchemaArtifact.from_schema(schema)
        df = _sample_df()

        with tempfile.NamedTemporaryFile(suffix=".zeo", delete=False) as f:
            path = Path(f.name)
        artifact.save(path)
        loaded = SchemaArtifact.load(path)

        expected = schema.apply(df).data.collect()
        actual = loaded.apply(df).data.collect()
        assert_frame_equal(actual, expected)

    def test_to_dict_round_trips(self):
        artifact = SchemaArtifact.from_schema(_advanced_schema())
        data = artifact.to_dict()
        loaded = SchemaArtifact.from_dict(data)
        expected = _advanced_schema().apply(_sample_df()).data.collect()
        actual = loaded.apply(_sample_df()).data.collect()
        assert_frame_equal(actual, expected)


class TestEndToEndWorkflow:
    def test_schema_to_spec_to_artifact_to_apply(self):
        """Full workflow: define → to_spec() → compile() → apply()"""
        import tempfile

        schema = (
            z.schema("workflow")
            .columns(
                z.col.str("id").validations(z.Check.not_empty(error="any")),
                z.col.int("count").optional(),
            )
            .table_validation(z.TableCheck.removed_rows(warning="any"))
        )
        df = pl.DataFrame({"id": ["x", "y"], "count": [1, 2]})
        expected = schema.apply(df).data.collect()

        # to_spec → compile → apply
        spec = schema.to_spec()
        artifact = spec.compile()
        assert artifact.apply(df).data.collect().equals(expected)

        # to_artifact → save → load → apply
        with tempfile.NamedTemporaryFile(suffix=".zeo", delete=False) as f:
            path = Path(f.name)
        schema.to_artifact().save(path)
        loaded = z.SchemaArtifact.load(path)
        assert loaded.apply(df).data.collect().equals(expected)
