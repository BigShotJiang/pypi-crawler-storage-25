"""
Unit tests for TableSchema class methods.

Tests schema creation, column management, and configuration methods.
"""

import polars as pl
import zeolite as z
from zeolite.schema._table import TableSchema
from zeolite.types import ProcessingSuccess


class TestSchemaCreation:
    """Tests for basic schema instantiation."""

    def test_schema_creation(self):
        """Test basic schema creation."""
        # Act
        schema = z.schema("test")

        # Assert
        assert isinstance(schema, TableSchema)
        assert schema._params.name == "test"


class TestColumnsMethod:
    """Tests for .columns() method."""

    def test_add_columns_basic_pipeline(self):
        """Test adding columns to schema."""
        # Arrange
        df = pl.DataFrame(
            {
                "id": ["001"],
                "name": ["Alice"],
                "age": [25],
            }
        )

        # Act
        schema = z.schema("test").columns(
            z.col.str("id"),
            z.col.str("name"),
            z.col.int("age"),
        )
        result = schema.apply(df)

        # Assert
        assert isinstance(result, ProcessingSuccess)
        assert result.data.collect().to_dict(as_series=False) == {
            "id": ["001"],
            "name": ["Alice"],
            "age": [25],
        }

    def test_columns_accept_dict_and_keyword_names(self):
        """Test unnamed columns can be named by dict keys and kwargs."""
        # Arrange
        df = pl.DataFrame(
            {
                "id": ["001"],
                "age": [25],
                "name": ["Alice"],
            }
        )

        # Act
        schema = z.schema("test").columns(
            {"id": z.col.str(), "age": z.col.int()},
            name=z.col.str(),
        )
        result = schema.apply(df)

        # Assert
        assert isinstance(result, ProcessingSuccess)
        assert result.data.collect().columns == ["id", "age", "name"]

    def test_columns_replace_discards_previous_columns(self):
        """Test method='replace' resets the schema columns."""
        # Arrange
        df = pl.DataFrame(
            {
                "legacy": ["old"],
                "id": ["001"],
            }
        )

        # Act
        schema = (
            z.schema("test")
            .columns(z.col.str("legacy"))
            .columns(z.col.str("id"), method="replace")
        )
        result = schema.apply(df)

        # Assert
        assert isinstance(result, ProcessingSuccess)
        assert result.data.collect().to_dict(as_series=False) == {"id": ["001"]}


class TestSchemaConfiguration:
    """Tests for schema configuration methods."""

    def test_optional_method(self):
        """Test .optional() method."""
        # Act
        schema = z.schema("test").optional()

        # Assert
        assert schema._params.is_required is False


class TestSchemaChaining:
    """Tests for method chaining."""

    def test_method_chaining(self):
        """Test chaining multiple configuration methods."""
        # Act
        schema = (
            z.schema("test")
            .strict(True)
            .optional()
            .columns(
                z.col.str("id"),
                z.col.str("name"),
            )
            .table_validation(z.TableCheck.min_rows(reject=1))
        )

        # Assert
        assert schema._params.strict is True
        assert schema._params.is_required is False
        assert len(schema._params.table_checks) == 1
        assert len(schema._params.registry.by_name) >= 2
