import polars as pl
from zeolite.schema._pipeline import Pipeline, PipelineParams
from zeolite.types import SourceColDef
from zeolite.types.validation.threshold import ThresholdLevel
from zeolite.schema.validation.variants import TableCheckRemovedRows


def _simple_inputs() -> PipelineParams:
    return PipelineParams(
        schema_name="test",
        is_required=True,
        stage=None,
        strict=True,
        coerce="default_true",
        source_columns=[
            SourceColDef(
                name="id",
                variants={"id"},
                if_missing=ThresholdLevel.REJECT,
                is_meta=False,
            ),
        ],
        prepare_stages=[],
        validation_rules=[],
        table_checks=[TableCheckRemovedRows(warning="any")],
        refined_columns={"id": "id"},
    )


def test_run_pipeline_returns_success():
    df = pl.DataFrame({"id": ["a", "b", "c"]})
    result = Pipeline.run(df, _simple_inputs())
    assert result.success
    assert result.data.collect()["id"].to_list() == ["a", "b", "c"]


def test_run_pipeline_drops_extra_columns():
    df = pl.DataFrame({"id": ["a"], "extra": [1]})
    result = Pipeline.run(df, _simple_inputs())
    assert result.success
    assert "extra" not in result.data.collect().columns


def test_run_pipeline_fails_on_missing_required_column():
    df = pl.DataFrame({"wrong": ["a"]})
    result = Pipeline.run(df, _simple_inputs())
    assert not result.success
    assert result.failed_stage == "normalise"
