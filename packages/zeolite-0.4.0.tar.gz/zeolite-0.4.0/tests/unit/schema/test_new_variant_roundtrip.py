"""Acceptance test for the variant-owned-serialisation refactor.

Defines a brand-new check variant inline (not in `src/`) and verifies it
round-trips through the spec without any edits to `spec.py`. This is the
contract the refactor is meant to deliver: adding a new variant should only
require declaring `SPEC`.
"""

from __future__ import annotations

from dataclasses import dataclass, replace
from typing import Optional

import polars as pl
import pytest
import zeolite as z
from zeolite.column.validation._base import BaseCheck, CheckSpec, _CheckParams
from zeolite.column.validation._utils.data_checks import ROW_VALIDATION_SUCCESS_VALUE
from zeolite.exceptions import SchemaConfigurationError
from zeolite.schema._utils.serialise.spec import decode_check, encode_check
from zeolite.types.validation.threshold import CheckThreshold


# --- New variant: `is_constant` ------------------------------------------------


@dataclass(frozen=True, kw_only=True)
class _IsConstantParams(_CheckParams):
    constant: int | float | str


class CheckIsConstant(BaseCheck):
    """Toy check: every row must equal a fixed constant."""

    _required_args = {"constant"}
    SPEC = CheckSpec(id="is_constant", params=_IsConstantParams)

    def __init__(
        self,
        constant: int | float | str,
        *,
        message: Optional[str] = None,
        warning: Optional[CheckThreshold] = None,
        error: Optional[CheckThreshold] = None,
        reject: Optional[CheckThreshold] = None,
        check_on_cleaned: bool = False,
        alias: str | None = None,
    ):
        super().__init__(
            message=message or "constant mismatch",
            warning=warning,
            error=error,
            reject=reject,
            check_on_cleaned=check_on_cleaned,
            alias=alias,
            label=f"{self.method_id()}_{constant}",
        )
        self._params = self._create_extended_params(
            _IsConstantParams, constant=constant
        )

    def expression(self, source_column: str, alias: str, fail_value="fail"):
        return (
            pl.when(pl.col(source_column).eq(self._params.constant))
            .then(pl.lit(ROW_VALIDATION_SUCCESS_VALUE))
            .otherwise(pl.lit(fail_value))
            .alias(alias)
        )


@dataclass(frozen=True, kw_only=True)
class _BrokenParams(_CheckParams):
    persisted: int = 0


class CheckBrokenDecode(BaseCheck):
    SPEC = CheckSpec(id="broken_decode_guard", params=_BrokenParams)

    def __init__(
        self,
        value: int,
        *,
        message: Optional[str] = None,
        warning: Optional[CheckThreshold] = None,
        error: Optional[CheckThreshold] = None,
        reject: Optional[CheckThreshold] = None,
        check_on_cleaned: bool = False,
        alias: str | None = None,
    ):
        super().__init__(
            message=message or "broken",
            warning=warning,
            error=error,
            reject=reject,
            check_on_cleaned=check_on_cleaned,
            alias=alias,
            label=f"{self.method_id()}_{value}",
        )
        self._params = self._create_extended_params(_BrokenParams)

    def expression(self, source_column: str, alias: str, fail_value="fail"):
        return pl.lit(ROW_VALIDATION_SUCCESS_VALUE).alias(alias)


# --- The acceptance test ------------------------------------------------------


def test_new_variant_round_trips_without_spec_edits():
    """End-to-end: define a variant outside src/, register it, embed it in a
    schema, run the schema → spec → schema → artifact pipeline, and verify
    behaviour is preserved. `spec.py` is never modified."""

    check = CheckIsConstant(42, error=0.5)
    encoded = encode_check(check, bound_column="x")
    assert encoded["check"] == "is_constant"
    assert encoded["params"] == {"constant": 42}

    decoded = decode_check(encoded)
    assert isinstance(decoded, CheckIsConstant)
    assert decoded.params.constant == 42
    assert decoded.params.thresholds.error == 0.5

    # And inside a full schema
    schema = z.schema("acc").columns(z.col.int("x").validations(check))
    rebuilt = schema.to_spec().to_table_schema()
    df = pl.DataFrame({"x": [42, 42, 1, 42]})
    out = rebuilt.apply(df)
    # Schema still applies cleanly post-roundtrip.
    assert out.data.collect().height == 4


def test_decode_rejects_variant_state_not_accepted_by_init():
    check = CheckBrokenDecode(1)
    check = check._set_params(replace(check.params, persisted=99))

    encoded = encode_check(check, bound_column="x")

    with pytest.raises(SchemaConfigurationError, match="persisted"):
        decode_check(encoded)
