import polars as pl
import pytest

import zeolite as z
from zeolite.exceptions import CheckConfigurationError
from zeolite.ref import ref


def _apply_nodes(df: pl.DataFrame, nodes):
    result = df
    for node in nodes:
        result = result.with_columns(node.expression)
    return result


def test_is_null_validation():
    df = pl.DataFrame({"source_col": [None, "", "   ", "abc", "0"]})

    chk = z.Check.is_null(warning="any")
    node = chk.get_validation_node(ref("source_col"))
    test_df = df.with_columns(node.expression)

    assert test_df[node.name].to_list() == ["pass", "pass", "pass", "fail", "fail"]


def test_is_null_validation_without_treating_empty_strings_as_null():
    df = pl.DataFrame({"source_col": [None, "", "abc"]})

    chk = z.Check.is_null(
        warning="any",
        treat_empty_strings_as_null=False,
    )
    node = chk.get_validation_node(ref("source_col"))
    test_df = df.with_columns(node.expression)

    assert test_df[node.name].to_list() == ["pass", "fail", "fail"]


def test_compound_any_expression():
    df = pl.DataFrame({"source_col": [None, "A", "C", "B"]})

    chk = z.Check.any(
        z.Check.is_null(),
        z.Check.is_in(["A", "B"]),
        warning="any",
    )
    nodes = chk.get_validation_nodes(ref("source_col"))
    test_df = _apply_nodes(df, nodes)

    assert len(nodes) == 3
    assert test_df[nodes[-1].name].to_list() == ["pass", "pass", "fail", "pass"]


def test_compound_or_alias_expression():
    df = pl.DataFrame({"source_col": [None, "A", "C", "B"]})

    chk = z.Check.or_(
        z.Check.is_null(),
        z.Check.is_in(["A", "B"]),
        warning="any",
    )
    nodes = chk.get_validation_nodes(ref("source_col"))
    test_df = _apply_nodes(df, nodes)

    assert len(nodes) == 3
    assert test_df[nodes[-1].name].to_list() == ["pass", "pass", "fail", "pass"]


def test_compound_all_expression():
    df = pl.DataFrame({"source_col": [5, -1, 4]})

    chk = z.Check.all(
        z.Check.equal_to(5),
        z.Check.greater_than(0),
        warning="any",
    )
    nodes = chk.get_validation_nodes(ref("source_col"))
    test_df = _apply_nodes(df, nodes)

    assert len(nodes) == 3
    assert test_df[nodes[-1].name].to_list() == ["pass", "fail", "fail"]


def test_compound_and_alias_expression():
    df = pl.DataFrame({"source_col": [5, -1, 4]})

    chk = z.Check.and_(
        z.Check.equal_to(5),
        z.Check.greater_than(0),
        warning="any",
    )
    nodes = chk.get_validation_nodes(ref("source_col"))
    test_df = _apply_nodes(df, nodes)

    assert len(nodes) == 3
    assert test_df[nodes[-1].name].to_list() == ["pass", "fail", "fail"]


def test_compound_xor_expression():
    df = pl.DataFrame({"source_col": [5, -1, 4]})

    chk = z.Check.xor(
        z.Check.equal_to(5),
        z.Check.greater_than(0),
        warning="any",
    )
    nodes = chk.get_validation_nodes(ref("source_col"))
    test_df = _apply_nodes(df, nodes)

    assert len(nodes) == 3
    assert test_df[nodes[-1].name].to_list() == ["fail", "fail", "pass"]


def test_compound_get_validation_nodes_returns_children_then_summary():
    chk = z.Check.any(
        z.Check.is_null(),
        z.Check.is_in(["A", "B"]),
        warning="any",
    )

    nodes = chk.get_validation_nodes(ref("source_col"))

    assert len(nodes) == 3
    assert chk.get_validation_node(ref("source_col")).name == nodes[-1].name
    assert all(node.expression is not None for node in nodes)


def test_compound_child_nodes_keep_original_names():
    child_a = z.Check.is_null()
    child_b = z.Check.is_in(["A", "B"])
    chk = z.Check.any(child_a, child_b, warning="any")

    child_a_node = child_a.get_validation_node(ref("source_col"))
    child_b_node = child_b.get_validation_node(ref("source_col"))
    nodes = chk.get_validation_nodes(ref("source_col"))

    assert nodes[0].name == child_a_node.name
    assert nodes[1].name == child_b_node.name


def test_compound_mixed_raw_and_cleaned_children():
    chk = z.Check.any(
        z.Check.is_null(),
        z.Check.is_null(check_on_cleaned=True),
        warning="any",
    )

    nodes = chk.get_validation_nodes(ref("source_col"))

    assert len(nodes) == 3
    assert "source_col" in nodes[0].name
    assert "__check__" in nodes[0].name
    assert "source_col" in nodes[1].name
    assert "__clean__check__" in nodes[1].name


def test_nulls_valid_replaces_nullable_compound_for_is_in():
    df = pl.DataFrame({"source_col": [None, "A", "C", "B"]})

    chk = z.Check.is_in(["A", "B"], nulls_valid=True, warning="any")
    nodes = chk.get_validation_nodes(ref("source_col"))
    test_df = _apply_nodes(df, nodes)

    assert len(nodes) == 1
    assert test_df[nodes[0].name].to_list() == ["pass", "pass", "fail", "pass"]


def test_compound_requires_at_least_two_checks():
    with pytest.raises(
        CheckConfigurationError,
        match="at least 2 child checks",
    ):
        z.Check.any(z.Check.is_null())


def test_compound_requires_check_children():
    with pytest.raises(
        CheckConfigurationError,
        match="only accept child BaseCheck instances",
    ):
        z.Check.any(z.Check.is_null(), "not-a-check")  # type: ignore[arg-type]


def test_compound_rejects_nested_compounds():
    with pytest.raises(
        CheckConfigurationError,
        match="Nested compound checks are not supported",
    ):
        z.Check.any(
            z.Check.any(z.Check.is_null(), z.Check.not_null()),
            z.Check.is_null(),
        )


def test_compound_allows_child_aliases():
    chk = z.Check.any(
        z.Check.is_null().alias("child_alias"),
        z.Check.not_null(),
        warning="any",
    )

    nodes = chk.get_validation_nodes(ref("source_col"))

    assert len(nodes) == 3
    assert nodes[0].alias == "child_alias"


def test_compound_check_on_cleaned_raises():
    chk = z.Check.any(
        z.Check.is_null(),
        z.Check.not_null(),
    )

    with pytest.raises(
        CheckConfigurationError,
        match="set it on each child check instead",
    ):
        chk.check_on_cleaned()
