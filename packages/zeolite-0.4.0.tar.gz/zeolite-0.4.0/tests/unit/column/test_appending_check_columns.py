import polars as pl
from zeolite.column.validation import Check
from zeolite.ref import ref


def test_not_null_validation():
    df = pl.DataFrame(
        {
            "source_col": [1, 2, None, 4],
        }
    )
    chk = Check.not_null(warning="any")
    node = chk.get_validation_node(ref("source_col"))
    test_df = df.with_columns(node.expression)

    expected = ["pass", "pass", "fail", "pass"]
    assert test_df[node.name].to_list() == expected


def test_not_null_validation_with_remove():
    df = pl.DataFrame(
        {
            "source_col": [1, 2, None, 4],
        }
    )
    chk = Check.not_null(warning="any").remove_row_on_fail()
    node = chk.get_validation_node(ref("source_col"))
    test_df = df.with_columns(node.expression)

    expected = ["pass", "pass", "reject", "pass"]
    assert test_df[node.name].to_list() == expected


def test_unique_validation():
    df = pl.DataFrame(
        {
            "source_col": [1, 2, 2, 3, 3, 4],
        }
    )
    chk = Check.unique(warning="any")
    node = chk.get_validation_node(ref("source_col"))
    test_df = df.with_columns(node.expression)

    expected = ["pass", "fail", "fail", "fail", "fail", "pass"]
    assert test_df[node.name].to_list() == expected


def test_equality_validation():
    df = pl.DataFrame(
        {
            "source_col": [1, 5, 3, 5, 7],
        }
    )
    chk = Check.equal_to(5, warning="any")
    node = chk.get_validation_node(ref("source_col"))
    test_df = df.with_columns(node.expression)

    expected = ["fail", "pass", "fail", "pass", "fail"]
    assert test_df[node.name].to_list() == expected


def test_string_pattern_validation():
    df = pl.DataFrame(
        {
            "source_col": ["abc", "123", "def", "456"],
        }
    )
    chk = Check.str_matches(r"^[A-Za-z]+$", warning="any")
    node = chk.get_validation_node(ref("source_col"))
    test_df = df.with_columns(node.expression)

    expected = ["pass", "fail", "pass", "fail"]
    assert test_df[node.name].to_list() == expected


def test_numeric_range_validation():
    df = pl.DataFrame(
        {
            "source_col": [1, 5, 11, 3, 8],
        }
    )
    chk = Check.between(1, 10, warning="any")
    node = chk.get_validation_node(ref("source_col"))
    test_df = df.with_columns(node.expression)

    expected = ["pass", "pass", "fail", "pass", "pass"]
    assert test_df[node.name].to_list() == expected


def test_in_list_validation():
    df = pl.DataFrame(
        {
            "source_col": [1, 4, 2, 5, 3],
        }
    )
    chk = Check.is_in([1, 2, 3], warning="any")
    node = chk.get_validation_node(ref("source_col"))
    test_df = df.with_columns(node.expression)

    expected = ["pass", "fail", "pass", "fail", "pass"]
    assert test_df[node.name].to_list() == expected
