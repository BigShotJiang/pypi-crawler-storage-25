import polars as pl

import zeolite as z
from zeolite.types import ProcessingSuccess


def _run_validate_stage(schema, df: pl.DataFrame):
    normalised = schema.step_1_normalise_table_structure(df)
    coerced = schema.step_2_coerce_datatypes(normalised.data)
    prepared = schema.step_3_prepare_additional_columns(coerced.data)
    validated = schema.step_4_validate_columns(prepared.data)
    return prepared, validated


def test_any_with_is_null_and_is_in():
    df = pl.DataFrame({"status": [None, "A", "B", "C", ""]})
    schema = z.schema("test").columns(
        z.col.str("status").validations(
            z.Check.any(
                z.Check.is_null(),
                z.Check.is_in(["A", "B"]),
                warning="any",
            )
        )
    )

    _, validated = _run_validate_stage(schema, df)

    assert len(validated.errors) == 1
    assert "status" in str(validated.errors[0]).lower()


def test_any_with_is_null_and_str_matches():
    df = pl.DataFrame({"status": [None, "AA-1", "INVALID", "AB-2"]})
    schema = z.schema("test").columns(
        z.col.str("status").validations(
            z.Check.any(
                z.Check.is_null(),
                z.Check.str_matches(r"^[A-Z]{2}-\d$"),
                warning="any",
            )
        )
    )

    _, validated = _run_validate_stage(schema, df)

    assert len(validated.errors) == 1
    assert "status" in str(validated.errors[0]).lower()


def test_raw_not_null_and_cleaned_is_null_compound_alias():
    df = pl.DataFrame({"date_text": ["2024-01-01", "bad-date", None]})
    schema = z.schema("test").columns(
        z.col.str("date_text")
        .clean(z.Clean.date())
        .validations(
            z.Check.all(
                z.Check.not_null(),
                z.Check.is_null(check_on_cleaned=True),
            ).alias("invalid_raw_date")
        )
    )

    result = schema.apply(df)

    assert isinstance(result, ProcessingSuccess)
    final_df = result.data.collect()
    assert final_df["invalid_raw_date"].to_list() == ["fail", "pass", "fail"]


def test_compound_summary_only_reporting():
    df = pl.DataFrame({"status": [None, "A", "C"]})
    schema = z.schema("test").columns(
        z.col.str("status").validations(
            z.Check.any(
                z.Check.is_null(),
                z.Check.is_in(["A", "B"]),
                warning="any",
            )
        )
    )

    _, validated = _run_validate_stage(schema, df)

    assert len(validated.errors) == 1


def test_compound_child_and_summary_reporting():
    df = pl.DataFrame({"status": ["A", "C", None]})
    schema = z.schema("test").columns(
        z.col.str("status").validations(
            z.Check.any(
                z.Check.is_null(),
                z.Check.is_in(["A", "B"]).warning("any"),
                warning="any",
            )
        )
    )

    _, validated = _run_validate_stage(schema, df)

    assert len(validated.errors) == 2


def test_compound_remove_row_on_fail_filters_invalid_rows():
    df = pl.DataFrame({"status": [None, "A", "C"]})
    schema = z.schema("test").columns(
        z.col.str("status").validations(
            z.Check.any(
                z.Check.is_null(),
                z.Check.is_in(["A", "B"]),
                warning="any",
                remove_row_on_fail=True,
            )
        )
    )

    result = schema.apply(df)

    assert isinstance(result, ProcessingSuccess)
    final_df = result.data.collect()
    assert final_df["status"].to_list() == [None, "A"]


def test_compound_alias_does_not_leak_child_nodes():
    df = pl.DataFrame({"status": [None, "A", "C"]})
    schema = z.schema("test").columns(
        z.col.str("status").validations(
            z.Check.any(
                z.Check.is_null(),
                z.Check.is_in(["A", "B"]),
                warning="any",
            ).alias("status_rule")
        )
    )

    result = schema.apply(df)

    assert isinstance(result, ProcessingSuccess)
    assert result.data.collect().columns == ["status", "status_rule"]


def test_single_check_nulls_valid_avoids_compound_columns():
    df = pl.DataFrame({"status": [None, "A", "C"]})
    schema = z.schema("test").columns(
        z.col.str("status").validations(
            z.Check.is_in(["A", "B"], nulls_valid=True, warning="any").alias(
                "status_rule"
            )
        )
    )

    result = schema.apply(df)

    assert isinstance(result, ProcessingSuccess)
    assert result.data.collect().columns == ["status", "status_rule"]


def test_compound_child_alias_persists_in_refined_output():
    df = pl.DataFrame({"status": [None, "A", "C"]})
    schema = z.schema("test").columns(
        z.col.str("status").validations(
            z.Check.any(
                z.Check.is_null().alias("status_is_null"),
                z.Check.is_in(["A", "B"]),
                warning="any",
            ).alias("status_rule")
        )
    )

    result = schema.apply(df)

    assert isinstance(result, ProcessingSuccess)
    assert result.data.collect().columns == ["status", "status_is_null", "status_rule"]
