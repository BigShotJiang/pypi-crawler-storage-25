"""Comprehensive coverage of the coerce stage (`step_2_coerce_datatypes`).

These test model input data which is already typed (or mistyped) and
the schema's `data_type` declaration alone forces Polars' `cast` via the
coerce stage. No `Clean` variants here.

Coverage:

* Every typed factory: `z.col.int / .float / .bool / .date / .datetime /
  .decimal / .time / .id / .temp`.
* Polars dtype objects via `data_type=`: `pl.Decimal(p, s)`,
  `pl.Datetime(time_unit, time_zone)`, `pl.UInt32`, `pl.Categorical`,
  `pl.Enum([...])`.
* `.data_type()` and `.coerce()` instance methods.
* All `CoerceOption` values: `default / coerce / strict / skip`.
* All `CoerceOverride` values: `default_true / default_strict /
  default_skip / force / force_strict / force_skip_all`.
* Strict failure → `ProcessingFailure` with `failed_stage="coerce"`.
* Derived columns bypass the coerce stage.

"""

from __future__ import annotations

import polars as pl
import pytest

import zeolite as z


# =============================================================================
# Shared fixture: typed input where dtypes deliberately mismatch the schemas
# =============================================================================


@pytest.fixture
def typed_input() -> pl.DataFrame:
    return pl.DataFrame(
        {
            "row_id": pl.Series([1, 2, 3, 4, 5], dtype=pl.Int32),
            "qty_small": pl.Series([10, 20, 30, 40, 50], dtype=pl.Int16),
            "qty_unsigned": pl.Series([1, 2, 3, 4, 5], dtype=pl.Int64),
            "ratio": pl.Series([1, 2, 3, 4, 5], dtype=pl.Int64),
            "is_active": pl.Series([1, 0, 1, 0, 1], dtype=pl.Int8),
            "event_date": pl.Series(
                ["2026-01-01", "2026-02-15", "2026-03-30", "2026-04-04", "2026-05-09"],
            ).str.to_date(),
            "event_ts_ns": pl.Series(
                [
                    "2026-01-01T00:00:00",
                    "2026-02-15T12:30:45",
                    "2026-03-30T08:15:00",
                    "2026-04-04T18:00:00",
                    "2026-05-09T23:59:59",
                ],
            ).str.to_datetime(time_unit="ns"),
            "unit_price": pl.Series([1.5, 2.25, 3.125, 4.0, 5.75], dtype=pl.Float64),
            "open_at": pl.Series(
                ["09:00:00", "09:30:00", "10:00:00", "10:30:00", "11:00:00"]
            ),
            "external_id": pl.Series(["abc-1", "abc-2", "abc-3", "abc-4", "abc-5"]),
            "region": pl.Series(["north", "south", "north", "east", "west"]),
            "status": pl.Series(["new", "open", "open", "closed", "new"]),
            "bad_int": pl.Series(["1", "2", "not_a_number", "4", "5"]),
        }
    )


# =============================================================================
# Helpers
# =============================================================================


def _errors_by_column(result, level: str | None = None) -> dict[str, list]:
    out: dict[str, list] = {}
    for err in result.errors:
        if level is not None and err.level != level:
            continue
        out.setdefault(err.column, []).append(err)
    return out


def _coerced_schema(result) -> dict[str, pl.DataType]:
    return dict(result.coerced.collect_schema())


def _refined_schema(result) -> dict[str, pl.DataType]:
    return dict(result.refined.collect_schema())


# =============================================================================
# 1. Typed factory shortcuts — every `z.col.<type>` gets coerced from a
#    mismatched input dtype.
# =============================================================================


def test_typed_factory_shortcuts_coerce_to_target_dtypes(typed_input):
    schema = z.schema("typed_factories", coerce="default_true").columns(
        z.col.int("row_id"),
        z.col.int("qty_small"),
        z.col.float("ratio"),
        z.col.bool("is_active"),
        z.col.date("event_date"),
        z.col.datetime("event_ts_ns"),
        z.col.decimal("unit_price"),
        z.col.time("open_at"),
        z.col.id("external_id"),
    )

    result = schema.apply(typed_input)
    assert result.success, result.errors

    coerced = _coerced_schema(result)
    assert coerced["row_id"] == pl.Int64
    assert coerced["qty_small"] == pl.Int64  # Int16 → Int64
    assert coerced["ratio"] == pl.Float64  # Int64 → Float64
    assert coerced["is_active"] == pl.Boolean  # Int8 → Boolean
    assert coerced["event_date"] == pl.Date
    # datetime shortcut → microsecond precision, no tz
    assert coerced["event_ts_ns"] == pl.Datetime(time_unit="us", time_zone=None)
    # decimal shortcut → Decimal(38, 2) (per get_polars_type)
    assert coerced["unit_price"] == pl.Decimal(precision=38, scale=2)
    # time/id columns are strings (no string→time auto-cast in coerce)
    assert coerced["open_at"] == pl.String
    assert coerced["external_id"] == pl.String

    # Each mismatched source column produces a `data_type_mismatch` warning.
    mismatched = {
        c
        for c, errs in _errors_by_column(result, level="warning").items()
        if any(e.error == "data_type_mismatch" for e in errs)
    }
    assert mismatched == {
        "row_id",
        "qty_small",
        "ratio",
        "is_active",
        "event_ts_ns",
        "unit_price",
    }


# =============================================================================
# 2. Polars dtype objects — shapes string shortcuts can't express.
# =============================================================================


def test_polars_dtype_objects_coerce_with_full_precision(typed_input):
    schema = z.schema("polars_dtypes", coerce="default_true").columns(
        z.col("qty_unsigned", data_type=pl.UInt32),
        z.col("unit_price", data_type=pl.Decimal(precision=12, scale=4)),
        z.col("event_ts_ns", data_type=pl.Datetime(time_unit="us", time_zone="UTC")),
        z.col("region", data_type=pl.Categorical),
        z.col("status", data_type=pl.Enum(["new", "open", "closed"])),
    )

    result = schema.apply(typed_input)
    assert result.success, result.errors

    coerced = _coerced_schema(result)
    assert coerced["qty_unsigned"] == pl.UInt32
    assert coerced["unit_price"] == pl.Decimal(precision=12, scale=4)
    assert coerced["event_ts_ns"] == pl.Datetime(time_unit="us", time_zone="UTC")
    assert coerced["region"] == pl.Categorical
    assert coerced["status"] == pl.Enum(["new", "open", "closed"])


# =============================================================================
# 3. `.data_type()` and `.coerce()` instance methods.
# =============================================================================


def test_data_type_and_coerce_instance_methods(typed_input):
    schema = z.schema("instance_methods").columns(
        # Start as int, promote to float via .data_type()
        z.col.int("ratio").data_type("float"),
        # Untyped → attach Polars dtype + strict coerce in one call
        z.col("unit_price").data_type(pl.Decimal(10, 2), coerce="strict"),
        # Start as int, then attach .coerce("skip") — wrong dtype passes through
        z.col.int("qty_small").coerce("skip"),
    )

    result = schema.apply(typed_input)
    assert result.success, result.errors

    coerced = _coerced_schema(result)
    assert coerced["ratio"] == pl.Float64
    assert coerced["unit_price"] == pl.Decimal(precision=10, scale=2)
    # skip honoured: input Int16 retained, no cast applied
    assert coerced["qty_small"] == pl.Int16

    # qty_small must NOT have a data_type_mismatch error (skip suppresses it)
    qty_warnings = [
        e
        for e in _errors_by_column(result).get("qty_small", [])
        if e.error == "data_type_mismatch"
    ]
    assert qty_warnings == []


# =============================================================================
# 4. Per-column CoerceOption literals.
# =============================================================================


def test_per_column_coerce_options(typed_input):
    schema = z.schema("coerce_options").columns(
        z.col.int("row_id", coerce="default"),
        z.col.float("ratio", coerce="coerce"),
        z.col.bool("is_active", coerce="strict"),
        z.col.int("qty_small", coerce="skip"),
    )

    result = schema.apply(typed_input)
    assert result.success, result.errors

    coerced = _coerced_schema(result)
    assert coerced["row_id"] == pl.Int64
    assert coerced["ratio"] == pl.Float64
    assert coerced["is_active"] == pl.Boolean
    assert coerced["qty_small"] == pl.Int16  # skip wins


# =============================================================================
# 5. Strict coercion failure → ProcessingFailure at coerce stage.
# =============================================================================


def test_strict_coerce_failure_rejects_pipeline(typed_input):
    schema = z.schema("strict_failure", coerce="default_strict").columns(
        z.col.int("bad_int"),
    )

    result = schema.apply(typed_input)
    assert not result.success
    assert result.failed_stage == "coerce"

    reject_errors = [e for e in result.errors if e.level == "reject"]
    assert len(reject_errors) == 1
    assert reject_errors[0].error == "failed_type_coercion"
    assert reject_errors[0].column == "bad_int"


# =============================================================================
# 6. Schema-level CoerceOverride literals.
#
#    Same column set per parametrise; the override is the only difference.
# =============================================================================


def _override_schema(override):
    return z.schema(f"ov_{override}", coerce=override).columns(
        z.col.int("row_id"),
        z.col.float("ratio").coerce("skip"),  # column says skip
        z.col.bool("is_active").coerce("strict"),  # column says strict
    )


def test_override_default_true_respects_per_column(typed_input):
    result = _override_schema("default_true").apply(typed_input)
    coerced = _coerced_schema(result)
    assert coerced["row_id"] == pl.Int64  # default_true: coerce
    assert coerced["ratio"] == pl.Int64  # column.skip wins
    assert coerced["is_active"] == pl.Boolean  # column.strict


def test_override_default_strict_promotes_to_strict(typed_input):
    result = _override_schema("default_strict").apply(typed_input)
    coerced = _coerced_schema(result)
    assert coerced["row_id"] == pl.Int64
    assert coerced["ratio"] == pl.Int64  # column.skip still wins over default
    assert coerced["is_active"] == pl.Boolean


def test_override_default_skip_disables_default_coercion(typed_input):
    result = _override_schema("default_skip").apply(typed_input)
    coerced = _coerced_schema(result)
    # row_id has no per-column coerce setting → default_skip leaves Int32
    assert coerced["row_id"] == pl.Int32
    assert coerced["ratio"] == pl.Int64  # skip
    # column.strict ("strict" maps specific_coerce=True) overrides default_skip
    assert coerced["is_active"] == pl.Boolean


def test_override_force_strict_overrides_per_column_skip(typed_input):
    result = _override_schema("force_strict").apply(typed_input)
    coerced = _coerced_schema(result)
    assert coerced["row_id"] == pl.Int64
    assert coerced["ratio"] == pl.Float64  # force_strict overrides column.skip
    assert coerced["is_active"] == pl.Boolean


def test_override_force_skip_all_short_circuits_stage(typed_input):
    result = _override_schema("force_skip_all").apply(typed_input)
    coerced = _coerced_schema(result)
    # No coercion at all — every column keeps its input dtype.
    assert coerced["row_id"] == pl.Int32
    assert coerced["ratio"] == pl.Int64
    assert coerced["is_active"] == pl.Int8

    # And no data_type_mismatch warnings should be emitted.
    mismatch_errors = [e for e in result.errors if e.error == "data_type_mismatch"]
    assert mismatch_errors == []


# =============================================================================
# 7. Derived columns bypass coercion entirely.
# =============================================================================


def test_derived_columns_bypass_coercion(typed_input):
    schema = z.schema("derived_bypass").columns(
        z.col.int("qty_unsigned"),
        z.col.float("ratio"),
        z.col.derived(
            "qty_times_ratio",
            function=pl.col("qty_unsigned") * pl.col("ratio"),
            data_type="integer",  # declared int, expression returns float
        ),
    )

    result = schema.apply(typed_input)
    assert result.success, result.errors

    refined = _refined_schema(result)
    # Source columns are coerced as declared.
    assert refined["qty_unsigned"] == pl.Int64
    assert refined["ratio"] == pl.Float64
    # Derived column dtype comes from the expression, NOT from `data_type=`.
    # (declared "integer" but expression is int*float → Float64)
    assert refined["qty_times_ratio"] == pl.Float64

    # And the derived column never appears in coerce-stage errors.
    derived_errors = [e for e in result.errors if e.column == "qty_times_ratio"]
    assert derived_errors == []


# =============================================================================
# 8. Temp columns + coerce.
#
#    Bug: temp columns are filtered out of _cols_to_sources, so the coerce
#    stage never sees them. Declared dtype/coerce are silently ignored.
# =============================================================================


def test_temp_columns_are_coerced_like_regular_columns(typed_input):
    """Temp columns flow through the coerce stage like any other source.

    Also exercises the class-form Polars dtype (`pl.Float32`, not
    `pl.Float32()`) — both forms should be accepted by `get_polars_type`.
    """
    schema = z.schema("temp_with_coerce").columns(
        z.col.temp("row_id", data_type="integer"),
        z.col.temp("ratio", data_type=pl.Float32, coerce="strict"),
        z.col.derived(
            "row_ratio",
            function=pl.col("row_id") * pl.col("ratio"),
            data_type="float",
        ),
    )

    result = schema.apply(typed_input)
    assert result.success, result.errors
    coerced = _coerced_schema(result)
    assert coerced["ratio"] == pl.Float32
    assert coerced["row_id"] == pl.Int64
