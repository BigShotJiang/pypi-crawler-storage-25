"""Round-trip safety net for the variant-owned-serialisation refactor.

Pins the invariants that matter semantically — `schema.to_artifact()` and
`schema.to_spec().to_table_schema().to_artifact()` must contain the same
columns, the same prepare-stage shape, the same validation rules, and the
same table checks.

We deliberately avoid byte-comparing serialised Polars expressions: their
binary fallback is non-deterministic even within a single process, so a
strict DeepDiff would be flaky.
"""

from __future__ import annotations

import sys
from pathlib import Path

import pytest

EXAMPLES_DIR = Path(__file__).resolve().parents[2] / "examples"


@pytest.fixture(scope="module")
def kitchen_sink_schema():
    sys.path.insert(0, str(EXAMPLES_DIR))
    try:
        from kitchen_sink import KitchenSinkSchema  # type: ignore[import-not-found]
    finally:
        sys.path.pop(0)
    return KitchenSinkSchema


def _shape(artifact_dict: dict) -> dict:
    """Reduce an artifact dict to its semantically-stable shape."""
    return {
        "schema": artifact_dict["schema"],
        "source_columns": sorted(
            (c["name"], tuple(sorted(c.get("variants", []))), c.get("dtype"))
            for c in artifact_dict["source_columns"]
        ),
        "prepare_stage_names": [
            sorted(e["name"] for e in stage)
            for stage in artifact_dict["prepare_stages"]
        ],
        "validation_rules": sorted(
            (r["check_id"], r["source_column"], r["check_column"])
            for r in artifact_dict["validation_rules"]
        ),
        "table_checks": sorted(c["check"] for c in artifact_dict["table_checks"]),
        "refined_columns": list(artifact_dict["refined_columns"]),
    }


def test_kitchen_sink_artifact_roundtrip_shape(kitchen_sink_schema):
    direct = _shape(kitchen_sink_schema.to_artifact().to_dict())
    roundtripped = _shape(
        kitchen_sink_schema.to_spec().to_table_schema().to_artifact().to_dict()
    )
    assert direct == roundtripped
