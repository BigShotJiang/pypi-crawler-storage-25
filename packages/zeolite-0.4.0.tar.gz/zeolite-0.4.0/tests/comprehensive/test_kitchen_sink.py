from __future__ import annotations

from copy import deepcopy
import sys
from pathlib import Path

import polars as pl
import pytest

EXAMPLES_DIR = Path(__file__).resolve().parents[2] / "examples"
sys.path.insert(0, str(EXAMPLES_DIR))
try:
    from kitchen_sink import KitchenSinkSchema  # type: ignore[import-not-found]
finally:
    sys.path.pop(0)


ROW_COUNT = 120


pytestmark = pytest.mark.comprehensive


def _valid_rows(row_count: int = ROW_COUNT) -> list[dict[str, str]]:
    rows = []
    for i in range(row_count):
        rows.append(
            {
                "source_system": ["web", "pos", "marketplace", "support_import"][i % 4],
                "source_file": "orders.csv",
                "ingested_at": "2026-04-27T10:00:00",
                "raw_row_number": str(i + 1),
                "customer_id": f"cust-{i:05d}",
                "customer_name": f"Customer {i:05d}",
                "email": f"customer{i:05d}@example.com",
                "phone": f"+64 21 555 {i % 10000:04d}",
                "support_contact": f"email:customer{i:05d}@example.com",
                "order_id": f"ord-{i:05d}",
                "order_status": "paid",
                "payment_method": "card",
                "preferred_contact_method": "email",
                "customer_segment": "retail",
                "country": "NZ",
                "postal_code": f"{6000 + (i % 1000):04d}",
                "order_date": "2026-04-20",
                "ship_date": "2026-04-21",
                "delivered_at": "2026-04-22T09:30:00",
                "order_time": "12:30:00",
                "handling_minutes": "45",
                "quantity": "2",
                "unit_price": "10.50",
                "discount_amount": "1.00",
                "tax_rate": "0.15",
                "gift_wrap": "yes",
                "loyalty_points": str(i),
                "coupon_code": f"SAVE-{i:05d}",
                "survey_score": "9",
                "internal_notes": "reviewed",
            }
        )
    return rows


def _valid_df(row_count: int = ROW_COUNT) -> pl.DataFrame:
    return pl.DataFrame(_valid_rows(row_count))


def _invalid_df() -> pl.DataFrame:
    rows = deepcopy(_valid_rows())

    for i in range(0, 7):
        rows[i]["source_system"] = "legacy"

    for i in range(7, 14):
        rows[i]["email"] = f"customer{i:05d}@example.invalid"
        rows[i]["support_contact"] = f"email:customer{i:05d}@example.invalid"

    for i in range(14, 21):
        rows[i]["unit_price"] = "60000.00"

    for i in range(21, 46):
        rows[i]["postal_code"] = "BAD"

    for i in range(46, 59):
        rows[i]["survey_score"] = "11"

    return pl.DataFrame(rows)


def _normalise_artifact_for_comparison(value):
    if isinstance(value, dict):
        if set(value) == {"format", "data"}:
            return {"expression": "<serialised-polars-expression>"}
        return {k: _normalise_artifact_for_comparison(v) for k, v in value.items()}
    if isinstance(value, list):
        return [_normalise_artifact_for_comparison(v) for v in value]
    return value


def _errors_by_column(result) -> dict[str, object]:
    return {error.column: error for error in result.errors if error.column is not None}


def test_schema_exports_spec():
    spec = KitchenSinkSchema.to_spec().to_dict()

    assert spec["version"] == "1"
    assert spec["name"] == "kitchen_sink"
    assert spec["stage"] == "bronze"
    assert len(spec["columns"]) == 41
    assert {check["check"] for check in spec["table_checks"]} == {
        "removed_rows",
        "min_rows",
    }


def test_schema_exports_artifact():
    artifact = KitchenSinkSchema.to_artifact().to_dict()

    assert artifact["schema"]["name"] == "kitchen_sink"
    assert artifact["schema"]["stage"] == "bronze"
    assert len(artifact["source_columns"]) == 30
    assert len(artifact["prepare_stages"]) >= 2
    assert len(artifact["validation_rules"]) == 53


def test_schema_spec_schema_artifact_matches_direct_artifact():
    direct = KitchenSinkSchema.to_artifact().to_dict()
    roundtripped = KitchenSinkSchema.to_spec().to_table_schema().to_artifact().to_dict()

    assert _normalise_artifact_for_comparison(roundtripped) == (
        _normalise_artifact_for_comparison(direct)
    )


def test_valid_fake_csv_data_processes_successfully():
    result = KitchenSinkSchema.apply(_valid_df(), source_name="valid-kitchen-sink.csv")

    assert result.success
    assert result.errors == []

    final_df = result.data.collect()
    assert final_df.height == ROW_COUNT
    assert "line_total" in final_df.columns
    assert "net_total" in final_df.columns
    assert "risk_band" in final_df.columns
    assert "raw_row_number" not in final_df.columns
    assert "import_row_number" not in final_df.columns
    assert "tax_rate_value" not in final_df.columns


def test_invalid_fake_csv_data_reports_expected_non_reject_levels():
    result = KitchenSinkSchema.apply(
        _invalid_df(), source_name="invalid-kitchen-sink.csv"
    )

    assert result.success
    assert {error.level for error in result.errors}.issubset(
        {"debug", "warning", "error"}
    )
    assert {error.source for error in result.errors} == {"invalid-kitchen-sink.csv"}

    errors = _errors_by_column(result)

    source_system_error = errors[
        "source_system___clean__check__is_in_[web...support_import]"
    ]
    assert source_system_error.error == "is_in"
    assert source_system_error.level == "warning"
    assert source_system_error.count_failed == 7

    email_error = errors["email___clean__check__email_not_invalid_tld"]
    assert email_error.error == "is_custom"
    assert email_error.level == "warning"
    assert email_error.count_failed == 7

    unit_price_error = errors["unit_price___clean__check__unit_price_reasonable"]
    assert unit_price_error.error == "is_between"
    assert unit_price_error.level == "error"
    assert unit_price_error.count_failed == 7

    postal_code_error = errors["derived__custom_check___valid_country_postal_code"]
    assert postal_code_error.error == "custom_validation"
    assert postal_code_error.level == "error"
    assert postal_code_error.count_failed == 25

    survey_score_error = errors["survey_score___clean__check__is_between_1_to_10"]
    assert survey_score_error.error == "is_between"
    assert survey_score_error.level == "warning"
    assert survey_score_error.count_failed == 13
