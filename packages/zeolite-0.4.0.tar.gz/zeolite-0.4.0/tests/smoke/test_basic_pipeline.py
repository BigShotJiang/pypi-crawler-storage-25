"""
Basic smoke tests for schema pipeline.

Tests that the pipeline succeeds for simple valid data and fails for a simple
schema mismatch.
"""

import polars as pl
import zeolite as z
from zeolite.types import ProcessingFailure, ProcessingSuccess


class TestBasicPipeline:
    """Basic smoke tests for pipeline functionality."""

    def test_single_row_passthrough(self):
        """Test processing single row with no transformations."""
        # Arrange
        df = pl.DataFrame(
            {
                "id": ["001"],
                "name": ["Alice"],
                "age": [25],
            }
        )

        schema = z.schema("test").columns(
            z.col.str("id"),
            z.col.str("name"),
            z.col.int("age"),
        )

        # Act
        result = schema.apply(df)

        # Assert
        assert isinstance(result, ProcessingSuccess)
        final_df = result.data.collect()
        assert final_df.shape[0] == 1
        assert final_df["id"][0] == "001"
        assert final_df["name"][0] == "Alice"
        assert final_df["age"][0] == 25

    def test_missing_required_column_fails(self):
        """Test processing fails when a required column is missing."""
        # Arrange
        df = pl.DataFrame(
            {
                "id": ["001"],
            }
        )

        schema = z.schema("test").columns(
            z.col.str("id"),
            z.col.str("name"),
        )

        # Act
        result = schema.apply(df)

        # Assert
        assert isinstance(result, ProcessingFailure)
        assert result.failed_stage == "normalise"
