# registry/

`ColumnRegistry` + dependency graph + execution-stage planner.

## STRUCTURE
- `__init__.py` — `ColumnRegistry`: stores `ColumnNode`s; `by_id` and `by_name` lookups; resolves parent IDs after each update
- `lineage.py` — `create_dependency_graph`: nodes + edges from registered columns
- `optimise_calc_stages.py` — `generate_optimized_stages`: topological sort → ordered list of parallel-executable stages
- `verify_registry.py` — DFS cycle detection + parent-mapping validation

## COLUMN-ID FORMAT
`[stage::schema]:::[prefix]:::[base_name]:::[suffix]`
- `:::` separates the four sections; `::` separates fields within a section
- prefix flags: `meta`, `derived`, `custom_check`
- suffix flags: `clean`, `check::{name}`
- Built/parsed in `_utils/column_id.py` (`make_column_id`, `parse_column_name_to_config`)
- Polars-safe column NAMES escape separators: `:::` → `___`, `::` → `__`

## EXECUTION-STAGE PLANNER
- Input: all registered `ColumnNode`s, filtered to calculated columns (cleans, derived, checks).
- Algorithm: Kahn's topological sort tracking in-degree.
- Output: `list[list[ColumnNode]]` — each inner list is independent and can be applied in one Polars `with_columns` call.
- Cycles raise; this is the only place cycles surface.

## PARENT RESOLUTION
- `ColumnNode.parent_columns` holds NAMES (user-facing); `parent_ids` holds resolved IDs.
- Resolution runs in `Registry._post_update()` via `by_name` lookup.
- Missing parents are **silently dropped** — don't rely on registration order failing loudly. Use `verify_registry.py` to surface gaps.