# schema/

Pipeline orchestration, table-level checks, schema serialisation. The 6 pipeline stages are described in root CLAUDE.md.

## STRUCTURE
- `_table.py` — `TableSchema`, the user-facing API; binds columns + table checks to the pipeline
- `_pipeline.py` — `Pipeline` class; static methods per stage, each takes a LazyFrame + `PipelineParams` and returns a `ValidationResult(stage, data, errors, reject)`
- `_spec.py` — `SchemaSpec` dataclass: serialisable representation of a schema
- `_artifact.py` — `SchemaArtifact`: pipeline output container (data + metadata + errors)
- `validation/_base.py` — `BaseTableCheck`, `_TableCheckParams`
- `validation/variants/` — `_removed_rows.py`, `_min_rows.py`
- `_utils/coerce_types.py`, `_utils/normalise.py` — stage helpers
- `_utils/serialise/` — JSON round-trip for schemas (added in 3cec7ee)

## TABLE CHECK CONTRACT (`validation/variants/`)
Differs from column checks: table checks operate on whole LazyFrames, not row expressions.

- Subclass `BaseTableCheck`. Params dataclass: `_TableCheckParams` (label, thresholds, message) — no `remove_row_on_fail`, no `check_on_cleaned`.
- Declare `SPEC = TableCheckSpec(id=..., params=_TableCheckParams)` on each concrete table check. This drives method id, decode lookup, and auto-registration.
- Implement `validate(validated_lf, filtered_lf, schema_name, source) -> DataValidationError | None`.
  - Receives BOTH the pre-filter and post-filter LazyFrames; compare counts/aggregates across them.
- `TableCheckMinRows` rejects fractional thresholds; converts integer `1` to `"any"` internally and serialises counts back out via its `to_spec`.

## SERIALISE PACKAGE (`_utils/serialise/`)
Round-trips a full `SchemaSpec` (cleans + checks + derived cols + table checks) to JSON.

- `spec.py` — top-level `encode_*` / `decode_*` for spec components
- `common.py` — primitive serialisers: Polars `Expr` (binary→base64 or JSON), dtype, `Threshold`, `ColumnRef`
- `artifact.py` — `SchemaArtifact` ↔ JSON
- `_decode_registry.py` — imports built-in variant modules so each class' `SPEC` auto-registers in `CLEAN_VARIANTS` / `CHECK_VARIANTS` / `TABLE_CHECK_VARIANTS`.

## CONVENTIONS
- `VALIDATION_CHECK_COL` (`validation__check__ROW_PASSED`) is the marker column added in `validate_columns`; table checks rely on it for the filtered/unfiltered split.
- Thresholds are immutable; builder methods return new instances via `dataclasses.replace`.
- Stage methods on `Pipeline` are static — no instance state. Pass everything via `PipelineParams`.
- Schema definitions must use `pl.Expr` only — no Python callables (they don't serialise).
