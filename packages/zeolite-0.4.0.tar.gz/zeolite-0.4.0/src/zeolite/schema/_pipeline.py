from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING, Optional

import polars as pl
from polars.exceptions import ColumnNotFoundError, ShapeError

from ._utils.coerce_types import coerce_column_types, CoerceOverride
from ._utils.normalise import normalise_column_headers
from ..types import (
    SourceColDef,
    ThresholdLevel,
    ValidationResult,
    ProcessingFailure,
    ProcessingSuccess,
    StructureValidationError,
    TableValidationError,
    ProcessingStage,
)
from .validation.variants import VALIDATION_CHECK_COL

if TYPE_CHECKING:
    from ..types.validation.validation_rule import ColumnValidationRule
    from .validation.variants import TableCheckType


@dataclass(frozen=True)
class PrepareEntry:
    name: str
    expression: pl.Expr


@dataclass(frozen=True)
class PipelineParams:
    schema_name: str
    is_required: bool
    stage: Optional[str]
    strict: bool
    coerce: CoerceOverride
    source_columns: list[SourceColDef]
    prepare_stages: list[list[PrepareEntry]]
    validation_rules: list["ColumnValidationRule"]
    table_checks: list["TableCheckType"]
    refined_columns: dict[str, str]  # alias → actual column name


class Pipeline:
    @staticmethod
    def normalise(
        df: pl.LazyFrame | pl.DataFrame,
        inputs: PipelineParams,
        *,
        source_name: str | None = None,
    ) -> ValidationResult:
        return normalise_column_headers(
            df.lazy(),
            col_defs=inputs.source_columns,
            schema_name=inputs.schema_name,
            source_name=source_name,
        )

    @staticmethod
    def coerce(
        df: pl.LazyFrame | pl.DataFrame,
        inputs: PipelineParams,
        *,
        source_name: str | None = None,
    ) -> ValidationResult:
        return coerce_column_types(
            df.lazy(),
            schema_name=inputs.schema_name,
            col_defs=inputs.source_columns,
            source_name=source_name,
            coerce_override=inputs.coerce,
        )

    @staticmethod
    def prepare(
        df: pl.LazyFrame | pl.DataFrame,
        inputs: PipelineParams,
        *,
        source_name: Optional[str],
    ) -> ValidationResult:
        lf = df.lazy()
        errors = []
        try:
            for stage in inputs.prepare_stages:
                lf = lf.with_columns([entry.expression for entry in stage])

            # We collect the first 2 rows to validate the LazyFrame is executable.
            # This catches empty datasets and chunk boundary bugs that only manifest when processing multiple chunks (https://github.com/pola-rs/polars/issues/25500)
            # If it's invalid it will raise an error that we handle further down
            is_empty = lf.limit(2).collect().is_empty()
            if is_empty:
                errors.append(
                    StructureValidationError(
                        schema=inputs.schema_name,
                        source=source_name,
                        error="empty_data",
                        level=ThresholdLevel.REJECT.level,
                        message=f"`{inputs.schema_name}` has no data after attempting to add columns.",
                    )
                )

        except ColumnNotFoundError as e:
            errors.append(
                StructureValidationError(
                    schema=inputs.schema_name,
                    source=source_name,
                    error="column_not_found",
                    level=ThresholdLevel.REJECT.level,
                    message=f"polars.exceptions.ColumnNotFoundError: {e}",
                )
            )
        except ShapeError as e:
            errors.append(
                StructureValidationError(
                    schema=inputs.schema_name,
                    source=source_name,
                    error="shape_error",
                    level=ThresholdLevel.REJECT.level,
                    message=f"polars.exceptions.ShapeError: {e}",
                    # message=(
                    #     f"polars.exceptions.ShapeError: {e}. This is a known Polars bug with "
                    #     "timezone-aware datetime literals on multi-chunk DataFrames. "
                    #     "Workaround: call .rechunk() on your DataFrame before applying the schema, "
                    #     "or use pl.scan_parquet().collect().rechunk() for LazyFrames."
                    # ),
                )
            )
        except Exception as e:
            errors.append(
                StructureValidationError(
                    schema=inputs.schema_name,
                    source=source_name,
                    error="unknown",
                    level=ThresholdLevel.REJECT.level,
                    message=f"{e}",
                )
            )
        reject = any(e.level == ThresholdLevel.REJECT.level for e in errors)
        return ValidationResult(stage="prepare", data=lf, errors=errors, reject=reject)

    @staticmethod
    def validate_columns(
        df: pl.LazyFrame | pl.DataFrame,
        inputs: PipelineParams,
        *,
        source_name: Optional[str],
    ) -> ValidationResult:
        lf = df.lazy()
        errors = []
        reject = False
        rejectable_columns: list[str] = []

        if inputs.validation_rules:
            failure_count_columns = {
                f"__zeolite_failed_rows_{index}": rule
                for index, rule in enumerate(inputs.validation_rules)
            }
            checks = lf.select(
                pl.len().alias("__zeolite_total_rows"),
                *[
                    rule.failure_count_expr(alias)
                    for alias, rule in failure_count_columns.items()
                ],
            ).collect()
            total_rows = checks["__zeolite_total_rows"].item()
        else:
            failure_count_columns = {}
            checks = {}
            total_rows = 0

        for alias, rule in failure_count_columns.items():
            failed_rows = checks[alias].item()
            check = rule.validate_counts(
                total_rows=total_rows,
                failed_rows=failed_rows,
                source=source_name,
            )
            if check is not None:
                errors.append(check)
                if check.level == ThresholdLevel.REJECT.level:
                    reject = True
            if rule.remove_row_on_fail:
                rejectable_columns.append(rule.check_column)

        if rejectable_columns:
            lf_with_reject_col = lf.with_columns(
                (
                    ~pl.any_horizontal(
                        *[
                            pl.col(r).ne(ThresholdLevel.PASS.level)
                            for r in rejectable_columns
                        ]
                    )
                ).alias(VALIDATION_CHECK_COL)
            )
        else:
            lf_with_reject_col = lf.with_columns(
                pl.lit(True).alias(VALIDATION_CHECK_COL)
            )

        return ValidationResult(
            stage="validate", data=lf_with_reject_col, errors=errors, reject=reject
        )

    @staticmethod
    def validate_table(
        df: pl.LazyFrame | pl.DataFrame,
        inputs: PipelineParams,
        *,
        source_name: Optional[str],
    ) -> ValidationResult:
        lf = df.lazy()
        filtered = lf.filter(pl.col(VALIDATION_CHECK_COL))
        errors = []
        reject = False

        if inputs.table_checks:
            counts = lf.select(
                pl.len().alias("__zeolite_total_rows"),
                pl.col(VALIDATION_CHECK_COL).sum().alias("__zeolite_filtered_rows"),
            ).collect()
            total_rows = counts["__zeolite_total_rows"].item()
            filtered_rows = counts["__zeolite_filtered_rows"].item()
        else:
            total_rows = 0
            filtered_rows = 0

        for check in inputs.table_checks:
            result = check.validate_counts(
                total_rows=total_rows,
                filtered_rows=filtered_rows,
                schema_name=inputs.schema_name,
                source=source_name,
            )
            if result:
                errors.append(result)
                if result.level == ThresholdLevel.REJECT.level:
                    reject = True

        return ValidationResult(
            stage="filter", data=filtered, errors=errors, reject=reject
        )

    @staticmethod
    def refine(
        df: pl.LazyFrame | pl.DataFrame,
        inputs: PipelineParams,
        *,
        source_name: Optional[str],
    ) -> ValidationResult:
        lf = df.lazy()
        try:
            refined = lf.select(
                *[
                    pl.col(col_name).alias(alias)
                    for alias, col_name in inputs.refined_columns.items()
                ]
            )
            return ValidationResult(
                stage="refine", data=refined, errors=[], reject=False
            )
        except Exception as e:
            return ValidationResult(
                stage="refine",
                data=lf,
                errors=[
                    TableValidationError(
                        message="Fatal error refining to final schema",
                        schema=inputs.schema_name,
                        level="reject",
                        error=f"{e}",
                        source=source_name,
                    )
                ],
                reject=True,
            )

    @staticmethod
    def run(
        df: pl.LazyFrame | pl.DataFrame,
        inputs: PipelineParams,
        *,
        source_name: Optional[str] = None,
    ) -> ProcessingFailure | ProcessingSuccess:
        errors = []
        failed_stage: Optional[ProcessingStage] = None
        normalised = Pipeline.normalise(df, inputs, source_name=source_name)
        errors.extend(normalised.errors)
        if normalised.reject:
            failed_stage: ProcessingStage = normalised.stage
            if inputs.strict:
                return ProcessingFailure(
                    normalised=normalised.data,
                    coerced=None,
                    prepared=None,
                    validated=None,
                    filtered=None,
                    refined=None,
                    data=None,
                    errors=errors,
                    failed_stage=failed_stage,
                )
        coerced = Pipeline.coerce(normalised.data, inputs, source_name=source_name)
        errors.extend(coerced.errors)
        if coerced.reject:
            failed_stage: ProcessingStage = (
                coerced.stage if failed_stage is None else failed_stage
            )
            if inputs.strict:
                return ProcessingFailure(
                    normalised=normalised.data,
                    coerced=coerced.data,
                    prepared=None,
                    validated=None,
                    filtered=None,
                    refined=None,
                    data=None,
                    errors=errors,
                    failed_stage=failed_stage,
                )

        prepped = Pipeline.prepare(coerced.data, inputs, source_name=source_name)
        errors.extend(prepped.errors)
        if prepped.reject:
            failed_stage: ProcessingStage = (
                prepped.stage if failed_stage is None else failed_stage
            )
            if inputs.strict:
                return ProcessingFailure(
                    normalised=normalised.data,
                    coerced=coerced.data,
                    prepared=prepped.data,
                    validated=None,
                    filtered=None,
                    refined=None,
                    data=None,
                    errors=errors,
                    failed_stage=failed_stage,
                )

        valid = Pipeline.validate_columns(prepped.data, inputs, source_name=source_name)
        errors.extend(valid.errors)
        if valid.reject:
            failed_stage: ProcessingStage = (
                valid.stage if failed_stage is None else failed_stage
            )
            if inputs.strict:
                return ProcessingFailure(
                    normalised=normalised.data,
                    coerced=coerced.data,
                    prepared=prepped.data,
                    validated=valid.data,
                    filtered=None,
                    refined=None,
                    data=None,
                    errors=errors,
                    failed_stage=failed_stage,
                )

        filtered = Pipeline.validate_table(valid.data, inputs, source_name=source_name)
        errors.extend(filtered.errors)
        if filtered.reject:
            failed_stage: ProcessingStage = (
                filtered.stage if failed_stage is None else failed_stage
            )
            if inputs.strict:
                return ProcessingFailure(
                    normalised=normalised.data,
                    coerced=coerced.data,
                    prepared=prepped.data,
                    validated=valid.data,
                    filtered=filtered.data,
                    refined=None,
                    data=None,
                    errors=errors,
                    failed_stage=failed_stage,
                )

        refined = Pipeline.refine(filtered.data, inputs, source_name=source_name)
        errors.extend(refined.errors)

        if filtered.reject or failed_stage is not None:
            return ProcessingFailure(
                normalised=normalised.data,
                coerced=coerced.data,
                prepared=prepped.data,
                validated=valid.data,
                filtered=filtered.data,
                refined=refined.data,
                data=None,
                errors=errors,
                failed_stage=refined.stage if failed_stage is None else failed_stage,
            )

        return ProcessingSuccess(
            normalised=normalised.data,
            coerced=coerced.data,
            prepared=prepped.data,
            validated=valid.data,
            filtered=filtered.data,
            refined=refined.data,
            data=refined.data,
            errors=errors,
        )
