from __future__ import annotations

import copy
import json
from pathlib import Path
from typing import TYPE_CHECKING

from ._pipeline import Pipeline, PipelineParams, PrepareEntry
from .._utils.serialise.common import (
    serialize_expr,
    deserialize_expr,
    encode_table_check,
    decode_table_check,
)
from ._utils.serialise.artifact import (
    encode_source_col_def,
    decode_source_col_def,
    encode_validation_rule,
    decode_validation_rule,
)
from ..types import ProcessingFailure, ProcessingSuccess

if TYPE_CHECKING:
    from polars import LazyFrame, DataFrame
    from ._table import TableSchema

ARTIFACT_VERSION = "1"
ARTIFACT_SUFFIX = ".zeo"


class SchemaArtifact:
    def __init__(self, data: dict) -> None:
        self._data = data

    # ------------------------------------------------------------------
    # Construction
    # ------------------------------------------------------------------

    @classmethod
    def from_schema(cls, schema: "TableSchema") -> "SchemaArtifact":
        inputs = schema._params.compiled.pipeline_params
        data = {
            "version": ARTIFACT_VERSION,
            "schema": {
                "name": schema._params.name,
                "is_required": schema._params.is_required,
                "stage": schema._params.stage,
                "strict": schema._params.strict,
                "coerce": schema._params.coerce,
            },
            "source_columns": [
                encode_source_col_def(scd) for scd in inputs.source_columns
            ],
            "prepare_stages": [
                [
                    {"name": e.name, "expression": serialize_expr(e.expression)}
                    for e in stage
                ]
                for stage in inputs.prepare_stages
            ],
            "validation_rules": [
                encode_validation_rule(rule) for rule in inputs.validation_rules
            ],
            "table_checks": [
                encode_table_check(check) for check in inputs.table_checks
            ],
            "refined_columns": inputs.refined_columns,
        }
        return cls(data)

    @classmethod
    def from_dict(cls, data: dict) -> "SchemaArtifact":
        if data.get("version") != ARTIFACT_VERSION:
            raise ValueError(f"Unsupported artifact version: {data.get('version')!r}")
        return cls(data)

    @classmethod
    def load(cls, path: str | Path) -> "SchemaArtifact":
        p = Path(path)
        if p.suffix != ARTIFACT_SUFFIX:
            raise ValueError(
                f"Artifact path must have a {ARTIFACT_SUFFIX!r} suffix, got {p.suffix!r}"
            )
        # Artifact files are trusted input — dtype strings are eval'd during apply().
        # Do not load artifacts from untrusted sources.
        return cls.from_dict(json.loads(p.read_text()))

    # ------------------------------------------------------------------
    # Export
    # ------------------------------------------------------------------

    def to_dict(self) -> dict:
        return copy.deepcopy(self._data)

    def save(self, path: str | Path) -> None:
        p = Path(path)
        if p.suffix != ARTIFACT_SUFFIX:
            raise ValueError(
                f"Artifact path must have a {ARTIFACT_SUFFIX!r} suffix, got {p.suffix!r}"
            )
        p.write_text(json.dumps(self._data))

    # ------------------------------------------------------------------
    # Apply
    # ------------------------------------------------------------------

    def apply(
        self, df: "LazyFrame | DataFrame", *, source_name: str | None = None
    ) -> ProcessingFailure | ProcessingSuccess:
        return Pipeline.run(df, self._to_pipeline_inputs(), source_name=source_name)

    def _to_pipeline_inputs(self) -> PipelineParams:
        d = self._data
        schema = d["schema"]
        return PipelineParams(
            schema_name=schema["name"],
            is_required=schema["is_required"],
            stage=schema["stage"],
            strict=schema["strict"],
            coerce=schema["coerce"],
            source_columns=[decode_source_col_def(s) for s in d["source_columns"]],
            prepare_stages=[
                [
                    PrepareEntry(
                        name=e["name"], expression=deserialize_expr(e["expression"])
                    )
                    for e in stage
                ]
                for stage in d["prepare_stages"]
            ],
            validation_rules=[decode_validation_rule(r) for r in d["validation_rules"]],
            table_checks=[decode_table_check(c) for c in d["table_checks"]],
            refined_columns=d["refined_columns"],
        )
