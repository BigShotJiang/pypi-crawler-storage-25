from __future__ import annotations

from importlib import import_module

from ....column._clean._base import CleanColumn
from ....column.validation._base import BaseCheck
from ...validation._base import BaseTableCheck


for module in (
    "zeolite.column._clean._boolean",
    "zeolite.column._clean._custom",
    "zeolite.column._clean._date",
    "zeolite.column._clean._enum",
    "zeolite.column._clean._id",
    "zeolite.column._clean._number",
    "zeolite.column._clean._string",
    "zeolite.column.validation.variants._compound",
    "zeolite.column.validation.variants._custom",
    "zeolite.column.validation.variants._date",
    "zeolite.column.validation.variants._equality",
    "zeolite.column.validation.variants._in_list",
    "zeolite.column.validation.variants._null",
    "zeolite.column.validation.variants._number",
    "zeolite.column.validation.variants._string",
    "zeolite.column.validation.variants._unique",
    "zeolite.schema.validation.variants._min_rows",
    "zeolite.schema.validation.variants._removed_rows",
):
    import_module(module)


CLEAN_VARIANTS: dict[str, type[CleanColumn]] = CleanColumn._registry
CHECK_VARIANTS: dict[str, type[BaseCheck]] = BaseCheck._registry
TABLE_CHECK_VARIANTS: dict[str, type[BaseTableCheck]] = BaseTableCheck._registry

COMPOUND_CHECK_IDS = frozenset(k for k, c in CHECK_VARIANTS.items() if c._is_compound())
