from __future__ import annotations

from ....types import SourceColDef
from ....types.validation.validation_rule import ColumnValidationRule
from ...._utils.serialise.common import (
    encode_dtype,
    decode_dtype,
    encode_threshold,
    decode_threshold,
    encode_threshold_level,
    decode_threshold_level,
)


# ------------------------------------------------------------------
# Source column definitions
# ------------------------------------------------------------------
def encode_source_col_def(scd: SourceColDef) -> dict:
    return {
        "name": scd.name,
        "variants": sorted(scd.variants),
        "if_missing": encode_threshold_level(scd.if_missing),
        "is_meta": scd.is_meta,
        "dtype": encode_dtype(scd.dtype),
        "coerce": scd.coerce,
    }


def decode_source_col_def(data: dict) -> SourceColDef:
    return SourceColDef(
        name=data["name"],
        variants=frozenset(data["variants"]),
        if_missing=decode_threshold_level(data["if_missing"]),
        is_meta=data["is_meta"],
        dtype=decode_dtype(data["dtype"]),
        coerce=data.get("coerce"),
    )


# ------------------------------------------------------------------
# Validation rules
# ------------------------------------------------------------------
def encode_validation_rule(rule: ColumnValidationRule) -> dict:
    return {
        "check_id": rule.check_id,
        "thresholds": encode_threshold(rule.thresholds),
        "message": rule.message,
        "source_column": rule.source_column,
        "check_column": rule.check_column,
        "schema": rule.schema,
        "remove_row_on_fail": rule.remove_row_on_fail,
    }


def decode_validation_rule(data: dict) -> ColumnValidationRule:
    return ColumnValidationRule(
        check_id=data["check_id"],
        thresholds=decode_threshold(data["thresholds"]),
        message=data["message"],
        source_column=data["source_column"],
        check_column=data["check_column"],
        schema=data["schema"],
        remove_row_on_fail=data["remove_row_on_fail"],
    )
