from __future__ import annotations

from ...._utils.serialise.helpers import EncodeContext as _EncodeContext, encode_value
from ....exceptions import SchemaConfigurationError
from ....ref import ColumnRef
from ....types.sensitivity import Sensitivity
from ._decode_registry import CHECK_VARIANTS, CLEAN_VARIANTS
from ...._utils.serialise.common import (
    deserialize_expr,
    encode_dtype,
    encode_threshold_level,
    serialize_expr,
)


def _decode_sensitivity(value: str | None) -> Sensitivity | None:
    return None if value is None else Sensitivity(value)


# ------------------------------------------------------------------
# Clean encoding/decoding
# ------------------------------------------------------------------


def encode_clean(clean, *, bound_column: str | None = None) -> dict:
    out = clean.to_spec(_EncodeContext(bound_column=bound_column))
    out["method"] = clean.__class__.__name__
    return out


def decode_clean(data: dict):
    method = data["method"]
    if method not in CLEAN_VARIANTS:
        raise SchemaConfigurationError(f"Unknown clean variant in spec: {method!r}")
    cls = CLEAN_VARIANTS[method]
    return cls.from_spec(data)


# ------------------------------------------------------------------
# Check encoding/decoding
# ------------------------------------------------------------------
def encode_check(
    check,
    *,
    bound_column: str | None = None,
    bound_column_cleaned: str | None = None,
) -> dict:
    return check.to_spec(
        _EncodeContext(
            bound_column=bound_column, bound_column_cleaned=bound_column_cleaned
        )
    )


def decode_check(data: dict):
    check_id = data["check"]
    if check_id not in CHECK_VARIANTS:
        raise SchemaConfigurationError(f"Unknown check variant in spec: {check_id!r}")
    cls = CHECK_VARIANTS[check_id]
    return cls.from_spec(data)


# ------------------------------------------------------------------
# Column encoding
# ------------------------------------------------------------------
def encode_col(col) -> dict:
    if col.ref.is_derived:
        return _encode_derived_col(col)
    return _encode_source_col(col)


def _encode_derived_col(col) -> dict:
    ref = col.ref
    p = col.params
    return {
        "kind": "derived",
        "name": ref.base_name,
        "type": p.type_label,
        "dtype": encode_dtype(p.dtype),
        "coerce": p.coerce,
        "sensitivity": p.sensitivity.value if p.sensitivity else None,
        "temporary": p.is_temporary,
        "alias": col.get_alias(),
        "expression": serialize_expr(p.expression)
        if p.expression is not None
        else None,
        "validations": [encode_check(v, bound_column=ref.name) for v in p.validations],
        "custom_validation": _encode_custom_validation(p.custom_validation),
    }


def _encode_source_col(col) -> dict:
    ref = col.ref
    p = col.params
    return {
        "kind": "meta" if ref.is_meta else "source",
        "name": ref.base_name,
        "type": p.type_label,
        "dtype": encode_dtype(p.dtype),
        "coerce": p.coerce,
        "if_missing": encode_threshold_level(p.if_missing),
        "variants": sorted(col.get_variants),
        "sensitivity": p.sensitivity.value if p.sensitivity else None,
        "temporary": p.is_temporary,
        "alias": col.get_alias(),
        "clean": encode_clean(p.clean, bound_column=ref.name)
        if p.clean is not None
        else None,
        "validations": [
            encode_check(
                v,
                bound_column=ref.name,
                bound_column_cleaned=ref.clean().name,
            )
            for v in p.validations
        ],
        "custom_validation": _encode_custom_validation(p.custom_validation),
    }


def _encode_custom_validation(cv) -> dict | None:
    if cv is None:
        return None
    return {k: encode_value(v) for k, v in cv.items()}


def decode_col(data: dict):
    from ....column._base import Col

    name = data["name"]
    type_label = data["type"]
    coerce = data.get("coerce", "default")
    sens = _decode_sensitivity(data.get("sensitivity"))
    temporary = data.get("temporary", False)
    kind = data["kind"]

    if kind == "derived":
        cv = data.get("custom_validation")
        expr_data = data.get("expression")
        if cv is not None:
            if expr_data is None:
                raise SchemaConfigurationError(
                    f"Custom-check column {name!r} is missing its expression."
                )
            col = Col(
                col_ref=ColumnRef(name).custom_check(),
                data_type=type_label,
                sensitivity=sens,
            ).custom_check(
                deserialize_expr(expr_data),
                thresholds=cv.get("thresholds"),
                message=cv.get("message", ""),
                remove_row_on_fail=cv.get("remove_row_on_fail", False) or False,
            )
            if temporary:
                col = col.temporary(True)
            return col

        validations = [decode_check(v) for v in data.get("validations") or []]
        col = Col(
            col_ref=ColumnRef(name).derived(),
            data_type=type_label,
            coerce=coerce,
            sensitivity=sens,
            validations=validations,
            temporary=temporary,
        )
        if expr_data is not None:
            col = col.derived(deserialize_expr(expr_data))
        return col

    is_meta = kind == "meta"
    optional = data.get("if_missing", "reject")
    clean_data = data.get("clean")
    clean = decode_clean(clean_data) if clean_data is not None else None
    validations = [decode_check(v) for v in data.get("validations") or []]
    return Col(
        col_ref=ColumnRef(name, is_meta=is_meta),
        data_type=type_label,
        coerce=coerce,
        sensitivity=sens,
        variants=set(data.get("variants") or []),
        optional=optional,
        validations=validations,
        clean=clean,
        temporary=temporary,
    )
