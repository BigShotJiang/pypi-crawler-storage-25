import copy
from dataclasses import dataclass, field, replace
from typing import TYPE_CHECKING, Literal, Optional
from collections.abc import Iterable

import polars as pl

from ._compiler import (
    OutputColumnInfo,
    _CompiledSchema,
    _compile_schema,
)
from ._pipeline import Pipeline
from ._utils.coerce_types import CoerceOverride
from .validation.variants import TableCheckRemovedRows
from ..types import (
    SourceColDef,
    ValidationResult,
    ProcessingFailure,
    ProcessingSuccess,
)
from ..exceptions import SchemaConfigurationError
from ..column import Col

if TYPE_CHECKING:
    from .validation.variants import TableCheckType
    from ._spec import SchemaSpec
    from ._artifact import SchemaArtifact


@dataclass(frozen=True, kw_only=True)
class _SchemaParams:
    name: str
    is_required: bool = False
    stage: Optional[str] = None
    strict: bool = True
    coerce: CoerceOverride = "default_true"
    table_checks: list["TableCheckType"] = field(default_factory=list)
    columns: list[Col] = field(default_factory=list)  # original Col list for to_spec()
    compiled: _CompiledSchema | None = None

    @property
    def registry(self):
        return self.compiled.registry

    @property
    def source_columns(self):
        return self.compiled.source_columns

    @property
    def refined_columns(self):
        return self.compiled.refined_columns


class TableSchema:
    """
    Defines a table schema for data validation and processing.

    Parameters:
        name (str): Name of the schema.
        columns (List[ColumnSchema] | dict[str, ColumnSchema], optional): List of column schemas.
        optional (bool): Whether the schema is optional or required.
        stage (str, optional): Processing stage.

    Usage:
        demo_schema = z.schema("demo", columns=[...])
    """

    def __init__(
        self,
        name: str,
        columns: Iterable[Col] | dict[str, Col] | None = None,
        *,
        optional: bool = False,
        stage: Optional[str] = None,
        strict: bool = True,
        coerce: CoerceOverride = "default_true",
        table_validations: Iterable["TableCheckType"] | None = None,
    ):
        cols = _parse_columns_into_list(columns)
        table_checks = (
            list(table_validations)
            if table_validations
            else [TableCheckRemovedRows(warning="any")]
        )
        self._params = _build_schema_params(
            name=name,
            is_required=not optional,
            stage=stage,
            strict=strict,
            coerce=coerce,
            table_checks=table_checks,
            columns=cols,
        )

    def columns(
        self,
        *args: Col | Iterable[Col] | dict[str, Col],
        method: Literal["merge", "replace"] = "merge",
        **kwargs: Col,
    ) -> "TableSchema":
        """Add or replace columns in the schema.

        Args:
            *args: ColumnSchema objects, lists of ColumnSchema, or dicts mapping names to ColumnSchema
            method: Either "merge" to add to existing columns or "replace" to replace all columns
            **kwargs: Named ColumnSchema objects where the key is the column name

        Returns:
            TableSchema: A new schema with the updated columns
        """
        cols = _parse_columns_into_list(*args, **kwargs)
        if method == "merge":
            return self._replace(
                columns=list(self._params.columns) + cols,
            )
        elif method == "replace":
            return self._replace(columns=cols)
        else:
            raise SchemaConfigurationError(f"Invalid method: {method}")

    def optional(self, optional: bool = True) -> "TableSchema":
        """Set the schema as required"""
        return self._replace(is_required=not optional)

    def strict(self, strict: bool = True) -> "TableSchema":
        """Set the schema to strict mode"""
        return self._replace(strict=strict)

    def coerce(self, coerce: CoerceOverride) -> "TableSchema":
        """Set the coercion mode for the schema"""
        return self._replace(coerce=coerce)

    def table_validation(
        self, *checks: "TableCheckType | Iterable[TableCheckType]"
    ) -> "TableSchema":
        """
        Configure table-level validation checks.

        Table checks validate aggregate properties of the output data,
        such as how many rows were removed or minimum row count requirements.

        Args:
            *checks: BaseTableCheck instances

        Returns:
            TableSchema: A new schema with table validation checks configured

        Examples:
            # Reject if more than 40% of rows removed
            schema.table_validation(
                z.TableCheck.removed_rows(reject=0.4)
            )

            # Multiple checks
            schema.table_validation(
                z.TableCheck.removed_rows(warning=0.2, error=0.3, reject=0.5),
                z.TableCheck.min_rows(reject=10)
            )
        """
        from .validation import BaseTableCheck

        for check in checks:
            if not isinstance(check, BaseTableCheck):
                raise SchemaConfigurationError(
                    f"All table checks must be TableCheck instances, got {type(check)}"
                )

        return self._replace(table_checks=list(checks))

    @property
    def name(self) -> str:
        """Get the name of the table schema"""
        return self._params.name

    @property
    def is_required(self) -> bool:
        """Get the required status of the table schema"""
        return self._params.is_required

    @property
    def stage(self) -> str | None:
        """Get the stage of the table schema"""
        return self._params.stage

    @property
    def input_columns(self) -> tuple[SourceColDef, ...]:
        """Get read-only metadata for source columns accepted by this schema."""
        return self._params.compiled.input_column_info

    @property
    def output_columns(self) -> tuple[OutputColumnInfo, ...]:
        """Get read-only metadata for final output columns produced by this schema."""
        return self._params.compiled.output_column_info

    def lineage(self):
        """Return dependency lineage as copied plain graph data."""
        return copy.deepcopy(self._params.compiled.registry.lineage())

    # def registry_nodes(self) -> tuple[RegistryNodeInfo, ...]:
    #     """Return read-only metadata for internal registry nodes."""
    #     return self._params.compiled.registry_node_info

    def step_1_normalise_table_structure(
        self, df: pl.LazyFrame | pl.DataFrame, *, source_name: str | None = None
    ) -> ValidationResult:
        """
        Normalises the provided Polars LazyFrame to ensure column headers align with the
        defined schema/column definitions. It will attempt to rename columns based on
        the column variants, if column headers are missing it will add them, and drop any
        additional column not defined in the schema.

        Args:
            df (pl.LazyFrame | pl.DataFrame): The Polars LazyFrame or DataFrame to be normalised.
            source_name (str | None): Optional name of the source for populating error messages.

        Returns:
            ValidationResult: The result of the normalization process, including the
            normalised lazy frame and any errors encountered during the process.

        """
        return Pipeline.normalise(
            df, self._params.compiled.pipeline_params, source_name=source_name
        )

    def step_2_coerce_datatypes(
        self, df: pl.LazyFrame | pl.DataFrame, *, source_name: str | None = None
    ) -> ValidationResult:
        """
        Coerces the data types of the columns in the provided Polars LazyFrame (lf) to match the
        defined schema/column definitions. This function uses the column definitions to determine
        the expected data types and applies the necessary coercions to the LazyFrame.

        Args:
            df (pl.LazyFrame | pl.DataFrame): The Polars LazyFrame or DataFrame to be coerced.
            source_name (str | None): Optional name of the source for populating error messages.

        Returns:
            ValidationResult: The result of the coercion process, including the
            coerced lazy frame and any errors encountered during the process.
        """
        return Pipeline.coerce(
            df, self._params.compiled.pipeline_params, source_name=source_name
        )

    def step_3_prepare_additional_columns(
        self, df: pl.LazyFrame | pl.DataFrame, *, source_name: str | None = None
    ) -> ValidationResult:
        """
        Applies optimized transformations to the provided Polars LazyFrame (lf). This function
        uses the column definitions to create cleaned & derived/calculated columns, and creates
        check columns based on the validation rules defined for each column.

        Args:
            df (pl.LazyFrame | pl.DataFrame): The Polars LazyFrame or DataFrame to be processed.
            source_name (str | None): Optional name of the source for populating error messages.

        Returns:
            ValidationResult: The result of the preparation process, including the
            processed LazyFrame and any errors encountered during the process.
        """
        return Pipeline.prepare(
            df, self._params.compiled.pipeline_params, source_name=source_name
        )

    def step_4_validate_columns(
        self, df: pl.LazyFrame | pl.DataFrame, *, source_name: str | None = None
    ) -> ValidationResult:
        """
        Applies validation rules to the provided Polars LazyFrame (lf) based on the column definitions.
        This uses the check columns created in step 2 and applies the validation thresholds to determine
        the resulting validation status/level. The returned LazyFrame isn't modified, but should only be used
        if the entire validation process succeeds without any `reject` level errors.

        Args:
            df (pl.LazyFrame | pl.DataFrame): The Polars LazyFrame or DataFrame to be validated.
            source_name (str | None): Optional name of the source for populating error messages.

        Returns:
            ValidationResult: The result of the validation process, including the
            validated LazyFrame and any errors encountered during the process.
        """
        return Pipeline.validate_columns(
            df, self._params.compiled.pipeline_params, source_name=source_name
        )

    def step_5_validate_and_filter_table(
        self, df: pl.LazyFrame | pl.DataFrame, *, source_name: str | None = None
    ) -> ValidationResult:
        """
        Drop rows that failed validation and evaluate table-level checks.

        This step:
        1. Filters out rows marked for removal (via VALIDATION_CHECK_COL)
        2. Counts total rows and rows removed
        3. Evaluates table-level validation checks against these metrics
        4. Returns rejection if any table check reaches reject threshold

        Args:
            df (pl.LazyFrame | pl.DataFrame): The Polars LazyFrame or DataFrame with validation columns.
            source_name (str | None): Optional name of the source for populating error messages.

        Returns:
            ValidationResult: The result with filtered data and any table validation errors.
        """
        return Pipeline.validate_table(
            df, self._params.compiled.pipeline_params, source_name=source_name
        )

    def step_6_refine_structure(
        self, df: pl.LazyFrame | pl.DataFrame, *, source_name: str | None = None
    ):
        """
        Refines the schema to a final state by:

        - replacing original columns with clean columns (unless the Clean definition was given an `alias`)
        - dropping the check columns used in validation (unless the Check definition was given an `alias`)
        - renaming derived/calculated columns to remove prefix

        Args:
            df (pl.LazyFrame | pl.DataFrame): The Polars LazyFrame or DataFrame from the filter stage.
            source_name (str | None): Optional name of the source for populating error messages.

        Returns:
            ValidationResult: The result of the refinement process, including the
            tidy LazyFrame and any errors encountered during the process.
        """
        return Pipeline.refine(
            df, self._params.compiled.pipeline_params, source_name=source_name
        )

    def apply(
        self, df: pl.LazyFrame | pl.DataFrame, *, source_name: str | None = None
    ) -> ProcessingFailure | ProcessingSuccess:
        """
        Applies the schema to the DataFrame/LazyFrame and processes data through multiple stages:

        `normalisation -> preparation -> validation -> filtering -> refinement`

        Each stage processes the input data and checks for errors. If any stage fails,
        the process aborts (in 'strict' mode), returning the stage results and a failure status. If all stages
        are successful, the method returns a success status with all intermediate and final
        results.

        Args:
            df (pl.LazyFrame | pl.DataFrame): Polars LazyFrame or DataFrame containing the data to be processed.
            source_name (str | None): Optional name of the source for populating error messages.

        Returns:
            ProcessingResult: If any stage (`normalise`, `prepare`, `validate`, `filter`, `refine`) fails with a `reject`,
            returns a `ProcessingFailure` containing intermediate results, encountered errors, and
            the name of the failed stage. Otherwise, returns a `ProcessingSuccess` containing
            intermediate and final results, as well as collected errors during processing.
        """
        return Pipeline.run(
            df, self._params.compiled.pipeline_params, source_name=source_name
        )

    def to_spec(self) -> "SchemaSpec":
        from ._spec import SchemaSpec

        return SchemaSpec.from_schema(self)

    def to_artifact(self) -> "SchemaArtifact":
        from ._artifact import SchemaArtifact

        return SchemaArtifact.from_schema(self)

    def _replace(self, **kwargs):
        params = replace(self._params, **kwargs)
        new_params = _build_schema_params(
            name=params.name,
            is_required=params.is_required,
            stage=params.stage,
            strict=params.strict,
            coerce=params.coerce,
            table_checks=params.table_checks,
            columns=params.columns,
        )
        return TableSchema.__new__(TableSchema).__set_params(new_params)

    def __set_params(self, params: _SchemaParams) -> "TableSchema":
        self._params = params
        return self


def _build_schema_params(
    *,
    name: str,
    is_required: bool,
    stage: str | None,
    strict: bool,
    coerce: CoerceOverride,
    table_checks: list["TableCheckType"],
    columns: list[Col],
) -> _SchemaParams:
    compiled = _compile_schema(
        name=name,
        is_required=is_required,
        stage=stage,
        strict=strict,
        coerce=coerce,
        table_checks=table_checks,
        columns=columns,
    )
    return _SchemaParams(
        name=name,
        is_required=is_required,
        stage=stage,
        strict=strict,
        coerce=coerce,
        table_checks=table_checks,
        columns=columns,
        compiled=compiled,
    )


def _parse_columns_into_list(
    *args: Col | Iterable[Col] | dict[str, Col] | None,
    **kwargs: Col,
) -> list[Col]:
    cols = []
    # Process positional arguments
    for arg in args:
        if arg is None:
            continue
        if isinstance(arg, dict):
            # Handle dict input like {a: z.col, b: z.col}
            cols.extend(c.with_name(k) for k, c in arg.items())
        elif isinstance(arg, list):
            # Handle list input like [z.col("a"), z.col("b")]
            cols.extend(arg)
        else:
            # Handle single ColumnSchema like z.col("a")
            cols.append(arg)

    # Process keyword arguments
    cols.extend(c.with_name(k) for k, c in kwargs.items())

    return cols
