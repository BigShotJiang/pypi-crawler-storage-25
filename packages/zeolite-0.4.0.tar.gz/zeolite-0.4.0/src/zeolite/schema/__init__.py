from ._table import TableSchema
from ._spec import SchemaSpec
from ._artifact import SchemaArtifact
from .validation.variants import VALIDATION_CHECK_COL


schema = TableSchema
"""
Defines a table schema for data validation and processing.

Parameters:
    name (str): Name of the schema.
    columns (List[ColumnSchema] | dict[str, ColumnSchema], optional): List of column schemas.
    is_required (bool): Whether the schema is required.
    stage (str, optional): Processing stage.

Example:
    demo_schema = z.schema("demo", columns=[...])
"""


__all__ = [
    "TableSchema",
    "schema",
    "VALIDATION_CHECK_COL",
    "SchemaSpec",
    "SchemaArtifact",
]
