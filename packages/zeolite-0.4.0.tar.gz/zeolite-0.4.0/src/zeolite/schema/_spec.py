from __future__ import annotations

import copy
import json
from pathlib import Path
from typing import TYPE_CHECKING

from .._utils.serialise.common import encode_table_check
from ._utils.serialise.spec import encode_col

if TYPE_CHECKING:
    from ._table import TableSchema
    from ._artifact import SchemaArtifact

SPEC_VERSION = "1"


class SchemaSpec:
    def __init__(self, data: dict, _schema=None) -> None:
        self._data = data
        self._schema_ref = (
            _schema  # set only when created from_schema(); None when loaded from file
        )

    # ------------------------------------------------------------------
    # Construction
    # ------------------------------------------------------------------

    @classmethod
    def from_schema(cls, schema: "TableSchema") -> "SchemaSpec":
        data = {
            "version": SPEC_VERSION,
            "name": schema._params.name,
            "optional": not schema._params.is_required,
            "stage": schema._params.stage,
            "strict": schema._params.strict,
            "coerce": schema._params.coerce,
            "columns": [encode_col(c) for c in schema._params.columns],
            "table_checks": [
                encode_table_check(tc) for tc in schema._params.table_checks
            ],
        }
        return cls(data, _schema=schema)

    @classmethod
    def load(cls, path: str | Path) -> "SchemaSpec":
        return cls(json.loads(Path(path).read_text()))

    # ------------------------------------------------------------------
    # Export
    # ------------------------------------------------------------------

    def to_dict(self) -> dict:
        return copy.deepcopy(self._data)

    def save(self, path: str | Path) -> None:
        Path(path).write_text(json.dumps(self._data, indent=2))

    # ------------------------------------------------------------------
    # Decode back to a TableSchema
    # ------------------------------------------------------------------

    def to_table_schema(self) -> "TableSchema":
        from .._utils.serialise.common import decode_table_check
        from ._table import TableSchema
        from ._utils.serialise.spec import decode_col

        d = self._data
        return TableSchema(
            d["name"],
            columns=[decode_col(c) for c in d["columns"]],
            optional=d.get("optional", False),
            stage=d.get("stage"),
            strict=d.get("strict", True),
            coerce=d.get("coerce", "default_true"),
            table_validations=[
                decode_table_check(t) for t in d.get("table_checks", [])
            ],
        )

    # ------------------------------------------------------------------
    # Compile to artifact
    # ------------------------------------------------------------------

    def compile(self) -> "SchemaArtifact":
        from ._artifact import SchemaArtifact

        if self._schema_ref is None:
            self._schema_ref = self.to_table_schema()
        return SchemaArtifact.from_schema(self._schema_ref)
