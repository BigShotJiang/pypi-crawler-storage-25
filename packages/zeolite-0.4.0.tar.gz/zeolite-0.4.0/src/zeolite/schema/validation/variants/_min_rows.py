from typing import TYPE_CHECKING, Optional
import polars as pl

from .._base import BaseTableCheck, TableCheckSpec, _TableCheckParams
from ....exceptions import InvalidThresholdError
from ....types.validation.threshold import ThresholdLevel

if TYPE_CHECKING:
    from polars import LazyFrame
    from ....types.error import TableValidationError


class TableCheckMinRows(BaseTableCheck):
    SPEC = TableCheckSpec(id="min_rows", params=_TableCheckParams)

    """
    Check if output has minimum required number of rows.

    Only supports absolute count-based thresholds (>1), not fractions.

    Examples:
        # Reject if output has fewer than 10 rows
        z.TableCheck.min_output_rows(reject=10)

        # Multiple levels
        z.TableCheck.min_output_rows(warning=100, error=50, reject=10)
    """

    def __init__(
        self,
        *,
        message: str = "Table requires at least {{target}} rows, but only has {{total}}",
        debug: Optional[int] = None,
        warning: Optional[int] = None,
        error: Optional[int] = None,
        reject: Optional[int] = None,
    ):
        # For min_output_rows, we only support count-based thresholds
        converted_thresholds = {}

        for key, val in [
            ("debug", debug),
            ("warning", warning),
            ("error", error),
            ("reject", reject),
        ]:
            if val is not None:
                # Check if it's a fraction (0-1) which we don't support
                if isinstance(val, float) and 0 < val <= 1:
                    raise InvalidThresholdError(
                        f"min_output_rows does not support fraction thresholds. "
                        f"Use integer counts only. Got {key}={val}"
                    )
                # Also reject special keywords that don't make sense
                if isinstance(val, str) and val in ["any", "all"]:
                    raise InvalidThresholdError(
                        f"min_output_rows does not support '{val}'. "
                        f"Use integer counts only."
                    )

                # Convert 1 to "any" since Threshold doesn't allow 1
                # For min_output_rows(reject=1), this means "at least 1 row"
                if val == 1:
                    converted_thresholds[key] = "any"
                else:
                    converted_thresholds[key] = val

        super().__init__(message=message, **converted_thresholds)

    def validate(
        self,
        validated_lf: "LazyFrame",
        filtered_lf: "LazyFrame",
        *,
        schema_name: str,
        source: str | None = None,
    ) -> "TableValidationError | None":
        """Evaluate if output has minimum required rows"""
        total_rows = filtered_lf.select(pl.len()).collect().item()
        return self.validate_counts(
            total_rows=total_rows,
            filtered_rows=total_rows,
            schema_name=schema_name,
            source=source,
        )

    def validate_counts(
        self,
        *,
        total_rows: int,
        filtered_rows: int,
        schema_name: str,
        source: str | None = None,
    ) -> "TableValidationError | None":
        """Evaluate if output has minimum required rows from precomputed counts."""
        from ....types.error import TableValidationError

        for level in sorted(ThresholdLevel, key=lambda x: x.priority, reverse=True):
            if level == ThresholdLevel.PASS:
                continue

            # Access the internal _thresholds dict to get count values
            fraction, min_row_target = self._params.thresholds._thresholds.get(
                level, (None, None)
            )

            # We should only have count-based thresholds (validated in __init__)
            if fraction is not None and fraction != 0:
                raise InvalidThresholdError(
                    "min_output_rows does not support fraction thresholds. "
                    "This should have been caught during initialization."
                )

            if min_row_target is not None and filtered_rows < min_row_target:
                shortage = min_row_target - filtered_rows

                return TableValidationError(
                    schema=schema_name,
                    source=source,
                    error=self.method_id(),
                    level=level.level,
                    count_failed=shortage,
                    fraction_failed=None,
                    message=self._format_message(
                        filtered_rows,
                        filtered_rows,
                        target=min_row_target,
                    ),
                )

        return None

    def to_spec(self, ctx=None) -> dict:
        """Recover original integer counts from the Threshold internal map.
        `__init__` converts `1` to `"any"` and validates non-fractional input,
        so we read counts back out rather than the fraction slot."""
        d: dict = {"check": self.method_id(), "message": self._params.message}
        t = self._params.thresholds
        for level in ThresholdLevel:
            if level == ThresholdLevel.PASS:
                continue
            pair = t._thresholds.get(level)
            if pair is not None:
                _, count = pair
                if count is not None:
                    d[level.level] = count
        return d
