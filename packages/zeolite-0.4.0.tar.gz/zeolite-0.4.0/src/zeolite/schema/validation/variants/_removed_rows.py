from typing import TYPE_CHECKING, Optional

import polars as pl

from .._base import BaseTableCheck, TableCheckSpec, _TableCheckParams
from ....types.validation.threshold import CheckThreshold

if TYPE_CHECKING:
    from polars import LazyFrame
    from ....types.error import TableValidationError


VALIDATION_CHECK_COL = "validation__check__ROW_PASSED"


class TableCheckRemovedRows(BaseTableCheck):
    SPEC = TableCheckSpec(id="removed_rows", params=_TableCheckParams)

    """
    Check if too many rows were removed during validation.

    Supports both fraction-based and count-based thresholds:
    - Fractions (0-1): Percentage of input rows that were removed
    - Counts (>1): Absolute number of rows removed

    Examples:
        # Reject if more than 40% of rows removed
        z.TableCheck.removed(reject=0.4)

        # Reject if more than 100 rows removed
        z.TableCheck.removed(reject=100)

        # Multiple levels
        z.TableCheck.removed(warning=0.2, error=0.3, reject=0.5)

        # Reject if ALL rows removed
        z.TableCheck.removed(reject="all")
    """

    row_check_col: Optional[str]

    def __init__(
        self,
        *,
        message: str = "Removed {{count}} rows ({{fraction}}) for failing validation",
        row_check_col: Optional[str] = VALIDATION_CHECK_COL,
        thresholds=None,
        debug: Optional[CheckThreshold] = None,
        warning: Optional[CheckThreshold] = None,
        error: Optional[CheckThreshold] = None,
        reject: Optional[CheckThreshold] = None,
    ):
        self.row_check_col = row_check_col
        super().__init__(
            message,
            thresholds=thresholds,
            debug=debug,
            warning=warning,
            error=error,
            reject=reject,
        )

    def validate(
        self,
        validated_lf: "LazyFrame",
        filtered_lf: "LazyFrame",
        *,
        schema_name: str,
        source: str | None = None,
    ) -> "TableValidationError | None":
        """Evaluate if too many rows were removed"""
        total_rows = validated_lf.select(pl.len()).collect().item()
        filtered_row = filtered_lf.select(pl.len()).collect().item()
        return self.validate_counts(
            total_rows=total_rows,
            filtered_rows=filtered_row,
            schema_name=schema_name,
            source=source,
        )

    def validate_counts(
        self,
        *,
        total_rows: int,
        filtered_rows: int,
        schema_name: str,
        source: str | None = None,
    ) -> "TableValidationError | None":
        from ....types.error import TableValidationError

        removed_rows = total_rows - filtered_rows

        if removed_rows == 0:
            return None

        res = self._params.thresholds.resolve(
            failed_rows=removed_rows, total_rows=total_rows
        )

        if res.level == "pass":
            return None

        return TableValidationError(
            schema=schema_name,
            source=source,
            error=self.method_id(),
            level=res.level,
            fraction_failed=res.fraction_failed,
            count_failed=res.count_failed,
            message=self._format_message(removed_rows, total_rows),
        )
