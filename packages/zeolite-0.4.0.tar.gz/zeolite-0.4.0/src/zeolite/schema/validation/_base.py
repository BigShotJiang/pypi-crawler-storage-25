from dataclasses import dataclass, replace, asdict
from typing import TYPE_CHECKING, ClassVar, Optional, TypeVar

from ..._utils.serialise.helpers import TableCheckSpec
from ...types.validation.threshold import Threshold, CheckThreshold
from ...exceptions import InvalidThresholdError, TableCheckConfigurationError

if TYPE_CHECKING:
    from polars import LazyFrame
    from ...types.error import TableValidationError


type ThresholdType = Threshold | dict[str, CheckThreshold] | None


@dataclass(frozen=True, kw_only=True)
class _TableCheckParams:
    label: str
    thresholds: Threshold
    message: str = ""


_T = TypeVar("_T", bound="_TableCheckParams")


def _get_threshold(
    *,
    thresholds: ThresholdType = None,
    debug: Optional[CheckThreshold] = None,
    warning: Optional[CheckThreshold] = None,
    error: Optional[CheckThreshold] = None,
    reject: Optional[CheckThreshold] = None,
) -> Threshold:
    """Create a Threshold object from various input formats"""
    if thresholds is not None:
        if isinstance(thresholds, Threshold):
            return thresholds
        elif isinstance(thresholds, dict):
            return Threshold(**thresholds)
        else:
            raise InvalidThresholdError(f"Invalid thresholds type: {type(thresholds)}")
    else:
        # Create from individual parameters
        kwargs = {}
        if debug is not None:
            kwargs["debug"] = debug
        if warning is not None:
            kwargs["warning"] = warning
        if error is not None:
            kwargs["error"] = error
        if reject is not None:
            kwargs["reject"] = reject

        if not kwargs:
            raise InvalidThresholdError(
                "At least one of `thresholds`, `debug`, `warning`, `error`, or `reject` must be provided"
            )

        return Threshold(**kwargs)


class BaseTableCheck:
    """Base class for table-level validation checks"""

    _registry: ClassVar[dict[str, type["BaseTableCheck"]]] = {}
    _required_args: set[str] = set()
    SPEC: ClassVar[TableCheckSpec] = TableCheckSpec(params=_TableCheckParams)

    def __init_subclass__(cls, **kwargs):
        super().__init_subclass__(**kwargs)
        spec = cls.__dict__.get("SPEC")
        if cls is not BaseTableCheck and spec is not None and spec.id is not None:
            BaseTableCheck._registry[spec.id] = cls

    def __init__(
        self,
        message: str = "",
        thresholds: ThresholdType = None,
        debug: Optional[CheckThreshold] = None,
        warning: Optional[CheckThreshold] = None,
        error: Optional[CheckThreshold] = None,
        reject: Optional[CheckThreshold] = None,
        label: Optional[str] = None,
    ):
        self._params = _TableCheckParams(
            message=message,
            thresholds=_get_threshold(
                thresholds=thresholds,
                debug=debug,
                warning=warning,
                error=error,
                reject=reject,
            ),
            label=label or self.method_id(),
        )

    @classmethod
    def method_id(cls) -> str:
        """Unique identifier for this check type"""
        return cls.SPEC.id or "__table_check_base__"

    @property
    def params(self) -> _TableCheckParams:
        return self._params

    def thresholds(
        self,
        *,
        debug: Optional[CheckThreshold] = None,
        warning: Optional[CheckThreshold] = None,
        error: Optional[CheckThreshold] = None,
        reject: Optional[CheckThreshold] = None,
        thresholds: Optional[ThresholdType] = None,
        message: Optional[str] = None,
    ):
        """Configure thresholds for this check"""
        if (
            (thresholds is None)
            and (debug is None)
            and (warning is None)
            and (error is None)
            and (reject is None)
        ):
            raise InvalidThresholdError(
                "At least one of `thresholds`, `debug`, `warning`, `error`, or `reject` must be provided"
            )

        new_thresholds = _get_threshold(
            thresholds=thresholds,
            debug=debug,
            warning=warning,
            error=error,
            reject=reject,
        )

        return self._replace(
            thresholds=new_thresholds, message=message or self._params.message
        )

    def debug(self, level: CheckThreshold):
        return self._merge_thresholds(debug=level)

    def warning(self, level: CheckThreshold):
        return self._merge_thresholds(warning=level)

    def error(self, level: CheckThreshold):
        return self._merge_thresholds(error=level)

    def reject(self, level: CheckThreshold):
        return self._merge_thresholds(reject=level)

    def message(self, message: str):
        """Set a custom error message"""
        return self._replace(message=message)

    def validate(
        self,
        validated_lf: "LazyFrame",
        filtered_lf: "LazyFrame",
        *,
        schema_name: str,
        source: str | None = None,
    ) -> "TableValidationError | None":
        """
        Evaluate this check against table metrics.

        Args:
            validated_lf: The LazyFrame with validation column
            filtered_lf: The LazyFrame with the row filter applied
            schema_name: Name of the schema being validated
            source: Optional source name for error messages

        Returns:
            TableValidationError if check fails, None if passes
        """
        raise NotImplementedError("Must be implemented in subclass")

    def validate_counts(
        self,
        *,
        total_rows: int,
        filtered_rows: int,
        schema_name: str,
        source: str | None = None,
    ) -> "TableValidationError | None":
        """Evaluate this check from precomputed table row counts."""
        raise NotImplementedError("Must be implemented in subclass")

    def _merge_thresholds(self, **kwargs):
        if self._params.thresholds is not None:
            new_thresholds = replace(self._params.thresholds, **kwargs)
        else:
            new_thresholds = Threshold(**kwargs)
        return self._replace(thresholds=new_thresholds)

    def _replace(self, **kwargs):
        new_params = replace(self._params, **kwargs)

        for arg in self._required_args:
            if hasattr(new_params, arg):
                continue
            elif hasattr(self, arg):
                continue
            else:
                raise TableCheckConfigurationError(
                    f"Required argument '{arg}' not found in params or instance"
                )

        new_check = object.__new__(self.__class__)
        new_check.__dict__.update(self.__dict__)
        return new_check._set_params(new_params)

    def _set_params(self, params: _TableCheckParams) -> "BaseTableCheck":
        self._params = params
        return self

    def to_spec(self, ctx=None) -> dict:
        """Default flat encoding: emit `check`, `message`, plus each set threshold level"""
        d: dict = {"check": self.method_id(), "message": self._params.message}
        t = self._params.thresholds
        for k in ("debug", "warning", "error", "reject"):
            v = getattr(t, k, None)
            if v is not None and v is not False:
                d[k] = v
        return d

    @classmethod
    def from_spec(cls, data: dict) -> "BaseTableCheck":
        """Default decode: pass threshold levels and message to `__init__`."""
        kwargs = {
            k: data[k]
            for k in ("debug", "warning", "error", "reject")
            if data.get(k) is not None
        }
        if "message" in data:
            kwargs["message"] = data["message"]
        return cls(**kwargs)

    def _create_extended_params(self, params_class: type[_T], **extra_params) -> _T:
        """
        Helper method to create extended params while preserving the Threshold dataclass.
        """
        base_params = {
            k: v for k, v in asdict(self._params).items() if k != "thresholds"
        }
        return params_class(
            **{**base_params, **extra_params},
            thresholds=extra_params.get("thresholds", self._params.thresholds),
        )

    def _format_message(
        self,
        count: int,
        total: int,
        target: int | None = None,
    ) -> str:
        return (
            self._params.message.replace("{{count}}", f"{count:,}")
            .replace("{{total}}", f"{total:,}")
            .replace("{{target}}", f"{target or 0:,}")
            .replace("{{fraction}}", f"{count / total:,.2%}")
        )
