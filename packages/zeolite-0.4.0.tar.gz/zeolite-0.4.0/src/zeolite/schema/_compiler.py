from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

from ._pipeline import PipelineParams, PrepareEntry
from ._utils.coerce_types import CoerceOverride
from .._utils.sanitise import sanitise_column_name
from ..column import Col
from ..exceptions import DuplicateColumnError, SchemaConfigurationError
from ..registry import ColumnRegistry
from ..types import ColumnNode, ColumnNodeType, SourceColDef
from ..types.sensitivity import Sensitivity

if TYPE_CHECKING:
    from .validation.variants import TableCheckType


@dataclass(frozen=True)
class OutputColumnMetadata:
    enum_values: frozenset[str] | None = None


@dataclass(frozen=True)
class OutputColumnInfo:
    name: str
    source_name: str
    id: str
    dtype: str
    sensitivity: Sensitivity
    column_type: ColumnNodeType
    meta: OutputColumnMetadata


# @dataclass(frozen=True)
# class RegistryNodeInfo:
#     id: str
#     name: str
#     dtype: str
#     column_type: ColumnNodeType
#     schema: str
#     stage: str | None
#     sensitivity: Sensitivity
#     parent_columns: frozenset[str]
#     parent_ids: frozenset[str]
#     alias: str | None
#     is_temporary: bool


@dataclass(frozen=True)
class _CompiledSchema:
    registry: ColumnRegistry
    source_columns: dict[str, SourceColDef]
    refined_columns: dict[str, str]
    pipeline_params: PipelineParams
    input_column_info: tuple[SourceColDef, ...]
    output_column_info: tuple[OutputColumnInfo, ...]
    # registry_node_info: tuple[RegistryNodeInfo, ...]


def _compile_schema(
    *,
    name: str,
    is_required: bool,
    stage: str | None,
    strict: bool,
    coerce: CoerceOverride,
    table_checks: list["TableCheckType"],
    columns: list[Col],
) -> _CompiledSchema:
    nodes = _cols_to_nodes(schema=name, stage=stage, columns=columns)
    registry = ColumnRegistry(nodes)
    registry.verify_integrity()

    source_columns = _cols_to_sources(columns, schema_name=name)
    refined_columns = _cols_to_refined_targets(registry.nodes())
    output_metadata = _cols_to_output_metadata(
        schema=name,
        stage=stage,
        columns=columns,
    )
    pipeline_params = _to_pipeline_params(
        name=name,
        is_required=is_required,
        stage=stage,
        strict=strict,
        coerce=coerce,
        table_checks=table_checks,
        registry=registry,
        source_columns=source_columns,
        refined_columns=refined_columns,
    )
    return _CompiledSchema(
        registry=registry,
        source_columns=source_columns,
        refined_columns=refined_columns,
        pipeline_params=pipeline_params,
        input_column_info=tuple(source_columns.values()),
        output_column_info=tuple(
            _output_column_info(alias, col_id, registry, output_metadata)
            for alias, col_id in refined_columns.items()
        ),
        # registry_node_info=tuple(_node_to_info(node) for node in registry.nodes()),
    )


def _to_pipeline_params(
    *,
    name: str,
    is_required: bool,
    stage: str | None,
    strict: bool,
    coerce: CoerceOverride,
    table_checks: list["TableCheckType"],
    registry: ColumnRegistry,
    source_columns: dict[str, SourceColDef],
    refined_columns: dict[str, str],
) -> PipelineParams:
    return PipelineParams(
        schema_name=name,
        is_required=is_required,
        stage=stage,
        strict=strict,
        coerce=coerce,
        source_columns=list(source_columns.values()),
        prepare_stages=[
            [
                PrepareEntry(name=n.name, expression=n.expression)
                for n in stage_nodes
                if n.expression is not None
            ]
            for stage_nodes in registry.get_execution_stages()
            if any(n.expression is not None for n in stage_nodes)
        ],
        validation_rules=[
            n.validation_rule for n in registry.nodes() if n.validation_rule is not None
        ],
        table_checks=table_checks,
        refined_columns={
            alias: registry.get_by_id(col_id).name
            for alias, col_id in refined_columns.items()
        },
    )


def _cols_to_nodes(
    schema: str, stage: str | None = None, columns: list[Col] | None = None
) -> list[ColumnNode]:
    nodes = []
    if columns is None:
        return nodes

    for column in columns:
        if not isinstance(column, Col):
            raise SchemaConfigurationError(
                f"All columns must be a Column Schema definition - {column}"
            )
        if column.ref.base_name is None:
            raise SchemaConfigurationError("""
        All Columns must have a name, either:
          - directly on creation, e.g. z.col("name")
          - assigning after creation, e.g. z.col().with_name("name")
          - defined through a keyword arg on schema.columns e.g. x.columns( name = z.col() )
          - defined through a dict key on schema.columns e.g. x.columns({ "name": z.col() })
        """)
        nodes.extend(column.get_nodes(schema, stage))

    return nodes


def _cols_to_sources(
    columns: list[Col] | None, schema_name: str | None = None
) -> dict[str, SourceColDef]:
    sources: dict[str, SourceColDef] = {}
    variants: dict[str, str] = {}
    if columns is None:
        return sources

    for column in columns:
        if column.has_expression:
            continue

        ref = column.ref
        col_variants = {sanitise_column_name(a) for a in column.get_variants}
        col_variants.add(sanitise_column_name(ref.name))
        source = SourceColDef(
            name=ref.name,
            variants=frozenset(col_variants),
            if_missing=column.if_missing,
            is_meta=column.ref.is_meta,
            dtype=column.params.dtype,
            coerce=column.params.coerce if column.params.dtype is not None else None,
        )

        existing_source = sources.get(ref.name)
        if existing_source is not None and existing_source != source:
            raise DuplicateColumnError(
                f"Duplicate source column name: {ref.name}",
                column_name=ref.name,
                schema_name=schema_name,
            )

        for alias in col_variants:
            existing_owner = variants.get(alias)
            if existing_owner is not None and existing_owner != ref.name:
                raise DuplicateColumnError(
                    f"Duplicate column alias: The sanitised alias `{alias}` for column `{ref.name}` already used for `{existing_owner}`",
                    column_name=ref.name,
                    duplicate_of=existing_owner,
                    schema_name=schema_name,
                )
            variants[alias] = ref.name

        sources[ref.name] = source

    return sources


def _cols_to_refined_targets(nodes: list[ColumnNode] | None) -> dict[str, str]:
    targets: dict[str, str] = {}
    counts: dict[str, int] = {}
    if nodes is None:
        return targets

    for node in nodes:
        if node.is_temporary:
            continue
        if node.alias is None:
            continue
        if node.alias not in counts:
            counts[node.alias] = 1
            targets[node.alias] = node.id
        else:
            index = counts[node.alias] + 1
            counts[node.alias] = index
            targets[f"{node.alias}_{index}"] = node.id

    return targets


def _cols_to_output_metadata(
    *,
    schema: str,
    stage: str | None,
    columns: list[Col],
) -> dict[str, OutputColumnMetadata]:
    metadata: dict[str, OutputColumnMetadata] = {}

    for column in columns:
        clean = column.params.clean
        if clean is None:
            continue

        clean_params = clean.params
        if not hasattr(clean_params, "enum_map"):
            continue

        enum_values = set(clean_params.enum_map.values())
        if clean_params.invalid_value is not None:
            enum_values.add(clean_params.invalid_value)
        if clean_params.null_value is not None:
            enum_values.add(clean_params.null_value)

        metadata[column.ref.with_schema(schema, stage).clean().id] = (
            OutputColumnMetadata(enum_values=frozenset(enum_values))
        )

    return metadata


# def _node_to_info(node: ColumnNode) -> RegistryNodeInfo:
#     return RegistryNodeInfo(
#         id=node.id,
#         name=node.name,
#         dtype=node.data_type,
#         column_type=node.column_type,
#         schema=node.schema,
#         stage=node.stage,
#         sensitivity=node.sensitivity,
#         parent_columns=frozenset(node.parent_columns),
#         parent_ids=frozenset(node.parent_ids),
#         alias=node.alias,
#         is_temporary=node.is_temporary,
#     )


def _output_column_info(
    alias: str,
    col_id: str,
    registry: ColumnRegistry,
    output_metadata: dict[str, OutputColumnMetadata],
) -> OutputColumnInfo:
    node = registry.get_by_id(col_id)
    if node is None:
        raise SchemaConfigurationError(
            f"Compiled refined column `{alias}` references unknown column ID `{col_id}`"
        )
    return OutputColumnInfo(
        name=alias,
        source_name=node.name,
        id=col_id,
        dtype=node.data_type,
        sensitivity=node.sensitivity,
        column_type=node.column_type,
        meta=output_metadata.get(col_id, OutputColumnMetadata()),
    )
