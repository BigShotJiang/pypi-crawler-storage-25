# %%
import polars as pl

from ..types import ColumnDataType


# %%
def get_polars_type(data_type: ColumnDataType):
    if isinstance(data_type, pl.DataType):
        return data_type
    # Polars dtypes can be passed as the class itself (`pl.Float32`) or an
    # instance (`pl.Float32()`); treat the class form as equivalent.
    if isinstance(data_type, type) and issubclass(data_type, pl.DataType):
        return data_type()
    if data_type in ("string", "id", "sanitised_string"):
        return pl.String()
    elif data_type in ("number", "float"):
        return pl.Float64()
    elif data_type == "integer":
        return pl.Int64()
    elif data_type == "boolean":
        return pl.Boolean()
    elif data_type == "date":
        return pl.Date()
    elif data_type == "datetime":
        return pl.Datetime()
    elif data_type == "duration":
        return pl.Duration()
    elif data_type == "categorical":
        return pl.Categorical()
    elif data_type == "decimal":
        print(
            "Decimal defaults to `.2f`, if you need to customise use a polars decimal `pl.Decimal`"
        )
        return pl.Decimal(None, 2)
    elif data_type == "enum":
        raise TypeError(
            "enum must be defined as a polars enum e.g. `pl.Enum(['a', 'b', 'c'])`"
        )
    else:
        # raise ValueError(f"Unsupported data type: {data_type}")
        return None


def get_data_type_label(data_type: ColumnDataType):
    if isinstance(data_type, str):
        return data_type
    elif isinstance(data_type, pl.DataType):
        return str(data_type).split("(")[0].lower()
    elif isinstance(data_type, type) and issubclass(data_type, pl.DataType):
        return data_type.__name__.lower()
    else:
        return "unknown"
