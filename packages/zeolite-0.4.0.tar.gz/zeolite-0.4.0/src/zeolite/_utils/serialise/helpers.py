"""Shared helpers for variant spec encoding/decoding.

Variant families (`BaseCheck`, `CleanColumn`, table checks) own their
`to_spec` / `from_spec` methods directly. This module only provides the small
shared pieces that are not domain-specific.

Wire-format contract:
- Wrapper-level fields (declared on the family base) sit at the top of the
  encoded dict.
- Derived-only fields declared on `SPEC.derived` are skipped on encode and
  rebuilt by the variant constructor or params class' `__post_init__`.
- Everything else is a "variant param" and gets nested under `params`.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

import polars as pl

from ...exceptions import SchemaConfigurationError
from ...ref import ColumnRef
from ...types.sensitivity import Sensitivity
from ...types.validation.threshold import Threshold, ThresholdLevel


@dataclass(frozen=True, kw_only=True)
class VariantSpec:
    """Single declaration of a variant's spec-facing contract."""

    params: type
    id: str | None = None
    method: str | None = None
    derived: frozenset[str] = field(default_factory=frozenset)
    callables: frozenset[str] = field(default_factory=frozenset)
    user_label: bool = False


class CheckSpec(VariantSpec):
    pass


class CleanSpec(VariantSpec):
    pass


class TableCheckSpec(VariantSpec):
    pass


# ---------------------------------------------------------------------------
# Encode context
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class EncodeContext:
    """Context threaded through `to_spec` so callable-valued fields can be
    materialised against the right runtime column name.

    `bound_column` is the source column the variant operates on at apply time.
    `bound_column_cleaned` is the corresponding cleaned-column runtime name,
    used when a check's `check_on_cleaned` is true. Either may be `None` if
    not applicable (e.g. table checks have no bound column).
    """

    bound_column: str | None = None
    bound_column_cleaned: str | None = None

    def runtime_bound(self, *, check_on_cleaned: bool) -> str | None:
        if check_on_cleaned and self.bound_column_cleaned is not None:
            return self.bound_column_cleaned
        return self.bound_column


# ---------------------------------------------------------------------------
# Generic value encoding
# ---------------------------------------------------------------------------


def encode_value(v: Any) -> Any:
    """Encode a single value to its JSON-safe spec representation."""
    from .common import (
        encode_dtype,
        encode_threshold,
        encode_threshold_level,
        serialize_expr,
    )

    if v is None or isinstance(v, (bool, int, float, str)):
        return v
    if isinstance(v, Sensitivity):
        return v.value
    if isinstance(v, ThresholdLevel):
        return encode_threshold_level(v)
    if isinstance(v, Threshold):
        return encode_threshold(v)
    if isinstance(v, ColumnRef):
        return {"$ref": v.id, "name": v.name}
    if isinstance(v, pl.Expr):
        return serialize_expr(v)
    if isinstance(v, type) and issubclass(v, pl.DataType):
        return encode_dtype(v)
    if isinstance(v, pl.DataType):
        return encode_dtype(v)
    if isinstance(v, (set, frozenset)):
        encoded = [encode_value(x) for x in v]
        try:
            return sorted(encoded)
        except TypeError:
            return sorted(encoded, key=repr)
    if isinstance(v, (tuple, list)):
        return [encode_value(x) for x in v]
    if isinstance(v, dict):
        return {str(k): encode_value(val) for k, val in v.items()}
    if callable(v):
        raise SchemaConfigurationError(
            "Custom function cannot be serialised directly; it must be "
            "materialised to a pl.Expr against a bound column first."
        )
    raise SchemaConfigurationError(
        f"Cannot encode value of type {type(v).__name__!r} for spec: {v!r}"
    )


def materialise_callable(
    fn: Any, bound_column: str | None, *, field_label: str
) -> pl.Expr:
    """Invoke a user callable with `pl.col(bound_column)` to produce an Expr."""
    if bound_column is None:
        raise SchemaConfigurationError(
            f"Cannot serialise callable {field_label!r}: no bound column known. "
            "Custom callables can only be serialised once attached to a column."
        )
    result = fn(pl.col(bound_column))
    if not isinstance(result, pl.Expr):
        raise SchemaConfigurationError(
            f"Custom {field_label!r} callable must return a pl.Expr; got "
            f"{type(result).__name__!r}."
        )
    return result


# ---------------------------------------------------------------------------
# Generic shape-based decoding
# ---------------------------------------------------------------------------


def decode_value(raw: Any) -> Any:
    """Best-effort generic decode based on wire shape. Variants override
    `_decode_field` for type-specific reconstruction not covered here."""
    from .common import deserialize_expr

    if isinstance(raw, dict):
        if "format" in raw and "data" in raw:
            return deserialize_expr(raw)
        if "$ref" in raw:
            return ColumnRef.from_id(raw["$ref"])
    return raw


__all__ = [
    "CheckSpec",
    "CleanSpec",
    "TableCheckSpec",
    "EncodeContext",
    "VariantSpec",
    "decode_value",
    "encode_value",
    "materialise_callable",
]
