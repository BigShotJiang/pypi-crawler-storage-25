from __future__ import annotations

import base64
import json
import re

import polars as pl

from ...types.validation.threshold import Threshold, ThresholdLevel


# ------------------------------------------------------------------
# Polars expression
# ------------------------------------------------------------------
def serialize_expr(expr: pl.Expr) -> dict:
    json_expr = expr.meta.serialize(format="json")
    try:
        pl.Expr.deserialize(json_expr.encode(), format="json")
    except Exception:
        return {
            "format": "binary",
            "data": base64.b64encode(expr.meta.serialize(format="binary")).decode(
                "ascii"
            ),
        }

    return {
        "format": "json",
        "data": json.loads(json_expr),
    }


def deserialize_expr(data: dict) -> pl.Expr:
    match data.get("format"):
        case "binary":
            return pl.Expr.deserialize(base64.b64decode(data["data"]), format="binary")
        case "json":
            return pl.Expr.deserialize(json.dumps(data["data"]).encode(), format="json")
        case _:
            return pl.Expr.deserialize(json.dumps(data).encode(), format="json")


# ------------------------------------------------------------------
# Polars dtype
# ------------------------------------------------------------------
def encode_dtype(dtype: pl.DataType | None) -> str | None:
    return None if dtype is None else str(dtype)


def decode_dtype(value: str | None) -> pl.DataType | None:
    if value is None:
        return None
    # Add 'pl.' prefix to bare capitalised type names, but not to Python
    # keywords (None/True/False) or to words already inside quoted strings.
    _SKIP = {"None", "True", "False"}

    def _prefix_types(source: str) -> str:
        parts = re.split(r"('(?:[^'\\]|\\.)*'|\"(?:[^\"\\]|\\.)*\")", source)
        out = []
        for i, part in enumerate(parts):
            if i % 2 == 1:  # inside a string literal – leave as-is
                out.append(part)
            else:
                out.append(
                    re.sub(
                        r"\b([A-Z][a-zA-Z0-9]*)\b",
                        lambda m: (
                            m.group(1) if m.group(1) in _SKIP else f"pl.{m.group(1)}"
                        ),
                        part,
                    )
                )
        return "".join(out)

    return eval(_prefix_types(value), {"pl": pl})  # noqa: S307


# ------------------------------------------------------------------
# Thresholds
# ------------------------------------------------------------------
def encode_threshold(t: Threshold) -> dict:
    result = {}
    for k in ("debug", "warning", "error", "reject"):
        v = getattr(t, k)
        if v is not None and v is not False:
            result[k] = v
    return result


def decode_threshold(data: dict) -> Threshold:
    return Threshold(**{k: v for k, v in data.items() if v is not None})


def encode_threshold_level(level: ThresholdLevel) -> str:
    return level.level


def decode_threshold_level(value: str) -> ThresholdLevel:
    for lv in ThresholdLevel:
        if lv.level == value:
            return lv
    raise ValueError(f"Unknown threshold level: {value!r}")


# ------------------------------------------------------------------
# Table-level checks (delegate to BaseTableCheck.to_spec / .from_spec)
# ------------------------------------------------------------------
def encode_table_check(check) -> dict:
    return check.to_spec()


def decode_table_check(data: dict):
    from ...exceptions import SchemaConfigurationError
    from ...schema._utils.serialise._decode_registry import TABLE_CHECK_VARIANTS

    check_id = data["check"]
    if check_id not in TABLE_CHECK_VARIANTS:
        raise SchemaConfigurationError(f"Unknown table check type: {check_id!r}")
    return TABLE_CHECK_VARIANTS[check_id].from_spec(data)
