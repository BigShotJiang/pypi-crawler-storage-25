from dataclasses import dataclass, asdict, field
from typing import TYPE_CHECKING, Union

import polars as pl

from .._utils.column_id import (
    make_column_id,
    ID_PART_DIVIDER,
    COLUMN_NAME_PART_DIVIDER,
    COLUMN_NAME_SECTION_DIVIDER,
    ID_SECTION_DIVIDER,
    ColumnIdConfig,
    parse_column_name_to_config,
)
from ..exceptions import RegistryIntegrityError

if TYPE_CHECKING:
    from ..registry import ColumnRegistry
    from ..types import ColumnNode
    from ..column.validation import BaseCheck, ColumnCheckType


@dataclass(frozen=True)
class ColumnRef(ColumnIdConfig):
    """Reference to a column that can be used to look up actual column names/ids"""

    # alias_name: Optional[str] = None

    def _chain(self, **kwargs: dict[str, any]) -> "ColumnRef":
        """Create a new instance with some fields replaced"""
        return ColumnRef(**{**asdict(self), **kwargs})

    def clean(self) -> "ColumnRef":
        return self._chain(is_clean=True)

    def check(
        self, validation: Union["ColumnCheckType", type["BaseCheck"], str]
    ) -> "ColumnRef":
        from ..column.validation import BaseCheck

        if isinstance(validation, str):
            check_name = validation
        elif isinstance(validation, BaseCheck):
            check_name = (
                validation.params.alias
                or validation.params.label
                or validation.method_id()
            )
        else:
            check_name = validation.method_id()
        return self._chain(is_check=True, check_name=check_name)

    def derived(self) -> "ColumnRef":
        return self._chain(is_derived=True)

    def custom_check(self) -> "ColumnRef":
        return self._chain(is_custom_check=True, is_derived=True)

    def with_schema(self, schema: str, stage: str | None = None) -> "ColumnRef":
        if stage is not None:
            return self._chain(schema=schema, stage=stage)
        else:
            return self._chain(schema=schema)

    def with_base_name(self, name: str) -> "ColumnRef":
        """Sets the column reference name"""
        ref = parse_column_name(name)
        return self._chain(base_name=ref.base_name)

    # def alias(self, name: str) -> 'ColumnRef':
    #     """Set an alias for this column reference"""
    #     return self._chain(alias_name=name)

    def get_id(
        self,
        *,
        schema: str | None = None,
        stage: str | None = None,
        include_schema_prefix: bool = True,
    ) -> str:
        """Get the ID of the column reference"""
        return make_column_id(
            name=self.base_name,
            schema=schema if schema else self.schema,
            stage=stage if stage else self.stage,
            is_clean=self.is_clean,
            is_derived=self.is_derived,
            is_meta=self.is_meta,
            is_custom_check=self.is_custom_check,
            check_name=self.check_name,
            include_schema_prefix=include_schema_prefix,
        )

    def get_name(self) -> str:
        """Get the name of the column reference"""
        return (
            self.get_id(include_schema_prefix=False)
            .replace(ID_SECTION_DIVIDER, COLUMN_NAME_SECTION_DIVIDER)
            .replace(ID_PART_DIVIDER, COLUMN_NAME_PART_DIVIDER)
        )

    @property
    def col(self) -> pl.Expr:
        """Get the name of the column reference"""
        return pl.col(self.name)

    @property
    def name(self) -> str:
        """Get the name of the column reference"""
        return self.get_name()

    @property
    def id(self) -> str:
        """Get the ID of the column reference"""
        return self.get_id()

    @classmethod
    def from_id(cls, id: str) -> "ColumnRef":
        """Create a new column reference from an ID"""
        sections = id.split(ID_SECTION_DIVIDER)
        stage = None
        schema = None
        name = ""
        is_clean = False
        is_check = False
        is_derived = False
        is_meta = False
        is_custom_check = False
        check_name = None

        if len(sections) == 1:
            return cls(base_name=sections[0])

        valid_prefixes = {"meta", "derived", "custom_check"}
        valid_suffixes = {"clean", "check"}
        idx = 0

        first_parts = sections[0].split(ID_PART_DIVIDER)
        second_parts = sections[1].split(ID_PART_DIVIDER) if len(sections) > 1 else []
        first_is_prefix = all(part in valid_prefixes for part in first_parts)
        second_is_suffix = any(part in valid_suffixes for part in second_parts)
        first_is_schema = not first_is_prefix and (
            len(sections) >= 3 or not second_is_suffix
        )

        if first_is_schema:
            if len(first_parts) == 1:
                schema = first_parts[0]
            elif len(first_parts) == 2:
                stage, schema = first_parts
            else:
                name = sections[0]
            idx = 1
        elif not first_is_prefix:
            name = sections[0]
            idx = 1

        if idx < len(sections):
            attr_parts = sections[idx].split(ID_PART_DIVIDER)
            if all(part in valid_prefixes for part in attr_parts):
                is_meta = "meta" in attr_parts
                is_derived = "derived" in attr_parts
                is_custom_check = "custom_check" in attr_parts
                idx += 1

        if idx < len(sections) and name == "":
            name = sections[idx]
            idx += 1

        if idx < len(sections):
            suffix_parts = sections[idx].split(ID_PART_DIVIDER)
            if "clean" in suffix_parts:
                is_clean = True
            if "check" in suffix_parts:
                check_idx = suffix_parts.index("check")
                if check_idx + 1 < len(suffix_parts):
                    is_check = True
                    check_name = suffix_parts[check_idx + 1]

        return cls(
            base_name=name,
            schema=schema,
            stage=stage,
            is_clean=is_clean,
            is_derived=is_derived,
            is_check=is_check,
            is_meta=is_meta,
            is_custom_check=is_custom_check,
            check_name=check_name,
        )

    def resolve(
        self,
        registry: "ColumnRegistry",
        *,
        schema: str | None = None,
        stage: str | None = None,
    ) -> "ColumnNode":
        """Resolve the reference in the registry to an actual column node"""
        col_id = self.get_id(schema=schema, stage=stage)

        node = registry.get_by_id(col_id)
        if not node:
            raise RegistryIntegrityError(
                f"Could not find column with ID {col_id} in registry"
            )
        return node


@dataclass(frozen=True)
class MetaColumnRef(ColumnRef):
    """Reference to a derived column"""

    is_meta: bool = field(default=True, init=False)


@dataclass(frozen=True)
class DerivedColumnRef(ColumnRef):
    """Reference to a derived column"""

    is_derived: bool = field(default=True, init=False)


@dataclass(frozen=True)
class CustomCheckColumnRef(ColumnRef):
    """Reference to a custom check column"""

    is_custom_check: bool = field(default=True, init=False)
    is_derived: bool = field(default=True, init=False)


def get_column_ref_from_id(col_id: str) -> ColumnRef:
    """Get a column reference from an ID"""
    return ColumnRef.from_id(col_id)


def parse_column_name(col_name: str) -> ColumnRef:
    """
    Parse a column name string into a ColumnRef

    Args:
        col_name: The column name string to parse

    Returns:
        ColumnRef
    """
    config = parse_column_name_to_config(col_name)
    return ColumnRef(**asdict(config))
