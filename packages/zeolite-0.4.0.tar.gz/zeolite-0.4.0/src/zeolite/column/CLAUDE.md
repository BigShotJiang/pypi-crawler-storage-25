# column/

Column definitions, cleaning variants, validation check variants. See root CLAUDE.md for the variants pattern overview.

## STRUCTURE
- `__init__.py` — `ColFactory` + module-level aliases (`Check.is_null`, `Clean.enum`, etc.)
- `_base/` — `Col` dataclass, `_ColumnParams`, node generation
- `_clean/` — `CleanColumn` base + per-type variants (`_string`, `_number`, `_date`, `_boolean`, `_enum`, `_id`, `_custom`)
- `validation/_base.py` — `BaseCheck`, `_CheckParams`
- `validation/variants/` — concrete check classes (one file per check family)
- `validation/_utils/` — shared expression builders, `RowCheckType` enum

## CHECK VARIANT CONTRACT (`validation/variants/`)
- Subclass `BaseCheck`. Define a frozen `kw_only=True` `_CustomParams` dataclass extending `_CheckParams`.
- Declare `SPEC = CheckSpec(id=..., params=_CustomParams)` on each concrete check. This drives method id, encode/decode, and auto-registration.
- In `__init__`: call `super().__init__()`, then `self._params = self._create_extended_params(_CustomParams, **fields)`. No other side effects.
- Implement `expression(source_column: str, alias: str, fail_value: CheckFailLevel) -> pl.Expr`.
  - MUST use `when(...).then(ROW_VALIDATION_SUCCESS_VALUE).otherwise(fail_value)` — never hardcode the success value.
- Set class var `_required_args: set[str]` for fields needed by `_replace()`.

## CLEAN VARIANT CONTRACT (`_clean/`)
- Subclass `CleanColumn`. Frozen `kw_only=True` `_CustomParams` extending `_CleanParams`.
- Declare `SPEC = CleanSpec(params=_CustomParams)` on each concrete clean. Use `derived={...}` for runtime-only params.
- `__init__(*, data_type, col_sensitivity, alias, is_temporary, **custom)` → `super().__init__()` then assign `self._params`.
- Implement `clean_expr(source: str, alias: str) -> pl.Expr` — return expression with terminal `.alias(alias)`.

## CONVENTIONS
- Check class names: `Check{Type}{Action}` (e.g. `CheckStrIsEmail`); param dataclasses underscore-prefixed.
- Label format: `f"{method_id()}_{value}".lower().replace(" ", "_")`.
- All `_Params` are `frozen=True`; mutate via `_replace()` helper, never directly.
- Register new check via `RowCheckType` enum + re-export in `validation/__init__.py` + alias on `Check`.
- New variants auto-register for spec decode when their module is imported and they declare `SPEC`.
