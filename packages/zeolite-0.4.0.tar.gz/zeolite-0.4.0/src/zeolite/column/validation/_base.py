from dataclasses import dataclass, field, fields, replace, asdict
from inspect import Parameter, signature
from typing import TYPE_CHECKING, Any, ClassVar, Literal, Optional, TypeVar

import polars as pl

from ..._utils.serialise.helpers import (
    CheckSpec,
    EncodeContext,
    decode_value,
    materialise_callable,
    encode_value,
)
from ...types.validation.threshold import Threshold, CheckThreshold
from ...exceptions import (
    InvalidThresholdError,
    CheckConfigurationError,
    SchemaConfigurationError,
)
from ._utils.parse_threshold import parse_to_threshold, ThresholdType
from ._utils.validation_node import get_validation_node

if TYPE_CHECKING:
    from ...ref import ColumnRef
    from ...types import ColumnNode


type CheckFailLevel = Literal["fail", "reject"]

T = TypeVar("T", bound="_CheckParams")


@dataclass(frozen=True, kw_only=True)
class _CheckParams:
    label: str
    remove_row_on_fail: bool = False
    alias: str | None = None
    check_on_cleaned: bool = False
    is_temporary: bool = True
    message: str = field(default="")
    thresholds: Threshold | None


_CHECK_BASE_FIELDS = frozenset(f.name for f in fields(_CheckParams))


class BaseCheck:
    """Configuration for a row check"""

    _registry: ClassVar[dict[str, type["BaseCheck"]]] = {}
    _required_args: set[str] = set()
    SPEC: ClassVar[CheckSpec] = CheckSpec(
        params=_CheckParams, derived=frozenset({"label"})
    )

    def __init_subclass__(cls, **kwargs):
        super().__init_subclass__(**kwargs)
        spec = cls.__dict__.get("SPEC")
        if cls is not BaseCheck and spec is not None and spec.id is not None:
            BaseCheck._registry[spec.id] = cls

    def __init__(
        self,
        remove_row_on_fail: bool = False,
        alias: str | None = None,
        check_on_cleaned: bool = False,
        message: str = "",
        thresholds: ThresholdType = None,
        debug: Optional[CheckThreshold] = None,
        warning: Optional[CheckThreshold] = None,
        error: Optional[CheckThreshold] = None,
        reject: Optional[CheckThreshold] = None,
        label: Optional[str] = None,
        is_temporary: bool = True,
    ):
        self._params = _CheckParams(
            remove_row_on_fail=remove_row_on_fail,
            alias=alias,
            check_on_cleaned=check_on_cleaned,
            message=message,
            thresholds=parse_to_threshold(
                remove_row_on_fail=remove_row_on_fail,
                thresholds=thresholds,
                debug=debug,
                warning=warning,
                error=error,
                reject=reject,
            ),
            label=label or self.method_id(),
            is_temporary=is_temporary,
        )

    @classmethod
    def method_id(cls) -> str:
        return cls.SPEC.id or "__check_base__"

    def thresholds(
        self,
        *,
        debug: Optional[CheckThreshold] = None,
        warning: Optional[CheckThreshold] = None,
        error: Optional[CheckThreshold] = None,
        reject: Optional[CheckThreshold] = None,
        thresholds: Optional[ThresholdType] = None,
        message: Optional[str] = None,
    ):
        """Configure thresholds for this check"""
        if (
            (thresholds is None)
            and (debug is None or debug is False)
            and (warning is None or warning is False)
            and (error is None or error is False)
            and (reject is None or reject is False)
        ):
            raise InvalidThresholdError(
                "At least one of `thresholds`, `debug`, `warning`, `error`, or `reject` must be provided"
            )

        new_thresholds = parse_to_threshold(
            remove_row_on_fail=self._params.remove_row_on_fail,
            thresholds=thresholds,
            debug=debug,
            warning=warning,
            error=error,
            reject=reject,
        )

        return self._replace(
            thresholds=new_thresholds, message=message or self._params.message
        )

    def _merge_thresholds(self, **kwargs):
        if self._params.thresholds is not None:
            new_thresholds = replace(self._params.thresholds, **kwargs)
        else:
            new_thresholds = Threshold(**kwargs)
        return self._replace(thresholds=new_thresholds)

    def debug(self, level: CheckThreshold):
        return self._merge_thresholds(debug=level)

    def warning(self, level: CheckThreshold):
        return self._merge_thresholds(warning=level)

    def error(self, level: CheckThreshold):
        return self._merge_thresholds(error=level)

    def reject(self, level: CheckThreshold):
        return self._merge_thresholds(reject=level)

    def remove_row_on_fail(self, remove: bool = True):
        new_thresholds = parse_to_threshold(
            remove_row_on_fail=remove,
            thresholds=self._params.thresholds,
        )
        return self._replace(remove_row_on_fail=remove, thresholds=new_thresholds)

    def alias(self, alias: str, *, is_temporary: bool | None = None):
        if is_temporary is None:
            return self._replace(alias=alias, is_temporary=False)
        else:
            return self._replace(alias=alias, is_temporary=is_temporary)

    def temporary(self, is_temporary: bool = True):
        return self._replace(is_temporary=is_temporary)

    def message(self, message: str):
        return self._replace(message=message)

    def check_on_cleaned(self, check_cleaned: bool = True):
        return self._replace(check_on_cleaned=check_cleaned)

    @property
    def params(self) -> _CheckParams:
        return self._params

    def get_validation_node(self, source_column: "ColumnRef") -> "ColumnNode":
        """Create a validation node for this check"""
        return get_validation_node(
            check=self,
            source_column=source_column,
        )

    def get_validation_nodes(self, source_column: "ColumnRef") -> list["ColumnNode"]:
        """Create validation nodes for this check in dependency order."""
        return [self.get_validation_node(source_column)]

    def expression(
        self, source_column: str, alias: str, fail_value: CheckFailLevel
    ) -> pl.Expr:
        """Polars expression for this check"""
        raise NotImplementedError("Must be implemented in subclass")

    def _replace(self, **kwargs):
        new_params = replace(self._params, **kwargs)

        args = {}
        for arg in self._required_args:
            if hasattr(new_params, arg):
                args[arg] = getattr(new_params, arg)
            elif hasattr(self, arg):
                args[arg] = getattr(self, arg)
            else:
                raise CheckConfigurationError(
                    f"Required argument '{arg}' not found in params or instance"
                )

        return self.__class__(**args)._set_params(new_params)

    def _set_params(self, params: _CheckParams) -> "BaseCheck":
        self._params = params
        return self

    def _create_extended_params(self, params_class: type[T], **extra_params) -> T:
        """
        Helper method to create extended params while preserving the Threshold dataclass.
        """
        base_params = {
            k: v for k, v in asdict(self._params).items() if k != "thresholds"
        }
        return params_class(
            **{**base_params, **extra_params},
            thresholds=extra_params.get("thresholds", self._params.thresholds),
        )

    # --- Serialisation -------------------------------------------------
    @staticmethod
    def _is_compound() -> bool:
        """Compound checks override to True"""
        return False

    def _is_derived(self, field_name: str) -> bool:
        return field_name in self.SPEC.derived

    def _callable_bound_column(self, ctx: EncodeContext) -> str | None:
        return ctx.runtime_bound(check_on_cleaned=self._params.check_on_cleaned)

    def _encode_field(self, field_name: str, value: Any, ctx: EncodeContext) -> Any:
        if (
            field_name in self.SPEC.callables
            and callable(value)
            and not isinstance(value, pl.Expr)
        ):
            value = materialise_callable(
                value, self._callable_bound_column(ctx), field_label=field_name
            )
        return encode_value(value)

    @classmethod
    def _decode_field(cls, field_name: str, raw: Any) -> Any:
        return decode_value(raw)

    def to_spec(self, ctx: EncodeContext | None = None) -> dict:
        ctx = ctx or EncodeContext()
        p = self._params
        is_compound = self._is_compound()

        out: dict[str, Any] = {
            "check": self.method_id(),
            "alias": p.alias,
            "temporary": p.is_temporary,
            "remove_row_on_fail": p.remove_row_on_fail,
            "message": p.message,
        }
        t = p.thresholds
        if t is not None:
            for k in ("debug", "warning", "error", "reject"):
                v = getattr(t, k, None)
                if v is not None and v is not False:
                    out[k] = v
        if not is_compound:
            out["check_on_cleaned"] = p.check_on_cleaned
        if self.SPEC.user_label:
            out["label"] = p.label

        variant_params: dict[str, Any] = {}
        for f in fields(p):
            if f.name in _CHECK_BASE_FIELDS or f.name in self.SPEC.derived:
                continue
            value = getattr(p, f.name)
            if f.name == "checks" and is_compound:
                variant_params["checks"] = [c.to_spec(ctx) for c in value]
                continue
            variant_params[f.name] = self._encode_field(f.name, value, ctx)
        out["params"] = variant_params
        return out

    @classmethod
    def from_spec(cls, data: dict) -> "BaseCheck":
        instance = cls(**cls._init_kwargs_from_spec(data))
        if "temporary" in data:
            instance = instance.temporary(data["temporary"])
        return instance

    @classmethod
    def _init_kwargs_from_spec(cls, data: dict) -> dict[str, Any]:
        return cls._filter_init_kwargs(
            {
                **cls._wrapper_kwargs_from_spec(data),
                **cls._variant_kwargs_from_spec(data),
            }
        )

    @classmethod
    def _filter_init_kwargs(cls, kwargs: dict[str, Any]) -> dict[str, Any]:
        params = signature(cls.__init__).parameters
        if any(p.kind == Parameter.VAR_KEYWORD for p in params.values()):
            return kwargs
        unexpected = {
            key for key in kwargs if key not in params and key not in _CHECK_BASE_FIELDS
        }
        if unexpected:
            raise SchemaConfigurationError(
                f"{cls.__name__} cannot decode the following fields: "
                f"{', '.join(sorted(unexpected))}"
            )
        return {k: v for k, v in kwargs.items() if k in params}

    @classmethod
    def _wrapper_kwargs_from_spec(
        cls, data: dict, *, include_check_on_cleaned: bool = True
    ) -> dict[str, Any]:
        kwargs: dict[str, Any] = {
            "remove_row_on_fail": data.get("remove_row_on_fail", False),
            "alias": data.get("alias"),
        }
        if include_check_on_cleaned:
            kwargs["check_on_cleaned"] = data.get("check_on_cleaned", False)
        if data.get("message") is not None:
            kwargs["message"] = data["message"]
        if cls.SPEC.user_label:
            kwargs["label"] = data["label"]
        for level in ("debug", "warning", "error", "reject"):
            if level in data:
                kwargs[level] = data[level]
        return kwargs

    @classmethod
    def _variant_kwargs_from_spec(cls, data: dict) -> dict[str, Any]:
        """Decode params fields that map directly to constructor kwargs."""
        raw = data.get("params") or {}
        param_field_names = {f.name for f in fields(cls.SPEC.params)}
        kwargs: dict[str, Any] = {}
        for wire_name, raw_value in raw.items():
            if (
                wire_name in param_field_names
                and wire_name not in _CHECK_BASE_FIELDS
                and wire_name not in cls.SPEC.derived
            ):
                kwargs[wire_name] = cls._decode_field(wire_name, raw_value)
        return kwargs
