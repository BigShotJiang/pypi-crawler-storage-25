from dataclasses import dataclass
from typing import Optional

import polars as pl

from .._base import BaseCheck, CheckFailLevel, CheckSpec, ThresholdType, _CheckParams
from .._utils.data_checks import ROW_VALIDATION_SUCCESS_VALUE
from .._utils.types import RowCheckType
from .._utils.validation_node import create_validation_rule
from ....exceptions import CheckConfigurationError
from ....ref import ColumnRef
from ....types import ColumnNode
from ....types.sensitivity import Sensitivity
from ....types.validation.threshold import CheckThreshold


@dataclass(frozen=True, kw_only=True)
class _CompoundParams(_CheckParams):
    checks: list[BaseCheck]

    def __post_init__(self):
        if len(self.checks) < 2:
            raise CheckConfigurationError(
                "Compound checks require at least 2 child checks"
            )
        for check in self.checks:
            if not isinstance(check, BaseCheck):
                raise CheckConfigurationError(
                    "Compound checks only accept child BaseCheck instances"
                )
            if check._is_compound():
                raise CheckConfigurationError(
                    "Nested compound checks are not supported in v1"
                )


class _BaseCompoundCheck(BaseCheck):
    _required_args = {"checks"}

    def __init__(
        self,
        *children: BaseCheck,
        checks: list[BaseCheck] | None = None,
        remove_row_on_fail: bool = False,
        alias: str | None = None,
        thresholds: ThresholdType = None,
        debug: Optional[CheckThreshold] = None,
        warning: Optional[CheckThreshold] = None,
        error: Optional[CheckThreshold] = None,
        reject: Optional[CheckThreshold] = None,
        message: str = "{{column}} has {{count}} failed value(s) ({{fraction}})",
        label: str | None = None,
    ):
        raw_checks = list(children) if len(children) > 0 else (checks or [])
        parsed_checks = list(raw_checks)
        for c in parsed_checks:
            if not isinstance(c, BaseCheck):
                raise CheckConfigurationError(
                    "Compound checks only accept child BaseCheck instances"
                )
        compound_label = label or self._build_default_label(parsed_checks)

        super().__init__(
            remove_row_on_fail=remove_row_on_fail,
            alias=alias,
            message=message,
            thresholds=thresholds,
            debug=debug,
            warning=warning,
            error=error,
            reject=reject,
            label=compound_label,
        )
        self._params = self._create_extended_params(
            _CompoundParams,
            checks=parsed_checks,
        )

    def check_on_cleaned(self, check_cleaned: bool = True):
        raise CheckConfigurationError(
            "Compound checks do not support `check_on_cleaned`; set it on each child check instead"
        )

    def get_validation_node(self, source_column: ColumnRef) -> ColumnNode:
        return self.get_validation_nodes(source_column)[-1]

    def get_validation_nodes(self, source_column: ColumnRef) -> list[ColumnNode]:
        child_nodes: list[ColumnNode] = []
        child_summary_names: list[str] = []

        for child in self._params.checks:
            expanded_nodes = child.get_validation_nodes(source_column)
            child_nodes.extend(expanded_nodes)
            child_summary_names.append(expanded_nodes[-1].name)

        summary_node = self._create_summary_node(
            source_column=source_column,
            child_summary_names=child_summary_names,
        )
        return [*child_nodes, summary_node]

    def _create_summary_node(
        self, *, source_column: ColumnRef, child_summary_names: list[str]
    ) -> ColumnNode:
        label = self._params.label if self._params.label else self.method_id()
        working_name = (
            source_column.check(self._params.alias).name
            if self._params.alias
            else source_column.check(label).name
        )
        expr = self.expression(
            child_summary_names,
            working_name,
            fail_value="reject" if self._params.remove_row_on_fail else "fail",
        )
        validation_rule = create_validation_rule(
            check_method_id=self.method_id(),
            message=self._params.message,
            source_column=source_column.name,
            check_col_name=working_name,
            schema=source_column.schema,
            thresholds=self._params.thresholds,
            remove_row_on_fail=self._params.remove_row_on_fail,
        )

        return ColumnNode(
            id=source_column.check(label).id,
            name=working_name,
            data_type="boolean",
            column_type="validation",
            schema=source_column.schema,
            stage=source_column.stage,
            sensitivity=Sensitivity.NON_SENSITIVE,
            expression=expr,
            validation_rule=validation_rule,
            alias=self._params.alias,
            is_temporary=self._params.is_temporary,
        )

    def expression(
        self, source_columns: list[str], alias: str, fail_value: CheckFailLevel = "fail"
    ) -> pl.Expr:
        condition = self._summary_condition(source_columns)
        return (
            pl.when(condition)
            .then(pl.lit(ROW_VALIDATION_SUCCESS_VALUE))
            .otherwise(pl.lit(fail_value))
            .alias(alias)
        )

    def _summary_condition(self, source_columns: list[str]) -> pl.Expr:
        raise NotImplementedError("Must be implemented in subclass")

    def _build_default_label(self, checks: list[BaseCheck]) -> str:
        child_labels = [
            check.params.label if check.params.label else check.method_id()
            for check in checks
        ]
        return f"{f'__{self.method_id()}__'.join(child_labels)}"

    @staticmethod
    def _is_compound() -> bool:
        return True

    @classmethod
    def _init_kwargs_from_spec(cls, data: dict) -> dict:
        from ....schema._utils.serialise._decode_registry import CHECK_VARIANTS

        children_data = (data.get("params") or {}).get("checks", [])
        children: list[BaseCheck] = []
        for child_data in children_data:
            child_id = child_data.get("check")
            if child_id not in CHECK_VARIANTS:
                raise CheckConfigurationError(
                    f"Unknown check variant in compound spec: {child_id!r}"
                )
            child_cls = CHECK_VARIANTS[child_id]
            children.append(child_cls.from_spec(child_data))
        return {
            **cls._wrapper_kwargs_from_spec(data, include_check_on_cleaned=False),
            "checks": children,
        }


class CheckAll(_BaseCompoundCheck):
    SPEC = CheckSpec(id=RowCheckType.ALL.value, params=_CompoundParams)

    def _summary_condition(self, source_columns: list[str]) -> pl.Expr:
        return pl.all_horizontal(
            *[
                pl.col(source_column).eq(ROW_VALIDATION_SUCCESS_VALUE)
                for source_column in source_columns
            ]
        )


class CheckAny(_BaseCompoundCheck):
    SPEC = CheckSpec(id=RowCheckType.ANY.value, params=_CompoundParams)

    def _summary_condition(self, source_columns: list[str]) -> pl.Expr:
        return pl.any_horizontal(
            *[
                pl.col(source_column).eq(ROW_VALIDATION_SUCCESS_VALUE)
                for source_column in source_columns
            ]
        )


class CheckXor(_BaseCompoundCheck):
    SPEC = CheckSpec(id=RowCheckType.XOR.value, params=_CompoundParams)

    def _summary_condition(self, source_columns: list[str]) -> pl.Expr:
        return (
            pl.sum_horizontal(
                *[
                    pl.col(source_column).eq(ROW_VALIDATION_SUCCESS_VALUE).cast(pl.Int8)
                    for source_column in source_columns
                ]
            )
            == 1
        )
