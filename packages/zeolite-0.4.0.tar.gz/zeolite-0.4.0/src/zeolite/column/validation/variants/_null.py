# %%
from dataclasses import dataclass
from typing import Optional

import polars as pl

from .._utils.types import RowCheckType
from .._base import BaseCheck, CheckFailLevel, CheckSpec, ThresholdType, _CheckParams
from .._utils.data_checks import ROW_VALIDATION_SUCCESS_VALUE
from ...._utils.sanitise import full_sanitise_string_col
from ....types.validation.threshold import CheckThreshold


# %%


@dataclass(frozen=True, kw_only=True)
class _EmptyParams(_CheckParams):
    treat_empty_strings_as_null: bool


class _BaseNullCheck(BaseCheck):
    _is_inverse: bool = False

    def __init__(
        self,
        *,
        treat_empty_strings_as_null: bool = True,
        remove_row_on_fail: bool = False,
        alias: str | None = None,
        check_on_cleaned: bool = False,
        thresholds: ThresholdType = None,
        debug: Optional[CheckThreshold] = None,
        warning: Optional[CheckThreshold] = None,
        error: Optional[CheckThreshold] = None,
        reject: Optional[CheckThreshold] = None,
        message: str,
    ):
        super().__init__(
            remove_row_on_fail=remove_row_on_fail,
            alias=alias,
            check_on_cleaned=check_on_cleaned,
            message=message,
            thresholds=thresholds,
            debug=debug,
            warning=warning,
            error=error,
            reject=reject,
        )
        self._params = self._create_extended_params(
            _EmptyParams,
            treat_empty_strings_as_null=treat_empty_strings_as_null,
        )

    def _empty_condition(self, source_column: str) -> pl.Expr:
        if not self._params.treat_empty_strings_as_null:
            return pl.col(source_column).is_null()

        return pl.col(source_column).is_null() | full_sanitise_string_col(
            source_column
        ).str.len_chars().eq(0)

    def expression(
        self, source_column: str, alias: str, fail_value: CheckFailLevel = "fail"
    ) -> pl.Expr:
        empty_condition = self._empty_condition(source_column)
        passes = ~empty_condition if self._is_inverse else empty_condition

        return (
            pl.when(passes)
            .then(pl.lit(ROW_VALIDATION_SUCCESS_VALUE))
            .otherwise(pl.lit(fail_value))
            .alias(alias)
        )


class CheckIsNull(_BaseNullCheck):
    SPEC = CheckSpec(id=RowCheckType.IS_NULL.value, params=_EmptyParams)

    """
    Validation check: Ensures that column values are null or empty.

    Parameters:
        treat_empty_strings_as_null (bool): Whether to treat empty strings as null.

        remove_row_on_fail (bool): Whether to exclude rows with non-null values.
        check_on_cleaned (bool): Whether to check on cleaned column or the original.

        thresholds (Threshold): Thresholds for error capturing when the table is processed.
        warning (CheckThreshold): Warning threshold (used when no thresholds are provided).
        error (CheckThreshold): Error threshold (used when no thresholds are provided).
        reject (CheckThreshold): Reject threshold (used when no thresholds are provided).

        message (str): Error message template.
    """

    def __init__(
        self,
        *,
        treat_empty_strings_as_null: bool = True,
        remove_row_on_fail: bool = False,
        alias: str | None = None,
        check_on_cleaned: bool = False,
        thresholds: ThresholdType = None,
        debug: Optional[CheckThreshold] = None,
        warning: Optional[CheckThreshold] = None,
        error: Optional[CheckThreshold] = None,
        reject: Optional[CheckThreshold] = None,
        message: str = "{{column}} has {{count}} non-null (non-empty) value(s) ({{fraction}})",
    ):
        super().__init__(
            treat_empty_strings_as_null=treat_empty_strings_as_null,
            remove_row_on_fail=remove_row_on_fail,
            alias=alias,
            check_on_cleaned=check_on_cleaned,
            thresholds=thresholds,
            debug=debug,
            warning=warning,
            error=error,
            reject=reject,
            message=message,
        )


class CheckIsNotNull(_BaseNullCheck):
    """
    Validation check: Ensures that column values are not empty or null.

    Parameters:
        treat_empty_strings_as_null (bool): Whether to treat empty strings as null.

        remove_row_on_fail (bool): Whether to exclude rows with empty values.
        check_on_cleaned (bool): Whether to check on cleaned column or the original.

        thresholds (Threshold): Thresholds for error capturing when the table is processed.
        warning (CheckThreshold): Warning threshold (used when no thresholds are provided).
        error (CheckThreshold): Error threshold (used when no thresholds are provided).
        reject (CheckThreshold): Reject threshold (used when no thresholds are provided).

        message (str): Error message template.
    """

    _is_inverse = True
    SPEC = CheckSpec(id=RowCheckType.IS_NOT_NULL.value, params=_EmptyParams)

    def __init__(
        self,
        *,
        treat_empty_strings_as_null: bool = True,
        remove_row_on_fail: bool = False,
        alias: str | None = None,
        check_on_cleaned: bool = False,
        thresholds: ThresholdType = None,
        debug: Optional[CheckThreshold] = None,
        warning: Optional[CheckThreshold] = None,
        error: Optional[CheckThreshold] = None,
        reject: Optional[CheckThreshold] = None,
        message: str = "{{column}} has {{count}} null (empty) value(s) ({{fraction}})",
    ):
        super().__init__(
            treat_empty_strings_as_null=treat_empty_strings_as_null,
            remove_row_on_fail=remove_row_on_fail,
            alias=alias,
            check_on_cleaned=check_on_cleaned,
            thresholds=thresholds,
            debug=debug,
            warning=warning,
            error=error,
            reject=reject,
            message=message,
        )
