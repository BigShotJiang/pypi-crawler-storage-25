# %%
from dataclasses import dataclass
from typing import Optional, Callable

import polars as pl

from .._utils.types import RowCheckType
from .._base import BaseCheck, CheckFailLevel, CheckSpec, ThresholdType, _CheckParams
from .._utils.data_checks import (
    ROW_VALIDATION_SUCCESS_VALUE,
)
from ....types.validation.threshold import CheckThreshold
from ....exceptions import CheckConfigurationError


# %%


@dataclass(frozen=True, kw_only=True)
class _CustomParams(_CheckParams):
    function: Callable[[pl.Expr], pl.Expr] | pl.Expr

    def __post_init__(self):
        if not callable(self.function) and not isinstance(self.function, pl.Expr):
            raise CheckConfigurationError(
                "A function or Polars Expression must be provided"
            )
        if callable(self.function) and not isinstance(self.function, pl.Expr):
            if not isinstance(self.function(pl.col("test")), pl.Expr):
                raise CheckConfigurationError(
                    "Function must return a Polars Expression (pl.Expr)"
                )


class CheckCustom(BaseCheck):
    SPEC = CheckSpec(
        id=RowCheckType.CUSTOM.value,
        params=_CustomParams,
        callables=frozenset({"function"}),
        user_label=True,
    )

    _required_args = {"function", "label"}
    """
    Custom Validation check: Executes a custom expression to create a validation/check column.

    Parameters:
        function (Callable[[Expr], Expr] | Expr): Polars expression or callable/lambda that takes (source_col: pl.Expr) and returns a pl.Expr.

        remove_row_on_fail (bool): Whether to exclude rows with empty values.
        check_on_cleaned (bool): Whether to check on cleaned column or the original.

        thresholds (Threshold): Thresholds for error capturing when the table is processed.
        warning (CheckThreshold): Warning threshold (used when no thresholds are provided).
        error (CheckThreshold): Error threshold (used when no thresholds are provided).
        reject (CheckThreshold): Reject threshold (used when no thresholds are provided).

        message (str): Error message template.
    """

    def __init__(
        self,
        function: Callable[[pl.Expr], pl.Expr] | pl.Expr,
        *,
        # --------------------------------------------
        label: str,
        remove_row_on_fail: bool = False,
        alias: str | None = None,
        check_on_cleaned: bool = False,
        thresholds: ThresholdType = None,
        debug: Optional[CheckThreshold] = None,
        warning: Optional[CheckThreshold] = None,
        error: Optional[CheckThreshold] = None,
        reject: Optional[CheckThreshold] = None,
        message: str = "{{column}} has {{count}} failed value(s) ({{fraction}})",
    ):
        if label is None:
            raise CheckConfigurationError("Label must be provided")

        # assert json.loads(function.meta.serialize(format="json")).get("BinaryExpr") is not None

        super().__init__(
            remove_row_on_fail=remove_row_on_fail,
            alias=alias,
            check_on_cleaned=check_on_cleaned,
            message=message,
            thresholds=thresholds,
            debug=debug,
            warning=warning,
            error=error,
            reject=reject,
            label=label,
        )
        self._params = self._create_extended_params(
            _CustomParams,
            function=function,
        )

    def expression(
        self, source_column: str, alias: str, fail_value: CheckFailLevel = "fail"
    ) -> pl.Expr:
        if isinstance(self._params.function, pl.Expr):
            expr = self._params.function
        else:
            expr = self._params.function(pl.col(source_column))

        return (
            pl.when(expr)
            .then(pl.lit(ROW_VALIDATION_SUCCESS_VALUE))
            .otherwise(pl.lit(fail_value))
            .alias(alias)
        )

    @classmethod
    def _decode_field(cls, field_name: str, raw):
        from ....exceptions import SchemaConfigurationError
        from ...._utils.serialise.common import deserialize_expr

        if field_name == "function":
            if not isinstance(raw, dict):
                raise SchemaConfigurationError(
                    f"Cannot decode 'function' from spec: expected a serialised "
                    f"pl.Expr, got {type(raw).__name__!r}. Custom Python "
                    f"callables cannot round-trip; the original schema must "
                    f"serialise the function as a pl.Expr."
                )
            return deserialize_expr(raw)
        return super()._decode_field(field_name, raw)
