# %%
from dataclasses import dataclass
from typing import Optional

import polars as pl

from .._utils.types import RowCheckType
from .._base import BaseCheck, CheckFailLevel, CheckSpec, ThresholdType, _CheckParams
from .._utils.data_checks import (
    ROW_VALIDATION_SUCCESS_VALUE,
)
from ....types.validation.threshold import CheckThreshold


# %%
@dataclass(frozen=True, kw_only=True)
class _DateCheckParams(_CheckParams):
    nulls_valid: bool = False


class CheckIsValidDate(BaseCheck):
    SPEC = CheckSpec(id=RowCheckType.IS_VALID_DATE.value, params=_DateCheckParams)

    """
    Validation check: Ensures that column values are valid dates - essentially checks
    for nulls in a date data-type column.

    Parameters:
        nulls_valid (bool): Whether null values should count as valid dates.
        remove_row_on_fail (bool): Whether to exclude rows with empty values.
        check_on_cleaned (bool): Whether to check on cleaned column or the original.
        thresholds (Threshold): Thresholds for error capturing when the table is processed.
        warning (CheckThreshold): Warning threshold (used when no thresholds are provided).
        error (CheckThreshold): Error threshold (used when no thresholds are provided).
        reject (CheckThreshold): Reject threshold (used when no thresholds are provided).
        message (str): Error message template.
    """

    def __init__(
        self,
        *,
        check_on_cleaned: bool = False,
        nulls_valid: bool = False,
        # --------------------------------------------
        remove_row_on_fail: bool = False,
        alias: str | None = None,
        thresholds: ThresholdType = None,
        debug: Optional[CheckThreshold] = None,
        warning: Optional[CheckThreshold] = None,
        error: Optional[CheckThreshold] = None,
        reject: Optional[CheckThreshold] = None,
        message: str = "{{column}} has {{count}} row(s) with invalid date format ({{fraction}})",
    ):
        super().__init__(
            remove_row_on_fail=remove_row_on_fail,
            alias=alias,
            check_on_cleaned=check_on_cleaned,
            message=message,
            thresholds=thresholds,
            debug=debug,
            warning=warning,
            error=error,
            reject=reject,
        )
        self._params = self._create_extended_params(
            _DateCheckParams,
            nulls_valid=nulls_valid,
        )

    def expression(
        self, source_column: str, alias: str, fail_value: CheckFailLevel = "fail"
    ) -> pl.Expr:
        check_exp = pl.col(source_column).cast(pl.Date, strict=False).is_not_null()
        if self._params.nulls_valid:
            check_exp = pl.col(source_column).is_null().or_(check_exp)

        return (
            pl.when(check_exp)
            .then(pl.lit(ROW_VALIDATION_SUCCESS_VALUE))
            .otherwise(pl.lit(fail_value))
            .alias(alias)
        )
