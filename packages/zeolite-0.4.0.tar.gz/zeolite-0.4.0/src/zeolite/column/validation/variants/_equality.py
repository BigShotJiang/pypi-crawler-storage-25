from dataclasses import dataclass
from typing import Optional

import polars as pl

from .._utils.types import RowCheckType
from .._base import BaseCheck, CheckFailLevel, CheckSpec, ThresholdType, _CheckParams
from .._utils.data_checks import (
    ROW_VALIDATION_SUCCESS_VALUE,
)
from ....types.validation.threshold import CheckThreshold


# %%
@dataclass(frozen=True, kw_only=True)
class _ValueMatchParams(_CheckParams):
    value: str | int | float | bool
    nulls_valid: bool = False


class _BaseEqualityCheck(BaseCheck):
    """
    Base class for equality-based validation checks.
    """

    _required_args = {"value"}
    _is_inverse = False

    def __init__(
        self,
        value: str | int | float | bool,
        *,
        message: Optional[str] = None,
        is_inverse: bool = False,
        nulls_valid: bool = False,
        **kwargs,
    ):
        if message is None:
            message = (
                "{{column}} has {{count}} row(s) not equal to `{{match_value}}` ({{fraction}})"
                if not is_inverse
                else "{{column}} has {{count}} row(s) equal to `{{match_value}}` ({{fraction}})"
            )

        super().__init__(
            **kwargs,
            message=message.replace("{{match_value}}", str(value)),
            label=f"{self.method_id()}_{value}".lower().replace(" ", "_"),
        )
        self._params = self._create_extended_params(
            _ValueMatchParams,
            value=value,
            nulls_valid=nulls_valid,
        )

    def expression(
        self, source_column: str, alias: str, fail_value: CheckFailLevel = "fail"
    ) -> pl.Expr:
        check_exp = pl.col(source_column).eq(self._params.value)

        if self._is_inverse:
            if not self._params.nulls_valid:
                check_exp = pl.col(source_column).is_null().or_(check_exp)
            return (
                pl.when(check_exp)
                .then(pl.lit(fail_value))
                .otherwise(pl.lit(ROW_VALIDATION_SUCCESS_VALUE))
                .alias(alias)
            )

        else:
            if self._params.nulls_valid:
                check_exp = pl.col(source_column).is_null().or_(check_exp)
            return (
                pl.when(check_exp)
                .then(pl.lit(ROW_VALIDATION_SUCCESS_VALUE))
                .otherwise(pl.lit(fail_value))
                .alias(alias)
            )


class CheckIsEqualTo(_BaseEqualityCheck):
    SPEC = CheckSpec(id=RowCheckType.IS_EQUAL_TO.value, params=_ValueMatchParams)

    """
    Validation check: Ensures that column values are equal to a specified value. This will
    throw an error if the value IS NOT FOUND in the column.

    Parameters:
        value (str | int | float | bool): The value to check against.
        nulls_valid (bool): Whether null values should also count as passing values.
        remove_row_on_fail (bool): Whether to exclude rows with empty values.
        check_on_cleaned (bool): Whether to check on cleaned column or the original.
        thresholds (Threshold): Thresholds for error capturing when the table is processed.
        warning (CheckThreshold): Warning threshold (used when no thresholds are provided).
        error (CheckThreshold): Error threshold (used when no thresholds are provided).
        reject (CheckThreshold): Reject threshold (used when no thresholds are provided).
        message (str): Error message template.
    """

    def __init__(
        self,
        value: str | int | float | bool,
        *,
        nulls_valid: bool = False,
        remove_row_on_fail: bool = False,
        check_on_cleaned: bool = False,
        alias: str | None = None,
        thresholds: ThresholdType = None,
        debug: Optional[CheckThreshold] = None,
        warning: Optional[CheckThreshold] = None,
        error: Optional[CheckThreshold] = None,
        reject: Optional[CheckThreshold] = None,
        message: Optional[str] = None,
    ):
        super().__init__(
            value=value,
            is_inverse=False,
            nulls_valid=nulls_valid,
            remove_row_on_fail=remove_row_on_fail,
            check_on_cleaned=check_on_cleaned,
            alias=alias,
            thresholds=thresholds,
            debug=debug,
            warning=warning,
            error=error,
            reject=reject,
            message=message,
        )


class CheckIsNotEqualTo(_BaseEqualityCheck):
    _is_inverse = True
    SPEC = CheckSpec(id=RowCheckType.IS_NOT_EQUAL_TO.value, params=_ValueMatchParams)

    """
    Validation check: Ensures that column values are not equal to a specified value. This will
    throw an error if the value IS FOUND in the column.

    Parameters:
        value (str | int | float | bool): The value to check against.
        nulls_valid (bool): Whether null values should count as not equal to the target value.
        remove_row_on_fail (bool): Whether to exclude rows with empty values.
        check_on_cleaned (bool): Whether to check on cleaned column or the original.
        thresholds (Threshold): Thresholds for error capturing when the table is processed.
        warning (CheckThreshold): Warning threshold (used when no thresholds are provided).
        error (CheckThreshold): Error threshold (used when no thresholds are provided).
        reject (CheckThreshold): Reject threshold (used when no thresholds are provided).
        message (str): Error message template.
    """

    def __init__(
        self,
        value: str | int | float | bool,
        *,
        nulls_valid: bool = True,
        remove_row_on_fail: bool = False,
        check_on_cleaned: bool = False,
        alias: str | None = None,
        thresholds: ThresholdType = None,
        debug: Optional[CheckThreshold] = None,
        warning: Optional[CheckThreshold] = None,
        error: Optional[CheckThreshold] = None,
        reject: Optional[CheckThreshold] = None,
        message: Optional[str] = None,
    ):
        super().__init__(
            value=value,
            is_inverse=True,
            nulls_valid=nulls_valid,
            remove_row_on_fail=remove_row_on_fail,
            check_on_cleaned=check_on_cleaned,
            alias=alias,
            thresholds=thresholds,
            debug=debug,
            warning=warning,
            error=error,
            reject=reject,
            message=message,
        )
