from dataclasses import dataclass
from typing import Callable

import polars as pl

from ._base import CleanColumn, CleanSpec, _CleanParams
from ...exceptions import CleanConfigurationError
from ...types.data_type import ColumnDataType
from ...types.sensitivity import Sensitivity


# %%-----------------------------------------------------------------
# Custom Clean Column
# ------------------------------------------------------------------
@dataclass(frozen=True, kw_only=True)
class _CustomCleanParams(_CleanParams):
    function: Callable[[pl.Expr], pl.Expr] | pl.Expr

    def __post_init__(self):
        if not callable(self.function) and not isinstance(self.function, pl.Expr):
            raise CleanConfigurationError(
                "A function or Polars Expression must be provided"
            )
        if callable(self.function) and not isinstance(self.function, pl.Expr):
            if not isinstance(self.function(pl.col("test")), pl.Expr):
                raise CleanConfigurationError(
                    "function must return a Polars Expression (pl.Expr)"
                )


class CustomCleanColumn(CleanColumn):
    """
    Custom cleaning column that allows users to define their own cleaning logic.

    Parameters:
        function: Polars expression or callable that takes (source_col: pl.Expr) and returns a pl.Expr.
        data_type: Data type of the cleaned column (default: "unknown")
        col_sensitivity: Optional sensitivity level for the cleaned column
        alias: Optional alias for the cleaned column output
    """

    _required_args = {"function"}
    SPEC = CleanSpec(params=_CustomCleanParams, callables=frozenset({"function"}))

    def __init__(
        self,
        function: Callable[[pl.Expr], pl.Expr] | pl.Expr,
        *,
        data_type: ColumnDataType = "unknown",
        col_sensitivity: Sensitivity | None = None,
        alias: str | None = None,
    ):
        super().__init__(
            data_type=data_type,
            col_sensitivity=col_sensitivity,
            alias=alias,
        )
        self._params = self._create_extended_params(
            _CustomCleanParams,
            function=function,
        )

    def clean_expr(self, source: str, alias: str) -> pl.Expr:
        if isinstance(self._params.function, pl.Expr):
            expr = self._params.function
        else:
            expr = self._params.function(pl.col(source))
        return expr.alias(alias)
