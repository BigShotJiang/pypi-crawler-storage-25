from dataclasses import dataclass, field, fields, KW_ONLY, asdict, replace
from inspect import Parameter, signature
from typing import Any, ClassVar, TypeVar
import polars as pl

from ..._utils.serialise.helpers import (
    CleanSpec,
    EncodeContext,
    decode_value,
    encode_value,
    materialise_callable,
)
from ...exceptions import CleanConfigurationError, SchemaConfigurationError
from ...ref import ColumnRef
from ...types.data_type import ColumnDataType
from ...types.sensitivity import Sensitivity


def _get_column_names(source: "ColumnRef") -> tuple[str, str]:
    source_column = source.name
    # alias = self.alias if self.alias is not None else source.clean().name
    alias = source.clean().name
    return source_column, alias


@dataclass(frozen=True, kw_only=True)
class _CleanParams:
    _: KW_ONLY
    data_type: ColumnDataType = field(default="string")
    col_sensitivity: Sensitivity | None = field(default=None)
    alias: str | None = field(default=None)
    is_temporary: bool | None = field(default=None)


_CLEAN_BASE_FIELDS = frozenset(f.name for f in fields(_CleanParams))


T = TypeVar("T", bound="_CleanParams")


class CleanColumn:
    _registry: ClassVar[dict[str, type["CleanColumn"]]] = {}
    _required_args: set[str] = set()
    SPEC: ClassVar[CleanSpec] = CleanSpec(params=_CleanParams)

    def __init_subclass__(cls, **kwargs):
        super().__init_subclass__(**kwargs)
        spec = cls.__dict__.get("SPEC")
        if spec is not None:
            CleanColumn._registry[spec.method or cls.__name__] = cls

    def __init__(
        self,
        *,
        data_type: ColumnDataType,
        col_sensitivity: Sensitivity | None = None,
        alias: str | None = None,
        is_temporary: bool | None = None,
    ):
        self._params = _CleanParams(
            data_type=data_type,
            col_sensitivity=col_sensitivity,
            alias=alias,
            is_temporary=is_temporary,
        )

    def alias(self, alias: str, *, is_temporary: bool | None = None):
        if is_temporary is None:
            return self._replace(alias=alias, is_temporary=False)
        else:
            return self._replace(alias=alias, is_temporary=is_temporary)

    def temporary(self, is_temporary: bool = True):
        return self._replace(is_temporary=is_temporary)

    @property
    def params(self) -> _CleanParams:
        return self._params

    def clean_ref(self, source: "ColumnRef") -> "ColumnRef":
        return source.clean()

    def get_alias(self, source: "ColumnRef") -> str:
        return self._params.alias if self._params.alias is not None else source.name

    def clean_expr(self, source: str, alias: str) -> pl.Expr:
        return pl.col(source).cast(pl.String).alias(alias)

    def apply(self, source: "ColumnRef") -> pl.Expr:
        source_column, alias = _get_column_names(source)
        return self.clean_expr(source_column, alias)

    def _create_extended_params(self, params_class: type[T], **extra_params) -> T:
        base_params = {k: v for k, v in asdict(self._params).items()}
        return params_class(
            **{**base_params, **extra_params},
        )

    def _replace(self, **kwargs):
        new_params = replace(self._params, **kwargs)

        args = {}
        for arg in self._required_args:
            if hasattr(new_params, arg):
                args[arg] = getattr(new_params, arg)
            elif hasattr(self, arg):
                args[arg] = getattr(self, arg)
            else:
                raise CleanConfigurationError(f"Required argument '{arg}' not found")

        return self.__class__(**args)._set_params(new_params)

    def _set_params(self, params: _CleanParams) -> "CleanColumn":
        self._params = params
        return self

    # --- Serialisation hooks ------------------------------------------------

    def _is_derived(self, field_name: str) -> bool:
        return field_name in self.SPEC.derived

    def _callable_bound_column(self, ctx: EncodeContext) -> str | None:
        return ctx.bound_column

    def _encode_field(self, field_name: str, value: Any, ctx: EncodeContext) -> Any:
        if (
            field_name in self.SPEC.callables
            and callable(value)
            and not isinstance(value, pl.Expr)
        ):
            value = materialise_callable(
                value, self._callable_bound_column(ctx), field_label=field_name
            )
        return encode_value(value)

    @classmethod
    def _decode_field(cls, field_name: str, raw: Any) -> Any:
        return decode_value(raw)

    @classmethod
    def _decode_wrapper_field(cls, field_name: str, raw: Any) -> Any:
        if field_name == "col_sensitivity":
            return None if raw is None else Sensitivity(raw)
        return raw

    def to_spec(self, ctx: EncodeContext | None = None) -> dict:
        ctx = ctx or EncodeContext()
        p = self._params
        out: dict[str, Any] = {
            "data_type": self._encode_field("data_type", p.data_type, ctx),
            "sensitivity": self._encode_field(
                "col_sensitivity", p.col_sensitivity, ctx
            ),
            "alias": self._encode_field("alias", p.alias, ctx),
            "temporary": self._encode_field("is_temporary", p.is_temporary, ctx),
        }
        variant_params: dict[str, Any] = {}

        for f in fields(p):
            if f.name in _CLEAN_BASE_FIELDS or self._is_derived(f.name):
                continue
            variant_params[f.name] = self._encode_field(f.name, getattr(p, f.name), ctx)

        out["params"] = variant_params
        return out

    @classmethod
    def from_spec(cls, data: dict) -> "CleanColumn":
        instance = cls(**cls._init_kwargs_from_spec(data))
        if "temporary" in data:
            instance = instance.temporary(data["temporary"])
        return instance

    @classmethod
    def _init_kwargs_from_spec(cls, data: dict) -> dict[str, Any]:
        return cls._filter_init_kwargs(
            {
                **cls._wrapper_kwargs_from_spec(data, include_data_type=True),
                **cls._variant_kwargs_from_spec(data),
            }
        )

    @classmethod
    def _filter_init_kwargs(cls, kwargs: dict[str, Any]) -> dict[str, Any]:
        params = signature(cls.__init__).parameters
        if any(p.kind == Parameter.VAR_KEYWORD for p in params.values()):
            return kwargs
        unexpected = {
            key for key in kwargs if key not in params and key not in _CLEAN_BASE_FIELDS
        }
        if unexpected:
            raise SchemaConfigurationError(
                f"{cls.__name__} cannot decode the following fields: "
                f"{', '.join(sorted(unexpected))}"
            )
        return {k: v for k, v in kwargs.items() if k in params}

    @classmethod
    def _wrapper_kwargs_from_spec(
        cls, data: dict, *, include_data_type: bool = False
    ) -> dict[str, Any]:
        kwargs: dict[str, Any] = {
            "col_sensitivity": cls._decode_wrapper_field(
                "col_sensitivity", data.get("sensitivity")
            ),
            "alias": data.get("alias"),
        }
        if include_data_type:
            kwargs["data_type"] = data.get("data_type")
        return kwargs

    @classmethod
    def _variant_kwargs_from_spec(cls, data: dict) -> dict[str, Any]:
        param_field_names = {f.name for f in fields(cls.SPEC.params)}
        kwargs: dict[str, Any] = {}
        for wire_name, raw in (data.get("params") or {}).items():
            if (
                wire_name in param_field_names
                and wire_name not in _CLEAN_BASE_FIELDS
                and wire_name not in cls.SPEC.derived
            ):
                kwargs[wire_name] = cls._decode_field(wire_name, raw)
        return kwargs
