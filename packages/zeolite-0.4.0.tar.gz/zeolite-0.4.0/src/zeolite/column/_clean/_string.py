from dataclasses import dataclass

import polars as pl

from ._base import CleanColumn, CleanSpec, _CleanParams
from ...types import ColumnDataType
from ...types.sensitivity import Sensitivity
from ..._utils.sanitise import SanitiseLevelType, SanitiseLevel, sanitise_string_col
from ...exceptions import CleanConfigurationError


# %%-----------------------------------------------------------------
# String Cleans
# ------------------------------------------------------------------


@dataclass(frozen=True, kw_only=True)
class _StringParams(_CleanParams):
    sanitise: SanitiseLevelType | None
    sanitise_join_char: str | None

    def __post_init__(self):
        if self.sanitise is not None and self.sanitise not in SanitiseLevel:
            raise CleanConfigurationError(
                f"sanitise must be one of "
                f"{', '.join(f"'{s}'" for s in SanitiseLevel)} or None. "
                f"Received {self.sanitise}"
            )


class CleanStringColumn(CleanColumn):
    SPEC = CleanSpec(params=_StringParams)

    def __init__(
        self,
        *,
        sanitise: SanitiseLevelType | None = None,
        sanitise_join_char: str = "_",
        col_sensitivity: Sensitivity | None = None,
        alias: str | None = None,
        data_type: ColumnDataType = None,
    ):
        super().__init__(
            data_type=data_type or "string" if sanitise is None else "sanitised_string",
            col_sensitivity=col_sensitivity,
            alias=alias,
        )
        self._params = self._create_extended_params(
            _StringParams,
            sanitise=sanitise,
            sanitise_join_char=sanitise_join_char,
        )

    def _sanitise(self, source_column: str | pl.Expr) -> pl.Expr:
        return sanitise_string_col(
            source_column,
            sanitise_level=self._params.sanitise,
            join_char=self._params.sanitise_join_char,
        )

    def clean_expr(self, source_column: str, alias: str) -> pl.Expr:
        return self._sanitise(source_column).alias(alias)


class CleanSanitisedStringColumn(CleanStringColumn):
    _required_args = {"sanitise"}
    SPEC = CleanSpec(params=_StringParams)

    def __init__(
        self,
        *,
        sanitise: SanitiseLevelType = "full",
        sanitise_join_char: str = "_",
        col_sensitivity: Sensitivity | None = None,
        alias: str | None = None,
    ):
        if sanitise not in SanitiseLevel:
            raise CleanConfigurationError(
                f"sanitise must be one of {', '.join(f"'{s}'" for s in SanitiseLevel)}. Received {sanitise}"
            )

        super().__init__(
            data_type="sanitised_string",
            sanitise=sanitise,
            sanitise_join_char=sanitise_join_char,
            col_sensitivity=col_sensitivity,
            alias=alias,
        )
