from dataclasses import dataclass

from typing import Any
import polars as pl

from ._base import CleanColumn, CleanSpec, _CleanParams
from ...types.sensitivity import Sensitivity
from ..._utils.serialise.common import decode_dtype


# %%-----------------------------------------------------------------
# Number Cleans
# ------------------------------------------------------------------
@dataclass(frozen=True, kw_only=True)
class _NumberParams(_CleanParams):
    output_format: type[pl.Int64 | pl.Float64]


def _clean_float(
    name: str,
    *,
    thousand_separator=",",
    output_format: pl.Float64 | pl.Decimal = pl.Float64,
) -> pl.Expr:
    return (
        pl.col(name)
        .cast(pl.String, strict=False)
        .str.replace_all(" ", "")
        .str.replace_all(thousand_separator, "")
        .cast(output_format, strict=False)
    )


class CleanNumberColumn(CleanColumn):
    SPEC = CleanSpec(params=_NumberParams)

    def __init__(
        self,
        *,
        output_format: type[pl.Int64 | pl.Float64] = pl.Float64,
        col_sensitivity: Sensitivity | None = None,
        alias: str | None = None,
    ):
        super().__init__(
            data_type="integer" if output_format == pl.Int64 else "float",
            col_sensitivity=col_sensitivity,
            alias=alias,
        )
        self._params = self._create_extended_params(
            _NumberParams,
            output_format=output_format,
        )

    def clean_expr(self, source_column: str, alias: str) -> pl.Expr:
        output = self._params.output_format
        expr = _clean_float(source_column)

        if output == pl.Float64:
            return expr.fill_nan(None).alias(alias)
        elif output == pl.Int64:
            return expr.round(0).cast(pl.Int64).alias(alias)
        else:
            return (
                pl.col(source_column)
                .cast(output, strict=False)
                .fill_nan(None)
                .alias(alias)
            )

    @classmethod
    def _decode_field(cls, field_name: str, raw: Any) -> Any:
        if field_name == "output_format":
            return decode_dtype(raw) if raw is not None else pl.Float64
        return super()._decode_field(field_name, raw)


class CleanIntegerColumn(CleanNumberColumn):
    SPEC = CleanSpec(params=_NumberParams, derived=frozenset({"output_format"}))

    def __init__(
        self,
        *,
        col_sensitivity: Sensitivity | None = None,
        alias: str | None = None,
    ):
        super().__init__(
            output_format=pl.Int64, col_sensitivity=col_sensitivity, alias=alias
        )


@dataclass(frozen=True, kw_only=True)
class _DecimalParams(_CleanParams):
    decimal_places: int


class CleanDecimalColumn(CleanColumn):
    SPEC = CleanSpec(params=_DecimalParams)

    def __init__(
        self,
        *,
        decimal_places: int = 2,
        col_sensitivity: Sensitivity | None = None,
        alias: str | None = None,
    ):
        super().__init__(
            data_type="decimal", col_sensitivity=col_sensitivity, alias=alias
        )
        self._params = self._create_extended_params(
            _DecimalParams,
            decimal_places=decimal_places,
        )

    def clean_expr(self, source_column: str, alias: str) -> pl.Expr:
        return _clean_float(
            source_column, output_format=pl.Decimal(None, self._params.decimal_places)
        ).alias(alias)
