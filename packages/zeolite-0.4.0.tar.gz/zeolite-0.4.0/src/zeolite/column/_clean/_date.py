from dataclasses import dataclass

from typing import Any, Literal
import polars as pl

from ._base import CleanColumn, CleanSpec, _CleanParams
from ..._utils.parse_dates import mega_date_handler
from ...exceptions import CleanConfigurationError
from ...types.sensitivity import Sensitivity
from ..._utils.serialise.common import decode_dtype


# %%-----------------------------------------------------------------
# Date Cleans
# ------------------------------------------------------------------
@dataclass(frozen=True, kw_only=True)
class _DateParams(_CleanParams):
    output_format: pl.Date | pl.Datetime
    day_first: bool

    def __post_init__(self):
        if self.output_format not in [pl.Date, pl.Datetime]:
            raise CleanConfigurationError(
                "output_format must be either pl.Date or pl.Datetime"
            )


class CleanDateColumn(CleanColumn):
    SPEC = CleanSpec(params=_DateParams)

    def __init__(
        self,
        *,
        output_format: pl.Date | pl.Datetime = pl.Date,
        day_first: bool = True,
        col_sensitivity: Sensitivity | None = None,
        alias: str | None = None,
    ):
        super().__init__(
            data_type="date" if output_format == pl.Date else "datetime",
            col_sensitivity=col_sensitivity,
            alias=alias,
        )
        self._params = self._create_extended_params(
            _DateParams,
            output_format=output_format,
            day_first=day_first,
        )

    def clean_expr(self, source_column: str, alias: str) -> pl.Expr:
        return mega_date_handler(
            source_column,
            alias=alias,
            output_format=self._params.output_format,
            day_first=self._params.day_first,
        )

    @classmethod
    def _decode_field(cls, field_name: str, raw: Any) -> Any:
        if field_name == "output_format":
            return decode_dtype(raw) if raw is not None else pl.Date
        return super()._decode_field(field_name, raw)


class CleanDatetimeColumn(CleanDateColumn):
    SPEC = CleanSpec(
        params=_DateParams, derived=frozenset({"output_format", "day_first"})
    )

    def __init__(
        self,
        *,
        col_sensitivity: Sensitivity | None = None,
        alias: str | None = None,
    ):
        super().__init__(
            output_format=pl.Datetime, col_sensitivity=col_sensitivity, alias=alias
        )


@dataclass(frozen=True, kw_only=True)
class _TimeParams(_CleanParams):
    time_format: str


class CleanTimeColumn(CleanColumn):
    SPEC = CleanSpec(params=_TimeParams)

    def __init__(
        self,
        *,
        time_format: str = "%H:%M:%S",
        col_sensitivity: Sensitivity | None = None,
        alias: str | None = None,
    ):
        super().__init__(data_type="time", col_sensitivity=col_sensitivity, alias=alias)
        self._params = self._create_extended_params(
            _TimeParams,
            time_format=time_format,
        )

    def clean_expr(self, source_column: str, alias: str) -> pl.Expr:
        return (
            pl.col(source_column)
            .cast(pl.String)
            .str.strptime(pl.Time, self._params.time_format, strict=False)
            .alias(alias)
        )


type DurationType = Literal[
    "weeks",
    "days",
    "hours",
    "minutes",
    "seconds",
    "milliseconds",
    "microseconds",
    "nanoseconds",
]


@dataclass(frozen=True, kw_only=True)
class _DurationParams(_CleanParams):
    input_unit: DurationType
    output_unit: Literal[None, "us", "ms", "ns"]


class CleanDurationColumn(CleanColumn):
    _required_args = {"input_unit"}
    SPEC = CleanSpec(params=_DurationParams)

    def __init__(
        self,
        *,
        input_unit: DurationType,
        output_unit: Literal[None, "us", "ms", "ns"] = None,
        col_sensitivity: Sensitivity | None = None,
        alias: str | None = None,
    ):
        super().__init__(
            data_type="duration", col_sensitivity=col_sensitivity, alias=alias
        )
        self._params = self._create_extended_params(
            _DurationParams,
            input_unit=input_unit,
            output_unit=output_unit,
        )

    def clean_expr(self, source_column: str, alias: str) -> pl.Expr:
        return pl.duration(
            **{self._params.input_unit: pl.col(source_column).cast(pl.Float64)},
            time_unit=self._params.output_unit,
        ).alias(alias)
