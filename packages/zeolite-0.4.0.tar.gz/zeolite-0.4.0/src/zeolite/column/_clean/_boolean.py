from dataclasses import dataclass, field

from typing import Any
import polars as pl

from ._base import CleanColumn, CleanSpec, _CleanParams
from ..._utils.sanitise import sanitise_scalar_string, full_sanitise_string_col
from ...types.sensitivity import Sensitivity
from ...exceptions import CleanConfigurationError


# %%-----------------------------------------------------------------
# Boolean Cleans
# ------------------------------------------------------------------
@dataclass(frozen=True, kw_only=True)
class _BooleanParams(_CleanParams):
    true_values: frozenset[Any] | set[Any]
    false_values: frozenset[Any] | set[Any]
    bool_map: dict[str, bool] = field(init=False, repr=False)

    def __post_init__(self):
        if not isinstance(self.true_values, (set, frozenset)):
            raise CleanConfigurationError(
                f"true_values must be a set or frozenset: {self.true_values}"
            )
        if not isinstance(self.false_values, (set, frozenset)):
            raise CleanConfigurationError(
                f"false_values must be a set or frozenset: {self.false_values}"
            )
        if len(self.true_values) == 0 and len(self.false_values) == 0:
            raise CleanConfigurationError(
                "true_values and/or false_values must be non-empty"
            )
        sanitised_true = frozenset(sanitise_scalar_string(v) for v in self.true_values)
        sanitised_false = frozenset(
            sanitise_scalar_string(v) for v in self.false_values
        )
        if any(value in sanitised_false for value in sanitised_true):
            raise CleanConfigurationError(
                f"true_values and false_values must be disjoint sets: "
                f"{sanitised_true} and {sanitised_false}"
            )
        bool_map = {
            **{val: True for val in sanitised_true},
            **{val: False for val in sanitised_false},
        }
        object.__setattr__(self, "bool_map", bool_map)


class CleanBooleanColumn(CleanColumn):
    SPEC = CleanSpec(params=_BooleanParams, derived=frozenset({"bool_map"}))

    def __init__(
        self,
        *,
        true_values: frozenset[Any] | set[Any] = frozenset({"yes", "y", "true", "1"}),
        false_values: frozenset[Any] | set[Any] = frozenset({"no", "n", "false", "0"}),
        col_sensitivity: Sensitivity | None = None,
        alias: str | None = None,
    ):
        super().__init__(
            data_type="boolean", col_sensitivity=col_sensitivity, alias=alias
        )
        self._params = self._create_extended_params(
            _BooleanParams,
            true_values=true_values,
            false_values=false_values,
        )

    def clean_expr(self, source_column: str, alias: str) -> pl.Expr:
        return (
            full_sanitise_string_col(source_column)
            .replace_strict(
                self._params.bool_map, default=None, return_dtype=pl.Boolean
            )
            .alias(alias)
        )

    @classmethod
    def _decode_field(cls, field_name: str, raw):
        if field_name in {"true_values", "false_values"} and isinstance(raw, list):
            return frozenset(raw)
        return super()._decode_field(field_name, raw)
