from dataclasses import dataclass

import polars as pl

from ._base import CleanSpec
from ._string import CleanStringColumn, _StringParams
from ..._utils.sanitise import SanitiseLevelType
from ...ref import ColumnRef
from ...types.sensitivity import Sensitivity


# %%-----------------------------------------------------------------
# Id Cleans
# ------------------------------------------------------------------
@dataclass(frozen=True, kw_only=True)
class _IdParams(_StringParams):
    prefix: ColumnRef | str | None
    separator: str


class CleanIdColumn(CleanStringColumn):
    SPEC = CleanSpec(params=_IdParams)

    def __init__(
        self,
        *,
        prefix: ColumnRef | str | None = None,
        separator: str = "::",
        sanitise: SanitiseLevelType | None = None,
        sanitise_join_char: str = "_",
        col_sensitivity: Sensitivity | None = None,
        alias: str | None = None,
    ):
        super().__init__(
            data_type="id",
            col_sensitivity=col_sensitivity,
            sanitise=sanitise,
            sanitise_join_char=sanitise_join_char,
            alias=alias,
        )
        self._params = self._create_extended_params(
            _IdParams,
            prefix=prefix,
            separator=separator,
        )

    def prefix(self, prefix: ColumnRef | str):
        self._replace(prefix=prefix)

    def clean_expr(self, source_column: str, alias: str) -> pl.Expr:
        if self._params.prefix is not None:
            prefix_expr = (
                pl.col(self._params.prefix.name).cast(pl.String).str.strip_chars()
                if isinstance(self._params.prefix, ColumnRef)
                else pl.lit(str(self._params.prefix).strip())
            ) + self._params.separator
            return (
                prefix_expr
                + self._sanitise(
                    pl.col(source_column).cast(pl.String).str.strip_prefix(prefix_expr)
                )
            ).alias(alias)
        else:
            return self._sanitise(source_column).alias(alias)
