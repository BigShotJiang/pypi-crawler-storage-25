from dataclasses import dataclass, field, replace
from typing import Optional, Literal
import polars as pl

from .data_type import ColumnDataType
from .sensitivity import Sensitivity
from .validation.threshold import ThresholdLevel
from .validation.validation_rule import ColumnValidationRule
from .error import (
    SchemaValidationError,
    FileValidationError,
    StructureValidationError,
    DataValidationError,
    TableValidationError,
    UnknownValidationError,
)

__all__ = [
    "ColumnNode",
    "ColumnDataType",
    "ColumnNodeType",
    "CoerceOption",
    "SourceColDef",
    "ValidationResult",
    "ProcessingResult",
    "ProcessingFailure",
    "ProcessingSuccess",
    "ProcessingStage",
    "SchemaValidationError",
    "FileValidationError",
    "StructureValidationError",
    "TableValidationError",
    "DataValidationError",
    "UnknownValidationError",
    "ThresholdLevel",
]

ColumnNodeType = Literal[
    "source", "cleaned", "validation", "meta", "derived", "custom_validation"
]


@dataclass(frozen=True)
class ColumnNode:
    id: str
    name: str
    data_type: str
    column_type: ColumnNodeType
    schema: str
    stage: str
    sensitivity: Sensitivity
    expression: Optional[pl.Expr] = None
    validation_rule: Optional[ColumnValidationRule] = None
    parent_columns: frozenset[str] = field(default_factory=frozenset)
    parent_ids: frozenset[str] = field(default_factory=frozenset)
    alias: Optional[str] = None
    is_temporary: bool = False

    def __post_init__(self):
        if self.expression is not None:
            assert self.name == self.expression.meta.output_name(), (
                f"Column name {self.name} does not match expression output name {self.expression.meta.output_name()}"
            )
            if len(self.parent_columns) == 0:
                object.__setattr__(
                    self,
                    "parent_columns",
                    frozenset(
                        {c for c in self.expression.meta.root_names() if c != ""}
                    ),
                )

    def with_parent_ids(self, parent_ids: frozenset[str]) -> "ColumnNode":
        return replace(self, parent_ids=parent_ids)


type CoerceOption = Literal["strict", "default", "skip"]


@dataclass(frozen=True)
class SourceColDef:
    name: str
    variants: frozenset[str]
    if_missing: ThresholdLevel
    is_meta: bool
    dtype: pl.DataType | None = None
    coerce: CoerceOption | None = None


type ProcessingStage = Literal[
    "normalise", "coerce", "prepare", "validate", "filter", "refine"
]


# Validation Results
@dataclass(frozen=True)
class ValidationResult:
    stage: ProcessingStage
    data: pl.LazyFrame
    errors: list[SchemaValidationError]
    reject: bool = False


@dataclass(frozen=True)
class ProcessingResult:
    normalised: pl.LazyFrame | None
    coerced: pl.LazyFrame | None
    prepared: pl.LazyFrame | None
    validated: pl.LazyFrame | None
    filtered: pl.LazyFrame | None
    refined: pl.LazyFrame | None
    data: pl.LazyFrame | None
    errors: list[SchemaValidationError]
    success: bool = False
    failed_stage: ProcessingStage | None = None


@dataclass(frozen=True)
class ProcessingFailure(ProcessingResult):
    success: False = False
    data: None
    failed_stage: ProcessingStage


@dataclass(frozen=True)
class ProcessingSuccess(ProcessingResult):
    normalised: pl.LazyFrame
    coerced: pl.LazyFrame
    prepared: pl.LazyFrame
    validated: pl.LazyFrame
    filtered: pl.LazyFrame
    refined: pl.LazyFrame
    data: pl.LazyFrame
    success: True = True
    failed_stage: None = None
