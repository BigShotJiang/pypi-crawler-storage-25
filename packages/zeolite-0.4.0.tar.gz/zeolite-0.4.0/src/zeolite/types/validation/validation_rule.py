from dataclasses import KW_ONLY, dataclass
import polars as pl

from .threshold import Threshold, ThresholdLevel
from ..error import DataValidationError


@dataclass(frozen=True)
class ColumnValidationRule:
    check_id: str
    _: KW_ONLY
    thresholds: Threshold
    message: str
    source_column: str
    check_column: str
    schema: str
    remove_row_on_fail: bool

    def failure_count_expr(self, alias: str) -> pl.Expr:
        return (
            pl.col(self.check_column).ne(ThresholdLevel.PASS.level).sum().alias(alias)
        )

    def validate_counts(
        self, *, total_rows: int, failed_rows: int, source: str | None = None
    ) -> DataValidationError | None:
        if failed_rows == 0:
            return None

        res = self.thresholds.resolve(failed_rows=failed_rows, total_rows=total_rows)

        return (
            DataValidationError(
                schema=self.schema,
                source=source,
                column=self.check_column,
                error=self.check_id,
                level=res.level,
                fraction_failed=res.fraction_failed,
                count_failed=res.count_failed,
                message=self._format_message(
                    self.source_column, failed_rows, total_rows
                ),
            )
            if res.level != "pass"
            else None
        )

    def validate(
        self, lf: pl.LazyFrame | pl.DataFrame, source: str | None = None
    ) -> DataValidationError | None:
        checks = (
            lf.lazy()
            .select(
                pl.len().alias("total_rows"),
                self.failure_count_expr("failed_rows"),
            )
            .collect()
        )

        total_rows = checks["total_rows"].item()
        failed_rows = checks["failed_rows"].item()
        return self.validate_counts(
            total_rows=total_rows,
            failed_rows=failed_rows,
            source=source,
        )

    def _format_message(
        self,
        col: str,
        count: int,
        total: int,
        value: str | int | float | bool | None = None,
    ) -> str:
        return (
            self.message.replace("{{column}}", f"`{col}`")
            .replace("{{count}}", f"{count:,}")
            .replace("{{fraction}}", f"{count / total:,.2%}")
        )
