from typing import Literal
import polars as pl
from polars.datatypes import DataTypeClass

type ColumnDataTypeLabel = Literal[
    "string",
    "id",
    "number",
    "integer",
    "float",
    "decimal",
    "boolean",
    "date",
    "datetime",
    "duration",
    "time",
    "enum",
    "categorical",
    "sanitised_string",
    "unknown",
]

type ColumnDataType = ColumnDataTypeLabel | pl.DataType | DataTypeClass

NO_DATA = "NO_DATA"
INVALID_DATA = "INVALID_DATA"
