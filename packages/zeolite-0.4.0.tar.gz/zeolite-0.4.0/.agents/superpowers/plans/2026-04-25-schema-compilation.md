# Schema Compilation Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Extract the 6-stage pipeline from `TableSchema` into a shared module, then build `SchemaArtifact` and `SchemaSpec` for portable, step-predefined schema serialization.

**Architecture:** `PipelineInputs` is a pure-data frozen dataclass holding pre-computed per-step inputs; `run_pipeline()` is a standalone function both `TableSchema` and `SchemaArtifact` delegate to. `SchemaArtifact` serializes each pipeline step's inputs to JSON (with Polars expression ASTs via `expr.meta.serialize()`), allowing `apply()` with zero Python construction cost on load.

**Tech Stack:** Python 3.12+, Polars, uv for package management, pytest.

---

### Task 1: Create `_pipeline.py` — data structures and `run_pipeline()`

**Files:**
- Create: `src/zeolite/schema/_pipeline.py`
- Create: `tests/unit/schema/test_pipeline.py`

- [ ] **Step 1: Write failing tests**

```python
# tests/unit/schema/test_pipeline.py
import polars as pl
import zeolite as z
from zeolite.schema._pipeline import run_pipeline, PipelineParams, PrepareEntry
from zeolite.types import SourceColDef
from zeolite.types.validation.threshold import ThresholdLevel
from zeolite.schema.validation.variants import TableCheckRemovedRows


def _simple_inputs() -> PipelineParams:
    return PipelineParams(
        schema_name="test",
        is_required=True,
        stage=None,
        strict=True,
        coerce="default_true",
        source_columns=[
            SourceColDef(name="id", variants={"id"}, if_missing=ThresholdLevel.REJECT, is_meta=False),
        ],
        prepare_stages=[],
        validation_rules=[],
        table_checks=[TableCheckRemovedRows(warning="any")],
        refined_columns={"id": "id"},
    )


def test_run_pipeline_returns_success():
    df = pl.DataFrame({"id": ["a", "b", "c"]})
    result = run_pipeline(df, _simple_inputs())
    assert result.success
    assert result.data.collect()["id"].to_list() == ["a", "b", "c"]


def test_run_pipeline_drops_extra_columns():
    df = pl.DataFrame({"id": ["a"], "extra": [1]})
    result = run_pipeline(df, _simple_inputs())
    assert result.success
    assert "extra" not in result.data.collect().columns


def test_run_pipeline_fails_on_missing_required_column():
    df = pl.DataFrame({"wrong": ["a"]})
    result = run_pipeline(df, _simple_inputs())
    assert not result.success
    assert result.failed_stage == "normalise"
```

- [ ] **Step 2: Run tests to confirm they fail**

```bash
uv run pytest tests/unit/schema/test_pipeline.py -v
```
Expected: `ImportError: cannot import name '_pipeline'`

- [ ] **Step 3: Create `src/zeolite/schema/_pipeline.py`**

```python
from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING, Optional

import polars as pl
from polars import LazyFrame, DataFrame, any_horizontal, col, lit
from polars.exceptions import ColumnNotFoundError, ShapeError

from ._utils.coerce_types import coerce_column_types, CoerceOverride
from ._utils.normalise import normalise_column_headers
from ..types import (
    SourceColDef,
    ThresholdLevel,
    ValidationResult,
    ProcessingFailure,
    ProcessingSuccess,
    StructureValidationError,
    TableValidationError,
)
from .validation.variants import VALIDATION_CHECK_COL

if TYPE_CHECKING:
    from ..types.validation.validation_rule import ColumnValidationRule
    from .validation.variants import TableCheckType


@dataclass(frozen=True)
class PrepareEntry:
    name: str
    expression: pl.Expr


@dataclass(frozen=True)
class PipelineInputs:
    schema_name: str
    is_required: bool
    stage: Optional[str]
    strict: bool
    coerce: CoerceOverride
    source_columns: list[SourceColDef]
    prepare_stages: list[list[PrepareEntry]]
    validation_rules: list["ColumnValidationRule"]
    table_checks: list["TableCheckType"]
    refined_columns: dict[str, str]  # alias → actual column name


def run_pipeline(
    df: LazyFrame | DataFrame,
    inputs: PipelineInputs,
    *,
    source_name: Optional[str] = None,
) -> ProcessingFailure | ProcessingSuccess:
    errors = []
    failed_stage: Optional[str] = None

    normalised = normalise_column_headers(
        df.lazy(),
        schema_name=inputs.schema_name,
        col_defs=inputs.source_columns,
        source_name=source_name,
    )
    errors.extend(normalised.errors)
    if normalised.reject:
        failed_stage = "normalise"
        if inputs.strict:
            return ProcessingFailure(
                normalised=normalised.data, coerced=None, prepared=None,
                validated=None, filtered=None, refined=None, data=None,
                errors=errors, failed_stage=failed_stage,
            )

    coerced = coerce_column_types(
        normalised.data,
        schema_name=inputs.schema_name,
        col_defs=inputs.source_columns,
        source_name=source_name,
        coerce_override=inputs.coerce,
    )
    errors.extend(coerced.errors)
    if coerced.reject:
        failed_stage = "coerce" if failed_stage is None else failed_stage
        if inputs.strict:
            return ProcessingFailure(
                normalised=normalised.data, coerced=coerced.data, prepared=None,
                validated=None, filtered=None, refined=None, data=None,
                errors=errors, failed_stage=failed_stage,
            )

    prepped = _prepare(coerced.data, inputs, source_name=source_name)
    errors.extend(prepped.errors)
    if prepped.reject:
        failed_stage = "prepare" if failed_stage is None else failed_stage
        if inputs.strict:
            return ProcessingFailure(
                normalised=normalised.data, coerced=coerced.data, prepared=prepped.data,
                validated=None, filtered=None, refined=None, data=None,
                errors=errors, failed_stage=failed_stage,
            )

    valid = _validate(prepped.data, inputs, source_name=source_name)
    errors.extend(valid.errors)
    if valid.reject:
        failed_stage = "validate" if failed_stage is None else failed_stage
        if inputs.strict:
            return ProcessingFailure(
                normalised=normalised.data, coerced=coerced.data, prepared=prepped.data,
                validated=valid.data, filtered=None, refined=None, data=None,
                errors=errors, failed_stage=failed_stage,
            )

    filtered = _filter(valid.data, inputs, source_name=source_name)
    errors.extend(filtered.errors)
    if filtered.reject:
        failed_stage = "filter" if failed_stage is None else failed_stage
        if inputs.strict:
            return ProcessingFailure(
                normalised=normalised.data, coerced=coerced.data, prepared=prepped.data,
                validated=valid.data, filtered=filtered.data, refined=None, data=None,
                errors=errors, failed_stage=failed_stage,
            )

    refined = _refine(filtered.data, inputs, source_name=source_name)
    errors.extend(refined.errors)

    if filtered.reject or failed_stage is not None:
        return ProcessingFailure(
            normalised=normalised.data, coerced=coerced.data, prepared=prepped.data,
            validated=valid.data, filtered=filtered.data, refined=refined.data, data=None,
            errors=errors,
            failed_stage="refine" if failed_stage is None else failed_stage,
        )

    return ProcessingSuccess(
        normalised=normalised.data, coerced=coerced.data, prepared=prepped.data,
        validated=valid.data, filtered=filtered.data, refined=refined.data,
        data=refined.data, errors=errors,
    )


def _prepare(lf: LazyFrame, inputs: PipelineInputs, *, source_name: Optional[str]) -> ValidationResult:
    lf = lf.lazy()
    errors = []
    try:
        for stage in inputs.prepare_stages:
            lf = lf.with_columns([entry.expression for entry in stage])
        is_empty = lf.limit(2).collect().is_empty()
        if is_empty:
            errors.append(StructureValidationError(
                schema=inputs.schema_name, source=source_name,
                error="empty_data", level=ThresholdLevel.REJECT.level,
                message=f"`{inputs.schema_name}` has no data after attempting to add columns.",
            ))
    except ColumnNotFoundError as e:
        errors.append(StructureValidationError(
            schema=inputs.schema_name, source=source_name,
            error="column_not_found", level=ThresholdLevel.REJECT.level,
            message=f"polars.exceptions.ColumnNotFoundError: {e}",
        ))
    except ShapeError as e:
        errors.append(StructureValidationError(
            schema=inputs.schema_name, source=source_name,
            error="shape_error", level=ThresholdLevel.REJECT.level,
            message=(
                f"polars.exceptions.ShapeError: {e}. This is a known Polars bug with "
                "timezone-aware datetime literals on multi-chunk DataFrames. "
                "Workaround: call .rechunk() on your DataFrame before applying the schema."
            ),
        ))
    except Exception as e:
        errors.append(StructureValidationError(
            schema=inputs.schema_name, source=source_name,
            error="unknown", level=ThresholdLevel.REJECT.level,
            message=f"{e}",
        ))
    reject = any(e.level == ThresholdLevel.REJECT.level for e in errors)
    return ValidationResult(data=lf, errors=errors, reject=reject)


def _validate(lf: LazyFrame, inputs: PipelineInputs, *, source_name: Optional[str]) -> ValidationResult:
    lf = lf.lazy()
    errors = []
    reject = False
    rejectable: list[str] = []

    for rule in inputs.validation_rules:
        check = rule.validate(lf, source=source_name)
        if check is not None:
            errors.append(check)
            if check.level == ThresholdLevel.REJECT.level:
                reject = True
        if rule.remove_row_on_fail:
            rejectable.append(rule.check_column)

    if rejectable:
        lf = lf.with_columns(
            (~any_horizontal(*[col(r).ne(ThresholdLevel.PASS.level) for r in rejectable]))
            .alias(VALIDATION_CHECK_COL)
        )
    else:
        lf = lf.with_columns(lit(True).alias(VALIDATION_CHECK_COL))

    return ValidationResult(data=lf, errors=errors, reject=reject)


def _filter(lf: LazyFrame, inputs: PipelineInputs, *, source_name: Optional[str]) -> ValidationResult:
    lf = lf.lazy()
    filtered = lf.filter(col(VALIDATION_CHECK_COL))
    errors = []
    reject = False

    for check in inputs.table_checks:
        result = check.validate(
            validated_lf=lf, filtered_lf=filtered,
            schema_name=inputs.schema_name, source=source_name,
        )
        if result:
            errors.append(result)
            if result.level == ThresholdLevel.REJECT.level:
                reject = True

    return ValidationResult(data=filtered, errors=errors, reject=reject)


def _refine(lf: LazyFrame, inputs: PipelineInputs, *, source_name: Optional[str]) -> ValidationResult:
    lf = lf.lazy()
    try:
        refined = lf.select(
            *[col(col_name).alias(alias) for alias, col_name in inputs.refined_columns.items()]
        )
        return ValidationResult(data=refined, errors=[], reject=False)
    except Exception as e:
        return ValidationResult(
            data=lf,
            errors=[TableValidationError(
                message="Fatal error refining to final schema",
                schema=inputs.schema_name,
                level="reject",
                error=f"{e}",
                source=source_name,
            )],
            reject=True,
        )
```

- [ ] **Step 4: Run tests to confirm they pass**

```bash
uv run pytest tests/unit/schema/test_pipeline.py -v
```
Expected: 3 tests PASS

- [ ] **Step 5: Commit**

```bash
git add src/zeolite/schema/_pipeline.py tests/unit/schema/test_pipeline.py
git commit -m "feat: add _pipeline.py with PipelineInputs and run_pipeline()"
```

---

### Task 2: Wire `TableSchema.apply()` to `run_pipeline()`

**Files:**
- Modify: `src/zeolite/schema/_table.py`

- [ ] **Step 1: Baseline — confirm all tests pass before touching anything**

```bash
uv run pytest --tb=short -q
```
Note the test count. Expected: all pass.

- [ ] **Step 2: Add import to `_table.py`**

At the top of `src/zeolite/schema/_table.py`, after the existing imports, add:

```python
from ._pipeline import run_pipeline, PipelineInputs, PrepareEntry
```

- [ ] **Step 3: Add `_pipeline_inputs()` method to `TableSchema`**

Add this method to `TableSchema`, after the `coerce()` method (around line 143):

```python
def _pipeline_inputs(self) -> PipelineInputs:
    registry = self._params.registry
    return PipelineInputs(
        schema_name=self._params.name,
        is_required=self._params.is_required,
        stage=self._params.stage,
        strict=self._params.strict,
        coerce=self._params.coerce,
        source_columns=list(self._params.source_columns.values()),
        prepare_stages=[
            [
                PrepareEntry(name=n.name, expression=n.expression)
                for n in stage
                if n.expression is not None
            ]
            for stage in registry.get_execution_stages()
            if any(n.expression is not None for n in stage)
        ],
        validation_rules=[
            n.validation_rule
            for n in registry.nodes()
            if n.validation_rule is not None
        ],
        table_checks=self._params.table_checks,
        refined_columns={
            alias: registry.get_by_id(col_id).name
            for alias, col_id in self._params.refined_columns.items()
        },
    )
```

- [ ] **Step 4: Replace `apply()` body**

Replace the full `apply()` method body (lines 402–544) with:

```python
def apply(
    self, df: LazyFrame | DataFrame, *, source_name: str | None = None
) -> ProcessingFailure | ProcessingSuccess:
    return run_pipeline(df, self._pipeline_inputs(), source_name=source_name)
```

Keep the existing docstring.

- [ ] **Step 5: Run all tests — must match baseline count**

```bash
uv run pytest --tb=short -q
```
Expected: same count as Step 1, all pass.

- [ ] **Step 6: Run the advanced example**

```bash
uv run python examples/advanced.py
```
Expected: `✅ dataset successfully processed`

- [ ] **Step 7: Commit**

```bash
git add src/zeolite/schema/_table.py
git commit -m "refactor: TableSchema.apply() delegates to run_pipeline()"
```

---

### Task 3: Serialisation helpers

**Files:**
- Create: `src/zeolite/schema/_serialise/__init__.py`
- Create: `src/zeolite/schema/_serialise/_expressions.py`
- Create: `src/zeolite/schema/_serialise/_types.py`
- Create: `src/zeolite/schema/_serialise/_rules.py`
- Create: `tests/unit/schema/test_serialise.py`

- [ ] **Step 1: Write failing tests**

```python
# tests/unit/schema/test_serialise.py
import polars as pl
import pytest

from zeolite.schema._serialise._expressions import serialize_expr, deserialize_expr
from zeolite.schema._serialise._types import (
    encode_dtype, decode_dtype,
    encode_threshold, decode_threshold,
    encode_source_col_def, decode_source_col_def,
    encode_table_check, decode_table_check,
)
from zeolite.schema._serialise._rules import encode_validation_rule, decode_validation_rule
from zeolite.types import SourceColDef
from zeolite.types.validation.threshold import ThresholdLevel, Threshold
from zeolite.types.validation.validation_rule import ColumnValidationRule
from zeolite.schema.validation.variants import TableCheckRemovedRows, TableCheckMinRows


class TestExprSerialization:
    def test_round_trips_alias_expr(self):
        expr = pl.col("x").cast(pl.String).alias("y")
        result = deserialize_expr(serialize_expr(expr))
        assert result.meta.output_name() == "y"

    def test_round_trips_binary_expr(self):
        expr = (pl.col("price") * pl.col("qty")).alias("total")
        result = deserialize_expr(serialize_expr(expr))
        assert result.meta.output_name() == "total"


class TestDtypeSerialization:
    @pytest.mark.parametrize("dtype", [pl.String, pl.Int64, pl.Float64, pl.Boolean, pl.Date])
    def test_round_trips(self, dtype):
        assert decode_dtype(encode_dtype(dtype)) == dtype

    def test_none_round_trips(self):
        assert encode_dtype(None) is None
        assert decode_dtype(None) is None


class TestThresholdSerialization:
    def test_round_trips_numeric(self):
        t = Threshold(warning=0.1, error=0.2, reject=0.5)
        decoded = decode_threshold(encode_threshold(t))
        assert decoded.warning == 0.1
        assert decoded.error == 0.2
        assert decoded.reject == 0.5

    def test_round_trips_string_literals(self):
        t = Threshold(warning="any", reject="all")
        decoded = decode_threshold(encode_threshold(t))
        assert decoded.warning == "any"
        assert decoded.reject == "all"


class TestSourceColDefSerialization:
    def test_round_trips(self):
        scd = SourceColDef(
            name="id",
            variants={"id", "user_id"},
            if_missing=ThresholdLevel.REJECT,
            is_meta=False,
            dtype=pl.String,
            coerce="default",
        )
        decoded = decode_source_col_def(encode_source_col_def(scd))
        assert decoded.name == "id"
        assert decoded.variants == {"id", "user_id"}
        assert decoded.if_missing == ThresholdLevel.REJECT
        assert decoded.dtype == pl.String
        assert decoded.coerce == "default"

    def test_none_dtype_round_trips(self):
        scd = SourceColDef(name="x", variants={"x"}, if_missing=ThresholdLevel.REJECT, is_meta=False)
        decoded = decode_source_col_def(encode_source_col_def(scd))
        assert decoded.dtype is None
        assert decoded.coerce is None


class TestTableCheckSerialization:
    def test_removed_rows_round_trips(self):
        check = TableCheckRemovedRows(warning=0.2, error=0.3, reject=0.5)
        decoded = decode_table_check(encode_table_check(check))
        assert decoded.method_id() == "removed_rows"
        assert decoded._params.thresholds.warning == 0.2
        assert decoded._params.thresholds.reject == 0.5

    def test_min_rows_round_trips(self):
        check = TableCheckMinRows(reject=10)
        decoded = decode_table_check(encode_table_check(check))
        assert decoded.method_id() == "min_rows"

    def test_min_rows_reject_1_round_trips(self):
        check = TableCheckMinRows(reject=1)
        decoded = decode_table_check(encode_table_check(check))
        assert decoded.method_id() == "min_rows"


class TestValidationRuleSerialization:
    def test_round_trips(self):
        rule = ColumnValidationRule(
            check_id="not_empty",
            thresholds=Threshold(warning="any", error=0.1),
            message="{{column}} has {{count}} empty values",
            source_column="id",
            check_column="id__check__not_empty",
            schema="test",
            remove_row_on_fail=False,
        )
        decoded = decode_validation_rule(encode_validation_rule(rule))
        assert decoded.check_id == "not_empty"
        assert decoded.source_column == "id"
        assert decoded.check_column == "id__check__not_empty"
        assert decoded.thresholds.warning == "any"
        assert decoded.thresholds.error == 0.1
        assert decoded.remove_row_on_fail is False
```

- [ ] **Step 2: Run tests to confirm they fail**

```bash
uv run pytest tests/unit/schema/test_serialise.py -v
```
Expected: `ModuleNotFoundError`

- [ ] **Step 3: Create `src/zeolite/schema/_serialise/__init__.py`** (empty)

```python
```

- [ ] **Step 4: Create `src/zeolite/schema/_serialise/_expressions.py`**

```python
from __future__ import annotations
import json
import polars as pl


def serialize_expr(expr: pl.Expr) -> dict:
    return json.loads(expr.meta.serialize(format="json"))


def deserialize_expr(data: dict) -> pl.Expr:
    return pl.Expr.deserialize(json.dumps(data).encode(), format="json")
```

- [ ] **Step 5: Create `src/zeolite/schema/_serialise/_types.py`**

```python
from __future__ import annotations
import polars as pl
from zeolite.types import SourceColDef
from zeolite.types.validation.threshold import Threshold, ThresholdLevel


def encode_dtype(dtype: pl.DataType | None) -> str | None:
    return None if dtype is None else str(dtype)


def decode_dtype(value: str | None) -> pl.DataType | None:
    return None if value is None else getattr(pl, value)


def encode_threshold(t: Threshold) -> dict:
    result = {}
    for k in ("debug", "warning", "error", "reject"):
        v = getattr(t, k)
        if v is not None and v is not False:
            result[k] = v
    return result


def decode_threshold(data: dict) -> Threshold:
    return Threshold(**{k: v for k, v in data.items() if v is not None})


def encode_threshold_level(level: ThresholdLevel) -> str:
    return level.level


def decode_threshold_level(value: str) -> ThresholdLevel:
    return next(lv for lv in ThresholdLevel if lv.level == value)


def encode_source_col_def(scd: SourceColDef) -> dict:
    return {
        "name": scd.name,
        "variants": sorted(scd.variants),
        "if_missing": encode_threshold_level(scd.if_missing),
        "is_meta": scd.is_meta,
        "dtype": encode_dtype(scd.dtype),
        "coerce": scd.coerce,
    }


def decode_source_col_def(data: dict) -> SourceColDef:
    return SourceColDef(
        name=data["name"],
        variants=set(data["variants"]),
        if_missing=decode_threshold_level(data["if_missing"]),
        is_meta=data["is_meta"],
        dtype=decode_dtype(data["dtype"]),
        coerce=data.get("coerce"),
    )


def encode_table_check(check) -> dict:
    t = check._params.thresholds
    d = {"check": check.method_id(), "message": check._params.message}
    for k in ("debug", "warning", "error", "reject"):
        v = getattr(t, k)
        if v is not None and v is not False:
            d[k] = v
    # For min_rows, recover original integer counts from internal _thresholds
    # because TableCheckMinRows converts 1 → "any" internally
    if check.method_id() == "min_rows":
        d = {"check": check.method_id(), "message": check._params.message}
        for level in ThresholdLevel:
            if level == ThresholdLevel.PASS:
                continue
            pair = t._thresholds.get(level)
            if pair is not None:
                _, count = pair
                if count is not None:
                    d[level.level] = count
    return d


def decode_table_check(data: dict):
    from zeolite.schema.validation.variants import TableCheckRemovedRows, TableCheckMinRows
    kwargs = {k: data[k] for k in ("debug", "warning", "error", "reject") if data.get(k) is not None}
    if data.get("message"):
        kwargs["message"] = data["message"]
    match data["check"]:
        case "removed_rows":
            return TableCheckRemovedRows(**kwargs)
        case "min_rows":
            return TableCheckMinRows(**kwargs)
        case other:
            raise ValueError(f"Unknown table check type: {other!r}")
```

- [ ] **Step 6: Create `src/zeolite/schema/_serialise/_rules.py`**

```python
from __future__ import annotations
from zeolite.types.validation.validation_rule import ColumnValidationRule
from ._types import encode_threshold, decode_threshold


def encode_validation_rule(rule: ColumnValidationRule) -> dict:
    return {
        "check_id": rule.check_id,
        "thresholds": encode_threshold(rule.thresholds),
        "message": rule.message,
        "source_column": rule.source_column,
        "check_column": rule.check_column,
        "schema": rule.schema,
        "remove_row_on_fail": rule.remove_row_on_fail,
    }


def decode_validation_rule(data: dict) -> ColumnValidationRule:
    return ColumnValidationRule(
        check_id=data["check_id"],
        thresholds=decode_threshold(data["thresholds"]),
        message=data["message"],
        source_column=data["source_column"],
        check_column=data["check_column"],
        schema=data["schema"],
        remove_row_on_fail=data["remove_row_on_fail"],
    )
```

- [ ] **Step 7: Run all serialisation tests**

```bash
uv run pytest tests/unit/schema/test_serialise.py -v
```
Expected: All tests pass.

- [ ] **Step 8: Run full suite to confirm nothing regressed**

```bash
uv run pytest --tb=short -q
```
Expected: All tests pass.

- [ ] **Step 9: Commit**

```bash
git add src/zeolite/schema/serialise/ tests/unit/schema/test_serialise.py
git commit -m "feat: add _serialise helpers for expressions, types, and validation rules"
```

---

### Task 4: Create `SchemaArtifact`

**Files:**
- Create: `src/zeolite/schema/_artifact.py`
- Create: `tests/unit/schema/test_artifact.py`

- [ ] **Step 1: Write failing tests**

```python
# tests/unit/schema/test_artifact.py
import json
import tempfile
from pathlib import Path
import polars as pl
import zeolite as z
from zeolite.schema._artifact import SchemaArtifact


def _advanced_schema():
    price_col = z.col.float("price").clean(z.Clean.decimal(decimal_places=2))
    quantity_col = z.col.int("quantity").clean(z.Clean.int())
    return (
        z.schema("test_artifact")
        .columns(
            z.col.str("id").validations(z.Check.not_empty(error="any")),
            z.col.str("name").optional(),
            z.col.int("age").optional(),
            price_col.temporary(),
            quantity_col.temporary(),
            z.col.derived("total", function=price_col.ref.col * quantity_col.ref.col),
        )
        .table_validation(z.TableCheck.removed_rows(warning=0.2))
    )


def _sample_df():
    return pl.DataFrame({
        "id": ["a", "b", "c"],
        "name": ["Alice", None, "Bob"],
        "age": [25, 30, None],
        "price": [10.0, 20.0, 15.0],
        "quantity": [2, 1, 3],
    })


class TestSchemaArtifactFromSchema:
    def test_from_schema_returns_artifact(self):
        schema = _advanced_schema()
        artifact = SchemaArtifact.from_schema(schema)
        assert isinstance(artifact, SchemaArtifact)

    def test_artifact_apply_matches_schema_apply(self):
        schema = _advanced_schema()
        artifact = SchemaArtifact.from_schema(schema)
        df = _sample_df()

        expected = schema.apply(df).data.collect()
        actual = artifact.apply(df).data.collect()

        assert actual.frame_equal(expected)

    def test_artifact_apply_returns_success(self):
        schema = _advanced_schema()
        artifact = SchemaArtifact.from_schema(schema)
        result = artifact.apply(_sample_df())
        assert result.success


class TestSchemaArtifactSaveLoad:
    def test_save_produces_valid_json(self):
        artifact = SchemaArtifact.from_schema(_advanced_schema())
        with tempfile.NamedTemporaryFile(suffix=".json", delete=False) as f:
            path = Path(f.name)
        artifact.save(path)
        data = json.loads(path.read_text())
        assert data["version"] == "1"
        assert "source_columns" in data
        assert "prepare_stages" in data
        assert "validation_rules" in data
        assert "table_checks" in data
        assert "refined_columns" in data

    def test_load_apply_matches_original(self):
        schema = _advanced_schema()
        artifact = SchemaArtifact.from_schema(schema)
        df = _sample_df()

        with tempfile.NamedTemporaryFile(suffix=".json", delete=False) as f:
            path = Path(f.name)
        artifact.save(path)
        loaded = SchemaArtifact.load(path)

        expected = schema.apply(df).data.collect()
        actual = loaded.apply(df).data.collect()
        assert actual.frame_equal(expected)

    def test_to_dict_round_trips(self):
        artifact = SchemaArtifact.from_schema(_advanced_schema())
        data = artifact.to_dict()
        loaded = SchemaArtifact.from_dict(data)
        expected = _advanced_schema().apply(_sample_df()).data.collect()
        actual = loaded.apply(_sample_df()).data.collect()
        assert actual.frame_equal(expected)
```

- [ ] **Step 2: Run tests to confirm they fail**

```bash
uv run pytest tests/unit/schema/test_artifact.py -v
```
Expected: `ImportError`

- [ ] **Step 3: Create `src/zeolite/schema/_artifact.py`**

```python
from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import TYPE_CHECKING

import polars as pl

from ._pipeline import run_pipeline, PipelineInputs, PrepareEntry
from ._serialise._expressions import serialize_expr, deserialize_expr
from ._serialise._types import (
    encode_source_col_def, decode_source_col_def,
    encode_table_check, decode_table_check,
)
from ._serialise._rules import encode_validation_rule, decode_validation_rule
from ..types import ProcessingFailure, ProcessingSuccess

if TYPE_CHECKING:
    from polars import LazyFrame, DataFrame
    from ._table import TableSchema

ARTIFACT_VERSION = "1"


class SchemaArtifact:
    def __init__(self, data: dict) -> None:
        self._data = data

    # ------------------------------------------------------------------
    # Construction
    # ------------------------------------------------------------------

    @classmethod
    def from_schema(cls, schema: "TableSchema") -> "SchemaArtifact":
        inputs = schema._pipeline_inputs()
        data = {
            "version": ARTIFACT_VERSION,
            "schema": {
                "name": schema._params.name,
                "is_required": schema._params.is_required,
                "stage": schema._params.stage,
                "strict": schema._params.strict,
                "coerce": schema._params.coerce,
            },
            "source_columns": [
                encode_source_col_def(scd) for scd in inputs.source_columns
            ],
            "prepare_stages": [
                [{"name": e.name, "expression": serialize_expr(e.expression)} for e in stage]
                for stage in inputs.prepare_stages
            ],
            "validation_rules": [
                encode_validation_rule(rule) for rule in inputs.validation_rules
            ],
            "table_checks": [
                encode_table_check(check) for check in inputs.table_checks
            ],
            "refined_columns": inputs.refined_columns,
        }
        return cls(data)

    @classmethod
    def from_dict(cls, data: dict) -> "SchemaArtifact":
        if data.get("version") != ARTIFACT_VERSION:
            raise ValueError(f"Unsupported artifact version: {data.get('version')!r}")
        return cls(data)

    @classmethod
    def load(cls, path: str | Path) -> "SchemaArtifact":
        return cls.from_dict(json.loads(Path(path).read_text()))

    # ------------------------------------------------------------------
    # Export
    # ------------------------------------------------------------------

    def to_dict(self) -> dict:
        return self._data

    def save(self, path: str | Path) -> None:
        Path(path).write_text(json.dumps(self._data, indent=2))

    # ------------------------------------------------------------------
    # Apply
    # ------------------------------------------------------------------

    def apply(
        self, df: "LazyFrame | DataFrame", *, source_name: str | None = None
    ) -> ProcessingFailure | ProcessingSuccess:
        return run_pipeline(df, self._to_pipeline_inputs(), source_name=source_name)

    def _to_pipeline_inputs(self) -> PipelineInputs:
        d = self._data
        schema = d["schema"]
        return PipelineInputs(
            schema_name=schema["name"],
            is_required=schema["is_required"],
            stage=schema["stage"],
            strict=schema["strict"],
            coerce=schema["coerce"],
            source_columns=[decode_source_col_def(s) for s in d["source_columns"]],
            prepare_stages=[
                [PrepareEntry(name=e["name"], expression=deserialize_expr(e["expression"])) for e in stage]
                for stage in d["prepare_stages"]
            ],
            validation_rules=[decode_validation_rule(r) for r in d["validation_rules"]],
            table_checks=[decode_table_check(c) for c in d["table_checks"]],
            refined_columns=d["refined_columns"],
        )
```

- [ ] **Step 4: Run tests**

```bash
uv run pytest tests/unit/schema/test_artifact.py -v
```
Expected: All tests pass.

- [ ] **Step 5: Run full suite**

```bash
uv run pytest --tb=short -q
```
Expected: All tests pass.

- [ ] **Step 6: Commit**

```bash
git add src/zeolite/schema/artifact.py tests/unit/schema/test_artifact.py
git commit -m "feat: add SchemaArtifact with from_schema(), apply(), save(), load()"
```

---

### Task 5: Add `columns` to `_SchemaParams` and create `SchemaSpec`

**Files:**
- Modify: `src/zeolite/schema/_table.py`
- Create: `src/zeolite/schema/_spec.py`
- Create: `tests/unit/schema/test_spec.py`

- [ ] **Step 1: Write failing tests**

```python
# tests/unit/schema/test_spec.py
import json
import tempfile
from pathlib import Path
import polars as pl
import zeolite as z
from zeolite.schema._spec import SchemaSpec


def _advanced_schema():
    price_col = z.col.float("price").clean(z.Clean.decimal(decimal_places=2))
    quantity_col = z.col.int("quantity").clean(z.Clean.int())
    return (
        z.schema("spec_test")
        .columns(
            z.col.str("id").validations(z.Check.not_empty(error="any")),
            z.col.str("name").optional(),
            z.col.int("age").optional(),
            price_col.temporary(),
            quantity_col.temporary(),
            z.col.derived("total", function=price_col.ref.col * quantity_col.ref.col),
        )
        .table_validation(z.TableCheck.removed_rows(warning=0.2))
    )


def _sample_df():
    return pl.DataFrame({
        "id": ["a", "b", "c"],
        "name": ["Alice", None, "Bob"],
        "age": [25, 30, None],
        "price": [10.0, 20.0, 15.0],
        "quantity": [2, 1, 3],
    })


class TestSchemaSpecFromSchema:
    def test_from_schema_returns_spec(self):
        spec = SchemaSpec.from_schema(_advanced_schema())
        assert isinstance(spec, SchemaSpec)

    def test_spec_has_expected_top_level_keys(self):
        data = SchemaSpec.from_schema(_advanced_schema()).to_dict()
        assert data["version"] == "1"
        assert data["name"] == "spec_test"
        assert "columns" in data
        assert "table_checks" in data

    def test_spec_columns_are_human_readable(self):
        data = SchemaSpec.from_schema(_advanced_schema()).to_dict()
        col_names = [c["name"] for c in data["columns"]]
        assert "id" in col_names
        assert "total" in col_names

    def test_source_column_has_validations(self):
        data = SchemaSpec.from_schema(_advanced_schema()).to_dict()
        id_col = next(c for c in data["columns"] if c["name"] == "id")
        assert id_col["kind"] == "source"
        assert len(id_col["validations"]) >= 1
        assert id_col["validations"][0]["check"] == "not_empty"

    def test_derived_column_has_expression(self):
        data = SchemaSpec.from_schema(_advanced_schema()).to_dict()
        total_col = next(c for c in data["columns"] if c["name"] == "total")
        assert total_col["kind"] == "derived"
        assert "expression" in total_col


class TestSchemaSpecSaveLoad:
    def test_save_produces_readable_json(self):
        spec = SchemaSpec.from_schema(_advanced_schema())
        with tempfile.NamedTemporaryFile(suffix=".json", delete=False) as f:
            path = Path(f.name)
        spec.save(path)
        data = json.loads(path.read_text())
        assert data["version"] == "1"

    def test_load_returns_same_dict(self):
        spec = SchemaSpec.from_schema(_advanced_schema())
        with tempfile.NamedTemporaryFile(suffix=".json", delete=False) as f:
            path = Path(f.name)
        spec.save(path)
        loaded = SchemaSpec.load(path)
        assert loaded.to_dict() == spec.to_dict()


class TestSchemaSpecCompile:
    def test_compile_returns_artifact(self):
        from zeolite.schema._artifact import SchemaArtifact
        spec = SchemaSpec.from_schema(_advanced_schema())
        artifact = spec.compile()
        assert isinstance(artifact, SchemaArtifact)

    def test_compile_artifact_produces_correct_output(self):
        schema = _advanced_schema()
        df = _sample_df()
        expected = schema.apply(df).data.collect()

        spec = SchemaSpec.from_schema(schema)
        actual = spec.compile().apply(df).data.collect()

        assert actual.frame_equal(expected)
```

- [ ] **Step 2: Run tests to confirm they fail**

```bash
uv run pytest tests/unit/schema/test_spec.py -v
```
Expected: `ImportError`

- [ ] **Step 3: Add `columns: list[Col]` field to `_SchemaParams` in `_table.py`**

In `_table.py`, import `Col` at the top if not already imported (it is, via `from ..column import Col`).

Add `columns` field to `_SchemaParams` (after line 40, before `__post_init__`):

```python
@dataclass(frozen=True, kw_only=True)
class _SchemaParams:
    name: str
    is_required: bool = False
    stage: Optional[str] = None
    source_columns: dict[str, SourceColDef] = field(default_factory=dict)
    refined_columns: dict[str, str] = field(default_factory=dict)
    registry: ColumnRegistry = field(default_factory=ColumnRegistry)
    strict: bool = True
    coerce: CoerceOverride = "default_true"
    table_checks: list["TableCheckType"] = field(default_factory=list)
    columns: list[Col] = field(default_factory=list)  # original Col list for to_spec()

    def __post_init__(self):
        self.registry.verify_integrity()
```

In `TableSchema.__init__`, pass `columns=cols` to `_SchemaParams`:

```python
self._params = _SchemaParams(
    name=name,
    is_required=not optional,
    stage=stage,
    registry=registry,
    source_columns=_cols_to_sources(cols, schema_name=name),
    refined_columns=_cols_to_refined_targets(nodes),
    strict=strict,
    coerce=coerce,
    table_checks=list(table_validations) if table_validations else [TableCheckRemovedRows(warning="any")],
    columns=cols,
)
```

Also update `TableSchema.columns()` to pass the updated col list when merging. In the `merge` branch, add:
```python
return self._replace(
    registry=new_registry,
    source_columns=new_source_columns,
    refined_columns=new_refined_columns,
    columns=list(self._params.columns) + cols,
)
```
And in the `replace` branch:
```python
return self._replace(
    registry=_reset_registry(new_nodes),
    source_columns=_cols_to_sources(cols, schema_name=self._params.name),
    refined_columns=_cols_to_refined_targets(new_nodes),
    columns=cols,
)
```

- [ ] **Step 4: Run existing tests to confirm nothing broke**

```bash
uv run pytest --tb=short -q
```
Expected: All tests pass.

- [ ] **Step 5: Create `src/zeolite/schema/_spec.py`**

```python
from __future__ import annotations

import json
from pathlib import Path
from typing import TYPE_CHECKING

from ._serialise._expressions import serialize_expr
from ._serialise._types import encode_table_check

if TYPE_CHECKING:
    from ._table import TableSchema
    from ._artifact import SchemaArtifact

SPEC_VERSION = "1"


class SchemaSpec:
    def __init__(self, data: dict) -> None:
        self._data = data

    # ------------------------------------------------------------------
    # Construction
    # ------------------------------------------------------------------

    @classmethod
    def from_schema(cls, schema: "TableSchema") -> "SchemaSpec":
        data = {
            "version": SPEC_VERSION,
            "name": schema._params.name,
            "optional": not schema._params.is_required,
            "stage": schema._params.stage,
            "strict": schema._params.strict,
            "coerce": schema._params.coerce,
            "columns": [_encode_col(c) for c in schema._params.columns],
            "table_checks": [encode_table_check(tc) for tc in schema._params.table_checks],
        }
        return cls(data)

    @classmethod
    def load(cls, path: str | Path) -> "SchemaSpec":
        return cls(json.loads(Path(path).read_text()))

    # ------------------------------------------------------------------
    # Export
    # ------------------------------------------------------------------

    def to_dict(self) -> dict:
        return self._data

    def save(self, path: str | Path) -> None:
        Path(path).write_text(json.dumps(self._data, indent=2))

    # ------------------------------------------------------------------
    # Compile to artifact
    # ------------------------------------------------------------------

    def compile(self) -> "SchemaArtifact":
        from ._artifact import SchemaArtifact
        schema = _spec_to_schema(self._data)
        return SchemaArtifact.from_schema(schema)


# ------------------------------------------------------------------
# Column encoding helpers
# ------------------------------------------------------------------

def _encode_col(col) -> dict:
    from ..column._base import Col
    from ..column._clean._base import CleanColumn

    ref = col.ref

    if col.has_expression:
        return {
            "kind": "derived",
            "name": ref.base_name,
            "type": col.params.data_type if hasattr(col.params, "data_type") else "unknown",
            "sensitivity": col.params.sensitivity.value if col.params.sensitivity else None,
            "temporary": col.params.is_temporary,
            "alias": col.params.alias,
            "expression": serialize_expr(col.params.expression),
        }

    result = {
        "kind": "meta" if ref.is_meta else "source",
        "name": ref.base_name,
        "type": col.params.data_type if hasattr(col.params, "data_type") else "unknown",
        "optional": not col.params.is_required if hasattr(col.params, "is_required") else False,
        "variants": sorted(col.get_variants),
        "sensitivity": col.params.sensitivity.value if col.params.sensitivity else None,
        "temporary": col.params.is_temporary,
        "alias": col.params.alias,
        "clean": _encode_clean(col.params.clean) if col.params.clean is not None else None,
        "validations": [_encode_check(v) for v in col.validations],
    }
    return result


def _encode_clean(clean) -> dict:
    return {
        "method": clean.method_id(),
        "params": clean.spec_params(),
        "alias": clean.params.alias,
        "temporary": clean.params.is_temporary,
        "sensitivity": clean.params.sensitivity.value if clean.params.sensitivity else None,
    }


def _encode_check(check) -> dict:
    from ..column.validation.variants._compound import _BaseCompoundCheck
    if isinstance(check, _BaseCompoundCheck):
        return {
            "check": check.method_id(),
            "alias": check.params.alias,
            "temporary": check.params.is_temporary,
            "remove_row_on_fail": check.params.remove_row_on_fail,
            **_encode_thresholds(check.params.thresholds),
            "checks": [_encode_check(c) for c in check._params.checks],
        }
    return {
        "check": check.method_id(),
        "alias": check.params.alias,
        "temporary": check.params.is_temporary,
        "check_on_cleaned": getattr(check.params, "check_on_cleaned", False),
        "remove_row_on_fail": check.params.remove_row_on_fail,
        **_encode_thresholds(check.params.thresholds),
    }


def _encode_thresholds(t) -> dict:
    result = {}
    for k in ("debug", "warning", "error", "reject"):
        v = getattr(t, k, None)
        if v is not None and v is not False:
            result[k] = v
    return result


def _spec_to_schema(data: dict):
    import zeolite as z
    schema = z.schema(
        data["name"],
        optional=data.get("optional", False),
        stage=data.get("stage"),
        strict=data.get("strict", True),
        coerce=data.get("coerce", "default_true"),
    )
    # table_checks reconstruction deferred (requires Check/Clean factories)
    return schema
```

**Note:** `_encode_clean` and `_encode_check` above require `spec_params()` methods on `CleanColumn` and `BaseCheck`. These methods don't exist yet and must be added in Task 5 Step 6 below. For now, the tests for `compile()` use the schema's already-constructed pipeline inputs (not re-construction from spec JSON), so `_spec_to_schema` is only used in the future `from_spec` flow. The `compile()` method works by calling `_spec_to_schema` which currently returns a bare schema — this won't reproduce the full column structure. Adjust `compile()` to use the original schema reference instead.

**Revised `compile()` approach** — store a reference to the original schema in the spec:

Add a private `_schema` reference to `SchemaSpec.__init__`:

```python
class SchemaSpec:
    def __init__(self, data: dict, _schema=None) -> None:
        self._data = data
        self._schema_ref = _schema  # set only when created from_schema(); None when loaded from file

    @classmethod
    def from_schema(cls, schema: "TableSchema") -> "SchemaSpec":
        ...
        instance = cls(data, _schema=schema)
        return instance

    def compile(self) -> "SchemaArtifact":
        from ._artifact import SchemaArtifact
        if self._schema_ref is not None:
            return SchemaArtifact.from_schema(self._schema_ref)
        # Future: reconstruct from spec JSON via _spec_to_schema()
        raise NotImplementedError(
            "Compiling from a loaded spec file requires from_spec() factories (not yet implemented). "
            "Use SchemaSpec.from_schema(schema).compile() instead."
        )
```

Update the `compile()` test to use the `from_schema()` path only:

The test `test_compile_artifact_produces_correct_output` already does `SchemaSpec.from_schema(schema).compile()` so it will use the schema reference. ✓

- [ ] **Step 6: Run spec tests**

```bash
uv run pytest tests/unit/schema/test_spec.py -v
```
Expected: All tests pass. (The `_encode_col` helper will need `col.params.clean`, `col.validations`, `col.get_variants`, `col.params.is_required`, `col.params.data_type`, `col.params.sensitivity`, `col.params.is_temporary`, `col.params.alias` to be accessible. If any attribute is missing, inspect `src/zeolite/column/_base/__init__.py` and adjust attribute access accordingly.)

- [ ] **Step 7: Run full suite**

```bash
uv run pytest --tb=short -q
```
Expected: All tests pass.

- [ ] **Step 8: Commit**

```bash
git add src/zeolite/schema/_table.py src/zeolite/schema/spec.py tests/unit/schema/test_spec.py
git commit -m "feat: add SchemaSpec and columns field to _SchemaParams"
```

---

### Task 6: Wire `TableSchema`, export public API, end-to-end verification

**Files:**
- Modify: `src/zeolite/schema/_table.py`
- Modify: `src/zeolite/schema/__init__.py`
- Modify: `src/zeolite/__init__.py`

- [ ] **Step 1: Add `to_spec()` and `to_artifact()` to `TableSchema`**

In `src/zeolite/schema/_table.py`, add these two methods to `TableSchema` (after `table_validation()`):

```python
def to_spec(self) -> "SchemaSpec":
    from ._spec import SchemaSpec
    return SchemaSpec.from_schema(self)

def to_artifact(self) -> "SchemaArtifact":
    from ._artifact import SchemaArtifact
    return SchemaArtifact.from_schema(self)
```

Add the TYPE_CHECKING imports:
```python
if TYPE_CHECKING:
    ...
    from ._spec import SchemaSpec
    from ._artifact import SchemaArtifact
```

- [ ] **Step 2: Export from `schema/__init__.py`**

Replace `src/zeolite/schema/__init__.py` with:

```python
from ._table import TableSchema, VALIDATION_CHECK_COL
from ._spec import SchemaSpec
from ._artifact import SchemaArtifact

schema = TableSchema

__all__ = ["TableSchema", "schema", "VALIDATION_CHECK_COL", "SchemaSpec", "SchemaArtifact"]
```

- [ ] **Step 3: Export from `zeolite/__init__.py`**

Add to `src/zeolite/__init__.py`:

```python
from .schema._spec import SchemaSpec
from .schema._artifact import SchemaArtifact
```

And add `"SchemaSpec"` and `"SchemaArtifact"` to `__all__`.

- [ ] **Step 4: Write a final integration test**

```python
# tests/unit/schema/test_artifact.py — add to the existing file

class TestEndToEndWorkflow:
    def test_schema_to_spec_to_artifact_to_apply(self):
        """Full workflow: define → to_spec() → compile() → apply()"""
        import tempfile
        import zeolite as z
        schema = (
            z.schema("workflow")
            .columns(
                z.col.str("id").validations(z.Check.not_empty(error="any")),
                z.col.int("count").optional(),
            )
            .table_validation(z.TableCheck.removed_rows(warning="any"))
        )
        df = pl.DataFrame({"id": ["x", "y"], "count": [1, 2]})
        expected = schema.apply(df).data.collect()

        # to_spec → compile → apply
        spec = schema.to_spec()
        artifact = spec.compile()
        assert artifact.apply(df).data.collect().frame_equal(expected)

        # to_artifact → save → load → apply
        with tempfile.NamedTemporaryFile(suffix=".json", delete=False) as f:
            path = Path(f.name)
        schema.to_artifact().save(path)
        loaded = z.SchemaArtifact.load(path)
        assert loaded.apply(df).data.collect().frame_equal(expected)
```

- [ ] **Step 5: Run all tests**

```bash
uv run pytest --tb=short -q
```
Expected: All tests pass.

- [ ] **Step 6: Run the advanced example via the artifact path**

```python
# Run this inline to verify end-to-end with the real advanced schema
uv run python -c "
import polars as pl
import zeolite as z
from examples.advanced import advanced_schema_1, data
artifact = advanced_schema_1.to_artifact()
res = artifact.apply(data)
print('artifact apply success:', res.success)
assert res.success
"
```
Expected: `artifact apply success: True`

- [ ] **Step 7: Run linter**

```bash
uv run ruff check src/zeolite/schema/_pipeline.py src/zeolite/schema/artifact.py src/zeolite/schema/spec.py src/zeolite/schema/serialise/
```
Expected: No errors. Fix any reported.

- [ ] **Step 8: Final commit**

```bash
git add src/zeolite/schema/_table.py src/zeolite/schema/__init__.py src/zeolite/__init__.py
git commit -m "feat: expose to_spec() and to_artifact() on TableSchema; export SchemaSpec and SchemaArtifact"
```
