# Architecture

Zeolite's architecture centers around four key components that work together to process raw data into validated, standardized datasets.

## Data Processing Pipeline

Raw data flows through distinct stages, with each component handling a specific transformation:

```
Raw Data → Schema → Columns → Cleaning → Validation → Clean Dataset
```

## Core Components

### Schema
The schema is the top-level container that defines your table structure. It coordinates column definitions and processing rules.

```python
schema = z.schema("users")  # Creates schema container
```

### Columns
Columns define individual fields with data types, sensitivity levels, and processing rules. They serve as the blueprint for each data field.

```python
z.str_col("name")     # String column
z.int_col("age")      # Integer column  
z.date_col("dob")     # Date column
```

### Cleaning
The cleaning stage transforms raw data into standardized formats. It handles type conversion, normalization, and data formatting.

```python
.clean(z.Clean.integer())                    # Parse as integer
.clean(z.Clean.date())    # Parse as date
.clean(z.Clean.enum(enum_map={"m": "Male", "f": "Female"}))
```

### Validation
Validation applies data quality rules with configurable error thresholds. Rules can be applied to original or cleaned data.

```python
.validations(
    z.Check.not_null(error=0.1),        # Allow 10% nulls before error
    z.Check.unique(reject="any"),        # Reject any duplicates
    z.Check.between(min=0, max=150)      # Value range validation
)
```

## Column Types and Stages

Zeolite processes data through multiple column stages:

**Source Columns**: Original data fields as they appear in raw data
**Cleaned Columns**: Transformed versions after cleaning rules are applied  
**Derived Columns**: Computed fields based on expressions using other columns
**Meta Columns**: Additional fields added during processing (timestamps, batch IDs)

```python
# Source column with cleaning
z.str_col("raw_date").clean(z.Clean.date())

# Derived column from other fields
z.derived_col("full_name", function=z.ref("first").col + " " + z.ref("last").col)

# Meta column for processing metadata
z.meta_col("processed_at", function=z.expr.datetime.now())
```

## References and Expressions

Column references (`z.ref()`) allow you to build expressions that reference other columns in your schema:

```python
# Reference original column
z.ref("age").col > 18

# Reference cleaned version
z.ref("birth_date").clean().col

# Complex expressions
z.derived_col("is_adult", function=z.ref("age").clean().col >= 18)
```

## Error Handling and Thresholds

Zeolite uses a threshold-based system for handling validation failures:

- **Debug**: Log issues but continue processing
- **Warning**: Log warnings, data processing continues  
- **Error**: Log errors, processing continues with degraded quality
- **Reject**: Stop processing, data quality too poor

```python
z.Check.not_null(
    warning=0.05,   # Warn if >5% null
    error=0.10,     # Error if >10% null  
    reject=0.20     # Reject if >20% null
)
```

This graduated approach allows you to balance data quality requirements with processing flexibility.