# Examples

Comprehensive examples demonstrating Zeolite's capabilities across different use cases and scenarios.

## Basic Data Processing

### Simple CSV Processing
Process a basic customer dataset with cleaning and validation:

```python
import zeolite as z

# Customer data schema
customer_schema = z.schema("customers").columns(
    z.str_col("customer_id")
        .clean(z.Clean.id(, prefix="CUST_")
        .validations(z.Check.not_null(), z.Check.unique()),
    
    z.str_col("first_name")
        .clean(z.Clean.string(sanitize="full")
        .validations(z.Check.not_null()),
    
    z.str_col("last_name")
        .clean(z.Clean.string(sanitize="full")
        .validations(z.Check.not_null()),
    
    z.str_col("email")
        .clean(z.Clean.string(, sanitize="lowercase")
        .validations(z.Check.str_matches(r"^[^@]+@[^@]+\.[^@]+$")),
    
    z.str_col("age")
        .clean(z.Clean.integer()
        .validations(z.Check.between(min=0, max=150))
)
```

### Product Catalog Processing
Handle product data with enumerations and business rules:

```python
product_schema = z.schema("products").columns(
    z.str_col("sku")
        .clean(z.Clean.id(, prefix="SKU_")
        .validations(z.Check.unique(reject="any")),
    
    z.str_col("name")
        .clean(z.Clean.string(sanitize="full")
        .validations(z.Check.str_length(min_length=3, max_length=100)),
    
    z.str_col("category")
        .clean(z.Clean.enum(, enum_map={
            "electronics": "Electronics",
            "clothing": "Clothing", 
            "books": "Books",
            "home": "Home & Garden"
        })
        .validations(z.Check.not_null()),
    
    z.str_col("price")
        .clean(z.Clean.decimal(, precision=2)
        .validations(z.Check.greater_than(0)),
    
    z.str_col("in_stock")
        .clean(z.Clean.boolean(, true_values={"yes", "1", "true"})
)
```

## Advanced Data Transformation

### Multi-Source Data Integration
Combine data from multiple sources with derived columns:

```python
integration_schema = z.schema("integrated_data").columns(
    # Source system identifiers
    z.str_col("system_a_id").clean(z.Clean.id(, prefix="SYS_A_"),
    z.str_col("system_b_id").clean(z.Clean.id(, prefix="SYS_B_"),
    
    # Personal information
    z.str_col("birth_date")
        .clean(z.Clean.date(, date_formats=["%Y-%m-%d", "%m/%d/%Y"])
        .validations(z.Check.valid_date()),
    
    z.str_col("gender")
        .clean(z.Clean.enum(, enum_map={
            "m": "Male", "male": "Male", "man": "Male",
            "f": "Female", "female": "Female", "woman": "Female",
            "nb": "Non-binary", "other": "Non-binary"
        }),
    
    # Derived fields
    z.derived_col("age",
        function=z.expr.datetime.now().dt.year() - z.ref("birth_date").clean().col.dt.year(),
        data_type="integer"
    ),
    
    z.derived_col("full_id",
        function=z.ref("system_a_id").clean().col + "_" + z.ref("system_b_id").clean().col,
        data_type="string"
    ),
    
    # Meta information
    z.meta_col("processed_at", 
        function=z.expr.datetime.now(),
        data_type="datetime"
    )
)
```

### Financial Data Processing
Handle financial data with precision requirements and business rules:

```python
financial_schema = z.schema("transactions").columns(
    z.str_col("transaction_id")
        .clean(z.Clean.id(, prefix="TXN_")
        .validations(z.Check.unique(reject="any")),
    
    z.str_col("account_id")
        .clean(z.Clean.id(, prefix="ACC_")
        .validations(z.Check.not_null()),
    
    z.str_col("amount")
        .clean(z.Clean.decimal(, precision=2)
        .validations(z.Check.not_null()),
    
    z.str_col("transaction_type")
        .clean(z.Clean.enum(, enum_map={
            "deposit": "DEPOSIT",
            "withdrawal": "WITHDRAWAL", 
            "transfer": "TRANSFER"
        })
        .validations(z.Check.not_null()),
    
    z.str_col("timestamp")
        .clean(z.Clean.datetime()
        .validations(z.Check.not_null()),
    
    # Business rule validation
    z.derived_custom_check("amount_sign_check",
        function=z.when(z.ref("transaction_type").clean().col == "WITHDRAWAL")
                 .then(z.ref("amount").clean().col < 0)
                 .otherwise(z.ref("amount").clean().col > 0),
        message="Withdrawals must be negative, deposits/transfers positive",
        thresholds=z.Threshold(reject="any")
    )
)
```

## Data Quality Scenarios

### Strict Validation Schema
High-quality data requirements with tight validation rules:

```python
quality_schema = z.schema("high_quality").columns(
    z.str_col("id")
        .clean(z.Clean.id(, prefix="HQ_")
        .validations(
            z.Check.not_null(reject="any"),
            z.Check.unique(reject="any"),
            z.Check.str_matches(r"^HQ_\d{8}$", error="any")
        ),
    
    z.str_col("email")
        .clean(z.Clean.string(, sanitize="lowercase")
        .validations(
            z.Check.str_matches(r"^[^@]+@[^@]+\.[^@]+$", reject="any"),
            z.Check.unique(error="any")
        ),
    
    z.str_col("phone")
        .clean(z.Clean.string(, sanitize="trim")
        .validations(
            z.Check.str_matches(r"^\+?[\d\s\-\(\)]{10,15}$", error=0.05),
            z.Check.str_length(min_length=10, error=0.02)
        ),
    
    z.str_col("score")
        .clean(z.Clean.integer() 
        .validations(
            z.Check.between(min=0, max=100, reject="any"),
            z.Check.not_null(reject="any")
        )
)
```

### Lenient Processing Schema
Flexible schema for messy or incomplete data:

```python
lenient_schema = z.schema("lenient_processing").columns(
    z.str_col("id")
        .clean(z.Clean.string(, sanitize="trim")
        .validations(z.Check.not_null(warning=0.10, error=0.25)),
    
    z.str_col("name")
        .clean(z.Clean.string(sanitize="full")
        .validations(z.Check.str_length(min_length=1, warning=0.20)),
    
    z.str_col("age")
        .clean(z.Clean.integer()
        .validations(
            z.Check.between(min=0, max=150, warning=0.05, error=0.15),
            z.Check.not_null(warning=0.30)
        ),
    
    z.str_col("category")
        .clean(z.Clean.string(, sanitize="lowercase")
        .validations(
            z.Check.is_in(["a", "b", "c", "other"], warning=0.10, error=0.25)
        ),
    
    # Optional fields
    z.str_col("optional_field")
        .optional()
        .clean(z.Clean.string()
        .validations(z.Check.str_length(max_length=50, warning=0.05))
)
```

## API Response Processing

### REST API Validation
Validate external API responses with comprehensive checks:

```python
api_schema = z.schema("api_response").columns(
    z.str_col("id")
        .validations(
            z.Check.not_null(reject="any"),
            z.Check.str_matches(r"^[a-zA-Z0-9_-]+$")
        ),
    
    z.str_col("status")
        .validations(z.Check.is_in([
            "pending", "processing", "completed", "failed"
        ], reject="any")),
    
    z.str_col("created_at")
        .clean(z.Clean.datetime()
        .validations(z.Check.not_null()),
    
    z.str_col("data")
        .optional(warning="any"),  # Warn if missing
    
    # Derived validation for timestamps
    z.derived_custom_check("timestamp_validation",
        function=z.ref("created_at").clean().col <= z.expr.datetime.now(),
        message="Created timestamp cannot be in the future",
        thresholds=z.Threshold(error="any")
    )
)
```

### Webhook Data Processing
Process incoming webhook data with flexible handling:

```python
webhook_schema = z.schema("webhook_data").columns(
    z.str_col("event_type")
        .clean(z.Clean.string(, sanitize="lowercase")
        .validations(z.Check.is_in([
            "user.created", "user.updated", "user.deleted",
            "order.placed", "payment.completed"
        ])),
    
    z.str_col("timestamp")
        .clean(z.Clean.datetime()
        .validations(z.Check.not_null()),
    
    z.str_col("user_id")
        .clean(z.Clean.id(, prefix="USER_")
        .validations(z.Check.not_null(warning=0.05)),
    
    z.str_col("payload")  # JSON string
        .validations(z.Check.not_null()),
    
    # Meta fields
    z.meta_col("received_at",
        function=z.expr.datetime.now(),
        data_type="datetime"
    ),
    
    z.meta_col("source",
        function=z.expr.lit("webhook"),
        data_type="string"
    )
)
```

## Legacy System Migration

### Database Migration Schema
Transform legacy database formats to modern standards:

```python
legacy_migration_schema = z.schema("legacy_migration").columns(
    # Legacy ID transformation
    z.str_col("old_customer_id")
        .clean(z.Clean.id(, prefix="LEGACY_CUST_")
        .validations(z.Check.unique()),
    
    # Name field consolidation
    z.str_col("fname").clean(z.Clean.string(sanitize="full"),
    z.str_col("lname").clean(z.Clean.string(sanitize="full"),
    z.derived_col("full_name",
        function=z.ref("fname").clean().col + " " + z.ref("lname").clean().col,
        data_type="string"
    ),
    
    # Date format standardization
    z.str_col("birth_dt")
        .clean(z.Clean.date(, date_formats=[
            "%m/%d/%Y", "%m-%d-%Y", "%Y%m%d", "%m.%d.%Y"
        ])
        .validations(z.Check.valid_date(warning=0.10)),
    
    # Status code mapping
    z.str_col("status_cd")
        .clean(z.Clean.enum(, enum_map={
            "A": "ACTIVE", "I": "INACTIVE", "S": "SUSPENDED",
            "D": "DELETED", "P": "PENDING"
        })
        .validations(z.Check.not_null()),
    
    # Currency handling
    z.str_col("balance_amt")
        .clean(z.Clean.decimal(, precision=2)
        .validations(z.Check.greater_than_or_equal(0, warning=0.05)),
    
    # Boolean flag normalization
    z.str_col("vip_flag")
        .clean(z.Clean.boolean(, true_values={"Y", "1", "TRUE"}, false_values={"N", "0", "FALSE"})
)
```

## Performance Optimization Examples

### Large Dataset Processing
Optimize for processing large datasets efficiently:

```python
large_dataset_schema = z.schema("large_data").columns(
    # Minimal validation for performance
    z.str_col("id")
        .clean(z.Clean.string()
        .validations(z.Check.not_null(error=0.01)),
    
    z.str_col("timestamp")
        .clean(z.Clean.datetime()
        .validations(z.Check.not_null(error=0.01)),
    
    z.str_col("value")
        .clean(z.Clean.decimal()
        .validations(z.Check.not_null(warning=0.05)),
    
    # Batch processing indicators
    z.meta_col("batch_id",
        function=z.expr.lit("BATCH_2024_001"),
        data_type="string"
    )
)
```

This comprehensive documentation provides practical examples for implementing Zeolite in real-world scenarios, from basic data processing to complex business rule validation.