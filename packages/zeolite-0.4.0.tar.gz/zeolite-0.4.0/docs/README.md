# Zeolite Documentation

## Table of Contents

1. [Getting Started](./getting-started.md) - Quick introduction and installation
2. [Architecture](./architecture.md) - How schemas, columns, cleaning, and validation work together
3. [Schema](./schema.md) - Defining table schemas and structure
4. [Columns](./columns.md) - Column types, data types, and configuration
5. [Cleaning](./cleaning.md) - Data transformation and normalization
6. [Validation](./validation.md) - Data quality checks and rules
7. [Examples](./examples.md) - Comprehensive usage examples

---

Zeolite is a Python library for defining data schemas and processing raw data through cleaning and validation pipelines. It uses Polars for high-performance data processing and provides a declarative API for data quality assurance.