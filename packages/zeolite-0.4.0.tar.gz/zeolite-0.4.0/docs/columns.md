# Columns

Columns define individual fields in your data schema, specifying data types, processing rules, and validation requirements. They are the building blocks of your data transformation pipeline.

## Column Types

### Basic Columns
Use `z.col()` for generic columns with explicit data type specification:

```python
z.col("name")                    # Generic column
z.col("age", data_type="integer") # With explicit data type
```

### Typed Columns
Use convenience functions for common data types:

```python
z.str_col("name")       # String column
z.int_col("age")        # Integer column
z.float_col("price")    # Float column
z.bool_col("active")    # Boolean column
z.date_col("created")   # Date column
```

### Special Columns

**Derived Columns**: Computed from expressions using other columns

```python
z.derived_col("full_name", 
    function=z.ref("first").col + " " + z.ref("last").col,
    data_type="string"
)
```

**Meta Columns**: Additional metadata fields

```python
z.meta_col("processed_at", 
    function=z.expr.datetime.now(),
    data_type="datetime"  
)
```

**Custom Validation Columns**: Complex validation rules

```python
z.derived_custom_check("age_check",
    function=z.ref("age").col.between(0, 150),
    message="Age must be between 0 and 150",
    thresholds=z.Threshold(error=0.05)
)
```

## API Reference

### Column Constructor Parameters

**Common Parameters:**
- `name` (str): Column identifier
- `data_type` (ColumnDataType): Expected data type
- `sensitivity` (Sensitivity): Data sensitivity level
- `aliases` (set[str]): Alternative column names
- `coerce` (CoerceOption): Type coercion behavior
- `validations` (List[Check]): Validation rules
- `clean` (CleanStage): Data cleaning configuration

### Method Chaining

All column methods return a new column instance, enabling fluent configuration:

```python
column = (z.str_col("email")
    .sensitivity(z.Sensitivity.IDENTIFIABLE)
    .aliases({"email_address", "e_mail"})
    .clean(z.Clean.string(, sanitize="lowercase") 
    .validations(
        z.Check.not_null(),
        z.Check.str_matches(r"^[^@]+@[^@]+\.[^@]+$")
    )
)
```

## Column Configuration

### Data Types
Specify the expected data format for type checking and coercion:

```python
z.col("price", data_type="decimal")
z.col("count", data_type="integer") 
z.col("active", data_type="boolean")
z.col("created", data_type="date")
```

### Sensitivity Levels
Mark columns based on data privacy requirements:

```python
z.str_col("name").sensitivity(z.Sensitivity.IDENTIFIABLE)
z.str_col("ssn").sensitivity(z.Sensitivity.SENSITIVE)
z.str_col("category").sensitivity(z.Sensitivity.NON_SENSITIVE)
```

### Column Aliases
Handle variations in column naming across data sources:

```python
# Single alias
z.str_col("name").aliases("full_name")

# Multiple aliases  
z.str_col("id").aliases({"user_id", "customer_id", "account_id"})

# Merge with existing aliases
z.str_col("phone").aliases({"mobile", "cell"}, merge=True)
```

### Optional Columns
Configure behavior when columns are missing from source data:

```python
z.str_col("middle_name").optional()           # Allow missing
z.str_col("last_name").optional(False)        # Required (default)
z.int_col("age").optional("warning")          # Warn if missing
```

## Column References

Use `z.ref()` to reference other columns in expressions:

```python
# Reference original column
z.ref("birth_date").col.dt.year()

# Reference cleaned version
z.ref("price_string").clean().col.cast(float)

# Complex derived column
z.derived_col("profit_margin",
    function=(z.ref("revenue").col - z.ref("cost").col) / z.ref("revenue").col
)
```

## Use Cases

### Data Import Processing
Handle messy CSV imports with cleaning and validation:

```python
z.str_col("customer_id")
    .clean(z.Clean.id(, prefix="CUST_")
    .validations(z.Check.not_null(), z.Check.unique()),

z.str_col("phone_number") 
    .clean(z.Clean.string(, sanitize="trim")
    .validations(z.Check.str_matches(r"^\+?[\d\s\-\(\)]+$")),

z.str_col("signup_date")
    .clean(z.Clean.date(, date_formats=["%Y-%m-%d", "%m/%d/%Y"])
    .validations(z.Check.valid_date())
```

### API Response Processing
Validate and normalize external API data:

```python
z.str_col("status")
    .validations(z.Check.is_in(["active", "inactive", "pending"])),

z.int_col("score")
    .validations(z.Check.between(min=0, max=100)),

z.str_col("created_timestamp")
    .clean(z.Clean.datetime()
    .validations(z.Check.not_null())
```

### Business Logic Implementation  
Create computed fields with business rules:

```python
# Age calculation
z.derived_col("age",
    function=z.expr.datetime.now().dt.year() - z.ref("birth_year").col,
    data_type="integer"
),

# Full name concatenation
z.derived_col("display_name", 
    function=z.ref("first").clean().col + " " + z.ref("last").clean().col,
    data_type="string"
),

# Eligibility check
z.derived_col("is_eligible",
    function=(z.ref("age").col >= 18) & (z.ref("status").col == "active"),
    data_type="boolean"
)
```