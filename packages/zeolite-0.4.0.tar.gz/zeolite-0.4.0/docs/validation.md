# Validation

Validation ensures data quality by applying rules and checks with configurable error thresholds. Zeolite provides built-in validation checks and supports custom validation logic.

## Basic Usage

Add validation rules to columns using the `.validations()` method:

```python
z.str_col("email").validations(
    z.Check.not_null(),
    z.Check.str_matches(r"^[^@]+@[^@]+\.[^@]+$")
)
```

## Threshold System

Validation uses a graduated threshold system for handling rule failures:

- **Debug**: Log issues, continue processing
- **Warning**: Log warnings, continue processing  
- **Error**: Log errors, continue with degraded quality
- **Reject**: Stop processing, data quality unacceptable

```python
z.Check.not_null(
    warning=0.05,   # Warn if >5% null
    error=0.10,     # Error if >10% null
    reject=0.20     # Reject if >20% null
)
```

## Available Checks

### Null and Empty Checks
Validate data presence and completeness:

```python
# No null values allowed
z.Check.not_null()

# Allow some null values with thresholds
z.Check.not_null(warning=0.05, error=0.10)

# Treat empty strings as null
z.Check.not_null(treat_empty_strings_as_null=True)
```

### Uniqueness Checks
Ensure values are unique within the dataset:

```python
# All values must be unique
z.Check.unique()

# Allow some duplicates
z.Check.unique(warning=0.01, error=0.05)

# Check uniqueness on cleaned data
z.Check.unique(check_on_cleaned=True)
```

### Equality Checks
Validate values against specific targets:

```python
# Must equal specific value
z.Check.equal_to("active")

# Must not equal specific value  
z.Check.not_equal_to("deleted")

# With thresholds
z.Check.equal_to("valid", error=0.05)
```

### Range and Comparison Checks
Validate numeric ranges and boundaries:

```python
# Less than comparisons
z.Check.less_than(100)
z.Check.less_than_or_equal(100)

# Greater than comparisons  
z.Check.greater_than(0)
z.Check.greater_than_or_equal(18)

# Range validation
z.Check.between(min=0, max=100)
z.Check.between(min=18, max=65, error=0.02)
```

### List Membership Checks
Validate values against allowed/forbidden lists:

```python
# Value must be in allowed list
z.Check.is_in(["active", "inactive", "pending"])

# Value must not be in forbidden list
z.Check.not_in(["deleted", "banned", "suspended"])

# With thresholds
z.Check.is_in(["small", "medium", "large"], warning=0.05)
```

### String Pattern Checks
Validate text using regular expressions:

```python
# Must match pattern
z.Check.str_matches(r"^[A-Z]{2,3}-\d{4}$")  # Code format

# Must not match pattern
z.Check.str_not_matches(r"test|demo|sample")  # No test data

# Email validation
z.Check.str_matches(r"^[^@]+@[^@]+\.[^@]+$")
```

### String Length Checks
Validate text length constraints:

```python
# Exact length
z.Check.str_length(length=10)

# Length range
z.Check.str_length(min_length=3, max_length=50)

# Minimum length only
z.Check.str_length(min_length=1, error=0.05)
```

### Date Validation
Validate date formats and values:

```python
# Valid date format
z.Check.valid_date()

# Check on original vs cleaned data
z.Check.valid_date(check_on_cleaned=False)
```

### Custom Validation
Create custom validation logic:

```python
# Custom check with Polars expression
z.Check.custom(
    expression=pl.col("age") > 0,
    message="Age must be positive"
)
```

## API Reference

### `z.Check` Methods

All check methods support these common parameters:
- `warning` (float): Threshold for warning level (0.0 to 1.0)
- `error` (float): Threshold for error level (0.0 to 1.0) 
- `reject` (float): Threshold for reject level (0.0 to 1.0)
- `check_on_cleaned` (bool): Apply to cleaned vs original data

### Threshold Shortcuts

Use shortcut strings for common threshold patterns:
- `"any"`: Any failure triggers the level (threshold = 0.0)
- `"all"`: All rows must fail to trigger (threshold = 1.0)

```python
z.Check.not_null(reject="any")        # Reject any nulls
z.Check.unique(error="any")           # Error on any duplicates  
```

## Advanced Validation

### Multi-Column Validation
Create validation rules that span multiple columns:

```python
z.derived_custom_check("age_validation",
    function=(z.ref("birth_year").col > 1900) & 
             (z.ref("birth_year").col <= 2024),
    message="Birth year must be between 1900 and 2024",
    thresholds=z.Threshold(error=0.01)
)
```

### Conditional Validation
Apply validation rules conditionally:

```python
z.derived_custom_check("conditional_email",
    function=z.when(z.ref("contact_type").col == "email")
             .then(z.ref("contact_value").col.str.contains("@"))
             .otherwise(True),
    message="Email contacts must contain @ symbol"
)
```

### Validation Chaining
Combine multiple validation rules with different thresholds:

```python
z.str_col("product_code").validations(
    z.Check.not_null(reject="any"),
    z.Check.str_matches(r"^[A-Z]{3}-\d{4}$", error=0.05),
    z.Check.unique(warning=0.01, error=0.10),
    z.Check.str_length(min_length=8, max_length=8)
)
```

## Use Cases

### Data Quality Assessment
Apply comprehensive validation for data quality reporting:

```python
schema = z.schema("quality_check").columns(
    z.str_col("customer_id").validations(
        z.Check.not_null(reject="any"),
        z.Check.unique(error="any"),
        z.Check.str_matches(r"^CUST_\d+$")
    ),
    z.int_col("age").validations(
        z.Check.between(min=0, max=150, warning=0.01),
        z.Check.not_null(error=0.05)
    ),
    z.str_col("email").validations(
        z.Check.str_matches(r"^[^@]+@[^@]+\.[^@]+$", error=0.02),
        z.Check.not_null(warning=0.10)
    )
)
```

### API Response Validation
Validate external API responses:

```python
schema = z.schema("api_validation").columns(
    z.str_col("status").validations(
        z.Check.is_in(["success", "pending", "failed"], reject="any")
    ),
    z.int_col("code").validations(
        z.Check.between(min=200, max=599)
    ),
    z.str_col("timestamp").validations(
        z.Check.valid_date(),
        z.Check.not_null(reject="any")
    )
)
```

### Business Rule Validation
Enforce business logic constraints:

```python
schema = z.schema("business_rules").columns(
    z.float_col("price").validations(
        z.Check.greater_than(0, reject="any"),
        z.Check.less_than(10000, warning=0.05)
    ),
    z.str_col("category").validations(
        z.Check.is_in(["electronics", "clothing", "books"], error=0.02)
    ),
    z.derived_custom_check("price_discount_check",
        function=z.ref("discount_price").col <= z.ref("original_price").col,
        message="Discount price cannot exceed original price",
        thresholds=z.Threshold(reject="any")
    )
)
```