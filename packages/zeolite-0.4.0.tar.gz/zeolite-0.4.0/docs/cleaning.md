# Cleaning

Data cleaning transforms raw input data into standardized, consistent formats. Zeolite provides built-in cleaners for common data types and transformation patterns.

## Basic Usage

Apply cleaning transformations using the `.clean()` method on columns:

```python
z.str_col("age").clean(z.Clean.integer())
z.str_col("price").clean(z.Clean.decimal(precision=2))  
z.str_col("active").clean(z.Clean.boolean(true_values={"yes", "1"}))
```

## Available Cleaners

### String Cleaning
Normalize and sanitize text data:

```python
# Basic string cleaning
z.str_col("name").clean(z.Clean.string())

# Sanitized string (trim, lowercase, normalize)
z.str_col("category").clean(z.Clean.string(sanitize="full"))

# Custom sanitization
z.str_col("title").clean(z.Clean.string(, sanitize="lowercase"))
```

**String Parameters:**
- `sanitize`: `"full"`, `"lowercase"`, `"trim"`, or `None`
- `sanitise_join_char`: Character for joining multiple values (default: `" "`)

### Numeric Cleaning  
Convert strings to numeric types with validation:

```python
# Integer conversion
z.str_col("count").clean(z.Clean.integer()

# Float conversion  
z.str_col("price").clean(z.Clean.float()

# Decimal with precision
z.str_col("amount").clean(z.Clean.decimal(precision=2))

# Generic number (auto-detects int/float)
z.str_col("value").clean(z.Clean.number())
```

### Boolean Cleaning
Convert various text representations to boolean values:

```python
z.str_col("active").clean(
    to="boolean",
    true_values={"yes", "true", "1", "active"},
    false_values={"no", "false", "0", "inactive"}
)
```

**Boolean Parameters:**
- `true_values`: Set of strings that represent `True`
- `false_values`: Set of strings that represent `False`

### Date and Time Cleaning
Parse date strings with flexible format support:

```python
# Basic date parsing
z.str_col("created").clean(z.Clean.date()

# Custom date formats
z.str_col("birth_date").clean(
    to="date", 
    date_formats=["%Y-%m-%d", "%m/%d/%Y", "%d-%m-%Y"]
)

# DateTime parsing
z.str_col("timestamp").clean(z.Clean.datetime())
```

### Enumeration Cleaning
Map values to standardized categories:

```python
z.str_col("gender").clean(
    to="enum",
    enum_map={
        "m": "Male", "male": "Male", "man": "Male",
        "f": "Female", "female": "Female", "woman": "Female",
        "nb": "Non-binary", "other": "Non-binary"
    },
    sanitize="lowercase"  # Apply before mapping
)
```

**Enum Parameters:**
- `enum_map`: Dictionary mapping input values to output values
- `invalid_value`: Value for unmapped inputs (default: `None`)
- `null_value`: Value for null inputs (default: `None`)

### ID Cleaning
Standardize identifier formats:

```python
z.str_col("user_id").clean(
    to="id",
    prefix="USER_",
    separator="-"
)
```

**ID Parameters:**
- `prefix`: String prefix to add to IDs  
- `separator`: Character between prefix and ID (default: `""`)

## API Reference

### `column.clean(to, **kwargs)`

**Parameters:**
- `to` (str): Target data type or cleaning method
- `**kwargs`: Type-specific cleaning parameters

**Supported `to` values:**
- `"string"`: Basic string normalization
- `"sanitised_string"`: Full text sanitization  
- `"integer"`: Convert to integer
- `"float"`: Convert to floating point
- `"decimal"`: Convert to decimal with precision
- `"number"`: Auto-detect numeric type
- `"boolean"`: Convert to boolean
- `"date"`: Parse as date
- `"datetime"`: Parse as datetime  
- `"enum"`: Map to enumerated values
- `"id"`: Format as identifier

## Advanced Cleaning

### Sensitivity Control
Specify sensitivity for cleaned columns:

```python
z.str_col("ssn").clean(
    to="id", 
    col_sensitivity=z.Sensitivity.SENSITIVE
)
```

### Output Format Control  
Specify exact Polars data types for cleaned data:

```python
z.str_col("price").clean(
    to="decimal",
    output_format=pl.Decimal(precision=10, scale=2)
)
```

### Custom Cleaning Logic
Use custom to 

```python
z.str_col("phone").clean(
    z.Clean.custom()
)
```

## Use Cases

### CSV Import Processing
Clean messy CSV data with inconsistent formats:

```python
schema = z.schema("csv_import").columns(
    z.str_col("customer_id").clean(z.Clean.id(, prefix="CUST_"),
    z.str_col("signup_date").clean(z.Clean.date(),
    z.str_col("is_premium").clean(
        to="boolean", 
        true_values={"yes", "premium", "1"}
    ),
    z.str_col("age").clean(z.Clean.integer(),
    z.str_col("country").clean(z.Clean.string(sanitize="full")
)
```

### API Response Normalization  
Standardize external API data:

```python
schema = z.schema("api_data").columns(
    z.str_col("user_status").clean(
        to="enum",
        enum_map={"ACTIVE": "active", "INACTIVE": "inactive"}
    ),
    z.str_col("created_at").clean(z.Clean.datetime(),
    z.str_col("score").clean(z.Clean.decimal(, precision=1)
)
```

### Legacy Data Migration
Transform old data formats to modern standards:

```python
schema = z.schema("legacy_migration").columns(
    z.str_col("old_id").clean(z.Clean.id(, prefix="NEW_"),
    z.str_col("gender_code").clean(
        to="enum",
        enum_map={"M": "Male", "F": "Female", "O": "Other"}
    ),
    z.str_col("birth_year").clean(z.Clean.integer(),
    z.str_col("full_name").clean(z.Clean.string(sanitize="full")
)
```