# Getting Started

Zeolite is a Python library for defining data schemas and processing raw data through cleaning and validation pipelines. It uses Polars for high-performance data processing.

## Installation

Install Zeolite using pip or your preferred package manager:

```bash
uv add zeolite
```

## Quick Example

Here's a simple schema that demonstrates Zeolite's core concepts:

```python
import zeolite as z

# Define a schema with columns, cleaning, and validation
user_schema = z.schema("users").columns(
    z.str_col("id")
        .clean(z.Clean.id(prefix="USER_"))
        .validations(
            z.Check.not_null(),
            z.Check.unique()
        ),
    
    z.str_col("email")
        .validations(z.Check.str_matches(r"^[^@]+@[^@]+\.[^@]+$")),
    
    z.str_col("age")
        .clean(z.Clean.integer())
        .validations(z.Check.between(min=0, max=150)),
    
    z.str_col("is_active")
        .clean(z.Clean.boolean(true_values={"yes", "1"}, false_values={"no", "0"}))
)
```

## Core Concepts

**Schema**: The top-level container that defines your table structure and processing rules.

```python
schema = z.schema("table_name")
```

**Columns**: Individual field definitions with data types, cleaning rules, and validations.

```python
z.str_col("name")  # String column
z.int_col("age")   # Integer column  
z.date_col("dob")  # Date column
```

**Cleaning**: Transform raw data into standardized formats.

```python
.clean(z.Clean.integer())  # Convert string to integer
.clean(z.Clean.date())     # Parse string as date
.clean(z.Clean.boolean(true_values={"yes"}, false_values={"no"}))
```

**Validation**: Define data quality rules with configurable thresholds.

```python
.validations(
    z.Check.not_null(),           # No null values
    z.Check.unique(),             # All values unique
    z.Check.between(min=0, max=100)  # Value range check
)
```

## Next Steps

- [Architecture](./architecture.md) - Understanding how components work together
- [Schema](./schema.md) - Detailed schema configuration
- [Columns](./columns.md) - Column types and options
- [Cleaning](./cleaning.md) - Data transformation patterns
- [Validation](./validation.md) - Quality checks and thresholds