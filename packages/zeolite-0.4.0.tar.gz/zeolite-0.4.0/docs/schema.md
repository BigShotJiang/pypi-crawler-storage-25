# Schema

A schema defines the structure and processing rules for your data table. It acts as the container for column definitions and coordinates the data transformation pipeline.

## Basic Usage

Create a schema by providing a name and column definitions:

```python
import zeolite as z

# Simple schema with basic columns
user_schema = z.schema("users").columns(
    z.str_col("name"),
    z.int_col("age"), 
    z.str_col("email")
)
```

## API Reference

### `z.schema(name)`

**Parameters:**
- `name` (str): Name identifier for the schema
- `columns` (List[ColumnSchema] | dict, optional): Column definitions
- `is_required` (bool, optional): Whether schema is required (default: True)
- `stage` (str, optional): Processing stage identifier

**Returns:** `TableSchema` - Schema instance for method chaining

## Adding Columns

### Method Chaining
Use the fluent interface to build schemas step by step:

```python
schema = (z.schema("products")
    .columns(
        z.str_col("id").clean(z.Clean.id(prefix="PROD_")),
        z.str_col("name").validations(z.Check.not_null()),
        z.str_col("price").clean(z.Clean.decimal())
    )
)
```

### Column Lists
Pass columns as a list for larger schemas:

```python
columns = [
    z.str_col("user_id").clean(z.Clean.id()),
    z.str_col("first_name"),
    z.str_col("last_name"), 
    z.int_col("age").validations(z.Check.between(min=0, max=150))
]

schema = z.schema("users").columns(columns)
```

### Dictionary Format
Use dictionaries for dynamic schema construction:

```python
column_specs = {
    "id": z.str_col().clean(z.Clean.id()),
    "name": z.str_col().validations(z.Check.not_null()),
    "score": z.int_col().validations(z.Check.between(min=0, max=100))
}

schema = z.schema("scores").columns(column_specs)
```

## Schema Properties

### Name and Identification
Each schema has a unique name used for identification and processing:

```python
schema = z.schema("customer_data")
print(schema.name)  # "customer_data"
```

### Column Access
Access individual columns by name after schema creation:

```python
schema = z.schema("users").columns(
    z.str_col("name"),
    z.int_col("age")
)

name_column = schema.get_column("name")
age_column = schema.get_column("age")
```

## Use Cases

### Data Import Schemas
Define schemas for processing raw CSV or database imports:

```python
import_schema = z.schema("raw_customers").columns(
    z.str_col("customer_id").clean(z.Clean.id(prefix="CUST_")),
    z.str_col("full_name").clean(z.Clean.string(sanitize="full")),
    z.str_col("birth_date").clean(z.Clean.date()),
    z.str_col("phone").clean(z.Clean.string(sanitize="trim"))
)
```

### API Response Schemas
Validate data from external APIs:

```python
api_schema = z.schema("api_response").columns(
    z.str_col("id").validations(z.Check.not_null(), z.Check.unique()),
    z.str_col("status").validations(z.Check.is_in(["active", "inactive", "pending"])),
    z.int_col("created_timestamp").validations(z.Check.greater_than(0))
)
```

### Data Quality Schemas
Focus on validation with strict quality rules:

```python
quality_schema = z.schema("validated_data").columns(
    z.str_col("email").validations(
        z.Check.str_matches(r"^[^@]+@[^@]+\.[^@]+$"),
        z.Check.not_null(reject="any")
    ),
    z.int_col("age").validations(
        z.Check.between(min=0, max=150, reject=0.01),
        z.Check.not_null(error=0.05)
    )
)
```