# %%
import polars as pl
import zeolite as z

# NOTE: All source columns are strings because this example models a CSV import.
# Cleans produce the typed columns used by validations and downstream derivations.


# %% Enumerations and reusable validation definitions

ORDER_STATUS_VALUES = {
    "new": "new",
    "pending": "pending",
    "paid": "paid",
    "shipped": "shipped",
    "complete": "complete",
    "completed": "complete",
    "cancelled": "cancelled",
    "canceled": "cancelled",
    "refunded": "refunded",
}

PAYMENT_METHOD_VALUES = {
    "card": "card",
    "credit card": "card",
    "bank transfer": "bank_transfer",
    "bank_transfer": "bank_transfer",
    "cash": "cash",
    "voucher": "voucher",
}

CONTACT_METHOD_VALUES = {
    "email": "email",
    "phone": "phone",
    "sms": "sms",
    "post": "post",
    "none": "none",
}

COUNTRY_VALUES = {
    "nz": "NZ",
    "new zealand": "NZ",
    "au": "AU",
    "australia": "AU",
    "us": "US",
    "united states": "US",
    "gb": "GB",
    "united kingdom": "GB",
}

CUSTOMER_SEGMENT_VALUES = {
    "retail": "retail",
    "wholesale": "wholesale",
    "enterprise": "enterprise",
    "internal": "internal",
    "test": "test",
}

mandatory_clean_value = z.Check.not_null(
    check_on_cleaned=True,
    warning="any",
    error=0.05,
    reject=0.25,
)
valid_clean_enum = z.Check.ne(
    z.INVALID_DATA,
    check_on_cleaned=True,
    warning=0.02,
    error=0.10,
).alias("enum_value_known")


# %% Source columns

source_system_col = (
    z.col.str("source_system")
    .variants("Source System", "source")
    .sensitivity(z.Sensitivity.NON_SENSITIVE)
    .clean(z.Clean.sanitised_string(sanitise="full"))
    .validations(
        z.Check.not_empty(warning="any"),
        z.Check.is_in(
            ["web", "pos", "marketplace", "support_import"],
            check_on_cleaned=True,
            warning=0.05,
        ),
    )
)

source_file_col = (
    z.col.str("source_file")
    .optional("warning")
    .sensitivity(z.Sensitivity.LIMITED)
    .clean(z.Clean.string(sanitise="trim"))
    .validations(
        z.Check.str_matches(
            r".+\.(csv|tsv|txt)$",
            nulls_valid=True,
            check_on_cleaned=True,
            warning=0.05,
        ).alias("source_file_extension_ok")
    )
)

ingested_at_col = (
    z.col.str("ingested_at")
    .optional("warning")
    .sensitivity(z.Sensitivity.NON_SENSITIVE)
    .clean(z.Clean.datetime().alias("ingested_at_ts"))
    .validations(
        z.Check.valid_date(
            check_on_cleaned=True,
            nulls_valid=True,
            warning=0.05,
        ).alias("ingested_at_valid_timestamp")
    )
)

raw_row_number_col = (
    z.col.str("raw_row_number")
    .variants("row", "line_number")
    .temporary()
    .clean(z.Clean.int().alias("import_row_number", is_temporary=True))
    .validations(
        z.Check.gte(1, check_on_cleaned=True, debug=10).alias(
            "row_number_positive", is_temporary=True
        )
    )
)

customer_id_col = (
    z.col.str("customer_id")
    .variants("Customer ID", "cust_id", "customer")
    .sensitivity(z.Sensitivity.IDENTIFIABLE)
    .clean(
        z.Clean.id(
            prefix="CUST",
            sanitise="uppercase",
            col_sensitivity=z.Sensitivity.IDENTIFIABLE,
        )
    )
    .validations(
        z.Check.not_empty(
            check_on_cleaned=True,
            reject="any",
            remove_row_on_fail=True,
        ),
        z.Check.unique(check_on_cleaned=True, error="any"),
        z.Check.str_matches(
            r"^CUST::[A-Z0-9_-]+$",
            check_on_cleaned=True,
            reject=2,
        ).alias("customer_id_shape"),
    )
)

customer_name_col = (
    z.col.str("customer_name")
    .variants("Customer Name", "name")
    .sensitivity(z.Sensitivity.IDENTIFIABLE)
    .clean(
        z.Clean.string(
            sanitise="trim",
            col_sensitivity=z.Sensitivity.IDENTIFIABLE,
            alias="customer_name_trimmed",
        )
    )
    .validations(
        z.Check.not_empty(warning="any", error=0.05),
        z.Check.str_len(
            min_length=2,
            max_length=120,
            trim=True,
            warning=0.02,
        ).alias("customer_name_length_ok"),
        z.Check.str_not_matches(
            r"(?i)\b(test|dummy|unknown)\b",
            nulls_valid=True,
            warning=0.01,
        ).alias("customer_name_not_placeholder"),
    )
)

email_col = (
    z.col.str("email")
    .variants("Email Address", "email_address")
    .optional("warning")
    .sensitivity(z.Sensitivity.IDENTIFIABLE)
    .clean(
        z.Clean.sanitised_string(
            sanitise="lowercase",
            col_sensitivity=z.Sensitivity.IDENTIFIABLE,
            alias="email_normalised",
        )
    )
    .validations(
        z.Check.str_matches(
            r"^[^@\s]+@[^@\s]+\.[^@\s]+$",
            nulls_valid=True,
            check_on_cleaned=True,
            warning=0.05,
        ).alias("email_format_ok"),
        z.Check.custom(
            lambda col: col.is_null() | col.str.ends_with(".invalid").not_(),
            label="email_not_invalid_tld",
            check_on_cleaned=True,
            debug=0.01,
            warning=0.05,
        ),
    )
)

phone_col = (
    z.col.str("phone")
    .variants("Phone Number", "mobile")
    .optional()
    .sensitivity(z.Sensitivity.IDENTIFIABLE)
    .clean(
        z.Clean.custom(
            lambda col: col.cast(pl.String).str.replace_all(r"\D", "", literal=False),
            data_type="string",
            col_sensitivity=z.Sensitivity.IDENTIFIABLE,
            alias="phone_digits",
        )
    )
    .validations(
        z.Check.custom(
            lambda col: col.is_null() | col.str.len_chars().is_between(7, 15),
            label="phone_length_ok",
            check_on_cleaned=True,
            warning=0.10,
        )
    )
)

support_contact_col = (
    z.col.str("support_contact")
    .optional()
    .sensitivity(z.Sensitivity.POTENTIALLY_IDENTIFIABLE)
    .clean(z.Clean.string(sanitise="trim").alias("support_contact_trimmed"))
    .validations(
        z.Check.xor(
            z.Check.str_matches(r"^email:", check_on_cleaned=True, nulls_valid=True),
            z.Check.str_matches(r"^phone:", check_on_cleaned=True, nulls_valid=True),
            warning=0.10,
        ).alias("exactly_one_support_contact_kind")
    )
)

order_id_col = (
    z.col.str("order_id")
    .variants("Order ID", "order")
    .sensitivity(z.Sensitivity.LIMITED)
    .clean(z.Clean.id(prefix=source_system_col.ref.clean(), sanitise="uppercase"))
    .validations(
        z.Check.not_empty(check_on_cleaned=True, reject="any", remove_row_on_fail=True),
        z.Check.unique(check_on_cleaned=True, error="any", remove_row_on_fail=True),
    )
)

order_status_col = (
    z.col.str("order_status")
    .variants("status")
    .clean(
        z.Clean.enum(
            enum_map=ORDER_STATUS_VALUES,
            sanitise="full",
            null_value=None,
        )
    )
    .validations(
        mandatory_clean_value.alias("order_status_present"),
        valid_clean_enum.alias("order_status_known"),
        z.Check.not_in(
            ["cancelled", "refunded"],
            check_on_cleaned=True,
            nulls_valid=False,
            debug=0.05,
            warning=0.25,
        ).alias("order_status_not_terminal"),
    )
)

payment_method_col = (
    z.col.str("payment_method")
    .optional("warning")
    .clean(
        z.Clean.enum(
            enum_map=PAYMENT_METHOD_VALUES,
            sanitise="full",
            alias="payment_method_clean",
        )
    )
    .validations(
        z.Check.any(
            z.Check.is_null(check_on_cleaned=True),
            z.Check.ne(z.INVALID_DATA, check_on_cleaned=True),
            warning=0.02,
        ).alias("payment_method_missing_or_known")
    )
)

contact_method_col = (
    z.col.str("preferred_contact_method")
    .optional()
    .clean(
        z.Clean.enum(
            enum_map=CONTACT_METHOD_VALUES,
            sanitise="full",
            alias="contact_method",
        )
    )
    .validations(
        z.Check.is_in(
            ["email", "phone", "sms", "post", "none", z.NO_DATA],
            check_on_cleaned=True,
            warning=0.03,
        ).alias("contact_method_allowed")
    )
)

customer_segment_col = (
    z.col.str("customer_segment")
    .optional("warning")
    .clean(
        z.Clean.enum(
            enum_map=CUSTOMER_SEGMENT_VALUES,
            sanitise="full",
            alias="segment",
        )
    )
    .validations(
        z.Check.ne("test", check_on_cleaned=True, warning="any").alias(
            "segment_not_test"
        )
    )
)

country_col = (
    z.col.str("country")
    .variants("Country Code", "shipping_country")
    .optional("warning")
    .clean(
        z.Clean.enum(
            enum_map=COUNTRY_VALUES,
            sanitise="full",
            alias="country_code",
        )
    )
    .validations(
        z.Check.all(
            z.Check.not_null(check_on_cleaned=True),
            z.Check.ne(z.INVALID_DATA, check_on_cleaned=True),
            warning=0.10,
            error=0.20,
        ).alias("country_present_and_known")
    )
)

postal_code_col = (
    z.col.str("postal_code")
    .optional()
    .clean(
        z.Clean.sanitised_string(sanitise="uppercase").alias(
            "postal_code_normalised",
            is_temporary=True,
        )
    )
    .validations(
        z.Check.str_len(
            min_length=3,
            max_length=12,
            check_on_cleaned=True,
            nulls_valid=True,
            warning=0.05,
        ).alias("postal_code_length_ok", is_temporary=True)
    )
)

order_date_col = (
    z.col.str("order_date")
    .variants("Order Date")
    .clean(z.Clean.date(day_first=False))
    .validations(
        z.Check.all(
            z.Check.not_null(check_on_cleaned=True),
            z.Check.valid_date(check_on_cleaned=True),
            reject="any",
            remove_row_on_fail=True,
        ).alias("order_date_required_and_valid"),
    )
)

ship_date_col = (
    z.col.str("ship_date")
    .variants("Shipped Date")
    .optional()
    .clean(z.Clean.date(day_first=False).alias("ship_date_clean"))
    .validations(
        z.Check.any(
            z.Check.is_null(check_on_cleaned=True),
            z.Check.valid_date(check_on_cleaned=True),
            warning=0.05,
        ).alias("ship_date_blank_or_valid")
    )
)

delivered_at_col = (
    z.col.str("delivered_at")
    .optional()
    .clean(z.Clean.datetime().alias("delivered_at_ts"))
    .validations(
        z.Check.valid_date(
            check_on_cleaned=True,
            nulls_valid=True,
            warning=0.05,
        ).alias("delivered_at_valid_timestamp")
    )
)

order_time_col = (
    z.col.str("order_time")
    .optional()
    .clean(z.Clean.time(time_format="%H:%M:%S").alias("order_time_clean"))
)

handling_minutes_col = (
    z.col.str("handling_minutes")
    .optional()
    .clean(
        z.Clean.duration(
            input_unit="minutes",
            output_unit="ms",
            alias="handling_duration",
        )
    )
)

quantity_col = (
    z.col.str("quantity")
    .clean(z.Clean.int())
    .validations(
        z.Check.gte(1, check_on_cleaned=True, reject="any", remove_row_on_fail=True),
        z.Check.lte(500, check_on_cleaned=True, warning=0.01, error=0.05),
    )
)

unit_price_col = (
    z.col.str("unit_price")
    .clean(z.Clean.decimal(decimal_places=2).alias("unit_price_amount"))
    .validations(
        z.Check.gt(0, check_on_cleaned=True, reject="any", remove_row_on_fail=True),
        z.Check.between(
            0.01,
            50000,
            check_on_cleaned=True,
            warning=0.01,
            error=0.05,
        ).alias("unit_price_reasonable"),
    )
)

discount_amount_col = (
    z.col.str("discount_amount")
    .optional()
    .clean(z.Clean.number().alias("discount_amount_value"))
    .validations(
        z.Check.gte(0, check_on_cleaned=True, nulls_valid=True, warning=0.05),
        z.Check.lt(10000, check_on_cleaned=True, nulls_valid=True, debug=0.02),
    )
)

tax_rate_col = (
    z.col.str("tax_rate")
    .optional()
    .clean(z.Clean.number().alias("tax_rate_value", is_temporary=True))
    .validations(
        z.Check.between(
            0,
            1,
            check_on_cleaned=True,
            nulls_valid=True,
            warning=0.05,
        ).alias("tax_rate_between_zero_and_one", is_temporary=True)
    )
)

gift_wrap_col = (
    z.col.str("gift_wrap")
    .optional()
    .clean(
        z.Clean.boolean(
            true_values={"yes", "y", "true", "1", "gift"},
            false_values={"no", "n", "false", "0", "none"},
            alias="is_gift_wrap",
        )
    )
    .validations(
        z.Check.custom(
            lambda col: col.is_null() | col.is_in([True, False]),
            label="gift_wrap_boolean_cleaned",
            check_on_cleaned=True,
            warning=0.05,
        )
    )
)

loyalty_points_col = (
    z.col.str("loyalty_points")
    .optional()
    .clean(z.Clean.int().alias("loyalty_points_value"))
    .validations(
        z.Check.gte(0, check_on_cleaned=True, nulls_valid=True, warning=0.05),
        z.Check.less_than_or_equal(
            1000000,
            check_on_cleaned=True,
            nulls_valid=True,
            error=3,
        ).alias("loyalty_points_ceiling"),
    )
)

coupon_code_col = (
    z.col.str("coupon_code")
    .optional()
    .clean(
        z.Clean.custom(
            lambda col: (
                col.cast(pl.String)
                .str.strip_chars()
                .str.to_uppercase()
                .str.replace_all(r"[^A-Z0-9-]", "", literal=False)
            ),
            data_type="string",
            alias="coupon_code_normalised",
        )
    )
    .validations(
        z.Check.str_len(
            min_length=4,
            max_length=32,
            check_on_cleaned=True,
            nulls_valid=True,
            warning=0.05,
        ),
        z.Check.str_not_matches(
            r"^FREE-ALL$",
            check_on_cleaned=True,
            nulls_valid=True,
            warning="any",
        ).alias("coupon_not_forbidden"),
    )
)

survey_score_col = (
    z.col.str("survey_score")
    .optional()
    .clean(z.Clean.int().alias("survey_score_value"))
    .validations(
        z.Check.between(
            1,
            10,
            check_on_cleaned=True,
            nulls_valid=True,
            warning=0.10,
        ),
        z.Check.ne(0, check_on_cleaned=True, nulls_valid=True, debug=0.01),
    )
)

internal_notes_col = (
    z.col.str("internal_notes")
    .optional()
    .sensitivity(z.Sensitivity.CONFIDENTIAL)
    .clean(
        z.Clean.string(
            sanitise="trim",
            col_sensitivity=z.Sensitivity.CONFIDENTIAL,
        ).temporary()
    )
    .validations(
        z.Check.str_not_matches(
            r"(?i)\b(password|secret|token)\b",
            check_on_cleaned=True,
            nulls_valid=True,
            error="any",
        ).alias("notes_do_not_contain_secrets")
    )
)


# %% Derived columns and custom row checks

line_total_col = z.col.derived(
    "line_total",
    data_type=pl.Decimal(None, 2),
    sensitivity=z.Sensitivity.LIMITED,
    function=quantity_col.ref.clean().col * unit_price_col.ref.clean().col,
    validations=[
        z.Check.gte(0, warning="any"),
        z.Check.lt(10000000, error=0.01),
    ],
)

tax_amount_col = z.col.derived(
    "tax_amount",
    data_type="float",
    sensitivity=z.Sensitivity.LIMITED,
    function=line_total_col.ref.col * tax_rate_col.ref.clean().col.fill_null(0),
)

net_total_col = z.col.derived(
    "net_total",
    data_type="float",
    sensitivity=z.Sensitivity.LIMITED,
    function=line_total_col.ref.col
    + tax_amount_col.ref.col
    - discount_amount_col.ref.clean().col.fill_null(0),
    validations=[
        z.Check.gte(0, warning="any", error=0.01),
        z.Check.less_than(10000000, error=0.01),
    ],
)

high_value_order_col = z.col.derived(
    "is_high_value_order",
    data_type="boolean",
    sensitivity=z.Sensitivity.NON_SENSITIVE,
    function=net_total_col.ref.col.gt(1000),
)

customer_contactable_col = z.col.derived(
    "is_customer_contactable",
    data_type="boolean",
    sensitivity=z.Sensitivity.POTENTIALLY_IDENTIFIABLE,
    function=(
        email_col.ref.clean().col.is_not_null()
        | phone_col.ref.clean().col.str.len_chars().ge(7)
    ),
)

risk_band_col = z.col.derived(
    "risk_band",
    data_type="string",
    sensitivity=z.Sensitivity.LIMITED,
    function=(
        pl.when(customer_segment_col.ref.clean().col.eq("test"))
        .then(pl.lit("test"))
        .when(high_value_order_col.ref.col & customer_contactable_col.ref.col.not_())
        .then(pl.lit("high"))
        .when(net_total_col.ref.col.gt(500))
        .then(pl.lit("medium"))
        .otherwise(pl.lit("standard"))
    ),
    validations=[
        z.Check.is_in(["test", "high", "medium", "standard"], warning="any"),
    ],
)

valid_contact_for_method_check = z.col.custom_check(
    "valid_contact_for_method",
    function=(
        contact_method_col.ref.clean().col.eq("none")
        | (
            contact_method_col.ref.clean().col.eq("email")
            & email_col.ref.clean().col.is_not_null()
        )
        | (
            contact_method_col.ref.clean().col.is_in(["phone", "sms"])
            & phone_col.ref.clean().col.str.len_chars().ge(7)
        )
        | contact_method_col.ref.clean().col.eq("post")
    ),
    thresholds={"warning": 0.05, "error": 0.15, "reject": 0.50},
    message="{{column}} has {{count}} row(s) where contact details do not support the preferred contact method ({{fraction}})",
)

valid_shipping_timeline_check = z.col.custom_check(
    "valid_shipping_timeline",
    function=(
        ship_date_col.ref.clean().col.is_null()
        | order_date_col.ref.clean().col.is_null()
        | ship_date_col.ref.clean().col.ge(order_date_col.ref.clean().col)
    ),
    thresholds={"warning": 0.01, "error": 0.05},
    message="{{column}} has {{count}} row(s) where ship date is before order date ({{fraction}})",
)

valid_discount_check = z.col.custom_check(
    "valid_discount_amount",
    function=(
        discount_amount_col.ref.clean().col.is_null()
        | discount_amount_col.ref.clean().col.le(line_total_col.ref.col)
    ),
    thresholds={"warning": "any", "error": 0.05},
    remove_row_on_fail=True,
    message="{{column}} has {{count}} row(s) where discount exceeds the line total ({{fraction}})",
)

valid_country_postal_code_check = z.col.custom_check(
    "valid_country_postal_code",
    function=(
        country_col.ref.clean().col.ne("NZ")
        | postal_code_col.ref.clean().col.str.contains(r"^\d{4}$")
    ),
    thresholds={"debug": 0.01, "warning": 0.05, "error": 0.20},
    message="{{column}} has {{count}} NZ row(s) without a four digit postal code ({{fraction}})",
)

valid_total_for_status_check = z.col.custom_check(
    "valid_total_for_status",
    function=(
        order_status_col.ref.clean().col.is_in(["cancelled", "refunded"])
        | net_total_col.ref.col.gt(0)
    ),
    thresholds={"warning": 0.05, "reject": "all"},
    message="{{column}} has {{count}} non-terminal order(s) without a positive total ({{fraction}})",
)


# %% Schema definition

KitchenSinkSchema = (
    z.schema(
        "kitchen_sink",
        stage="bronze",
        strict=True,
    )
    .columns(
        source_system_col,
        source_file_col,
        ingested_at_col,
        raw_row_number_col,
        customer_id_col,
        customer_name_col,
        email_col,
        phone_col,
        support_contact_col,
        order_id_col,
        order_status_col,
        payment_method_col,
        contact_method_col,
        customer_segment_col,
        country_col,
        postal_code_col,
        order_date_col,
        ship_date_col,
        delivered_at_col,
        order_time_col,
        handling_minutes_col,
        quantity_col,
        unit_price_col,
        discount_amount_col,
        tax_rate_col,
        gift_wrap_col,
        loyalty_points_col,
        coupon_code_col,
        survey_score_col,
        internal_notes_col,
        line_total_col,
        tax_amount_col,
        net_total_col,
        high_value_order_col,
        customer_contactable_col,
        risk_band_col,
        valid_contact_for_method_check,
        valid_shipping_timeline_check,
        valid_discount_check,
        valid_country_postal_code_check,
        valid_total_for_status_check,
    )
    .table_validation(
        z.TableCheck.removed_rows(debug=0.01, warning=0.05, error=0.20, reject=0.40),
        z.TableCheck.min_rows(debug=100, warning=50, error=10, reject=1),
    )
)


kitchen_sink = KitchenSinkSchema
kitchen_sink_schema = KitchenSinkSchema
