# %%
import polars as pl
import zeolite as z
from zeolite._utils.calc_age import calculate_age
from zeolite.schema import SchemaArtifact

# %% Meta
meta_source_col = z.col("pipeline_source")
meta_extract_date = z.col("pipeline_period_start")
meta_period_date = z.col("pipeline_period_start")

# %% Age columns

date_of_birth_col = z.col.str("date_of_birth").variants("DOB").clean(z.Clean.date())

age_col = z.col.derived(
    "age_at_extract",
    function=calculate_age(
        date_of_birth_col.ref.clean().name,
        comparison_date=meta_period_date.name,
    ),
)
age_group_col = z.col.derived(
    "age_group",
    function=(
        pl.when(pl.col(age_col.name).lt(10))
        .then(pl.lit("under_10_years"))
        .when(pl.col(age_col.name).is_between(10, 18, closed="left"))
        .then(pl.lit("10_17_years"))
        .when(pl.col(age_col.name).is_between(18, 25, closed="left"))
        .then(pl.lit("18_24_years"))
        .when(pl.col(age_col.name).is_between(25, 45, closed="left"))
        .then(pl.lit("25_44_years"))
        .when(pl.col(age_col.name).is_between(45, 65, closed="left"))
        .then(pl.lit("45_64_years"))
        .when(pl.col(age_col.name).ge(65))
        .then(pl.lit("over_65"))
        .otherwise(pl.lit("unknown"))
        .cast(
            pl.Enum(
                [
                    "under_10_years",
                    "10_17_years",
                    "18_24_years",
                    "25_44_years",
                    "45_64_years",
                    "over_65",
                    "unknown",
                ]
            )
        )
    ),
)
# %%

ethnicity_check = z.Check.str_matches(r"^\d{2,5}$", nulls_valid=True, warning=0.05)

ethn_1 = (
    z.col.str("ethnicity_1")
    .variants("Ethnicity1")
    .validations(
        ethnicity_check.alias("ethnicity_1_format_correct"),
    )
)
ethn_2 = (
    z.col.str("ethnicity_2")
    .variants("Ethnicity2")
    .optional("warning")
    .validations(
        ethnicity_check.alias("ethnicity_2_format_correct"),
    )
)
ethn_3 = (
    z.col.str("ethnicity_3")
    .variants("Ethnicity3")
    .optional("warning")
    .validations(
        ethnicity_check.alias("ethnicity_3_format_correct"),
    )
)
ethn_4 = (
    z.col.str("ethnicity_4")
    .variants("Ethnicity4")
    .optional("warning")
    .validations(
        ethnicity_check.alias("ethnicity_4_format_correct"),
    )
)
ethn_5 = (
    z.col.str("ethnicity_5")
    .variants("Ethnicity5")
    .optional("warning")
    .validations(
        ethnicity_check.alias("ethnicity_5_format_correct"),
    )
)
ethn_6 = (
    z.col.str("ethnicity_6")
    .variants("Ethnicity6")
    .optional("warning")
    .validations(
        ethnicity_check.alias("ethnicity_6_format_correct"),
    )
)

# %%


def _make_ethn_col(name: str, match: str):
    return z.col.derived(
        name,
        function=(
            pl.any_horizontal(
                ethn_1.ref.col.str.slice(0, len(match)).eq(match),
                ethn_2.ref.col.str.slice(0, len(match)).eq(match),
                ethn_3.ref.col.str.slice(0, len(match)).eq(match),
                ethn_4.ref.col.str.slice(0, len(match)).eq(match),
                ethn_5.ref.col.str.slice(0, len(match)).eq(match),
                ethn_6.ref.col.str.slice(0, len(match)).eq(match),
            )
        ),
    )


is_maori_col = _make_ethn_col("is_maori", "2")
is_pacific_col = _make_ethn_col("is_pacific", "3")
is_asian_col = _make_ethn_col("is_asian", "4")
is_melaa_col = _make_ethn_col("is_melaa", "5")
is_pakeha_col = _make_ethn_col("is_pakeha", "11")

# %%


def _make_other_col(col: pl.Expr):
    return (
        col.str.slice(0, 1)
        .eq("6")
        .or_(col.str.slice(0, 1).eq("1").and_(col.str.slice(0, 2).ne("11")))
    )


is_other_col = z.col.derived(
    "is_other",
    function=(
        _make_other_col(ethn_1.ref.col)
        .or_(_make_other_col(ethn_2.ref.col))
        .or_(_make_other_col(ethn_3.ref.col))
        .or_(_make_other_col(ethn_4.ref.col))
        .or_(_make_other_col(ethn_5.ref.col))
        .or_(_make_other_col(ethn_6.ref.col))
    ),
)

# %%

prioritised_ethnicity_col = z.col.derived(
    "ethnicity_prioritised",
    function=(
        pl.when(is_maori_col.ref.col)
        .then(pl.lit("maori"))
        .when(is_pacific_col.ref.col)
        .then(pl.lit("pacific"))
        .when(is_asian_col.ref.col)
        .then(pl.lit("asian"))
        .when(is_melaa_col.ref.col)
        .then(pl.lit("melaa"))
        .when(is_pakeha_col.ref.col)
        .then(pl.lit("pakeha"))
        .when(is_other_col.ref.col)
        .then(pl.lit("other"))
        .otherwise(pl.lit("unknown"))
        .cast(
            pl.Enum(
                [
                    "maori",
                    "pacific",
                    "asian",
                    "pakeha",
                    "melaa",
                    "other",
                    "unknown",
                ]
            )
        )
    ),
)

# Replace these placeholders once the enum definitions are available.
GENDER_VALUES = {"M": "male", "F": "female", "tane": "male"}

PLACE_DEATH_VALUES = {
    "1": "1",
    "2": "2",
    "3": "3",
    "4": "4",
    "5": "5",
    "6": "6",
    "99": "unknown",
}

date_death_col = z.col.str("date_death").variants("DateDeath").clean(z.Clean.date())

# place_death_check = z.Check.is_in(
#     PLACE_DEATH_VALUES.keys(), nulls_valid=True, warning=0.05
# ).alias("valid_place_death_values")
place_death_check = z.Check.ne(z.INVALID_DATA, nulls_valid=True, warning=0.05).alias(
    "valid_place_death_values"
)
place_death_col = (
    z.col.str("place_death")
    .variants("PlaceDeath")
    .clean(z.Clean.enum(enum_map=PLACE_DEATH_VALUES, sanitise="full", null_value=None))
    .validations(place_death_check)
)


# %% Validation Schema definition
PatientSchema = z.schema(
    "patient",
    stage="bronze",
    columns=[
        # --------------------------------------------------
        z.col.str("nhi")
        .clean(z.Clean.sanitised_string(sanitise="uppercase"))
        .validations(
            z.Check.not_null(warning="any", remove_row_on_fail=True),
            z.Check.unique(warning="any"),
            z.Check.str_matches(
                r"^[A-Z]{3}\d{4}$|^[A-Z]{3}\d{3}[A-Z]$",
                remove_row_on_fail=True,
                nulls_valid=True,
                warning="any",
            ).alias("is_valid_nhi"),
        ),
        date_death_col,
        date_of_birth_col.validations(
            z.Check.not_null(warning=0.05),
            z.Check.valid_date(warning=0.05, check_on_cleaned=True, nulls_valid=True),
        ),
        # --------------------------------------------------
        z.col.str("address_city").variants("AddressCity", "Address City", "City"),
        z.col.str("address_suburb").variants("AddressSuburb"),
        z.col.str("postcode")
        .variants("Postcode")
        .clean(z.Clean.sanitised_string(sanitise="full"))
        .validations(
            z.Check.str_matches(
                r"^\d{4}$", nulls_valid=True, warning=0.05, check_on_cleaned=True
            ).alias("valid_postcode"),
        ),
        # --------------------------------------------------
        ethn_1,
        ethn_2,
        ethn_3,
        ethn_4,
        ethn_5,
        ethn_6,
        # --------------------------------------------------
        z.col.str("gender")
        .clean(z.Clean.enum(enum_map=GENDER_VALUES, null_value=None, sanitise="full"))
        .validations(
            z.Check.ne(z.INVALID_DATA, reject="any"),
        ),
        # --------------------------------------------------
        z.col.str("iwi_code_1").variants("IwiCode1"),
        z.col.str("iwi_code_2").variants("IwiCode2"),
        z.col.str("iwi_code_3").variants("IwiCode3"),
        z.col.str("iwi_name_1").variants("IwiName1"),
        z.col.str("iwi_name_2").variants("IwiName2"),
        z.col.str("iwi_name_3").variants("IwiName3"),
        # --------------------------------------------------
        place_death_col,
        z.col.custom_check(
            "valid_place_death",
            # function=date_death_col.ref.clean().col.is_null().or_(place_death_col.ref.check(place_death_check).col.eq("pass")),
            function=date_death_col.ref.clean()
            .col.is_null()
            .or_(place_death_col.ref.check("valid_place_death_values").col.eq("pass")),
            thresholds={"warning": 0.05},
        ),
        is_maori_col,
        is_pacific_col,
        is_asian_col,
        is_melaa_col,
        is_pakeha_col,
        is_other_col,
        prioritised_ethnicity_col,
        # --------------------------------------------------
        meta_source_col,
        meta_period_date,
    ],
).table_validation(z.TableCheck.removed_rows(warning="any"))

# %%
artifact = SchemaArtifact.from_schema(PatientSchema)
# %%.
artifact.save(".data/patient.zeo")

# %%
spec = PatientSchema.to_spec().to_dict()
