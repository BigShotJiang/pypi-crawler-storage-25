"""Optional HTTPS ingest of SDK telemetry into the CogNEXUS dashboard.

Requires an API key created under **Account → API Keys** in the dashboard.
If no key or base URL is configured, :func:`post_sdk_event` returns immediately
without raising — user application code keeps running.

Environment variables
---------------------
``COGNEXUS_API_KEY``
    Primary secret sent as ``X-Api-Key``.
``MYAPP_API_KEY``
    Fallback secret name (same semantics as ``COGNEXUS_API_KEY``).
``COGNEXUS_API_BASE_URL``
    API origin, e.g. ``https://cognexuslabs.ai`` — **no trailing slash required**.
"""

from __future__ import annotations

import json
import logging
import os
import platform
import sys
import threading
import urllib.error
import urllib.request
from typing import Any, Optional

_log = logging.getLogger("cognexus.cloud")

_override_key: Optional[str] = None
_override_base: Optional[str] = None
_session_lock = threading.Lock()
_session_logged = False

_MISSING = object()


def _package_version() -> str:
    try:
        from importlib.metadata import version

        return version("cognexus")
    except Exception:
        return "unknown"


def has_api_key() -> bool:
    """True when cloud ingest is configured (override or env)."""
    return _effective_key() is not None


def configure(*, api_key: Any = _MISSING, base_url: Any = _MISSING) -> None:
    """Set package-wide defaults (overrides env until cleared).

    Pass ``api_key=None`` or ``base_url=None`` to clear an override and fall
    back to environment variables / built-in default base URL.
    """
    global _override_key, _override_base
    if api_key is not _MISSING:
        if api_key is None:
            _override_key = None
        else:
            _override_key = str(api_key).strip() or None
    if base_url is not _MISSING:
        if base_url is None:
            _override_base = None
        else:
            _override_base = str(base_url).strip().rstrip("/") or None


def _effective_key() -> Optional[str]:
    if _override_key:
        return _override_key
    return (
        (os.environ.get("COGNEXUS_API_KEY") or "").strip()
        or (os.environ.get("MYAPP_API_KEY") or "").strip()
        or None
    )


def _effective_base() -> str:
    if _override_base:
        return _override_base.rstrip("/")
    raw = (os.environ.get("COGNEXUS_API_BASE_URL") or "").strip().rstrip("/")
    if raw:
        return raw
    return "https://cognexuslabs.ai"


def _sdk_user_agent() -> str:
    """Identifiable client for CDN/WAF allowlists (Cloudflare blocks bare urllib)."""
    return f"cognexus-python-sdk/{_package_version()}"


def _api_request_headers(api_key: Optional[str] = None) -> dict[str, str]:
    headers = {
        "Accept": "application/json",
        "User-Agent": _sdk_user_agent(),
    }
    if api_key:
        headers["X-Api-Key"] = api_key
    return headers


def _log_http_error(op: str, event_type: str, exc: urllib.error.HTTPError) -> None:
    body = ""
    try:
        body = exc.read().decode("utf-8", errors="replace")[:240]
    except Exception:
        pass
    if exc.code == 403 and ("1010" in body or "cloudflare" in body.lower()):
        _log.warning(
            "cloud: %s %s failed HTTP 403 (CDN/WAF — use a current cognexus package "
            "or allow User-Agent %r on /api/events)",
            op,
            event_type,
            _sdk_user_agent(),
        )
        return
    if exc.code == 401:
        _log.warning(
            "cloud: %s %s failed HTTP 401 — invalid or revoked API key for %s",
            op,
            event_type,
            _effective_base(),
        )
        return
    _log.warning("cloud: %s %s failed HTTP %s %s", op, event_type, exc.code, body)


def ensure_sdk_session_logged() -> None:
    """Post one ``sdk_session`` row per process when an API key is configured."""
    global _session_logged
    if not has_api_key():
        return
    with _session_lock:
        if _session_logged:
            return
        _session_logged = True
    post_sdk_event(
        "sdk_session",
        source="pypi_sdk",
        level="info",
        title="Python SDK · session started",
        payload={
            "package": "cognexus",
            "version": _package_version(),
            "python": sys.version.split()[0],
            "platform": platform.platform(),
        },
        _skip_session_hook=True,
    )


def post_generation_outcome(
    *,
    outcome: str,
    reason: str,
    model_id: Optional[str] = None,
    request_id: Optional[str] = None,
    tokens_out: Optional[int] = None,
    latency_ms: Optional[float] = None,
    extra: Optional[dict[str, Any]] = None,
) -> None:
    """Log an LLM generation pass or failure to the dashboard (optional helper).

    Call after ``model.generate()`` (or your provider's equivalent) when you want
    generation outcomes visible in **Event Logs** alongside prompt-defense rows.

    Args:
        outcome: ``"passed"`` or ``"failed"`` (other values are stored as-is).
        reason: Human-readable explanation (e.g. blocked by guard, success, timeout).
        model_id: Optional model / deployment label.
        request_id: Correlation id (new UUID hex when omitted).
        tokens_out: Optional completion token count.
        latency_ms: Optional wall time in milliseconds.
        extra: Additional JSON-serialisable fields merged into the payload.
    """
    oc = (outcome or "").strip().lower()
    if oc == "passed":
        level = "success"
        title = "Generation · PASSED"
    elif oc == "failed":
        level = "error"
        title = "Generation · FAILED"
    else:
        level = "info"
        title = f"Generation · {outcome or 'event'}"

    import uuid

    rid = (request_id or uuid.uuid4().hex).lower()
    payload: dict[str, Any] = {
        "outcome": oc or outcome,
        "reason": (reason or "").strip()[:2000],
        "request_id": rid,
        "model_id": model_id,
    }
    if tokens_out is not None:
        payload["tokens_out"] = int(tokens_out)
    if latency_ms is not None:
        payload["latency_ms"] = max(0.0, float(latency_ms))
    if extra:
        payload.update(extra)

    post_sdk_event(
        "generation",
        source="pypi_sdk",
        level=level,
        title=title,
        payload=payload,
    )


def post_sdk_event(
    event_type: str,
    *,
    source: str = "pypi_sdk",
    payload: Optional[dict[str, Any]] = None,
    level: str = "info",
    title: Optional[str] = None,
    timeout_sec: float = 5.0,
    _skip_session_hook: bool = False,
) -> None:
    """POST one row to ``/api/events`` (fire-and-forget thread).

    Never raises to callers. Logs at DEBUG when skipped (no key); WARNING when
    the HTTP round-trip fails after a key was present.

    The first successful post in a process also emits ``sdk_session`` (package
    version and runtime) so the dashboard shows when the SDK was invoked.
    """
    key = _effective_key()
    if not key:
        _log.debug("cloud: skip event %r — no COGNEXUS_API_KEY / MYAPP_API_KEY", event_type)
        return

    if not _skip_session_hook:
        ensure_sdk_session_logged()

    body_obj = {
        "event_type": event_type,
        "source": source,
        "payload": payload or {},
        "level": level,
        "title": title,
    }

    def _run() -> None:
        url = _effective_base() + "/api/events"
        data = json.dumps(body_obj, ensure_ascii=False).encode("utf-8")
        headers = _api_request_headers(key)
        headers["Content-Type"] = "application/json"
        req = urllib.request.Request(url, data=data, method="POST", headers=headers)
        try:
            with urllib.request.urlopen(req, timeout=timeout_sec) as resp:
                if resp.status >= 400:
                    _log.warning(
                        "cloud: event POST %s returned HTTP %s", event_type, resp.status
                    )
        except urllib.error.HTTPError as exc:
            _log_http_error("event POST", event_type, exc)
        except Exception as exc:
            _log.warning("cloud: event POST %s failed: %s", event_type, exc)

    threading.Thread(target=_run, daemon=True).start()


def post_policy_human_decision(
    verdict: str,
    *,
    request_id: str = "",
    surface: str = "pypi_sdk_review",
    notes: str = "",
    timeout_sec: float = 5.0,
) -> None:
    """POST a human **approved** / **denied** follow-up to ``/api/policy-decisions``.

    Uses the same API key and base URL as :func:`post_sdk_event`. Fire-and-forget;
    never raises.
    """
    key = _effective_key()
    if not key:
        _log.debug("cloud: skip policy decision %r — no COGNEXUS_API_KEY / MYAPP_API_KEY", verdict)
        return
    v = (verdict or "").strip().lower()
    if v not in ("approved", "denied"):
        _log.warning("cloud: policy decision verdict must be approved|denied, got %r", verdict)
        return

    body_obj = {
        "verdict": v,
        "request_id": (request_id or "").strip()[:64],
        "surface": (surface or "pypi_sdk_review").strip()[:200] or "pypi_sdk_review",
        "notes": (notes or "").strip()[:2000],
    }

    def _run() -> None:
        url = _effective_base() + "/api/policy-decisions"
        data = json.dumps(body_obj, ensure_ascii=False).encode("utf-8")
        headers = _api_request_headers(key)
        headers["Content-Type"] = "application/json"
        req = urllib.request.Request(url, data=data, method="POST", headers=headers)
        try:
            with urllib.request.urlopen(req, timeout=timeout_sec) as resp:
                if resp.status >= 400:
                    _log.warning(
                        "cloud: policy decision POST returned HTTP %s", resp.status
                    )
        except urllib.error.HTTPError as exc:
            _log_http_error("policy decision POST", verdict, exc)
        except Exception as exc:
            _log.warning("cloud: policy decision POST failed: %s", exc)

    threading.Thread(target=_run, daemon=True).start()


def fetch_client_policy_rules(
    *,
    timeout_sec: float = 12.0,
) -> list[dict[str, Any]]:
    """Download tenant policy rules from ``GET /api/policy-enforcement/rules``.

    Requires ``COGNEXUS_API_KEY`` (or :func:`configure`). Returns an empty list
    when no key is configured or the request fails.
    """
    key = _effective_key()
    if not key:
        _log.debug("cloud: skip policy rules fetch — no API key")
        return []
    url = _effective_base() + "/api/policy-enforcement/rules"
    req = urllib.request.Request(
        url,
        method="GET",
        headers=_api_request_headers(key),
    )
    try:
        with urllib.request.urlopen(req, timeout=timeout_sec) as resp:
            body = resp.read().decode("utf-8")
        data = json.loads(body)
        rules = data.get("rules") if isinstance(data, dict) else None
        return list(rules) if isinstance(rules, list) else []
    except urllib.error.HTTPError as exc:
        _log_http_error("policy rules GET", "policy-enforcement", exc)
        return []
    except Exception as exc:
        _log.warning("cloud: policy rules fetch failed: %s", exc)
        return []


__all__ = [
    "configure",
    "ensure_sdk_session_logged",
    "fetch_client_policy_rules",
    "has_api_key",
    "post_generation_outcome",
    "post_sdk_event",
    "post_policy_human_decision",
]
