"""cleanvibe - scaffold AI-assisted coding projects and launch Claude Code."""

__version__ = "1.10.0"
