# Contributing to HEAP

Thanks for your interest! HEAP is intentionally small in v0.1 (~5k LOC of
source); contributions that keep that property are easier to land.

## Development setup

```bash
git clone https://github.com/vicente-r-junior/heap-ai.git
cd heap-ai
make install                 # creates .venv, installs editable + dev/test deps
cp .env.example .env         # add ANTHROPIC_API_KEY (other providers optional)
make test                    # 331 tests should pass
```

## Daily workflow

```bash
make test         # pytest, full suite (~3s)
make lint         # ruff check + format --check
make format       # ruff format (apply)
make example      # examples/hello_gateway.py — sanity-check live API
.venv/bin/heap --help
```

## Project layout

```
heap/             # the package
  gateway.py        # L1 — LiteLLM wrapper, role routing, cost/budget
  agent.py          # L4 — Agent class, PEV loop
  hooks.py          # Block / Warn / Retry / Continue
  tool.py           # @tool decorator + Pydantic schema gen
  spec/             # interactive interrogator + structurer + validator
  scenarios.py      # generation, gap detection, spec amendments
  plan.py           # Plan models, §10 renderer, heuristics, amendments
  run.py            # state machine, persistence, §9.3 retry
  status.py         # §11.1 formatter
  watch.py          # trace.jsonl tail
  cli.py            # `heap` console script
tests/            # mirrors heap/, deterministic, mocked Gateway
examples/         # three runnable examples (see examples/README.md)
specs/            # runtime spec/scenarios/plan artifacts (gitignored)
.heap/runs/       # persisted run state (gitignored)
```

## Code style

- **Python 3.11+.** Type hints everywhere they aid clarity.
- **Linter/formatter:** [ruff](https://docs.astral.sh/ruff/).
  Configured in `pyproject.toml`. CI requires both `check` and
  `format --check` clean.
- **Imports:** one per line, sorted by ruff's isort rules.
- **No unjustified abstractions.** Three similar lines beats a premature
  helper.
- **Comments only when WHY is non-obvious.** Don't restate WHAT — well-named
  identifiers already do that. Don't reference current task / fix / callers
  ("used by X", "added for the Y flow") — that belongs in commit messages.

## Testing patterns

HEAP modules that call models follow a consistent test pattern: the
`Gateway` is constructed with stub model names, then `gateway.call` is
patched to return a canned `GatewayResponse`. This keeps tests offline,
deterministic, and free.

```python
from unittest.mock import patch
from heap.gateway import Gateway, GatewayResponse

def _gw_resp(payload: dict) -> GatewayResponse:
    return GatewayResponse(
        content=json.dumps(payload),
        model_used="t/p",
        tokens_in=100, tokens_out=50,
        cost_usd=0.001, latency_ms=200.0,
    )

def test_my_thing():
    gw = Gateway(planner="t/p", worker="t/w", fast="t/f")
    with patch.object(gw, "call", return_value=_gw_resp({"ok": True})):
        ...
```

CLI tests use Click's `CliRunner`; engine tests use a stub `execute_phase`
callback. See `tests/test_scenarios.py` and `tests/test_run.py` for canonical
examples.

## Commit style

- [Conventional Commits](https://www.conventionalcommits.org/):
  `feat:`, `fix:`, `chore:`, `docs:`, `test:`, `refactor:`.
- One commit per logical change. Squash on merge if multiple WIP commits
  ended up in a PR.
- Reference issues in the body, not the title (titles stay short).

## Pull requests

- Open against `main`.
- Link the related issue (or open one first for non-trivial work).
- CI must pass before review.
- Description: 2-line summary + a checklist of what changed.
- Don't `--force-push` to a shared branch unless you've coordinated with
  reviewers. The repo's pre-push hook blocks force-pushes by default.

## Spec-driven mindset

HEAP is built using HEAP's own pattern. New features start with a spec,
not code. If you're proposing something non-trivial:

1. Open a discussion describing **the user-visible behavior** (what
   changes for the operator running `heap ...`).
2. List the **acceptance criteria** (how we know it's done — what tests
   would prove it).
3. Note **risks and out-of-scope items**.

Implementation discussion follows acceptance, not the other way around.
For experimental work, you can run `heap spec new --mode feature` against
your own checkout and attach the resulting `specs/<name>.spec.md` to the
discussion.

## What v0.1 is NOT

To keep v0.1 shippable, several things are explicitly **out of scope**.
Please open issues *to discuss* before contributing in these areas:

- L2 sandbox / policy engine
- L5 multi-agent orchestration
- Headless / maintenance / multi-user
- Knowledge connectors (Notion, Linear, Confluence, etc.)
- Web dashboard
- Auto-graduation of memory tiers
- Drift detection in CI

These are flagged for v0.2+; contributions land more easily once v0.1 is
out and the API surface stabilizes.

## Troubleshooting

- **`make install` fails on Apple Silicon Python 3.13 builds:** the project
  pins Python 3.11+; pyenv-installed 3.11 or 3.12 is the smoothest path.
- **`heap spec new` says "API key not set":** the CLI loads `.env` from the
  current directory. Run from the repo root, or `export ANTHROPIC_API_KEY=...`.
- **Tests pass locally but fail in CI:** check that `specs/` and
  `.heap/runs/` are gitignored; lingering state from a manual run can
  influence relative-path tests.

## License

By contributing you agree to license your work under the project's
[MIT License](LICENSE).
