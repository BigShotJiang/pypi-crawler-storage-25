"""Tests for heap.tool — @tool decorator + Pydantic schema generation."""

from __future__ import annotations

import pytest
from pydantic import ValidationError

from heap import ToolMeta, get_meta, tool

# ---------------------------------------------------------------------------
# decorator forms
# ---------------------------------------------------------------------------


def test_bare_decorator_no_args() -> None:
    @tool
    def add(x: int, y: int) -> int:
        """Add two integers."""
        return x + y

    meta = get_meta(add)
    assert isinstance(meta, ToolMeta)
    assert meta.name == "add"
    assert meta.description == "Add two integers."
    assert meta.requires_approval is False
    assert meta.side_effects == []


def test_parameterized_decorator() -> None:
    @tool(
        requires_approval=True,
        side_effects=["filesystem"],
        rate_limit=5,
        description="Override description.",
    )
    def write_file(path: str, content: str) -> str:
        """The docstring is ignored when description= is provided."""
        return path

    meta = get_meta(write_file)
    assert meta.requires_approval is True
    assert meta.side_effects == ["filesystem"]
    assert meta.rate_limit == 5
    assert meta.description == "Override description."


def test_explicit_name_overrides_function_name() -> None:
    @tool(name="renamed")
    def original(x: int) -> int:
        """doc."""
        return x

    assert get_meta(original).name == "renamed"


def test_undecorated_function_raises() -> None:
    def plain(x: int) -> int:
        return x

    with pytest.raises(TypeError, match="not a @tool"):
        get_meta(plain)


# ---------------------------------------------------------------------------
# schema generation
# ---------------------------------------------------------------------------


def test_schema_for_primitive_args() -> None:
    @tool
    def f(s: str, n: int, x: float, b: bool) -> str:
        """f."""
        return s

    schema = get_meta(f).schema
    assert schema["type"] == "object"
    props = schema["properties"]
    assert props["s"]["type"] == "string"
    assert props["n"]["type"] == "integer"
    assert props["x"]["type"] == "number"
    assert props["b"]["type"] == "boolean"
    assert set(schema["required"]) == {"s", "n", "x", "b"}


def test_schema_with_defaults_marks_optional() -> None:
    @tool
    def f(required: str, optional: int = 7) -> str:
        """f."""
        return required

    schema = get_meta(f).schema
    assert schema["required"] == ["required"]
    assert schema["properties"]["optional"]["default"] == 7


def test_schema_for_optional_type() -> None:
    @tool
    def f(maybe: str | None = None) -> str:
        """f."""
        return maybe or ""

    schema = get_meta(f).schema
    # Optional[str] generates anyOf[string, null] in pydantic v2
    prop = schema["properties"]["maybe"]
    assert "anyOf" in prop or "type" in prop


def test_schema_for_list_arg() -> None:
    @tool
    def f(items: list[str]) -> int:
        """f."""
        return len(items)

    schema = get_meta(f).schema
    prop = schema["properties"]["items"]
    assert prop["type"] == "array"
    assert prop["items"]["type"] == "string"


def test_to_openai_tool_format() -> None:
    @tool
    def get_weather(city: str) -> str:
        """Return the weather for a city."""
        return f"sunny in {city}"

    payload = get_meta(get_weather).to_openai_tool()
    assert payload["type"] == "function"
    assert payload["function"]["name"] == "get_weather"
    assert payload["function"]["description"] == "Return the weather for a city."
    assert "parameters" in payload["function"]
    assert payload["function"]["parameters"]["properties"]["city"]["type"] == "string"


# ---------------------------------------------------------------------------
# .call() dispatch + validation
# ---------------------------------------------------------------------------


def test_call_dispatches_with_validated_args() -> None:
    @tool
    def add(x: int, y: int) -> int:
        """Add."""
        return x + y

    assert get_meta(add).call(x=2, y=3) == 5


def test_call_raises_validation_error_on_bad_types() -> None:
    @tool
    def add(x: int, y: int) -> int:
        """Add."""
        return x + y

    with pytest.raises(ValidationError):
        get_meta(add).call(x="not a number", y=3)


def test_call_uses_default_when_omitted() -> None:
    @tool
    def greet(name: str, salutation: str = "Hello") -> str:
        """g."""
        return f"{salutation}, {name}!"

    assert get_meta(greet).call(name="V") == "Hello, V!"
    assert get_meta(greet).call(name="V", salutation="Hi") == "Hi, V!"


def test_no_docstring_falls_back_to_function_name() -> None:
    @tool
    def silent(x: int) -> int:  # noqa: D103
        return x

    assert get_meta(silent).description == "silent"


def test_decorated_function_still_callable_directly() -> None:
    """The decorator must not replace the function — direct invocation works."""

    @tool
    def double(x: int) -> int:
        """d."""
        return x * 2

    assert double(5) == 10
