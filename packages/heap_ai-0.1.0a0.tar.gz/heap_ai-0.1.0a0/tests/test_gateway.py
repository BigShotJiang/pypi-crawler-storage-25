"""Tests for heap.gateway — mocked LiteLLM, no real API calls."""

from __future__ import annotations

from types import SimpleNamespace
from unittest.mock import patch

import pytest

from heap import BudgetExceeded, Gateway, GatewayResponse


def _fake_response(
    content: str = "hello",
    tokens_in: int = 10,
    tokens_out: int = 5,
    tool_calls: list | None = None,
):
    """Build an OpenAI-shaped response object suitable for the gateway."""
    msg = SimpleNamespace(content=content, tool_calls=tool_calls)
    choice = SimpleNamespace(message=msg)
    return SimpleNamespace(
        choices=[choice],
        usage=SimpleNamespace(
            prompt_tokens=tokens_in,
            completion_tokens=tokens_out,
        ),
    )


@pytest.fixture
def gw() -> Gateway:
    return Gateway(
        planner="test/planner",
        worker="test/worker",
        fast="test/fast",
        fallback=["test/fb1", "test/fb2"],
        budget_usd=1.00,
    )


def test_construction_initial_state(gw: Gateway) -> None:
    assert gw.models == {
        "planner": "test/planner",
        "worker": "test/worker",
        "fast": "test/fast",
    }
    assert gw.fallback == ["test/fb1", "test/fb2"]
    assert gw.spent_usd == 0.0
    assert gw.tokens_in == 0
    assert gw.tokens_out == 0
    assert gw.calls_made == 0


def test_call_routes_to_role_and_normalizes(gw: Gateway) -> None:
    with (
        patch("heap.gateway.litellm.completion") as mock_call,
        patch("heap.gateway.litellm.completion_cost", return_value=0.0042),
    ):
        mock_call.return_value = _fake_response("planner says hi", 20, 8)
        result = gw.call(role="planner", messages=[{"role": "user", "content": "hi"}])

    assert isinstance(result, GatewayResponse)
    assert result.content == "planner says hi"
    assert result.model_used == "test/planner"
    assert result.tokens_in == 20
    assert result.tokens_out == 8
    assert result.cost_usd == pytest.approx(0.0042)
    assert result.used_fallback is False
    assert result.fallback_chain_index is None
    # Cumulative tallies updated
    assert gw.spent_usd == pytest.approx(0.0042)
    assert gw.tokens_in == 20
    assert gw.tokens_out == 8
    assert gw.calls_made == 1
    # And the right model was passed
    assert mock_call.call_args.kwargs["model"] == "test/planner"


def test_fallback_on_primary_failure(gw: Gateway) -> None:
    with (
        patch("heap.gateway.litellm.completion") as mock_call,
        patch("heap.gateway.litellm.completion_cost", return_value=0.001),
    ):
        mock_call.side_effect = [
            Exception("primary down"),
            _fake_response("fallback hello", 12, 4),
        ]
        result = gw.call(role="planner", messages=[{"role": "user", "content": "hi"}])

    assert result.content == "fallback hello"
    assert result.used_fallback is True
    assert result.fallback_chain_index == 1
    assert result.model_used == "test/fb1"


def test_walks_full_chain_then_raises(gw: Gateway) -> None:
    with (
        patch("heap.gateway.litellm.completion", side_effect=Exception("everything down")),
        pytest.raises(RuntimeError, match="All models failed"),
    ):
        gw.call(role="fast", messages=[])


def test_unknown_role_raises_value_error(gw: Gateway) -> None:
    with pytest.raises(ValueError, match="Unknown role"):
        gw.call(role="bogus", messages=[])  # type: ignore[arg-type]


def test_budget_exceeded_blocks_before_call(gw: Gateway) -> None:
    gw.spent_usd = 1.50  # already past the $1 budget
    with patch("heap.gateway.litellm.completion") as mock_call:
        with pytest.raises(BudgetExceeded):
            gw.call(role="worker", messages=[{"role": "user", "content": "hi"}])
        mock_call.assert_not_called()


def test_no_budget_allows_unbounded_calls() -> None:
    gw = Gateway(planner="p", worker="w", fast="f", budget_usd=None)
    gw.spent_usd = 99999.0  # huge, but no cap
    with (
        patch("heap.gateway.litellm.completion", return_value=_fake_response()),
        patch("heap.gateway.litellm.completion_cost", return_value=0.001),
    ):
        result = gw.call(role="planner", messages=[])
    assert result.content == "hello"


def test_reset_clears_tallies(gw: Gateway) -> None:
    gw.spent_usd = 5.0
    gw.tokens_in = 100
    gw.tokens_out = 50
    gw.calls_made = 3
    gw.reset()
    assert gw.spent_usd == 0.0
    assert gw.tokens_in == 0
    assert gw.tokens_out == 0
    assert gw.calls_made == 0


def test_cost_lookup_failure_doesnt_break_response(gw: Gateway) -> None:
    """If litellm.completion_cost raises (e.g. unknown model), cost falls back to 0.0."""
    with (
        patch("heap.gateway.litellm.completion", return_value=_fake_response("ok", 5, 2)),
        patch("heap.gateway.litellm.completion_cost", side_effect=Exception("no pricing")),
    ):
        result = gw.call(role="planner", messages=[])
    assert result.content == "ok"
    assert result.cost_usd == 0.0
    assert result.tokens_in == 5
    assert result.tokens_out == 2


def test_streaming_returns_iterator(gw: Gateway) -> None:
    """stream=True passes through the LiteLLM iterator unchanged.

    Tallies are NOT updated for streamed calls in v0.1 — that's a documented limit.
    """
    fake_iter = iter([{"chunk": 1}, {"chunk": 2}])
    with patch("heap.gateway.litellm.completion", return_value=fake_iter) as mock_call:
        result = gw.call(role="worker", messages=[], stream=True)
    assert result is fake_iter
    assert mock_call.call_args.kwargs["stream"] is True
    assert gw.calls_made == 0
    assert gw.spent_usd == 0.0


def test_tool_calls_normalized_from_pydantic_objects(gw: Gateway) -> None:
    """If LiteLLM returns Pydantic-shaped tool calls, they're converted to dicts."""

    class _ToolCall:
        def __init__(self) -> None:
            self.id = "tc_1"
            self.type = "function"

        def model_dump(self) -> dict:
            return {"id": self.id, "type": self.type, "function": {"name": "noop"}}

    with (
        patch(
            "heap.gateway.litellm.completion",
            return_value=_fake_response(content=None, tool_calls=[_ToolCall()]),
        ),
        patch("heap.gateway.litellm.completion_cost", return_value=0.0),
    ):
        result = gw.call(role="fast", messages=[])

    assert result.content is None
    assert result.tool_calls == [{"id": "tc_1", "type": "function", "function": {"name": "noop"}}]
