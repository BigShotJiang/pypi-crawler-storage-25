"""S7 smoke test — drive the full HEAP loop on a real bug end-to-end.

The deterministic counterpart to ``examples/csv-bom/README.md``. Copies
the buggy package into ``tmp_path``, walks Spec → Scenarios → Plan → Run
through real HEAP modules, and confirms an executor that applies the
fix turns the failing tests green.

Everything is offline: planner calls are mocked at the Gateway boundary
so this exercises orchestration, persistence, and the §9.3 retry policy
without API spend.
"""

from __future__ import annotations

import shutil
import subprocess
import sys
from pathlib import Path

import pytest

from heap.plan import (
    Phase,
    Plan,
    Sprint,
    apply_heuristics,
    approve_plan,
    write_plan,
)
from heap.run import (
    PhaseResult,
    RunContext,
    RunEngine,
    load_state,
)
from heap.scenarios import Scenario, ScenarioSet
from heap.scenarios import write_yaml as write_scenarios
from heap.spec import InterrogatorOutcome, Structurer

EXAMPLE_DIR = Path(__file__).parent.parent / "examples" / "csv-bom"


# ---------------------------------------------------------------------------
# helpers
# ---------------------------------------------------------------------------


def _isolated_example(tmp_path: Path) -> Path:
    """Copy examples/csv-bom into tmp_path/example so we can mutate it."""
    target = tmp_path / "example"
    shutil.copytree(EXAMPLE_DIR, target)
    return target


def _run_pytest_in(target: Path) -> tuple[int, str]:
    proc = subprocess.run(
        [sys.executable, "-m", "pytest", "tests/", "-q", "--no-header"],
        cwd=target,
        capture_output=True,
        text=True,
    )
    return proc.returncode, proc.stdout + proc.stderr


def _seed_spec(specs_dir: Path) -> tuple[Structurer, object]:
    structurer = Structurer(specs_dir=specs_dir)
    outcome = InterrogatorOutcome(
        mode="bug",
        audience="developer",
        facts={
            "symptom": "BOM-prefixed CSV imports lose access to the first column",
            "expected": "All rows accessible by their canonical column names regardless of BOM",
        },
        transcript=[],
        finalized_at="2026-04-27T11:30:00Z",
        turns_used=0,
        incomplete=False,
    )
    spec = structurer.write(outcome, name="csv-bom")
    return structurer, spec


def _seed_scenarios(specs_dir: Path):
    scen = ScenarioSet(
        spec_name="csv-bom",
        spec_version=1,
        scenarios=[
            Scenario(
                id="T1",
                title="All rows imported from BOM file",
                given=["a CSV with 3 rows and a UTF-8 BOM"],
                when=["import_rows runs"],
                then=["all 3 rows are returned"],
                acceptance_ref=0,
                source="spec",
            ),
            Scenario(
                id="T2",
                title="No BOM in header keys",
                given=["a CSV with a UTF-8 BOM"],
                when=["import_rows runs"],
                then=["no header contains the BOM character"],
                acceptance_ref=1,
                source="spec",
            ),
        ],
        approved_at="2026-04-27T11:31:00Z",
    )
    write_scenarios(scen, specs_dir / "csv-bom.scenarios.yaml")


def _seed_plan(specs_dir: Path) -> Plan:
    plan = Plan(
        plan_id="csv-bom-smoke-1",
        spec_name="csv-bom",
        spec_version=1,
        spec_ref="csv-bom v1",
        sprints=[
            Sprint(
                id="S1",
                name="Reproduce",
                goal="lock the bug into a failing test",
                gate="failing test exists",
                phases=[
                    Phase(
                        id="S1.P1",
                        name="Verify bug",
                        agent="worker/Sonnet",
                        deliverables=["bug reproduction"],
                        tests=["BOM file fails import"],
                        gate="bug observed",
                    ),
                ],
            ),
            Sprint(
                id="S2",
                name="Fix",
                goal="encoding='utf-8-sig'",
                gate="all green",
                phases=[
                    Phase(
                        id="S2.P1",
                        name="Apply fix",
                        agent="worker/Sonnet",
                        deliverables=["csv_importer.py with utf-8-sig"],
                        tests=["All importer tests pass"],
                        gate="pytest passes",
                    ),
                ],
            ),
        ],
        scope_in=["Fix UTF-8 BOM handling in csv_importer.py"],
        scope_out=["Refactor importer; non-CSV file types"],
    )
    plan = apply_heuristics(plan)
    plan = approve_plan(plan, approver="smoke-test")
    write_plan(plan, specs_dir / "csv-bom.plan.yaml")
    return plan


# ---------------------------------------------------------------------------
# the smoke
# ---------------------------------------------------------------------------


def test_s7_smoke_drives_full_loop_against_real_bug(tmp_path):
    """End-to-end: bug exists → HEAP loop → executor fixes → bug gone."""

    # ------------------------------------------------------------------
    # 0. The example exists and the bug is real.
    # ------------------------------------------------------------------
    example = _isolated_example(tmp_path)
    rc, out = _run_pytest_in(example)
    assert rc != 0, "BOM bug should make tests fail before the fix"
    assert "BOM leaked" in out

    # ------------------------------------------------------------------
    # 1-3. Spec, scenarios, plan — all seeded directly (no API calls).
    # ------------------------------------------------------------------
    specs = tmp_path / "specs"
    _seed_spec(specs)
    _seed_scenarios(specs)
    plan = _seed_plan(specs)

    # ------------------------------------------------------------------
    # 4. Run engine with an executor that applies the real fix on S2.P1.
    # ------------------------------------------------------------------
    importer_path = example / "csv_importer.py"
    fix_applied: list[bool] = []

    def smoke_executor(ctx: RunContext) -> PhaseResult:
        if ctx.phase.id == "S1.P1":
            # "Verify bug": re-run the example's tests; they should fail.
            rc, _ = _run_pytest_in(example)
            return PhaseResult(
                passed=(rc != 0),
                detail="confirmed BOM bug" if rc != 0 else "tests unexpectedly green",
                cost_usd=0.0,
            )
        if ctx.phase.id == "S2.P1":
            # "Apply fix": rewrite importer to use utf-8-sig.
            text = importer_path.read_text(encoding="utf-8")
            patched = text.replace('encoding="utf-8"', 'encoding="utf-8-sig"')
            assert patched != text, "fix should have changed the file"
            importer_path.write_text(patched, encoding="utf-8")
            fix_applied.append(True)
            rc, out = _run_pytest_in(example)
            return PhaseResult(
                passed=(rc == 0),
                detail=f"pytest rc={rc}",
                cost_usd=0.0,
            )
        return PhaseResult(passed=False, detail="unexpected phase")

    runs_root = tmp_path / "runs"
    engine = RunEngine(
        plan,
        execute_phase=smoke_executor,
        run_dir=runs_root / "smoke-1",
        plan_ref=str(specs / "csv-bom.plan.yaml"),
    )
    engine.state.run_id = "smoke-1"

    # Walk: S1 → gate → S2 → gate → complete.
    state = engine.run()
    assert state.run_status == "awaiting_gate"
    assert state.awaiting_gate == "S1"

    engine.approve_gate(approver="smoke-test")
    state = engine.run()
    assert state.run_status == "awaiting_gate"
    assert state.awaiting_gate == "S2"
    assert fix_applied == [True]

    engine.approve_gate(approver="smoke-test")
    state = engine.run()
    assert state.run_status == "complete"
    assert state.completed_sprints == ["S1", "S2"]
    assert state.completed_phases == ["S1.P1", "S2.P1"]

    # ------------------------------------------------------------------
    # 5. Bug is gone.
    # ------------------------------------------------------------------
    rc, out = _run_pytest_in(example)
    assert rc == 0, f"tests should pass after the fix; got:\n{out}"

    # ------------------------------------------------------------------
    # 6. Persistence captured the full trace.
    # ------------------------------------------------------------------
    on_disk = load_state("smoke-1", base=runs_root)
    assert on_disk is not None
    assert on_disk.run_status == "complete"
    assert on_disk.completed_sprints == ["S1", "S2"]


def test_csv_bom_example_directory_layout():
    """Sanity: the example exists and contains the expected files."""
    assert EXAMPLE_DIR.is_dir()
    assert (EXAMPLE_DIR / "csv_importer.py").exists()
    assert (EXAMPLE_DIR / "tests" / "test_csv_importer.py").exists()
    assert (EXAMPLE_DIR / "tests" / "fixtures" / "with_bom.csv").exists()
    assert (EXAMPLE_DIR / "tests" / "fixtures" / "plain.csv").exists()
    # BOM is real
    head = (EXAMPLE_DIR / "tests" / "fixtures" / "with_bom.csv").read_bytes()[:3]
    assert head == b"\xef\xbb\xbf", "fixture should start with UTF-8 BOM"


def test_csv_bom_example_currently_buggy(tmp_path):
    """Guard test: the shipped example must demonstrate the bug.

    If this passes, the example was accidentally fixed and the smoke
    walkthrough loses its punch. Run the smoke test fixture in tmp_path
    to keep the source unmodified.
    """
    target = _isolated_example(tmp_path)
    rc, out = _run_pytest_in(target)
    assert rc != 0, "shipped example should be buggy until HEAP fixes it"
    assert "BOM leaked" in out or "BOM" in out


@pytest.mark.parametrize("fixture_name", ["with_bom.csv", "plain.csv"])
def test_csv_fixtures_have_expected_rows(fixture_name, tmp_path):
    """The fixtures themselves are well-formed CSVs with 3 data rows."""
    target = _isolated_example(tmp_path)
    fpath = target / "tests" / "fixtures" / fixture_name
    text = fpath.read_text(encoding="utf-8-sig")  # tolerant read for verification
    lines = [line for line in text.splitlines() if line.strip()]
    assert len(lines) == 4  # 1 header + 3 rows
    assert lines[0].endswith("role")
