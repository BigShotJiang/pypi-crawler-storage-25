"""Tests for heap.plan — mocked Gateway, deterministic, offline."""

from __future__ import annotations

import json
from unittest.mock import patch

import pytest
from pydantic import ValidationError

from heap.gateway import Gateway, GatewayResponse
from heap.plan import (
    Phase,
    Plan,
    PlanGenerator,
    RiskItem,
    Sprint,
    generate,
    read_plan,
    write_plan,
)
from heap.scenarios import Scenario, ScenarioSet
from heap.spec.structurer import StructuredSpec

# ---------------------------------------------------------------------------
# helpers
# ---------------------------------------------------------------------------


def _gw_resp(payload, cost=0.0042):
    content = payload if isinstance(payload, str) else json.dumps(payload)
    return GatewayResponse(
        content=content,
        model_used="t/p",
        tokens_in=400,
        tokens_out=600,
        cost_usd=cost,
        latency_ms=900.0,
    )


def _gw() -> Gateway:
    return Gateway(planner="t/p", worker="t/w", fast="t/f")


def _spec(*, name="csv-bom", version=1) -> StructuredSpec:
    return StructuredSpec(
        name=name,
        version=version,
        mode="bug",
        audience="developer",
        facts={"symptom": "zero rows", "expected": "all rows imported"},
        acceptance=[
            "After fix: all rows imported",
            "After fix: no warnings on UTF-8 BOM files",
        ],
        created_at="2026-04-26T18:00:00Z",
    )


def _payload():
    return {
        "sprints": [
            {
                "id": "S1",
                "name": "Foundation",
                "goal": "Stand up the harness",
                "gate": "Tests pass; CLI launches",
                "phases": [
                    {
                        "id": "S1.P1",
                        "name": "Skeleton",
                        "agent": "worker/Sonnet",
                        "deliverables": ["pyproject.toml", "package layout"],
                        "tests": ["import works"],
                        "gate": "make install succeeds",
                    },
                    {
                        "id": "S1.P2",
                        "name": "Gateway",
                        "agent": "worker/Sonnet",
                        "deliverables": ["heap/gateway.py"],
                        "tests": ["Anthropic call returns content + cost"],
                        "gate": "live API call works",
                    },
                ],
            },
            {
                "id": "S2",
                "name": "Fix BOM",
                "goal": "Importer handles UTF-8 BOM",
                "gate": "all scenarios pass",
                "phases": [
                    {
                        "id": "S2.P1",
                        "name": "Repro",
                        "agent": "worker/Sonnet",
                        "deliverables": ["failing test"],
                        "tests": ["test reproduces zero-row outcome"],
                        "gate": "test fails with expected diff",
                    },
                    {
                        "id": "S2.P2",
                        "name": "Fix",
                        "agent": "worker/Sonnet",
                        "deliverables": ["minimal patch"],
                        "tests": ["test passes; existing tests still pass"],
                        "gate": "all green",
                    },
                ],
            },
        ],
        "risk_register": [
            {
                "description": "Encoding detection unreliable on Windows",
                "severity": "medium",
                "mitigation": "Pin to utf-8-sig where possible",
            },
            {
                "description": "Existing callers depend on header alias",
                "severity": "high",
                "mitigation": "Add regression test before patch",
            },
        ],
        "scope_in": ["Fix BOM column-matching", "Add regression test"],
        "scope_out": ["Refactor importer", "Support BOM-mid-file"],
    }


# ---------------------------------------------------------------------------
# model validation
# ---------------------------------------------------------------------------


def test_phase_defaults():
    p = Phase(id="S1.P1", name="Skeleton")
    assert p.agent == "worker/Sonnet"
    assert p.deliverables == []
    assert p.cost_estimate_usd == 0.0


def test_sprint_with_phases():
    s = Sprint(
        id="S1",
        name="Foundation",
        phases=[Phase(id="S1.P1", name="Skeleton")],
    )
    assert len(s.phases) == 1


def test_riskitem_invalid_severity_rejected():
    with pytest.raises(ValidationError):
        RiskItem(description="x", severity="extreme")  # type: ignore[arg-type]


def test_plan_minimal_fields():
    p = Plan(plan_id="x", spec_name="x", spec_version=1, spec_ref="x v1")
    assert p.sprints == []
    assert p.approved_at is None


# ---------------------------------------------------------------------------
# generate — happy path
# ---------------------------------------------------------------------------


def test_generate_returns_plan_from_planner_json():
    gw = _gw()
    payload = _payload()

    with patch.object(gw, "call", return_value=_gw_resp(payload)) as mock:
        plan = PlanGenerator(gw).generate(_spec())

    assert isinstance(plan, Plan)
    assert plan.spec_name == "csv-bom"
    assert plan.spec_version == 1
    assert plan.spec_ref == "csv-bom v1"
    assert len(plan.sprints) == 2
    assert plan.sprints[0].id == "S1"
    assert plan.sprints[0].name == "Foundation"
    assert len(plan.sprints[0].phases) == 2
    assert plan.sprints[0].phases[0].agent == "worker/Sonnet"
    assert len(plan.risk_register) == 2
    assert plan.risk_register[1].severity == "high"
    assert plan.scope_in == ["Fix BOM column-matching", "Add regression test"]
    assert plan.scope_out == ["Refactor importer", "Support BOM-mid-file"]
    # human_approval_gates auto-populated
    assert plan.human_approval_gates == ["after_plan_review", "after_S1", "after_S2"]
    # plan_id format
    assert plan.plan_id.startswith("csv-bom-v1-")
    assert len(plan.plan_id.split("-")) >= 3
    # planner role
    assert mock.call_args.kwargs["role"] == "planner"


def test_generate_convenience_function():
    gw = _gw()
    with patch.object(gw, "call", return_value=_gw_resp(_payload())):
        plan = generate(_spec(), gw)

    assert isinstance(plan, Plan)
    assert plan.spec_name == "csv-bom"


def test_generate_passes_scenarios_into_prompt_when_provided():
    gw = _gw()
    scenarios = ScenarioSet(
        spec_name="csv-bom",
        spec_version=1,
        scenarios=[
            Scenario(id="T1", title="rows imported", acceptance_ref=0, source="spec"),
            Scenario(id="G2", title="empty file", source="gap", note="spec silent"),
        ],
    )

    with patch.object(gw, "call", return_value=_gw_resp(_payload())) as mock:
        PlanGenerator(gw).generate(_spec(), scenarios)

    user_msg = mock.call_args.kwargs["messages"][1]["content"]
    assert "T1 rows imported" in user_msg
    assert "G2 empty file" in user_msg


def test_generate_handles_missing_scenarios():
    gw = _gw()
    with patch.object(gw, "call", return_value=_gw_resp(_payload())) as mock:
        PlanGenerator(gw).generate(_spec(), None)

    user_msg = mock.call_args.kwargs["messages"][1]["content"]
    assert "(none provided)" in user_msg


# ---------------------------------------------------------------------------
# generate — parsing edge cases
# ---------------------------------------------------------------------------


def test_generate_handles_markdown_fenced_json():
    gw = _gw()
    fenced = "```json\n" + json.dumps(_payload()) + "\n```"

    with patch.object(gw, "call", return_value=_gw_resp(fenced)):
        plan = PlanGenerator(gw).generate(_spec())

    assert len(plan.sprints) == 2


def test_generate_unparseable_response_returns_empty_plan():
    gw = _gw()
    with patch.object(gw, "call", return_value=_gw_resp("not json")):
        plan = PlanGenerator(gw).generate(_spec())

    assert plan.sprints == []
    assert plan.risk_register == []
    assert plan.spec_name == "csv-bom"
    assert plan.human_approval_gates == ["after_plan_review"]  # no sprints to suffix


def test_generate_drops_sprint_without_id_or_name():
    gw = _gw()
    payload = {
        "sprints": [
            {"name": "no-id"},  # drop
            {"id": "S1"},  # drop (no name)
            {"id": "S2", "name": "valid", "phases": []},
        ]
    }
    with patch.object(gw, "call", return_value=_gw_resp(payload)):
        plan = PlanGenerator(gw).generate(_spec())

    assert len(plan.sprints) == 1
    assert plan.sprints[0].id == "S2"


def test_generate_drops_phase_without_id_or_name():
    gw = _gw()
    payload = {
        "sprints": [
            {
                "id": "S1",
                "name": "x",
                "phases": [
                    {"name": "no-id"},  # drop
                    {"id": "S1.P1"},  # drop (no name)
                    {"id": "S1.P2", "name": "valid"},
                ],
            }
        ]
    }
    with patch.object(gw, "call", return_value=_gw_resp(payload)):
        plan = PlanGenerator(gw).generate(_spec())

    assert len(plan.sprints[0].phases) == 1
    assert plan.sprints[0].phases[0].id == "S1.P2"


def test_generate_unknown_severity_coerced_to_medium():
    gw = _gw()
    payload = {
        "sprints": [],
        "risk_register": [
            {"description": "A", "severity": "critical"},
            {"description": "B", "severity": "low"},
        ],
    }
    with patch.object(gw, "call", return_value=_gw_resp(payload)):
        plan = PlanGenerator(gw).generate(_spec())

    assert plan.risk_register[0].severity == "medium"
    assert plan.risk_register[1].severity == "low"


def test_generate_drops_risk_without_description():
    gw = _gw()
    payload = {"sprints": [], "risk_register": [{"severity": "high"}, {"description": "real"}]}
    with patch.object(gw, "call", return_value=_gw_resp(payload)):
        plan = PlanGenerator(gw).generate(_spec())

    assert len(plan.risk_register) == 1
    assert plan.risk_register[0].description == "real"


# ---------------------------------------------------------------------------
# YAML round-trip
# ---------------------------------------------------------------------------


def test_yaml_round_trip(tmp_path):
    original = Plan(
        plan_id="csv-bom-v1-20260426230000",
        spec_name="csv-bom",
        spec_version=1,
        spec_ref="csv-bom v1",
        sprints=[
            Sprint(
                id="S1",
                name="Foundation",
                goal="stand up",
                gate="all green",
                phases=[
                    Phase(
                        id="S1.P1",
                        name="Skeleton",
                        agent="worker/Sonnet",
                        deliverables=["pyproject"],
                        tests=["import works"],
                        gate="install succeeds",
                    )
                ],
            )
        ],
        risk_register=[RiskItem(description="x", severity="low", mitigation="y")],
        scope_in=["a"],
        scope_out=["b"],
        human_approval_gates=["after_plan_review", "after_S1"],
        generated_by="t/p",
        generated_at="2026-04-26T23:00:00Z",
        cost_usd=0.005,
    )
    path = tmp_path / "csv-bom.plan.yaml"

    written = write_plan(original, path)
    assert written == path
    assert path.exists()

    loaded = read_plan(path)
    assert loaded == original


def test_read_plan_returns_none_for_missing_file(tmp_path):
    assert read_plan(tmp_path / "nope.yaml") is None


def test_write_plan_creates_parent_directories(tmp_path):
    plan = Plan(plan_id="x", spec_name="x", spec_version=1, spec_ref="x v1")
    path = tmp_path / "deep" / "nested" / "plans" / "x.yaml"
    write_plan(plan, path)
    assert path.exists()


# ---------------------------------------------------------------------------
# §10 ASCII renderer
# ---------------------------------------------------------------------------


def _full_plan() -> Plan:
    return Plan(
        plan_id="csv-bom-v1-20260426",
        spec_name="csv-bom",
        spec_version=1,
        spec_ref="csv-bom v1",
        sprints=[
            Sprint(
                id="S1",
                name="Foundation",
                goal="stand up",
                gate="install + tests pass",
                cost_estimate_usd=2.0,
                duration_estimate_min=45,
                phases=[
                    Phase(
                        id="S1.P1",
                        name="Skeleton",
                        agent="worker/Sonnet",
                        deliverables=["pyproject.toml"],
                        tests=["import works"],
                        gate="make install",
                    ),
                    Phase(
                        id="S1.P2",
                        name="Gateway",
                        agent="planner/Opus",
                        deliverables=["heap/gateway.py"],
                        tests=["api call OK", "fallback works"],
                        gate="live call",
                    ),
                ],
            ),
            Sprint(
                id="S2",
                name="Fix BOM",
                goal="handle BOM",
                gate="scenarios green",
                cost_estimate_usd=3.0,
                duration_estimate_min=90,
                phases=[Phase(id="S2.P1", name="Repro")],
            ),
        ],
        risk_register=[
            RiskItem(description="encoding", severity="medium", mitigation="utf-8-sig"),
            RiskItem(description="callers", severity="high", mitigation="regression test"),
        ],
        scope_in=["fix BOM", "regression test"],
        scope_out=["refactor importer"],
        human_approval_gates=["after_plan_review", "after_S1", "after_S2"],
        estimated_cost_usd_low=4.0,
        estimated_cost_usd_high=6.0,
        estimated_duration_min_low=120,
        estimated_duration_min_high=180,
        estimated_tokens_total=120000,
    )


def test_to_text_renders_header():
    from heap.plan import to_text

    out = to_text(_full_plan())
    assert "PLAN: csv-bom-v1-20260426" in out
    assert "Spec: csv-bom v1" in out
    assert "$4.00-$6.00" in out
    assert "2h-3h" in out
    assert "120,000 tokens" in out


def test_to_text_renders_sprints_and_phases():
    from heap.plan import to_text

    out = to_text(_full_plan())
    assert "S1 · Foundation" in out
    assert "S1.P1  Skeleton" in out
    assert "[Sonnet]" in out
    assert "S1.P2  Gateway" in out
    assert "[Opus]" in out
    assert "S2 · Fix BOM" in out
    assert "S2.P1  Repro" in out
    # Deliverables shown
    assert "pyproject.toml" in out
    # Test summary collapses multiple
    assert "2 tests" in out


def test_to_text_renders_gates():
    from heap.plan import to_text

    out = to_text(_full_plan())
    assert "Gate: install + tests pass" in out
    assert "HUMAN APPROVAL REQUIRED" in out


def test_to_text_renders_scope_and_risks():
    from heap.plan import to_text

    out = to_text(_full_plan())
    assert "SCOPE BOUNDARIES" in out
    assert "✓ In scope:    fix BOM" in out
    assert "✗ Out:         refactor importer" in out
    assert "RISKS" in out
    assert "[medium] encoding" in out
    assert "→ utf-8-sig" in out
    assert "[high] callers" in out


def test_to_text_renders_actions_menu():
    from heap.plan import to_text

    out = to_text(_full_plan())
    assert "ACTIONS" in out
    assert "[a] Approve and start" in out
    assert "[e] Edit" in out
    assert "[r] Regenerate" in out
    assert "[q] Cancel" in out


def test_to_text_handles_empty_plan():
    from heap.plan import to_text

    p = Plan(plan_id="x", spec_name="x", spec_version=1, spec_ref="x v1")
    out = to_text(p)
    assert "PLAN: x" in out
    assert "0 sprints" in out
    # No sprint blocks rendered
    assert "Gate:" not in out
    # No scope / risks sections
    assert "SCOPE BOUNDARIES" not in out
    assert "RISKS" not in out
    # Action menu still rendered
    assert "ACTIONS" in out


# ---------------------------------------------------------------------------
# Heuristics — S5.P3
# ---------------------------------------------------------------------------


def _bare_plan(*, sprints=None, scope_out=None) -> Plan:
    return Plan(
        plan_id="x",
        spec_name="x",
        spec_version=1,
        spec_ref="x v1",
        sprints=sprints or [],
        scope_out=scope_out or [],
    )


def test_apply_heuristics_fills_phase_estimates():
    from heap.plan import apply_heuristics

    plan = _bare_plan(
        sprints=[
            Sprint(
                id="S1",
                name="Foo",
                phases=[
                    Phase(
                        id="S1.P1",
                        name="x",
                        agent="worker/Sonnet",
                        deliverables=["a"],
                        tests=["t1", "t2"],
                    )
                ],
            )
        ],
        scope_out=["explicit-out"],  # silence the scope-creep risk
    )
    out = apply_heuristics(plan)
    p = out.sprints[0].phases[0]
    assert p.duration_estimate_min > 0
    assert p.cost_estimate_usd > 0
    # Sprint rolls up
    assert out.sprints[0].duration_estimate_min == p.duration_estimate_min
    assert out.sprints[0].cost_estimate_usd == p.cost_estimate_usd


def test_apply_heuristics_scales_with_deliverables_and_tests():
    from heap.plan import apply_heuristics

    bigger = apply_heuristics(
        _bare_plan(
            sprints=[
                Sprint(
                    id="S1",
                    name="x",
                    phases=[
                        Phase(
                            id="S1.P1",
                            name="x",
                            agent="worker/Sonnet",
                            deliverables=["a", "b", "c"],
                            tests=["t1", "t2", "t3", "t4"],
                        )
                    ],
                )
            ],
            scope_out=["x"],
        )
    )
    smaller = apply_heuristics(
        _bare_plan(
            sprints=[
                Sprint(
                    id="S1",
                    name="x",
                    phases=[
                        Phase(
                            id="S1.P1",
                            name="x",
                            agent="worker/Sonnet",
                            deliverables=["a"],
                            tests=["t1"],
                        )
                    ],
                )
            ],
            scope_out=["x"],
        )
    )

    assert (
        bigger.sprints[0].phases[0].duration_estimate_min
        > smaller.sprints[0].phases[0].duration_estimate_min
    )
    assert (
        bigger.sprints[0].phases[0].cost_estimate_usd
        > smaller.sprints[0].phases[0].cost_estimate_usd
    )


def test_apply_heuristics_planner_costs_more_than_worker():
    from heap.plan import apply_heuristics

    planner_phase = Phase(
        id="S1.P1", name="x", agent="planner/Opus", deliverables=["a"], tests=["t"]
    )
    worker_phase = Phase(
        id="S1.P1", name="x", agent="worker/Sonnet", deliverables=["a"], tests=["t"]
    )

    p_planner = apply_heuristics(
        _bare_plan(sprints=[Sprint(id="S1", name="x", phases=[planner_phase])], scope_out=["x"])
    )
    p_worker = apply_heuristics(
        _bare_plan(sprints=[Sprint(id="S1", name="x", phases=[worker_phase])], scope_out=["x"])
    )

    assert (
        p_planner.sprints[0].phases[0].cost_estimate_usd
        > p_worker.sprints[0].phases[0].cost_estimate_usd
    )


def test_apply_heuristics_byhand_phase_has_zero_cost():
    from heap.plan import apply_heuristics

    plan = _bare_plan(
        sprints=[
            Sprint(
                id="S0",
                name="bootstrap",
                phases=[
                    Phase(id="S0.P1", name="x", agent="by-hand", deliverables=["a"], tests=["t"])
                ],
            )
        ],
        scope_out=["x"],
    )
    out = apply_heuristics(plan)
    assert out.sprints[0].phases[0].cost_estimate_usd == 0.0
    assert out.sprints[0].phases[0].duration_estimate_min > 0  # still has time


def test_apply_heuristics_preserves_existing_estimates():
    """If the planner already provided a number, don't overwrite it."""
    from heap.plan import apply_heuristics

    plan = _bare_plan(
        sprints=[
            Sprint(
                id="S1",
                name="x",
                phases=[
                    Phase(
                        id="S1.P1",
                        name="x",
                        agent="worker/Sonnet",
                        deliverables=["a"],
                        tests=["t"],
                        cost_estimate_usd=99.99,  # explicit override
                        duration_estimate_min=999,
                    )
                ],
                cost_estimate_usd=100.0,
                duration_estimate_min=1000,
            )
        ],
        scope_out=["x"],
    )
    out = apply_heuristics(plan)
    assert out.sprints[0].phases[0].cost_estimate_usd == 99.99
    assert out.sprints[0].phases[0].duration_estimate_min == 999
    assert out.sprints[0].cost_estimate_usd == 100.0
    assert out.sprints[0].duration_estimate_min == 1000


def test_apply_heuristics_rolls_up_to_plan_range():
    from heap.plan import apply_heuristics

    plan = _bare_plan(
        sprints=[
            Sprint(
                id="S1",
                name="x",
                phases=[
                    Phase(
                        id="S1.P1", name="x", agent="worker/Sonnet", deliverables=["a"], tests=["t"]
                    )
                ],
            ),
            Sprint(
                id="S2",
                name="x",
                phases=[
                    Phase(
                        id="S2.P1", name="x", agent="worker/Sonnet", deliverables=["a"], tests=["t"]
                    )
                ],
            ),
        ],
        scope_out=["x"],
    )
    out = apply_heuristics(plan)
    # Range: low ≈ 0.7×, high ≈ 1.4×
    assert out.estimated_cost_usd_high > out.estimated_cost_usd_low > 0
    assert out.estimated_duration_min_high > out.estimated_duration_min_low > 0
    assert out.estimated_tokens_total > 0


def test_apply_heuristics_idempotent_on_estimates():
    """Running twice does not double-count the rollups."""
    from heap.plan import apply_heuristics

    plan = _bare_plan(
        sprints=[
            Sprint(
                id="S1",
                name="x",
                phases=[
                    Phase(
                        id="S1.P1", name="x", agent="worker/Sonnet", deliverables=["a"], tests=["t"]
                    )
                ],
            )
        ],
        scope_out=["x"],
    )
    once = apply_heuristics(plan)
    twice = apply_heuristics(once)
    assert twice.estimated_cost_usd_low == once.estimated_cost_usd_low
    assert twice.estimated_cost_usd_high == once.estimated_cost_usd_high
    assert (
        twice.sprints[0].phases[0].cost_estimate_usd == once.sprints[0].phases[0].cost_estimate_usd
    )


def test_apply_heuristics_flags_phase_without_tests():
    from heap.plan import apply_heuristics

    plan = _bare_plan(
        sprints=[
            Sprint(
                id="S1",
                name="x",
                phases=[Phase(id="S1.P1", name="x", deliverables=["a"], tests=[])],
            )
        ],
        scope_out=["x"],
    )
    out = apply_heuristics(plan)
    descs = [r.description for r in out.risk_register]
    assert any("S1.P1" in d and "no tests" in d for d in descs)


def test_apply_heuristics_flags_oversized_sprint():
    from heap.plan import apply_heuristics

    big_sprint = Sprint(
        id="S1",
        name="x",
        phases=[
            Phase(id=f"S1.P{i}", name="x", deliverables=["a"], tests=["t"]) for i in range(1, 7)
        ],
    )
    plan = _bare_plan(sprints=[big_sprint], scope_out=["x"])
    out = apply_heuristics(plan)
    descs = [r.description for r in out.risk_register]
    assert any("6 phases" in d for d in descs)


def test_apply_heuristics_flags_empty_scope_out():
    from heap.plan import apply_heuristics

    plan = _bare_plan(
        sprints=[
            Sprint(
                id="S1",
                name="x",
                phases=[Phase(id="S1.P1", name="x", deliverables=["a"], tests=["t"])],
            )
        ],
        scope_out=[],
    )
    out = apply_heuristics(plan)
    descs = [r.description for r in out.risk_register]
    assert any("scope creep" in d.lower() for d in descs)


def test_apply_heuristics_skips_risks_for_empty_plan():
    """Degenerate plans (no sprints) get no auto-risks."""
    from heap.plan import apply_heuristics

    out = apply_heuristics(_bare_plan(sprints=[], scope_out=[]))
    assert out.risk_register == []


def test_apply_heuristics_dedupes_existing_risk():
    from heap.plan import apply_heuristics

    plan = Plan(
        plan_id="x",
        spec_name="x",
        spec_version=1,
        spec_ref="x v1",
        sprints=[],
        risk_register=[
            RiskItem(
                description="Scope creep risk — keep an eye on out-of-scope additions",
                severity="medium",
            )
        ],
        scope_out=[],
    )
    out = apply_heuristics(plan)
    # Should not add a duplicate scope-creep entry
    creep_entries = [r for r in out.risk_register if "scope creep" in r.description.lower()]
    assert len(creep_entries) == 1


def test_planner_generate_applies_heuristics_by_default():
    """End-to-end integration: generate() calls apply_heuristics."""
    gw = _gw()
    payload = {
        "sprints": [
            {
                "id": "S1",
                "name": "x",
                "phases": [{"id": "S1.P1", "name": "x", "deliverables": ["a"], "tests": ["t"]}],
            }
        ],
        "risk_register": [],
        "scope_in": ["a"],
        "scope_out": ["b"],  # scope_out non-empty so the creep risk doesn't fire
    }
    with patch.object(gw, "call", return_value=_gw_resp(payload)):
        plan = PlanGenerator(gw).generate(_spec())

    assert plan.estimated_cost_usd_high > 0
    assert plan.estimated_duration_min_high > 0
    assert plan.sprints[0].phases[0].cost_estimate_usd > 0


def test_planner_generate_respects_apply_heuristics_pass_false():
    """Disabling the pass leaves zeros."""
    gw = _gw()
    payload = {
        "sprints": [{"id": "S1", "name": "x", "phases": [{"id": "S1.P1", "name": "x"}]}],
        "risk_register": [],
        "scope_in": [],
        "scope_out": ["x"],
    }
    with patch.object(gw, "call", return_value=_gw_resp(payload)):
        plan = PlanGenerator(gw).generate(_spec(), apply_heuristics_pass=False)

    assert plan.estimated_cost_usd_high == 0.0
    assert plan.estimated_duration_min_high == 0
    assert plan.sprints[0].phases[0].cost_estimate_usd == 0.0


# ---------------------------------------------------------------------------
# Amendments — S5.P4
# ---------------------------------------------------------------------------


def _amendable_plan() -> Plan:
    """Plan with one sprint and two phases, ready for amendments."""
    return Plan(
        plan_id="csv-bom-v1-x",
        spec_name="csv-bom",
        spec_version=1,
        spec_ref="csv-bom v1",
        sprints=[
            Sprint(
                id="S1",
                name="Foundation",
                gate="install + tests pass",
                phases=[
                    Phase(id="S1.P1", name="Skel", deliverables=["a"], tests=["t1"], gate="ok"),
                    Phase(id="S1.P2", name="Plan", deliverables=["b"], tests=[], gate="ok"),
                ],
            )
        ],
        risk_register=[RiskItem(description="encoding", severity="medium")],
        scope_in=["fix"],
        scope_out=["refactor"],
    )


def test_amendment_add_phase_appends_and_bumps_rev():
    from heap.plan import Amendment, apply_amendment

    plan = _amendable_plan()
    amendment = Amendment(
        kind="add_phase",
        sprint_id="S1",
        payload={"id": "S1.P3", "name": "New phase", "agent": "worker/Sonnet", "gate": "ok"},
        rationale="needed",
    )
    out = apply_amendment(plan, amendment)

    assert out.rev == 2
    assert len(out.sprints[0].phases) == 3
    assert out.sprints[0].phases[2].id == "S1.P3"
    assert len(out.revisions) == 1
    assert out.revisions[0].applied_at  # timestamp set
    # Approval reset
    assert out.approved_at is None
    assert out.approved_by == ""


def test_amendment_add_deliverable_appends():
    from heap.plan import Amendment, apply_amendment

    plan = _amendable_plan()
    out = apply_amendment(
        plan,
        Amendment(
            kind="add_deliverable",
            sprint_id="S1",
            phase_id="S1.P1",
            payload={"deliverable": "new file"},
        ),
    )
    assert out.sprints[0].phases[0].deliverables == ["a", "new file"]
    # Other phase untouched
    assert out.sprints[0].phases[1].deliverables == ["b"]


def test_amendment_add_test_appends():
    from heap.plan import Amendment, apply_amendment

    plan = _amendable_plan()
    out = apply_amendment(
        plan,
        Amendment(
            kind="add_test",
            sprint_id="S1",
            phase_id="S1.P2",
            payload={"test": "first test"},
        ),
    )
    assert out.sprints[0].phases[1].tests == ["first test"]


def test_amendment_change_phase_gate():
    from heap.plan import Amendment, apply_amendment

    plan = _amendable_plan()
    out = apply_amendment(
        plan,
        Amendment(
            kind="change_gate",
            sprint_id="S1",
            phase_id="S1.P1",
            payload={"gate": "all green + integration"},
        ),
    )
    assert out.sprints[0].phases[0].gate == "all green + integration"
    assert out.sprints[0].phases[1].gate == "ok"  # untouched


def test_amendment_change_sprint_gate_when_phase_id_blank():
    from heap.plan import Amendment, apply_amendment

    plan = _amendable_plan()
    out = apply_amendment(
        plan,
        Amendment(
            kind="change_gate",
            sprint_id="S1",
            payload={"gate": "tests + a smoke"},
        ),
    )
    assert out.sprints[0].gate == "tests + a smoke"


def test_amendment_add_risk_appends():
    from heap.plan import Amendment, apply_amendment

    plan = _amendable_plan()
    out = apply_amendment(
        plan,
        Amendment(
            kind="add_risk",
            payload={"description": "new risk", "severity": "high", "mitigation": "test more"},
        ),
    )
    assert len(out.risk_register) == 2
    assert out.risk_register[1].description == "new risk"
    assert out.risk_register[1].severity == "high"


def test_amendment_add_scope_out_appends():
    from heap.plan import Amendment, apply_amendment

    plan = _amendable_plan()
    out = apply_amendment(
        plan,
        Amendment(kind="add_scope_out", payload={"item": "expensive UI"}),
    )
    assert "expensive UI" in out.scope_out


def test_amendment_unknown_sprint_raises():
    from heap.plan import Amendment, AmendmentError, apply_amendment

    plan = _amendable_plan()
    with pytest.raises(AmendmentError, match="not found"):
        apply_amendment(
            plan, Amendment(kind="add_phase", sprint_id="GHOST", payload={"id": "x", "name": "y"})
        )


def test_amendment_missing_required_field_raises():
    from heap.plan import Amendment, AmendmentError, apply_amendment

    plan = _amendable_plan()
    with pytest.raises(AmendmentError, match="payload"):
        apply_amendment(plan, Amendment(kind="add_risk", payload={}))


def test_amendments_are_chainable_and_audited():
    from heap.plan import Amendment, apply_amendment

    p = _amendable_plan()
    p2 = apply_amendment(p, Amendment(kind="add_scope_out", payload={"item": "X"}))
    p3 = apply_amendment(p2, Amendment(kind="add_scope_out", payload={"item": "Y"}))
    p4 = apply_amendment(p3, Amendment(kind="add_risk", payload={"description": "R"}))

    assert p4.rev == 4
    assert len(p4.revisions) == 3
    assert p4.scope_out == ["refactor", "X", "Y"]
    assert any(r.description == "R" for r in p4.risk_register)


def test_approve_plan_sets_fields():
    from heap.plan import approve_plan

    plan = _amendable_plan()
    out = approve_plan(plan, approver="vicente")
    assert out.approved_at is not None
    assert out.approved_by == "vicente"


def test_approve_plan_default_approver_blank():
    from heap.plan import approve_plan

    out = approve_plan(_amendable_plan())
    assert out.approved_at is not None
    assert out.approved_by == ""
