"""Tests for heap.spec.structurer — pure file-system, no model calls."""

from __future__ import annotations

import json

import pytest
import yaml

from heap.spec import InterrogatorOutcome, StructuredSpec, Structurer
from heap.spec.evidence import inspect_file
from heap.spec.interrogator import TranscriptEntry

# ---------------------------------------------------------------------------
# helpers
# ---------------------------------------------------------------------------


def _outcome(
    mode: str = "bug",
    audience: str = "developer",
    facts: dict | None = None,
    transcript_n: int = 0,
) -> InterrogatorOutcome:
    transcript = []
    for i in range(transcript_n):
        transcript.append(TranscriptEntry(role="interrogator", content=f"Q{i + 1}"))
        transcript.append(TranscriptEntry(role="user", content=f"A{i + 1}"))
    return InterrogatorOutcome(
        mode=mode,
        audience=audience,
        facts=facts or {},
        transcript=transcript,
        finalized_at="2026-04-26T18:00:00Z",
        turns_used=transcript_n,
        incomplete=False,
    )


# ---------------------------------------------------------------------------
# basic write — all 4 artifacts created
# ---------------------------------------------------------------------------


def test_write_creates_all_four_artifacts(tmp_path):
    s = Structurer(specs_dir=tmp_path)
    outcome = _outcome(
        mode="bug",
        facts={
            "symptom": "CSV import returns zero rows",
            "expected": "all rows imported",
        },
    )

    spec = s.write(outcome, name="csv-bom")

    assert isinstance(spec, StructuredSpec)
    assert spec.version == 1
    assert (tmp_path / "csv-bom.spec.yaml").exists()
    assert (tmp_path / "csv-bom.spec.v1.yaml").exists()
    assert (tmp_path / "csv-bom.spec.md").exists()
    assert (tmp_path / "csv-bom.acceptance.json").exists()

    # Canonical and versioned YAML have identical content
    canon = (tmp_path / "csv-bom.spec.yaml").read_text()
    v1 = (tmp_path / "csv-bom.spec.v1.yaml").read_text()
    assert canon == v1


def test_write_yaml_is_loadable_and_round_trips(tmp_path):
    s = Structurer(specs_dir=tmp_path)
    outcome = _outcome(facts={"symptom": "x", "expected": "y"})
    s.write(outcome, name="rt")

    loaded = yaml.safe_load((tmp_path / "rt.spec.yaml").read_text())
    assert loaded["name"] == "rt"
    assert loaded["version"] == 1
    assert loaded["facts"]["symptom"] == "x"


def test_acceptance_json_is_a_flat_string_list(tmp_path):
    s = Structurer(specs_dir=tmp_path)
    outcome = _outcome(
        mode="bug",
        facts={"symptom": "CSV import zero rows", "expected": "all rows imported"},
    )
    s.write(outcome, name="csv")

    accept = json.loads((tmp_path / "csv.acceptance.json").read_text())
    assert isinstance(accept, list)
    assert all(isinstance(s, str) for s in accept)
    assert len(accept) == 2


# ---------------------------------------------------------------------------
# versioning — automatic bump
# ---------------------------------------------------------------------------


def test_versioning_bumps_on_repeated_writes(tmp_path):
    s = Structurer(specs_dir=tmp_path)
    s.write(_outcome(facts={"symptom": "v1"}), name="amend")
    s.write(_outcome(facts={"symptom": "v2"}), name="amend")
    spec3 = s.write(_outcome(facts={"symptom": "v3"}), name="amend")

    assert spec3.version == 3
    assert (tmp_path / "amend.spec.v1.yaml").exists()
    assert (tmp_path / "amend.spec.v2.yaml").exists()
    assert (tmp_path / "amend.spec.v3.yaml").exists()
    # Canonical mirrors latest (v3)
    latest = yaml.safe_load((tmp_path / "amend.spec.yaml").read_text())
    assert latest["version"] == 3
    assert latest["facts"]["symptom"] == "v3"


def test_list_versions_returns_existing(tmp_path):
    s = Structurer(specs_dir=tmp_path)
    s.write(_outcome(), name="x")
    s.write(_outcome(), name="x")
    assert s.list_versions("x") == [1, 2]
    assert s.list_versions("nonexistent") == []


# ---------------------------------------------------------------------------
# read
# ---------------------------------------------------------------------------


def test_read_canonical_returns_latest(tmp_path):
    s = Structurer(specs_dir=tmp_path)
    s.write(_outcome(facts={"symptom": "v1"}), name="x")
    s.write(_outcome(facts={"symptom": "v2"}), name="x")

    spec = s.read("x")
    assert spec is not None
    assert spec.version == 2
    assert spec.facts["symptom"] == "v2"


def test_read_specific_version(tmp_path):
    s = Structurer(specs_dir=tmp_path)
    s.write(_outcome(facts={"symptom": "v1"}), name="x")
    s.write(_outcome(facts={"symptom": "v2"}), name="x")

    spec1 = s.read("x", version=1)
    assert spec1 is not None
    assert spec1.version == 1
    assert spec1.facts["symptom"] == "v1"


def test_read_missing_returns_none(tmp_path):
    s = Structurer(specs_dir=tmp_path)
    assert s.read("nope") is None
    assert s.read("nope", version=99) is None


# ---------------------------------------------------------------------------
# list
# ---------------------------------------------------------------------------


def test_list_returns_unique_names(tmp_path):
    s = Structurer(specs_dir=tmp_path)
    s.write(_outcome(), name="alpha")
    s.write(_outcome(), name="alpha")  # bumps to v2 for alpha
    s.write(_outcome(), name="beta")
    assert s.list() == ["alpha", "beta"]


def test_list_handles_missing_dir(tmp_path):
    s = Structurer(specs_dir=tmp_path / "doesnt-exist")
    assert s.list() == []


# ---------------------------------------------------------------------------
# acceptance extraction by mode
# ---------------------------------------------------------------------------


def test_feature_mode_reads_acceptance_key(tmp_path):
    s = Structurer(specs_dir=tmp_path)
    outcome = _outcome(
        mode="feature",
        facts={"acceptance": ["criterion 1", "criterion 2"]},
    )
    spec = s.write(outcome, name="feat")
    assert spec.acceptance == ["criterion 1", "criterion 2"]


def test_feature_mode_falls_back_to_success_key(tmp_path):
    s = Structurer(specs_dir=tmp_path)
    outcome = _outcome(mode="feature", facts={"success": "the thing works"})
    spec = s.write(outcome, name="feat")
    assert spec.acceptance == ["the thing works"]


def test_bug_mode_derives_from_expected_and_symptom(tmp_path):
    s = Structurer(specs_dir=tmp_path)
    outcome = _outcome(
        mode="bug",
        facts={"symptom": "zero rows", "expected": "rows imported"},
    )
    spec = s.write(outcome, name="bug")
    assert any("rows imported" in c for c in spec.acceptance)
    assert any("zero rows" in c for c in spec.acceptance)


def test_bug_mode_explicit_acceptance_overrides_derivation(tmp_path):
    s = Structurer(specs_dir=tmp_path)
    outcome = _outcome(
        mode="bug",
        facts={
            "symptom": "x",
            "expected": "y",
            "acceptance": ["Tests pass after fix."],
        },
    )
    spec = s.write(outcome, name="bug")
    assert spec.acceptance == ["Tests pass after fix."]


def test_greenfield_mode_reads_first_iteration(tmp_path):
    s = Structurer(specs_dir=tmp_path)
    outcome = _outcome(
        mode="greenfield",
        facts={"first_iteration": "ship a hello-world page"},
    )
    spec = s.write(outcome, name="g")
    assert spec.acceptance == ["ship a hello-world page"]


def test_empty_facts_yields_empty_acceptance(tmp_path):
    s = Structurer(specs_dir=tmp_path)
    spec = s.write(_outcome(facts={}), name="empty")
    assert spec.acceptance == []


# ---------------------------------------------------------------------------
# transcript summary + markdown
# ---------------------------------------------------------------------------


def test_markdown_contains_facts_and_acceptance(tmp_path):
    s = Structurer(specs_dir=tmp_path)
    outcome = _outcome(
        mode="bug",
        facts={"symptom": "zero rows", "expected": "rows imported"},
        transcript_n=2,
    )
    s.write(outcome, name="bug")
    md = (tmp_path / "bug.spec.md").read_text()
    assert "# bug" in md
    assert "**symptom:**" in md
    assert "## Acceptance criteria" in md
    assert "[ ]" in md  # checkboxes
    assert "## Transcript summary" in md


def test_transcript_summary_counts_qa(tmp_path):
    s = Structurer(specs_dir=tmp_path)
    outcome = _outcome(transcript_n=3)
    spec = s.write(outcome, name="t")
    assert "3 answers" in spec.transcript_summary


# ---------------------------------------------------------------------------
# evidence integration
# ---------------------------------------------------------------------------


def test_evidence_models_are_serialized(tmp_path):
    """A real evidence collector (inspect_file) plugged in cleanly."""
    bom_path = tmp_path / "with_bom.csv"
    bom_path.write_bytes(b"\xef\xbb\xbfname,age\n")

    ev = inspect_file(bom_path)
    s = Structurer(specs_dir=tmp_path)
    spec = s.write(_outcome(), name="ev", evidence=[ev])

    assert len(spec.evidence) == 1
    assert "BOM" in (spec.evidence[0].get("encoding_hint") or "")


def test_evidence_dict_passthrough(tmp_path):
    s = Structurer(specs_dir=tmp_path)
    spec = s.write(_outcome(), name="ev", evidence=[{"custom": "shape"}])
    assert spec.evidence == [{"custom": "shape"}]


# ---------------------------------------------------------------------------
# validation
# ---------------------------------------------------------------------------


def test_invalid_name_raises(tmp_path):
    s = Structurer(specs_dir=tmp_path)
    with pytest.raises(ValueError, match="invalid"):
        s.write(_outcome(), name="bad/name")
    with pytest.raises(ValueError, match="invalid"):
        s.write(_outcome(), name="")
    with pytest.raises(ValueError, match="invalid"):
        s.write(_outcome(), name="../escape")


def test_specs_dir_created_on_first_write(tmp_path):
    target = tmp_path / "deep" / "specs"
    s = Structurer(specs_dir=target)
    s.write(_outcome(), name="x")
    assert target.exists()
    assert (target / "x.spec.yaml").exists()


# ---------------------------------------------------------------------------
# append_acceptance — S4.P3 spec-amendment path
# ---------------------------------------------------------------------------


def test_append_acceptance_bumps_version_and_adds_criterion(tmp_path):
    s = Structurer(specs_dir=tmp_path)
    s.write(_outcome(facts={"symptom": "zero rows", "expected": "rows imported"}), name="bug")

    new = s.append_acceptance("bug", "After fix: empty CSV files log an empty-state message")

    assert new.version == 2
    assert new.acceptance[-1] == "After fix: empty CSV files log an empty-state message"
    # File system reflects the bump
    assert (tmp_path / "bug.spec.v2.yaml").exists()
    canonical = yaml.safe_load((tmp_path / "bug.spec.yaml").read_text())
    assert canonical["version"] == 2
    accept = json.loads((tmp_path / "bug.acceptance.json").read_text())
    assert accept[-1] == "After fix: empty CSV files log an empty-state message"
    # facts['acceptance'] is now the explicit override list
    assert canonical["facts"]["acceptance"] == new.acceptance


def test_append_acceptance_preserves_v1_history(tmp_path):
    s = Structurer(specs_dir=tmp_path)
    s.write(_outcome(facts={"symptom": "x", "expected": "y"}), name="bug")
    s.append_acceptance("bug", "After fix: new criterion one")
    s.append_acceptance("bug", "After fix: new criterion two")

    assert (tmp_path / "bug.spec.v1.yaml").exists()
    assert (tmp_path / "bug.spec.v2.yaml").exists()
    assert (tmp_path / "bug.spec.v3.yaml").exists()

    v1 = yaml.safe_load((tmp_path / "bug.spec.v1.yaml").read_text())
    v3 = yaml.safe_load((tmp_path / "bug.spec.v3.yaml").read_text())
    assert v1["version"] == 1
    assert len(v1["acceptance"]) == 2  # original derived from expected/symptom
    assert v3["version"] == 3
    assert "After fix: new criterion two" in v3["acceptance"]


def test_append_acceptance_rejects_empty_criterion(tmp_path):
    s = Structurer(specs_dir=tmp_path)
    s.write(_outcome(facts={"symptom": "x", "expected": "y"}), name="bug")
    with pytest.raises(ValueError):
        s.append_acceptance("bug", "")
    with pytest.raises(ValueError):
        s.append_acceptance("bug", "   ")


def test_append_acceptance_rejects_unknown_spec(tmp_path):
    s = Structurer(specs_dir=tmp_path)
    with pytest.raises(ValueError):
        s.append_acceptance("ghost", "After fix: anything")


def test_append_acceptance_rejects_duplicate(tmp_path):
    s = Structurer(specs_dir=tmp_path)
    s.write(_outcome(facts={"symptom": "x", "expected": "y"}), name="bug")
    s.append_acceptance("bug", "After fix: only criterion")
    with pytest.raises(ValueError, match="already present"):
        s.append_acceptance("bug", "After fix: only criterion")
