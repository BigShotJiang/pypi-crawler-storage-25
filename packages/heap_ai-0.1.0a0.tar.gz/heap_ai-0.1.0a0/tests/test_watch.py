"""Tests for heap.watch — formatter + non-follow tail."""

from __future__ import annotations

from heap.run import RunEvent
from heap.watch import format_event, tail_jsonl


def _ev(kind: str, **kw) -> RunEvent:
    base = dict(ts="2026-04-27T12:00:00Z", kind=kind, sprint_id="", phase_id="", detail="")
    base.update(kw)
    return RunEvent(**base)


# ---------------------------------------------------------------------------
# format_event
# ---------------------------------------------------------------------------


def test_format_event_renders_kind_and_ids():
    ev = _ev("phase_pass", sprint_id="S1", phase_id="S1.P1", detail="ok")
    out = format_event(ev, color=False)
    assert "phase_pass" in out
    assert "S1.P1" in out
    assert "ok" in out
    assert "S1" in out


def test_format_event_uses_glyph_per_kind():
    assert "▶" in format_event(_ev("run_start"), color=False)
    assert "⚑" in format_event(_ev("sprint_gate"), color=False)
    assert "↻" in format_event(_ev("phase_retry"), color=False)
    assert "✓" in format_event(_ev("phase_pass"), color=False)
    assert "✗" in format_event(_ev("phase_fail"), color=False)


def test_format_event_no_color_omits_ansi():
    out = format_event(_ev("phase_pass"), color=False)
    assert "\x1b[" not in out  # no escape codes


def test_format_event_color_adds_ansi_for_styled_kinds():
    out = format_event(_ev("phase_pass"), color=True)
    assert "\x1b[" in out


def test_format_event_unknown_kind_uses_default_glyph():
    out = format_event(_ev("custom_kind"), color=False)
    assert "·" in out  # default glyph
    assert "custom_kind" in out


def test_format_event_empty_ids_render_padding():
    out = format_event(_ev("run_complete"), color=False)
    # 4 chars sprint padding + 8 chars phase padding when blank
    assert "run_complete" in out


# ---------------------------------------------------------------------------
# tail_jsonl — snapshot mode
# ---------------------------------------------------------------------------


def test_tail_jsonl_no_follow_returns_last_n(tmp_path):
    p = tmp_path / "trace.jsonl"
    lines = [_ev(f"k{i}").model_dump_json() for i in range(10)]
    p.write_text("\n".join(lines) + "\n")

    events = list(tail_jsonl(p, follow=False, n=3))
    kinds = [e.kind for e in events]
    assert kinds == ["k7", "k8", "k9"]


def test_tail_jsonl_no_follow_missing_file_yields_empty(tmp_path):
    events = list(tail_jsonl(tmp_path / "nope.jsonl", follow=False))
    assert events == []


def test_tail_jsonl_skips_malformed_lines(tmp_path):
    p = tmp_path / "trace.jsonl"
    parts = [
        _ev("ok1").model_dump_json(),
        "not json",
        _ev("ok2").model_dump_json(),
    ]
    p.write_text("\n".join(parts) + "\n")

    events = list(tail_jsonl(p, follow=False, n=10))
    assert [e.kind for e in events] == ["ok1", "ok2"]


# ---------------------------------------------------------------------------
# tail_jsonl — follow mode (bounded with max_iters for testability)
# ---------------------------------------------------------------------------


def test_tail_jsonl_follow_picks_up_new_lines(tmp_path):
    p = tmp_path / "trace.jsonl"
    p.write_text(_ev("seed").model_dump_json() + "\n")

    # Append two new events; tail with max_iters=2 should observe them.
    with p.open("a") as f:
        f.write(_ev("new1").model_dump_json() + "\n")
        f.write(_ev("new2").model_dump_json() + "\n")

    events = list(tail_jsonl(p, follow=True, n=10, interval_s=0.0, max_iters=1))
    kinds = [e.kind for e in events]
    # Initial tail returns "seed"; the appends were before the follow loop ran,
    # so they're picked up on the first poll cycle as new bytes.
    assert "seed" in kinds
    assert "new1" in kinds
    assert "new2" in kinds


def test_tail_jsonl_follow_with_no_initial_file(tmp_path):
    """Follow mode tolerates a missing file at start (waits for it)."""
    target = tmp_path / "trace.jsonl"
    # Bounded by max_iters so the test exits even if file never appears.
    events = list(tail_jsonl(target, follow=True, n=5, interval_s=0.0, max_iters=2))
    assert events == []


def test_tail_jsonl_follow_handles_truncation(tmp_path):
    """If the file shrinks (rotation), tail restarts from byte 0."""
    p = tmp_path / "trace.jsonl"
    p.write_text(_ev("a").model_dump_json() + "\n" + _ev("b").model_dump_json() + "\n")

    # Truncate to fewer bytes so the follow loop sees cur_size < pos.
    p.write_text(_ev("c").model_dump_json() + "\n")

    events = list(tail_jsonl(p, follow=True, n=10, interval_s=0.0, max_iters=2))
    kinds = [e.kind for e in events]
    # Initial dump caught {a,b} from the *first* read which... wait — the file
    # was rewritten before the iterator started, so initial dump sees only {c}.
    # The follow loop doesn't yield anything new because pos was reset to 0.
    assert "c" in kinds
