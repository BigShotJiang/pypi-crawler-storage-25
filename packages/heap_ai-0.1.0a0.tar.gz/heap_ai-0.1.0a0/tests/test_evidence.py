"""Tests for heap.spec.evidence — pure-function collectors, no mocks needed."""

from __future__ import annotations

import textwrap

from heap.spec.evidence import (
    FileAttachmentEvidence,
    LogEvidence,
    ReproEvidence,
    StackTraceEvidence,
    inspect_file,
    parse_log_text,
    parse_repro_steps,
    parse_stacktrace,
)

# ---------------------------------------------------------------------------
# parse_log_text
# ---------------------------------------------------------------------------


def test_parse_log_text_extracts_levels_and_counts() -> None:
    text = textwrap.dedent("""
        2026-04-26T18:03:11Z INFO  app: starting
        2026-04-26T18:03:11Z ERROR app: db connect failed: refused
        2026-04-26T18:03:12Z WARN  app: retrying
        2026-04-26T18:03:13Z ERROR app: still failing
        random non-log line that does not match any pattern
    """).strip()

    ev = parse_log_text(text)
    assert isinstance(ev, LogEvidence)
    assert ev.error_count == 2
    assert ev.warning_count == 1
    assert ev.info_count == 1
    assert ev.other_count == 1
    assert len(ev.entries) == 5
    assert ev.errors[0].message.startswith("app: db connect failed")
    assert ev.errors[0].timestamp == "2026-04-26T18:03:11Z"
    assert "2 errors, 1 warnings" in ev.summary


def test_parse_log_text_handles_bracketed_levels() -> None:
    text = "[ERROR] something broke\n[INFO] but recovered"
    ev = parse_log_text(text)
    assert ev.error_count == 1
    assert ev.info_count == 1


def test_parse_log_text_normalizes_aliased_levels() -> None:
    text = "FATAL: total failure\nWARNING: light issue\nERR: short error"
    ev = parse_log_text(text)
    # FATAL/CRITICAL/ERR all collapse to ERROR; WARNING → WARN
    assert ev.error_count == 2
    assert ev.warning_count == 1


def test_parse_log_text_empty_input_is_empty() -> None:
    ev = parse_log_text("")
    assert ev.entries == []
    assert ev.summary.startswith("0 errors")


def test_parse_log_text_skips_blank_lines() -> None:
    text = "ERROR a\n\n\nWARN b\n"
    ev = parse_log_text(text)
    assert len(ev.entries) == 2


# ---------------------------------------------------------------------------
# parse_stacktrace
# ---------------------------------------------------------------------------


_PY_TRACEBACK = textwrap.dedent("""
    Traceback (most recent call last):
      File "/Users/vicentejr/dev/heap-ai/heap/gateway.py", line 42, in call
        return litellm.completion(model=model_id, messages=messages)
      File "/Users/vicentejr/dev/heap-ai/heap/agent.py", line 200, in run
        plan_resp = self._call_plan(task, last_verify=last_verify)
    ValueError: Unknown role 'bogus'; expected one of ('planner', 'worker', 'fast')
""").strip()


def test_parse_stacktrace_extracts_error_and_frames() -> None:
    ev = parse_stacktrace(_PY_TRACEBACK)
    assert isinstance(ev, StackTraceEvidence)
    assert ev.error_type == "ValueError"
    assert ev.error_message and "Unknown role" in ev.error_message
    assert len(ev.frames) == 2
    f0 = ev.frames[0]
    assert f0.file.endswith("gateway.py")
    assert f0.line == 42
    assert f0.function == "call"
    assert f0.code and "litellm.completion" in f0.code


def test_parse_stacktrace_no_error_type_is_ok() -> None:
    """Just frames without a final 'XError: …' line."""
    text = '  File "foo.py", line 1, in bar\n    do_thing()'
    ev = parse_stacktrace(text)
    assert ev.error_type is None
    assert len(ev.frames) == 1
    assert ev.frames[0].file == "foo.py"


def test_parse_stacktrace_empty_input() -> None:
    ev = parse_stacktrace("")
    assert ev.frames == []
    assert ev.error_type is None
    assert ev.error_message is None


# ---------------------------------------------------------------------------
# inspect_file
# ---------------------------------------------------------------------------


def test_inspect_file_detects_utf8_bom(tmp_path) -> None:
    p = tmp_path / "with_bom.csv"
    p.write_bytes(b"\xef\xbb\xbfname,age\nAlice,30\n")

    ev = inspect_file(p)
    assert isinstance(ev, FileAttachmentEvidence)
    assert ev.exists is True
    assert ev.size_bytes == len(b"\xef\xbb\xbfname,age\nAlice,30\n")
    assert ev.hex_dump.startswith("ef bb bf")
    assert ev.encoding_hint and "BOM" in ev.encoding_hint


def test_inspect_file_detects_zip_magic(tmp_path) -> None:
    p = tmp_path / "thing.zip"
    p.write_bytes(b"PK\x03\x04" + b"\x00" * 12)

    ev = inspect_file(p)
    assert ev.encoding_hint and "ZIP" in ev.encoding_hint


def test_inspect_file_plain_text_no_hint(tmp_path) -> None:
    p = tmp_path / "plain.txt"
    p.write_bytes(b"Just some text without a BOM.")

    ev = inspect_file(p)
    assert ev.encoding_hint is None
    assert ev.size_bytes > 0
    assert ev.hex_dump  # non-empty


def test_inspect_file_missing_file_returns_exists_false(tmp_path) -> None:
    ev = inspect_file(tmp_path / "does_not_exist.txt")
    assert ev.exists is False
    assert ev.size_bytes == 0
    assert ev.hex_dump == ""


def test_inspect_file_directory_returns_exists_false(tmp_path) -> None:
    """Inspecting a directory shouldn't crash; treats as 'not a file'."""
    ev = inspect_file(tmp_path)
    assert ev.exists is False


def test_inspect_file_short_file_pads_correctly(tmp_path) -> None:
    """File smaller than 16 bytes — hex dump just shows what's there."""
    p = tmp_path / "short.bin"
    p.write_bytes(b"\x00\xff\x42")

    ev = inspect_file(p)
    assert ev.size_bytes == 3
    assert ev.hex_dump == "00 ff 42"


# ---------------------------------------------------------------------------
# parse_repro_steps
# ---------------------------------------------------------------------------


def test_parse_repro_steps_numbered_with_dots() -> None:
    text = textwrap.dedent("""
        Steps to reproduce:
        1. open the dashboard
        2. upload a CSV with UTF-8 BOM
        3. observe zero rows imported
    """).strip()

    ev = parse_repro_steps(text)
    assert isinstance(ev, ReproEvidence)
    assert len(ev.steps) == 3
    assert ev.steps[0].step_number == 1
    assert ev.steps[0].text == "open the dashboard"
    assert ev.steps[2].text.startswith("observe zero rows")


def test_parse_repro_steps_numbered_with_parens() -> None:
    text = "Repro:\n1) click here\n2) wait\n3) observe"
    ev = parse_repro_steps(text)
    assert len(ev.steps) == 3


def test_parse_repro_steps_step_prefix_form() -> None:
    text = "Reproduction:\nStep 1: log in\nStep 2: click X\nStep 3: see crash"
    ev = parse_repro_steps(text)
    assert len(ev.steps) == 3
    assert ev.steps[1].text == "click X"


def test_parse_repro_steps_bulleted_assigns_auto_numbers() -> None:
    text = "Steps to reproduce:\n- thing one\n- thing two\n- thing three"
    ev = parse_repro_steps(text)
    assert [s.step_number for s in ev.steps] == [1, 2, 3]
    assert ev.steps[0].text == "thing one"


def test_parse_repro_steps_no_header_still_finds_steps() -> None:
    """If user pastes steps without the 'Steps to reproduce:' header."""
    text = "1. first\n2. second\n3. third"
    ev = parse_repro_steps(text)
    assert len(ev.steps) == 3


def test_parse_repro_steps_ignores_unrelated_lines() -> None:
    text = textwrap.dedent("""
        Some context here.
        Steps to reproduce:
        1. first
        Some commentary
        2. second
        End of report.
    """).strip()
    ev = parse_repro_steps(text)
    # "Some commentary" and "End of report." don't match the step regex.
    assert len(ev.steps) == 2
    assert ev.steps[0].text == "first"
    assert ev.steps[1].text == "second"


def test_parse_repro_steps_empty_returns_empty() -> None:
    ev = parse_repro_steps("")
    assert ev.steps == []
