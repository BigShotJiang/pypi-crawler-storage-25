"""Tests for heap.spec.validator — mocked Gateway."""

from __future__ import annotations

import json
from unittest.mock import patch

from heap.gateway import Gateway, GatewayResponse
from heap.spec import StructuredSpec, ValidationFinding, ValidationReport, Validator

# ---------------------------------------------------------------------------
# helpers
# ---------------------------------------------------------------------------


def _gw_resp(payload: dict | str) -> GatewayResponse:
    content = payload if isinstance(payload, str) else json.dumps(payload)
    return GatewayResponse(
        content=content,
        model_used="t/p",
        tokens_in=200,
        tokens_out=80,
        cost_usd=0.0015,
        latency_ms=400.0,
    )


def _spec(facts: dict | None = None) -> StructuredSpec:
    return StructuredSpec(
        name="csv-bom",
        version=1,
        mode="bug",
        audience="developer",
        facts=facts or {"symptom": "zero rows", "expected": "all rows imported"},
        acceptance=["After fix: all rows imported"],
        created_at="2026-04-26T18:00:00Z",
    )


# ---------------------------------------------------------------------------
# happy path
# ---------------------------------------------------------------------------


def test_validate_returns_report_with_findings():
    gw = Gateway(planner="t/p", worker="t/w", fast="t/f")
    findings_payload = {
        "findings": [
            {
                "severity": "missing",
                "description": "No mention of which CSV parser is used.",
                "suggestion": "Specify whether csv stdlib or pandas.",
            },
            {
                "severity": "edge_case",
                "description": "What if the BOM appears mid-file?",
                "suggestion": None,
            },
        ]
    }

    with patch.object(gw, "call", return_value=_gw_resp(findings_payload)) as mock:
        report = Validator(gw).validate(_spec())

    assert isinstance(report, ValidationReport)
    assert report.spec_name == "csv-bom"
    assert report.spec_version == 1
    assert report.parse_failed is False
    assert len(report.findings) == 2
    assert all(isinstance(f, ValidationFinding) for f in report.findings)
    assert report.findings[0].severity == "missing"
    assert "csv parser" in report.findings[0].description.lower()
    assert report.findings[1].severity == "edge_case"
    assert report.findings[1].suggestion is None
    assert report.cost_usd == 0.0015
    # Planner role used
    assert mock.call_args.kwargs["role"] == "planner"
    # Spec content actually passed in
    user_msg = mock.call_args.kwargs["messages"][1]["content"]
    assert "csv-bom" in user_msg
    assert "zero rows" in user_msg


def test_validate_handles_empty_findings_list():
    """A clean spec → zero findings, parse_failed=False."""
    gw = Gateway(planner="t/p", worker="t/w", fast="t/f")

    with patch.object(gw, "call", return_value=_gw_resp({"findings": []})):
        report = Validator(gw).validate(_spec())

    assert report.findings == []
    assert report.parse_failed is False


# ---------------------------------------------------------------------------
# parsing edge cases
# ---------------------------------------------------------------------------


def test_validate_handles_markdown_fenced_json():
    gw = Gateway(planner="t/p", worker="t/w", fast="t/f")
    payload = {"findings": [{"severity": "ambiguous", "description": "what does 'rows' mean?"}]}
    fenced = "```json\n" + json.dumps(payload) + "\n```"

    with patch.object(gw, "call", return_value=_gw_resp(fenced)):
        report = Validator(gw).validate(_spec())

    assert report.parse_failed is False
    assert len(report.findings) == 1


def test_validate_handles_prose_with_embedded_json():
    gw = Gateway(planner="t/p", worker="t/w", fast="t/f")
    rambling = (
        "Sure, here's my review: "
        + json.dumps({"findings": [{"severity": "missing", "description": "no error log shown"}]})
        + " — hope that helps!"
    )

    with patch.object(gw, "call", return_value=_gw_resp(rambling)):
        report = Validator(gw).validate(_spec())

    assert len(report.findings) == 1
    assert report.findings[0].severity == "missing"


def test_validate_unparseable_response_returns_empty_with_parse_failed():
    gw = Gateway(planner="t/p", worker="t/w", fast="t/f")

    with patch.object(gw, "call", return_value=_gw_resp("definitely not json")):
        report = Validator(gw).validate(_spec())

    assert report.findings == []
    assert report.parse_failed is True
    assert report.raw_response == "definitely not json"


def test_validate_empty_response_returns_empty_with_parse_failed():
    gw = Gateway(planner="t/p", worker="t/w", fast="t/f")

    with patch.object(gw, "call", return_value=_gw_resp("")):
        report = Validator(gw).validate(_spec())

    assert report.findings == []
    assert report.parse_failed is True


# ---------------------------------------------------------------------------
# severity normalization
# ---------------------------------------------------------------------------


def test_unknown_severity_coerced_to_ambiguous():
    """If model invents a severity ('critical', 'warning'), don't drop the finding — coerce."""
    gw = Gateway(planner="t/p", worker="t/w", fast="t/f")
    payload = {
        "findings": [
            {"severity": "critical", "description": "the world is ending"},
            {"severity": "missing", "description": "valid one"},
        ]
    }

    with patch.object(gw, "call", return_value=_gw_resp(payload)):
        report = Validator(gw).validate(_spec())

    assert len(report.findings) == 2
    assert report.findings[0].severity == "ambiguous"  # coerced
    assert report.findings[0].description == "the world is ending"
    assert report.findings[1].severity == "missing"  # unchanged


def test_finding_without_description_is_skipped():
    gw = Gateway(planner="t/p", worker="t/w", fast="t/f")
    payload = {
        "findings": [
            {"severity": "missing"},  # no description, dropped
            {"severity": "missing", "description": "real one"},
        ]
    }

    with patch.object(gw, "call", return_value=_gw_resp(payload)):
        report = Validator(gw).validate(_spec())

    assert len(report.findings) == 1
    assert report.findings[0].description == "real one"


def test_findings_field_missing_or_wrong_type_returns_empty():
    """If the JSON parses but has no 'findings' list, return empty (not parse_failed)."""
    gw = Gateway(planner="t/p", worker="t/w", fast="t/f")

    with patch.object(gw, "call", return_value=_gw_resp({"other_key": "value"})):
        report = Validator(gw).validate(_spec())

    assert report.findings == []
    # parse_failed stays False — JSON was valid; just not the expected shape
    # we treat that as "no findings"
    assert report.parse_failed is False


def test_validator_passes_spec_yaml_to_planner():
    """The planner sees the spec rendered as YAML in the user prompt."""
    gw = Gateway(planner="t/p", worker="t/w", fast="t/f")

    with patch.object(gw, "call", return_value=_gw_resp({"findings": []})) as mock:
        Validator(gw).validate(_spec())

    user_content = mock.call_args.kwargs["messages"][1]["content"]
    # YAML formatting clues
    assert "yaml" in user_content.lower()
    assert "facts:" in user_content
    assert "expected: all rows imported" in user_content
