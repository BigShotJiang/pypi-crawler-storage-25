"""Tests for heap.spec.interrogator — mocked Gateway + prompter."""

from __future__ import annotations

import json
from typing import Any
from unittest.mock import patch

import pytest

from heap.gateway import Gateway, GatewayResponse
from heap.spec import Interrogator, InterrogatorOutcome

# ---------------------------------------------------------------------------
# helpers
# ---------------------------------------------------------------------------


def _gw_resp(payload: dict[str, Any] | str) -> GatewayResponse:
    """Build a GatewayResponse whose .content is the given payload as JSON."""
    content = payload if isinstance(payload, str) else json.dumps(payload)
    return GatewayResponse(
        content=content,
        model_used="t/p",
        tokens_in=80,
        tokens_out=40,
        cost_usd=0.0009,
        latency_ms=200.0,
    )


@pytest.fixture
def gw() -> Gateway:
    return Gateway(planner="t/p", worker="t/w", fast="t/f")


def _scripted_io():
    """Return (prompter, printer, captured_outputs, captured_prompts)."""
    captured_outputs: list[str] = []
    captured_prompts: list[str] = []

    inputs: list[str] = []

    def prompter(prompt: str) -> str:
        captured_prompts.append(prompt)
        if not inputs:
            return ""
        return inputs.pop(0)

    def printer(msg: str) -> None:
        captured_outputs.append(msg)

    return prompter, printer, captured_outputs, captured_prompts, inputs


# ---------------------------------------------------------------------------
# construction / validation
# ---------------------------------------------------------------------------


def test_rejects_unknown_mode(gw: Gateway) -> None:
    with pytest.raises(ValueError, match="unsupported mode"):
        Interrogator(mode="bogus", audience="developer", gateway=gw)  # type: ignore[arg-type]


def test_rejects_unknown_audience(gw: Gateway) -> None:
    with pytest.raises(ValueError, match="unsupported audience"):
        Interrogator(mode="bug", audience="alien", gateway=gw)  # type: ignore[arg-type]


def test_construction_with_supported_combo(gw: Gateway) -> None:
    Interrogator(mode="bug", audience="developer", gateway=gw)
    Interrogator(mode="feature", audience="non_technical", gateway=gw)
    Interrogator(mode="greenfield", audience="developer", gateway=gw)


# ---------------------------------------------------------------------------
# happy path: ask → ask → echo_back → finalize
# ---------------------------------------------------------------------------


def test_full_interrogation_flow(gw: Gateway) -> None:
    prompter, printer, outputs, _prompts, inputs = _scripted_io()
    inputs.extend(
        [
            "CSV import returns zero rows",
            "When I open the dashboard, it shows 'no data'",
            "yes confirmed",
        ]
    )

    model_turns = [
        _gw_resp({"action": "ask", "question": "What is the symptom?"}),
        _gw_resp({"action": "ask", "question": "When does it happen?"}),
        _gw_resp(
            {
                "action": "echo_back",
                "summary": (
                    "CSV imports of UTF-8 BOM files return zero rows; user "
                    "sees 'no data' on the dashboard."
                ),
            }
        ),
        _gw_resp(
            {
                "action": "finalize",
                "facts": {
                    "symptom": "CSV import returns zero rows",
                    "trigger": "opening the dashboard with a BOM file",
                    "expected": "rows imported",
                    "actual": "zero rows",
                },
            }
        ),
    ]

    interrogator = Interrogator(
        mode="bug",
        audience="developer",
        gateway=gw,
        prompter=prompter,
        printer=printer,
    )
    with patch.object(gw, "call", side_effect=model_turns):
        outcome = interrogator.interview()

    assert isinstance(outcome, InterrogatorOutcome)
    assert outcome.mode == "bug"
    assert outcome.audience == "developer"
    assert outcome.incomplete is False
    assert outcome.facts["symptom"] == "CSV import returns zero rows"
    assert outcome.turns_used == 4
    # Transcript: 2 ask Q+A pairs, 1 echo_back Q+A pair → 6 entries
    assert len(outcome.transcript) == 6
    assert outcome.transcript[0].role == "interrogator"
    assert outcome.transcript[1].role == "user"
    assert outcome.transcript[1].content == "CSV import returns zero rows"
    # Two questions printed; final 'finalizing' message printed
    joined = "\n".join(outputs)
    assert "What is the symptom?" in joined
    assert "When does it happen?" in joined
    assert "Got it" in joined  # finalizing message


# ---------------------------------------------------------------------------
# parsing edge cases
# ---------------------------------------------------------------------------


def test_handles_markdown_fenced_json(gw: Gateway) -> None:
    """Model wraps JSON in ```json ... ``` fences."""
    prompter, printer, _, _, inputs = _scripted_io()

    fenced = "```json\n" + json.dumps({"action": "finalize", "facts": {"x": 1}}) + "\n```"

    interrogator = Interrogator(
        mode="bug",
        audience="developer",
        gateway=gw,
        prompter=prompter,
        printer=printer,
    )
    with patch.object(gw, "call", return_value=_gw_resp(fenced)):
        outcome = interrogator.interview()

    assert outcome.facts == {"x": 1}
    assert outcome.incomplete is False


def test_handles_prose_with_embedded_json(gw: Gateway) -> None:
    """Model rambles before the JSON; parser should still find it."""
    prompter, printer, _, _, _inputs = _scripted_io()

    rambling = (
        "Sure, here's the action: "
        + json.dumps({"action": "finalize", "facts": {"y": "ok"}})
        + " — done."
    )

    interrogator = Interrogator(
        mode="feature",
        audience="non_technical",
        gateway=gw,
        prompter=prompter,
        printer=printer,
    )
    with patch.object(gw, "call", return_value=_gw_resp(rambling)):
        outcome = interrogator.interview()

    assert outcome.facts == {"y": "ok"}


def test_unparseable_model_output_finalizes_incomplete(gw: Gateway) -> None:
    """Garbage from model → loop terminates with incomplete=True."""
    prompter, printer, _, _, _inputs = _scripted_io()

    interrogator = Interrogator(
        mode="bug",
        audience="developer",
        gateway=gw,
        prompter=prompter,
        printer=printer,
    )
    with patch.object(gw, "call", return_value=_gw_resp("definitely not json")):
        outcome = interrogator.interview()

    assert outcome.incomplete is True
    assert "unknown action" in (outcome.incomplete_reason or "")


def test_finalize_with_non_dict_facts_normalizes(gw: Gateway) -> None:
    """If model returns facts as a non-dict, wrap it under 'raw' key."""
    prompter, printer, _, _, _inputs = _scripted_io()

    interrogator = Interrogator(
        mode="bug",
        audience="developer",
        gateway=gw,
        prompter=prompter,
        printer=printer,
    )
    weird = _gw_resp({"action": "finalize", "facts": "should be a dict"})
    with patch.object(gw, "call", return_value=weird):
        outcome = interrogator.interview()

    assert outcome.incomplete is False
    assert "raw" in outcome.facts


# ---------------------------------------------------------------------------
# safety: max_turns cap
# ---------------------------------------------------------------------------


def test_max_turns_caps_runaway_loop(gw: Gateway) -> None:
    """Model that keeps asking forever is bounded by max_turns."""
    prompter, printer, _, _, inputs = _scripted_io()
    inputs.extend(["a"] * 50)  # plenty of canned answers

    interrogator = Interrogator(
        mode="bug",
        audience="developer",
        gateway=gw,
        prompter=prompter,
        printer=printer,
        max_turns=3,
    )
    with patch.object(
        gw,
        "call",
        return_value=_gw_resp({"action": "ask", "question": "more?"}),
    ):
        outcome = interrogator.interview()

    assert outcome.incomplete is True
    assert "max_turns" in (outcome.incomplete_reason or "")
    assert outcome.turns_used == 3


# ---------------------------------------------------------------------------
# prompt parameterization
# ---------------------------------------------------------------------------


def test_system_prompt_includes_mode_and_audience(gw: Gateway) -> None:
    """The first model call's system prompt should reflect mode + audience."""
    prompter, printer, _, _, _inputs = _scripted_io()

    interrogator = Interrogator(
        mode="greenfield",
        audience="non_technical",
        gateway=gw,
        prompter=prompter,
        printer=printer,
    )
    with patch.object(
        gw,
        "call",
        return_value=_gw_resp({"action": "finalize", "facts": {}}),
    ) as mock:
        interrogator.interview()

    sys_msg = mock.call_args.kwargs["messages"][0]
    assert sys_msg["role"] == "system"
    assert "MODE: greenfield" in sys_msg["content"]
    assert "AUDIENCE: non_technical" in sys_msg["content"]
    assert "everyday language" in sys_msg["content"]
