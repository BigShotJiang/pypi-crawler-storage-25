"""Tests for heap.cli — Click CliRunner; mocked Gateway for `new`/`amend`."""

from __future__ import annotations

import json
from unittest.mock import patch

import pytest
import yaml
from click.testing import CliRunner

from heap import __version__
from heap.cli import main
from heap.gateway import GatewayResponse

# ---------------------------------------------------------------------------
# helpers
# ---------------------------------------------------------------------------


def _gw_resp(payload, tokens_in=20, tokens_out=10, cost=0.0001):
    content = payload if isinstance(payload, str) else json.dumps(payload)
    return GatewayResponse(
        content=content,
        model_used="t/p",
        tokens_in=tokens_in,
        tokens_out=tokens_out,
        cost_usd=cost,
        latency_ms=80.0,
    )


@pytest.fixture
def runner() -> CliRunner:
    return CliRunner()


# ---------------------------------------------------------------------------
# top-level
# ---------------------------------------------------------------------------


def test_main_help_shows_subcommands(runner: CliRunner) -> None:
    result = runner.invoke(main, ["--help"])
    assert result.exit_code == 0
    assert "spec" in result.output


def test_version_option(runner: CliRunner) -> None:
    result = runner.invoke(main, ["--version"])
    assert result.exit_code == 0
    assert __version__ in result.output


def test_spec_help_shows_subcommands(runner: CliRunner) -> None:
    result = runner.invoke(main, ["spec", "--help"])
    assert result.exit_code == 0
    for cmd in ("new", "show", "list", "amend"):
        assert cmd in result.output


# ---------------------------------------------------------------------------
# `heap spec list`
# ---------------------------------------------------------------------------


def test_list_empty_dir(runner: CliRunner, tmp_path) -> None:
    result = runner.invoke(main, ["spec", "list", "--specs-dir", str(tmp_path)])
    assert result.exit_code == 0
    assert "no specs" in result.output


def test_list_with_specs(runner: CliRunner, tmp_path) -> None:
    # Pre-create canonical spec files
    (tmp_path / "alpha.spec.yaml").write_text("name: alpha\nversion: 1\n")
    (tmp_path / "alpha.spec.v1.yaml").write_text("name: alpha\nversion: 1\n")
    (tmp_path / "beta.spec.yaml").write_text("name: beta\nversion: 2\n")
    (tmp_path / "beta.spec.v1.yaml").write_text("name: beta\nversion: 1\n")
    (tmp_path / "beta.spec.v2.yaml").write_text("name: beta\nversion: 2\n")

    result = runner.invoke(main, ["spec", "list", "--specs-dir", str(tmp_path)])
    assert result.exit_code == 0
    assert "alpha" in result.output
    assert "beta" in result.output
    assert "v1" in result.output
    assert "v2" in result.output


# ---------------------------------------------------------------------------
# `heap spec show`
# ---------------------------------------------------------------------------


def test_show_missing_exits_nonzero(runner: CliRunner, tmp_path) -> None:
    result = runner.invoke(main, ["spec", "show", "ghost", "--specs-dir", str(tmp_path)])
    assert result.exit_code == 1
    assert "not found" in result.output


def test_show_existing_spec_prints_yaml(runner: CliRunner, tmp_path) -> None:
    spec_data = {
        "name": "csv-bom",
        "version": 1,
        "mode": "bug",
        "audience": "developer",
        "facts": {"symptom": "zero rows"},
        "evidence": [],
        "acceptance": ["After fix: rows imported"],
        "transcript_summary": "",
        "created_at": "2026-04-26T18:00:00Z",
    }
    (tmp_path / "csv-bom.spec.yaml").write_text(yaml.safe_dump(spec_data))

    result = runner.invoke(main, ["spec", "show", "csv-bom", "--specs-dir", str(tmp_path)])
    assert result.exit_code == 0
    assert "csv-bom" in result.output
    assert "symptom: zero rows" in result.output


def test_show_specific_version(runner: CliRunner, tmp_path) -> None:
    v1 = {
        "name": "x",
        "version": 1,
        "mode": "bug",
        "audience": "developer",
        "facts": {"k": "v1"},
        "evidence": [],
        "acceptance": [],
        "transcript_summary": "",
        "created_at": "2026-04-26T00:00:00Z",
    }
    v2 = {**v1, "version": 2, "facts": {"k": "v2"}}
    (tmp_path / "x.spec.yaml").write_text(yaml.safe_dump(v2))
    (tmp_path / "x.spec.v1.yaml").write_text(yaml.safe_dump(v1))
    (tmp_path / "x.spec.v2.yaml").write_text(yaml.safe_dump(v2))

    result = runner.invoke(
        main, ["spec", "show", "x", "--version", "1", "--specs-dir", str(tmp_path)]
    )
    assert result.exit_code == 0
    assert "k: v1" in result.output


# ---------------------------------------------------------------------------
# `heap spec new`
# ---------------------------------------------------------------------------


def test_new_without_api_key_errors(runner: CliRunner, tmp_path) -> None:
    """No ANTHROPIC_API_KEY → exit 1 with helpful message."""
    result = runner.invoke(
        main,
        [
            "spec",
            "new",
            "--mode",
            "bug",
            "--audience",
            "developer",
            "--name",
            "x",
            "--specs-dir",
            str(tmp_path),
        ],
        env={"ANTHROPIC_API_KEY": ""},  # cleared
    )
    assert result.exit_code == 1
    assert "ANTHROPIC_API_KEY" in result.output


def test_new_with_invalid_mode_errors(runner: CliRunner, tmp_path) -> None:
    result = runner.invoke(
        main,
        ["spec", "new", "--mode", "bogus", "--specs-dir", str(tmp_path)],
    )
    assert result.exit_code != 0
    assert "Invalid value" in result.output or "bogus" in result.output


def test_new_writes_artifacts_with_mocked_gateway(runner: CliRunner, tmp_path) -> None:
    """End-to-end-ish: real CLI parsing, mocked Gateway, real Structurer.

    The interrogator finalizes immediately (single turn). The validator
    (on by default) returns zero findings. We patch litellm.completion
    at the Gateway boundary so all of Gateway / Interrogator / Structurer
    / Validator run for real.
    """
    with (
        patch("heap.gateway.litellm.completion") as mock_lit,
        patch("heap.gateway.litellm.completion_cost", return_value=0.0001),
    ):
        # Provide raw OpenAI-shape responses; gateway normalizes them.
        from types import SimpleNamespace

        def fake_completion(**kwargs):
            # Decide which canned response to return based on the system prompt
            sys_msg = next(
                (m for m in kwargs.get("messages", []) if m["role"] == "system"),
                {"content": ""},
            )
            target = "validator" if "adversarial" in sys_msg["content"].lower() else "interrogator"
            payload = (
                json.dumps({"findings": []})
                if target == "validator"
                else json.dumps(
                    {
                        "action": "finalize",
                        "facts": {"symptom": "zero rows", "expected": "rows imported"},
                    }
                )
            )
            msg = SimpleNamespace(content=payload, tool_calls=None)
            return SimpleNamespace(
                choices=[SimpleNamespace(message=msg)],
                usage=SimpleNamespace(prompt_tokens=20, completion_tokens=10),
            )

        mock_lit.side_effect = fake_completion

        result = runner.invoke(
            main,
            [
                "spec",
                "new",
                "--mode",
                "bug",
                "--audience",
                "developer",
                "--name",
                "csv-bom",
                "--specs-dir",
                str(tmp_path),
            ],
            env={"ANTHROPIC_API_KEY": "fake-key"},
        )

    assert result.exit_code == 0, result.output
    assert (tmp_path / "csv-bom.spec.yaml").exists()
    assert (tmp_path / "csv-bom.spec.v1.yaml").exists()
    assert (tmp_path / "csv-bom.spec.md").exists()
    assert (tmp_path / "csv-bom.acceptance.json").exists()
    assert "Wrote artifacts" in result.output


def test_new_invalid_name_rejected(runner: CliRunner, tmp_path) -> None:
    """Slashes / dots / etc. in name should be rejected by the structurer."""
    finalize_payload = json.dumps({"action": "finalize", "facts": {}})

    with (
        patch("heap.gateway.litellm.completion") as mock_lit,
        patch("heap.gateway.litellm.completion_cost", return_value=0.0),
    ):
        from types import SimpleNamespace

        msg = SimpleNamespace(content=finalize_payload, tool_calls=None)
        mock_lit.return_value = SimpleNamespace(
            choices=[SimpleNamespace(message=msg)],
            usage=SimpleNamespace(prompt_tokens=10, completion_tokens=5),
        )
        result = runner.invoke(
            main,
            [
                "spec",
                "new",
                "--mode",
                "bug",
                "--name",
                "bad/name",
                "--specs-dir",
                str(tmp_path),
                "--no-validate",
            ],
            env={"ANTHROPIC_API_KEY": "fake-key"},
        )

    assert result.exit_code != 0


# ---------------------------------------------------------------------------
# `heap spec amend`
# ---------------------------------------------------------------------------


def test_amend_missing_spec_errors(runner: CliRunner, tmp_path) -> None:
    result = runner.invoke(
        main,
        ["spec", "amend", "ghost", "--specs-dir", str(tmp_path)],
        env={"ANTHROPIC_API_KEY": "fake-key"},
    )
    assert result.exit_code == 1
    assert "not found" in result.output


def test_amend_existing_bumps_version(runner: CliRunner, tmp_path) -> None:
    # Pre-create a v1 spec
    spec_data = {
        "name": "csv-bom",
        "version": 1,
        "mode": "bug",
        "audience": "developer",
        "facts": {"symptom": "zero rows"},
        "evidence": [],
        "acceptance": [],
        "transcript_summary": "",
        "created_at": "2026-04-26T18:00:00Z",
    }
    (tmp_path / "csv-bom.spec.yaml").write_text(yaml.safe_dump(spec_data))
    (tmp_path / "csv-bom.spec.v1.yaml").write_text(yaml.safe_dump(spec_data))

    finalize_payload = json.dumps(
        {"action": "finalize", "facts": {"symptom": "zero rows", "expected": "rows imported"}}
    )
    with (
        patch("heap.gateway.litellm.completion") as mock_lit,
        patch("heap.gateway.litellm.completion_cost", return_value=0.0),
    ):
        from types import SimpleNamespace

        msg = SimpleNamespace(content=finalize_payload, tool_calls=None)
        mock_lit.return_value = SimpleNamespace(
            choices=[SimpleNamespace(message=msg)],
            usage=SimpleNamespace(prompt_tokens=10, completion_tokens=5),
        )
        result = runner.invoke(
            main,
            ["spec", "amend", "csv-bom", "--specs-dir", str(tmp_path)],
            env={"ANTHROPIC_API_KEY": "fake-key"},
        )

    assert result.exit_code == 0, result.output
    assert (tmp_path / "csv-bom.spec.v2.yaml").exists()
    assert "v2" in result.output


# ---------------------------------------------------------------------------
# `heap scenarios` — helpers
# ---------------------------------------------------------------------------


def _seed_spec(specs_dir, *, name="csv-bom", acceptance=None):
    """Write a minimal canonical spec.yaml so subcommands can read it."""
    if acceptance is None:
        acceptance = [
            "After fix: all rows imported",
            "After fix: no warnings on UTF-8 BOM files",
        ]
    data = {
        "name": name,
        "version": 1,
        "mode": "bug",
        "audience": "developer",
        "facts": {"symptom": "zero rows", "expected": "all rows imported"},
        "evidence": [],
        "acceptance": acceptance,
        "transcript_summary": "",
        "created_at": "2026-04-26T18:00:00Z",
    }
    text = yaml.safe_dump(data)
    (specs_dir / f"{name}.spec.yaml").write_text(text)
    (specs_dir / f"{name}.spec.v1.yaml").write_text(text)
    return data


def _seed_scenarios(specs_dir, *, name="csv-bom", scenarios=None, approved_at=None):
    """Write a minimal scenarios.yaml file."""
    if scenarios is None:
        scenarios = [
            {
                "id": "T1",
                "title": "All rows imported",
                "given": ["a CSV with 3 rows"],
                "when": ["the importer runs"],
                "then": ["all 3 rows are loaded"],
                "acceptance_ref": 0,
                "source": "spec",
                "confidence": "high",
                "note": None,
            },
            {
                "id": "T2",
                "title": "No BOM warning",
                "given": ["a CSV with a UTF-8 BOM"],
                "when": ["the importer runs"],
                "then": ["no warning is logged"],
                "acceptance_ref": 1,
                "source": "spec",
                "confidence": "medium",
                "note": None,
            },
        ]
    data = {
        "spec_name": name,
        "spec_version": 1,
        "scenarios": scenarios,
        "generated_by": "t/p",
        "generated_at": "2026-04-26T19:00:00Z",
        "cost_usd": 0.001,
        "approved_at": approved_at,
        "approved_by": "",
        "deletions": [],
    }
    (specs_dir / f"{name}.scenarios.yaml").write_text(yaml.safe_dump(data))
    return data


# ---------------------------------------------------------------------------
# `heap scenarios` — top-level
# ---------------------------------------------------------------------------


def test_scenarios_help_lists_subcommands(runner: CliRunner) -> None:
    result = runner.invoke(main, ["scenarios", "--help"])
    assert result.exit_code == 0
    for cmd in ("generate", "show", "review"):
        assert cmd in result.output


# ---------------------------------------------------------------------------
# `heap scenarios generate`
# ---------------------------------------------------------------------------


def test_scenarios_generate_missing_spec_errors(runner: CliRunner, tmp_path) -> None:
    result = runner.invoke(
        main,
        ["scenarios", "generate", "ghost", "--specs-dir", str(tmp_path)],
    )
    assert result.exit_code == 1
    assert "not found" in result.output


def test_scenarios_generate_writes_yaml(runner: CliRunner, tmp_path) -> None:
    _seed_spec(tmp_path)
    payload = {
        "scenarios": [
            {
                "title": "All rows imported",
                "given": ["BOM file"],
                "when": ["import runs"],
                "then": ["all rows present"],
                "acceptance_ref": 0,
                "confidence": "high",
            },
            {
                "title": "No BOM warning",
                "given": ["BOM file"],
                "when": ["import runs"],
                "then": ["no warning logged"],
                "acceptance_ref": 1,
                "confidence": "high",
            },
        ]
    }

    with patch("heap.cli.Generator.generate") as mock_gen:
        mock_gen.return_value = ScenarioSet.model_validate(
            {
                "spec_name": "csv-bom",
                "spec_version": 1,
                "scenarios": [
                    {
                        "id": f"T{i + 1}",
                        "title": s["title"],
                        "given": s["given"],
                        "when": s["when"],
                        "then": s["then"],
                        "acceptance_ref": s["acceptance_ref"],
                        "source": "spec",
                        "confidence": "high",
                    }
                    for i, s in enumerate(payload["scenarios"])
                ],
                "generated_by": "t/p",
                "generated_at": "2026-04-26T19:00:00Z",
                "cost_usd": 0.005,
            }
        )
        with patch("heap.cli.Generator.detect_gaps", return_value=[]):
            result = runner.invoke(
                main,
                [
                    "scenarios",
                    "generate",
                    "csv-bom",
                    "--specs-dir",
                    str(tmp_path),
                    "--no-detect-gaps",
                ],
                env={"ANTHROPIC_API_KEY": "fake-key"},
            )

    assert result.exit_code == 0, result.output
    out_path = tmp_path / "csv-bom.scenarios.yaml"
    assert out_path.exists()
    loaded = yaml.safe_load(out_path.read_text())
    assert loaded["spec_name"] == "csv-bom"
    assert len(loaded["scenarios"]) == 2
    assert "Wrote" in result.output


def test_scenarios_generate_with_gaps(runner: CliRunner, tmp_path) -> None:
    _seed_spec(tmp_path)
    base = ScenarioSet(
        spec_name="csv-bom",
        spec_version=1,
        scenarios=[Scenario(id="T1", title="t1", acceptance_ref=0, source="spec")],
        generated_by="t/p",
        generated_at="2026-04-26T19:00:00Z",
        cost_usd=0.001,
    )
    gap = Scenario(id="G2", title="Empty CSV", source="gap", note="not in spec", confidence="low")

    with (
        patch("heap.cli.Generator.generate", return_value=base),
        patch("heap.cli.Generator.detect_gaps", return_value=[gap]),
    ):
        result = runner.invoke(
            main,
            ["scenarios", "generate", "csv-bom", "--specs-dir", str(tmp_path)],
            env={"ANTHROPIC_API_KEY": "fake-key"},
        )

    assert result.exit_code == 0, result.output
    loaded = yaml.safe_load((tmp_path / "csv-bom.scenarios.yaml").read_text())
    assert len(loaded["scenarios"]) == 2
    assert loaded["scenarios"][1]["source"] == "gap"
    assert "added 1 gap" in result.output


def test_scenarios_generate_without_api_key(runner: CliRunner, tmp_path) -> None:
    _seed_spec(tmp_path)
    result = runner.invoke(
        main,
        ["scenarios", "generate", "csv-bom", "--specs-dir", str(tmp_path)],
        env={"ANTHROPIC_API_KEY": ""},
    )
    assert result.exit_code == 1
    assert "ANTHROPIC_API_KEY" in result.output


# ---------------------------------------------------------------------------
# `heap scenarios show`
# ---------------------------------------------------------------------------


def test_scenarios_show_renders_text(runner: CliRunner, tmp_path) -> None:
    _seed_scenarios(tmp_path)
    result = runner.invoke(
        main,
        ["scenarios", "show", "csv-bom", "--specs-dir", str(tmp_path)],
    )
    assert result.exit_code == 0
    assert "[✓] T1" in result.output
    assert "All rows imported" in result.output
    assert "Approved" not in result.output  # not approved


def test_scenarios_show_marks_approved(runner: CliRunner, tmp_path) -> None:
    _seed_scenarios(tmp_path, approved_at="2026-04-26T20:00:00Z")
    result = runner.invoke(
        main,
        ["scenarios", "show", "csv-bom", "--specs-dir", str(tmp_path)],
    )
    assert result.exit_code == 0
    assert "Approved at 2026-04-26T20:00:00Z" in result.output


def test_scenarios_show_missing_errors(runner: CliRunner, tmp_path) -> None:
    result = runner.invoke(
        main,
        ["scenarios", "show", "ghost", "--specs-dir", str(tmp_path)],
    )
    assert result.exit_code == 1
    assert "No scenarios" in result.output


# ---------------------------------------------------------------------------
# `heap scenarios review`
# ---------------------------------------------------------------------------


def test_scenarios_review_approve_writes_approved_at(runner: CliRunner, tmp_path) -> None:
    _seed_spec(tmp_path)
    _seed_scenarios(tmp_path)

    result = runner.invoke(
        main,
        ["scenarios", "review", "csv-bom", "--specs-dir", str(tmp_path)],
        input="a\n",
    )

    assert result.exit_code == 0, result.output
    loaded = yaml.safe_load((tmp_path / "csv-bom.scenarios.yaml").read_text())
    assert loaded["approved_at"] is not None
    assert "Approved" in result.output


def test_scenarios_review_quit_does_not_save(runner: CliRunner, tmp_path) -> None:
    _seed_spec(tmp_path)
    _seed_scenarios(tmp_path)
    before = (tmp_path / "csv-bom.scenarios.yaml").read_text()

    result = runner.invoke(
        main,
        ["scenarios", "review", "csv-bom", "--specs-dir", str(tmp_path)],
        input="q\n",
    )

    assert result.exit_code == 0
    after = (tmp_path / "csv-bom.scenarios.yaml").read_text()
    assert before == after  # untouched
    assert "cancelled" in result.output.lower()


def test_scenarios_review_delete_records_deletion(runner: CliRunner, tmp_path) -> None:
    _seed_spec(tmp_path)
    _seed_scenarios(tmp_path)

    # `d T1` then prompt for reason → "stale" → then approve
    result = runner.invoke(
        main,
        ["scenarios", "review", "csv-bom", "--specs-dir", str(tmp_path)],
        input="d T1\nstale scenario\na\n",
    )

    assert result.exit_code == 0, result.output
    loaded = yaml.safe_load((tmp_path / "csv-bom.scenarios.yaml").read_text())
    ids = [s["id"] for s in loaded["scenarios"]]
    assert "T1" not in ids
    assert "T2" in ids
    assert len(loaded["deletions"]) == 1
    assert loaded["deletions"][0]["id"] == "T1"
    assert loaded["deletions"][0]["reason"] == "stale scenario"


def test_scenarios_review_delete_unknown_id(runner: CliRunner, tmp_path) -> None:
    _seed_spec(tmp_path)
    _seed_scenarios(tmp_path)

    result = runner.invoke(
        main,
        ["scenarios", "review", "csv-bom", "--specs-dir", str(tmp_path)],
        input="d ZZZ\nq\n",
    )

    assert result.exit_code == 0
    assert "no scenario with id 'ZZZ'" in result.output


def test_scenarios_review_add_appends_manual(runner: CliRunner, tmp_path) -> None:
    _seed_spec(tmp_path)
    _seed_scenarios(tmp_path)

    # `+` → prompts: title, given, when, then (each list ended by blank line) → approve
    user_input = "\n".join(
        [
            "+",  # action
            "Edge: no rows",  # title
            "the file is empty",  # given line 1
            "",  # given done
            "the importer runs",  # when line 1
            "",  # when done
            "an empty-state message is logged",  # then line 1
            "",  # then done
            "a",  # approve
        ]
    )

    result = runner.invoke(
        main,
        ["scenarios", "review", "csv-bom", "--specs-dir", str(tmp_path)],
        input=user_input + "\n",
        env={"ANTHROPIC_API_KEY": ""},  # force the "amendment unavailable" path
    )

    assert result.exit_code == 0, result.output
    loaded = yaml.safe_load((tmp_path / "csv-bom.scenarios.yaml").read_text())
    manuals = [s for s in loaded["scenarios"] if s["source"] == "manual"]
    assert len(manuals) == 1
    assert manuals[0]["title"] == "Edge: no rows"
    assert manuals[0]["id"] == "M1"
    assert manuals[0]["given"] == ["the file is empty"]
    assert manuals[0]["then"] == ["an empty-state message is logged"]
    # Without an API key the amendment offer is unavailable.
    assert "spec amendment offer requires gateway" in result.output


def test_scenarios_review_edit_updates_title(runner: CliRunner, tmp_path) -> None:
    _seed_spec(tmp_path)
    _seed_scenarios(tmp_path)

    # `e T1` → prompts: Title (use new) → Replace given/when/then? n → approve
    user_input = "\n".join(["e T1", "Renamed scenario", "n", "a"])

    result = runner.invoke(
        main,
        ["scenarios", "review", "csv-bom", "--specs-dir", str(tmp_path)],
        input=user_input + "\n",
    )

    assert result.exit_code == 0, result.output
    loaded = yaml.safe_load((tmp_path / "csv-bom.scenarios.yaml").read_text())
    t1 = next(s for s in loaded["scenarios"] if s["id"] == "T1")
    assert t1["title"] == "Renamed scenario"
    # given/when/then untouched
    assert t1["given"] == ["a CSV with 3 rows"]


def test_scenarios_review_regenerate_keeps_manual_and_gap(runner: CliRunner, tmp_path) -> None:
    _seed_spec(tmp_path)
    # Pre-existing set has a gap and a manual scenario alongside the spec ones
    _seed_scenarios(
        tmp_path,
        scenarios=[
            {
                "id": "T1",
                "title": "old spec one",
                "given": [],
                "when": [],
                "then": [],
                "acceptance_ref": 0,
                "source": "spec",
                "confidence": "high",
                "note": None,
            },
            {
                "id": "G2",
                "title": "old gap",
                "given": [],
                "when": [],
                "then": [],
                "acceptance_ref": None,
                "source": "gap",
                "confidence": "medium",
                "note": "from previous pass",
            },
            {
                "id": "M3",
                "title": "user-added",
                "given": [],
                "when": [],
                "then": [],
                "acceptance_ref": None,
                "source": "manual",
                "confidence": "medium",
                "note": None,
            },
        ],
    )

    fresh = ScenarioSet(
        spec_name="csv-bom",
        spec_version=1,
        scenarios=[
            Scenario(id="T1", title="fresh spec A", acceptance_ref=0, source="spec"),
            Scenario(id="T2", title="fresh spec B", acceptance_ref=1, source="spec"),
        ],
        generated_by="t/p",
        generated_at="2026-04-26T20:30:00Z",
        cost_usd=0.002,
    )

    with patch("heap.cli.Generator.generate", return_value=fresh):
        result = runner.invoke(
            main,
            ["scenarios", "review", "csv-bom", "--specs-dir", str(tmp_path)],
            input="r\n\na\n",  # regenerate, blank notes, approve
            env={"ANTHROPIC_API_KEY": "fake-key"},
        )

    assert result.exit_code == 0, result.output
    loaded = yaml.safe_load((tmp_path / "csv-bom.scenarios.yaml").read_text())
    titles = [s["title"] for s in loaded["scenarios"]]
    assert "fresh spec A" in titles
    assert "fresh spec B" in titles
    assert "old gap" in titles  # gap preserved
    assert "user-added" in titles  # manual preserved
    assert "old spec one" not in titles  # old spec dropped


def test_scenarios_review_discuss_calls_planner(runner: CliRunner, tmp_path) -> None:
    _seed_spec(tmp_path)
    _seed_scenarios(tmp_path)

    fake_resp = GatewayResponse(
        content="The 'when' could be tightened — consider naming the importer.",
        model_used="t/p",
        tokens_in=120,
        tokens_out=40,
        cost_usd=0.0008,
        latency_ms=300.0,
    )

    with patch("heap.gateway.Gateway.call", return_value=fake_resp) as mock_call:
        result = runner.invoke(
            main,
            ["scenarios", "review", "csv-bom", "--specs-dir", str(tmp_path)],
            input="? T1\nIs the When line specific enough?\nq\n",
            env={"ANTHROPIC_API_KEY": "fake-key"},
        )

    assert result.exit_code == 0, result.output
    assert "could be tightened" in result.output
    assert mock_call.call_args.kwargs["role"] == "planner"


def test_scenarios_review_unknown_action(runner: CliRunner, tmp_path) -> None:
    _seed_spec(tmp_path)
    _seed_scenarios(tmp_path)

    result = runner.invoke(
        main,
        ["scenarios", "review", "csv-bom", "--specs-dir", str(tmp_path)],
        input="zzz\nq\n",
    )

    assert result.exit_code == 0
    assert "unknown action" in result.output


def test_scenarios_review_missing_file(runner: CliRunner, tmp_path) -> None:
    _seed_spec(tmp_path)  # spec exists, scenarios don't
    result = runner.invoke(
        main,
        ["scenarios", "review", "csv-bom", "--specs-dir", str(tmp_path)],
    )
    assert result.exit_code == 1
    assert "No scenarios" in result.output


# ---------------------------------------------------------------------------
# `heap scenarios review` — S4.P3 spec-amendment flow
# ---------------------------------------------------------------------------


def test_scenarios_review_add_with_amendment_bumps_spec(runner: CliRunner, tmp_path) -> None:
    """Add a manual scenario AND promote it to a spec acceptance criterion.

    Patches:
      - propose_acceptance to return a deterministic draft
      - litellm.completion (so even if anything else calls it, no network)
    """
    _seed_spec(tmp_path)  # v1 with 2 acceptance criteria
    _seed_scenarios(tmp_path)

    # Confirm v1 starts with 2 criteria
    v1 = yaml.safe_load((tmp_path / "csv-bom.spec.yaml").read_text())
    assert len(v1["acceptance"]) == 2

    user_input = "\n".join(
        [
            "+",  # action
            "Edge: empty file",  # title
            "the file is empty",  # given
            "",
            "the importer runs",  # when
            "",
            "an empty-state message is logged",  # then
            "",
            "y",  # promote to acceptance criterion
            "",  # accept the drafted criterion (default)
            "a",  # approve
        ]
    )

    with (
        patch(
            "heap.cli.propose_acceptance",
            return_value="After fix: empty CSV files log an empty-state message",
        ),
        patch("heap.gateway.litellm.completion") as mock_lit,
    ):
        # Belt-and-braces: if anything else hits litellm, return harmless content.
        from types import SimpleNamespace

        msg = SimpleNamespace(content="{}", tool_calls=None)
        mock_lit.return_value = SimpleNamespace(
            choices=[SimpleNamespace(message=msg)],
            usage=SimpleNamespace(prompt_tokens=5, completion_tokens=5),
        )
        result = runner.invoke(
            main,
            ["scenarios", "review", "csv-bom", "--specs-dir", str(tmp_path)],
            input=user_input + "\n",
            env={"ANTHROPIC_API_KEY": "fake-key"},
        )

    assert result.exit_code == 0, result.output

    # Spec bumped to v2 with the new criterion appended
    assert (tmp_path / "csv-bom.spec.v2.yaml").exists()
    v2 = yaml.safe_load((tmp_path / "csv-bom.spec.yaml").read_text())
    assert v2["version"] == 2
    assert len(v2["acceptance"]) == 3
    assert v2["acceptance"][-1] == "After fix: empty CSV files log an empty-state message"

    # acceptance.json refreshed
    accept = json.loads((tmp_path / "csv-bom.acceptance.json").read_text())
    assert accept[-1] == "After fix: empty CSV files log an empty-state message"

    # Scenario references the new criterion (index 2)
    loaded = yaml.safe_load((tmp_path / "csv-bom.scenarios.yaml").read_text())
    manuals = [s for s in loaded["scenarios"] if s["source"] == "manual"]
    assert len(manuals) == 1
    assert manuals[0]["acceptance_ref"] == 2
    # ScenarioSet's spec_version updated
    assert loaded["spec_version"] == 2

    # User-facing confirmation
    assert "bumped to v2" in result.output


def test_scenarios_review_add_decline_amendment_does_not_bump(runner: CliRunner, tmp_path) -> None:
    """User adds scenario but says 'n' → spec stays at v1."""
    _seed_spec(tmp_path)
    _seed_scenarios(tmp_path)

    user_input = "\n".join(
        [
            "+",
            "Edge: empty file",
            "g",
            "",
            "w",
            "",
            "t",
            "",
            "n",  # decline promotion
            "a",  # approve
        ]
    )

    result = runner.invoke(
        main,
        ["scenarios", "review", "csv-bom", "--specs-dir", str(tmp_path)],
        input=user_input + "\n",
        env={"ANTHROPIC_API_KEY": "fake-key"},
    )

    assert result.exit_code == 0, result.output
    assert not (tmp_path / "csv-bom.spec.v2.yaml").exists()
    v1 = yaml.safe_load((tmp_path / "csv-bom.spec.yaml").read_text())
    assert v1["version"] == 1
    assert len(v1["acceptance"]) == 2  # unchanged


def test_scenarios_review_add_amendment_user_edits_draft(runner: CliRunner, tmp_path) -> None:
    """User accepts promotion but edits the draft criterion before applying."""
    _seed_spec(tmp_path)
    _seed_scenarios(tmp_path)

    user_input = "\n".join(
        [
            "+",
            "Edge: empty file",
            "",  # no given
            "",  # no when
            "the empty-state shows",  # one then line
            "",
            "y",  # promote
            "After fix: handle empty input gracefully",  # custom criterion
            "a",  # approve
        ]
    )

    with patch("heap.cli.propose_acceptance", return_value="DRAFT (will be overridden)"):
        result = runner.invoke(
            main,
            ["scenarios", "review", "csv-bom", "--specs-dir", str(tmp_path)],
            input=user_input + "\n",
            env={"ANTHROPIC_API_KEY": "fake-key"},
        )

    assert result.exit_code == 0, result.output
    v2 = yaml.safe_load((tmp_path / "csv-bom.spec.yaml").read_text())
    assert v2["acceptance"][-1] == "After fix: handle empty input gracefully"


# ---------------------------------------------------------------------------
# `heap plan` subgroup — S5.P2
# ---------------------------------------------------------------------------


def _seed_plan_yaml(specs_dir, *, name="csv-bom"):
    """Write a deterministic plan.yaml directly (no model call)."""
    data = {
        "plan_id": f"{name}-v1-20260426230000",
        "spec_name": name,
        "spec_version": 1,
        "spec_ref": f"{name} v1",
        "sprints": [
            {
                "id": "S1",
                "name": "Foundation",
                "goal": "stand up",
                "gate": "tests pass",
                "phases": [
                    {
                        "id": "S1.P1",
                        "name": "Skeleton",
                        "agent": "worker/Sonnet",
                        "deliverables": ["pyproject.toml"],
                        "tests": ["import works"],
                        "gate": "make install",
                        "cost_estimate_usd": 0.0,
                        "duration_estimate_min": 0,
                    }
                ],
                "cost_estimate_usd": 1.0,
                "duration_estimate_min": 30,
            }
        ],
        "risk_register": [
            {"description": "encoding", "severity": "medium", "mitigation": "utf-8-sig"}
        ],
        "scope_in": ["fix BOM"],
        "scope_out": ["refactor importer"],
        "human_approval_gates": ["after_plan_review", "after_S1"],
        "estimated_cost_usd_low": 1.0,
        "estimated_cost_usd_high": 3.0,
        "estimated_duration_min_low": 30,
        "estimated_duration_min_high": 60,
        "estimated_tokens_total": 50000,
        "generated_by": "t/p",
        "generated_at": "2026-04-26T23:00:00Z",
        "cost_usd": 0.005,
        "approved_at": None,
        "approved_by": "",
    }
    (specs_dir / f"{name}.plan.yaml").write_text(yaml.safe_dump(data))
    return data


def test_plan_help_lists_subcommands(runner: CliRunner) -> None:
    result = runner.invoke(main, ["plan", "--help"])
    assert result.exit_code == 0
    for cmd in ("generate", "show", "list"):
        assert cmd in result.output


def test_plan_generate_missing_spec_errors(runner: CliRunner, tmp_path) -> None:
    result = runner.invoke(
        main,
        ["plan", "generate", "ghost", "--specs-dir", str(tmp_path)],
    )
    assert result.exit_code == 1
    assert "not found" in result.output


def test_plan_generate_writes_yaml_with_mocked_planner(runner: CliRunner, tmp_path) -> None:
    _seed_spec(tmp_path)
    plan_payload = {
        "sprints": [
            {
                "id": "S1",
                "name": "Foundation",
                "goal": "stand up",
                "gate": "green",
                "phases": [{"id": "S1.P1", "name": "skel"}],
            }
        ],
        "risk_register": [{"description": "encoding", "severity": "medium"}],
        "scope_in": ["fix"],
        "scope_out": ["refactor"],
    }
    with (
        patch("heap.gateway.litellm.completion") as mock_lit,
        patch("heap.gateway.litellm.completion_cost", return_value=0.0001),
    ):
        from types import SimpleNamespace

        msg = SimpleNamespace(content=json.dumps(plan_payload), tool_calls=None)
        mock_lit.return_value = SimpleNamespace(
            choices=[SimpleNamespace(message=msg)],
            usage=SimpleNamespace(prompt_tokens=400, completion_tokens=600),
        )
        result = runner.invoke(
            main,
            [
                "plan",
                "generate",
                "csv-bom",
                "--specs-dir",
                str(tmp_path),
                "--no-include-scenarios",
            ],
            env={"ANTHROPIC_API_KEY": "fake-key"},
        )

    assert result.exit_code == 0, result.output
    out_path = tmp_path / "csv-bom.plan.yaml"
    assert out_path.exists()
    loaded = yaml.safe_load(out_path.read_text())
    assert loaded["spec_name"] == "csv-bom"
    assert len(loaded["sprints"]) == 1
    assert "Wrote" in result.output


def test_plan_generate_without_api_key_errors(runner: CliRunner, tmp_path) -> None:
    _seed_spec(tmp_path)
    result = runner.invoke(
        main,
        ["plan", "generate", "csv-bom", "--specs-dir", str(tmp_path), "--no-include-scenarios"],
        env={"ANTHROPIC_API_KEY": ""},
    )
    assert result.exit_code == 1
    assert "ANTHROPIC_API_KEY" in result.output


def test_plan_show_renders_plan(runner: CliRunner, tmp_path) -> None:
    _seed_plan_yaml(tmp_path)
    result = runner.invoke(
        main,
        ["plan", "show", "csv-bom", "--specs-dir", str(tmp_path)],
    )
    assert result.exit_code == 0
    assert "PLAN: csv-bom-v1-20260426230000" in result.output
    assert "Spec: csv-bom v1" in result.output
    assert "S1.P1  Skeleton" in result.output
    assert "[Sonnet]" in result.output
    assert "SCOPE BOUNDARIES" in result.output
    assert "RISKS" in result.output
    assert "ACTIONS" in result.output


def test_plan_show_marks_approved(runner: CliRunner, tmp_path) -> None:
    data = _seed_plan_yaml(tmp_path)
    data["approved_at"] = "2026-04-26T23:30:00Z"
    data["approved_by"] = "vicente"
    (tmp_path / "csv-bom.plan.yaml").write_text(yaml.safe_dump(data))

    result = runner.invoke(
        main,
        ["plan", "show", "csv-bom", "--specs-dir", str(tmp_path)],
    )
    assert result.exit_code == 0
    assert "Approved at 2026-04-26T23:30:00Z by vicente" in result.output


def test_plan_show_missing_errors(runner: CliRunner, tmp_path) -> None:
    result = runner.invoke(
        main,
        ["plan", "show", "ghost", "--specs-dir", str(tmp_path)],
    )
    assert result.exit_code == 1
    assert "No plan" in result.output


def test_plan_list_empty(runner: CliRunner, tmp_path) -> None:
    result = runner.invoke(main, ["plan", "list", "--specs-dir", str(tmp_path)])
    assert result.exit_code == 0
    assert "no plans" in result.output


def test_plan_list_with_plans(runner: CliRunner, tmp_path) -> None:
    _seed_plan_yaml(tmp_path, name="alpha")
    _seed_plan_yaml(tmp_path, name="beta")
    result = runner.invoke(main, ["plan", "list", "--specs-dir", str(tmp_path)])
    assert result.exit_code == 0
    assert "alpha" in result.output
    assert "beta" in result.output


# ---------------------------------------------------------------------------
# `heap plan amend` / `heap plan approve` — S5.P4
# ---------------------------------------------------------------------------


def test_plan_amend_add_phase_via_cli(runner: CliRunner, tmp_path) -> None:
    _seed_plan_yaml(tmp_path)

    user_input = "\n".join(
        [
            "1",  # kind index 1 = add_phase
            "S1",  # sprint id
            "S1.P2",  # new phase id
            "Smoke",  # phase name
            "worker/Sonnet",  # agent
            "lint+tests",  # gate
            "rationale: needed for v0.2",
        ]
    )
    result = runner.invoke(
        main,
        ["plan", "amend", "csv-bom", "--specs-dir", str(tmp_path)],
        input=user_input + "\n",
    )

    assert result.exit_code == 0, result.output
    loaded = yaml.safe_load((tmp_path / "csv-bom.plan.yaml").read_text())
    assert loaded["rev"] == 2
    phases = loaded["sprints"][0]["phases"]
    assert any(p["id"] == "S1.P2" for p in phases)
    assert len(loaded["revisions"]) == 1
    assert "bumped to rev 2" in result.output


def test_plan_amend_with_options_skips_prompts(runner: CliRunner, tmp_path) -> None:
    _seed_plan_yaml(tmp_path)
    result = runner.invoke(
        main,
        [
            "plan",
            "amend",
            "csv-bom",
            "--specs-dir",
            str(tmp_path),
            "--kind",
            "add_scope_out",
            "--rationale",
            "user pushed back on UI scope",
        ],
        input="expensive UI\n",
    )

    assert result.exit_code == 0, result.output
    loaded = yaml.safe_load((tmp_path / "csv-bom.plan.yaml").read_text())
    assert "expensive UI" in loaded["scope_out"]
    assert loaded["revisions"][0]["rationale"] == "user pushed back on UI scope"


def test_plan_amend_missing_plan_errors(runner: CliRunner, tmp_path) -> None:
    result = runner.invoke(
        main,
        ["plan", "amend", "ghost", "--specs-dir", str(tmp_path), "--kind", "add_scope_out"],
        input="x\nrationale\n",
    )
    assert result.exit_code == 1
    assert "No plan" in result.output


def test_plan_amend_resets_approval(runner: CliRunner, tmp_path) -> None:
    """Amending an approved plan revokes approval per SPEC §1.5."""
    data = _seed_plan_yaml(tmp_path)
    data["approved_at"] = "2026-04-26T20:00:00Z"
    data["approved_by"] = "vicente"
    (tmp_path / "csv-bom.plan.yaml").write_text(yaml.safe_dump(data))

    result = runner.invoke(
        main,
        [
            "plan",
            "amend",
            "csv-bom",
            "--specs-dir",
            str(tmp_path),
            "--kind",
            "add_scope_out",
            "--rationale",
            "x",
        ],
        input="thing\n",
    )

    assert result.exit_code == 0, result.output
    loaded = yaml.safe_load((tmp_path / "csv-bom.plan.yaml").read_text())
    assert loaded["approved_at"] is None
    assert loaded["approved_by"] == ""


def test_plan_amend_invalid_kind_choice(runner: CliRunner, tmp_path) -> None:
    _seed_plan_yaml(tmp_path)
    result = runner.invoke(
        main,
        ["plan", "amend", "csv-bom", "--specs-dir", str(tmp_path)],
        input="99\n",  # out-of-range kind index
    )
    assert result.exit_code == 1
    assert "Invalid choice" in result.output


def test_plan_approve_sets_fields(runner: CliRunner, tmp_path) -> None:
    _seed_plan_yaml(tmp_path)
    result = runner.invoke(
        main,
        ["plan", "approve", "csv-bom", "--specs-dir", str(tmp_path), "--by", "vicente"],
    )

    assert result.exit_code == 0, result.output
    loaded = yaml.safe_load((tmp_path / "csv-bom.plan.yaml").read_text())
    assert loaded["approved_at"] is not None
    assert loaded["approved_by"] == "vicente"
    assert "approved at" in result.output.lower()


def test_plan_approve_missing_plan_errors(runner: CliRunner, tmp_path) -> None:
    result = runner.invoke(
        main,
        ["plan", "approve", "ghost", "--specs-dir", str(tmp_path)],
    )
    assert result.exit_code == 1
    assert "No plan" in result.output


# ---------------------------------------------------------------------------
# `heap run` subgroup — S6.P2
# ---------------------------------------------------------------------------


def _seed_runnable_plan(specs_dir, *, name="csv-bom"):
    """Write a plan with two single-phase sprints — usable by `heap run start`."""
    data = {
        "plan_id": f"{name}-runnable",
        "spec_name": name,
        "spec_version": 1,
        "spec_ref": f"{name} v1",
        "rev": 1,
        "sprints": [
            {
                "id": "S1",
                "name": "First",
                "goal": "first",
                "gate": "first done",
                "phases": [
                    {
                        "id": "S1.P1",
                        "name": "Skel",
                        "agent": "worker/Sonnet",
                        "deliverables": ["a"],
                        "tests": ["t1"],
                        "gate": "ok",
                        "cost_estimate_usd": 0.0,
                        "duration_estimate_min": 0,
                    }
                ],
                "cost_estimate_usd": 0.0,
                "duration_estimate_min": 0,
            },
            {
                "id": "S2",
                "name": "Second",
                "goal": "second",
                "gate": "second done",
                "phases": [
                    {
                        "id": "S2.P1",
                        "name": "Wire",
                        "agent": "worker/Sonnet",
                        "deliverables": ["b"],
                        "tests": ["t2"],
                        "gate": "ok",
                        "cost_estimate_usd": 0.0,
                        "duration_estimate_min": 0,
                    }
                ],
                "cost_estimate_usd": 0.0,
                "duration_estimate_min": 0,
            },
        ],
        "risk_register": [],
        "scope_in": ["x"],
        "scope_out": ["y"],
        "human_approval_gates": ["after_plan_review", "after_S1", "after_S2"],
        "estimated_cost_usd_low": 0.0,
        "estimated_cost_usd_high": 0.0,
        "estimated_duration_min_low": 0,
        "estimated_duration_min_high": 0,
        "estimated_tokens_total": 0,
        "generated_by": "test",
        "generated_at": "2026-04-27T00:00:00Z",
        "cost_usd": 0.0,
        "approved_at": "2026-04-27T00:00:00Z",
        "approved_by": "vicente",
        "revisions": [],
    }
    (specs_dir / f"{name}.plan.yaml").write_text(yaml.safe_dump(data))
    return data


def test_run_help_lists_subcommands(runner: CliRunner) -> None:
    result = runner.invoke(main, ["run", "--help"])
    assert result.exit_code == 0
    for cmd in ("start", "resume", "approve", "show", "list"):
        assert cmd in result.output


def test_run_start_halts_at_first_sprint_gate(runner: CliRunner, tmp_path) -> None:
    _seed_runnable_plan(tmp_path)
    runs_dir = tmp_path / "runs"

    # Operator answers `pass` then notes empty for S1.P1
    user_input = "\n".join(["pass", "", ""])
    result = runner.invoke(
        main,
        [
            "run",
            "start",
            "csv-bom",
            "--specs-dir",
            str(tmp_path),
            "--runs-base",
            str(runs_dir),
        ],
        input=user_input + "\n",
    )

    assert result.exit_code == 0, result.output
    # State persisted
    runs = sorted(d.name for d in runs_dir.iterdir() if d.is_dir())
    assert len(runs) == 1
    state_path = runs_dir / runs[0] / "state.json"
    trace_path = runs_dir / runs[0] / "trace.jsonl"
    assert state_path.exists()
    assert trace_path.exists()
    state = json.loads(state_path.read_text())
    assert state["run_status"] == "awaiting_gate"
    assert state["awaiting_gate"] == "S1"
    assert state["completed_phases"] == ["S1.P1"]


def test_run_start_missing_plan_errors(runner: CliRunner, tmp_path) -> None:
    result = runner.invoke(
        main,
        ["run", "start", "ghost", "--specs-dir", str(tmp_path)],
    )
    assert result.exit_code == 1
    assert "No plan" in result.output


def test_run_show_prints_state_and_events(runner: CliRunner, tmp_path) -> None:
    """Seed a saved run by hand and verify `heap run show` reads it."""
    runs_dir = tmp_path / "runs" / "run-x-1"
    runs_dir.mkdir(parents=True)
    state = {
        "run_id": "run-x-1",
        "plan_id": "x",
        "plan_ref": "",
        "spec_ref": "x v1",
        "started_at": "2026-04-27T00:00:00Z",
        "last_event_at": "2026-04-27T00:00:01Z",
        "sprint_idx": 0,
        "phase_idx": 0,
        "sprint_status": "in_progress",
        "phase_status": "passed",
        "run_status": "awaiting_gate",
        "completed_sprints": [],
        "completed_phases": ["S1.P1"],
        "failed_phase": "",
        "awaiting_gate": "S1",
        "cost_usd_total": 0.05,
        "tokens_in_total": 100,
        "tokens_out_total": 50,
    }
    (runs_dir / "state.json").write_text(json.dumps(state))
    trace_lines = [
        '{"ts": "2026-04-27T00:00:00Z", "kind": "phase_start", "sprint_id": "S1", "phase_id": "S1.P1", "detail": ""}',
        '{"ts": "2026-04-27T00:00:01Z", "kind": "phase_pass", "sprint_id": "S1", "phase_id": "S1.P1", "detail": "ok"}',
    ]
    (runs_dir / "trace.jsonl").write_text("\n".join(trace_lines) + "\n")

    result = runner.invoke(
        main,
        ["run", "show", "run-x-1", "--runs-base", str(tmp_path / "runs")],
    )
    assert result.exit_code == 0, result.output
    assert "run-x-1" in result.output
    assert "awaiting_gate" in result.output
    assert "phase_pass" in result.output


def test_run_show_missing_errors(runner: CliRunner, tmp_path) -> None:
    result = runner.invoke(main, ["run", "show", "ghost", "--runs-base", str(tmp_path)])
    assert result.exit_code == 1
    assert "No run" in result.output


def test_run_list_empty(runner: CliRunner, tmp_path) -> None:
    result = runner.invoke(main, ["run", "list", "--runs-base", str(tmp_path)])
    assert result.exit_code == 0
    assert "no runs" in result.output


def test_run_list_with_runs(runner: CliRunner, tmp_path) -> None:
    for rid in ("alpha", "beta"):
        d = tmp_path / rid
        d.mkdir()
        (d / "state.json").write_text(
            json.dumps({"run_id": rid, "plan_id": "x", "run_status": "awaiting_gate"})
        )
    result = runner.invoke(main, ["run", "list", "--runs-base", str(tmp_path)])
    assert result.exit_code == 0
    assert "alpha" in result.output
    assert "beta" in result.output


def test_run_resume_continues_from_disk(runner: CliRunner, tmp_path) -> None:
    """Start → halt → resume + approve cycle through CLI."""
    _seed_runnable_plan(tmp_path)
    runs_dir = tmp_path / "runs"

    # Start
    runner.invoke(
        main,
        ["run", "start", "csv-bom", "--specs-dir", str(tmp_path), "--runs-base", str(runs_dir)],
        input="pass\n\n",
    )
    rid = next(d.name for d in runs_dir.iterdir() if d.is_dir())

    # Approve gate
    res_approve = runner.invoke(
        main,
        ["run", "approve", rid, "--runs-base", str(runs_dir), "--by", "vicente"],
    )
    assert res_approve.exit_code == 0, res_approve.output
    assert "approved" in res_approve.output.lower()

    # Resume — runs S2.P1 then halts
    res_resume = runner.invoke(
        main,
        ["run", "resume", rid, "--runs-base", str(runs_dir)],
        input="pass\n\n",
    )
    assert res_resume.exit_code == 0, res_resume.output
    state = json.loads((runs_dir / rid / "state.json").read_text())
    assert state["completed_sprints"] == ["S1"]
    assert state["completed_phases"] == ["S1.P1", "S2.P1"]
    assert state["run_status"] == "awaiting_gate"
    assert state["awaiting_gate"] == "S2"


def test_run_approve_when_not_at_gate_errors(runner: CliRunner, tmp_path) -> None:
    """Approving a run that's mid-flight (not at a gate) is rejected."""
    _seed_runnable_plan(tmp_path)
    runs_dir = tmp_path / "runs"

    # Hand-build a run with run_status=in_progress (no gate halt yet)
    rid = "run-mid"
    d = runs_dir / rid
    d.mkdir(parents=True)
    state = {
        "run_id": rid,
        "plan_id": "csv-bom-runnable",
        "plan_ref": str(tmp_path / "csv-bom.plan.yaml"),
        "spec_ref": "csv-bom v1",
        "started_at": "2026-04-27T00:00:00Z",
        "last_event_at": "2026-04-27T00:00:00Z",
        "sprint_idx": 0,
        "phase_idx": 0,
        "sprint_status": "pending",
        "phase_status": "pending",
        "run_status": "in_progress",
        "completed_sprints": [],
        "completed_phases": [],
        "failed_phase": "",
        "awaiting_gate": "",
        "cost_usd_total": 0.0,
        "tokens_in_total": 0,
        "tokens_out_total": 0,
    }
    (d / "state.json").write_text(json.dumps(state))

    result = runner.invoke(
        main,
        ["run", "approve", rid, "--runs-base", str(runs_dir)],
    )
    assert result.exit_code == 1
    assert "not awaiting" in result.output


# ---------------------------------------------------------------------------
# `heap status` — S7.P1
# ---------------------------------------------------------------------------


def test_status_with_plan_only(runner: CliRunner, tmp_path) -> None:
    _seed_plan_yaml(tmp_path)
    runs_dir = tmp_path / "runs"

    result = runner.invoke(
        main,
        [
            "status",
            "csv-bom",
            "--specs-dir",
            str(tmp_path),
            "--runs-base",
            str(runs_dir),
        ],
    )
    assert result.exit_code == 0, result.output
    assert "csv-bom" in result.output
    assert "no run started yet" in result.output
    assert "plan layout:" in result.output


def test_status_picks_latest_run(runner: CliRunner, tmp_path) -> None:
    """No --run-id, no name → grabs the most-recently-modified run."""
    _seed_plan_yaml(tmp_path)
    runs_dir = tmp_path / "runs"

    # Start a run via the CLI to populate runs_dir
    runner.invoke(
        main,
        ["run", "start", "csv-bom", "--specs-dir", str(tmp_path), "--runs-base", str(runs_dir)],
        input="pass\n\n",
    )

    result = runner.invoke(
        main,
        ["status", "--specs-dir", str(tmp_path), "--runs-base", str(runs_dir)],
    )
    assert result.exit_code == 0, result.output
    assert "Sprint 1 of" in result.output
    assert "awaiting gate" in result.output


def test_status_explicit_run_id(runner: CliRunner, tmp_path) -> None:
    _seed_plan_yaml(tmp_path)
    runs_dir = tmp_path / "runs"

    runner.invoke(
        main,
        ["run", "start", "csv-bom", "--specs-dir", str(tmp_path), "--runs-base", str(runs_dir)],
        input="pass\n\n",
    )
    rid = next(d.name for d in runs_dir.iterdir() if d.is_dir())

    result = runner.invoke(
        main,
        [
            "status",
            "--run-id",
            rid,
            "--specs-dir",
            str(tmp_path),
            "--runs-base",
            str(runs_dir),
        ],
    )
    assert result.exit_code == 0, result.output
    assert rid in result.output


def test_status_missing_run_id_errors(runner: CliRunner, tmp_path) -> None:
    result = runner.invoke(
        main,
        ["status", "--run-id", "ghost", "--runs-base", str(tmp_path)],
    )
    assert result.exit_code == 1
    assert "No run" in result.output


def test_status_no_plan_no_run_errors(runner: CliRunner, tmp_path) -> None:
    """No plan, no run → friendly error suggesting next steps."""
    result = runner.invoke(
        main,
        [
            "status",
            "--specs-dir",
            str(tmp_path / "empty"),
            "--runs-base",
            str(tmp_path / "norun"),
        ],
    )
    assert result.exit_code == 1
    assert "Nothing to show" in result.output


def test_status_missing_plan_for_named_arg(runner: CliRunner, tmp_path) -> None:
    result = runner.invoke(
        main,
        ["status", "ghost", "--specs-dir", str(tmp_path), "--runs-base", str(tmp_path / "r")],
    )
    assert result.exit_code == 1
    assert "No plan" in result.output


# ---------------------------------------------------------------------------
# `heap watch` — S7.P2
# ---------------------------------------------------------------------------


def test_watch_no_follow_prints_events(runner: CliRunner, tmp_path) -> None:
    run_dir = tmp_path / "run-x"
    run_dir.mkdir()
    trace = run_dir / "trace.jsonl"
    lines = [
        '{"ts": "2026-04-27T12:00:00Z", "kind": "phase_start", "sprint_id": "S1", "phase_id": "S1.P1", "detail": ""}',
        '{"ts": "2026-04-27T12:00:01Z", "kind": "phase_pass", "sprint_id": "S1", "phase_id": "S1.P1", "detail": "ok"}',
    ]
    trace.write_text("\n".join(lines) + "\n")

    result = runner.invoke(
        main,
        ["watch", "run-x", "--no-follow", "--runs-base", str(tmp_path), "--no-color"],
    )
    assert result.exit_code == 0, result.output
    assert "phase_start" in result.output
    assert "phase_pass" in result.output


def test_watch_no_follow_missing_trace_errors(runner: CliRunner, tmp_path) -> None:
    result = runner.invoke(
        main,
        ["watch", "ghost", "--no-follow", "--runs-base", str(tmp_path)],
    )
    assert result.exit_code == 1
    assert "No trace.jsonl" in result.output


def test_watch_truncates_to_n(runner: CliRunner, tmp_path) -> None:
    run_dir = tmp_path / "run-x"
    run_dir.mkdir()
    trace = run_dir / "trace.jsonl"
    lines = [
        f'{{"ts": "2026-04-27T12:00:0{i}Z", "kind": "k{i}", "sprint_id": "", "phase_id": "", "detail": ""}}'
        for i in range(8)
    ]
    trace.write_text("\n".join(lines) + "\n")

    result = runner.invoke(
        main,
        ["watch", "run-x", "--no-follow", "-n", "3", "--runs-base", str(tmp_path), "--no-color"],
    )
    assert result.exit_code == 0
    assert "k7" in result.output
    assert "k6" in result.output
    assert "k5" in result.output
    assert "k0" not in result.output


# Imports needed by the helper fixtures above
from heap.scenarios import Scenario, ScenarioSet  # noqa: E402
