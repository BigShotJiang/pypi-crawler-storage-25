"""Tests for heap.status — pure formatter."""

from __future__ import annotations

from heap.plan import Phase, Plan, Sprint
from heap.run import RunEvent, RunState
from heap.status import recent_events, sprint_progress, status_line, summary


def _plan() -> Plan:
    return Plan(
        plan_id="csv-bom-v1-1",
        spec_name="csv-bom",
        spec_version=1,
        spec_ref="csv-bom v1",
        sprints=[
            Sprint(
                id="S1",
                name="Reproduce",
                phases=[Phase(id="S1.P1", name="Repro"), Phase(id="S1.P2", name="Diagnose")],
            ),
            Sprint(
                id="S2",
                name="Fix",
                phases=[Phase(id="S2.P1", name="Patch")],
            ),
        ],
    )


def _state(**overrides) -> RunState:
    base = dict(
        run_id="run-1",
        plan_id="csv-bom-v1-1",
        plan_ref="specs/csv-bom.plan.yaml",
        spec_ref="csv-bom v1",
        started_at="2026-04-27T10:00:00Z",
        run_status="in_progress",
    )
    base.update(overrides)
    return RunState(**base)


# ---------------------------------------------------------------------------
# status_line
# ---------------------------------------------------------------------------


def test_status_line_in_progress_shows_current_phase():
    plan = _plan()
    state = _state(sprint_idx=0, phase_idx=1, cost_usd_total=0.42)
    out = status_line(plan, state)

    assert "Sprint 1 of 2" in out
    assert "S1.P2" in out
    assert "Diagnose" in out
    assert "Cost: $0.4200" in out


def test_status_line_awaiting_gate():
    plan = _plan()
    state = _state(
        sprint_idx=0,
        phase_idx=2,  # past end of S1
        run_status="awaiting_gate",
        awaiting_gate="S1",
    )
    out = status_line(plan, state)
    assert "awaiting gate" in out
    assert "S1" in out


def test_status_line_complete_run():
    plan = _plan()
    state = _state(
        sprint_idx=2,  # past end
        run_status="complete",
        completed_sprints=["S1", "S2"],
    )
    out = status_line(plan, state)
    assert "Run complete" in out
    assert "2/2" in out


def test_status_line_failed_run():
    plan = _plan()
    state = _state(run_status="failed", failed_phase="S1.P2")
    out = status_line(plan, state)
    assert "failed" in out
    assert "S1.P2" in out


# ---------------------------------------------------------------------------
# sprint_progress
# ---------------------------------------------------------------------------


def test_sprint_progress_marks_done_current_pending():
    plan = _plan()
    state = _state(
        sprint_idx=1,  # currently in S2
        phase_idx=0,
        completed_sprints=["S1"],
    )
    out = sprint_progress(plan, state)
    lines = out.splitlines()
    assert "✓ S1" in lines[0]
    assert "▶ S2" in lines[1]


def test_sprint_progress_handles_pending_run():
    plan = _plan()
    state = _state(run_status="pending")
    out = sprint_progress(plan, state)
    # No sprint marked current when run hasn't started
    assert "▶" not in out


def test_sprint_progress_empty_plan():
    plan = Plan(plan_id="x", spec_name="x", spec_version=1, spec_ref="x v1")
    state = _state(plan_id="x")
    out = sprint_progress(plan, state)
    assert "no sprints" in out


# ---------------------------------------------------------------------------
# recent_events
# ---------------------------------------------------------------------------


def test_recent_events_renders_events():
    events = [
        RunEvent(ts="2026-04-27T10:00:00Z", kind="phase_start", sprint_id="S1", phase_id="S1.P1"),
        RunEvent(
            ts="2026-04-27T10:00:05Z",
            kind="phase_pass",
            sprint_id="S1",
            phase_id="S1.P1",
            detail="ok",
        ),
    ]
    out = recent_events(events)
    assert "phase_start" in out
    assert "phase_pass" in out
    assert "ok" in out


def test_recent_events_empty():
    assert "no events" in recent_events([])


def test_recent_events_truncates_to_n():
    events = [
        RunEvent(ts=f"2026-04-27T10:00:0{i}Z", kind=f"k{i}", sprint_id="S1") for i in range(10)
    ]
    out = recent_events(events, n=3)
    assert "k7" in out
    assert "k8" in out
    assert "k9" in out
    assert "k0" not in out


# ---------------------------------------------------------------------------
# summary
# ---------------------------------------------------------------------------


def test_summary_with_state_and_events():
    plan = _plan()
    state = _state(sprint_idx=0, phase_idx=1, cost_usd_total=0.10)
    events = [RunEvent(ts="2026-04-27T10:00:00Z", kind="phase_start", phase_id="S1.P1")]
    out = summary(plan, state, events)

    assert "plan:" in out
    assert "spec:" in out
    assert "Sprint 1 of 2" in out
    assert "sprint progress:" in out
    assert "recent events:" in out
    assert "phase_start" in out


def test_summary_without_state_shows_plan_only():
    plan = _plan()
    out = summary(plan, None, None)
    assert "no run started yet" in out
    assert "plan layout:" in out
    # No events / status line
    assert "Sprint 1 of 2" not in out


def test_summary_marks_approved_plan():
    plan = _plan()
    plan = plan.model_copy(update={"approved_at": "2026-04-27T11:00:00Z", "approved_by": "vicente"})
    out = summary(plan, None, None)
    assert "approved at 2026-04-27T11:00:00Z" in out
    assert "vicente" in out
