"""Tests for heap.run — RunEngine state machine + sprint gates.

The engine takes an ``execute_phase`` callback rather than calling a
model, so all tests run offline with deterministic stub executors.
"""

from __future__ import annotations

import pytest

from heap.plan import Phase, Plan, Sprint
from heap.run import (
    PhaseResult,
    RunContext,
    RunEngine,
    RunEvent,
)

# ---------------------------------------------------------------------------
# fixtures
# ---------------------------------------------------------------------------


def _phase(pid: str, name: str = "x") -> Phase:
    return Phase(
        id=pid,
        name=name,
        agent="worker/Sonnet",
        deliverables=["x"],
        tests=["t"],
        gate="ok",
    )


def _plan(sprint_specs: list[tuple[str, list[str]]]) -> Plan:
    """Build a Plan from [(sprint_id, [phase_id, ...]), ...]."""
    return Plan(
        plan_id="test-plan-1",
        spec_name="x",
        spec_version=1,
        spec_ref="x v1",
        sprints=[
            Sprint(
                id=sid,
                name=sid,
                phases=[_phase(pid) for pid in pids],
                gate=f"{sid}: tests pass",
            )
            for sid, pids in sprint_specs
        ],
    )


def _always_pass(_ctx: RunContext) -> PhaseResult:
    return PhaseResult(passed=True, detail="ok", cost_usd=0.05, tokens_in=10, tokens_out=20)


# ---------------------------------------------------------------------------
# bootstrap
# ---------------------------------------------------------------------------


def test_engine_rejects_empty_plan():
    plan = Plan(plan_id="x", spec_name="x", spec_version=1, spec_ref="x v1")
    with pytest.raises(ValueError, match="zero sprints"):
        RunEngine(plan, execute_phase=_always_pass)


def test_engine_initializes_pending_state():
    plan = _plan([("S1", ["S1.P1"])])
    engine = RunEngine(plan, execute_phase=_always_pass)

    assert engine.state.run_status == "pending"
    assert engine.state.sprint_idx == 0
    assert engine.state.phase_idx == 0
    assert engine.state.run_id.startswith("run-test-plan-1-")
    assert engine.state.plan_id == "test-plan-1"


# ---------------------------------------------------------------------------
# halt at first sprint gate
# ---------------------------------------------------------------------------


def test_run_halts_at_first_sprint_gate():
    plan = _plan([("S1", ["S1.P1", "S1.P2"]), ("S2", ["S2.P1"])])
    engine = RunEngine(plan, execute_phase=_always_pass)

    state = engine.run()

    assert state.run_status == "awaiting_gate"
    assert state.awaiting_gate == "S1"
    assert state.sprint_idx == 0  # not advanced yet
    assert state.completed_phases == ["S1.P1", "S1.P2"]
    # Sprint S2 not started
    assert "S2.P1" not in state.completed_phases


def test_run_emits_phase_and_sprint_events_in_order():
    plan = _plan([("S1", ["S1.P1", "S1.P2"])])
    engine = RunEngine(plan, execute_phase=_always_pass)
    engine.run()

    kinds = [e.kind for e in engine.events]
    # Order matters
    assert kinds.index("run_start") < kinds.index("sprint_start")
    assert kinds.index("sprint_start") < kinds.index("phase_start")
    assert kinds.count("phase_start") == 2
    assert kinds.count("phase_pass") == 2
    assert kinds[-1] == "sprint_gate"


def test_event_sink_receives_events():
    plan = _plan([("S1", ["S1.P1"])])
    seen: list[RunEvent] = []
    engine = RunEngine(plan, execute_phase=_always_pass, event_sink=seen.append)

    engine.run()

    assert len(seen) > 0
    assert any(e.kind == "phase_pass" for e in seen)


def test_event_sink_errors_do_not_break_run():
    plan = _plan([("S1", ["S1.P1"])])

    def bad_sink(_ev):
        raise RuntimeError("boom")

    engine = RunEngine(plan, execute_phase=_always_pass, event_sink=bad_sink)

    state = engine.run()

    assert state.run_status == "awaiting_gate"


# ---------------------------------------------------------------------------
# approve_gate progresses the run
# ---------------------------------------------------------------------------


def test_approve_gate_advances_to_next_sprint():
    plan = _plan([("S1", ["S1.P1"]), ("S2", ["S2.P1"])])
    engine = RunEngine(plan, execute_phase=_always_pass)

    engine.run()
    assert engine.state.run_status == "awaiting_gate"

    engine.approve_gate(approver="vicente")
    assert engine.state.completed_sprints == ["S1"]
    assert engine.state.sprint_idx == 1
    assert engine.state.phase_idx == 0
    assert engine.state.run_status == "in_progress"

    # Continue
    engine.run()
    assert engine.state.run_status == "awaiting_gate"
    assert engine.state.awaiting_gate == "S2"


def test_approve_gate_rejects_when_not_at_gate():
    plan = _plan([("S1", ["S1.P1"])])
    engine = RunEngine(plan, execute_phase=_always_pass)

    with pytest.raises(RuntimeError, match="awaiting"):
        engine.approve_gate()


def test_full_walk_completes_on_final_gate_approval():
    plan = _plan([("S1", ["S1.P1"]), ("S2", ["S2.P1"])])
    engine = RunEngine(plan, execute_phase=_always_pass)

    engine.run()
    engine.approve_gate()
    engine.run()
    engine.approve_gate()

    # No more sprints — next run() finishes
    state = engine.run()
    assert state.run_status == "complete"
    assert state.completed_sprints == ["S1", "S2"]
    assert state.completed_phases == ["S1.P1", "S2.P1"]


# ---------------------------------------------------------------------------
# phase failure halts the run
# ---------------------------------------------------------------------------


def test_phase_failure_halts_run_with_failed_status():
    plan = _plan([("S1", ["S1.P1", "S1.P2"]), ("S2", ["S2.P1"])])

    def fail_on_p2(ctx: RunContext) -> PhaseResult:
        if ctx.phase.id == "S1.P2":
            return PhaseResult(passed=False, detail="contract not met")
        return _always_pass(ctx)

    engine = RunEngine(plan, execute_phase=fail_on_p2)

    state = engine.run()
    assert state.run_status == "failed"
    assert state.failed_phase == "S1.P2"
    assert state.completed_phases == ["S1.P1"]
    # Subsequent run() is a no-op
    again = engine.run()
    assert again.run_status == "failed"


def test_phase_failure_emits_phase_fail_and_run_failed_events():
    plan = _plan([("S1", ["S1.P1"])])

    def fail(_ctx: RunContext) -> PhaseResult:
        return PhaseResult(passed=False, detail="bad")

    engine = RunEngine(plan, execute_phase=fail)
    engine.run()

    kinds = [e.kind for e in engine.events]
    assert "phase_fail" in kinds
    assert "run_failed" in kinds
    assert kinds[-1] == "run_failed"


# ---------------------------------------------------------------------------
# hooks fire
# ---------------------------------------------------------------------------


def test_pre_post_phase_hooks_fire():
    plan = _plan([("S1", ["S1.P1", "S1.P2"])])
    pre_calls: list[str] = []
    post_calls: list[str] = []

    def pre(ctx: RunContext) -> None:
        pre_calls.append(ctx.phase.id)

    def post(ctx: RunContext) -> None:
        post_calls.append(ctx.phase.id)

    engine = RunEngine(
        plan,
        execute_phase=_always_pass,
        pre_phase=pre,
        post_phase=post,
    )
    engine.run()

    assert pre_calls == ["S1.P1", "S1.P2"]
    assert post_calls == ["S1.P1", "S1.P2"]


def test_on_gate_hook_fires_at_sprint_end():
    plan = _plan([("S1", ["S1.P1"])])
    gate_calls: list[str] = []

    def on_gate(ctx: RunContext) -> None:
        gate_calls.append(ctx.sprint.id)

    engine = RunEngine(plan, execute_phase=_always_pass, on_gate=on_gate)
    engine.run()

    assert gate_calls == ["S1"]


# ---------------------------------------------------------------------------
# totals roll up
# ---------------------------------------------------------------------------


def test_cost_and_tokens_roll_up():
    plan = _plan([("S1", ["S1.P1", "S1.P2"]), ("S2", ["S2.P1"])])

    def costy(ctx: RunContext) -> PhaseResult:
        return PhaseResult(
            passed=True,
            cost_usd=0.10,
            tokens_in=100,
            tokens_out=50,
        )

    engine = RunEngine(plan, execute_phase=costy)
    engine.run()
    engine.approve_gate()
    engine.run()
    engine.approve_gate()
    engine.run()

    assert engine.state.cost_usd_total == pytest.approx(0.30)
    assert engine.state.tokens_in_total == 300
    assert engine.state.tokens_out_total == 150


# ---------------------------------------------------------------------------
# resume from saved state (S6.P2 will use this disk-backed)
# ---------------------------------------------------------------------------


def test_engine_resumes_from_passed_state():
    plan = _plan([("S1", ["S1.P1"]), ("S2", ["S2.P1", "S2.P2"])])
    engine = RunEngine(plan, execute_phase=_always_pass)
    engine.run()
    engine.approve_gate()
    engine.run()  # halts at S2 gate after P1 + P2 pass

    saved = engine.state.model_copy()
    assert saved.completed_sprints == ["S1"]
    assert saved.awaiting_gate == "S2"

    # New engine resumes from saved state — should be at gate, no phases re-run
    runs: list[str] = []

    def track(ctx: RunContext) -> PhaseResult:
        runs.append(ctx.phase.id)
        return _always_pass(ctx)

    resumed = RunEngine(plan, execute_phase=track, state=saved)
    state = resumed.run()

    assert runs == []  # no phases re-executed (already at gate)
    assert state.run_status == "awaiting_gate"


# ---------------------------------------------------------------------------
# Persistence — S6.P2
# ---------------------------------------------------------------------------


def test_save_and_load_state(tmp_path):
    from heap.run import RunState, load_state, save_state

    state = RunState(run_id="run-x-1", plan_id="x")
    target_dir = tmp_path / "run-x-1"
    save_state(state, target_dir)

    assert (target_dir / "state.json").exists()
    loaded = load_state("run-x-1", base=tmp_path)
    assert loaded == state


def test_load_state_missing_returns_none(tmp_path):
    from heap.run import load_state

    assert load_state("ghost", base=tmp_path) is None


def test_append_event_and_load_events(tmp_path):
    from heap.run import RunEvent, append_event, load_events

    target_dir = tmp_path / "run-x-1"
    append_event(RunEvent(ts="2026-04-27T00:00:00Z", kind="phase_start"), target_dir)
    append_event(RunEvent(ts="2026-04-27T00:00:01Z", kind="phase_pass"), target_dir)

    events = load_events("run-x-1", base=tmp_path)
    assert len(events) == 2
    assert events[0].kind == "phase_start"
    assert events[1].kind == "phase_pass"


def test_load_events_missing_returns_empty(tmp_path):
    from heap.run import load_events

    assert load_events("ghost", base=tmp_path) == []


def test_load_events_skips_malformed_lines(tmp_path):
    from heap.run import RunEvent, append_event, load_events

    target_dir = tmp_path / "run-x-1"
    append_event(RunEvent(ts="2026-04-27T00:00:00Z", kind="ok"), target_dir)
    # Inject a bad line
    (target_dir / "trace.jsonl").open("a").write("not json\n")
    append_event(RunEvent(ts="2026-04-27T00:00:01Z", kind="ok2"), target_dir)

    events = load_events("run-x-1", base=tmp_path)
    assert [e.kind for e in events] == ["ok", "ok2"]


def test_list_runs_returns_only_dirs_with_state(tmp_path):
    from heap.run import RunState, list_runs, save_state

    save_state(RunState(run_id="alpha", plan_id="x"), tmp_path / "alpha")
    save_state(RunState(run_id="beta", plan_id="x"), tmp_path / "beta")
    # Empty directory should not be listed
    (tmp_path / "garbage").mkdir()

    runs = list_runs(tmp_path)
    assert runs == ["alpha", "beta"]


def test_list_runs_empty_for_missing_base(tmp_path):
    from heap.run import list_runs

    assert list_runs(tmp_path / "does-not-exist") == []


def test_engine_with_run_dir_persists_each_transition(tmp_path):
    from heap.run import load_events, load_state

    plan = _plan([("S1", ["S1.P1", "S1.P2"])])
    engine = RunEngine(
        plan,
        execute_phase=_always_pass,
        run_dir=tmp_path / "run-1",
    )
    engine.run()

    # State persisted; matches in-memory
    state_on_disk = load_state("run-1", base=tmp_path)
    assert state_on_disk == engine.state
    # Events persisted in JSONL
    events_on_disk = load_events("run-1", base=tmp_path)
    assert [e.kind for e in events_on_disk] == [e.kind for e in engine.events]
    assert any(e.kind == "sprint_gate" for e in events_on_disk)


def test_load_run_resumes_from_disk(tmp_path):
    """Round-trip: run → save → load_run → resume → finish."""
    from heap.plan import write_plan
    from heap.run import load_run

    plan = _plan([("S1", ["S1.P1"]), ("S2", ["S2.P1"])])
    plan_path = tmp_path / "x.plan.yaml"
    write_plan(plan, plan_path)

    runs_root = tmp_path / "runs"
    engine = RunEngine(
        plan,
        execute_phase=_always_pass,
        run_dir=runs_root / "run-1",
        plan_ref=str(plan_path),
    )
    # Force a stable run_id so we can find it by name.
    engine.state.run_id = "run-1"
    engine.state.plan_ref = str(plan_path)
    engine.run()
    assert engine.state.run_status == "awaiting_gate"

    # Load it back from disk and resume — phase totals + completed_phases preserved
    resumed = load_run("run-1", execute_phase=_always_pass, base=runs_root)
    assert resumed.state.completed_phases == ["S1.P1"]
    assert resumed.state.run_status == "awaiting_gate"
    resumed.approve_gate()
    resumed.run()  # finishes S2 + halts at its gate
    assert resumed.state.completed_phases == ["S1.P1", "S2.P1"]
    assert resumed.state.awaiting_gate == "S2"


def test_load_run_missing_plan_file_raises(tmp_path):
    """If the plan file referenced by state.plan_ref is gone, fail loudly."""
    from heap.run import RunState, load_run, save_state

    state = RunState(run_id="ghost", plan_id="x", plan_ref=str(tmp_path / "no-such.plan.yaml"))
    save_state(state, tmp_path / "ghost")

    with pytest.raises(FileNotFoundError):
        load_run("ghost", execute_phase=_always_pass, base=tmp_path)


def test_load_run_missing_state_raises(tmp_path):
    from heap.run import load_run

    with pytest.raises(FileNotFoundError):
        load_run("ghost", execute_phase=_always_pass, base=tmp_path)


# ---------------------------------------------------------------------------
# Auto-retry (§9.3) — S6.P3
# ---------------------------------------------------------------------------


def test_non_retryable_failure_halts_immediately():
    plan = _plan([("S1", ["S1.P1"])])
    calls = []

    def exec_fail_no_retry(ctx: RunContext) -> PhaseResult:
        calls.append(ctx.attempt)
        return PhaseResult(passed=False, retryable=False, detail="architectural mismatch")

    engine = RunEngine(plan, execute_phase=exec_fail_no_retry)
    state = engine.run()

    assert state.run_status == "failed"
    assert calls == [1]  # exactly one call, no retry
    kinds = [e.kind for e in engine.events]
    assert "phase_retry" not in kinds
    assert "phase_fail" in kinds


def test_retryable_failure_then_pass_advances():
    plan = _plan([("S1", ["S1.P1"])])
    calls: list[int] = []

    def exec_pass_on_retry(ctx: RunContext) -> PhaseResult:
        calls.append(ctx.attempt)
        if ctx.attempt == 1:
            return PhaseResult(passed=False, retryable=True, detail="flaky test")
        return PhaseResult(passed=True, detail="passed on retry")

    engine = RunEngine(plan, execute_phase=exec_pass_on_retry)
    state = engine.run()

    assert calls == [1, 2]
    assert state.run_status == "awaiting_gate"
    assert state.completed_phases == ["S1.P1"]
    kinds = [e.kind for e in engine.events]
    assert kinds.count("phase_start") == 1
    assert kinds.count("phase_retry") == 1
    assert kinds.count("phase_pass") == 1


def test_retryable_failing_twice_still_halts():
    plan = _plan([("S1", ["S1.P1"])])
    calls = []

    def exec_always_fail(ctx: RunContext) -> PhaseResult:
        calls.append(ctx.attempt)
        return PhaseResult(passed=False, retryable=True, detail=f"failed on attempt {ctx.attempt}")

    engine = RunEngine(plan, execute_phase=exec_always_fail)
    state = engine.run()

    assert calls == [1, 2]  # exactly one retry, then halt
    assert state.run_status == "failed"
    assert state.failed_phase == "S1.P1"
    kinds = [e.kind for e in engine.events]
    assert kinds.count("phase_retry") == 1
    assert kinds.count("phase_fail") == 1


def test_retry_uses_attempt_2_in_context():
    plan = _plan([("S1", ["S1.P1"])])
    seen_attempts: list[int] = []

    def exec_check_ctx(ctx: RunContext) -> PhaseResult:
        seen_attempts.append(ctx.attempt)
        return PhaseResult(
            passed=ctx.attempt == 2,  # only succeeds on retry
            retryable=True,
            detail="x",
        )

    engine = RunEngine(plan, execute_phase=exec_check_ctx)
    engine.run()

    assert seen_attempts == [1, 2]


def test_retry_then_pass_records_costs_from_both_attempts():
    """Cost telemetry should add up across retried attempts."""
    plan = _plan([("S1", ["S1.P1"])])

    def exec_costy(ctx: RunContext) -> PhaseResult:
        if ctx.attempt == 1:
            return PhaseResult(passed=False, retryable=True, cost_usd=0.10, tokens_out=50)
        return PhaseResult(passed=True, cost_usd=0.05, tokens_out=20)

    engine = RunEngine(plan, execute_phase=exec_costy)
    engine.run()

    assert engine.state.cost_usd_total == pytest.approx(0.15)
    assert engine.state.tokens_out_total == 70


def test_retry_works_inside_persisted_engine(tmp_path):
    """Retry events also land on disk, so resume sees the retry trace."""
    from heap.run import load_events

    plan = _plan([("S1", ["S1.P1"])])

    def exec_retry_pass(ctx: RunContext) -> PhaseResult:
        return PhaseResult(
            passed=ctx.attempt == 2,
            retryable=True,
        )

    engine = RunEngine(
        plan,
        execute_phase=exec_retry_pass,
        run_dir=tmp_path / "run-1",
    )
    engine.run()

    on_disk = [e.kind for e in load_events("run-1", base=tmp_path)]
    assert "phase_retry" in on_disk
    assert "phase_pass" in on_disk
