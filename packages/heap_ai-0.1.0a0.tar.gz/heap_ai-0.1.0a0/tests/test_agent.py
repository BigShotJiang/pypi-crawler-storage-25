"""Tests for heap.agent — mocked Gateway, no real model calls."""

from __future__ import annotations

from unittest.mock import patch

import pytest

from heap import (
    Agent,
    AgentResult,
    Block,
    Gateway,
    GatewayResponse,
    PhaseLogEntry,
    Retry,
    Warn,
)

# ---------------------------------------------------------------------------
# helpers / fixtures
# ---------------------------------------------------------------------------


def _gw_resp(
    content: str,
    model: str = "test/m",
    tokens_in: int = 50,
    tokens_out: int = 25,
    cost: float = 0.001,
) -> GatewayResponse:
    return GatewayResponse(
        content=content,
        model_used=model,
        tokens_in=tokens_in,
        tokens_out=tokens_out,
        cost_usd=cost,
        latency_ms=120.0,
    )


def _verify_pass(reason: str = "satisfies contract") -> str:
    return f'{{"passed": true, "reason": "{reason}", "evidence": ["ok"]}}'


def _verify_fail(reason: str = "missing X") -> str:
    return f'{{"passed": false, "reason": "{reason}", "evidence": []}}'


@pytest.fixture
def gw() -> Gateway:
    return Gateway(planner="t/p", worker="t/w", fast="t/f")


@pytest.fixture
def agent(gw: Gateway) -> Agent:
    return Agent(
        name="t-agent",
        model="t/w",
        planner_model="t/p",
        contract="The output must contain the word 'done'.",
        gateway=gw,
        max_replans=3,
    )


# ---------------------------------------------------------------------------
# construction
# ---------------------------------------------------------------------------


def test_agent_construction_owns_gateway() -> None:
    """Without a gateway= arg, the agent should build its own."""
    a = Agent(name="solo", model="m1", planner_model="m2", contract="c")
    assert isinstance(a._gw, Gateway)
    assert a._gw.models["worker"] == "m1"
    assert a._gw.models["planner"] == "m2"
    assert a.name == "solo"
    assert a.contract == "c"
    assert a.max_replans == 3
    assert a.tools == []
    assert a.skill_names == []


def test_agent_accepts_injected_gateway(gw: Gateway) -> None:
    a = Agent(name="x", model="m", planner_model="p", contract="c", gateway=gw)
    assert a._gw is gw


def test_agent_strips_contract_whitespace() -> None:
    a = Agent(name="x", model="m", planner_model="p", contract="\n  do thing  \n")
    assert a.contract == "do thing"


# ---------------------------------------------------------------------------
# happy path
# ---------------------------------------------------------------------------


def test_run_happy_path(agent: Agent, gw: Gateway) -> None:
    responses = [
        _gw_resp("1. step one\n2. step two", model="t/p"),  # plan
        _gw_resp("done. result delivered.", model="t/w"),  # execute
        _gw_resp(_verify_pass(), model="t/p"),  # verify
    ]
    with patch.object(gw, "call", side_effect=responses) as mock:
        result = agent.run("write a thing")

    assert isinstance(result, AgentResult)
    assert result.verify_outcome.passed is True
    assert result.replan_count == 0
    assert result.escalated is False
    assert "step one" in result.plan
    assert result.content == "done. result delivered."
    assert len(result.phase_log) == 3
    assert [p.phase for p in result.phase_log] == ["plan", "execute", "verify"]
    assert all(isinstance(p, PhaseLogEntry) for p in result.phase_log)
    assert result.total_cost_usd == pytest.approx(0.003, rel=1e-3)
    assert result.total_tokens_in == 150
    assert result.total_tokens_out == 75
    assert mock.call_count == 3
    # plan + verify on planner role; execute on worker role
    roles_used = [c.kwargs["role"] for c in mock.call_args_list]
    assert roles_used == ["planner", "worker", "planner"]


# ---------------------------------------------------------------------------
# replan / escalation
# ---------------------------------------------------------------------------


def test_run_replans_on_verify_fail(agent: Agent, gw: Gateway) -> None:
    responses = [
        _gw_resp("plan 1", model="t/p"),
        _gw_resp("exec 1", model="t/w"),
        _gw_resp(_verify_fail("not done yet"), model="t/p"),
        _gw_resp("plan 2 (improved)", model="t/p"),
        _gw_resp("done finally", model="t/w"),
        _gw_resp(_verify_pass(), model="t/p"),
    ]
    with patch.object(gw, "call", side_effect=responses):
        result = agent.run("task")

    assert result.verify_outcome.passed is True
    assert result.replan_count == 1
    assert result.escalated is False
    # Plan re-prompt for the second pass should reference the previous reason
    assert any("plan 2" in p.model_used or True for p in result.phase_log)


def test_run_escalates_after_max_replans(agent: Agent, gw: Gateway) -> None:
    """1 initial PEV + 3 replans = 4 cycles, all failing → escalate."""
    fail = _verify_fail("still broken")
    responses = []
    for _ in range(4):
        responses.extend(
            [
                _gw_resp("plan", model="t/p"),
                _gw_resp("exec", model="t/w"),
                _gw_resp(fail, model="t/p"),
            ]
        )
    with patch.object(gw, "call", side_effect=responses):
        result = agent.run("task")

    assert result.escalated is True
    assert result.replan_count == 3
    assert result.verify_outcome.passed is False
    assert "still broken" in (result.escalation_reason or "")
    assert len(result.phase_log) == 12  # 4 cycles * 3 phases


# ---------------------------------------------------------------------------
# verify-output parsing edge cases
# ---------------------------------------------------------------------------


def test_verify_handles_markdown_fenced_json(agent: Agent, gw: Gateway) -> None:
    """If verify wraps JSON in ```json ... ``` fences, the parser strips them."""
    fenced = "```json\n" + _verify_pass() + "\n```"
    responses = [
        _gw_resp("plan", model="t/p"),
        _gw_resp("exec", model="t/w"),
        _gw_resp(fenced, model="t/p"),
    ]
    with patch.object(gw, "call", side_effect=responses):
        result = agent.run("task")

    assert result.verify_outcome.passed is True


def test_verify_handles_prose_with_embedded_json(agent: Agent, gw: Gateway) -> None:
    """If verify rambles before the JSON, the parser still extracts it."""
    rambling = "Here you go: " + _verify_pass() + " — hope that helps!"
    responses = [
        _gw_resp("plan", model="t/p"),
        _gw_resp("exec", model="t/w"),
        _gw_resp(rambling, model="t/p"),
    ]
    with patch.object(gw, "call", side_effect=responses):
        result = agent.run("task")

    assert result.verify_outcome.passed is True


def test_verify_unparseable_treated_as_failure(agent: Agent, gw: Gateway) -> None:
    """Garbage verify output → fail; replans then escalates."""
    responses = []
    for _ in range(4):
        responses.extend(
            [
                _gw_resp("plan", model="t/p"),
                _gw_resp("exec", model="t/w"),
                _gw_resp("not json at all, sorry", model="t/p"),
            ]
        )
    with patch.object(gw, "call", side_effect=responses):
        result = agent.run("task")

    assert result.escalated is True
    assert result.verify_outcome.passed is False
    assert "not parseable" in result.verify_outcome.reason


def test_verify_empty_treated_as_failure(agent: Agent, gw: Gateway) -> None:
    responses = []
    for _ in range(4):
        responses.extend(
            [
                _gw_resp("plan", model="t/p"),
                _gw_resp("exec", model="t/w"),
                _gw_resp("", model="t/p"),
            ]
        )
    with patch.object(gw, "call", side_effect=responses):
        result = agent.run("task")

    assert result.escalated is True
    assert "empty content" in result.verify_outcome.reason


# ---------------------------------------------------------------------------
# hook surface (registration only — actions handled in S2.P2)
# ---------------------------------------------------------------------------


def test_hook_registers_and_fires_at_phase_boundaries(agent: Agent, gw: Gateway) -> None:
    fired: list[str] = []

    @agent.hook("pre_phase")
    def on_pre(ctx) -> None:
        fired.append(f"pre:{ctx.phase}:{ctx.iteration}")

    @agent.hook("post_phase")
    def on_post(ctx) -> None:
        fired.append(f"post:{ctx.phase}:{ctx.iteration}")

    responses = [
        _gw_resp("plan", model="t/p"),
        _gw_resp("exec", model="t/w"),
        _gw_resp(_verify_pass(), model="t/p"),
    ]
    with patch.object(gw, "call", side_effect=responses):
        agent.run("task")

    # Each phase fires pre + post once → 6 total
    assert len(fired) == 6
    assert fired == [
        "pre:plan:0",
        "post:plan:0",
        "pre:execute:0",
        "post:execute:0",
        "pre:verify:0",
        "post:verify:0",
    ]


def test_hook_decorator_returns_function_unchanged(agent: Agent) -> None:
    """The decorator must not wrap or replace the function."""

    @agent.hook("pre_phase")
    def my_hook(ctx) -> None:
        return None

    # Hook callable is the same object that was decorated
    assert my_hook in agent._hooks["pre_phase"]


def test_hook_action_classes_importable() -> None:
    """Block/Warn/Retry/Continue exist at the public API (semantics in S2.P2)."""
    b = Block("test")
    assert b.reason == "test"


def test_failing_hook_does_not_crash_run(agent: Agent, gw: Gateway) -> None:
    """A hook that raises is logged and skipped — does not abort the run.

    This protects user-supplied hook bugs from killing the agent. Once
    Block semantics land in S2.P2, *intentional* blocks WILL stop the
    run; this test only covers accidental exceptions.
    """

    @agent.hook("pre_phase")
    def buggy(ctx) -> None:
        raise RuntimeError("oops")

    responses = [
        _gw_resp("plan", model="t/p"),
        _gw_resp("exec", model="t/w"),
        _gw_resp(_verify_pass(), model="t/p"),
    ]
    with patch.object(gw, "call", side_effect=responses):
        result = agent.run("task")
    assert result.verify_outcome.passed is True


# ---------------------------------------------------------------------------
# skills
# ---------------------------------------------------------------------------


def test_skills_loaded_from_disk_when_present(tmp_path, gw: Gateway) -> None:
    skill_dir = tmp_path / "skills"
    skill_dir.mkdir()
    (skill_dir / "debugging.md").write_text("Always read the stack trace first.\n")

    a = Agent(
        name="x",
        model="m",
        planner_model="p",
        contract="c",
        skills=["debugging"],
        gateway=gw,
        skills_dir=skill_dir,
    )
    assert "Always read the stack trace first." in a._skills_text


def test_missing_skill_does_not_raise(tmp_path, gw: Gateway, caplog) -> None:
    a = Agent(
        name="x",
        model="m",
        planner_model="p",
        contract="c",
        skills=["nonexistent"],
        gateway=gw,
        skills_dir=tmp_path,
    )
    assert a._skills_text == ""


# ---------------------------------------------------------------------------
# hook action semantics (S2.P2)
# ---------------------------------------------------------------------------


def test_hook_block_at_pre_phase_aborts_run(agent: Agent, gw: Gateway) -> None:
    """Block at pre_phase(plan) → no PEV calls happen; finalized as blocked."""

    @agent.hook("pre_phase")
    def deny_plan(ctx):
        if ctx.phase == "plan":
            return Block("policy says no")

    with patch.object(gw, "call") as mock_call:
        result = agent.run("task")

    mock_call.assert_not_called()
    assert result.hook_blocked is True
    assert result.escalated is True
    assert "policy says no" in (result.escalation_reason or "")
    assert result.replan_count == 0


def test_hook_block_at_post_phase_execute_aborts(agent: Agent, gw: Gateway) -> None:
    """Block after execute (e.g., side-effect detection) stops before verify."""

    @agent.hook("post_phase")
    def stop_after_exec(ctx):
        if ctx.phase == "execute":
            return Block("execute side-effects detected")

    responses = [
        _gw_resp("plan", model="t/p"),
        _gw_resp("exec result", model="t/w"),
        # verify should never be called
    ]
    with patch.object(gw, "call", side_effect=responses) as mock:
        result = agent.run("task")

    assert result.hook_blocked is True
    assert "side-effects detected" in (result.escalation_reason or "")
    assert mock.call_count == 2  # plan + execute, no verify


def test_hook_warn_collects_messages(agent: Agent, gw: Gateway) -> None:
    """Warn does not block; messages land in AgentResult.warnings."""

    @agent.hook("post_phase")
    def warn_on_phase(ctx):
        if ctx.phase == "plan":
            return Warn("plan looks weak")

    responses = [
        _gw_resp("plan", model="t/p"),
        _gw_resp("exec", model="t/w"),
        _gw_resp(_verify_pass(), model="t/p"),
    ]
    with patch.object(gw, "call", side_effect=responses):
        result = agent.run("task")

    assert result.hook_blocked is False
    assert result.verify_outcome.passed is True
    assert "plan looks weak" in result.warnings


def test_hook_retry_at_post_verify_forces_replan(agent: Agent, gw: Gateway) -> None:
    """Retry from post_phase(verify) overrides a passing verdict and replans."""
    fire_count = {"n": 0}

    @agent.hook("post_phase")
    def force_one_replan(ctx):
        if ctx.phase == "verify" and fire_count["n"] == 0:
            fire_count["n"] += 1
            return Retry("add more evidence")

    responses = [
        _gw_resp("plan v1", model="t/p"),
        _gw_resp("exec v1", model="t/w"),
        _gw_resp(_verify_pass(), model="t/p"),  # verifier said pass
        _gw_resp("plan v2", model="t/p"),
        _gw_resp("exec v2", model="t/w"),
        _gw_resp(_verify_pass(), model="t/p"),  # second time accepted
    ]
    with patch.object(gw, "call", side_effect=responses):
        result = agent.run("task")

    assert result.replan_count == 1
    assert result.verify_outcome.passed is True  # second verify passed cleanly
    assert result.escalated is False


def test_hook_retry_ignored_at_other_firing_points(agent: Agent, gw: Gateway) -> None:
    """Retry at pre_phase(plan) is a no-op in v0.1 (logged only)."""

    @agent.hook("pre_phase")
    def silly_retry(ctx):
        if ctx.phase == "plan":
            return Retry("not meaningful here")

    responses = [
        _gw_resp("plan", model="t/p"),
        _gw_resp("exec", model="t/w"),
        _gw_resp(_verify_pass(), model="t/p"),
    ]
    with patch.object(gw, "call", side_effect=responses):
        result = agent.run("task")

    # Run completes normally — Retry was simply ignored at pre_phase.
    assert result.replan_count == 0
    assert result.verify_outcome.passed is True
    assert result.escalated is False


def test_block_wins_over_warn_at_same_firing_point(agent: Agent, gw: Gateway) -> None:
    """Multiple hooks at same boundary: Block dominates."""

    @agent.hook("pre_phase")
    def warn_first(ctx):
        if ctx.phase == "plan":
            return Warn("just a heads-up")

    @agent.hook("pre_phase")
    def then_block(ctx):
        if ctx.phase == "plan":
            return Block("policy")

    with patch.object(gw, "call") as mock_call:
        result = agent.run("task")

    mock_call.assert_not_called()
    assert result.hook_blocked is True
    # Warn still recorded (collected before Block check)
    assert "just a heads-up" in result.warnings


def test_continue_is_explicit_noop(agent: Agent, gw: Gateway) -> None:
    """Continue() and None are equivalent — both let the run proceed."""
    from heap import Continue

    @agent.hook("pre_phase")
    def explicit_continue(ctx):
        return Continue()

    @agent.hook("pre_phase")
    def implicit_none(ctx):
        return None

    responses = [
        _gw_resp("plan", model="t/p"),
        _gw_resp("exec", model="t/w"),
        _gw_resp(_verify_pass(), model="t/p"),
    ]
    with patch.object(gw, "call", side_effect=responses):
        result = agent.run("task")

    assert result.verify_outcome.passed is True
    assert result.warnings == []
    assert result.hook_blocked is False


# ---------------------------------------------------------------------------
# tool integration (S2.P3)
# ---------------------------------------------------------------------------


def _gw_resp_with_tool_calls(
    tool_calls: list[dict],
    content: str = "",
    model: str = "t/w",
) -> GatewayResponse:
    """A gateway response that includes one or more tool_calls."""
    return GatewayResponse(
        content=content,
        tool_calls=tool_calls,
        model_used=model,
        tokens_in=30,
        tokens_out=15,
        cost_usd=0.0005,
        latency_ms=80.0,
    )


def _make_tool_call(name: str, args: dict, call_id: str = "call_1") -> dict:
    import json as _json

    return {
        "id": call_id,
        "type": "function",
        "function": {"name": name, "arguments": _json.dumps(args)},
    }


def test_agent_rejects_undecorated_tool(gw: Gateway) -> None:
    def plain(x: int) -> int:
        return x

    with pytest.raises(TypeError, match="not @tool-decorated"):
        Agent(
            name="x",
            model="m",
            planner_model="p",
            contract="c",
            tools=[plain],
            gateway=gw,
        )


def test_agent_rejects_duplicate_tool_names(gw: Gateway) -> None:
    from heap import tool as tool_dec

    @tool_dec(name="dup")
    def t1(x: int) -> int:
        """d."""
        return x

    @tool_dec(name="dup")
    def t2(x: int) -> int:
        """d."""
        return x

    with pytest.raises(ValueError, match="duplicate tool name"):
        Agent(
            name="x",
            model="m",
            planner_model="p",
            contract="c",
            tools=[t1, t2],
            gateway=gw,
        )


def test_agent_dispatches_single_tool_call(gw: Gateway) -> None:
    """Model emits a tool_call; agent runs the tool and re-prompts."""
    from heap import tool as tool_dec

    @tool_dec
    def get_weather(city: str) -> str:
        """Return the weather for a city."""
        return f"sunny in {city}"

    a = Agent(
        name="weather",
        model="t/w",
        planner_model="t/p",
        contract="Report the weather.",
        tools=[get_weather],
        gateway=gw,
    )

    responses = [
        _gw_resp("1. Look up weather for NYC.", model="t/p"),  # plan
        _gw_resp_with_tool_calls(  # execute, first call returns tool_call
            [_make_tool_call("get_weather", {"city": "NYC"})]
        ),
        _gw_resp("It's sunny in NYC."),  # execute, second call returns final content
        _gw_resp(_verify_pass(), model="t/p"),  # verify
    ]
    with patch.object(gw, "call", side_effect=responses) as mock:
        result = a.run("What's the weather in NYC?")

    assert result.verify_outcome.passed is True
    assert result.content == "It's sunny in NYC."
    # Tool was dispatched
    assert len(result.tool_calls_made) == 1
    assert result.tool_calls_made[0]["tool"] == "get_weather"
    assert result.tool_calls_made[0]["args"] == {"city": "NYC"}
    assert result.tool_calls_made[0]["result"] == "sunny in NYC"
    # Total gateway calls = 4 (plan + 2× execute + verify)
    assert mock.call_count == 4
    # The tool schema must have been passed to the worker
    worker_calls = [c for c in mock.call_args_list if c.kwargs.get("role") == "worker"]
    assert len(worker_calls) == 2
    assert worker_calls[0].kwargs.get("tools") is not None
    assert worker_calls[0].kwargs["tools"][0]["function"]["name"] == "get_weather"


def test_agent_handles_unknown_tool_name(gw: Gateway) -> None:
    """Model hallucinates a tool name → agent returns an error string."""
    from heap import tool as tool_dec

    @tool_dec
    def real_tool(x: int) -> int:
        """r."""
        return x

    a = Agent(
        name="x",
        model="t/w",
        planner_model="t/p",
        contract="c",
        tools=[real_tool],
        gateway=gw,
    )

    responses = [
        _gw_resp("plan", model="t/p"),
        _gw_resp_with_tool_calls([_make_tool_call("nonexistent_tool", {"x": 1})]),
        _gw_resp("ok, falling back", model="t/w"),
        _gw_resp(_verify_pass(), model="t/p"),
    ]
    with patch.object(gw, "call", side_effect=responses):
        result = a.run("task")

    assert "unknown tool" in result.tool_calls_made[0]["result"]


def test_agent_handles_tool_exception(gw: Gateway) -> None:
    """Tool raises → error message in tool result, agent continues."""
    from heap import tool as tool_dec

    @tool_dec
    def buggy(x: int) -> int:
        """b."""
        raise RuntimeError("boom")

    a = Agent(
        name="x",
        model="t/w",
        planner_model="t/p",
        contract="c",
        tools=[buggy],
        gateway=gw,
    )

    responses = [
        _gw_resp("plan", model="t/p"),
        _gw_resp_with_tool_calls([_make_tool_call("buggy", {"x": 1})]),
        _gw_resp("ok handled the error", model="t/w"),
        _gw_resp(_verify_pass(), model="t/p"),
    ]
    with patch.object(gw, "call", side_effect=responses):
        result = a.run("task")

    assert "boom" in result.tool_calls_made[0]["result"]


def test_block_at_pre_tool_call_aborts_run(gw: Gateway) -> None:
    """Block from pre_tool_call → run finalizes with hook_blocked=True."""
    from heap import tool as tool_dec

    @tool_dec(side_effects=["network"])
    def fetch(url: str) -> str:
        """f."""
        return f"content of {url}"

    a = Agent(
        name="x",
        model="t/w",
        planner_model="t/p",
        contract="c",
        tools=[fetch],
        gateway=gw,
    )

    @a.hook("pre_tool_call")
    def deny_network(ctx):
        if ctx.tool == "fetch":
            return Block(f"network calls forbidden for {ctx.args.get('url')}")

    responses = [
        _gw_resp("plan", model="t/p"),
        _gw_resp_with_tool_calls([_make_tool_call("fetch", {"url": "http://evil.example"})]),
        # Verify should never be called
    ]
    with patch.object(gw, "call", side_effect=responses) as mock:
        result = a.run("task")

    assert result.hook_blocked is True
    assert "network calls forbidden" in (result.escalation_reason or "")
    assert "evil.example" in (result.escalation_reason or "")
    assert mock.call_count == 2  # plan + execute(first), no verify


def test_post_tool_call_hook_collects_warnings(gw: Gateway) -> None:
    from heap import tool as tool_dec

    @tool_dec
    def echo(s: str) -> str:
        """e."""
        return s

    a = Agent(
        name="x",
        model="t/w",
        planner_model="t/p",
        contract="c",
        tools=[echo],
        gateway=gw,
    )

    @a.hook("post_tool_call")
    def watch(ctx):
        return Warn(f"called {ctx.tool} with {ctx.args}")

    responses = [
        _gw_resp("plan", model="t/p"),
        _gw_resp_with_tool_calls([_make_tool_call("echo", {"s": "hi"})]),
        _gw_resp("did it"),
        _gw_resp(_verify_pass(), model="t/p"),
    ]
    with patch.object(gw, "call", side_effect=responses):
        result = a.run("task")

    assert any("echo" in w for w in result.warnings)


def test_max_tool_calls_caps_the_loop(gw: Gateway) -> None:
    """Model that keeps calling tools is bounded by max_tool_calls."""
    from heap import tool as tool_dec

    @tool_dec
    def noop(x: int) -> int:
        """n."""
        return x

    a = Agent(
        name="x",
        model="t/w",
        planner_model="t/p",
        contract="c",
        tools=[noop],
        gateway=gw,
        max_tool_calls=2,
    )

    # plan; then 3 successive tool_call responses; then verify must still get called
    looping = [
        _gw_resp_with_tool_calls([_make_tool_call("noop", {"x": 1}, call_id=f"c{i}")])
        for i in range(3)
    ]
    responses = [
        _gw_resp("plan", model="t/p"),
        *looping,
        _gw_resp(_verify_fail(), model="t/p"),  # verify fails (no final content)
        _gw_resp("plan2", model="t/p"),
        _gw_resp("ok", model="t/w"),  # second cycle: no tool_calls
        _gw_resp(_verify_pass(), model="t/p"),
    ]
    with patch.object(gw, "call", side_effect=responses):
        result = a.run("task")

    # max_tool_calls=2 means at most 2 tool dispatch rounds in the first execute.
    # First cycle: 2 dispatched (cap), no final content → verify fails.
    # Second cycle (replan): clean execute, verify passes.
    assert result.replan_count == 1
    assert result.verify_outcome.passed is True
    # Only the first 2 tool calls in execute round 1 were dispatched
    assert len(result.tool_calls_made) == 2
