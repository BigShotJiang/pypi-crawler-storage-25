"""S4 integration test — full spec→scenarios→review→amendment loop.

This is the deterministic on-disk integration that S4.P4 promises: drive a
real Structurer (no mocking inside the spec module), wire a Generator with
a mocked Gateway, and exercise every §7.3 action plus the §7.6 amendment
cycle through the actual ``heap scenarios`` CLI.

A real session is a Click ``CliRunner`` invocation against ``heap.cli.main``
with a stitched-together input stream. All planner calls are intercepted
so the test is offline and free.
"""

from __future__ import annotations

import json
from types import SimpleNamespace
from unittest.mock import patch

import yaml
from click.testing import CliRunner

from heap.cli import main
from heap.spec import InterrogatorOutcome, Structurer

# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


def _seed_real_spec(specs_dir, *, name: str = "csv-bom"):
    """Build a v1 spec via the real Structurer, no model calls."""
    structurer = Structurer(specs_dir=specs_dir)
    outcome = InterrogatorOutcome(
        mode="bug",
        audience="developer",
        facts={
            "symptom": "zero rows imported when CSV has UTF-8 BOM",
            "expected": "all rows imported when CSV has UTF-8 BOM",
        },
        transcript=[],
        finalized_at="2026-04-26T18:00:00Z",
        turns_used=0,
        incomplete=False,
    )
    spec = structurer.write(outcome, name=name)
    return spec, structurer


def _scenarios_payload():
    """Canned planner reply for `Generator.generate`."""
    return {
        "scenarios": [
            {
                "title": "All rows imported",
                "given": ["a CSV with 3 rows and a UTF-8 BOM"],
                "when": ["the importer runs"],
                "then": ["all 3 rows are loaded"],
                "acceptance_ref": 0,
                "confidence": "high",
            },
            {
                "title": "BOM symptom no longer occurs",
                "given": ["a CSV with a UTF-8 BOM"],
                "when": ["the importer runs"],
                "then": ["the symptom no longer occurs"],
                "acceptance_ref": 1,
                "confidence": "medium",
            },
        ]
    }


def _gaps_payload():
    return {
        "gaps": [
            {
                "title": "Empty CSV",
                "given": ["the file is empty"],
                "when": ["the importer runs"],
                "then": ["a friendly empty-state message is logged"],
                "note": "Spec is silent on empty input",
                "confidence": "medium",
            }
        ]
    }


def _amendment_payload():
    return {"criterion": "After fix: empty CSV files log an empty-state message"}


def _make_litellm_dispatch():
    """Route fake completions based on the system prompt content.

    Generator (system: 'translate spec acceptance...')      → scenarios
    Gap detector (system: 'adversarial reviewer of a draft')→ gaps
    propose_acceptance (system: 'convert a single Given...')→ criterion
    Anything else                                           → empty findings
    """

    def dispatch(**kwargs):
        sys_msg = next(
            (m for m in kwargs.get("messages", []) if m["role"] == "system"),
            {"content": ""},
        )
        s = sys_msg.get("content", "").lower()
        if "translate spec acceptance" in s:
            payload = json.dumps(_scenarios_payload())
        elif "adversarial reviewer of a draft scenario" in s:
            payload = json.dumps(_gaps_payload())
        elif "convert a single given/when/then scenario" in s:
            payload = json.dumps(_amendment_payload())
        else:
            payload = "{}"

        msg = SimpleNamespace(content=payload, tool_calls=None)
        return SimpleNamespace(
            choices=[SimpleNamespace(message=msg)],
            usage=SimpleNamespace(prompt_tokens=20, completion_tokens=10),
        )

    return dispatch


# ---------------------------------------------------------------------------
# Test
# ---------------------------------------------------------------------------


def test_s4_full_loop_against_s3_spec(tmp_path):
    """Drive: spec(v1) → generate+gaps → review (every action) → amend → v2.

    Asserts at the end of the run:
      - scenarios.yaml exists and is approved
      - it contains: spec scenarios (regenerated), the gap, a manual scenario, no T1-deleted entries
      - spec.yaml has been bumped to v2 with the new acceptance criterion
      - acceptance.json reflects the v2 list
      - deletions log captured the T1 reason
    """
    runner = CliRunner()
    spec, _ = _seed_real_spec(tmp_path)
    assert spec.version == 1
    assert len(spec.acceptance) == 2

    dispatch = _make_litellm_dispatch()

    # ---- 1. Generate scenarios (with gaps) -----------------------------------
    with (
        patch("heap.gateway.litellm.completion", side_effect=dispatch),
        patch("heap.gateway.litellm.completion_cost", return_value=0.0001),
    ):
        gen_result = runner.invoke(
            main,
            ["scenarios", "generate", "csv-bom", "--specs-dir", str(tmp_path)],
            env={"ANTHROPIC_API_KEY": "fake-key"},
        )
    assert gen_result.exit_code == 0, gen_result.output
    scenarios_path = tmp_path / "csv-bom.scenarios.yaml"
    assert scenarios_path.exists()
    initial = yaml.safe_load(scenarios_path.read_text())
    # 2 spec scenarios + 1 gap
    assert len(initial["scenarios"]) == 3
    sources = {s["source"] for s in initial["scenarios"]}
    assert sources == {"spec", "gap"}

    # ---- 2. Drive the review loop through every action -----------------------
    # Sequence: edit T1 → discuss T2 → delete T1 → add manual + promote → regen → approve
    review_input = "\n".join(
        [
            # e T1: rename, do not replace G/W/T
            "e T1",
            "Renamed: rows imported",
            "n",
            # ? T2: discuss (one question)
            "? T2",
            "Is this scenario specific enough?",
            # d T1: delete with reason
            "d T1",
            "renamed-and-superseded",
            # +: add manual + promote to acceptance criterion
            "+",
            "Edge: empty CSV",
            "the file is empty",
            "",
            "the importer runs",
            "",
            "an empty-state message is logged",
            "",
            "y",  # promote
            "",  # accept drafted criterion
            # r: regenerate (drops spec, keeps gap+manual). blank notes.
            "r",
            "",
            # a: approve
            "a",
        ]
    )

    with (
        patch("heap.gateway.litellm.completion", side_effect=dispatch),
        patch("heap.gateway.litellm.completion_cost", return_value=0.0001),
    ):
        review_result = runner.invoke(
            main,
            ["scenarios", "review", "csv-bom", "--specs-dir", str(tmp_path)],
            input=review_input + "\n",
            env={"ANTHROPIC_API_KEY": "fake-key"},
        )

    assert review_result.exit_code == 0, review_result.output

    # ---- 3. Verify final state ----------------------------------------------
    final = yaml.safe_load(scenarios_path.read_text())

    # Approved
    assert final["approved_at"] is not None

    # Sources after regenerate: spec (fresh from generate) + gap + manual.
    by_source: dict[str, list[dict]] = {}
    for s in final["scenarios"]:
        by_source.setdefault(s["source"], []).append(s)
    assert "spec" in by_source
    assert "gap" in by_source
    assert "manual" in by_source

    # Manual scenario references the new (v2) acceptance criterion (index 2)
    manuals = by_source["manual"]
    assert len(manuals) == 1
    assert manuals[0]["title"] == "Edge: empty CSV"
    assert manuals[0]["acceptance_ref"] == 2

    # Deletion of T1 captured with reason
    assert len(final["deletions"]) == 1
    assert final["deletions"][0]["id"] == "T1"
    assert final["deletions"][0]["reason"] == "renamed-and-superseded"

    # Spec bumped to v2 with new criterion
    spec_v2 = yaml.safe_load((tmp_path / "csv-bom.spec.yaml").read_text())
    assert spec_v2["version"] == 2
    assert len(spec_v2["acceptance"]) == 3
    assert spec_v2["acceptance"][-1] == "After fix: empty CSV files log an empty-state message"
    assert (tmp_path / "csv-bom.spec.v1.yaml").exists()
    assert (tmp_path / "csv-bom.spec.v2.yaml").exists()

    # acceptance.json reflects v2
    accept = json.loads((tmp_path / "csv-bom.acceptance.json").read_text())
    assert accept[-1] == "After fix: empty CSV files log an empty-state message"

    # ScenarioSet's spec_version updated by the amendment
    assert final["spec_version"] == 2

    # Output mentions every key milestone
    out = review_result.output
    assert "deleted T1" in out
    assert "bumped to v2" in out
    assert "Approved" in out
