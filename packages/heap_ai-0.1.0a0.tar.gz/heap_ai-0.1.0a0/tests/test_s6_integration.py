"""S6 integration test — drive a fixture plan to completion through every gate.

This is the deterministic on-disk integration that satisfies the S6 gate
criterion:
    "Drive a fake plan to completion, kill mid-phase, resume cleanly;
     retry per §9.3."

Walked end-to-end through real ``RunEngine`` + persistence + ``load_run``
+ retry — no mocking inside ``heap.run``. The executor is a small state
machine that simulates a phase crash, then a flaky test that needs one
retry, then plain passes.
"""

from __future__ import annotations

import json

import pytest

from heap.plan import Phase, Plan, Sprint, write_plan
from heap.run import (
    PhaseResult,
    RunContext,
    RunEngine,
    load_events,
    load_run,
    load_state,
)


def _phase(pid: str) -> Phase:
    return Phase(
        id=pid,
        name=pid,
        agent="worker/Sonnet",
        deliverables=["x"],
        tests=["t"],
        gate="ok",
    )


def _build_plan() -> Plan:
    return Plan(
        plan_id="csv-bom-v1-test",
        spec_name="csv-bom",
        spec_version=1,
        spec_ref="csv-bom v1",
        sprints=[
            Sprint(
                id="S1",
                name="Reproduce",
                phases=[_phase("S1.P1"), _phase("S1.P2")],
                gate="failing test exists",
            ),
            Sprint(
                id="S2",
                name="Fix + verify",
                phases=[_phase("S2.P1"), _phase("S2.P2")],
                gate="all green",
            ),
        ],
        scope_in=["fix BOM"],
        scope_out=["refactor"],
    )


def test_s6_full_loop_with_crash_resume_and_retry(tmp_path):
    """End-to-end flow that exercises every S6 capability.

    Phases of the test:
      1. First engine starts; S1.P1 passes; S1.P2 *crashes* mid-execution.
      2. Test loads state from disk → confirms persistence captured the
         crash boundary (S1.P1 in completed_phases, phase_idx=1).
      3. Second engine resumes via ``load_run`` with a fresh executor that
         passes S1.P2 cleanly; the run halts at the S1 gate.
      4. Approve the S1 gate.
      5. Resume into S2; the executor returns retryable=True on
         S2.P1 attempt 1 (flaky), passes on attempt 2.
      6. S2.P2 passes; halt at S2 gate.
      7. Approve the S2 gate; final ``run()`` finishes the plan.
      8. Verify the on-disk trace contains the full sequence including
         crash, retry, and gate events.
    """
    plan = _build_plan()
    plan_path = tmp_path / "csv-bom.plan.yaml"
    write_plan(plan, plan_path)

    runs_root = tmp_path / "runs"
    run_id = "run-csv-bom-test"

    # ------------------------------------------------------------------
    # 1. First engine — crash mid-phase on S1.P2
    # ------------------------------------------------------------------

    def crashing_executor(ctx: RunContext) -> PhaseResult:
        if ctx.phase.id == "S1.P1":
            return PhaseResult(passed=True, detail="repro test added", cost_usd=0.05)
        if ctx.phase.id == "S1.P2":
            raise RuntimeError("simulated process crash mid-phase")
        return PhaseResult(passed=True)

    engine = RunEngine(
        plan,
        execute_phase=crashing_executor,
        run_dir=runs_root / run_id,
        plan_ref=str(plan_path),
    )
    # Stable run_id so we can resume by name.
    engine.state.run_id = run_id
    engine.state.plan_ref = str(plan_path)

    with pytest.raises(RuntimeError, match="simulated process crash"):
        engine.run()

    # ------------------------------------------------------------------
    # 2. Crash boundary captured on disk
    # ------------------------------------------------------------------
    saved = load_state(run_id, base=runs_root)
    assert saved is not None
    assert saved.completed_phases == ["S1.P1"]
    assert saved.phase_idx == 1
    assert saved.phase_status == "in_progress"  # we crashed mid-phase
    # Cost recorded for the phase that did finish.
    assert saved.cost_usd_total == pytest.approx(0.05)

    # The trace recorded both phase_starts but only one phase_pass.
    events = load_events(run_id, base=runs_root)
    assert sum(1 for e in events if e.kind == "phase_start") == 2
    assert sum(1 for e in events if e.kind == "phase_pass") == 1

    # ------------------------------------------------------------------
    # 3. Resume with a clean executor; finish S1
    # ------------------------------------------------------------------
    s2p1_attempts: list[int] = []

    def recovery_executor(ctx: RunContext) -> PhaseResult:
        # S1.P2 — clean pass on resume
        if ctx.phase.id == "S1.P2":
            return PhaseResult(passed=True, detail="diagnosed", cost_usd=0.02)
        # S2.P1 — flaky: fail with retry on attempt 1, pass on attempt 2
        if ctx.phase.id == "S2.P1":
            s2p1_attempts.append(ctx.attempt)
            if ctx.attempt == 1:
                return PhaseResult(
                    passed=False,
                    retryable=True,
                    detail="flaky test (timing)",
                    cost_usd=0.01,
                )
            return PhaseResult(passed=True, detail="passed on retry", cost_usd=0.01)
        # S2.P2 — straight pass
        if ctx.phase.id == "S2.P2":
            return PhaseResult(passed=True, detail="ok", cost_usd=0.03)
        return PhaseResult(passed=False, detail="unexpected phase")

    resumed = load_run(run_id, execute_phase=recovery_executor, base=runs_root)
    state = resumed.run()

    # Halts at S1 gate now.
    assert state.run_status == "awaiting_gate"
    assert state.awaiting_gate == "S1"
    assert state.completed_phases == ["S1.P1", "S1.P2"]

    # ------------------------------------------------------------------
    # 4 + 5 + 6. Approve S1, run S2 with retry, halt at S2 gate
    # ------------------------------------------------------------------
    resumed.approve_gate(approver="vicente")
    state = resumed.run()

    assert state.run_status == "awaiting_gate"
    assert state.awaiting_gate == "S2"
    assert state.completed_sprints == ["S1"]
    assert state.completed_phases == ["S1.P1", "S1.P2", "S2.P1", "S2.P2"]
    # S2.P1 was retried exactly once.
    assert s2p1_attempts == [1, 2]

    # ------------------------------------------------------------------
    # 7. Approve S2; final run() completes the plan
    # ------------------------------------------------------------------
    resumed.approve_gate(approver="vicente")
    final = resumed.run()
    assert final.run_status == "complete"
    assert final.completed_sprints == ["S1", "S2"]

    # ------------------------------------------------------------------
    # 8. Trace on disk contains the full sequence
    # ------------------------------------------------------------------
    final_events = load_events(run_id, base=runs_root)
    kinds = [e.kind for e in final_events]
    # The crash plus the recovery means S1.P2 has TWO phase_start events
    # (one before the crash, one on resume).
    assert kinds.count("phase_start") == 5  # S1.P1, S1.P2 (crash), S1.P2 (resume), S2.P1, S2.P2
    assert kinds.count("phase_pass") == 4  # all four phases
    assert kinds.count("phase_retry") == 1  # S2.P1
    assert kinds.count("sprint_gate") == 2  # S1 + S2
    assert kinds.count("gate_approved") == 2
    assert kinds[-1] == "run_complete"

    # State.json on disk reflects completion (final persisted snapshot).
    final_on_disk = json.loads((runs_root / run_id / "state.json").read_text())
    assert final_on_disk["run_status"] == "complete"
    assert final_on_disk["completed_sprints"] == ["S1", "S2"]
    # Total cost rolled up across all attempts (including the failed-then-retried S2.P1).
    expected_cost = 0.05 + 0.02 + 0.01 + 0.01 + 0.03
    assert final_on_disk["cost_usd_total"] == pytest.approx(expected_cost)
