"""Tests for heap.scenarios — mocked Gateway, deterministic, offline."""

from __future__ import annotations

import json
from unittest.mock import patch

import pytest
from pydantic import ValidationError

from heap.gateway import Gateway, GatewayResponse
from heap.scenarios import (
    Generator,
    Scenario,
    ScenarioSet,
    detect_gaps,
    generate,
    read_yaml,
    to_text,
    write_yaml,
)
from heap.spec.structurer import StructuredSpec

# ---------------------------------------------------------------------------
# helpers
# ---------------------------------------------------------------------------


def _gw_resp(payload: dict | str) -> GatewayResponse:
    content = payload if isinstance(payload, str) else json.dumps(payload)
    return GatewayResponse(
        content=content,
        model_used="t/p",
        tokens_in=300,
        tokens_out=150,
        cost_usd=0.0042,
        latency_ms=500.0,
    )


def _gw() -> Gateway:
    return Gateway(planner="t/p", worker="t/w", fast="t/f")


def _spec(
    *,
    name: str = "csv-bom",
    version: int = 1,
    mode: str = "bug",
    acceptance: list[str] | None = None,
    facts: dict | None = None,
) -> StructuredSpec:
    return StructuredSpec(
        name=name,
        version=version,
        mode=mode,
        audience="developer",
        facts=facts or {"symptom": "zero rows", "expected": "all rows imported"},
        acceptance=acceptance
        if acceptance is not None
        else [
            "After fix: all rows imported",
            "After fix: no warnings on UTF-8 BOM files",
            "After fix: column count matches header",
        ],
        created_at="2026-04-26T18:00:00Z",
    )


# ---------------------------------------------------------------------------
# generate — happy paths
# ---------------------------------------------------------------------------


def test_generate_returns_scenarios_per_acceptance_criterion():
    gw = _gw()
    payload = {
        "scenarios": [
            {
                "title": "All rows imported",
                "given": ["a CSV with 3 rows and a UTF-8 BOM"],
                "when": ["the importer runs"],
                "then": ["all 3 rows are loaded"],
                "acceptance_ref": 0,
                "confidence": "high",
            },
            {
                "title": "No BOM warning",
                "given": ["a CSV with a UTF-8 BOM"],
                "when": ["the importer runs"],
                "then": ["no warning about the BOM is logged"],
                "acceptance_ref": 1,
                "confidence": "medium",
            },
            {
                "title": "Column count matches",
                "given": ["a CSV header with 4 columns"],
                "when": ["the importer runs"],
                "then": ["each row reports 4 columns"],
                "acceptance_ref": 2,
                "confidence": "high",
            },
        ]
    }

    with patch.object(gw, "call", return_value=_gw_resp(payload)) as mock:
        result = Generator(gw).generate(_spec())

    assert isinstance(result, ScenarioSet)
    assert result.spec_name == "csv-bom"
    assert result.spec_version == 1
    assert len(result.scenarios) == 3
    assert all(isinstance(s, Scenario) for s in result.scenarios)
    assert {s.acceptance_ref for s in result.scenarios} == {0, 1, 2}
    assert all(s.source == "spec" for s in result.scenarios)
    assert result.scenarios[0].id == "T1"
    assert result.scenarios[2].id == "T3"
    assert result.cost_usd == 0.0042
    assert result.generated_by == "t/p"
    # Planner role used
    assert mock.call_args.kwargs["role"] == "planner"
    # Spec content actually passed in
    user_msg = mock.call_args.kwargs["messages"][1]["content"]
    assert "csv-bom" in user_msg
    assert "After fix: all rows imported" in user_msg


def test_generate_convenience_function_matches_class():
    gw = _gw()
    payload = {"scenarios": [{"title": "X", "acceptance_ref": 0}]}

    with patch.object(gw, "call", return_value=_gw_resp(payload)):
        result = generate(_spec(acceptance=["only crit"]), gw)

    assert len(result.scenarios) == 1
    assert result.scenarios[0].title == "X"


def test_generate_skips_call_when_spec_has_no_acceptance():
    gw = _gw()
    spec = _spec(acceptance=[])

    with patch.object(gw, "call") as mock:
        result = Generator(gw).generate(spec)

    assert result.scenarios == []
    assert result.spec_name == spec.name
    mock.assert_not_called()


# ---------------------------------------------------------------------------
# generate — parsing edge cases
# ---------------------------------------------------------------------------


def test_generate_handles_markdown_fenced_json():
    gw = _gw()
    payload = {"scenarios": [{"title": "fenced", "acceptance_ref": 0}]}
    fenced = "```json\n" + json.dumps(payload) + "\n```"

    with patch.object(gw, "call", return_value=_gw_resp(fenced)):
        result = Generator(gw).generate(_spec())

    assert len(result.scenarios) == 1
    assert result.scenarios[0].title == "fenced"


def test_generate_handles_prose_with_embedded_json():
    gw = _gw()
    rambling = (
        "Sure, here you go: "
        + json.dumps({"scenarios": [{"title": "embedded", "acceptance_ref": 1}]})
        + " — let me know if you need more!"
    )

    with patch.object(gw, "call", return_value=_gw_resp(rambling)):
        result = Generator(gw).generate(_spec())

    assert len(result.scenarios) == 1
    assert result.scenarios[0].acceptance_ref == 1


def test_generate_unparseable_response_returns_empty_set():
    gw = _gw()
    with patch.object(gw, "call", return_value=_gw_resp("definitely not json")):
        result = Generator(gw).generate(_spec())

    assert result.scenarios == []


def test_generate_drops_scenario_without_title():
    gw = _gw()
    payload = {
        "scenarios": [
            {"acceptance_ref": 0},  # no title — drop
            {"title": "real one", "acceptance_ref": 0},
        ]
    }
    with patch.object(gw, "call", return_value=_gw_resp(payload)):
        result = Generator(gw).generate(_spec())

    assert len(result.scenarios) == 1
    assert result.scenarios[0].title == "real one"
    assert result.scenarios[0].id == "T1"  # ids are sequential among kept items


def test_generate_invalid_acceptance_ref_becomes_none():
    """If model returns ref=99 for a 3-criterion spec, coerce to None (not crash)."""
    gw = _gw()
    payload = {
        "scenarios": [
            {"title": "out of range", "acceptance_ref": 99},
            {"title": "negative", "acceptance_ref": -1},
            {"title": "string", "acceptance_ref": "0"},
            {"title": "valid", "acceptance_ref": 1},
        ]
    }
    with patch.object(gw, "call", return_value=_gw_resp(payload)):
        result = Generator(gw).generate(_spec())

    assert [s.acceptance_ref for s in result.scenarios] == [None, None, None, 1]


def test_generate_unknown_confidence_coerced_to_medium():
    gw = _gw()
    payload = {
        "scenarios": [
            {"title": "bogus conf", "acceptance_ref": 0, "confidence": "extreme"},
            {"title": "valid conf", "acceptance_ref": 0, "confidence": "low"},
        ]
    }
    with patch.object(gw, "call", return_value=_gw_resp(payload)):
        result = Generator(gw).generate(_spec())

    assert result.scenarios[0].confidence == "medium"
    assert result.scenarios[1].confidence == "low"


# ---------------------------------------------------------------------------
# detect_gaps
# ---------------------------------------------------------------------------


def test_detect_gaps_returns_gap_marked_scenarios():
    gw = _gw()
    existing = ScenarioSet(
        spec_name="csv-bom",
        spec_version=1,
        scenarios=[
            Scenario(id="T1", title="Existing one", acceptance_ref=0, source="spec"),
            Scenario(id="T2", title="Existing two", acceptance_ref=1, source="spec"),
        ],
    )
    payload = {
        "gaps": [
            {
                "title": "Empty CSV",
                "given": ["the file is empty"],
                "when": ["the importer runs"],
                "then": ["a friendly empty-state message is logged"],
                "note": "Spec is silent on empty input",
                "confidence": "medium",
            },
            {
                "title": "Malformed BOM",
                "note": "What if the BOM is corrupted?",
                "confidence": "low",
            },
        ]
    }

    with patch.object(gw, "call", return_value=_gw_resp(payload)) as mock:
        gaps = Generator(gw).detect_gaps(_spec(), existing)

    assert len(gaps) == 2
    assert all(isinstance(g, Scenario) for g in gaps)
    assert all(g.source == "gap" for g in gaps)
    assert all(g.acceptance_ref is None for g in gaps)
    # IDs offset past existing scenarios
    assert gaps[0].id == "G3"
    assert gaps[1].id == "G4"
    assert gaps[0].note == "Spec is silent on empty input"
    # Planner role + spec passed in
    assert mock.call_args.kwargs["role"] == "planner"
    user_msg = mock.call_args.kwargs["messages"][1]["content"]
    assert "Existing one" in user_msg


def test_detect_gaps_convenience_function():
    gw = _gw()
    existing = ScenarioSet(spec_name="x", spec_version=1)
    payload = {"gaps": [{"title": "lone gap", "note": "see spec"}]}

    with patch.object(gw, "call", return_value=_gw_resp(payload)):
        gaps = detect_gaps(_spec(), existing, gw)

    assert len(gaps) == 1
    assert gaps[0].source == "gap"
    assert gaps[0].id == "G1"


def test_detect_gaps_returns_empty_when_model_says_no_gaps():
    gw = _gw()
    existing = ScenarioSet(spec_name="x", spec_version=1)

    with patch.object(gw, "call", return_value=_gw_resp({"gaps": []})):
        gaps = Generator(gw).detect_gaps(_spec(), existing)

    assert gaps == []


def test_detect_gaps_handles_unparseable_response():
    gw = _gw()
    existing = ScenarioSet(spec_name="x", spec_version=1)

    with patch.object(gw, "call", return_value=_gw_resp("???")):
        gaps = Generator(gw).detect_gaps(_spec(), existing)

    assert gaps == []


# ---------------------------------------------------------------------------
# to_text rendering
# ---------------------------------------------------------------------------


def test_to_text_renders_scenarios_in_section_7_1_format():
    s = ScenarioSet(
        spec_name="pills",
        spec_version=2,
        scenarios=[
            Scenario(
                id="T4",
                title="Mom sees her pills for today",
                given=["she has 3 pills scheduled today"],
                when=["she opens the home screen"],
                then=[
                    "she sees 3 pill cards",
                    "each card shows the pill name in large text (≥24pt)",
                ],
                acceptance_ref=2,
                source="spec",
            ),
        ],
    )
    out = to_text(s)

    assert "# pills v2" in out
    assert "[✓] T4  Mom sees her pills for today" in out
    assert "    Given she has 3 pills scheduled today" in out
    assert "    When she opens the home screen" in out
    assert "    Then she sees 3 pill cards" in out
    assert "    Then each card shows the pill name in large text (≥24pt)" in out


def test_to_text_marks_gap_scenarios_with_warning_glyph():
    s = ScenarioSet(
        spec_name="pills",
        spec_version=1,
        scenarios=[
            Scenario(
                id="G9",
                title="Empty state",
                given=["no pills are scheduled"],
                when=["she opens the home screen"],
                then=["she sees a friendly empty state"],
                source="gap",
                note="Spec doesn't mention empty state",
            ),
        ],
    )
    out = to_text(s)

    assert "[⚠] G9  Empty state  GAP DETECTED" in out
    assert "    note: Spec doesn't mention empty state" in out


def test_to_text_show_impl_includes_acceptance_ref():
    s = ScenarioSet(
        spec_name="x",
        spec_version=1,
        scenarios=[Scenario(id="T1", title="t", acceptance_ref=0, source="spec")],
    )
    plain = to_text(s, show_impl=False)
    technical = to_text(s, show_impl=True)

    assert "covers acceptance #0" not in plain
    assert "(covers acceptance #0)" in technical


def test_to_text_handles_empty_scenario_set():
    s = ScenarioSet(spec_name="empty", spec_version=1)
    out = to_text(s)

    assert "empty v1" in out
    assert "(no scenarios yet)" in out


# ---------------------------------------------------------------------------
# YAML round-trip
# ---------------------------------------------------------------------------


def test_yaml_round_trip(tmp_path):
    original = ScenarioSet(
        spec_name="csv-bom",
        spec_version=1,
        scenarios=[
            Scenario(
                id="T1",
                title="All rows imported",
                given=["a CSV with 3 rows"],
                when=["the importer runs"],
                then=["all 3 rows are loaded"],
                acceptance_ref=0,
                source="spec",
                confidence="high",
            ),
            Scenario(
                id="G2",
                title="Empty CSV",
                given=["the file is empty"],
                when=["the importer runs"],
                then=["empty-state message logged"],
                acceptance_ref=None,
                source="gap",
                confidence="medium",
                note="not in spec",
            ),
        ],
        generated_by="t/p",
        generated_at="2026-04-26T19:00:00Z",
        cost_usd=0.005,
    )
    path = tmp_path / "csv-bom.scenarios.yaml"

    written = write_yaml(original, path)
    assert written == path
    assert path.exists()

    loaded = read_yaml(path)
    assert loaded == original


def test_read_yaml_returns_none_for_missing_file(tmp_path):
    assert read_yaml(tmp_path / "nope.yaml") is None


def test_write_yaml_creates_parent_directories(tmp_path):
    s = ScenarioSet(spec_name="x", spec_version=1)
    path = tmp_path / "deeply" / "nested" / "dir" / "x.yaml"

    write_yaml(s, path)

    assert path.exists()


# ---------------------------------------------------------------------------
# top-level package re-exports
# ---------------------------------------------------------------------------


def test_top_level_package_re_exports():
    """`from heap import generate, detect_gaps, Scenario, ScenarioSet` works."""
    import heap

    assert hasattr(heap, "Scenario")
    assert hasattr(heap, "ScenarioSet")
    assert hasattr(heap, "generate")
    assert hasattr(heap, "detect_gaps")
    # generate() and detect_gaps() exist as callables, not just symbols
    assert callable(heap.generate)
    assert callable(heap.detect_gaps)


# ---------------------------------------------------------------------------
# guard rails
# ---------------------------------------------------------------------------


def test_scenario_rejects_invalid_source():
    """Pydantic Literal type should reject unknown source values."""
    with pytest.raises(ValidationError):
        Scenario(id="T1", title="t", source="invented")  # type: ignore[arg-type]


# ---------------------------------------------------------------------------
# propose_acceptance — S4.P3 spec-amendment helper
# ---------------------------------------------------------------------------


def test_propose_acceptance_returns_planner_text():
    from heap.scenarios import propose_acceptance

    gw = _gw()
    payload = {"criterion": "After fix: empty CSV logs an empty-state message"}
    scen = Scenario(
        id="M1",
        title="Edge: empty file",
        given=["the file is empty"],
        when=["the importer runs"],
        then=["an empty-state message is logged"],
        source="manual",
    )

    with patch.object(gw, "call", return_value=_gw_resp(payload)) as mock:
        result = propose_acceptance(scen, _spec(), gw)

    assert result == "After fix: empty CSV logs an empty-state message"
    assert mock.call_args.kwargs["role"] == "planner"
    user_msg = mock.call_args.kwargs["messages"][1]["content"]
    assert "M1" in user_msg
    assert "the file is empty" in user_msg


def test_propose_acceptance_falls_back_when_unparseable():
    """Unparseable response → deterministic 'After <title>: <then>' fallback."""
    from heap.scenarios import propose_acceptance

    gw = _gw()
    scen = Scenario(
        id="M1",
        title="Edge: empty file.",
        given=[],
        when=[],
        then=["empty-state shown"],
        source="manual",
    )

    with patch.object(gw, "call", return_value=_gw_resp("not json at all")):
        result = propose_acceptance(scen, _spec(), gw)

    assert "Edge: empty file" in result
    assert "empty-state shown" in result


def test_propose_acceptance_falls_back_when_criterion_missing():
    from heap.scenarios import propose_acceptance

    gw = _gw()
    scen = Scenario(id="M1", title="x", then=["y"], source="manual")

    with patch.object(gw, "call", return_value=_gw_resp({"other_key": "z"})):
        result = propose_acceptance(scen, _spec(), gw)

    # Fallback is non-empty
    assert isinstance(result, str)
    assert result.strip()
