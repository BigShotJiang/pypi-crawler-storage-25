# HEAP examples

Three runnable examples, ordered from simplest to most complete. Each one
proves a different layer of HEAP works end-to-end.

| Example | Layer | Cost | What it proves |
|---|---|---|---|
| [`hello_gateway.py`](hello_gateway.py) | L1 — Gateway | ~$0.001 | One Anthropic call, cost + token reporting, role routing |
| [`weather_agent.py`](weather_agent.py) | L4 — Agent runtime | ~$0.01-0.03 | PEV loop (Plan→Execute→Verify), hooks firing, `@tool` dispatch |
| [`csv-bom/`](csv-bom/README.md) | Full HEAP loop | ~$0.05-0.20 | Spec → Scenarios → Plan → Run against a real bug |

## Setup (once)

From the repo root:

```bash
make install                # creates .venv with editable heap-ai install
cp .env.example .env        # add your ANTHROPIC_API_KEY
```

## Run them

```bash
# 1. The simplest possible HEAP usage — one model call.
.venv/bin/python examples/hello_gateway.py

# 2. Watch hooks + tools + a PEV cycle.
.venv/bin/python examples/weather_agent.py

# 3. The full loop — see examples/csv-bom/README.md for the walkthrough.
```

## Offline alternative

If you don't want to spend API budget yet, every example has a
deterministic test counterpart in `tests/`:

```bash
.venv/bin/pytest tests/test_gateway.py     # mocked Gateway
.venv/bin/pytest tests/test_agent.py       # mocked PEV loop
.venv/bin/pytest tests/test_s7_smoke.py    # full HEAP loop, mocked planner
```

These run in seconds and cost nothing.
