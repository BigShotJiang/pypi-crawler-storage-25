"""hello_gateway — proves the Layer 1 Model Gateway works end-to-end.

Run from the repo root:

    cp .env.example .env        # then put your real ANTHROPIC_API_KEY in .env
    pip install -e .            # (or `make install`)
    python examples/hello_gateway.py

What it does:
  1. Loads .env (python-dotenv).
  2. Constructs a Gateway with the v0.1 default model roles per SPEC §3.
  3. Sends a small prompt via the *planner* role.
  4. Prints the response, model used, token counts, cost, and latency.

This is the S1 acceptance gate: a real Anthropic call completes and
cost is reported.
"""

from __future__ import annotations

import os
import sys
import textwrap

from dotenv import load_dotenv

from heap import Gateway

# v0.1 default models per SPEC §3.
PLANNER_MODEL = "anthropic/claude-opus-4-7"
WORKER_MODEL = "anthropic/claude-sonnet-4-6"
FAST_MODEL = "anthropic/claude-haiku-4-5-20251001"


def _bail(msg: str) -> int:
    print(f"\n[hello_gateway] {msg}\n", file=sys.stderr)
    return 1


def main() -> int:
    load_dotenv()

    if not os.getenv("ANTHROPIC_API_KEY"):
        return _bail(
            "ANTHROPIC_API_KEY is not set. Create a `.env` from `.env.example` "
            "and put your real key there, or `export ANTHROPIC_API_KEY=...` in "
            "your shell."
        )

    gw = Gateway(
        planner=PLANNER_MODEL,
        worker=WORKER_MODEL,
        fast=FAST_MODEL,
        budget_usd=None,  # no cap for the demo
    )

    prompt = textwrap.dedent(
        """\
        Reply with one short sentence (<= 12 words) describing what HEAP is
        for. Be concrete; do not include disclaimers or filler.
        """
    ).strip()

    print(f"[hello_gateway] sending prompt to {PLANNER_MODEL} ...")
    response = gw.call(
        role="planner",
        messages=[
            {"role": "user", "content": prompt},
        ],
        max_tokens=80,
    )

    bar = "─" * 64
    print(bar)
    print(f"  model:     {response.model_used}")
    print(f"  latency:   {response.latency_ms:.0f} ms")
    print(f"  tokens:    in={response.tokens_in}  out={response.tokens_out}")
    print(f"  cost:      ${response.cost_usd:.6f}")
    print(f"  fallback:  {response.used_fallback}")
    print(bar)
    print(f"  content:   {response.content}")
    print(bar)
    print(
        f"\n[hello_gateway] cumulative spend on this Gateway: "
        f"${gw.spent_usd:.6f}  (calls: {gw.calls_made})"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
