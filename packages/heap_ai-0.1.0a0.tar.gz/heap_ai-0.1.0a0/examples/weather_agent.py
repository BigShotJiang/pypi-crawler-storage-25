"""weather_agent — proves the Agent runtime, hooks, and @tool end-to-end.

This is the S2 acceptance gate: a real PEV cycle including a tool call,
all phases logged, hooks firing.

The ``get_weather`` tool returns hardcoded data — no external API, so
the demo is deterministic and free to run repeatedly. The point is to
demonstrate dispatch, not to actually fetch weather.

Usage::

    cp .env.example .env       # then put your real ANTHROPIC_API_KEY in .env
    make weather               # or: python examples/weather_agent.py
"""

from __future__ import annotations

import logging
import os
import sys
import textwrap

from dotenv import load_dotenv

from heap import Agent, Warn, tool

# v0.1 default models per SPEC §3.
PLANNER_MODEL = "anthropic/claude-opus-4-7"
WORKER_MODEL = "anthropic/claude-sonnet-4-6"


@tool
def get_weather(city: str) -> str:
    """Return a one-line weather summary for `city`.

    NOTE: this returns hardcoded fake data — it does NOT hit a real
    weather API. The point is to demonstrate tool dispatch in HEAP.
    """
    fake_data = {
        "Lisbon": "Mild, 18C, partly cloudy",
        "Porto": "Cool, 14C, light rain",
        "Sao Paulo": "Warm, 24C, scattered showers",
        "Rio de Janeiro": "Hot, 30C, sunny",
        "New York": "Cold, 4C, clear skies",
        "London": "Damp, 9C, overcast",
        "Tokyo": "Mild, 16C, breezy",
    }
    return fake_data.get(city, f"No data for {city!r} in this demo dataset.")


def _bail(msg: str) -> int:
    print(f"\n[weather_agent] {msg}\n", file=sys.stderr)
    return 1


def main() -> int:
    load_dotenv()
    if not os.getenv("ANTHROPIC_API_KEY"):
        return _bail(
            "ANTHROPIC_API_KEY is not set. Create a .env from .env.example "
            "or `export ANTHROPIC_API_KEY=...` first."
        )

    # Compact INFO logs for visibility into hook firing + agent state.
    logging.basicConfig(level=logging.INFO, format="%(levelname)s | %(name)s: %(message)s")

    contract = textwrap.dedent("""
        Look up the weather for the requested city using the get_weather tool,
        then produce a one-sentence weather report mentioning the city by name.
        Keep the final answer under 25 words.
    """).strip()

    agent = Agent(
        name="weather-reporter",
        model=WORKER_MODEL,
        planner_model=PLANNER_MODEL,
        contract=contract,
        tools=[get_weather],
    )

    # ---- Hooks: visible PEV phase tracing + a Warn after each tool call ----

    @agent.hook("pre_phase")
    def trace_phase_in(ctx) -> None:
        print(f"  ▶ {ctx.phase.upper():<7}  iter={ctx.iteration}")

    @agent.hook("pre_tool_call")
    def trace_tool_in(ctx) -> None:
        print(f"      ↳ tool: {ctx.tool}({ctx.args})")

    @agent.hook("post_tool_call")
    def trace_tool_out(ctx) -> Warn:
        print(f"      ← tool: {ctx.tool} → {ctx.result!r}")
        return Warn(f"used {ctx.tool}")

    # ---- Run ---------------------------------------------------------------

    task = "What's the weather in Lisbon?"
    bar = "─" * 64
    print(bar)
    print(f"  weather_agent · task: {task!r}")
    print(bar)

    result = agent.run(task)

    print(bar)
    print(f"  verify.passed:  {result.verify_outcome.passed}")
    print(f"  verify.reason:  {result.verify_outcome.reason}")
    print(f"  replans:        {result.replan_count}")
    print(f"  hook_blocked:   {result.hook_blocked}")
    print(f"  tool_calls:     {len(result.tool_calls_made)}")
    for i, tc in enumerate(result.tool_calls_made):
        print(f"     [{i}] {tc['tool']}({tc['args']}) → {tc['result']!r}")
    print(f"  warnings:       {result.warnings}")
    print(f"  phases:         {len(result.phase_log)}")
    for p in result.phase_log:
        print(
            f"     - {p.phase:<7} iter={p.iteration} "
            f"{p.model_used}  "
            f"in={p.tokens_in:<5} out={p.tokens_out:<4} "
            f"${p.cost_usd:.4f}  {p.latency_ms:.0f}ms"
        )
    print(f"  total cost:     ${result.total_cost_usd:.6f}")
    print(f"  total tokens:   in={result.total_tokens_in}  out={result.total_tokens_out}")
    print(bar)
    print(f"\n  FINAL ANSWER:\n  {result.content}\n")

    return 0 if result.verify_outcome.passed else 1


if __name__ == "__main__":
    raise SystemExit(main())
