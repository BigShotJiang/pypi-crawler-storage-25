"""Tests for the buggy importer.

The first test demonstrates the bug. After HEAP walks the spec → scenarios
→ plan → run loop and an executor applies the fix, all tests pass.
"""

from __future__ import annotations

from pathlib import Path

from csv_importer import import_rows

FIXTURE_DIR = Path(__file__).parent / "fixtures"


def test_imports_all_rows_from_bom_file():
    rows = import_rows(FIXTURE_DIR / "with_bom.csv")
    assert len(rows) == 3, f"expected 3 rows, got {len(rows)}"
    # The first header should be 'name', not '﻿name'.
    assert "name" in rows[0]
    assert rows[0]["name"] == "alice"


def test_imports_all_rows_from_plain_file():
    rows = import_rows(FIXTURE_DIR / "plain.csv")
    assert len(rows) == 3
    assert rows[0]["name"] == "alice"


def test_no_bom_leaks_into_keys():
    """No header should contain the BOM character."""
    rows = import_rows(FIXTURE_DIR / "with_bom.csv")
    assert rows, "fixture should have rows"
    for key in rows[0]:
        assert "﻿" not in key, f"BOM leaked into header {key!r}"
