# `csv-bom` — HEAP smoke walkthrough

A tiny buggy package used to demonstrate HEAP's spec → scenarios → plan →
run loop end-to-end on a real bug.

**The bug.** `csv_importer.py` opens files with `encoding='utf-8'`,
which leaves a UTF-8 BOM (`﻿`) attached to the first column header.
Anything that does `row['name']` then misses, because the actual key is
`'﻿name'`.

**The fix.** Use `encoding='utf-8-sig'` so the BOM is consumed during
decoding.

---

## See the bug

```bash
cd examples/csv-bom
.venv/bin/pytest tests/         # 2 failures expected
```

You should see:

```
AssertionError: BOM leaked into header '﻿name'
```

## Walk the HEAP loop

From the **repo root** (so `heap` is on PATH via the project venv):

```bash
# 1. Spec the bug — interactive interrogator (planner: Opus, ~$0.05)
.venv/bin/heap spec new --mode bug --audience developer --name csv-bom

# 2. Generate scenarios from the spec — and a gap pass (planner, ~$0.05)
.venv/bin/heap scenarios generate csv-bom

# 3. Review and approve scenarios
.venv/bin/heap scenarios review csv-bom         # press [a] when ready

# 4. Generate the implementation plan (planner, ~$0.05)
.venv/bin/heap plan generate csv-bom

# 5. Inspect and approve
.venv/bin/heap plan show csv-bom
.venv/bin/heap plan approve csv-bom --by you

# 6. Run the engine (operator confirms each phase)
.venv/bin/heap run start csv-bom
.venv/bin/heap run list                          # find the run id
.venv/bin/heap run show <run-id>                 # snapshot
.venv/bin/heap run approve <run-id> --by you     # advance past sprint gates
.venv/bin/heap run resume <run-id>               # continue
```

**While it runs, in another terminal:**

```bash
.venv/bin/heap watch <run-id>          # live tail
.venv/bin/heap status                  # current snapshot
```

## What HEAP does for you here

HEAP doesn't write the code fix itself in v0.1 — its value is the
**approval-gated lifecycle**: every step (spec, scenarios, plan, each
sprint) is approved before the next, and every transition is persisted
so a crash mid-run can resume cleanly. Auto-retry catches a single flaky
phase per §9.3. The §10 plan view + §11.1 status line keep you (and any
future agent) aligned on where things are.

The deterministic offline version of this exact flow lives at
`tests/test_s7_smoke.py` — that test exercises the full chain via a
fixture executor that applies the fix, verifying the bug is gone after
the run completes.
