"""Tiny CSV importer with the UTF-8 BOM bug HEAP demonstrates fixing.

The bug: opening a UTF-8 BOM file with ``encoding='utf-8'`` leaves the
zero-width BOM character ``﻿`` attached to the first header. Anything
that does ``row['name']`` then misses, because the first key is actually
``'﻿name'``.

The fix is to read with ``encoding='utf-8-sig'`` (or strip the BOM
defensively from the first header). This file ships with the bug; the
HEAP smoke walkthrough demonstrates the agent loop fixing it.
"""

from __future__ import annotations

import csv
from pathlib import Path


def import_rows(path: str | Path) -> list[dict[str, str]]:
    """Return all rows of ``path`` as dicts keyed by header.

    Buggy: uses ``encoding='utf-8'`` so a BOM at the file head leaks into
    the first header name.
    """
    with open(path, encoding="utf-8") as f:  # ← bug: should be utf-8-sig
        reader = csv.DictReader(f)
        return [dict(row) for row in reader]
