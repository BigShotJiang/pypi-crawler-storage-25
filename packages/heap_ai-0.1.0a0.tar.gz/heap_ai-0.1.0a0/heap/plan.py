"""Plan generation — bridge between spec + scenarios and the run engine.

Per SPEC §8 the plan is the contract Vicente approves before any work
starts. It contains the sprint/phase breakdown, deliverables, tests,
gates, risks, scope boundaries, and rough estimates.

This module covers S5.P1: dataclasses + generation. The §10 ASCII
renderer (S5.P2), estimate/risk heuristics (S5.P3), and amendment
flow (S5.P4) live elsewhere.

Design notes:
  - Models stay simple Pydantic v2 — no business logic on the model.
  - The planner LLM produces a draft; the heuristics layer (S5.P3)
    fills in or overrides estimates and risks deterministically so the
    plan is auditable.
  - JSON parsing is permissive (fenced code, embedded prose) the same
    way scenarios.py does it.
"""

from __future__ import annotations

import json
import logging
import re
from datetime import UTC, datetime
from pathlib import Path
from typing import Any, Literal

import yaml
from pydantic import BaseModel, Field

from heap.gateway import Gateway, GatewayResponse
from heap.scenarios import ScenarioSet
from heap.spec.structurer import StructuredSpec

logger = logging.getLogger(__name__)


Severity = Literal["low", "medium", "high"]
ALLOWED_SEVERITIES: tuple[Severity, ...] = ("low", "medium", "high")


# ---------------------------------------------------------------------------
# Models
# ---------------------------------------------------------------------------


class Phase(BaseModel):
    """A single PEV phase inside a sprint (per SPEC §8.1)."""

    id: str  # e.g. "S1.P2"
    name: str
    agent: str = "worker/Sonnet"  # worker / planner / fast / by-hand
    deliverables: list[str] = Field(default_factory=list)
    tests: list[str] = Field(default_factory=list)
    gate: str = ""
    cost_estimate_usd: float = 0.0
    duration_estimate_min: int = 0


class Sprint(BaseModel):
    """An ordered group of phases ending in an approval gate."""

    id: str  # e.g. "S2"
    name: str
    goal: str = ""
    phases: list[Phase] = Field(default_factory=list)
    gate: str = ""
    cost_estimate_usd: float = 0.0
    duration_estimate_min: int = 0


class RiskItem(BaseModel):
    """One entry in the plan's risk register."""

    description: str
    severity: Severity = "medium"
    mitigation: str = ""


AmendmentKind = Literal[
    "add_phase",
    "add_deliverable",
    "add_test",
    "change_gate",
    "add_risk",
    "add_scope_out",
]
ALLOWED_AMENDMENT_KINDS: tuple[AmendmentKind, ...] = (
    "add_phase",
    "add_deliverable",
    "add_test",
    "change_gate",
    "add_risk",
    "add_scope_out",
)


class Amendment(BaseModel):
    """A proposed (or applied) modification to an existing plan (SPEC §8.2)."""

    kind: AmendmentKind
    sprint_id: str = ""  # required for sprint-scoped amendments
    phase_id: str = ""  # required for phase-scoped amendments
    payload: dict[str, Any] = Field(default_factory=dict)
    rationale: str = ""
    cost_delta_usd: float = 0.0
    duration_delta_min: int = 0
    applied_at: str = ""  # set when apply_amendment runs


class Plan(BaseModel):
    """Approval-ready plan document.

    The plan is bound to a specific spec version; regenerating against a
    new spec version produces a new plan with a new ``plan_id``.
    """

    plan_id: str
    spec_name: str
    spec_version: int
    spec_ref: str  # e.g. "csv-bom v1" — convenience for human reading
    rev: int = 1
    sprints: list[Sprint] = Field(default_factory=list)
    risk_register: list[RiskItem] = Field(default_factory=list)
    scope_in: list[str] = Field(default_factory=list)
    scope_out: list[str] = Field(default_factory=list)
    human_approval_gates: list[str] = Field(default_factory=list)
    estimated_cost_usd_low: float = 0.0
    estimated_cost_usd_high: float = 0.0
    estimated_duration_min_low: int = 0
    estimated_duration_min_high: int = 0
    estimated_tokens_total: int = 0
    generated_by: str = ""
    generated_at: str = ""  # ISO 8601, UTC
    cost_usd: float = 0.0  # cost of *generating* the plan
    approved_at: str | None = None
    approved_by: str = ""
    revisions: list[Amendment] = Field(default_factory=list)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _now_iso() -> str:
    return datetime.now(UTC).strftime("%Y-%m-%dT%H:%M:%SZ")


def _make_plan_id(spec_name: str, spec_version: int) -> str:
    """``<spec_name>-v<N>-<YYYYMMDDHHMMSS>`` — collision-free per second."""
    stamp = datetime.now(UTC).strftime("%Y%m%d%H%M%S")
    return f"{spec_name}-v{spec_version}-{stamp}"


_JSON_OBJECT_RE = re.compile(r"\{.*\}", re.DOTALL)


def _extract_json_object(content: str | None) -> dict[str, Any] | None:
    """Permissively pull a top-level JSON object out of an LLM reply."""
    if not content:
        return None
    cleaned = content.strip()
    if cleaned.startswith("```"):
        cleaned = re.sub(r"^```(?:json)?\s*", "", cleaned)
        cleaned = re.sub(r"\s*```$", "", cleaned)
    if not cleaned.startswith("{"):
        m = _JSON_OBJECT_RE.search(cleaned)
        if not m:
            return None
        cleaned = m.group(0)
    try:
        data = json.loads(cleaned)
    except json.JSONDecodeError as e:
        logger.debug("plan: JSON decode failed: %s", e)
        return None
    return data if isinstance(data, dict) else None


def _coerce_str_list(value: Any) -> list[str]:
    if value is None:
        return []
    if isinstance(value, list):
        return [str(v).strip() for v in value if str(v).strip()]
    if isinstance(value, str):
        s = value.strip()
        return [s] if s else []
    return [str(value)]


def _coerce_severity(value: Any) -> Severity:
    if isinstance(value, str) and value.lower() in ALLOWED_SEVERITIES:
        return value.lower()  # type: ignore[return-value]
    return "medium"


# ---------------------------------------------------------------------------
# Prompts
# ---------------------------------------------------------------------------


_GENERATE_SYSTEM = (
    "You produce a structured implementation plan for a software project, "
    "given a spec and (optionally) the approved scenarios. Apply the "
    "HEAP harness pattern:\n"
    "  - Break work into 2-6 sprints, each ending in an approval gate.\n"
    "  - Each sprint has 2-5 phases.\n"
    "  - Each phase has: id (e.g. 'S1.P2'), name, agent (worker/Sonnet, "
    "planner/Opus, fast/Haiku, or by-hand), deliverables, tests, gate.\n"
    "  - Risks: list 3-7 concrete risks with severity (low|medium|high) and "
    "a brief mitigation.\n"
    "  - Scope: split features into `scope_in` and `scope_out` lists.\n"
    "  - Estimates are best-effort ranges. Use 0 if unknown — heuristics "
    "will refine them in a later pass.\n\n"
    "Output JSON ONLY (no prose, no markdown fences):\n"
    "{\n"
    '  "sprints": [\n'
    '    {"id":"S1","name":"...","goal":"...","gate":"...","phases":[\n'
    '      {"id":"S1.P1","name":"...","agent":"worker/Sonnet",'
    '"deliverables":["..."],"tests":["..."],"gate":"..."}\n'
    "    ]}\n"
    "  ],\n"
    '  "risk_register": [{"description":"...","severity":"medium","mitigation":"..."}],\n'
    '  "scope_in": ["..."],\n'
    '  "scope_out": ["..."]\n'
    "}"
)


def _build_user_prompt(spec: StructuredSpec, scenarios: ScenarioSet | None) -> str:
    spec_yaml = yaml.safe_dump(spec.model_dump(), sort_keys=False, allow_unicode=True)
    scenario_lines: list[str] = []
    if scenarios is not None:
        for s in scenarios.scenarios:
            scenario_lines.append(f"  [{s.source}] {s.id} {s.title}")
    scenario_block = "\n".join(scenario_lines) if scenario_lines else "  (none provided)"
    return (
        f"SPEC ({spec.name} v{spec.version}, mode={spec.mode}):\n\n"
        "```yaml\n"
        f"{spec_yaml}"
        "```\n\n"
        f"APPROVED SCENARIOS:\n{scenario_block}\n\n"
        "Produce the plan JSON. Keep deliverables/tests concrete and short."
    )


# ---------------------------------------------------------------------------
# PlanGenerator
# ---------------------------------------------------------------------------


class PlanGenerator:
    """Generate a Plan from a spec (and optional ScenarioSet)."""

    def __init__(self, gateway: Gateway) -> None:
        self.gateway = gateway

    def generate(
        self,
        spec: StructuredSpec,
        scenarios: ScenarioSet | None = None,
        *,
        apply_heuristics_pass: bool = True,
    ) -> Plan:
        resp = self.gateway.call(
            role="planner",
            messages=[
                {"role": "system", "content": _GENERATE_SYSTEM},
                {"role": "user", "content": _build_user_prompt(spec, scenarios)},
            ],
            max_tokens=4000,
        )
        if not isinstance(resp, GatewayResponse):
            raise RuntimeError(f"Gateway returned non-response object: {type(resp)!r}")

        sprints, risks, scope_in, scope_out = self._parse(resp.content)

        gates = ["after_plan_review"] + [f"after_{s.id}" for s in sprints]
        plan = Plan(
            plan_id=_make_plan_id(spec.name, spec.version),
            spec_name=spec.name,
            spec_version=spec.version,
            spec_ref=f"{spec.name} v{spec.version}",
            sprints=sprints,
            risk_register=risks,
            scope_in=scope_in,
            scope_out=scope_out,
            human_approval_gates=gates,
            generated_by=resp.model_used,
            generated_at=_now_iso(),
            cost_usd=resp.cost_usd,
        )
        if apply_heuristics_pass:
            plan = apply_heuristics(plan)
        return plan

    # ------------------------------------------------------------------
    # Internals
    # ------------------------------------------------------------------

    @classmethod
    def _parse(
        cls, content: str | None
    ) -> tuple[list[Sprint], list[RiskItem], list[str], list[str]]:
        data = _extract_json_object(content)
        if not data:
            return [], [], [], []
        sprints = cls._parse_sprints(data.get("sprints"))
        risks = cls._parse_risks(data.get("risk_register"))
        scope_in = _coerce_str_list(data.get("scope_in"))
        scope_out = _coerce_str_list(data.get("scope_out"))
        return sprints, risks, scope_in, scope_out

    @classmethod
    def _parse_sprints(cls, raw: Any) -> list[Sprint]:
        if not isinstance(raw, list):
            return []
        out: list[Sprint] = []
        for item in raw:
            if not isinstance(item, dict):
                continue
            sid = (item.get("id") or "").strip()
            name = (item.get("name") or "").strip()
            if not sid or not name:
                continue
            phases = cls._parse_phases(item.get("phases"))
            out.append(
                Sprint(
                    id=sid,
                    name=name,
                    goal=(item.get("goal") or "").strip(),
                    phases=phases,
                    gate=(item.get("gate") or "").strip(),
                    cost_estimate_usd=float(item.get("cost_estimate_usd") or 0.0),
                    duration_estimate_min=int(item.get("duration_estimate_min") or 0),
                )
            )
        return out

    @classmethod
    def _parse_phases(cls, raw: Any) -> list[Phase]:
        if not isinstance(raw, list):
            return []
        out: list[Phase] = []
        for item in raw:
            if not isinstance(item, dict):
                continue
            pid = (item.get("id") or "").strip()
            name = (item.get("name") or "").strip()
            if not pid or not name:
                continue
            out.append(
                Phase(
                    id=pid,
                    name=name,
                    agent=(item.get("agent") or "worker/Sonnet").strip(),
                    deliverables=_coerce_str_list(item.get("deliverables")),
                    tests=_coerce_str_list(item.get("tests")),
                    gate=(item.get("gate") or "").strip(),
                    cost_estimate_usd=float(item.get("cost_estimate_usd") or 0.0),
                    duration_estimate_min=int(item.get("duration_estimate_min") or 0),
                )
            )
        return out

    @classmethod
    def _parse_risks(cls, raw: Any) -> list[RiskItem]:
        if not isinstance(raw, list):
            return []
        out: list[RiskItem] = []
        for item in raw:
            if not isinstance(item, dict):
                continue
            desc = (item.get("description") or "").strip()
            if not desc:
                continue
            out.append(
                RiskItem(
                    description=desc,
                    severity=_coerce_severity(item.get("severity")),
                    mitigation=(item.get("mitigation") or "").strip(),
                )
            )
        return out


# ---------------------------------------------------------------------------
# Convenience top-level + YAML round-trip
# ---------------------------------------------------------------------------


def generate(
    spec: StructuredSpec,
    gateway: Gateway,
    scenarios: ScenarioSet | None = None,
) -> Plan:
    """Generate a plan. Convenience wrapper around PlanGenerator."""
    return PlanGenerator(gateway).generate(spec, scenarios)


def write_plan(plan: Plan, path: str | Path) -> Path:
    """Persist a Plan to YAML. Returns the resolved path."""
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    text = yaml.safe_dump(plan.model_dump(), sort_keys=False, allow_unicode=True)
    p.write_text(text, encoding="utf-8")
    return p


def read_plan(path: str | Path) -> Plan | None:
    """Load a Plan from YAML. Returns None if the file is absent."""
    p = Path(path)
    if not p.exists():
        return None
    data = yaml.safe_load(p.read_text(encoding="utf-8"))
    if not isinstance(data, dict):
        return None
    return Plan.model_validate(data)


# ---------------------------------------------------------------------------
# Heuristics — deterministic estimate + risk register augmentation
# ---------------------------------------------------------------------------
#
# The planner LLM produces structure; the heuristics layer fills in
# numbers and flags structural risks. Heuristics are intentionally
# coarse: they're a sanity-check baseline, not a real estimator.
# Numbers below come from rough HEAP-build calibration (a phase like
# "write a Pydantic module + 15 tests" tends to be ~20-30 minutes of
# Sonnet effort).

# Per-agent base profile: (base_minutes, per_deliverable_min, per_test_min,
# base_cost_usd, per_deliverable_cost, per_test_cost, tokens_estimate).
_AGENT_PROFILE: dict[str, tuple[int, int, int, float, float, float, int]] = {
    "worker": (20, 8, 4, 0.30, 0.10, 0.05, 12000),
    "planner": (35, 12, 8, 1.10, 0.40, 0.20, 8000),
    "fast": (5, 2, 1, 0.02, 0.01, 0.005, 4000),
    "by-hand": (15, 5, 3, 0.0, 0.0, 0.0, 0),
}
_DEFAULT_AGENT_KEY = "worker"


def _agent_key(agent: str) -> str:
    """Map ``role/Model`` strings to a profile key."""
    head = agent.split("/", 1)[0].lower().strip() if agent else ""
    if head in _AGENT_PROFILE:
        return head
    if head in {"sonnet", "opus", "haiku"}:
        return {"sonnet": "worker", "opus": "planner", "haiku": "fast"}[head]
    return _DEFAULT_AGENT_KEY


def _phase_baseline(phase: Phase) -> tuple[int, float, int]:
    """Return ``(duration_min, cost_usd, tokens)`` for a phase from heuristics."""
    base_min, per_d_min, per_t_min, base_c, per_d_c, per_t_c, tokens = _AGENT_PROFILE[
        _agent_key(phase.agent)
    ]
    n_d = max(len(phase.deliverables), 1)
    n_t = len(phase.tests)
    duration = base_min + per_d_min * n_d + per_t_min * n_t
    cost = base_c + per_d_c * n_d + per_t_c * n_t
    return duration, round(cost, 4), tokens


def _augment_risks(plan: Plan) -> list[RiskItem]:
    """Return a new risk_register with rule-based items added.

    Each rule emits a risk with a stable tag prefix. Dedupe is by tag:
    if any existing risk description contains all of the tag's tokens
    (case-insensitive), the heuristic skips that addition.
    """
    existing_descs = [r.description.lower().strip() for r in plan.risk_register]

    def _already_flagged(*tokens: str) -> bool:
        toks = [t.lower() for t in tokens if t]
        return any(all(t in e for t in toks) for e in existing_descs)

    additions: list[RiskItem] = []

    # Plans without sprints are degenerate — no structural heuristics apply.
    if not plan.sprints:
        return list(plan.risk_register)

    for sprint in plan.sprints:
        for phase in sprint.phases:
            if not phase.tests and not _already_flagged(phase.id, "no tests"):
                additions.append(
                    RiskItem(
                        description=f"Phase {phase.id} has no tests defined",
                        severity="medium",
                        mitigation="Add at least one test or mark explicitly as no-test.",
                    )
                )
        if len(sprint.phases) > 5 and not _already_flagged(sprint.id, "phases"):
            additions.append(
                RiskItem(
                    description=f"Sprint {sprint.id} has {len(sprint.phases)} phases (>5)",
                    severity="medium",
                    mitigation="Consider splitting into two sprints to keep gates frequent.",
                )
            )

    if not plan.scope_out and not _already_flagged("scope creep"):
        additions.append(
            RiskItem(
                description="Scope creep risk — explicitly-out list is empty",
                severity="medium",
                mitigation="Add explicit out-of-scope items so amendments require approval.",
            )
        )

    return list(plan.risk_register) + additions


def apply_heuristics(plan: Plan) -> Plan:
    """Fill 0-valued estimates and augment risks with rule-based items.

    Returns a *new* Plan; the input is not mutated. Idempotent: re-applying
    on a plan that already has filled estimates is a no-op for those
    fields, and risks are deduped on description.
    """
    new_sprints: list[Sprint] = []
    total_dur = 0
    total_cost = 0.0
    total_tokens = 0

    for sprint in plan.sprints:
        new_phases: list[Phase] = []
        sprint_dur = 0
        sprint_cost = 0.0
        for phase in sprint.phases:
            d, c, tok = _phase_baseline(phase)
            new_phase = phase.model_copy(
                update={
                    "duration_estimate_min": phase.duration_estimate_min or d,
                    "cost_estimate_usd": phase.cost_estimate_usd or c,
                }
            )
            new_phases.append(new_phase)
            sprint_dur += new_phase.duration_estimate_min
            sprint_cost += new_phase.cost_estimate_usd
            total_tokens += tok
        new_sprint = sprint.model_copy(
            update={
                "phases": new_phases,
                "duration_estimate_min": sprint.duration_estimate_min or sprint_dur,
                "cost_estimate_usd": sprint.cost_estimate_usd or round(sprint_cost, 4),
            }
        )
        new_sprints.append(new_sprint)
        total_dur += new_sprint.duration_estimate_min
        total_cost += new_sprint.cost_estimate_usd

    plan_with_estimates = plan.model_copy(
        update={
            "sprints": new_sprints,
            "estimated_cost_usd_low": plan.estimated_cost_usd_low or round(total_cost * 0.7, 2),
            "estimated_cost_usd_high": plan.estimated_cost_usd_high or round(total_cost * 1.4, 2),
            "estimated_duration_min_low": plan.estimated_duration_min_low or int(total_dur * 0.7),
            "estimated_duration_min_high": plan.estimated_duration_min_high or int(total_dur * 1.4),
            "estimated_tokens_total": plan.estimated_tokens_total or total_tokens,
        }
    )

    # Risk augmentation runs against the post-estimate plan
    enriched_risks = _augment_risks(plan_with_estimates)
    return plan_with_estimates.model_copy(update={"risk_register": enriched_risks})


# ---------------------------------------------------------------------------
# Plan amendments (SPEC §8.2)
# ---------------------------------------------------------------------------


class AmendmentError(ValueError):
    """Raised when an amendment cannot be applied (bad target, invalid kind)."""


def _find_sprint(plan: Plan, sprint_id: str) -> Sprint:
    for s in plan.sprints:
        if s.id == sprint_id:
            return s
    raise AmendmentError(f"sprint {sprint_id!r} not found in plan {plan.plan_id!r}")


def _find_phase(sprint: Sprint, phase_id: str) -> Phase:
    for p in sprint.phases:
        if p.id == phase_id:
            return p
    raise AmendmentError(f"phase {phase_id!r} not found in sprint {sprint.id!r}")


def apply_amendment(plan: Plan, amendment: Amendment) -> Plan:
    """Return a new plan with the amendment applied.

    Bumps ``plan.rev`` and appends to ``plan.revisions``. Approval flags
    are reset — every amendment requires re-approval per SPEC §1.5.
    Estimates are NOT recomputed automatically; callers can re-run
    ``apply_heuristics`` if they want refreshed rollups.
    """
    new_sprints = [s.model_copy(update={"phases": list(s.phases)}) for s in plan.sprints]
    sprint_lookup = {s.id: s for s in new_sprints}

    kind = amendment.kind
    if kind == "add_phase":
        if not amendment.sprint_id:
            raise AmendmentError("add_phase requires sprint_id")
        if amendment.sprint_id not in sprint_lookup:
            raise AmendmentError(f"sprint {amendment.sprint_id!r} not found")
        sprint = sprint_lookup[amendment.sprint_id]
        sprint.phases.append(Phase(**amendment.payload))

    elif kind == "add_deliverable":
        if not amendment.sprint_id or not amendment.phase_id:
            raise AmendmentError("add_deliverable requires sprint_id and phase_id")
        sprint = _find_sprint(_p_for(plan, new_sprints), amendment.sprint_id)
        # Replace phase in-place
        new_phases = []
        for p in sprint_lookup[amendment.sprint_id].phases:
            if p.id == amendment.phase_id:
                new_d = list(p.deliverables) + [amendment.payload.get("deliverable", "").strip()]
                new_d = [d for d in new_d if d]
                new_phases.append(p.model_copy(update={"deliverables": new_d}))
            else:
                new_phases.append(p)
        sprint_lookup[amendment.sprint_id].phases = new_phases

    elif kind == "add_test":
        if not amendment.sprint_id or not amendment.phase_id:
            raise AmendmentError("add_test requires sprint_id and phase_id")
        new_phases = []
        sprint = sprint_lookup.get(amendment.sprint_id)
        if sprint is None:
            raise AmendmentError(f"sprint {amendment.sprint_id!r} not found")
        for p in sprint.phases:
            if p.id == amendment.phase_id:
                new_t = list(p.tests) + [amendment.payload.get("test", "").strip()]
                new_t = [t for t in new_t if t]
                new_phases.append(p.model_copy(update={"tests": new_t}))
            else:
                new_phases.append(p)
        sprint.phases = new_phases

    elif kind == "change_gate":
        target_gate = amendment.payload.get("gate", "").strip()
        if not target_gate:
            raise AmendmentError("change_gate requires payload['gate']")
        sprint = sprint_lookup.get(amendment.sprint_id)
        if sprint is None:
            raise AmendmentError(f"sprint {amendment.sprint_id!r} not found")
        if amendment.phase_id:
            new_phases = []
            for p in sprint.phases:
                if p.id == amendment.phase_id:
                    new_phases.append(p.model_copy(update={"gate": target_gate}))
                else:
                    new_phases.append(p)
            sprint.phases = new_phases
        else:
            # Sprint gate change
            sprint_lookup[amendment.sprint_id] = sprint.model_copy(update={"gate": target_gate})
            new_sprints = [sprint_lookup.get(s.id, s) for s in new_sprints]

    elif kind == "add_risk":
        desc = amendment.payload.get("description", "").strip()
        if not desc:
            raise AmendmentError("add_risk requires payload['description']")
        # No structural change to sprints; the new risk is appended below.

    elif kind == "add_scope_out":
        item = amendment.payload.get("item", "").strip()
        if not item:
            raise AmendmentError("add_scope_out requires payload['item']")

    else:
        raise AmendmentError(f"unknown amendment kind: {kind!r}")

    applied = amendment.model_copy(update={"applied_at": _now_iso()})

    # Build the final plan with all changes folded in
    new_risks = list(plan.risk_register)
    if kind == "add_risk":
        desc = amendment.payload.get("description", "").strip()
        new_risks.append(
            RiskItem(
                description=desc,
                severity=_coerce_severity(amendment.payload.get("severity")),
                mitigation=amendment.payload.get("mitigation", "").strip(),
            )
        )

    new_scope_out = list(plan.scope_out)
    if kind == "add_scope_out":
        new_scope_out.append(amendment.payload["item"].strip())

    return plan.model_copy(
        update={
            "rev": plan.rev + 1,
            "sprints": new_sprints,
            "risk_register": new_risks,
            "scope_out": new_scope_out,
            "revisions": [*plan.revisions, applied],
            "approved_at": None,  # re-approval required
            "approved_by": "",
        }
    )


def _p_for(plan: Plan, new_sprints: list[Sprint]) -> Plan:
    """Tiny helper so _find_sprint can operate on the in-progress plan."""
    return plan.model_copy(update={"sprints": new_sprints})


def approve_plan(plan: Plan, approver: str = "") -> Plan:
    """Mark a plan approved. Returns a new Plan."""
    return plan.model_copy(
        update={
            "approved_at": _now_iso(),
            "approved_by": approver,
        }
    )


__all__ = [
    "Phase",
    "Sprint",
    "RiskItem",
    "Plan",
    "Amendment",
    "AmendmentError",
    "AmendmentKind",
    "ALLOWED_AMENDMENT_KINDS",
    "Severity",
    "ALLOWED_SEVERITIES",
    "PlanGenerator",
    "generate",
    "apply_heuristics",
    "apply_amendment",
    "approve_plan",
    "write_plan",
    "read_plan",
    "to_text",
]


# ---------------------------------------------------------------------------
# §10 ASCII renderer
# ---------------------------------------------------------------------------


_DBOX_W = 68  # inner width for double-line header boxes


def _money(amount: float) -> str:
    """Compact currency: '$0.00' below $10, '$N.NN' above."""
    if amount >= 100:
        return f"${amount:.0f}"
    return f"${amount:.2f}"


def _duration(minutes: int) -> str:
    if minutes <= 0:
        return "—"
    if minutes < 60:
        return f"{minutes}m"
    hours = minutes // 60
    rem = minutes % 60
    return f"{hours}h{rem}m" if rem else f"{hours}h"


def _agent_short(agent: str) -> str:
    """Strip the role/ prefix for compact phase lines."""
    if "/" in agent:
        return agent.split("/", 1)[1]
    return agent


def _box_top(width: int) -> str:
    return "╔" + "═" * (width + 2) + "╗"


def _box_bot(width: int) -> str:
    return "╚" + "═" * (width + 2) + "╝"


def _box_line(text: str, width: int) -> str:
    """Pad text to fit inside a width-N double box. Truncate if too long."""
    if len(text) > width:
        text = text[: max(0, width - 1)] + "…"
    return f"║ {text:<{width}} ║"


def _sprint_header(sprint: Sprint, width: int) -> list[str]:
    """Single-line dotted header for a sprint."""
    label = f" {sprint.id} · {sprint.name} "
    cost = _money(sprint.cost_estimate_usd)
    dur = _duration(sprint.duration_estimate_min)
    right = f" {cost} · {dur} "
    fill = max(width - len(label) - len(right), 0)
    return [f"┌─{label}{'─' * fill}{right}┐"]


def to_text(plan: Plan) -> str:
    """Render the plan per SPEC §10.1.

    Output is plain-text-with-box-drawing (Unicode). Designed to be
    readable in a terminal at 78+ columns.
    """
    lines: list[str] = []

    # Header
    lines.append(_box_top(_DBOX_W))
    lines.append(_box_line(f"PLAN: {plan.plan_id}", _DBOX_W))
    lines.append(_box_line(f"Spec: {plan.spec_ref}", _DBOX_W))
    cost_label = (
        f"{_money(plan.estimated_cost_usd_low)}-{_money(plan.estimated_cost_usd_high)}"
        if (plan.estimated_cost_usd_high or plan.estimated_cost_usd_low)
        else "—"
    )
    dur_label = (
        f"{_duration(plan.estimated_duration_min_low)}-"
        f"{_duration(plan.estimated_duration_min_high)}"
        if (plan.estimated_duration_min_high or plan.estimated_duration_min_low)
        else "—"
    )
    tok_label = f"{plan.estimated_tokens_total:,}" if plan.estimated_tokens_total else "—"
    lines.append(
        _box_line(f"Estimated: {cost_label}  ·  {dur_label}  ·  {tok_label} tokens", _DBOX_W)
    )
    lines.append(_box_bot(_DBOX_W))

    n_sprints = len(plan.sprints)
    n_phases = sum(len(s.phases) for s in plan.sprints)
    n_gates = len(plan.human_approval_gates)
    lines.append(f"{n_sprints} sprints  ·  {n_phases} phases  ·  {n_gates} approval gates")
    lines.append("")

    # Each sprint as its own block
    inner = _DBOX_W - 2
    for sprint in plan.sprints:
        lines.extend(_sprint_header(sprint, inner))
        lines.append("│" + " " * inner + " │")
        for phase in sprint.phases:
            agent_label = f"[{_agent_short(phase.agent)}]"
            head = f"   {phase.id}  {phase.name}"
            spaces = max(inner - len(head) - len(agent_label) - 1, 1)
            lines.append("│" + head + " " * spaces + agent_label + " │")
            for d in phase.deliverables:
                line = f"       └─ {d}"
                if len(line) > inner:
                    line = line[: inner - 1] + "…"
                lines.append("│" + line.ljust(inner) + " │")
            if phase.tests:
                test_summary = "       └─ " + (
                    phase.tests[0] if len(phase.tests) == 1 else f"{len(phase.tests)} tests"
                )
                if len(test_summary) > inner:
                    test_summary = test_summary[: inner - 1] + "…"
                lines.append("│" + test_summary.ljust(inner) + " │")
            lines.append("│" + " " * inner + " │")

        # Gate sub-box inside the sprint block
        if sprint.gate:
            gate_inner = inner - 6
            gate_label = f"Gate: {sprint.gate}"
            if len(gate_label) > gate_inner:
                gate_label = gate_label[: gate_inner - 1] + "…"
            lines.append("│   ┌─" + ("─" * gate_inner) + "─┐ │")
            lines.append("│   │ " + gate_label.ljust(gate_inner) + " │ │")
            lines.append(
                "│   │ " + "⚑ HUMAN APPROVAL REQUIRED before next sprint".ljust(gate_inner) + " │ │"
            )
            lines.append("│   └─" + ("─" * gate_inner) + "─┘ │")
        lines.append("└" + "─" * (inner + 1) + "┘")
        lines.append("")

    # Scope boundaries
    if plan.scope_in or plan.scope_out:
        lines.append("SCOPE BOUNDARIES")
        for item in plan.scope_in:
            lines.append(f"  ✓ In scope:    {item}")
        for item in plan.scope_out:
            lines.append(f"  ✗ Out:         {item}")
        lines.append("")

    # Risks
    if plan.risk_register:
        lines.append("RISKS")
        for r in plan.risk_register:
            sev = {"low": " ", "medium": "!", "high": "!!"}[r.severity]
            line = f"  {sev} [{r.severity}] {r.description}"
            lines.append(line)
            if r.mitigation:
                lines.append(f"        → {r.mitigation}")
        lines.append("")

    # Actions
    lines.append("ACTIONS")
    lines.append("  [a] Approve and start")
    lines.append("  [e] Edit (drop a sprint, change scope, adjust budget)")
    lines.append("  [r] Regenerate plan (with notes)")
    lines.append("  [q] Cancel")

    return "\n".join(lines).rstrip() + "\n"
