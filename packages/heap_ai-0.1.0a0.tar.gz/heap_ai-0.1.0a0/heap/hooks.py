"""Hook actions for HEAP agents.

Per SPEC §5.2, agent hooks return one of these actions to control the
PEV loop. Action semantics (S2.P2):

  - Block(reason)  : Highest priority. Aborts the run; AgentResult gets
                     hook_blocked=True and escalation_reason=reason.
  - Retry(hint)    : At post_phase("verify"), treated as a verify failure
                     with the hint forwarded to the next plan. Ignored
                     elsewhere in v0.1 (logged for visibility).
  - Warn(message)  : Appended to AgentResult.warnings, run continues.
  - Continue()     : Explicit no-op (equivalent to returning None).

When multiple hooks fire at the same boundary, the action with the
highest priority wins (Block > Retry > Warn > Continue).
"""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass(frozen=True)
class Block:
    """Stop the run and surface ``reason``. Agent finalizes with hook_blocked=True."""

    reason: str


@dataclass(frozen=True)
class Warn:
    """Log a warning and continue. Message lands in AgentResult.warnings."""

    message: str


@dataclass(frozen=True)
class Retry:
    """At post_phase("verify"): treat as fail with ``hint`` forwarded to replan.

    At other firing points in v0.1 this is logged but does not retry —
    those semantics are reserved for S2.P3 (tool retries) and beyond.
    """

    hint: str


@dataclass(frozen=True)
class Continue:
    """Explicit no-op. Equivalent to returning ``None`` from a hook."""


HookAction = Block | Warn | Retry | Continue


class HookBlocked(RuntimeError):
    """Internal signal raised when a hook returns ``Block``.

    Agent.run() catches this and finalizes the result with
    ``hook_blocked=True`` and ``escalated=True``. User code should
    return ``Block(...)`` from a hook rather than raise this directly.
    """


@dataclass(frozen=True)
class InterpretedHooks:
    """Aggregate result of firing all hooks at a single boundary.

    Highest-priority action wins (Block > Retry > Warn). Warns are
    collected separately because multiple are allowed simultaneously.
    """

    block: Block | None = None
    retry: Retry | None = None
    warnings: list[Warn] = field(default_factory=list)


def interpret(actions: list[HookAction | None]) -> InterpretedHooks:
    """Reduce a list of hook return values to the dominant action."""
    block: Block | None = None
    retry: Retry | None = None
    warnings: list[Warn] = []
    for a in actions:
        if a is None or isinstance(a, Continue):
            continue
        if isinstance(a, Block):
            # First Block wins; later Blocks ignored for clarity.
            block = block or a
        elif isinstance(a, Retry):
            retry = retry or a
        elif isinstance(a, Warn):
            warnings.append(a)
    return InterpretedHooks(block=block, retry=retry, warnings=warnings)


__all__ = [
    "Block",
    "Warn",
    "Retry",
    "Continue",
    "HookAction",
    "HookBlocked",
    "InterpretedHooks",
    "interpret",
]
