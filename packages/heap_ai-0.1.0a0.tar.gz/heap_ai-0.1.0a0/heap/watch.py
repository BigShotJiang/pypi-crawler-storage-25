"""HEAP watch — live tail of a run's ``trace.jsonl``.

Renders each ``RunEvent`` as a one-line colored entry. Two modes:

  - snapshot: print the last N events and exit
  - follow:   print last N, then poll for new events until interrupted

Polling-based (not inotify) because trace.jsonl is small and append-only;
a 500ms poll covers the worst-case human-visible latency without burning
CPU. Cross-platform with no extra deps.
"""

from __future__ import annotations

import time
from collections.abc import Iterator
from pathlib import Path

import click

from heap.run import RunEvent

# ---------------------------------------------------------------------------
# Per-event formatting
# ---------------------------------------------------------------------------


# Map RunEvent.kind → (color, glyph)
_EVENT_STYLE: dict[str, tuple[str | None, str]] = {
    "run_start": ("cyan", "▶"),
    "run_complete": ("green", "✓"),
    "run_failed": ("red", "✗"),
    "run_blocked": ("yellow", "⏸"),
    "sprint_start": ("cyan", "→"),
    "sprint_gate": ("yellow", "⚑"),
    "sprint_complete": ("green", "✓"),
    "phase_start": (None, "·"),
    "phase_pass": ("green", "✓"),
    "phase_fail": ("red", "✗"),
    "phase_retry": ("yellow", "↻"),
    "gate_approved": ("green", "⚑"),
}


def format_event(ev: RunEvent, *, color: bool = True) -> str:
    """One-line colored event line for terminal output."""
    style, glyph = _EVENT_STYLE.get(ev.kind, (None, "·"))
    sprint = f"{ev.sprint_id:>4}" if ev.sprint_id else "    "
    phase = f"{ev.phase_id:>8}" if ev.phase_id else "        "
    suffix = f" — {ev.detail}" if ev.detail else ""
    line = f"  [{ev.ts}] {glyph} {ev.kind:14} {sprint} {phase}{suffix}"
    if color and style is not None:
        line = click.style(line, fg=style)
    return line


# ---------------------------------------------------------------------------
# Tail / follow loop
# ---------------------------------------------------------------------------


def _parse_line(raw: str) -> RunEvent | None:
    raw = raw.strip()
    if not raw:
        return None
    try:
        return RunEvent.model_validate_json(raw)
    except Exception:  # noqa: BLE001 — defensive, keep tailing
        return None


def tail_jsonl(
    path: str | Path,
    *,
    follow: bool = True,
    n: int = 20,
    interval_s: float = 0.5,
    max_iters: int | None = None,
) -> Iterator[RunEvent]:
    """Yield ``RunEvent`` objects from a trace.jsonl file.

    On entry, yields the last ``n`` events (already on disk). If ``follow``
    is True, then keeps polling the file and yielding any new events. The
    loop ends when:
      - the user interrupts (Ctrl-C → KeyboardInterrupt propagates), OR
      - ``max_iters`` poll cycles have elapsed (test escape hatch).

    Missing file is non-fatal: yields nothing in snapshot mode; in follow
    mode polls until the file appears.
    """
    p = Path(path)

    # Snapshot phase — emit existing tail
    initial: list[RunEvent] = []
    if p.exists():
        for raw in p.read_text(encoding="utf-8").splitlines():
            ev = _parse_line(raw)
            if ev is not None:
                initial.append(ev)
    yield from initial[-n:]

    if not follow:
        return

    # Follow phase — poll for new lines
    pos = p.stat().st_size if p.exists() else 0
    iters = 0
    while True:
        if max_iters is not None and iters >= max_iters:
            return
        iters += 1

        if not p.exists():
            time.sleep(interval_s)
            continue

        cur_size = p.stat().st_size
        if cur_size > pos:
            with p.open("r", encoding="utf-8") as f:
                f.seek(pos)
                for raw in f.readlines():
                    ev = _parse_line(raw)
                    if ev is not None:
                        yield ev
            pos = cur_size
        elif cur_size < pos:
            # File rotated / truncated — restart from 0.
            pos = 0

        time.sleep(interval_s)


__all__ = [
    "format_event",
    "tail_jsonl",
]
