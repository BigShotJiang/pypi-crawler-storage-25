"""Run engine — execute an approved Plan with PEV phases and sprint gates.

Per SPEC §9 the engine reads an approved plan, walks sprints in order,
runs phases via the PEV ritual, halts at sprint gates for explicit
human approval, and persists state on every transition so a crashed
run can resume.

This module covers S6.P1: state-machine skeleton + gate halting.
S6.P2 adds disk persistence + ``heap resume``. S6.P3 adds the §9.3
auto-retry policy. S6.P4 ties it all together with fixture-driven
integration tests.

Design constraints:
  - The engine never calls a model directly. The user supplies an
    ``execute_phase`` callback that does the real work; the engine
    handles ordering, gates, and state.
  - State transitions are simple enums; every transition emits a
    trace event so progress is observable.
  - The engine is synchronous and single-run; concurrency is v0.2.
"""

from __future__ import annotations

import logging
from collections.abc import Callable
from datetime import UTC, datetime
from pathlib import Path
from typing import Literal

from pydantic import BaseModel, Field

from heap.plan import Phase, Plan, Sprint, read_plan

logger = logging.getLogger(__name__)


PhaseStatus = Literal["pending", "in_progress", "passed", "failed"]
SprintStatus = Literal["pending", "in_progress", "awaiting_gate", "passed", "failed"]
RunStatus = Literal["pending", "in_progress", "awaiting_gate", "complete", "failed"]


# ---------------------------------------------------------------------------
# Trace event
# ---------------------------------------------------------------------------


class RunEvent(BaseModel):
    """One event in the run trace.

    Kept tiny on purpose — events stream to JSONL on disk in S6.P2.
    """

    ts: str  # ISO 8601, UTC
    kind: str  # e.g. "phase_start", "phase_pass", "sprint_gate", "run_complete"
    sprint_id: str = ""
    phase_id: str = ""
    detail: str = ""


# ---------------------------------------------------------------------------
# Result of executing one phase
# ---------------------------------------------------------------------------


class PhaseResult(BaseModel):
    """What ``execute_phase`` returns to the engine.

    ``passed=True`` advances. ``passed=False`` halts the run. Auto-retry
    (S6.P3) inspects ``retryable`` to decide if it should re-invoke the
    callback once with the same ``RunContext``.
    """

    passed: bool
    detail: str = ""
    retryable: bool = False
    cost_usd: float = 0.0
    tokens_in: int = 0
    tokens_out: int = 0


# ---------------------------------------------------------------------------
# RunState — the persisted snapshot
# ---------------------------------------------------------------------------


class RunState(BaseModel):
    """Snapshot of where a run is.

    Persisted to ``.heap/runs/<run_id>/state.json`` (S6.P2). On crash
    the engine reads this back and resumes at the last persisted phase
    boundary — never mid-phase.
    """

    run_id: str
    plan_id: str
    plan_ref: str = ""  # e.g. "specs/csv-bom.plan.yaml"
    spec_ref: str = ""
    started_at: str = ""
    last_event_at: str = ""
    sprint_idx: int = 0
    phase_idx: int = 0
    sprint_status: SprintStatus = "pending"
    phase_status: PhaseStatus = "pending"
    run_status: RunStatus = "pending"
    completed_sprints: list[str] = Field(default_factory=list)
    completed_phases: list[str] = Field(default_factory=list)
    failed_phase: str = ""
    awaiting_gate: str = ""  # sprint id we're stopped at, if any
    cost_usd_total: float = 0.0
    tokens_in_total: int = 0
    tokens_out_total: int = 0


# ---------------------------------------------------------------------------
# RunContext — what the executor sees
# ---------------------------------------------------------------------------


class RunContext(BaseModel):
    """Immutable per-phase context handed to ``execute_phase``."""

    model_config = {"arbitrary_types_allowed": True}

    run_id: str
    plan_id: str
    sprint: Sprint
    phase: Phase
    sprint_idx: int
    phase_idx: int
    attempt: int = 1  # 1 on first call; 2 on retry per §9.3 (S6.P3)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _now_iso() -> str:
    return datetime.now(UTC).strftime("%Y-%m-%dT%H:%M:%SZ")


def _make_run_id(plan_id: str) -> str:
    """Stamp a unique run id off the plan id."""
    stamp = datetime.now(UTC).strftime("%Y%m%d%H%M%S")
    return f"run-{plan_id}-{stamp}"


# ---------------------------------------------------------------------------
# Engine
# ---------------------------------------------------------------------------


# A phase executor returns a PhaseResult. May be a closure capturing a Gateway.
ExecuteFn = Callable[[RunContext], PhaseResult]
HookFn = Callable[[RunContext], None]
EventSink = Callable[[RunEvent], None]


# ---------------------------------------------------------------------------
# Persistence (SPEC §9.1)
# ---------------------------------------------------------------------------

DEFAULT_RUNS_BASE = ".heap/runs"


def runs_base(base: str | Path | None = None) -> Path:
    return Path(base or DEFAULT_RUNS_BASE)


def run_dir_for(run_id: str, base: str | Path | None = None) -> Path:
    return runs_base(base) / run_id


def save_state(state: RunState, run_dir: str | Path) -> Path:
    """Atomically write ``state.json`` into ``run_dir``."""
    p = Path(run_dir)
    p.mkdir(parents=True, exist_ok=True)
    target = p / "state.json"
    tmp = target.with_suffix(".json.tmp")
    tmp.write_text(state.model_dump_json(indent=2), encoding="utf-8")
    tmp.replace(target)
    return target


def load_state(run_id: str, base: str | Path | None = None) -> RunState | None:
    """Read ``<base>/<run_id>/state.json``. Returns None if missing."""
    p = run_dir_for(run_id, base) / "state.json"
    if not p.exists():
        return None
    return RunState.model_validate_json(p.read_text(encoding="utf-8"))


def append_event(event: RunEvent, run_dir: str | Path) -> Path:
    """Append one JSONL event line to ``trace.jsonl`` under ``run_dir``."""
    p = Path(run_dir)
    p.mkdir(parents=True, exist_ok=True)
    target = p / "trace.jsonl"
    with target.open("a", encoding="utf-8") as f:
        f.write(event.model_dump_json() + "\n")
    return target


def load_events(run_id: str, base: str | Path | None = None) -> list[RunEvent]:
    """Read ``<base>/<run_id>/trace.jsonl`` and parse each line."""
    p = run_dir_for(run_id, base) / "trace.jsonl"
    if not p.exists():
        return []
    out: list[RunEvent] = []
    for raw in p.read_text(encoding="utf-8").splitlines():
        if not raw.strip():
            continue
        try:
            out.append(RunEvent.model_validate_json(raw))
        except Exception as e:  # noqa: BLE001
            logger.debug("trace.jsonl: skipping malformed line: %s", e)
    return out


def list_runs(base: str | Path | None = None) -> list[str]:
    """List run ids — directories that contain a state.json."""
    root = runs_base(base)
    if not root.exists():
        return []
    return sorted(d.name for d in root.iterdir() if d.is_dir() and (d / "state.json").exists())


def load_run(
    run_id: str,
    *,
    execute_phase: ExecuteFn,
    base: str | Path | None = None,
    plan_path: str | Path | None = None,
    pre_phase: HookFn | None = None,
    post_phase: HookFn | None = None,
    on_gate: HookFn | None = None,
    event_sink: EventSink | None = None,
) -> RunEngine:
    """Reconstruct a ``RunEngine`` for an existing run.

    Looks up the saved ``RunState`` under ``<base>/<run_id>/`` and the
    plan referenced by ``state.plan_ref`` (or the explicit ``plan_path``
    override). The engine reuses the same ``run_dir`` so further
    transitions continue to persist there.
    """
    state = load_state(run_id, base)
    if state is None:
        raise FileNotFoundError(f"no state.json for run {run_id!r} under {runs_base(base)}/")

    plan_p = Path(plan_path or state.plan_ref)
    if not plan_p.exists():
        raise FileNotFoundError(
            f"plan file {plan_p!s} (from state.plan_ref) not found; pass plan_path= to override."
        )
    plan = read_plan(plan_p)
    if plan is None:
        raise ValueError(f"could not parse plan at {plan_p!s}")

    return RunEngine(
        plan,
        execute_phase=execute_phase,
        pre_phase=pre_phase,
        post_phase=post_phase,
        on_gate=on_gate,
        event_sink=event_sink,
        state=state,
        run_dir=run_dir_for(run_id, base),
        plan_ref=str(plan_p),
    )


class GateRequired(Exception):
    """Raised internally to break out of phase loop at a sprint gate."""


class RunEngine:
    """Walk a plan one phase at a time, halting at every sprint gate.

    Usage:
        engine = RunEngine(plan, execute_phase=my_executor)
        engine.run()              # halts at first sprint gate
        engine.approve_gate()     # advances past gate
        engine.run()              # continues through next sprint
        engine.state              # current RunState
        engine.events             # in-memory event log (S6.P2 will spill to disk)

    The engine never blocks on input; gate halting is signaled by
    ``state.run_status == "awaiting_gate"``.
    """

    def __init__(
        self,
        plan: Plan,
        *,
        execute_phase: ExecuteFn,
        pre_phase: HookFn | None = None,
        post_phase: HookFn | None = None,
        on_gate: HookFn | None = None,
        event_sink: EventSink | None = None,
        run_id: str | None = None,
        state: RunState | None = None,
        run_dir: str | Path | None = None,
        plan_ref: str = "",
    ) -> None:
        if not plan.sprints:
            raise ValueError("cannot run a plan with zero sprints")
        self.plan = plan
        self._execute = execute_phase
        self._pre_phase = pre_phase
        self._post_phase = post_phase
        self._on_gate = on_gate
        self._user_event_sink = event_sink
        self.events: list[RunEvent] = []
        self.run_dir: Path | None = Path(run_dir) if run_dir else None

        if state is not None:
            # Resuming an existing run.
            self.state = state
        else:
            self.state = RunState(
                run_id=run_id or _make_run_id(plan.plan_id),
                plan_id=plan.plan_id,
                plan_ref=plan_ref,
                spec_ref=plan.spec_ref,
                started_at=_now_iso(),
                last_event_at=_now_iso(),
                run_status="pending",
            )

        if self.run_dir is not None:
            self.run_dir.mkdir(parents=True, exist_ok=True)
            save_state(self.state, self.run_dir)

    # ------------------------------------------------------------------
    # Public entry points
    # ------------------------------------------------------------------

    def run(self) -> RunState:
        """Run forward until a gate halt, a phase failure, or completion.

        Idempotent across gate halts: calling ``run()`` again with the
        run still ``awaiting_gate`` raises ``GateRequired``-style state
        signal. Use ``approve_gate()`` first.
        """
        if self.state.run_status == "awaiting_gate":
            self._emit("run_blocked", detail=f"awaiting gate at sprint {self.state.awaiting_gate}")
            return self.state
        if self.state.run_status == "complete":
            return self.state
        if self.state.run_status == "failed":
            return self.state

        self.state.run_status = "in_progress"
        self._emit("run_start")

        try:
            while self.state.sprint_idx < len(self.plan.sprints):
                self._run_current_sprint()
                # If still awaiting_gate after the sprint loop, halt for human.
                if self.state.run_status == "awaiting_gate":
                    return self.state
            # Walked off the end → done
            self.state.run_status = "complete"
            self._emit("run_complete")
        except _PhaseFailed as e:
            self.state.run_status = "failed"
            self.state.failed_phase = e.phase_id
            self._emit("run_failed", phase_id=e.phase_id, detail=e.detail)
        return self.state

    def approve_gate(self, *, approver: str = "") -> RunState:
        """Acknowledge the current sprint gate and advance to the next sprint."""
        if self.state.run_status != "awaiting_gate":
            raise RuntimeError(
                f"approve_gate called but run_status={self.state.run_status!r}; "
                "gate is only relevant when the engine is awaiting one."
            )
        sprint = self.plan.sprints[self.state.sprint_idx]
        self.state.completed_sprints.append(sprint.id)
        self.state.sprint_idx += 1
        self.state.phase_idx = 0
        self.state.sprint_status = "pending"
        self.state.phase_status = "pending"
        self.state.awaiting_gate = ""
        self.state.run_status = "in_progress"
        self._emit(
            "gate_approved", sprint_id=sprint.id, detail=f"by {approver}" if approver else ""
        )
        return self.state

    # ------------------------------------------------------------------
    # Internals
    # ------------------------------------------------------------------

    def _run_current_sprint(self) -> None:
        sprint = self.plan.sprints[self.state.sprint_idx]
        if self.state.sprint_status == "pending":
            self.state.sprint_status = "in_progress"
            self._emit("sprint_start", sprint_id=sprint.id)

        while self.state.phase_idx < len(sprint.phases):
            self._run_current_phase()

        # All phases done → halt for the gate.
        self.state.sprint_status = "awaiting_gate"
        self.state.run_status = "awaiting_gate"
        self.state.awaiting_gate = sprint.id
        self._emit("sprint_gate", sprint_id=sprint.id, detail=sprint.gate)
        if self._on_gate is not None:
            ctx = RunContext(
                run_id=self.state.run_id,
                plan_id=self.plan.plan_id,
                sprint=sprint,
                phase=sprint.phases[-1] if sprint.phases else Phase(id="", name=""),
                sprint_idx=self.state.sprint_idx,
                phase_idx=max(self.state.phase_idx - 1, 0),
            )
            self._on_gate(ctx)

    def _run_current_phase(self) -> None:
        """Execute the current phase, applying the §9.3 auto-retry policy.

        At most one retry per phase. The retry is triggered only when
        ``PhaseResult.retryable=True``; this is the executor's signal that
        the failure is tightly scoped (single test, lint violation, etc.)
        per §9.3. Architectural / scope / budget failures must not set
        ``retryable=True``.
        """
        sprint = self.plan.sprints[self.state.sprint_idx]
        phase = sprint.phases[self.state.phase_idx]

        for attempt in (1, 2):
            ctx = RunContext(
                run_id=self.state.run_id,
                plan_id=self.plan.plan_id,
                sprint=sprint,
                phase=phase,
                sprint_idx=self.state.sprint_idx,
                phase_idx=self.state.phase_idx,
                attempt=attempt,
            )

            self.state.phase_status = "in_progress"
            if attempt == 1:
                self._emit("phase_start", sprint_id=sprint.id, phase_id=phase.id)
            else:
                self._emit(
                    "phase_retry",
                    sprint_id=sprint.id,
                    phase_id=phase.id,
                    detail="auto-retry per §9.3",
                )

            if self._pre_phase is not None:
                self._pre_phase(ctx)
            result = self._execute(ctx)
            self._record_phase_totals(result)
            if self._post_phase is not None:
                self._post_phase(ctx)

            if result.passed:
                self.state.phase_status = "passed"
                self.state.completed_phases.append(phase.id)
                self.state.phase_idx += 1
                self._emit(
                    "phase_pass",
                    sprint_id=sprint.id,
                    phase_id=phase.id,
                    detail=result.detail,
                )
                return

            # Failed — decide whether to retry.
            if attempt == 1 and result.retryable:
                # Loop again with attempt=2.
                continue

            self.state.phase_status = "failed"
            self._emit(
                "phase_fail",
                sprint_id=sprint.id,
                phase_id=phase.id,
                detail=result.detail,
            )
            raise _PhaseFailed(phase_id=phase.id, detail=result.detail)

    def _record_phase_totals(self, result: PhaseResult) -> None:
        self.state.cost_usd_total = round(self.state.cost_usd_total + result.cost_usd, 6)
        self.state.tokens_in_total += result.tokens_in
        self.state.tokens_out_total += result.tokens_out

    def _emit(
        self, kind: str, *, sprint_id: str = "", phase_id: str = "", detail: str = ""
    ) -> None:
        ev = RunEvent(
            ts=_now_iso(),
            kind=kind,
            sprint_id=sprint_id,
            phase_id=phase_id,
            detail=detail,
        )
        self.events.append(ev)
        self.state.last_event_at = ev.ts
        # Durable persistence precedes side effects (SPEC §9.1).
        if self.run_dir is not None:
            try:
                append_event(ev, self.run_dir)
                save_state(self.state, self.run_dir)
            except OSError as e:
                logger.warning("run persistence write failed: %s", e)
        if self._user_event_sink is not None:
            try:
                self._user_event_sink(ev)
            except Exception as e:  # noqa: BLE001 — sink errors must not kill the run
                logger.warning("event sink raised %s — continuing", e)


class _PhaseFailed(Exception):
    """Internal — surfaced as run_status='failed' on the state."""

    def __init__(self, phase_id: str, detail: str) -> None:
        super().__init__(detail)
        self.phase_id = phase_id
        self.detail = detail


__all__ = [
    "PhaseStatus",
    "SprintStatus",
    "RunStatus",
    "RunEvent",
    "PhaseResult",
    "RunState",
    "RunContext",
    "RunEngine",
    "ExecuteFn",
    "HookFn",
    "EventSink",
    "GateRequired",
    "DEFAULT_RUNS_BASE",
    "runs_base",
    "run_dir_for",
    "save_state",
    "load_state",
    "append_event",
    "load_events",
    "list_runs",
    "load_run",
]
