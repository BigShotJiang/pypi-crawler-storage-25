"""Scenarios — first-class approval-gate artifact between spec and run.

Per SPEC §7, scenarios sit between plan approval and execution. They
are written as Given/When/Then in plain English so non-technical users
can contribute judgment. Two kinds:

  - source="spec" — generated from a spec acceptance criterion
  - source="gap"  — flagged by the validator pass: the spec is silent on
                    something but a scenario is implied

This module covers S4.P1: generation + gap detection. The review CLI
(S4.P2), spec-amendment flow (S4.P3), and end-to-end acceptance against
S3 specs (S4.P4) live elsewhere.

Keep this module:
  - Pure (no CLI, no I/O beyond YAML round-trip)
  - Permissive parsing (LLMs sometimes wrap JSON in fences or prose)
  - Deterministic when called with mocked Gateway responses
"""

from __future__ import annotations

import json
import logging
import re
from datetime import UTC, datetime
from pathlib import Path
from typing import Any, Literal

import yaml
from pydantic import BaseModel, Field

from heap.gateway import Gateway, GatewayResponse
from heap.spec.structurer import StructuredSpec

logger = logging.getLogger(__name__)


Source = Literal["spec", "gap", "manual"]
Confidence = Literal["high", "medium", "low"]
ALLOWED_SOURCES: tuple[Source, ...] = ("spec", "gap", "manual")
ALLOWED_CONFIDENCES: tuple[Confidence, ...] = ("high", "medium", "low")


# ---------------------------------------------------------------------------
# Models
# ---------------------------------------------------------------------------


class Scenario(BaseModel):
    """One Given/When/Then scenario.

    ``acceptance_ref`` is the index (0-based) of the spec acceptance
    criterion this scenario covers, or ``None`` for gap scenarios that
    don't map to any existing criterion yet.
    """

    id: str
    title: str
    given: list[str] = Field(default_factory=list)
    when: list[str] = Field(default_factory=list)
    then: list[str] = Field(default_factory=list)
    acceptance_ref: int | None = None
    source: Source = "spec"
    confidence: Confidence = "high"
    note: str | None = None  # used for gap scenarios to explain WHY


class Deletion(BaseModel):
    """Audit log entry for a scenario deleted during review."""

    id: str
    title: str
    reason: str = ""
    deleted_at: str = ""  # ISO 8601, UTC


class ScenarioSet(BaseModel):
    """A list of scenarios bound to a specific spec version."""

    spec_name: str
    spec_version: int
    scenarios: list[Scenario] = Field(default_factory=list)
    generated_by: str = ""
    generated_at: str = ""  # ISO 8601, UTC
    cost_usd: float = 0.0
    approved_at: str | None = None  # set by `heap scenarios review` on approval
    approved_by: str = ""  # username / email if known
    deletions: list[Deletion] = Field(default_factory=list)


# ---------------------------------------------------------------------------
# Prompts
# ---------------------------------------------------------------------------


_GENERATE_SYSTEM = (
    "You translate spec acceptance criteria into plain-English "
    "Given/When/Then scenarios. One acceptance criterion may yield one "
    "or several scenarios — write one scenario per distinct user-visible "
    "behavior implied by the criterion.\n\n"
    "Rules:\n"
    "  - Use everyday language. No jargon, no file paths, no selectors.\n"
    "  - 'Given' lines describe preconditions.\n"
    "  - 'When'  lines describe the user action or event.\n"
    "  - 'Then'  lines describe observable outcomes.\n"
    "  - Each scenario MUST set acceptance_ref to the 0-based index of the "
    "criterion it covers.\n"
    "  - Title is a short imperative phrase (≤8 words).\n\n"
    "Output JSON ONLY (no prose, no markdown fences):\n"
    '{"scenarios": [\n'
    '  {"title": "...", "given": ["..."], "when": ["..."], "then": ["..."], '
    '"acceptance_ref": 0, "confidence": "high|medium|low"}\n'
    "]}"
)


_GAP_SYSTEM = (
    "You are an adversarial reviewer of a draft scenario set. The spec "
    "and the existing scenarios are below. Find scenarios that are "
    "IMPLIED by the spec but not yet covered — empty states, error paths, "
    "edge cases the user would care about. Prefer concrete, testable "
    "behaviors. Do NOT restate scenarios already in the list.\n\n"
    "If the existing set already covers the spec well, return zero gaps. "
    "Do NOT invent gaps to look thorough.\n\n"
    "Output JSON ONLY (no prose, no markdown fences):\n"
    '{"gaps": [\n'
    '  {"title": "...", "given": ["..."], "when": ["..."], "then": ["..."], '
    '"note": "<why this gap matters>", "confidence": "high|medium|low"}\n'
    "]}"
)


def _build_generate_prompt(spec: StructuredSpec) -> str:
    spec_yaml = yaml.safe_dump(spec.model_dump(), sort_keys=False, allow_unicode=True)
    crits = "\n".join(f"  [{i}] {c}" for i, c in enumerate(spec.acceptance))
    return (
        f"SPEC ({spec.name} v{spec.version}, mode={spec.mode}, "
        f"audience={spec.audience}):\n\n"
        "```yaml\n"
        f"{spec_yaml}"
        "```\n\n"
        f"ACCEPTANCE CRITERIA (use these indices in acceptance_ref):\n{crits}\n\n"
        "Generate scenarios. Return JSON with the scenarios list."
    )


def _build_gap_prompt(spec: StructuredSpec, existing: list[Scenario]) -> str:
    spec_yaml = yaml.safe_dump(spec.model_dump(), sort_keys=False, allow_unicode=True)
    rendered = (
        "\n".join(f"  - {s.title} (acceptance_ref={s.acceptance_ref})" for s in existing)
        or "  (none)"
    )
    return (
        f"SPEC ({spec.name} v{spec.version}):\n\n"
        "```yaml\n"
        f"{spec_yaml}"
        "```\n\n"
        f"EXISTING SCENARIOS:\n{rendered}\n\n"
        "Find any scenarios implied by the spec but not yet covered. "
        "Return JSON with the gaps list."
    )


# ---------------------------------------------------------------------------
# Generator
# ---------------------------------------------------------------------------


_JSON_OBJECT_RE = re.compile(r"\{.*\}", re.DOTALL)


def _extract_json_object(content: str | None) -> dict[str, Any] | None:
    """Permissively pull a top-level JSON object out of the model's reply."""
    if not content:
        return None
    cleaned = content.strip()
    if cleaned.startswith("```"):
        cleaned = re.sub(r"^```(?:json)?\s*", "", cleaned)
        cleaned = re.sub(r"\s*```$", "", cleaned)
    if not cleaned.startswith("{"):
        m = _JSON_OBJECT_RE.search(cleaned)
        if not m:
            return None
        cleaned = m.group(0)
    try:
        data = json.loads(cleaned)
    except json.JSONDecodeError as e:
        logger.debug("scenarios: JSON decode failed: %s", e)
        return None
    return data if isinstance(data, dict) else None


def _coerce_str_list(value: Any) -> list[str]:
    if value is None:
        return []
    if isinstance(value, list):
        return [str(v).strip() for v in value if str(v).strip()]
    if isinstance(value, str):
        s = value.strip()
        return [s] if s else []
    return [str(value)]


def _coerce_confidence(value: Any) -> Confidence:
    if isinstance(value, str) and value.lower() in ALLOWED_CONFIDENCES:
        return value.lower()  # type: ignore[return-value]
    return "medium"


def _now_iso() -> str:
    return datetime.now(UTC).strftime("%Y-%m-%dT%H:%M:%SZ")


class Generator:
    """Generate scenarios + gap scenarios for a StructuredSpec."""

    def __init__(self, gateway: Gateway) -> None:
        self.gateway = gateway

    # --- public ------------------------------------------------------------

    def generate(self, spec: StructuredSpec) -> ScenarioSet:
        """Produce one or more scenarios per acceptance criterion."""
        if not spec.acceptance:
            return ScenarioSet(
                spec_name=spec.name,
                spec_version=spec.version,
                generated_by="",
                generated_at=_now_iso(),
            )

        resp = self.gateway.call(
            role="planner",
            messages=[
                {"role": "system", "content": _GENERATE_SYSTEM},
                {"role": "user", "content": _build_generate_prompt(spec)},
            ],
            max_tokens=2500,
        )
        if not isinstance(resp, GatewayResponse):
            raise RuntimeError(f"Gateway returned non-response object: {type(resp)!r}")

        scenarios = self._parse_scenarios(
            resp.content,
            n_criteria=len(spec.acceptance),
            id_prefix="T",
            source="spec",
        )
        return ScenarioSet(
            spec_name=spec.name,
            spec_version=spec.version,
            scenarios=scenarios,
            generated_by=resp.model_used,
            generated_at=_now_iso(),
            cost_usd=resp.cost_usd,
        )

    def detect_gaps(
        self,
        spec: StructuredSpec,
        scenarios: ScenarioSet,
    ) -> list[Scenario]:
        """Adversarial pass — return additional scenarios marked source='gap'."""
        resp = self.gateway.call(
            role="planner",
            messages=[
                {"role": "system", "content": _GAP_SYSTEM},
                {"role": "user", "content": _build_gap_prompt(spec, scenarios.scenarios)},
            ],
            max_tokens=2000,
        )
        if not isinstance(resp, GatewayResponse):
            raise RuntimeError(f"Gateway returned non-response object: {type(resp)!r}")

        offset = len(scenarios.scenarios)
        return self._parse_gaps(resp.content, offset=offset)

    # --- internals ---------------------------------------------------------

    @classmethod
    def _parse_scenarios(
        cls,
        content: str | None,
        *,
        n_criteria: int,
        id_prefix: str,
        source: Source,
    ) -> list[Scenario]:
        data = _extract_json_object(content)
        if not data:
            return []
        raw_list = data.get("scenarios", [])
        if not isinstance(raw_list, list):
            return []

        out: list[Scenario] = []
        for item in raw_list:
            if not isinstance(item, dict):
                continue
            title = (item.get("title") or "").strip()
            if not title:
                continue
            ref = item.get("acceptance_ref")
            ref_int = ref if isinstance(ref, int) and 0 <= ref < n_criteria else None
            out.append(
                Scenario(
                    id=f"{id_prefix}{len(out) + 1}",
                    title=title,
                    given=_coerce_str_list(item.get("given")),
                    when=_coerce_str_list(item.get("when")),
                    then=_coerce_str_list(item.get("then")),
                    acceptance_ref=ref_int,
                    source=source,
                    confidence=_coerce_confidence(item.get("confidence")),
                )
            )
        return out

    @classmethod
    def _parse_gaps(cls, content: str | None, *, offset: int) -> list[Scenario]:
        data = _extract_json_object(content)
        if not data:
            return []
        raw_list = data.get("gaps", [])
        if not isinstance(raw_list, list):
            return []

        out: list[Scenario] = []
        for item in raw_list:
            if not isinstance(item, dict):
                continue
            title = (item.get("title") or "").strip()
            if not title:
                continue
            out.append(
                Scenario(
                    id=f"G{offset + len(out) + 1}",
                    title=title,
                    given=_coerce_str_list(item.get("given")),
                    when=_coerce_str_list(item.get("when")),
                    then=_coerce_str_list(item.get("then")),
                    acceptance_ref=None,
                    source="gap",
                    confidence=_coerce_confidence(item.get("confidence")),
                    note=(str(item["note"]).strip() if item.get("note") else None),
                )
            )
        return out


# ---------------------------------------------------------------------------
# Convenience top-level functions
# ---------------------------------------------------------------------------


def generate(spec: StructuredSpec, gateway: Gateway) -> ScenarioSet:
    """Generate scenarios for a spec. Convenience wrapper around Generator."""
    return Generator(gateway).generate(spec)


def detect_gaps(
    spec: StructuredSpec,
    scenarios: ScenarioSet,
    gateway: Gateway,
) -> list[Scenario]:
    """Adversarial pass — find implied-but-uncovered scenarios."""
    return Generator(gateway).detect_gaps(spec, scenarios)


_PROPOSE_SYSTEM = (
    "You convert a single Given/When/Then scenario into one acceptance "
    "criterion sentence suitable for a spec. Rules:\n"
    "  - Use a single declarative sentence.\n"
    "  - Keep the user-visible behaviour, not implementation details.\n"
    "  - Match the tense and tone of the existing acceptance criteria below "
    "(e.g., if they all start with 'After fix:', match that).\n\n"
    "Output JSON ONLY (no prose, no markdown fences):\n"
    '{"criterion": "<one sentence>"}'
)


def _build_propose_prompt(scenario: Scenario, existing: list[str]) -> str:
    rendered = (
        f"Scenario {scenario.id} — {scenario.title}\n"
        f"  Given: {'; '.join(scenario.given) or '(none)'}\n"
        f"  When:  {'; '.join(scenario.when) or '(none)'}\n"
        f"  Then:  {'; '.join(scenario.then) or '(none)'}\n"
    )
    crit_block = "\n".join(f"  - {c}" for c in existing) if existing else "  (none yet)"
    return (
        f"{rendered}\nEXISTING ACCEPTANCE CRITERIA:\n{crit_block}\n\n"
        "Draft one acceptance criterion that captures this scenario's promise. "
        "Return JSON with the criterion field."
    )


def propose_acceptance(
    scenario: Scenario,
    spec: StructuredSpec,
    gateway: Gateway,
) -> str:
    """Draft one acceptance-criterion sentence from a manual scenario.

    Falls back to a deterministic "After: <then-lines>" string if the
    planner reply can't be parsed — never raises so the review loop
    can always offer the user something to confirm or edit.
    """
    resp = gateway.call(
        role="planner",
        messages=[
            {"role": "system", "content": _PROPOSE_SYSTEM},
            {"role": "user", "content": _build_propose_prompt(scenario, list(spec.acceptance))},
        ],
        max_tokens=400,
    )
    fallback = (
        f"After {scenario.title.strip().rstrip('.')}: "
        + ("; ".join(scenario.then) if scenario.then else "the scenario's outcome holds")
    ).strip()
    if not isinstance(resp, GatewayResponse):
        return fallback
    data = _extract_json_object(resp.content)
    if not data:
        return fallback
    crit = data.get("criterion")
    if isinstance(crit, str) and crit.strip():
        return crit.strip()
    return fallback


def regenerate(
    spec: StructuredSpec,
    existing: ScenarioSet,
    gateway: Gateway,
) -> ScenarioSet:
    """Regenerate spec-source scenarios; keep ``gap`` and ``manual`` entries.

    Spec-source scenarios are dropped and replaced with a fresh planner
    pass. User-curated entries (``gap``, ``manual``) are preserved with
    their existing IDs.
    """
    fresh = Generator(gateway).generate(spec)
    preserved = [s for s in existing.scenarios if s.source in ("gap", "manual")]
    combined = list(fresh.scenarios) + preserved
    return ScenarioSet(
        spec_name=existing.spec_name,
        spec_version=existing.spec_version,
        scenarios=combined,
        generated_by=fresh.generated_by,
        generated_at=fresh.generated_at,
        cost_usd=existing.cost_usd + fresh.cost_usd,
        approved_at=None,  # regeneration invalidates prior approval
        approved_by="",
        deletions=list(existing.deletions),
    )


# ---------------------------------------------------------------------------
# Rendering (§7.1 / §7.2 plain-English view)
# ---------------------------------------------------------------------------


def to_text(scenarios: ScenarioSet, *, show_impl: bool = False) -> str:
    """Render the §7.1/§7.2 plain-English view.

    ``show_impl`` is the §7.4 flag for technical detail; in v0.1 we keep
    it minimal (no impl details to render yet) but accept it so the
    review CLI can call this signature directly.
    """
    if not scenarios.scenarios:
        return f"# {scenarios.spec_name} v{scenarios.spec_version}\n\n(no scenarios yet)\n"

    lines: list[str] = [f"# {scenarios.spec_name} v{scenarios.spec_version}", ""]
    for s in scenarios.scenarios:
        marker = {"gap": "[⚠]", "manual": "[+]", "spec": "[✓]"}.get(s.source, "[✓]")
        suffix = "  GAP DETECTED" if s.source == "gap" else ""
        lines.append(f"{marker} {s.id}  {s.title}{suffix}")
        for g in s.given:
            lines.append(f"    Given {g}")
        for w in s.when:
            lines.append(f"    When {w}")
        for t in s.then:
            lines.append(f"    Then {t}")
        if s.note:
            lines.append(f"    note: {s.note}")
        if show_impl and s.acceptance_ref is not None:
            lines.append(f"    (covers acceptance #{s.acceptance_ref})")
        lines.append("")
    return "\n".join(lines).rstrip() + "\n"


# ---------------------------------------------------------------------------
# YAML round-trip
# ---------------------------------------------------------------------------


def write_yaml(scenarios: ScenarioSet, path: str | Path) -> Path:
    """Persist a ScenarioSet to YAML. Returns the resolved path."""
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    text = yaml.safe_dump(scenarios.model_dump(), sort_keys=False, allow_unicode=True)
    p.write_text(text, encoding="utf-8")
    return p


def read_yaml(path: str | Path) -> ScenarioSet | None:
    """Load a ScenarioSet from YAML. Returns None if the file is absent."""
    p = Path(path)
    if not p.exists():
        return None
    data = yaml.safe_load(p.read_text(encoding="utf-8"))
    if not isinstance(data, dict):
        return None
    return ScenarioSet.model_validate(data)


__all__ = [
    "Scenario",
    "ScenarioSet",
    "Deletion",
    "Generator",
    "generate",
    "detect_gaps",
    "regenerate",
    "propose_acceptance",
    "to_text",
    "write_yaml",
    "read_yaml",
    "Source",
    "Confidence",
    "ALLOWED_SOURCES",
    "ALLOWED_CONFIDENCES",
]
