"""HEAP status — render the §11.1 status line + sprint/phase progress.

Pure formatter functions. Takes a ``Plan`` and (optionally) a ``RunState``
plus the most recent ``RunEvent`` list and returns a text block ready
for stdout.

Used by ``heap status`` (S7.P1) and re-used by ``heap watch`` (S7.P2)
for header rendering.

Design constraints:
  - No model calls, no I/O. Caller loads plan / state / events.
  - Output is plain ASCII + a few box characters; works in any terminal.
  - One render per call. Live tailing is the watcher's job.
"""

from __future__ import annotations

from datetime import UTC, datetime

from heap.plan import Plan
from heap.run import RunEvent, RunState

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _money(amount: float) -> str:
    if amount >= 100:
        return f"${amount:.0f}"
    return f"${amount:.4f}" if amount < 1 else f"${amount:.2f}"


def _tokens(n: int) -> str:
    if n >= 1000:
        return f"{n / 1000:.1f}k"
    return str(n)


def _elapsed(started_at: str) -> str:
    """Humanize ISO-8601 → elapsed since now (UTC)."""
    if not started_at:
        return "—"
    try:
        start = datetime.strptime(started_at, "%Y-%m-%dT%H:%M:%SZ").replace(tzinfo=UTC)
    except ValueError:
        return "—"
    delta = datetime.now(UTC) - start
    secs = int(delta.total_seconds())
    if secs < 60:
        return f"{secs}s"
    mins, s = divmod(secs, 60)
    if mins < 60:
        return f"{mins}m {s}s"
    hours, m = divmod(mins, 60)
    return f"{hours}h {m}m"


def _phase_for(plan: Plan, state: RunState):  # type: ignore[no-untyped-def]
    """Return the (sprint, phase) the run is currently inside, or None."""
    if state.sprint_idx >= len(plan.sprints):
        return None, None
    sprint = plan.sprints[state.sprint_idx]
    if state.phase_idx >= len(sprint.phases):
        return sprint, None
    return sprint, sprint.phases[state.phase_idx]


# ---------------------------------------------------------------------------
# §11.1 status line
# ---------------------------------------------------------------------------


def status_line(plan: Plan, state: RunState) -> str:
    """One-line status header: ``Sprint X of Y · Phase Sx.Py · name · elapsed``."""
    n_sprints = len(plan.sprints)
    sprint, phase = _phase_for(plan, state)

    # Status word reflecting the run's posture
    if state.run_status == "complete":
        head = f"Run complete · {len(state.completed_sprints)}/{n_sprints} sprints"
    elif state.run_status == "failed":
        head = f"Run failed at {state.failed_phase or '?'}"
    elif state.run_status == "awaiting_gate":
        head = (
            f"Sprint {state.sprint_idx + 1} of {n_sprints} · awaiting gate ({state.awaiting_gate})"
        )
    elif sprint is None:
        head = f"Run pending · {n_sprints} sprints planned"
    elif phase is None:
        head = f"Sprint {state.sprint_idx + 1} of {n_sprints} · {sprint.id} · {sprint.name}"
    else:
        head = f"Sprint {state.sprint_idx + 1} of {n_sprints} · Phase {phase.id} · {phase.name}"

    elapsed = _elapsed(state.started_at)
    line1 = f"{head} · {elapsed} elapsed"
    line2 = (
        f"  └─ status: {state.run_status} · "
        f"Tokens: in={_tokens(state.tokens_in_total)} "
        f"out={_tokens(state.tokens_out_total)} · "
        f"Cost: {_money(state.cost_usd_total)}"
    )
    return line1 + "\n" + line2


# ---------------------------------------------------------------------------
# Sprint progress block
# ---------------------------------------------------------------------------


def _checkbox(done: bool, current: bool) -> str:
    if done:
        return "✓"
    if current:
        return "▶"
    return "·"


def sprint_progress(plan: Plan, state: RunState) -> str:
    """Per-sprint summary table: status checkbox + sprint id + name."""
    if not plan.sprints:
        return "  (plan has no sprints)"
    lines: list[str] = []
    for i, sprint in enumerate(plan.sprints):
        if sprint.id in state.completed_sprints:
            mark = _checkbox(done=True, current=False)
            phase_summary = f"{len(sprint.phases)}/{len(sprint.phases)} phases"
        elif i == state.sprint_idx and state.run_status not in ("pending", "complete"):
            mark = _checkbox(done=False, current=True)
            phase_summary = f"{state.phase_idx}/{len(sprint.phases)} phases"
        else:
            mark = _checkbox(done=False, current=False)
            phase_summary = f"0/{len(sprint.phases)} phases"
        lines.append(f"  {mark} {sprint.id}  {sprint.name:<30} {phase_summary}")
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Recent events
# ---------------------------------------------------------------------------


def recent_events(events: list[RunEvent], n: int = 8) -> str:
    if not events:
        return "  (no events recorded yet)"
    tail = events[-n:]
    out: list[str] = []
    for ev in tail:
        suffix = f" — {ev.detail}" if ev.detail else ""
        out.append(f"  [{ev.ts}] {ev.kind:14} {ev.sprint_id:>4} {ev.phase_id:>8}{suffix}")
    return "\n".join(out)


# ---------------------------------------------------------------------------
# Top-level summary
# ---------------------------------------------------------------------------


def summary(plan: Plan, state: RunState | None, events: list[RunEvent] | None = None) -> str:
    """Multi-section status block.

    If ``state`` is None (no run yet), shows plan-only info.
    """
    lines: list[str] = []
    lines.append(f"plan:    {plan.plan_id}")
    lines.append(f"spec:    {plan.spec_ref}")
    if plan.approved_at:
        approver = f" by {plan.approved_by}" if plan.approved_by else ""
        lines.append(f"plan approved at {plan.approved_at}{approver}")
    else:
        lines.append("plan NOT approved (run `heap plan approve <name>` first)")

    if state is None:
        lines.append("")
        lines.append("(no run started yet — use `heap run start <name>` to begin)")
        lines.append("")
        lines.append("plan layout:")
        lines.append(sprint_progress(plan, _empty_state(plan)))
        return "\n".join(lines) + "\n"

    lines.append(f"run:     {state.run_id}")
    lines.append("")
    lines.append(status_line(plan, state))
    lines.append("")
    lines.append("sprint progress:")
    lines.append(sprint_progress(plan, state))
    if events:
        lines.append("")
        lines.append("recent events:")
        lines.append(recent_events(events))
    return "\n".join(lines) + "\n"


def _empty_state(plan: Plan) -> RunState:
    return RunState(
        run_id="",
        plan_id=plan.plan_id,
        plan_ref="",
        spec_ref=plan.spec_ref,
        run_status="pending",
    )


__all__ = [
    "summary",
    "status_line",
    "sprint_progress",
    "recent_events",
]
