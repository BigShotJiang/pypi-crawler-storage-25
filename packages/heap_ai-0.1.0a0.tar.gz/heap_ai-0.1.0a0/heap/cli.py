"""HEAP command-line interface.

Wires the spec module's Interrogator / Structurer / Validator together
behind ``heap spec new / show / list / amend`` per SPEC §6.4. The
``heap`` console script (declared in pyproject.toml) lands at
``heap.cli:main``.

This module deliberately keeps argument-parsing and I/O thin so the
underlying classes stay testable in isolation. End-to-end (real model)
testing happens at the S3 gate.
"""

from __future__ import annotations

import os
import sys

import click
import yaml
from dotenv import load_dotenv

from heap import __version__
from heap.gateway import Gateway, GatewayResponse
from heap.plan import (
    ALLOWED_AMENDMENT_KINDS,
    Amendment,
    AmendmentError,
    apply_amendment,
    approve_plan,
    read_plan,
)
from heap.plan import generate as plan_generate
from heap.plan import to_text as plan_to_text
from heap.plan import write_plan as plan_write_yaml
from heap.run import (
    DEFAULT_RUNS_BASE,
    PhaseResult,
    RunContext,
    RunEngine,
    list_runs,
    load_events,
    load_run,
    load_state,
)
from heap.scenarios import (
    Deletion,
    Generator,
    Scenario,
    ScenarioSet,
    propose_acceptance,
    read_yaml,
    regenerate,
    to_text,
    write_yaml,
)
from heap.spec import Interrogator, Structurer, Validator
from heap.status import summary as status_summary
from heap.watch import format_event, tail_jsonl

# v0.1 default models per SPEC §3.
_DEFAULT_PLANNER = "anthropic/claude-opus-4-7"
_DEFAULT_WORKER = "anthropic/claude-sonnet-4-6"
_DEFAULT_FAST = "anthropic/claude-haiku-4-5-20251001"


# ---------------------------------------------------------------------------
# Top-level group
# ---------------------------------------------------------------------------


@click.group()
@click.version_option(version=__version__, prog_name="heap")
def main() -> None:
    """HEAP — Harness for Execution, Approvals & Plans.

    A spec-driven, approval-gated harness for AI agents.
    """


# ---------------------------------------------------------------------------
# `heap spec` subgroup
# ---------------------------------------------------------------------------


@main.group("spec")
def spec_group() -> None:
    """Spec management — interrogate, list, show, amend."""


@spec_group.command("new")
@click.option(
    "--mode",
    type=click.Choice(["feature", "bug", "greenfield"], case_sensitive=False),
    required=True,
    help="Interrogation mode.",
)
@click.option(
    "--audience",
    type=click.Choice(["non_technical", "developer"], case_sensitive=False),
    default="developer",
    show_default=True,
    help="Vocabulary level.",
)
@click.option(
    "--name",
    default=None,
    help="Spec name (alphanumeric/_/-). Prompted if omitted.",
)
@click.option(
    "--validate/--no-validate",
    default=True,
    show_default=True,
    help="Run an adversarial validator pass after the interrogation.",
)
@click.option(
    "--specs-dir",
    default="specs",
    show_default=True,
    help="Directory to write spec artifacts.",
)
def cmd_new(mode: str, audience: str, name: str | None, validate: bool, specs_dir: str) -> None:
    """Create a new spec via interactive interrogation."""
    load_dotenv()
    if not os.getenv("ANTHROPIC_API_KEY"):
        click.echo(
            "Error: ANTHROPIC_API_KEY is not set. Copy .env.example to .env and fill in your key.",
            err=True,
        )
        sys.exit(1)

    if not name:
        name = click.prompt("Spec name (alphanumeric, hyphens, underscores)")

    gw = _build_gateway()
    structurer = Structurer(specs_dir=specs_dir)

    click.echo(f"Starting {mode}-mode interrogation for spec {name!r}...")
    outcome = Interrogator(mode=mode, audience=audience, gateway=gw).interview()

    if outcome.incomplete:
        click.secho(
            f"\nWarning: interrogation flagged as incomplete: {outcome.incomplete_reason}",
            fg="yellow",
            err=True,
        )

    spec = structurer.write(outcome, name=name)

    click.secho("\nWrote artifacts:", fg="green")
    click.echo(f"  {specs_dir}/{name}.spec.yaml      (canonical, v{spec.version})")
    click.echo(f"  {specs_dir}/{name}.spec.v{spec.version}.yaml")
    click.echo(f"  {specs_dir}/{name}.spec.md")
    click.echo(f"  {specs_dir}/{name}.acceptance.json")

    if validate:
        click.echo("\nRunning adversarial validator...")
        report = Validator(gw).validate(spec)
        if report.parse_failed:
            click.secho(
                "  validator response was not parseable; skipping findings.",
                fg="yellow",
            )
        elif report.findings:
            click.secho(f"  {len(report.findings)} potential issue(s) flagged:", fg="yellow")
            for f in report.findings:
                click.echo(f"    [{f.severity}] {f.description}")
                if f.suggestion:
                    click.echo(f"        → {f.suggestion}")
        else:
            click.secho("  no issues found.", fg="green")
        click.echo(f"  validator cost: ${report.cost_usd:.6f}")

    click.echo(
        f"\nGateway total: ${gw.spent_usd:.6f}  ({gw.calls_made} calls, "
        f"in={gw.tokens_in} out={gw.tokens_out})"
    )


@spec_group.command("show")
@click.argument("name")
@click.option(
    "--version",
    type=int,
    default=None,
    help="Specific version to show. Defaults to latest.",
)
@click.option("--specs-dir", default="specs", show_default=True)
def cmd_show(name: str, version: int | None, specs_dir: str) -> None:
    """Print a spec (latest, or --version N)."""
    structurer = Structurer(specs_dir=specs_dir)
    spec = structurer.read(name, version=version)
    if spec is None:
        target = f"{name} v{version}" if version else name
        click.echo(f"Spec {target!r} not found in {specs_dir}/.", err=True)
        sys.exit(1)
    click.echo(yaml.safe_dump(spec.model_dump(), sort_keys=False, allow_unicode=True))


@spec_group.command("list")
@click.option("--specs-dir", default="specs", show_default=True)
def cmd_list(specs_dir: str) -> None:
    """List all specs and their versions."""
    structurer = Structurer(specs_dir=specs_dir)
    names = structurer.list()
    if not names:
        click.echo("(no specs found)")
        return
    for n in names:
        versions = structurer.list_versions(n)
        v_str = ", ".join(f"v{v}" for v in versions) if versions else "?"
        click.echo(f"  {n}    [{v_str}]")


@spec_group.command("amend")
@click.argument("name")
@click.option(
    "--mode",
    type=click.Choice(["feature", "bug", "greenfield"], case_sensitive=False),
    default=None,
    help="Override mode (defaults to existing spec's mode).",
)
@click.option("--specs-dir", default="specs", show_default=True)
def cmd_amend(name: str, mode: str | None, specs_dir: str) -> None:
    """Amend an existing spec — runs a fresh interrogation, bumps version."""
    structurer = Structurer(specs_dir=specs_dir)
    existing = structurer.read(name)
    if existing is None:
        click.echo(
            f"Spec {name!r} not found in {specs_dir}/. Did you mean `heap spec new`?",
            err=True,
        )
        sys.exit(1)

    actual_mode = mode or existing.mode
    audience = existing.audience

    load_dotenv()
    if not os.getenv("ANTHROPIC_API_KEY"):
        click.echo("Error: ANTHROPIC_API_KEY is not set.", err=True)
        sys.exit(1)

    click.echo(
        f"Amending {name!r} (current v{existing.version}, "
        f"mode={actual_mode}, audience={audience})..."
    )
    gw = _build_gateway()
    outcome = Interrogator(mode=actual_mode, audience=audience, gateway=gw).interview()
    new_spec = structurer.write(outcome, name=name)
    click.secho(f"\nWrote v{new_spec.version}: {specs_dir}/{name}.spec.yaml", fg="green")


# ---------------------------------------------------------------------------
# `heap scenarios` subgroup
# ---------------------------------------------------------------------------


@main.group("scenarios")
def scenarios_group() -> None:
    """Scenario management — generate, show, review."""


@scenarios_group.command("generate")
@click.argument("name")
@click.option(
    "--specs-dir",
    default="specs",
    show_default=True,
    help="Directory holding spec artifacts and scenarios YAML.",
)
@click.option(
    "--detect-gaps/--no-detect-gaps",
    default=True,
    show_default=True,
    help="Run an adversarial gap-detection pass after generation.",
)
def cmd_scenarios_generate(name: str, specs_dir: str, detect_gaps: bool) -> None:
    """Generate scenarios for an existing spec."""
    structurer = Structurer(specs_dir=specs_dir)
    spec = structurer.read(name)
    if spec is None:
        click.echo(f"Spec {name!r} not found in {specs_dir}/.", err=True)
        sys.exit(1)
    if not spec.acceptance:
        click.secho(
            f"Spec {name!r} has no acceptance criteria; nothing to generate.",
            fg="yellow",
        )

    load_dotenv()
    if not os.getenv("ANTHROPIC_API_KEY"):
        click.echo("Error: ANTHROPIC_API_KEY is not set.", err=True)
        sys.exit(1)

    gw = _build_gateway()
    gen = Generator(gw)

    click.echo(f"Generating scenarios for {name!r} (v{spec.version})...")
    scenarios = gen.generate(spec)

    if detect_gaps and scenarios.scenarios:
        click.echo("Running gap detector...")
        gaps = gen.detect_gaps(spec, scenarios)
        if gaps:
            scenarios.scenarios.extend(gaps)
            click.echo(f"  added {len(gaps)} gap scenario(s).")
        else:
            click.echo("  no gaps found.")

    out_path = _scenarios_path(specs_dir, name)
    write_yaml(scenarios, out_path)
    click.secho(f"\nWrote {out_path} ({len(scenarios.scenarios)} scenarios).", fg="green")
    click.echo(
        f"Gateway total: ${gw.spent_usd:.6f}  ({gw.calls_made} calls, "
        f"in={gw.tokens_in} out={gw.tokens_out})"
    )


@scenarios_group.command("show")
@click.argument("name")
@click.option("--specs-dir", default="specs", show_default=True)
@click.option("--show-impl/--no-show-impl", default=False, show_default=True)
def cmd_scenarios_show(name: str, specs_dir: str, show_impl: bool) -> None:
    """Print the rendered scenario list for ``name``."""
    scenarios = read_yaml(_scenarios_path(specs_dir, name))
    if scenarios is None:
        click.echo(
            f"No scenarios for {name!r} in {specs_dir}/. Run `heap scenarios generate` first.",
            err=True,
        )
        sys.exit(1)
    click.echo(to_text(scenarios, show_impl=show_impl))
    if scenarios.approved_at:
        click.secho(
            f"Approved at {scenarios.approved_at}"
            + (f" by {scenarios.approved_by}" if scenarios.approved_by else ""),
            fg="green",
        )


@scenarios_group.command("review")
@click.argument("name")
@click.option("--specs-dir", default="specs", show_default=True)
def cmd_scenarios_review(name: str, specs_dir: str) -> None:
    """Interactive review per SPEC §7.3."""
    path = _scenarios_path(specs_dir, name)
    scenarios = read_yaml(path)
    if scenarios is None:
        click.echo(
            f"No scenarios for {name!r} in {specs_dir}/. Run `heap scenarios generate` first.",
            err=True,
        )
        sys.exit(1)

    structurer = Structurer(specs_dir=specs_dir)
    spec = structurer.read(name)
    if spec is None:
        click.echo(f"Spec {name!r} not found in {specs_dir}/.", err=True)
        sys.exit(1)

    gw_factory = _build_gateway  # late-binding so tests can monkeypatch
    final = _review_loop(
        scenarios,
        spec=spec,
        structurer=structurer,
        gw_factory=gw_factory,
        output=click.echo,
    )

    if final is None:
        click.secho("Review cancelled. No changes saved.", fg="yellow")
        return

    write_yaml(final, path)
    if final.approved_at:
        click.secho(f"\nApproved. Wrote {path}.", fg="green")
    else:
        click.secho(f"\nSaved (not yet approved). Wrote {path}.", fg="yellow")


# ---------------------------------------------------------------------------
# Review loop helpers (module-level so they're unit-testable)
# ---------------------------------------------------------------------------


def _scenarios_path(specs_dir: str, name: str):  # type: ignore[no-untyped-def]
    from pathlib import Path

    return Path(specs_dir) / f"{name}.scenarios.yaml"


def _now_iso() -> str:
    from datetime import UTC, datetime

    return datetime.now(UTC).strftime("%Y-%m-%dT%H:%M:%SZ")


def _next_manual_id(scenarios: ScenarioSet) -> str:
    """Next available M<n> id."""
    used = {
        int(s.id[1:])
        for s in scenarios.scenarios
        if s.source == "manual" and s.id[:1] == "M" and s.id[1:].isdigit()
    }
    n = 1
    while n in used:
        n += 1
    return f"M{n}"


def _find(scenarios: ScenarioSet, sid: str) -> Scenario | None:
    for s in scenarios.scenarios:
        if s.id == sid:
            return s
    return None


def _action_add(
    scenarios: ScenarioSet,
    *,
    spec=None,  # type: ignore[no-untyped-def]
    structurer=None,  # type: ignore[no-untyped-def]
    gateway=None,  # type: ignore[no-untyped-def]
    specs_dir: str = "specs",
):  # type: ignore[no-untyped-def]
    """Prompt for a new manual scenario; append it. Returns ``(scenarios, new_spec_or_None)``.

    If ``spec``, ``structurer``, and ``gateway`` are provided the user is
    offered the §7.6 spec-amendment path: promote the new scenario to an
    acceptance criterion and bump the spec version. If the user declines or
    the path is unavailable, the second element of the tuple is ``None``.
    """
    title = click.prompt("Title")
    given = _prompt_lines("Given (one per line, blank to finish)")
    when = _prompt_lines("When (one per line, blank to finish)")
    then = _prompt_lines("Then (one per line, blank to finish)")
    new = Scenario(
        id=_next_manual_id(scenarios),
        title=title.strip(),
        given=given,
        when=when,
        then=then,
        source="manual",
        confidence="medium",
    )
    scenarios.scenarios.append(new)

    if spec is None or structurer is None or gateway is None:
        click.secho(
            "(spec amendment offer requires gateway+structurer+spec; "
            "scenario added but the spec is unchanged.)",
            fg="yellow",
        )
        return scenarios, None

    if not click.confirm(
        "Promote this scenario to a new spec acceptance criterion (bumps spec version)?",
        default=False,
    ):
        return scenarios, None

    draft = propose_acceptance(new, spec, gateway)
    click.echo(f"\nDrafted criterion:\n  {draft}\n")
    final = click.prompt("Press enter to accept, or edit", default=draft)
    final = final.strip()
    if not final:
        click.secho("  empty criterion — skipping spec amendment.", fg="yellow")
        return scenarios, None

    try:
        new_spec = structurer.append_acceptance(spec.name, final)
    except ValueError as e:
        click.secho(f"  spec amendment failed: {e}", fg="red")
        return scenarios, None

    new.acceptance_ref = len(new_spec.acceptance) - 1
    scenarios.spec_version = new_spec.version
    click.secho(
        f"  spec {spec.name!r} bumped to v{new_spec.version}; "
        f"scenario {new.id} now references acceptance #{new.acceptance_ref}.",
        fg="green",
    )
    return scenarios, new_spec


def _action_edit(scenarios: ScenarioSet, sid: str) -> ScenarioSet:
    s = _find(scenarios, sid)
    if s is None:
        click.secho(f"  no scenario with id {sid!r}.", fg="red")
        return scenarios
    new_title = click.prompt("Title", default=s.title)
    s.title = new_title.strip()
    if click.confirm("Replace Given/When/Then?", default=False):
        s.given = _prompt_lines("Given (one per line, blank to finish)")
        s.when = _prompt_lines("When (one per line, blank to finish)")
        s.then = _prompt_lines("Then (one per line, blank to finish)")
    return scenarios


def _action_delete(scenarios: ScenarioSet, sid: str, *, reason: str = "") -> ScenarioSet:
    s = _find(scenarios, sid)
    if s is None:
        click.secho(f"  no scenario with id {sid!r}.", fg="red")
        return scenarios
    if not reason:
        reason = click.prompt("Reason for deletion", default="")
    scenarios.scenarios = [x for x in scenarios.scenarios if x.id != sid]
    scenarios.deletions.append(
        Deletion(id=s.id, title=s.title, reason=reason.strip(), deleted_at=_now_iso())
    )
    click.secho(f"  deleted {sid}.", fg="yellow")
    return scenarios


def _action_discuss(scenarios: ScenarioSet, sid: str, *, gateway: Gateway) -> str:
    """One-shot planner discussion about a scenario. No mutation."""
    s = _find(scenarios, sid)
    if s is None:
        return f"no scenario with id {sid!r}."
    user_q = click.prompt("Question for the planner about this scenario")
    rendered = (
        f"Scenario {s.id} — {s.title}\n"
        f"  Given: {'; '.join(s.given) or '(none)'}\n"
        f"  When:  {'; '.join(s.when) or '(none)'}\n"
        f"  Then:  {'; '.join(s.then) or '(none)'}\n"
        f"  source={s.source} acceptance_ref={s.acceptance_ref}"
    )
    resp = gateway.call(
        role="planner",
        messages=[
            {
                "role": "system",
                "content": (
                    "You are helping a user reason about a single Given/When/Then "
                    "scenario. Answer their question concisely (3-5 sentences). "
                    "Suggest concrete edits if you see weaknesses, but do not "
                    "rewrite the scenario yourself."
                ),
            },
            {"role": "user", "content": f"{rendered}\n\nQuestion: {user_q}"},
        ],
        max_tokens=600,
    )
    if not isinstance(resp, GatewayResponse):
        return f"(unexpected gateway response type: {type(resp)!r})"
    return resp.content or "(no response)"


def _action_regenerate(
    scenarios: ScenarioSet,
    *,
    spec,
    gateway: Gateway,  # type: ignore[no-untyped-def]
) -> ScenarioSet:
    """Drop spec-source scenarios; keep gap+manual; re-run generation."""
    notes = click.prompt("Optional notes for the regenerator", default="")
    if notes:
        click.echo(f"  (notes recorded: {notes!r}; v0.1 doesn't yet inject them into the prompt)")
    return regenerate(spec, scenarios, gateway)


def _prompt_lines(label: str) -> list[str]:
    """Read multiple lines from the user; blank line ends input."""
    click.echo(f"{label}:")
    out: list[str] = []
    while True:
        line = click.prompt("  ", default="", show_default=False, prompt_suffix="").strip()
        if not line:
            break
        out.append(line)
    return out


def _review_loop(  # noqa: C901 — explicit dispatch is clearer than a table here
    scenarios: ScenarioSet,
    *,
    spec,  # type: ignore[no-untyped-def]
    structurer=None,  # type: ignore[no-untyped-def]
    gw_factory,  # type: ignore[no-untyped-def]
    output=click.echo,  # type: ignore[no-untyped-def]
) -> ScenarioSet | None:
    """Drive the §7.3 review loop. Returns final ScenarioSet or None on quit."""
    gateway: Gateway | None = None  # lazy: only built if we need it (regenerate / discuss)

    def _gw() -> Gateway:
        nonlocal gateway
        if gateway is None:
            load_dotenv()
            if not os.getenv("ANTHROPIC_API_KEY"):
                raise click.UsageError("ANTHROPIC_API_KEY is not set.")
            gateway = gw_factory()
        return gateway

    while True:
        output(to_text(scenarios))
        output(
            "ACTIONS  [a]pprove  [e <id>] edit  [+] add  [d <id>] delete  "
            "[? <id>] discuss  [r]egenerate  [q]uit"
        )
        cmd = click.prompt("›", default="", show_default=False).strip()
        if not cmd:
            continue

        head = cmd.split(maxsplit=1)[0].lower()
        rest = cmd[len(head) :].strip()

        if head == "a":
            scenarios.approved_at = _now_iso()
            return scenarios
        if head == "q":
            return None
        if head == "+":
            try:
                gw = _gw() if structurer is not None else None
            except click.UsageError:
                gw = None
            scenarios, maybe_new_spec = _action_add(
                scenarios,
                spec=spec if structurer is not None else None,
                structurer=structurer,
                gateway=gw,
            )
            if maybe_new_spec is not None:
                spec = maybe_new_spec
            continue
        if head == "r":
            try:
                scenarios = _action_regenerate(scenarios, spec=spec, gateway=_gw())
            except click.UsageError as e:
                output(f"  {e.format_message()}")
            continue
        if head == "e":
            if not rest:
                output("  usage: e <id>")
                continue
            scenarios = _action_edit(scenarios, rest)
            continue
        if head == "d":
            if not rest:
                output("  usage: d <id>")
                continue
            parts = rest.split(maxsplit=1)
            sid = parts[0]
            reason = parts[1] if len(parts) > 1 else ""
            scenarios = _action_delete(scenarios, sid, reason=reason)
            continue
        if head == "?":
            if not rest:
                output("  usage: ? <id>")
                continue
            try:
                answer = _action_discuss(scenarios, rest, gateway=_gw())
                output(f"\n{answer}\n")
            except click.UsageError as e:
                output(f"  {e.format_message()}")
            continue

        output(f"  unknown action: {cmd!r}")


# ---------------------------------------------------------------------------
# `heap plan` subgroup
# ---------------------------------------------------------------------------


@main.group("plan")
def plan_group() -> None:
    """Plan management — generate, show, list."""


@plan_group.command("generate")
@click.argument("name")
@click.option("--specs-dir", default="specs", show_default=True)
@click.option(
    "--include-scenarios/--no-include-scenarios",
    default=True,
    show_default=True,
    help="Pass approved scenarios into the plan prompt (when present).",
)
def cmd_plan_generate(name: str, specs_dir: str, include_scenarios: bool) -> None:
    """Generate a plan for an existing spec (and optional scenarios)."""
    structurer = Structurer(specs_dir=specs_dir)
    spec = structurer.read(name)
    if spec is None:
        click.echo(f"Spec {name!r} not found in {specs_dir}/.", err=True)
        sys.exit(1)

    scenarios = None
    if include_scenarios:
        scenarios = read_yaml(_scenarios_path(specs_dir, name))
        if scenarios is None:
            click.secho(
                "  (no scenarios.yaml found; generating plan from spec only.)",
                fg="yellow",
            )

    load_dotenv()
    if not os.getenv("ANTHROPIC_API_KEY"):
        click.echo("Error: ANTHROPIC_API_KEY is not set.", err=True)
        sys.exit(1)

    gw = _build_gateway()
    click.echo(f"Generating plan for {name!r} (v{spec.version})...")
    plan = plan_generate(spec, gw, scenarios=scenarios) if scenarios else plan_generate(spec, gw)

    out_path = _plan_path(specs_dir, name)
    plan_write_yaml(plan, out_path)
    click.secho(f"\nWrote {out_path} ({len(plan.sprints)} sprints).", fg="green")
    click.echo(
        f"Gateway total: ${gw.spent_usd:.6f}  ({gw.calls_made} calls, "
        f"in={gw.tokens_in} out={gw.tokens_out})"
    )


@plan_group.command("show")
@click.argument("name")
@click.option("--specs-dir", default="specs", show_default=True)
def cmd_plan_show(name: str, specs_dir: str) -> None:
    """Print the §10-formatted plan for ``name``."""
    plan = read_plan(_plan_path(specs_dir, name))
    if plan is None:
        click.echo(
            f"No plan for {name!r} in {specs_dir}/. Run `heap plan generate` first.",
            err=True,
        )
        sys.exit(1)
    click.echo(plan_to_text(plan))
    if plan.approved_at:
        click.secho(
            f"Approved at {plan.approved_at}"
            + (f" by {plan.approved_by}" if plan.approved_by else ""),
            fg="green",
        )


@plan_group.command("list")
@click.option("--specs-dir", default="specs", show_default=True)
def cmd_plan_list(specs_dir: str) -> None:
    """List plan files in the specs directory."""
    from pathlib import Path

    p = Path(specs_dir)
    if not p.exists():
        click.echo("(no plans found)")
        return
    plans = sorted(
        f.name[: -len(".plan.yaml")] for f in p.iterdir() if f.name.endswith(".plan.yaml")
    )
    if not plans:
        click.echo("(no plans found)")
        return
    for n in plans:
        click.echo(f"  {n}")


@plan_group.command("amend")
@click.argument("name")
@click.option("--specs-dir", default="specs", show_default=True)
@click.option(
    "--kind",
    type=click.Choice(list(ALLOWED_AMENDMENT_KINDS), case_sensitive=False),
    default=None,
    help="Amendment kind. Prompted if omitted.",
)
@click.option(
    "--sprint-id",
    default=None,
    help="Target sprint id (required for sprint/phase-scoped amendments).",
)
@click.option(
    "--phase-id",
    default=None,
    help="Target phase id (required for phase-scoped amendments).",
)
@click.option(
    "--rationale",
    default=None,
    help="Why this amendment is needed (prompted if omitted).",
)
def cmd_plan_amend(  # noqa: C901 — dispatch on kind is naturally branchy
    name: str,
    specs_dir: str,
    kind: str | None,
    sprint_id: str | None,
    phase_id: str | None,
    rationale: str | None,
) -> None:
    """Amend a plan — interactive prompt then apply, bumping rev."""
    path = _plan_path(specs_dir, name)
    plan = read_plan(path)
    if plan is None:
        click.echo(f"No plan for {name!r} in {specs_dir}/.", err=True)
        sys.exit(1)

    if kind is None:
        click.echo("Pick an amendment kind:")
        for i, k in enumerate(ALLOWED_AMENDMENT_KINDS, 1):
            click.echo(f"  [{i}] {k}")
        choice = click.prompt("›", default="1")
        try:
            kind = ALLOWED_AMENDMENT_KINDS[int(choice) - 1]
        except (ValueError, IndexError):
            click.echo(f"Invalid choice {choice!r}.", err=True)
            sys.exit(1)

    payload: dict = {}
    if kind == "add_phase":
        sprint_id = sprint_id or click.prompt("Sprint id (e.g. S1)")
        payload["id"] = click.prompt("New phase id (e.g. S1.P3)")
        payload["name"] = click.prompt("Phase name")
        payload["agent"] = click.prompt("Agent", default="worker/Sonnet")
        payload["gate"] = click.prompt("Phase gate", default="")
    elif kind == "add_deliverable":
        sprint_id = sprint_id or click.prompt("Sprint id")
        phase_id = phase_id or click.prompt("Phase id")
        payload["deliverable"] = click.prompt("Deliverable to add")
    elif kind == "add_test":
        sprint_id = sprint_id or click.prompt("Sprint id")
        phase_id = phase_id or click.prompt("Phase id")
        payload["test"] = click.prompt("Test to add")
    elif kind == "change_gate":
        sprint_id = sprint_id or click.prompt("Sprint id")
        if not phase_id:
            phase_id = click.prompt("Phase id (blank for sprint-level)", default="")
        payload["gate"] = click.prompt("New gate text")
    elif kind == "add_risk":
        payload["description"] = click.prompt("Risk description")
        payload["severity"] = click.prompt(
            "Severity",
            type=click.Choice(["low", "medium", "high"], case_sensitive=False),
            default="medium",
        )
        payload["mitigation"] = click.prompt("Mitigation", default="")
    elif kind == "add_scope_out":
        payload["item"] = click.prompt("Out-of-scope item")
    else:
        click.echo(f"unsupported kind: {kind!r}", err=True)
        sys.exit(1)

    if rationale is None:
        rationale = click.prompt("Rationale (why is this needed?)", default="")

    amendment = Amendment(
        kind=kind,  # type: ignore[arg-type]
        sprint_id=sprint_id or "",
        phase_id=phase_id or "",
        payload=payload,
        rationale=rationale or "",
    )

    try:
        new_plan = apply_amendment(plan, amendment)
    except AmendmentError as e:
        click.echo(f"Amendment failed: {e}", err=True)
        sys.exit(1)

    plan_write_yaml(new_plan, path)
    click.secho(
        f"Plan {name!r} bumped to rev {new_plan.rev} "
        f"({len(new_plan.revisions)} revision(s); approval reset).",
        fg="green",
    )


@plan_group.command("approve")
@click.argument("name")
@click.option("--specs-dir", default="specs", show_default=True)
@click.option("--by", default="", help="Approver name (defaults to empty).")
def cmd_plan_approve(name: str, specs_dir: str, by: str) -> None:
    """Mark a plan as approved."""
    path = _plan_path(specs_dir, name)
    plan = read_plan(path)
    if plan is None:
        click.echo(f"No plan for {name!r} in {specs_dir}/.", err=True)
        sys.exit(1)
    new_plan = approve_plan(plan, approver=by)
    plan_write_yaml(new_plan, path)
    click.secho(
        f"Plan {name!r} approved at {new_plan.approved_at}" + (f" by {by}" if by else "") + ".",
        fg="green",
    )


def _plan_path(specs_dir: str, name: str):  # type: ignore[no-untyped-def]
    from pathlib import Path

    return Path(specs_dir) / f"{name}.plan.yaml"


# ---------------------------------------------------------------------------
# `heap run` subgroup
# ---------------------------------------------------------------------------


@main.group("run")
def run_group() -> None:
    """Run engine — start / resume / approve / show / list runs."""


def _interactive_executor(ctx: RunContext) -> PhaseResult:
    """Default executor for `heap run` — prompts the operator for each phase.

    Real automated executors will replace this in S7. For S6 the engine
    needs *something* to drive it through the loop and exercise the
    persistence layer; an operator-in-the-loop executor does that without
    pulling in another model call.
    """
    click.echo()
    click.secho(
        f"▶ Phase {ctx.phase.id} — {ctx.phase.name}  [{ctx.phase.agent}]",
        fg="cyan",
    )
    if ctx.phase.deliverables:
        click.echo("  deliverables:")
        for d in ctx.phase.deliverables:
            click.echo(f"    • {d}")
    if ctx.phase.tests:
        click.echo("  tests:")
        for t in ctx.phase.tests:
            click.echo(f"    • {t}")
    click.echo(f"  gate: {ctx.phase.gate or '(none)'}")
    answer = click.prompt(
        "  result",
        type=click.Choice(["pass", "fail"], case_sensitive=False),
        default="pass",
    )
    detail = click.prompt("  notes (optional)", default="", show_default=False)
    return PhaseResult(passed=(answer == "pass"), detail=detail.strip())


@run_group.command("start")
@click.argument("name")
@click.option("--specs-dir", default="specs", show_default=True)
@click.option("--runs-base", "runs_base_opt", default=DEFAULT_RUNS_BASE, show_default=True)
def cmd_run_start(name: str, specs_dir: str, runs_base_opt: str) -> None:
    """Start a new run from an approved plan; halts at the first sprint gate."""
    plan_path = _plan_path(specs_dir, name)
    plan = read_plan(plan_path)
    if plan is None:
        click.echo(f"No plan for {name!r} in {specs_dir}/.", err=True)
        sys.exit(1)
    if not plan.approved_at:
        click.secho(
            "  warning: plan is not approved. Run `heap plan approve` first if you want a clean record.",
            fg="yellow",
        )

    from pathlib import Path as _P

    base = _P(runs_base_opt)
    engine = RunEngine(
        plan,
        execute_phase=_interactive_executor,
        run_dir=None,  # set below once we know the run_id
        plan_ref=str(plan_path),
    )
    engine.run_dir = base / engine.state.run_id
    engine.run_dir.mkdir(parents=True, exist_ok=True)
    engine.state.plan_ref = str(plan_path)

    click.echo(f"Starting run {engine.state.run_id!r} for plan {plan.plan_id!r}.")
    state = engine.run()
    _print_run_summary(state)


@run_group.command("resume")
@click.argument("run_id")
@click.option("--runs-base", "runs_base_opt", default=DEFAULT_RUNS_BASE, show_default=True)
def cmd_run_resume(run_id: str, runs_base_opt: str) -> None:
    """Resume a run from disk; continues from the last persisted boundary."""
    try:
        engine = load_run(
            run_id,
            execute_phase=_interactive_executor,
            base=runs_base_opt,
        )
    except (FileNotFoundError, ValueError) as e:
        click.echo(f"Resume failed: {e}", err=True)
        sys.exit(1)
    click.echo(f"Resuming run {run_id!r} (status: {engine.state.run_status}).")
    state = engine.run()
    _print_run_summary(state)


@run_group.command("approve")
@click.argument("run_id")
@click.option("--runs-base", "runs_base_opt", default=DEFAULT_RUNS_BASE, show_default=True)
@click.option("--by", default="", help="Approver name.")
def cmd_run_approve(run_id: str, runs_base_opt: str, by: str) -> None:
    """Approve the current sprint gate and advance to the next sprint."""
    try:
        engine = load_run(
            run_id,
            execute_phase=_interactive_executor,
            base=runs_base_opt,
        )
    except (FileNotFoundError, ValueError) as e:
        click.echo(f"Approve failed: {e}", err=True)
        sys.exit(1)
    if engine.state.run_status != "awaiting_gate":
        click.echo(
            f"Run {run_id!r} is not awaiting a gate (status: {engine.state.run_status}).",
            err=True,
        )
        sys.exit(1)
    state = engine.approve_gate(approver=by)
    click.secho(
        f"Gate {state.completed_sprints[-1]!r} approved"
        + (f" by {by}" if by else "")
        + f"; sprint_idx now {state.sprint_idx}.",
        fg="green",
    )


@run_group.command("show")
@click.argument("run_id")
@click.option("--runs-base", "runs_base_opt", default=DEFAULT_RUNS_BASE, show_default=True)
@click.option("--events", "n_events", type=int, default=10, show_default=True)
def cmd_run_show(run_id: str, runs_base_opt: str, n_events: int) -> None:
    """Print the current state of a run + last N trace events."""
    state = load_state(run_id, runs_base_opt)
    if state is None:
        click.echo(f"No run {run_id!r} under {runs_base_opt}/.", err=True)
        sys.exit(1)
    _print_run_summary(state)
    events = load_events(run_id, runs_base_opt)
    if events:
        click.echo("\nrecent events:")
        for ev in events[-n_events:]:
            tail = f" — {ev.detail}" if ev.detail else ""
            click.echo(f"  [{ev.ts}] {ev.kind:14} {ev.sprint_id:>4} {ev.phase_id:>8}{tail}")


@run_group.command("list")
@click.option("--runs-base", "runs_base_opt", default=DEFAULT_RUNS_BASE, show_default=True)
def cmd_run_list(runs_base_opt: str) -> None:
    """List run ids under the runs base directory."""
    runs = list_runs(runs_base_opt)
    if not runs:
        click.echo("(no runs found)")
        return
    for rid in runs:
        st = load_state(rid, runs_base_opt)
        status = st.run_status if st else "?"
        click.echo(f"  {rid}    [{status}]")


# ---------------------------------------------------------------------------
# `heap watch` (S7.P2)
# ---------------------------------------------------------------------------


@main.command("watch")
@click.argument("run_id")
@click.option(
    "--follow/--no-follow",
    default=True,
    show_default=True,
    help="Tail new events live (Ctrl-C to stop) vs print last N and exit.",
)
@click.option("-n", "n_events", type=int, default=20, show_default=True)
@click.option("--runs-base", "runs_base_opt", default=DEFAULT_RUNS_BASE, show_default=True)
@click.option("--no-color", is_flag=True, help="Disable ANSI colors.")
def cmd_watch(
    run_id: str,
    follow: bool,
    n_events: int,
    runs_base_opt: str,
    no_color: bool,
) -> None:
    """Live tail of a run's trace.jsonl (or snapshot of last N events)."""
    from pathlib import Path as _P

    trace = _P(runs_base_opt) / run_id / "trace.jsonl"
    if not trace.exists() and not follow:
        click.echo(f"No trace.jsonl for run {run_id!r} under {runs_base_opt}/.", err=True)
        sys.exit(1)

    use_color = not no_color
    try:
        for ev in tail_jsonl(trace, follow=follow, n=n_events):
            click.echo(format_event(ev, color=use_color))
    except KeyboardInterrupt:
        click.echo("\n(stopped watching)")


# ---------------------------------------------------------------------------
# `heap status` (S7.P1)
# ---------------------------------------------------------------------------


@main.command("status")
@click.argument("name", required=False)
@click.option("--run-id", default=None, help="Specific run id (defaults to latest).")
@click.option("--specs-dir", default="specs", show_default=True)
@click.option("--runs-base", "runs_base_opt", default=DEFAULT_RUNS_BASE, show_default=True)
@click.option("--events", "n_events", type=int, default=8, show_default=True)
def cmd_status(
    name: str | None,
    run_id: str | None,
    specs_dir: str,
    runs_base_opt: str,
    n_events: int,
) -> None:
    """Snapshot of where a run + plan currently stand (§11.1)."""
    state = None
    plan = None
    events: list = []

    # Resolve which run (if any) to display.
    if run_id is not None:
        state = load_state(run_id, runs_base_opt)
        if state is None:
            click.echo(f"No run {run_id!r} under {runs_base_opt}/.", err=True)
            sys.exit(1)
        events = load_events(run_id, runs_base_opt)
    elif name is None:
        # No run_id, no name → pick latest run (if any).
        state = _latest_run_state(runs_base_opt)
        if state is not None:
            events = load_events(state.run_id, runs_base_opt)

    # Resolve which plan to display.
    if state is not None and state.plan_ref:
        from pathlib import Path as _Path

        plan = read_plan(_Path(state.plan_ref))
    if plan is None and name is not None:
        plan = read_plan(_plan_path(specs_dir, name))
        if plan is None:
            click.echo(f"No plan for {name!r} in {specs_dir}/.", err=True)
            sys.exit(1)
    if plan is None and state is not None:
        click.secho(
            f"  warning: plan_ref {state.plan_ref!r} could not be loaded.",
            fg="yellow",
        )
    if plan is None:
        click.echo(
            "Nothing to show. Run `heap plan generate <name>` then "
            "`heap status <name>` (or pass --run-id).",
            err=True,
        )
        sys.exit(1)

    click.echo(status_summary(plan, state, events[-n_events:] if events else None))


def _latest_run_state(runs_base_opt: str):  # type: ignore[no-untyped-def]
    """Return the most-recently-modified run's state, or None."""
    from pathlib import Path as _Path

    base = _Path(runs_base_opt)
    if not base.exists():
        return None
    candidates = []
    for d in base.iterdir():
        st_path = d / "state.json"
        if d.is_dir() and st_path.exists():
            candidates.append((st_path.stat().st_mtime, d.name))
    if not candidates:
        return None
    candidates.sort(reverse=True)
    _, latest_id = candidates[0]
    return load_state(latest_id, runs_base_opt)


def _print_run_summary(state) -> None:  # type: ignore[no-untyped-def]
    click.echo(
        f"\nrun_id:        {state.run_id}\n"
        f"plan_id:       {state.plan_id}\n"
        f"status:        {state.run_status}"
        + (
            f"  (awaiting gate: {state.awaiting_gate})"
            if state.run_status == "awaiting_gate"
            else ""
        )
        + f"\nsprint:        {state.sprint_idx}  ({state.sprint_status})\n"
        f"phase:         {state.phase_idx}  ({state.phase_status})\n"
        f"completed:     sprints={state.completed_sprints}  "
        f"phases={len(state.completed_phases)}\n"
        f"cost:          ${state.cost_usd_total:.4f}\n"
        f"tokens:        in={state.tokens_in_total}  out={state.tokens_out_total}"
    )


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


def _build_gateway() -> Gateway:
    """Construct the v0.1 default Gateway. Honors HEAP_*_MODEL env overrides."""
    return Gateway(
        planner=os.getenv("HEAP_PLANNER_MODEL", _DEFAULT_PLANNER),
        worker=os.getenv("HEAP_WORKER_MODEL", _DEFAULT_WORKER),
        fast=os.getenv("HEAP_FAST_MODEL", _DEFAULT_FAST),
        budget_usd=(
            float(os.environ["HEAP_BUDGET_USD"]) if os.environ.get("HEAP_BUDGET_USD") else None
        ),
    )


if __name__ == "__main__":
    main()
