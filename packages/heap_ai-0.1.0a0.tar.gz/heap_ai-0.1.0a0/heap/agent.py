"""Layer 4 — Agent Runtime.

Implements the PEV (Plan-Execute-Verify) loop per SPEC §5.2:

  PLAN     ─►  planner model (Opus tier) drafts a plan from task + contract
  EXECUTE  ─►  worker model (Sonnet tier) carries out the plan
  VERIFY   ─►  planner model checks output against the contract
                 ↳ fail  →  replan (up to ``max_replans`` times)
                 ↳ pass  →  return AgentResult

The contract is free-form natural language; the agent injects it into the
planner's system prompt to define what "done" means. Verify must respond
in JSON ``{"passed": bool, "reason": str, "evidence": list[str]}`` — a
permissive parser tolerates surrounding markdown.

Hook firing points are wired here; action semantics (Block/Retry/...) land
in S2.P2 — at that point the agent learns to act on hook return values.

Public API per SPEC §5.2:

    agent = Agent(
        name="bug-fixer",
        model="anthropic/claude-sonnet-4-6",
        planner_model="anthropic/claude-opus-4-7",
        contract="...",
    )
    result = agent.run("Fix bug #1247: ...")
"""

from __future__ import annotations

import json
import logging
import re
from collections.abc import Callable
from pathlib import Path
from typing import Any

from pydantic import BaseModel, Field

from heap.gateway import Gateway, GatewayResponse
from heap.hooks import (
    HookAction,  # noqa: F401  — re-exported for hook authors
    HookBlocked,
    InterpretedHooks,
    interpret,
)
from heap.tool import ToolMeta

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Result types
# ---------------------------------------------------------------------------


class VerifyOutcome(BaseModel):
    """Structured verifier verdict against the contract."""

    passed: bool
    reason: str
    evidence: list[str] = Field(default_factory=list)


class PhaseLogEntry(BaseModel):
    """One entry per PEV phase invocation, useful for debugging and §11.3 traces."""

    phase: str  # "plan" | "execute" | "verify"
    iteration: int  # 0 for initial pass, 1+ for replans
    model_used: str
    tokens_in: int
    tokens_out: int
    cost_usd: float
    latency_ms: float


class AgentResult(BaseModel):
    """Final outcome of ``Agent.run()``."""

    content: str | None
    plan: str
    verify_outcome: VerifyOutcome
    replan_count: int
    phase_log: list[PhaseLogEntry] = Field(default_factory=list)
    total_cost_usd: float
    total_tokens_in: int
    total_tokens_out: int
    escalated: bool = False
    escalation_reason: str | None = None
    hook_blocked: bool = False
    warnings: list[str] = Field(default_factory=list)
    tool_calls_made: list[dict[str, Any]] = Field(default_factory=list)


# ---------------------------------------------------------------------------
# Agent
# ---------------------------------------------------------------------------


HookFn = Callable[..., Any]


class Agent:
    """A spec-driven agent with a PEV loop, contract, and hook surface.

    The agent owns (or accepts) a ``Gateway`` and drives a Plan-Execute-Verify
    cycle until the verifier accepts the work or the replan budget is
    exhausted (then escalates).

    Args:
        name: Human-readable agent name; used in system prompts and logs.
        model: Worker model id (Sonnet tier per SPEC §3).
        planner_model: Planner/verifier model id (Opus tier).
        contract: Natural-language definition of "done". Injected into
            the planner system prompt and the verifier prompt.
        tools: Reserved for S2.P3 — the @tool surface. Accepted as a
            list now so the API does not break later; agent does not yet
            invoke tools in S2.P1.
        skills: Names of skill files under ``skills/<name>.md``. Their
            content is prepended to system prompts at session start.
        fallback: Fallback model chain; passed through to Gateway.
        budget_usd: USD cap; raised as ``BudgetExceeded`` when reached.
        max_replans: How many times to retry PLAN→EXECUTE→VERIFY before
            escalating. Default 3 per SPEC §5.2.
        gateway: Optional pre-built Gateway. If omitted, the agent
            constructs its own from the model arguments.
        skills_dir: Directory to search for skill files. Defaults to
            ``./skills`` relative to the current working directory.
    """

    def __init__(
        self,
        name: str,
        model: str,
        planner_model: str,
        contract: str,
        tools: list[Any] | None = None,
        skills: list[str] | None = None,
        fallback: list[str] | None = None,
        budget_usd: float | None = None,
        max_replans: int = 3,
        max_tool_calls: int = 10,
        gateway: Gateway | None = None,
        skills_dir: str | Path = "skills",
    ) -> None:
        self.name = name
        self.contract = contract.strip()
        self.tools = list(tools or [])
        self.skill_names = list(skills or [])
        self.max_replans = int(max_replans)
        self.max_tool_calls = int(max_tool_calls)
        self.skills_dir = Path(skills_dir)

        # Validate every tool is @tool-decorated and build a name → meta map.
        self._tool_metas: dict[str, ToolMeta] = {}
        for fn in self.tools:
            meta = getattr(fn, "__tool_meta__", None)
            if not isinstance(meta, ToolMeta):
                raise TypeError(
                    f"Agent {name!r}: tool {fn!r} is not @tool-decorated. "
                    "Wrap it with @tool first (see heap.tool)."
                )
            if meta.name in self._tool_metas:
                raise ValueError(f"Agent {name!r}: duplicate tool name {meta.name!r}")
            self._tool_metas[meta.name] = meta

        if gateway is not None:
            self._gw = gateway
        else:
            # The fast role is unused in v0.1's PEV but Gateway requires it.
            self._gw = Gateway(
                planner=planner_model,
                worker=model,
                fast=model,
                fallback=fallback,
                budget_usd=budget_usd,
            )

        self.model = model
        self.planner_model = planner_model

        self._skills_text = self._load_skills(self.skill_names)
        self._hooks: dict[str, list[HookFn]] = {}
        self._collected_warnings: list[str] = []

    # ------------------------------------------------------------------
    # Hook surface (registration only — full action handling in S2.P2)
    # ------------------------------------------------------------------

    def hook(self, name: str) -> Callable[[HookFn], HookFn]:
        """Register a hook function for the given firing point.

        Recognised names (per SPEC §5.2):
            pre_tool_call, post_tool_call,
            pre_phase, post_phase,
            pre_response, post_response.

        v0.1 (S2.P1): hooks are recorded and called at the right boundaries,
        but their return values are not yet acted upon. S2.P2 wires
        Block/Warn/Retry/Continue semantics.
        """

        def decorator(fn: HookFn) -> HookFn:
            self._hooks.setdefault(name, []).append(fn)
            return fn

        return decorator

    def _fire_hook(self, name: str, **ctx: Any) -> InterpretedHooks:
        """Fire all hooks at ``name``; return the dominant action(s).

        Hook exceptions are logged and treated as a no-op so a buggy
        user hook can't crash the run. Intentional stops use Block.
        """
        results: list[HookAction | None] = []
        for fn in self._hooks.get(name, []):
            try:
                results.append(fn(SimpleContext(**ctx)))
            except Exception as e:
                logger.warning("hook %r raised: %s", name, e)
        return interpret(results)

    def _absorb_warnings(self, hooks: InterpretedHooks) -> None:
        for w in hooks.warnings:
            self._collected_warnings.append(w.message)
            logger.warning("hook Warn: %s", w.message)

    # ------------------------------------------------------------------
    # Public — drive the PEV loop
    # ------------------------------------------------------------------

    def run(self, task: str) -> AgentResult:
        """Drive the PEV loop until verify passes or the replan budget exhausts."""
        phase_log: list[PhaseLogEntry] = []
        tool_calls_made: list[dict[str, Any]] = []
        replan_count = 0
        last_verify: VerifyOutcome | None = None
        plan_text: str = ""
        execute_content: str = ""
        self._collected_warnings = []

        def _block_finalize(reason: str, outcome: VerifyOutcome) -> AgentResult:
            return self._finalize(
                content=execute_content,
                plan_text=plan_text,
                outcome=outcome,
                phase_log=phase_log,
                replan_count=replan_count,
                escalated=True,
                escalation_reason=reason,
                hook_blocked=True,
                tool_calls_made=tool_calls_made,
            )

        not_run = VerifyOutcome(passed=False, reason="not run")

        while True:
            # ---- PLAN -------------------------------------------------
            h = self._fire_hook("pre_phase", phase="plan", iteration=replan_count)
            self._absorb_warnings(h)
            if h.block:
                return _block_finalize(
                    f"hook Block at pre_phase(plan): {h.block.reason}",
                    last_verify or not_run,
                )

            plan_resp = self._call_plan(task, last_verify=last_verify)
            plan_text = plan_resp.content or ""
            phase_log.append(self._log_entry("plan", replan_count, plan_resp))

            h = self._fire_hook(
                "post_phase", phase="plan", iteration=replan_count, response=plan_resp
            )
            self._absorb_warnings(h)
            if h.block:
                return _block_finalize(
                    f"hook Block at post_phase(plan): {h.block.reason}",
                    last_verify or not_run,
                )

            # ---- EXECUTE ----------------------------------------------
            h = self._fire_hook("pre_phase", phase="execute", iteration=replan_count)
            self._absorb_warnings(h)
            if h.block:
                return _block_finalize(
                    f"hook Block at pre_phase(execute): {h.block.reason}",
                    last_verify or not_run,
                )

            try:
                exec_resp, new_tool_calls = self._call_execute(task, plan_text)
            except HookBlocked as e:
                return _block_finalize(str(e), last_verify or not_run)
            tool_calls_made.extend(new_tool_calls)
            execute_content = exec_resp.content or ""
            phase_log.append(self._log_entry("execute", replan_count, exec_resp))

            h = self._fire_hook(
                "post_phase", phase="execute", iteration=replan_count, response=exec_resp
            )
            self._absorb_warnings(h)
            if h.block:
                return _block_finalize(
                    f"hook Block at post_phase(execute): {h.block.reason}",
                    last_verify or not_run,
                )

            # ---- VERIFY -----------------------------------------------
            h = self._fire_hook("pre_phase", phase="verify", iteration=replan_count)
            self._absorb_warnings(h)
            if h.block:
                return _block_finalize(
                    f"hook Block at pre_phase(verify): {h.block.reason}",
                    last_verify or not_run,
                )

            verify_resp = self._call_verify(task, plan_text, execute_content)
            phase_log.append(self._log_entry("verify", replan_count, verify_resp))
            outcome = self._parse_verify(verify_resp.content)

            h = self._fire_hook(
                "post_phase",
                phase="verify",
                iteration=replan_count,
                response=verify_resp,
                outcome=outcome,
            )
            self._absorb_warnings(h)
            if h.block:
                return _block_finalize(
                    f"hook Block at post_phase(verify): {h.block.reason}",
                    outcome,
                )
            # Retry from a verify hook overrides the verifier's verdict:
            # treat as a fail with the hint forwarded into the next plan.
            if h.retry is not None:
                outcome = VerifyOutcome(
                    passed=False,
                    reason=f"hook Retry: {h.retry.hint}",
                    evidence=outcome.evidence,
                )

            last_verify = outcome
            if outcome.passed:
                return self._finalize(
                    content=execute_content,
                    plan_text=plan_text,
                    outcome=outcome,
                    phase_log=phase_log,
                    replan_count=replan_count,
                    escalated=False,
                    escalation_reason=None,
                    tool_calls_made=tool_calls_made,
                )

            replan_count += 1
            if replan_count > self.max_replans:
                return self._finalize(
                    content=execute_content,
                    plan_text=plan_text,
                    outcome=outcome,
                    phase_log=phase_log,
                    replan_count=self.max_replans,
                    escalated=True,
                    escalation_reason=(
                        f"VERIFY failed after {self.max_replans} replans: {outcome.reason}"
                    ),
                    tool_calls_made=tool_calls_made,
                )
            logger.info(
                "agent %r: verify failed (%s) — replanning (%d/%d)",
                self.name,
                outcome.reason,
                replan_count,
                self.max_replans,
            )

    # ------------------------------------------------------------------
    # Internal — phase calls
    # ------------------------------------------------------------------

    def _call_plan(self, task: str, last_verify: VerifyOutcome | None) -> GatewayResponse:
        sys_prompt = (
            f"You are an agent named {self.name!r}.\n"
            f"Your job is to draft a plan that satisfies the contract below.\n\n"
            f"CONTRACT (definition of done):\n{self.contract}\n"
        )
        if self._skills_text:
            sys_prompt += f"\nSKILLS:\n{self._skills_text}\n"
        sys_prompt += (
            "\nOutput a concise plan as a numbered list of steps. "
            "Each step should be specific and actionable. "
            "Do not execute the plan; only produce it."
        )

        user_parts = [f"TASK:\n{task}"]
        if last_verify is not None:
            user_parts.append(
                "\nThe previous attempt failed verification.\n"
                f"Reason: {last_verify.reason}\n"
                + (
                    "Evidence:\n- " + "\n- ".join(last_verify.evidence)
                    if last_verify.evidence
                    else ""
                )
                + "\nRefine the plan to address this."
            )
        user_prompt = "\n\n".join(user_parts)

        return self._call_role(
            "planner",
            sys_prompt=sys_prompt,
            user_prompt=user_prompt,
            max_tokens=2000,
        )

    def _call_execute(
        self, task: str, plan_text: str
    ) -> tuple[GatewayResponse, list[dict[str, Any]]]:
        """Run the EXECUTE phase, dispatching tool calls in a loop.

        Returns:
            (final_response, tool_calls_record) — the final tool-free
            model response, plus a record of every tool dispatched.

        Raises:
            HookBlocked: if a pre/post_tool_call hook returned Block.
        """
        sys_prompt = (
            f"You are an agent named {self.name!r}. "
            "Execute the plan below to accomplish the task. Be concise and direct.\n\n"
            f"CONTRACT (definition of done):\n{self.contract}\n\n"
            f"PLAN:\n{plan_text}\n"
        )
        if self._skills_text:
            sys_prompt += f"\nSKILLS:\n{self._skills_text}\n"

        user_prompt = f"TASK:\n{task}\n\nExecute the plan now and report the result."
        messages: list[dict[str, Any]] = [
            {"role": "system", "content": sys_prompt},
            {"role": "user", "content": user_prompt},
        ]

        tool_schemas = (
            [m.to_openai_tool() for m in self._tool_metas.values()] if self._tool_metas else None
        )

        resp = self._gw_call_role("worker", messages=messages, tools=tool_schemas, max_tokens=2000)

        tool_calls_record: list[dict[str, Any]] = []
        iterations = 0

        while resp.tool_calls and iterations < self.max_tool_calls:
            # Append the assistant's tool-calling turn.
            messages.append(
                {
                    "role": "assistant",
                    "content": resp.content or "",
                    "tool_calls": resp.tool_calls,
                }
            )

            for tc in resp.tool_calls:
                tool_name = (tc.get("function") or {}).get("name", "?")
                raw_args = (tc.get("function") or {}).get("arguments", "{}")
                try:
                    args = json.loads(raw_args) if isinstance(raw_args, str) else dict(raw_args)
                except json.JSONDecodeError:
                    args = {}

                # ---- pre_tool_call hook ----
                h = self._fire_hook("pre_tool_call", tool=tool_name, args=args)
                self._absorb_warnings(h)
                if h.block:
                    raise HookBlocked(f"hook Block at pre_tool_call({tool_name}): {h.block.reason}")

                meta = self._tool_metas.get(tool_name)
                if meta is None:
                    tool_result: Any = f"Error: unknown tool {tool_name!r}"
                else:
                    try:
                        tool_result = meta.call(**args)
                    except Exception as e:  # noqa: BLE001
                        tool_result = f"Error: {type(e).__name__}: {e}"

                # ---- post_tool_call hook ----
                h2 = self._fire_hook(
                    "post_tool_call",
                    tool=tool_name,
                    args=args,
                    result=tool_result,
                )
                self._absorb_warnings(h2)
                if h2.block:
                    raise HookBlocked(
                        f"hook Block at post_tool_call({tool_name}): {h2.block.reason}"
                    )

                tool_calls_record.append(
                    {
                        "tool": tool_name,
                        "args": args,
                        "result": str(tool_result),
                    }
                )
                messages.append(
                    {
                        "role": "tool",
                        "tool_call_id": tc.get("id", ""),
                        "content": str(tool_result),
                    }
                )

            iterations += 1
            resp = self._gw_call_role(
                "worker", messages=messages, tools=tool_schemas, max_tokens=2000
            )

        return resp, tool_calls_record

    def _gw_call_role(self, role: str, **kwargs: Any) -> GatewayResponse:
        """Thin wrapper around Gateway.call() that asserts non-streaming response."""
        resp = self._gw.call(role=role, **kwargs)
        if not isinstance(resp, GatewayResponse):
            raise RuntimeError(f"Gateway returned non-response object: {type(resp)!r}")
        return resp

    def _call_verify(self, task: str, plan_text: str, execute_content: str) -> GatewayResponse:
        sys_prompt = (
            "You are a strict verifier. Check whether the agent's output "
            "satisfies the contract for the given task.\n\n"
            f"CONTRACT:\n{self.contract}\n\n"
            "Output JSON ONLY in this exact shape (no prose, no markdown fences):\n"
            '{"passed": true|false, "reason": "<one short sentence>", '
            '"evidence": ["<bullet 1>", "<bullet 2>"]}'
        )
        user_prompt = (
            f"TASK:\n{task}\n\n"
            f"PLAN:\n{plan_text}\n\n"
            f"AGENT OUTPUT:\n{execute_content}\n\n"
            "Verify and return JSON."
        )
        return self._call_role(
            "planner",
            sys_prompt=sys_prompt,
            user_prompt=user_prompt,
            max_tokens=400,
        )

    def _call_role(
        self, role: str, sys_prompt: str, user_prompt: str, **kwargs: Any
    ) -> GatewayResponse:
        messages = [
            {"role": "system", "content": sys_prompt},
            {"role": "user", "content": user_prompt},
        ]
        resp = self._gw.call(role=role, messages=messages, **kwargs)
        if not isinstance(resp, GatewayResponse):
            # Should never happen for non-streaming calls; guards future drift.
            raise RuntimeError(f"Gateway returned non-response object: {type(resp)!r}")
        return resp

    # ------------------------------------------------------------------
    # Internal — verify parsing, finalization, helpers
    # ------------------------------------------------------------------

    _JSON_OBJECT_RE = re.compile(r"\{.*\}", re.DOTALL)

    def _parse_verify(self, content: str | None) -> VerifyOutcome:
        if not content:
            return VerifyOutcome(
                passed=False,
                reason="verifier returned empty content",
                evidence=[],
            )
        cleaned = content.strip()
        # Strip ```json ... ``` fences if present.
        if cleaned.startswith("```"):
            cleaned = re.sub(r"^```(?:json)?\s*", "", cleaned)
            cleaned = re.sub(r"\s*```$", "", cleaned)

        # If still not a plain object, scan for one.
        if not cleaned.startswith("{"):
            m = self._JSON_OBJECT_RE.search(cleaned)
            cleaned = m.group(0) if m else cleaned

        try:
            data = json.loads(cleaned)
        except json.JSONDecodeError as e:
            return VerifyOutcome(
                passed=False,
                reason=f"verifier output not parseable as JSON: {e}",
                evidence=[content[:200]],
            )

        try:
            return VerifyOutcome.model_validate(data)
        except Exception as e:  # noqa: BLE001
            return VerifyOutcome(
                passed=False,
                reason=f"verifier JSON did not match expected shape: {e}",
                evidence=[content[:200]],
            )

    def _finalize(
        self,
        content: str | None,
        plan_text: str,
        outcome: VerifyOutcome,
        phase_log: list[PhaseLogEntry],
        replan_count: int,
        escalated: bool,
        escalation_reason: str | None,
        hook_blocked: bool = False,
        tool_calls_made: list[dict[str, Any]] | None = None,
    ) -> AgentResult:
        return AgentResult(
            content=content,
            plan=plan_text,
            verify_outcome=outcome,
            replan_count=replan_count,
            phase_log=phase_log,
            total_cost_usd=sum(p.cost_usd for p in phase_log),
            total_tokens_in=sum(p.tokens_in for p in phase_log),
            total_tokens_out=sum(p.tokens_out for p in phase_log),
            escalated=escalated,
            escalation_reason=escalation_reason,
            hook_blocked=hook_blocked,
            warnings=list(self._collected_warnings),
            tool_calls_made=list(tool_calls_made or []),
        )

    @staticmethod
    def _log_entry(phase: str, iteration: int, resp: GatewayResponse) -> PhaseLogEntry:
        return PhaseLogEntry(
            phase=phase,
            iteration=iteration,
            model_used=resp.model_used,
            tokens_in=resp.tokens_in,
            tokens_out=resp.tokens_out,
            cost_usd=resp.cost_usd,
            latency_ms=resp.latency_ms,
        )

    def _load_skills(self, names: list[str]) -> str:
        if not names:
            return ""
        chunks: list[str] = []
        for n in names:
            path = self.skills_dir / f"{n}.md"
            if not path.exists():
                logger.warning("agent %r: skill %r not found at %s", self.name, n, path)
                continue
            chunks.append(f"--- skill: {n} ---\n{path.read_text(encoding='utf-8')}")
        return "\n\n".join(chunks)


# ---------------------------------------------------------------------------
# Hook context
# ---------------------------------------------------------------------------


class SimpleContext:
    """A bag-of-attributes context object passed to hook functions.

    Hooks receive this and read whatever fields are relevant to their
    firing point. Concrete fields depend on the hook name:

      pre_phase / post_phase: phase, iteration, response (post only),
                              outcome (post-verify only)
      pre_tool_call / post_tool_call: tool, args, result (post only)
                                      [wired in S2.P3]
      pre_response / post_response: messages, response (post only)
                                    [wired as needed in S2.P2]
    """

    def __init__(self, **kwargs: Any) -> None:
        for k, v in kwargs.items():
            setattr(self, k, v)

    def __repr__(self) -> str:  # pragma: no cover — debug aid only
        attrs = ", ".join(f"{k}={v!r}" for k, v in self.__dict__.items())
        return f"SimpleContext({attrs})"


__all__ = [
    "Agent",
    "AgentResult",
    "VerifyOutcome",
    "PhaseLogEntry",
    "SimpleContext",
]
