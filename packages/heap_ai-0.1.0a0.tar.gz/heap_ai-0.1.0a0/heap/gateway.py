"""Layer 1 — Model Gateway.

Wraps LiteLLM to provide:
  - Role-based model routing (planner / worker / fast) per SPEC §3
  - Provider fallback chain on errors
  - Cost tracking (tokens in/out, USD) per call and cumulative
  - Per-Gateway USD budget with hard-fail before each call
  - Streaming pass-through (proper streaming-cost rollup is v0.2)

Public API per SPEC §5.1.
"""

from __future__ import annotations

import logging
import time
from collections.abc import Iterator
from typing import Any, Literal

import litellm
from pydantic import BaseModel, Field

logger = logging.getLogger(__name__)

Role = Literal["planner", "worker", "fast"]
_VALID_ROLES: tuple[Role, ...] = ("planner", "worker", "fast")


class BudgetExceeded(RuntimeError):
    """Raised when a Gateway call would exceed the configured USD budget.

    The exception is raised *before* the call hits the provider, so no
    cost is incurred when this fires.
    """


class GatewayResponse(BaseModel):
    """Normalized response shape returned by Gateway.call().

    Fields kept flat and primitive on purpose — the caller should not have
    to know about LiteLLM's underlying response object.
    """

    content: str | None
    tool_calls: list[dict[str, Any]] = Field(default_factory=list)
    model_used: str
    tokens_in: int
    tokens_out: int
    cost_usd: float
    latency_ms: float
    used_fallback: bool = False
    fallback_chain_index: int | None = None


class Gateway:
    """LiteLLM-based gateway with role routing, fallback, cost, and budget.

    Example:
        gw = Gateway(
            planner="anthropic/claude-opus-4-7",
            worker="anthropic/claude-sonnet-4-6",
            fast="anthropic/claude-haiku-4-5-20251001",
            fallback=["openai/gpt-4.1", "ollama/qwen3:32b"],
            budget_usd=None,
        )
        resp = gw.call(role="planner", messages=[{"role":"user","content":"hi"}])
        print(resp.content, resp.cost_usd)
    """

    def __init__(
        self,
        planner: str,
        worker: str,
        fast: str,
        fallback: list[str] | None = None,
        budget_usd: float | None = None,
    ) -> None:
        self.models: dict[Role, str] = {
            "planner": planner,
            "worker": worker,
            "fast": fast,
        }
        self.fallback: list[str] = list(fallback or [])
        self.budget_usd: float | None = budget_usd

        self.spent_usd: float = 0.0
        self.tokens_in: int = 0
        self.tokens_out: int = 0
        self.calls_made: int = 0

    # ------------------------------------------------------------------
    # Public
    # ------------------------------------------------------------------

    def call(
        self,
        role: Role,
        messages: list[dict[str, Any]],
        tools: list[dict[str, Any]] | None = None,
        stream: bool = False,
        **litellm_kwargs: Any,
    ) -> GatewayResponse | Iterator[Any]:
        """Dispatch a chat completion via the model assigned to ``role``.

        On exception, walks the fallback chain in order. Raises
        ``BudgetExceeded`` *before* the network call if the cumulative
        spend already meets/exceeds ``budget_usd``.

        When ``stream=True``, returns the raw LiteLLM streaming iterator;
        cost and token tallies are NOT updated for streamed calls in v0.1.
        """
        if role not in self.models:
            raise ValueError(f"Unknown role {role!r}; expected one of {_VALID_ROLES}")

        self._enforce_budget()

        candidates = [self.models[role], *self.fallback]
        last_error: Exception | None = None

        for idx, model_id in enumerate(candidates):
            try:
                if stream:
                    return litellm.completion(
                        model=model_id,
                        messages=messages,
                        tools=tools,
                        stream=True,
                        **litellm_kwargs,
                    )

                t0 = time.perf_counter()
                raw = litellm.completion(
                    model=model_id,
                    messages=messages,
                    tools=tools,
                    **litellm_kwargs,
                )
                latency_ms = (time.perf_counter() - t0) * 1000.0

                resp = self._normalize(
                    raw=raw,
                    model_used=model_id,
                    latency_ms=latency_ms,
                    fallback_idx=idx,
                )

                self.spent_usd += resp.cost_usd
                self.tokens_in += resp.tokens_in
                self.tokens_out += resp.tokens_out
                self.calls_made += 1
                return resp

            except BudgetExceeded:
                raise
            except Exception as e:  # noqa: BLE001 — fallback path is the point
                last_error = e
                logger.warning(
                    "gateway: model %r failed (idx=%d): %s — trying next",
                    model_id,
                    idx,
                    e,
                )
                continue

        raise RuntimeError(
            f"All models failed for role={role!r} "
            f"(1 primary + {len(self.fallback)} fallbacks). "
            f"Last error: {last_error}"
        )

    def reset(self) -> None:
        """Zero out cumulative spend and token tallies. Does not change config."""
        self.spent_usd = 0.0
        self.tokens_in = 0
        self.tokens_out = 0
        self.calls_made = 0

    # ------------------------------------------------------------------
    # Internal
    # ------------------------------------------------------------------

    def _enforce_budget(self) -> None:
        if self.budget_usd is None:
            return
        if self.spent_usd >= self.budget_usd:
            raise BudgetExceeded(
                f"Cumulative spend ${self.spent_usd:.4f} >= budget "
                f"${self.budget_usd:.4f}; refusing further calls."
            )

    def _normalize(
        self,
        raw: Any,
        model_used: str,
        latency_ms: float,
        fallback_idx: int,
    ) -> GatewayResponse:
        choice = raw.choices[0].message
        content = getattr(choice, "content", None)

        tool_calls_raw = getattr(choice, "tool_calls", None) or []
        tool_calls: list[dict[str, Any]] = []
        for tc in tool_calls_raw:
            if hasattr(tc, "model_dump"):
                tool_calls.append(tc.model_dump())
            elif isinstance(tc, dict):
                tool_calls.append(tc)
            else:
                tool_calls.append({k: getattr(tc, k, None) for k in ("id", "type", "function")})

        usage = getattr(raw, "usage", None)
        tokens_in = getattr(usage, "prompt_tokens", 0) or 0
        tokens_out = getattr(usage, "completion_tokens", 0) or 0

        try:
            cost = float(litellm.completion_cost(completion_response=raw) or 0.0)
        except Exception as e:  # noqa: BLE001
            logger.debug("gateway: cost lookup failed for %r: %s", model_used, e)
            cost = 0.0

        return GatewayResponse(
            content=content,
            tool_calls=tool_calls,
            model_used=model_used,
            tokens_in=int(tokens_in),
            tokens_out=int(tokens_out),
            cost_usd=cost,
            latency_ms=latency_ms,
            used_fallback=(fallback_idx > 0),
            fallback_chain_index=fallback_idx if fallback_idx > 0 else None,
        )


__all__ = ["Gateway", "GatewayResponse", "BudgetExceeded", "Role"]
