"""Spec structurer — turn an InterrogatorOutcome into 3 on-disk artifacts.

Per SPEC §6.2.3 the structurer writes:

  - <specs_dir>/<name>.spec.yaml         canonical (latest) machine-readable
  - <specs_dir>/<name>.spec.v<N>.yaml    versioned history (1, 2, ...)
  - <specs_dir>/<name>.spec.md           human-readable summary (latest)
  - <specs_dir>/<name>.acceptance.json   flat acceptance list (latest)

Versioning bumps automatically: first write → v1, subsequent writes
with the same name → v2, v3 ... Each historical version is preserved
as its own ``.v<N>.yaml`` file; the canonical ``.spec.yaml`` mirrors
the most recent.

Acceptance criteria are mode-aware:
  - feature   → read facts.acceptance / success / acceptance_criteria
  - bug       → derive from facts.expected / facts.symptom
  - greenfield → read facts.first_iteration / mvp / minimum_viable
"""

from __future__ import annotations

import json
import re
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

import yaml
from pydantic import BaseModel, Field

from heap.spec.interrogator import InterrogatorOutcome

# ---------------------------------------------------------------------------
# Models
# ---------------------------------------------------------------------------


class StructuredSpec(BaseModel):
    """The on-disk shape of a versioned spec."""

    name: str
    version: int
    mode: str
    audience: str
    facts: dict[str, Any] = Field(default_factory=dict)
    evidence: list[dict[str, Any]] = Field(default_factory=list)
    acceptance: list[str] = Field(default_factory=list)
    transcript_summary: str = ""
    created_at: str  # ISO 8601


# ---------------------------------------------------------------------------
# Acceptance extraction (mode-aware)
# ---------------------------------------------------------------------------


def _as_str_list(value: Any) -> list[str]:
    """Best-effort coerce facts['key'] to a list[str]."""
    if value is None:
        return []
    if isinstance(value, list):
        return [str(v).strip() for v in value if str(v).strip()]
    if isinstance(value, str):
        s = value.strip()
        return [s] if s else []
    return [str(value)]


def _extract_acceptance(facts: dict[str, Any], mode: str) -> list[str]:
    if mode == "feature":
        for key in ("acceptance", "acceptance_criteria", "success", "success_criteria"):
            crits = _as_str_list(facts.get(key))
            if crits:
                return crits
        return []
    if mode == "bug":
        crits: list[str] = []
        if facts.get("expected"):
            crits.append(f"After fix: {facts['expected']}")
        if facts.get("symptom"):
            crits.append(f"After fix: '{facts['symptom']}' no longer occurs")
        # Allow explicit override if the model populated 'acceptance' anyway.
        explicit = _as_str_list(facts.get("acceptance"))
        return explicit or crits
    if mode == "greenfield":
        for key in ("first_iteration", "mvp", "minimum_viable", "minimum_viable_scope"):
            crits = _as_str_list(facts.get(key))
            if crits:
                return crits
        return _as_str_list(facts.get("acceptance"))
    return _as_str_list(facts.get("acceptance"))


# ---------------------------------------------------------------------------
# Markdown rendering
# ---------------------------------------------------------------------------


def _render_markdown(spec: StructuredSpec) -> str:
    lines: list[str] = [
        f"# {spec.name}",
        "",
        f"- **Mode:** `{spec.mode}`",
        f"- **Audience:** `{spec.audience}`",
        f"- **Version:** v{spec.version}",
        f"- **Finalized:** {spec.created_at}",
        "",
    ]

    if spec.facts:
        lines.append("## Facts")
        lines.append("")
        for key, value in spec.facts.items():
            lines.append(f"- **{key}:** {_render_value(value)}")
        lines.append("")

    if spec.acceptance:
        lines.append("## Acceptance criteria")
        lines.append("")
        for crit in spec.acceptance:
            lines.append(f"- [ ] {crit}")
        lines.append("")

    if spec.evidence:
        lines.append("## Evidence")
        lines.append("")
        for ev in spec.evidence:
            lines.append(f"- {_render_value(ev)}")
        lines.append("")

    if spec.transcript_summary:
        lines.append("## Transcript summary")
        lines.append("")
        lines.append(spec.transcript_summary)
        lines.append("")

    return "\n".join(lines).rstrip() + "\n"


def _render_value(value: Any) -> str:
    if isinstance(value, str):
        return value
    if isinstance(value, list):
        return ", ".join(_render_value(v) for v in value)
    if isinstance(value, dict):
        return ", ".join(f"{k}: {_render_value(v)}" for k, v in value.items())
    return str(value)


# ---------------------------------------------------------------------------
# Transcript summary (cheap, no LLM)
# ---------------------------------------------------------------------------


def _summarize_transcript(transcript: list) -> str:
    """Compact representation: count of Q/A pairs + first 2 questions.

    A richer summary could be a planner-pass, but for v0.1 we keep it
    deterministic and cheap.
    """
    if not transcript:
        return ""
    qs = [e for e in transcript if getattr(e, "role", None) == "interrogator"]
    n_qa = sum(1 for e in transcript if getattr(e, "role", None) == "user")
    parts = [f"{n_qa} answers gathered across {len(qs)} prompts."]
    for q in qs[:3]:
        parts.append(f"  - “{getattr(q, 'content', '')[:80]}”")
    if len(qs) > 3:
        parts.append(f"  ... and {len(qs) - 3} more.")
    return "\n".join(parts)


# ---------------------------------------------------------------------------
# Structurer
# ---------------------------------------------------------------------------


_VERSION_RE = re.compile(r"^(?P<name>.+)\.spec\.v(?P<v>\d+)\.yaml$")


class Structurer:
    """Persist InterrogatorOutcome → on-disk spec artifacts."""

    def __init__(self, specs_dir: str | Path = "specs") -> None:
        self.specs_dir = Path(specs_dir)

    # --- public ------------------------------------------------------------

    def write(
        self,
        outcome: InterrogatorOutcome,
        name: str,
        evidence: list[BaseModel] | None = None,
    ) -> StructuredSpec:
        """Write all 4 artifacts for ``name``; return the StructuredSpec."""
        if not name or not re.match(r"^[a-zA-Z0-9_-]+$", name):
            raise ValueError(
                f"spec name {name!r} is invalid; use letters, digits, hyphen, or underscore only"
            )

        self.specs_dir.mkdir(parents=True, exist_ok=True)
        next_version = self._next_version(name)

        ev_dicts: list[dict[str, Any]] = []
        for e in evidence or []:
            if isinstance(e, BaseModel):
                ev_dicts.append(e.model_dump())
            elif isinstance(e, dict):
                ev_dicts.append(e)
            else:
                ev_dicts.append({"raw": str(e)})

        spec = StructuredSpec(
            name=name,
            version=next_version,
            mode=outcome.mode,
            audience=outcome.audience,
            facts=dict(outcome.facts),
            evidence=ev_dicts,
            acceptance=_extract_acceptance(outcome.facts, outcome.mode),
            transcript_summary=_summarize_transcript(outcome.transcript),
            created_at=outcome.finalized_at,
        )

        canonical_yaml = self.specs_dir / f"{name}.spec.yaml"
        versioned_yaml = self.specs_dir / f"{name}.spec.v{next_version}.yaml"
        md_path = self.specs_dir / f"{name}.spec.md"
        accept_path = self.specs_dir / f"{name}.acceptance.json"

        yaml_text = yaml.safe_dump(spec.model_dump(), sort_keys=False, allow_unicode=True)
        canonical_yaml.write_text(yaml_text, encoding="utf-8")
        versioned_yaml.write_text(yaml_text, encoding="utf-8")
        md_path.write_text(_render_markdown(spec), encoding="utf-8")
        accept_path.write_text(
            json.dumps(spec.acceptance, indent=2, ensure_ascii=False), encoding="utf-8"
        )

        return spec

    def read(self, name: str, version: int | None = None) -> StructuredSpec | None:
        """Read a spec from disk. ``version=None`` returns the canonical (latest)."""
        if version is None:
            path = self.specs_dir / f"{name}.spec.yaml"
        else:
            path = self.specs_dir / f"{name}.spec.v{version}.yaml"
        if not path.exists():
            return None
        data = yaml.safe_load(path.read_text(encoding="utf-8"))
        if not isinstance(data, dict):
            return None
        return StructuredSpec.model_validate(data)

    def list(self) -> list[str]:
        """List all spec names that have a canonical ``.spec.yaml`` file."""
        if not self.specs_dir.exists():
            return []
        names: set[str] = set()
        for p in self.specs_dir.iterdir():
            if p.is_file() and p.name.endswith(".spec.yaml"):
                names.add(p.name[: -len(".spec.yaml")])
        return sorted(names)

    def list_versions(self, name: str) -> list[int]:
        """Return existing version numbers for ``name``, ascending."""
        return sorted(self._existing_versions(name))

    def append_acceptance(self, name: str, criterion: str) -> StructuredSpec:
        """Append a new acceptance criterion to ``name`` and bump its version.

        Implements the bidirectional spec-amendment path of SPEC §7.6: when
        a user adds a new scenario during ``heap scenarios review``, that
        scenario's acceptance criterion can be promoted into the spec, which
        bumps the spec version. The new criterion is added via the explicit
        ``facts['acceptance']`` override list so the bug-mode extractor (which
        normally derives criteria from ``expected``/``symptom``) honours it.

        Returns the newly written StructuredSpec.
        """
        criterion = (criterion or "").strip()
        if not criterion:
            raise ValueError("criterion must be a non-empty string")

        existing = self.read(name)
        if existing is None:
            raise ValueError(f"spec {name!r} not found in {self.specs_dir}/")

        new_facts = dict(existing.facts)
        current_list = list(existing.acceptance)
        if criterion in current_list:
            raise ValueError(f"criterion already present in spec {name!r}; refusing duplicate")
        new_list = [*current_list, criterion]
        new_facts["acceptance"] = new_list  # explicit override across all modes

        next_version = self._next_version(name)
        new_spec = StructuredSpec(
            name=existing.name,
            version=next_version,
            mode=existing.mode,
            audience=existing.audience,
            facts=new_facts,
            evidence=list(existing.evidence),
            acceptance=new_list,
            transcript_summary=existing.transcript_summary,
            created_at=datetime.now(UTC).strftime("%Y-%m-%dT%H:%M:%SZ"),
        )

        canonical_yaml = self.specs_dir / f"{name}.spec.yaml"
        versioned_yaml = self.specs_dir / f"{name}.spec.v{next_version}.yaml"
        md_path = self.specs_dir / f"{name}.spec.md"
        accept_path = self.specs_dir / f"{name}.acceptance.json"

        yaml_text = yaml.safe_dump(new_spec.model_dump(), sort_keys=False, allow_unicode=True)
        canonical_yaml.write_text(yaml_text, encoding="utf-8")
        versioned_yaml.write_text(yaml_text, encoding="utf-8")
        md_path.write_text(_render_markdown(new_spec), encoding="utf-8")
        accept_path.write_text(
            json.dumps(new_spec.acceptance, indent=2, ensure_ascii=False), encoding="utf-8"
        )
        return new_spec

    # --- internal ----------------------------------------------------------

    def _next_version(self, name: str) -> int:
        existing = self._existing_versions(name)
        return (max(existing) if existing else 0) + 1

    def _existing_versions(self, name: str) -> list[int]:
        if not self.specs_dir.exists():
            return []
        versions: list[int] = []
        for p in self.specs_dir.iterdir():
            if not p.is_file():
                continue
            m = _VERSION_RE.match(p.name)
            if m and m.group("name") == name:
                versions.append(int(m.group("v")))
        return versions


__all__ = [
    "Structurer",
    "StructuredSpec",
]
