"""Evidence collectors for spec interrogation.

Per SPEC §6.2.2, bug mode and feature mode benefit from evidence. v0.1
ships four collectors:

  - parse_log_text     — pull errors/warnings from log dumps
  - parse_stacktrace   — locate files + line numbers from a traceback
  - inspect_file       — mime detect + hex-dump first 16 bytes
                         (catches BOMs, magic numbers, binary mistakes)
  - parse_repro_steps  — extract numbered "Steps to reproduce" lists

Deferred to v0.2 (per SPEC §6.2.2):
  - screenshot (multimodal)
  - har_file   (network traces)

All collectors are pure functions returning Pydantic models. They're
input-shape agnostic — designed to be called either by the
interrogator (with text the user pasted) or directly by an agent that
already has a file path or log buffer.
"""

from __future__ import annotations

import mimetypes
import re
from pathlib import Path

from pydantic import BaseModel, Field

# ---------------------------------------------------------------------------
# Log text
# ---------------------------------------------------------------------------


class LogEntry(BaseModel):
    """One parsed log line."""

    line_number: int  # 1-indexed in the source text
    level: str  # "ERROR" / "WARN" / "INFO" / "DEBUG" / "OTHER"
    timestamp: str | None = None
    message: str
    raw: str


class LogEvidence(BaseModel):
    """Aggregate of parsed log entries with summary counts."""

    entries: list[LogEntry] = Field(default_factory=list)
    error_count: int = 0
    warning_count: int = 0
    info_count: int = 0
    other_count: int = 0
    summary: str = ""

    @property
    def errors(self) -> list[LogEntry]:
        return [e for e in self.entries if e.level == "ERROR"]

    @property
    def warnings(self) -> list[LogEntry]:
        return [e for e in self.entries if e.level == "WARN"]


# Common log line shapes:
#   2026-04-26T18:03:11Z ERROR foo: ...
#   2026-04-26 18:03:11 [ERROR] foo: ...
#   ERROR: foo
#   [ERROR] foo
#   2026-04-26 INFO ...
_TS_PAT = r"(?P<ts>\d{4}-\d{2}-\d{2}[T ]\d{2}:\d{2}:\d{2}(?:[.,]\d+)?Z?)"
_LVL_PAT = r"(?P<lvl>ERROR|ERR|WARN(?:ING)?|INFO|DEBUG|TRACE|FATAL|CRITICAL)"
_LOG_LINE_RE = re.compile(
    rf"^\s*(?:{_TS_PAT}\s+)?\[?{_LVL_PAT}\]?[\s:]+(?P<msg>.*)$",
    re.IGNORECASE,
)

_LEVEL_NORMALIZE = {
    "ERROR": "ERROR",
    "ERR": "ERROR",
    "FATAL": "ERROR",
    "CRITICAL": "ERROR",
    "WARN": "WARN",
    "WARNING": "WARN",
    "INFO": "INFO",
    "DEBUG": "DEBUG",
    "TRACE": "DEBUG",
}


def parse_log_text(text: str) -> LogEvidence:
    """Parse free-form log text into structured LogEvidence.

    Tolerant: lines that don't match a known shape are recorded with
    ``level="OTHER"`` so nothing is silently dropped.
    """
    entries: list[LogEntry] = []
    for idx, raw_line in enumerate(text.splitlines(), start=1):
        line = raw_line.rstrip()
        if not line.strip():
            continue
        m = _LOG_LINE_RE.match(line)
        if m:
            level_raw = (m.group("lvl") or "").upper()
            level = _LEVEL_NORMALIZE.get(level_raw, "OTHER")
            entries.append(
                LogEntry(
                    line_number=idx,
                    level=level,
                    timestamp=m.group("ts"),
                    message=(m.group("msg") or "").strip(),
                    raw=line,
                )
            )
        else:
            entries.append(
                LogEntry(
                    line_number=idx,
                    level="OTHER",
                    timestamp=None,
                    message=line.strip(),
                    raw=line,
                )
            )

    error_count = sum(1 for e in entries if e.level == "ERROR")
    warning_count = sum(1 for e in entries if e.level == "WARN")
    info_count = sum(1 for e in entries if e.level == "INFO")
    other_count = sum(1 for e in entries if e.level not in ("ERROR", "WARN", "INFO"))
    summary = (
        f"{error_count} errors, {warning_count} warnings, "
        f"{info_count} info, {other_count} other; total {len(entries)} entries"
    )
    return LogEvidence(
        entries=entries,
        error_count=error_count,
        warning_count=warning_count,
        info_count=info_count,
        other_count=other_count,
        summary=summary,
    )


# ---------------------------------------------------------------------------
# Stack traces
# ---------------------------------------------------------------------------


class StackFrame(BaseModel):
    """One frame of a parsed stack trace."""

    file: str
    line: int | None = None
    function: str | None = None
    code: str | None = None  # the literal code line, when present


class StackTraceEvidence(BaseModel):
    """A parsed exception traceback."""

    error_type: str | None = None
    error_message: str | None = None
    frames: list[StackFrame] = Field(default_factory=list)
    raw: str = ""


# Python traceback frame:
#   File "/path/to/foo.py", line 123, in some_func
_PY_FRAME_RE = re.compile(
    r'\s*File\s+"(?P<file>[^"]+)",\s+line\s+(?P<line>\d+)(?:,\s+in\s+(?P<func>\S+))?',
)
# Last line: "TypeError: thing went wrong"
_PY_ERROR_RE = re.compile(r"^\s*(?P<type>[A-Z]\w*(?:Error|Exception|Warning))\s*:\s*(?P<msg>.*)$")


def parse_stacktrace(text: str) -> StackTraceEvidence:
    """Parse a Python-style traceback. Tolerant of partial input."""
    frames: list[StackFrame] = []
    error_type: str | None = None
    error_message: str | None = None

    lines = text.splitlines()
    i = 0
    while i < len(lines):
        line = lines[i]
        m = _PY_FRAME_RE.match(line)
        if m:
            code: str | None = None
            # The next non-empty line may be the source-code line.
            if i + 1 < len(lines):
                next_line = lines[i + 1]
                # If it doesn't look like another frame or error, treat as code.
                if (
                    next_line.strip()
                    and not _PY_FRAME_RE.match(next_line)
                    and not _PY_ERROR_RE.match(next_line)
                ):
                    code = next_line.strip()
                    i += 1
            frames.append(
                StackFrame(
                    file=m.group("file"),
                    line=int(m.group("line")),
                    function=m.group("func"),
                    code=code,
                )
            )
        else:
            err = _PY_ERROR_RE.match(line)
            if err:
                error_type = err.group("type")
                error_message = (err.group("msg") or "").strip()
        i += 1

    return StackTraceEvidence(
        error_type=error_type,
        error_message=error_message,
        frames=frames,
        raw=text,
    )


# ---------------------------------------------------------------------------
# File attachment
# ---------------------------------------------------------------------------


class FileAttachmentEvidence(BaseModel):
    """Mime + hex dump (first 16 bytes) for a file the user attached."""

    path: str
    size_bytes: int
    mime_type: str | None = None
    hex_dump: str  # e.g. "ef bb bf 6e 61 6d 65 ..."
    encoding_hint: str | None = None  # e.g. "UTF-8 BOM detected"
    exists: bool = True


# Magic-byte fingerprints for "the surprise was actually a binary".
_MAGIC_HINTS: list[tuple[bytes, str]] = [
    (b"\xef\xbb\xbf", "UTF-8 BOM detected (will break naive CSV/text parsers)"),
    (b"\xff\xfe", "UTF-16 LE BOM detected"),
    (b"\xfe\xff", "UTF-16 BE BOM detected"),
    (b"\x89PNG\r\n\x1a\n", "PNG image"),
    (b"\xff\xd8\xff", "JPEG image"),
    (b"%PDF-", "PDF document"),
    (b"PK\x03\x04", "ZIP archive (or modern docx/xlsx/jar/etc.)"),
    (b"\x1f\x8b", "gzip compressed"),
    (b"\x42\x5a\x68", "bzip2 compressed"),
]


def inspect_file(path: str | Path) -> FileAttachmentEvidence:
    """Return mime type + first-16-byte hex dump + an encoding hint when obvious."""
    p = Path(path)
    if not p.exists() or not p.is_file():
        return FileAttachmentEvidence(
            path=str(p),
            size_bytes=0,
            mime_type=None,
            hex_dump="",
            encoding_hint=None,
            exists=False,
        )
    size = p.stat().st_size
    mime, _enc = mimetypes.guess_type(str(p))
    with open(p, "rb") as f:
        head = f.read(16)
    hex_dump = " ".join(f"{b:02x}" for b in head)

    hint: str | None = None
    for prefix, label in _MAGIC_HINTS:
        if head.startswith(prefix):
            hint = label
            break

    return FileAttachmentEvidence(
        path=str(p),
        size_bytes=size,
        mime_type=mime,
        hex_dump=hex_dump,
        encoding_hint=hint,
        exists=True,
    )


# ---------------------------------------------------------------------------
# Repro steps
# ---------------------------------------------------------------------------


class ReproStep(BaseModel):
    step_number: int
    text: str


class ReproEvidence(BaseModel):
    steps: list[ReproStep] = Field(default_factory=list)
    raw: str = ""


# Match numbered/bulleted step prefixes:
#   "1. do thing"  /  "1) do thing"  /  "Step 1: do thing"  /  "- do thing"
_STEP_RE = re.compile(
    r"""^\s*
        (?:Step\s*)?
        (?:(?P<num>\d+)[.)\s:]+|[-*]\s+)
        (?P<body>\S.*)$
    """,
    re.IGNORECASE | re.VERBOSE,
)


def parse_repro_steps(text: str) -> ReproEvidence:
    """Extract numbered/bulleted steps from arbitrary text.

    If the text contains a ``Steps to reproduce`` (or similar) header,
    only lines after it are scanned. Otherwise the whole text is scanned.
    """
    # Find a "Steps to reproduce" header to scope the search.
    scoped = text
    header_pat = re.compile(
        r"(?:steps\s+to\s+reproduce|repro\s+steps|reproduction)\s*:?\s*\n",
        re.IGNORECASE,
    )
    m = header_pat.search(text)
    if m:
        scoped = text[m.end() :]

    steps: list[ReproStep] = []
    auto_num = 1
    for raw_line in scoped.splitlines():
        line = raw_line.rstrip()
        sm = _STEP_RE.match(line)
        if not sm:
            continue
        body = sm.group("body").strip()
        if not body:
            continue
        num_str = sm.group("num")
        n = int(num_str) if num_str else auto_num
        auto_num = n + 1
        steps.append(ReproStep(step_number=n, text=body))

    return ReproEvidence(steps=steps, raw=text)


__all__ = [
    "LogEntry",
    "LogEvidence",
    "parse_log_text",
    "StackFrame",
    "StackTraceEvidence",
    "parse_stacktrace",
    "FileAttachmentEvidence",
    "inspect_file",
    "ReproStep",
    "ReproEvidence",
    "parse_repro_steps",
]
