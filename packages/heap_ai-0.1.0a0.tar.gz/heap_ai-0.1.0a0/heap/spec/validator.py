"""Spec validator — adversarial second pass over a draft spec.

Per SPEC §6.2.4 this is intentionally minimal in v0.1. The validator
sends the structured spec to the planner model with a prompt of the
shape "what's missing / ambiguous / edge-case / contradicted?" and
parses a list of findings.

Findings are advisory: they are surfaced for the user to accept,
discard, or convert into amendments. The validator never modifies the
spec on its own (§1.6: never silently modify SPEC.md or specs).
"""

from __future__ import annotations

import json
import logging
import re
from typing import Literal

import yaml
from pydantic import BaseModel, Field

from heap.gateway import Gateway, GatewayResponse
from heap.spec.structurer import StructuredSpec

logger = logging.getLogger(__name__)


Severity = Literal["missing", "ambiguous", "edge_case", "contradiction"]
ALLOWED_SEVERITIES: tuple[Severity, ...] = (
    "missing",
    "ambiguous",
    "edge_case",
    "contradiction",
)


# ---------------------------------------------------------------------------
# Models
# ---------------------------------------------------------------------------


class ValidationFinding(BaseModel):
    """One thing the validator flagged in the spec."""

    severity: Severity
    description: str
    suggestion: str | None = None


class ValidationReport(BaseModel):
    """Aggregated validator output."""

    spec_name: str
    spec_version: int
    findings: list[ValidationFinding] = Field(default_factory=list)
    cost_usd: float = 0.0
    raw_response: str = ""
    parse_failed: bool = False


# ---------------------------------------------------------------------------
# Prompts
# ---------------------------------------------------------------------------


_SYSTEM_PROMPT = (
    "You are an adversarial spec reviewer. Your job is to find weaknesses "
    "in a draft spec — not to fix them. Be specific and concrete. Cite the "
    "exact field or claim that's problematic.\n\n"
    "Look for FOUR kinds of issues:\n"
    "  - missing       : critical info that should be there but isn't\n"
    "  - ambiguous     : a claim that could be read multiple ways\n"
    "  - edge_case     : implied by the spec but not addressed explicitly\n"
    "  - contradiction : two facts in the spec disagree\n\n"
    "If the spec is solid, return zero findings — do NOT invent issues to "
    "look thorough.\n\n"
    "Output JSON ONLY (no prose, no markdown fences):\n"
    '{"findings": [\n'
    '  {"severity": "missing|ambiguous|edge_case|contradiction", '
    '"description": "<what is wrong>", '
    '"suggestion": "<optional next step, or null>"}\n'
    "]}"
)


def _build_user_prompt(spec: StructuredSpec) -> str:
    spec_yaml = yaml.safe_dump(spec.model_dump(), sort_keys=False, allow_unicode=True)
    return (
        f"DRAFT SPEC ({spec.name} v{spec.version}, mode={spec.mode}, "
        f"audience={spec.audience}):\n\n"
        "```yaml\n"
        f"{spec_yaml}"
        "```\n\n"
        "Review the draft and return JSON with the findings list. If "
        'everything is solid, return `{"findings": []}`.'
    )


# ---------------------------------------------------------------------------
# Validator
# ---------------------------------------------------------------------------


class Validator:
    """Adversarial reviewer for a StructuredSpec.

    v0.1 is single-pass and best-effort: one planner call, JSON parse,
    findings list. Future iterations may add multi-round probing,
    severity-weighted summaries, or auto-suggestions for amendments.
    """

    def __init__(self, gateway: Gateway) -> None:
        self.gateway = gateway

    def validate(self, spec: StructuredSpec) -> ValidationReport:
        sys_prompt = _SYSTEM_PROMPT
        user_prompt = _build_user_prompt(spec)

        resp = self.gateway.call(
            role="planner",
            messages=[
                {"role": "system", "content": sys_prompt},
                {"role": "user", "content": user_prompt},
            ],
            max_tokens=1500,
        )
        if not isinstance(resp, GatewayResponse):
            raise RuntimeError(f"Gateway returned non-response object: {type(resp)!r}")

        findings, parse_failed = self._parse_findings(resp.content)
        return ValidationReport(
            spec_name=spec.name,
            spec_version=spec.version,
            findings=findings,
            cost_usd=resp.cost_usd,
            raw_response=resp.content or "",
            parse_failed=parse_failed,
        )

    # ------------------------------------------------------------------
    # Internals
    # ------------------------------------------------------------------

    _JSON_OBJECT_RE = re.compile(r"\{.*\}", re.DOTALL)

    @classmethod
    def _parse_findings(cls, content: str | None) -> tuple[list[ValidationFinding], bool]:
        """Permissively extract a list of findings; return (findings, parse_failed)."""
        if not content:
            return [], True

        cleaned = content.strip()
        if cleaned.startswith("```"):
            cleaned = re.sub(r"^```(?:json)?\s*", "", cleaned)
            cleaned = re.sub(r"\s*```$", "", cleaned)

        if not cleaned.startswith("{"):
            m = cls._JSON_OBJECT_RE.search(cleaned)
            cleaned = m.group(0) if m else cleaned

        try:
            data = json.loads(cleaned)
        except json.JSONDecodeError as e:
            logger.debug("validator: JSON decode failed: %s", e)
            return [], True

        if not isinstance(data, dict):
            return [], True

        raw_findings = data.get("findings", [])
        if not isinstance(raw_findings, list):
            return [], True

        findings: list[ValidationFinding] = []
        for item in raw_findings:
            if not isinstance(item, dict):
                continue
            severity = item.get("severity")
            description = item.get("description")
            if severity not in ALLOWED_SEVERITIES:
                # Coerce unknown severities to "ambiguous" so we don't lose info.
                severity = "ambiguous"
            if not description:
                continue
            findings.append(
                ValidationFinding(
                    severity=severity,
                    description=str(description),
                    suggestion=(str(item["suggestion"]) if item.get("suggestion") else None),
                )
            )
        return findings, False


__all__ = [
    "Validator",
    "ValidationReport",
    "ValidationFinding",
    "Severity",
    "ALLOWED_SEVERITIES",
]
