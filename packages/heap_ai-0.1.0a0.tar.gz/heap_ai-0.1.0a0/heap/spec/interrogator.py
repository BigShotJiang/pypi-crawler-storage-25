"""Conversational spec interrogator.

Runs a planner-driven Q&A loop to gather just enough facts to write a
spec. The Python loop drives the I/O; the model only decides the next
move (ask / echo_back / finalize) per turn, returning structured JSON.

Audience and mode shape the system prompt, not the loop.

Per SPEC §6.2.1.
"""

from __future__ import annotations

import json
import logging
import re
from collections.abc import Callable
from datetime import UTC, datetime
from typing import Any, Literal

from pydantic import BaseModel, Field

from heap.gateway import Gateway, GatewayResponse

logger = logging.getLogger(__name__)


Mode = Literal["feature", "bug", "greenfield"]
Audience = Literal["non_technical", "developer"]
SUPPORTED_MODES: tuple[Mode, ...] = ("feature", "bug", "greenfield")
SUPPORTED_AUDIENCES: tuple[Audience, ...] = ("non_technical", "developer")


# ---------------------------------------------------------------------------
# Outcome model
# ---------------------------------------------------------------------------


class TranscriptEntry(BaseModel):
    """One side of one turn in the interrogation transcript."""

    role: Literal["interrogator", "user"]
    content: str


class InterrogatorOutcome(BaseModel):
    """Result of a completed interrogation session."""

    mode: Mode
    audience: Audience
    facts: dict[str, Any] = Field(default_factory=dict)
    transcript: list[TranscriptEntry] = Field(default_factory=list)
    finalized_at: str  # ISO 8601 UTC
    turns_used: int = 0
    incomplete: bool = False
    incomplete_reason: str | None = None


# ---------------------------------------------------------------------------
# Prompts
# ---------------------------------------------------------------------------


_MODE_GUIDANCE: dict[Mode, str] = {
    "feature": (
        "Focus on: who the user is, what they want to do, what success "
        "looks like, what's explicitly out of scope, what concrete "
        "acceptance criteria look like. Do not dive into implementation."
    ),
    "bug": (
        "Focus on: what's broken (symptom), how to reproduce, what was "
        "expected vs. what actually happens, what evidence we have "
        "(logs, errors, file paths, line numbers). Do not propose "
        "fixes — just gather facts. If a clear hypothesis emerges, "
        "you may capture it as advisory."
    ),
    "greenfield": (
        "Focus on: the big-picture vision, target users, key "
        "constraints, explicit non-goals. The first iteration should "
        "be minimal and discardable; help the user identify what NOT "
        "to build first."
    ),
}

_AUDIENCE_GUIDANCE: dict[Audience, str] = {
    "non_technical": (
        "Use everyday language. Avoid technical jargon entirely. Ask "
        'for concrete examples ("can you show me an example?"). Do '
        "not reference code, APIs, schemas, or implementation details."
    ),
    "developer": (
        "You can use technical terms freely. Ask about file paths, "
        "function names, error messages, stack traces, dependency "
        "versions, and existing code patterns where relevant."
    ),
}


def _build_system_prompt(mode: Mode, audience: Audience) -> str:
    return (
        "You are a HEAP spec interrogator. Your job is to gather just "
        "enough information to write a clear, actionable spec — no more, "
        "no less.\n\n"
        f"MODE: {mode}\n{_MODE_GUIDANCE[mode]}\n\n"
        f"AUDIENCE: {audience}\n{_AUDIENCE_GUIDANCE[audience]}\n\n"
        "RULES:\n"
        "- Ask exactly ONE question per turn. Wait for the answer.\n"
        "- After 5–10 useful answers, propose an ECHO_BACK summarizing "
        "what you've learned and ask the user to confirm or correct.\n"
        "- After confirmation, FINALIZE with structured facts.\n"
        "- If you detect contradiction or vagueness, gently probe — "
        "do not lecture.\n"
        "- Keep responses concise.\n\n"
        "Each turn, output JSON ONLY (no prose, no markdown fences) "
        "in one of these shapes:\n"
        '  {"action": "ask", "question": "<single question>"}\n'
        '  {"action": "echo_back", "summary": "<plain-language summary>"}\n'
        '  {"action": "finalize", "facts": <object>}\n'
    )


# ---------------------------------------------------------------------------
# Interrogator
# ---------------------------------------------------------------------------


class Interrogator:
    """Conversational fact-gatherer driven by a planner model.

    The Python loop manages I/O; the model decides each turn's action
    (ask / echo_back / finalize) and emits JSON. After the user
    confirms an echo_back, the model finalizes with a ``facts`` dict.

    Args:
        mode: Interrogation mode — feature/bug/greenfield.
        audience: Vocabulary level — non_technical/developer.
        gateway: Configured Gateway. Planner role is used.
        prompter: Callable that takes a string prompt and returns the
            user's input. Defaults to ``input`` for CLI use; tests can
            inject a fake.
        printer: Callable that takes a string and prints it. Defaults
            to ``print``; tests can inject a fake.
        max_turns: Hard cap on conversation turns to prevent runaway
            loops on a misbehaving model. Default 25.
    """

    def __init__(
        self,
        mode: Mode,
        audience: Audience,
        gateway: Gateway,
        prompter: Callable[[str], str] = input,
        printer: Callable[[str], None] = print,
        max_turns: int = 25,
    ) -> None:
        if mode not in SUPPORTED_MODES:
            raise ValueError(f"unsupported mode {mode!r}; expected one of {SUPPORTED_MODES}")
        if audience not in SUPPORTED_AUDIENCES:
            raise ValueError(
                f"unsupported audience {audience!r}; expected one of {SUPPORTED_AUDIENCES}"
            )
        self.mode: Mode = mode
        self.audience: Audience = audience
        self.gateway = gateway
        self.prompter = prompter
        self.printer = printer
        self.max_turns = int(max_turns)
        self._sys_prompt = _build_system_prompt(mode, audience)

    # ------------------------------------------------------------------
    # Public entry
    # ------------------------------------------------------------------

    def interview(self) -> InterrogatorOutcome:
        """Run the interrogation loop until ``finalize`` or ``max_turns``."""
        transcript: list[TranscriptEntry] = []

        self.printer(
            f"\n--- HEAP spec interrogation (mode={self.mode}, audience={self.audience}) ---\n"
        )

        for turn in range(self.max_turns):
            move = self._next_move(transcript)
            action = move.get("action")

            if action == "ask":
                question = (move.get("question") or "").strip() or "(blank question)"
                self.printer(f"\n  ?  {question}")
                answer = self.prompter("  > ")
                transcript.append(TranscriptEntry(role="interrogator", content=question))
                transcript.append(TranscriptEntry(role="user", content=answer))

            elif action == "echo_back":
                summary = (move.get("summary") or "").strip() or "(blank summary)"
                self.printer("\n  Here's what I understand so far:")
                self.printer(f"  {summary}\n")
                confirm = self.prompter("  Confirm or correct: ")
                transcript.append(
                    TranscriptEntry(role="interrogator", content=f"SUMMARY: {summary}")
                )
                transcript.append(
                    TranscriptEntry(role="user", content=f"CONFIRM/CORRECT: {confirm}")
                )

            elif action == "finalize":
                facts = move.get("facts") or {}
                if not isinstance(facts, dict):
                    facts = {"raw": str(facts)}
                self.printer("\n  Got it — finalizing the spec facts.")
                return self._finalize(transcript, facts=facts, turns_used=turn + 1)

            else:
                # Unknown action — abort with what we have.
                self.printer(f"\n  [interrogator: unknown action {action!r}; finalizing]")
                return self._finalize(
                    transcript,
                    facts={"raw_move": move},
                    turns_used=turn + 1,
                    incomplete=True,
                    incomplete_reason=f"unknown action {action!r}",
                )

        self.printer(
            f"\n  [interrogator: hit max_turns={self.max_turns}; finalizing with what we have]"
        )
        return self._finalize(
            transcript,
            facts={},
            turns_used=self.max_turns,
            incomplete=True,
            incomplete_reason=f"hit max_turns={self.max_turns}",
        )

    # ------------------------------------------------------------------
    # Internals
    # ------------------------------------------------------------------

    def _next_move(self, transcript: list[TranscriptEntry]) -> dict[str, Any]:
        """Ask the planner for the next move, returning the parsed JSON."""
        user_prompt = self._render_transcript(transcript)
        resp = self.gateway.call(
            role="planner",
            messages=[
                {"role": "system", "content": self._sys_prompt},
                {"role": "user", "content": user_prompt},
            ],
            max_tokens=600,
        )
        if not isinstance(resp, GatewayResponse):
            raise RuntimeError(f"Gateway returned non-response object: {type(resp)!r}")
        return self._parse_move(resp.content)

    @staticmethod
    def _render_transcript(transcript: list[TranscriptEntry]) -> str:
        if not transcript:
            return "TRANSCRIPT: (empty — start the interrogation)"
        lines = ["TRANSCRIPT (most recent last):"]
        for entry in transcript:
            tag = "Q" if entry.role == "interrogator" else "A"
            lines.append(f"  {tag}: {entry.content}")
        lines.append("\nWhat is your next action?")
        return "\n".join(lines)

    _JSON_OBJECT_RE = re.compile(r"\{.*\}", re.DOTALL)

    @classmethod
    def _parse_move(cls, content: str | None) -> dict[str, Any]:
        """Permissively extract the JSON action object from model output."""
        if not content:
            return {"action": "unknown", "reason": "empty content"}

        cleaned = content.strip()
        if cleaned.startswith("```"):
            cleaned = re.sub(r"^```(?:json)?\s*", "", cleaned)
            cleaned = re.sub(r"\s*```$", "", cleaned)

        if not cleaned.startswith("{"):
            m = cls._JSON_OBJECT_RE.search(cleaned)
            cleaned = m.group(0) if m else cleaned

        try:
            data = json.loads(cleaned)
        except json.JSONDecodeError as e:
            return {"action": "unknown", "reason": f"unparseable JSON: {e}"}
        if not isinstance(data, dict):
            return {"action": "unknown", "reason": "JSON is not an object"}
        return data

    def _finalize(
        self,
        transcript: list[TranscriptEntry],
        facts: dict[str, Any],
        turns_used: int,
        incomplete: bool = False,
        incomplete_reason: str | None = None,
    ) -> InterrogatorOutcome:
        return InterrogatorOutcome(
            mode=self.mode,
            audience=self.audience,
            facts=facts,
            transcript=transcript,
            finalized_at=datetime.now(tz=UTC).strftime("%Y-%m-%dT%H:%M:%SZ"),
            turns_used=turns_used,
            incomplete=incomplete,
            incomplete_reason=incomplete_reason,
        )


__all__ = [
    "Interrogator",
    "InterrogatorOutcome",
    "TranscriptEntry",
    "Mode",
    "Audience",
    "SUPPORTED_MODES",
    "SUPPORTED_AUDIENCES",
]
