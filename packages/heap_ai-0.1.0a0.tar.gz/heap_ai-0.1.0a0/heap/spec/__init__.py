"""Spec module — interactive interrogation, evidence, structuring, validation.

See SPEC §6.
"""

from heap.spec.interrogator import Interrogator, InterrogatorOutcome
from heap.spec.structurer import StructuredSpec, Structurer
from heap.spec.validator import ValidationFinding, ValidationReport, Validator

__all__ = [
    "Interrogator",
    "InterrogatorOutcome",
    "Structurer",
    "StructuredSpec",
    "Validator",
    "ValidationReport",
    "ValidationFinding",
]
