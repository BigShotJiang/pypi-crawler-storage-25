"""Layer 3.1 — Tool decorator and schema generation.

The ``@tool`` decorator wraps a Python function and attaches metadata
that the agent + gateway need to expose it as an OpenAI/LiteLLM-format
function-calling tool. Schemas are generated from Python type hints via
Pydantic v2.

Usage::

    from heap import tool

    @tool(requires_approval=True, side_effects=["filesystem"])
    def write_file(path: str, content: str) -> str:
        \"\"\"Write content to a file in the workspace.\"\"\"
        ...

    @tool
    def get_weather(city: str) -> str:
        \"\"\"Return a one-line weather summary for `city`.\"\"\"
        ...

The wrapped function gets a ``__tool_meta__`` attribute pointing at a
``ToolMeta`` describing it.
"""

from __future__ import annotations

import inspect
from collections.abc import Callable
from dataclasses import dataclass, field
from typing import Any, get_type_hints

from pydantic import BaseModel, ValidationError, create_model

# ---------------------------------------------------------------------------
# ToolMeta
# ---------------------------------------------------------------------------


@dataclass
class ToolMeta:
    """All the metadata needed to expose a tool to the model + dispatch it.

    - ``schema`` is the JSON schema for the function's parameters
      (the value of ``"parameters"`` in OpenAI tools format).
    - ``args_model`` is the Pydantic model used at dispatch time to
      validate the model's tool-call arguments.
    - ``fn`` is the original Python function to invoke.
    """

    name: str
    description: str
    schema: dict[str, Any]
    requires_approval: bool = False
    side_effects: list[str] = field(default_factory=list)
    rate_limit: int | None = None
    args_model: type[BaseModel] | None = None
    fn: Callable[..., Any] | None = None

    def to_openai_tool(self) -> dict[str, Any]:
        """Render as a single entry of LiteLLM's ``tools=[...]`` parameter."""
        return {
            "type": "function",
            "function": {
                "name": self.name,
                "description": self.description,
                "parameters": self.schema,
            },
        }

    def call(self, **kwargs: Any) -> Any:
        """Validate ``kwargs`` against the args model and invoke the function.

        Raises:
            pydantic.ValidationError: if args don't match the schema.
            RuntimeError: if the tool was registered without a function.
        """
        if self.args_model is None or self.fn is None:
            raise RuntimeError(f"tool {self.name!r} has no callable bound")
        try:
            validated = self.args_model(**kwargs)
        except ValidationError:
            raise
        return self.fn(**validated.model_dump())


# ---------------------------------------------------------------------------
# Decorator
# ---------------------------------------------------------------------------


def tool(
    fn: Callable[..., Any] | None = None,
    *,
    name: str | None = None,
    description: str | None = None,
    requires_approval: bool = False,
    side_effects: list[str] | None = None,
    rate_limit: int | None = None,
) -> Callable[..., Any]:
    """Decorator that turns a function into a HEAP tool.

    Both ``@tool`` and ``@tool(...)`` forms are supported::

        @tool
        def f(x: int) -> int: ...

        @tool(requires_approval=True)
        def f(x: int) -> int: ...
    """

    def _wrap(f: Callable[..., Any]) -> Callable[..., Any]:
        sig = inspect.signature(f)
        try:
            hints = get_type_hints(f)
        except Exception:
            hints = {}

        # Build pydantic field declarations from the function signature.
        fields: dict[str, tuple[Any, Any]] = {}
        for pname, param in sig.parameters.items():
            if param.kind in (
                inspect.Parameter.VAR_POSITIONAL,
                inspect.Parameter.VAR_KEYWORD,
            ):
                # *args / **kwargs not supported in tool schemas.
                continue
            ann = hints.get(pname, Any)
            default = ... if param.default is inspect.Parameter.empty else param.default
            fields[pname] = (ann, default)

        args_model = create_model(f"{f.__name__}__Args", **fields)  # type: ignore[call-overload]

        # Pydantic v2 schema. For primitive args (str/int/bool/float/list/dict),
        # this returns a clean object schema. For nested models we'd need to
        # dereference $defs — left for v0.2.
        json_schema = args_model.model_json_schema()
        # Strip pydantic's "title" noise on the root + properties for cleaner
        # output to the model.
        json_schema.pop("title", None)
        for prop in (json_schema.get("properties") or {}).values():
            prop.pop("title", None)

        # Description: use explicit override, then docstring's first paragraph,
        # then the function name as a fallback.
        if description is not None:
            desc = description
        else:
            doc = (inspect.getdoc(f) or "").strip()
            desc = doc.split("\n\n")[0] if doc else f.__name__

        meta = ToolMeta(
            name=name or f.__name__,
            description=desc,
            schema=json_schema,
            requires_approval=requires_approval,
            side_effects=list(side_effects or []),
            rate_limit=rate_limit,
            args_model=args_model,
            fn=f,
        )

        f.__tool_meta__ = meta  # type: ignore[attr-defined]
        return f

    # Bare @tool (no parens) — fn is the function itself.
    if fn is not None and callable(fn):
        return _wrap(fn)
    # @tool(...) — return the actual wrapper.
    return _wrap


def get_meta(fn: Callable[..., Any]) -> ToolMeta:
    """Return the ``ToolMeta`` attached to ``fn`` or raise.

    Convenience for callers that want to assert a function was decorated.
    """
    meta = getattr(fn, "__tool_meta__", None)
    if not isinstance(meta, ToolMeta):
        raise TypeError(f"{fn!r} is not a @tool-decorated function")
    return meta


__all__ = ["tool", "ToolMeta", "get_meta"]
