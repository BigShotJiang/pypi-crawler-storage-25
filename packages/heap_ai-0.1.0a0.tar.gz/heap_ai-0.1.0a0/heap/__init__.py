"""HEAP — Harness for Execution, Approvals & Plans.

A model-agnostic Python harness for AI agents. See SPEC.md / README.md.
"""

from heap.agent import Agent, AgentResult, PhaseLogEntry, VerifyOutcome
from heap.gateway import BudgetExceeded, Gateway, GatewayResponse
from heap.hooks import Block, Continue, Retry, Warn
from heap.plan import Phase, Plan, PlanGenerator, RiskItem, Sprint
from heap.scenarios import Scenario, ScenarioSet, detect_gaps, generate
from heap.tool import ToolMeta, get_meta, tool

__version__ = "0.1.0a0"
__all__ = [
    # Layer 1
    "Gateway",
    "GatewayResponse",
    "BudgetExceeded",
    # Layer 3
    "tool",
    "ToolMeta",
    "get_meta",
    # Layer 4
    "Agent",
    "AgentResult",
    "VerifyOutcome",
    "PhaseLogEntry",
    # Hook actions
    "Block",
    "Warn",
    "Retry",
    "Continue",
    # Scenarios
    "Scenario",
    "ScenarioSet",
    "generate",
    "detect_gaps",
    # Plan
    "Plan",
    "Sprint",
    "Phase",
    "RiskItem",
    "PlanGenerator",
    "__version__",
]
