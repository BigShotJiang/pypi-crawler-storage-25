"""Real application integration checks."""
