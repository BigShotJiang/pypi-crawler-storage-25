from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any, cast

from agent_plugin_diagnostics.clients.snippets import doctor_server_snippet
from agent_plugin_diagnostics.core.models import DiagnosticReport
from agent_plugin_diagnostics.core.rules import RULES
from agent_plugin_diagnostics.core.workflows import audit, probe, scan
from agent_plugin_diagnostics.fixers.plans import (
    apply_preview,
    build_fix_preview,
    fix_preview_to_dict,
    render_fix_preview,
)
from agent_plugin_diagnostics.integrations.apps import (
    check_real_app_integrations,
    render_integrations_json,
    render_integrations_markdown,
    render_integrations_terminal,
)
from agent_plugin_diagnostics.reports.renderers import ReportFormat, render_report


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    try:
        return int(args.func(args))
    except BrokenPipeError:
        return 1


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="apd",
        description="Diagnose MCP and AI coding-agent plugin setups.",
    )
    subparsers = parser.add_subparsers(dest="command", required=True)

    scan_parser = _add_report_command(subparsers, "scan", "Discover MCP configs without checks.")
    scan_parser.set_defaults(func=_scan_command)

    audit_parser = _add_report_command(
        subparsers, "audit", "Discover configs and run static checks."
    )
    audit_parser.set_defaults(func=_audit_command)

    export_parser = _add_report_command(subparsers, "export", "Write an audit report.")
    export_parser.set_defaults(func=_audit_command)

    fix_parser = subparsers.add_parser("fix", help="Preview or apply safe config fixes.")
    fix_parser.add_argument("root", nargs="?", default=".", help="Workspace root to inspect.")
    fix_parser.add_argument("--home", default=None, help="Home directory override for tests or CI.")
    fix_parser.add_argument(
        "--finding",
        action="append",
        default=None,
        help="Only consider a specific finding id, for example APD050. Can be repeated.",
    )
    fix_parser.add_argument(
        "--all",
        action="store_true",
        help="Consider all supported automatic fixes. This is the default.",
    )
    mode = fix_parser.add_mutually_exclusive_group()
    mode.add_argument(
        "--dry-run",
        action="store_true",
        help="Preview diffs without writing files. This is the default.",
    )
    mode.add_argument("--apply", action="store_true", help="Write applicable fixes to disk.")
    fix_parser.add_argument(
        "--no-backup",
        action="store_true",
        help="Do not create .apd.bak backup files when applying fixes.",
    )
    fix_parser.add_argument(
        "--format",
        default="terminal",
        choices=["terminal", "json"],
        help="Output format.",
    )
    fix_parser.set_defaults(func=_fix_command)

    probe_parser = _add_report_command(
        subparsers, "probe", "Run static checks and controlled MCP probes."
    )
    probe_parser.add_argument("--server", help="Only probe a single server id.")
    probe_parser.add_argument(
        "--remote",
        action="store_true",
        help="Include remote HTTP and SSE probes. This may make network requests.",
    )
    probe_parser.add_argument(
        "--timeout",
        type=float,
        default=10.0,
        help="Probe timeout in seconds.",
    )
    probe_parser.set_defaults(func=_probe_command)

    explain_parser = subparsers.add_parser("explain", help="Explain a diagnostic rule.")
    explain_parser.add_argument("rule_id")
    explain_parser.set_defaults(func=_explain_command)

    integrations_parser = subparsers.add_parser(
        "integrations",
        help="Check real installed agent apps and documented config paths.",
    )
    integrations_parser.add_argument(
        "root",
        nargs="?",
        default=".",
        help="Workspace root to inspect.",
    )
    integrations_parser.add_argument(
        "--home",
        default=None,
        help="Home directory override for tests or CI.",
    )
    integrations_parser.add_argument(
        "--format",
        default="terminal",
        choices=["terminal", "json", "markdown"],
        help="Output format.",
    )
    integrations_parser.add_argument(
        "--output",
        default=None,
        help="Write output to a file instead of stdout.",
    )
    integrations_parser.add_argument(
        "--timeout",
        type=float,
        default=3.0,
        help="Timeout in seconds for app version commands.",
    )
    integrations_parser.add_argument(
        "--no-version",
        action="store_true",
        help="Only detect commands; do not run version commands.",
    )
    integrations_parser.set_defaults(func=_integrations_command)

    init_parser = subparsers.add_parser("init", help="Print an MCP Doctor config snippet.")
    init_parser.add_argument(
        "--client",
        required=True,
        choices=[
            "claude-code",
            "claude-desktop",
            "cline",
            "codex",
            "cursor",
            "opencode",
            "roo-code",
            "vscode",
            "windsurf",
            "zed",
        ],
    )
    init_parser.set_defaults(func=_init_command)

    serve_parser = subparsers.add_parser("serve-mcp", help="Run APD as an MCP server.")
    serve_parser.set_defaults(func=_serve_mcp_command)
    return parser


def _add_report_command(
    subparsers: argparse._SubParsersAction[Any],
    name: str,
    help_text: str,
) -> argparse.ArgumentParser:
    command = cast(argparse.ArgumentParser, subparsers.add_parser(name, help=help_text))
    command.add_argument("root", nargs="?", default=".", help="Workspace root to inspect.")
    command.add_argument("--home", default=None, help="Home directory override for tests or CI.")
    command.add_argument(
        "--format",
        default="terminal",
        choices=["terminal", "json", "markdown", "sarif"],
        help="Output format.",
    )
    command.add_argument("--output", default=None, help="Write output to a file instead of stdout.")
    return command


def _scan_command(args: argparse.Namespace) -> int:
    report = scan(root=Path(args.root), home=Path(args.home) if args.home else None)
    return _write_report(report, args.format, args.output)


def _audit_command(args: argparse.Namespace) -> int:
    report = audit(root=Path(args.root), home=Path(args.home) if args.home else None)
    _write_report(report, args.format, args.output)
    return (
        1
        if any(finding.severity.value in {"critical", "high"} for finding in report.findings)
        else 0
    )


def _probe_command(args: argparse.Namespace) -> int:
    report = probe(
        root=Path(args.root),
        home=Path(args.home) if args.home else None,
        server_id=args.server,
        include_remote=bool(args.remote),
        timeout=float(args.timeout),
    )
    _write_report(report, args.format, args.output)
    return (
        1
        if any(finding.severity.value in {"critical", "high"} for finding in report.findings)
        else 0
    )


def _fix_command(args: argparse.Namespace) -> int:
    root = Path(args.root)
    report = audit(root=root, home=Path(args.home) if args.home else None)
    finding_ids = {str(finding).upper() for finding in args.finding} if args.finding else None
    preview = build_fix_preview(report=report, root=root, finding_ids=finding_ids)
    backups: tuple[Path, ...] = ()
    if args.apply and preview.has_changes:
        backups = apply_preview(preview, create_backups=not bool(args.no_backup))

    if args.format == "json":
        payload = fix_preview_to_dict(preview)
        payload["applied"] = bool(args.apply)
        payload["backups"] = [str(path) for path in backups]
        sys.stdout.write(json.dumps(payload, indent=2, sort_keys=True) + "\n")
        return 0

    sys.stdout.write(render_fix_preview(preview))
    if args.apply:
        sys.stdout.write(f"Applied patches: {len(preview.patches)}\n")
        if backups:
            sys.stdout.write("Backups:\n")
            for backup in backups:
                sys.stdout.write(f"- {backup}\n")
    else:
        sys.stdout.write("Dry run only. Re-run with --apply to write applicable patches.\n")
    return 0


def _integrations_command(args: argparse.Namespace) -> int:
    report = check_real_app_integrations(
        root=Path(args.root),
        home=Path(args.home) if args.home else None,
        timeout=float(args.timeout),
        include_versions=not bool(args.no_version),
    )
    if args.format == "json":
        rendered = render_integrations_json(report)
    elif args.format == "markdown":
        rendered = render_integrations_markdown(report)
    else:
        rendered = render_integrations_terminal(report)
    if args.output:
        Path(args.output).write_text(rendered, encoding="utf-8")
    else:
        sys.stdout.write(rendered)
    return 0


def _write_report(report: DiagnosticReport, output_format: str, output: str | None) -> int:
    rendered = render_report(report, cast(ReportFormat, output_format))
    if output:
        Path(output).write_text(rendered, encoding="utf-8")
    else:
        sys.stdout.write(rendered)
    return 0


def _explain_command(args: argparse.Namespace) -> int:
    rule = RULES.get(args.rule_id.upper())
    if not rule:
        sys.stderr.write(f"Unknown rule id: {args.rule_id}\n")
        return 2
    sys.stdout.write(
        "\n".join(
            [
                f"{rule.id}: {rule.title}",
                f"Severity: {rule.severity.value}",
                f"Category: {rule.category}",
                "",
                rule.description,
                "",
                f"Fix: {rule.suggestion}",
            ]
        )
        + "\n"
    )
    return 0


def _init_command(args: argparse.Namespace) -> int:
    sys.stdout.write(doctor_server_snippet(str(args.client)))
    return 0


def _serve_mcp_command(_: argparse.Namespace) -> int:
    from agent_plugin_diagnostics.mcp_server.server import run

    run()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
