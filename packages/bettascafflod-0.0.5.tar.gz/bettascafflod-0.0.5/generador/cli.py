from rich.console import Console
import pyfiglet
from rich.text import Text
from rich.prompt import Prompt
from generador.parser import parse_create_table
from generador.generators.csharp.createModel import create_model_csharp
from generador.generators.csharp.createCRUD import create_crud_csharp
from generador.generators.peewee import generate_peewee
import sys

console = Console()

def main():
    ascii_banner = pyfiglet.figlet_format("BettaScaffold")
    banner_text = Text(ascii_banner, style="bold magenta")

    console.print(banner_text)
    console.print("[bold green]Convierte tus tablas SQL en modelos JSON, C# o Peewee.[/bold green]\n")
    console.print("Escribe [red]exit[/red] para salir. \t\t\t\t\t\t version 0.0.2\n")

    while True:
        console.print("[bold cyan] Qué quieres hacer?:[/bold cyan]")
        console.print("1. Convertir SQL a JSON")
        console.print("2. Convertir SQL a Data Entity C#")
        console.print("3. Convertir SQL a  Data Entity Peewee")        
        console.print("4. Convertir a CRUD Basico en C# (Dapper)")
        console.print("5. Convertir a CRUD Basico en Python (Peewee)")
        console.print("6. Ejemplo de SQL para probar el parser")
        console.print("Escribe [red]exit[/red] para salir.\n")
        
        choice = Prompt.ask("Selecciona una opción", choices=["1", "2", "3", "4", "5","6","exit"], default="1")

        if choice == "1":
            sql = Prompt.ask("Ingresa tu sentencia SQL CREATE TABLE")
            if sql.strip().lower() == "exit":
                console.print("[yellow]Saliendo de Bettascaffold...[/yellow]")
                sys.exit(0)

            try:
                model = parse_create_table(sql)
            except Exception as e:
                console.print(f"[red]Error al parsear SQL: {e}[/red]")
                continue
            console.print("\n=== JSON MODEL ===")
            console.print(model)
        elif choice == "2":
            sql = Prompt.ask("Ingresa tu sentencia SQL CREATE TABLE")
            if sql.strip().lower() == "exit":
                console.print("[yellow]Saliendo de Bettascaffold...[/yellow]")
                sys.exit(0)

            try:
                model = parse_create_table(sql)
            except Exception as e:
                console.print(f"[red]Error al parsear SQL: {e}[/red]")
                continue
            console.print("\n=== C# MODEL ===")
            console.print(create_model_csharp(model))
        elif choice == "3":
            sql = Prompt.ask("Ingresa tu sentencia SQL CREATE TABLE")
            if sql.strip().lower() == "exit":
                console.print("[yellow]Saliendo de Bettascaffold...[/yellow]")
                sys.exit(0)

            try:
                model = parse_create_table(sql)
            except Exception as e:
                console.print(f"[red]Error al parsear SQL: {e}[/red]")
                continue
            console.print("\n=== PYTHON (PEEWEE) ===")
            console.print(generate_peewee(model))
        elif choice == "4":
            sql = Prompt.ask("Ingresa tu sentencia SQL CREATE TABLE")
            if sql.strip().lower() == "exit":
                console.print("[yellow]Saliendo de Bettascaffold...[/yellow]")
                sys.exit(0)

            try:
                model = parse_create_table(sql)
            except Exception as e:
                console.print(f"[red]Error al parsear SQL: {e}[/red]")
                continue
            console.print("\n=== C# CRUD ===")
            console.print(create_crud_csharp(model))
        elif choice == "5":
            sql = Prompt.ask("Ingresa tu sentencia SQL CREATE TABLE")
            sys.exit(0)
        elif choice == "6":
            sql_input = "CREATE [REFERENCE] TABLE YourTable (first_column bigint(20) NOT NULL AUTO_INCREMENT PRIMARY KEY, second_column varchar(150) NOT NULL)"
            console.print("\n=== SQL DE PRUEBA ===")
            console.print(sql_input)
            console.print("\n=== JSON MODEL ===")
            console.print(parse_create_table(sql_input))
        if choice == "exit":
            console.print("[yellow]Saliendo de Bettascaffold...[/yellow]")
            sys.exit(0)
