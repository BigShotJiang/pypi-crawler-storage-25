import re

def parse_create_table(sql: str):
    # 1. Extraer el nombre de la tabla (Soporta CREATE TABLE o CREATE REFERENCE TABLE)
    table_match = re.search(r'CREATE(?:\s+\w+)?\s+TABLE\s+`?(\w+)`?', sql, re.IGNORECASE)
    if not table_match:
        return None
    
    table_name = table_match.group(1)

    # 2. Extraer SOLO lo que está entre los paréntesis principales (...)
    # Esto evita que palabras como "CREATE" o "REFERENCE" se procesen como columnas
    content_match = re.search(r'\((.*)\)', sql, re.DOTALL)
    if not content_match:
        return {"table": table_name, "columns": []}
    
    inner_content = content_match.group(1)

    # 3. Buscar las columnas dentro del contenido extraído
    # Explicación de la regex:
    # `?(\w+)`?          -> Captura el nombre (con o sin comillas)
    # \s+([a-zA-Z]+)     -> Captura el tipo de dato
    # (?:\((\d+)\))?     -> Captura la longitud opcional (ej: 255)
    # .*?(AUTO_INCREMENT)? -> Busca si existe AUTO_INCREMENT antes de la siguiente coma o fin
    column_pattern = re.compile(r'`?(\w+)`?\s+([a-zA-Z]+)(?:\((\d+)\))?.*?(AUTO_INCREMENT)?', re.IGNORECASE)
    
    # Buscamos también las llaves primarias para marcarlas
    primary_keys = re.findall(r'PRIMARY KEY\s+\(`?(\w+)`?\)', inner_content, re.IGNORECASE)

    columns = []
    # Dividimos por comas para procesar cada línea de columna individualmente
    for line in inner_content.split(','):
        line = line.strip()
        col_match = column_pattern.match(line)
        
        if col_match:
            name, col_type, length, auto = col_match.groups()
            
            # Evitar capturar la palabra 'PRIMARY' como una columna (caso de PRIMARY KEY al final)
            if name.upper() == 'PRIMARY':
                continue

            columns.append({
                "name": name,
                "type": col_type.lower(),
                "length": int(length) if length else None,
                "primary": name in primary_keys or "PRIMARY KEY" in line.upper(),
                "autoIncrement": bool(auto)
            })

    return {
        "table": table_name,
        "columns": columns
    }
