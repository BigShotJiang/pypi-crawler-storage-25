from generador.utils import to_pascal_case

TYPE_MAP = {
    "bigint": "long?",
    "int": "int?",
    "varchar": "string?",
    "text": "string?",
    "tinyint": "bool?",
    "datetime": "DateTime?",
    "char": "string?",
    "date": "DateTime?",
    "timestamp": "DateTime",
    "decimal": "decimal?",
    
}

def create_model_csharp(model):
    lines = []
    class_name = model["table"] + "DE"

    lines.append(f"public class {class_name}")
    lines.append("{")

    for col in model["columns"]:
        csharp_type = TYPE_MAP.get(col["type"], "string")
        name = to_pascal_case(col["name"])

        lines.append(f"    public {csharp_type} {name} {{ get; set; }}")

    lines.append("}")

    return "\n".join(lines)