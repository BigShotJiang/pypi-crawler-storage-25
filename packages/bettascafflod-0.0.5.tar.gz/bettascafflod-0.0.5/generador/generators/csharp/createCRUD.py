from generador.utils import to_pascal_case


def create_crud_csharp(model):
    table_name = model["table"]
    class_name = "Imp" + table_name + "DA"
    entity_name = table_name + "DE"
    
    generated_code = _generate_create_method(model,entity_name,table_name)
    generated_code += _generate_get__method(model,entity_name,table_name)
    generated_code += _generate_update_csharp(model,entity_name,table_name)
    generated_code += generate_logical_delete_csharp(model)
    return generated_code
    

def _generate_create_method(model,entity_name,table_name):
    cols = [col['name'] for col in model['columns'] if not col.get('autoIncrement', False)]
    sql_cols = ", ".join(cols)
    sql_params = ", ".join(["@" + to_pascal_case(col) for col in cols])
    
    return f"""
        public async Task<long> Create{to_pascal_case(table_name)}({entity_name} model, long UserId)
        {{
            var query = @"INSERT INTO {table_name} ({sql_cols}) 
                        VALUES ({sql_params}); 
                        SELECT LAST_INSERT_ID();";

            return await _retryPolicy.ExecuteAsync(async () =>
            {{
                using var connection = _dapperContext.CreateConnection();
                if (connection.State != ConnectionState.Open)
                    connection.Open();

                using var transaction = connection.BeginTransaction();
                try
                {{
                    var id = await connection.ExecuteScalarAsync<long>(query, model);

                    await _systemDA.InsertLog(new LogDE
                    {{
                        UserId = UserId,
                        LogTypeId = Consts.RecordCreation,
                        CreatedAt = DateTimeOffset.Now.AddDays(_time).DateTime,
                        LogDesc = $"{table_name} creado: {{id}}",
                        DataContent = Newtonsoft.Json.JsonConvert.SerializeObject(model),
                        IdTransaction = transaction
                    }});

                    transaction.Commit();
                    return id;
                }}
                catch (MySqlException ex)
                {{
                    _logger.LogError(ex, "Error creating {table_name}");
                    transaction.Rollback();
                    throw;
                }}
            }});
        }}"""

def _generate_get__method(model,entity_name,table_name):
    primary_key = next((col['name'] for col in model['columns'] if col.get('primary')), "Id")
    return f"""        
        public async Task<IEnumerable<{to_pascal_case(table_name)}>> GetAll{to_pascal_case(entity_name)}(long UserId)
        {{

            var query = @"SELECT * FROM {table_name}";

            return await _retryPolicy.ExecuteAsync(async () =>
            {{
                using var connection = _dapperContext.CreateConnection();
                if (connection.State != ConnectionState.Open)
                    connection.Open();

                using var transaction = connection.BeginTransaction();
                try
                {{
                    var {table_name}s = await connection.QueryAsync<{to_pascal_case(entity_name)}>(query);

                    await _systemDA.InsertLog(new LogDE
                    {{
                        UserId = UserId,
                        LogTypeId = Consts.SensitiveDataInquiry,
                        CreatedAt = DateTimeOffset.Now.AddDays(_time).DateTime,
                        LogDesc = $"",
                        DataContent = Newtonsoft.Json.JsonConvert.SerializeObject(),
                        IdTransaction = transaction
                    }});
                    transaction.Commit();
                    return {table_name}s;
                }}
                catch (MySqlException ex)
                {{
                    _logger.LogError(ex, "Error getting {table_name}");
                    transaction.Rollback();
                    throw;
                }}
            }});
        }}
        
        public async Task<{to_pascal_case(table_name)}> Get{to_pascal_case(table_name)}ById(long id)
        {{
            var query = f"SELECT * FROM {to_pascal_case(table_name)} WHERE {primary_key} = @Id";
            using var connection = _dapperContext.CreateConnection();
            
            return await _retryPolicy.ExecuteAsync(async () =>
            {{
                using var connection = _dapperContext.CreateConnection();
                if (connection.State != ConnectionState.Open)
                    connection.Open();

                using var transaction = connection.BeginTransaction();
                try
                {{
                    var {table_name} = await connection.QueryFirstOrDefaultAsync<{to_pascal_case(table_name)}>(query, new {{ Id = id }});

                    await _systemDA.InsertLog(new LogDE
                    {{
                        UserId = UserId,
                        LogTypeId = Consts.SensitiveDataInquiry,
                        CreatedAt = DateTimeOffset.Now.AddDays(_time).DateTime,
                        LogDesc = $"",
                        DataContent = Newtonsoft.Json.JsonConvert.SerializeObject(),
                        IdTransaction = transaction
                    }});
                    transaction.Commit();
                    return {table_name};
                }}
                catch (MySqlException ex)
                {{
                    _logger.LogError(ex, "Error getting {table_name}");
                    transaction.Rollback();
                    throw;
                }}
            }});
        }}
        
        """

def _generate_update_csharp(model,entity_name,table_name):
    
    primary_key = next((col['name'] for col in model['columns'] if col.get('primary')), "Id") 
    fields = [col['name'] for col in model['columns'] if not col['primary']]
    
    set_clause = ", ".join([f"{col} = @{to_pascal_case(col)}" for col in fields])
    where_clause = f"{primary_key} = @{to_pascal_case(primary_key)}"

    return f"""
        public async Task<bool> Update{to_pascal_case(table_name)}({entity_name} model, long UserId)
        {{
            var query = @"UPDATE {table_name} SET {set_clause} WHERE {where_clause};";

            return await _retryPolicy.ExecuteAsync(async () =>
            {{
                using var connection = _dapperContext.CreateConnection();
                var rows = await connection.ExecuteAsync(query, model);
                
                if (rows > 0)
                {{
                    await _systemDA.InsertLog(new LogDE {{
                        UserId = UserId,
                        LogTypeId = Consts.RecordUpdate,
                        LogDesc = $"",
                        DataContent = Newtonsoft.Json.JsonConvert.SerializeObject(model)
                    }});
                }}
                return rows > 0;
            }});
        }}"""        

def generate_logical_delete_csharp(model):
    table_name = model["table"]
    # Buscamos la PK en el JSON
    primary_key = next((col['name'] for col in model['columns'] if col.get('primary')), "id")
    pk_pascal = to_pascal_case(primary_key)
    

    code = f"""
        public async Task<bool> Delete{table_name}(long {pk_pascal.lower()}, long UserId)
        {{
            var query = @"UPDATE {table_name} 
                        SET deleted_at = @DeletedAt 
                        WHERE {primary_key} = @{pk_pascal}";

            var parameters = new
            {{
                DeletedAt = DateTimeOffset.Now.AddHours(_time).DateTime,
                {pk_pascal} = {pk_pascal.lower()}
            }};

            return await _retryPolicy.ExecuteAsync(async () =>
            {{
                using var connection = _dapperContext.CreateConnection();
                if (connection.State != ConnectionState.Open)
                    connection.Open();

                using var transaction = connection.BeginTransaction();
                try
                {{
                    var rowsAffected = await connection.ExecuteAsync(query, parameters, transaction);

                    await _systemDA.InsertLog(new LogDE
                    {{
                        UserId = UserId,
                        LogTypeId = Consts.RecordDeletion,
                        CreatedAt = DateTimeOffset.Now.AddHours(_time).DateTime,
                        LogDesc = $"{table_name} {{ {pk_pascal.lower()} }} eliminado por {{userId}}",
                        DataContent = Newtonsoft.Json.JsonConvert.SerializeObject(new {{ {pk_pascal} = {pk_pascal.lower()} }}),
                        IdTransaction = transaction
                    }});

                    transaction.Commit();
                    return rowsAffected > 0;
                }}
                catch (MySqlException ex)
                {{
                    _logger.LogError(ex, "Error deleting {table_name}");
                    transaction.Rollback();
                    throw;
                }}
            }});
        }}"""
    return code