TYPE_MAP = {
    "bigint": "BigIntegerField",
    "int": "IntegerField",
    "varchar": "CharField",
    "text": "TextField",
    "tinyint": "BooleanField",
    "datetime": "DateTimeField",
    "char": "CharField",
    "date": "DateField",
    "timestamp": "DateTimeField",
    "decimal": "DecimalField",
}

def generate_peewee(model):
    lines = []
    class_name = model["table"]

    lines.append(f"class {class_name}(BaseModal):")

    for col in model["columns"]:
        field_type = TYPE_MAP.get(col["type"], "CharField")

        if col["primary"] and col["autoIncrement"]:
            line = f"    {col['name']} = AutoField(primary_key=True)"
        elif col["type"] == "varchar":
            line = f"    {col['name']} = CharField(max_length={col['length']})"
        else:
            line = f"    {col['name']} = {field_type}()"

        lines.append(line)

    lines.append("\n    class Meta:")
    lines.append(f"        table_name = \"{model['table']}\"")

    return "\n".join(lines)