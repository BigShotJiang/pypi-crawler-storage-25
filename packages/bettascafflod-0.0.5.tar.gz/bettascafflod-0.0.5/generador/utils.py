def to_pascal_case(s: str):
    return ''.join(word.capitalize() for word in s.split('_'))