# Contributing to fognode

Personal library. PRs accepted only in narrow scope.

## Accepted

| Type | Accepted |
|---|---|
| Bug fixes | yes |
| Code optimization | yes |
| Cross-platform improvements | yes |
| Security hardening | yes |
| Features | no |
| Documentation | no |
| Questions | no |

## Requirements

- Python 3.10+
- `ruff check src/ tests/`
- `black --check src/ tests/`
- `pyright src/`
- `pytest tests/`
- No comments explaining what code does
- `from __future__ import annotations` where needed

## PR checklist

- [ ] All checks pass
- [ ] No breaking API changes in `src/fognode/__init__.py`
