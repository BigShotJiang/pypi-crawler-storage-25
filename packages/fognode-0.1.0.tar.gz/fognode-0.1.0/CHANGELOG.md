# Changelog

## 0.1.0

- Initial release.
- TLS 1.2+ with strong cipher suite.
- X25519 ephemeral key exchange over TLS.
- AESGCM-256 + HMAC-SHA256 frame encryption.
- PBKDF2-HMAC-SHA256 password derivation.
- Monotonic counter + timestamp replay protection.
- IP-to-word encoding for human-readable addresses.
- Rate-limited authentication.
