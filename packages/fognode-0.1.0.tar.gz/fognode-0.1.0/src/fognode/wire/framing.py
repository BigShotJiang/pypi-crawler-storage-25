from __future__ import annotations

import json
import ssl
import struct
from typing import Any

from fognode.types.constants import MAX_MESSAGE_SIZE
from fognode.types.exceptions import SecurityError


def wire_send(sock: ssl.SSLSocket, data: dict[str, Any]) -> None:
    raw = json.dumps(data).encode()
    sock.sendall(struct.pack(">I", len(raw)) + raw)


def wire_recv(sock: ssl.SSLSocket) -> dict[str, Any]:
    hdr = b""
    while len(hdr) < 4:
        c = sock.recv(4 - len(hdr))
        if not c:
            raise ConnectionError("closed")
        hdr += c
    n = struct.unpack(">I", hdr)[0]
    if n > MAX_MESSAGE_SIZE:
        raise SecurityError(f"msg size {n} > limit")
    buf = b""
    while len(buf) < n:
        c = sock.recv(n - len(buf))
        if not c:
            raise ConnectionError("closed")
        buf += c
    return json.loads(buf.decode())
