from __future__ import annotations

import logging
import socket
import ssl
import threading
import time

from cryptography import x509
from cryptography.x509.oid import NameOID

from fognode.auth.handshake import server_handshake
from fognode.core.state import ChatState
from fognode.crypto.cert import cert_fingerprint, cert_paths, generate_cert, ssl_server_context
from fognode.crypto.channel import SecureChannel
from fognode.crypto.password import store_password
from fognode.types.constants import CHAT_MAX_TEXT_LENGTH
from fognode.types.exceptions import AuthError, SecurityError
from fognode.types.protocol import CodeName, IPAddress, OnConnect, OnDisconnect, Port, User
from fognode.utils.ipwords import ip_to_name
from fognode.utils.net import local_ip
from fognode.utils.ratelimit import RateLimiter

_state = ChatState()
_rl = RateLimiter()


def _session_loop(
    ch: SecureChannel,
    user: User,
    ip: IPAddress,
    on_connect: OnConnect | None,
    on_disconnect: OnDisconnect | None,
) -> None:
    _state.register(user, ch)
    if on_connect:
        on_connect(user)

    ch.send(
        {
            "type": "welcome",
            "user": user,
            "online": _state.users(),
            "history": [m.as_dict() for m in _state.history(30)],
        }
    )

    try:
        while True:
            msg = ch.recv()
            mtype = msg.get("type", "")

            if mtype == "chat":
                text = str(msg.get("text", ""))[:CHAT_MAX_TEXT_LENGTH]
                entry = _state.add(user, text)
                ch.send(entry.as_dict())
                _state.broadcast(entry, exclude=user)

            elif mtype == "cmd":
                _handle_cmd(ch, user, msg)
    except (ConnectionError, OSError, SecurityError):
        pass
    finally:
        _state.unregister(user)
        ch.close()
        if on_disconnect:
            on_disconnect(user)


def _handle_cmd(ch: SecureChannel, user: User, msg: dict) -> None:  # type: ignore[type-arg]
    cmd = msg.get("cmd", "")
    if cmd == "ping":
        ch.send({"type": "pong", "ts": time.time()})
    elif cmd == "info":
        ch.send(
            {
                "type": "info",
                "server": "fognode/1.0",
                "user": user,
                "online": _state.users(),
                "msgs": _state.message_count(),
                "time": time.strftime("%Y-%m-%d %H:%M:%S UTC", time.gmtime()),
                "tls": ch._sock.version(),
                "cipher": (ch._sock.cipher() or ["?"])[0],
            }
        )
    elif cmd == "history":
        n = min(int(msg.get("n", 50)), 200)
        ch.send(
            {
                "type": "history",
                "messages": [m.as_dict() for m in _state.history(n)],
            }
        )
    elif cmd == "users":
        ch.send({"type": "users", "online": _state.users()})
    elif cmd == "quit":
        ch.send({"type": "bye"})
        raise ConnectionError("quit")


def _handle_client(
    raw: socket.socket,
    client_ip: IPAddress,
    user: User,
    ctx: ssl.SSLContext,
    on_connect: OnConnect | None,
    on_disconnect: OnDisconnect | None,
) -> None:
    if not _rl.check(client_ip):
        raw.close()
        return
    try:
        with ctx.wrap_socket(raw, server_side=True) as tls:
            tls.settimeout(30)
            ch = server_handshake(tls, client_ip, user)
            _session_loop(ch, user, client_ip, on_connect, on_disconnect)
    except ssl.SSLError as e:
        if "EOF" not in str(e):
            logging.debug(f"TLS {client_ip}: {e}")
        _rl.fail(client_ip)
    except AuthError as e:
        logging.warning(f"auth fail {client_ip}: {e}")
        _rl.fail(client_ip)
    except Exception as e:
        logging.debug(f"{client_ip}: {e}")
    finally:
        try:
            raw.close()
        except Exception:
            pass


def start_server(
    host: str,
    port: Port,
    username: User,
    password: str,
    on_connect: OnConnect | None = None,
    on_disconnect: OnDisconnect | None = None,
) -> tuple[IPAddress, CodeName, str]:
    local = local_ip()
    display_ip = local if host == "0.0.0.0" else host
    code_name = ip_to_name(display_ip)

    cert_file, key_file = cert_paths()
    if not cert_file.exists() or not key_file.exists():
        generate_cert(code_name)
    else:
        try:
            existing_cn = (
                x509.load_pem_x509_certificate(cert_file.read_bytes())
                .subject.get_attributes_for_oid(NameOID.COMMON_NAME)[0]
                .value
            )
            if existing_cn != code_name:
                generate_cert(code_name)
        except Exception:
            generate_cert(code_name)

    store_password(password)
    fp = cert_fingerprint(cert_file)
    ctx = ssl_server_context()

    def _serve() -> None:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as srv:
            srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            srv.bind((host, port))
            srv.listen(20)
            while True:
                try:
                    conn, addr = srv.accept()
                except OSError:
                    break
                threading.Thread(
                    target=_handle_client,
                    args=(conn, addr[0], username, ctx, on_connect, on_disconnect),
                    daemon=True,
                ).start()

    threading.Thread(target=_serve, daemon=True).start()
    return display_ip, code_name, fp
