from __future__ import annotations

import time
from threading import Lock

from fognode.crypto.channel import SecureChannel
from fognode.types.constants import CHAT_HISTORY_LIMIT
from fognode.types.protocol import ChatMsg, OnMessage, User


class ChatState:
    def __init__(self, limit: int = CHAT_HISTORY_LIMIT) -> None:
        self._lock = Lock()
        self._hist: list[ChatMsg] = []
        self._sess: dict[User, SecureChannel] = {}
        self._hooks: list[OnMessage] = []
        self.limit = limit

    def add(self, user: User, text: str) -> ChatMsg:
        m = ChatMsg(time.time(), user, text)
        with self._lock:
            self._hist.append(m)
            if len(self._hist) > self.limit:
                self._hist = self._hist[-self.limit :]
        for cb in self._hooks:
            try:
                cb(m)
            except Exception:
                pass
        return m

    def history(self, n: int = 50) -> list[ChatMsg]:
        with self._lock:
            return list(self._hist[-n:])

    def register(self, user: User, ch: SecureChannel) -> None:
        with self._lock:
            self._sess[user] = ch

    def unregister(self, user: User) -> None:
        with self._lock:
            self._sess.pop(user, None)

    def get_channel(self, user: User) -> SecureChannel | None:
        with self._lock:
            return self._sess.get(user)

    def users(self) -> list[User]:
        with self._lock:
            return list(self._sess.keys())

    def broadcast(self, m: ChatMsg, exclude: User | None = None) -> None:
        with self._lock:
            targets = [(u, ch) for u, ch in self._sess.items() if u != exclude]
        for _, ch in targets:
            try:
                ch.send(m.as_dict())
            except Exception:
                pass

    def message_count(self) -> int:
        with self._lock:
            return len(self._hist)

    def on_message(self, cb: OnMessage) -> None:
        self._hooks.append(cb)
