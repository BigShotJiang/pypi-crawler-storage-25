from __future__ import annotations

import base64
import os
import socket
import tempfile
from pathlib import Path

from fognode.auth.handshake import client_handshake
from fognode.crypto.cert import cert_fingerprint, ssl_probe_context, ssl_verified_context
from fognode.crypto.channel import SecureChannel
from fognode.types.protocol import CodeName, ConnectString, IPAddress, Port, User
from fognode.utils.ipwords import name_to_ip


def client_connect(connect_str: ConnectString, password: str) -> tuple[SecureChannel, str]:
    try:
        user_part, port_str = connect_str.rsplit(":", 1)
        port: Port = int(port_str)
        username: User
        code_name: CodeName
        username, code_name = user_part.split("@", 1)
    except Exception:
        raise ValueError(f"Bad connect string: {connect_str!r}") from None

    server_ip: IPAddress = name_to_ip(code_name)

    raw_p = socket.create_connection((server_ip, port), timeout=10)
    tls_p = ssl_probe_context().wrap_socket(raw_p, server_hostname=code_name)
    der = tls_p.getpeercert(binary_form=True)
    tls_p.close()
    raw_p.close()
    if not der:
        raise ConnectionError("no cert from server")
    measured_fp = cert_fingerprint(der)

    pem = (
        b"-----BEGIN CERTIFICATE-----\n" + base64.encodebytes(der) + b"-----END CERTIFICATE-----\n"
    )
    fd, tmp_path = tempfile.mkstemp(suffix=".pem")
    os.write(fd, pem)
    os.close(fd)
    tmp = Path(tmp_path)
    try:
        raw_sock = socket.create_connection((server_ip, port), timeout=10)
        tls_sock = ssl_verified_context(tmp, code_name).wrap_socket(
            raw_sock, server_hostname=code_name
        )
        tls_sock.settimeout(30)
    finally:
        tmp.unlink(missing_ok=True)

    channel = client_handshake(tls_sock, username, password, measured_fp)
    return channel, measured_fp
