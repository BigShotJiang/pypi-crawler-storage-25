from __future__ import annotations

import socket
from typing import Any

from fognode.crypto.cert import cert_fingerprint, ssl_probe_context
from fognode.types.protocol import CodeName, ConnectString, IPAddress, Port, User
from fognode.utils.ipwords import name_to_ip


def probe_server(connect_str: ConnectString) -> dict[str, Any]:
    try:
        user_part, port_str = connect_str.rsplit(":", 1)
        port: Port = int(port_str)
        username: User
        code_name: CodeName
        username, code_name = user_part.split("@", 1)
    except Exception:
        raise ValueError(f"Bad connect string: {connect_str!r}") from None

    server_ip: IPAddress = name_to_ip(code_name)

    raw = socket.create_connection((server_ip, port), timeout=10)
    tls = ssl_probe_context().wrap_socket(raw, server_hostname=code_name)
    der = tls.getpeercert(binary_form=True)
    version = tls.version()
    cipher = tls.cipher()
    tls.close()
    raw.close()

    return {
        "connect_string": connect_str,
        "username": username,
        "code_name": code_name,
        "server_ip": server_ip,
        "port": port,
        "tls_version": version,
        "cipher": cipher[0] if cipher else "?",
        "cipher_bits": cipher[2] if cipher else 0,
        "cipher_version": cipher[1] if cipher else "?",
        "fp": cert_fingerprint(der) if der else None,
    }
