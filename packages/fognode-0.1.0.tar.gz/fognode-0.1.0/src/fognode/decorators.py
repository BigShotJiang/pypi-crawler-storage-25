from __future__ import annotations

import functools
import time
from typing import Any, Callable, TypeVar

from fognode.types.exceptions import SecurityError
from fognode.utils.ratelimit import RateLimiter

F = TypeVar("F", bound=Callable[..., Any])


def retry(max_attempts: int = 3, delay: float = 1.0, backoff: float = 2.0) -> Callable[[F], F]:
    def decorator(func: F) -> F:
        @functools.wraps(func)
        def wrapper(*args: Any, **kwargs: Any) -> Any:
            current_delay = delay
            last_exc: BaseException | None = None
            for attempt in range(1, max_attempts + 1):
                try:
                    return func(*args, **kwargs)
                except BaseException as e:
                    last_exc = e
                    if attempt < max_attempts:
                        time.sleep(current_delay)
                        current_delay *= backoff
            assert last_exc is not None
            raise last_exc from None

        return wrapper  # type: ignore[return-value]

    return decorator


def rate_limited(
    max_attempts: int = 5, window: int = 300, key_func: Callable[..., str] | None = None
) -> Callable[[F], F]:
    rl = RateLimiter(max_attempts=max_attempts, window=window)

    def decorator(func: F) -> F:
        @functools.wraps(func)
        def wrapper(*args: Any, **kwargs: Any) -> Any:
            key = key_func(*args, **kwargs) if key_func else "default"
            if not rl.check(key):
                raise SecurityError("rate limited")
            try:
                return func(*args, **kwargs)
            except Exception:
                rl.fail(key)
                raise

        return wrapper  # type: ignore[return-value]

    return decorator


def timed(func: F) -> F:
    @functools.wraps(func)
    def wrapper(*args: Any, **kwargs: Any) -> Any:
        start = time.perf_counter()
        result = func(*args, **kwargs)
        elapsed = time.perf_counter() - start
        print(f"[timed] {func.__name__}: {elapsed:.4f}s")
        return result

    return wrapper  # type: ignore[return-value]
