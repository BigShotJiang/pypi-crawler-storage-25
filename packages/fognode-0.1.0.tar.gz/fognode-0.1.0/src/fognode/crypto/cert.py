from __future__ import annotations

import base64
import datetime
import ssl
from pathlib import Path
from typing import Any

from cryptography import x509
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import rsa
from cryptography.x509.oid import NameOID

from fognode.types.constants import CERT_VALIDITY_DAYS, RSA_KEY_SIZE

_CERT_FILE: Path = Path("fognode_cert.pem")
_KEY_FILE: Path = Path("fognode_key.pem")

_CIPHERS = (
    "ECDHE-ECDSA-AES256-GCM-SHA384:"
    "ECDHE-RSA-AES256-GCM-SHA384:"
    "ECDHE-ECDSA-CHACHA20-POLY1305:"
    "ECDHE-RSA-CHACHA20-POLY1305"
)


def cert_paths() -> tuple[Path, Path]:
    return _CERT_FILE, _KEY_FILE


def generate_cert(cn: str) -> None:
    key = rsa.generate_private_key(public_exponent=65537, key_size=RSA_KEY_SIZE)
    name = x509.Name(
        [
            x509.NameAttribute(NameOID.COMMON_NAME, cn),
            x509.NameAttribute(NameOID.ORGANIZATION_NAME, "fognode"),
            x509.NameAttribute(NameOID.ORGANIZATIONAL_UNIT_NAME, "fognode_v1"),
        ]
    )
    now = datetime.datetime.now(datetime.timezone.utc)
    cert = (
        x509.CertificateBuilder()
        .subject_name(name)
        .issuer_name(name)
        .public_key(key.public_key())
        .serial_number(x509.random_serial_number())
        .not_valid_before(now)
        .not_valid_after(now + datetime.timedelta(days=CERT_VALIDITY_DAYS))
        .add_extension(x509.SubjectAlternativeName([x509.DNSName(cn)]), critical=False)
        .add_extension(
            x509.BasicConstraints(ca=False, path_length=None),
            critical=True,
        )
        .add_extension(
            x509.KeyUsage(
                digital_signature=True,
                key_encipherment=True,
                content_commitment=False,
                data_encipherment=False,
                key_agreement=False,
                key_cert_sign=False,
                crl_sign=False,
                encipher_only=False,
                decipher_only=False,
            ),
            critical=True,
        )
        .sign(key, hashes.SHA256())
    )
    _CERT_FILE.write_bytes(cert.public_bytes(serialization.Encoding.PEM))
    _KEY_FILE.write_bytes(
        key.private_bytes(
            serialization.Encoding.PEM,
            serialization.PrivateFormat.TraditionalOpenSSL,
            serialization.NoEncryption(),
        )
    )
    _KEY_FILE.chmod(0o600)


def _pem_to_der(pem: bytes) -> bytes:
    lines = [line for line in pem.split(b"\n") if line and not line.startswith(b"-----")]
    return base64.b64decode(b"".join(lines))


def cert_fingerprint(source: Path | bytes) -> str:
    der = _pem_to_der(source.read_bytes()) if isinstance(source, Path) else source
    d = hashes.Hash(hashes.SHA256())
    d.update(der)
    h = d.finalize().hex().upper()
    return ":".join(h[i : i + 2] for i in range(0, len(h), 2))


def cert_info(source: Path) -> dict[str, Any]:
    cert = x509.load_pem_x509_certificate(source.read_bytes())
    subject = cert.subject
    issuer = cert.issuer

    san_list: list[str] = []
    try:
        san_ext = cert.extensions.get_extension_for_class(x509.SubjectAlternativeName)
        san_list = [str(v) for v in san_ext.value]
    except Exception:
        pass

    key_size: int | None = None
    pub = cert.public_key()
    if hasattr(pub, "key_size"):
        key_size = pub.key_size  # type: ignore[union-attr]

    return {
        "subject_cn": _attr_value(subject, NameOID.COMMON_NAME),
        "subject_o": _attr_value(subject, NameOID.ORGANIZATION_NAME),
        "subject_ou": _attr_value(subject, NameOID.ORGANIZATIONAL_UNIT_NAME),
        "issuer_cn": _attr_value(issuer, NameOID.COMMON_NAME),
        "issuer_o": _attr_value(issuer, NameOID.ORGANIZATION_NAME),
        "issuer_ou": _attr_value(issuer, NameOID.ORGANIZATIONAL_UNIT_NAME),
        "serial": str(cert.serial_number),
        "not_before": cert.not_valid_before_utc.isoformat(),
        "not_after": cert.not_valid_after_utc.isoformat(),
        "fingerprint_sha256": cert_fingerprint(source),
        "san": san_list,
        "key_size": key_size,
        "sig_alg": cert.signature_algorithm_oid._name,
        "version": cert.version.name,
    }


def _attr_value(name: x509.Name, oid: x509.ObjectIdentifier) -> str | None:
    attrs = name.get_attributes_for_oid(oid)
    return str(attrs[0].value) if attrs else None


def ssl_server_context() -> ssl.SSLContext:
    ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
    ctx.minimum_version = ssl.TLSVersion.TLSv1_2
    ctx.load_cert_chain(str(_CERT_FILE), str(_KEY_FILE))
    ctx.set_ciphers(_CIPHERS)
    ctx.options |= ssl.OP_SINGLE_DH_USE | ssl.OP_SINGLE_ECDH_USE
    return ctx


def ssl_probe_context() -> ssl.SSLContext:
    ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
    ctx.minimum_version = ssl.TLSVersion.TLSv1_2
    ctx.check_hostname = False
    ctx.verify_mode = ssl.CERT_NONE
    ctx.set_ciphers(_CIPHERS)
    return ctx


def ssl_verified_context(cert_pem: Path, hostname: str) -> ssl.SSLContext:
    ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
    ctx.minimum_version = ssl.TLSVersion.TLSv1_2
    ctx.check_hostname = True
    ctx.verify_mode = ssl.CERT_REQUIRED
    ctx.load_verify_locations(cafile=str(cert_pem))
    ctx.set_ciphers(_CIPHERS)
    return ctx
