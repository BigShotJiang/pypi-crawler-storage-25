from __future__ import annotations

from fognode.crypto.primitives import hkdf_expand


def make_session_key(pbkdf2_key: bytes, token: bytes) -> bytes:
    return hkdf_expand(pbkdf2_key, token, b"fognode_v1_session_key")
