from __future__ import annotations

from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.x25519 import X25519PrivateKey, X25519PublicKey


def x25519_keypair() -> tuple[bytes, X25519PrivateKey]:
    priv = X25519PrivateKey.generate()
    pub = priv.public_key().public_bytes(serialization.Encoding.Raw, serialization.PublicFormat.Raw)
    return pub, priv


def x25519_shared(priv: X25519PrivateKey, peer_pub_bytes: bytes) -> bytes:
    peer = X25519PublicKey.from_public_bytes(peer_pub_bytes)
    return priv.exchange(peer)
