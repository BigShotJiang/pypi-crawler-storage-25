from __future__ import annotations

import os
from pathlib import Path

from fognode.crypto.primitives import pbkdf2
from fognode.types.constants import SALT_LENGTH

PASSWORD_STORE: Path = Path("fognode_passwd.bin")


def store_password(password: str) -> None:
    salt = os.urandom(SALT_LENGTH)
    key = pbkdf2(password, salt)
    PASSWORD_STORE.write_bytes(salt + key)
    PASSWORD_STORE.chmod(0o600)


def load_password_key() -> tuple[bytes, bytes]:
    raw = PASSWORD_STORE.read_bytes()
    return raw[:SALT_LENGTH], raw[SALT_LENGTH:]
