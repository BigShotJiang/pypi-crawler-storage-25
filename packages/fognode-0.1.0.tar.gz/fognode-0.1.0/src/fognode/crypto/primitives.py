from __future__ import annotations

import os

from cryptography.exceptions import InvalidSignature, InvalidTag
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives import hmac as _hmac_prim
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.kdf.hkdf import HKDF
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC

from fognode.types.constants import AESGCM_NONCE_LENGTH, PBKDF2_ITERATIONS
from fognode.types.exceptions import SecurityError


def pbkdf2(password: str | bytes, salt: bytes) -> bytes:
    if isinstance(password, str):
        password = password.encode()
    kdf = PBKDF2HMAC(
        algorithm=hashes.SHA256(),
        length=32,
        salt=salt,
        iterations=PBKDF2_ITERATIONS,
    )
    return kdf.derive(password)


def hmac256(key: bytes, data: bytes) -> bytes:
    h = _hmac_prim.HMAC(key, hashes.SHA256())
    h.update(data)
    return h.finalize()


def hmac256_verify(key: bytes, data: bytes, sig: bytes) -> bool:
    h = _hmac_prim.HMAC(key, hashes.SHA256())
    h.update(data)
    try:
        h.verify(sig)
        return True
    except InvalidSignature:
        return False


def hkdf_expand(ikm: bytes, salt: bytes, info: bytes, length: int = 32) -> bytes:
    return HKDF(
        algorithm=hashes.SHA256(),
        length=length,
        salt=salt,
        info=info,
    ).derive(ikm)


def aes_encrypt(key: bytes, plaintext: bytes, aad: bytes) -> tuple[bytes, bytes]:
    nonce = os.urandom(AESGCM_NONCE_LENGTH)
    ct = AESGCM(key).encrypt(nonce, plaintext, aad)
    return nonce, ct


def aes_decrypt(key: bytes, nonce: bytes, ciphertext: bytes, aad: bytes) -> bytes:
    try:
        return AESGCM(key).decrypt(nonce, ciphertext, aad)
    except InvalidTag:
        raise SecurityError("AESGCM tag invalid") from None
