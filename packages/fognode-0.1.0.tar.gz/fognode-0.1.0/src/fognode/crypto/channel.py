from __future__ import annotations

import base64
import json
import ssl
import struct
import time
from threading import Lock
from typing import Any

from fognode.crypto.primitives import aes_decrypt, aes_encrypt, hmac256, hmac256_verify
from fognode.types.constants import MAX_MESSAGE_SIZE, REPLAY_WINDOW
from fognode.types.exceptions import SecurityError


class SecureChannel:
    def __init__(self, sock: ssl.SSLSocket, enc_key: bytes, mac_key: bytes) -> None:
        self._sock = sock
        self._enc = enc_key
        self._mac = mac_key
        self._send_ctr = 0
        self._recv_ctr = -1
        self._lock = Lock()

    def send(self, msg: dict[str, Any]) -> None:
        payload = json.dumps(msg, ensure_ascii=False).encode()
        with self._lock:
            ctr = self._send_ctr
            self._send_ctr += 1
        ts = int(time.time())
        aad = struct.pack(">QQ", ctr, ts)
        nonce, ct = aes_encrypt(self._enc, payload, aad)
        sig = hmac256(self._mac, aad + nonce + ct)
        frame = json.dumps(
            {
                "c": ctr,
                "t": ts,
                "n": base64.b64encode(nonce).decode(),
                "e": base64.b64encode(ct).decode(),
                "s": sig.hex(),
            }
        ).encode()
        if len(frame) > MAX_MESSAGE_SIZE:
            raise ValueError("message too large")
        self._sock.sendall(struct.pack(">I", len(frame)) + frame)

    def recv(self) -> dict[str, Any]:
        hdr = self._recv_exact(4)
        n = struct.unpack(">I", hdr)[0]
        if n > MAX_MESSAGE_SIZE:
            raise SecurityError(f"frame {n} > limit")
        buf = self._recv_exact(n)
        env = json.loads(buf.decode())
        ctr = int(env["c"])
        ts = int(env["t"])
        sig = bytes.fromhex(env["s"])
        nonce = base64.b64decode(env["n"])
        ct = base64.b64decode(env["e"])
        if ctr <= self._recv_ctr:
            raise SecurityError(f"replay/reorder: ctr={ctr} ≤ {self._recv_ctr}")
        if abs(time.time() - ts) > REPLAY_WINDOW:
            raise SecurityError(f"timestamp drift > {REPLAY_WINDOW}s")
        aad = struct.pack(">QQ", ctr, ts)
        if not hmac256_verify(self._mac, aad + nonce + ct, sig):
            raise SecurityError("HMAC mismatch")
        self._recv_ctr = ctr
        return json.loads(aes_decrypt(self._enc, nonce, ct, aad))

    def _recv_exact(self, n: int) -> bytes:
        buf = b""
        while len(buf) < n:
            c = self._sock.recv(n - len(buf))
            if not c:
                raise ConnectionError("closed")
            buf += c
        return buf

    def close(self) -> None:
        try:
            self._sock.close()
        except Exception:
            pass
