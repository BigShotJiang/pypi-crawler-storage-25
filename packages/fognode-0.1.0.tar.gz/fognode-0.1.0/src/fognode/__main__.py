from __future__ import annotations

from fognode.cli.entrypoint import main

main()
