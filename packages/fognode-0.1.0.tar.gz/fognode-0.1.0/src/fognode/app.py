from __future__ import annotations

import asyncio
import threading
from dataclasses import dataclass
from typing import TYPE_CHECKING, Any, Callable

from fognode.core.client import client_connect
from fognode.core.server import _state, start_server
from fognode.crypto.channel import SecureChannel
from fognode.filters import Command
from fognode.handlers import HandlerObject
from fognode.types.constants import DEFAULT_HOST, DEFAULT_PORT, Cipher
from fognode.types.protocol import ChatMsg

if TYPE_CHECKING:
    from fognode.app import App


@dataclass(slots=True, frozen=True)
class Message:
    type: str
    user: str
    text: str
    ts: float
    raw: dict[str, Any]

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> Message:
        return cls(
            type=data.get("type", ""),
            user=data.get("user", ""),
            text=data.get("text", ""),
            ts=data.get("ts", 0.0),
            raw=data,
        )


@dataclass(slots=True)
class Context:
    app: App
    channel: SecureChannel | None
    user: str
    message: Message | None = None

    async def answer(self, text: str) -> None:
        if self.channel is None:
            raise RuntimeError("no channel available")
        self.channel.send({"type": "chat", "text": text})

    async def send(self, data: dict[str, Any]) -> None:
        if self.channel is None:
            raise RuntimeError("no channel available")
        self.channel.send(data)

    async def reply(self, data: dict[str, Any]) -> None:
        if self.channel is None:
            raise RuntimeError("no channel available")
        self.channel.send(data)


class Router:
    def __init__(self) -> None:
        self._handlers: dict[str, list[HandlerObject]] = {
            "connect": [],
            "disconnect": [],
            "message": [],
        }

    def on_connect(self) -> Callable[..., Any]:
        def decorator(callback: Callable[..., Any]) -> Callable[..., Any]:
            self._handlers["connect"].append(HandlerObject(callback))
            return callback

        return decorator

    def on_disconnect(self) -> Callable[..., Any]:
        def decorator(callback: Callable[..., Any]) -> Callable[..., Any]:
            self._handlers["disconnect"].append(HandlerObject(callback))
            return callback

        return decorator

    def on_message(self, *filters: Any) -> Callable[..., Any]:
        def decorator(callback: Callable[..., Any]) -> Callable[..., Any]:
            self._handlers["message"].append(HandlerObject(callback, list(filters)))
            return callback

        return decorator

    def on_command(self, commands: str | list[str]) -> Callable[..., Any]:
        def decorator(callback: Callable[..., Any]) -> Callable[..., Any]:
            self._handlers["message"].append(HandlerObject(callback, [Command(commands)]))
            return callback

        return decorator

    def include(self, app: App) -> None:
        for event, handlers in self._handlers.items():
            app._handlers[event].extend(handlers)


class App:
    def __init__(
        self,
        host: str = DEFAULT_HOST,
        port: int = DEFAULT_PORT,
        user: str | None = None,
        password: str | None = None,
        cipher: Cipher = Cipher.AESGCM,
        mode: str = "server",
        connect_string: str | None = None,
    ) -> None:
        self.host = host
        self.port = port
        self.user = user
        self.password = password
        self.cipher = cipher
        self.mode = mode
        self.connect_string = connect_string
        self._handlers: dict[str, list[HandlerObject]] = {
            "connect": [],
            "disconnect": [],
            "message": [],
        }
        self._loop: asyncio.AbstractEventLoop | None = None
        self._channel: SecureChannel | None = None

    @classmethod
    def client(
        cls,
        connect_string: str,
        password: str,
        cipher: Cipher = Cipher.AESGCM,
    ) -> App:
        return cls(
            mode="client",
            connect_string=connect_string,
            password=password,
            cipher=cipher,
        )

    def on_connect(self) -> Callable[..., Any]:
        def decorator(callback: Callable[..., Any]) -> Callable[..., Any]:
            self._handlers["connect"].append(HandlerObject(callback))
            return callback

        return decorator

    def on_disconnect(self) -> Callable[..., Any]:
        def decorator(callback: Callable[..., Any]) -> Callable[..., Any]:
            self._handlers["disconnect"].append(HandlerObject(callback))
            return callback

        return decorator

    def on_message(self, *filters: Any) -> Callable[..., Any]:
        def decorator(callback: Callable[..., Any]) -> Callable[..., Any]:
            self._handlers["message"].append(HandlerObject(callback, list(filters)))
            return callback

        return decorator

    def on_command(self, commands: str | list[str]) -> Callable[..., Any]:
        def decorator(callback: Callable[..., Any]) -> Callable[..., Any]:
            self._handlers["message"].append(HandlerObject(callback, [Command(commands)]))
            return callback

        return decorator

    def include_router(self, router: Router) -> None:
        router.include(self)

    def run(self) -> None:
        self._loop = asyncio.new_event_loop()
        asyncio.set_event_loop(self._loop)
        if self.mode == "server":
            self._setup_server()
        else:
            self._setup_client()
        try:
            self._loop.run_forever()
        except KeyboardInterrupt:
            pass
        finally:
            self._loop.close()

    def _setup_server(self) -> None:
        if not self.user or not self.password:
            raise ValueError("user and password required for server mode")

        def _on_connect(user: str) -> None:
            if self._loop is not None:
                self._loop.call_soon_threadsafe(self._process_connect, user)

        def _on_disconnect(user: str) -> None:
            if self._loop is not None:
                self._loop.call_soon_threadsafe(self._process_disconnect, user)

        def _on_msg(msg: ChatMsg) -> None:
            if self._loop is not None:
                self._loop.call_soon_threadsafe(self._process_chat, msg)

        start_server(
            self.host,
            self.port,
            self.user,
            self.password,
            on_connect=_on_connect,
            on_disconnect=_on_disconnect,
        )
        _state.on_message(_on_msg)

    def _setup_client(self) -> None:
        if not self.connect_string or not self.password:
            raise ValueError("connect_string and password required for client mode")

        ch, _fp = client_connect(self.connect_string, self.password)
        self._channel = ch

        welcome = ch.recv()
        if welcome.get("type") == "welcome":
            for m in welcome.get("history", []):
                self._process_raw_msg(ch, m)

        def _recv() -> None:
            while True:
                try:
                    msg = ch.recv()
                    if self._loop is not None:
                        self._loop.call_soon_threadsafe(self._process_raw_msg, ch, msg)
                except Exception:
                    break

        threading.Thread(target=_recv, daemon=True).start()

    def _process_connect(self, user: str) -> None:
        ch = _state.get_channel(user)
        ctx = Context(self, ch, user)
        for handler in self._handlers["connect"]:
            asyncio.create_task(handler.call(ctx))

    def _process_disconnect(self, user: str) -> None:
        ch = _state.get_channel(user)
        ctx = Context(self, ch, user)
        for handler in self._handlers["disconnect"]:
            asyncio.create_task(handler.call(ctx))

    def _process_chat(self, m: ChatMsg) -> None:
        ch = _state.get_channel(m.user)
        if ch is None:
            return
        msg = Message.from_dict(m.as_dict())
        ctx = Context(self, ch, m.user, msg)
        for handler in self._handlers["message"]:
            asyncio.create_task(self._run_handler(handler, msg.raw, ctx))

    def _process_raw_msg(self, ch: SecureChannel, msg: dict[str, Any]) -> None:
        mtype = msg.get("type", "")
        if mtype == "chat":
            message = Message.from_dict(msg)
            ctx = Context(self, ch, msg.get("user", ""), message)
            for handler in self._handlers["message"]:
                asyncio.create_task(self._run_handler(handler, msg, ctx))

    async def _run_handler(
        self, handler: HandlerObject, data: dict[str, Any], ctx: Context
    ) -> None:
        if await handler.check(data):
            await handler.call(ctx)
