from __future__ import annotations

import time
from threading import Lock

from fognode.types.constants import RATE_LIMIT_MAX_ATTEMPTS, RATE_LIMIT_WINDOW


class RateLimiter:
    def __init__(
        self, max_attempts: int = RATE_LIMIT_MAX_ATTEMPTS, window: int = RATE_LIMIT_WINDOW
    ) -> None:
        self._lock = Lock()
        self._attempts: dict[str, list[float]] = {}
        self._blocked: dict[str, float] = {}
        self.max_attempts = max_attempts
        self.window = window

    def check(self, ip: str) -> bool:
        now = time.time()
        with self._lock:
            if ip in self._blocked:
                if now - self._blocked[ip] < self.window:
                    return False
                del self._blocked[ip]
                self._attempts.pop(ip, None)
            alive = [t for t in self._attempts.get(ip, []) if now - t < self.window]
            self._attempts[ip] = alive
            return len(alive) < self.max_attempts

    def fail(self, ip: str) -> None:
        now = time.time()
        with self._lock:
            a = self._attempts.get(ip, [])
            a.append(now)
            self._attempts[ip] = a
            if len(a) >= self.max_attempts:
                self._blocked[ip] = now

    def ok(self, ip: str) -> None:
        with self._lock:
            self._attempts.pop(ip, None)
            self._blocked.pop(ip, None)
