from __future__ import annotations

from fognode.cli.entrypoint import main

__all__ = ["main"]
