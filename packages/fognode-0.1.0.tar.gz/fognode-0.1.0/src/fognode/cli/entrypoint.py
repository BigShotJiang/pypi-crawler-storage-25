from __future__ import annotations

import argparse
import getpass
import json
import os
import signal
import sys
import threading
import time
from typing import Any

from fognode.core.client import client_connect
from fognode.core.probe import probe_server
from fognode.core.server import _state, start_server
from fognode.crypto.cert import cert_info, cert_paths
from fognode.types.constants import DEFAULT_HOST, DEFAULT_PORT
from fognode.types.exceptions import AuthError, SecurityError
from fognode.types.protocol import ChatMsg


def _ts() -> str:
    return time.strftime("%H:%M:%S")


def _banner(title: str) -> None:
    print("═" * 60)
    print(f"  {title}")
    print("═" * 60)


def _kv(key: str, val: str | int | float | None) -> None:
    print(f"  {key:<20} {val}")


def _json_or_print(data: dict[str, Any], use_json: bool) -> None:
    if use_json:
        print(json.dumps(data, indent=2, default=str))
    else:
        for k, v in data.items():
            _kv(str(k), v)


def cmd_server(args: argparse.Namespace) -> None:
    verbose: bool = args.verbose
    username: str | None = args.user or os.environ.get("FOGNODE_USER")
    password: str | None = args.password or os.environ.get("FOGNODE_PASSWORD")

    if not username:
        username = input("Username: ").strip()
    if not username:
        sys.exit("username required")
    if not password:
        password = getpass.getpass("Password: ")
        confirm = getpass.getpass("Confirm: ")
        if password != confirm:
            sys.exit("passwords do not match")

    on_connect = None
    on_disconnect = None
    if verbose:

        def _on_connect(user: str) -> None:
            print(f"  [{_ts()}] + {user} connected")

        def _on_disconnect(user: str) -> None:
            print(f"  [{_ts()}] - {user} disconnected")

        on_connect = _on_connect
        on_disconnect = _on_disconnect

    t0 = time.perf_counter()
    display_ip, code_name, fp = start_server(
        args.host,
        args.port,
        username,
        password,
        on_connect=on_connect,
        on_disconnect=on_disconnect,
    )
    t1 = time.perf_counter()

    cert_file, _key_file = cert_paths()
    cinfo = cert_info(cert_file)

    _banner("fognode server")
    _kv("mode", "server")
    _kv("host", args.host)
    _kv("port", args.port)
    _kv("display_ip", display_ip)
    _kv("code_name", code_name)
    _kv("startup_ms", f"{(t1 - t0) * 1000:.1f}")
    print()
    _kv("cert_cn", cinfo.get("subject_cn"))
    _kv("cert_o", cinfo.get("subject_o"))
    _kv("cert_ou", cinfo.get("subject_ou"))
    _kv("cert_issuer_cn", cinfo.get("issuer_cn"))
    _kv("cert_issuer_o", cinfo.get("issuer_o"))
    _kv("cert_issuer_ou", cinfo.get("issuer_ou"))
    _kv("cert_serial", cinfo.get("serial"))
    _kv("cert_not_before", cinfo.get("not_before"))
    _kv("cert_not_after", cinfo.get("not_after"))
    _kv("cert_fp_sha256", cinfo.get("fingerprint_sha256"))
    _kv("cert_san", ", ".join(cinfo.get("san", [])))
    _kv("cert_key_size", cinfo.get("key_size"))
    _kv("cert_sig_alg", cinfo.get("sig_alg"))
    _kv("cert_version", cinfo.get("version"))
    print()
    _kv("connect_string", f"{username}@{code_name}:{args.port}")
    print("═" * 60)

    def _on_msg(msg: ChatMsg) -> None:
        print(f"  [{_ts()}] {msg.user}: {msg.text}")

    _state.on_message(_on_msg)

    try:
        signal.pause()
    except (KeyboardInterrupt, AttributeError):
        pass


def cmd_client(args: argparse.Namespace) -> None:
    verbose: bool = args.verbose
    password: str | None = args.password or os.environ.get("FOGNODE_PASSWORD")
    if not password:
        password = getpass.getpass("Password: ")

    print(f"[*] connecting to {args.connect}...")
    t0 = time.perf_counter()

    try:
        ch, fp = client_connect(args.connect, password)
        t1 = time.perf_counter()
    except (SecurityError, AuthError, ConnectionError) as e:
        sys.exit(f"[!] {e}")

    tls_ver = ch._sock.version() or "unknown"
    cipher = ch._sock.cipher() or ["?", "?", 0]

    _banner("fognode client")
    _kv("mode", "client")
    _kv("target", args.connect)
    _kv("fp", fp)
    _kv("tls_version", tls_ver)
    _kv("cipher", cipher[0])
    _kv("cipher_bits", cipher[2])
    _kv("channel", "AESGCM-256 + HMAC-SHA256")
    _kv("kex", "X25519 + HKDF")
    _kv("connect_ms", f"{(t1 - t0) * 1000:.1f}")
    print("═" * 60)

    welcome = ch.recv()
    if welcome.get("type") == "welcome":
        print(f"[+] online: {', '.join(welcome.get('online', []))}")
        if verbose:
            print(f"[+] history: {len(welcome.get('history', []))} messages")

    def _recv() -> None:
        while True:
            try:
                msg = ch.recv()
                mtype = msg.get("type", "")
                if mtype == "chat":
                    ts = time.strftime("%H:%M", time.localtime(msg.get("ts", 0)))
                    print(f"\r  [{ts}] {msg['user']}: {msg['text']}")
                elif mtype == "pong" and verbose:
                    print(f"  [pong] ts={msg.get('ts', 0):.3f}")
                elif mtype == "info" and verbose:
                    print(f"  [info] users={len(msg.get('online', []))} msgs={msg.get('msgs')}")
                elif mtype == "users" and verbose:
                    print(f"  [users] {', '.join(msg.get('online', []))}")
                elif mtype == "bye":
                    print("  [server closed session]")
                    break
            except Exception:
                print("[!] connection lost")
                break

    threading.Thread(target=_recv, daemon=True).start()

    try:
        while True:
            line = input("> ").strip()
            if not line:
                continue
            if line.startswith("/"):
                cmd = line[1:].strip()
                if cmd in ("quit", "q", "exit"):
                    ch.send({"type": "cmd", "cmd": "quit"})
                    break
                elif cmd == "ping":
                    ch.send({"type": "cmd", "cmd": "ping"})
                elif cmd == "info":
                    ch.send({"type": "cmd", "cmd": "info"})
                elif cmd.startswith("history"):
                    parts = cmd.split()
                    n = int(parts[1]) if len(parts) > 1 else 50
                    ch.send({"type": "cmd", "cmd": "history", "n": n})
                elif cmd == "users":
                    ch.send({"type": "cmd", "cmd": "users"})
                else:
                    print(f"[!] unknown command: /{cmd}")
            else:
                ch.send({"type": "chat", "text": line})
    except KeyboardInterrupt:
        pass
    finally:
        ch.close()


def cmd_cert(args: argparse.Namespace) -> None:
    from pathlib import Path

    p = Path(args.file)
    if not p.exists():
        sys.exit(f"[!] cert not found: {p}")
    info = cert_info(p)
    _banner(f"certificate {p.name}")
    _json_or_print(info, args.json)
    print("═" * 60)


def cmd_probe(args: argparse.Namespace) -> None:
    info = probe_server(args.connect)
    _banner(f"probe {args.connect}")
    _json_or_print(info, args.json)
    print("═" * 60)


def cmd_status(args: argparse.Namespace) -> None:
    password: str | None = args.password or os.environ.get("FOGNODE_PASSWORD")
    if not password:
        password = getpass.getpass("Password: ")

    try:
        ch, fp = client_connect(args.connect, password)
    except (SecurityError, AuthError, ConnectionError) as e:
        sys.exit(f"[!] {e}")

    tls_ver = ch._sock.version() or "unknown"
    cipher = ch._sock.cipher() or ["?", "?", 0]

    ch.send({"type": "cmd", "cmd": "info"})
    info_msg = ch.recv()
    ch.send({"type": "cmd", "cmd": "users"})
    users_msg = ch.recv()
    ch.send({"type": "cmd", "cmd": "quit"})
    ch.close()

    data = {
        "target": args.connect,
        "fp": fp,
        "tls_version": tls_ver,
        "cipher": cipher[0],
        "cipher_bits": cipher[2],
        "server": info_msg.get("server"),
        "time": info_msg.get("time"),
        "message_count": info_msg.get("msgs"),
        "users_online": users_msg.get("online", []),
    }

    _banner(f"status {args.connect}")
    _json_or_print(data, args.json)
    print("═" * 60)


def cmd_send(args: argparse.Namespace) -> None:
    password: str | None = args.password or os.environ.get("FOGNODE_PASSWORD")
    if not password:
        password = getpass.getpass("Password: ")

    try:
        ch, _fp = client_connect(args.connect, password)
    except (SecurityError, AuthError, ConnectionError) as e:
        sys.exit(f"[!] {e}")

    welcome = ch.recv()
    if welcome.get("type") == "welcome":
        print(f"[+] online: {', '.join(welcome.get('online', []))}")

    ch.send({"type": "chat", "text": args.text})
    time.sleep(0.5)
    ch.close()
    print("[+] sent")


def cmd_monitor(args: argparse.Namespace) -> None:
    password: str | None = args.password or os.environ.get("FOGNODE_PASSWORD")
    if not password:
        password = getpass.getpass("Password: ")

    try:
        ch, fp = client_connect(args.connect, password)
    except (SecurityError, AuthError, ConnectionError) as e:
        sys.exit(f"[!] {e}")

    tls_ver = ch._sock.version() or "unknown"
    cipher = ch._sock.cipher() or ["?", "?", 0]

    _banner("fognode monitor")
    _kv("target", args.connect)
    _kv("fp", fp)
    _kv("tls_version", tls_ver)
    _kv("cipher", cipher[0])
    _kv("cipher_bits", cipher[2])
    print("═" * 60)

    def _recv() -> None:
        while True:
            try:
                msg = ch.recv()
                mtype = msg.get("type", "")
                if args.json:
                    print(json.dumps(msg, indent=None, default=str))
                else:
                    if mtype == "chat":
                        ts = time.strftime("%H:%M:%S", time.localtime(msg.get("ts", 0)))
                        print(f"[{ts}] {msg['user']}: {msg['text']}")
                    elif mtype == "pong":
                        print(f"[pong] ts={msg.get('ts', 0):.3f}")
                    elif mtype == "info":
                        print(f"[info] users={len(msg.get('online', []))} msgs={msg.get('msgs')}")
                    elif mtype == "users":
                        print(f"[users] {', '.join(msg.get('online', []))}")
                    elif mtype == "bye":
                        print("[server closed session]")
                        break
            except Exception:
                print("[!] connection lost")
                break

    threading.Thread(target=_recv, daemon=True).start()

    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        pass
    finally:
        ch.close()


def main() -> None:
    ap = argparse.ArgumentParser(
        prog="fognode",
        description="fognode admin tool",
    )
    sub = ap.add_subparsers(dest="cmd", required=True)

    p_server = sub.add_parser("server", help="Run server")
    p_server.add_argument("--host", default=DEFAULT_HOST)
    p_server.add_argument("--port", type=int, default=DEFAULT_PORT)
    p_server.add_argument("--user", default=None)
    p_server.add_argument("--password", default=None)
    p_server.add_argument("-v", "--verbose", action="store_true")
    p_server.set_defaults(func=cmd_server)

    p_client = sub.add_parser("client", help="Run interactive client")
    p_client.add_argument("connect", help="user@code:port")
    p_client.add_argument("--password", default=None)
    p_client.add_argument("-v", "--verbose", action="store_true")
    p_client.set_defaults(func=cmd_client)

    p_cert = sub.add_parser("cert", help="Show certificate info")
    p_cert.add_argument("--file", default="fognode_cert.pem")
    p_cert.add_argument("--json", action="store_true")
    p_cert.set_defaults(func=cmd_cert)

    p_probe = sub.add_parser("probe", help="Probe server TLS without auth")
    p_probe.add_argument("connect", help="user@code:port")
    p_probe.add_argument("--json", action="store_true")
    p_probe.set_defaults(func=cmd_probe)

    p_status = sub.add_parser("status", help="Server status via auth channel")
    p_status.add_argument("connect", help="user@code:port")
    p_status.add_argument("--password", default=None)
    p_status.add_argument("--json", action="store_true")
    p_status.set_defaults(func=cmd_status)

    p_send = sub.add_parser("send", help="Send message and exit")
    p_send.add_argument("connect", help="user@code:port")
    p_send.add_argument("--password", default=None)
    p_send.add_argument("--text", required=True)
    p_send.set_defaults(func=cmd_send)

    p_monitor = sub.add_parser("monitor", help="Monitor messages only")
    p_monitor.add_argument("connect", help="user@code:port")
    p_monitor.add_argument("--password", default=None)
    p_monitor.add_argument("--json", action="store_true")
    p_monitor.set_defaults(func=cmd_monitor)

    args = ap.parse_args()
    args.func(args)


if __name__ == "__main__":
    main()
