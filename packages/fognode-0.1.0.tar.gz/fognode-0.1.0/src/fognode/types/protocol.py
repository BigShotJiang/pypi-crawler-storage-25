from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Callable, Protocol, TypedDict

User = str
Password = str
IPAddress = str
CodeName = str
Fingerprint = str
ConnectString = str
Port = int
Bytes32 = bytes


class ChallengeMsg(TypedDict):
    type: str
    nonce: str
    salt: str
    fp: str
    ecdh_pub: str
    ver: str


class ResponseMsg(TypedDict):
    user: str
    hmac_resp: str
    cert_fp: str
    ecdh_pub: str


class AuthResult(TypedDict):
    ok: bool
    error: str | None
    token: str | None


class ChatMsgDict(TypedDict):
    type: str
    ts: float
    user: str
    text: str


class CmdMsg(TypedDict):
    type: str
    cmd: str
    n: int | None


class WelcomeMsg(TypedDict):
    type: str
    user: str
    online: list[str]
    history: list[ChatMsgDict]


class InfoMsg(TypedDict):
    type: str
    server: str
    user: str
    online: list[str]
    msgs: int
    time: str
    tls: str | None
    cipher: str


class PongMsg(TypedDict):
    type: str
    ts: float


class HistoryMsg(TypedDict):
    type: str
    messages: list[ChatMsgDict]


class UsersMsg(TypedDict):
    type: str
    online: list[str]


class ByeMsg(TypedDict):
    type: str


@dataclass(slots=True, frozen=True)
class ServerInfo:
    name: str
    version: str
    tls_version: str | None
    cipher: str
    timestamp: str


@dataclass(slots=True, frozen=True)
class ConnectionInfo:
    ip: IPAddress
    port: Port
    user: User
    fingerprint: Fingerprint
    code_name: CodeName


@dataclass(slots=True)
class ChatMsg:
    ts: float
    user: User
    text: str

    def as_dict(self) -> dict[str, Any]:
        return {"type": "chat", "ts": self.ts, "user": self.user, "text": self.text}


class OnConnect(Protocol):
    def __call__(self, user: User) -> None: ...


class OnDisconnect(Protocol):
    def __call__(self, user: User) -> None: ...


class OnMessage(Protocol):
    def __call__(self, msg: ChatMsg) -> None: ...


MessageHandler = Callable[[dict[str, Any]], None]
