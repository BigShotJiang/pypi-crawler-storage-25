from __future__ import annotations


class SecurityError(Exception):
    pass


class AuthError(Exception):
    pass


class WireError(Exception):
    pass


class HandshakeError(Exception):
    pass


class CertError(Exception):
    pass


class FrameError(Exception):
    pass
