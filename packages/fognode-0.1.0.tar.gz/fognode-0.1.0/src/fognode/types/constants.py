from __future__ import annotations

from enum import Enum


class Cipher(Enum):
    AESGCM = "aesgcm"
    CHACHA20 = "chacha20"


DEFAULT_PORT: int = 9443
DEFAULT_HOST: str = "0.0.0.0"
MAX_MESSAGE_SIZE: int = 64 * 1024
REPLAY_WINDOW: int = 30
PBKDF2_ITERATIONS: int = 390_000
SALT_LENGTH: int = 32
NONCE_LENGTH: int = 32
TOKEN_LENGTH: int = 32
AESGCM_NONCE_LENGTH: int = 12
CERT_VALIDITY_DAYS: int = 365
RSA_KEY_SIZE: int = 4096
RATE_LIMIT_MAX_ATTEMPTS: int = 5
RATE_LIMIT_WINDOW: int = 300
CHAT_HISTORY_LIMIT: int = 500
CHAT_MAX_TEXT_LENGTH: int = 2000
