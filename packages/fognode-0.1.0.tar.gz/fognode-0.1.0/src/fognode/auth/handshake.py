from __future__ import annotations

import base64
import os
import ssl

from fognode.crypto.cert import cert_fingerprint, cert_paths
from fognode.crypto.channel import SecureChannel
from fognode.crypto.kx import x25519_keypair, x25519_shared
from fognode.crypto.password import load_password_key
from fognode.crypto.primitives import hkdf_expand, hmac256, hmac256_verify, pbkdf2
from fognode.types.constants import NONCE_LENGTH, TOKEN_LENGTH
from fognode.types.exceptions import AuthError, SecurityError
from fognode.types.protocol import IPAddress, User
from fognode.utils.ratelimit import RateLimiter
from fognode.wire.framing import wire_recv, wire_send

_rl = RateLimiter()


def server_handshake(
    tls: ssl.SSLSocket, client_ip: IPAddress, expected_user: User
) -> SecureChannel:
    salt, stored_key = load_password_key()
    server_fp = cert_fingerprint(cert_paths()[0])
    nonce = os.urandom(NONCE_LENGTH)
    sv_pub, sv_priv = x25519_keypair()

    wire_send(
        tls,
        {
            "type": "challenge",
            "nonce": nonce.hex(),
            "salt": salt.hex(),
            "fp": server_fp,
            "ecdh_pub": base64.b64encode(sv_pub).decode(),
            "ver": "1",
        },
    )

    resp = wire_recv(tls)
    client_user = resp.get("user", "")
    hmac_resp = bytes.fromhex(resp.get("hmac_resp", ""))
    client_fp = resp.get("cert_fp", "")
    cl_pub = base64.b64decode(resp.get("ecdh_pub", ""))

    if client_fp.upper() != server_fp.upper():
        wire_send(tls, {"ok": False, "error": "fp_mismatch"})
        raise AuthError("fp mismatch")

    if client_user.encode() != expected_user.encode():
        wire_send(tls, {"ok": False, "error": "bad_user"})
        raise AuthError("bad user")

    if not hmac256_verify(nonce, stored_key, hmac_resp):
        wire_send(tls, {"ok": False, "error": "bad_password"})
        raise AuthError("bad password")

    session_token = os.urandom(TOKEN_LENGTH)
    shared = x25519_shared(sv_priv, cl_pub)
    key_material = hkdf_expand(shared, session_token, b"fognode_v1_channel_keys", length=64)
    enc_key, mac_key = key_material[:32], key_material[32:]

    wire_send(tls, {"ok": True, "token": session_token.hex()})
    _rl.ok(client_ip)
    return SecureChannel(tls, enc_key, mac_key)


def client_handshake(
    tls: ssl.SSLSocket, username: User, password: str, measured_fp: str
) -> SecureChannel:
    chal = wire_recv(tls)
    if chal.get("type") != "challenge":
        raise ConnectionError("expected challenge")

    nonce = bytes.fromhex(chal["nonce"])
    salt = bytes.fromhex(chal["salt"])
    server_fp = chal.get("fp", "")
    sv_pub = base64.b64decode(chal.get("ecdh_pub", ""))

    if measured_fp.upper() != server_fp.upper():
        raise SecurityError("fingerprint mismatch")

    key = pbkdf2(password, salt)
    hmac_resp = hmac256(nonce, key)
    cl_pub, cl_priv = x25519_keypair()

    wire_send(
        tls,
        {
            "user": username,
            "hmac_resp": hmac_resp.hex(),
            "cert_fp": measured_fp,
            "ecdh_pub": base64.b64encode(cl_pub).decode(),
        },
    )

    result = wire_recv(tls)
    if not result.get("ok"):
        raise AuthError(f"auth rejected: {result.get('error')}")

    session_token = bytes.fromhex(result["token"])
    shared = x25519_shared(cl_priv, sv_pub)
    key_material = hkdf_expand(shared, session_token, b"fognode_v1_channel_keys", length=64)
    enc_key, mac_key = key_material[:32], key_material[32:]

    return SecureChannel(tls, enc_key, mac_key)
