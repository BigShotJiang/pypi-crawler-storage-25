from __future__ import annotations

from fognode.filters.base import BaseFilter


class Text(BaseFilter):
    def __init__(self, text: str | list[str]) -> None:
        self.texts = [text] if isinstance(text, str) else list(text)

    async def __call__(self, data: dict) -> bool:  # type: ignore[type-arg]
        return data.get("text", "") in self.texts
