from __future__ import annotations

from typing import Any


class BaseFilter:
    async def __call__(self, data: dict[str, Any]) -> bool:
        return True
