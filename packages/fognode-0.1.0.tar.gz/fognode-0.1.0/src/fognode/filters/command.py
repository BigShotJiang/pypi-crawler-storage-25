from __future__ import annotations

from fognode.filters.base import BaseFilter


class Command(BaseFilter):
    def __init__(self, commands: str | list[str]) -> None:
        self.commands = [commands] if isinstance(commands, str) else list(commands)

    async def __call__(self, data: dict) -> bool:  # type: ignore[type-arg]
        text = data.get("text", "")
        if not isinstance(text, str) or not text.startswith("/"):
            return False
        cmd = text[1:].split()[0]
        return cmd in self.commands
