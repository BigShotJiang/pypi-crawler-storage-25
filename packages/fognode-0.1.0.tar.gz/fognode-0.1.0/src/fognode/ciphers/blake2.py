from __future__ import annotations

import hashlib


def blake2b(data: bytes, key: bytes = b"") -> bytes:
    return hashlib.blake2b(data, key=key).digest()


def blake2s(data: bytes, key: bytes = b"") -> bytes:
    return hashlib.blake2s(data, key=key).digest()


__all__ = ["blake2b", "blake2s"]
