from __future__ import annotations

from fognode.crypto.primitives import hkdf_expand

__all__ = ["hkdf_expand"]
