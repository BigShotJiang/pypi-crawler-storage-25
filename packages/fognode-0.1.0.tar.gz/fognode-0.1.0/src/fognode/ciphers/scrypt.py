from __future__ import annotations

from cryptography.hazmat.primitives.kdf.scrypt import Scrypt


def scrypt_kdf(
    password: str | bytes, salt: bytes, length: int = 32, n: int = 2**14, r: int = 8, p: int = 1
) -> bytes:
    if isinstance(password, str):
        password = password.encode()
    kdf = Scrypt(salt=salt, length=length, n=n, r=r, p=p)
    return kdf.derive(password)


__all__ = ["scrypt_kdf"]
