from __future__ import annotations

import hashlib


def sha3_256(data: bytes) -> bytes:
    return hashlib.sha3_256(data).digest()


def sha3_512(data: bytes) -> bytes:
    return hashlib.sha3_512(data).digest()


def sha512(data: bytes) -> bytes:
    return hashlib.sha512(data).digest()


__all__ = ["sha3_256", "sha3_512", "sha512"]
