from __future__ import annotations

import os

from cryptography.hazmat.primitives.ciphers import Cipher as _Cipher
from cryptography.hazmat.primitives.ciphers import algorithms, modes

from fognode.types.exceptions import SecurityError


def blowfish_encrypt(key: bytes, plaintext: bytes) -> tuple[bytes, bytes]:
    iv = os.urandom(8)
    cipher = _Cipher(algorithms.Blowfish(key), modes.CBC(iv))
    encryptor = cipher.encryptor()
    pad_len = 8 - (len(plaintext) % 8)
    padded = plaintext + bytes([pad_len] * pad_len)
    ct = encryptor.update(padded) + encryptor.finalize()
    return iv, ct


def blowfish_decrypt(key: bytes, iv: bytes, ciphertext: bytes) -> bytes:
    try:
        cipher = _Cipher(algorithms.Blowfish(key), modes.CBC(iv))
        decryptor = cipher.decryptor()
        padded = decryptor.update(ciphertext) + decryptor.finalize()
        pad_len = padded[-1]
        return padded[:-pad_len]
    except Exception:
        raise SecurityError("blowfish decrypt failed") from None


__all__ = ["blowfish_decrypt", "blowfish_encrypt"]
