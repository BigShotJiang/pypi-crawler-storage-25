from __future__ import annotations

from cryptography.fernet import Fernet, InvalidToken

from fognode.types.exceptions import SecurityError


def fernet_generate_key() -> bytes:
    return Fernet.generate_key()


def fernet_encrypt(key: bytes, plaintext: bytes) -> bytes:
    return Fernet(key).encrypt(plaintext)


def fernet_decrypt(key: bytes, ciphertext: bytes) -> bytes:
    try:
        return Fernet(key).decrypt(ciphertext)
    except InvalidToken:
        raise SecurityError("fernet token invalid") from None


__all__ = ["fernet_decrypt", "fernet_encrypt", "fernet_generate_key"]
