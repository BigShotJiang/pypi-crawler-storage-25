from __future__ import annotations

from fognode.handlers.handler import HandlerObject

__all__ = ["HandlerObject"]
