from __future__ import annotations

import asyncio
from typing import TYPE_CHECKING, Any, Callable

from fognode.filters.base import BaseFilter

if TYPE_CHECKING:
    from fognode.app import Context


async def _check_filter(filter_obj: Any, data: dict[str, Any]) -> bool:
    if asyncio.iscoroutinefunction(filter_obj):
        return await filter_obj(data)
    if isinstance(filter_obj, BaseFilter):
        return await filter_obj(data)
    if callable(filter_obj):
        return bool(filter_obj(data))
    return True


class HandlerObject:
    def __init__(self, callback: Callable[..., Any], filters: list[Any] | None = None) -> None:
        self.callback = callback
        self.filters = filters or []

    async def check(self, data: dict[str, Any]) -> bool:
        for f in self.filters:
            if not await _check_filter(f, data):
                return False
        return True

    async def call(self, ctx: Context) -> Any:
        if asyncio.iscoroutinefunction(self.callback):
            return await self.callback(ctx)
        return self.callback(ctx)
