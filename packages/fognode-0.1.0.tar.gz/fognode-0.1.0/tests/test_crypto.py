from __future__ import annotations

from fognode.crypto.password import load_password_key, store_password
from fognode.crypto.primitives import (
    aes_decrypt,
    aes_encrypt,
    hkdf_expand,
    hmac256,
    hmac256_verify,
    pbkdf2,
)


class TestCrypto:
    def test_pbkdf2(self) -> None:
        salt = b"0" * 32
        key1 = pbkdf2("pass", salt)
        key2 = pbkdf2("pass", salt)
        assert key1 == key2
        assert len(key1) == 32

    def test_hmac(self) -> None:
        key = b"k" * 32
        data = b"hello"
        sig = hmac256(key, data)
        assert hmac256_verify(key, data, sig)
        assert not hmac256_verify(key, b"other", sig)

    def test_hkdf(self) -> None:
        key = hkdf_expand(b"ikm", b"salt", b"info", 64)
        assert len(key) == 64

    def test_aes(self) -> None:
        key = b"k" * 32
        plaintext = b"secret"
        aad = b"aad"
        nonce, ct = aes_encrypt(key, plaintext, aad)
        assert aes_decrypt(key, nonce, ct, aad) == plaintext

    def test_password_store(self, tmp_path, password: str) -> None:
        from fognode.crypto import password as pwd

        old = pwd.PASSWORD_STORE
        try:
            pwd.PASSWORD_STORE = tmp_path / "test_passwd.bin"
            store_password(password)
            salt, key = load_password_key()
            assert len(salt) == 32
            assert len(key) == 32
            assert key == pbkdf2(password, salt)
        finally:
            pwd.PASSWORD_STORE = old
