from __future__ import annotations

import pytest


@pytest.fixture
def password() -> str:
    return "test-password-123"
