from __future__ import annotations

import json
import struct

from fognode.wire.framing import wire_recv, wire_send


class MockSocket:
    def __init__(self, data: bytes = b"") -> None:
        self._rx = data
        self._tx = bytearray()

    def recv(self, n: int) -> bytes:
        chunk = self._rx[:n]
        self._rx = self._rx[n:]
        return chunk

    def sendall(self, data: bytes) -> None:
        self._tx.extend(data)

    def get_sent(self) -> bytes:
        return bytes(self._tx)


class TestFraming:
    def test_wire_send(self) -> None:
        sock = MockSocket()
        wire_send(sock, {"type": "ping"})  # type: ignore[arg-type]
        data = sock.get_sent()
        n = struct.unpack(">I", data[:4])[0]
        assert json.loads(data[4:].decode()) == {"type": "ping"}
        assert len(data[4:]) == n

    def test_wire_recv(self) -> None:
        raw = json.dumps({"type": "pong"}).encode()
        frame = struct.pack(">I", len(raw)) + raw
        sock = MockSocket(frame)
        msg = wire_recv(sock)  # type: ignore[arg-type]
        assert msg == {"type": "pong"}
