from __future__ import annotations

from fognode.utils.ratelimit import RateLimiter


class TestRateLimiter:
    def test_allow_under_limit(self) -> None:
        rl = RateLimiter(max_attempts=3, window=60)
        assert rl.check("1.2.3.4")
        assert rl.check("1.2.3.4")
        assert rl.check("1.2.3.4")

    def test_block_over_limit(self) -> None:
        rl = RateLimiter(max_attempts=2, window=60)
        rl.fail("1.2.3.4")
        rl.fail("1.2.3.4")
        assert not rl.check("1.2.3.4")

    def test_ok_clears(self) -> None:
        rl = RateLimiter(max_attempts=2, window=60)
        rl.fail("1.2.3.4")
        rl.fail("1.2.3.4")
        assert not rl.check("1.2.3.4")
        rl.ok("1.2.3.4")
        assert rl.check("1.2.3.4")
