from __future__ import annotations

import pytest

from fognode.utils.ipwords import ip_to_name, name_to_ip


class TestIpWords:
    def test_roundtrip(self) -> None:
        ip = "192.168.1.1"
        name = ip_to_name(ip)
        assert name_to_ip(name) == ip

    def test_invalid_ip(self) -> None:
        with pytest.raises(ValueError):
            ip_to_name("256.1.1.1")

    def test_invalid_name(self) -> None:
        with pytest.raises(ValueError):
            name_to_ip("not-a-valid-name")
