## Bug fix

- [ ] `ruff check src/ tests/` — no errors
- [ ] `black --check src/ tests/` — no changes needed
- [ ] `pyright src/` — no errors
- [ ] `pytest tests/` — all pass

### What bug is fixed?

### Root cause

### How was it fixed?
