## Optimization

- [ ] `ruff check src/ tests/` — no errors
- [ ] `black --check src/ tests/` — no changes needed
- [ ] `pyright src/` — no errors
- [ ] `pytest tests/` — all pass

### What was optimized?

### Measured improvement

### Risks / trade-offs
