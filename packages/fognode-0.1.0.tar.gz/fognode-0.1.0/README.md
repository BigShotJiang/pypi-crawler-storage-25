<h1 align="center">fognode</h1>

<h4 align="center">headless secure encrypted data transmission.</h4>

<p align="center">
  <a href="LICENSE"><img src="https://img.shields.io/badge/License-MIT-green?style=for-the-badge&logo=opensourceinitiative&logoColor=FFFFFF" alt="License"></a>
  <img src="https://img.shields.io/badge/Python-3.10%2B-blue?style=for-the-badge&logo=python&logoColor=white" alt="Python">
  <img src="https://img.shields.io/badge/Platform-Linux%20%7C%20macOS%20%7C%20Windows-lightgrey?style=for-the-badge&logo=linux&logoColor=FCC624" alt="Platform">
  <img src="https://img.shields.io/badge/code%20style-black-000000?style=for-the-badge" alt="black">
  <img src="https://img.shields.io/badge/linting-ruff-orange?style=for-the-badge" alt="ruff">
  <img src="https://img.shields.io/badge/type%20checked-pyright-4B8BBE?style=for-the-badge" alt="pyright">
</p>

---

Encrypted channel library for headless projects. Built for speed and zero-trust networking.

Stack: TLS 1.2+ · X25519 · AESGCM-256 · HMAC-SHA256 · PBKDF2 · HKDF

---

## Install

```bash
pip install fognode
```

## Quick start (aiogram-style)

### Server

```python
from fognode import App, Cipher

app = App(
    host="0.0.0.0",
    port=9443,
    user="alice",
    password="secret",
    cipher=Cipher.AESGCM,
)

@app.on_message()
async def echo(ctx):
    await ctx.answer(f"echo: {ctx.message.text}")

@app.on_command("ping")
async def ping(ctx):
    await ctx.answer("pong")

@app.on_connect()
async def on_connect(ctx):
    print(f"+ {ctx.user}")

if __name__ == "__main__":
    app.run()
```

### Client

```python
from fognode import App, Cipher

app = App.client(
    connect_string="alice@oak-pine-stone-field:9443",
    password="secret",
    cipher=Cipher.AESGCM,
)

@app.on_message()
async def on_message(ctx):
    print(f"{ctx.message.user}: {ctx.message.text}")

if __name__ == "__main__":
    app.run()
```

## Classic API

```python
from fognode import start_server, client_connect

ip, code, fp = start_server("0.0.0.0", 9443, "alice", "secret")
print(f"Connect: alice@{code}:9443")
```

## Structure

```
src/fognode/
├── app.py          # App class (aiogram-style)
├── cipher.py       # Cipher enum
├── context.py      # Context for handlers
├── message.py      # Message dataclass
├── router.py       # Router for handlers
├── filters/        # Command, Text filters
├── handlers/       # HandlerObject
├── types/          # exceptions, constants, protocol
├── crypto/         # primitives, kdf, cert, channel
├── ciphers/        # aesgcm, chacha20, x25519, hkdf, pbkdf2, hmac
├── wire/           # framing
├── auth/           # handshake
├── core/           # server, client, session, state
├── decorators.py   # retry, rate_limited, timed
├── exceptions.py   # errors
├── utils/          # ipwords, ratelimit, net
└── cli/            # entrypoint
```

---

<p align="center"><sub><a href="LICENSE">MIT</a> © reekeer</sub></p>
