from __future__ import annotations

from fognode import start_server

ip, code, fp = start_server("0.0.0.0", 9443, "alice", "secret")
print(f"Server running at {ip} ({code}) port 9443")
print(f"Fingerprint: {fp}")

import signal

try:
    signal.pause()
except (KeyboardInterrupt, AttributeError):
    pass
