import typer # type: ignore
import os
from .utils import collect_files, get_promignore, estimate_tokens, is_text_file
from .config import MAX_FILES

app = typer.Typer()


@app.command()
def create():
    """Собрать все файлы проекта в один промпт."""
    current = os.getcwd()
    files = collect_files()

    if len(files) > MAX_FILES:
        typer.echo(f"⚠️  Найдено {len(files)} файлов — это больше {MAX_FILES}.")
        typer.echo("Добавь папки в .promignore или увеличь MAX_FILES.")
        raise typer.Exit()

    if not files:
        typer.echo("⚠️  Не найдено ни одного файла с допустимым расширением.")
        raise typer.Exit()

    typer.echo(f"📂 Найдено файлов: {len(files)}")

    lines = []
    lines.append("Ниже указана структура текущего проекта.")
    lines.append("Структура проекта это путь к файлу и содержимое файла.")
    lines.append("-" * 60)
    lines.append("")

    for rel_path in sorted(files):
        full_path = os.path.join(current, rel_path)
        lines.append(f"### Path: {rel_path}")
        lines.append("")

        if not is_text_file(full_path):
            typer.echo(f"⚠️  Пропускаю бинарный файл: {rel_path}")
            continue

        try:
            with open(full_path, "r", encoding="utf-8") as f:
                content = f.read()
            lines.append(content)
        except Exception as e:
            lines.append(f"[Не удалось прочитать файл: {e}]")

        lines.append("")
        lines.append("-" * 60)
        lines.append("")

    lines.append("=" * 60)
    lines.append("ВОПРОС / ЗАДАЧА:")

    output_path = os.path.join(current, "prompt.txt")
    with open(output_path, "w", encoding="utf-8") as f:
        f.write("\n".join(lines))

    typer.echo(f"✅ Файл создан: prompt.txt")

    token_count = estimate_tokens(output_path)
    typer.echo(f"🔢 Токенов: ~{token_count}")


@app.command()
def ignore():
    """Показать текущий список файлов или папок для игнорирования."""
    ignore_dirs, ignore_files, ignore_extensions = get_promignore()

    if not ignore_dirs and not ignore_files and not ignore_extensions:
        typer.echo("Нет игнорируемых файлов.")
        typer.echo("Создай .promignore в корне проекта.")
        return

    if ignore_dirs:
        typer.echo("📁 Папки:")
        for item in ignore_dirs:
            typer.echo(f"  - {item}")

    if ignore_files:
        typer.echo("📄 Файлы:")
        for item in ignore_files:
            typer.echo(f"  - {item}")

    if ignore_extensions:
        typer.echo("🔖 Расширения:")
        for item in ignore_extensions:
            typer.echo(f"  - *.{item}")


if __name__ == "__main__":
    app()