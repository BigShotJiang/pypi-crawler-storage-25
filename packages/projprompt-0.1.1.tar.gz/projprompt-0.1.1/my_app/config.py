# Допустимые расширения файла
ALLOWED_EXTENSIONS = ['py', 'html', 'toml', 'md', 'txt', 'js', 'css', 'json']
# Допустимые файлы у которых нету расширения
ALLOWED_FILENAMES = ['Dockerfile', '.dockerignore', '.gitignore']
# Системные файлы — пропускаем всегда
SYSTEM_FILES = ['prompt.txt', '.promignore']
# Если в проекте больше 30 файлов остановить
MAX_FILES = 30