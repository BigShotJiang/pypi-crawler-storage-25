import os
import tiktoken # type: ignore
from .config import ALLOWED_EXTENSIONS, SYSTEM_FILES, ALLOWED_FILENAMES

# Профитать файл игнора и вернуть списки для игнорирования
def get_promignore():
    current = os.getcwd()
    items = os.listdir(current)
    ignore_dirs = []
    ignore_files = []
    ignore_extensions = []

    if '.promignore' in items:
        path_promignore = os.path.join(current, '.promignore')

        with open(path_promignore, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()

                if not line or line.startswith('#'):
                    continue

                if line.startswith('*.'):
                    ext = line[2:]
                    ignore_extensions.append(ext)

                elif line.endswith('/'):
                    ignore_dirs.append(line[:-1])

                else:
                    ignore_dirs.append(line)
                    ignore_files.append(line)

    return ignore_dirs, ignore_files, ignore_extensions

# Функцыя которая отбирает файлы для склейки
def collect_files():
    current = os.getcwd()
    collected = []
    ignore_dirs, ignore_files, ignore_extensions = get_promignore()

    for dirpath, dirs, files in os.walk(current):
        dirs[:] = [d for d in dirs if d not in ignore_dirs]

        for file in files:
            if file in SYSTEM_FILES:
                continue

            if file in ignore_files:
                continue

            ext = file.rsplit('.', 1)[-1] if '.' in file else ''

            if ext in ignore_extensions:
                continue

            if ext in ALLOWED_EXTENSIONS or file in ALLOWED_FILENAMES:
                full_path = os.path.join(dirpath, file)
                rel_path = os.path.relpath(full_path, current)
                collected.append(rel_path)

    return collected

# Оценка количества токенов
def estimate_tokens(filepath='prompt.txt'):
    """Вернуть количество токенов в файле."""
    with open(filepath, "r", encoding="utf-8") as f:
        text = f.read()

    enc = tiktoken.get_encoding("cl100k_base")
    tokens = enc.encode(text)
    return len(tokens)

def is_text_file(filepath):
    """Проверить что файл текстовый а не бинарный."""
    try:
        with open(filepath, "r", encoding="utf-8") as f:
            f.read(1024)  # читаем только первые 1024 байта
        return True
    except UnicodeDecodeError:
        return False