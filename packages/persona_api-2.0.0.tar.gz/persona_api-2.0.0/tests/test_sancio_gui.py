"""Sancio GUI (port 8401) backend tests.

Covers:

* App boot writes a token file at the requested path with mode 0600
  (POSIX) or just-exists (Windows).
* ``GET /api/health`` does NOT require a Bearer header.
* ``GET /api/runtime/state`` rejects missing / wrong Bearer (401).
* Correct Bearer unlocks ``/api/runtime/state`` and surfaces the
  expected runtime knobs.
* ``GET /api/skills`` discovers event_bindings via the dispatcher glue.
* ``GET /api/sessions`` reflects the live dispatcher cache.
"""

from __future__ import annotations

import os
import sys
from pathlib import Path

import pytest

_SRC = Path(__file__).resolve().parent.parent / "src"
if str(_SRC) not in sys.path:
    sys.path.insert(0, str(_SRC))


@pytest.fixture
def gui_app(tmp_path):
    """Build a fresh Sancio GUI app with a known token + isolated path.

    Mirrors ``concinno.tests.test_gui_auth.app_with_known_token`` so the
    tests read familiar across the two GUI surfaces.
    """
    from persona.gui.server import create_sancio_gui_app

    token_path = tmp_path / "sancio_gui_token"
    app = create_sancio_gui_app(
        token="UNIT-TEST-TOKEN-SANCIO",
        token_path=token_path,
    )
    return app, "UNIT-TEST-TOKEN-SANCIO", token_path


def test_create_app_writes_token_to_disk(gui_app):
    _app, token, token_path = gui_app
    assert token_path.is_file()
    assert token_path.read_text(encoding="utf-8") == token
    if sys.platform != "win32":
        # POSIX: ``concinno.gui.auth.write_token`` chmods 0600 on
        # POSIX hosts before atomic-rename. This is the privacy
        # invariant for the bearer token file.
        mode = os.stat(token_path).st_mode & 0o777
        assert mode == 0o600


def test_health_route_bypasses_auth(gui_app):
    from fastapi.testclient import TestClient

    app, _tok, _path = gui_app
    with TestClient(app) as client:
        r = client.get("/api/health")
        assert r.status_code == 200
        body = r.json()
        assert body["status"] == "ok"
        assert body["service"] == "sancio-gui"


def test_runtime_state_requires_bearer(gui_app):
    from fastapi.testclient import TestClient

    app, _tok, _path = gui_app
    with TestClient(app) as client:
        r = client.get("/api/runtime/state")
        assert r.status_code == 401


def test_runtime_state_rejects_wrong_bearer(gui_app):
    from fastapi.testclient import TestClient

    app, _tok, _path = gui_app
    with TestClient(app) as client:
        r = client.get(
            "/api/runtime/state",
            headers={"Authorization": "Bearer not-the-real-token"},
        )
        assert r.status_code == 401


def test_runtime_state_accepts_correct_bearer(gui_app):
    from fastapi.testclient import TestClient

    app, tok, _path = gui_app
    with TestClient(app) as client:
        r = client.get(
            "/api/runtime/state",
            headers={"Authorization": f"Bearer {tok}"},
        )
        assert r.status_code == 200
        body = r.json()
        # ``persona.runtime.get_runtime_state`` always exposes these.
        assert "active_preset" in body
        assert "audit_level" in body
        assert "provider_preference" in body
        # Sancio gui adds these lightweight live counters.
        assert "dispatcher_session_count" in body
        assert "event_dispatcher_enabled" in body
        assert "sancio_require_auth" in body


def test_sessions_reflect_dispatcher_cache(gui_app, tmp_path):
    """Populating the dispatcher cache must show up in /api/sessions."""
    from fastapi.testclient import TestClient

    from persona.runtime_dispatcher_glue import (
        get_dispatcher,
        reset_dispatcher_cache,
    )

    reset_dispatcher_cache()
    # Use an isolated cache_dir so OutcomeStore writes never touch the
    # operator's real ``~/.concinno/`` tree.
    get_dispatcher("test-session-aaa", cache_dir=str(tmp_path / "cache"))
    get_dispatcher("test-session-bbb", cache_dir=str(tmp_path / "cache"))

    app, tok, _path = gui_app
    try:
        with TestClient(app) as client:
            r = client.get(
                "/api/sessions",
                headers={"Authorization": f"Bearer {tok}"},
            )
            assert r.status_code == 200
            body = r.json()
            assert body["count"] >= 2
            ids = [s["session_id_truncated"] for s in body["sessions"]]
            # Truncated form is "test-ses…-aaa" / "test-ses…-bbb".
            assert any("aaa" in s for s in ids)
            assert any("bbb" in s for s in ids)
    finally:
        reset_dispatcher_cache()


def test_skills_endpoint_runs_discovery(gui_app, monkeypatch):
    """``/api/skills`` must call ``discover_event_bindings`` and surface
    its rows. We monkeypatch the discovery to a controlled fixture so
    the test is independent of which SKILL.md files happen to exist on
    the dev box.
    """
    from fastapi.testclient import TestClient

    from persona import runtime_dispatcher_glue as glue

    fake_path = Path("/tmp/fake-skill/SKILL.md")
    fake_meta = {
        "name": "fake-test-skill",
        "description": "Synthetic skill row for the GUI test.",
        "event_bindings": [
            {
                "event": "PreToolUse",
                "invoke": "skill:fake-test-skill",
                "priority": 50,
                "cooldown_s": 0,
            },
        ],
    }
    monkeypatch.setattr(
        glue,
        "discover_event_bindings",
        lambda *a, **kw: [(fake_path, fake_meta)],
    )

    app, tok, _path = gui_app
    with TestClient(app) as client:
        r = client.get(
            "/api/skills",
            headers={"Authorization": f"Bearer {tok}"},
        )
        assert r.status_code == 200
        body = r.json()
        assert body["count"] == 1
        row = body["skills"][0]
        assert row["name"] == "fake-test-skill"
        assert row["binding_count"] == 1
        assert row["event_bindings"][0]["event"] == "PreToolUse"


def test_landing_page_renders_without_auth(gui_app):
    """``GET /`` returns the v0.1 stub HTML for unauthenticated browser
    visits — VS Code iframe webview hits this path before reading the
    token off disk.
    """
    from fastapi.testclient import TestClient

    app, _tok, _path = gui_app
    with TestClient(app) as client:
        r = client.get("/")
        assert r.status_code == 200
        assert "Sancio GUI" in r.text
