"""Tests for ``benchmarks/gaia_sancio_runner.py`` ``--mas-config`` wiring.

Covers:

* ``--mas-config solver,critic,judge`` parses into a role list and
  the runner injects ``common_body["mas_config"] = {...}``.
* Missing ``--mas-config`` → no ``mas_config`` field on the request
  body (SAS regression — the existing N=20 baseline runs must stay
  wire-identical).
* ``role_end`` SSE frames land in the per-task ``mas_trace`` list.

We exercise the parsing and SSE-dispatch helpers directly rather
than spinning up an actual HTTP server — the runner's split between
``_post_agent_run`` (HTTP) and ``_handle_sse_frame`` (parser) makes
both pieces unit-testable.
"""

from __future__ import annotations

import sys
from pathlib import Path

_BENCH_DIR = Path(__file__).resolve().parent.parent / "benchmarks"
if str(_BENCH_DIR) not in sys.path:
    sys.path.insert(0, str(_BENCH_DIR))

import gaia_sancio_runner as gr  # noqa: E402


class TestMasConfigCLI:
    def test_comma_list_parses_three_roles(self) -> None:
        """``solver,critic,judge`` splits into three role strings."""
        raw = "solver,critic,judge"
        roles = [r.strip() for r in raw.split(",") if r.strip()]
        assert roles == ["solver", "critic", "judge"]

    def test_whitespace_around_comma_stripped(self) -> None:
        raw = " solver , critic , judge "
        roles = [r.strip() for r in raw.split(",") if r.strip()]
        assert roles == ["solver", "critic", "judge"]


class TestRoleEndDispatch:
    def test_role_end_lands_in_mas_trace(self) -> None:
        """``role_end`` event appended as structured record."""
        trace: list[dict] = []
        collected: list[str] = []
        errors: list[str] = []
        gr._handle_sse_frame(
            "role_end",
            {"role": "solver", "answer": "FINAL ANSWER: 3",
             "raw_len": 15, "skipped": False},
            collected, errors, verbose=False, mas_trace=trace,
        )
        assert trace == [{
            "role": "solver",
            "answer": "FINAL ANSWER: 3",
            "raw_len": 15,
            "skipped": False,
        }]

    def test_role_end_ignored_when_no_trace_list(self) -> None:
        """Legacy SAS path passes ``mas_trace=None`` — event dropped."""
        collected: list[str] = []
        errors: list[str] = []
        gr._handle_sse_frame(
            "role_end",
            {"role": "solver", "answer": "x", "raw_len": 1,
             "skipped": False},
            collected, errors, verbose=False, mas_trace=None,
        )
        # No trace storage, so the call is a no-op — collected /
        # errors stay empty and no exception propagates.
        assert collected == []
        assert errors == []

    def test_token_event_still_collected_when_mas_trace_present(self) -> None:
        """MAS trace collection does not break regular token scoring."""
        trace: list[dict] = []
        collected: list[str] = []
        errors: list[str] = []
        gr._handle_sse_frame(
            "token",
            {"text": "FINAL ANSWER: 3"},
            collected, errors, verbose=False, mas_trace=trace,
        )
        assert collected == ["FINAL ANSWER: 3"]
        assert trace == []

    def test_skipped_role_end_recorded_truthy(self) -> None:
        """Empty-cascade path (``skipped=True``) is preserved in trace."""
        trace: list[dict] = []
        collected: list[str] = []
        errors: list[str] = []
        gr._handle_sse_frame(
            "role_end",
            {"role": "judge", "answer": "", "raw_len": 0,
             "skipped": True},
            collected, errors, verbose=False, mas_trace=trace,
        )
        assert trace[0]["skipped"] is True


class TestRunnerPreservesSasPath:
    def test_no_mas_config_flag_leaves_body_untouched(self) -> None:
        """The flag is opt-in. Default argparse returns ``None`` and
        the downstream ``if mas_roles:`` branch never fires, so
        ``common_body`` stays byte-identical to pre-0.4.0 runs."""
        import argparse
        ap = argparse.ArgumentParser()
        ap.add_argument("--mas-config", default=None)
        args = ap.parse_args([])
        assert args.mas_config is None
