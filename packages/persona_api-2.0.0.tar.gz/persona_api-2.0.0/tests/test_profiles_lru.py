"""P0#1 Task 4 — ``_profiles`` LRU + TTL cap.

Verifies :class:`persona.api._ProfilesLRU` behaves like the
documented LRU-with-TTL: size cap evicts oldest, TTL evicts stale,
refresh-on-hit keeps hot keys alive.
"""

from __future__ import annotations

import time

import pytest

from persona.api import _ProfilesLRU
from persona.loader import parse_persona_text


def _mkpersona(name: str):
    """Minimal valid persona payload for LRU tests."""
    return parse_persona_text(
        f"You are {name}, a curious engineer.",
    )


def test_lru_basic_set_get() -> None:
    lru = _ProfilesLRU(max_size=3, ttl_s=60)
    p = _mkpersona("alice")
    lru.set("alice", p)
    assert lru.get("alice") is p
    assert len(lru) == 1


def test_lru_evicts_oldest_on_overflow() -> None:
    lru = _ProfilesLRU(max_size=2, ttl_s=60)
    lru.set("a", _mkpersona("a"))
    lru.set("b", _mkpersona("b"))
    lru.set("c", _mkpersona("c"))
    # 'a' was LRU, should have been evicted.
    assert lru.get("a") is None
    assert lru.get("b") is not None
    assert lru.get("c") is not None
    assert len(lru) == 2


def test_get_refreshes_lru_position() -> None:
    lru = _ProfilesLRU(max_size=2, ttl_s=60)
    lru.set("a", _mkpersona("a"))
    lru.set("b", _mkpersona("b"))
    # Bump 'a' to MRU.
    assert lru.get("a") is not None
    lru.set("c", _mkpersona("c"))
    # 'b' should now be evicted, 'a' stays.
    assert lru.get("a") is not None
    assert lru.get("b") is None
    assert lru.get("c") is not None


def test_ttl_evicts_stale_entries(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    lru = _ProfilesLRU(max_size=10, ttl_s=1.0)
    lru.set("a", _mkpersona("a"))
    assert lru.get("a") is not None

    # Move the clock forward past the TTL.
    t0 = [time.time()]

    def _fake_time() -> float:
        return t0[0] + 2.0

    monkeypatch.setattr(time, "time", _fake_time)
    assert lru.get("a") is None


def test_clear_wipes_everything() -> None:
    lru = _ProfilesLRU(max_size=5, ttl_s=60)
    lru.set("a", _mkpersona("a"))
    lru.set("b", _mkpersona("b"))
    lru.clear()
    assert len(lru) == 0
    assert lru.get("a") is None


def test_contains_operator() -> None:
    lru = _ProfilesLRU(max_size=3, ttl_s=60)
    lru.set("a", _mkpersona("a"))
    assert "a" in lru
    assert "b" not in lru


def test_max_size_floor_is_one() -> None:
    """A zero/negative max_size still holds at least one entry
    (defensive — we prefer one stale entry over a 500)."""
    lru = _ProfilesLRU(max_size=0, ttl_s=60)
    lru.set("a", _mkpersona("a"))
    assert lru.get("a") is not None
