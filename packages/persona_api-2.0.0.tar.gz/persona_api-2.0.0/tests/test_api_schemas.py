"""Contract tests for ``persona.api_schemas``.

These tests pin the pydantic v2 schema layer that backs
``POST /v1/cerno/cycle``. They run in two regimes:

1. **Schema-only**: ``CernoCycleRequest`` / ``CernoCycleResponse``
   are exercised in isolation via :meth:`BaseModel.model_validate` and
   :meth:`BaseModel.model_dump`. No HTTP, no Cerno.

2. **Wire-level**: a single happy-path round-trip hits
   ``/v1/cerno/cycle`` through Starlette ``TestClient`` and asserts
   the response body validates cleanly against
   ``CernoCycleResponse``. This is the "schema matches the real
   endpoint" guarantee.

The legacy error-code contract tests live in
``tests/test_api_cerno_endpoint.py`` and must stay green alongside
this file — any divergence means the pydantic validator is drifting
away from the hand-written ``isinstance`` fallback.
"""

from __future__ import annotations

import pytest
from pydantic import ValidationError
from starlette.applications import Starlette
from starlette.testclient import TestClient

from persona.api import _set_cernos_for_tests, create_aegis_routes
from persona.api_schemas import (
    ActionOut,
    CernoCycleRequest,
    CernoCycleResponse,
    AssessmentOut,
    DefectHitOut,
    EquilibriumStateOut,
    ReviewOut,
    StateOut,
)


# ── Request: happy paths ────────────────────────


def test_request_happy_path_minimal() -> None:
    """``intent`` + ``child_id`` only → defaults fill the rest."""
    req = CernoCycleRequest.model_validate(
        {"intent": "x", "child_id": "y"},
    )
    assert req.intent == "x"
    assert req.child_id == "y"
    assert req.child_output == ""
    assert req.config is None


def test_request_happy_path_full() -> None:
    """All four fields explicitly set → validates."""
    req = CernoCycleRequest.model_validate(
        {
            "intent": "summarize",
            "child_id": "child-1",
            "child_output": "A short summary.",
            "config": {"deny_quality_threshold": 80},
        },
    )
    assert req.intent == "summarize"
    assert req.child_output == "A short summary."
    assert req.config == {"deny_quality_threshold": 80}


# ── Request: rejection cases ────────────────────


def test_request_extra_field_rejected() -> None:
    """``extra="forbid"`` blocks unknown top-level keys."""
    with pytest.raises(ValidationError) as excinfo:
        CernoCycleRequest.model_validate(
            {
                "intent": "x",
                "child_id": "y",
                "mystery_field": 42,
            },
        )
    errs = excinfo.value.errors()
    assert any(e["type"] == "extra_forbidden" for e in errs)


def test_request_missing_intent_raises() -> None:
    """``intent`` absent → ValidationError type=missing."""
    with pytest.raises(ValidationError) as excinfo:
        CernoCycleRequest.model_validate({"child_id": "y"})
    errs = excinfo.value.errors()
    assert any(
        e["type"] == "missing" and "intent" in e.get("loc", ())
        for e in errs
    )


def test_request_missing_child_id_raises() -> None:
    """``child_id`` absent → ValidationError type=missing."""
    with pytest.raises(ValidationError) as excinfo:
        CernoCycleRequest.model_validate({"intent": "x"})
    errs = excinfo.value.errors()
    assert any(
        e["type"] == "missing" and "child_id" in e.get("loc", ())
        for e in errs
    )


def test_request_intent_empty_raises() -> None:
    """Empty-string ``intent`` fails ``min_length=1``."""
    with pytest.raises(ValidationError) as excinfo:
        CernoCycleRequest.model_validate({"intent": "", "child_id": "y"})
    errs = excinfo.value.errors()
    assert any(e["type"] == "string_too_short" for e in errs)


def test_request_child_id_empty_raises() -> None:
    """Empty-string ``child_id`` fails ``min_length=1``."""
    with pytest.raises(ValidationError) as excinfo:
        CernoCycleRequest.model_validate({"intent": "x", "child_id": ""})
    errs = excinfo.value.errors()
    assert any(e["type"] == "string_too_short" for e in errs)


def test_request_config_not_dict_raises() -> None:
    """``config`` must be a dict or None — plain string rejected."""
    with pytest.raises(ValidationError) as excinfo:
        CernoCycleRequest.model_validate(
            {"intent": "x", "child_id": "y", "config": "not-a-dict"},
        )
    errs = excinfo.value.errors()
    assert any("dict" in e["type"] for e in errs)


def test_request_intent_wrong_type_raises() -> None:
    """``intent`` as an int fails ``string_type`` validator."""
    with pytest.raises(ValidationError) as excinfo:
        CernoCycleRequest.model_validate({"intent": 42, "child_id": "y"})
    errs = excinfo.value.errors()
    assert any(e["type"] == "string_type" for e in errs)


# ── Response: schema-only construction ──────────


def _make_fake_response() -> CernoCycleResponse:
    """Hand-rolled ``CernoCycleResponse`` with every field populated."""
    return CernoCycleResponse(
        action=ActionOut(
            type="deny",
            reason="2 critical defect(s): L7, A3",
            defects=["L7", "A3"],
        ),
        review=ReviewOut(
            defects_found=[
                DefectHitOut(
                    id="L7",
                    severity="high",
                    evidence="absolutely guaranteed",
                    confidence=0.9,
                ),
            ],
            quality_score=30,
            aligned_with_assessment=False,
            sycophancy_risk=0.2,
            reviewed_at=1_000_000.0,
        ),
        assessment=AssessmentOut(
            user_intent="explain",
            risk_level="medium",
            expected_traits=["clarity", "honesty"],
            assessed_at=999_999.0,
        ),
        state=StateOut(
            child_id="test-child",
            consecutive_denies=1,
            current_identity="mirror",
            equilibrium=EquilibriumStateOut(
                pressure=1.0,
                breaker_tripped=False,
                cooldown_remaining=0,
                deny_rate=0.5,
                total_steps=2,
                pressure_history=[0.0, 1.0],
                tct_frozen=False,
            ),
            recent_scores=[30],
        ),
    )


def test_response_shape_round_trip() -> None:
    """Build → ``model_dump(mode='json')`` → revalidate → equal."""
    original = _make_fake_response()
    dumped = original.model_dump(mode="json")

    # Top-level keys line up with the wire contract.
    assert set(dumped.keys()) == {"action", "review", "assessment", "state"}
    assert dumped["action"]["type"] == "deny"
    assert dumped["state"]["child_id"] == "test-child"
    assert dumped["state"]["recent_scores"] == [30]

    # Revalidation is lossless.
    rebuilt = CernoCycleResponse.model_validate(dumped)
    assert rebuilt == original


def test_response_action_discriminator() -> None:
    """``ActionOut.type`` must be one of the four literals."""
    with pytest.raises(ValidationError):
        ActionOut.model_validate({"type": "frobnicate"})


def test_response_state_identity_accepts_any_str() -> None:
    """``current_identity`` is ``str``, not a ``Literal``.

    Pinning a literal would reject forward-compatible mother-identity
    additions. Regression guard: a never-before-seen identity string
    must validate cleanly.
    """
    state = StateOut(
        child_id="x",
        consecutive_denies=0,
        current_identity="never_seen_before",
        equilibrium=EquilibriumStateOut(
            pressure=0.0,
            breaker_tripped=False,
            cooldown_remaining=0,
            deny_rate=0.0,
            total_steps=0,
            pressure_history=[],
            tct_frozen=False,
        ),
        recent_scores=[],
    )
    assert state.current_identity == "never_seen_before"


def test_response_allow_action_minimal() -> None:
    """``ActionOut(type='allow')`` omits reason/defects/handoff."""
    action = ActionOut.model_validate({"type": "allow"})
    assert action.type == "allow"
    assert action.reason is None
    assert action.defects is None
    assert action.handoff is None


def test_response_nullable_review_and_assessment() -> None:
    """Fresh Cerno state (pre-cycle) → review / assessment = None."""
    resp = CernoCycleResponse(
        action=ActionOut(type="allow"),
        review=None,
        assessment=None,
        state=StateOut(
            child_id="fresh",
            consecutive_denies=0,
            current_identity="mirror",
            equilibrium=EquilibriumStateOut(
                pressure=0.0,
                breaker_tripped=False,
                cooldown_remaining=0,
                deny_rate=0.0,
                total_steps=0,
                pressure_history=[],
                tct_frozen=False,
            ),
            recent_scores=[],
        ),
    )
    dumped = resp.model_dump(mode="json")
    assert dumped["review"] is None
    assert dumped["assessment"] is None


# ── Wire-level: real endpoint → schema validation ─


@pytest.fixture()
def client() -> TestClient:
    """Fresh TestClient with an empty Cerno registry."""
    _set_cernos_for_tests(None)
    app = Starlette(routes=create_aegis_routes())
    try:
        yield TestClient(app)
    finally:
        _set_cernos_for_tests(None)


def test_wire_round_trip_validates_against_response_schema(
    client: TestClient,
) -> None:
    """Real endpoint body validates cleanly against the schema.

    This is the "schema matches reality" check. A benign input runs
    through a real ``Cerno`` instance and the resulting JSON must
    round-trip cleanly through ``CernoCycleResponse.model_validate``.
    If this ever fails, either the endpoint or the schema has drifted
    and the OpenAPI contract is no longer accurate.
    """
    resp = client.post(
        "/v1/cerno/cycle",
        json={
            "intent": "summarize this paragraph",
            "child_output": "Here is a short, honest summary.",
            "child_id": "schema-wire-child",
        },
    )
    assert resp.status_code == 200, resp.text
    body = resp.json()

    # Top-level shape matches schema exactly.
    model = CernoCycleResponse.model_validate(body)
    assert model.state.child_id == "schema-wire-child"
    assert model.action.type in {"allow", "deny", "transfer", "recalibrate"}
    # Equilibrium nested model must hydrate from the real dataclass
    # dump — the seven field names below pin the EquilibriumState
    # wire shape end-to-end.
    assert isinstance(model.state.equilibrium, EquilibriumStateOut)
    assert isinstance(model.state.equilibrium.pressure, float)
    assert isinstance(model.state.equilibrium.breaker_tripped, bool)
    assert isinstance(model.state.equilibrium.total_steps, int)
