"""Tests for Commander-routed MAS on ``POST /v1/agent/run`` (Tier 1).

Surface under test
------------------

* ``SANCIO_MAS_COMMANDER=0`` (default) → commander not consulted even
  when ``mas_config=None``; SAS path reproduces byte-identical.
* ``SANCIO_MAS_COMMANDER=1`` + ``mas_config=None`` + tier 0 from
  commander → still SAS (no auto-promote).
* ``SANCIO_MAS_COMMANDER=1`` + ``mas_config=None`` + tier ≥1 from
  commander → auto-promote to MAS with an ``AsymmetryPlan``; SSE
  stream carries a ``commander`` event.
* ``SANCIO_MAS_COMMANDER=1`` + explicit ``mas_config`` → commander
  still emits attribution but does not override the client's pin.

All tests hermetic — scripted fake provider, no real LLM call.
"""

from __future__ import annotations

from collections.abc import Iterator
from typing import Any

import pytest
from starlette.testclient import TestClient

from persona import agent_api
from persona.api import create_standalone_app
from persona.engine.agent_loop import LLMResponse


@pytest.fixture()
def client() -> Iterator[TestClient]:
    app = create_standalone_app()
    with TestClient(app) as c:
        yield c
    agent_api.reset_llm_call()


@pytest.fixture()
def mas_enabled(monkeypatch: pytest.MonkeyPatch) -> Iterator[None]:
    """MAS feature-flag on; commander still needs its own opt-in."""
    monkeypatch.setattr(agent_api, "_MAS_ENABLED", True)
    monkeypatch.setattr(agent_api, "_MAS_MAX_ROLES", 3)
    yield


@pytest.fixture()
def commander_on(monkeypatch: pytest.MonkeyPatch) -> Iterator[None]:
    monkeypatch.setattr(agent_api, "_MAS_COMMANDER_ENABLED", True)
    yield


@pytest.fixture()
def commander_off(monkeypatch: pytest.MonkeyPatch) -> Iterator[None]:
    monkeypatch.setattr(agent_api, "_MAS_COMMANDER_ENABLED", False)
    yield


def _install_fake(*scripted: str) -> list[str]:
    """Script N sequential LLM replies (solver → critic → judge → ...)."""
    idx = {"i": 0}

    async def _call(
        messages: list[dict[str, Any]],
        schemas: list[dict[str, Any]],  # noqa: ARG001
    ) -> LLMResponse:
        i = idx["i"]
        idx["i"] = i + 1
        if i >= len(scripted):
            raise AssertionError(
                f"llm called {i + 1}x but only {len(scripted)} scripted",
            )
        return LLMResponse(content=scripted[i], tool_calls=[])

    agent_api.set_llm_call(_call)
    return list(scripted)


def _parse_sse(body: str) -> list[tuple[str, str]]:
    events: list[tuple[str, str]] = []
    for block in body.strip().split("\n\n"):
        event = ""
        data_parts: list[str] = []
        for line in block.splitlines():
            if line.startswith("event:"):
                event = line.split(":", 1)[1].strip()
            elif line.startswith("data:"):
                data_parts.append(line.split(":", 1)[1].strip())
        if data_parts:
            events.append((event or "message", "\n".join(data_parts)))
    return events


# ── Default OFF (M3 ACCEPT) ──


class TestCommanderDefaultOff:
    """S5 M3 ACCEPT — Commander default-off; nothing changes unless opt-in."""

    def test_flag_default_is_false(self) -> None:
        """Module-level default must be off — ``os.environ`` default "0"."""
        # Re-read the module: the env default evaluation happens at
        # import time, so a fresh interpreter with no flag should have
        # ``_MAS_COMMANDER_ENABLED=False``. We can't re-import mid-test
        # safely, so we check the env logic directly.
        import os
        env_value = os.environ.get("SANCIO_MAS_COMMANDER", "0")
        assert env_value.strip().lower() not in {"1", "true", "yes", "on"}

    def test_sas_unchanged_when_commander_off(
        self, client: TestClient, mas_enabled: None,  # noqa: ARG002
        commander_off: None,  # noqa: ARG002
    ) -> None:
        _install_fake("FINAL ANSWER: ok")
        resp = client.post(
            "/v1/agent/run",
            json={
                "stack": "aegis",
                "model": "fake/model",
                "messages": [{"role": "user", "content": "ping"}],
                "max_iterations": 2,
            },
        )
        assert resp.status_code == 200
        events = _parse_sse(resp.text)
        names = [n for n, _ in events]
        # SAS path has no ``commander`` event and no ``role_end`` MAS events.
        assert "commander" not in names
        assert "role_end" not in names


# ── Commander ON but tier 0 — remains SAS ──


class TestCommanderTierZeroStaysSAS:
    """Commander returns tier 0 → ``mas_config`` not synthesised."""

    def test_tier_0_no_auto_promote(
        self, client: TestClient, mas_enabled: None,  # noqa: ARG002
        commander_on: None,  # noqa: ARG002
        monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        from concinno.agent import Commander, TierDecision
        from concinno.agent.commander import TIER_BUDGETS

        def _fake_route(self, q: str, ctx: dict) -> TierDecision:  # noqa: ARG001
            return TierDecision(
                tier=0, alpha_t=0.1, budget=TIER_BUDGETS[0],
                reason="test tier 0",
            )

        monkeypatch.setattr(Commander, "route", _fake_route)

        _install_fake("FINAL ANSWER: 4")
        resp = client.post(
            "/v1/agent/run",
            json={
                "stack": "aegis",
                "model": "fake/model",
                "messages": [{"role": "user", "content": "simple q"}],
                "max_iterations": 2,
            },
        )
        assert resp.status_code == 200
        events = _parse_sse(resp.text)
        names = [n for n, _ in events]
        assert "commander" not in names  # Only present when promoted
        assert "role_end" not in names


# ── Commander ON, tier ≥1 — auto-promote to MAS + emit commander event ──


class TestCommanderAutoPromote:
    """S5 ACCEPT — tier ≥1 → synthesise mas_config + asymmetry plan."""

    def test_tier_1_emits_commander_event(
        self, client: TestClient, mas_enabled: None,  # noqa: ARG002
        commander_on: None,  # noqa: ARG002
        monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        from concinno.agent import Commander, TierDecision
        from concinno.agent.commander import TIER_BUDGETS

        def _fake_route(self, q: str, ctx: dict) -> TierDecision:  # noqa: ARG001
            return TierDecision(
                tier=1,
                alpha_t=0.5,
                budget=TIER_BUDGETS[1],
                reason="complicated -> tier 1",
                fallback_chain=[1, 0],
            )

        monkeypatch.setattr(Commander, "route", _fake_route)

        # 3 scripted: solver / critic / judge.
        _install_fake(
            "solver says 4",
            "critic says 3",
            "FINAL ANSWER: 3",
        )
        resp = client.post(
            "/v1/agent/run",
            json={
                "stack": "aegis",
                "model": "fake/model",
                "messages": [{"role": "user", "content": "complicated q"}],
                "max_iterations": 2,
            },
        )
        assert resp.status_code == 200
        events = _parse_sse(resp.text)
        names = [n for n, _ in events]
        # Auto-promote → commander event fires + MAS role events appear.
        assert "commander" in names
        assert names.count("role_end") == 3

    def test_tier_3_emits_commander_event(
        self, client: TestClient, mas_enabled: None,  # noqa: ARG002
        commander_on: None,  # noqa: ARG002
        monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        from concinno.agent import Commander, TierDecision
        from concinno.agent.commander import TIER_BUDGETS

        def _fake_route(self, q: str, ctx: dict) -> TierDecision:  # noqa: ARG001
            return TierDecision(
                tier=3,
                alpha_t=0.95,
                budget=TIER_BUDGETS[3],
                reason="chaotic -> tier 3",
                fallback_chain=[3, 2, 0],
            )

        monkeypatch.setattr(Commander, "route", _fake_route)
        _install_fake("solver", "critic", "FINAL ANSWER: z")

        resp = client.post(
            "/v1/agent/run",
            json={
                "stack": "aegis",
                "model": "fake/model",
                "messages": [{"role": "user", "content": "chaotic q"}],
                "max_iterations": 2,
            },
        )
        assert resp.status_code == 200
        events = _parse_sse(resp.text)
        names = [n for n, _ in events]
        assert "commander" in names


# ── Explicit mas_config still respected when Commander on ──


class TestCommanderDoesNotOverrideExplicit:
    """When client pins mas_config, Commander doesn't override roles."""

    def test_explicit_mas_config_preserved(
        self, client: TestClient, mas_enabled: None,  # noqa: ARG002
        commander_on: None,  # noqa: ARG002
        monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        from concinno.agent import Commander, TierDecision
        from concinno.agent.commander import TIER_BUDGETS

        def _fake_route(self, q: str, ctx: dict) -> TierDecision:  # noqa: ARG001
            return TierDecision(
                tier=2, alpha_t=0.7, budget=TIER_BUDGETS[2],
                reason="complex", fallback_chain=[2, 1, 0],
            )

        monkeypatch.setattr(Commander, "route", _fake_route)
        _install_fake("s", "c", "FINAL ANSWER: j")

        resp = client.post(
            "/v1/agent/run",
            json={
                "stack": "aegis",
                "model": "fake/model",
                "messages": [{"role": "user", "content": "q"}],
                "max_iterations": 2,
                "mas_config": {
                    "roles": ["solver", "critic", "judge"],
                    "vote": "judge",
                },
            },
        )
        assert resp.status_code == 200
        events = _parse_sse(resp.text)
        names = [n for n, _ in events]
        assert "commander" in names
        assert names.count("role_end") == 3


# ── Commander routes failure-tolerant ──


class TestCommanderFailureTolerant:
    """Commander exceptions must not 500 the endpoint — fall through to SAS."""

    def test_commander_raises_falls_through_sas(
        self, client: TestClient, mas_enabled: None,  # noqa: ARG002
        commander_on: None,  # noqa: ARG002
        monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        from concinno.agent import Commander

        def _boom(self, q: str, ctx: dict) -> None:  # noqa: ARG001
            raise RuntimeError("commander failure simulated")

        monkeypatch.setattr(Commander, "route", _boom)
        _install_fake("FINAL ANSWER: sas_fallback")

        resp = client.post(
            "/v1/agent/run",
            json={
                "stack": "aegis",
                "model": "fake/model",
                "messages": [{"role": "user", "content": "q"}],
                "max_iterations": 2,
            },
        )
        assert resp.status_code == 200
        # No ``commander`` event because decision was None.
        events = _parse_sse(resp.text)
        names = [n for n, _ in events]
        assert "commander" not in names


# ── Env parsing ──


class TestEnvFlagParsing:
    """``SANCIO_MAS_COMMANDER`` only opens on explicit truthy values."""

    @pytest.mark.parametrize(
        "value,expected",
        [
            ("1", True),
            ("true", True),
            ("TRUE", True),
            ("yes", True),
            ("on", True),
            ("0", False),
            ("false", False),
            ("", False),
            ("no", False),
            ("off", False),
        ],
    )
    def test_env_values(self, value: str, expected: bool) -> None:
        # Direct logic mirror (can't re-import module-level state mid-test).
        is_on = value.strip().lower() in {"1", "true", "yes", "on"}
        assert is_on is expected


class TestAsymmetryMinAxesEnv:
    """``SANCIO_MAS_ASYMMETRY_MIN_AXES`` default is 2."""

    def test_default_is_two(self) -> None:
        assert agent_api._MAS_ASYMMETRY_MIN_AXES == 2


class TestFTRLSunsetEnv:
    """``SANCIO_MAS_FTRL_SUNSET_N`` default is 60 (藍 C2 ACCEPT)."""

    def test_default_is_sixty(self) -> None:
        assert agent_api._MAS_FTRL_SUNSET_N == 60
