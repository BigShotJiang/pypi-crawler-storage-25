"""Tests for persona.runtime.apply_preset — Sancio consumer hook for v4 cascade."""

from __future__ import annotations

import pytest

from persona.runtime import KNOWN_PRESETS, apply_preset, get_runtime_state


@pytest.fixture(autouse=True)
def _reset_state(monkeypatch: pytest.MonkeyPatch) -> None:
    """Leave every test with a clean env + module state."""
    monkeypatch.delenv("SANCIO_REQUIRE_AUTH", raising=False)
    # Module-level _RUNTIME_STATE dict — reset fields per test.
    import persona.runtime as _rt

    _rt._RUNTIME_STATE["active_preset"] = None
    _rt._RUNTIME_STATE["audit_level"] = "full"
    _rt._RUNTIME_STATE["provider_preference"] = "default"


def test_benchmark_sets_require_auth_zero(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    apply_preset("benchmark")
    import os

    assert os.environ["SANCIO_REQUIRE_AUTH"] == "0"
    state = get_runtime_state()
    assert state["active_preset"] == "benchmark"
    assert state["audit_level"] == "minimal"
    assert state["provider_preference"] == "ollama_native"


def test_general_sets_require_auth_one() -> None:
    apply_preset("general")
    import os

    assert os.environ["SANCIO_REQUIRE_AUTH"] == "1"
    state = get_runtime_state()
    assert state["active_preset"] == "general"
    assert state["audit_level"] == "full"


def test_prod_is_strict_like_general() -> None:
    apply_preset("prod")
    import os

    assert os.environ["SANCIO_REQUIRE_AUTH"] == "1"
    state = get_runtime_state()
    assert state["active_preset"] == "prod"
    assert state["audit_level"] == "full"


def test_unknown_preset_is_noop() -> None:
    # Start with benchmark applied.
    apply_preset("benchmark")
    import os

    assert os.environ["SANCIO_REQUIRE_AUTH"] == "0"
    # Unknown preset must not flip state.
    apply_preset("experimental")
    assert os.environ["SANCIO_REQUIRE_AUTH"] == "0"
    assert get_runtime_state()["active_preset"] == "benchmark"


def test_empty_name_is_noop() -> None:
    apply_preset("")  # must not raise
    assert get_runtime_state()["active_preset"] is None


def test_non_string_name_is_noop() -> None:
    # type: ignore — exercising runtime defense.
    apply_preset(None)  # type: ignore[arg-type]
    assert get_runtime_state()["active_preset"] is None


def test_idempotent() -> None:
    apply_preset("benchmark")
    apply_preset("benchmark")
    import os

    assert os.environ["SANCIO_REQUIRE_AUTH"] == "0"
    assert get_runtime_state()["active_preset"] == "benchmark"


def test_known_presets_list() -> None:
    assert set(KNOWN_PRESETS.keys()) == {"benchmark", "general", "prod"}
