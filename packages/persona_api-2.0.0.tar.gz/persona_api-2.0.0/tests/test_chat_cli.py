"""Tests for ``sancio chat`` REPL (M1 Week 1 deliverable).

Covers:
  * argparse smoke (parser builds, ``chat`` subcommand registered)
  * driver injection + 1-round / multi-round chat round-trip
  * tool-call round-trip with mock callback
  * /exit /clear /help slash dispatch
  * Concinno PromptEngine integration (best-effort, not required)
  * PII guard input scan (advisory, never blocks)
  * Rich missing → PlainPrinter fallback
  * Existing CLI surface (``sancio gui --help``) unbroken
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

import pytest

from persona.cli.chat import (
    ChatConfig,
    ChatREPL,
    PlainPrinter,
    run_chat,
)
from persona.cli.main import build_parser


# ── Fakes / helpers ─────────────────────────────────────────────


@dataclass
class _ToolCall:
    """Mimics :class:`concinno.agent.session_loop.ToolCall`."""

    id: str
    name: str
    arguments: dict[str, Any] = field(default_factory=dict)


@dataclass
class _Response:
    """Mimics :class:`concinno.agent.session_loop.LLMResponse`."""

    text: str = ""
    tool_calls: tuple[_ToolCall, ...] = ()
    stop_reason: str = "end_turn"


class _MockDriver:
    """Scriptable LLMDriver double.

    ``script`` is a list of :class:`_Response` returned in order, one
    per ``complete()`` call. The driver records every call's
    ``messages`` argument so tests can assert on history shape.
    """

    model_id = "mock-model-1"

    def __init__(self, script: list[_Response]) -> None:
        self.script = list(script)
        self.calls: list[list[dict[str, Any]]] = []
        self.kwargs_seen: list[dict[str, Any]] = []

    def complete(
        self,
        messages: list[dict[str, Any]],
        tools: list[dict[str, Any]] | None = None,
        **kwargs: Any,
    ) -> _Response:
        self.calls.append([dict(m) for m in messages])
        self.kwargs_seen.append(dict(kwargs))
        if not self.script:
            return _Response(text="(script exhausted)", stop_reason="end_turn")
        return self.script.pop(0)


class _RecordingPrinter(PlainPrinter):
    """PlainPrinter that captures everything to a list."""

    def __init__(self) -> None:
        self.lines: list[str] = []

    def print(self, *args: Any, **kwargs: Any) -> None:
        kwargs.pop("style", None)
        kwargs.pop("highlight", None)
        self.lines.append(" ".join(str(a) for a in args))

    def rule(self, title: str = "", **_: Any) -> None:
        self.lines.append(f"--rule:{title}--")


# ── argparse smoke ─────────────────────────────────────────────


def test_parser_builds_with_chat_subcommand() -> None:
    """``sancio chat --help`` parses without error and exposes flags."""
    parser = build_parser()
    # argparse exits on --help; just verify the subcommand is reachable.
    args = parser.parse_args(["chat", "--driver", "mock", "--max-rounds", "3"])
    assert args.command == "chat"
    assert args.driver == "mock"
    assert args.max_rounds == 3
    assert hasattr(args, "func")


def test_parser_chat_default_flags() -> None:
    """Default flags resolve to documented values."""
    parser = build_parser()
    args = parser.parse_args(["chat"])
    assert args.driver == "anthropic"
    assert args.max_rounds == 8
    assert args.no_scan is False
    assert args.no_rich is False


# ── Driver injection + round-trip ──────────────────────────────


def test_one_round_chat_with_mock_driver() -> None:
    """A single user turn → driver.complete called once → text echoed."""
    driver = _MockDriver([_Response(text="hello back", stop_reason="end_turn")])
    repl = ChatREPL(
        config=ChatConfig(driver=driver, scan_input=False, use_rich=False),
        printer=_RecordingPrinter(),
    )
    rc = repl.run(input_lines=["hi there", "/exit"])
    assert rc == 0
    assert len(driver.calls) == 1
    # History: user → assistant
    assert repl.messages[0]["role"] == "user"
    assert repl.messages[0]["content"] == "hi there"
    assert repl.messages[-1]["role"] == "assistant"
    assert repl.messages[-1]["content"] == "hello back"


def test_multi_round_chat_three_turns() -> None:
    """Three user turns → three driver calls → six messages in history."""
    driver = _MockDriver(
        [
            _Response(text="reply-1"),
            _Response(text="reply-2"),
            _Response(text="reply-3"),
        ]
    )
    repl = ChatREPL(
        config=ChatConfig(driver=driver, scan_input=False, use_rich=False),
        printer=_RecordingPrinter(),
    )
    repl.run(input_lines=["q1", "q2", "q3", "/exit"])
    assert len(driver.calls) == 3
    # 3 user + 3 assistant turns
    assert len(repl.messages) == 6
    assert [m["role"] for m in repl.messages] == [
        "user",
        "assistant",
        "user",
        "assistant",
        "user",
        "assistant",
    ]


# ── Tool-use round-trip ────────────────────────────────────────


def test_tool_call_round_trip() -> None:
    """tool_use → callback dispatched → result block fed back → final text."""
    tool_call = _ToolCall(id="call-1", name="echo", arguments={"text": "ping"})
    driver = _MockDriver(
        [
            _Response(
                text="thinking...",
                tool_calls=(tool_call,),
                stop_reason="tool_use",
            ),
            _Response(text="echo result was: ping"),
        ]
    )
    callback_seen: list[dict[str, Any]] = []

    def echo_cb(args: dict[str, Any]) -> str:
        callback_seen.append(args)
        return f"echo:{args['text']}"

    repl = ChatREPL(
        config=ChatConfig(driver=driver, scan_input=False, use_rich=False),
        printer=_RecordingPrinter(),
        tool_callbacks={"echo": echo_cb},
    )
    repl.run(input_lines=["use the tool", "/exit"])
    assert len(driver.calls) == 2
    assert callback_seen == [{"text": "ping"}]
    # The 2nd driver call must see the tool_result block in history.
    second_call = driver.calls[1]
    last_user = second_call[-1]
    assert last_user["role"] == "user"
    assert isinstance(last_user["content"], list)
    assert last_user["content"][0]["type"] == "tool_result"
    assert last_user["content"][0]["content"] == "echo:ping"


# ── Slash commands ─────────────────────────────────────────────


def test_slash_exit_returns_zero() -> None:
    """``/exit`` terminates the loop with rc=0."""
    driver = _MockDriver([])
    repl = ChatREPL(
        config=ChatConfig(driver=driver, scan_input=False, use_rich=False),
        printer=_RecordingPrinter(),
    )
    rc = repl.run(input_lines=["/exit"])
    assert rc == 0
    assert driver.calls == []  # nothing sent to the LLM


def test_slash_clear_resets_history() -> None:
    """``/clear`` empties messages mid-session."""
    driver = _MockDriver([_Response(text="ok")])
    repl = ChatREPL(
        config=ChatConfig(driver=driver, scan_input=False, use_rich=False),
        printer=_RecordingPrinter(),
    )
    repl.run(input_lines=["hello", "/clear", "/exit"])
    # After /clear the history is empty (the final /exit doesn't add).
    assert repl.messages == []


def test_slash_help_lists_commands() -> None:
    """``/help`` emits a line for each registered slash."""
    printer = _RecordingPrinter()
    repl = ChatREPL(
        config=ChatConfig(driver=_MockDriver([]), scan_input=False, use_rich=False),
        printer=printer,
    )
    repl.run(input_lines=["/help", "/exit"])
    helped = "\n".join(printer.lines)
    assert "/exit" in helped
    assert "/clear" in helped
    assert "/help" in helped


def test_slash_unknown_command_warns() -> None:
    """Unknown ``/foo`` warns but does not crash."""
    printer = _RecordingPrinter()
    repl = ChatREPL(
        config=ChatConfig(driver=_MockDriver([]), scan_input=False, use_rich=False),
        printer=printer,
    )
    repl.run(input_lines=["/foo", "/exit"])
    out = "\n".join(printer.lines)
    assert "unknown command" in out


# ── Concinno integration smoke ─────────────────────────────────


def test_prompt_engine_integration_does_not_crash() -> None:
    """The system-prompt assembly path runs without raising.

    We don't assert on the exact prompt because PromptEngine output
    depends on workspace state; we only assert the kwargs reach the
    driver (or that the driver was called at all when the engine
    falls back silently).
    """
    driver = _MockDriver([_Response(text="ok")])
    repl = ChatREPL(
        config=ChatConfig(
            driver=driver, scan_input=False, use_rich=False, system=None
        ),
        printer=_RecordingPrinter(),
    )
    repl.run(input_lines=["hello", "/exit"])
    assert len(driver.calls) == 1
    # When PromptEngine succeeds, kwargs["system"] is set; when it
    # falls back silently, kwargs is empty. Both branches are valid.
    seen = driver.kwargs_seen[0]
    assert "system" in seen or seen == {}


def test_explicit_system_prompt_passes_through() -> None:
    """``ChatConfig.system`` overrides PromptEngine path."""
    driver = _MockDriver([_Response(text="ok")])
    repl = ChatREPL(
        config=ChatConfig(
            driver=driver,
            scan_input=False,
            use_rich=False,
            system="custom system",
        ),
        printer=_RecordingPrinter(),
    )
    repl.run(input_lines=["hi", "/exit"])
    assert driver.kwargs_seen[0]["system"] == "custom system"


# ── PII guard ──────────────────────────────────────────────────


def test_pii_guard_warns_but_does_not_block(
    capsys: pytest.CaptureFixture[str],
) -> None:
    """A user message containing an SSN is sent + flagged on stderr."""
    driver = _MockDriver([_Response(text="ack")])
    repl = ChatREPL(
        config=ChatConfig(driver=driver, scan_input=True, use_rich=False),
        printer=_RecordingPrinter(),
    )
    repl.run(input_lines=["my ssn is 123-45-6789", "/exit"])
    err = capsys.readouterr().err
    # The message was forwarded regardless.
    assert len(driver.calls) == 1
    # Either the guard warned, or Concinno is unavailable (silent
    # fallback). Both outcomes are documented behaviour.
    assert "pii_guard" in err or err == ""


# ── Rich fallback ──────────────────────────────────────────────


def test_plain_printer_when_rich_disabled() -> None:
    """``use_rich=False`` keeps the PlainPrinter even when rich exists."""
    driver = _MockDriver([_Response(text="hi")])
    repl = ChatREPL(
        config=ChatConfig(driver=driver, scan_input=False, use_rich=False),
        printer=PlainPrinter(),
    )
    assert isinstance(repl.printer, PlainPrinter)
    repl.run(input_lines=["q", "/exit"])


def test_plain_printer_print_drops_rich_kwargs(
    capsys: pytest.CaptureFixture[str],
) -> None:
    """PlainPrinter.print swallows ``style`` / ``highlight`` kwargs."""
    p = PlainPrinter()
    p.print("hello", style="bold red", highlight=True)
    out = capsys.readouterr().out
    assert "hello" in out


# ── run_chat helper ────────────────────────────────────────────


def test_run_chat_helper_returns_zero_on_clean_exit() -> None:
    """``run_chat`` is a thin wrapper that returns the REPL's rc."""
    # ChatConfig.driver is None — the helper attempts registry resolve
    # only when a turn fires. ``/exit`` exits before the first turn,
    # so this test is safe even if no driver is registered.
    rc = run_chat(
        config=ChatConfig(use_rich=False, scan_input=False),
        input_lines=["/exit"],
    )
    assert rc == 0


# ── Existing CLI regression ────────────────────────────────────


def test_existing_self_update_subcommand_still_parses() -> None:
    """Adding ``chat`` must not break ``sancio self-update --help``."""
    parser = build_parser()
    args = parser.parse_args(["self-update", "--dry-run"])
    assert args.command == "self-update"
    assert args.dry_run is True


def test_existing_gui_subcommand_still_parses() -> None:
    """``sancio gui`` remains reachable through the umbrella parser."""
    parser = build_parser()
    args = parser.parse_args(["gui"])
    assert args.command == "gui"


# ── EOF / signal handling ──────────────────────────────────────


def test_eof_returns_zero() -> None:
    """Empty input_lines (StopIteration) is treated as EOF → rc=0."""
    repl = ChatREPL(
        config=ChatConfig(driver=_MockDriver([]), scan_input=False, use_rich=False),
        printer=_RecordingPrinter(),
    )
    rc = repl.run(input_lines=[])
    assert rc == 0
