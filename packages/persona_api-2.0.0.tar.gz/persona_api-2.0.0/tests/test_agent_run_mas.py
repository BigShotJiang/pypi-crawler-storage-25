"""Tests for MAS dispatch on ``POST /v1/agent/run`` (Sancio 0.4.0).

Surface under test
------------------

* ``mas_config=None`` → SAS path unchanged (regression).
* ``mas_config={...}`` → ``_run_mas`` dispatched.
* ``mas_config={"vote": "majority"}`` → 400 via Pydantic Literal.
* ``mas_config={"rolez": ...}`` (typo) → 400 via ``extra="forbid"``.
* ``SANCIO_MAS_ENABLED=0`` + ``mas_config`` present → 503 +
  ``Retry-After`` header.
* 3-role happy path emits ``role_start`` / ``role_end`` / ``vote``
  events on top of the existing ``token`` / ``done`` stream.

All tests are hermetic — the module-level LLM adapter is swapped
with a scripted fake so solver + critic + judge roles each draw a
deterministic reply, and no real Ollama / Anthropic call happens.
"""

from __future__ import annotations

import json
from collections.abc import Iterator
from typing import Any

import pytest
from starlette.testclient import TestClient

from persona import agent_api
from persona.api import create_standalone_app
from persona.engine.agent_loop import LLMResponse


# ── Fixtures ─────────────────────────────────────


@pytest.fixture()
def client() -> Iterator[TestClient]:
    """Fresh standalone app per test — isolates module-level state."""
    app = create_standalone_app()
    with TestClient(app) as c:
        yield c
    agent_api.reset_llm_call()


@pytest.fixture()
def mas_enabled(monkeypatch: pytest.MonkeyPatch) -> Iterator[None]:
    """Force MAS on at dispatch time regardless of env."""
    monkeypatch.setattr(agent_api, "_MAS_ENABLED", True)
    monkeypatch.setattr(agent_api, "_MAS_MAX_ROLES", 3)
    yield


def _install_three_role_fake(
    solver_text: str = "FINAL ANSWER: 4",
    critic_text: str = "FINAL ANSWER: 3",
    judge_text: str = "FINAL ANSWER: 3",
) -> list[str]:
    """Install a fake that answers solver / critic / judge in order.

    Returns the same list of texts for assertion convenience. Call
    order is deterministic because ``_run_mas`` drives the three
    roles sequentially: solver first (tools allowed), then critic
    (text-only), then judge (text-only).
    """
    scripted = [solver_text, critic_text, judge_text]
    idx = {"i": 0}

    async def _call(
        messages: list[dict[str, Any]],
        schemas: list[dict[str, Any]],  # noqa: ARG001
    ) -> LLMResponse:
        i = idx["i"]
        idx["i"] = i + 1
        if i >= len(scripted):
            raise AssertionError(
                f"llm called {i + 1}x but only {len(scripted)} scripted",
            )
        return LLMResponse(content=scripted[i], tool_calls=[])

    agent_api.set_llm_call(_call)
    return scripted


def _parse_sse(body: str) -> list[tuple[str, str]]:
    events: list[tuple[str, str]] = []
    for block in body.strip().split("\n\n"):
        event = ""
        data_parts: list[str] = []
        for line in block.splitlines():
            if line.startswith("event:"):
                event = line.split(":", 1)[1].strip()
            elif line.startswith("data:"):
                data_parts.append(line.split(":", 1)[1].strip())
        if data_parts:
            events.append((event or "message", "\n".join(data_parts)))
    return events


# ── mas_config schema rejections ─────────────────


def test_mas_config_majority_rejected_400(client: TestClient) -> None:
    """``vote='majority'`` deferred to 0.5+ — rejected by Pydantic."""
    resp = client.post(
        "/v1/agent/run",
        json={
            "stack": "ccc",
            "model": "m",
            "messages": [{"role": "user", "content": "hi"}],
            "mas_config": {
                "roles": ["solver", "critic", "judge"],
                "vote": "majority",
            },
        },
    )
    assert resp.status_code == 400
    assert resp.json()["error"] == "invalid_field"


def test_mas_config_unknown_key_rejected_400(client: TestClient) -> None:
    """``extra='forbid'`` catches ``rolez`` typo at request-parse time."""
    resp = client.post(
        "/v1/agent/run",
        json={
            "stack": "ccc",
            "model": "m",
            "messages": [{"role": "user", "content": "hi"}],
            "mas_config": {
                "roles": ["solver"],
                "rolez": ["bogus"],  # typo
            },
        },
    )
    assert resp.status_code == 400
    assert resp.json()["error"] == "invalid_field"


# ── Kill-switch → 503 ────────────────────────────


def test_mas_disabled_returns_503(
    client: TestClient, monkeypatch: pytest.MonkeyPatch,
) -> None:
    """``SANCIO_MAS_ENABLED=0`` + ``mas_config`` set → 503 + Retry-After."""
    monkeypatch.setattr(agent_api, "_MAS_ENABLED", False)

    resp = client.post(
        "/v1/agent/run",
        json={
            "stack": "ccc",
            "model": "m",
            "messages": [{"role": "user", "content": "hi"}],
            "mas_config": {"roles": ["solver", "critic", "judge"]},
        },
    )
    assert resp.status_code == 503
    assert resp.headers.get("Retry-After") == "3600"
    body = resp.json()
    assert body["error"] == "mas_disabled"
    assert "request_id" in body


def test_mas_disabled_does_not_affect_sas_path(
    client: TestClient, monkeypatch: pytest.MonkeyPatch,
) -> None:
    """With MAS off, the SAS path (no ``mas_config``) still streams 200."""
    monkeypatch.setattr(agent_api, "_MAS_ENABLED", False)

    # SAS uses the module-level adapter for its own one-shot reply.
    async def _call(
        messages: list[dict[str, Any]],
        schemas: list[dict[str, Any]],  # noqa: ARG001
    ) -> LLMResponse:
        return LLMResponse(content="sas-ok", tool_calls=[])

    agent_api.set_llm_call(_call)

    resp = client.post(
        "/v1/agent/run",
        json={
            "stack": "ccc",
            "model": "m",
            "messages": [{"role": "user", "content": "hi"}],
        },
    )
    assert resp.status_code == 200
    assert resp.headers["content-type"].startswith("text/event-stream")


# ── Regression: SAS path byte-identical when mas_config is absent ──


def test_sas_regression_no_new_events(client: TestClient) -> None:
    """Without ``mas_config`` the SSE stream carries no MAS events."""

    async def _call(
        messages: list[dict[str, Any]],
        schemas: list[dict[str, Any]],  # noqa: ARG001
    ) -> LLMResponse:
        return LLMResponse(content="classic-sas", tool_calls=[])

    agent_api.set_llm_call(_call)

    resp = client.post(
        "/v1/agent/run",
        json={
            "stack": "ccc",
            "model": "m",
            "messages": [{"role": "user", "content": "hi"}],
        },
    )
    assert resp.status_code == 200
    events = _parse_sse(resp.text)
    kinds = {ev for ev, _ in events}
    # Legacy events present, MAS events absent.
    assert "token" in kinds
    assert "done" in kinds
    assert "role_start" not in kinds
    assert "role_end" not in kinds
    assert "vote" not in kinds


# ── Happy path: 3-role MAS dispatch ──────────────


def test_mas_happy_path_emits_role_events(
    client: TestClient, mas_enabled: None,
) -> None:
    """Three scripted LLM replies drive solver / critic / judge in order."""
    _install_three_role_fake()

    resp = client.post(
        "/v1/agent/run",
        json={
            "stack": "ccc",
            "model": "m",
            "messages": [{"role": "user", "content": "riddle"}],
            "mas_config": {
                "roles": ["solver", "critic", "judge"],
                "vote": "judge",
            },
        },
    )
    assert resp.status_code == 200

    events = _parse_sse(resp.text)
    kinds = [ev for ev, _ in events]
    # Three role_start + three role_end + one vote + terminal done.
    assert kinds.count("role_start") == 3
    assert kinds.count("role_end") == 3
    assert kinds.count("vote") == 1
    assert kinds[-1] == "done"

    # ``done`` envelope flags ``mas=True`` so benchmark runners can
    # attribute spend to the MAS path.
    done_payload = json.loads(events[-1][1])
    assert done_payload["usage"].get("mas") is True

    # Vote event carries audit_mapping for un-blinding.
    vote_payload = json.loads(
        next(d for ev, d in events if ev == "vote"),
    )
    assert "audit_mapping" in vote_payload
    assert set(vote_payload["audit_mapping"].keys()) == {
        "response_1", "response_2",
    }


def test_mas_role_seeds_offset_by_plus_one_and_two(
    client: TestClient, mas_enabled: None,
) -> None:
    """Seeds derived +0/+1/+2 from outer ``provider_extra.seed``.

    The solver call path wraps ``_llm_call`` through the tool-use
    branch, whereas critic/judge go through the text-only path. We
    capture ``_model_extra`` from each call so the test can assert
    all three seeds landed distinctly.
    """
    seen_seeds: list[int] = []

    async def _call(
        messages: list[dict[str, Any]],
        schemas: list[dict[str, Any]],  # noqa: ARG001
    ) -> LLMResponse:
        for m in messages:
            extra = m.get("_model_extra")
            if isinstance(extra, dict) and "seed" in extra:
                seen_seeds.append(int(extra["seed"]))
                break
        return LLMResponse(content="FINAL ANSWER: x", tool_calls=[])

    agent_api.set_llm_call(_call)

    resp = client.post(
        "/v1/agent/run",
        json={
            "stack": "ccc",
            "model": "m",
            "messages": [{"role": "user", "content": "hi"}],
            "mas_config": {"roles": ["solver", "critic", "judge"]},
            "provider_extra": {"seed": 42},
        },
    )
    assert resp.status_code == 200
    # Solver = 42, critic = 43, judge = 44 — order-preserving because
    # ``_run_mas`` dispatches roles sequentially.
    assert seen_seeds[:3] == [42, 43, 44]
