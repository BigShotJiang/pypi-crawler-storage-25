"""P0#1 Task 2 — built-in tools run inside the tenant workspace root.

Pre-P0 ``_build_tool_registry()`` passed ``root=None`` to every
filesystem / bash tool so a successful prompt injection would let
the LLM ``write_file("/etc/shadow", ...)`` or
``run_bash("cat /etc/shadow")``. These tests verify the tenant
sub-directory is honoured:

* ``WriteFileTool.execute`` rejects writes that escape the sandbox.
* ``ReadFileTool.execute`` rejects reads that escape the sandbox.
* ``RunBashTool`` carries the sandbox cwd.
* ``_tenant_workspace_root`` sanitises traversal attempts in the
  tenant_id and collapses them back to ``default``.
"""

from __future__ import annotations

from pathlib import Path

import pytest

from persona.agent_api import (
    _build_tool_registry,
    _safe_tenant_id,
    _tenant_workspace_root,
)


@pytest.fixture()
def workspace(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch,
) -> Path:
    monkeypatch.setenv("SANCIO_WORKSPACE_ROOT", str(tmp_path))
    return tmp_path


def test_build_tool_registry_scopes_tools_to_tenant(
    workspace: Path,
) -> None:
    """Every filesystem tool resolves ``root`` under the tenant dir."""
    tools = _build_tool_registry(tenant_id="alice")
    tenant_root = workspace / "alice"
    assert tenant_root.exists()

    # Each sandbox-aware tool should track the tenant root. The
    # attribute is `_root` on the fs tools, `_cwd` on RunBashTool.
    assert tools["read_file"]._root.resolve() == tenant_root.resolve()
    assert tools["write_file"]._root.resolve() == tenant_root.resolve()
    assert tools["edit_file"]._root.resolve() == tenant_root.resolve()
    assert tools["list_files"]._root.resolve() == tenant_root.resolve()
    assert tools["search_files"]._root.resolve() == tenant_root.resolve()
    assert tools["run_bash"]._cwd.resolve() == tenant_root.resolve()


def test_write_file_cannot_escape_sandbox(workspace: Path) -> None:
    """WriteFileTool should raise on ``../`` escape attempts."""
    import asyncio

    tools = _build_tool_registry(tenant_id="alice")
    wf = tools["write_file"]

    async def _go() -> None:
        with pytest.raises(PermissionError):
            await wf.execute({
                "path": "../../etc/shadow",
                "content": "pwned",
            })

    asyncio.run(_go())


def test_read_file_cannot_escape_sandbox(workspace: Path) -> None:
    """ReadFileTool should refuse reads outside the tenant root."""
    import asyncio

    tools = _build_tool_registry(tenant_id="alice")
    rf = tools["read_file"]

    async def _go() -> None:
        with pytest.raises(PermissionError):
            await rf.execute({"path": "../../../etc/passwd"})

    asyncio.run(_go())


def test_different_tenants_get_different_roots(
    workspace: Path,
) -> None:
    """Tenant isolation: alice's root != bob's root."""
    tools_a = _build_tool_registry(tenant_id="alice")
    tools_b = _build_tool_registry(tenant_id="bob")
    assert tools_a["read_file"]._root != tools_b["read_file"]._root


def test_tenant_id_traversal_collapses_to_default(
    workspace: Path,
) -> None:
    """Malicious tenant_id like ``../../etc`` must not escape base."""
    p = _tenant_workspace_root("../../etc")
    # After sanitise, ``..`` → ``_``, result is within the base
    # workspace. Belt-and-braces: the dir is under ``workspace``.
    assert p.is_relative_to(workspace)


def test_safe_tenant_id_rejects_separators() -> None:
    """``_safe_tenant_id`` strips path separators + dot-dot."""
    assert _safe_tenant_id("") == "default"
    assert _safe_tenant_id("a/b") == "ab"
    assert _safe_tenant_id("..") == "_"  # ``..`` replaced with ``_``
    assert _safe_tenant_id("a_b.c-1") == "a_b.c-1"
    # Overly long tenant_id gets clipped to 64.
    long = "x" * 500
    assert len(_safe_tenant_id(long)) == 64


def test_tenant_root_is_created_on_demand(workspace: Path) -> None:
    """First call to ``_tenant_workspace_root`` creates the sub-dir."""
    tenant = "newtenant"
    assert not (workspace / tenant).exists()
    p = _tenant_workspace_root(tenant)
    assert p.exists()
    assert p == (workspace / tenant).resolve()
