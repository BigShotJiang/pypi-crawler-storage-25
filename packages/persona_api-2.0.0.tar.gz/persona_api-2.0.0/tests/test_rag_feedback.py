"""Tests for PersonaRAG.feedback() bucket reward flow.

These cover the M1 follow-up fix: feedback() was a best-effort
substring stub (``st in text.lower()``) that happened to never be
called by engine.py because of a dead `_rag is not None` guard. The
fix points engine.chat() at the ``self.rag`` property (triggering
lazy init) and rewrites feedback() to read ``source_type`` from the
result dicts populated by search() itself.

We cannot easily run the full engine+chromadb path here, so the
contract is tested at the PersonaRAG level: feedback() must read
``source_type`` from hit dicts, not run substring guesses on text.
"""

from __future__ import annotations

import json
from pathlib import Path

import pytest

from persona.rag import (
    SOURCE_TYPES,
    PersonaRAG,
    _load_weights,
)


@pytest.fixture
def rag(tmp_path: Path) -> PersonaRAG:
    return PersonaRAG(cache_dir=str(tmp_path / "rag"))


def test_feedback_reads_source_type_not_substring(rag: PersonaRAG) -> None:
    """source_type is authoritative even if text has no bucket keyword."""
    hits = [
        {"text": "Totally unrelated to any bucket name",
         "source_type": "persona_data"},
        {"text": "Another neutral snippet",
         "source_type": "emotion"},
    ]
    rag.feedback(hits)

    weights = _load_weights(rag._weights_path)
    # Both the persona_data and emotion weights should have moved
    # off the 1.0 baseline. The other two stay at 1.0.
    assert weights["persona_data"] != pytest.approx(1.0)
    assert weights["emotion"] != pytest.approx(1.0)
    assert weights["memory"] == pytest.approx(1.0)
    assert weights["knowledge"] == pytest.approx(1.0)


def test_feedback_ignores_hits_without_source_type(
    rag: PersonaRAG,
) -> None:
    """Hits that never went through search() lack source_type."""
    hits = [{"text": "raw text, no bucket tag"}]
    rag.feedback(hits)

    weights = _load_weights(rag._weights_path)
    for bucket in SOURCE_TYPES:
        assert weights[bucket] == pytest.approx(1.0)


def test_feedback_empty_list_noop(rag: PersonaRAG) -> None:
    rag.feedback([])
    assert not rag._weights_path.exists()


def test_feedback_idempotent_per_bucket(rag: PersonaRAG) -> None:
    """Multiple hits from the same bucket collapse to one nudge.

    Prevents top_k-heavy queries from exploding one bucket's weight.
    """
    single = [{"text": "x", "source_type": "memory"}]
    rag.feedback(single)
    w_after_one = _load_weights(rag._weights_path)["memory"]

    # Reset weights file and fire 3 hits from the same bucket in one call.
    rag._weights_path.write_text(
        json.dumps({st: 1.0 for st in SOURCE_TYPES}),
        encoding="utf-8",
    )
    three_same = [
        {"text": f"x{i}", "source_type": "memory"} for i in range(3)
    ]
    rag.feedback(three_same)
    w_after_three = _load_weights(rag._weights_path)["memory"]

    assert w_after_three == pytest.approx(w_after_one)


def test_feedback_unknown_source_type_silently_skipped(
    rag: PersonaRAG,
) -> None:
    """Forward-compat: CCC might add a bucket Aegis doesn't know yet."""
    hits = [{"text": "t", "source_type": "FROM_THE_FUTURE"}]
    rag.feedback(hits)

    weights = _load_weights(rag._weights_path)
    for bucket in SOURCE_TYPES:
        assert weights[bucket] == pytest.approx(1.0)
