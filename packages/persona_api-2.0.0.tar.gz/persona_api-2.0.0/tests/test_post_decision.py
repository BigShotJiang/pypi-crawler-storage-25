"""Unit tests for :mod:`persona.hooks.post_decision` (Sancio 2.0.0).

Covers the dataclass contract and exception surface introduced for
the **Option C reframe** of the L6 PostToolUse design conflict (see
``_AI_BRAIN/05_Planning/2026-05-01-l6-posttooluse-design-conflict-options.md``).
The agent-loop integration tests live in
:mod:`tests.test_agent_loop` — these tests are intentionally
narrow: dataclass shape, frozen guarantee, exception inheritance,
exception payload round-trip.
"""

from __future__ import annotations

import dataclasses

import pytest

from persona.hooks.post_decision import (
    PostToolDeny,
    PostToolUseBlocked,
    PostToolUseDecision,
)


def test_post_decision_default_construction() -> None:
    """All fields default to ``None`` so a hook can express any subset."""
    decision = PostToolUseDecision()
    assert decision.updated_output is None
    assert decision.additional_context is None
    assert decision.decision is None
    assert decision.reason is None


def test_post_decision_full_construction() -> None:
    """All four CC-parity fields are accepted via keyword arg."""
    decision = PostToolUseDecision(
        updated_output={"redacted": True},
        additional_context="\n[note: credentials stripped]",
        decision="block",
        reason="contains api key",
    )
    assert decision.updated_output == {"redacted": True}
    assert decision.additional_context == "\n[note: credentials stripped]"
    assert decision.decision == "block"
    assert decision.reason == "contains api key"


def test_post_decision_is_frozen() -> None:
    """Decisions flow as immutable values across the post-hook chain.

    Frozen-ness is the guarantee that a decision returned from hook A
    cannot be silently mutated by hook B's reference; the loop applies
    each decision atomically.
    """
    decision = PostToolUseDecision(updated_output="x")
    with pytest.raises(dataclasses.FrozenInstanceError):
        decision.updated_output = "y"  # type: ignore[misc]
    with pytest.raises(dataclasses.FrozenInstanceError):
        decision.decision = "block"  # type: ignore[misc]


def test_post_decision_is_dataclass() -> None:
    """Sanity: it really is a dataclass — supports ``fields()``."""
    field_names = {f.name for f in dataclasses.fields(PostToolUseDecision)}
    assert field_names == {
        "updated_output",
        "additional_context",
        "decision",
        "reason",
    }


def test_post_decision_repr_contains_class_name() -> None:
    """``repr`` is the dataclass default — useful for test failure output."""
    decision = PostToolUseDecision(decision="block", reason="oops")
    text = repr(decision)
    assert "PostToolUseDecision" in text
    assert "block" in text
    assert "oops" in text


def test_post_decision_equality_is_value_based() -> None:
    """Default dataclass eq: same fields → equal."""
    a = PostToolUseDecision(updated_output="x", reason="r")
    b = PostToolUseDecision(updated_output="x", reason="r")
    c = PostToolUseDecision(updated_output="x", reason="different")
    assert a == b
    assert a != c


def test_post_tool_use_blocked_inherits_exception() -> None:
    """``PostToolUseBlocked`` is a real ``Exception`` subclass."""
    assert issubclass(PostToolUseBlocked, Exception)


def test_post_tool_use_blocked_carries_reason() -> None:
    """The reason string round-trips via ``str(exc)``."""
    exc = PostToolUseBlocked("policy_violation: api_key leak")
    assert str(exc) == "policy_violation: api_key leak"


def test_post_tool_deny_inherits_exception() -> None:
    """``PostToolDeny`` is a real ``Exception`` subclass."""
    assert issubclass(PostToolDeny, Exception)


def test_post_tool_deny_distinct_from_blocked() -> None:
    """Two distinct exception classes — agent_loop catches them separately.

    The reframe (Option C) splits the deny path:
    * ``PostToolUseBlocked`` — synthesised twin of ``decision="block"``
    * ``PostToolDeny`` — direct-raise from Cerno when its verdict denies
    """
    assert PostToolDeny is not PostToolUseBlocked
    assert not issubclass(PostToolDeny, PostToolUseBlocked)
    assert not issubclass(PostToolUseBlocked, PostToolDeny)


def test_post_tool_deny_carries_reason() -> None:
    """``PostToolDeny`` round-trips its reason string via ``str(exc)``."""
    exc = PostToolDeny("cerno deny: drift_too_high")
    assert str(exc) == "cerno deny: drift_too_high"


def test_post_decision_arbitrary_updated_output_types() -> None:
    """``updated_output`` accepts any type — JSON-serialised at use site."""
    for sample in [
        "string",
        42,
        {"key": "value"},
        [1, 2, 3],
        None,  # explicit None still allowed (no rewrite)
    ]:
        decision = PostToolUseDecision(updated_output=sample)
        assert decision.updated_output == sample
