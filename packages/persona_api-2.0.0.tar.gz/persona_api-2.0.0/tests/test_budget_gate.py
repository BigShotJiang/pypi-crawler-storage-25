"""P0#1 Task 3 — per-user Anthropic budget gate regression tests.

Verifies that :class:`persona.budget.BudgetGate`:

* charges USD proportional to token counts + configurable rate.
* rejects a pre-check that would push spend over the daily cap.
* surfaces a 429 ``BudgetExceeded`` with ``retry_after`` + ``window``.
* persists spend across ``BudgetGate`` instances (SQLite-backed).
* prune_old wipes historical rows.
"""

from __future__ import annotations

from pathlib import Path

import pytest

from persona.budget import BudgetExceeded, BudgetGate


@pytest.fixture()
def gate(tmp_path: Path) -> BudgetGate:
    """BudgetGate against an isolated SQLite file + tight caps."""
    return BudgetGate(
        db_path=str(tmp_path / "budget.db"),
        daily_cap_usd=1.0,
        monthly_cap_usd=5.0,
        usd_per_1k_tokens=0.10,  # $0.10 / 1k tokens
    )


def test_fresh_user_has_zero_spend(gate: BudgetGate) -> None:
    s = gate.get_spend("alice")
    assert s.daily_usd == 0.0
    assert s.monthly_usd == 0.0
    assert s.daily_cap == 1.0


def test_record_tokens_accumulates_usd(gate: BudgetGate) -> None:
    gate.record("alice", actual_tokens=1000)  # $0.10
    s = gate.get_spend("alice")
    assert s.daily_usd == pytest.approx(0.10, abs=1e-6)
    assert s.monthly_usd == pytest.approx(0.10, abs=1e-6)


def test_daily_cap_blocks_check(gate: BudgetGate) -> None:
    """Spending up to the cap + a fresh estimated call → 429."""
    # Burn $0.90 first (under cap).
    gate.record("alice", actual_tokens=9_000)
    # Now estimate a 5k-token call = $0.50 → projected $1.40 > $1.00.
    with pytest.raises(BudgetExceeded) as ei:
        gate.check("alice", estimated_tokens=5_000)
    assert ei.value.code == 429
    assert ei.value.window == "daily"
    assert ei.value.retry_after > 0
    assert ei.value.cap_usd == pytest.approx(1.0)


def test_under_cap_check_passes(gate: BudgetGate) -> None:
    """A cheap call under the cap returns normally."""
    spend = gate.check("alice", estimated_tokens=500)  # $0.05
    assert spend.daily_usd == 0.0


def test_user_isolation(gate: BudgetGate) -> None:
    """Alice blowing her cap does NOT block Bob."""
    gate.record("alice", actual_tokens=20_000)  # $2.00, over daily cap
    # Bob is pristine.
    bob = gate.get_spend("bob")
    assert bob.daily_usd == 0.0
    # Bob's small call should NOT raise.
    gate.check("bob", estimated_tokens=500)


def test_zero_tokens_record_is_noop(gate: BudgetGate) -> None:
    """Providers sometimes return 0 usage on cached hits — we don't
    want that to silently accrue."""
    gate.record("alice", actual_tokens=0)
    assert gate.get_spend("alice").daily_usd == 0.0


def test_cost_usd_override_wins(gate: BudgetGate) -> None:
    """``cost_usd`` supersedes the token-based estimate."""
    gate.record("alice", actual_tokens=0, cost_usd=0.42)
    assert gate.get_spend("alice").daily_usd == pytest.approx(0.42)


def test_persistence_across_instances(tmp_path: Path) -> None:
    """Spend survives process restart (SQLite-backed)."""
    db = str(tmp_path / "persistent.db")
    g1 = BudgetGate(db_path=db, daily_cap_usd=1.0, monthly_cap_usd=5.0,
                    usd_per_1k_tokens=0.10)
    g1.record("alice", actual_tokens=1_000)

    g2 = BudgetGate(db_path=db, daily_cap_usd=1.0, monthly_cap_usd=5.0,
                    usd_per_1k_tokens=0.10)
    s = g2.get_spend("alice")
    assert s.daily_usd == pytest.approx(0.10)


def test_monthly_cap_blocks(gate: BudgetGate) -> None:
    """Back-dated records keep monthly counter running."""
    import time
    # Simulate 4 days of spend close to but under daily cap each.
    now = time.time()
    for day_offset in range(0, 4):
        gate.record(
            "alice", actual_tokens=9_000,
            now=now - day_offset * 86400,
        )
    # 9000 * 4 = 36k tokens × $0.10/1k = $3.60 spread across days.
    # Check against $5 monthly cap — a $2 estimate should still fit,
    # but a $1.50 one+already spent should fire.
    # Add one more $1 day-spend to push total to $4.60.
    gate.record("alice", actual_tokens=10_000)  # $1.00 today
    # Current day spend is $1.00 (== daily cap). A tiny estimate of
    # $0.01 flips daily over first, which is expected behaviour.
    with pytest.raises(BudgetExceeded):
        gate.check("alice", estimated_tokens=1_000)


def test_dict_row_factory_not_sqlite3_row(tmp_path: Path) -> None:
    """Regression: row_factory must NOT be ``sqlite3.Row``.

    ``sqlite3.Row`` is a C type bound to stdlib ``sqlite3.Cursor`` and
    crashes with ``TypeError: Row() argument 1 must be sqlite3.Cursor,
    not pysqlcipher3.dbapi2.Cursor`` when the sqlcipher branch is
    taken. Plain-sqlite deploys hit the dict factory too, so the bug
    is catchable without pysqlcipher3 installed.
    """
    import sqlite3

    from persona.budget import _connect

    conn = _connect(str(tmp_path / "budget.db"))
    try:
        assert conn.row_factory is not sqlite3.Row
        # Our factory yields dicts — round-trip a column access.
        conn.execute(
            "INSERT INTO budget_daily(user_id, day, tokens, usd, updated_at)"
            " VALUES (?, ?, ?, ?, ?)",
            ("alice", "2026-04-22", 1000, 0.5, 1.0),
        )
        row = conn.execute(
            "SELECT user_id, usd FROM budget_daily WHERE user_id = ?",
            ("alice",),
        ).fetchone()
        assert row is not None
        assert row["user_id"] == "alice"
        assert row["usd"] == 0.5
    finally:
        conn.close()


def test_prune_old_wipes_history(gate: BudgetGate) -> None:
    """`prune_old` deletes rows older than N days."""
    import time
    # Create a record 200 days ago.
    old = time.time() - 200 * 86400
    gate.record("alice", actual_tokens=1_000, now=old)
    # Prune everything older than 90d.
    removed = gate.prune_old(older_than_days=90)
    assert removed >= 1
