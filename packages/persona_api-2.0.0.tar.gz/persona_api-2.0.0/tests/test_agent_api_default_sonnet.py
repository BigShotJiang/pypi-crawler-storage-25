"""Tests for the default Sonnet model-hint resolver.

Covers the decision ladder in :func:`persona.agent_api._default_sonnet_model_hint`:

1. ``PERSONA_DEFAULT_SONNET_MODEL`` env override wins.
2. ``PERSONA_SKIP_SONNET_PROBE`` short-circuits to the 4.6 fallback.
3. Missing ``ANTHROPIC_API_KEY`` short-circuits to the 4.6 fallback.
4. Probe that lists a ``claude-sonnet-4-7*`` id upgrades to 4.7.
5. Probe that does not list a 4.7 id falls back to 4.6.
6. Probe HTTP 500 / exception falls back to 4.6.
7. Result is cached for the process; a manual reset re-probes.
8. Prefix matching accepts dated ids like ``claude-sonnet-4-7-20260801``.
"""

from __future__ import annotations

from collections.abc import Iterator
from typing import Any

import pytest

from persona import agent_api


@pytest.fixture(autouse=True)
def _clean_env_and_cache(
    monkeypatch: pytest.MonkeyPatch,
) -> Iterator[pytest.MonkeyPatch]:
    """Each test starts with no override / no probe skip / no api key."""
    monkeypatch.delenv("PERSONA_DEFAULT_SONNET_MODEL", raising=False)
    monkeypatch.delenv("PERSONA_SKIP_SONNET_PROBE", raising=False)
    monkeypatch.delenv("ANTHROPIC_API_KEY", raising=False)
    agent_api._reset_default_sonnet_cache()
    yield monkeypatch
    agent_api._reset_default_sonnet_cache()


class _FakeResponse:
    def __init__(self, status_code: int, payload: Any) -> None:
        self.status_code = status_code
        self._payload = payload

    def json(self) -> Any:
        return self._payload


def _install_fake_httpx(
    monkeypatch: pytest.MonkeyPatch,
    response: _FakeResponse | Exception,
    recorder: dict[str, Any] | None = None,
) -> None:
    """Patch ``httpx.get`` inside the helper to a scripted response.

    The helper does ``import httpx`` lazily, so we patch the real
    module rather than a name bound in ``agent_api``.
    """
    import httpx

    def _fake_get(url: str, **kwargs: Any) -> _FakeResponse:
        if recorder is not None:
            recorder["url"] = url
            recorder["kwargs"] = kwargs
        if isinstance(response, Exception):
            raise response
        return response

    monkeypatch.setattr(httpx, "get", _fake_get)


def test_env_override_wins(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("PERSONA_DEFAULT_SONNET_MODEL", "anthropic:custom-x")
    monkeypatch.setenv("ANTHROPIC_API_KEY", "sk-should-not-probe")

    def _should_not_be_called(*_a: Any, **_k: Any) -> None:
        raise AssertionError("probe must not run when override is set")

    import httpx
    monkeypatch.setattr(httpx, "get", _should_not_be_called)

    assert agent_api._default_sonnet_model_hint() == "anthropic:custom-x"


def test_skip_probe_env_forces_fallback(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setenv("PERSONA_SKIP_SONNET_PROBE", "1")
    monkeypatch.setenv("ANTHROPIC_API_KEY", "sk-would-probe")

    def _should_not_be_called(*_a: Any, **_k: Any) -> None:
        raise AssertionError("probe must not run when skip flag is set")

    import httpx
    monkeypatch.setattr(httpx, "get", _should_not_be_called)

    assert (
        agent_api._default_sonnet_model_hint()
        == "anthropic:claude-sonnet-4-6"
    )


def test_no_api_key_forces_fallback(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    # autouse fixture already cleared ANTHROPIC_API_KEY
    assert (
        agent_api._default_sonnet_model_hint()
        == "anthropic:claude-sonnet-4-6"
    )


def test_probe_finds_sonnet_47_exact_id(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setenv("ANTHROPIC_API_KEY", "sk-probe")
    recorder: dict[str, Any] = {}
    _install_fake_httpx(
        monkeypatch,
        _FakeResponse(
            200,
            {
                "data": [
                    {"id": "claude-opus-4-7"},
                    {"id": "claude-sonnet-4-7"},
                    {"id": "claude-sonnet-4-6"},
                ]
            },
        ),
        recorder,
    )
    assert (
        agent_api._default_sonnet_model_hint()
        == "anthropic:claude-sonnet-4-7"
    )
    # Verify wire contract the docs specify.
    assert recorder["url"] == "https://api.anthropic.com/v1/models"
    headers = recorder["kwargs"]["headers"]
    assert headers["x-api-key"] == "sk-probe"
    assert headers["anthropic-version"] == "2023-06-01"


def test_probe_prefix_matches_dated_id(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setenv("ANTHROPIC_API_KEY", "sk-probe")
    _install_fake_httpx(
        monkeypatch,
        _FakeResponse(
            200,
            {"data": [{"id": "claude-sonnet-4-7-20260801"}]},
        ),
    )
    assert (
        agent_api._default_sonnet_model_hint()
        == "anthropic:claude-sonnet-4-7"
    )


def test_probe_without_sonnet_47_falls_back(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setenv("ANTHROPIC_API_KEY", "sk-probe")
    _install_fake_httpx(
        monkeypatch,
        _FakeResponse(
            200,
            {
                "data": [
                    {"id": "claude-sonnet-4-6"},
                    {"id": "claude-opus-4-7"},
                    {"id": "claude-haiku-4-5-20251001"},
                ]
            },
        ),
    )
    assert (
        agent_api._default_sonnet_model_hint()
        == "anthropic:claude-sonnet-4-6"
    )


def test_probe_http_500_falls_back(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setenv("ANTHROPIC_API_KEY", "sk-probe")
    _install_fake_httpx(
        monkeypatch,
        _FakeResponse(500, {"error": "upstream"}),
    )
    assert (
        agent_api._default_sonnet_model_hint()
        == "anthropic:claude-sonnet-4-6"
    )


def test_probe_exception_falls_back(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setenv("ANTHROPIC_API_KEY", "sk-probe")
    _install_fake_httpx(monkeypatch, RuntimeError("connection refused"))
    assert (
        agent_api._default_sonnet_model_hint()
        == "anthropic:claude-sonnet-4-6"
    )


def test_probe_malformed_payload_falls_back(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setenv("ANTHROPIC_API_KEY", "sk-probe")
    _install_fake_httpx(
        monkeypatch,
        _FakeResponse(200, {"data": "not-a-list"}),
    )
    assert (
        agent_api._default_sonnet_model_hint()
        == "anthropic:claude-sonnet-4-6"
    )


def test_result_is_cached_within_process(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setenv("ANTHROPIC_API_KEY", "sk-probe")
    call_count = {"n": 0}

    def _counting_get(url: str, **kwargs: Any) -> _FakeResponse:
        call_count["n"] += 1
        return _FakeResponse(200, {"data": [{"id": "claude-sonnet-4-6"}]})

    import httpx
    monkeypatch.setattr(httpx, "get", _counting_get)

    first = agent_api._default_sonnet_model_hint()
    second = agent_api._default_sonnet_model_hint()
    third = agent_api._default_sonnet_model_hint()
    assert first == second == third == "anthropic:claude-sonnet-4-6"
    assert call_count["n"] == 1, "probe must run exactly once per process"

    agent_api._reset_default_sonnet_cache()
    agent_api._default_sonnet_model_hint()
    assert call_count["n"] == 2, "reset should allow a fresh probe"
