"""Integration tests for the provider-backed ``/v1/agent/run`` wiring.

The default LLM adapter for ``/v1/agent/run`` is
:func:`persona.agent_api._provider_backed_llm_call`, which routes
through :meth:`persona.engine.PersonaEngine._llm_via_provider` so every
call shares AppendOnlyLog + UsageStats telemetry with ``/v1/chat``.

Two layers of coverage here:

1. **Plumbing** — register a fake :class:`LLMProvider` on the engine's
   :class:`ProviderRegistry` and verify the endpoint actually dispatches
   through it (not the echo stub), including model-string parsing from
   the ``"<provider>:<model>"`` / ``"<provider>/<model>"`` wire.
2. **Live smoke (optional)** — when a local Ollama is reachable at
   ``http://127.0.0.1:11434`` we do one real round-trip to prove the
   adapter contract works end-to-end. Skipped otherwise so CI stays
   hermetic.
"""

from __future__ import annotations

import json
import os
import urllib.request
from collections.abc import AsyncIterator, Iterator

import pytest
from starlette.testclient import TestClient

from persona import agent_api, api
from persona.agent_api import (
    _provider_backed_llm_call,
    _split_model_string,
)
from persona.api import create_standalone_app
from persona.providers import ModelPolicy


# ── Fake provider for deterministic plumbing tests ─────────────


class _FakeProvider:
    """Minimal :class:`LLMProvider` that echoes the last user turn.

    Records calls for assertion so the test can prove the endpoint
    actually went through the registry and not the echo stub.
    """

    name = "fake"

    def __init__(self) -> None:
        self.last_usage = None
        self.calls: list[tuple[list[dict[str, str]], ModelPolicy]] = []

    async def generate(
        self,
        messages: list[dict[str, str]],
        policy: ModelPolicy,
    ) -> str:
        self.calls.append((list(messages), policy))
        last = next(
            (m for m in reversed(messages) if m.get("role") == "user"),
            None,
        )
        text = str(last.get("content", "")) if last else ""
        return f"fake({policy.model}):{text}"

    async def _empty_stream(self) -> AsyncIterator[str]:
        if False:  # pragma: no cover — protocol shape only
            yield ""

    def generate_stream(
        self,
        messages: list[dict[str, str]],
        policy: ModelPolicy,
    ) -> AsyncIterator[str]:
        return self._empty_stream()


@pytest.fixture()
def client_with_fake_provider() -> Iterator[tuple[TestClient, _FakeProvider]]:
    """Install a fake provider on the live engine, wire the real adapter."""
    fake = _FakeProvider()
    # pylint: disable=protected-access
    api._engine._provider_router.register_instance("fake", fake)
    # Force the production adapter path (create_standalone_app wires
    # this inside create_aegis_routes, but we install it ahead of
    # time too so the first request cannot fall through to the echo
    # stub if the app factory's wiring ever regresses).
    agent_api.set_llm_call(_provider_backed_llm_call(api._engine))

    app = create_standalone_app()
    with TestClient(app) as c:
        yield c, fake
    agent_api.reset_llm_call()


def _parse_sse(body: str) -> list[tuple[str, str]]:
    """Extract ``(event, data)`` pairs from an SSE body."""
    events: list[tuple[str, str]] = []
    for block in body.strip().split("\n\n"):
        event = ""
        data_parts: list[str] = []
        for line in block.splitlines():
            if line.startswith("event:"):
                event = line.split(":", 1)[1].strip()
            elif line.startswith("data:"):
                data_parts.append(line.split(":", 1)[1].strip())
        if data_parts:
            events.append((event or "message", "\n".join(data_parts)))
    return events


# ── Unit: model-string parsing ─────────────────────────────────


def test_split_model_string_colon_form() -> None:
    assert _split_model_string("anthropic:claude-sonnet-4-5") == (
        "anthropic", "claude-sonnet-4-5",
    )


def test_split_model_string_slash_form() -> None:
    assert _split_model_string("ollama/gemma4:latest") == (
        "ollama", "gemma4:latest",
    )


def test_split_model_string_bare_claude_infers_anthropic() -> None:
    assert _split_model_string("claude-opus-4-6") == (
        "anthropic", "claude-opus-4-6",
    )


def test_split_model_string_bare_gpt_infers_openai() -> None:
    assert _split_model_string("gpt-4o") == ("openai", "gpt-4o")


def test_split_model_string_bare_gemma_infers_ollama() -> None:
    assert _split_model_string("gemma4") == ("ollama", "gemma4")


def test_split_model_string_unknown_falls_back_to_anthropic() -> None:
    assert _split_model_string("mystery-model-7b") == (
        "anthropic", "mystery-model-7b",
    )


# ── Integration: fake provider round-trip via /v1/agent/run ────


def test_agent_run_dispatches_through_provider_registry(
    client_with_fake_provider: tuple[TestClient, _FakeProvider],
) -> None:
    """Endpoint hits the fake provider (not the echo stub) and
    surfaces its text in the final ``token`` frame."""
    client, fake = client_with_fake_provider

    resp = client.post(
        "/v1/agent/run",
        json={
            "stack": "ccc",
            "model": "fake:toy-v1",
            "messages": [{"role": "user", "content": "ping"}],
        },
    )
    assert resp.status_code == 200
    events = _parse_sse(resp.text)

    # The adapter stripped ``_model`` / ``_max_tokens`` and forwarded
    # to the provider exactly once with the parsed policy.
    assert len(fake.calls) == 1
    sent_messages, sent_policy = fake.calls[0]
    assert sent_policy.provider == "fake"
    assert sent_policy.model == "toy-v1"
    assert all("_model" not in m for m in sent_messages)
    assert all("_max_tokens" not in m for m in sent_messages)
    assert sent_messages[-1] == {"role": "user", "content": "ping"}

    # Terminal ``token`` frame carries the provider's text, not "echo:".
    token_frames = [d for ev, d in events if ev == "token"]
    assert token_frames
    payload = json.loads(token_frames[-1])
    assert payload["text"] == "fake(toy-v1):ping"
    assert not payload["text"].startswith("echo:")


def test_agent_run_default_provider_when_model_unprefixed(
    client_with_fake_provider: tuple[TestClient, _FakeProvider],
) -> None:
    """Unprefixed bare model string still reaches *some* provider.

    Bare ``claude-*`` infers ``anthropic``. We don't have a real
    anthropic key in CI — but we can assert the endpoint returns
    200 with an ``error`` SSE frame (ProviderError) rather than the
    old echo text. That proves the adapter is wired.
    """
    client, _fake = client_with_fake_provider

    resp = client.post(
        "/v1/agent/run",
        json={
            "stack": "ccc",
            "model": "claude-unknown-test-model",
            "messages": [{"role": "user", "content": "hi"}],
        },
    )
    assert resp.status_code == 200
    events = _parse_sse(resp.text)
    kinds = [ev for ev, _ in events]

    # Either the provider call failed (no key → error frame) or it
    # somehow succeeded (unlikely in CI). In both cases the response
    # must NOT be the ``echo: hi`` stub from the old wiring.
    all_text = " ".join(d for _, d in events)
    assert "echo: hi" not in all_text
    # One of these terminal frames must appear.
    assert "done" in kinds or "error" in kinds


# ── Optional live smoke: local Ollama ──────────────────────────


def _ollama_reachable() -> bool:
    """Best-effort probe of ``http://127.0.0.1:11434/api/tags``.

    Returns ``True`` only on a 200 with a parseable JSON payload.
    Any exception / non-200 returns ``False`` so the live smoke
    test skips cleanly on CI boxes without Ollama.
    """
    url = os.environ.get(
        "AEGIS_OLLAMA_SMOKE_URL",
        "http://127.0.0.1:11434/api/tags",
    )
    try:
        with urllib.request.urlopen(url, timeout=1.5) as r:  # noqa: S310
            if r.status != 200:
                return False
            json.loads(r.read().decode("utf-8", errors="replace"))
            return True
    except Exception:  # noqa: BLE001 — negative probe swallows all
        return False


@pytest.mark.skipif(
    not _ollama_reachable(),
    reason="local Ollama not reachable on 127.0.0.1:11434",
)
def test_agent_run_live_ollama_smoke() -> None:
    """Real round-trip to Ollama to prove the adapter works end-to-end.

    Only runs when a local Ollama daemon is up; otherwise skipped.
    Uses the smallest / fastest model we can assume exists — callers
    can override with ``AEGIS_OLLAMA_SMOKE_MODEL``.
    """
    model = os.environ.get("AEGIS_OLLAMA_SMOKE_MODEL", "llama3.2:1b")

    agent_api.set_llm_call(_provider_backed_llm_call(api._engine))
    app = create_standalone_app()
    with TestClient(app) as c:
        resp = c.post(
            "/v1/agent/run",
            json={
                "stack": "ccc",
                "model": f"ollama:{model}",
                "messages": [
                    {"role": "user", "content": "Say exactly: pong"},
                ],
                "max_iterations": 1,
            },
        )
    agent_api.reset_llm_call()

    assert resp.status_code == 200
    events = _parse_sse(resp.text)
    kinds = [ev for ev, _ in events]
    # Accept either ``done`` (model present + responded) or ``error``
    # (model not pulled / daemon flaked) — the contract we prove here
    # is that the adapter is wired to the Ollama provider, not that
    # any particular model exists on the dev box. Echo would surface
    # as ``done`` with payload ``echo: Say exactly: pong`` so we
    # defensively check that as a regression guard.
    assert kinds[-1] in {"done", "error"}
    all_text = " ".join(d for _, d in events)
    assert "echo: Say exactly" not in all_text
