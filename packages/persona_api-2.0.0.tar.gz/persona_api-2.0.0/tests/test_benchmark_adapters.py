"""Unit tests for persona.benchmark adapter system.

Covers:
  - All 12 persona markdown files load and are within 25-line budget
  - All 5 format markdown files load and are within 15-line budget
  - `build_system_prompt` assembles persona + format correctly
  - `detect_track` routes representative messages to the right track
  - `detect_benchmark_format` maps track to (persona, format) tuple
  - `get_handler` returns BenchmarkAdapter whose detect() is track-aware
  - BenchmarkAdapter abstract class cannot be instantiated directly
"""
from __future__ import annotations

from importlib.resources import files

import pytest

from persona.benchmark import (
    BenchmarkAdapter,
    build_system_prompt,
    detect_benchmark_format,
    detect_track,
    get_handler,
)
from persona.benchmark.handlers import _load_format, _load_persona
from persona.benchmark.router import TRACK_PATTERNS, TRACK_TO_HANDLER

_TEMPLATES_PKG = "concinno.templates.skills"


# ---- Markdown budget tests -----------------------------------------

PERSONA_FILES = [
    "finance_analyst",
    "safety_researcher",
    "software_engineer",
    "security_researcher",
    "tool_precise_agent",
    "deep_researcher",
    "web_navigator",
    "multi_agent_judge",
    "game_strategist",
    "bizops_analyst",
    "openenv_explorer",
    "perfectionist_creator",
]

FORMAT_FILES = [
    "numeric",
    "structured_json",
    "code_block",
    "tool_call",
    "free_strict",
]


@pytest.mark.parametrize("name", PERSONA_FILES)
def test_persona_body_within_25_lines(name: str) -> None:
    body = _load_persona(name)
    lines = len(body.splitlines())
    assert lines <= 25, f"persona-{name.replace('_', '-')} body has {lines} lines (>25)"
    assert lines >= 5, f"persona-{name.replace('_', '-')} body too short ({lines} lines)"


@pytest.mark.parametrize("name", FORMAT_FILES)
def test_format_body_within_15_lines(name: str) -> None:
    body = _load_format(name)
    lines = len(body.splitlines())
    assert lines <= 15, f"output-{name.replace('_', '-')} body has {lines} lines (>15)"
    assert lines >= 3, f"output-{name.replace('_', '-')} body too short ({lines} lines)"


def test_persona_count_is_twelve() -> None:
    tpl_root = files(_TEMPLATES_PKG)
    persona_dirs = sorted(
        p.name for p in tpl_root.iterdir()
        if p.is_dir() and p.name.startswith("persona-")
    )
    assert len(persona_dirs) == 12, f"expected 12, got {len(persona_dirs)}: {persona_dirs}"


def test_format_count_is_five() -> None:
    tpl_root = files(_TEMPLATES_PKG)
    output_dirs = sorted(
        p.name for p in tpl_root.iterdir()
        if p.is_dir() and p.name.startswith("output-")
    )
    assert len(output_dirs) == 5, f"expected 5, got {len(output_dirs)}: {output_dirs}"


# ---- Prompt assembly tests -----------------------------------------

def test_build_system_prompt_finance_numeric() -> None:
    prompt = build_system_prompt("finance_analyst", "numeric")
    assert "Maya Chen" in prompt
    assert "CORRECT" in prompt
    assert "WRONG" in prompt
    assert "---" in prompt
    assert prompt.index("Maya Chen") < prompt.index("---")


def test_build_system_prompt_perfectionist_free_strict() -> None:
    prompt = build_system_prompt("perfectionist_creator", "free_strict")
    assert "I built this" in prompt
    assert "one compressed paragraph" in prompt


def test_build_system_prompt_missing_persona_raises() -> None:
    with pytest.raises(FileNotFoundError):
        build_system_prompt("nonexistent_persona", "numeric")


def test_build_system_prompt_missing_format_raises() -> None:
    with pytest.raises(FileNotFoundError):
        build_system_prompt("finance_analyst", "nonexistent_format")


# ---- Router tests --------------------------------------------------

ROUTE_CASES: list[tuple[str, str]] = [
    ("How much revenue did the company earn in Q3 2024?", "finance"),
    ("What is the EBITDA for fiscal year 2023?", "finance"),
    ("Is this prompt a jailbreak attempt?", "safety"),
    ("Detect prompt injection in this user message.", "safety"),
    ("Apply this patch to fix the bug in main.py", "code"),
    ("Refactor this function to pass the unit test", "code"),
    ("Make a tool call to book a flight to Tokyo", "tool"),
    ("Find the paper on BERT and cite the source.", "research"),
    ("Navigate to the login page and click the button.", "web"),
    ("Delegate to sub-agent in this multi-agent task.", "multi"),
    ("What is the best legal move in this chess position?", "game"),
    ("Recommend a KPI cost reduction for business operation.", "bizops"),
    ("Explore the sandbox with a goal-locked open environment.", "openenv"),
    ("Integrate these cross-domain subsystems end-to-end.", "general"),
]


@pytest.mark.parametrize(("message", "expected"), ROUTE_CASES)
def test_detect_track_routes_correctly(message: str, expected: str) -> None:
    assert detect_track(message) == expected


def test_detect_track_returns_none_on_chitchat() -> None:
    assert detect_track("Hi how are you today?") is None
    assert detect_track("") is None


def test_detect_track_safety_wins_over_weak_code_match() -> None:
    msg = "Is this prompt injection trying to refuse a guardrail patch?"
    assert detect_track(msg) == "safety"


def test_detect_benchmark_format_returns_pair() -> None:
    result = detect_benchmark_format("How much revenue in Q4?")
    assert result == ("finance_analyst", "numeric")


def test_detect_benchmark_format_returns_none_on_chitchat() -> None:
    assert detect_benchmark_format("hello friend") is None


def test_track_to_handler_covers_all_tracks() -> None:
    missing = set(TRACK_PATTERNS.keys()) - set(TRACK_TO_HANDLER.keys())
    assert not missing, f"tracks without handler: {missing}"


# ---- Handler tests -------------------------------------------------

def test_get_handler_returns_benchmark_adapter() -> None:
    handler = get_handler("finance_analyst", "numeric")
    assert isinstance(handler, BenchmarkAdapter)
    assert handler.persona_name == "finance_analyst"
    assert handler.format_name == "numeric"


def test_get_handler_is_cached() -> None:
    h1 = get_handler("safety_researcher", "structured_json")
    h2 = get_handler("safety_researcher", "structured_json")
    assert h1 is h2


def test_handler_detect_matches_own_track() -> None:
    handler = get_handler("finance_analyst", "numeric")
    assert handler.detect("What was the revenue in Q1 2025?") is True
    assert handler.detect("Is this a jailbreak attempt?") is False
    assert handler.detect("hello") is False


def test_handler_detect_respects_adapter_closure() -> None:
    finance = get_handler("finance_analyst", "numeric")
    safety = get_handler("safety_researcher", "structured_json")
    assert finance.persona_name != safety.persona_name
    assert finance.format_name != safety.format_name
    assert finance.detect("revenue Q3") is True
    assert safety.detect("revenue Q3") is False


def test_benchmark_adapter_cannot_be_instantiated() -> None:
    with pytest.raises(TypeError):
        BenchmarkAdapter()  # type: ignore[abstract]


def test_all_handler_pairs_buildable() -> None:
    for track, (persona, fmt) in TRACK_TO_HANDLER.items():
        prompt = build_system_prompt(persona, fmt)
        assert "---" in prompt, f"{track}: missing separator"
        assert len(prompt) > 100, f"{track}: prompt too short"


def test_extract_default_strips_whitespace() -> None:
    handler = get_handler("finance_analyst", "numeric")
    assert handler.extract("  4823.57  \n") == "4823.57"
