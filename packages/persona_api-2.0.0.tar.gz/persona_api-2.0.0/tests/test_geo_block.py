"""GeoBlockMiddleware tests — Cf-IPCountry header inspection + 451."""

from __future__ import annotations

import pytest
from starlette.applications import Starlette
from starlette.middleware import Middleware
from starlette.responses import JSONResponse
from starlette.routing import Route
from starlette.testclient import TestClient

from persona.middleware.geo_block import (
    DEFAULT_BLOCKED_COUNTRIES,
    GeoBlockMiddleware,
    _parse_env_countries,
)


async def _ok(_request):
    return JSONResponse({"ok": True})


def _make_client() -> TestClient:
    app = Starlette(
        routes=[Route("/v1/ping", _ok, methods=["GET"])],
        middleware=[Middleware(GeoBlockMiddleware)],
    )
    return TestClient(app)


# ── defaults ────────────────────────────────────


def test_default_blocklist_contains_ear_set() -> None:
    assert "CN" in DEFAULT_BLOCKED_COUNTRIES
    assert "IR" in DEFAULT_BLOCKED_COUNTRIES
    assert "KP" in DEFAULT_BLOCKED_COUNTRIES
    assert "SY" in DEFAULT_BLOCKED_COUNTRIES
    assert "CU" in DEFAULT_BLOCKED_COUNTRIES
    # Non-blocked baseline:
    assert "TW" not in DEFAULT_BLOCKED_COUNTRIES
    assert "US" not in DEFAULT_BLOCKED_COUNTRIES


def test_parse_env_countries_normalises_case_and_whitespace() -> None:
    got = _parse_env_countries("cn, ir ,  kp,BY")
    assert got == frozenset({"CN", "IR", "KP", "BY"})


def test_parse_env_countries_drops_invalid_codes() -> None:
    got = _parse_env_countries("USA, X1, ??, CN")
    # 3-letter, digits, question marks — all rejected.
    assert got == frozenset({"CN"})


# ── behaviour ──────────────────────────────────


def test_request_without_cf_header_is_allowed() -> None:
    client = _make_client()
    r = client.get("/v1/ping")
    assert r.status_code == 200


def test_request_from_allowed_country_is_allowed(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.delenv("SANCIO_GEO_BLOCK_COUNTRIES", raising=False)
    client = _make_client()
    r = client.get("/v1/ping", headers={"Cf-IPCountry": "TW"})
    assert r.status_code == 200


def test_request_from_blocked_country_returns_451(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.delenv("SANCIO_GEO_BLOCK_COUNTRIES", raising=False)
    client = _make_client()
    r = client.get("/v1/ping", headers={"Cf-IPCountry": "CN"})
    assert r.status_code == 451
    body = r.json()
    assert body["error"] == "unavailable_for_legal_reasons"
    assert body["country"] == "CN"


def test_env_override_replaces_defaults(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    # Only block Belarus — CN must now pass.
    monkeypatch.setenv("SANCIO_GEO_BLOCK_COUNTRIES", "BY")
    client = _make_client()
    assert client.get(
        "/v1/ping", headers={"Cf-IPCountry": "CN"},
    ).status_code == 200
    assert client.get(
        "/v1/ping", headers={"Cf-IPCountry": "BY"},
    ).status_code == 451


def test_empty_env_disables_middleware(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setenv("SANCIO_GEO_BLOCK_COUNTRIES", "")
    client = _make_client()
    # Even CN passes when the list is empty.
    r = client.get("/v1/ping", headers={"Cf-IPCountry": "CN"})
    assert r.status_code == 200


def test_xx_country_is_treated_as_unknown(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    # Cloudflare emits "XX" when geolocation fails — must not 451.
    monkeypatch.delenv("SANCIO_GEO_BLOCK_COUNTRIES", raising=False)
    client = _make_client()
    r = client.get("/v1/ping", headers={"Cf-IPCountry": "XX"})
    # XX isn't in the blocklist so it passes.
    assert r.status_code == 200


def test_lowercase_header_value_is_matched(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.delenv("SANCIO_GEO_BLOCK_COUNTRIES", raising=False)
    client = _make_client()
    # Cloudflare always sends uppercase, but defense-in-depth: handle
    # a misbehaving proxy that lowercases.
    r = client.get("/v1/ping", headers={"Cf-IPCountry": "ir"})
    assert r.status_code == 451
