"""Tests for A2 tool registry — happy + error path per tool.

Every test is hermetic: filesystem tools use pytest's ``tmp_path``,
``run_bash`` picks portable commands (``python -c ...``), and
``get_diagnostics`` falls back to the ``ruff not installed`` branch
when the binary is missing on CI.
"""

from __future__ import annotations

import sys
from pathlib import Path

import pytest

from persona.tools import (
    EditFileTool,
    GetDiagnosticsTool,
    ListFilesTool,
    ReadFileTool,
    RunBashTool,
    SearchFilesTool,
    WriteFileTool,
    default_tools,
    resolve_sandboxed,
)


# ─────────────────── base.resolve_sandboxed ───────────────────


def test_resolve_sandboxed_rejects_parent_escape(tmp_path: Path) -> None:
    """``..`` escapes out of the sandbox must raise PermissionError."""
    with pytest.raises(PermissionError):
        resolve_sandboxed(tmp_path, "../escape.txt")


def test_resolve_sandboxed_accepts_inside_path(tmp_path: Path) -> None:
    resolved = resolve_sandboxed(tmp_path, "sub/file.txt")
    assert resolved.is_relative_to(tmp_path.resolve())


# ─────────────────── read_file ───────────────────


@pytest.mark.asyncio
async def test_read_file_happy(tmp_path: Path) -> None:
    target = tmp_path / "hello.txt"
    target.write_text("hi\nworld\n", encoding="utf-8")
    tool = ReadFileTool(root=tmp_path)

    out = await tool.execute({"path": "hello.txt"})

    assert out == "hi\nworld\n"
    assert tool.schema()["function"]["name"] == "read_file"


@pytest.mark.asyncio
async def test_read_file_missing_raises(tmp_path: Path) -> None:
    tool = ReadFileTool(root=tmp_path)
    with pytest.raises(FileNotFoundError):
        await tool.execute({"path": "does_not_exist.txt"})


@pytest.mark.asyncio
async def test_read_file_slicing(tmp_path: Path) -> None:
    target = tmp_path / "big.txt"
    target.write_text("\n".join(f"L{i}" for i in range(1, 11)), encoding="utf-8")
    tool = ReadFileTool(root=tmp_path)

    out = await tool.execute({"path": "big.txt", "offset": 3, "limit": 2})

    assert "L3" in out and "L4" in out and "L5" not in out


# ─────────────────── write_file ───────────────────


@pytest.mark.asyncio
async def test_write_file_creates_parents(tmp_path: Path) -> None:
    tool = WriteFileTool(root=tmp_path)

    msg = await tool.execute({"path": "a/b/c.txt", "content": "hello"})

    assert "wrote 5 chars" in msg
    assert (tmp_path / "a/b/c.txt").read_text(encoding="utf-8") == "hello"


@pytest.mark.asyncio
async def test_write_file_escape_blocked(tmp_path: Path) -> None:
    tool = WriteFileTool(root=tmp_path)
    with pytest.raises(PermissionError):
        await tool.execute({"path": "../escape.txt", "content": "x"})


# ─────────────────── edit_file ───────────────────


@pytest.mark.asyncio
async def test_edit_file_unique_match(tmp_path: Path) -> None:
    target = tmp_path / "code.py"
    target.write_text("def foo():\n    return 1\n", encoding="utf-8")
    tool = EditFileTool(root=tmp_path)

    msg = await tool.execute({
        "path": "code.py",
        "old_string": "return 1",
        "new_string": "return 2",
    })

    assert "replaced 1" in msg
    assert "return 2" in target.read_text(encoding="utf-8")


@pytest.mark.asyncio
async def test_edit_file_ambiguous_without_replace_all(tmp_path: Path) -> None:
    target = tmp_path / "code.py"
    target.write_text("x = 1\nx = 1\n", encoding="utf-8")
    tool = EditFileTool(root=tmp_path)

    out = await tool.execute({
        "path": "code.py",
        "old_string": "x = 1",
        "new_string": "x = 2",
    })

    assert "error: old_string matches 2 places" in out
    # File must not be mutated on ambiguous match.
    assert target.read_text(encoding="utf-8") == "x = 1\nx = 1\n"


@pytest.mark.asyncio
async def test_edit_file_replace_all(tmp_path: Path) -> None:
    target = tmp_path / "code.py"
    target.write_text("x = 1\nx = 1\n", encoding="utf-8")
    tool = EditFileTool(root=tmp_path)

    msg = await tool.execute({
        "path": "code.py",
        "old_string": "x = 1",
        "new_string": "x = 2",
        "replace_all": True,
    })

    assert "replaced 2" in msg
    assert target.read_text(encoding="utf-8") == "x = 2\nx = 2\n"


# ─────────────────── list_files ───────────────────


@pytest.mark.asyncio
async def test_list_files_with_glob(tmp_path: Path) -> None:
    (tmp_path / "a.py").write_text("", encoding="utf-8")
    (tmp_path / "b.txt").write_text("", encoding="utf-8")
    (tmp_path / "sub").mkdir()
    (tmp_path / "sub/c.py").write_text("", encoding="utf-8")
    tool = ListFilesTool(root=tmp_path)

    entries = await tool.execute({"pattern": "**/*.py"})

    assert len(entries) == 2
    assert all(e.endswith(".py") for e in entries)


@pytest.mark.asyncio
async def test_list_files_limit(tmp_path: Path) -> None:
    for i in range(5):
        (tmp_path / f"f{i}.txt").write_text("", encoding="utf-8")
    tool = ListFilesTool(root=tmp_path)

    entries = await tool.execute({"limit": 2})

    assert len(entries) == 2


# ─────────────────── search_files ───────────────────


@pytest.mark.asyncio
async def test_search_files_finds_matches(tmp_path: Path) -> None:
    (tmp_path / "a.py").write_text("import os\nimport sys\n", encoding="utf-8")
    (tmp_path / "b.py").write_text("print('hi')\n", encoding="utf-8")
    tool = SearchFilesTool(root=tmp_path)

    hits = await tool.execute({"pattern": r"^import ", "glob": "**/*.py"})

    assert len(hits) == 2
    assert all(h["text"].startswith("import ") for h in hits)


@pytest.mark.asyncio
async def test_search_files_no_match(tmp_path: Path) -> None:
    (tmp_path / "a.py").write_text("x = 1\n", encoding="utf-8")
    tool = SearchFilesTool(root=tmp_path)

    hits = await tool.execute({"pattern": r"nomatch_xyz"})

    assert hits == []


# ─────────────────── run_bash ───────────────────


@pytest.mark.asyncio
async def test_run_bash_echo() -> None:
    tool = RunBashTool()

    out = await tool.execute({
        "cmd": f'"{sys.executable}" -c "print(123)"',
    })

    assert out["exit_code"] == 0
    assert "123" in out["stdout"]


@pytest.mark.asyncio
async def test_run_bash_timeout() -> None:
    tool = RunBashTool()

    out = await tool.execute({
        "cmd": f'"{sys.executable}" -c "import time; time.sleep(5)"',
        "timeout": 0.2,
    })

    assert out["exit_code"] == -1
    assert "timeout" in out["stderr"].lower()


# ─────────────────── get_diagnostics ───────────────────


@pytest.mark.asyncio
async def test_get_diagnostics_returns_list(tmp_path: Path) -> None:
    target = tmp_path / "a.py"
    target.write_text("import os\n", encoding="utf-8")  # unused import
    tool = GetDiagnosticsTool(root=tmp_path)

    out = await tool.execute({"path": "a.py"})

    # Contract: always a dict with a diagnostics list, regardless of
    # whether ruff is installed on the CI runner.
    assert isinstance(out, dict)
    assert isinstance(out["diagnostics"], list)


# ─────────────────── default_tools() ───────────────────


def test_default_tools_roster(tmp_path: Path) -> None:
    tools = default_tools(root=tmp_path)
    assert set(tools.keys()) == {
        "read_file",
        "read_attachment",
        "write_file",
        "edit_file",
        "list_files",
        "search_files",
        "run_bash",
        "get_diagnostics",
        "web_search",
        "fetch_url",
        "fetch_wikipedia_section",
        "fetch_image",
        "date_calc",
        "python_exec",
    }
    for t in tools.values():
        assert hasattr(t, "schema")
        assert callable(t.schema)
