"""L6 Option C — observation-channel deny path tests (Sancio 2.0.0).

These tests prove the **Option C reframe** of the long-standing
"L6 PostToolUse hard deny" promise (see
``_AI_BRAIN/05_Planning/2026-05-01-l6-posttooluse-design-conflict-options.md``):

* CC's L6 ceiling is a **physics constraint** — once ``tool.execute()``
  returns, side effects exist. No runtime can magic-undo them
  (anthropics/claude-code#32105).
* What Sancio uniquely owns is **observation-channel deny**: a
  post-hook can raise :class:`PostToolDeny` (direct-raise path) or
  return :class:`PostToolUseDecision(decision="block", reason=...)`
  (structured path which the loop synthesises into
  :class:`PostToolUseBlocked`). Either way the LLM-visible tool result
  is replaced with an ``is_error=True`` message containing
  ``"post-hook deny: {exc}"`` or ``"blocked: {reason}"``.

These tests reference symbols produced by sub-agent A (engine
refactor: catch ``PostToolDeny`` in ``_run_one_tool``, propagate as
synthesised error tool message). Until A merges, ``pytest`` will fail
with AttributeError / no-handler — that is the expected pre-merge
mode and confirms the integration point.
"""

from __future__ import annotations

from typing import Any

import pytest

from persona.engine.agent_loop import (
    AgentLoop,
    LLMResponse,
    ToolCall,
)
from persona.hooks.post_decision import (
    PostToolDeny,
    PostToolUseBlocked,
    PostToolUseDecision,
)


class _FakeTool:
    def __init__(self, name: str, result: Any) -> None:
        self.name = name
        self._result = result

    def schema(self) -> dict[str, Any]:
        return {
            "type": "function",
            "function": {"name": self.name, "parameters": {}},
        }

    async def execute(self, args: dict[str, Any]) -> Any:
        return self._result


def _scripted_llm(replies: list[LLMResponse]):
    idx = {"i": 0}

    async def _call(messages, schemas) -> LLMResponse:
        i = idx["i"]
        idx["i"] = i + 1
        if i >= len(replies):
            pytest.fail(
                f"llm called {i + 1} times but only "
                f"{len(replies)} scripted replies available",
            )
        return replies[i]

    return _call


@pytest.mark.asyncio
async def test_post_tool_deny_raise_path_marks_is_error_true() -> None:
    """PostToolDeny raised → tool_msg has is_error=True + "post-hook deny" text.

    Direct-raise path. Cerno uses this when its deny verdict fires
    mid-cycle. The agent loop catches the exception, replaces
    ``result`` with ``f"post-hook deny: {exc}"``, sets
    ``is_error=True``. Side effects of the original tool already
    happened (CC physics) — what we deny is the **observation
    channel**.
    """

    async def deny_hook(name, args, result) -> PostToolUseDecision | None:
        raise PostToolDeny("policy violation: forbidden output")

    tool = _FakeTool("dangerous", "leaked-secret")
    llm = _scripted_llm(
        [
            LLMResponse(
                content="",
                tool_calls=[ToolCall(id="tc1", name="dangerous")],
            ),
            LLMResponse(content="acknowledged"),
        ],
    )

    loop = AgentLoop(
        llm_call=llm,
        tools={"dangerous": tool},
        post_hooks=[deny_hook],
    )

    state = await loop.run([{"role": "user", "content": "do it"}])

    tool_msgs = [m for m in state.messages if m.get("role") == "tool"]
    assert len(tool_msgs) == 1
    assert tool_msgs[0]["is_error"] is True
    assert "post-hook deny" in tool_msgs[0]["content"]
    assert "policy violation" in tool_msgs[0]["content"]


@pytest.mark.asyncio
async def test_llm_sees_is_error_following_iteration() -> None:
    """Following iteration: LLM sees is_error → typically retries or gives up.

    The scripted LLM is configured to react to the error message by
    emitting a final apology text. We assert the second LLM turn
    received the error tool_msg in its message history.
    """

    async def deny_hook(name, args, result) -> PostToolUseDecision | None:
        raise PostToolDeny("blocked by sancio policy")

    tool = _FakeTool("forbidden", "should-not-reach-llm")
    captured_messages: list[list[dict[str, Any]]] = []

    async def capturing_llm(messages, schemas) -> LLMResponse:
        captured_messages.append(list(messages))
        i = len(captured_messages)
        if i == 1:
            return LLMResponse(
                content="",
                tool_calls=[ToolCall(id="tc1", name="forbidden")],
            )
        return LLMResponse(content="ok, giving up")

    loop = AgentLoop(
        llm_call=capturing_llm,
        tools={"forbidden": tool},
        post_hooks=[deny_hook],
    )

    state = await loop.run([{"role": "user", "content": "fetch creds"}])

    assert state.done is True
    assert state.final_text == "ok, giving up"
    # Second LLM turn received the error tool_msg in history.
    assert len(captured_messages) == 2
    second_turn_msgs = captured_messages[1]
    tool_msgs = [m for m in second_turn_msgs if m.get("role") == "tool"]
    assert len(tool_msgs) == 1
    assert tool_msgs[0]["is_error"] is True
    assert "post-hook deny" in tool_msgs[0]["content"]


@pytest.mark.asyncio
async def test_post_tool_use_blocked_structured_decision_path() -> None:
    """decision="block" + reason → loop synthesises PostToolUseBlocked.

    Same shape as the direct-raise path but reason captured into the
    tool message. Mirrors CC's top-level ``decision: "block"`` shape.
    """

    async def block_hook(name, args, result) -> PostToolUseDecision | None:
        return PostToolUseDecision(
            decision="block",
            reason="contains PII",
        )

    tool = _FakeTool("scrape", "personal-data")
    llm = _scripted_llm(
        [
            LLMResponse(
                content="",
                tool_calls=[ToolCall(id="tc1", name="scrape")],
            ),
            LLMResponse(content="aborted"),
        ],
    )

    loop = AgentLoop(
        llm_call=llm,
        tools={"scrape": tool},
        post_hooks=[block_hook],
    )

    state = await loop.run([{"role": "user", "content": "scrape it"}])

    tool_msgs = [m for m in state.messages if m.get("role") == "tool"]
    assert len(tool_msgs) == 1
    assert tool_msgs[0]["is_error"] is True
    # Reason captured: "blocked: contains PII" or similar synthesis.
    content = tool_msgs[0]["content"]
    assert "blocked" in content.lower() or "PostToolUseBlocked" in content
    assert "contains PII" in content


@pytest.mark.asyncio
async def test_post_tool_use_blocked_exception_can_be_imported() -> None:
    """Smoke test — confirm symbol surface area at import time.

    Sancio 2.0.0 promise: ``PostToolUseBlocked`` is importable from
    ``persona.hooks.post_decision`` AND a subclass of ``Exception`` so
    callers can ``except PostToolUseBlocked:`` cleanly.
    """
    assert issubclass(PostToolUseBlocked, Exception)
    # Carries reason via standard args[0]:
    exc = PostToolUseBlocked("test reason")
    assert "test reason" in str(exc)
