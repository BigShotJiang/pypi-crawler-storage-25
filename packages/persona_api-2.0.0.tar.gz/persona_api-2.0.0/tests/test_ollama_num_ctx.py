"""Regression tests for ``OllamaProvider`` ``num_ctx`` plumbing.

``ModelPolicy.extra["num_ctx"]`` must land on the outgoing payload
as ``options.num_ctx``; omission must fall back to the provider's
module-level default (16384). Tests hit all three paths:
``generate``, ``generate_with_tools``, and ``generate_stream``.

We intercept HTTP via ``httpx.MockTransport`` and assert on the
exact JSON body the provider sends, so the wire format stays locked.
"""

from __future__ import annotations

import json
from typing import Any

import httpx
import pytest

from persona.providers.base import ModelPolicy
from persona.providers.ollama import OllamaProvider, _DEFAULT_NUM_CTX


def _ok_response() -> httpx.Response:
    return httpx.Response(
        200,
        json={
            "choices": [{
                "message": {"content": "ok", "role": "assistant"},
                "finish_reason": "stop",
            }],
        },
    )


def _mock_client(capture: dict[str, Any]) -> httpx.AsyncClient:
    def _handler(req: httpx.Request) -> httpx.Response:
        capture["payload"] = json.loads(req.content.decode("utf-8"))
        return _ok_response()

    return httpx.AsyncClient(
        transport=httpx.MockTransport(_handler),
        timeout=5.0,
    )


# ─────────────────── generate() — explicit num_ctx ───────────────────


@pytest.mark.asyncio
async def test_generate_propagates_num_ctx_from_extra() -> None:
    capture: dict[str, Any] = {}
    client = _mock_client(capture)
    provider = OllamaProvider(base_url="http://fake/v1", client=client)

    policy = ModelPolicy(
        provider="ollama",
        model="gemma4:latest",
        extra={"num_ctx": 32768},
    )

    try:
        out = await provider.generate(
            [{"role": "user", "content": "hi"}], policy,
        )
    finally:
        await client.aclose()

    assert out == "ok"
    payload = capture["payload"]
    assert "options" in payload
    assert payload["options"]["num_ctx"] == 32768


@pytest.mark.asyncio
async def test_generate_uses_default_num_ctx_when_missing() -> None:
    capture: dict[str, Any] = {}
    client = _mock_client(capture)
    provider = OllamaProvider(base_url="http://fake/v1", client=client)

    policy = ModelPolicy(provider="ollama", model="gemma4:latest")

    try:
        await provider.generate(
            [{"role": "user", "content": "hi"}], policy,
        )
    finally:
        await client.aclose()

    payload = capture["payload"]
    assert payload["options"]["num_ctx"] == _DEFAULT_NUM_CTX


# ─────────────────── generate_with_tools() ───────────────────


@pytest.mark.asyncio
async def test_generate_with_tools_propagates_num_ctx() -> None:
    capture: dict[str, Any] = {}
    client = _mock_client(capture)
    provider = OllamaProvider(base_url="http://fake/v1", client=client)

    policy = ModelPolicy(
        provider="ollama",
        model="gemma4:latest",
        extra={"num_ctx": 8192},
    )

    try:
        await provider.generate_with_tools(
            [{"role": "user", "content": "hi"}], policy, [],
        )
    finally:
        await client.aclose()

    payload = capture["payload"]
    assert payload["options"]["num_ctx"] == 8192


# ─────────────────── generate_stream() ───────────────────


@pytest.mark.asyncio
async def test_generate_stream_propagates_num_ctx() -> None:
    capture: dict[str, Any] = {}

    def _handler(req: httpx.Request) -> httpx.Response:
        capture["payload"] = json.loads(req.content.decode("utf-8"))
        # One minimal SSE frame + DONE so the stream iterator exits.
        body = (
            b'data: {"choices":[{"delta":{"content":"hi"}}]}\n\n'
            b"data: [DONE]\n\n"
        )
        return httpx.Response(
            200,
            headers={"content-type": "text/event-stream"},
            content=body,
        )

    client = httpx.AsyncClient(
        transport=httpx.MockTransport(_handler), timeout=5.0,
    )
    provider = OllamaProvider(base_url="http://fake/v1", client=client)

    policy = ModelPolicy(
        provider="ollama",
        model="gemma4:latest",
        extra={"num_ctx": 65536},
    )

    try:
        chunks: list[str] = []
        async for chunk in provider.generate_stream(
            [{"role": "user", "content": "hi"}], policy,
        ):
            chunks.append(chunk)
    finally:
        await client.aclose()

    assert chunks == ["hi"]
    payload = capture["payload"]
    assert payload["stream"] is True
    assert payload["options"]["num_ctx"] == 65536


# ─────────────────── None opts out ───────────────────


@pytest.mark.asyncio
async def test_generate_omits_options_when_num_ctx_is_none() -> None:
    capture: dict[str, Any] = {}
    client = _mock_client(capture)
    provider = OllamaProvider(base_url="http://fake/v1", client=client)

    # Explicit None disables the default — keeps payload shape stable
    # for tests that care about the exact wire output.
    policy = ModelPolicy(
        provider="ollama",
        model="gemma4:latest",
        extra={"num_ctx": None},
    )

    try:
        await provider.generate(
            [{"role": "user", "content": "hi"}], policy,
        )
    finally:
        await client.aclose()

    payload = capture["payload"]
    assert "options" not in payload
