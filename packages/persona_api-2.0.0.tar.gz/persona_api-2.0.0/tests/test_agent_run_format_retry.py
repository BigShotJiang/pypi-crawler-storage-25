"""Tests for the Concinno format-guard retry layer in ``/v1/agent/run``.

Contract
--------

* Malformed first output (retry-talk, empty, quote-dump,
  special-token) triggers a ``format_retry`` SSE event + a second
  ``loop.run`` call with ``FORMAT_RETRY_REMINDER`` appended to the
  original user message.
* Well-formed first output is a no-op — no ``format_retry`` event,
  LLM called once.
* ``SANCIO_FORMAT_RETRY_ENABLED=0`` disables the feature at
  runtime; the same malformed first output flows through to the
  client unchanged.

Tests are hermetic — no real provider round-trip, LLM adapter is
swapped via :func:`persona.agent_api.set_llm_call`.
"""

from __future__ import annotations

import json
from collections.abc import Iterator
from typing import Any

import pytest
from starlette.testclient import TestClient

from persona import agent_api
from persona.api import create_standalone_app
from persona.engine.agent_loop import LLMResponse


@pytest.fixture()
def client() -> Iterator[TestClient]:
    app = create_standalone_app()
    with TestClient(app) as c:
        yield c
    agent_api.reset_llm_call()


def _install_llm_sequence(replies: list[LLMResponse]) -> dict[str, list[Any]]:
    """Install an LLM fake that records calls + returns ``replies`` in order."""
    call_log: dict[str, list[Any]] = {"messages": []}
    idx = {"i": 0}

    async def _call(
        messages: list[dict[str, Any]],
        schemas: list[dict[str, Any]],
    ) -> LLMResponse:
        call_log["messages"].append(messages)
        i = idx["i"]
        idx["i"] = i + 1
        if i >= len(replies):
            raise AssertionError(
                f"llm called {i + 1}x but only {len(replies)} replies",
            )
        return replies[i]

    agent_api.set_llm_call(_call)
    return call_log


def _parse_sse(body: str) -> list[tuple[str, dict[str, Any]]]:
    events: list[tuple[str, dict[str, Any]]] = []
    for block in body.strip().split("\n\n"):
        event = ""
        data_parts: list[str] = []
        for line in block.splitlines():
            if line.startswith("event:"):
                event = line.split(":", 1)[1].strip()
            elif line.startswith("data:"):
                data_parts.append(line.split(":", 1)[1].strip())
        if data_parts:
            try:
                events.append((event, json.loads(" ".join(data_parts))))
            except json.JSONDecodeError:
                events.append((event, {"_raw": " ".join(data_parts)}))
    return events


def _run(
    client: TestClient,
    question: str,
    *,
    max_iter: int = 3,
) -> list[tuple[str, dict[str, Any]]]:
    resp = client.post(
        "/v1/agent/run",
        json={
            "stack": "sancio",
            "model": "anthropic/claude-sonnet-4-6",
            "max_iterations": max_iter,
            "tenant_id": "test",
            "messages": [{"role": "user", "content": question}],
        },
    )
    assert resp.status_code == 200, resp.text
    return _parse_sse(resp.text)


# ─── retry_talk triggers ────────────────────────────


def test_retry_talk_triggers_format_retry_event(
    client: TestClient,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setenv("SANCIO_FORMAT_RETRY_ENABLED", "1")
    # First attempt returns think-aloud; second returns clean answer.
    call_log = _install_llm_sequence([
        LLMResponse(
            content="Wait, I'll search for the movie title",
            tool_calls=[],
        ),
        LLMResponse(
            content="FINAL ANSWER: Interstellar",
            tool_calls=[],
        ),
    ])
    events = _run(client, "What movie is that about a dream within dreams?")
    names = [e[0] for e in events]
    assert "format_retry" in names, (
        f"expected format_retry event, got: {names}"
    )
    retry = next(e for e in events if e[0] == "format_retry")
    assert retry[1]["mode"] == "retry_talk"
    # Second LLM call must have received the reminder in its user msg
    second_call_msgs = call_log["messages"][1]
    first_user = next(m for m in second_call_msgs if m["role"] == "user")
    assert "FORMAT REMINDER" in first_user["content"]
    # Final token carries the CLEAN answer
    token = next(e for e in events if e[0] == "token")
    assert "Interstellar" in token[1]["text"]


# ─── empty raw triggers ────────────────────────────


def test_empty_first_output_triggers_retry(
    client: TestClient,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setenv("SANCIO_FORMAT_RETRY_ENABLED", "1")
    _install_llm_sequence([
        LLMResponse(content="", tool_calls=[]),
        LLMResponse(
            content="FINAL ANSWER: 42",
            tool_calls=[],
        ),
    ])
    events = _run(client, "What is 6 × 7?")
    retry = next((e for e in events if e[0] == "format_retry"), None)
    assert retry is not None, "empty raw should trigger format_retry"
    assert retry[1]["mode"] == "empty"


# ─── special-token triggers ─────────────────────────


def test_special_token_leak_triggers_retry(
    client: TestClient,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setenv("SANCIO_FORMAT_RETRY_ENABLED", "1")
    _install_llm_sequence([
        LLMResponse(
            content="FINAL ANSWER: <|tool_call|>",
            tool_calls=[],
        ),
        LLMResponse(
            content="FINAL ANSWER: Tokyo",
            tool_calls=[],
        ),
    ])
    events = _run(client, "What is the capital of Japan?")
    retry = next((e for e in events if e[0] == "format_retry"), None)
    assert retry is not None
    assert retry[1]["mode"] == "special_token"


# ─── well-formed answer is a no-op ─────────────────


def test_clean_first_output_does_not_retry(
    client: TestClient,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setenv("SANCIO_FORMAT_RETRY_ENABLED", "1")
    call_log = _install_llm_sequence([
        LLMResponse(
            content="FINAL ANSWER: 2010",
            tool_calls=[],
        ),
    ])
    events = _run(client, "What year did Inception release?")
    names = [e[0] for e in events]
    assert "format_retry" not in names, (
        f"clean answer must not retry; got events: {names}"
    )
    # Exactly one LLM call
    assert len(call_log["messages"]) == 1


# ─── opt-out disables the feature ──────────────────


def test_env_opt_out_disables_retry(
    client: TestClient,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setenv("SANCIO_FORMAT_RETRY_ENABLED", "0")
    call_log = _install_llm_sequence([
        LLMResponse(
            content="Wait, let me think about this",
            tool_calls=[],
        ),
    ])
    events = _run(client, "anything")
    names = [e[0] for e in events]
    assert "format_retry" not in names, (
        f"opt-out env should skip retry; got: {names}"
    )
    assert len(call_log["messages"]) == 1
