"""Tests for the ``intent_anchor`` wire-up in
``POST /v1/agent/run`` (concinno 2.35.0+ Stage -1).
"""

from __future__ import annotations

import pytest
from pydantic import ValidationError

from persona.agent_api import AgentRunRequest


# ── Request model surface ─────────────────────────────────────────────


class TestRequestField:
    def test_intent_anchor_defaults_false(self):
        req = AgentRunRequest(
            stack="sancio",
            messages=[{"role": "user", "content": "test"}],
            model="anthropic:claude-sonnet-4-6",
        )
        assert req.intent_anchor is False

    def test_intent_anchor_can_be_set_true(self):
        req = AgentRunRequest(
            stack="sancio",
            messages=[{"role": "user", "content": "test"}],
            model="anthropic:claude-sonnet-4-6",
            intent_anchor=True,
        )
        assert req.intent_anchor is True

    def test_unknown_typo_still_rejected(self):
        # ``extra="forbid"`` must catch typos so clients learn the
        # canonical spelling on first try.
        with pytest.raises(ValidationError):
            AgentRunRequest(
                stack="sancio",
                messages=[{"role": "user", "content": "test"}],
                model="anthropic:claude-sonnet-4-6",
                intent_anchour=True,  # type: ignore[call-arg]
            )


# ── Anchor injection logic (extracted via the same helpers
#    concinno.intent_anchor uses, so the assertion is on the
#    contract, not on a brittle string). ──────────────────────────────


class TestAnchorInjectionLogic:
    """Exercise the anchor extractor + render the wire-up calls.

    Full end-to-end SSE invocation needs a live LLM provider, so we
    isolate the prepend logic to a focused unit test.
    """

    def test_extract_anchor_for_typical_gaia_question(self):
        from concinno.intent_anchor import (
            extract_anchor,
            render_anchor_block,
        )

        prompt = (
            "Please answer with the integer count of studio albums "
            "Mercedes Sosa released as of 2009."
        )
        anchor = extract_anchor(prompt)
        assert anchor.summary
        assert anchor.done_spec
        assert "2009" in anchor.constraints
        block = render_anchor_block(
            anchor, title="🎯 Stage -1 意圖錨定（首輪）",
        )
        assert "Stage -1" in block
        assert "原始意圖" in block
        assert "2009" in block

    def test_anchor_skipped_when_prompt_too_short(self):
        from concinno.intent_anchor import extract_anchor

        # Empty prompt → anchor.is_empty() is True; wire-up skips.
        anchor = extract_anchor("")
        assert anchor.is_empty() is True

    def test_anchor_block_independent_of_payload_content(self):
        # Anchor should be heuristic-only — content-of-message dependent
        # but provider/model agnostic. Smoke test: same prompt, different
        # models → identical block.
        from concinno.intent_anchor import (
            extract_anchor,
            render_anchor_block,
        )

        prompt = "Answer the count of items as of 2020."
        block1 = render_anchor_block(extract_anchor(prompt))
        block2 = render_anchor_block(extract_anchor(prompt))
        assert block1 == block2
