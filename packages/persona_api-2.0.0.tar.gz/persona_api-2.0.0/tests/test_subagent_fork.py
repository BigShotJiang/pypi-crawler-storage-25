"""Tests for A5 subagent fork — parent spawns child AgentLoop."""

from __future__ import annotations

from typing import Any

import pytest

from persona.engine.agent_loop import AgentLoop, LLMResponse, ToolCall
from persona.engine.subagent_fork import (
    SubagentForkTool,
    SubagentRecursionError,
    fork_tool_from_parent,
)


def _scripted_llm(scripts: dict[str, list[LLMResponse]]):
    """Route LLM calls to different scripts based on the first user message.

    The parent and child each have their own reply script; the
    routing lets a single ``llm_call`` feed both halves of the fork.
    """
    state: dict[str, int] = {k: 0 for k in scripts}

    async def _call(
        messages: list[dict[str, Any]],
        _schemas: list[dict[str, Any]],
    ) -> LLMResponse:
        # Identify which script this conversation belongs to by
        # searching for a marker substring in any user message.
        for key in scripts:
            if any(
                m.get("role") == "user" and key in str(m.get("content", ""))
                for m in messages
            ):
                i = state[key]
                state[key] = i + 1
                return scripts[key][i]
        raise AssertionError(
            f"no script matched; messages={messages}",
        )

    return _call


@pytest.mark.asyncio
async def test_parent_spawns_child_and_gets_text() -> None:
    """Parent delegates a sub-task; child returns a string to parent."""
    llm = _scripted_llm({
        "PARENT": [
            LLMResponse(tool_calls=[ToolCall(
                id="s1",
                name="spawn_subagent",
                args={"prompt": "CHILD: solve 1+1"},
            )]),
            LLMResponse(content="The answer is 2."),
        ],
        "CHILD": [
            LLMResponse(content="2"),
        ],
    })

    fork = SubagentForkTool(llm_call=llm)
    parent = AgentLoop(llm_call=llm, tools={"spawn_subagent": fork})

    state = await parent.run([
        {"role": "user", "content": "PARENT: delegate the math"},
    ])

    assert state.done is True
    assert state.final_text == "The answer is 2."
    # Tool message carried the child's final text back.
    tool_msg = next(m for m in state.messages if m["role"] == "tool")
    assert tool_msg["content"] == "2"
    assert tool_msg["is_error"] is False


@pytest.mark.asyncio
async def test_fork_tool_from_parent_inherits_tools_and_hooks() -> None:
    """Helper factory passes parent context down to the child."""
    class _EchoTool:
        name = "echo"

        def schema(self) -> dict[str, Any]:
            return {"type": "function", "function": {"name": "echo"}}

        async def execute(self, args: dict[str, Any]) -> str:
            return args.get("text", "")

    hook_fired: list[str] = []

    async def _audit(tool: str, _args: dict[str, Any]) -> None:
        hook_fired.append(tool)

    llm = _scripted_llm({
        "PARENT": [
            LLMResponse(tool_calls=[ToolCall(
                id="s1",
                name="spawn_subagent",
                args={"prompt": "CHILD: echo hello"},
            )]),
            LLMResponse(content="child said hello"),
        ],
        "CHILD": [
            LLMResponse(tool_calls=[ToolCall(
                id="e1", name="echo", args={"text": "hello"},
            )]),
            LLMResponse(content="hello"),
        ],
    })

    parent = AgentLoop(
        llm_call=llm,
        tools={"echo": _EchoTool()},
        pre_hooks=[_audit],
    )
    parent.tools["spawn_subagent"] = fork_tool_from_parent(parent)

    await parent.run([{"role": "user", "content": "PARENT: delegate"}])

    # Parent's audit hook saw both the parent's fork call AND the
    # child's echo call — hooks inherited correctly.
    assert "spawn_subagent" in hook_fired
    assert "echo" in hook_fired


@pytest.mark.asyncio
async def test_recursion_depth_soft_cap_raises_directly() -> None:
    """Guard fires when ``_depth >= max_depth`` — test the boundary directly.

    Agent-loop-mediated recursion burns too many indirection layers
    to observe the raise at the top level (the intermediate layer's
    AgentLoop catches and converts to ``is_error`` tool msg, which
    the grandparent can't see). We test the guard at its source
    instead — same behavioural contract, no framing confusion.
    """
    async def dummy_llm(
        _messages: list[dict[str, Any]],
        _schemas: list[dict[str, Any]],
    ) -> LLMResponse:
        return LLMResponse(content="never reached")

    saturated = SubagentForkTool(
        llm_call=dummy_llm,
        max_depth=2,
        _depth=2,  # already at the cap
    )
    with pytest.raises(SubagentRecursionError, match="max_depth 2"):
        await saturated.execute({"prompt": "anything"})


@pytest.mark.asyncio
async def test_nested_fork_increments_depth() -> None:
    """allow_nested=True → child's fork tool carries _depth+1."""
    async def dummy_llm(
        _messages: list[dict[str, Any]],
        _schemas: list[dict[str, Any]],
    ) -> LLMResponse:
        return LLMResponse(content="done")

    fork = SubagentForkTool(
        llm_call=dummy_llm,
        allow_nested=True,
        max_depth=5,
    )

    # Drive one spawn and inspect the deeper tool the child inherits.
    # We can't easily observe it from outside, so trigger via a tiny
    # manual fork: build the child registry exactly as execute() does.
    deeper = SubagentForkTool(
        llm_call=fork.llm_call,
        tools=fork.tools,
        pre_hooks=list(fork.pre_hooks),
        post_hooks=list(fork.post_hooks),
        max_iterations=fork.max_iterations,
        max_depth=fork.max_depth,
        allow_nested=True,
        _depth=fork._depth + 1,
    )
    assert deeper._depth == 1
    assert deeper.max_depth == 5


@pytest.mark.asyncio
async def test_non_nested_child_cannot_spawn_grandchild() -> None:
    """Default allow_nested=False → child's registry lacks spawn_subagent."""
    llm = _scripted_llm({
        "PARENT": [
            LLMResponse(tool_calls=[ToolCall(
                id="s1",
                name="spawn_subagent",
                args={"prompt": "CHILD: try nesting"},
            )]),
            LLMResponse(content="parent done"),
        ],
        "CHILD": [
            # Child tries to spawn a grandchild — AgentLoop records
            # "unknown tool" because spawn_subagent was stripped.
            LLMResponse(tool_calls=[ToolCall(
                id="g1",
                name="spawn_subagent",
                args={"prompt": "grandchild"},
            )]),
            LLMResponse(content="child gave up"),
        ],
    })

    fork = SubagentForkTool(llm_call=llm)
    parent = AgentLoop(llm_call=llm, tools={"spawn_subagent": fork})

    state = await parent.run([{"role": "user", "content": "PARENT: go"}])

    assert state.done is True
    # The string returned by the child comes back verbatim.
    tool_msg = next(m for m in state.messages if m["role"] == "tool")
    assert tool_msg["content"] == "child gave up"


@pytest.mark.asyncio
async def test_expose_tools_subset() -> None:
    """``expose_tools`` hands the child a narrow slice of the parent registry."""
    class _DummyTool:
        def __init__(self, name: str) -> None:
            self.name = name

        def schema(self) -> dict[str, Any]:
            return {"type": "function", "function": {"name": self.name}}

        async def execute(self, _args: dict[str, Any]) -> str:
            return self.name

    parent = AgentLoop(
        llm_call=lambda *_: None,  # type: ignore[return-value, arg-type]
        tools={"a": _DummyTool("a"), "b": _DummyTool("b")},
    )
    fork = fork_tool_from_parent(parent, expose_tools=["a"])

    assert set(fork.tools.keys()) == {"a"}


# ── Fidelity delta wiring (Tran&Kiela DPI loss measurement) ────────


@pytest.mark.asyncio
async def test_fork_records_fidelity_delta_on_preserved_response() -> None:
    """High-fidelity reply populates ``last_fidelity`` with low delta."""
    from concinno.fidelity_delta import FidelityDeltaRecord

    async def child_llm(
        _messages: list[dict[str, Any]],
        _schemas: list[dict[str, Any]],
    ) -> LLMResponse:
        return LLMResponse(
            content="I analyzed the csv file and found alpha and beta as expected",
        )

    fork = SubagentForkTool(llm_call=child_llm)
    # Call execute directly — avoids the parent loop's scripted routing.
    out = await fork.execute({
        "prompt": "please analyze the csv file and find alpha and beta",
    })
    assert "analyzed" in out
    assert isinstance(fork.last_fidelity, FidelityDeltaRecord)
    # Output echoes both key tokens → delta should be low.
    assert fork.last_fidelity.delta <= 0.3


@pytest.mark.asyncio
async def test_fork_records_high_delta_on_dropped_fields() -> None:
    """Reply that drops bullets shows high delta + lost_fields entries."""
    from concinno.fidelity_delta import FidelityDeltaRecord

    async def child_llm(
        _messages: list[dict[str, Any]],
        _schemas: list[dict[str, Any]],
    ) -> LLMResponse:
        return LLMResponse(content="alpha received ok")

    fork = SubagentForkTool(llm_call=child_llm)
    await fork.execute({
        "prompt": "- alpha aaaa\n- beta bbbb\n- gamma cccc",
    })
    assert isinstance(fork.last_fidelity, FidelityDeltaRecord)
    assert fork.last_fidelity.delta >= 0.5
    # Two of the three bullets should have landed in lost_fields.
    assert len(fork.last_fidelity.lost_fields) >= 2


@pytest.mark.asyncio
async def test_measure_fidelity_disabled_leaves_last_fidelity_none() -> None:
    """Opt-out keeps the record unset even after a fork."""
    async def child_llm(
        _messages: list[dict[str, Any]],
        _schemas: list[dict[str, Any]],
    ) -> LLMResponse:
        return LLMResponse(content="response")

    fork = SubagentForkTool(llm_call=child_llm, measure_fidelity=False)
    await fork.execute({"prompt": "do the thing"})
    assert fork.last_fidelity is None


@pytest.mark.asyncio
async def test_fidelity_measurement_failure_never_masks_result() -> None:
    """If compute_fidelity_delta raises, the child's final_text still returns."""
    async def child_llm(
        _messages: list[dict[str, Any]],
        _schemas: list[dict[str, Any]],
    ) -> LLMResponse:
        return LLMResponse(content="ok result")

    fork = SubagentForkTool(llm_call=child_llm)

    # Monkey-patch the module-level compute_fidelity_delta to raise.
    from persona.engine import subagent_fork as sf
    original = sf.compute_fidelity_delta

    def _blow_up(*_a: Any, **_kw: Any) -> Any:
        raise RuntimeError("measurement failed")

    sf.compute_fidelity_delta = _blow_up  # type: ignore[assignment]
    try:
        out = await fork.execute({"prompt": "any prompt"})
        assert out == "ok result"
        # Failure path leaves the record as None.
        assert fork.last_fidelity is None
    finally:
        sf.compute_fidelity_delta = original  # type: ignore[assignment]


@pytest.mark.asyncio
async def test_fork_tool_from_parent_passes_measure_flag() -> None:
    """Helper threads ``measure_fidelity`` through to the returned tool."""
    parent = AgentLoop(
        llm_call=lambda *_: None,  # type: ignore[return-value, arg-type]
        tools={},
    )
    fork_on = fork_tool_from_parent(parent)
    fork_off = fork_tool_from_parent(parent, measure_fidelity=False)

    assert fork_on.measure_fidelity is True
    assert fork_off.measure_fidelity is False
