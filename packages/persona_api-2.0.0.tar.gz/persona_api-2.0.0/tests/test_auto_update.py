"""Tests for ``persona.auto_update`` Tier 2 self-update mirror.

Mirrors the spirit of ``concinno/tests/test_self_update.py`` but
exercises persona-specific differences:

* PyPI fetch targets ``persona-api`` (not ``concinno``).
* Spawn argv contains ``persona-api==<ver>`` (not ``concinno==<ver>``).
* Helper log lives under the Sancio dir (``~/.sancio/...`` POSIX,
  ``%LOCALAPPDATA%\\sancio\\...`` Windows).
* In-use detection scans for ``persona`` / ``sancio`` cmdlines.
* CLI dispatcher (``sancio self-update``) routes to the new umbrella
  in :mod:`persona.cli.main`, with backward-compat preserved through
  :func:`persona.gui.cli.main`.
"""

from __future__ import annotations

import sys
from pathlib import Path
from unittest.mock import patch

_SRC = Path(__file__).resolve().parent.parent / "src"
if str(_SRC) not in sys.path:
    sys.path.insert(0, str(_SRC))


# ── Engine: sancio_self_update() ───────────────────────────────────


def test_dry_run_skip_in_use_returns_clean_result():
    """Dry-run + skip-in-use: no spawn, no error, target_version set."""
    from persona.auto_update import sancio_self_update

    with patch(
        "persona.auto_update.tier2_self_update.get_latest_pypi_version",
        return_value="0.99.0",
    ):
        result = sancio_self_update(
            dry_run=True, skip_in_use_check=True
        )

    assert result.dry_run is True
    assert result.helper_spawned is False
    assert result.error is None
    assert result.latest_version == "0.99.0"
    assert result.target_version == "0.99.0"


def test_pypi_fetch_uses_persona_api_distribution_name():
    """The mirror must request ``persona-api``, NOT ``concinno``."""
    from persona.auto_update import sancio_self_update

    captured: dict[str, str] = {}

    def _fake_fetch(pkg, *args, **kwargs):
        captured["pkg"] = pkg
        return "0.99.0"

    with patch(
        "persona.auto_update.tier2_self_update.get_latest_pypi_version",
        side_effect=_fake_fetch,
    ):
        sancio_self_update(dry_run=True, skip_in_use_check=True)

    assert captured["pkg"] == "persona-api"


def test_spawn_argv_targets_persona_api_package(monkeypatch):
    """Detached helper must run ``pip install --upgrade persona-api==X``."""
    from persona.auto_update import tier2_self_update as t

    argv = t._build_pip_argv("0.4.0")

    assert argv[0] == sys.executable
    assert "pip" in argv
    assert "install" in argv
    assert "--upgrade" in argv
    assert "persona-api==0.4.0" in argv
    # Defensive: must NOT smuggle the concinno package in.
    assert not any("concinno==" in a for a in argv)


def test_log_path_lives_under_sancio_dir(monkeypatch, tmp_path):
    """POSIX log path = ``<home>/.sancio/self_update.log``."""
    from persona.auto_update import tier2_self_update as t

    monkeypatch.setattr("platform.system", lambda: "Linux")
    monkeypatch.setattr(Path, "home", lambda: tmp_path)
    monkeypatch.delenv("LOCALAPPDATA", raising=False)

    log_dir = t._sancio_log_dir()

    assert log_dir == tmp_path / ".sancio"


def test_log_path_windows_uses_localappdata(monkeypatch, tmp_path):
    """Windows log path = ``%LOCALAPPDATA%\\sancio\\``."""
    from persona.auto_update import tier2_self_update as t

    monkeypatch.setattr("platform.system", lambda: "Windows")
    monkeypatch.setenv("LOCALAPPDATA", str(tmp_path / "AppDataLocal"))

    log_dir = t._sancio_log_dir()

    assert log_dir == tmp_path / "AppDataLocal" / "sancio"


def test_already_on_target_skips_spawn(monkeypatch):
    """Current version == target version → no spawn, no error."""
    from persona.auto_update import sancio_self_update

    monkeypatch.setattr(
        "persona.auto_update.tier2_self_update._current_persona_version",
        lambda: "0.4.0",
    )

    with patch(
        "persona.auto_update.tier2_self_update.get_latest_pypi_version",
        return_value="0.4.0",
    ):
        result = sancio_self_update(skip_in_use_check=True)

    assert result.helper_spawned is False
    assert result.error is None
    assert result.target_version == "0.4.0"


def test_pypi_fetch_failure_returns_error(monkeypatch):
    """PyPI returning None → ``error`` set, no spawn."""
    from persona.auto_update import sancio_self_update

    with patch(
        "persona.auto_update.tier2_self_update.get_latest_pypi_version",
        return_value=None,
    ):
        result = sancio_self_update(skip_in_use_check=True)

    assert result.helper_spawned is False
    assert result.error is not None
    assert "persona-api" in result.error


# ── CLI plumbing ───────────────────────────────────────────────────


def test_umbrella_parser_registers_both_verbs():
    """``sancio --help`` must list both ``gui`` and ``self-update``."""
    from persona.cli.main import build_parser

    parser = build_parser()
    help_text = parser.format_help()

    assert "gui" in help_text
    assert "self-update" in help_text


def test_self_update_subcommand_routes_to_engine(monkeypatch, capsys):
    """``sancio self-update --dry-run --skip-in-use-check`` reaches engine."""
    from persona.cli.main import main as umbrella_main

    called: dict[str, object] = {}

    def _fake(*args, **kwargs):
        from persona.auto_update import SelfUpdateResult

        called["kwargs"] = kwargs
        return SelfUpdateResult(
            current_version="0.3.0",
            latest_version="0.4.0",
            target_version="0.4.0",
            method="pip-venv",
            dry_run=True,
        )

    monkeypatch.setattr("persona.auto_update.sancio_self_update", _fake)

    umbrella_main(["self-update", "--dry-run", "--skip-in-use-check"])

    assert called["kwargs"]["dry_run"] is True
    assert called["kwargs"]["skip_in_use_check"] is True
    out = capsys.readouterr().out
    assert "Current: 0.3.0" in out
    assert "Target:  0.4.0" in out


def test_legacy_gui_cli_main_forwards_to_umbrella(capsys):
    """Backward-compat: ``persona.gui.cli:main`` still works as entry."""
    from persona.gui.cli import main as legacy_main

    # No subcommand → prints help (exits cleanly, no SystemExit).
    legacy_main([])
    out = capsys.readouterr().out
    assert "sancio" in out
    assert "self-update" in out  # umbrella exposes the new verb too
