"""Tests for ``POST /v1/agent/run`` SSE endpoint (agent_api).

Contract surface under test
---------------------------

* 200 SSE happy-path — event stream ordering and terminal `done`.
* 400 rejections — invalid body, unknown/unsupported stack, bad field.
* `event: token` shape — text carried in ``data: {"text": ...}``.
* `event: done` usage envelope — includes request_id and stop_reason.
* `event: error` code/shape when the LLM raises.
* Multi-iteration tool use emits ``tool_call`` / ``tool_result``.

All tests are hermetic: the module-level LLM adapter is swapped via
:func:`persona.agent_api.set_llm_call` to scripted fakes; no real
provider round-trip ever happens.
"""

from __future__ import annotations

from collections.abc import Iterator
from typing import Any

import pytest
from starlette.testclient import TestClient

from persona import agent_api
from persona.api import create_standalone_app
from persona.engine.agent_loop import LLMResponse, ToolCall


# ── Fixtures ─────────────────────────────────────


@pytest.fixture()
def client() -> Iterator[TestClient]:
    """Fresh Aegis app per test — isolates module-level state."""
    app = create_standalone_app()
    with TestClient(app) as c:
        yield c
    agent_api.reset_llm_call()


def _install_scripted_llm(replies: list[LLMResponse]) -> None:
    """Install an LLM fake that returns ``replies`` in order."""
    idx = {"i": 0}

    async def _call(
        messages: list[dict[str, Any]],
        schemas: list[dict[str, Any]],
    ) -> LLMResponse:
        i = idx["i"]
        idx["i"] = i + 1
        if i >= len(replies):
            # The loop should not iterate past the scripted reply count
            # — exceeding it is a test bug, not a production contract.
            raise AssertionError(
                f"llm called {i + 1}x but only {len(replies)} replies",
            )
        return replies[i]

    agent_api.set_llm_call(_call)


def _parse_sse(body: str) -> list[tuple[str, str]]:
    """Split a text/event-stream body into ``(event, data)`` tuples.

    Blank-line delimited blocks, ``event:`` + ``data:`` lines only.
    Unknown field lines are ignored — that matches the browser
    EventSource wire format.
    """
    events: list[tuple[str, str]] = []
    for block in body.strip().split("\n\n"):
        event = ""
        data_parts: list[str] = []
        for line in block.splitlines():
            if line.startswith("event:"):
                event = line.split(":", 1)[1].strip()
            elif line.startswith("data:"):
                data_parts.append(line.split(":", 1)[1].strip())
        if data_parts:
            events.append((event or "message", "\n".join(data_parts)))
    return events


# ── Tests ────────────────────────────────────────


def test_happy_path_ccc_stack_200_sse(client: TestClient) -> None:
    """Minimal ccc run streams token + iteration + done, in that order."""
    _install_scripted_llm([LLMResponse(content="hello world")])

    resp = client.post(
        "/v1/agent/run",
        json={
            "stack": "ccc",
            "model": "claude-sonnet-4-6",
            "messages": [{"role": "user", "content": "hi"}],
        },
    )

    assert resp.status_code == 200
    assert resp.headers["content-type"].startswith("text/event-stream")
    assert resp.headers.get("x-request-id")

    events = _parse_sse(resp.text)
    kinds = [ev for ev, _ in events]
    assert "iteration" in kinds
    assert "token" in kinds
    assert kinds[-1] == "done"

    # Terminal envelope carries request_id + usage.
    import json
    done_payload = json.loads(events[-1][1])
    assert "usage" in done_payload
    assert "request_id" in done_payload
    assert done_payload["usage"]["stop_reason"] == "completed"


def test_invalid_body_non_json_returns_400(client: TestClient) -> None:
    """A non-JSON body yields ``invalid_body`` 400."""
    resp = client.post(
        "/v1/agent/run",
        content=b"not json",
        headers={"Content-Type": "application/json"},
    )
    assert resp.status_code == 400
    body = resp.json()
    assert body["error"] == "invalid_body"
    assert "request_id" in body


def test_unsupported_stack_clean_rejected(client: TestClient) -> None:
    """``clean`` never hits Aegis — 400 + actionable detail."""
    resp = client.post(
        "/v1/agent/run",
        json={
            "stack": "clean",
            "model": "gpt-4o",
            "messages": [{"role": "user", "content": "hi"}],
        },
    )
    assert resp.status_code == 400
    assert resp.json()["error"] == "unsupported_stack"


def test_unknown_stack_rejected(client: TestClient) -> None:
    """Random stack name surfaces as ``unknown_stack``."""
    resp = client.post(
        "/v1/agent/run",
        json={
            "stack": "bogus",
            "model": "gpt-4o",
            "messages": [{"role": "user", "content": "hi"}],
        },
    )
    assert resp.status_code == 400
    assert resp.json()["error"] == "unknown_stack"


def test_missing_required_field_returns_400(client: TestClient) -> None:
    """Missing ``messages`` surfaces as ``invalid_field``."""
    resp = client.post(
        "/v1/agent/run",
        json={"stack": "ccc", "model": "x"},
    )
    assert resp.status_code == 400
    assert resp.json()["error"] == "invalid_field"


def test_token_event_carries_text(client: TestClient) -> None:
    """``event: token`` data.text holds the assistant chunk."""
    _install_scripted_llm([LLMResponse(content="abc-delta")])

    resp = client.post(
        "/v1/agent/run",
        json={
            "stack": "ccc",
            "model": "m",
            "messages": [{"role": "user", "content": "ping"}],
        },
    )
    import json
    events = _parse_sse(resp.text)
    token_events = [json.loads(d) for ev, d in events if ev == "token"]
    assert token_events, f"no token events in {events!r}"
    assert token_events[0]["text"] == "abc-delta"


def test_strategos_marker_header(client: TestClient) -> None:
    """``strategos`` stack emits the forward-compat marker header."""
    _install_scripted_llm([LLMResponse(content="ok")])

    resp = client.post(
        "/v1/agent/run",
        json={
            "stack": "strategos",
            "model": "m",
            "messages": [{"role": "user", "content": "hi"}],
        },
    )
    assert resp.status_code == 200
    assert resp.headers.get("x-sancio-stack") == "strategos"


class _FakeEngine:
    """Stand-in for ``PersonaEngine`` used by the provider-backed path.

    Captures the ``ModelPolicy`` it receives so tests can assert
    ``policy.extra`` reflects the ``provider_extra`` wire payload.
    """

    def __init__(self) -> None:
        self.captured: dict[str, Any] = {}

    async def _llm_via_provider(
        self,
        policy: Any,
        messages: list[dict[str, Any]],
    ) -> str:
        self.captured["extra"] = dict(policy.extra)
        self.captured["model"] = policy.model
        return "ok"


@pytest.mark.asyncio
async def test_provider_extra_reaches_model_policy() -> None:
    """``_model_extra`` on messages[0] lands on ``ModelPolicy.extra``.

    Benchmark runners pin the sampler with
    ``provider_extra: {"seed": 42, "num_ctx": 16384}`` for paired-seed
    McNemar analyses. The wire path is:

      HTTP body.provider_extra
        -> messages[0]["_model_extra"]
        -> parsed in ``_provider_backed_llm_call``
        -> ``ModelPolicy.extra``.

    We exercise the tail three legs directly (bypassing HTTP) so the
    test doesn't need a provider registry fake.
    """
    engine = _FakeEngine()
    call = agent_api._provider_backed_llm_call(engine)
    resp = await call(
        [
            {
                "role": "user",
                "content": "hi",
                "_model": "anthropic:claude-sonnet-4-6",
                "_model_extra": {"seed": 42, "num_ctx": 16384},
            },
        ],
        [],
    )
    assert resp.content == "ok"
    assert engine.captured["extra"] == {"seed": 42, "num_ctx": 16384}


@pytest.mark.asyncio
async def test_provider_extra_missing_yields_empty_extra() -> None:
    """Absent ``_model_extra`` leaves ``ModelPolicy.extra`` empty."""
    engine = _FakeEngine()
    call = agent_api._provider_backed_llm_call(engine)
    await call(
        [
            {
                "role": "user",
                "content": "hi",
                "_model": "anthropic:claude-sonnet-4-6",
            },
        ],
        [],
    )
    assert engine.captured["extra"] == {}


@pytest.mark.asyncio
async def test_provider_extra_non_dict_value_is_ignored() -> None:
    """A non-dict ``_model_extra`` (e.g. a string) is silently dropped.

    Defends the provider layer from garbled client payloads — the
    endpoint's Pydantic validation already blocks bad shapes, but
    the adapter is reachable from other code paths (tests, future
    internal callers), so the type check stays.
    """
    engine = _FakeEngine()
    call = agent_api._provider_backed_llm_call(engine)
    await call(
        [
            {
                "role": "user",
                "content": "hi",
                "_model": "anthropic:claude-sonnet-4-6",
                "_model_extra": "not-a-dict",
            },
        ],
        [],
    )
    assert engine.captured["extra"] == {}


def test_cerno_config_forwarded_to_registry(
    client: TestClient, monkeypatch: pytest.MonkeyPatch,
) -> None:
    """``cerno_config`` in the request body reaches the registry.

    Benchmark runners opt into the Reflexion-lite retry path
    (MEMORY #56) by posting ``cerno_config: {"enable_retry": True}``.
    The endpoint must forward that dict unchanged into
    :func:`persona.api._get_or_create_cerno` so the registry can
    merge it on top of ``DEFAULT_CERNO_CONFIG``.
    """
    from persona import api as _api_module

    captured: dict[str, Any] = {}

    # Wrap the real factory so we see what the endpoint forwards.
    real_factory = _api_module._get_or_create_cerno

    def _spy(
        child_id: str,
        config_override: dict | None = None,
        *,
        tenant: str = "default",
    ) -> Any:
        captured["child_id"] = child_id
        captured["config_override"] = config_override
        captured["tenant"] = tenant
        return real_factory(
            child_id, config_override=config_override, tenant=tenant,
        )

    monkeypatch.setattr(_api_module, "_get_or_create_cerno", _spy)

    _install_scripted_llm([LLMResponse(content="ok")])
    resp = client.post(
        "/v1/agent/run",
        json={
            "stack": "sancio",
            "model": "m",
            "messages": [{"role": "user", "content": "hi"}],
            "tenant_id": "gaia",
            "cerno_config": {
                "enable_retry": True,
                "retry_max_attempts": 2,
            },
        },
    )
    assert resp.status_code == 200
    assert captured["tenant"] == "gaia"
    assert captured["config_override"] == {
        "enable_retry": True,
        "retry_max_attempts": 2,
    }


def test_cerno_config_omitted_defaults_to_none(
    client: TestClient, monkeypatch: pytest.MonkeyPatch,
) -> None:
    """When ``cerno_config`` is not in the body, registry sees ``None``.

    Production ``/v1/agent/run`` callers that skip the field must not
    accidentally flip retry on. ``None`` preserves the
    ``DEFAULT_CERNO_CONFIG`` path (``enable_retry=False``).
    """
    from persona import api as _api_module

    captured: dict[str, Any] = {}
    real_factory = _api_module._get_or_create_cerno

    def _spy(
        child_id: str,
        config_override: dict | None = None,
        *,
        tenant: str = "default",
    ) -> Any:
        captured["config_override"] = config_override
        return real_factory(
            child_id, config_override=config_override, tenant=tenant,
        )

    monkeypatch.setattr(_api_module, "_get_or_create_cerno", _spy)

    _install_scripted_llm([LLMResponse(content="ok")])
    resp = client.post(
        "/v1/agent/run",
        json={
            "stack": "sancio",
            "model": "m",
            "messages": [{"role": "user", "content": "hi"}],
        },
    )
    assert resp.status_code == 200
    assert captured["config_override"] is None


def test_tool_call_and_tool_result_events(client: TestClient) -> None:
    """A tool-using reply emits tool_call + tool_result frames."""
    # First LLM turn: emit a tool_call for list_files.
    # Second LLM turn: natural language close.
    replies = [
        LLMResponse(
            content="",
            tool_calls=[
                ToolCall(id="tc1", name="list_files", args={"path": "."}),
            ],
        ),
        LLMResponse(content="done-listing"),
    ]
    _install_scripted_llm(replies)

    resp = client.post(
        "/v1/agent/run",
        json={
            "stack": "ccc",
            "model": "m",
            "messages": [{"role": "user", "content": "list"}],
            "max_iterations": 5,
        },
    )

    assert resp.status_code == 200
    events = _parse_sse(resp.text)
    kinds = [ev for ev, _ in events]
    # tool_call / tool_result pair must be present.
    assert "tool_call" in kinds
    assert "tool_result" in kinds
    # Final token + done still emitted.
    assert kinds[-1] == "done"
