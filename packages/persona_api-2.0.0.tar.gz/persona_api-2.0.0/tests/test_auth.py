"""Account system MVP — auth + config sync tests.

Covers:
  * login happy path + bad password + unknown user
  * /v1/auth/me with/without Bearer
  * /v1/config GET + PUT round-trip
  * /v1/auth/change-password happy path + old-pw mismatch
  * /v1/auth/logout event-record

Uses an isolated on-disk SQLite DB per test via the ``auth_env`` fixture,
so tests never touch the production /opt/persona-api/data/auth.db path.
"""

from __future__ import annotations

import os
from pathlib import Path

import pytest
from starlette.applications import Starlette
from starlette.testclient import TestClient

from persona import auth
from persona.auth import create_auth_routes


@pytest.fixture()
def auth_env(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> Path:
    """Point auth at a throwaway SQLite DB + a deterministic JWT secret."""
    db = tmp_path / "auth.db"
    monkeypatch.setenv("AUTH_DB_PATH", str(db))
    monkeypatch.setenv("AEGIS_JWT_SECRET", "test-secret-do-not-use-in-prod")
    return db


@pytest.fixture()
def client(auth_env: Path) -> TestClient:
    """Build a Starlette app with only the auth routes mounted."""
    app = Starlette(routes=create_auth_routes())
    # Seed the canonical MVP user for every test.
    auth.create_user("mm9319", "mm9319")
    return TestClient(app)


# ── login ──────────────────────────────────────────────────────────


def test_login_happy_path_returns_bearer_token(client: TestClient) -> None:
    r = client.post(
        "/v1/auth/login",
        json={"username": "mm9319", "password": "mm9319"},
    )
    assert r.status_code == 200, r.text
    body = r.json()
    assert body["token_type"] == "Bearer"
    assert isinstance(body["token"], str) and len(body["token"]) > 20
    assert body["expires_in"] == 24 * 3600
    assert body["user"]["username"] == "mm9319"
    assert "password_hash" not in body["user"]


def test_login_rejects_bad_password(client: TestClient) -> None:
    r = client.post(
        "/v1/auth/login",
        json={"username": "mm9319", "password": "wrong"},
    )
    assert r.status_code == 401
    assert r.json()["error"] == "invalid_credentials"


def test_login_rejects_unknown_user(client: TestClient) -> None:
    r = client.post(
        "/v1/auth/login",
        json={"username": "ghost", "password": "whatever"},
    )
    assert r.status_code == 401
    assert r.json()["error"] == "invalid_credentials"


def test_login_rejects_missing_fields(client: TestClient) -> None:
    r = client.post("/v1/auth/login", json={"username": "mm9319"})
    assert r.status_code == 400


# ── /v1/auth/me ────────────────────────────────────────────────────


def test_me_requires_bearer(client: TestClient) -> None:
    r = client.get("/v1/auth/me")
    assert r.status_code == 401
    assert r.json()["error"] == "unauthorized"


def test_me_returns_current_user(client: TestClient) -> None:
    token = client.post(
        "/v1/auth/login",
        json={"username": "mm9319", "password": "mm9319"},
    ).json()["token"]
    r = client.get(
        "/v1/auth/me",
        headers={"Authorization": f"Bearer {token}"},
    )
    assert r.status_code == 200
    assert r.json()["user"]["username"] == "mm9319"


def test_me_rejects_garbled_token(client: TestClient) -> None:
    r = client.get(
        "/v1/auth/me",
        headers={"Authorization": "Bearer not.a.jwt"},
    )
    assert r.status_code == 401


# ── /v1/config ─────────────────────────────────────────────────────


def _bearer(client: TestClient) -> dict[str, str]:
    tok = client.post(
        "/v1/auth/login",
        json={"username": "mm9319", "password": "mm9319"},
    ).json()["token"]
    return {"Authorization": f"Bearer {tok}"}


def test_config_get_defaults_to_empty(client: TestClient) -> None:
    r = client.get("/v1/config", headers=_bearer(client))
    assert r.status_code == 200
    assert r.json()["config"] == {}


def test_config_put_then_get_round_trips(client: TestClient) -> None:
    h = _bearer(client)
    payload = {
        "config": {
            "stackEndpoints": {
                "aegis": "https://aegis.ai-king.dev",
            },
            "digitalHumanCharacterName": "purple",
            "digitalHumanTrial": True,
        },
    }
    r = client.put("/v1/config", headers=h, json=payload)
    assert r.status_code == 200, r.text
    r = client.get("/v1/config", headers=h)
    assert r.status_code == 200
    assert r.json()["config"] == payload["config"]


def test_config_put_rejects_non_object(client: TestClient) -> None:
    r = client.put(
        "/v1/config",
        headers=_bearer(client),
        json={"config": "not-an-object"},
    )
    assert r.status_code == 400


# ── change-password ────────────────────────────────────────────────


def test_change_password_happy_path(client: TestClient) -> None:
    h = _bearer(client)
    r = client.post(
        "/v1/auth/change-password",
        headers=h,
        json={"old": "mm9319", "new": "new-secret-42"},
    )
    assert r.status_code == 200
    # Old password no longer works.
    assert client.post(
        "/v1/auth/login",
        json={"username": "mm9319", "password": "mm9319"},
    ).status_code == 401
    # New password works.
    assert client.post(
        "/v1/auth/login",
        json={"username": "mm9319", "password": "new-secret-42"},
    ).status_code == 200


def test_change_password_rejects_wrong_old(client: TestClient) -> None:
    r = client.post(
        "/v1/auth/change-password",
        headers=_bearer(client),
        json={"old": "nope", "new": "something-else"},
    )
    assert r.status_code == 401


# ── logout ─────────────────────────────────────────────────────────


def test_logout_records_event(client: TestClient) -> None:
    h = _bearer(client)
    r = client.post("/v1/auth/logout", headers=h)
    assert r.status_code == 200
    assert r.json() == {"ok": True}
    # Event row should exist.
    conn = auth._connect()
    try:
        rows = conn.execute(
            "SELECT event FROM auth_events WHERE user_id = 1 ORDER BY id",
        ).fetchall()
    finally:
        conn.close()
    events = [r[0] for r in rows]
    assert "login" in events and "logout" in events


# ── unit-level checks ──────────────────────────────────────────────


def test_hash_roundtrip(auth_env: Path) -> None:
    h = auth.hash_password("hunter2")
    assert auth.verify_password("hunter2", h) is True
    assert auth.verify_password("hunter3", h) is False


def test_jwt_roundtrip(auth_env: Path) -> None:
    t = auth.issue_token(42, "alice", ttl_s=60)
    claims = auth.verify_token(t)
    assert claims is not None
    assert claims["sub"] == "42"
    assert claims["username"] == "alice"


def test_create_user_rejects_duplicate(auth_env: Path) -> None:
    auth.create_user("alice", "pw1")
    with pytest.raises(ValueError):
        auth.create_user("alice", "pw2")


def test_db_path_env_override(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    target = tmp_path / "other.db"
    monkeypatch.setenv("AUTH_DB_PATH", str(target))
    assert auth._db_path() == str(target)
    # Touching the DB should create the file.
    auth.create_user("u1", "p1")
    assert target.exists()
    # Clean up so other tests don't inherit this file.
    os.remove(target)


# ── 0.17.0 — permission gate cloud sync ────────────────────────────


def test_mm9319_default_has_autoapprove_true(
    auth_env: Path, tmp_path: Path,
) -> None:
    """After running the autoApproveAll migration, mm9319's loaded
    config must contain ``autoApproveAll: true`` so the extension can
    pull it and silently skip the permission gate."""
    # Seed user + apply the migration the VPS would run.
    auth.create_user("mm9319", "mm9319")
    user = auth.get_user_by_username("mm9319")
    assert user is not None
    auth.save_config(user["id"], {"autoApproveAll": True})
    cfg = auth.load_config(user["id"])
    assert cfg.get("autoApproveAll") is True


def test_config_whitelist_accepts_autoapprove(client: TestClient) -> None:
    """PUT /v1/config must accept ``autoApproveAll`` and round-trip
    it, while silently dropping keys that aren't in ``allowed_config_keys``."""
    assert "autoApproveAll" in auth.allowed_config_keys
    h = _bearer(client)
    r = client.put(
        "/v1/config",
        headers=h,
        json={
            "config": {
                "autoApproveAll": True,
                # This one should be dropped — not in the whitelist.
                "notAllowed": "leak",
            },
        },
    )
    assert r.status_code == 200, r.text
    returned = r.json()["config"]
    assert returned.get("autoApproveAll") is True
    assert "notAllowed" not in returned
    # And the stored blob reflects the filter.
    r2 = client.get("/v1/config", headers=h)
    assert r2.status_code == 200
    stored = r2.json()["config"]
    assert stored.get("autoApproveAll") is True
    assert "notAllowed" not in stored
