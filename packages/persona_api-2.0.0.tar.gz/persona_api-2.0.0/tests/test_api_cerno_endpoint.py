"""Tests for /v1/cerno/cycle — Phase 1 P1.2 LIVE.

History
-------
Previously this endpoint returned HTTP 501 with a stable error shape
while the aegis-fw Python Cerno was waiting to land. That contract
is now replaced: the endpoint is backed by a real
``persona.cerno.Cerno`` instance keyed per ``child_id`` at
module level, and the file ports its tests from "assert 501" to
"assert 200 with CernoAction shape + regression on 400 / 500 /
adjacent endpoints".

The port verification lives in ``test_persona_cerno_module.py`` —
this file is the HTTP contract layer.
"""

from __future__ import annotations

import pytest
from starlette.applications import Starlette
from starlette.testclient import TestClient

from persona.api import (
    _set_cernos_for_tests,
    create_aegis_routes,
)


@pytest.fixture()
def client() -> TestClient:
    """Return a TestClient wrapping the persona-api Starlette app.

    Also resets the module-level cerno registry so each test
    starts with a clean equilibrium/state.
    """
    _set_cernos_for_tests(None)
    app = Starlette(routes=create_aegis_routes())
    try:
        yield TestClient(app)
    finally:
        _set_cernos_for_tests(None)


# ── 1. Happy-path 200 + shape ────────────────────


def test_cerno_cycle_happy_path_allow(client: TestClient) -> None:
    """Benign input → 200 + action.type='allow' + full shape."""
    resp = client.post(
        "/v1/cerno/cycle",
        json={
            "intent": "summarize this article",
            "child_output": "Here is a short summary of the article.",
            "child_id": "happy-child",
        },
    )
    assert resp.status_code == 200
    data = resp.json()

    # Action shape
    assert "action" in data and isinstance(data["action"], dict)
    assert data["action"].get("type") in {
        "allow", "deny", "transfer", "recalibrate",
    }

    # Top-level keys present
    for key in ("action", "review", "assessment", "state"):
        assert key in data

    # State shape
    state = data["state"]
    assert state["child_id"] == "happy-child"
    assert isinstance(state["consecutive_denies"], int)
    assert state["current_identity"] in {
        "mirror", "sage", "judge", "guardian",
    }
    assert isinstance(state["equilibrium"], dict)
    assert isinstance(state["recent_scores"], list)


def test_cerno_cycle_deny_on_false_certainty(
    client: TestClient,
) -> None:
    """Output stuffed with `definitely`/`guaranteed` → critical L7 → deny.

    Path 1 of :func:`persona.cerno.intercept.intercept` short-
    circuits on any ``severity=high`` + ``confidence>=0.6`` defect
    regardless of quality_score. L7 false_certainty fits that
    profile when two or more high-certainty adverbs fire.
    """
    resp = client.post(
        "/v1/cerno/cycle",
        json={
            "intent": "explain the solution",
            "child_output": (
                "This will definitely work and is absolutely "
                "guaranteed to succeed without doubt."
            ),
            "child_id": "deny-child",
        },
    )
    assert resp.status_code == 200
    data = resp.json()
    # We do not hard-assert 'deny' because detector sensitivity is
    # config-dependent, but if the system denied, the shape must
    # include a reason + defects list (discriminator contract).
    action = data["action"]
    if action["type"] == "deny":
        assert "reason" in action and isinstance(action["reason"], str)
        assert "defects" in action and isinstance(action["defects"], list)
    else:
        # Otherwise the review still must have captured an L7 hit.
        review = data.get("review") or {}
        ids = [d.get("id") for d in review.get("defects_found", [])]
        assert "L7" in ids or action["type"] in {"allow", "recalibrate"}


def test_cerno_cycle_preserves_state_across_calls(
    client: TestClient,
) -> None:
    """Same child_id → recent_scores list grows across calls."""
    payload = {
        "intent": "summarize briefly",
        "child_output": "A terse summary.",
        "child_id": "stateful-child",
    }
    first = client.post("/v1/cerno/cycle", json=payload).json()
    second = client.post("/v1/cerno/cycle", json=payload).json()

    first_len = len(first["state"]["recent_scores"])
    second_len = len(second["state"]["recent_scores"])
    assert second_len > first_len, (
        "recent_scores should accumulate across calls for the same child_id; "
        f"first={first_len} second={second_len}"
    )
    assert first["state"]["child_id"] == second["state"]["child_id"]


def test_cerno_cycle_different_child_isolated(
    client: TestClient,
) -> None:
    """Different child_id → isolated recent_scores (registry keying)."""
    payload_a = {
        "intent": "alpha intent",
        "child_output": "alpha out",
        "child_id": "child-a",
    }
    payload_b = {
        "intent": "beta intent",
        "child_output": "beta out",
        "child_id": "child-b",
    }
    # Fire A three times, B once. B should have 1 recent_score, not 4.
    for _ in range(3):
        client.post("/v1/cerno/cycle", json=payload_a)
    b = client.post("/v1/cerno/cycle", json=payload_b).json()
    assert len(b["state"]["recent_scores"]) == 1
    assert b["state"]["child_id"] == "child-b"


def test_cerno_cycle_config_override_applied(
    client: TestClient,
) -> None:
    """`config.deny_quality_threshold` override respected on new child."""
    resp = client.post(
        "/v1/cerno/cycle",
        json={
            "intent": "verify",
            "child_output": "ok",
            "child_id": "cfg-child",
            "config": {"deny_quality_threshold": 95},
        },
    )
    assert resp.status_code == 200


# ── 2. 400 error shapes ─────────────────────────


def test_cerno_cycle_malformed_json_400(client: TestClient) -> None:
    """Non-JSON body → 400 invalid_body."""
    resp = client.post(
        "/v1/cerno/cycle",
        content=b"not-json{{{",
        headers={"content-type": "application/json"},
    )
    assert resp.status_code == 400
    assert resp.json().get("error") == "invalid_body"


def test_cerno_cycle_empty_body_400(client: TestClient) -> None:
    """Empty object → 400 missing_field (intent required)."""
    resp = client.post("/v1/cerno/cycle", json={})
    assert resp.status_code == 400
    assert resp.json().get("error") == "missing_field"


def test_cerno_cycle_missing_child_id_400(client: TestClient) -> None:
    """`intent` present but `child_id` missing → 400 missing_field."""
    resp = client.post(
        "/v1/cerno/cycle",
        json={"intent": "do a thing", "child_output": "done"},
    )
    assert resp.status_code == 400
    assert resp.json().get("error") == "missing_field"


def test_cerno_cycle_bad_field_type_400(client: TestClient) -> None:
    """`config` not a dict → 400 invalid_field."""
    resp = client.post(
        "/v1/cerno/cycle",
        json={
            "intent": "do",
            "child_id": "bad-cfg",
            "config": "not-a-dict",
        },
    )
    assert resp.status_code == 400
    assert resp.json().get("error") == "invalid_field"


# ── 3. 500 shape on forced internal error ───────


def test_cerno_cycle_cycle_exception_500(
    client: TestClient,
    monkeypatch,
) -> None:
    """Forced Cerno.cycle exception → 500 cycle_failed shape."""
    from persona import api as api_module
    from persona.cerno import Cerno

    def _explode(self: Cerno, intent: str, child_output: str) -> None:  # noqa: ARG001
        raise RuntimeError("synthetic blast")

    monkeypatch.setattr(Cerno, "cycle", _explode)
    # Ensure the registry is empty so the next request constructs a
    # fresh Cerno that will hit the patched method.
    api_module._set_cernos_for_tests(None)

    resp = client.post(
        "/v1/cerno/cycle",
        json={
            "intent": "make it boom",
            "child_output": "boom",
            "child_id": "boom-child",
        },
    )
    assert resp.status_code == 500
    data = resp.json()
    assert data.get("error") == "cycle_failed"
    assert "synthetic blast" in data.get("detail", "")


# ── 4. Regression: adjacent endpoints unchanged ──


def test_regression_health_endpoint_unchanged(
    client: TestClient,
) -> None:
    resp = client.get("/v1/health")
    assert resp.status_code == 200
    data = resp.json()
    assert data.get("status") == "ok"
    assert data.get("service") == "sancio"


def test_regression_load_endpoint_still_validates(
    client: TestClient,
) -> None:
    resp = client.post("/v1/load", json={})
    assert resp.status_code == 400
    assert "error" in resp.json()


# ── 5. Registry lifecycle (DELETE + GET + LRU) ───
#
# Session 2026-04-15 P3.1: per-child Cerno registry gains explicit
# lifecycle management — LRU eviction on ``_CERNO_REGISTRY_CAP``
# overflow, DELETE endpoint for deterministic teardown, GET for
# observability. These tests cover both the new endpoints and the
# LRU-touch side effect on the existing ``/v1/cerno/cycle`` call.


def _post_cycle(client: TestClient, child_id: str) -> dict:
    """Fire one minimal cycle request for ``child_id``."""
    payload = {
        "intent": "summarize briefly",
        "child_output": "ok",
        "child_id": child_id,
    }
    resp = client.post("/v1/cerno/cycle", json=payload)
    assert resp.status_code == 200, resp.text
    return resp.json()


class TestCernoRegistryLifecycle:
    """DELETE + GET /v1/cerno/registry + LRU eviction contracts."""

    def test_cerno_delete_removes_existing(
        self, client: TestClient,
    ) -> None:
        """POST creates, DELETE returns 200, GET registry count drops."""
        _post_cycle(client, "del-child")

        before = client.get("/v1/cerno/registry").json()
        assert before["count"] == 1

        resp = client.delete("/v1/cerno/cycle/del-child")
        assert resp.status_code == 200
        body = resp.json()
        assert body == {"deleted": True, "child_id": "del-child"}

        after = client.get("/v1/cerno/registry").json()
        assert after["count"] == 0
        assert after["children"] == []

    def test_cerno_delete_404_on_unknown_child(
        self, client: TestClient,
    ) -> None:
        """DELETE on never-created child → 404 not_found shape."""
        resp = client.delete("/v1/cerno/cycle/ghost-child")
        assert resp.status_code == 404
        body = resp.json()
        assert body.get("error") == "not_found"
        assert body.get("child_id") == "ghost-child"

    def test_cerno_delete_idempotency(
        self, client: TestClient,
    ) -> None:
        """First DELETE → 200, second DELETE on same id → 404."""
        _post_cycle(client, "twice-child")

        first = client.delete("/v1/cerno/cycle/twice-child")
        assert first.status_code == 200
        assert first.json().get("deleted") is True

        second = client.delete("/v1/cerno/cycle/twice-child")
        assert second.status_code == 404
        assert second.json().get("error") == "not_found"

    def test_cerno_registry_list_shape(
        self, client: TestClient,
    ) -> None:
        """POST 3 different children → count=3 + LRU order + 4 fields."""
        for cid in ("lst-a", "lst-b", "lst-c"):
            _post_cycle(client, cid)

        resp = client.get("/v1/cerno/registry")
        assert resp.status_code == 200
        body = resp.json()

        assert body["count"] == 3
        assert isinstance(body["cap"], int) and body["cap"] >= 1
        assert isinstance(body["children"], list)
        assert len(body["children"]) == 3

        # LRU order: oldest first, newest last. We inserted a, b, c
        # with no subsequent touches, so the order is exactly a,b,c.
        ids = [row["child_id"] for row in body["children"]]
        assert ids == ["lst-a", "lst-b", "lst-c"]

        # Shape check: all 4 required fields, correct types.
        for row in body["children"]:
            assert set(row.keys()) == {
                "child_id",
                "consecutive_denies",
                "recent_score_count",
                "current_identity",
            }
            assert isinstance(row["child_id"], str)
            assert isinstance(row["consecutive_denies"], int)
            assert isinstance(row["recent_score_count"], int)
            assert isinstance(row["current_identity"], str)
            assert row["recent_score_count"] >= 1

    def test_cerno_registry_list_lru_order_after_access(
        self, client: TestClient,
    ) -> None:
        """POST a,b,c then re-POST a → LRU order flips to b,c,a."""
        for cid in ("ord-a", "ord-b", "ord-c"):
            _post_cycle(client, cid)
        # Touch ``ord-a`` so it becomes MRU. This goes through
        # ``_cerno_cycle``, which calls ``_get_or_create_cerno``
        # and then ``_cernos.move_to_end`` explicitly.
        _post_cycle(client, "ord-a")

        body = client.get("/v1/cerno/registry").json()
        ids = [row["child_id"] for row in body["children"]]
        assert ids == ["ord-b", "ord-c", "ord-a"], (
            f"LRU order broken after re-POST; got {ids}"
        )

    def test_cerno_registry_lru_eviction_on_cap(
        self,
        client: TestClient,
        monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        """cap=2 + POST a,b,c → a evicted, b+c remain."""
        from persona import api as api_module

        monkeypatch.setattr(api_module, "_CERNO_REGISTRY_CAP", 2)

        _post_cycle(client, "cap-a")
        _post_cycle(client, "cap-b")
        # Registry full at cap=2. Next POST should evict cap-a (LRU).
        _post_cycle(client, "cap-c")

        body = client.get("/v1/cerno/registry").json()
        ids = [row["child_id"] for row in body["children"]]
        assert ids == ["cap-b", "cap-c"]
        assert body["count"] == 2
        assert body["cap"] == 2

        # DELETE on the evicted child should now return 404 —
        # its slot in the registry is gone.
        resp = client.delete("/v1/cerno/cycle/cap-a")
        assert resp.status_code == 404

    def test_cerno_lru_touch_on_cycle_read(
        self,
        client: TestClient,
        monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        """cap=2, POST a,b, re-POST a → POST c evicts b not a.

        Asserts LRU touches fire on every ``/v1/cerno/cycle`` call,
        not only on the initial create. Without the touch, a hot
        child_id would still be evicted the moment ~cap~ cold
        newcomers pile up.
        """
        from persona import api as api_module

        monkeypatch.setattr(api_module, "_CERNO_REGISTRY_CAP", 2)

        _post_cycle(client, "hot-a")
        _post_cycle(client, "hot-b")
        # Touch ``hot-a`` → LRU=[hot-b, hot-a], ``hot-b`` is now LRU.
        _post_cycle(client, "hot-a")
        # Insert ``hot-c`` → evicts ``hot-b`` (least-recently-used).
        _post_cycle(client, "hot-c")

        body = client.get("/v1/cerno/registry").json()
        ids = [row["child_id"] for row in body["children"]]
        assert ids == ["hot-a", "hot-c"], (
            f"LRU touch broken on cycle read; got {ids}"
        )

        # ``hot-b`` should be gone, ``hot-a`` should still resolve.
        assert client.delete("/v1/cerno/cycle/hot-b").status_code == 404
        assert client.delete("/v1/cerno/cycle/hot-a").status_code == 200

    def test_cerno_registry_empty_on_fresh_app(
        self, client: TestClient,
    ) -> None:
        """Fresh fixture → GET registry returns count=0 + children=[]."""
        resp = client.get("/v1/cerno/registry")
        assert resp.status_code == 200
        body = resp.json()
        assert body["count"] == 0
        assert body["children"] == []
        assert "cap" in body and isinstance(body["cap"], int)

    def test_cerno_cycle_state_preserved_with_lru(
        self, client: TestClient,
    ) -> None:
        """LRU touch must not break recent_scores accumulation.

        Regression twin of
        :func:`test_cerno_cycle_preserves_state_across_calls` — the
        LRU side-effect in ``_cerno_cycle`` should be idempotent
        and must not reset or rebuild the Cerno instance.
        """
        payload = {
            "intent": "summarize briefly",
            "child_output": "A terse summary.",
            "child_id": "lru-stateful",
        }
        first = client.post("/v1/cerno/cycle", json=payload).json()
        second = client.post("/v1/cerno/cycle", json=payload).json()
        third = client.post("/v1/cerno/cycle", json=payload).json()

        first_len = len(first["state"]["recent_scores"])
        second_len = len(second["state"]["recent_scores"])
        third_len = len(third["state"]["recent_scores"])

        assert first_len < second_len < third_len, (
            "LRU touch broke recent_scores accumulation; "
            f"lens={first_len},{second_len},{third_len}"
        )

        # Registry still reports exactly one child and the
        # recent_score_count matches the final cycle's state length.
        body = client.get("/v1/cerno/registry").json()
        assert body["count"] == 1
        assert body["children"][0]["child_id"] == "lru-stateful"
        assert (
            body["children"][0]["recent_score_count"] == third_len
        )
