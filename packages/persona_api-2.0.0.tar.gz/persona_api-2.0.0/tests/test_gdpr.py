"""GDPR endpoint tests — Art 15 export + Art 17 erasure + privacy."""

from __future__ import annotations

from pathlib import Path

import pytest
from starlette.applications import Starlette
from starlette.testclient import TestClient

from persona import auth, gdpr
from persona.auth import create_auth_routes
from persona.gdpr import create_gdpr_routes


@pytest.fixture()
def gdpr_env(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> Path:
    """Isolate auth DB + budget DB + JWT secret per test."""
    db = tmp_path / "auth.db"
    bdb = tmp_path / "budget.db"
    monkeypatch.setenv("AUTH_DB_PATH", str(db))
    monkeypatch.setenv("SANCIO_BUDGET_DB_PATH", str(bdb))
    monkeypatch.setenv("AEGIS_JWT_SECRET", "test-secret-gdpr")
    # Short retention so purge_expired tests don't need sleep.
    monkeypatch.setenv("SANCIO_GDPR_RETENTION_DAYS", "7")
    # Reload module-level constant (read at import time).
    monkeypatch.setattr(gdpr, "SOFT_DELETE_RETENTION_DAYS", 7)
    return db


@pytest.fixture()
def client(gdpr_env: Path) -> TestClient:
    """Starlette app with auth + gdpr routes mounted, no middleware."""
    app = Starlette(routes=create_auth_routes() + create_gdpr_routes())
    return TestClient(app)


def _login(client: TestClient, username: str, password: str) -> str:
    r = client.post(
        "/v1/auth/login", json={"username": username, "password": password},
    )
    assert r.status_code == 200, r.text
    return r.json()["token"]


# ── /v1/privacy (public) ───────────────────────


def test_privacy_endpoint_is_public(client: TestClient) -> None:
    r = client.get("/v1/privacy")
    assert r.status_code == 200
    body = r.json()
    assert body["controller"].startswith("AI King")
    assert "privacy@ai-king.dev" == body["contact"]
    assert "erasure" in body["rights"]
    assert "export" in body["endpoints"]
    assert body["legal_basis"].startswith("GDPR Art 6")


def test_privacy_includes_retention_schedule(client: TestClient) -> None:
    r = client.get("/v1/privacy")
    ret = r.json()["retention"]
    assert "budget_db" in ret
    assert "audit_log" in ret
    assert "profile" in ret


# ── /v1/gdpr/export ─────────────────────────────


def test_export_requires_bearer(client: TestClient) -> None:
    r = client.post("/v1/gdpr/export")
    assert r.status_code == 401


def test_export_returns_user_data(client: TestClient) -> None:
    auth.create_user("alice", "alicepw")
    token = _login(client, "alice", "alicepw")
    r = client.post(
        "/v1/gdpr/export", headers={"Authorization": f"Bearer {token}"},
    )
    assert r.status_code == 200, r.text
    body = r.json()
    assert body["schema_version"] == "1"
    assert body["user_id"] > 0
    assert body["profile"]["user"]["username"] == "alice"
    # password hash must NEVER appear in an export
    assert "password_hash" not in body["profile"]["user"]
    assert isinstance(body["budget_history"], list)
    assert isinstance(body["a2a_invocations"], list)
    # Login event must be in the audit trail.
    events = [e["event"] for e in body["profile"]["auth_events"]]
    assert "login" in events


def test_export_writes_audit_event(client: TestClient) -> None:
    auth.create_user("bob", "bobpw")
    token = _login(client, "bob", "bobpw")
    client.post(
        "/v1/gdpr/export", headers={"Authorization": f"Bearer {token}"},
    )
    # Second export → now the event trail has gdpr_export.
    r = client.post(
        "/v1/gdpr/export", headers={"Authorization": f"Bearer {token}"},
    )
    events = [e["event"] for e in r.json()["profile"]["auth_events"]]
    assert "gdpr_export" in events


# ── /v1/gdpr/delete ─────────────────────────────


def test_delete_requires_bearer(client: TestClient) -> None:
    r = client.post("/v1/gdpr/delete")
    assert r.status_code == 401


def test_delete_creates_soft_delete_record(client: TestClient) -> None:
    auth.create_user("carol", "carolpw")
    token = _login(client, "carol", "carolpw")
    r = client.post(
        "/v1/gdpr/delete", headers={"Authorization": f"Bearer {token}"},
    )
    assert r.status_code == 200, r.text
    body = r.json()
    assert body["state"] == "pending_hard_delete"
    assert body["retention_days"] == 7
    assert body["hard_delete_after"] > body["requested_at"]
    # User row STILL EXISTS until purge_expired runs.
    row = auth.get_user_by_username("carol")
    assert row is not None


def test_delete_is_idempotent(client: TestClient) -> None:
    auth.create_user("dave", "davepw")
    token = _login(client, "dave", "davepw")
    r1 = client.post(
        "/v1/gdpr/delete", headers={"Authorization": f"Bearer {token}"},
    ).json()
    r2 = client.post(
        "/v1/gdpr/delete", headers={"Authorization": f"Bearer {token}"},
    ).json()
    # Second request bumps requested_at but keeps same user_id.
    assert r1["user_id"] == r2["user_id"]
    assert r2["requested_at"] >= r1["requested_at"]


def test_purge_expired_hard_deletes_after_retention(
    client: TestClient,
) -> None:
    auth.create_user("erin", "erinpw")
    token = _login(client, "erin", "erinpw")
    # Schedule deletion.
    client.post(
        "/v1/gdpr/delete", headers={"Authorization": f"Bearer {token}"},
    )
    user = auth.get_user_by_username("erin")
    assert user is not None
    # Fast-forward past the retention window.
    far_future = 2 ** 31 - 1
    purged = gdpr.purge_expired(now=far_future)
    assert user["id"] in purged
    # Verify the row is gone.
    assert auth.get_user_by_username("erin") is None


def test_purge_expired_respects_retention_window(
    client: TestClient,
) -> None:
    auth.create_user("frank", "frankpw")
    token = _login(client, "frank", "frankpw")
    r = client.post(
        "/v1/gdpr/delete", headers={"Authorization": f"Bearer {token}"},
    ).json()
    # Before retention expires, purge should be a no-op for this user.
    before = r["hard_delete_after"] - 1
    purged = gdpr.purge_expired(now=before)
    assert r["user_id"] not in purged
    assert auth.get_user_by_username("frank") is not None
