"""End-to-end integration: SKILL.md → glue → dispatcher → adapter → hooks.

Wires :mod:`persona.runtime_dispatcher_glue` against the live
:class:`persona.event_dispatcher.EventDispatcher`. The unit-test suite in
``tests/test_event_dispatcher/`` covers the dispatcher in isolation;
this file proves the runtime glue actually feeds it from real
``SKILL.md`` files and translates :class:`AgentLoop`-shaped tool-loop
events into spec-compliant ``OutcomeRecord`` rows.

Five scenarios:

1. SKILL.md with block-style ``event_bindings`` is discovered + parsed
   correctly (tests the PyYAML fallback for the YAML-lite parser gap).
2. Pre-hook fires ``PreToolUse`` and the binding's adapter records an
   outcome (skill_not_found stub is the right shape for v0.6).
3. Predicate ``when`` returning False produces a ``skipped`` outcome
   without invoking the adapter.
4. Post-hook fires ``PostToolUseFailure`` when the tool result string
   carries the ``"tool error:"`` prefix (mirrors AgentLoop's encoding).
5. ``get_dispatcher`` returns the same instance for the same
   ``session_id`` and a different one across sessions.
"""

from __future__ import annotations

import asyncio
import tempfile
from pathlib import Path

import pytest

from persona.runtime_dispatcher_glue import (
    discover_event_bindings,
    fire_stop,
    fire_user_prompt_submit,
    get_dispatcher,
    make_dispatcher_post_hook,
    make_dispatcher_pre_hook,
    parse_skill_md_with_bindings,
    reset_discovery_cache,
    reset_dispatcher_cache,
)


# Synthetic SKILL.md with block-style event_bindings — exactly the
# shape concinno's YAML-lite parser refuses to unpack. The glue's
# PyYAML fallback owns the rescue.
_SKILL_MD_BLOCK = """---
name: triage_failed_test
description: fires after Edit on test files
triggers:
  - edit
  - test_file
event_bindings:
  - event: PreToolUse
    when: 'tool_name == "Edit" and "test_" in file_path'
    invoke: triage_failed_test
    priority: 80
  - event: PostToolUseFailure
    invoke: triage_failed_test
    cooldown_seconds: 0
  - event: Stop
    invoke: handoff_check
    cooldown_seconds: 30
---

# Triage failed test

Body content.
"""


@pytest.fixture(autouse=True)
def _isolate_dispatcher_cache():
    """Reset the per-session dispatcher cache and discovery cache around
    each test so we never bleed bindings from one scenario into another.
    """
    reset_dispatcher_cache()
    reset_discovery_cache()
    yield
    reset_dispatcher_cache()
    reset_discovery_cache()


def _write_skill_md(parent: Path, name: str, body: str) -> Path:
    """Build ``<parent>/<name>/SKILL.md`` with the given body."""
    skill_dir = parent / name
    skill_dir.mkdir(parents=True, exist_ok=True)
    md = skill_dir / "SKILL.md"
    md.write_text(body, encoding="utf-8")
    return md


def _make_skills_root(tmp_path: Path) -> Path:
    """Mirror the ``~/.claude/skills`` shape under tmp_path."""
    root = tmp_path / "skills"
    root.mkdir(parents=True, exist_ok=True)
    return root


# ── 1. SKILL.md → meta with event_bindings ──────────────────────────


def test_parse_skill_md_with_bindings_extracts_block_list(tmp_path: Path):
    md = _write_skill_md(tmp_path, "triage_failed_test", _SKILL_MD_BLOCK)
    meta = parse_skill_md_with_bindings(md)
    assert meta["name"] == "triage_failed_test"
    bindings = meta["event_bindings"]
    assert isinstance(bindings, list)
    assert len(bindings) == 3
    # First binding round-trips event + when + invoke + priority.
    assert bindings[0]["event"] == "PreToolUse"
    assert bindings[0]["invoke"] == "triage_failed_test"
    assert bindings[0]["priority"] == 80
    assert bindings[0]["when"].startswith("tool_name == ")
    # Last binding has cooldown_seconds.
    assert bindings[2]["event"] == "Stop"
    assert bindings[2]["cooldown_seconds"] == 30


def test_discover_event_bindings_walks_extra_root(tmp_path: Path):
    root = _make_skills_root(tmp_path)
    _write_skill_md(root, "triage_failed_test", _SKILL_MD_BLOCK)
    # Plus a second skill with no bindings — should still load name but
    # not produce any binding.
    _write_skill_md(
        root, "noop", "---\nname: noop\ndescription: empty\n---\n",
    )

    out = discover_event_bindings(extra_roots=[root])
    names = {meta.get("name") for _path, meta in out}
    assert "triage_failed_test" in names
    assert "noop" in names
    # The triage_failed_test entry has bindings; noop does not.
    by_name = {meta["name"]: meta for _p, meta in out}
    assert "event_bindings" in by_name["triage_failed_test"]
    assert "event_bindings" not in by_name["noop"]


# ── 2 & 3. Hooks fire → predicate gating ──────────────────────────


def test_pre_hook_fires_PreToolUse_with_predicate_match(tmp_path: Path):
    root = _make_skills_root(tmp_path)
    _write_skill_md(root, "triage_failed_test", _SKILL_MD_BLOCK)

    cache_dir = tempfile.mkdtemp(prefix="rdg_int_")
    dispatcher = get_dispatcher(
        "session-A", cache_dir=cache_dir, extra_roots=[root],
    )
    # Two of three bindings register (Stop + PreToolUse + PostToolUseFailure
    # all have valid event names; that's three).
    assert len(dispatcher.binding_ids()) == 3

    pre_hook = make_dispatcher_pre_hook(dispatcher)

    # File path matches the predicate -> binding fires; stub adapter
    # produces skill_not_found.
    asyncio.run(
        pre_hook("Edit", {"file_path": "tests/test_foo.py"})
    )
    out = dispatcher.outcomes()
    assert len(out) == 1
    assert out[0].event == "PreToolUse"
    assert out[0].outcome == "skill_not_found"
    assert out[0].skill_name == "triage_failed_test"
    # Privacy: only payload key names recorded, not values.
    assert "tool_name" in out[0].payload_keys
    assert "file_path" in out[0].payload_keys
    assert "Edit" not in str(out[0].to_dict())
    assert "tests/test_foo.py" not in str(out[0].to_dict())


def test_pre_hook_predicate_false_records_skipped(tmp_path: Path):
    root = _make_skills_root(tmp_path)
    _write_skill_md(root, "triage_failed_test", _SKILL_MD_BLOCK)

    cache_dir = tempfile.mkdtemp(prefix="rdg_int_")
    dispatcher = get_dispatcher(
        "session-B", cache_dir=cache_dir, extra_roots=[root],
    )
    pre_hook = make_dispatcher_pre_hook(dispatcher)

    # tool_name=Read does NOT match `tool_name == "Edit"` predicate.
    asyncio.run(
        pre_hook("Read", {"file_path": "tests/test_foo.py"})
    )
    out = dispatcher.outcomes()
    assert len(out) == 1
    assert out[0].outcome == "skipped"


# ── 4. Post-hook tool error → PostToolUseFailure ─────────────────


def test_post_hook_routes_tool_error_to_failure_event(tmp_path: Path):
    root = _make_skills_root(tmp_path)
    _write_skill_md(root, "triage_failed_test", _SKILL_MD_BLOCK)

    cache_dir = tempfile.mkdtemp(prefix="rdg_int_")
    dispatcher = get_dispatcher(
        "session-C", cache_dir=cache_dir, extra_roots=[root],
    )
    post_hook = make_dispatcher_post_hook(dispatcher)

    # Result starting with "tool error:" → routed to PostToolUseFailure.
    asyncio.run(
        post_hook("Edit", {"file_path": "x"}, "tool error: boom")
    )
    out = dispatcher.outcomes()
    assert len(out) == 1
    assert out[0].event == "PostToolUseFailure"
    # The PostToolUseFailure binding has no `when`, so it is not
    # gated; outcome is skill_not_found from the stub adapter.
    assert out[0].outcome == "skill_not_found"

    # Successful result → PostToolUse, but no PostToolUse binding in
    # this skill, so nothing should be recorded.
    asyncio.run(
        post_hook("Edit", {"file_path": "x"}, "ok output")
    )
    out2 = dispatcher.outcomes()
    # Still 1 — no PostToolUse binding was registered.
    assert len(out2) == 1


# ── 5. Lifecycle: UserPromptSubmit / Stop helpers ─────────────────


def test_user_prompt_submit_and_stop_fire_clean(tmp_path: Path):
    """Both lifecycle helpers must succeed even when no binding matches.

    UserPromptSubmit is not bound by the synthetic SKILL.md, so this
    confirms the helpers are no-op-safe (an empty list of outcomes is
    a valid result for a session with no UserPromptSubmit bindings).
    """
    root = _make_skills_root(tmp_path)
    _write_skill_md(root, "triage_failed_test", _SKILL_MD_BLOCK)

    cache_dir = tempfile.mkdtemp(prefix="rdg_int_")
    dispatcher = get_dispatcher(
        "session-D", cache_dir=cache_dir, extra_roots=[root],
    )

    out = fire_user_prompt_submit(
        dispatcher,
        prompt="hello",
        stack="aegis",
        session_id="session-D",
    )
    # No SKILL.md binding listens for UserPromptSubmit.
    assert out == []

    # Stop binding exists and is throttle-free on first fire.
    out2 = fire_stop(
        dispatcher,
        session_id="session-D",
        stop_reason="completed",
        iterations=3,
    )
    assert len(out2) == 1
    assert out2[0].event == "Stop"
    assert out2[0].outcome == "skill_not_found"


# ── 6. Per-session caching contract ────────────────────────────────


def test_get_dispatcher_per_session_isolation(tmp_path: Path):
    root = _make_skills_root(tmp_path)
    _write_skill_md(root, "triage_failed_test", _SKILL_MD_BLOCK)

    cache_dir = tempfile.mkdtemp(prefix="rdg_int_")
    d1 = get_dispatcher("X", cache_dir=cache_dir, extra_roots=[root])
    d1_again = get_dispatcher("X", cache_dir=cache_dir, extra_roots=[root])
    d2 = get_dispatcher("Y", cache_dir=cache_dir, extra_roots=[root])
    # Same session id => same instance.
    assert d1 is d1_again
    # Different session id => different instance.
    assert d1 is not d2
    # Both have all three bindings registered.
    assert len(d1.binding_ids()) == 3
    assert len(d2.binding_ids()) == 3
