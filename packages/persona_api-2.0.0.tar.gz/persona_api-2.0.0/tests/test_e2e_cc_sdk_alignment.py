"""End-to-end integration tests — CC SDK April 2026 alignment (Sancio 2.0.0).

Drives a full :class:`persona.engine.agent_loop.AgentLoop` run with
both new surfaces composed in one flight:

* A scripted ``LLMCall`` issues ``tool_call`` → ``tool_result`` →
  ``final``.
* One PreToolUse hook (no-op) confirms the legacy slot is untouched.
* One PostToolUse hook returns
  :class:`persona.hooks.post_decision.PostToolUseDecision` with
  ``updated_output="REWRITTEN"`` — asserts ``state.messages`` tool
  entry has ``content="REWRITTEN"`` (CC ``updatedToolOutput`` parity).
* Mid-flight: a :class:`persona.hooks.config_change.ConfigChangeEvent`
  is fired through the new fan-out — asserts a registered subscriber
  observed the event.

These tests reference symbols produced by sub-agents A (engine
refactor + ``post_decision.py``) and B (``config_change.py``). Until
A+B merge with sub-agent C's deliverables, ``pytest`` will fail with
ImportError on the B-side imports — this is expected per the prepare-
session brief and unblocks at merge.

Plans authoritative:

* `_AI_BRAIN/05_Planning/2026-05-01-sancio-cc-sdk-2026-04-alignment.md`
* `_AI_BRAIN/05_Planning/2026-05-01-l6-posttooluse-design-conflict-options.md`
"""

from __future__ import annotations

from typing import Any

import pytest

from persona.engine.agent_loop import (
    AgentLoop,
    LLMResponse,
    ToolCall,
)
from persona.hooks.post_decision import (
    PostToolUseDecision,
)


class _FakeTool:
    """Minimal Tool conforming to the ``Tool`` protocol."""

    def __init__(self, name: str, result: Any) -> None:
        self.name = name
        self._result = result
        self.calls: list[dict[str, Any]] = []

    def schema(self) -> dict[str, Any]:
        return {
            "type": "function",
            "function": {"name": self.name, "parameters": {}},
        }

    async def execute(self, args: dict[str, Any]) -> Any:
        self.calls.append(args)
        return self._result


def _scripted_llm(replies: list[LLMResponse]):
    """Build an ``llm_call`` that returns ``replies`` in order."""
    idx = {"i": 0}

    async def _call(
        messages: list[dict[str, Any]],
        schemas: list[dict[str, Any]],
    ) -> LLMResponse:
        i = idx["i"]
        idx["i"] = i + 1
        if i >= len(replies):
            pytest.fail(
                f"llm called {i + 1} times but only "
                f"{len(replies)} scripted replies available",
            )
        return replies[i]

    return _call


@pytest.mark.asyncio
async def test_e2e_post_decision_rewrite_round_trip() -> None:
    """PostToolUseDecision(updated_output="REWRITTEN") round-trips into state.

    Composition:
        - Pre-hook: no-op (asserts legacy slot still works).
        - Tool: returns "ORIGINAL".
        - Post-hook: returns
          :class:`PostToolUseDecision(updated_output="REWRITTEN")`.
        - LLM second turn: emits final text seeing the rewritten value.

    Assertion: the tool message in ``state.messages`` carries the
    rewritten content, NOT the original tool output.
    """
    pre_calls: list[tuple[str, dict[str, Any]]] = []

    async def pre_hook(name: str, args: dict[str, Any]) -> None:
        pre_calls.append((name, args))

    async def post_hook(
        name: str,
        args: dict[str, Any],
        result: Any,
    ) -> PostToolUseDecision | None:
        return PostToolUseDecision(updated_output="REWRITTEN")

    tool = _FakeTool("echo", "ORIGINAL")

    llm = _scripted_llm(
        [
            LLMResponse(
                content="",
                tool_calls=[ToolCall(id="tc1", name="echo", args={"x": 1})],
            ),
            LLMResponse(content="done"),
        ],
    )

    loop = AgentLoop(
        llm_call=llm,
        tools={"echo": tool},
        pre_hooks=[pre_hook],
        post_hooks=[post_hook],
    )

    state = await loop.run([{"role": "user", "content": "hi"}])

    assert state.done is True
    assert state.final_text == "done"
    assert pre_calls == [("echo", {"x": 1})]

    tool_msgs = [m for m in state.messages if m.get("role") == "tool"]
    assert len(tool_msgs) == 1
    assert tool_msgs[0]["content"] == "REWRITTEN"
    assert tool_msgs[0]["is_error"] is False


@pytest.mark.asyncio
async def test_e2e_two_post_hooks_first_non_none_wins() -> None:
    """Multi-hook chaining: first non-None ``updated_output`` wins.

    Subsequent hooks see the rewritten value as their ``result``
    argument — the contract documented in
    ``persona.hooks.post_decision.PostToolUseDecision``.
    """
    second_hook_saw: dict[str, Any] = {}

    async def hook_one(name, args, result) -> PostToolUseDecision | None:
        return PostToolUseDecision(updated_output="WON")

    async def hook_two(name, args, result) -> PostToolUseDecision | None:
        second_hook_saw["result"] = result
        # Second hook returns None → does not override hook_one.
        return None

    tool = _FakeTool("echo", "ORIGINAL")
    llm = _scripted_llm(
        [
            LLMResponse(
                content="",
                tool_calls=[ToolCall(id="tc1", name="echo")],
            ),
            LLMResponse(content="done"),
        ],
    )

    loop = AgentLoop(
        llm_call=llm,
        tools={"echo": tool},
        post_hooks=[hook_one, hook_two],
    )

    state = await loop.run([{"role": "user", "content": "hi"}])
    tool_msgs = [m for m in state.messages if m.get("role") == "tool"]

    assert tool_msgs[0]["content"] == "WON"
    # Hook chaining contract: hook_two received the rewritten value.
    assert second_hook_saw["result"] == "WON"


@pytest.mark.asyncio
async def test_e2e_config_change_subscriber_observes_event() -> None:
    """Mid-flight ``ConfigChangeEvent`` reaches a registered subscriber.

    Drives the agent_loop with a normal tool call, then fires a
    ``ConfigChangeEvent`` through the in-process registry. Asserts the
    subscriber callable was invoked with the matching payload.

    Imports the B-side surfaces (``config_change``,
    ``ConfigChangeEvent``, ``register_config_change``,
    ``fire_config_change``). Until B merges, this test fails with
    ImportError — that is the expected pre-merge mode and confirms the
    integration point.
    """
    # B-side imports — present after merge.
    from persona.hooks.config_change import (  # noqa: PLC0415
        ConfigChangeEvent,
        fire_config_change,
        register_config_change,
        unregister_config_change,
    )

    observed: list[ConfigChangeEvent] = []

    async def on_change(event: ConfigChangeEvent) -> None:
        observed.append(event)

    token = register_config_change(on_change)
    try:
        # Run a small agent loop in parallel with config mutation.
        tool = _FakeTool("noop", "ok")
        llm = _scripted_llm(
            [
                LLMResponse(
                    content="",
                    tool_calls=[ToolCall(id="tc1", name="noop")],
                ),
                LLMResponse(content="done"),
            ],
        )
        loop = AgentLoop(llm_call=llm, tools={"noop": tool})
        state = await loop.run([{"role": "user", "content": "go"}])
        assert state.done is True

        # Mid-flight (here: post-loop, same async context) fire a
        # ``ConfigChangeEvent``. The fan-out is async so we await it.
        await fire_config_change(
            ConfigChangeEvent(
                session_id="sess-e2e",
                source="user_settings",
                file_path="/tmp/sancio_user_settings.yaml",
                changed_at=0.0,
            ),
        )
    finally:
        unregister_config_change(token)

    assert len(observed) == 1
    assert observed[0].source == "user_settings"
    assert observed[0].file_path.endswith("sancio_user_settings.yaml")
