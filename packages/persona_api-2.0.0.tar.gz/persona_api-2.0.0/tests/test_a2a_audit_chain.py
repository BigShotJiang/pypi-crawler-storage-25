"""Audit chain: hash-chain integrity + tamper detection."""

from __future__ import annotations

import json

from persona.a2a_security import AuditChain


def test_empty_chain_verifies_clean(tmp_path):
    chain = AuditChain(tmp_path / "a.jsonl")
    ok, line, _msg = chain.verify()
    assert ok is True
    assert line is None


def test_append_and_verify(tmp_path):
    chain = AuditChain(tmp_path / "a.jsonl")
    chain.append({"ts": 1.0, "dir": "in", "agent_id": "x",
                  "method": "m", "status": 200, "code": "ok",
                  "req_id": "r1"})
    chain.append({"ts": 2.0, "dir": "in", "agent_id": "x",
                  "method": "m", "status": 401, "code": "nope",
                  "req_id": "r2"})
    ok, _line, _msg = chain.verify()
    assert ok is True


def test_tamper_middle_line_detected(tmp_path):
    path = tmp_path / "a.jsonl"
    chain = AuditChain(path)
    for i in range(5):
        chain.append({"ts": float(i), "dir": "in", "agent_id": "x",
                      "method": "m", "status": 200, "code": "ok",
                      "req_id": f"r{i}"})
    lines = path.read_text(encoding="utf-8").splitlines()
    # Tamper with line 3 — change ``status`` to 500 but keep hash.
    obj = json.loads(lines[2])
    obj["status"] = 500
    lines[2] = json.dumps(obj, sort_keys=True, separators=(",", ":"))
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    ok, line, msg = chain.verify()
    assert ok is False
    assert line == 3
    assert "mismatch" in msg


def test_tamper_inserted_line_detected(tmp_path):
    path = tmp_path / "a.jsonl"
    chain = AuditChain(path)
    for i in range(3):
        chain.append({"ts": float(i), "dir": "in", "agent_id": "x",
                      "method": "m", "status": 200, "code": "ok",
                      "req_id": f"r{i}"})
    lines = path.read_text(encoding="utf-8").splitlines()
    # Inject a fake entry between line 1 and 2.
    fake = {"ts": 99.0, "dir": "in", "agent_id": "evil",
            "method": "m", "status": 200, "code": "ok",
            "req_id": "x", "prev_hash": "f" * 64,
            "hash": "e" * 64}
    lines.insert(1, json.dumps(fake, sort_keys=True, separators=(",", ":")))
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    ok, line, _msg = chain.verify()
    assert ok is False
    assert line is not None


def test_chain_survives_reopen(tmp_path):
    path = tmp_path / "a.jsonl"
    c1 = AuditChain(path)
    c1.append({"ts": 1.0, "dir": "in", "agent_id": "x",
               "method": "m", "status": 200, "code": "ok",
               "req_id": "r1"})
    # Reopen — should pick up the existing tail hash and keep chaining.
    c2 = AuditChain(path)
    c2.append({"ts": 2.0, "dir": "in", "agent_id": "x",
               "method": "m", "status": 200, "code": "ok",
               "req_id": "r2"})
    ok, _line, _msg = c2.verify()
    assert ok is True
    assert len(path.read_text(encoding="utf-8").splitlines()) == 2


def test_genesis_prev_hash_is_all_zeros(tmp_path):
    path = tmp_path / "a.jsonl"
    chain = AuditChain(path)
    chain.append({"ts": 1.0, "dir": "in", "agent_id": "x",
                  "method": "m", "status": 200, "code": "ok",
                  "req_id": "r1"})
    line = path.read_text(encoding="utf-8").splitlines()[0]
    obj = json.loads(line)
    assert obj["prev_hash"] == "0" * 64
