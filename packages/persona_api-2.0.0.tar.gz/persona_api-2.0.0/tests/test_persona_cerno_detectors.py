"""Unit tests for the 28 Cerno detectors in ``persona.cerno.review``.

Each implemented detector in ``_DETECTORS`` gets at least one
``_fires_on_trigger`` test. Five detectors additionally assert the
full ``DefectHit`` shape (id + severity + confidence) to catch silent
threshold drift. A single ``clean_baseline`` test asserts that a
benign, on-topic output triggers zero defects.

Call ``review`` directly with synthetic inputs — no mocks, no HTTP.
"""

from __future__ import annotations

import time

from persona.cerno.review import review
from persona.cerno.types import Assessment, DefectHit, ReviewResult


# ── Helpers ─────────────────────────────────────────────────


def _mk(
    intent: str = "generic intent that describes a simple task clearly",
    risk: str = "low",
    traits: list[str] | None = None,
) -> Assessment:
    """Build a minimal Assessment. ``risk`` / ``traits`` gate detectors."""
    return Assessment(
        user_intent=intent,
        risk_level=risk,  # type: ignore[arg-type]
        expected_traits=traits or [],
        assessed_at=time.time(),
    )


def _ids(r: ReviewResult) -> list[str]:
    return [d.id for d in r.defects_found]


def _hit(r: ReviewResult, did: str) -> DefectHit:
    matches = [d for d in r.defects_found if d.id == did]
    assert matches, f"expected {did} in {[d.id for d in r.defects_found]}"
    return matches[0]


# ── L-bucket (6 detectors) ──────────────────────────────────


def test_L1_attention_overflow_fires_on_missing_middle() -> None:
    """L1: long intent with >10 long words, output ignores mid-30-70%."""
    intent = (
        "please refactor authentication middleware database connection "
        "pooling caching layer inventory warehouse dispatch shipping "
        "tracking analytics dashboard reporting module"
    )
    # Output only mentions the very first concept
    output = "refactor authentication done."
    r = review(output, _mk(intent=intent))
    assert "L1" in _ids(r)


def test_L5_verbosity_inflation_fires_when_output_4x_input() -> None:
    """L5: output length > 4x intent length."""
    intent = "hi"
    output = "x" * 500
    r = review(output, _mk(intent=intent))
    hit = _hit(r, "L5")
    assert hit.severity == "low"
    assert 0.0 < hit.confidence <= 0.9


def test_L6_hallucination_fires_on_ungrounded_paths() -> None:
    """L6: >3 multi-segment file paths not in intent."""
    intent = "summarize readme"
    output = (
        "Modified /src/core/auth.py, /src/core/db.py, "
        "/lib/utils/helper.py, /tests/unit/test_auth.py as part of work."
    )
    r = review(output, _mk(intent=intent))
    hit = _hit(r, "L6")
    assert hit.severity == "high"
    assert hit.confidence == 0.5


def test_L7_false_certainty_fires_on_multiple_absolutes() -> None:
    """L7: >=2 high-certainty adverbs."""
    output = "This will definitely work and is absolutely the right call."
    r = review(output, _mk())
    hit = _hit(r, "L7")
    assert hit.severity == "high"
    assert hit.confidence == 0.6


def test_L7_false_certainty_silent_on_single_adverb() -> None:
    """L7: single high-certainty adverb must NOT fire."""
    output = "This will definitely work for the given edge case."
    r = review(output, _mk())
    assert "L7" not in _ids(r)


def test_L7_false_certainty_fires_on_undoubtedly_and_certainly() -> None:
    """L7: mixed high-certainty tokens (undoubtedly + certainly).

    Note: ``100%`` as a regex alternative has a trailing ``\\b`` that
    fails to match because ``%`` is already non-word, so
    ``100%``-based outputs are effectively uncatchable by L7.
    Documented in the honest-gaps report. We assert the alphabetic
    path here.
    """
    output = "Undoubtedly the migration will certainly succeed on all nodes."
    r = review(output, _mk())
    assert "L7" in _ids(r)


def test_L8_pattern_completion_fires_on_repeated_blocks() -> None:
    """L8: 2+ lines repeated 3+ times each."""
    line_a = "this is a structural line repeated many times identically"
    line_b = "another distinct repeated structural paragraph chunk here"
    output = "\n".join([line_a] * 3 + [line_b] * 3)
    r = review(output, _mk())
    assert "L8" in _ids(r)


def test_L10_context_window_decay_fires_on_detail_drop() -> None:
    """L10: 500+ words, markers in first half, zero markers in second.

    Careful: the implementation splits at len(words)//2, so a marker
    word at position ``half+1`` counts as second-half. We put all
    marker text tightly at the front, then a long marker-free tail,
    so the second half is guaranteed marker-free.
    """
    # 10 markers total, all in the first 50 words
    head = (
        "because therefore specifically for example "
        "because therefore specifically for example "
        + "filler " * 40
    )
    # 500 marker-free words to dominate the second half
    tail = "lorem " * 500
    output = head + tail
    r = review(output, _mk())
    assert "L10" in _ids(r)


# ── A-bucket (4 detectors) ──────────────────────────────────


def test_A1_sycophancy_fires_on_risky_agreement_no_pushback() -> None:
    """A1: risky task + agreement phrase + no pushback keywords."""
    output = "Great idea — let's ship it. Just run the drop and move on."
    r = review(output, _mk(risk="high"))
    hit = _hit(r, "A1")
    assert hit.severity == "high"
    assert hit.confidence == 0.7


def test_A2_loss_aversion_fires_on_preservation_when_simplify_wanted() -> None:
    """A2: minimal_complexity trait + preservation language."""
    output = "Let's keep backward compatibility and maintain legacy support."
    r = review(output, _mk(traits=["minimal_complexity"]))
    assert "A2" in _ids(r)


def test_A3_over_correction_fires_on_three_extreme_prohibitions() -> None:
    """A3: >=3 prohibition phrases."""
    output = (
        "Never do that. Under no circumstances touch the DB. "
        "This is strictly forbidden in production."
    )
    r = review(output, _mk())
    assert "A3" in _ids(r)


def test_A4_safety_theater_fires_on_multiple_disclaimers() -> None:
    """A4: >=2 disclaimer phrases."""
    output = (
        "Please note this is not legal advice. Also please note you "
        "should proceed with caution before running."
    )
    r = review(output, _mk())
    assert "A4" in _ids(r)


# ── B-bucket (5 detectors) ──────────────────────────────────


def test_B1_short_termism_fires_on_quick_fix_no_long_term() -> None:
    """B1: quick-fix vocabulary + no long-term thinking words."""
    output = "Let's apply a quick fix as a temporary workaround for now."
    r = review(output, _mk())
    hit = _hit(r, "B1")
    assert hit.severity == "high"
    assert hit.confidence == 0.5


def test_B2_action_bias_fires_on_unrequested_additions_lowrisk() -> None:
    """B2: low-risk task + unrequested additions."""
    output = "I also added a bonus retry wrapper while I was at it."
    r = review(output, _mk(risk="low"))
    assert "B2" in _ids(r)


def test_B3_premature_convergence_fires_on_long_no_alternatives() -> None:
    """B3: >200 words + no alternative language."""
    # 250 distinct-ish words, no "option", "alternative", "trade-off"…
    body = " ".join(["decision"] * 250)
    r = review(body, _mk())
    assert "B3" in _ids(r)


def test_B4_scope_creep_fires_on_bonus_language() -> None:
    """B4: bonus/additionally phrases."""
    output = "Bonus: I also polished the error messages."
    r = review(output, _mk())
    assert "B4" in _ids(r)


def test_B5_cargo_cult_fires_on_convention_without_reason() -> None:
    """B5: best-practice citation without rationale words."""
    output = "This is industry standard boilerplate. Always do it this way."
    r = review(output, _mk())
    assert "B5" in _ids(r)


# ── D-bucket (5 detectors) ──────────────────────────────────


def test_D1_sop_erosion_fires_on_skip_step_language() -> None:
    """D1: suggests skipping a step/check/validation."""
    output = "Let's just skip the validation step and go straight to deploy."
    r = review(output, _mk())
    hit = _hit(r, "D1")
    assert hit.severity == "high"
    assert hit.confidence == 0.6


def test_D2_identity_loss_fires_on_generic_ai_fallback() -> None:
    """D2: 'as an AI' / 'I'm a language model' phrases."""
    output = "As an AI language model, I don't have opinions on this."
    r = review(output, _mk())
    assert "D2" in _ids(r)


def test_D3_goal_drift_fires_on_intent_keywords_absent() -> None:
    """D3: <20% of long intent words appear in output."""
    intent = (
        "refactor authentication middleware and database pooling layer"
    )
    output = "Here is a recipe for tomato soup with fresh basil leaves."
    r = review(output, _mk(intent=intent))
    assert "D3" in _ids(r)


def test_D4_standard_decay_fires_on_euphemism() -> None:
    """D4: 'mostly works' / 'good enough' phrasing."""
    output = "The fix mostly works and is probably good enough to ship."
    r = review(output, _mk())
    assert "D4" in _ids(r)


def test_D5_instruction_amnesia_fires_on_inscope_refusal() -> None:
    """D5: 'I can't help with' / 'outside my scope' phrasing."""
    output = "I can't help with that request — it's outside my scope."
    r = review(output, _mk())
    assert "D5" in _ids(r)


# ── E-bucket (8 detectors) ──────────────────────────────────


def test_E1_context_loss_fires_on_asking_for_context() -> None:
    """E1: 'I don't have that context' / 'could you remind me'."""
    output = "I don't have the context — can you remind me of the details?"
    r = review(output, _mk())
    assert "E1" in _ids(r)


def test_E2_parallel_chaos_fires_on_contradiction_signals() -> None:
    """E2: >=2 'contradicts' / 'but earlier' tokens."""
    output = (
        "But earlier the spec said X, which contradicts the later claim "
        "and is inconsistent with the design."
    )
    r = review(output, _mk())
    assert "E2" in _ids(r)


def test_E3_tool_misuse_fires_on_wrong_tool_phrasing() -> None:
    """E3: 'let me use grep for' / 'I'll echo to the file'."""
    output = "Let me use grep to find all callers in the repo."
    r = review(output, _mk())
    assert "E3" in _ids(r)


def test_E4_resource_waste_fires_on_500_words_lowrisk() -> None:
    """E4: >500 words on low-risk task."""
    output = " ".join(["word"] * 600)
    r = review(output, _mk(risk="low"))
    assert "E4" in _ids(r)


def test_E5_phantom_artifact_fires_on_multiple_creations_no_verify() -> None:
    """E5: >=2 'created X' claims without 'verified/confirmed/tested'."""
    output = "Created file foo.py. Also wrote bar.py with the logic."
    r = review(output, _mk())
    assert "E5" in _ids(r)


def test_E6_silent_failure_fires_on_errors_without_ack() -> None:
    """E6: >=2 error tokens, no fix/resolve/investigate word."""
    output = (
        "The traceback shows an error and another exception downstream. "
        "Moving on to the next step now."
    )
    r = review(output, _mk())
    assert "E6" in _ids(r)


def test_E7_dependency_blindness_fires_on_breaking_change_no_downstream() -> None:
    """E7: breaking-change phrase without consumer/downstream mention."""
    output = "Marked as a breaking change: deleted the export."
    r = review(output, _mk())
    assert "E7" in _ids(r)


def test_E8_test_theater_fires_on_tests_pass_no_detail() -> None:
    """E8: 'tests pass' without coverage/assert/verify vocab."""
    output = "All tests pass. Ready to ship the fix now."
    r = review(output, _mk())
    assert "E8" in _ids(r)


# ── Clean baseline ──────────────────────────────────────────


def test_clean_baseline_triggers_no_defects() -> None:
    """A minimal benign output must fire zero detectors.

    Keeps every trigger regex honest: if any detector starts false
    positive-ing on trivial text, this test breaks.
    """
    intent = "summarize this short paragraph"
    output = "Here is a concise summary of the paragraph."
    r = review(output, _mk(intent=intent))
    assert r.defects_found == [], f"unexpected defects: {_ids(r)}"


# ── Detector roster invariant ───────────────────────────────


def test_detector_roster_count_is_28() -> None:
    """Guard the handoff's '28 detectors' contract.

    If a new detector is added (or one is removed), this test forces
    the author to update the dedicated unit-test coverage for it.
    """
    from persona.cerno.review import _DETECTORS

    # 28 original + E9/E10/E11 Reflexion-lite (MEMORY #56, 2026-04-17)
    assert len(_DETECTORS) == 31
