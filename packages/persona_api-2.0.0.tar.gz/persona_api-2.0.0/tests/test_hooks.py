"""Tests for A3 hooks — Guards PreToolUse + Cerno PostToolUse.

Both adapters use injected fakes so no CortexLibrary round-trip or
28-detector real review runs in CI. The contract under test:

* Guard hook raises :class:`PermissionDenied` iff the classifier
  returns a level in ``deny_on``.
* Cerno hook calls ``cerno.cycle(user_input, result)``, never
  blocks the loop (v3 § 5 rule), and emits an
  :class:`CernoHookEvent` to every listener — even when a listener
  raises.
"""

from __future__ import annotations

from typing import Any

import pytest

from persona.cerno.types import CernoAllow, CernoDeny
from persona.engine.agent_loop import (
    AgentLoop,
    LLMResponse,
    PermissionDenied,
    ToolCall,
)
from persona.guards import SafetyLevel, SafetyResult
from persona.hooks import (
    CernoHookEvent,
    make_cerno_post_hook,
    make_guard_pre_hook,
)


# ─────────────────── guard_hook ───────────────────


@pytest.mark.asyncio
async def test_guard_hook_denies_on_dangerous() -> None:
    def fake_classify(_text: str) -> SafetyResult:
        return SafetyResult(
            level=SafetyLevel.DANGEROUS,
            threat_type="rm_root",
            detail="rm -rf /",
        )

    hook = make_guard_pre_hook(classifier=fake_classify)
    with pytest.raises(PermissionDenied) as excinfo:
        await hook("run_bash", {"cmd": "rm -rf /"})
    assert "rm_root" in str(excinfo.value)


@pytest.mark.asyncio
async def test_guard_hook_allows_safe() -> None:
    def fake_classify(_text: str) -> SafetyResult:
        return SafetyResult(level=SafetyLevel.SAFE)

    hook = make_guard_pre_hook(classifier=fake_classify)
    # Should return None silently — no exception raised.
    assert await hook("read_file", {"path": "a.txt"}) is None


@pytest.mark.asyncio
async def test_guard_hook_uncertain_not_in_default_deny_set() -> None:
    """UNCERTAIN falls through by default so the LLM can retry."""
    def fake_classify(_text: str) -> SafetyResult:
        return SafetyResult(level=SafetyLevel.UNCERTAIN)

    hook = make_guard_pre_hook(classifier=fake_classify)
    assert await hook("any_tool", {}) is None


# ─────────────────── cerno_hook ───────────────────


class _FakeCerno:
    """Stand-in for :class:`Cerno` — records calls, returns scripted action."""

    def __init__(self, action: Any) -> None:
        self._action = action
        self.calls: list[tuple[str, str]] = []

    def cycle(self, user_input: str, child_output: str) -> Any:
        self.calls.append((user_input, child_output))
        return self._action


@pytest.mark.asyncio
async def test_cerno_hook_emits_to_listeners() -> None:
    allow = CernoAllow()
    cerno = _FakeCerno(action=allow)
    events: list[CernoHookEvent] = []

    hook = make_cerno_post_hook(
        cerno,  # type: ignore[arg-type] — fake satisfies structural contract
        user_input_provider=lambda: "user asked X",
        listeners=[events.append],
    )

    await hook("read_file", {"path": "a.txt"}, "file contents")

    assert cerno.calls == [("user asked X", "file contents")]
    assert len(events) == 1
    assert events[0].tool_name == "read_file"
    assert events[0].action is allow


@pytest.mark.asyncio
async def test_cerno_hook_listener_exception_swallowed() -> None:
    cerno = _FakeCerno(action=CernoDeny(reason="bad"))

    def bad_listener(_ev: CernoHookEvent) -> None:
        raise RuntimeError("listener blew up")

    good_events: list[CernoHookEvent] = []
    hook = make_cerno_post_hook(
        cerno,  # type: ignore[arg-type]
        listeners=[bad_listener, good_events.append],
    )

    # Must not raise — listener errors are isolated.
    await hook("write_file", {"path": "x"}, "done")

    assert len(good_events) == 1


# ─────────────────── End-to-end: AgentLoop + hooks ───────────────────


@pytest.mark.asyncio
async def test_loop_with_guard_deny_and_cerno_observe() -> None:
    """Full v3 § 5 unified loop: Pre denies, Post still reviews the rest."""
    dangerous_patterns = {"rm -rf"}

    def fake_classify(text: str) -> SafetyResult:
        if any(p in text for p in dangerous_patterns):
            return SafetyResult(
                level=SafetyLevel.DANGEROUS,
                threat_type="rm_root",
                detail=text[:80],
            )
        return SafetyResult(level=SafetyLevel.SAFE)

    cerno = _FakeCerno(action=CernoAllow())
    observed: list[CernoHookEvent] = []

    pre = make_guard_pre_hook(classifier=fake_classify)
    post = make_cerno_post_hook(
        cerno,  # type: ignore[arg-type]
        listeners=[observed.append],
    )

    class _EchoTool:
        name = "echo"

        def schema(self) -> dict[str, Any]:
            return {"type": "function", "function": {"name": "echo"}}

        async def execute(self, args: dict[str, Any]) -> str:
            return args.get("text", "")

    llm_replies = [
        LLMResponse(
            tool_calls=[ToolCall(
                id="c1", name="echo", args={"text": "rm -rf /"},
            )],
        ),
        LLMResponse(
            tool_calls=[ToolCall(
                id="c2", name="echo", args={"text": "hello"},
            )],
        ),
        LLMResponse(content="done."),
    ]
    idx = {"i": 0}

    async def llm_call(
        _msgs: list[dict[str, Any]],
        _schemas: list[dict[str, Any]],
    ) -> LLMResponse:
        i = idx["i"]
        idx["i"] = i + 1
        return llm_replies[i]

    loop = AgentLoop(
        llm_call=llm_call,
        tools={"echo": _EchoTool()},
        pre_hooks=[pre],
        post_hooks=[post],
    )

    state = await loop.run([{"role": "user", "content": "do stuff"}])

    assert state.done is True
    assert state.final_text == "done."
    # Two tool messages: one denied (is_error), one ran (not error).
    tool_msgs = [m for m in state.messages if m["role"] == "tool"]
    assert len(tool_msgs) == 2
    assert tool_msgs[0]["is_error"] is True
    assert "permission denied" in tool_msgs[0]["content"]
    assert tool_msgs[1]["is_error"] is False
    assert tool_msgs[1]["content"] == "hello"
    # Cerno reviewed **only** the successful execution. Denied calls
    # never reach PostToolUse — matches v3 § 5 flow diagram.
    assert len(observed) == 1
    assert observed[0].tool_result == "hello"
