"""Tests for :mod:`persona.hooks.config_change` (Sancio 2.0.0).

Covers the 12 contract guarantees called out in the 2026-05-01 alignment
plan §4.2 / §5 risk register:

1.  register/unregister/list parity with :mod:`persona.hooks.fanout`
2.  fire with no subs returns ``True`` (no blockers)
3.  Single sync sub fires correctly
4.  Single async sub fires correctly
5.  Generic exception in subscriber: logged, fail-open, fan-out continues
6.  ``ConfigChangeBlocked`` -> fan-out returns ``False``
7.  ``ConfigChangeBlocked`` + ``source=policy_settings`` -> ignored (R3)
8.  Multiple subs, one blocks -> returns ``False``
9.  Subscriber timeout -> logged + skipped
10. Entry-point lazy resolution (mock ``importlib.metadata.entry_points``)
11. ``reset_for_tests`` clears registry
12. Concurrent fan-out: 5 subs all fire in parallel under 1.5x slowest
"""

from __future__ import annotations

import asyncio
import time
from typing import Any
from unittest.mock import patch

import pytest

from persona.hooks import config_change as cc
from persona.hooks.config_change import (
    ConfigChangeBlocked,
    ConfigChangeEvent,
    fire_config_change,
    list_config_change_subscribers,
    register_config_change,
    reset_for_tests,
    unregister_config_change,
)


@pytest.fixture(autouse=True)
def _reset() -> None:
    """Each test starts with an empty registry."""
    reset_for_tests()
    yield
    reset_for_tests()


def _event(
    source: cc.ConfigChangeSource = "user_settings",
    file_path: str = "/tmp/x.json",
    session_id: str | None = "s-1",
) -> ConfigChangeEvent:
    return ConfigChangeEvent(
        session_id=session_id,
        source=source,
        file_path=file_path,
        changed_at=time.time(),
    )


# ---------------------------------------------------------------------------
# 1. register / unregister / list parity
# ---------------------------------------------------------------------------


def test_register_unregister_list_parity() -> None:
    def sub_a(_e: ConfigChangeEvent) -> None:
        return None

    def sub_b(_e: ConfigChangeEvent) -> None:
        return None

    name_a = register_config_change(sub_a, name="alpha")
    name_b = register_config_change(sub_b, name="beta")
    assert name_a == "alpha"
    assert name_b == "beta"

    listed = list_config_change_subscribers()
    assert "alpha" in listed and "beta" in listed

    # Idempotent re-register
    register_config_change(sub_a, name="alpha")
    assert list_config_change_subscribers().count("alpha") == 1

    # Unregister by name
    assert unregister_config_change("alpha") is True
    assert "alpha" not in list_config_change_subscribers()
    assert unregister_config_change("alpha") is False  # second time = no-op

    # Unregister by callable
    assert unregister_config_change(sub_b) is True
    assert "beta" not in list_config_change_subscribers()


# ---------------------------------------------------------------------------
# 2. fire with no subs -> True
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_fire_no_subs_returns_true() -> None:
    should_reload, results = await fire_config_change(_event())
    assert should_reload is True
    assert results == []


# ---------------------------------------------------------------------------
# 3. Single sync sub fires
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_single_sync_sub_fires() -> None:
    seen: list[ConfigChangeEvent] = []

    def sub(e: ConfigChangeEvent) -> None:
        seen.append(e)

    register_config_change(sub, name="sync_one")
    should_reload, results = await fire_config_change(_event())
    assert should_reload is True
    assert len(seen) == 1
    assert len(results) == 1
    assert results[0].ok is True
    assert results[0].name == "sync_one"


# ---------------------------------------------------------------------------
# 4. Single async sub fires
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_single_async_sub_fires() -> None:
    seen: list[ConfigChangeEvent] = []

    async def sub(e: ConfigChangeEvent) -> None:
        await asyncio.sleep(0)  # yield once
        seen.append(e)

    register_config_change(sub, name="async_one")
    should_reload, results = await fire_config_change(_event())
    assert should_reload is True
    assert len(seen) == 1
    assert results[0].ok is True


# ---------------------------------------------------------------------------
# 5. Generic exception -> logged, fail-open
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_generic_exception_fail_open(
    caplog: pytest.LogCaptureFixture,
) -> None:
    def boom(_e: ConfigChangeEvent) -> None:
        raise ValueError("nope")

    def good(_e: ConfigChangeEvent) -> None:
        return None

    register_config_change(boom, name="boom")
    register_config_change(good, name="good")

    with caplog.at_level("WARNING"):
        should_reload, results = await fire_config_change(_event())

    # Generic exception is fail-open — does NOT block reload.
    assert should_reload is True
    assert len(results) == 2
    by_name = {r.name: r for r in results}
    assert by_name["boom"].ok is False
    assert "ValueError" in (by_name["boom"].error or "")
    assert by_name["good"].ok is True
    assert any("boom" in rec.message for rec in caplog.records)


# ---------------------------------------------------------------------------
# 6. ConfigChangeBlocked -> returns False
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_block_decision_returns_false() -> None:
    def vetoer(_e: ConfigChangeEvent) -> None:
        raise ConfigChangeBlocked("schema invalid")

    register_config_change(vetoer, name="vetoer")
    should_reload, results = await fire_config_change(
        _event(source="user_settings")
    )
    assert should_reload is False
    assert len(results) == 1
    assert results[0].ok is False
    assert "blocked" in (results[0].error or "")


# ---------------------------------------------------------------------------
# 7. policy_settings exemption (R3 critical)
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_policy_settings_blocking_ignored(
    caplog: pytest.LogCaptureFixture,
) -> None:
    """Policy edits MUST apply even if a subscriber tries to block them."""

    def vetoer(_e: ConfigChangeEvent) -> None:
        raise ConfigChangeBlocked("malicious veto")

    register_config_change(vetoer, name="vetoer")

    with caplog.at_level("WARNING"):
        should_reload, results = await fire_config_change(
            _event(source="policy_settings", file_path="/etc/policy.json")
        )

    # R3: block IGNORED, reload proceeds, log entry emitted.
    assert should_reload is True
    assert len(results) == 1
    # Per-subscriber result still records the block (observability) —
    # only the aggregation is overridden.
    assert results[0].ok is False
    assert "blocked" in (results[0].error or "")
    # Warning log MUST mention policy exemption + file path.
    msgs = "\n".join(rec.getMessage() for rec in caplog.records)
    assert "policy_settings" in msgs
    assert "/etc/policy.json" in msgs


# ---------------------------------------------------------------------------
# 8. Multiple subs, one blocks
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_multiple_subs_one_blocks() -> None:
    seen: list[str] = []

    def good_a(_e: ConfigChangeEvent) -> None:
        seen.append("a")

    def vetoer(_e: ConfigChangeEvent) -> None:
        seen.append("v")
        raise ConfigChangeBlocked("nope")

    def good_b(_e: ConfigChangeEvent) -> None:
        seen.append("b")

    register_config_change(good_a, name="a")
    register_config_change(vetoer, name="v")
    register_config_change(good_b, name="b")

    should_reload, results = await fire_config_change(_event())
    assert should_reload is False
    assert len(results) == 3
    # Concurrent fan-out: all three saw the event before aggregation.
    assert set(seen) == {"a", "v", "b"}


# ---------------------------------------------------------------------------
# 9. Subscriber timeout -> logged + skipped
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_subscriber_timeout(
    caplog: pytest.LogCaptureFixture,
) -> None:
    async def slow(_e: ConfigChangeEvent) -> None:
        await asyncio.sleep(2.0)

    def fast(_e: ConfigChangeEvent) -> None:
        return None

    register_config_change(slow, name="slow")
    register_config_change(fast, name="fast")

    with caplog.at_level("WARNING"):
        should_reload, results = await fire_config_change(
            _event(), timeout=0.1
        )

    assert should_reload is True  # Timeout is fail-open
    by_name = {r.name: r for r in results}
    assert by_name["slow"].ok is False
    assert by_name["slow"].error == "timeout"
    assert by_name["fast"].ok is True


# ---------------------------------------------------------------------------
# 10. Entry-point lazy resolution
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_entry_point_lazy_resolution() -> None:
    """Mock entry_points() to inject a fake plugin subscriber."""
    received: list[ConfigChangeEvent] = []

    def plugin_sub(e: ConfigChangeEvent) -> None:
        received.append(e)

    class _FakeEP:
        name = "fake_plugin"

        def load(self) -> Any:
            return plugin_sub

    fake_eps = [_FakeEP()]

    with patch.object(cc, "_load_entry_point_subscribers") as mock_loader:
        mock_loader.return_value = [("fake_plugin", plugin_sub)]
        listed = list_config_change_subscribers()
        assert "fake_plugin" in listed

        should_reload, results = await fire_config_change(_event())
        assert should_reload is True
        assert len(received) == 1
        assert any(r.name == "fake_plugin" and r.ok for r in results)

    # After the patch exits the entry-point loader returns [] again
    # (no actual entry_points registered for this group in tests).
    assert "fake_plugin" not in list_config_change_subscribers()
    # Silence unused-var lint.
    _ = fake_eps


# ---------------------------------------------------------------------------
# 11. reset_for_tests clears registry
# ---------------------------------------------------------------------------


def test_reset_clears_registry() -> None:
    register_config_change(lambda _e: None, name="x")
    register_config_change(lambda _e: None, name="y")
    assert len(list_config_change_subscribers()) >= 2
    reset_for_tests()
    assert list_config_change_subscribers() == []


# ---------------------------------------------------------------------------
# 12. Concurrent fan-out perf — 5 subs fire in parallel
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_concurrent_fanout_parallel() -> None:
    """Prove fan-out is parallel by observing concurrent in-flight subs.

    Wall-clock thresholds are timing-sensitive under full-suite load on
    Windows (Proactor event loop scheduler granularity + ambient process
    contention can push 5×100ms parallel tasks past serial 500ms). Use
    overlap-detection instead: at peak, at least 2 subs must be
    concurrently in-flight; a serial fan-out would never see >1.
    """
    SLEEP_S = 0.05
    N_SUBS = 5
    in_flight = 0
    max_in_flight = 0
    lock = asyncio.Lock()

    async def slow_sub(_e: ConfigChangeEvent) -> None:
        nonlocal in_flight, max_in_flight
        async with lock:
            in_flight += 1
            if in_flight > max_in_flight:
                max_in_flight = in_flight
        await asyncio.sleep(SLEEP_S)
        async with lock:
            in_flight -= 1

    for i in range(N_SUBS):
        register_config_change(slow_sub, name=f"slow_{i}")

    should_reload, results = await fire_config_change(_event(), timeout=2.0)

    assert should_reload is True
    assert len(results) == N_SUBS
    assert all(r.ok for r in results)
    # Serial fan-out would yield max_in_flight == 1. Parallel ≥ 2 proves
    # subs overlap (timing-independent, robust to scheduler noise).
    assert max_in_flight >= 2, (
        f"Fan-out not parallel: max_in_flight={max_in_flight}, "
        "expected >= 2 (serial would be 1)"
    )
