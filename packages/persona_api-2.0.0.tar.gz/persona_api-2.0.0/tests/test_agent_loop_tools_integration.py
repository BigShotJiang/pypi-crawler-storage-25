"""Integration — AgentLoop driving real A2 tools end-to-end.

Validates the contract between A1 (loop) and A2 (registry): a
scripted LLM issues real tool calls, the loop dispatches them to
the stock tools, and the state machine terminates cleanly with
the tool side-effects observable on the filesystem.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

import pytest

from persona.engine.agent_loop import AgentLoop, LLMResponse, ToolCall
from persona.tools import default_tools


def _scripted_llm(replies: list[LLMResponse]):
    idx = {"i": 0}

    async def _call(
        messages: list[dict[str, Any]],
        schemas: list[dict[str, Any]],
    ) -> LLMResponse:
        # Full default roster is exposed to the LLM. The exact count
        # tracks ``persona.tools.default_tools`` and grows over time
        # (14 as of python_exec landing). Assert the lower bound + key
        # members rather than a hard-coded count to avoid false alarms
        # the next time the roster grows.
        names = {s["function"]["name"] for s in schemas}
        assert len(schemas) >= 13
        assert {"read_file", "write_file", "edit_file"} <= names
        i = idx["i"]
        idx["i"] = i + 1
        return replies[i]

    return _call


@pytest.mark.asyncio
async def test_loop_writes_then_reads_file(tmp_path: Path) -> None:
    """LLM writes a file, reads it back, then answers the user."""
    tools = default_tools(root=tmp_path)

    llm = _scripted_llm([
        LLMResponse(
            tool_calls=[ToolCall(
                id="w1",
                name="write_file",
                args={"path": "note.txt", "content": "answer=42"},
            )],
        ),
        LLMResponse(
            tool_calls=[ToolCall(
                id="r1",
                name="read_file",
                args={"path": "note.txt"},
            )],
        ),
        LLMResponse(content="The answer is 42."),
    ])

    loop = AgentLoop(llm_call=llm, tools=tools)
    state = await loop.run([
        {"role": "user", "content": "save and recite 42"},
    ])

    assert state.done is True
    assert state.iterations == 3
    assert state.final_text == "The answer is 42."
    # File really exists on disk — no mock trickery.
    assert (tmp_path / "note.txt").read_text(encoding="utf-8") == "answer=42"
    # Tool round-trip ids preserved for every call.
    tool_msgs = [m for m in state.messages if m["role"] == "tool"]
    assert [m["tool_call_id"] for m in tool_msgs] == ["w1", "r1"]
