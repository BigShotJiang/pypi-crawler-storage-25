"""Tests for multi-round tool-use via ``_provider_backed_llm_call``.

These complement ``test_agent_loop.py`` (pure state-machine unit tests)
and ``test_agent_run_real_provider.py`` (fake-provider plumbing) by
driving real multi-round flows through the full adapter chain:

    AgentLoop → _provider_backed_llm_call
        → provider.generate_with_tools (scripted fake)
        → ProviderResponse → LLMResponse → next round

Scenarios
---------

* **Three-round read→write→done** — provider emits two tool_calls in
  sequence, then a text-only reply. Verifies round ordering,
  ``tool_call_id`` round-trip, and final text harvest.
* **max_iterations reached** — provider never settles. Loop bails with
  ``stop_reason == "max_iterations"``.
* **Tool execution error** — the called tool raises; the loop converts
  into an ``is_error`` tool message and offers the LLM a recovery round.
* **Zero tool use** — provider replies with text only on round 1.
  Degenerate path must still produce ``final_text`` + ``completed``.
"""

from __future__ import annotations

from typing import Any

import pytest

from persona.engine.agent_loop import (
    AgentLoop,
    LLMResponse,
    ToolCall,
)
from persona.providers.base import (
    ProviderResponse,
    ToolCallRequest,
    ToolSpec,
)


class _ScriptedProvider:
    """Provider stub that returns pre-canned :class:`ProviderResponse`."""

    name = "scripted"

    def __init__(self, responses: list[ProviderResponse]) -> None:
        self._responses = responses
        self.calls: list[tuple[list[dict[str, Any]], list[ToolSpec]]] = []
        self.last_usage = None

    async def generate_with_tools(
        self,
        messages: list[dict[str, Any]],
        policy: Any,
        tools: list[ToolSpec],
    ) -> ProviderResponse:
        i = len(self.calls)
        self.calls.append((list(messages), list(tools)))
        if i >= len(self._responses):
            raise AssertionError(
                f"provider called {i + 1}x but only "
                f"{len(self._responses)} scripted responses",
            )
        return self._responses[i]


class _SpyTool:
    """Minimal tool whose execute logs args and returns a scripted result."""

    def __init__(
        self,
        name: str,
        result: Any,
        *,
        raises: Exception | None = None,
    ) -> None:
        self.name = name
        self._result = result
        self._raises = raises
        self.calls: list[dict[str, Any]] = []

    def schema(self) -> dict[str, Any]:
        return {
            "type": "function",
            "function": {
                "name": self.name,
                "description": f"{self.name} spy",
                "parameters": {
                    "type": "object",
                    "properties": {},
                    "required": [],
                },
            },
        }

    async def execute(self, args: dict[str, Any]) -> Any:
        self.calls.append(dict(args))
        if self._raises is not None:
            raise self._raises
        return self._result


def _make_llm_call(provider: _ScriptedProvider):
    """Build an :class:`LLMCall` that adapts a scripted provider."""

    async def _call(
        messages: list[dict[str, Any]],
        schemas: list[dict[str, Any]],
    ) -> LLMResponse:
        tool_specs = [
            ToolSpec(
                name=s["function"]["name"],
                description=s["function"].get("description", ""),
                input_schema=s["function"].get("parameters", {}),
            )
            for s in schemas
        ]
        resp = await provider.generate_with_tools(messages, None, tool_specs)
        return LLMResponse(
            content=resp.text or "",
            tool_calls=[
                ToolCall(id=tc.id, name=tc.name, args=tc.input)
                for tc in resp.tool_calls
            ],
        )

    return _call


# ── Scenario 1: three-round read→write→done ──────────────────────


@pytest.mark.asyncio
async def test_multi_round_read_then_write_then_done() -> None:
    read_tool = _SpyTool("read_file", result="file contents here")
    write_tool = _SpyTool("write_file", result="ok")

    provider = _ScriptedProvider([
        ProviderResponse(
            text=None,
            tool_calls=[ToolCallRequest(
                id="tc_1", name="read_file", input={"path": "a.txt"},
            )],
            stop_reason="tool_use",
        ),
        ProviderResponse(
            text=None,
            tool_calls=[ToolCallRequest(
                id="tc_2", name="write_file",
                input={"path": "b.txt", "content": "file contents here"},
            )],
            stop_reason="tool_use",
        ),
        ProviderResponse(
            text="done: copied a.txt to b.txt",
            tool_calls=[],
            stop_reason="end_turn",
        ),
    ])

    loop = AgentLoop(
        llm_call=_make_llm_call(provider),
        tools={read_tool.name: read_tool, write_tool.name: write_tool},
    )
    state = await loop.run([{"role": "user", "content": "copy a to b"}])

    assert state.stop_reason == "completed"
    assert state.iterations == 3
    assert state.final_text == "done: copied a.txt to b.txt"
    assert read_tool.calls == [{"path": "a.txt"}]
    assert write_tool.calls == [
        {"path": "b.txt", "content": "file contents here"},
    ]
    # History carries both tool rounds plus the final assistant turn.
    tool_msgs = [m for m in state.messages if m.get("role") == "tool"]
    assert [m["tool_call_id"] for m in tool_msgs] == ["tc_1", "tc_2"]


# ── Scenario 2: max_iterations reached ─────────────────────────


@pytest.mark.asyncio
async def test_max_iterations_reached() -> None:
    # Provider never settles — every round emits another tool_call.
    looping = _ScriptedProvider([
        ProviderResponse(
            text=None,
            tool_calls=[ToolCallRequest(
                id=f"tc_{i}", name="read_file", input={"path": "loop"},
            )],
            stop_reason="tool_use",
        )
        for i in range(10)
    ])
    tool = _SpyTool("read_file", result="x")
    loop = AgentLoop(
        llm_call=_make_llm_call(looping),
        tools={tool.name: tool},
        max_iterations=3,
    )
    state = await loop.run([{"role": "user", "content": "go"}])
    assert state.stop_reason == "max_iterations"
    assert state.iterations == 3
    assert len(tool.calls) == 3


# ── Scenario 3: tool execution error surfaces as is_error ─────


@pytest.mark.asyncio
async def test_tool_execution_error_recovery_round() -> None:
    broken = _SpyTool(
        "read_file", result=None, raises=RuntimeError("disk full"),
    )
    provider = _ScriptedProvider([
        ProviderResponse(
            text=None,
            tool_calls=[ToolCallRequest(
                id="tc_err", name="read_file", input={"path": "x"},
            )],
            stop_reason="tool_use",
        ),
        ProviderResponse(
            text="sorry, bailing",
            tool_calls=[],
            stop_reason="end_turn",
        ),
    ])
    loop = AgentLoop(
        llm_call=_make_llm_call(provider),
        tools={broken.name: broken},
    )
    state = await loop.run([{"role": "user", "content": "try"}])
    assert state.stop_reason == "completed"
    assert state.iterations == 2
    tool_msg = next(m for m in state.messages if m.get("role") == "tool")
    assert tool_msg["is_error"] is True
    assert "disk full" in str(tool_msg["content"])


# ── Scenario 4: zero tool use (pure chat) ─────────────────────


@pytest.mark.asyncio
async def test_zero_tool_use_single_round() -> None:
    provider = _ScriptedProvider([
        ProviderResponse(
            text="hello back",
            tool_calls=[],
            stop_reason="end_turn",
        ),
    ])
    loop = AgentLoop(
        llm_call=_make_llm_call(provider),
        tools={},
    )
    state = await loop.run([{"role": "user", "content": "hi"}])
    assert state.stop_reason == "completed"
    assert state.iterations == 1
    assert state.final_text == "hello back"


# ── Scenario 5: tool-spec round-trip ──────────────────────────


@pytest.mark.asyncio
async def test_tools_forwarded_to_provider_as_toolspec() -> None:
    """The adapter must translate OpenAI-nested schema → ToolSpec."""
    spy = _SpyTool("read_file", result="x")
    provider = _ScriptedProvider([
        ProviderResponse(text="noop", tool_calls=[], stop_reason="end_turn"),
    ])
    loop = AgentLoop(
        llm_call=_make_llm_call(provider),
        tools={spy.name: spy},
    )
    await loop.run([{"role": "user", "content": "noop"}])

    assert len(provider.calls) == 1
    _sent_msgs, sent_tools = provider.calls[0]
    assert len(sent_tools) == 1
    assert sent_tools[0].name == "read_file"
    assert sent_tools[0].description == "read_file spy"
    assert sent_tools[0].input_schema["type"] == "object"
