"""Tests for the non-stream ``PersonaEngine.chat()`` provider migration.

These tests pin the behaviour of the canonical provider-layer path
now that the legacy ``_llm_generate`` / ``_llm_anthropic`` pair has
been deleted:

1. ``chat()`` defaults to Ollama + ``_GEMMA_MODEL`` when no policy
   is supplied (mirrors ``chat_stream``).
2. ``chat()`` respects an explicit :class:`ModelPolicy` and hits
   the requested provider.
3. ``ProviderError`` inside the provider layer is mapped back to
   the legacy ``"[Persona engine error] ..."`` plain string, so
   existing downstream consumers keep working.
4. FTRL feedback still fires after a successful chat.
5. The ``/v1/chat`` endpoint body shape is unchanged (plain JSON
   blob with a ``response`` field).
6. A per-request ``model_policy`` on ``/v1/chat`` plumbs through
   the non-stream path.

Every test is hermetic. Fakes are injected via
:meth:`ProviderRegistry.register_instance` and the module-level
``_engine`` is temporarily swapped when the HTTP surface is under
test. No real LLM endpoint is ever contacted.
"""

from __future__ import annotations

from collections.abc import AsyncIterator
from typing import Any

import pytest
from starlette.testclient import TestClient

import persona.engine as engine_mod
from persona import api as api_module
from persona.api import create_standalone_app
from persona.engine import PersonaEngine
from persona.loader import parse_persona_text
from persona.providers import (
    ModelPolicy,
    ProviderError,
    ProviderRegistry,
)


# ─────────────────── Fakes ───────────────────


class _NonStreamFakeProvider:
    """Async double matching :class:`LLMProvider` Protocol.

    ``reply`` is what :meth:`generate` returns. ``raise_exc`` (when
    set) is raised instead so we can exercise the ProviderError
    → legacy-string mapping path.
    """

    name = "fake"
    last_usage = None

    def __init__(
        self,
        reply: str = "fake-reply",
        raise_exc: ProviderError | None = None,
    ) -> None:
        self.reply = reply
        self.raise_exc = raise_exc
        self.generate_calls: list[
            tuple[list[dict[str, str]], ModelPolicy]
        ] = []

    async def generate(
        self,
        messages: list[dict[str, str]],
        policy: ModelPolicy,
    ) -> str:
        self.generate_calls.append((list(messages), policy))
        if self.raise_exc is not None:
            raise self.raise_exc
        return self.reply

    async def generate_stream(
        self,
        messages: list[dict[str, str]],  # noqa: ARG002
        policy: ModelPolicy,  # noqa: ARG002
    ) -> AsyncIterator[str]:
        # Unused by non-stream tests but required by the Protocol.
        # Make this an async generator so it satisfies the signature.
        if False:  # pragma: no cover — Protocol conformance stub
            yield ""


def _make_registry(
    ollama: _NonStreamFakeProvider | None = None,
    anthropic: _NonStreamFakeProvider | None = None,
) -> ProviderRegistry:
    """Build a registry with the fakes callers care about.

    We always register the generic ``fake`` name so explicit-policy
    tests hit a known provider. The ``ollama`` and ``anthropic``
    names get wired up separately so the ``ModelPolicy`` default
    and explicit-Anthropic routing tests can assert which fake got
    called without cross-contamination.
    """
    reg = ProviderRegistry()
    # Always give tests a ``fake`` handle for explicit policy.
    if ollama is not None:
        reg.register_instance("fake", ollama)
    if ollama is not None:
        reg.register_instance("ollama", ollama)
    if anthropic is not None:
        reg.register_instance("anthropic", anthropic)
    return reg


def _make_persona() -> Any:
    return parse_persona_text(
        "You are Ada, a 30 year old curious engineer from London.",
    )


# ─────────────────── Engine-level ───────────────────


@pytest.mark.asyncio
async def test_chat_defaults_to_ollama_policy() -> None:
    """No model_policy → default ollama fake receives the call."""
    fake = _NonStreamFakeProvider(reply="OLLAMA-DEFAULT")
    engine = PersonaEngine(
        provider_registry=_make_registry(ollama=fake),
    )
    persona = _make_persona()

    out = await engine.chat("t1", persona, "hello world")

    assert out == "OLLAMA-DEFAULT"
    assert len(fake.generate_calls) == 1
    _, policy = fake.generate_calls[0]
    assert policy.provider == "ollama"
    # _GEMMA_MODEL comes from engine module env default.
    assert policy.model == engine_mod._GEMMA_MODEL


@pytest.mark.asyncio
async def test_chat_respects_explicit_model_policy() -> None:
    """Explicit policy → that named provider is hit, not the default."""
    ollama_fake = _NonStreamFakeProvider(reply="OLLAMA-OUTPUT")
    anth_fake = _NonStreamFakeProvider(reply="ANTHROPIC-OUTPUT")
    engine = PersonaEngine(
        provider_registry=_make_registry(
            ollama=ollama_fake, anthropic=anth_fake,
        ),
    )
    persona = _make_persona()

    out = await engine.chat(
        "t2", persona, "hello",
        model_policy=ModelPolicy(
            provider="anthropic", model="claude-haiku-4-5",
        ),
    )

    assert out == "ANTHROPIC-OUTPUT"
    assert len(anth_fake.generate_calls) == 1
    assert ollama_fake.generate_calls == []
    _, used = anth_fake.generate_calls[0]
    assert used.provider == "anthropic"
    assert used.model == "claude-haiku-4-5"


@pytest.mark.asyncio
async def test_chat_provider_error_returns_legacy_string_shape() -> None:
    """ProviderError → ``[Persona engine error] <provider>: <detail>``."""
    fake = _NonStreamFakeProvider(
        raise_exc=ProviderError("ollama", "boom"),
    )
    engine = PersonaEngine(
        provider_registry=_make_registry(ollama=fake),
    )
    persona = _make_persona()

    # Must NOT raise — legacy contract is error-as-string.
    out = await engine.chat("t3", persona, "please explode")

    assert isinstance(out, str)
    assert out == "[Persona engine error] ollama: boom"
    # Error response is still committed to history so the turn
    # is not silently lost on replay.
    ctx = engine.get_or_create_context("t3", persona)
    assert ctx.messages[-1] == {
        "role": "assistant",
        "content": "[Persona engine error] ollama: boom",
    }


@pytest.mark.asyncio
async def test_chat_preserves_rag_feedback(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Successful chat → rag.feedback() fires with the real hits."""
    fake = _NonStreamFakeProvider(reply="FOO")
    engine = PersonaEngine(
        provider_registry=_make_registry(ollama=fake),
    )

    hits = [
        {
            "text": "Ada once debugged a steam engine.",
            "file": "memory/persona/ada.md",
            "source_type": "persona_memory",
            "score": 0.9,
        },
    ]

    class _FakeRAG:
        def __init__(self) -> None:
            self.search_calls: list[tuple[str, int]] = []
            self.feedback_calls: list[list[dict]] = []

        def search(self, query: str, top_k: int = 3) -> list[dict]:
            self.search_calls.append((query, top_k))
            return list(hits)

        def feedback(self, used: list[dict]) -> None:
            self.feedback_calls.append(used)

    fake_rag = _FakeRAG()
    engine._rag = fake_rag  # type: ignore[assignment]

    def _force_rag(_msg: str, _turn: int) -> Any:
        class _R:
            use_rag = True
        return _R()

    monkeypatch.setattr(engine_mod, "route_persona_query", _force_rag)

    out = await engine.chat(
        "rag-ctx", _make_persona(), "tell me about ada",
    )

    assert out == "FOO"
    assert fake_rag.search_calls
    assert fake_rag.feedback_calls == [hits]
    # Provider saw the injected RAG block on the wire.
    sent_messages, _ = fake.generate_calls[0]
    assert "[Retrieved Persona Context]" in sent_messages[0]["content"]
    assert "steam engine" in sent_messages[0]["content"]


# ─────────────────── HTTP endpoint ───────────────────


@pytest.fixture()
def non_stream_client() -> TestClient:
    """HTTP client whose engine routes every call to a fake provider."""
    fake = _NonStreamFakeProvider(reply="HTTP-FAKE-REPLY")
    engine = PersonaEngine(
        provider_registry=_make_registry(ollama=fake),
    )
    orig = api_module._engine
    api_module._engine = engine  # type: ignore[assignment]
    try:
        yield TestClient(create_standalone_app())
    finally:
        api_module._engine = orig  # type: ignore[assignment]


def test_chat_non_stream_response_format_unchanged(
    non_stream_client: TestClient,
) -> None:
    """Happy-path /v1/chat still returns ``{response: str, ...}``."""
    body = {
        "message": "hello ada",
        "context_id": "http-regression",
        "persona_id": "ada",
        "persona_text": (
            "You are Ada, a 30 year old curious engineer from London."
        ),
    }
    resp = non_stream_client.post("/v1/chat", json=body)
    assert resp.status_code == 200
    data = resp.json()
    assert data["response"] == "HTTP-FAKE-REPLY"
    assert "track" in data
    assert "context_id" in data
    assert data["context_id"] == "http-regression"


def test_chat_non_stream_plumbs_model_policy_into_engine() -> None:
    """Explicit ``model_policy`` on /v1/chat reaches engine.chat()."""
    ollama_fake = _NonStreamFakeProvider(reply="OLLAMA-VIA-HTTP")
    anth_fake = _NonStreamFakeProvider(reply="ANTHROPIC-VIA-HTTP")
    engine = PersonaEngine(
        provider_registry=_make_registry(
            ollama=ollama_fake, anthropic=anth_fake,
        ),
    )
    orig = api_module._engine
    api_module._engine = engine  # type: ignore[assignment]
    try:
        client = TestClient(create_standalone_app())
        body = {
            "message": "hello from anthropic",
            "context_id": "policy-plumb",
            "persona_id": "ada",
            "persona_text": (
                "You are Ada, a 30 year old curious engineer "
                "from London."
            ),
            "model_policy": {
                "provider": "anthropic",
                "model": "claude-haiku-4-5",
                "temperature": 0.2,
                "max_tokens": 64,
            },
        }
        resp = client.post("/v1/chat", json=body)
    finally:
        api_module._engine = orig  # type: ignore[assignment]

    assert resp.status_code == 200
    data = resp.json()
    assert data["response"] == "ANTHROPIC-VIA-HTTP"
    assert len(anth_fake.generate_calls) == 1
    assert ollama_fake.generate_calls == []
    _, used_policy = anth_fake.generate_calls[0]
    assert used_policy.provider == "anthropic"
    assert used_policy.model == "claude-haiku-4-5"
    assert used_policy.temperature == 0.2
    assert used_policy.max_tokens == 64
