"""Tests for ``persona.compaction`` (M1 Week 2 task #8.1).

Covers:
  * estimate_tokens / count_message_tokens / count_messages_tokens
  * CompactionConfig threshold / target math
  * should_compact — under, over, below message floor
  * select_preserved — system anchor, last-N user turns, open tool_use
  * deterministic_summarizer — header + bullet shape + truncation
  * summarize_dropped — fallback on summarizer raise
  * compact_messages — no-op, replace_dropped, prepend, force
  * AutoCompactor — usage_pct, history bound, force vs maybe
  * make_llm_summarizer — happy path with a mock driver
"""
from __future__ import annotations

from collections.abc import Sequence
from typing import Any

import pytest

from persona.compaction import (
    AutoCompactor,
    CompactionConfig,
    CompactionResult,
    SummarizerCallable,
    compact_messages,
    count_message_tokens,
    count_messages_tokens,
    deterministic_summarizer,
    estimate_tokens,
    make_llm_summarizer,
    select_preserved,
    should_compact,
    summarize_dropped,
)


# ─────────────────────────────────────────────────────────────────
# Token estimation
# ─────────────────────────────────────────────────────────────────


class TestEstimateTokens:
    def test_empty_string_zero(self) -> None:
        assert estimate_tokens("") == 0

    def test_single_char_at_least_one(self) -> None:
        assert estimate_tokens("a") >= 1

    def test_ascii_blended_ratio(self) -> None:
        # ~3.5 chars/token blended → 70 chars ≈ 20 tokens
        text = "a" * 70
        assert 18 <= estimate_tokens(text) <= 22

    def test_cjk_heavier(self) -> None:
        cjk = "繁體中文測試字串內容多" * 5
        ascii_text = "abcde" * (len(cjk) // 5)
        # CJK should weigh more per char than ASCII.
        assert estimate_tokens(cjk) > estimate_tokens(ascii_text) * 1.2


class TestCountMessageTokens:
    def test_simple_string_content(self) -> None:
        msg = {"role": "user", "content": "hello world"}
        assert count_message_tokens(msg) >= 5  # "user" + content + 4 overhead

    def test_block_content(self) -> None:
        msg = {
            "role": "assistant",
            "content": [
                {"type": "text", "text": "answer"},
                {"type": "tool_use", "name": "fetch", "input": {"url": "x"}, "id": "t1"},
            ],
        }
        assert count_message_tokens(msg) > 0

    def test_total_messages(self) -> None:
        msgs = [
            {"role": "user", "content": "abc"},
            {"role": "assistant", "content": "def"},
        ]
        total = count_messages_tokens(msgs)
        assert total == sum(count_message_tokens(m) for m in msgs)


# ─────────────────────────────────────────────────────────────────
# Threshold decision
# ─────────────────────────────────────────────────────────────────


class TestShouldCompact:
    def test_below_min_messages_never_triggers(self) -> None:
        cfg = CompactionConfig(
            context_window=100, threshold_pct=0.1, min_messages_to_compact=10,
        )
        msgs = [{"role": "user", "content": "x" * 1000}]
        triggered, _ = should_compact(msgs, cfg)
        assert triggered is False

    def test_above_threshold_triggers(self) -> None:
        cfg = CompactionConfig(
            context_window=200, threshold_pct=0.5, min_messages_to_compact=2,
        )
        msgs = [
            {"role": "user", "content": "x" * 500},
            {"role": "assistant", "content": "y" * 500},
        ]
        triggered, tokens = should_compact(msgs, cfg)
        assert triggered is True
        assert tokens > cfg.threshold_tokens()

    def test_under_threshold_does_not_trigger(self) -> None:
        cfg = CompactionConfig(
            context_window=200_000, threshold_pct=0.8, min_messages_to_compact=2,
        )
        msgs = [
            {"role": "user", "content": "tiny"},
            {"role": "assistant", "content": "tiny"},
        ]
        triggered, _ = should_compact(msgs, cfg)
        assert triggered is False

    def test_threshold_tokens_helper(self) -> None:
        cfg = CompactionConfig(context_window=100_000, threshold_pct=0.8)
        assert cfg.threshold_tokens() == 80_000

    def test_target_tokens_helper(self) -> None:
        cfg = CompactionConfig(context_window=100_000, target_post_compact_pct=0.4)
        assert cfg.target_tokens() == 40_000


# ─────────────────────────────────────────────────────────────────
# Preservation selection
# ─────────────────────────────────────────────────────────────────


class TestSelectPreserved:
    def _build(self, n_pairs: int) -> list[dict[str, Any]]:
        msgs: list[dict[str, Any]] = []
        for i in range(n_pairs):
            msgs.append({"role": "user", "content": f"q{i}"})
            msgs.append({"role": "assistant", "content": f"a{i}"})
        return msgs

    def test_preserves_last_n_user_turns(self) -> None:
        msgs = self._build(10)  # 20 messages, 10 user turns
        cfg = CompactionConfig(preserve_last_user_turns=3)
        preserved, dropped = select_preserved(msgs, cfg)
        # Last 3 users start at index 14 (q7) → keep 14..19 = 6 msgs
        assert preserved[0] == 14
        assert dropped[-1] < 14

    def test_disjoint(self) -> None:
        msgs = self._build(10)
        cfg = CompactionConfig(preserve_last_user_turns=3)
        preserved, dropped = select_preserved(msgs, cfg)
        assert set(preserved).isdisjoint(set(dropped))
        assert len(preserved) + len(dropped) == len(msgs)

    def test_system_anchor_kept(self) -> None:
        msgs = [
            {"role": "system", "content": "system prompt"},
            *self._build(5),
        ]
        cfg = CompactionConfig(preserve_last_user_turns=1)
        preserved, _ = select_preserved(msgs, cfg)
        assert 0 in preserved

    def test_open_tool_use_preserved(self) -> None:
        msgs = [
            {"role": "user", "content": "old1"},
            {"role": "assistant", "content": "old2"},
            {
                "role": "assistant",
                "content": [{"type": "tool_use", "id": "t1", "name": "x", "input": {}}],
            },
            # No matching tool_result — open!
            {"role": "user", "content": "later1"},
            {"role": "assistant", "content": "later2"},
            {"role": "user", "content": "later3"},
            {"role": "assistant", "content": "later4"},
        ]
        cfg = CompactionConfig(preserve_last_user_turns=1)
        preserved, _ = select_preserved(msgs, cfg)
        # Index 2 (open tool_use) must survive even though it's not in
        # the last-1-user window.
        assert 2 in preserved

    def test_resolved_tool_use_droppable(self) -> None:
        msgs = [
            {
                "role": "assistant",
                "content": [{"type": "tool_use", "id": "t1", "name": "x", "input": {}}],
            },
            {
                "role": "user",
                "content": [{"type": "tool_result", "tool_use_id": "t1", "content": "ok"}],
            },
            {"role": "user", "content": "u1"},
            {"role": "assistant", "content": "a1"},
            {"role": "user", "content": "u2"},
            {"role": "assistant", "content": "a2"},
            {"role": "user", "content": "u3"},
            {"role": "assistant", "content": "a3"},
        ]
        cfg = CompactionConfig(preserve_last_user_turns=2)
        preserved, dropped = select_preserved(msgs, cfg)
        # The closed tool_use pair (idx 0,1) can be dropped now.
        assert 0 in dropped
        assert 1 in dropped

    def test_empty_input(self) -> None:
        preserved, dropped = select_preserved([], CompactionConfig())
        assert preserved == []
        assert dropped == []


# ─────────────────────────────────────────────────────────────────
# Summarizer
# ─────────────────────────────────────────────────────────────────


class TestDeterministicSummarizer:
    def test_empty_input(self) -> None:
        out = deterministic_summarizer([], 1000)
        assert "0 messages" in out

    def test_header_and_bullets(self) -> None:
        msgs = [
            {"role": "user", "content": "first question."},
            {"role": "assistant", "content": "first answer."},
            {"role": "user", "content": "second question."},
        ]
        out = deterministic_summarizer(msgs, 1000)
        assert out.startswith("[compaction-summary 3 messages")
        assert "- user: first question." in out
        assert "- assistant: first answer." in out

    def test_truncation_budget(self) -> None:
        big = [{"role": "user", "content": "x" * 200} for _ in range(100)]
        out = deterministic_summarizer(big, 50)
        # Should hit the budget bail-out marker.
        assert "truncated" in out

    def test_long_content_first_120(self) -> None:
        msgs = [{"role": "user", "content": "a" * 500}]
        out = deterministic_summarizer(msgs, 1000)
        assert "…" in out


class TestSummarizeDropped:
    def test_falls_back_on_exception(self) -> None:
        def bad_summarizer(*_args: Any, **_kwargs: Any) -> str:
            raise RuntimeError("kaboom")

        out = summarize_dropped(
            [{"role": "user", "content": "hi"}],
            CompactionConfig(),
            bad_summarizer,
        )
        # Falls back to deterministic — should produce the marker.
        assert "[compaction-summary" in out

    def test_falls_back_on_empty_string(self) -> None:
        def empty_summarizer(*_args: Any, **_kwargs: Any) -> str:
            return ""

        out = summarize_dropped(
            [{"role": "user", "content": "hi"}],
            CompactionConfig(),
            empty_summarizer,
        )
        assert "[compaction-summary" in out

    def test_uses_provided_when_works(self) -> None:
        def custom(*_args: Any, **_kwargs: Any) -> str:
            return "custom-summary-text"

        out = summarize_dropped(
            [{"role": "user", "content": "hi"}],
            CompactionConfig(),
            custom,
        )
        assert out == "custom-summary-text"


# ─────────────────────────────────────────────────────────────────
# Orchestrator
# ─────────────────────────────────────────────────────────────────


class TestCompactMessages:
    def _bulky_msgs(self, n: int = 20, payload: int = 1000) -> list[dict[str, Any]]:
        msgs = []
        for i in range(n):
            role = "user" if i % 2 == 0 else "assistant"
            msgs.append({"role": role, "content": "x" * payload})
        return msgs

    def test_no_op_when_below_threshold(self) -> None:
        cfg = CompactionConfig(context_window=1_000_000)
        msgs = [{"role": "user", "content": "tiny"}] * 10
        result = compact_messages(msgs, cfg)
        assert result.triggered is False
        assert result.new_messages == msgs
        # Returned list is a fresh copy, not the same reference.
        assert result.new_messages is not msgs

    def test_force_when_below_threshold(self) -> None:
        cfg = CompactionConfig(
            context_window=1_000_000, preserve_last_user_turns=1,
            min_messages_to_compact=2,
        )
        msgs = self._bulky_msgs(10, 50)
        result = compact_messages(msgs, cfg, force=True)
        assert result.triggered is True
        assert result.dropped_count > 0

    def test_replace_dropped_placement(self) -> None:
        cfg = CompactionConfig(
            context_window=200, threshold_pct=0.1, preserve_last_user_turns=2,
            min_messages_to_compact=2,
        )
        msgs = self._bulky_msgs(20, 100)
        result = compact_messages(msgs, cfg)
        assert result.triggered is True
        # Summary block should appear *before* the preserved tail.
        compact_blocks = [
            i for i, m in enumerate(result.new_messages) if m.get("_compaction")
        ]
        assert len(compact_blocks) == 1

    def test_prepend_placement(self) -> None:
        cfg = CompactionConfig(
            context_window=200, threshold_pct=0.1, preserve_last_user_turns=2,
            min_messages_to_compact=2,
        )
        msgs = self._bulky_msgs(20, 100)
        result = compact_messages(msgs, cfg, placement="prepend")
        assert result.new_messages[0].get("_compaction") is True

    def test_token_count_drops(self) -> None:
        cfg = CompactionConfig(
            context_window=200, threshold_pct=0.1, preserve_last_user_turns=2,
            min_messages_to_compact=2,
        )
        msgs = self._bulky_msgs(20, 100)
        result = compact_messages(msgs, cfg)
        assert result.after_tokens < result.before_tokens
        assert result.tokens_freed > 0

    def test_no_drops_returns_no_op(self) -> None:
        cfg = CompactionConfig(
            context_window=10, threshold_pct=0.1, preserve_last_user_turns=10,
            min_messages_to_compact=2,
        )
        msgs = self._bulky_msgs(4, 100)
        # All messages preserved by the last-N rule → nothing to drop.
        result = compact_messages(msgs, cfg, force=True)
        assert result.triggered is False
        assert "nothing to drop" in result.reason


# ─────────────────────────────────────────────────────────────────
# AutoCompactor
# ─────────────────────────────────────────────────────────────────


class TestAutoCompactor:
    def test_usage_pct(self) -> None:
        comp = AutoCompactor(CompactionConfig(context_window=1000))
        msgs = [{"role": "user", "content": "x" * 350}]  # ~100 tokens
        pct = comp.usage_pct(msgs)
        assert 0.0 < pct < 0.5

    def test_usage_summary_shape(self) -> None:
        comp = AutoCompactor(CompactionConfig(context_window=10_000))
        summary = comp.usage_summary([{"role": "user", "content": "hi"}])
        for key in (
            "tokens", "context_window", "usage_pct", "threshold_pct",
            "threshold_tokens", "messages", "events", "last_event",
        ):
            assert key in summary
        assert summary["last_event"] is None  # nothing run yet

    def test_force_compact_records_event(self) -> None:
        comp = AutoCompactor(
            CompactionConfig(
                context_window=1_000_000, preserve_last_user_turns=1,
                min_messages_to_compact=2,
            ),
        )
        msgs = [{"role": "user", "content": "x" * 100} for _ in range(10)]
        comp.force_compact(msgs)
        assert len(comp.history) == 1
        assert comp.history[0].triggered is True

    def test_history_bounded(self) -> None:
        comp = AutoCompactor(CompactionConfig(context_window=1_000_000))
        for _ in range(40):
            comp.maybe_compact([{"role": "user", "content": "tiny"}])
        assert len(comp.history) <= AutoCompactor._MAX_HISTORY  # noqa: SLF001

    def test_maybe_compact_no_trigger(self) -> None:
        comp = AutoCompactor(CompactionConfig(context_window=1_000_000))
        result = comp.maybe_compact(
            [{"role": "user", "content": "tiny"}, {"role": "assistant", "content": "tiny"}],
        )
        assert result.triggered is False


# ─────────────────────────────────────────────────────────────────
# LLM-backed summarizer adapter
# ─────────────────────────────────────────────────────────────────


class _MockDriver:
    def __init__(self, text: str) -> None:
        self.text = text
        self.calls: list[dict[str, Any]] = []

    def complete(
        self,
        messages: list[dict[str, Any]],
        tools: list[dict[str, Any]] | None = None,
        **kwargs: Any,
    ) -> Any:
        self.calls.append({"messages": messages, "kwargs": kwargs})
        return type("Resp", (), {"text": self.text})()


class TestMakeLlmSummarizer:
    def test_round_trip(self) -> None:
        driver = _MockDriver("LLM SUMMARY")
        summarizer = make_llm_summarizer(driver)
        out = summarizer(
            [
                {"role": "user", "content": "question"},
                {"role": "assistant", "content": "answer"},
            ],
            500,
        )
        assert out == "LLM SUMMARY"
        assert len(driver.calls) == 1
        assert "max_tokens" in driver.calls[0]["kwargs"]

    def test_includes_transcript(self) -> None:
        driver = _MockDriver("ok")
        summarizer = make_llm_summarizer(driver)
        summarizer(
            [{"role": "user", "content": "MAGIC_TOKEN_42"}],
            200,
        )
        prompt = driver.calls[0]["messages"][0]["content"]
        assert "MAGIC_TOKEN_42" in prompt
        assert "user" in prompt


# ─────────────────────────────────────────────────────────────────
# Protocol / type sanity
# ─────────────────────────────────────────────────────────────────


def test_summarizer_callable_protocol() -> None:
    """Ensure deterministic_summarizer satisfies the Protocol structurally."""

    def consumer(s: SummarizerCallable) -> str:
        return s([{"role": "user", "content": "hi"}], 100)

    assert "compaction-summary" in consumer(deterministic_summarizer)


def test_compaction_result_tokens_freed_never_negative() -> None:
    r = CompactionResult(
        triggered=True,
        before_tokens=10,
        after_tokens=20,  # weird: after > before
        before_messages=5,
        after_messages=3,
        preserved_count=2,
        dropped_count=1,
        summary_tokens=15,
    )
    assert r.tokens_freed == 0  # clamped


@pytest.mark.parametrize(
    "content,expected_min",
    [
        ("hello", 1),
        ("a" * 100, 20),
        ("中文" * 50, 30),
    ],
)
def test_estimate_tokens_parametric(content: str, expected_min: int) -> None:
    assert estimate_tokens(content) >= expected_min


def test_count_messages_tokens_iterable() -> None:
    """Accepts any iterable, not just list."""

    def gen() -> Sequence[dict[str, Any]]:
        return [{"role": "user", "content": "a"}, {"role": "assistant", "content": "b"}]

    assert count_messages_tokens(gen()) > 0
