"""Regression: post-hook chain preserves dict result type for downstream hooks.

Covers RED Opus HIGH-5 (2026-05-01): when a hook returns a
``PostToolUseDecision`` with ``additional_context`` and the current
``result`` is a ``dict`` (or ``list``), the agent loop previously
``json.dumps``'d the dict + concatenated the context — the next hook
in the chain saw a string, not the original structured value.

Fix wraps non-string structured results as
``{"output": <orig>, "additional_context": ctx}`` so subsequent hooks
still see the structured shape, and the final ``_tool_msg``
JSON-serialises whatever the chain ends with.

Also covers RED Opus FATAL-3 (2026-05-01): the default Cerno post-hook
must return ``PostToolUseDecision()`` (zero-field) rather than ``None``
so the agent loop's legacy-hook DeprecationWarning shim does NOT fire
on every Sancio production tool call.
"""

from __future__ import annotations

import warnings
from typing import Any

import pytest

from persona.cerno.types import CernoAllow
from persona.engine.agent_loop import (
    AgentLoop,
    LLMResponse,
    PostToolUseDecision,
    ToolCall,
)
from persona.hooks import make_cerno_post_hook


class _DictTool:
    """Tool returning a dict so we can prove dict-result preservation."""

    name = "fetch_user"

    def __init__(self) -> None:
        self.calls: list[dict[str, Any]] = []

    def schema(self) -> dict[str, Any]:
        return {"type": "function", "function": {"name": "fetch_user"}}

    async def execute(self, args: dict[str, Any]) -> Any:
        self.calls.append(args)
        return {"id": 42, "name": "alice", "email": "a@b.c"}


def _scripted_llm(replies: list[LLMResponse]):
    idx = {"i": 0}

    async def _call(
        _messages: list[dict[str, Any]],
        _schemas: list[dict[str, Any]],
    ) -> LLMResponse:
        i = idx["i"]
        idx["i"] = i + 1
        return replies[i]

    return _call


@pytest.mark.asyncio
async def test_additional_context_preserves_dict_result_for_next_hook() -> None:
    """Hook A returns ctx → Hook B sees the original dict, not a string."""
    captured_results: list[Any] = []

    async def hook_a(
        _name: str, _args: dict[str, Any], _result: Any,
    ) -> PostToolUseDecision | None:
        return PostToolUseDecision(additional_context=" [redacted-pii]")

    async def hook_b(
        _name: str, _args: dict[str, Any], result: Any,
    ) -> PostToolUseDecision | None:
        captured_results.append(result)
        return PostToolUseDecision()

    loop = AgentLoop(
        llm_call=_scripted_llm([
            LLMResponse(
                tool_calls=[ToolCall(id="c1", name="fetch_user", args={})],
            ),
            LLMResponse(content="done."),
        ]),
        tools={"fetch_user": _DictTool()},
        post_hooks=[hook_a, hook_b],
    )

    state = await loop.run([{"role": "user", "content": "fetch"}])

    assert state.done is True
    assert len(captured_results) == 1, (
        "hook_b should have observed exactly one post-hook invocation"
    )
    seen_by_b = captured_results[0]
    # Pre-fix this would be a JSON string. Post-fix it must be a dict
    # (the wrapper) so structured-data downstream hooks keep working.
    assert isinstance(seen_by_b, dict), (
        f"hook_b saw {type(seen_by_b).__name__}, expected dict — "
        f"additional_context broke type preservation"
    )
    assert seen_by_b.get("output") == {
        "id": 42, "name": "alice", "email": "a@b.c",
    }, "original dict must be preserved under 'output' key"
    assert seen_by_b.get("additional_context") == " [redacted-pii]"


@pytest.mark.asyncio
async def test_additional_context_string_result_concatenates_unchanged() -> None:
    """When result is a string, additional_context still concatenates (back-compat)."""
    captured_results: list[Any] = []

    class _StrTool:
        name = "echo"

        def schema(self) -> dict[str, Any]:
            return {"type": "function", "function": {"name": "echo"}}

        async def execute(self, args: dict[str, Any]) -> str:
            return "ORIGINAL"

    async def hook_a(
        _name: str, _args: dict[str, Any], _result: Any,
    ) -> PostToolUseDecision | None:
        return PostToolUseDecision(additional_context=" + ctx")

    async def hook_b(
        _name: str, _args: dict[str, Any], result: Any,
    ) -> PostToolUseDecision | None:
        captured_results.append(result)
        return PostToolUseDecision()

    loop = AgentLoop(
        llm_call=_scripted_llm([
            LLMResponse(tool_calls=[ToolCall(id="c1", name="echo", args={})]),
            LLMResponse(content="done."),
        ]),
        tools={"echo": _StrTool()},
        post_hooks=[hook_a, hook_b],
    )

    await loop.run([{"role": "user", "content": "echo"}])
    assert captured_results == ["ORIGINAL + ctx"]


# ── Fix #3 verification ────────────────────────────────────────


class _FakeCerno:
    def cycle(self, _user_input: str, _child_output: str) -> Any:
        return CernoAllow()


@pytest.mark.asyncio
async def test_cerno_hook_default_does_not_warn_legacy() -> None:
    """Default Cerno hook returns ``PostToolUseDecision()`` so the legacy-hook
    DeprecationWarning shim does NOT fire (RED Opus FATAL-3)."""

    class _EchoTool:
        name = "echo"

        def schema(self) -> dict[str, Any]:
            return {"type": "function", "function": {"name": "echo"}}

        async def execute(self, args: dict[str, Any]) -> str:
            return args.get("text", "")

    cerno_hook = make_cerno_post_hook(_FakeCerno())  # type: ignore[arg-type]

    loop = AgentLoop(
        llm_call=_scripted_llm([
            LLMResponse(
                tool_calls=[
                    ToolCall(id="c1", name="echo", args={"text": "hi"}),
                ],
            ),
            LLMResponse(content="done."),
        ]),
        tools={"echo": _EchoTool()},
        post_hooks=[cerno_hook],
    )

    with warnings.catch_warnings(record=True) as captured:
        warnings.simplefilter("always")
        state = await loop.run([{"role": "user", "content": "go"}])

    deprecation_warnings = [
        w for w in captured if issubclass(w.category, DeprecationWarning)
        and "PostToolUseHook returned None" in str(w.message)
    ]
    assert state.done is True
    assert not deprecation_warnings, (
        f"Default Cerno hook still emits legacy DeprecationWarning: "
        f"{[str(w.message) for w in deprecation_warnings]} — "
        f"expected zero (Sancio's own default warning against itself = log spam)"
    )
