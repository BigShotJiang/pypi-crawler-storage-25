"""Regression test for the Sancio fanout entry-point registration.

Why this test exists
--------------------
``persona.hooks.fanout`` resolves out-of-process subscribers via setuptools
``importlib.metadata.entry_points``. The fanout group names
(``sancio.hooks.session_start`` / ``sancio.hooks.session_stop``) are public
contract — any operator who ``pip install persona-api`` should see at least
one default subscriber loaded so the entry-point side of the registry is
exercised, not dead code.

Without an entry in ``pyproject.toml`` the entry-points selection returns
empty, the loader silently no-ops, and the registry path only ever fires
in-process subscribers — which means tests passing locally tells us
nothing about whether the wheel actually ships the entry-point metadata.

This test asserts two invariants:

1. The ``LoggingSubscriber`` callable is importable from
   ``persona.hooks.builtins`` (the symbol the entry points reference).
2. ``importlib.metadata.entry_points`` resolves the
   ``sancio.hooks.session_start`` and ``sancio.hooks.session_stop`` groups
   to at least one entry whose target module is
   ``persona.hooks.builtins``. This requires the package to be installed
   (editable or wheel) so the entry-point metadata is on sys.path.

The second assertion is **conditionally skipped** when the test is run
against a source checkout that has not been ``pip install -e .``-ed yet
— developers running the tests via ``pytest`` directly out of the repo
without prior install would otherwise see a confusing failure when the
real bug is "package not installed". The skip condition prints the
diagnostic explicitly so CI cannot silently pass.
"""

from __future__ import annotations

from importlib.metadata import PackageNotFoundError, entry_points, version

import pytest

from persona.hooks.fanout import SessionEvent


def test_logging_subscriber_class_importable() -> None:
    """The class form is importable and constructs without args."""
    from persona.hooks.builtins import LoggingSubscriber

    sub = LoggingSubscriber()
    # The class is callable as a subscriber via __call__ dispatching on
    # event.phase — verifying the dispatch shape here keeps the
    # entry-point contract end-to-end testable without spinning the
    # whole asyncio fanout.
    sub(SessionEvent(
        phase="start", session_id="t-1", started_at=0.0, extra={},
    ))
    sub(SessionEvent(
        phase="stop", session_id="t-1", started_at=0.0, extra={},
    ))


def test_logging_subscriber_callables_importable() -> None:
    """The free-function aliases used by the entry points exist."""
    from persona.hooks.builtins import on_session_start, on_session_stop

    on_session_start(SessionEvent(
        phase="start", session_id="t-2", started_at=0.0, extra={},
    ))
    on_session_stop(SessionEvent(
        phase="stop", session_id="t-2", started_at=0.0, extra={},
    ))


def _persona_api_installed() -> bool:
    """Return True iff persona-api metadata is discoverable via importlib."""
    try:
        version("persona-api")
    except PackageNotFoundError:
        return False
    return True


@pytest.mark.skipif(
    not _persona_api_installed(),
    reason=(
        "persona-api metadata not installed — run "
        "`pip install -e projects/sancio-runtime` to exercise the "
        "entry-point round-trip. Pure source-tree pytest cannot see "
        "entry_points until the package is installed."
    ),
)
def test_session_start_entry_point_resolves_to_builtins() -> None:
    """The wheel ships at least one ``sancio.hooks.session_start`` entry.

    The default ``logging`` entry must point at
    ``persona.hooks.builtins`` so a fresh install has a non-empty
    fanout subscriber set.
    """
    eps = entry_points(group="sancio.hooks.session_start")
    targets = [ep.value for ep in eps]
    assert any("persona.hooks.builtins" in t for t in targets), (
        "Expected at least one 'sancio.hooks.session_start' entry "
        f"pointing at persona.hooks.builtins; got {targets!r}"
    )


@pytest.mark.skipif(
    not _persona_api_installed(),
    reason=(
        "persona-api metadata not installed — see "
        "test_session_start_entry_point_resolves_to_builtins for fix."
    ),
)
def test_session_stop_entry_point_resolves_to_builtins() -> None:
    """Mirror of the SessionStart test for the SessionStop group."""
    eps = entry_points(group="sancio.hooks.session_stop")
    targets = [ep.value for ep in eps]
    assert any("persona.hooks.builtins" in t for t in targets), (
        "Expected at least one 'sancio.hooks.session_stop' entry "
        f"pointing at persona.hooks.builtins; got {targets!r}"
    )


@pytest.mark.skipif(
    not _persona_api_installed(),
    reason="persona-api metadata not installed",
)
def test_entry_point_load_returns_callable_subscriber() -> None:
    """The entry point must ``.load()`` to a callable accepting SessionEvent.

    This is the contract :func:`persona.hooks.fanout._load_entry_point_subscribers`
    enforces — anything non-callable is logged and skipped, which would
    silently regress the default subscriber. Asserting the load contract
    here protects against future ``pyproject.toml`` typos that point at
    a missing symbol.
    """
    eps = entry_points(group="sancio.hooks.session_start")
    builtins_eps = [ep for ep in eps if "persona.hooks.builtins" in ep.value]
    assert builtins_eps, "no persona.hooks.builtins entry in session_start group"

    loaded = builtins_eps[0].load()
    assert callable(loaded), f"loaded entry point {loaded!r} is not callable"

    # Smoke-call to ensure the loaded symbol actually accepts the event
    # shape the fanout dispatches with.
    loaded(SessionEvent(
        phase="start", session_id="ep-load", started_at=0.0, extra={},
    ))
