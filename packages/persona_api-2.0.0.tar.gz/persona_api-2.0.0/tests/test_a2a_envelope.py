"""Envelope primitives — signing, timestamp skew, nonce replay."""

from __future__ import annotations

import base64
import time

import pytest
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import (
    Ed25519PrivateKey,
)

from persona.a2a_security import (
    A2ADenied,
    NonceCache,
    canonical_payload,
    check_timestamp_skew,
    sign_ed25519,
    sign_hmac,
    validate_envelope_shape,
    verify_ed25519,
    verify_hmac,
)


def _keypair():
    pk = Ed25519PrivateKey.generate()
    priv_raw = pk.private_bytes(
        serialization.Encoding.Raw,
        serialization.PrivateFormat.Raw,
        serialization.NoEncryption(),
    )
    pub_raw = pk.public_key().public_bytes(
        serialization.Encoding.Raw,
        serialization.PublicFormat.Raw,
    )
    return (
        base64.b64encode(priv_raw).decode("ascii"),
        base64.b64encode(pub_raw).decode("ascii"),
    )


def _envelope(method="agent.invoke"):
    return {
        "id": "req-1",
        "from": "peer.x",
        "to": "aegis.local",
        "method": method,
        "params": {"tool": "echo", "value": 1},
        "nonce": "nonce-1",
        "timestamp": int(time.time()),
    }


def test_canonical_payload_is_stable_and_ignores_signature():
    env1 = _envelope()
    env2 = dict(env1)
    env2["signature"] = "ignored"
    assert canonical_payload(env1) == canonical_payload(env2)


def test_canonical_payload_is_sorted():
    env = _envelope()
    out = canonical_payload(env)
    # Key ordering deterministic regardless of insertion.
    assert b'"from":"peer.x"' in out
    assert b'"id":"req-1"' in out


def test_ed25519_sign_verify_roundtrip():
    priv, pub = _keypair()
    env = _envelope()
    env["signature"] = sign_ed25519(priv, env)
    assert verify_ed25519(pub, env) is True


def test_ed25519_bad_signature_rejected():
    priv, pub = _keypair()
    env = _envelope()
    env["signature"] = sign_ed25519(priv, env)
    # Tamper with the payload after signing.
    env["params"] = {"tool": "echo", "value": 2}
    assert verify_ed25519(pub, env) is False


def test_ed25519_missing_signature_rejected():
    _priv, pub = _keypair()
    env = _envelope()
    assert verify_ed25519(pub, env) is False


def test_hmac_sign_verify_roundtrip():
    secret = b"shared-secret-bytes"
    env = _envelope()
    env["signature"] = sign_hmac(secret, env)
    assert verify_hmac(secret, env) is True


def test_hmac_wrong_secret_rejected():
    env = _envelope()
    env["signature"] = sign_hmac(b"one", env)
    assert verify_hmac(b"two", env) is False


def test_timestamp_skew_accepts_now():
    env = _envelope()
    check_timestamp_skew(env)  # does not raise


def test_timestamp_skew_rejects_old():
    env = _envelope()
    env["timestamp"] = int(time.time()) - 3600
    with pytest.raises(A2ADenied) as exc:
        check_timestamp_skew(env)
    assert exc.value.status == 401


def test_timestamp_skew_rejects_missing():
    env = _envelope()
    env.pop("timestamp")
    with pytest.raises(A2ADenied):
        check_timestamp_skew(env)


def test_nonce_cache_first_use_ok():
    cache = NonceCache()
    cache.check_and_add("abc")


def test_nonce_cache_replay_denied():
    cache = NonceCache()
    cache.check_and_add("abc")
    with pytest.raises(A2ADenied) as exc:
        cache.check_and_add("abc")
    assert exc.value.status == 409


def test_nonce_cache_empty_denied():
    cache = NonceCache()
    with pytest.raises(A2ADenied):
        cache.check_and_add("")


def test_validate_envelope_shape_missing_fields():
    with pytest.raises(A2ADenied) as exc:
        validate_envelope_shape({"id": "x"})
    assert exc.value.status == 400
    assert "missing" in exc.value.message
