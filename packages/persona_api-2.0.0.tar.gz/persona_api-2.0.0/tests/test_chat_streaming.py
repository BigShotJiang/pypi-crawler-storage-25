"""Tests for the A5 streaming chat path — engine + ``/v1/chat/stream``.

Covers :meth:`PersonaEngine.chat_stream` and the Starlette endpoint
that wraps it. Every test is hermetic: fakes are injected via
:meth:`ProviderRegistry.register_instance` and the module-level
``_engine`` is temporarily swapped when the HTTP surface is under
test. No real LLM endpoint is ever contacted.

The tests deliberately live alongside ``test_subagent.py`` and reuse
the same streaming-fake shape so cross-test mental load stays low.
"""

from __future__ import annotations

import asyncio
import json
from collections.abc import AsyncIterator
from pathlib import Path
from typing import Any

import pytest
from starlette.testclient import TestClient

from concinno.cache import AppendOnlyLog
from persona import api as api_module
from persona.api import create_standalone_app
from persona.engine import PersonaEngine
from persona.loader import parse_persona_text
from persona.providers import (
    ModelPolicy,
    ProviderError,
    ProviderRegistry,
)


# ─────────────────── Fakes ───────────────────


class _StreamingFakeProvider:
    """Async double matching :class:`LLMProvider` Protocol.

    ``stream_chunks`` controls the streamed deltas. ``stream_error``
    raises *after* the queued chunks are yielded so we can exercise
    mid-stream failure paths with a deterministic partial buffer.
    """

    name = "fake"

    def __init__(
        self,
        reply: str = "fake-reply",
        stream_chunks: list[str] | None = None,
        stream_error: ProviderError | None = None,
    ) -> None:
        self.reply = reply
        self.stream_chunks = stream_chunks
        self.stream_error = stream_error
        self.generate_calls: list[
            tuple[list[dict[str, str]], ModelPolicy]
        ] = []
        self.stream_calls: list[
            tuple[list[dict[str, str]], ModelPolicy]
        ] = []

    async def generate(
        self,
        messages: list[dict[str, str]],
        policy: ModelPolicy,
    ) -> str:
        self.generate_calls.append((list(messages), policy))
        return self.reply

    async def generate_stream(
        self,
        messages: list[dict[str, str]],
        policy: ModelPolicy,
    ) -> AsyncIterator[str]:
        self.stream_calls.append((list(messages), policy))
        chunks = (
            self.stream_chunks
            if self.stream_chunks is not None
            else [self.reply]
        )
        for c in chunks:
            yield c
        if self.stream_error is not None:
            raise self.stream_error


def _make_registry(provider: _StreamingFakeProvider) -> ProviderRegistry:
    reg = ProviderRegistry()
    reg.register_instance("fake", provider)
    # Ollama default fallback in chat_stream — register the same
    # fake under that name too so a no-policy test still lands on
    # our fake without a registry miss.
    reg.register_instance("ollama", provider)
    return reg


def _make_persona() -> Any:
    return parse_persona_text(
        "You are Ada, a 30 year old curious engineer from London.",
    )


async def _drain_stream(
    ait: AsyncIterator[str],
) -> list[str]:
    """Collect every chunk from an async iterator."""
    chunks: list[str] = []
    async for c in ait:
        chunks.append(c)
    return chunks


# ─────────────────── Engine-level streaming ───────────────────


@pytest.mark.asyncio
async def test_chat_stream_yields_chunks_and_commits_history() -> None:
    """Caller sees each provider chunk verbatim + ctx absorbs joined."""
    chunks = ["Hello ", "there, ", "traveller"]
    fake = _StreamingFakeProvider(stream_chunks=chunks)
    engine = PersonaEngine(provider_registry=_make_registry(fake))

    persona = _make_persona()
    received = await _drain_stream(
        engine.chat_stream(
            context_id="t1",
            persona=persona,
            user_message="hi",
            model_policy=ModelPolicy(
                provider="fake", model="m1",
            ),
        ),
    )

    assert received == chunks
    # History absorbed the joined response.
    ctx = engine.get_or_create_context("t1", persona)
    assert ctx.messages[-1] == {
        "role": "assistant", "content": "Hello there, traveller",
    }
    # Only the streaming path hit the provider — no non-stream call.
    assert len(fake.stream_calls) == 1
    assert fake.generate_calls == []


@pytest.mark.asyncio
async def test_chat_stream_rag_feedback_fires(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """RAG-enabled route: feedback() runs with the real hits after stream."""
    fake = _StreamingFakeProvider(stream_chunks=["one ", "two"])
    engine = PersonaEngine(provider_registry=_make_registry(fake))

    hits = [
        {
            "text": "Ada once debugged a steam engine.",
            "file": "memory/persona/ada.md",
            "source_type": "persona_memory",
            "score": 0.9,
        },
        {
            "text": "Ada's favourite tool is curiosity.",
            "file": "kb/traits/curiosity.md",
            "source_type": "kb_trait",
            "score": 0.75,
        },
    ]

    class _FakeRAG:
        def __init__(self) -> None:
            self.search_calls: list[tuple[str, int]] = []
            self.feedback_calls: list[list[dict]] = []

        def search(self, query: str, top_k: int = 3) -> list[dict]:
            self.search_calls.append((query, top_k))
            return list(hits)

        def feedback(self, used: list[dict]) -> None:
            self.feedback_calls.append(used)

    fake_rag = _FakeRAG()
    # Force the lazy RAG slot so the engine skips the real init.
    engine._rag = fake_rag  # type: ignore[assignment]

    # Pin the router so use_rag is True regardless of heuristics.
    from persona import engine as engine_mod

    def _force_rag(_msg: str, _turn: int) -> Any:
        class _R:
            use_rag = True
        return _R()

    monkeypatch.setattr(engine_mod, "route_persona_query", _force_rag)

    received = await _drain_stream(
        engine.chat_stream(
            context_id="rag-ctx",
            persona=_make_persona(),
            user_message="tell me about ada",
            model_policy=ModelPolicy(provider="fake", model="m1"),
        ),
    )

    assert received == ["one ", "two"]
    assert fake_rag.search_calls
    assert fake_rag.feedback_calls == [hits]

    # The system prompt on the wire carries the injected RAG context.
    sent_messages, _ = fake.stream_calls[0]
    assert "[Retrieved Persona Context]" in sent_messages[0]["content"]
    assert "steam engine" in sent_messages[0]["content"]


@pytest.mark.asyncio
async def test_chat_stream_provider_error_propagates() -> None:
    """Mid-stream failure: partial captured + ProviderError re-raised."""
    fake = _StreamingFakeProvider(
        stream_chunks=["part-a ", "part-b"],
        stream_error=ProviderError("fake", "network dropped"),
    )
    engine = PersonaEngine(provider_registry=_make_registry(fake))

    persona = _make_persona()
    partial: list[str] = []
    with pytest.raises(ProviderError) as ei:
        async for chunk in engine.chat_stream(
            context_id="err-ctx",
            persona=persona,
            user_message="hello",
            model_policy=ModelPolicy(provider="fake", model="m1"),
        ):
            partial.append(chunk)

    assert partial == ["part-a ", "part-b"]
    assert ei.value.provider == "fake"
    assert "dropped" in ei.value.detail
    # Partial response committed so the turn is not silently lost.
    ctx = engine.get_or_create_context("err-ctx", persona)
    assert ctx.messages[-1] == {
        "role": "assistant", "content": "part-a part-b",
    }


@pytest.mark.asyncio
async def test_chat_stream_logs_start_end_with_causal_chain(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch,
) -> None:
    """AppendOnlyLog receives start → end with parent chain preserved."""
    log_dir = tmp_path / "append_log"
    monkeypatch.setenv("CCC_APPEND_LOG_DIR", str(log_dir))

    fake = _StreamingFakeProvider(stream_chunks=["alpha ", "beta"])
    engine = PersonaEngine(provider_registry=_make_registry(fake))

    await _drain_stream(
        engine.chat_stream(
            context_id="log-session",
            persona=_make_persona(),
            user_message="hi",
            model_policy=ModelPolicy(provider="fake", model="m1"),
        ),
    )

    log = AppendOnlyLog(log_dir=log_dir)
    events = log.read_session("log-session")
    types = [e.event_type for e in events]
    assert "llm_call_start" in types
    assert "llm_call_end" in types

    start_ev = next(e for e in events if e.event_type == "llm_call_start")
    end_ev = next(e for e in events if e.event_type == "llm_call_end")
    assert start_ev.payload["streaming"] is True
    assert end_ev.payload["streaming"] is True
    assert end_ev.parent_event_id == start_ev.event_id
    assert end_ev.payload["response_length"] == len("alpha beta")


@pytest.mark.asyncio
async def test_chat_stream_logs_error_event_on_failure(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Failure path still writes llm_call_error with parent chain."""
    log_dir = tmp_path / "append_log"
    monkeypatch.setenv("CCC_APPEND_LOG_DIR", str(log_dir))

    fake = _StreamingFakeProvider(
        stream_chunks=["only-chunk"],
        stream_error=ProviderError("fake", "boom"),
    )
    engine = PersonaEngine(provider_registry=_make_registry(fake))

    with pytest.raises(ProviderError):
        async for _ in engine.chat_stream(
            context_id="err-log-session",
            persona=_make_persona(),
            user_message="hi",
            model_policy=ModelPolicy(provider="fake", model="m1"),
        ):
            pass

    log = AppendOnlyLog(log_dir=log_dir)
    events = log.read_session("err-log-session")
    types = [e.event_type for e in events]
    assert "llm_call_start" in types
    assert "llm_call_error" in types
    err_ev = next(e for e in events if e.event_type == "llm_call_error")
    assert "boom" in err_ev.payload["error"]
    assert err_ev.payload["streaming"] is True
    start_ev = next(e for e in events if e.event_type == "llm_call_start")
    assert err_ev.parent_event_id == start_ev.event_id


# ─────────────────── HTTP endpoint ───────────────────


def _parse_sse_frames(raw: bytes) -> list[dict]:
    """Parse raw SSE bytes into a list of decoded frame dicts.

    One frame = one ``data: {json}\\n\\n`` block. Anything that
    doesn't JSON-parse is skipped so a stray keepalive line would
    not blow the test — we explicitly assert frame content below.
    """
    out: list[dict] = []
    text = raw.decode("utf-8")
    for block in text.split("\n\n"):
        block = block.strip()
        if not block or not block.startswith("data:"):
            continue
        body = block[len("data:"):].strip()
        try:
            out.append(json.loads(body))
        except ValueError:
            continue
    return out


@pytest.fixture()
def streaming_client() -> TestClient:
    """HTTP test client with engine swapped for a streaming fake."""
    fake = _StreamingFakeProvider(
        stream_chunks=["sse-A ", "sse-B ", "sse-C"],
    )
    engine = PersonaEngine(provider_registry=_make_registry(fake))
    orig_engine = api_module._engine
    api_module._engine = engine  # type: ignore[assignment]
    try:
        yield TestClient(create_standalone_app())
    finally:
        api_module._engine = orig_engine  # type: ignore[assignment]


@pytest.fixture()
def streaming_error_client() -> TestClient:
    """HTTP test client whose provider raises mid-stream."""
    fake = _StreamingFakeProvider(
        stream_chunks=["prefix-"],
        stream_error=ProviderError("fake", "upstream sad"),
    )
    engine = PersonaEngine(provider_registry=_make_registry(fake))
    orig_engine = api_module._engine
    api_module._engine = engine  # type: ignore[assignment]
    try:
        yield TestClient(create_standalone_app())
    finally:
        api_module._engine = orig_engine  # type: ignore[assignment]


def test_http_chat_stream_emits_text_and_done_frames(
    streaming_client: TestClient,
) -> None:
    """SSE wire format: one ``text`` frame per chunk + ``done`` terminator."""
    body = {
        "message": "hello streaming world",
        "context_id": "http-ctx",
        "persona_id": "ada",
        "persona_text": (
            "You are Ada, a 30 year old curious engineer from London."
        ),
        "model_policy": {"provider": "fake", "model": "m1"},
    }
    resp = streaming_client.post("/v1/chat/stream", json=body)
    assert resp.status_code == 200
    assert resp.headers["content-type"].startswith("text/event-stream")

    frames = _parse_sse_frames(resp.content)
    text_frames = [f for f in frames if "text" in f and "type" not in f]
    done_frames = [f for f in frames if f.get("type") == "done"]
    assert [f["text"] for f in text_frames] == [
        "sse-A ", "sse-B ", "sse-C",
    ]
    assert len(done_frames) == 1
    assert done_frames[0]["total_tokens"] == len("sse-A sse-B sse-C")


def test_http_chat_stream_provider_error_frame(
    streaming_error_client: TestClient,
) -> None:
    """Mid-stream failure flushes partial + ``error`` frame + 200 status."""
    body = {
        "message": "hello",
        "context_id": "err-http",
        "persona_id": "ada",
        "persona_text": (
            "You are Ada, a 30 year old curious engineer from London."
        ),
        "model_policy": {"provider": "fake", "model": "m1"},
    }
    resp = streaming_error_client.post("/v1/chat/stream", json=body)
    # SSE convention: transport-level errors come through as frames,
    # the HTTP response itself is still 200.
    assert resp.status_code == 200
    frames = _parse_sse_frames(resp.content)

    text_frames = [f for f in frames if "text" in f and "type" not in f]
    error_frames = [f for f in frames if f.get("type") == "error"]
    assert text_frames == [{"text": "prefix-"}]
    assert len(error_frames) == 1
    assert error_frames[0]["provider"] == "fake"
    assert "upstream sad" in error_frames[0]["detail"]


def test_http_chat_stream_respects_model_policy(
    streaming_client: TestClient,
) -> None:
    """Explicit ``model_policy`` body drives the provider choice."""
    body = {
        "message": "hi",
        "context_id": "policy-ctx",
        "persona_id": "ada",
        "persona_text": (
            "You are Ada, a 30 year old curious engineer from London."
        ),
        "model_policy": {
            "provider": "fake",
            "model": "m-custom",
            "temperature": 0.1,
            "max_tokens": 32,
        },
    }
    resp = streaming_client.post("/v1/chat/stream", json=body)
    assert resp.status_code == 200

    # The fake provider recorded the exact policy instance it saw.
    fake_provider = api_module._engine._provider_router.get("fake")  # type: ignore[attr-defined]
    assert fake_provider.stream_calls, "provider was never invoked"
    _, used_policy = fake_provider.stream_calls[-1]
    assert used_policy.provider == "fake"
    assert used_policy.model == "m-custom"
    assert used_policy.temperature == 0.1
    assert used_policy.max_tokens == 32


def test_http_chat_stream_missing_message_returns_400(
    streaming_client: TestClient,
) -> None:
    """Pre-stream validation still surfaces as a real HTTP 400."""
    resp = streaming_client.post("/v1/chat/stream", json={})
    assert resp.status_code == 400
    assert "message" in resp.json()["error"]


def test_http_chat_non_streaming_still_works(
    streaming_client: TestClient,
) -> None:
    """Regression guard: /v1/chat returns a whole JSON blob unchanged."""
    body = {
        "message": "hi",
        "context_id": "regression",
        "persona_id": "ada",
        "persona_text": (
            "You are Ada, a 30 year old curious engineer from London."
        ),
        "model_policy": {"provider": "fake", "model": "m1"},
    }
    resp = streaming_client.post("/v1/chat", json=body)
    assert resp.status_code == 200
    data = resp.json()
    # Non-streaming path goes through _llm_via_provider → fake.generate
    # which returns the static reply, NOT the stream chunks.
    assert data["response"] == "fake-reply"
    assert "track" in data


# Ensure the asyncio fixture is active for sync-only tests too.
@pytest.fixture(autouse=True)
def _close_loops() -> None:
    """Yield a fresh event-loop slot for each test.

    The subagent test suite lets pytest-asyncio drive its own loop.
    We piggy-back on the same pattern: sync HTTP tests live side by
    side with ``@pytest.mark.asyncio`` coroutines without collisions.
    """
    # asyncio module import ensures the symbol is used even if no
    # test in this module explicitly drives a manual loop.
    _ = asyncio.get_event_loop_policy()
    yield
