"""Tests for :mod:`benchmarks.paired_analysis`.

Covers
------
* ``mcnemar_chi2`` — no-discordance degeneracy / symmetric inputs /
  the continuity-correction edge case (|b-c| == 0) / the known worked
  example (b=12, c=4 → chi2=3.0625, p≈0.08) so the math stays honest
  if the closed-form survival function is ever swapped out.
* ``tabulate_paired`` — the four-cell counting and the mismatch guard.
* ``bootstrap_paired_ci`` — determinism under a pinned ``seed``,
  shape sanity (ci_low <= mean_delta <= ci_high), empty-input
  handling, and the width-shrinks-with-N sanity check.
* ``format_paired_summary`` — returns a non-empty multi-line string
  covering both McNemar and bootstrap so runners can paste it
  verbatim.
"""

from __future__ import annotations

import math
import sys
from pathlib import Path

import pytest

# Runner lives under ``benchmarks/`` which is not a package — add
# to path so ``import paired_analysis`` works in the test.
_BENCH_DIR = Path(__file__).resolve().parent.parent / "benchmarks"
if str(_BENCH_DIR) not in sys.path:
    sys.path.insert(0, str(_BENCH_DIR))

import paired_analysis as pa  # noqa: E402


# ── McNemar ────────────────────────────────────────────


def test_mcnemar_zero_discordance_returns_p_one() -> None:
    """No discordant pairs -> chi2=0, p=1 (identical agents)."""
    result = pa.mcnemar_chi2(b=0, c=0)
    assert result.chi2 == 0.0
    assert result.p_value == 1.0


def test_mcnemar_equal_discordance_after_correction_is_zero() -> None:
    """b == c — after Yates' ``-1`` the diff goes negative; clamp to 0."""
    result = pa.mcnemar_chi2(b=5, c=5)
    assert result.chi2 == 0.0
    assert result.p_value == 1.0


def test_mcnemar_known_worked_example() -> None:
    """b=12, c=4 -> chi2 = (|8|-1)^2 / 16 = 49/16 = 3.0625."""
    result = pa.mcnemar_chi2(b=12, c=4)
    assert math.isclose(result.chi2, 3.0625, rel_tol=1e-9)
    # Two-sided p via erfc(sqrt(3.0625 / 2)) ~= 0.0801
    assert 0.07 < result.p_value < 0.09


def test_mcnemar_highly_significant_when_one_sided() -> None:
    """b=20, c=0 -> chi2 = 361/20 ~= 18.05, p well under 0.001."""
    result = pa.mcnemar_chi2(b=20, c=0)
    assert result.chi2 > 18
    assert result.p_value < 0.001


def test_mcnemar_rejects_negative_counts() -> None:
    with pytest.raises(ValueError):
        pa.mcnemar_chi2(b=-1, c=5)
    with pytest.raises(ValueError):
        pa.mcnemar_chi2(b=3, c=-2)


# ── tabulate_paired ───────────────────────────────────


def test_tabulate_paired_counts_four_cells() -> None:
    variant = [True, True, False, False, True]
    baseline = [True, False, True, False, False]
    both, v_only, b_only, neither = pa.tabulate_paired(variant, baseline)
    assert (both, v_only, b_only, neither) == (1, 2, 1, 1)


def test_tabulate_paired_rejects_mismatched_lengths() -> None:
    with pytest.raises(ValueError):
        pa.tabulate_paired([True, False], [True])


def test_tabulate_paired_handles_empty() -> None:
    assert pa.tabulate_paired([], []) == (0, 0, 0, 0)


# ── Bootstrap ─────────────────────────────────────────


def test_bootstrap_deterministic_under_fixed_seed() -> None:
    variant = [True] * 10 + [False] * 10
    baseline = [True] * 5 + [False] * 15
    a = pa.bootstrap_paired_ci(variant, baseline, n_iter=500, seed=7)
    b = pa.bootstrap_paired_ci(variant, baseline, n_iter=500, seed=7)
    assert a == b


def test_bootstrap_different_seeds_usually_disagree() -> None:
    """Sanity: unseeded / different-seed runs should diverge on N=200.

    Not a strict guarantee (two seeds can collide), but at N_iter=200
    the chance of byte-for-byte equality with seeds 1 vs 2 is
    astronomically small. If this ever flakes, pick larger seeds.
    """
    variant = [True, False] * 25
    baseline = [False, True] * 25
    a = pa.bootstrap_paired_ci(variant, baseline, n_iter=200, seed=1)
    b = pa.bootstrap_paired_ci(variant, baseline, n_iter=200, seed=2)
    assert a != b


def test_bootstrap_mean_delta_matches_raw_accuracy_diff() -> None:
    variant = [True] * 15 + [False] * 5
    baseline = [True] * 10 + [False] * 10
    ci = pa.bootstrap_paired_ci(variant, baseline, n_iter=300, seed=0)
    # 15/20 vs 10/20 -> 0.75 - 0.5 = +0.25
    assert math.isclose(ci.mean_delta, 0.25, rel_tol=1e-9)


def test_bootstrap_ci_brackets_mean_delta() -> None:
    variant = [True] * 12 + [False] * 8
    baseline = [True] * 6 + [False] * 14
    ci = pa.bootstrap_paired_ci(variant, baseline, n_iter=500, seed=3)
    # Empirical mean is deterministic; CI should bracket it at
    # alpha=0.05 for a reasonable N_iter.
    assert ci.ci_low <= ci.mean_delta <= ci.ci_high


def test_bootstrap_empty_inputs_return_zeroes() -> None:
    ci = pa.bootstrap_paired_ci([], [], n_iter=100, seed=0)
    assert ci.mean_delta == 0.0
    assert ci.ci_low == 0.0
    assert ci.ci_high == 0.0
    assert ci.n_iter == 100


def test_bootstrap_rejects_mismatched_lengths() -> None:
    with pytest.raises(ValueError):
        pa.bootstrap_paired_ci([True], [True, False], n_iter=10, seed=0)


def test_bootstrap_rejects_bad_iter_and_alpha() -> None:
    v = [True, False]
    b = [False, True]
    with pytest.raises(ValueError):
        pa.bootstrap_paired_ci(v, b, n_iter=0, seed=0)
    with pytest.raises(ValueError):
        pa.bootstrap_paired_ci(v, b, n_iter=10, alpha=0.0, seed=0)
    with pytest.raises(ValueError):
        pa.bootstrap_paired_ci(v, b, n_iter=10, alpha=1.0, seed=0)


# ── format_paired_summary ─────────────────────────────


def test_format_paired_summary_mentions_both_tests() -> None:
    variant = [True, True, False, True, False]
    baseline = [False, True, False, False, True]
    out = pa.format_paired_summary(
        variant, baseline, n_iter=300, seed=11,
    )
    assert "McNemar" in out
    assert "bootstrap" in out.lower()
    assert "delta:" in out
    # 4-cell line echoes the counting so reviewers can sanity-check.
    assert "4-cell" in out


# ── gaia_sancio_runner._print_paired_analysis integration ─


def test_runner_paired_analysis_aligns_on_task_id(
    tmp_path: Path, capsys: pytest.CaptureFixture[str],
) -> None:
    """``_print_paired_analysis`` pairs by task_id, drops non-overlap.

    Guards the runner against the classic benchmark footgun where a
    stale baseline inflates the variant delta because the two runs
    scored different items.
    """
    import importlib.util

    runner_path = (
        Path(__file__).resolve().parent.parent
        / "benchmarks"
        / "gaia_sancio_runner.py"
    )
    spec = importlib.util.spec_from_file_location(
        "gaia_sancio_runner", runner_path,
    )
    assert spec is not None
    assert spec.loader is not None
    runner_mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(runner_mod)

    variant = [
        {"task_id": "t1", "correct": True},
        {"task_id": "t2", "correct": True},
        {"task_id": "t3", "correct": False},
        {"task_id": "t4", "correct": True},   # missing in baseline
    ]
    baseline = [
        {"task_id": "t1", "correct": False},
        {"task_id": "t2", "correct": True},
        {"task_id": "t3", "correct": True},
        {"task_id": "t9", "correct": True},   # missing in variant (ignored)
    ]
    baseline_path = tmp_path / "baseline.json"
    import json as _json
    baseline_path.write_text(_json.dumps(baseline), encoding="utf-8")

    runner_mod._print_paired_analysis(
        variant, baseline_path, analysis_seed=0,
    )
    out = capsys.readouterr().out

    # Missing-from-baseline notice mentions t4 (dropped)
    assert "t4" in out
    # Summary block is present.
    assert "McNemar" in out
    # N=3 aligned tasks (t1 / t2 / t3) — runner prints "N=3".
    assert "N=3" in out


def test_runner_paired_analysis_handles_bad_baseline(
    tmp_path: Path, capsys: pytest.CaptureFixture[str],
) -> None:
    """Non-list / unreadable baseline degrades to a printed warning."""
    import importlib.util

    runner_path = (
        Path(__file__).resolve().parent.parent
        / "benchmarks"
        / "gaia_sancio_runner.py"
    )
    spec = importlib.util.spec_from_file_location(
        "gaia_sancio_runner_bad", runner_path,
    )
    assert spec is not None
    assert spec.loader is not None
    runner_mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(runner_mod)

    import json as _json
    bogus = tmp_path / "bogus.json"
    bogus.write_text(_json.dumps({"not": "a list"}), encoding="utf-8")

    runner_mod._print_paired_analysis(
        [{"task_id": "t1", "correct": True}], bogus, analysis_seed=0,
    )
    out = capsys.readouterr().out
    assert "not a list" in out


# ── gaia_sancio_runner guidance ablation (P0#6(a), 2026-04-18) ─


def _load_runner_module(label: str = "gaia_sancio_runner_guidance"):
    """Load ``gaia_sancio_runner`` via ``importlib`` — benchmarks is
    not an importable package so every test that needs the module
    pays the spec_from_file_location ceremony."""
    import importlib.util

    runner_path = (
        Path(__file__).resolve().parent.parent
        / "benchmarks"
        / "gaia_sancio_runner.py"
    )
    spec = importlib.util.spec_from_file_location(label, runner_path)
    assert spec is not None
    assert spec.loader is not None
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def test_guidance_choices_declares_v1_and_compute_tools() -> None:
    """Public tuple acts as the single source of truth for the CLI
    choices list and the ``run`` / ``_build_system_suffix`` guard."""
    runner_mod = _load_runner_module("gaia_sancio_runner_choices")
    assert runner_mod.GUIDANCE_CHOICES == (
        "v1",
        "compute_tools",
        "v1_phase1",
        "v2_anchor",
    )


def test_build_system_suffix_v1_phase1_adds_search_and_quote() -> None:
    """``v1_phase1`` layers SEARCH_DISCIPLINE + EXACT_QUOTE on top of
    v1 (keeps ARITHMETIC, not COMPUTE_TOOLS). Both phase-1 blocks
    must appear in full so the B/C/G/I FAIL classes surface their
    targeted discipline to the model."""
    from concinno.agent import (
        AGENT_GUIDANCE_ARITHMETIC,
        AGENT_GUIDANCE_COMPUTE_TOOLS,
        AGENT_GUIDANCE_EXACT_QUOTE,
        AGENT_GUIDANCE_SEARCH_DISCIPLINE,
        AGENT_GUIDANCE_UNCERTAINTY,
    )

    runner_mod = _load_runner_module("gaia_sancio_runner_phase1")
    s = runner_mod.SYSTEM_SUFFIX_V1_PHASE1
    assert AGENT_GUIDANCE_UNCERTAINTY in s
    assert AGENT_GUIDANCE_ARITHMETIC in s
    assert AGENT_GUIDANCE_SEARCH_DISCIPLINE in s
    assert AGENT_GUIDANCE_EXACT_QUOTE in s
    # compute_tools branch stays disjoint from phase1.
    assert AGENT_GUIDANCE_COMPUTE_TOOLS not in s
    assert "FINAL ANSWER" in s


def test_build_system_suffix_v1_matches_legacy_constant() -> None:
    """``v1`` branch must stay byte-identical to the module-level
    ``SYSTEM_SUFFIX`` — paired-seed McNemar against the 9/20 = 45%
    2026-04-17 baseline only makes sense if the baseline suffix
    string did not drift under us."""
    runner_mod = _load_runner_module("gaia_sancio_runner_v1")
    assert runner_mod._build_system_suffix("v1") == runner_mod.SYSTEM_SUFFIX


def test_build_system_suffix_compute_tools_swaps_arithmetic() -> None:
    """``compute_tools`` drops ARITHMETIC's run_bash recipe for the
    date_calc / python_exec few-shot. Gemma 4 ignored schema-only
    tool descriptions (N=20 Δ=0 pilot), so we assert the concrete
    invocation shapes are present for the weak model to copy."""
    from concinno.agent import AGENT_GUIDANCE_ARITHMETIC

    runner_mod = _load_runner_module("gaia_sancio_runner_ct")
    s = runner_mod.SYSTEM_SUFFIX_COMPUTE_TOOLS
    # Few-shot examples the weak model can pattern-match against.
    assert "date_calc" in s
    assert 'op="delta"' in s
    assert "python_exec" in s
    assert 'code="sum(' in s
    # ARITHMETIC's full run_bash recipe is NOT embedded — the
    # compute_tools branch contrasts against it ("rather than
    # run_bash") but must not re-seed the bash habit Gemma already
    # defaults to.
    assert AGENT_GUIDANCE_ARITHMETIC not in s
    # The FINAL ANSWER contract is still enforced so scoring stays
    # comparable across both guidance variants.
    assert "FINAL ANSWER" in s


def test_build_system_suffix_rejects_unknown_label() -> None:
    runner_mod = _load_runner_module("gaia_sancio_runner_bad_label")
    with pytest.raises(ValueError, match="unknown guidance"):
        runner_mod._build_system_suffix("v99")


def test_build_user_message_routes_suffix_override() -> None:
    """The keyword-only ``suffix`` override threads through to the
    emitted user message. Regression-guards the per-task loop in
    ``run`` that now passes ``suffix=<chosen>`` every iteration."""
    runner_mod = _load_runner_module("gaia_sancio_runner_msg")
    msg_v1 = runner_mod._build_user_message("Q?", None)
    msg_ct = runner_mod._build_user_message(
        "Q?", None, suffix=runner_mod.SYSTEM_SUFFIX_COMPUTE_TOOLS,
    )
    assert msg_v1.endswith(runner_mod.SYSTEM_SUFFIX)
    assert msg_ct.endswith(runner_mod.SYSTEM_SUFFIX_COMPUTE_TOOLS)
    assert msg_v1 != msg_ct


def test_build_system_suffix_v2_anchor_falls_back_to_v1_statically() -> None:
    """``v2_anchor`` composes per-question at runtime. The static
    ``_build_system_suffix('v2_anchor')`` fallback therefore returns
    the v1 base blocks (so any code path that happens to read a
    static suffix still works), with the anchor-specific blocks
    added only via ``_build_system_suffix_targeted(question)``."""
    from concinno.agent import (
        AGENT_GUIDANCE_ARITHMETIC,
        AGENT_GUIDANCE_EXACT_QUOTE,
        AGENT_GUIDANCE_EXACT_UNIT,
        AGENT_GUIDANCE_FACTUAL_COUNT,
        AGENT_GUIDANCE_UNCERTAINTY,
    )

    runner_mod = _load_runner_module("gaia_sancio_runner_v2_static")
    s = runner_mod._build_system_suffix("v2_anchor")
    assert AGENT_GUIDANCE_UNCERTAINTY in s
    assert AGENT_GUIDANCE_ARITHMETIC in s
    # Anchor blocks are NOT attached to the static form — that's by
    # design, they come from the per-question composer.
    assert AGENT_GUIDANCE_EXACT_UNIT not in s
    assert AGENT_GUIDANCE_EXACT_QUOTE not in s
    assert AGENT_GUIDANCE_FACTUAL_COUNT not in s
    assert "FINAL ANSWER" in s


def test_build_system_suffix_targeted_emits_v1_for_plain_question() -> None:
    """A question matching no anchor regex must receive exactly the
    v1 base + FINAL ANSWER envelope. This is the key no-regression
    invariant: paired-seed comparison on plain questions is a
    true no-op control."""
    from concinno.agent import (
        AGENT_GUIDANCE_EXACT_QUOTE,
        AGENT_GUIDANCE_EXACT_UNIT,
        AGENT_GUIDANCE_FACTUAL_COUNT,
    )

    runner_mod = _load_runner_module("gaia_sancio_runner_v2_plain")
    s = runner_mod._build_system_suffix_targeted(
        "What is the capital of France?",
    )
    # No anchor should be injected for a plain factual-single question
    assert AGENT_GUIDANCE_EXACT_UNIT not in s
    assert AGENT_GUIDANCE_EXACT_QUOTE not in s
    assert AGENT_GUIDANCE_FACTUAL_COUNT not in s
    assert "FINAL ANSWER" in s


def test_build_system_suffix_targeted_unit_question_injects_unit() -> None:
    """#12 layer 2 regression guard — unit-format questions must
    pick up the EXACT_UNIT block."""
    from concinno.agent import AGENT_GUIDANCE_EXACT_UNIT

    runner_mod = _load_runner_module("gaia_sancio_runner_v2_unit")
    s = runner_mod._build_system_suffix_targeted(
        "Report the distance in Angstroms, rounded to the nearest "
        "picometer.",
    )
    assert AGENT_GUIDANCE_EXACT_UNIT in s


def test_build_system_suffix_targeted_quote_question_injects_quote() -> None:
    """#15 regression guard — quote questions must pick up the
    EXACT_QUOTE block. Note that the block itself was already in
    the module but v1_phase1 appended it globally (prompt bloat).
    v2_anchor only appends when the question actually demands a
    verbatim quote."""
    from concinno.agent import AGENT_GUIDANCE_EXACT_QUOTE

    runner_mod = _load_runner_module("gaia_sancio_runner_v2_quote")
    s = runner_mod._build_system_suffix_targeted(
        "What's the last line of the rhyme on the headstone?",
    )
    assert AGENT_GUIDANCE_EXACT_QUOTE in s


def test_build_system_suffix_targeted_count_injects_factual_count() -> None:
    """#3 regression guard — 'how many' questions depending on real
    data must pick up the FACTUAL_COUNT block so the model searches
    a primary source instead of inventing a number."""
    from concinno.agent import AGENT_GUIDANCE_FACTUAL_COUNT

    runner_mod = _load_runner_module("gaia_sancio_runner_v2_count")
    s = runner_mod._build_system_suffix_targeted(
        "How many articles were published by Nature in 2020?",
    )
    assert AGENT_GUIDANCE_FACTUAL_COUNT in s


def test_cli_guidance_flag_is_parseable() -> None:
    """``argparse`` wires ``--guidance`` with choices from
    ``GUIDANCE_CHOICES`` so a typo like ``--guidance v2`` is rejected
    before a 20-question run burns real tokens."""
    import argparse as _argparse

    runner_mod = _load_runner_module("gaia_sancio_runner_cli")

    # main() calls parse_args then run(); we only want the former,
    # so we rebuild the parser fragment here to avoid the HTTP side.
    ap = _argparse.ArgumentParser()
    ap.add_argument(
        "--guidance",
        choices=list(runner_mod.GUIDANCE_CHOICES),
        default="v1",
    )
    assert ap.parse_args([]).guidance == "v1"
    assert ap.parse_args(
        ["--guidance", "compute_tools"],
    ).guidance == "compute_tools"
    with pytest.raises(SystemExit):
        ap.parse_args(["--guidance", "bogus"])
