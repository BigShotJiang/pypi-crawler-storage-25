"""Tests for ``persona.tools.web_search.WebSearchTool``.

The Anthropic SDK is a heavy optional dependency; we mock the
client object entirely. The tool only cares about
``client.messages.create(...)`` existing and returning a response
whose ``content`` is an iterable of objects with ``.text`` attrs.

Contract under test:

* Happy path returns concatenated ``.text`` blocks trimmed to cap.
* Empty result yields the ``[empty search result]`` sentinel.
* SDK exceptions are caught and surfaced as ``"error: ..."``.
* Missing ``query`` returns an argument-error string.
* ``messages.create`` is called with the expected model / tools
  shape (regression lock for the SDK arg schema).
"""

from __future__ import annotations

from types import SimpleNamespace
from typing import Any

import pytest

from persona.tools.web_search import WebSearchTool


class _FakeMessages:
    """Stand-in for ``anthropic.Anthropic().messages`` that records calls."""

    def __init__(self, response: Any, raise_exc: Exception | None = None):
        self._response = response
        self._raise = raise_exc
        self.last_kwargs: dict[str, Any] | None = None

    def create(self, **kwargs: Any) -> Any:
        self.last_kwargs = kwargs
        if self._raise is not None:
            raise self._raise
        return self._response


class _FakeClient:
    def __init__(self, response: Any, raise_exc: Exception | None = None):
        self.messages = _FakeMessages(response, raise_exc)


def _text_block(text: str) -> Any:
    return SimpleNamespace(text=text)


# ─────────────────── happy path ───────────────────


@pytest.mark.asyncio
async def test_web_search_returns_joined_text() -> None:
    response = SimpleNamespace(
        content=[_text_block("First fact."), _text_block("Second fact.")],
    )
    client = _FakeClient(response)
    tool = WebSearchTool(client=client)

    out = await tool.execute({"query": "who built the Eiffel Tower?"})

    assert "First fact." in out
    assert "Second fact." in out
    # Schema shape matches the function-calling spec.
    assert tool.schema()["function"]["name"] == "web_search"


@pytest.mark.asyncio
async def test_web_search_passes_expected_sdk_shape() -> None:
    """Regression: locks the SDK args so a silent change breaks a test."""
    response = SimpleNamespace(content=[_text_block("ok")])
    client = _FakeClient(response)
    tool = WebSearchTool(
        client=client,
        model="claude-sonnet-4-6",
        max_uses=5,
        max_tokens=1000,
    )

    await tool.execute({"query": "test"})

    kwargs = client.messages.last_kwargs
    assert kwargs is not None
    assert kwargs["model"] == "claude-sonnet-4-6"
    assert kwargs["max_tokens"] == 1000
    tools = kwargs["tools"]
    assert tools[0]["type"] == "web_search_20250305"
    assert tools[0]["max_uses"] == 5
    # Query text must land in the user message.
    msgs = kwargs["messages"]
    assert msgs[0]["role"] == "user"
    assert "test" in msgs[0]["content"]


# ─────────────────── edge cases ───────────────────


@pytest.mark.asyncio
async def test_web_search_empty_content_returns_sentinel() -> None:
    response = SimpleNamespace(content=[])
    client = _FakeClient(response)
    tool = WebSearchTool(client=client)

    out = await tool.execute({"query": "obscure"})

    assert out == "[empty search result]"


@pytest.mark.asyncio
async def test_web_search_missing_query_returns_error() -> None:
    tool = WebSearchTool(client=_FakeClient(SimpleNamespace(content=[])))
    out = await tool.execute({})
    assert out.startswith("error: query is required")


@pytest.mark.asyncio
async def test_web_search_sdk_exception_becomes_error_string() -> None:
    client = _FakeClient(None, raise_exc=RuntimeError("rate limited"))
    tool = WebSearchTool(client=client)

    out = await tool.execute({"query": "anything"})

    assert out.startswith("error: web_search failed")
    assert "rate limited" in out


@pytest.mark.asyncio
async def test_web_search_truncates_long_output() -> None:
    big = "X" * 10000
    response = SimpleNamespace(content=[_text_block(big)])
    client = _FakeClient(response)
    tool = WebSearchTool(client=client, output_cap=500)

    out = await tool.execute({"query": "noise"})

    assert len(out) <= 501
    assert out.endswith("…")
