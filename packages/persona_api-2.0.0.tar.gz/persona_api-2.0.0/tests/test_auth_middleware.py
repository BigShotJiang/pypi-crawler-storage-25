"""P0#1 Task 1 — auth middleware regression tests.

Covers the RCE-surface lockdown: every protected endpoint returns
401 when called without a Bearer token, and the public bootstrap
endpoints (``/v1/health``, ``/v1/auth/login``, ``/v1/a2a/capabilities``)
stay anonymous. The ``SANCIO_REQUIRE_AUTH=0`` kill-switch is also
exercised so operators running the stack in offline test mode can
confirm the gate actually disables.
"""

from __future__ import annotations

from collections.abc import Iterator
from pathlib import Path

import pytest
from starlette.testclient import TestClient

from persona import agent_api, auth
from persona.api import create_standalone_app


@pytest.fixture()
def auth_env(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch,
) -> Path:
    """Fresh DB + deterministic JWT secret + auth required."""
    db = tmp_path / "auth.db"
    monkeypatch.setenv("AUTH_DB_PATH", str(db))
    monkeypatch.setenv("SANCIO_JWT_SECRET", "test-secret-no-prod")
    monkeypatch.setenv("SANCIO_REQUIRE_AUTH", "1")
    # Isolate budget + workspace so the Task 3 hook doesn't 429 us
    # on a shared fixture state from other tests.
    monkeypatch.setenv(
        "SANCIO_BUDGET_DB_PATH", str(tmp_path / "budget.db"),
    )
    monkeypatch.setenv(
        "SANCIO_WORKSPACE_ROOT", str(tmp_path / "workspace"),
    )
    monkeypatch.setenv("SANCIO_BUDGET_DAILY_USD", "9999")
    monkeypatch.setenv("SANCIO_BUDGET_MONTHLY_USD", "99999")
    return db


@pytest.fixture()
def client(auth_env: Path) -> Iterator[TestClient]:
    """Standalone Sancio app with the full middleware stack."""
    app = create_standalone_app()
    with TestClient(app) as c:
        yield c
    agent_api.reset_llm_call()


@pytest.fixture()
def bearer_token(client: TestClient) -> str:
    """Create the canonical user and return a live JWT."""
    auth.create_user("p0user", "p0password")
    r = client.post(
        "/v1/auth/login",
        json={"username": "p0user", "password": "p0password"},
    )
    assert r.status_code == 200, r.text
    return str(r.json()["token"])


# ── Protected endpoints reject missing Bearer ────

PROTECTED_CASES = [
    # (method, path, body)
    ("POST", "/v1/agent/run", {
        "stack": "sancio",
        "messages": [{"role": "user", "content": "hi"}],
        "model": "anthropic:claude-sonnet-4-6",
    }),
    ("POST", "/v1/chat", {"message": "hi"}),
    ("POST", "/v1/chat/stream", {"message": "hi"}),
    ("POST", "/v1/cerno/cycle", {
        "intent": "t", "child_id": "c", "child_output": "o",
    }),
    ("POST", "/v1/subagent/spawn", {
        "system_prompt": "x",
        "user_messages": [{"role": "user", "content": "x"}],
        "policy": {"provider": "ollama", "model": "gemma4:latest"},
    }),
    ("POST", "/v1/load", {"persona_id": "p", "persona_text": "name: x"}),
    ("POST", "/v1/a2a/invoke", {}),
]


@pytest.mark.parametrize("method,path,body", PROTECTED_CASES)
def test_protected_endpoint_rejects_missing_bearer(
    client: TestClient, method: str, path: str, body: dict,
) -> None:
    """Every P0 endpoint returns 401 without Authorization header."""
    r = client.request(method, path, json=body)
    assert r.status_code == 401, (path, r.text)
    data = r.json()
    assert data.get("error") == "unauthorized"


@pytest.mark.parametrize("method,path,body", PROTECTED_CASES)
def test_protected_endpoint_rejects_malformed_bearer(
    client: TestClient, method: str, path: str, body: dict,
) -> None:
    """Garbage token → 401, not 500."""
    r = client.request(
        method, path, json=body,
        headers={"Authorization": "Bearer not-a-real-token"},
    )
    assert r.status_code == 401, (path, r.text)


# ── Public endpoints stay anonymous ──────────────


def test_health_endpoint_is_public(client: TestClient) -> None:
    r = client.get("/v1/health")
    assert r.status_code == 200
    assert r.json()["status"] == "ok"


def test_login_endpoint_is_public(client: TestClient) -> None:
    auth.create_user("public_user", "public_password")
    r = client.post(
        "/v1/auth/login",
        json={"username": "public_user", "password": "public_password"},
    )
    assert r.status_code == 200


def test_a2a_capabilities_is_public(client: TestClient) -> None:
    r = client.get("/v1/a2a/capabilities")
    assert r.status_code == 200


# ── SANCIO_REQUIRE_AUTH=0 disables the gate ──────


def test_require_auth_env_switch_disables_gate(
    auth_env: Path, monkeypatch: pytest.MonkeyPatch,
) -> None:
    """SANCIO_REQUIRE_AUTH=0 lets anonymous callers through."""
    monkeypatch.setenv("SANCIO_REQUIRE_AUTH", "0")
    app = create_standalone_app()
    with TestClient(app) as c:
        # /v1/cerno/cycle still needs a valid body, but auth is off
        # so we should get 200 / 400 (body-shape), NOT 401.
        r = c.post("/v1/cerno/cycle", json={
            "intent": "probe", "child_id": "ch", "child_output": "",
        })
        assert r.status_code != 401, r.text


# ── Valid Bearer is accepted ────────────────────


def test_valid_bearer_passes_gate(
    client: TestClient, bearer_token: str,
) -> None:
    """Authenticated request reaches the endpoint (non-401)."""
    r = client.post(
        "/v1/cerno/cycle",
        json={
            "intent": "probe", "child_id": "ch", "child_output": "",
        },
        headers={"Authorization": f"Bearer {bearer_token}"},
    )
    assert r.status_code != 401, r.text


def test_path_prefix_match_is_exact_or_slash(
    client: TestClient,
) -> None:
    """``/v1/agent/runXXX`` must NOT be gated — only ``/v1/agent/run``
    and its sub-paths."""
    # /v1/agent/runfoo doesn't exist → 404, NOT 401.
    r = client.get("/v1/agent/runfoo")
    assert r.status_code == 404, r.text


def test_unknown_env_value_defaults_to_on(
    auth_env: Path, monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Random SANCIO_REQUIRE_AUTH values keep the gate ON (fail-safe)."""
    monkeypatch.setenv("SANCIO_REQUIRE_AUTH", "maybe")
    app = create_standalone_app()
    with TestClient(app) as c:
        r = c.post("/v1/cerno/cycle", json={})
        # "maybe" is NOT in ("0","false","no","off","") → auth ON
        assert r.status_code == 401


def test_auth_disabled_on_empty_string(
    auth_env: Path, monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Empty SANCIO_REQUIRE_AUTH disables the gate (dev convenience)."""
    monkeypatch.setenv("SANCIO_REQUIRE_AUTH", "")
    app = create_standalone_app()
    with TestClient(app) as c:
        r = c.get("/v1/health")
        assert r.status_code == 200
