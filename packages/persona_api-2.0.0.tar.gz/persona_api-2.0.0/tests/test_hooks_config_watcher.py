"""Tests for :mod:`persona.hooks.config_watcher` (Sancio 2.0.0).

Exercises the 5 contract guarantees called out in the 2026-05-01
alignment plan §4.2 / §5 risk register:

1. File mutation triggers ``reload_callback`` (R1 cross-platform via
   ``tmp_path`` fixture — same test runs on Windows / Linux / macOS).
2. Debounce: rapid mutations coalesce to a single reload.
3. Subscriber blocks -> ``reload_callback`` NOT called.
4. File deletion fires event with ``file_path`` set + source preserved (R6).
5. Watcher stops cleanly within ``STOP_TIMEOUT_S`` (R6 leak prevention).

Cross-platform notes
--------------------
``watchfiles`` propagation latency varies by OS:

* Linux ``inotify``: ~10-50ms after ``write``+``flush``+``fsync``.
* Windows ``ReadDirectoryChangesW``: ~50-300ms typical.
* macOS ``FSEvents``: ~1-3s coalesce window.

We use generous waits (up to 5s) backed by ``asyncio.Event`` + polling
so a slow CI runner does not flake.
"""

from __future__ import annotations

import asyncio
import time
from pathlib import Path

import pytest

from persona.hooks import config_change as cc
from persona.hooks.config_change import (
    ConfigChangeBlocked,
    ConfigChangeEvent,
    register_config_change,
    reset_for_tests,
)
from persona.hooks.config_watcher import (
    STOP_TIMEOUT_S,
    ConfigWatcher,
)

# Mark every async test in this module — watcher is async-first.
pytestmark = pytest.mark.asyncio


@pytest.fixture(autouse=True)
def _reset_registry() -> None:
    reset_for_tests()
    yield
    reset_for_tests()


def _resolver(_p: Path) -> cc.ConfigChangeSource:
    """Default source resolver — every path becomes ``user_settings``."""
    return "user_settings"


async def _await_event(
    flag: asyncio.Event,
    timeout: float = 5.0,
) -> bool:
    """Wait for ``flag`` with ``timeout``. Returns True iff fired."""
    try:
        await asyncio.wait_for(flag.wait(), timeout=timeout)
        return True
    except asyncio.TimeoutError:
        return False


def _touch(path: Path, content: str = "") -> None:
    """Write+flush+fsync so OS notifies the watcher promptly."""
    with open(path, "w", encoding="utf-8") as fh:
        fh.write(content)
        fh.flush()
        try:
            import os

            os.fsync(fh.fileno())
        except OSError:  # pragma: no cover — some FS lack fsync
            pass


# ---------------------------------------------------------------------------
# 1. File mutation triggers reload_callback
# ---------------------------------------------------------------------------


async def test_mutation_triggers_reload(tmp_path: Path) -> None:
    target = tmp_path / "settings.json"
    target.write_text("{}", encoding="utf-8")

    fired = asyncio.Event()
    seen_paths: list[Path] = []

    async def reload_cb(p: Path) -> None:
        seen_paths.append(p)
        fired.set()

    watcher = ConfigWatcher(
        paths=[target],
        reload_callback=reload_cb,
        source_resolver=_resolver,
        debounce_ms=50,
        session_id="s-1",
    )
    await watcher.start()
    try:
        # Give watcher a beat to attach to the FS.
        await asyncio.sleep(0.2)
        _touch(target, '{"v": 2}')
        ok = await _await_event(fired, timeout=5.0)
        assert ok, "reload_callback never fired after file mutation"
        assert len(seen_paths) >= 1
        assert Path(seen_paths[0]).name == "settings.json"
    finally:
        await watcher.stop()


# ---------------------------------------------------------------------------
# 2. Debounce: rapid mutations coalesce
# ---------------------------------------------------------------------------


async def test_debounce_coalesces_rapid_mutations(tmp_path: Path) -> None:
    target = tmp_path / "settings.json"
    target.write_text("{}", encoding="utf-8")

    call_count = 0
    first_fired = asyncio.Event()

    async def reload_cb(_p: Path) -> None:
        nonlocal call_count
        call_count += 1
        first_fired.set()

    # Use a long debounce window so the burst below collapses.
    watcher = ConfigWatcher(
        paths=[target],
        reload_callback=reload_cb,
        source_resolver=_resolver,
        debounce_ms=500,
    )
    await watcher.start()
    try:
        await asyncio.sleep(0.2)
        # 3 rapid mutations within < debounce_ms.
        for i in range(3):
            _touch(target, f'{{"v": {i}}}')
            await asyncio.sleep(0.02)

        # Wait for at least one reload.
        ok = await _await_event(first_fired, timeout=5.0)
        assert ok, "no reload fired at all"

        # Let watchfiles flush its own debounce window before counting.
        await asyncio.sleep(1.0)
        # Without debounce we would expect ~3 calls. With debounce we
        # expect exactly 1 (or at most 2 if a stray late event slips
        # past the window — still strictly less than 3).
        assert call_count <= 2, (
            f"Debounce ineffective: got {call_count} reloads "
            f"for 3 rapid mutations"
        )
    finally:
        await watcher.stop()


# ---------------------------------------------------------------------------
# 3. Subscriber blocks -> reload_callback NOT called
# ---------------------------------------------------------------------------


async def test_subscriber_block_skips_reload(tmp_path: Path) -> None:
    target = tmp_path / "settings.json"
    target.write_text("{}", encoding="utf-8")

    veto_fired = asyncio.Event()
    reload_called = False

    def vetoer(_e: ConfigChangeEvent) -> None:
        veto_fired.set()
        raise ConfigChangeBlocked("schema invalid")

    async def reload_cb(_p: Path) -> None:
        nonlocal reload_called
        reload_called = True

    register_config_change(vetoer, name="vetoer")

    watcher = ConfigWatcher(
        paths=[target],
        reload_callback=reload_cb,
        source_resolver=_resolver,
        debounce_ms=50,
    )
    await watcher.start()
    try:
        await asyncio.sleep(0.2)
        _touch(target, '{"v": 2}')
        ok = await _await_event(veto_fired, timeout=5.0)
        assert ok, "vetoer never saw the event"
        # Give the watcher loop a chance to (incorrectly) call reload.
        await asyncio.sleep(0.5)
        assert reload_called is False, (
            "reload_callback was called despite ConfigChangeBlocked"
        )
    finally:
        await watcher.stop()


# ---------------------------------------------------------------------------
# 4. File deletion fires event with file_path + source preserved (R6)
# ---------------------------------------------------------------------------


async def test_deletion_event_preserves_source(tmp_path: Path) -> None:
    target = tmp_path / "policy.json"
    target.write_text("{}", encoding="utf-8")

    captured: list[ConfigChangeEvent] = []
    fired = asyncio.Event()

    def policy_resolver(p: Path) -> cc.ConfigChangeSource:
        return "policy_settings" if "policy" in p.name else "user_settings"

    def observer(e: ConfigChangeEvent) -> None:
        captured.append(e)
        fired.set()

    register_config_change(observer, name="obs")

    async def reload_cb(_p: Path) -> None:
        return None

    watcher = ConfigWatcher(
        paths=[target],
        reload_callback=reload_cb,
        source_resolver=policy_resolver,
        debounce_ms=50,
    )
    await watcher.start()
    try:
        await asyncio.sleep(0.2)
        target.unlink()
        ok = await _await_event(fired, timeout=5.0)
        assert ok, "deletion event never fired"
        assert any(
            Path(e.file_path).name == "policy.json"
            and e.source == "policy_settings"
            for e in captured
        ), f"deletion event missing path/source: {captured}"
    finally:
        await watcher.stop()


# ---------------------------------------------------------------------------
# 5. Watcher stops cleanly within STOP_TIMEOUT_S (R6 leak)
# ---------------------------------------------------------------------------


async def test_watcher_stops_cleanly(tmp_path: Path) -> None:
    target = tmp_path / "settings.json"
    target.write_text("{}", encoding="utf-8")

    async def reload_cb(_p: Path) -> None:
        return None

    watcher = ConfigWatcher(
        paths=[target],
        reload_callback=reload_cb,
        source_resolver=_resolver,
    )
    await watcher.start()
    assert watcher.is_running

    start_ts = time.monotonic()
    await watcher.stop()
    elapsed = time.monotonic() - start_ts

    assert not watcher.is_running
    # Must complete well under the 2.0s ceiling.
    assert elapsed < STOP_TIMEOUT_S, (
        f"Stop took {elapsed:.2f}s, exceeded STOP_TIMEOUT_S={STOP_TIMEOUT_S}s"
    )
