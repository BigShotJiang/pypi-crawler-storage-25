"""End-to-end tests for /v1/a2a/{capabilities,invoke,status}."""

from __future__ import annotations

import base64
import time
import uuid

import pytest
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import (
    Ed25519PrivateKey,
)
from starlette.applications import Starlette
from starlette.testclient import TestClient

from persona.a2a import create_a2a_routes, reset_singletons_for_tests
from persona.a2a_registry import PeerRecord, PeerRegistry
from persona.a2a_security import issue_jwt, sign_ed25519


def _keypair():
    pk = Ed25519PrivateKey.generate()
    priv_raw = pk.private_bytes(
        serialization.Encoding.Raw,
        serialization.PrivateFormat.Raw,
        serialization.NoEncryption(),
    )
    pub_raw = pk.public_key().public_bytes(
        serialization.Encoding.Raw,
        serialization.PublicFormat.Raw,
    )
    return (
        base64.b64encode(priv_raw).decode("ascii"),
        base64.b64encode(pub_raw).decode("ascii"),
    )


@pytest.fixture()
def setup_a2a(tmp_path, monkeypatch):
    reg_path = tmp_path / "peers.json"
    audit_path = tmp_path / "audit.jsonl"
    caps_path = tmp_path / "caps.yaml"
    limits_path = tmp_path / "limits.yaml"

    caps_path.write_text(
        "capabilities:\n"
        "  - method: capabilities.list\n"
        "  - method: agent.status\n"
        "  - method: agent.invoke\n"
        "    tools: [echo, safety.classify]\n"
        "  - method: tool.delegate\n"
        "    tools: [echo]\n",
        encoding="utf-8",
    )
    limits_path.write_text(
        "default:\n  rpm: 60\n  day_quota: 10000\noverrides: {}\n",
        encoding="utf-8",
    )

    monkeypatch.setenv("AEGIS_A2A_REGISTRY_PATH", str(reg_path))
    monkeypatch.setenv("AEGIS_A2A_AUDIT_PATH", str(audit_path))
    monkeypatch.setenv("AEGIS_A2A_CAPABILITIES_PATH", str(caps_path))
    monkeypatch.setenv("AEGIS_A2A_LIMITS_PATH", str(limits_path))
    monkeypatch.setenv("AEGIS_A2A_AGENT_ID", "aegis.test")
    monkeypatch.setenv("AEGIS_A2A_AUTH_MODE", "jwt")

    reset_singletons_for_tests()

    priv, pub = _keypair()
    reg = PeerRegistry(str(reg_path))
    reg.upsert(PeerRecord(
        agent_id="peer.x", endpoint="https://peer.example",
        public_key_b64=pub,
    ))

    app = Starlette(routes=create_a2a_routes())
    client = TestClient(app)
    yield client, priv, pub

    reset_singletons_for_tests()


def _make_envelope(priv_b64, method="agent.invoke",
                   tool="echo", nonce=None, ts=None, **override):
    env = {
        "id": f"req-{uuid.uuid4()}",
        "from": "peer.x",
        "to": "aegis.test",
        "method": method,
        "params": {"tool": tool, "value": 1},
        "nonce": nonce or str(uuid.uuid4()),
        "timestamp": ts or int(time.time()),
    }
    env.update(override)
    env["signature"] = sign_ed25519(priv_b64, env)
    return env


def test_capabilities_endpoint_public_no_auth(setup_a2a):
    client, _priv, _pub = setup_a2a
    r = client.get("/v1/a2a/capabilities")
    assert r.status_code == 200
    body = r.json()
    assert body["agent_id"] == "aegis.test"
    assert any(c.get("method") == "agent.invoke"
               for c in body["capabilities"])


def test_invoke_happy_path_echo(setup_a2a):
    client, priv, _pub = setup_a2a
    env = _make_envelope(priv, tool="echo")
    token = issue_jwt(priv, issuer="peer.x", audience="aegis.test")
    r = client.post(
        "/v1/a2a/invoke", json=env,
        headers={"Authorization": f"Bearer {token}"},
    )
    assert r.status_code == 200, r.text
    body = r.json()
    assert body["id"] == env["id"]
    assert "invocation_id" in body["result"]
    # The echo handler returns {"echo": merged_params} where
    # ``tool``/``args``/``input`` are stripped. ``value`` passes through.
    assert body["result"]["output"]["echo"].get("value") == 1


def test_invoke_status_roundtrip(setup_a2a):
    client, priv, _pub = setup_a2a
    token = issue_jwt(priv, issuer="peer.x", audience="aegis.test")
    env = _make_envelope(priv, tool="echo")
    r = client.post(
        "/v1/a2a/invoke", json=env,
        headers={"Authorization": f"Bearer {token}"},
    )
    inv_id = r.json()["result"]["invocation_id"]
    status_env = _make_envelope(
        priv, method="agent.status",
    )
    status_env["params"] = {"invocation_id": inv_id}
    status_env["signature"] = sign_ed25519(priv, status_env)
    r2 = client.post(
        "/v1/a2a/status", json=status_env,
        headers={"Authorization": f"Bearer {token}"},
    )
    assert r2.status_code == 200
    assert r2.json()["result"]["status"] == "done"


def test_invoke_unknown_method_400(setup_a2a):
    client, priv, _pub = setup_a2a
    token = issue_jwt(priv, issuer="peer.x", audience="aegis.test")
    env = _make_envelope(priv, method="does.not.exist", tool="echo")
    # Re-sign after method change (already in _make_envelope).
    r = client.post(
        "/v1/a2a/invoke", json=env,
        headers={"Authorization": f"Bearer {token}"},
    )
    # Capability check fires first for unknown methods.
    assert r.status_code in (400, 403)


def test_invoke_bad_json_400(setup_a2a):
    client, _priv, _pub = setup_a2a
    r = client.post(
        "/v1/a2a/invoke", content="not-json",
        headers={"Authorization": "Bearer x"},
    )
    assert r.status_code == 400


def test_invoke_missing_tool_400(setup_a2a):
    client, priv, _pub = setup_a2a
    token = issue_jwt(priv, issuer="peer.x", audience="aegis.test")
    env = {
        "id": "req-missing-tool",
        "from": "peer.x",
        "to": "aegis.test",
        "method": "agent.invoke",
        "params": {},  # no tool
        "nonce": str(uuid.uuid4()),
        "timestamp": int(time.time()),
    }
    env["signature"] = sign_ed25519(priv, env)
    r = client.post(
        "/v1/a2a/invoke", json=env,
        headers={"Authorization": f"Bearer {token}"},
    )
    assert r.status_code == 400


def test_capabilities_list_method_via_invoke(setup_a2a):
    client, priv, _pub = setup_a2a
    token = issue_jwt(priv, issuer="peer.x", audience="aegis.test")
    env = {
        "id": "req-caplist",
        "from": "peer.x",
        "to": "aegis.test",
        "method": "capabilities.list",
        "params": {},
        "nonce": str(uuid.uuid4()),
        "timestamp": int(time.time()),
    }
    env["signature"] = sign_ed25519(priv, env)
    r = client.post(
        "/v1/a2a/invoke", json=env,
        headers={"Authorization": f"Bearer {token}"},
    )
    assert r.status_code == 200
    assert r.json()["result"]["agent_id"] == "aegis.test"
