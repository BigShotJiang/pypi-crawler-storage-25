"""Tests for ``persona.session_persist`` (M1 Week 2 task #8.3).

Covers:
  * default_session_root / generate_session_id / SCHEMA_VERSION
  * SessionManifest: to_dict / from_dict round-trip + schema mismatch
  * SessionSnapshot: same
  * CheckpointPolicy: every_n_messages / every_n_seconds / custom_trigger
  * SessionStore.checkpoint: writes manifest + log + tracker update
  * SessionStore.maybe_checkpoint: triggers / no-ops correctly
  * SessionStore.load_latest_checkpoint / load_checkpoint_history
  * SessionStore.list_sessions: ordering by last_active
  * SessionStore.delete_session: clears both files + tracker
  * SessionStore.resume: bundled load
  * SessionStore: max_history cap on log
  * Schema mismatch propagation
  * Custom state_store injection
  * Concurrent checkpoint thread safety
"""
from __future__ import annotations

import json
import threading
from collections.abc import Sequence
from pathlib import Path
from typing import Any

import pytest

from persona.session_persist import (
    SCHEMA_VERSION,
    CheckpointPolicy,
    SchemaVersionMismatch,
    SessionManifest,
    SessionSnapshot,
    SessionStore,
    default_session_root,
    generate_session_id,
)


# ─────────────────────────────────────────────────────────────────
# Fixtures
# ─────────────────────────────────────────────────────────────────


@pytest.fixture
def tmp_session_dir(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> Path:
    """Point SessionStore at a temp dir for the test's duration."""
    monkeypatch.setenv("SANCIO_SESSION_DIR", str(tmp_path))
    return tmp_path


@pytest.fixture
def store(tmp_session_dir: Path) -> SessionStore:
    return SessionStore(
        root=tmp_session_dir,
        policy=CheckpointPolicy(every_n_messages=2, every_n_seconds=0),
    )


# ─────────────────────────────────────────────────────────────────
# Helpers / module-level
# ─────────────────────────────────────────────────────────────────


class TestModuleHelpers:
    def test_default_session_root_default(
        self, monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        monkeypatch.delenv("SANCIO_SESSION_DIR", raising=False)
        root = default_session_root()
        assert root.name == "state"
        assert root.parent.name == ".sancio"

    def test_default_session_root_override(
        self, monkeypatch: pytest.MonkeyPatch, tmp_path: Path,
    ) -> None:
        monkeypatch.setenv("SANCIO_SESSION_DIR", str(tmp_path))
        assert default_session_root() == tmp_path

    def test_generate_session_id_length(self) -> None:
        sid = generate_session_id()
        assert len(sid) == 32
        assert all(c in "0123456789abcdef" for c in sid)

    def test_generate_session_id_unique(self) -> None:
        ids = {generate_session_id() for _ in range(100)}
        assert len(ids) == 100

    def test_schema_version_constant(self) -> None:
        assert isinstance(SCHEMA_VERSION, int)
        assert SCHEMA_VERSION >= 1


# ─────────────────────────────────────────────────────────────────
# SessionManifest
# ─────────────────────────────────────────────────────────────────


class TestSessionManifest:
    def test_round_trip(self) -> None:
        m = SessionManifest(
            session_id="abc",
            model_id="claude-sonnet-4-7",
            tool_set=("fetch", "exec"),
            message_count=12,
            checkpoint_count=3,
            labels={"project": "sancio"},
        )
        d = m.to_dict()
        assert d["tool_set"] == ["fetch", "exec"]
        m2 = SessionManifest.from_dict(d)
        assert m2 == m

    def test_schema_mismatch(self) -> None:
        bad = {"session_id": "x", "schema": SCHEMA_VERSION + 999}
        with pytest.raises(SchemaVersionMismatch) as exc:
            SessionManifest.from_dict(bad)
        assert exc.value.found == SCHEMA_VERSION + 999

    def test_defaults(self) -> None:
        m = SessionManifest(session_id="abc")
        assert m.model_id == ""
        assert m.tool_set == ()
        assert m.message_count == 0
        assert m.schema == SCHEMA_VERSION


# ─────────────────────────────────────────────────────────────────
# SessionSnapshot
# ─────────────────────────────────────────────────────────────────


class TestSessionSnapshot:
    def test_round_trip(self) -> None:
        s = SessionSnapshot(
            session_id="abc",
            messages=[{"role": "user", "content": "hi"}],
            model_id="claude-haiku-4-5",
            tool_set=("a",),
            message_count=1,
            reason="auto",
        )
        d = s.to_dict()
        s2 = SessionSnapshot.from_dict(d)
        assert s2 == s

    def test_schema_mismatch(self) -> None:
        bad = {"session_id": "x", "schema": 99}
        with pytest.raises(SchemaVersionMismatch):
            SessionSnapshot.from_dict(bad)


# ─────────────────────────────────────────────────────────────────
# CheckpointPolicy
# ─────────────────────────────────────────────────────────────────


class TestCheckpointPolicy:
    def test_message_count_trigger(self) -> None:
        policy = CheckpointPolicy(every_n_messages=3, every_n_seconds=0)
        msgs: Sequence[dict[str, Any]] = [{"role": "user", "content": "x"}] * 5
        assert policy.should_fire(msgs, last_ts=0.0, last_message_count=2) is True
        assert policy.should_fire(msgs, last_ts=0.0, last_message_count=4) is False

    def test_time_trigger(self) -> None:
        policy = CheckpointPolicy(every_n_messages=0, every_n_seconds=10)
        import time

        ts = time.time() - 20
        assert policy.should_fire([], last_ts=ts, last_message_count=0) is True

    def test_no_trigger_when_disabled(self) -> None:
        policy = CheckpointPolicy(every_n_messages=0, every_n_seconds=0)
        assert policy.should_fire([], last_ts=0.0, last_message_count=0) is False

    def test_custom_trigger(self) -> None:
        called = {"n": 0}

        def custom(msgs: Sequence[dict[str, Any]], _ts: float, _ct: int) -> bool:
            called["n"] += 1
            return len(msgs) > 0

        policy = CheckpointPolicy(
            every_n_messages=0, every_n_seconds=0, custom_trigger=custom,
        )
        assert policy.should_fire([{"role": "user", "content": "x"}], 0.0, 0) is True
        assert called["n"] == 1

    def test_custom_trigger_exception_swallowed(self) -> None:
        def boom(*_args: Any) -> bool:
            raise RuntimeError("bad")

        policy = CheckpointPolicy(
            every_n_messages=0, every_n_seconds=0, custom_trigger=boom,
        )
        # Should return False, not raise.
        assert policy.should_fire([], 0.0, 0) is False


# ─────────────────────────────────────────────────────────────────
# SessionStore: checkpoint + manifest
# ─────────────────────────────────────────────────────────────────


class TestSessionStoreCheckpoint:
    def test_creates_manifest_on_first_checkpoint(self, store: SessionStore) -> None:
        sid = generate_session_id()
        store.checkpoint(
            sid,
            [{"role": "user", "content": "hi"}],
            model_id="claude-sonnet-4-7",
        )
        m = store.get_manifest(sid)
        assert m is not None
        assert m["session_id"] == sid
        assert m["checkpoint_count"] == 1
        assert m["model_id"] == "claude-sonnet-4-7"

    def test_subsequent_increments_count(self, store: SessionStore) -> None:
        sid = generate_session_id()
        for i in range(3):
            store.checkpoint(sid, [{"role": "user", "content": f"m{i}"}])
        m = store.get_manifest(sid)
        assert m["checkpoint_count"] == 3

    def test_manifest_labels_merge(self, store: SessionStore) -> None:
        sid = generate_session_id()
        store.checkpoint(sid, [], labels={"a": "1"})
        store.checkpoint(sid, [], labels={"b": "2"})
        m = store.get_manifest(sid)
        assert m["labels"] == {"a": "1", "b": "2"}

    def test_load_latest_checkpoint_returns_newest(
        self, store: SessionStore,
    ) -> None:
        sid = generate_session_id()
        store.checkpoint(sid, [{"role": "user", "content": "first"}])
        store.checkpoint(sid, [{"role": "user", "content": "second"}])
        latest = store.load_latest_checkpoint(sid)
        assert latest is not None
        assert latest["messages"][0]["content"] == "second"

    def test_load_history_preserves_order(self, store: SessionStore) -> None:
        sid = generate_session_id()
        for i in range(5):
            store.checkpoint(sid, [{"role": "user", "content": f"m{i}"}])
        history = store.load_checkpoint_history(sid)
        assert len(history) == 5
        assert history[0]["messages"][0]["content"] == "m0"
        assert history[-1]["messages"][0]["content"] == "m4"

    def test_load_history_with_limit(self, store: SessionStore) -> None:
        sid = generate_session_id()
        for i in range(10):
            store.checkpoint(sid, [{"role": "user", "content": f"m{i}"}])
        history = store.load_checkpoint_history(sid, limit=3)
        assert len(history) == 3
        assert history[0]["messages"][0]["content"] == "m7"


# ─────────────────────────────────────────────────────────────────
# SessionStore: maybe_checkpoint
# ─────────────────────────────────────────────────────────────────


class TestMaybeCheckpoint:
    def test_first_call_no_trigger(self, tmp_session_dir: Path) -> None:
        # every_n_messages=5 → 1 msg won't fire.
        store = SessionStore(
            root=tmp_session_dir,
            policy=CheckpointPolicy(every_n_messages=5, every_n_seconds=0),
        )
        sid = generate_session_id()
        result = store.maybe_checkpoint(sid, [{"role": "user", "content": "x"}])
        assert result is None

    def test_triggers_after_threshold(self, tmp_session_dir: Path) -> None:
        store = SessionStore(
            root=tmp_session_dir,
            policy=CheckpointPolicy(every_n_messages=3, every_n_seconds=0),
        )
        sid = generate_session_id()
        msgs = [{"role": "user", "content": f"m{i}"} for i in range(3)]
        result = store.maybe_checkpoint(sid, msgs)
        assert result is not None
        assert result.reason == "auto"

    def test_does_not_double_trigger(self, tmp_session_dir: Path) -> None:
        store = SessionStore(
            root=tmp_session_dir,
            policy=CheckpointPolicy(every_n_messages=3, every_n_seconds=0),
        )
        sid = generate_session_id()
        msgs = [{"role": "user", "content": f"m{i}"} for i in range(3)]
        first = store.maybe_checkpoint(sid, msgs)
        second = store.maybe_checkpoint(sid, msgs)  # same length → no fire
        assert first is not None
        assert second is None


# ─────────────────────────────────────────────────────────────────
# SessionStore: list / delete / resume
# ─────────────────────────────────────────────────────────────────


class TestListDeleteResume:
    def test_list_sessions_sorted(self, store: SessionStore) -> None:
        sid1 = generate_session_id()
        sid2 = generate_session_id()
        store.checkpoint(sid1, [], labels={"first": "true"})
        # Tweak last_active so we have a deterministic order.
        m1 = SessionManifest.from_dict(store.get_manifest(sid1))
        m1.last_active = "2026-01-01T00:00:00Z"
        store.upsert_manifest(m1)

        store.checkpoint(sid2, [], labels={"second": "true"})
        m2 = SessionManifest.from_dict(store.get_manifest(sid2))
        m2.last_active = "2026-12-31T00:00:00Z"
        store.upsert_manifest(m2)

        listing = store.list_sessions()
        assert listing[0]["session_id"] == sid2  # newer first

    def test_delete_session_removes_files(self, store: SessionStore) -> None:
        sid = generate_session_id()
        store.checkpoint(sid, [{"role": "user", "content": "x"}])
        assert store.delete_session(sid) is True
        assert store.get_manifest(sid) is None
        assert store.load_latest_checkpoint(sid) is None

    def test_delete_session_idempotent(self, store: SessionStore) -> None:
        # No such session — returns False, doesn't crash.
        assert store.delete_session("nope" * 8) is False

    def test_resume_returns_both(self, store: SessionStore) -> None:
        sid = generate_session_id()
        store.checkpoint(sid, [{"role": "user", "content": "saved"}])
        manifest, snapshot = store.resume(sid)
        assert manifest is not None and manifest.session_id == sid
        assert snapshot is not None
        assert snapshot.messages[0]["content"] == "saved"

    def test_resume_missing_session(self, store: SessionStore) -> None:
        manifest, snapshot = store.resume("nonexistent")
        assert manifest is None
        assert snapshot is None


# ─────────────────────────────────────────────────────────────────
# Max history cap
# ─────────────────────────────────────────────────────────────────


class TestMaxHistory:
    def test_log_capped(self, tmp_session_dir: Path) -> None:
        store = SessionStore(
            root=tmp_session_dir,
            policy=CheckpointPolicy(
                every_n_messages=1, every_n_seconds=0, max_history=3,
            ),
        )
        sid = generate_session_id()
        for i in range(10):
            store.checkpoint(sid, [{"role": "user", "content": f"m{i}"}])
        history = store.load_checkpoint_history(sid)
        assert len(history) == 3
        # Should be the last three written.
        assert history[-1]["messages"][0]["content"] == "m9"


# ─────────────────────────────────────────────────────────────────
# Manifest preserves earlier model id when later checkpoint omits one
# ─────────────────────────────────────────────────────────────────


class TestManifestPreservation:
    def test_model_id_preserved(self, store: SessionStore) -> None:
        sid = generate_session_id()
        store.checkpoint(sid, [], model_id="claude-opus-4-7")
        store.checkpoint(sid, [])  # no model_id
        m = store.get_manifest(sid)
        assert m["model_id"] == "claude-opus-4-7"

    def test_tool_set_preserved(self, store: SessionStore) -> None:
        sid = generate_session_id()
        store.checkpoint(sid, [], tool_set=("a", "b"))
        store.checkpoint(sid, [])
        m = store.get_manifest(sid)
        assert tuple(m["tool_set"]) == ("a", "b")


# ─────────────────────────────────────────────────────────────────
# Custom state_store injection
# ─────────────────────────────────────────────────────────────────


class _FakeStore:
    def __init__(self) -> None:
        self.data: dict[str, Any] = {}

    def read(self, ns: str, sid: str, default: Any = None) -> Any:
        return self.data.get((ns, sid), default)

    def write(self, ns: str, sid: str, data: Any) -> None:
        self.data[(ns, sid)] = data

    def _path(self, ns: str, sid: str) -> str:
        return f"/tmp/fake/{ns}/{sid}.json"


class TestStateStoreInjection:
    def test_custom_state_store(self, tmp_session_dir: Path) -> None:
        fake = _FakeStore()
        store = SessionStore(root=tmp_session_dir, state_store=fake)
        sid = generate_session_id()
        # The checkpoint code path mostly uses the file-based path
        # logic via _path(); we only assert the manifest write went
        # through the custom store.
        try:
            store.checkpoint(sid, [{"role": "user", "content": "hi"}])
        except OSError:
            # checkpoint also writes through the file-based path; an
            # OSError on the fake-tmp /tmp/fake/ path is expected on
            # Windows. The manifest write succeeded.
            pass
        assert (("sessions", sid)) in fake.data


# ─────────────────────────────────────────────────────────────────
# Schema mismatch propagation in maybe_checkpoint
# ─────────────────────────────────────────────────────────────────


class TestSchemaPropagation:
    def test_resume_with_bad_manifest_returns_none_manifest(
        self, store: SessionStore, tmp_session_dir: Path,
    ) -> None:
        sid = generate_session_id()
        # Write a bogus-schema manifest directly through the store.
        store._store.write(  # noqa: SLF001
            "sessions", sid, {"session_id": sid, "schema": 999},
        )
        manifest, _ = store.resume(sid)
        assert manifest is None  # schema mismatch silently nulled


# ─────────────────────────────────────────────────────────────────
# Concurrent access
# ─────────────────────────────────────────────────────────────────


class TestConcurrency:
    def test_parallel_checkpoints_serialised(
        self, tmp_session_dir: Path,
    ) -> None:
        store = SessionStore(
            root=tmp_session_dir,
            policy=CheckpointPolicy(every_n_messages=1, every_n_seconds=0),
        )
        sid = generate_session_id()

        def worker(i: int) -> None:
            store.checkpoint(sid, [{"role": "user", "content": f"m{i}"}])

        threads = [threading.Thread(target=worker, args=(i,)) for i in range(8)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()

        m = store.get_manifest(sid)
        assert m["checkpoint_count"] == 8


# ─────────────────────────────────────────────────────────────────
# File layout sanity
# ─────────────────────────────────────────────────────────────────


class TestFileLayout:
    def test_files_created_under_root(
        self, store: SessionStore, tmp_session_dir: Path,
    ) -> None:
        sid = generate_session_id()
        store.checkpoint(sid, [{"role": "user", "content": "hi"}])
        # Two namespaces: sessions/ and checkpoints/
        ns_dirs = {p.name for p in tmp_session_dir.iterdir() if p.is_dir()}
        assert "sessions" in ns_dirs
        assert "checkpoints" in ns_dirs

    def test_checkpoint_log_is_json(
        self, store: SessionStore, tmp_session_dir: Path,
    ) -> None:
        sid = generate_session_id()
        store.checkpoint(sid, [{"role": "user", "content": "hi"}])
        # Find the checkpoint file (blake2b key, 16 hex chars).
        ckpt_dir = tmp_session_dir / "checkpoints"
        files = list(ckpt_dir.glob("*.json"))
        assert len(files) == 1
        with files[0].open("r", encoding="utf-8") as fh:
            payload = json.load(fh)
        assert payload["schema"] == SCHEMA_VERSION
        assert payload["session_id"] == sid
        assert isinstance(payload["snapshots"], list)


# ─────────────────────────────────────────────────────────────────
# Robustness
# ─────────────────────────────────────────────────────────────────


class TestRobustness:
    def test_get_manifest_empty_sid_returns_none(self, store: SessionStore) -> None:
        assert store.get_manifest("") is None

    def test_corrupt_checkpoint_log_returns_empty(
        self, store: SessionStore, tmp_session_dir: Path,
    ) -> None:
        sid = generate_session_id()
        store.checkpoint(sid, [{"role": "user", "content": "x"}])
        # Trash the file.
        ckpt_dir = tmp_session_dir / "checkpoints"
        target = next(ckpt_dir.glob("*.json"))
        target.write_text("not json{{{", encoding="utf-8")
        assert store.load_checkpoint_history(sid) == []
        assert store.load_latest_checkpoint(sid) is None

    def test_list_sessions_skips_garbage(
        self, store: SessionStore, tmp_session_dir: Path,
    ) -> None:
        sid = generate_session_id()
        store.checkpoint(sid, [])
        sessions_dir = tmp_session_dir / "sessions"
        # Drop a junk file alongside the real one.
        (sessions_dir / "junk.json").write_text("not json", encoding="utf-8")
        listing = store.list_sessions()
        assert len(listing) == 1
        assert listing[0]["session_id"] == sid


def test_env_override_picked_up_by_default_root(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path,
) -> None:
    monkeypatch.setenv("SANCIO_SESSION_DIR", str(tmp_path / "custom"))
    assert default_session_root() == tmp_path / "custom"


def test_env_override_creates_dir_on_store_construction(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path,
) -> None:
    target = tmp_path / "fresh"
    monkeypatch.setenv("SANCIO_SESSION_DIR", str(target))
    SessionStore()
    assert target.is_dir()


def test_session_store_uses_concinno_state_store(tmp_path: Path) -> None:
    """Sanity: when no state_store is injected we end up with the real one."""
    store = SessionStore(root=tmp_path)
    # Duck-type check — read() / write() / _path() are the surface used.
    assert hasattr(store._store, "read")  # noqa: SLF001
    assert hasattr(store._store, "write")  # noqa: SLF001
    assert hasattr(store._store, "_path")  # noqa: SLF001


def test_unset_env_falls_back_to_home(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.delenv("SANCIO_SESSION_DIR", raising=False)
    root = default_session_root()
    assert ".sancio" in root.parts


def test_module_exports_complete() -> None:
    from persona import session_persist as sp

    for name in (
        "CheckpointPolicy", "SchemaVersionMismatch", "SessionManifest",
        "SessionSnapshot", "SessionStore", "default_session_root",
        "generate_session_id", "SCHEMA_VERSION",
    ):
        assert hasattr(sp, name)
