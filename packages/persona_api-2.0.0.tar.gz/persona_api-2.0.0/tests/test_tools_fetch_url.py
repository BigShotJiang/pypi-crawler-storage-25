"""Tests for ``persona.tools.fetch_url.FetchUrlTool``.

All network I/O is mocked via :class:`httpx.MockTransport` so the
tests are hermetic and do not depend on real servers. The tool
contract we verify:

* Happy path returns the decoded body (stripped of HTML tags when
  ``content-type: text/html``).
* 4xx/5xx responses surface as a ``"error: http <code>"`` string
  rather than raising — so the agent loop can observe and retry.
* Oversize responses are rejected by the size cap (tested via a
  tiny cap + a payload larger than the cap).
* Non-text content types return the ``[non-text content: ...]``
  sentinel.
"""

from __future__ import annotations

from typing import Any

import httpx
import pytest

from persona.tools.fetch_url import FetchUrlTool


def _mock_client(
    handler: "Any",
) -> httpx.Client:
    """Build a sync ``httpx.Client`` wired to a MockTransport handler.

    The Sancio FetchUrlTool is a thin async adapter over Concinno's
    sync FetchUrlTool (``httpx.Client``-based). Tests use the sync
    mock client because it is what Concinno's impl consumes; the
    adapter bridges to async via ``asyncio.to_thread``.
    """
    return httpx.Client(
        transport=httpx.MockTransport(handler),
        timeout=5.0,
    )


# ─────────────────── happy path ───────────────────


@pytest.mark.asyncio
async def test_fetch_url_plain_text() -> None:
    def _handler(req: httpx.Request) -> httpx.Response:
        return httpx.Response(
            200,
            headers={"content-type": "text/plain; charset=utf-8"},
            content=b"hello world\nline two",
        )

    client = _mock_client(_handler)
    try:
        tool = FetchUrlTool(client=client)
        out = await tool.execute({"url": "https://example.com/page"})
    finally:
        client.close()

    assert "hello world" in out
    assert "line two" in out
    assert tool.schema()["function"]["name"] == "fetch_url"


@pytest.mark.asyncio
async def test_fetch_url_html_strips_tags() -> None:
    body = (
        "<html><head><title>T</title><script>var x=1;</script></head>"
        "<body><p>Hello</p><p>World</p></body></html>"
    )

    def _handler(req: httpx.Request) -> httpx.Response:
        return httpx.Response(
            200,
            headers={"content-type": "text/html; charset=utf-8"},
            content=body.encode("utf-8"),
        )

    client = _mock_client(_handler)
    try:
        tool = FetchUrlTool(client=client)
        out = await tool.execute({"url": "https://example.com/"})
    finally:
        client.close()

    assert "Hello" in out
    assert "World" in out
    # <script> body must be dropped.
    assert "var x=1" not in out
    # Tags must be gone.
    assert "<p>" not in out and "<html>" not in out


# ─────────────────── error paths ───────────────────


@pytest.mark.asyncio
async def test_fetch_url_404() -> None:
    def _handler(req: httpx.Request) -> httpx.Response:
        return httpx.Response(404, content=b"nope")

    client = _mock_client(_handler)
    try:
        tool = FetchUrlTool(client=client)
        out = await tool.execute({"url": "https://example.com/missing"})
    finally:
        client.close()

    assert out.startswith("error: http 404")


@pytest.mark.asyncio
async def test_fetch_url_rejects_non_http_scheme() -> None:
    tool = FetchUrlTool()
    out = await tool.execute({"url": "ftp://example.com/"})
    assert out.startswith("error: url must be http")


@pytest.mark.asyncio
async def test_fetch_url_requires_url() -> None:
    tool = FetchUrlTool()
    out = await tool.execute({})
    assert out.startswith("error: url is required")


# ─────────────────── size cap ───────────────────


@pytest.mark.asyncio
async def test_fetch_url_size_cap_via_content_length() -> None:
    def _handler(req: httpx.Request) -> httpx.Response:
        # 100 bytes body, but we declare 10 MB — the header-based
        # pre-check should trip.
        return httpx.Response(
            200,
            headers={
                "content-type": "text/plain",
                "content-length": str(10 * 1024 * 1024),
            },
            content=b"x" * 100,
        )

    client = _mock_client(_handler)
    try:
        tool = FetchUrlTool(client=client, max_bytes=1024)
        out = await tool.execute({"url": "https://example.com/big"})
    finally:
        client.close()

    assert out.startswith("error: content-length")


@pytest.mark.asyncio
async def test_fetch_url_size_cap_via_body() -> None:
    # Declare a content-length that passes the pre-check but deliver
    # a larger body. httpx's MockTransport auto-populates
    # content-length when the header is absent, so we set a truthful-
    # looking one that slips under the cap; the post-fetch size check
    # is what we actually want to exercise here.
    def _handler(req: httpx.Request) -> httpx.Response:
        return httpx.Response(
            200,
            headers={
                "content-type": "text/plain",
                # Under the 1024 cap so the pre-check passes…
                "content-length": "500",
            },
            # …but the real payload blows past it.
            content=b"x" * 2048,
        )

    client = _mock_client(_handler)
    try:
        tool = FetchUrlTool(client=client, max_bytes=1024)
        out = await tool.execute({"url": "https://example.com/big2"})
    finally:
        client.close()

    assert out.startswith("error: body size")


# ─────────────────── non-text ───────────────────


@pytest.mark.asyncio
async def test_fetch_url_non_text_returns_sentinel() -> None:
    def _handler(req: httpx.Request) -> httpx.Response:
        return httpx.Response(
            200,
            headers={"content-type": "image/png"},
            content=b"\x89PNG\r\n\x1a\n...binary...",
        )

    client = _mock_client(_handler)
    try:
        tool = FetchUrlTool(client=client)
        out = await tool.execute({"url": "https://example.com/pic.png"})
    finally:
        client.close()

    assert out == "[non-text content: image/png]"


# ─────────────────── output cap ───────────────────


@pytest.mark.asyncio
async def test_fetch_url_truncates_long_output() -> None:
    body = "A" * 20000

    def _handler(req: httpx.Request) -> httpx.Response:
        return httpx.Response(
            200,
            headers={"content-type": "text/plain"},
            content=body.encode("utf-8"),
        )

    client = _mock_client(_handler)
    try:
        tool = FetchUrlTool(client=client, max_output_chars=500)
        out = await tool.execute({"url": "https://example.com/long"})
    finally:
        client.close()

    assert len(out) <= 501  # 500 chars + trailing ellipsis
    assert out.endswith("…")
