"""P0#1 Task 5 — ``_invocations`` LRU + TTL cap (a2a.py)."""

from __future__ import annotations

import time

import pytest

from persona.a2a import _InvocationsLRU


def test_set_and_get() -> None:
    lru = _InvocationsLRU(max_size=3, ttl_s=60)
    lru["a"] = {"status": "done"}
    assert lru.get("a") == {"status": "done"}


def test_size_cap_evicts_oldest() -> None:
    lru = _InvocationsLRU(max_size=2, ttl_s=60)
    lru["a"] = {"n": 1}
    lru["b"] = {"n": 2}
    lru["c"] = {"n": 3}
    assert lru.get("a") is None
    assert lru.get("b") == {"n": 2}
    assert lru.get("c") == {"n": 3}


def test_ttl_expiry(monkeypatch: pytest.MonkeyPatch) -> None:
    lru = _InvocationsLRU(max_size=10, ttl_s=1.0)
    lru["a"] = {"n": 1}
    t0 = [time.time()]

    def _fake() -> float:
        return t0[0] + 2.0

    monkeypatch.setattr(time, "time", _fake)
    assert lru.get("a") is None


def test_get_default_on_missing() -> None:
    lru = _InvocationsLRU(max_size=5, ttl_s=60)
    assert lru.get("missing") is None
    assert lru.get("missing", {"fallback": True}) == {"fallback": True}


def test_contains() -> None:
    lru = _InvocationsLRU(max_size=3, ttl_s=60)
    lru["a"] = {"n": 1}
    assert "a" in lru
    assert "b" not in lru


def test_clear() -> None:
    lru = _InvocationsLRU(max_size=3, ttl_s=60)
    lru["a"] = {"n": 1}
    lru["b"] = {"n": 2}
    lru.clear()
    assert len(lru) == 0
    assert lru.get("a") is None


def test_get_refreshes_lru_position() -> None:
    """Touching an entry via ``.get()`` bumps it to MRU."""
    lru = _InvocationsLRU(max_size=2, ttl_s=60)
    lru["a"] = {"n": 1}
    lru["b"] = {"n": 2}
    assert lru.get("a") == {"n": 1}  # a now MRU
    lru["c"] = {"n": 3}
    # b should be evicted, not a.
    assert lru.get("a") == {"n": 1}
    assert lru.get("b") is None
    assert lru.get("c") == {"n": 3}
