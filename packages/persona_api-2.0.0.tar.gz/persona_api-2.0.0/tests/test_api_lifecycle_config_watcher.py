"""Regression: ConfigWatcher is wired into Sancio's app lifecycle (2.0.0).

Covers RED Opus FATAL-1 (2026-05-01): ``attach_config_watcher`` /
``detach_config_watcher`` must fire from ``create_standalone_app``'s
``_on_startup`` / ``_on_shutdown`` hooks. Pre-fix the watcher was
defined but never invoked → 310 LoC of dead code in production.

Three scenarios:

1. Empty path list → startup logs "no config files to watch" and does
   NOT raise (graceful degradation per BLUE 弱點 #3).
2. Non-empty path list → ``attach_config_watcher`` is called with the
   resolved paths; ``detach_config_watcher`` is called on shutdown.
3. ``attach_config_watcher`` raising → server boot still succeeds
   (observability feature is fail-open, not safety-critical).
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any

import pytest

# NOTE: do NOT use a module-level ``pytestmark = pytest.mark.asyncio``
# because two of the helper-function unit tests below are sync — pytest
# warns and refuses to mix when an async mark is applied to a sync def.
# Each async test gets its own decorator instead.


# ── helpers ────────────────────────────────────────────────────


def _build_app() -> Any:
    """Construct the standalone app via the public factory."""
    from persona.api import create_standalone_app

    return create_standalone_app()


async def _run_startup(app: Any) -> None:
    for cb in app.router.on_startup:
        await cb()


async def _run_shutdown(app: Any) -> None:
    for cb in app.router.on_shutdown:
        await cb()


# ── tests ──────────────────────────────────────────────────────


@pytest.mark.asyncio
async def test_startup_empty_paths_logs_and_does_not_raise(
    monkeypatch: pytest.MonkeyPatch,
    caplog: pytest.LogCaptureFixture,
    tmp_path: Path,
) -> None:
    """Empty SANCIO_CONFIG_PATHS + no default files → graceful skip."""
    # Force resolver to return an empty list by pointing at a directory
    # that has no policy.yaml / skills.yaml.
    monkeypatch.setenv("SANCIO_CONFIG_PATHS", str(tmp_path / "nonexistent.yaml"))

    app = _build_app()
    caplog.set_level(logging.INFO, logger="persona.api")

    # Must not raise.
    await _run_startup(app)

    assert any(
        "no config files to watch" in rec.getMessage()
        for rec in caplog.records
    ), "expected 'no config files to watch' INFO log"

    # Shutdown must also be clean (no watcher attached).
    await _run_shutdown(app)


@pytest.mark.asyncio
async def test_startup_with_path_attaches_watcher(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    """Non-empty path list → attach_config_watcher is called."""
    # Create a real file so the resolver picks it up.
    cfg = tmp_path / "policy.yaml"
    cfg.write_text("rules: []\n", encoding="utf-8")
    monkeypatch.setenv("SANCIO_CONFIG_PATHS", str(cfg))

    captured: dict[str, Any] = {}

    async def fake_attach(watcher: Any) -> None:
        captured["watcher"] = watcher
        captured["paths"] = list(watcher._paths)
        # Mark the watcher as 'started' so detach treats it as live.
        watcher._task = object()  # truthy sentinel — see is_running

    detach_called: dict[str, bool] = {"flag": False}

    async def fake_detach() -> None:
        detach_called["flag"] = True

    # The api.py _on_startup binds these via ``from .runtime import``
    # at function-call time — patching them on the runtime module
    # itself is the durable monkeypatch target.
    monkeypatch.setattr(
        "persona.runtime.attach_config_watcher", fake_attach, raising=True,
    )
    monkeypatch.setattr(
        "persona.runtime.detach_config_watcher", fake_detach, raising=True,
    )

    app = _build_app()
    await _run_startup(app)

    assert "watcher" in captured, "attach_config_watcher was never called"
    assert any(
        Path(str(p)) == cfg for p in captured["paths"]
    ), f"expected {cfg} in watched paths, got {captured['paths']}"

    await _run_shutdown(app)
    assert detach_called["flag"] is True, (
        "detach_config_watcher must fire on app shutdown"
    )


@pytest.mark.asyncio
async def test_startup_attach_failure_does_not_break_boot(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
    caplog: pytest.LogCaptureFixture,
) -> None:
    """attach raising → server boot continues (BLUE 弱點 #3)."""
    cfg = tmp_path / "policy.yaml"
    cfg.write_text("rules: []\n", encoding="utf-8")
    monkeypatch.setenv("SANCIO_CONFIG_PATHS", str(cfg))

    async def boom(watcher: Any) -> None:
        raise RuntimeError("watchfiles missing")

    monkeypatch.setattr(
        "persona.runtime.attach_config_watcher", boom, raising=True,
    )

    app = _build_app()
    caplog.set_level(logging.ERROR, logger="persona.api")

    # Must not raise — observability feature is fail-open.
    await _run_startup(app)

    # The exception path is logged at exception level.
    assert any(
        "ConfigWatcher startup raised" in rec.getMessage()
        for rec in caplog.records
    ), "expected 'ConfigWatcher startup raised' log on failure path"

    await _run_shutdown(app)


# ── helper-function unit tests ─────────────────────────────────


def test_resolve_config_watch_paths_env_override(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    """SANCIO_CONFIG_PATHS env var beats default ~/.sancio/* lookup."""
    import os as _os

    from persona.api import _resolve_config_watch_paths

    a = tmp_path / "a.yaml"
    a.write_text("a: 1\n", encoding="utf-8")
    b = tmp_path / "b.yaml"  # does NOT exist on disk
    monkeypatch.setenv("SANCIO_CONFIG_PATHS", _os.pathsep.join([str(a), str(b)]))

    result = _resolve_config_watch_paths()
    # Only existing files survive.
    assert len(result) == 1
    assert Path(str(result[0])) == a


def test_classify_config_source_maps_stems() -> None:
    """Stem-based source classifier matches the documented behaviour."""
    from persona.api import _classify_config_source

    assert _classify_config_source(Path("/x/policy.yaml")) == "policy_settings"
    assert _classify_config_source(Path("/x/skills.yaml")) == "skills"
    assert _classify_config_source(Path("/x/settings.json")) == "user_settings"
    assert _classify_config_source(Path("/x/random.yaml")) == "project_settings"
