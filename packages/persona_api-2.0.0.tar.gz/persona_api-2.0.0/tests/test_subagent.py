"""Tests for the A11 SubagentSpawner — full prompt capture layer.

Hermetic by construction: every test injects a fake provider via
:meth:`ProviderRegistry.register_instance`, so nothing talks to a
real LLM endpoint. WebSocket round-trips use Starlette's
``TestClient.websocket_connect`` — Starlette's test harness fakes
the ASGI scope end-to-end, still no network.
"""

from __future__ import annotations

import json
from collections.abc import AsyncIterator
from pathlib import Path
from typing import Any

import pytest
from starlette.testclient import TestClient

from persona import api as api_module
from persona.api import create_standalone_app
from persona.providers import (
    ModelPolicy,
    ProviderError,
    ProviderRegistry,
)
from persona.subagent import SpawnRecord, SpawnRequest, SubagentSpawner


# ─────────────────── Fakes ───────────────────


class _FakeProvider:
    """Async double matching :class:`LLMProvider` Protocol.

    ``stream_chunks`` controls the real-stream path used by
    :meth:`SubagentSpawner.spawn_stream`. When ``stream_error`` is
    set, the iterator yields all queued ``stream_chunks`` first and
    then raises — this models a mid-stream provider failure.
    """

    name = "fake"

    def __init__(
        self,
        reply: str = "fake-reply",
        error: ProviderError | None = None,
        stream_chunks: list[str] | None = None,
        stream_error: ProviderError | None = None,
    ) -> None:
        self.reply = reply
        self.error = error
        self.stream_chunks = stream_chunks
        self.stream_error = stream_error
        self.calls: list[tuple[list[dict[str, str]], ModelPolicy]] = []
        self.stream_calls: list[
            tuple[list[dict[str, str]], ModelPolicy]
        ] = []

    async def generate(
        self,
        messages: list[dict[str, str]],
        policy: ModelPolicy,
    ) -> str:
        self.calls.append((list(messages), policy))
        if self.error is not None:
            raise self.error
        return self.reply

    async def generate_stream(
        self,
        messages: list[dict[str, str]],
        policy: ModelPolicy,
    ) -> AsyncIterator[str]:
        self.stream_calls.append((list(messages), policy))
        # Default: one-shot the full reply as a single chunk so the
        # legacy "drive streaming from the non-stream reply" case
        # stays test-ergonomic; explicit ``stream_chunks`` overrides.
        chunks = (
            self.stream_chunks
            if self.stream_chunks is not None
            else [self.reply]
        )
        for c in chunks:
            yield c
        if self.stream_error is not None:
            raise self.stream_error


def _make_registry(provider: _FakeProvider) -> ProviderRegistry:
    reg = ProviderRegistry()
    reg.register_instance("fake", provider)
    return reg


def _make_request(
    tenant_id: str = "default",
    role: str = "red-team",
    system: str = "You are a careful auditor.",
) -> SpawnRequest:
    return SpawnRequest(
        system_prompt=system,
        user_messages=[{"role": "user", "content": "find a bug"}],
        policy=ModelPolicy(provider="fake", model="m1", max_tokens=128),
        tenant_id=tenant_id,
        subagent_role=role,
        metadata={"priority": "high"},
    )


# ─────────────────── Dataclass shape ───────────────────


def test_spawn_request_defaults() -> None:
    req = SpawnRequest(
        system_prompt="s",
        user_messages=[],
        policy=ModelPolicy(provider="fake", model="m"),
    )
    assert req.tenant_id == "default"
    assert req.subagent_role == ""
    assert req.metadata == {}


def test_spawn_record_fields() -> None:
    req = _make_request()
    rec = SpawnRecord(spawn_id="abc", request=req, started_at=1.0)
    assert rec.spawn_id == "abc"
    assert rec.completed_at is None
    assert rec.response is None
    assert rec.error is None
    assert rec.tokens_estimated == 0


# ─────────────────── Spawner happy path ───────────────────


@pytest.mark.asyncio
async def test_spawn_records_happy_path(tmp_path: Path) -> None:
    fake = _FakeProvider(reply="hello world " * 10)
    spawner = SubagentSpawner(
        provider_registry=_make_registry(fake),
        log_dir=tmp_path,
    )
    record = await spawner.spawn(_make_request())

    assert record.response == fake.reply
    assert record.error is None
    assert record.completed_at is not None
    assert record.completed_at >= record.started_at
    assert record.tokens_estimated > 0
    assert len(fake.calls) == 1
    sent_messages, sent_policy = fake.calls[0]
    # system must come first, then our user turn
    assert sent_messages[0] == {
        "role": "system", "content": "You are a careful auditor.",
    }
    assert sent_messages[1] == {"role": "user", "content": "find a bug"}
    assert sent_policy.provider == "fake"


@pytest.mark.asyncio
async def test_spawn_persists_record_on_disk(tmp_path: Path) -> None:
    fake = _FakeProvider(reply="persisted")
    spawner = SubagentSpawner(
        provider_registry=_make_registry(fake),
        log_dir=tmp_path,
    )
    record = await spawner.spawn(_make_request(tenant_id="alice"))

    path = tmp_path / "alice" / f"{record.spawn_id}.json"
    assert path.exists()
    data = json.loads(path.read_text(encoding="utf-8"))
    assert data["spawn_id"] == record.spawn_id
    assert data["response"] == "persisted"
    assert data["request"]["tenant_id"] == "alice"
    assert data["request"]["system_prompt"] == "You are a careful auditor."


@pytest.mark.asyncio
async def test_spawn_persists_before_provider_call(tmp_path: Path) -> None:
    """The capture contract: record must hit disk *before* the LLM call.

    We prove it by having the provider raise — a record should still
    exist with the full request captured and ``error`` set afterwards.
    """
    fake = _FakeProvider(error=ProviderError("fake", "boom"))
    spawner = SubagentSpawner(
        provider_registry=_make_registry(fake),
        log_dir=tmp_path,
    )
    record = await spawner.spawn(_make_request(tenant_id="bob"))

    assert record.error == "fake: boom"
    assert record.response is None
    path = tmp_path / "bob" / f"{record.spawn_id}.json"
    assert path.exists()
    data = json.loads(path.read_text(encoding="utf-8"))
    assert data["request"]["system_prompt"] == "You are a careful auditor."
    assert data["error"] == "fake: boom"


@pytest.mark.asyncio
async def test_spawn_wraps_unknown_exception(tmp_path: Path) -> None:
    class _Blowup:
        name = "fake"

        async def generate(
            self, messages: Any, policy: Any,
        ) -> str:
            raise RuntimeError("unexpected thing happened " * 50)

    reg = ProviderRegistry()
    reg.register_instance("fake", _Blowup())  # type: ignore[arg-type]
    spawner = SubagentSpawner(provider_registry=reg, log_dir=tmp_path)
    record = await spawner.spawn(_make_request())

    assert record.error is not None
    assert record.error.startswith("unknown:")
    # truncation keeps the error shape predictable for log consumers
    assert len(record.error) < 250


# ─────────────────── Lookup + tenant isolation ───────────────────


@pytest.mark.asyncio
async def test_get_record_finds_live_and_disk(tmp_path: Path) -> None:
    fake = _FakeProvider()
    spawner = SubagentSpawner(
        provider_registry=_make_registry(fake),
        log_dir=tmp_path,
    )
    record = await spawner.spawn(_make_request(tenant_id="carol"))

    found = spawner.get_record(record.spawn_id)
    assert found is not None
    assert found.spawn_id == record.spawn_id
    assert found.request.tenant_id == "carol"


def test_get_record_returns_none_on_unknown(tmp_path: Path) -> None:
    spawner = SubagentSpawner(log_dir=tmp_path)
    assert spawner.get_record("nope") is None


@pytest.mark.asyncio
async def test_list_records_is_tenant_scoped(tmp_path: Path) -> None:
    fake = _FakeProvider()
    spawner = SubagentSpawner(
        provider_registry=_make_registry(fake),
        log_dir=tmp_path,
    )
    await spawner.spawn(_make_request(tenant_id="A"))
    await spawner.spawn(_make_request(tenant_id="A"))
    await spawner.spawn(_make_request(tenant_id="B"))

    a_list = spawner.list_records(tenant_id="A")
    b_list = spawner.list_records(tenant_id="B")
    assert len(a_list) == 2
    assert len(b_list) == 1
    assert all(r.request.tenant_id == "A" for r in a_list)
    assert all(r.request.tenant_id == "B" for r in b_list)


@pytest.mark.asyncio
async def test_list_records_sorted_desc(tmp_path: Path) -> None:
    fake = _FakeProvider()
    spawner = SubagentSpawner(
        provider_registry=_make_registry(fake),
        log_dir=tmp_path,
    )
    recs = []
    for _ in range(3):
        recs.append(await spawner.spawn(_make_request()))

    listed = spawner.list_records(tenant_id="default")
    assert [r.spawn_id for r in listed] == [
        recs[-1].spawn_id, recs[-2].spawn_id, recs[-3].spawn_id,
    ]


def test_list_records_empty_tenant(tmp_path: Path) -> None:
    spawner = SubagentSpawner(log_dir=tmp_path)
    assert spawner.list_records(tenant_id="ghost") == []


# ─────────────────── Streaming ───────────────────


@pytest.mark.asyncio
async def test_spawn_stream_emits_start_token_end(tmp_path: Path) -> None:
    """Real token-per-chunk streaming: one token event per provider chunk."""
    chunks = ["Hello ", "world", "! ", "from ", "stream"]
    fake = _FakeProvider(stream_chunks=chunks)
    spawner = SubagentSpawner(
        provider_registry=_make_registry(fake),
        log_dir=tmp_path,
    )
    events = []
    async for event in spawner.spawn_stream(_make_request()):
        events.append(event)

    assert events[0]["type"] == "start"
    assert events[0]["captured_prompt_len"] > 0
    assert events[-1]["type"] == "end"
    token_events = [e for e in events if e["type"] == "token"]
    assert len(token_events) == len(chunks)  # one event per provider chunk
    assert [e["text"] for e in token_events] == chunks
    assert "".join(e["text"] for e in token_events) == "Hello world! from stream"
    # Record holds the joined string + recomputed token estimate.
    assert events[-1]["total_tokens"] > 0


@pytest.mark.asyncio
async def test_spawn_stream_record_persists_joined_response(
    tmp_path: Path,
) -> None:
    """On-disk record carries joined chunks + consistent token count."""
    chunks = ["alpha ", "bravo ", "charlie"]
    fake = _FakeProvider(stream_chunks=chunks)
    spawner = SubagentSpawner(
        provider_registry=_make_registry(fake),
        log_dir=tmp_path,
    )
    events = []
    async for event in spawner.spawn_stream(
        _make_request(tenant_id="joined"),
    ):
        events.append(event)

    # Find the persisted record.
    path = next((tmp_path / "joined").glob("*.json"))
    data = json.loads(path.read_text(encoding="utf-8"))
    assert data["response"] == "alpha bravo charlie"
    assert data["error"] is None
    # _estimate_tokens heuristic: max(1, len // 4).
    assert data["tokens_estimated"] == max(1, len("alpha bravo charlie") // 4)
    assert data["completed_at"] is not None


@pytest.mark.asyncio
async def test_spawn_stream_empty_stream_yields_only_start_end(
    tmp_path: Path,
) -> None:
    """Provider that yields nothing → start + end, empty response."""
    fake = _FakeProvider(stream_chunks=[])
    spawner = SubagentSpawner(
        provider_registry=_make_registry(fake),
        log_dir=tmp_path,
    )
    events = []
    async for event in spawner.spawn_stream(
        _make_request(tenant_id="empty"),
    ):
        events.append(event)

    types = [e["type"] for e in events]
    assert types == ["start", "end"]
    path = next((tmp_path / "empty").glob("*.json"))
    data = json.loads(path.read_text(encoding="utf-8"))
    assert data["response"] == ""
    assert data["error"] is None
    assert data["tokens_estimated"] == 0


@pytest.mark.asyncio
async def test_spawn_stream_emits_error_on_provider_failure(
    tmp_path: Path,
) -> None:
    """Immediate failure: error event before any token yields."""
    fake = _FakeProvider(
        stream_chunks=[],
        stream_error=ProviderError("fake", "kaboom"),
    )
    spawner = SubagentSpawner(
        provider_registry=_make_registry(fake),
        log_dir=tmp_path,
    )
    events = []
    async for event in spawner.spawn_stream(_make_request()):
        events.append(event)

    assert events[0]["type"] == "start"
    assert any(e["type"] == "error" for e in events)
    err_event = next(e for e in events if e["type"] == "error")
    assert "kaboom" in err_event["detail"]


@pytest.mark.asyncio
async def test_spawn_stream_partial_tokens_then_error(
    tmp_path: Path,
) -> None:
    """Mid-stream failure: partial tokens preserved, then error."""
    fake = _FakeProvider(
        stream_chunks=["part1 ", "part2"],
        stream_error=ProviderError("fake", "dropped"),
    )
    spawner = SubagentSpawner(
        provider_registry=_make_registry(fake),
        log_dir=tmp_path,
    )
    events = []
    async for event in spawner.spawn_stream(
        _make_request(tenant_id="partial"),
    ):
        events.append(event)

    types = [e["type"] for e in events]
    assert types == ["start", "token", "token", "error"]
    token_texts = [e["text"] for e in events if e["type"] == "token"]
    assert token_texts == ["part1 ", "part2"]

    # Record should have partial response + error.
    path = next((tmp_path / "partial").glob("*.json"))
    data = json.loads(path.read_text(encoding="utf-8"))
    assert data["response"] == "part1 part2"
    assert data["error"] == "fake: dropped"


@pytest.mark.asyncio
async def test_spawn_stream_persists_before_first_provider_call(
    tmp_path: Path,
) -> None:
    """Capture contract: record on disk BEFORE provider iteration.

    We prove it by having the provider iterator raise on its first
    ``__anext__``, then asserting the original request shape still
    exists on disk with the full system_prompt intact.
    """

    class _ImmediateRaise:
        name = "fake"

        async def generate(
            self, messages: Any, policy: Any,
        ) -> str:  # pragma: no cover — unused
            raise ProviderError("fake", "non-stream path unused")

        async def generate_stream(
            self, messages: Any, policy: Any,
        ) -> AsyncIterator[str]:
            raise ProviderError("fake", "insta-fail")
            yield ""  # pragma: no cover — unreachable, marks as async gen

    reg = ProviderRegistry()
    reg.register_instance("fake", _ImmediateRaise())  # type: ignore[arg-type]
    spawner = SubagentSpawner(provider_registry=reg, log_dir=tmp_path)

    events = []
    async for event in spawner.spawn_stream(
        _make_request(tenant_id="precall"),
    ):
        events.append(event)

    # Even though the provider blew up immediately, the request is
    # captured on disk with the full system prompt.
    path = next((tmp_path / "precall").glob("*.json"))
    data = json.loads(path.read_text(encoding="utf-8"))
    assert data["request"]["system_prompt"] == "You are a careful auditor."
    assert data["error"] == "fake: insta-fail"
    # And the error event surfaces to the consumer.
    assert events[-1]["type"] == "error"
    assert "insta-fail" in events[-1]["detail"]


# ─────────────────── HTTP endpoints ───────────────────


@pytest.fixture()
def client(tmp_path: Path) -> TestClient:
    fake = _FakeProvider(reply="endpoint-ok")
    spawner = SubagentSpawner(
        provider_registry=_make_registry(fake),
        log_dir=tmp_path,
    )
    api_module._set_spawner_for_tests(spawner)
    try:
        yield TestClient(create_standalone_app())
    finally:
        api_module._set_spawner_for_tests(None)


def _spawn_body(**overrides: Any) -> dict[str, Any]:
    body = {
        "system_prompt": "you audit code",
        "user_messages": [{"role": "user", "content": "audit X"}],
        "policy": {"provider": "fake", "model": "m"},
        "tenant_id": "http-tenant",
        "subagent_role": "auditor",
    }
    body.update(overrides)
    return body


def test_http_spawn_happy_path(client: TestClient) -> None:
    resp = client.post("/v1/subagent/spawn", json=_spawn_body())
    assert resp.status_code == 200
    data = resp.json()
    assert data["status"] == "ok"
    assert data["response"] == "endpoint-ok"
    assert data["error"] is None
    assert data["tenant_id"] == "http-tenant"
    assert data["subagent_role"] == "auditor"
    assert data["spawn_id"]


def test_http_spawn_missing_field(client: TestClient) -> None:
    body = _spawn_body()
    del body["system_prompt"]
    resp = client.post("/v1/subagent/spawn", json=body)
    assert resp.status_code == 400
    assert "system_prompt" in resp.json()["error"]


def test_http_spawn_invalid_policy(client: TestClient) -> None:
    body = _spawn_body(policy="not-a-dict")
    resp = client.post("/v1/subagent/spawn", json=body)
    assert resp.status_code == 400


def test_http_get_record_roundtrip(client: TestClient) -> None:
    resp = client.post("/v1/subagent/spawn", json=_spawn_body())
    spawn_id = resp.json()["spawn_id"]

    get_resp = client.get(f"/v1/subagent/{spawn_id}")
    assert get_resp.status_code == 200
    fetched = get_resp.json()
    assert fetched["spawn_id"] == spawn_id
    assert fetched["request"]["tenant_id"] == "http-tenant"
    assert fetched["response"] == "endpoint-ok"


def test_http_get_record_unknown_returns_404(client: TestClient) -> None:
    resp = client.get("/v1/subagent/does-not-exist-xyz")
    assert resp.status_code == 404


def test_http_list_records_scoped(client: TestClient) -> None:
    client.post(
        "/v1/subagent/spawn",
        json=_spawn_body(tenant_id="list-A"),
    )
    client.post(
        "/v1/subagent/spawn",
        json=_spawn_body(tenant_id="list-A"),
    )
    client.post(
        "/v1/subagent/spawn",
        json=_spawn_body(tenant_id="list-B"),
    )

    a_resp = client.get("/v1/subagent?tenant_id=list-A")
    assert a_resp.status_code == 200
    a_data = a_resp.json()
    assert a_data["count"] == 2
    assert a_data["tenant_id"] == "list-A"

    b_resp = client.get("/v1/subagent?tenant_id=list-B")
    assert b_resp.json()["count"] == 1


# ─────────────────── WebSocket streaming ───────────────────


def test_websocket_streaming_emits_frames(client: TestClient) -> None:
    with client.websocket_connect("/v1/subagent/spawn/stream") as ws:
        ws.send_json(_spawn_body())
        frames = []
        # Collect until we see end or error or socket closes.
        for _ in range(20):
            try:
                frames.append(ws.receive_json())
            except Exception:  # noqa: BLE001 — socket closed by server
                break
            if frames[-1]["type"] in {"end", "error"}:
                break

    assert frames, "expected at least one frame"
    assert frames[0]["type"] == "start"
    assert frames[-1]["type"] in {"end", "error"}


def test_websocket_rejects_invalid_request(client: TestClient) -> None:
    with client.websocket_connect("/v1/subagent/spawn/stream") as ws:
        ws.send_json({"system_prompt": "hi"})  # missing user_messages/policy
        frame = ws.receive_json()
        assert frame["type"] == "error"
        assert "invalid request" in frame["detail"]
