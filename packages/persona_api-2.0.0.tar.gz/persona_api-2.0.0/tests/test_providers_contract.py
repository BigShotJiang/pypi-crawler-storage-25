"""Contract tests for the A5 self-contained model router.

Covers:
  * Protocol conformance for every built-in provider.
  * ModelPolicy dataclass field shape + defaults.
  * ProviderRegistry lookup, caching and injection surface.
  * ProviderError raised on missing env vars (fail-closed contract).
  * Ollama/OpenAI/Groq happy-path with mocked httpx.AsyncClient.
  * PersonaEngine._llm_via_provider dispatches through the registry.

Every test is hermetic: no real network calls, no real API keys,
no sleep. httpx.AsyncClient is faked with an async double that
records calls and returns canned payloads.
"""

from __future__ import annotations

import asyncio
from typing import Any

import pytest

from persona.engine import PersonaEngine
from persona.providers import (
    AnthropicProvider,
    GroqProvider,
    LLMProvider,
    ModelPolicy,
    OllamaProvider,
    OpenAIProvider,
    ProviderError,
    ProviderRegistry,
    UsageStats,
)


# ─────────────────── Fakes ───────────────────


class _FakeResponse:
    """Minimal httpx.Response stand-in."""

    def __init__(self, payload: dict[str, Any], status: int = 200) -> None:
        self._payload = payload
        self.status_code = status

    def raise_for_status(self) -> None:
        if self.status_code >= 400:
            import httpx
            req = httpx.Request("POST", "http://fake")
            raise httpx.HTTPStatusError(
                f"status={self.status_code}",
                request=req,
                response=httpx.Response(self.status_code, request=req),
            )

    def json(self) -> dict[str, Any]:
        return self._payload


class _FakeHttpxClient:
    """Async double. Returns canned payload per URL suffix."""

    def __init__(
        self,
        payloads: dict[str, dict[str, Any]],
        status: int = 200,
    ) -> None:
        self.payloads = payloads
        self.status = status
        self.calls: list[tuple[str, dict[str, Any]]] = []

    async def post(
        self,
        url: str,
        json: dict[str, Any] | None = None,
        headers: dict[str, str] | None = None,
    ) -> _FakeResponse:
        self.calls.append((url, json or {}))
        suffix = url.rsplit("/", 1)[-1]
        return _FakeResponse(
            self.payloads.get(suffix, {"choices": []}),
            status=self.status,
        )


def _openai_style_payload(text: str) -> dict[str, Any]:
    return {"choices": [{"message": {"content": text}}]}


# ─────────────────── Protocol + dataclass ───────────────────


def test_model_policy_defaults() -> None:
    policy = ModelPolicy(provider="anthropic", model="claude-opus-4-6")
    assert policy.provider == "anthropic"
    assert policy.model == "claude-opus-4-6"
    assert policy.temperature == 0.7
    assert policy.max_tokens == 4096
    assert policy.cache_breakpoints is None
    assert policy.extra == {}


def test_model_policy_all_fields() -> None:
    policy = ModelPolicy(
        provider="openai",
        model="gpt-5",
        temperature=0.1,
        max_tokens=1024,
        cache_breakpoints=[0, 1],
        extra={"top_p": 0.9},
    )
    assert policy.cache_breakpoints == [0, 1]
    assert policy.extra == {"top_p": 0.9}


@pytest.mark.parametrize(
    "cls",
    [AnthropicProvider, OpenAIProvider, OllamaProvider, GroqProvider],
)
def test_provider_satisfies_protocol(cls: type) -> None:
    instance = cls()  # type: ignore[call-arg]
    assert isinstance(instance, LLMProvider)
    assert instance.name in {"anthropic", "openai", "ollama", "groq"}
    assert callable(instance.generate)


# ─────────────────── Registry ───────────────────


def test_registry_default_has_five_providers() -> None:
    """Built-in registry: anthropic / groq / local_inproc / ollama / openai.

    ``local_inproc`` joined the default set in Concinno 2.21.0 /
    persona-api wiring for Sancio direct-GGUF runtime (MEMORY #98 +
    handoff 跑分5 §∞ rule #2) — test asserts the stable set so a
    drift (accidental removal / reorder) trips immediately.
    """
    reg = ProviderRegistry.default()
    assert reg.known() == [
        "anthropic", "groq", "local_inproc", "ollama", "openai",
    ]


def test_registry_get_returns_correct_class() -> None:
    reg = ProviderRegistry.default()
    assert isinstance(reg.get("anthropic"), AnthropicProvider)
    assert isinstance(reg.get("openai"), OpenAIProvider)
    assert isinstance(reg.get("ollama"), OllamaProvider)
    assert isinstance(reg.get("groq"), GroqProvider)


def test_registry_get_caches_instance() -> None:
    reg = ProviderRegistry.default()
    first = reg.get("ollama")
    second = reg.get("ollama")
    assert first is second


def test_registry_unknown_provider_raises() -> None:
    reg = ProviderRegistry.default()
    with pytest.raises(ProviderError) as ei:
        reg.get("does-not-exist")
    assert "unknown provider" in ei.value.detail


def test_registry_register_instance_overwrites() -> None:
    reg = ProviderRegistry.default()

    class _Fake:
        name = "ollama"

        async def generate(self, messages, policy):  # noqa: ARG002
            return "fake"

    fake = _Fake()
    reg.register_instance("ollama", fake)  # type: ignore[arg-type]
    assert reg.get("ollama") is fake


# ─────────────────── Ollama happy path ───────────────────


def test_ollama_provider_generates_text() -> None:
    client = _FakeHttpxClient(
        {"completions": _openai_style_payload("hello from gemma")},
    )
    provider = OllamaProvider(
        base_url="http://fake/v1", client=client,  # type: ignore[arg-type]
    )
    policy = ModelPolicy(provider="ollama", model="gemma3:27b")
    result = asyncio.run(
        provider.generate(
            [{"role": "user", "content": "hi"}], policy,
        ),
    )
    assert result == "hello from gemma"
    assert len(client.calls) == 1
    url, body = client.calls[0]
    assert url.endswith("/chat/completions")
    assert body["model"] == "gemma3:27b"
    assert body["messages"] == [{"role": "user", "content": "hi"}]


def test_ollama_falls_back_to_reasoning() -> None:
    client = _FakeHttpxClient({
        "completions": {
            "choices": [{
                "message": {"content": "", "reasoning": "fallback ok"},
            }],
        },
    })
    provider = OllamaProvider(
        base_url="http://fake/v1", client=client,  # type: ignore[arg-type]
    )
    policy = ModelPolicy(provider="ollama", model="gemma3:27b")
    result = asyncio.run(
        provider.generate([{"role": "user", "content": "hi"}], policy),
    )
    assert result == "fallback ok"


def test_ollama_empty_response_raises() -> None:
    client = _FakeHttpxClient({
        "completions": {"choices": [{"message": {"content": ""}}]},
    })
    provider = OllamaProvider(
        base_url="http://fake/v1", client=client,  # type: ignore[arg-type]
    )
    policy = ModelPolicy(provider="ollama", model="gemma3:27b")
    with pytest.raises(ProviderError) as ei:
        asyncio.run(
            provider.generate([{"role": "user", "content": "hi"}], policy),
        )
    assert ei.value.provider == "ollama"


# ─────────────────── OpenAI happy path ───────────────────


def test_openai_missing_key_raises() -> None:
    provider = OpenAIProvider(api_key="")
    policy = ModelPolicy(provider="openai", model="gpt-5")
    with pytest.raises(ProviderError) as ei:
        asyncio.run(
            provider.generate([{"role": "user", "content": "hi"}], policy),
        )
    assert "OPENAI_API_KEY" in ei.value.detail


def test_openai_happy_path_mocked() -> None:
    client = _FakeHttpxClient(
        {"completions": _openai_style_payload("gpt says hi")},
    )
    provider = OpenAIProvider(
        api_key="sk-fake",
        base_url="http://fake/v1",
        client=client,  # type: ignore[arg-type]
    )
    policy = ModelPolicy(
        provider="openai", model="gpt-5", extra={"top_p": 0.5},
    )
    result = asyncio.run(
        provider.generate([{"role": "user", "content": "hi"}], policy),
    )
    assert result == "gpt says hi"
    assert client.calls[0][1]["top_p"] == 0.5


# ─────────────────── Groq happy path ───────────────────


def test_groq_missing_key_raises() -> None:
    provider = GroqProvider(api_key="")
    policy = ModelPolicy(provider="groq", model="llama-4-scout")
    with pytest.raises(ProviderError) as ei:
        asyncio.run(
            provider.generate([{"role": "user", "content": "hi"}], policy),
        )
    assert "GROQ_API_KEY" in ei.value.detail


def test_groq_happy_path_mocked() -> None:
    client = _FakeHttpxClient(
        {"completions": _openai_style_payload("llama says hi")},
    )
    provider = GroqProvider(
        api_key="gsk-fake",
        base_url="http://fake/openai/v1",
        client=client,  # type: ignore[arg-type]
    )
    policy = ModelPolicy(provider="groq", model="llama-4-scout")
    result = asyncio.run(
        provider.generate([{"role": "user", "content": "hi"}], policy),
    )
    assert result == "llama says hi"


# ─────────────────── Anthropic (no SDK / no key) ───────────────────


def test_anthropic_missing_key_raises(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.delenv("ANTHROPIC_API_KEY", raising=False)
    provider = AnthropicProvider(api_key="")
    policy = ModelPolicy(provider="anthropic", model="claude-opus-4-6")
    with pytest.raises(ProviderError) as ei:
        asyncio.run(
            provider.generate([{"role": "user", "content": "hi"}], policy),
        )
    assert "ANTHROPIC_API_KEY" in ei.value.detail


# ─────────────── Anthropic _prepare cache modes ───────────────
#
# These tests pin the public contract of
# ``AnthropicProvider._prepare`` so the 5 modes (legacy / disabled /
# explicit / multiturn / length-guard) can't silently regress.


def _prov() -> AnthropicProvider:
    return AnthropicProvider(api_key="fake")


def _policy(**kw: Any) -> ModelPolicy:
    defaults: dict[str, Any] = {
        "provider": "anthropic",
        "model": "claude-opus-4-6",
    }
    defaults.update(kw)
    return ModelPolicy(**defaults)


def _msgs_multi() -> list[dict[str, str]]:
    return [
        {"role": "system", "content": "SYS"},
        {"role": "user", "content": "U1"},
        {"role": "assistant", "content": "A1"},
        {"role": "user", "content": "U2"},
        {"role": "assistant", "content": "A2"},
        {"role": "user", "content": "U3"},
    ]


def _has_cache(block: dict) -> bool:
    content = block["content"]
    if isinstance(content, list) and content:
        return content[-1].get("cache_control") == {"type": "ephemeral"}
    return False


def test_prepare_legacy_none_is_backwards_compatible() -> None:
    """``cache_breakpoints=None`` caches system + first user turn."""
    sys_block, msgs = _prov()._prepare(_msgs_multi(), _policy())
    assert sys_block[0]["cache_control"] == {"type": "ephemeral"}
    assert _has_cache(msgs[0])  # U1
    assert not _has_cache(msgs[2])  # U2 plain
    assert not _has_cache(msgs[4])  # U3 plain
    assert msgs[1]["content"] == "A1"  # assistant untouched


def test_prepare_empty_list_disables_cache_entirely() -> None:
    """``cache_breakpoints=[]`` = explicit disable, no cache_control."""
    policy = _policy(cache_breakpoints=[])
    sys_block, msgs = _prov()._prepare(_msgs_multi(), policy)
    assert "cache_control" not in sys_block[0]
    for m in msgs:
        assert not _has_cache(m)


def test_prepare_explicit_indices_mark_listed_positions() -> None:
    """``cache_breakpoints=[0, 2]`` caches system + msgs[0] + msgs[2]."""
    policy = _policy(cache_breakpoints=[0, 2])
    sys_block, msgs = _prov()._prepare(_msgs_multi(), policy)
    assert sys_block[0]["cache_control"] == {"type": "ephemeral"}
    assert _has_cache(msgs[0])  # U1
    assert _has_cache(msgs[2])  # U2
    assert not _has_cache(msgs[4])  # U3 plain


def test_prepare_explicit_negative_indices_supported() -> None:
    """Negative indices count from the end."""
    policy = _policy(cache_breakpoints=[-1])
    _, msgs = _prov()._prepare(_msgs_multi(), policy)
    assert _has_cache(msgs[-1])  # U3
    assert not _has_cache(msgs[0])  # U1 plain


def test_prepare_explicit_out_of_range_raises() -> None:
    """OOB indices raise ProviderError, not silent swallow."""
    policy = _policy(cache_breakpoints=[99])
    with pytest.raises(ProviderError) as ei:
        _prov()._prepare(_msgs_multi(), policy)
    assert "out of range" in ei.value.detail


def test_prepare_multiturn_strategy_caches_three_points() -> None:
    """``cache_strategy=multiturn`` caches system + 1st user + 3rd-from-last user."""
    policy = _policy(extra={"cache_strategy": "multiturn"})
    sys_block, msgs = _prov()._prepare(_msgs_multi(), policy)
    assert sys_block[0]["cache_control"] == {"type": "ephemeral"}
    # Users are at indices 0 (U1), 2 (U2), 4 (U3); 3rd-from-last = U1.
    # With 3 user turns, first and third-from-last collapse to the
    # same index, yielding 2 breakpoints total (system + U1).
    assert _has_cache(msgs[0])  # U1
    # Add more turns to make first and third-from-last distinct.
    extended = _msgs_multi() + [
        {"role": "assistant", "content": "A3"},
        {"role": "user", "content": "U4"},
        {"role": "assistant", "content": "A4"},
        {"role": "user", "content": "U5"},
    ]
    sys_block, msgs = _prov()._prepare(extended, policy)
    # Users: U1(0) U2(2) U3(4) U4(6) U5(8). 3rd-from-last = U3 at 4.
    assert _has_cache(msgs[0])  # U1 (first)
    assert _has_cache(msgs[4])  # U3 (3rd-from-last)
    assert not _has_cache(msgs[6])  # U4 plain
    assert not _has_cache(msgs[8])  # U5 plain (latest, kept hot)


def test_prepare_length_guard_skips_short_system_prompt() -> None:
    """``cache_min_chars`` above system prompt length skips all cache."""
    policy = _policy(extra={"cache_min_chars": 10_000})
    sys_block, msgs = _prov()._prepare(_msgs_multi(), policy)
    assert "cache_control" not in sys_block[0]
    for m in msgs:
        assert not _has_cache(m)


def test_prepare_length_guard_passes_long_system_prompt() -> None:
    """When system prompt meets ``cache_min_chars``, legacy caching applies."""
    long_sys = "x" * 5000
    msgs_in = [
        {"role": "system", "content": long_sys},
        {"role": "user", "content": "U1"},
        {"role": "assistant", "content": "A1"},
        {"role": "user", "content": "U2"},
    ]
    policy = _policy(extra={"cache_min_chars": 4096})
    sys_block, msgs = _prov()._prepare(msgs_in, policy)
    assert sys_block[0]["cache_control"] == {"type": "ephemeral"}
    assert _has_cache(msgs[0])  # U1 cached via legacy path


def test_prepare_single_user_turn_skips_first_user_cache() -> None:
    """One-shot calls don't benefit from first-user cache — skip it."""
    msgs_in = [
        {"role": "system", "content": "SYS"},
        {"role": "user", "content": "ONE"},
    ]
    sys_block, msgs = _prov()._prepare(msgs_in, _policy())
    assert sys_block[0]["cache_control"] == {"type": "ephemeral"}
    assert not _has_cache(msgs[0])  # user content stays plain string
    assert msgs[0]["content"] == "ONE"


# ─────────────── Anthropic cache_ttl (5m default / 1h beta) ───────────────
#
# Tests that ``policy.extra["cache_ttl"]`` threads through every
# cache_control block Anthropic emits, and that the 1h value
# triggers the beta-header gate :func:`_needs_extended_ttl_beta`.


def test_cache_control_helper_default_is_5m_no_ttl_field() -> None:
    """``None`` and ``"5m"`` both produce legacy shape without ttl key."""
    from persona.providers.anthropic import _cache_control

    assert _cache_control(None) == {"type": "ephemeral"}
    assert _cache_control("5m") == {"type": "ephemeral"}


def test_cache_control_helper_1h_adds_ttl_field() -> None:
    """``"1h"`` adds the ttl field that the Anthropic beta requires."""
    from persona.providers.anthropic import _cache_control

    assert _cache_control("1h") == {"type": "ephemeral", "ttl": "1h"}


def test_cache_control_helper_invalid_raises_value_error() -> None:
    """Unknown TTLs fail early with ValueError, not silent 5m fallback."""
    from persona.providers.anthropic import _cache_control

    with pytest.raises(ValueError, match="unsupported cache_ttl"):
        _cache_control("10m")


def test_needs_extended_ttl_beta_only_for_1h() -> None:
    """Beta header gate fires only on 1h, not on None/5m/other."""
    from persona.providers.anthropic import _needs_extended_ttl_beta

    assert _needs_extended_ttl_beta(_policy()) is False
    assert _needs_extended_ttl_beta(
        _policy(extra={"cache_ttl": "5m"}),
    ) is False
    assert _needs_extended_ttl_beta(
        _policy(extra={"cache_ttl": "1h"}),
    ) is True


def test_prepare_ttl_1h_threads_through_system_and_user_blocks() -> None:
    """``cache_ttl=1h`` reaches every cache_control block, not just system."""
    policy = _policy(extra={"cache_ttl": "1h"})
    sys_block, msgs = _prov()._prepare(_msgs_multi(), policy)
    expected = {"type": "ephemeral", "ttl": "1h"}
    assert sys_block[0]["cache_control"] == expected
    # Legacy mode caches first user turn — it must also carry ttl.
    first_user = msgs[0]
    assert first_user["content"][-1]["cache_control"] == expected


def test_prepare_ttl_5m_explicit_matches_default() -> None:
    """``cache_ttl="5m"`` is identical to the default (None) shape."""
    policy = _policy(extra={"cache_ttl": "5m"})
    sys_block, msgs = _prov()._prepare(_msgs_multi(), policy)
    assert sys_block[0]["cache_control"] == {"type": "ephemeral"}
    # First user turn cache_control has no ttl field.
    assert msgs[0]["content"][-1]["cache_control"] == {"type": "ephemeral"}


def test_prepare_ttl_invalid_raises_provider_error() -> None:
    """Bad ttl surfaces as ProviderError, not a 400 from upstream."""
    policy = _policy(extra={"cache_ttl": "10m"})
    with pytest.raises(ProviderError) as ei:
        _prov()._prepare(_msgs_multi(), policy)
    assert "unsupported cache_ttl" in ei.value.detail


def test_prepare_ttl_1h_works_with_explicit_breakpoints() -> None:
    """1h ttl + explicit breakpoints: all marked blocks get the ttl."""
    policy = _policy(extra={"cache_ttl": "1h"}, cache_breakpoints=[0, 2])
    sys_block, msgs = _prov()._prepare(_msgs_multi(), policy)
    expected = {"type": "ephemeral", "ttl": "1h"}
    assert sys_block[0]["cache_control"] == expected
    assert msgs[0]["content"][-1]["cache_control"] == expected
    assert msgs[2]["content"][-1]["cache_control"] == expected


# ───────────── Cache hit-rate telemetry (cumulative across calls) ─────────────


def test_cache_hit_rate_starts_as_none_before_any_call() -> None:
    """No cache activity yet = no data, return ``None`` not ``0.0``."""
    provider = _prov()
    assert provider.cache_hit_rate is None
    assert provider.cache_totals == {"creation": 0, "read": 0, "calls": 0}


def test_record_usage_accumulates_cache_counters() -> None:
    """Successive ``_record_usage`` calls sum into ``cache_totals``."""
    provider = _prov()
    provider._record_usage(UsageStats(
        input_tokens=100,
        output_tokens=50,
        cache_creation_input_tokens=200,
        cache_read_input_tokens=0,
    ))
    provider._record_usage(UsageStats(
        input_tokens=10,
        output_tokens=5,
        cache_creation_input_tokens=0,
        cache_read_input_tokens=200,
    ))
    assert provider.cache_totals == {
        "creation": 200, "read": 200, "calls": 2,
    }


def test_cache_hit_rate_computes_read_over_total() -> None:
    """``cache_hit_rate == read / (read + creation)`` across calls."""
    provider = _prov()
    # Call 1: all write (creation=300, read=0) → miss band.
    provider._record_usage(UsageStats(
        cache_creation_input_tokens=300,
        cache_read_input_tokens=0,
    ))
    # Call 2: mixed (creation=100, read=300) → partial hit.
    provider._record_usage(UsageStats(
        cache_creation_input_tokens=100,
        cache_read_input_tokens=300,
    ))
    # Totals: creation=400, read=300 → 300 / (300+400) = 3/7 ≈ 0.4286
    assert abs(provider.cache_hit_rate - 3 / 7) < 1e-9


def test_record_usage_none_does_not_count_call() -> None:
    """A ``None`` usage leaves counters untouched (no phantom call)."""
    provider = _prov()
    provider._record_usage(UsageStats(cache_read_input_tokens=50))
    provider._record_usage(None)
    assert provider.cache_totals["calls"] == 1
    assert provider.cache_totals["read"] == 50


def test_cache_totals_returns_shallow_copy() -> None:
    """Mutating the returned dict must not corrupt provider state."""
    provider = _prov()
    provider._record_usage(UsageStats(
        cache_creation_input_tokens=100,
        cache_read_input_tokens=50,
    ))
    snapshot = provider.cache_totals
    snapshot["read"] = 9999  # caller mutates their copy
    assert provider.cache_totals["read"] == 50  # provider untouched


def test_cache_hit_rate_all_misses_is_zero_not_none() -> None:
    """When only writes happen, hit rate is 0.0 (not None — we have data)."""
    provider = _prov()
    provider._record_usage(UsageStats(
        cache_creation_input_tokens=500,
        cache_read_input_tokens=0,
    ))
    assert provider.cache_hit_rate == 0.0


def test_cache_hit_rate_all_hits_is_one() -> None:
    """Pure cache reads (no new writes) = 100% hit rate."""
    provider = _prov()
    provider._record_usage(UsageStats(
        cache_creation_input_tokens=0,
        cache_read_input_tokens=500,
    ))
    assert provider.cache_hit_rate == 1.0


def test_record_usage_handles_none_fields_as_zero() -> None:
    """UsageStats fields that are None accumulate as 0, not raise."""
    provider = _prov()
    provider._record_usage(UsageStats(
        input_tokens=10,
        # cache fields left as None — common for non-cached calls
    ))
    assert provider.cache_totals == {"creation": 0, "read": 0, "calls": 1}
    assert provider.cache_hit_rate is None  # denominator still zero


# ─────────────────── Engine dispatch ───────────────────


class _FakeProvider:
    """Records the last call for engine dispatch assertions."""

    name = "fake"

    def __init__(self) -> None:
        self.calls: list[tuple[list[dict], ModelPolicy]] = []

    async def generate(
        self,
        messages: list[dict[str, str]],
        policy: ModelPolicy,
    ) -> str:
        self.calls.append((messages, policy))
        return "fake response"


def test_engine_dispatches_through_registry() -> None:
    reg = ProviderRegistry()
    fake = _FakeProvider()
    reg.register_instance("fake", fake)  # type: ignore[arg-type]
    engine = PersonaEngine(provider_registry=reg)

    policy = ModelPolicy(provider="fake", model="fake-model")
    messages = [{"role": "user", "content": "hi"}]
    result = asyncio.run(engine._llm_via_provider(policy, messages))

    assert result == "fake response"
    assert len(fake.calls) == 1
    assert fake.calls[0][1].provider == "fake"


def test_engine_provider_error_surfaces() -> None:
    reg = ProviderRegistry()

    class _BoomProvider:
        name = "boom"

        async def generate(self, messages, policy):  # noqa: ARG002
            raise ProviderError("boom", "simulated")

    reg.register_instance("boom", _BoomProvider())  # type: ignore[arg-type]
    engine = PersonaEngine(provider_registry=reg)

    policy = ModelPolicy(provider="boom", model="x")
    with pytest.raises(ProviderError) as ei:
        asyncio.run(
            engine._llm_via_provider(
                policy, [{"role": "user", "content": "hi"}],
            ),
        )
    assert ei.value.provider == "boom"


def test_engine_wraps_unexpected_exception() -> None:
    reg = ProviderRegistry()

    class _Chaos:
        name = "chaos"

        async def generate(self, messages, policy):  # noqa: ARG002
            raise RuntimeError("unexpected")

    reg.register_instance("chaos", _Chaos())  # type: ignore[arg-type]
    engine = PersonaEngine(provider_registry=reg)

    policy = ModelPolicy(provider="chaos", model="x")
    with pytest.raises(ProviderError) as ei:
        asyncio.run(
            engine._llm_via_provider(
                policy, [{"role": "user", "content": "hi"}],
            ),
        )
    assert ei.value.provider == "chaos"
    assert "unexpected" in ei.value.detail


# ─────────────────── Non-stream usage telemetry ───────────────────
#
# UsageStats sidechannel contract: every adapter exposes
# ``last_usage`` initialised to None. After a successful generate()
# it must be populated from the wire response. Anthropic gets all 4
# fields; OpenAI / Groq only get input_tokens + output_tokens (cache
# fields stay None). Ollama always stays None.


def test_all_providers_initialize_last_usage_to_none() -> None:
    """Protocol contract: every adapter starts with last_usage=None."""
    assert AnthropicProvider(api_key="k").last_usage is None
    assert OpenAIProvider(api_key="k").last_usage is None
    assert GroqProvider(api_key="k").last_usage is None
    assert OllamaProvider().last_usage is None


def test_usage_stats_dataclass_shape() -> None:
    """UsageStats is frozen + defaults all four fields to None."""
    u = UsageStats()
    assert u.input_tokens is None
    assert u.output_tokens is None
    assert u.cache_creation_input_tokens is None
    assert u.cache_read_input_tokens is None
    # Frozen: mutating should raise.
    with pytest.raises(Exception):  # noqa: B017 — FrozenInstanceError
        u.input_tokens = 5  # type: ignore[misc]


class _FakeAnthropicUsage:
    """Mimics ``response.usage`` on the Anthropic SDK."""

    def __init__(
        self,
        input_tokens: int | None = None,
        output_tokens: int | None = None,
        cache_creation_input_tokens: int | None = None,
        cache_read_input_tokens: int | None = None,
    ) -> None:
        self.input_tokens = input_tokens
        self.output_tokens = output_tokens
        self.cache_creation_input_tokens = cache_creation_input_tokens
        self.cache_read_input_tokens = cache_read_input_tokens


class _FakeAnthropicContentBlock:
    def __init__(self, text: str) -> None:
        self.type = "text"
        self.text = text


class _FakeAnthropicResponse:
    def __init__(
        self,
        text: str,
        usage: _FakeAnthropicUsage | None,
    ) -> None:
        self.content = [_FakeAnthropicContentBlock(text)]
        self.usage = usage


class _FakeAnthropicMessages:
    def __init__(self, resp: _FakeAnthropicResponse) -> None:
        self._resp = resp

    async def create(self, **_: Any) -> _FakeAnthropicResponse:
        return self._resp


class _FakeAsyncAnthropic:
    """Minimal stand-in for the Anthropic SDK AsyncAnthropic client.

    The provider constructs a client inline inside ``generate()``;
    we override ``sys.modules['anthropic']`` with a module object
    whose ``AsyncAnthropic`` attribute returns this class.
    """

    def __init__(self, **_: Any) -> None:
        self.messages = _FakeAnthropicMessages(
            _FakeAsyncAnthropic._next_response,  # type: ignore[arg-type]
        )

    _next_response: _FakeAnthropicResponse | None = None


def _install_fake_anthropic(
    monkeypatch: pytest.MonkeyPatch,
    resp: _FakeAnthropicResponse,
) -> None:
    """Swap ``sys.modules['anthropic']`` for a fake returning ``resp``."""
    import sys
    import types

    mod = types.ModuleType("anthropic")
    _FakeAsyncAnthropic._next_response = resp  # type: ignore[assignment]
    mod.AsyncAnthropic = _FakeAsyncAnthropic  # type: ignore[attr-defined]
    monkeypatch.setitem(sys.modules, "anthropic", mod)


def test_anthropic_non_stream_captures_full_usage(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """All 4 fields land on last_usage after a cache-hit call."""
    resp = _FakeAnthropicResponse(
        text="hi",
        usage=_FakeAnthropicUsage(
            input_tokens=100,
            output_tokens=20,
            cache_creation_input_tokens=0,
            cache_read_input_tokens=80,
        ),
    )
    _install_fake_anthropic(monkeypatch, resp)

    provider = AnthropicProvider(api_key="sk-ant-fake")
    policy = ModelPolicy(provider="anthropic", model="claude-opus-4-6")
    result = asyncio.run(
        provider.generate(
            [
                {"role": "system", "content": "be brief"},
                {"role": "user", "content": "u"},
            ],
            policy,
        ),
    )
    assert result == "hi"
    assert provider.last_usage is not None
    assert provider.last_usage.input_tokens == 100
    assert provider.last_usage.output_tokens == 20
    assert provider.last_usage.cache_creation_input_tokens == 0
    assert provider.last_usage.cache_read_input_tokens == 80


def test_anthropic_non_stream_missing_usage_stays_none(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """SDK response without ``usage`` degrades to last_usage=None."""
    resp = _FakeAnthropicResponse(text="hi", usage=None)
    _install_fake_anthropic(monkeypatch, resp)

    provider = AnthropicProvider(api_key="sk-ant-fake")
    policy = ModelPolicy(provider="anthropic", model="claude-opus-4-6")
    asyncio.run(
        provider.generate(
            [
                {"role": "system", "content": "s"},
                {"role": "user", "content": "u"},
            ],
            policy,
        ),
    )
    assert provider.last_usage is None


# ── Opus 4.7 sampling-param compatibility ──────────────────


@pytest.mark.parametrize(
    "model_id,expected",
    [
        ("claude-opus-4-7", True),
        ("claude-opus-4-7-20260416", True),
        ("claude-opus-4-8", True),
        ("claude-opus-5-0", True),
        ("claude-opus-4-6", False),
        ("claude-opus-4-5", False),
        ("claude-opus-4-1", False),
        ("claude-opus-3-5", False),
        ("claude-sonnet-4-6", False),
        ("claude-haiku-4-5", False),
        ("claude-opus", False),
        ("claude-opus-vnext", False),
    ],
)
def test_is_opus_4_7_plus_detector(model_id: str, expected: bool) -> None:
    from persona.providers.anthropic import _is_opus_4_7_plus
    assert _is_opus_4_7_plus(model_id) is expected


class _RecordingAnthropicMessages:
    """Fake that captures kwargs for assertion."""

    def __init__(self, resp: _FakeAnthropicResponse) -> None:
        self._resp = resp
        self.last_kwargs: dict[str, Any] = {}

    async def create(self, **kwargs: Any) -> _FakeAnthropicResponse:
        self.last_kwargs = kwargs
        return self._resp


class _RecordingAsyncAnthropic:
    _messages_holder: _RecordingAnthropicMessages | None = None

    def __init__(self, **_: Any) -> None:
        # Reuse the singleton so the test can inspect captured kwargs.
        assert _RecordingAsyncAnthropic._messages_holder is not None
        self.messages = _RecordingAsyncAnthropic._messages_holder


def _install_recording_anthropic(
    monkeypatch: pytest.MonkeyPatch,
    resp: _FakeAnthropicResponse,
) -> _RecordingAnthropicMessages:
    import sys
    import types

    mod = types.ModuleType("anthropic")
    holder = _RecordingAnthropicMessages(resp)
    _RecordingAsyncAnthropic._messages_holder = holder
    mod.AsyncAnthropic = _RecordingAsyncAnthropic  # type: ignore[attr-defined]
    monkeypatch.setitem(sys.modules, "anthropic", mod)
    return holder


def test_anthropic_opus_4_7_strips_temperature(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Opus 4.7 rejects non-default temperature with 400 — must not be sent."""
    resp = _FakeAnthropicResponse(text="ok", usage=None)
    holder = _install_recording_anthropic(monkeypatch, resp)

    provider = AnthropicProvider(api_key="sk-ant-fake")
    policy = ModelPolicy(
        provider="anthropic", model="claude-opus-4-7", temperature=0.5,
    )
    asyncio.run(
        provider.generate(
            [{"role": "user", "content": "u"}], policy,
        ),
    )
    assert holder.last_kwargs["model"] == "claude-opus-4-7"
    assert "temperature" not in holder.last_kwargs
    assert "top_p" not in holder.last_kwargs
    assert "top_k" not in holder.last_kwargs


def test_anthropic_opus_4_6_keeps_temperature(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Pre-4.7 Opus (and all Sonnet/Haiku) still accept temperature."""
    resp = _FakeAnthropicResponse(text="ok", usage=None)
    holder = _install_recording_anthropic(monkeypatch, resp)

    provider = AnthropicProvider(api_key="sk-ant-fake")
    policy = ModelPolicy(
        provider="anthropic", model="claude-opus-4-6", temperature=0.5,
    )
    asyncio.run(
        provider.generate(
            [{"role": "user", "content": "u"}], policy,
        ),
    )
    assert holder.last_kwargs["temperature"] == 0.5


def test_anthropic_sonnet_keeps_temperature(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    resp = _FakeAnthropicResponse(text="ok", usage=None)
    holder = _install_recording_anthropic(monkeypatch, resp)

    provider = AnthropicProvider(api_key="sk-ant-fake")
    policy = ModelPolicy(
        provider="anthropic", model="claude-sonnet-4-6", temperature=0.4,
    )
    asyncio.run(
        provider.generate(
            [{"role": "user", "content": "u"}], policy,
        ),
    )
    assert holder.last_kwargs["temperature"] == 0.4


def test_openai_non_stream_maps_usage_fields() -> None:
    """OpenAI ``usage.prompt_tokens`` / ``completion_tokens`` land on UsageStats."""
    client = _FakeHttpxClient({
        "completions": {
            "choices": [{"message": {"content": "gpt says hi"}}],
            "usage": {
                "prompt_tokens": 50,
                "completion_tokens": 12,
                "total_tokens": 62,
            },
        },
    })
    provider = OpenAIProvider(
        api_key="sk-fake",
        base_url="http://fake/v1",
        client=client,  # type: ignore[arg-type]
    )
    policy = ModelPolicy(provider="openai", model="gpt-5")
    asyncio.run(
        provider.generate([{"role": "user", "content": "hi"}], policy),
    )
    assert provider.last_usage is not None
    assert provider.last_usage.input_tokens == 50
    assert provider.last_usage.output_tokens == 12
    # OpenAI has no cache telemetry — cache fields stay None.
    assert provider.last_usage.cache_creation_input_tokens is None
    assert provider.last_usage.cache_read_input_tokens is None


def test_openai_non_stream_missing_usage_stays_none() -> None:
    """Response without ``usage`` leaves last_usage at None."""
    client = _FakeHttpxClient(
        {"completions": _openai_style_payload("gpt says hi")},
    )
    provider = OpenAIProvider(
        api_key="sk-fake",
        base_url="http://fake/v1",
        client=client,  # type: ignore[arg-type]
    )
    policy = ModelPolicy(provider="openai", model="gpt-5")
    asyncio.run(
        provider.generate([{"role": "user", "content": "hi"}], policy),
    )
    assert provider.last_usage is None


def test_groq_non_stream_maps_usage_fields() -> None:
    """Groq mirrors OpenAI usage shape exactly."""
    client = _FakeHttpxClient({
        "completions": {
            "choices": [{"message": {"content": "llama says hi"}}],
            "usage": {
                "prompt_tokens": 77,
                "completion_tokens": 9,
                "total_tokens": 86,
            },
        },
    })
    provider = GroqProvider(
        api_key="gsk-fake",
        base_url="http://fake/openai/v1",
        client=client,  # type: ignore[arg-type]
    )
    policy = ModelPolicy(provider="groq", model="llama-4-scout")
    asyncio.run(
        provider.generate([{"role": "user", "content": "hi"}], policy),
    )
    assert provider.last_usage is not None
    assert provider.last_usage.input_tokens == 77
    assert provider.last_usage.output_tokens == 9
    assert provider.last_usage.cache_read_input_tokens is None


def test_ollama_non_stream_always_none() -> None:
    """Ollama has no usage surface — stays None after any success."""
    client = _FakeHttpxClient(
        {"completions": _openai_style_payload("gemma says hi")},
    )
    provider = OllamaProvider(
        base_url="http://fake/v1", client=client,  # type: ignore[arg-type]
    )
    policy = ModelPolicy(provider="ollama", model="gemma3:27b")
    asyncio.run(
        provider.generate([{"role": "user", "content": "hi"}], policy),
    )
    assert provider.last_usage is None
