"""Contract tests for :class:`persona.providers.LocalInProcessProvider`.

Covers
------
* Protocol conformance (``LLMProvider`` isinstance check).
* ``_split_system`` helper — pulls ``role=system`` off the front of
  a chat history and leaves the tail intact.
* ``generate`` happy path via injected fake backend.
* ``generate`` empty response + backend exception → ``ProviderError``.
* ``generate_with_tools`` happy path: translates ``ToolSpec`` → OpenAI
  function shape, parses ``tool_calls`` from fake backend dict.
* ``generate_with_tools`` text-only path + ``finish_reason`` mapping.
* ``generate_stream`` yields a single chunk equal to the full text.
* ``ProviderRegistry.default()`` respects ``GEMMA_VENDOR=inproc`` env
  override and always registers the explicit ``local_inproc`` name.

Every test is hermetic — no llama.cpp import, no real GGUF load, no
concinno runtime dep pulled in. Injected fake backends mirror the
:class:`concinno.llm_runtime.in_process.InProcessLlamaCppBackend` API
surface (``chat`` + ``chat_with_tools``) so a real backend drop-in
satisfies the same contract.
"""

from __future__ import annotations

import asyncio
from typing import Any

import pytest

from persona.providers import (
    LLMProvider,
    LocalInProcessProvider,
    ModelPolicy,
    OllamaProvider,
    ProviderError,
    ProviderRegistry,
    ToolSpec,
)
from persona.providers.local_inproc import _split_system


# ─────────────────── Fakes ───────────────────


class _FakeBackend:
    """In-memory stand-in for ``InProcessLlamaCppBackend``.

    Records every call so tests can assert on message translation
    + kwargs, and returns whatever canned shape the test set up via
    :attr:`chat_return` / :attr:`chat_with_tools_return`.
    """

    def __init__(
        self,
        chat_return: str = "",
        chat_with_tools_return: dict[str, Any] | None = None,
        chat_raises: Exception | None = None,
    ) -> None:
        self.chat_return = chat_return
        self.chat_with_tools_return = chat_with_tools_return or {
            "message": {"content": "ok", "tool_calls": []},
            "finish_reason": "stop",
        }
        self.chat_raises = chat_raises
        self.chat_calls: list[dict[str, Any]] = []
        self.chat_with_tools_calls: list[dict[str, Any]] = []

    def chat(
        self,
        system: str,
        messages: list[dict[str, Any]],
        max_tokens: int = 2000,
        temperature: float = 0.3,
    ) -> str:
        if self.chat_raises is not None:
            raise self.chat_raises
        self.chat_calls.append({
            "system": system,
            "messages": messages,
            "max_tokens": max_tokens,
            "temperature": temperature,
        })
        return self.chat_return

    def chat_with_tools(
        self,
        system: str,
        messages: list[dict[str, Any]],
        tools: list[dict[str, Any]] | None = None,
        max_tokens: int = 2000,
        temperature: float = 0.3,
    ) -> dict[str, Any]:
        if self.chat_raises is not None:
            raise self.chat_raises
        self.chat_with_tools_calls.append({
            "system": system,
            "messages": messages,
            "tools": tools,
            "max_tokens": max_tokens,
            "temperature": temperature,
        })
        return self.chat_with_tools_return


def _policy(**kw: Any) -> ModelPolicy:
    """Factory with sensible test defaults."""
    defaults = {
        "provider": "local_inproc",
        "model": "gemma-4-31b-q4",
        "max_tokens": 256,
        "temperature": 0.0,
    }
    defaults.update(kw)
    return ModelPolicy(**defaults)


# ─────────────────── _split_system helper ───────────────────


def test_split_system_peels_leading_system_block() -> None:
    system, rest = _split_system([
        {"role": "system", "content": "sys"},
        {"role": "user", "content": "u1"},
        {"role": "assistant", "content": "a1"},
    ])
    assert system == "sys"
    assert rest == [
        {"role": "user", "content": "u1"},
        {"role": "assistant", "content": "a1"},
    ]


def test_split_system_returns_empty_when_no_system_role() -> None:
    system, rest = _split_system([
        {"role": "user", "content": "hi"},
    ])
    assert system == ""
    assert rest == [{"role": "user", "content": "hi"}]


def test_split_system_serialises_non_string_system_content() -> None:
    system, _ = _split_system([
        {"role": "system", "content": [{"type": "text", "text": "x"}]},
    ])
    assert "text" in system  # JSON dump contains the key


# ─────────────────── Provider protocol + construction ───────────────────


def test_local_inproc_is_llm_provider() -> None:
    assert isinstance(LocalInProcessProvider(backend=_FakeBackend()), LLMProvider)


def test_local_inproc_name_is_local_inproc() -> None:
    p = LocalInProcessProvider(backend=_FakeBackend())
    assert p.name == "local_inproc"


def test_local_inproc_last_usage_starts_none() -> None:
    p = LocalInProcessProvider(backend=_FakeBackend())
    assert p.last_usage is None


def test_lazy_backend_construction_raises_when_concinno_missing(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """No backend injected + concinno not importable → ProviderError on call.

    We simulate the missing-concinno case by clobbering the import
    name so ``_ensure_backend`` hits the ImportError branch.
    """
    import sys
    monkeypatch.setitem(
        sys.modules, "concinno.llm_runtime.in_process", None,
    )
    provider = LocalInProcessProvider()  # no backend, no router
    with pytest.raises(ProviderError) as excinfo:
        asyncio.run(provider.generate(
            [{"role": "user", "content": "hi"}], _policy(),
        ))
    assert "concinno.llm_runtime" in excinfo.value.detail


# ─────────────────── generate() ───────────────────


def test_generate_returns_text_from_backend() -> None:
    backend = _FakeBackend(chat_return="  hello world  ")
    provider = LocalInProcessProvider(backend=backend)
    result = asyncio.run(provider.generate(
        [
            {"role": "system", "content": "you are helpful"},
            {"role": "user", "content": "hi"},
        ],
        _policy(max_tokens=128, temperature=0.5),
    ))
    assert result == "hello world"
    # Backend saw system stripped to its own arg; messages tail preserved.
    assert len(backend.chat_calls) == 1
    call = backend.chat_calls[0]
    assert call["system"] == "you are helpful"
    assert call["messages"] == [{"role": "user", "content": "hi"}]
    assert call["max_tokens"] == 128
    assert call["temperature"] == 0.5


def test_generate_empty_response_raises_provider_error() -> None:
    provider = LocalInProcessProvider(backend=_FakeBackend(chat_return=""))
    with pytest.raises(ProviderError) as excinfo:
        asyncio.run(provider.generate(
            [{"role": "user", "content": "hi"}], _policy(),
        ))
    assert "empty response" in excinfo.value.detail


def test_generate_backend_exception_raises_provider_error() -> None:
    provider = LocalInProcessProvider(backend=_FakeBackend(
        chat_raises=RuntimeError("cuda OOM"),
    ))
    with pytest.raises(ProviderError) as excinfo:
        asyncio.run(provider.generate(
            [{"role": "user", "content": "hi"}], _policy(),
        ))
    assert "cuda OOM" in excinfo.value.detail


# ─────────────────── generate_with_tools() ───────────────────


def test_generate_with_tools_parses_tool_calls() -> None:
    backend = _FakeBackend(chat_with_tools_return={
        "message": {
            "content": None,
            "tool_calls": [
                {
                    "id": "call_abc",
                    "function": {
                        "name": "get_weather",
                        "arguments": '{"city": "Taipei"}',
                    },
                },
            ],
        },
        "finish_reason": "tool_calls",
    })
    provider = LocalInProcessProvider(backend=backend)
    spec = ToolSpec(
        name="get_weather",
        description="weather lookup",
        input_schema={"type": "object", "properties": {}},
    )
    resp = asyncio.run(provider.generate_with_tools(
        [
            {"role": "system", "content": "be useful"},
            {"role": "user", "content": "weather?"},
        ],
        _policy(), [spec],
    ))
    assert resp.text is None
    assert len(resp.tool_calls) == 1
    tc = resp.tool_calls[0]
    assert tc.id == "call_abc"
    assert tc.name == "get_weather"
    assert tc.input == {"city": "Taipei"}
    # OpenAI-style "tool_calls" finish reason → Anthropic "tool_use".
    assert resp.stop_reason == "tool_use"
    # Backend received OpenAI-shaped tools kwarg.
    tools_sent = backend.chat_with_tools_calls[0]["tools"]
    assert tools_sent[0]["type"] == "function"
    assert tools_sent[0]["function"]["name"] == "get_weather"


def test_generate_with_tools_text_only_maps_stop_reason() -> None:
    backend = _FakeBackend(chat_with_tools_return={
        "message": {
            "content": "final answer is 1.456",
            "tool_calls": [],
        },
        "finish_reason": "length",
    })
    provider = LocalInProcessProvider(backend=backend)
    resp = asyncio.run(provider.generate_with_tools(
        [{"role": "user", "content": "q"}], _policy(), [],
    ))
    assert resp.text == "final answer is 1.456"
    assert resp.tool_calls == []
    # OpenAI "length" → Anthropic "max_tokens".
    assert resp.stop_reason == "max_tokens"


def test_generate_with_tools_handles_malformed_arguments() -> None:
    """Non-JSON ``arguments`` preserved under ``_raw`` key — mirrors
    OpenAI / Ollama provider behaviour so the agent loop sees the
    same degrade shape regardless of backend."""
    backend = _FakeBackend(chat_with_tools_return={
        "message": {
            "tool_calls": [
                {
                    "id": "call_x",
                    "function": {
                        "name": "foo",
                        "arguments": "{not json",
                    },
                },
            ],
        },
        "finish_reason": "tool_calls",
    })
    provider = LocalInProcessProvider(backend=backend)
    resp = asyncio.run(provider.generate_with_tools(
        [{"role": "user", "content": "go"}], _policy(), [],
    ))
    assert resp.tool_calls[0].input == {"_raw": "{not json"}


def test_generate_with_tools_synthesises_missing_call_id() -> None:
    backend = _FakeBackend(chat_with_tools_return={
        "message": {
            "tool_calls": [
                {
                    "function": {
                        "name": "foo",
                        "arguments": "{}",
                    },
                },
            ],
        },
        "finish_reason": "tool_calls",
    })
    provider = LocalInProcessProvider(backend=backend)
    resp = asyncio.run(provider.generate_with_tools(
        [{"role": "user", "content": "go"}], _policy(), [],
    ))
    assert resp.tool_calls[0].id.startswith("call_")


def test_generate_with_tools_no_tools_still_returns_response() -> None:
    """Empty ``tools`` list is equivalent to text-only; backend still
    receives ``tools=None`` so the agent loop stays one-code-path."""
    backend = _FakeBackend(chat_with_tools_return={
        "message": {"content": "hi", "tool_calls": []},
        "finish_reason": "stop",
    })
    provider = LocalInProcessProvider(backend=backend)
    resp = asyncio.run(provider.generate_with_tools(
        [{"role": "user", "content": "q"}], _policy(), [],
    ))
    assert resp.text == "hi"
    assert backend.chat_with_tools_calls[0]["tools"] is None


# ─────────────────── generate_stream() ───────────────────


def test_generate_stream_yields_single_chunk_with_full_text() -> None:
    backend = _FakeBackend(chat_return="streamed once")
    provider = LocalInProcessProvider(backend=backend)

    async def drain() -> list[str]:
        chunks: list[str] = []
        async for c in provider.generate_stream(
            [{"role": "user", "content": "go"}], _policy(),
        ):
            chunks.append(c)
        return chunks

    chunks = asyncio.run(drain())
    assert chunks == ["streamed once"]


def test_generate_stream_empty_response_surfaces_provider_error() -> None:
    provider = LocalInProcessProvider(backend=_FakeBackend(chat_return=""))

    async def drain() -> list[str]:
        chunks: list[str] = []
        async for c in provider.generate_stream(
            [{"role": "user", "content": "q"}], _policy(),
        ):
            chunks.append(c)
        return chunks

    with pytest.raises(ProviderError):
        asyncio.run(drain())


# ─────────────────── ProviderRegistry GEMMA_VENDOR switch ───────────────────


def test_registry_default_ollama_is_http_when_gemma_vendor_unset(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.delenv("GEMMA_VENDOR", raising=False)
    reg = ProviderRegistry.default()
    provider = reg.get("ollama")
    assert isinstance(provider, OllamaProvider)


def test_registry_default_ollama_flips_to_inproc_when_env_set(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setenv("GEMMA_VENDOR", "inproc")
    reg = ProviderRegistry.default()
    provider = reg.get("ollama")
    assert isinstance(provider, LocalInProcessProvider)


def test_registry_explicit_local_inproc_name_always_registered(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Both env-set and env-unset deploys expose the explicit name
    so callers / tests that want unambiguous dispatch never rely on
    the env flag."""
    monkeypatch.delenv("GEMMA_VENDOR", raising=False)
    reg_a = ProviderRegistry.default()
    assert isinstance(reg_a.get("local_inproc"), LocalInProcessProvider)
    monkeypatch.setenv("GEMMA_VENDOR", "inproc")
    reg_b = ProviderRegistry.default()
    assert isinstance(reg_b.get("local_inproc"), LocalInProcessProvider)


def test_registry_gemma_vendor_case_insensitive(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setenv("GEMMA_VENDOR", "INPROC")
    reg = ProviderRegistry.default()
    assert isinstance(reg.get("ollama"), LocalInProcessProvider)


def test_registry_gemma_vendor_other_values_keep_http_path(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Only ``inproc`` flips the switch — the pre-existing
    ``llamacpp``/``vllm``/``lmstudio`` values stay on the HTTP
    ``OpenAICompatProvider`` path (they configure HTTP vendor-wire
    dialect, not in-process weight loading)."""
    for val in ("llamacpp", "vllm", "lmstudio", ""):
        monkeypatch.setenv("GEMMA_VENDOR", val)
        reg = ProviderRegistry.default()
        assert isinstance(reg.get("ollama"), OllamaProvider), (
            f"GEMMA_VENDOR={val!r} should not flip ollama → inproc"
        )


# ─────────────────── Multimodal router integration ───────────────────


class _FakeRouter:
    """Minimal ``MultimodalRouter`` stand-in.

    We only need the ``chat`` surface for ``generate()``; the real
    router's ``decide``/``capabilities`` surface is tested in
    Concinno's own test suite.
    """

    def __init__(
        self,
        text_backend: _FakeBackend,
        chat_return: str = "routed reply",
    ) -> None:
        self._text = text_backend
        self.chat_return = chat_return
        self.chat_calls: list[dict[str, Any]] = []

    def chat(
        self,
        system: str,
        messages: list[dict[str, Any]],
        max_tokens: int = 2000,
        temperature: float = 0.3,
    ) -> str:
        self.chat_calls.append({"system": system, "messages": messages})
        return self.chat_return


def test_generate_routes_through_router_when_injected(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """When a router is passed explicitly, ``generate()`` dispatches
    through it rather than the bare text backend — image messages
    then land on the vision backend inside the router without the
    provider having to know the modality up front."""
    monkeypatch.setenv("CONCINNO_LLM_VISION_GGUF_PATH", "/fake/vision.gguf")
    fake_backend = _FakeBackend()
    router = _FakeRouter(fake_backend)
    provider = LocalInProcessProvider(router=router)
    result = asyncio.run(provider.generate(
        [{"role": "user", "content": "describe"}], _policy(),
    ))
    assert result == "routed reply"
    assert len(router.chat_calls) == 1
    # Bare backend untouched — router owned the dispatch.
    assert fake_backend.chat_calls == []


def test_generate_with_tools_bypasses_router_and_uses_text_backend(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Tool-call path is text-only — vision GGUFs ship without
    function-calling templates — so the tools method always targets
    the text backend directly even when a router is wired."""
    monkeypatch.setenv("CONCINNO_LLM_VISION_GGUF_PATH", "/fake/vision.gguf")
    fake_backend = _FakeBackend(chat_with_tools_return={
        "message": {"content": "text-only", "tool_calls": []},
        "finish_reason": "stop",
    })
    router = _FakeRouter(fake_backend)
    provider = LocalInProcessProvider(
        backend=fake_backend, router=router,
    )
    resp = asyncio.run(provider.generate_with_tools(
        [{"role": "user", "content": "q"}], _policy(), [],
    ))
    assert resp.text == "text-only"
    assert len(fake_backend.chat_with_tools_calls) == 1
    assert router.chat_calls == []
