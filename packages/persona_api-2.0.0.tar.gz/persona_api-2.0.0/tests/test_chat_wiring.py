"""Tests for ``sancio chat`` REPL wiring (M1 Week 2 — sub-agent L).

Sub-agent E shipped :mod:`persona.compaction`,
:mod:`persona.slash`, and :mod:`persona.session_persist` as standalone
modules. This file covers the wiring layer in :mod:`persona.cli.chat`
that ties them together:

  * Slash dispatch goes through :class:`SlashRegistry` (not the inline
    4-cmd table the pre-1.2.0 REPL had).
  * ``ChatConfig.compactor`` triggers
    :meth:`AutoCompactor.maybe_compact` after every user turn and
    rewrites :attr:`ChatREPL.messages` in place when the threshold
    fires.
  * ``ChatConfig.session_persist`` + ``session_id`` triggers
    :meth:`SessionStore.maybe_checkpoint` after every user turn.
  * ``/compact`` slash command produces the same effect on demand.
  * ``/resume`` round-trips a snapshot back into the REPL.
  * ``/model`` rebinds ``ChatConfig.model`` so the next driver
    resolution picks up the change.
  * The legacy :attr:`ChatREPL.slash_table` view still surfaces
    name → (handler, doc) tuples for back-compat with code that
    introspected the old structure.
"""
from __future__ import annotations

from collections.abc import Sequence
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import pytest

from persona.cli.chat import (
    ChatConfig,
    ChatREPL,
    PlainPrinter,
)
from persona.compaction import (
    AutoCompactor,
    CompactionConfig,
    CompactionResult,
)
from persona.session_persist import (
    CheckpointPolicy,
    SessionStore,
    generate_session_id,
)
from persona.slash import SlashCommand, SlashContext, SlashRegistry


# ── Fakes mirroring test_chat_cli.py ──────────────────────────────


@dataclass
class _ToolCall:
    id: str
    name: str
    arguments: dict[str, Any] = field(default_factory=dict)


@dataclass
class _Response:
    text: str = ""
    tool_calls: tuple[_ToolCall, ...] = ()
    stop_reason: str = "end_turn"


class _MockDriver:
    model_id = "mock-model-1"

    def __init__(self, script: list[_Response]) -> None:
        self.script = list(script)
        self.calls: list[list[dict[str, Any]]] = []
        self.kwargs_seen: list[dict[str, Any]] = []

    def complete(
        self,
        messages: list[dict[str, Any]],
        tools: list[dict[str, Any]] | None = None,
        **kwargs: Any,
    ) -> _Response:
        self.calls.append([dict(m) for m in messages])
        self.kwargs_seen.append(dict(kwargs))
        if not self.script:
            return _Response(text="(script exhausted)", stop_reason="end_turn")
        return self.script.pop(0)


class _RecordingPrinter(PlainPrinter):
    def __init__(self) -> None:
        self.lines: list[str] = []

    def print(self, *args: Any, **kwargs: Any) -> None:
        kwargs.pop("style", None)
        kwargs.pop("highlight", None)
        self.lines.append(" ".join(str(a) for a in args))

    def rule(self, title: str = "", **_: Any) -> None:
        self.lines.append(f"--rule:{title}--")


def _make_repl(
    driver: _MockDriver,
    *,
    compactor: AutoCompactor | None = None,
    session_persist: SessionStore | None = None,
    session_id: str = "",
    printer: _RecordingPrinter | None = None,
) -> tuple[ChatREPL, _RecordingPrinter]:
    """Construct a ChatREPL with the standard scan/rich-off knobs."""
    printer = printer or _RecordingPrinter()
    repl = ChatREPL(
        config=ChatConfig(
            driver=driver,
            scan_input=False,
            use_rich=False,
            compactor=compactor,
            session_persist=session_persist,
            session_id=session_id,
        ),
        printer=printer,
    )
    return repl, printer


# ── Slash registry integration ───────────────────────────────────


def test_slash_registry_attached_by_default() -> None:
    """Without an injected registry, the REPL builds a default one."""
    repl, _ = _make_repl(_MockDriver([]))
    assert isinstance(repl.slash_registry, SlashRegistry)
    # Builtins shipped by sub-agent E:
    for name in ("clear", "compact", "status", "model", "help", "resume",
                 "exit", "quit"):
        assert name in repl.slash_registry, f"/{name} missing from default registry"


def test_slash_registry_dispatch_routes_to_builtin() -> None:
    """``/clear`` from the registry empties messages."""
    driver = _MockDriver([_Response(text="ack")])
    repl, _ = _make_repl(driver)
    repl.run(input_lines=["hello", "/clear", "/exit"])
    assert repl.messages == []


def test_slash_registry_supports_aliases() -> None:
    """``/reset`` is an alias for ``/clear`` per builtin definition."""
    driver = _MockDriver([_Response(text="ack")])
    repl, _ = _make_repl(driver)
    repl.run(input_lines=["q", "/reset", "/exit"])
    assert repl.messages == []


def test_slash_help_lists_registry_commands() -> None:
    """``/help`` enumerates every registered command."""
    repl, printer = _make_repl(_MockDriver([]))
    repl.run(input_lines=["/help", "/exit"])
    out = "\n".join(printer.lines)
    # Sub-agent E builtins must all show up.
    for name in ("clear", "compact", "status", "model", "help", "resume",
                 "exit", "quit"):
        assert f"/{name}" in out, f"/{name} missing from /help output"


def test_custom_slash_command_registered() -> None:
    """Caller-injected commands dispatch through the same registry."""
    seen: list[str] = []

    def _ping(ctx: SlashContext, args: str) -> bool:
        seen.append(args)
        ctx.printer.print(f"pong:{args}")
        return True

    repl, _ = _make_repl(_MockDriver([]))
    assert repl.slash_registry is not None
    repl.slash_registry.register(
        SlashCommand(
            name="ping",
            doc="Echo the args back as 'pong:<args>'.",
            handler=_ping,
        )
    )
    repl.run(input_lines=["/ping hello world", "/exit"])
    assert seen == ["hello world"]


def test_dispatch_slash_returns_false_on_exit() -> None:
    """``dispatch_slash('/exit')`` returns False so the loop terminates."""
    repl, _ = _make_repl(_MockDriver([]))
    assert repl.dispatch_slash("/exit") is False
    assert repl.dispatch_slash("/clear") is True


def test_unknown_slash_command_does_not_crash() -> None:
    """Unknown commands warn but keep the loop alive."""
    repl, printer = _make_repl(_MockDriver([]))
    repl.run(input_lines=["/nonsense", "/exit"])
    assert any("unknown command" in line for line in printer.lines)


# ── Legacy slash_table back-compat shim ───────────────────────────


def test_legacy_slash_table_view_lists_commands() -> None:
    """``ChatREPL.slash_table`` exposes the registry as legacy tuples."""
    repl, _ = _make_repl(_MockDriver([]))
    table = repl.slash_table
    assert "exit" in table
    assert "clear" in table
    assert "help" in table
    handler, doc = table["clear"]
    assert callable(handler)
    assert isinstance(doc, str) and doc


def test_legacy_slash_table_handler_invokes_registry() -> None:
    """Calling a legacy handler from the table mutates state correctly."""
    driver = _MockDriver([_Response(text="hi")])
    repl, _ = _make_repl(driver)
    # Seed history.
    repl.messages.append({"role": "user", "content": "x"})
    table = repl.slash_table
    handler, _doc = table["clear"]
    keep_running = handler(repl, "")
    assert keep_running is True
    assert repl.messages == []


# ── Compactor wiring ─────────────────────────────────────────────


def test_compactor_attached_via_config() -> None:
    """``ChatConfig.compactor`` is exposed to slash handlers."""
    compactor = AutoCompactor(CompactionConfig(context_window=1000))
    repl, _ = _make_repl(_MockDriver([]), compactor=compactor)
    ctx = repl._build_slash_context()  # noqa: SLF001 — internal probe
    assert ctx.compactor is compactor


def test_post_turn_hook_calls_maybe_compact() -> None:
    """After a normal user turn the REPL invokes maybe_compact."""

    class _SpyCompactor(AutoCompactor):
        def __init__(self) -> None:
            super().__init__(CompactionConfig(context_window=10_000))
            self.calls: list[int] = []

        def maybe_compact(  # type: ignore[override]
            self,
            messages: Sequence[dict[str, Any]],
        ) -> CompactionResult:
            self.calls.append(len(messages))
            return super().maybe_compact(messages)

    spy = _SpyCompactor()
    driver = _MockDriver([_Response(text="hi")])
    repl, _ = _make_repl(driver, compactor=spy)
    repl.run(input_lines=["hello", "/exit"])
    # One turn → one maybe_compact call (after the assistant reply).
    assert spy.calls == [2]


def test_post_turn_hook_rewrites_messages_when_triggered() -> None:
    """When the threshold crosses, ``messages`` are rewritten in place."""
    # Tiny context window forces compaction on first turn.
    cfg = CompactionConfig(
        context_window=50,
        threshold_pct=0.1,
        min_messages_to_compact=2,
        preserve_last_user_turns=1,
    )
    compactor = AutoCompactor(cfg)
    driver = _MockDriver(
        [
            _Response(text="reply-1"),
            _Response(text="reply-2"),
        ]
    )
    repl, _ = _make_repl(driver, compactor=compactor)
    # Pre-load history to exceed the threshold immediately.
    repl.messages.extend(
        [
            {"role": "user", "content": "q-old-1 " * 50},
            {"role": "assistant", "content": "a-old-1 " * 50},
            {"role": "user", "content": "q-old-2 " * 50},
            {"role": "assistant", "content": "a-old-2 " * 50},
        ]
    )
    repl.run(input_lines=["new question", "/exit"])
    # Compaction must have triggered at least once → an event landed.
    assert any(ev.triggered for ev in compactor.history)
    # The oldest message must have been replaced by a summary block.
    assert any(m.get("_compaction") for m in repl.messages)


def test_compactor_failure_does_not_break_chat(
    capsys: pytest.CaptureFixture[str],
) -> None:
    """A raising compactor logs to stderr but keeps the chat alive."""

    class _BoomCompactor:
        def maybe_compact(self, _msgs: Any) -> CompactionResult:
            raise RuntimeError("boom")

    driver = _MockDriver([_Response(text="ok")])
    repl, _ = _make_repl(driver, compactor=_BoomCompactor())  # type: ignore[arg-type]
    rc = repl.run(input_lines=["q", "/exit"])
    assert rc == 0
    err = capsys.readouterr().err
    assert "compactor" in err and "boom" in err


# ── Slash /compact integration ───────────────────────────────────


def test_slash_compact_with_no_compactor_warns() -> None:
    """``/compact`` without a compactor emits the friendly warning."""
    repl, printer = _make_repl(_MockDriver([]))
    repl.run(input_lines=["/compact", "/exit"])
    out = "\n".join(printer.lines)
    assert "no compactor" in out


def test_slash_compact_force_runs_via_registry() -> None:
    """``/compact`` triggers ``force_compact`` on the wired AutoCompactor."""
    cfg = CompactionConfig(
        context_window=10_000,
        threshold_pct=0.99,
        min_messages_to_compact=2,
        preserve_last_user_turns=1,
    )
    compactor = AutoCompactor(cfg)
    repl, printer = _make_repl(_MockDriver([]), compactor=compactor)
    repl.messages.extend(
        [
            {"role": "user", "content": "early"},
            {"role": "assistant", "content": "answer"},
            {"role": "user", "content": "middle"},
            {"role": "assistant", "content": "answer-2"},
        ]
    )
    repl.run(input_lines=["/compact", "/exit"])
    out = "\n".join(printer.lines)
    # Either a "compacted" banner or "no compaction needed" — both prove
    # the registry routed to _compact_handler.
    assert "compacted" in out or "no compaction needed" in out


# ── SessionStore wiring ──────────────────────────────────────────


def test_auto_session_id_when_persistence_attached(tmp_path: Path) -> None:
    """Empty session_id + non-None session_persist → REPL generates one."""
    store = SessionStore(
        root=tmp_path,
        policy=CheckpointPolicy(every_n_messages=1, every_n_seconds=0),
    )
    repl, _ = _make_repl(
        _MockDriver([]),
        session_persist=store,
        session_id="",
    )
    assert repl.config.session_id, "session_id should auto-populate"
    # Re-construction does not regenerate over a non-empty id.
    sid = repl.config.session_id
    repl2 = ChatREPL(
        config=ChatConfig(
            driver=_MockDriver([]),
            scan_input=False,
            use_rich=False,
            session_persist=store,
            session_id=sid,
        ),
        printer=_RecordingPrinter(),
    )
    assert repl2.config.session_id == sid


def test_post_turn_checkpoint_creates_manifest(tmp_path: Path) -> None:
    """A user turn fires SessionStore.maybe_checkpoint → manifest written."""
    sid = generate_session_id()
    store = SessionStore(
        root=tmp_path,
        policy=CheckpointPolicy(every_n_messages=1, every_n_seconds=0),
    )
    driver = _MockDriver([_Response(text="hello back")])
    repl, _ = _make_repl(
        driver,
        session_persist=store,
        session_id=sid,
    )
    repl.run(input_lines=["hi", "/exit"])
    manifest = store.get_manifest(sid)
    assert manifest is not None
    assert manifest["checkpoint_count"] >= 1
    assert manifest["message_count"] == len(repl.messages)


def test_session_store_failure_does_not_break_chat(
    tmp_path: Path,
    capsys: pytest.CaptureFixture[str],
) -> None:
    """A raising SessionStore logs to stderr but keeps the chat alive."""

    class _BoomStore:
        def maybe_checkpoint(self, *_a: Any, **_kw: Any) -> None:
            raise RuntimeError("disk full")

    driver = _MockDriver([_Response(text="ok")])
    repl, _ = _make_repl(
        driver,
        session_persist=_BoomStore(),  # type: ignore[arg-type]
        session_id="manual-sid",
    )
    rc = repl.run(input_lines=["q", "/exit"])
    assert rc == 0
    err = capsys.readouterr().err
    assert "session_persist" in err and "disk full" in err


def test_resume_round_trip_restores_messages(tmp_path: Path) -> None:
    """``/resume <sid>`` restores a previously checkpointed conversation."""
    sid = generate_session_id()
    store = SessionStore(
        root=tmp_path,
        policy=CheckpointPolicy(every_n_messages=1, every_n_seconds=0),
    )
    # Seed a checkpoint via a first REPL session.
    driver1 = _MockDriver([_Response(text="answer-from-session-1")])
    repl1, _ = _make_repl(
        driver1,
        session_persist=store,
        session_id=sid,
    )
    repl1.run(input_lines=["original question", "/exit"])
    snapshot_before = list(repl1.messages)
    assert snapshot_before  # sanity

    # Fresh REPL, empty history. /resume <sid> should rehydrate.
    driver2 = _MockDriver([])
    repl2, _ = _make_repl(
        driver2,
        session_persist=store,
        session_id="",  # different starting sid
    )
    repl2.run(input_lines=[f"/resume {sid}", "/exit"])
    assert repl2.messages == snapshot_before
    assert repl2.config.session_id == sid


def test_status_slash_includes_compactor_and_persistence(
    tmp_path: Path,
) -> None:
    """``/status`` enumerates compactor + persistence state when wired."""
    sid = generate_session_id()
    store = SessionStore(
        root=tmp_path,
        policy=CheckpointPolicy(every_n_messages=1, every_n_seconds=0),
    )
    compactor = AutoCompactor(CompactionConfig(context_window=100_000))
    driver = _MockDriver([_Response(text="ok")])
    repl, printer = _make_repl(
        driver,
        compactor=compactor,
        session_persist=store,
        session_id=sid,
    )
    repl.run(input_lines=["seed turn", "/status", "/exit"])
    out = "\n".join(printer.lines)
    assert "session_id" in out
    assert "context" in out
    assert "persistence" in out


# ── Model rebind ──────────────────────────────────────────────────


def test_model_slash_rebinds_config_model() -> None:
    """``/model opus`` updates ``ChatConfig.model`` for next driver lookup."""
    driver = _MockDriver([])
    repl, _ = _make_repl(driver)
    assert repl.config.model is None
    repl.run(input_lines=["/model opus", "/exit"])
    assert repl.config.model == "claude-opus-4-7"
