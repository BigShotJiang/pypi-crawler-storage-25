"""Tests for A6 MCP client + tool adapter.

Hermetic: we drive an in-process fake MCP server script via
:mod:`asyncio.create_subprocess_exec` so the real JSON-RPC
round-trip runs without any network or external binary. The fake
server lives as a temporary Python one-liner written to disk per
test, so CI never depends on @modelcontextprotocol/* npm packages.
"""

from __future__ import annotations

import sys
import textwrap
from pathlib import Path

import pytest

from persona.mcp import (
    MCPClient,
    MCPError,
    MCPRemoteTool,
    load_mcp_tools,
)


def _write_fake_server(tmp_path: Path, body: str) -> Path:
    """Write a Python script that speaks newline-JSON-RPC on stdio."""
    script = tmp_path / "fake_mcp.py"
    script.write_text(
        textwrap.dedent(
            """
            import json, sys

            def send(msg):
                sys.stdout.write(json.dumps(msg) + "\\n")
                sys.stdout.flush()

            def recv():
                line = sys.stdin.readline()
                if not line:
                    return None
                return json.loads(line)
            """,
        ).strip()
        + "\n"
        + body,
        encoding="utf-8",
    )
    return script


def _client(script: Path) -> MCPClient:
    return MCPClient(command=[sys.executable, str(script)])


# ─────────────────── initialize handshake ───────────────────


@pytest.mark.asyncio
async def test_connect_handshake(tmp_path: Path) -> None:
    body = textwrap.dedent(
        """
        # Responds only to 'initialize' — confirms the handshake
        # payload then exits after the 'initialized' notification.
        msg = recv()
        assert msg["method"] == "initialize"
        send({
            "jsonrpc": "2.0",
            "id": msg["id"],
            "result": {
                "protocolVersion": msg["params"]["protocolVersion"],
                "capabilities": {"tools": {}},
                "serverInfo": {"name": "fake", "version": "0.1"},
            },
        })
        # Consume the 'initialized' notification and hold open briefly
        _ = recv()
        """,
    )
    script = _write_fake_server(tmp_path, body)
    client = _client(script)
    try:
        result = await client.connect()
        assert result["serverInfo"]["name"] == "fake"
        assert "protocolVersion" in result
    finally:
        await client.close()


# ─────────────────── tools/list ───────────────────


@pytest.mark.asyncio
async def test_list_tools(tmp_path: Path) -> None:
    body = textwrap.dedent(
        """
        def handle():
            msg = recv()
            if msg is None:
                return False
            if msg.get("method") == "initialize":
                send({"jsonrpc": "2.0", "id": msg["id"], "result": {
                    "protocolVersion": msg["params"]["protocolVersion"],
                    "capabilities": {}, "serverInfo": {"name": "f"},
                }})
                return True
            if msg.get("method") == "tools/list":
                send({"jsonrpc": "2.0", "id": msg["id"], "result": {
                    "tools": [
                        {"name": "echo", "description": "echo back",
                         "inputSchema": {"type": "object",
                                          "properties": {"text": {"type": "string"}}}},
                        {"name": "add", "description": "sum",
                         "inputSchema": {}},
                    ],
                }})
                return True
            return True  # ignore notifications

        while handle():
            pass
        """,
    )
    script = _write_fake_server(tmp_path, body)
    client = _client(script)
    try:
        await client.connect()
        tools = await client.list_tools()
        names = sorted(t.name for t in tools)
        assert names == ["add", "echo"]
        echo = next(t for t in tools if t.name == "echo")
        assert echo.description == "echo back"
        assert "text" in echo.input_schema.get("properties", {})
    finally:
        await client.close()


# ─────────────────── tools/call + adapter ───────────────────


@pytest.mark.asyncio
async def test_call_tool_via_adapter(tmp_path: Path) -> None:
    body = textwrap.dedent(
        """
        def handle():
            msg = recv()
            if msg is None:
                return False
            mid = msg.get("id")
            meth = msg.get("method")
            if meth == "initialize":
                send({"jsonrpc": "2.0", "id": mid, "result": {
                    "protocolVersion": msg["params"]["protocolVersion"],
                    "capabilities": {}, "serverInfo": {"name": "f"},
                }})
            elif meth == "tools/list":
                send({"jsonrpc": "2.0", "id": mid, "result": {
                    "tools": [{"name": "echo",
                               "inputSchema": {"type": "object"}}],
                }})
            elif meth == "tools/call":
                args = msg["params"]["arguments"]
                send({"jsonrpc": "2.0", "id": mid, "result": {
                    "content": [
                        {"type": "text",
                         "text": f"echo: {args.get('text', '')}"},
                    ],
                }})
            return True

        while handle():
            pass
        """,
    )
    script = _write_fake_server(tmp_path, body)
    client = _client(script)
    try:
        await client.connect()
        tools = await load_mcp_tools(client)
        assert "mcp_echo" in tools
        assert isinstance(tools["mcp_echo"], MCPRemoteTool)

        result = await tools["mcp_echo"].execute({"text": "hi"})
        # Adapter flattens text-content lists to a plain string.
        assert result == "echo: hi"
    finally:
        await client.close()


# ─────────────────── JSON-RPC error surfaces as MCPError ──────────


@pytest.mark.asyncio
async def test_server_error_becomes_mcperror(tmp_path: Path) -> None:
    body = textwrap.dedent(
        """
        msg = recv()
        send({"jsonrpc": "2.0", "id": msg["id"], "result": {
            "protocolVersion": msg["params"]["protocolVersion"],
            "capabilities": {}, "serverInfo": {"name": "f"},
        }})
        recv()  # initialized notification
        msg = recv()  # tools/list
        send({"jsonrpc": "2.0", "id": msg["id"],
              "error": {"code": -32602, "message": "bad params"}})
        """,
    )
    script = _write_fake_server(tmp_path, body)
    client = _client(script)
    try:
        await client.connect()
        with pytest.raises(MCPError) as excinfo:
            await client.list_tools()
        assert excinfo.value.code == -32602
        assert "bad params" in str(excinfo.value)
    finally:
        await client.close()


# ─────────────────── schema shape ──────────────────


@pytest.mark.asyncio
async def test_remote_tool_schema_uses_prefixed_name() -> None:
    from persona.mcp.client import MCPTool

    class _NullClient:
        async def call_tool(self, *_a, **_k):
            return {}

    raw = MCPTool(name="echo", description="d", input_schema={"type": "object"})
    wrapped = MCPRemoteTool(
        _NullClient(),  # type: ignore[arg-type] — duck typing is fine here
        raw,
        prefix="mcp_",
    )
    schema = wrapped.schema()
    assert schema["function"]["name"] == "mcp_echo"
    assert schema["function"]["parameters"] == {"type": "object"}


# ─────────────────── close is idempotent ──────────────────


@pytest.mark.asyncio
async def test_close_is_idempotent(tmp_path: Path) -> None:
    body = textwrap.dedent(
        """
        msg = recv()
        send({"jsonrpc": "2.0", "id": msg["id"], "result": {
            "protocolVersion": msg["params"]["protocolVersion"],
            "capabilities": {}, "serverInfo": {"name": "f"},
        }})
        recv()
        # Hang waiting for more.
        import time; time.sleep(10)
        """,
    )
    script = _write_fake_server(tmp_path, body)
    client = _client(script)
    await client.connect()
    await client.close()
    # Second close must not raise.
    await client.close()
