"""5-pillar security — each pillar DENIES (not WARNS) on failure."""

from __future__ import annotations

import base64
import time
import uuid

import pytest
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import (
    Ed25519PrivateKey,
)
from starlette.applications import Starlette
from starlette.testclient import TestClient

from persona.a2a import create_a2a_routes, reset_singletons_for_tests
from persona.a2a_registry import PeerRecord, PeerRegistry
from persona.a2a_security import (
    A2ADenied,
    RateLimiter,
    check_capability,
    issue_jwt,
    sign_ed25519,
)


def _keypair():
    pk = Ed25519PrivateKey.generate()
    priv_raw = pk.private_bytes(
        serialization.Encoding.Raw,
        serialization.PrivateFormat.Raw,
        serialization.NoEncryption(),
    )
    pub_raw = pk.public_key().public_bytes(
        serialization.Encoding.Raw,
        serialization.PublicFormat.Raw,
    )
    return (
        base64.b64encode(priv_raw).decode("ascii"),
        base64.b64encode(pub_raw).decode("ascii"),
    )


@pytest.fixture()
def a2a_env(tmp_path, monkeypatch):
    reg_path = tmp_path / "peers.json"
    caps_path = tmp_path / "caps.yaml"
    limits_path = tmp_path / "limits.yaml"
    caps_path.write_text(
        "capabilities:\n"
        "  - method: agent.invoke\n"
        "    tools: [echo]\n"
        "  - method: agent.status\n",
        encoding="utf-8",
    )
    limits_path.write_text(
        "default:\n  rpm: 2\n  day_quota: 10000\noverrides: {}\n",
        encoding="utf-8",
    )

    monkeypatch.setenv("AEGIS_A2A_REGISTRY_PATH", str(reg_path))
    monkeypatch.setenv("AEGIS_A2A_AUDIT_PATH", str(tmp_path / "a.jsonl"))
    monkeypatch.setenv("AEGIS_A2A_CAPABILITIES_PATH", str(caps_path))
    monkeypatch.setenv("AEGIS_A2A_LIMITS_PATH", str(limits_path))
    monkeypatch.setenv("AEGIS_A2A_AGENT_ID", "aegis.test")
    monkeypatch.setenv("AEGIS_A2A_AUTH_MODE", "jwt")
    reset_singletons_for_tests()

    priv, pub = _keypair()
    reg = PeerRegistry(str(reg_path))
    reg.upsert(PeerRecord(
        agent_id="peer.x", endpoint="https://peer.example",
        public_key_b64=pub,
    ))
    app = Starlette(routes=create_a2a_routes())
    client = TestClient(app)
    yield client, priv, pub
    reset_singletons_for_tests()


def _env(priv, **over):
    env = {
        "id": f"req-{uuid.uuid4()}",
        "from": "peer.x",
        "to": "aegis.test",
        "method": "agent.invoke",
        "params": {"tool": "echo"},
        "nonce": str(uuid.uuid4()),
        "timestamp": int(time.time()),
    }
    env.update(over)
    env["signature"] = sign_ed25519(priv, env)
    return env


def _auth(priv, issuer="peer.x"):
    tok = issue_jwt(priv, issuer=issuer, audience="aegis.test")
    return {"Authorization": f"Bearer {tok}"}


# Pillar 1: Identity ------------------------------------------------


def test_pillar1_missing_jwt_denied_401(a2a_env):
    client, priv, _pub = a2a_env
    r = client.post("/v1/a2a/invoke", json=_env(priv))
    assert r.status_code == 401
    assert r.json()["error"]["code"] == "missing_auth"


def test_pillar1_wrong_key_jwt_denied_401(a2a_env):
    client, _priv, _pub = a2a_env
    wrong_priv, _wrong_pub = _keypair()
    # Register a peer, then present JWT signed by a DIFFERENT key.
    r = client.post(
        "/v1/a2a/invoke", json=_env(wrong_priv),
        headers=_auth(wrong_priv),
    )
    assert r.status_code == 401


def test_pillar1_unknown_peer_denied_403(a2a_env):
    client, priv, _pub = a2a_env
    # Peer.zz is not registered.
    env = _env(priv, **{"from": "peer.zz"})
    # Resign with correct from.
    env["signature"] = sign_ed25519(priv, env)
    r = client.post(
        "/v1/a2a/invoke", json=env, headers=_auth(priv, issuer="peer.zz"),
    )
    assert r.status_code == 403


# Pillar 2: Capability ---------------------------------------------


def test_pillar2_capability_allowlist_unit():
    caps = [{"method": "agent.invoke", "tools": ["echo"]}]
    check_capability(caps, "agent.invoke", "echo")  # ok
    with pytest.raises(A2ADenied) as exc:
        check_capability(caps, "agent.invoke", "forbidden")
    assert exc.value.status == 403


def test_pillar2_tool_not_advertised_denied_403(a2a_env):
    client, priv, _pub = a2a_env
    env = _env(priv, params={"tool": "forbidden_tool"})
    env["signature"] = sign_ed25519(priv, env)
    r = client.post(
        "/v1/a2a/invoke", json=env, headers=_auth(priv),
    )
    assert r.status_code == 403


def test_pillar2_method_not_advertised_denied_403(a2a_env):
    client, priv, _pub = a2a_env
    env = _env(priv, method="capabilities.list", params={})
    env["signature"] = sign_ed25519(priv, env)
    r = client.post(
        "/v1/a2a/invoke", json=env, headers=_auth(priv),
    )
    # Fixture caps do not advertise capabilities.list → 403.
    assert r.status_code == 403


# Pillar 3: Signature + replay -------------------------------------


def test_pillar3_bad_signature_denied_401(a2a_env):
    client, priv, _pub = a2a_env
    env = _env(priv)
    env["signature"] = base64.b64encode(b"x" * 64).decode("ascii")
    r = client.post(
        "/v1/a2a/invoke", json=env, headers=_auth(priv),
    )
    assert r.status_code == 401


def test_pillar3_timestamp_skew_denied_401(a2a_env):
    client, priv, _pub = a2a_env
    env = _env(priv, timestamp=int(time.time()) - 3600)
    env["signature"] = sign_ed25519(priv, env)
    r = client.post(
        "/v1/a2a/invoke", json=env, headers=_auth(priv),
    )
    assert r.status_code == 401


def test_pillar3_nonce_replay_denied_409(a2a_env):
    client, priv, _pub = a2a_env
    env = _env(priv)
    # First call succeeds.
    r1 = client.post(
        "/v1/a2a/invoke", json=env, headers=_auth(priv),
    )
    assert r1.status_code == 200
    # Second call — same envelope, same nonce → 409.
    r2 = client.post(
        "/v1/a2a/invoke", json=env, headers=_auth(priv),
    )
    assert r2.status_code == 409


# Pillar 4: Rate limit ---------------------------------------------


def test_pillar4_rate_limit_denied_429(a2a_env):
    client, priv, _pub = a2a_env
    # Fixture config: rpm=2. Burn through the bucket.
    for _ in range(2):
        env = _env(priv)
        r = client.post(
            "/v1/a2a/invoke", json=env, headers=_auth(priv),
        )
        assert r.status_code == 200
    # Third should be 429.
    env = _env(priv)
    r = client.post(
        "/v1/a2a/invoke", json=env, headers=_auth(priv),
    )
    assert r.status_code == 429


def test_pillar4_rate_limiter_unit():
    rl = RateLimiter(rpm=2, day_quota=5)
    rl.check("a")
    rl.check("a")
    with pytest.raises(A2ADenied) as exc:
        rl.check("a")
    assert exc.value.status == 429


def test_pillar4_daily_quota_unit():
    rl = RateLimiter(rpm=1000, day_quota=3)
    for _ in range(3):
        rl.check("a")
    with pytest.raises(A2ADenied) as exc:
        rl.check("a")
    assert exc.value.status == 429
    assert exc.value.code == "quota_exceeded"


# Pillar 5 covered in test_a2a_audit_chain.py.


# DENY-not-WARN — deliberately verify none of these return 200.


def test_deny_not_warn_summary(a2a_env):
    """Each pillar failure MUST be HTTP error, never 200."""
    client, priv, _pub = a2a_env
    # Build a baseline happy envelope.
    bad_cases: list[tuple[str, dict, dict]] = [
        (
            "no_auth",
            _env(priv),
            {},  # no Authorization header
        ),
        (
            "bad_sig",
            {**_env(priv), "signature": "AAAA"},
            _auth(priv),
        ),
    ]
    for _label, env, hdr in bad_cases:
        r = client.post("/v1/a2a/invoke", json=env, headers=hdr)
        assert r.status_code >= 400, f"{_label} leaked as 200"
