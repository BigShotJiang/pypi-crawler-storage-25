"""Streaming contract tests for the A5 self-contained model router.

Covers:
  * Protocol-level ``generate_stream`` presence on all 4 adapters.
  * OpenAI / Ollama / Groq SSE wire parsing — synthetic
    ``data: {json}`` frames produce the right concatenated string
    and > 1 chunk event (proving real streaming, not a one-shot).
  * Error propagation (401 / HTTP error / invalid SSE) surfaces as
    :class:`ProviderError` with the provider name intact.
  * Empty stream → returns empty iterator without raising.
  * Anthropic adapter streams via the SDK
    ``messages.stream`` async context manager; we inject a fake
    ``AsyncAnthropic`` into ``sys.modules['anthropic']`` so no
    network contact happens.

Hermetic: no real network. Every httpx client is replaced with a
tiny ``_FakeStreamingClient`` that owns canned SSE body bytes.
"""

from __future__ import annotations

import asyncio
import inspect
import sys
import types
from collections.abc import AsyncIterator
from typing import Any

import httpx
import pytest

from persona.providers import (
    AnthropicProvider,
    GroqProvider,
    OllamaProvider,
    OpenAIProvider,
    ProviderError,
)
from persona.providers.base import ModelPolicy


# ─────────────────── Fake streaming httpx client ───────────────────


class _FakeStreamContext:
    """Async CM standing in for ``httpx.AsyncClient.stream(...)``.

    Real ``httpx`` returns an ``AsyncStreamContextManager`` from a
    sync call; we mimic that exactly so the adapter's
    ``async with self._client.stream(...)`` body just works.
    """

    def __init__(
        self,
        lines: list[str],
        status: int = 200,
    ) -> None:
        self._lines = lines
        self._status = status

    async def __aenter__(self) -> "_FakeStreamResponse":
        return _FakeStreamResponse(self._lines, self._status)

    async def __aexit__(self, *_: Any) -> None:
        return None


class _FakeStreamResponse:
    """Minimal response stand-in with ``aiter_lines`` + ``raise_for_status``."""

    def __init__(self, lines: list[str], status: int) -> None:
        self._lines = lines
        self.status_code = status

    def raise_for_status(self) -> None:
        if self.status_code >= 400:
            req = httpx.Request("POST", "http://fake/stream")
            raise httpx.HTTPStatusError(
                f"status={self.status_code}",
                request=req,
                response=httpx.Response(self.status_code, request=req),
            )

    async def aiter_lines(self) -> AsyncIterator[str]:
        for line in self._lines:
            yield line


class _FakeStreamingClient:
    """Async double. Produces canned SSE bodies per URL suffix."""

    def __init__(
        self,
        lines_by_suffix: dict[str, list[str]],
        status: int = 200,
    ) -> None:
        self._lines_by_suffix = lines_by_suffix
        self._status = status
        self.calls: list[tuple[str, dict[str, Any]]] = []

    def stream(
        self,
        method: str,  # noqa: ARG002 — signature parity with httpx
        url: str,
        json: dict[str, Any] | None = None,
        headers: dict[str, str] | None = None,  # noqa: ARG002
    ) -> _FakeStreamContext:
        self.calls.append((url, json or {}))
        suffix = url.rsplit("/", 1)[-1]
        return _FakeStreamContext(
            self._lines_by_suffix.get(suffix, []),
            status=self._status,
        )


def _openai_sse_lines(chunks: list[str]) -> list[str]:
    """Encode a list of text deltas as OpenAI-style SSE lines."""
    import json as _json
    out: list[str] = []
    for c in chunks:
        frame = {"choices": [{"delta": {"content": c}}]}
        out.append(f"data: {_json.dumps(frame)}")
        out.append("")  # SSE frame separator
    out.append("data: [DONE]")
    return out


async def _collect(it: AsyncIterator[str]) -> list[str]:
    """Drain an async iterator into a list."""
    chunks: list[str] = []
    async for c in it:
        chunks.append(c)
    return chunks


# ─────────────────── Protocol presence ───────────────────


@pytest.mark.parametrize(
    "cls",
    [AnthropicProvider, OpenAIProvider, OllamaProvider, GroqProvider],
)
def test_provider_exposes_generate_stream(cls: type) -> None:
    instance = cls()  # type: ignore[call-arg]
    fn = getattr(instance, "generate_stream", None)
    assert fn is not None
    assert callable(fn)
    assert inspect.isasyncgenfunction(fn)


# ─────────────────── Ollama streaming ───────────────────


def test_ollama_stream_happy_path() -> None:
    client = _FakeStreamingClient({
        "completions": _openai_sse_lines(
            ["Hello ", "world", "! ", "done"],
        ),
    })
    provider = OllamaProvider(
        base_url="http://fake/v1",
        client=client,  # type: ignore[arg-type]
    )
    policy = ModelPolicy(provider="ollama", model="gemma3:27b")
    chunks = asyncio.run(
        _collect(
            provider.generate_stream(
                [{"role": "user", "content": "hi"}], policy,
            ),
        ),
    )
    assert "".join(chunks) == "Hello world! done"
    assert len(chunks) > 1  # real streaming, not one-shot
    # Request body includes stream=True flag.
    assert client.calls[0][1]["stream"] is True


def test_ollama_stream_http_error_raises_provider_error() -> None:
    client = _FakeStreamingClient(
        {"completions": []}, status=401,
    )
    provider = OllamaProvider(
        base_url="http://fake/v1",
        client=client,  # type: ignore[arg-type]
    )
    policy = ModelPolicy(provider="ollama", model="gemma3:27b")
    with pytest.raises(ProviderError) as ei:
        asyncio.run(
            _collect(
                provider.generate_stream(
                    [{"role": "user", "content": "hi"}], policy,
                ),
            ),
        )
    assert ei.value.provider == "ollama"


def test_ollama_stream_empty_terminator_only() -> None:
    """Stream with only ``data: [DONE]`` yields zero chunks cleanly."""
    client = _FakeStreamingClient({"completions": ["data: [DONE]"]})
    provider = OllamaProvider(
        base_url="http://fake/v1",
        client=client,  # type: ignore[arg-type]
    )
    policy = ModelPolicy(provider="ollama", model="gemma3:27b")
    chunks = asyncio.run(
        _collect(
            provider.generate_stream(
                [{"role": "user", "content": "hi"}], policy,
            ),
        ),
    )
    assert chunks == []


# ─────────────────── OpenAI streaming ───────────────────


def test_openai_stream_happy_path() -> None:
    client = _FakeStreamingClient({
        "completions": _openai_sse_lines(
            ["gpt ", "says ", "hi"],
        ),
    })
    provider = OpenAIProvider(
        api_key="sk-fake",
        base_url="http://fake/v1",
        client=client,  # type: ignore[arg-type]
    )
    policy = ModelPolicy(
        provider="openai", model="gpt-5", extra={"top_p": 0.5},
    )
    chunks = asyncio.run(
        _collect(
            provider.generate_stream(
                [{"role": "user", "content": "hi"}], policy,
            ),
        ),
    )
    assert "".join(chunks) == "gpt says hi"
    assert len(chunks) == 3
    # stream flag + extra knob are both merged into the payload.
    body = client.calls[0][1]
    assert body["stream"] is True
    assert body["top_p"] == 0.5


def test_openai_stream_missing_key_raises() -> None:
    provider = OpenAIProvider(api_key="")
    policy = ModelPolicy(provider="openai", model="gpt-5")
    with pytest.raises(ProviderError) as ei:
        asyncio.run(
            _collect(
                provider.generate_stream(
                    [{"role": "user", "content": "hi"}], policy,
                ),
            ),
        )
    assert "OPENAI_API_KEY" in ei.value.detail


def test_openai_stream_skips_blank_and_keepalive_frames() -> None:
    client = _FakeStreamingClient({
        "completions": [
            "",                                             # keepalive
            ": comment",                                    # not data:
            'data: {"choices":[{"delta":{"content":"A"}}]}',
            "",                                             # separator
            'data: {"choices":[{"delta":{}}]}',             # role-only
            'data: {"choices":[{"delta":{"content":"B"}}]}',
            "data: [DONE]",
        ],
    })
    provider = OpenAIProvider(
        api_key="sk-fake",
        base_url="http://fake/v1",
        client=client,  # type: ignore[arg-type]
    )
    policy = ModelPolicy(provider="openai", model="gpt-5")
    chunks = asyncio.run(
        _collect(
            provider.generate_stream(
                [{"role": "user", "content": "hi"}], policy,
            ),
        ),
    )
    assert chunks == ["A", "B"]


# ─────────────────── Groq streaming ───────────────────


def test_groq_stream_happy_path() -> None:
    client = _FakeStreamingClient({
        "completions": _openai_sse_lines(
            ["llama ", "streams ", "fast"],
        ),
    })
    provider = GroqProvider(
        api_key="gsk-fake",
        base_url="http://fake/openai/v1",
        client=client,  # type: ignore[arg-type]
    )
    policy = ModelPolicy(provider="groq", model="llama-4-scout")
    chunks = asyncio.run(
        _collect(
            provider.generate_stream(
                [{"role": "user", "content": "hi"}], policy,
            ),
        ),
    )
    assert "".join(chunks) == "llama streams fast"
    assert len(chunks) == 3


def test_groq_stream_missing_key_raises() -> None:
    provider = GroqProvider(api_key="")
    policy = ModelPolicy(provider="groq", model="llama-4-scout")
    with pytest.raises(ProviderError) as ei:
        asyncio.run(
            _collect(
                provider.generate_stream(
                    [{"role": "user", "content": "hi"}], policy,
                ),
            ),
        )
    assert "GROQ_API_KEY" in ei.value.detail


# ─────────────────── Anthropic streaming (SDK-faked) ───────────────────


class _FakeTextStream:
    """Stand-in for ``stream.text_stream`` — async iterable of deltas."""

    def __init__(self, deltas: list[str]) -> None:
        self._deltas = deltas

    def __aiter__(self) -> "_FakeTextStream":
        self._i = 0
        return self

    async def __anext__(self) -> str:
        if self._i >= len(self._deltas):
            raise StopAsyncIteration
        out = self._deltas[self._i]
        self._i += 1
        return out


class _FakeStream:
    """Stand-in for the ``AsyncMessageStream`` yielded by ``messages.stream``."""

    def __init__(self, deltas: list[str]) -> None:
        self.text_stream = _FakeTextStream(deltas)


class _FakeStreamManager:
    """Async CM stand-in for ``AsyncMessageStreamManager``.

    The Anthropic SDK returns a *sync* callable that produces an
    async context manager; we mirror that layering exactly.
    """

    def __init__(self, deltas: list[str], raise_on_enter: bool = False) -> None:
        self._deltas = deltas
        self._raise = raise_on_enter

    async def __aenter__(self) -> _FakeStream:
        if self._raise:
            raise RuntimeError("simulated anthropic network error")
        return _FakeStream(self._deltas)

    async def __aexit__(self, *_: Any) -> None:
        return None


class _FakeMessages:
    def __init__(self, deltas: list[str], raise_on_enter: bool = False) -> None:
        self._deltas = deltas
        self._raise = raise_on_enter

    def stream(self, **_: Any) -> _FakeStreamManager:
        return _FakeStreamManager(self._deltas, self._raise)


class _FakeAsyncAnthropic:
    def __init__(self, *, api_key: str, **_: Any) -> None:  # noqa: ARG002
        self.messages = _FakeMessages(_FakeAsyncAnthropic._deltas)

    _deltas: list[str] = []
    _raise: bool = False


@pytest.fixture()
def fake_anthropic_module(
    monkeypatch: pytest.MonkeyPatch,
) -> types.ModuleType:
    """Inject a fake ``anthropic`` module for the duration of one test."""
    mod = types.ModuleType("anthropic")

    def _make_client_cls(deltas: list[str], raise_on_enter: bool = False):
        class _Client(_FakeAsyncAnthropic):
            def __init__(self, *, api_key: str, **_: Any) -> None:  # noqa: ARG002
                self.messages = _FakeMessages(deltas, raise_on_enter)
        return _Client

    mod._make_client_cls = _make_client_cls  # type: ignore[attr-defined]
    mod.AsyncAnthropic = _make_client_cls(["default"])  # type: ignore[attr-defined]
    monkeypatch.setitem(sys.modules, "anthropic", mod)
    return mod


def test_anthropic_stream_happy_path(
    fake_anthropic_module: types.ModuleType,
) -> None:
    fake_anthropic_module.AsyncAnthropic = (  # type: ignore[attr-defined]
        fake_anthropic_module._make_client_cls(  # type: ignore[attr-defined]
            ["Hello ", "Claude ", "stream"],
        )
    )
    provider = AnthropicProvider(api_key="sk-ant-fake")
    policy = ModelPolicy(provider="anthropic", model="claude-opus-4-6")
    chunks = asyncio.run(
        _collect(
            provider.generate_stream(
                [{"role": "user", "content": "hi"}], policy,
            ),
        ),
    )
    assert "".join(chunks) == "Hello Claude stream"
    assert len(chunks) == 3  # real streaming proof


def test_anthropic_stream_missing_key_raises(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.delenv("ANTHROPIC_API_KEY", raising=False)
    provider = AnthropicProvider(api_key="")
    policy = ModelPolicy(provider="anthropic", model="claude-opus-4-6")
    with pytest.raises(ProviderError) as ei:
        asyncio.run(
            _collect(
                provider.generate_stream(
                    [{"role": "user", "content": "hi"}], policy,
                ),
            ),
        )
    assert "ANTHROPIC_API_KEY" in ei.value.detail


def test_anthropic_stream_sdk_error_wraps_provider_error(
    fake_anthropic_module: types.ModuleType,
) -> None:
    """SDK-level exception inside the stream CM surfaces as ProviderError."""
    fake_anthropic_module.AsyncAnthropic = (  # type: ignore[attr-defined]
        fake_anthropic_module._make_client_cls(  # type: ignore[attr-defined]
            [], raise_on_enter=True,
        )
    )
    provider = AnthropicProvider(api_key="sk-ant-fake")
    policy = ModelPolicy(provider="anthropic", model="claude-opus-4-6")
    with pytest.raises(ProviderError) as ei:
        asyncio.run(
            _collect(
                provider.generate_stream(
                    [{"role": "user", "content": "hi"}], policy,
                ),
            ),
        )
    assert ei.value.provider == "anthropic"
    assert "simulated" in ei.value.detail


def test_anthropic_stream_empty_deltas(
    fake_anthropic_module: types.ModuleType,
) -> None:
    """Stream that yields no deltas terminates as an empty iterator."""
    fake_anthropic_module.AsyncAnthropic = (  # type: ignore[attr-defined]
        fake_anthropic_module._make_client_cls([])  # type: ignore[attr-defined]
    )
    provider = AnthropicProvider(api_key="sk-ant-fake")
    policy = ModelPolicy(provider="anthropic", model="claude-opus-4-6")
    chunks = asyncio.run(
        _collect(
            provider.generate_stream(
                [{"role": "user", "content": "hi"}], policy,
            ),
        ),
    )
    assert chunks == []


# ─────────────────── Streaming usage telemetry ───────────────────
#
# Anthropic stream: after draining ``stream.text_stream`` we call
# ``stream.get_final_message()`` to harvest ``usage`` (all 4 fields).
# The test rig patches ``_FakeStream`` to expose both.
#
# OpenAI / Groq stream: the adapter appends
# ``stream_options.include_usage=true`` to the payload and parses
# the final frame (``choices == []`` + populated ``usage`` block)
# into UsageStats with cache fields left None.
#
# Ollama stream: stays None — no telemetry surface.


class _FakeAnthropicStreamUsage:
    def __init__(
        self,
        input_tokens: int | None = None,
        output_tokens: int | None = None,
        cache_creation_input_tokens: int | None = None,
        cache_read_input_tokens: int | None = None,
    ) -> None:
        self.input_tokens = input_tokens
        self.output_tokens = output_tokens
        self.cache_creation_input_tokens = cache_creation_input_tokens
        self.cache_read_input_tokens = cache_read_input_tokens


class _FakeFinalMessage:
    def __init__(self, usage: _FakeAnthropicStreamUsage | None) -> None:
        self.usage = usage


class _FakeStreamWithFinal(_FakeStream):
    """_FakeStream + ``get_final_message`` for usage harvesting."""

    def __init__(
        self,
        deltas: list[str],
        final_usage: _FakeAnthropicStreamUsage | None,
        raise_on_get_final: bool = False,
    ) -> None:
        super().__init__(deltas)
        self._final_usage = final_usage
        self._raise = raise_on_get_final

    async def get_final_message(self) -> _FakeFinalMessage:
        if self._raise:
            raise RuntimeError("no final message available")
        return _FakeFinalMessage(self._final_usage)


class _FakeStreamManagerWithFinal(_FakeStreamManager):
    def __init__(
        self,
        deltas: list[str],
        final_usage: _FakeAnthropicStreamUsage | None,
        raise_on_get_final: bool = False,
    ) -> None:
        super().__init__(deltas, raise_on_enter=False)
        self._final_usage = final_usage
        self._raise_on_get_final = raise_on_get_final

    async def __aenter__(self) -> _FakeStreamWithFinal:
        return _FakeStreamWithFinal(
            self._deltas,
            self._final_usage,
            self._raise_on_get_final,
        )


def _patch_anthropic_stream_with_final(
    fake_module: types.ModuleType,
    deltas: list[str],
    usage: _FakeAnthropicStreamUsage | None,
    raise_on_get_final: bool = False,
) -> None:
    """Install a fake AsyncAnthropic whose stream yields final usage."""
    class _Messages:
        def stream(self, **_: Any) -> _FakeStreamManagerWithFinal:
            return _FakeStreamManagerWithFinal(
                deltas, usage, raise_on_get_final,
            )

    class _Client:
        def __init__(self, *, api_key: str, **_: Any) -> None:  # noqa: ARG002
            self.messages = _Messages()

    fake_module.AsyncAnthropic = _Client  # type: ignore[attr-defined]


def test_anthropic_stream_captures_usage_via_get_final_message(
    fake_anthropic_module: types.ModuleType,
) -> None:
    """Anthropic streaming populates all 4 usage fields on completion."""
    _patch_anthropic_stream_with_final(
        fake_anthropic_module,
        ["Hello ", "cached "],
        _FakeAnthropicStreamUsage(
            input_tokens=100,
            output_tokens=20,
            cache_creation_input_tokens=0,
            cache_read_input_tokens=80,
        ),
    )
    provider = AnthropicProvider(api_key="sk-ant-fake")
    policy = ModelPolicy(provider="anthropic", model="claude-opus-4-6")
    chunks = asyncio.run(
        _collect(
            provider.generate_stream(
                [{"role": "user", "content": "hi"}], policy,
            ),
        ),
    )
    assert "".join(chunks) == "Hello cached "
    assert provider.last_usage is not None
    assert provider.last_usage.input_tokens == 100
    assert provider.last_usage.output_tokens == 20
    assert provider.last_usage.cache_creation_input_tokens == 0
    assert provider.last_usage.cache_read_input_tokens == 80


def test_anthropic_stream_get_final_failure_degrades_to_none(
    fake_anthropic_module: types.ModuleType,
) -> None:
    """get_final_message raising must not fail the stream; usage=None."""
    _patch_anthropic_stream_with_final(
        fake_anthropic_module,
        ["ok ", "done"],
        usage=None,
        raise_on_get_final=True,
    )
    provider = AnthropicProvider(api_key="sk-ant-fake")
    policy = ModelPolicy(provider="anthropic", model="claude-opus-4-6")
    chunks = asyncio.run(
        _collect(
            provider.generate_stream(
                [{"role": "user", "content": "hi"}], policy,
            ),
        ),
    )
    assert "".join(chunks) == "ok done"
    assert provider.last_usage is None


def _openai_sse_lines_with_usage(
    chunks: list[str],
    prompt_tokens: int,
    completion_tokens: int,
) -> list[str]:
    """Encode deltas + a final ``stream_options.include_usage`` frame."""
    import json as _json
    out: list[str] = []
    for c in chunks:
        frame = {"choices": [{"delta": {"content": c}}]}
        out.append(f"data: {_json.dumps(frame)}")
        out.append("")
    # Final usage frame — OpenAI emits an empty choices array here.
    usage_frame = {
        "choices": [],
        "usage": {
            "prompt_tokens": prompt_tokens,
            "completion_tokens": completion_tokens,
            "total_tokens": prompt_tokens + completion_tokens,
        },
    }
    out.append(f"data: {_json.dumps(usage_frame)}")
    out.append("")
    out.append("data: [DONE]")
    return out


def test_openai_stream_captures_usage_from_final_frame() -> None:
    """include_usage=true final frame populates last_usage."""
    client = _FakeStreamingClient({
        "completions": _openai_sse_lines_with_usage(
            ["gpt ", "says ", "hi"],
            prompt_tokens=50,
            completion_tokens=12,
        ),
    })
    provider = OpenAIProvider(
        api_key="sk-fake",
        base_url="http://fake/v1",
        client=client,  # type: ignore[arg-type]
    )
    policy = ModelPolicy(provider="openai", model="gpt-5")
    chunks = asyncio.run(
        _collect(
            provider.generate_stream(
                [{"role": "user", "content": "hi"}], policy,
            ),
        ),
    )
    assert "".join(chunks) == "gpt says hi"
    # stream_options.include_usage opt-in lives in the request body.
    body = client.calls[0][1]
    assert body["stream_options"] == {"include_usage": True}
    assert provider.last_usage is not None
    assert provider.last_usage.input_tokens == 50
    assert provider.last_usage.output_tokens == 12
    assert provider.last_usage.cache_read_input_tokens is None


def test_openai_stream_without_usage_frame_stays_none() -> None:
    """No usage frame means last_usage stays at None after iteration."""
    client = _FakeStreamingClient({
        "completions": _openai_sse_lines(["a", "b"]),
    })
    provider = OpenAIProvider(
        api_key="sk-fake",
        base_url="http://fake/v1",
        client=client,  # type: ignore[arg-type]
    )
    policy = ModelPolicy(provider="openai", model="gpt-5")
    asyncio.run(
        _collect(
            provider.generate_stream(
                [{"role": "user", "content": "hi"}], policy,
            ),
        ),
    )
    assert provider.last_usage is None


def test_groq_stream_captures_usage_from_final_frame() -> None:
    """Groq mirrors OpenAI include_usage behaviour."""
    client = _FakeStreamingClient({
        "completions": _openai_sse_lines_with_usage(
            ["llama ", "fast"],
            prompt_tokens=77,
            completion_tokens=9,
        ),
    })
    provider = GroqProvider(
        api_key="gsk-fake",
        base_url="http://fake/openai/v1",
        client=client,  # type: ignore[arg-type]
    )
    policy = ModelPolicy(provider="groq", model="llama-4-scout")
    asyncio.run(
        _collect(
            provider.generate_stream(
                [{"role": "user", "content": "hi"}], policy,
            ),
        ),
    )
    body = client.calls[0][1]
    assert body["stream_options"] == {"include_usage": True}
    assert provider.last_usage is not None
    assert provider.last_usage.input_tokens == 77
    assert provider.last_usage.output_tokens == 9


def test_ollama_stream_last_usage_always_none() -> None:
    """Ollama streaming has no usage surface — last_usage stays None."""
    client = _FakeStreamingClient({
        "completions": _openai_sse_lines(["a", "b", "c"]),
    })
    provider = OllamaProvider(
        base_url="http://fake/v1",
        client=client,  # type: ignore[arg-type]
    )
    policy = ModelPolicy(provider="ollama", model="gemma3:27b")
    asyncio.run(
        _collect(
            provider.generate_stream(
                [{"role": "user", "content": "hi"}], policy,
            ),
        ),
    )
    assert provider.last_usage is None
