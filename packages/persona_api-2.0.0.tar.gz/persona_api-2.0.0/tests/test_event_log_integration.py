"""A3 — CCC AppendOnlyLog integration tests.

Covers the two hook sites added in Aegis G6 §16.4 CP 26:

* :meth:`persona.engine.PersonaEngine._llm_via_provider` emits
  ``llm_call_start`` + (``llm_call_end`` | ``llm_call_error``).
* :meth:`persona.subagent.SubagentSpawner.spawn` emits
  ``subagent_spawn_start`` + (``subagent_spawn_end`` |
  ``subagent_spawn_error``).

Every test pins ``CCC_APPEND_LOG_DIR`` to a ``tmp_path`` so no state
leaks between tests and no personal path ever appears in CI. Every
test also asserts that an intentional log failure does **not** break
the underlying LLM call — observability is a second-class citizen,
correctness is first-class.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

import pytest

from concinno.cache import AppendOnlyLog
from persona.engine import PersonaEngine
from persona.providers import (
    ModelPolicy,
    ProviderError,
    ProviderRegistry,
    UsageStats,
)
from persona.subagent import SpawnRequest, SubagentSpawner


# ─────────────────── Fakes ───────────────────


class _FakeProvider:
    """Minimal async provider double.

    Carries an optional ``last_usage`` attribute so the engine
    telemetry wiring (A5 cache-hit observability) can be asserted
    end-to-end through the AppendOnlyLog ``llm_call_end`` payload.
    """

    name = "fake"

    def __init__(
        self,
        reply: str = "hello-world",
        error: Exception | None = None,
        last_usage: UsageStats | None = None,
    ) -> None:
        self.reply = reply
        self.error = error
        self.last_usage = last_usage

    async def generate(
        self,
        messages: list[dict[str, str]],
        policy: ModelPolicy,
    ) -> str:
        if self.error is not None:
            raise self.error
        return self.reply


def _registry(provider: _FakeProvider) -> ProviderRegistry:
    reg = ProviderRegistry()
    reg.register_instance("fake", provider)
    return reg


@pytest.fixture
def isolated_log_dir(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch,
) -> Path:
    """Pin AppendOnlyLog storage to a tmp dir, per test."""
    log_dir = tmp_path / "append_log"
    monkeypatch.setenv("CCC_APPEND_LOG_DIR", str(log_dir))
    return log_dir


# ─────────────────── Engine hook ───────────────────


@pytest.mark.asyncio
async def test_engine_llm_call_logs_start_end(
    isolated_log_dir: Path,
) -> None:
    """Successful provider call writes start + end to AppendOnlyLog."""
    provider = _FakeProvider(reply="answer-123")
    engine = PersonaEngine(provider_registry=_registry(provider))

    result = await engine._llm_via_provider(
        policy=ModelPolicy(
            provider="fake", model="m1", max_tokens=64, temperature=0.2,
        ),
        messages=[
            {"role": "system", "content": "be brief"},
            {"role": "user", "content": "hi"},
        ],
        session_id="engine-session-ok",
    )
    assert result == "answer-123"

    log = AppendOnlyLog(log_dir=isolated_log_dir)
    events = log.read_session("engine-session-ok")
    types = [e.event_type for e in events]
    assert "llm_call_start" in types
    assert "llm_call_end" in types

    start_ev = next(e for e in events if e.event_type == "llm_call_start")
    end_ev = next(e for e in events if e.event_type == "llm_call_end")
    # Causal chain: the end event must point back at the start event.
    assert end_ev.parent_event_id == start_ev.event_id
    # Metadata is captured, message bodies are not (privacy/size).
    assert start_ev.payload["provider"] == "fake"
    assert start_ev.payload["model"] == "m1"
    assert start_ev.payload["messages_count"] == 2
    assert "content" not in start_ev.payload
    assert end_ev.payload["response_length"] == len("answer-123")


@pytest.mark.asyncio
async def test_engine_llm_call_error_logs_error_event(
    isolated_log_dir: Path,
) -> None:
    """Provider raising ProviderError emits llm_call_error event."""
    err = ProviderError("fake", "boom")
    provider = _FakeProvider(error=err)
    engine = PersonaEngine(provider_registry=_registry(provider))

    with pytest.raises(ProviderError):
        await engine._llm_via_provider(
            policy=ModelPolicy(provider="fake", model="m1"),
            messages=[{"role": "user", "content": "hi"}],
            session_id="engine-session-err",
        )

    log = AppendOnlyLog(log_dir=isolated_log_dir)
    events = log.read_session("engine-session-err")
    types = [e.event_type for e in events]
    assert "llm_call_start" in types
    assert "llm_call_error" in types
    err_ev = next(e for e in events if e.event_type == "llm_call_error")
    assert "boom" in err_ev.payload["error"]
    # Parent chain still intact even on error.
    start_ev = next(e for e in events if e.event_type == "llm_call_start")
    assert err_ev.parent_event_id == start_ev.event_id


@pytest.mark.asyncio
async def test_engine_llm_call_end_captures_usage_payload(
    isolated_log_dir: Path,
) -> None:
    """``llm_call_end`` carries the 4-field ``usage`` sub-dict when populated.

    This is the round-trip check for the A5 cache-hit telemetry:
    provider.last_usage → engine._llm_end_payload → AppendOnlyLog.
    """
    provider = _FakeProvider(
        reply="hello-cached",
        last_usage=UsageStats(
            input_tokens=100,
            output_tokens=20,
            cache_creation_input_tokens=0,
            cache_read_input_tokens=80,
        ),
    )
    engine = PersonaEngine(provider_registry=_registry(provider))

    await engine._llm_via_provider(
        policy=ModelPolicy(provider="fake", model="m1"),
        messages=[{"role": "user", "content": "hi"}],
        session_id="engine-session-usage",
    )

    log = AppendOnlyLog(log_dir=isolated_log_dir)
    events = log.read_session("engine-session-usage")
    end_ev = next(e for e in events if e.event_type == "llm_call_end")
    assert "usage" in end_ev.payload
    usage = end_ev.payload["usage"]
    assert usage["input_tokens"] == 100
    assert usage["output_tokens"] == 20
    assert usage["cache_creation_input_tokens"] == 0
    assert usage["cache_read_input_tokens"] == 80


@pytest.mark.asyncio
async def test_engine_llm_call_end_omits_usage_when_none(
    isolated_log_dir: Path,
) -> None:
    """Provider with ``last_usage=None`` (e.g. Ollama) omits the key."""
    provider = _FakeProvider(reply="no-telemetry", last_usage=None)
    engine = PersonaEngine(provider_registry=_registry(provider))

    await engine._llm_via_provider(
        policy=ModelPolicy(provider="fake", model="m1"),
        messages=[{"role": "user", "content": "hi"}],
        session_id="engine-session-nousage",
    )

    log = AppendOnlyLog(log_dir=isolated_log_dir)
    events = log.read_session("engine-session-nousage")
    end_ev = next(e for e in events if e.event_type == "llm_call_end")
    assert "usage" not in end_ev.payload
    # Baseline fields still present.
    assert end_ev.payload["response_length"] == len("no-telemetry")


@pytest.mark.asyncio
async def test_engine_log_failure_does_not_break_call(
    isolated_log_dir: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """AppendOnlyLog.append raising must NEVER kill the LLM call."""
    provider = _FakeProvider(reply="still-works")
    engine = PersonaEngine(provider_registry=_registry(provider))

    # Force-init event_log then poison its append method.
    log = engine.event_log
    assert log is not None

    def _blow_up(*_a: Any, **_kw: Any) -> None:
        raise RuntimeError("disk full")

    monkeypatch.setattr(log, "append", _blow_up)

    result = await engine._llm_via_provider(
        policy=ModelPolicy(provider="fake", model="m1"),
        messages=[{"role": "user", "content": "hi"}],
        session_id="engine-session-poisoned",
    )
    assert result == "still-works"


# ─────────────────── Subagent hook ───────────────────


@pytest.mark.asyncio
async def test_subagent_spawn_logs_to_event_log(
    isolated_log_dir: Path, tmp_path: Path,
) -> None:
    """Spawn success emits start + end AppendOnlyLog events."""
    provider = _FakeProvider(reply="subagent-output")
    spawner = SubagentSpawner(
        provider_registry=_registry(provider),
        log_dir=tmp_path / "per_tenant_logs",
    )

    req = SpawnRequest(
        system_prompt="You are an auditor.",
        user_messages=[{"role": "user", "content": "audit x"}],
        policy=ModelPolicy(provider="fake", model="m1"),
        tenant_id="tenant-alpha",
        subagent_role="red-team",
    )
    record = await spawner.spawn(req)
    assert record.response == "subagent-output"
    assert record.error is None

    log = AppendOnlyLog(log_dir=isolated_log_dir)
    events = log.read_session("tenant-alpha")
    types = [e.event_type for e in events]
    assert "subagent_spawn_start" in types
    assert "subagent_spawn_end" in types

    start_ev = next(
        e for e in events if e.event_type == "subagent_spawn_start"
    )
    end_ev = next(
        e for e in events if e.event_type == "subagent_spawn_end"
    )
    # spawn_id is the start event_id and also the end's parent.
    assert start_ev.event_id == record.spawn_id
    assert end_ev.parent_event_id == record.spawn_id
    assert start_ev.payload["subagent_role"] == "red-team"
    assert start_ev.payload["provider"] == "fake"
    assert end_ev.payload["response_length"] == len("subagent-output")


@pytest.mark.asyncio
async def test_subagent_and_engine_tenant_isolation(
    isolated_log_dir: Path, tmp_path: Path,
) -> None:
    """Engine session_id and subagent tenant_id partition the log.

    Both sites share one AppendOnlyLog instance (same tmp dir), but
    ``read_session`` is keyed and must never surface events from the
    wrong tenant.
    """
    engine_provider = _FakeProvider(reply="engine-out")
    engine = PersonaEngine(provider_registry=_registry(engine_provider))

    sub_provider = _FakeProvider(reply="sub-out")
    spawner = SubagentSpawner(
        provider_registry=_registry(sub_provider),
        log_dir=tmp_path / "per_tenant_logs",
    )

    await engine._llm_via_provider(
        policy=ModelPolicy(provider="fake", model="m1"),
        messages=[{"role": "user", "content": "e"}],
        session_id="alpha",
    )
    await spawner.spawn(SpawnRequest(
        system_prompt="s",
        user_messages=[{"role": "user", "content": "b"}],
        policy=ModelPolicy(provider="fake", model="m1"),
        tenant_id="beta",
    ))

    log = AppendOnlyLog(log_dir=isolated_log_dir)
    alpha_events = log.read_session("alpha")
    beta_events = log.read_session("beta")
    # Alpha only has engine events, beta only has subagent events.
    assert all(
        "llm_call" in e.event_type for e in alpha_events
    ), [e.event_type for e in alpha_events]
    assert all(
        "subagent_spawn" in e.event_type for e in beta_events
    ), [e.event_type for e in beta_events]
    assert len(alpha_events) >= 2  # start + end
    assert len(beta_events) >= 2
