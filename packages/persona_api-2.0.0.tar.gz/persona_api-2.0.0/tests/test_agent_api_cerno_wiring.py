"""Regression: ``_build_loop`` wires Option C ``deny_on_action`` (2.0.0).

Covers RED Opus FATAL-2 (2026-05-01): without ``deny_on_action`` set,
Cerno deny verdicts are silently swallowed in production — the 2.0.0
README/CHANGELOG claim "deny verdicts no longer silently swallowed"
becomes vapor. This test exercises the production code path
(``_build_loop`` → ``make_cerno_post_hook`` with the deny lambda) so a
regression to the bare ``make_cerno_post_hook(cerno)`` signature
fails the test.

Approach
--------
We do NOT spin up the full Starlette app. We call ``_build_loop``
directly with a stack name that triggers the cerno wiring, then
inject a fake Cerno into the registry that emits a ``CernoDeny``
verdict on its first cycle. We drive ``loop.run`` with a scripted
LLMCall and assert the final tool message has ``is_error=True`` and
contains the deny reason — proving the deny path is wired end-to-end.
"""

from __future__ import annotations

from typing import Any

import pytest

from persona.agent_api import _build_loop
from persona.cerno.types import CernoDeny
from persona.engine.agent_loop import LLMResponse, ToolCall


class _FakeCerno:
    """Stand-in for :class:`Cerno` that scripts a deny verdict."""

    def __init__(self, verdict: Any) -> None:
        self._verdict = verdict
        self.calls: list[tuple[str, str]] = []

    def cycle(self, user_input: str, child_output: str) -> Any:
        self.calls.append((user_input, child_output))
        return self._verdict


@pytest.mark.asyncio
async def test_build_loop_wires_deny_on_action_for_sancio_stack(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """``_build_loop("sancio", ...)`` ships a cerno hook that denies on type=='deny'."""
    from persona import api as api_module

    deny_verdict = CernoDeny(reason="cerno blocked: leaked secret")

    def fake_get_or_create_cerno(
        *,
        child_id: str,
        config_override: Any = None,
        tenant: str | None = None,
    ) -> Any:
        return _FakeCerno(verdict=deny_verdict)

    monkeypatch.setattr(
        api_module, "_get_or_create_cerno", fake_get_or_create_cerno,
        raising=True,
    )

    # Build the production loop. We override its post-built tool
    # registry with a single echo tool so the LLM has something to
    # call. _build_loop's pre-hooks (policy + guard) are no-ops on a
    # benign tool call — verified by the existing test_loop_with_guard
    # _deny_and_cerno_observe regression in test_hooks.py.
    loop = _build_loop(
        stack="sancio",
        max_iterations=4,
        tenant_id="t-test",
    )

    class _EchoTool:
        name = "echo"

        def schema(self) -> dict[str, Any]:
            return {"type": "function", "function": {"name": "echo"}}

        async def execute(self, args: dict[str, Any]) -> str:
            return args.get("text", "")

    loop.tools = {"echo": _EchoTool()}

    # Scripted LLM: call echo once, then emit final text.
    llm_replies = [
        LLMResponse(
            tool_calls=[
                ToolCall(id="c1", name="echo", args={"text": "benign"}),
            ],
        ),
        LLMResponse(content="done."),
    ]
    idx = {"i": 0}

    async def llm_call(
        _msgs: list[dict[str, Any]],
        _schemas: list[dict[str, Any]],
    ) -> LLMResponse:
        i = idx["i"]
        idx["i"] = i + 1
        return llm_replies[i]

    loop.llm_call = llm_call

    state = await loop.run([{"role": "user", "content": "do echo"}])

    # Tool message should be marked is_error=True with the deny reason
    # surfaced via the post-hook deny path.
    tool_msgs = [m for m in state.messages if m["role"] == "tool"]
    assert tool_msgs, "expected at least one tool message"
    last_tool = tool_msgs[-1]
    assert last_tool["is_error"] is True, (
        "Cerno deny verdict must mark the LLM-visible message as an error "
        "(Option C observation-channel deny)"
    )
    assert "post-hook deny" in last_tool["content"], (
        f"expected 'post-hook deny' in content, got {last_tool['content']!r}"
    )
    assert "cerno blocked: leaked secret" in last_tool["content"], (
        f"deny reason not propagated: {last_tool['content']!r}"
    )
