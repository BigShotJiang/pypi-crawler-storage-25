"""Unit tests for :class:`persona.cerno_registry.CernoRegistry`.

Session 2026-04-15 P3.2 sub-B — dedicated unit-level invariants for
the LRU + TTL + background-prune + persistence + multi-tenant
registry landed in commit ``33ba81f``. The HTTP contract layer is
already covered by ``tests/test_api_cerno_endpoint.py``; this file
targets internal invariants that the HTTP surface cannot reach (e.g.
tenant isolation, TTL monotonic clock behaviour, atomic persist
safety on dump failure, snapshot version mismatch handling).

Target: ≥17 tests, sync except for the background-prune coroutine
which uses ``pytest.mark.asyncio``.
"""

from __future__ import annotations

import asyncio
import json
import time
from pathlib import Path

import pytest

from persona.cerno import Cerno
from persona.cerno_registry import (
    SNAPSHOT_VERSION,
    CernoRegistry,
    _Entry,
)


# ── LRU group ────────────────────────────────────────────────


def test_get_or_create_caches_instance() -> None:
    """Same (key, tenant) returns the same Cerno instance object."""
    reg = CernoRegistry(max_size=8, ttl_seconds=60.0)
    first = reg.get_or_create("c1")
    second = reg.get_or_create("c1")
    assert first is second
    # Cross-check via ``get`` — no extra construction.
    assert reg.get("c1") is first


def test_lru_evicts_oldest_when_full() -> None:
    """Filling max_size+1 evicts the least-recently-used entry."""
    reg = CernoRegistry(max_size=3, ttl_seconds=60.0)
    for cid in ("a", "b", "c"):
        reg.get_or_create(cid)
    # At cap. Adding one more evicts ``a`` (the oldest insertion).
    reg.get_or_create("d")

    assert sorted(reg.list_keys(tenant="default")) == ["b", "c", "d"]
    with pytest.raises(KeyError):
        reg.get("a")
    assert reg.stats()["evictions"] == 1


def test_lru_promotes_on_get() -> None:
    """get() promotes old key to MRU; next overflow evicts untouched newer key."""
    reg = CernoRegistry(max_size=3, ttl_seconds=60.0)
    reg.get_or_create("a")
    reg.get_or_create("b")
    reg.get_or_create("c")
    # Touch ``a`` → LRU order becomes [b, c, a]. ``b`` is now LRU.
    reg.get("a")
    # Overflow → evict ``b`` (LRU), not ``a``.
    reg.get_or_create("d")

    keys = reg.list_keys(tenant="default")
    assert "a" in keys, "touched key must survive eviction"
    assert "b" not in keys, "untouched oldest-after-promotion key must evict"
    assert sorted(keys) == ["a", "c", "d"]


def test_lru_cap_applies_per_tenant_not_global() -> None:
    """Two tenants at cap=2 each keep 2 entries (4 total, not 2)."""
    reg = CernoRegistry(max_size=2, ttl_seconds=60.0)
    reg.get_or_create("x", tenant="A")
    reg.get_or_create("y", tenant="A")
    reg.get_or_create("x", tenant="B")
    reg.get_or_create("y", tenant="B")

    assert reg.size(tenant="A") == 2
    assert reg.size(tenant="B") == 2
    assert reg.size() == 4
    assert reg.stats()["evictions"] == 0


# ── TTL group ────────────────────────────────────────────────


def test_ttl_expires_inline_on_get() -> None:
    """ttl=0.01s → after 0.05s sleep, get_or_create returns a fresh instance."""
    reg = CernoRegistry(max_size=4, ttl_seconds=0.01)
    first = reg.get_or_create("c1")
    time.sleep(0.05)
    # Direct ``get`` should raise KeyError (expired).
    with pytest.raises(KeyError):
        reg.get("c1")
    # ``get_or_create`` rebuilds — fresh instance.
    second = reg.get_or_create("c1")
    assert second is not first
    assert reg.stats()["expired"] >= 1


def test_ttl_fresh_entry_not_expired() -> None:
    """ttl=10s + immediate re-get → same instance object."""
    reg = CernoRegistry(max_size=4, ttl_seconds=10.0)
    first = reg.get_or_create("c1")
    assert reg.get("c1") is first
    assert reg.get_or_create("c1") is first


def test_ttl_touch_updates_last_used() -> None:
    """get() advances the internal last_used_at monotonic timestamp."""
    reg = CernoRegistry(max_size=4, ttl_seconds=10.0)
    reg.get_or_create("c1")
    entry_before: _Entry = reg._stores["default"]["c1"]
    ts_before = entry_before.last_used_at

    time.sleep(0.05)
    reg.get("c1")

    entry_after: _Entry = reg._stores["default"]["c1"]
    assert entry_after.last_used_at > ts_before


# ── Background prune ─────────────────────────────────────────


@pytest.mark.asyncio
async def test_background_prune_sweeps_expired_entries() -> None:
    """Background task wipes expired entries after one prune_interval tick."""
    reg = CernoRegistry(
        max_size=8, ttl_seconds=0.05, prune_interval_s=0.05,
    )
    for cid in ("a", "b", "c"):
        reg.get_or_create(cid)
    assert reg.size() == 3

    await reg.start_background_prune()
    try:
        # Entries expire after 0.05s; first sweep runs at ~0.05s. Wait
        # long enough for at least one full tick *after* expiry.
        await asyncio.sleep(0.25)
        assert reg.size() == 0, (
            f"background sweep did not clear expired entries: "
            f"{reg.list_keys()}"
        )
    finally:
        await reg.stop_background_prune()


@pytest.mark.asyncio
async def test_stop_background_prune_is_idempotent() -> None:
    """stop() before start and stop() twice must not raise."""
    reg = CernoRegistry(max_size=4, ttl_seconds=1.0)
    # Never started — must be a no-op.
    await reg.stop_background_prune()
    await reg.stop_background_prune()

    await reg.start_background_prune()
    await reg.stop_background_prune()
    # Double-stop after real start.
    await reg.stop_background_prune()


# ── Multi-tenant ─────────────────────────────────────────────


def test_tenant_isolation_same_child_id() -> None:
    """Same child_id under different tenants → two distinct Cerno instances."""
    reg = CernoRegistry(max_size=8, ttl_seconds=60.0)
    a = reg.get_or_create("shared", tenant="A")
    b = reg.get_or_create("shared", tenant="B")

    assert a is not b
    # Mutate state on A — B must not observe the change.
    a.state.consecutive_denies = 7
    assert b.state.consecutive_denies == 0


def test_list_keys_filtered_by_tenant() -> None:
    """tenant='A' returns only A's keys, not B's."""
    reg = CernoRegistry(max_size=8, ttl_seconds=60.0)
    reg.get_or_create("a1", tenant="A")
    reg.get_or_create("a2", tenant="A")
    reg.get_or_create("b1", tenant="B")

    assert sorted(reg.list_keys(tenant="A")) == ["a1", "a2"]
    assert sorted(reg.list_keys(tenant="B")) == ["b1"]
    # Unknown tenant → empty list (not error).
    assert reg.list_keys(tenant="ghost") == []


def test_list_keys_all_tenants() -> None:
    """tenant=None returns every (tenant, child_id) flat-listed."""
    reg = CernoRegistry(max_size=8, ttl_seconds=60.0)
    reg.get_or_create("a1", tenant="A")
    reg.get_or_create("b1", tenant="B")
    reg.get_or_create("b2", tenant="B")

    all_keys = reg.list_keys(tenant=None)
    assert sorted(all_keys) == ["a1", "b1", "b2"]


# ── Persistence ──────────────────────────────────────────────


def test_persist_then_restore_round_trip(tmp_path: Path) -> None:
    """Populate → persist → restore → all state fields survive."""
    persist = str(tmp_path / "snapshot.json")
    reg = CernoRegistry(max_size=8, ttl_seconds=60.0, persist_path=persist)

    arb_a = reg.get_or_create("child-a", tenant="T1")
    arb_a.state.consecutive_denies = 4
    arb_a.state.current_identity = "judge"
    arb_a.state.recent_scores = [10, 20, 30]
    arb_a.state.equilibrium.pressure = 12.5
    arb_a.state.equilibrium.total_steps = 99

    arb_b = reg.get_or_create("child-b", tenant="T2")
    arb_b.state.consecutive_denies = 1

    reg.persist_to_disk()
    assert Path(persist).exists()

    restored = CernoRegistry.restore_from_disk(
        persist, max_size=8, ttl_seconds=60.0,
    )
    assert sorted(restored.list_keys(tenant="T1")) == ["child-a"]
    assert sorted(restored.list_keys(tenant="T2")) == ["child-b"]

    r_a = restored.get("child-a", tenant="T1")
    assert r_a.state.consecutive_denies == 4
    assert r_a.state.current_identity == "judge"
    assert r_a.state.recent_scores == [10, 20, 30]
    assert r_a.state.equilibrium.pressure == 12.5
    assert r_a.state.equilibrium.total_steps == 99

    r_b = restored.get("child-b", tenant="T2")
    assert r_b.state.consecutive_denies == 1


def test_persist_atomic_on_dump_failure(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """If json.dump raises mid-write, the previous snapshot stays intact."""
    persist = str(tmp_path / "snapshot.json")
    reg = CernoRegistry(max_size=8, ttl_seconds=60.0, persist_path=persist)

    # First successful persist — this is the baseline the next failure
    # must not corrupt.
    reg.get_or_create("c1")
    reg.persist_to_disk()
    original_bytes = Path(persist).read_bytes()
    assert len(original_bytes) > 0

    # Now monkeypatch json.dump to raise. The registry contract:
    # tmp+rename means the target file on disk is untouched.
    import persona.cerno_registry as registry_mod

    def _boom(*args: object, **kwargs: object) -> None:
        raise RuntimeError("synthetic dump failure")

    monkeypatch.setattr(registry_mod.json, "dump", _boom)

    # Mutate state so a successful persist would produce different
    # bytes — that way we can detect whether the file was overwritten.
    reg.get_or_create("c2")
    with pytest.raises(RuntimeError, match="synthetic dump failure"):
        reg.persist_to_disk()

    # Previous snapshot bytes-for-bytes identical.
    assert Path(persist).read_bytes() == original_bytes
    # .tmp cleaned up (the except-branch in persist_to_disk unlinks it).
    assert not Path(persist + ".tmp").exists()


def test_restore_unknown_version_starts_empty(tmp_path: Path) -> None:
    """Snapshot with version != SNAPSHOT_VERSION yields an empty registry."""
    persist = tmp_path / "snapshot.json"
    persist.write_text(
        json.dumps({
            "version": SNAPSHOT_VERSION + 999,
            "saved_at": time.time(),
            "entries": [
                {
                    "tenant": "T1",
                    "child_id": "orphan",
                    "state": {"consecutive_denies": 5},
                    "last_used_at": 0.0,
                },
            ],
        }),
        encoding="utf-8",
    )

    restored = CernoRegistry.restore_from_disk(str(persist))
    assert restored.list_keys() == []
    assert restored.size() == 0


def test_persist_path_none_skips_persistence(tmp_path: Path) -> None:
    """persist_path=None → persist_to_disk is a no-op (no file created)."""
    reg = CernoRegistry(max_size=4, ttl_seconds=60.0, persist_path=None)
    reg.get_or_create("c1")
    # Must not raise + must not create anything under tmp_path.
    reg.persist_to_disk()
    assert list(tmp_path.iterdir()) == []


# ── Stats + delete ───────────────────────────────────────────


def test_stats_counts_hits_misses_evictions() -> None:
    """Counters reflect 2 hits + 1 miss + 1 eviction after mixed traffic."""
    reg = CernoRegistry(max_size=2, ttl_seconds=60.0)

    # Two create-misses to populate (counts as misses, not hits).
    reg.get_or_create("a")  # miss (new)
    reg.get_or_create("b")  # miss (new)

    # Two hits on existing entries.
    reg.get("a")  # hit
    reg.get("b")  # hit

    # One cold miss via ``get``.
    with pytest.raises(KeyError):
        reg.get("ghost")

    # Trigger one eviction by overflowing the cap.
    reg.get_or_create("c")  # miss (new) + evicts LRU

    s = reg.stats()
    assert s["hits"] == 2
    # Three create-misses + one cold miss = 4.
    assert s["misses"] == 4
    assert s["evictions"] == 1


def test_delete_returns_true_on_hit_false_on_miss() -> None:
    """delete() returns True on existing key, False on missing key."""
    reg = CernoRegistry(max_size=4, ttl_seconds=60.0)
    reg.get_or_create("c1")

    assert reg.delete("c1") is True
    # Second delete on same key — now missing → False.
    assert reg.delete("c1") is False
    # Never-created key → False.
    assert reg.delete("ghost") is False
    # Wrong tenant → False even though the key exists under default.
    reg.get_or_create("c2")
    assert reg.delete("c2", tenant="ghost-tenant") is False
    assert reg.delete("c2", tenant="default") is True


# ── Extra smoke test: iter_entries + size ─────────────────────


def test_iter_entries_yields_all_tenants() -> None:
    """iter_entries yields every (tenant, child_id, cerno) across tenants."""
    reg = CernoRegistry(max_size=4, ttl_seconds=60.0)
    reg.get_or_create("a", tenant="T1")
    reg.get_or_create("b", tenant="T2")

    rows = reg.iter_entries()
    assert len(rows) == 2
    tenants_seen = {r[0] for r in rows}
    assert tenants_seen == {"T1", "T2"}
    for _tenant, _cid, arb in rows:
        assert isinstance(arb, Cerno)
