"""Unit tests for the Anthropic Messages thin gateway.

Covers the pure transform helpers only — no HTTP, no provider
round-trips. Integration tests against a real Ollama / llama.cpp
backend live in the live-smoke harness, which is excluded from the
default pytest run.

The transform functions are deliberately pure so that every
gateway-level decision (model routing, num_ctx precedence,
Anthropic ↔ OpenAI shape mapping) is exercisable in microseconds
without spinning a server.
"""
from __future__ import annotations

import pytest

from persona.api import (
    _MESSAGES_MODEL_ROUTES,
    _anthropic_to_openai_messages,
    _check_messages_auth,
    _flatten_anthropic_text,
    _openai_to_anthropic_response,
    _resolve_model_route,
    _resolve_num_ctx,
)
from persona.providers.ollama import _DEFAULT_NUM_CTX


# ── _anthropic_to_openai_messages ───────────────────────────


class TestAnthropicToOpenAIMessages:
    """Anthropic Messages turns → OpenAI ChatCompletion turns."""

    def test_string_system_becomes_first_system_message(self) -> None:
        out = _anthropic_to_openai_messages(
            "You are helpful.",
            [{"role": "user", "content": "Hi"}],
        )
        assert out == [
            {"role": "system", "content": "You are helpful."},
            {"role": "user", "content": "Hi"},
        ]

    def test_empty_system_is_dropped(self) -> None:
        out = _anthropic_to_openai_messages(
            "  ",
            [{"role": "user", "content": "Hi"}],
        )
        assert out == [{"role": "user", "content": "Hi"}]

    def test_none_system_is_dropped(self) -> None:
        out = _anthropic_to_openai_messages(
            None,
            [{"role": "user", "content": "Hi"}],
        )
        assert out == [{"role": "user", "content": "Hi"}]

    def test_block_list_system_is_concatenated(self) -> None:
        out = _anthropic_to_openai_messages(
            [
                {"type": "text", "text": "You are "},
                {"type": "text", "text": "helpful."},
            ],
            [{"role": "user", "content": "Hi"}],
        )
        assert out[0] == {"role": "system", "content": "You are helpful."}

    def test_assistant_turn_passthrough(self) -> None:
        out = _anthropic_to_openai_messages(
            None,
            [
                {"role": "user", "content": "Hi"},
                {"role": "assistant", "content": "Hello back"},
            ],
        )
        assert out == [
            {"role": "user", "content": "Hi"},
            {"role": "assistant", "content": "Hello back"},
        ]

    def test_block_list_message_content(self) -> None:
        out = _anthropic_to_openai_messages(
            None,
            [{
                "role": "user",
                "content": [
                    {"type": "text", "text": "part1 "},
                    {"type": "text", "text": "part2"},
                ],
            }],
        )
        assert out == [{"role": "user", "content": "part1 part2"}]

    def test_non_text_blocks_are_dropped(self) -> None:
        # Image / tool_use / tool_result blocks are silently skipped:
        # local Gemma4 backend cannot consume them, and 400-ing every
        # request that contains one would block PSYCHE TS even when
        # the relevant block is irrelevant to this turn.
        out = _anthropic_to_openai_messages(
            None,
            [{
                "role": "user",
                "content": [
                    {"type": "image", "source": {"type": "base64"}},
                    {"type": "text", "text": "describe please"},
                ],
            }],
        )
        assert out == [{"role": "user", "content": "describe please"}]

    def test_invalid_role_raises(self) -> None:
        with pytest.raises(ValueError, match="role must be"):
            _anthropic_to_openai_messages(
                None,
                [{"role": "system", "content": "no"}],
            )

    def test_non_dict_message_raises(self) -> None:
        with pytest.raises(ValueError, match="must be an object"):
            _anthropic_to_openai_messages(None, ["just a string"])  # type: ignore[list-item]

    def test_empty_assistant_content_becomes_empty_string(self) -> None:
        # Anthropic permits empty assistant turns as a prefill hint,
        # but OpenAI rejects ``content=None``. We always coerce to "".
        out = _anthropic_to_openai_messages(
            None,
            [
                {"role": "user", "content": "x"},
                {"role": "assistant", "content": []},
            ],
        )
        assert out[1] == {"role": "assistant", "content": ""}


# ── _flatten_anthropic_text ─────────────────────────────────


class TestFlattenAnthropicText:
    """Edge cases for the content-block flattener."""

    def test_string_passthrough(self) -> None:
        assert _flatten_anthropic_text("hello") == "hello"

    def test_none_returns_empty(self) -> None:
        assert _flatten_anthropic_text(None) == ""

    def test_empty_list_returns_empty(self) -> None:
        assert _flatten_anthropic_text([]) == ""

    def test_unknown_block_type_skipped(self) -> None:
        assert _flatten_anthropic_text(
            [{"type": "tool_use", "id": "x"}, {"type": "text", "text": "kept"}],
        ) == "kept"


# ── _openai_to_anthropic_response ───────────────────────────


class TestOpenAIToAnthropicResponse:
    """Plain text + finish_reason → Anthropic Messages response."""

    def test_basic_response_shape(self) -> None:
        resp = _openai_to_anthropic_response(
            "Hi back!",
            "gemma4-31b-official",
            stop_reason="stop",
            input_tokens=10,
            output_tokens=3,
        )
        assert resp["type"] == "message"
        assert resp["role"] == "assistant"
        assert resp["model"] == "gemma4-31b-official"
        assert resp["content"] == [{"type": "text", "text": "Hi back!"}]
        assert resp["stop_reason"] == "end_turn"
        assert resp["usage"] == {"input_tokens": 10, "output_tokens": 3}
        assert resp["id"].startswith("msg_")

    def test_length_finish_maps_to_max_tokens(self) -> None:
        resp = _openai_to_anthropic_response(
            "x", "gemma4-nsfw", stop_reason="length",
        )
        assert resp["stop_reason"] == "max_tokens"

    def test_tool_calls_finish_maps_to_tool_use(self) -> None:
        resp = _openai_to_anthropic_response(
            "", "gemma4-nsfw", stop_reason="tool_calls",
        )
        assert resp["stop_reason"] == "tool_use"

    def test_unknown_stop_reason_falls_back_to_end_turn(self) -> None:
        resp = _openai_to_anthropic_response(
            "", "gemma4-nsfw", stop_reason="???",
        )
        assert resp["stop_reason"] == "end_turn"


# ── _resolve_model_route ────────────────────────────────────


class TestResolveModelRoute:
    """Routing table lookup."""

    def test_official_route(self) -> None:
        # Default base_url comes from ``GEMMA_URL`` env (or 11434 if
        # unset). The historical ``:8400`` was a wire-mismatch with
        # the deploy SOP — fixed 2026-04-26 (red-team F2).
        provider, base_url, model = _resolve_model_route(
            "gemma4-31b-official",
        )
        assert provider == "ollama"
        assert base_url is not None and base_url.endswith("/v1")
        assert model == "gemma4:31b"

    def test_nsfw_route_gemma4(self) -> None:
        # gemma4-nsfw = currently LIVE backend (mradermacher Gemma-4-31B
        # abliterated Q4_K_M, 2026-04-27 onwards). Each alias names its
        # own model + has its own GEMMA4_NSFW_URL env override.
        provider, base_url, model = _resolve_model_route("gemma4-nsfw")
        assert provider == "ollama"
        assert base_url is not None and base_url.endswith("/v1")
        assert model == "gemma4-nsfw"

    def test_gemma3_nsfw_removed(self) -> None:
        # 2026-04-27g: gemma3-nsfw alias removed — Gemma-3 line discontinued.
        # gemma4-nsfw is the canonical and only NSFW alias.
        with pytest.raises(KeyError, match="unknown model"):
            _resolve_model_route("gemma3-nsfw")

    def test_claude_models_rejected(self) -> None:
        with pytest.raises(PermissionError, match="claude-"):
            _resolve_model_route("claude-3-5-sonnet-20241022")

    def test_unknown_model_raises_keyerror(self) -> None:
        with pytest.raises(KeyError, match="unknown model"):
            _resolve_model_route("gpt-99")

    def test_empty_model_raises(self) -> None:
        with pytest.raises(KeyError):
            _resolve_model_route("")

    def test_routes_table_is_non_empty(self) -> None:
        # Sanity guard against accidental wipe of the routing table —
        # an empty dict would make every request 404.
        assert len(_MESSAGES_MODEL_ROUTES) >= 2


# ── _resolve_num_ctx ────────────────────────────────────────


class _FakeHeaders:
    """Mimic Starlette's Headers ``.get`` (case-insensitive lower-key)."""

    def __init__(self, **kwargs: str) -> None:
        # Starlette Headers normalise to lowercase on lookup.
        self._d = {k.lower(): v for k, v in kwargs.items()}

    def get(self, key: str, default: str | None = None) -> str | None:
        return self._d.get(key.lower(), default)


class TestResolveNumCtx:
    """Precedence: body > header > env > default."""

    def test_body_wins(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.setenv("GEMMA_NUM_CTX", "999")
        out = _resolve_num_ctx(
            {"num_ctx": 4096},
            _FakeHeaders(**{"X-Num-Ctx": "8192"}),
        )
        assert out == 4096

    def test_header_wins_over_env(
        self, monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        monkeypatch.setenv("GEMMA_NUM_CTX", "999")
        out = _resolve_num_ctx(
            {}, _FakeHeaders(**{"X-Num-Ctx": "8192"}),
        )
        assert out == 8192

    def test_env_wins_over_default(
        self, monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        monkeypatch.setenv("GEMMA_NUM_CTX", "12345")
        out = _resolve_num_ctx({}, _FakeHeaders())
        assert out == 12345

    def test_default_used_when_nothing_set(
        self, monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        monkeypatch.delenv("GEMMA_NUM_CTX", raising=False)
        out = _resolve_num_ctx({}, _FakeHeaders())
        assert out == _DEFAULT_NUM_CTX

    def test_invalid_body_value_falls_through(
        self, monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        monkeypatch.setenv("GEMMA_NUM_CTX", "555")
        out = _resolve_num_ctx({"num_ctx": "not-a-number"}, _FakeHeaders())
        assert out == 555

    def test_negative_body_value_falls_through(
        self, monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        monkeypatch.delenv("GEMMA_NUM_CTX", raising=False)
        out = _resolve_num_ctx({"num_ctx": -1}, _FakeHeaders())
        assert out == _DEFAULT_NUM_CTX


# ── _check_messages_auth (red-team F1: dual-header support) ─


class TestCheckMessagesAuth:
    """Auth header acceptance — both Authorization Bearer and
    X-Sancio-Key carry the same secret (PSYCHE TS uses the latter)."""

    def test_unset_key_lets_through_with_warning(
        self, monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        # Dev-frictionless path: no env, no headers, returns None.
        monkeypatch.delenv("SANCIO_API_KEY", raising=False)
        assert _check_messages_auth(_FakeHeaders()) is None

    def test_authorization_bearer_accepted(
        self, monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        monkeypatch.setenv("SANCIO_API_KEY", "secret-xyz")
        h = _FakeHeaders(**{"Authorization": "Bearer secret-xyz"})
        assert _check_messages_auth(h) is None

    def test_x_sancio_key_accepted(
        self, monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        # PSYCHE TS legacy header (src/anthropic.ts:38).
        monkeypatch.setenv("SANCIO_API_KEY", "secret-xyz")
        h = _FakeHeaders(**{"X-Sancio-Key": "secret-xyz"})
        assert _check_messages_auth(h) is None

    def test_authorization_takes_precedence_over_x_sancio(
        self, monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        # When both are present, Authorization wins. Wrong Bearer +
        # right X-Sancio-Key still 401 — keeps the precedence simple
        # to reason about and prevents a partial-auth confusion.
        monkeypatch.setenv("SANCIO_API_KEY", "secret-xyz")
        h = _FakeHeaders(**{
            "Authorization": "Bearer wrong",
            "X-Sancio-Key": "secret-xyz",
        })
        resp = _check_messages_auth(h)
        assert resp is not None
        assert resp.status_code == 401

    def test_wrong_bearer_returns_401(
        self, monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        monkeypatch.setenv("SANCIO_API_KEY", "secret-xyz")
        h = _FakeHeaders(**{"Authorization": "Bearer wrong"})
        resp = _check_messages_auth(h)
        assert resp is not None
        assert resp.status_code == 401

    def test_wrong_x_sancio_key_returns_401(
        self, monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        monkeypatch.setenv("SANCIO_API_KEY", "secret-xyz")
        h = _FakeHeaders(**{"X-Sancio-Key": "wrong"})
        resp = _check_messages_auth(h)
        assert resp is not None
        assert resp.status_code == 401

    def test_no_header_returns_401(
        self, monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        monkeypatch.setenv("SANCIO_API_KEY", "secret-xyz")
        resp = _check_messages_auth(_FakeHeaders())
        assert resp is not None
        assert resp.status_code == 401

    def test_malformed_authorization_falls_back_to_x_sancio(
        self, monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        # If Authorization is present but not "Bearer <key>" shape,
        # we drop to the X-Sancio-Key fallback rather than 401-ing
        # immediately — avoids breaking PSYCHE TS clients that might
        # accidentally send Authorization: Basic ... or similar.
        monkeypatch.setenv("SANCIO_API_KEY", "secret-xyz")
        h = _FakeHeaders(**{
            "Authorization": "Basic deadbeef",
            "X-Sancio-Key": "secret-xyz",
        })
        assert _check_messages_auth(h) is None


# ── _resolve_model_route env-driven base_url (red-team F2) ──


class TestModelRouteEnvResolution:
    """``GEMMA_URL`` / ``GEMMA_NSFW_URL`` env vars override defaults.

    Module-level ``_MESSAGES_MODEL_ROUTES`` is built at import time so
    these tests assert the *default* shape (``/v1`` suffix) rather
    than re-importing under a monkeypatched env. Dynamic re-resolve
    is left to the deploy SOP — uvicorn process is the unit of env
    application, not per-request.
    """

    def test_official_default_uses_ollama_port(self) -> None:
        # The historical ``:8400`` was a wire-mismatch with the deploy
        # SOP (which spins Ollama on :11434). Default must align with
        # the SOP, not with the broken constant.
        _, base_url, _ = _resolve_model_route("gemma4-31b-official")
        assert base_url is not None
        # Default-or-env value must end ``/v1`` so the OpenAI-compat
        # path concatenation keeps working.
        assert base_url.endswith("/v1")

    def test_nsfw_default_points_at_llama_cpp(self) -> None:
        # 2026-04-27g: gemma4-nsfw is the canonical and only NSFW alias
        # after Gemma-3 line was discontinued and aliases removed.
        _, base_url, _ = _resolve_model_route("gemma4-nsfw")
        assert base_url is not None
        assert base_url.endswith("/v1")
