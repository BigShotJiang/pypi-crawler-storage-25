"""Tests for ``persona.slash`` package (M1 Week 2 task #8.2).

Covers:
  * SlashRegistry: register / unregister / aliases / resolve / dispatch
  * Builtin commands: clear, compact, status, model, help, resume
  * Builtin alias names registered correctly
  * Dispatch: unknown command, empty input, leading-slash check
  * /clear: empties messages + compactor history
  * /compact: with/without compactor; force vs threshold paths
  * /status: with/without compactor; with/without session_persist
  * /model: list mode, switch mode, alias resolution
  * /help: full listing, single-command detail, missing registry
  * /resume: missing store, missing arg, missing checkpoint, happy
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

import pytest

from persona.compaction import AutoCompactor, CompactionConfig
from persona.slash import (
    SlashCommand,
    SlashContext,
    SlashRegistry,
    build_default_registry,
    builtin_commands,
)
from persona.slash.commands import (
    clear_command,
    compact_command,
    exit_command,
    help_command,
    model_command,
    quit_command,
    resume_command,
    status_command,
)


# ─────────────────────────────────────────────────────────────────
# Fakes
# ─────────────────────────────────────────────────────────────────


@dataclass
class _RecPrinter:
    lines: list[str] = field(default_factory=list)

    def print(self, *args: Any, **_kwargs: Any) -> None:
        self.lines.append(" ".join(str(a) for a in args))

    def rule(self, title: str = "", **_kwargs: Any) -> None:
        self.lines.append(f"--- {title} ---")


def _ctx(**overrides: Any) -> SlashContext:
    base = SlashContext(
        messages=overrides.pop("messages", []),
        printer=overrides.pop("printer", _RecPrinter()),
        model_id=overrides.pop("model_id", "claude-sonnet-4-7"),
        compactor=overrides.pop("compactor", None),
        session_persist=overrides.pop("session_persist", None),
        session_id=overrides.pop("session_id", "abc123"),
    )
    if "extras" in overrides:
        base.extras.update(overrides.pop("extras"))
    return base


# ─────────────────────────────────────────────────────────────────
# SlashRegistry core
# ─────────────────────────────────────────────────────────────────


class TestSlashRegistry:
    def test_empty(self) -> None:
        r = SlashRegistry()
        assert len(r) == 0
        assert r.names() == []
        assert r.commands() == []

    def test_register_basic(self) -> None:
        r = SlashRegistry()
        r.register_function("foo", "do foo", lambda c, a: True)
        assert "foo" in r
        assert len(r) == 1

    def test_aliases_resolve(self) -> None:
        r = SlashRegistry()
        r.register_function("foo", "do foo", lambda c, a: True, aliases=("bar", "baz"))
        cmd_via_alias = r.resolve("bar")
        cmd_via_canonical = r.resolve("foo")
        assert cmd_via_alias is cmd_via_canonical
        assert "baz" in r

    def test_alias_canonical_collision_skipped(self) -> None:
        # When the alias matches the canonical name we don't double-register.
        r = SlashRegistry()
        r.register_function("foo", "doc", lambda c, a: True, aliases=("foo",))
        # Canonical wins; aliases_for("foo") excludes the canonical itself.
        assert r.aliases_for("foo") == []

    def test_unregister(self) -> None:
        r = SlashRegistry()
        r.register_function("foo", "doc", lambda c, a: True, aliases=("alias",))
        assert r.unregister("foo") is True
        assert r.unregister("foo") is False
        assert "alias" not in r

    def test_unregister_via_alias(self) -> None:
        r = SlashRegistry()
        r.register_function("foo", "doc", lambda c, a: True, aliases=("alias",))
        assert r.unregister("alias") is True
        assert "foo" not in r

    def test_register_overwrites(self) -> None:
        r = SlashRegistry()
        r.register_function("foo", "v1", lambda c, a: True)
        r.register_function("foo", "v2", lambda c, a: True)
        assert r.resolve("foo").doc == "v2"

    def test_empty_name_rejected(self) -> None:
        r = SlashRegistry()
        with pytest.raises(ValueError):
            r.register_function("", "doc", lambda c, a: True)

    def test_by_category(self) -> None:
        r = SlashRegistry()
        r.register_function("a", "doc", lambda c, a: True, category="x")
        r.register_function("b", "doc", lambda c, a: True, category="y")
        r.register_function("c", "doc", lambda c, a: True, category="x")
        groups = r.by_category()
        assert sorted(groups.keys()) == ["x", "y"]
        assert len(groups["x"]) == 2

    def test_contains_non_string(self) -> None:
        r = SlashRegistry()
        assert (123 in r) is False  # type: ignore[operator]


# ─────────────────────────────────────────────────────────────────
# Dispatch
# ─────────────────────────────────────────────────────────────────


class TestDispatch:
    def test_unknown_command(self) -> None:
        r = SlashRegistry()
        ctx = _ctx()
        result = r.dispatch("/nope", ctx)
        assert result is True
        assert any("unknown" in line.lower() for line in ctx.printer.lines)

    def test_empty_command(self) -> None:
        r = SlashRegistry()
        ctx = _ctx()
        r.dispatch("/", ctx)
        assert any("empty" in line.lower() for line in ctx.printer.lines)

    def test_no_leading_slash(self) -> None:
        r = SlashRegistry()
        ctx = _ctx()
        r.dispatch("foo", ctx)
        assert any("leading slash" in line.lower() for line in ctx.printer.lines)

    def test_arg_passing(self) -> None:
        seen: list[str] = []

        def handler(c: SlashContext, args: str) -> bool:
            seen.append(args)
            return True

        r = SlashRegistry()
        r.register_function("greet", "doc", handler)
        r.dispatch("/greet hello world", _ctx())
        assert seen == ["hello world"]

    def test_handler_returns_false_terminates(self) -> None:
        r = SlashRegistry()
        r.register_function("bye", "doc", lambda c, a: False)
        result = r.dispatch("/bye", _ctx())
        assert result is False


# ─────────────────────────────────────────────────────────────────
# Builtins listing
# ─────────────────────────────────────────────────────────────────


class TestBuiltins:
    def test_default_registry_shape(self) -> None:
        r = build_default_registry()
        # 5 core + exit/quit/resume = 8
        for name in ("clear", "compact", "status", "model", "help", "resume", "exit", "quit"):
            assert name in r

    def test_builtin_commands_returns_list(self) -> None:
        cmds = builtin_commands()
        assert all(isinstance(c, SlashCommand) for c in cmds)
        assert len(cmds) >= 5

    def test_help_alias(self) -> None:
        r = build_default_registry()
        assert r.resolve("?") is r.resolve("help")

    def test_clear_alias(self) -> None:
        r = build_default_registry()
        assert r.resolve("reset") is r.resolve("clear")


# ─────────────────────────────────────────────────────────────────
# /clear
# ─────────────────────────────────────────────────────────────────


class TestClear:
    def test_empties_messages(self) -> None:
        msgs = [{"role": "user", "content": "hi"}, {"role": "assistant", "content": "yo"}]
        ctx = _ctx(messages=msgs)
        clear_command().handler(ctx, "")
        assert ctx.messages == []

    def test_clears_compactor_history(self) -> None:
        comp = AutoCompactor(CompactionConfig(context_window=1_000_000))
        comp.force_compact([{"role": "user", "content": "x" * 100} for _ in range(8)])
        assert len(comp.history) > 0
        ctx = _ctx(messages=[{"role": "user", "content": "x"}], compactor=comp)
        clear_command().handler(ctx, "")
        assert len(comp.history) == 0

    def test_returns_true(self) -> None:
        ctx = _ctx()
        assert clear_command().handler(ctx, "") is True


# ─────────────────────────────────────────────────────────────────
# /compact
# ─────────────────────────────────────────────────────────────────


class TestCompact:
    def test_no_compactor_warns(self) -> None:
        ctx = _ctx(compactor=None)
        compact_command().handler(ctx, "")
        assert any("no compactor" in line.lower() for line in ctx.printer.lines)

    def test_force_path_runs(self) -> None:
        comp = AutoCompactor(
            CompactionConfig(
                context_window=1_000_000,
                preserve_last_user_turns=1,
                min_messages_to_compact=2,
            ),
        )
        msgs = [{"role": "user", "content": "x" * 200} for _ in range(10)]
        ctx = _ctx(messages=msgs, compactor=comp)
        compact_command().handler(ctx, "")
        assert any("compacted" in line.lower() for line in ctx.printer.lines)
        # Slice-assignment kept the same list identity.
        assert ctx.messages is msgs

    def test_handles_compactor_exception(self) -> None:
        class _Boom:
            def force_compact(self, _msgs: Any) -> Any:
                raise RuntimeError("simulated")

        ctx = _ctx(compactor=_Boom())
        compact_command().handler(ctx, "")
        assert any("compaction failed" in line.lower() for line in ctx.printer.lines)


# ─────────────────────────────────────────────────────────────────
# /status
# ─────────────────────────────────────────────────────────────────


class TestStatus:
    def test_basic_no_compactor(self) -> None:
        ctx = _ctx(messages=[{"role": "user", "content": "x"}])
        status_command().handler(ctx, "")
        text = "\n".join(ctx.printer.lines)
        assert "messages" in text
        assert "no compactor attached" in text

    def test_with_compactor(self) -> None:
        comp = AutoCompactor(CompactionConfig(context_window=10_000))
        ctx = _ctx(messages=[{"role": "user", "content": "x"}], compactor=comp)
        status_command().handler(ctx, "")
        text = "\n".join(ctx.printer.lines)
        assert "tokens" in text
        assert "(never)" in text  # never compacted yet

    def test_with_compactor_after_event(self) -> None:
        comp = AutoCompactor(
            CompactionConfig(
                context_window=1_000_000,
                preserve_last_user_turns=1,
                min_messages_to_compact=2,
            ),
        )
        msgs = [{"role": "user", "content": "x" * 200} for _ in range(10)]
        comp.force_compact(msgs)
        ctx = _ctx(messages=msgs, compactor=comp)
        status_command().handler(ctx, "")
        text = "\n".join(ctx.printer.lines)
        assert "last compact" in text
        assert "(never)" not in text

    def test_with_session_persist(self) -> None:
        class _Store:
            def get_manifest(self, sid: str) -> dict[str, Any] | None:
                return {
                    "session_id": sid,
                    "created_at": "2026-01-01T00:00:00Z",
                    "last_active": "2026-01-02T00:00:00Z",
                    "checkpoint_count": 4,
                }

        ctx = _ctx(session_persist=_Store())
        status_command().handler(ctx, "")
        text = "\n".join(ctx.printer.lines)
        assert "checkpoints 4" in text


# ─────────────────────────────────────────────────────────────────
# /model
# ─────────────────────────────────────────────────────────────────


class TestModel:
    def test_no_arg_prints_current(self) -> None:
        ctx = _ctx(model_id="claude-sonnet-4-7")
        model_command().handler(ctx, "")
        text = "\n".join(ctx.printer.lines)
        assert "current model" in text
        assert "aliases" in text

    def test_alias_resolves(self) -> None:
        ctx = _ctx(model_id="old-model")
        model_command().handler(ctx, "haiku")
        assert ctx.model_id == "claude-haiku-4-5"
        assert ctx.extras["model_change"]["from"] == "old-model"

    def test_unknown_alias_passthrough(self) -> None:
        ctx = _ctx()
        model_command().handler(ctx, "private-model-foo")
        assert ctx.model_id == "private-model-foo"

    def test_canonical_passes_through(self) -> None:
        ctx = _ctx()
        model_command().handler(ctx, "claude-opus-4-7")
        assert ctx.model_id == "claude-opus-4-7"

    def test_opus_1m_alias(self) -> None:
        ctx = _ctx()
        model_command().handler(ctx, "opus-1m")
        assert "1m" in ctx.model_id


# ─────────────────────────────────────────────────────────────────
# /help
# ─────────────────────────────────────────────────────────────────


class TestHelp:
    def test_full_listing(self) -> None:
        r = build_default_registry()
        ctx = _ctx(extras={"registry": r})
        help_command().handler(ctx, "")
        text = "\n".join(ctx.printer.lines)
        assert "/clear" in text
        assert "/compact" in text
        assert "/status" in text

    def test_single_command_detail(self) -> None:
        r = build_default_registry()
        ctx = _ctx(extras={"registry": r})
        help_command().handler(ctx, "model")
        text = "\n".join(ctx.printer.lines)
        assert "/model" in text
        assert "category" in text

    def test_unknown_command(self) -> None:
        r = build_default_registry()
        ctx = _ctx(extras={"registry": r})
        help_command().handler(ctx, "nope")
        text = "\n".join(ctx.printer.lines)
        assert "no command" in text.lower()

    def test_missing_registry(self) -> None:
        ctx = _ctx()  # no extras["registry"]
        help_command().handler(ctx, "")
        text = "\n".join(ctx.printer.lines)
        assert "registry missing" in text.lower()


# ─────────────────────────────────────────────────────────────────
# /resume
# ─────────────────────────────────────────────────────────────────


class TestResume:
    def test_no_store_warns(self) -> None:
        ctx = _ctx(session_persist=None)
        resume_command().handler(ctx, "abc")
        assert any("no SessionStore" in line for line in ctx.printer.lines)

    def test_missing_arg(self) -> None:
        class _Store:
            pass

        ctx = _ctx(session_persist=_Store())
        resume_command().handler(ctx, "")
        text = "\n".join(ctx.printer.lines)
        assert "requires a session id" in text

    def test_missing_checkpoint(self) -> None:
        class _Store:
            def load_latest_checkpoint(self, _sid: str) -> dict[str, Any] | None:
                return None

        ctx = _ctx(session_persist=_Store())
        resume_command().handler(ctx, "deadbeef")
        text = "\n".join(ctx.printer.lines)
        assert "no checkpoint" in text.lower()

    def test_happy_path(self) -> None:
        snapshot = {
            "messages": [
                {"role": "user", "content": "saved q"},
                {"role": "assistant", "content": "saved a"},
            ],
            "model_id": "claude-haiku-4-5",
        }

        class _Store:
            def load_latest_checkpoint(self, _sid: str) -> dict[str, Any] | None:
                return snapshot

        msgs: list[dict[str, Any]] = []
        ctx = _ctx(messages=msgs, session_persist=_Store(), model_id="other-model")
        resume_command().handler(ctx, "deadbeef")
        # Slice-assignment kept identity but loaded the snapshot's entries.
        assert ctx.messages is msgs
        assert len(ctx.messages) == 2
        assert ctx.model_id == "claude-haiku-4-5"
        assert ctx.session_id == "deadbeef"

    def test_handles_store_exception(self) -> None:
        class _Boom:
            def load_latest_checkpoint(self, _sid: str) -> dict[str, Any]:
                raise RuntimeError("disk full")

        ctx = _ctx(session_persist=_Boom())
        resume_command().handler(ctx, "abc")
        assert any("resume failed" in line for line in ctx.printer.lines)


# ─────────────────────────────────────────────────────────────────
# /exit /quit
# ─────────────────────────────────────────────────────────────────


class TestExitQuit:
    def test_exit_returns_false(self) -> None:
        assert exit_command().handler(_ctx(), "") is False

    def test_quit_returns_false(self) -> None:
        assert quit_command().handler(_ctx(), "") is False
