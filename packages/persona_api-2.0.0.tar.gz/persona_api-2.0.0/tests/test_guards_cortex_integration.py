"""Tests for persona.guards CortexLibrary integration.

persona-api hard-depends on concinno>=1.17.1 (declared in
pyproject.toml). The legacy 9-pattern regex fallback was removed in
M3 (2026-04-14, master decision §16.7); concinno must be importable
at module load and runtime exceptions fail closed (DANGEROUS).

These tests verify the thin wrapper behaviour:

  1. Dangerous input (rm -rf /) → DANGEROUS via CortexLibrary
  2. Benign input (hello) → SAFE
  3. get_cortex() singleton — repeat calls return identical instance
  4. reset_cortex_singleton() forces a fresh instance
  5. SafetyResult dataclass shape is backward compatible
  6. CortexLibrary runtime exception → fail-closed DANGEROUS
  7. Long benign message → UNCERTAIN (length_anomaly heuristic)
"""

from __future__ import annotations

from dataclasses import fields
from typing import Any

import pytest

import persona.guards as guards_mod
from persona.guards import (
    SafetyLevel,
    SafetyResult,
    classify_safety,
    get_cortex,
    reset_cortex_singleton,
)


@pytest.fixture(autouse=True)
def _reset_singleton() -> None:
    """Ensure every test starts with a clean singleton."""
    reset_cortex_singleton()
    yield
    reset_cortex_singleton()


# ── 1. Dangerous via CortexLibrary ──────────────


def test_classify_safety_dangerous_rm_rf() -> None:
    """P0#1 Task 8 — bare ``rm -rf /`` user message is NOT DANGEROUS.

    Pre-P0 this assertion was ``== DANGEROUS`` because the function
    routed user chat through the Bash guard pipeline, which fired
    destruction rules on any string containing ``rm -rf``. That
    false-denied legitimate conversational mentions of the command.
    Post-Task 8 user messages flow through the prompt-injection
    surface + ``Write``-shaped pipeline; a bare command string that
    isn't a jailbreak attempt lands as SAFE. Destruction of actual
    bash invocations is caught at tool-execution time by the
    ``default_policy`` rules (see ``test_default_policy_bypass.py``).
    """
    result = classify_safety("rm -rf /")
    assert result.level != SafetyLevel.DANGEROUS


# ── 2. Benign via CortexLibrary ─────────────────


def test_classify_safety_safe_hello() -> None:
    """Plain hello should be SAFE."""
    result = classify_safety("hello")
    assert result.level == SafetyLevel.SAFE


# ── 3. Singleton behaviour ──────────────────────


def test_get_cortex_singleton_same_instance() -> None:
    """Repeat get_cortex() calls return identical CortexLibrary."""
    first = get_cortex()
    second = get_cortex()
    assert first is second
    assert first is not None  # hard-depend: never None


# ── 4. Singleton reset ──────────────────────────


def test_reset_singleton_allows_reinit() -> None:
    """reset_cortex_singleton clears cached state and yields a fresh instance."""
    first = get_cortex()
    reset_cortex_singleton()
    second = get_cortex()
    assert first is not second


# ── 5. SafetyResult shape backward compat ──────


def test_safety_result_dataclass_shape_frozen() -> None:
    """Public API: SafetyResult must expose level/threat_type/detail."""
    field_names = {f.name for f in fields(SafetyResult)}
    assert field_names == {"level", "threat_type", "detail"}

    # Default construction still works (callers may omit optional fields)
    empty = SafetyResult(level=SafetyLevel.SAFE)
    assert empty.level == SafetyLevel.SAFE
    assert empty.threat_type == ""
    assert empty.detail == ""


# ── 6. CortexLibrary runtime exception → fail-closed ──


def test_classify_safety_fail_closed_on_cortex_exception(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """If CortexLibrary.check_safety raises, return DANGEROUS (fail closed)."""

    class _Exploding:
        def check_safety(self, *args: Any, **kwargs: Any) -> Any:
            raise RuntimeError("simulated pipeline crash")

    # Force get_cortex() to return the exploding stub
    monkeypatch.setattr(
        guards_mod, "_cortex_library", _Exploding(), raising=False,
    )

    result = classify_safety("rm -rf /")
    assert result.level == SafetyLevel.DANGEROUS  # fail closed
    assert result.threat_type == "cortex_runtime_error"
    assert "simulated pipeline crash" in result.detail


# ── 7. Length anomaly heuristic ─────────────────


def test_classify_safety_length_uncertain() -> None:
    """Benign but very long message → UNCERTAIN."""
    # 6000 chars of 'a' — benign content, trips the 5000-char heuristic
    result = classify_safety("a" * 6000)
    assert result.level == SafetyLevel.UNCERTAIN
    assert result.threat_type == "length_anomaly"
