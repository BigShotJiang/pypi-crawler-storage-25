"""Tests for :mod:`persona.skills_proactive` + UserPromptSubmit hook.

Covers the 12-case acceptance matrix from the Week 1 Sancio task brief
(`pip-4-2-5-typed-lamport.md` line 47):

1.  frontmatter scan correctly parses YAML-lite SKILL.md blocks
2.  cache TTL expiry triggers a re-scan
3.  cheap_filter narrows the candidate set as advertised
4.  haiku_judge with a fake judge_fn returns top-K Matches
5.  discover top-K results sorted by score
6.  graceful degrade when no Anthropic API key is configured
7.  multilingual user prompts (zh-TW + en) hit the same Skill
8.  corrupted SKILL.md frontmatter does not crash the scanner
9.  corrupt cache file rebuilds gracefully
10. UserPromptSubmit hook integration smoke (formatted hint output)
11. ZIQ outcome bus emit (using the real bus with a subscriber)
12. existing sancio import paths remain importable (regression)
"""

from __future__ import annotations

import asyncio
import json
import time
from pathlib import Path

import pytest

from persona import skills_proactive as sp
from persona.hooks.skill_proactive_hook import (
    format_hint_lines,
    make_skill_proactive_hook,
)
from persona.skills_proactive import (
    Match,
    SkillDiscovery,
    SkillManifest,
    is_disabled,
)


# ── Fixtures ──────────────────────────────────────────────────────


def _write_skill(
    root: Path,
    name: str,
    description: str,
    triggers: list[str] | None = None,
    extra_body: str = "",
) -> Path:
    skill_dir = root / name
    skill_dir.mkdir(parents=True, exist_ok=True)
    triggers_line = ""
    if triggers is not None:
        # Inline list form for compactness.
        triggers_line = (
            "triggers: ["
            + ", ".join(f"'{t}'" for t in triggers)
            + "]\n"
        )
    body = (
        "---\n"
        f"name: {name}\n"
        f"description: {description}\n"
        f"{triggers_line}"
        "---\n"
        f"\n{extra_body}\n"
    )
    skill_md = skill_dir / "SKILL.md"
    skill_md.write_text(body, encoding="utf-8")
    return skill_md


@pytest.fixture
def skills_root(tmp_path: Path) -> Path:
    root = tmp_path / "skills"
    root.mkdir()
    _write_skill(
        root,
        "kb_handoff",
        "Handoff hygiene + compression + routing for session pass-baton",
        triggers=["交接", "handoff", "引き継ぎ", "인수인계", "pass baton"],
    )
    _write_skill(
        root,
        "redteam-cycle",
        "CBUA red-blue adversarial review for major architecture decisions",
        triggers=["紅隊", "red team", "adversarial", "redteam-cycle"],
    )
    _write_skill(
        root,
        "kb_runpod",
        "RunPod GPU pod lifecycle, SSH, network volume rules",
        triggers=["runpod", "GPU pod", "ablation runner"],
    )
    return root


@pytest.fixture
def cache_path(tmp_path: Path) -> Path:
    return tmp_path / "skill_proactive_cache.json"


@pytest.fixture(autouse=True)
def _disable_real_outcome_bus(monkeypatch: pytest.MonkeyPatch) -> None:
    """Hard-kill the bus by default so emit calls do not touch real
    pinned files. Tests that need the bus opt in via ``monkeypatch.delenv``.
    """
    monkeypatch.setenv("CONCINNO_ZIQ_BUS_DISABLED", "1")
    monkeypatch.delenv("CONCINNO_SKILL_PROACTIVE_DISABLED", raising=False)


# ── 1. Frontmatter scan ───────────────────────────────────────────


def test_scan_frontmatter_parses_all_skills(
    skills_root: Path, cache_path: Path
) -> None:
    disco = SkillDiscovery(skills_root=skills_root, cache_path=cache_path)
    skills = disco.scan_frontmatter()
    names = {s.name for s in skills}
    assert names == {"kb_handoff", "redteam-cycle", "kb_runpod"}
    handoff = next(s for s in skills if s.name == "kb_handoff")
    assert "Handoff hygiene" in handoff.description
    assert "交接" in handoff.triggers
    assert "handoff" in handoff.triggers


# ── 2. Cache TTL ──────────────────────────────────────────────────


def test_cache_ttl_triggers_rescan(
    skills_root: Path, cache_path: Path
) -> None:
    disco = SkillDiscovery(
        skills_root=skills_root,
        cache_path=cache_path,
        ttl_seconds=0.05,
    )
    first = disco.scan_frontmatter()
    # Add a new skill and wait past TTL.
    _write_skill(
        skills_root,
        "kb_extra",
        "Extra skill added after first scan",
        triggers=["extra"],
    )
    time.sleep(0.06)
    second = disco.scan_frontmatter()
    assert {s.name for s in second} - {s.name for s in first} == {"kb_extra"}


# ── 3. cheap_filter ───────────────────────────────────────────────


def test_cheap_filter_narrows_candidates(
    skills_root: Path, cache_path: Path
) -> None:
    disco = SkillDiscovery(skills_root=skills_root, cache_path=cache_path)
    skills = disco.scan_frontmatter()
    narrow = disco.cheap_filter("I need to do a handoff", skills, narrow_to=2)
    assert any(s.name == "kb_handoff" for s in narrow)
    assert len(narrow) <= 2


# ── 4. haiku_judge with injected fake ─────────────────────────────


def test_haiku_judge_with_fake_returns_topk(
    skills_root: Path, cache_path: Path
) -> None:
    def fake_judge(prompt: str, skills: list[SkillManifest], k: int):
        return [
            {"skill_name": s.name, "score": 0.9 - i * 0.1, "reason": "fake"}
            for i, s in enumerate(skills[:k])
        ]

    disco = SkillDiscovery(
        skills_root=skills_root,
        cache_path=cache_path,
        judge_fn=fake_judge,
    )
    skills = disco.scan_frontmatter()
    matches = disco.haiku_judge("handoff please", skills, k=2)
    assert len(matches) == 2
    assert matches[0].score >= matches[1].score
    assert all(isinstance(m, Match) for m in matches)


# ── 5. discover orders by score ───────────────────────────────────


def test_discover_returns_topk_sorted(
    skills_root: Path, cache_path: Path
) -> None:
    def fake_judge(prompt: str, skills: list[SkillManifest], k: int):
        # Force kb_handoff to win over redteam-cycle.
        ordered = sorted(skills, key=lambda s: s.name != "kb_handoff")
        return [
            {
                "skill_name": s.name,
                "score": 0.95 - i * 0.05,
                "reason": "rank",
            }
            for i, s in enumerate(ordered[:k])
        ]

    disco = SkillDiscovery(
        skills_root=skills_root,
        cache_path=cache_path,
        judge_fn=fake_judge,
    )
    matches = disco.discover("handoff for next session", k=2)
    assert matches  # at least one above threshold
    assert matches[0].skill_name == "kb_handoff"
    if len(matches) > 1:
        assert matches[0].score >= matches[1].score


# ── 6. graceful degrade with no API key ───────────────────────────


def test_graceful_degrade_when_judge_returns_none(
    skills_root: Path,
    cache_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.delenv("ANTHROPIC_API_KEY", raising=False)

    def degrade_judge(prompt, skills, k):
        return None  # simulates "no key / SDK missing"

    disco = SkillDiscovery(
        skills_root=skills_root,
        cache_path=cache_path,
        judge_fn=degrade_judge,
    )
    matches = disco.discover("handoff please", k=2)
    # Cheap-filter-only fallback still surfaces candidates with the
    # documented reason string.
    assert matches
    assert all("cheap-filter" in m.reason for m in matches)


# ── 7. Multilingual matching ──────────────────────────────────────


@pytest.mark.parametrize(
    "prompt",
    [
        "I want to handoff to the next session",  # English
        "我想要做交接給下一個 session",  # zh-TW
        "引き継ぎをしたい",  # Japanese
    ],
)
def test_multilingual_prompts_hit_handoff_skill(
    skills_root: Path, cache_path: Path, prompt: str
) -> None:
    disco = SkillDiscovery(skills_root=skills_root, cache_path=cache_path)
    skills = disco.scan_frontmatter()
    narrow = disco.cheap_filter(prompt, skills, narrow_to=3)
    assert any(s.name == "kb_handoff" for s in narrow), (
        f"Expected kb_handoff for prompt {prompt!r}, got {[s.name for s in narrow]}"
    )


# ── 8. Corrupted SKILL.md ─────────────────────────────────────────


def test_corrupt_skill_md_does_not_crash_scanner(
    skills_root: Path, cache_path: Path
) -> None:
    # Skill dir with malformed frontmatter (no closing ---).
    bad_dir = skills_root / "broken_skill"
    bad_dir.mkdir()
    (bad_dir / "SKILL.md").write_text(
        "---\nname: broken_skill\ndescription: missing closing fence",
        encoding="utf-8",
    )
    # Skill dir with no SKILL.md at all (should be skipped silently).
    (skills_root / "empty_dir").mkdir()
    disco = SkillDiscovery(skills_root=skills_root, cache_path=cache_path)
    skills = disco.scan_frontmatter()
    # The good skills survive.
    names = {s.name for s in skills}
    assert "kb_handoff" in names
    # The broken skill is either skipped or partially parsed — either
    # way, no exception was raised.
    assert "kb_runpod" in names


# ── 9. Corrupt cache file rebuilds ────────────────────────────────


def test_corrupt_cache_file_rebuilds(
    skills_root: Path, cache_path: Path
) -> None:
    cache_path.parent.mkdir(parents=True, exist_ok=True)
    cache_path.write_text("not json at all", encoding="utf-8")
    disco = SkillDiscovery(skills_root=skills_root, cache_path=cache_path)
    skills = disco.scan_frontmatter()
    assert skills  # rebuilt without raising


# ── 10. Hook integration smoke ────────────────────────────────────


def test_hook_returns_formatted_hint(
    skills_root: Path,
    cache_path: Path,
    capsys: pytest.CaptureFixture[str],
) -> None:
    def fake_judge(prompt, skills, k):
        return [
            {"skill_name": "kb_handoff", "score": 0.92, "reason": "matches"},
        ]

    disco = SkillDiscovery(
        skills_root=skills_root,
        cache_path=cache_path,
        judge_fn=fake_judge,
    )
    hook = make_skill_proactive_hook(discovery=disco, k=1, write_stderr=True)
    out = asyncio.run(hook("handoff please"))
    assert out is not None
    assert "[skill_proactive] Consider using /kb_handoff" in out
    err = capsys.readouterr().err
    assert "kb_handoff" in err


def test_hook_returns_none_when_disabled(
    skills_root: Path,
    cache_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setenv("CONCINNO_SKILL_PROACTIVE_DISABLED", "1")
    disco = SkillDiscovery(skills_root=skills_root, cache_path=cache_path)
    hook = make_skill_proactive_hook(discovery=disco, k=1)
    out = asyncio.run(hook("handoff please"))
    assert out is None
    assert is_disabled() is True


def test_format_hint_lines_empty_returns_empty_string() -> None:
    assert format_hint_lines([]) == ""


# ── 11. ZIQ outcome bus emit ──────────────────────────────────────


def test_outcome_bus_emit_observed(
    skills_root: Path,
    cache_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    # Re-enable the bus for this test only.
    monkeypatch.delenv("CONCINNO_ZIQ_BUS_DISABLED", raising=False)
    # Redirect the pin file to a temp path to avoid touching ~/.concinno.
    pin_path = cache_path.parent / "ziq_pinned.json"
    monkeypatch.setenv("CONCINNO_ZIQ_PIN_FILE", str(pin_path))

    from concinno.ziq_outcome_bus import (  # noqa: PLC0415
        Outcome,
        ZIQOutcomeBus,
        get_bus,
    )

    ZIQOutcomeBus._reset_for_testing()
    received: list[Outcome] = []
    unsub = get_bus().subscribe(
        "skill_proactive.haiku_score_threshold", received.append
    )
    try:

        def fake_judge(prompt, skills, k):
            return [
                {"skill_name": "kb_handoff", "score": 0.9, "reason": "ok"},
            ]

        disco = SkillDiscovery(
            skills_root=skills_root,
            cache_path=cache_path,
            judge_fn=fake_judge,
        )
        matches = disco.discover("handoff", k=1)
        assert matches
        # discover() emits one outcome with reward=0 (placeholder), then
        # record_skill_usage emits the reward when the agent loop
        # observes the slash-command actually being invoked.
        assert any(o.reward == 0.0 for o in received)
        disco.record_skill_usage("handoff", "kb_handoff", used=True)
        assert any(o.reward == 1.0 for o in received)
    finally:
        unsub()
        ZIQOutcomeBus._reset_for_testing()


# ── 12. Regression: existing imports unbroken ─────────────────────


def test_existing_persona_imports_still_work() -> None:
    # Smoke import of unrelated sancio modules — guarantees the new
    # file did not shadow or conflict with the existing namespace.
    from persona import guards as _guards  # noqa: F401, PLC0415
    from persona.hooks import (  # noqa: F401, PLC0415
        guard_hook as _gh,
    )

    assert _gh is not None


# ── Bonus: cache persistence round-trip ────────────────────────────


def test_cache_persists_and_reloads(
    skills_root: Path, cache_path: Path
) -> None:
    def fake_judge(prompt, skills, k):
        return [{"skill_name": "kb_handoff", "score": 0.8, "reason": "rt"}]

    disco_a = SkillDiscovery(
        skills_root=skills_root,
        cache_path=cache_path,
        judge_fn=fake_judge,
    )
    matches_a = disco_a.discover("handoff", k=1)
    assert matches_a
    assert cache_path.exists()
    payload = json.loads(cache_path.read_text(encoding="utf-8"))
    assert payload["version"] == 1
    # New instance hydrates from disk and serves the same prompt cache.
    disco_b = SkillDiscovery(
        skills_root=skills_root,
        cache_path=cache_path,
        judge_fn=lambda *_a, **_k: pytest.fail("should hit cache"),
    )
    matches_b = disco_b.discover("handoff", k=1)
    assert [m.skill_name for m in matches_b] == [
        m.skill_name for m in matches_a
    ]


def test_module_exports_minimal_surface() -> None:
    # Public names follow the L0 #6 three-layer rule (index symbols
    # only — full body is on disk).
    assert "SkillDiscovery" in sp.__all__
    assert "SkillManifest" in sp.__all__
    assert "Match" in sp.__all__
    assert "is_disabled" in sp.__all__
