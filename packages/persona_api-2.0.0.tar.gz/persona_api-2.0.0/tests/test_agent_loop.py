"""Tests for A1 agent loop — Aegis v3 roadmap.

Original three scenarios cover the state machine contract:

1. **No tools** — loop degrades to single-shot chat. Validates that
   ``chat()`` behaviour is preserved when ``tools={}``.
2. **Multi-round tool use** — LLM calls a tool once, receives the
   result, emits final text on the next turn. Validates history
   append order and ``tool_call_id`` round-trip.
3. **PreToolUse deny** — a :class:`PermissionDenied` from a pre-hook
   records an ``is_error`` tool message and the loop keeps going,
   giving the LLM a chance to recover. Validates Aegis's policy slot.

Sancio 2.0.0 additions (Option C reframe — see
``_AI_BRAIN/05_Planning/2026-05-01-l6-posttooluse-design-conflict-options.md``)
cover the new :data:`PostToolUseHook` contract end-to-end:

* hook returns ``None`` → output unchanged (1.x compat path).
* :class:`PostToolUseDecision(updated_output=...)` → output rewritten.
* ``decision="block"`` → ``is_error=True`` block message.
* multi-hook chain → first non-None ``updated_output`` wins, the
  next hook sees the rewritten value.
* :class:`PostToolDeny` raised → result replaced with deny error.
* :class:`PostToolUseBlocked` raised → identical shape.
* ``additional_context`` appended to tool message.
* generic Exception → fail-open (R6), original output preserved.
* :data:`PostToolUseFailureHook` fires on tool exec failure with
  ``duration_ms``; PostToolUse hooks do NOT fire on the failure path.
"""

from __future__ import annotations

import warnings
from typing import Any

import pytest

from persona.engine.agent_loop import (
    AgentLoop,
    LLMResponse,
    PermissionDenied,
    PostToolDeny,
    PostToolUseBlocked,
    PostToolUseDecision,
    ToolCall,
)


class _FakeTool:
    """Minimal Tool conforming to the :class:`Tool` protocol."""

    def __init__(self, name: str, result: Any) -> None:
        self.name = name
        self._result = result
        self.calls: list[dict[str, Any]] = []

    def schema(self) -> dict[str, Any]:
        return {
            "type": "function",
            "function": {"name": self.name, "parameters": {}},
        }

    async def execute(self, args: dict[str, Any]) -> Any:
        self.calls.append(args)
        return self._result


def _scripted_llm(replies: list[LLMResponse]):
    """Build an ``llm_call`` that returns ``replies`` in order."""
    idx = {"i": 0}

    async def _call(
        messages: list[dict[str, Any]],
        schemas: list[dict[str, Any]],
    ) -> LLMResponse:
        # Sanity: the loop must hand us the schema list on every turn.
        assert isinstance(schemas, list)
        i = idx["i"]
        idx["i"] = i + 1
        if i >= len(replies):
            pytest.fail(
                f"llm called {i + 1} times but only {len(replies)} "
                "scripted replies available",
            )
        return replies[i]

    return _call


@pytest.mark.asyncio
async def test_no_tools_single_shot() -> None:
    """Empty tools → first reply's text becomes the final answer."""
    llm = _scripted_llm([LLMResponse(content="hello world")])
    loop = AgentLoop(llm_call=llm, tools={})

    state = await loop.run(
        [{"role": "user", "content": "hi"}],
    )

    assert state.done is True
    assert state.stop_reason == "completed"
    assert state.iterations == 1
    assert state.final_text == "hello world"
    # One user message + one assistant message — no tool messages.
    assert [m["role"] for m in state.messages] == ["user", "assistant"]


@pytest.mark.asyncio
async def test_multi_round_tool_use() -> None:
    """LLM calls a tool once, then emits the final answer."""
    tool = _FakeTool(name="get_weather", result={"temp": 22})
    llm = _scripted_llm([
        LLMResponse(
            content="",
            tool_calls=[
                ToolCall(id="c1", name="get_weather", args={"city": "Taipei"}),
            ],
        ),
        LLMResponse(content="It's 22 degrees."),
    ])
    loop = AgentLoop(llm_call=llm, tools={"get_weather": tool})

    state = await loop.run(
        [{"role": "user", "content": "weather?"}],
    )

    assert state.done is True
    assert state.iterations == 2
    assert state.final_text == "It's 22 degrees."
    assert tool.calls == [{"city": "Taipei"}]
    roles = [m["role"] for m in state.messages]
    assert roles == ["user", "assistant", "tool", "assistant"]
    # Tool message round-trips the id for LLM correlation.
    tool_msg = state.messages[2]
    assert tool_msg["tool_call_id"] == "c1"
    assert tool_msg["is_error"] is False


@pytest.mark.asyncio
async def test_pre_hook_denies_then_recovers() -> None:
    """A Pre-hook denial is surfaced as an is_error tool message, not a crash."""
    tool = _FakeTool(name="run_bash", result="should never run")
    seen_denials: list[str] = []

    async def deny_dangerous(name: str, args: dict[str, Any]) -> None:
        if args.get("cmd", "").startswith("rm -rf"):
            seen_denials.append(args["cmd"])
            raise PermissionDenied("rm -rf not allowed")

    llm = _scripted_llm([
        LLMResponse(
            content="",
            tool_calls=[
                ToolCall(id="c1", name="run_bash", args={"cmd": "rm -rf /"}),
            ],
        ),
        LLMResponse(content="I won't do that."),
    ])
    loop = AgentLoop(
        llm_call=llm,
        tools={"run_bash": tool},
        pre_hooks=[deny_dangerous],
    )

    state = await loop.run(
        [{"role": "user", "content": "delete everything"}],
    )

    assert state.done is True
    assert state.final_text == "I won't do that."
    # Hook fired and tool never executed.
    assert seen_denials == ["rm -rf /"]
    assert tool.calls == []
    # Tool message records the denial with is_error=True.
    tool_msg = next(m for m in state.messages if m["role"] == "tool")
    assert tool_msg["is_error"] is True
    assert "permission denied" in tool_msg["content"]


# ─── Sancio 2.0.0 PostToolUse contract (Option C reframe) ──────────


def _one_tool_call_then_done(
    tool_name: str = "echo",
    args: dict[str, Any] | None = None,
) -> list[LLMResponse]:
    """Standard scripted LLM: one tool call, then a final-text reply.

    Used by every Sancio 2.0 PostToolUse test below — the loop's
    state-machine contract is already covered by the original three
    tests, so the new tests focus on the post-hook chain semantics.
    """
    return [
        LLMResponse(
            content="",
            tool_calls=[ToolCall(id="tc1", name=tool_name, args=args or {})],
        ),
        LLMResponse(content="done"),
    ]


@pytest.mark.asyncio
async def test_post_hook_returning_none_leaves_output_unchanged() -> None:
    """1.x compat path: ``None`` return → original output preserved."""
    tool = _FakeTool(name="echo", result="ORIGINAL")

    async def legacy_hook(
        name: str, args: dict[str, Any], result: Any,
    ) -> None:
        # Legacy 1.x signature: returns nothing. Loop must accept and
        # leave the tool result untouched.
        return None

    loop = AgentLoop(
        llm_call=_scripted_llm(_one_tool_call_then_done()),
        tools={"echo": tool},
        post_hooks=[legacy_hook],
    )
    # Suppress one-shot DeprecationWarning emitted for legacy hooks.
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", DeprecationWarning)
        state = await loop.run([{"role": "user", "content": "hi"}])

    tool_msg = next(m for m in state.messages if m["role"] == "tool")
    assert tool_msg["content"] == "ORIGINAL"
    assert tool_msg["is_error"] is False


@pytest.mark.asyncio
async def test_post_hook_updated_output_replaces_result() -> None:
    """``PostToolUseDecision(updated_output=X)`` → tool message content is X."""
    tool = _FakeTool(name="echo", result="ORIGINAL")

    async def rewrite_hook(
        name: str, args: dict[str, Any], result: Any,
    ) -> PostToolUseDecision | None:
        return PostToolUseDecision(updated_output="REWRITTEN")

    loop = AgentLoop(
        llm_call=_scripted_llm(_one_tool_call_then_done()),
        tools={"echo": tool},
        post_hooks=[rewrite_hook],
    )
    state = await loop.run([{"role": "user", "content": "hi"}])

    tool_msg = next(m for m in state.messages if m["role"] == "tool")
    assert tool_msg["content"] == "REWRITTEN"
    assert tool_msg["is_error"] is False


@pytest.mark.asyncio
async def test_post_hook_decision_block_marks_is_error() -> None:
    """``decision="block"`` → tool message ``is_error=True`` + ``blocked: …``."""
    tool = _FakeTool(name="echo", result="LEAKED_API_KEY")

    async def block_hook(
        name: str, args: dict[str, Any], result: Any,
    ) -> PostToolUseDecision | None:
        return PostToolUseDecision(
            decision="block", reason="contains api key",
        )

    loop = AgentLoop(
        llm_call=_scripted_llm(_one_tool_call_then_done()),
        tools={"echo": tool},
        post_hooks=[block_hook],
    )
    state = await loop.run([{"role": "user", "content": "hi"}])

    tool_msg = next(m for m in state.messages if m["role"] == "tool")
    assert tool_msg["is_error"] is True
    assert tool_msg["content"] == "blocked: contains api key"


@pytest.mark.asyncio
async def test_two_post_hooks_first_non_none_wins_chain() -> None:
    """Multi-hook chaining contract: first non-None updated_output wins.

    Subsequent hooks see the rewritten value as their ``result`` arg —
    documented in ``persona.hooks.post_decision.PostToolUseDecision``.
    """
    second_seen: dict[str, Any] = {}
    tool = _FakeTool(name="echo", result="ORIGINAL")

    async def first_hook(
        name: str, args: dict[str, Any], result: Any,
    ) -> PostToolUseDecision | None:
        return PostToolUseDecision(updated_output="WON")

    async def second_hook(
        name: str, args: dict[str, Any], result: Any,
    ) -> PostToolUseDecision | None:
        second_seen["result"] = result
        return None

    loop = AgentLoop(
        llm_call=_scripted_llm(_one_tool_call_then_done()),
        tools={"echo": tool},
        post_hooks=[first_hook, second_hook],
    )
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", DeprecationWarning)
        state = await loop.run([{"role": "user", "content": "hi"}])

    tool_msg = next(m for m in state.messages if m["role"] == "tool")
    assert tool_msg["content"] == "WON"
    # Crucial: hook chain mutated `result` so the second hook saw the
    # rewritten value, not the tool's original output.
    assert second_seen["result"] == "WON"


@pytest.mark.asyncio
async def test_post_hook_post_tool_deny_replaces_result() -> None:
    """``PostToolDeny`` raised → ``is_error=True`` + ``post-hook deny: …``.

    This is the Option C observation-channel deny path Cerno wires into.
    Side effects of the tool already happened (CC physics constraint per
    GitHub anthropics/claude-code#32105) — only the LLM-visible channel
    is denied.
    """
    tool = _FakeTool(name="echo", result="ORIGINAL")

    async def cerno_deny_hook(
        name: str, args: dict[str, Any], result: Any,
    ) -> PostToolUseDecision | None:
        raise PostToolDeny("cerno deny: drift_too_high")

    loop = AgentLoop(
        llm_call=_scripted_llm(_one_tool_call_then_done()),
        tools={"echo": tool},
        post_hooks=[cerno_deny_hook],
    )
    state = await loop.run([{"role": "user", "content": "hi"}])

    tool_msg = next(m for m in state.messages if m["role"] == "tool")
    assert tool_msg["is_error"] is True
    assert tool_msg["content"] == "post-hook deny: cerno deny: drift_too_high"


@pytest.mark.asyncio
async def test_post_hook_post_tool_use_blocked_raised_directly() -> None:
    """Direct-raise ``PostToolUseBlocked`` → same shape as decision="block"."""
    tool = _FakeTool(name="echo", result="ORIGINAL")

    async def blocked_hook(
        name: str, args: dict[str, Any], result: Any,
    ) -> PostToolUseDecision | None:
        raise PostToolUseBlocked("manual block")

    loop = AgentLoop(
        llm_call=_scripted_llm(_one_tool_call_then_done()),
        tools={"echo": tool},
        post_hooks=[blocked_hook],
    )
    state = await loop.run([{"role": "user", "content": "hi"}])

    tool_msg = next(m for m in state.messages if m["role"] == "tool")
    assert tool_msg["is_error"] is True
    assert tool_msg["content"] == "blocked: manual block"


@pytest.mark.asyncio
async def test_post_hook_additional_context_appended() -> None:
    """``additional_context`` is appended to the tool message content."""
    tool = _FakeTool(name="echo", result="ORIGINAL")

    async def context_hook(
        name: str, args: dict[str, Any], result: Any,
    ) -> PostToolUseDecision | None:
        return PostToolUseDecision(additional_context="\n[ctx: ok]")

    loop = AgentLoop(
        llm_call=_scripted_llm(_one_tool_call_then_done()),
        tools={"echo": tool},
        post_hooks=[context_hook],
    )
    state = await loop.run([{"role": "user", "content": "hi"}])

    tool_msg = next(m for m in state.messages if m["role"] == "tool")
    assert tool_msg["content"] == "ORIGINAL\n[ctx: ok]"
    assert tool_msg["is_error"] is False


@pytest.mark.asyncio
async def test_post_hook_generic_exception_fails_open() -> None:
    """Non-Sancio exceptions: fail-open per R6 — original output preserved."""
    tool = _FakeTool(name="echo", result="ORIGINAL")

    async def buggy_hook(
        name: str, args: dict[str, Any], result: Any,
    ) -> PostToolUseDecision | None:
        raise RuntimeError("oops, hook bug")

    loop = AgentLoop(
        llm_call=_scripted_llm(_one_tool_call_then_done()),
        tools={"echo": tool},
        post_hooks=[buggy_hook],
    )
    state = await loop.run([{"role": "user", "content": "hi"}])

    tool_msg = next(m for m in state.messages if m["role"] == "tool")
    assert tool_msg["content"] == "ORIGINAL"
    assert tool_msg["is_error"] is False


class _FailingTool:
    """Tool whose execute() raises — exercises the failure path."""

    def __init__(self, name: str, exc: Exception) -> None:
        self.name = name
        self._exc = exc

    def schema(self) -> dict[str, Any]:
        return {
            "type": "function",
            "function": {"name": self.name, "parameters": {}},
        }

    async def execute(self, args: dict[str, Any]) -> Any:
        raise self._exc


@pytest.mark.asyncio
async def test_post_failure_hook_fires_with_duration_ms() -> None:
    """``PostToolUseFailureHook`` fires when tool raises; duration_ms ≥ 0.

    CC SDK April 2026 ``PostToolUseFailure`` parity — the failure
    hook receives ``(name, args, exception, duration_ms)``.
    """
    seen: dict[str, Any] = {}
    tool = _FailingTool(name="bash", exc=RuntimeError("boom"))

    async def failure_hook(
        name: str,
        args: dict[str, Any],
        exc: Exception,
        duration_ms: float,
    ) -> None:
        seen["name"] = name
        seen["args"] = args
        seen["exc_type"] = type(exc).__name__
        seen["duration_ms"] = duration_ms

    loop = AgentLoop(
        llm_call=_scripted_llm(
            _one_tool_call_then_done(tool_name="bash", args={"cmd": "x"}),
        ),
        tools={"bash": tool},
        post_failure_hooks=[failure_hook],
    )
    await loop.run([{"role": "user", "content": "go"}])

    assert seen["name"] == "bash"
    assert seen["args"] == {"cmd": "x"}
    assert seen["exc_type"] == "RuntimeError"
    # perf_counter is monotonic non-negative; we don't assert tightness
    # because Windows perf_counter resolution can read 0.0 on fast paths.
    assert isinstance(seen["duration_ms"], float)
    assert seen["duration_ms"] >= 0.0


@pytest.mark.asyncio
async def test_post_failure_hook_separate_from_post_hook() -> None:
    """On failure: PostToolUseFailureHook fires, PostToolUseHook does NOT.

    Mirrors CC SDK semantics — ``PostToolUse`` only fires on success,
    ``PostToolUseFailure`` only fires on failure. This avoids hooks
    that try to rewrite a tool result that does not exist.
    """
    failure_calls: list[str] = []
    post_calls: list[str] = []
    tool = _FailingTool(name="bash", exc=ValueError("kaboom"))

    async def post_hook(
        name: str, args: dict[str, Any], result: Any,
    ) -> PostToolUseDecision | None:
        post_calls.append(name)
        return None

    async def failure_hook(
        name: str,
        args: dict[str, Any],
        exc: Exception,
        duration_ms: float,
    ) -> None:
        failure_calls.append(name)

    loop = AgentLoop(
        llm_call=_scripted_llm(_one_tool_call_then_done(tool_name="bash")),
        tools={"bash": tool},
        post_hooks=[post_hook],
        post_failure_hooks=[failure_hook],
    )
    state = await loop.run([{"role": "user", "content": "go"}])

    assert failure_calls == ["bash"]
    assert post_calls == []
    # Tool message still records the failure as an is_error=True entry.
    tool_msg = next(m for m in state.messages if m["role"] == "tool")
    assert tool_msg["is_error"] is True
    assert "tool error: kaboom" in tool_msg["content"]


@pytest.mark.asyncio
async def test_legacy_post_hook_emits_deprecation_warning_once() -> None:
    """Compat shim: legacy ``Awaitable[None]`` hook still works + warns once."""
    tool = _FakeTool(name="echo", result="ORIGINAL")

    async def legacy_hook(
        name: str, args: dict[str, Any], result: Any,
    ) -> None:
        return None

    # Two tool calls in a row should still only warn once for the same
    # hook callable (WeakSet de-dup).
    loop = AgentLoop(
        llm_call=_scripted_llm([
            LLMResponse(
                content="",
                tool_calls=[ToolCall(id="tc1", name="echo")],
            ),
            LLMResponse(
                content="",
                tool_calls=[ToolCall(id="tc2", name="echo")],
            ),
            LLMResponse(content="done"),
        ]),
        tools={"echo": tool},
        post_hooks=[legacy_hook],
    )

    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter("always", DeprecationWarning)
        state = await loop.run([{"role": "user", "content": "hi"}])

    # Hook ran twice, but DeprecationWarning fires once via WeakSet
    # de-dup. Filter to only our category — pytest may emit unrelated
    # warnings on the same loop run.
    sancio_warnings = [
        w for w in caught
        if issubclass(w.category, DeprecationWarning)
        and "PostToolUseHook returned None" in str(w.message)
    ]
    assert len(sancio_warnings) == 1
    # Both tool messages still made it through, original content preserved.
    tool_msgs = [m for m in state.messages if m["role"] == "tool"]
    assert len(tool_msgs) == 2
    assert all(m["content"] == "ORIGINAL" for m in tool_msgs)
