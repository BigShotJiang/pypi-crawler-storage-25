"""Tests for permission gate — ``permission_ask`` SSE + ``POST /v1/agent/permission``.

Coverage:
  1. permission_ask event emitted when policy says "ask"
  2. POST /v1/agent/permission with allow_once resumes the loop
  3. Timeout (no POST) → default deny → error SSE event
  4. POST /v1/agent/permission with deny → PermissionDenied error
  5. POST with invalid/missing request_id → 400/404
"""

from __future__ import annotations

import json
import threading
import time
from collections.abc import Iterator
from typing import Any

import pytest
from starlette.testclient import TestClient

from persona import agent_api
from persona.api import create_standalone_app
from persona.engine.agent_loop import LLMResponse, ToolCall
from persona.policy.dsl import Policy, Rule


# ── Fixtures ─────────────────────────────────────


@pytest.fixture(autouse=True)
def _short_permission_timeout(monkeypatch: pytest.MonkeyPatch) -> None:
    """Use a 1s permission timeout so tests don't block."""
    monkeypatch.setattr(agent_api, "_PERMISSION_TIMEOUT_S", 1.0)


@pytest.fixture()
def client() -> Iterator[TestClient]:
    """Fresh Aegis app per test — isolates module-level state.

    Snapshots ``_build_loop`` on entry and restores on teardown so
    ``_install_ask_policy`` (which monkey-patches the module-level
    builder) cannot leak across test boundaries. Without this,
    cross-file tests that run later (e.g.
    ``test_agent_run_endpoint::test_tool_call_and_tool_result_events``)
    inherit the ask-policy hook and fail with ``permission_ask``
    events instead of ``tool_call``.
    """
    original_build_loop = agent_api._build_loop
    app = create_standalone_app()
    with TestClient(app) as c:
        yield c
    agent_api.reset_llm_call()
    agent_api._build_loop = original_build_loop  # type: ignore[assignment]


def _install_scripted_llm(replies: list[LLMResponse]) -> None:
    idx = {"i": 0}

    async def _call(
        messages: list[dict[str, Any]],
        schemas: list[dict[str, Any]],
    ) -> LLMResponse:
        i = idx["i"]
        idx["i"] = i + 1
        if i >= len(replies):
            raise AssertionError(
                f"llm called {i + 1}x but only {len(replies)} replies",
            )
        return replies[i]

    agent_api.set_llm_call(_call)


def _parse_sse(body: str) -> list[tuple[str, str]]:
    events: list[tuple[str, str]] = []
    for block in body.strip().split("\n\n"):
        event = ""
        data_parts: list[str] = []
        for line in block.splitlines():
            if line.startswith("event:"):
                event = line.split(":", 1)[1].strip()
            elif line.startswith("data:"):
                data_parts.append(line.split(":", 1)[1].strip())
        if data_parts:
            events.append((event or "message", "\n".join(data_parts)))
    return events


def _install_ask_policy() -> None:
    """Override the default policy to ask on list_files."""
    from persona.policy.hook import make_policy_pre_hook

    ask_policy = Policy(
        rules=[
            Rule(
                tool="list_files",
                decision="ask",
                reason="testing permission ask",
            ),
        ],
        default_decision="allow",
    )
    hook = make_policy_pre_hook(ask_policy)

    # Replace the module-level loop builder to inject our policy.
    original_build = agent_api._build_loop

    def _patched_build(
        stack: str,
        max_iterations: int,
        tenant_id: str,
        cerno_config: dict[str, Any] | None = None,
    ) -> Any:
        loop = original_build(
            stack, max_iterations, tenant_id, cerno_config=cerno_config,
        )
        # Prepend our ask-policy hook.
        loop.pre_hooks.insert(0, hook)
        return loop

    agent_api._build_loop = _patched_build  # type: ignore[assignment]


# ── Tests ────────────────────────────────────────


def test_permission_ask_emitted_on_ask_policy(
    client: TestClient,
) -> None:
    """Policy ``ask`` → SSE emits ``permission_ask`` event."""
    _install_ask_policy()
    _install_scripted_llm([
        LLMResponse(
            content="",
            tool_calls=[
                ToolCall(id="tc1", name="list_files", args={"path": "."}),
            ],
        ),
        LLMResponse(content="done"),
    ])

    resp = client.post(
        "/v1/agent/run",
        json={
            "stack": "ccc",
            "model": "m",
            "messages": [{"role": "user", "content": "list"}],
            "max_iterations": 5,
        },
    )
    assert resp.status_code == 200
    events = _parse_sse(resp.text)
    kinds = [ev for ev, _ in events]
    assert "permission_ask" in kinds, f"expected permission_ask in {kinds}"

    # Verify the permission_ask payload has required fields.
    for ev_name, ev_data in events:
        if ev_name == "permission_ask":
            payload = json.loads(ev_data)
            assert payload["tool"] == "list_files"
            assert "request_id" in payload
            assert "args" in payload
            break


def test_permission_timeout_results_in_deny(
    client: TestClient,
) -> None:
    """No POST response within timeout → tool denied."""
    _install_ask_policy()
    _install_scripted_llm([
        LLMResponse(
            content="",
            tool_calls=[
                ToolCall(id="tc1", name="list_files", args={"path": "."}),
            ],
        ),
        LLMResponse(content="fallback"),
    ])

    resp = client.post(
        "/v1/agent/run",
        json={
            "stack": "ccc",
            "model": "m",
            "messages": [{"role": "user", "content": "list"}],
            "max_iterations": 5,
        },
    )
    assert resp.status_code == 200
    events = _parse_sse(resp.text)
    kinds = [ev for ev, _ in events]
    # Should have permission_ask followed by tool_result with deny.
    assert "permission_ask" in kinds


def test_permission_allow_resumes_loop(
    client: TestClient,
) -> None:
    """POST allow_once before timeout → tool executes normally."""
    _install_ask_policy()
    _install_scripted_llm([
        LLMResponse(
            content="",
            tool_calls=[
                ToolCall(id="tc1", name="list_files", args={"path": "."}),
            ],
        ),
        LLMResponse(content="listed-ok"),
    ])

    def _respond_allow() -> None:
        """Watch for pending permission and POST allow_once."""
        for _ in range(50):  # poll for up to 5s
            time.sleep(0.1)
            waiters = dict(agent_api._permission_waiters)
            if waiters:
                perm_id = next(iter(waiters))
                client.post(
                    "/v1/agent/permission",
                    json={
                        "request_id": perm_id,
                        "decision": "allow_once",
                    },
                )
                return

    t = threading.Thread(target=_respond_allow, daemon=True)
    t.start()

    resp = client.post(
        "/v1/agent/run",
        json={
            "stack": "ccc",
            "model": "m",
            "messages": [{"role": "user", "content": "list"}],
            "max_iterations": 5,
        },
    )
    t.join(timeout=10)

    assert resp.status_code == 200
    events = _parse_sse(resp.text)
    kinds = [ev for ev, _ in events]
    assert "permission_ask" in kinds
    # The loop should complete with tool_result + done.
    assert "done" in kinds
    # Verify final text came through.
    for ev_name, ev_data in events:
        if ev_name == "token":
            payload = json.loads(ev_data)
            assert payload["text"] == "listed-ok"
            break


def test_permission_deny_via_post(
    client: TestClient,
) -> None:
    """POST deny → tool gets PermissionDenied, loop continues."""
    _install_ask_policy()
    _install_scripted_llm([
        LLMResponse(
            content="",
            tool_calls=[
                ToolCall(id="tc1", name="list_files", args={"path": "."}),
            ],
        ),
        LLMResponse(content="denied-fallback"),
    ])

    def _respond_deny() -> None:
        for _ in range(50):
            time.sleep(0.1)
            waiters = dict(agent_api._permission_waiters)
            if waiters:
                perm_id = next(iter(waiters))
                client.post(
                    "/v1/agent/permission",
                    json={
                        "request_id": perm_id,
                        "decision": "deny",
                    },
                )
                return

    t = threading.Thread(target=_respond_deny, daemon=True)
    t.start()

    resp = client.post(
        "/v1/agent/run",
        json={
            "stack": "ccc",
            "model": "m",
            "messages": [{"role": "user", "content": "list"}],
            "max_iterations": 5,
        },
    )
    t.join(timeout=10)

    assert resp.status_code == 200
    events = _parse_sse(resp.text)
    kinds = [ev for ev, _ in events]
    assert "permission_ask" in kinds
    assert "done" in kinds


def test_permission_endpoint_invalid_request_id(
    client: TestClient,
) -> None:
    """POST with unknown request_id → 404."""
    resp = client.post(
        "/v1/agent/permission",
        json={"request_id": "nonexistent", "decision": "allow_once"},
    )
    assert resp.status_code == 404
    assert resp.json()["error"] == "not_found"


def test_permission_endpoint_missing_fields(
    client: TestClient,
) -> None:
    """POST without request_id → 400."""
    resp = client.post(
        "/v1/agent/permission",
        json={"decision": "allow_once"},
    )
    assert resp.status_code == 400
    assert resp.json()["error"] == "invalid_field"


def test_permission_endpoint_invalid_decision(
    client: TestClient,
) -> None:
    """POST with invalid decision value → 400."""
    resp = client.post(
        "/v1/agent/permission",
        json={"request_id": "fake", "decision": "yolo"},
    )
    assert resp.status_code == 400
    assert resp.json()["error"] == "invalid_field"
