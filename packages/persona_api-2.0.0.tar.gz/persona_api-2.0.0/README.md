# persona-api (Sancio)

Digital Persona API — private deployment for VPS.

Sancio is the runtime that serves the Claude-powered digital
persona behind `munio.ai-king.dev`. It wraps Anthropic's Claude
API with:

* Bearer auth (JWT HS256) on every RCE-capable endpoint.
* Per-user daily + monthly USD budget caps (`persona.budget`).
* Tenant workspace sandbox for tool calls.
* GDPR Art 15/17 data-subject endpoints (`/v1/gdpr/*`).
* U.S. EAR geo-block middleware (returns HTTP 451 for embargoed
  regions).
* A2A (agent-to-agent) protocol for peer invocations.

See `CHANGELOG.md` for the version history.

## Export Control Notice

This software dispatches requests to the Anthropic Claude API,
which is subject to U.S. Export Administration Regulations (EAR)
and OFAC sanctions. Users are responsible for compliance with
applicable export control laws. **This software is not for use
in embargoed or sanctioned jurisdictions**, including but not
limited to Cuba, Iran, North Korea, Syria, and mainland China.
The default `GeoBlockMiddleware` blocks requests from these
regions at the ASGI layer; operators are expected to add a
matching Cloudflare WAF firewall rule as the primary gate. See
`docs/export-control.md` for the runbook.

## Privacy

Sancio is designed to comply with GDPR as a data controller
for EU users under Art 3(2) territorial scope. The machine-
readable privacy policy is served at `GET /v1/privacy`; the
Record of Processing Activities lives at `docs/ropa.md`.

Data-subject rights:

* Art 15 access — `POST /v1/gdpr/export`
* Art 17 erasure — `POST /v1/gdpr/delete`

Contact: `privacy@ai-king.dev`.

## Deploy

VPS `5.104.83.69` is the single source of truth. No local Docker.
See `RELEASE_COORDINATION.md` for the upgrade protocol.

## License

**persona-api (Sancio) is dual-licensed** under:

1. **GNU Affero General Public License v3.0 or later (AGPL-3.0-or-later)** —
   the default. Use, modify, and redistribute freely, including over
   a network, **provided** you comply with §13 (network-use disclosure
   of complete corresponding source). See [LICENSE](LICENSE).
2. **Commercial License** — for organizations that cannot or will
   not comply with AGPL §13 (most commercial SaaS deployments) or
   whose internal policy bans AGPL-licensed dependencies. See
   [COMMERCIAL_LICENSE.md](COMMERCIAL_LICENSE.md) for tiers,
   pricing, and contact.

**Differentiation note.** persona-api hosts the **Cerno 7-step
maternal-agent cycle** that does not exist in upstream Concinno —
sense → orient → guard-budget → think → act → verify → consolidate.
The Cerno cycle is a separate trade-secret-protected derivative
work; commercial licensees of persona-api also receive the right
to deploy the Cerno cycle in production. See COMMERCIAL_LICENSE.md
§ "What's Included" for the full delta.

**L6 PostToolUse — observation-channel deny + Pre-hook escalation.**
Sancio 2.0.0 closes the CC SDK April 2026 surface gap (`updatedToolOutput`
+ `ConfigChange`) and reframes the long-standing "L6 hard deny"
promise. CC's L6 ceiling — "PostToolUse cannot block tool execution"
— is a **physics constraint**, not an implementation choice
(see [anthropics/claude-code#32105](https://github.com/anthropics/claude-code/issues/32105)).
Once `tool.execute()` returns, side effects exist; no runtime can
magic-undo them. What Sancio uniquely owns is **observation-channel
deny + Pre-hook escalation**: a post-hook can replace the LLM-visible
tool result with `is_error=True` (CC's `updatedToolOutput` rewrites
silently — no error flag) AND mutate the pre-hook policy state so
iteration N+1 hits a real PreToolUse hard-deny on the next attempt.
Both mechanisms compose with the new `ConfigChangeEvent` watcher for
live-reload of policy DSL. See
`docs/migration-1.3-to-2.0.md` for the migration guide and
`_AI_BRAIN/05_Planning/2026-05-01-l6-posttooluse-design-conflict-options.md`
for the Option C verdict.

**Trademarks.** "Sancio", "Cerno", "Concinno", "ZIQ", "FieldRead",
"PSYCHE", and "TACB" are trademarks of Chen Syuan Wang (王晨宣 /
AI King). AGPL grant does not include trademark rights.

**Sole copyright.** All persona-api / Sancio / Cerno copyright is
held by Chen Syuan Wang as sole author. For acquisition or
strategic partnership discussions: <me@ai-king.dev>.
