"""Persona API standalone server — runs on VPS behind Caddy.

Usage:
  uv run python src/server.py --host 127.0.0.1 --port 8500
"""

from __future__ import annotations

import argparse
import os

import uvicorn

from persona.api import create_standalone_app


def main() -> None:
    """Launch persona API server."""
    parser = argparse.ArgumentParser(
        description="Digital Persona API server",
    )
    parser.add_argument(
        "--host", default="127.0.0.1",
    )
    parser.add_argument(
        "--port", type=int, default=8500,
    )
    args = parser.parse_args()

    app = create_standalone_app()

    # Pre-load personas from PERSONA_DIR or bundled personas/
    from pathlib import Path

    from persona.api import _profiles
    from persona.loader import load_persona_md

    persona_dir = os.environ.get(
        "PERSONA_DIR",
        str(Path(__file__).parent.parent / "personas"),
    )
    persona_path = Path(persona_dir)
    if persona_path.exists():
        for md in persona_path.glob("*/persona.md"):
            pid = md.parent.name
            _profiles.set(pid, load_persona_md(md))
            print(f"Loaded persona: {pid}")

    # Set "purple" as default if available
    purple = _profiles.get("purple")
    if purple is not None and _profiles.get("default") is None:
        _profiles.set("default", purple)
        print("Default persona: purple")

    uvicorn.run(app, host=args.host, port=args.port)


if __name__ == "__main__":
    main()
