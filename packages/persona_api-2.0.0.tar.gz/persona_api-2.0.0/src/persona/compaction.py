"""persona.compaction — Auto-compaction for chat conversation context.

Sancio M1 Week 2 (1.2.0) deliverable. Triggers when message-token usage
crosses a configurable threshold (default 80%) and rewrites the
conversation in place: critical turns are preserved verbatim, the
older bulk gets compressed into a single summary block.

Borrowed structure (cleanroom port, no source copied):
  * Concinno's ``cleanup.py`` — its CleanupResult dataclass shape and
    "detect → act → report" split inspired :class:`CompactionResult`
    + the :func:`compact_messages` orchestrator.
  * Claude Code's auto-compact behaviour (described in
    ``~/.claude/skills/kb_cc_source/``) inspired the preservation
    rules: "keep last N user turns, keep all open tool_use blocks,
    summarize the rest". We intentionally do *not* depend on any CC
    private API — the implementation is self-contained.

@module persona.compaction
@responsibility Decide when to compact, choose what to keep, drive the
    LLM-based summarizer (Haiku-class), and return the rewritten
    message list. Pure-Python core with a pluggable summarizer
    callback so unit tests can exercise the logic without an LLM.
@dependencies stdlib only at the core. Optional: an LLM driver
    matching :class:`SummarizerCallable` for production summarization.
@exports CompactionConfig, CompactionResult, MessageLike,
    estimate_tokens, count_message_tokens, should_compact,
    select_preserved, summarize_dropped, compact_messages,
    AutoCompactor, deterministic_summarizer

License: AGPL-3.0-or-later (matches persona-api). Borrows freely
from concinno (also AGPL).
"""

from __future__ import annotations

import logging
import re
import threading
from collections.abc import Iterable, Sequence
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Literal, Protocol, runtime_checkable

logger = logging.getLogger("persona.compaction")


# ─────────────────────────────────────────────────────────────────
# Token estimation
# ─────────────────────────────────────────────────────────────────

# Anthropic's public guidance: ~4 chars/token for English, ~2 chars/token
# for CJK. The chat REPL is multilingual (繁中 + en mixed), so we pick a
# blended average. This is intentionally pessimistic — over-counting by
# ~10% is much safer than under-counting and missing the threshold.
_BLENDED_CHARS_PER_TOKEN = 3.5

_CJK_RE = re.compile(r"[　-鿿가-힯]")


def estimate_tokens(text: str) -> int:
    """Estimate token count from raw text.

    Uses a blended chars-per-token ratio that handles ASCII + CJK
    reasonably without pulling in tokenizer dependencies. The error
    bound vs ``tiktoken`` for typical chat traffic is < 15% — good
    enough for threshold decisions where we have a 5-10pp safety
    margin baked into the default config.

    Args:
        text: Raw user / assistant text. Pre-formatted JSON tool blocks
            should be passed as their string-serialized form.

    Returns:
        Estimated token count. Always ``>= 1`` for non-empty input
        so a one-char message never registers as zero.
    """
    if not text:
        return 0
    cjk_chars = len(_CJK_RE.findall(text))
    other_chars = len(text) - cjk_chars
    # CJK weights ~2 chars/token; other text weights via the blended
    # constant. Weighted sum + ceiling.
    raw = (cjk_chars / 2.0) + (other_chars / _BLENDED_CHARS_PER_TOKEN)
    return max(1, int(raw + 0.999))


# A "message" here is the Anthropic-style dict the chat REPL maintains:
# ``{"role": "user"|"assistant"|"system", "content": str | list[block]}``.
# We keep the type loose (dict[str, Any]) to mirror the REPL's existing
# shape rather than forcing a Pydantic model on it.
MessageLike = dict[str, Any]


def _stringify_tool_result_body(body: Any) -> str:
    """Render a ``tool_result.content`` payload as a single string."""
    if not isinstance(body, list):
        return str(body)
    pieces: list[str] = []
    for b in body:
        if isinstance(b, dict):
            pieces.append(str(b.get("text", "")))
        else:
            pieces.append(str(b))
    return " ".join(pieces)


def _stringify_block(block: Any) -> str:
    """Render one Anthropic-style content block to a string."""
    if not isinstance(block, dict):
        return str(block)
    kind = block.get("type", "")
    if kind == "text":
        return str(block.get("text", ""))
    if kind == "tool_use":
        return (
            f"[tool_use {block.get('name', '?')} "
            f"input={block.get('input', {})}]"
        )
    if kind == "tool_result":
        body = _stringify_tool_result_body(block.get("content", ""))
        return f"[tool_result {body}]"
    return str(block)


def _stringify_content(content: Any) -> str:
    """Best-effort serialize a message ``content`` field to a string.

    Handles three shapes the REPL produces:
      * ``str`` — passthrough.
      * ``list[block]`` — concatenate ``block["text"]`` /
        ``block["content"]`` / a stringified fallback per block.
      * Anything else — ``repr()``.

    The result is fed to :func:`estimate_tokens`, so absolute fidelity
    isn't required; we just need stable size signals.
    """
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        return "\n".join(_stringify_block(b) for b in content)
    return repr(content)


def count_message_tokens(message: MessageLike) -> int:
    """Count tokens in a single message (role + content)."""
    role = str(message.get("role", ""))
    content_str = _stringify_content(message.get("content", ""))
    # Add a small overhead per message to account for role markers and
    # JSON envelope bytes Anthropic adds on the wire.
    return estimate_tokens(role) + estimate_tokens(content_str) + 4


def count_messages_tokens(messages: Iterable[MessageLike]) -> int:
    """Count total tokens across every message in the conversation."""
    return sum(count_message_tokens(m) for m in messages)


# ─────────────────────────────────────────────────────────────────
# Threshold decision
# ─────────────────────────────────────────────────────────────────


@dataclass(frozen=True)
class CompactionConfig:
    """Tunable parameters for the auto-compactor.

    All fields are read at compactor construction time; mutate by
    rebuilding the dataclass (frozen for thread-safety).

    Attributes:
        context_window: Maximum tokens the model accepts for one
            request. Defaults to 200k (Sonnet 4 / Opus 4 baseline).
            Override per-driver via :class:`AutoCompactor` ctor.
        threshold_pct: Trigger compaction when usage crosses this
            fraction of ``context_window``. Default 0.80 (80%) per the
            Week 2 plan.
        preserve_last_user_turns: Keep the last N user/assistant pairs
            verbatim. Default 3.
        preserve_open_tool_use: When True (default), any ``tool_use``
            block that hasn't seen its matching ``tool_result`` yet is
            kept verbatim regardless of age — the LLM cannot resume a
            broken tool round-trip without it.
        target_post_compact_pct: After compaction, aim for this much
            of the window so the user has headroom for the next turn.
            Default 0.40 (40%).
        summary_max_tokens: Hard cap on the summary block. Prevents an
            LLM-side summarizer from regenerating the bulk it was
            asked to compress. Default 2000.
        min_messages_to_compact: Don't bother compacting fewer than N
            messages — the overhead isn't worth it. Default 6.
    """

    context_window: int = 200_000
    threshold_pct: float = 0.80
    preserve_last_user_turns: int = 3
    preserve_open_tool_use: bool = True
    target_post_compact_pct: float = 0.40
    summary_max_tokens: int = 2000
    min_messages_to_compact: int = 6

    def threshold_tokens(self) -> int:
        """Trigger token threshold (e.g. 160k for default 80% × 200k)."""
        return int(self.context_window * self.threshold_pct)

    def target_tokens(self) -> int:
        """Post-compaction target token budget."""
        return int(self.context_window * self.target_post_compact_pct)


def should_compact(
    messages: Sequence[MessageLike],
    config: CompactionConfig,
) -> tuple[bool, int]:
    """Return ``(trigger, current_tokens)``.

    ``trigger`` is True when ``current_tokens >= threshold_tokens()``
    *and* the message count is above the floor in
    :attr:`CompactionConfig.min_messages_to_compact`. The token count
    is also returned so callers (e.g. ``/status``) can show the
    headroom without recomputing.
    """
    current = count_messages_tokens(messages)
    if len(messages) < config.min_messages_to_compact:
        return False, current
    return current >= config.threshold_tokens(), current


# ─────────────────────────────────────────────────────────────────
# Preservation selection
# ─────────────────────────────────────────────────────────────────


def _is_open_tool_use(message: MessageLike) -> set[str]:
    """Return the set of tool_use_ids in *message* (assistant turn)."""
    content = message.get("content")
    if not isinstance(content, list):
        return set()
    out: set[str] = set()
    for block in content:
        if isinstance(block, dict) and block.get("type") == "tool_use":
            tid = block.get("id")
            if isinstance(tid, str):
                out.add(tid)
    return out


def _resolved_tool_ids(message: MessageLike) -> set[str]:
    """Return the set of tool_use_ids resolved by *message* (user turn)."""
    content = message.get("content")
    if not isinstance(content, list):
        return set()
    out: set[str] = set()
    for block in content:
        if isinstance(block, dict) and block.get("type") == "tool_result":
            tid = block.get("tool_use_id")
            if isinstance(tid, str):
                out.add(tid)
    return out


def _find_open_tool_pairs(messages: Sequence[MessageLike]) -> set[int]:
    """Indices of messages involved in unresolved tool_use round-trips.

    A tool_use is "open" when the assistant emitted it but the matching
    tool_result hasn't been appended yet — dropping either side breaks
    the next driver call.

    We scan back-to-front, collecting ids that appear in ``tool_use``
    blocks and removing them when the matching ``tool_result`` is
    seen. Any leftover ids → indices of the assistant message hosting
    them stay in the keep-set.
    """
    pending: dict[str, int] = {}
    keep_idx: set[int] = set()
    for i, msg in enumerate(messages):
        if msg.get("role") == "assistant":
            for tid in _is_open_tool_use(msg):
                pending[tid] = i
        elif msg.get("role") == "user":
            for tid in _resolved_tool_ids(msg):
                # Resolved → pair complete; drop bookkeeping but mark
                # both sides as "keep together" so the assistant's
                # context block survives if the result does.
                if tid in pending:
                    pending.pop(tid, None)
    # Whatever stays in `pending` is unresolved at end of conversation;
    # keep the assistant indices.
    keep_idx.update(pending.values())
    return keep_idx


def select_preserved(
    messages: Sequence[MessageLike],
    config: CompactionConfig,
) -> tuple[list[int], list[int]]:
    """Split message indices into ``(preserved, drop_candidates)``.

    Preservation rules (in priority order):
      1. The system / leading prompt at index 0 if present and role is
         ``system`` — drivers often expect it to stay first.
      2. Last ``preserve_last_user_turns`` user-assistant pairs.
      3. Open tool_use round-trips (``preserve_open_tool_use``).

    Anything else becomes a drop candidate. The two returned lists are
    disjoint; their union is the full ``range(len(messages))``.
    """
    n = len(messages)
    if n == 0:
        return [], []

    keep: set[int] = set()

    # 1. System prompt anchor.
    if messages[0].get("role") == "system":
        keep.add(0)

    # 2. Last N user turns (and the assistant turn that follows each,
    #    plus any tool round-trip the assistant kicked off).
    user_turn_indices = [i for i, m in enumerate(messages) if m.get("role") == "user"]
    last_users = user_turn_indices[-config.preserve_last_user_turns:]
    if last_users:
        # Keep everything from the earliest-of-the-last-N user turn
        # through the end of the conversation. This naturally captures
        # the assistant replies + any tool_result blocks interleaved.
        anchor = last_users[0]
        keep.update(range(anchor, n))

    # 3. Open tool_use rescue.
    if config.preserve_open_tool_use:
        keep.update(_find_open_tool_pairs(messages))

    preserved = sorted(keep)
    drop_candidates = [i for i in range(n) if i not in keep]
    return preserved, drop_candidates


# ─────────────────────────────────────────────────────────────────
# Summarization
# ─────────────────────────────────────────────────────────────────


@runtime_checkable
class SummarizerCallable(Protocol):
    """Protocol for a summarizer.

    A summarizer takes the dropped-bulk messages plus a max-token
    budget and returns a single string (not a message dict — the
    caller wraps it). Production wires this to a Haiku-class driver;
    tests inject :func:`deterministic_summarizer`.
    """

    def __call__(
        self,
        dropped: Sequence[MessageLike],
        max_tokens: int,
    ) -> str: ...


def deterministic_summarizer(
    dropped: Sequence[MessageLike],
    max_tokens: int,
) -> str:
    """Pure-Python fallback summarizer — no LLM required.

    Concatenates the first sentence of each dropped message into a
    bulleted list. Truncates to fit ``max_tokens`` (estimated). Used
    by tests + as the production fallback when the configured LLM
    summarizer raises.

    The output is intentionally machine-recognizable so a downstream
    driver knows it's looking at a compaction marker:

        [compaction-summary 12 messages, 4231 tokens dropped]
        - user: how do I install …
        - assistant: pip install persona-api …
        - user: it failed with permission …
        …
    """
    if not dropped:
        return "[compaction-summary 0 messages dropped]"

    total_dropped_tokens = count_messages_tokens(dropped)
    header = (
        f"[compaction-summary {len(dropped)} messages, "
        f"{total_dropped_tokens} tokens dropped]"
    )
    lines = [header]

    for msg in dropped:
        role = msg.get("role", "?")
        content_str = _stringify_content(msg.get("content", ""))
        # First sentence (or ~80 chars).
        match = re.search(r"[.!?。！？\n]", content_str)
        if match and match.start() < 200:
            snippet = content_str[: match.start() + 1].strip()
        else:
            snippet = content_str[:120].strip()
            if len(content_str) > 120:
                snippet += "…"
        if snippet:
            lines.append(f"- {role}: {snippet}")
        if estimate_tokens("\n".join(lines)) >= max_tokens:
            lines.append(f"- … (truncated at {max_tokens} token budget)")
            break

    return "\n".join(lines)


def summarize_dropped(
    dropped: Sequence[MessageLike],
    config: CompactionConfig,
    summarizer: SummarizerCallable | None = None,
) -> str:
    """Run the summarizer with safety net.

    If a custom *summarizer* is provided it gets first crack; on any
    exception we fall back to :func:`deterministic_summarizer`. This
    matches the chat REPL's "never break on a side-effect" stance.
    """
    if summarizer is None:
        return deterministic_summarizer(dropped, config.summary_max_tokens)
    try:
        text = summarizer(dropped, config.summary_max_tokens)
        if not isinstance(text, str) or not text.strip():
            raise ValueError("summarizer returned empty string")
        return text
    except Exception as exc:  # noqa: BLE001 — defence in depth
        logger.warning(
            "compaction summarizer failed, falling back to deterministic: %s",
            exc,
        )
        return deterministic_summarizer(dropped, config.summary_max_tokens)


# ─────────────────────────────────────────────────────────────────
# Result type
# ─────────────────────────────────────────────────────────────────


@dataclass
class CompactionResult:
    """Outcome of one :func:`compact_messages` call.

    Attributes:
        triggered: Whether a compaction actually ran.
        before_tokens: Token count before compaction.
        after_tokens: Token count after compaction (== ``before`` if
            not triggered).
        before_messages: Message count before compaction.
        after_messages: Message count after compaction.
        preserved_count: Number of messages kept verbatim.
        dropped_count: Number of messages summarised away.
        summary_tokens: Token count of the summary block (0 if not
            triggered).
        new_messages: The rewritten message list (== input list if
            not triggered, never the same reference even when no-op).
        timestamp: ISO-8601 UTC timestamp of the compaction event.
        reason: Human-readable explanation — useful for ``/status``.
    """

    triggered: bool
    before_tokens: int
    after_tokens: int
    before_messages: int
    after_messages: int
    preserved_count: int
    dropped_count: int
    summary_tokens: int
    new_messages: list[MessageLike] = field(default_factory=list)
    timestamp: str = field(
        default_factory=lambda: datetime.now(timezone.utc).isoformat()
    )
    reason: str = ""

    @property
    def tokens_freed(self) -> int:
        """Net tokens reclaimed (``before - after``, never negative)."""
        return max(0, self.before_tokens - self.after_tokens)


# ─────────────────────────────────────────────────────────────────
# Orchestrator
# ─────────────────────────────────────────────────────────────────


CompactionPlacement = Literal["replace_dropped", "prepend"]


def compact_messages(
    messages: Sequence[MessageLike],
    config: CompactionConfig | None = None,
    summarizer: SummarizerCallable | None = None,
    *,
    force: bool = False,
    placement: CompactionPlacement = "replace_dropped",
) -> CompactionResult:
    """Run one compaction pass over *messages*.

    When the threshold isn't crossed (and ``force=False``) the call is
    a no-op — the result is returned with ``triggered=False`` and the
    original message list cloned. The clone keeps the contract that
    ``new_messages`` is always safe to swap into the REPL state.

    Placement controls where the synthesised summary block lands:

      * ``"replace_dropped"`` (default): the contiguous range of
        dropped messages is replaced by one ``user`` message holding
        the summary. Subsequent preserved messages shift left.
      * ``"prepend"``: the summary becomes the very first message
        regardless of where the dropped range sat. Useful when the
        preserved set is non-contiguous and a clean "context recap →
        recent turns" story matters more than positional fidelity.

    Args:
        messages: Conversation history.
        config: Tunables. Defaults to ``CompactionConfig()``.
        summarizer: Optional LLM-backed summarizer.
        force: Skip the threshold check and compact unconditionally.
        placement: Where to put the summary block (see above).

    Returns:
        :class:`CompactionResult` with the rewritten messages and
        diagnostic counters.
    """
    cfg = config or CompactionConfig()
    msgs = list(messages)
    before_tokens = count_messages_tokens(msgs)
    before_messages = len(msgs)

    trigger, _ = should_compact(msgs, cfg)
    if not trigger and not force:
        return CompactionResult(
            triggered=False,
            before_tokens=before_tokens,
            after_tokens=before_tokens,
            before_messages=before_messages,
            after_messages=before_messages,
            preserved_count=before_messages,
            dropped_count=0,
            summary_tokens=0,
            new_messages=list(msgs),
            reason="threshold not crossed",
        )

    preserved_idx, drop_idx = select_preserved(msgs, cfg)

    # No drops → nothing to do (e.g. very short conversation hit the
    # forced path). Treat as no-op.
    if not drop_idx:
        return CompactionResult(
            triggered=False,
            before_tokens=before_tokens,
            after_tokens=before_tokens,
            before_messages=before_messages,
            after_messages=before_messages,
            preserved_count=before_messages,
            dropped_count=0,
            summary_tokens=0,
            new_messages=list(msgs),
            reason="nothing to drop after preservation rules",
        )

    dropped_msgs = [msgs[i] for i in drop_idx]
    summary_text = summarize_dropped(dropped_msgs, cfg, summarizer)
    summary_msg: MessageLike = {
        "role": "user",
        "content": summary_text,
        "_compaction": True,
        "_compaction_dropped": len(dropped_msgs),
    }
    summary_tokens = count_message_tokens(summary_msg)

    preserved_msgs = [msgs[i] for i in preserved_idx]

    if placement == "prepend":
        new_messages: list[MessageLike] = [summary_msg, *preserved_msgs]
    else:
        # "replace_dropped": stitch summary into the position the first
        # dropped message used to occupy, then the preserved tail.
        first_drop = drop_idx[0]
        prefix = [m for i, m in enumerate(msgs) if i in preserved_idx and i < first_drop]
        suffix = [m for i, m in enumerate(msgs) if i in preserved_idx and i >= first_drop]
        new_messages = [*prefix, summary_msg, *suffix]

    after_tokens = count_messages_tokens(new_messages)
    return CompactionResult(
        triggered=True,
        before_tokens=before_tokens,
        after_tokens=after_tokens,
        before_messages=before_messages,
        after_messages=len(new_messages),
        preserved_count=len(preserved_idx),
        dropped_count=len(drop_idx),
        summary_tokens=summary_tokens,
        new_messages=new_messages,
        reason="forced" if force and not trigger else "threshold crossed",
    )


# ─────────────────────────────────────────────────────────────────
# Stateful wrapper for the REPL
# ─────────────────────────────────────────────────────────────────


@dataclass
class CompactionEvent:
    """Tiny audit trail entry kept by :class:`AutoCompactor`."""

    timestamp: str
    triggered: bool
    before_tokens: int
    after_tokens: int
    dropped_count: int
    reason: str


class AutoCompactor:
    """Reusable compactor with its own threading lock + history.

    The REPL holds one instance and calls :meth:`maybe_compact` after
    each user turn. Concurrent calls (e.g. from a slash command on
    another thread) are serialised on ``self._lock`` so the message
    list never ends up half-rewritten.

    Attributes (read-only):
        config: The :class:`CompactionConfig` in use.
        summarizer: Optional summarizer callable.
        history: Bounded list of recent :class:`CompactionEvent`s.
    """

    _MAX_HISTORY = 32

    def __init__(
        self,
        config: CompactionConfig | None = None,
        summarizer: SummarizerCallable | None = None,
    ) -> None:
        self.config = config or CompactionConfig()
        self.summarizer = summarizer
        self.history: list[CompactionEvent] = []
        self._lock = threading.RLock()

    # ── Pure helpers exposed for /status ─────────────────────────

    def usage_pct(self, messages: Sequence[MessageLike]) -> float:
        """Return current usage as a fraction of the window (0.0-…)."""
        tokens = count_messages_tokens(messages)
        if self.config.context_window <= 0:
            return 0.0
        return tokens / self.config.context_window

    def usage_summary(self, messages: Sequence[MessageLike]) -> dict[str, Any]:
        """Compact dict for ``/status`` rendering."""
        tokens = count_messages_tokens(messages)
        return {
            "tokens": tokens,
            "context_window": self.config.context_window,
            "usage_pct": (
                tokens / self.config.context_window
                if self.config.context_window > 0
                else 0.0
            ),
            "threshold_pct": self.config.threshold_pct,
            "threshold_tokens": self.config.threshold_tokens(),
            "messages": len(messages),
            "events": len(self.history),
            "last_event": (
                {
                    "ts": self.history[-1].timestamp,
                    "triggered": self.history[-1].triggered,
                    "freed": (
                        self.history[-1].before_tokens
                        - self.history[-1].after_tokens
                    ),
                    "dropped": self.history[-1].dropped_count,
                }
                if self.history
                else None
            ),
        }

    # ── Driving compaction ───────────────────────────────────────

    def maybe_compact(
        self,
        messages: Sequence[MessageLike],
    ) -> CompactionResult:
        """Compact iff threshold crossed. Thread-safe."""
        with self._lock:
            result = compact_messages(messages, self.config, self.summarizer)
            self._record(result)
            return result

    def force_compact(
        self,
        messages: Sequence[MessageLike],
    ) -> CompactionResult:
        """Compact regardless of threshold. Thread-safe."""
        with self._lock:
            result = compact_messages(
                messages, self.config, self.summarizer, force=True,
            )
            self._record(result)
            return result

    # ── Internal ─────────────────────────────────────────────────

    def _record(self, result: CompactionResult) -> None:
        event = CompactionEvent(
            timestamp=result.timestamp,
            triggered=result.triggered,
            before_tokens=result.before_tokens,
            after_tokens=result.after_tokens,
            dropped_count=result.dropped_count,
            reason=result.reason,
        )
        self.history.append(event)
        if len(self.history) > self._MAX_HISTORY:
            # Drop oldest in batches to amortize the slice cost.
            self.history = self.history[-self._MAX_HISTORY:]


# ─────────────────────────────────────────────────────────────────
# LLM-backed summarizer adapter (optional production wiring)
# ─────────────────────────────────────────────────────────────────


_SUMMARY_SYSTEM_PROMPT = (
    "You are a conversation summarizer for the Sancio chat runtime. "
    "Compress the supplied conversation transcript into a dense, "
    "lossy-but-faithful recap. Keep:\n"
    "  - user goals, requirements, decisions made\n"
    "  - tool calls + their final outcomes (not the raw payloads)\n"
    "  - any open question or pending task\n"
    "Drop:\n"
    "  - filler, greetings, small talk\n"
    "  - intermediate tool reasoning\n"
    "Output a markdown bullet list. Maximum {max_tokens} tokens."
)


def make_llm_summarizer(driver: Any) -> SummarizerCallable:
    """Wrap an LLM driver as a :data:`SummarizerCallable`.

    The driver must expose ``complete(messages, **kwargs)`` returning
    an object with a ``.text`` attribute — same Protocol the chat
    REPL uses (:class:`persona.cli.chat._DriverLike`). Designed for
    Haiku 4.5 in production but driver-agnostic.

    Failures bubble up to :func:`summarize_dropped` which catches
    them and falls back to :func:`deterministic_summarizer`.
    """

    def _call(dropped: Sequence[MessageLike], max_tokens: int) -> str:
        # Render the dropped transcript as one big user message so the
        # driver sees a self-contained "summarize this" task without
        # us spoofing a conversation.
        transcript_lines: list[str] = []
        for m in dropped:
            role = m.get("role", "?")
            transcript_lines.append(f"### {role}")
            transcript_lines.append(_stringify_content(m.get("content", "")))
        transcript = "\n".join(transcript_lines)

        system = _SUMMARY_SYSTEM_PROMPT.format(max_tokens=max_tokens)
        prompt = (
            f"Summarize the following conversation transcript "
            f"(target ≤ {max_tokens} tokens):\n\n{transcript}"
        )
        response = driver.complete(
            [{"role": "user", "content": prompt}],
            tools=None,
            system=system,
            max_tokens=max_tokens,
        )
        text = getattr(response, "text", "") or ""
        return str(text)

    return _call


# ─────────────────────────────────────────────────────────────────
# Public surface
# ─────────────────────────────────────────────────────────────────

__all__ = [
    "AutoCompactor",
    "CompactionConfig",
    "CompactionEvent",
    "CompactionPlacement",
    "CompactionResult",
    "MessageLike",
    "SummarizerCallable",
    "compact_messages",
    "count_message_tokens",
    "count_messages_tokens",
    "deterministic_summarizer",
    "estimate_tokens",
    "make_llm_summarizer",
    "select_preserved",
    "should_compact",
    "summarize_dropped",
]
