"""GDPR compliance endpoints — Art 15 (access) + Art 17 (erasure).

Sancio has EU users under GDPR Art 3(2) territorial scope (services
targeted at EU data subjects). This module implements the two
data-subject rights that are *mandatory* for any processor:

* ``POST /v1/gdpr/export``  — Art 15 Right of Access. Returns a
  JSON bundle of every piece of PII we store about the
  Bearer-authenticated user: profile, budget history, a2a
  invocations referencing their id, persona bindings.
* ``POST /v1/gdpr/delete``  — Art 17 Right to Erasure. Soft-deletes
  the user immediately (marks them deleted + scrubs PII from
  response surface) and schedules a hard-delete after
  :data:`SOFT_DELETE_RETENTION_DAYS` so accidental requests can be
  reversed within the window.
* ``GET  /v1/privacy``      — public privacy-policy JSON (Art 13/14
  transparency notice, machine-readable).

Design notes
------------

* No user can export or delete *another* user's data — we pull the
  user id from the JWT claim, never from the request body.
* The audit log (``auth_events``) records each export / erasure
  request with the user id + event name but **not** any PII — the
  whole point of erasure is that the user's name is not retained
  after the retention window.
* Hard-delete runs in-process (no external cron): ``purge_expired``
  is idempotent and callable from a systemd timer, or from the
  same middleware path on next request. For the 0.3.0 ship we
  expose it as a helper so operators can run it from a one-off
  REPL; a timer will come in 0.4.0.
"""

from __future__ import annotations

import json
import logging
import os
import sqlite3
import time
from pathlib import Path
from typing import TYPE_CHECKING

from starlette.responses import JSONResponse
from starlette.routing import Route

from .auth import (
    _db_path as _auth_db_path,
    _require_user,
)
from .budget import _db_path as _budget_db_path

if TYPE_CHECKING:
    from starlette.requests import Request

_LOG = logging.getLogger("persona.gdpr")


# ── Config ──────────────────────────────────────

SOFT_DELETE_RETENTION_DAYS = int(
    os.environ.get("SANCIO_GDPR_RETENTION_DAYS", "7"),
)


# ── Soft-delete schema (bolt-on table in auth.db) ───


_SOFT_DELETE_SCHEMA = """
CREATE TABLE IF NOT EXISTS gdpr_deletions (
    user_id INTEGER PRIMARY KEY,
    username TEXT NOT NULL,
    requested_at INTEGER NOT NULL,
    hard_delete_after INTEGER NOT NULL
);
"""


def _connect_auth() -> sqlite3.Connection:
    """Auth DB connection with gdpr schema applied."""
    path = _auth_db_path()
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(path, isolation_level=None)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    conn.executescript(_SOFT_DELETE_SCHEMA)
    return conn


# ── Export (Art 15) ─────────────────────────────


def _collect_profile(user_id: int) -> dict:
    """Pull the user's profile + config blob (no password hash)."""
    conn = _connect_auth()
    try:
        user_row = conn.execute(
            "SELECT id, username, created_at, updated_at"
            " FROM users WHERE id = ?",
            (user_id,),
        ).fetchone()
        config_row = conn.execute(
            "SELECT config_json, updated_at FROM user_configs"
            " WHERE user_id = ?",
            (user_id,),
        ).fetchone()
        events = conn.execute(
            "SELECT event, at FROM auth_events WHERE user_id = ?"
            " ORDER BY at ASC",
            (user_id,),
        ).fetchall()
    finally:
        conn.close()
    return {
        "user": dict(user_row) if user_row else None,
        "config": (
            json.loads(config_row["config_json"])
            if config_row and config_row["config_json"] else {}
        ),
        "config_updated_at": (
            config_row["updated_at"] if config_row else None
        ),
        "auth_events": [dict(row) for row in events],
    }


def _collect_budget(user_id: int) -> list[dict]:
    """Pull the user's budget daily history."""
    path = _budget_db_path()
    if not Path(path).exists():
        return []
    try:
        conn = sqlite3.connect(path, isolation_level=None)
        conn.row_factory = sqlite3.Row
        try:
            rows = conn.execute(
                "SELECT day, tokens, usd, updated_at FROM budget_daily"
                " WHERE user_id = ? ORDER BY day ASC",
                (str(user_id),),
            ).fetchall()
        finally:
            conn.close()
    except sqlite3.Error:
        return []
    return [dict(row) for row in rows]


def _collect_a2a(user_id: int) -> list[dict]:
    """Pull a2a invocations referencing this user id.

    A2A state is in-memory (LRU cache in :mod:`persona.a2a`) so we
    snapshot what's live now. Empty list on cache miss is correct —
    evicted rows are *genuinely gone* and we have no duty to keep
    them for export.
    """
    try:
        from .a2a import _invocations  # type: ignore[attr-defined]
    except ImportError:
        return []
    user_str = str(user_id)
    out: list[dict] = []
    # _invocations is an _InvocationsLRU: ._store is OrderedDict[str,
    # (dict, float)] keyed by invocation id. Iterate a snapshot so
    # we don't trip over concurrent mutation during export.
    try:
        store = getattr(_invocations, "_store", None)
        if store is None:
            return []
        for inv_id, entry in list(store.items()):
            if not isinstance(entry, tuple) or len(entry) != 2:
                continue
            record, _ts = entry
            if not isinstance(record, dict):
                continue
            initiator = record.get("initiator")
            if not isinstance(initiator, dict):
                initiator = {}
            if (
                record.get("user_id") == user_str
                or initiator.get("user_id") == user_str
            ):
                out.append({"invocation_id": inv_id, **record})
    except Exception:  # noqa: BLE001 — defensive cache probe
        return []
    return out


def build_export(user_id: int) -> dict:
    """Assemble the full Art 15 JSON bundle for ``user_id``."""
    now = int(time.time())
    return {
        "schema_version": "1",
        "generated_at": now,
        "user_id": user_id,
        "profile": _collect_profile(user_id),
        "budget_history": _collect_budget(user_id),
        "a2a_invocations": _collect_a2a(user_id),
        "persona_bindings": _collect_profile(user_id)["config"].get(
            "digitalHumanCharacterName",
        ),
        "notes": (
            "This export contains all personal data Sancio stores "
            "about you at the moment of request. Cache-evicted rows "
            "are not recoverable. Contact privacy@ai-king.dev for "
            "clarification."
        ),
    }


async def _export_endpoint(request: Request) -> JSONResponse:
    """``POST /v1/gdpr/export`` — return Art 15 data bundle."""
    user, err = await _require_user(request)
    if err:
        return err
    bundle = build_export(int(user["id"]))

    # Audit record (PII-free: just the user id + event).
    try:
        from .auth import record_event
        record_event(int(user["id"]), "gdpr_export")
    except Exception:  # noqa: BLE001
        _LOG.exception("failed to record gdpr_export audit event")

    return JSONResponse(bundle)


# ── Erasure (Art 17) ────────────────────────────


def request_deletion(user_id: int, username: str) -> dict:
    """Mark the user as pending-delete; hard-delete after retention.

    Idempotent — calling twice just bumps ``requested_at``. Returns
    the deletion record so callers can surface the scheduled
    hard-delete timestamp.
    """
    now = int(time.time())
    hard_after = now + SOFT_DELETE_RETENTION_DAYS * 86400
    conn = _connect_auth()
    try:
        conn.execute(
            "INSERT INTO gdpr_deletions"
            " (user_id, username, requested_at, hard_delete_after)"
            " VALUES (?, ?, ?, ?)"
            " ON CONFLICT(user_id) DO UPDATE SET"
            " requested_at = excluded.requested_at,"
            " hard_delete_after = excluded.hard_delete_after",
            (user_id, username, now, hard_after),
        )
    finally:
        conn.close()
    return {
        "user_id": user_id,
        "state": "pending_hard_delete",
        "requested_at": now,
        "hard_delete_after": hard_after,
        "retention_days": SOFT_DELETE_RETENTION_DAYS,
    }


def _hard_delete_user(user_id: int) -> None:
    """Scrub every table we own for this user. Idempotent."""
    # Auth DB — users row + configs + auth_events + gdpr_deletions.
    conn = _connect_auth()
    try:
        conn.execute("DELETE FROM users WHERE id = ?", (user_id,))
        conn.execute(
            "DELETE FROM user_configs WHERE user_id = ?", (user_id,),
        )
        conn.execute(
            "DELETE FROM auth_events WHERE user_id = ?", (user_id,),
        )
        conn.execute(
            "DELETE FROM gdpr_deletions WHERE user_id = ?", (user_id,),
        )
    finally:
        conn.close()

    # Budget DB — daily rows keyed by stringified user id.
    path = _budget_db_path()
    if Path(path).exists():
        try:
            bconn = sqlite3.connect(path, isolation_level=None)
            try:
                bconn.execute(
                    "DELETE FROM budget_daily WHERE user_id = ?",
                    (str(user_id),),
                )
            finally:
                bconn.close()
        except sqlite3.Error:
            _LOG.exception(
                "budget hard-delete failed for user_id=%s", user_id,
            )

    # A2A in-memory invocations — flush matching. ``_store`` is the
    # OrderedDict[str, (dict, float)] inside _InvocationsLRU.
    try:
        from .a2a import _invocations
        store = getattr(_invocations, "_store", None)
        if store is not None:
            user_str = str(user_id)
            for inv_id, entry in list(store.items()):
                if not isinstance(entry, tuple) or len(entry) != 2:
                    continue
                record, _ts = entry
                if not isinstance(record, dict):
                    continue
                initiator = record.get("initiator")
                if not isinstance(initiator, dict):
                    initiator = {}
                if (
                    record.get("user_id") == user_str
                    or initiator.get("user_id") == user_str
                ):
                    store.pop(inv_id, None)
    except Exception:  # noqa: BLE001
        pass


def purge_expired(now: int | None = None) -> list[int]:
    """Hard-delete every user past their ``hard_delete_after``.

    Returns the list of hard-deleted user ids. Callable from a
    systemd timer / REPL / test.
    """
    t = now if now is not None else int(time.time())
    conn = _connect_auth()
    try:
        rows = conn.execute(
            "SELECT user_id FROM gdpr_deletions"
            " WHERE hard_delete_after <= ?",
            (t,),
        ).fetchall()
    finally:
        conn.close()
    ids = [int(row["user_id"]) for row in rows]
    for uid in ids:
        _hard_delete_user(uid)
    return ids


async def _delete_endpoint(request: Request) -> JSONResponse:
    """``POST /v1/gdpr/delete`` — Art 17 erasure (soft then hard)."""
    user, err = await _require_user(request)
    if err:
        return err
    record = request_deletion(int(user["id"]), str(user["username"]))

    # Audit (PII-free).
    try:
        from .auth import record_event
        record_event(int(user["id"]), "gdpr_delete_requested")
    except Exception:  # noqa: BLE001
        _LOG.exception("failed to record gdpr_delete audit event")

    return JSONResponse(record)


# ── Privacy policy (public) ──────────────────────


PRIVACY_POLICY = {
    "schema_version": "1",
    "controller": "AI King (ai-king.dev)",
    "processors": [
        "Anthropic (Claude API)",
        "Cloudflare (CDN / tunnel transport)",
        "VPS provider (hosting)",
    ],
    "purposes": [
        "agent inference",
        "budget tracking",
        "audit / anti-abuse",
        "persona state sync",
    ],
    "legal_basis": "GDPR Art 6(1)(f) legitimate interest",
    "retention": {
        "budget_db": "2 years",
        "audit_log": "6 months",
        "profile": "account lifetime",
        "soft_deleted": f"{SOFT_DELETE_RETENTION_DAYS} days",
    },
    "rights": [
        "access",
        "rectification",
        "erasure",
        "portability",
        "object",
        "restrict_processing",
    ],
    "contact": "privacy@ai-king.dev",
    "endpoints": {
        "export": "POST /v1/gdpr/export (Bearer)",
        "delete": "POST /v1/gdpr/delete (Bearer)",
        "policy": "GET /v1/privacy (public)",
    },
}


async def _privacy_endpoint(_request: Request) -> JSONResponse:
    """``GET /v1/privacy`` — public transparency notice."""
    return JSONResponse(PRIVACY_POLICY)


# ── Route factory ───────────────────────────────


def create_gdpr_routes() -> list[Route]:
    """Return the GDPR + privacy route list."""
    return [
        Route("/v1/gdpr/export", _export_endpoint, methods=["POST"]),
        Route("/v1/gdpr/delete", _delete_endpoint, methods=["POST"]),
        Route("/v1/privacy", _privacy_endpoint, methods=["GET"]),
    ]
