"""Context-budget guard for the local LLM gateway.

Last-resort sliding window applied at the ``/v1/messages`` boundary
to keep prompts inside ``N_CTX`` no matter what shape the upstream
caller built. This is a *floor*, not a strategy — PSYCHE TS owns
the smart hierarchical summary (rolling LLM-summary of older turns)
and FieldRead-bounded system prompt; this module exists because:

1. PSYCHE ``_passthroughChat`` forwards ``body.messages`` verbatim
   without any compression — a 30+ turn mod conversation would
   crash the local Llama with "Failed to create llama_context".
2. Future callers (OpenClaw, ad-hoc curl, A2A peers) won't go
   through PSYCHE compression at all.
3. Bugs in PSYCHE compression should still degrade gracefully
   instead of 5xx.

Architecture context (2026-04-27j):

* Local Gemma-4-31B Q4_K_M on RTX 5090, ``N_CTX=12288`` (VRAM
  ceiling determined experimentally — see
  ``scripts/pod/llamacpp_wrap.py`` history block).
* ``flash_attn=True`` enabled at the wheel level so V cache is
  not padded to ``head_dim=4096``.
* Reply budget reservation must leave room for both the model's
  generation *and* internal scratch tensors that llama.cpp
  allocates inside the same KV cache region.

Strategy (closest production analogue: Mem0's recent-verbatim +
truncate-from-front; LangChain ConversationBufferWindowMemory):

* Estimate token count via mixed-script heuristic (CJK chars cost
  ~1.6/token, ASCII ~4 chars/token — accurate enough at the
  boundary; underestimate is safer than overestimate so we err
  toward keeping more context but log a warning if we cut).
* Keep system message (always) + sliding window of most recent
  user/assistant turns where ``sum(tokens) <= budget``.
* If system alone exceeds 80% of budget, prefix-truncate it
  (keep the head — that's where FieldRead writes the hard
  identity / lore — and drop the tail with a marker).
* Always preserve the *last* user message verbatim (otherwise
  the model has no input to respond to).

This module is intentionally heuristic and stateless. Production
SOTA (Mem0/Letta) does importance scoring + LLM summarisation;
that quality layer lives in PSYCHE TS where the per-character
data root is available. Sancio just makes sure nothing crashes.
"""

from __future__ import annotations

import logging
from typing import Any

_log = logging.getLogger(__name__)


# Asymmetric tokenisation constants (see module docstring).
#
# When ESTIMATING tokens from chars, we want to *underestimate* the
# token count so we don't over-trim. ASCII has 4 chars/token, CJK
# has 1.6 — using the per-script divisor below gives a tight
# estimate.
#
# When INVERTING (computing the chars budget for a target token
# count, used to truncate oversize messages), we must use the
# WORST-CASE density: CJK at 1.6 chars/token. If we used the
# average 1.8, then a pure-CJK string truncated to ``tokens × 1.8``
# chars still yields ``(tokens × 1.8) / 1.6 > tokens`` real tokens
# — i.e. we'd violate our own budget contract. Always invert with
# the densest-script ratio.
_CHARS_PER_TOKEN_DENSEST = 1.0  # CJK worst-case (1 token per char)
_PER_MESSAGE_OVERHEAD = 6       # Gemma <start_of_turn>...<end_of_turn> wrap


def estimate_tokens(text: str | None) -> int:
    """Heuristic token count for a mixed CJK/ASCII string.

    Accuracy bounds: ±15% vs. real Gemma BPE tokenizer on Chinese
    role-play traffic; deliberately *underestimates* on heavy
    punctuation / mark-up since llama.cpp tokenisers fold those
    into 1 token most of the time. We pad with a safety margin
    at the call site rather than trying to match the real
    tokenizer here (which would require loading the model just
    to count — defeats the purpose of a cheap pre-filter).
    """
    if not text:
        return 0
    # CJK Unified Ideographs (most common in our traffic).
    cjk = sum(1 for c in text if "一" <= c <= "鿿")
    other = len(text) - cjk
    # CONSERVATIVE upper bound: zh ~1.0 char/token (Gemma BPE on
    # CJK frequently splits one character into one token, sometimes
    # rare characters into two — empirically validated 04-27j when
    # the previous 1.6 divisor underestimated by ~50% and the wrap
    # server still 500'd after Tier S trimmed). en/punct ~3.5/token
    # (ASCII can compress harder but punctuation dilutes).
    # We *prefer to overestimate* so ``apply_sliding_window`` trims
    # more aggressively — a smaller-than-needed prompt is safe; a
    # larger-than-needed one crashes llama.
    return int(cjk / 1.0 + other / 3.5)


def estimate_message_tokens(message: dict[str, Any]) -> int:
    """Token cost of one OpenAI-shape message (role + content + per-msg overhead).

    Per-message overhead (~4 tokens) covers the role marker, content
    boundary, and chat-template wrapping that llama.cpp injects per
    turn. This matches OpenAI's published tokenisation guidance for
    chat completion.
    """
    content = message.get("content")
    if isinstance(content, list):
        # Multi-modal content blocks (text, image, etc.). Sum text
        # parts; ignore image / tool blocks for now since Gemma-4
        # text-only deployment doesn't surface them.
        text_total = 0
        for block in content:
            if isinstance(block, dict) and block.get("type") == "text":
                text_total += estimate_tokens(block.get("text"))
        return text_total + _PER_MESSAGE_OVERHEAD
    return (
        estimate_tokens(content if isinstance(content, str) else None)
        + _PER_MESSAGE_OVERHEAD
    )


def _truncate_oversize_system(
    messages: list[dict[str, Any]],
    sys_idx: int,
    budget: int,
) -> list[dict[str, Any]]:
    """Prefix-keep + tail-drop a system message that exceeds 80% of budget.

    FieldRead writes the hard identity / lore at the head of the
    system prompt and accumulates softer per-turn context toward
    the tail, so prefix-kept truncation is the safe direction.

    Inversion uses ``_CHARS_PER_TOKEN_DENSEST`` (CJK 1.6) — see
    module-level constant docstring for why we cannot use the
    average 1.8 here.
    """
    sys_msg = messages[sys_idx]
    sys_t = estimate_message_tokens(sys_msg)
    target_t_cap = int(budget * 0.8)
    if sys_t <= target_t_cap:
        return messages
    content = sys_msg.get("content", "")
    if not isinstance(content, str):
        return messages
    marker = (
        "\n\n[...system prompt truncated by sancio "
        "context_budget guard — pre-existing length "
        f"{sys_t}t exceeded 80%% of budget {budget}t...]"
    )
    marker_t = estimate_tokens(marker) + _PER_MESSAGE_OVERHEAD
    target_chars = int(
        max(target_t_cap - marker_t, 100) * _CHARS_PER_TOKEN_DENSEST
    )
    truncated = content[:target_chars] + marker
    out = list(messages)
    out[sys_idx] = {**sys_msg, "content": truncated}
    _log.warning(
        "context_budget: system prompt %dt > 80%% of budget %dt; "
        "truncated to ~%dt (prefix-kept)",
        sys_t, budget, estimate_message_tokens(out[sys_idx]),
    )
    return out


def _truncate_oversize_last_user(
    messages: list[dict[str, Any]],
    last_user_idx: int,
    available: int,
) -> tuple[list[dict[str, Any]], int]:
    """Tail-keep truncate when the latest user message alone exceeds budget.

    Returns ``(messages, new_last_user_tokens)``. Last user message
    is the model's input — keep its tail (newest content) since
    role-play context usually puts the immediate prompt last.
    """
    m = messages[last_user_idx]
    last_user_t = estimate_message_tokens(m)
    if last_user_t <= available:
        return messages, last_user_t
    content = m.get("content", "")
    if not isinstance(content, str):
        return messages, last_user_t
    marker = "\n\n[...input truncated by sancio guard, tail-kept...]"
    marker_t = estimate_tokens(marker) + _PER_MESSAGE_OVERHEAD
    target_chars = int(
        max(available - marker_t, 100) * _CHARS_PER_TOKEN_DENSEST
    )
    out = list(messages)
    out[last_user_idx] = {
        **m,
        "content": content[-target_chars:] + marker,
    }
    _log.warning(
        "context_budget: last user message %dt > available %dt; "
        "tail-truncated to fit",
        last_user_t, available,
    )
    return out, estimate_message_tokens(out[last_user_idx])


def apply_sliding_window(
    messages: list[dict[str, Any]],
    n_ctx: int,
    max_reply: int,
    safety_margin: int = 512,
) -> tuple[list[dict[str, Any]], int]:
    """Trim ``messages`` so the prompt fits in ``n_ctx − max_reply − safety_margin``.

    Returns ``(trimmed_messages, dropped_count)``.

    Invariants:
      * System message (role == "system") is always preserved.
      * The *last* user message is always preserved (model needs input).
      * If system alone > 80% of budget, prefix-kept + tail-dropped.
      * Drop priority: oldest non-system, non-last-user messages first.
    """
    if not messages:
        return messages, 0
    budget = n_ctx - max_reply - safety_margin
    if budget <= 0:
        _log.warning(
            "context_budget: n_ctx=%d − max_reply=%d − margin=%d ≤ 0; "
            "nothing fits, returning empty (caller will get 400)",
            n_ctx, max_reply, safety_margin,
        )
        return [], len(messages)

    sys_idx = next(
        (i for i, m in enumerate(messages) if m.get("role") == "system"),
        None,
    )
    last_user_idx = next(
        (i for i in range(len(messages) - 1, -1, -1)
         if messages[i].get("role") == "user"),
        None,
    )

    if sys_idx is not None:
        messages = _truncate_oversize_system(messages, sys_idx, budget)
    sys_t = (
        estimate_message_tokens(messages[sys_idx])
        if sys_idx is not None else 0
    )
    available = budget - sys_t

    must_keep_idx: set[int] = set()
    if sys_idx is not None:
        must_keep_idx.add(sys_idx)
    if last_user_idx is not None:
        must_keep_idx.add(last_user_idx)
        messages, last_user_t = _truncate_oversize_last_user(
            messages, last_user_idx, available,
        )
        available = max(available - last_user_t, 0)
    else:
        last_user_t = 0

    # Greedy keep-from-end among non-anchor messages.
    keep_idx: set[int] = set(must_keep_idx)
    used = 0
    for i in range(len(messages) - 1, -1, -1):
        if i in must_keep_idx:
            continue
        t = estimate_message_tokens(messages[i])
        if used + t > available:
            break
        used += t
        keep_idx.add(i)

    trimmed = [messages[i] for i in sorted(keep_idx)]
    dropped = len(messages) - len(trimmed)
    if dropped > 0:
        # WARNING level so it propagates through uvicorn's default
        # root-logger filter (which suppresses INFO from non-uvicorn
        # modules). Operators want to see when the guard activates.
        _log.warning(
            "context_budget: dropped %d older message(s) to fit budget "
            "%dt (kept %d, sys_t≈%d, last_user_t≈%d)",
            dropped, budget, len(trimmed), sys_t, last_user_t,
        )
    return trimmed, dropped


__all__ = [
    "estimate_tokens",
    "estimate_message_tokens",
    "apply_sliding_window",
]
