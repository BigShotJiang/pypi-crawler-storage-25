"""Aegis API — unified safety + persona engine.

2.0.0 surface (CC SDK April 2026 alignment + L6 Option C reframe):

* :class:`persona.hooks.post_decision.PostToolUseDecision` — return
  shape for :data:`persona.engine.agent_loop.PostToolUseHook`. Mirrors
  CC's ``hookSpecificOutput`` (``updatedToolOutput`` /
  ``additionalContext`` / ``decision="block"`` + ``reason``).
* :class:`PostToolDeny` / :class:`PostToolUseBlocked` — exceptions
  raised by post-hooks to deny via the observation channel. Side
  effects already happened (CC physics ceiling per GitHub #32105) —
  what we contain is the LLM-visible conversation downstream.
* :class:`ConfigChangeEvent` / :class:`ConfigChangeBlocked` /
  :class:`ConfigWatcher` — live-reload surface for settings DSL
  mutations (CC ``ConfigChange`` parity).

See ``docs/migration-1.3-to-2.0.md`` for migration steps from 1.x
hooks. The legacy ``Awaitable[None]`` post-hook signature is
accepted in 2.0.x with a one-shot ``DeprecationWarning`` and
removed in 2.1.
"""

from __future__ import annotations

from .engine import PersonaEngine
from .guards import SafetyLevel, classify_safety
from .hooks.post_decision import (
    PostToolDeny,
    PostToolUseBlocked,
    PostToolUseDecision,
)
from .loader import PersonaData, load_persona_md

# ConfigChange surface — produced by sub-agent B
# (``persona.hooks.config_change`` + ``persona.hooks.config_watcher``).
# Lazy try/except so this module imports cleanly during the prepare
# session window before B's files land. Once B merges, the symbols
# are re-exported unconditionally.
try:  # pragma: no cover — graceful fallback during prepare-session window
    from .hooks.config_change import (  # type: ignore[attr-defined]
        ConfigChangeBlocked,
        ConfigChangeEvent,
    )
    from .hooks.config_watcher import (  # type: ignore[attr-defined]
        ConfigWatcher,
    )

    _CONFIG_CHANGE_AVAILABLE = True
except ImportError:  # pragma: no cover — pre-merge window only
    _CONFIG_CHANGE_AVAILABLE = False

__version__ = "2.0.0"

__all__ = [
    "PersonaData",
    "PersonaEngine",
    "PostToolDeny",
    "PostToolUseBlocked",
    "PostToolUseDecision",
    "SafetyLevel",
    "__version__",
    "classify_safety",
    "load_persona_md",
]

if _CONFIG_CHANGE_AVAILABLE:
    __all__ += [
        "ConfigChangeBlocked",
        "ConfigChangeEvent",
        "ConfigWatcher",
    ]
