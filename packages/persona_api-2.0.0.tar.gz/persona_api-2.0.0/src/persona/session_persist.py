"""persona.session_persist — Chat session manifest + checkpoint snapshot.

Sancio M1 Week 2 (1.2.0) deliverable. Persists ``sancio chat``
sessions across process restarts so the user can ``/resume <id>`` a
conversation that was interrupted by a crash, a deliberate shutdown,
or a model switch.

Design choices:
    * Storage backend: :class:`concinno.core.state_store.StateStore`.
      We don't reinvent atomic JSON I/O — Concinno already exposes a
      battle-tested, file-locking, blake2b-keyed namespace store.
      All Sancio session state lives in two namespaces under
      ``~/.sancio/state/``:
          - ``"sessions"``      — manifest per session (one file).
          - ``"checkpoints"``   — newline-delimited checkpoint log per
                                  session (one file, append-mostly).
    * Schema versioning: every persisted record carries a
      ``"schema": 1`` field so a future migration can fork on it.
    * Trigger model: callers (the chat REPL) decide when to checkpoint
      via :meth:`SessionStore.maybe_checkpoint` — we expose a "every N
      messages OR every M seconds" policy by default but allow a fully
      custom trigger via :class:`CheckpointPolicy`.
    * Resume contract: :meth:`SessionStore.load_latest_checkpoint`
      returns the last successful snapshot or ``None`` — never raises
      on a missing session, so the slash ``/resume`` handler stays
      simple.

@module persona.session_persist
@responsibility Persist + restore the chat REPL's mutable state
    (messages, model id, slash-set fingerprint, tool config) keyed by
    a session id, with manifest metadata and a bounded checkpoint
    history.
@dependencies concinno.core.state_store (StateStore), stdlib.
@exports SessionManifest, SessionSnapshot, CheckpointPolicy,
    SessionStore, default_session_root, generate_session_id,
    SchemaVersionMismatch

License: AGPL-3.0-or-later.
"""

from __future__ import annotations

import json
import logging
import os
import secrets
import threading
import time
from collections.abc import Callable, Sequence
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

logger = logging.getLogger("persona.session_persist")

# Current on-disk schema. Bump when a non-additive change lands; the
# load path raises :class:`SchemaVersionMismatch` so the caller can
# decide whether to migrate or refuse.
SCHEMA_VERSION = 1


# ─────────────────────────────────────────────────────────────────
# Errors
# ─────────────────────────────────────────────────────────────────


class SchemaVersionMismatch(RuntimeError):
    """Raised when a persisted record carries a schema we don't grok."""

    def __init__(self, found: int, expected: int) -> None:
        super().__init__(
            f"session schema mismatch: found v{found}, expected v{expected}",
        )
        self.found = found
        self.expected = expected


# ─────────────────────────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────────────────────────


def default_session_root() -> Path:
    """Default base directory for session state.

    Honours ``SANCIO_SESSION_DIR`` for tests / containerised deploys,
    otherwise lands at ``~/.sancio/state``.
    """
    override = os.environ.get("SANCIO_SESSION_DIR")
    if override:
        return Path(override)
    return Path.home() / ".sancio" / "state"


def generate_session_id() -> str:
    """Return a fresh, URL-safe session id (32 hex chars).

    Uses :func:`secrets.token_hex` so the id is unguessable — sessions
    can theoretically contain credentials in the conversation history,
    so leaking the id by enumeration would be bad.
    """
    return secrets.token_hex(16)


def _utc_iso() -> str:
    """Current UTC time as an ISO-8601 string with timezone."""
    return datetime.now(timezone.utc).isoformat()


# ─────────────────────────────────────────────────────────────────
# Data types
# ─────────────────────────────────────────────────────────────────


@dataclass
class SessionManifest:
    """One-per-session metadata record.

    Lives at ``<root>/sessions/<key>.json`` (key = blake2b(sid)) so
    we can list all sessions cheaply without scanning the heavier
    checkpoint log. Every field is JSON-serialisable.

    Attributes:
        session_id: The full session id. Stored alongside the blake2b
            key so we can recover the human-readable id from the manifest
            (the blake2b key is one-way).
        model_id: Last-known model id at write time.
        tool_set: Names of tools the REPL had registered. Just a hint
            for the resume path — actual tool resolution happens at the
            REPL when it rebuilds.
        created_at: First write timestamp (ISO-8601 UTC).
        last_active: Most recent write timestamp.
        message_count: Cached count from the last checkpoint.
        checkpoint_count: How many snapshots have been written.
        schema: Schema version (always SCHEMA_VERSION on write).
        labels: Free-form key/value tags (e.g. project name, branch).
    """

    session_id: str
    model_id: str = ""
    tool_set: tuple[str, ...] = ()
    created_at: str = field(default_factory=_utc_iso)
    last_active: str = field(default_factory=_utc_iso)
    message_count: int = 0
    checkpoint_count: int = 0
    schema: int = SCHEMA_VERSION
    labels: dict[str, str] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        """Convert to a plain dict ready for JSON serialisation."""
        d = asdict(self)
        # Tuples → lists (JSON has no tuple type).
        d["tool_set"] = list(self.tool_set)
        return d

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> SessionManifest:
        """Build from the dict returned by :class:`StateStore.read`."""
        schema = int(data.get("schema", SCHEMA_VERSION))
        if schema != SCHEMA_VERSION:
            raise SchemaVersionMismatch(found=schema, expected=SCHEMA_VERSION)
        return cls(
            session_id=str(data.get("session_id", "")),
            model_id=str(data.get("model_id", "")),
            tool_set=tuple(data.get("tool_set", ())),
            created_at=str(data.get("created_at") or _utc_iso()),
            last_active=str(data.get("last_active") or _utc_iso()),
            message_count=int(data.get("message_count", 0)),
            checkpoint_count=int(data.get("checkpoint_count", 0)),
            schema=schema,
            labels=dict(data.get("labels", {})),
        )


@dataclass
class SessionSnapshot:
    """One checkpointed snapshot of the REPL state.

    Snapshots are append-only — the checkpoint log keeps the last N
    (configurable) so a user can ``/resume`` to any of them, not just
    the most recent. The N-cap is enforced by :class:`SessionStore`.

    Attributes:
        session_id: Owning session.
        timestamp: ISO-8601 UTC.
        messages: Conversation history (deep copy).
        model_id: Active model id at snapshot time.
        tool_set: Active tools at snapshot time (names).
        message_count: Cached len(messages).
        labels: Free-form metadata snapshotted from the manifest.
        schema: Schema version.
        reason: Why the snapshot was taken (``"timer"`` /
            ``"message_count"`` / ``"manual"`` / ``"shutdown"``).
    """

    session_id: str
    timestamp: str = field(default_factory=_utc_iso)
    messages: list[dict[str, Any]] = field(default_factory=list)
    model_id: str = ""
    tool_set: tuple[str, ...] = ()
    message_count: int = 0
    labels: dict[str, str] = field(default_factory=dict)
    schema: int = SCHEMA_VERSION
    reason: str = "manual"

    def to_dict(self) -> dict[str, Any]:
        """Convert to a JSON-friendly dict."""
        d = asdict(self)
        d["tool_set"] = list(self.tool_set)
        return d

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> SessionSnapshot:
        """Inverse of :meth:`to_dict`."""
        schema = int(data.get("schema", SCHEMA_VERSION))
        if schema != SCHEMA_VERSION:
            raise SchemaVersionMismatch(found=schema, expected=SCHEMA_VERSION)
        return cls(
            session_id=str(data.get("session_id", "")),
            timestamp=str(data.get("timestamp") or _utc_iso()),
            messages=list(data.get("messages", [])),
            model_id=str(data.get("model_id", "")),
            tool_set=tuple(data.get("tool_set", ())),
            message_count=int(data.get("message_count", 0)),
            labels=dict(data.get("labels", {})),
            schema=schema,
            reason=str(data.get("reason", "manual")),
        )


# ─────────────────────────────────────────────────────────────────
# Checkpoint policy
# ─────────────────────────────────────────────────────────────────


@dataclass(frozen=True)
class CheckpointPolicy:
    """When should the SessionStore take a checkpoint?

    Two threshold knobs OR a custom callback. Defaults are tuned for a
    casual chat REPL — checkpoint every 5 user/assistant pairs or
    every 60 seconds, whichever fires first.

    Attributes:
        every_n_messages: Fire when the message count grew by at least
            this many since the last checkpoint. ``0`` disables.
        every_n_seconds: Fire when at least this many seconds elapsed
            since the last checkpoint. ``0`` disables.
        max_history: Keep at most this many snapshots in the
            checkpoint log; older ones are dropped on write. Resume
            can only target snapshots still in the log.
        custom_trigger: Optional callback receiving
            ``(messages, last_ts, last_count)`` and returning True to
            force a snapshot. Runs *in addition to* the threshold
            knobs, not instead of.
    """

    every_n_messages: int = 5
    every_n_seconds: int = 60
    max_history: int = 32
    custom_trigger: Callable[
        [Sequence[dict[str, Any]], float, int], bool
    ] | None = None

    def should_fire(
        self,
        messages: Sequence[dict[str, Any]],
        last_ts: float,
        last_message_count: int,
    ) -> bool:
        """Return True if a checkpoint is due now."""
        now = time.time()
        if (
            self.every_n_messages > 0
            and len(messages) - last_message_count >= self.every_n_messages
        ):
            return True
        if (
            self.every_n_seconds > 0
            and last_ts > 0
            and (now - last_ts) >= self.every_n_seconds
        ):
            return True
        if self.custom_trigger is not None:
            try:
                return bool(self.custom_trigger(messages, last_ts, last_message_count))
            except Exception as exc:  # noqa: BLE001
                logger.warning("custom checkpoint trigger raised: %s", exc)
        return False


# ─────────────────────────────────────────────────────────────────
# SessionStore
# ─────────────────────────────────────────────────────────────────


_SESSIONS_NS = "sessions"
_CHECKPOINTS_NS = "checkpoints"


class SessionStore:
    """Persist + restore chat sessions atop Concinno's StateStore.

    One instance per Sancio process is fine — internal mutation is
    serialised on a re-entrant lock so the chat REPL can call
    :meth:`maybe_checkpoint` from any thread.

    Args:
        root: Base directory for session state. Defaults to
            :func:`default_session_root`.
        policy: Checkpoint trigger policy.
        state_store: Optional pre-built StateStore (tests inject one
            pointing at a temp dir).
    """

    def __init__(
        self,
        root: Path | str | None = None,
        *,
        policy: CheckpointPolicy | None = None,
        state_store: Any = None,
    ) -> None:
        self.root = Path(root) if root is not None else default_session_root()
        self.policy = policy or CheckpointPolicy()
        self._lock = threading.RLock()
        self._tracker: dict[str, _SessionTracker] = {}

        if state_store is not None:
            self._store = state_store
        else:
            self.root.mkdir(parents=True, exist_ok=True)
            try:
                from concinno.core.state_store import StateStore
            except ImportError as exc:  # pragma: no cover — install failure
                raise RuntimeError(
                    "concinno.core.state_store is required by SessionStore. "
                    "Install concinno >= 4.3.0.",
                ) from exc
            self._store = StateStore(str(self.root))

    # ── Manifest API ─────────────────────────────────────────────

    def get_manifest(self, session_id: str) -> dict[str, Any] | None:
        """Return the manifest dict for *session_id* or ``None``.

        Returns the raw dict (not :class:`SessionManifest`) so the
        ``/status`` slash command can render fields directly without
        importing this module's types.
        """
        if not session_id:
            return None
        data = self._store.read(_SESSIONS_NS, session_id, default=None)
        if not data:
            return None
        return dict(data)

    def list_sessions(self) -> list[dict[str, Any]]:
        """Enumerate every persisted session as a manifest dict.

        Sorted by ``last_active`` descending so a user-facing
        ``/sessions`` command can show "most recently touched first".
        """
        out: list[dict[str, Any]] = []
        ns_dir = self.root / _SESSIONS_NS
        if not ns_dir.is_dir():
            return out
        for entry in ns_dir.iterdir():
            if entry.suffix != ".json":
                continue
            try:
                with entry.open("r", encoding="utf-8") as fh:
                    raw = json.load(fh)
            except (OSError, json.JSONDecodeError):
                continue
            if isinstance(raw, dict) and raw.get("session_id"):
                out.append(raw)
        out.sort(key=lambda d: d.get("last_active", ""), reverse=True)
        return out

    def upsert_manifest(self, manifest: SessionManifest) -> None:
        """Write a manifest, replacing any existing record."""
        self._store.write(
            _SESSIONS_NS,
            manifest.session_id,
            manifest.to_dict(),
        )

    def delete_session(self, session_id: str) -> bool:
        """Remove the manifest + checkpoint log for *session_id*.

        Returns True when at least one file was deleted.
        """
        deleted = False
        for ns in (_SESSIONS_NS, _CHECKPOINTS_NS):
            path = Path(self._store._path(ns, session_id))  # noqa: SLF001
            if path.exists():
                try:
                    path.unlink()
                    deleted = True
                except OSError as exc:
                    logger.warning("delete_session failed for %s: %s", path, exc)
        with self._lock:
            self._tracker.pop(session_id, None)
        return deleted

    # ── Checkpoint API ───────────────────────────────────────────

    def checkpoint(
        self,
        session_id: str,
        messages: Sequence[dict[str, Any]],
        *,
        model_id: str = "",
        tool_set: Sequence[str] = (),
        labels: dict[str, str] | None = None,
        reason: str = "manual",
    ) -> SessionSnapshot:
        """Force-write a checkpoint regardless of policy.

        Returns the freshly-written snapshot. Updates the manifest's
        ``last_active`` / ``message_count`` / ``checkpoint_count`` in
        the same call.
        """
        with self._lock:
            snapshot = SessionSnapshot(
                session_id=session_id,
                messages=list(messages),
                model_id=model_id,
                tool_set=tuple(tool_set),
                message_count=len(messages),
                labels=dict(labels or {}),
                reason=reason,
            )
            self._append_checkpoint(snapshot)

            existing = self.get_manifest(session_id)
            if existing is None:
                manifest = SessionManifest(
                    session_id=session_id,
                    model_id=model_id,
                    tool_set=tuple(tool_set),
                    message_count=len(messages),
                    checkpoint_count=1,
                    labels=dict(labels or {}),
                )
            else:
                try:
                    manifest = SessionManifest.from_dict(existing)
                except SchemaVersionMismatch:
                    manifest = SessionManifest(session_id=session_id)
                manifest.model_id = model_id or manifest.model_id
                manifest.tool_set = tuple(tool_set) if tool_set else manifest.tool_set
                manifest.message_count = len(messages)
                manifest.checkpoint_count += 1
                manifest.last_active = _utc_iso()
                if labels:
                    manifest.labels.update(labels)
            self.upsert_manifest(manifest)

            tracker = self._tracker.setdefault(session_id, _SessionTracker())
            tracker.last_ts = time.time()
            tracker.last_message_count = len(messages)
            return snapshot

    def maybe_checkpoint(
        self,
        session_id: str,
        messages: Sequence[dict[str, Any]],
        *,
        model_id: str = "",
        tool_set: Sequence[str] = (),
        labels: dict[str, str] | None = None,
    ) -> SessionSnapshot | None:
        """Take a checkpoint iff :class:`CheckpointPolicy` says yes.

        Returns the new snapshot or ``None`` when nothing fired.
        Calls :meth:`checkpoint` under the hood when triggered, so
        the manifest is always updated atomically with the snapshot.
        """
        with self._lock:
            tracker = self._tracker.setdefault(session_id, _SessionTracker())
            if not self.policy.should_fire(
                messages, tracker.last_ts, tracker.last_message_count,
            ):
                return None
            return self.checkpoint(
                session_id,
                messages,
                model_id=model_id,
                tool_set=tool_set,
                labels=labels,
                reason="auto",
            )

    def load_latest_checkpoint(self, session_id: str) -> dict[str, Any] | None:
        """Return the newest snapshot dict for *session_id* or ``None``."""
        log = self._read_checkpoint_log(session_id)
        if not log:
            return None
        return log[-1]

    def load_checkpoint_history(
        self,
        session_id: str,
        *,
        limit: int | None = None,
    ) -> list[dict[str, Any]]:
        """Return checkpoint history (oldest → newest), optionally capped."""
        log = self._read_checkpoint_log(session_id)
        if limit is not None and limit > 0:
            return log[-limit:]
        return log

    # ── Resume helpers ───────────────────────────────────────────

    def resume(
        self,
        session_id: str,
    ) -> tuple[SessionManifest | None, SessionSnapshot | None]:
        """Load both manifest + latest snapshot for *session_id*.

        Convenience for the chat REPL: one call, both pieces of state.
        Either side may be ``None`` independently — manifest can exist
        without any checkpoint (very fresh session) or vice versa
        (legacy log without manifest).
        """
        manifest_dict = self.get_manifest(session_id)
        manifest: SessionManifest | None = None
        if manifest_dict is not None:
            try:
                manifest = SessionManifest.from_dict(manifest_dict)
            except SchemaVersionMismatch as exc:
                logger.warning(
                    "manifest schema mismatch for %s: %s", session_id, exc,
                )
        snap_dict = self.load_latest_checkpoint(session_id)
        snapshot: SessionSnapshot | None = None
        if snap_dict is not None:
            try:
                snapshot = SessionSnapshot.from_dict(snap_dict)
            except SchemaVersionMismatch as exc:
                logger.warning(
                    "snapshot schema mismatch for %s: %s", session_id, exc,
                )
        return manifest, snapshot

    # ── Internal: checkpoint log ─────────────────────────────────

    def _checkpoint_path(self, session_id: str) -> Path:
        """Filesystem path for the checkpoint log."""
        return Path(self._store._path(_CHECKPOINTS_NS, session_id))  # noqa: SLF001

    def _read_checkpoint_log(self, session_id: str) -> list[dict[str, Any]]:
        """Load the checkpoint log (oldest → newest)."""
        path = self._checkpoint_path(session_id)
        if not path.exists():
            return []
        try:
            with path.open("r", encoding="utf-8") as fh:
                raw = json.load(fh)
        except (OSError, json.JSONDecodeError) as exc:
            logger.warning("failed to read checkpoint log %s: %s", path, exc)
            return []
        if not isinstance(raw, dict):
            return []
        items = raw.get("snapshots")
        if not isinstance(items, list):
            return []
        return [s for s in items if isinstance(s, dict)]

    def _append_checkpoint(self, snapshot: SessionSnapshot) -> None:
        """Append *snapshot* to the per-session log, capped at policy size."""
        existing = self._read_checkpoint_log(snapshot.session_id)
        existing.append(snapshot.to_dict())
        if self.policy.max_history > 0:
            existing = existing[-self.policy.max_history:]
        envelope = {
            "schema": SCHEMA_VERSION,
            "session_id": snapshot.session_id,
            "snapshots": existing,
        }
        # write_flat goes through the same atomic write_atomic path used
        # by the rest of StateStore; use a checkpoint-shaped filename
        # rather than the default sid-keyed path so cleanup tools can
        # spot it.
        path = self._checkpoint_path(snapshot.session_id)
        try:
            path.parent.mkdir(parents=True, exist_ok=True)
            tmp = path.with_suffix(path.suffix + ".tmp")
            with tmp.open("w", encoding="utf-8") as fh:
                json.dump(envelope, fh, ensure_ascii=False, indent=2)
            os.replace(tmp, path)
        except OSError as exc:
            logger.warning("failed to persist checkpoint %s: %s", path, exc)


# ─────────────────────────────────────────────────────────────────
# Internal tracker (timestamps + counters since last write)
# ─────────────────────────────────────────────────────────────────


@dataclass
class _SessionTracker:
    """Per-session in-memory bookkeeping for the policy decision."""

    last_ts: float = 0.0
    last_message_count: int = 0


__all__ = [
    "CheckpointPolicy",
    "SCHEMA_VERSION",
    "SchemaVersionMismatch",
    "SessionManifest",
    "SessionSnapshot",
    "SessionStore",
    "default_session_root",
    "generate_session_id",
]
