"""persona.auto_update -- Sancio (persona-api) self-update.

Mirror of :mod:`concinno.auto_update.tier2_self_update` for the
``persona-api`` PyPI package. Reuses concinno helpers wholesale (PyPI
version fetch, install-method detection, detached helper spawn,
SelfUpdateResult dataclass) and only overrides the package-specific
bits:

* Target package name = ``persona-api`` (not ``concinno``).
* Helper log path = ``~/.sancio/self_update.log`` (POSIX) /
  ``%LOCALAPPDATA%\\sancio\\self_update.log`` (Windows).
* In-use detection scans for ``persona`` / ``sancio`` importing
  processes (not ``concinno``).

The mirror is intentionally thin — see
``_AI_BRAIN/05_Planning/sancio-gui-extension-commander-verdict-2026-04-25.md``
Phase 3 task #9 for the rationale: same Tier 2 architecture, different
package identity.

@module persona.auto_update
@responsibility Re-export concinno's self-update primitives and wrap
    :func:`concinno.auto_update.tier2_self_update.self_update` so the
    persona-api ``sancio self-update`` CLI subcommand can drive
    ``pip install --upgrade persona-api`` from a detached helper.
@dependencies concinno >= 2.36.0 (for Tier 2 auto_update API)
@exports SelfUpdateResult, sancio_self_update,
    detect_pip_install_method, get_latest_pypi_version,
    is_persona_in_use, pip_available
"""

from __future__ import annotations

from .tier2_self_update import (
    SelfUpdateResult,
    detect_pip_install_method,
    get_latest_pypi_version,
    is_persona_in_use,
    pip_available,
    sancio_self_update,
)

__all__ = [
    "SelfUpdateResult",
    "detect_pip_install_method",
    "get_latest_pypi_version",
    "is_persona_in_use",
    "pip_available",
    "sancio_self_update",
]
