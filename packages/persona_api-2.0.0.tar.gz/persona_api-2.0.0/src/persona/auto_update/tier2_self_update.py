"""persona.auto_update.tier2_self_update -- ``sancio self-update`` engine.

Thin mirror of :mod:`concinno.auto_update.tier2_self_update`. The full
architectural rationale (detached helper / file-lock probe / pre-release
filter / editable-install abort) is documented there; this module only
swaps the **package identity** so the same flow drives
``pip install --upgrade persona-api`` instead of ``concinno``.

Why a mirror module instead of a thin one-liner:

* The concinno helper :func:`concinno.auto_update.tier2_self_update.self_update`
  takes ``pkg`` as a kwarg (good — version fetch parameterises), but
  it always logs to ``~/.concinno/self_update.log`` and probes
  ``concinno`` for in-use detection. Both are package-specific and
  hard-coded inside private helpers (``_open_helper_log`` /
  ``_probe_psutil_walk``).
* Rather than monkey-patching concinno internals, we re-implement the
  thin **outer layer** (log path + in-use scan target + spawn glue)
  while delegating every reusable primitive (PyPI fetch, version
  sort, editable detect, pip-method classify, Windows process flags)
  to concinno's public API.

Net effect: ~120 LoC of glue, **zero duplication of policy**. If
concinno's Tier 2 architecture evolves (e.g. new in-use signals,
better pre-release filter), persona-api inherits it the next
``pip install --upgrade concinno``.

@module persona.auto_update.tier2_self_update
@responsibility Drive ``pip install --upgrade persona-api`` from a
    detached helper using concinno's tier2 primitives, with persona-
    specific log path and in-use scan target.
@dependencies concinno.auto_update.tier2_self_update (>= 2.36.0),
    stdlib (subprocess, sys, os, platform, pathlib)
@exports SelfUpdateResult, sancio_self_update,
    detect_pip_install_method, get_latest_pypi_version,
    is_persona_in_use, pip_available
"""

from __future__ import annotations

import os
import platform
import subprocess
import sys
from pathlib import Path

from concinno.auto_update.tier2_self_update import (
    SelfUpdateResult,
    detect_pip_install_method,
    get_latest_pypi_version,
    pip_available,
)
from concinno.auto_update.tier2_self_update import (
    _CREATE_NEW_PROCESS_GROUP,
    _CREATE_NO_WINDOW,
    _DETACHED_PROCESS,
)

# ── Constants ──────────────────────────────────────────────────────

_PKG_NAME = "persona-api"
# Module-import name (different from PyPI distribution name); used for
# in-use detection and version introspection.
_IMPORT_NAME = "persona"
_DEFAULT_TIMEOUT_S = 5


# ── Log path (per-OS, persona-specific) ────────────────────────────


def _sancio_log_dir() -> Path:
    """Return the OS-appropriate Sancio state dir.

    POSIX: ``~/.sancio/``. Windows: ``%LOCALAPPDATA%\\sancio\\`` if the
    env var is set, falling back to ``~/.sancio/`` so test fixtures
    that mock ``Path.home()`` still hit a predictable place.
    """
    if platform.system() == "Windows":
        local_app = os.environ.get("LOCALAPPDATA")
        if local_app:
            return Path(local_app) / "sancio"
    return Path.home() / ".sancio"


def _open_helper_log() -> tuple[Path, "object"]:
    """Open ``<sancio-dir>/self_update.log`` for the helper subprocess."""
    log_dir = _sancio_log_dir()
    log_dir.mkdir(parents=True, exist_ok=True)
    log_path = log_dir / "self_update.log"
    fp = open(log_path, "ab", buffering=0)  # noqa: SIM115 -- intentional
    return log_path, fp


# ── In-use detection (persona-specific target) ─────────────────────


def is_persona_in_use() -> tuple[bool, list[str]]:
    """Detect if other processes are currently importing persona/sancio.

    Mirror of :func:`concinno.auto_update.tier2_self_update.is_concinno_in_use`
    but scans for ``persona`` / ``sancio`` rather than ``concinno`` in
    cmdlines and open files. psutil is optional; fail-soft to
    ``in_use=False`` if not installed.

    Returns ``(in_use, [evidence])``.
    """
    evidence: list[str] = []
    in_use = False

    try:
        import psutil  # type: ignore[import-not-found]
    except ImportError:
        return in_use, evidence

    own_pid = os.getpid()
    try:
        my_persona = Path(__import__(_IMPORT_NAME).__file__).resolve().parent
    except Exception:
        my_persona = None

    for proc in psutil.process_iter(["pid", "name"]):
        try:
            pid = proc.info["pid"]
            if pid == own_pid:
                continue
            name = proc.info.get("name", "?")
            cmdline = " ".join(proc.cmdline() or [])
            cmd_lc = cmdline.lower()
            if _IMPORT_NAME in cmd_lc or "sancio" in cmd_lc:
                evidence.append(
                    f"PID {pid} ({name}): cmdline mentions persona/sancio"
                )
                in_use = True
                continue
            if my_persona is not None:
                in_use_open = _scan_open_files(
                    proc, pid, name, my_persona, evidence, psutil
                )
                if in_use_open:
                    in_use = True
        except (
            psutil.NoSuchProcess,
            psutil.AccessDenied,
            psutil.ZombieProcess,
        ):
            continue

    return in_use, evidence


def _scan_open_files(proc, pid, name, my_persona, evidence, psutil_mod) -> bool:
    """Inner helper: scan one proc's open files for persona path overlap."""
    try:
        open_files = proc.open_files() or []
    except (psutil_mod.AccessDenied, psutil_mod.NoSuchProcess, OSError):
        return False
    target = my_persona.as_posix()
    for f in open_files:
        try:
            if target in Path(f.path).resolve().as_posix():
                evidence.append(
                    f"PID {pid} ({name}): has open handle to {f.path}"
                )
                return True
        except OSError:
            continue
    return False


# ── Detached helper spawn (persona-api pip target) ─────────────────


def _build_pip_argv(target_version: str) -> list[str]:
    """Build the pip invocation upgrading ``persona-api`` to target."""
    return [
        sys.executable,
        "-m",
        "pip",
        "install",
        "--upgrade",
        "--disable-pip-version-check",
        f"{_PKG_NAME}=={target_version}",
    ]


def _spawn_detached(target_version: str) -> tuple[int, str | None]:
    """Spawn the pip helper for persona-api, fully detached.

    Mirror of concinno's ``_spawn_detached`` but logs to the Sancio dir
    on POSIX. On Windows we DEVNULL stdout/stderr (parent exits before
    the helper finishes, so we can't safely keep an inheritable handle).
    """
    argv = _build_pip_argv(target_version)
    is_windows = platform.system() == "Windows"

    if is_windows:
        flags = (
            _DETACHED_PROCESS
            | _CREATE_NEW_PROCESS_GROUP
            | _CREATE_NO_WINDOW
        )
        proc = subprocess.Popen(  # noqa: S603 -- argv constructed safely
            argv,
            stdin=subprocess.DEVNULL,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            creationflags=flags,
            close_fds=True,
        )
        return proc.pid, None

    log_path, log_fp = _open_helper_log()
    try:
        proc = subprocess.Popen(  # noqa: S603 -- argv constructed safely
            argv,
            stdin=subprocess.DEVNULL,
            stdout=log_fp,
            stderr=subprocess.STDOUT,
            start_new_session=True,
            close_fds=True,
        )
        return proc.pid, str(log_path)
    finally:
        log_fp.close()


# ── Main entry point ───────────────────────────────────────────────


def _current_persona_version() -> str:
    """Best-effort read of the installed persona-api version string.

    persona-api's ``persona/__init__.py`` (as of 0.3.0) does not export
    ``__version__``; the canonical source is the package distribution
    metadata. We therefore consult ``importlib.metadata.version`` first
    and only fall back to ``persona.__version__`` for forward
    compatibility (in case a future release adds the dunder).
    """
    try:
        from importlib.metadata import PackageNotFoundError, version

        return version(_PKG_NAME)
    except (PackageNotFoundError, Exception):
        pass
    try:
        import persona  # type: ignore[import-not-found]

        return getattr(persona, "__version__", "unknown")
    except Exception:
        return "unknown"


def sancio_self_update(
    *,
    target_version: str | None = None,
    pre_release: bool = False,
    skip_in_use_check: bool = False,
    dry_run: bool = False,
) -> SelfUpdateResult:
    """Drive the persona-api self-update flow.

    Mirror of :func:`concinno.auto_update.tier2_self_update.self_update`
    but operates on the ``persona-api`` PyPI package, logs to the
    Sancio dir, and probes persona/sancio processes for in-use.

    See :mod:`concinno.auto_update.tier2_self_update` for the
    architecture rationale (detached helper / Windows file-lock /
    editable abort).

    Never raises; all errors flow back via ``SelfUpdateResult.error``.
    """
    current_version = _current_persona_version()
    result = SelfUpdateResult(
        current_version=current_version,
        method=detect_pip_install_method(),
        dry_run=dry_run,
    )

    # 1. Editable install -> abort.
    if result.method == "editable":
        result.error = (
            "editable install detected; self-update would clobber your "
            "working tree. Run `pip install --upgrade persona-api` "
            "manually from outside this checkout."
        )
        return result

    # 2. Resolve target version.
    if target_version is None:
        latest = get_latest_pypi_version(_PKG_NAME, pre_release=pre_release)
        if latest is None:
            result.error = (
                f"failed to fetch latest version from PyPI for {_PKG_NAME}. "
                f"Check network."
            )
            return result
        result.latest_version = latest
        target = latest
    else:
        target = target_version
        result.latest_version = get_latest_pypi_version(
            _PKG_NAME, pre_release=pre_release
        )
    result.target_version = target

    # 3. Already on target -> success without spawn.
    if current_version == target:
        result.error = None
        return result

    # 4. In-use check.
    if not skip_in_use_check:
        in_use, evidence = is_persona_in_use()
        result.in_use_warning = list(evidence)
        if in_use and platform.system() == "Windows":
            result.error = (
                "persona/sancio is in use by another process; close it "
                "(or pass --skip-in-use-check) before self-update on "
                "Windows."
            )
            return result
        # POSIX: warn but continue.

    # 5. Dry-run -> stop before spawn.
    if dry_run:
        return result

    # 6. Spawn detached helper.
    try:
        pid, log_path = _spawn_detached(target)
    except OSError as exc:
        result.error = f"failed to spawn pip helper: {exc}"
        return result

    result.helper_spawned = True
    result.helper_pid = pid
    result.log_path = log_path
    return result


__all__ = [
    "SelfUpdateResult",
    "detect_pip_install_method",
    "get_latest_pypi_version",
    "is_persona_in_use",
    "pip_available",
    "sancio_self_update",
]
