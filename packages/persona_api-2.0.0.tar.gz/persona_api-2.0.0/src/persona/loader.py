"""Persona Markdown loader — mirrors psyche-engine persona-parser.ts.

Reads persona.md files (innate/experience sections) and extracts:
- OCEAN scores [O,C,E,A,N] 0-1
- Identity (name, age, gender, nationality, etc.)
- Communication style, behavior rules, spike words
- Locked values, narrative
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path

_OCEAN_DIM_COUNT = 5
_PAD_DIM_COUNT = 3

# Patterns for CJK key-value (fullwidth colon is intentional)
_KV_COLON = "\uff1a:"  # noqa: RUF001  — fullwidth colon intentional for CJK
_CJK_COMMA = "\u3001\uff0c,"  # noqa: RUF001


@dataclass
class PersonaIdentity:
    """Core identity fields parsed from persona markdown."""

    name: str = ""
    age: str = ""
    gender: str = ""
    nationality: str = ""
    mbti: str = ""
    language: str = ""
    appearance: str = ""


@dataclass
class PersonaData:
    """Structured persona extracted from markdown."""

    identity: PersonaIdentity = field(
        default_factory=PersonaIdentity,
    )
    ocean: list[float] = field(
        default_factory=lambda: [0.5] * _OCEAN_DIM_COUNT,
    )
    mood_baseline: list[float] = field(
        default_factory=lambda: [0.0] * _PAD_DIM_COUNT,
    )
    narrative: str = ""
    communication_style: str = ""
    locked_values: list[str] = field(default_factory=list)
    spike_words: list[str] = field(default_factory=list)
    relationship_attitudes: str = ""
    raw_text: str = ""

    @property
    def ocean_labels(self) -> dict[str, float]:
        """Map OCEAN dimension names to scores."""
        dims = [
            "Openness",
            "Conscientiousness",
            "Extraversion",
            "Agreeableness",
            "Neuroticism",
        ]
        return dict(zip(dims, self.ocean, strict=True))


# ── Helpers ─────────────────────────────────────


def _kv(text: str, key: str) -> str:
    m = re.search(rf"{key}[{_KV_COLON}]\s*(.+)", text)
    return m.group(1).strip() if m else ""


def _list_items(text: str) -> list[str]:
    return [
        m.strip()
        for m in re.findall(r"^-\s+(.+)$", text, re.MULTILINE)
    ]


def _split_sections(
    text: str, level: str = "##",
) -> dict[str, str]:
    """Split markdown by heading level into {title: body}."""
    pattern = rf"^{re.escape(level)}\s+"
    parts = re.split(pattern, text, flags=re.MULTILINE)
    sections: dict[str, str] = {}
    for part in parts[1:]:
        nl = part.find("\n")
        if nl < 0:
            continue
        title = part[:nl].strip()
        body = part[nl + 1:]
        sections[title] = body
    return sections


def _find_key(
    sections: dict[str, str], substr: str,
) -> str | None:
    for k in sections:
        if substr in k:
            return k
    return None


# ── Main loader ─────────────────────────────────


def load_persona_md(path: str | Path) -> PersonaData:
    """Load a persona.md file into PersonaData."""
    path = Path(path)
    if not path.exists():
        msg = f"Persona file not found: {path}"
        raise FileNotFoundError(msg)

    text = path.read_text(encoding="utf-8")
    return parse_persona_text(text)


def parse_persona_text(text: str) -> PersonaData:
    """Parse raw persona markdown text into PersonaData."""
    data = PersonaData(raw_text=text)

    sections = _split_sections(text, "##")

    innate_key = _find_key(sections, "\u672c\u80fd\u51fd\u6578")
    if innate_key:
        _parse_innate(sections[innate_key], data)

    exp_key = _find_key(sections, "\u7d93\u9a57\u51fd\u6578")
    if exp_key:
        _parse_experience(sections[exp_key], data)

    if not innate_key and not exp_key:
        _parse_flat_persona(text, data)

    return data


# ── Section parsers ─────────────────────────────


def _parse_ocean(subs: dict[str, str], data: PersonaData) -> None:
    ocean_key = (
        _find_key(subs, "OCEAN")
        or _find_key(subs, "\u4eba\u683c\u57fa\u56e0")
    )
    if not ocean_key:
        return
    t = subs[ocean_key]
    ocean: list[float] = []
    for dim in ["O", "C", "E", "A", "N"]:
        m = re.search(rf"{dim}[{_KV_COLON}]\s*([\d.]+)", t)
        ocean.append(float(m.group(1)) if m else 0.5)
    if len(ocean) == _OCEAN_DIM_COUNT:
        data.ocean = ocean


def _parse_pad(subs: dict[str, str], data: PersonaData) -> None:
    pad_key = (
        _find_key(subs, "PAD")
        or _find_key(subs, "\u60c5\u7dd2\u57fa\u7dda")
    )
    if not pad_key:
        return
    t = subs[pad_key]
    pad: list[float] = []
    for dim in ["V", "A", "D"]:
        m = re.search(rf"{dim}[{_KV_COLON}]\s*([-\d.]+)", t)
        pad.append(float(m.group(1)) if m else 0.0)
    if len(pad) == _PAD_DIM_COUNT:
        data.mood_baseline = pad


def _parse_innate(text: str, data: PersonaData) -> None:
    subs = _split_sections(text, "###")

    _parse_ocean(subs, data)
    _parse_pad(subs, data)

    if "\u6838\u5fc3\u8eab\u4efd" in subs:
        t = subs["\u6838\u5fc3\u8eab\u4efd"]
        data.identity = PersonaIdentity(
            name=_kv(t, "\u540d\u5b57"),
            age=_kv(t, "\u5e74\u9f61"),
            gender=_kv(t, "\u6027\u5225"),
            nationality=_kv(t, "\u570b\u7c4d"),
            mbti=_kv(t, "MBTI"),
            language=_kv(t, "\u8a9e\u8a00"),
            appearance=_kv(t, "\u5916\u8c8c"),
        )

    if "\u8eab\u4efd\u6558\u4e8b" in subs:
        data.narrative = subs["\u8eab\u4efd\u6558\u4e8b"].strip()

    spike_key = _find_key(subs, "\u89f8\u767c\u8a5e")
    if spike_key:
        data.spike_words = _list_items(subs[spike_key])

    locked_key = (
        _find_key(subs, "\u786c\u6838")
        or _find_key(subs, "locked")
    )
    if locked_key:
        data.locked_values = [
            line.strip()
            for line in re.findall(
                r"^K\d+.+$", subs[locked_key], re.MULTILINE,
            )
        ]


def _parse_experience(text: str, data: PersonaData) -> None:
    subs = _split_sections(text, "###")

    if "\u6e9d\u901a\u98a8\u683c" in subs:
        data.communication_style = subs["\u6e9d\u901a\u98a8\u683c"].strip()

    if "\u95dc\u4fc2\u614b\u5ea6" in subs:
        data.relationship_attitudes = subs["\u95dc\u4fc2\u614b\u5ea6"].strip()


def _parse_flat_persona(text: str, data: PersonaData) -> None:
    """Parse flat persona text (JP/CN style without sections)."""
    # noqa: RUF001 — CJK punctuation is intentional
    name_m = re.search(
        r"\u79c1\u306f(.+?)[" + _CJK_COMMA + "]", text,  # noqa: RUF001
    )
    if name_m:
        data.identity.name = name_m.group(1)

    age_m = re.search(r"(\d+)[\u6b73\u6b72]", text)
    if age_m:
        data.identity.age = age_m.group(1)

    data.narrative = text.strip()
