"""``write_file`` tool — overwrite a file with new content (A2)."""

from __future__ import annotations

from pathlib import Path
from typing import Any

from .base import function_schema, resolve_sandboxed


class WriteFileTool:
    """Create or overwrite ``path`` with ``content`` (UTF-8)."""

    name = "write_file"

    def __init__(self, root: Path | None = None) -> None:
        self._root = root

    def schema(self) -> dict[str, Any]:
        return function_schema(
            name=self.name,
            description=(
                "Write UTF-8 text to a file, creating parents if needed. "
                "Overwrites silently — use edit_file for targeted patches."
            ),
            properties={
                "path": {"type": "string"},
                "content": {"type": "string"},
            },
            required=["path", "content"],
        )

    async def execute(self, args: dict[str, Any]) -> str:
        path = resolve_sandboxed(self._root, args["path"])
        path.parent.mkdir(parents=True, exist_ok=True)
        content = args["content"]
        path.write_text(content, encoding="utf-8")
        return f"wrote {len(content)} chars to {path}"
