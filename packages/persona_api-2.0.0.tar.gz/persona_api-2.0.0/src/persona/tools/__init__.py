"""Aegis agent tool registry (A2, v3 roadmap).

Each tool conforms to the :class:`persona.engine.agent_loop.Tool`
protocol. :func:`default_tools` assembles the seven stock tools with
an optional shared sandbox root — callers that want a subset can
pick by name.

Hook slots (Pre/PostToolUse) live on :class:`AgentLoop`, not here.
Guards plug in via A3; this package stays infrastructure-only.
"""

from __future__ import annotations

import os
from pathlib import Path

from .base import function_schema, resolve_sandboxed
from .date_calc import DateCalcTool
from .edit_file import EditFileTool
from .fetch_image import FetchImageTool
from .fetch_url import FetchUrlTool
from .fetch_wikipedia_section import FetchWikipediaSectionTool
from .get_diagnostics import GetDiagnosticsTool
from .list_files import ListFilesTool
from .python_exec import PythonExecTool
from .read_attachment import ReadAttachmentTool
from .read_file import ReadFileTool
from .run_bash import RunBashTool
from .search_files import SearchFilesTool
from .web_search import WebSearchTool
from .web_search_ddg import WebSearchTool as _WebSearchDDG
from .write_file import WriteFileTool


def _web_search_tool() -> object | None:
    """Dispatch to the WebSearch backend, or return ``None`` when disabled.

    ``SANCIO_DISABLE_WEB_SEARCH=1`` — drop the tool entirely so the
    agent registry shrinks from 14 → 13. Per user 2026-04-25 part-H
    directive: Anthropic web_search is paid + rate-limited and most
    GAIA tasks can route through ``fetch_wikipedia`` / ``fetch_url`` /
    ``python_exec`` / ``run_bash`` instead.

    ``SANCIO_WEB_SEARCH_BACKEND``:
    ``anthropic`` (default) — Concinno WebSearchTool (paid Claude summariser).
    ``duckduckgo`` — DDG raw results, zero cost; P0#6c GAIA ablation.
    """
    if os.environ.get(
        "SANCIO_DISABLE_WEB_SEARCH", "0",
    ).strip().lower() in ("1", "true", "yes"):
        return None
    backend = os.environ.get(
        "SANCIO_WEB_SEARCH_BACKEND", "anthropic",
    ).strip().lower()
    if backend == "duckduckgo":
        return _WebSearchDDG()
    return WebSearchTool()


def default_tools(root: Path | None = None) -> dict[str, object]:
    """Return the stock tool roster keyed by ``name``.

    ``root`` is forwarded to every filesystem-aware tool. ``run_bash``
    receives it as ``cwd`` so subprocess calls honour the same
    sandbox by default. Network tools (``web_search``, ``fetch_url``)
    and pure-computation tools (``date_calc``, ``python_exec``)
    ignore ``root`` — they either touch remote services or stay
    entirely in-process.
    """
    _ws = _web_search_tool()
    tools: list[object] = [
        ReadFileTool(root=root),
        ReadAttachmentTool(root=root),
        WriteFileTool(root=root),
        EditFileTool(root=root),
        ListFilesTool(root=root),
        SearchFilesTool(root=root),
        RunBashTool(cwd=root),
        GetDiagnosticsTool(root=root),
        *([_ws] if _ws is not None else []),
        FetchUrlTool(),
        FetchWikipediaSectionTool(),
        FetchImageTool(),
        DateCalcTool(),
        PythonExecTool(),
    ]
    return {t.name: t for t in tools}  # type: ignore[attr-defined]


__all__ = [
    "DateCalcTool",
    "EditFileTool",
    "FetchUrlTool",
    "FetchWikipediaSectionTool",
    "GetDiagnosticsTool",
    "ListFilesTool",
    "PythonExecTool",
    "ReadAttachmentTool",
    "ReadFileTool",
    "RunBashTool",
    "SearchFilesTool",
    "WebSearchTool",
    "WriteFileTool",
    "default_tools",
    "function_schema",
    "resolve_sandboxed",
]
