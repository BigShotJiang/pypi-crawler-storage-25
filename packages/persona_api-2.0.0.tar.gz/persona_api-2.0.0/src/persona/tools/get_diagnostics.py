"""``get_diagnostics`` tool — ruff-based static diagnostics (A2).

Minimal implementation: shells out to ``ruff check --output-format=json``
so Aegis benchmarks get a lightweight lint signal without pulling in
a full LSP client. Returns an empty list when ruff is absent — the
tool never crashes the loop on missing infrastructure.
"""

from __future__ import annotations

import asyncio
import json
import shutil
from pathlib import Path
from typing import Any

from .base import function_schema, resolve_sandboxed


class GetDiagnosticsTool:
    """Run ruff against a path and return parsed diagnostics."""

    name = "get_diagnostics"

    def __init__(self, root: Path | None = None) -> None:
        self._root = root

    def schema(self) -> dict[str, Any]:
        return function_schema(
            name=self.name,
            description=(
                "Return static-analysis diagnostics for a file or "
                "directory (ruff-backed)."
            ),
            properties={
                "path": {"type": "string", "description": "Target path."},
            },
            required=["path"],
        )

    async def execute(self, args: dict[str, Any]) -> dict[str, Any]:
        path = resolve_sandboxed(self._root, args["path"])
        ruff_bin = shutil.which("ruff")
        if ruff_bin is None:
            return {"diagnostics": [], "note": "ruff not installed"}

        proc = await asyncio.create_subprocess_exec(
            ruff_bin,
            "check",
            "--output-format=json",
            str(path),
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        out, _err = await proc.communicate()
        try:
            diagnostics = json.loads(out.decode("utf-8") or "[]")
        except json.JSONDecodeError:
            diagnostics = []
        return {"diagnostics": diagnostics, "count": len(diagnostics)}
