"""``list_files`` tool — glob listing (A2)."""

from __future__ import annotations

from pathlib import Path
from typing import Any

from .base import function_schema, resolve_sandboxed


class ListFilesTool:
    """List entries in a directory, optionally filtered by glob pattern."""

    name = "list_files"

    def __init__(self, root: Path | None = None) -> None:
        self._root = root

    def schema(self) -> dict[str, Any]:
        return function_schema(
            name=self.name,
            description="List files in a directory. Accepts glob patterns.",
            properties={
                "path": {
                    "type": "string",
                    "description": "Directory (default '.').",
                },
                "pattern": {
                    "type": "string",
                    "description": "Glob pattern e.g. '**/*.py'.",
                },
                "limit": {
                    "type": "integer",
                    "description": "Max entries returned (default 500).",
                },
            },
            required=[],
        )

    async def execute(self, args: dict[str, Any]) -> list[str]:
        path_str = args.get("path") or "."
        directory = resolve_sandboxed(self._root, path_str)
        pattern = args.get("pattern")
        limit = int(args.get("limit") or 500)

        if pattern:
            entries = sorted(str(p) for p in directory.glob(pattern))
        else:
            entries = sorted(str(p) for p in directory.iterdir())
        return entries[:limit]
