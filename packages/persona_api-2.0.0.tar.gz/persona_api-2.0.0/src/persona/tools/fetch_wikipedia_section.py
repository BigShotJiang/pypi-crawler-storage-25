"""``fetch_wikipedia_section`` tool — Sancio async adapter.

Positioning
-----------
Wraps :class:`concinno.tools.builtin.wiki.FetchWikipediaSectionTool`
so the Sancio agent loop can expose it alongside
``web_search`` / ``fetch_url`` / ``fetch_image``.

Why it exists
-------------
Multi-step Wikipedia lookups ("find URL → fetch_url → locate section
→ count") bankrupt weak models. This tool collapses the sequence
into one call: ``fetch_wikipedia_section(subject, section)``. See
the Concinno module docstring for the failure-mode context
(GAIA #7 Mercedes Sosa 23k-char reasoning loop).

Bridging rule
-------------
Concinno's FetchWikipediaSectionTool is sync (httpx.Client). Sancio
needs async; we delegate via :func:`asyncio.to_thread` so the
blocking network I/O does not stall the event loop (same pattern as
:mod:`persona.tools.fetch_url`).
"""

from __future__ import annotations

import asyncio
from typing import Any

from concinno.tools.builtin.wiki import (
    FetchWikipediaSectionTool as _ConcinnoWiki,
)

from .base import function_schema


class FetchWikipediaSectionTool:
    """Async adapter exposing Concinno's wiki tool to Sancio."""

    name = "fetch_wikipedia_section"

    def __init__(self, **kwargs: Any) -> None:
        self._impl = _ConcinnoWiki(**kwargs)

    def schema(self) -> dict[str, Any]:
        return function_schema(
            name=self.name,
            description=self._impl.description,
            properties={
                "subject": {
                    "type": "string",
                    "description": (
                        "English Wikipedia article title, e.g. "
                        "'Mercedes Sosa'."
                    ),
                },
                "section": {
                    "type": "string",
                    "description": (
                        "Section header text, e.g. 'Studio albums', "
                        "'Bibliography'. Matched case-insensitive."
                    ),
                },
            },
            required=["subject", "section"],
        )

    async def execute(self, args: dict[str, Any]) -> str:
        return await asyncio.to_thread(
            self._impl.call,
            subject=args.get("subject", ""),
            section=args.get("section", ""),
        )
