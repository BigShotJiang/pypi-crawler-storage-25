"""``run_bash`` tool — subprocess shell execution with timeout (A2)."""

from __future__ import annotations

import asyncio
import shlex
from pathlib import Path
from typing import Any

from .base import function_schema


class RunBashTool:
    """Execute a shell command and return stdout/stderr/exit_code.

    Not a security boundary — Aegis Guards (A3 PreToolUseHook) and
    permission DSL (A4) are responsible for vetting the command
    string before this tool runs. Default timeout is 60 s; pass
    ``timeout`` to override.
    """

    name = "run_bash"

    def __init__(
        self,
        cwd: Path | None = None,
        default_timeout: float = 60.0,
    ) -> None:
        self._cwd = cwd
        self._default_timeout = default_timeout

    def schema(self) -> dict[str, Any]:
        return function_schema(
            name=self.name,
            description=(
                "Run a shell command. Returns stdout, stderr, and "
                "exit_code. Default timeout 60 s."
            ),
            properties={
                "cmd": {
                    "type": "string",
                    "description": "Shell command line.",
                },
                "timeout": {
                    "type": "number",
                    "description": "Seconds before kill.",
                },
            },
            required=["cmd"],
        )

    async def execute(self, args: dict[str, Any]) -> dict[str, Any]:
        cmd = args["cmd"]
        timeout = float(args.get("timeout") or self._default_timeout)

        proc = await asyncio.create_subprocess_shell(
            cmd,
            cwd=str(self._cwd) if self._cwd else None,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        try:
            out, err = await asyncio.wait_for(
                proc.communicate(), timeout=timeout,
            )
        except asyncio.TimeoutError:
            proc.kill()
            await proc.wait()
            return {
                "stdout": "",
                "stderr": f"timeout after {timeout}s",
                "exit_code": -1,
                "cmd": shlex.split(cmd, posix=False)[0] if cmd else "",
            }
        return {
            "stdout": out.decode("utf-8", errors="replace"),
            "stderr": err.decode("utf-8", errors="replace"),
            "exit_code": proc.returncode or 0,
        }
