"""``date_calc`` tool — Sancio async adapter over Concinno impl.

The real implementation (``DateCalcTool`` — strict strptime, no
natural-language parsing, calendar-accurate year/month/day
breakdowns) lives in :mod:`concinno.tools.builtin.date_calc`. Sancio
keeps this thin adapter so the agent loop keeps the async
``execute(args)`` + ``schema()`` shape without duplicating the
Concinno logic.

Bridging rule
-------------
Concinno's Tool protocol is sync ``call(**kwargs)``. Sancio's
``AgentLoop`` needs async. :func:`asyncio.to_thread` is used for
parity with the other adapters in this package; the actual
``DateCalcTool`` is CPU-only and returns in microseconds so the
thread-offload is strictly protocol shaping, not a latency concern.
"""

from __future__ import annotations

import asyncio
from typing import Any

from concinno.tools.builtin.date_calc import DateCalcTool as _ConcinnoDateCalc

from .base import function_schema


class DateCalcTool:
    """Async adapter exposing Concinno's DateCalcTool to Sancio."""

    name = "date_calc"

    def __init__(self, **kwargs: Any) -> None:
        self._impl = _ConcinnoDateCalc(**kwargs)

    def schema(self) -> dict[str, Any]:
        return function_schema(
            name=self.name,
            description=self._impl.description,
            properties={
                "op": {
                    "type": "string",
                    "enum": ["delta", "parse", "format"],
                    "description": (
                        "Operation. delta: days between two dates. "
                        "parse: parse to ISO 8601. format: reformat "
                        "an existing date."
                    ),
                },
                "date_from": {
                    "type": "string",
                    "description": "Start date (for delta).",
                },
                "date_to": {
                    "type": "string",
                    "description": "End date (for delta).",
                },
                "date_str": {
                    "type": "string",
                    "description": "Date string (for parse / format).",
                },
                "format_str": {
                    "type": "string",
                    "description": (
                        "strptime / strftime format string. Required "
                        "for parse and format; optional for delta "
                        "(defaults to ISO YYYY-MM-DD)."
                    ),
                },
            },
            required=["op"],
        )

    async def execute(self, args: dict[str, Any]) -> str:
        return await asyncio.to_thread(
            self._impl.call,
            op=args.get("op", ""),
            date_from=args.get("date_from"),
            date_to=args.get("date_to"),
            date_str=args.get("date_str"),
            format_str=args.get("format_str"),
        )
