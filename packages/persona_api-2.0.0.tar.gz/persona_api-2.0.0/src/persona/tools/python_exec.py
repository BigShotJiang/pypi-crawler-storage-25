"""``python_exec`` tool — Sancio async adapter over Concinno impl.

The real implementation (``PythonExecTool`` — AST whitelist +
builtin whitelist + source/node size caps) lives in
:mod:`concinno.tools.builtin.python_exec`. Sancio keeps this thin
adapter so the agent loop keeps the async ``execute(args)`` +
``schema()`` shape without duplicating the sandbox logic.

Security posture is inherited verbatim from Concinno — do NOT
patch around the whitelist here. If the GAIA/benchmark agent needs
a capability this tool does not allow, the right fix is either a
new Concinno tool (not a sandbox exception) or a widening of the
Concinno whitelist after explicit review.
"""

from __future__ import annotations

import asyncio
from typing import Any

from concinno.tools.builtin.python_exec import (
    PythonExecTool as _ConcinnoPythonExec,
)

from .base import function_schema


class PythonExecTool:
    """Async adapter exposing Concinno's PythonExecTool to Sancio."""

    name = "python_exec"

    def __init__(self, **kwargs: Any) -> None:
        self._impl = _ConcinnoPythonExec(**kwargs)

    def schema(self) -> dict[str, Any]:
        return function_schema(
            name=self.name,
            description=self._impl.description,
            properties={
                "code": {
                    "type": "string",
                    "description": (
                        "A single Python expression. No statements, "
                        "no import, no attribute access, no lambda. "
                        "Result is str()-ified before return."
                    ),
                },
            },
            required=["code"],
        )

    async def execute(self, args: dict[str, Any]) -> str:
        return await asyncio.to_thread(
            self._impl.call, code=args.get("code", ""),
        )
