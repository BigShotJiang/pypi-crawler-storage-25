"""``fetch_image`` tool — Sancio async adapter over Concinno impl.

Positioning
-----------
Concinno's :class:`concinno.tools.builtin.fetch_image.FetchImageTool`
downloads a single image URL and returns a marker-delimited base64
string (``__CONCINNO_IMAGE_B64__ … __CONCINNO_END_IMAGE__``). The
OpenAI-compat provider rewrites the marker into a proper
``{type:"image_url","image_url":{"url":"data:…"}}`` block the next
time it materializes a request, so a vision-capable model
(Gemma 4 26B, GPT-4o, Claude 3.5+) actually sees the image on the
next inference turn.

Sancio keeps this file as a thin async wrapper so the agent loop
continues to consume the ``execute(args)`` + ``schema()`` shape
without duplicating logic.
"""

from __future__ import annotations

import asyncio
from typing import Any

from concinno.tools.builtin.fetch_image import (
    FetchImageTool as _ConcinnoFetchImage,
)

from .base import function_schema


class FetchImageTool:
    """Async adapter exposing Concinno's FetchImageTool to Sancio."""

    name = "fetch_image"

    def __init__(self, **kwargs: Any) -> None:
        self._impl = _ConcinnoFetchImage(**kwargs)

    def schema(self) -> dict[str, Any]:
        return function_schema(
            name=self.name,
            description=self._impl.description,
            properties={
                "url": {
                    "type": "string",
                    "description": (
                        "Absolute http(s) URL of the image to download. "
                        "Use this when the question requires visual "
                        "inspection (identifying something in a photo, "
                        "reading a headstone inscription, etc). The image "
                        "is passed inline to the next inference turn so "
                        "the vision-capable model can actually see it."
                    ),
                },
            },
            required=["url"],
        )

    async def execute(self, args: dict[str, Any]) -> str:
        return await asyncio.to_thread(
            self._impl.call, url=args.get("url", ""),
        )
