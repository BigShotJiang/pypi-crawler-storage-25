"""``fetch_url`` tool — Sancio async adapter over Concinno impl.

Positioning
-----------
The real implementation (httpx.Client, HTML strip, size cap) lives
in :mod:`concinno.tools.builtin.web`. Sancio retains this file as a
thin async wrapper so the agent loop continues to consume the
``execute(args)`` + ``schema()`` shape without duplicating logic.

Bridging rule
-------------
Concinno's FetchUrlTool is sync (uses ``httpx.Client``) to conform
to Concinno's Tool protocol. Sancio needs async; we delegate via
:func:`asyncio.to_thread` so blocking network I/O doesn't stall the
event loop.
"""

from __future__ import annotations

import asyncio
from typing import Any

from concinno.tools.builtin.web import FetchUrlTool as _ConcinnoFetchUrl

from .base import function_schema


class FetchUrlTool:
    """Async adapter exposing Concinno's FetchUrlTool to Sancio."""

    name = "fetch_url"

    def __init__(self, **kwargs: Any) -> None:
        self._impl = _ConcinnoFetchUrl(**kwargs)

    def schema(self) -> dict[str, Any]:
        return function_schema(
            name=self.name,
            description=self._impl.description,
            properties={
                "url": {
                    "type": "string",
                    "description": "Absolute http(s) URL to fetch.",
                },
            },
            required=["url"],
        )

    async def execute(self, args: dict[str, Any]) -> str:
        return await asyncio.to_thread(
            self._impl.call, url=args.get("url", ""),
        )
