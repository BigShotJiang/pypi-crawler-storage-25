"""``search_files`` tool — regex content search (A2)."""

from __future__ import annotations

import re
from pathlib import Path
from typing import Any

from .base import function_schema, resolve_sandboxed


class SearchFilesTool:
    """Grep-style regex search across files under a directory.

    Implemented in pure Python so the tool works on the Aegis Docker
    image without a ripgrep dependency. Performance is fine for
    benchmark-sized working dirs; swap for ``rg`` subprocess later
    if a big-repo target needs it.
    """

    name = "search_files"

    def __init__(self, root: Path | None = None) -> None:
        self._root = root

    def schema(self) -> dict[str, Any]:
        return function_schema(
            name=self.name,
            description=(
                "Regex search across files under a directory. Returns "
                "list of {path, line, text} matches."
            ),
            properties={
                "pattern": {"type": "string", "description": "Python regex."},
                "path": {
                    "type": "string",
                    "description": "Search root (default '.').",
                },
                "glob": {
                    "type": "string",
                    "description": "Optional glob filter e.g. '**/*.py'.",
                },
                "limit": {
                    "type": "integer",
                    "description": "Max matches returned (default 200).",
                },
            },
            required=["pattern"],
        )

    async def execute(self, args: dict[str, Any]) -> list[dict[str, Any]]:
        pattern = re.compile(args["pattern"])
        path_str = args.get("path") or "."
        directory = resolve_sandboxed(self._root, path_str)
        glob = args.get("glob") or "**/*"
        limit = int(args.get("limit") or 200)

        results: list[dict[str, Any]] = []
        for path in directory.glob(glob):
            if not path.is_file():
                continue
            try:
                text = path.read_text(encoding="utf-8", errors="replace")
            except OSError:
                continue
            for lineno, line in enumerate(text.splitlines(), start=1):
                if pattern.search(line):
                    results.append({
                        "path": str(path),
                        "line": lineno,
                        "text": line,
                    })
                    if len(results) >= limit:
                        return results
        return results
