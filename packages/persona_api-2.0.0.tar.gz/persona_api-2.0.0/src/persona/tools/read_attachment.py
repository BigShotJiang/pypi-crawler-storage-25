"""``read_attachment`` tool — Sancio async adapter over Concinno impl.

The real implementation (format-aware file reader: xlsx / csv /
plain-text dispatch, binary sniff on unknown suffixes) lives in
:mod:`concinno.tools.builtin.read_attachment`. Sancio keeps this
thin adapter so the agent loop keeps the async ``execute(args)`` +
``schema()`` shape without duplicating the dispatch logic.

This tool *complements* :class:`ReadFileTool` — that one only
returns UTF-8 text and therefore chokes on xlsx/binary. Both
tools coexist in the registry so the model can pick the right
one based on the attachment hint the runner injects in the
user message.
"""

from __future__ import annotations

import asyncio
from pathlib import Path
from typing import Any

from concinno.tools.builtin.read_attachment import (
    ReadAttachmentTool as _ConcinnoReadAttachment,
)

from .base import function_schema


class ReadAttachmentTool:
    """Async adapter exposing Concinno's ReadAttachmentTool to Sancio."""

    name = "read_attachment"

    def __init__(self, root: Path | None = None, **kwargs: Any) -> None:
        # ``root`` is accepted to match the ReadFileTool signature in the
        # tool registry; the Concinno impl already sandboxes by absolute
        # path validation so the argument is intentionally unused here.
        _ = root
        self._impl = _ConcinnoReadAttachment(**kwargs)

    def schema(self) -> dict[str, Any]:
        return function_schema(
            name=self.name,
            description=self._impl.description,
            properties={
                "path": {
                    "type": "string",
                    "description": (
                        "Absolute path to the attachment file. Use "
                        "this tool for xlsx/xlsm/csv spreadsheets, "
                        "or any attachment where the binary content "
                        "is not plain UTF-8 text. For plain text "
                        "files the regular read_file tool also works."
                    ),
                },
            },
            required=["path"],
        )

    async def execute(self, args: dict[str, Any]) -> str:
        return await asyncio.to_thread(
            self._impl.call, path=args.get("path", ""),
        )
