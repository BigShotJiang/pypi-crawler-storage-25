"""``edit_file`` tool — exact string replacement patch (A2)."""

from __future__ import annotations

from pathlib import Path
from typing import Any

from .base import function_schema, resolve_sandboxed


class EditFileTool:
    """Replace ``old_string`` with ``new_string`` inside ``path``.

    Mirrors Claude Code's Edit tool semantics: the match must be
    unique unless ``replace_all=True``. Returning an error string
    instead of raising keeps the LLM in the loop — it can decide
    whether to widen the match or give up.
    """

    name = "edit_file"

    def __init__(self, root: Path | None = None) -> None:
        self._root = root

    def schema(self) -> dict[str, Any]:
        return function_schema(
            name=self.name,
            description=(
                "Exact-string replacement in a file. Match must be "
                "unique unless replace_all is true."
            ),
            properties={
                "path": {"type": "string"},
                "old_string": {"type": "string"},
                "new_string": {"type": "string"},
                "replace_all": {"type": "boolean"},
            },
            required=["path", "old_string", "new_string"],
        )

    async def execute(self, args: dict[str, Any]) -> str:
        path = resolve_sandboxed(self._root, args["path"])
        old = args["old_string"]
        new = args["new_string"]
        replace_all = bool(args.get("replace_all", False))

        original = path.read_text(encoding="utf-8")
        occurrences = original.count(old)
        if occurrences == 0:
            return f"error: old_string not found in {path.name}"
        if occurrences > 1 and not replace_all:
            return (
                f"error: old_string matches {occurrences} places in "
                f"{path.name}; set replace_all=true or add context"
            )

        patched = (
            original.replace(old, new)
            if replace_all
            else original.replace(old, new, 1)
        )
        path.write_text(patched, encoding="utf-8")
        return f"replaced {occurrences if replace_all else 1} in {path.name}"
