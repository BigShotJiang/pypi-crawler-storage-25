"""``web_search`` tool — Sancio async adapter over Concinno impl.

Positioning
-----------
The tool's real implementation (anthropic WebSearch proxy + output
capping + lazy client construction) lives in
:mod:`concinno.tools.builtin.web` — the canonical location for
network-read tools in the Concinno library. Sancio keeps this thin
adapter so its agent loop keeps seeing the async
``execute(args)`` + ``schema()`` shape it was built around, without
duplicating the Concinno logic.

Bridging rule
-------------
Concinno's Tool protocol is sync ``call(**kwargs)``. Sancio's
``AgentLoop`` needs async. We delegate via :func:`asyncio.to_thread`
so the underlying blocking anthropic SDK call doesn't stall the
event loop. Any future tuning (retries, caching, telemetry) should
land in Concinno once — both Concinno's direct consumers and
Sancio's agent loop pick it up.
"""

from __future__ import annotations

import asyncio
from typing import Any

from concinno.tools.builtin.web import WebSearchTool as _ConcinnoWebSearch

from .base import function_schema


class WebSearchTool:
    """Async adapter exposing Concinno's WebSearchTool to Sancio."""

    name = "web_search"

    def __init__(self, **kwargs: Any) -> None:
        self._impl = _ConcinnoWebSearch(**kwargs)

    def schema(self) -> dict[str, Any]:
        return function_schema(
            name=self.name,
            description=self._impl.description,
            properties={
                "query": {
                    "type": "string",
                    "description": "Search query in natural language.",
                },
            },
            required=["query"],
        )

    async def execute(self, args: dict[str, Any]) -> str:
        return await asyncio.to_thread(
            self._impl.call, query=args.get("query", ""),
        )
