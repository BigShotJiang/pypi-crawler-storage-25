"""``read_file`` tool — dump a file's text (A2)."""

from __future__ import annotations

from pathlib import Path
from typing import Any

from .base import function_schema, resolve_sandboxed


class ReadFileTool:
    """Return the text content of ``path`` (optionally sliced)."""

    name = "read_file"

    def __init__(self, root: Path | None = None) -> None:
        self._root = root

    def schema(self) -> dict[str, Any]:
        return function_schema(
            name=self.name,
            description="Read a UTF-8 text file. Optional line slicing.",
            properties={
                "path": {"type": "string", "description": "File path."},
                "offset": {
                    "type": "integer",
                    "description": "1-based first line to return.",
                },
                "limit": {
                    "type": "integer",
                    "description": "Max lines returned (default 2000).",
                },
            },
            required=["path"],
        )

    async def execute(self, args: dict[str, Any]) -> str:
        path = resolve_sandboxed(self._root, args["path"])
        text = path.read_text(encoding="utf-8", errors="replace")
        offset = int(args.get("offset") or 1)
        limit = int(args.get("limit") or 2000)
        if offset <= 1 and limit >= 2000 and text.count("\n") < limit:
            return text
        lines = text.splitlines(keepends=True)
        start = max(0, offset - 1)
        return "".join(lines[start : start + limit])
