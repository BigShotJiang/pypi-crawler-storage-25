"""Shared helpers for tool implementations (A2, v3 roadmap).

Every tool in this package conforms to the
:class:`persona.engine.agent_loop.Tool` protocol (``name`` attr +
``schema()`` + ``async execute()``). This module hosts the bits they
share — path sandboxing and a tiny OpenAI function-schema helper —
so each tool file stays focused on its own logic.

Sandbox rule
------------
Every filesystem tool accepts an optional ``root`` constructor
argument. When ``root`` is set, :func:`resolve_sandboxed` forces all
paths to resolve inside the root and rejects ``..`` escapes. When
``root`` is ``None`` the tool runs unsandboxed — suitable for local
scripts, unsafe for untrusted prompts. Aegis policy DSL (A4) is the
authoritative boundary; this helper is just the file-layer seatbelt.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any


def function_schema(
    name: str,
    description: str,
    properties: dict[str, dict[str, Any]],
    required: list[str] | None = None,
) -> dict[str, Any]:
    """Assemble an OpenAI-style ``type=function`` schema dict."""
    return {
        "type": "function",
        "function": {
            "name": name,
            "description": description,
            "parameters": {
                "type": "object",
                "properties": properties,
                "required": required or [],
            },
        },
    }


def resolve_sandboxed(root: Path | None, path_str: str) -> Path:
    """Resolve ``path_str`` against ``root`` with escape protection.

    * ``root is None`` → return ``Path(path_str).expanduser().resolve()``.
    * ``root`` set → ``(root / path_str).resolve()`` but raise
      :class:`PermissionError` if the result escapes ``root``.

    Absolute ``path_str`` is accepted and normalised; the containment
    check catches both ``..`` tricks and absolute paths that happen
    to fall outside ``root``.
    """
    target = Path(path_str).expanduser()
    if root is None:
        return target.resolve()

    root_resolved = Path(root).expanduser().resolve()
    if target.is_absolute():
        candidate = target.resolve()
    else:
        candidate = (root_resolved / target).resolve()

    # Path.is_relative_to lands in 3.9 — persona-api already targets 3.11
    # (see pyproject.toml), so this is safe.
    if not candidate.is_relative_to(root_resolved):
        raise PermissionError(
            f"path escapes sandbox root: {path_str!r} → {candidate}",
        )
    return candidate
