"""``web_search`` DDG backend — Sancio P0#6c pilot only.

Positioning
-----------
Alternative :class:`WebSearchTool` that talks to DuckDuckGo instead of
Anthropic WebSearch. Built for the GAIA P0#6c ablation: does the search
layer matter once Gemma4 tool-ceiling + few-shot are both null?

Activation
----------
Opt-in via ``SANCIO_WEB_SEARCH_BACKEND=duckduckgo``. Default remains
the Anthropic-backed Concinno WebSearch so production behaviour is
unchanged. Once the ablation validates DDG (or kills it), promote the
chosen backend to Concinno and retire this file.

Dependency
----------
Requires ``duckduckgo-search`` at runtime (not in ``pyproject`` yet —
installed on pod only for the pilot). Failure to import surfaces as a
tool-error string so the agent loop sees ``"error: ..."`` rather than
crashing mid-benchmark.
"""

from __future__ import annotations

import asyncio
from typing import Any

from .base import function_schema


_DEFAULT_MAX_RESULTS = 5
_DEFAULT_OUTPUT_CAP = 4000


def _ddg_text_search(query: str, max_results: int) -> list[dict[str, str]]:
    # ``duckduckgo_search`` (legacy) and ``ddgs`` (renamed) both work;
    # prefer the new name which has better result quality (2026-04 fork).
    try:
        from ddgs import DDGS  # type: ignore[import-not-found]
    except ImportError:
        from duckduckgo_search import DDGS  # type: ignore[import-not-found]

    ddgs = DDGS()
    return list(ddgs.text(query=query, max_results=max_results))


def _format_results(results: list[dict[str, str]], cap: int) -> str:
    if not results:
        return "[empty search result]"
    lines: list[str] = []
    for idx, r in enumerate(results, start=1):
        title = (r.get("title") or "").strip()
        body = (r.get("body") or "").strip()
        href = (r.get("href") or "").strip()
        lines.append(f"[{idx}] {title}\n{body}\nSource: {href}")
    merged = "\n\n".join(lines)
    if len(merged) > cap:
        merged = merged[:cap].rstrip() + "…"
    return merged


class WebSearchTool:
    """Async DDG-backed WebSearch — drop-in for Sancio default_tools."""

    name = "web_search"

    def __init__(
        self,
        max_results: int = _DEFAULT_MAX_RESULTS,
        output_cap: int = _DEFAULT_OUTPUT_CAP,
        **_kwargs: Any,
    ) -> None:
        self._max_results = int(max_results)
        self._output_cap = int(output_cap)

    def schema(self) -> dict[str, Any]:
        return function_schema(
            name=self.name,
            description=(
                "Search the web via DuckDuckGo and return the top N "
                "result titles, snippets, and URLs as plain text. "
                "Use a specific query; results are unfiltered search "
                "hits (no LLM summarisation)."
            ),
            properties={
                "query": {
                    "type": "string",
                    "description": "Search query in natural language.",
                },
            },
            required=["query"],
        )

    async def execute(self, args: dict[str, Any]) -> str:
        query = str(args.get("query") or "").strip()
        if not query:
            return "error: query is required"
        try:
            results = await asyncio.to_thread(
                _ddg_text_search, query, self._max_results,
            )
        except ImportError:
            return (
                "error: duckduckgo-search package not installed "
                "(pip install duckduckgo-search)"
            )
        except Exception as exc:  # noqa: BLE001 — surface as tool error
            return (
                f"error: ddg_web_search failed: "
                f"{type(exc).__name__}: {exc}"
            )
        return _format_results(results, self._output_cap)
