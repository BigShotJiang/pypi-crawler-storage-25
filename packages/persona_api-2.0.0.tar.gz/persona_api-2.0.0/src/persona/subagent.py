"""Aegis SubagentSpawner — full prompt capture on every subagent call.

Why this module exists
----------------------
Claude Code's ``SubagentStart`` hook is a L2-capped shim: it fires
with only an ``agent_type`` keyword, so a parent agent running under
CC cannot see the actual system prompt, messages, or tool bundle its
child is about to receive. That gap caps CC's supervision story at
~40% of the ceiling: the parent can't audit, can't intervene, can't
replay, can't isolate per-tenant logs.

Aegis is the spawner here, not a guest. The prompt is in memory on
our side of the wire the instant someone calls :meth:`spawn`, so we
capture it *before* the LLM round-trip starts and persist the record
to disk so a crash mid-flight still leaves a replayable artifact.

Design rules (kept deliberately boring)
---------------------------------------
1. **concinno is a soft dependency.** The per-tenant JSON log path
   is the authoritative disk record and never imports concinno.
   AppendOnlyLog is layered on top for cross-session search and is
   tolerated as missing (soft no-op) when concinno is absent. This
   keeps the independence-layer promise: Aegis still runs when CCC
   is unavailable, just without the lossless replay layer.
2. **Delegate LLM I/O to A5.** The spawner does *not* speak HTTP. It
   asks :class:`ProviderRegistry` for a provider and hands it the
   captured messages. If A5 ever swaps an adapter, the spawner keeps
   working unchanged.
3. **Persist twice.** Once before the provider call (so a hard crash
   still leaves the request on disk) and once after (to record the
   response/error and timing). Both writes are whole-file atomic
   enough for our JSON-file scale.
4. **Per-tenant isolation on disk.** Records live in
   ``<log_dir>/<tenant_id>/<spawn_id>.json``. Listing one tenant
   never touches another tenant's directory — a tiny multi-tenant
   story that CC's global hook log cannot offer.
5. **Async all the way.** Starlette-friendly, never blocks the
   event loop with sync I/O beyond a short JSON dump.
"""

from __future__ import annotations

import json
import time
import uuid
from collections.abc import AsyncIterator
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any

from .providers import (
    LLMProvider,
    ModelPolicy,
    ProviderError,
    ProviderRegistry,
)

# A3 — CCC AppendOnlyLog lossless event capture. Soft import: if
# concinno is not installed the spawner still works, just without
# the cross-session lossless layer. Per-tenant JSON records remain
# the authoritative disk log regardless.
try:  # pragma: no cover — import guard
    from concinno.cache import AppendOnlyLog, LogEvent
    _APPEND_LOG_AVAILABLE = True
except ImportError:  # pragma: no cover — soft fallback
    AppendOnlyLog = None  # type: ignore[misc,assignment]
    LogEvent = None  # type: ignore[misc,assignment]
    _APPEND_LOG_AVAILABLE = False

__all__ = [
    "SpawnRequest",
    "SpawnRecord",
    "SubagentSpawner",
]


@dataclass
class SpawnRequest:
    """Fully captured input to one :meth:`SubagentSpawner.spawn` call.

    Everything the child agent will see must be present on this
    object. The whole point of the module is that no field is
    allowed to be synthesised after capture.
    """

    system_prompt: str
    user_messages: list[dict[str, str]]
    policy: ModelPolicy
    tenant_id: str = "default"
    subagent_role: str = ""
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class SpawnRecord:
    """One spawn event, in-flight or completed.

    ``response`` and ``error`` are mutually exclusive in practice but
    we don't enforce it at the type level — a provider that returns
    an empty string *and* we still flag it an error for some reason
    is a legitimate future extension.
    """

    spawn_id: str
    request: SpawnRequest
    started_at: float
    completed_at: float | None = None
    response: str | None = None
    error: str | None = None
    tokens_estimated: int = 0


def _estimate_tokens(text: str | None) -> int:
    """Rough 4-chars-per-token heuristic.

    Accurate enough for observability and rate accounting; replaced
    by a real tokenizer the day we care about billing.
    """
    if not text:
        return 0
    return max(1, len(text) // 4)


def _serialise(record: SpawnRecord) -> dict[str, Any]:
    """Convert a :class:`SpawnRecord` to a JSON-safe dict.

    ``asdict`` handles nested dataclasses (``SpawnRequest`` +
    ``ModelPolicy``) in one call, so the on-disk format stays flat
    and readable without a custom encoder.
    """
    return asdict(record)


class SubagentSpawner:
    """Owns the spawn pipeline: capture → persist → call → record.

    Not an LLM client itself. The registry does the HTTP work; this
    class supplies the supervision story on top of it.
    """

    def __init__(
        self,
        provider_registry: ProviderRegistry | None = None,
        log_dir: Path | str | None = None,
    ) -> None:
        self._registry: ProviderRegistry = (
            provider_registry or ProviderRegistry.default()
        )
        base = Path(log_dir) if log_dir else Path("data/subagent_logs")
        base.mkdir(parents=True, exist_ok=True)
        self._log_dir: Path = base
        self._active: dict[str, SpawnRecord] = {}
        # A3 — CCC AppendOnlyLog (cross-session lossless replay).
        # Lazy so tests can monkeypatch CCC_APPEND_LOG_DIR after
        # import and still observe the override.
        self._event_log: AppendOnlyLog | None = None

    @property
    def event_log(self) -> AppendOnlyLog | None:
        """Lazy-init AppendOnlyLog. ``None`` when concinno absent.

        Call sites must tolerate ``None`` — every ``append`` is
        wrapped in ``try/except`` so observability failures never
        propagate into the real spawn call path.
        """
        if self._event_log is None and _APPEND_LOG_AVAILABLE:
            try:
                self._event_log = AppendOnlyLog()
            except Exception:  # noqa: BLE001 — defensive: never
                # let log init break the spawner.
                return None
        return self._event_log

    # ── Public surface ─────────────────────────────────────

    async def spawn(self, req: SpawnRequest) -> SpawnRecord:
        """Run one subagent completion, with full capture.

        The record is persisted *before* the provider call so a
        crash mid-flight (OOM, connection drop, process kill) still
        leaves the captured request on disk. A second write after
        the call records the outcome.

        In addition to the per-tenant JSON record, A3 emits a
        lossless ``subagent_spawn_start`` + ``subagent_spawn_end``
        (or ``_error``) pair into CCC AppendOnlyLog scoped by
        ``req.tenant_id``. That layer is what cross-session replay
        and 6-month acquisition forensics consume.
        """
        record = self._make_record(req)
        self._active[record.spawn_id] = record
        self._persist(record)
        self._log_spawn_start(record, req)

        try:
            response = await self._dispatch(req)
            record.response = response
            record.tokens_estimated = _estimate_tokens(response)
        except ProviderError as exc:
            record.error = f"{exc.provider}: {exc.detail}"
        except Exception as exc:  # noqa: BLE001 — defensive umbrella
            record.error = f"unknown: {str(exc)[:200]}"
        finally:
            record.completed_at = time.time()
            self._persist(record)
            self._log_spawn_end(record, req)
            self._active.pop(record.spawn_id, None)

        return record

    async def spawn_stream(
        self, req: SpawnRequest,
    ) -> AsyncIterator[dict[str, Any]]:
        """Stream real token deltas from the provider.

        Emits ``start`` → N × ``token`` → ``end`` (on success) or
        ``start`` → 0..N × ``token`` → ``error`` (on failure). Each
        ``token`` event carries the raw provider delta; the spawn
        record is persisted twice — once before the provider call
        (same capture contract as :meth:`spawn`) and once in the
        ``finally`` block so partial output, total token count and
        timing land on disk even when the provider raises mid-stream.

        The final ``response`` field on the record is the
        concatenation of every chunk yielded before termination.
        Token estimation runs once on that joined string, not per
        chunk, so the heuristic stays consistent with :meth:`spawn`.
        """
        record = self._make_record(req)
        self._active[record.spawn_id] = record
        self._persist(record)
        self._log_spawn_start(record, req)

        yield {
            "type": "start",
            "spawn_id": record.spawn_id,
            "tenant_id": req.tenant_id,
            "subagent_role": req.subagent_role,
            "captured_prompt_len": len(req.system_prompt),
            "captured_user_turns": len(req.user_messages),
        }

        response_parts: list[str] = []
        try:
            async for chunk in self._dispatch_stream(req):
                if not chunk:
                    continue
                response_parts.append(chunk)
                yield {
                    "type": "token",
                    "spawn_id": record.spawn_id,
                    "text": chunk,
                }

            joined = "".join(response_parts)
            record.response = joined
            record.tokens_estimated = _estimate_tokens(joined)
            record.completed_at = time.time()
            yield {
                "type": "end",
                "spawn_id": record.spawn_id,
                "total_tokens": record.tokens_estimated,
            }
        except ProviderError as exc:
            # Best-effort partial response on mid-stream failure.
            partial = "".join(response_parts)
            record.response = partial or None
            record.tokens_estimated = _estimate_tokens(partial)
            record.error = f"{exc.provider}: {exc.detail}"
            record.completed_at = time.time()
            yield {
                "type": "error",
                "spawn_id": record.spawn_id,
                "detail": record.error,
            }
        except Exception as exc:  # noqa: BLE001
            partial = "".join(response_parts)
            record.response = partial or None
            record.tokens_estimated = _estimate_tokens(partial)
            record.error = f"unknown: {str(exc)[:200]}"
            record.completed_at = time.time()
            yield {
                "type": "error",
                "spawn_id": record.spawn_id,
                "detail": record.error,
            }
        finally:
            self._persist(record)
            self._log_spawn_end(record, req)
            self._active.pop(record.spawn_id, None)

    def get_record(self, spawn_id: str) -> SpawnRecord | None:
        """Fetch a spawn record by ID.

        Checks in-flight records first (cheap, same-process), then
        walks tenant directories on disk. Returns ``None`` if
        neither source carries the ID.
        """
        live = self._active.get(spawn_id)
        if live is not None:
            return live

        if not self._log_dir.exists():
            return None
        for tenant_dir in self._log_dir.iterdir():
            if not tenant_dir.is_dir():
                continue
            path = tenant_dir / f"{spawn_id}.json"
            if path.exists():
                return self._load_record(path)
        return None

    def list_records(
        self,
        tenant_id: str = "default",
        limit: int = 50,
    ) -> list[SpawnRecord]:
        """Return up to ``limit`` recent records for one tenant.

        Sorted by ``started_at`` descending. Tenant isolation is a
        directory walk, not a filter — a list call for tenant A
        never opens files owned by tenant B.
        """
        tenant_dir = self._log_dir / tenant_id
        if not tenant_dir.exists():
            return []

        records: list[SpawnRecord] = []
        for path in tenant_dir.glob("*.json"):
            record = self._load_record(path)
            if record is not None:
                records.append(record)

        records.sort(key=lambda r: r.started_at, reverse=True)
        return records[:limit]

    # ── Internals ──────────────────────────────────────────

    def _log_spawn_start(
        self, record: SpawnRecord, req: SpawnRequest,
    ) -> None:
        """Emit ``subagent_spawn_start`` to AppendOnlyLog. Safe no-op."""
        log = self.event_log
        if log is None:
            return
        try:
            log.append(LogEvent(
                event_id=record.spawn_id,
                session_id=req.tenant_id,
                timestamp=record.started_at,
                event_type="subagent_spawn_start",
                payload={
                    "spawn_id": record.spawn_id,
                    "subagent_role": req.subagent_role,
                    "provider": req.policy.provider,
                    "model": req.policy.model,
                    "system_prompt_len": len(req.system_prompt),
                    "user_messages_count": len(req.user_messages),
                },
                tokens_estimate=(
                    len(req.system_prompt)
                    + sum(
                        len(m.get("content", ""))
                        for m in req.user_messages
                    )
                ) // 4,
            ))
        except Exception:  # noqa: BLE001 — log failure is not fatal
            pass

    def _log_spawn_end(
        self, record: SpawnRecord, req: SpawnRequest,
    ) -> None:
        """Emit ``subagent_spawn_end``/``_error`` to AppendOnlyLog."""
        log = self.event_log
        if log is None:
            return
        try:
            log.append(LogEvent(
                event_id=AppendOnlyLog.new_event_id(),
                session_id=req.tenant_id,
                timestamp=record.completed_at or time.time(),
                event_type=(
                    "subagent_spawn_end"
                    if record.error is None
                    else "subagent_spawn_error"
                ),
                payload={
                    "spawn_id": record.spawn_id,
                    "response_length": len(record.response or ""),
                    "error": record.error,
                },
                parent_event_id=record.spawn_id,
                tokens_estimate=record.tokens_estimated,
            ))
        except Exception:  # noqa: BLE001
            pass

    def _make_record(self, req: SpawnRequest) -> SpawnRecord:
        return SpawnRecord(
            spawn_id=str(uuid.uuid4()),
            request=req,
            started_at=time.time(),
        )

    async def _dispatch(self, req: SpawnRequest) -> str:
        provider: LLMProvider = self._registry.get(req.policy.provider)
        messages: list[dict[str, str]] = [
            {"role": "system", "content": req.system_prompt},
        ]
        messages.extend(req.user_messages)
        return await provider.generate(messages, req.policy)

    async def _dispatch_stream(
        self, req: SpawnRequest,
    ) -> AsyncIterator[str]:
        """Streaming twin of :meth:`_dispatch`.

        Mirrors the non-streaming path's system+user assembly so
        the on-disk spawn record stays identical in shape regardless
        of which spawn entry point the caller used.
        """
        provider: LLMProvider = self._registry.get(req.policy.provider)
        messages: list[dict[str, str]] = [
            {"role": "system", "content": req.system_prompt},
        ]
        messages.extend(req.user_messages)
        async for chunk in provider.generate_stream(messages, req.policy):
            yield chunk

    def _persist(self, record: SpawnRecord) -> None:
        """Write the record as pretty JSON under ``<log_dir>/<tenant>``.

        Single ``write_text`` is atomic enough for dev usage; we are
        not trying to survive a power loss between bytes.
        """
        tenant_dir = self._log_dir / record.request.tenant_id
        tenant_dir.mkdir(parents=True, exist_ok=True)
        path = tenant_dir / f"{record.spawn_id}.json"
        payload = _serialise(record)
        path.write_text(
            json.dumps(payload, indent=2, ensure_ascii=False),
            encoding="utf-8",
        )

    def _load_record(self, path: Path) -> SpawnRecord | None:
        """Reconstruct a record from disk.

        Tolerates schema drift: unknown fields are silently dropped
        so old logs stay readable after a dataclass extension.
        """
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            return None

        req_data = data.get("request") or {}
        policy_data = req_data.get("policy") or {}
        try:
            policy = ModelPolicy(
                provider=str(policy_data.get("provider", "")),
                model=str(policy_data.get("model", "")),
                temperature=float(policy_data.get("temperature", 0.7)),
                max_tokens=int(policy_data.get("max_tokens", 4096)),
                cache_breakpoints=policy_data.get("cache_breakpoints"),
                extra=dict(policy_data.get("extra") or {}),
            )
            request = SpawnRequest(
                system_prompt=str(req_data.get("system_prompt", "")),
                user_messages=list(req_data.get("user_messages") or []),
                policy=policy,
                tenant_id=str(req_data.get("tenant_id", "default")),
                subagent_role=str(req_data.get("subagent_role", "")),
                metadata=dict(req_data.get("metadata") or {}),
            )
            return SpawnRecord(
                spawn_id=str(data.get("spawn_id", "")),
                request=request,
                started_at=float(data.get("started_at", 0.0)),
                completed_at=data.get("completed_at"),
                response=data.get("response"),
                error=data.get("error"),
                tokens_estimated=int(data.get("tokens_estimated") or 0),
            )
        except (TypeError, ValueError):
            return None
