"""Account system MVP — users + JWT + config sync.

Endpoints:
  POST /v1/auth/login            — username/password → JWT (24h)
  GET  /v1/auth/me               — Bearer → user info
  POST /v1/auth/logout           — Bearer → record logout (token not revoked)
  POST /v1/auth/change-password  — Bearer + {old, new} → update hash
  GET  /v1/config                — Bearer → user config blob
  PUT  /v1/config                — Bearer + blob → replace user config

Storage: SQLite at ``AUTH_DB_PATH`` (default ``/opt/persona-api/data/auth.db``).
Secret: ``SANCIO_JWT_SECRET`` env var (seed script generates + persists).

Middleware
----------
``AuthMiddleware`` enforces Bearer auth on the configured
``PROTECTED_PREFIXES`` (P0 RCE-surface endpoints — agent/run, chat,
cerno, subagent/spawn, load, a2a/invoke). Env switch
``SANCIO_REQUIRE_AUTH=0`` disables the gate (development only) and
logs a loud warning — default is ON.
"""

from __future__ import annotations

import json
import logging
import os
import secrets
import sqlite3
import time
from pathlib import Path
from typing import TYPE_CHECKING

import bcrypt
import jwt
from starlette.responses import JSONResponse
from starlette.routing import Route
from starlette.types import ASGIApp, Receive, Scope, Send

if TYPE_CHECKING:
    from starlette.requests import Request

_LOG = logging.getLogger("persona.auth")


# ── Config knobs ────────────────────────────────

DEFAULT_DB_PATH = "/opt/persona-api/data/auth.db"
DEFAULT_JWT_TTL_S = 24 * 3600
JWT_ALGO = "HS256"

# 0.17.0 — whitelist of keys accepted by PUT /v1/config. Unknown keys
# are silently dropped so a compromised client cannot smuggle arbitrary
# state into another account's config blob. Mirrors the extension-side
# ``SYNC_FIELDS`` in ``src/auth/config-sync.ts``.
allowed_config_keys: frozenset[str] = frozenset({
    "stackEndpoints",
    "sancioAllowedHosts",
    "aegisAllowedHosts",     # backward compat
    "digitalHumanCharacterName",
    "digitalHumanChatPath",
    "digitalHumanTrial",
    "sancioEndpoint",
    "aegisEndpoint",         # backward compat
    "digitalHumanUserId",
    "autoApproveAll",
})


def _db_path() -> str:
    """Resolve the SQLite path — env override wins."""
    return os.environ.get("AUTH_DB_PATH") or DEFAULT_DB_PATH


def _jwt_secret() -> str:
    """Return the JWT signing secret.

    Priority:
      1. ``SANCIO_JWT_SECRET`` / ``AEGIS_JWT_SECRET`` env var.
      2. File ``<db_parent>/.jwt_secret`` (auto-generated, 0600).
      3. Fresh random secret, persisted to the file.

    We never fall back to a hardcoded constant — signing with a known
    secret would silently accept forged tokens on a misconfigured host.
    """
    env = (
        os.environ.get("SANCIO_JWT_SECRET", "").strip()
        or os.environ.get("AEGIS_JWT_SECRET", "").strip()
    )
    if env:
        return env
    db = Path(_db_path())
    db.parent.mkdir(parents=True, exist_ok=True)
    secret_file = db.parent / ".jwt_secret"
    if secret_file.exists():
        return secret_file.read_text(encoding="utf-8").strip()
    fresh = secrets.token_urlsafe(48)
    secret_file.write_text(fresh, encoding="utf-8")
    try:
        os.chmod(secret_file, 0o600)
    except OSError:
        # Windows / test tmpdir — best-effort only.
        pass
    return fresh


# ── Schema ──────────────────────────────────────


_SCHEMA = """
CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT NOT NULL UNIQUE,
    password_hash TEXT NOT NULL,
    created_at INTEGER NOT NULL,
    updated_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS user_configs (
    user_id INTEGER PRIMARY KEY,
    config_json TEXT NOT NULL DEFAULT '{}',
    updated_at INTEGER NOT NULL,
    FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS auth_events (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    event TEXT NOT NULL,
    at INTEGER NOT NULL,
    FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
);
"""


def _connect() -> sqlite3.Connection:
    """Open a connection with schema applied + FK on."""
    path = _db_path()
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(path, isolation_level=None)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    conn.executescript(_SCHEMA)
    return conn


# ── User ops ────────────────────────────────────


def hash_password(plain: str) -> str:
    """bcrypt hash at rounds=12."""
    return bcrypt.hashpw(
        plain.encode("utf-8"), bcrypt.gensalt(rounds=12),
    ).decode("utf-8")


def verify_password(plain: str, hashed: str) -> bool:
    """Constant-time bcrypt verify. Bad hashes return False, never raise."""
    try:
        return bcrypt.checkpw(
            plain.encode("utf-8"), hashed.encode("utf-8"),
        )
    except (ValueError, TypeError):
        return False


def create_user(username: str, password: str) -> int:
    """Insert a new user; returns the new id.

    Raises :class:`ValueError` on duplicate username so callers can
    surface a 409 without leaking the underlying sqlite error.
    """
    now = int(time.time())
    conn = _connect()
    try:
        cur = conn.execute(
            "INSERT INTO users (username, password_hash, created_at, updated_at)"
            " VALUES (?, ?, ?, ?)",
            (username, hash_password(password), now, now),
        )
        user_id = int(cur.lastrowid or 0)
        conn.execute(
            "INSERT INTO user_configs (user_id, config_json, updated_at)"
            " VALUES (?, '{}', ?)",
            (user_id, now),
        )
        return user_id
    except sqlite3.IntegrityError as exc:
        raise ValueError(f"username already exists: {username}") from exc
    finally:
        conn.close()


def get_user_by_username(username: str) -> dict | None:
    """Row as dict, or None if not found."""
    conn = _connect()
    try:
        row = conn.execute(
            "SELECT id, username, password_hash, created_at, updated_at"
            " FROM users WHERE username = ?",
            (username,),
        ).fetchone()
        return dict(row) if row else None
    finally:
        conn.close()


def get_user_by_id(user_id: int) -> dict | None:
    """Row as dict, or None."""
    conn = _connect()
    try:
        row = conn.execute(
            "SELECT id, username, password_hash, created_at, updated_at"
            " FROM users WHERE id = ?",
            (user_id,),
        ).fetchone()
        return dict(row) if row else None
    finally:
        conn.close()


def update_password(user_id: int, new_password: str) -> None:
    """Hash + store the new password, bump updated_at."""
    now = int(time.time())
    conn = _connect()
    try:
        conn.execute(
            "UPDATE users SET password_hash = ?, updated_at = ? WHERE id = ?",
            (hash_password(new_password), now, user_id),
        )
    finally:
        conn.close()


def record_event(user_id: int, event: str) -> None:
    """Append a tiny audit row (login / logout / pw_change)."""
    conn = _connect()
    try:
        conn.execute(
            "INSERT INTO auth_events (user_id, event, at) VALUES (?, ?, ?)",
            (user_id, event, int(time.time())),
        )
    finally:
        conn.close()


def load_config(user_id: int) -> dict:
    """Return the parsed JSON blob for this user (empty dict default)."""
    conn = _connect()
    try:
        row = conn.execute(
            "SELECT config_json FROM user_configs WHERE user_id = ?",
            (user_id,),
        ).fetchone()
        if not row:
            return {}
        try:
            return json.loads(row["config_json"])
        except (ValueError, TypeError):
            return {}
    finally:
        conn.close()


def save_config(user_id: int, config: dict) -> None:
    """Replace the user's config blob wholesale."""
    now = int(time.time())
    payload = json.dumps(config, ensure_ascii=False)
    conn = _connect()
    try:
        conn.execute(
            "INSERT INTO user_configs (user_id, config_json, updated_at)"
            " VALUES (?, ?, ?)"
            " ON CONFLICT(user_id) DO UPDATE SET"
            " config_json = excluded.config_json,"
            " updated_at = excluded.updated_at",
            (user_id, payload, now),
        )
    finally:
        conn.close()


# ── JWT ─────────────────────────────────────────


def issue_token(user_id: int, username: str, ttl_s: int = DEFAULT_JWT_TTL_S) -> str:
    """HS256 token with ``sub``/``username``/``iat``/``exp`` claims."""
    now = int(time.time())
    payload = {
        "sub": str(user_id),
        "username": username,
        "iat": now,
        "exp": now + ttl_s,
    }
    return jwt.encode(payload, _jwt_secret(), algorithm=JWT_ALGO)


def verify_token(token: str) -> dict | None:
    """Decode + verify; return claims dict, or None on any failure."""
    try:
        return jwt.decode(token, _jwt_secret(), algorithms=[JWT_ALGO])
    except jwt.PyJWTError:
        return None


def _extract_bearer(request: Request) -> str | None:
    """Pull a ``Bearer <token>`` string out of the Authorization header."""
    auth = request.headers.get("authorization", "")
    if not auth.lower().startswith("bearer "):
        return None
    return auth[7:].strip() or None


async def _require_user(request: Request) -> tuple[dict, JSONResponse | None]:
    """Resolve the current user from the Authorization header.

    Returns ``(user_row, None)`` on success or ``({}, error_response)``
    on failure so handlers can short-circuit with one ``if err`` branch.
    """
    token = _extract_bearer(request)
    if not token:
        return {}, JSONResponse(
            {"error": "unauthorized", "detail": "missing Bearer token"},
            status_code=401,
        )
    claims = verify_token(token)
    if not claims:
        return {}, JSONResponse(
            {"error": "unauthorized", "detail": "invalid or expired token"},
            status_code=401,
        )
    try:
        user_id = int(claims.get("sub", "0"))
    except (TypeError, ValueError):
        user_id = 0
    user = get_user_by_id(user_id) if user_id else None
    if not user:
        return {}, JSONResponse(
            {"error": "unauthorized", "detail": "user not found"},
            status_code=401,
        )
    return user, None


# ── HTTP handlers ───────────────────────────────


def _user_public(user: dict) -> dict:
    """Shape a user row into the public JSON projection (no hash)."""
    return {
        "id": user["id"],
        "username": user["username"],
        "created_at": user["created_at"],
        "updated_at": user["updated_at"],
    }


async def _read_json(request: Request) -> tuple[dict, JSONResponse | None]:
    """Parse the body as a JSON dict, or return a 400 response."""
    try:
        body = await request.json()
    except Exception:  # noqa: BLE001 — transport / parse failure
        return {}, JSONResponse(
            {"error": "invalid_body", "detail": "body must be valid JSON"},
            status_code=400,
        )
    if not isinstance(body, dict):
        return {}, JSONResponse(
            {"error": "invalid_body", "detail": "body must be a JSON object"},
            status_code=400,
        )
    return body, None


async def _login(request: Request) -> JSONResponse:
    """Exchange ``{username, password}`` for a 24h JWT."""
    body, err = await _read_json(request)
    if err:
        return err
    username = str(body.get("username", "")).strip()
    password = str(body.get("password", ""))
    if not username or not password:
        return JSONResponse(
            {"error": "invalid_credentials",
             "detail": "username and password are required"},
            status_code=400,
        )
    user = get_user_by_username(username)
    # Always hit verify_password to keep timing roughly flat on
    # unknown-user vs. bad-password — we use a fixed dummy hash when
    # the user is missing so the bcrypt work still happens.
    if user is None:
        verify_password(password, "$2b$12$" + "x" * 53)
        return JSONResponse(
            {"error": "invalid_credentials",
             "detail": "username or password is incorrect"},
            status_code=401,
        )
    if not verify_password(password, user["password_hash"]):
        return JSONResponse(
            {"error": "invalid_credentials",
             "detail": "username or password is incorrect"},
            status_code=401,
        )
    token = issue_token(user["id"], user["username"])
    record_event(user["id"], "login")
    return JSONResponse({
        "token": token,
        "token_type": "Bearer",
        "expires_in": DEFAULT_JWT_TTL_S,
        "user": _user_public(user),
    })


async def _me(request: Request) -> JSONResponse:
    """Return the current user's public profile."""
    user, err = await _require_user(request)
    if err:
        return err
    return JSONResponse({"user": _user_public(user)})


async def _logout(request: Request) -> JSONResponse:
    """Record a logout event. Token is not revoked (short TTL)."""
    user, err = await _require_user(request)
    if err:
        return err
    record_event(user["id"], "logout")
    return JSONResponse({"ok": True})


async def _change_password(request: Request) -> JSONResponse:
    """Rotate the user's password after verifying the old one."""
    user, err = await _require_user(request)
    if err:
        return err
    body, berr = await _read_json(request)
    if berr:
        return berr
    old = str(body.get("old", ""))
    new = str(body.get("new", ""))
    if not old or not new:
        return JSONResponse(
            {"error": "invalid_body",
             "detail": "`old` and `new` are required"},
            status_code=400,
        )
    if len(new) < 4:
        return JSONResponse(
            {"error": "invalid_body",
             "detail": "`new` must be at least 4 characters"},
            status_code=400,
        )
    if not verify_password(old, user["password_hash"]):
        return JSONResponse(
            {"error": "invalid_credentials",
             "detail": "old password is incorrect"},
            status_code=401,
        )
    update_password(user["id"], new)
    record_event(user["id"], "pw_change")
    return JSONResponse({"ok": True})


async def _get_config(request: Request) -> JSONResponse:
    """Return the user's config blob."""
    user, err = await _require_user(request)
    if err:
        return err
    return JSONResponse({
        "user_id": user["id"],
        "config": load_config(user["id"]),
    })


async def _put_config(request: Request) -> JSONResponse:
    """Replace the user's config blob with the posted JSON object."""
    user, err = await _require_user(request)
    if err:
        return err
    body, berr = await _read_json(request)
    if berr:
        return berr
    config = body.get("config")
    if not isinstance(config, dict):
        return JSONResponse(
            {"error": "invalid_body",
             "detail": "`config` must be a JSON object"},
            status_code=400,
        )
    # 0.17.0 — filter to the whitelist so unknown keys can't ride the
    # sync channel. Returning the filtered view in the response makes
    # it obvious client-side when something got dropped.
    filtered = {k: v for k, v in config.items() if k in allowed_config_keys}
    save_config(user["id"], filtered)
    return JSONResponse({"ok": True, "config": filtered})


# ── Auth middleware (P0 RCE lockdown) ───────────
#
# P0#1 Task 1: every endpoint that can spend tokens, run tools, or
# touch the filesystem MUST sit behind a Bearer check. Cloudflare
# Tunnel is NOT an auth layer — it's a transport. Before this
# middleware /v1/agent/run, /v1/chat, /v1/cerno/cycle,
# /v1/subagent/spawn, /v1/load were anonymously callable. Now they
# all resolve through ``verify_token`` first.
#
# The middleware is **path-prefix keyed** rather than per-route decorator
# because Starlette's Route list is rebuilt on each app factory call
# and we want the gate declared ONCE in a place the app factory can't
# forget. Env var ``SANCIO_REQUIRE_AUTH=0`` disables the gate (dev
# only) and logs a loud warning on every boot.

# Prefixes that MUST carry a valid Bearer token. Ordered roughly by
# blast radius: RCE-capable endpoints first, then read/write helpers.
PROTECTED_PREFIXES: tuple[str, ...] = (
    "/v1/agent/run",
    "/v1/agent/permission",
    "/v1/chat",            # also covers /v1/chat/stream
    "/v1/cerno/cycle",     # POST + DELETE
    "/v1/cerno/registry",
    "/v1/subagent",        # /v1/subagent{,/spawn,/stream,/<id>}
    "/v1/load",
    "/v1/a2a/invoke",      # envelope-signed peer layer stays on top
    "/v1/a2a/status",
)

# Paths that MUST stay anonymous so clients can bootstrap / probe.
PUBLIC_PATHS: tuple[str, ...] = (
    "/v1/auth/login",
    "/v1/health",
    "/v1/a2a/capabilities",
)


def _benchmark_mode() -> bool:
    """Umbrella switch — True iff the deploy is a benchmark / eval run.

    ``PERSONA_BENCHMARK_MODE=1`` (or ``true``/``yes``/``on``) collapses
    every dev-friction gate: auth requirement, rate limits, audit log
    verbosity, etc. Benchmark runners (GAIA / AgentBench / OSWorld) flip
    this once on boot instead of threading N individual env flags.

    Downstream gates MUST read ``_benchmark_mode()`` first and short-
    circuit when True so new safety gates auto-inherit the bypass
    without revisiting every runner script.
    """
    val = os.environ.get("PERSONA_BENCHMARK_MODE", "").strip().lower()
    return val in ("1", "true", "yes", "on")


def _auth_required() -> bool:
    """Return True iff the middleware should enforce Bearer auth.

    Default ON. Two opt-out paths:

    * ``PERSONA_BENCHMARK_MODE=1`` — umbrella benchmark switch (shared
      with every other dev-friction gate). Preferred for GAIA / eval
      runs so adding a new gate later auto-inherits the bypass.
    * ``SANCIO_REQUIRE_AUTH=0`` — legacy per-gate switch, kept for
      backwards compat with older deploys that don't yet know the
      umbrella.

    Either path emits a stderr warning on every boot so the operator
    can't miss that protected endpoints are wide open.
    """
    if _benchmark_mode():
        _LOG.warning(
            "PERSONA_BENCHMARK_MODE=1 — auth disabled (benchmark "
            "umbrella). Protected endpoints are wide open.",
        )
        return False
    val = os.environ.get("SANCIO_REQUIRE_AUTH", "1").strip().lower()
    enabled = val not in ("0", "false", "no", "off", "")
    if not enabled:
        _LOG.warning(
            "SANCIO_REQUIRE_AUTH=0 — auth disabled, do not use in "
            "production. Protected endpoints are wide open.",
        )
    return enabled


def _path_is_protected(path: str) -> bool:
    """Match a request path against :data:`PROTECTED_PREFIXES`.

    Public paths short-circuit to False so ``/v1/auth/login`` never
    gets gated even though it shares the ``/v1`` root with protected
    routes.
    """
    for pub in PUBLIC_PATHS:
        if path == pub or path.startswith(pub + "/"):
            return False
    for pre in PROTECTED_PREFIXES:
        if path == pre or path.startswith(pre + "/"):
            return True
    return False


class AuthMiddleware:
    """ASGI middleware that denies unauthenticated access to P0 routes.

    Checks ``SANCIO_REQUIRE_AUTH`` per-request (not just at __init__)
    so test fixtures can flip the switch mid-suite without rebuilding
    the whole app.
    """

    def __init__(self, app: ASGIApp) -> None:
        self.app = app

    async def __call__(
        self, scope: Scope, receive: Receive, send: Send,
    ) -> None:
        if scope["type"] != "http" and scope["type"] != "websocket":
            await self.app(scope, receive, send)
            return

        path = scope.get("path", "")
        if not _path_is_protected(path):
            await self.app(scope, receive, send)
            return

        if not _auth_required():
            await self.app(scope, receive, send)
            return

        # Pull Bearer token off the Authorization header. Both HTTP
        # and WebSocket scopes expose headers as a [(bytes, bytes)]
        # list in Starlette.
        auth_header = b""
        for name, value in scope.get("headers") or []:
            if name == b"authorization":
                auth_header = value
                break

        token = ""
        if auth_header and auth_header.lower().startswith(b"bearer "):
            token = auth_header[7:].decode("ascii", errors="ignore").strip()

        if not token or not verify_token(token):
            if scope["type"] == "websocket":
                await send({"type": "websocket.close", "code": 4401})
                return
            response = JSONResponse(
                {"error": "unauthorized",
                 "detail": "missing or invalid Bearer token"},
                status_code=401,
            )
            await response(scope, receive, send)
            return

        await self.app(scope, receive, send)


# ── Route factory ───────────────────────────────


def create_auth_routes() -> list[Route]:
    """Return the account + config sync route list."""
    return [
        Route("/v1/auth/login", _login, methods=["POST"]),
        Route("/v1/auth/me", _me, methods=["GET"]),
        Route("/v1/auth/logout", _logout, methods=["POST"]),
        Route(
            "/v1/auth/change-password", _change_password, methods=["POST"],
        ),
        Route("/v1/config", _get_config, methods=["GET"]),
        Route("/v1/config", _put_config, methods=["PUT"]),
    ]
