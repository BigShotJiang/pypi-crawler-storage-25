"""persona.runtime_dispatcher_glue — Wire EventDispatcher into the runtime.

@module runtime_dispatcher_glue
@responsibility Glue layer between :class:`persona.event_dispatcher.
    EventDispatcher` (Sancio 0.6) and the live ``/v1/agent/run`` runtime.
    Owns three responsibilities the dispatcher itself does not:

    1. **Skill discovery** — walk ``~/.claude/skills``, ``<cwd>/.claude/
       skills``, and ``concinno.skills`` entry-points; parse each
       ``SKILL.md`` and extract any ``event_bindings`` block.
    2. **Per-session lifecycle** — return a fresh
       :class:`EventDispatcher` keyed on ``session_id`` (so
       :class:`OutcomeStore` writes land in the right StateStore file)
       while sharing the parsed-binding cache across sessions.
    3. **Hook fan-out** — produce ``pre_hook`` / ``post_hook`` callables
       compatible with :class:`persona.engine.agent_loop.AgentLoop` that
       translate each tool call into a ``PreToolUse`` / ``PostToolUse``
       (or ``PostToolUseFailure``) event and feed it to the dispatcher.

@dependencies persona.event_dispatcher, concinno.skill_parser,
    concinno.skills.schema, concinno.plugins (best-effort)
@exports get_dispatcher, parse_skill_md_with_bindings,
    discover_event_bindings, make_dispatcher_pre_hook,
    make_dispatcher_post_hook, fire_user_prompt_submit, fire_stop,
    reset_discovery_cache, reset_dispatcher_cache

Design notes
------------

* **Process-singleton parse cache, per-session dispatcher.** Spec §3.1
  pins the dispatcher to "single-instance per session"; we honour that
  literally. The expensive part — disk-walk + ``parse_skill_md`` on N
  SKILL.md files — runs once per process and is shared across sessions.
* **PyYAML fallback** — concinno's ``skill_parser`` is YAML-lite and
  intentionally does not unpack list-of-dicts (block ``event_bindings``).
  We re-extract the frontmatter ourselves with ``yaml.safe_load`` when
  PyYAML is available, otherwise we silently fall through with zero
  bindings (still spec-compliant per §5).
* **Hooks are observational** — pre-hook never raises (the dispatcher
  itself swallows all exceptions and records ``OutcomeRecord``); the
  guard / policy gates remain the sole source of ``PermissionDenied``.
* **Fail-soft everywhere** — a malformed ``SKILL.md``, a missing
  entry-point, or a YAML parse error never aborts the runtime. Worst
  case: that one binding is silently dropped, the rest keep working.
"""

from __future__ import annotations

import logging
import os
import re
from pathlib import Path
from typing import Any

from .event_dispatcher import EventDispatcher, OutcomeRecord

_LOG = logging.getLogger("persona.runtime_dispatcher_glue")

# ── frontmatter helpers ────────────────────────────────────────────

_FRONTMATTER_RE = re.compile(
    r"\A﻿?---\s*\n(.*?)\n---\s*(?:\n|\Z)",
    re.DOTALL,
)


def _extract_frontmatter_text(skill_md_path: Path) -> str | None:
    """Return the raw frontmatter body of *skill_md_path*, or None.

    We cannot reuse ``concinno.skill_parser._extract_frontmatter`` —
    it is private and the YAML-lite parser eats list-of-dicts before
    we can intercept. Reading the file again is cheap (skill md
    files are tiny) and keeps the boundary clean.
    """
    try:
        text = skill_md_path.read_text(encoding="utf-8", errors="replace")
    except (OSError, ValueError):
        return None
    if not text:
        return None
    m = _FRONTMATTER_RE.match(text)
    if not m:
        return None
    return m.group(1)


def _yaml_parse_event_bindings(frontmatter_text: str) -> list[dict[str, Any]]:
    """Best-effort: parse the frontmatter with PyYAML and pluck
    ``event_bindings``.

    Returns ``[]`` on any failure — never raises. PyYAML is a soft
    dependency: persona-api ships it (6.0+) but if a downstream
    install strips it we still degrade to "no bindings" rather than
    a 500.
    """
    try:
        import yaml  # type: ignore[import-not-found]
    except Exception:  # noqa: BLE001 — soft dep
        return []
    try:
        data = yaml.safe_load(frontmatter_text)
    except Exception:  # noqa: BLE001 — malformed YAML, keep loading other skills
        return []
    if not isinstance(data, dict):
        return []
    raw = data.get("event_bindings")
    if not isinstance(raw, list):
        return []
    out: list[dict[str, Any]] = []
    for item in raw:
        if isinstance(item, dict):
            out.append(item)
    return out


def parse_skill_md_with_bindings(skill_md_path: Path) -> dict[str, Any]:
    """Return a meta dict combining ``parse_skill_md`` + raw event_bindings.

    Workflow:
        1. Run :func:`concinno.skill_parser.parse_skill_md` for the
           flat keys (``name``, ``description``, ``triggers``, …).
        2. If the meta already has a list-of-dicts ``event_bindings``
           (a future concinno bump may teach the YAML-lite parser to
           handle this), keep it.
        3. Otherwise pull the raw frontmatter and try PyYAML to extract
           the ``event_bindings`` block.

    The result is shaped exactly like spec §2 — ready to hand to
    :func:`concinno.skills.schema.parse_event_bindings`.
    """
    try:
        from concinno.skill_parser import parse_skill_md
    except Exception:  # noqa: BLE001 — concinno missing: surface zero
        return {}
    meta = parse_skill_md(skill_md_path) or {}
    existing = meta.get("event_bindings")
    if isinstance(existing, list) and all(
        isinstance(x, dict) for x in existing
    ):
        # Concinno already handed us list-of-dicts (future).
        return meta
    fm = _extract_frontmatter_text(skill_md_path)
    if fm is None:
        return meta
    bindings = _yaml_parse_event_bindings(fm)
    if bindings:
        meta["event_bindings"] = bindings
    return meta


# ── skill discovery ────────────────────────────────────────────────


def _user_skill_root() -> Path:
    """``~/.claude/skills`` honoring the ``CLAUDE_HOME`` override."""
    override = os.environ.get("CLAUDE_HOME")
    if override:
        return Path(override) / "skills"
    return Path.home() / ".claude" / "skills"


def _project_skill_root() -> Path:
    """``<cwd>/.claude/skills`` — project-level skills."""
    return Path.cwd() / ".claude" / "skills"


def _walk_skill_dir(root: Path) -> list[Path]:
    """Yield every SKILL.md beneath *root* (one per immediate subdir).

    Matches concinno's GUI server semantics: subdirectories named
    ``official`` / ``public`` / ``private`` are sub-scopes — the
    SKILL.md lives one level deeper.
    """
    if not root.is_dir():
        return []
    out: list[Path] = []
    try:
        children = sorted(root.iterdir())
    except OSError:
        return []
    for child in children:
        if not child.is_dir():
            continue
        if child.name in ("official", "public", "private"):
            try:
                grand_children = sorted(child.iterdir())
            except OSError:
                continue
            for gc in grand_children:
                if gc.is_dir():
                    skill_md = gc / "SKILL.md"
                    if skill_md.is_file():
                        out.append(skill_md)
        else:
            skill_md = child / "SKILL.md"
            if skill_md.is_file():
                out.append(skill_md)
    return out


def _plugin_skill_paths() -> list[Path]:
    """Return SKILL.md paths discovered via ``concinno.skills`` entry-points.

    Best-effort: any error in plugin discovery (missing concinno,
    plugin entry-point load failure, file-system stat error) → empty
    list. We never let plugin issues abort runtime startup.
    """
    out: list[Path] = []
    try:
        from concinno.plugins import iter_plugin_skill_roots
    except Exception:  # noqa: BLE001
        return out
    try:
        for plugin_root, _pkg_name in iter_plugin_skill_roots():
            out.extend(_walk_skill_dir(plugin_root))
    except Exception:  # noqa: BLE001
        return out
    return out


# Module-level cache: parsed (path, meta) tuples. Discovery is expensive
# enough (FS walk + YAML parse on every SKILL.md) that we run it once per
# process and reuse. Tests reset via :func:`reset_discovery_cache`.
_DISCOVERY_CACHE: list[tuple[Path, dict[str, Any]]] | None = None


def reset_discovery_cache() -> None:
    """Force the next :func:`discover_event_bindings` call to re-scan."""
    global _DISCOVERY_CACHE
    _DISCOVERY_CACHE = None


def discover_event_bindings(
    *,
    extra_roots: list[Path] | None = None,
) -> list[tuple[Path, dict[str, Any]]]:
    """Walk every skill root and return ``(path, meta)`` tuples.

    Args:
        extra_roots: Additional roots to scan (test injection). When
            provided, the global cache is **bypassed** — the caller
            owns the result. This keeps tests from poisoning the
            production cache.

    The result is cached at process scope when no ``extra_roots`` are
    given; call :func:`reset_discovery_cache` to invalidate.
    """
    if extra_roots is not None:
        out: list[tuple[Path, dict[str, Any]]] = []
        for root in extra_roots:
            for path in _walk_skill_dir(root):
                meta = parse_skill_md_with_bindings(path)
                if meta:
                    out.append((path, meta))
        return out

    global _DISCOVERY_CACHE
    if _DISCOVERY_CACHE is not None:
        return _DISCOVERY_CACHE

    paths: list[Path] = []
    paths.extend(_walk_skill_dir(_user_skill_root()))
    project_root = _project_skill_root()
    if project_root != _user_skill_root():
        paths.extend(_walk_skill_dir(project_root))
    paths.extend(_plugin_skill_paths())

    parsed: list[tuple[Path, dict[str, Any]]] = []
    seen_names: set[str] = set()
    for path in paths:
        meta = parse_skill_md_with_bindings(path)
        if not meta:
            continue
        name = str(meta.get("name") or path.parent.name)
        # Higher-precedence (user > project > plugin) wins on dup name —
        # paths arrive in that order so we only keep the first.
        if name in seen_names:
            continue
        seen_names.add(name)
        parsed.append((path, meta))
    _DISCOVERY_CACHE = parsed
    return parsed


# ── per-session dispatcher cache ───────────────────────────────────


def _default_cache_dir() -> str:
    """Return the OutcomeStore root.

    Honours ``CONCINNO_HOME`` then ``~/.concinno``. Created lazily on
    first :class:`OutcomeStore.append`.
    """
    override = os.environ.get("CONCINNO_HOME")
    if override:
        return override
    return str(Path.home() / ".concinno")


# Per-session dispatcher cache — keyed by session_id. Spec §3.1 pins
# "single-instance per session"; sharing across sessions would mix
# OutcomeRecords in the wrong StateStore file.
_DISPATCHER_BY_SESSION: dict[str, EventDispatcher] = {}


def reset_dispatcher_cache() -> None:
    """Drop the per-session dispatcher cache. Test-only helper."""
    _DISPATCHER_BY_SESSION.clear()


def get_dispatcher(
    session_id: str,
    *,
    cache_dir: str | None = None,
    extra_roots: list[Path] | None = None,
) -> EventDispatcher:
    """Return the :class:`EventDispatcher` for *session_id*.

    First call for a given ``session_id`` constructs a new dispatcher,
    runs :func:`discover_event_bindings`, and registers each parsed
    SKILL.md. Subsequent calls return the cached instance so registered
    bindings persist for the whole session lifetime.

    Args:
        session_id: Stable per-session identifier (HTTP request id is
            fine). Different ids → different dispatchers → different
            OutcomeStore files.
        cache_dir: Override the OutcomeStore root. Defaults to
            ``CONCINNO_HOME`` env var or ``~/.concinno``.
        extra_roots: Test-only injection — replaces the global skill
            discovery roots with this list. Skips the process-level
            cache when set.
    """
    if not session_id:
        # Defensive: empty session id would collide with other empty
        # ids. Fall back to a per-call ephemeral id.
        import uuid as _uuid

        session_id = f"_anon_{_uuid.uuid4().hex[:8]}"

    cached = _DISPATCHER_BY_SESSION.get(session_id)
    if cached is not None:
        return cached

    resolved_cache_dir = cache_dir or _default_cache_dir()
    dispatcher = EventDispatcher(
        cache_dir=resolved_cache_dir,
        session_id=session_id,
    )

    # Bulk register every discovered binding. The concinno schema
    # filter inside ``register_skill`` already drops malformed entries
    # so we don't pre-validate here.
    try:
        for path, meta in discover_event_bindings(extra_roots=extra_roots):
            try:
                dispatcher.register_skill(meta, path)
            except Exception as exc:  # noqa: BLE001
                _LOG.warning(
                    "register_skill(%s) failed: %s", path, exc,
                )
    except Exception as exc:  # noqa: BLE001
        _LOG.warning("event_bindings discovery failed: %s", exc)

    _DISPATCHER_BY_SESSION[session_id] = dispatcher
    return dispatcher


# ── hook fan-out ───────────────────────────────────────────────────


def _build_pre_payload(
    tool_name: str,
    args: dict[str, Any],
) -> dict[str, Any]:
    """Shape the payload spec §4 expects for ``PreToolUse``.

    Includes the conventional CC-style keys ``tool_name``,
    ``tool_input``, plus the flattened ``file_path`` if the tool
    arguments expose it (most file-mutating tools do, predicates use
    it).
    """
    payload: dict[str, Any] = {
        "tool_name": tool_name,
        "tool_input": args,
    }
    fp = args.get("file_path") if isinstance(args, dict) else None
    if fp is not None:
        payload["file_path"] = fp
    return payload


def _build_post_payload(
    tool_name: str,
    args: dict[str, Any],
    result: Any,
) -> dict[str, Any]:
    payload = _build_pre_payload(tool_name, args)
    payload["tool_result"] = result
    return payload


def make_dispatcher_pre_hook(dispatcher: EventDispatcher):
    """Build a PreToolUseHook that fires ``PreToolUse`` events.

    The hook never raises — dispatcher errors are swallowed inside
    :meth:`EventDispatcher.fire`. Guard / policy hooks remain the sole
    source of :class:`PermissionDenied`.
    """

    async def _hook(tool_name: str, args: dict[str, Any]) -> None:
        try:
            dispatcher.fire(
                "PreToolUse",
                _build_pre_payload(tool_name, args),
            )
        except Exception as exc:  # noqa: BLE001 — hook must not break loop
            _LOG.warning("dispatcher PreToolUse fire failed: %s", exc)

    return _hook


def _looks_like_tool_error(result: Any) -> bool:
    """Mirror agent_api's ``startswith("tool error:")`` heuristic.

    The agent loop encodes failed tool execution as a string starting
    with ``"tool error: "`` (see ``AgentLoop._run_one_tool``). We use
    the same signal to decide between ``PostToolUse`` and
    ``PostToolUseFailure``.
    """
    if isinstance(result, str) and result.startswith("tool error:"):
        return True
    return False


def make_dispatcher_post_hook(dispatcher: EventDispatcher):
    """Build a PostToolUseHook that fires ``PostToolUse`` /
    ``PostToolUseFailure`` events."""

    async def _hook(
        tool_name: str,
        args: dict[str, Any],
        result: Any,
    ) -> None:
        event = (
            "PostToolUseFailure"
            if _looks_like_tool_error(result)
            else "PostToolUse"
        )
        try:
            dispatcher.fire(
                event,
                _build_post_payload(tool_name, args, result),
            )
        except Exception as exc:  # noqa: BLE001
            _LOG.warning(
                "dispatcher %s fire failed: %s", event, exc,
            )

    return _hook


def fire_user_prompt_submit(
    dispatcher: EventDispatcher,
    *,
    prompt: str,
    stack: str,
    session_id: str,
) -> list[OutcomeRecord]:
    """Fire ``UserPromptSubmit`` once at request entry.

    Returns the OutcomeRecord list (empty when no binding matches) so
    callers / tests can inspect what fired.
    """
    return dispatcher.fire(
        "UserPromptSubmit",
        {
            "prompt": prompt,
            "stack": stack,
            "session_id": session_id,
        },
    )


def fire_stop(
    dispatcher: EventDispatcher,
    *,
    session_id: str,
    stop_reason: str,
    iterations: int,
) -> list[OutcomeRecord]:
    """Fire ``Stop`` once at request exit (success or error path)."""
    return dispatcher.fire(
        "Stop",
        {
            "session_id": session_id,
            "stop_reason": stop_reason,
            "iterations": iterations,
        },
    )


__all__ = [
    "discover_event_bindings",
    "fire_stop",
    "fire_user_prompt_submit",
    "get_dispatcher",
    "make_dispatcher_post_hook",
    "make_dispatcher_pre_hook",
    "parse_skill_md_with_bindings",
    "reset_discovery_cache",
    "reset_dispatcher_cache",
]
