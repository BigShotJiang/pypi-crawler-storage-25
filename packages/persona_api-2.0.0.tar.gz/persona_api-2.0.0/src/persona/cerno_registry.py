"""persona.cerno_registry — Cerno lifecycle manager.

Lifts the per-child Cerno registry out of ``persona.api`` into a
dedicated module so api.py stays a thin HTTP-shape layer. Adds four
lifecycle features on top of the original LRU-only map:

    1. **Multi-tenant sub-groups** — each ``tenant`` owns its own
       ``OrderedDict`` with an independent LRU clock. Overflow in
       tenant A cannot evict entries in tenant B.
    2. **TTL prune** — each entry carries ``last_used_at``. Inline
       checks on ``get`` / ``get_or_create`` handle the touched
       entry cheaply; the background task does full sweeps.
    3. **Async background prune task** — opt-in
       ``start_background_prune()`` schedules a periodic sweep.
       Cancellation is idempotent and fire-and-forget.
    4. **Persistence** — opt-in JSON snapshot of
       :class:`CernoState` dataclass fields. Restore rebuilds
       fresh :class:`Cerno` instances from the dataclass fields
       only; callbacks / closures / listeners are intentionally
       not serialised because they cannot round-trip through JSON.

Session 2026-04-15 P3.2 (handoff §4 P0 #3 — TTL / background prune /
persistence / multi-tenant).
"""

from __future__ import annotations

import asyncio
import copy
import dataclasses
import json
import logging
import os
import time
from collections import OrderedDict
from dataclasses import dataclass, field
from typing import Any

from persona.cerno import (
    Cerno,
    CernoConfig,
    DEFAULT_CERNO_CONFIG,
    EquilibriumState,
)

_LOG = logging.getLogger(__name__)

SNAPSHOT_VERSION = 1


@dataclass
class _Entry:
    """One registry row — the live Cerno + its LRU / TTL metadata.

    We keep ``last_used_at`` as a ``time.monotonic()`` reading so
    wall-clock jumps (NTP / DST) cannot retroactively expire rows.
    The trade-off is that persistence must not assume monotonic
    values survive a process restart — see :meth:`CernoRegistry.
    restore_from_disk` which resets ``last_used_at`` on every
    restored entry.
    """

    cerno: Cerno
    last_used_at: float = field(default_factory=time.monotonic)


class CernoRegistry:
    """LRU + TTL + background prune + persistence + tenant sub-groups.

    Storage layout::

        self._stores: dict[str, OrderedDict[str, _Entry]]
            tenant -> (child_id -> _Entry)

    Each tenant's OrderedDict is a fully independent LRU + TTL map.
    Eviction in one tenant never touches another. ``list_keys()``
    optionally filters by tenant, or returns a flat list across all
    tenants when ``tenant=None``.
    """

    def __init__(
        self,
        max_size: int = 256,
        ttl_seconds: float = 3600.0,
        persist_path: str | None = None,
        prune_interval_s: float = 60.0,
    ) -> None:
        self._max_size = max(1, int(max_size))
        self._ttl_seconds = float(ttl_seconds)
        self._persist_path = persist_path
        self._prune_interval_s = float(prune_interval_s)

        self._stores: dict[str, OrderedDict[str, _Entry]] = {}

        # Stats counters — exposed via :meth:`stats`.
        self._hits = 0
        self._misses = 0
        self._evictions = 0
        self._expired = 0

        self._prune_task: asyncio.Task[None] | None = None

    # ── internal helpers ────────────────────────────────────

    def _store_for(self, tenant: str) -> OrderedDict[str, _Entry]:
        """Return the per-tenant OrderedDict, creating it lazily."""
        store = self._stores.get(tenant)
        if store is None:
            store = OrderedDict()
            self._stores[tenant] = store
        return store

    def _is_expired(self, entry: _Entry) -> bool:
        """Entry exceeded TTL window since last touch."""
        if self._ttl_seconds <= 0:
            return False
        return (time.monotonic() - entry.last_used_at) > self._ttl_seconds

    def _enforce_max_size(self, store: OrderedDict[str, _Entry]) -> None:
        """Evict LRU rows until ``len(store) <= max_size``."""
        while len(store) > self._max_size:
            store.popitem(last=False)
            self._evictions += 1

    def _sweep_expired(self) -> int:
        """Full sweep — remove every expired row across all tenants.

        Returns the number of entries pruned. Called by the
        background task on every tick and available as a public-ish
        synchronous helper for tests that don't want to wait.
        """
        pruned = 0
        if self._ttl_seconds <= 0:
            return pruned
        now = time.monotonic()
        for store in self._stores.values():
            # Collect first, mutate second — OrderedDict mutation
            # during iteration raises.
            dead = [
                key for key, entry in store.items()
                if (now - entry.last_used_at) > self._ttl_seconds
            ]
            for key in dead:
                store.pop(key, None)
                self._expired += 1
                pruned += 1
        return pruned

    # ── public API: get / create / delete ───────────────────

    def get(self, key: str, *, tenant: str = "default") -> Cerno:
        """Return the live Cerno or raise :class:`KeyError`.

        Inline TTL check: if the touched entry has expired, it is
        removed and ``KeyError`` is raised so callers see the same
        "missing" outcome as a cold miss.
        """
        store = self._stores.get(tenant)
        if store is None or key not in store:
            self._misses += 1
            raise KeyError(f"no cerno for tenant={tenant!r} key={key!r}")

        entry = store[key]
        if self._is_expired(entry):
            store.pop(key, None)
            self._expired += 1
            self._misses += 1
            raise KeyError(
                f"cerno expired for tenant={tenant!r} key={key!r}"
            )

        entry.last_used_at = time.monotonic()
        store.move_to_end(key)
        self._hits += 1
        return entry.cerno

    def get_or_create(
        self,
        key: str,
        *,
        tenant: str = "default",
        config_overrides: dict[str, Any] | None = None,
    ) -> Cerno:
        """Return the Cerno for ``(tenant, key)``, creating it once.

        A ``config_overrides`` dict is merged on top of
        :data:`DEFAULT_CERNO_CONFIG` only at construction time.
        Subsequent calls with a different ``config_overrides`` are
        IGNORED on an existing instance — mutating config on a hot
        Cerno would silently drift from the state the child has
        already accumulated. Clients that need a reset should pass
        a new ``key`` (e.g. append a version suffix).
        """
        store = self._store_for(tenant)
        existing = store.get(key)
        if existing is not None and not self._is_expired(existing):
            existing.last_used_at = time.monotonic()
            store.move_to_end(key)
            self._hits += 1
            return existing.cerno

        # Either missing or expired — both paths rebuild a fresh
        # Cerno. Drop any expired row first so the counter is
        # honest.
        if existing is not None and self._is_expired(existing):
            store.pop(key, None)
            self._expired += 1

        self._misses += 1
        cfg = self._build_config(config_overrides)
        arb = Cerno(child_id=key, config=cfg)
        store[key] = _Entry(cerno=arb)
        store.move_to_end(key)
        self._enforce_max_size(store)
        return arb

    def delete(self, key: str, *, tenant: str = "default") -> bool:
        """Remove ``(tenant, key)``. Returns True iff it existed."""
        store = self._stores.get(tenant)
        if store is None or key not in store:
            return False
        store.pop(key, None)
        return True

    def list_keys(self, *, tenant: str | None = None) -> list[str]:
        """List child ids.

        ``tenant=None`` walks every tenant in insertion order and
        returns a flat list (may contain duplicates across tenants
        since the same child_id can legally live under multiple
        tenants).
        """
        if tenant is None:
            out: list[str] = []
            for store in self._stores.values():
                out.extend(store.keys())
            return out
        store = self._stores.get(tenant)
        if store is None:
            return []
        return list(store.keys())

    # ── stats / introspection ───────────────────────────────

    def size(self, *, tenant: str | None = None) -> int:
        """Total entries, optionally scoped to a single tenant."""
        if tenant is None:
            return sum(len(s) for s in self._stores.values())
        store = self._stores.get(tenant)
        return 0 if store is None else len(store)

    def stats(self) -> dict[str, Any]:
        """Return a flat dict with counters + config snapshot."""
        return {
            "size": self.size(),
            "hits": self._hits,
            "misses": self._misses,
            "evictions": self._evictions,
            "expired": self._expired,
            "tenants": list(self._stores.keys()),
            "max_size": self._max_size,
            "ttl_seconds": self._ttl_seconds,
            "prune_interval_s": self._prune_interval_s,
            "persist_path": self._persist_path,
        }

    def iter_entries(self) -> list[tuple[str, str, Cerno]]:
        """Yield ``(tenant, child_id, cerno)`` for every live entry.

        Used by the HTTP registry list endpoint.
        """
        out: list[tuple[str, str, Cerno]] = []
        for tenant, store in self._stores.items():
            for child_id, entry in store.items():
                out.append((tenant, child_id, entry.cerno))
        return out

    # ── background prune task ───────────────────────────────

    async def start_background_prune(self) -> None:
        """Start the periodic sweep task. Idempotent."""
        if self._prune_task is not None and not self._prune_task.done():
            return
        self._prune_task = asyncio.create_task(self._prune_loop())

    async def stop_background_prune(self) -> None:
        """Cancel + await the sweep task. Safe to call repeatedly.

        The loop catches :class:`asyncio.CancelledError` internally
        so ``await`` here does not re-raise. That makes shutdown
        paths cleaner — callers do not need their own try/except.
        """
        task = self._prune_task
        if task is None:
            return
        self._prune_task = None
        if task.done():
            return
        task.cancel()
        try:
            await task
        except asyncio.CancelledError:
            # Defensive — the loop swallows this, but a cancellation
            # that races the ``await asyncio.sleep`` may still leak
            # it out depending on event-loop timing.
            pass

    async def _prune_loop(self) -> None:
        """Periodic full-sweep loop. Cancelled by ``stop_*``."""
        try:
            while True:
                await asyncio.sleep(self._prune_interval_s)
                try:
                    self._sweep_expired()
                except Exception:  # noqa: BLE001 — never kill the task
                    _LOG.exception("cerno_registry background sweep failed")
        except asyncio.CancelledError:
            # Swallow so ``stop_background_prune`` can await cleanly.
            return

    # ── persistence ─────────────────────────────────────────

    def persist_to_disk(self) -> None:
        """Atomic JSON snapshot to ``self._persist_path``.

        No-op when ``persist_path`` was not configured. Writes to a
        ``.tmp`` sibling then ``os.replace`` onto the target so a
        crash mid-write cannot truncate the previous snapshot. When
        :func:`json.dump` raises mid-write, the ``.tmp`` file is
        removed and the previous snapshot stays intact.
        """
        if not self._persist_path:
            return

        snapshot = {
            "version": SNAPSHOT_VERSION,
            "saved_at": time.time(),
            "entries": [
                {
                    "tenant": tenant,
                    "child_id": child_id,
                    "state": dataclasses.asdict(entry.cerno.state),
                    # last_used_at is monotonic → not restorable.
                    # We write it for debug visibility only and the
                    # restore path resets it on load.
                    "last_used_at": entry.last_used_at,
                }
                for tenant, store in self._stores.items()
                for child_id, entry in store.items()
            ],
        }

        tmp = self._persist_path + ".tmp"
        try:
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(snapshot, f)
            os.replace(tmp, self._persist_path)
        except Exception:
            # Remove the half-written tmp so the next run starts
            # clean. The previous snapshot (if any) is untouched
            # because ``os.replace`` never ran.
            try:
                os.unlink(tmp)
            except FileNotFoundError:
                pass
            raise

    @classmethod
    def restore_from_disk(
        cls,
        path: str,
        **kwargs: Any,
    ) -> "CernoRegistry":
        """Build a new registry, optionally seeded from a snapshot.

        Returns an empty registry when:
          * the file does not exist,
          * the file is malformed JSON,
          * the ``version`` field is unknown.

        Start-up must always succeed — a corrupt snapshot should
        not kill the service, only log a warning.
        """
        registry = cls(persist_path=path, **kwargs)

        if not os.path.exists(path):
            return registry

        try:
            with open(path, "r", encoding="utf-8") as f:
                data = json.load(f)
        except (OSError, json.JSONDecodeError) as exc:
            _LOG.warning(
                "cerno_registry restore failed (%s) — starting empty",
                exc,
            )
            return registry

        version = data.get("version")
        if version != SNAPSHOT_VERSION:
            _LOG.warning(
                "cerno_registry snapshot version %r != expected %r — "
                "starting empty",
                version,
                SNAPSHOT_VERSION,
            )
            return registry

        entries = data.get("entries", [])
        if not isinstance(entries, list):
            _LOG.warning(
                "cerno_registry snapshot entries not a list — starting empty"
            )
            return registry

        for row in entries:
            try:
                tenant = str(row["tenant"])
                child_id = str(row["child_id"])
                state_raw = row["state"]
            except (KeyError, TypeError):
                _LOG.warning("cerno_registry snapshot row malformed — skipped")
                continue

            arb = registry._rebuild_cerno(child_id, state_raw)
            store = registry._store_for(tenant)
            store[child_id] = _Entry(cerno=arb)

        return registry

    @staticmethod
    def _rebuild_cerno(child_id: str, state_raw: dict[str, Any]) -> Cerno:
        """Rebuild a fresh :class:`Cerno` from persisted state.

        Only the portable fields of :class:`CernoState` are
        restored: ``consecutive_denies``, ``current_identity``,
        ``recent_scores``, ``steps_since_recal``, plus the
        ``equilibrium`` sub-dataclass. Non-persistable parts
        (listeners, closures) are reinitialised to defaults.
        """
        arb = Cerno(child_id=child_id)
        try:
            arb.state.consecutive_denies = int(
                state_raw.get("consecutive_denies", 0) or 0
            )
            arb.state.current_identity = state_raw.get(
                "current_identity", arb.state.current_identity,
            )
            arb.state.steps_since_recal = int(
                state_raw.get("steps_since_recal", 0) or 0
            )

            scores = state_raw.get("recent_scores") or []
            if isinstance(scores, list):
                arb.state.recent_scores = [
                    int(s) for s in scores if isinstance(s, (int, float))
                ]

            eq_raw = state_raw.get("equilibrium") or {}
            if isinstance(eq_raw, dict):
                # Rebuild the sub-dataclass field-by-field so extra
                # keys in the snapshot never break startup.
                eq = EquilibriumState()
                for fld in dataclasses.fields(EquilibriumState):
                    if fld.name in eq_raw:
                        setattr(eq, fld.name, eq_raw[fld.name])
                arb.state.equilibrium = eq
        except Exception as exc:  # noqa: BLE001 — partial restore is OK
            _LOG.warning(
                "cerno_registry rebuild child=%r partially failed: %s",
                child_id,
                exc,
            )
        return arb

    # ── config merging ──────────────────────────────────────

    @staticmethod
    def _build_config(
        overrides: dict[str, Any] | None,
    ) -> CernoConfig:
        """Merge ``overrides`` onto :data:`DEFAULT_CERNO_CONFIG`.

        Only keys that correspond to real fields on
        :class:`CernoConfig` are applied — the endpoint forwards
        arbitrary client JSON here, so unknown keys must be dropped
        silently rather than raising.
        """
        if not overrides:
            return copy.deepcopy(DEFAULT_CERNO_CONFIG)
        known = {
            k: v
            for k, v in overrides.items()
            if hasattr(DEFAULT_CERNO_CONFIG, k)
        }
        return dataclasses.replace(
            copy.deepcopy(DEFAULT_CERNO_CONFIG), **known,
        )

    # ── test helpers ────────────────────────────────────────

    def clear(self) -> None:
        """Drop every entry + reset counters. Used by test fixtures."""
        self._stores.clear()
        self._hits = 0
        self._misses = 0
        self._evictions = 0
        self._expired = 0
