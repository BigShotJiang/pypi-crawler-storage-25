"""Per-user Anthropic / provider token budget gate (P0#1 Task 3).

Why this exists
---------------
Pre-P0 ``/v1/agent/run`` ran with ``max_iterations=200`` and
``max_tokens=64000``. A single malicious (or buggy) caller could
burn ~$960 of Anthropic credit in one request — no cap, no daily
limit, no per-tenant budget. This module plugs that hole:

* ``BudgetGate.check()`` runs BEFORE every provider call; raises
  :class:`BudgetExceeded` (HTTP 429 + ``Retry-After``) when the
  caller has already spent their daily / monthly allowance.
* ``BudgetGate.record()`` runs AFTER every provider call with the
  actual token counts; amortises to USD using a tiny price table
  that operators can replace via env var.

Storage is SQLite keyed on ``(user_id, YYYY-MM-DD)`` so per-day
windows roll over cleanly and a process restart does NOT zero the
spend counter (the pre-P0 naive dict-in-memory approach would).

The module is deliberately small: no LRU, no eviction — SQLite is
the LRU. Daily rows older than the monthly window are pruned by
:meth:`BudgetGate.prune_old`, which production calls from a cron
task (scripts/prune_budget.py is a future hook).
"""

from __future__ import annotations

import logging
import os
import sqlite3
import threading
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Optional

_LOG = logging.getLogger("persona.budget")

# ── Optional SQLCipher (encryption at rest) ──────
#
# GDPR / SOC2 best practice: encrypt PII-adjacent DBs at rest. The
# budget DB holds (user_id, day, tokens, usd) rows — user_id links
# to a human through the auth DB, so treat it as PII-adjacent.
#
# Wire order:
#   1. If ``pysqlcipher3`` is installed AND
#      ``SANCIO_BUDGET_DB_ENCRYPT_KEY`` is set, open the DB with
#      SQLCipher and apply ``PRAGMA key = ?``.
#   2. If the env key is set but pysqlcipher3 is missing, log a
#      loud warning and fall through to plain sqlite3. Operators
#      should fall back to filesystem-level encryption (LUKS /
#      gocryptfs / BitLocker) — see ``docs/export-control.md``.
#   3. If neither is set, plain sqlite3 — the pre-0.3.0 default.
try:  # pragma: no cover — import-guard, exercised via ENV in prod
    from pysqlcipher3 import dbapi2 as _sqlcipher  # type: ignore
    _HAS_SQLCIPHER = True
except ImportError:  # pragma: no cover
    _sqlcipher = None  # type: ignore[assignment]
    _HAS_SQLCIPHER = False


# ── Tunables (env-driven so prod can raise without a deploy) ──

_DEFAULT_DB_PATH = "/opt/persona-api/data/budget.db"
_DEFAULT_DAILY_USD = 5.0
_DEFAULT_MONTHLY_USD = 50.0

# Conservative price floor — $15/1M input + $75/1M output for
# Claude Opus tiers. Operators can override via the
# ``SANCIO_BUDGET_USD_PER_1K_TOKENS`` env var. We use the combined
# worst-case rate ($90 / 1M tokens ≈ 9e-5 USD/token) rather than
# split in/out pricing to keep the schema stable across providers
# that only report a total.
_DEFAULT_USD_PER_1K_TOKENS = 0.09


def _db_path() -> str:
    return os.environ.get("SANCIO_BUDGET_DB_PATH") or _DEFAULT_DB_PATH


def _daily_cap_usd() -> float:
    try:
        return float(os.environ.get("SANCIO_BUDGET_DAILY_USD")
                     or _DEFAULT_DAILY_USD)
    except (TypeError, ValueError):
        return _DEFAULT_DAILY_USD


def _monthly_cap_usd() -> float:
    try:
        return float(os.environ.get("SANCIO_BUDGET_MONTHLY_USD")
                     or _DEFAULT_MONTHLY_USD)
    except (TypeError, ValueError):
        return _DEFAULT_MONTHLY_USD


def _usd_per_1k_tokens() -> float:
    try:
        return float(os.environ.get("SANCIO_BUDGET_USD_PER_1K_TOKENS")
                     or _DEFAULT_USD_PER_1K_TOKENS)
    except (TypeError, ValueError):
        return _DEFAULT_USD_PER_1K_TOKENS


# ── Exception ──────────────────────────────────


class BudgetExceeded(Exception):
    """Raised when the caller has exhausted their daily / monthly cap.

    Carries an HTTP-style ``code`` (429) and a ``retry_after``
    seconds-until-midnight hint so the ``/v1/agent/run`` endpoint
    can surface a standards-compliant ``Retry-After`` header.
    """

    def __init__(
        self,
        detail: str,
        *,
        code: int = 429,
        retry_after: int = 0,
        window: str = "daily",
        spent_usd: float = 0.0,
        cap_usd: float = 0.0,
    ) -> None:
        super().__init__(detail)
        self.code = code
        self.retry_after = retry_after
        self.window = window
        self.spent_usd = spent_usd
        self.cap_usd = cap_usd


# ── Persistence ────────────────────────────────


_SCHEMA = """
CREATE TABLE IF NOT EXISTS budget_daily (
    user_id TEXT NOT NULL,
    day TEXT NOT NULL,
    tokens INTEGER NOT NULL DEFAULT 0,
    usd REAL NOT NULL DEFAULT 0,
    updated_at INTEGER NOT NULL,
    PRIMARY KEY(user_id, day)
);
CREATE INDEX IF NOT EXISTS idx_budget_daily_user
    ON budget_daily(user_id);
CREATE INDEX IF NOT EXISTS idx_budget_daily_day
    ON budget_daily(day);
"""


_WARNED_MISSING_CIPHER = False


def _connect(path: str) -> sqlite3.Connection:
    """Open the budget DB.

    When ``SANCIO_BUDGET_DB_ENCRYPT_KEY`` is set AND ``pysqlcipher3``
    is importable, use SQLCipher's ``PRAGMA key`` to encrypt at
    rest. Otherwise fall through to plain sqlite3 — compatible
    with every existing deploy, since plain sqlite3 reads the same
    file format as SQLCipher only when the key is absent.
    """
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    key = os.environ.get("SANCIO_BUDGET_DB_ENCRYPT_KEY", "").strip()
    if key and _HAS_SQLCIPHER and _sqlcipher is not None:
        conn = _sqlcipher.connect(path, isolation_level=None)
        # PRAGMA key must be the very first statement after connect.
        # Quote-escape the key so an operator-supplied key with a
        # literal ``'`` doesn't break the pragma.
        conn.execute(f"PRAGMA key = '{key.replace(chr(39), chr(39) * 2)}'")
    else:
        if key and not _HAS_SQLCIPHER:
            global _WARNED_MISSING_CIPHER
            if not _WARNED_MISSING_CIPHER:
                _LOG.warning(
                    "SANCIO_BUDGET_DB_ENCRYPT_KEY is set but "
                    "pysqlcipher3 is not installed. Budget DB is "
                    "NOT encrypted at rest. Install pysqlcipher3 or "
                    "use filesystem-level encryption (LUKS / "
                    "gocryptfs / BitLocker). See "
                    "docs/export-control.md.",
                )
                _WARNED_MISSING_CIPHER = True
        conn = sqlite3.connect(path, isolation_level=None)
    # Dict row factory works for both stdlib sqlite3 and pysqlcipher3.
    # sqlite3.Row is a C type bound to stdlib Cursor and raises
    # "TypeError: Row() argument 1 must be sqlite3.Cursor, not
    # pysqlcipher3.dbapi2.Cursor" when the sqlcipher branch is taken.
    def _dict_row(cursor: Any, row: tuple[Any, ...]) -> dict[str, Any]:
        return {desc[0]: row[idx] for idx, desc in enumerate(cursor.description)}

    conn.row_factory = _dict_row
    conn.executescript(_SCHEMA)
    return conn


# ── Time helpers (kept testable via fake ``now``) ──


def _today_utc(now: float) -> str:
    """UTC calendar day. Explicit UTC keeps rollovers predictable
    across server timezones."""
    return time.strftime("%Y-%m-%d", time.gmtime(now))


def _month_prefix(now: float) -> str:
    """UTC YYYY-MM — SQL ``LIKE`` lets us sum all days in the month
    without a second column."""
    return time.strftime("%Y-%m", time.gmtime(now))


def _seconds_to_midnight_utc(now: float) -> int:
    """How many seconds until 00:00 UTC. Used for ``Retry-After``."""
    tm = time.gmtime(now)
    secs_today = tm.tm_hour * 3600 + tm.tm_min * 60 + tm.tm_sec
    return max(1, 86400 - secs_today)


# ── Gate ───────────────────────────────────────


@dataclass
class BudgetSpend:
    """Current state for one user."""

    user_id: str
    daily_usd: float
    monthly_usd: float
    daily_cap: float
    monthly_cap: float

    @property
    def daily_remaining_usd(self) -> float:
        return max(0.0, self.daily_cap - self.daily_usd)

    @property
    def monthly_remaining_usd(self) -> float:
        return max(0.0, self.monthly_cap - self.monthly_usd)


class BudgetGate:
    """SQLite-backed per-user token/USD spend tracker.

    Thread-safe via a module-level ``threading.Lock``. We don't use
    per-user locks because SQLite's own WAL mode serialises writes
    and the contention is microscopic at this scale.
    """

    def __init__(
        self,
        db_path: Optional[str] = None,
        daily_cap_usd: Optional[float] = None,
        monthly_cap_usd: Optional[float] = None,
        usd_per_1k_tokens: Optional[float] = None,
    ) -> None:
        self._db_path = db_path or _db_path()
        self._daily_cap = (
            daily_cap_usd if daily_cap_usd is not None else _daily_cap_usd()
        )
        self._monthly_cap = (
            monthly_cap_usd if monthly_cap_usd is not None
            else _monthly_cap_usd()
        )
        self._rate = (
            usd_per_1k_tokens if usd_per_1k_tokens is not None
            else _usd_per_1k_tokens()
        )
        self._lock = threading.Lock()

    # -- public API ---------------------------------

    def check(
        self,
        user_id: str,
        estimated_tokens: int = 0,
        *,
        now: Optional[float] = None,
    ) -> BudgetSpend:
        """Raise :class:`BudgetExceeded` when spend + estimate > cap.

        Set ``estimated_tokens`` to the provider's max_tokens budget
        for the upcoming call so we pre-reject requests that are
        guaranteed to push the user over. Zero is acceptable for a
        pure status probe.
        """
        now_val = now if now is not None else time.time()
        estimated_usd = self._tokens_to_usd(estimated_tokens)

        with self._lock:
            spend = self._load_spend(user_id, now_val)

            # Daily first (most common limiter).
            projected_daily = spend.daily_usd + estimated_usd
            if projected_daily > spend.daily_cap:
                raise BudgetExceeded(
                    detail=(
                        f"daily budget exceeded for user {user_id!r}: "
                        f"${spend.daily_usd:.4f} spent + ${estimated_usd:.4f}"
                        f" est > ${spend.daily_cap:.2f} cap"
                    ),
                    retry_after=_seconds_to_midnight_utc(now_val),
                    window="daily",
                    spent_usd=spend.daily_usd,
                    cap_usd=spend.daily_cap,
                )

            projected_monthly = spend.monthly_usd + estimated_usd
            if projected_monthly > spend.monthly_cap:
                # Retry-after for monthly cap is best-effort: seconds
                # to next month-start UTC. Capped at 31 days so a
                # client never sees a >1-month hint.
                raise BudgetExceeded(
                    detail=(
                        f"monthly budget exceeded for user {user_id!r}: "
                        f"${spend.monthly_usd:.4f} spent + "
                        f"${estimated_usd:.4f} est > "
                        f"${spend.monthly_cap:.2f} cap"
                    ),
                    retry_after=_seconds_to_midnight_utc(now_val),
                    window="monthly",
                    spent_usd=spend.monthly_usd,
                    cap_usd=spend.monthly_cap,
                )
            return spend

    def record(
        self,
        user_id: str,
        actual_tokens: int,
        cost_usd: Optional[float] = None,
        *,
        now: Optional[float] = None,
    ) -> BudgetSpend:
        """Add ``actual_tokens`` (and optional USD) to the user's spend.

        Pass ``cost_usd`` when the provider returned a precise USD
        figure (Anthropic does in the response metadata). Omitting
        it falls back to ``tokens * rate``.
        """
        if actual_tokens <= 0 and not cost_usd:
            return self.get_spend(user_id, now=now)

        now_val = now if now is not None else time.time()
        day = _today_utc(now_val)
        usd = cost_usd if cost_usd is not None else self._tokens_to_usd(
            actual_tokens,
        )

        with self._lock:
            conn = _connect(self._db_path)
            try:
                conn.execute(
                    "INSERT INTO budget_daily (user_id, day, tokens, usd, updated_at)"
                    " VALUES (?, ?, ?, ?, ?)"
                    " ON CONFLICT(user_id, day) DO UPDATE SET"
                    " tokens = tokens + excluded.tokens,"
                    " usd = usd + excluded.usd,"
                    " updated_at = excluded.updated_at",
                    (user_id, day, max(0, actual_tokens), usd, int(now_val)),
                )
            finally:
                conn.close()

            return self._load_spend(user_id, now_val)

    def get_spend(
        self,
        user_id: str,
        *,
        now: Optional[float] = None,
    ) -> BudgetSpend:
        """Return the current daily + monthly spend without mutating."""
        now_val = now if now is not None else time.time()
        with self._lock:
            return self._load_spend(user_id, now_val)

    def prune_old(self, older_than_days: int = 90) -> int:
        """Delete rows older than ``older_than_days``. Returns count."""
        cutoff = time.time() - older_than_days * 86400
        cutoff_day = _today_utc(cutoff)
        with self._lock:
            conn = _connect(self._db_path)
            try:
                cur = conn.execute(
                    "DELETE FROM budget_daily WHERE day < ?",
                    (cutoff_day,),
                )
                return int(cur.rowcount or 0)
            finally:
                conn.close()

    # -- internals ----------------------------------

    def _tokens_to_usd(self, tokens: int) -> float:
        if tokens <= 0:
            return 0.0
        return (tokens / 1000.0) * self._rate

    def _load_spend(self, user_id: str, now: float) -> BudgetSpend:
        day = _today_utc(now)
        month = _month_prefix(now)
        conn = _connect(self._db_path)
        try:
            daily_row = conn.execute(
                "SELECT COALESCE(usd, 0) AS usd FROM budget_daily"
                " WHERE user_id = ? AND day = ?",
                (user_id, day),
            ).fetchone()
            monthly_row = conn.execute(
                "SELECT COALESCE(SUM(usd), 0) AS usd FROM budget_daily"
                " WHERE user_id = ? AND day LIKE ?",
                (user_id, f"{month}-%"),
            ).fetchone()
        finally:
            conn.close()

        daily_usd = float(daily_row["usd"]) if daily_row else 0.0
        monthly_usd = float(monthly_row["usd"]) if monthly_row else 0.0
        return BudgetSpend(
            user_id=user_id,
            daily_usd=daily_usd,
            monthly_usd=monthly_usd,
            daily_cap=self._daily_cap,
            monthly_cap=self._monthly_cap,
        )


# ── Module-level singleton ──────────────────────

_gate: Optional[BudgetGate] = None
_gate_lock = threading.Lock()


def get_budget_gate() -> BudgetGate:
    """Lazy singleton. Env-driven config is re-read on first use."""
    global _gate
    if _gate is None:
        with _gate_lock:
            if _gate is None:
                _gate = BudgetGate()
    return _gate


def reset_budget_gate_for_tests() -> None:
    """Drop the cached singleton. Test fixtures call this so env
    overrides take effect before the next ``get_budget_gate()``."""
    global _gate
    with _gate_lock:
        _gate = None


__all__ = [
    "BudgetExceeded",
    "BudgetGate",
    "BudgetSpend",
    "get_budget_gate",
    "reset_budget_gate_for_tests",
]
