"""persona.runtime — Sancio consumer hook for the Concinno v4 preset cascade.

@module runtime
@responsibility Receive ``apply_preset(preset_name)`` calls from
    :func:`concinno.preset_cascade.set_preset` (dispatched via the
    ``concinno.preset_consumers`` entry_points group) and translate
    each cascade preset into Sancio runtime knobs — currently:
    ``SANCIO_REQUIRE_AUTH``, audit verbosity hint, preferred provider.

    Also (2.0.0) holds the optional process-wide
    :class:`~persona.hooks.config_watcher.ConfigWatcher` reference and
    exposes :func:`attach_config_watcher` / :func:`detach_config_watcher`
    so a lifecycle owner (typically the Starlette app factory in
    :mod:`persona.api`) can start and stop the watcher in lockstep
    with the API server. Keeping the slot here, not in
    :mod:`persona.api`, lets non-API consumers (CLI, embedded
    runtimes) wire a watcher too without pulling in Starlette.
@dependencies stdlib only (no concinno import — consumer contract is
    a pure ``str -> None`` callable the library invokes). The watcher
    type is imported lazily from :mod:`persona.hooks.config_watcher`
    so this module stays cheap to import.
@exports apply_preset, KNOWN_PRESETS, get_runtime_state,
    attach_config_watcher, detach_config_watcher,
    get_active_config_watcher.

Design notes:

* **Idempotent** — same preset applied twice = same state, no side
  effects beyond the env var write.
* **Unknown preset** = ``no-op + log`` (do not raise), so a future
  Concinno ship that introduces ``"experimental"`` does not crash
  older persona-api installs still holding ``0.3.0``.
* **Env vars** are the cross-process communication primitive. The
  ``/v1/cerno/cycle`` endpoint re-reads ``SANCIO_REQUIRE_AUTH``
  per-request (see persona.auth), so flipping the env var from this
  hook takes effect immediately without a restart.
* **Audit verbosity** and **provider preference** are advisory knobs
  used by downstream modules — they read ``_RUNTIME_STATE`` at call
  time. They do NOT mutate global singletons so tests can reset
  cleanly.
* **ConfigWatcher attach/detach** are async because watcher
  ``start()`` / ``stop()`` are async — see
  :mod:`persona.hooks.config_watcher`. The attach helper is
  idempotent on the same watcher instance and refuses to overwrite
  a different running watcher (caller must detach first).
"""

from __future__ import annotations

import logging
import os
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from persona.hooks.config_watcher import ConfigWatcher

_LOG = logging.getLogger("persona.runtime")

# Known preset names → intended runtime state. Unknown names fall back
# to a no-op + warning.
KNOWN_PRESETS: dict[str, dict[str, Any]] = {
    "benchmark": {
        "sancio_require_auth": "0",
        "audit_level": "minimal",
        "provider_preference": "ollama_native",
    },
    "general": {
        "sancio_require_auth": "1",
        "audit_level": "full",
        "provider_preference": "default",
    },
    "prod": {
        "sancio_require_auth": "1",
        "audit_level": "full",
        "provider_preference": "default",
    },
}


# In-process state set by the last apply_preset() call. Downstream
# modules may read this to adjust logging / provider selection. Keeping
# it module-level (not a singleton class) makes pytest fixture reset
# trivial and avoids a new import dependency.
_RUNTIME_STATE: dict[str, Any] = {
    "active_preset": None,
    "audit_level": "full",
    "provider_preference": "default",
}


def apply_preset(name: str) -> None:
    """Cascade hook entry point. Idempotent + safe on unknown names.

    Called by :func:`concinno.preset_cascade.set_preset` through the
    ``concinno.preset_consumers`` entry_point declared in
    ``pyproject.toml`` (``sancio = "persona.runtime:apply_preset"``).
    """
    if not isinstance(name, str) or not name:
        _LOG.warning("apply_preset called with invalid name: %r", name)
        return

    spec = KNOWN_PRESETS.get(name)
    if spec is None:
        _LOG.warning(
            "apply_preset: unknown preset %r (known: %s) — no-op",
            name,
            ", ".join(sorted(KNOWN_PRESETS.keys())),
        )
        return

    # Env var (cross-process) — auth gate re-reads per request.
    try:
        os.environ["SANCIO_REQUIRE_AUTH"] = spec["sancio_require_auth"]
    except Exception as exc:  # pragma: no cover — defensive only
        _LOG.warning("apply_preset: failed to set SANCIO_REQUIRE_AUTH: %s", exc)

    # In-process advisory state.
    _RUNTIME_STATE["active_preset"] = name
    _RUNTIME_STATE["audit_level"] = spec["audit_level"]
    _RUNTIME_STATE["provider_preference"] = spec["provider_preference"]

    _LOG.info(
        "apply_preset: %s -> SANCIO_REQUIRE_AUTH=%s audit=%s provider=%s",
        name,
        spec["sancio_require_auth"],
        spec["audit_level"],
        spec["provider_preference"],
    )


def get_runtime_state() -> dict[str, Any]:
    """Return a copy of the current runtime state (read-only)."""
    return dict(_RUNTIME_STATE)


# ---------------------------------------------------------------------------
# ConfigWatcher attach slot (Sancio 2.0.0)
# ---------------------------------------------------------------------------
#
# Single process-wide slot for the active ConfigWatcher. Kept module-level
# (not a class singleton) so pytest fixtures can reset it via
# ``persona.runtime._ACTIVE_CONFIG_WATCHER = None``. The Starlette app
# factory in :mod:`persona.api` is the canonical lifecycle owner —
# ``await attach_config_watcher(w)`` in ``on_startup`` and
# ``await detach_config_watcher()`` in ``on_shutdown``.
_ACTIVE_CONFIG_WATCHER: ConfigWatcher | None = None


async def attach_config_watcher(watcher: ConfigWatcher) -> None:
    """Attach + start a :class:`ConfigWatcher` for this process.

    Idempotent on the same watcher instance: a second attach with the
    already-running watcher is a no-op. Refuses to silently replace a
    different running watcher — caller must :func:`detach_config_watcher`
    first.

    Raises
    ------
    RuntimeError
        If a *different* watcher is already attached and running.
    """
    global _ACTIVE_CONFIG_WATCHER
    current = _ACTIVE_CONFIG_WATCHER
    if current is watcher:
        # Already attached. Make sure it is started (idempotent).
        if not watcher.is_running:
            await watcher.start()
        return
    if current is not None and current.is_running:
        raise RuntimeError(
            "attach_config_watcher: another ConfigWatcher is already "
            "running; call detach_config_watcher() first"
        )
    await watcher.start()
    _ACTIVE_CONFIG_WATCHER = watcher
    _LOG.info("attach_config_watcher: started %r", watcher)


async def detach_config_watcher() -> None:
    """Stop + clear the active :class:`ConfigWatcher`, if any.

    No-op when no watcher is attached. Bounded by the watcher's own
    :data:`~persona.hooks.config_watcher.STOP_TIMEOUT_S` so a wedged
    callback cannot block runtime shutdown.
    """
    global _ACTIVE_CONFIG_WATCHER
    watcher = _ACTIVE_CONFIG_WATCHER
    if watcher is None:
        return
    try:
        await watcher.stop()
    except Exception:  # noqa: BLE001 — shutdown must always succeed
        _LOG.exception("detach_config_watcher: watcher.stop() raised (ignored)")
    finally:
        _ACTIVE_CONFIG_WATCHER = None
    _LOG.info("detach_config_watcher: stopped")


def get_active_config_watcher() -> ConfigWatcher | None:
    """Return the currently-attached watcher (or None). Read-only."""
    return _ACTIVE_CONFIG_WATCHER


__all__ = [
    "KNOWN_PRESETS",
    "apply_preset",
    "attach_config_watcher",
    "detach_config_watcher",
    "get_active_config_watcher",
    "get_runtime_state",
]
