"""Wrap :class:`MCPTool` into the Aegis :class:`Tool` protocol (A6).

``MCPClient.list_tools()`` returns MCP-native shapes
(``inputSchema``); :class:`MCPRemoteTool` adapts each to the
OpenAI-style function schema that :mod:`persona.engine.agent_loop`
expects. Tool names are prefixed (default ``"mcp_"``) so MCP tools
never clash with Aegis's stock tools — the prefix is stripped
before forwarding to :meth:`MCPClient.call_tool`.
"""

from __future__ import annotations

from typing import Any

from .client import MCPClient, MCPTool


class MCPRemoteTool:
    """Wraps one MCP tool as a local :class:`Tool`-conforming object."""

    def __init__(
        self,
        client: MCPClient,
        mcp_tool: MCPTool,
        prefix: str = "mcp_",
    ) -> None:
        self._client = client
        self._remote_name = mcp_tool.name
        self._description = mcp_tool.description
        self._input_schema = mcp_tool.input_schema
        self.name = f"{prefix}{mcp_tool.name}"

    def schema(self) -> dict[str, Any]:
        return {
            "type": "function",
            "function": {
                "name": self.name,
                "description": self._description,
                "parameters": self._input_schema
                or {"type": "object", "properties": {}},
            },
        }

    async def execute(self, args: dict[str, Any]) -> Any:
        result = await self._client.call_tool(self._remote_name, args)
        # MCP tools/call result shape: {"content": [...], "isError": bool?}.
        # Flatten the common "text content" case into a plain string so
        # LLM tool_result messages stay readable; fall back to the raw
        # result otherwise.
        content = result.get("content") if isinstance(result, dict) else None
        if isinstance(content, list) and all(
            isinstance(c, dict) and c.get("type") == "text" for c in content
        ):
            return "\n".join(c.get("text", "") for c in content)
        return result


async def load_mcp_tools(
    client: MCPClient,
    prefix: str = "mcp_",
) -> dict[str, MCPRemoteTool]:
    """Discover MCP tools and return them keyed by local (prefixed) name.

    Caller is responsible for lifecycle — call
    :meth:`MCPClient.connect` before and :meth:`MCPClient.close` when
    done.
    """
    remote_tools = await client.list_tools()
    wrapped = [MCPRemoteTool(client, t, prefix=prefix) for t in remote_tools]
    return {t.name: t for t in wrapped}


__all__ = ["MCPRemoteTool", "load_mcp_tools"]
