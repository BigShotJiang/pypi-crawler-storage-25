"""Minimal MCP (Model Context Protocol) client — stdio JSON-RPC (A6).

Implements just enough of the MCP spec (2024-11-05 protocol version)
for Aegis to connect to an MCP server subprocess, discover its
tools, and invoke them. Newline-delimited JSON-RPC 2.0 over the
server's stdio.

Intentional scope cuts for A6
-----------------------------
* **stdio transport only** — websocket / SSE transports are out of
  scope. Most real MCP servers (filesystem, github, brave-search)
  ship stdio; we lean on that.
* **No resource / prompt primitives** — tools/list + tools/call are
  the 20% of MCP that delivers 80% of the value for agent_loop.
* **No sampling (server-to-client LLM calls)** — Aegis already has
  its own LLM layer; the agent_loop never advertises this capability.
* **No progress notifications** — call_tool awaits the final
  response; long-running tool timeouts fall to the caller.

See ``persona.mcp.tool_adapter`` for wiring MCP tools into
:class:`persona.engine.agent_loop.AgentLoop`.
"""

from __future__ import annotations

import asyncio
import json
import os
from dataclasses import dataclass, field
from typing import Any

_PROTOCOL_VERSION = "2024-11-05"
_CLIENT_INFO = {"name": "sancio", "version": "1.0"}


class MCPError(RuntimeError):
    """Raised when the MCP server returns a JSON-RPC error."""

    def __init__(self, code: int, message: str, data: Any = None) -> None:
        super().__init__(f"MCP error {code}: {message}")
        self.code = code
        self.data = data


@dataclass
class MCPTool:
    """One tool advertised by the MCP server."""

    name: str
    description: str = ""
    input_schema: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_wire(cls, payload: dict[str, Any]) -> MCPTool:
        return cls(
            name=payload["name"],
            description=payload.get("description") or "",
            input_schema=payload.get("inputSchema") or {},
        )


class MCPClient:
    """Async MCP client over a child process's stdio.

    Usage::

        client = MCPClient([
            "npx", "-y",
            "@modelcontextprotocol/server-filesystem",
            "/tmp",
        ])
        await client.connect()
        tools = await client.list_tools()
        result = await client.call_tool("read_file", {"path": "a.txt"})
        await client.close()

    Not thread-safe. One client per event loop.
    """

    def __init__(
        self,
        command: list[str],
        env: dict[str, str] | None = None,
        cwd: str | None = None,
    ) -> None:
        self._command = command
        self._env = {**os.environ, **(env or {})}
        self._cwd = cwd
        self._proc: asyncio.subprocess.Process | None = None
        self._next_id = 1
        self._pending: dict[int, asyncio.Future[Any]] = {}
        self._reader_task: asyncio.Task[None] | None = None
        self._closed = False

    # ── Lifecycle ──────────────────────────────────

    async def connect(self) -> dict[str, Any]:
        """Spawn the subprocess, perform the MCP initialize handshake.

        Returns the server's ``initialize`` result payload (contains
        ``serverInfo`` + ``capabilities``). Safe to call exactly once
        per client instance.
        """
        if self._proc is not None:
            raise RuntimeError("MCPClient already connected")
        self._proc = await asyncio.create_subprocess_exec(
            *self._command,
            stdin=asyncio.subprocess.PIPE,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
            env=self._env,
            cwd=self._cwd,
        )
        self._reader_task = asyncio.create_task(self._read_loop())

        init_result = await self._request(
            "initialize",
            {
                "protocolVersion": _PROTOCOL_VERSION,
                "clientInfo": _CLIENT_INFO,
                "capabilities": {},
            },
        )
        # Per spec: notify after successful init.
        await self._notify("notifications/initialized", {})
        return init_result

    async def close(self) -> None:
        if self._closed:
            return
        self._closed = True
        if self._reader_task is not None:
            self._reader_task.cancel()
        if self._proc is not None and self._proc.returncode is None:
            try:
                self._proc.terminate()
            except ProcessLookupError:
                pass
            try:
                await asyncio.wait_for(self._proc.wait(), timeout=3.0)
            except asyncio.TimeoutError:
                self._proc.kill()
                await self._proc.wait()
        # Cancel any still-pending requests.
        for fut in self._pending.values():
            if not fut.done():
                fut.set_exception(MCPError(-32000, "client closed"))
        self._pending.clear()

    # ── High-level API ─────────────────────────────

    async def list_tools(self) -> list[MCPTool]:
        payload = await self._request("tools/list", {})
        raw = payload.get("tools") or []
        return [MCPTool.from_wire(t) for t in raw]

    async def call_tool(
        self,
        name: str,
        arguments: dict[str, Any],
    ) -> dict[str, Any]:
        """Invoke an MCP tool. Returns the raw ``result`` object."""
        return await self._request(
            "tools/call",
            {"name": name, "arguments": arguments},
        )

    # ── JSON-RPC plumbing ──────────────────────────

    async def _request(self, method: str, params: dict[str, Any]) -> Any:
        assert self._proc is not None and self._proc.stdin is not None
        req_id = self._next_id
        self._next_id += 1
        fut: asyncio.Future[Any] = asyncio.get_running_loop().create_future()
        self._pending[req_id] = fut

        payload = {
            "jsonrpc": "2.0",
            "id": req_id,
            "method": method,
            "params": params,
        }
        line = json.dumps(payload, ensure_ascii=False) + "\n"
        self._proc.stdin.write(line.encode("utf-8"))
        await self._proc.stdin.drain()
        return await fut

    async def _notify(self, method: str, params: dict[str, Any]) -> None:
        assert self._proc is not None and self._proc.stdin is not None
        payload = {
            "jsonrpc": "2.0",
            "method": method,
            "params": params,
        }
        line = json.dumps(payload, ensure_ascii=False) + "\n"
        self._proc.stdin.write(line.encode("utf-8"))
        await self._proc.stdin.drain()

    async def _read_loop(self) -> None:
        assert self._proc is not None and self._proc.stdout is not None
        stdout = self._proc.stdout
        try:
            while True:
                line = await stdout.readline()
                if not line:
                    break
                try:
                    msg = json.loads(line.decode("utf-8"))
                except json.JSONDecodeError:
                    # MCP server may print non-JSON log lines — skip.
                    continue
                self._dispatch(msg)
        except asyncio.CancelledError:
            return

    def _dispatch(self, msg: dict[str, Any]) -> None:
        # We only handle responses (requests from server → client are
        # things like sampling/createMessage which we don't advertise).
        if "id" not in msg:
            return
        req_id = msg["id"]
        fut = self._pending.pop(req_id, None)
        if fut is None or fut.done():
            return
        if "error" in msg:
            err = msg["error"]
            fut.set_exception(
                MCPError(
                    code=int(err.get("code", -32000)),
                    message=str(err.get("message", "unknown")),
                    data=err.get("data"),
                ),
            )
            return
        fut.set_result(msg.get("result"))


__all__ = ["MCPClient", "MCPError", "MCPTool"]
