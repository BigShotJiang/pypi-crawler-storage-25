"""persona.mcp.server -- Sancio in-process MCP server (stdio, 1.3.0).

Why Sancio, not Concinno
------------------------
Concinno is the cognitive **library** (CBUA pipeline, Cerno, ZIQ). It
has no transport surface. Claude Code's harness has no built-in MCP
*server* entry point either — the CC binary is an MCP *client* that
spawns external server subprocesses.

Sancio runtime owns the persona-api process surface (the ``sancio``
console script, the FastAPI/Starlette app, the dispatch glue). Adding
a stdio MCP server *under* the Sancio CLI is therefore the natural
home: external MCP clients (CC, IDE extensions, custom orchestrators)
launch ``sancio mcp start`` as a subprocess and talk to the runtime
over a stable JSON-RPC contract — no HTTP cycle, no auth race.

Scope cuts (matched to :mod:`persona.mcp.client`)
-------------------------------------------------
* stdio transport only (newline-delimited JSON-RPC 2.0)
* Protocol version pinned to ``2024-11-05``
* No resource / prompt / sampling primitives — only ``tools/list`` and
  ``tools/call``.
* Three tools exposed:

  - ``sancio.health``         — runtime health (mirrors persona-api
    /v1/health response shape).
  - ``sancio.session.list``   — enumerate Sancio session IDs from the
    SessionStore (best-effort; falls back to empty list).
  - ``sancio.persona.chat``   — proxy a chat round to the running
    persona-api ``/v1/persona/{name}/chat`` endpoint.

Auth
----
If the env var ``SANCIO_MCP_TOKEN`` is set, every ``tools/call``
request must include ``arguments["_token"]`` matching the env value
exactly. If unset, the server runs unauthenticated (intended for
local dev / smoke tests). The server NEVER reads ``initialize`` for
auth — by spec, ``initialize`` happens before any token negotiation.

Lifecycle
---------
Sync entry:: :func:`serve_stdio_blocking` runs the server until stdin
EOF or KeyboardInterrupt. The CLI subcommand
:mod:`persona.cli.mcp_cmd` calls this directly.

Public API
----------
* :class:`MCPServer` — server class with read/dispatch loop.
* :func:`serve_stdio_blocking` — sync helper for the CLI.
* :class:`MCPServerError` — JSON-RPC error sentinel raised from
  handlers; the dispatch loop converts it to a wire ``error`` object.

@module persona.mcp.server
@responsibility Build the JSON-RPC dispatch loop, expose the three
    Sancio runtime tools, enforce shared-secret auth on
    ``tools/call``, marshal results into MCP-shaped ``content`` lists.
@dependencies stdlib only (asyncio, json, os, sys, typing). Optional:
    httpx for the persona chat proxy (best-effort import — the tool
    returns a structured error if httpx is unavailable).
@exports MCPServer, MCPServerError, serve_stdio_blocking,
    PROTOCOL_VERSION, SERVER_INFO.
"""

from __future__ import annotations

import asyncio
import json
import os
import sys
from collections.abc import Awaitable, Callable
from dataclasses import dataclass
from typing import Any

PROTOCOL_VERSION = "2024-11-05"
SERVER_INFO = {"name": "sancio-mcp", "version": "1.3.0"}
SHARED_SECRET_ENV = "SANCIO_MCP_TOKEN"
PERSONA_API_DEFAULT_BASE = "http://127.0.0.1:8500"


class MCPServerError(RuntimeError):
    """Raised inside a tool handler. Mapped to a JSON-RPC error reply."""

    def __init__(self, code: int, message: str, data: Any = None) -> None:
        super().__init__(message)
        self.code = code
        self.message = message
        self.data = data


@dataclass(frozen=True)
class ToolDef:
    """One MCP tool the Sancio server exposes."""

    name: str
    description: str
    input_schema: dict[str, Any]
    handler: Callable[[dict[str, Any]], Awaitable[dict[str, Any]]]

    def to_wire(self) -> dict[str, Any]:
        return {
            "name": self.name,
            "description": self.description,
            "inputSchema": self.input_schema,
        }


# ── Built-in tool handlers ──────────────────────────────────────


async def _tool_health(_args: dict[str, Any]) -> dict[str, Any]:
    """Mirror the /v1/health response shape from persona.api._health."""
    from persona import __version__

    return {
        "ok": True,
        "service": "sancio-mcp",
        "version": __version__,
        "protocol_version": PROTOCOL_VERSION,
    }


async def _tool_session_list(_args: dict[str, Any]) -> dict[str, Any]:
    """List Sancio session IDs from the SessionStore.

    Best-effort: a missing or unreadable session store returns an
    empty list rather than failing the tool — the operator's MCP
    client should not crash because no sessions exist yet.
    """
    try:
        from persona.session_persist import SessionStore

        store = SessionStore()
        manifests = store.list_sessions()
    except Exception as exc:  # noqa: BLE001
        return {"sessions": [], "warning": f"{type(exc).__name__}: {exc}"}
    ids = [m.get("session_id") for m in manifests if m.get("session_id")]
    return {"sessions": ids}


async def _tool_persona_chat(args: dict[str, Any]) -> dict[str, Any]:
    """Proxy ``persona-api`` /v1/persona/{name}/chat over HTTP.

    Args:
        persona: persona profile name (e.g. ``ai-king``)
        message: user message text
        base_url: optional override for the persona-api base URL
                  (default ``http://127.0.0.1:8500``)
    """
    persona = args.get("persona")
    message = args.get("message")
    if not persona or not isinstance(persona, str):
        raise MCPServerError(-32602, "persona is required (str)")
    if not message or not isinstance(message, str):
        raise MCPServerError(-32602, "message is required (str)")
    base_url = args.get("base_url") or PERSONA_API_DEFAULT_BASE

    try:
        import httpx  # type: ignore[import-not-found]
    except ImportError:
        raise MCPServerError(
            -32000,
            "httpx not installed — sancio.persona.chat requires httpx",
        ) from None

    url = f"{base_url.rstrip('/')}/v1/persona/{persona}/chat"
    try:
        async with httpx.AsyncClient(timeout=30.0) as client:
            resp = await client.post(url, json={"message": message})
            resp.raise_for_status()
            data = resp.json()
    except Exception as exc:  # noqa: BLE001
        raise MCPServerError(
            -32000, f"persona chat proxy failed: {exc}"
        ) from exc
    return {"persona": persona, "response": data}


def _builtin_tools() -> list[ToolDef]:
    """Return the canonical built-in tool registry."""
    return [
        ToolDef(
            name="sancio.health",
            description="Sancio runtime health status",
            input_schema={"type": "object", "properties": {}},
            handler=_tool_health,
        ),
        ToolDef(
            name="sancio.session.list",
            description="List Sancio session IDs from the SessionStore",
            input_schema={"type": "object", "properties": {}},
            handler=_tool_session_list,
        ),
        ToolDef(
            name="sancio.persona.chat",
            description="Proxy a chat round to persona-api /v1/persona/{name}/chat",
            input_schema={
                "type": "object",
                "required": ["persona", "message"],
                "properties": {
                    "persona": {"type": "string"},
                    "message": {"type": "string"},
                    "base_url": {"type": "string"},
                },
            },
            handler=_tool_persona_chat,
        ),
    ]


# ── Server core ─────────────────────────────────────────────────


class MCPServer:
    """Sancio MCP server. JSON-RPC 2.0 over newline-delimited stdio."""

    def __init__(
        self,
        tools: list[ToolDef] | None = None,
        shared_secret: str | None = None,
    ) -> None:
        self._tools: dict[str, ToolDef] = {
            t.name: t for t in (tools if tools is not None else _builtin_tools())
        }
        self._secret: str | None = shared_secret
        self._initialized: bool = False

    @property
    def tools(self) -> dict[str, ToolDef]:
        return dict(self._tools)

    def _check_auth(self, args: dict[str, Any]) -> None:
        """If a shared secret is configured, demand a matching ``_token``.

        Raises :class:`MCPServerError` with code -32001 (auth failure)
        when the token is missing / mismatched. The token is consumed
        from ``args`` so it does not leak to the tool handler.
        """
        if self._secret is None:
            return
        token = args.pop("_token", None)
        if token != self._secret:
            raise MCPServerError(-32001, "auth required: missing or invalid _token")

    async def _handle_initialize(self, _params: dict[str, Any]) -> dict[str, Any]:
        self._initialized = True
        return {
            "protocolVersion": PROTOCOL_VERSION,
            "capabilities": {"tools": {}},
            "serverInfo": SERVER_INFO,
        }

    async def _handle_tools_list(self, _params: dict[str, Any]) -> dict[str, Any]:
        return {"tools": [t.to_wire() for t in self._tools.values()]}

    async def _handle_tools_call(
        self, params: dict[str, Any]
    ) -> dict[str, Any]:
        name = params.get("name")
        if not name or not isinstance(name, str):
            raise MCPServerError(-32602, "tools/call missing 'name'")
        tool = self._tools.get(name)
        if tool is None:
            raise MCPServerError(-32601, f"unknown tool: {name}")
        args = dict(params.get("arguments") or {})
        self._check_auth(args)
        try:
            result = await tool.handler(args)
        except MCPServerError:
            raise
        except Exception as exc:  # noqa: BLE001
            raise MCPServerError(
                -32000, f"tool {name} failed: {type(exc).__name__}: {exc}"
            ) from exc
        # Wrap structured payload in MCP "content" envelope.
        return {
            "content": [
                {"type": "text", "text": json.dumps(result, ensure_ascii=False)}
            ],
            "isError": False,
        }

    async def dispatch(self, msg: dict[str, Any]) -> dict[str, Any] | None:
        """Dispatch one JSON-RPC message. Returns the wire reply (or None).

        Notifications (no ``id``) return ``None`` per JSON-RPC spec.
        """
        method = msg.get("method")
        msg_id = msg.get("id")
        params = msg.get("params") or {}
        is_notification = "id" not in msg

        try:
            if method == "initialize":
                result = await self._handle_initialize(params)
            elif method == "tools/list":
                result = await self._handle_tools_list(params)
            elif method == "tools/call":
                result = await self._handle_tools_call(params)
            elif method == "notifications/initialized":
                # Spec: client confirms init; no response.
                return None
            elif method == "ping":
                # Optional spec method — return empty result.
                result = {}
            else:
                if is_notification:
                    return None
                return _error_reply(msg_id, -32601, f"method not found: {method}")
        except MCPServerError as exc:
            if is_notification:
                return None
            return _error_reply(
                msg_id, exc.code, exc.message, data=exc.data
            )
        except Exception as exc:  # noqa: BLE001
            if is_notification:
                return None
            return _error_reply(
                msg_id, -32000, f"internal error: {exc}"
            )

        if is_notification:
            return None
        return {"jsonrpc": "2.0", "id": msg_id, "result": result}

    async def serve(
        self,
        reader: asyncio.StreamReader,
        writer_callback: Callable[[bytes], Awaitable[None]],
    ) -> None:
        """Read JSON-RPC lines from ``reader`` until EOF."""
        while True:
            line = await reader.readline()
            if not line:
                return
            try:
                msg = json.loads(line.decode("utf-8"))
            except json.JSONDecodeError:
                continue  # ignore non-JSON noise
            reply = await self.dispatch(msg)
            if reply is not None:
                payload = json.dumps(reply, ensure_ascii=False) + "\n"
                await writer_callback(payload.encode("utf-8"))


def _error_reply(
    msg_id: Any, code: int, message: str, data: Any = None
) -> dict[str, Any]:
    err: dict[str, Any] = {"code": code, "message": message}
    if data is not None:
        err["data"] = data
    return {"jsonrpc": "2.0", "id": msg_id, "error": err}


# ── Entry points ────────────────────────────────────────────────


async def _serve_stdio_async(
    server: MCPServer | None = None,
) -> None:
    """Wrap stdin/stdout into asyncio streams + run the server."""
    server = server or MCPServer(
        shared_secret=os.environ.get(SHARED_SECRET_ENV) or None
    )
    loop = asyncio.get_running_loop()
    reader = asyncio.StreamReader()
    protocol = asyncio.StreamReaderProtocol(reader)
    await loop.connect_read_pipe(lambda: protocol, sys.stdin)

    async def _writeback(payload: bytes) -> None:
        sys.stdout.buffer.write(payload)
        sys.stdout.buffer.flush()

    await server.serve(reader, _writeback)


def serve_stdio_blocking(server: MCPServer | None = None) -> int:
    """Sync entry — blocks until stdin EOF or KeyboardInterrupt."""
    try:
        asyncio.run(_serve_stdio_async(server))
    except KeyboardInterrupt:
        return 130
    return 0


__all__ = [
    "MCPServer",
    "MCPServerError",
    "PERSONA_API_DEFAULT_BASE",
    "PROTOCOL_VERSION",
    "SERVER_INFO",
    "SHARED_SECRET_ENV",
    "ToolDef",
    "serve_stdio_blocking",
]
