"""Aegis MCP (Model Context Protocol) client layer (A6, v3 roadmap).

Public surface:

* :class:`MCPClient` — stdio-subprocess JSON-RPC client with
  ``connect`` / ``list_tools`` / ``call_tool`` / ``close``.
* :class:`MCPTool` — dataclass for one MCP-advertised tool.
* :class:`MCPError` — raised on JSON-RPC error responses.
* :class:`MCPRemoteTool` — adapter: one MCP tool as an Aegis Tool.
* :func:`load_mcp_tools` — convenience to pull the full registry.

Callers hook MCP tools into :class:`persona.engine.agent_loop.AgentLoop`
by merging the dict from :func:`load_mcp_tools` into the agent's
``tools={}``. Policy / Guards / Cerno hooks apply transparently.
"""

from __future__ import annotations

from .client import MCPClient, MCPError, MCPTool
from .tool_adapter import MCPRemoteTool, load_mcp_tools

__all__ = [
    "MCPClient",
    "MCPError",
    "MCPRemoteTool",
    "MCPTool",
    "load_mcp_tools",
]
