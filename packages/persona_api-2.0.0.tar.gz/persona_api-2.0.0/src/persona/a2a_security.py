"""A2A security primitives — the five pillars.

Each function enforces one pillar and raises :class:`A2ADenied` on
failure. DENY, never WARN. The router in :mod:`persona.a2a` catches
``A2ADenied`` and maps it to the appropriate HTTP status.

Pillars:
  1. Identity      — ``verify_identity`` (JWT or mTLS)
  2. Capability    — ``check_capability`` (allow-list lookup)
  3. Sig + replay  — ``verify_envelope_signature`` + ``NonceCache``
  4. Rate / quota  — ``RateLimiter``
  5. Audit         — ``AuditChain``
"""

from __future__ import annotations

import base64
import hashlib
import hmac
import json
import os
import threading
import time
from collections import OrderedDict
from dataclasses import dataclass
from pathlib import Path
from typing import Any

try:  # pragma: no cover — optional but recommended
    from cryptography.exceptions import InvalidSignature
    from cryptography.hazmat.primitives.asymmetric.ed25519 import (
        Ed25519PrivateKey,
        Ed25519PublicKey,
    )
    _HAS_ED25519 = True
except Exception:  # pragma: no cover
    _HAS_ED25519 = False

try:
    import jwt as _jwt  # PyJWT
    _HAS_JWT = True
except Exception:  # pragma: no cover
    _HAS_JWT = False


# ── Errors ──────────────────────────────────────


class A2ADenied(Exception):
    """All security denials flow through this. ``status`` is HTTP."""

    def __init__(self, status: int, code: str, message: str) -> None:
        super().__init__(message)
        self.status = status
        self.code = code
        self.message = message


# ── 3. Signature + replay ───────────────────────


def canonical_payload(envelope: dict) -> bytes:
    """Return the bytes that must be signed / verified.

    Strategy: drop ``signature``, sort keys, no whitespace. Stable
    across Python/Node as long as both use the JSON-canonical form.
    """
    envelope_no_sig = {k: v for k, v in envelope.items() if k != "signature"}
    return json.dumps(
        envelope_no_sig, sort_keys=True, separators=(",", ":"),
    ).encode("utf-8")


def sign_hmac(secret: bytes, envelope: dict) -> str:
    """Sign an envelope with HMAC-SHA256 → base64 string."""
    mac = hmac.new(secret, canonical_payload(envelope), hashlib.sha256)
    return base64.b64encode(mac.digest()).decode("ascii")


def verify_hmac(secret: bytes, envelope: dict) -> bool:
    sig_b64 = envelope.get("signature")
    if not sig_b64:
        return False
    try:
        sig = base64.b64decode(sig_b64)
    except Exception:
        return False
    expected = hmac.new(
        secret, canonical_payload(envelope), hashlib.sha256,
    ).digest()
    return hmac.compare_digest(sig, expected)


def sign_ed25519(private_key_b64: str, envelope: dict) -> str:
    """Sign an envelope with Ed25519 → base64 string."""
    if not _HAS_ED25519:  # pragma: no cover
        raise RuntimeError("cryptography package not available")
    raw = base64.b64decode(private_key_b64)
    pk = Ed25519PrivateKey.from_private_bytes(raw)
    sig = pk.sign(canonical_payload(envelope))
    return base64.b64encode(sig).decode("ascii")


def verify_ed25519(public_key_b64: str, envelope: dict) -> bool:
    if not _HAS_ED25519:  # pragma: no cover
        return False
    sig_b64 = envelope.get("signature")
    if not sig_b64:
        return False
    try:
        pub_raw = base64.b64decode(public_key_b64)
        sig = base64.b64decode(sig_b64)
        pk = Ed25519PublicKey.from_public_bytes(pub_raw)
        pk.verify(sig, canonical_payload(envelope))
        return True
    except (InvalidSignature, ValueError, Exception):
        return False


def check_timestamp_skew(envelope: dict, max_skew_s: int = 60) -> None:
    ts = envelope.get("timestamp")
    if not isinstance(ts, (int, float)):
        raise A2ADenied(401, "bad_timestamp", "missing or invalid timestamp")
    if abs(time.time() - float(ts)) > max_skew_s:
        raise A2ADenied(401, "timestamp_skew",
                        f"timestamp skew exceeds {max_skew_s}s")


class NonceCache:
    """Bounded LRU of seen nonces with TTL eviction.

    Thread-safe. Not durable — a restart accepts a replay from before
    the restart, which is bounded by the ±60 s timestamp check anyway.
    """

    def __init__(self, max_size: int = 10_000, ttl_s: int = 300) -> None:
        self._max_size = max_size
        self._ttl_s = ttl_s
        self._seen: OrderedDict[str, float] = OrderedDict()
        self._lock = threading.Lock()

    def _evict(self, now: float) -> None:
        # Drop expired entries (oldest first).
        while self._seen:
            nonce, expires = next(iter(self._seen.items()))
            if expires <= now:
                self._seen.popitem(last=False)
            else:
                break
        # Size cap fallback.
        while len(self._seen) > self._max_size:
            self._seen.popitem(last=False)

    def check_and_add(self, nonce: str) -> None:
        if not nonce or not isinstance(nonce, str):
            raise A2ADenied(400, "bad_nonce", "missing or invalid nonce")
        now = time.time()
        with self._lock:
            self._evict(now)
            if nonce in self._seen:
                raise A2ADenied(409, "replay", f"nonce replay: {nonce}")
            self._seen[nonce] = now + self._ttl_s

    def __len__(self) -> int:
        with self._lock:
            return len(self._seen)


# ── 1. Identity — JWT ───────────────────────────


def verify_jwt(
    token: str, public_key_b64: str, expected_aud: str,
) -> dict[str, Any]:
    """Return claims on success, raise A2ADenied otherwise.

    Uses Ed25519 (``EdDSA`` in JWT land). Claims validated:
    ``iss`` (set on the caller), ``aud`` must match ``expected_aud``,
    ``exp`` must not be in the past.
    """
    if not _HAS_JWT:  # pragma: no cover
        raise A2ADenied(500, "jwt_unavailable", "pyjwt not installed")
    try:
        pub_raw = base64.b64decode(public_key_b64)
        pk = Ed25519PublicKey.from_public_bytes(pub_raw)
        claims = _jwt.decode(
            token,
            pk,
            algorithms=["EdDSA"],
            audience=expected_aud,
            options={"require": ["iss", "aud", "exp"]},
        )
        return claims
    except _jwt.ExpiredSignatureError:
        raise A2ADenied(401, "jwt_expired", "jwt expired") from None
    except _jwt.InvalidAudienceError:
        raise A2ADenied(401, "jwt_bad_aud", "jwt audience mismatch") from None
    except _jwt.InvalidTokenError as exc:
        raise A2ADenied(401, "jwt_invalid", f"jwt invalid: {exc}") from None
    except Exception as exc:
        raise A2ADenied(401, "jwt_error", f"jwt verify failed: {exc}") from None


def issue_jwt(
    private_key_b64: str, issuer: str, audience: str, ttl_s: int = 300,
) -> str:
    """Mint a short-lived JWT (Ed25519). Used in tests + outbound calls."""
    if not _HAS_JWT:  # pragma: no cover
        raise RuntimeError("pyjwt not installed")
    now = int(time.time())
    payload = {"iss": issuer, "aud": audience, "iat": now,
               "exp": now + ttl_s}
    raw = base64.b64decode(private_key_b64)
    pk = Ed25519PrivateKey.from_private_bytes(raw)
    return _jwt.encode(payload, pk, algorithm="EdDSA")


# ── 2. Capability allow-list ────────────────────


def check_capability(
    capabilities: list[dict],
    method: str,
    tool: str | None = None,
) -> None:
    """Raise if ``method``/``tool`` is not in the advertised list."""
    for entry in capabilities:
        if entry.get("method") != method:
            continue
        if tool is None:
            return
        tools = entry.get("tools") or []
        if tool in tools:
            return
        # Method matches, tool does not — fall through to deny below.
        break
    what = method if tool is None else f"{method}:{tool}"
    raise A2ADenied(403, "capability_denied",
                    f"not advertised: {what}")


# ── 4. Rate limit + quota (hand-rolled token bucket) ──


@dataclass
class _Bucket:
    tokens: float
    capacity: float
    refill_per_s: float
    last_refill: float
    day_count: int
    day_start: float
    day_quota: int


class RateLimiter:
    """Per-agent token bucket + daily quota.

    Thread-safe. No background thread — buckets refill on demand.
    """

    def __init__(
        self,
        rpm: int = 60,
        day_quota: int = 10_000,
        overrides: dict[str, dict] | None = None,
    ) -> None:
        self._default_rpm = rpm
        self._default_day_quota = day_quota
        self._overrides = overrides or {}
        self._buckets: dict[str, _Bucket] = {}
        self._lock = threading.Lock()

    def _params(self, agent_id: str) -> tuple[int, int]:
        ov = self._overrides.get(agent_id, {})
        rpm = int(ov.get("rpm", self._default_rpm))
        day = int(ov.get("day_quota", self._default_day_quota))
        return rpm, day

    def _get_or_create(self, agent_id: str, now: float) -> _Bucket:
        b = self._buckets.get(agent_id)
        if b is None:
            rpm, day = self._params(agent_id)
            b = _Bucket(
                tokens=float(rpm),
                capacity=float(rpm),
                refill_per_s=rpm / 60.0,
                last_refill=now,
                day_count=0,
                day_start=now,
                day_quota=day,
            )
            self._buckets[agent_id] = b
        return b

    def check(self, agent_id: str) -> None:
        now = time.time()
        with self._lock:
            b = self._get_or_create(agent_id, now)
            # Daily window rollover (86400 s).
            if now - b.day_start >= 86400:
                b.day_start = now
                b.day_count = 0
            if b.day_count >= b.day_quota:
                raise A2ADenied(429, "quota_exceeded",
                                f"daily quota {b.day_quota} exceeded")
            # Refill.
            elapsed = max(0.0, now - b.last_refill)
            b.tokens = min(b.capacity, b.tokens + elapsed * b.refill_per_s)
            b.last_refill = now
            if b.tokens < 1.0:
                raise A2ADenied(429, "rate_limit",
                                "per-minute rate limit exceeded")
            b.tokens -= 1.0
            b.day_count += 1


# ── 5. Tamper-evident audit chain ───────────────


class AuditChain:
    """Append-only JSONL log with a sha256 hash chain.

    Each line is a JSON object with ``prev_hash`` (previous line's
    ``hash``) and ``hash`` = sha256(prev_hash + canonical(entry)).
    Verification: recompute each hash, flag first mismatch.
    """

    _GENESIS = "0" * 64

    def __init__(self, path: str | os.PathLike) -> None:
        self._path = Path(path)
        self._path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.Lock()
        self._last_hash: str | None = None

    def _read_last_hash(self) -> str:
        if not self._path.exists() or self._path.stat().st_size == 0:
            return self._GENESIS
        # Read last non-empty line.
        with self._path.open("rb") as f:
            f.seek(0, os.SEEK_END)
            size = f.tell()
            # Walk back up to 8 KB to find the last newline.
            window = min(8192, size)
            f.seek(size - window)
            tail = f.read(window)
        last_line = tail.splitlines()[-1] if tail.strip() else b""
        if not last_line:
            return self._GENESIS
        try:
            obj = json.loads(last_line.decode("utf-8"))
            return obj.get("hash") or self._GENESIS
        except Exception:
            return self._GENESIS

    def append(self, entry: dict) -> str:
        """Append ``entry`` with computed hash. Returns the new hash."""
        with self._lock:
            if self._last_hash is None:
                self._last_hash = self._read_last_hash()
            base = dict(entry)
            base["prev_hash"] = self._last_hash
            payload = json.dumps(
                base, sort_keys=True, separators=(",", ":"),
            ).encode("utf-8")
            new_hash = hashlib.sha256(
                self._last_hash.encode("ascii") + payload,
            ).hexdigest()
            base["hash"] = new_hash
            line = json.dumps(base, sort_keys=True,
                              separators=(",", ":"))
            with self._path.open("a", encoding="utf-8") as f:
                f.write(line + "\n")
            self._last_hash = new_hash
            return new_hash

    def verify(self) -> tuple[bool, int | None, str]:
        """Return (ok, failing_line_number, message)."""
        if not self._path.exists():
            return True, None, "empty"
        prev = self._GENESIS
        with self._path.open("r", encoding="utf-8") as f:
            for idx, raw in enumerate(f, start=1):
                if not raw.strip():
                    continue
                try:
                    obj = json.loads(raw)
                except Exception:
                    return False, idx, "json parse error"
                got_prev = obj.get("prev_hash")
                got_hash = obj.get("hash")
                if got_prev != prev:
                    return False, idx, "prev_hash mismatch"
                entry = {k: v for k, v in obj.items() if k != "hash"}
                payload = json.dumps(
                    entry, sort_keys=True, separators=(",", ":"),
                ).encode("utf-8")
                expected = hashlib.sha256(
                    prev.encode("ascii") + payload,
                ).hexdigest()
                if expected != got_hash:
                    return False, idx, "hash mismatch"
                prev = got_hash
        return True, None, "ok"


# ── Envelope-level orchestration ────────────────


REQUIRED_ENVELOPE_FIELDS = (
    "id", "from", "to", "method", "params",
    "nonce", "timestamp", "signature",
)


def validate_envelope_shape(env: dict) -> None:
    if not isinstance(env, dict):
        raise A2ADenied(400, "bad_envelope", "envelope must be object")
    missing = [k for k in REQUIRED_ENVELOPE_FIELDS if k not in env]
    if missing:
        raise A2ADenied(400, "bad_envelope",
                        f"missing fields: {','.join(missing)}")
