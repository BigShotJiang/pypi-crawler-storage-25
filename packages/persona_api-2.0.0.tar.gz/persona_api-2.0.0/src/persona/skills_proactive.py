"""Proactive Skill discovery: surface relevant Skills based on user intent.

Architecture (Sancio runtime, Week 1 deliverable per ecosystem
synthesis 2026-04-27 plan)::

    UserPromptSubmit hook
        │
        ▼
    SkillDiscovery.discover(user_prompt, k=3)
        │
        ├── 1. scan_frontmatter()          # cached 1hr, ~/.claude/skills/*/SKILL.md
        │       └─ reuse concinno.skill_parser.parse_skill_md (no PyYAML)
        │
        ├── 2. cheap_filter(prompt, manifests)
        │       └─ token-jaccard on description + triggers, top 20 narrow
        │
        ├── 3. haiku_judge(prompt, narrow, k=3)
        │       └─ Anthropic Haiku call (graceful degrade when key missing)
        │
        └── 4. emit ziq Outcome (skill_proactive.haiku_score_threshold)
                so Concinno ZIQAutoTuner can learn the threshold from
                downstream "did the user actually invoke the suggested
                Skill?" reward signal (W2 wires the consumer).

Why Sancio not Concinno (per AGENTS.md / CLAUDE.md boundary rule):
    - L6 ceiling: Concinno hooks can WARN but not deny. UserPromptSubmit
      is purely advisory by design — Concinno already ships a base
      Skill registry, and Sancio adds *proactive routing* on top so the
      same Skill set surfaces without the user typing the slash command.
    - When CC ships a runtime that lets PostToolUse hard-deny based on
      Skill misuse, this proactive surface migrates back into Concinno
      and Sancio retracts (per CLAUDE.md "Ceiling retraction rule").

Switchable per L0 #6 DoD::

    env CONCINNO_SKILL_PROACTIVE_DISABLED=1   → discover() returns []
    FEATURE_META["skill_proactive"]["enabled"] = False  (Concinno side)

Multilingual semantic matching per ``rules/L1/multilingual_triggers.md``:
    cheap_filter is intentionally token-based (cross-lingual via shared
    code identifiers + skill names); haiku_judge handles paraphrase /
    language switching natively. The user prompt language never has to
    match the skill description language.

Three-layer per L0 #6::

    Layer 1 (index)   → SkillDiscovery public API + Match dataclass
    Layer 2 (summary) → SkillManifest (parsed frontmatter only)
    Layer 3 (full)    → SKILL.md body (read on demand by caller, NOT here)

Lazy-load per L0 #6: Anthropic SDK is imported only when haiku_judge
runs and at least one cheap_filter result exists — common case (no
matches) avoids the import entirely.
"""

from __future__ import annotations

import hashlib
import json
import logging
import os
import re
import time
from collections import OrderedDict
from collections.abc import Callable, Iterable
from dataclasses import dataclass
from pathlib import Path
from typing import Any

__all__ = [
    "FEATURE_NAME",
    "Match",
    "SkillDiscovery",
    "SkillManifest",
    "is_disabled",
]

FEATURE_NAME = "skill_proactive"
_TUNABLE_THRESHOLD = "skill_proactive.haiku_score_threshold"
_DEFAULT_THRESHOLD = 0.55
_DEFAULT_TOP_K = 3
_DEFAULT_NARROW = 20
_FRONTMATTER_TTL_SEC = 3600  # 1 hour
_PROMPT_LRU_CAP = 100
_SCAN_CACHE_VERSION = 1

_log = logging.getLogger(__name__)

# Tokens that carry no discriminative power for Skill matching. Kept
# short on purpose — the cheap filter is meant to over-recall and let
# the Haiku judge tighten precision.
_STOP_TOKENS = frozenset(
    {
        "a",
        "an",
        "and",
        "are",
        "as",
        "at",
        "be",
        "by",
        "do",
        "for",
        "from",
        "have",
        "i",
        "in",
        "is",
        "it",
        "of",
        "on",
        "or",
        "that",
        "the",
        "this",
        "to",
        "use",
        "using",
        "want",
        "with",
        "you",
        "your",
        # very common zh-TW filler — matched character-by-character
        # below, but listed for documentation.
    }
)

# CJK / Latin word boundary. Splits "讀檔 read file" into
# ["讀", "檔", "read", "file"] so cheap_filter has something to match.
_TOKEN_SPLIT_RE = re.compile(r"[A-Za-z0-9_]+|[一-鿿぀-ヿ가-힯]")


# ── Disabled gate ──────────────────────────────────────────────────


def is_disabled() -> bool:
    """Return True when proactive Skill discovery is opted out.

    Honoured sources (any one is sufficient):

    * env ``CONCINNO_SKILL_PROACTIVE_DISABLED`` truthy
    * Concinno ``FEATURE_META["skill_proactive"]["enabled"] = False``
      (best-effort import; missing module = enabled by default so Sancio
      can run without the full Concinno install)
    """
    raw = os.environ.get("CONCINNO_SKILL_PROACTIVE_DISABLED", "").strip().lower()
    if raw in {"1", "true", "yes", "on"}:
        return True
    try:  # pragma: no cover - depends on Concinno install
        from concinno.feature_config import meta_enabled_default  # noqa: PLC0415

        if not meta_enabled_default(FEATURE_NAME):
            return True
    except Exception:
        # Concinno not installed or older version without the registry —
        # fall through to enabled by default. Tests pin via env.
        pass
    return False


# ── Dataclasses ────────────────────────────────────────────────────


@dataclass(frozen=True)
class SkillManifest:
    """Lightweight summary of a single SKILL.md frontmatter block.

    Only fields needed for matching are stored — full body is left on
    disk so the typical "match miss" case doesn't pay for body load.
    """

    name: str
    description: str
    triggers: tuple[str, ...]
    path: Path

    @property
    def search_blob(self) -> str:
        """Concatenate searchable text for cheap filtering."""
        return " ".join((self.name, self.description, *self.triggers)).lower()


@dataclass(frozen=True)
class Match:
    """One Skill recommendation."""

    skill_name: str
    score: float
    reason: str
    path: Path | None = None


@dataclass
class _CacheEntry:
    skills: list[SkillManifest]
    scanned_at: float
    skills_root_resolved: str

    def is_fresh(self, now: float, ttl: float) -> bool:
        return (now - self.scanned_at) <= ttl


# ── Public API ─────────────────────────────────────────────────────


class SkillDiscovery:
    """Discover Skills semantically relevant to a user prompt.

    The discovery flow is intentionally **two-tier**:

    1. ``cheap_filter`` — pure-Python token Jaccard, top-N narrow. Cost
       is sub-millisecond on 65 Skills, so it runs every UserPromptSubmit
       hook even when the Anthropic key is absent.
    2. ``haiku_judge`` — single Anthropic Haiku call ranking the narrow
       set against the user prompt. Skipped (gracefully) when no API key
       is configured or the ``anthropic`` package is missing.

    Cross-session cache lives in ``~/.concinno/skill_proactive_cache.json``
    and stores both the frontmatter scan and the per-prompt-hash judge
    result (LRU-trimmed at 100 entries — bigger caches are not worth the
    disk I/O at this stage).

    Tests typically inject ``skills_root=tmp_path`` and a fake Haiku
    ``judge_fn`` to bypass network entirely.
    """

    def __init__(
        self,
        skills_root: Path | None = None,
        cache_path: Path | None = None,
        ttl_seconds: float = _FRONTMATTER_TTL_SEC,
        prompt_cache_capacity: int = _PROMPT_LRU_CAP,
        judge_fn: JudgeFn | None = None,
    ) -> None:
        self._skills_root = (
            Path(skills_root).expanduser()
            if skills_root is not None
            else Path.home() / ".claude" / "skills"
        )
        self._cache_path = (
            Path(cache_path).expanduser()
            if cache_path is not None
            else Path.home() / ".concinno" / "skill_proactive_cache.json"
        )
        self._ttl = float(ttl_seconds)
        self._prompt_cap = int(prompt_cache_capacity)
        # When ``judge_fn`` is supplied it bypasses the Anthropic call
        # entirely — the test path uses this to avoid network. Production
        # leaves it None so :meth:`_default_haiku_judge` is used.
        self._injected_judge: JudgeFn | None = judge_fn
        # In-memory caches, hydrated lazily from disk on first use.
        self._scan_cache: _CacheEntry | None = None
        self._prompt_cache: OrderedDict[str, list[Match]] = OrderedDict()
        self._cache_loaded: bool = False

    # ── Frontmatter scan ──────────────────────────────────

    def scan_frontmatter(self, *, force: bool = False) -> list[SkillManifest]:
        """Return cached or freshly-parsed SkillManifest list.

        Re-scans when:

        * ``force=True``
        * cache is stale (``ttl_seconds`` exceeded)
        * cache root differs from current ``skills_root`` (test isolation)
        """
        self._ensure_cache_loaded()
        now = time.time()
        resolved_root = str(self._skills_root.resolve())
        cache = self._scan_cache
        if (
            not force
            and cache is not None
            and cache.is_fresh(now, self._ttl)
            and cache.skills_root_resolved == resolved_root
        ):
            return list(cache.skills)

        skills = self._scan_disk()
        self._scan_cache = _CacheEntry(
            skills=skills,
            scanned_at=now,
            skills_root_resolved=resolved_root,
        )
        self._persist_cache()
        return list(skills)

    def _scan_disk(self) -> list[SkillManifest]:
        root = self._skills_root
        if not root.exists() or not root.is_dir():
            return []
        manifests: list[SkillManifest] = []
        for skill_dir in sorted(p for p in root.iterdir() if p.is_dir()):
            skill_md = skill_dir / "SKILL.md"
            if not skill_md.is_file():
                continue
            try:
                meta = _parse_skill_md(skill_md)
            except Exception as exc:  # pragma: no cover - defensive
                _log.debug("skills_proactive: skip %s (%s)", skill_md, exc)
                continue
            if not isinstance(meta, dict):
                continue
            name = str(meta.get("name") or skill_dir.name).strip()
            if not name:
                continue
            description = str(meta.get("description") or "").strip()
            triggers_raw = meta.get("triggers") or []
            if isinstance(triggers_raw, str):
                triggers_raw = [triggers_raw]
            triggers: tuple[str, ...] = tuple(
                str(t).strip() for t in triggers_raw if str(t).strip()
            )
            manifests.append(
                SkillManifest(
                    name=name,
                    description=description,
                    triggers=triggers,
                    path=skill_md,
                ),
            )
        return manifests

    # ── Cheap filter ──────────────────────────────────────

    def cheap_filter(
        self,
        user_prompt: str,
        skills: Iterable[SkillManifest],
        narrow_to: int = _DEFAULT_NARROW,
    ) -> list[SkillManifest]:
        """Token-Jaccard pre-filter. Returns at most ``narrow_to`` skills.

        Stable order: by descending score, then ascending name (so the
        same input always picks the same skills, which keeps the prompt
        cache stable across sessions).
        """
        prompt_tokens = _tokenise(user_prompt)
        if not prompt_tokens:
            return []
        scored: list[tuple[float, str, SkillManifest]] = []
        for sm in skills:
            blob = sm.search_blob
            sk_tokens = _tokenise(blob)
            if not sk_tokens:
                continue
            score = _jaccard(prompt_tokens, sk_tokens)
            if score <= 0.0:
                # Substring fallback for short prompts where Jaccard
                # underflows to 0 because every token is split — gives
                # us a non-zero signal when the prompt mentions the
                # skill name verbatim.
                lowered = user_prompt.lower()
                if sm.name.lower() in lowered:
                    score = 0.05
            if score > 0.0:
                scored.append((score, sm.name, sm))
        scored.sort(key=lambda t: (-t[0], t[1]))
        return [sm for _, _, sm in scored[:narrow_to]]

    # ── Haiku judge ───────────────────────────────────────

    def haiku_judge(
        self,
        user_prompt: str,
        skills: list[SkillManifest],
        k: int = _DEFAULT_TOP_K,
    ) -> list[Match]:
        """Return up to ``k`` semantically-best Matches.

        Behaviour:

        * Empty ``skills`` → ``[]`` (nothing to rank).
        * Injected ``judge_fn`` (test path) → honoured directly.
        * No ``ANTHROPIC_API_KEY`` env or ``anthropic`` package missing
          → graceful degrade: return cheap-filter top-k as Matches with
          score copied from filter and ``reason="cheap-filter only"``.
        * Anthropic SDK call → JSON parsed and validated.
        """
        if not skills:
            return []
        judge = self._injected_judge or self._default_haiku_judge
        try:
            raw = judge(user_prompt, skills, k)
        except Exception as exc:  # pragma: no cover - defensive
            _log.warning("skills_proactive: judge raised %r — degrading", exc)
            return self._degraded_matches(user_prompt, skills, k)
        if raw is None:
            return self._degraded_matches(user_prompt, skills, k)
        cleaned: list[Match] = []
        seen: set[str] = set()
        for entry in raw:
            name = str(entry.get("skill_name", "")).strip()
            if not name or name in seen:
                continue
            try:
                score = float(entry.get("score", 0.0))
            except (TypeError, ValueError):
                continue
            score = max(0.0, min(1.0, score))
            reason = str(entry.get("reason", "")).strip() or "haiku judge"
            sm = next((s for s in skills if s.name == name), None)
            cleaned.append(
                Match(
                    skill_name=name,
                    score=score,
                    reason=reason,
                    path=sm.path if sm else None,
                ),
            )
            seen.add(name)
            if len(cleaned) >= k:
                break
        if not cleaned:
            return self._degraded_matches(user_prompt, skills, k)
        return cleaned

    def _default_haiku_judge(
        self,
        user_prompt: str,
        skills: list[SkillManifest],
        k: int,
    ) -> list[dict[str, Any]] | None:
        """Real Anthropic call. Returns None when SDK / key absent.

        Lazy-imports ``anthropic`` so Sancio can run without the SDK
        installed (the cheap-filter path then handles every prompt).
        """
        api_key = os.environ.get("ANTHROPIC_API_KEY", "").strip()
        if not api_key:
            return None
        try:
            import anthropic  # noqa: PLC0415  (lazy)
        except ImportError:
            return None
        client = anthropic.Anthropic(api_key=api_key)
        catalogue = "\n".join(
            f"- {s.name}: {s.description}" for s in skills if s.description
        )
        system_prompt = (
            "You rank Anthropic-style Skills by semantic match to a user prompt. "
            "Match by meaning across languages — the user prompt may be in any "
            "language while skill descriptions are in English. "
            "Return STRICT JSON: an array of objects with keys "
            '"skill_name", "score" (0..1), "reason" (≤20 words). '
            f"Return at most {k} entries, descending score. No prose, no markdown."
        )
        user_msg = (
            f"User prompt:\n{user_prompt}\n\nCandidate skills:\n{catalogue}\n\n"
            f"Top {k} matches as JSON array."
        )
        try:
            resp = client.messages.create(
                model="claude-haiku-4-5",
                max_tokens=512,
                system=system_prompt,
                messages=[{"role": "user", "content": user_msg}],
            )
        except Exception as exc:  # pragma: no cover - network
            _log.warning("skills_proactive: haiku call failed %r", exc)
            return None
        text = _extract_text(resp)
        return _parse_judge_json(text)

    def _degraded_matches(
        self,
        user_prompt: str,
        skills: list[SkillManifest],
        k: int,
    ) -> list[Match]:
        """Cheap-filter-only fallback when Haiku is unavailable."""
        prompt_tokens = _tokenise(user_prompt)
        out: list[Match] = []
        for sm in skills[:k]:
            sk_tokens = _tokenise(sm.search_blob)
            score = _jaccard(prompt_tokens, sk_tokens) if sk_tokens else 0.0
            out.append(
                Match(
                    skill_name=sm.name,
                    score=score,
                    reason="cheap-filter only (no Haiku)",
                    path=sm.path,
                ),
            )
        return out

    # ── Top-level discover ────────────────────────────────

    def discover(
        self,
        user_prompt: str,
        k: int = _DEFAULT_TOP_K,
    ) -> list[Match]:
        """Return the top-K relevant Skills for the user prompt.

        No-op (returns ``[]``) when the feature is disabled. Honours
        the prompt LRU cache so multiple hooks per session don't repeat
        the Haiku call.
        """
        if is_disabled():
            return []
        prompt = (user_prompt or "").strip()
        if not prompt:
            return []
        self._ensure_cache_loaded()
        prompt_hash = _hash_prompt(prompt, k)
        cached = self._prompt_cache.get(prompt_hash)
        if cached is not None:
            self._prompt_cache.move_to_end(prompt_hash)
            return list(cached)

        manifests = self.scan_frontmatter()
        if not manifests:
            self._cache_prompt_result(prompt_hash, [])
            return []
        narrow = self.cheap_filter(prompt, manifests, narrow_to=_DEFAULT_NARROW)
        if not narrow:
            self._cache_prompt_result(prompt_hash, [])
            return []
        matches = self.haiku_judge(prompt, narrow, k=k)
        # Apply learned threshold (best-effort; missing autotune registry
        # falls back to the static default).
        threshold = _resolve_threshold()
        filtered = [m for m in matches if m.score >= threshold]
        if not filtered and matches:
            # Always surface at least the top match when the judge
            # produced *something*, otherwise the discovery is invisible
            # the moment the threshold is set conservatively. The
            # subsequent reward signal then teaches FTRL to widen.
            filtered = [matches[0]]
        self._cache_prompt_result(prompt_hash, filtered)
        _emit_outcome(
            tunable=_TUNABLE_THRESHOLD,
            value=threshold,
            reward=0.0,  # placeholder — real reward arrives later via
                        # ``record_skill_usage`` from the agent loop.
            metadata={
                "matches": [m.skill_name for m in filtered],
                "narrow_count": len(narrow),
                "manifest_count": len(manifests),
            },
        )
        return list(filtered)

    # ── Reward feedback ───────────────────────────────────

    def record_skill_usage(
        self,
        prompt: str,
        skill_name: str,
        used: bool,
    ) -> None:
        """Emit the downstream reward for a previously surfaced match.

        The agent loop is expected to call this when it observes a
        ``Skill`` invocation (or the lack thereof) shortly after a
        proactive hint was injected. ``used=True`` produces reward 1.0,
        ``used=False`` produces 0.0 — Concinno FTRL will adjust the
        threshold over time.
        """
        if is_disabled():
            return
        _emit_outcome(
            tunable=_TUNABLE_THRESHOLD,
            value=_resolve_threshold(),
            reward=1.0 if used else 0.0,
            metadata={
                "skill_name": skill_name,
                "prompt_hash": _hash_prompt(prompt, _DEFAULT_TOP_K),
            },
        )

    # ── Cache plumbing ────────────────────────────────────

    def _ensure_cache_loaded(self) -> None:
        if self._cache_loaded:
            return
        self._cache_loaded = True
        path = self._cache_path
        if not path.exists():
            return
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            # Corrupt cache: truncate so next persist replaces it.
            try:
                path.unlink()
            except OSError:
                pass
            return
        if not isinstance(data, dict):
            return
        if data.get("version") != _SCAN_CACHE_VERSION:
            return
        scan = data.get("frontmatter_scan") or {}
        if isinstance(scan, dict) and scan.get("skills_root") == str(
            self._skills_root.resolve(),
        ):
            try:
                manifests = [
                    SkillManifest(
                        name=str(s["name"]),
                        description=str(s.get("description", "")),
                        triggers=tuple(s.get("triggers", ())),
                        path=Path(s["path"]),
                    )
                    for s in scan.get("skills", [])
                    if isinstance(s, dict) and s.get("name")
                ]
            except (KeyError, TypeError, ValueError):
                manifests = []
            scanned_at = float(scan.get("scanned_at", 0.0))
            self._scan_cache = _CacheEntry(
                skills=manifests,
                scanned_at=scanned_at,
                skills_root_resolved=str(self._skills_root.resolve()),
            )
        prompts = data.get("prompt_cache") or []
        if isinstance(prompts, list):
            for entry in prompts[-self._prompt_cap :]:
                if not isinstance(entry, dict):
                    continue
                key = entry.get("hash")
                payload = entry.get("matches") or []
                if not isinstance(key, str) or not isinstance(payload, list):
                    continue
                try:
                    matches = [
                        Match(
                            skill_name=str(m["skill_name"]),
                            score=float(m.get("score", 0.0)),
                            reason=str(m.get("reason", "")),
                            path=Path(m["path"]) if m.get("path") else None,
                        )
                        for m in payload
                        if isinstance(m, dict) and m.get("skill_name")
                    ]
                except (KeyError, TypeError, ValueError):
                    continue
                self._prompt_cache[key] = matches

    def _cache_prompt_result(self, key: str, matches: list[Match]) -> None:
        self._prompt_cache[key] = matches
        self._prompt_cache.move_to_end(key)
        while len(self._prompt_cache) > self._prompt_cap:
            self._prompt_cache.popitem(last=False)
        self._persist_cache()

    def _persist_cache(self) -> None:
        path = self._cache_path
        try:
            path.parent.mkdir(parents=True, exist_ok=True)
        except OSError:
            return
        scan_payload: dict[str, Any] = {}
        if self._scan_cache is not None:
            scan_payload = {
                "skills_root": self._scan_cache.skills_root_resolved,
                "scanned_at": self._scan_cache.scanned_at,
                "skills": [
                    {
                        "name": s.name,
                        "description": s.description,
                        "triggers": list(s.triggers),
                        "path": str(s.path),
                    }
                    for s in self._scan_cache.skills
                ],
            }
        prompt_payload = [
            {
                "hash": key,
                "matches": [
                    {
                        "skill_name": m.skill_name,
                        "score": m.score,
                        "reason": m.reason,
                        "path": str(m.path) if m.path else None,
                    }
                    for m in matches
                ],
            }
            for key, matches in self._prompt_cache.items()
        ]
        try:
            path.write_text(
                json.dumps(
                    {
                        "version": _SCAN_CACHE_VERSION,
                        "frontmatter_scan": scan_payload,
                        "prompt_cache": prompt_payload,
                    },
                    indent=2,
                    sort_keys=False,
                ),
                encoding="utf-8",
            )
        except OSError:
            pass


# ── Helpers ────────────────────────────────────────────────────────


# Type hint for an injected judge function (test seam). Returns either
# a list of dicts (raw judge output) or None (degrade signal).
JudgeFn = Callable[[str, list[SkillManifest], int], "list[dict[str, Any]] | None"]


def _tokenise(text: str) -> set[str]:
    """Lowercase Latin tokens + per-character CJK splits, minus stopwords."""
    if not text:
        return set()
    raw = _TOKEN_SPLIT_RE.findall(text.lower())
    return {tok for tok in raw if tok and tok not in _STOP_TOKENS}


def _jaccard(a: set[str], b: set[str]) -> float:
    if not a or not b:
        return 0.0
    inter = a & b
    union = a | b
    if not union:
        return 0.0
    return len(inter) / len(union)


def _hash_prompt(prompt: str, k: int) -> str:
    h = hashlib.blake2b(digest_size=8)
    h.update(prompt.encode("utf-8", errors="replace"))
    h.update(b"|")
    h.update(str(int(k)).encode("ascii"))
    return h.hexdigest()


def _parse_skill_md(path: Path) -> dict[str, Any]:
    """Reuse Concinno's parser if available; otherwise minimal fallback.

    Lazy import to avoid hard-coupling Sancio tests to a Concinno install
    (CI without Concinno still parses the obvious cases).
    """
    try:
        from concinno.skill_parser import parse_skill_md  # noqa: PLC0415

        result = parse_skill_md(path)
    except ImportError:
        return _parse_skill_md_fallback(path)
    return result if isinstance(result, dict) else {}


def _parse_skill_md_fallback(path: Path) -> dict[str, Any]:
    """Tiny YAML-lite parser used only when Concinno is missing.

    Handles ``name:``, ``description:``, ``triggers: [...]`` inline
    lists. Block-list form is intentionally NOT supported — full
    fidelity lives in concinno.skill_parser. CI without Concinno will
    still parse the bulk of skills.
    """
    try:
        text = path.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return {}
    if not text.startswith("---"):
        return {}
    rest = text[3:].lstrip("\r\n")
    end = rest.find("\n---")
    if end < 0:
        return {}
    body = rest[:end]
    out: dict[str, Any] = {}
    for line in body.splitlines():
        line = line.strip()
        if not line or ":" not in line:
            continue
        key, _, value = line.partition(":")
        key = key.strip()
        value = value.strip()
        if value.startswith("[") and value.endswith("]"):
            items = [
                v.strip().strip("'\"")
                for v in value[1:-1].split(",")
                if v.strip()
            ]
            out[key] = items
        elif value:
            if (
                len(value) >= 2
                and value[0] == value[-1]
                and value[0] in {"'", '"'}
            ):
                value = value[1:-1]
            out[key] = value
    return out


def _extract_text(resp: Any) -> str:
    """Pull the first text block out of an Anthropic Messages response.

    Tolerates both the SDK object shape (``resp.content[i].text``) and
    a plain dict shape (used by some tests / fakes).
    """
    content = getattr(resp, "content", None)
    if content is None and isinstance(resp, dict):
        content = resp.get("content")
    if not content:
        return ""
    for block in content:
        text = getattr(block, "text", None)
        if text is None and isinstance(block, dict):
            text = block.get("text")
        if isinstance(text, str) and text.strip():
            return text
    return ""


def _parse_judge_json(text: str) -> list[dict[str, Any]] | None:
    """Parse the JSON array returned by haiku_judge.

    Strips common markdown fences (``` ```json ... ``` ```). Returns
    None on parse error so the caller can degrade gracefully.
    """
    if not text:
        return None
    cleaned = text.strip()
    if cleaned.startswith("```"):
        # Remove the leading fence (with optional language tag) and any
        # trailing fence.
        cleaned = cleaned.split("\n", 1)[1] if "\n" in cleaned else ""
        if cleaned.endswith("```"):
            cleaned = cleaned[:-3]
    cleaned = cleaned.strip()
    try:
        data = json.loads(cleaned)
    except json.JSONDecodeError:
        return None
    if not isinstance(data, list):
        return None
    return [d for d in data if isinstance(d, dict)]


def _resolve_threshold() -> float:
    """Return the current ZIQ-tuned threshold, or default.

    Uses the autotune registry's pinned/learned value when available;
    falls back to ``_DEFAULT_THRESHOLD`` so this module is fully usable
    against pre-2.36 Concinno installs.
    """
    try:  # pragma: no cover - depends on Concinno install
        from concinno.ziq_outcome_bus import get_bus  # noqa: PLC0415

        pinned = get_bus().pinned_value(_TUNABLE_THRESHOLD)
        if isinstance(pinned, (int, float)):
            return max(0.0, min(1.0, float(pinned)))
    except Exception:
        pass
    return _DEFAULT_THRESHOLD


def _emit_outcome(
    *,
    tunable: str,
    value: float,
    reward: float,
    metadata: dict[str, Any] | None = None,
) -> None:
    """Best-effort emit to the Concinno ZIQ outcome bus.

    Silent on import failure (older Concinno without the bus). Errors
    must never break the proactive surface.
    """
    try:  # pragma: no cover - depends on Concinno install
        from concinno.ziq_outcome_bus import Outcome  # noqa: PLC0415
        from concinno.ziq_outcome_bus import emit as _emit_decorator  # noqa: F401, PLC0415
        from concinno.ziq_outcome_bus import get_bus  # noqa: PLC0415

        get_bus().emit(
            Outcome(
                tunable=tunable,
                value=float(value),
                reward=float(reward),
                metadata=metadata or {},
                source="sancio.skills_proactive",
            ),
        )
    except Exception as exc:  # pragma: no cover - defensive
        _log.debug("skills_proactive: emit skipped (%s)", exc)
