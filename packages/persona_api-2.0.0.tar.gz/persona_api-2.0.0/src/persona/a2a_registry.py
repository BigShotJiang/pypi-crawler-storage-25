"""A2A peer registry — persistent map of known agents.

Stores `{agent_id -> {endpoint, public_key_b64, last_seen,
capabilities_cache, capabilities_cache_at}}` in JSON at
``data/a2a_peers.json`` by default.
"""

from __future__ import annotations

import json
import threading
import time
from dataclasses import asdict, dataclass, field
from pathlib import Path


@dataclass
class PeerRecord:
    agent_id: str
    endpoint: str
    public_key_b64: str
    last_seen: float = 0.0
    capabilities_cache: list[dict] = field(default_factory=list)
    capabilities_cache_at: float = 0.0
    # Optional per-peer HMAC secret (base64). When set, HMAC sig
    # verification is also accepted in addition to Ed25519.
    hmac_secret_b64: str = ""
    rate_limit_override: dict = field(default_factory=dict)


class PeerRegistry:
    """Thread-safe peer store with JSON persistence."""

    def __init__(self, path: str | Path = "data/a2a_peers.json") -> None:
        self._path = Path(path)
        self._lock = threading.Lock()
        self._peers: dict[str, PeerRecord] = {}
        self._load()

    def _load(self) -> None:
        if not self._path.exists():
            return
        try:
            data = json.loads(self._path.read_text(encoding="utf-8"))
        except Exception:
            return
        for agent_id, body in data.items():
            body = dict(body)
            body.setdefault("agent_id", agent_id)
            # Filter to known fields (forward-compat when adding columns).
            known = {
                "agent_id", "endpoint", "public_key_b64", "last_seen",
                "capabilities_cache", "capabilities_cache_at",
                "hmac_secret_b64", "rate_limit_override",
            }
            filtered = {k: v for k, v in body.items() if k in known}
            self._peers[agent_id] = PeerRecord(**filtered)

    def _save_locked(self) -> None:
        self._path.parent.mkdir(parents=True, exist_ok=True)
        payload = {aid: asdict(p) for aid, p in self._peers.items()}
        tmp = self._path.with_suffix(self._path.suffix + ".tmp")
        tmp.write_text(
            json.dumps(payload, indent=2, sort_keys=True),
            encoding="utf-8",
        )
        tmp.replace(self._path)

    def get(self, agent_id: str) -> PeerRecord | None:
        with self._lock:
            return self._peers.get(agent_id)

    def upsert(self, peer: PeerRecord) -> None:
        with self._lock:
            self._peers[peer.agent_id] = peer
            self._save_locked()

    def touch(self, agent_id: str) -> None:
        with self._lock:
            p = self._peers.get(agent_id)
            if p:
                p.last_seen = time.time()
                self._save_locked()

    def set_capabilities_cache(
        self, agent_id: str, capabilities: list[dict],
    ) -> None:
        with self._lock:
            p = self._peers.get(agent_id)
            if not p:
                return
            p.capabilities_cache = capabilities
            p.capabilities_cache_at = time.time()
            self._save_locked()

    def all(self) -> dict[str, PeerRecord]:
        with self._lock:
            return dict(self._peers)
