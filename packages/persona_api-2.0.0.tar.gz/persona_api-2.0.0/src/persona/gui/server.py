"""FastAPI backend for the Sancio runtime observability GUI.

@module persona.gui.server
@responsibility Expose a tiny localhost-only REST surface over the
    Sancio runtime — active session ids tracked by the dispatcher cache,
    per-session OutcomeRecord history, discovered event_bindings,
    runtime preset state. **Read-only** by design: no POSTs, no
    config mutation. Concinno's GUI (port 8400) owns config writes;
    this GUI (port 8401) is for observability.

Design notes:

* Mirrors :mod:`concinno.gui.server` patterns (``create_app`` factory,
  per-process bearer token written to disk, ``BearerTokenMiddleware``,
  ``/api/health`` bypass) but **does not import** the FastAPI app
  builder from there — that one is pinned to FEATURE_META + harness
  routes which are not Sancio-runtime relevant.
* Re-uses :mod:`concinno.gui.auth` for the audited token utilities
  (atomic write, OS-aware chmod 0600, hmac.compare_digest verify).
  The token *path* differs (``~/.sancio/gui_token``) — passed via the
  ``path=`` override parameter the auth module already supports.
* Loopback default. ``--host 0.0.0.0`` requires
  ``SANCIO_GUI_ALLOW_PUBLIC_BIND=1`` env var (mirrors concinno's
  ``CONCINNO_GUI_ALLOW_PUBLIC_BIND`` discipline).
* Frontend stub: ``GET /`` returns inline minimal HTML pointing at the
  VS Code iframe target. Full vanilla-JS frontend lands in Phase 4.
"""

from __future__ import annotations

import logging
import os
import sys
from pathlib import Path
from typing import Any, Optional

try:
    from fastapi import FastAPI, HTTPException, Request
    from fastapi.responses import HTMLResponse, JSONResponse
    from starlette.middleware.base import BaseHTTPMiddleware
except ImportError as _err:  # pragma: no cover — optional dep
    raise ImportError(
        "persona.gui requires FastAPI. Install with `pip install fastapi`."
    ) from _err

from concinno.gui import auth as _auth

_logger = logging.getLogger(__name__)

# Routes hit without auth (loopback liveness probes before token read).
_AUTH_BYPASS_PATHS = frozenset({"/api/health", "/"})


def get_sancio_token_path() -> Path:
    """Return the OS-appropriate path for the Sancio GUI bearer token.

    Mirrors :func:`concinno.gui.auth.get_token_path` except the directory
    name is ``sancio`` rather than ``concinno`` so the two GUIs do not
    share a token file. (A federated switcher reads both.)
    """
    if sys.platform == "win32":
        local_app = os.environ.get("LOCALAPPDATA")
        if local_app:
            return Path(local_app) / "sancio" / "gui_token"
    return Path.home() / ".sancio" / "gui_token"


class BearerTokenMiddleware(BaseHTTPMiddleware):
    """Reject any request whose ``Authorization: Bearer …`` header does
    not match the in-process expected token.

    Bypass paths (kept narrow) live in :data:`_AUTH_BYPASS_PATHS` --
    ``/api/health`` is exempt so loopback liveness probes can run before
    a client has read the token from disk; ``/`` returns the stub HTML
    landing page for unauthenticated browser visits.

    Mirrors :class:`concinno.gui.server.BearerTokenMiddleware`. We
    deliberately copy the ~15-LoC middleware shell rather than import
    it, because doing so would pull all of concinno.gui.server's
    config-mutation routes in via the import side-effects. The actual
    constant-time token comparison delegates to
    :func:`concinno.gui.auth.verify_token_header` (the audited helper).
    """

    def __init__(self, app, expected_token: str) -> None:
        super().__init__(app)
        self._expected = expected_token

    async def dispatch(self, request: Request, call_next):
        if request.url.path in _AUTH_BYPASS_PATHS:
            return await call_next(request)
        header = request.headers.get("authorization")
        if not _auth.verify_token_header(header, self._expected):
            return JSONResponse(
                {"detail": "missing or invalid bearer token"},
                status_code=401,
            )
        return await call_next(request)


# ── route builders ──────────────────────────────────────────────


def _register_health_route(app: "FastAPI") -> None:
    @app.get("/api/health")
    def health() -> JSONResponse:
        return JSONResponse({"status": "ok", "service": "sancio-gui"})


def _register_landing_page(app: "FastAPI") -> None:
    @app.get("/", response_class=HTMLResponse)
    def landing() -> HTMLResponse:
        token_path = get_sancio_token_path()
        body = f"""<!doctype html>
<html><head><meta charset="utf-8"><title>Sancio GUI</title></head>
<body style="font-family: system-ui, sans-serif; padding: 2em; max-width: 720px; margin: 0 auto;">
<h1>Sancio GUI v0.1</h1>
<p>Sancio runtime observability surface (read-only).</p>
<p>Default port: <code>8401</code>. This is the <em>persona-api / Sancio</em>
GUI. The Concinno config GUI lives on port <code>8400</code>.</p>
<p>Bearer token (clients only — value never echoed in logs):
<code>{token_path}</code></p>
<p>Routes (all require <code>Authorization: Bearer &lt;token&gt;</code> except
<code>/api/health</code> and <code>/</code>):</p>
<ul>
<li><code>GET /api/health</code></li>
<li><code>GET /api/runtime/state</code> — preset / audit / provider</li>
<li><code>GET /api/sessions</code> — active dispatcher sessions</li>
<li><code>GET /api/dispatchers</code> — registered binding counts per session</li>
<li><code>GET /api/outcomes/{{session_id}}</code> — recent OutcomeRecords</li>
<li><code>GET /api/skills</code> — discovered event_bindings</li>
</ul>
<p>Embedded view: open this URL in the AI King VS Code extension iframe
webview. Full vanilla-JS frontend lands in Phase 4.</p>
</body></html>"""
        return HTMLResponse(body)


def _register_runtime_state_route(app: "FastAPI") -> None:
    @app.get("/api/runtime/state")
    def runtime_state() -> JSONResponse:
        try:
            from persona.runtime import get_runtime_state
            state = get_runtime_state()
        except Exception as exc:  # pragma: no cover — defensive only
            return JSONResponse(
                {"error": f"runtime import failed: {exc}"},
                status_code=500,
            )
        # Light dispatcher-cache stats so the operator sees live activity
        # at a glance without a separate /api/sessions call.
        try:
            from persona.runtime_dispatcher_glue import (
                _DISPATCHER_BY_SESSION,
            )
            state["dispatcher_session_count"] = len(_DISPATCHER_BY_SESSION)
            state["event_dispatcher_enabled"] = True
        except Exception:
            state["dispatcher_session_count"] = 0
            state["event_dispatcher_enabled"] = False
        # Sancio auth-gate state (env-var driven; auth.py re-reads
        # SANCIO_REQUIRE_AUTH per request so this is the live value).
        state["sancio_require_auth"] = os.environ.get(
            "SANCIO_REQUIRE_AUTH", "1",
        )
        return JSONResponse(state)


def _truncate_session_id(sid: str, *, head: int = 8, tail: int = 4) -> str:
    """Render an opaque session id without leaking the full value to the
    GUI surface. Matches the truncation discipline used elsewhere in
    persona-api for log/audit display.
    """
    if not sid or len(sid) <= head + tail + 1:
        return sid
    return f"{sid[:head]}…{sid[-tail:]}"


def _register_sessions_route(app: "FastAPI") -> None:
    @app.get("/api/sessions")
    def list_sessions() -> JSONResponse:
        try:
            from persona.runtime_dispatcher_glue import (
                _DISPATCHER_BY_SESSION,
            )
        except Exception as exc:  # pragma: no cover
            return JSONResponse(
                {"error": f"dispatcher cache import failed: {exc}",
                 "sessions": []},
                status_code=500,
            )
        sessions: list[dict[str, Any]] = []
        for sid, dispatcher in _DISPATCHER_BY_SESSION.items():
            try:
                binding_count = len(dispatcher.binding_ids())
            except Exception:
                binding_count = 0
            sessions.append({
                "session_id_truncated": _truncate_session_id(sid),
                "binding_count": binding_count,
            })
        return JSONResponse({"sessions": sessions, "count": len(sessions)})


def _register_dispatchers_route(app: "FastAPI") -> None:
    @app.get("/api/dispatchers")
    def list_dispatchers() -> JSONResponse:
        try:
            from persona.runtime_dispatcher_glue import (
                _DISPATCHER_BY_SESSION,
            )
        except Exception as exc:  # pragma: no cover
            return JSONResponse(
                {"error": f"dispatcher cache import failed: {exc}",
                 "dispatchers": []},
                status_code=500,
            )
        out: list[dict[str, Any]] = []
        for sid, dispatcher in _DISPATCHER_BY_SESSION.items():
            try:
                binding_ids = list(dispatcher.binding_ids())
            except Exception:
                binding_ids = []
            out.append({
                "session_id_truncated": _truncate_session_id(sid),
                "binding_ids": binding_ids,
                "binding_count": len(binding_ids),
            })
        return JSONResponse({"dispatchers": out, "count": len(out)})


def _register_outcomes_route(app: "FastAPI") -> None:
    @app.get("/api/outcomes/{session_id}")
    def list_outcomes(session_id: str, limit: int = 50) -> JSONResponse:
        if not session_id or "/" in session_id or "\\" in session_id:
            raise HTTPException(status_code=400, detail="invalid session_id")
        # Cap limit to defend the JSON response size.
        limit = max(1, min(int(limit), 500))
        try:
            from persona.runtime_dispatcher_glue import (
                _DISPATCHER_BY_SESSION,
            )
        except Exception as exc:  # pragma: no cover
            return JSONResponse(
                {"error": f"dispatcher cache import failed: {exc}",
                 "outcomes": []},
                status_code=500,
            )
        # Match by either truncated or full session id — clients only
        # ever see truncated ids from /api/sessions, so we accept both.
        dispatcher = None
        for sid, disp in _DISPATCHER_BY_SESSION.items():
            if sid == session_id or _truncate_session_id(sid) == session_id:
                dispatcher = disp
                break
        if dispatcher is None:
            raise HTTPException(
                status_code=404,
                detail=f"unknown session: {session_id}",
            )
        try:
            records = dispatcher.outcomes()
        except Exception as exc:  # pragma: no cover
            return JSONResponse(
                {"error": f"outcomes read failed: {exc}", "outcomes": []},
                status_code=500,
            )
        # Most-recent-first; cap to ``limit``.
        records = sorted(records, key=lambda r: r.fired_at, reverse=True)
        rows = [r.to_dict() for r in records[:limit]]
        return JSONResponse({
            "session_id": _truncate_session_id(session_id),
            "outcomes": rows,
            "count": len(rows),
        })


def _register_skills_route(app: "FastAPI") -> None:
    @app.get("/api/skills")
    def list_skills() -> JSONResponse:
        try:
            from persona.runtime_dispatcher_glue import (
                discover_event_bindings,
            )
        except Exception as exc:  # pragma: no cover
            return JSONResponse(
                {"error": f"discovery import failed: {exc}",
                 "skills": []},
                status_code=500,
            )
        try:
            discovered = discover_event_bindings()
        except Exception as exc:  # pragma: no cover
            return JSONResponse(
                {"error": f"discovery failed: {exc}", "skills": []},
                status_code=500,
            )
        skills: list[dict[str, Any]] = []
        for path, meta in discovered:
            bindings_raw = meta.get("event_bindings", [])
            binding_summaries: list[dict[str, Any]] = []
            if isinstance(bindings_raw, list):
                for b in bindings_raw:
                    if not isinstance(b, dict):
                        continue
                    binding_summaries.append({
                        "event": b.get("event"),
                        "invoke": b.get("invoke"),
                        "priority": b.get("priority"),
                        "cooldown_s": b.get("cooldown_s"),
                    })
            skills.append({
                "name": meta.get("name") or path.parent.name,
                "description": (meta.get("description") or "")[:200],
                "skill_md_path": str(path),
                "event_bindings": binding_summaries,
                "binding_count": len(binding_summaries),
            })
        return JSONResponse({"skills": skills, "count": len(skills)})


def create_sancio_gui_app(
    *,
    token: Optional[str] = None,
    token_path: Optional[Path] = None,
) -> "FastAPI":
    """Build the Sancio GUI FastAPI app and persist a per-process bearer token.

    Args:
        token: Override the auto-generated token (mostly for tests).
            When omitted, a fresh :func:`auth.generate_token` is created.
        token_path: Override the token file location (mostly for tests).
            When omitted, :func:`get_sancio_token_path` is used.

    The token is written atomically to disk (via the audited
    :func:`concinno.gui.auth.write_token`) before the app object is
    returned so any client (VS Code extension, federated switcher) can
    read it the moment the bind address is reported.

    Raises:
        TokenAuthError: When the token file cannot be written
            (fail-fast — better to refuse to start than to silently
            run unauthenticated).
    """
    chosen_token = token or _auth.generate_token()
    chosen_path = token_path or get_sancio_token_path()
    written_path = _auth.write_token(chosen_token, path=chosen_path)
    _logger.info(
        "persona.gui: token written to %s; clients must send "
        "Authorization: Bearer <token>",
        written_path,
    )

    app = FastAPI(
        title="Sancio Runtime GUI",
        description=(
            "Read-only observability surface over the Sancio "
            "EventDispatcher cache, OutcomeRecord history, and "
            "discovered SKILL.md event_bindings. Pair with the "
            "Concinno config GUI on port 8400."
        ),
        version="0.1.0",
    )
    app.add_middleware(BearerTokenMiddleware, expected_token=chosen_token)
    _register_health_route(app)
    _register_landing_page(app)
    _register_runtime_state_route(app)
    _register_sessions_route(app)
    _register_dispatchers_route(app)
    _register_outcomes_route(app)
    _register_skills_route(app)
    # Stash for test introspection only — not part of the public API.
    app.state.gui_token = chosen_token
    app.state.gui_token_path = written_path
    return app


def run(host: str = "127.0.0.1", port: int = 8401, reload: bool = False) -> None:
    """Block on uvicorn until SIGINT.

    Loopback is the default. To bind a non-loopback host, set the env
    var ``SANCIO_GUI_ALLOW_PUBLIC_BIND=1`` — this surface is read-only
    so the risk is information disclosure (which sessions are active,
    which skills are wired) rather than mutation, but defaulting to
    loopback still matters because the bearer token leaks via header
    inspection on a shared network.
    """
    try:
        import uvicorn
    except ImportError as err:  # pragma: no cover
        raise ImportError(
            "persona.gui needs uvicorn. Install with `pip install uvicorn`."
        ) from err

    if host not in ("127.0.0.1", "localhost") and not os.environ.get(
        "SANCIO_GUI_ALLOW_PUBLIC_BIND"
    ):
        raise SystemExit(
            f"sancio gui refuses host={host!r}; set env "
            "SANCIO_GUI_ALLOW_PUBLIC_BIND=1 to override (loopback-only "
            "by default — this UI exposes runtime introspection that "
            "leaks active session ids and dispatcher topology)."
        )
    uvicorn.run(
        "persona.gui.server:create_sancio_gui_app",
        host=host,
        port=port,
        reload=reload,
        factory=True,
        log_level="info",
    )


__all__ = [
    "BearerTokenMiddleware",
    "create_sancio_gui_app",
    "get_sancio_token_path",
    "run",
]
