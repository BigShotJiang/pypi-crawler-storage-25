"""persona.gui.cli — ``sancio gui`` subcommand handler + legacy entry.

@module persona.gui.cli
@responsibility Define the ``gui`` verb's flag surface (``--host``,
    ``--port``, ``--reload``, ``--print-token-path``) and its handler
    :func:`_cmd_gui`. Exports both:

    * :func:`register` — attaches ``gui`` to a parent argparse
      ``subparsers`` action. Called by the umbrella dispatcher
      :mod:`persona.cli.main` so the unified ``sancio`` entry point
      can route ``sancio gui`` here without duplicating flags.
    * :func:`main` — legacy console-script entry. Earlier versions of
      ``persona-api`` wired ``[project.scripts]`` ``sancio`` directly
      to ``persona.gui.cli:main``; we keep this callable as a
      backward-compat alias that forwards to
      :func:`persona.cli.main.main`. It also still works standalone
      for any tooling that invokes the function directly.

Wiring lives in ``pyproject.toml`` under ``[project.scripts]``::

    sancio = "persona.cli.main:main"   # current (0.4.0+)

The previous wiring ``sancio = "persona.gui.cli:main"`` is preserved
through :func:`main` below; calling it produces the same observable
behaviour as the new umbrella for the ``gui`` subcommand.

Side note: persona-api today has no umbrella ``sancio`` daemon — the
runtime API is invoked via ``uvicorn persona.api:app``. The ``sancio``
console script is purely the operator-facing front end.
"""

from __future__ import annotations

import argparse
import sys


def _add_gui_arguments(p: argparse.ArgumentParser) -> None:
    """Populate ``p`` with the ``gui`` subcommand's flags.

    Centralised so :func:`_build_parser` (legacy single-verb parser)
    and :func:`register` (umbrella attach) stay byte-identical on the
    flag surface.
    """
    p.add_argument(
        "--host",
        default="127.0.0.1",
        help="Bind host (default: 127.0.0.1 loopback).",
    )
    p.add_argument(
        "--port",
        type=int,
        default=8401,
        help="Bind port (default: 8401; concinno GUI uses 8400).",
    )
    p.add_argument(
        "--reload",
        action="store_true",
        help="Enable uvicorn auto-reload (dev only).",
    )
    p.add_argument(
        "--print-token-path",
        action="store_true",
        help=(
            "Print the OS-appropriate path where the Sancio bearer "
            "token is/will be stored, then exit. The token value "
            "itself is NEVER printed — clients should read it from "
            "this path."
        ),
    )


def register(subparsers: argparse._SubParsersAction) -> None:
    """Attach the ``gui`` subcommand to a parent argparse subparsers.

    Used by :mod:`persona.cli.main` to fold ``sancio gui`` into the
    umbrella ``sancio`` parser without duplicating flag definitions.
    """
    p_gui = subparsers.add_parser(
        "gui",
        help=(
            "Launch the Sancio runtime observability GUI on loopback "
            "(default port 8401)."
        ),
    )
    _add_gui_arguments(p_gui)
    p_gui.set_defaults(func=_cmd_gui)


def _build_parser() -> argparse.ArgumentParser:
    """Legacy single-verb parser (used only by :func:`main` standalone).

    The umbrella dispatcher in :mod:`persona.cli.main` does not call
    this; it calls :func:`register` directly so all sancio verbs share
    one parser.
    """
    parser = argparse.ArgumentParser(
        prog="sancio",
        description="Sancio runtime CLI (currently: GUI launcher).",
    )
    sub = parser.add_subparsers(dest="command")
    register(sub)
    return parser


def _cmd_gui(args: argparse.Namespace) -> None:
    """Execute the ``sancio gui`` subcommand.

    ``--print-token-path`` short-circuits before importing FastAPI /
    uvicorn so a deploy that has not yet installed ``[gui]`` extras
    can still discover the token path.
    """
    if getattr(args, "print_token_path", False):
        from persona.gui.server import get_sancio_token_path

        print(get_sancio_token_path())
        return
    try:
        from persona.gui.server import run as _run
    except ImportError as err:
        print(f"[sancio gui] missing dependency: {err}")
        print("Install with: pip install fastapi uvicorn")
        sys.exit(1)
    print(
        f"[sancio gui] serving on http://{args.host}:{args.port}  "
        "(Ctrl+C to stop)"
    )
    _run(host=args.host, port=args.port, reload=args.reload)


def main(argv: list[str] | None = None) -> None:
    """Backward-compat entry point.

    Earlier ``[project.scripts]`` wired ``sancio`` to this function
    directly. The current wiring is ``persona.cli.main:main`` (the
    umbrella dispatcher), but we forward to it so any external tooling
    or pinned install that still calls ``persona.gui.cli:main``
    observes identical behaviour — including the new ``self-update``
    verb being available.

    Args:
        argv: Argument list (omit to read from ``sys.argv[1:]``).
    """
    from persona.cli.main import main as umbrella_main

    umbrella_main(argv)


__all__ = ["main", "register"]
