"""persona.gui — Sancio runtime observability GUI (port 8401 default).

@module persona.gui
@responsibility Read-only HTTP surface mirroring Concinno's GUI patterns
    (``concinno.gui.server``) but scoped to the *Sancio runtime* — active
    sessions, registered dispatchers, recent OutcomeRecords, discovered
    skill event_bindings. Concinno owns FEATURE_META configuration; Sancio
    GUI owns runtime introspection. The two GUIs run on different ports
    (8400 vs 8401) and use different bearer-token files.

Token-file invariant: ``~/.sancio/gui_token`` (POSIX) /
``%LOCALAPPDATA%\\sancio\\gui_token`` (Windows). Atomic write via
:func:`concinno.gui.auth.write_token` with explicit ``path=`` override —
we deliberately re-use the audited token utility from concinno rather
than reinventing the chmod / atomic-replace logic.

Layer rule (per ``projects/concinno/CLAUDE.md`` §"Boundary"): runtime
observability is Sancio territory because it surfaces ``EventDispatcher``
state introduced by persona.event_dispatcher (Sancio 0.6 active-trigger
runtime), not anything CC can do natively. Stays out of OSS Concinno.
"""
