"""Unified agent-run endpoint — ``POST /v1/agent/run`` (SSE).

The thin VS Code / editor / 3rd-party front-ends no longer carry their
own tool loops in 0.12+. They POST the turn here, Aegis runs the
multi-iteration :class:`persona.engine.agent_loop.AgentLoop` with the
stack-specific layer stack (tools / guard hook / cerno hook / policy
pre-hook), and streams events back as ``text/event-stream`` frames.

Event schema (one frame = ``event: <name>\\ndata: <json>\\n\\n``):

  * ``token``       — assistant text delta. ``{"text": "..."}``
  * ``tool_call``   — LLM issued a tool call before execution.
                     ``{"id", "tool", "input"}``
  * ``tool_result`` — post-execution result. ``{"id", "output", "error"}``
  * ``iteration``   — soft checkpoint per loop iteration.
                     ``{"n", "state"}``
  * ``done``        — terminal event. ``{"usage": {...}, "stop_reason"}``
  * ``error``       — terminal transport/tool error. ``{"message", "code"}``

Stack semantics (see :func:`_build_loop` for the truth table):

  * ``ccc``       — tools only (no guard, no cerno, no policy).
  * ``aegis``     — tools + guard_pre + cerno_post + policy_pre.
  * ``strategos`` — ``aegis`` + adds ``X-Aegis-Stack: strategos`` (the
                     organisation-graph feature is TODO; the header is a
                     forward-compatible marker so clients can track
                     emergence).
  * ``infinite``  — same as ``strategos``; TODO for dynamic org gen.

Stacks ``clean`` and ``digital-human`` are intentionally NOT served
here:

  * ``clean``         — extension provider direct-streams, never hits
                         ``/v1/agent/run``.
  * ``digital-human`` — PSYCHEFORGE endpoint (out of scope, TODO).

Requests targeting those stacks return 400 with an actionable message.
"""

from __future__ import annotations

import asyncio
import json
import os
import time
import uuid
from collections.abc import AsyncIterator, Awaitable, Callable
from typing import TYPE_CHECKING, Any

from pydantic import BaseModel, Field, ValidationError
from starlette.responses import JSONResponse, StreamingResponse
from starlette.routing import Route

from pathlib import Path

from concinno.agent import (
    AsymmetryPlan,
    Commander,
    EpistemicAxis,
    MASConfig,
    MASResult,
    TierDecision,
    derive_role_seeds,
    run_mas,
)

from .engine.agent_loop import (
    AgentLoop,
    LLMResponse,
    PermissionDenied,
    ToolCall,
)
from .policy.dsl import PermissionAsk
from .providers import ModelPolicy, ProviderError, ToolSpec
from .hooks.cerno_hook import make_cerno_post_hook
from .hooks.guard_hook import make_guard_pre_hook
from .policy.defaults import default_policy
from .policy.hook import make_policy_pre_hook
from .runtime_dispatcher_glue import (
    fire_stop,
    fire_user_prompt_submit,
    get_dispatcher,
    make_dispatcher_post_hook,
    make_dispatcher_pre_hook,
)
from .tools import default_tools as _default_tools


# ── Tenant-scoped workspace root (P0#1 Task 2) ──

_DEFAULT_WORKSPACE_ROOT = "/opt/persona-api/runtime_workspace"


def _workspace_root_base() -> Path:
    """Return the base runtime workspace directory for tenant sandboxes.

    Read from ``SANCIO_WORKSPACE_ROOT`` (set by the systemd unit on
    prod). Falls back to ``/opt/persona-api/runtime_workspace`` so a
    missing env var does NOT silently give tools access to ``/``.

    The base is created on first use. Tenant sub-directories are
    created lazily inside :func:`_tenant_workspace_root` so a compromised
    caller can't exhaust inode quota by spraying tenant IDs at us.
    """
    base = os.environ.get(
        "SANCIO_WORKSPACE_ROOT", _DEFAULT_WORKSPACE_ROOT,
    ).strip() or _DEFAULT_WORKSPACE_ROOT
    p = Path(base).expanduser().resolve()
    p.mkdir(parents=True, exist_ok=True)
    return p


def _safe_tenant_id(tenant_id: str) -> str:
    """Return a filesystem-safe tenant directory name.

    Strips path separators + null bytes, clips to 64 chars, and
    falls back to ``default`` on empty/garbage input. We specifically
    reject ``..`` so a tenant_id like ``../../etc`` cannot reach the
    parent of the workspace root even though :meth:`Path.resolve`
    would also catch the escape.
    """
    if not tenant_id or not isinstance(tenant_id, str):
        return "default"
    cleaned = "".join(
        c for c in tenant_id
        if c.isalnum() or c in ("-", "_", ".")
    )
    cleaned = cleaned.replace("..", "_")
    cleaned = cleaned[:64]
    return cleaned or "default"


def _tenant_workspace_root(tenant_id: str) -> Path:
    """Return ``<base>/<tenant_id>/`` with path traversal hardening.

    ``_safe_tenant_id`` strips dangerous chars first. A second
    ``.is_relative_to`` check after resolve catches anything that
    slipped through (symlinks, edge cases). On escape we collapse
    back to the ``default`` tenant rather than raising because tool
    construction happens deep in the loop and surfacing errors there
    would cascade into 500s on otherwise-legitimate requests.
    """
    base = _workspace_root_base()
    safe = _safe_tenant_id(tenant_id)
    tenant_dir = (base / safe).resolve()
    if not tenant_dir.is_relative_to(base):
        tenant_dir = (base / "default").resolve()
    tenant_dir.mkdir(parents=True, exist_ok=True)
    return tenant_dir

if TYPE_CHECKING:
    from starlette.requests import Request

    from .engine.agent_loop import Tool


# ── Request / response models ───────────────────

_ALLOWED_STACKS = {
    "sancio", "concinno", "redigo", "subtexo",
    "aegis", "ccc", "strategos", "infinite",
}
_REJECTED_STACKS = {
    "clean": (
        "stack=clean is served by the extension provider directly; "
        "do not POST to /v1/agent/run."
    ),
    "digital-human": (
        "stack=digital-human is served by PSYCHEFORGE (not implemented). "
        "Target the PSYCHEFORGE endpoint instead."
    ),
}


class _AgentMessage(BaseModel):
    role: str = Field(pattern=r"^(user|assistant|system|tool)$")
    content: str


class AgentRunRequest(BaseModel):
    """Wire contract for ``POST /v1/agent/run``.

    ``extra = "forbid"`` is intentional — unknown fields surface as 400
    so clients catch protocol drift early rather than silently losing
    parameters.
    """

    stack: str = Field(min_length=1)
    messages: list[_AgentMessage] = Field(min_length=1)
    model: str = Field(min_length=1)
    persona_id: str | None = None
    thinking_budget: int = Field(default=8000, ge=0, le=64000)
    max_iterations: int = Field(default=25, ge=1, le=200)
    tenant_id: str = Field(default="default", min_length=1)
    # Optional provider-specific extras forwarded verbatim onto
    # :class:`ModelPolicy.extra`. Generic passthrough for knobs like
    # ``{"seed": 42, "num_ctx": 16384}`` so benchmark runners can
    # drive deterministic paired-seed evaluations without a new
    # field per knob. Unknown keys are ignored by providers that
    # don't understand them. Named ``provider_extra`` rather than
    # ``model_extra`` to avoid shadowing the Pydantic v2
    # ``BaseModel.model_extra`` attribute.
    provider_extra: dict[str, Any] | None = None
    # Optional per-request Cerno config overrides merged on top of
    # ``DEFAULT_CERNO_CONFIG``. Unknown keys are silently dropped by
    # the registry (see ``cerno_registry._build_config``) so clients
    # can forward benchmark-only flags like ``{"enable_retry": True}``
    # without risking 400s when new keys land upstream.
    cerno_config: dict[str, Any] | None = None
    # Optional Multi-Agent-System (solver → critic → judge) config.
    # When ``None`` the endpoint runs the existing Single Agent System
    # path and the SSE stream stays byte-identical. When set, the
    # endpoint dispatches to :func:`_run_mas` which uses
    # :func:`concinno.agent.run_mas` to drive three sequential roles
    # on top of the same :func:`_build_loop` solver stack. See Sancio
    # 0.4.0 Phase 2 design / red-team / commander-verdict docs under
    # ``_AI_BRAIN/05_Planning/mas-phase2-*.md`` for rationale.
    #
    # Typed sub-model (``extra="forbid"``) catches wire-drift like
    # ``{"rolez": [...]}`` or ``{"vote": "majority"}`` at request
    # parse time — the outer ``extra="forbid"`` on this class only
    # catches *top-level* unknown keys, not keys inside a raw dict.
    mas_config: MASConfig | None = None

    # Optional CBUA Stage -1 intent anchor (concinno 2.35.0+). When True,
    # the first user message is run through
    # ``concinno.intent_anchor.extract_anchor`` and the rendered anchor
    # block is prepended as a system message before the loop sees the
    # request. Skipped when False / when there's no user message.
    # Drives the N=20 paper-pass ablation (variant_2_35_anchor) without
    # touching the production default.
    intent_anchor: bool = False

    model_config = {"extra": "forbid"}


# ── Default Sonnet model resolution ─────────────

_DEFAULT_SONNET_CACHE: str | None = None
_SONNET_FALLBACK = "anthropic:claude-sonnet-4-6"
_SONNET_PREFERRED = "anthropic:claude-sonnet-4-7"


def _default_sonnet_model_hint() -> str:
    """Return the default Sonnet model hint, preferring the latest available.

    Sonnet is the cost-conscious default so ad-hoc ``/v1/agent/run``
    callers who omit ``model`` do NOT silently drain the account on
    Opus pricing. Opus variants stay opt-in via an explicit
    ``model:"anthropic:claude-opus-4-7"`` in the request body.

    Lookup order:
      1. ``PERSONA_DEFAULT_SONNET_MODEL`` env var (explicit override).
      2. Process-level probe cache from a prior call.
      3. Anthropic Models API probe for ``claude-sonnet-4-7``.
      4. Safe fallback to ``claude-sonnet-4-6``.

    The probe is skipped (and falls back immediately) when:
      * ``PERSONA_SKIP_SONNET_PROBE`` is truthy (CI / offline tests).
      * ``ANTHROPIC_API_KEY`` is unset (no credential to probe with).
      * The HTTP probe raises or returns non-200.

    Result is cached for the process lifetime; tests that flip env
    vars should call :func:`_reset_default_sonnet_cache` first.
    """
    global _DEFAULT_SONNET_CACHE

    override = os.environ.get("PERSONA_DEFAULT_SONNET_MODEL")
    if override:
        return override

    if _DEFAULT_SONNET_CACHE is not None:
        return _DEFAULT_SONNET_CACHE

    if os.environ.get("PERSONA_SKIP_SONNET_PROBE"):
        _DEFAULT_SONNET_CACHE = _SONNET_FALLBACK
        return _SONNET_FALLBACK

    api_key = os.environ.get("ANTHROPIC_API_KEY")
    if not api_key:
        _DEFAULT_SONNET_CACHE = _SONNET_FALLBACK
        return _SONNET_FALLBACK

    try:
        import httpx

        resp = httpx.get(
            "https://api.anthropic.com/v1/models",
            params={"limit": 1000},
            headers={
                "x-api-key": api_key,
                "anthropic-version": "2023-06-01",
            },
            timeout=3.0,
        )
        if resp.status_code == 200:
            payload = resp.json()
            data = payload.get("data") if isinstance(payload, dict) else None
            if isinstance(data, list):
                # Sonnet 4.7 may ship as bare ``claude-sonnet-4-7`` or
                # dated (e.g. ``claude-sonnet-4-7-20260801``); match both
                # via prefix so the probe works regardless of alias
                # policy.
                has_sonnet_47 = any(
                    isinstance(m, dict)
                    and isinstance(m.get("id"), str)
                    and m["id"].startswith("claude-sonnet-4-7")
                    for m in data
                )
                if has_sonnet_47:
                    _DEFAULT_SONNET_CACHE = _SONNET_PREFERRED
                    return _SONNET_PREFERRED
    except Exception:
        pass
    _DEFAULT_SONNET_CACHE = _SONNET_FALLBACK
    return _SONNET_FALLBACK


def _reset_default_sonnet_cache() -> None:
    """Clear the process-level Sonnet-probe cache. Test-only helper."""
    global _DEFAULT_SONNET_CACHE
    _DEFAULT_SONNET_CACHE = None


# ── LLM adapter — provider-agnostic stub for now ─

# A fake, sync-safe LLM caller so the loop state machine is exercisable
# without a real provider round-trip. Real integration lands when A5
# provider router exposes a streaming OpenAI-compatible call surface.
# We keep the protocol shim here so the endpoint contract is stable
# while the provider layer evolves behind it.

LLMStreamingCall = Callable[
    [list[dict[str, Any]], list[dict[str, Any]]],
    Awaitable[LLMResponse],
]


def _default_llm_call() -> LLMStreamingCall:
    """Return a single-shot echo LLM for tests / missing provider.

    Emits the last user turn back as the assistant message so the
    endpoint is wire-testable without network. Real provider hookup
    happens in :func:`set_llm_call`.
    """

    async def _echo(
        messages: list[dict[str, Any]],
        tool_schemas: list[dict[str, Any]],
    ) -> LLMResponse:
        last_user = next(
            (m for m in reversed(messages) if m.get("role") == "user"),
            None,
        )
        text = str(last_user.get("content", "")) if last_user else ""
        return LLMResponse(content=f"echo: {text}", tool_calls=[])

    return _echo


def _split_model_string(raw: str) -> tuple[str, str]:
    """Best-effort parse ``"<provider>:<model>"`` / ``"<provider>/<model>"``.

    Extension 0.12.x ships either a prefixed form (``anthropic/claude-…``
    from the webview router) or a bare model id (``claude-sonnet-4-5``
    from legacy callers). We keep parsing forgiving so the endpoint
    stays usable while the extension's model-string contract solidifies.

    Fallback when no prefix is present: infer by family. Anything that
    starts with ``claude`` → anthropic; ``gpt`` → openai; ``gemma``/
    ``llama``/``qwen`` → ollama; else anthropic (safest for Aegis).
    """
    # Slash takes precedence over colon because Ollama model IDs use
    # colon for the tag (e.g. ``gemma4:latest``), so ``ollama/gemma4:latest``
    # must split at the slash, not the first colon.
    for sep in ("/", ":"):
        if sep in raw:
            prov, _, mdl = raw.partition(sep)
            prov = prov.strip().lower()
            mdl = mdl.strip()
            if prov and mdl:
                return prov, mdl
    low = raw.lower()
    if low.startswith("claude"):
        return "anthropic", raw
    if low.startswith(("gpt", "o1", "o3", "o4")):
        return "openai", raw
    if low.startswith(("gemma", "llama", "qwen", "mistral", "phi")):
        return "ollama", raw
    return "anthropic", raw


def _provider_backed_llm_call(
    engine: Any,
    default_max_tokens: int = 4096,
) -> LLMStreamingCall:
    """Build an LLM adapter that routes through ``PersonaEngine``.

    The returned callable is the production wiring for
    ``/v1/agent/run``: it parses the ``model`` string from the request
    (threaded into ``messages[0]`` by the caller is NOT how we carry
    it — see note), constructs a :class:`ModelPolicy`, and dispatches
    through :meth:`PersonaEngine._llm_via_provider` so AppendOnlyLog,
    ``UsageStats`` telemetry, and the provider registry all participate.

    Tool-calling note
    -----------------
    When ``tool_schemas`` is non-empty we route through
    ``provider.generate_with_tools`` (protocol upgrade in 0.13.0)
    and translate the native ``tool_calls`` back into
    :class:`ToolCall` so the agent loop can dispatch. Empty tool
    list falls back to ``provider.generate`` for backward compat
    with consumers that don't pass tools.

    Model-string plumbing
    ---------------------
    ``messages[0]["_model"]`` is the channel used by the endpoint to
    smuggle the per-request model string (set in :func:`_run_and_stream`
    before dispatch). We strip it back off before forwarding to the
    provider so the on-wire message list stays clean.
    """

    async def _call(
        messages: list[dict[str, Any]],
        tool_schemas: list[dict[str, Any]],
    ) -> LLMResponse:
        # Pull the out-of-band model hint that the endpoint stashed on
        # the first message (see ``_run_and_stream``). Fallback to a
        # conservative default if absent so ad-hoc callers still work.
        model_hint: str | None = None
        max_tokens = default_max_tokens
        model_extra: dict[str, Any] = {}
        clean_msgs: list[dict[str, str]] = []
        for m in messages:
            if "_model" in m and model_hint is None:
                model_hint = str(m.get("_model") or "")
            if "_max_tokens" in m and m.get("_max_tokens"):
                try:
                    max_tokens = int(m["_max_tokens"])
                except (TypeError, ValueError):
                    pass
            if "_model_extra" in m and isinstance(
                m.get("_model_extra"), dict,
            ):
                model_extra = dict(m["_model_extra"])
            role = str(m.get("role", "user"))
            content = m.get("content", "")
            if isinstance(content, list):
                # Flatten to text — providers don't speak tool-result
                # content blocks through this adapter (see docstring).
                content = " ".join(
                    str(p.get("text", ""))
                    for p in content
                    if isinstance(p, dict)
                )
            clean_msgs.append({"role": role, "content": str(content)})

        if not model_hint:
            model_hint = _default_sonnet_model_hint()
        provider_name, model = _split_model_string(model_hint)
        policy = ModelPolicy(
            provider=provider_name,
            model=model,
            temperature=0.7,
            max_tokens=max_tokens,
            extra=model_extra,
        )

        # Text-only path: no tools advertised, keep the legacy
        # engine._llm_via_provider surface so AppendOnlyLog +
        # UsageStats routing stays intact.
        if not tool_schemas:
            try:
                text = await engine._llm_via_provider(policy, clean_msgs)
            except ProviderError:
                raise
            return LLMResponse(content=text or "", tool_calls=[])

        # Tool-use path: translate the loop's history (which may now
        # carry role=tool and assistant.tool_calls) through to the
        # provider's native tool_use API. Each provider converts
        # ToolSpec / ProviderResponse to/from its own wire format.
        provider = engine._provider_router.get(provider_name)

        # Graceful degrade: providers that predate 0.13.0 only
        # implement ``generate``. Route through the legacy path so
        # existing fakes + third-party providers keep working; the
        # loop just sees tool_calls=[] and settles after one round.
        if not hasattr(provider, "generate_with_tools"):
            try:
                text = await engine._llm_via_provider(policy, clean_msgs)
            except ProviderError:
                raise
            return LLMResponse(content=text or "", tool_calls=[])
        tools_spec = [
            ToolSpec(
                name=s["function"]["name"],
                description=s["function"].get("description", ""),
                input_schema=s["function"].get("parameters", {}),
            )
            for s in tool_schemas
            if isinstance(s, dict) and "function" in s
        ]
        # Rebuild the wire-message list: pull assistant.tool_calls /
        # role=tool turns straight from ``messages`` (pre-cleaning)
        # so we don't lose tool metadata that the clean_msgs loop
        # above dropped.
        native_msgs: list[dict[str, Any]] = []
        for m in messages:
            if (
                "_model" in m
                or "_max_tokens" in m
                or "_model_extra" in m
            ):
                m2 = {k: v for k, v in m.items()
                      if k not in ("_model", "_max_tokens", "_model_extra")}
                native_msgs.append(m2)
            else:
                native_msgs.append(m)
        try:
            resp = await provider.generate_with_tools(
                native_msgs, policy, tools_spec,
            )
        except ProviderError:
            raise
        return LLMResponse(
            content=resp.text or "",
            tool_calls=[
                ToolCall(id=tc.id, name=tc.name, args=tc.input)
                for tc in resp.tool_calls
            ],
        )

    return _call


_llm_call: LLMStreamingCall = _default_llm_call()


def set_llm_call(call: LLMStreamingCall) -> None:
    """Swap the module-level LLM adapter.

    Tests install a scripted fake; production wiring installs the
    provider router. Keeping this as a module-level hook rather than
    baking the provider lookup into :func:`_build_loop` lets tests
    exercise tool-use flows deterministically.
    """
    global _llm_call
    _llm_call = call


def reset_llm_call() -> None:
    """Restore the echo adapter — used by test fixture teardown."""
    global _llm_call
    _llm_call = _default_llm_call()


# ── Tool registry ────────────────────────────────


def _build_tool_registry(tenant_id: str = "default") -> dict[str, "Tool"]:
    """Return one instance per built-in tool, keyed by name.

    P0#1 Task 2: every filesystem + bash tool is constructed with a
    ``root`` / ``cwd`` pointing at the tenant-scoped workspace
    directory so an LLM prompt injection cannot read
    ``/etc/shadow`` or write to ``/opt/persona-api/data/auth.db``.
    The pre-P0 code passed ``root=None`` which meant every tool ran
    rooted at the server process CWD — pure RCE.

    Each tool module exposes a ``Tool`` subclass whose ``name``
    attribute matches the OpenAI function-calling spec. Callers that
    need a trimmed subset (eg. ``ccc`` stack) filter afterwards.
    """
    root = _tenant_workspace_root(tenant_id)
    return _default_tools(root=root)  # type: ignore[return-value]


# ── Loop factory ─────────────────────────────────


def _build_loop(
    stack: str,
    max_iterations: int,
    tenant_id: str,
    cerno_config: dict[str, Any] | None = None,
) -> AgentLoop:
    """Compose an :class:`AgentLoop` with the right layers for ``stack``.

    Stack truth table mirrors the module docstring. ``ccc`` is the
    minimal shell (tools only) so upstream stacks can stack on top
    without re-implementing the bare loop.

    ``cerno_config`` is an opt-in per-request overrides dict merged on
    top of :data:`DEFAULT_CERNO_CONFIG` the first time a Cerno is
    instantiated for ``tenant_id``. Benchmark runners set
    ``{"enable_retry": True}`` here to turn on the Reflexion-lite
    retry path (MEMORY #56) without touching the production default.
    """
    tools = _build_tool_registry(tenant_id=tenant_id)
    pre_hooks: list[Any] = []
    post_hooks: list[Any] = []

    if stack in (
        "sancio", "concinno", "redigo", "subtexo",
        "aegis", "strategos", "infinite",
    ):
        # Cheap deterministic policy first, then semantic guard.
        pre_hooks.append(make_policy_pre_hook(default_policy()))
        pre_hooks.append(make_guard_pre_hook())

        # Lazy registry import so this module stays import-cheap.
        from . import api as _api_module

        cerno = _api_module._get_or_create_cerno(
            child_id=f"agent-run-{tenant_id}",
            config_override=cerno_config,
            tenant=tenant_id,
        )
        # Sancio 2.0.0 — wire Option C deny_on_action so Cerno's deny
        # verdicts flip the LLM-visible channel to is_error=True (per
        # `_AI_BRAIN/05_Planning/2026-05-01-l6-posttooluse-design-conflict-options.md`).
        # CC physics still hold (post-hook can't roll back side effects),
        # but the next LLM iteration sees "post-hook deny: <reason>"
        # instead of the silently-allowed tool output. RED Opus FATAL-2
        # 2026-05-01 — without this wire, the 2.0.0 README/CHANGELOG
        # claim "deny verdicts no longer silently swallowed" is vapor
        # in production.
        post_hooks.append(
            make_cerno_post_hook(
                cerno,
                deny_on_action=lambda a: getattr(a, "type", None) == "deny",
            )
        )

    return AgentLoop(
        llm_call=_llm_call,
        tools=tools,
        pre_hooks=pre_hooks,
        post_hooks=post_hooks,
        max_iterations=max_iterations,
    )


# ── Permission gate (human-in-the-loop via SSE + POST) ──


# Per-request permission wait state. Keyed by a unique permission
# request_id (NOT the HTTP request_id — one agent run may emit multiple
# permission asks). Each entry is an (Event, decision-holder) pair.
_permission_waiters: dict[str, asyncio.Event] = {}
_permission_decisions: dict[str, str] = {}

_PERMISSION_TIMEOUT_S = float(
    os.environ.get("SANCIO_PERMISSION_TIMEOUT_S")
    or os.environ.get("AEGIS_PERMISSION_TIMEOUT_S", "60"),
)

_VALID_DECISIONS = {"allow_once", "allow_tool", "allow_session", "deny"}


# Sancio 0.6 EventDispatcher rollout flag (spec §5).
#
# 0.6.0 default = OFF; flip via ``SANCIO_EVENT_DISPATCHER_ENABLED=1``
# once outcome telemetry shows zero regressions, then default-on in
# 0.7.0. Reading the env var per-request (not at import time) so an
# operator flip takes effect without a server restart.
def _is_event_dispatcher_enabled() -> bool:
    val = os.environ.get(
        "SANCIO_EVENT_DISPATCHER_ENABLED", "0",
    ).strip().lower()
    return val in ("1", "true", "yes", "on")


def _wrap_hooks_with_permission_gate(
    pre_hooks: list[Any],
    sse_queue: asyncio.Queue[bytes | None],
) -> list[Any]:
    """Wrap each pre-hook so ``PermissionAsk`` is caught and gated via SSE.

    When the policy DSL evaluates a rule as ``"ask"``, the policy hook
    raises :class:`PermissionAsk`. This wrapper catches it, pushes a
    ``permission_ask`` SSE frame onto *sse_queue* (which the generator
    yields to the client), then waits up to ``_PERMISSION_TIMEOUT_S``
    for the extension to POST back to ``/v1/agent/permission``.

    Decisions ``allow_*`` → return silently (tool proceeds).
    Decision ``deny`` or timeout → raise :class:`PermissionDenied`.
    """

    def _wrap(original_hook: Any) -> Any:
        async def _wrapped(tool_name: str, args: dict[str, Any]) -> None:
            try:
                await original_hook(tool_name, args)
            except PermissionAsk:
                perm_id = uuid.uuid4().hex[:12]
                event = asyncio.Event()
                _permission_waiters[perm_id] = event

                sse_queue.put_nowait(_sse("permission_ask", {
                    "tool": tool_name,
                    "args": args,
                    "request_id": perm_id,
                }))

                try:
                    await asyncio.wait_for(
                        event.wait(), timeout=_PERMISSION_TIMEOUT_S,
                    )
                except asyncio.TimeoutError:
                    pass  # treat as deny below

                decision = _permission_decisions.pop(perm_id, "deny")
                _permission_waiters.pop(perm_id, None)

                if decision.startswith("allow"):
                    return
                raise PermissionDenied(
                    f"permission denied by client "
                    f"(decision={decision}, tool={tool_name})",
                )

        return _wrapped

    return [_wrap(h) for h in pre_hooks]


# ── SSE emitter helpers ──────────────────────────


def _sse(event: str, payload: dict[str, Any]) -> bytes:
    """Encode one named SSE event + JSON data."""
    body = json.dumps(payload, ensure_ascii=False, default=str)
    return f"event: {event}\ndata: {body}\n\n".encode("utf-8")


async def _run_and_stream(
    req: AgentRunRequest,
    request_id: str,
    budget_user_id: str | None = None,
) -> AsyncIterator[bytes]:
    """Drive the loop and emit SSE frames as events land.

    The loop runs in a background task so that ``permission_ask``
    frames can be yielded to the client in real-time while the loop
    is blocked waiting for the user's decision.  All SSE frames
    (tool_call, tool_result, permission_ask, iteration, token, done,
    error) flow through a single :class:`asyncio.Queue`.  A ``None``
    sentinel signals end-of-stream.
    """
    loop = _build_loop(
        req.stack,
        req.max_iterations,
        req.tenant_id,
        cerno_config=req.cerno_config,
    )

    messages: list[dict[str, Any]] = [
        {"role": m.role, "content": m.content} for m in req.messages
    ]

    # CBUA Stage -1 intent anchor (concinno 2.35.0+) — opt-in via
    # ``intent_anchor=True``. Heuristic-extract done_spec / constraints
    # from the first user message and prepend a system anchor block so
    # the model sees it before the task. Pure stdlib regex; no LLM
    # judge, no network. Driving the N=20 paper-pass ablation
    # variant_2_35_anchor vs baseline_v1.
    if req.intent_anchor and messages:
        first_user = next(
            (m for m in messages if m.get("role") == "user"), None,
        )
        if first_user and isinstance(first_user.get("content"), str):
            try:
                from concinno.intent_anchor import (
                    extract_anchor,
                    render_anchor_block,
                )

                anchor = extract_anchor(first_user["content"])
                if not anchor.is_empty():
                    block = render_anchor_block(
                        anchor,
                        title="🎯 Stage -1 意圖錨定（首輪）",
                    )
                    messages.insert(0, {"role": "system", "content": block})
            except Exception:
                pass  # anchor must never break agent run

    if messages:
        messages[0] = {
            **messages[0],
            "_model": req.model,
            "_max_tokens": req.thinking_budget or 4096,
        }
        if req.provider_extra:
            messages[0]["_model_extra"] = req.provider_extra

    q: asyncio.Queue[bytes | None] = asyncio.Queue()

    # Wrap pre-hooks with permission gate so PermissionAsk is caught,
    # an SSE frame is pushed, and the hook awaits the client response.
    loop.pre_hooks = _wrap_hooks_with_permission_gate(loop.pre_hooks, q)

    # Sancio 0.6 EventDispatcher fan-out (opt-in via env, spec §5
    # default-off in 0.6.0). When enabled, every PreToolUse / PostToolUse
    # / PostToolUseFailure tool-loop event is mirrored to the dispatcher
    # so SKILL.md ``event_bindings`` declarations can route side-effects.
    # The hooks never raise; dispatcher errors land as OutcomeRecord
    # entries, not as 500s on the SSE stream.
    dispatcher = None
    if _is_event_dispatcher_enabled():
        try:
            dispatcher = get_dispatcher(request_id)
            loop.pre_hooks.append(make_dispatcher_pre_hook(dispatcher))
            loop.post_hooks.append(make_dispatcher_post_hook(dispatcher))
            # UserPromptSubmit fires once at request entry. Pull the
            # last user turn so predicates can match against the
            # final inbound text.
            last_user = next(
                (m.content for m in reversed(req.messages) if m.role == "user"),
                "",
            )
            fire_user_prompt_submit(
                dispatcher,
                prompt=last_user,
                stack=req.stack,
                session_id=request_id,
            )
        except Exception:  # noqa: BLE001 — dispatcher must not break the run
            dispatcher = None

    async def _drive() -> None:
        """Run the loop, push all SSE frames to *q*, send sentinel."""
        t_start = time.time()
        tokens_out = 0
        try:
            iter_n = 0
            original_llm = loop.llm_call

            async def _instrumented_llm(
                msgs: list[dict[str, Any]],
                schemas: list[dict[str, Any]],
            ) -> LLMResponse:
                nonlocal iter_n
                iter_n += 1
                return await original_llm(msgs, schemas)

            loop.llm_call = _instrumented_llm  # type: ignore[assignment]

            async def _sse_post(
                tool_name: str,
                args: dict[str, Any],
                result: Any,
            ) -> None:
                tool_id = f"tc_{uuid.uuid4().hex[:8]}"
                is_error = isinstance(result, str) and result.startswith(
                    "tool error:",
                )
                q.put_nowait(_sse("tool_call", {
                    "id": tool_id,
                    "tool": tool_name,
                    "input": args,
                }))
                q.put_nowait(_sse("tool_result", {
                    "id": tool_id,
                    "output": (
                        result if isinstance(result, str) else str(result)
                    ),
                    "error": is_error or None,
                }))

            loop.post_hooks.append(_sse_post)

            state = await loop.run(messages)

            # ── Format-guard retry (Concinno 2.17+) ─────────────
            #
            # The first loop.run() may finish with an output that the
            # grader will reject despite correct evidence gathering:
            # empty raw, think-aloud lead-in, search-query dump, or a
            # quantization-token leak. ``classify_output_format`` is
            # a pure-regex, question-agnostic classifier that returns
            # None for well-formed output (zero regression risk on
            # already-passing questions) and one of four failure-mode
            # enum members otherwise.
            #
            # On a detected failure we re-run the loop once with the
            # ORIGINAL question plus a short ``FORMAT_RETRY_REMINDER``
            # suffix. We never feed the bad first reply back in as
            # assistant context — that locks the model into doubling
            # down on the bad format. The retry is a clean re-ask
            # with a tighter output rule.
            #
            # Opt-out: ``SANCIO_FORMAT_RETRY_ENABLED=0`` (env).
            # Default on. Roughly 2× API cost on failing questions
            # only; already-passing questions pay zero extra.
            fg_enabled = os.environ.get(
                "SANCIO_FORMAT_RETRY_ENABLED", "1",
            ).strip().lower() not in ("0", "false", "no", "off", "")
            if fg_enabled:
                from concinno.agent import (
                    classify_output_format,
                    extract_sentinel_answer,
                    retry_reminder_for_mode,
                )
                first_text = state.final_text or ""
                # Prefer the ``FINAL ANSWER:`` sentinel payload; fall
                # back to the final non-empty line of the output so
                # retry-talk / quote-dump patterns get detected even
                # when the model never emitted the sentinel at all
                # (the grader applies the same last-line fallback
                # server-side in GAIA and similar evals).
                first_ans = extract_sentinel_answer(
                    first_text, "FINAL ANSWER:", take_last=True,
                )
                if not first_ans:
                    lines = [
                        line.strip()
                        for line in first_text.splitlines()
                        if line.strip()
                    ]
                    first_ans = lines[-1] if lines else first_text
                # Pass the original user question so the classifier
                # can detect PARAPHRASE_RISK (verbatim-quote questions
                # where the grader rejects any rephrasing). Still
                # no expected-answer read — the classifier only sees
                # question structure, not the correct answer.
                original_user_text = next(
                    (
                        m.get("content", "") for m in messages
                        if m.get("role") == "user"
                    ),
                    "",
                )
                fail_mode = classify_output_format(
                    first_text,
                    first_ans,
                    question=original_user_text,
                )
                if fail_mode is not None:
                    # Surface the retry decision to the client so
                    # runners can log / count it without re-parsing.
                    q.put_nowait(_sse("format_retry", {
                        "mode": fail_mode.value,
                        "first_answer_preview": first_ans[:100],
                    }))
                    # Build augmented request: keep original user
                    # text + any model/_model_extra hints, append
                    # the question-agnostic format reminder.
                    if messages:
                        first_user_idx = next(
                            (
                                i for i, m in enumerate(messages)
                                if m.get("role") == "user"
                            ),
                            0,
                        )
                        augmented = list(messages)
                        original_msg = augmented[first_user_idx]
                        augmented[first_user_idx] = {
                            **original_msg,
                            "content": (
                                original_msg.get("content", "")
                                + retry_reminder_for_mode(fail_mode)
                            ),
                        }
                        # Second attempt — non-fatal on exception;
                        # if the retry itself errors, fall through
                        # with the first state so we emit at least
                        # something rather than a 500.
                        try:
                            state = await loop.run(augmented)
                        except Exception as retry_exc:  # noqa: BLE001
                            q.put_nowait(_sse("format_retry_error", {
                                "code": type(retry_exc).__name__,
                                "message": str(retry_exc)[:200],
                            }))

            q.put_nowait(_sse("iteration", {
                "n": state.iterations,
                "state": state.stop_reason or "completed",
            }))

            if state.final_text:
                tokens_out = len(state.final_text)
                q.put_nowait(_sse("token", {"text": state.final_text}))

            # P0#1 Task 3: record actual spend against the budget gate.
            # We use ``output_chars`` as a rough token proxy when the
            # provider didn't return a usage struct (loop.run today
            # doesn't thread that through — future work). This is a
            # conservative floor, not a ceiling: ``check()`` already
            # pre-rejected the worst case.
            try:
                from .budget import get_budget_gate
                approx_tokens = max(
                    tokens_out, int(req.thinking_budget or 0),
                )
                get_budget_gate().record(
                    user_id=budget_user_id or req.tenant_id,
                    actual_tokens=approx_tokens,
                )
            except Exception:  # noqa: BLE001 — never break the stream
                pass

            q.put_nowait(_sse("done", {
                "usage": {
                    "output_chars": tokens_out,
                    "iterations": state.iterations,
                    "stop_reason": state.stop_reason or "completed",
                },
                "request_id": request_id,
                "elapsed_s": round(time.time() - t_start, 3),
            }))
        except PermissionDenied as exc:
            q.put_nowait(_sse("error", {
                "code": "permission_denied",
                "message": str(exc),
                "request_id": request_id,
            }))
        except Exception as exc:  # noqa: BLE001
            q.put_nowait(_sse("error", {
                "code": "internal_error",
                "message": f"{type(exc).__name__}: {str(exc)[:400]}",
                "request_id": request_id,
            }))
        finally:
            # Sancio 0.6 — fire Stop once at the very end so SKILL.md
            # bindings on Stop (handoff_check, sediment-pending, …) can
            # observe the final state. Best-effort; never raises.
            if dispatcher is not None:
                try:
                    fire_stop(
                        dispatcher,
                        session_id=request_id,
                        stop_reason="completed",
                        iterations=iter_n,
                    )
                except Exception:  # noqa: BLE001
                    pass
            q.put_nowait(None)  # sentinel

    task = asyncio.create_task(_drive())
    try:
        while True:
            frame = await q.get()
            if frame is None:
                break
            yield frame
    finally:
        if not task.done():
            task.cancel()
            try:
                await task
            except asyncio.CancelledError:
                pass


# ── MAS (solver → critic → judge) env gates + adapter ───

# Sancio 0.4.0 multi-agent-system config switches. Defaults keep the
# feature enabled so the runner can drive N=20 paired pilots without
# env gymnastics, but operators can disable on prod by flipping
# SANCIO_MAS_ENABLED=0 — the endpoint then returns 503 +
# Retry-After on any ``mas_config``-bearing request (clients can
# distinguish "feature disabled" from "malformed body" at the
# status-code layer; L2 in the red-team review).
_MAS_ENABLED = (
    os.environ.get("SANCIO_MAS_ENABLED", "1").strip().lower()
    not in {"0", "false", "no", ""}
)
_MAS_MAX_ROLES = int(os.environ.get("SANCIO_MAS_MAX_ROLES", "3"))
# Raised from the 300s design-doc number per H4 in the red-team
# (long-tail Ollama Gemma4 inference on the shared pod regularly
# crosses 300s; 600s matches the existing httpx timeout on the
# benchmark runner).
_MAS_PER_ROLE_TIMEOUT_S = float(
    os.environ.get("SANCIO_MAS_PER_ROLE_TIMEOUT_S", "600"),
)

# MAS 3-tier overhaul (Tier 1) — Commander routing + asymmetry knobs.
#
# S5 verdict M3 ACCEPT: ``SANCIO_MAS_COMMANDER`` default="0".
# Commander routing is OPT-IN until N=40 confirm validates the lift.
# Only when the flag is explicitly on does the endpoint call
# :class:`concinno.agent.Commander` / build an :class:`AsymmetryPlan`.
#
# S5 H1 ACCEPT: ``SANCIO_MAS_ASYMMETRY_MIN_AXES`` default=2 so
# prompt-only + temp-only ablation arms are rejected by
# ``AsymmetryPlan.assert_distinct`` unless the runner explicitly lowers
# the threshold for a per-axis ablation run.
#
# S5 藍 C2 ACCEPT: ``SANCIO_MAS_FTRL_SUNSET_N`` default=60 so the
# sunset flag advertises the "FTRL activates after N≥60 outcomes"
# contract. Tier 1 exposes it via :class:`TierDecision`; Tier 2 ships
# the actual on-line update wiring.
_MAS_COMMANDER_ENABLED = (
    os.environ.get("SANCIO_MAS_COMMANDER", "0").strip().lower()
    in {"1", "true", "yes", "on"}
)
_MAS_ASYMMETRY_MIN_AXES = int(
    os.environ.get("SANCIO_MAS_ASYMMETRY_MIN_AXES", "2"),
)
_MAS_FTRL_SUNSET_N = int(
    os.environ.get("SANCIO_MAS_FTRL_SUNSET_N", "60"),
)


def _build_text_only_llm_call(
    seed: int,
) -> Callable[[str], Awaitable[str]]:
    """Build a text-only LLM call wrapping the module-level ``_llm_call``.

    Critic / judge roles never advertise tool schemas, so the call
    degrades to ``provider.generate`` on providers that implement the
    0.13+ ``generate_with_tools`` surface and to the legacy
    ``engine._llm_via_provider`` path on older fakes. Either way we
    pull the ``content`` back as a plain string.

    We reuse the module-level adapter rather than building a fresh
    ``_provider_backed_llm_call`` so ``set_llm_call`` test swaps keep
    working for MAS paths too — tests can install one fake adapter
    and have it serve all three roles via ``tool_schemas=[]``.

    ``seed`` is threaded onto the ``_model_extra`` side-channel the
    same way :func:`_run_and_stream` does, so paired-seed evaluations
    stay reproducible when the provider is deterministic on seed.
    """

    async def _call(prompt: str) -> str:
        msg: dict[str, Any] = {
            "role": "user",
            "content": prompt,
            "_model_extra": {"seed": int(seed)},
        }
        resp = await _llm_call([msg], [])
        return resp.content or ""

    return _call


async def _run_mas(
    req: AgentRunRequest,
    request_id: str,
    budget_user_id: str | None = None,
    *,
    tier_decision: TierDecision | None = None,
    asymmetry_plan: AsymmetryPlan | None = None,
) -> AsyncIterator[bytes]:
    """Drive the MAS loop for a ``/v1/agent/run`` request.

    Dispatches only when ``req.mas_config is not None``. Calls into
    :func:`concinno.agent.run_mas` with three callables:

    * ``solver_loop`` — wraps the existing :func:`_build_loop` +
      full tool registry (provider drives web_search, read_file, ...).
      Collects the solver's ``final_text`` plus its post-hook tool
      results as a trace list.
    * ``critic_call`` / ``judge_call`` — text-only adapters built by
      :func:`_build_text_only_llm_call`. No tool schemas, so
      ``SANCIO_DEFAULT_DECISION=ask`` can't surface a permission_ask
      frame on these roles and the blast radius is empty set.

    Role seeds are offset ``+0/+1/+2`` from the outer
    ``provider_extra.seed`` by :func:`concinno.agent.derive_role_seeds`
    so the three roles don't collapse to the same sampling stream on
    identical input (M3 in the red-team).

    All SSE frames flow through a single ``asyncio.Queue`` mirroring
    :func:`_run_and_stream`. The orchestrator emits ``role_start`` /
    ``role_end`` / ``vote`` via the injected callback; this adapter
    layers ``token`` / ``done`` events around them so clients get the
    final answer string the same way they do for SAS.
    """
    # Re-check the env kill switch at dispatch time so a flip between
    # request parse and stream start is honoured (tests flip env
    # between requests).
    if not _MAS_ENABLED:
        async def _disabled_stream() -> AsyncIterator[bytes]:
            yield _sse("error", {
                "code": "mas_disabled",
                "message": "MAS is disabled on this server "
                           "(SANCIO_MAS_ENABLED=0)",
                "request_id": request_id,
            })
        async for f in _disabled_stream():
            yield f
        return

    # ``mas_config`` already validated at request parse time; read the
    # typed sub-model directly.
    mas_cfg: MASConfig = req.mas_config  # type: ignore[assignment]

    # Per-role seed derivation. Outer ``provider_extra.seed`` is the
    # anchor — critic = +1, judge = +2 (see concinno.derive_role_seeds).
    raw_seed = 42
    if req.provider_extra and "seed" in req.provider_extra:
        try:
            raw_seed = int(req.provider_extra["seed"])
        except (TypeError, ValueError):
            raw_seed = 42
    seeds = mas_cfg.seeds or derive_role_seeds(raw_seed)

    # Pull the user question from the last user turn. The existing SAS
    # path treats ``messages`` the same way and relies on the caller
    # to compose a self-contained turn.
    question = next(
        (m.content for m in reversed(req.messages) if m.role == "user"),
        "",
    )
    # ``task_id`` for blind-labelling in the judge call. Reuse the
    # incoming ``x-request-id`` so a swap-test auditor can align
    # experiments by request id / ``audit_mapping`` surfaced in the
    # ``vote`` event.
    task_id = request_id

    q: asyncio.Queue[bytes | None] = asyncio.Queue()

    def _emit(name: str, payload: dict[str, Any]) -> None:
        q.put_nowait(_sse(name, payload))

    # Solver: wraps the full tool-enabled loop. Collects the
    # final answer + a simple trace (tool_result strings) via a
    # capture hook tucked on the post_hooks list.
    async def _solver_loop() -> dict[str, Any]:
        loop = _build_loop(
            req.stack,
            req.max_iterations,
            req.tenant_id,
            cerno_config=req.cerno_config,
        )
        messages: list[dict[str, Any]] = [
            {"role": m.role, "content": m.content} for m in req.messages
        ]
        if messages:
            messages[0] = {
                **messages[0],
                "_model": req.model,
                "_max_tokens": req.thinking_budget or 4096,
            }
            extra = dict(req.provider_extra or {})
            extra["seed"] = int(seeds["solver"])
            messages[0]["_model_extra"] = extra

        # Wrap pre-hooks with permission gate so denied tools don't
        # silently stall the solver.
        loop.pre_hooks = _wrap_hooks_with_permission_gate(
            loop.pre_hooks, q,
        )

        trace: list[str] = []

        async def _trace_hook(
            tool_name: str, args: dict[str, Any], result: Any,
        ) -> None:
            # Keep the trace compact — per red-team H4, we only need
            # the first few tool results and the concinno truncator
            # will top-3 them before the critic sees anything.
            snippet = str(result)[:500] if result is not None else ""
            trace.append(f"[{tool_name}] {snippet}")

        loop.post_hooks.append(_trace_hook)

        try:
            state = await asyncio.wait_for(
                loop.run(messages),
                timeout=_MAS_PER_ROLE_TIMEOUT_S,
            )
            final_text = state.final_text or ""
        except asyncio.TimeoutError:
            final_text = ""
        except PermissionDenied:
            final_text = ""
        except Exception:  # noqa: BLE001 — downstream roles still run
            final_text = ""
        return {
            "answer": final_text,
            "raw_len": len(final_text),
            "trace": trace,
        }

    # Text-only critic + judge. Seeds threaded through ``_model_extra``.
    critic_call = _build_text_only_llm_call(seeds["critic"])
    judge_call = _build_text_only_llm_call(seeds["judge"])

    # Pull GAIA-flavored prompts from the benchmark-side override
    # module. This keeps benchmark-specific wording out of concinno
    # (MEMORY #52 boundary) while still giving Sancio the GAIA
    # FINAL ANSWER sentinel critic/judge need to parse.
    from .benchmark.mas_prompts import (
        GAIA_CRITIC_FALLBACK_PROMPT,
        GAIA_CRITIC_PROMPT,
        GAIA_JUDGE_PROMPT,
    )

    t_start = time.time()

    # S5 F1/M3 ACCEPT — when the adapter received a
    # ``tier_decision`` from the Commander-routed dispatch path we
    # surface it as a ``commander`` SSE frame so clients can log the
    # tier attribution without parsing the role trace. Identical
    # information is available on ``TierDecision.signals``.
    if tier_decision is not None:
        _emit("commander", {
            "tier": tier_decision.tier,
            "alpha_t": tier_decision.alpha_t,
            "reason": tier_decision.reason,
            "budget": {
                "max_tokens": tier_decision.budget.max_tokens,
                "max_iterations": tier_decision.budget.max_iterations,
                "per_role_timeout_s": tier_decision.budget.per_role_timeout_s,
            },
            "fallback_chain": list(tier_decision.fallback_chain),
            "thresholds_frozen_until_n_outcomes": (
                tier_decision.thresholds_frozen_until_n_outcomes
            ),
        })

    async def _drive() -> None:
        result: MASResult | None = None
        try:
            result = await run_mas(
                config=mas_cfg,
                solver_loop=_solver_loop,
                critic_call=critic_call,
                judge_call=judge_call,
                question=question,
                task_id=task_id,
                emit=_emit,
                critic_prompt=GAIA_CRITIC_PROMPT,
                critic_fallback_prompt=GAIA_CRITIC_FALLBACK_PROMPT,
                judge_prompt=GAIA_JUDGE_PROMPT,
                trace_top_k=3,
                asymmetry_plan=asymmetry_plan,
            )
            # Layer a terminal ``token`` event so existing SSE
            # consumers that scrape ``token.text`` still extract the
            # judge's final answer without needing the new ``vote``
            # event.
            if result.final_answer:
                q.put_nowait(_sse(
                    "token", {"text": result.final_answer},
                ))

            # Record budget spend the same way as the SAS path. We
            # approximate with ``raw_len`` sum across roles since
            # text-only roles don't surface token counts.
            try:
                from .budget import get_budget_gate
                approx_tokens = sum(
                    r.get("raw_len", 0) for r in result.per_role
                ) or int(req.thinking_budget or 0)
                get_budget_gate().record(
                    user_id=budget_user_id or req.tenant_id,
                    actual_tokens=approx_tokens,
                )
            except Exception:  # noqa: BLE001 — never break the stream
                pass

            q.put_nowait(_sse("done", {
                "usage": {
                    "output_chars": sum(
                        r.get("raw_len", 0) for r in result.per_role
                    ),
                    "iterations": len(result.per_role),
                    "stop_reason": (
                        "cascade_empty"
                        if result.cascade_empty
                        else "completed"
                    ),
                    "mas": True,
                },
                "request_id": request_id,
                "elapsed_s": round(time.time() - t_start, 3),
            }))
        except Exception as exc:  # noqa: BLE001
            q.put_nowait(_sse("error", {
                "code": "internal_error",
                "message": f"{type(exc).__name__}: {str(exc)[:400]}",
                "request_id": request_id,
            }))
        finally:
            q.put_nowait(None)  # sentinel

    task = asyncio.create_task(_drive())
    try:
        while True:
            frame = await q.get()
            if frame is None:
                break
            yield frame
    finally:
        if not task.done():
            task.cancel()
            try:
                await task
            except asyncio.CancelledError:
                pass


# ── Endpoint ─────────────────────────────────────


async def _agent_run(request: "Request") -> StreamingResponse | JSONResponse:
    """``POST /v1/agent/run`` — SSE endpoint."""
    request_id = request.headers.get("x-request-id") or uuid.uuid4().hex[:12]

    try:
        raw = await request.body()
    except Exception:  # noqa: BLE001 — transport error
        return JSONResponse(
            {"error": "invalid_body", "detail": "failed to read body",
             "request_id": request_id},
            status_code=400,
        )
    if not raw:
        return JSONResponse(
            {"error": "invalid_body", "detail": "request body is empty",
             "request_id": request_id},
            status_code=400,
        )
    try:
        body = json.loads(raw)
    except (ValueError, TypeError):
        return JSONResponse(
            {"error": "invalid_body",
             "detail": "request body must be valid JSON",
             "request_id": request_id},
            status_code=400,
        )
    if not isinstance(body, dict):
        return JSONResponse(
            {"error": "invalid_body",
             "detail": "request body must be a JSON object",
             "request_id": request_id},
            status_code=400,
        )

    try:
        req = AgentRunRequest.model_validate(body)
    except ValidationError as exc:
        first = exc.errors()[0]
        return JSONResponse(
            {
                "error": "invalid_field",
                "detail": first.get("msg", "validation failed"),
                "loc": list(first.get("loc") or []),
                "request_id": request_id,
            },
            status_code=400,
        )

    if req.stack in _REJECTED_STACKS:
        return JSONResponse(
            {
                "error": "unsupported_stack",
                "detail": _REJECTED_STACKS[req.stack],
                "stack": req.stack,
                "request_id": request_id,
            },
            status_code=400,
        )
    if req.stack not in _ALLOWED_STACKS:
        return JSONResponse(
            {
                "error": "unknown_stack",
                "detail": (
                    f"stack must be one of "
                    f"{sorted(_ALLOWED_STACKS)}; got {req.stack!r}"
                ),
                "request_id": request_id,
            },
            status_code=400,
        )

    # P0#1 Task 3: per-user Anthropic budget gate. Pre-flight check
    # with an estimate of ``max_iterations * max_tokens`` so a caller
    # who has already blown their daily cap is rejected before we
    # spin up the loop / provider. Actual spend is recorded inside
    # ``_drive()`` once the provider returns usage stats.
    from .auth import verify_token
    from .budget import BudgetExceeded, get_budget_gate

    user_id = req.tenant_id
    auth = request.headers.get("authorization", "")
    if auth.lower().startswith("bearer "):
        token = auth[7:].strip()
        claims = verify_token(token)
        if claims:
            user_id = str(claims.get("sub") or req.tenant_id)

    # PERSONA_BENCHMARK_MODE=1 bypasses the budget gate — benchmark /
    # GAIA eval runs are expected to burn tokens; the $5 daily cap
    # exists to protect interactive users, not paired-seed smoke sets.
    # Inline env read (no import) so the guard can't silently no-op
    # due to an import-time failure in this long-living module.
    _bench_val = os.environ.get(
        "PERSONA_BENCHMARK_MODE", "",
    ).strip().lower()
    _bench_on = _bench_val in ("1", "true", "yes", "on")
    if not _bench_on:
        estimated_tokens = int(req.max_iterations) * int(
            req.thinking_budget or 4096,
        )
        try:
            get_budget_gate().check(
                user_id=user_id, estimated_tokens=estimated_tokens,
            )
        except BudgetExceeded as exc:
            return JSONResponse(
                {
                    "error": "budget_exceeded",
                    "detail": str(exc),
                    "window": exc.window,
                    "spent_usd": round(exc.spent_usd, 4),
                    "cap_usd": round(exc.cap_usd, 4),
                    "retry_after": exc.retry_after,
                    "request_id": request_id,
                },
                status_code=exc.code,
                headers={"Retry-After": str(exc.retry_after)},
            )

    headers = {"x-request-id": request_id}
    if req.stack in ("redigo", "subtexo",
                      "strategos", "infinite"):
        # Forward-compat marker: lets clients / logs track which
        # upstream stack requested the call even before the org-graph
        # feature ships. See module docstring TODO.
        headers["x-sancio-stack"] = req.stack

    # Commander routing (Tier 1, S5 M3 ACCEPT — default OFF).
    #
    # When ``SANCIO_MAS_COMMANDER=1`` is explicitly set **and** the
    # client did not pin ``mas_config`` we ask the Concinno Commander
    # to compute an α_t + tier decision from the request. Tier 0 →
    # fall through to SAS (byte-identical to today's path). Tier ≥1 →
    # auto-promote to MAS by synthesising a ``MASConfig`` + building
    # an :class:`AsymmetryPlan`. The per-request ``mas_config`` still
    # wins when the client pins one — Commander only *upgrades*, it
    # does not override explicit client intent.
    commander_decision: TierDecision | None = None
    commander_plan: AsymmetryPlan | None = None
    if _MAS_COMMANDER_ENABLED and _MAS_ENABLED:
        last_user_msg = next(
            (m.content for m in reversed(req.messages) if m.role == "user"),
            "",
        )
        try:
            commander = Commander()
            commander_decision = commander.route(
                last_user_msg,
                {"attached_file_count": 0},
            )
        except Exception:  # noqa: BLE001 — commander must never 500 a request
            commander_decision = None

        if commander_decision is not None and commander_decision.tier >= 1:
            # Auto-promote the request: if no explicit mas_config yet,
            # synthesise the canonical 3-role one so ``_run_mas`` can
            # take over. Existing mas_config (if any) is left alone.
            if req.mas_config is None:
                req = req.model_copy(update={
                    "mas_config": MASConfig(
                        roles=["solver", "critic", "judge"],
                        vote="judge",
                    ),
                })
            # Build an asymmetry plan only when the decision is ≥ tier 1.
            # H1 ACCEPT: axes_enabled defaults to all 3 new-novel.
            try:
                raw_seed = 42
                if req.provider_extra and "seed" in req.provider_extra:
                    try:
                        raw_seed = int(req.provider_extra["seed"])
                    except (TypeError, ValueError):
                        raw_seed = 42
                plan = AsymmetryPlan.build(
                    solver_profile={"seed_offset": raw_seed},
                    axes_enabled={
                        EpistemicAxis.SEED_OFFSET,
                        EpistemicAxis.TEMP_DELTA,
                        EpistemicAxis.PROMPT_FRAME,
                    },
                )
                # S5 H1 ACCEPT — env-configurable minimum axis count.
                plan.assert_distinct(min_axes=_MAS_ASYMMETRY_MIN_AXES)
                commander_plan = plan
            except ValueError:
                commander_plan = None

    # MAS dispatch: if the client passed ``mas_config`` the endpoint
    # routes through the 3-role orchestrator instead of the SAS
    # stream. Sub-model validation already happened at
    # ``model_validate`` above (typed ``MASConfig`` with
    # ``extra="forbid"`` rejects unknown keys + ``vote='majority'``).
    #
    # Kill-switch: when ``SANCIO_MAS_ENABLED`` is explicitly off we
    # return 503 + ``Retry-After`` so clients distinguish "feature
    # disabled" from "malformed body" at the status-code level (L2 in
    # the red-team review).
    if req.mas_config is not None:
        if not _MAS_ENABLED:
            return JSONResponse(
                {
                    "error": "mas_disabled",
                    "detail": (
                        "MAS is disabled on this server "
                        "(SANCIO_MAS_ENABLED=0). Retry after the "
                        "operator re-enables the feature flag or "
                        "omit mas_config to run the single-agent "
                        "path."
                    ),
                    "request_id": request_id,
                },
                status_code=503,
                headers={
                    "Retry-After": "3600",
                    "x-request-id": request_id,
                },
            )
        # Cap role count to the env ceiling. DoS guard: a request body
        # with ``roles=[...×1000]`` would otherwise fan out that many
        # role dispatches. 0.4.0 only implements 3 roles so the cap is
        # effectively 3, but keeping the env read makes the knob
        # discoverable for 0.5+.
        if len(req.mas_config.roles) > _MAS_MAX_ROLES:
            return JSONResponse(
                {
                    "error": "mas_too_many_roles",
                    "detail": (
                        f"mas_config.roles length "
                        f"{len(req.mas_config.roles)} exceeds "
                        f"SANCIO_MAS_MAX_ROLES={_MAS_MAX_ROLES}"
                    ),
                    "request_id": request_id,
                },
                status_code=400,
            )
        return StreamingResponse(
            _run_mas(
                req,
                request_id,
                budget_user_id=user_id,
                tier_decision=commander_decision,
                asymmetry_plan=commander_plan,
            ),
            media_type="text/event-stream",
            headers=headers,
        )

    return StreamingResponse(
        _run_and_stream(req, request_id, budget_user_id=user_id),
        media_type="text/event-stream",
        headers=headers,
    )


async def _agent_permission(request: "Request") -> JSONResponse:
    """``POST /v1/agent/permission`` — receive permission decision from client.

    Body: ``{"request_id": "<perm_id>", "decision": "allow_once|..."}``

    The permission pre-hook wrapper (see :func:`_wrap_hooks_with_permission_gate`)
    is blocked on an :class:`asyncio.Event` keyed by ``request_id``. This
    endpoint stores the decision and sets the event so the hook resumes.
    """
    try:
        raw = await request.body()
        body = json.loads(raw) if raw else {}
    except (ValueError, TypeError):
        return JSONResponse(
            {"error": "invalid_body", "detail": "request body must be valid JSON"},
            status_code=400,
        )

    perm_id = body.get("request_id")
    decision = body.get("decision", "deny")

    if not isinstance(perm_id, str) or not perm_id:
        return JSONResponse(
            {"error": "invalid_field", "detail": "request_id is required"},
            status_code=400,
        )
    if decision not in _VALID_DECISIONS:
        return JSONResponse(
            {
                "error": "invalid_field",
                "detail": f"decision must be one of {sorted(_VALID_DECISIONS)}",
            },
            status_code=400,
        )

    event = _permission_waiters.get(perm_id)
    if event is None:
        return JSONResponse(
            {"error": "not_found",
             "detail": f"no pending request: {perm_id}"},
            status_code=404,
        )

    _permission_decisions[perm_id] = decision
    event.set()

    return JSONResponse({"ok": True, "request_id": perm_id, "decision": decision})


def create_agent_run_routes() -> list[Route]:
    """Expose the agent-run route list for ``api.create_sancio_routes``."""
    return [
        Route("/v1/agent/run", _agent_run, methods=["POST"]),
        Route("/v1/agent/permission", _agent_permission, methods=["POST"]),
    ]


# Env-overridable cap for long-running loops; host operators can lower
# this to bound the SSE session on shared boxes.
AGENT_RUN_MAX_ITERATIONS = int(
    os.environ.get("SANCIO_AGENT_RUN_MAX_ITERATIONS")
    or os.environ.get(
        "AEGIS_AGENT_RUN_MAX_ITERATIONS", "200",
    ),
)


__all__ = [
    "AGENT_RUN_MAX_ITERATIONS",
    "AgentRunRequest",
    "create_agent_run_routes",
    "reset_llm_call",
    "set_llm_call",
    "_provider_backed_llm_call",
]
