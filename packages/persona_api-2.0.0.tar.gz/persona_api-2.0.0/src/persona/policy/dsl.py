"""Aegis permission DSL — rule + policy dataclasses (A4, v3 roadmap).

**Why a DSL on top of Guards?** ``persona.guards.classify_safety``
runs 55+ semantic guards through CortexLibrary (fuzzy, AI-assisted,
slow). A DSL complements that with **deterministic, fast, explicit**
rules the operator can audit line-by-line — e.g. "never let
``run_bash`` match ``rm -rf*`` regardless of phrasing". Both layers
stack: the policy hook runs first (cheap deny), the guard hook runs
second (semantic catch-all). Either layer denying denies the call.

## Rule shape

.. code-block:: python

    Rule(
        tool="run_bash",
        arg_patterns={"cmd": "rm -rf*"},  # glob by default
        decision="deny",
        reason="filesystem destruction",
    )

Patterns default to fnmatch-style globs on the string form of each
arg. A ``regex:`` prefix switches to Python regex. A ``literal:``
prefix disables wildcard expansion (useful for paths that contain
literal ``*``).

## Matching

Rules are evaluated in order. **First match wins** (allow-then-deny
ordering — operators put allow rules above deny rules when they
want to carve exceptions). When no rule matches, :attr:`Policy
.default_decision` fires.

## Decisions

* ``"allow"`` — hook returns silently, loop proceeds
* ``"deny"`` — hook raises :class:`PermissionDenied`
* ``"ask"`` — hook raises :class:`PermissionAsk`. The loop captures
  it as a ``tool`` message with ``is_error=True`` and a signalling
  prefix; the outer caller (HTTP endpoint / CLI) decides whether to
  relay the ask to a human. A4 does **not** itself implement the
  human-in-the-loop channel; it just provides the ask signal.
"""

from __future__ import annotations

from collections.abc import Iterable, Mapping
from dataclasses import dataclass, field
from typing import Any, Literal

Decision = Literal["allow", "deny", "ask"]


@dataclass(frozen=True)
class Rule:
    """One permission rule.

    Parameters
    ----------
    tool:
        Tool name to match. ``"*"`` matches any tool (e.g. a
        blanket ``deny`` rule at the tail of the list).
    arg_patterns:
        Mapping of ``arg_name -> pattern_string``. **Every** entry
        must match for the rule to fire; an arg absent from the
        call short-circuits the rule (no match). An empty mapping
        means "match regardless of args" (tool-name-only rule).
    decision:
        ``"allow"`` | ``"deny"`` | ``"ask"``.
    reason:
        Short human-readable string surfaced in
        :class:`PermissionDenied` / :class:`PermissionAsk` messages.
    """

    tool: str
    decision: Decision
    arg_patterns: Mapping[str, str] = field(default_factory=dict)
    reason: str = ""

    def to_dict(self) -> dict[str, Any]:
        return {
            "tool": self.tool,
            "decision": self.decision,
            "arg_patterns": dict(self.arg_patterns),
            "reason": self.reason,
        }

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> Rule:
        decision = data.get("decision")
        if decision not in ("allow", "deny", "ask"):
            raise ValueError(
                f"invalid decision: {decision!r} "
                "(expected 'allow' | 'deny' | 'ask')",
            )
        tool = data.get("tool")
        if not isinstance(tool, str) or not tool:
            raise ValueError("rule.tool must be a non-empty string")
        patterns = data.get("arg_patterns") or {}
        if not isinstance(patterns, Mapping):
            raise ValueError("rule.arg_patterns must be a mapping")
        return cls(
            tool=tool,
            decision=decision,
            arg_patterns=dict(patterns),
            reason=str(data.get("reason") or ""),
        )


@dataclass
class Policy:
    """Ordered rule list + default fallback.

    :meth:`evaluate` returns ``(decision, reason)`` — the reason is
    empty for the default fallback, and for matched rules it echoes
    :attr:`Rule.reason`.
    """

    rules: list[Rule] = field(default_factory=list)
    default_decision: Decision = "allow"

    def evaluate(
        self,
        tool_name: str,
        args: Mapping[str, Any],
    ) -> tuple[Decision, str, Rule | None]:
        """Return the first matching rule's decision, else the default."""
        from .matcher import rule_matches  # local import to avoid cycles

        for rule in self.rules:
            if rule_matches(rule, tool_name, args):
                return rule.decision, rule.reason, rule
        return self.default_decision, "", None

    def to_dict(self) -> dict[str, Any]:
        return {
            "rules": [r.to_dict() for r in self.rules],
            "default_decision": self.default_decision,
        }

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> Policy:
        default = data.get("default_decision", "allow")
        if default not in ("allow", "deny", "ask"):
            raise ValueError(
                f"invalid default_decision: {default!r}",
            )
        rules_raw = data.get("rules") or []
        if not isinstance(rules_raw, Iterable):
            raise ValueError("rules must be iterable")
        return cls(
            rules=[Rule.from_dict(r) for r in rules_raw],
            default_decision=default,
        )


class PermissionAsk(Exception):
    """Raised when a policy rule says ``"ask"`` — human-in-the-loop signal."""


__all__ = [
    "Decision",
    "PermissionAsk",
    "Policy",
    "Rule",
]
