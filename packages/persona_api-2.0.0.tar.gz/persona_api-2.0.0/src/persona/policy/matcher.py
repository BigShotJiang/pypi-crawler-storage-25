"""Pattern matching for policy rules (A4).

Supports three pattern flavours via explicit prefix:

* ``"regex:<python regex>"`` — Python :mod:`re` search
* ``"literal:<exact string>"`` — ``==`` comparison (wildcards escape)
* plain string — fnmatch glob (``*``, ``?``, ``[...]``)

``None`` or missing args **never** match — rules whose
``arg_patterns`` reference a missing arg simply fail, giving
operators a way to write tool-name-only rules (empty dict) without
accidentally matching calls that lack the expected arg.
"""

from __future__ import annotations

import fnmatch
import re
from collections.abc import Mapping
from typing import Any

from .dsl import Rule


def pattern_matches(pattern: str, value: Any) -> bool:
    """Return True iff ``str(value)`` matches ``pattern`` under the DSL rules."""
    text = value if isinstance(value, str) else str(value)
    if pattern.startswith("regex:"):
        return re.search(pattern[6:], text) is not None
    if pattern.startswith("literal:"):
        return text == pattern[8:]
    return fnmatch.fnmatchcase(text, pattern)


def rule_matches(
    rule: Rule,
    tool_name: str,
    args: Mapping[str, Any],
) -> bool:
    """True iff ``rule`` applies to this ``(tool_name, args)`` call."""
    if rule.tool != "*" and rule.tool != tool_name:
        return False
    for arg_name, pattern in rule.arg_patterns.items():
        if arg_name not in args:
            return False
        if not pattern_matches(pattern, args[arg_name]):
            return False
    return True


__all__ = ["pattern_matches", "rule_matches"]
