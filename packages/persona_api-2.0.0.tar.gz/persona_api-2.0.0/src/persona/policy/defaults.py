"""Bundled default policy — common-sense deny rules (A4).

Operators start from :func:`default_policy` and extend with
domain-specific rules on top. Every rule is conservative by design
— false positives are fine (LLM can adapt), false negatives are
expensive (tool runs). Rules are ordered **allow-first, deny-last**
so allow-list entries can carve exceptions through a following
blanket deny.

P0#1 Task 7 hardening (2026-04-18)
----------------------------------
Red team found multiple bypasses on the pre-P0 rule set:

* ``rm  -rf`` (double-space) — regex ``\\brm\\s+-[rf]*[rf][rf]*``
  didn't collapse whitespace properly; rewritten with ``\\s+`` + a
  ``-[rfRF]+`` character class that survives weird flag ordering.
* ``/bin/sh -c "rm -rf /"`` — no explicit pattern before; added.
* ``echo <base64> | base64 -d | sh`` — pipe-to-interpreter rule
  only caught ``curl|wget`` as sources; extended to any
  ``echo``/``cat``/``printf`` + base64 + sh pipeline.
* ``../`` path traversal — new deny rule catches the sequence in
  filesystem tool args.
* LLM-originated commands default to ``ask`` rather than ``allow``
  so the permission hook gates through ``/v1/agent/permission``.
"""

from __future__ import annotations

from .dsl import Policy, Rule

_DEFAULT_RULES: list[Rule] = [
    # ── run_bash ────────────────────────────────────
    # rm -rf (single/multi flag segments, any whitespace, upper/lowercase).
    # Matches `rm -rf /`, `rm  -rf /`, `rm -r -f /tmp`, `rm -RF /`.
    Rule(
        tool="run_bash",
        arg_patterns={
            # rm followed by any flag combination that includes
            # both r/R AND f/F in the same invocation, in any order,
            # possibly with other flag letters (v / i / -- / etc).
            # We anchor on the ``rm`` word and require a path
            # following so ``rm`` by itself on a command line (help
            # query) doesn't fire.
            "cmd": (
                r"regex:\brm\b(?=(?:\s+-\S*[rRfF]){2,}|"
                r"\s+-\S*[rR]\S*[fF]|\s+-\S*[fF]\S*[rR])"
            ),
        },
        decision="deny",
        reason="rm -rf pattern rejected (P0#1 hardened)",
    ),
    # /bin/sh -c "<anything>" and friends. The explicit invocation
    # usually means an attacker bypassing argument parsing.
    Rule(
        tool="run_bash",
        arg_patterns={
            "cmd": (
                r"regex:(?:^|[\s;&|`])"
                r"(?:/bin/)?(?:sh|bash|zsh|dash|ksh|ash)\s+-[ci]"
            ),
        },
        decision="deny",
        reason="explicit shell -c / -i invocation rejected",
    ),
    # Classic pipe-to-interpreter (curl / wget / ...).
    Rule(
        tool="run_bash",
        arg_patterns={
            "cmd": (
                r"regex:\b(?:curl|wget|fetch)\b[^|]*"
                r"\|\s*(?:sh|bash|zsh|python\d?|perl|ruby|php|node)\b"
            ),
        },
        decision="deny",
        reason=(
            "pipe-to-interpreter (curl|sh / wget|bash / ...) rejected"
        ),
    ),
    # Encoded payload pipe-to-interpreter:
    #   echo <b64> | base64 -d | sh
    #   printf 'raw' | sh
    # The key tell is any data source piped through `base64 -d` into
    # a shell, OR direct echo/printf into sh.
    Rule(
        tool="run_bash",
        arg_patterns={
            "cmd": (
                r"regex:\b(?:echo|printf|cat)\b[^|]*"
                r"\|\s*base64\s+(?:-d|--decode|-D)\s*"
                r"\|\s*(?:sh|bash|zsh|python\d?|perl|ruby|php|node)\b"
            ),
        },
        decision="deny",
        reason="base64 decode-then-exec pipeline rejected",
    ),
    Rule(
        tool="run_bash",
        arg_patterns={
            "cmd": (
                r"regex:\b(?:echo|printf)\b[^|]*"
                r"\|\s*(?:sh|bash|zsh)\b"
            ),
        },
        decision="deny",
        reason="echo/printf piped to shell rejected",
    ),
    # Path-escape in bash command strings (catches ``rm ../../etc/*``).
    Rule(
        tool="run_bash",
        arg_patterns={
            "cmd": r"regex:(?:^|[\s;&|=`\"'])\.\.(?:/|\\)",
        },
        decision="deny",
        reason="parent-directory traversal sequence rejected",
    ),
    Rule(
        tool="run_bash",
        arg_patterns={"cmd": r"regex:\bsudo\b"},
        decision="deny",
        reason="sudo invocations rejected",
    ),
    Rule(
        tool="run_bash",
        arg_patterns={
            "cmd": r"regex:\b(shutdown|reboot|halt|poweroff)\b",
        },
        decision="deny",
        reason="system power command rejected",
    ),
    Rule(
        tool="run_bash",
        arg_patterns={
            "cmd": r"regex:>\s*/dev/(sd[a-z]|nvme\d|hd[a-z])",
        },
        decision="deny",
        reason="raw block-device write rejected",
    ),
    Rule(
        tool="run_bash",
        # ``:`` is not a word character, so ``\b`` doesn't anchor
        # correctly. Drop the word boundary and pattern-match the
        # canonical fork-bomb shape directly.
        arg_patterns={"cmd": r"regex::\(\)\s*\{.*:\s*\|\s*:\s*&.*\}\s*;\s*:"},
        decision="deny",
        reason="fork-bomb pattern rejected",
    ),
    Rule(
        tool="run_bash",
        arg_patterns={"cmd": r"regex:\bmkfs\."},
        decision="deny",
        reason="filesystem format rejected",
    ),
    Rule(
        tool="run_bash",
        arg_patterns={"cmd": r"regex:\bdd\b.*\bof=/dev/"},
        decision="deny",
        reason="dd to raw device rejected",
    ),
    # ── write_file / edit_file ──────────────────────
    Rule(
        tool="write_file",
        arg_patterns={
            "path": r"regex:^(/etc|/boot|/sys|/proc)(/|$)",
        },
        decision="deny",
        reason="write into system directory rejected",
    ),
    Rule(
        tool="edit_file",
        arg_patterns={
            "path": r"regex:^(/etc|/boot|/sys|/proc)(/|$)",
        },
        decision="deny",
        reason="edit inside system directory rejected",
    ),
    Rule(
        tool="write_file",
        arg_patterns={
            "path": (
                r"regex:(\.ssh/(id_|authorized_keys)"
                r"|\.aws/credentials|\.env$|credentials\.json$)"
            ),
        },
        decision="deny",
        reason="write to credentials file rejected",
    ),
    # Path-escape for filesystem tools. Parent-dir sequence in a
    # path arg is almost always wrong (and if it isn't, the operator
    # is expected to opt in with an ``allow`` rule above).
    Rule(
        tool="write_file",
        arg_patterns={"path": r"regex:(?:^|/)\.\.(?:/|$)"},
        decision="deny",
        reason="write path contains `..` traversal rejected",
    ),
    Rule(
        tool="edit_file",
        arg_patterns={"path": r"regex:(?:^|/)\.\.(?:/|$)"},
        decision="deny",
        reason="edit path contains `..` traversal rejected",
    ),
    Rule(
        tool="read_file",
        arg_patterns={"path": r"regex:(?:^|/)\.\.(?:/|$)"},
        decision="deny",
        reason="read path contains `..` traversal rejected",
    ),
    # ── catch-all for unknown tools (off by default) ──
    # Operators who want a zero-trust posture bump
    # default_decision to "deny" on their Policy instance.
]


def default_policy() -> Policy:
    """Return a fresh :class:`Policy` seeded with the default rules.

    Fresh instance each call so operators can mutate
    :attr:`Policy.rules` without aliasing a shared list.

    P0#1 Task 7: ``default_decision`` changed from ``"allow"`` to
    ``"ask"`` so LLM-originated tool calls that don't match any
    explicit allow rule surface to the human via
    ``/v1/agent/permission`` instead of running silently. Operators
    running batch / benchmark jobs can restore the legacy ``allow``
    default via ``SANCIO_DEFAULT_DECISION=allow``.
    """
    import os as _os

    default = _os.environ.get("SANCIO_DEFAULT_DECISION", "ask").strip().lower()
    if default not in ("allow", "deny", "ask"):
        default = "ask"

    return Policy(
        rules=list(_DEFAULT_RULES),
        default_decision=default,
    )


__all__ = ["default_policy"]
