"""Aegis permission DSL (A4, v3 roadmap).

Public surface:

* :class:`Rule` / :class:`Policy` — dataclasses with
  ``from_dict``/``to_dict`` for JSON-friendly persistence.
* :func:`make_policy_pre_hook` — plug a Policy into
  :class:`persona.engine.agent_loop.AgentLoop` as a PreToolUseHook.
* :class:`PermissionAsk` — signal exception for human-in-the-loop
  rules (``decision="ask"``).
* :func:`default_policy` — bundled common-sense rule pack
  (rm -rf, sudo, pipe-to-interpreter, /etc writes, ...).
"""

from __future__ import annotations

from .defaults import default_policy
from .dsl import Decision, PermissionAsk, Policy, Rule
from .hook import make_policy_pre_hook
from .matcher import pattern_matches, rule_matches

__all__ = [
    "Decision",
    "PermissionAsk",
    "Policy",
    "Rule",
    "default_policy",
    "make_policy_pre_hook",
    "pattern_matches",
    "rule_matches",
]
