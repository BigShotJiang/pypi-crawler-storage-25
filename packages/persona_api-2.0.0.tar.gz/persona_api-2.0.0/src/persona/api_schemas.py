"""Pydantic v2 request / response schemas for the Aegis HTTP API.

Right now this module is **cerno-cycle only** — it mirrors the
manual ``isinstance`` validation inside
:func:`persona.api._cerno_cycle` and the dataclass tree in
:mod:`persona.cerno.types` one-for-one.

Why a mirror instead of importing the dataclasses
-------------------------------------------------
The wire contract and the internal dataclass tree are on **different
release cadences**. Pinning the OpenAPI shape to ``dataclasses``
would leak every refactor of :mod:`persona.cerno.types` into the
public API surface. Instead we keep two sources of truth that
travel together: the dataclasses stay free to evolve, and the
schemas stay free to add forward-compatible optional fields without
touching ``cerno/types.py``.

Validation error mapping
------------------------
The existing ``/v1/cerno/cycle`` endpoint produces three 400 error
codes that live external clients depend on::

    missing_field  -> "intent" or "child_id" missing / empty
    invalid_field  -> a field is present but wrong type
    invalid_body   -> body is not a JSON object at all

``CernoCycleRequest`` preserves those semantics via
``extra="forbid"`` + ``min_length=1`` + strict types, and the
endpoint translates pydantic :class:`ValidationError` back to those
three codes at the call site (see ``api._cerno_cycle``).

Literal choices
---------------
``ActionOut.type``: mirrors the four ``CernoAction`` dataclasses
    exactly (allow / deny / transfer / recalibrate).
``ReviewOut / AssessmentOut``: severity + risk levels mirror
    :data:`persona.cerno.types.DefectSeverity` and
    :data:`persona.cerno.types.RiskLevel`.
``StateOut.current_identity``: uses ``str`` rather than a ``Literal``
    union because the real runtime values come from the Cerno
    ``MotherIdentity`` alias, which may gain entries without the
    public API bumping a major. Pinning a ``Literal`` here would
    make the schema reject otherwise-valid state snapshots — the
    cure worse than the disease.
"""

from __future__ import annotations

from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field

# ── Request ─────────────────────────────────────


class CernoCycleRequest(BaseModel):
    """Request body for ``POST /v1/cerno/cycle``.

    Mirrors the manual ``isinstance`` checks currently in
    :func:`persona.api._cerno_cycle`. All field constraints are
    enforced by pydantic v2 validators so validation errors map to
    the existing 400 error shape at the call site.
    """

    model_config = ConfigDict(extra="forbid")

    intent: str = Field(
        ...,
        min_length=1,
        description=(
            "The user-facing intent the child agent is acting on. "
            "Must be a non-empty string."
        ),
    )
    child_output: str = Field(
        default="",
        description=(
            "The candidate child-agent output to be reviewed. "
            "Empty string is allowed on pre-check cycles."
        ),
    )
    child_id: str = Field(
        ...,
        min_length=1,
        description=(
            "Stable per-tenant child session identifier — used as "
            "the key into the module-level Cerno registry."
        ),
    )
    config: dict[str, Any] | None = Field(
        default=None,
        description=(
            "Optional ``CernoConfig`` field overrides applied at "
            "first-create time only. Ignored on subsequent cycles "
            "for the same ``child_id``."
        ),
    )
    tenant_id: str = Field(
        default="default",
        min_length=1,
        description=(
            "Optional multi-tenant scope. Each tenant has its own "
            "LRU + TTL clock, so overflow in one tenant cannot "
            "evict entries in another. Defaults to the ``default`` "
            "tenant so existing single-tenant clients keep working."
        ),
    )


# ── Response — nested leaves ────────────────────


class DefectHitOut(BaseModel):
    """Wire shape of :class:`persona.cerno.types.DefectHit`.

    Field names mirror the dataclass exactly — note that the real
    dataclass uses ``evidence`` (not ``detail``).
    """

    id: str
    severity: Literal["low", "medium", "high"]
    evidence: str
    confidence: float


class ReviewOut(BaseModel):
    """Wire shape of :class:`persona.cerno.types.ReviewResult`."""

    defects_found: list[DefectHitOut]
    quality_score: int
    aligned_with_assessment: bool
    sycophancy_risk: float
    reviewed_at: float


class AssessmentOut(BaseModel):
    """Wire shape of :class:`persona.cerno.types.Assessment`.

    ``risk_level`` mirrors :data:`persona.cerno.types.RiskLevel`
    — the full four-value set, not the three-value subset.
    """

    user_intent: str
    risk_level: Literal["low", "medium", "high", "critical"]
    expected_traits: list[str]
    assessed_at: float


class HandoffRecordOut(BaseModel):
    """Wire shape of :class:`persona.cerno.types.HandoffRecord`."""

    from_agent: str
    completed_work: str
    remaining_work: str
    unresolved_issues: list[str]
    transfer_reason: str
    transferred_at: float


class EquilibriumStateOut(BaseModel):
    """Wire shape of :class:`persona.cerno.types.EquilibriumState`."""

    pressure: float
    breaker_tripped: bool
    cooldown_remaining: int
    deny_rate: float
    total_steps: int
    pressure_history: list[float]
    tct_frozen: bool


# ── Response — action union ─────────────────────


class ActionOut(BaseModel):
    """Flat projection of the ``CernoAction`` union.

    ``type`` is the discriminator (one of the four literals).
    ``reason`` / ``defects`` / ``handoff`` are populated only on
    the dataclass variants that carry them; other action types
    leave them ``None``.
    """

    type: Literal["allow", "deny", "transfer", "recalibrate"]
    reason: str | None = None
    # ``CernoDeny.defects`` is ``list[str]`` of defect ids (e.g.
    # "L7"), NOT a ``list[DefectHit]``. Mirror that literally.
    defects: list[str] | None = None
    handoff: HandoffRecordOut | None = None


# ── Response — top-level state ──────────────────


class StateOut(BaseModel):
    """Subset of :class:`persona.cerno.types.CernoState`.

    We do NOT serialize ``assessment`` and ``review`` here — those
    already live at the top level of the response. This field only
    mirrors the bookkeeping pieces the endpoint exposes explicitly
    in ``_cerno_cycle`` (``state.child_id``, ``consecutive_denies``,
    ``current_identity``, ``equilibrium``, ``recent_scores``).

    ``current_identity`` is ``str`` rather than a ``Literal`` — the
    underlying ``MotherIdentity`` type is private and may grow;
    pinning the wire schema to a subset would reject otherwise-
    valid state.
    """

    child_id: str
    consecutive_denies: int
    current_identity: str
    equilibrium: EquilibriumStateOut
    recent_scores: list[int]


# ── Response — top-level envelope ───────────────


class CernoCycleResponse(BaseModel):
    """Top-level 200 body for ``POST /v1/cerno/cycle``.

    Shape::

        {
          "action":     ActionOut,
          "review":     ReviewOut | None,
          "assessment": AssessmentOut | None,
          "state":      StateOut,
        }

    ``review`` and ``assessment`` are nullable because on the very
    first cycle, before the Cerno has run Step R / Step A, the
    underlying ``CernoState`` still holds ``None`` for both. Once
    the 7-step cycle has executed at least once they are populated.
    """

    action: ActionOut
    review: ReviewOut | None = None
    assessment: AssessmentOut | None = None
    state: StateOut
