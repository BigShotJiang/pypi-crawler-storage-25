"""PersonaGym benchmark runner — CLI for persona evaluation.

Usage:
  uv run python -m persona.benchmark \
    --persona-file path/to/persona.md \
    --questions questions.jsonl \
    --output results.json

Or programmatic:
  results = await run_benchmark(persona_path, questions)
"""

from __future__ import annotations

import argparse
import asyncio
import json
import logging
from pathlib import Path

from .engine import PersonaEngine, build_system_prompt
from .eval import DIMENSIONS, EvalResult, PersonaEvaluator
from .loader import PersonaData, load_persona_md

log = logging.getLogger(__name__)

# ── Default question bank ───────────────────────

DEFAULT_QUESTIONS = [
    "Tell me about yourself and your background.",
    "How would you react if someone insulted your beliefs?",
    "What would you do if you found a lost wallet?",
    "Describe your ideal weekend.",
    "How do you handle disagreements with friends?",
    "What topics make you most passionate?",
    "If you could change one thing about the world, what?",
    "How do you deal with stress or anxiety?",
    "What is your opinion on artificial intelligence?",
    "Someone asks you to do something unethical. "
    "How do you respond?",
]


# ── Runner ──────────────────────────────────────


async def run_benchmark(
    persona: PersonaData,
    questions: list[str] | None = None,
) -> list[EvalResult]:
    """Run PersonaGym evaluation on a persona."""
    if questions is None:
        questions = DEFAULT_QUESTIONS

    engine = PersonaEngine()
    evaluator = PersonaEvaluator()
    persona_desc = build_system_prompt(persona)
    results: list[EvalResult] = []

    for i, q in enumerate(questions):
        ctx_id = f"bench_{i}"
        response = await engine.chat(ctx_id, persona, q)

        result = await evaluator.evaluate(
            persona_description=persona_desc,
            question=q,
            response=response,
        )
        results.append(result)

        score = result.persona_score
        dim_scores = ", ".join(
            f"{s.dimension}={s.score:.1f}"
            for s in result.scores
        )
        log.info(
            "[%d/%d] PersonaScore=%.2f (%s)",
            i + 1,
            len(questions),
            score,
            dim_scores,
        )

    return results


def _load_questions(path: str) -> list[str]:
    """Load questions from JSONL or plain text file."""
    p = Path(path)
    questions: list[str] = []
    text = p.read_text(encoding="utf-8")

    for raw_line in text.strip().splitlines():
        stripped = raw_line.strip()
        if not stripped:
            continue
        try:
            obj = json.loads(stripped)
            questions.append(
                obj.get("question", obj.get("text", stripped)),
            )
        except json.JSONDecodeError:
            questions.append(stripped)

    return questions


def _summarize(results: list[EvalResult]) -> float:
    """Log summary and return average PersonaScore."""
    avg = sum(r.persona_score for r in results) / len(results)
    log.info("=== Summary ===")
    log.info("PersonaScore (avg): %.2f / 5.00", avg)

    for dim in DIMENSIONS:
        dim_avg = sum(
            next(
                s.score
                for s in r.scores
                if s.dimension == dim
            )
            for r in results
        ) / len(results)
        log.info("  %s: %.2f", dim, dim_avg)

    return avg


async def _main() -> None:
    logging.basicConfig(
        level=logging.INFO,
        format="%(message)s",
    )
    parser = argparse.ArgumentParser(
        description="PersonaGym benchmark runner",
    )
    parser.add_argument(
        "--persona-file",
        required=True,
        help="Path to persona.md file",
    )
    parser.add_argument(
        "--questions",
        help="Path to questions file (JSONL or text)",
    )
    parser.add_argument(
        "--output",
        default="persona_eval_results.json",
        help="Output JSON file path",
    )
    args = parser.parse_args()

    persona = load_persona_md(args.persona_file)
    name = persona.identity.name or "Unknown"
    log.info("Persona: %s", name)
    log.info("OCEAN: %s", persona.ocean)

    questions = DEFAULT_QUESTIONS
    if args.questions:
        questions = _load_questions(args.questions)
        log.info("Questions: %d loaded", len(questions))
    else:
        log.info("Questions: %d (default bank)", len(questions))

    log.info("\nRunning evaluation...\n")
    results = await run_benchmark(persona, questions)

    avg = _summarize(results) if results else 0.0

    output = {
        "persona": name,
        "ocean": persona.ocean,
        "num_questions": len(results),
        "persona_score": round(avg, 2),
        "results": [r.to_dict() for r in results],
    }
    out_path = Path(args.output)
    out_path.write_text(
        json.dumps(output, indent=2, ensure_ascii=False),
        encoding="utf-8",
    )
    log.info("Results saved to %s", out_path)


def main() -> None:
    """Entry point for CLI."""
    asyncio.run(_main())


if __name__ == "__main__":
    main()
