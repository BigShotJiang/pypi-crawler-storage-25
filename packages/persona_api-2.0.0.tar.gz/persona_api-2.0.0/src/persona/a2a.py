"""A2A endpoints — `/v1/a2a/{invoke,capabilities,status}`.

Wires the five security pillars from :mod:`persona.a2a_security`
plus the peer registry from :mod:`persona.a2a_registry` into three
Starlette routes. Protocol contract: see
``docs/a2a-protocol.md``.

The module exposes :func:`create_a2a_routes` which returns the
``Route`` list consumed by :func:`persona.api.create_aegis_routes`.
"""

from __future__ import annotations

import os
import time
import uuid
from collections import OrderedDict
from pathlib import Path
from typing import Any

import yaml
from starlette.requests import Request
from starlette.responses import JSONResponse
from starlette.routing import Route

from .a2a_registry import PeerRegistry
from .a2a_security import (
    A2ADenied,
    AuditChain,
    NonceCache,
    RateLimiter,
    check_capability,
    check_timestamp_skew,
    validate_envelope_shape,
    verify_ed25519,
    verify_hmac,
    verify_jwt,
)

# Module singletons — populated lazily on first request so tests
# can monkey-patch paths via env vars before the factory runs.
_registry: PeerRegistry | None = None
_nonces: NonceCache | None = None
_rate_limiter: RateLimiter | None = None
_audit: AuditChain | None = None
_my_agent_id: str | None = None
_capabilities: list[dict] | None = None

# In-memory invocation store for `agent.status`. Stays simple —
# long-running jobs land here keyed by invocation_id.
#
# P0#1 Task 5: pre-P0 this was an unbounded dict — a long-running
# process accumulates one entry per invocation forever. A caller
# that hits /v1/a2a/invoke 1/s would add 86400 entries/day. Now we
# cap at ``_INVOCATIONS_MAX`` (env ``SANCIO_A2A_INVOCATIONS_MAX``,
# default 10_000) with a 24h TTL and LRU eviction on overflow.

_INVOCATIONS_MAX = int(
    os.environ.get("SANCIO_A2A_INVOCATIONS_MAX", "10000"),
)
_INVOCATIONS_TTL_S = float(
    os.environ.get("SANCIO_A2A_INVOCATIONS_TTL_S", str(24 * 3600)),
)


class _InvocationsLRU:
    """OrderedDict-backed LRU + TTL. Same shape as ``_ProfilesLRU``.

    Kept in this module rather than shared with ``api._ProfilesLRU``
    because ``_invocations`` stores plain dicts (not ``PersonaData``)
    — typing a shared generic cache would drag more surface area
    than the duplication saves at this scale.
    """

    def __init__(self, max_size: int, ttl_s: float) -> None:
        self._max_size = max(1, max_size)
        self._ttl_s = max(1.0, ttl_s)
        self._store: "OrderedDict[str, tuple[dict, float]]" = (
            OrderedDict()
        )

    def __len__(self) -> int:
        return len(self._store)

    def __contains__(self, key: str) -> bool:
        return key in self._store

    def _evict_expired(self, now: float) -> None:
        expired = [
            k for k, (_v, ts) in self._store.items()
            if now - ts > self._ttl_s
        ]
        for k in expired:
            self._store.pop(k, None)

    def get(self, key: str, default: dict | None = None) -> dict | None:
        now = time.time()
        self._evict_expired(now)
        entry = self._store.get(key)
        if entry is None:
            return default
        value, _ts = entry
        self._store[key] = (value, now)
        self._store.move_to_end(key)
        return value

    def __setitem__(self, key: str, value: dict) -> None:
        now = time.time()
        self._evict_expired(now)
        self._store[key] = (value, now)
        self._store.move_to_end(key)
        while len(self._store) > self._max_size:
            self._store.popitem(last=False)

    def clear(self) -> None:
        self._store.clear()


_invocations: _InvocationsLRU = _InvocationsLRU(
    max_size=_INVOCATIONS_MAX, ttl_s=_INVOCATIONS_TTL_S,
)


# ── Config loaders ──────────────────────────────


def _load_yaml(path: str | Path, default: Any) -> Any:
    p = Path(path)
    if not p.exists():
        return default
    try:
        return yaml.safe_load(p.read_text(encoding="utf-8")) or default
    except Exception:
        return default


_CONFIG_ENV_VARS = {
    "a2a_capabilities.yaml": "SANCIO_A2A_CAPABILITIES_PATH",
    "a2a_limits.yaml": "SANCIO_A2A_LIMITS_PATH",
}
_CONFIG_ENV_VARS_LEGACY = {
    "a2a_capabilities.yaml": "AEGIS_A2A_CAPABILITIES_PATH",
    "a2a_limits.yaml": "AEGIS_A2A_LIMITS_PATH",
}


def _config_path(name: str) -> Path:
    env_var = _CONFIG_ENV_VARS.get(name)
    if env_var:
        override = os.environ.get(env_var)
        if override:
            return Path(override)
    # Backward compat: try AEGIS_ prefixed env var.
    legacy = _CONFIG_ENV_VARS_LEGACY.get(name)
    if legacy:
        override = os.environ.get(legacy)
        if override:
            return Path(override)
    return Path("config") / name


def _load_capabilities() -> list[dict]:
    data = _load_yaml(
        _config_path("a2a_capabilities.yaml"),
        {"capabilities": []},
    )
    caps = data.get("capabilities") if isinstance(data, dict) else None
    return caps or []


def _load_limits() -> dict:
    data = _load_yaml(
        _config_path("a2a_limits.yaml"),
        {"default": {"rpm": 60, "day_quota": 10000}, "overrides": {}},
    )
    if not isinstance(data, dict):
        return {"default": {"rpm": 60, "day_quota": 10000}, "overrides": {}}
    return data


# ── Singleton accessors (test-friendly) ─────────


def get_registry() -> PeerRegistry:
    global _registry
    if _registry is None:
        path = (
            os.environ.get("SANCIO_A2A_REGISTRY_PATH")
            or os.environ.get(
                "AEGIS_A2A_REGISTRY_PATH",
                "data/a2a_peers.json",
            )
        )
        _registry = PeerRegistry(path)
    return _registry


def get_nonce_cache() -> NonceCache:
    global _nonces
    if _nonces is None:
        _nonces = NonceCache()
    return _nonces


def get_rate_limiter() -> RateLimiter:
    global _rate_limiter
    if _rate_limiter is None:
        cfg = _load_limits()
        default = cfg.get("default") or {}
        _rate_limiter = RateLimiter(
            rpm=int(default.get("rpm", 60)),
            day_quota=int(default.get("day_quota", 10000)),
            overrides=cfg.get("overrides") or {},
        )
    return _rate_limiter


def get_audit() -> AuditChain:
    global _audit
    if _audit is None:
        path = (
            os.environ.get("SANCIO_A2A_AUDIT_PATH")
            or os.environ.get(
                "AEGIS_A2A_AUDIT_PATH",
                "logs/a2a_audit.jsonl",
            )
        )
        _audit = AuditChain(path)
    return _audit


def get_my_agent_id() -> str:
    global _my_agent_id
    if _my_agent_id is None:
        _my_agent_id = (
            os.environ.get("SANCIO_A2A_AGENT_ID")
            or os.environ.get(
                "AEGIS_A2A_AGENT_ID",
                "sancio.local",
            )
        )
    return _my_agent_id


def get_capabilities() -> list[dict]:
    global _capabilities
    if _capabilities is None:
        _capabilities = _load_capabilities()
    return _capabilities


def reset_singletons_for_tests() -> None:
    """Test helper — drop every cached singleton.

    Callers that mutate env vars (registry path, audit path, agent
    id) between tests should call this right after so the next
    ``get_*`` rebuilds with the new config.
    """
    global _registry, _nonces, _rate_limiter, _audit
    global _my_agent_id, _capabilities, _invocations
    _registry = None
    _nonces = None
    _rate_limiter = None
    _audit = None
    _my_agent_id = None
    _capabilities = None
    _invocations = _InvocationsLRU(
        max_size=_INVOCATIONS_MAX, ttl_s=_INVOCATIONS_TTL_S,
    )


# ── Tool dispatcher ─────────────────────────────


# Registered inbound tool handlers. Signature: (params: dict) -> dict.
# Tests and production code register via ``register_tool``. The
# default set is intentionally minimal; the production wiring adds
# ``safety.classify`` etc. from :mod:`persona.guards`.
_TOOL_HANDLERS: dict[str, Any] = {}


def register_tool(name: str, handler: Any) -> None:
    _TOOL_HANDLERS[name] = handler


def _default_tools() -> None:
    """Register default tool handlers once."""
    if "echo" in _TOOL_HANDLERS:
        return

    def _echo(params: dict) -> dict:
        return {"echo": params}

    def _safety_classify(params: dict) -> dict:
        # Thin wrapper so inbound peers can probe the safety guard
        # without going through /v1/chat. Falls back to a minimal
        # signal when guards module is unavailable.
        text = str(params.get("text", ""))
        try:
            from .guards import classify_safety
            result = classify_safety(text)
            return {
                "level": result.level.value,
                "threat_type": getattr(result, "threat_type", None),
            }
        except Exception as exc:  # pragma: no cover
            return {"level": "UNKNOWN", "error": str(exc)}

    register_tool("echo", _echo)
    register_tool("safety.classify", _safety_classify)


_default_tools()


# ── Security pipeline ───────────────────────────


def _verify_identity(
    request: Request, env: dict, mode: str,
) -> tuple[str, str | None]:
    """Return (caller_agent_id, public_key_b64_or_None). DENY on fail.

    JWT mode: ``Authorization: Bearer <token>`` where the token is
    signed by the caller's Ed25519 private key, registered in the
    peer store.

    mTLS mode: the caller's ``agent_id`` is expected in a trusted
    header (``X-Agent-Id``) and the TLS layer has already verified
    the client cert — Uvicorn is responsible for that upstream. We
    still require the peer to be registered.
    """
    registry = get_registry()
    caller = str(env.get("from", ""))
    peer = registry.get(caller)
    if peer is None:
        raise A2ADenied(403, "unknown_peer",
                        f"peer not registered: {caller}")

    if mode == "jwt":
        auth = request.headers.get("authorization", "")
        if not auth.lower().startswith("bearer "):
            raise A2ADenied(401, "missing_auth",
                            "Authorization: Bearer required")
        token = auth[len("Bearer "):].strip()
        claims = verify_jwt(
            token, peer.public_key_b64, expected_aud=get_my_agent_id(),
        )
        if claims.get("iss") != caller:
            raise A2ADenied(401, "jwt_iss_mismatch",
                            "jwt iss does not match envelope.from")
        return caller, peer.public_key_b64

    if mode == "mtls":
        # The TLS layer is assumed to have already verified the
        # client cert at connection time. We bind the cert CN to an
        # agent id via a trusted header set by the TLS terminator.
        header_id = request.headers.get("x-agent-id")
        if not header_id or header_id != caller:
            raise A2ADenied(401, "mtls_id_mismatch",
                            "X-Agent-Id missing or does not match")
        return caller, peer.public_key_b64

    raise A2ADenied(500, "bad_auth_mode",
                    f"unknown SANCIO_A2A_AUTH_MODE: {mode}")


def _verify_signature(env: dict, peer_public_key_b64: str) -> None:
    """Signature verify — Ed25519 preferred, HMAC fallback.

    Failure is a 401. Callers who use HMAC must register
    ``hmac_secret_b64`` on the peer record.
    """
    if peer_public_key_b64 and verify_ed25519(peer_public_key_b64, env):
        return
    # HMAC fallback: look up the per-peer shared secret.
    peer = get_registry().get(str(env.get("from", "")))
    if peer and peer.hmac_secret_b64:
        import base64
        try:
            secret = base64.b64decode(peer.hmac_secret_b64)
        except Exception:
            secret = b""
        if secret and verify_hmac(secret, env):
            return
    raise A2ADenied(401, "bad_signature",
                    "envelope signature invalid")


def _security_pipeline(
    request: Request, env: dict,
) -> str:
    """Run all 5 pillars. Returns caller agent_id. Raises on deny.

    Order matters:
      400 shape → 401 identity → 401 sig → 401 timestamp →
      409 replay → 403 capability → 429 rate.
    """
    validate_envelope_shape(env)

    if env.get("to") != get_my_agent_id():
        raise A2ADenied(400, "wrong_audience",
                        f"envelope.to != {get_my_agent_id()}")

    mode = (
        os.environ.get("SANCIO_A2A_AUTH_MODE")
        or os.environ.get("SANCIO_A2A_AUTH_MODE") or os.environ.get("AEGIS_A2A_AUTH_MODE", "jwt")
    ).lower()
    caller, pub_key = _verify_identity(request, env, mode)

    _verify_signature(env, pub_key or "")
    check_timestamp_skew(env)
    get_nonce_cache().check_and_add(str(env.get("nonce", "")))

    method = str(env.get("method", ""))
    params = env.get("params") or {}
    tool = None
    if method in ("agent.invoke", "tool.delegate"):
        tool = params.get("tool") if isinstance(params, dict) else None
        if not tool:
            raise A2ADenied(400, "missing_tool",
                            f"{method} requires params.tool")
    check_capability(get_capabilities(), method, tool)
    get_rate_limiter().check(caller)

    return caller


# ── Routes ──────────────────────────────────────


def _dispatch_tool(
    env: dict, params: dict, caller: str,
) -> dict | JSONResponse:
    """Execute a registered tool handler with bounded error handling.

    Returns the result dict on success, or a :class:`JSONResponse`
    already shaped as an error reply on failure. Extracted from the
    invoke endpoint to keep that function's nesting depth shallow.
    """
    tool = params["tool"]
    handler = _TOOL_HANDLERS.get(tool)
    if handler is None:
        _audit_entry(
            "in", env, status=502, code="tool_missing", caller=caller,
        )
        return _error(502, "tool_missing", f"no handler: {tool}")
    tool_params = params.get("args") or params.get("input") or {}
    if not isinstance(tool_params, dict):
        tool_params = {"value": tool_params}
    merged = {
        k: v for k, v in params.items()
        if k not in ("tool", "args", "input")
    }
    merged.update(tool_params)
    inv_id = str(uuid.uuid4())
    _invocations[inv_id] = {
        "status": "running", "invocation_id": inv_id,
        "started_at": time.time(),
    }
    try:
        output = handler(merged)
    except Exception as exc:  # noqa: BLE001 — tool errors become 502
        _invocations[inv_id] = {
            "status": "error", "invocation_id": inv_id,
            "error": str(exc),
        }
        _audit_entry(
            "in", env, status=502, code="tool_error", caller=caller,
        )
        return _error(502, "tool_error", str(exc))
    _invocations[inv_id] = {
        "status": "done", "invocation_id": inv_id, "result": output,
    }
    return {"invocation_id": inv_id, "output": output}


async def _capabilities_endpoint(request: Request) -> JSONResponse:
    """Public advertisement — no auth required by design."""
    return JSONResponse({
        "agent_id": get_my_agent_id(),
        "version": "1",
        "capabilities": get_capabilities(),
    })


async def _invoke_endpoint(request: Request) -> JSONResponse:
    try:
        env = await request.json()
    except Exception:
        return _error(400, "bad_json", "request body is not valid JSON")

    try:
        caller = _security_pipeline(request, env)
    except A2ADenied as deny:
        _audit_entry("in", env, status=deny.status, code=deny.code)
        return _error(deny.status, deny.code, deny.message)

    method = env["method"]
    params = env.get("params") or {}
    req_id = env.get("id")

    try:
        if method == "capabilities.list":
            result: dict = {
                "agent_id": get_my_agent_id(),
                "capabilities": get_capabilities(),
            }
        elif method == "agent.status":
            inv_id = str(params.get("invocation_id", ""))
            result = _invocations.get(
                inv_id, {"status": "unknown", "invocation_id": inv_id},
            )
        elif method in ("agent.invoke", "tool.delegate"):
            resp = _dispatch_tool(env, params, caller)
            if isinstance(resp, JSONResponse):
                return resp
            result = resp
        else:
            _audit_entry("in", env, status=400,
                         code="unknown_method", caller=caller)
            return _error(400, "unknown_method", f"method: {method}")
    except A2ADenied as deny:
        _audit_entry("in", env, status=deny.status, code=deny.code,
                     caller=caller)
        return _error(deny.status, deny.code, deny.message)

    _audit_entry("in", env, status=200, code="ok", caller=caller)
    get_registry().touch(caller)
    return JSONResponse({"id": req_id, "result": result})


async def _status_endpoint(request: Request) -> JSONResponse:
    try:
        env = await request.json()
    except Exception:
        return _error(400, "bad_json", "request body is not valid JSON")
    try:
        caller = _security_pipeline(request, env)
    except A2ADenied as deny:
        _audit_entry("in", env, status=deny.status, code=deny.code)
        return _error(deny.status, deny.code, deny.message)

    params = env.get("params") or {}
    inv_id = str(params.get("invocation_id", ""))
    result = _invocations.get(
        inv_id, {"status": "unknown", "invocation_id": inv_id},
    )
    _audit_entry("in", env, status=200, code="ok", caller=caller)
    return JSONResponse({"id": env.get("id"), "result": result})


# ── Helpers ─────────────────────────────────────


def _error(status: int, code: str, message: str) -> JSONResponse:
    return JSONResponse(
        {"error": {"code": code, "message": message}},
        status_code=status,
    )


def _audit_entry(
    direction: str, env: dict, *, status: int, code: str,
    caller: str | None = None,
) -> None:
    try:
        get_audit().append({
            "ts": time.time(),
            "dir": direction,
            "agent_id": caller or env.get("from", "?"),
            "method": env.get("method", "?"),
            "status": status,
            "code": code,
            "req_id": env.get("id"),
        })
    except Exception:  # pragma: no cover
        # Audit is best-effort; never break the request on audit
        # IO failure (the verifier will catch any gap).
        pass


def create_a2a_routes() -> list[Route]:
    return [
        Route(
            "/v1/a2a/capabilities",
            _capabilities_endpoint,
            methods=["GET"],
        ),
        Route(
            "/v1/a2a/invoke", _invoke_endpoint, methods=["POST"],
        ),
        Route(
            "/v1/a2a/status", _status_endpoint, methods=["POST"],
        ),
    ]
