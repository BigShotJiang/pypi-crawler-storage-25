"""Persona ZIQ Router — complexity-based query routing.

Thin adapter over ``concinno.signal_patterns``. The regex
patterns and matcher helpers live in CCC (public, reusable);
this module keeps only the PersonaDepth enum, RouteDecision
dataclass, and the persona-specific decision logic.

Routes persona queries to appropriate processing depth:
  - FAST: cached system prompt, no RAG (greetings, simple chat)
  - STANDARD: RAG-augmented response (personality-relevant retrieval)
  - DEEP: full pipeline (RAG + reranker + multi-turn analysis)
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum

from concinno.signal_patterns import (
    is_character_challenge,
    is_greeting,
    is_identity_probe,
)


class PersonaDepth(Enum):
    """Processing depth for persona queries."""

    FAST = "fast"
    STANDARD = "standard"
    DEEP = "deep"


@dataclass
class RouteDecision:
    """Routing decision with transparency signals."""

    depth: PersonaDepth
    use_rag: bool
    use_reranker: bool
    signals: dict = field(default_factory=dict)


def _count_turns(message: str) -> int:
    """Estimate conversation complexity from message length."""
    words = len(message.split())
    if words < 10:  # noqa: PLR2004
        return 1
    if words < 50:  # noqa: PLR2004
        return 2
    return 3


def route_persona_query(
    message: str,
    turn_count: int = 0,
) -> RouteDecision:
    """Route a persona query to appropriate depth.

    PTME mapping:
      P (momentum): conversation turn count stability
      T (tension): identity probe / challenge detection
      M (memory): accumulated context length
      E (decision): final depth selection

    Args:
        message: User's input message.
        turn_count: Number of turns in current conversation.

    Returns:
        RouteDecision with depth, RAG/reranker flags, signals.
    """
    signals: dict = {}

    # Signal 1: Fast pattern match (greetings etc.)
    is_fast = is_greeting(message)
    signals["fast_match"] = is_fast

    # Signal 2: Deep identity probe
    is_deep = is_identity_probe(message)
    signals["identity_probe"] = is_deep

    # Signal 3: Character challenge
    is_challenge = is_character_challenge(message)
    signals["challenge"] = is_challenge

    # Signal 4: Turn complexity
    turn_complexity = _count_turns(message)
    signals["turn_complexity"] = turn_complexity
    signals["turn_count"] = turn_count

    # Decision logic
    if is_challenge:
        # Challenges need full pipeline to maintain consistency
        return RouteDecision(
            depth=PersonaDepth.DEEP,
            use_rag=True,
            use_reranker=True,
            signals=signals,
        )

    if is_deep or turn_count > 10 or turn_complexity >= 3:  # noqa: PLR2004
        return RouteDecision(
            depth=PersonaDepth.DEEP,
            use_rag=True,
            use_reranker=True,
            signals=signals,
        )

    if is_fast and turn_count < 3:  # noqa: PLR2004
        return RouteDecision(
            depth=PersonaDepth.FAST,
            use_rag=False,
            use_reranker=False,
            signals=signals,
        )

    # Default: standard with RAG, no reranker
    return RouteDecision(
        depth=PersonaDepth.STANDARD,
        use_rag=True,
        use_reranker=False,
        signals=signals,
    )
