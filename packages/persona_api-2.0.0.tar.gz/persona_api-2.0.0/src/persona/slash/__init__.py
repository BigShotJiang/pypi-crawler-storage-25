"""persona.slash — Pluggable slash-command system for ``sancio chat``.

M1 Week 2 (1.2.0) deliverable. Splits the previously inline slash
dispatch out of :mod:`persona.cli.chat` into a dedicated package so
new commands can be added without touching the REPL itself, and so
sub-packages (auto-update, persona-api, future Cerno tooling) can
register their own commands at install time via entry-points.

Architecture:
    * :class:`SlashCommand` — value object holding a name, doc-string,
      and a handler.
    * :class:`SlashRegistry` — ordered map of name → command with
      registration helpers and dispatch.
    * Five builtins live in sibling modules and are auto-loaded by
      :func:`build_default_registry`.

@module persona.slash
@responsibility Registry-of-commands abstraction + the five M1 Week 2
    builtins (``/clear`` ``/compact`` ``/status`` ``/model`` ``/help``).
@dependencies stdlib only at the registry level. Builtins import
    optionally from :mod:`persona.compaction` and the chat module.
@exports SlashCommand, SlashContext, SlashRegistry,
    build_default_registry, builtin_commands

License: AGPL-3.0-or-later.
"""

from __future__ import annotations

from .registry import (
    SlashCommand,
    SlashContext,
    SlashRegistry,
    build_default_registry,
    builtin_commands,
)

__all__ = [
    "SlashCommand",
    "SlashContext",
    "SlashRegistry",
    "build_default_registry",
    "builtin_commands",
]
