"""persona.slash.registry — Slash command core types + registry.

@module persona.slash.registry
@responsibility Define the value types (:class:`SlashCommand`,
    :class:`SlashContext`) and the registry that resolves a slash-name
    to a handler. Aliases supported (a single command can be registered
    under multiple names, e.g. ``/exit`` ⇔ ``/quit``).
@dependencies stdlib only.
@exports SlashCommand, SlashContext, SlashRegistry,
    build_default_registry, builtin_commands
"""

from __future__ import annotations

from collections.abc import Callable, Iterable
from dataclasses import dataclass, field
from typing import Any, Protocol, runtime_checkable

# ─────────────────────────────────────────────────────────────────
# Context object passed to every slash handler
# ─────────────────────────────────────────────────────────────────


@runtime_checkable
class _PrinterLike(Protocol):
    """Subset of the Rich Console / PlainPrinter surface we rely on."""

    def print(self, *args: Any, **kwargs: Any) -> None: ...

    def rule(self, title: str = "", **kwargs: Any) -> None: ...


@dataclass
class SlashContext:
    """Bundle of mutable state passed to a slash handler.

    The chat REPL builds one of these per turn and hands it to the
    dispatcher. Handlers mutate the fields in place (e.g. ``/clear``
    empties ``messages``; ``/model`` rebinds ``model_id``). Returning
    a falsy value from the handler signals "exit the REPL".

    Attributes:
        messages: The conversation history list — same reference the
            REPL holds. Mutate in place; never reassign.
        printer: Output sink (rich Console / PlainPrinter / mock).
        model_id: Current driver model id. Handlers may overwrite.
        compactor: Optional :class:`persona.compaction.AutoCompactor`
            owned by the REPL. ``/compact`` and ``/status`` consume
            it; the field stays ``None`` for tests that don't wire one.
        session_id: Stable id for the live REPL session, used by
            ``/status`` and (in M2) ``/resume``.
        extras: Free-form dict for sub-packages to stash references
            handlers might need without expanding the dataclass.
    """

    messages: list[dict[str, Any]]
    printer: _PrinterLike
    model_id: str = ""
    compactor: Any = None  # persona.compaction.AutoCompactor (optional dep)
    session_persist: Any = None  # persona.session_persist.SessionStore (optional)
    session_id: str = ""
    extras: dict[str, Any] = field(default_factory=dict)


# Handler signature — receives the context plus the trailing arg
# string (everything after the first whitespace). Returns False to
# end the REPL loop, anything else (True / None / int) keeps it running.
SlashHandler = Callable[[SlashContext, str], Any]


# ─────────────────────────────────────────────────────────────────
# SlashCommand value object
# ─────────────────────────────────────────────────────────────────


@dataclass(frozen=True)
class SlashCommand:
    """One registered slash command.

    Attributes:
        name: Canonical name *without* the leading slash. Lowercase by
            convention.
        doc: Short one-line description shown in ``/help``.
        handler: Callable receiving (:class:`SlashContext`, args).
        aliases: Extra names to register the same handler under.
        category: Optional grouping hint for ``/help`` (default
            ``"general"``). Builtins use ``"core"``.
    """

    name: str
    doc: str
    handler: SlashHandler
    aliases: tuple[str, ...] = ()
    category: str = "general"


# ─────────────────────────────────────────────────────────────────
# Registry
# ─────────────────────────────────────────────────────────────────


class SlashRegistry:
    """Name → SlashCommand map with dispatch + alias support.

    Keeps insertion order so ``/help`` lists commands in the order
    they were registered. A second registration of the same name
    overwrites the first — modules that want to extend a builtin can
    re-register the same name with a thicker handler.
    """

    def __init__(self) -> None:
        self._commands: dict[str, SlashCommand] = {}
        self._aliases: dict[str, str] = {}

    # ── Registration ─────────────────────────────────────────────

    def register(self, cmd: SlashCommand) -> None:
        """Add or replace *cmd* in the registry, including aliases.

        Names are normalised to lowercase. Empty names raise
        :class:`ValueError` — the dispatcher relies on a non-empty
        token after the leading slash.
        """
        name = cmd.name.strip().lower()
        if not name:
            raise ValueError("SlashCommand.name must be non-empty")
        # Drop stale aliases that pointed to a previous version.
        stale = [a for a, target in self._aliases.items() if target == name]
        for a in stale:
            self._aliases.pop(a, None)

        self._commands[name] = cmd
        for alias in cmd.aliases:
            alias_name = alias.strip().lower()
            if not alias_name or alias_name == name:
                continue
            self._aliases[alias_name] = name

    def register_function(
        self,
        name: str,
        doc: str,
        handler: SlashHandler,
        *,
        aliases: Iterable[str] = (),
        category: str = "general",
    ) -> SlashCommand:
        """Convenience wrapper around :meth:`register`."""
        cmd = SlashCommand(
            name=name,
            doc=doc,
            handler=handler,
            aliases=tuple(aliases),
            category=category,
        )
        self.register(cmd)
        return cmd

    def unregister(self, name: str) -> bool:
        """Remove a command + its aliases. Returns True if removed."""
        key = name.strip().lower()
        if key in self._aliases:
            key = self._aliases[key]
        cmd = self._commands.pop(key, None)
        if cmd is None:
            return False
        # Clear orphaned aliases.
        stale = [a for a, target in self._aliases.items() if target == key]
        for a in stale:
            self._aliases.pop(a, None)
        return True

    # ── Lookup ───────────────────────────────────────────────────

    def resolve(self, name: str) -> SlashCommand | None:
        """Return the SlashCommand for *name* (canonical or alias)."""
        key = name.strip().lower()
        if key in self._aliases:
            key = self._aliases[key]
        return self._commands.get(key)

    def __contains__(self, name: object) -> bool:
        if not isinstance(name, str):
            return False
        return self.resolve(name) is not None

    def __len__(self) -> int:
        return len(self._commands)

    def names(self) -> list[str]:
        """Canonical names in registration order."""
        return list(self._commands.keys())

    def aliases_for(self, name: str) -> list[str]:
        """All alias strings that resolve to *name* (excluding canonical)."""
        key = name.strip().lower()
        return sorted(
            alias for alias, target in self._aliases.items() if target == key
        )

    def commands(self) -> list[SlashCommand]:
        """Snapshot of all commands (registration order)."""
        return list(self._commands.values())

    def by_category(self) -> dict[str, list[SlashCommand]]:
        """Group commands by ``category`` field for ``/help`` rendering."""
        out: dict[str, list[SlashCommand]] = {}
        for cmd in self._commands.values():
            out.setdefault(cmd.category, []).append(cmd)
        return out

    # ── Dispatch ─────────────────────────────────────────────────

    def dispatch(self, line: str, ctx: SlashContext) -> Any:
        """Run the command encoded in *line* against *ctx*.

        ``line`` is the raw input including the leading ``/``. The
        first whitespace splits name from arg-tail. Unknown commands
        and empty input emit a friendly error via ``ctx.printer`` and
        return True (don't kill the REPL).
        """
        if not line.startswith("/"):
            ctx.printer.print("[err] dispatch called without leading slash.")
            return True
        body = line[1:].strip()
        if not body:
            ctx.printer.print("[err] empty slash command. Try /help.")
            return True
        name, _, args = body.partition(" ")
        cmd = self.resolve(name)
        if cmd is None:
            ctx.printer.print(
                f"[err] unknown command /{name}. Try /help.",
            )
            return True
        return cmd.handler(ctx, args.strip())


# ─────────────────────────────────────────────────────────────────
# Builtins helper
# ─────────────────────────────────────────────────────────────────


def builtin_commands() -> list[SlashCommand]:
    """Return the M1 Week 2 builtin command set in registration order.

    Imports are lazy so the registry module can be used in isolation
    (e.g. unit tests for the dispatcher itself) without pulling in
    the compaction module's optional deps.
    """
    from .commands import (
        clear_command,
        compact_command,
        exit_command,
        help_command,
        model_command,
        quit_command,
        resume_command,
        status_command,
    )

    return [
        clear_command(),
        compact_command(),
        status_command(),
        model_command(),
        help_command(),
        # Resume is wired alongside session-persist; tests confirm it
        # tolerates a missing SessionStore by replying with a friendly
        # error (see test_slash_resume_without_store).
        resume_command(),
        # ``/exit`` and ``/quit`` are the only non-Week-2-listed builtins
        # that ship — the REPL was unusable without a graceful shutdown
        # path, and the original chat.py had them inline. Carrying them
        # over is a no-regression move.
        exit_command(),
        quit_command(),
    ]


def build_default_registry() -> SlashRegistry:
    """Construct a SlashRegistry pre-populated with the builtins."""
    reg = SlashRegistry()
    for cmd in builtin_commands():
        reg.register(cmd)
    return reg
