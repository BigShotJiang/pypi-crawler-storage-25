"""persona.slash.commands — The five M1 Week 2 builtin slash commands.

@module persona.slash.commands
@responsibility Concrete handlers for ``/clear`` ``/compact``
    ``/status`` ``/model`` ``/help`` plus the carried-over ``/exit``
    ``/quit`` ``/resume`` (resume lives here so the registry has one
    import; the persistence integration lives in
    :mod:`persona.session_persist`).
@dependencies persona.compaction (optional — /compact and /status
    fall back to friendly errors when no AutoCompactor is on the
    context).
@exports clear_command, compact_command, exit_command, help_command,
    model_command, quit_command, resume_command, status_command
"""

from __future__ import annotations

from typing import Any

from .registry import SlashCommand, SlashContext

# ─────────────────────────────────────────────────────────────────
# /clear
# ─────────────────────────────────────────────────────────────────


def _clear_handler(ctx: SlashContext, _args: str) -> bool:
    """Drop every message in the conversation history.

    Mutates ``ctx.messages`` in place so the REPL keeps the same list
    reference (tests assert on identity in some places). Also clears
    the compactor's history if one is wired — a fresh conversation
    shouldn't carry forward stale compaction events.
    """
    ctx.messages.clear()
    if ctx.compactor is not None:
        try:
            ctx.compactor.history.clear()
        except AttributeError:
            pass
    ctx.printer.print("[ok] history cleared.")
    return True


def clear_command() -> SlashCommand:
    """Build the ``/clear`` SlashCommand."""
    return SlashCommand(
        name="clear",
        doc="Clear the conversation history.",
        handler=_clear_handler,
        aliases=("reset",),
        category="core",
    )


# ─────────────────────────────────────────────────────────────────
# /compact
# ─────────────────────────────────────────────────────────────────


def _compact_handler(ctx: SlashContext, args: str) -> bool:
    """Force an immediate compaction pass.

    Args may include ``--force`` (default behaviour anyway — ``/compact``
    always forces; the flag is accepted for muscle-memory compatibility
    with users coming from claude-code's CLI). When no compactor is
    wired we degrade to a friendly notice — tests with a bare REPL
    rely on this.
    """
    if ctx.compactor is None:
        ctx.printer.print(
            "[warn] no compactor attached to this REPL — /compact is a no-op.",
        )
        return True
    try:
        result = ctx.compactor.force_compact(ctx.messages)
    except Exception as exc:  # noqa: BLE001 — defence in depth
        ctx.printer.print(f"[err] compaction failed: {exc}")
        return True

    # Swap the rewritten messages into place. ``new_messages`` is a
    # fresh list so we slice-assign to keep the same list identity.
    ctx.messages[:] = result.new_messages
    if not result.triggered:
        ctx.printer.print(
            f"[ok] no compaction needed ({result.before_tokens} tokens, "
            f"reason: {result.reason}).",
        )
        return True
    ctx.printer.print(
        f"[ok] compacted: {result.before_messages}→{result.after_messages} "
        f"messages, {result.before_tokens}→{result.after_tokens} tokens "
        f"(saved {result.tokens_freed}, dropped {result.dropped_count}).",
    )
    if "--force" in args:
        # Acknowledge the noisy flag so users don't think it was ignored.
        pass
    return True


def compact_command() -> SlashCommand:
    """Build the ``/compact`` SlashCommand."""
    return SlashCommand(
        name="compact",
        doc="Force a context compaction pass right now.",
        handler=_compact_handler,
        aliases=("squash",),
        category="core",
    )


# ─────────────────────────────────────────────────────────────────
# /status
# ─────────────────────────────────────────────────────────────────


def _format_pct(frac: float) -> str:
    return f"{frac * 100:.1f}%"


def _status_handler(ctx: SlashContext, _args: str) -> bool:
    """Print a short health snapshot of the REPL session."""
    n_messages = len(ctx.messages)
    lines = [
        "── sancio chat session ──",
        f"  session_id : {ctx.session_id or '(unset)'}",
        f"  model      : {ctx.model_id or '(unset)'}",
        f"  messages   : {n_messages}",
    ]

    if ctx.compactor is not None:
        try:
            summary = ctx.compactor.usage_summary(ctx.messages)
        except Exception as exc:  # noqa: BLE001
            lines.append(f"  context    : (error: {exc})")
        else:
            lines.append(
                f"  context    : {summary['tokens']:,} / "
                f"{summary['context_window']:,} tokens "
                f"({_format_pct(summary['usage_pct'])} of window, "
                f"threshold {_format_pct(summary['threshold_pct'])})"
            )
            last = summary.get("last_event")
            if last:
                lines.append(
                    f"  last compact: {last['ts']} — freed {last['freed']} "
                    f"tokens, dropped {last['dropped']} messages"
                )
            else:
                lines.append("  last compact: (never)")
    else:
        lines.append("  context    : (no compactor attached)")

    if ctx.session_persist is not None:
        try:
            manifest = ctx.session_persist.get_manifest(ctx.session_id)
        except Exception as exc:  # noqa: BLE001
            lines.append(f"  persistence: (error reading manifest: {exc})")
        else:
            if manifest is None:
                lines.append(
                    "  persistence: (no manifest yet — first checkpoint pending)",
                )
            else:
                lines.append(
                    f"  persistence: created {manifest.get('created_at', '?')}, "
                    f"checkpoints {manifest.get('checkpoint_count', 0)}, "
                    f"last_active {manifest.get('last_active', '?')}",
                )
    else:
        lines.append("  persistence: (no SessionStore attached)")

    ctx.printer.print("\n".join(lines))
    return True


def status_command() -> SlashCommand:
    """Build the ``/status`` SlashCommand."""
    return SlashCommand(
        name="status",
        doc="Show session info: model, message count, context %.",
        handler=_status_handler,
        aliases=("info",),
        category="core",
    )


# ─────────────────────────────────────────────────────────────────
# /model
# ─────────────────────────────────────────────────────────────────


# Friendly aliases → driver model identifiers. Sancio's chat REPL
# resolves drivers via concinno.agent.session_loop.get_driver, which
# accepts the canonical Anthropic strings on the right.
_MODEL_ALIASES: dict[str, str] = {
    "opus": "claude-opus-4-7",
    "opus-4-7": "claude-opus-4-7",
    "opus-1m": "claude-opus-4-7[1m]",
    "sonnet": "claude-sonnet-4-7",
    "sonnet-4-7": "claude-sonnet-4-7",
    "haiku": "claude-haiku-4-5",
    "haiku-4-5": "claude-haiku-4-5",
}


def _resolve_model(arg: str) -> str:
    """Map a friendly alias to its canonical driver model id.

    Unknown aliases are returned verbatim — the user might know
    something we don't (e.g. a private model name in their config).
    The driver-side ``get_driver`` will surface a clean error in
    that case.
    """
    key = arg.strip().lower()
    return _MODEL_ALIASES.get(key, arg.strip())


def _model_handler(ctx: SlashContext, args: str) -> bool:
    """Switch the active model id.

    With no argument: prints the current model + the friendly alias
    table so the user sees what they can switch to. With an argument:
    rewrites ``ctx.model_id`` and lets the REPL pick it up on the
    next driver resolution.
    """
    if not args:
        ctx.printer.print(f"[ok] current model: {ctx.model_id or '(unset)'}")
        ctx.printer.print("aliases:")
        for alias in sorted(_MODEL_ALIASES):
            ctx.printer.print(f"  {alias:<10} → {_MODEL_ALIASES[alias]}")
        return True
    new_model = _resolve_model(args)
    old_model = ctx.model_id
    ctx.model_id = new_model
    ctx.extras["model_change"] = {"from": old_model, "to": new_model}
    ctx.printer.print(f"[ok] model switched: {old_model or '(unset)'} → {new_model}")
    return True


def model_command() -> SlashCommand:
    """Build the ``/model`` SlashCommand."""
    return SlashCommand(
        name="model",
        doc="Show or switch the active model (opus / sonnet / haiku / …).",
        handler=_model_handler,
        aliases=("m",),
        category="core",
    )


# ─────────────────────────────────────────────────────────────────
# /help
# ─────────────────────────────────────────────────────────────────


def _help_handler(ctx: SlashContext, args: str) -> bool:
    """List every registered command grouped by category.

    With no argument: full listing. With an argument: detailed view
    of one command (name, aliases, doc, category).

    The handler reaches into the registry through ``ctx.extras["registry"]``
    — set by the REPL when it constructs the context. Tests that drive
    the dispatcher directly populate this themselves.
    """
    registry = ctx.extras.get("registry")
    if registry is None:
        ctx.printer.print("[err] registry missing from context.")
        return True

    if args:
        cmd = registry.resolve(args.strip())
        if cmd is None:
            ctx.printer.print(f"[err] no command named /{args.strip()}.")
            return True
        ctx.printer.print(f"/{cmd.name} — {cmd.doc}")
        if cmd.aliases:
            ctx.printer.print(f"  aliases: {', '.join(cmd.aliases)}")
        ctx.printer.print(f"  category: {cmd.category}")
        return True

    grouped = registry.by_category()
    lines: list[str] = ["Available commands:"]
    for category in sorted(grouped):
        lines.append(f"\n[{category}]")
        for cmd in sorted(grouped[category], key=lambda c: c.name):
            alias_suffix = ""
            if cmd.aliases:
                alias_suffix = f" (aliases: {', '.join(cmd.aliases)})"
            lines.append(f"  /{cmd.name:<10} {cmd.doc}{alias_suffix}")
    ctx.printer.print("\n".join(lines))
    return True


def help_command() -> SlashCommand:
    """Build the ``/help`` SlashCommand."""
    return SlashCommand(
        name="help",
        doc="List slash commands or show details for one.",
        handler=_help_handler,
        aliases=("?",),
        category="core",
    )


# ─────────────────────────────────────────────────────────────────
# /resume — bridges to persona.session_persist
# ─────────────────────────────────────────────────────────────────


def _resume_handler(ctx: SlashContext, args: str) -> Any:
    """Restore conversation state from a saved session id.

    Required argument: the session id to resume. We delegate to the
    SessionStore wired on the context — when none is attached we
    print a friendly error so the test surface has a stable shape.
    """
    if ctx.session_persist is None:
        ctx.printer.print(
            "[warn] no SessionStore attached — /resume is a no-op.",
        )
        return True
    sid = args.strip()
    if not sid:
        ctx.printer.print(
            "[err] /resume requires a session id. "
            "Try /resume <id> (use /status to find yours).",
        )
        return True
    try:
        snapshot = ctx.session_persist.load_latest_checkpoint(sid)
    except Exception as exc:  # noqa: BLE001
        ctx.printer.print(f"[err] resume failed: {exc}")
        return True
    if snapshot is None:
        ctx.printer.print(f"[err] no checkpoint found for session {sid!r}.")
        return True
    ctx.messages[:] = list(snapshot.get("messages", []))
    new_model = snapshot.get("model_id")
    if isinstance(new_model, str) and new_model:
        ctx.model_id = new_model
    ctx.session_id = sid
    ctx.printer.print(
        f"[ok] resumed session {sid} — {len(ctx.messages)} messages restored, "
        f"model={ctx.model_id or '(unset)'}.",
    )
    return True


def resume_command() -> SlashCommand:
    """Build the ``/resume`` SlashCommand."""
    return SlashCommand(
        name="resume",
        doc="Resume a saved chat session by id (/resume <session_id>).",
        handler=_resume_handler,
        aliases=("load",),
        category="persistence",
    )


# ─────────────────────────────────────────────────────────────────
# /exit /quit (carry-over from inline chat.py)
# ─────────────────────────────────────────────────────────────────


def _exit_handler(_ctx: SlashContext, _args: str) -> bool:
    """Signal the REPL loop to terminate."""
    return False


def exit_command() -> SlashCommand:
    """Build the ``/exit`` SlashCommand."""
    return SlashCommand(
        name="exit",
        doc="Quit the REPL.",
        handler=_exit_handler,
        category="core",
    )


def quit_command() -> SlashCommand:
    """Build the ``/quit`` SlashCommand (alias-style for /exit).

    Registered as a separate command (not just an alias) so the
    ``/help`` listing shows both names individually — that matches
    user expectation more than burying ``/quit`` in an alias suffix.
    """
    return SlashCommand(
        name="quit",
        doc="Quit the REPL (alias of /exit).",
        handler=_exit_handler,
        category="core",
    )


__all__ = [
    "clear_command",
    "compact_command",
    "exit_command",
    "help_command",
    "model_command",
    "quit_command",
    "resume_command",
    "status_command",
]
