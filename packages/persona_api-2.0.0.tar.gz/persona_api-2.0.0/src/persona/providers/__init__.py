"""Aegis self-contained LLM provider layer.

Public surface:

- :class:`LLMProvider` — Protocol every adapter satisfies.
- :class:`ModelPolicy` — declarative model selection dataclass.
- :class:`ProviderError` — unified failure type.
- :class:`ProviderRegistry` — lookup / instantiate by name.
- Concrete adapters: :class:`AnthropicProvider`,
  :class:`OpenAIProvider`, :class:`OllamaProvider`, :class:`GroqProvider`.

Typical use from the engine:

.. code-block:: python

    registry = ProviderRegistry.default()
    policy = ModelPolicy(provider="anthropic", model="claude-opus-4-6")
    provider = registry.get(policy.provider)
    text = await provider.generate(messages, policy)

The registry is mutation-friendly: tests and callers can
``register`` their own fakes without monkey-patching module globals.
"""

from __future__ import annotations

import os
from typing import Callable

from .anthropic import AnthropicProvider
from .base import (
    LLMProvider,
    ModelPolicy,
    ProviderError,
    ProviderResponse,
    ToolCallRequest,
    ToolSpec,
    UsageStats,
)
from .groq import GroqProvider
from .local_inproc import LocalInProcessProvider
from .ollama import OllamaProvider
from .openai import OpenAIProvider

__all__ = [
    "AnthropicProvider",
    "GroqProvider",
    "LLMProvider",
    "LocalInProcessProvider",
    "ModelPolicy",
    "OllamaProvider",
    "OpenAIProvider",
    "ProviderError",
    "ProviderRegistry",
    "ProviderResponse",
    "ToolCallRequest",
    "ToolSpec",
    "UsageStats",
]

# Factory signature: no-arg callable returning a concrete provider.
ProviderFactory = Callable[[], LLMProvider]


class ProviderRegistry:
    """Name → provider factory map with lazy instantiation + caching.

    Factories are stored so we don't pay construction cost for
    providers that are never used in a given session (e.g. the
    OpenAI provider in a pure local-Gemma deployment). Once a
    provider is resolved the instance is cached.
    """

    def __init__(self) -> None:
        self._factories: dict[str, ProviderFactory] = {}
        self._cache: dict[str, LLMProvider] = {}

    @classmethod
    def default(cls) -> "ProviderRegistry":
        """Registry pre-populated with the built-in providers.

        ``GEMMA_VENDOR=inproc`` env override
        ------------------------------------
        The legacy ``"ollama"`` provider name dispatches to
        :class:`OpenAICompatProvider` which speaks OpenAI-compatible
        HTTP to a sidecar (Ollama :11434 or llama-cpp-server :9000 per
        ``GEMMA_VENDOR``). Setting ``GEMMA_VENDOR=inproc`` flips the
        ``"ollama"`` entry to dispatch to
        :class:`LocalInProcessProvider` instead — zero HTTP, same
        ``provider="ollama"`` ``ModelPolicy`` at call sites, no code
        change needed at the engine / benchmark / api dispatch layer.

        Trade-off: the name "ollama" keeps its registry slot even
        though the effective backend is in-process. Accepted because
        (1) every built-in ``ModelPolicy`` default references that
        name so flipping the env flag is a true one-line ops switch,
        (2) :class:`LocalInProcessProvider` is also registered under
        the explicit ``"local_inproc"`` name for tests and callers
        that want unambiguous dispatch.
        """
        reg = cls()
        reg.register("anthropic", AnthropicProvider)
        reg.register("openai", OpenAIProvider)
        vendor = os.environ.get("GEMMA_VENDOR", "").strip().lower()
        if vendor == "inproc":
            reg.register("ollama", LocalInProcessProvider)
        else:
            reg.register("ollama", OllamaProvider)
        reg.register("local_inproc", LocalInProcessProvider)
        reg.register("groq", GroqProvider)
        return reg

    def register(
        self,
        name: str,
        factory: ProviderFactory,
    ) -> None:
        """Register a factory. Overwrites existing entry of same name."""
        self._factories[name] = factory
        self._cache.pop(name, None)

    def register_instance(
        self,
        name: str,
        instance: LLMProvider,
    ) -> None:
        """Register a pre-built instance. Used by tests to inject fakes."""
        self._factories[name] = lambda inst=instance: inst
        self._cache[name] = instance

    def get(self, name: str) -> LLMProvider:
        """Return the provider bound to ``name``, instantiating on demand."""
        if name in self._cache:
            return self._cache[name]
        if name not in self._factories:
            raise ProviderError(
                "registry", f"unknown provider: {name!r}",
            )
        instance = self._factories[name]()
        self._cache[name] = instance
        return instance

    def known(self) -> list[str]:
        """Return registered provider names, sorted for determinism."""
        return sorted(self._factories.keys())
