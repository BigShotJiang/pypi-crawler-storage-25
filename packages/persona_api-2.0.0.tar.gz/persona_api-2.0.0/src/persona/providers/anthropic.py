"""Anthropic Claude provider with ephemeral prompt caching.

Protocol-compliant adapter that replaced the old
``engine._llm_anthropic`` (removed once the legacy path had no
remaining callers). The SDK import is lazy so environments without
the optional ``[anthropic]`` extra still load this module.
"""

from __future__ import annotations

import os
from collections.abc import AsyncIterator

from typing import Any

from .base import (
    LLMProvider,
    ModelPolicy,
    ProviderError,
    ProviderResponse,
    ToolCallRequest,
    ToolSpec,
    UsageStats,
)


_EPHEMERAL = {"type": "ephemeral"}

# Anthropic extended cache-TTL beta. Required header when any
# ``cache_control`` block carries ``"ttl": "1h"``; omitted for the
# default 5-minute TTL which ships under the stable API surface.
_BETA_HEADER_1H = "extended-cache-ttl-2025-04-11"


def _cache_control(ttl: str | None) -> dict:
    """Build the Anthropic ``cache_control`` block for the requested TTL.

    ``ttl`` is read from ``policy.extra["cache_ttl"]`` upstream.
    - ``None`` or ``"5m"``: legacy default, 5-minute TTL, no beta header
      required. Shape: ``{"type": "ephemeral"}``.
    - ``"1h"``: extended TTL, beta-gated. Shape adds ``"ttl": "1h"``
      and :func:`_needs_extended_ttl_beta` returns True so the caller
      injects ``anthropic-beta`` header.

    ``ValueError`` is raised for unknown values; the caller converts it
    to :class:`ProviderError` at the API boundary.
    """
    if ttl is None or ttl == "5m":
        return dict(_EPHEMERAL)
    if ttl == "1h":
        return {"type": "ephemeral", "ttl": "1h"}
    raise ValueError(
        f"unsupported cache_ttl: {ttl!r} (valid: '5m', '1h')",
    )


def _needs_extended_ttl_beta(policy: ModelPolicy) -> bool:
    """True when the call must carry the 1-hour-TTL beta header."""
    extra = policy.extra or {}
    return extra.get("cache_ttl") == "1h"


def _is_opus_4_7_plus(model_id: str) -> bool:
    """True when ``model_id`` is Claude Opus 4.7 or later.

    Opus 4.7 returns a 400 error if ``temperature`` / ``top_p`` / ``top_k``
    are set to any non-default value. Older Opus (4.6 and below) and all
    Sonnet / Haiku variants still accept them. Callers use this to strip
    sampling kwargs from the request payload.
    """
    if not model_id.startswith("claude-opus-"):
        return False
    rest = model_id.removeprefix("claude-opus-")
    parts = rest.split("-")
    if len(parts) < 2:
        return False
    try:
        major = int(parts[0])
        minor = int(parts[1])
    except ValueError:
        return False
    return (major, minor) >= (4, 7)


def _usage_from_sdk(usage_obj: object) -> UsageStats | None:
    """Best-effort extraction of :class:`UsageStats` from an SDK usage block.

    The Anthropic SDK exposes ``response.usage`` as a pydantic-ish
    object with four attributes we care about. We read each one
    defensively so an SDK minor version that renames or drops a
    field degrades to ``None`` for that field (or the whole struct
    on a hard failure) without raising out into the LLM call path.
    """
    if usage_obj is None:
        return None
    try:
        return UsageStats(
            input_tokens=getattr(usage_obj, "input_tokens", None),
            output_tokens=getattr(usage_obj, "output_tokens", None),
            cache_creation_input_tokens=getattr(
                usage_obj, "cache_creation_input_tokens", None,
            ),
            cache_read_input_tokens=getattr(
                usage_obj, "cache_read_input_tokens", None,
            ),
        )
    except Exception:  # noqa: BLE001 — telemetry is never fatal
        return None


def _wrap_with_cache(message: dict, ttl: str | None = None) -> dict:
    """Return a copy of ``message`` with ``cache_control`` attached.

    ``ttl`` forwards to :func:`_cache_control`; ``None`` keeps legacy
    5-minute behaviour. Works for both plain-string content (wraps
    into a single text block) and list-of-blocks content (attaches
    to the last block so the whole prefix up to that message is
    cached).
    """
    cc = _cache_control(ttl)
    content = message["content"]
    if isinstance(content, str):
        return {
            "role": message["role"],
            "content": [{
                "type": "text",
                "text": content,
                "cache_control": cc,
            }],
        }
    if isinstance(content, list) and content:
        new_blocks = [dict(b) for b in content]
        new_blocks[-1] = {**new_blocks[-1], "cache_control": cc}
        return {"role": message["role"], "content": new_blocks}
    return message


class AnthropicProvider(LLMProvider):
    """Adapter for Anthropic Messages API with prompt caching.

    Cache breakpoint semantics (``policy.cache_breakpoints``):

    - ``None`` (default): cache system block + first user turn.
      Legacy behaviour, 100% backwards-compatible.
    - ``[]`` (empty list): disable caching entirely.
    - ``[i, j, ...]``: cache the system block + the anthropic-message
      indices listed (supports negative indices, duplicates dropped,
      out-of-range raises :class:`ProviderError`). System prompt is
      always cached unless the list is empty.

    Convenience strategies via ``policy.extra["cache_strategy"]``:

    - ``"multiturn"``: system + first user turn + third-from-last
      user turn. Optimises 20-turn conversation cost (multi-turn
      history cache). Only kicks in when there are ≥3 user turns.

    Length guard via ``policy.extra["cache_min_chars"]`` (int):

    - If set and the system prompt is shorter than this many chars,
      all caching is skipped. Avoids paying the 1.25× cache-write
      penalty on system prompts below the Anthropic minimum token
      threshold (≈1024 tokens ≈ 4096 chars for Opus/Sonnet).
      Default ``None`` = no length check (backwards-compatible).
    """

    name = "anthropic"

    def __init__(self, api_key: str | None = None) -> None:
        self._api_key = api_key or os.environ.get("ANTHROPIC_API_KEY", "")
        self.last_usage: UsageStats | None = None
        # Cumulative cache telemetry since provider instantiation.
        # Separate from ``last_usage`` (per-call snapshot) because
        # hit-rate analysis spans many calls. Both are populated by
        # :meth:`_record_usage`; consumers never write these directly.
        self._cache_totals: dict[str, int] = {"creation": 0, "read": 0}
        self._cache_calls: int = 0  # calls with non-None usage

    def _record_usage(self, usage: UsageStats | None) -> None:
        """Update ``last_usage`` and accumulate cache totals.

        Called from every ``generate*`` path so the telemetry contract
        holds regardless of which entry point ran. Defensive: ``None``
        usage leaves everything untouched (no call counted, no division
        risk).
        """
        self.last_usage = usage
        if usage is None:
            return
        self._cache_calls += 1
        self._cache_totals["creation"] += (
            usage.cache_creation_input_tokens or 0
        )
        self._cache_totals["read"] += usage.cache_read_input_tokens or 0

    @property
    def cache_hit_rate(self) -> float | None:
        """Fraction of cached-input-tokens served from cache (not written).

        ``read / (read + creation)`` over the provider's lifetime.
        Returns ``None`` when no cache activity has been observed yet
        so callers can distinguish "no data" from "0% hit rate".

        Note: this is the *cache-layer* hit rate, not the overall
        input-token cache ratio. A denominator of zero means every
        call skipped caching (e.g. length_guard triggered, or the
        system prompt was never cached).
        """
        total = self._cache_totals["creation"] + self._cache_totals["read"]
        if total == 0:
            return None
        return self._cache_totals["read"] / total

    @property
    def cache_totals(self) -> dict[str, int]:
        """Snapshot of cumulative creation/read/call counters.

        Returns a shallow copy so callers cannot mutate provider state
        through the reference. Keys: ``creation`` (tokens written into
        cache, 1.25x cost band), ``read`` (tokens served from cache,
        0.1x cost band), ``calls`` (calls with non-None usage).
        """
        return {
            "creation": self._cache_totals["creation"],
            "read": self._cache_totals["read"],
            "calls": self._cache_calls,
        }

    def _prepare(
        self,
        messages: list[dict[str, str]],
        policy: ModelPolicy,
    ) -> tuple[list[dict], list[dict]]:
        """Split messages into Anthropic ``system`` + ``messages`` blocks.

        Returns ``(system_block, anth_messages)``. Raises
        :class:`ProviderError` when no user turn is present or an
        explicit breakpoint index is out of range. Centralised so
        :meth:`generate` and :meth:`generate_stream` share identical
        cache-breakpoint semantics.
        """
        system_text = ""
        chat: list[dict] = []
        for m in messages:
            role = m.get("role")
            content = m.get("content", "")
            if role == "system":
                system_text = (
                    system_text + "\n\n" + content if system_text else content
                )
            elif role in ("user", "assistant"):
                chat.append({"role": role, "content": content})
        if not chat:
            raise ProviderError(self.name, "no user messages")

        extra = policy.extra or {}
        breakpoints = policy.cache_breakpoints
        strategy = extra.get("cache_strategy")
        min_chars = extra.get("cache_min_chars")
        cache_ttl = extra.get("cache_ttl")  # None/"5m"/"1h"

        # Validate cache_ttl early so a bad value fails the call
        # cleanly instead of surfacing as a 400 from Anthropic.
        try:
            _cache_control(cache_ttl)
        except ValueError as exc:
            raise ProviderError(self.name, str(exc)) from exc

        # Length guard: short prompts can't hit Anthropic's cache
        # minimum, so paying the write penalty is pure loss.
        length_skip = (
            isinstance(min_chars, int)
            and len(system_text) < min_chars
        )

        # Resolve the effective caching mode (precedence: length guard
        # > explicit empty list = disable > explicit list > strategy
        # > legacy None default).
        if length_skip or breakpoints == []:
            mode = "disabled"
        elif breakpoints is not None:
            mode = "explicit"
        elif strategy == "multiturn":
            mode = "multiturn"
        else:
            mode = "legacy"

        system_block: list[dict] = [{
            "type": "text",
            "text": system_text or "You are a helpful assistant.",
        }]
        if mode != "disabled":
            system_block[0]["cache_control"] = _cache_control(cache_ttl)

        anth_messages: list[dict] = [
            {"role": m["role"], "content": m["content"]} for m in chat
        ]
        n = len(anth_messages)
        cache_indices: set[int] = set()

        if mode == "legacy" and n > 1:
            # Cache the first user turn (skip when it's the only turn
            # — single-turn calls don't benefit from write-then-read).
            for i, m in enumerate(anth_messages):
                if m["role"] == "user":
                    cache_indices.add(i)
                    break

        elif mode == "explicit":
            for raw_idx in breakpoints or []:
                real = raw_idx if raw_idx >= 0 else n + raw_idx
                if real < 0 or real >= n:
                    raise ProviderError(
                        self.name,
                        f"cache_breakpoints index out of range: {raw_idx}",
                    )
                cache_indices.add(real)

        elif mode == "multiturn":
            # system + first user + third-from-last user turn.
            user_positions = [
                i for i, m in enumerate(anth_messages) if m["role"] == "user"
            ]
            if len(user_positions) >= 1 and n > 1:
                cache_indices.add(user_positions[0])
            if len(user_positions) >= 3:
                cache_indices.add(user_positions[-3])

        for i in cache_indices:
            anth_messages[i] = _wrap_with_cache(
                anth_messages[i], cache_ttl,
            )

        return system_block, anth_messages

    async def generate(
        self,
        messages: list[dict[str, str]],
        policy: ModelPolicy,
    ) -> str:
        if not self._api_key:
            raise ProviderError(self.name, "ANTHROPIC_API_KEY not set")
        try:
            import anthropic  # noqa: PLC0415
        except ImportError as exc:
            raise ProviderError(
                self.name, f"anthropic SDK missing: {exc}",
            ) from exc

        system_block, anth_messages = self._prepare(messages, policy)

        try:
            client = anthropic.AsyncAnthropic(api_key=self._api_key)
            create_kwargs: dict[str, Any] = {
                "model": policy.model,
                "max_tokens": policy.max_tokens,
                "system": system_block,
                "messages": anth_messages,
            }
            if not _is_opus_4_7_plus(policy.model):
                create_kwargs["temperature"] = policy.temperature
            if _needs_extended_ttl_beta(policy):
                create_kwargs["extra_headers"] = {
                    "anthropic-beta": _BETA_HEADER_1H,
                }
            resp = await client.messages.create(**create_kwargs)
        except Exception as exc:  # noqa: BLE001 — SDK surface
            raise ProviderError(self.name, str(exc)) from exc

        # Telemetry sidechannel: capture usage BEFORE content parsing
        # so an empty-content ProviderError still records the tokens
        # billed. Defensive — never raises out of here.
        try:
            self._record_usage(
                _usage_from_sdk(getattr(resp, "usage", None)),
            )
        except Exception:  # noqa: BLE001 — telemetry is never fatal
            self.last_usage = None

        blocks = getattr(resp, "content", []) or []
        text_parts = [
            getattr(b, "text", "") for b in blocks
            if getattr(b, "type", "") == "text"
        ]
        out = "".join(text_parts).strip()
        if not out:
            raise ProviderError(self.name, "empty content")
        return out

    @staticmethod
    def _map_stop_reason(raw: str | None) -> str:
        """Pass-through; Anthropic vocab is our canonical form."""
        return raw or ""

    def _anth_messages_for_tools(
        self,
        messages: list[dict[str, Any]],
    ) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
        """Translate loop history to Anthropic system + messages.

        Tool-aware variant of :meth:`_prepare` that accepts
        ``role=tool`` turns (emitted by :class:`AgentLoop` after
        :meth:`Tool.execute`) and folds them into an Anthropic
        ``user`` turn carrying a ``tool_result`` content block. Also
        preserves assistant turns that already carry a ``tool_use``
        content block from a prior round.
        """
        system_text = ""
        out: list[dict[str, Any]] = []
        for m in messages:
            role = m.get("role")
            content = m.get("content", "")
            if role == "system":
                system_text = (
                    system_text + "\n\n" + content if system_text else content
                )
                continue
            if role == "tool":
                # Agent loop tool result → Anthropic tool_result block.
                block = {
                    "type": "tool_result",
                    "tool_use_id": m.get("tool_call_id") or "",
                    "content": content if isinstance(content, str)
                    else str(content),
                }
                if m.get("is_error"):
                    block["is_error"] = True
                out.append({"role": "user", "content": [block]})
                continue
            if role == "assistant" and m.get("tool_calls"):
                # Reconstruct an Anthropic tool_use assistant turn.
                blocks: list[dict[str, Any]] = []
                if content:
                    blocks.append({"type": "text", "text": str(content)})
                for tc in m["tool_calls"]:
                    blocks.append({
                        "type": "tool_use",
                        "id": tc.get("id", ""),
                        "name": tc.get("name", ""),
                        "input": tc.get("args") or tc.get("input") or {},
                    })
                out.append({"role": "assistant", "content": blocks})
                continue
            if role in ("user", "assistant"):
                out.append({"role": role, "content": content})
        system_block = [{
            "type": "text",
            "text": system_text or "You are a helpful assistant.",
        }]
        return system_block, out

    async def generate_with_tools(
        self,
        messages: list[dict[str, Any]],
        policy: ModelPolicy,
        tools: list[ToolSpec],
    ) -> ProviderResponse:
        """Anthropic Messages API with native ``tools`` + ``tool_use``.

        Converts :class:`ToolSpec` to Anthropic's
        ``{"name","description","input_schema"}`` shape and parses
        ``content`` blocks back into :class:`ToolCallRequest` entries.
        Text and tool_use can coexist in one response; both land on
        :class:`ProviderResponse`.
        """
        if not self._api_key:
            raise ProviderError(self.name, "ANTHROPIC_API_KEY not set")
        try:
            import anthropic  # noqa: PLC0415
        except ImportError as exc:
            raise ProviderError(
                self.name, f"anthropic SDK missing: {exc}",
            ) from exc

        system_block, anth_messages = self._anth_messages_for_tools(messages)
        anth_tools = [
            {
                "name": t.name,
                "description": t.description,
                "input_schema": t.input_schema,
            }
            for t in tools
        ]

        try:
            client = anthropic.AsyncAnthropic(api_key=self._api_key)
            kwargs: dict[str, Any] = {
                "model": policy.model,
                "max_tokens": policy.max_tokens,
                "system": system_block,
                "messages": anth_messages,
            }
            if not _is_opus_4_7_plus(policy.model):
                kwargs["temperature"] = policy.temperature
            if anth_tools:
                kwargs["tools"] = anth_tools
            if _needs_extended_ttl_beta(policy):
                kwargs["extra_headers"] = {
                    "anthropic-beta": _BETA_HEADER_1H,
                }
            resp = await client.messages.create(**kwargs)
        except Exception as exc:  # noqa: BLE001 — SDK surface
            raise ProviderError(self.name, str(exc)) from exc

        try:
            self._record_usage(
                _usage_from_sdk(getattr(resp, "usage", None)),
            )
        except Exception:  # noqa: BLE001 — telemetry never fatal
            self.last_usage = None

        text_parts: list[str] = []
        tool_calls: list[ToolCallRequest] = []
        for b in getattr(resp, "content", []) or []:
            btype = getattr(b, "type", "")
            if btype == "text":
                text_parts.append(getattr(b, "text", "") or "")
            elif btype == "tool_use":
                tool_calls.append(ToolCallRequest(
                    id=getattr(b, "id", "") or "",
                    name=getattr(b, "name", "") or "",
                    input=dict(getattr(b, "input", {}) or {}),
                ))

        text = "".join(text_parts).strip() or None
        usage_obj = getattr(resp, "usage", None)
        usage_dict: dict[str, Any] = {}
        if usage_obj is not None:
            for key in (
                "input_tokens", "output_tokens",
                "cache_creation_input_tokens", "cache_read_input_tokens",
            ):
                val = getattr(usage_obj, key, None)
                if val is not None:
                    usage_dict[key] = val
        return ProviderResponse(
            text=text,
            tool_calls=tool_calls,
            stop_reason=self._map_stop_reason(
                getattr(resp, "stop_reason", None),
            ),
            usage=usage_dict,
        )

    async def generate_stream(
        self,
        messages: list[dict[str, str]],
        policy: ModelPolicy,
    ) -> AsyncIterator[str]:
        """Stream Anthropic Messages text deltas.

        Uses the official SDK's ``client.messages.stream(...)`` async
        context manager and yields from ``stream.text_stream`` — the
        SDK does the SSE parsing and reconnection for us. We wrap the
        whole iteration in one ``try``: any exception raised before
        the first yield is converted into a
        :class:`ProviderError`; once we start yielding, an upstream
        failure terminates the iterator and the SDK's own exception
        surfaces to the consumer (no partial error prose leaks).
        """
        if not self._api_key:
            raise ProviderError(self.name, "ANTHROPIC_API_KEY not set")
        try:
            import anthropic  # noqa: PLC0415
        except ImportError as exc:
            raise ProviderError(
                self.name, f"anthropic SDK missing: {exc}",
            ) from exc

        system_block, anth_messages = self._prepare(messages, policy)

        client = anthropic.AsyncAnthropic(api_key=self._api_key)
        try:
            stream_kwargs: dict[str, Any] = {
                "model": policy.model,
                "max_tokens": policy.max_tokens,
                "system": system_block,
                "messages": anth_messages,
            }
            if not _is_opus_4_7_plus(policy.model):
                stream_kwargs["temperature"] = policy.temperature
            if _needs_extended_ttl_beta(policy):
                stream_kwargs["extra_headers"] = {
                    "anthropic-beta": _BETA_HEADER_1H,
                }
            stream_cm = client.messages.stream(**stream_kwargs)
        except Exception as exc:  # noqa: BLE001 — defensive
            raise ProviderError(self.name, str(exc)) from exc

        try:
            async with stream_cm as stream:
                async for delta in stream.text_stream:
                    if delta:
                        yield delta
                # Stream drained successfully — now reach for the
                # final message to harvest usage. ``get_final_message``
                # is the canonical SDK API (matches
                # anthropic/_streaming.py:AsyncMessageStream). We
                # wrap the whole extraction in try/except so an SDK
                # minor-version API drift leaves last_usage=None
                # instead of corrupting the success path.
                try:
                    getter = getattr(stream, "get_final_message", None)
                    if callable(getter):
                        final = await getter()
                        self._record_usage(
                            _usage_from_sdk(getattr(final, "usage", None)),
                        )
                    else:
                        # SDK too old for get_final_message — try the
                        # direct attribute some pre-0.40 SDKs exposed.
                        self._record_usage(
                            _usage_from_sdk(
                                getattr(stream, "usage", None),
                            ),
                        )
                except Exception:  # noqa: BLE001 — telemetry never fatal
                    self.last_usage = None
        except ProviderError:
            raise
        except Exception as exc:  # noqa: BLE001 — SDK surface
            raise ProviderError(self.name, str(exc)) from exc
