"""Groq provider (Llama-4 Scout, Kimi-K2, mixtral variants).

Groq's API is OpenAI chat-completions compatible. We keep it as a
separate class (rather than aliasing ``OpenAIProvider``) so registry
lookups and future Groq-specific knobs (rate-limit headers,
``X-Groq-*`` metadata) have a stable home.

Format assumption: standard ``choices[0].message.content`` payload.
Verified against Groq docs 2026-04-14, not hit live in tests.
"""

from __future__ import annotations

import os
from collections.abc import AsyncIterator

import httpx

import json
from typing import Any

from .base import (
    SSE_DONE,
    LLMProvider,
    ModelPolicy,
    ProviderError,
    ProviderResponse,
    ToolCallRequest,
    ToolSpec,
    UsageStats,
    parse_openai_sse_line,
    parse_openai_sse_usage,
)
from .openai import _OAI_STOP_MAP, _openai_messages_with_tools

_DEFAULT_URL = os.environ.get(
    "GROQ_BASE_URL", "https://api.groq.com/openai/v1",
)


class GroqProvider(LLMProvider):
    """Adapter for Groq chat completions."""

    name = "groq"

    def __init__(
        self,
        api_key: str | None = None,
        base_url: str | None = None,
        client: httpx.AsyncClient | None = None,
    ) -> None:
        self._api_key = api_key or os.environ.get("GROQ_API_KEY", "")
        self._base_url = (base_url or _DEFAULT_URL).rstrip("/")
        self._client = client or httpx.AsyncClient(timeout=120)
        self.last_usage: UsageStats | None = None

    async def generate(
        self,
        messages: list[dict[str, str]],
        policy: ModelPolicy,
    ) -> str:
        if not self._api_key:
            raise ProviderError(self.name, "GROQ_API_KEY not set")
        try:
            resp = await self._client.post(
                f"{self._base_url}/chat/completions",
                json={
                    "model": policy.model,
                    "messages": messages,
                    "temperature": policy.temperature,
                    "max_tokens": policy.max_tokens,
                },
                headers={
                    "Authorization": f"Bearer {self._api_key}",
                    "Content-Type": "application/json",
                },
            )
            resp.raise_for_status()
            data = resp.json()
        except httpx.HTTPError as exc:
            raise ProviderError(self.name, f"http: {exc}") from exc
        except ValueError as exc:
            raise ProviderError(self.name, f"bad json: {exc}") from exc
        try:
            content = data["choices"][0]["message"]["content"]
        except (KeyError, IndexError, TypeError) as exc:
            raise ProviderError(self.name, f"parse: {exc}") from exc
        # Capture usage from the OpenAI-compat response envelope.
        try:
            usage = data.get("usage") if isinstance(data, dict) else None
            if isinstance(usage, dict):
                self.last_usage = UsageStats(
                    input_tokens=usage.get("prompt_tokens"),
                    output_tokens=usage.get("completion_tokens"),
                    cache_creation_input_tokens=None,
                    cache_read_input_tokens=None,
                )
            else:
                self.last_usage = None
        except Exception:  # noqa: BLE001 — telemetry never fatal
            self.last_usage = None
        text = (content or "").strip()
        if not text:
            raise ProviderError(self.name, "empty content")
        return text

    async def generate_with_tools(
        self,
        messages: list[dict[str, Any]],
        policy: ModelPolicy,
        tools: list[ToolSpec],
    ) -> ProviderResponse:
        """Groq chat-completions with native tool calling.

        Groq's wire format is OpenAI-identical (verified via their
        `/openai/v1/chat/completions` endpoint docs); the only
        differences vs :class:`OpenAIProvider` are the API key and
        base URL. We reuse the shared message translator and
        finish_reason map.
        """
        if not self._api_key:
            raise ProviderError(self.name, "GROQ_API_KEY not set")
        payload: dict[str, Any] = {
            "model": policy.model,
            "messages": _openai_messages_with_tools(messages),
            "temperature": policy.temperature,
            "max_tokens": policy.max_tokens,
        }
        if tools:
            payload["tools"] = [
                {
                    "type": "function",
                    "function": {
                        "name": t.name,
                        "description": t.description,
                        "parameters": t.input_schema,
                    },
                }
                for t in tools
            ]
        try:
            resp = await self._client.post(
                f"{self._base_url}/chat/completions",
                json=payload,
                headers={
                    "Authorization": f"Bearer {self._api_key}",
                    "Content-Type": "application/json",
                },
            )
            resp.raise_for_status()
            data = resp.json()
        except httpx.HTTPError as exc:
            raise ProviderError(self.name, f"http: {exc}") from exc
        except ValueError as exc:
            raise ProviderError(self.name, f"bad json: {exc}") from exc

        try:
            choice = data["choices"][0]
            msg = choice["message"]
        except (KeyError, IndexError, TypeError) as exc:
            raise ProviderError(self.name, f"parse: {exc}") from exc

        raw_content = msg.get("content")
        text = raw_content.strip() if isinstance(raw_content, str) else None
        if text == "":
            text = None

        tool_calls: list[ToolCallRequest] = []
        for tc in msg.get("tool_calls") or []:
            fn = tc.get("function") or {}
            raw_args = fn.get("arguments", "{}")
            if isinstance(raw_args, str):
                try:
                    parsed = json.loads(raw_args)
                except ValueError:
                    parsed = {"_raw": raw_args}
            else:
                parsed = raw_args or {}
            tool_calls.append(ToolCallRequest(
                id=tc.get("id", ""),
                name=fn.get("name", ""),
                input=parsed if isinstance(parsed, dict) else {"_value": parsed},
            ))

        usage = data.get("usage") if isinstance(data, dict) else None
        if isinstance(usage, dict):
            self.last_usage = UsageStats(
                input_tokens=usage.get("prompt_tokens"),
                output_tokens=usage.get("completion_tokens"),
                cache_creation_input_tokens=None,
                cache_read_input_tokens=None,
            )
        else:
            self.last_usage = None

        raw_stop = choice.get("finish_reason") or ""
        return ProviderResponse(
            text=text,
            tool_calls=tool_calls,
            stop_reason=_OAI_STOP_MAP.get(raw_stop, raw_stop),
            usage=dict(usage) if isinstance(usage, dict) else {},
        )

    async def generate_stream(
        self,
        messages: list[dict[str, str]],
        policy: ModelPolicy,
    ) -> AsyncIterator[str]:
        """Stream Groq chat-completions deltas as plain chunks.

        Groq's streaming wire format is OpenAI-identical, so we
        reuse :func:`parse_openai_sse_line`. Only the
        ``GROQ_API_KEY`` requirement and default ``base_url``
        differ from :class:`~persona.providers.openai.OpenAIProvider`.
        """
        if not self._api_key:
            raise ProviderError(self.name, "GROQ_API_KEY not set")
        payload: dict[str, object] = {
            "model": policy.model,
            "messages": messages,
            "temperature": policy.temperature,
            "max_tokens": policy.max_tokens,
            "stream": True,
            # Groq natively supports the OpenAI ``stream_options``
            # extension; include_usage=True gives us a final frame
            # with token counts for ``last_usage``.
            "stream_options": {"include_usage": True},
        }
        # Reset telemetry; populated on the final usage frame.
        self.last_usage = None
        try:
            async with self._client.stream(
                "POST",
                f"{self._base_url}/chat/completions",
                json=payload,
                headers={
                    "Authorization": f"Bearer {self._api_key}",
                    "Content-Type": "application/json",
                },
            ) as resp:
                resp.raise_for_status()
                async for line in resp.aiter_lines():
                    try:
                        maybe_usage = parse_openai_sse_usage(line)
                        if maybe_usage is not None:
                            self.last_usage = maybe_usage
                    except Exception:  # noqa: BLE001 — never fatal
                        pass
                    chunk = parse_openai_sse_line(line)
                    if chunk is None:
                        continue
                    if chunk == SSE_DONE:
                        return
                    if chunk:
                        yield chunk
        except httpx.HTTPError as exc:
            raise ProviderError(self.name, f"http: {exc}") from exc
