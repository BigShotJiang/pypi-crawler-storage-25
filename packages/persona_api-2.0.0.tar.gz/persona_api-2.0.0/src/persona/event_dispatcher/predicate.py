"""persona.event_dispatcher.predicate — Safe AST walker for ``when`` strings.

@module event_dispatcher.predicate
@responsibility Evaluate the optional ``when`` predicate on a binding
    against a hook payload without ever running ``eval`` / ``exec``.
    Only a tight subset of Python expression nodes is permitted; anything
    else raises :class:`PredicateError`.
@dependencies stdlib ``ast`` only
@exports PredicateError, evaluate
"""

from __future__ import annotations

import ast

# Hard cap on AST node count. Prevents DoS via pathologically huge
# predicates smuggled into SKILL.md. Any well-formed real-world
# predicate stays well under this bound (the spec's example is ~7 nodes).
_MAX_AST_NODES = 256


class PredicateError(Exception):
    """Raised when a ``when`` string cannot be safely evaluated.

    Caller (the dispatcher) converts this into an ``OutcomeRecord`` with
    ``outcome="predicate_error"`` — never propagates to the host hook.
    """


# Allowlisted comparison / boolean / unary operator node classes.
_CMP_OPS: tuple[type, ...] = (
    ast.Eq,
    ast.NotEq,
    ast.Lt,
    ast.LtE,
    ast.Gt,
    ast.GtE,
    ast.In,
    ast.NotIn,
)
_BOOL_OPS: tuple[type, ...] = (ast.And, ast.Or)
_UNARY_OPS: tuple[type, ...] = (ast.Not,)


def _count_nodes(tree: ast.AST) -> int:
    return sum(1 for _ in ast.walk(tree))


def _resolve(node: ast.AST, payload: dict, read_keys: set[str]) -> object:
    """Walk an allowlisted AST subtree and return its value.

    ``read_keys`` is mutated in place: every payload key actually touched
    during evaluation gets added, so the caller can populate
    :attr:`OutcomeRecord.payload_keys` without exposing the values.
    """
    if isinstance(node, ast.Expression):
        return _resolve(node.body, payload, read_keys)

    if isinstance(node, ast.Constant):
        return node.value

    if isinstance(node, ast.Name):
        if node.id not in payload:
            # Missing keys resolve to None — predicates that reference
            # them typically return False under comparison, and the
            # dispatcher treats "predicate evaluated False" as a skip,
            # not a crash. The name is still recorded as "read".
            read_keys.add(node.id)
            return None
        read_keys.add(node.id)
        return payload[node.id]

    if isinstance(node, ast.Attribute):
        # Read-only attribute access. Writes (ast.Store ctx) are rejected
        # by the validator pass so we never see them here.
        obj = _resolve(node.value, payload, read_keys)
        return getattr(obj, node.attr, None)

    if isinstance(node, ast.Subscript):
        # Only literal constant indices are allowed.
        if not isinstance(node.slice, ast.Constant):
            raise PredicateError("subscript index must be a literal")
        container = _resolve(node.value, payload, read_keys)
        if container is None:
            return None
        try:
            return container[node.slice.value]
        except (KeyError, IndexError, TypeError):
            return None

    if isinstance(node, ast.UnaryOp):
        if not isinstance(node.op, _UNARY_OPS):
            raise PredicateError(f"unary op not allowed: {type(node.op).__name__}")
        return not _resolve(node.operand, payload, read_keys)

    if isinstance(node, ast.BoolOp):
        if not isinstance(node.op, _BOOL_OPS):
            raise PredicateError(f"bool op not allowed: {type(node.op).__name__}")
        values = [_resolve(v, payload, read_keys) for v in node.values]
        if isinstance(node.op, ast.And):
            result: object = True
            for v in values:
                if not v:
                    return v
                result = v
            return result
        # ast.Or
        result = False
        for v in values:
            if v:
                return v
            result = v
        return result

    if isinstance(node, ast.BinOp):
        # Only string concatenation via ``+`` is allowed. Any other
        # arithmetic would pull in type coercion surprises without
        # adding predicate expressiveness.
        if not isinstance(node.op, ast.Add):
            raise PredicateError(f"binop not allowed: {type(node.op).__name__}")
        left = _resolve(node.left, payload, read_keys)
        right = _resolve(node.right, payload, read_keys)
        if isinstance(left, str) and isinstance(right, str):
            return left + right
        raise PredicateError("BinOp Add only supported for str + str")

    if isinstance(node, ast.Compare):
        left = _resolve(node.left, payload, read_keys)
        for op, comparator in zip(node.ops, node.comparators):
            right = _resolve(comparator, payload, read_keys)
            if not isinstance(op, _CMP_OPS):
                raise PredicateError(
                    f"compare op not allowed: {type(op).__name__}",
                )
            try:
                ok = _apply_cmp(op, left, right)
            except TypeError:
                # ``"foo" < None`` etc. Swallow to False rather than
                # blow up the whole predicate — one payload shape hiccup
                # should not disable the binding forever.
                return False
            if not ok:
                return False
            left = right
        return True

    raise PredicateError(f"node not allowed: {type(node).__name__}")


def _apply_cmp(op: ast.cmpop, left: object, right: object) -> bool:
    if isinstance(op, ast.Eq):
        return left == right
    if isinstance(op, ast.NotEq):
        return left != right
    if isinstance(op, ast.Lt):
        return left < right  # type: ignore[operator]
    if isinstance(op, ast.LtE):
        return left <= right  # type: ignore[operator]
    if isinstance(op, ast.Gt):
        return left > right  # type: ignore[operator]
    if isinstance(op, ast.GtE):
        return left >= right  # type: ignore[operator]
    if isinstance(op, ast.In):
        if right is None:
            return False
        return left in right  # type: ignore[operator]
    if isinstance(op, ast.NotIn):
        if right is None:
            return True
        return left not in right  # type: ignore[operator]
    raise PredicateError(f"compare op not allowed: {type(op).__name__}")


# Allowlisted statement/expression node types. The validator pass rejects
# anything not in this set before we hand the tree to ``_resolve``, so
# even a bug in _resolve can't smuggle a disallowed node past this gate.
_ALLOWED_NODES: tuple[type, ...] = (
    ast.Expression,
    ast.Name,
    ast.Attribute,
    ast.Constant,
    ast.Compare,
    ast.BoolOp,
    ast.UnaryOp,
    ast.Subscript,
    ast.BinOp,
    ast.Load,
    ast.And,
    ast.Or,
    ast.Not,
    ast.Eq,
    ast.NotEq,
    ast.Lt,
    ast.LtE,
    ast.Gt,
    ast.GtE,
    ast.In,
    ast.NotIn,
    ast.Add,
)


def _validate(tree: ast.AST) -> None:
    for node in ast.walk(tree):
        if isinstance(node, _ALLOWED_NODES):
            continue
        raise PredicateError(f"node not allowed: {type(node).__name__}")


def evaluate(
    when: str,
    payload: dict,
    *,
    read_keys: set[str] | None = None,
) -> bool:
    """Return the boolean result of *when* against *payload*.

    Args:
        when: The predicate source (raw string from ``EventBinding.when``).
        payload: The hook payload dict. Only string keys are resolved as
            names; nested containers reached via subscript are accessed
            with literal indices only.
        read_keys: Optional set the caller passes in to capture the names
            of payload keys actually read during evaluation. Useful for
            :attr:`OutcomeRecord.payload_keys`. Mutated in place.

    Raises:
        PredicateError: on any disallowed node, AST size cap breach, or
            syntax failure. The dispatcher converts this to an
            ``OutcomeRecord`` with ``outcome="predicate_error"``.
    """
    if not isinstance(when, str):
        raise PredicateError("when must be a string")
    try:
        tree = ast.parse(when, mode="eval")
    except SyntaxError as exc:
        raise PredicateError(f"syntax error: {exc.msg}") from exc
    if _count_nodes(tree) > _MAX_AST_NODES:
        raise PredicateError("AST too large")
    _validate(tree)
    if read_keys is None:
        read_keys = set()
    result = _resolve(tree, payload, read_keys)
    return bool(result)
