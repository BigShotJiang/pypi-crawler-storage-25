"""persona.event_dispatcher.outcome — OutcomeRecord + per-session storage.

@module event_dispatcher.outcome
@responsibility Dataclass for one dispatch outcome and an
    :class:`OutcomeStore` helper that appends / reads records via
    :class:`concinno.core.state_store.StateStore` under the
    ``event_dispatch`` namespace. Privacy invariant: only payload *key
    names* are ever persisted; the values are never written.
@dependencies concinno.core.state_store
@exports OutcomeRecord, OutcomeStore, OUTCOME_LITERALS
"""

from __future__ import annotations

import time
from dataclasses import asdict, dataclass, field
from typing import Literal

from concinno.core.state_store import StateStore

_NS = "event_dispatch"
_KEY = "records"

# Fixed outcome vocabulary — matches spec §3.3 exactly. Extending
# requires a concinno schema bump because Cigito training export
# serialises these literals into downstream storage.
OUTCOME_LITERALS = (
    "ok",
    "error",
    "skipped",
    "throttled",
    "predicate_error",
    "skill_not_found",
)

OutcomeLiteral = Literal[
    "ok",
    "error",
    "skipped",
    "throttled",
    "predicate_error",
    "skill_not_found",
]

# Cap ``error_summary`` to one-line-ish. 200 chars is enough for most
# Python exception repr()s without letting a runaway traceback blow the
# per-session state file.
_ERROR_SUMMARY_MAX = 200


@dataclass
class OutcomeRecord:
    """One dispatch outcome — audit row + future Cigito training row.

    Fields are documented in ``docs/event-dispatcher-spec.md`` §3.3.
    """

    binding_id: str
    skill_name: str
    event: str
    invoke: str
    fired_at: float
    outcome: OutcomeLiteral
    latency_ms: float = 0.0
    error_summary: str = ""
    payload_keys: list[str] = field(default_factory=list)

    def __post_init__(self) -> None:
        if len(self.error_summary) > _ERROR_SUMMARY_MAX:
            self.error_summary = self.error_summary[:_ERROR_SUMMARY_MAX]
        # Defensive: newlines in a "single line" summary break downstream
        # grep tooling. Collapse to spaces.
        if "\n" in self.error_summary or "\r" in self.error_summary:
            self.error_summary = (
                self.error_summary.replace("\r", " ").replace("\n", " ")
            )

    def to_dict(self) -> dict:
        return asdict(self)

    @classmethod
    def from_dict(cls, d: dict) -> OutcomeRecord:
        outcome = d.get("outcome", "error")
        if outcome not in OUTCOME_LITERALS:
            outcome = "error"
        return cls(
            binding_id=d.get("binding_id", ""),
            skill_name=d.get("skill_name", ""),
            event=d.get("event", ""),
            invoke=d.get("invoke", ""),
            fired_at=float(d.get("fired_at", 0.0)),
            outcome=outcome,  # type: ignore[arg-type]
            latency_ms=float(d.get("latency_ms", 0.0)),
            error_summary=d.get("error_summary", ""),
            payload_keys=list(d.get("payload_keys", [])),
        )


class OutcomeStore:
    """Append-only per-session persistence of :class:`OutcomeRecord`.

    Uses :class:`StateStore` read-modify-write with a file lock so
    concurrent fires within the same session do not lose records.
    """

    def __init__(self, *, cache_dir: str, session_id: str) -> None:
        self._store = StateStore(cache_dir)
        self._session_id = session_id

    def append(self, record: OutcomeRecord) -> None:
        def _apply(state: dict) -> dict:
            items = state.setdefault(_KEY, [])
            items.append(record.to_dict())
            return state

        self._store.read_modify_write(
            _NS, self._session_id, _apply, default={},
        )

    def read_all(self) -> list[OutcomeRecord]:
        state = self._store.read(_NS, self._session_id, default={})
        raw = state.get(_KEY, [])
        if not isinstance(raw, list):
            return []
        out: list[OutcomeRecord] = []
        for item in raw:
            if isinstance(item, dict):
                out.append(OutcomeRecord.from_dict(item))
        return out

    def filter(
        self,
        *,
        binding_id: str | None = None,
        since: float | None = None,
    ) -> list[OutcomeRecord]:
        records = self.read_all()
        if binding_id is not None:
            records = [r for r in records if r.binding_id == binding_id]
        if since is not None:
            records = [r for r in records if r.fired_at >= since]
        return records


def now_epoch() -> float:
    """Wall-clock seconds for ``OutcomeRecord.fired_at``."""
    return time.time()
