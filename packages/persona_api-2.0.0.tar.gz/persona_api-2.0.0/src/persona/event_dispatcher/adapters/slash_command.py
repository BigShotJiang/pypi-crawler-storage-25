"""persona.event_dispatcher.adapters.slash_command — Slash command stub.

@module event_dispatcher.adapters.slash_command
@responsibility Return a stub callable for ``invoke`` strings starting
    with ``/``. Until the Sancio runtime exposes a slash-command registry,
    the callable records :data:`RESOLVER_NOT_FOUND` so the dispatcher
    emits an ``OutcomeRecord`` with ``outcome="skill_not_found"``.
@dependencies (none)
@exports slash_command_resolver

TODO (Sancio 0.6.x K-extension): wire this to the real slash-command
registry. At that point the callable should import ``persona.runtime``
lazily, look up the command, and invoke it; it must still return an
integer exit code (0 = ok) per the :data:`InvokeCallable` contract.
"""

from __future__ import annotations

from typing import Callable

# Mirror of the sentinel exported from ``adapters/__init__``. Redefined
# locally to avoid an import cycle (adapters/__init__ imports from here).
_RESOLVER_NOT_FOUND = -1


def slash_command_resolver(invoke: str) -> Callable[[dict], int]:
    """Return a stub callable for a slash-command ``invoke`` string."""

    def _stub(_payload: dict) -> int:  # noqa: ARG001 — stub signature
        return _RESOLVER_NOT_FOUND

    _stub.__name__ = f"slash_command_stub::{invoke}"
    return _stub
