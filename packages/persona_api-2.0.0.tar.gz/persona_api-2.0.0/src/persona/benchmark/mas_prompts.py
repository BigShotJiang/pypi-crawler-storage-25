"""GAIA-flavored prompts for the solver → critic → judge MAS stack.

These override the generic defaults in :mod:`concinno.agent.mas_prompts`
with benchmark-specific wording:

* FINAL ANSWER sentinel so
  :func:`concinno.agent.extract_sentinel_answer` can scrape the value
  the GAIA scorer uses (``normalize_answer`` in
  ``benchmarks/gaia_sancio_runner.py``).
* Positive framing per MEMORY #5 / #89 — never describe refusal or
  "solver failed" in the fallback, otherwise Gemma echoes the phrase
  as its own final answer and the cascade still produces nulls.
* Explicit "commit to one value" anchor so critic/judge don't hedge.

The concinno orchestrator renders these via ``str.format_map`` with
slots ``{question}`` / ``{solver_answer}`` / ``{solver_trace_summary}``
/ ``{response_1}`` / ``{response_2}``. Slot contract mirrors
:mod:`concinno.agent.mas_prompts` so the orchestrator can swap this
override in without tracking two shapes.

@module persona.benchmark.mas_prompts
@dependencies stdlib only
@exports GAIA_CRITIC_PROMPT, GAIA_CRITIC_FALLBACK_PROMPT,
    GAIA_JUDGE_PROMPT
"""

from __future__ import annotations


GAIA_CRITIC_PROMPT = (
    "You are the critic in a 3-role adversarial GAIA agent stack. "
    "A solver already produced an answer using web_search / tools. "
    "Consider the question and the solver's top tool results, then "
    "commit to your own single concrete answer — which may agree "
    "with or diverge from the solver's.\n\n"
    "Question:\n{question}\n\n"
    "Solver's final answer:\n{solver_answer}\n\n"
    "Solver's top-3 tool results (summarised):\n"
    "{solver_trace_summary}\n\n"
    "Output exactly one concrete answer on its own line. Do not "
    "hedge or apologise. Do not repeat the solver if you would "
    "answer differently — the whole point of your role is to surface "
    "an independent candidate.\n"
    "FINAL ANSWER: <value>"
)


GAIA_CRITIC_FALLBACK_PROMPT = (
    "Based on the question alone, what is your best-effort single "
    "concrete answer?\n\n"
    "Question:\n{question}\n\n"
    "Commit to exactly one value — a number, a name, a short "
    "phrase, or a date. A best guess beats an empty response. The "
    "value must be concise: never include units unless the question "
    "asks, never convert or round numbers, use source precision "
    "exactly.\n"
    "FINAL ANSWER: <value>"
)


GAIA_JUDGE_PROMPT = (
    "You are the judge in a 3-role adversarial GAIA agent stack. "
    "Two candidate answers are shown below in randomised order — "
    "the ordering carries no signal. Pick the one you assess as "
    "correct for the GAIA grader, which matches strings after "
    "normalisation and compares numbers with tight tolerance.\n\n"
    "Question:\n{question}\n\n"
    "Response 1:\n{response_1}\n\n"
    "Response 2:\n{response_2}\n\n"
    "Output your chosen value on the final line. If both are "
    "plausible, pick the one with the more verifiable chain of "
    "reasoning. The value must be concise — a number, a name, a "
    "short phrase — and never include units unless asked.\n"
    "FINAL ANSWER: <value>"
)


__all__ = [
    "GAIA_CRITIC_FALLBACK_PROMPT",
    "GAIA_CRITIC_PROMPT",
    "GAIA_JUDGE_PROMPT",
]
