"""Benchmark track router — keyword-based dispatch to (persona, format) handler.

Given a raw user message, `detect_track` scores a set of conservative keyword
patterns and returns the highest-scoring track name (or None). `get_handler`
returns a cached BenchmarkAdapter subclass instance bound to that track's
persona and format.

Patterns are deliberately conservative to avoid false positives on
adversarial safety prompts that may mention a keyword from a different
track (e.g. a jailbreak mentioning "revenue"). Ties are broken by Python's
`max` stability over the insertion-ordered dict.
"""
from __future__ import annotations

import re
from typing import TYPE_CHECKING, Optional

if TYPE_CHECKING:
    from .base import BenchmarkAdapter


# ---- Track keyword patterns (lowercase, conservative) ----
TRACK_PATTERNS: dict[str, re.Pattern[str]] = {
    "finance": re.compile(
        r"\b(?:revenue|earnings|ebitda|q[1-4]|fiscal\s+year|treasury|"
        r"bulletin|profit\s+margin|roi|cagr|net\s+income)\b",
        re.IGNORECASE,
    ),
    "safety": re.compile(
        r"\b(?:jailbreak|harmful|unsafe|refuse|guardrail|alignment|"
        r"prompt\s+injection|red\s+team|naamse)\b",
        re.IGNORECASE,
    ),
    "code": re.compile(
        r"\b(?:patch|diff|pull\s+request|github\s+issue|fix\s+this\s+bug|"
        r"refactor|implement|swe-bench|unit\s+test)\b",
        re.IGNORECASE,
    ),
    "tool": re.compile(
        r"\b(?:tau2|tau-bench|tool\s+call|function\s+call|"
        r"api\s+invocation|book\s+a\s+flight|reserve\s+a)\b",
        re.IGNORECASE,
    ),
    "research": re.compile(
        r"\b(?:gaia|deep\s+research|literature\s+review|find\s+the\s+paper|"
        r"cite\s+the\s+source|investigate)\b",
        re.IGNORECASE,
    ),
    "web": re.compile(
        r"\b(?:webarena|navigate\s+to|click\s+the|fill\s+in\s+the\s+form|"
        r"browse\s+to|web\s+automation|dom\s+element)\b",
        re.IGNORECASE,
    ),
    "multi": re.compile(
        r"\b(?:multi-agent|swarm|consensus|coordination|delegate\s+to|"
        r"sub-agent|agent\s+trace)\b",
        re.IGNORECASE,
    ),
    "game": re.compile(
        r"\b(?:game\s+state|legal\s+move|opponent|win\s+condition|"
        r"chess\s+position|go\s+board|poker\s+hand)\b",
        re.IGNORECASE,
    ),
    "bizops": re.compile(
        r"\b(?:kpi|business\s+operation|process\s+improvement|"
        r"cost\s+reduction|stakeholder|quarterly\s+review)\b",
        re.IGNORECASE,
    ),
    "openenv": re.compile(
        r"\b(?:open\s+environment|sandbox\s+exploration|goal-locked|"
        r"episodic\s+task|openenv)\b",
        re.IGNORECASE,
    ),
    "general": re.compile(
        r"\b(?:integrate|architect|cross-domain|end-to-end|"
        r"whole\s+system|perfectionist)\b",
        re.IGNORECASE,
    ),
}


# ---- Track -> (persona, format) mapping ----
TRACK_TO_HANDLER: dict[str, tuple[str, str]] = {
    "finance":  ("finance_analyst", "numeric"),
    "safety":   ("safety_researcher", "structured_json"),
    "code":     ("software_engineer", "code_block"),
    "tool":     ("tool_precise_agent", "tool_call"),
    "research": ("deep_researcher", "free_strict"),
    "web":      ("web_navigator", "tool_call"),
    "multi":    ("multi_agent_judge", "structured_json"),
    "game":     ("game_strategist", "tool_call"),
    "bizops":   ("bizops_analyst", "free_strict"),
    "openenv":  ("openenv_explorer", "tool_call"),
    "general":  ("perfectionist_creator", "free_strict"),
}


def detect_track(message: str) -> Optional[str]:
    """Return the highest-scoring track name, or None if no pattern matches.

    Scoring is the count of regex matches per track. Ties are broken by
    insertion order in TRACK_PATTERNS (dict stability). No match returns
    None so callers can fall back to the default persona engine path.
    """
    if not message:
        return None
    scores: dict[str, int] = {}
    for track, pattern in TRACK_PATTERNS.items():
        hits = len(pattern.findall(message))
        if hits > 0:
            scores[track] = hits
    if not scores:
        return None
    return max(scores, key=lambda k: scores[k])


def detect_benchmark_format(message: str) -> Optional[tuple[str, str]]:
    """Return (persona_name, format_name) for the matched track, or None."""
    track = detect_track(message)
    if track is None:
        return None
    return TRACK_TO_HANDLER.get(track)


# ---- Handler cache (one adapter instance per track) ----
_HANDLER_CACHE: dict[str, "BenchmarkAdapter"] = {}


def get_handler(persona_name: str, format_name: str) -> "BenchmarkAdapter":
    """Return a cached BenchmarkAdapter instance for the given pair.

    Uses `type()` (not a nested class) to avoid the Python class-body
    scope trap where `persona_name = persona_name` would read the class
    attribute, not the enclosing argument.
    """
    from .base import BenchmarkAdapter

    key = f"{persona_name}:{format_name}"
    if key in _HANDLER_CACHE:
        return _HANDLER_CACHE[key]

    # Capture arguments in closures so `detect` sees the right values.
    _persona = persona_name
    _format = format_name

    def _detect(self: "BenchmarkAdapter", msg: str) -> bool:
        return detect_benchmark_format(msg) == (_persona, _format)

    cls = type(
        f"Adapter_{persona_name}_{format_name}",
        (BenchmarkAdapter,),
        {
            "persona_name": persona_name,
            "format_name": format_name,
            "detect": _detect,
        },
    )
    instance = cls()
    _HANDLER_CACHE[key] = instance
    return instance
