"""Persona x format -> system prompt assembly.

The system prompt for any track is composed from two markdown files
that live in concinno as the single source of truth:

    concinno/templates/skills/persona-<persona-name>/SKILL.md
    concinno/templates/skills/output-<format-name>/SKILL.md

Each SKILL.md wraps the prompt body in a YAML frontmatter block; this
module strips the frontmatter and concatenates the two bodies with a
horizontal rule so the model sees a clear boundary between identity
and output contract.

Migration M2 (2026-04-14): personas/ and formats/ markdown files were
deleted from this package. concinno.templates.skills is the SSoT.
"""
from __future__ import annotations

from functools import lru_cache
from importlib.resources import files

_TEMPLATES_PKG = "concinno.templates.skills"


def _strip_frontmatter(text: str) -> str:
    """Remove a leading YAML frontmatter block (between --- markers)."""
    lines = text.splitlines()
    if not lines or lines[0].strip() != "---":
        return text.strip()
    for idx in range(1, len(lines)):
        if lines[idx].strip() == "---":
            return "\n".join(lines[idx + 1:]).strip()
    return text.strip()


def _read_skill_body(skill_dir: str) -> str:
    """Read SKILL.md from concinno.templates.skills.<skill_dir>, strip frontmatter."""
    try:
        path = files(_TEMPLATES_PKG) / skill_dir / "SKILL.md"
        raw = path.read_text(encoding="utf-8")
    except (FileNotFoundError, ModuleNotFoundError) as exc:
        raise FileNotFoundError(
            f"Skill template not found: {_TEMPLATES_PKG}/{skill_dir}/SKILL.md. "
            f"Ensure concinno >= 1.17 is installed.",
        ) from exc
    return _strip_frontmatter(raw)


@lru_cache(maxsize=128)
def _load_persona(persona_name: str) -> str:
    skill_dir = f"persona-{persona_name.replace('_', '-')}"
    return _read_skill_body(skill_dir)


@lru_cache(maxsize=128)
def _load_format(format_name: str) -> str:
    skill_dir = f"output-{format_name.replace('_', '-')}"
    return _read_skill_body(skill_dir)


def build_system_prompt(persona_name: str, format_name: str) -> str:
    """Load persona + format markdown and combine into a single system prompt.

    Structure:

        <persona body>

        ---

        <format body>

    Total length should stay <=40 lines (25 persona + ~15 format) so that
    the U-shaped attention profile (Liu 2023 Lost in the Middle) keeps
    the head (identity) and tail (format contract) in high-attention zones.
    """
    persona = _load_persona(persona_name)
    fmt = _load_format(format_name)
    return f"{persona}\n\n---\n\n{fmt}"
