"""BenchmarkAdapter base class — uniform interface for all track handlers.

A BenchmarkAdapter binds a persona markdown (the "who") to a format markdown
(the "how to answer") and provides a single entry point `handle()` that the
persona engine can dispatch to once `detect()` returns True.

Subclasses are generated dynamically by `router.get_handler` so new tracks
can be added simply by dropping a persona/format pair into the mapping.
"""
from __future__ import annotations

from abc import ABC, abstractmethod
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from ..engine import PersonaEngine


class BenchmarkAdapter(ABC):
    """Abstract adapter: (persona_name, format_name) -> system prompt + handler."""

    persona_name: str = ""
    format_name: str = ""

    @abstractmethod
    def detect(self, message: str) -> bool:
        """Return True if message matches this adapter's track."""

    async def handle(self, engine: "PersonaEngine", message: str) -> str:
        """Build prompt + call LLM + extract answer.

        All LLM calls go through the provider layer (Ollama + Gemma
        default) so the same RunPod backend + timeout + error handling
        apply uniformly. ``ProviderError`` is caught and rendered as a
        string so the benchmark harness's "never raises" contract is
        preserved — subclasses downstream simply see a string that
        starts with ``[benchmark provider error]`` on failure.
        """
        from ..engine import _GEMMA_MODEL  # noqa: PLC0415
        from ..providers import ModelPolicy, ProviderError  # noqa: PLC0415
        from .handlers import build_system_prompt

        system = build_system_prompt(self.persona_name, self.format_name)
        messages = [
            {"role": "system", "content": system},
            {"role": "user", "content": message},
        ]
        policy = ModelPolicy(
            provider="ollama",
            model=_GEMMA_MODEL,
            max_tokens=512,
            temperature=0.0,
        )
        try:
            raw = await engine._llm_via_provider(  # noqa: SLF001
                policy, messages,
            )
        except ProviderError as exc:
            raw = f"[benchmark provider error] {exc.provider}: {exc.detail}"
        return self.extract(raw)

    def extract(self, raw: str) -> str:
        """Default extraction: strip surrounding whitespace.

        Override for format-specific extraction (e.g. JSON parsing,
        code-block unwrapping). Kept intentionally simple so that
        non-overriding adapters still benefit from the persona contract.
        """
        return raw.strip()
