"""Benchmark adapter system: persona x format axes for competition tracks.

Usage:

    from persona.benchmark import detect_benchmark_format, get_handler

    pair = detect_benchmark_format(user_message)
    if pair is not None:
        adapter = get_handler(*pair)
        answer = await adapter.handle(engine, user_message)
"""
from .base import BenchmarkAdapter
from .handlers import build_system_prompt
from .router import (
    TRACK_PATTERNS,
    TRACK_TO_HANDLER,
    detect_benchmark_format,
    detect_track,
    get_handler,
)

__all__ = [
    "BenchmarkAdapter",
    "TRACK_PATTERNS",
    "TRACK_TO_HANDLER",
    "build_system_prompt",
    "detect_benchmark_format",
    "detect_track",
    "get_handler",
]
