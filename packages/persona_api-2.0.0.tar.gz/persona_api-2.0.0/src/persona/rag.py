"""Aegis persona RAG — thin adapter over concinno.rag.RAGIndex.

M1 migration (2026-04-15): the 418-line duplicate implementation
(custom RRF + BM25 + FTRL + chunker) was replaced with a wrapper that
delegates retrieval to concinno RAGIndex. The only Aegis-specific
logic retained is ``_classify_source``, which tags results into 4
buckets (persona_data / memory / knowledge / emotion) so that FTRL
weight diversity does not collapse — see Aegis master decision doc
§3 anti-pattern #7 ("if you drop the shim, .aegis_memory/ falls
into a single bucket and weight diversity dies").

CCC's ZIQRetrieval uses a different 5-bucket taxonomy
(correction/rule/skill/handoff/memory) and its ``_classify_source``
is hardwired, so we cannot reuse it directly. Instead we keep a
tiny persistent EMA state for the 4 Aegis buckets and apply it as a
multiplier on RAGIndex scores.

Public API preserved (only shape consumed by engine.py):
  - ``PersonaRAG(cache_dir=...)`` constructor
  - ``.search(query, top_k) -> list[dict]`` where each dict has key ``text``
"""

from __future__ import annotations

import json
import os
from pathlib import Path

from concinno.rag import RAGIndex

# ── Aegis-specific source classification (NOT in CCC) ────────

SOURCE_TYPES = (
    "persona_data",  # character identity, OCEAN profile, narrative
    "memory",        # .aegis_memory/, conversation history, transcripts
    "knowledge",     # domain facts, external references
    "emotion",       # mood, affect, feeling state
)


def _classify_source(file_path: str) -> str:
    """Classify a file path into one of 4 Aegis source buckets.

    Buckets kept identical to pre-M1 semantics so FTRL weight
    diversity survives the migration.
    """
    fp = file_path.lower().replace("\\", "/")
    if "persona" in fp or "identity" in fp or "ocean" in fp:
        return "persona_data"
    if "memory" in fp or "transcript" in fp or "history" in fp:
        return "memory"
    if "emotion" in fp or "mood" in fp or "feeling" in fp:
        return "emotion"
    return "knowledge"


# ── Tiny 4-bucket EMA weight store (Aegis-local, not CCC) ────

_LR = 0.15
_WEIGHT_MIN = 0.1
_WEIGHT_MAX = 5.0


def _load_weights(path: Path) -> dict[str, float]:
    if not path.exists():
        return {st: 1.0 for st in SOURCE_TYPES}
    try:
        raw = json.loads(path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return {st: 1.0 for st in SOURCE_TYPES}
    return {st: float(raw.get(st, 1.0)) for st in SOURCE_TYPES}


def _save_weights(path: Path, weights: dict[str, float]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(weights, indent=2), encoding="utf-8",
    )


def _ema_update(weight: float, reward: float) -> float:
    target = weight * (1.0 + reward)
    new = (1.0 - _LR) * weight + _LR * target
    return max(_WEIGHT_MIN, min(_WEIGHT_MAX, new))


# ── Main wrapper ─────────────────────────────────────────────


class PersonaRAG:
    """Thin wrapper over concinno RAGIndex with Aegis 4-bucket FTRL.

    engine.py calls::

        rag = PersonaRAG(cache_dir=...)
        results = rag.search(query, top_k=3)
        texts = [r["text"] for r in results]

    Indexing is owned by concinno (``RAGIndex.build()``). If no
    content has been indexed, ``hybrid_search`` returns ``[]`` and
    engine.py's ``if results:`` check skips the enrichment branch —
    identical observable behavior to the pre-M1 empty-chunks path.
    """

    def __init__(self, cache_dir: str = ".persona_rag") -> None:
        self._cache_dir = Path(cache_dir)
        self._cache_dir.mkdir(parents=True, exist_ok=True)
        self._weights_path = self._cache_dir / "ziq_weights.json"
        # Delegate all retrieval to concinno. Passing an empty
        # knowledge_dirs list + include_bundled=False keeps the
        # index scoped to whatever the caller explicitly adds via
        # ``RAGIndex.update(path)``.
        self._index = RAGIndex(
            knowledge_dirs=[],
            project_dir=os.environ.get("CLAUDE_PROJECT_DIR", "."),
            cache_dir=str(self._cache_dir / "rag"),
            include_bundled=False,
            namespace="aegis_persona",
        )

    def search(
        self, query: str, top_k: int = 5,
    ) -> list[dict]:
        """Hybrid search + Aegis 4-bucket weight rerank.

        Over-fetches top_k * 3 candidates from concinno to give the
        bucket reweight some room to re-order, then returns top_k.
        """
        try:
            hits = self._index.hybrid_search(
                query, top_k=top_k * 3,
            )
        except Exception:
            # Index not built / chromadb missing → safe empty.
            # engine.py's `if results:` guard handles this.
            return []

        if not hits:
            return []

        weights = _load_weights(self._weights_path)
        for h in hits:
            src_type = _classify_source(h.get("file", ""))
            h["source_type"] = src_type
            base = h.get("fused_score", h.get("score", 0.5))
            h["final_score"] = base * weights[src_type]

        hits.sort(
            key=lambda x: x.get("final_score", 0.0),
            reverse=True,
        )
        return hits[:top_k]

    def feedback(self, used_results: list[dict]) -> None:
        """EMA update: reward the 4 buckets whose hits were used.

        Takes the actual search-result dicts (NOT raw text), reads
        ``source_type`` populated by ``search()``, and nudges the
        weight for every bucket seen. No substring guessing.

        The positive-only arm is intentional: unused buckets don't
        decay here because the next ``search()`` call will already
        apply the current weights to rerank, so under-performing
        buckets lose ground automatically by not accumulating
        reward. Keeping the update idempotent per bucket (one nudge
        regardless of how many hits came from that bucket) avoids
        blowing out weights when top_k happens to be bucket-heavy.
        """
        if not used_results:
            return
        weights = _load_weights(self._weights_path)
        seen_buckets: set[str] = set()
        for hit in used_results:
            bucket = hit.get("source_type")
            if bucket in SOURCE_TYPES:
                seen_buckets.add(bucket)
        if not seen_buckets:
            return
        for bucket in seen_buckets:
            weights[bucket] = _ema_update(weights[bucket], 1.0)
        _save_weights(self._weights_path, weights)

    def get_weights(self) -> dict[str, float]:
        """Expose current 4-bucket FTRL weights (debug/telemetry)."""
        weights = _load_weights(self._weights_path)
        return {st: round(w, 3) for st, w in weights.items()}
