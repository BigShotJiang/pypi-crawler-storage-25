"""Subagent fork — spawn a child :class:`AgentLoop` from a parent (A5).

**Why not reuse** :mod:`persona.subagent`? That module (A11 work) is
a web-UI prompt-capture layer — it streams a single LLM call to a
WebSocket. A5 is structurally different: it spawns a full agent
loop (multi-round, tool-using) **inside** the parent's loop, so the
LLM can delegate a self-contained sub-task and receive a single
textual answer back.

**No CC-style fork caps**. CC imposes a hard limit on concurrent
subagents (``L1`` / ``L2`` gates). Aegis replaces that with a
**soft recursion-depth guard** (default 5) which only prevents
runaway recursion from a buggy LLM — operators can raise it
freely. The authoritative limit is the policy DSL (A4) via the
shared pre-hook list.

Shared context
--------------
The child inherits:

* the parent's ``llm_call`` (same provider / same credentials)
* a subset (or all) of the parent's ``tools``
* the parent's ``pre_hooks`` + ``post_hooks`` by default (so
  Guards / Cerno / policy all apply) — callers can pass override
  lists to carve a narrower sandbox for the child

The child does **not** share ``AgentState`` with the parent: the
fork is opaque, the parent observes only the returned ``final_text``.
This matches CC's subagent contract and keeps the parent's history
tidy.
"""

from __future__ import annotations

from collections.abc import Iterable
from dataclasses import dataclass, field
from typing import Any

from concinno.fidelity_delta import (
    FidelityDeltaRecord,
    compute_fidelity_delta,
)

from .agent_loop import (
    AgentLoop,
    AgentState,
    LLMCall,
    PostToolUseHook,
    PreToolUseHook,
    Tool,
)


class SubagentRecursionError(RuntimeError):
    """Raised when fork depth exceeds the soft recursion cap."""


@dataclass
class SubagentForkTool:
    """Tool that spawns a child :class:`AgentLoop` on demand.

    Conforms to the :class:`Tool` protocol so the parent loop can
    call it like any other tool. The LLM issues a ``spawn_subagent``
    tool call with a ``prompt`` and optional ``system`` override;
    this tool runs the child loop to completion and returns its
    ``final_text`` as the tool result.

    Parameters
    ----------
    llm_call:
        Shared LLM provider — normally the parent's.
    tools:
        Child's tool registry. Must **exclude** this
        :class:`SubagentForkTool` to break the recursion, unless
        the caller explicitly opts into nested spawning (set
        ``allow_nested=True``).
    pre_hooks / post_hooks:
        Inherited hook lists. Default ``()`` means the child has no
        guards — callers almost always want to pass the parent's
        lists here.
    max_iterations:
        Forwarded to :class:`AgentLoop.max_iterations` for each child.
    max_depth:
        Soft cap on how many times ``spawn_subagent`` can recursively
        fire. Starts at ``1`` (parent counts as depth 0, first child
        = depth 1). Default ``5`` blocks runaway recursion without
        boxing in legitimate deep decompositions.
    allow_nested:
        When False (default), this tool removes itself from the
        child's registry so children cannot spawn grandchildren.
        When True, the child inherits the full parent registry
        including the fork tool — depth guard keeps infinite
        recursion bounded.
    """

    llm_call: LLMCall
    tools: dict[str, Tool] = field(default_factory=dict)
    pre_hooks: list[PreToolUseHook] = field(default_factory=list)
    post_hooks: list[PostToolUseHook] = field(default_factory=list)
    max_iterations: int = 25
    max_depth: int = 5
    allow_nested: bool = False
    measure_fidelity: bool = True
    _depth: int = 0

    name: str = "spawn_subagent"

    # Instance-level record of the last fork's fidelity delta.
    # Not a dataclass field so it stays out of __init__ / __eq__ /
    # __repr__ — it is purely observational state populated by
    # ``execute``. ``None`` means either no fork has run yet, or
    # ``measure_fidelity`` was disabled for the last call.
    last_fidelity: "FidelityDeltaRecord | None" = field(default=None, repr=False)

    def schema(self) -> dict[str, Any]:
        return {
            "type": "function",
            "function": {
                "name": self.name,
                "description": (
                    "Spawn a child agent with a focused prompt. Returns "
                    "the child's final text once it completes."
                ),
                "parameters": {
                    "type": "object",
                    "properties": {
                        "prompt": {
                            "type": "string",
                            "description": "User-style prompt for the child.",
                        },
                        "system": {
                            "type": "string",
                            "description": (
                                "Optional system prompt. When omitted the "
                                "child has no system message."
                            ),
                        },
                    },
                    "required": ["prompt"],
                },
            },
        }

    async def execute(self, args: dict[str, Any]) -> str:
        """Run the child loop and return its final text."""
        if self._depth >= self.max_depth:
            raise SubagentRecursionError(
                f"subagent recursion depth {self._depth} "
                f">= max_depth {self.max_depth}",
            )

        prompt = args.get("prompt") or ""
        system = args.get("system") or ""

        child_tools = dict(self.tools)
        if not self.allow_nested:
            child_tools.pop(self.name, None)
        else:
            # Pass a deeper-depth clone so recursion terminates.
            deeper = SubagentForkTool(
                llm_call=self.llm_call,
                tools=self.tools,
                pre_hooks=list(self.pre_hooks),
                post_hooks=list(self.post_hooks),
                max_iterations=self.max_iterations,
                max_depth=self.max_depth,
                allow_nested=True,
                _depth=self._depth + 1,
            )
            child_tools[self.name] = deeper

        child = AgentLoop(
            llm_call=self.llm_call,
            tools=child_tools,
            pre_hooks=list(self.pre_hooks),
            post_hooks=list(self.post_hooks),
            max_iterations=self.max_iterations,
        )

        messages: list[dict[str, Any]] = []
        if system:
            messages.append({"role": "system", "content": system})
        messages.append({"role": "user", "content": prompt})

        state: AgentState = await child.run(messages)
        # Even on max_iterations, return whatever the last assistant
        # said — better than an opaque "truncated" marker. The parent
        # can inspect stop_reason by wrapping execute() if needed.
        final_text = state.final_text or "[subagent produced no final text]"

        # Record structured-field fidelity delta for this fork so the
        # parent (or outer meta-router) can spot forks that collapsed
        # too much of the input. Keeps the DPI-loss measurement
        # per-spawn without blocking the parent path — failures in
        # delta computation must never mask the child's own result.
        if self.measure_fidelity:
            try:
                self.last_fidelity = compute_fidelity_delta(
                    prompt, final_text,
                )
            except Exception:  # noqa: BLE001 — observational metric
                self.last_fidelity = None

        return final_text


def fork_tool_from_parent(
    parent: AgentLoop,
    *,
    expose_tools: Iterable[str] | None = None,
    max_depth: int = 5,
    allow_nested: bool = False,
    measure_fidelity: bool = True,
) -> SubagentForkTool:
    """Convenience: build a fork tool that inherits the parent's context.

    ``expose_tools`` lets callers hand the child a **subset** of the
    parent's tools (useful for least-privilege subagents). ``None``
    passes all parent tools through.

    ``measure_fidelity`` controls whether each spawn computes a
    ``FidelityDeltaRecord`` into ``last_fidelity``. Default ``True``;
    set ``False`` on hot paths where the per-fork delta is not read.
    """
    if expose_tools is None:
        tool_subset = dict(parent.tools)
    else:
        allowed = set(expose_tools)
        tool_subset = {n: t for n, t in parent.tools.items() if n in allowed}
    return SubagentForkTool(
        llm_call=parent.llm_call,
        tools=tool_subset,
        pre_hooks=list(parent.pre_hooks),
        post_hooks=list(parent.post_hooks),
        max_iterations=parent.max_iterations,
        max_depth=max_depth,
        allow_nested=allow_nested,
        measure_fidelity=measure_fidelity,
    )


__all__ = [
    "SubagentForkTool",
    "SubagentRecursionError",
    "fork_tool_from_parent",
]
