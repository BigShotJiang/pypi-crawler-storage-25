"""Guards → :data:`PreToolUseHook` adapter (A3)."""

from __future__ import annotations

import json
from collections.abc import Callable, Iterable
from typing import Any

from ..engine.agent_loop import PermissionDenied, PreToolUseHook
from ..guards import SafetyLevel, SafetyResult, classify_safety


def _serialize_call(tool_name: str, args: dict[str, Any]) -> str:
    """Flatten a tool invocation into a single text blob for classification.

    CortexLibrary expects a string. Using ``json.dumps(default=str)``
    keeps non-stringy arg values (paths, enums, numbers) classifiable
    without blowing up on serialisation — Guards match on substrings.
    """
    try:
        payload = json.dumps(args, default=str, ensure_ascii=False)
    except (TypeError, ValueError):
        payload = str(args)
    return f"{tool_name} {payload}"


def make_guard_pre_hook(
    classifier: Callable[[str], SafetyResult] = classify_safety,
    deny_on: Iterable[SafetyLevel] = (SafetyLevel.DANGEROUS,),
) -> PreToolUseHook:
    """Build a PreToolUseHook that denies when Guards flag a risk level.

    Parameters
    ----------
    classifier:
        Callable ``(text) -> SafetyResult``. Defaults to the CCC-backed
        :func:`persona.guards.classify_safety`. Tests pass a fake.
    deny_on:
        Set of :class:`SafetyLevel` values that trigger
        :class:`PermissionDenied`. Defaults to ``{DANGEROUS}`` —
        ``UNCERTAIN`` falls through so the LLM can retry with
        different arguments.
    """
    deny_set = set(deny_on)

    async def _hook(tool_name: str, args: dict[str, Any]) -> None:
        blob = _serialize_call(tool_name, args)
        result = classifier(blob)
        if result.level in deny_set:
            raise PermissionDenied(
                f"{result.threat_type or result.level.value}: "
                f"{result.detail or 'guard denied'}",
            )

    return _hook


__all__ = ["make_guard_pre_hook"]
