"""persona.hooks.fanout -- Sancio SessionStart/Stop hook fan-out (1.3.0).

This module is **the Sancio side** of the SessionStart / SessionStop
lifecycle hook surface, separate from Claude Code's harness-level
``SessionStart`` / ``SessionStop`` hooks.

Why Sancio, not Concinno
------------------------
Concinno is a *library* — pure logic that runs inside any host (CC,
sancio, third-party). Concinno cannot supervise child processes spawned
by Claude Code because **CC L1 (spawn-control) is rate/quota-locked at
the platform layer**: once a sub-agent is spawned by the CC harness,
Concinno has no in-band channel to observe its lifecycle. Concinno's
PostToolUse hooks can only emit warnings — they cannot deny.

Sancio is a *runtime*. It owns its own session model (the persona-api
process), and therefore owns the SessionStart/Stop semantics for the
agents that run under it. The fan-out registry here lets Sancio's host
plugins (auto-update probes, Cerno auditors, persona warm-up, MCP
server bring-up, etc.) hook the *Sancio* session lifecycle without
touching Concinno's CBUA pipeline. This is the supervision channel
that bypasses the CC L1 ceiling.

Subscriber model
----------------
Subscribers register two ways:

1. **In-process** via :func:`register_session_start` /
   :func:`register_session_stop` for tests + tightly coupled host code.
2. **Out-of-process** via setuptools ``entry_points``:

   * group ``sancio.hooks.session_start`` -> callable
   * group ``sancio.hooks.session_stop``  -> callable

   Each entry point's value is a ``"module:attr"`` reference resolved
   through :func:`importlib.metadata.entry_points` at fan-out time.
   Lazy resolution avoids paying import cost for plugins that never
   fire.

Each subscriber is invoked concurrently with its own asyncio task and
a per-subscriber timeout (default ``5.0`` seconds). The fan-out is
**fail-open**: a subscriber that raises or times out is logged via
``logging.getLogger(__name__).warning`` and skipped — it does NOT
abort the other subscribers, and it does NOT bubble up to the caller.

This is the deliberate inverse of the PreToolUse hook contract (which
denies on raise) because session lifecycle hooks are observational —
the session has already started/stopped by the time the hook fires.
The right place to deny session creation is the API layer, not here.

Public API
----------
* :func:`register_session_start` / :func:`register_session_stop`
* :func:`unregister_session_start` / :func:`unregister_session_stop`
* :func:`list_subscribers`
* :func:`fire_session_start` / :func:`fire_session_stop` (async)
* :func:`reset_for_tests`
* :class:`FanoutResult` — per-subscriber outcome dataclass.

@module persona.hooks.fanout
@responsibility Maintain the in-process subscriber registry, load
    entry-point subscribers lazily, fan out SessionStart/Stop events
    concurrently, collect per-subscriber outcomes.
@dependencies stdlib only (asyncio, contextvars, dataclasses, logging,
    importlib.metadata, time, typing).
@exports register_session_start, register_session_stop,
    unregister_session_start, unregister_session_stop,
    list_subscribers, fire_session_start, fire_session_stop,
    reset_for_tests, FanoutResult, SessionEvent.
"""

from __future__ import annotations

import asyncio
import inspect
import logging
import time
from collections.abc import Awaitable, Callable
from dataclasses import dataclass, field
from typing import Any, Literal

logger = logging.getLogger(__name__)

DEFAULT_TIMEOUT_S: float = 5.0
ENTRY_POINT_GROUP_START = "sancio.hooks.session_start"
ENTRY_POINT_GROUP_STOP = "sancio.hooks.session_stop"

# A subscriber callable accepts a single ``SessionEvent`` arg and
# returns either ``None`` (sync) or an awaitable. We accept both
# shapes — the fan-out wraps sync callables in ``run_in_executor``.
Subscriber = Callable[["SessionEvent"], Any]


@dataclass(frozen=True)
class SessionEvent:
    """Payload passed to every SessionStart/Stop subscriber.

    Frozen so subscribers cannot mutate the event for downstream peers.
    """

    phase: Literal["start", "stop"]
    session_id: str
    started_at: float
    extra: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class FanoutResult:
    """Per-subscriber outcome from a single fan-out call.

    ``ok=True`` => subscriber returned without raising and within the
    timeout window. ``error`` is the str() of the exception or the
    sentinel ``"timeout"`` when the deadline elapsed.
    """

    name: str
    ok: bool
    elapsed_s: float
    error: str | None = None


# Module-level registries. We keep two lists rather than one keyed
# dict so the same callable can be registered under two distinct
# names if the host wants — this matches how entry_points behave.
_session_start_subs: list[tuple[str, Subscriber]] = []
_session_stop_subs: list[tuple[str, Subscriber]] = []


def register_session_start(name: str, subscriber: Subscriber) -> None:
    """Register an in-process SessionStart subscriber.

    Idempotent on ``(name, subscriber)`` pairs — registering the same
    pair twice is a no-op (avoids subtle test-leak duplicates).
    """
    pair = (name, subscriber)
    if pair not in _session_start_subs:
        _session_start_subs.append(pair)


def register_session_stop(name: str, subscriber: Subscriber) -> None:
    """Register an in-process SessionStop subscriber. See `register_session_start`."""
    pair = (name, subscriber)
    if pair not in _session_stop_subs:
        _session_stop_subs.append(pair)


def unregister_session_start(name: str) -> bool:
    """Remove all SessionStart subscribers registered under ``name``.

    Returns True iff at least one entry was removed.
    """
    before = len(_session_start_subs)
    _session_start_subs[:] = [(n, s) for n, s in _session_start_subs if n != name]
    return len(_session_start_subs) < before


def unregister_session_stop(name: str) -> bool:
    """Remove all SessionStop subscribers registered under ``name``."""
    before = len(_session_stop_subs)
    _session_stop_subs[:] = [(n, s) for n, s in _session_stop_subs if n != name]
    return len(_session_stop_subs) < before


def list_subscribers(phase: Literal["start", "stop"]) -> list[str]:
    """Return the names of currently registered subscribers for ``phase``.

    Includes both in-process and entry-point subscribers (the latter
    are resolved lazily here so callers can introspect what would fire
    without actually firing).
    """
    if phase == "start":
        in_proc = [n for n, _ in _session_start_subs]
        ep_subs = _load_entry_point_subscribers(ENTRY_POINT_GROUP_START)
    else:
        in_proc = [n for n, _ in _session_stop_subs]
        ep_subs = _load_entry_point_subscribers(ENTRY_POINT_GROUP_STOP)
    return in_proc + [n for n, _ in ep_subs]


def reset_for_tests() -> None:
    """Clear both registries. Intended for ``conftest.py`` autouse fixture."""
    _session_start_subs.clear()
    _session_stop_subs.clear()


def _load_entry_point_subscribers(group: str) -> list[tuple[str, Subscriber]]:
    """Resolve setuptools entry_points for ``group``.

    Failures (missing module, ImportError) are logged and skipped —
    the fan-out is fail-open at every level.
    """
    try:
        from importlib.metadata import entry_points
    except ImportError:  # pragma: no cover — Python <3.10 not supported
        return []

    out: list[tuple[str, Subscriber]] = []
    try:
        eps = entry_points(group=group)
    except TypeError:
        # Python <3.10 select() shape — fall back to dict access.
        try:
            eps = entry_points().get(group, [])  # type: ignore[union-attr]
        except Exception:  # pragma: no cover — defensive
            return []
    except Exception as exc:  # pragma: no cover — defensive
        logger.warning("entry_points(%s) failed: %s", group, exc)
        return []

    for ep in eps:
        try:
            obj = ep.load()
        except Exception as exc:
            logger.warning(
                "Failed to load entry point %s in group %s: %s", ep.name, group, exc
            )
            continue
        if not callable(obj):
            logger.warning(
                "Entry point %s in group %s is not callable", ep.name, group
            )
            continue
        out.append((ep.name, obj))
    return out


async def _invoke_one(
    name: str,
    subscriber: Subscriber,
    event: SessionEvent,
    timeout_s: float,
) -> FanoutResult:
    """Invoke one subscriber with a timeout. Returns a FanoutResult."""
    start = time.monotonic()
    try:
        result = subscriber(event)
        if inspect.isawaitable(result):
            await asyncio.wait_for(result, timeout=timeout_s)
        # else: sync subscriber already completed.
    except asyncio.TimeoutError:
        return FanoutResult(
            name=name,
            ok=False,
            elapsed_s=time.monotonic() - start,
            error="timeout",
        )
    except Exception as exc:  # noqa: BLE001 — fail-open contract
        logger.warning(
            "Sancio fanout subscriber %r raised %s: %s",
            name,
            type(exc).__name__,
            exc,
        )
        return FanoutResult(
            name=name,
            ok=False,
            elapsed_s=time.monotonic() - start,
            error=f"{type(exc).__name__}: {exc}",
        )
    return FanoutResult(
        name=name, ok=True, elapsed_s=time.monotonic() - start, error=None
    )


async def _fire(
    phase: Literal["start", "stop"],
    session_id: str,
    *,
    extra: dict[str, Any] | None = None,
    timeout_s: float = DEFAULT_TIMEOUT_S,
) -> list[FanoutResult]:
    """Fire ``phase`` subscribers concurrently. Returns per-sub outcomes."""
    if phase == "start":
        in_proc = list(_session_start_subs)
        eps = _load_entry_point_subscribers(ENTRY_POINT_GROUP_START)
    else:
        in_proc = list(_session_stop_subs)
        eps = _load_entry_point_subscribers(ENTRY_POINT_GROUP_STOP)

    subs = in_proc + eps
    if not subs:
        return []

    event = SessionEvent(
        phase=phase,
        session_id=session_id,
        started_at=time.time(),
        extra=dict(extra or {}),
    )
    coros: list[Awaitable[FanoutResult]] = [
        _invoke_one(name, sub, event, timeout_s) for name, sub in subs
    ]
    return list(await asyncio.gather(*coros, return_exceptions=False))


async def fire_session_start(
    session_id: str,
    *,
    extra: dict[str, Any] | None = None,
    timeout_s: float = DEFAULT_TIMEOUT_S,
) -> list[FanoutResult]:
    """Fan out a SessionStart event. Subscribers run concurrently.

    Returns the per-subscriber outcomes. Caller can inspect these for
    observability; the fan-out itself never raises.
    """
    return await _fire(
        "start", session_id, extra=extra, timeout_s=timeout_s
    )


async def fire_session_stop(
    session_id: str,
    *,
    extra: dict[str, Any] | None = None,
    timeout_s: float = DEFAULT_TIMEOUT_S,
) -> list[FanoutResult]:
    """Fan out a SessionStop event. See :func:`fire_session_start`."""
    return await _fire(
        "stop", session_id, extra=extra, timeout_s=timeout_s
    )


__all__ = [
    "DEFAULT_TIMEOUT_S",
    "ENTRY_POINT_GROUP_START",
    "ENTRY_POINT_GROUP_STOP",
    "FanoutResult",
    "SessionEvent",
    "Subscriber",
    "fire_session_start",
    "fire_session_stop",
    "list_subscribers",
    "register_session_start",
    "register_session_stop",
    "reset_for_tests",
    "unregister_session_start",
    "unregister_session_stop",
]
