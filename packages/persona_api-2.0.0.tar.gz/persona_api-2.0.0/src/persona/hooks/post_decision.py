"""PostToolUse decision contract — Sancio 2.0.0 (CC SDK April 2026 alignment).

This module implements the **Option C reframe** of the long-standing
"L6 PostToolUse hard deny" promise (see
``_AI_BRAIN/05_Planning/2026-05-01-l6-posttooluse-design-conflict-options.md``):

* **CC physics constraint** (GitHub anthropics/claude-code#32105): once
  ``tool.execute()`` returns, side effects already exist — no runtime
  can magic-undo them. Anthropic's own docs: "PreToolUse is the only
  hook that can block actions." This is a **physics-level** ceiling,
  not a CC implementation choice.

* **What Sancio actually owns** (and CC's SDK does NOT expose):

  1. *Observation-channel deny* — a post-hook can return
     ``decision="block"`` (synthesised :class:`PostToolUseBlocked`) or
     raise :class:`PostToolDeny`; the agent loop catches it and
     replaces the LLM-visible tool result with an ``is_error=True``
     message. CC's ``updatedToolOutput`` rewrites silently and never
     marks the result as an error — this is the SDK gap Sancio fills.

  2. *Cross-iteration enforcement* — a deny verdict from iteration N
     can mutate the pre-hook policy state so iteration N+1 hits a
     PreToolUse hard-deny. The post-hook → pre-hook bridge lives in
     downstream Cerno glue (see :mod:`persona.hooks.cerno_hook`); this
     module supplies the data plumbing.

The CC parity surface:

* ``updated_output`` mirrors CC's ``hookSpecificOutput.updatedToolOutput``
  (rewrite the tool's output before the LLM sees it).
* ``additional_context`` mirrors CC's ``additionalContext`` (append
  information to the tool result).
* ``decision="block"`` + ``reason`` mirror CC's top-level
  ``decision: "block"`` shape, raised through
  :class:`PostToolUseBlocked` so the agent loop can synthesise an
  ``is_error=True`` tool message exactly like a tool-execution failure.

Backwards-compat: a hook that returns ``None`` (the legacy 1.x
contract) is treated as observational, no mutation. The agent loop
emits a one-shot ``DeprecationWarning`` for hooks that never return a
:class:`PostToolUseDecision`; the legacy signature is dropped in 2.1.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Literal


@dataclass(frozen=True)
class PostToolUseDecision:
    """Return value from a :data:`PostToolUseHook`.

    Aligns with CC SDK April 2026 ``hookSpecificOutput`` shape — every
    field is optional so a hook can express any subset of:

    * ``updated_output`` — replace the tool's output entirely before
      the next LLM iteration sees it (CC ``updatedToolOutput`` parity).
      First non-None wins across multiple hooks; subsequent hooks see
      the rewritten value as their ``result`` argument.

    * ``additional_context`` — append a string to the tool result
      content (CC ``additionalContext`` parity). Multiple hooks
      append in registration order.

    * ``decision="block"`` + ``reason`` — raise
      :class:`PostToolUseBlocked` from the loop, the tool result is
      replaced with an ``is_error=True`` message containing
      ``"blocked: {reason}"``. CC parity: top-level ``decision: "block"``
      with ``reason``.

    The dataclass is frozen so hooks cannot accidentally mutate a
    decision after returning it (which would race with multi-hook
    chaining where decisions flow as immutable values).
    """

    updated_output: Any | None = None
    additional_context: str | None = None
    decision: Literal["block"] | None = None
    reason: str | None = None


class PostToolUseBlocked(Exception):
    """Raised when a post-hook returns ``decision="block"``.

    The agent loop catches this and synthesises an ``is_error=True``
    tool message containing ``"blocked: {reason}"`` so the LLM sees
    the block exactly like a tool-execution failure. The side effects
    of the original tool still happened (CC physics constraint per
    GitHub #32105) — what we deny is the **observation channel**
    feeding the next LLM iteration.
    """


class PostToolDeny(Exception):
    """Raised by a post-hook to deny the tool result via the observation channel.

    Distinct from :class:`PostToolUseBlocked` (which is the synthesised
    twin of the structured ``decision="block"`` return value) — this
    exception is the **direct-raise** path Cerno uses when its deny
    verdict fires mid-cycle. The agent loop catches it and replaces
    ``result`` with ``f"post-hook deny: {exc}"`` plus ``is_error=True``.

    Per Option C reframe: this is **observation-channel deny**, not
    side-effect rollback. The tool already ran. What we contain is
    the conversation downstream of the deny. For cross-iteration
    enforcement, hooks may also mutate pre-hook policy state (so
    iteration N+1 hits a PreToolUse hard-deny on the next attempt).
    """


__all__ = [
    "PostToolDeny",
    "PostToolUseBlocked",
    "PostToolUseDecision",
]
