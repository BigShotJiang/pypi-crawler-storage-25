"""Aegis agent-loop hooks (A3, v3 roadmap).

v3 § 5 unified loop: **Pre-call Guards → LLM → PreToolUse Guards →
Tool exec → PostToolUse Cerno**. This package snaps Aegis's
existing strength layer (47 Guards + 28-detector Cerno) onto the
hook slots exposed by :class:`persona.engine.agent_loop.AgentLoop`
without re-implementing anything.

Design split:

* :mod:`.guard_hook` — factory for a :data:`PreToolUseHook` that
  calls :func:`persona.guards.classify_safety` and raises
  :class:`PermissionDenied` on DANGEROUS hits.
* :mod:`.cerno_hook` — factory for a :data:`PostToolUseHook` that
  invokes :meth:`persona.cerno.Cerno.cycle` for each tool output.
  Post-hooks support **observation-channel deny + Pre-hook
  escalation** per Option C reframe (2026-05-01,
  ``_AI_BRAIN/05_Planning/2026-05-01-l6-posttooluse-design-conflict-options.md``).
  :class:`PostToolDeny` (raised) or
  :class:`PostToolUseDecision` ``decision="block"`` (returned)
  replaces the tool result with an ``is_error=True`` message before
  the LLM iterates; for cross-iteration enforcement, hooks may also
  mutate pre-hook policy state for iteration N+1. The CC physics
  constraint (post-hook cannot block side effects per GitHub
  anthropics/claude-code#32105) is honoured — only the LLM-visible
  channel is denied.
* :mod:`.post_decision` — :class:`PostToolUseDecision` dataclass +
  :class:`PostToolDeny` / :class:`PostToolUseBlocked` exceptions
  (Sancio 2.0.0 contract, CC SDK April 2026
  ``hookSpecificOutput.updatedToolOutput`` parity).

Lazy-loading note: the ``cerno_hook`` and ``guard_hook`` submodules
import from :mod:`persona.engine.agent_loop`, which in turn imports
from :mod:`.post_decision`. Loading them eagerly here would create a
circular-import chain (agent_loop -> hooks/__init__ -> cerno_hook ->
agent_loop). We therefore expose the public symbols through PEP 562
``__getattr__`` so the agent_loop bootstrap path can import
:mod:`.post_decision` directly without dragging in the heavy
adapters.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from .post_decision import (
    PostToolDeny,
    PostToolUseBlocked,
    PostToolUseDecision,
)

if TYPE_CHECKING:
    # Re-exports surface for static analysis. At runtime these resolve
    # via the __getattr__ shim below to break the import cycle.
    from .cerno_hook import CernoHookEvent, make_cerno_post_hook
    from .guard_hook import make_guard_pre_hook


_LAZY_EXPORTS = {
    "CernoHookEvent": (".cerno_hook", "CernoHookEvent"),
    "make_cerno_post_hook": (".cerno_hook", "make_cerno_post_hook"),
    "make_guard_pre_hook": (".guard_hook", "make_guard_pre_hook"),
}


def __getattr__(name: str) -> Any:
    """PEP 562 lazy-import shim — see module docstring for rationale."""
    target = _LAZY_EXPORTS.get(name)
    if target is None:
        raise AttributeError(
            f"module 'persona.hooks' has no attribute {name!r}",
        )
    module_path, attr = target
    from importlib import import_module

    mod = import_module(module_path, package=__name__)
    value = getattr(mod, attr)
    globals()[name] = value  # cache for subsequent attribute lookups
    return value


__all__ = [
    "CernoHookEvent",
    "PostToolDeny",
    "PostToolUseBlocked",
    "PostToolUseDecision",
    "make_cerno_post_hook",
    "make_guard_pre_hook",
]
