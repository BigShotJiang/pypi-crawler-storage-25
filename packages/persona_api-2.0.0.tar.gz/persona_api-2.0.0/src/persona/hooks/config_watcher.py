"""persona.hooks.config_watcher -- watchfiles-backed ConfigChange watcher (2.0.0).

Async filesystem watcher that drives :func:`persona.hooks.config_change.fire_config_change`
when configured paths mutate. Mirrors the CC SDK ``ConfigChange`` event
contract: every detected mutation is mapped to a
:class:`~persona.hooks.config_change.ConfigChangeEvent` with the
appropriate ``source`` label, fanned out to subscribers, and (if no
subscriber blocks) handed to a caller-provided reload callback.

Cross-platform backbone
-----------------------
We use :mod:`watchfiles` (``awatch`` async iterator). Watchfiles is
Rust-backed and routes through the platform native APIs:

* Windows -> ``ReadDirectoryChangesW`` (R1 risk register coverage)
* Linux   -> ``inotify``
* macOS   -> ``FSEvents``

Pinned ``watchfiles>=0.21`` upstream — see plan §5 R1. If the package
is unavailable at import time we fall back to a no-op watcher whose
``start()`` raises a clear :class:`RuntimeError`. This keeps the
import side-effect-free for non-watchfiles installs (rare but
permitted by R1's "graceful degrade" requirement).

Debouncing
----------
``watchfiles.awatch`` already coalesces events on its own polling
window; we additionally enforce a configurable in-process debounce
(default 250ms — the CC default mentioned in plan §2.4) so a burst of
mutations to the same file maps to a single fan-out + reload pair.

Failure isolation
-----------------
A reload callback that raises is logged and the watcher loop
continues. The watcher itself does not implement "last-good
revert" — that is the caller's responsibility (the loader owns the
config state). Per plan §5 R6 the watcher's only commitment is
"never crash the watch loop" and "stop cleanly on shutdown".

@module persona.hooks.config_watcher
@responsibility Map filesystem mutations to ConfigChangeEvent, fan
    out to subscribers, invoke reload callback when no block raised,
    survive subscriber + reload failures, exit cleanly on stop().
@dependencies watchfiles (>=0.21,<2.0) + stdlib (asyncio, logging,
    pathlib, time, typing) + :mod:`persona.hooks.config_change`.
@exports ConfigWatcher.
"""

from __future__ import annotations

import asyncio
import importlib
import logging
import time
from collections.abc import Awaitable, Callable, Iterable
from pathlib import Path
from typing import Any

from persona.hooks.config_change import (
    ConfigChangeEvent,
    ConfigChangeSource,
    fire_config_change,
)

logger = logging.getLogger(__name__)

DEFAULT_DEBOUNCE_MS: int = 250
STOP_TIMEOUT_S: float = 2.0


def _load_awatch() -> Any:
    """Return ``watchfiles.awatch`` or raise a clear RuntimeError.

    Resolved lazily so the module import does not fail on hosts that
    chose not to install ``watchfiles`` (e.g. headless test runners
    that never start a watcher).
    """
    try:
        wf = importlib.import_module("watchfiles")
    except ImportError as exc:  # pragma: no cover — depends on env
        raise RuntimeError(
            "ConfigWatcher requires the 'watchfiles' package "
            "(>=0.21,<2.0). Install via: pip install watchfiles"
        ) from exc
    awatch = getattr(wf, "awatch", None)
    if awatch is None:  # pragma: no cover — defensive
        raise RuntimeError(
            "watchfiles is installed but lacks awatch(); upgrade to >=0.21"
        )
    return awatch


class ConfigWatcher:
    """Async config-file watcher that drives ConfigChange fan-out.

    Lifecycle::

        watcher = ConfigWatcher(
            paths=[Path("~/.claude/settings.json").expanduser()],
            reload_callback=loader.reload_async,
            source_resolver=lambda p: "user_settings",
            debounce_ms=250,
            session_id="sancio-app-1",
        )
        await watcher.start()
        ...
        await watcher.stop()

    Parameters
    ----------
    paths
        Iterable of :class:`pathlib.Path` objects to watch. Each path
        may be a file or directory; watchfiles handles both. Paths
        that do not exist at start time are still watched (watchfiles
        emits ``Change.added`` once they appear).
    reload_callback
        ``async`` callable invoked with the mutated :class:`Path` once
        no subscriber blocked the change. The watcher catches and
        logs callback exceptions — it does NOT propagate them. The
        caller is responsible for any "last-good config" revert.
    source_resolver
        Maps a mutated :class:`Path` to a ``ConfigChangeSource``
        literal (``user_settings | project_settings | local_settings
        | policy_settings | skills``). Allows the host to encode its
        own settings layout without leaking it into this module.
    debounce_ms
        Per-file debounce window. Mutations to the same path within
        this window coalesce to a single fan-out + reload pair.
        Defaults to 250ms (CC SDK default per plan §2.4).
    session_id
        Optional Sancio session id passed through on every
        :class:`ConfigChangeEvent`. ``None`` for global watchers.

    Notes
    -----
    The watcher is **single-shot per instance** — once :meth:`stop`
    has been awaited, calling :meth:`start` again is undefined. Spin
    up a fresh ``ConfigWatcher`` for the next lifecycle.
    """

    def __init__(
        self,
        paths: Iterable[Path],
        reload_callback: Callable[[Path], Awaitable[None]],
        source_resolver: Callable[[Path], ConfigChangeSource],
        *,
        debounce_ms: int = DEFAULT_DEBOUNCE_MS,
        session_id: str | None = None,
    ) -> None:
        self._paths: list[Path] = [Path(p) for p in paths]
        self._reload_callback = reload_callback
        self._source_resolver = source_resolver
        self._debounce_ms = max(0, int(debounce_ms))
        self._session_id = session_id

        self._task: asyncio.Task[None] | None = None
        self._stop_event: asyncio.Event | None = None
        # Per-path last-fire timestamp (monotonic seconds) used for
        # in-process debounce. Distinct from watchfiles' internal
        # debounce so callers can tune them independently.
        self._last_fire: dict[str, float] = {}

    @property
    def is_running(self) -> bool:
        """True iff the watch task has been started and is not done."""
        return self._task is not None and not self._task.done()

    async def start(self) -> None:
        """Start the watch task. Idempotent — second call is a no-op.

        Raises :class:`RuntimeError` if ``watchfiles`` is not
        installed (the package is a soft runtime dep).
        """
        if self.is_running:
            return
        # Resolve awatch eagerly so a missing dep fails fast at start
        # rather than silently in the background task.
        _load_awatch()
        self._stop_event = asyncio.Event()
        self._task = asyncio.create_task(
            self._run_loop(), name="sancio-config-watcher"
        )

    async def stop(self) -> None:
        """Signal the watch loop to exit and await its completion.

        Bounded by :data:`STOP_TIMEOUT_S` (2.0s — plan §5 R6) so a
        wedged callback cannot block runtime shutdown indefinitely.
        """
        if self._stop_event is not None:
            self._stop_event.set()
        task = self._task
        if task is None:
            return
        try:
            await asyncio.wait_for(task, timeout=STOP_TIMEOUT_S)
        except asyncio.TimeoutError:
            logger.warning(
                "ConfigWatcher.stop() timed out after %.1fs — cancelling task",
                STOP_TIMEOUT_S,
            )
            task.cancel()
            try:
                await task
            except (asyncio.CancelledError, Exception):  # noqa: BLE001
                pass
        finally:
            self._task = None
            self._stop_event = None

    async def _run_loop(self) -> None:
        """Inner watch loop. Survives every kind of subscriber failure."""
        awatch = _load_awatch()
        assert self._stop_event is not None
        # Convert paths to str for watchfiles (it accepts Path too on
        # recent versions but stringification keeps us forward-compat).
        watch_targets = [str(p) for p in self._paths]
        try:
            async for changes in awatch(
                *watch_targets,
                stop_event=self._stop_event,
                # debounce in watchfiles is in ms, applied across the
                # whole batch. We still re-debounce per-path below.
                debounce=max(50, self._debounce_ms),
            ):
                await self._handle_changes(changes)
        except asyncio.CancelledError:
            raise
        except Exception:  # noqa: BLE001 — last-line defence
            logger.exception("ConfigWatcher loop terminated unexpectedly")

    async def _handle_changes(
        self, changes: Iterable[tuple[Any, str]]
    ) -> None:
        """Process a watchfiles batch. Coalesce per-path, fan-out, reload.

        ``changes`` is an iterable of ``(Change, path_str)`` tuples
        where ``Change`` is the ``watchfiles.Change`` enum (added /
        modified / deleted). We treat all three uniformly — the fan-out
        subscribers can inspect ``ConfigChangeEvent.file_path`` if they
        need to differentiate.
        """
        # Deduplicate per-path within the batch so a rapid
        # added+modified pair collapses to one event.
        seen: dict[str, float] = {}
        now = time.monotonic()
        for _change_type, path_str in changes:
            seen[path_str] = now

        for path_str, _ts in seen.items():
            last = self._last_fire.get(path_str, 0.0)
            if (now - last) * 1000.0 < self._debounce_ms:
                continue
            self._last_fire[path_str] = now
            await self._fire_for_path(Path(path_str))

    async def _fire_for_path(self, path: Path) -> None:
        """Build event, fan out, reload if no block. Survives any failure."""
        try:
            source = self._source_resolver(path)
        except Exception:  # noqa: BLE001
            logger.exception(
                "ConfigWatcher source_resolver raised for %s — skipping event",
                path,
            )
            return

        event = ConfigChangeEvent(
            session_id=self._session_id,
            source=source,
            file_path=str(path),
            changed_at=time.time(),
        )

        try:
            should_reload, _results = await fire_config_change(event)
        except Exception:  # noqa: BLE001 — fan-out is fail-open but
            # catch defensively in case a future change introduces a
            # raise path.
            logger.exception(
                "ConfigWatcher fire_config_change raised — assuming "
                "reload should proceed (fail-open) for %s",
                path,
            )
            should_reload = True

        if not should_reload:
            logger.info(
                "ConfigWatcher: reload skipped for %s (source=%s) — "
                "subscriber blocked",
                path,
                source,
            )
            return

        try:
            await self._reload_callback(path)
        except Exception:  # noqa: BLE001 — last-good preserved upstream
            logger.exception(
                "ConfigWatcher reload_callback raised for %s — last-good "
                "config preserved by caller; watcher loop continues",
                path,
            )


__all__ = [
    "DEFAULT_DEBOUNCE_MS",
    "STOP_TIMEOUT_S",
    "ConfigWatcher",
]
