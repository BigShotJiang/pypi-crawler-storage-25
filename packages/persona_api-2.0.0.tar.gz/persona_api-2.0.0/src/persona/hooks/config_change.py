"""persona.hooks.config_change -- Sancio ConfigChange hook fan-out (2.0.0).

This module is **the Sancio side** of the CC SDK ``ConfigChange`` hook
event documented at ``code.claude.com/docs/en/hooks``. It fires when a
configuration file mutates mid-session (user_settings / project_settings
/ local_settings / policy_settings / skills) and lets Sancio host
plugins observe — and optionally **block** — the live-reload.

Why this is a separate module
-----------------------------
:mod:`persona.hooks.fanout` covers SessionStart/Stop. Those are
observational (fail-open, no veto). ``ConfigChange`` is different:
the CC docs make it explicitly blockable via ``decision: "block"``,
**except** when ``source == "policy_settings"`` — operator policy is
sovereign and a misbehaving subscriber must not be able to silently
suppress a policy edit. Conflating the two contracts in the same
module would either weaken SessionStart's fail-open guarantee or
weaken ConfigChange's policy-exempt guarantee. Two modules, two
contracts.

Subscriber model
----------------
Subscribers register two ways:

1. **In-process** via :func:`register_config_change` for tests + tightly
   coupled host code.
2. **Out-of-process** via setuptools ``entry_points``:

   * group ``sancio.hooks.config_change`` -> callable

   Each entry point's value is a ``"module:attr"`` reference resolved
   through :func:`importlib.metadata.entry_points` at fan-out time.
   Lazy resolution avoids paying import cost for plugins that never
   fire.

Each subscriber is invoked concurrently with its own asyncio task and
a per-subscriber timeout (default ``5.0`` seconds). The fan-out is
**fail-open on generic exceptions** — a subscriber that raises an
unrelated error or times out is logged and skipped, it does NOT abort
peers and it does NOT block the reload.

Block semantics
---------------
A subscriber that wants to veto the reload raises
:class:`ConfigChangeBlocked`. The fan-out aggregates the result:

* ``fire_config_change(...)`` returns ``True`` when no subscriber
  blocked (caller proceeds with reload).
* Returns ``False`` when at least one subscriber blocked AND the event
  source is **not** ``"policy_settings"`` (caller skips reload).
* If the source IS ``"policy_settings"``, any block is **logged and
  ignored** — the policy edit applies. This mirrors the CC behaviour
  (``Exit code 2 blocks the configuration change from taking effect
  (except policy_settings)``) and is enforced by a dedicated test
  per Risk Register R3 in the 2026-04 alignment plan.

Public API
----------
* :func:`register_config_change` / :func:`unregister_config_change`
* :func:`list_config_change_subscribers`
* :func:`fire_config_change` (async)
* :func:`reset_for_tests`
* :class:`ConfigChangeEvent`
* :class:`ConfigChangeBlocked` (subscriber raises to veto reload)
* :class:`FanoutResult` (re-exported from :mod:`persona.hooks.fanout`)

@module persona.hooks.config_change
@responsibility Maintain the in-process subscriber registry, load
    entry-point subscribers lazily, fan out ConfigChange events
    concurrently, aggregate block decisions with policy_settings
    exemption.
@dependencies stdlib only (asyncio, dataclasses, importlib.metadata,
    inspect, logging, time, typing) + reuses
    :class:`persona.hooks.fanout.FanoutResult`.
@exports register_config_change, unregister_config_change,
    list_config_change_subscribers, fire_config_change,
    reset_for_tests, ConfigChangeEvent, ConfigChangeBlocked,
    ConfigChangeSource.
"""

from __future__ import annotations

import asyncio
import inspect
import logging
import time
from collections.abc import Awaitable, Callable
from dataclasses import dataclass
from typing import Any, Literal

from persona.hooks.fanout import FanoutResult

logger = logging.getLogger(__name__)

DEFAULT_TIMEOUT_S: float = 5.0
ENTRY_POINT_GROUP = "sancio.hooks.config_change"

# CC SDK matchers (live docs at code.claude.com/docs/en/hooks). Keep
# the literal names byte-identical to the CC payload so cross-runtime
# integration tests can reuse the same source label.
ConfigChangeSource = Literal[
    "user_settings",
    "project_settings",
    "local_settings",
    "policy_settings",
    "skills",
]

# A subscriber callable accepts a single ``ConfigChangeEvent`` arg and
# returns either ``None`` (sync) or an awaitable. The fan-out wraps
# sync callables and awaits async ones with the per-sub timeout.
Subscriber = Callable[["ConfigChangeEvent"], Any]


class ConfigChangeBlocked(Exception):
    """Raised by a subscriber that wants to veto the configuration reload.

    The fan-out catches this and reports back to the caller so the
    caller can skip the reload. Subscribers should pass a ``reason``
    string for observability::

        raise ConfigChangeBlocked("schema validation failed: missing 'version'")

    **Policy exemption**: when the event ``source`` is
    ``"policy_settings"``, the fan-out logs the block and ignores it
    (returns ``True``). Operator policy is sovereign. See
    Risk Register R3 in the 2026-05-01 alignment plan.
    """


@dataclass(frozen=True)
class ConfigChangeEvent:
    """Payload passed to every ConfigChange subscriber.

    Frozen so subscribers cannot mutate the event for downstream peers.

    Attributes
    ----------
    session_id
        Sancio session id firing the event. ``None`` when the watcher
        is not bound to a specific session (e.g. global config reload
        before the first session starts).
    source
        CC SDK matcher. One of ``user_settings | project_settings |
        local_settings | policy_settings | skills``. ``policy_settings``
        is exempt from blocking — see :class:`ConfigChangeBlocked`.
    file_path
        Absolute path of the mutated file. Set even on deletion (the
        path is what was deleted).
    changed_at
        Unix timestamp (``time.time()``) when the watcher detected the
        mutation. Useful for debounce diagnostics.
    """

    session_id: str | None
    source: ConfigChangeSource
    file_path: str
    changed_at: float


# Module-level registry. Same shape as fanout.py — list of (name,
# subscriber) tuples so the same callable can register under two
# different names if the host wants.
_subs: list[tuple[str, Subscriber]] = []


def register_config_change(
    subscriber: Subscriber,
    *,
    name: str | None = None,
) -> str:
    """Register an in-process ConfigChange subscriber.

    Idempotent on ``(name, subscriber)`` pairs — registering the same
    pair twice is a no-op (avoids subtle test-leak duplicates).

    Parameters
    ----------
    subscriber
        Callable accepting a :class:`ConfigChangeEvent`. Sync or async.
    name
        Optional registration name. Defaults to ``subscriber.__name__``
        when present, else ``repr(subscriber)``.

    Returns
    -------
    str
        The resolved registration name (caller can pass it to
        :func:`unregister_config_change`).
    """
    resolved = name or getattr(subscriber, "__name__", None) or repr(subscriber)
    pair = (resolved, subscriber)
    if pair not in _subs:
        _subs.append(pair)
    return resolved


def unregister_config_change(name_or_callable: str | Subscriber) -> bool:
    """Remove a previously-registered subscriber.

    Accepts either the registration name (string) or the original
    callable. Returns True iff at least one entry was removed.
    """
    before = len(_subs)
    if isinstance(name_or_callable, str):
        _subs[:] = [(n, s) for n, s in _subs if n != name_or_callable]
    else:
        _subs[:] = [(n, s) for n, s in _subs if s is not name_or_callable]
    return len(_subs) < before


def list_config_change_subscribers() -> list[str]:
    """Return names of currently registered subscribers (in-proc + entry-point).

    Entry-point subscribers are resolved lazily here so callers can
    introspect what would fire without actually firing.
    """
    in_proc = [n for n, _ in _subs]
    eps = _load_entry_point_subscribers()
    return in_proc + [n for n, _ in eps]


def reset_for_tests() -> None:
    """Clear the registry. Intended for ``conftest.py`` autouse fixtures."""
    _subs.clear()


def _load_entry_point_subscribers() -> list[tuple[str, Subscriber]]:
    """Resolve setuptools entry_points for ``sancio.hooks.config_change``.

    Failures (missing module, ImportError) are logged and skipped — the
    fan-out is fail-open at every level. Mirrors
    :func:`persona.hooks.fanout._load_entry_point_subscribers`.
    """
    try:
        from importlib.metadata import entry_points
    except ImportError:  # pragma: no cover — Python <3.10 not supported
        return []

    out: list[tuple[str, Subscriber]] = []
    try:
        eps = entry_points(group=ENTRY_POINT_GROUP)
    except TypeError:
        # Python <3.10 select() shape — fall back to dict access.
        try:
            eps = entry_points().get(ENTRY_POINT_GROUP, [])  # type: ignore[union-attr]
        except Exception:  # pragma: no cover — defensive
            return []
    except Exception as exc:  # pragma: no cover — defensive
        logger.warning("entry_points(%s) failed: %s", ENTRY_POINT_GROUP, exc)
        return []

    for ep in eps:
        try:
            obj = ep.load()
        except Exception as exc:
            logger.warning(
                "Failed to load entry point %s in group %s: %s",
                ep.name,
                ENTRY_POINT_GROUP,
                exc,
            )
            continue
        if not callable(obj):
            logger.warning(
                "Entry point %s in group %s is not callable",
                ep.name,
                ENTRY_POINT_GROUP,
            )
            continue
        out.append((ep.name, obj))
    return out


async def _invoke_one(
    name: str,
    subscriber: Subscriber,
    event: ConfigChangeEvent,
    timeout_s: float,
) -> tuple[FanoutResult, bool]:
    """Invoke one subscriber with a timeout.

    Returns a ``(FanoutResult, blocked)`` pair where ``blocked`` is
    True iff the subscriber raised :class:`ConfigChangeBlocked` (the
    block is **not** suppressed at the policy_settings layer here —
    the caller :func:`fire_config_change` does that aggregation so
    the per-subscriber outcome stays observable).
    """
    start = time.monotonic()
    blocked = False
    try:
        result = subscriber(event)
        if inspect.isawaitable(result):
            await asyncio.wait_for(result, timeout=timeout_s)
    except asyncio.TimeoutError:
        return (
            FanoutResult(
                name=name,
                ok=False,
                elapsed_s=time.monotonic() - start,
                error="timeout",
            ),
            False,
        )
    except ConfigChangeBlocked as exc:
        blocked = True
        return (
            FanoutResult(
                name=name,
                ok=False,
                elapsed_s=time.monotonic() - start,
                error=f"blocked: {exc}" if str(exc) else "blocked",
            ),
            blocked,
        )
    except Exception as exc:  # noqa: BLE001 — fail-open contract
        logger.warning(
            "Sancio config_change subscriber %r raised %s: %s",
            name,
            type(exc).__name__,
            exc,
        )
        return (
            FanoutResult(
                name=name,
                ok=False,
                elapsed_s=time.monotonic() - start,
                error=f"{type(exc).__name__}: {exc}",
            ),
            False,
        )
    return (
        FanoutResult(
            name=name, ok=True, elapsed_s=time.monotonic() - start, error=None
        ),
        False,
    )


async def fire_config_change(
    event: ConfigChangeEvent,
    *,
    timeout: float = DEFAULT_TIMEOUT_S,
) -> tuple[bool, list[FanoutResult]]:
    """Fan out a ConfigChange event. Subscribers run concurrently.

    Parameters
    ----------
    event
        The :class:`ConfigChangeEvent` payload. Subscribers receive
        the same frozen instance.
    timeout
        Per-subscriber timeout in seconds. Subscribers that exceed it
        are logged + skipped (fail-open) — they cannot wedge the reload.

    Returns
    -------
    tuple[bool, list[FanoutResult]]
        First element: ``True`` if reload should proceed (no
        subscriber blocked, OR source is ``"policy_settings"``).
        ``False`` if a non-policy block decision was raised.
        Second element: per-subscriber outcomes for observability.

    Notes
    -----
    The fan-out itself never raises. Caller can rely on the boolean
    to gate the actual reload action.
    """
    in_proc = list(_subs)
    eps = _load_entry_point_subscribers()
    subs = in_proc + eps

    if not subs:
        # No subscribers — nothing to block, reload proceeds.
        return True, []

    coros: list[Awaitable[tuple[FanoutResult, bool]]] = [
        _invoke_one(name, sub, event, timeout) for name, sub in subs
    ]
    pairs = await asyncio.gather(*coros, return_exceptions=False)
    results = [r for r, _ in pairs]
    any_blocked = any(b for _, b in pairs)

    if any_blocked and event.source == "policy_settings":
        # Policy is sovereign — log and ignore the block. R3 mitigation.
        blocking_names = [r.name for r, b in pairs if b]
        logger.warning(
            "ConfigChange block on source=policy_settings ignored "
            "(subscribers: %s, file_path=%s) — policy edit applies",
            ", ".join(blocking_names),
            event.file_path,
        )
        return True, results

    return (not any_blocked), results


__all__ = [
    "DEFAULT_TIMEOUT_S",
    "ENTRY_POINT_GROUP",
    "ConfigChangeBlocked",
    "ConfigChangeEvent",
    "ConfigChangeSource",
    "FanoutResult",
    "Subscriber",
    "fire_config_change",
    "list_config_change_subscribers",
    "register_config_change",
    "reset_for_tests",
    "unregister_config_change",
]
