"""persona.cerno.cerno — The engine: 7-step Cerno cycle.

This is the heart. Without this class, the 7 modules are parts without
an engine. Ported from ``projects/aegis/src/aegis/cerno/cerno.py``.

Usage::

    from persona.cerno import Cerno

    arb = Cerno(child_id="agent-1")
    action = arb.cycle("delete production db", child_output)
    if action.type == "deny":
        print(f"Blocked: {action.reason}")
    elif action.type == "transfer":
        print(f"Replace child: {action.handoff.transfer_reason}")
"""

from __future__ import annotations

import copy
from typing import Callable, Optional

from persona.cerno.assess import assess, classify_child_action
from persona.cerno.identity import select_identity
from persona.cerno.intercept import intercept
from persona.cerno.recalibrate import recalibrate, should_recalibrate
from persona.cerno.review import review
from persona.cerno.transfer import build_handoff, equilibrate
from persona.cerno.types import (
    CernoAction,
    CernoConfig,
    CernoState,
    DEFAULT_CERNO_CONFIG,
    EquilibriumState,
    HandoffRecord,
    ReviewResult,
)

# ── Callback type ───────────────────────────────────────────

EventCallback = Callable[..., None]


class Cerno:
    """Mother-agent supervisory framework — the 7-step cycle engine.

    CBUA is for the craftsman (child). Cerno is for the cerno
    (mother). Mother supervises, never executes. Mother sees what
    the child missed.

    Seven-step cycle:
        A: Assess (independent pre-judgment)
        R: Review (36-item defect taxonomy, 28 detectors)
        B: Balance (equilibrium pressure tracking)
        I: Intercept (deny / transfer decision)
        T: Transfer (replace unsalvageable child)
        E: Equilibrate (reset after transfer)
        R2: Recalibrate (self-adjust thresholds)
    """

    def __init__(
        self,
        child_id: str = "",
        config: Optional[CernoConfig] = None,
    ):
        self.config = config or copy.deepcopy(DEFAULT_CERNO_CONFIG)
        self.state = CernoState(
            child_id=child_id,
            equilibrium=EquilibriumState(),
            current_identity="mirror",
        )
        self._listeners: dict[str, list[EventCallback]] = {}

    # ── Event system (replaces TS EventEmitter) ─────────────

    def on(self, event: str, callback: EventCallback) -> None:
        self._listeners.setdefault(event, []).append(callback)

    def _emit(self, event: str, **kwargs) -> None:
        for cb in self._listeners.get(event, []):
            try:
                cb(**kwargs)
            except Exception:  # noqa: BLE001 - listener errors isolated
                pass  # Listener errors don't break the cycle

    # ── Full 7-step cycle ───────────────────────────────────

    def cycle(
        self, user_input: str, child_output: str,
    ) -> CernoAction:
        """Run the full Cerno cycle on a child's output.

        Args:
            user_input: Original user request (mother reads independently).
            child_output: Child agent's response.

        Returns:
            CernoAction: allow / deny / transfer / recalibrate.
        """
        # Step A: Assess (mother forms independent judgment)
        assessment = assess(user_input)
        self.state.assessment = assessment

        # Identity rotation based on child action type
        child_action = classify_child_action(user_input)
        new_identity = select_identity(child_action)
        if new_identity != self.state.current_identity:
            old = self.state.current_identity
            self.state.current_identity = new_identity
            self._emit(
                "identity_changed", old=old, new=new_identity,
            )

        # Step R: Review (28 detectors + sycophancy + alignment)
        review_result = review(child_output, assessment)
        self.state.review = review_result

        # Track scores
        self.state.recent_scores.append(review_result.quality_score)
        if len(self.state.recent_scores) > self.config.max_recent_scores:
            self.state.recent_scores.pop(0)

        # Step I: Intercept (decide action)
        action = intercept(review_result, self.state, self.config)

        # Step B: Balance (update equilibrium pressure)
        was_denied = action.type in ("deny", "transfer")
        self._update_equilibrium(review_result, was_denied)

        # Track consecutive denies
        if was_denied:
            self.state.consecutive_denies += 1
        else:
            self.state.consecutive_denies = 0

        # Breaker event
        if self.state.equilibrium.breaker_tripped:
            self._emit(
                "breaker_tripped",
                pressure=self.state.equilibrium.pressure,
            )

        # Step R2: Recalibrate (periodic self-adjustment)
        self.state.steps_since_recal += 1
        if should_recalibrate(self.state, self.config):
            recal = recalibrate(self.state, self.config)
            self.state.steps_since_recal = 0
            if recal.adjustments:
                eq = self.config.equilibrium
                for k, v in recal.adjustments.items():
                    if hasattr(eq, k):
                        setattr(eq, k, v)
            self._emit("recalibration", result=recal)

        # Emit cycle events
        self._emit(
            "cycle_complete",
            action=action,
            review=review_result,
        )
        if action.type == "deny":
            self._emit(
                "deny", reason=action.reason, defects=action.defects,
            )
        if action.type == "transfer":
            self._emit(
                "transfer", handoff=action.handoff,
            )

        return action

    # ── Transfer management ─────────────────────────────────

    def transfer_to(self, new_child_id: str) -> HandoffRecord:
        """Replace current child with a new one (Step T + E)."""
        handoff = build_handoff(self.state, "Manual transfer")
        self.state = equilibrate(self.state, new_child_id)
        return handoff

    # ── Queries ─────────────────────────────────────────────

    def get_state(self) -> CernoState:
        return copy.copy(self.state)

    def is_quality_bypassed(self) -> bool:
        """Should quality guards be skipped? (breaker tripped)."""
        return self.state.equilibrium.breaker_tripped

    def get_child_id(self) -> str:
        return self.state.child_id

    def get_recent_scores(self) -> list[int]:
        return list(self.state.recent_scores)

    # ── Equilibrium (Step B) ────────────────────────────────

    def _update_equilibrium(
        self, review_result: ReviewResult, was_denied: bool,
    ) -> None:
        """Update pressure. Deny builds fast, allow restores slow."""
        del review_result  # Reserved for future per-defect weighting
        eq = self.state.equilibrium
        cfg = self.config.equilibrium

        # Cooldown tick
        if eq.cooldown_remaining > 0:
            eq.cooldown_remaining -= 1
            if eq.cooldown_remaining == 0:
                eq.breaker_tripped = False

        # Pressure update
        if was_denied:
            eq.pressure = min(
                eq.pressure + cfg.deny_increment, cfg.pressure_cap,
            )
        else:
            eq.pressure = max(eq.pressure - cfg.allow_decrement, 0)

        # Breaker check
        if (
            eq.pressure >= cfg.pressure_threshold
            and not eq.breaker_tripped
        ):
            eq.breaker_tripped = True
            eq.cooldown_remaining = cfg.cooldown_steps

        # Deny rate (EMA, alpha = 1/50)
        alpha = 1 / 50
        eq.deny_rate = (1 - alpha) * eq.deny_rate + alpha * (
            1.0 if was_denied else 0.0
        )

        eq.total_steps += 1
        eq.pressure_history.append(eq.pressure)
        if len(eq.pressure_history) > 30:
            eq.pressure_history.pop(0)
