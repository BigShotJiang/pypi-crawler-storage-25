"""persona.cerno.recalibrate — Step R2: Self-calibration.

Every N steps, mother recalibrates own thresholds.
Self-correction: am I too strict? too lenient? new patterns?

Ported from ``projects/aegis/src/aegis/cerno/recalibrate.py``.
"""

from __future__ import annotations

import time

from persona.cerno.types import (
    CernoConfig,
    CernoState,
    RecalibrationResult,
)


def should_recalibrate(
    state: CernoState, config: CernoConfig,
) -> bool:
    return state.steps_since_recal >= config.recalibration_interval


def recalibrate(
    state: CernoState, config: CernoConfig,
) -> RecalibrationResult:
    """Step R2: Recalibrate thresholds based on track record.

    - Deny rate > 40% -> too strict -> loosen
    - Deny rate < 5% (with 10+ data) -> too lenient -> tighten
    - Otherwise -> balanced
    """
    deny_rate = state.equilibrium.deny_rate
    adjustments: dict = {}
    drift: str = "balanced"

    if deny_rate > 0.4:
        drift = "too_strict"
        adjustments["deny_increment"] = max(
            config.equilibrium.deny_increment * 0.8, 0.3,
        )
        adjustments["pressure_threshold"] = min(
            config.equilibrium.pressure_threshold * 1.2, 30,
        )
    elif deny_rate < 0.05 and len(state.recent_scores) >= 10:
        drift = "too_lenient"
        adjustments["deny_increment"] = min(
            config.equilibrium.deny_increment * 1.2, 3.0,
        )
        adjustments["pressure_threshold"] = max(
            config.equilibrium.pressure_threshold * 0.9, 2.0,
        )

    # Detect emerging defect patterns
    emerging: list[str] = []
    if state.review:
        counts: dict[str, int] = {}
        for d in state.review.defects_found:
            counts[d.id] = counts.get(d.id, 0) + 1
        for did, cnt in counts.items():
            if cnt >= 3:
                emerging.append(f"{did} recurring ({cnt}x)")

    # Sycophancy calibration check
    avg = (
        sum(state.recent_scores) / len(state.recent_scores)
        if state.recent_scores
        else 50
    )
    if avg > 90 and state.equilibrium.deny_rate < 0.02:
        emerging.append(
            "Suspiciously high scores — possible detection blind spot"
        )

    return RecalibrationResult(
        steps_since_last_recal=state.steps_since_recal,
        deny_rate_drift=drift,  # type: ignore[arg-type]
        emerging_patterns=emerging,
        adjustments=adjustments,
        recalibrated_at=time.time(),
    )
