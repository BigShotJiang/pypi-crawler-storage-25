"""persona.cerno.review — Step R: 36-item defect taxonomy + 28 detectors.

Mother reviews child output. Pattern match, not LLM call. ~0.5ms.
Ported from ``projects/aegis/src/aegis/cerno/review.py``.
"""

from __future__ import annotations

import re
import time
from typing import Callable, Optional

from persona.cerno.types import (
    Assessment,
    DefectDefinition,
    DefectHit,
    DefectSeverity,
    ReviewResult,
)

# ── 36-item defect taxonomy ─────────────────────────────────

DEFECT_TABLE: list[DefectDefinition] = [
    # L: LLM native (10)
    DefectDefinition(
        "L1", "L", "attention_overflow",
        "Output ignores middle-section details", "medium",
    ),
    DefectDefinition(
        "L2", "L", "position_bias",
        "Disproportionate focus on beginning/end", "low",
    ),
    DefectDefinition(
        "L3", "L", "recency_bias",
        "Latest info overweights earlier context", "medium",
    ),
    DefectDefinition(
        "L4", "L", "anchoring",
        "First number/option dominates reasoning", "medium",
    ),
    DefectDefinition(
        "L5", "L", "verbosity_inflation",
        "Response much longer than necessary", "low",
    ),
    DefectDefinition(
        "L6", "L", "hallucination",
        "Claims facts not supported by input", "high",
    ),
    DefectDefinition(
        "L7", "L", "false_certainty",
        "High confidence on uncertain claims", "high",
    ),
    DefectDefinition(
        "L8", "L", "pattern_completion",
        "Continues pattern without checking", "medium",
    ),
    DefectDefinition(
        "L9", "L", "training_bias",
        "Outdated or domain-inappropriate patterns", "medium",
    ),
    DefectDefinition(
        "L10", "L", "context_window_decay",
        "Quality degrades as conversation grows", "high",
    ),
    # A: RLHF (5)
    DefectDefinition(
        "A1", "A", "sycophancy",
        "Agrees without critical evaluation", "high",
    ),
    DefectDefinition(
        "A2", "A", "loss_aversion",
        "Avoids necessary deletions", "medium",
    ),
    DefectDefinition(
        "A3", "A", "over_correction",
        "Excessive opposite behavior", "medium",
    ),
    DefectDefinition(
        "A4", "A", "safety_theater",
        "Unnecessary warnings/disclaimers", "low",
    ),
    DefectDefinition(
        "A5", "A", "refusal_creep",
        "Refuses reasonable requests", "medium",
    ),
    # B: Behavioral (5)
    DefectDefinition(
        "B1", "B", "short_termism",
        "Quick fix ignoring long-term", "high",
    ),
    DefectDefinition(
        "B2", "B", "action_bias",
        "Doing when nothing is better", "medium",
    ),
    DefectDefinition(
        "B3", "B", "premature_convergence",
        "Locks into first approach", "high",
    ),
    DefectDefinition(
        "B4", "B", "scope_creep",
        "Does more than asked", "medium",
    ),
    DefectDefinition(
        "B5", "B", "cargo_cult",
        "Copies without understanding", "high",
    ),
    # D: Drift (5)
    DefectDefinition(
        "D1", "D", "sop_erosion",
        "Deviates from procedures", "high",
    ),
    DefectDefinition(
        "D2", "D", "identity_loss",
        "Persona instructions forgotten", "medium",
    ),
    DefectDefinition(
        "D3", "D", "goal_drift",
        "Original objective lost", "high",
    ),
    DefectDefinition(
        "D4", "D", "standard_decay",
        "Quality standards relax", "medium",
    ),
    DefectDefinition(
        "D5", "D", "instruction_amnesia",
        "System instructions ignored", "high",
    ),
    # E: Environmental (8)
    DefectDefinition(
        "E1", "E", "context_loss",
        "Earlier context dropped", "high",
    ),
    DefectDefinition(
        "E2", "E", "parallel_chaos",
        "Sub-agents conflict", "high",
    ),
    DefectDefinition(
        "E3", "E", "tool_misuse",
        "Wrong tool for the job", "medium",
    ),
    DefectDefinition(
        "E4", "E", "resource_waste",
        "Excessive token usage", "low",
    ),
    DefectDefinition(
        "E5", "E", "phantom_artifact",
        "Claims output but it doesn't exist", "high",
    ),
    DefectDefinition(
        "E6", "E", "silent_failure",
        "Error swallowed without reporting", "high",
    ),
    DefectDefinition(
        "E7", "E", "dependency_blindness",
        "Changes break downstream", "high",
    ),
    DefectDefinition(
        "E8", "E", "test_theater",
        "Tests pass but don't validate", "high",
    ),
    # Added 2026-04-17: Reflexion-lite retry triggers (MEMORY #56)
    DefectDefinition(
        "E9", "E", "refusal_echo",
        "Output echoes 'I cannot/unable' on answerable task", "high",
    ),
    DefectDefinition(
        "E10", "E", "empty_answer",
        "Output <10 chars or whitespace only", "high",
    ),
    DefectDefinition(
        "E11", "E", "raw_tool_leak",
        "Output is raw tool_result JSON/stderr without synthesis",
        "medium",
    ),
]

# ── Detector helpers ────────────────────────────────────────

_Ctx = dict  # {"output": str, "assessment": Assessment}
_Detector = Callable[[_Ctx], Optional[DefectHit]]


def _hit(
    did: str, sev: DefectSeverity, evidence: str, conf: float,
) -> DefectHit:
    return DefectHit(
        id=did, severity=sev, evidence=evidence, confidence=conf,
    )


# ── 28 Detectors ────────────────────────────────────────────

def _L1(c: _Ctx) -> Optional[DefectHit]:
    """Attention overflow — middle-section ignored."""
    words = c["assessment"].user_intent.split()
    words = [w for w in words if len(w) > 5]
    if len(words) < 10:
        return None
    n = len(words)
    mid = words[int(n * 0.3):int(n * 0.7)]
    if not mid:
        return None
    out = c["output"].lower()
    hits = sum(1 for w in mid if w.lower() in out)
    ratio = hits / len(mid)
    if ratio < 0.15 and len(mid) >= 5:
        return _hit("L1", "medium", f"Middle coverage {ratio:.0%}", 0.5)
    return None


def _L5(c: _Ctx) -> Optional[DefectHit]:
    """Verbosity — output > 4x input length."""
    r = len(c["output"]) / max(len(c["assessment"].user_intent), 1)
    if r > 4:
        return _hit(
            "L5", "low", f"Output/input ratio: {r:.1f}x", min(r / 10, 0.9),
        )
    return None


def _L6(c: _Ctx) -> Optional[DefectHit]:
    """Hallucination — file paths not grounded in input."""
    paths = re.findall(r"(?:/[\w.-]+){2,}", c["output"])
    bad = [p for p in paths if p not in c["assessment"].user_intent]
    if len(bad) > 3:
        return _hit(
            "L6", "high", f"{len(bad)} ungrounded file paths", 0.5,
        )
    return None


def _L7(c: _Ctx) -> Optional[DefectHit]:
    """False certainty."""
    m = re.findall(
        r"\b(definitely|certainly|absolutely|100%|guaranteed|"
        r"undoubtedly|without doubt)\b",
        c["output"], re.I,
    )
    if len(m) >= 2:
        return _hit(
            "L7", "high", f"{len(m)} high-certainty claims", 0.6,
        )
    return None


def _L8(c: _Ctx) -> Optional[DefectHit]:
    """Pattern completion — repeated structural blocks."""
    seen: dict[str, int] = {}
    for line in c["output"].split("\n"):
        t = line.strip()
        if len(t) < 20:
            continue
        seen[t] = seen.get(t, 0) + 1
    reps = sum(1 for v in seen.values() if v >= 3)
    if reps >= 2:
        return _hit(
            "L8", "medium", f"{reps} lines repeated 3+ times", 0.5,
        )
    return None


def _L10(c: _Ctx) -> Optional[DefectHit]:
    """Context window decay — detail drops in second half."""
    words = c["output"].split()
    if len(words) < 500:
        return None
    half = len(words) // 2
    pat = re.compile(
        r"\b(because|therefore|specifically|example|e\.g\.|i\.e\.)\b",
        re.I,
    )
    d1 = len(pat.findall(" ".join(words[:half])))
    d2 = len(pat.findall(" ".join(words[half:])))
    if d1 > 0 and d2 == 0:
        return _hit(
            "L10", "high",
            f"Detail markers: first {d1}, second 0", 0.5,
        )
    return None


def _A1(c: _Ctx) -> Optional[DefectHit]:
    """Sycophancy — agreement without pushback on risky input."""
    if c["assessment"].risk_level == "low":
        return None
    agree = re.search(
        r"\b(great idea|you're right|absolutely|perfect approach|"
        r"that's correct|good thinking)\b",
        c["output"], re.I,
    )
    push = re.search(
        r"\b(however|but|warning|risk|concern|caution|consider|"
        r"alternative|downside)\b",
        c["output"], re.I,
    )
    if agree and not push:
        return _hit(
            "A1", "high",
            "Agrees with risky request without pushback", 0.7,
        )
    return None


def _A2(c: _Ctx) -> Optional[DefectHit]:
    """Loss aversion — avoids deletions when simplification requested."""
    if "minimal_complexity" not in c["assessment"].expected_traits:
        return None
    if re.search(
        r"\b(keep|preserve|maintain|don't remove|backward compat|"
        r"legacy support)\b",
        c["output"], re.I,
    ):
        return _hit(
            "A2", "medium",
            "Avoids removal when simplification requested", 0.5,
        )
    return None


def _A3(c: _Ctx) -> Optional[DefectHit]:
    """Over-correction — extreme prohibition phrases."""
    m = re.findall(
        r"\b(never|absolutely not|under no circumstances|"
        r"strictly forbidden|zero tolerance)\b",
        c["output"], re.I,
    )
    if len(m) >= 3:
        return _hit(
            "A3", "medium", f"{len(m)} extreme prohibitions", 0.5,
        )
    return None


def _A4(c: _Ctx) -> Optional[DefectHit]:
    """Safety theater — unnecessary disclaimers."""
    m = re.findall(
        r"\b(please note|important disclaimer|be careful|"
        r"use at your own risk|"
        r"this is not (?:legal|medical|financial) advice|"
        r"proceed with caution)\b",
        c["output"], re.I,
    )
    if len(m) >= 2:
        return _hit(
            "A4", "low", f"{len(m)} unnecessary disclaimers", 0.5,
        )
    return None


def _B1(c: _Ctx) -> Optional[DefectHit]:
    """Short-termism — quick fix without long-term thought."""
    qf = re.search(
        r"\b(quick fix|temporary|workaround|hack|band-?aid|"
        r"hotfix|TODO.*later)\b",
        c["output"], re.I,
    )
    lt = re.search(
        r"\b(root cause|proper fix|refactor|long[- ]term|"
        r"sustainable|architecture)\b",
        c["output"], re.I,
    )
    if qf and not lt:
        return _hit(
            "B1", "high",
            "Quick fix without long-term consideration", 0.5,
        )
    return None


def _B2(c: _Ctx) -> Optional[DefectHit]:
    """Action bias — unrequested additions."""
    if c["assessment"].risk_level != "low":
        return None
    if re.search(
        r"\b(I (?:also|additionally) (?:added|created|implemented|built)|"
        r"while (?:I was|we were) at it|bonus)\b",
        c["output"], re.I,
    ):
        return _hit(
            "B2", "medium",
            "Unrequested additions on low-risk task", 0.4,
        )
    return None


def _B3(c: _Ctx) -> Optional[DefectHit]:
    """Premature convergence — no alternatives explored."""
    opt = re.search(
        r"\b(option [a-c]|alternative|approach [12]|could also|"
        r"another way|trade-?off)\b",
        c["output"], re.I,
    )
    wc = len(c["output"].split())
    if wc > 200 and not opt:
        return _hit(
            "B3", "high",
            "Long output with no alternatives explored", 0.5,
        )
    return None


def _B4(c: _Ctx) -> Optional[DefectHit]:
    """Scope creep."""
    if re.search(
        r"\b(bonus|additionally|while we're at it|I also|extra|"
        r"nice to have|let me also)\b",
        c["output"], re.I,
    ):
        return _hit(
            "B4", "medium", "Scope expansion beyond request", 0.5,
        )
    return None


def _B5(c: _Ctx) -> Optional[DefectHit]:
    """Cargo cult — cites convention without explaining why."""
    cargo = re.search(
        r"\b(best practice|industry standard|always do it this way|"
        r"convention says|boilerplate)\b",
        c["output"], re.I,
    )
    reason = re.search(
        r"\b(because|reason|trade-?off|benefit|purpose|why)\b",
        c["output"], re.I,
    )
    if cargo and not reason:
        return _hit(
            "B5", "high",
            "Cites convention without explaining purpose", 0.5,
        )
    return None


def _D1(c: _Ctx) -> Optional[DefectHit]:
    """SOP erosion — suggests skipping procedure."""
    if re.search(
        r"\b(skip(?:ped|ping)? (?:the |this )?"
        r"(?:step|check|validation|review|test)|"
        r"let's just|straight to|no need to)\b",
        c["output"], re.I,
    ):
        return _hit(
            "D1", "high",
            "Suggests skipping established procedure", 0.6,
        )
    return None


def _D2(c: _Ctx) -> Optional[DefectHit]:
    """Identity loss — fell back to generic AI."""
    if re.search(
        r"\b(as an AI|I'm (?:just )?(?:a |an )?"
        r"(?:language model|AI|chatbot|assistant))\b",
        c["output"], re.I,
    ):
        return _hit(
            "D2", "medium", "Fell back to generic AI identity", 0.7,
        )
    return None


def _D3(c: _Ctx) -> Optional[DefectHit]:
    """Goal drift — output doesn't address original intent."""
    iw = [
        w for w in c["assessment"].user_intent.lower().split()
        if len(w) > 4
    ]
    if len(iw) < 3:
        return None
    out = c["output"].lower()
    hits = sum(1 for w in iw if w in out)
    cov = hits / len(iw)
    if cov < 0.2:
        return _hit("D3", "high", f"Intent coverage {cov:.0%}", 0.6)
    return None


def _D4(c: _Ctx) -> Optional[DefectHit]:
    """Standard decay — euphemisms masking incomplete work."""
    if re.search(
        r"\b(mostly works|almost (?:there|correct)|good enough|"
        r"close enough|roughly right|not quite|partially)\b",
        c["output"], re.I,
    ):
        return _hit(
            "D4", "medium",
            "Euphemism masking incomplete work", 0.4,
        )
    return None


def _D5(c: _Ctx) -> Optional[DefectHit]:
    """Instruction amnesia — refuses in-scope request."""
    if re.search(
        r"\b(I (?:can't|cannot|don't|won't) (?:do|help with|assist)|"
        r"that's (?:outside|beyond) (?:my|the) scope)\b",
        c["output"], re.I,
    ):
        return _hit("D5", "high", "Refuses in-scope request", 0.4)
    return None


def _E1(c: _Ctx) -> Optional[DefectHit]:
    """Context loss — asks for available context."""
    if re.search(
        r"\b(I (?:don't|do not) (?:have|see|recall) "
        r"(?:that|the|any) (?:context|information|previous)|"
        r"(?:could you|can you) (?:remind|repeat|share) "
        r"(?:that|the))\b",
        c["output"], re.I,
    ):
        return _hit(
            "E1", "high",
            "Asks for context that should be available", 0.7,
        )
    return None


def _E2(c: _Ctx) -> Optional[DefectHit]:
    """Parallel chaos — conflicting signals."""
    m = re.findall(
        r"\b(but earlier|contradicts|conflict|inconsistent)\b",
        c["output"], re.I,
    )
    if len(m) >= 2:
        return _hit(
            "E2", "high", f"{len(m)} contradiction signals", 0.5,
        )
    return None


def _E3(c: _Ctx) -> Optional[DefectHit]:
    """Tool misuse."""
    if re.search(
        r"\b(let me use (?:grep|find|cat|echo) (?:to|for)|"
        r"I'll (?:write|echo) (?:to|into) (?:the file|stdout))\b",
        c["output"], re.I,
    ):
        return _hit(
            "E3", "medium", "Proposes wrong tool for the job", 0.4,
        )
    return None


def _E4(c: _Ctx) -> Optional[DefectHit]:
    """Resource waste — too much output for simple task."""
    if c["assessment"].risk_level != "low":
        return None
    wc = len(c["output"].split())
    if wc > 500:
        return _hit(
            "E4", "low", f"{wc} words for low-risk task", 0.4,
        )
    return None


def _E5(c: _Ctx) -> Optional[DefectHit]:
    """Phantom artifact — claims creation without verification."""
    claims = re.findall(
        r"\b(created|wrote|generated|saved|output)\s+"
        r"(?:to\s+)?(?:file\s+)?[\"'`]?[\w./\\-]+[\"'`]?",
        c["output"], re.I,
    )
    verify = re.search(
        r"\b(verified|confirmed|checked|exists|tested)\b",
        c["output"], re.I,
    )
    if len(claims) >= 2 and not verify:
        return _hit(
            "E5", "high",
            f"{len(claims)} creation claims without verification", 0.6,
        )
    return None


def _E6(c: _Ctx) -> Optional[DefectHit]:
    """Silent failure — errors without acknowledgment."""
    errs = re.findall(
        r"\b(error|failed|failure|exception|traceback|FATAL|PANIC)\b",
        c["output"], re.I,
    )
    ack = re.search(
        r"\b(fix|resolve|investigate|debug|address|handle|report)\b",
        c["output"], re.I,
    )
    if len(errs) >= 2 and not ack:
        return _hit(
            "E6", "high",
            f"{len(errs)} errors without acknowledgment", 0.5,
        )
    return None


def _E7(c: _Ctx) -> Optional[DefectHit]:
    """Dependency blindness — breaking change without impact analysis."""
    brk = re.search(
        r"\b(breaking change|deprecated|removed|"
        r"deleted (?:the |this )?"
        r"(?:export|function|method|class|type|interface))\b",
        c["output"], re.I,
    )
    ds = re.search(
        r"\b(consumer|downstream|dependent|import|caller|usage)\b",
        c["output"], re.I,
    )
    if brk and not ds:
        return _hit(
            "E7", "high",
            "Breaking change without downstream analysis", 0.5,
        )
    return None


def _E8(c: _Ctx) -> Optional[DefectHit]:
    """Test theater — claims tests pass without validation detail."""
    claim = re.search(
        r"\b(tests? (?:pass|green|passing|succeeded)|"
        r"all (?:tests? )?(?:pass|green))\b",
        c["output"], re.I,
    )
    detail = re.search(
        r"\b(coverage|assert|expect|verify|validate|"
        r"behavior|scenario|edge case)\b",
        c["output"], re.I,
    )
    if claim and not detail:
        return _hit(
            "E8", "high",
            "Claims tests pass without validation detail", 0.4,
        )
    return None


def _E9(c: _Ctx) -> Optional[DefectHit]:
    """Refusal echo — output contains 'I cannot / unable / as an AI'
    on task whose risk_level is ``low`` (answerable).

    Added 2026-04-17 for GAIA Reflexion-lite retry (MEMORY #56).
    Pattern observed on Gemma 4: model echoes NO_REFUSAL rule text
    as the answer itself (see MEMORY #54).
    """
    pat = re.compile(
        r"\b(I (?:cannot|can't|am unable)|as an AI|"
        r"I don't have (?:access|enough))\b",
        re.I,
    )
    if pat.search(c["output"]) and c["assessment"].risk_level == "low":
        return _hit("E9", "high", "refusal on answerable task", 0.8)
    return None


def _E10(c: _Ctx) -> Optional[DefectHit]:
    """Empty answer — output whitespace-stripped <10 chars.

    Added 2026-04-17 for GAIA Reflexion-lite retry (MEMORY #56).
    Gemma 4 batch variance often produces empty raw (see MEMORY #54).
    """
    stripped = c["output"].strip()
    if len(stripped) < 10:
        return _hit("E10", "high", f"empty: {len(stripped)} chars", 0.95)
    return None


def _E11(c: _Ctx) -> Optional[DefectHit]:
    """Raw tool_result leak — output looks like JSON or Traceback.

    Added 2026-04-17 for GAIA Reflexion-lite retry (MEMORY #56).
    Weak models sometimes return raw tool_result verbatim as their
    answer without synthesis.
    """
    s = c["output"].strip()
    if not s:
        return None
    json_like = s.startswith(("{", "[")) and s.endswith(("}", "]"))
    traceback_like = s.startswith("Traceback") or "stderr>" in s[:80]
    if json_like or traceback_like:
        return _hit("E11", "medium", "raw tool_result in output", 0.7)
    return None


# ── All detectors ───────────────────────────────────────────

_DETECTORS: list[_Detector] = [
    _L1, _L5, _L6, _L7, _L8, _L10,
    _A1, _A2, _A3, _A4,
    _B1, _B2, _B3, _B4, _B5,
    _D1, _D2, _D3, _D4, _D5,
    _E1, _E2, _E3, _E4, _E5, _E6, _E7, _E8,
    _E9, _E10, _E11,
]

# ── Sycophancy scoring ──────────────────────────────────────


def _score_sycophancy(output: str, assessment: Assessment) -> float:
    s = 0.0
    if re.search(
        r"\b(you're right|great idea|excellent point)\b", output, re.I,
    ):
        s += 0.3
    if assessment.risk_level != "low" and not re.search(
        r"\b(risk|warning|caution|careful)\b", output, re.I,
    ):
        s += 0.3
    if re.search(
        r"\b(brilliant|genius|amazing|perfect)\b", output, re.I,
    ):
        s += 0.2
    if not re.search(
        r"\b(alternative|however|consider|trade-?off|downside)\b",
        output, re.I,
    ):
        s += 0.2
    return min(s, 1.0)


# ── Alignment check ─────────────────────────────────────────

_TRAIT_PATTERNS: dict[str, re.Pattern] = {
    "includes_tests": re.compile(
        r"\b(test|spec|expect|assert|describe|it\()\b", re.I,
    ),
    "security_conscious": re.compile(
        r"\b(secur|guard|sanitiz|validat|escape)\b", re.I,
    ),
    "well_documented": re.compile(
        r"\b(/\*\*|//|@param|@returns|jsdoc|comment)\b", re.I,
    ),
    "performance_focused": re.compile(
        r"\b(perf|optim|cache|memo|lazy|O\()\b", re.I,
    ),
    "type_safe": re.compile(
        r"\b(type|interface|schema|zod|z\.\w+)\b", re.I,
    ),
}


def _check_minimal_complexity(text: str) -> bool:
    """Structural check for the ``minimal_complexity`` trait.

    Replaces the legacy placeholder regex ``r"^.{0,5000}$"`` which
    always matched any output <= 5000 chars regardless of actual
    shape — pinned by test_A2 and live for the whole Cerno port
    until 2026-04-15c cleanup. We now evaluate three cheap
    structural signals instead of a meaningless length gate:

    - line count <= 50
    - max indent <= 16 visible columns (about 4 levels at 4-space
      indent, or 4 tabs)
    - average line length <= 120 chars

    All three must hold. Empty input is "minimally complex" by
    definition. We deliberately do NOT parse code — this is used
    for both prose persona responses and code snippets, and the
    regex-only neighbourhood in ``_TRAIT_PATTERNS`` is a document-
    text matcher, not an AST walker.
    """
    lines = text.splitlines() or [""]
    if len(lines) > 50:
        return False
    max_indent = max(
        (len(ln) - len(ln.lstrip(" \t")) for ln in lines),
        default=0,
    )
    if max_indent > 16:
        return False
    total_len = sum(len(ln) for ln in lines)
    avg_len = total_len / max(len(lines), 1)
    return avg_len <= 120


# Extended trait-check registry: each value is either a compiled
# ``re.Pattern`` (matched via ``.search``) or a callable
# ``(text) -> bool``. ``_check_alignment`` dispatches on the type.
_TRAIT_CHECKS: dict[str, object] = {
    **_TRAIT_PATTERNS,
    "minimal_complexity": _check_minimal_complexity,
}


def _check_alignment(output: str, assessment: Assessment) -> bool:
    """Return True when enough expected traits match the output.

    Threshold rationale
    -------------------
    ``hits >= len(traits) * 0.6`` — documented explicitly because
    the 0.6 boundary produces surprising float edges:

    - 1 trait  -> need 1  (1  >= 0.6)
    - 2 traits -> need 2  (2  >= 1.2)
    - 3 traits -> need 2  (2  >= 1.8, 0.667 hit ratio)
    - 4 traits -> need 3  (3  >= 2.4, 0.75 hit ratio)
    - 5 traits -> need 3  (3  >= 3.0, 0.6 hit ratio exact)
    - 6 traits -> need 4  (4  >= 3.6, 0.667 hit ratio)

    Strict inequality (`>`) would exclude the 5-trait-need-3 case,
    which is the canonical "3 out of 5" common sense. We keep
    ``>=`` intentionally.

    Empty traits list short-circuits to True (nothing expected,
    nothing to fail).
    """
    traits = assessment.expected_traits
    if not traits:
        return True
    hits = 0
    for t in traits:
        matcher = _TRAIT_CHECKS.get(t)
        if matcher is None:
            continue
        if callable(matcher) and not hasattr(matcher, "search"):
            if matcher(output):
                hits += 1
        elif matcher.search(output):  # type: ignore[attr-defined]
            hits += 1
    return hits >= len(traits) * 0.6


# ── Quality scoring ─────────────────────────────────────────

# Module-level so tests can import + assert. Unknown severities
# fall back to the medium penalty, which is safer than a KeyError
# at runtime for a new detector that types ``severity="critical"``.
_SEVERITY_PENALTY: dict[str, int] = {"high": 20, "medium": 10, "low": 5}


def _compute_quality(
    defects: list[DefectHit], aligned: bool, sycophancy: float,
) -> int:
    """Quality score in ``[0, 100]``. Higher is better.

    Penalty model:
    - per-defect: ``severity_penalty * confidence``
    - not aligned: -15 flat
    - sycophancy > 0.6: -10 flat

    ``severity_penalty`` falls back to ``10`` (the medium default)
    when the defect's severity is not in the canonical
    {high, medium, low} set. This is defensive against detectors
    that ship new severity labels — the former implementation
    indexed the dict with ``[d.severity]`` and raised KeyError
    instead, which would crash the whole review() call for a
    single bad detector.
    """
    score = 100.0
    for d in defects:
        penalty = _SEVERITY_PENALTY.get(d.severity, 10)
        score -= penalty * d.confidence
    if not aligned:
        score -= 15
    if sycophancy > 0.6:
        score -= 10
    return max(0, min(100, round(score)))


# ── Public API ──────────────────────────────────────────────

def review(child_output: str, assessment: Assessment) -> ReviewResult:
    """Step R: Review child output. Pure computation, ~0.5ms."""
    ctx = {"output": child_output, "assessment": assessment}
    defects = [d for det in _DETECTORS if (d := det(ctx)) is not None]
    syc = _score_sycophancy(child_output, assessment)
    aligned = _check_alignment(child_output, assessment)
    quality = _compute_quality(defects, aligned, syc)
    return ReviewResult(
        defects_found=defects,
        quality_score=quality,
        aligned_with_assessment=aligned,
        sycophancy_risk=syc,
        reviewed_at=time.time(),
    )
