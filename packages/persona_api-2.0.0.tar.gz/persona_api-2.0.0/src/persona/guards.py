"""Aegis guard layer — CortexLibrary thin wrapper.

persona-api delegates safety classification to concinno's 55+ guard
pipeline via `concinno.library.CortexLibrary`. This is a hard
dependency (declared in pyproject.toml as `concinno>=1.17.1`); the
module fails at import time if concinno is unavailable.

Public API (`SafetyLevel`, `SafetyResult`, `classify_safety`,
`get_cortex`, `reset_cortex_singleton`) is preserved for backward
compatibility — no caller needs to change.

P0#1 Task 8 — tool name fix
---------------------------
Pre-P0 ``classify_safety`` called ``cortex.check_safety("Bash",
{"command": message})`` — user chat messages were being routed
through the Bash guard pipeline. That meant:

* Bash-specific destruction guards (``rm -rf`` / ``sudo`` / ``mkfs``)
  false-denied conversational mentions of those commands.
* The Bash pipeline does NOT include ``PromptInjectionGuard`` as a
  first-class check for free-text user messages — it scans
  ``ctx.tool_input["command"]`` which is only populated for
  structured bash calls.

The fix: use ``Write`` with ``content=message`` so
``PromptInjectionGuard._extract_text`` picks up the message through
the ``content`` branch, and a second-tier direct
``PromptInjectionGuard().check()`` call gives us a guaranteed
prompt-injection verdict even if the broader pipeline decides
``allow``. Bash-destruction rules no longer false-fire on
conversational messages.
"""

from __future__ import annotations

import logging
import os
from dataclasses import dataclass
from enum import Enum
from typing import Optional

from concinno.library import CortexLibrary

_LOG = logging.getLogger("persona.guards")


class SafetyLevel(Enum):
    """Safety classification result."""

    SAFE = "safe"
    UNCERTAIN = "uncertain"
    DANGEROUS = "dangerous"


@dataclass
class SafetyResult:
    """Guard classification output.

    Public API — shape is frozen for backward compat. Callers
    rely on `level`, `threat_type`, and `detail`.
    """

    level: SafetyLevel
    threat_type: str = ""
    detail: str = ""


# ── CortexLibrary singleton ─────────────────────

_cortex_library: Optional[CortexLibrary] = None


def get_cortex() -> CortexLibrary:
    """Lazy-initialize CortexLibrary singleton.

    concinno is a hard dependency declared in pyproject.toml; if
    the import succeeded at module load, this function always
    returns a live instance.
    """
    global _cortex_library
    if _cortex_library is None:
        workspace = os.environ.get("PERSONA_API_WORKSPACE", os.getcwd())
        _cortex_library = CortexLibrary(workspace=workspace)
    return _cortex_library


def reset_cortex_singleton() -> None:
    """Reset singleton (test-only helper)."""
    global _cortex_library
    _cortex_library = None


# ── Prompt-injection sub-guard (P0#1 Task 8) ────
#
# Direct handle on ``PromptInjectionGuard`` so user-message analysis
# runs the SECURITY-class injection detector explicitly instead of
# relying on the Bash pipeline to happen to invoke it. Singleton to
# avoid re-compiling regex tables on every call.

_injection_guard = None


def _get_injection_guard():  # pragma: no cover — thin import shim
    """Lazy singleton for :class:`PromptInjectionGuard`."""
    global _injection_guard
    if _injection_guard is None:
        from concinno.prompt_injection_guard import PromptInjectionGuard
        _injection_guard = PromptInjectionGuard()
    return _injection_guard


def _make_user_message_context(text: str):
    """Build a :class:`GuardContext` shaped for free-text scanning.

    ``PromptInjectionGuard._extract_text`` looks at ``Bash.command``,
    ``Write.content``, and ``Edit.new_string``. We pick ``Write``
    with ``content`` so the guard sees the message verbatim without
    the Bash-specific destruction guards joining in.
    """
    from concinno.guards.base import GuardContext

    return GuardContext(
        tool_name="Write",
        tool_input={"path": "__user_message__", "content": text},
        session_id=f"usermsg-{os.getpid()}",
        cache_dir="",
        hook_event="PreToolUse",
        tool_result="",
        workspace="",
    )


def classify_safety(message: str) -> SafetyResult:
    """Classify message safety via CCC CortexLibrary (55+ guards).

    P0#1 Task 8 — the original implementation called
    ``check_safety("Bash", {"command": message})`` which routed
    user-chat messages through the Bash guard pipeline. That both
    false-denied conversational references to bash commands AND
    left the prompt-injection detector partially blind because the
    ``Bash`` path extracts ``command`` but the combined pipeline
    runs filesystem / destruction rules alongside, producing noisy
    verdicts.

    The new flow:

    1. Run ``PromptInjectionGuard.check()`` directly on a
       ``Write``-shaped context. Hits here are DANGEROUS — this is
       the prompt-injection defence.
    2. Fall back to ``check_safety("Write", {"path": "...",
       "content": message})`` for the long-tail SECURITY guards
       that key off ``Write.content``. We do NOT route through
       ``Bash`` any more so bash destruction rules can't misfire
       on user messages.
    3. Preserve the length heuristic (UNCERTAIN for very long
       messages) from the pre-P0 version.

    Runtime exceptions from CortexLibrary are caught and converted
    to a fail-closed DANGEROUS result; we never silently allow
    potentially unsafe content through.
    """
    if not message:
        return SafetyResult(level=SafetyLevel.SAFE)

    # Step 1: direct prompt-injection check. This is the primary
    # defence for user-originated free text. SECURITY-class guard,
    # so a hit is a hard DENY.
    try:
        guard = _get_injection_guard()
        ctx = _make_user_message_context(message)
        injection_result = guard.check(ctx)
        if injection_result is not None and getattr(
            injection_result, "action", None,
        ):
            # GuardResult.deny() → action "deny"
            from concinno.guards.base import GuardAction
            if injection_result.action == GuardAction.DENY:
                return SafetyResult(
                    level=SafetyLevel.DANGEROUS,
                    threat_type="prompt_injection",
                    detail=(getattr(injection_result, "reason", "")
                            or "prompt injection detected")[:200],
                )
    except Exception as exc:  # noqa: BLE001 — guard must never raise
        _LOG.warning(
            "PromptInjectionGuard raised %s; falling back to "
            "CortexLibrary.check_safety pipeline.",
            exc,
        )

    # Step 2: long-tail SECURITY guards via the Write surface. This
    # catches guards that react to ``Write.content`` (secret-file
    # heuristics, exfil patterns) without dragging in bash rules.
    cortex = get_cortex()
    try:
        result = cortex.check_safety(
            "Write", {"path": "__user_message__", "content": message},
        )
    except Exception as exc:  # noqa: BLE001 — guard must never raise
        _LOG.warning(
            "CortexLibrary.check_safety raised %s; failing closed "
            "(returning DANGEROUS) for this call.",
            exc,
        )
        return SafetyResult(
            level=SafetyLevel.DANGEROUS,
            threat_type="cortex_runtime_error",
            detail=str(exc)[:200],
        )

    if result.denied:
        return SafetyResult(
            level=SafetyLevel.DANGEROUS,
            threat_type=(result.reason or "cortex_denied")[:80],
            detail=(result.context or "")[:200],
        )

    # CCC allowed — still apply the length heuristic for UNCERTAIN.
    if len(message) > 5000:  # noqa: PLR2004
        return SafetyResult(
            level=SafetyLevel.UNCERTAIN,
            threat_type="length_anomaly",
            detail=f"Message length: {len(message)}",
        )
    return SafetyResult(level=SafetyLevel.SAFE)
