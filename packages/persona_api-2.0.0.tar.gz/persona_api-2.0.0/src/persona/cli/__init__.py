"""persona.cli -- Sancio umbrella CLI dispatcher.

Aggregates all ``sancio <verb>`` subcommands into a single argparse
tree. As of 0.4.0 the verbs are:

* ``sancio gui [--port ... --host ... --print-token-path]`` — proxies
  to :mod:`persona.gui.cli` (the original entry point lived there
  before this umbrella module existed; see backward-compat note in
  ``persona.gui.cli.main``).
* ``sancio self-update [--version ... --pre --skip-in-use-check
  --dry-run]`` — drives :func:`persona.auto_update.sancio_self_update`.

Future verbs (``sancio status``, ``sancio dispatchers``…) attach to the
same parser via ``register(subparsers)`` callbacks; see
:func:`persona.cli.main._build_parser`.
"""

from __future__ import annotations

from .main import main

__all__ = ["main"]
