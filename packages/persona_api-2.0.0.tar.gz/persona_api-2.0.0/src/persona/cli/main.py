"""persona.cli.main -- Sancio umbrella CLI entry point.

Wired by ``[project.scripts]`` in ``pyproject.toml``::

    sancio = "persona.cli.main:main"

Replaces the previous direct ``persona.gui.cli:main`` wiring (which is
preserved as a backward-compat alias — see :mod:`persona.gui.cli` and
its module docstring). The umbrella exists so future verbs
(``self-update`` from 0.4.0, plus planned ``status`` / ``dispatchers``)
can attach to the same argparse tree without growing one monolithic
file.

@module persona.cli.main
@responsibility Build the top-level argparse tree, register every
    ``sancio <verb>`` subcommand, and dispatch to the appropriate
    handler. No business logic lives here — handlers are imported
    from sibling ``persona.cli.<verb>_cmd`` modules.
@dependencies stdlib only (argparse, sys)
@exports main, build_parser
"""

from __future__ import annotations

import argparse
from typing import Sequence


def build_parser() -> argparse.ArgumentParser:
    """Construct the top-level ``sancio`` argparse parser.

    Subcommand registration is delegated to per-verb modules: each
    verb's ``register(subparsers)`` callback owns the flag set + the
    ``set_defaults(func=...)`` hook that ``main()`` dispatches on.
    """
    parser = argparse.ArgumentParser(
        prog="sancio",
        description=(
            "Sancio runtime CLI. Verbs: gui (launch observability "
            "GUI), self-update (Tier 2 pip upgrade)."
        ),
    )
    sub = parser.add_subparsers(dest="command")

    # gui — delegate to persona.gui.cli.register so the gui flag
    # surface stays canonical there (one definition, two attach
    # paths: umbrella dispatcher here + legacy standalone main).
    from persona.gui.cli import register as register_gui

    register_gui(sub)

    # self-update — Tier 2 mirror of concinno self-update.
    from .self_update_cmd import register as register_self_update

    register_self_update(sub)

    # chat — interactive REPL backed by a Concinno LLMDriver
    # (M1 Week 1 deliverable, sancio-runtime 1.1.0).
    from .chat_cmd import register as register_chat

    register_chat(sub)

    # mcp — built-in stdio MCP server (1.3.0). External MCP clients
    # spawn ``sancio mcp start`` as a subprocess and talk JSON-RPC
    # over stdio. See persona.mcp.server.
    from .mcp_cmd import register as register_mcp

    register_mcp(sub)

    # doctor — runtime health diagnostic (1.3.0). Probes persona-api
    # / MCP server / hook fanout / state store / VPS version drift.
    from .doctor import register as register_doctor

    register_doctor(sub)

    return parser


def main(argv: Sequence[str] | None = None) -> None:
    """Entry point for the ``sancio`` console script.

    Args:
        argv: Argument list (omit to read from ``sys.argv[1:]``).
            Tests pass an explicit list to avoid relying on global
            state.
    """
    parser = build_parser()
    args = parser.parse_args(list(argv) if argv is not None else None)
    if not getattr(args, "command", None):
        parser.print_help()
        return
    func = getattr(args, "func", None)
    if func is None:
        parser.print_help()
        return
    func(args)


__all__ = ["main", "build_parser"]
