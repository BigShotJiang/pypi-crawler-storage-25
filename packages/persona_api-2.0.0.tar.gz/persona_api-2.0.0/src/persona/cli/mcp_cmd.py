"""persona.cli.mcp_cmd -- ``sancio mcp`` subcommand wiring (1.3.0).

Thin argparse glue for the MCP server runtime. ``sancio mcp start``
runs :func:`persona.mcp.server.serve_stdio_blocking` until stdin EOF
or KeyboardInterrupt — meant to be spawned as a child of an external
MCP client (CC, IDE extension, custom orchestrator).

@module persona.cli.mcp_cmd
@responsibility argparse register() + cmd_mcp_start handler
@dependencies stdlib only (argparse, sys)
@exports cmd_mcp_start, register
"""

from __future__ import annotations

import argparse
import sys


def cmd_mcp_start(_args: argparse.Namespace) -> int:
    """Handler for ``sancio mcp start``.

    Boots the stdio MCP server. Returns the server's exit code so the
    umbrella CLI can convert it to ``sys.exit``. The server itself
    blocks on stdin, exits 0 on EOF, 130 on KeyboardInterrupt.
    """
    from persona.mcp.server import serve_stdio_blocking

    return serve_stdio_blocking()


def _cmd_mcp_start_main(args: argparse.Namespace) -> None:
    rc = cmd_mcp_start(args)
    if rc != 0:
        sys.exit(rc)


def register(subparsers: argparse._SubParsersAction) -> None:
    """Attach the ``mcp`` subcommand group to the sancio CLI parser."""
    p = subparsers.add_parser(
        "mcp",
        help="Sancio MCP server (stdio transport). See `sancio mcp -h`.",
    )
    sub = p.add_subparsers(dest="mcp_command")

    start = sub.add_parser(
        "start",
        help=(
            "Start the stdio MCP server (auth via SANCIO_MCP_TOKEN env)"
        ),
    )
    start.set_defaults(func=_cmd_mcp_start_main)

    # If the user runs `sancio mcp` without a verb, show subcommand help.
    def _default(args: argparse.Namespace) -> None:
        if not getattr(args, "mcp_command", None):
            p.print_help()

    p.set_defaults(func=_default)


__all__ = ["cmd_mcp_start", "register"]
