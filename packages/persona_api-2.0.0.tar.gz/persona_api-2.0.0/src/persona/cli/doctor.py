"""persona.cli.doctor -- ``sancio doctor`` runtime diagnostic (1.3.0).

Why Sancio, not Concinno
------------------------
``sancio doctor`` diagnoses *Sancio-only* state: persona-api HTTP
endpoint, MCP server liveness, hook fan-out subscriber count, the
SessionStore filesystem layout, and VPS deploy version drift. None
of these surfaces exist in Concinno — Concinno is a host-agnostic
library, while Sancio is the persona-api process surface. Putting
``doctor`` in Sancio keeps Concinno's CLI free of host-coupled
checks.

Output modes
------------
* ``--format json`` — machine-readable summary, single JSON object on
  stdout. Stable schema for monitoring scrapers.
* ``--format pretty`` (default) — human-readable table on stdout.

Exit codes
----------
* ``0`` — all checks pass (healthy)
* ``1`` — at least one warning (degraded; e.g. persona-api unreachable
  but MCP server alive)
* ``2`` — at least one critical failure (e.g. SessionStore unwritable)

@module persona.cli.doctor
@responsibility Run a fixed list of runtime probes, aggregate
    results, render JSON or pretty table, return the right exit code.
@dependencies stdlib only (argparse, json, os, sys, urllib.request,
    pathlib, dataclasses, importlib).
@exports DoctorCheck, DoctorReport, run_doctor, register, cmd_doctor.
"""

from __future__ import annotations

import argparse
import json
import os
import sys
import urllib.error
import urllib.request
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Literal

Severity = Literal["ok", "warning", "critical"]

PERSONA_API_DEFAULT_BASE = "http://127.0.0.1:8500"
PERSONA_API_BASE_ENV = "SANCIO_PERSONA_API_BASE"
DOCTOR_HTTP_TIMEOUT_S = 3.0


@dataclass
class DoctorCheck:
    """Outcome of a single diagnostic probe."""

    name: str
    status: Severity
    detail: str
    extra: dict[str, object] = field(default_factory=dict)


@dataclass
class DoctorReport:
    """Aggregated doctor output. Maps to the ``--format json`` schema."""

    healthy: bool
    exit_code: int
    checks: list[DoctorCheck] = field(default_factory=list)

    def to_dict(self) -> dict[str, object]:
        return {
            "healthy": self.healthy,
            "exit_code": self.exit_code,
            "checks": [asdict(c) for c in self.checks],
        }


# ── Individual probes ───────────────────────────────────────────


def _check_persona_api(base_url: str) -> DoctorCheck:
    """Hit ``GET {base_url}/v1/health`` with a tight timeout.

    Reachable + 200 => ok. Any error => warning (the runtime might be
    starting up, or the operator might be running doctor without the
    server).
    """
    url = f"{base_url.rstrip('/')}/v1/health"
    try:
        req = urllib.request.Request(url, method="GET")
        with urllib.request.urlopen(req, timeout=DOCTOR_HTTP_TIMEOUT_S) as resp:
            code = resp.getcode()
            body = resp.read(512).decode("utf-8", errors="replace")
    except urllib.error.URLError as exc:
        return DoctorCheck(
            name="persona_api",
            status="warning",
            detail=f"persona-api unreachable at {url}: {exc.reason}",
            extra={"url": url},
        )
    except Exception as exc:  # noqa: BLE001
        return DoctorCheck(
            name="persona_api",
            status="warning",
            detail=f"persona-api probe failed: {type(exc).__name__}: {exc}",
            extra={"url": url},
        )
    if code != 200:
        return DoctorCheck(
            name="persona_api",
            status="warning",
            detail=f"persona-api returned status {code}",
            extra={"url": url, "body_head": body[:200]},
        )
    return DoctorCheck(
        name="persona_api",
        status="ok",
        detail=f"persona-api reachable at {url}",
        extra={"url": url},
    )


def _check_mcp_server() -> DoctorCheck:
    """Verify :mod:`persona.mcp.server` imports + builtin tools resolve.

    We do NOT spawn a real MCP subprocess (would deadlock on stdin).
    Importable + builtin registry non-empty => ok.
    """
    try:
        from persona.mcp.server import MCPServer, _builtin_tools

        server = MCPServer()
        tools = list(server.tools)
        builtins = [t.name for t in _builtin_tools()]
    except Exception as exc:  # noqa: BLE001
        return DoctorCheck(
            name="mcp_server",
            status="critical",
            detail=f"persona.mcp.server import failed: {type(exc).__name__}: {exc}",
        )
    if not tools:
        return DoctorCheck(
            name="mcp_server",
            status="warning",
            detail="MCP server has no registered tools",
        )
    return DoctorCheck(
        name="mcp_server",
        status="ok",
        detail=f"MCP server alive with {len(tools)} tools",
        extra={"tools": tools, "builtins": builtins},
    )


def _check_hook_fanout() -> DoctorCheck:
    """Count SessionStart/Stop subscribers (in-proc + entry-points).

    Zero subscribers is fine — that just means no plugins. We only
    flag when the import itself fails (critical).
    """
    try:
        from persona.hooks.fanout import list_subscribers

        starts = list_subscribers("start")
        stops = list_subscribers("stop")
    except Exception as exc:  # noqa: BLE001
        return DoctorCheck(
            name="hook_fanout",
            status="critical",
            detail=f"persona.hooks.fanout import failed: {exc}",
        )
    return DoctorCheck(
        name="hook_fanout",
        status="ok",
        detail=(
            f"hook fanout: {len(starts)} session_start subscribers, "
            f"{len(stops)} session_stop subscribers"
        ),
        extra={"session_start": starts, "session_stop": stops},
    )


def _check_state_store_writable() -> DoctorCheck:
    """Verify ``Path.home() / '.sancio'`` is writable.

    Persona-api session_persist relies on this directory. Unwritable
    or missing parent => critical (sessions cannot persist).
    """
    root = Path.home() / ".sancio"
    try:
        root.mkdir(parents=True, exist_ok=True)
        probe = root / ".doctor_probe"
        probe.write_text("ok", encoding="utf-8")
        probe.unlink()
    except OSError as exc:
        return DoctorCheck(
            name="state_store",
            status="critical",
            detail=f"~/.sancio not writable: {exc}",
            extra={"root": str(root)},
        )
    return DoctorCheck(
        name="state_store",
        status="ok",
        detail=f"state store writable at {root}",
        extra={"root": str(root)},
    )


def _check_vps_version_match(base_url: str) -> DoctorCheck:
    """Compare local persona-api version with the deployed /v1/health.

    A mismatch is a warning (deploy drift), not critical. Network
    failures are silent — we already covered that in the persona_api
    probe.
    """
    try:
        from persona import __version__ as local_version
    except Exception as exc:  # noqa: BLE001
        return DoctorCheck(
            name="vps_version",
            status="warning",
            detail=f"local persona version unavailable: {exc}",
        )
    url = f"{base_url.rstrip('/')}/v1/health"
    try:
        req = urllib.request.Request(url, method="GET")
        with urllib.request.urlopen(req, timeout=DOCTOR_HTTP_TIMEOUT_S) as resp:
            body = resp.read(512).decode("utf-8", errors="replace")
        data = json.loads(body)
        deployed = str(data.get("version") or data.get("sancio_version") or "")
    except Exception:  # noqa: BLE001
        return DoctorCheck(
            name="vps_version",
            status="warning",
            detail="deployed version unknown (skipped)",
            extra={"local": local_version},
        )
    if not deployed:
        return DoctorCheck(
            name="vps_version",
            status="warning",
            detail="/v1/health did not include 'version' field",
            extra={"local": local_version},
        )
    if deployed != local_version:
        return DoctorCheck(
            name="vps_version",
            status="warning",
            detail=f"version drift: local={local_version} deployed={deployed}",
            extra={"local": local_version, "deployed": deployed},
        )
    return DoctorCheck(
        name="vps_version",
        status="ok",
        detail=f"version match: {local_version}",
        extra={"local": local_version, "deployed": deployed},
    )


# ── Aggregator ──────────────────────────────────────────────────


def run_doctor(*, base_url: str | None = None) -> DoctorReport:
    """Execute every probe + return the aggregate report."""
    base_url = base_url or os.environ.get(PERSONA_API_BASE_ENV) or PERSONA_API_DEFAULT_BASE
    checks: list[DoctorCheck] = [
        _check_persona_api(base_url),
        _check_mcp_server(),
        _check_hook_fanout(),
        _check_state_store_writable(),
        _check_vps_version_match(base_url),
    ]

    has_critical = any(c.status == "critical" for c in checks)
    has_warning = any(c.status == "warning" for c in checks)

    if has_critical:
        exit_code = 2
    elif has_warning:
        exit_code = 1
    else:
        exit_code = 0
    healthy = exit_code == 0
    return DoctorReport(healthy=healthy, exit_code=exit_code, checks=checks)


# ── Renderers ───────────────────────────────────────────────────


def render_json(report: DoctorReport) -> str:
    return json.dumps(report.to_dict(), ensure_ascii=False, indent=2)


def render_pretty(report: DoctorReport) -> str:
    lines: list[str] = []
    headline = "[OK] healthy" if report.healthy else (
        "[WARN] degraded" if report.exit_code == 1 else "[CRIT] critical"
    )
    lines.append(f"sancio doctor — {headline}")
    lines.append("")
    name_width = max((len(c.name) for c in report.checks), default=10)
    for c in report.checks:
        marker = {"ok": "[OK]  ", "warning": "[WARN]", "critical": "[CRIT]"}[
            c.status
        ]
        lines.append(f"{marker} {c.name.ljust(name_width)}  {c.detail}")
    return "\n".join(lines)


# ── CLI glue ────────────────────────────────────────────────────


def cmd_doctor(args: argparse.Namespace) -> int:
    """Handler for ``sancio doctor``. Returns the exit code."""
    report = run_doctor(base_url=args.base_url)
    if args.format == "json":
        sys.stdout.write(render_json(report) + "\n")
    else:
        sys.stdout.write(render_pretty(report) + "\n")
    return report.exit_code


def _cmd_doctor_main(args: argparse.Namespace) -> None:
    rc = cmd_doctor(args)
    if rc != 0:
        sys.exit(rc)


def register(subparsers: argparse._SubParsersAction) -> None:
    """Attach the ``doctor`` subcommand to the sancio CLI parser."""
    p = subparsers.add_parser(
        "doctor",
        help="Diagnose Sancio runtime health (persona-api / MCP / state)",
    )
    p.add_argument(
        "--format",
        choices=("pretty", "json"),
        default="pretty",
        help="Output format (default: pretty table)",
    )
    p.add_argument(
        "--base-url",
        dest="base_url",
        default=None,
        help=(
            "persona-api base URL (default: env "
            f"{PERSONA_API_BASE_ENV} or {PERSONA_API_DEFAULT_BASE})"
        ),
    )
    p.set_defaults(func=_cmd_doctor_main)


__all__ = [
    "DoctorCheck",
    "DoctorReport",
    "PERSONA_API_BASE_ENV",
    "PERSONA_API_DEFAULT_BASE",
    "cmd_doctor",
    "register",
    "render_json",
    "render_pretty",
    "run_doctor",
]
