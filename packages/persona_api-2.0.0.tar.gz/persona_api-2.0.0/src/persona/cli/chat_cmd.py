"""persona.cli.chat_cmd -- ``sancio chat`` subcommand wiring.

Thin argparse glue that translates ``sancio chat ...`` into a
:class:`persona.cli.chat.ChatConfig` and hands control to
:func:`persona.cli.chat.run_chat`. All real REPL logic lives in
``persona.cli.chat`` so this module stays trivial — the test suite
exercises ``chat.ChatREPL`` directly and only smoke-tests the parser
plumbing here.

@module persona.cli.chat_cmd
@responsibility argparse register() + cmd_chat handler
@dependencies stdlib only (argparse, sys)
@exports cmd_chat, register
"""

from __future__ import annotations

import argparse
import sys


def cmd_chat(args: argparse.Namespace) -> int:
    """Handler for ``sancio chat``.

    Build a :class:`ChatConfig` from the CLI flags and run the REPL.
    Returns the REPL's exit code so the umbrella dispatcher can pass
    it to ``sys.exit`` (non-zero → SystemExit).
    """
    from .chat import ChatConfig, run_chat

    config = ChatConfig(
        driver_name=args.driver,
        model=args.model,
        max_rounds=args.max_rounds,
        scan_input=not args.no_scan,
        use_rich=not args.no_rich,
    )
    return run_chat(config=config)


def _cmd_chat_main(args: argparse.Namespace) -> None:
    """argparse-friendly wrapper: convert int return to SystemExit."""
    rc = cmd_chat(args)
    if rc != 0:
        sys.exit(rc)


def register(subparsers: argparse._SubParsersAction) -> None:
    """Attach the ``chat`` subcommand to the sancio CLI parser."""
    p = subparsers.add_parser(
        "chat",
        help="Interactive chat REPL backed by a Concinno LLMDriver",
    )
    p.add_argument(
        "--driver",
        default="anthropic",
        help="Concinno driver registry name (default: anthropic)",
    )
    p.add_argument(
        "--model",
        default=None,
        help="Model id forwarded to the driver factory (e.g. claude-opus-4-7)",
    )
    p.add_argument(
        "--max-rounds",
        dest="max_rounds",
        type=int,
        default=8,
        help="Hard cap on tool-use round-trips per user turn (default: 8)",
    )
    p.add_argument(
        "--no-scan",
        dest="no_scan",
        action="store_true",
        help="Disable PII guard input scan (default: scan on, advisory)",
    )
    p.add_argument(
        "--no-rich",
        dest="no_rich",
        action="store_true",
        help="Force plain output even when 'rich' is installed",
    )
    p.set_defaults(func=_cmd_chat_main)


__all__ = ["cmd_chat", "register"]
