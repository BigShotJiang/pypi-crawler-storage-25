"""persona.cli.chat -- ``sancio chat`` REPL core.

Inspired by claude-agent-sdk-python @anthropics/claude-agent-sdk-python (MIT)
— structure borrowed (REPL loop + slash command dispatcher + driver
abstraction), no source copied. Re-implemented with Concinno-aware
integration so the chat surface lives in the Sancio runtime and not in
Concinno.

Sancio L1 ceiling + L6 Option C reframe (2026-05-01):
    Concinno's :class:`concinno.agent.session_loop.SessionLoop` returns
    :class:`LLMResponse` from ``run_session`` but cannot enforce
    sub-agent fork supervision — that is CC's L1 spawn-control limit
    once the harness spawns a child. The chat REPL surface owns that
    interception point at the Sancio runtime layer.

    M2 instruments **observation-channel deny + Pre-hook escalation**
    via Cerno (Option C reframe per
    ``_AI_BRAIN/05_Planning/2026-05-01-l6-posttooluse-design-conflict-options.md``).
    CC's L6 physics constraint — post-hook cannot block side effects
    per GitHub anthropics/claude-code#32105 — is honored; what Sancio
    uniquely owns is (a) LLM-visible result rewrite that marks the
    result as ``is_error=True`` (CC's ``updatedToolOutput`` rewrites
    silently, no error flag) and (b) cross-iteration policy
    escalation that the CC SDK does not expose. The M1 deliverable is
    the foundation; M2 wires Cerno-backed observation-channel deny on
    top of this loop.

M1 Week 2 (1.2.0) extension:
    Inline 4-cmd dispatcher replaced by :class:`persona.slash.SlashRegistry`
    so sub-packages (auto-update, future Cerno tooling) can register
    commands at install time. Optional :class:`AutoCompactor` +
    :class:`SessionStore` wiring runs after each user turn so context
    stays under threshold and conversations survive process restarts.

@module persona.cli.chat
@responsibility Multi-round chat REPL backed by any
    :class:`concinno.agent.session_loop.LLMDriver`. Owns conversation
    history, slash command dispatch (via SlashRegistry), optional rich
    pretty-printing, optional auto-compaction, optional session
    persistence, and a PolicyGate input scan (PII) before each user
    turn is forwarded to the LLM.
@dependencies stdlib only (argparse, sys, typing). Optional ``rich``
    for terminal styling; falls back to plain ``print`` when missing.
    Concinno >= 4.3.0 for ``LLMDriver`` Protocol, ``PromptEngine``,
    ``security.PIIGuard``. Sibling modules ``persona.slash``,
    ``persona.compaction``, ``persona.session_persist``.
@exports ChatREPL, ChatConfig, run_chat
"""

from __future__ import annotations

import sys
from collections.abc import Callable, Sequence
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any, Protocol, runtime_checkable

from persona.slash import (
    SlashCommand,
    SlashContext,
    SlashRegistry,
    build_default_registry,
)

if TYPE_CHECKING:  # pragma: no cover — typing-only imports
    from persona.compaction import AutoCompactor
    from persona.session_persist import SessionStore

# ── Concinno integration (lazy / soft) ───────────────────────────


@runtime_checkable
class _DriverLike(Protocol):
    """Structural Protocol matching :class:`concinno.agent.LLMDriver`.

    Re-declared locally so this module imports cleanly even when
    Concinno is missing at type-check time (the runtime call still
    requires a real driver). Mirrors the public surface of
    :class:`concinno.agent.session_loop.LLMDriver` — only the methods
    the REPL actually invokes (``complete`` plus ``model_id``).
    """

    @property
    def model_id(self) -> str: ...

    def complete(  # noqa: D401 — Protocol stub
        self,
        messages: list[dict[str, Any]],
        tools: list[dict[str, Any]] | None = None,
        **kwargs: Any,
    ) -> Any: ...


# ── Pretty output abstraction ────────────────────────────────────


def _try_import_rich() -> Any | None:
    """Return ``rich.console.Console`` instance or ``None``.

    Rich is an optional dependency in the ``[chat]`` extras. The REPL
    must keep working without it (plain ``print`` fallback) so that a
    minimal install of ``persona-api`` stays usable from a stock
    Python environment.
    """
    try:  # pragma: no cover — exercised by both branches via a fake
        from rich.console import Console  # type: ignore[import-not-found]

        return Console()
    except ImportError:
        return None


class PlainPrinter:
    """Fallback pretty-printer used when ``rich`` is absent.

    Intentionally minimal — exposes the same three methods the REPL
    calls on a real :class:`rich.console.Console` so call sites never
    branch on ``rich is None``.
    """

    def print(self, *args: Any, **kwargs: Any) -> None:
        """Forward to :func:`print`, dropping rich-specific kwargs."""
        kwargs.pop("style", None)
        kwargs.pop("highlight", None)
        print(*args, **kwargs)

    def rule(self, title: str = "", **_: Any) -> None:
        """Print a horizontal rule with optional title."""
        bar = "─" * 40
        if title:
            print(f"{bar} {title} {bar}")
        else:
            print(bar * 2)


# ── Configuration ────────────────────────────────────────────────


@dataclass
class ChatConfig:
    """Configuration for one :class:`ChatREPL` session.

    Attributes:
        driver_name: Concinno driver registry key (e.g. ``"anthropic"``).
            Resolved lazily via ``concinno.agent.session_loop.get_driver``
            unless ``driver`` is passed directly.
        driver: Pre-built driver instance — overrides ``driver_name``
            when present. Tests inject a mock driver this way.
        model: Optional model id forwarded to the driver factory.
        system: Optional override for the system prompt. ``None`` means
            "let Concinno PromptEngine assemble one".
        max_rounds: Hard cap on tool-use round-trips per user turn.
        scan_input: When True, run the PII guard on each user turn
            before forwarding to the LLM. Findings are reported on
            stderr; the message is still sent (the guard is advisory
            in chat — a hard block would interrupt conversation flow).
        use_rich: When True (default), attempt to import rich; fall
            back to :class:`PlainPrinter` when unavailable.
        compactor: Optional :class:`persona.compaction.AutoCompactor`.
            When set, the REPL calls :meth:`AutoCompactor.maybe_compact`
            after each user turn and rewrites ``ChatREPL.messages`` in
            place if the threshold was crossed. ``None`` (default)
            disables auto-compaction — explicit ``/compact`` still
            no-ops politely in that mode.
        session_persist: Optional :class:`persona.session_persist.SessionStore`.
            When set together with ``session_id``, the REPL calls
            :meth:`SessionStore.maybe_checkpoint` after each user turn so
            the conversation survives a crash. ``None`` (default)
            disables persistence — ``/resume`` becomes a friendly no-op.
        session_id: Stable id for this REPL session. Required for
            persistence to work; if ``session_persist`` is set but
            ``session_id`` is empty the REPL auto-generates one via
            :func:`persona.session_persist.generate_session_id`.
    """

    driver_name: str = "anthropic"
    driver: _DriverLike | None = None
    model: str | None = None
    system: str | None = None
    max_rounds: int = 8
    scan_input: bool = True
    use_rich: bool = True
    compactor: AutoCompactor | None = None
    session_persist: SessionStore | None = None
    session_id: str = ""


# ── Slash command dispatcher (back-compat shim) ──────────────────


# Legacy handler signature — kept for back-compat with code that
# extended :attr:`ChatREPL.slash_table` directly. New code should
# build a :class:`SlashCommand` via :mod:`persona.slash` and register
# it on :attr:`ChatREPL.slash_registry`.
SlashHandler = Callable[["ChatREPL", str], bool]
"""Legacy slash handler signature.

Returns True to keep the REPL running, False to exit.
"""


# ── Core REPL ────────────────────────────────────────────────────


@dataclass
class ChatREPL:
    """Multi-round conversational REPL.

    The REPL maintains a list of ``{role, content}`` messages in
    Anthropic-style structure (``role`` ∈ ``{"user", "assistant"}``,
    ``content`` either a string or a list of typed blocks). Each user
    turn flows through:

      1. Optional PII scan (``ChatConfig.scan_input``).
      2. ``driver.complete(messages, tools=None, **kwargs)``.
      3. Tool-use round-trip — if the model returns
         ``stop_reason="tool_use"``, the REPL appends the assistant
         turn + each tool call as a ``tool_use`` block, dispatches via
         the registered tool callbacks, and feeds the results back as
         ``tool_result`` blocks. Repeats until ``stop_reason !=
         "tool_use"`` or ``max_rounds`` is exhausted.
      4. Optional auto-compaction (``ChatConfig.compactor``).
      5. Optional session checkpoint (``ChatConfig.session_persist``).

    Attributes:
        config: Immutable session configuration.
        messages: Conversation state, mutated in place. Cleared by
            ``/clear``.
        printer: Pretty output handle (rich Console or PlainPrinter).
        tools: Tool spec list passed to the driver. Optional — None
            means "no tools wired" (typical for the M1 deliverable).
        tool_callbacks: Maps tool name → callable that accepts the
            tool's ``input`` dict and returns a string result.
        slash_registry: Pluggable slash command registry. Populated
            by :func:`persona.slash.build_default_registry` on
            ``__post_init__`` unless the caller injected one.
        slash_table: Legacy alias kept for back-compat. Mutating it
            after construction is *not* honoured — the registry is
            the source of truth. Reads expose ``{name: (handler, doc)}``
            tuples that wrap the registry entries.
    """

    config: ChatConfig
    messages: list[dict[str, Any]] = field(default_factory=list)
    printer: Any = field(default_factory=PlainPrinter)
    tools: list[dict[str, Any]] | None = None
    tool_callbacks: dict[str, Callable[[dict[str, Any]], str]] = field(
        default_factory=dict
    )
    slash_registry: SlashRegistry | None = None

    def __post_init__(self) -> None:
        if self.config.use_rich:
            console = _try_import_rich()
            if console is not None:
                self.printer = console
        if self.slash_registry is None:
            self.slash_registry = build_default_registry()
        # Auto-generate a session id when persistence is wired but the
        # caller didn't pick one — keeps the REPL usable in one-liner
        # construction (`ChatREPL(config=ChatConfig(session_persist=...))`)
        # without forcing every test to import generate_session_id.
        if (
            self.config.session_persist is not None
            and not self.config.session_id
        ):
            try:
                from persona.session_persist import generate_session_id

                self.config.session_id = generate_session_id()
            except ImportError:  # pragma: no cover — soft dep
                pass

    # ── Legacy slash_table view (back-compat shim) ───────────────

    @property
    def slash_table(self) -> dict[str, tuple[SlashHandler, str]]:
        """Read-only legacy view: ``{name: (handler_fn, doc)}``.

        Mirrors the shape the pre-1.2.0 REPL exposed. Each tuple's
        handler is a small lambda that adapts the legacy
        ``handler(repl, args) -> bool`` signature to the new
        ``handler(ctx, args) -> Any`` one. Mutating the returned dict
        does NOT affect dispatch — register on
        ``self.slash_registry`` instead.
        """
        if self.slash_registry is None:  # pragma: no cover — guarded by post_init
            return {}
        out: dict[str, tuple[SlashHandler, str]] = {}
        for cmd in self.slash_registry.commands():
            out[cmd.name] = (_legacy_handler_adapter(cmd), cmd.doc)
            for alias in cmd.aliases:
                out[alias] = (_legacy_handler_adapter(cmd), cmd.doc)
        return out

    # ── Driver resolution ────────────────────────────────────────

    def _resolve_driver(self) -> _DriverLike:
        """Return a live driver, resolving from registry if needed.

        Tests pass ``ChatConfig.driver`` directly to avoid touching
        the registry. When only ``driver_name`` is set, we look it up
        via Concinno's ``get_driver`` — the import is lazy so a
        missing ``concinno.agent`` (e.g. unit-test isolated env) only
        blows up at the call site, not at import time.
        """
        if self.config.driver is not None:
            return self.config.driver
        try:
            from concinno.agent.session_loop import get_driver
        except ImportError as exc:  # pragma: no cover — install failure
            raise RuntimeError(
                "concinno.agent.session_loop is required to resolve a driver "
                "by name. Install concinno >= 4.3.0 or pass ChatConfig.driver "
                "directly."
            ) from exc
        kwargs: dict[str, Any] = {}
        if self.config.model:
            kwargs["model"] = self.config.model
        return get_driver(self.config.driver_name, **kwargs)  # type: ignore[no-any-return]

    # ── PolicyGate input scan ────────────────────────────────────

    def _scan_user_input(self, text: str) -> None:
        """Run the PII guard, print findings to stderr, never block.

        We intentionally do NOT abort the turn on a finding — chat is
        an interactive surface where surprising the user with a hard
        block would shred the UX. The right shape is "warn so the
        operator notices what they just typed". A future hard-deny
        mode can be plumbed through ``ChatConfig.scan_input`` becoming
        a Literal["off", "warn", "deny"].
        """
        if not self.config.scan_input or not text:
            return
        try:
            from concinno.security import PIIGuard
        except ImportError:
            return
        try:
            guard = PIIGuard(profile="lite", fail_mode_override="warn")
            result = guard.evaluate(text)
        except Exception as exc:  # noqa: BLE001 — defence in depth
            print(f"[pii_guard] scan failed: {exc}", file=sys.stderr)
            return
        if result.findings:
            kinds = ", ".join(sorted({f.type for f in result.findings}))
            print(
                f"[pii_guard] {len(result.findings)} finding(s) detected "
                f"({kinds}). Message will still be sent.",
                file=sys.stderr,
            )

    # ── Slash dispatch ───────────────────────────────────────────

    def _build_slash_context(self) -> SlashContext:
        """Construct the SlashContext handed to each command handler.

        The ctx.extras["registry"] reference is what powers /help —
        :func:`persona.slash.commands._help_handler` reads it to enumerate
        the registered commands.
        """
        # Resolve a model_id for /status / /model: prefer the config
        # override, fall back to a live driver lookup, then "" so the
        # status handler shows "(unset)" rather than crashing.
        model_id = self.config.model or ""
        if not model_id and self.config.driver is not None:
            model_id = getattr(self.config.driver, "model_id", "") or ""
        ctx = SlashContext(
            messages=self.messages,
            printer=self.printer,
            model_id=model_id,
            compactor=self.config.compactor,
            session_persist=self.config.session_persist,
            session_id=self.config.session_id,
        )
        ctx.extras["registry"] = self.slash_registry
        ctx.extras["repl"] = self
        return ctx

    def dispatch_slash(self, line: str) -> bool:
        """Run a slash command. Returns False to exit the REPL.

        ``line`` is the full input including the leading ``/``. The
        registry handles parse + lookup + execution. We coerce the
        handler's return value into a strict ``bool`` so callers
        (the main loop) keep their tight while-True semantics.
        """
        if self.slash_registry is None:  # pragma: no cover — guarded
            self.printer.print("[err] slash registry missing.")
            return True
        ctx = self._build_slash_context()
        result = self.slash_registry.dispatch(line, ctx)
        # Propagate handler's optional model_id rebind back to config
        # so the next driver resolution picks up /model switches.
        if ctx.model_id and ctx.model_id != (self.config.model or ""):
            self.config.model = ctx.model_id
        # Propagate session_id rebind from /resume so subsequent
        # checkpoints land on the correct session.
        if ctx.session_id and ctx.session_id != self.config.session_id:
            self.config.session_id = ctx.session_id
        # Handlers return False explicitly to terminate; everything else
        # (True, None, int) keeps the loop running.
        return result is not False

    # ── LLM round-trip ───────────────────────────────────────────

    def _run_one_turn(self, user_text: str) -> None:
        """One user turn → one or more LLM calls → final assistant text."""
        self._scan_user_input(user_text)
        self.messages.append({"role": "user", "content": user_text})
        driver = self._resolve_driver()

        kwargs: dict[str, Any] = {}
        if self.config.system is not None:
            kwargs["system"] = self.config.system
        else:
            engine_system = self._maybe_assemble_system_prompt(user_text)
            if engine_system:
                kwargs["system"] = engine_system

        for _round in range(self.config.max_rounds):
            response = driver.complete(
                list(self.messages), tools=self.tools, **kwargs
            )
            text = getattr(response, "text", "") or ""
            tool_calls = getattr(response, "tool_calls", ()) or ()
            stop_reason = getattr(response, "stop_reason", "end_turn")

            if stop_reason != "tool_use" or not tool_calls:
                if text:
                    self.messages.append({"role": "assistant", "content": text})
                    self.printer.print(text)
                self._post_turn_hooks(driver)
                return

            # tool_use: append assistant blocks + dispatch tools
            assistant_blocks: list[dict[str, Any]] = []
            if text:
                assistant_blocks.append({"type": "text", "text": text})
            for call in tool_calls:
                assistant_blocks.append(
                    {
                        "type": "tool_use",
                        "id": getattr(call, "id", ""),
                        "name": getattr(call, "name", ""),
                        "input": getattr(call, "arguments", {}) or {},
                    }
                )
            self.messages.append(
                {"role": "assistant", "content": assistant_blocks}
            )

            result_blocks: list[dict[str, Any]] = []
            for call in tool_calls:
                cb = self.tool_callbacks.get(getattr(call, "name", ""))
                args = getattr(call, "arguments", {}) or {}
                try:
                    body = cb(args) if cb else f"[no callback for {call.name!r}]"
                    is_error = False
                except Exception as exc:  # noqa: BLE001
                    body = f"tool dispatch failed: {exc}"
                    is_error = True
                result_blocks.append(
                    {
                        "type": "tool_result",
                        "tool_use_id": getattr(call, "id", ""),
                        "content": body,
                        "is_error": is_error,
                    }
                )
            self.messages.append({"role": "user", "content": result_blocks})

        self.printer.print(
            "[warn] max_rounds exhausted; turn ended without a final reply."
        )
        self._post_turn_hooks(driver)

    def _post_turn_hooks(self, driver: _DriverLike) -> None:
        """Run AutoCompactor + SessionStore hooks after a finished turn.

        Both hooks are no-ops when the corresponding ``ChatConfig``
        field is ``None``. Failures are caught and reported to stderr
        — neither hook should ever break the chat surface.
        """
        compactor = self.config.compactor
        if compactor is not None:
            try:
                result = compactor.maybe_compact(self.messages)
            except Exception as exc:  # noqa: BLE001 — never break chat
                print(f"[compactor] maybe_compact failed: {exc}", file=sys.stderr)
            else:
                if result.triggered:
                    # Swap rewritten history into place (slice-assign so
                    # the list reference held by SlashContext stays valid).
                    self.messages[:] = result.new_messages
                    self.printer.print(
                        f"[auto-compact] {result.before_messages}→"
                        f"{result.after_messages} messages, "
                        f"{result.before_tokens}→{result.after_tokens} tokens "
                        f"(saved {result.tokens_freed})."
                    )

        store = self.config.session_persist
        if store is not None and self.config.session_id:
            try:
                store.maybe_checkpoint(
                    self.config.session_id,
                    self.messages,
                    model_id=getattr(driver, "model_id", "") or "",
                    tool_set=tuple(sorted(self.tool_callbacks.keys())),
                )
            except Exception as exc:  # noqa: BLE001
                print(
                    f"[session_persist] maybe_checkpoint failed: {exc}",
                    file=sys.stderr,
                )

    def _maybe_assemble_system_prompt(self, user_text: str) -> str | None:
        """Assemble a system prompt via Concinno PromptEngine.

        Returns ``None`` when Concinno is unavailable or the engine
        raises — we degrade silently because chat without a system
        prompt is still functional, it just loses anti-drift markers.
        """
        try:
            from concinno.prompt_engine import PromptEngine
        except ImportError:
            return None
        try:
            engine = PromptEngine()
            engine.load_static()
            return engine.assemble(task_prompt=user_text, complexity="standard")
        except Exception:  # noqa: BLE001 — never break chat over prompt build
            return None

    # ── Main loop ────────────────────────────────────────────────

    def run(
        self,
        input_lines: Sequence[str] | None = None,
    ) -> int:
        """Run the REPL.

        Args:
            input_lines: Optional pre-canned input sequence. When
                provided, used in place of ``input()`` — tests inject
                a list to drive the loop deterministically. ``None``
                means "read from stdin via input()".

        Returns:
            Process exit code. ``0`` on clean exit (``/exit`` or EOF),
            ``130`` on KeyboardInterrupt to match the conventional
            shell signal-128 + SIGINT(2).
        """
        self.printer.rule("sancio chat")
        self.printer.print("Type /help for commands, /exit to quit.")

        line_iter = iter(input_lines) if input_lines is not None else None
        while True:
            try:
                if line_iter is not None:
                    try:
                        line = next(line_iter)
                    except StopIteration:
                        return 0
                else:
                    line = input("you> ")
            except (EOFError, KeyboardInterrupt):
                self.printer.print("")  # newline after ^C/^D
                return 130 if sys.exc_info()[0] is KeyboardInterrupt else 0

            if not line.strip():
                continue
            if line.startswith("/"):
                if not self.dispatch_slash(line):
                    return 0
                continue

            try:
                self._run_one_turn(line)
            except Exception as exc:  # noqa: BLE001 — top-level shield
                print(f"[err] turn failed: {exc}", file=sys.stderr)


# ── Legacy adapter for slash_table back-compat ───────────────────


def _legacy_handler_adapter(cmd: SlashCommand) -> SlashHandler:
    """Wrap a registry handler so it satisfies the legacy signature.

    Pre-1.2.0 callers iterate ``slash_table`` items expecting tuples
    of ``(handler(repl, args) -> bool, doc)``. Registry handlers take
    ``(ctx, args)`` instead. The adapter builds an ad-hoc context from
    the supplied REPL so legacy callers that *invoke* a handler from
    the table (rare; mostly the table is read-only metadata) still
    behave.
    """

    def _adapt(repl: ChatREPL, args: str) -> bool:
        ctx = repl._build_slash_context()  # noqa: SLF001 — controlled use
        result = cmd.handler(ctx, args)
        return result is not False

    return _adapt


# ── Module entry helper ──────────────────────────────────────────


def run_chat(
    config: ChatConfig | None = None,
    *,
    input_lines: Sequence[str] | None = None,
) -> int:
    """Convenience entry — build a REPL, run it, return its exit code.

    Tests construct a :class:`ChatREPL` directly so they can inject
    state (mock driver, captured printer, tool callbacks). Production
    callers go through this wrapper to keep ``cli/chat_cmd.py``
    minimal.
    """
    repl = ChatREPL(config=config or ChatConfig())
    return repl.run(input_lines=input_lines)


__all__ = ["ChatConfig", "ChatREPL", "PlainPrinter", "run_chat"]
