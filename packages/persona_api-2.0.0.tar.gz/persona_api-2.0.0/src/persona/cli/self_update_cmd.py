"""persona.cli.self_update_cmd -- ``sancio self-update`` subcommand.

Mirror of :mod:`concinno.cli.self_update_cmd` for the persona-api
package. Wires :func:`persona.auto_update.sancio_self_update` into the
sancio CLI; the engine module owns all heavy lifting (PyPI fetch,
detached spawn, in-use detection).

@module persona.cli.self_update_cmd
@responsibility Translate CLI flags into ``sancio_self_update()``
    kwargs, print a human-readable report, and exit with an
    appropriate status code.
@dependencies stdlib only (argparse, sys)
@exports cmd_self_update, register
"""

from __future__ import annotations

import argparse
import sys


def cmd_self_update(args: argparse.Namespace) -> int:
    """Handler for ``sancio self-update``.

    Returns the desired exit code. Callers (including the test suite)
    can invoke this directly to inspect the int return; the argparse
    glue in :func:`_cmd_self_update_main` converts a non-zero return
    into ``sys.exit(rc)``.
    """
    from persona.auto_update import sancio_self_update

    result = sancio_self_update(
        target_version=args.version,
        pre_release=args.pre,
        skip_in_use_check=args.skip_in_use_check,
        dry_run=args.dry_run,
    )

    print(f"Current: {result.current_version}")
    if result.latest_version is not None:
        print(f"Latest:  {result.latest_version}")
    else:
        print("Latest:  (unknown — PyPI fetch failed)")
    if result.target_version:
        print(f"Target:  {result.target_version}")
    print(f"Method:  {result.method}")

    if result.in_use_warning:
        print("In-use evidence:")
        for line in result.in_use_warning:
            print(f"  - {line}")

    if result.error:
        print(f"\nError: {result.error}", file=sys.stderr)
        return 1

    if result.dry_run:
        print("\n(dry-run — no helper spawned)")
        return 0

    if result.current_version == (result.target_version or result.latest_version):
        print("\n[OK] Already on target version. Nothing to do.")
        return 0

    if result.helper_spawned:
        print(
            f"\n[OK] Update started in background (PID {result.helper_pid}). "
            f"Restart Sancio / Claude Code to use new version."
        )
        if result.log_path:
            print(f"  Helper log: {result.log_path}")
        return 0

    # Defensive fall-through.
    print("\nNo action taken.")
    return 0


def _cmd_self_update_main(args: argparse.Namespace) -> None:
    """argparse-friendly wrapper: convert int return to SystemExit."""
    rc = cmd_self_update(args)
    if rc != 0:
        sys.exit(rc)


def register(subparsers: argparse._SubParsersAction) -> None:
    """Attach the ``self-update`` subcommand to the sancio CLI parser."""
    p = subparsers.add_parser(
        "self-update",
        help="Upgrade persona-api via detached helper (Tier 2 auto-update)",
    )
    p.add_argument(
        "--version",
        default=None,
        help="Target version (default: latest stable from PyPI)",
    )
    p.add_argument(
        "--pre",
        action="store_true",
        help="Allow alpha/beta/rc/dev pre-releases when picking latest",
    )
    p.add_argument(
        "--skip-in-use-check",
        dest="skip_in_use_check",
        action="store_true",
        help="Skip 'is persona/sancio in use' probe (Windows blocks otherwise)",
    )
    p.add_argument(
        "--dry-run",
        dest="dry_run",
        action="store_true",
        help="Inspect everything but do not spawn the pip helper",
    )
    p.set_defaults(func=_cmd_self_update_main)


__all__ = ["cmd_self_update", "register"]
