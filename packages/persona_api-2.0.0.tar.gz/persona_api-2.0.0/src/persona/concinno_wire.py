"""Centralised Concinno guard wiring for persona-api (wave-3 ROI #1).

This module extends the existing ``persona.guards.classify_safety``
pipeline with two guards that ``CortexLibrary.check_safety("Write",
...)`` does NOT run:

1. :class:`~concinno.secret_scan.SecretScanGuard` — detect messages
   that carry API keys, PEM blocks, or other credentials.
   Chat-path adaptation: return UNCERTAIN + ``redacted=True`` instead
   of DANGEROUS so the caller can strip the secret before forwarding
   to the LLM, rather than hard-blocking an accidental paste.
   Severity: HIGH (secrets reaching LLM telemetry = data breach).

2. :class:`~concinno.threat_patterns_guard.ThreatPatternsGuard` —
   six extended threat categories (harmful-content, social-eng,
   persona-hijack, role-switch, no-restrictions-mode,
   context-reset-attack) ported from the legacy Aegis guard set.
   These key off free-text patterns rather than tool-call shape so
   the existing Write pipeline skips them.
   Severity: MEDIUM-HIGH → DANGEROUS (hard-deny).

Public API
----------
:class:`ChatGuardRouter`
    One-stop router for the ``/v1/chat`` input path. Thread-safe
    (all state is read-only after construction). Tests can inject
    fake guards via the ``extras`` constructor parameter.

:func:`get_chat_guard_router`
    Module-level lazy singleton — same lifecycle as
    ``guards.get_cortex()``.

:func:`chat_classify`
    Drop-in companion to :func:`persona.guards.classify_safety` that
    adds the two extra guards with chat-context filtering.

Design notes
------------
``GuardResult`` metadata fields: both ``SecretScanGuard`` and
``ThreatPatternsGuard`` pass guard-specific data as ``**metadata`` to
``GuardResult.deny()``, which stores them in ``result.metadata`` (a
plain dict). Access is ``result.metadata.get("secrets", [])`` and
``result.metadata.get("threat_type")``.

No new pip deps: both guards ship in ``concinno >= 2.36.0`` which is
declared in ``pyproject.toml``.
"""

from __future__ import annotations

import logging
import os
from dataclasses import dataclass
from enum import Enum
from typing import Optional

from concinno.guards.base import GuardAction, GuardContext

_LOG = logging.getLogger("persona.concinno_wire")


# ── ChatSafetyLevel ─────────────────────────────────────────────────


class ChatSafetyLevel(Enum):
    """Extended safety classification for the chat guard path."""

    SAFE = "safe"
    UNCERTAIN = "uncertain"
    DANGEROUS = "dangerous"


@dataclass
class ChatSafetyResult:
    """Guard classification output for the chat guard router.

    Attributes:
        level: Overall classification verdict.
        threat_type: Short slug identifying the trigger (e.g.
            ``"secret_scan"``, ``"threat_patterns"``,
            ``"prompt_injection"``).
        detail: Human-readable detail for logging / response bodies.
        redacted: When ``True`` the caller may strip the secret and
            forward a sanitised message instead of hard-denying.
        source: Which sub-guard produced the verdict (for audit logs).
    """

    level: ChatSafetyLevel
    threat_type: str = ""
    detail: str = ""
    redacted: bool = False
    source: str = ""


# ── Guard context builder ───────────────────────────────────────────


def _make_chat_guard_context(text: str) -> GuardContext:
    """Build a :class:`GuardContext` shaped for free-text chat messages.

    Uses ``tool_name="Write"`` with ``content=text`` so:

    * ``SecretScanGuard`` triggers (it checks ``Write.content``).
    * ``ThreatPatternsGuard._extract_scannable_text`` picks up the
      message via ``inp.get("content")``.
    * ``PromptInjectionGuard._extract_text`` also sees it via the
      ``Write.content`` branch.

    Mirrors the context builder in :mod:`persona.guards` so both
    pipelines agree on the tool shape.
    """
    return GuardContext(
        tool_name="Write",
        tool_input={"path": "__chat_message__", "content": text},
        session_id=f"chat-{os.getpid()}",
        cache_dir="",
        hook_event="PreToolUse",
        tool_result="",
        workspace="",
    )


# ── ChatGuardRouter ─────────────────────────────────────────────────


class ChatGuardRouter:
    """One-stop chat-path guard router.

    Adds ``SecretScanGuard`` and ``ThreatPatternsGuard`` on top of the
    existing ``CortexLibrary`` + ``PromptInjectionGuard`` chain that
    ``persona.guards.classify_safety`` already runs.

    Pipeline order
    ~~~~~~~~~~~~~~
    1. ``SecretScanGuard`` — secrets in chat → ``UNCERTAIN`` +
       ``redacted=True`` (not DANGEROUS; accidental paste should
       warn + redact, not hard-block).
    2. ``ThreatPatternsGuard`` — actual attack patterns → ``DANGEROUS``.
    3. ``classify_safety`` — existing ``CortexLibrary`` write-path +
       ``PromptInjectionGuard`` chain.

    Parameters
    ----------
    extras:
        Override the list of extra guard instances. Useful in tests
        to inject fakes without patching module globals.
    """

    def __init__(self, extras: Optional[list] = None) -> None:
        from concinno.secret_scan import SecretScanGuard
        from concinno.threat_patterns_guard import ThreatPatternsGuard

        self._extras: list = (
            extras
            if extras is not None
            else [SecretScanGuard(), ThreatPatternsGuard()]
        )

    def check(self, message: str) -> ChatSafetyResult:
        """Classify a chat message through the full extended pipeline.

        Returns:
            :class:`ChatSafetyResult` with the worst verdict seen.
        """
        if not message:
            return ChatSafetyResult(level=ChatSafetyLevel.SAFE)

        ctx = _make_chat_guard_context(message)

        # 1. SecretScanGuard (chat-adapted: redact, not deny)
        result = self._run_secret_scan(ctx)
        if result is not None:
            return result

        # 2. ThreatPatternsGuard (hard-deny)
        result = self._run_threat_patterns(ctx)
        if result is not None:
            return result

        # 3. Existing CortexLibrary + PromptInjectionGuard
        from .guards import classify_safety

        base = classify_safety(message)
        return ChatSafetyResult(
            level=ChatSafetyLevel(base.level.value),
            threat_type=base.threat_type,
            detail=base.detail,
            source="cortex_library",
        )

    # ------------------------------------------------------------------
    # Private helpers

    def _run_secret_scan(
        self, ctx: GuardContext,
    ) -> Optional[ChatSafetyResult]:
        """Run SecretScanGuard; return UNCERTAIN+redacted on hit."""
        for guard in self._extras:
            if type(guard).__name__ != "SecretScanGuard":
                continue
            try:
                gr = guard.check(ctx)
            except Exception as exc:  # noqa: BLE001
                _LOG.warning("SecretScanGuard raised %s; skipping.", exc)
                return None

            if gr is not None and gr.action == GuardAction.DENY:
                secrets: list[str] = gr.metadata.get("secrets", [])
                secret_types = ", ".join(secrets) if secrets else "unknown"
                return ChatSafetyResult(
                    level=ChatSafetyLevel.UNCERTAIN,
                    threat_type="secret_scan",
                    detail=(
                        f"Possible secret in message ({secret_types}). "
                        "Value redacted before forwarding to LLM."
                    ),
                    redacted=True,
                    source="SecretScanGuard",
                )
        return None

    def _run_threat_patterns(
        self, ctx: GuardContext,
    ) -> Optional[ChatSafetyResult]:
        """Run ThreatPatternsGuard; return DANGEROUS on hit."""
        for guard in self._extras:
            if type(guard).__name__ != "ThreatPatternsGuard":
                continue
            try:
                gr = guard.check(ctx)
            except Exception as exc:  # noqa: BLE001
                _LOG.warning("ThreatPatternsGuard raised %s; skipping.", exc)
                return None

            if gr is not None and gr.action == GuardAction.DENY:
                threat_type: str = (
                    gr.metadata.get("threat_type") or "threat_patterns"
                )
                detail: str = (gr.reason or gr.context or "threat pattern detected")[:200]
                return ChatSafetyResult(
                    level=ChatSafetyLevel.DANGEROUS,
                    threat_type=threat_type,
                    detail=detail,
                    source="ThreatPatternsGuard",
                )
        return None


# ── Module-level singleton ──────────────────────────────────────────

_router: Optional[ChatGuardRouter] = None


def get_chat_guard_router() -> ChatGuardRouter:
    """Return the module-level :class:`ChatGuardRouter` singleton.

    Initialised lazily on first call, matching the lifecycle of
    ``guards.get_cortex()``. Tests can reset via
    :func:`reset_chat_guard_router`.
    """
    global _router
    if _router is None:
        _router = ChatGuardRouter()
    return _router


def reset_chat_guard_router() -> None:
    """Reset the singleton (test-only helper)."""
    global _router
    _router = None


def chat_classify(message: str) -> ChatSafetyResult:
    """Classify a chat message via the full extended guard pipeline.

    Drop-in companion to :func:`persona.guards.classify_safety`.
    Returns the richer :class:`ChatSafetyResult` with ``redacted``
    flag and ``source`` provenance.
    """
    return get_chat_guard_router().check(message)
