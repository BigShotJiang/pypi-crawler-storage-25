"""Outline structuring, compaction, reduction stages, and formatting.

Parses the raw outline string (cached alongside page content) into structured
entries, applies intelligent compaction for token-efficient responses, and
formats entries back to the wire format.

The raw outline is produced by ``parser.py`` and stored as-is in the cache.
This module operates on that cached string at response time.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Literal

import structlog

from procontext.parser import _FENCE_RE, _is_matching_fence_closer, _match_heading

log = structlog.get_logger()

OutlineReductionStage = Literal["none", "drop_h6", "drop_h5", "drop_fenced", "drop_h4", "drop_h3"]


@dataclass(frozen=True)
class OutlineEntry:
    """Single entry in a structured outline."""

    line_number: int  # 1-based line number in the source content
    text: str  # Original line text (e.g., "## Usage" or "```python")
    depth: int | None  # 1 for H1 … 6 for H6; None for fence lines
    is_fence: bool  # True for fence opener/closer
    in_fence: bool  # True if inside a fenced code block


# ---------------------------------------------------------------------------
# Parsing
# ---------------------------------------------------------------------------


def parse_outline_entries(outline_string: str) -> list[OutlineEntry]:
    """Parse a cached outline string into structured entries.

    The input format is ``"<lineno>:<original line>\\n..."``.  Each line is
    split on the first ``:``, then classified as a heading or fence line with
    CommonMark-compliant fence state tracking.
    """
    if not outline_string:
        return []

    entries: list[OutlineEntry] = []

    # Fence state tracking (CommonMark rules)
    in_fence = False
    fence_char: str = ""
    fence_len: int = 0

    for raw_line in outline_string.split("\n"):
        if not raw_line:
            continue

        # Split on first ":"
        colon_idx = raw_line.find(":")
        if colon_idx == -1:
            log.warning("outline_malformed_line", raw_line=raw_line)
            continue
        line_number = int(raw_line[:colon_idx])
        text = raw_line[colon_idx + 1 :]

        # Determine if this is a fence line
        fence_match = _FENCE_RE.match(text)

        if not in_fence and fence_match is not None:
            marker = fence_match.group(1)
            char = marker[0]
            length = len(marker)
            in_fence = True
            fence_char = char
            fence_len = length
            entries.append(
                OutlineEntry(
                    line_number=line_number,
                    text=text,
                    depth=None,
                    is_fence=True,
                    in_fence=False,  # The opener itself is not "inside" the fence
                )
            )
        elif in_fence and _is_matching_fence_closer(
            text,
            fence_char=fence_char,
            fence_len=fence_len,
        ):
            in_fence = False
            fence_char = ""
            fence_len = 0
            entries.append(
                OutlineEntry(
                    line_number=line_number,
                    text=text,
                    depth=None,
                    is_fence=True,
                    in_fence=False,  # The closer itself is not "inside" the fence
                )
            )
        else:
            depth = _extract_depth(text, in_fence=in_fence)
            entries.append(
                OutlineEntry(
                    line_number=line_number,
                    text=text,
                    depth=depth,
                    is_fence=False,
                    in_fence=in_fence,
                )
            )

    return entries


def _extract_depth(text: str, *, in_fence: bool) -> int | None:
    """Extract heading depth (1-6) from a line, or None if not a heading."""
    match = _match_heading(text, in_fence=in_fence)
    if match:
        return len(match.group(1))
    return None


# ---------------------------------------------------------------------------
# Empty fence stripping
# ---------------------------------------------------------------------------


def strip_empty_fences(entries: list[OutlineEntry]) -> list[OutlineEntry]:
    """Remove fence pairs that contain no heading entries.

    Fence markers exist in the outline to disambiguate headings inside code
    blocks from structural headings.  Fence pairs with zero heading entries
    add no navigational value and are removed.
    """
    # Identify indices to remove
    remove: set[int] = set()
    opener_idx: int | None = None

    for i, entry in enumerate(entries):
        if entry.is_fence:
            if opener_idx is None:
                # This is an opener
                opener_idx = i
            else:
                # This is a closer — check for headings between opener and closer
                has_headings = any(entries[j].depth is not None for j in range(opener_idx + 1, i))
                if not has_headings:
                    # Mark opener, closer, and everything between for removal
                    for j in range(opener_idx, i + 1):
                        remove.add(j)
                opener_idx = None

    return [e for i, e in enumerate(entries) if i not in remove]


# ---------------------------------------------------------------------------
# Compaction
# ---------------------------------------------------------------------------


def apply_outline_reduction_stage(
    entries: list[OutlineEntry], stage: OutlineReductionStage
) -> list[OutlineEntry]:
    """Apply a single progressive reduction stage to outline entries."""
    if stage == "none":
        return entries
    if stage == "drop_h6":
        return [entry for entry in entries if entry.depth != 6]
    if stage == "drop_h5":
        return [entry for entry in entries if entry.depth != 5]
    if stage == "drop_fenced":
        return [entry for entry in entries if not entry.in_fence and not entry.is_fence]
    if stage == "drop_h4":
        return [entry for entry in entries if entry.depth != 4]
    return [entry for entry in entries if entry.depth != 3]


def iter_outline_reduction_stages(
    entries: list[OutlineEntry],
) -> list[tuple[OutlineReductionStage, list[OutlineEntry]]]:
    """Return entries after each progressive reduction stage.

    The stages are cumulative and ordered exactly as read_page/search_page
    compaction applies them.
    """
    stages: list[tuple[OutlineReductionStage, list[OutlineEntry]]] = [("none", entries)]
    result = entries
    for stage in ("drop_h6", "drop_h5", "drop_fenced", "drop_h4", "drop_h3"):
        result = apply_outline_reduction_stage(result, stage)
        stages.append((stage, result))
    return stages


def compact_outline(
    entries: list[OutlineEntry],
    *,
    max_entries: int = 50,
    max_chars: int = 4000,
) -> list[OutlineEntry] | None:
    """Progressively reduce outline entries to fit within *max_entries* and *max_chars*.

    Both constraints are active: compaction continues until the outline satisfies
    both (entry count ≤ max_entries AND formatted string ≤ max_chars).

    Reduction stages (in order, stopping as soon as both constraints are satisfied):
      1. Remove H6 headings
      2. Remove H5 headings
      3. Remove fenced content (in_fence entries) and their enclosing fence markers
      4. Remove H4 headings
      5. Remove H3 headings

    Returns ``None`` if the outline cannot be reduced to satisfy both constraints
    (only H1/H2 remain and still exceed either limit).
    """
    for _stage, result in iter_outline_reduction_stages(entries):
        if len(result) <= max_entries and _formatted_outline_size(result) <= max_chars:
            return result

    # Irreducible — only H1/H2 remain and still exceed at least one constraint
    return None


def _formatted_outline_size(entries: list[OutlineEntry]) -> int:
    """Return the character count of the formatted outline string."""
    return len(format_outline(entries))


# ---------------------------------------------------------------------------
# Match-range trimming
# ---------------------------------------------------------------------------


def trim_outline_to_range(
    entries: list[OutlineEntry], first_line: int, last_line: int
) -> list[OutlineEntry]:
    """Filter entries to those within the given line range (inclusive)."""
    return [e for e in entries if first_line <= e.line_number <= last_line]


# ---------------------------------------------------------------------------
# Formatting
# ---------------------------------------------------------------------------


def format_outline(entries: list[OutlineEntry]) -> str:
    """Convert structured entries back to the wire format.

    Returns ``"<lineno>:<text>\\n<lineno>:<text>\\n..."``.
    """
    return "\n".join(f"{e.line_number}:{e.text}" for e in entries)


def build_compaction_note(
    entries: list[OutlineEntry],
    total_entries: int,
    *,
    match_range: tuple[int, int] | None = None,
) -> str:
    """Build a human-readable note describing what the compacted outline contains.

    Args:
        entries: The compacted entries (after compaction).
        total_entries: Total entry count before compaction (after fence stripping).
        match_range: Optional ``(first_line, last_line)`` tuple for search_page.

    Returns:
        A bracketed note string, e.g.
        ``[Compacted: showing H1-H3 headings only. ...]``
    """
    # Determine the surviving heading depth range
    depths = sorted({e.depth for e in entries if e.depth is not None})
    if depths:
        if len(depths) > 1:
            depth_desc = f"H{depths[0]}-H{depths[-1]} headings"
        else:
            depth_desc = f"H{depths[0]} headings"
    else:
        depth_desc = "no headings"

    range_desc = ""
    if match_range is not None:
        range_desc = f" in match range (lines {match_range[0]}-{match_range[1]})"

    return f"[Compacted: showing {depth_desc}{range_desc}.]"
