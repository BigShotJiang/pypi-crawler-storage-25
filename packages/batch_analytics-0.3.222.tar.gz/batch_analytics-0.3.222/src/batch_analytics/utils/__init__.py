"""Utilities shared across batch_analytics (e.g. Gluon / AutoGluon helpers)."""
