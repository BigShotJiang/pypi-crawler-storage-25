"""Shared helpers for AutoGluon train/infer Gluon jobs (S3 + table naming)."""

from __future__ import annotations

import os
from pathlib import Path
from typing import Tuple


def parse_s3_uri(uri: str) -> Tuple[str, str]:
    """
    Split ``s3://bucket/key/prefix`` into bucket and key prefix (may be empty).

    The key prefix does not include a leading slash; trailing slashes are preserved on the key side.
    """
    u = (uri or "").strip()
    if not u.startswith("s3://"):
        raise ValueError(f"Not an s3 URI: {uri!r}")
    rest = u[5:]
    if "/" not in rest:
        return rest, ""
    bucket, key = rest.split("/", 1)
    return bucket, key


def clickhouse_full_table(database: str, table: str) -> str:
    """Build ``db.table`` when ``table`` is unqualified."""
    t = (table or "").strip()
    if not t:
        return t
    if "." in t and "'" not in t:
        return t
    db = (database or "").strip() or "default"
    return f"{db}.{t}"


def local_training_dir() -> str:
    return os.environ.get("AUTOGLUON_LOCAL_MODEL_DIR", "/tmp/autogluon_model")


def boto3_client():
    import boto3

    return boto3.client("s3")


def upload_directory_to_s3(local_dir: str, s3_dir_uri: str) -> None:
    """Upload every file under ``local_dir`` to ``s3_dir_uri`` (directory URI, trailing ``/`` optional)."""
    bucket, prefix = parse_s3_uri(s3_dir_uri.rstrip("/") + "/")
    prefix = prefix.rstrip("/")
    if prefix:
        prefix = prefix + "/"
    cli = boto3_client()
    root = Path(local_dir)
    for path in root.rglob("*"):
        if not path.is_file():
            continue
        rel = path.relative_to(root).as_posix()
        key = prefix + rel
        cli.upload_file(str(path), bucket, key)


def download_s3_prefix_to_dir(s3_dir_uri: str, local_dir: str) -> None:
    """Download all objects under the S3 prefix implied by ``s3_dir_uri`` into ``local_dir``."""
    bucket, pfx = parse_s3_uri(s3_dir_uri.rstrip("/") + "/")
    pfx = pfx.rstrip("/")
    if pfx:
        pfx = pfx + "/"
    cli = boto3_client()
    os.makedirs(local_dir, exist_ok=True)
    paginator = cli.get_paginator("list_objects_v2")
    pages = paginator.paginate(Bucket=bucket, Prefix=pfx)
    for page in pages:
        for obj in page.get("Contents") or []:
            key = obj["Key"]
            if key.endswith("/"):
                continue
            rel = key[len(pfx) :] if key.startswith(pfx) else key
            if not rel:
                continue
            dest = Path(local_dir) / rel
            dest.parent.mkdir(parents=True, exist_ok=True)
            cli.download_file(bucket, key, str(dest))
