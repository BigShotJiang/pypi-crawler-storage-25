"""
Batch analytics pipeline: Extract, Transform, Log stages + analytics modules.

PySpark is optional: install ``batch-analytics[spark]``. Gluon image: ``[autogluon]`` only.
"""

from __future__ import annotations

import importlib
from typing import Any

from .config import BatchAnalyticsConfig, SparkK8sConfig

__all__ = [
    "BatchAnalyticsConfig",
    "SparkK8sConfig",
    "expand_kv_blob_column",
    "extract_anchor_id",
    "extract_all",
    "extract_table",
    "extract_unified",
    "parse_extract_filter_values",
    "remove_duplicates",
    "stage_to_clickhouse",
    "transform",
    "transform_and_stage",
    "load_staged",
    "log_run",
    "log_analytics_artifacts",
    "run_pipeline",
    "create_spark_session",
]

# Lazy imports so ``import batch_analytics`` works without PySpark (Gluon image).
_LAZY = {
    "expand_kv_blob_column": ("transform", "expand_kv_blob_column"),
    "extract_anchor_id": ("transform", "extract_anchor_id"),
    "extract_all": ("extract", "extract_all"),
    "extract_table": ("extract", "extract_table"),
    "extract_unified": ("extract", "extract_unified"),
    "parse_extract_filter_values": ("extract", "parse_extract_filter_values"),
    "remove_duplicates": ("transform", "remove_duplicates"),
    "stage_to_clickhouse": ("transform", "stage_to_clickhouse"),
    "transform": ("transform", "transform"),
    "transform_and_stage": ("transform", "transform_and_stage"),
    "load_staged": ("transform", "load_staged"),
    "log_run": ("log", "log_run"),
    "log_analytics_artifacts": ("log", "log_analytics_artifacts"),
    "run_pipeline": ("job_runner", "run_pipeline"),
    "create_spark_session": ("job_runner", "create_spark_session"),
}


def __getattr__(name: str) -> Any:
    if name in _LAZY:
        mod_name, attr = _LAZY[name]
        mod = importlib.import_module(f".{mod_name}", __name__)
        return getattr(mod, attr)
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")


def __dir__() -> list[str]:
    return sorted({*__all__, *globals().keys()})
