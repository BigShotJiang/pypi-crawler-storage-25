"""
Log stage: Persist run metadata, metrics, and analytics results for audit and debugging.
"""

import json
import logging
from datetime import datetime
from pathlib import Path
from typing import List, Optional, Union

from pyspark.sql import SparkSession

logger = logging.getLogger(__name__)


def log_run(
    run_id: str,
    stage: str,
    metrics: dict,
    output_dir: Optional[Union[str, Path]] = None,
    extra: Optional[dict] = None,
) -> Path:
    """
    Write run log (metadata + metrics) to a JSON file.
    Returns the path of the written file.
    """
    output_dir = Path(output_dir) if output_dir else Path("/tmp/analytics_logs")
    output_dir.mkdir(parents=True, exist_ok=True)

    log_data = {
        "run_id": run_id,
        "stage": stage,
        "timestamp": datetime.utcnow().isoformat() + "Z",
        "metrics": metrics,
        **(extra or {}),
    }

    log_file = output_dir / f"{run_id}_{stage}.json"
    with open(log_file, "w") as f:
        json.dump(log_data, f, indent=2)

    logger.info("Logged %s to %s", stage, log_file)
    return log_file


def log_dataframe_summary(
    spark: SparkSession,
    df_name: str,
    df,
) -> dict:
    """Produce a summary dict for a DataFrame (row count, schema snippet)."""
    count = df.count()
    schema = [f.name for f in df.schema.fields[:20]]  # first 20 columns
    if len(df.schema.fields) > 20:
        schema.append("...")
    return {
        "name": df_name,
        "row_count": count,
        "column_count": len(df.schema.fields),
        "columns": schema,
    }


def log_analytics_artifacts(
    run_id: str,
    artifacts: dict,
    output_dir: Union[str, Path],
) -> List[Path]:
    """
    Write analytics module outputs (e.g. slopes, correlation matrix, PCA loadings)
    to JSON files in the log directory.
    """
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    paths: List[Path] = []
    for name, data in artifacts.items():
        path = output_dir / f"{run_id}_analytics_{name}.json"
        with open(path, "w") as f:
            json.dump(_serialize_for_json(data), f, indent=2)
        paths.append(path)

    return paths


def _serialize_for_json(obj):
    """Convert numpy/Python types to JSON-serializable forms."""
    import numpy as np

    if isinstance(obj, dict):
        return {k: _serialize_for_json(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [_serialize_for_json(x) for x in obj]
    if isinstance(obj, np.ndarray):
        return obj.tolist()
    if isinstance(obj, (np.floating, np.float32, np.float64)):
        return float(obj)
    if isinstance(obj, (np.integer, np.int32, np.int64)):
        return int(obj)
    if isinstance(obj, np.bool_):
        return bool(obj)
    return obj
