"""
Extract stage: Load data from ClickHouse using Spark ClickHouse connector or JDBC.
"""

import json
import logging
import os
from typing import Dict, List, Optional, Tuple

from pyspark.sql import DataFrame, SparkSession
from pyspark.sql.functions import col

from .config import BatchAnalyticsConfig

logger = logging.getLogger(__name__)


def parse_extract_filter_values(raw: str) -> List[str]:
    """
    Parse BATCH_EXTRACT_FILTER_VALUES: comma-separated tokens, or JSON array string.

    Examples:
      a,b,c -> ["a","b","c"]
      ["GP/A","GP/B"] -> JSON list (values may contain commas)
    """
    text = (raw or "").strip()
    if not text:
        return []
    if text.startswith("["):
        try:
            data = json.loads(text)
            if isinstance(data, list):
                out = [str(x).strip() for x in data if str(x).strip()]
                return out
        except json.JSONDecodeError:
            logger.warning("BATCH_EXTRACT_FILTER_VALUES looks like JSON but failed to parse; using comma split")
    return [p.strip() for p in text.split(",") if p.strip()]


def _apply_extract_filter(df: DataFrame, config: BatchAnalyticsConfig) -> DataFrame:
    """Apply col IN (values) when filter_column is set; empty column = no filter."""
    col_name = (config.extract.filter_column or "").strip()
    if not col_name:
        return df
    if col_name not in df.columns:
        logger.warning(
            "BATCH_EXTRACT_FILTER_COLUMN=%r not in extracted columns %s; skipping filter",
            col_name,
            df.columns,
        )
        return df
    values = parse_extract_filter_values(config.extract.filter_values)
    if not values:
        logger.warning(
            "BATCH_EXTRACT_FILTER_COLUMN=%r set but BATCH_EXTRACT_FILTER_VALUES is empty; skipping IN filter",
            col_name,
        )
        return df
    filtered = df.filter(col(col_name).isin(values))
    return filtered


def _parse_ch_database_table(table: str, default_database: str) -> Tuple[str, str]:
    """
    Resolve ``table`` reference to (database, table_name).

    ``batch_metric_facts`` → (default_database, batch_metric_facts)
    ``analytics.batch_metric_facts`` → (analytics, batch_metric_facts)
    """
    t = (table or "").strip()
    if not t:
        return default_database, t
    if "." in t and not t.startswith("("):
        db, tbl = t.split(".", 1)
        db, tbl = db.strip(), tbl.strip()
        if db and tbl:
            return db, tbl
    return default_database, t


def _read_via_catalog(spark: SparkSession, cfg: BatchAnalyticsConfig, table: str) -> Optional[DataFrame]:
    """
    Read via Spark SQL catalog (ClickHouseCatalog), registered in job_runner.create_spark_session.

    clickhouse-spark-runtime does **not** register legacy short name ``format(\"clickhouse\")`` /
    ``clickhouse.DefaultSource``; catalog + ``spark.table(catalog.db.table)`` is the supported path.
    """
    cat = os.environ.get("BATCH_CLICKHOUSE_CATALOG", "batch_ch").strip()
    if not cat:
        return None
    db, tbl = _parse_ch_database_table(table, cfg.clickhouse.database)
    ident = f"{cat}.{db}.{tbl}"
    try:
        return spark.table(ident)
    except Exception as e:
        logger.warning(
            "Catalog read failed for %s (%s): %s. Trying other readers.",
            ident,
            table,
            e,
        )
        return None


def _read_via_format(spark: SparkSession, cfg: BatchAnalyticsConfig, table: str) -> Optional[DataFrame]:
    """
    Read from ClickHouse using the native format API (clickhouse-spark-runtime).
    Requires: com.clickhouse.spark:clickhouse-spark-runtime in spark.jars.packages
    """
    try:
        rd = (
            spark.read.format("clickhouse")
            .option("host", cfg.clickhouse.host)
            .option("protocol", cfg.clickhouse.protocol)
            .option("http_port", str(cfg.clickhouse.port))
            .option("database", cfg.clickhouse.database)
            .option("table", table)
            .option("user", cfg.clickhouse.user)
        )
        if cfg.clickhouse.password:
            rd = rd.option("password", cfg.clickhouse.password)
        df = rd.load()
        return df
    except Exception as e:
        logger.warning(
            "Native ClickHouse connector failed for table %s: %s. Falling back to JDBC.",
            table,
            e,
        )
        return None


def _read_via_jdbc(spark: SparkSession, cfg: BatchAnalyticsConfig, table: str) -> DataFrame:
    """Read from ClickHouse via JDBC."""
    return spark.read.jdbc(
        cfg.clickhouse.jdbc_url,
        table,
        properties=cfg.clickhouse.jdbc_properties,
    )


def extract_table(
    spark: SparkSession,
    table: str,
    config: BatchAnalyticsConfig,
) -> DataFrame:
    """
    Extract a single table from ClickHouse.
    Uses native connector if configured, otherwise JDBC.
    """
    if config.extract.use_native_connector:
        # Prefer catalog (matches clickhouse-spark-runtime); avoid legacy DefaultSource path.
        df = _read_via_catalog(spark, config, table)
        if df is None:
            df = _read_via_format(spark, config, table)
        if df is None:
            df = _read_via_jdbc(spark, config, table)
    else:
        df = _read_via_jdbc(spark, config, table)

    df = _apply_extract_filter(df, config)
    logger.info("Extracted table %s: %d rows", table, df.count())
    return df


def extract_all(
    spark: SparkSession,
    config: BatchAnalyticsConfig,
) -> Dict[str, DataFrame]:
    """
    Extract all configured source tables from ClickHouse.
    Returns a dict mapping table name to DataFrame.
    """
    tables = [t.strip() for t in config.extract.source_tables.split(",") if t.strip()]
    if not tables:
        raise ValueError("No source tables configured in BATCH_SOURCE_TABLES")

    result: Dict[str, DataFrame] = {}
    for table in tables:
        df = extract_table(spark, table, config)
        result[table] = df

    return result


def extract_unified(
    spark: SparkSession,
    config: BatchAnalyticsConfig,
    join_keys: Optional[List[str]] = None,
    primary_table: Optional[str] = None,
) -> DataFrame:
    """
    Extract and unify source tables into one DataFrame.
    - Single table: returns it directly.
    - Multiple tables + join_keys: joins on those keys (left join, first table base).
    - Multiple tables, no join_keys: returns the primary (or first) table.
      Use primary_table to choose which table to use for analytics.
    """
    all_dfs = extract_all(spark, config)

    if len(all_dfs) == 1:
        return list(all_dfs.values())[0]

    if join_keys:
        dfs = list(all_dfs.values())
        base = dfs[0]
        for other in dfs[1:]:
            base = base.join(other, on=join_keys, how="left")
        return base

    # Multiple tables, no join: use primary or first
    if primary_table and primary_table in all_dfs:
        return all_dfs[primary_table]
    return list(all_dfs.values())[0]
