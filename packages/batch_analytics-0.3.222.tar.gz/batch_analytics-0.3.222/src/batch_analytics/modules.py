"""
Module registry for batch analytics. Maps --modules short names to run functions.

Must stay in sync with analytics_runner catalog module_arg for each Spark method.
See analytics_runner/catalog/analytics_catalog.yaml.
"""

from .analytics import (
    run_linear_regression,
    run_correlation,
    run_pca_clustering,
    run_t_test,
)

# module_arg -> (run_fn, result_key)
MODULE_REGISTRY = {
    "lr": (run_linear_regression, "linear_regression"),
    "corr": (run_correlation, "correlation"),
    "pca": (run_pca_clustering, "pca_clustering"),
    "ttest": (run_t_test, "t_test"),
}

VALID_MODULES = list(MODULE_REGISTRY.keys())
DEFAULT_MODULES = VALID_MODULES.copy()
