"""
Transform stage: Clean data (remove duplicates), expand JSON/KV blob column, and stage.
"""

import ast
import json
import logging
import os
import re
from typing import Any, Dict, List, Optional, Sequence, Set

from pyspark.sql import DataFrame, SparkSession
from pyspark.sql.functions import col, explode, map_keys, udf
from pyspark.sql.types import MapType, StringType

from .config import BatchAnalyticsConfig

logger = logging.getLogger(__name__)


def _stringify_leaf(v: Any) -> str:
    if v is None:
        return ""
    if isinstance(v, (dict, list)):
        return json.dumps(v, separators=(",", ":"))
    return str(v)


def parse_blob_to_strmap(s: Any) -> Dict[str, str]:
    """
    Parse a cell value into a flat string map (top-level keys only).

    Accepts standard JSON objects or Python repr dicts (e.g. single-quoted).
    Non-dict / unparsable input yields an empty map.
    """
    if s is None:
        return {}
    text = str(s).strip()
    if not text:
        return {}
    obj: Any = None
    try:
        obj = json.loads(text)
    except json.JSONDecodeError:
        pass
    if obj is None:
        try:
            obj = ast.literal_eval(text)
        except (ValueError, SyntaxError, MemoryError):
            return {}
    if not isinstance(obj, dict):
        return {}
    out: Dict[str, str] = {}
    for k, v in obj.items():
        key = str(k).strip()
        if not key:
            continue
        out[key] = _stringify_leaf(v)
    return out


def _spark_safe_base_name(key: str) -> str:
    """Sanitize JSON key to a usable Spark column name."""
    s = re.sub(r"[^0-9a-zA-Z_]", "_", key.strip())
    s = re.sub(r"_+", "_", s).strip("_")
    if not s:
        return "kv_key"
    if s[0].isdigit():
        s = "c_" + s
    return s


def _unique_column_name(base: str, used: Set[str]) -> str:
    name = base
    n = 1
    while name in used:
        n += 1
        name = f"{base}_{n}"
    used.add(name)
    return name


def expand_kv_blob_column(
    df: DataFrame,
    config: BatchAnalyticsConfig,
) -> DataFrame:
    """
    Parse the configured blob column into top-level key/value pairs and add one String column per key.

    No per-key user configuration: every distinct key observed in the column (across the dataset)
    becomes a column; values are strings (nested dict/list serialized as JSON). Empty / null cells
    yield nulls in those columns.

    Source column: ``config.transform.add_dimension_column`` (env ``BATCH_ADD_DIMENSION_COLUMN``).
    """
    col_name = config.transform.add_dimension_column
    if col_name not in df.columns:
        logger.debug("KV blob column %r not found, skipping expansion", col_name)
        return df

    parse_udf = udf(parse_blob_to_strmap, MapType(StringType(), StringType()))
    with_map = df.withColumn("_kv_blob_map", parse_udf(col(col_name)))

    key_rows = (
        with_map.select(explode(map_keys(col("_kv_blob_map"))).alias("_k"))
        .where(col("_k").isNotNull())
        .distinct()
        .collect()
    )
    all_keys: List[str] = sorted({str(r._k).strip() for r in key_rows if r._k and str(r._k).strip()})

    if not all_keys:
        logger.info("No keys found in KV blob column %r; dropping temporary map only", col_name)
        return with_map.drop("_kv_blob_map")

    used: Set[str] = set(with_map.columns)
    out = with_map
    added: List[str] = []
    for k in all_keys:
        base = _spark_safe_base_name(k)
        target = _unique_column_name(base, used)
        added.append(target)
        out = out.withColumn(target, col("_kv_blob_map").getItem(k))

    out = out.drop("_kv_blob_map")
    logger.info(
        "Expanded KV blob column %r into %d columns: %s",
        col_name,
        len(added),
        ", ".join(added),
    )
    return out


def extract_anchor_id(
    df: DataFrame,
    config: BatchAnalyticsConfig,
) -> DataFrame:
    """Backward-compatible name: expands all keys from the blob column (not only ``anchor_id``)."""
    return expand_kv_blob_column(df, config)


def remove_duplicates(
    df: DataFrame,
    key_columns: Optional[Sequence[str]] = None,
) -> DataFrame:
    """
    Remove duplicate rows.
    If key_columns is provided, keeps first occurrence per key.
    Otherwise, drops exact row duplicates.
    """
    before_count = df.count()
    if key_columns:
        df_cleaned = df.dropDuplicates(key_columns)
    else:
        df_cleaned = df.distinct()
    after_count = df_cleaned.count()
    removed = before_count - after_count
    logger.info(
        "Deduplication: %d -> %d rows (removed %d duplicates)",
        before_count,
        after_count,
        removed,
    )
    return df_cleaned


def transform(
    df: DataFrame,
    config: BatchAnalyticsConfig,
) -> DataFrame:
    """
    Apply transformation only: (1) expand JSON/KV blob column into one column per top-level key,
    (2) deduplicate by BATCH_DEDUP_COLUMNS if set, else by full row.
    Does not write anywhere. Use stage_to_clickhouse() separately to persist.
    """
    transformed = expand_kv_blob_column(df, config)
    dedup_cols = (
        [c.strip() for c in config.transform.dedup_columns.split(",") if c.strip()]
        if config.transform.dedup_columns
        else None
    )
    return remove_duplicates(transformed, key_columns=dedup_cols)


def _normalize_staging_write_mode(raw: str) -> str:
    """Spark DataFrameWriter mode: overwrite (replace table contents) or append."""
    m = (raw or "overwrite").strip().lower()
    if m in ("overwrite", "append"):
        return m
    logger.warning("Invalid BATCH_STAGING_WRITE_MODE=%r; using overwrite", raw)
    return "overwrite"


def stage_to_clickhouse(
    spark: SparkSession,
    df: DataFrame,
    config: BatchAnalyticsConfig,
) -> None:
    """
    Write transformed data to ClickHouse staging table.
    Separate job from transform; must complete before analytics can run.
    Uses native connector if available, else JDBC.
    Write mode from BATCH_STAGING_WRITE_MODE (default overwrite = full replace).
    """
    n = df.count()
    mode = _normalize_staging_write_mode(config.transform.staging_write_mode)
    try:
        ch = config.clickhouse
        writer = (
            df.write.format("clickhouse")
            .option("host", ch.host)
            .option("protocol", ch.protocol)
            .option("http_port", str(ch.port))
            .option("database", ch.database)
            .option("table", config.transform.staging_table)
            .option("user", ch.user)
            .mode(mode)
        )
        if ch.password:
            writer = writer.option("password", ch.password)
        writer.save()
    except Exception as e:
        logger.warning("ClickHouse connector failed (%s), using JDBC", e)
        df.write.jdbc(
            config.clickhouse.jdbc_url,
            config.transform.staging_table,
            mode=mode,
            properties=config.clickhouse.jdbc_properties,
        )
    logger.info(
        "Staged data to ClickHouse %s.%s (%d rows)",
        config.clickhouse.database,
        config.transform.staging_table,
        n,
    )


def stage_to_path(
    spark: SparkSession,
    df: DataFrame,
    config: BatchAnalyticsConfig,
) -> None:
    """Write transformed data to parquet/delta (for local dev or intermediate storage)."""
    path = config.transform.staging_path
    fmt = config.transform.staging_format
    mode = _normalize_staging_write_mode(config.transform.staging_write_mode)
    if fmt == "parquet":
        df.write.mode(mode).parquet(path)
        logger.info("Staged data to %s (parquet)", path)
    elif fmt == "delta":
        df.write.format("delta").mode(mode).save(path)
        logger.info("Staged data to %s (delta)", path)
    else:
        df.write.format(fmt).mode(mode).save(path)
        logger.info("Staged data to %s (%s)", path, fmt)


def transform_and_stage(
    spark: SparkSession,
    df: DataFrame,
    config: BatchAnalyticsConfig,
) -> DataFrame:
    """
    Transform and stage to ClickHouse. Kept for backward compatibility.
    Prefer calling transform() then stage_to_clickhouse() separately.
    """
    cleaned = transform(df, config)
    stage_to_clickhouse(spark, cleaned, config)
    return cleaned


def load_staged(
    spark: SparkSession,
    config: BatchAnalyticsConfig,
) -> DataFrame:
    """
    Load previously staged data (e.g. when running only analytics modules).
    """
    staging_path = config.transform.staging_path
    fmt = config.transform.staging_format

    if fmt == "parquet":
        return spark.read.parquet(staging_path)
    if fmt == "delta":
        return spark.read.format("delta").load(staging_path)
    if fmt == "clickhouse":
        ch = config.clickhouse
        tbl = config.transform.staging_table
        cat = os.environ.get("BATCH_CLICKHOUSE_CATALOG", "batch_ch").strip()
        if cat:
            try:
                return spark.table(f"{cat}.{ch.database}.{tbl}")
            except Exception as e:
                logger.warning(
                    "load_staged: catalog table %s.%s.%s failed (%s), using JDBC",
                    cat,
                    ch.database,
                    tbl,
                    e,
                )
        dbtable = f"(SELECT * FROM `{ch.database}`.`{tbl}`) AS _stg"
        return spark.read.jdbc(
            ch.jdbc_url,
            dbtable,
            properties=ch.jdbc_properties,
        )
    return spark.read.format(fmt).load(staging_path)
