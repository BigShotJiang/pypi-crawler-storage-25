"""
Module 3: PCA for key feature identification and clustering on staged data.
"""

import logging
from typing import Any, Dict, List

from pyspark.ml.clustering import KMeans
from pyspark.ml.feature import PCA, StandardScaler, VectorAssembler
from pyspark.sql import DataFrame, SparkSession

from ..config import BatchAnalyticsConfig

logger = logging.getLogger(__name__)


def run_pca_clustering(
    spark: SparkSession,
    df: DataFrame,
    config: BatchAnalyticsConfig,
) -> Dict[str, Any]:
    """
    Run PCA to identify key features (principal components) and KMeans clustering.
    Uses scaled features; PCA components capture variance; clustering groups similar rows.

    Returns:
        - pca: explained variance, cumulative variance, feature loadings per PC
        - clustering: cluster assignments, centroids, sizes
    """
    feature_cols = [
        c.strip()
        for c in config.analytics.pca_features.split(",")
        if c.strip()
    ]

    if not feature_cols:
        feature_cols = [
            f.name
            for f in df.schema.fields
            if "double" in str(f.dataType).lower()
            or "int" in str(f.dataType).lower()
            or "long" in str(f.dataType).lower()
            or "float" in str(f.dataType).lower()
        ]
        logger.info("Auto-selected %d numeric columns for PCA/clustering", len(feature_cols))

    missing = [c for c in feature_cols if c not in df.columns]
    if missing:
        raise ValueError(
            f"PCA features not found: {missing}. Available: {df.columns[:15]}..."
        )

    if len(feature_cols) < 2:
        return {
            "pca": {"explained_variance": [1.0], "feature_names": feature_cols},
            "clustering": {"k": config.analytics.cluster_k, "sizes": []},
        }

    from pyspark.sql.functions import col
    from pyspark.sql.types import DoubleType

    df_num = df.select(
        *[col(c).cast(DoubleType()).alias(c) for c in feature_cols]
    ).dropna()

    assembler = VectorAssembler(
        inputCols=feature_cols,
        outputCol="features_raw",
        handleInvalid="skip",
    )
    df_vec = assembler.transform(df_num)

    scaler = StandardScaler(
        inputCol="features_raw",
        outputCol="features",
        withStd=True,
        withMean=True,
    )
    scaler_model = scaler.fit(df_vec)
    df_scaled = scaler_model.transform(df_vec)

    # PCA - keep enough components for target variance
    variance_threshold = config.analytics.pca_variance_threshold
    n_comp_max = min(len(feature_cols), 20)
    pca = PCA(k=n_comp_max, inputCol="features", outputCol="pca_features")
    pca_model = pca.fit(df_scaled)
    df_pca = pca_model.transform(df_scaled)

    explained = pca_model.explainedVariance.toArray().tolist()
    cumsum = []
    s = 0.0
    for v in explained:
        s += v
        cumsum.append(s)

    # Feature loadings per PC (which original features contribute most)
    components = pca_model.pc.toArray()
    loadings: List[dict] = []
    for i, comp in enumerate(components):
        ranked = sorted(
            zip(feature_cols, comp.tolist()),
            key=lambda x: abs(x[1]),
            reverse=True,
        )
        loadings.append({
            "pc": i + 1,
            "top_features": [{"name": n, "loading": float(v)} for n, v in ranked[:5]],
        })

    k = config.analytics.cluster_k
    kmeans = KMeans(k=k, seed=42, featuresCol="pca_features", predictionCol="cluster")
    kmeans_model = kmeans.fit(df_pca)

    df_clustered = kmeans_model.transform(df_pca)
    cluster_sizes = (
        df_clustered.groupBy("cluster")
        .count()
        .orderBy("cluster")
        .collect()
    )
    sizes = {int(r["cluster"]): int(r["count"]) for r in cluster_sizes}

    centroids = []
    for i in range(k):
        c = kmeans_model.clusterCenters()[i]
        centroids.append({"cluster": i, "centroid": c.tolist()})

    return {
        "pca": {
            "explained_variance": explained,
            "cumulative_variance": cumsum,
            "feature_names": feature_cols,
            "component_loadings": loadings,
            "n_components": len(explained),
        },
        "clustering": {
            "k": k,
            "sizes": sizes,
            "centroids": centroids,
            "within_cluster_sum_of_squared_distances": float(
                kmeans_model.summary.trainingCost
            ),
        },
    }
