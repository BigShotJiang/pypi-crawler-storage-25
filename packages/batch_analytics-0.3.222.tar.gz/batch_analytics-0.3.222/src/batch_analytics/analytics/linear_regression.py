"""
Module 1: Simple linear regression on XY data with slope comparison across groups.
"""

import logging
from typing import Any, Dict

from pyspark.ml.feature import VectorAssembler
from pyspark.ml.regression import LinearRegression
from pyspark.sql import DataFrame, SparkSession
from pyspark.sql.functions import col, concat_ws
from pyspark.sql.types import DoubleType

from ..config import BatchAnalyticsConfig

logger = logging.getLogger(__name__)


def _ensure_numeric(df: DataFrame, x_col: str, y_col: str) -> DataFrame:
    """Cast X and Y columns to double."""
    return df.select(
        col(x_col).cast(DoubleType()).alias(x_col),
        col(y_col).cast(DoubleType()).alias(y_col),
        *[c for c in df.columns if c not in (x_col, y_col)],
    ).filter(col(x_col).isNotNull() & col(y_col).isNotNull())


def run_linear_regression(
    spark: SparkSession,
    df: DataFrame,
    config: BatchAnalyticsConfig,
) -> Dict[str, Any]:
    """
    Run simple linear regression: Y ~ X.
    If group columns are configured, fit separate models per group and compare slopes.

    Returns:
        - slopes: per-group slope and intercept
        - global: single regression over all data
        - slope_comparison: pairwise slope differences (when multiple groups)
    """
    x_col = config.analytics.lr_x_column
    y_col = config.analytics.lr_y_column
    group_cols = [
        c.strip()
        for c in config.analytics.lr_group_columns.split(",")
        if c.strip()
    ]

    # Ensure required columns exist
    if x_col not in df.columns or y_col not in df.columns:
        numeric_cols = [f.name for f in df.schema.fields if "double" in str(f.dataType).lower() or "int" in str(f.dataType).lower()]
        if len(numeric_cols) >= 2:
            x_col = numeric_cols[0]
            y_col = numeric_cols[1]
            logger.warning(
                "LR columns not found, using first two numeric: %s, %s",
                x_col,
                y_col,
            )
        else:
            raise ValueError(
                f"Could not find LR columns (x={x_col}, y={y_col}). "
                "Specify BATCH_LR_X_COLUMN and BATCH_LR_Y_COLUMN."
            )

    df = _ensure_numeric(df, x_col, y_col)

    assembler = VectorAssembler(inputCols=[x_col], outputCol="features", handleInvalid="skip")
    df_vec = assembler.transform(df).withColumnRenamed(y_col, "label")

    # Global regression (all data)
    lr = LinearRegression(featuresCol="features", labelCol="label")
    global_model = lr.fit(df_vec)
    global_slope = float(global_model.coefficients[0])
    global_intercept = float(global_model.intercept)
    global_r2 = float(global_model.summary.r2)

    result: Dict[str, Any] = {
        "global": {
            "slope": global_slope,
            "intercept": global_intercept,
            "r2": global_r2,
        },
        "slopes": {},
        "slope_comparison": [],
    }

    if not group_cols or not all(g in df.columns for g in group_cols):
        return result

    # Per-group regression
    group_key = "_group_key"
    df_grouped = df_vec.withColumn(
        group_key,
        concat_ws("|", *[col(g).cast("string") for g in group_cols]),
    )
    groups = df_grouped.select(group_key).distinct().collect()

    slopes_by_group: Dict[str, dict] = {}
    for row in groups:
        key_str = row[group_key]
        if key_str is None:
            continue
        key_parts = key_str.split("|")

        sub_df = df_grouped.filter(col(group_key) == key_str).drop(group_key)
        if sub_df.count() < 2:
            continue

        model = lr.fit(sub_df)
        slopes_by_group[key_str] = {
            "slope": float(model.coefficients[0]),
            "intercept": float(model.intercept),
            "r2": float(model.summary.r2),
            "n": sub_df.count(),
            "group": dict(zip(group_cols, key_parts)),
        }

    result["slopes"] = slopes_by_group

    # Slope comparison: pairwise differences
    keys = list(slopes_by_group.keys())
    for i in range(len(keys)):
        for j in range(i + 1, len(keys)):
            s1 = slopes_by_group[keys[i]]["slope"]
            s2 = slopes_by_group[keys[j]]["slope"]
            result["slope_comparison"].append({
                "group_a": keys[i],
                "group_b": keys[j],
                "slope_a": s1,
                "slope_b": s2,
                "slope_diff": s1 - s2,
            })

    return result
