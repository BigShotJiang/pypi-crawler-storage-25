"""
Module 2: Multi-feature correlation analysis.
"""

import logging
from typing import Any, Dict, List

from pyspark.ml.feature import VectorAssembler
from pyspark.ml.stat import Correlation
from pyspark.sql import DataFrame, SparkSession

from ..config import BatchAnalyticsConfig

logger = logging.getLogger(__name__)


def run_correlation(
    spark: SparkSession,
    df: DataFrame,
    config: BatchAnalyticsConfig,
) -> Dict[str, Any]:
    """
    Compute correlation matrix over multiple numeric features.
    Optionally identify pairs above a threshold (collinearity).

    Returns:
        - correlation_matrix: full matrix (list of lists)
        - feature_names: column order
        - high_corr_pairs: pairs with |corr| >= threshold
        - threshold: used threshold
    """
    feature_cols = [
        c.strip()
        for c in config.analytics.corr_features.split(",")
        if c.strip()
    ]

    if not feature_cols:
        # Auto-select numeric columns
        feature_cols = [
            f.name
            for f in df.schema.fields
            if "double" in str(f.dataType).lower()
            or "int" in str(f.dataType).lower()
            or "long" in str(f.dataType).lower()
            or "float" in str(f.dataType).lower()
        ]
        logger.info("Auto-selected %d numeric columns for correlation", len(feature_cols))

    missing = [c for c in feature_cols if c not in df.columns]
    if missing:
        raise ValueError(
            f"Correlation features not found: {missing}. "
            f"Available: {df.columns[:15]}..."
        )

    if len(feature_cols) < 2:
        return {
            "correlation_matrix": [[1.0]],
            "feature_names": feature_cols,
            "high_corr_pairs": [],
            "threshold": config.analytics.corr_threshold,
        }

    # Cast to double and drop nulls
    from pyspark.sql.functions import col
    from pyspark.sql.types import DoubleType

    df_num = df.select(
        *[col(c).cast(DoubleType()).alias(c) for c in feature_cols]
    ).dropna()

    assembler = VectorAssembler(
        inputCols=feature_cols,
        outputCol="features",
        handleInvalid="skip",
    )
    df_vec = assembler.transform(df_num)

    corr_matrix = Correlation.corr(df_vec, "features", "pearson")
    corr_row = corr_matrix.head()
    if corr_row is None:
        return {
            "correlation_matrix": [],
            "feature_names": feature_cols,
            "high_corr_pairs": [],
            "threshold": config.analytics.corr_threshold,
        }

    import numpy as np

    arr = corr_row[0].toArray()
    matrix = np.asarray(arr)

    threshold = config.analytics.corr_threshold
    high_pairs: List[dict] = []
    n = len(feature_cols)
    for i in range(n):
        for j in range(i + 1, n):
            val = float(matrix[i, j])
            if abs(val) >= threshold:
                high_pairs.append({
                    "feature_a": feature_cols[i],
                    "feature_b": feature_cols[j],
                    "correlation": val,
                })

    return {
        "correlation_matrix": matrix.tolist(),
        "feature_names": feature_cols,
        "high_corr_pairs": high_pairs,
        "threshold": threshold,
    }
