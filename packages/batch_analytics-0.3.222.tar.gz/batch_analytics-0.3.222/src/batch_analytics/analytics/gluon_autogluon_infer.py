"""
Load AutoGluon TabularPredictor from S3; score ClickHouse rows; write predictions to output.

Env: CLICKHOUSE_*, BATCH_STAGING_TABLE (inference feature table), MODEL_S3_PREFIX,
  OUTPUT_TYPE (from OutputConfig.type), OUTPUT_CLICKHOUSE_DATABASE, OUTPUT_CLICKHOUSE_TABLE (clickhouse),
  OUTPUT_CLICKHOUSE_AUTO_CREATE (optional; default true when unset — CREATE TABLE IF NOT EXISTS for clickhouse),
  or OUTPUT_S3_PATH (s3 parquet)
"""

from __future__ import annotations

import logging
import os
import shutil
import sys
import tempfile

import clickhouse_connect
import pandas as pd

try:
    from batch_analytics.utils.gluon_autogluon_common import (
        clickhouse_full_table,
        download_s3_prefix_to_dir,
        parse_s3_uri,
    )
except ImportError:
    _pkg_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    if _pkg_root not in sys.path:
        sys.path.insert(0, _pkg_root)
    from utils.gluon_autogluon_common import (  # noqa: E402
        clickhouse_full_table,
        download_s3_prefix_to_dir,
        parse_s3_uri,
    )

logging.basicConfig(level=logging.INFO, format="%(levelname)s %(message)s")
logger = logging.getLogger(__name__)


def _env_truthy(name: str, *, default: bool) -> bool:
    raw = (os.environ.get(name) or "").strip().lower()
    if not raw:
        return default
    return raw in ("1", "true", "yes", "on")


def _sql_ident(name: str) -> str:
    return "`" + str(name).replace("`", "``") + "`"


def _pandas_col_ch_type(series: pd.Series) -> str:
    """Map a pandas column to ClickHouse; Nullable(...) when the column has nulls."""
    try:
        kind = series.dtype.kind
    except AttributeError:
        kind = "O"
    if kind == "b":
        base = "Bool"
    elif kind == "i":
        sz = getattr(series.dtype, "itemsize", 8) or 8
        base = {1: "Int8", 2: "Int16", 4: "Int32", 8: "Int64"}.get(sz, "Int64")
    elif kind == "u":
        sz = getattr(series.dtype, "itemsize", 8) or 8
        base = {1: "UInt8", 2: "UInt16", 4: "UInt32", 8: "UInt64"}.get(sz, "UInt64")
    elif kind == "f":
        sz = getattr(series.dtype, "itemsize", 8) or 8
        base = "Float32" if sz <= 4 else "Float64"
    elif kind == "M":
        base = "DateTime64(3)"
    else:
        base = "String"
    if series.isna().any():
        return f"Nullable({base})"
    return base


def _ensure_clickhouse_output_table(client, database: str, table: str, out_df: pd.DataFrame) -> None:
    col_defs = []
    for col in out_df.columns:
        col_defs.append(f"  {_sql_ident(col)} {_pandas_col_ch_type(out_df[col])}")
    body = ",\n".join(col_defs)
    fq = f"{_sql_ident(database)}.{_sql_ident(table)}"
    ddl = f"CREATE TABLE IF NOT EXISTS {fq} (\n{body}\n) ENGINE = MergeTree ORDER BY tuple()"
    logger.info("Ensuring ClickHouse output table exists: %s.%s", database, table)
    client.command(ddl)


def _require(name: str) -> str:
    v = os.environ.get(name, "").strip()
    if not v:
        logger.error("Missing required env var: %s", name)
        sys.exit(2)
    return v


def main() -> None:
    model_prefix = _require("MODEL_S3_PREFIX")
    out_type = os.environ.get("OUTPUT_TYPE", "clickhouse").strip().lower()
    if out_type not in ("clickhouse", "s3"):
        logger.error("OUTPUT_TYPE must be clickhouse or s3, got %r", out_type)
        sys.exit(2)

    host = _require("CLICKHOUSE_HOST")
    port = int(os.environ.get("CLICKHOUSE_HTTP_PORT", "8123"))
    database = os.environ.get("CLICKHOUSE_DB", "default").strip() or "default"
    user = os.environ.get("CLICKHOUSE_USER", "default")
    password = os.environ.get("CLICKHOUSE_PASSWORD", "")
    inference_table = _require("BATCH_STAGING_TABLE")
    full_table = clickhouse_full_table(database, inference_table)

    sql = f"SELECT * FROM {full_table}"
    logger.info("Loading rows to score: %s", sql)
    client = clickhouse_connect.get_client(
        host=host,
        port=port,
        username=user,
        password=password or None,
        database=database,
    )
    df = client.query_df(sql)
    if df.empty:
        logger.warning("Inference input is empty; nothing to write")
        return

    try:
        from autogluon.tabular import TabularPredictor
    except ImportError:
        logger.exception("autogluon is not installed; use pip install 'batch-analytics[autogluon]'")
        sys.exit(4)

    local_model = tempfile.mkdtemp(prefix="ag_infer_")
    try:
        logger.info("Downloading model from %s", model_prefix)
        download_s3_prefix_to_dir(model_prefix, local_model)
        predictor = TabularPredictor.load(local_model)
        y_pred = predictor.predict(df)
        out_df = df.copy()
        out_df["prediction"] = pd.Series(y_pred, index=df.index)

        if out_type == "clickhouse":
            odb = _require("OUTPUT_CLICKHOUSE_DATABASE")
            otbl = _require("OUTPUT_CLICKHOUSE_TABLE")
            out_full = clickhouse_full_table(odb, otbl)
            if _env_truthy("OUTPUT_CLICKHOUSE_AUTO_CREATE", default=True):
                _ensure_clickhouse_output_table(client, odb, otbl, out_df)
            logger.info("Inserting %s rows into %s", len(out_df), out_full)
            client.insert_df(out_full, out_df)
        else:
            path = _require("OUTPUT_S3_PATH")
            bucket, key = parse_s3_uri(path.rstrip("/") + "/")
            key = key.rstrip("/")
            if key:
                key = key + "/"
            parquet_key = key + "predictions.parquet"
            tmp_parquet = os.path.join(local_model, "predictions.parquet")
            out_df.to_parquet(tmp_parquet, index=False)
            import boto3

            boto3.client("s3").upload_file(tmp_parquet, bucket, parquet_key)
            logger.info("Wrote s3://%s/%s", bucket, parquet_key)
    finally:
        shutil.rmtree(local_model, ignore_errors=True)


if __name__ == "__main__":
    main()
