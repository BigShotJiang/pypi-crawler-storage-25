"""
Analytics modules for batch analytics pipeline.
- Module 1: Linear regression (XY) and slope comparison
- Module 2: Multi-feature correlation
- Module 3: PCA and clustering
- Module 4: T-test to compare means of two groups
"""

from .linear_regression import run_linear_regression
from .correlation import run_correlation
from .pca_clustering import run_pca_clustering
from .t_test import run_t_test

__all__ = [
    "run_linear_regression",
    "run_correlation",
    "run_pca_clustering",
    "run_t_test",
]
