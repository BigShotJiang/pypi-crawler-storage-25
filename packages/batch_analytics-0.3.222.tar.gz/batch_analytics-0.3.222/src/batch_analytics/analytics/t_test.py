"""
Module 4: T-test and one-way ANOVA for comparing means across groups.
"""

import logging
from typing import Any, Dict, List

from pyspark.sql import DataFrame, SparkSession
from pyspark.sql.functions import col, avg, stddev, count
from pyspark.sql.types import DoubleType

from ..config import BatchAnalyticsConfig

logger = logging.getLogger(__name__)


def run_t_test(
    spark: SparkSession,
    df: DataFrame,
    config: BatchAnalyticsConfig,
) -> Dict[str, Any]:
    """
    Compare means across groups or two numeric columns.

    Supports:
    1. Value + group: one numeric column, one categorical column.
       - **2 groups:** Welch's t-test (unequal variances).
       - **3+ groups:** one-way ANOVA (F-test on equal means).
    2. Two columns: two numeric columns, Welch t-test on their column means.

    Returns:
        For Welch: ``group_a``, ``group_b``, ``t_statistic``, ``p_value``, ``test`` = ``\"Welch\"``.
        For ANOVA: ``groups``, ``f_statistic``, ``p_value``, ``test`` = ``\"one_way_anova\"``, SS/df.
    """
    value_col = (config.analytics.ttest_value_column or "").strip()
    group_col = (config.analytics.ttest_group_column or "").strip()
    col_a = (config.analytics.ttest_col_a or "").strip()
    col_b = (config.analytics.ttest_col_b or "").strip()

    # Mode 1: value column + group column (both required)
    if value_col and group_col and value_col in df.columns and group_col in df.columns:
        return _run_t_test_by_group(df, value_col, group_col)

    # Mode 2: two numeric columns
    if col_a and col_b and col_a in df.columns and col_b in df.columns:
        return _run_t_test_two_columns(df, col_a, col_b)

    # Fallback: first numeric + string-like column with at least 2 distinct groups
    numeric_cols = [
        f.name for f in df.schema.fields
        if "double" in str(f.dataType).lower()
        or "int" in str(f.dataType).lower()
        or "float" in str(f.dataType).lower()
    ]
    string_cols = [
        f.name for f in df.schema.fields
        if "string" in str(f.dataType).lower()
    ]
    for nc in numeric_cols:
        for sc in string_cols:
            distinct = df.select(sc).distinct().count()
            if distinct >= 2:
                logger.info(
                    "Auto-selected value=%s, group=%s (%d groups)", nc, sc, distinct
                )
                return _run_t_test_by_group(df, nc, sc)

    raise ValueError(
        "T-test requires either (BATCH_TTEST_VALUE_COLUMN + BATCH_TTEST_GROUP_COLUMN) "
        "or (BATCH_TTEST_COL_A + BATCH_TTEST_COL_B). "
        f"Available columns: {df.columns}"
    )


def _run_t_test_by_group(
    df: DataFrame,
    value_col: str,
    group_col: str,
) -> Dict[str, Any]:
    """Compare mean of value_col across groups: Welch (2 groups) or one-way ANOVA (3+)."""
    df_num = df.select(
        col(value_col).cast(DoubleType()).alias("_val"),
        col(group_col).cast("string").alias("_grp"),
    ).filter(col("_val").isNotNull() & col("_grp").isNotNull())

    stats = (
        df_num.groupBy("_grp")
        .agg(
            avg("_val").alias("mean"),
            stddev("_val").alias("std"),
            count("_val").alias("n"),
        )
        .collect()
    )

    k = len(stats)
    if k < 2:
        raise ValueError(
            f"Need at least 2 groups in {group_col} for comparison. Found: {[r['_grp'] for r in stats]}"
        )

    if k > 2:
        return _run_one_way_anova(stats, value_col, group_col)

    r0, r1 = stats[0], stats[1]
    return _compute_t_test_result(
        group_a=r0["_grp"],
        mean_a=float(r0["mean"]),
        std_a=float(r0["std"] or 0.0),
        n_a=int(r0["n"]),
        group_b=r1["_grp"],
        mean_b=float(r1["mean"]),
        std_b=float(r1["std"] or 0.0),
        n_b=int(r1["n"]),
    )


def _run_one_way_anova(
    stats_rows: List[Any],
    value_col: str,
    group_col: str,
) -> Dict[str, Any]:
    """
    One-way ANOVA from per-group mean, sample stddev, and n (Spark ``stddev`` uses ddof=1).

    SS_within = sum_i (n_i - 1) * s_i^2
    SS_between = sum_i n_i * (mean_i - grand_mean)^2
    """
    try:
        from scipy import stats as scipy_stats
    except ImportError:
        raise ImportError("ANOVA requires scipy. Install with: pip install scipy")

    groups: List[Dict[str, Any]] = []
    for r in stats_rows:
        name = r["_grp"]
        mean = float(r["mean"])
        std_raw = r["std"]
        std = 0.0 if std_raw is None else float(std_raw)
        n = int(r["n"])
        groups.append(
            {"name": name, "mean": mean, "std": std, "n": n}
        )

    k = len(groups)
    N = sum(g["n"] for g in groups)
    if N <= k:
        raise ValueError(
            f"ANOVA needs more observations than groups (N={N}, k={k})"
        )

    grand_mean = sum(g["n"] * g["mean"] for g in groups) / N
    ss_between = sum(g["n"] * (g["mean"] - grand_mean) ** 2 for g in groups)
    ss_within = sum(
        (g["n"] - 1) * (g["std"] ** 2) for g in groups if g["n"] > 1
    )

    df_between = k - 1
    df_within = N - k
    if df_within <= 0:
        raise ValueError(
            f"ANOVA: df_within must be positive (N={N}, k={k})"
        )

    ms_between = ss_between / df_between
    ms_within = ss_within / df_within if df_within > 0 else 0.0

    if ms_within <= 0.0:
        if ms_between <= 0.0:
            f_stat = 0.0
            p_value = 1.0
        else:
            f_stat = float("inf")
            p_value = 0.0
    else:
        f_stat = ms_between / ms_within
        p_value = float(scipy_stats.f.sf(f_stat, df_between, df_within))

    out: Dict[str, Any] = {
        "test": "one_way_anova",
        "value_column": value_col,
        "group_column": group_col,
        "k_groups": k,
        "n_total": N,
        "grand_mean": grand_mean,
        "f_statistic": f_stat,
        "p_value": p_value,
        "df_between": df_between,
        "df_within": df_within,
        "ss_between": ss_between,
        "ss_within": ss_within,
        "ms_between": ms_between,
        "ms_within": ms_within,
        "groups": [
            {
                "name": g["name"],
                "mean": g["mean"],
                "std": g["std"],
                "n": g["n"],
            }
            for g in sorted(groups, key=lambda x: str(x["name"]))
        ],
    }
    if f_stat == float("inf"):
        out["f_statistic"] = None
        out["f_statistic_note"] = "infinite (MS_within == 0, reject equal means if SS_between > 0)"
    return out


def _run_t_test_two_columns(df: DataFrame, col_a: str, col_b: str) -> Dict[str, Any]:
    """T-test: compare means of two numeric columns."""
    df_num = df.select(
        col(col_a).cast(DoubleType()).alias("_a"),
        col(col_b).cast(DoubleType()).alias("_b"),
    ).filter(col("_a").isNotNull() & col("_b").isNotNull())

    row = df_num.agg(
        avg("_a").alias("mean_a"),
        stddev("_a").alias("std_a"),
        count("_a").alias("n_a"),
        avg("_b").alias("mean_b"),
        stddev("_b").alias("std_b"),
        count("_b").alias("n_b"),
    ).collect()[0]

    return _compute_t_test_result(
        group_a=col_a,
        mean_a=float(row["mean_a"]),
        std_a=float(row["std_a"] or 0.0),
        n_a=int(row["n_a"]),
        group_b=col_b,
        mean_b=float(row["mean_b"]),
        std_b=float(row["std_b"] or 0.0),
        n_b=int(row["n_b"]),
    )


def _compute_t_test_result(
    group_a: str,
    mean_a: float,
    std_a: float,
    n_a: int,
    group_b: str,
    mean_b: float,
    std_b: float,
    n_b: int,
) -> Dict[str, Any]:
    """Compute Welch's t-test from summary statistics."""
    try:
        from scipy import stats
    except ImportError:
        raise ImportError("T-test requires scipy. Install with: pip install scipy")

    t_stat, p_value = stats.ttest_ind_from_stats(
        mean1=mean_a,
        std1=std_a,
        nobs1=n_a,
        mean2=mean_b,
        std2=std_b,
        nobs2=n_b,
        equal_var=False,  # Welch's t-test
    )

    return {
        "group_a": {
            "name": group_a,
            "mean": mean_a,
            "std": std_a,
            "n": n_a,
        },
        "group_b": {
            "name": group_b,
            "mean": mean_b,
            "std": std_b,
            "n": n_b,
        },
        "t_statistic": float(t_stat),
        "p_value": float(p_value),
        "mean_difference": mean_a - mean_b,
        "test": "Welch",
    }
