"""
Train AutoGluon TabularPredictor from ClickHouse staging data; upload artifacts to S3.

Env (injected by analytics_runner Gluon job):
  CLICKHOUSE_*, BATCH_STAGING_TABLE, MODEL_S3_PREFIX, TASK_ID,
  AUTOGLUON_LABEL, AUTOGLUON_FEATURES, AUTOGLUON_PROBLEM_TYPE, AUTOGLUON_TIME_LIMIT,
  optional AUTOGLUON_MAX_ROWS,
  optional AUTOGLUON_HYPERPARAMETERS — JSON object of AutoGluon model hyperparameters; default {"GBM": {}} (LightGBM only, no PyTorch)
"""

from __future__ import annotations

import json
import logging
import os
import shutil
import sys

import clickhouse_connect

try:
    from batch_analytics.utils.gluon_autogluon_common import (
        clickhouse_full_table,
        local_training_dir,
        upload_directory_to_s3,
    )
except ImportError:
    _pkg_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    if _pkg_root not in sys.path:
        sys.path.insert(0, _pkg_root)
    from utils.gluon_autogluon_common import (  # noqa: E402
        clickhouse_full_table,
        local_training_dir,
        upload_directory_to_s3,
    )

logging.basicConfig(level=logging.INFO, format="%(levelname)s %(message)s")
logger = logging.getLogger(__name__)


def _require(name: str) -> str:
    v = os.environ.get(name, "").strip()
    if not v:
        logger.error("Missing required env var: %s", name)
        sys.exit(2)
    return v


def _hyperparameters_from_env() -> dict:
    """Default: GBM (LightGBM) only — matches autogluon-tabular[lightgbm] and avoids NN/torch models."""
    raw = os.environ.get("AUTOGLUON_HYPERPARAMETERS", "").strip()
    if not raw:
        return {"GBM": {}}
    try:
        parsed = json.loads(raw)
    except json.JSONDecodeError as e:
        logger.error("AUTOGLUON_HYPERPARAMETERS must be valid JSON: %s", e)
        sys.exit(2)
    if not isinstance(parsed, dict):
        logger.error("AUTOGLUON_HYPERPARAMETERS must be a JSON object, e.g. {\"GBM\": {}}")
        sys.exit(2)
    return parsed


def main() -> None:
    model_prefix = _require("MODEL_S3_PREFIX")
    label = _require("AUTOGLUON_LABEL")
    features_raw = _require("AUTOGLUON_FEATURES")
    feature_list = [c.strip() for c in features_raw.split(",") if c.strip()]

    host = _require("CLICKHOUSE_HOST")
    port = int(os.environ.get("CLICKHOUSE_HTTP_PORT", "8123"))
    database = os.environ.get("CLICKHOUSE_DB", "default").strip() or "default"
    user = os.environ.get("CLICKHOUSE_USER", "default")
    password = os.environ.get("CLICKHOUSE_PASSWORD", "")
    staging_table = _require("BATCH_STAGING_TABLE")
    full_table = clickhouse_full_table(database, staging_table)

    max_rows = os.environ.get("AUTOGLUON_MAX_ROWS", "").strip()
    limit_sql = f" LIMIT {int(max_rows)}" if max_rows else ""
    sql = f"SELECT * FROM {full_table}{limit_sql}"

    logger.info("Loading training data: %s", sql)
    client = clickhouse_connect.get_client(
        host=host,
        port=port,
        username=user,
        password=password or None,
        database=database,
    )
    df = client.query_df(sql)

    missing = [c for c in feature_list + [label] if c not in df.columns]
    if missing:
        logger.error("Columns missing from training data: %s (have: %s)", missing, list(df.columns))
        sys.exit(3)

    try:
        from autogluon.tabular import TabularPredictor
    except ImportError as e:
        if isinstance(e, ModuleNotFoundError) and e.name == "typing_extensions":
            logger.exception(
                "Install typing-extensions (required by AutoGluon): pip install 'typing-extensions>=4.8'"
            )
        else:
            logger.exception("autogluon is not installed; use pip install 'batch-analytics[autogluon]'")
        sys.exit(4)

    problem_type = os.environ.get("AUTOGLUON_PROBLEM_TYPE", "binary").strip() or "binary"
    time_limit = int(os.environ.get("AUTOGLUON_TIME_LIMIT", "300"))

    local_dir = local_training_dir()
    if os.path.isdir(local_dir):
        shutil.rmtree(local_dir)
    os.makedirs(local_dir, exist_ok=True)

    train_df = df[feature_list + [label]]
    hyper = _hyperparameters_from_env()
    logger.info(
        "Fitting TabularPredictor problem_type=%s time_limit=%ss hyperparameters=%s rows=%s",
        problem_type,
        time_limit,
        hyper,
        len(train_df),
    )
    predictor = TabularPredictor(
        label=label,
        problem_type=problem_type,
        path=local_dir,
    )
    predictor.fit(train_df, time_limit=time_limit, hyperparameters=hyper)

    logger.info("Uploading model artifacts to %s", model_prefix)
    upload_directory_to_s3(local_dir, model_prefix)
    logger.info("Train finished; task_id=%s", os.environ.get("TASK_ID", ""))


if __name__ == "__main__":
    main()
