"""
Local output driver: writes analytics results to a local directory (BATCH_LOG_PATH).
"""

import json
import logging
from pathlib import Path
from typing import Any, Dict, List, Union

from .base import OutputDriver, _serialize_for_json

logger = logging.getLogger(__name__)


class LocalOutputDriver(OutputDriver):
    """Write analytics artifacts to local filesystem."""

    def __init__(self, path: Union[str, Path] = "/tmp/analytics_logs", **kwargs: Any) -> None:
        self.path = Path(path)
        self.path.mkdir(parents=True, exist_ok=True)

    def write(
        self,
        run_id: str,
        task_id: str,
        artifacts: Dict[str, Any],
    ) -> List[str]:
        locations: List[str] = []
        for name, data in artifacts.items():
            filepath = self.path / f"{run_id}_analytics_{name}.json"
            with open(filepath, "w") as f:
                json.dump(_serialize_for_json(data), f, indent=2)
            locations.append(str(filepath))

        logger.info("Wrote %d analytics artifacts to %s", len(locations), self.path)
        return locations
