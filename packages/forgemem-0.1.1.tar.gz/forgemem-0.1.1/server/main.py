"""
Forgemem Managed Inference API — v0.3

Endpoints:
  POST /v1/inference            — run a prompt, deduct credits
  GET  /v1/balance              — get current credit balance
  POST /v1/checkout             — create Stripe Checkout session
  POST /webhooks/stripe         — Stripe webhook (top up credits on payment)
  POST /cli-auth/send-link      — send magic link email
  GET  /cli-auth/verify         — verify magic link, create session, redirect to CLI
  GET  /cli-auth                — browser landing page (renders email form)
"""
from __future__ import annotations

import os
import re
import secrets
import urllib.parse as _urlparse
from typing import Annotated

import anthropic
from fastapi import FastAPI, Header, HTTPException, Request
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.templating import Jinja2Templates
from pydantic import BaseModel

from auth import create_magic_link_token, create_session_token, verify_session_token
from billing import CREDIT_PACKS, create_checkout_session, parse_webhook_event
from db import Database
from email_sender import send_magic_link
from usage import RateLimitExceeded, check_rate_limit

app = FastAPI(title="Forgemem Inference API", version="0.3.0")
templates = Jinja2Templates(directory=os.path.join(os.path.dirname(__file__), "templates"))

ANTHROPIC_API_KEY = os.environ.get("ANTHROPIC_API_KEY", "")
PLATFORM_FEE_USD = float(os.environ.get("PLATFORM_FEE_USD", "0.02"))
FREE_CREDIT_USD = float(os.environ.get("FREE_CREDIT_USD", "5.0"))
API_BASE_URL = os.environ.get("API_BASE_URL", "https://api.forgemem.com")

db = Database()
db.init()

_CLI_CALLBACK_RE = re.compile(r"^http://127\.0\.0\.1:\d{4,5}/\S*$")


# ---------------------------------------------------------------------------
# Request/response models
# ---------------------------------------------------------------------------

class InferenceRequest(BaseModel):
    prompt: str
    max_tokens: int = 300
    model: str = "claude-haiku-4-5-20251001"


class InferenceResponse(BaseModel):
    text: str
    cost_usd: float
    balance_usd: float
    run_id: str


class CheckoutRequest(BaseModel):
    pack_id: str = "starter"
    success_url: str = "https://app.forgemem.com/billing/success"
    cancel_url: str = "https://app.forgemem.com/billing"


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _auth_user(authorization: str) -> dict:
    token = authorization.removeprefix("Bearer ").strip()
    if not token:
        raise HTTPException(status_code=401, detail="Missing token")
    try:
        verify_session_token(token)
    except ValueError as e:
        raise HTTPException(status_code=401, detail=str(e))
    user = db.get_user_by_session(token)
    if not user:
        raise HTTPException(status_code=401, detail="Session not found or expired")
    return user


def _estimate_cost(prompt: str, max_tokens: int, model: str) -> float:
    input_tokens = len(prompt) / 4
    # Haiku pricing: $0.25/M input, $1.25/M output
    input_cost = (input_tokens / 1_000_000) * 0.25
    output_cost = (max_tokens / 1_000_000) * 1.25
    return round(input_cost + output_cost + PLATFORM_FEE_USD, 6)


def _validate_cli_callback(callback: str) -> None:
    if not callback or not _CLI_CALLBACK_RE.match(callback):
        raise HTTPException(
            status_code=400,
            detail="Invalid callback: must be a loopback address (http://127.0.0.1:<port>/...)",
        )


# ---------------------------------------------------------------------------
# Routes
# ---------------------------------------------------------------------------

@app.post("/v1/inference", response_model=InferenceResponse)
async def inference(body: InferenceRequest, authorization: Annotated[str, Header()]):
    user = _auth_user(authorization)

    try:
        check_rate_limit(db, user["id"])
    except RateLimitExceeded as e:
        raise HTTPException(status_code=429, detail=str(e))

    estimated_cost = _estimate_cost(body.prompt, body.max_tokens, body.model)
    if user["balance_usd"] < estimated_cost:
        raise HTTPException(
            status_code=402,
            detail={"message": "Insufficient credits", "balance_usd": user["balance_usd"]},
        )

    client = anthropic.Anthropic(api_key=ANTHROPIC_API_KEY)
    response = client.messages.create(
        model=body.model,
        max_tokens=body.max_tokens,
        messages=[{"role": "user", "content": body.prompt}],
    )
    text = response.content[0].text.strip()

    try:
        new_balance = db.deduct_credits(user["id"], estimated_cost)
    except ValueError:
        raise HTTPException(status_code=402, detail="Insufficient credits")

    run_id = secrets.token_hex(8)
    db.log_run(user["id"], run_id, estimated_cost, body.model, new_balance)

    return InferenceResponse(
        text=text,
        cost_usd=estimated_cost,
        balance_usd=new_balance,
        run_id=run_id,
    )


@app.get("/v1/balance")
async def balance(authorization: Annotated[str, Header()]):
    user = _auth_user(authorization)
    return {"balance_usd": user["balance_usd"]}


@app.post("/v1/checkout")
async def checkout(body: CheckoutRequest, authorization: Annotated[str, Header()]):
    """Create a Stripe Checkout session. Client opens returned checkout_url in browser."""
    user = _auth_user(authorization)
    try:
        url = create_checkout_session(
            user_id=user["id"],
            pack_id=body.pack_id,
            success_url=body.success_url,
            cancel_url=body.cancel_url,
        )
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    return {"checkout_url": url, "packs": CREDIT_PACKS}


@app.post("/webhooks/stripe")
async def stripe_webhook(request: Request):
    """Verify Stripe signature, top up credits on successful payment. Idempotent."""
    payload = await request.body()
    sig = request.headers.get("stripe-signature", "")
    try:
        result = parse_webhook_event(payload, sig)
    except Exception:
        raise HTTPException(status_code=400, detail="Invalid webhook signature")

    if result is None:
        return {"status": "ignored"}

    if db.stripe_event_seen(result["event_id"]):
        return {"status": "duplicate"}

    try:
        db.top_up_credits(result["user_id"], result["credit_usd"])
    except ValueError:
        raise HTTPException(status_code=404, detail="User not found for this payment")
    return {"status": "ok", "credit_usd": result["credit_usd"]}


@app.post("/cli-auth/send-link")
async def cli_auth_send_link(request: Request):
    form = await request.form()
    email = str(form.get("email", "")).strip().lower()
    callback = str(form.get("callback", ""))
    state = str(form.get("state", ""))
    _validate_cli_callback(callback)

    if not email or "@" not in email:
        raise HTTPException(status_code=400, detail="Invalid email")

    token = create_magic_link_token()
    db.create_magic_link_token(token, email, callback, state)

    safe_token = _urlparse.quote(token)
    safe_cb = _urlparse.quote(callback)
    safe_state = _urlparse.quote(state)
    magic_url = f"{API_BASE_URL}/cli-auth/verify?token={safe_token}&callback={safe_cb}&state={safe_state}"

    send_magic_link(to=email, magic_url=magic_url)
    return HTMLResponse(
        "<html><body><p>Check your email for a magic link (expires in 10 minutes).</p></body></html>"
    )


@app.get("/cli-auth/verify")
async def cli_auth_verify(token: str, callback: str, state: str):
    """Verify magic link, create session, redirect to CLI callback with token."""
    _validate_cli_callback(callback)
    link = db.consume_magic_link_token(token)
    if not link or link["callback"] != callback or link["state"] != state:
        raise HTTPException(status_code=400, detail="Invalid or expired link")

    email = link["email"]
    user = db.get_user_by_email(email)
    if user is None:
        user_id = db.create_user(email, initial_balance=FREE_CREDIT_USD)
    else:
        user_id = user["id"]

    session_token = create_session_token(user_id)
    db.create_session(session_token, user_id)

    safe_token = _urlparse.quote(session_token)
    safe_state = _urlparse.quote(state)
    return RedirectResponse(
        url=f"{callback}?token={safe_token}&state={safe_state}",
        status_code=302,
    )


@app.get("/cli-auth")
async def cli_auth_landing(request: Request):
    """Browser landing page — renders the email + magic link form."""
    callback = request.query_params.get("callback", "")
    state = request.query_params.get("state", "")
    _validate_cli_callback(callback)
    csrf_token = secrets.token_urlsafe(16)
    return templates.TemplateResponse(
        "cli_auth.html",
        {"request": request, "callback": callback, "state": state, "csrf_token": csrf_token},
    )
