"""
Server data layer — supports both SQLite (local dev) and Postgres (production).

Backend selection:
  - DATABASE_URL set  -> Postgres via psycopg2
  - DATABASE_URL unset -> SQLite at ~/.forgemem/server.db

Users' local memory DB (~/.forgemem/forgemem_memory.db) is completely separate
and is never touched by this module.
"""
from __future__ import annotations

import os
import secrets
import sqlite3
import time
from pathlib import Path

DATABASE_URL: str = os.environ.get("DATABASE_URL", "")
DB_PATH = Path(os.environ.get("FORGEMEM_SERVER_DB", str(Path.home() / ".forgemem" / "server.db")))

# Schema as individual statements (executescript is SQLite-only)
_SCHEMA_STATEMENTS = [
    """CREATE TABLE IF NOT EXISTS users (
        id          TEXT PRIMARY KEY,
        email       TEXT UNIQUE NOT NULL,
        balance_usd DOUBLE PRECISION NOT NULL DEFAULT 5.0,
        created_at  BIGINT NOT NULL
    )""",
    """CREATE TABLE IF NOT EXISTS sessions (
        token       TEXT PRIMARY KEY,
        user_id     TEXT NOT NULL REFERENCES users(id),
        created_at  BIGINT NOT NULL,
        expires_at  BIGINT NOT NULL
    )""",
    """CREATE TABLE IF NOT EXISTS magic_link_tokens (
        token       TEXT PRIMARY KEY,
        email       TEXT NOT NULL,
        callback    TEXT NOT NULL,
        state       TEXT NOT NULL,
        created_at  BIGINT NOT NULL,
        expires_at  BIGINT NOT NULL,
        used        INTEGER NOT NULL DEFAULT 0
    )""",
    """CREATE TABLE IF NOT EXISTS usage_runs (
        run_id      TEXT PRIMARY KEY,
        user_id     TEXT NOT NULL REFERENCES users(id),
        cost_usd    DOUBLE PRECISION NOT NULL,
        model       TEXT NOT NULL,
        balance_usd DOUBLE PRECISION NOT NULL,
        ts          BIGINT NOT NULL
    )""",
    """CREATE TABLE IF NOT EXISTS stripe_events (
        event_id     TEXT PRIMARY KEY,
        processed_at BIGINT NOT NULL
    )""",
]


class Database:
    def __init__(self, path: Path = DB_PATH, url: str = DATABASE_URL):
        self.path = path
        self.url = url

    def _conn(self):
        if self.url:
            import psycopg2
            import psycopg2.extras
            conn = psycopg2.connect(self.url)
            conn.cursor_factory = psycopg2.extras.RealDictCursor
            return conn
        conn = sqlite3.connect(self.path)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("PRAGMA foreign_keys=ON")
        return conn

    def _exec(self, conn, sql: str, params: tuple = ()):
        """Execute uniformly: psycopg2 needs a cursor, sqlite3 uses conn directly."""
        if self.url:
            cur = conn.cursor()
            cur.execute(sql, params)
            return cur
        return conn.execute(sql, params)

    def _fetchone(self, conn, sql: str, params: tuple = ()) -> dict | None:
        cur = self._exec(conn, sql, params)
        row = cur.fetchone()
        return dict(row) if row else None

    def _q(self, sql: str) -> str:
        """Swap ? -> %s for Postgres."""
        return sql.replace("?", "%s") if self.url else sql

    def init(self) -> None:
        if not self.url:
            self.path.parent.mkdir(parents=True, exist_ok=True)
        with self._conn() as conn:
            for stmt in _SCHEMA_STATEMENTS:
                self._exec(conn, stmt)
            conn.commit()

    def create_user(self, email: str, initial_balance: float = 5.0) -> str:
        uid = secrets.token_hex(16)
        now = int(time.time())
        with self._conn() as conn:
            self._exec(
                conn,
                self._q("INSERT INTO users (id, email, balance_usd, created_at) VALUES (?,?,?,?)"),
                (uid, email, initial_balance, now),
            )
            conn.commit()
        return uid

    def get_user_by_email(self, email: str) -> dict | None:
        with self._conn() as conn:
            return self._fetchone(conn, self._q("SELECT * FROM users WHERE email=?"), (email,))

    def get_user_by_session(self, token: str) -> dict | None:
        now = int(time.time())
        sql = self._q(
            "SELECT u.* FROM users u "
            "JOIN sessions s ON s.user_id = u.id "
            "WHERE s.token=? AND s.expires_at > ?"
        )
        with self._conn() as conn:
            return self._fetchone(conn, sql, (token, now))

    def create_session(self, token: str, user_id: str, ttl_seconds: int = 30 * 86400) -> None:
        now = int(time.time())
        if self.url:
            sql = (
                "INSERT INTO sessions (token, user_id, created_at, expires_at) "
                "VALUES (%s,%s,%s,%s) "
                "ON CONFLICT (token) DO UPDATE SET "
                "user_id=EXCLUDED.user_id, created_at=EXCLUDED.created_at, "
                "expires_at=EXCLUDED.expires_at"
            )
        else:
            sql = "INSERT OR REPLACE INTO sessions (token, user_id, created_at, expires_at) VALUES (?,?,?,?)"
        with self._conn() as conn:
            self._exec(conn, sql, (token, user_id, now, now + ttl_seconds))
            conn.commit()

    def deduct_credits(self, user_id: str, amount: float) -> float:
        with self._conn() as conn:
            row = self._fetchone(conn, self._q("SELECT balance_usd FROM users WHERE id=?"), (user_id,))
            if not row:
                raise ValueError(f"User {user_id} not found")
            new_balance = round(row["balance_usd"] - amount, 6)
            if new_balance < 0:
                raise ValueError(f"Insufficient credits (balance: ${row['balance_usd']:.4f})")
            self._exec(conn, self._q("UPDATE users SET balance_usd=? WHERE id=?"), (new_balance, user_id))
            conn.commit()
        return new_balance

    def top_up_credits(self, user_id: str, amount: float) -> float:
        with self._conn() as conn:
            self._exec(
                conn,
                self._q("UPDATE users SET balance_usd = balance_usd + ? WHERE id=?"),
                (amount, user_id),
            )
            row = self._fetchone(conn, self._q("SELECT balance_usd FROM users WHERE id=?"), (user_id,))
            conn.commit()
        if not row:
            raise ValueError(f"User {user_id} not found")
        return round(row["balance_usd"], 6)

    def log_run(self, user_id: str, run_id: str, cost_usd: float, model: str, balance_usd: float) -> None:
        sql = self._q(
            "INSERT INTO usage_runs (run_id, user_id, cost_usd, model, balance_usd, ts) "
            "VALUES (?,?,?,?,?,?)"
        )
        with self._conn() as conn:
            self._exec(conn, sql, (run_id, user_id, cost_usd, model, balance_usd, int(time.time())))
            conn.commit()

    def run_count_in_window(self, user_id: str, window_seconds: int = 3600) -> int:
        cutoff = int(time.time()) - window_seconds
        with self._conn() as conn:
            cur = self._exec(
                conn,
                self._q("SELECT COUNT(*) FROM usage_runs WHERE user_id=? AND ts > ?"),
                (user_id, cutoff),
            )
            row = cur.fetchone()
        return row[0] if row else 0

    def create_magic_link_token(self, token: str, email: str, callback: str, state: str, ttl: int = 600) -> None:
        now = int(time.time())
        sql = self._q(
            "INSERT INTO magic_link_tokens "
            "(token, email, callback, state, created_at, expires_at) VALUES (?,?,?,?,?,?)"
        )
        with self._conn() as conn:
            self._exec(conn, sql, (token, email, callback, state, now, now + ttl))
            conn.commit()

    def consume_magic_link_token(self, token: str) -> dict | None:
        now = int(time.time())
        with self._conn() as conn:
            row = self._fetchone(
                conn,
                self._q("SELECT * FROM magic_link_tokens WHERE token=? AND expires_at>? AND used=0"),
                (token, now),
            )
            if row:
                self._exec(conn, self._q("UPDATE magic_link_tokens SET used=1 WHERE token=?"), (token,))
                conn.commit()
        return row

    def stripe_event_seen(self, event_id: str) -> bool:
        """Returns True if already processed (idempotency). Inserts if new."""
        with self._conn() as conn:
            row = self._fetchone(
                conn,
                self._q("SELECT 1 FROM stripe_events WHERE event_id=?"),
                (event_id,),
            )
            if row:
                return True
            self._exec(
                conn,
                self._q("INSERT INTO stripe_events (event_id, processed_at) VALUES (?,?)"),
                (event_id, int(time.time())),
            )
            conn.commit()
        return False
