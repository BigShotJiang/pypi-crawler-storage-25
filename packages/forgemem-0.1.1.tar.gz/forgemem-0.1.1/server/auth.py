"""JWT session token creation/verification for Forgemem."""
from __future__ import annotations

import os
import secrets
import time

import jwt

JWT_SECRET = os.environ.get("FORGEMEM_JWT_SECRET", "")
JWT_ALGORITHM = "HS256"


def create_session_token(user_id: str, ttl_seconds: int = 30 * 86400) -> str:
    if not JWT_SECRET:
        raise RuntimeError("FORGEMEM_JWT_SECRET env var not set")
    payload = {
        "sub": user_id,
        "iat": int(time.time()),
        "exp": int(time.time()) + ttl_seconds,
    }
    return jwt.encode(payload, JWT_SECRET, algorithm=JWT_ALGORITHM)


def verify_session_token(token: str) -> dict:
    """Return payload dict. Raises ValueError on invalid/expired token."""
    if not JWT_SECRET:
        raise RuntimeError("FORGEMEM_JWT_SECRET env var not set")
    try:
        return jwt.decode(token, JWT_SECRET, algorithms=[JWT_ALGORITHM])
    except jwt.ExpiredSignatureError:
        raise ValueError("Token expired")
    except jwt.InvalidTokenError as e:
        raise ValueError(f"Invalid token: {e}")


def create_magic_link_token() -> str:
    return secrets.token_urlsafe(32)
