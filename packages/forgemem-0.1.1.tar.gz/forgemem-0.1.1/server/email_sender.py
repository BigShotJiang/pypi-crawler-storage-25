"""Send transactional email via Resend (https://resend.com)."""
from __future__ import annotations

import os

import httpx

RESEND_API_KEY = os.environ.get("RESEND_API_KEY", "")
FROM_ADDRESS = "Forgemem <noreply@forgemem.com>"


def send_magic_link(to: str, magic_url: str) -> None:
    """Send a magic link email. Raises RuntimeError on Resend API failure."""
    if not RESEND_API_KEY:
        raise RuntimeError("RESEND_API_KEY env var not set")

    html = f"""
    <p>Click the link below to sign in to Forgemem CLI. This link expires in 10 minutes.</p>
    <p><a href="{magic_url}" style="font-size:16px;font-weight:bold">Sign in to Forgemem</a></p>
    <p>Or copy this URL:<br><code>{magic_url}</code></p>
    <p style="color:#888;font-size:12px">If you didn't request this, ignore this email.</p>
    """

    resp = httpx.post(
        "https://api.resend.com/emails",
        headers={"Authorization": f"Bearer {RESEND_API_KEY}"},
        json={
            "from": FROM_ADDRESS,
            "to": [to],
            "subject": "Your Forgemem sign-in link",
            "html": html,
        },
        timeout=10,
    )

    if resp.status_code != 200:
        raise RuntimeError(f"Resend API error {resp.status_code}: {resp.text[:200]}")
