#!/usr/bin/env python3
"""Forgemem CLI — flat ruff-style commands."""

from __future__ import annotations

import argparse
import json
import shutil
import subprocess
import sys
from pathlib import Path
from typing import Optional

import typer
from typing_extensions import Annotated
from rich.console import Console
from rich.panel import Panel

from forgemem import __version__

# ---------------------------------------------------------------------------
# App + console
# ---------------------------------------------------------------------------

app = typer.Typer(
    name="forgemem",
    help="Long-term memory store for AI agents.",
    add_completion=False,
)


def _version_callback(value: bool) -> None:
    if value:
        print(f"forgemem {__version__}")
        raise typer.Exit()


@app.callback()
def _main(
    version: Annotated[Optional[bool], typer.Option(
        "--version", "-V",
        callback=_version_callback,
        is_eager=True,
        help="Show version and exit.",
    )] = None,
) -> None:
    pass

console = Console()

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

PLIST_PATH = Path.home() / "Library" / "LaunchAgents" / "com.forgemem.server.plist"
PLIST_LABEL = "com.forgemem.server"
LOG_PATH = Path.home() / "Library" / "Logs" / "forgemem.log"

SKILL_PATHS: dict[str, Path] = {
    "claude": Path.home() / ".claude" / "skills" / "forgemem.md",
    "gemini": Path.home() / ".gemini" / "forgemem-skill.md",
    "codex":  Path.home() / ".codex"  / "forgemem-skill.json",
}

SKILL_TEMPLATES_DIR = Path(__file__).parent / "skills"

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _register_mcp(settings_path: Path) -> bool:
    """Idempotently add forgemem to ~/.claude/settings.json mcpServers."""
    data = json.loads(settings_path.read_text()) if settings_path.exists() else {}
    servers = data.setdefault("mcpServers", {})
    if "forgemem" not in servers:
        servers["forgemem"] = {"command": "forgemem", "args": ["mcp"]}
        settings_path.parent.mkdir(parents=True, exist_ok=True)
        settings_path.write_text(json.dumps(data, indent=2))
        return True
    return False


def _generate_skill(agent: str, dry_run: bool = False) -> None:
    """Read template from forgemem/skills/{agent}.{ext} and write to SKILL_PATHS[agent]."""
    ext = "json" if agent == "codex" else "md"
    template = SKILL_TEMPLATES_DIR / f"{agent}.{ext}"
    dest = SKILL_PATHS[agent]

    if dry_run:
        console.print(f"  [dim]dry-run[/] would write: {dest}")
        return

    if not template.exists():
        console.print(f"  [yellow]warning:[/] skill template not found: {template}")
        return

    dest.parent.mkdir(parents=True, exist_ok=True)
    content = template.read_text()
    dest.write_text(content)
    console.print(f"  [green]wrote[/] {dest}")


def _auto_detect_and_generate_skills(yes: bool) -> None:
    detected: list[str] = []
    if (Path.home() / ".claude" / "settings.json").exists():
        detected.append("claude")
    if (Path.home() / ".gemini").exists():
        detected.append("gemini")
    if (Path.home() / ".codex").exists():
        detected.append("codex")

    if not detected:
        return

    agents_str = ", ".join(detected)
    if not yes:
        proceed = typer.confirm(
            f"Generate Forgemem skill files for detected agents ({agents_str})?",
            default=True,
        )
        if not proceed:
            return

    for agent in detected:
        _generate_skill(agent)


def _detect_project_from_git() -> Optional[str]:
    result = subprocess.run(
        ["git", "rev-parse", "--show-toplevel"],
        capture_output=True,
        text=True,
    )
    if result.returncode == 0:
        return Path(result.stdout.strip()).name
    return None


# ---------------------------------------------------------------------------
# Commands
# ---------------------------------------------------------------------------


@app.command()
def init(
    yes: bool = typer.Option(False, "--yes", help="Skip confirmation prompts"),
):
    """Initialize DB, register MCP server, and detect agent skills."""
    # Python version guard
    if sys.version_info < (3, 9):
        console.print("[red]error:[/] Python 3.9+ required")
        raise typer.Exit(1)

    # DB init
    from forgemem.core import DB_PATH, get_conn, INIT_SQL
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    conn = get_conn()
    conn.executescript(INIT_SQL)
    conn.commit()
    conn.close()
    console.print(f"[green]DB initialized:[/] {DB_PATH}")

    # MCP registration
    settings_path = Path.home() / ".claude" / "settings.json"
    registered = _register_mcp(settings_path)
    if registered:
        console.print(f"[green]MCP registered[/] in {settings_path}")
    else:
        console.print("[dim]MCP already registered[/]")

    # Skill auto-detect
    _auto_detect_and_generate_skills(yes)

    # Ollama auto-detect (only if provider not yet configured)
    from forgemem import config as fm_cfg
    from forgemem.config import detect_ollama

    if fm_cfg.load().get("provider") is None:
        ollama = detect_ollama()
        if ollama:
            models_str = ", ".join(ollama["models"][:5]) or "no models pulled yet"
            console.print(f"\n[cyan]Ollama detected[/] at {ollama['url']}")
            console.print(f"  Available models: {models_str}")
            use_ollama = yes or typer.confirm(
                "Use Ollama as your inference provider? (free, private, local)",
                default=True,
            )
            if use_ollama:
                best = ollama["models"][0] if ollama["models"] else fm_cfg.DEFAULT_MODELS["ollama"]
                fm_cfg.set_provider("ollama")
                cfg_data = fm_cfg.load()
                cfg_data["model"] = best
                fm_cfg.save(cfg_data)
                console.print(f"[green]Provider set to ollama[/] using model [bold]{best}[/]")

    console.print(Panel(
        "[bold green]Forgemem initialized successfully![/]\n"
        "Run [cyan]forgemem status[/] to verify, [cyan]forgemem start[/] to launch the MCP server.",
        title="Forgemem Init",
        expand=False,
    ))


@app.command()
def start(
    schedule: Annotated[
        Optional[str],
        typer.Option(help="login|hourly|manual"),
    ] = None,
):
    """Start the MCP server. On macOS: installs a LaunchAgent plist."""
    if sys.platform != "darwin":
        console.print("[yellow]warning:[/] LaunchAgent is macOS only. On Linux, run [cyan]forgemem mcp[/] directly.")
        raise typer.Exit(0)

    forgemem_bin = shutil.which("forgemem")
    if not forgemem_bin:
        console.print("[red]error:[/] 'forgemem' binary not found in PATH. Install the package first.")
        raise typer.Exit(1)

    schedule_xml: str
    if schedule == "login" or schedule is None:
        schedule_xml = "<key>RunAtLoad</key><true/>"
    elif schedule == "hourly":
        schedule_xml = "<key>StartInterval</key><integer>3600</integer>"
    elif schedule == "manual":
        schedule_xml = ""
    else:
        console.print(f"[red]error:[/] unknown schedule '{schedule}'. Use login|hourly|manual.")
        raise typer.Exit(1)

    LOG_PATH.parent.mkdir(parents=True, exist_ok=True)
    plist_content = f"""<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>Label</key><string>{PLIST_LABEL}</string>
    <key>ProgramArguments</key>
    <array>
        <string>{forgemem_bin}</string>
        <string>mcp</string>
    </array>
    {schedule_xml}
    <key>StandardOutPath</key><string>{LOG_PATH}</string>
    <key>StandardErrorPath</key><string>{LOG_PATH}</string>
</dict>
</plist>
"""
    PLIST_PATH.parent.mkdir(parents=True, exist_ok=True)
    PLIST_PATH.write_text(plist_content)
    console.print(f"[green]plist written:[/] {PLIST_PATH}")

    result = subprocess.run(
        ["launchctl", "load", str(PLIST_PATH)],
        capture_output=True,
        text=True,
    )
    if result.returncode == 0:
        console.print("[green]LaunchAgent loaded.[/]")
    else:
        console.print(f"[yellow]launchctl load returned {result.returncode}:[/] {result.stderr.strip()}")


@app.command()
def stop():
    """Unload the LaunchAgent and optionally remove the plist."""
    if sys.platform != "darwin":
        console.print("[yellow]warning:[/] LaunchAgent is macOS only.")
        raise typer.Exit(0)

    if not PLIST_PATH.exists():
        console.print(f"[yellow]plist not found:[/] {PLIST_PATH}")
        raise typer.Exit(0)

    result = subprocess.run(
        ["launchctl", "unload", str(PLIST_PATH)],
        check=False,
        capture_output=True,
        text=True,
    )
    if result.returncode == 0:
        console.print("[green]LaunchAgent unloaded.[/]")
    else:
        console.print(f"[yellow]launchctl unload returned {result.returncode}:[/] {result.stderr.strip()}")

    remove = typer.confirm("Remove plist file?", default=False)
    if remove:
        PLIST_PATH.unlink(missing_ok=True)
        console.print(f"[dim]removed[/] {PLIST_PATH}")


@app.command()
def status():
    """Show DB stats, server health, and skill status."""
    from forgemem.core import DB_PATH, get_conn

    # DB stats
    if not DB_PATH.exists():
        console.print(f"[red]DB not found:[/] {DB_PATH}  (run [cyan]forgemem init[/])")
        raise typer.Exit(1)

    conn = get_conn()
    t_total     = conn.execute("SELECT COUNT(*) FROM traces").fetchone()[0]
    p_total     = conn.execute("SELECT COUNT(*) FROM principles").fetchone()[0]
    undistilled = conn.execute("SELECT COUNT(*) FROM traces WHERE distilled=0").fetchone()[0]
    conn.close()

    console.print(Panel(
        f"[bold]DB:[/] {DB_PATH}\n"
        f"Traces: {t_total}  |  Principles: {p_total}  |  Undistilled: {undistilled}",
        title="Forgemem Status",
        expand=False,
    ))

    # Server health (macOS LaunchAgent)
    if sys.platform == "darwin":
        if PLIST_PATH.exists():
            console.print(f"[green]LaunchAgent plist:[/] {PLIST_PATH}")
        else:
            console.print("[dim]LaunchAgent not installed[/]")

    # Skill status
    console.print("\n[bold]Skills:[/]")
    for agent, path in SKILL_PATHS.items():
        if path.exists():
            console.print(f"  [green]✓[/] {agent}: {path}")
        else:
            console.print(f"  [dim]✗[/] {agent}: {path} (not installed)")

    # MCP registration
    settings_path = Path.home() / ".claude" / "settings.json"
    if settings_path.exists():
        try:
            data = json.loads(settings_path.read_text())
            if "forgemem" in data.get("mcpServers", {}):
                console.print("\n[green]MCP:[/] registered in ~/.claude/settings.json")
            else:
                console.print("\n[yellow]MCP:[/] not registered (run [cyan]forgemem init[/])")
        except Exception:
            console.print("\n[yellow]MCP:[/] could not parse ~/.claude/settings.json")

    # Ollama health (only shown when ollama is the active provider)
    from forgemem import config as fm_cfg
    from forgemem.config import detect_ollama

    if fm_cfg.get_provider() == "ollama":
        console.print("\n[bold]Ollama:[/]")
        ollama = detect_ollama()
        if ollama:
            console.print(f"  [green]✓ running[/] at {ollama['url']}")
            if ollama["models"]:
                console.print("  Models: " + ", ".join(ollama["models"][:8]))
            else:
                console.print("  [yellow]No models pulled.[/] Run: ollama pull llama3.2")
        else:
            url = fm_cfg.get_ollama_url()
            console.print(f"  [red]✗ not reachable[/] at {url}")
            console.print("  Start with: [cyan]ollama serve[/]")


@app.command()
def search(
    query: str,
    k: int = typer.Option(5, help="Max results"),
    project: Optional[str] = typer.Option(None),
    type: Optional[str] = typer.Option(None, help="success|failure|plan|note"),
    format: str = typer.Option("md", help="md|json"),
):
    """Search memory traces and principles."""
    from forgemem.core import cmd_retrieve

    args = argparse.Namespace(
        query=query,
        k=k,
        project=project,
        type=type,
        format=format,
    )
    cmd_retrieve(args)


@app.command()
def store(
    content: str,
    type: str = typer.Option("note", help="success|failure|plan|note"),
    project: Optional[str] = typer.Option(None),
    session: Optional[str] = typer.Option(None),
    distill: bool = typer.Option(False),
    principle: Optional[str] = typer.Option(None),
):
    """Save a memory trace."""
    from forgemem.core import cmd_save

    # Auto-detect project from git if not passed
    if project is None:
        project = _detect_project_from_git()

    args = argparse.Namespace(
        type=type,
        content=content,
        project=project,
        session=session,
        distill=distill,
        principle=principle,
        score=5,
        tags=None,
    )
    cmd_save(args)


@app.command()
def mine():
    """Run the memory scanner."""
    from forgemem import scanner
    scanner.run()


@app.command()
def distill(target: str = typer.Argument("all")):
    """Distill undistilled traces into principles."""
    from forgemem.core import cmd_distill

    # target can be a session id or "all"
    session = None if target == "all" else target
    args = argparse.Namespace(
        session=session,
        project=None,
    )
    cmd_distill(args)


@app.command()
def config(
    provider: Optional[str] = typer.Argument(None, help="Provider: anthropic | openai | gemini | ollama | forgemem"),
    key: Optional[str] = typer.Option(None, "--key", "-k", help="API key for the provider (stored locally)"),
    model: Optional[str] = typer.Option(None, "--model", "-m", help="Override default model for this provider"),
    ollama_url: Optional[str] = typer.Option(None, "--ollama-url", help="Ollama base URL (default: http://localhost:11434)"),
    show: bool = typer.Option(False, "--show", help="Print current config (masks keys)"),
):
    """Configure AI provider and API keys.

    Examples:\n
      forgemem config                                    # show current config\n
      forgemem config anthropic --key sk-ant-...         # set provider + key\n
      forgemem config openai --key sk-...                # switch to OpenAI\n
      forgemem config gemini --key AIza...               # switch to Gemini\n
      forgemem config ollama                             # use local Ollama (free, private)\n
      forgemem config ollama --model llama3.2            # use specific Ollama model\n
      forgemem config ollama --ollama-url http://host:11434  # remote Ollama\n
      forgemem config forgemem                           # use Forgemem starter inference\n
    """
    from forgemem import config as fm_cfg

    if provider is None or show:
        current = fm_cfg.load()
        active = current.get("provider", "anthropic")
        keys = current.get("api_keys", {})
        masked = {p: v[:8] + "..." + v[-4:] if len(v) > 12 else "***" for p, v in keys.items()}
        ollama_info = f"\n[bold]Ollama URL:[/] {fm_cfg.get_ollama_url()}" if active == "ollama" else ""
        console.print(Panel(
            f"[bold]Provider:[/] {active}\n"
            f"[bold]Model:[/]    {current.get('model') or fm_cfg.DEFAULT_MODELS.get(active, 'default')}\n"
            f"[bold]Config:[/]   {fm_cfg.CONFIG_PATH}\n"
            f"[bold]Keys:[/]     {masked or '(none stored — using env vars)'}"
            + ollama_info,
            title="Forgemem Config",
        ))
        return

    if provider not in fm_cfg.SUPPORTED_PROVIDERS:
        console.print(f"[red]Unknown provider '{provider}'.[/] Choose: {', '.join(fm_cfg.SUPPORTED_PROVIDERS)}")
        raise typer.Exit(1)

    fm_cfg.set_provider(provider, api_key=key)

    if provider == "ollama":
        from forgemem.config import detect_ollama
        ollama = detect_ollama()
        if ollama:
            console.print(f"[cyan]Ollama detected[/] at {ollama['url']}")
            if ollama["models"]:
                console.print("  Available models: " + ", ".join(ollama["models"][:8]))
                if not model:
                    model = ollama["models"][0]
                    console.print(f"[green]Auto-selected model:[/] {model}")
            else:
                console.print("  [yellow]No models pulled yet.[/] Run: ollama pull llama3.2")
        else:
            console.print("[yellow]Ollama not detected[/] at default port. Start it with: ollama serve")

    cfg_data = fm_cfg.load()
    if model:
        cfg_data["model"] = model
        fm_cfg.save(cfg_data)
    if ollama_url and provider == "ollama":
        cfg_data["ollama_url"] = ollama_url
        fm_cfg.save(cfg_data)

    msg = f"[green]Provider set to:[/] {provider}"
    if provider == "ollama":
        url = ollama_url or fm_cfg.get_ollama_url()
        used_model = model or fm_cfg.DEFAULT_MODELS["ollama"]
        msg += f"\n[dim]Ollama URL:[/] {url}"
        msg += f"\n[dim]Model:[/] {used_model}"
        msg += "\n[green]Inference runs locally — your traces never leave your machine.[/]"
    elif key:
        msg += f"\n[green]API key stored[/] in {fm_cfg.CONFIG_PATH}"
    else:
        msg += "\n[dim]No key stored — will fall back to env var[/]"
    if provider == "forgemem":
        msg += "\n[yellow]Managed inference coming in v0.3 — for now use BYOK.[/]"
    console.print(msg)


@app.command()
def auth(
    action: str = typer.Argument("status", help="login | logout | status"),
):
    """Authenticate with Forgemem for managed inference.

    Examples:\n
      forgemem auth login    # open browser, store token\n
      forgemem auth status   # show current auth state\n
      forgemem auth logout   # remove stored token\n
    """
    import webbrowser
    import http.server
    import threading
    import secrets
    import urllib.parse
    from forgemem import config as fm_cfg

    if action == "status":
        token = fm_cfg.load().get("forgemem_token")
        if token:
            console.print("[green]Authenticated[/] with Forgemem Inference")
            console.print(f"[dim]Token: {token[:8]}...{token[-4:]}[/]")
            console.print("Run [bold]forgemem config[/] to see full provider state.")
        else:
            console.print("[yellow]Not authenticated.[/] Run: forgemem auth login")
        return

    if action == "logout":
        cfg_data = fm_cfg.load()
        if "forgemem_token" in cfg_data:
            del cfg_data["forgemem_token"]
            fm_cfg.save(cfg_data)
            console.print("[green]Logged out.[/] Token removed.")
        else:
            console.print("[dim]Not logged in.[/]")
        return

    if action == "login":
        port = 47474
        state = secrets.token_urlsafe(16)
        received_token: dict = {}

        class _Handler(http.server.BaseHTTPRequestHandler):
            def do_GET(self):
                parsed = urllib.parse.urlparse(self.path)
                params = urllib.parse.parse_qs(parsed.query)
                if params.get("state", [""])[0] == state and "token" in params:
                    received_token["value"] = params["token"][0]
                    self.send_response(200)
                    self.end_headers()
                    self.wfile.write(b"<h2>Authenticated! You can close this tab.</h2>")
                else:
                    self.send_response(400)
                    self.end_headers()

            def log_message(self, *args):  # silence request logs
                pass

        server = http.server.HTTPServer(("127.0.0.1", port), _Handler)

        def _serve():
            server.handle_request()  # handle one request then stop

        t = threading.Thread(target=_serve, daemon=True)
        t.start()

        login_url = (
            f"https://app.forgemem.com/cli-auth"
            f"?callback=http://127.0.0.1:{port}/callback"
            f"&state={state}"
        )
        console.print(f"Opening browser to authenticate...\n{login_url}")
        webbrowser.open(login_url)
        console.print("[dim]Waiting for browser callback (Ctrl+C to cancel)...[/]")

        t.join(timeout=120)

        if received_token.get("value"):
            cfg_data = fm_cfg.load()
            cfg_data["forgemem_token"] = received_token["value"]
            cfg_data["provider"] = "forgemem"
            fm_cfg.save(cfg_data)
            console.print("[green]Authenticated![/] Provider set to Forgemem Inference.")
            console.print("[dim]Your $5 free credits are ready.[/]")
        else:
            console.print("[red]Login timed out or was cancelled.[/]")
            raise typer.Exit(1)
        return

    console.print(f"[red]Unknown action '{action}'.[/] Use: login | logout | status")
    raise typer.Exit(1)


@app.command()
def skill(
    action: str = typer.Argument("generate"),
    agent: Optional[str] = typer.Option(None, help="claude|gemini|codex"),
    dry_run: bool = typer.Option(False),
):
    """Generate, update, or list agent skill files."""
    if action == "list":
        console.print("[bold]Installed skills:[/]")
        for a, path in SKILL_PATHS.items():
            status_str = "[green]installed[/]" if path.exists() else "[dim]not installed[/]"
            console.print(f"  {a}: {path} — {status_str}")
        return

    if action in ("generate", "update"):
        agents_to_process: list[str]
        if agent:
            if agent not in SKILL_PATHS:
                console.print(f"[red]error:[/] unknown agent '{agent}'. Use claude|gemini|codex.")
                raise typer.Exit(1)
            agents_to_process = [agent]
        else:
            agents_to_process = list(SKILL_PATHS.keys())

        for a in agents_to_process:
            _generate_skill(a, dry_run=dry_run)
        return

    console.print(f"[red]error:[/] unknown action '{action}'. Use generate|update|list.")
    raise typer.Exit(1)


@app.command(hidden=True)
def mcp(http: bool = typer.Option(False)):
    """Run the MCP server (stdio only in v0.1)."""
    if http:
        console.print("[yellow]warning:[/] HTTP mode not supported in v0.1. Running stdio.", err=True)

    from forgemem import mcp_server
    mcp_server.mcp.run()


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------


def main():
    app()


if __name__ == "__main__":
    main()
