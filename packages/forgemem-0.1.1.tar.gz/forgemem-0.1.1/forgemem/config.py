"""
Forgemem provider configuration.
Stored at ~/.forgemem/config.json — never sent to Forgemem servers.
"""

import json
import os
from pathlib import Path

CONFIG_PATH = Path(os.environ.get("FORGEMEM_CONFIG", Path.home() / ".forgemem" / "config.json"))

SUPPORTED_PROVIDERS = ("anthropic", "openai", "gemini", "ollama", "forgemem")

DEFAULT_MODELS = {
    "anthropic": "claude-haiku-4-5-20251001",
    "openai": "gpt-4o-mini",
    "gemini": "gemini-1.5-flash",
    "ollama": "phi3.5",  # auto-detected from running instance if available
    "forgemem": "claude-haiku-4-5-20251001",  # managed — model chosen server-side
}

OLLAMA_DEFAULT_URL = "http://localhost:11434"


def load() -> dict:
    if CONFIG_PATH.exists():
        try:
            return json.loads(CONFIG_PATH.read_text())
        except (json.JSONDecodeError, OSError):
            pass
    return {}


def save(cfg: dict) -> None:
    CONFIG_PATH.parent.mkdir(parents=True, exist_ok=True)
    CONFIG_PATH.write_text(json.dumps(cfg, indent=2))


def get_provider() -> str:
    return load().get("provider", "anthropic")


def get_api_key(provider: str) -> str | None:
    """Config file takes precedence over env vars. Ollama needs no key."""
    if provider == "ollama":
        return None
    cfg = load()
    key_in_config = cfg.get("api_keys", {}).get(provider)
    if key_in_config:
        return key_in_config
    env_map = {
        "anthropic": "ANTHROPIC_API_KEY",
        "openai": "OPENAI_API_KEY",
        "gemini": "GEMINI_API_KEY",
    }
    return os.environ.get(env_map.get(provider, ""))


def get_ollama_url() -> str:
    return load().get("ollama_url") or os.environ.get("OLLAMA_HOST", OLLAMA_DEFAULT_URL)


def detect_ollama() -> dict | None:
    """Probe local (and OLLAMA_HOST) for a running Ollama instance.

    Returns {'url': str, 'models': list[str]} or None if not reachable.
    Uses /api/tags — no auth required, 2s timeout to stay non-blocking.
    """
    import requests
    url = os.environ.get("OLLAMA_HOST", OLLAMA_DEFAULT_URL).rstrip("/")
    try:
        resp = requests.get(f"{url}/api/tags", timeout=2)
        if resp.ok:
            models = [m["name"] for m in resp.json().get("models", [])]
            return {"url": url, "models": models}
    except Exception:
        pass
    return None


def get_model(provider: str) -> str:
    return load().get("model") or DEFAULT_MODELS.get(provider, DEFAULT_MODELS["anthropic"])


def set_provider(provider: str, api_key: str | None = None) -> None:
    if provider not in SUPPORTED_PROVIDERS:
        raise ValueError(f"Unknown provider '{provider}'. Choose: {', '.join(SUPPORTED_PROVIDERS)}")
    cfg = load()
    cfg["provider"] = provider
    if api_key:
        cfg.setdefault("api_keys", {})[provider] = api_key
    save(cfg)


def set_api_key(provider: str, api_key: str) -> None:
    cfg = load()
    cfg.setdefault("api_keys", {})[provider] = api_key
    save(cfg)
