#!/usr/bin/env python3
"""
Integration test that exercises ALL LLM routes in a single comprehensive flow.
This test validates the complete lifecycle of LLM configurations.
"""

import os
import sys
from datetime import datetime

try:
    from dotenv import load_dotenv
except ImportError:
    load_dotenv = None

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from az_cortex_sdk import CortexClient

# ANSI color codes
GREEN = '\033[92m'
RED = '\033[91m'
BLUE = '\033[94m'
RESET = '\033[0m'
BOLD = '\033[1m'

def print_header(text: str):
    print(f"\n{BOLD}{BLUE}{'='*80}{RESET}")
    print(f"{BOLD}{BLUE}  {text}{RESET}")
    print(f"{BOLD}{BLUE}{'='*80}{RESET}\n")

def print_step(num: int, text: str):
    print(f"\n{BOLD}Step {num}: {text}{RESET}")

def print_success(text: str):
    print(f"{GREEN}✓{RESET} {text}")

def print_error(text: str):
    print(f"{RED}✗{RESET} {text}")

def print_info(text: str):
    print(f"  {text}")

def main():
    # Load environment
    if load_dotenv:
        load_dotenv('.env_llm')
        load_dotenv('.env')

    print_header("Complete LLM Routes Integration Test")

    client = CortexClient.from_env()
    timestamp = datetime.now().strftime("%Y%m%d-%H%M%S")

    # Get credentials
    api_key = os.getenv("AZURE_OPENAI_API_KEY")
    endpoint = os.getenv("AZURE_OPENAI_ENDPOINT")
    deployment = os.getenv("AZURE_OPENAI_DEPLOYMENT")
    model = os.getenv("AZURE_OPENAI_MODEL")

    config_name_1 = f"integration-test-1-{timestamp}"
    config_name_2 = f"integration-test-2-{timestamp}"

    try:
        # ===== ROUTE 1: POST /llm (Create) =====
        print_step(1, "POST /llm - Create LLM configuration with api_key")
        config1 = client.llm.create(
            config_name=config_name_1,
            provider="azure-openai",
            model=model,
            api_key=api_key,
            endpoint=endpoint,
            deployment=deployment,
            default_parameters={
                "temperature": 0.7,
                "max_tokens": 500
            }
        )
        print_success(f"Created config: {config1.config_name}")
        print_info(f"Secret: {config1.secret_name}")
        print_info(f"Provider: {config1.provider}")
        print_info(f"Model: {config1.model}")

        # ===== ROUTE 2: GET /llm (List) =====
        print_step(2, "GET /llm - List all LLM configurations")
        configs = client.llm.list()
        print_success(f"Found {configs.total} total configurations")
        print_info(f"Current page has {len(configs.items)} items")
        assert any(c.config_name == config_name_1 for c in configs.items), "Config should be in list"

        # ===== ROUTE 3: GET /llm/:configName (Get) =====
        print_step(3, "GET /llm/:configName - Get specific configuration")
        retrieved = client.llm.get(config_name_1)
        print_success(f"Retrieved config: {retrieved.config_name}")
        print_info(f"ID: {retrieved.id}")
        print_info(f"Created: {retrieved.created_date}")
        assert retrieved.config_name == config_name_1, "Config name should match"
        assert retrieved.secret_name == f"llm-{config_name_1}", "Secret name should match"

        # ===== ROUTE 4: PUT /llm/:configName (Update) =====
        print_step(4, "PUT /llm/:configName - Update configuration")
        updated = client.llm.update(
            config_name=config_name_1,
            model="gpt-4",
            default_parameters={
                "temperature": 0.9,
                "max_tokens": 1000
            }
        )
        print_success(f"Updated config: {updated.config_name}")
        print_info(f"New model: {updated.model}")
        print_info(f"New temperature: {updated.default_parameters.temperature}")
        assert updated.default_parameters.temperature == 0.9, "Temperature should be updated"

        # ===== ROUTE 5: POST /llm/infer (Inference) =====
        print_step(5, "POST /llm/infer - Perform inference")
        messages = [
            {"role": "system", "content": "You are a helpful assistant. Be very concise."},
            {"role": "user", "content": "Say 'Test successful!' and nothing else."}
        ]
        result = client.llm.infer(config_name_1, messages)
        print_success("Inference completed")
        print_info(f"Inference type: {result.inference_type}")
        print_info(f"LLM config name: {result.llm_config_name}")
        response_text = result.outputs['messages'][0]['content'] if 'messages' in result.outputs else 'N/A'
        print_info(f"Response: {response_text[:100]}")
        print_info(f"Duration: {result.duration}ms")
        assert result.inference_type == 'llm', "Should be LLM inference"
        assert result.llm_config_name == config_name_1, "Config name should match"

        # ===== ROUTE 6: POST /llm/infer/stream (Streaming Inference) =====
        print_step(6, "POST /llm/infer/stream - Perform streaming inference")
        stream_messages = [
            {"role": "user", "content": "Count from 1 to 3."}
        ]
        print("  Streaming response: ", end="")

        chunks = []
        for event in client.llm.infer_stream(config_name_1, stream_messages):
            if event['type'] == 'chunk':
                chunks.append(event['content'])
                print(event['content'], end='', flush=True)
            elif event['type'] == 'done':
                print()  # New line
                print_success(f"Streaming completed with {len(chunks)} chunks")
                if 'usage' in event:
                    print_info(f"Usage: {event['usage']}")

        assert len(chunks) > 0, "Should receive chunks"

        # ===== ROUTE 7: Create second config for testing =====
        print_step(7, "POST /llm - Create second configuration")
        config2 = client.llm.create(
            config_name=config_name_2,
            provider="azure-openai",
            model=model,
            api_key=api_key,
            endpoint=endpoint,
            deployment=deployment
        )
        print_success(f"Created second config: {config2.config_name}")

        # ===== ROUTE 8: PUT /llm/:configName/archive (Archive) =====
        print_step(8, "PUT /llm/:configName/archive - Archive configuration")
        archived = client.llm.archive(config_name_1)
        print_success(f"Archived config: {archived.config_name}")
        print_info(f"Is archived: {archived.is_archived}")
        assert archived.is_archived, "Should be archived"

        # ===== ROUTE 9: GET /llm with is_archived filter =====
        print_step(9, "GET /llm?is_archived=false - List non-archived configs")
        active_configs = client.llm.list(is_archived=False)
        active_names = [c.config_name for c in active_configs.items]
        print_success(f"Found {len(active_configs.items)} active configurations")
        assert config_name_1 not in active_names, "Archived config should not appear"
        assert config_name_2 in active_names, "Active config should appear"

        print_step(10, "GET /llm?is_archived=true - List archived configs")
        archived_configs = client.llm.list(is_archived=True)
        archived_names = [c.config_name for c in archived_configs.items]
        print_success(f"Found {len(archived_configs.items)} archived configurations")
        assert config_name_1 in archived_names, "Archived config should appear"

        # ===== ROUTE 10: DELETE /llm/:configName (Hard Delete) =====
        print_step(11, "DELETE /llm/:configName - Hard delete configurations")

        # Delete first config
        result1 = client.llm.delete(config_name_1)
        print_success(f"Deleted {config_name_1}")
        print_info(f"Message: {result1.message}")

        # Delete second config
        result2 = client.llm.delete(config_name_2)
        print_success(f"Deleted {config_name_2}")
        print_info(f"Message: {result2.message}")

        # ===== ROUTE 11: Verify deletion =====
        print_step(12, "GET /llm/:configName - Verify configs are deleted")
        try:
            client.llm.get(config_name_1)
            print_error("Config 1 still exists!")
            return 1
        except Exception:
            print_success("Config 1 successfully deleted")

        try:
            client.llm.get(config_name_2)
            print_error("Config 2 still exists!")
            return 1
        except Exception:
            print_success("Config 2 successfully deleted")

        # ===== SUCCESS =====
        print_header("Integration Test Results")
        print_success("All routes tested successfully!")
        print_info("\nRoutes validated:")
        print_info("  ✓ POST   /llm                    (Create)")
        print_info("  ✓ GET    /llm                    (List)")
        print_info("  ✓ GET    /llm/:configName        (Get)")
        print_info("  ✓ PUT    /llm/:configName        (Update)")
        print_info("  ✓ POST   /llm/infer              (Inference)")
        print_info("  ✓ POST   /llm/infer/stream       (Streaming)")
        print_info("  ✓ PUT    /llm/:configName/archive (Archive)")
        print_info("  ✓ DELETE /llm/:configName        (Delete)")
        print_info("  ✓ GET    /llm?is_archived=...    (Filter)")

        print(f"\n{GREEN}{BOLD}🎉 Complete integration test passed!{RESET}\n")
        return 0

    except Exception as e:
        print_error(f"\nIntegration test failed: {e}")
        import traceback
        traceback.print_exc()

        # Cleanup on failure
        print("\nCleaning up...")
        try:
            client.llm.delete(config_name_1)
            print_success(f"Cleaned up {config_name_1}")
        except:
            pass
        try:
            client.llm.delete(config_name_2)
            print_success(f"Cleaned up {config_name_2}")
        except:
            pass

        return 1

if __name__ == "__main__":
    sys.exit(main())

"""Integration tests for environment management."""

import time

import pytest

from az_cortex_sdk.exceptions import APIError, NotFoundError


@pytest.mark.integration
class TestEnvironmentsIntegration:
    """Integration tests for environment operations."""

    def test_list_environments(self, integration_client: CortexClient):
        """Test listing environments."""
        environments = integration_client.environments.list()

        assert environments is not None
        assert hasattr(environments, 'items')
        assert isinstance(environments.items, list)

        # Check structure of first environment if any exist
        if environments.items:
            env = environments.items[0]
            assert hasattr(env, 'name')
            assert hasattr(env, 'id')

    def test_environment_crud_operations(
        self,
        integration_client: CortexClient,
        test_environment_name: str,
        cleanup_environments
    ):
        """Test complete CRUD operations for environments."""
        version = "1.0.0"
        cleanup_environments(test_environment_name, version)

        # Create environment
        result = integration_client.environments.create(
            name=test_environment_name,
            version=version,
            description="Integration test environment",
            image="mcr.microsoft.com/azureml/minimal-ubuntu20.04-py38-cpu-inference:latest",
            tags={"test": "integration", "sdk": "az-cortex-sdk"},
            properties={"purpose": "testing"}
        )

        assert result is not None
        assert result.success is True
        assert result.name == test_environment_name
        assert result.version == version

        # Wait a moment for the environment to be available
        time.sleep(2)

        # Get the created environment
        env = integration_client.environments.get(test_environment_name, version)
        assert env is not None
        assert env.name == test_environment_name
        assert env.version == version
        assert env.description == "Integration test environment"

        # Update environment
        update_result = integration_client.environments.update(
            name=test_environment_name,
            version=version,
            description="Updated integration test environment",
            tags={"test": "integration", "sdk": "az-cortex-sdk", "updated": "true"}
        )

        assert update_result is not None
        assert update_result.success is True

        # Verify update
        updated_env = integration_client.environments.get(test_environment_name, version)
        assert updated_env is not None
        assert updated_env.description == "Updated integration test environment"

        # Test listing with the new environment
        environments = integration_client.environments.list()
        env_names = [env.name for env in environments.items]
        assert test_environment_name in env_names

    def test_environment_not_found(self, integration_client: CortexClient):
        """Test handling of non-existent environment."""
        with pytest.raises(NotFoundError):
            integration_client.environments.get("non-existent-env", "1.0.0")

    def test_environment_validation_errors(self, integration_client: CortexClient):
        """Test validation errors for invalid environment data."""
        with pytest.raises((APIError, ValueError)):
            integration_client.environments.create(
                name="",  # Invalid empty name
                version="1.0.0",
                description="Test environment"
            )

        with pytest.raises((APIError, ValueError)):
            integration_client.environments.create(
                name="test-env",
                version="",  # Invalid empty version
                description="Test environment"
            )

    def test_environment_list_pagination(self, integration_client: CortexClient):
        """Test environment listing with pagination."""
        # Test with small page size
        environments = integration_client.environments.list(page=1, per_page=5)

        assert environments is not None
        assert hasattr(environments, 'items')
        assert len(environments.items) <= 5

        if hasattr(environments, 'total_documents'):
            assert environments.total_documents >= 0
        if hasattr(environments, 'page'):
            assert environments.page == 1
        if hasattr(environments, 'per_page'):
            assert environments.per_page == 5
"""Integration tests for model management."""

import pickle
import tempfile
from pathlib import Path

import pytest

from az_cortex_sdk import CortexClient


@pytest.mark.integration
class TestModelsIntegration:
    """Integration tests for model operations."""

    def test_list_models(self, integration_client: CortexClient):
        """Test listing models."""
        models = integration_client.models.list()

        assert models is not None
        assert hasattr(models, 'items')
        assert isinstance(models.items, list)

        # Check structure of first model if any exist
        if models.items:
            model = models.items[0]
            assert hasattr(model, 'name')
            assert hasattr(model, 'id')

    def test_model_crud_operations(
        self,
        integration_client: CortexClient,
        test_model_name: str,
        cleanup_models
    ):
        """Test complete CRUD operations for models."""
        version = "1.0.0"
        cleanup_models(test_model_name, version)

        # Create a simple test model file
        test_data = {"model_type": "test", "parameters": [1, 2, 3]}

        with tempfile.NamedTemporaryFile(suffix=".pkl", delete=False) as tmp_file:
            pickle.dump(test_data, tmp_file)
            tmp_file.flush()

            try:
                # Upload and create model
                result = integration_client.models.upload_and_create(
                    file_path=tmp_file.name,
                    name=test_model_name,
                    version=version,
                    description="Integration test model",
                    model_type="custom",
                    tags={"test": "integration", "sdk": "az-cortex-sdk"},
                    properties={"framework": "test", "accuracy": "0.95"}
                )

                assert result is not None
                assert "upload_result" in result
                assert "registration_result" in result

                upload_result = result["upload_result"]
                assert upload_result.success is True
                assert upload_result.file_name.endswith(".pkl")

                reg_result = result["registration_result"]
                assert reg_result.success is True
                assert reg_result.name == test_model_name
                assert reg_result.version == version

                # Wait a moment for the model to be available
                time.sleep(2)

                # Get the created model
                model = integration_client.models.get(test_model_name, version)
                assert model is not None
                assert model.name == test_model_name
                assert model.version == version
                assert model.description == "Integration test model"

                # Test listing with the new model
                models = integration_client.models.list()
                model_names = [model.name for model in models.items]
                assert test_model_name in model_names

            finally:
                # Clean up temp file
                Path(tmp_file.name).unlink(missing_ok=True)

    def test_model_buffer_upload(
        self,
        integration_client: CortexClient,
        test_model_name: str,
        cleanup_models
    ):
        """Test uploading model from buffer."""
        version = "2.0.0"
        cleanup_models(test_model_name, version)

        # Create test data
        test_data = {"model_type": "buffer_test", "data": "test_content"}
        buffer_data = pickle.dumps(test_data)

        # Upload from buffer
        result = integration_client.models.upload_buffer_and_create(
            buffer=buffer_data,
            file_name="test_model.pkl",
            name=test_model_name,
            version=version,
            description="Buffer upload test model",
            model_type="custom",
            tags={"test": "buffer", "sdk": "az-cortex-sdk"}
        )

        assert result is not None
        assert "upload_result" in result
        assert "registration_result" in result

        upload_result = result["upload_result"]
        assert upload_result.success is True
        assert upload_result.file_name == "test_model.pkl"
        assert upload_result.size_bytes == len(buffer_data)

        reg_result = result["registration_result"]
        assert reg_result.success is True
        assert reg_result.name == test_model_name
        assert reg_result.version == version

    def test_model_not_found(self, integration_client: CortexClient):
        """Test handling of non-existent model."""
        with pytest.raises(NotFoundError):
            integration_client.models.get("non-existent-model", "1.0.0")

    def test_model_validation_errors(self, integration_client: CortexClient):
        """Test validation errors for invalid model data."""
        with tempfile.NamedTemporaryFile(suffix=".pkl", delete=False) as tmp_file:
            pickle.dump({"test": "data"}, tmp_file)
            tmp_file.flush()

            try:
                with pytest.raises((APIError, ValueError)):
                    integration_client.models.upload_and_create(
                        file_path=tmp_file.name,
                        name="",  # Invalid empty name
                        version="1.0.0",
                        description="Test model"
                    )

                with pytest.raises((APIError, ValueError)):
                    integration_client.models.upload_and_create(
                        file_path=tmp_file.name,
                        name="test-model",
                        version="",  # Invalid empty version
                        description="Test model"
                    )
            finally:
                Path(tmp_file.name).unlink(missing_ok=True)

    def test_model_list_pagination(self, integration_client: CortexClient):
        """Test model listing with pagination."""
        # Test with small page size
        models = integration_client.models.list(page=1, per_page=5)

        assert models is not None
        assert hasattr(models, 'items')
        assert len(models.items) <= 5

        if hasattr(models, 'total_documents'):
            assert models.total_documents >= 0
        if hasattr(models, 'page'):
            assert models.page == 1
        if hasattr(models, 'per_page'):
            assert models.per_page == 5

    def test_model_file_not_found(self, integration_client: CortexClient):
        """Test handling of non-existent file."""
        result = integration_client.models.upload_and_create(
            file_path="/non/existent/file.pkl",
            name="test-model",
            version="1.0.0",
            description="Test model"
        )

        assert result is not None
        assert "upload_result" in result
        upload_result = result["upload_result"]
        assert upload_result.success is False
        assert "not found" in upload_result.error.lower()
"""Integration tests for error handling and edge cases."""


import pytest

from az_cortex_sdk import CortexClient, CortexConfig
from az_cortex_sdk.exceptions import (
    AuthenticationError,
    RateLimitError,
    ValidationError,
)


@pytest.mark.integration
class TestErrorHandlingIntegration:
    """Integration tests for error handling scenarios."""

    def test_authentication_failure(self):
        """Test authentication failure with invalid credentials."""
        config = CortexConfig(
            base_url="https://api.az-dev.nearlyhuman.ai",
            client_id="invalid-client-id",
            client_secret="invalid-client-secret",
            tenant="demo"
        )

        client = CortexClient(config=config)

        with pytest.raises(AuthenticationError):
            client.environments.list()

    def test_invalid_base_url(self):
        """Test handling of invalid base URL."""
        config = CortexConfig(
            base_url="https://invalid-url-that-does-not-exist.com",
            client_id="test-id",
            client_secret="test-secret",
            tenant="demo"
        )

        client = CortexClient(config=config)

        with pytest.raises((APIError, ConnectionError)):
            client.environments.list()

    def test_not_found_errors(self, integration_client: CortexClient):
        """Test NotFoundError for non-existent resources."""
        # Test non-existent environment
        with pytest.raises(NotFoundError):
            integration_client.environments.get("non-existent-env-12345", "1.0.0")

        # Test non-existent model
        with pytest.raises(NotFoundError):
            integration_client.models.get("non-existent-model-12345", "1.0.0")

    def test_validation_errors(self, integration_client: CortexClient):
        """Test validation errors for invalid input data."""
        # Test empty environment name
        with pytest.raises((ValidationError, APIError)):
            integration_client.environments.create(
                name="",  # Invalid empty name
                version="1.0.0",
                description="Test environment"
            )

        # Test empty model name
        with tempfile.NamedTemporaryFile(suffix=".pkl", delete=False) as tmp_file:
            tmp_file.write(b"test data")
            tmp_file.flush()

            try:
                with pytest.raises((ValidationError, APIError)):
                    integration_client.models.upload_and_create(
                        file_path=tmp_file.name,
                        name="",  # Invalid empty name
                        version="1.0.0",
                        description="Test model"
                    )
            finally:
                Path(tmp_file.name).unlink(missing_ok=True)

    def test_invalid_version_format(self, integration_client: CortexClient):
        """Test handling of invalid version formats."""
        with pytest.raises((ValidationError, APIError)):
            integration_client.environments.create(
                name="test-env",
                version="invalid.version.format.with.too.many.parts",
                description="Test environment"
            )

    def test_large_file_upload(self, integration_client: CortexClient):
        """Test handling of large file uploads."""
        # Create a moderately large file (1MB) to test upload limits
        large_data = b"x" * (1024 * 1024)  # 1MB

        with tempfile.NamedTemporaryFile(suffix=".bin", delete=False) as tmp_file:
            tmp_file.write(large_data)
            tmp_file.flush()

            try:
                # This should either succeed or fail gracefully
                result = integration_client.models.upload_and_create(
                    file_path=tmp_file.name,
                    name="large-file-test",
                    version="1.0.0",
                    description="Large file upload test",
                    model_type="binary"
                )

                # If it succeeds, verify the upload
                if result["upload_result"].success:
                    assert result["upload_result"].size_bytes == len(large_data)
                else:
                    # If it fails, it should be a clear error message
                    assert result["upload_result"].error is not None

            except APIError as e:
                # Should be a clear error about file size limits
                assert "size" in str(e).lower() or "limit" in str(e).lower()
            finally:
                Path(tmp_file.name).unlink(missing_ok=True)

    def test_concurrent_requests(self, integration_client: CortexClient):
        """Test handling of concurrent requests."""
        import concurrent.futures

        def list_environments():
            """Helper function to list environments."""
            return integration_client.environments.list()

        # Make multiple concurrent requests
        with concurrent.futures.ThreadPoolExecutor(max_workers=5) as executor:
            futures = [executor.submit(list_environments) for _ in range(5)]

            results = []
            for future in concurrent.futures.as_completed(futures):
                try:
                    result = future.result(timeout=30)
                    results.append(result)
                except Exception as e:
                    # Some requests might fail due to rate limiting
                    if not isinstance(e, RateLimitError):
                        raise

        # At least some requests should succeed
        assert len(results) > 0

    def test_malformed_response_handling(self, integration_client: CortexClient):
        """Test handling of unexpected response formats."""
        # This test verifies that the SDK can handle unexpected API responses
        # The actual test depends on the API behavior, but we test basic robustness

        try:
            # Make a request that should return a well-formed response
            environments = integration_client.environments.list()

            # Verify the response has expected structure
            assert hasattr(environments, 'items')
            assert isinstance(environments.items, list)

        except Exception as e:
            # If there's an error, it should be a known exception type
            assert isinstance(e, (APIError, ValidationError, NotFoundError, AuthenticationError))

    def test_timeout_handling(self):
        """Test timeout handling with very short timeout."""
        config = CortexConfig(
            base_url="https://api.az-dev.nearlyhuman.ai",
            client_id="test-id",
            client_secret="test-secret",
            tenant="demo",
            timeout=0.001  # Very short timeout
        )

        client = CortexClient(config=config)

        with pytest.raises((APIError, TimeoutError)):
            client.environments.list()

    def test_retry_mechanism(self, integration_client: CortexClient):
        """Test that retry mechanism works for transient failures."""
        # This is hard to test directly, but we can verify that the client
        # has retry configuration and doesn't fail immediately on network issues

        assert integration_client.config.max_retries > 0
        assert integration_client.config.retry_delay > 0

        # Make a request that should succeed with retries
        environments = integration_client.environments.list()
        assert environments is not None

    def test_special_characters_in_names(self, integration_client: CortexClient):
        """Test handling of special characters in resource names."""
        # Test names with special characters that might cause issues
        special_names = [
            "test-with-dashes",
            "test_with_underscores",
            "test.with.dots",
            "test123with456numbers"
        ]

        for name in special_names:
            try:
                # Try to create environment with special name
                result = integration_client.environments.create(
                    name=name,
                    version="1.0.0",
                    description=f"Test environment with special name: {name}",
                    image="mcr.microsoft.com/azureml/minimal-ubuntu20.04-py38-cpu-inference:latest"
                )

                # If creation succeeds, the name should be preserved
                if result.success:
                    assert result.name == name

            except (ValidationError, APIError) as e:
                # If it fails, it should be a clear validation error
                assert "name" in str(e).lower() or "invalid" in str(e).lower()

    @pytest.mark.slow
    def test_pagination_edge_cases(self, integration_client: CortexClient):
        """Test pagination with edge cases."""
        # Test very large page size
        try:
            environments = integration_client.environments.list(page=1, per_page=10000)
            assert environments is not None
        except APIError as e:
            # Should be a clear error about page size limits
            assert "page" in str(e).lower() or "limit" in str(e).lower()

        # Test invalid page numbers
        with pytest.raises(APIError):
            integration_client.environments.list(page=0, per_page=10)

        with pytest.raises(APIError):
            integration_client.environments.list(page=-1, per_page=10)
"""Integration tests for health check endpoints."""

import pytest

from az_cortex_sdk import CortexClient


@pytest.mark.integration
class TestHealthIntegration:
    """Integration tests for health check functionality."""

    def test_health_check(self, integration_client: CortexClient):
        """Test health check endpoint."""
        response = integration_client.health_check()

        assert response is not None
        assert isinstance(response, dict)
        # The exact structure may vary, but we expect some response

    def test_client_connection(self, integration_client: CortexClient):
        """Test that client can connect and authenticate."""
        # This test passes if the client fixture was created successfully
        assert integration_client is not None
        assert integration_client.config is not None
        assert integration_client.config.base_url is not None
