"""Tests for inference and message services."""

from datetime import datetime
from unittest.mock import Mock

from az_cortex_sdk.exceptions import NotFoundError
from az_cortex_sdk.models import Message, PaginatedResponse
from az_cortex_sdk.services.inferences import InferenceService
from az_cortex_sdk.services.messages import MessageService


class TestInferenceService:
    """Test cases for InferenceService."""

    def setup_method(self):
        """Set up test fixtures."""
        self.mock_http_client = Mock()
        self.service = InferenceService(self.mock_http_client)

    def test_list_inferences(self):
        """Test listing inferences."""
        # Mock response
        mock_response = {
            "documents": [
                {
                    "_id": "inference-1",
                    "appName": "test-app",
                    "conversationId": "conv-123",
                    "createdAt": "2024-01-01T00:00:00Z"
                }
            ],
            "totalDocuments": 1,
            "page": 1,
            "perPage": 25
        }
        self.mock_http_client.get.return_value = mock_response

        # Test list
        result = self.service.list()

        # Assertions
        assert isinstance(result, PaginatedResponse)
        assert len(result.items) == 1
        assert result.items[0].id == "inference-1"
        assert result.total == 1
        self.mock_http_client.get.assert_called_once_with(
            "/inferences",
            params={"page": 1, "perPage": 25, "isTestGenerated": "false"}
        )


class TestMessageService:
    """Test cases for MessageService."""

    def setup_method(self):
        """Set up test fixtures."""
        self.mock_http_client = Mock()
        self.service = MessageService(self.mock_http_client)

    def test_list_messages(self):
        """Test listing messages."""
        # Mock response
        mock_response = {
            "documents": [
                {
                    "_id": "msg1",
                    "tenantKey": "demo",
                    "appName": "test-app",
                    "text": "Hello world",
                    "email": "user@example.com",
                    "createdDate": "2024-01-01T12:00:00Z"
                }
            ],
            "totalDocuments": 1,
            "page": 1,
            "perPage": 25
        }
        self.mock_http_client.get.return_value = mock_response

        # Test list
        result = self.service.list(app_name="test-app")

        # Assertions
        assert isinstance(result, PaginatedResponse)
        assert len(result.items) == 1
        assert result.items[0]["_id"] == "msg1"
        assert result.items[0]["text"] == "Hello world"
        assert result.total == 1
        assert result.page == 1
        assert result.per_page == 25
        self.mock_http_client.get.assert_called_once_with(
            "/messages",
            params={"page": 1, "perPage": 25, "appName": "test-app", "isTestGenerated": "false"}
        )

    def test_list_messages_with_filters(self):
        """Test listing messages with multiple filters."""
        # Mock response
        mock_response = {
            "documents": [],
            "totalDocuments": 0,
            "page": 1,
            "perPage": 10
        }
        self.mock_http_client.get.return_value = mock_response

        # Test with filters
        start_date = datetime(2024, 1, 1, 12, 0, 0)
        end_date = datetime(2024, 1, 2, 12, 0, 0)

        self.service.list(
            tenant_key="demo",
            app_name="test-app",
            conversation_id="conv-123",
            email="user@example.com",
            text="hello",
            inference_id="inf-456",
            created_date_start=start_date,
            created_date_end=end_date,
            page=2,
            per_page=10
        )

        # Assertions
        expected_params = {
            "page": 2,
            "perPage": 10,
            "tenantKey": "demo",
            "appName": "test-app",
            "conversationId": "conv-123",
            "email": "user@example.com",
            "text": "hello",
            "inferenceId": "inf-456",
            "createdDateStart": "2024-01-01T12:00:00",
            "createdDateEnd": "2024-01-02T12:00:00",
            "isTestGenerated": "false"
        }
        self.mock_http_client.get.assert_called_once_with("/messages", params=expected_params)

    def test_get_message(self):
        """Test getting a specific message."""
        # Mock response
        mock_response = {
            "_id": "msg1",
            "tenantKey": "demo",
            "appName": "test-app",
            "text": "Hello world",
            "email": "user@example.com",
            "createdDate": "2024-01-01T12:00:00Z"
        }
        self.mock_http_client.get.return_value = mock_response

        # Test get
        result = self.service.get("msg1")

        # Assertions
        assert isinstance(result, Message)
        assert result.id == "msg1"
        assert result.text == "Hello world"
        assert result.email == "user@example.com"
        self.mock_http_client.get.assert_called_once_with("/messages/msg1")

    def test_get_message_not_found(self):
        """Test getting a non-existent message."""
        self.mock_http_client.get.side_effect = NotFoundError("Message not found")

        result = self.service.get("non-existent")

        assert result is None

    def test_create_message(self):
        """Test creating a new message."""
        # Mock response
        mock_response = {
            "_id": "msg1",
            "tenantKey": "demo",
            "appName": "test-app",
            "conversationId": "conv-123",
            "text": "Hello world",
            "email": "user@example.com",
            "ipAddress": "192.168.1.1",
            "createdDate": "2024-01-01T12:00:00Z"
        }
        self.mock_http_client.post.return_value = mock_response

        # Test create
        result = self.service.create(
            tenant_key="demo",
            app_name="test-app",
            conversation_id="conv-123",
            text="Hello world",
            email="user@example.com",
            ip_address="192.168.1.1"
        )

        # Assertions
        assert isinstance(result, Message)
        assert result.id == "msg1"
        assert result.text == "Hello world"
        assert result.email == "user@example.com"
        assert result.ip_address == "192.168.1.1"

        expected_data = {
            "tenantKey": "demo",
            "appName": "test-app",
            "conversationId": "conv-123",
            "text": "Hello world",
            "email": "user@example.com",
            "ipAddress": "192.168.1.1"
        }
        self.mock_http_client.post.assert_called_once_with("/messages", data=expected_data)

    def test_update_message(self):
        """Test updating a message."""
        # Mock response
        mock_response = {
            "_id": "msg1",
            "tenantKey": "demo",
            "appName": "test-app",
            "text": "Updated text",
            "email": "updated@example.com",
            "updatedDate": "2024-01-01T13:00:00Z"
        }
        self.mock_http_client.put.return_value = mock_response

        # Test update
        result = self.service.update(
            "msg1",
            text="Updated text",
            email="updated@example.com"
        )

        # Assertions
        assert isinstance(result, Message)
        assert result.id == "msg1"
        assert result.text == "Updated text"
        assert result.email == "updated@example.com"

        expected_data = {
            "text": "Updated text",
            "email": "updated@example.com"
        }
        self.mock_http_client.put.assert_called_once_with("/messages/msg1", data=expected_data)

    def test_transform_message_data_with_dates(self):
        """Test message data transformation with date parsing."""
        # Test data with ISO date strings
        data = {
            "_id": "msg1",
            "text": "Hello",
            "createdDate": "2024-01-01T12:00:00Z",
            "updatedDate": "2024-01-01T13:00:00.123Z"
        }

        result = self.service._transform_message_data(data)

        # Assertions
        assert result["_id"] == "msg1"
        assert result["text"] == "Hello"
        assert isinstance(result["createdDate"], datetime)
        assert isinstance(result["updatedDate"], datetime)

    def test_transform_message_data_invalid_dates(self):
        """Test message data transformation with invalid dates."""
        # Test data with invalid date strings
        data = {
            "_id": "msg1",
            "text": "Hello",
            "createdDate": "invalid-date",
            "updatedDate": None
        }

        result = self.service._transform_message_data(data)

        # Assertions - invalid dates should be kept as-is
        assert result["_id"] == "msg1"
        assert result["text"] == "Hello"
        assert result["createdDate"] == "invalid-date"
        assert result["updatedDate"] is None
"""Tests for inference service."""

from unittest.mock import patch

import pytest

from az_cortex_sdk import CortexClient, EscalationRoute, Inference, InferenceResponse
from az_cortex_sdk.config import CortexConfig


@pytest.fixture
def mock_client():
    """Create a mock client for testing."""
    config = CortexConfig(
        base_url="https://test.example.com",
        client_id="test-id",
        client_secret="test-secret",
    )

    with patch("az_cortex_sdk.client.HTTPClient") as mock_http_client_class:
        mock_http_instance = Mock()
        mock_http_client_class.return_value = mock_http_instance

        client = CortexClient(config=config)
        client._mock_http_client = mock_http_instance  # Store for easy access in tests

        return client


class TestInferenceService:
    """Test cases for InferenceService."""

    def test_list_inferences_empty(self, mock_client):
        """Test listing inferences when none exist."""
        mock_client._mock_http_client.get.return_value = {
            "documents": [],
            "totalDocuments": 0,
            "page": 1,
            "perPage": 25,
        }

        result = mock_client.inferences.list()

        assert len(result.items) == 0
        assert result.total == 0
        assert result.page == 1
        assert result.per_page == 25
        assert not result.has_next
        assert not result.has_prev

    def test_list_inferences_with_data(self, mock_client):
        """Test listing inferences with data."""
        mock_data = [
            {
                "_id": "inf-123",
                "appName": "demo-app",
                "email": "user@example.com",
                "inferrerName": "test-inferrer",
                "inputs": {"question": "Hello"},
                "outputs": {"answer": "Hi there!"},
                "duration": 150,
                "createdDate": "2023-01-01T00:00:00Z",
            }
        ]

        mock_client._mock_http_client.get.return_value = {
            "documents": mock_data,
            "totalDocuments": 1,
            "page": 1,
            "perPage": 25,
        }

        result = mock_client.inferences.list()

        assert len(result.items) == 1
        assert result.total == 1

        inference = result.items[0]
        assert isinstance(inference, Inference)
        assert inference.id == "inf-123"
        assert inference.app_name == "demo-app"
        assert inference.email == "user@example.com"
        assert inference.inferrer_name == "test-inferrer"
        assert inference.inputs == {"question": "Hello"}
        assert inference.outputs == {"answer": "Hi there!"}
        assert inference.duration == 150

    def test_list_inferences_with_filters(self, mock_client):
        """Test listing inferences with filters."""
        mock_client._mock_http_client.get.return_value = {
            "documents": [],
            "totalDocuments": 0,
            "page": 1,
            "perPage": 10,
        }

        mock_client.inferences.list(
            app_name="demo-app",
            email="user@example.com",
            has_annotation=True,
            page=2,
            per_page=10
        )

        # Verify the correct parameters were passed
        mock_client._mock_http_client.get.assert_called_once_with(
            "/inferences",
            params={
                "page": 2,
                "perPage": 10,
                "appName": "demo-app",
                "email": "user@example.com",
                "hasAnnotation": "true",  # Boolean converted to string
                "isTestGenerated": "false",  # Default filtering
            }
        )

    def test_get_inference_success(self, mock_client):
        """Test successful inference retrieval."""
        mock_inference_data = {
            "_id": "inf-123",
            "appName": "demo-app",
            "email": "user@example.com",
            "inferrerName": "test-inferrer",
            "inputs": {"question": "Hello"},
            "outputs": {"answer": "Hi there!"},
            "annotation": "Good response",
            "tags": ["positive", "helpful"],
            "duration": 150,
            "createdDate": "2023-01-01T00:00:00Z",
        }

        mock_client._mock_http_client.get.return_value = mock_inference_data

        result = mock_client.inferences.get("inf-123")

        assert isinstance(result, Inference)
        assert result.id == "inf-123"
        assert result.app_name == "demo-app"
        assert result.annotation == "Good response"
        assert result.tags == ["positive", "helpful"]

        mock_client._mock_http_client.get.assert_called_once_with("/inferences/inf-123")

    def test_get_inference_not_found(self, mock_client):
        """Test inference not found."""
        from az_cortex_sdk.exceptions import NotFoundError

        mock_client._mock_http_client.get.side_effect = NotFoundError("Inference not found")

        with pytest.raises(NotFoundError):
            mock_client.inferences.get("nonexistent-id")

    def test_update_inference_success(self, mock_client):
        """Test successful inference update."""
        mock_response = {
            "_id": "inf-123",
            "appName": "demo-app",
            "annotation": "Updated annotation",
            "tags": ["updated", "reviewed"],
            "createdDate": "2023-01-01T00:00:00Z",
        }

        mock_client._mock_http_client.put.return_value = mock_response

        result = mock_client.inferences.update(
            "inf-123",
            annotation="Updated annotation",
            tags=["updated", "reviewed"]
        )

        assert isinstance(result, Inference)
        assert result.id == "inf-123"
        assert result.annotation == "Updated annotation"
        assert result.tags == ["updated", "reviewed"]

        mock_client._mock_http_client.put.assert_called_once_with(
            "/inferences/inf-123",
            data={
                "annotation": "Updated annotation",
                "tags": ["updated", "reviewed"]
            }
        )

    def test_transform_inference_data_with_escalation_routes(self, mock_client):
        """Test data transformation with escalation routes."""
        mock_data = {
            "_id": "inf-123",
            "appName": "demo-app",
            "escalationRoutes": [
                {
                    "escalationRouteId": "route-1",
                    "escalationTargetName": "Support Team",
                    "escalationLink": "https://support.example.com",
                    "escalationTooltip": "Contact support"
                }
            ],
            "createdDate": "2023-01-01T12:00:00Z",
        }

        mock_client._mock_http_client.get.return_value = mock_data

        result = mock_client.inferences.get("inf-123")

        assert isinstance(result, Inference)
        assert result.escalation_routes is not None
        assert len(result.escalation_routes) == 1

        route = result.escalation_routes[0]
        assert isinstance(route, EscalationRoute)
        assert route.escalation_route_id == "route-1"
        assert route.escalation_target_name == "Support Team"
        assert route.escalation_link == "https://support.example.com"
        assert route.escalation_tooltip == "Contact support"

    def test_date_parsing(self, mock_client):
        """Test datetime parsing from ISO strings."""
        mock_data = {
            "_id": "inf-123",
            "createdDate": "2023-01-01T12:00:00Z",
            "updatedDate": "2023-01-02T12:00:00+00:00",
        }

        mock_client._mock_http_client.get.return_value = mock_data

        result = mock_client.inferences.get("inf-123")

        assert isinstance(result, Inference)
        assert isinstance(result.created_date, datetime)
        assert isinstance(result.updated_date, datetime)
        assert result.created_date.year == 2023
        assert result.created_date.month == 1
        assert result.created_date.day == 1

    def test_infer_success(self, mock_client):
        """Test successful inference via InferenceService."""
        # Mock response
        mock_response = {
            "messages": {
                "documents": ["doc1", "doc2"],
                "content": "This is a test response",
                "role": "assistant",
                "metadatas": [{"key": "value"}]
            }
        }
        mock_client._mock_http_client.post.return_value = mock_response

        # Test inference
        result = mock_client.inferences.infer("test-app", {"prompt": "test"})

        # Assertions
        assert isinstance(result, InferenceResponse)
        assert result.messages is not None
        assert result.messages["content"] == "This is a test response"
        mock_client._mock_http_client.post.assert_called_once_with(
            "/apps/test-app/infer",
            data={"inputs": {"prompt": "test"}}
        )

    def test_infer_app_not_found(self, mock_client):
        """Test inference with non-existent app via InferenceService."""
        mock_client._mock_http_client.post.side_effect = NotFoundError("App not found")

        with pytest.raises(NotFoundError):
            mock_client.inferences.infer("non-existent-app", {"prompt": "test"})

"""Tests for conversation service."""


import pytest

from az_cortex_sdk import Conversation


@pytest.fixture
def mock_client():
    """Create a mock client for testing."""
    config = CortexConfig(
        base_url="https://test.example.com",
        client_id="test-id",
        client_secret="test-secret",
    )

    with patch("az_cortex_sdk.client.HTTPClient") as mock_http_client_class:
        mock_http_instance = Mock()
        mock_http_client_class.return_value = mock_http_instance

        client = CortexClient(config=config)
        client._mock_http_client = mock_http_instance  # Store for easy access in tests

        return client


class TestConversationService:
    """Test cases for ConversationService."""

    def test_list_conversations_empty(self, mock_client):
        """Test listing conversations when none exist."""
        mock_client._mock_http_client.get.return_value = {
            "documents": [],
            "totalDocuments": 0,
            "page": 1,
            "perPage": 25,
        }

        result = mock_client.conversations.list()

        assert len(result.items) == 0
        assert result.total == 0
        assert result.page == 1
        assert result.per_page == 25
        assert not result.has_next
        assert not result.has_prev

    def test_list_conversations_with_data(self, mock_client):
        """Test listing conversations with data."""
        mock_data = [
            {
                "_id": "conv-123",
                "name": "John Doe",
                "email": "john@example.com",
                "appName": "demo-app",
                "isEscalated": False,
                "isResolved": True,
                "isArchived": False,
                "createdDate": "2023-01-01T00:00:00Z",
            }
        ]

        mock_client._mock_http_client.get.return_value = {
            "documents": mock_data,
            "totalDocuments": 1,
            "page": 1,
            "perPage": 25,
        }

        result = mock_client.conversations.list()

        assert len(result.items) == 1
        assert result.total == 1

        conversation = result.items[0]
        assert isinstance(conversation, Conversation)
        assert conversation.id == "conv-123"
        assert conversation.name == "John Doe"
        assert conversation.email == "john@example.com"
        assert conversation.app_name == "demo-app"
        assert conversation.is_escalated is False
        assert conversation.is_resolved is True
        assert conversation.is_archived is False

    def test_list_conversations_with_filters(self, mock_client):
        """Test listing conversations with filters."""
        mock_client._mock_http_client.get.return_value = {
            "documents": [],
            "totalDocuments": 0,
            "page": 1,
            "perPage": 10,
        }

        mock_client.conversations.list(
            app_name="demo-app",
            is_escalated=True,
            is_resolved=False,
            page=2,
            per_page=10
        )

        # Verify the correct parameters were passed
        mock_client._mock_http_client.get.assert_called_once_with(
            "/conversations",
            params={
                "page": 2,
                "perPage": 10,
                "appName": "demo-app",
                "isEscalated": "true",   # Boolean converted to string
                "isResolved": "false",   # Boolean converted to string
                "isTestGenerated": "false",  # Default filtering
            }
        )

    def test_get_conversation_success(self, mock_client):
        """Test successful conversation retrieval."""
        mock_conversation_data = {
            "_id": "conv-123",
            "name": "John Doe",
            "email": "john@example.com",
            "appName": "demo-app",
            "isEscalated": True,
            "isResolved": False,
            "selectedEscalationRoute": "support-team",
            "escalationDate": "2023-01-02T00:00:00Z",
            "createdDate": "2023-01-01T00:00:00Z",
        }

        mock_client._mock_http_client.get.return_value = mock_conversation_data

        result = mock_client.conversations.get("conv-123")

        assert isinstance(result, Conversation)
        assert result.id == "conv-123"
        assert result.name == "John Doe"
        assert result.is_escalated is True
        assert result.is_resolved is False
        assert result.selected_escalation_route == "support-team"

        mock_client._mock_http_client.get.assert_called_once_with("/conversations/conv-123")

    def test_get_conversation_not_found(self, mock_client):
        """Test conversation not found."""
        from az_cortex_sdk.exceptions import NotFoundError

        mock_client._mock_http_client.get.side_effect = NotFoundError("Conversation not found")

        with pytest.raises(NotFoundError):
            mock_client.conversations.get("nonexistent-id")

    def test_update_conversation_success(self, mock_client):
        """Test successful conversation update."""
        mock_response = {
            "_id": "conv-123",
            "name": "Jane Doe",
            "email": "jane@example.com",
            "isResolved": True,
            "createdDate": "2023-01-01T00:00:00Z",
        }

        mock_client._mock_http_client.put.return_value = mock_response

        result = mock_client.conversations.update(
            "conv-123",
            name="Jane Doe",
            email="jane@example.com",
            is_resolved=True
        )

        assert isinstance(result, Conversation)
        assert result.id == "conv-123"
        assert result.name == "Jane Doe"
        assert result.email == "jane@example.com"
        assert result.is_resolved is True

        mock_client._mock_http_client.put.assert_called_once_with(
            "/conversations/conv-123",
            data={
                "name": "Jane Doe",
                "email": "jane@example.com",
                "isResolved": True
            }
        )

    def test_escalate_conversation_success(self, mock_client):
        """Test successful conversation escalation."""
        mock_response = {
            "_id": "conv-123",
            "name": "John Doe",
            "isEscalated": True,
            "selectedEscalationRoute": "support-team",
            "escalationDate": "2023-01-02T00:00:00Z",
        }

        mock_client._mock_http_client.put.return_value = mock_response

        result = mock_client.conversations.escalate("conv-123", "support-team")

        assert isinstance(result, Conversation)
        assert result.id == "conv-123"
        assert result.is_escalated is True
        assert result.selected_escalation_route == "support-team"

        mock_client._mock_http_client.put.assert_called_once_with(
            "/conversations/conv-123/escalate",
            data={"selectedEscalationRoute": "support-team"}
        )

    def test_resolve_conversation_success(self, mock_client):
        """Test successful conversation resolution."""
        mock_response = {
            "_id": "conv-123",
            "name": "John Doe",
            "isResolved": True,
            "resolutionDate": "2023-01-03T00:00:00Z",
        }

        mock_client._mock_http_client.put.return_value = mock_response

        result = mock_client.conversations.resolve("conv-123")

        assert isinstance(result, Conversation)
        assert result.id == "conv-123"
        assert result.is_resolved is True

        mock_client._mock_http_client.put.assert_called_once_with("/conversations/conv-123/resolve")

    def test_transform_conversation_data_with_escalation_routes(self, mock_client):
        """Test data transformation with escalation routes."""
        mock_data = {
            "_id": "conv-123",
            "name": "John Doe",
            "escalationRoutes": [
                {
                    "escalationRouteId": "route-1",
                    "escalationTargetName": "Support Team",
                    "escalationLink": "https://support.example.com",
                    "escalationTooltip": "Contact support"
                }
            ],
            "createdDate": "2023-01-01T12:00:00Z",
        }

        mock_client._mock_http_client.get.return_value = mock_data

        result = mock_client.conversations.get("conv-123")

        assert isinstance(result, Conversation)
        assert result.escalation_routes is not None
        assert len(result.escalation_routes) == 1

        route = result.escalation_routes[0]
        assert isinstance(route, EscalationRoute)
        assert route.escalation_route_id == "route-1"
        assert route.escalation_target_name == "Support Team"
        assert route.escalation_link == "https://support.example.com"
        assert route.escalation_tooltip == "Contact support"

    def test_date_parsing(self, mock_client):
        """Test datetime parsing from ISO strings."""
        mock_data = {
            "_id": "conv-123",
            "createdDate": "2023-01-01T12:00:00Z",
            "updatedDate": "2023-01-02T12:00:00+00:00",
            "escalationDate": "2023-01-03T12:00:00Z",
            "resolutionDate": "2023-01-04T12:00:00Z",
        }

        mock_client._mock_http_client.get.return_value = mock_data

        result = mock_client.conversations.get("conv-123")

        assert isinstance(result, Conversation)
        assert isinstance(result.created_date, datetime)
        assert isinstance(result.updated_date, datetime)
        assert isinstance(result.escalation_date, datetime)
        assert isinstance(result.resolution_date, datetime)
        assert result.created_date.year == 2023
        assert result.created_date.month == 1
        assert result.created_date.day == 1
#!/usr/bin/env python3
"""Test message auto-infer functionality with LLM configs."""

import os
import sys

import pytest

try:
    from dotenv import load_dotenv
except ImportError:
    load_dotenv = None

# Add parent directory to path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))


# NOTE: Environment loading moved to _load_env_for_integration_tests() function
# to avoid polluting the environment during pytest collection.
# Call this function at the start of integration tests that need it.
def _load_env_for_integration_tests():
    """Load environment variables for integration tests. Call this in tests that need it."""
    if load_dotenv:
        env_path = os.path.join(os.path.dirname(__file__), '..', '.env_llm')
        load_dotenv(env_path)
        print(f"Loaded LLM config from: {env_path}")

        env_path = os.path.join(os.path.dirname(__file__), '..', '.env')
        load_dotenv(env_path)
        print(f"Loaded auth config from: {env_path}")

# Get configuration from environment
TENANT_ID = os.getenv("TENANT_ID")
CLIENT_ID = os.getenv("CLIENT_ID")
CLIENT_SECRET = os.getenv("CLIENT_SECRET")
BASE_URL = os.getenv("BASE_URL")
TENANT_KEY = os.getenv("TENANT_KEY")

# LLM Configuration
AZURE_OPENAI_ENDPOINT = os.getenv("AZURE_OPENAI_ENDPOINT")
AZURE_OPENAI_API_KEY = os.getenv("AZURE_OPENAI_API_KEY")
AZURE_OPENAI_DEPLOYMENT = os.getenv("AZURE_OPENAI_DEPLOYMENT")
AZURE_OPENAI_MODEL = os.getenv("AZURE_OPENAI_MODEL")

@pytest.mark.skipif(
    not all([CLIENT_ID, CLIENT_SECRET, BASE_URL, TENANT_KEY, AZURE_OPENAI_ENDPOINT, AZURE_OPENAI_API_KEY]),
    reason="Live API credentials not configured"
)
def test_message_autoinfer():
    """Test message creation with auto-infer using LLM config."""

    print("\n" + "="*80)
    print("  Testing Message Auto-Infer with LLM Config")
    print("="*80)

    # Initialize client
    client = CortexClient(
        tenant=TENANT_ID,
        client_id=CLIENT_ID,
        client_secret=CLIENT_SECRET,
        base_url=BASE_URL,
    )
    print("✓ Initialized CortexClient")

    # Create unique config name
    timestamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    config_name = f"test-msg-autoinfer-{timestamp}"

    try:
        # Step 1: Create LLM config
        print(f"\n1. Creating LLM config: {config_name}")
        client.llm.create(
            config_name=config_name,
            provider="azure-openai",
            model=AZURE_OPENAI_MODEL,
            api_key=AZURE_OPENAI_API_KEY,
            endpoint=AZURE_OPENAI_ENDPOINT,
            deployment=AZURE_OPENAI_DEPLOYMENT,
            default_parameters={
                "temperature": 0.7,
                "max_tokens": 100,
            }
        )
        print(f"✓ Created LLM config: {config_name}")

        # Step 2: Create message with auto_infer=True (default) using llm_config_name
        print("\n2. Creating message with auto_infer=True (default)")
        message1 = client.messages.create(
            tenant_key=TENANT_KEY,
            llm_config_name=config_name,
            text="Say 'Hello from auto-infer test!' and nothing else.",
            email="test@example.com",
            is_test_generated=True,
        )
        print("✓ Created message with auto-infer")
        print(f"     Message ID: {message1.id}")
        print(f"     LLM config name: {message1.llm_config_name}")
        print(f"     Inference ID: {message1.inference_id}")

        if message1.inference_id:
            print("✓ Auto-inference was triggered (inference_id present)")
        else:
            print("✗ Auto-inference was NOT triggered (no inference_id)")

        # Step 3: Create message with auto_infer=False
        print("\n3. Creating message with auto_infer=False")
        message2 = client.messages.create(
            tenant_key=TENANT_KEY,
            llm_config_name=config_name,
            conversation_id=message1.conversation_id,  # Same conversation
            text="This should not trigger inference",
            email="test@example.com",
            auto_infer=False,
            is_test_generated=True,
        )
        print("✓ Created message without auto-infer")
        print(f"     Message ID: {message2.id}")
        print(f"     LLM config name: {message2.llm_config_name}")
        print(f"     Inference ID: {message2.inference_id}")

        if message2.inference_id is None:
            print("✓ Auto-inference was correctly disabled (no inference_id)")
        else:
            print("✗ Auto-inference was triggered despite auto_infer=False")

        # Step 4: Verify conversation has llm_config_name
        print("\n4. Verifying conversation configuration")
        conversation = client.conversations.get(message1.conversation_id)
        print(f"✓ Retrieved conversation: {conversation.id}")
        print(f"     LLM config name: {conversation.llm_config_name}")
        print(f"     Endpoint name: {conversation.endpoint_name}")

        if conversation.llm_config_name == config_name:
            print("✓ Conversation correctly configured with LLM config")
        else:
            print("✗ Conversation LLM config mismatch")

        # Step 5: List messages in conversation
        print("\n5. Listing messages in conversation")
        messages = client.messages.list(
            conversation_id=message1.conversation_id,
            per_page=10
        )
        print(f"✓ Found {len(messages.items)} messages in conversation")

        for i, msg in enumerate(messages.items, 1):
            print(f"     Message {i}: {msg.text[:50]}...")
            print(f"       - Has inference: {msg.inference_id is not None}")

        # Cleanup
        print("\n6. Cleaning up")

        # Archive conversation (which archives messages)
        client.conversations.archive(message1.conversation_id)
        print("✓ Archived conversation")

        # Delete LLM config
        client.llm.delete(config_name)
        print(f"✓ Deleted LLM config: {config_name}")

        print("\n" + "="*80)
        print("  Test Summary")
        print("="*80)
        print("✓ Message Auto-Infer Test: PASSED")
        print("\nVerified:")
        print("  ✓ Messages can be created with llm_config_name")
        print("  ✓ Auto-infer works by default (creates inference)")
        print("  ✓ Auto-infer can be disabled with auto_infer=False")
        print("  ✓ Conversation inherits llm_config_name")
        print("\n🎉 All message auto-infer tests passed!")

    except Exception as e:
        print(f"\n✗ Test failed with error: {e}")
        import traceback
        traceback.print_exc()

        # Cleanup on error
        try:
            client.llm.delete(config_name)
            print(f"✓ Cleaned up LLM config: {config_name}")
        except:
            pass

        # Re-raise the exception for pytest to handle
        raise

if __name__ == "__main__":
    test_message_autoinfer()

