#!/usr/bin/env python3
"""Live integration tests for LLM functionality.

This test file validates all LLM routes against the deployed dev API.
Run with: python tests/test_llm_live.py
"""

import os
import sys
from datetime import datetime
from pathlib import Path

# Add parent directory to path for imports
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

# NOTE: Environment loading moved to _load_env_for_live_tests() function
# to avoid polluting the environment during pytest collection.
try:
    from dotenv import load_dotenv as _load_dotenv_main
except ImportError:
    _load_dotenv_main = None


def _load_env_for_live_tests():
    """Load environment variables for live tests. Call this in tests that need it."""
    if _load_dotenv_main:
        env_path = Path(__file__).parent.parent / '.env'
        _load_dotenv_main(env_path)
        print(f"Loaded environment from: {env_path}")
    else:
        print("Warning: python-dotenv not installed. Using existing environment variables.")

from az_cortex_sdk import CortexClient


def print_section(title: str):
    """Print a formatted section header."""
    print(f"\n{'=' * 80}")
    print(f"  {title}")
    print(f"{'=' * 80}\n")


def print_success(message: str):
    """Print a success message."""
    print(f"✓ {message}")


def print_error(message: str):
    """Print an error message."""
    print(f"✗ {message}")


def print_info(message: str):
    """Print an info message."""
    print(f"  {message}")


def test_llm_config_crud():
    """Test LLM configuration CRUD operations."""
    print_section("Testing LLM Configuration CRUD Operations")

    # Initialize client
    client = CortexClient.from_env()
    print_success("Initialized CortexClient")

    # Generate unique config name for testing
    timestamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    config_name = f"test-openai-config-{timestamp}"

    try:
        # Test 1: Create LLM configuration
        print_info("Creating OpenAI LLM configuration...")
        config = client.llm.create(
            config_name=config_name,
            provider="openai",
            model="gpt-4",
            api_key="sk-test-key-placeholder",
            default_parameters={
                "temperature": 0.7,
                "max_tokens": 1000,
                "top_p": 1.0,
            }
        )
        print_success(f"Created LLM config: {config.config_name}")
        print_info(f"  Provider: {config.provider}")
        print_info(f"  Model: {config.model}")
        print_info(f"  Default temperature: {config.default_parameters.temperature if config.default_parameters else 'N/A'}")

        # Test 2: Get specific LLM configuration
        print_info("\nRetrieving LLM configuration...")
        retrieved_config = client.llm.get(config_name)
        print_success(f"Retrieved LLM config: {retrieved_config.config_name}")
        print_info(f"  ID: {retrieved_config.id}")
        print_info(f"  Provider: {retrieved_config.provider}")
        print_info(f"  Model: {retrieved_config.model}")

        # Test 3: List LLM configurations
        print_info("\nListing all LLM configurations...")
        configs_list = client.llm.list(per_page=10)
        print_success(f"Found {configs_list.total} LLM configurations")
        print_info(f"  Page: {configs_list.page}")
        print_info(f"  Per page: {configs_list.per_page}")
        print_info(f"  Has next: {configs_list.has_next}")

        # Test 4: List with filters
        print_info("\nListing OpenAI configurations only...")
        openai_configs = client.llm.list(provider="openai", per_page=5)
        print_success(f"Found {openai_configs.total} OpenAI configurations")

        # Test 5: Update LLM configuration
        print_info("\nUpdating LLM configuration...")
        updated_config = client.llm.update(
            config_name=config_name,
            model="gpt-4-turbo",
            default_parameters={
                "temperature": 0.8,
                "max_tokens": 2000,
            }
        )
        print_success(f"Updated LLM config: {updated_config.config_name}")
        print_info(f"  New model: {updated_config.model}")
        print_info(f"  New temperature: {updated_config.default_parameters.temperature if updated_config.default_parameters else 'N/A'}")

        # Test 6: Archive LLM configuration
        print_info("\nArchiving LLM configuration...")
        archived_config = client.llm.archive(config_name)
        print_success(f"Archived LLM config: {archived_config.config_name}")
        print_info(f"  Is archived: {archived_config.is_archived}")

        # Test 7: List including archived
        print_info("\nListing configurations including archived...")
        all_configs = client.llm.list(is_archived=True, per_page=10)
        print_success(f"Found {all_configs.total} configurations (including archived)")

        print_section("LLM Configuration CRUD Tests: PASSED")
        return True

    except Exception as e:
        print_error(f"LLM Configuration CRUD test failed: {e}")
        import traceback
        traceback.print_exc()
        return False


def test_llm_inference():
    """Test LLM inference functionality."""
    print_section("Testing LLM Inference")

    # Initialize client
    client = CortexClient.from_env()
    print_success("Initialized CortexClient")

    # Generate unique config name for testing
    timestamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    config_name = f"test-inference-config-{timestamp}"

    try:
        # Create a test configuration
        print_info("Creating test LLM configuration for inference...")
        config = client.llm.create(
            config_name=config_name,
            provider="openai",
            model="gpt-3.5-turbo",
            api_key=os.getenv("OPENAI_API_KEY", "sk-test-key-placeholder"),
            default_parameters={
                "temperature": 0.7,
                "max_tokens": 100,
            }
        )
        print_success(f"Created test config: {config.config_name}")

        # Test inference (note: will fail with placeholder API key, but tests the SDK integration)
        print_info("\nPerforming LLM inference (note: using placeholder API key)...")
        messages = [
            {
                "role": "system",
                "content": "You are a helpful assistant."
            },
            {
                "role": "user",
                "content": "What is 2+2? Answer in one word."
            }
        ]

        try:
            inference_result = client.llm.infer(
                config_name=config_name,
                messages=messages,
                parameters={
                    "temperature": 0.5,
                    "max_tokens": 50,
                },
                is_test_generated=True
            )

            print_success("Inference completed successfully")
            print_info(f"  Inference ID: {inference_result.id}")
            print_info(f"  Config name: {inference_result.config_name}")
            print_info(f"  Duration: {inference_result.duration}ms")
            print_info(f"  Is test generated: {inference_result.is_test_generated}")

            if inference_result.inputs:
                print_info(f"  Input messages: {len(inference_result.inputs.get('messages', []))} messages")

            if inference_result.outputs:
                print_info(f"  Output keys: {list(inference_result.outputs.keys())}")
                if 'messages' in inference_result.outputs:
                    output_messages = inference_result.outputs['messages']
                    if output_messages and len(output_messages) > 0:
                        print_info(f"  Response: {output_messages[0].get('content', 'N/A')[:100]}...")
        except Exception as e:
            # Expected to fail with placeholder API key
            print_info(f"  Inference failed (expected with placeholder API key): {str(e)[:100]}")
            print_success("SDK correctly handled inference request (API key validation expected)")

        # Clean up: Archive the test configuration
        print_info("\nCleaning up test configuration...")
        client.llm.archive(config_name)
        print_success("Test configuration archived")

        print_section("LLM Inference Tests: PASSED")
        return True

    except Exception as e:
        print_error(f"LLM Inference test failed: {e}")
        import traceback
        traceback.print_exc()

        # Try to clean up even if test failed
        try:
            client.llm.archive(config_name)
            print_info("Cleaned up test configuration")
        except:
            pass

        return False


def test_azure_openai_config():
    """Test Azure OpenAI configuration."""
    print_section("Testing Azure OpenAI Configuration")

    # Initialize client
    client = CortexClient.from_env()
    print_success("Initialized CortexClient")

    # Generate unique config name for testing
    timestamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    config_name = f"test-azure-config-{timestamp}"

    try:
        # Create Azure OpenAI configuration
        print_info("Creating Azure OpenAI LLM configuration...")
        config = client.llm.create(
            config_name=config_name,
            provider="azure-openai",
            api_key="test-azure-key",
            endpoint="https://test-resource.openai.azure.com",
            deployment="gpt-4-deployment",
            default_parameters={
                "temperature": 0.7,
                "max_tokens": 1500,
            }
        )
        print_success(f"Created Azure OpenAI config: {config.config_name}")
        print_info(f"  Provider: {config.provider}")
        print_info(f"  Endpoint: {config.endpoint}")
        print_info(f"  Deployment: {config.deployment}")

        # Retrieve and verify
        print_info("\nRetrieving Azure OpenAI configuration...")
        retrieved = client.llm.get(config_name)
        print_success(f"Retrieved config: {retrieved.config_name}")
        print_info(f"  Endpoint matches: {retrieved.endpoint == config.endpoint}")
        print_info(f"  Deployment matches: {retrieved.deployment == config.deployment}")

        # Clean up
        print_info("\nCleaning up Azure OpenAI configuration...")
        client.llm.archive(config_name)
        print_success("Azure OpenAI configuration archived")

        print_section("Azure OpenAI Configuration Tests: PASSED")
        return True

    except Exception as e:
        print_error(f"Azure OpenAI configuration test failed: {e}")
        import traceback
        traceback.print_exc()

        # Try to clean up
        try:
            client.llm.archive(config_name)
        except:
            pass

        return False


def main():
    """Run all LLM tests."""
    print("\n" + "=" * 80)
    print("  Azure Cortex SDK - LLM Live Integration Tests")
    print("=" * 80)

    results = []

    # Run all tests
    results.append(("LLM Config CRUD", test_llm_config_crud()))
    results.append(("LLM Inference", test_llm_inference()))
    results.append(("Azure OpenAI Config", test_azure_openai_config()))

    # Print summary
    print_section("Test Summary")
    passed = sum(1 for _, result in results if result)
    total = len(results)

    for test_name, result in results:
        status = "PASSED" if result else "FAILED"
        symbol = "✓" if result else "✗"
        print(f"{symbol} {test_name}: {status}")

    print(f"\nTotal: {passed}/{total} tests passed")

    if passed == total:
        print("\n🎉 All tests passed!")
        return 0
    else:
        print(f"\n⚠️  {total - passed} test(s) failed")
        return 1


if __name__ == "__main__":
    sys.exit(main())

#!/usr/bin/env python3
"""
Comprehensive live test for all LLM routes using real Azure OpenAI credentials.
Tests all new features with actual API calls.
"""

import os
import sys

try:
    from dotenv import load_dotenv as _load_dotenv
except ImportError:
    _load_dotenv = None

# Add parent directory to path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))


# ANSI color codes
GREEN = '\033[92m'
RED = '\033[91m'
BLUE = '\033[94m'
YELLOW = '\033[93m'
RESET = '\033[0m'
BOLD = '\033[1m'

def print_header(text: str):
    print(f"\n{BOLD}{BLUE}{'='*80}{RESET}")
    print(f"{BOLD}{BLUE}  {text}{RESET}")
    print(f"{BOLD}{BLUE}{'='*80}{RESET}\n")

def print_success(text: str):
    print(f"{GREEN}✓{RESET} {text}")

def print_error(text: str):
    print(f"{RED}✗{RESET} {text}")

def print_info(text: str):
    print(f"  {text}")

def test_secret_management_live():
    """Test secret management with real credentials."""
    print_header("Testing Secret Management (Live)")

    client = CortexClient.from_env()
    print_success("Initialized CortexClient")

    timestamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    config_name = f"test-secret-{timestamp}"

    # Get credentials from environment
    api_key = os.getenv("AZURE_OPENAI_API_KEY")
    endpoint = os.getenv("AZURE_OPENAI_ENDPOINT")
    deployment = os.getenv("AZURE_OPENAI_DEPLOYMENT")
    model = os.getenv("AZURE_OPENAI_MODEL")

    try:
        # Test 1: Create with api_key (auto-creates secret)
        print_info("\n1. Creating config with api_key (auto-creates secret)")
        config = client.llm.create(
            config_name=config_name,
            provider="azure-openai",
            model=model,
            api_key=api_key,
            endpoint=endpoint,
            deployment=deployment
        )
        print_success(f"Created config: {config_name}")
        print_info(f"   Secret name: {config.secret_name}")
        print_info(f"   Expected: llm-{config_name}")
        assert config.secret_name == f"llm-{config_name}", "Secret name mismatch"

        # Test 2: Retrieve and verify
        print_info("\n2. Retrieving config to verify secret")
        retrieved = client.llm.get(config_name)
        print_success(f"Retrieved config: {retrieved.config_name}")
        print_info(f"   Secret name: {retrieved.secret_name}")
        assert retrieved.secret_name == config.secret_name, "Secret name changed"

        # Test 3: Update with new api_key
        print_info("\n3. Updating config with new api_key")
        updated = client.llm.update(
            config_name=config_name,
            api_key=api_key  # Same key, but tests the update flow
        )
        print_success("Updated config")
        print_info(f"   Secret name: {updated.secret_name}")
        assert updated.secret_name == config.secret_name, "Secret name should remain same"

        # Cleanup
        print_info("\n4. Cleaning up")
        client.llm.delete(config_name)
        print_success(f"Deleted {config_name}")

        return True

    except Exception as e:
        print_error(f"Test failed: {e}")
        import traceback
        traceback.print_exc()
        # Cleanup on failure
        try:
            client.llm.delete(config_name)
        except:
            pass
        return False

def test_archive_and_delete_live():
    """Test archive and delete operations."""
    print_header("Testing Archive & Delete (Live)")

    client = CortexClient.from_env()
    print_success("Initialized CortexClient")

    timestamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    config_name = f"test-delete-{timestamp}"

    api_key = os.getenv("AZURE_OPENAI_API_KEY")
    endpoint = os.getenv("AZURE_OPENAI_ENDPOINT")
    deployment = os.getenv("AZURE_OPENAI_DEPLOYMENT")
    model = os.getenv("AZURE_OPENAI_MODEL")

    try:
        # Create test config
        print_info("\n1. Creating test config")
        client.llm.create(
            config_name=config_name,
            provider="azure-openai",
            model=model,
            api_key=api_key,
            endpoint=endpoint,
            deployment=deployment
        )
        print_success(f"Created config: {config_name}")

        # Test archive
        print_info("\n2. Testing archive (soft delete)")
        archived = client.llm.archive(config_name)
        print_success("Archived config")
        print_info(f"   is_archived: {archived.is_archived}")
        assert archived.is_archived, "Config should be archived"

        # Verify hidden from default list
        print_info("\n3. Verifying archived config is hidden")
        configs = client.llm.list()
        config_names = [c.config_name for c in configs.items]
        assert config_name not in config_names, "Archived config should be hidden"
        print_success("Archived config correctly hidden from default list")

        # Verify appears with is_archived=True
        print_info("\n4. Verifying archived config appears with is_archived=True")
        archived_configs = client.llm.list(is_archived=True)
        archived_names = [c.config_name for c in archived_configs.items]
        assert config_name in archived_names, "Archived config should appear when requested"
        print_success("Archived config appears when requested")

        # Test hard delete
        print_info("\n5. Testing hard delete")
        result = client.llm.delete(config_name)
        print_success("Hard deleted config")
        print_info(f"   Message: {result.message}")

        # Verify completely gone
        print_info("\n6. Verifying config is completely deleted")
        try:
            client.llm.get(config_name)
            print_error("Config still exists after hard delete")
            return False
        except Exception:
            print_success("Config successfully deleted")

        return True

    except Exception as e:
        print_error(f"Test failed: {e}")
        import traceback
        traceback.print_exc()
        # Cleanup on failure
        try:
            client.llm.delete(config_name)
        except:
            pass
        return False

def test_inference_live():
    """Test regular inference with real API."""
    print_header("Testing LLM Inference (Live)")

    client = CortexClient.from_env()
    print_success("Initialized CortexClient")

    timestamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    config_name = f"test-infer-{timestamp}"

    api_key = os.getenv("AZURE_OPENAI_API_KEY")
    endpoint = os.getenv("AZURE_OPENAI_ENDPOINT")
    deployment = os.getenv("AZURE_OPENAI_DEPLOYMENT")
    model = os.getenv("AZURE_OPENAI_MODEL")

    try:
        # Create config
        print_info("\n1. Creating test config")
        client.llm.create(
            config_name=config_name,
            provider="azure-openai",
            model=model,
            api_key=api_key,
            endpoint=endpoint,
            deployment=deployment,
            default_parameters={
                "temperature": float(os.getenv("AZURE_OPENAI_TEMPERATURE", "0.7")),
                "max_tokens": int(os.getenv("AZURE_OPENAI_MAX_TOKENS", "1000")),
                "top_p": float(os.getenv("AZURE_OPENAI_TOP_P", "0.9"))
            }
        )
        print_success(f"Created config: {config_name}")

        # Test inference
        print_info("\n2. Testing inference")
        messages = [
            {"role": "system", "content": "You are a helpful assistant. Be concise."},
            {"role": "user", "content": "Say 'Hello from Azure Cortex SDK!' and nothing else."}
        ]

        result = client.llm.infer(config_name, messages)
        print_success("Inference completed")
        print_info(f"   Inference type: {result.inference_type}")
        print_info(f"   LLM config name: {result.llm_config_name}")

        # Extract response text from messages
        response_text = ""
        if 'messages' in result.outputs and len(result.outputs['messages']) > 0:
            response_text = result.outputs['messages'][0].get('content', 'N/A')

        print_info(f"   Response: {response_text[:100]}")

        # Verify new fields
        assert result.inference_type == 'llm', "Inference type should be 'llm'"
        assert result.llm_config_name == config_name, "LLM config name mismatch"
        assert 'messages' in result.outputs, "Response should have messages output"
        assert len(result.outputs['messages']) > 0, "Should have at least one message"
        assert 'usage' in result.outputs, "Response should have usage info"

        # Cleanup
        print_info("\n3. Cleaning up")
        client.llm.delete(config_name)
        print_success(f"Deleted {config_name}")

        return True

    except Exception as e:
        print_error(f"Test failed: {e}")
        import traceback
        traceback.print_exc()
        # Cleanup on failure
        try:
            client.llm.delete(config_name)
        except:
            pass
        return False

def test_streaming_inference_live():
    """Test streaming inference with real API."""
    print_header("Testing Streaming Inference (Live)")

    client = CortexClient.from_env()
    print_success("Initialized CortexClient")

    timestamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    config_name = f"test-stream-{timestamp}"

    api_key = os.getenv("AZURE_OPENAI_API_KEY")
    endpoint = os.getenv("AZURE_OPENAI_ENDPOINT")
    deployment = os.getenv("AZURE_OPENAI_DEPLOYMENT")
    model = os.getenv("AZURE_OPENAI_MODEL")

    try:
        # Create config
        print_info("\n1. Creating test config")
        client.llm.create(
            config_name=config_name,
            provider="azure-openai",
            model=model,
            api_key=api_key,
            endpoint=endpoint,
            deployment=deployment
        )
        print_success(f"Created config: {config_name}")

        # Test streaming
        print_info("\n2. Testing streaming inference")
        messages = [
            {"role": "system", "content": "You are a helpful assistant. Be very concise."},
            {"role": "user", "content": "Count from 1 to 5, one number per line."}
        ]

        print_info("   Streaming response:")
        print("   ", end="")

        full_response = ""
        usage_info = None
        chunk_count = 0

        for event in client.llm.infer_stream(config_name, messages):
            if event['type'] == 'chunk':
                content = event['content']
                full_response += content
                chunk_count += 1
                print(content, end='', flush=True)
            elif event['type'] == 'done':
                usage_info = event.get('usage')
                print()  # New line
            elif event['type'] == 'error':
                print()
                print_error(f"Stream error: {event['message']}")
                return False

        print_success("Streaming completed")
        print_info(f"   Chunks received: {chunk_count}")
        print_info(f"   Total response length: {len(full_response)} chars")
        if usage_info:
            print_info(f"   Usage: {usage_info}")

        # Verify we got content
        assert len(full_response) > 0, "Should have received content"
        assert chunk_count > 0, "Should have received chunks"

        # Cleanup
        print_info("\n3. Cleaning up")
        client.llm.delete(config_name)
        print_success(f"Deleted {config_name}")

        return True

    except Exception as e:
        print_error(f"Test failed: {e}")
        import traceback
        traceback.print_exc()
        # Cleanup on failure
        try:
            client.llm.delete(config_name)
        except:
            pass
        return False

def main():
    # Load environment variables from .env_llm
    if _load_dotenv:
        env_path = os.path.join(os.path.dirname(__file__), '..', '.env_llm')
        _load_dotenv(env_path)

        # Also load main .env for auth
        main_env_path = os.path.join(os.path.dirname(__file__), '..', '.env')
        _load_dotenv(main_env_path)

    print(f"Loaded LLM config from: {env_path}")
    print(f"Loaded auth config from: {main_env_path}\n")

    # Verify required env vars
    required_vars = [
        "AZURE_OPENAI_API_KEY",
        "AZURE_OPENAI_ENDPOINT",
        "AZURE_OPENAI_DEPLOYMENT",
        "AZURE_OPENAI_MODEL"
    ]

    missing = [var for var in required_vars if not os.getenv(var)]
    if missing:
        print_error(f"Missing required environment variables: {', '.join(missing)}")
        return 1

    print_header("Comprehensive LLM Live Test Suite")
    print_info(f"Endpoint: {os.getenv('AZURE_OPENAI_ENDPOINT')}")
    print_info(f"Model: {os.getenv('AZURE_OPENAI_MODEL')}")
    print_info(f"Deployment: {os.getenv('AZURE_OPENAI_DEPLOYMENT')}")

    results = {}

    # Run tests
    results['Secret Management'] = test_secret_management_live()
    results['Archive & Delete'] = test_archive_and_delete_live()
    results['Inference'] = test_inference_live()
    results['Streaming Inference'] = test_streaming_inference_live()

    # Print summary
    print_header("Test Summary")

    passed = sum(1 for v in results.values() if v)
    total = len(results)

    for test_name, result in results.items():
        if result:
            print_success(f"{test_name}: PASSED")
        else:
            print_error(f"{test_name}: FAILED")

    print(f"\nTotal: {passed}/{total} tests passed")

    if passed == total:
        print(f"\n{GREEN}{BOLD}🎉 All live tests passed!{RESET}")
        return 0
    else:
        print(f"\n{YELLOW}⚠️  {total - passed} test(s) failed{RESET}")
        return 1

if __name__ == "__main__":
    sys.exit(main())

#!/usr/bin/env python3
"""
Test new LLM features:
- Secret management (api_key vs secret_name)
- Archive route change (PUT /llm/:configName/archive)
- Hard delete (DELETE /llm/:configName)
- Streaming inference (POST /llm/infer/stream)
"""

import os
import sys

try:
    from dotenv import load_dotenv as _load_dotenv2
except ImportError:
    _load_dotenv2 = None

# Add parent directory to path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))


# ANSI color codes
GREEN = '\033[92m'
RED = '\033[91m'
BLUE = '\033[94m'
YELLOW = '\033[93m'
RESET = '\033[0m'
BOLD = '\033[1m'

def print_header(text: str):
    print(f"\n{BOLD}{BLUE}{'='*80}{RESET}")
    print(f"{BOLD}{BLUE}  {text}{RESET}")
    print(f"{BOLD}{BLUE}{'='*80}{RESET}\n")

def print_success(text: str):
    print(f"{GREEN}✓{RESET} {text}")

def print_error(text: str):
    print(f"{RED}✗{RESET} {text}")

def print_info(text: str):
    print(f"  {text}")

def test_secret_management():
    """Test creating configs with api_key vs secret_name."""
    print_header("Testing Secret Management")

    client = CortexClient.from_env()
    print_success("Initialized CortexClient")

    timestamp = datetime.now().strftime("%Y%m%d-%H%M%S")

    try:
        # Test 1: Create with api_key (auto-creates secret)
        print_info("\n1. Creating config with api_key (auto-creates secret)")
        config_name_1 = f"test-apikey-{timestamp}"
        config1 = client.llm.create(
            config_name=config_name_1,
            provider="openai",
            model="gpt-4",
            api_key="sk-test-key-12345"
        )
        print_success(f"Created config: {config_name_1}")
        print_info(f"   Secret name: {config1.secret_name}")
        print_info(f"   API key field: {config1.api_key}")

        # Test 2: Create with secret_name (references existing secret)
        print_info("\n2. Creating config with secret_name")
        config_name_2 = f"test-secretname-{timestamp}"

        # First create a secret manually (if you have access)
        # For now, we'll test that the API validates the secret exists
        try:
            client.llm.create(
                config_name=config_name_2,
                provider="openai",
                model="gpt-4",
                secret_name="non-existent-secret"
            )
            print_error("Should have failed with non-existent secret")
        except Exception as e:
            print_success(f"Correctly rejected non-existent secret: {str(e)[:80]}")

        # Test 3: Update with new api_key
        print_info("\n3. Updating config with new api_key")
        updated = client.llm.update(
            config_name=config_name_1,
            api_key="sk-test-key-updated"
        )
        print_success("Updated config with new API key")
        print_info(f"   Secret name: {updated.secret_name}")

        # Test 4: Try to provide both api_key and secret_name (should fail)
        print_info("\n4. Testing mutual exclusivity (api_key + secret_name)")
        try:
            client.llm.create(
                config_name=f"test-both-{timestamp}",
                provider="openai",
                model="gpt-4",
                api_key="sk-test",
                secret_name="some-secret"
            )
            print_error("Should have failed with both api_key and secret_name")
        except Exception as e:
            print_success(f"Correctly rejected both parameters: {str(e)[:80]}")

        # Cleanup
        print_info("\n5. Cleaning up test configs")
        client.llm.delete(config_name_1)
        print_success(f"Deleted {config_name_1}")

        return True

    except Exception as e:
        print_error(f"Test failed: {e}")
        import traceback
        traceback.print_exc()
        return False

def test_archive_and_delete():
    """Test archive (soft delete) vs hard delete."""
    print_header("Testing Archive vs Hard Delete")

    client = CortexClient.from_env()
    print_success("Initialized CortexClient")

    timestamp = datetime.now().strftime("%Y%m%d-%H%M%S")

    try:
        # Create test config
        print_info("\n1. Creating test config")
        config_name = f"test-delete-{timestamp}"
        client.llm.create(
            config_name=config_name,
            provider="openai",
            model="gpt-4",
            api_key="sk-test-delete"
        )
        print_success(f"Created config: {config_name}")

        # Test archive (soft delete)
        print_info("\n2. Testing archive (soft delete)")
        archived = client.llm.archive(config_name)
        print_success("Archived config")
        print_info(f"   is_archived: {archived.is_archived}")

        # Verify it doesn't appear in default list
        print_info("\n3. Verifying archived config is hidden")
        configs = client.llm.list()
        config_names = [c.config_name for c in configs.items]
        if config_name not in config_names:
            print_success("Archived config correctly hidden from default list")
        else:
            print_error("Archived config still appears in default list")

        # Verify it appears when is_archived=True
        print_info("\n4. Verifying archived config appears with is_archived=True")
        archived_configs = client.llm.list(is_archived=True)
        archived_names = [c.config_name for c in archived_configs.items]
        if config_name in archived_names:
            print_success("Archived config appears when requested")
        else:
            print_error("Archived config not found when is_archived=True")

        # Test hard delete
        print_info("\n5. Testing hard delete")
        result = client.llm.delete(config_name)
        print_success("Hard deleted config")
        print_info(f"   Message: {result.message}")

        # Verify it's completely gone
        print_info("\n6. Verifying config is completely deleted")
        try:
            client.llm.get(config_name)
            print_error("Config still exists after hard delete")
        except Exception:
            print_success("Config successfully deleted")

        return True

    except Exception as e:
        print_error(f"Test failed: {e}")
        import traceback
        traceback.print_exc()
        return False

def test_streaming_inference():
    """Test streaming LLM inference."""
    print_header("Testing Streaming Inference")

    client = CortexClient.from_env()
    print_success("Initialized CortexClient")

    timestamp = datetime.now().strftime("%Y%m%d-%H%M%S")

    try:
        # Create test config
        print_info("\n1. Creating test config for streaming")
        config_name = f"test-stream-{timestamp}"
        client.llm.create(
            config_name=config_name,
            provider="openai",
            model="gpt-4",
            api_key="sk-test-stream-placeholder"
        )
        print_success(f"Created config: {config_name}")

        # Test streaming inference
        print_info("\n2. Testing streaming inference")
        messages = [
            {"role": "system", "content": "You are a helpful assistant."},
            {"role": "user", "content": "Count from 1 to 5."}
        ]

        print_info("   Streaming response:")
        print("   ", end="")

        full_response = ""
        usage_info = None

        try:
            for event in client.llm.infer_stream(config_name, messages):
                if event['type'] == 'chunk':
                    content = event['content']
                    full_response += content
                    print(content, end='', flush=True)
                elif event['type'] == 'done':
                    usage_info = event.get('usage')
                    print()  # New line after streaming
                elif event['type'] == 'error':
                    print()
                    print_error(f"Stream error: {event['message']}")
                    break

            if usage_info:
                print_success("Streaming completed successfully")
                print_info(f"   Full response length: {len(full_response)} chars")
                print_info(f"   Usage: {usage_info}")
            else:
                print_info("Streaming failed (expected with placeholder API key)")
                print_success("SDK correctly handled streaming request")

        except Exception as e:
            print_info(f"\n   Stream error (expected with placeholder key): {str(e)[:80]}")
            print_success("SDK correctly handled streaming request")

        # Cleanup
        print_info("\n3. Cleaning up")
        client.llm.delete(config_name)
        print_success(f"Deleted {config_name}")

        return True

    except Exception as e:
        print_error(f"Test failed: {e}")
        import traceback
        traceback.print_exc()
        return False

def main():
    # Load environment variables
    if _load_dotenv2:
        env_path = os.path.join(os.path.dirname(__file__), '..', '.env')
        _load_dotenv2(env_path)
        print(f"Loaded environment from: {env_path}\n")

    print_header("LLM New Features Test Suite")

    results = {}

    # Run tests
    results['Secret Management'] = test_secret_management()
    results['Archive & Delete'] = test_archive_and_delete()
    results['Streaming Inference'] = test_streaming_inference()

    # Print summary
    print_header("Test Summary")

    passed = sum(1 for v in results.values() if v)
    total = len(results)

    for test_name, result in results.items():
        if result:
            print_success(f"{test_name}: PASSED")
        else:
            print_error(f"{test_name}: FAILED")

    print(f"\nTotal: {passed}/{total} tests passed")

    if passed == total:
        print(f"\n{GREEN}🎉 All tests passed!{RESET}")
        return 0
    else:
        print(f"\n{YELLOW}⚠️  {total - passed} test(s) failed{RESET}")
        return 1

if __name__ == "__main__":
    sys.exit(main())

