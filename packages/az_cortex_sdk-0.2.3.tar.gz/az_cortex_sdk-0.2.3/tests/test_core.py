"""Tests for CortexClient and CortexConfig."""

import os
from unittest.mock import Mock, patch

import pytest

from az_cortex_sdk import CortexClient, CortexConfig
from az_cortex_sdk.auth import AuthManager
from az_cortex_sdk.http_client import HTTPClient


class TestCortexClient:
    """Test cases for CortexClient."""

    def test_client_initialization_with_config(self):
        """Test client initialization with config object."""
        config = CortexConfig(
            base_url="https://test.example.com",
            client_id="test-id",
            client_secret="test-secret",
            tenant="test-tenant",
        )

        client = CortexClient(config=config)

        assert client.config.base_url == "https://test.example.com"
        assert client.config.client_id == "test-id"
        assert client.config.tenant == "test-tenant"
        assert hasattr(client, "environments")
        assert hasattr(client, "models")

    def test_client_initialization_with_params(self):
        """Test client initialization with individual parameters."""
        client = CortexClient(
            base_url="https://test.example.com",
            client_id="test-id",
            client_secret="test-secret",
            tenant="test-tenant",
            verify_ssl=False,
        )

        assert client.config.base_url == "https://test.example.com"
        assert client.config.client_id == "test-id"
        assert client.config.tenant == "test-tenant"
        assert client.config.verify_ssl is False

    def test_from_credentials_classmethod(self):
        """Test creating client from credentials."""
        client = CortexClient.from_credentials(
            base_url="https://test.example.com",
            client_id="test-id",
            client_secret="test-secret",
            tenant="test-tenant",
        )

        assert client.config.base_url == "https://test.example.com"
        assert client.config.client_id == "test-id"
        assert client.config.tenant == "test-tenant"

    @patch.dict(
        "os.environ",
        {
            "CORTEX_API_BASE_URL": "https://env.example.com",
            "CORTEX_CLIENT_ID": "env-id",
            "CORTEX_CLIENT_SECRET": "env-secret",
            "CORTEX_TENANT": "env-tenant",
        },
    )
    def test_from_env_classmethod(self):
        """Test creating client from environment variables."""
        client = CortexClient.from_env()

        assert client.config.base_url == "https://env.example.com"
        assert client.config.client_id == "env-id"
        assert client.config.tenant == "env-tenant"

    def test_context_manager(self):
        """Test client as context manager."""
        config = CortexConfig(
            base_url="https://test.example.com",
            client_id="test-id",
            client_secret="test-secret",
        )

        with CortexClient(config=config) as client:
            assert isinstance(client, CortexClient)

        # Client should be closed after context exit
        # (We can't easily test this without mocking)

    @patch("requests.get")
    def test_health_check(self, mock_requests_get):
        """Test health check method."""
        # Mock successful response
        mock_response = Mock()
        mock_response.status_code = 200
        mock_requests_get.return_value = mock_response

        config = CortexConfig(
            base_url="https://test.example.com",
            client_id="test-id",
            client_secret="test-secret",
        )

        client = CortexClient(config=config)

        # Mock the auth manager to avoid authentication
        mock_auth_manager = Mock()
        mock_auth_manager.get_auth_headers.return_value = {"Authorization": "Bearer test-token"}
        client._http_client.auth_manager = mock_auth_manager

        result = client.health_check()

        assert result == {"status": "healthy"}
        mock_requests_get.assert_called_once()
        assert mock_requests_get.call_args.kwargs["verify"] is True

    @patch("requests.get")
    def test_health_check_respects_verify_ssl(self, mock_requests_get):
        """Test health check uses the configured SSL verification setting."""
        mock_response = Mock()
        mock_response.status_code = 200
        mock_requests_get.return_value = mock_response

        config = CortexConfig(
            base_url="https://test.example.com",
            client_id="test-id",
            client_secret="test-secret",
            verify_ssl=False,
        )

        client = CortexClient(config=config)
        mock_auth_manager = Mock()
        mock_auth_manager.get_auth_headers.return_value = {"Authorization": "Bearer test-token"}
        client._http_client.auth_manager = mock_auth_manager

        result = client.health_check()

        assert result == {"status": "healthy"}
        assert mock_requests_get.call_args.kwargs["verify"] is False

    def test_parameter_override(self):
        """Test that explicit parameters override config."""
        config = CortexConfig(
            base_url="https://config.example.com",
            client_id="config-id",
            client_secret="config-secret",
            tenant="config-tenant",
        )

        client = CortexClient(
            config=config,
            base_url="https://override.example.com",
            tenant="override-tenant",
        )

        # Overridden values
        assert client.config.base_url == "https://override.example.com"
        assert client.config.tenant == "override-tenant"

        # Non-overridden values from config
        assert client.config.client_id == "config-id"
        assert client.config.client_secret == "config-secret"


class TestCortexConfig:
    """Test cases for CortexConfig."""

    def test_config_with_explicit_values(self):
        """Test config creation with explicit values."""
        config = CortexConfig(
            base_url="https://test.example.com",
            client_id="test-id",
            client_secret="test-secret",
            tenant="test-tenant",
        )

        assert config.base_url == "https://test.example.com"
        assert config.client_id == "test-id"
        assert config.client_secret == "test-secret"
        assert config.tenant == "test-tenant"

    def test_auth_url_constructed_from_tenant_parameter(self):
        """Test that auth_url is dynamically constructed from tenant parameter."""
        config = CortexConfig(
            client_id="test-id",
            client_secret="test-secret",
            tenant="linkbank",
        )

        expected_auth_url = "https://auth.az-dev.nearlyhuman.ai/realms/linkbank/protocol/openid-connect/token"
        assert config.auth_url == expected_auth_url
        assert config.tenant == "linkbank"

    @patch.dict(os.environ, {"CORTEX_TENANT": "linkbank"}, clear=False)
    def test_auth_url_constructed_from_tenant_env_var(self):
        """Test that auth_url is dynamically constructed from CORTEX_TENANT env var."""
        config = CortexConfig(
            client_id="test-id",
            client_secret="test-secret",
        )

        expected_auth_url = "https://auth.az-dev.nearlyhuman.ai/realms/linkbank/protocol/openid-connect/token"
        assert config.auth_url == expected_auth_url
        assert config.tenant == "linkbank"

    @patch.dict(os.environ, {"CORTEX_TENANT": "env-tenant"}, clear=False)
    def test_tenant_parameter_overrides_env_var(self):
        """Test that explicit tenant parameter overrides environment variable."""
        config = CortexConfig(
            client_id="test-id",
            client_secret="test-secret",
            tenant="param-tenant",
        )

        expected_auth_url = "https://auth.az-dev.nearlyhuman.ai/realms/param-tenant/protocol/openid-connect/token"
        assert config.auth_url == expected_auth_url
        assert config.tenant == "param-tenant"

    def test_explicit_auth_url_not_overridden(self):
        """Test that explicit auth_url is not overridden by tenant."""
        custom_auth_url = "https://custom.auth.example.com/token"
        config = CortexConfig(
            client_id="test-id",
            client_secret="test-secret",
            tenant="linkbank",
            auth_url=custom_auth_url,
        )

        assert config.auth_url == custom_auth_url
        assert config.tenant == "linkbank"

    @patch.dict(
        os.environ,
        {
            "CORTEX_AUTH_URL": "https://env.auth.example.com/token",
            "CORTEX_TENANT": "linkbank",
        },
        clear=False,
    )
    def test_auth_url_env_var_overrides_tenant(self):
        """Test that CORTEX_AUTH_URL env var takes precedence over tenant."""
        config = CortexConfig(
            client_id="test-id",
            client_secret="test-secret",
        )

        # When CORTEX_AUTH_URL is set, it should be used directly
        assert config.auth_url == "https://env.auth.example.com/token"
        assert config.tenant == "linkbank"

    def test_default_tenant_is_demo(self):
        """Test that default tenant is 'demo' when not specified."""
        with patch.dict(os.environ, {}, clear=True):
            # Clear CORTEX_TENANT if it exists
            os.environ.pop("CORTEX_TENANT", None)

            config = CortexConfig(
                client_id="test-id",
                client_secret="test-secret",
            )

            expected_auth_url = "https://auth.az-dev.nearlyhuman.ai/realms/demo/protocol/openid-connect/token"
            assert config.tenant == "demo"
            assert config.auth_url == expected_auth_url

    def test_base_url_trailing_slash_removed(self):
        """Test that trailing slash is removed from base_url."""
        config = CortexConfig(
            base_url="https://test.example.com/",
            client_id="test-id",
            client_secret="test-secret",
        )

        assert config.base_url == "https://test.example.com"

    def test_missing_client_secret_raises_error(self):
        """Test that missing client_secret raises validation error."""
        with pytest.raises(ValueError, match="client_secret is required"):
            CortexConfig(
                base_url="https://test.example.com",
                client_id="test-id",
                client_secret="",
            )

    def test_custom_timeout_and_retries(self):
        """Test custom timeout and retry settings."""
        config = CortexConfig(
            client_id="test-id",
            client_secret="test-secret",
            timeout=60.0,
            max_retries=5,
            retry_delay=2.0,
        )

        assert config.timeout == 60.0
        assert config.max_retries == 5
        assert config.retry_delay == 2.0

    def test_custom_scope(self):
        """Test custom OAuth scope."""
        config = CortexConfig(
            client_id="test-id",
            client_secret="test-secret",
            scope="custom-scope",
        )

        assert config.scope == "custom-scope"

    def test_verify_ssl_defaults_true(self):
        """Test SSL verification is enabled by default."""
        config = CortexConfig(
            client_id="test-id",
            client_secret="test-secret",
        )

        assert config.verify_ssl is True

    def test_verify_ssl_can_be_disabled_explicitly(self):
        """Test SSL verification can be disabled explicitly."""
        config = CortexConfig(
            client_id="test-id",
            client_secret="test-secret",
            verify_ssl=False,
        )

        assert config.verify_ssl is False

    @patch.dict(os.environ, {"CORTEX_VERIFY_SSL": "false"}, clear=False)
    def test_verify_ssl_from_environment_variable(self):
        """Test SSL verification can be configured from environment."""
        config = CortexConfig(
            client_id="test-id",
            client_secret="test-secret",
        )

        assert config.verify_ssl is False

    def test_auth_manager_session_respects_verify_ssl(self):
        """Test auth session uses the configured SSL verification setting."""
        config = CortexConfig(
            client_id="test-id",
            client_secret="test-secret",
            verify_ssl=False,
        )

        auth_manager = AuthManager(config)
        try:
            assert auth_manager._session.verify is False
        finally:
            auth_manager.close()

    def test_http_client_session_respects_verify_ssl(self):
        """Test API session uses the configured SSL verification setting."""
        config = CortexConfig(
            client_id="test-id",
            client_secret="test-secret",
            verify_ssl=False,
        )

        http_client = HTTPClient(config)
        try:
            assert http_client._session.verify is False
        finally:
            http_client.close()

    @patch.dict(
        os.environ,
        {
            "CORTEX_API_BASE_URL": "https://env.example.com",
            "CORTEX_CLIENT_ID": "env-id",
            "CORTEX_CLIENT_SECRET": "env-secret",
            "CORTEX_TENANT": "env-tenant",
            "CORTEX_TIMEOUT": "45.0",
            "CORTEX_MAX_RETRIES": "5",
        },
        clear=False,
    )
    def test_config_from_environment_variables(self):
        """Test config creation from environment variables."""
        config = CortexConfig()

        assert config.base_url == "https://env.example.com"
        assert config.client_id == "env-id"
        assert config.client_secret == "env-secret"
        assert config.tenant == "env-tenant"
        # Note: timeout and max_retries from env vars are strings and need conversion
        # The current implementation uses Field defaults, not env var parsing for these

    def test_multiple_tenants_produce_different_auth_urls(self):
        """Test that different tenants produce different auth URLs."""
        tenants = ["demo", "linkbank", "production", "staging"]

        for tenant in tenants:
            config = CortexConfig(
                client_id="test-id",
                client_secret="test-secret",
                tenant=tenant,
            )

            expected_auth_url = f"https://auth.az-dev.nearlyhuman.ai/realms/{tenant}/protocol/openid-connect/token"
            assert config.auth_url == expected_auth_url
            assert config.tenant == tenant

