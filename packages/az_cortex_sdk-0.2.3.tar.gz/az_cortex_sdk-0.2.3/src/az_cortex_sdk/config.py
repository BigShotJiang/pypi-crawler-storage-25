"""Configuration management for Azure Cortex SDK."""

import os

from pydantic import BaseModel, Field, field_validator


def get_env_with_fallback(primary_key: str, fallback_key: str, default: str = "") -> str:
    """Get environment variable with fallback to alternative naming convention.

    Azure ML injects secrets with hyphens (e.g., CORTEX-API-BASE-URL),
    but standard convention uses underscores (e.g., CORTEX_API_BASE_URL).
    This function tries both.

    Args:
        primary_key: Primary environment variable name (with underscores)
        fallback_key: Fallback environment variable name (with hyphens)
        default: Default value if neither is found

    Returns:
        str: Environment variable value or default

    """
    value = os.getenv(primary_key)
    if value is not None:
        return value

    value = os.getenv(fallback_key)
    if value is not None:
        return value

    return default


def get_bool_env_with_fallback(
    primary_key: str, fallback_key: str, default: bool = True
) -> bool:
    """Get boolean environment variable with fallback to alternative naming."""
    value = get_env_with_fallback(primary_key, fallback_key, "")
    if value == "":
        return default

    normalized = value.strip().lower()
    if normalized in {"1", "true", "yes", "on"}:
        return True
    if normalized in {"0", "false", "no", "off"}:
        return False

    return default


class CortexConfig(BaseModel):
    """Configuration for Azure Cortex SDK client."""

    base_url: str = Field(
        default_factory=lambda: get_env_with_fallback(
            "CORTEX_API_BASE_URL",
            "CORTEX-API-BASE-URL",
            "https://api.az-dev.nearlyhuman.ai"
        ),
        description="Base URL for the Cortex API",
    )

    client_id: str = Field(
        default_factory=lambda: get_env_with_fallback(
            "CORTEX_CLIENT_ID",
            "CORTEX-CLIENT-ID",
            "cortex-api-test"
        ),
        description="OAuth client ID",
    )

    client_secret: str = Field(
        default_factory=lambda: get_env_with_fallback(
            "CORTEX_CLIENT_SECRET",
            "CORTEX-CLIENT-SECRET",
            ""
        ),
        description="OAuth client secret",
    )

    tenant: str = Field(
        default_factory=lambda: get_env_with_fallback(
            "CORTEX_TENANT",
            "CORTEX-TENANT",
            "demo"
        ),
        description="Tenant name",
    )

    auth_url: str = Field(
        default_factory=lambda: get_env_with_fallback(
            "CORTEX_AUTH_URL",
            "CORTEX-AUTH-URL",
            ""
        ),
        description="OAuth token endpoint URL. If not provided, will be constructed from tenant.",
    )

    timeout: float = Field(default=30.0, description="Request timeout in seconds")

    max_retries: int = Field(default=3, description="Maximum number of retry attempts")

    retry_delay: float = Field(
        default=1.0, description="Base delay between retries in seconds"
    )

    scope: str = Field(default="openid", description="OAuth scope")

    verify_ssl: bool = Field(
        default_factory=lambda: get_bool_env_with_fallback(
            "CORTEX_VERIFY_SSL",
            "CORTEX-VERIFY-SSL",
            True,
        ),
        description="Whether to verify SSL certificates for auth and API requests",
    )

    @field_validator("base_url")
    @classmethod
    def validate_base_url(cls, v: str) -> str:
        """Ensure base URL doesn't end with slash."""
        return v.rstrip("/")

    def __init__(self, **data):
        """Initialize config and set auth_url if not provided."""
        # Set auth_url before calling parent __init__ if not provided
        # Check both data dict (explicit params) and env var (with fallback)
        auth_url_from_env = get_env_with_fallback("CORTEX_AUTH_URL", "CORTEX-AUTH-URL", "")
        if not data.get("auth_url") and not auth_url_from_env:
            # Get tenant from data, env var (with fallback), or default to "demo"
            tenant = data.get("tenant") or get_env_with_fallback("CORTEX_TENANT", "CORTEX-TENANT", "demo")
            data["auth_url"] = (
                f"https://auth.az-dev.nearlyhuman.ai/realms/{tenant}/protocol/openid-connect/token"
            )

        super().__init__(**data)

    @field_validator("client_secret")
    @classmethod
    def validate_client_secret(cls, v: str) -> str:
        """Ensure client secret is provided."""
        if not v:
            raise ValueError("client_secret is required")
        return v

    class Config:
        """Pydantic config."""

        env_prefix = "CORTEX_"
        case_sensitive = False


def get_default_config() -> CortexConfig:
    """Get default configuration from environment variables."""
    return CortexConfig()
