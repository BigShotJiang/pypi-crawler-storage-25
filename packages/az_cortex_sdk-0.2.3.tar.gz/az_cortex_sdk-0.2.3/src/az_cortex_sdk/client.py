"""Main client for Azure Cortex SDK."""

from typing import Optional

from .config import CortexConfig, get_default_config
from .http_client import HTTPClient
from .services import (
    AppService,
    ConversationService,
    DeploymentService,
    DocumentCollectionService,
    DocumentCollectionVersionService,
    DocumentService,
    DocumentVersionService,
    EmbeddingService,
    EndpointService,
    EnvironmentService,
    EnvironmentVersionService,
    FileService,
    InferenceService,
    LLMService,
    MessageService,
    ModelService,
    ModelVersionService,
    ScoringService,
    SecretsService,
    VectorService,
)


class CortexClient:
    """Main client for Azure Cortex ML API."""

    def __init__(
        self,
        config: Optional[CortexConfig] = None,
        base_url: Optional[str] = None,
        client_id: Optional[str] = None,
        client_secret: Optional[str] = None,
        tenant: Optional[str] = None,
        **kwargs,
    ):
        """Initialize Cortex client.

        Args:
            config: CortexConfig instance. If not provided, will be created from other args or env vars.
            base_url: API base URL. Overrides config if provided.
            client_id: OAuth client ID. Overrides config if provided.
            client_secret: OAuth client secret. Overrides config if provided.
            tenant: Tenant name. Overrides config if provided.
            **kwargs: Additional config parameters.

        """
        if config is None:
            config = get_default_config()

        # Override config with explicit parameters
        if base_url is not None:
            config.base_url = base_url
        if client_id is not None:
            config.client_id = client_id
        if client_secret is not None:
            config.client_secret = client_secret
        if tenant is not None:
            config.tenant = tenant

        # Apply any additional kwargs
        for key, value in kwargs.items():
            if hasattr(config, key):
                setattr(config, key, value)

        self.config = config
        self._http_client = HTTPClient(config)

        # Initialize services
        self.apps = AppService(self._http_client)
        self.conversations = ConversationService(self._http_client)
        self.deployments = DeploymentService(self._http_client)
        self.documents = DocumentService(self._http_client)
        self.document_versions = DocumentVersionService(self._http_client)
        self.document_collections = DocumentCollectionService(self._http_client)
        self.document_collection_versions = DocumentCollectionVersionService(
            self._http_client
        )
        self.embeddings = EmbeddingService(self._http_client)
        self.endpoints = EndpointService(self._http_client)
        self.environments = EnvironmentService(self._http_client)
        self.environment_versions = EnvironmentVersionService(self._http_client)
        self.files = FileService(self._http_client)
        self.inferences = InferenceService(self._http_client)
        self.llm = LLMService(self._http_client)
        self.messages = MessageService(self._http_client)
        self.models = ModelService(self._http_client)
        self.model_versions = ModelVersionService(self._http_client)
        self.scorings = ScoringService(self._http_client)
        self.secrets = SecretsService(self._http_client)
        self.vectors = VectorService(self._http_client)

    def health_check(self) -> dict:
        """Check API health status."""
        try:
            # Health endpoint returns status 200 with no JSON body, so we make a raw request
            import requests

            url = f"{self.config.base_url}/health"
            headers = self._http_client.auth_manager.get_auth_headers()
            response = requests.get(
                url,
                headers=headers,
                timeout=self.config.timeout,
                verify=self.config.verify_ssl,
            )
            return {"status": "healthy" if response.status_code == 200 else "unhealthy"}
        except Exception as e:
            return {"status": "unhealthy", "error": str(e)}

    def close(self) -> None:
        """Close the client and cleanup resources."""
        self._http_client.close()

    def __enter__(self):
        """Context manager entry."""
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager exit."""
        self.close()

    @classmethod
    def from_env(cls) -> "CortexClient":
        """Create client from environment variables."""
        return cls(config=get_default_config())

    @classmethod
    def from_credentials(
        cls,
        base_url: str,
        client_id: str,
        client_secret: str,
        tenant: str = "demo",
        **kwargs,
    ) -> "CortexClient":
        """Create client from explicit credentials."""
        return cls(
            base_url=base_url,
            client_id=client_id,
            client_secret=client_secret,
            tenant=tenant,
            **kwargs,
        )
