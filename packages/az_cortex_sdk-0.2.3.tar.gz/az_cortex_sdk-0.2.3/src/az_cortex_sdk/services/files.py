"""File service for Azure Cortex SDK."""

from typing import Any, Dict, Optional

from ..http_client import HTTPClient
from ..models import File, PaginatedResponse


class FileService:
    """Service for managing files."""

    def __init__(self, http_client: HTTPClient):
        self.http_client = http_client

    def list(
        self,
        page: int = 1,
        per_page: int = 25,
        file_name: Optional[str] = None,
        owner_email: Optional[str] = None,
    ) -> PaginatedResponse:
        """List all files with pagination."""
        params = {
            "page": page,
            "perPage": per_page,
            "fileName": file_name,
            "ownerEmail": owner_email,
        }

        response = self.http_client.get("/files", params=params)

        files = [File(**item) for item in response.get("items", [])]

        return PaginatedResponse(
            items=files,
            page=response.get("page", page),
            per_page=response.get("perPage", per_page),
            total=response.get("total", len(files)),
            has_next=response.get("page", page) * response.get("perPage", per_page)
            < response.get("total", 0),
            has_prev=response.get("page", page) > 1,
        )

    def get(self, file_id: str) -> File:
        """Get a specific file by ID."""
        response = self.http_client.get(f"/files/{file_id}")
        return File(**response)

    def delete(self, file_id: str) -> Dict[str, Any]:
        """Delete a file."""
        response = self.http_client.delete(f"/files/{file_id}")
        return response

    def download(self, file_id: str) -> bytes:
        """Download a file and return its content as bytes."""
        response = self.http_client.get(f"/files/{file_id}/download", stream=True)
        # Return the content as bytes, not the Response object
        return response.content

    def upload(self, file_path: str, owner_email: Optional[str] = None) -> File:
        """Upload a file."""
        params = (
            {"ownerEmail": owner_email} if owner_email else None
        )  # Optional parameter
        response = self.http_client.post(
            "/files", files={"file": open(file_path, "rb")}, params=params
        )
        return File(**response)

    def upload_buffer(
        self, buffer: bytes, file_name: str, owner_email: Optional[str] = None
    ) -> File:
        """Upload a file from a buffer."""
        params = (
            {"ownerEmail": owner_email} if owner_email else None
        )  # Optional parameter
        response = self.http_client.post(
            "/files",
            files={"file": (file_name, buffer, "application/octet-stream")},
            params=params,
        )
        return File(**response)
