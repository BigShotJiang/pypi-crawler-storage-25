"""Document collection version service for Azure Cortex SDK."""

from typing import Any, Dict, Optional

from ..exceptions import NotFoundError
from ..http_client import HTTPClient
from ..models import (
    DocumentCollectionVersion,
    PaginatedResponse,
)


class DocumentCollectionVersionService:
    """Service for managing document collection versions."""

    def __init__(self, http_client: HTTPClient):
        self.http_client = http_client

    def list(
        self, collection_name: str, app_name: str, page: int = 1, per_page: int = 25
    ) -> PaginatedResponse:
        """List all versions of a document collection."""
        params = {
            "page": page,
            "perPage": per_page,
            "appName": app_name,
            "collectionName": collection_name,
        }

        response = self.http_client.get("/document-collection-versions", params=params)

        versions = [
            DocumentCollectionVersion(**item) for item in response.get("documents", [])
        ]

        return PaginatedResponse(
            items=versions,
            page=response.get("page", page),
            per_page=response.get("perPage", per_page),
            total=response.get("total", len(versions)),
            has_next=response.get("page", page) * response.get("perPage", per_page)
            < response.get("total", 0),
            has_prev=response.get("page", page) > 1,
        )

    def get(
        self, collection_name: str, version: str, app_name: str
    ) -> Optional[DocumentCollectionVersion]:
        """Get specific version of a document collection."""
        try:
            response = self.http_client.get(
                f"/document-collection-versions/{version}",
                params={"appName": app_name, "collectionName": collection_name},
            )
            return DocumentCollectionVersion(**response)
        except NotFoundError:
            raise
        except Exception:
            return None

    def get_latest(
        self, collection_name: str, app_name: str
    ) -> Optional[DocumentCollectionVersion]:
        """Get latest version of a document collection."""
        try:
            response = self.http_client.get(
                "/document-collection-versions/latest",
                params={"appName": app_name, "collectionName": collection_name},
            )
            return DocumentCollectionVersion(**response)
        except NotFoundError:
            raise
        except Exception:
            return None

    def update(
        self,
        collection_name: str,
        version: str,
        app_name: str,
        documents: Dict[str, str],
    ) -> DocumentCollectionVersion:
        """Update a version of a document collection."""
        data = {
            "documents": documents,
        }
        response = self.http_client.put(
            f"/document-collection-versions/{version}",
            params={"appName": app_name, "collectionName": collection_name},
            data=data,
        )
        return DocumentCollectionVersion(**response)

    def create(
        self, collection_name: str, app_name: str, documents: Dict[str, str]
    ) -> DocumentCollectionVersion:
        """Create a new version of a document collection."""
        data = {
            "documents": documents,
        }
        response = self.http_client.post(
            "/document-collection-versions",
            data=data,
            params={"appName": app_name, "collectionName": collection_name},
        )
        return DocumentCollectionVersion(**response)

    def delete(
        self, collection_name: str, version: str, app_name: str
    ) -> Dict[str, Any]:
        """Delete a version of a document collection."""
        response = self.http_client.delete(
            f"/document-collection-versions/{version}",
            params={"appName": app_name, "collectionName": collection_name},
        )
        return response
