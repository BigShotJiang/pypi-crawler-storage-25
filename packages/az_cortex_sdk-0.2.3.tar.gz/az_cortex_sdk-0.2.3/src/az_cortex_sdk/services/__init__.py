"""Services module for Azure Cortex SDK."""

from .apps import AppService
from .conversations import ConversationService
from .deployments import DeploymentService
from .document_collection_versions import DocumentCollectionVersionService
from .document_collections import DocumentCollectionService
from .document_versions import DocumentVersionService
from .documents import DocumentService
from .embeddings import EmbeddingService
from .endpoints import EndpointService
from .environment_versions import EnvironmentVersionService
from .environments import EnvironmentService
from .files import FileService
from .inferences import InferenceService
from .llm import LLMService
from .messages import MessageService
from .model_versions import ModelVersionService
from .models import ModelService
from .scorings import ScoringService
from .secrets import SecretsService
from .vectors import VectorService

__all__ = [
    "AppService",
    "ConversationService",
    "DeploymentService",
    "DocumentService",
    "DocumentVersionService",
    "DocumentCollectionService",
    "DocumentCollectionVersionService",
    "EmbeddingService",
    "EndpointService",
    "EnvironmentService",
    "EnvironmentVersionService",
    "FileService",
    "InferenceService",
    "LLMService",
    "MessageService",
    "ModelService",
    "ModelVersionService",
    "ScoringService",
    "SecretsService",
    "VectorService",
]
