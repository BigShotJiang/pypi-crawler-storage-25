"""Secrets service for Azure Cortex SDK."""

from ..exceptions import NotFoundError
from ..http_client import HTTPClient
from ..models import (
    SecretCreate,
    SecretDelete,
    SecretResponse,
    SecretsList,
    SecretUpdate,
    SecretValueResponse,
)


class SecretsService:
    """Service for managing Azure Key Vault secrets."""

    def __init__(self, http_client: HTTPClient):
        self.http_client = http_client

    def list(self, page: int = 1, per_page: int = 25) -> SecretsList:
        """List all secrets with pagination.

        Args:
            page: Page number (default: 1)
            per_page: Items per page (default: 25)

        Returns:
            SecretsList: List of secrets with pagination info

        """
        params = {
            "page": page,
            "perPage": per_page,
        }

        try:
            response = self.http_client.get("/secrets", params=params)
            return SecretsList(**response)
        except Exception as e:
            # Add context to the error
            raise Exception(f"Failed to list secrets: {e}") from e

    def create(self, name: str, value: str) -> SecretResponse:
        """Create a new secret.

        Args:
            name: Secret name
            value: Secret value

        Returns:
            SecretResponse: Creation response with name and message

        """
        data = SecretCreate(name=name, value=value).model_dump()

        try:
            response = self.http_client.post("/secrets", data=data)
            return SecretResponse(**response)
        except Exception as e:
            raise Exception(f"Failed to create secret '{name}': {e}") from e

    def update(self, name: str, value: str) -> SecretResponse:
        """Update an existing secret's value.

        Args:
            name: Secret name
            value: New secret value

        Returns:
            SecretResponse: Update response with name and message

        """
        data = SecretUpdate(value=value).model_dump()

        try:
            response = self.http_client.put(f"/secrets/{name}", data=data)
            return SecretResponse(**response)
        except NotFoundError:
            raise NotFoundError(f"Secret '{name}' not found")
        except Exception as e:
            if "not found" in str(e).lower() or "404" in str(e):
                raise NotFoundError(f"Secret '{name}' not found")
            raise Exception(f"Failed to update secret '{name}': {e}") from e

    def delete(self, name: str) -> SecretResponse:
        """Delete a secret.

        Args:
            name: Secret name

        Returns:
            SecretResponse: Deletion response with name and message

        """
        data = SecretDelete(name=name).model_dump()

        try:
            response = self.http_client.delete("/secrets", data=data)
            return SecretResponse(**response)
        except NotFoundError:
            raise NotFoundError(f"Secret '{name}' not found")
        except Exception as e:
            if "not found" in str(e).lower() or "404" in str(e):
                raise NotFoundError(f"Secret '{name}' not found")
            raise Exception(f"Failed to delete secret '{name}': {e}") from e

    def set(self, name: str, value: str) -> SecretResponse:
        """Set a secret value (create if doesn't exist, update if exists).

        This is a convenience method that attempts to create a secret first,
        and if it already exists, updates it instead.

        Args:
            name: Secret name
            value: Secret value

        Returns:
            SecretResponse: Operation response with name and message

        """
        try:
            # Try to create first
            return self.create(name, value)
        except Exception as create_error:
            # If creation fails (likely because secret exists), try to update
            if (
                "already exists" in str(create_error).lower()
                or "conflict" in str(create_error).lower()
            ):
                try:
                    return self.update(name, value)
                except Exception as update_error:
                    raise Exception(
                        f"Failed to set secret '{name}': Create failed ({create_error}), Update failed ({update_error})"
                    ) from update_error
            else:
                # Re-raise the original create error if it's not a conflict
                raise create_error

    def get(self, name: str) -> SecretValueResponse:
        """Get a secret's value.

        Args:
            name: Secret name

        Returns:
            SecretValueResponse: Response containing the secret value

        """
        try:
            response = self.http_client.get(f"/secrets/{name}/value")
            return SecretValueResponse(**response)
        except NotFoundError:
            raise NotFoundError(f"Secret '{name}' not found")
        except Exception as e:
            if "not found" in str(e).lower() or "404" in str(e):
                raise NotFoundError(f"Secret '{name}' not found")
            raise Exception(f"Failed to get secret '{name}': {e}") from e
