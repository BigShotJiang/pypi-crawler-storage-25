"""Model version service for Azure Cortex SDK."""

from pathlib import Path
from typing import Any, Dict, Optional

from ..exceptions import NotFoundError
from ..http_client import HTTPClient
from ..models import ModelVersion, PaginatedResponse, RegistrationResult, UploadResult


class ModelVersionService:
    """Service for managing Azure ML model versions."""

    def __init__(self, http_client: HTTPClient):
        self.http_client = http_client

    def _convert_version_to_integer(self, version: str) -> str:
        """Convert semantic version to integer for Azure ML API."""
        # Azure ML API expects integer versions, not semantic versions
        # Convert "1.0.0" -> "1", "2.1.0" -> "2", etc.
        try:
            # Try to extract the major version number
            major_version = version.split(".")[0]
            if major_version.isdigit():
                return major_version
            else:
                # If it's already an integer string, return as-is
                return version
        except (ValueError, AttributeError, IndexError):
            # Fallback: return as-is
            return version

    def list(
        self,
        model_name: str,
        page: int = 1,
        per_page: int = 25,
        latest: bool = False,
        is_archived: bool = False,
    ) -> PaginatedResponse:
        """List model versions with pagination and filtering."""
        params = {
            "modelName": model_name,
            "page": page,
            "perPage": per_page,
            "isArchived": str(is_archived).lower(),
        }

        if latest:
            params["latest"] = "true"

        try:
            response = self.http_client.get("/model-versions", params=params)

            # Handle response format from API
            versions_data = response.get("versions", [])
            versions = [ModelVersion(**item) for item in versions_data]

            return PaginatedResponse(
                items=versions,
                page=response.get("page", page),
                per_page=response.get("perPage", per_page),
                total=response.get("totalDocuments", len(versions)),
                has_next=response.get("page", page) * response.get("perPage", per_page)
                < response.get("totalDocuments", 0),
                has_prev=response.get("page", page) > 1,
            )
        except Exception as e:
            raise Exception(
                f"Failed to list model versions for '{model_name}': {e}"
            ) from e

    def get(self, model_name: str, version: str) -> Optional[ModelVersion]:
        """Get specific model version."""
        try:
            # Convert version to integer format for Azure ML API
            api_version = self._convert_version_to_integer(version)
            response = self.http_client.get(
                f"/model-versions/{api_version}", params={"modelName": model_name}
            )

            # Transform API response to match SDK model structure
            transformed_response = {
                **response,
                "name": model_name,  # Use the model name from the request
                "version": response.get(
                    "name", api_version
                ),  # API returns version in "name" field
            }

            # Handle isArchived field - move from properties to top level if present
            if "properties" in transformed_response and isinstance(
                transformed_response["properties"], dict
            ):
                if "isArchived" in transformed_response["properties"]:
                    transformed_response["is_archived"] = transformed_response[
                        "properties"
                    ]["isArchived"]
                    # Remove from properties to avoid validation issues
                    transformed_response["properties"] = {
                        k: v
                        for k, v in transformed_response["properties"].items()
                        if k != "isArchived"
                    }

            return ModelVersion(**transformed_response)
        except NotFoundError:
            raise NotFoundError(f"Model version '{model_name}:{version}' not found")
        except Exception as e:
            if "not found" in str(e).lower() or "404" in str(e):
                raise NotFoundError(f"Model version '{model_name}:{version}' not found")
            raise

    def register(
        self,
        model_name: str,
        version: str,
        description: Optional[str] = None,
        model_uri: Optional[str] = None,
        model_type: Optional[str] = None,
        tags: Optional[Dict[str, str]] = None,
        properties: Optional[Dict[str, str]] = None,
        flavors: Optional[Dict[str, Any]] = None,
        job_name: Optional[str] = None,
    ) -> RegistrationResult:
        """Register (create) a new model version."""
        data: Dict[str, Any] = {}

        if description:
            data["description"] = description
        if model_uri:
            data["modelUri"] = model_uri
        if model_type:
            data["modelType"] = model_type
        if tags:
            data["tags"] = tags
        if properties:
            data["properties"] = properties
        if flavors:
            data["flavors"] = flavors
        if job_name:
            data["jobName"] = job_name

        # Convert version to integer format for Azure ML API
        api_version = self._convert_version_to_integer(version)

        try:
            response = self.http_client.post(
                f"/model-versions/{api_version}",
                params={"modelName": model_name},
                data=data,
            )

            return RegistrationResult(
                success=True,  # If we got here, it was successful
                name=model_name,  # Use the original name we sent
                version=response.get(
                    "name", api_version
                ),  # API returns version in "name" field
                id=response.get("id"),
                error=None,
            )
        except Exception as e:
            return RegistrationResult(
                success=False,
                name=model_name,
                version=version,
                id=None,
                error=str(e),
            )

    def register_from_file(
        self,
        file_path: str,
        model_name: str,
        version: str,
        description: Optional[str] = None,
        model_type: Optional[str] = None,
        tags: Optional[Dict[str, str]] = None,
        properties: Optional[Dict[str, str]] = None,
        flavors: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """Register a model version by uploading a file."""
        file_path = Path(file_path)
        if not file_path.exists():
            raise FileNotFoundError(f"File not found: {file_path}")

        # Convert version to integer format for Azure ML API
        api_version = self._convert_version_to_integer(version)

        # Prepare form data
        form_data = {}
        if description:
            form_data["description"] = description
        if model_type:
            form_data["modelType"] = model_type
        if tags:
            form_data["tags"] = tags
        if properties:
            form_data["properties"] = properties
        if flavors:
            form_data["flavors"] = flavors

        # Prepare file for upload
        files = {
            "file": (file_path.name, open(file_path, "rb"), "application/octet-stream")
        }

        try:
            response = self.http_client.post(
                f"/model-versions/{api_version}",
                params={"modelName": model_name},
                files=files,
                data=form_data,
            )

            return {
                "upload_result": UploadResult(
                    success=True,
                    file_name=file_path.name,
                    azure_ml_uri=response.get("modelUri"),
                    size_bytes=file_path.stat().st_size,
                ),
                "registration_result": RegistrationResult(
                    success=True,  # If we got here, it was successful
                    name=model_name,  # Use the original name we sent
                    version=response.get(
                        "name", api_version
                    ),  # API returns version in "name" field
                    id=response.get("id"),
                    error=None,
                ),
            }
        except Exception as e:
            return {
                "upload_result": UploadResult(
                    success=False,
                    file_name=file_path.name,
                    azure_ml_uri=None,
                    size_bytes=file_path.stat().st_size,
                    error=str(e),
                ),
                "registration_result": RegistrationResult(
                    success=False,
                    name=model_name,
                    version=version,
                    id=None,
                    error=str(e),
                ),
            }
        finally:
            # Close the file
            if "file" in files:
                files["file"][1].close()

    def register_from_buffer(
        self,
        buffer: bytes,
        file_name: str,
        model_name: str,
        version: str,
        description: Optional[str] = None,
        model_type: Optional[str] = None,
        tags: Optional[Dict[str, str]] = None,
        properties: Optional[Dict[str, str]] = None,
        flavors: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """Register a model version by uploading from a buffer."""
        # Convert version to integer format for Azure ML API
        api_version = self._convert_version_to_integer(version)

        # Prepare form data
        form_data = {}
        if description:
            form_data["description"] = description
        if model_type:
            form_data["modelType"] = model_type
        if tags:
            form_data["tags"] = tags
        if properties:
            form_data["properties"] = properties
        if flavors:
            form_data["flavors"] = flavors

        # Prepare file for upload
        files = {"file": (file_name, buffer, "application/octet-stream")}

        try:
            response = self.http_client.post(
                f"/model-versions/{api_version}",
                params={"modelName": model_name},
                files=files,
                data=form_data,
            )

            return {
                "upload_result": UploadResult(
                    success=True,
                    file_name=file_name,
                    azure_ml_uri=response.get("modelUri"),
                    size_bytes=len(buffer),
                ),
                "registration_result": RegistrationResult(
                    success=True,  # If we got here, it was successful
                    name=model_name,  # Use the original name we sent
                    version=response.get(
                        "name", api_version
                    ),  # API returns version in "name" field
                    id=response.get("id"),
                    error=None,
                ),
            }
        except Exception as e:
            return {
                "upload_result": UploadResult(
                    success=False,
                    file_name=file_name,
                    azure_ml_uri=None,
                    size_bytes=len(buffer),
                    error=str(e),
                ),
                "registration_result": RegistrationResult(
                    success=False,
                    name=model_name,
                    version=version,
                    id=None,
                    error=str(e),
                ),
            }

    def update(
        self,
        model_name: str,
        version: str,
        description: Optional[str] = None,
        model_uri: Optional[str] = None,
        tags: Optional[Dict[str, str]] = None,
        properties: Optional[Dict[str, str]] = None,
        flavors: Optional[Dict[str, Any]] = None,
        job_name: Optional[str] = None,
        is_archived: Optional[bool] = None,
    ) -> ModelVersion:
        """Update an existing model version."""
        data: Dict[str, Any] = {}

        if description is not None:
            data["description"] = description
        if model_uri is not None:
            data["modelUri"] = model_uri
        if tags is not None:
            data["tags"] = tags
        if properties is not None:
            data["properties"] = properties
        if flavors is not None:
            data["flavors"] = flavors
        if job_name is not None:
            data["jobName"] = job_name
        if is_archived is not None:
            data["isArchived"] = is_archived

        # Convert version to integer format for Azure ML API
        api_version = self._convert_version_to_integer(version)

        try:
            response = self.http_client.put(
                f"/model-versions/{api_version}",
                params={"modelName": model_name},
                data=data,
            )

            # Transform API response to match SDK model structure
            transformed_response = {
                **response,
                "name": model_name,  # Use the model name from the request
                "version": response.get(
                    "name", api_version
                ),  # API returns version in "name" field
            }

            # Handle isArchived field - move from properties to top level if present
            if "properties" in transformed_response and isinstance(
                transformed_response["properties"], dict
            ):
                if "isArchived" in transformed_response["properties"]:
                    transformed_response["is_archived"] = transformed_response[
                        "properties"
                    ]["isArchived"]
                    # Remove from properties to avoid validation issues
                    transformed_response["properties"] = {
                        k: v
                        for k, v in transformed_response["properties"].items()
                        if k != "isArchived"
                    }

            return ModelVersion(**transformed_response)
        except Exception as e:
            raise Exception(
                f"Failed to update model version '{model_name}:{version}': {e}"
            ) from e

    def archive(self, model_name: str, version: str) -> ModelVersion:
        """Archive a model version."""
        return self.update(model_name, version, is_archived=True)

    def unarchive(self, model_name: str, version: str) -> ModelVersion:
        """Unarchive a model version."""
        return self.update(model_name, version, is_archived=False)
