"""Endpoint service for Azure Cortex SDK."""

from typing import Any, Dict, Optional

from ..exceptions import NotFoundError
from ..http_client import HTTPClient
from ..models import Endpoint, EndpointIdentity, PaginatedResponse


class EndpointService:
    """Service for managing endpoints."""

    def __init__(self, http_client: HTTPClient):
        self.http_client = http_client

    def list(
        self,
        page: int = 1,
        per_page: int = 25,
    ) -> PaginatedResponse:
        """List endpoints.

        Args:
            page: Page number (1-based) - Note: pagination not currently supported by API
            per_page: Number of items per page - Note: pagination not currently supported by API

        Returns:
            PaginatedResponse: Paginated list of endpoints

        """
        # Note: The /endpoints API does not support pagination params.
        # Passing page/perPage causes it to return empty results.
        response = self.http_client.get("/endpoints")

        # Transform response data and convert to Endpoint objects
        endpoints = []
        if "documents" in response:
            endpoints = [
                Endpoint(**self._transform_endpoint_data(endpoint))
                for endpoint in response["documents"]
            ]

        # Transform to PaginatedResponse format
        total_documents = response.get("totalDocuments", len(endpoints))

        return PaginatedResponse(
            items=endpoints,
            page=1,
            per_page=total_documents or 1,
            total=total_documents,
            has_next=False,
            has_prev=False,
        )

    def get(self, name: str) -> Optional[Endpoint]:
        """Get a specific endpoint by name.

        Args:
            name: Endpoint name

        Returns:
            Endpoint: The endpoint if found, None otherwise

        Raises:
            NotFoundError: If endpoint is not found

        """
        try:
            response = self.http_client.get(f"/endpoints/{name}")
            return Endpoint(**self._transform_endpoint_data(response))
        except NotFoundError:
            return None

    def create(self, name: str) -> Dict[str, str]:
        """Create a new endpoint.

        Args:
            name: Endpoint name

        Returns:
            Dict[str, str]: Creation response message

        """
        endpoint_data = EndpointIdentity(name=name)
        response = self.http_client.post(
            "/endpoints", data=endpoint_data.model_dump(by_alias=True)
        )
        return response

    def delete(self, name: str) -> Dict[str, str]:
        """Delete an endpoint.

        Args:
            name: Endpoint name

        Returns:
            Dict[str, str]: Deletion response message

        """
        endpoint_data = EndpointIdentity(name=name)
        response = self.http_client.delete(
            "/endpoints", data=endpoint_data.model_dump(by_alias=True)
        )
        return response

    def _transform_endpoint_data(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Transform endpoint data from API response format to model format.

        Args:
            data: Raw endpoint data from API

        Returns:
            Dict[str, Any]: Transformed endpoint data

        """
        transformed = data.copy()

        # Handle nested properties transformation if needed
        if "properties" in transformed and isinstance(transformed["properties"], dict):
            properties = transformed["properties"]

            # Transform camelCase to snake_case for specific fields
            if "provisioningState" in properties:
                properties["provisioning_state"] = properties.pop("provisioningState")
            if "publicNetworkAccess" in properties:
                properties["public_network_access"] = properties.pop(
                    "publicNetworkAccess"
                )
            if "authMode" in properties:
                properties["auth_mode"] = properties.pop("authMode")
            if "scoringUri" in properties:
                properties["scoring_uri"] = properties.pop("scoringUri")
            if "swaggerUri" in properties:
                properties["swagger_uri"] = properties.pop("swaggerUri")

        # Handle systemData transformation
        if "systemData" in transformed:
            system_data = transformed.pop("systemData")
            # Transform camelCase to snake_case for systemData fields
            if "createdAt" in system_data:
                system_data["created_at"] = system_data.pop("createdAt")
            if "createdBy" in system_data:
                system_data["created_by"] = system_data.pop("createdBy")
            if "createdByType" in system_data:
                system_data["created_by_type"] = system_data.pop("createdByType")
            if "lastModifiedAt" in system_data:
                system_data["last_modified_at"] = system_data.pop("lastModifiedAt")
            if "lastModifiedBy" in system_data:
                system_data["last_modified_by"] = system_data.pop("lastModifiedBy")
            if "lastModifiedByType" in system_data:
                system_data["last_modified_by_type"] = system_data.pop("lastModifiedByType")
            transformed["system_data"] = system_data

        return transformed
