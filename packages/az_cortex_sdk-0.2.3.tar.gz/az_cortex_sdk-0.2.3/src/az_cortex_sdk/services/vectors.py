"""Vector database service for Azure Cortex SDK."""

from typing import Any, Dict, List, Optional

from ..http_client import HTTPClient
from ..models import (
    BatchSearchResponse,
    CollectionData,
    CollectionListResponse,
    DocumentAddResponse,
    PaginatedResponse,
    SearchResponse,
    VectorConfig,
    VectorDeleteResponse,
)


class VectorService:
    """Service for managing vector database configurations and operations."""

    def __init__(self, http_client: HTTPClient):
        self.http_client = http_client

    # Configuration Management

    def list(
        self,
        provider: Optional[str] = None,
        is_archived: Optional[bool] = None,
        page: int = 1,
        per_page: int = 25,
    ) -> PaginatedResponse:
        """List all vector database configurations with pagination.

        Args:
            provider: Filter by provider (e.g., 'pgvector', 'pinecone', 'qdrant', 'chroma')
            is_archived: Include archived configs
            page: Page number
            per_page: Items per page

        Returns:
            PaginatedResponse: Paginated list of vector configurations

        """
        params: Dict[str, Any] = {
            "page": page,
            "perPage": per_page,
        }

        if provider is not None:
            params["provider"] = provider
        if is_archived is not None:
            params["isArchived"] = str(is_archived).lower()

        response = self.http_client.get("/vector-configs", params=params)

        items_data = response.get("documents", [])
        total_count = response.get("totalDocuments", len(items_data))

        transformed_items = []
        for item in items_data:
            transformed_item = self._transform_vector_config(item)
            transformed_items.append(transformed_item)

        return PaginatedResponse(
            items=[VectorConfig(**item) for item in transformed_items],
            total=total_count,
            page=page,
            per_page=per_page,
            has_next=page * per_page < total_count,
            has_prev=page > 1,
        )

    def get(self, config_name: str) -> Optional[VectorConfig]:
        """Get a specific vector database configuration by name.

        Args:
            config_name: Configuration name

        Returns:
            VectorConfig: The vector database configuration

        """
        response = self.http_client.get(f"/vector-configs/{config_name}")
        transformed_response = self._transform_vector_config(response)
        return VectorConfig(**transformed_response)

    def create(
        self,
        config_name: str,
        provider: str,
        connection_options: Optional[Dict[str, Any]] = None,
        api_key: Optional[str] = None,
        secret_name: Optional[str] = None,
        embedding_provider: Optional[str] = None,
        embedding_model: Optional[str] = None,
        embedding_api_key: Optional[str] = None,
        embedding_secret_name: Optional[str] = None,
        embedding_endpoint: Optional[str] = None,
        embedding_deployment: Optional[str] = None,
    ) -> VectorConfig:
        """Create a new vector database configuration.

        Args:
            config_name: Configuration name
            provider: Vector DB provider ('pgvector', 'pinecone', 'qdrant', 'chroma', 'weaviate')
            connection_options: Provider-specific connection options
            api_key: API key (auto-stored as secret, mutually exclusive with secret_name)
            secret_name: Key Vault secret name (mutually exclusive with api_key)
            embedding_provider: Embedding provider ('openai', 'azure-openai', 'cohere', 'mistral')
            embedding_model: Embedding model name
            embedding_api_key: Embedding API key (auto-stored as secret)
            embedding_secret_name: Secret name for embedding API key
            embedding_endpoint: Embedding endpoint (for Azure OpenAI)
            embedding_deployment: Embedding deployment name (for Azure OpenAI)

        Returns:
            VectorConfig: The created vector database configuration

        """
        data: Dict[str, Any] = {
            "configName": config_name,
            "provider": provider,
        }

        if connection_options is not None:
            data["connectionOptions"] = self._transform_connection_options_to_api(
                connection_options
            )
        if api_key is not None:
            data["apiKey"] = api_key
        if secret_name is not None:
            data["secretName"] = secret_name
        if embedding_provider is not None:
            data["embeddingProvider"] = embedding_provider
        if embedding_model is not None:
            data["embeddingModel"] = embedding_model
        if embedding_api_key is not None:
            data["embeddingApiKey"] = embedding_api_key
        if embedding_secret_name is not None:
            data["embeddingSecretName"] = embedding_secret_name
        if embedding_endpoint is not None:
            data["embeddingEndpoint"] = embedding_endpoint
        if embedding_deployment is not None:
            data["embeddingDeployment"] = embedding_deployment

        response = self.http_client.post("/vector-configs", data=data)
        transformed_response = self._transform_vector_config(response)
        return VectorConfig(**transformed_response)

    def update(
        self,
        config_name: str,
        provider: Optional[str] = None,
        connection_options: Optional[Dict[str, Any]] = None,
        api_key: Optional[str] = None,
        secret_name: Optional[str] = None,
        embedding_provider: Optional[str] = None,
        embedding_model: Optional[str] = None,
        embedding_api_key: Optional[str] = None,
        embedding_secret_name: Optional[str] = None,
        embedding_endpoint: Optional[str] = None,
        embedding_deployment: Optional[str] = None,
    ) -> VectorConfig:
        """Update an existing vector database configuration.

        Args:
            config_name: Configuration name
            provider: Vector DB provider
            connection_options: Provider-specific connection options
            api_key: API key (auto-stored as secret)
            secret_name: Key Vault secret name
            embedding_provider: Embedding provider
            embedding_model: Embedding model name
            embedding_api_key: Embedding API key
            embedding_secret_name: Secret name for embedding API key
            embedding_endpoint: Embedding endpoint (for Azure OpenAI)
            embedding_deployment: Embedding deployment name (for Azure OpenAI)

        Returns:
            VectorConfig: The updated vector database configuration

        """
        data: Dict[str, Any] = {}

        if provider is not None:
            data["provider"] = provider
        if connection_options is not None:
            data["connectionOptions"] = self._transform_connection_options_to_api(
                connection_options
            )
        if api_key is not None:
            data["apiKey"] = api_key
        if secret_name is not None:
            data["secretName"] = secret_name
        if embedding_provider is not None:
            data["embeddingProvider"] = embedding_provider
        if embedding_model is not None:
            data["embeddingModel"] = embedding_model
        if embedding_api_key is not None:
            data["embeddingApiKey"] = embedding_api_key
        if embedding_secret_name is not None:
            data["embeddingSecretName"] = embedding_secret_name
        if embedding_endpoint is not None:
            data["embeddingEndpoint"] = embedding_endpoint
        if embedding_deployment is not None:
            data["embeddingDeployment"] = embedding_deployment

        response = self.http_client.put(f"/vector-configs/{config_name}", data=data)
        transformed_response = self._transform_vector_config(response)
        return VectorConfig(**transformed_response)

    def archive(self, config_name: str) -> VectorConfig:
        """Archive a vector database configuration (soft delete).

        Args:
            config_name: Configuration name

        Returns:
            VectorConfig: The archived vector database configuration

        """
        response = self.http_client.put(
            f"/vector-configs/{config_name}/archive", data={}
        )
        transformed_response = self._transform_vector_config(response)
        return VectorConfig(**transformed_response)

    def delete(self, config_name: str) -> VectorDeleteResponse:
        """Hard delete a vector database configuration.

        Args:
            config_name: Configuration name

        Returns:
            VectorDeleteResponse: Deletion confirmation message

        """
        response = self.http_client.delete(f"/vector-configs/{config_name}")
        return VectorDeleteResponse(**response)

    # Collection Management

    def create_collection(
        self,
        config_name: str,
        collection_name: str,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> CollectionData:
        """Create a new collection in the vector database.

        Args:
            config_name: Vector database configuration name
            collection_name: Name for the new collection
            metadata: Optional metadata for the collection

        Returns:
            CollectionData: The created collection information

        """
        data: Dict[str, Any] = {
            "configName": config_name,
            "collectionName": collection_name,
        }

        if metadata is not None:
            data["metadata"] = metadata

        response = self.http_client.post("/vector-collections", data=data)
        transformed_response = self._transform_collection_data(response)
        return CollectionData(**transformed_response)

    def list_collections(self, config_name: str) -> CollectionListResponse:
        """List all collections in a vector database configuration.

        Args:
            config_name: Vector database configuration name

        Returns:
            CollectionListResponse: List of collections

        """
        params = {"configName": config_name}
        response = self.http_client.get("/vector-collections", params=params)

        # Transform collections
        collections_data = response.get("documents", [])
        transformed_collections = [
            self._transform_collection_data(col) for col in collections_data
        ]

        return CollectionListResponse(
            collections=[CollectionData(**col) for col in transformed_collections],
            count=response.get("count", len(transformed_collections)),
        )

    def delete_collection(
        self,
        config_name: str,
        collection_name: str,
    ) -> VectorDeleteResponse:
        """Delete a collection from the vector database.

        Args:
            config_name: Vector database configuration name
            collection_name: Collection name to delete

        Returns:
            VectorDeleteResponse: Deletion confirmation message

        """
        data = {
            "configName": config_name,
            "collectionName": collection_name,
        }
        response = self.http_client.delete("/vector-collections", data=data)
        return VectorDeleteResponse(**response)

    def get_collection(
        self,
        config_name: str,
        collection_name: str,
    ) -> CollectionData:
        """Get information about a collection.

        Args:
            config_name: Vector database configuration name
            collection_name: Collection name

        Returns:
            CollectionData: Collection information

        """
        response = self.http_client.get(
            f"/vector-collections/{collection_name}",
            params={"configName": config_name},
        )
        transformed_response = self._transform_collection_data(response)
        return CollectionData(**transformed_response)

    # Document Management

    def add_documents(
        self,
        config_name: str,
        collection_name: str,
        documents: List[Dict[str, Any]],
    ) -> DocumentAddResponse:
        """Add documents to a collection.

        Args:
            config_name: Vector database configuration name
            collection_name: Collection name
            documents: List of documents with 'content', optional 'id', 'metadata', and 'vector'

        Returns:
            DocumentAddResponse: Information about added documents

        """
        data = {
            "configName": config_name,
            "collectionName": collection_name,
            "documents": documents,
        }

        response = self.http_client.post("/vector-documents", data=data)
        transformed_response = self._transform_document_add_response(response)
        return DocumentAddResponse(**transformed_response)

    def delete_document(
        self,
        config_name: str,
        collection_name: str,
        document_id: str,
    ) -> VectorDeleteResponse:
        """Delete a document from a collection.

        Args:
            config_name: Vector database configuration name
            collection_name: Collection name
            document_id: Document ID to delete

        Returns:
            VectorDeleteResponse: Deletion confirmation message

        """
        data = {
            "configName": config_name,
            "collectionName": collection_name,
            "documentId": document_id,
        }
        response = self.http_client.delete("/vector-documents", data=data)
        return VectorDeleteResponse(**response)

    def get_document(
        self,
        config_name: str,
        collection_name: str,
        document_id: str,
    ) -> Dict[str, Any]:
        """Get a document from a collection.

        Args:
            config_name: Vector database configuration name
            collection_name: Collection name
            document_id: Document ID to retrieve

        Returns:
            Dict[str, Any]: Document information

        """
        response = self.http_client.get(
            f"/vector-documents/{document_id}",
            params={"configName": config_name, "collectionName": collection_name},
        )
        return response

    def update_document(
        self,
        config_name: str,
        collection_name: str,
        document_id: str,
        content: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
        vector: Optional[List[float]] = None,
    ) -> Dict[str, Any]:
        """Update a document in a collection.

        Args:
            config_name: Vector database configuration name
            collection_name: Collection name
            document_id: Document ID to update
            content: New document content
            metadata: New document metadata
            vector: New embedding vector

        Returns:
            Dict[str, Any]: Updated document information

        """
        data: Dict[str, Any] = {}

        if content is not None:
            data["content"] = content
        if metadata is not None:
            data["metadata"] = metadata
        if vector is not None:
            data["vector"] = vector

        response = self.http_client.put(
            f"/vector-documents/{document_id}",
            data=data,
            params={"configName": config_name, "collectionName": collection_name},
        )
        return response

    # Search Operations

    def list_documents(
        self,
        config_name: str,
        collection_name: str,
        filters: Optional[Dict[str, Any]] = None,
        page: int = 1,
        per_page: int = 100,
        include_embeddings: bool = False,
    ) -> Dict[str, Any]:
        """List documents from a collection with optional filtering.

        Args:
            config_name: Vector database configuration name
            collection_name: Collection name
            filters: Optional filter criteria in the format:
                {
                    "operator": "AND" | "OR",
                    "conditions": [
                        {"field": "meta.field_name", "operator": "==", "value": "value"}
                    ]
                }
            page: Page number (1-indexed, default: 1)
            per_page: Number of documents per page (default: 100, max: 1000)
            include_embeddings: If True, include embedding vectors in the response

        Returns:
            Dict containing:
                - documents: List of documents with id, content, metadata, and optionally embedding
                - totalDocuments: Total number of documents

        """
        import json
        from urllib.parse import quote

        # Build query params
        query_parts = [
            f"configName={config_name}",
            f"collectionName={collection_name}",
            f"page={page}",
            f"perPage={per_page}",
        ]

        if filters is not None:
            encoded_filter = quote(json.dumps(filters), safe="")
            query_parts.append(f"filters={encoded_filter}")

        if include_embeddings:
            query_parts.append("includeEmbeddings=true")

        path = f"/vector-documents?{'&'.join(query_parts)}"
        response = self.http_client.get(path, params=None)

        return response

    def search(
        self,
        config_name: str,
        collection_name: str,
        query: str,
        k: Optional[int] = None,
        filter: Optional[Dict[str, Any]] = None,
    ) -> SearchResponse:
        """Perform similarity search in a collection.

        Args:
            config_name: Vector database configuration name
            collection_name: Collection name
            query: Text query (will be embedded)
            k: Number of results to return (default: 5)
            filter: Optional metadata filter

        Returns:
            SearchResponse: Search results

        """
        data: Dict[str, Any] = {
            "configName": config_name,
            "collectionName": collection_name,
            "query": query,
        }

        if k is not None:
            data["k"] = k
        if filter is not None:
            data["filter"] = filter

        response = self.http_client.post("/vector-search", data=data)
        return self._transform_search_response(response)

    def search_with_scores(
        self,
        config_name: str,
        collection_name: str,
        query: str,
        k: Optional[int] = None,
        filter: Optional[Dict[str, Any]] = None,
    ) -> SearchResponse:
        """Perform similarity search with scores in a collection.

        Args:
            config_name: Vector database configuration name
            collection_name: Collection name
            query: Text query (will be embedded)
            k: Number of results to return (default: 5)
            filter: Optional metadata filter

        Returns:
            SearchResponse: Search results with similarity scores

        """
        data: Dict[str, Any] = {
            "configName": config_name,
            "collectionName": collection_name,
            "query": query,
        }

        if k is not None:
            data["k"] = k
        if filter is not None:
            data["filter"] = filter

        response = self.http_client.post("/vector-search/with-scores", data=data)
        return self._transform_search_response(response)

    def search_by_vector(
        self,
        config_name: str,
        collection_name: str,
        vector: List[float],
        k: Optional[int] = None,
        filter: Optional[Dict[str, Any]] = None,
    ) -> SearchResponse:
        """Search using a pre-computed embedding vector.

        Args:
            config_name: Vector database configuration name
            collection_name: Collection name
            vector: Pre-computed embedding vector
            k: Number of results to return (default: 5)
            filter: Optional metadata filter

        Returns:
            SearchResponse: Search results

        """
        data: Dict[str, Any] = {
            "configName": config_name,
            "collectionName": collection_name,
            "vector": vector,
        }

        if k is not None:
            data["k"] = k
        if filter is not None:
            data["filter"] = filter

        response = self.http_client.post("/vector-search/by-vector", data=data)
        return self._transform_search_response(response)

    def mmr_search(
        self,
        config_name: str,
        collection_name: str,
        query: str,
        k: Optional[int] = None,
        fetch_k: Optional[int] = None,
        lambda_param: Optional[float] = None,
        filter: Optional[Dict[str, Any]] = None,
    ) -> SearchResponse:
        """Perform Maximum Marginal Relevance search for diverse results.

        Args:
            config_name: Vector database configuration name
            collection_name: Collection name
            query: Text query
            k: Number of results to return (default: 5)
            fetch_k: Number of candidates to fetch before diversification (default: 20)
            lambda_param: Diversity parameter, 0=max diversity, 1=max relevance (default: 0.5)
            filter: Optional metadata filter

        Returns:
            SearchResponse: Diverse search results

        """
        data: Dict[str, Any] = {
            "configName": config_name,
            "collectionName": collection_name,
            "query": query,
        }

        if k is not None:
            data["k"] = k
        if fetch_k is not None:
            data["fetchK"] = fetch_k
        if lambda_param is not None:
            data["lambda"] = lambda_param
        if filter is not None:
            data["filter"] = filter

        response = self.http_client.post("/vector-search/mmr", data=data)
        return self._transform_search_response(response)

    def batch_search(
        self,
        config_name: str,
        collection_name: str,
        queries: List[str],
        k: Optional[int] = None,
        filter: Optional[Dict[str, Any]] = None,
    ) -> BatchSearchResponse:
        """Perform batch search for multiple queries.

        Args:
            config_name: Vector database configuration name
            collection_name: Collection name
            queries: List of text queries
            k: Number of results per query (default: 5)
            filter: Optional metadata filter

        Returns:
            BatchSearchResponse: Results for each query

        """
        data: Dict[str, Any] = {
            "configName": config_name,
            "collectionName": collection_name,
            "queries": queries,
        }

        if k is not None:
            data["k"] = k
        if filter is not None:
            data["filter"] = filter

        response = self.http_client.post("/vector-search/batch", data=data)
        return self._transform_batch_search_response(response)

    # Transformation helpers

    def _transform_vector_config(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Transform API response to SDK model format."""
        transformed = {}

        field_mapping = {
            "_id": "id",
            "tenantKey": "tenant_key",
            "configName": "config_name",
            "provider": "provider",
            "apiKey": "api_key",
            "secretName": "secret_name",
            "embeddingProvider": "embedding_provider",
            "embeddingModel": "embedding_model",
            "embeddingSecretName": "embedding_secret_name",
            "embeddingApiKey": "embedding_api_key",
            "embeddingEndpoint": "embedding_endpoint",
            "embeddingDeployment": "embedding_deployment",
            "isArchived": "is_archived",
            "createdDate": "created_date",
            "updatedDate": "updated_date",
        }

        for api_field, sdk_field in field_mapping.items():
            if api_field in data:
                transformed[sdk_field] = data[api_field]

        # Transform connectionOptions
        if "connectionOptions" in data and data["connectionOptions"]:
            transformed["connection_options"] = (
                self._transform_connection_options_from_api(data["connectionOptions"])
            )

        return transformed

    def _transform_connection_options_from_api(
        self, data: Dict[str, Any]
    ) -> Dict[str, Any]:
        """Transform connection options from API format to SDK format."""
        transformed = {}

        field_mapping = {
            "host": "host",
            "port": "port",
            "database": "database",
            "tableName": "table_name",
            "distanceStrategy": "distance_strategy",
            "ssl": "ssl",
            "sslMode": "ssl_mode",
            "environment": "environment",
            "indexName": "index_name",
            "url": "url",
            "collectionName": "collection_name",
        }

        for api_field, sdk_field in field_mapping.items():
            if api_field in data:
                transformed[sdk_field] = data[api_field]

        return transformed

    def _transform_connection_options_to_api(
        self, data: Dict[str, Any]
    ) -> Dict[str, Any]:
        """Transform connection options from SDK format to API format."""
        transformed = {}

        field_mapping = {
            "host": "host",
            "port": "port",
            "database": "database",
            "table_name": "tableName",
            "distance_strategy": "distanceStrategy",
            "ssl": "ssl",
            "ssl_mode": "sslMode",
            "environment": "environment",
            "index_name": "indexName",
            "url": "url",
            "collection_name": "collectionName",
        }

        for sdk_field, api_field in field_mapping.items():
            if sdk_field in data and data[sdk_field] is not None:
                transformed[api_field] = data[sdk_field]

        return transformed

    def _transform_collection_data(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Transform collection data from API format to SDK format."""
        transformed = {}

        field_mapping = {
            "collectionName": "collection_name",
            "documentCount": "document_count",
            "metadata": "metadata",
            "createdDate": "created_date",
        }

        for api_field, sdk_field in field_mapping.items():
            if api_field in data:
                transformed[sdk_field] = data[api_field]

        return transformed

    def _transform_document_add_response(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Transform document add response from API format to SDK format."""
        return {
            "added_count": data.get("addedCount", 0),
            "document_ids": data.get("documentIds", []),
        }

    def _transform_search_response(self, data: Dict[str, Any]) -> SearchResponse:
        """Transform search response from API format to SDK format."""
        from ..models import SearchResult

        results_data = data.get("results", [])
        results = [SearchResult(**result) for result in results_data]

        return SearchResponse(results=results, count=data.get("count", len(results)))

    def _transform_batch_search_response(
        self, data: Dict[str, Any]
    ) -> BatchSearchResponse:
        """Transform batch search response from API format to SDK format."""
        from ..models import BatchSearchResult, SearchResult

        results_data = data.get("results", [])
        batch_results = []

        for result_item in results_data:
            search_results = [
                SearchResult(**sr) for sr in result_item.get("results", [])
            ]
            batch_results.append(
                BatchSearchResult(
                    query=result_item.get("query", ""), results=search_results
                )
            )

        return BatchSearchResponse(results=batch_results)
