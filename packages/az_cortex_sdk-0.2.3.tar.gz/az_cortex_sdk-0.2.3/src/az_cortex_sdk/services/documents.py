"""Document service for Azure Cortex SDK."""

import json
from pathlib import Path
from typing import Any, Dict, Optional, Union

from ..exceptions import NotFoundError
from ..http_client import HTTPClient
from ..models import (
    Document,
    DocumentVersion,
    PaginatedResponse,
    RegistrationResult,
    UploadResult,
)


class DocumentService:
    """Service for managing documents."""

    def __init__(self, http_client: HTTPClient):
        self.http_client = http_client

    def list(
        self,
        app_name: str,
        folder: Optional[str] = None,
        page: int = 1,
        per_page: int = 25,
        include_latest: bool = True,
    ) -> PaginatedResponse:
        """List all documents with pagination."""
        params = {
            "page": page,
            "perPage": per_page,
            "includeLatest": include_latest,
            "appName": app_name,
        }

        if folder:
            params["folder"] = folder

        response = self.http_client.get("/documents", params=params)

        # Handle both response formats: {items: []} and {documents: []}
        items_data = response.get("items", response.get("documents", []))
        total_count = response.get(
            "total", response.get("totalDocuments", len(items_data))
        )

        documents = [Document(**item) for item in items_data]

        return PaginatedResponse(
            items=documents,
            page=response.get("page", page),
            per_page=response.get("perPage", per_page),
            total=total_count,
            has_next=response.get("page", page) * response.get("perPage", per_page)
            < total_count,
            has_prev=response.get("page", page) > 1,
        )

    def get_container(
        self, name: str, app_name: str, folder: Optional[str] = None
    ) -> Optional[Document]:
        """Get document container (base document info without version details)."""
        try:
            response = self.http_client.get(
                f"/documents/{name}", params={"appName": app_name, "folder": folder}
            )

            # Transform API response to match SDK document structure
            transformed_response = {**response}

            if "properties" in response and isinstance(response["properties"], dict):
                props = response["properties"]
                if "description" in props:
                    transformed_response["description"] = props["description"]
                if "latestVersion" in props:
                    transformed_response["latest_version"] = props["latestVersion"]
                if "nextVersion" in props:
                    transformed_response["next_version"] = props["nextVersion"]
                if "isArchived" in props:
                    transformed_response["is_archived"] = props["isArchived"]
                if "tags" in props:
                    transformed_response["tags"] = props["tags"]
                if "properties" in props:
                    transformed_response["properties"] = props["properties"]

            return Document(**transformed_response)
        except NotFoundError:
            raise
        except Exception:
            return None

    def get(self, name: str, version: str, app_name: str) -> Optional[DocumentVersion]:
        """Get specific document version."""
        try:
            # Convert version to integer format for Azure ML API
            api_version = self._convert_version_to_integer(version)
            # Use the correct API endpoint: GET /document-versions/{version}?documentName={name}
            response = self.http_client.get(
                f"/document-versions/{api_version}",
                params={"appName": app_name, "documentName": name},
            )

            # Transform API response to match SDK document structure
            # API returns: {"name": "1", "properties": {...}, ...}
            # SDK expects: {"name": "document-name", "version": "1", ...}
            transformed_response = {
                **response,
                "name": name,  # Use the document name from the request
                "version": version,  # Use the original version from the request
            }

            # Extract nested properties if they exist
            if "properties" in response and isinstance(response["properties"], dict):
                props = response["properties"]
                # Map common properties from nested structure
                if "description" in props:
                    transformed_response["description"] = props["description"]
                if "documentUri" in props:
                    transformed_response["document_uri"] = props["documentUri"]
                if "isArchived" in props:
                    transformed_response["is_archived"] = props["isArchived"]
                if "tags" in props:
                    transformed_response["tags"] = props["tags"]
                if "properties" in props:
                    transformed_response["properties"] = props["properties"]
                if "flavors" in props:
                    transformed_response["flavors"] = props["flavors"]

            return DocumentVersion(**transformed_response)
        except NotFoundError:
            # Re-raise NotFoundError so error handling tests work correctly
            raise
        except Exception:
            return None

    def list_versions(
        self, name: str, app_name: str, page: int = 1, per_page: int = 25
    ) -> PaginatedResponse:
        """List all versions of a document."""
        params = {
            "page": page,
            "appName": app_name,
            "perPage": per_page,
        }

        response = self.http_client.get(f"/documents/{name}/versions", params=params)

        versions = [DocumentVersion(**item) for item in response.get("items", [])]

        return PaginatedResponse(
            items=versions,
            page=response.get("page", page),
            per_page=response.get("perPage", per_page),
            total=response.get("total", len(versions)),
            has_next=response.get("page", page) * response.get("perPage", per_page)
            < response.get("total", 0),
            has_prev=response.get("page", page) > 1,
        )

    def _convert_version_to_integer(self, version: str) -> str:
        """Convert semantic version to integer for Azure ML API."""
        # Azure ML API expects integer versions, not semantic versions
        # Convert "1.0.0" -> "1", "2.1.0" -> "2", etc.
        try:
            # Try to extract the major version number
            major_version = version.split(".")[0]
            if major_version.isdigit():
                return major_version
            else:
                # If it's already an integer string, return as-is
                return version
        except (ValueError, AttributeError, IndexError):
            # Fallback: return as-is
            return version

    def upload_and_create(
        self,
        file_path: Union[str, Path],
        name: str,
        app_name: str,
        version: str,
        folder: Optional[str] = None,
        description: Optional[str] = None,
        tags: Optional[Dict[str, str]] = None,
        properties: Optional[Dict[str, str]] = None,
        flavors: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """Upload a file and create document version."""
        file_path = Path(file_path)

        if not file_path.exists():
            return {
                "upload_result": UploadResult(
                    success=False,
                    file_name=file_path.name,
                    error=f"File not found: {file_path}",
                )
            }

        # Prepare multipart form data
        files = {
            "file": (file_path.name, open(file_path, "rb"), "application/octet-stream")
        }

        # Prepare form fields (name and version come from URL, not form data)
        form_data = {
            "assetType": "file"  # Required for single file uploads
        }

        if description:
            form_data["description"] = description
        if tags:
            form_data["tags"] = json.dumps(tags)
        if properties:
            form_data["properties"] = json.dumps(properties)
        if flavors:
            form_data["flavors"] = json.dumps(flavors)

        try:
            # Convert version to integer format for Azure ML API
            api_version = self._convert_version_to_integer(version)

            # Use the correct API endpoint: POST /document-versions/{version}?documentName={name}
            response = self.http_client.post(
                f"/document-versions/{api_version}",
                files=files,
                data=form_data,
                params={"appName": app_name, "documentName": name, "folder": folder},
            )

            return {
                "upload_result": UploadResult(
                    success=True,
                    file_name=file_path.name,
                    azure_ml_uri=response.get("documentUri"),
                    size_bytes=file_path.stat().st_size,
                ),
                "registration_result": RegistrationResult(
                    success=True,  # If we got here, it was successful
                    name=name,  # Use the original name we sent
                    version=response.get(
                        "name", api_version
                    ),  # API returns version in "name" field
                    id=response.get("id"),
                    error=None,
                ),
            }

        except Exception as e:
            return {
                "upload_result": UploadResult(
                    success=False, file_name=file_path.name, error=str(e)
                )
            }
        finally:
            # Close file handle
            if "file" in files:
                files["file"][1].close()

    def upload_buffer_and_create(
        self,
        buffer: bytes,
        file_name: str,
        name: str,
        app_name: str,
        version: str,
        description: Optional[str] = None,
        tags: Optional[Dict[str, str]] = None,
        properties: Optional[Dict[str, str]] = None,
        flavors: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """Upload a buffer and create document version."""
        # Prepare multipart form data
        files = {"file": (file_name, buffer, "application/octet-stream")}

        # Prepare form fields (name and version come from URL, not form data)
        form_data = {
            "assetType": "file"  # Required for single file uploads
        }

        if description:
            form_data["description"] = description
        if tags:
            form_data["tags"] = json.dumps(tags)
        if properties:
            form_data["properties"] = json.dumps(properties)
        if flavors:
            form_data["flavors"] = json.dumps(flavors)

        try:
            # Convert version to integer format for Azure ML API
            api_version = self._convert_version_to_integer(version)

            # Use the correct API endpoint: POST /document-versions/{version}?documentName={name}
            response = self.http_client.post(
                f"/document-versions/{api_version}",
                files=files,
                data=form_data,
                params={"appName": app_name, "documentName": name},
            )

            return {
                "upload_result": UploadResult(
                    success=True,
                    file_name=file_name,
                    azure_ml_uri=response.get("documentUri"),
                    size_bytes=len(buffer),
                ),
                "registration_result": RegistrationResult(
                    success=True,  # If we got here, it was successful
                    name=name,  # Use the original name we sent
                    version=response.get(
                        "name", api_version
                    ),  # API returns version in "name" field
                    id=response.get("id"),
                    error=None,
                ),
            }

        except Exception as e:
            return {
                "upload_result": UploadResult(
                    success=False, file_name=file_name, error=str(e)
                )
            }

    def download(self, name: str, app_name: str) -> str:
        """Download a document version."""
        response = self.http_client.get(
            f"/documents/{name}/download?appName={app_name}", stream=True
        )
        return response

    def delete(self, name: str, version: str, app_name: str) -> Dict[str, Any]:
        """Delete a document version."""
        # Convert version to integer format for Azure ML API
        api_version = self._convert_version_to_integer(version)
        response = self.http_client.delete(
            f"/document-versions/{api_version}",
            params={"appName": app_name, "documentName": name},
        )
        return response

    def delete_all_versions(self, name: str, app_name: str) -> Dict[str, Any]:
        """Delete all versions of a document."""
        response = self.http_client.delete(
            f"/documents/{name}", params={"appName": app_name}
        )
        return response
