"""Conversation service for Azure Cortex SDK."""

from datetime import datetime
from typing import Any, Dict, Literal, Optional

from ..exceptions import NotFoundError
from ..http_client import HTTPClient
from ..models import (
    Conversation,
    PaginatedResponse,
)


class ConversationService:
    """Service for managing conversations."""

    def __init__(self, http_client: HTTPClient):
        self.http_client = http_client

    def list(
        self,
        tenant_key: Optional[str] = None,
        app_name: Optional[str] = None,
        name: Optional[str] = None,
        email: Optional[str] = None,
        is_escalated: Optional[bool] = None,
        is_resolved: Optional[bool] = None,
        is_archived: Optional[bool] = None,
        is_test_generated: Optional[Literal["true", "false", "all"]] = None,
        created_date_start: Optional[datetime] = None,
        created_date_end: Optional[datetime] = None,
        updated_date_start: Optional[datetime] = None,
        updated_date_end: Optional[datetime] = None,
        page: int = 1,
        per_page: int = 25,
    ) -> PaginatedResponse:
        """List conversations with optional filtering.

        Args:
            tenant_key: Filter by tenant key
            app_name: Filter by app name
            name: Filter by user name
            email: Filter by user email
            is_escalated: Filter by escalation status
            is_resolved: Filter by resolution status
            is_archived: Filter by archived status
            is_test_generated: Filter by test generation status:
                - None (default): Hide test-generated conversations (same as 'false')
                - 'false': Hide test-generated conversations
                - 'true': Show only test-generated conversations
                - 'all': Show all conversations regardless of test generation status
            created_date_start: Filter by creation date (start)
            created_date_end: Filter by creation date (end)
            updated_date_start: Filter by update date (start)
            updated_date_end: Filter by update date (end)
            page: Page number (1-based)
            per_page: Items per page

        Returns:
            PaginatedResponse: Paginated list of conversations

        Note:
            By default, test-generated conversations are hidden. To see test data,
            explicitly set is_test_generated='true' or is_test_generated='all'.

        """
        params = {
            "page": page,
            "perPage": per_page,
        }

        if tenant_key is not None:
            params["tenantKey"] = tenant_key
        if app_name is not None:
            params["appName"] = app_name
        if name is not None:
            params["name"] = name
        if email is not None:
            params["email"] = email
        if is_escalated is not None:
            params["isEscalated"] = "true" if is_escalated else "false"
        if is_resolved is not None:
            params["isResolved"] = "true" if is_resolved else "false"
        if is_archived is not None:
            params["isArchived"] = "true" if is_archived else "false"

        # Handle isTestGenerated filtering with default behavior
        if is_test_generated is None:
            # Default: hide test-generated conversations
            params["isTestGenerated"] = "false"
        elif is_test_generated != "all":
            # Explicit 'true' or 'false' value
            params["isTestGenerated"] = is_test_generated
        # If is_test_generated == "all", don't add the parameter to show all

        if created_date_start is not None:
            params["createdDateStart"] = self._format_datetime_param(created_date_start)
        if created_date_end is not None:
            params["createdDateEnd"] = self._format_datetime_param(created_date_end)
        if updated_date_start is not None:
            params["updatedDateStart"] = self._format_datetime_param(updated_date_start)
        if updated_date_end is not None:
            params["updatedDateEnd"] = self._format_datetime_param(updated_date_end)

        response = self.http_client.get("/conversations", params=params)

        # Handle response format: {documents: [], totalDocuments: N, page: N, perPage: N}
        items_data = response.get("documents", [])
        total_count = response.get("totalDocuments", len(items_data))

        # Transform API response to match SDK model structure
        transformed_items = []
        for item in items_data:
            transformed_item = self._transform_conversation_data(item)
            transformed_items.append(transformed_item)

        conversations = [Conversation(**item) for item in transformed_items]

        return PaginatedResponse(
            items=conversations,
            page=response.get("page", page),
            per_page=response.get("perPage", per_page),
            total=total_count,
            has_next=response.get("page", page) * response.get("perPage", per_page)
            < total_count,
            has_prev=response.get("page", page) > 1,
        )

    def get(self, conversation_id: str) -> Optional[Conversation]:
        """Get specific conversation by ID."""
        try:
            response = self.http_client.get(f"/conversations/{conversation_id}")
            transformed_response = self._transform_conversation_data(response)
            return Conversation(**transformed_response)
        except NotFoundError:
            raise
        except Exception:
            return None

    def update(
        self,
        conversation_id: str,
        name: Optional[str] = None,
        email: Optional[str] = None,
        is_escalated: Optional[bool] = None,
        is_resolved: Optional[bool] = None,
        is_archived: Optional[bool] = None,
        is_test_generated: Optional[bool] = None,
        **kwargs: Any,
    ) -> Conversation:
        """Update conversation (admin only)."""
        data = {}

        if name is not None:
            data["name"] = name
        if email is not None:
            data["email"] = email
        if is_escalated is not None:
            data["isEscalated"] = is_escalated
        if is_resolved is not None:
            data["isResolved"] = is_resolved
        if is_archived is not None:
            data["isArchived"] = is_archived
        if is_test_generated is not None:
            data["isTestGenerated"] = is_test_generated

        # Allow additional fields to be updated
        for key, value in kwargs.items():
            if value is not None:
                data[key] = value

        response = self.http_client.put(f"/conversations/{conversation_id}", data=data)
        transformed_response = self._transform_conversation_data(response)
        return Conversation(**transformed_response)

    def escalate(
        self, conversation_id: str, selected_escalation_route: str
    ) -> Conversation:
        """Escalate conversation to specified route (admin only)."""
        data = {"selectedEscalationRoute": selected_escalation_route}

        response = self.http_client.put(
            f"/conversations/{conversation_id}/escalate", data=data
        )
        transformed_response = self._transform_conversation_data(response)
        return Conversation(**transformed_response)

    def resolve(self, conversation_id: str) -> Conversation:
        """Resolve conversation (admin only)."""
        response = self.http_client.put(f"/conversations/{conversation_id}/resolve")
        transformed_response = self._transform_conversation_data(response)
        return Conversation(**transformed_response)

    def list_test_conversations(
        self,
        tenant_key: Optional[str] = None,
        app_name: Optional[str] = None,
        name: Optional[str] = None,
        email: Optional[str] = None,
        is_escalated: Optional[bool] = None,
        is_resolved: Optional[bool] = None,
        is_archived: Optional[bool] = None,
        created_date_start: Optional[datetime] = None,
        created_date_end: Optional[datetime] = None,
        updated_date_start: Optional[datetime] = None,
        updated_date_end: Optional[datetime] = None,
        page: int = 1,
        per_page: int = 25,
    ) -> PaginatedResponse:
        """List test-generated conversations only.

        This is a convenience method that automatically filters for test-generated
        conversations by setting is_test_generated='true'.

        Args:
            tenant_key: Filter by tenant key
            app_name: Filter by app name
            name: Filter by user name
            email: Filter by user email
            is_escalated: Filter by escalation status
            is_resolved: Filter by resolution status
            is_archived: Filter by archived status
            created_date_start: Filter by creation date (start)
            created_date_end: Filter by creation date (end)
            updated_date_start: Filter by update date (start)
            updated_date_end: Filter by update date (end)
            page: Page number (1-based)
            per_page: Items per page

        Returns:
            PaginatedResponse: Paginated list of test-generated conversations

        """
        return self.list(
            tenant_key=tenant_key,
            app_name=app_name,
            name=name,
            email=email,
            is_escalated=is_escalated,
            is_resolved=is_resolved,
            is_archived=is_archived,
            is_test_generated="true",
            created_date_start=created_date_start,
            created_date_end=created_date_end,
            updated_date_start=updated_date_start,
            updated_date_end=updated_date_end,
            page=page,
            per_page=per_page,
        )

    def _format_datetime_param(self, date_param) -> str:
        """Format datetime parameter for API request."""
        if hasattr(date_param, "isoformat"):
            # It's a datetime object
            return date_param.replace(tzinfo=None).isoformat() + 'Z'
        else:
            # It's a string - ensure it's in proper ISO format
            date_str = str(date_param)
            # If it's just a date (YYYY-MM-DD), add time component
            if len(date_str) == 10 and date_str.count("-") == 2:
                return f"{date_str}T00:00:00Z"
            # If it doesn't end with Z or timezone, add Z
            elif "T" in date_str and not (
                date_str.endswith("Z")
                or "+" in date_str[-6:]
                or date_str.endswith("+00:00")
            ):
                return f"{date_str}Z"
            else:
                return date_str

    def _transform_conversation_data(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Transform API response data to match SDK model structure."""
        transformed = {**data}

        # Transform field names from API format to SDK format
        field_mappings = {
            "_id": "id",
            "tenantKey": "tenant_key",
            "appName": "app_name",
            "endpointName": "endpoint_name",
            "escalationRoutes": "escalation_routes",
            "selectedEscalationRoute": "selected_escalation_route",
            "escalatingInferenceId": "escalating_inference_id",
            "isEscalated": "is_escalated",
            "isResolved": "is_resolved",
            "isArchived": "is_archived",
            "isTestGenerated": "is_test_generated",
            "createdDate": "created_date",
            "updatedDate": "updated_date",
            "escalationDate": "escalation_date",
            "resolutionDate": "resolution_date",
        }

        for api_field, sdk_field in field_mappings.items():
            if api_field in data:
                transformed[sdk_field] = data[api_field]
                if api_field != sdk_field:  # Don't delete if same name
                    transformed.pop(api_field, None)

        # Transform escalation routes if present
        if "escalation_routes" in transformed and transformed["escalation_routes"]:
            escalation_routes = []
            for route in transformed["escalation_routes"]:
                escalation_route = {
                    "escalation_route_id": route.get("escalationRouteId"),
                    "escalation_target_name": route.get("escalationTargetName"),
                    "escalation_link": route.get("escalationLink"),
                    "escalation_tooltip": route.get("escalationTooltip"),
                }
                escalation_routes.append(escalation_route)
            transformed["escalation_routes"] = escalation_routes

        # Parse datetime strings if present
        for date_field in [
            "created_date",
            "updated_date",
            "escalation_date",
            "resolution_date",
        ]:
            if date_field in transformed and transformed[date_field]:
                try:
                    transformed[date_field] = datetime.fromisoformat(
                        transformed[date_field].replace("Z", "+00:00")
                    )
                except (ValueError, AttributeError):
                    pass  # Keep original value if parsing fails

        return transformed
