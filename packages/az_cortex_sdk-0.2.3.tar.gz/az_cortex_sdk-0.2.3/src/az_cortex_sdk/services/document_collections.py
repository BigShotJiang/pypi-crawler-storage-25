"""Document collection service for Azure Cortex SDK."""

from typing import Any, Dict, Optional

from ..exceptions import NotFoundError
from ..http_client import HTTPClient
from ..models import (
    DocumentCollection,
    PaginatedResponse,
)


class DocumentCollectionService:
    """Service for managing document collections."""

    def __init__(self, http_client: HTTPClient):
        self.http_client = http_client

    def list(
        self, app_name: str, page: int = 1, per_page: int = 25
    ) -> PaginatedResponse:
        """List all document collections with pagination."""
        params = {
            "page": page,
            "perPage": per_page,
            "appName": app_name,
        }

        response = self.http_client.get("/document-collections", params=params)

        collections = [
            DocumentCollection(**item) for item in response.get("documents", [])
        ]

        return PaginatedResponse(
            items=collections,
            page=response.get("page", page),
            per_page=response.get("perPage", per_page),
            total=response.get("total", len(collections)),
            has_next=response.get("page", page) * response.get("perPage", per_page)
            < response.get("total", 0),
            has_prev=response.get("page", page) > 1,
        )

    def get(self, name: str, app_name: str) -> Optional[DocumentCollection]:
        """Get specific document collection."""
        try:
            response = self.http_client.get(
                f"/document-collections/{name}", params={"appName": app_name}
            )
            return DocumentCollection(**response)
        except NotFoundError:
            raise
        except Exception:
            return None

    def create(
        self, name: str, app_name: str, documents: Dict[str, str]
    ) -> DocumentCollection:
        """Create a new document collection."""
        response = self.http_client.post(
            f"/document-collections/{name}",
            params={"appName": app_name},
            data={"documents": documents},
        )
        return DocumentCollection(**response)

    def delete(self, name: str, app_name: str) -> Dict[str, Any]:
        """Delete a document collection."""
        response = self.http_client.delete(
            f"/document-collections/{name}", params={"appName": app_name}
        )
        return response
