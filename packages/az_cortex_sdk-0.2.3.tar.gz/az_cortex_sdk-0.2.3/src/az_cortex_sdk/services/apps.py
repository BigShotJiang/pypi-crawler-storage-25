from typing import Any, Dict, Optional

from ..exceptions import NotFoundError
from ..http_client import HTTPClient
from ..models import App, InferenceResponse, PaginatedResponse


class AppService:
    """Service for managing apps."""

    def __init__(self, http_client: HTTPClient):
        self.http_client = http_client

    def list(self, page: int = 1, per_page: int = 25) -> PaginatedResponse:
        """List all apps with pagination."""
        params = {
            "page": page,
            "perPage": per_page,
        }

        response = self.http_client.get("/apps", params=params)

        apps = [App(**item) for item in response.get("documents", [])]

        return PaginatedResponse(
            items=apps,
            page=response.get("page", page),
            per_page=response.get("perPage", per_page),
            total=response.get("total", len(apps)),
            has_next=response.get("page", page) * response.get("perPage", per_page) < response.get("total", 0),
            has_prev=response.get("page", page) > 1,
        )

    def get(self, name: str) -> Optional[App]:
        """Get specific app."""
        try:
            response = self.http_client.get(f"/apps/{name}")
            return App(**response)
        except NotFoundError:
            raise
        except Exception:
            return None

    def create(self, name: str, endpoint_name: Optional[str] = None) -> App:
        """Create a new app."""
        data = {"name": name}
        if endpoint_name:
            data["endpointName"] = endpoint_name
        response = self.http_client.post("/apps", data=data)
        return App(**response)

    def update(self, name: str, endpoint_name: Optional[str] = None) -> App:
        """Update an app."""
        data = {}
        if endpoint_name:
            data["endpointName"] = endpoint_name
        response = self.http_client.put(f"/apps/{name}", data=data)
        return App(**response)

    def delete(self, name: str) -> Dict[str, Any]:
        """Delete an app."""
        response = self.http_client.delete(f"/apps/{name}")
        return response

    def infer(self, name: str, inputs: Dict[str, Any]) -> InferenceResponse:
        """Perform inference on an app.

        Args:
            name: App name
            inputs: Input data for inference

        Returns:
            InferenceResponse: The inference result

        Raises:
            NotFoundError: If app is not found
            APIError: If inference fails

        """
        request_data = {"inputs": inputs}
        response = self.http_client.post(f"/apps/{name}/infer", data=request_data)
        return InferenceResponse(**response)
