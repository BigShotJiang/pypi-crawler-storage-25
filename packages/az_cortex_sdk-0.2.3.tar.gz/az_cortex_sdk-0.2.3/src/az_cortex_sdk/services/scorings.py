"""Scoring service for Azure Cortex SDK."""

from ..exceptions import NotFoundError
from ..http_client import HTTPClient
from ..models import ScoringScript, ScoringScriptCreate, ScoringScriptList


class ScoringService:
    """Service for managing Azure ML scoring scripts."""

    def __init__(self, http_client: HTTPClient):
        self.http_client = http_client

    def list(self, page: int = 1, per_page: int = 25) -> ScoringScriptList:
        """List all scoring scripts with pagination."""
        params = {
            "page": page,
            "perPage": per_page,
        }

        try:
            response = self.http_client.get("/scorings", params=params)
            return ScoringScriptList(**response)
        except Exception as e:
            # Add context to the error
            raise Exception(f"Failed to list scoring scripts: {e}") from e

    def get(self, name: str) -> ScoringScript:
        """Get a specific scoring script by name."""
        try:
            response = self.http_client.get(f"/scorings/{name}")
            return ScoringScript(**response)
        except NotFoundError:
            # Re-raise NotFoundError as-is
            raise NotFoundError(f"Scoring script '{name}' not found")
        except Exception as e:
            if "not found" in str(e).lower() or "404" in str(e):
                raise NotFoundError(f"Scoring script '{name}' not found")
            raise

    def create(self, name: str, content: str) -> dict:
        """Create a new scoring script."""
        data = ScoringScriptCreate(name=name, content=content).model_dump()

        try:
            response = self.http_client.post("/scorings", data=data)
            return response
        except Exception as e:
            # Add context for debugging API validation issues
            error_msg = str(e).lower()
            if "422" in error_msg or "validation" in error_msg:
                raise Exception(
                    f"API validation error when creating scoring script '{name}'. "
                    f"This might be due to a known API validation schema mismatch. "
                    f"Original error: {e}"
                ) from e
            elif "500" in error_msg and "json" in error_msg:
                raise Exception(
                    f"Server error when creating scoring script '{name}'. "
                    f"This might be due to API response validation failing. "
                    f"Original error: {e}"
                ) from e
            else:
                # Re-raise other errors as-is
                raise

    def create_from_file(self, name: str, file_path: str) -> dict:
        """Create a scoring script from a file."""
        with open(file_path, encoding="utf-8") as f:
            content = f.read()

        return self.create(name=name, content=content)
