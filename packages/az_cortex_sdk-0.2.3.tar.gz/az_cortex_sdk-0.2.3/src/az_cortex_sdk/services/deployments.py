"""Deployment service for Azure Cortex SDK."""

from typing import Any, Dict, List, Optional

from ..exceptions import NotFoundError
from ..http_client import HTTPClient
from ..models import CreateDeployment, Deployment, PaginatedResponse


class DeploymentService:
    """Service for managing deployments."""

    def __init__(self, http_client: HTTPClient):
        self.http_client = http_client

    def list(
        self,
        app_name: str,
        page: int = 1,
        per_page: int = 25,
    ) -> PaginatedResponse:
        """List deployments for an app.

        Args:
            app_name: App name (required)
            page: Page number (1-based)
            per_page: Number of items per page

        Returns:
            PaginatedResponse: Paginated list of deployments

        """
        params = {"appName": app_name, "page": page, "perPage": per_page}
        response = self.http_client.get("/deployments", params=params)

        # Transform response data
        documents = []
        if "documents" in response:
            documents = [
                self._transform_deployment_data(deployment)
                for deployment in response["documents"]
            ]

        # Transform to PaginatedResponse format
        total_documents = response.get("totalDocuments", 0)
        current_page = response.get("page", page)
        items_per_page = response.get("perPage", per_page)

        return PaginatedResponse(
            items=documents,
            page=current_page,
            per_page=items_per_page,
            total=total_documents,
            has_next=(current_page * items_per_page) < total_documents,
            has_prev=current_page > 1,
        )

    def get(self, name: str, app_name: str) -> Optional[Deployment]:
        """Get a specific deployment by name.

        Args:
            name: Deployment name
            app_name: App name (required)

        Returns:
            Deployment: The deployment if found, None otherwise

        Raises:
            NotFoundError: If deployment is not found

        """
        try:
            params = {"appName": app_name}
            response = self.http_client.get(f"/deployments/{name}", params=params)
            return Deployment(**self._transform_deployment_data(response))
        except NotFoundError:
            return None

    def create(
        self,
        app_name: str,
        name: str,
        instance_type: str,
        model_name: str,
        model_version: str,
        environment_name: str,
        environment_version: str,
        scoring_script_name: str,
        traffic: Dict[str, int],
        secrets: Optional[List[str]] = None,
        request_timeout_seconds: Optional[int] = None,
        tags: Optional[Dict[str, str]] = None,
    ) -> Dict[str, str]:
        """Create a new deployment.

        Args:
            app_name: App name
            name: Deployment name
            instance_type: Instance type (e.g., 'Standard_DS1_v2')
            model_name: Model name
            model_version: Model version
            environment_name: Environment name
            environment_version: Environment version
            scoring_script_name: Scoring script name
            traffic: Traffic allocation (e.g., {"default": 100})
            secrets: Optional list of secret names
            request_timeout_seconds: Optional request timeout in seconds (default: 5)
            tags: Optional tags for the deployment (e.g., {'supportsStreaming': 'true'})

        Returns:
            Dict[str, str]: Creation response message

        """
        deployment_data = CreateDeployment(
            app_name=app_name,
            name=name,
            instance_type=instance_type,
            model_name=model_name,
            model_version=model_version,
            environment_name=environment_name,
            environment_version=environment_version,
            scoring_script_name=scoring_script_name,
            traffic=traffic,
            secrets=secrets,
            request_timeout_seconds=request_timeout_seconds,
            tags=tags,
        )

        response = self.http_client.post(
            "/deployments",
            data=deployment_data.model_dump(by_alias=True, exclude_none=True),
        )
        return response

    def delete(self, name: str, app_name: str) -> Dict[str, str]:
        """Delete a deployment.

        Args:
            name: Deployment name
            app_name: App name (required)

        Returns:
            Dict[str, str]: Deletion response message

        """
        params = {"appName": app_name}
        response = self.http_client.delete(f"/deployments/{name}", params=params)
        return response

    def _transform_deployment_data(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Transform deployment data from API response format to model format.

        Args:
            data: Raw deployment data from API

        Returns:
            Dict[str, Any]: Transformed deployment data

        """
        transformed = data.copy()

        # Handle systemData transformation
        if "systemData" in transformed:
            transformed["system_data"] = transformed.pop("systemData")

        return transformed
