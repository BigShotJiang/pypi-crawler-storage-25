"""Authentication module for Azure Cortex SDK."""

import json
from datetime import datetime, timedelta
from typing import Dict, Optional

import requests

from .config import CortexConfig
from .exceptions import AuthenticationError
from .models import AuthToken


class AuthManager:
    """Manages OAuth authentication for Cortex API."""

    def __init__(self, config: CortexConfig):
        self.config = config
        self._token: Optional[AuthToken] = None
        self._session = requests.Session()
        self._session.verify = self.config.verify_ssl

    def get_token(self, force_refresh: bool = False) -> str:
        """Get valid access token, refreshing if necessary."""
        if self._token is None or self._token.is_expired() or force_refresh:
            self._refresh_token()

        if self._token is None:
            raise AuthenticationError("Failed to obtain access token")

        return self._token.access_token

    def _refresh_token(self) -> None:
        """Refresh the access token using client credentials flow."""
        token_data = {
            "grant_type": "client_credentials",
            "client_id": self.config.client_id,
            "client_secret": self.config.client_secret,
            "scope": self.config.scope,
        }

        headers = {
            "Content-Type": "application/x-www-form-urlencoded",
            "Accept": "application/json",
        }

        try:
            response = self._session.post(
                self.config.auth_url,
                data=token_data,
                headers=headers,
                timeout=self.config.timeout,
            )

            if response.status_code != 200:
                error_data = {}
                try:
                    error_data = response.json()
                except (ValueError, json.JSONDecodeError):
                    pass

                raise AuthenticationError(
                    f"Token request failed with status {response.status_code}",
                    details={
                        "status_code": response.status_code,
                        "response": error_data,
                        "url": self.config.auth_url,
                    },
                )

            token_response = response.json()

            # Calculate expiration time with some buffer
            expires_in = token_response.get("expires_in", 3600)
            expires_at = datetime.utcnow() + timedelta(
                seconds=expires_in - 60
            )  # 60s buffer

            self._token = AuthToken(
                access_token=token_response["access_token"],
                token_type=token_response.get("token_type", "Bearer"),
                expires_in=expires_in,
                expires_at=expires_at,
                scope=token_response.get("scope"),
            )

        except requests.exceptions.RequestException as e:
            raise AuthenticationError(f"Failed to connect to auth server: {e}")
        except KeyError as e:
            raise AuthenticationError(f"Invalid token response format: missing {e}")

    def get_auth_headers(self) -> Dict[str, str]:
        """Get authentication headers for API requests."""
        token = self.get_token()
        return {
            "Authorization": f"Bearer {token}",
            "x-cortex-tenant": self.config.tenant,
        }

    def close(self) -> None:
        """Close the session."""
        self._session.close()
