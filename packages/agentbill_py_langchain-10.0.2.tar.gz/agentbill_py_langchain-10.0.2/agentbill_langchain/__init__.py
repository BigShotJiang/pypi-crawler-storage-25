"""AgentBill LangChain Integration

Zero-config callback handler for tracking LangChain usage in AgentBill.
v10.1.0: Added record_bulk for batch signal operations
"""

from .callback import AgentBillCallback
from .orders import OrdersResource
from .bulk import record_bulk

__version__ = "10.1.0"
__all__ = ["AgentBillCallback", "OrdersResource", "record_bulk"]
