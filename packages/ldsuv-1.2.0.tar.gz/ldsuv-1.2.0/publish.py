import os
import shutil
import subprocess


def setup_token():
    """
    配置 Token 环境变量：
    1. 优先检查系统环境变量
    2. 如果没有，则尝试从本地 .env 文件中读取
    """
    # 优先检查系统环境变量是否已经存在 Token
    if os.getenv("UV_PUBLISH_TOKEN"):
        print("✅ 检测到已存在系统环境变量: UV_PUBLISH_TOKEN")
        return True

    # 如果系统没有，尝试读取 .env 文件
    env_file = ".env"
    if os.path.exists(env_file):
        with open(env_file, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                # 忽略空行和注释
                if line and not line.startswith("#") and "=" in line:
                    key, value = line.split("=", 1)
                    if key.strip() == "UV_PUBLISH_TOKEN":
                        # 找到后，将其注入到当前运行的环境变量中
                        os.environ["UV_PUBLISH_TOKEN"] = value.strip()
                        print("✅ 已从本地 .env 文件中读取并注入 Token")
                        return True

    return False


def main():
    print("🚀 准备发布项目...\n")

    # 配置 Token
    if not setup_token():
        print("❌ 错误: 未在系统环境变量或 .env 文件中找到 UV_PUBLISH_TOKEN")
        print("💡 请配置环境变量，或在项目根目录创建包含 'UV_PUBLISH_TOKEN=你的token' 的 .env 文件。")
        return

    # 清理旧的构建文件
    dist_dir = "dist"
    if os.path.exists(dist_dir):
        print(f"\n🧹 清理旧的 {dist_dir} 目录...")
        shutil.rmtree(dist_dir)

    try:
        # 运行 uv build
        print("📦 正在构建项目 (uv build)...")
        subprocess.run(["uv", "build"], check=True)
        print("✅ 构建成功！\n")

        # 运行 uv publish
        # 此时环境变量中一定已经有 UV_PUBLISH_TOKEN，uv publish 会自动获取它
        print("🌐 正在发布到 PyPI (uv publish)...")
        subprocess.run(["uv", "publish"], check=True)
        print("🎉 发布成功！")

    except subprocess.CalledProcessError as e:
        print(f"\n❌ 执行失败，命令退出状态码: {e.returncode}")
    except FileNotFoundError:
        print("\n❌ 找不到 'uv' 命令，请确认 uv 已正确安装并配置在系统环境变量中。")


if __name__ == "__main__":
    main()
