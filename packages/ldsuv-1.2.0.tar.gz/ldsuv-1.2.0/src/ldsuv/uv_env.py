import os
import sys
import json
import subprocess
import datetime
import shutil
import urllib.request
import re
import math

SCRIPT_VERSION = "1.2.0"

# 兼容性处理 tomllib
try:
    import tomllib
except ImportError:
    import pip._vendor.tomli as tomllib

SETTINGS_FILE = 'env_settings.json'
PYTHON_VERSION_FILE = '.python-version'
PYPROJECT_FILE = 'pyproject.toml'
VENV_DIR = '.venv'
LOCK_FILE = 'uv.lock'


# 终端颜色代码（提升 UI 体验）
class Color:
    GREEN = '\033[92m'
    RED = '\033[91m'
    YELLOW = '\033[93m'
    CYAN = '\033[96m'
    RESET = '\033[0m'
    BOLD = '\033[1m'


def load_settings():
    if os.path.exists(SETTINGS_FILE):
        try:
            with open(SETTINGS_FILE, 'r', encoding='utf-8') as f:
                return json.load(f)
        except json.JSONDecodeError:
            print(f"{Color.YELLOW}⚠ 警告: 配置文件 {SETTINGS_FILE} 损坏，已恢复默认设置。{Color.RESET}")
        except Exception:
            pass
    return {"selected_mirror_name": "PyPI", "package_metadata": {}}


def save_settings(settings):
    with open(SETTINGS_FILE, 'w', encoding='utf-8') as f:
        json.dump(settings, f, ensure_ascii=False, indent=2)


class UVEnvManager:
    def __init__(self):
        self.settings = load_settings()
        self.mirrors = {
            "阿里": "https://mirrors.aliyun.com/pypi/simple/",
            "清华大学": "https://pypi.tuna.tsinghua.edu.cn/simple/",
            "PyPI": "https://pypi.org/simple",
        }
        self._check_uv_installation()
        self._auto_pin_existing_env()

    def _check_uv_installation(self):
        try:
            subprocess.run(["uv", "--version"], capture_output=True, check=True)
        except (FileNotFoundError, subprocess.CalledProcessError):
            print(f"\n{Color.RED}❌ 错误: 当前环境中未检测到 uv 工具。{Color.RESET}")
            ans = input(f"{Color.CYAN}是否尝试使用当前 Python (pip) 自动安装 uv? [Y/n]: {Color.RESET}").strip().lower()
            if ans != 'n':
                print(">> 正在安装 uv...")
                try:
                    subprocess.run([sys.executable, "-m", "pip", "install", "uv"], check=True)
                    print(f"{Color.GREEN}✔ uv 安装成功！\n{Color.RESET}")
                except Exception as e:
                    print(f"{Color.RED}❌ 安装失败: {e}\n请手动运行 'pip install uv' 后重试。{Color.RESET}")
                    sys.exit(1)
            else:
                sys.exit(1)

    def _get_venv_python_version(self):
        if not os.path.exists(VENV_DIR):
            return "unknown"
        py_exe = os.path.join(VENV_DIR, "Scripts", "python.exe") if os.name == "nt" else os.path.join(VENV_DIR, "bin", "python")
        if os.path.exists(py_exe):
            try:
                res = subprocess.run([py_exe, "--version"], capture_output=True, text=True, check=True)
                return res.stdout.strip().split(" ")[1]
            except Exception:
                pass
        return "unknown"

    def _auto_pin_existing_env(self):
        if os.path.exists(VENV_DIR) and not os.path.exists(PYTHON_VERSION_FILE):
            ver = self._get_venv_python_version()
            if ver != "unknown":
                with open(PYTHON_VERSION_FILE, "w") as f:
                    f.write(ver)
                print(f"{Color.GREEN}ℹ 检测到已有虚拟环境，已自动锁定 Python 版本为: {ver}{Color.RESET}")

    def _backup_existing_venv(self):
        if not os.path.exists(VENV_DIR):
            return
        ver = self._get_venv_python_version()
        ts = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        backup_name = f"{VENV_DIR}_backup_{ver}_{ts}"
        try:
            os.rename(VENV_DIR, backup_name)
            print(f"{Color.GREEN}✔ 原有虚拟环境已成功备份至: {backup_name}{Color.RESET}")
        except Exception as e:
            print(f"{Color.RED}❌ 备份虚拟环境失败: {e}{Color.RESET}")

    def _run_uv(self, args, capture=False):
        env = os.environ.copy()
        if self.settings["selected_mirror_name"] != "PyPI":
            env["UV_INDEX_URL"] = self.mirrors[self.settings["selected_mirror_name"]]
        env["UV_SHOW_PROGRESS"] = "auto"
        env["UV_HTTP_TIMEOUT"] = "30"

        try:
            if capture:
                res = subprocess.run(["uv"] + args, env=env, capture_output=True, text=True, check=True)
                return res.stdout
            else:
                res = subprocess.run(["uv"] + args, env=env)
                return res.returncode == 0
        except subprocess.CalledProcessError as e:
            print(f"\n{Color.RED}[uv 报错]:\n{e.stderr if e.stderr else e}{Color.RESET}")
            return False
        except Exception as e:
            print(f"\n{Color.RED}[执行异常]: {e}{Color.RESET}")
            return False

    def _fetch_pypi_repo_url(self, package_name):
        """从 PyPI 官方 API 获取库的源码/主页地址"""
        url = f"https://pypi.org/pypi/{package_name}/json"
        try:
            req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
            with urllib.request.urlopen(req, timeout=5) as response:
                data = json.loads(response.read().decode('utf-8'))
                urls = data.get("info", {}).get("project_urls") or {}

                # 优先级匹配：源码 > 仓库 > 主页
                for key in ["Source", "Source Code", "Repository", "Homepage"]:
                    if key in urls and urls[key]:
                        return urls[key]
                return data.get("info", {}).get("project_url", "")
        except Exception:
            return ""

    def _fetch_pypi_versions(self, package_name):
        """从 PyPI 获取按发布时间倒序排列的前10个版本号"""
        url = f"https://pypi.org/pypi/{package_name}/json"
        try:
            req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
            with urllib.request.urlopen(req, timeout=5) as response:
                data = json.loads(response.read().decode('utf-8'))
                releases = data.get("releases", {})

                version_times = []
                for ver, files in releases.items():
                    # 以该版本第一个文件的上传时间作为版本发布时间
                    upload_time = files[0].get("upload_time", "") if files else ""
                    version_times.append((ver, upload_time))

                # 按时间倒序排序（最新的在前）
                version_times.sort(key=lambda x: x[1], reverse=True)

                # 过滤并仅返回前10个
                return [v[0] for v in version_times[:10]]
        except Exception:
            return []

    def get_project_status(self):
        status = {"has_toml": os.path.exists(PYPROJECT_FILE), "has_venv": os.path.exists(VENV_DIR),
                  "project_name": "未命名", "dep_count": 0, "dev_dep_count": 0, "python_pinned": "未锁定"}
        if status["has_toml"]:
            try:
                with open(PYPROJECT_FILE, "rb") as f:
                    data = tomllib.load(f)
                    status["project_name"] = data.get("project", {}).get("name", "未命名")
                    status["dep_count"] = len(data.get("project", {}).get("dependencies", []))
                    status["dev_dep_count"] = len(data.get("dependency-groups", {}).get("dev", []))
            except:
                pass
        if os.path.exists(PYTHON_VERSION_FILE):
            try:
                with open(PYTHON_VERSION_FILE, "r") as f:
                    status["python_pinned"] = f.read().strip()
            except:
                pass
        return status

    def sync_environment(self):
        """新增统一的同步环境方法，允许选择是否安装 Dev 依赖"""
        print(f"\n{Color.CYAN}--- 环境同步选项 ---{Color.RESET}")
        print("1. 同步【全部】依赖 (基础生产库 + Dev 开发库) [默认]")
        print("2. 仅同步【基础库】 (不包含 Dev 开发库)")
        choice = input(f"请输入选项 [{Color.BOLD}1{Color.RESET}]: ").strip()

        args = ["sync"]
        if choice == '2':
            args.append("--no-dev")
            print(">> 正在执行同步 (仅基础生产依赖)...")
        else:
            print(">> 正在执行同步 (包含所有依赖)...")

        if self._run_uv(args):
            print(f"{Color.GREEN}✔ 环境同步完成。{Color.RESET}")
        else:
            print(f"{Color.RED}❌ 环境同步失败。{Color.RESET}")

    def init_or_recreate_project(self):
        print(f"\n{Color.CYAN}" + "-" * 40)
        print(" [项目初始化 / 重建工具]")
        print("-" * 40 + f"{Color.RESET}")

        if os.path.exists(PYPROJECT_FILE) or os.path.exists(VENV_DIR):
            print(f"{Color.YELLOW}⚠ 警告: 当前目录已存在项目文件或虚拟环境。{Color.RESET}")
            ans = input("是否要【备份现有环境并重新创建】一个纯净的项目？[y/N]: ").strip().lower()
            if ans != 'y':
                print(">> 操作已取消。")
                return

            if os.path.exists(PYPROJECT_FILE):
                ts = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
                backup_toml = f"{PYPROJECT_FILE}.backup_{ts}"
                shutil.copy2(PYPROJECT_FILE, backup_toml)
                os.remove(PYPROJECT_FILE)
                print(f"{Color.GREEN}✔ 配置文件已备份为: {backup_toml}{Color.RESET}")

            if os.path.exists(LOCK_FILE): os.remove(LOCK_FILE)
            self._backup_existing_venv()

        name = input("请输入新项目名称 (留空则使用当前目录名): ").strip()
        args = ["init"] + (["--name", name] if name else [])

        if self._run_uv(args):
            print(f"{Color.GREEN}✔ pyproject.toml 初始化成功。{Color.RESET}")
            print(">> 正在创建全新的虚拟环境...")
            if self._run_uv(["venv"]):
                print(f"{Color.GREEN}✔ 空虚拟环境 (.venv) 创建成功！{Color.RESET}")
                self._auto_pin_existing_env()
        else:
            print(f"{Color.RED}❌ 初始化失败。{Color.RESET}")

    def migrate_requirements(self):
        print(f"\n{Color.CYAN}" + "-" * 30)
        print(" [迁移工具] 正在导入依赖...")
        print("-" * 30 + f"{Color.RESET}")

        if os.path.exists(LOCK_FILE):
            if input(f"{Color.YELLOW}检测到 uv.lock，是否删除以重新解析依赖？[y/N]: {Color.RESET}").strip().lower() == 'y':
                os.remove(LOCK_FILE)

        if os.path.exists("requirements.txt"):
            print(">> 正在导入生产依赖...")
            if self._run_uv(["add", "--requirements", "requirements.txt"]):
                print(f"{Color.GREEN}✔ 生产依赖导入完成。{Color.RESET}")
            else:
                return print(f"{Color.RED}❌ 生产环境导入失败。{Color.RESET}")

        if os.path.exists("requirements_dev.txt"):
            print("\n>> 正在处理开发依赖...")
            with open("requirements_dev.txt", "r") as f:
                clean_lines = [l.strip() for l in f if l.strip() and not l.startswith(("#", "-r"))]
            if clean_lines:
                temp_dev = "temp_dev_reqs.txt"
                with open(temp_dev, "w") as f:
                    f.write("\n".join(clean_lines))
                success = self._run_uv(["add", "--dev", "--requirements", temp_dev])
                os.remove(temp_dev)
                if success:
                    print(f"{Color.GREEN}✔ 开发依赖导入完成。{Color.RESET}")

        self.sync_environment()
        print(f"\n{Color.GREEN}--- 迁移任务成功结束 ---{Color.RESET}")

    def update_specific_package(self):
        """交互式更新指定库的版本，支持翻页与自动获取最新版本"""
        try:
            out = self._run_uv(["pip", "list", "--format=json"], capture=True)
            if not out: return
            pkgs = json.loads(out)
        except:
            print(f"{Color.YELLOW}获取列表失败，请先确保环境已同步。{Color.RESET}")
            return

        if not pkgs:
            print(f"{Color.YELLOW}当前环境没有安装任何库。{Color.RESET}")
            return

        page_size = 20
        total_pages = math.ceil(len(pkgs) / page_size)
        current_page = 1
        pkg_name = ""

        while True:
            start_idx = (current_page - 1) * page_size
            end_idx = start_idx + page_size
            page_pkgs = pkgs[start_idx:end_idx]

            print(f"\n{Color.CYAN}--- 已安装的库 (第 {current_page}/{total_pages} 页) ---{Color.RESET}")
            for i, p in enumerate(page_pkgs, start_idx + 1):
                # {:>3} 保证编号对齐，{:<25} 保证包名对齐，界面极其整洁
                print(f"{i:>3}. {p['name']:<25} (当前版本: {p['version']})")

            print(f"{Color.YELLOW}操作: [n]下一页 | [p]上一页 | [q]取消返回{Color.RESET}")
            choice = input(f"\n请输入【编号】选择，或【直接输入包名】: ").strip()

            if not choice or choice.lower() == 'q':
                return
            elif choice.lower() == 'n':
                if current_page < total_pages: current_page += 1
                else: print(f"{Color.RED}⚠ 已经是最后一页了。{Color.RESET}")
            elif choice.lower() == 'p':
                if current_page > 1: current_page -= 1
                else: print(f"{Color.RED}⚠ 已经是第一页了。{Color.RESET}")
            elif choice.isdigit():
                idx = int(choice)
                if 1 <= idx <= len(pkgs):
                    pkg_name = pkgs[idx - 1]['name']
                    break
                else:
                    print(f"{Color.RED}⚠ 编号超出范围，请重新输入。{Color.RESET}")
            else:
                # 用户手动输入了库名，如 "requests" 或 "requests[security]"
                pkg_name = choice
                break

        pure_name = re.split(r'[=><\[]', pkg_name)[0].strip()

        print(f"\n>> 正在从 PyPI 联网获取 {pure_name} 的历史版本...")
        latest_versions = self._fetch_pypi_versions(pure_name)

        if latest_versions:
            print(f"\n{Color.CYAN}=== {pure_name} 最近的 10 个版本 ==={Color.RESET}")
            for i, v in enumerate(latest_versions, 1):
                print(f"{Color.GREEN}[{i}]{Color.RESET} {v}")
            print(f"{Color.GREEN}[0]{Color.RESET} 升级到最新兼容版本 (默认)")

            v_choice = input(f"\n请输入版本【编号】或直接输入【指定版本号】(直接回车选0): ").strip()

            if not v_choice or v_choice == '0':
                version = ""
            elif v_choice.isdigit() and 1 <= int(v_choice) <= len(latest_versions):
                version = latest_versions[int(v_choice) - 1]
            else:
                version = v_choice # 手动填写的版本号
        else:
            print(f"{Color.YELLOW}⚠ 无法从 PyPI 获取该库的版本信息，请手动输入。{Color.RESET}")
            version = input(f"请输入目标版本号 (如 2.31.0，留空则升级到最新版): ").strip()

        if version:
            args = ["add", f"{pkg_name}=={version}"]
            print(f">> 正在将 {pkg_name} 设置为版本 {version} ...")
        else:
            args = ["lock", "--upgrade-package", pkg_name]
            print(f">> 正在将 {pkg_name} 升级到最新兼容版本 ...")

        if self._run_uv(args):
            print(f"{Color.GREEN}✔ {pkg_name} 版本更新成功！{Color.RESET}")
            self._auto_fetch_and_save_repo(pkg_name)
            if not version:
                print(">> 正在同步环境...")
                self._run_uv(["sync"])
                print(f"{Color.GREEN}✔ 同步完成。{Color.RESET}")
        else:
            print(f"{Color.RED}❌ 更新失败。{Color.RESET}")
    def _auto_fetch_and_save_repo(self, pkg_string):
        """内部辅助函数：获取链接并保存备注"""
        # 使用正则提取纯粹的包名 (去除 ==, >=, <=, [extras] 等)
        pure_name = re.split(r'[=><\[]', pkg_string)[0].strip()
        self.settings["package_metadata"].setdefault(pure_name, {"notes": "", "repo_url": ""})

        print(f">> 正在尝试从 PyPI 获取 {pure_name} 的源码地址...")
        repo_url = self._fetch_pypi_repo_url(pure_name)
        if repo_url:
            self.settings["package_metadata"][pure_name]["repo_url"] = repo_url
            print(f"{Color.GREEN}✔ 自动提取并保存了项目地址: {repo_url}{Color.RESET}")
            save_settings(self.settings)
        else:
            print(f"{Color.YELLOW}ℹ 未能在 PyPI 找到该库的源码地址。{Color.RESET}")
        return pure_name

    def install_package(self):
        pkg = input("\n请输入库名 (如 django 或 requests==2.31.0): ").strip()
        if not pkg: return

        # 单库安装时明确提示安装到哪里
        print(f"\n请选择安装目标:")
        print("1. 基础生产依赖 (常规安装)")
        print("2. 开发依赖 (Dev - 仅开发测试使用)")
        choice = input(f"请输入选项 [{Color.BOLD}1{Color.RESET}]: ").strip()

        is_dev = (choice == '2')
        args = ["add", "--dev", pkg] if is_dev else ["add", pkg]

        if self._run_uv(args):
            pure_name = self._auto_fetch_and_save_repo(pkg)

            note = input(f"为 {pure_name} 添加本地备注 (留空跳过): ").strip()
            if note:
                self.settings["package_metadata"][pure_name]["notes"] = note
                save_settings(self.settings)

    def change_python_version(self):
        """切换 Python 版本时，提示重建虚拟环境"""
        ver = input("请输入目标 Python 版本 (如 3.11, 3.12): ").strip()
        if not ver: return

        if self._run_uv(["python", "pin", ver]):
            print(f"{Color.GREEN}✔ .python-version 已更新为 {ver}{Color.RESET}")
            if os.path.exists(VENV_DIR):
                print(f"\n{Color.YELLOW}⚠ 切换 Python 版本后，当前的虚拟环境 (.venv) 可能不再兼容。{Color.RESET}")
                if input("是否备份旧环境并使用新版本重新创建虚拟环境？[Y/n]: ").strip().lower() != 'n':
                    self._backup_existing_venv()
                    self._run_uv(["venv"])
                    self.sync_environment()
                    print(f"{Color.GREEN}✔ 基于 Python {ver} 的新环境已准备就绪。{Color.RESET}")

    def export_requirements(self):
        """默认导出无哈希值的清爽版，并询问是否导出 Dev"""
        print(">> 正在导出 requirements.txt (已自动去除 Hash 值使其更整洁)...")
        self._run_uv(["export", "--no-hashes", "--output-file", "requirements_exported.txt"])

        if input("是否还要导出开发依赖 (Dev)? [y/N]: ").strip().lower() == 'y':
            self._run_uv(["export", "--dev", "--no-hashes", "--output-file", "requirements_dev_exported.txt"])
        print(f"{Color.GREEN}✔ 导出完成。{Color.RESET}")

    def manage_metadata(self):
        try:
            out = self._run_uv(["pip", "list", "--format=json"], capture=True)
            if not out: return
            pkgs = json.loads(out)
        except:
            print(f"{Color.YELLOW}获取列表失败，请先确保环境已同步(选项5)。{Color.RESET}")
            return

        search = input("搜索 (直接回车列出): ").strip().lower()
        filtered = [p for p in pkgs if search in p['name'].lower()]

        print(f"\n{Color.CYAN}{'编号':<4} | {'库名':<20} | {'备注':<15} | {'源码地址'}{Color.RESET}")
        print("-" * 70)
        for idx, p in enumerate(filtered[:20], 1):
            n = p['name']
            info = self.settings["package_metadata"].get(n, {})
            note = info.get('notes', '无')
            url = info.get('repo_url', '无')
            # 缩短 URL 以免界面乱码
            display_url = url if len(url) < 30 else url[:27] + "..."
            print(f"{idx:<4} | {n:<20} | {note:<15} | {display_url}")

        sel = input("\n编辑编号 (b返回): ").strip()
        if sel.isdigit() and 1 <= int(sel) <= len(filtered):
            name = filtered[int(sel) - 1]['name']
            info = self.settings["package_metadata"].setdefault(name, {"repo_url": "", "notes": ""})
            info["notes"] = input(f"备注 [{info['notes']}]: ").strip() or info["notes"]

            # 如果没抓取到链接，允许手动补全
            info["repo_url"] = input(f"链接 [{info['repo_url']}]: ").strip() or info["repo_url"]
            save_settings(self.settings)

    def main_menu(self):
        while True:
            st = self.get_project_status()

            # 使用 ANSI 颜色美化状态显示
            toml_status = f"{Color.GREEN}已就绪{Color.RESET}" if st['has_toml'] else f"{Color.RED}缺失{Color.RESET}"
            venv_status = f"{Color.GREEN}已就绪{Color.RESET}" if st['has_venv'] else f"{Color.RED}缺失{Color.RESET}"

            print(f"\n{Color.CYAN}{Color.BOLD}" + "=" * 65)
            print(f" UV 环境管理助手 v{SCRIPT_VERSION}")
            print("=" * 65 + f"{Color.RESET}")
            print(f" 项目名称: {Color.BOLD}{st['project_name']}{Color.RESET}")
            print(f" 依赖统计: 生产 [{Color.GREEN}{st['dep_count']}{Color.RESET}] | 开发(Dev) [{Color.GREEN}{st['dev_dep_count']}{Color.RESET}]")
            print(f" 当前环境: Python {Color.YELLOW}{st['python_pinned']}{Color.RESET} | 镜像: {Color.YELLOW}{self.settings['selected_mirror_name']}{Color.RESET}")
            print(f" 配置文件 (pyproject.toml): {toml_status}")
            print(f" 虚拟环境 (.venv):         {venv_status}")
            print(f"{Color.CYAN}" + "=" * 65 + f"{Color.RESET}")

            print("0. 初始化项目 / 重建纯净环境 (uv init & venv)")
            print("1. 升级或修改库版本 (一键全部升级 / 修改指定库)")
            print("2. 安装新库 (Prod/Dev)")
            print("3. 管理本地备注与源码链接 (JSON)")
            print("4. Python 版本切换与锁定")
            print("5. 同步环境 (uv sync)")
            print("6. 切换镜像源")
            print("7. 导出 requirements.txt")
            print("8. 【迁移】从 requirements.txt 导入")
            print("e. 退出")

            c = input(f"\n{Color.BOLD}请输入指令: {Color.RESET}").strip().lower()
            if c == '0':
                self.init_or_recreate_project()
            elif c == '1':
                print(f"\n{Color.CYAN}--- 升级选项 ---{Color.RESET}")
                print("1. 一键升级【所有库】至最新版")
                print("2. 选择【指定库】升级或指定版本")
                sub_c = input("选择: ").strip()
                if sub_c == '1':
                    if self._run_uv(["lock", "--upgrade"]):
                        self.sync_environment()
                elif sub_c == '2':
                    self.update_specific_package()
            elif c == '2':
                self.install_package()
            elif c == '3':
                self.manage_metadata()  # 代码未变，省略避免冗长
            elif c == '4':
                self.change_python_version()
            elif c == '5':
                self.sync_environment()
            elif c == '6':
                names = list(self.mirrors.keys())
                for i, n in enumerate(names, 1): print(f"{i}. {n}")
                idx = input("选择: ").strip()
                if idx.isdigit() and 1 <= int(idx) <= len(names):
                    self.settings["selected_mirror_name"] = names[int(idx) - 1]
                    save_settings(self.settings)
            elif c == '7':
                self.export_requirements()
            elif c == '8':
                self.migrate_requirements()
            elif c == 'e':
                break


if __name__ == "__main__":
    # Windows 开启 ANSI 颜色支持
    if os.name == 'nt':
        os.system('')
    manager = UVEnvManager()
    manager.main_menu()
