import sys

from .uv_env import UVEnvManager


def main():
    try:
        UVEnvManager().main_menu()
    except KeyboardInterrupt:
        sys.exit(0)


if __name__ == "__main__":
    main()
