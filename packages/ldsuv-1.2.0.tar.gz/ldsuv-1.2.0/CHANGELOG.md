# 更改日志

此项目的所有显着更改都将记录在此文件中。

此项目遵循[语义化版本](https://semver.org/lang/zh-CN/)。

## [1.2.0] 

### Added
- 添加文字颜色支持
- 显示更多信息
- 支持选择本地的库更新
### Changed
- 初始化的时候支持备份
### Fixed
- 无

## [0.1.2] 

### Fixed
- 修复不能使用 python -m 运行的错误


## [0.1.1] 

### Changed
- 更新pypi信息

## [0.1.0] 

**初始版本**

### Added
- 无
### Changed
- 无
### Fixed
- 无

