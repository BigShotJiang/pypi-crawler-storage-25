import uuid
import hashlib
import socket
import subprocess
import platform

# 设备管理
class MyDevice:
    # 获取主机名称
    def getHostName(self) -> str:
        return socket.gethostname()
        
    # 获取设备ID
    def getDeviceID(self,withWindowsCPUID:bool = False,withWindowsBoardID:bool=True) -> str:
        deviceinfos=[]
        # 如果要获取CPD序列号
        if platform.system()=="Windows":
            # 获取CPU序列号
            if withWindowsCPUID:
                cpuid=self.getWindowsCPUID()
                if cpuid:
                    deviceinfos.append(cpuid)
            # 获取主板序列号
            if withWindowsBoardID:
                boardID=self.getWindowsBoardID()
                if boardID:
                    deviceinfos.append(boardID)
        elif platform.system()=="Linux":
            # 获取MachineID
            machineid=self.getLinuxMachineID()
            if machineid:
                deviceinfos.append(machineid)
        else:
            pass
            
        # 如果还有信息，就获取MAC地址
        if len(deviceinfos)==0:
            macAddress=self.getMAC()
            if macAddress:
                deviceinfos.append(macAddress)
        
        # 如果还是没有信息，就直接Unknown
        if len(deviceinfos)==0:
            deviceinfos.append("Unknown")
            
        # 拼接为字符串
        deviceinfostr = "".join(deviceinfos)
        
        return hashlib.md5(deviceinfostr.encode()).hexdigest()
        
    # 获取Windows的CPU序列号（用的是PowerShell不是wmic）
    def getWindowsCPUID(self) -> str:
        try:
            cmd = [
                "powershell",
                "-Command",
                "Get-CimInstance Win32_Processor | Select-Object -ExpandProperty ProcessorId"
            ]
            out = subprocess.check_output(cmd, text=True, encoding='gbk', errors='ignore').strip()
            return out if out else None
        except:
            return None
            
    # 获取Windows主板序列号
    def getWindowsBoardID(self) -> str:
        try:
            cmd = [
                "powershell",
                "-Command",
                "Get-CimInstance Win32_BaseBoard | Select-Object -ExpandProperty SerialNumber"
            ]
            out = subprocess.check_output(cmd, text=True, encoding='gbk', errors='ignore').strip()
            return out if out else None
        except:
            return None
            
    # 获取Linux的MachineID
    def getLinuxMachineID(slef) -> str:
        try:
            with open("/etc/machine-id", "r") as f:
                mid = f.read().strip()
            return mid if len(mid) == 32 else None
        except:
            return None
        
    # 获取MAC地址
    def getMAC(self) -> str:
        try:
            mac = uuid.getnode()
            return ':'.join(['{:02x}'.format((mac >> elements) & 0xff) for elements in range(0,8*6,8)][::-1])
        except:
            return None
            
    # 获取本地IP地址
    def getLocalIP(self) -> str:
        try:
            # 创建一个socket连接（实际上不会发送数据）
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect(("8.8.8.8", 80))
            ip = s.getsockname()[0]
            s.close()
            return ip
        except:
            return "127.0.0.1"