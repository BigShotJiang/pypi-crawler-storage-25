"""
模块：mysqlite
作者：李生
"""
import sqlite3
from typing import List, Tuple, Any, Optional
import asyncio
from concurrent.futures import ThreadPoolExecutor

class SQLite:
    def __init__(self, dbName: str = "data.db",maxWorker=5):
        self.dbName = dbName
        self.connection = None
        self.cursor = None
        self.executor = ThreadPoolExecutor(max_workers=maxWorker)
        self.loop = asyncio.get_event_loop()
    
    # 异步连接数据库
    async def connect4Async(self)->tuple[bool,str]:
        return await self.loop.run_in_executor(
            self.executor, 
            self.connect,
        )
        
    # 连接数据库
    def connect(self) -> tuple[bool,str]:
        try:
            self.connection = sqlite3.connect(self.dbName)
            self.cursor = self.connection.cursor()
            return True,"OK"
        except sqlite3.Error as e:
            return False,str(e)
            
    # 异步创建表
    async def createTable4Async(self, tableName: str, columns: dict) -> tuple[bool,str]:
        return await self.loop.run_in_executor(
            self.executor, 
            self.createTable,
            tableName,
            columns
        )
    
    # 创建表
    def createTable(self, tableName: str, columns: dict) -> tuple[bool,str]:
        if not self.connection:
            self.connect()
        cols = ", ".join([f"{name} {defn}" for name, defn in columns.items()])
        sql = f"CREATE TABLE IF NOT EXISTS {tableName} ({cols})"
        try:
            self.cursor.execute(sql)
            self.connection.commit()
            return True,"OK"
        except sqlite3.Error as e:
            return False,str(e)
            
    # 异步插入记录
    async def insert4Async(self, tableName: str, data: dict) -> tuple[bool,Optional[int]]:
        return await self.loop.run_in_executor(
            self.executor, 
            self.insert,
            tableName,
            data
        )
    
    # 插入记录
    def insert(self, tableName: str, data: dict) -> tuple[bool,Optional[int]]:
        if not self.connection:
            self.connect()
        columns = ", ".join(data.keys())
        placeholders = ", ".join(["?"] * len(data))
        values = tuple(data.values())
        sql = f"INSERT INTO {tableName} ({columns}) VALUES ({placeholders})"
        try:
            self.cursor.execute(sql, values)
            self.connection.commit()
            return True,self.cursor.lastrowid
        except sqlite3.Error as e:
            return False,None
    
    # 异步查询数据
    async def select4Async(self, tableName: str, columns: List[str] = None, where: str = None, params: Tuple[Any] = None) -> tuple[bool,List[Tuple]]:
        return await self.loop.run_in_executor(
            self.executor, 
            self.select,
            tableName,
            columns,
            where,
            params
        )
        
    # 查询数据
    def select(self, tableName: str, columns: List[str] = None, where: str = None, params: Tuple[Any] = None) -> tuple[bool,List[Tuple]]:
        if not self.connection:
            self.connect()
        cols = "*" if columns is None else ", ".join(columns)
        sql = f"SELECT {cols} FROM {tableName}"
        if where:
            sql += f" WHERE {where}"
        try:
            if where and params:
                self.cursor.execute(sql, params)
            else:
                self.cursor.execute(sql)
            results = self.cursor.fetchall()
            return True,results
        except sqlite3.Error as e:
            return False,[]
    
    # 异步更新数据
    async def update4Async(self, tableName: str, data: dict, where: str, params: Tuple[Any]) -> tuple[bool,str]:
        return await self.loop.run_in_executor(
            self.executor, 
            self.update,
            tableName,
            data,
            where,
            params
        )
        
    # 更新数据
    def update(self, tableName: str, data: dict, where: str, params: Tuple[Any]) -> tuple[bool,str]:
        if not self.connection:
            self.connect()
        set_clause = ", ".join([f"{key} = ?" for key in data.keys()])
        values = tuple(data.values()) + params
        sql = f"UPDATE {tableName} SET {set_clause} WHERE {where}"
        try:
            self.cursor.execute(sql, values)
            self.connection.commit()
            return True,"OK"
        except sqlite3.Error as e:
            return False,str(e)
    
    # 异步删除数据
    async def delete4Async(self, tableName: str, where: str, params: Tuple[Any]) -> tuple[bool,str]:
        return await self.loop.run_in_executor(
            self.executor, 
            self.delete,
            tableName,
            where,
            params
        )
        
    # 删除数据
    def delete(self, tableName: str, where: str, params: Tuple[Any]) -> tuple[bool,str]:
        if not self.connection:
            self.connect()
        sql = f"DELETE FROM {tableName} WHERE {where}"
        try:
            self.cursor.execute(sql, params)
            self.connection.commit()
            return True,"OK"
        except sqlite3.Error as e:
            return False,str(e)
    
    # 关闭连接
    def close(self) -> None:
        if self.cursor:
            self.cursor.close()
            self.cursor=None
        if self.connection:
            self.connection.close()
            self.connect=None