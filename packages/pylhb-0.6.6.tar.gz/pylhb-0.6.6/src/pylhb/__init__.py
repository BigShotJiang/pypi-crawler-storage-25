from .myconfig import MyConfig
from .myjson import MyJSON
from .mylog import MyLog
from .myodbc import MSSQL
from .mysqlite import SQLite
from .mycipher import MyAsymClipher,MyXORCipher,MyFernetCipher,MyBlowfishCipher
from .mysnowflake import MySnowflake
from .mydevice import MyDevice
from .mysubscribe import MySubscribe

__all__=[
    "MyConfig",
    "MyJSON",
    "MyLog",
    "MSSQL",
    "SQLite",
    "MyAsymClipher",
    "MyXORCipher",
    "MyFernetCipher",
    "MyBlowfishCipher",
    "MySnowflake",
    "MyDevice",
    "MySubscribe"
]

import argparse
import platform

def main() -> None:
    parser = argparse.ArgumentParser(description="Mr.Lee's Helpers")
    parser.add_argument('--version', action='store_true', help='show version')
    parser.add_argument('--deviceinfos', action='store_true', help='show device infomations')
    args = parser.parse_args()

    # show version
    if args.version:
        try:
            from importlib.metadata import version, PackageNotFoundError
            # 直接从包元数据获取版本号
            ver = version("pylhb")
            print(f"pylhb {ver}")
        except PackageNotFoundError:
            print("Package not found.")
        except ImportError:
            print("Package not found.")
        except:
            print("Package not found.")
        return
        
    # show device infomations
    if args.deviceinfos:
        d=MyDevice()
        print(f"系统: {platform.system()}")
        print(f"系统版本: {platform.version()}")
        print(f"系统发行版: {platform.release()}")
        print(f"架构: {platform.machine()}")
        print(f"处理器: {platform.processor()}")
        print(f"主机名: {platform.node()}")
        print(f"设备ID: {d.getDeviceID()}")
        print(f"MAC地址: {d.getMAC()}")
        print(f"IP地址: {d.getLocalIP()}")
        print(f"Python版本: {platform.python_version()}")
        return

if __name__ == '__main__':
    main()