from __future__ import annotations

import io
import json
import os
import tempfile
import unittest
from pathlib import Path
from unittest import mock
from urllib import error

import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from eona.gateway_client import (
    GatewayClientError,
    build_path_hint,
    collect_import_path,
    discover_import_files,
    gateway_base_url,
    gateway_access_token,
    import_folder_to_gateway,
    import_path_to_gateway,
    mount_import_to_gateway,
    post_gateway_json,
)


class GatewayClientTests(unittest.TestCase):
    def setUp(self) -> None:
        self.addCleanup(lambda: os.environ.pop("EONA_GATEWAY_ACCESS_TOKEN", None))
        self.addCleanup(lambda: os.environ.pop("EONA_GATEWAY_URL", None))
        self.addCleanup(lambda: os.environ.pop("EONA_GATEWAY_ACCESS_TOKEN", None))
        self.addCleanup(lambda: os.environ.pop("EONA_GATEWAY_URL", None))

    def test_gateway_access_token_requires_env(self) -> None:
        os.environ.pop("EONA_GATEWAY_ACCESS_TOKEN", None)
        os.environ.pop("EONA_GATEWAY_ACCESS_TOKEN", None)
        with self.assertRaisesRegex(GatewayClientError, "EONA_GATEWAY_ACCESS_TOKEN is required"):
            gateway_access_token()

    def test_gateway_access_token_accepts_eona_env(self) -> None:
        os.environ["EONA_GATEWAY_ACCESS_TOKEN"] = "eona-secret"

        self.assertEqual(gateway_access_token(), "eona-secret")

    def test_gateway_base_url_prefers_eona_env(self) -> None:
        os.environ["EONA_GATEWAY_URL"] = "http://legacy.example:8000"
        os.environ["EONA_GATEWAY_URL"] = "http://eona.example:8000"

        self.assertEqual(gateway_base_url(), "http://eona.example:8000")

    def test_post_gateway_json_adds_bearer_token_header(self) -> None:
        os.environ["EONA_GATEWAY_ACCESS_TOKEN"] = "secret-token"

        class _Response:
            def __enter__(self) -> "_Response":
                return self

            def __exit__(self, exc_type, exc, tb) -> None:
                return None

            def read(self) -> bytes:
                return b'{"ok":true}'

        with mock.patch("eona.gateway_client.request.urlopen", return_value=_Response()) as urlopen_mock:
            payload = post_gateway_json("/queries/photo-memory", {"query_version": 1})

        self.assertEqual(payload, {"ok": True})
        req = urlopen_mock.call_args.args[0]
        self.assertEqual(req.get_header("Authorization"), "Bearer secret-token")
        self.assertEqual(req.get_method(), "POST")

    def test_post_gateway_json_surfaces_gateway_http_error_message(self) -> None:
        os.environ["EONA_GATEWAY_ACCESS_TOKEN"] = "secret-token"
        err = error.HTTPError(
            url="http://eona-gateway:8000/queries/photo-memory",
            code=401,
            msg="Unauthorized",
            hdrs=None,
            fp=io.BytesIO(json.dumps({"error_code": "UNAUTHORIZED", "message": "Missing bearer token."}).encode("utf-8")),
        )
        with mock.patch("eona.gateway_client.request.urlopen", side_effect=err):
            with self.assertRaisesRegex(GatewayClientError, "Missing bearer token."):
                post_gateway_json("/queries/photo-memory", {"query_version": 1})

    def test_discover_import_files_filters_supported_extensions(self) -> None:
        with tempfile.TemporaryDirectory(prefix="g5-gateway-client-", dir="/tmp") as temp_dir:
            root = Path(temp_dir)
            (root / "a.jpg").write_bytes(b"a")
            (root / "b.heic").write_bytes(b"b")
            (root / "c.txt").write_text("c", encoding="utf-8")
            (root / "nested").mkdir()
            (root / "nested" / "d.jpeg").write_bytes(b"d")
            (root / ".hidden.jpg").write_bytes(b"h")
            os.symlink(root / "a.jpg", root / "link.jpg")

            files, errors = discover_import_files(root)

            self.assertEqual([path.name for path in files], ["a.jpg", "b.heic", "d.jpeg"])
            self.assertEqual(errors[0]["error_code"], "IMPORT_PATH_SYMLINK_UNSUPPORTED")

    def test_build_path_hint_relative_mode(self) -> None:
        root = Path("/tmp/photos")
        file_path = root / "Japan" / "IMG_001.jpg"
        self.assertEqual(build_path_hint(file_path, root=root, mode="relative"), "Japan/IMG_001.jpg")

    def test_import_folder_to_gateway_dry_run(self) -> None:
        with tempfile.TemporaryDirectory(prefix="g5-gateway-client-", dir="/tmp") as temp_dir:
            root = Path(temp_dir)
            (root / "photo.jpg").write_bytes(b"photo")

            result = import_folder_to_gateway(root, dry_run=True)

            self.assertTrue(result["ok"])
            self.assertEqual(result["status"], "dry_run")
            self.assertEqual(result["file_count"], 1)
            self.assertEqual(result["collection_mode"], "upload")

    def test_import_folder_to_gateway_stages_and_commits(self) -> None:
        with tempfile.TemporaryDirectory(prefix="g5-gateway-client-", dir="/tmp") as temp_dir:
            root = Path(temp_dir)
            (root / "Japan").mkdir()
            (root / "Japan" / "photo.jpg").write_bytes(b"photo")

            with (
                mock.patch("eona.gateway_client.create_import_session", return_value={"import_id": "imp_123"}) as create_mock,
                mock.patch("eona.gateway_client.import_file", return_value={"status": "staged"}) as import_file_mock,
                mock.patch("eona.gateway_client.commit_import_session", return_value={"run_id": "run_123", "status": "queued"}) as commit_mock,
            ):
                result = import_folder_to_gateway(root)

            self.assertTrue(result["ok"])
            self.assertEqual(result["import_id"], "imp_123")
            self.assertEqual(result["run_id"], "run_123")
            self.assertEqual(result["collection_mode"], "upload")
            create_mock.assert_called_once()
            import_file_mock.assert_called_once()
            self.assertEqual(import_file_mock.call_args.kwargs["path_hint"], "Japan/photo.jpg")
            commit_mock.assert_called_once_with("imp_123", base_url=None, access_token=None, timeout=30.0)

    def test_collect_import_path_posts_absolute_source_path(self) -> None:
        with tempfile.TemporaryDirectory(prefix="g5-gateway-client-", dir="/tmp") as temp_dir:
            root = Path(temp_dir) / "photos"
            root.mkdir()
            with mock.patch("eona.gateway_client.post_gateway_json", return_value={"ok": True}) as post_mock:
                result = collect_import_path("imp_123", source_path=root)

        self.assertEqual(result, {"ok": True})
        post_mock.assert_called_once_with(
            "/import-sessions/imp_123/collect",
            {"source_path": str(root.resolve())},
            base_url=None,
            access_token=None,
            timeout=30.0,
        )

    def test_mount_import_to_gateway_collects_and_commits(self) -> None:
        with tempfile.TemporaryDirectory(prefix="g5-gateway-client-", dir="/tmp") as temp_dir:
            root = Path(temp_dir)
            (root / "photo.jpg").write_bytes(b"photo")

            with (
                mock.patch("eona.gateway_client.create_import_session", return_value={"import_id": "imp_123"}) as create_mock,
                mock.patch("eona.gateway_client.collect_import_path", return_value={"error_count": 0, "errors": []}) as collect_mock,
                mock.patch("eona.gateway_client.commit_import_session", return_value={"run_id": "run_123", "status": "queued"}) as commit_mock,
            ):
                result = mount_import_to_gateway(root)

        self.assertTrue(result["ok"])
        self.assertEqual(result["collection_mode"], "mount")
        create_mock.assert_called_once()
        collect_mock.assert_called_once()
        commit_mock.assert_called_once_with("imp_123", base_url=None, access_token=None, timeout=30.0)

    def test_import_path_to_gateway_uses_mount_locally(self) -> None:
        with tempfile.TemporaryDirectory(prefix="g5-gateway-client-", dir="/tmp") as temp_dir:
            root = Path(temp_dir)
            with mock.patch("eona.gateway_client.mount_import_to_gateway", return_value={"ok": True}) as mount_mock:
                result = import_path_to_gateway(root, collection_mode="mount")
        self.assertEqual(result, {"ok": True})
        mount_mock.assert_called_once()

    def test_import_path_to_gateway_uses_upload_for_remote(self) -> None:
        with tempfile.TemporaryDirectory(prefix="g5-gateway-client-", dir="/tmp") as temp_dir:
            root = Path(temp_dir)
            root.mkdir(exist_ok=True)
            with mock.patch("eona.gateway_client.import_folder_to_gateway", return_value={"ok": True}) as upload_mock:
                result = import_path_to_gateway(root, collection_mode="upload")
        self.assertEqual(result, {"ok": True})
        upload_mock.assert_called_once()
