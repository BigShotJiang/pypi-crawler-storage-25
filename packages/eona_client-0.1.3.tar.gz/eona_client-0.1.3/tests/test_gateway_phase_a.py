from __future__ import annotations

import io
import json
import os
import runpy
import sqlite3
import subprocess
import tempfile
import time
import unittest
import binascii
import copy
import hashlib
from contextlib import redirect_stdout
from pathlib import Path
from unittest import mock

import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from eona.cli import main as cli_main
from eona.indexing import ExtractedMetadata, NormalizedLocation
from eona.gateway_canonicalize import GatewayCanonicalizer, PILLOW_CANONICAL_SPEC_VERSION, VIPS_CANONICAL_SPEC_VERSION
from eona.gateway_schema import initialize_gateway_storage
from eona.gateway_merge import GatewayMergeRunner
from eona.gateway_server import (
    GatewayHTTPServer,
    GatewayRequestHandler,
    build_gateway_server,
    _extract_boundary,
    _parse_multipart,
    _resolve_file_path_hints,
    serve_gateway,
    validate_gateway_policy,
)
from eona.gateway_ui import render_blocked_page, render_home_page, render_run_detail_page
from eona.gateway_pipeline import GatewayPipelineRunner
from eona.gateway_runtime import bootstrap_gateway_runtime, get_gateway_runtime_paths, inspect_gateway_runtime
from eona.gateway_runs import read_json
from eona.gateway_service import GatewayPauseRequested, GatewayService, GatewayServiceError
from eona.gateway_upgrade_tools import run_cadis_upgrade_tool, run_exiftool_upgrade_tool
from eona.gateway_worker import GatewayWorkerLoop
from eona.cadis_runtime import get_effective_cadis_cache_dir


def build_multipart(*, fields: dict[str, str], file_field: str, filename: str, content: bytes, boundary: str) -> bytes:
    lines: list[bytes] = []
    for key, value in fields.items():
        lines.extend(
            [
                f"--{boundary}".encode("utf-8"),
                f'Content-Disposition: form-data; name="{key}"'.encode("utf-8"),
                b"",
                value.encode("utf-8"),
            ]
        )
    lines.extend(
        [
            f"--{boundary}".encode("utf-8"),
            f'Content-Disposition: form-data; name="{file_field}"; filename="{filename}"'.encode("utf-8"),
            b"Content-Type: application/octet-stream",
            b"",
            content,
            f"--{boundary}--".encode("utf-8"),
            b"",
        ]
    )
    return b"\r\n".join(lines)


class GatewayPhaseATests(unittest.TestCase):
    def setUp(self) -> None:
        self.temp_dir = tempfile.TemporaryDirectory(prefix="g5-gateway-", dir="/tmp")
        self.addCleanup(self.temp_dir.cleanup)
        os.environ["EONA_GATEWAY_HOME"] = str(Path(self.temp_dir.name) / "gateway")
        os.environ["EONA_GATEWAY_ACCESS_TOKEN"] = "test-gateway-token"
        self.addCleanup(lambda: os.environ.pop("EONA_GATEWAY_HOME", None))
        self.addCleanup(lambda: os.environ.pop("EONA_GATEWAY_ACCESS_TOKEN", None))
        self.addCleanup(lambda: os.environ.pop("EONA_GATEWAY_ALLOW_NONLOCAL_BIND", None))
        self.addCleanup(lambda: os.environ.pop("EONA_GATEWAY_ALLOW_MOUNT_IMPORT", None))
        self.addCleanup(lambda: os.environ.pop("EONA_GATEWAY_REQUIRE_ACCESS_TOKEN", None))
        initialize_gateway_storage(force=True)

    def test_gateway_cli_module_executes_main(self) -> None:
        from eona import gateway_cli

        original_argv = sys.argv[:]
        calls: list[list[str]] = []

        def fake_main() -> int:
            calls.append(list(sys.argv))
            return 0

        with mock.patch.object(gateway_cli.eona_cli, "main", side_effect=fake_main):
            try:
                sys.argv = ["eona.gateway_cli", "serve", "--port", "9000"]
                with self.assertRaises(SystemExit) as excinfo:
                    runpy.run_module("eona.gateway_cli", run_name="__main__")
            finally:
                sys.argv = original_argv

        self.assertEqual(excinfo.exception.code, 0)
        self.assertEqual(calls, [["eona.gateway_cli", "gateway", "serve", "--port", "9000"]])

    def test_client_cli_module_executes_main(self) -> None:
        from eona import gateway_client

        original_argv = sys.argv[:]
        with mock.patch.object(
            gateway_client,
            "health_check_gateway",
            return_value={"ok": True, "checks": {"health": {}}, "summary": "ok", "details": []},
        ):
            try:
                sys.argv = ["eona.client_cli", "health", "--json"]
                with self.assertRaises(SystemExit) as excinfo:
                    runpy.run_module("eona.client_cli", run_name="__main__")
            finally:
                sys.argv = original_argv

        self.assertEqual(excinfo.exception.code, 0)

    def _sample_png_bytes(self) -> bytes:
        png_hex = (
            "89504e470d0a1a0a0000000d4948445200000001000000010802000000907753de"
            "0000000c4944415408d763f8ffff3f0005fe02fea7a68f3d0000000049454e44ae426082"
        )
        return binascii.unhexlify(png_hex)

    class _FakeExtractor:
        def extract(self, path: Path) -> ExtractedMetadata:
            return ExtractedMetadata(
                image_facts={
                    "taken_at_utc": "2026-03-19T00:00:00Z",
                    "taken_at_original": "2026:03:19 08:00:00",
                    "mime_type": "image/jpeg",
                    "width": 100,
                    "height": 80,
                    "orientation": 1,
                },
                image_camera={
                    "make": "EonaCam",
                    "model": path.stem,
                    "lens": None,
                    "focal_length_mm": None,
                    "aperture": None,
                    "iso": None,
                    "shutter_speed": None,
                },
                image_location={
                    "raw_latitude": 25.0,
                    "raw_longitude": 121.5,
                    "raw_altitude": None,
                    "cadis_result_json": None,
                    "cadis_version": None,
                },
            )

    class _FakeNormalizer:
        def normalize(self, latitude: float, longitude: float) -> NormalizedLocation:
            return NormalizedLocation(
                cadis_result_json='{"result":"ok"}',
                cadis_version="0.3.0",
                detail=None,
            )

    class _FlakyExtractor:
        def extract(self, path: Path) -> ExtractedMetadata:
            if path.read_bytes() == b"bad-meta":
                raise OSError("image file is truncated (40 bytes not processed)")
            return GatewayPhaseATests._FakeExtractor().extract(path)

    class _FlakyCanonicalizer:
        def canonicalize(self, *, source_path: Path, content_dir: Path):
            if source_path.read_bytes() == b"bad":
                raise OSError("image file is truncated (40 bytes not processed)")

            return GatewayPhaseATests._StableCanonicalizer().canonicalize(source_path=source_path, content_dir=content_dir)

    class _StableCanonicalizer:
        def canonicalize(self, *, source_path: Path, content_dir: Path):
            class _Canonical:
                def __init__(self, path: Path, root: Path) -> None:
                    digest = hashlib.sha256(path.name.encode("utf-8")).hexdigest()
                    self.content_id = f"con_{digest[:12]}"
                    self.canonical_spec_version = 1
                    self.storage_relpath = f"content/test/{digest}.jpg"
                    self.mime_type = "image/jpeg"
                    self.byte_size = 123
                    self.width = 100
                    self.height = 80
                    output_path = root / "test" / f"{digest}.jpg"
                    output_path.parent.mkdir(parents=True, exist_ok=True)
                    output_path.write_bytes(b"jpeg")

            return _Canonical(source_path, content_dir)

    def test_gateway_init_db_creates_database_and_layout(self) -> None:
        root = Path(os.environ["EONA_GATEWAY_HOME"])
        self.assertTrue((root / "db" / "gateway.db").is_file())
        self.assertTrue((root / "imports" / "sessions").is_dir())
        self.assertTrue((root / "runs").is_dir())
        with sqlite3.connect(root / "db" / "gateway.db") as connection:
            objects = connection.execute(
                "SELECT name, type FROM sqlite_master WHERE name IN ('gateway_query_photo_v1', 'gateway_query_photo_v2', 'gateway_query_path_v1', 'gateway_query_location_v2', 'gateway_query_duplicate_v1', 'gateway_query_tag_v1', 'photo_duplicate_semantic', 'photo_tag_semantic', 'semantic_enrichment_job') ORDER BY name"
            ).fetchall()
            photo_columns = {row[1] for row in connection.execute("PRAGMA table_info(photo)").fetchall()}
            semantic_job_columns = {row[1] for row in connection.execute("PRAGMA table_info(semantic_enrichment_job)").fetchall()}
        self.assertEqual(
            objects,
            [
                ("gateway_query_duplicate_v1", "view"),
                ("gateway_query_location_v2", "view"),
                ("gateway_query_path_v1", "view"),
                ("gateway_query_photo_v1", "view"),
                ("gateway_query_photo_v2", "view"),
                ("gateway_query_tag_v1", "view"),
                ("photo_duplicate_semantic", "table"),
                ("photo_tag_semantic", "table"),
                ("semantic_enrichment_job", "table"),
            ],
        )
        self.assertIn("taken_at_original", photo_columns)
        self.assertIn("cadis_result_json", photo_columns)
        self.assertIn("cadis_version", photo_columns)
        self.assertIn("location_detail", photo_columns)
        self.assertIn("total_rows", semantic_job_columns)

    def test_gateway_photo_memory_query_returns_grouped_rows(self) -> None:
        service = GatewayService()
        with sqlite3.connect(service.paths.database) as connection:
            connection.row_factory = sqlite3.Row
            connection.execute(
                """
                INSERT INTO content(
                    content_id, canonical_spec_version, storage_relpath, mime_type, byte_size, width, height, created_at
                ) VALUES (?, 1, ?, 'image/jpeg', 123, 10, 10, '2026-03-20T00:00:00Z')
                """,
                ("content-a", "content/aa/bb/content-a.jpg"),
            )
            connection.execute(
                """
                INSERT INTO photo(
                    photo_id, content_id, photo_signature, photo_signature_version, signature_payload_json,
                    taken_at_utc, taken_at_original, raw_latitude, raw_longitude, raw_altitude, camera_make, camera_model, created_at
                ) VALUES (?, ?, ?, 1, '{}', ?, ?, NULL, NULL, NULL, ?, ?, '2026-03-20T00:00:00Z')
                """,
                ("pho_001", "content-a", "sig-a", "2025-05-06T01:02:03Z", "2025:05:06 09:02:03", "apple", "iphone 15"),
            )
            connection.execute(
                """
                INSERT INTO content(
                    content_id, canonical_spec_version, storage_relpath, mime_type, byte_size, width, height, created_at
                ) VALUES (?, 1, ?, 'image/jpeg', 123, 10, 10, '2026-03-20T00:00:00Z')
                """,
                ("content-b", "content/aa/bb/content-b.jpg"),
            )
            connection.execute(
                """
                INSERT INTO photo(
                    photo_id, content_id, photo_signature, photo_signature_version, signature_payload_json,
                    taken_at_utc, taken_at_original, raw_latitude, raw_longitude, raw_altitude, camera_make, camera_model, created_at
                ) VALUES (?, ?, ?, 1, '{}', ?, ?, NULL, NULL, NULL, ?, ?, '2026-03-20T00:00:00Z')
                """,
                ("pho_002", "content-b", "sig-b", "2025-06-01T00:00:00Z", "2025:06:01 08:00:00", "apple", "iphone 15"),
            )
            connection.execute(
                """
                INSERT INTO import_run(
                    run_id, source_import_id, status, current_stage, progress, started_at, completed_at, created_at, error_code, error_message, report_json
                ) VALUES (?, ?, 'complete', NULL, 1.0, NULL, NULL, '2026-03-20T00:00:00Z', NULL, NULL, NULL)
                """,
                ("run_001", "imp_001"),
            )
            connection.execute(
                """
                INSERT INTO photo_path_observation(photo_id, path_text, first_seen_run_id, created_at)
                VALUES (?, ?, ?, '2026-03-20T00:00:00Z')
                """,
                ("pho_001", "/photos/Kyoto/IMG_0001.JPG", "run_001"),
            )
            connection.execute(
                """
                INSERT INTO photo_path_observation(photo_id, path_text, first_seen_run_id, created_at)
                VALUES (?, ?, ?, '2026-03-20T00:00:00Z')
                """,
                ("pho_002", "/photos/Tokyo/IMG_0002.JPG", "run_001"),
            )
            connection.commit()

        payload = service.query_photo_memory(
            {
                "query_version": 1,
                "anchor": {"entity": "camera"},
                "select": [
                    {"entity": "camera", "attribute": "model"},
                    {"entity": "photo", "attribute": "id", "aggregation": "count"},
                ],
                "filters": [
                    {"entity": "time", "attribute": "year", "operator": "==", "value": 2025},
                ],
                "group_by": [
                    {"entity": "camera", "attribute": "model"},
                ],
                "sort_by": [
                    {"entity": "photo", "attribute": "id", "aggregation": "count", "order": "desc"},
                ],
                "limit": 5,
            }
        )

        self.assertEqual(payload["row_count"], 1)
        self.assertEqual(payload["rows"], [{"camera_model": "iphone 15", "photo_count": 2}])
        self.assertEqual(payload["capabilities_used"], ["camera", "photo", "time"])

    def test_gateway_photo_memory_query_supports_path_filters(self) -> None:
        service = GatewayService()
        with sqlite3.connect(service.paths.database) as connection:
            connection.execute(
                """
                INSERT INTO content(
                    content_id, canonical_spec_version, storage_relpath, mime_type, byte_size, width, height, created_at
                ) VALUES (?, 1, ?, 'image/jpeg', 123, 10, 10, '2026-03-20T00:00:00Z')
                """,
                ("content-a", "content/aa/bb/content-a.jpg"),
            )
            connection.execute(
                """
                INSERT INTO photo(
                    photo_id, content_id, photo_signature, photo_signature_version, signature_payload_json,
                    taken_at_utc, taken_at_original, raw_latitude, raw_longitude, raw_altitude, camera_make, camera_model, created_at
                ) VALUES (?, ?, ?, 1, '{}', ?, ?, NULL, NULL, NULL, ?, ?, '2026-03-20T00:00:00Z')
                """,
                ("pho_001", "content-a", "sig-a", "2025-05-06T01:02:03Z", "2025:05:06 09:02:03", "apple", "iphone 15"),
            )
            connection.execute(
                """
                INSERT INTO import_run(
                    run_id, source_import_id, status, current_stage, progress, started_at, completed_at, created_at, error_code, error_message, report_json
                ) VALUES (?, ?, 'complete', NULL, 1.0, NULL, NULL, '2026-03-20T00:00:00Z', NULL, NULL, NULL)
                """,
                ("run_001", "imp_001"),
            )
            connection.execute(
                """
                INSERT INTO photo_path_observation(photo_id, path_text, first_seen_run_id, created_at)
                VALUES (?, ?, ?, '2026-03-20T00:00:00Z')
                """,
                ("pho_001", "/photos/Kyoto/IMG_0001.JPG", "run_001"),
            )
            connection.commit()

        payload = service.query_photo_memory(
            {
                "query_version": 1,
                "anchor": {"entity": "photo"},
                "select": [{"entity": "photo", "attribute": "id", "aggregation": "count"}],
                "filters": [{"entity": "path", "attribute": "text", "operator": "contains", "value": "Kyoto"}],
                "limit": 5,
            }
        )
        self.assertEqual(payload["rows"], [{"photo_count": 1}])

    def test_gateway_photo_memory_query_supports_tag_filters(self) -> None:
        service = GatewayService()
        with sqlite3.connect(service.paths.database) as connection:
            connection.execute(
                """
                INSERT INTO content(
                    content_id, canonical_spec_version, storage_relpath, mime_type, byte_size, width, height, created_at
                ) VALUES (?, 1, ?, 'image/jpeg', 123, 10, 10, '2026-03-20T00:00:00Z')
                """,
                ("content-a", "content/aa/bb/content-a.jpg"),
            )
            connection.execute(
                """
                INSERT INTO photo(
                    photo_id, content_id, photo_signature, photo_signature_version, signature_payload_json,
                    taken_at_utc, taken_at_original, raw_latitude, raw_longitude, raw_altitude, camera_make, camera_model, created_at
                ) VALUES (?, ?, ?, 1, '{}', ?, ?, NULL, NULL, NULL, ?, ?, '2026-03-20T00:00:00Z')
                """,
                ("pho_001", "content-a", "sig-a", "2025-05-06T01:02:03Z", "2025:05:06 09:02:03", "apple", "iphone 15"),
            )
            connection.execute(
                """
                INSERT INTO content(
                    content_id, canonical_spec_version, storage_relpath, mime_type, byte_size, width, height, created_at
                ) VALUES (?, 1, ?, 'image/jpeg', 123, 10, 10, '2026-03-20T00:00:00Z')
                """,
                ("content-b", "content/aa/bb/content-b.jpg"),
            )
            connection.execute(
                """
                INSERT INTO photo(
                    photo_id, content_id, photo_signature, photo_signature_version, signature_payload_json,
                    taken_at_utc, taken_at_original, raw_latitude, raw_longitude, raw_altitude, camera_make, camera_model, created_at
                ) VALUES (?, ?, ?, 1, '{}', ?, ?, NULL, NULL, NULL, ?, ?, '2026-03-20T00:00:00Z')
                """,
                ("pho_002", "content-b", "sig-b", "2025-06-01T00:00:00Z", "2025:06:01 08:00:00", "apple", "iphone 15"),
            )
            connection.execute(
                """
                INSERT INTO photo_tag_semantic(
                    photo_id, tag_key, tag_value, tag_source, tag_strength, semantic_version, computed_at
                ) VALUES (?, 'has_people', ?, 'opencv_yunet_face_detector', NULL, 1, '2026-03-20T00:00:00Z')
                """,
                ("pho_001", "true"),
            )
            connection.execute(
                """
                INSERT INTO photo_tag_semantic(
                    photo_id, tag_key, tag_value, tag_source, tag_strength, semantic_version, computed_at
                ) VALUES (?, 'has_people', ?, 'opencv_yunet_face_detector', NULL, 1, '2026-03-20T00:00:00Z')
                """,
                ("pho_002", "false"),
            )
            connection.commit()

        payload = service.query_photo_memory(
            {
                "query_version": 1,
                "anchor": {"entity": "photo"},
                "select": [{"entity": "photo", "attribute": "id", "aggregation": "count"}],
                "filters": [
                    {"entity": "tag", "attribute": "key", "operator": "==", "value": "has_people"},
                    {"entity": "tag", "attribute": "value", "operator": "==", "value": "true"},
                ],
                "limit": 5,
            }
        )
        self.assertEqual(payload["rows"], [{"photo_count": 1}])
        self.assertEqual(payload["capabilities_used"], ["photo", "tag"])

    def test_gateway_photo_memory_query_uses_taken_at_original_fallback_in_v2(self) -> None:
        service = GatewayService()
        with sqlite3.connect(service.paths.database) as connection:
            connection.execute(
                """
                INSERT INTO content(
                    content_id, canonical_spec_version, storage_relpath, mime_type, byte_size, width, height, created_at
                ) VALUES (?, 1, ?, 'image/jpeg', 123, 10, 10, '2026-03-20T00:00:00Z')
                """,
                ("content-a", "content/aa/bb/content-a.jpg"),
            )
            connection.execute(
                """
                INSERT INTO photo(
                    photo_id, content_id, photo_signature, photo_signature_version, signature_payload_json,
                    taken_at_utc, taken_at_original, raw_latitude, raw_longitude, raw_altitude, camera_make, camera_model, created_at
                ) VALUES (?, ?, ?, 1, '{}', NULL, ?, NULL, NULL, NULL, ?, ?, '2026-03-20T00:00:00Z')
                """,
                ("pho_001", "content-a", "sig-a", "2024:09:15 14:10:00", "Apple", "iPhone 11"),
            )
            connection.commit()

        payload = service.query_photo_memory(
            {
                "query_version": 1,
                "anchor": {"entity": "time"},
                "select": [
                    {"entity": "time", "attribute": "year"},
                    {"entity": "photo", "attribute": "id", "aggregation": "count"},
                ],
                "group_by": [
                    {"entity": "time", "attribute": "year"},
                ],
                "sort_by": [
                    {"entity": "time", "attribute": "year", "order": "asc"},
                ],
                "limit": 5,
            }
        )
        self.assertEqual(payload["rows"], [{"time_year": 2024, "photo_count": 1}])

    def test_gateway_photo_memory_query_supports_strict_location_filters(self) -> None:
        service = GatewayService()
        cadis_payload = json.dumps(
            {
                "state": {"world": {"iso2": "JP", "name": "Japan"}},
                "result": {
                    "country": {"name": "Japan"},
                    "admin_hierarchy": [{"name": "京都府"}, {"name": "京都市"}],
                },
            }
        )
        with sqlite3.connect(service.paths.database) as connection:
            connection.execute(
                """
                INSERT INTO content(
                    content_id, canonical_spec_version, storage_relpath, mime_type, byte_size, width, height, created_at
                ) VALUES (?, 1, ?, 'image/jpeg', 123, 10, 10, '2026-03-20T00:00:00Z')
                """,
                ("content-a", "content/aa/bb/content-a.jpg"),
            )
            connection.execute(
                """
                INSERT INTO photo(
                    photo_id, content_id, photo_signature, photo_signature_version, signature_payload_json,
                    taken_at_utc, taken_at_original, raw_latitude, raw_longitude, raw_altitude,
                    cadis_result_json, cadis_version, location_detail,
                    camera_make, camera_model, created_at
                ) VALUES (?, ?, ?, 1, '{}', NULL, NULL, NULL, NULL, NULL, ?, ?, ?, NULL, NULL, '2026-03-20T00:00:00Z')
                """,
                ("pho_001", "content-a", "sig-a", cadis_payload, "0.3.0", "ok"),
            )
            connection.commit()

        payload = service.query_photo_memory(
            {
                "query_version": 1,
                "anchor": {"entity": "location"},
                "select": [
                    {"entity": "location", "attribute": "country"},
                    {"entity": "photo", "attribute": "id", "aggregation": "count"},
                ],
                "filters": [
                    {"entity": "location", "attribute": "admin_label", "operator": "contains", "value": "京都市"},
                ],
                "group_by": [
                    {"entity": "location", "attribute": "country"},
                ],
                "limit": 5,
            }
        )

        self.assertEqual(payload["rows"], [{"location_country": "Japan", "photo_count": 1}])
        self.assertEqual(payload["capabilities_used"], ["location", "photo"])

    def test_gateway_backfill_photo_locations_persists_cadis_results(self) -> None:
        service = GatewayService()
        with sqlite3.connect(service.paths.database) as connection:
            connection.execute(
                """
                INSERT INTO content(
                    content_id, canonical_spec_version, storage_relpath, mime_type, byte_size, width, height, created_at
                ) VALUES (?, 1, ?, 'image/jpeg', 123, 10, 10, '2026-03-20T00:00:00Z')
                """,
                ("content-a", "content/aa/bb/content-a.jpg"),
            )
            connection.execute(
                """
                INSERT INTO photo(
                    photo_id, content_id, photo_signature, photo_signature_version, signature_payload_json,
                    taken_at_utc, taken_at_original, raw_latitude, raw_longitude, raw_altitude,
                    cadis_result_json, cadis_version, location_detail,
                    camera_make, camera_model, created_at
                ) VALUES (?, ?, ?, 1, '{}', NULL, NULL, ?, ?, NULL, NULL, NULL, NULL, NULL, NULL, '2026-03-20T00:00:00Z')
                """,
                ("pho_001", "content-a", "sig-a", 35.0116, 135.7681),
            )
            connection.commit()

        class _BackfillNormalizer:
            def normalize(self, latitude: float, longitude: float) -> NormalizedLocation:
                self.last = (latitude, longitude)
                return NormalizedLocation(
                    cadis_result_json=json.dumps(
                        {
                            "state": {"world": {"iso2": "JP", "name": "Japan"}},
                            "result": {
                                "country": {"name": "Japan"},
                                "admin_hierarchy": [{"name": "京都府"}, {"name": "京都市"}],
                            },
                        }
                    ),
                    cadis_version="0.3.0",
                    detail="ok",
                )

        normalizer = _BackfillNormalizer()
        result = service.backfill_photo_locations(normalizer=normalizer)

        self.assertTrue(result["ok"])
        self.assertEqual(result["updated"], 1)
        self.assertEqual(normalizer.last, (35.0116, 135.7681))
        with sqlite3.connect(service.paths.database) as connection:
            connection.row_factory = sqlite3.Row
            row = connection.execute(
                "SELECT cadis_version, location_detail, cadis_result_json FROM photo WHERE photo_id = ?",
                ("pho_001",),
            ).fetchone()
            location_row = connection.execute(
                "SELECT query_country, query_admin_label, query_admin_path, query_location_source FROM gateway_query_location_v2 WHERE photo_id = ?",
                ("pho_001",),
            ).fetchone()
        self.assertEqual(row["cadis_version"], "0.3.0")
        self.assertEqual(row["location_detail"], "ok")
        self.assertEqual(json.loads(str(row["cadis_result_json"]))["state"]["world"]["iso2"], "JP")
        self.assertEqual(
            dict(location_row),
            {
                "query_country": "Japan",
                "query_admin_label": "京都府 / 京都市",
                "query_admin_path": '["京都府","京都市"]',
                "query_location_source": "strict_geo",
            },
        )

    def test_gateway_backfill_photo_locations_skips_rows_without_gps(self) -> None:
        service = GatewayService()
        with sqlite3.connect(service.paths.database) as connection:
            connection.execute(
                """
                INSERT INTO content(
                    content_id, canonical_spec_version, storage_relpath, mime_type, byte_size, width, height, created_at
                ) VALUES (?, 1, ?, 'image/jpeg', 123, 10, 10, '2026-03-20T00:00:00Z')
                """,
                ("content-a", "content/aa/bb/content-a.jpg"),
            )
            connection.execute(
                """
                INSERT INTO photo(
                    photo_id, content_id, photo_signature, photo_signature_version, signature_payload_json,
                    taken_at_utc, taken_at_original, raw_latitude, raw_longitude, raw_altitude,
                    cadis_result_json, cadis_version, location_detail,
                    camera_make, camera_model, created_at
                ) VALUES (?, ?, ?, 1, '{}', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2026-03-20T00:00:00Z')
                """,
                ("pho_001", "content-a", "sig-a"),
            )
            connection.commit()

        result = service.backfill_photo_locations(normalizer=self._FakeNormalizer())

        self.assertTrue(result["ok"])
        self.assertEqual(result["updated"], 0)
        self.assertEqual(result["skipped_no_gps"], 1)

    def test_gateway_query_location_country_excludes_iso2_and_non_country_world_names(self) -> None:
        service = GatewayService()
        unsupported_country_payload = json.dumps(
            {
                "execution": {
                    "capability_detail": "unsupported_country",
                    "lookup_status": "failed",
                    "resolution_state": "remediable_capability_gap",
                },
                "result": None,
                "state": {
                    "dataset": {"iso2": "SG", "status": "missing"},
                    "world": {"classification": "country", "iso2": "SG", "status": "ok"},
                },
            }
        )
        non_country_payload = json.dumps(
            {
                "execution": {
                    "lookup_status": "failed",
                    "resolution_state": "terminal_non_country",
                },
                "result": None,
                "state": {
                    "world": {"classification": "open_sea", "name": "Strait of Singapore", "status": "ok"},
                },
            }
        )
        with sqlite3.connect(service.paths.database) as connection:
            connection.execute(
                """
                INSERT INTO content(
                    content_id, canonical_spec_version, storage_relpath, mime_type, byte_size, width, height, created_at
                ) VALUES (?, 1, ?, 'image/jpeg', 123, 10, 10, '2026-03-20T00:00:00Z')
                """,
                ("content-sg", "content/aa/bb/content-sg.jpg"),
            )
            connection.execute(
                """
                INSERT INTO content(
                    content_id, canonical_spec_version, storage_relpath, mime_type, byte_size, width, height, created_at
                ) VALUES (?, 1, ?, 'image/jpeg', 123, 10, 10, '2026-03-20T00:00:00Z')
                """,
                ("content-sea", "content/aa/bb/content-sea.jpg"),
            )
            connection.execute(
                """
                INSERT INTO photo(
                    photo_id, content_id, photo_signature, photo_signature_version, signature_payload_json,
                    taken_at_utc, taken_at_original, raw_latitude, raw_longitude, raw_altitude,
                    cadis_result_json, cadis_version, location_detail,
                    camera_make, camera_model, created_at
                ) VALUES (?, ?, ?, 1, '{}', NULL, NULL, NULL, NULL, NULL, ?, ?, ?, NULL, NULL, '2026-03-20T00:00:00Z')
                """,
                ("pho_sg", "content-sg", "sig-sg", unsupported_country_payload, "0.3.6", "missing"),
            )
            connection.execute(
                """
                INSERT INTO photo(
                    photo_id, content_id, photo_signature, photo_signature_version, signature_payload_json,
                    taken_at_utc, taken_at_original, raw_latitude, raw_longitude, raw_altitude,
                    cadis_result_json, cadis_version, location_detail,
                    camera_make, camera_model, created_at
                ) VALUES (?, ?, ?, 1, '{}', NULL, NULL, NULL, NULL, NULL, ?, ?, ?, NULL, NULL, '2026-03-20T00:00:00Z')
                """,
                ("pho_sea", "content-sea", "sig-sea", non_country_payload, "0.3.6", "open_sea"),
            )
            connection.commit()
            connection.row_factory = sqlite3.Row
            rows = connection.execute(
                """
                SELECT photo_id, query_country, query_location_source
                FROM gateway_query_location_v2
                WHERE photo_id IN ('pho_sg', 'pho_sea')
                ORDER BY photo_id
                """
            ).fetchall()
        self.assertEqual(
            [dict(row) for row in rows],
            [
                {"photo_id": "pho_sea", "query_country": None, "query_location_source": "unknown"},
                {"photo_id": "pho_sg", "query_country": None, "query_location_source": "unknown"},
            ],
        )

    def test_gateway_exiftool_upgrade_tool_reports_reimport_suggested_on_version_change(self) -> None:
        payload = run_exiftool_upgrade_tool(
            previous_identity={"exiftool_version": "13.52"},
            current_identity={"exiftool_version": "13.53"},
        )
        self.assertEqual(payload["module"], "exiftool")
        self.assertEqual(payload["status"], "reimport_suggested")
        self.assertTrue(payload["changed"])
        self.assertEqual(payload["details"]["changed_fields"], ["exiftool_version"])

    def test_gateway_cadis_upgrade_tool_reports_ready_when_unchanged(self) -> None:
        payload = run_cadis_upgrade_tool(
            previous_identity={
                "cadis_version": "0.4.1",
                "cadis_dataset_bundle_version": "bundle-a",
                "cadis_dataset_bundle_digest": "sha256:a",
            },
            current_identity={
                "cadis_version": "0.4.1",
                "cadis_dataset_bundle_version": "bundle-a",
                "cadis_dataset_bundle_digest": "sha256:a",
            },
        )
        self.assertEqual(payload["module"], "cadis")
        self.assertEqual(payload["status"], "ready")
        self.assertFalse(payload["changed"])

    def test_gateway_cadis_upgrade_tool_requires_attention_for_0_3_to_0_4_jump(self) -> None:
        payload = run_cadis_upgrade_tool(
            previous_identity={
                "cadis_version": "0.3.5",
                "cadis_dataset_bundle_version": "bundle-035",
                "cadis_dataset_bundle_digest": "sha256:035",
            },
            current_identity={
                "cadis_version": "0.4.1",
                "cadis_dataset_bundle_version": "bundle-041",
                "cadis_dataset_bundle_digest": "sha256:041",
            },
        )
        self.assertEqual(payload["module"], "cadis")
        self.assertEqual(payload["status"], "needs_attention")
        self.assertTrue(payload["changed"])
        self.assertEqual(payload["details"]["reason_code"], "cadis_world_name_semantics_changed")
        self.assertEqual(payload["details"]["reprocess_scope"], "all_geo_rows")

    def test_gateway_readiness_reports_needs_attention_for_cadis_semantic_jump(self) -> None:
        service = GatewayService()
        first_runtime = {
            "ok": True,
            "lifecycle_state": "ready",
            "summary": "Gateway runtime check passed.",
            "warnings": [],
            "problems": [],
            "runtime_identity": {
                "runtime_version": "gateway-v1-cadis-a",
                "runtime_image_digest": "sha256:cadis-a",
                "exiftool_version": "13.53",
                "cadis_version": "0.3.5",
                "cadis_dataset_bundle_version": "bundle-035",
                "cadis_dataset_bundle_digest": "sha256:035",
                "canonical_backend": "vips",
                "canonical_spec_version": 2,
            },
        }
        second_runtime = {
            "ok": True,
            "lifecycle_state": "ready",
            "summary": "Gateway runtime check passed.",
            "warnings": [],
            "problems": [],
            "runtime_identity": {
                "runtime_version": "gateway-v1-cadis-b",
                "runtime_image_digest": "sha256:cadis-b",
                "exiftool_version": "13.53",
                "cadis_version": "0.4.1",
                "cadis_dataset_bundle_version": "bundle-041",
                "cadis_dataset_bundle_digest": "sha256:041",
                "canonical_backend": "vips",
                "canonical_spec_version": 2,
            },
        }
        with mock.patch.object(
            service,
            "_content_store_integrity_status",
            return_value={"status": "ok", "summary": "ok", "problems": []},
        ):
            with mock.patch("eona.gateway_service.inspect_gateway_runtime", side_effect=lambda **_: copy.deepcopy(first_runtime)):
                service.readiness()
            with mock.patch("eona.gateway_service.inspect_gateway_runtime", side_effect=lambda **_: copy.deepcopy(second_runtime)):
                payload = service.readiness()
        self.assertEqual(payload["lifecycle_state"], "needs_attention")
        self.assertEqual(payload["runtime_upgrade"]["status"], "needs_attention")
        details_text = "\n".join(payload["runtime_upgrade"]["details"])
        self.assertIn("requires re-running all stored location rows", details_text)

    def test_gateway_apply_runtime_upgrades_reruns_cadis_rows_and_clears_state(self) -> None:
        service = GatewayService()

        class _UpgradeNormalizer:
            def normalize(self, latitude: float, longitude: float) -> NormalizedLocation:
                return NormalizedLocation(
                    cadis_result_json='{"result":"upgraded"}',
                    cadis_version="0.4.1",
                    detail="upgraded",
                )

        with sqlite3.connect(service.paths.database) as connection:
            connection.execute(
                """
                INSERT INTO content(
                    content_id, canonical_spec_version, storage_relpath, mime_type, byte_size, width, height, created_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    "con_upgrade",
                    2,
                    "content/upgrade/example.jpg",
                    "image/jpeg",
                    123,
                    10,
                    10,
                    "2026-03-20T00:00:00Z",
                ),
            )
            connection.execute(
                """
                INSERT INTO photo(
                    photo_id, content_id, photo_signature, photo_signature_version, signature_payload_json,
                    taken_at_utc, taken_at_original, raw_latitude, raw_longitude, raw_altitude,
                    cadis_result_json, cadis_version, location_detail,
                    camera_make, camera_model, created_at
                ) VALUES (?, ?, ?, 1, '{}', NULL, NULL, ?, ?, NULL, ?, ?, ?, NULL, NULL, '2026-03-20T00:00:00Z')
                """,
                (
                    "pho_upgrade",
                    "con_upgrade",
                    "sig-upgrade",
                    25.0,
                    121.5,
                    '{"old":"cadis"}',
                    "0.3.5",
                    "legacy",
                ),
            )
            connection.execute(
                """
                INSERT INTO gateway_runtime_state(
                    state_key,
                    current_runtime_identity_json,
                    previous_runtime_identity_json,
                    module_results_json,
                    lifecycle_state,
                    summary,
                    details_json,
                    updated_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    "current",
                    json.dumps(
                        {
                            "runtime_version": "gateway-v1-cadis-b",
                            "cadis_version": "0.4.1",
                            "cadis_dataset_bundle_version": "bundle-041",
                            "cadis_dataset_bundle_digest": "sha256:041",
                            "canonical_backend": "vips",
                            "canonical_spec_version": 2,
                            "exiftool_version": "13.53",
                            "runtime_image_digest": "sha256:cadis-b",
                        },
                        sort_keys=True,
                    ),
                    json.dumps(
                        {
                            "runtime_version": "gateway-v1-cadis-a",
                            "cadis_version": "0.3.5",
                            "cadis_dataset_bundle_version": "bundle-035",
                            "cadis_dataset_bundle_digest": "sha256:035",
                            "canonical_backend": "vips",
                            "canonical_spec_version": 2,
                            "exiftool_version": "13.53",
                            "runtime_image_digest": "sha256:cadis-a",
                        },
                        sort_keys=True,
                    ),
                    json.dumps(
                        [
                            {
                                "module": "cadis",
                                "status": "needs_attention",
                                "changed": True,
                                "details": {
                                    "message": "Cadis 0.3.x to 0.4.x upgrade requires re-running all stored location rows.",
                                    "reason_code": "cadis_world_name_semantics_changed",
                                    "reprocess_scope": "all_geo_rows",
                                },
                            }
                        ],
                        sort_keys=True,
                    ),
                    "needs_attention",
                    "Gateway runtime upgrade needs attention.",
                    json.dumps(["Cadis 0.3.x to 0.4.x upgrade requires re-running all stored location rows."]),
                    "2026-03-20T00:00:00Z",
                ),
            )
            connection.commit()

        result = service.apply_runtime_upgrades(normalizer=_UpgradeNormalizer())
        self.assertTrue(result["ok"])
        self.assertEqual(result["summary"], "Gateway runtime upgrades applied and pending acceptance.")
        self.assertEqual(result["actions"][0]["module"], "cadis")
        self.assertEqual(result["actions"][0]["status"], "ready")
        self.assertEqual(result["actions"][0]["details"]["updated"], 1)

        with sqlite3.connect(service.paths.database) as connection:
            connection.row_factory = sqlite3.Row
            photo = connection.execute(
                "SELECT cadis_result_json, cadis_version, location_detail FROM photo WHERE photo_id = ?",
                ("pho_upgrade",),
            ).fetchone()
            runtime_state = connection.execute(
                "SELECT lifecycle_state, summary FROM gateway_runtime_state WHERE state_key = 'current'"
            ).fetchone()
        self.assertEqual(str(photo["cadis_result_json"]), '{"result":"upgraded"}')
        self.assertEqual(str(photo["cadis_version"]), "0.4.1")
        self.assertEqual(str(photo["location_detail"]), "upgraded")
        self.assertEqual(str(runtime_state["lifecycle_state"]), "pending_acceptance")
        self.assertEqual(str(runtime_state["summary"]), "Gateway runtime upgrades applied and pending acceptance.")

        accept_result = service.accept_runtime_upgrades()
        self.assertTrue(accept_result["ok"])
        self.assertEqual(accept_result["summary"], "Gateway runtime upgrade accepted.")
        with sqlite3.connect(service.paths.database) as connection:
            connection.row_factory = sqlite3.Row
            accepted_state = connection.execute(
                "SELECT lifecycle_state, summary FROM gateway_runtime_state WHERE state_key = 'current'"
            ).fetchone()
        self.assertEqual(str(accepted_state["lifecycle_state"]), "ready")
        self.assertEqual(str(accepted_state["summary"]), "Gateway runtime upgrade accepted.")

    def test_gateway_apply_runtime_upgrades_bootstraps_runtime_state_when_missing(self) -> None:
        service = GatewayService()
        runtime_payload = {
            "ok": True,
            "lifecycle_state": "ready",
            "summary": "Gateway runtime check passed.",
            "warnings": [],
            "problems": [],
            "runtime_identity": {
                "runtime_version": "1.1.0",
                "runtime_image_digest": "sha256:bootstrap-a",
                "exiftool_version": "13.53",
                "cadis_version": "0.4.1",
                "cadis_dataset_bundle_version": "bundle-041",
                "cadis_dataset_bundle_digest": "sha256:041",
                "canonical_backend": "vips",
                "canonical_spec_version": 2,
            },
        }
        with mock.patch("eona.gateway_service.inspect_gateway_runtime", side_effect=lambda **_: copy.deepcopy(runtime_payload)):
            result = service.apply_runtime_upgrades()
        self.assertTrue(result["ok"])
        self.assertEqual(result["summary"], "Gateway runtime baseline recorded.")
        with sqlite3.connect(service.paths.database) as connection:
            row = connection.execute(
                "SELECT lifecycle_state, current_runtime_identity_json FROM gateway_runtime_state WHERE state_key = 'current'"
            ).fetchone()
        self.assertIsNotNone(row)
        self.assertEqual(str(row[0]), "ready")

    def test_gateway_backfill_duplicate_semantics_marks_export_variants(self) -> None:
        service = GatewayService()
        with sqlite3.connect(service.paths.database) as connection:
            for suffix in ("HEIC", "jpeg"):
                content_id = f"content-{suffix.lower()}"
                photo_id = f"pho_{suffix.lower()}"
                connection.execute(
                    """
                    INSERT INTO content(
                        content_id, canonical_spec_version, storage_relpath, mime_type, byte_size, width, height, created_at
                    ) VALUES (?, 1, ?, 'image/jpeg', 123, 10, 10, '2026-03-20T00:00:00Z')
                    """,
                    (content_id, f"content/test/{content_id}.jpg"),
                )
                connection.execute(
                    """
                    INSERT INTO photo(
                        photo_id, content_id, photo_signature, photo_signature_version, signature_payload_json,
                        taken_at_utc, taken_at_original, raw_latitude, raw_longitude, raw_altitude,
                        cadis_result_json, cadis_version, location_detail,
                        camera_make, camera_model, created_at
                    ) VALUES (?, ?, ?, 1, '{}', ?, ?, NULL, NULL, NULL, NULL, NULL, NULL, ?, ?, '2026-03-20T00:00:00Z')
                    """,
                    (
                        photo_id,
                        content_id,
                        f"sig-{suffix}",
                        "2024-09-13T10:00:00Z",
                        "2024:09:13 18:00:00",
                        "Apple",
                        "iPhone 11",
                    ),
                )
                connection.execute(
                    """
                    INSERT INTO import_run(
                        run_id, source_import_id, status, current_stage, progress, started_at, completed_at, created_at, error_code, error_message, report_json
                    ) VALUES (?, ?, 'complete', NULL, 1.0, NULL, NULL, '2026-03-20T00:00:00Z', NULL, NULL, NULL)
                    """,
                    (f"run_{suffix.lower()}", f"imp_{suffix.lower()}"),
                )
                connection.execute(
                    """
                    INSERT INTO photo_path_observation(photo_id, path_text, first_seen_run_id, created_at)
                    VALUES (?, ?, ?, '2026-03-20T00:00:00Z')
                    """,
                    (
                        photo_id,
                        f"2026.03.21 Mac Photos Backup/2024年9月13日, Oslo/IMG_9560.{suffix}",
                        f"run_{suffix.lower()}",
                    ),
                )
            connection.commit()

        result = service.backfill_duplicate_semantics()
        self.assertTrue(result["ok"])
        self.assertEqual(result["replay_mode"], "incremental")
        self.assertEqual(result["duplicate_rows"], 1)
        self.assertEqual(result["primary_rows"], 1)

        with sqlite3.connect(service.paths.database) as connection:
            connection.row_factory = sqlite3.Row
            rows = connection.execute(
                """
                SELECT photo_id, duplicate_cluster_id, duplicate_role, duplicate_reason
                FROM photo_duplicate_semantic
                ORDER BY photo_id
                """
            ).fetchall()
        self.assertEqual(len(rows), 2)
        self.assertEqual({row["duplicate_reason"] for row in rows}, {"export_variant"})
        self.assertEqual({row["duplicate_cluster_id"] for row in rows}.__len__(), 1)
        self.assertEqual({row["duplicate_role"] for row in rows}, {"primary", "duplicate"})
        with sqlite3.connect(service.paths.database) as connection:
            job = connection.execute(
                """
                SELECT job_name, semantic_version, status, total_rows, processed_rows, updated_rows, failed_rows
                FROM semantic_enrichment_job
                WHERE job_name = 'duplicate_semantic'
                """
            ).fetchone()
        self.assertEqual(job, ("duplicate_semantic", 1, "completed", 2, 2, 2, 0))

    def test_gateway_backfill_duplicate_semantics_collapses_iphoto_masters_and_previews(self) -> None:
        service = GatewayService()
        with sqlite3.connect(service.paths.database) as connection:
            for photo_id, content_id, path_text in (
                (
                    "pho_master",
                    "content-master",
                    "iPhoto9/Masters/2016/07/04/20160704-141423/IMG_2994.JPG",
                ),
                (
                    "pho_preview",
                    "content-preview",
                    "iPhoto9/Previews/2016/07/04/20160704-141423/WYrwn%d5RPyz6x5CnGzPhQ/IMG_2994.jpg",
                ),
            ):
                connection.execute(
                    """
                    INSERT INTO content(
                        content_id, canonical_spec_version, storage_relpath, mime_type, byte_size, width, height, created_at
                    ) VALUES (?, 1, ?, 'image/jpeg', 123, 10, 10, '2026-03-20T00:00:00Z')
                    """,
                    (content_id, f"content/test/{content_id}.jpg"),
                )
                connection.execute(
                    """
                    INSERT INTO photo(
                        photo_id, content_id, photo_signature, photo_signature_version, signature_payload_json,
                        taken_at_utc, taken_at_original, raw_latitude, raw_longitude, raw_altitude,
                        cadis_result_json, cadis_version, location_detail,
                        camera_make, camera_model, created_at
                    ) VALUES (?, ?, ?, 1, '{}', NULL, ?, ?, ?, NULL, NULL, NULL, NULL, ?, ?, '2026-03-20T00:00:00Z')
                    """,
                    (
                        photo_id,
                        content_id,
                        f"sig-{photo_id}",
                        "2016:01:03 15:38:45.844",
                        24.3881444444444,
                        120.778686111111,
                        "Apple",
                        "iPhone 6 Plus",
                    ),
                )
                connection.execute(
                    """
                    INSERT INTO import_run(
                        run_id, source_import_id, status, current_stage, progress, started_at, completed_at, created_at, error_code, error_message, report_json
                    ) VALUES (?, ?, 'complete', NULL, 1.0, NULL, NULL, '2026-03-20T00:00:00Z', NULL, NULL, NULL)
                    """,
                    (f"run_{photo_id}", f"imp_{photo_id}"),
                )
                connection.execute(
                    """
                    INSERT INTO photo_path_observation(photo_id, path_text, first_seen_run_id, created_at)
                    VALUES (?, ?, ?, '2026-03-20T00:00:00Z')
                    """,
                    (photo_id, path_text, f"run_{photo_id}"),
                )
            connection.commit()

        result = service.backfill_duplicate_semantics()
        self.assertTrue(result["ok"])
        self.assertEqual(result["replay_mode"], "incremental")
        self.assertEqual(result["duplicate_rows"], 1)
        self.assertEqual(result["primary_rows"], 1)

        with sqlite3.connect(service.paths.database) as connection:
            connection.row_factory = sqlite3.Row
            rows = connection.execute(
                """
                SELECT photo_id, duplicate_role, duplicate_reason
                FROM photo_duplicate_semantic
                ORDER BY photo_id
                """
            ).fetchall()
        self.assertEqual(len(rows), 2)
        self.assertEqual({row["duplicate_reason"] for row in rows}, {"export_variant"})
        roles = {row["photo_id"]: row["duplicate_role"] for row in rows}
        self.assertEqual(roles["pho_master"], "primary")
        self.assertEqual(roles["pho_preview"], "duplicate")

    def test_gateway_photo_memory_query_excludes_marked_duplicates_by_default(self) -> None:
        service = GatewayService()
        with sqlite3.connect(service.paths.database) as connection:
            for suffix in ("HEIC", "jpeg"):
                content_id = f"content-{suffix.lower()}"
                photo_id = f"pho_{suffix.lower()}"
                connection.execute(
                    """
                    INSERT INTO content(
                        content_id, canonical_spec_version, storage_relpath, mime_type, byte_size, width, height, created_at
                    ) VALUES (?, 1, ?, 'image/jpeg', 123, 10, 10, '2026-03-20T00:00:00Z')
                    """,
                    (content_id, f"content/test/{content_id}.jpg"),
                )
                connection.execute(
                    """
                    INSERT INTO photo(
                        photo_id, content_id, photo_signature, photo_signature_version, signature_payload_json,
                        taken_at_utc, taken_at_original, raw_latitude, raw_longitude, raw_altitude,
                        cadis_result_json, cadis_version, location_detail,
                        camera_make, camera_model, created_at
                    ) VALUES (?, ?, ?, 1, '{}', ?, ?, NULL, NULL, NULL, NULL, NULL, NULL, ?, ?, '2026-03-20T00:00:00Z')
                    """,
                    (
                        photo_id,
                        content_id,
                        f"sig-{suffix}",
                        "2024-09-13T10:00:00Z",
                        "2024:09:13 18:00:00",
                        "Apple",
                        "iPhone 11",
                    ),
                )
                connection.execute(
                    """
                    INSERT INTO import_run(
                        run_id, source_import_id, status, current_stage, progress, started_at, completed_at, created_at, error_code, error_message, report_json
                    ) VALUES (?, ?, 'complete', NULL, 1.0, NULL, NULL, '2026-03-20T00:00:00Z', NULL, NULL, NULL)
                    """,
                    (f"run_{suffix.lower()}", f"imp_{suffix.lower()}"),
                )
                connection.execute(
                    """
                    INSERT INTO photo_path_observation(photo_id, path_text, first_seen_run_id, created_at)
                    VALUES (?, ?, ?, '2026-03-20T00:00:00Z')
                    """,
                    (
                        photo_id,
                        f"2026.03.21 Mac Photos Backup/2024年9月13日, Oslo/IMG_9560.{suffix}",
                        f"run_{suffix.lower()}",
                    ),
                )
            connection.commit()

        service.backfill_duplicate_semantics()
        payload = service.query_photo_memory(
            {
                "query_version": 1,
                "anchor": {"entity": "photo"},
                "select": [{"entity": "photo", "attribute": "id", "aggregation": "count"}],
                "filters": [{"entity": "camera", "attribute": "model", "operator": "==", "value": "iPhone 11"}],
                "limit": 20,
            }
        )
        self.assertEqual(payload["rows"], [{"photo_count": 1}])

    def test_gateway_backfill_duplicate_semantics_marks_burst_time_gps_clusters(self) -> None:
        service = GatewayService()
        with sqlite3.connect(service.paths.database) as connection:
            for index, second in enumerate((0, 2, 3), start=1):
                content_id = f"content-burst-{index}"
                photo_id = f"pho_burst_{index}"
                connection.execute(
                    """
                    INSERT INTO content(
                        content_id, canonical_spec_version, storage_relpath, mime_type, byte_size, width, height, created_at
                    ) VALUES (?, 1, ?, 'image/jpeg', 123, 10, 10, '2026-03-20T00:00:00Z')
                    """,
                    (content_id, f"content/test/{content_id}.jpg"),
                )
                connection.execute(
                    """
                    INSERT INTO photo(
                        photo_id, content_id, photo_signature, photo_signature_version, signature_payload_json,
                        taken_at_utc, taken_at_original, raw_latitude, raw_longitude, raw_altitude,
                        cadis_result_json, cadis_version, location_detail,
                        camera_make, camera_model, created_at
                    ) VALUES (?, ?, ?, 1, '{}', ?, ?, ?, ?, NULL, NULL, NULL, NULL, ?, ?, '2026-03-20T00:00:00Z')
                    """,
                    (
                        photo_id,
                        content_id,
                        f"sig-burst-{index}",
                        f"2024-09-13T10:00:0{second}Z",
                        f"2024:09:13 18:00:0{second}",
                        59.9139,
                        10.7522,
                        "Apple",
                        "iPhone 11",
                    ),
                )
                connection.execute(
                    """
                    INSERT INTO import_run(
                        run_id, source_import_id, status, current_stage, progress, started_at, completed_at, created_at, error_code, error_message, report_json
                    ) VALUES (?, ?, 'complete', NULL, 1.0, NULL, NULL, '2026-03-20T00:00:00Z', NULL, NULL, NULL)
                    """,
                    (f"run_burst_{index}", f"imp_burst_{index}"),
                )
                connection.execute(
                    """
                    INSERT INTO photo_path_observation(photo_id, path_text, first_seen_run_id, created_at)
                    VALUES (?, ?, ?, '2026-03-20T00:00:00Z')
                    """,
                    (
                        photo_id,
                        f"2026.03.21 Mac Photos Backup/2024年9月13日, Oslo/IMG_{9600 + index}.HEIC",
                        f"run_burst_{index}",
                    ),
                )
            connection.commit()

        result = service.backfill_duplicate_semantics()
        self.assertTrue(result["ok"])
        self.assertEqual(result["replay_mode"], "incremental")
        self.assertGreaterEqual(result["duplicate_rows"], 2)

        with sqlite3.connect(service.paths.database) as connection:
            connection.row_factory = sqlite3.Row
            rows = connection.execute(
                """
                SELECT photo_id, duplicate_cluster_id, duplicate_role, duplicate_reason
                FROM photo_duplicate_semantic
                WHERE photo_id IN ('pho_burst_1', 'pho_burst_2', 'pho_burst_3')
                ORDER BY photo_id
                """
            ).fetchall()
        self.assertEqual(len(rows), 3)
        self.assertEqual({row["duplicate_reason"] for row in rows}, {"burst_time_gps"})
        self.assertEqual({row["duplicate_cluster_id"] for row in rows}.__len__(), 1)
        self.assertEqual({row["duplicate_role"] for row in rows}, {"primary", "duplicate"})

    def test_gateway_backfill_duplicate_semantics_accepts_fractional_taken_at_original(self) -> None:
        service = GatewayService()
        with sqlite3.connect(service.paths.database) as connection:
            for index, taken_at_original in enumerate(
                (
                    "2016:01:03 15:38:45.844",
                    "2016:01:03 15:38:46.111",
                    "2016:01:03 15:38:46.277",
                ),
                start=1,
            ):
                content_id = f"content-fractional-{index}"
                photo_id = f"pho_fractional_{index}"
                connection.execute(
                    """
                    INSERT INTO content(
                        content_id, canonical_spec_version, storage_relpath, mime_type, byte_size, width, height, created_at
                    ) VALUES (?, 1, ?, 'image/jpeg', 123, 10, 10, '2026-03-20T00:00:00Z')
                    """,
                    (content_id, f"content/test/{content_id}.jpg"),
                )
                connection.execute(
                    """
                    INSERT INTO photo(
                        photo_id, content_id, photo_signature, photo_signature_version, signature_payload_json,
                        taken_at_utc, taken_at_original, raw_latitude, raw_longitude, raw_altitude,
                        cadis_result_json, cadis_version, location_detail,
                        camera_make, camera_model, created_at
                    ) VALUES (?, ?, ?, 1, '{}', NULL, ?, ?, ?, NULL, NULL, NULL, NULL, ?, ?, '2026-03-20T00:00:00Z')
                    """,
                    (
                        photo_id,
                        content_id,
                        f"sig-fractional-{index}",
                        taken_at_original,
                        24.3881444444444,
                        120.778686111111,
                        "Apple",
                        "iPhone 6 Plus",
                    ),
                )
                connection.execute(
                    """
                    INSERT INTO import_run(
                        run_id, source_import_id, status, current_stage, progress, started_at, completed_at, created_at, error_code, error_message, report_json
                    ) VALUES (?, ?, 'complete', NULL, 1.0, NULL, NULL, '2026-03-20T00:00:00Z', NULL, NULL, NULL)
                    """,
                    (f"run_fractional_{index}", f"imp_fractional_{index}"),
                )
                connection.execute(
                    """
                    INSERT INTO photo_path_observation(photo_id, path_text, first_seen_run_id, created_at)
                    VALUES (?, ?, ?, '2026-03-20T00:00:00Z')
                    """,
                    (
                        photo_id,
                        f"iPhoto9/Masters/2016/07/04/20160704-141423/IMG_30{index:02d}.JPG",
                        f"run_fractional_{index}",
                    ),
                )
            connection.commit()

        result = service.backfill_duplicate_semantics()
        self.assertTrue(result["ok"])
        self.assertEqual(result["replay_mode"], "incremental")
        self.assertGreaterEqual(result["duplicate_rows"], 2)

    def test_gateway_backfill_duplicate_semantics_accepts_full_replay_mode(self) -> None:
        service = GatewayService()
        with sqlite3.connect(service.paths.database) as connection:
            for suffix in ("HEIC", "jpeg"):
                content_id = f"content-full-{suffix.lower()}"
                photo_id = f"pho_full_{suffix.lower()}"
                connection.execute(
                    """
                    INSERT INTO content(
                        content_id, canonical_spec_version, storage_relpath, mime_type, byte_size, width, height, created_at
                    ) VALUES (?, 1, ?, 'image/jpeg', 123, 10, 10, '2026-03-20T00:00:00Z')
                    """,
                    (content_id, f"content/test/{content_id}.jpg"),
                )
                connection.execute(
                    """
                    INSERT INTO photo(
                        photo_id, content_id, photo_signature, photo_signature_version, signature_payload_json,
                        taken_at_utc, taken_at_original, raw_latitude, raw_longitude, raw_altitude,
                        cadis_result_json, cadis_version, location_detail,
                        camera_make, camera_model, created_at
                    ) VALUES (?, ?, ?, 1, '{}', ?, ?, NULL, NULL, NULL, NULL, NULL, NULL, ?, ?, '2026-03-20T00:00:00Z')
                    """,
                    (
                        photo_id,
                        content_id,
                        f"sig-full-{suffix}",
                        "2024-09-13T10:00:00Z",
                        "2024:09:13 18:00:00",
                        "Apple",
                        "iPhone 11",
                    ),
                )
                connection.execute(
                    """
                    INSERT INTO import_run(
                        run_id, source_import_id, status, current_stage, progress, started_at, completed_at, created_at, error_code, error_message, report_json
                    ) VALUES (?, ?, 'complete', NULL, 1.0, NULL, NULL, '2026-03-20T00:00:00Z', NULL, NULL, NULL)
                    """,
                    (f"run_full_{suffix.lower()}", f"imp_full_{suffix.lower()}"),
                )
                connection.execute(
                    """
                    INSERT INTO photo_path_observation(photo_id, path_text, first_seen_run_id, created_at)
                    VALUES (?, ?, ?, '2026-03-20T00:00:00Z')
                    """,
                    (
                        photo_id,
                        f"2026.03.21 Mac Photos Backup/2024年9月13日, Oslo/IMG_9560.{suffix}",
                        f"run_full_{suffix.lower()}",
                    ),
                )
            connection.commit()

        result = service.backfill_duplicate_semantics(replay_mode="full_replay")
        self.assertTrue(result["ok"])
        self.assertEqual(result["replay_mode"], "full_replay")

    def test_gateway_backfill_duplicate_semantics_rejects_unknown_replay_mode(self) -> None:
        service = GatewayService()
        with self.assertRaises(GatewayServiceError) as exc:
            service.backfill_duplicate_semantics(replay_mode="unknown")
        self.assertEqual(exc.exception.error_code, "UNSUPPORTED_REPLAY_MODE")

    def test_gateway_backfill_tags_persists_has_people_values(self) -> None:
        service = GatewayService()
        with sqlite3.connect(service.paths.database) as connection:
            for photo_id, content_id in (("pho_tag_1", "content-tag-1"), ("pho_tag_2", "content-tag-2")):
                storage_relpath = f"content/test/{content_id}.jpg"
                connection.execute(
                    """
                    INSERT INTO content(
                        content_id, canonical_spec_version, storage_relpath, mime_type, byte_size, width, height, created_at
                    ) VALUES (?, 1, ?, 'image/jpeg', 4, 10, 10, '2026-03-20T00:00:00Z')
                    """,
                    (content_id, storage_relpath),
                )
                content_path = service.paths.root / storage_relpath
                content_path.parent.mkdir(parents=True, exist_ok=True)
                content_path.write_bytes(b"jpeg")
                connection.execute(
                    """
                    INSERT INTO photo(
                        photo_id, content_id, photo_signature, photo_signature_version, signature_payload_json,
                        taken_at_utc, taken_at_original, raw_latitude, raw_longitude, raw_altitude,
                        cadis_result_json, cadis_version, location_detail,
                        camera_make, camera_model, created_at
                    ) VALUES (?, ?, ?, 1, '{}', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2026-03-20T00:00:00Z')
                    """,
                    (photo_id, content_id, f"sig-{photo_id}"),
                )
            connection.commit()

        class _FakeDetector:
            def detect_face_count(self, image_path: Path) -> int:
                return 1 if image_path.name == "content-tag-1.jpg" else 0

        result = service.backfill_tags(tag="has_people", detector=_FakeDetector())
        self.assertTrue(result["ok"])
        self.assertEqual(result["tag"], "has_people")
        self.assertEqual(result["replay_mode"], "incremental")
        self.assertEqual(result["scanned"], 2)
        self.assertEqual(result["updated"], 2)

        with sqlite3.connect(service.paths.database) as connection:
            rows = connection.execute(
                """
                SELECT photo_id, tag_key, tag_value, tag_source, semantic_version
                FROM photo_tag_semantic
                ORDER BY photo_id, tag_key
                """
            ).fetchall()
        self.assertEqual(
            rows,
            [
                ("pho_tag_1", "face_count", "1", "opencv_yunet_face_detector", 1),
                ("pho_tag_1", "has_people", "true", "opencv_yunet_face_detector", 1),
                ("pho_tag_2", "face_count", "0", "opencv_yunet_face_detector", 1),
                ("pho_tag_2", "has_people", "false", "opencv_yunet_face_detector", 1),
            ],
        )
        with sqlite3.connect(service.paths.database) as connection:
            job = connection.execute(
                """
                SELECT job_name, semantic_version, status, total_rows, processed_rows, updated_rows, failed_rows
                FROM semantic_enrichment_job
                WHERE job_name = 'has_people'
                """
            ).fetchone()
        self.assertEqual(job, ("has_people", 1, "completed", 2, 2, 2, 0))

    def test_gateway_backfill_tags_incremental_only_processes_missing_current_rows(self) -> None:
        service = GatewayService()
        with sqlite3.connect(service.paths.database) as connection:
            for photo_id, content_id in (("pho_tag_1", "content-tag-1"), ("pho_tag_2", "content-tag-2")):
                storage_relpath = f"content/test/{content_id}.jpg"
                connection.execute(
                    """
                    INSERT INTO content(
                        content_id, canonical_spec_version, storage_relpath, mime_type, byte_size, width, height, created_at
                    ) VALUES (?, 1, ?, 'image/jpeg', 4, 10, 10, '2026-03-20T00:00:00Z')
                    """,
                    (content_id, storage_relpath),
                )
                content_path = service.paths.root / storage_relpath
                content_path.parent.mkdir(parents=True, exist_ok=True)
                content_path.write_bytes(b"jpeg")
                connection.execute(
                    """
                    INSERT INTO photo(
                        photo_id, content_id, photo_signature, photo_signature_version, signature_payload_json,
                        taken_at_utc, taken_at_original, raw_latitude, raw_longitude, raw_altitude,
                        cadis_result_json, cadis_version, location_detail,
                        camera_make, camera_model, created_at
                    ) VALUES (?, ?, ?, 1, '{}', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2026-03-20T00:00:00Z')
                    """,
                    (photo_id, content_id, f"sig-{photo_id}"),
                )
            connection.execute(
                """
                INSERT INTO photo_tag_semantic(
                    photo_id, tag_key, tag_value, tag_source, tag_strength, semantic_version, computed_at
                ) VALUES
                    ('pho_tag_1', 'has_people', 'true', 'opencv_yunet_face_detector', NULL, 1, '2026-03-20T00:00:00Z'),
                    ('pho_tag_1', 'face_count', '1', 'opencv_yunet_face_detector', NULL, 1, '2026-03-20T00:00:00Z')
                """
            )
            connection.commit()

        class _FakeDetector:
            def detect_face_count(self, image_path: Path) -> int:
                if image_path.name == "content-tag-1.jpg":
                    raise AssertionError("incremental mode should skip already-tagged photo")
                return 0

        result = service.backfill_tags(tag="has_people", replay_mode="incremental", detector=_FakeDetector())
        self.assertTrue(result["ok"])
        self.assertEqual(result["replay_mode"], "incremental")
        self.assertEqual(result["scanned"], 1)
        self.assertEqual(result["updated"], 1)

    def test_gateway_backfill_tags_full_replay_reprocesses_existing_rows(self) -> None:
        service = GatewayService()
        with sqlite3.connect(service.paths.database) as connection:
            for photo_id, content_id in (("pho_tag_1", "content-tag-1"), ("pho_tag_2", "content-tag-2")):
                storage_relpath = f"content/test/{content_id}.jpg"
                connection.execute(
                    """
                    INSERT INTO content(
                        content_id, canonical_spec_version, storage_relpath, mime_type, byte_size, width, height, created_at
                    ) VALUES (?, 1, ?, 'image/jpeg', 4, 10, 10, '2026-03-20T00:00:00Z')
                    """,
                    (content_id, storage_relpath),
                )
                content_path = service.paths.root / storage_relpath
                content_path.parent.mkdir(parents=True, exist_ok=True)
                content_path.write_bytes(b"jpeg")
                connection.execute(
                    """
                    INSERT INTO photo(
                        photo_id, content_id, photo_signature, photo_signature_version, signature_payload_json,
                        taken_at_utc, taken_at_original, raw_latitude, raw_longitude, raw_altitude,
                        cadis_result_json, cadis_version, location_detail,
                        camera_make, camera_model, created_at
                    ) VALUES (?, ?, ?, 1, '{}', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2026-03-20T00:00:00Z')
                    """,
                    (photo_id, content_id, f"sig-{photo_id}"),
                )
            connection.execute(
                """
                INSERT INTO photo_tag_semantic(
                    photo_id, tag_key, tag_value, tag_source, tag_strength, semantic_version, computed_at
                ) VALUES
                    ('pho_tag_1', 'has_people', 'false', 'legacy_detector', NULL, 0, '2026-03-20T00:00:00Z'),
                    ('pho_tag_1', 'face_count', '0', 'legacy_detector', NULL, 0, '2026-03-20T00:00:00Z')
                """
            )
            connection.commit()

        calls: list[str] = []

        class _FakeDetector:
            def detect_face_count(self, image_path: Path) -> int:
                calls.append(image_path.name)
                return 1 if image_path.name == "content-tag-1.jpg" else 0

        result = service.backfill_tags(tag="has_people", replay_mode="full_replay", detector=_FakeDetector())
        self.assertTrue(result["ok"])
        self.assertEqual(result["replay_mode"], "full_replay")
        self.assertEqual(result["scanned"], 2)
        self.assertEqual(sorted(calls), ["content-tag-1.jpg", "content-tag-2.jpg"])

    def test_gateway_backfill_tags_rejects_face_count_as_standalone_tag(self) -> None:
        service = GatewayService()
        with self.assertRaises(GatewayServiceError) as exc:
            service.backfill_tags(tag="face_count")
        self.assertEqual(exc.exception.error_code, "UNSUPPORTED_TAG")

    def test_gateway_backfill_tags_rejects_unknown_replay_mode(self) -> None:
        service = GatewayService()
        with self.assertRaises(GatewayServiceError) as exc:
            service.backfill_tags(tag="has_people", replay_mode="unknown")
        self.assertEqual(exc.exception.error_code, "UNSUPPORTED_REPLAY_MODE")

    def test_resolve_opencv_face_model_path_prefers_repo_artifact(self) -> None:
        from eona import gateway_service as gateway_service_module

        resolved = gateway_service_module._resolve_opencv_face_model_path()
        self.assertEqual(
            resolved,
            Path(__file__).resolve().parents[1] / "artifacts" / "opencv" / "common" / "face_detection_yunet_2023mar.onnx",
        )
        self.assertTrue(resolved.is_file())

    def test_gateway_backfill_tags_rejects_unknown_tag(self) -> None:
        service = GatewayService()
        with self.assertRaisesRegex(Exception, "Unsupported tag `unknown_tag`"):
            service.backfill_tags(tag="unknown_tag")

    def test_gateway_photo_memory_query_excludes_burst_time_gps_duplicates_by_default(self) -> None:
        service = GatewayService()
        with sqlite3.connect(service.paths.database) as connection:
            for index, second in enumerate((0, 2, 3), start=1):
                content_id = f"content-burst-{index}"
                photo_id = f"pho_burst_{index}"
                connection.execute(
                    """
                    INSERT INTO content(
                        content_id, canonical_spec_version, storage_relpath, mime_type, byte_size, width, height, created_at
                    ) VALUES (?, 1, ?, 'image/jpeg', 123, 10, 10, '2026-03-20T00:00:00Z')
                    """,
                    (content_id, f"content/test/{content_id}.jpg"),
                )
                connection.execute(
                    """
                    INSERT INTO photo(
                        photo_id, content_id, photo_signature, photo_signature_version, signature_payload_json,
                        taken_at_utc, taken_at_original, raw_latitude, raw_longitude, raw_altitude,
                        cadis_result_json, cadis_version, location_detail,
                        camera_make, camera_model, created_at
                    ) VALUES (?, ?, ?, 1, '{}', ?, ?, ?, ?, NULL, NULL, NULL, NULL, ?, ?, '2026-03-20T00:00:00Z')
                    """,
                    (
                        photo_id,
                        content_id,
                        f"sig-burst-{index}",
                        f"2024-09-13T10:00:0{second}Z",
                        f"2024:09:13 18:00:0{second}",
                        59.9139,
                        10.7522,
                        "Apple",
                        "iPhone 11",
                    ),
                )
                connection.execute(
                    """
                    INSERT INTO import_run(
                        run_id, source_import_id, status, current_stage, progress, started_at, completed_at, created_at, error_code, error_message, report_json
                    ) VALUES (?, ?, 'complete', NULL, 1.0, NULL, NULL, '2026-03-20T00:00:00Z', NULL, NULL, NULL)
                    """,
                    (f"run_burst_{index}", f"imp_burst_{index}"),
                )
                connection.execute(
                    """
                    INSERT INTO photo_path_observation(photo_id, path_text, first_seen_run_id, created_at)
                    VALUES (?, ?, ?, '2026-03-20T00:00:00Z')
                    """,
                    (
                        photo_id,
                        f"2026.03.21 Mac Photos Backup/2024年9月13日, Oslo/IMG_{9600 + index}.HEIC",
                        f"run_burst_{index}",
                    ),
                )
            connection.commit()

        service.backfill_duplicate_semantics()
        payload = service.query_photo_memory(
            {
                "query_version": 1,
                "anchor": {"entity": "photo"},
                "select": [{"entity": "photo", "attribute": "id", "aggregation": "count"}],
                "filters": [{"entity": "camera", "attribute": "model", "operator": "==", "value": "iPhone 11"}],
                "limit": 20,
            }
        )
        self.assertEqual(payload["rows"], [{"photo_count": 1}])

    def test_gateway_photo_memory_query_exposes_taken_at_original_in_photo_metadata(self) -> None:
        service = GatewayService()
        with sqlite3.connect(service.paths.database) as connection:
            connection.execute(
                """
                INSERT INTO content(
                    content_id, canonical_spec_version, storage_relpath, mime_type, byte_size, width, height, created_at
                ) VALUES (?, 1, ?, 'image/jpeg', 123, 10, 10, '2026-03-20T00:00:00Z')
                """,
                ("content-a", "content/aa/bb/content-a.jpg"),
            )
            connection.execute(
                """
                INSERT INTO photo(
                    photo_id, content_id, photo_signature, photo_signature_version, signature_payload_json,
                    taken_at_utc, taken_at_original, raw_latitude, raw_longitude, raw_altitude,
                    cadis_result_json, cadis_version, location_detail,
                    camera_make, camera_model, created_at
                ) VALUES (?, ?, ?, 1, '{}', NULL, ?, NULL, NULL, NULL, ?, ?, ?, NULL, NULL, '2026-03-20T00:00:00Z')
                """,
                (
                    "pho_001",
                    "content-a",
                    "sig-a",
                    "2024:09:15 14:10:00",
                    json.dumps(
                        {
                            "state": {"world": {"iso2": "JP", "name": "Japan"}},
                            "result": {
                                "country": {"name": "Japan"},
                                "admin_hierarchy": [{"name": "京都府"}, {"name": "京都市"}],
                            },
                        }
                    ),
                    "0.3.0",
                    "ok",
                ),
            )
            connection.commit()

        payload = service.get_photo_metadata("pho_001")
        self.assertEqual(payload["taken_at_utc"], None)
        self.assertEqual(payload["taken_at_original"], "2024:09:15 14:10:00")
        self.assertEqual(payload["cadis_result_json"]["state"]["world"]["iso2"], "JP")
        self.assertEqual(payload["cadis_version"], "0.3.0")
        self.assertEqual(payload["location_detail"], "ok")

    def test_gateway_photo_memory_query_rejects_invalid_plan(self) -> None:
        service = GatewayService()
        with self.assertRaisesRegex(Exception, "Unsupported entity `trip`"):
            service.query_photo_memory(
                {
                    "query_version": 1,
                    "anchor": {"entity": "photo"},
                    "select": [{"entity": "trip", "attribute": "country"}],
                }
            )

    def test_gateway_photo_memory_query_clamps_limit(self) -> None:
        service = GatewayService()
        with sqlite3.connect(service.paths.database) as connection:
            for index in range(60):
                content_id = f"content-{index:03d}"
                photo_id = f"pho_{index:03d}"
                connection.execute(
                    """
                    INSERT INTO content(
                        content_id, canonical_spec_version, storage_relpath, mime_type, byte_size, width, height, created_at
                    ) VALUES (?, 1, ?, 'image/jpeg', 123, 10, 10, '2026-03-20T00:00:00Z')
                    """,
                    (content_id, f"content/test/{content_id}.jpg"),
                )
                connection.execute(
                    """
                    INSERT INTO photo(
                        photo_id, content_id, photo_signature, photo_signature_version, signature_payload_json,
                        taken_at_utc, taken_at_original, raw_latitude, raw_longitude, raw_altitude,
                        cadis_result_json, cadis_version, location_detail,
                        camera_make, camera_model, created_at
                    ) VALUES (?, ?, ?, 1, '{}', ?, ?, NULL, NULL, NULL, NULL, NULL, NULL, ?, ?, '2026-03-20T00:00:00Z')
                    """,
                    (
                        photo_id,
                        content_id,
                        f"sig-{index:03d}",
                        "2025-01-01T00:00:00Z",
                        "2025:01:01 08:00:00",
                        "Apple",
                        f"model-{index:03d}",
                    ),
                )
            connection.commit()

        payload = service.query_photo_memory(
            {
                "query_version": 1,
                "anchor": {"entity": "camera"},
                "select": [{"entity": "camera", "attribute": "model"}],
                "sort_by": [{"entity": "camera", "attribute": "model", "order": "asc"}],
                "limit": 500,
            }
        )

        self.assertEqual(payload["resolved_plan"]["limit"], 50)
        self.assertEqual(payload["row_count"], 50)

    def test_gateway_photo_memory_query_rejects_oversized_response(self) -> None:
        service = GatewayService()
        with sqlite3.connect(service.paths.database) as connection:
            connection.execute(
                """
                INSERT INTO content(
                    content_id, canonical_spec_version, storage_relpath, mime_type, byte_size, width, height, created_at
                ) VALUES (?, 1, ?, 'image/jpeg', 123, 10, 10, '2026-03-20T00:00:00Z')
                """,
                ("content-a", "content/test/content-a.jpg"),
            )
            connection.execute(
                """
                INSERT INTO photo(
                    photo_id, content_id, photo_signature, photo_signature_version, signature_payload_json,
                    taken_at_utc, taken_at_original, raw_latitude, raw_longitude, raw_altitude,
                    cadis_result_json, cadis_version, location_detail,
                    camera_make, camera_model, created_at
                ) VALUES (?, ?, ?, 1, '{}', ?, ?, NULL, NULL, NULL, NULL, NULL, NULL, ?, ?, '2026-03-20T00:00:00Z')
                """,
                (
                    "pho_001",
                    "content-a",
                    "sig-a",
                    "2025-01-01T00:00:00Z",
                    "2025:01:01 08:00:00",
                    "Apple",
                    "X" * 400,
                ),
            )
            connection.commit()

        with mock.patch("eona.gateway_service.MAX_PHOTO_MEMORY_RESPONSE_BYTES", 150):
            with self.assertRaisesRegex(Exception, "too large to return safely"):
                service.query_photo_memory(
                    {
                        "query_version": 1,
                        "anchor": {"entity": "camera"},
                        "select": [{"entity": "camera", "attribute": "model"}],
                        "limit": 20,
                    }
                )

    def test_gateway_photo_memory_query_hostile_input_does_not_escape_parameterization(self) -> None:
        service = GatewayService()
        with sqlite3.connect(service.paths.database) as connection:
            connection.execute(
                """
                INSERT INTO content(
                    content_id, canonical_spec_version, storage_relpath, mime_type, byte_size, width, height, created_at
                ) VALUES (?, 1, ?, 'image/jpeg', 123, 10, 10, '2026-03-20T00:00:00Z')
                """,
                ("content-a", "content/test/content-a.jpg"),
            )
            connection.execute(
                """
                INSERT INTO photo(
                    photo_id, content_id, photo_signature, photo_signature_version, signature_payload_json,
                    taken_at_utc, taken_at_original, raw_latitude, raw_longitude, raw_altitude,
                    cadis_result_json, cadis_version, location_detail,
                    camera_make, camera_model, created_at
                ) VALUES (?, ?, ?, 1, '{}', ?, ?, NULL, NULL, NULL, NULL, NULL, NULL, ?, ?, '2026-03-20T00:00:00Z')
                """,
                (
                    "pho_001",
                    "content-a",
                    "sig-a",
                    "2025-01-01T00:00:00Z",
                    "2025:01:01 08:00:00",
                    "Apple",
                    "SafeCamera",
                ),
            )
            connection.execute(
                """
                INSERT INTO import_run(
                    run_id, source_import_id, status, current_stage, progress, started_at, completed_at, created_at, error_code, error_message, report_json
                ) VALUES (?, ?, 'complete', NULL, 1.0, NULL, NULL, '2026-03-20T00:00:00Z', NULL, NULL, NULL)
                """,
                ("run_001", "imp_001"),
            )
            connection.execute(
                """
                INSERT INTO photo_path_observation(photo_id, path_text, first_seen_run_id, created_at)
                VALUES (?, ?, ?, '2026-03-20T00:00:00Z')
                """,
                ("pho_001", "/photos/normal/IMG_0001.JPG", "run_001"),
            )
            connection.commit()

        payload = service.query_photo_memory(
            {
                "query_version": 1,
                "anchor": {"entity": "photo"},
                "select": [{"entity": "photo", "attribute": "id", "aggregation": "count"}],
                "filters": [{"entity": "path", "attribute": "text", "operator": "contains", "value": "' OR 1=1 --"}],
                "limit": 10,
            }
        )

        self.assertEqual(payload["rows"], [{"photo_count": 0}])
        with sqlite3.connect(service.paths.database) as connection:
            still_exists = connection.execute(
                "SELECT COUNT(*) FROM photo WHERE photo_id = ?",
                ("pho_001",),
            ).fetchone()[0]
        self.assertEqual(still_exists, 1)

    def test_gateway_commit_is_idempotent(self) -> None:
        service = GatewayService()
        session = service.create_import_session()
        import_id = str(session["import_id"])
        service.stage_import_file(
            import_id=import_id,
            client_filename="sample.jpg",
            content=b"content-a",
            path_hint="/photos/sample.jpg",
        )
        first = service.commit_import_session(import_id)
        second = service.commit_import_session(import_id)
        self.assertEqual(first["run_id"], second["run_id"])
        self.assertEqual(second["status"], "committed")

    def test_gateway_accepts_heic_imports_before_commit(self) -> None:
        service = GatewayService()
        session = service.create_import_session()
        staged = service.stage_import_file(
            import_id=str(session["import_id"]),
            client_filename="sample.HEIC",
            content=b"heic-bytes",
            path_hint="/photos/sample.HEIC",
        )
        self.assertEqual(staged["status"], "staged")

    def test_gateway_rejects_non_jpeg_imports_before_commit(self) -> None:
        service = GatewayService()
        session = service.create_import_session()
        with self.assertRaisesRegex(Exception, "Gateway currently accepts JPEG/HEIC"):
            service.stage_import_file(
                import_id=str(session["import_id"]),
                client_filename="sample.png",
                content=b"png-bytes",
                path_hint="/photos/sample.png",
            )

    def test_gateway_collect_import_path_snapshots_supported_files(self) -> None:
        service = GatewayService()
        session = service.create_import_session()
        import_id = str(session["import_id"])
        mount_root = Path(self.temp_dir.name) / "mount-source"
        (mount_root / "nested").mkdir(parents=True, exist_ok=True)
        (mount_root / "visible.jpg").write_bytes(b"jpg")
        (mount_root / "nested" / "keep.HEIC").write_bytes(b"heic")
        (mount_root / ".hidden.jpg").write_bytes(b"hidden")
        (mount_root / "skip.txt").write_text("skip", encoding="utf-8")
        os.symlink(mount_root / "visible.jpg", mount_root / "visible-link.jpg")

        collected = service.collect_import_path(import_id=import_id, source_path=str(mount_root.resolve()))

        self.assertEqual(collected["collected_count"], 2)
        self.assertEqual(collected["error_count"], 1)
        self.assertEqual(collected["file_count"], 2)
        self.assertEqual(collected["errors"][0]["error_code"], "IMPORT_PATH_SYMLINK_UNSUPPORTED")

        refreshed = service.get_import_session(import_id)
        self.assertEqual(refreshed["file_count"], 2)

        run_id = str(service.commit_import_session(import_id)["run_id"])
        manifest = service.seal_run_input(run_id)
        self.assertEqual([item["client_filename"] for item in manifest["items"]], ["keep.HEIC", "visible.jpg"])
        self.assertTrue(all(item["input_path"].startswith("/") for item in manifest["items"]))
        self.assertTrue(all(item["path_hint"].startswith("/") for item in manifest["items"]))
        self.assertTrue(all(item["input_relpath"] is None for item in manifest["items"]))

    def test_gateway_collect_import_path_rejects_non_absolute_input(self) -> None:
        service = GatewayService()
        session = service.create_import_session()
        with self.assertRaisesRegex(Exception, "must be absolute"):
            service.collect_import_path(import_id=str(session["import_id"]), source_path="relative/photos")

    def test_gateway_collect_import_path_reports_unreadable_files(self) -> None:
        service = GatewayService()
        session = service.create_import_session()
        import_id = str(session["import_id"])
        mount_root = Path(self.temp_dir.name) / "mount-unreadable"
        mount_root.mkdir(parents=True, exist_ok=True)
        good = mount_root / "good.jpg"
        bad = mount_root / "bad.jpg"
        good.write_bytes(b"good")
        bad.write_bytes(b"bad")
        original_open = Path.open

        def fake_open(path_obj: Path, *args, **kwargs):
            if path_obj.resolve() == bad.resolve():
                raise PermissionError("denied")
            return original_open(path_obj, *args, **kwargs)

        with mock.patch("pathlib.Path.open", autospec=True, side_effect=fake_open):
            collected = service.collect_import_path(import_id=import_id, source_path=str(mount_root.resolve()))

        self.assertEqual(collected["collected_count"], 1)
        self.assertEqual(collected["error_count"], 1)
        self.assertEqual(collected["errors"][0]["error_code"], "IMPORT_FILE_UNREADABLE")
        self.assertEqual(service.get_import_session(import_id)["file_count"], 1)

    def test_gateway_create_import_session_reports_storage_budget(self) -> None:
        service = GatewayService()
        with mock.patch("eona.gateway_service.shutil.disk_usage", return_value=mock.Mock(total=1000, used=400, free=600)):
            session = service.create_import_session()
        self.assertEqual(session["storage"]["free_bytes"], 600)
        self.assertEqual(session["storage"]["available_import_bytes"], 0)
        self.assertEqual(session["storage"]["min_free_bytes"], 2 * 1024 * 1024 * 1024)

    def test_gateway_marks_import_failed_when_storage_budget_is_exhausted(self) -> None:
        service = GatewayService()
        session = service.create_import_session()
        import_id = str(session["import_id"])
        with mock.patch("eona.gateway_service.shutil.disk_usage", return_value=mock.Mock(total=1000, used=800, free=200)):
            with self.assertRaisesRegex(Exception, "Gateway storage is too full for this import"):
                service.stage_import_file(
                    import_id=import_id,
                    client_filename="sample.jpg",
                    content=b"123456",
                    path_hint="/photos/sample.jpg",
                )
        refreshed = service.get_import_session(import_id)
        self.assertEqual(refreshed["status"], "failed")
        self.assertEqual(refreshed["error_code"], "IMPORT_STORAGE_EXHAUSTED")

    def test_gateway_cleanup_abandoned_import_sessions_removes_stale_session(self) -> None:
        service = GatewayService()
        stale = service.create_import_session()
        stale_id = str(stale["import_id"])
        service.stage_import_file(
            import_id=stale_id,
            client_filename="sample.jpg",
            content=b"abc",
            path_hint="/photos/sample.jpg",
        )
        session_dir = service.paths.import_sessions_dir / stale_id
        self.assertTrue(session_dir.is_dir())
        with sqlite3.connect(service.paths.database) as connection:
            connection.execute(
                "UPDATE import_session SET updated_at = '2026-03-18T00:00:00Z' WHERE import_id = ?",
                (stale_id,),
            )
            connection.commit()

        result = service.cleanup_abandoned_import_sessions(older_than_hours=24.0)
        self.assertEqual(result["removed_count"], 1)
        self.assertEqual(result["removed_file_count"], 1)
        self.assertFalse(session_dir.exists())
        with self.assertRaisesRegex(Exception, "Import session does not exist"):
            service.get_import_session(stale_id)

    def test_gateway_cleanup_abandoned_import_sessions_skips_committed_sessions(self) -> None:
        service = GatewayService()
        session = service.create_import_session()
        import_id = str(session["import_id"])
        service.stage_import_file(
            import_id=import_id,
            client_filename="sample.jpg",
            content=b"abc",
            path_hint="/photos/sample.jpg",
        )
        committed = service.commit_import_session(import_id)
        with sqlite3.connect(service.paths.database) as connection:
            connection.execute(
                "UPDATE import_session SET updated_at = '2026-03-18T00:00:00Z' WHERE import_id = ?",
                (import_id,),
            )
            connection.commit()

        result = service.cleanup_abandoned_import_sessions(older_than_hours=24.0)
        self.assertEqual(result["removed_count"], 0)
        refreshed = service.get_import_session(import_id)
        self.assertEqual(refreshed["status"], "committed")
        self.assertEqual(refreshed["import_run_id"], committed["run_id"])

    def test_gateway_cleanup_abandoned_import_sessions_dry_run_reports_candidates(self) -> None:
        service = GatewayService()
        session = service.create_import_session()
        import_id = str(session["import_id"])
        service.stage_import_file(
            import_id=import_id,
            client_filename="sample.jpg",
            content=b"abc",
            path_hint="/photos/sample.jpg",
        )
        with sqlite3.connect(service.paths.database) as connection:
            connection.execute(
                "UPDATE import_session SET updated_at = '2026-03-18T00:00:00Z' WHERE import_id = ?",
                (import_id,),
            )
            connection.commit()

        result = service.cleanup_abandoned_import_sessions(older_than_hours=24.0, dry_run=True)
        self.assertEqual(result["candidate_count"], 1)
        self.assertEqual(result["removed_count"], 0)
        self.assertTrue((service.paths.import_sessions_dir / import_id).exists())

    def test_gateway_commit_queues_run_without_sealing_input(self) -> None:
        service = GatewayService()
        session = service.create_import_session()
        import_id = str(session["import_id"])
        service.stage_import_file(
            import_id=import_id,
            client_filename="A.JPG",
            content=b"first-file",
            path_hint="/import/A.JPG",
        )
        service.stage_import_file(
            import_id=import_id,
            client_filename="B.JPG",
            content=b"second-file",
            path_hint="/import/B.JPG",
        )

        committed = service.commit_import_session(import_id)
        run_id = str(committed["run_id"])
        gateway_root = Path(os.environ["EONA_GATEWAY_HOME"])
        run_dir = gateway_root / "runs" / run_id
        run_state = read_json(run_dir / "run.json")

        self.assertTrue((run_dir / "input").is_dir())
        self.assertFalse((run_dir / "input_manifest.json").exists())
        self.assertEqual(list((run_dir / "input").iterdir()), [])
        self.assertEqual(run_state["run_id"], run_id)
        self.assertEqual(run_state["status"], "queued")
        self.assertEqual(run_state["source_import_id"], import_id)

    def test_gateway_worker_seals_input_manifest_before_pipeline(self) -> None:
        service = GatewayService()
        session = service.create_import_session()
        import_id = str(session["import_id"])
        first_content = b"first-file"
        second_content = b"second-file"
        service.stage_import_file(
            import_id=import_id,
            client_filename="A.JPG",
            content=first_content,
            path_hint="/import/A.JPG",
        )
        service.stage_import_file(
            import_id=import_id,
            client_filename="B.JPG",
            content=second_content,
            path_hint="/import/B.JPG",
        )

        committed = service.commit_import_session(import_id)
        run_id = str(committed["run_id"])
        manifest = service.seal_run_input(run_id)
        gateway_root = Path(os.environ["EONA_GATEWAY_HOME"])
        run_dir = gateway_root / "runs" / run_id
        run_state = read_json(run_dir / "run.json")

        self.assertEqual(manifest["run_id"], run_id)
        self.assertEqual(manifest["source_import_id"], import_id)
        self.assertEqual(manifest["manifest_version"], 1)
        self.assertEqual(manifest["item_count"], 2)
        self.assertEqual([item["client_filename"] for item in manifest["items"]], ["A.JPG", "B.JPG"])
        sealed_paths = [gateway_root / item["input_relpath"] for item in manifest["items"]]
        self.assertEqual(sealed_paths[0].read_bytes(), first_content)
        self.assertEqual(sealed_paths[1].read_bytes(), second_content)
        self.assertTrue(str(manifest["items"][0]["input_relpath"]).startswith(f"imports/sessions/{import_id}/"))
        self.assertEqual(run_state["input_manifest"], f"runs/{run_id}/input_manifest.json")
        self.assertEqual(run_state["stages"]["SEAL_INPUT"]["items_done"], 2)
        self.assertEqual(run_state["stages"]["SEAL_INPUT"]["items_total"], 2)
        self.assertEqual(run_state["stages"]["SEAL_INPUT"]["state"], "complete")

    def test_gateway_queue_claims_oldest_run_first(self) -> None:
        service = GatewayService()
        first_import = service.create_import_session()
        service.stage_import_file(
            import_id=str(first_import["import_id"]),
            client_filename="one.jpg",
            content=b"one",
            path_hint="/a/one.jpg",
        )
        first_run = service.commit_import_session(str(first_import["import_id"]))
        time.sleep(1)
        second_import = service.create_import_session()
        service.stage_import_file(
            import_id=str(second_import["import_id"]),
            client_filename="two.jpg",
            content=b"two",
            path_hint="/a/two.jpg",
        )
        second_run = service.commit_import_session(str(second_import["import_id"]))

        claimed_first = service.claim_next_run()
        self.assertEqual(claimed_first["run_id"], first_run["run_id"])
        service.complete_placeholder_run(str(claimed_first["run_id"]))
        claimed_second = service.claim_next_run()
        self.assertEqual(claimed_second["run_id"], second_run["run_id"])

    def test_gateway_queue_does_not_claim_second_run_while_one_is_running(self) -> None:
        service = GatewayService()
        first_import = service.create_import_session()
        service.stage_import_file(
            import_id=str(first_import["import_id"]),
            client_filename="one.jpg",
            content=b"one",
            path_hint="/a/one.jpg",
        )
        service.commit_import_session(str(first_import["import_id"]))
        second_import = service.create_import_session()
        service.stage_import_file(
            import_id=str(second_import["import_id"]),
            client_filename="two.jpg",
            content=b"two",
            path_hint="/a/two.jpg",
        )
        service.commit_import_session(str(second_import["import_id"]))

        claimed_first = service.claim_next_run()
        self.assertIsNotNone(claimed_first)
        claimed_second = service.claim_next_run()
        self.assertIsNone(claimed_second)

    def test_gateway_can_pause_and_resume_queued_run(self) -> None:
        service = GatewayService()
        session = service.create_import_session()
        import_id = str(session["import_id"])
        service.stage_import_file(
            import_id=import_id,
            client_filename="one.jpg",
            content=b"one",
            path_hint="/a/one.jpg",
        )
        committed = service.commit_import_session(import_id)
        run_id = str(committed["run_id"])

        paused = service.request_pause_run(run_id)
        self.assertEqual(paused["status"], "paused")
        self.assertIsNone(service.claim_next_run())

        resumed = service.resume_paused_run(run_id)
        self.assertEqual(resumed["status"], "queued")
        claimed = service.claim_next_run()
        self.assertIsNotNone(claimed)
        self.assertEqual(claimed["run_id"], run_id)

    def test_gateway_list_import_runs_handles_pause_control_join(self) -> None:
        service = GatewayService()
        session = service.create_import_session()
        import_id = str(session["import_id"])
        service.stage_import_file(
            import_id=import_id,
            client_filename="one.jpg",
            content=b"one",
            path_hint="/a/one.jpg",
        )
        run_id = str(service.commit_import_session(import_id)["run_id"])
        paused = service.request_pause_run(run_id)
        self.assertEqual(paused["status"], "paused")

        payload = service.list_import_runs(limit=10)
        self.assertEqual(payload["items"][0]["run_id"], run_id)
        self.assertEqual(payload["items"][0]["status"], "paused")

    def test_gateway_checkpoint_pause_acknowledges_running_run(self) -> None:
        service = GatewayService()
        session = service.create_import_session()
        import_id = str(session["import_id"])
        service.stage_import_file(
            import_id=import_id,
            client_filename="one.jpg",
            content=b"one",
            path_hint="/a/one.jpg",
        )
        run_id = str(service.commit_import_session(import_id)["run_id"])
        claimed = service.claim_next_run()
        self.assertIsNotNone(claimed)

        pausing = service.request_pause_run(run_id)
        self.assertEqual(pausing["status"], "pausing")
        with self.assertRaises(GatewayPauseRequested):
            service.checkpoint_pause(run_id, stage="METADATA_EXTRACTION")

        paused = service.get_import_run(run_id)
        self.assertEqual(paused["status"], "paused")
        self.assertIsNone(service.claim_next_run())

    def test_gateway_resume_from_merge_checkpoint_uses_pause_resume_path(self) -> None:
        service = GatewayService()
        session = service.create_import_session()
        import_id = str(session["import_id"])
        service.stage_import_file(
            import_id=import_id,
            client_filename="one.jpg",
            content=self._sample_png_bytes(),
            path_hint="/a/one.jpg",
        )
        service.stage_import_file(
            import_id=import_id,
            client_filename="two.jpg",
            content=self._sample_png_bytes(),
            path_hint="/a/two.jpg",
        )
        run_id = str(service.commit_import_session(import_id)["run_id"])
        claimed = service.claim_next_run()
        self.assertIsNotNone(claimed)
        service.seal_run_input(run_id)
        GatewayPipelineRunner(
            service=service,
            metadata_extractor=self._FakeExtractor(),
            location_normalizer=self._FakeNormalizer(),
        ).execute_run(run_id)

        service.request_pause_run(run_id)
        with self.assertRaises(GatewayPauseRequested):
            service.checkpoint_pause(run_id, stage="MERGE")
        paused = service.get_import_run_detail(run_id)
        self.assertEqual(paused["status"], "paused")
        self.assertEqual(paused["resume_from_stage"], "MERGE")

        service.resume_paused_run(run_id)
        resumed = service.get_import_run_detail(run_id)
        self.assertEqual(resumed["status"], "queued")
        self.assertEqual(resumed["resume_from_stage"], "MERGE")
        service.claim_next_run()
        completed = service.resume_paused_merge_run(
            run_id,
            merge_runner=GatewayMergeRunner(
                service=service,
                canonicalizer=self._StableCanonicalizer(),
            ),
        )
        self.assertEqual(completed["status"], "complete")
        self.assertEqual(completed["report"]["recovery_mode"], "pause_resume")

    def test_gateway_reconcile_interrupted_runs_marks_running_run_failed(self) -> None:
        service = GatewayService()
        session = service.create_import_session()
        import_id = str(session["import_id"])
        service.stage_import_file(
            import_id=import_id,
            client_filename="one.jpg",
            content=b"one",
            path_hint="/a/one.jpg",
        )
        committed = service.commit_import_session(import_id)
        run_id = str(committed["run_id"])
        claimed = service.claim_next_run()
        self.assertIsNotNone(claimed)

        result = service.reconcile_interrupted_runs()
        self.assertEqual(result["reconciled_count"], 1)
        self.assertEqual(result["run_ids"], [run_id])

        run_payload = service.get_import_run(run_id)
        self.assertEqual(run_payload["status"], "failed")
        self.assertEqual(run_payload["error_code"], "WORKER_INTERRUPTED")
        run_state = read_json(service.paths.runs_dir / run_id / "run.json")
        self.assertEqual(run_state["status"], "failed")
        self.assertEqual(run_state["error_code"], "WORKER_INTERRUPTED")

    def test_gateway_server_reconciles_interrupted_runs_before_worker_start(self) -> None:
        service = GatewayService()
        server = object.__new__(GatewayHTTPServer)
        server.gateway_service = service
        server.gateway_worker = mock.Mock()
        server.worker_thread = None
        server.startup_readiness = {"lifecycle_state": "ready"}
        with (
            mock.patch.object(service, "reconcile_interrupted_runs", return_value={"ok": True}) as reconcile_mock,
            mock.patch("threading.Thread") as thread_cls,
            mock.patch("http.server.ThreadingHTTPServer.serve_forever", side_effect=KeyboardInterrupt),
        ):
            thread_cls.return_value.start.return_value = None
            with self.assertRaises(KeyboardInterrupt):
                server.serve_forever()
        reconcile_mock.assert_called_once_with()

    def test_gateway_server_graceful_shutdown_requests_pause_for_active_run(self) -> None:
        service = GatewayService()
        server = object.__new__(GatewayHTTPServer)
        server.gateway_service = service
        server.gateway_worker = mock.Mock()
        server.gateway_worker.current_run_id = "run_123"
        server.worker_thread = mock.Mock()
        server.worker_thread.is_alive.side_effect = [True, False]
        with (
            mock.patch.object(service, "request_pause_run", return_value={"run_id": "run_123"}) as pause_mock,
            mock.patch("eona.gateway_server.time.sleep", return_value=None),
        ):
            server.request_graceful_shutdown(timeout=0.5)
        server.gateway_worker.request_graceful_stop.assert_called_once_with()
        pause_mock.assert_called_once_with("run_123")

    def test_gateway_server_graceful_shutdown_skips_pause_without_active_run(self) -> None:
        service = GatewayService()
        server = object.__new__(GatewayHTTPServer)
        server.gateway_service = service
        server.gateway_worker = mock.Mock()
        server.gateway_worker.current_run_id = None
        server.worker_thread = mock.Mock()
        server.worker_thread.is_alive.return_value = False
        with mock.patch.object(service, "request_pause_run") as pause_mock:
            server.request_graceful_shutdown(timeout=0.1)
        server.gateway_worker.request_graceful_stop.assert_called_once_with()
        pause_mock.assert_not_called()

    def test_gateway_queue_does_not_claim_run_until_import_session_is_committed(self) -> None:
        service = GatewayService()
        session = service.create_import_session()
        import_id = str(session["import_id"])
        service.stage_import_file(
            import_id=import_id,
            client_filename="one.jpg",
            content=b"one",
            path_hint="/a/one.jpg",
        )
        committed = service.commit_import_session(import_id)
        run_id = str(committed["run_id"])

        import sqlite3
        with sqlite3.connect(service.paths.database) as connection:
            connection.execute("UPDATE import_session SET status = 'committing' WHERE import_id = ?", (import_id,))
            connection.commit()

        claimed = service.claim_next_run()
        self.assertIsNone(claimed)

        with sqlite3.connect(service.paths.database) as connection:
            connection.execute("UPDATE import_session SET status = 'committed' WHERE import_id = ?", (import_id,))
            connection.commit()

        claimed_after_commit = service.claim_next_run()
        self.assertIsNotNone(claimed_after_commit)
        self.assertEqual(claimed_after_commit["run_id"], run_id)

    def test_gateway_worker_treats_locked_database_as_retryable(self) -> None:
        service = GatewayService()
        worker = GatewayWorkerLoop(service=service, poll_interval=0.01)
        call_count = {"value": 0}

        def flaky_claim():
            call_count["value"] += 1
            if call_count["value"] == 1:
                raise sqlite3.OperationalError("database is locked")
            worker.stop()
            return None

        worker.service.claim_next_run = flaky_claim
        worker.run_forever()
        self.assertEqual(call_count["value"], 2)

    def test_gateway_worker_blocks_on_sqlite_disk_io_error(self) -> None:
        service = GatewayService()
        worker = GatewayWorkerLoop(service=service, poll_interval=0.01)

        def broken_claim():
            raise sqlite3.OperationalError("disk I/O error")

        worker.service.claim_next_run = broken_claim
        worker.run_forever()
        readiness = service.readiness()
        self.assertFalse(readiness["ok"])
        self.assertEqual(readiness["lifecycle_state"], "blocked")
        self.assertEqual(readiness["storage_fault"]["error_code"], "DATABASE_IO_ERROR")
        self.assertIn("disk I/O error", readiness["storage_fault"]["message"])

    def test_gateway_worker_completes_committed_run(self) -> None:
        service = GatewayService()
        created = service.create_import_session()
        import_id = created["import_id"]
        boundary = "GatewayBoundary123"
        payload = build_multipart(
            fields={"path_hint": "/Users/test/Pictures/IMG_0001.JPG"},
            file_field="file",
            filename="IMG_0001.JPG",
            content=self._sample_png_bytes(),
            boundary=boundary,
        )
        parsed = _parse_multipart(body=payload, boundary=_extract_boundary(f"multipart/form-data; boundary={boundary}") or b"")
        staged = service.stage_import_file(
            import_id=import_id,
            client_filename=str(parsed["file"][0]["filename"]),
            content=bytes(parsed["file"][0]["content"]),
            path_hint=str(parsed["path_hint"][0]["text"]),
        )
        self.assertEqual(staged["status"], "staged")
        committed = service.commit_import_session(import_id)
        run_id = committed["run_id"]

        pipeline_runner = GatewayPipelineRunner(
            service=service,
            metadata_extractor=self._FakeExtractor(),
            location_normalizer=self._FakeNormalizer(),
        )
        worker = GatewayWorkerLoop(service=service, poll_interval=0.01, pipeline_runner=pipeline_runner)
        worker.run_forever = mock.Mock()
        claimed = service.claim_next_run()
        self.assertIsNotNone(claimed)
        service.seal_run_input(str(claimed["run_id"]))
        pipeline_runner.execute_run(str(claimed["run_id"]))
        report = worker.merge_runner.execute_run(str(claimed["run_id"]))
        service.complete_run(str(claimed["run_id"]), report=report.as_dict())
        deadline = time.time() + 5.0
        run_payload = None
        while time.time() < deadline:
            run_payload = service.get_import_run(run_id)
            if run_payload["status"] == "complete":
                break
            time.sleep(0.05)
        self.assertIsNotNone(run_payload)
        self.assertEqual(run_payload["status"], "complete")
        self.assertIsNotNone(run_payload["report"])
        self.assertEqual(run_payload["report"]["new_content_count"], 1)
        self.assertEqual(run_payload["report"]["new_photo_count"], 1)
        self.assertEqual(run_payload["report"]["new_path_count"], 1)
        suggestions = run_payload["report"].get("semantic_enrichment_suggestions")
        self.assertIsInstance(suggestions, list)
        self.assertEqual([item["job_name"] for item in suggestions], ["duplicate_semantic", "has_people"])
        self.assertEqual(suggestions[0]["priority"], "better_have")
        self.assertIn("Reduce export and burst duplicates", suggestions[0]["purpose"])
        self.assertIn("If skipped", suggestions[0]["impact"])
        self.assertIn("Run duplicate semantic enrichment", suggestions[0]["recommended_action"])
        self.assertEqual(worker.poll_interval, 0.01)
        gateway_root = Path(os.environ["EONA_GATEWAY_HOME"])
        run_state = read_json(gateway_root / "runs" / run_id / "run.json")
        self.assertEqual(run_state["status"], "complete")
        self.assertIsNotNone(run_state["report"])
        self.assertEqual(run_state["stages"]["SEAL_INPUT"]["state"], "complete")
        self.assertEqual(run_state["stages"]["CANONICALIZATION"]["items_done"], 1)
        self.assertEqual(run_state["stages"]["CANONICALIZATION"]["items_total"], 1)
        self.assertEqual(run_state["stages"]["MERGE"]["items_done"], 1)
        self.assertEqual(run_state["stages"]["MERGE"]["items_total"], 1)
        self.assertTrue((gateway_root / "runs" / run_id / "artifacts" / "photos.ndjson").is_file())
        self.assertTrue((gateway_root / "runs" / run_id / "artifacts" / "metadata.ndjson").is_file())
        self.assertTrue((gateway_root / "runs" / run_id / "artifacts" / "geo.ndjson").is_file())
        self.assertTrue((gateway_root / "runs" / run_id / "import.db").is_file())
        with service.paths.database.open("rb"):
            pass
        import sqlite3
        with sqlite3.connect(service.paths.database) as connection:
            content_rows = connection.execute("SELECT content_id, storage_relpath FROM content").fetchall()
            photo_rows = connection.execute("SELECT photo_id, content_id FROM photo").fetchall()
            path_rows = connection.execute("SELECT photo_id, path_text FROM photo_path_observation").fetchall()
        self.assertEqual(len(content_rows), 1)
        self.assertEqual(len(photo_rows), 1)
        self.assertEqual(len(path_rows), 1)
        canonical_path = gateway_root / content_rows[0][1]
        self.assertTrue(canonical_path.is_file())
        content_path, headers = service.get_content_response(content_rows[0][0])
        self.assertEqual(content_path.resolve(), canonical_path.resolve())
        self.assertEqual(headers["Content-Type"], "image/jpeg")
        photo_payload = service.get_photo_metadata(photo_rows[0][0])
        self.assertEqual(photo_payload["content_id"], content_rows[0][0])
        self.assertEqual(photo_payload["path_observations"], ["/Users/test/Pictures/IMG_0001.JPG"])

    def test_gateway_pipeline_continues_when_one_item_fails_metadata_extraction(self) -> None:
        service = GatewayService()
        session = service.create_import_session()
        import_id = str(session["import_id"])
        service.stage_import_file(
            import_id=import_id,
            client_filename="good.JPG",
            content=b"good-meta",
            path_hint="/import/good.JPG",
        )
        service.stage_import_file(
            import_id=import_id,
            client_filename="bad.JPG",
            content=b"bad-meta",
            path_hint="/import/bad.JPG",
        )
        run_id = str(service.commit_import_session(import_id)["run_id"])
        service.seal_run_input(run_id)

        pipeline_runner = GatewayPipelineRunner(
            service=service,
            metadata_extractor=self._FlakyExtractor(),
            location_normalizer=self._FakeNormalizer(),
        )
        pipeline_report = pipeline_runner.execute_run(run_id)

        self.assertEqual(pipeline_report["processed_count"], 1)
        self.assertEqual(pipeline_report["failed_item_count"], 1)
        run_state = read_json(service.paths.runs_dir / run_id / "run.json")
        self.assertEqual(run_state["stages"]["METADATA_EXTRACTION"]["items_done"], 2)
        self.assertEqual(run_state["stages"]["METADATA_EXTRACTION"]["items_total"], 2)

        with sqlite3.connect(service.paths.database) as connection:
            failed_row = connection.execute(
                """
                SELECT status, error_code, error_message
                FROM import_run_item
                WHERE run_id = ? AND source_path_text = ?
                """,
                (run_id, "/import/bad.JPG"),
            ).fetchone()
            pending_good = connection.execute(
                """
                SELECT status
                FROM import_run_item
                WHERE run_id = ? AND source_path_text = ?
                """,
                (run_id, "/import/good.JPG"),
            ).fetchone()
        self.assertEqual(failed_row[0], "failed")
        self.assertEqual(failed_row[1], "SOURCE_IMAGE_TRUNCATED")
        self.assertIn("Metadata extraction failed", failed_row[2])
        self.assertEqual(pending_good[0], "pending")

        import_db = service.paths.runs_dir / run_id / "import.db"
        with sqlite3.connect(import_db) as connection:
            photo_paths = [row[0] for row in connection.execute("SELECT path FROM photos ORDER BY path").fetchall()]
        self.assertEqual(len(photo_paths), 1)

    def test_gateway_merge_continues_when_one_item_is_truncated(self) -> None:
        service = GatewayService()
        session = service.create_import_session()
        import_id = str(session["import_id"])
        service.stage_import_file(
            import_id=import_id,
            client_filename="good.JPG",
            content=b"good",
            path_hint="/import/good.JPG",
        )
        service.stage_import_file(
            import_id=import_id,
            client_filename="bad.JPG",
            content=b"bad",
            path_hint="/import/bad.JPG",
        )
        run_id = str(service.commit_import_session(import_id)["run_id"])
        manifest = service.seal_run_input(run_id)

        run_paths = service.paths.runs_dir / run_id
        import_db_path = run_paths / "import.db"
        with sqlite3.connect(import_db_path) as connection:
            connection.executescript(
                """
                CREATE TABLE photos (path TEXT PRIMARY KEY);
                CREATE TABLE metadata (path TEXT PRIMARY KEY, metadata_json TEXT);
                """
            )
            for item in manifest["items"]:
                source_path = str(Path(str(item.get("input_path") or (service.paths.root / item["input_relpath"]))).resolve())
                metadata_json = json.dumps(
                    {
                        "image_facts": {"taken_at_utc": "2026-03-19T00:00:00Z"},
                        "image_camera": {"make": "EonaCam", "model": Path(source_path).stem},
                        "image_location": {},
                    },
                    sort_keys=True,
                )
                connection.execute("INSERT INTO photos(path) VALUES (?)", (source_path,))
                connection.execute("INSERT INTO metadata(path, metadata_json) VALUES (?, ?)", (source_path, metadata_json))
            connection.commit()

        runner = GatewayMergeRunner(
            service=service,
            canonicalizer=self._FlakyCanonicalizer(),
        )
        report = runner.execute_run(run_id)

        self.assertEqual(report.collected_files, 2)
        self.assertEqual(report.processed_items, 1)
        self.assertEqual(report.failed_item_count, 1)
        run_state = read_json(run_paths / "run.json")
        self.assertEqual(run_state["stages"]["CANONICALIZATION"]["items_done"], 2)
        self.assertEqual(run_state["stages"]["MERGE"]["items_done"], 2)

        with sqlite3.connect(service.paths.database) as connection:
            failed_row = connection.execute(
                """
                SELECT status, error_code, error_message
                FROM import_run_item
                WHERE run_id = ? AND source_path_text = ?
                """,
                (run_id, "/import/bad.JPG"),
            ).fetchone()
            complete_row = connection.execute(
                """
                SELECT status, photo_id, content_id
                FROM import_run_item
                WHERE run_id = ? AND source_path_text = ?
                """,
                (run_id, "/import/good.JPG"),
            ).fetchone()
        self.assertEqual(failed_row[0], "failed")
        self.assertEqual(failed_row[1], "SOURCE_IMAGE_TRUNCATED")
        self.assertIn("truncated", failed_row[2])
        self.assertEqual(complete_row[0], "complete")
        self.assertIsNotNone(complete_row[1])
        self.assertIsNotNone(complete_row[2])

    def test_gateway_request_handler_ignores_broken_pipe_when_writing(self) -> None:
        handler = object.__new__(GatewayRequestHandler)
        handler.wfile = mock.Mock()
        handler.wfile.write.side_effect = BrokenPipeError("broken pipe")

        handler._write_response_body(b"payload")

    def test_gateway_recover_merge_retries_only_incomplete_items(self) -> None:
        service = GatewayService()
        session = service.create_import_session()
        import_id = str(session["import_id"])
        service.stage_import_file(
            import_id=import_id,
            client_filename="good.JPG",
            content=b"good",
            path_hint="/import/good.JPG",
        )
        service.stage_import_file(
            import_id=import_id,
            client_filename="bad.JPG",
            content=b"bad",
            path_hint="/import/bad.JPG",
        )
        run_id = str(service.commit_import_session(import_id)["run_id"])
        service.seal_run_input(run_id)

        pipeline_runner = GatewayPipelineRunner(
            service=service,
            metadata_extractor=self._FakeExtractor(),
            location_normalizer=self._FakeNormalizer(),
        )
        pipeline_runner.execute_run(run_id)

        partial_merge_runner = GatewayMergeRunner(
            service=service,
            canonicalizer=self._FlakyCanonicalizer(),
        )
        partial_report = partial_merge_runner.execute_run(run_id)
        self.assertEqual(partial_report.processed_items, 1)
        self.assertEqual(partial_report.failed_item_count, 1)

        service.fail_run(run_id, error_code="INTERNAL_ERROR", error_message="image file is truncated (40 bytes not processed)")

        recovered = service.recover_merge_run(
            run_id,
            merge_runner=GatewayMergeRunner(
                service=service,
                canonicalizer=self._StableCanonicalizer(),
            ),
        )

        self.assertEqual(recovered["status"], "complete")
        self.assertEqual(recovered["report"]["recovery_mode"], "merge_resume")
        self.assertEqual(recovered["report"]["retried_items"], 1)
        self.assertEqual(recovered["report"]["recovered_item_count"], 1)
        self.assertEqual(recovered["report"]["processed_items"], 2)
        self.assertEqual(recovered["report"]["failed_item_count"], 0)

        with sqlite3.connect(service.paths.database) as connection:
            statuses = connection.execute(
                "SELECT status FROM import_run_item WHERE run_id = ? ORDER BY source_path_text",
                (run_id,),
            ).fetchall()
        self.assertEqual([row[0] for row in statuses], ["complete", "complete"])

    def test_cli_gateway_recover_merge_json_contract(self) -> None:
        stdout = io.StringIO()
        fake_run = {
            "run_id": "run_123",
            "status": "complete",
            "report": {"recovery_mode": "merge_resume"},
        }
        with (
            mock.patch.object(sys, "argv", ["eona", "gateway", "recover-merge", "run_123", "--json"]),
            mock.patch.object(GatewayService, "recover_merge_run", return_value=fake_run) as recover_mock,
            redirect_stdout(stdout),
        ):
            exit_code = cli_main()
        payload = json.loads(stdout.getvalue())
        self.assertEqual(exit_code, 0)
        self.assertTrue(payload["ok"])
        self.assertEqual(payload["runs"][0]["run_id"], "run_123")
        recover_mock.assert_called_once_with("run_123")

    def test_gateway_doctor_reports_recoverable_failed_merge_run(self) -> None:
        service = GatewayService()
        session = service.create_import_session()
        import_id = str(session["import_id"])
        service.stage_import_file(
            import_id=import_id,
            client_filename="good.JPG",
            content=b"good",
            path_hint="/import/good.JPG",
        )
        service.stage_import_file(
            import_id=import_id,
            client_filename="bad.JPG",
            content=b"bad",
            path_hint="/import/bad.JPG",
        )
        run_id = str(service.commit_import_session(import_id)["run_id"])
        service.seal_run_input(run_id)

        pipeline_runner = GatewayPipelineRunner(
            service=service,
            metadata_extractor=self._FakeExtractor(),
            location_normalizer=self._FakeNormalizer(),
        )
        pipeline_runner.execute_run(run_id)
        partial_merge_runner = GatewayMergeRunner(
            service=service,
            canonicalizer=self._FlakyCanonicalizer(),
        )
        partial_merge_runner.execute_run(run_id)
        service.fail_run(run_id, error_code="INTERNAL_ERROR", error_message="image file is truncated (40 bytes not processed)")

        payload = service.doctor()
        self.assertFalse(payload["ok"])
        self.assertEqual(payload["runs"]["by_status"]["failed"], 1)
        self.assertEqual(len(payload["runs"]["recoverable_merge_runs"]), 1)
        self.assertEqual(payload["runs"]["recoverable_merge_runs"][0]["run_id"], run_id)
        self.assertEqual(payload["runs"]["recoverable_merge_runs"][0]["retryable_items"], 1)
        recovery_items = [item for item in payload["operational_items"] if item["name"] == "recoverable_merge_runs"]
        self.assertEqual(len(recovery_items), 1)
        self.assertEqual(recovery_items[0]["priority"], "must_have")
        self.assertIn("Recover interrupted merge work", recovery_items[0]["purpose"])
        self.assertIn("recover-merge", recovery_items[0]["command"])

    def test_gateway_readiness_reports_pending_semantic_enrichment(self) -> None:
        service = GatewayService()

        payload = service.readiness()

        self.assertEqual(payload["semantic_enrichment"]["status"], "pending")
        self.assertNotEqual(payload["lifecycle_state"], "blocked")
        self.assertIn("Semantic enrichment jobs are pending.", payload.get("warnings", []))
        self.assertEqual(payload["semantic_enrichment"]["jobs"][0]["category"], "semantic_enrichment")
        self.assertEqual(payload["semantic_enrichment"]["jobs"][0]["priority"], "better_have")
        self.assertTrue(payload["operational_summary"]["usable_now"])
        self.assertEqual(
            [item["name"] for item in payload["operational_summary"]["recommended_actions"]],
            ["duplicate_semantic", "has_people"],
        )
        self.assertIn("usable now", payload["operational_summary"]["user_message"])

    def test_gateway_doctor_emits_agent_readable_semantic_items(self) -> None:
        service = GatewayService()

        payload = service.doctor()

        semantic_items = [item for item in payload["operational_items"] if item["category"] == "semantic_enrichment"]
        self.assertEqual([item["name"] for item in semantic_items], ["duplicate_semantic", "has_people"])
        self.assertEqual(semantic_items[0]["priority"], "better_have")
        self.assertIn("Reduce export and burst duplicates", semantic_items[0]["purpose"])
        self.assertIn("If skipped", semantic_items[0]["impact_if_skipped"])
        self.assertIn("Duplicate cleanup is optional", semantic_items[0]["user_explanation"])

    def test_gateway_cleanup_terminal_run_data_removes_completed_run_transients(self) -> None:
        service = GatewayService()
        session = service.create_import_session()
        import_id = str(session["import_id"])
        service.stage_import_file(
            import_id=import_id,
            client_filename="sample.JPG",
            content=b"sample",
            path_hint="/import/sample.JPG",
        )
        run_id = str(service.commit_import_session(import_id)["run_id"])
        service.seal_run_input(run_id)

        pipeline_runner = GatewayPipelineRunner(
            service=service,
            metadata_extractor=self._FakeExtractor(),
            location_normalizer=self._FakeNormalizer(),
        )
        pipeline_runner.execute_run(run_id)
        merge_report = GatewayMergeRunner(
            service=service,
            canonicalizer=self._StableCanonicalizer(),
        ).execute_run(run_id)
        service.complete_run(run_id, report=merge_report.as_dict())

        with sqlite3.connect(service.paths.database) as connection:
            connection.execute(
                "UPDATE import_run SET completed_at = '2026-03-18T00:00:00Z' WHERE run_id = ?",
                (run_id,),
            )
            connection.commit()

        run_paths = service.paths.runs_dir / run_id
        import_dir = service.paths.import_sessions_dir / import_id
        self.assertTrue((run_paths / "input").is_dir())
        self.assertTrue((run_paths / "import.db").is_file())
        self.assertFalse(import_dir.exists())

        result = service.cleanup_terminal_run_data(older_than_hours=24.0)
        self.assertEqual(result["removed_run_count"], 1)
        self.assertFalse((run_paths / "input").exists())
        self.assertFalse((run_paths / "import.db").exists())
        self.assertFalse((run_paths / "input_manifest.json").exists())
        self.assertFalse(import_dir.exists())
        self.assertTrue((run_paths / "run.json").is_file())

    def test_gateway_complete_run_removes_committed_import_session_files(self) -> None:
        service = GatewayService()
        session = service.create_import_session()
        import_id = str(session["import_id"])
        service.stage_import_file(
            import_id=import_id,
            client_filename="sample.JPG",
            content=b"sample",
            path_hint="/import/sample.JPG",
        )
        run_id = str(service.commit_import_session(import_id)["run_id"])
        service.seal_run_input(run_id)

        pipeline_runner = GatewayPipelineRunner(
            service=service,
            metadata_extractor=self._FakeExtractor(),
            location_normalizer=self._FakeNormalizer(),
        )
        pipeline_runner.execute_run(run_id)
        merge_report = GatewayMergeRunner(
            service=service,
            canonicalizer=self._StableCanonicalizer(),
        ).execute_run(run_id)

        import_dir = service.paths.import_sessions_dir / import_id
        self.assertTrue(import_dir.is_dir())
        service.complete_run(run_id, report=merge_report.as_dict())
        self.assertFalse(import_dir.exists())

    def test_gateway_cleanup_terminal_run_data_skips_recoverable_failed_runs_by_default(self) -> None:
        service = GatewayService()
        session = service.create_import_session()
        import_id = str(session["import_id"])
        service.stage_import_file(
            import_id=import_id,
            client_filename="good.JPG",
            content=b"good",
            path_hint="/import/good.JPG",
        )
        service.stage_import_file(
            import_id=import_id,
            client_filename="bad.JPG",
            content=b"bad",
            path_hint="/import/bad.JPG",
        )
        run_id = str(service.commit_import_session(import_id)["run_id"])
        service.seal_run_input(run_id)
        GatewayPipelineRunner(
            service=service,
            metadata_extractor=self._FakeExtractor(),
            location_normalizer=self._FakeNormalizer(),
        ).execute_run(run_id)
        GatewayMergeRunner(
            service=service,
            canonicalizer=self._FlakyCanonicalizer(),
        ).execute_run(run_id)
        service.fail_run(run_id, error_code="INTERNAL_ERROR", error_message="image file is truncated (40 bytes not processed)")
        with sqlite3.connect(service.paths.database) as connection:
            connection.execute(
                "UPDATE import_run SET completed_at = '2026-03-18T00:00:00Z' WHERE run_id = ?",
                (run_id,),
            )
            connection.commit()

        result = service.cleanup_terminal_run_data(older_than_hours=24.0, dry_run=True)
        self.assertEqual(result["candidate_count"], 0)
        self.assertTrue((service.paths.runs_dir / run_id / "input_manifest.json").exists())

    def test_gateway_ui_path_hints_can_map_per_file(self) -> None:
        file_parts = [
            {"filename": "one.jpg", "content": b"one"},
            {"filename": "two.jpg", "content": b"two"},
        ]
        import_parts = {
            "path_hint": [
                {"text": "Trip/one.jpg"},
                {"text": "Trip/two.jpg"},
            ]
        }
        self.assertEqual(
            _resolve_file_path_hints(file_parts=file_parts, import_parts=import_parts),
            ["Trip/one.jpg", "Trip/two.jpg"],
        )

    def test_home_page_renders_import_form_and_run_links(self) -> None:
        html = render_home_page(
            runs=[
                {
                    "run_id": "run_123",
                    "status": "queued",
                    "current_stage": "SCANNING",
                    "created_at": "2026-03-19T08:00:00Z",
                }
            ]
        )
        self.assertIn("Eona Gateway", html)
        self.assertIn('action="/ui/import"', html)
        self.assertIn('/runs/run_123', html)
        self.assertIn('webkitdirectory', html)
        self.assertIn('accept=".jpg,.jpeg,.heic,.heif,image/jpeg,image/heic,image/heif"', html)
        self.assertIn('Drag and drop a folder here', html)
        self.assertIn('choose-folder', html)
        self.assertIn('event.stopPropagation()', html)
        self.assertIn('Accepted formats are `.jpg`, `.jpeg`, `.heic`, and `.heif`.', html)
        self.assertIn('fetch("/import-sessions"', html)
        self.assertIn('Collecting 0 /', html)
        self.assertIn('starts a new import run from scratch', html)
        self.assertIn('available_import_bytes', html)
        self.assertIn('formatBytes(totalBytes)', html)
        self.assertIn('eona.gateway.activeImport', html)
        self.assertIn('beforeunload', html)
        self.assertIn('was interrupted by a page reload', html)
        self.assertIn('fetch(`/import-sessions/${importId}`)', html)
        self.assertIn('/import-sessions/${importId}/files', html)
        self.assertIn('/import-sessions/${importId}/commit', html)

    def test_run_detail_page_renders_report_and_stage_state(self) -> None:
        html = render_run_detail_page(
            run={
                "run_id": "run_123",
                "status": "running",
                "current_stage": "CANONICALIZATION",
                "progress": 1.0,
                "created_at": "2026-03-19T08:00:00Z",
                "started_at": "2026-03-19T08:01:00Z",
                "completed_at": None,
                "error_code": None,
                "report": {
                    "collected_files": 3,
                    "new_content_count": 2,
                },
                "stages": {
                    "SCANNING": {"state": "complete", "items_done": 3, "items_total": 3},
                    "CANONICALIZATION": {"state": "running", "items_done": 1, "items_total": 3},
                },
            },
            import_session={"import_id": "imp_1", "status": "committed", "file_count": 3},
        )
        self.assertIn("Import Run", html)
        self.assertIn("collected files", html.casefold())
        self.assertIn("SCANNING", html)
        self.assertIn("CANONICALIZATION", html)
        self.assertIn('class="stage-grid"', html)
        self.assertIn('class="stage-progress"', html)
        self.assertIn("running (1/3)", html)
        self.assertNotIn('<div class="progress"><span></span></div>', html)
        self.assertIn("imp_1", html)

    def test_run_detail_page_renders_interrupted_run_notice(self) -> None:
        html = render_run_detail_page(
            run={
                "run_id": "run_123",
                "status": "failed",
                "current_stage": None,
                "progress": 0.4,
                "created_at": "2026-03-19T08:00:00Z",
                "started_at": "2026-03-19T08:01:00Z",
                "completed_at": "2026-03-19T08:05:00Z",
                "error_code": "WORKER_INTERRUPTED",
                "report": {},
                "stages": {},
            },
            import_session={"import_id": "imp_1", "status": "committed", "file_count": 3},
        )
        self.assertIn("interrupted by a Gateway restart", html)
        self.assertIn("will not resume automatically", html)
        self.assertIn("from scratch", html)

    def test_run_detail_page_renders_pause_and_resume_controls(self) -> None:
        running_html = render_run_detail_page(
            run={
                "run_id": "run_running",
                "status": "running",
                "current_stage": "MERGE",
                "progress": 0.9,
                "created_at": "2026-03-19T08:00:00Z",
                "started_at": "2026-03-19T08:01:00Z",
                "completed_at": None,
                "error_code": None,
                "report": {},
                "stages": {},
            },
            import_session=None,
        )
        paused_html = render_run_detail_page(
            run={
                "run_id": "run_paused",
                "status": "paused",
                "current_stage": "MERGE",
                "progress": 0.9,
                "created_at": "2026-03-19T08:00:00Z",
                "started_at": "2026-03-19T08:01:00Z",
                "completed_at": None,
                "error_code": None,
                "report": {},
                "stages": {},
            },
            import_session=None,
        )
        self.assertIn("/import-runs/run_running/pause", running_html)
        self.assertIn(">Pause<", running_html)
        self.assertIn("/import-runs/run_paused/resume", paused_html)
        self.assertIn(">Resume<", paused_html)

    def test_run_detail_page_explains_resume_retry_counts(self) -> None:
        html = render_run_detail_page(
            run={
                "run_id": "run_resume",
                "status": "running",
                "current_stage": "CANONICALIZATION",
                "resume_from_stage": "CANONICALIZATION",
                "progress": 0.97,
                "created_at": "2026-03-19T08:00:00Z",
                "started_at": "2026-03-19T08:01:00Z",
                "completed_at": None,
                "error_code": None,
                "report": {"collected_files": 38693},
                "stages": {
                    "METADATA_EXTRACTION": {"state": "complete", "items_done": 38693, "items_total": 38693},
                    "CANONICALIZATION": {"state": "running", "items_done": 611, "items_total": 38183},
                },
            },
            import_session={"import_id": "imp_1", "status": "committed", "file_count": 38693},
        )
        self.assertIn("Resume In Progress", html)
        self.assertIn("Resuming from CANONICALIZATION.", html)
        self.assertIn("retry set (38183 items)", html)
        self.assertIn("Original import contained 38693 files.", html)

    def test_blocked_page_renders_operator_message(self) -> None:
        html = render_blocked_page(
            readiness={
                "summary": "Gateway integrity check failed.",
                "problems": [
                    "Canonical content bytes referenced by the database are missing from storage.",
                ],
            }
        )
        self.assertIn("Gateway Blocked", html)
        self.assertIn("operator-only mode", html)
        self.assertIn("Gateway integrity check failed.", html)

    def test_cli_gateway_init_db_json_contract(self) -> None:
        stdout = io.StringIO()
        with (
            mock.patch.object(sys, "argv", ["eona", "gateway", "init-db", "--json"]),
            redirect_stdout(stdout),
        ):
            exit_code = cli_main()
        payload = json.loads(stdout.getvalue())
        self.assertEqual(exit_code, 0)
        self.assertTrue(payload["ok"])
        self.assertEqual(payload["schema_version"], 1)

    def test_cli_gateway_serve_dispatches_to_server_entrypoint(self) -> None:
        with (
            mock.patch.object(sys, "argv", ["eona", "gateway", "serve", "--host", "127.0.0.1", "--port", "8010"]),
            mock.patch("eona.cli.serve_gateway", return_value=0) as serve_mock,
        ):
            exit_code = cli_main()
        self.assertEqual(exit_code, 0)
        serve_mock.assert_called_once_with(host="127.0.0.1", port=8010, poll_interval=0.25)

    def test_cli_gateway_check_runtime_propagates_failure_exit_code(self) -> None:
        stdout = io.StringIO()
        with (
            mock.patch.object(sys, "argv", ["eona", "gateway", "check-runtime"]),
            mock.patch(
                "eona.cli.inspect_gateway_runtime",
                return_value={
                    "ok": False,
                    "summary": "Gateway runtime check failed.",
                    "details": ["runtime manifest missing"],
                },
            ),
            redirect_stdout(stdout),
        ):
            exit_code = cli_main()
        self.assertEqual(exit_code, 1)
        self.assertIn("Gateway runtime check failed.", stdout.getvalue())

    def test_cli_gateway_bootstrap_runtime_json_contract(self) -> None:
        stdout = io.StringIO()
        with (
            mock.patch.object(sys, "argv", ["eona", "gateway", "bootstrap-runtime", "--json"]),
            mock.patch("eona.cli.bootstrap_gateway_runtime") as bootstrap_mock,
            redirect_stdout(stdout),
        ):
            bootstrap_mock.return_value = {
                "ok": True,
                "summary": "Gateway local runtime bootstrap completed.",
                "details": [],
                "paths": {
                    "image_root": "/tmp/eona-home",
                    "manifest": "/tmp/eona-home/runtime/metadata/runtime-manifest.json",
                    "datasets": "/tmp/eona-home/runtime/cadis/datasets",
                },
            }
            exit_code = cli_main()
        payload = json.loads(stdout.getvalue())
        self.assertEqual(exit_code, 0)
        self.assertTrue(payload["ok"])
        self.assertEqual(payload["summary"], "Gateway local runtime bootstrap completed.")

    def test_cli_setup_json_contract(self) -> None:
        stdout = io.StringIO()
        with (
            mock.patch.object(sys, "argv", ["eona", "setup", "--release-root", "/tmp/eona-release", "--json"]),
            mock.patch("eona.cli.setup_release") as setup_mock,
            redirect_stdout(stdout),
        ):
            setup_mock.return_value = {
                "ok": True,
                "summary": "Eona setup completed.",
                "details": [],
                "paths": {
                    "release_root": "/tmp/eona-release",
                    "eona_home": "/tmp/eona-home",
                    "gateway_home": "/tmp/eona-home/gateway",
                },
            }
            exit_code = cli_main()
        payload = json.loads(stdout.getvalue())
        self.assertEqual(exit_code, 0)
        self.assertTrue(payload["ok"])
        self.assertEqual(payload["summary"], "Eona setup completed.")
        setup_mock.assert_called_once_with(release_root="/tmp/eona-release", force=False)

    def test_cli_release_build_macos_json_contract(self) -> None:
        stdout = io.StringIO()
        with (
            mock.patch.object(sys, "argv", ["eona", "release", "build-macos", "/tmp/out", "--json"]),
            mock.patch("eona.cli.assemble_macos_release_tree") as build_mock,
            redirect_stdout(stdout),
        ):
            build_mock.return_value = {
                "ok": True,
                "summary": "Eona macOS release assembly completed.",
                "details": [],
                "paths": {
                    "release_root": "/tmp/out/eona-macos-arm64-0.1.0",
                    "client_launcher": "/tmp/out/eona-macos-arm64-0.1.0/bin/eona-client",
                    "gateway_launcher": "/tmp/out/eona-macos-arm64-0.1.0/bin/eona-gateway",
                    "runtime_root": "/tmp/out/eona-macos-arm64-0.1.0/runtime",
                },
            }
            exit_code = cli_main()
        payload = json.loads(stdout.getvalue())
        self.assertEqual(exit_code, 0)
        self.assertTrue(payload["ok"])
        self.assertEqual(payload["summary"], "Eona macOS release assembly completed.")
        build_mock.assert_called_once_with(release_root="/tmp/out", force=False)

    def test_gateway_runtime_paths_fall_back_to_eona_home_when_opt_root_missing(self) -> None:
        eona_root = Path(self.temp_dir.name) / "eona-home"
        os.environ["EONA_HOME"] = str(eona_root)
        self.addCleanup(lambda: os.environ.pop("EONA_HOME", None))
        paths = get_gateway_runtime_paths()
        self.assertEqual(paths.image_root, eona_root.resolve())

    def test_bootstrap_gateway_runtime_writes_local_manifest_and_datasets(self) -> None:
        eona_root = Path(self.temp_dir.name) / "eona-home"
        os.environ["EONA_HOME"] = str(eona_root)
        self.addCleanup(lambda: os.environ.pop("EONA_HOME", None))
        runtime_root = eona_root / "runtime"
        venv_bin = runtime_root / "venv" / "bin"
        venv_bin.mkdir(parents=True, exist_ok=True)
        pip_path = venv_bin / "pip"
        pip_path.write_text("#!/bin/sh\nexit 0\n", encoding="utf-8")
        pip_path.chmod(0o755)
        python_path = venv_bin / "python"
        python_path.write_text("#!/bin/sh\nexit 0\n", encoding="utf-8")
        python_path.chmod(0o755)

        source_root = Path(self.temp_dir.name) / "gateway-source"
        source_root.mkdir(parents=True, exist_ok=True)
        manifest_source = source_root / "runtime-manifest.json"
        datasets_source = runtime_root / "cadis" / "datasets"
        datasets_source.mkdir(parents=True, exist_ok=True)
        (datasets_source / "GB" / "gb.admin" / "v1.0.0").mkdir(parents=True, exist_ok=True)
        (datasets_source / "GB" / "gb.admin" / "v1.0.0" / "dataset_release_manifest.json").write_text(
            json.dumps({"country_iso": "GB", "dataset_id": "gb.admin", "dataset_version": "v1.0.0"}),
            encoding="utf-8",
        )
        manifest_source.write_text(
            json.dumps(
                {
                    "runtime_version": "gateway-local-test",
                    "tools": {"exiftool": {"version": "13.53", "executable_path": "/opt/eona/runtime/tools/exiftool/exiftool"}},
                    "python_packages": {"cadis": {"version": "0.4.1"}},
                    "dataset_bundle": {
                        "version": "generated-test",
                        "path": "/opt/eona/runtime/cadis/datasets",
                        "required_iso2": ["GB"],
                        "datasets": [{"country_iso": "GB", "dataset_id": "gb.admin", "dataset_version": "v1.0.0"}],
                        "bundle_digest": "sha256:test",
                    },
                }
            ),
            encoding="utf-8",
        )

        with (
            mock.patch("eona.gateway_runtime._gateway_manifest_source_path", return_value=manifest_source),
            mock.patch("eona.gateway_runtime._gateway_datasets_source_path", return_value=datasets_source),
            mock.patch("eona.gateway_runtime.subprocess.run") as subprocess_mock,
        ):
            result = bootstrap_gateway_runtime()

        self.assertTrue(result["ok"])
        local_manifest = eona_root / "runtime" / "metadata" / "runtime-manifest.json"
        local_payload = json.loads(local_manifest.read_text(encoding="utf-8"))
        self.assertEqual(local_payload["tools"]["exiftool"]["executable_path"], "runtime/tools/exiftool/exiftool")
        self.assertEqual(local_payload["dataset_bundle"]["path"], "runtime/cadis/datasets")
        self.assertTrue((runtime_root / "cadis" / "datasets" / "GB" / "gb.admin" / "v1.0.0").is_dir())
        self.assertEqual(subprocess_mock.call_count, 4)
        self.assertIn("Verified required Gateway Python dependencies are already present", result["details"][-1])

    def test_bootstrap_gateway_runtime_returns_structured_failure_when_required_packages_missing(self) -> None:
        eona_root = Path(self.temp_dir.name) / "eona-home"
        os.environ["EONA_HOME"] = str(eona_root)
        self.addCleanup(lambda: os.environ.pop("EONA_HOME", None))
        runtime_root = eona_root / "runtime"
        venv_bin = runtime_root / "venv" / "bin"
        venv_bin.mkdir(parents=True, exist_ok=True)
        pip_path = venv_bin / "pip"
        pip_path.write_text("#!/bin/sh\nexit 0\n", encoding="utf-8")
        pip_path.chmod(0o755)
        python_path = venv_bin / "python"
        python_path.write_text("#!/bin/sh\nexit 0\n", encoding="utf-8")
        python_path.chmod(0o755)

        source_root = Path(self.temp_dir.name) / "gateway-source"
        source_root.mkdir(parents=True, exist_ok=True)
        manifest_source = source_root / "runtime-manifest.json"
        datasets_source = source_root / "datasets"
        datasets_source.mkdir(parents=True, exist_ok=True)
        manifest_source.write_text(json.dumps({"runtime_version": "gateway-local-test"}), encoding="utf-8")

        with (
            mock.patch("eona.gateway_runtime._gateway_manifest_source_path", return_value=manifest_source),
            mock.patch("eona.gateway_runtime._gateway_datasets_source_path", return_value=datasets_source),
            mock.patch(
                "eona.gateway_runtime.subprocess.run",
                side_effect=subprocess.CalledProcessError(
                    1,
                    [str(python_path), "-c", "import importlib.metadata"],
                    stderr="PackageNotFoundError",
                ),
            ),
        ):
            result = bootstrap_gateway_runtime()

        self.assertFalse(result["ok"])
        self.assertEqual(result["summary"], "Gateway local runtime bootstrap failed.")
        self.assertIn("missing required Gateway Python packages", result["details"][0])
        self.assertIn("Missing packages:", result["details"][1])

    def test_local_gateway_server_build_uses_eona_home_runtime_root(self) -> None:
        eona_root = Path(self.temp_dir.name) / "eona-home"
        gateway_root = eona_root / "gateway"
        os.environ["EONA_HOME"] = str(eona_root)
        os.environ["EONA_GATEWAY_IMAGE_ROOT"] = str(eona_root)
        os.environ["EONA_GATEWAY_HOME"] = str(gateway_root)
        self.addCleanup(lambda: os.environ.pop("EONA_HOME", None))
        self.addCleanup(lambda: os.environ.pop("EONA_GATEWAY_IMAGE_ROOT", None))
        self.addCleanup(lambda: os.environ.pop("EONA_GATEWAY_HOME", None))

        exiftool_path = eona_root / "runtime" / "tools" / "exiftool" / "exiftool"
        exiftool_path.parent.mkdir(parents=True, exist_ok=True)
        exiftool_path.write_text("#!/bin/sh\nexit 0\n", encoding="utf-8")
        exiftool_path.chmod(0o755)

        dataset_dir = eona_root / "runtime" / "cadis" / "datasets" / "GB" / "gb.admin" / "v1.0.0"
        dataset_dir.mkdir(parents=True, exist_ok=True)
        data_file = dataset_dir / "hierarchy.json"
        data_file.write_text('{"ok":true}\n', encoding="utf-8")
        checksum = hashlib.sha256(data_file.read_bytes()).hexdigest()
        (dataset_dir / "dataset_release_manifest.json").write_text(
            json.dumps(
                {
                    "country_iso": "GB",
                    "dataset_id": "gb.admin",
                    "dataset_version": "v1.0.0",
                    "checksums": {
                        "files": {
                            "hierarchy.json": {
                                "sha256": checksum,
                                "size": data_file.stat().st_size,
                            }
                        }
                    },
                }
            ),
            encoding="utf-8",
        )
        manifest_path = eona_root / "runtime" / "metadata" / "runtime-manifest.json"
        manifest_path.parent.mkdir(parents=True, exist_ok=True)
        manifest_path.write_text(
            json.dumps(
                {
                    "runtime_version": "gateway-v1-local-test",
                    "tools": {
                        "exiftool": {
                            "version": "13.53",
                            "executable_path": "runtime/tools/exiftool/exiftool",
                        }
                    },
                    "python_packages": {"cadis": {"version": "0.4.1"}},
                    "dataset_bundle": {
                        "version": "local-test-bundle",
                        "path": "runtime/cadis/datasets",
                        "required_iso2": ["GB"],
                    },
                }
            ),
            encoding="utf-8",
        )

        with mock.patch("eona.gateway_server.GatewayHTTPServer") as server_cls:
            build_gateway_server(host="127.0.0.1", port=0, poll_interval=0.01)
        kwargs = server_cls.call_args.kwargs
        self.assertEqual(kwargs["startup_readiness"]["image_root"], str(eona_root.resolve()))
        self.assertTrue(kwargs["startup_readiness"]["ok"])

    def test_cli_gateway_cleanup_abandoned_json_contract(self) -> None:
        stdout = io.StringIO()
        with (
            mock.patch.object(sys, "argv", ["eona", "gateway", "cleanup-abandoned", "--dry-run", "--json"]),
            redirect_stdout(stdout),
        ):
            exit_code = cli_main()
        payload = json.loads(stdout.getvalue())
        self.assertEqual(exit_code, 0)
        self.assertTrue(payload["ok"])
        self.assertTrue(payload["dry_run"])
        self.assertIn("candidate_count", payload)

    def test_cli_gateway_doctor_json_contract(self) -> None:
        stdout = io.StringIO()
        fake_payload = {
            "ok": True,
            "summary": "Gateway doctor found no issues.",
            "readiness": {"ok": True},
            "imports": {"by_status": {}},
            "runs": {"by_status": {}, "recoverable_merge_runs": []},
            "filesystem": {"orphan_run_dir_count": 0, "orphan_import_session_dir_count": 0},
            "warnings": [],
        }
        with (
            mock.patch.object(sys, "argv", ["eona", "gateway", "doctor", "--json"]),
            mock.patch.object(GatewayService, "doctor", return_value=fake_payload) as doctor_mock,
            redirect_stdout(stdout),
        ):
            exit_code = cli_main()
        payload = json.loads(stdout.getvalue())
        self.assertEqual(exit_code, 0)
        self.assertTrue(payload["ok"])
        self.assertEqual(payload["summary"], "Gateway doctor found no issues.")
        doctor_mock.assert_called_once_with(abandoned_older_than_hours=24.0)

    def test_cli_gateway_doctor_plaintext_surfaces_operational_items(self) -> None:
        stdout = io.StringIO()
        fake_payload = {
            "ok": True,
            "summary": "Gateway doctor found no issues.",
            "details": [],
            "operational_items": [
                {
                    "name": "duplicate_semantic",
                    "priority": "better_have",
                    "summary": "Duplicate semantic enrichment has not been run yet.",
                    "command": "eona-client backfill-duplicate-semantic --incremental --json",
                }
            ],
        }
        with (
            mock.patch.object(sys, "argv", ["eona", "gateway", "doctor"]),
            mock.patch.object(GatewayService, "doctor", return_value=fake_payload),
            redirect_stdout(stdout),
        ):
            exit_code = cli_main()
        output = stdout.getvalue()
        self.assertEqual(exit_code, 0)
        self.assertIn("Gateway doctor found no issues.", output)
        self.assertIn("better_have/duplicate_semantic: Duplicate semantic enrichment has not been run yet.", output)
        self.assertIn("command: eona-client backfill-duplicate-semantic --incremental --json", output)

    def test_cli_gateway_cleanup_terminal_data_json_contract(self) -> None:
        stdout = io.StringIO()
        fake_payload = {
            "ok": True,
            "summary": "Removed transient data for 1 terminal runs.",
            "candidate_count": 1,
            "removed_run_count": 1,
            "removed_file_count": 10,
            "removed_bytes": 1000,
            "dry_run": False,
        }
        with (
            mock.patch.object(sys, "argv", ["eona", "gateway", "cleanup-terminal-data", "--json"]),
            mock.patch.object(GatewayService, "cleanup_terminal_run_data", return_value=fake_payload) as cleanup_mock,
            redirect_stdout(stdout),
        ):
            exit_code = cli_main()
        payload = json.loads(stdout.getvalue())
        self.assertEqual(exit_code, 0)
        self.assertTrue(payload["ok"])
        self.assertEqual(payload["removed_run_count"], 1)
        cleanup_mock.assert_called_once_with(
            older_than_hours=24.0,
            dry_run=False,
            include_recoverable_failed=False,
        )

    def test_serve_gateway_logs_blocked_readiness_reason(self) -> None:
        service = GatewayService()
        with sqlite3.connect(service.paths.database) as connection:
            connection.execute(
                """
                INSERT INTO content(
                    content_id, canonical_spec_version, storage_relpath, mime_type, byte_size, width, height, created_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    "con_missing",
                    1,
                    "content/missing/example.jpg",
                    "image/jpeg",
                    123,
                    10,
                    10,
                    "2026-03-20T00:00:00Z",
                ),
            )
            connection.commit()
        with (
            mock.patch("eona.gateway_server.GatewayService", return_value=service),
            mock.patch("eona.gateway_server.logger") as logger_mock,
            mock.patch("eona.gateway_server.GatewayHTTPServer") as server_cls,
            mock.patch(
                "eona.gateway_service.inspect_gateway_runtime",
                return_value={"ok": True, "lifecycle_state": "ready", "summary": "ok", "warnings": [], "problems": []},
            ),
            mock.patch.object(service, "refresh_content_store_integrity_async"),
        ):
            server_cls.return_value.serve_forever.side_effect = KeyboardInterrupt
            server_cls.return_value.shutdown.return_value = None
            server_cls.return_value.server_close.return_value = None
            self.assertEqual(serve_gateway(host="127.0.0.1", port=8013, poll_interval=0.25), 0)
        logger_mock.error.assert_not_called()

    def test_gateway_readiness_blocks_when_content_bytes_are_missing(self) -> None:
        service = GatewayService()
        with sqlite3.connect(service.paths.database) as connection:
            connection.execute(
                """
                INSERT INTO content(
                    content_id, canonical_spec_version, storage_relpath, mime_type, byte_size, width, height, created_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    "con_missing",
                    1,
                    "content/missing/example.jpg",
                    "image/jpeg",
                    123,
                    10,
                    10,
                    "2026-03-20T00:00:00Z",
                ),
            )
            connection.commit()
        payload = service.readiness()
        self.assertFalse(payload["ok"])
        self.assertEqual(payload["lifecycle_state"], "blocked")
        self.assertEqual(payload["summary"], "Gateway integrity check failed.")
        self.assertEqual(payload["content_store"]["status"], "error")
        self.assertEqual(payload["content_store"]["missing_count"], 1)
        self.assertIn("Mount /data as a complete unit", payload["content_store"]["problems"][0])

    def test_gateway_readiness_blocks_when_storage_fault_is_recorded(self) -> None:
        service = GatewayService()
        service.record_storage_fault(
            error_code="DATABASE_IO_ERROR",
            message="Gateway database storage failed with sqlite disk I/O error: disk I/O error",
        )
        payload = service.readiness()
        self.assertFalse(payload["ok"])
        self.assertEqual(payload["lifecycle_state"], "blocked")
        self.assertEqual(payload["summary"], "Gateway storage check failed.")
        self.assertEqual(payload["storage_fault"]["error_code"], "DATABASE_IO_ERROR")
        self.assertIn("disk I/O error", payload["storage_fault"]["message"])

    def test_gateway_readiness_records_runtime_baseline_on_first_boot(self) -> None:
        service = GatewayService()
        runtime_payload = {
            "ok": True,
            "lifecycle_state": "ready",
            "summary": "Gateway runtime check passed.",
            "warnings": [],
            "problems": [],
            "runtime_identity": {
                "runtime_version": "gateway-v1-dev-a",
                "runtime_image_digest": "sha256:upgrade-a",
                "exiftool_version": "13.40",
                "cadis_version": "0.4.0",
                "cadis_dataset_bundle_version": "bundle-upgrade-a",
                "cadis_dataset_bundle_digest": "sha256:bundle-upgrade-a",
                "canonical_backend": "vips",
                "canonical_spec_version": 2,
            },
        }
        with (
            mock.patch("eona.gateway_service.inspect_gateway_runtime", side_effect=lambda **_: copy.deepcopy(runtime_payload)),
            mock.patch.object(
                service,
                "_content_store_integrity_status",
                return_value={"status": "ok", "summary": "ok", "problems": []},
            ),
        ):
            payload = service.readiness()
        self.assertTrue(payload["ok"])
        self.assertEqual(payload["lifecycle_state"], "ready")
        self.assertEqual(payload["runtime_upgrade"]["status"], "ready")
        self.assertTrue(payload["runtime_upgrade"]["first_boot"])
        with sqlite3.connect(service.paths.database) as connection:
            row = connection.execute(
                "SELECT lifecycle_state, current_runtime_identity_json FROM gateway_runtime_state WHERE state_key = 'current'"
            ).fetchone()
        self.assertIsNotNone(row)
        self.assertEqual(row[0], "ready")
        stored_identity = json.loads(str(row[1]))
        self.assertEqual(stored_identity["runtime_image_digest"], "sha256:upgrade-a")

    def test_gateway_readiness_requires_attention_for_legacy_volume_without_runtime_tracking(self) -> None:
        service = GatewayService()
        runtime_payload = {
            "ok": True,
            "lifecycle_state": "ready",
            "summary": "Gateway runtime check passed.",
            "warnings": [],
            "problems": [],
            "runtime_identity": {
                "runtime_version": "gateway-v1-dev-a",
                "runtime_image_digest": "sha256:legacy-a",
                "exiftool_version": "13.53",
                "cadis_version": "0.4.1",
                "cadis_dataset_bundle_version": "bundle-041",
                "cadis_dataset_bundle_digest": "sha256:041",
                "canonical_backend": "vips",
                "canonical_spec_version": 2,
            },
        }
        with sqlite3.connect(service.paths.database) as connection:
            connection.execute(
                """
                INSERT INTO content(
                    content_id, canonical_spec_version, storage_relpath, mime_type, byte_size, width, height, created_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    "con_legacy",
                    2,
                    "content/legacy/example.jpg",
                    "image/jpeg",
                    123,
                    10,
                    10,
                    "2026-03-20T00:00:00Z",
                ),
            )
            connection.commit()
        with (
            mock.patch("eona.gateway_service.inspect_gateway_runtime", side_effect=lambda **_: copy.deepcopy(runtime_payload)),
            mock.patch.object(
                service,
                "_content_store_integrity_status",
                return_value={"status": "ok", "summary": "ok", "problems": []},
            ),
        ):
            payload = service.readiness()
        self.assertFalse(payload["runtime_upgrade"]["first_boot"])
        self.assertTrue(payload["runtime_upgrade"]["changed"])
        self.assertEqual(payload["runtime_upgrade"]["status"], "needs_attention")
        self.assertEqual(payload["lifecycle_state"], "needs_attention")
        details_text = "\n".join(payload["runtime_upgrade"]["details"])
        self.assertIn("replay upgrade-safe data", details_text)

    def test_gateway_apply_runtime_upgrades_replays_legacy_tracking_volume(self) -> None:
        service = GatewayService()

        class _LegacyUpgradeNormalizer:
            def normalize(self, latitude: float, longitude: float) -> NormalizedLocation:
                return NormalizedLocation(
                    cadis_result_json='{"result":"legacy-upgraded"}',
                    cadis_version="0.4.1",
                    detail="legacy-upgraded",
                )

        runtime_payload = {
            "ok": True,
            "lifecycle_state": "ready",
            "summary": "Gateway runtime check passed.",
            "warnings": [],
            "problems": [],
            "runtime_identity": {
                "runtime_version": "gateway-v1-dev",
                "runtime_image_digest": "sha256:legacy-a",
                "exiftool_version": "13.53",
                "cadis_version": "0.4.1",
                "cadis_dataset_bundle_version": "bundle-041",
                "cadis_dataset_bundle_digest": "sha256:041",
                "canonical_backend": "vips",
                "canonical_spec_version": 2,
            },
        }
        with sqlite3.connect(service.paths.database) as connection:
            connection.execute(
                """
                INSERT INTO content(
                    content_id, canonical_spec_version, storage_relpath, mime_type, byte_size, width, height, created_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    "con_legacy_upgrade",
                    2,
                    "content/legacy/upgrade.jpg",
                    "image/jpeg",
                    123,
                    10,
                    10,
                    "2026-03-20T00:00:00Z",
                ),
            )
            connection.execute(
                """
                INSERT INTO photo(
                    photo_id, content_id, photo_signature, photo_signature_version, signature_payload_json,
                    taken_at_utc, taken_at_original, raw_latitude, raw_longitude, raw_altitude,
                    cadis_result_json, cadis_version, location_detail,
                    camera_make, camera_model, created_at
                ) VALUES (?, ?, ?, 1, '{}', NULL, NULL, ?, ?, NULL, ?, ?, ?, NULL, NULL, '2026-03-20T00:00:00Z')
                """,
                (
                    "pho_legacy_upgrade",
                    "con_legacy_upgrade",
                    "sig-legacy-upgrade",
                    25.0,
                    121.5,
                    '{"old":"legacy"}',
                    "0.3.5",
                    "legacy",
                ),
            )
            connection.commit()

        with mock.patch("eona.gateway_service.inspect_gateway_runtime", side_effect=lambda **_: copy.deepcopy(runtime_payload)):
            result = service.apply_runtime_upgrades(normalizer=_LegacyUpgradeNormalizer())
        self.assertTrue(result["ok"])
        self.assertEqual(result["summary"], "Gateway runtime upgrades applied and pending acceptance.")
        self.assertEqual(result["actions"][0]["module"], "runtime_tracking")
        self.assertEqual(result["actions"][0]["status"], "ready")
        self.assertEqual(result["actions"][0]["details"]["updated"], 1)

        with sqlite3.connect(service.paths.database) as connection:
            connection.row_factory = sqlite3.Row
            photo = connection.execute(
                "SELECT cadis_result_json, cadis_version, location_detail FROM photo WHERE photo_id = ?",
                ("pho_legacy_upgrade",),
            ).fetchone()
            runtime_state = connection.execute(
                "SELECT lifecycle_state, summary FROM gateway_runtime_state WHERE state_key = 'current'"
            ).fetchone()
        self.assertEqual(str(photo["cadis_result_json"]), '{"result":"legacy-upgraded"}')
        self.assertEqual(str(photo["cadis_version"]), "0.4.1")
        self.assertEqual(str(photo["location_detail"]), "legacy-upgraded")
        self.assertEqual(str(runtime_state["lifecycle_state"]), "pending_acceptance")

    def test_gateway_readiness_reports_reimport_suggested_after_runtime_change(self) -> None:
        service = GatewayService()
        first_runtime = {
            "ok": True,
            "lifecycle_state": "ready",
            "summary": "Gateway runtime check passed.",
            "warnings": [],
            "problems": [],
            "runtime_identity": {
                "runtime_version": "gateway-v1-dev-a",
                "runtime_image_digest": "sha256:upgrade-a",
                "exiftool_version": "13.40",
                "cadis_version": "0.4.0",
                "cadis_dataset_bundle_version": "bundle-upgrade-a",
                "cadis_dataset_bundle_digest": "sha256:bundle-upgrade-a",
                "canonical_backend": "vips",
                "canonical_spec_version": 2,
            },
        }
        second_runtime = {
            "ok": True,
            "lifecycle_state": "ready",
            "summary": "Gateway runtime check passed.",
            "warnings": [],
            "problems": [],
            "runtime_identity": {
                "runtime_version": "gateway-v1-dev-b",
                "runtime_image_digest": "sha256:upgrade-b",
                "exiftool_version": "13.53",
                "cadis_version": "0.4.2",
                "cadis_dataset_bundle_version": "bundle-upgrade-b",
                "cadis_dataset_bundle_digest": "sha256:bundle-upgrade-b",
                "canonical_backend": "vips",
                "canonical_spec_version": 3,
            },
        }
        with mock.patch.object(
            service,
            "_content_store_integrity_status",
            return_value={"status": "ok", "summary": "ok", "problems": []},
        ):
            with mock.patch("eona.gateway_service.inspect_gateway_runtime", side_effect=lambda **_: copy.deepcopy(first_runtime)):
                first_payload = service.readiness()
            with mock.patch("eona.gateway_service.inspect_gateway_runtime", side_effect=lambda **_: copy.deepcopy(second_runtime)):
                second_payload = service.readiness()
            with mock.patch("eona.gateway_service.inspect_gateway_runtime", side_effect=lambda **_: copy.deepcopy(second_runtime)):
                repeated_payload = service.readiness()
        self.assertEqual(first_payload["runtime_upgrade"]["status"], "ready")
        self.assertEqual(second_payload["lifecycle_state"], "reimport_suggested")
        self.assertEqual(second_payload["runtime_upgrade"]["status"], "reimport_suggested")
        self.assertTrue(second_payload["runtime_upgrade"]["changed"])
        details_text = "\n".join(second_payload["runtime_upgrade"]["details"])
        self.assertIn("ExifTool runtime changed", details_text)
        self.assertIn("Cadis runtime or dataset bundle changed", details_text)
        self.assertIn("Canonicalization runtime changed", details_text)
        self.assertEqual(repeated_payload["lifecycle_state"], "reimport_suggested")
        self.assertEqual(repeated_payload["runtime_upgrade"]["status"], "reimport_suggested")
        self.assertFalse(repeated_payload["runtime_upgrade"]["changed"])

    def test_serve_gateway_starts_in_checking_state_when_content_integrity_may_be_broken(self) -> None:
        service = GatewayService()
        with sqlite3.connect(service.paths.database) as connection:
            connection.execute(
                """
                INSERT INTO content(
                    content_id, canonical_spec_version, storage_relpath, mime_type, byte_size, width, height, created_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    "con_missing",
                    1,
                    "content/missing/example.jpg",
                    "image/jpeg",
                    123,
                    10,
                    10,
                    "2026-03-20T00:00:00Z",
                ),
            )
            connection.commit()
        with (
            mock.patch("eona.gateway_server.GatewayService", return_value=service),
            mock.patch("eona.gateway_server.GatewayHTTPServer") as server_cls,
            mock.patch(
                "eona.gateway_service.inspect_gateway_runtime",
                return_value={"ok": True, "lifecycle_state": "ready", "summary": "ok", "warnings": [], "problems": []},
            ),
            mock.patch.object(service, "refresh_content_store_integrity_async") as refresh_mock,
        ):
            server_cls.return_value.serve_forever.side_effect = KeyboardInterrupt
            server_cls.return_value.shutdown.return_value = None
            server_cls.return_value.server_close.return_value = None
            self.assertEqual(serve_gateway(host="127.0.0.1", port=8012, poll_interval=0.25), 0)
            kwargs = server_cls.call_args.kwargs
            self.assertEqual(kwargs["startup_readiness"]["lifecycle_state"], "checking")
            self.assertGreaterEqual(refresh_mock.call_count, 1)

    def test_gateway_readiness_can_return_checking_from_cached_path(self) -> None:
        service = GatewayService()
        with mock.patch.object(service, "refresh_content_store_integrity_async") as refresh_mock:
            payload = service.readiness(allow_cached_pending=True)
        self.assertFalse(payload["ok"])
        self.assertEqual(payload["lifecycle_state"], "checking")
        self.assertEqual(payload["content_store"]["status"], "checking")
        refresh_mock.assert_called_once_with()

    def test_gateway_request_handler_blocks_when_dynamic_readiness_turns_blocked(self) -> None:
        service = GatewayService()
        server = object.__new__(GatewayHTTPServer)
        server.gateway_service = service
        server.gateway_worker = mock.Mock()
        server.worker_thread = None
        server.startup_readiness = {"lifecycle_state": "ready"}
        server.access_token = "test-gateway-token"
        server.require_access_token = True
        handler = object.__new__(GatewayRequestHandler)
        handler.server = server
        with mock.patch.object(service, "readiness", return_value={"lifecycle_state": "blocked", "summary": "broken"}):
            blocked = handler._blocked_readiness()
        self.assertEqual(blocked, {"lifecycle_state": "blocked", "summary": "broken"})

    def test_validate_gateway_policy_rejects_non_local_bind_without_explicit_opt_in(self) -> None:
        with self.assertRaisesRegex(Exception, "EONA_GATEWAY_ALLOW_NONLOCAL_BIND=1"):
            validate_gateway_policy(host="0.0.0.0")

    def test_validate_gateway_policy_rejects_missing_required_access_token(self) -> None:
        os.environ.pop("EONA_GATEWAY_ACCESS_TOKEN", None)
        os.environ.pop("EONA_GATEWAY_ACCESS_TOKEN", None)
        with self.assertRaisesRegex(Exception, "EONA_GATEWAY_ACCESS_TOKEN is not configured"):
            validate_gateway_policy(host="127.0.0.1")

    def test_validate_gateway_policy_allows_non_local_bind_with_explicit_opt_in_and_token(self) -> None:
        os.environ["EONA_GATEWAY_ALLOW_NONLOCAL_BIND"] = "1"
        validate_gateway_policy(host="0.0.0.0")

    def test_gateway_request_handler_rejects_missing_bearer_token_on_protected_route(self) -> None:
        server = object.__new__(GatewayHTTPServer)
        server.access_token = "test-gateway-token"
        server.require_access_token = True
        handler = object.__new__(GatewayRequestHandler)
        handler.server = server
        handler.headers = {}
        with mock.patch.object(handler, "_write_auth_error") as auth_error_mock:
            allowed = handler._check_service_auth(method="GET", path="/import-runs")
        self.assertFalse(allowed)
        auth_error_mock.assert_called_once_with(401, "Missing bearer token.")

    def test_gateway_request_handler_accepts_valid_bearer_token_on_protected_route(self) -> None:
        server = object.__new__(GatewayHTTPServer)
        server.access_token = "test-gateway-token"
        server.require_access_token = True
        handler = object.__new__(GatewayRequestHandler)
        handler.server = server
        handler.headers = {"Authorization": "Bearer test-gateway-token"}
        allowed = handler._check_service_auth(method="POST", path="/queries/photo-memory")
        self.assertTrue(allowed)

    def test_gateway_request_handler_allows_public_health_probe_without_token(self) -> None:
        server = object.__new__(GatewayHTTPServer)
        server.access_token = "test-gateway-token"
        server.require_access_token = True
        server.allow_mount_import = False
        handler = object.__new__(GatewayRequestHandler)
        handler.server = server
        handler.headers = {}
        allowed = handler._check_service_auth(method="GET", path="/health/live")
        self.assertTrue(allowed)

    def test_gateway_request_handler_rejects_mount_collection_when_not_allowed(self) -> None:
        server = object.__new__(GatewayHTTPServer)
        server.access_token = "test-gateway-token"
        server.require_access_token = True
        server.allow_mount_import = False
        handler = object.__new__(GatewayRequestHandler)
        handler.server = server
        with mock.patch.object(handler, "_write_json") as write_json_mock:
            allowed = handler._check_mount_collection_allowed()
        self.assertFalse(allowed)
        write_json_mock.assert_called_once_with(
            403,
            {
                "error_code": "IMPORT_MOUNT_NOT_ALLOWED",
                "message": "Mount-backed import is not allowed by this Gateway deployment.",
            },
        )

    def test_gateway_request_handler_allows_mount_collection_when_enabled(self) -> None:
        server = object.__new__(GatewayHTTPServer)
        server.access_token = "test-gateway-token"
        server.require_access_token = True
        server.allow_mount_import = True
        handler = object.__new__(GatewayRequestHandler)
        handler.server = server
        self.assertTrue(handler._check_mount_collection_allowed())

    def test_gateway_request_handler_routes_duplicate_semantic_backfill(self) -> None:
        server = object.__new__(GatewayHTTPServer)
        server.access_token = "test-gateway-token"
        server.require_access_token = True
        server.allow_mount_import = False
        server.start_semantic_job = mock.Mock(return_value=True)
        server.gateway_service = mock.Mock()
        server.gateway_service.get_semantic_enrichment_job.return_value = {
            "job_name": "duplicate_semantic",
            "status": "running",
            "summary": "Computing duplicate semantic enrichment.",
        }
        handler = object.__new__(GatewayRequestHandler)
        handler.server = server
        handler.path = "/semantic-jobs/backfill-duplicate-semantic"
        with (
            mock.patch.object(handler, "_check_service_auth", return_value=True),
            mock.patch.object(handler, "_blocked_readiness", return_value=None),
            mock.patch.object(handler, "_read_json_request", return_value={"limit": 5, "replay_mode": "full_replay"}),
            mock.patch.object(handler, "_write_json") as write_json_mock,
        ):
            handler.do_POST()
        server.start_semantic_job.assert_called_once()
        server.gateway_service.get_semantic_enrichment_job.assert_called_once_with("duplicate_semantic")
        write_json_mock.assert_called_once_with(
            202,
            {
                "ok": True,
                "job_name": "duplicate_semantic",
                "replay_mode": "full_replay",
                "status": "started",
                "summary": "Started duplicate semantic enrichment in the background.",
                "job": {
                    "job_name": "duplicate_semantic",
                    "status": "running",
                    "summary": "Computing duplicate semantic enrichment.",
                },
            },
        )

    def test_gateway_request_handler_routes_tag_backfill(self) -> None:
        server = object.__new__(GatewayHTTPServer)
        server.access_token = "test-gateway-token"
        server.require_access_token = True
        server.allow_mount_import = False
        server.start_semantic_job = mock.Mock(return_value=True)
        server.gateway_service = mock.Mock()
        server.gateway_service.get_semantic_enrichment_job.return_value = {
            "job_name": "has_people",
            "status": "running",
            "summary": "Computing `has_people` semantic enrichment.",
        }
        handler = object.__new__(GatewayRequestHandler)
        handler.server = server
        handler.path = "/semantic-jobs/backfill-tags"
        with (
            mock.patch.object(handler, "_check_service_auth", return_value=True),
            mock.patch.object(handler, "_blocked_readiness", return_value=None),
            mock.patch.object(handler, "_read_json_request", return_value={"tag": "has_people", "limit": 7, "replay_mode": "full_replay"}),
            mock.patch.object(handler, "_write_json") as write_json_mock,
        ):
            handler.do_POST()
        server.start_semantic_job.assert_called_once()
        server.gateway_service.get_semantic_enrichment_job.assert_called_once_with("has_people")
        write_json_mock.assert_called_once_with(
            202,
            {
                "ok": True,
                "job_name": "has_people",
                "tag": "has_people",
                "status": "started",
                "replay_mode": "full_replay",
                "summary": "Started `has_people` semantic enrichment in the background.",
                "job": {
                    "job_name": "has_people",
                    "status": "running",
                    "summary": "Computing `has_people` semantic enrichment.",
                },
            },
        )

    def test_gateway_runtime_inspects_release_manifest_and_required_iso(self) -> None:
        runtime_root = Path(self.temp_dir.name) / "image-root"
        dataset_dir = runtime_root / "runtime" / "cadis" / "datasets" / "GB" / "gb.admin" / "v1.0.0"
        dataset_dir.mkdir(parents=True, exist_ok=True)
        data_file = dataset_dir / "hierarchy.json"
        data_file.write_text('{"ok":true}\n', encoding="utf-8")
        checksum = hashlib.sha256(data_file.read_bytes()).hexdigest()
        manifest = {
            "runtime_version": "gateway-v1-test",
            "tools": {
                "exiftool": {
                    "version": "test",
                    "executable_path": "/bin/sh",
                }
            },
            "dataset_bundle": {
                "version": "gb.admin-v1.0.0",
                "path": "runtime/cadis/datasets",
                "required_iso2": ["GB"],
            },
        }
        manifest_path = runtime_root / "runtime" / "metadata" / "runtime-manifest.json"
        manifest_path.parent.mkdir(parents=True, exist_ok=True)
        manifest_path.write_text(json.dumps(manifest), encoding="utf-8")
        release_manifest = {
            "dataset_id": "gb.admin",
            "country_iso": "GB",
            "dataset_version": "v1.0.0",
            "checksums": {
                "files": {
                    "hierarchy.json": {
                        "sha256": checksum,
                        "size": data_file.stat().st_size,
                    }
                }
            },
        }
        (dataset_dir / "dataset_release_manifest.json").write_text(json.dumps(release_manifest), encoding="utf-8")

        with (
            mock.patch.dict(
                os.environ,
                {
                    "EONA_GATEWAY_IMAGE_ROOT": str(runtime_root),
                },
                clear=False,
            ),
            mock.patch("eona.gateway_runtime._installed_distribution_version", return_value="0.3.5"),
        ):
            payload = inspect_gateway_runtime(strict=True)

        self.assertTrue(payload["ok"])
        self.assertEqual(payload["dataset_bundle"]["installed_iso2"], ["GB"])
        self.assertEqual(payload["dataset_bundle"]["installed_datasets"][0]["status"], "ok")

    def test_gateway_runtime_uses_needs_attention_for_non_blocking_warnings(self) -> None:
        runtime_root = Path(self.temp_dir.name) / "image-root"
        dataset_dir = runtime_root / "runtime" / "cadis" / "datasets" / "GB" / "gb.admin" / "v1.0.0"
        dataset_dir.mkdir(parents=True, exist_ok=True)
        data_file = dataset_dir / "hierarchy.json"
        data_file.write_text('{"ok":true}\n', encoding="utf-8")
        checksum = hashlib.sha256(data_file.read_bytes()).hexdigest()
        manifest = {
            "runtime_version": "gateway-v1-test",
            "tools": {
                "exiftool": {
                    "version": "test",
                    "executable_path": "/bin/sh",
                }
            },
            "dataset_bundle": {
                "version": "gb.admin-v1.0.0",
                "path": "runtime/cadis/datasets",
                "required_iso2": ["GB"],
            },
        }
        manifest_path = runtime_root / "runtime" / "metadata" / "runtime-manifest.json"
        manifest_path.parent.mkdir(parents=True, exist_ok=True)
        manifest_path.write_text(json.dumps(manifest), encoding="utf-8")
        release_manifest = {
            "dataset_id": "gb.admin",
            "country_iso": "GB",
            "dataset_version": "v1.0.0",
            "checksums": {
                "files": {
                    "hierarchy.json": {
                        "sha256": checksum,
                        "size": data_file.stat().st_size,
                    }
                }
            },
        }
        (dataset_dir / "dataset_release_manifest.json").write_text(json.dumps(release_manifest), encoding="utf-8")

        with (
            mock.patch.dict(
                os.environ,
                {
                    "EONA_GATEWAY_IMAGE_ROOT": str(runtime_root),
                },
                clear=False,
            ),
            mock.patch("eona.gateway_runtime._installed_distribution_version", return_value="0.3.5"),
            mock.patch("eona.gateway_runtime.register_gateway_image_support", return_value={"heif": True}),
            mock.patch("PIL.Image.OPEN", {"HEIF": object()}),
        ):
            payload = inspect_gateway_runtime(strict=True)

        self.assertTrue(payload["ok"])
        self.assertEqual(payload["lifecycle_state"], "needs_attention")

    def test_gateway_runtime_reports_missing_heif_decoder(self) -> None:
        runtime_root = Path(self.temp_dir.name) / "image-root"
        manifest_path = runtime_root / "runtime" / "metadata" / "runtime-manifest.json"
        manifest_path.parent.mkdir(parents=True, exist_ok=True)
        manifest_path.write_text(
            json.dumps(
                {
                    "runtime_version": "gateway-v1-test",
                    "tools": {
                        "exiftool": {
                            "version": "test",
                            "executable_path": "/bin/sh",
                        }
                    },
                    "dataset_bundle": {
                        "version": "test",
                        "path": "runtime/cadis/datasets",
                    },
                }
            ),
            encoding="utf-8",
        )
        (runtime_root / "runtime" / "cadis" / "datasets").mkdir(parents=True, exist_ok=True)
        with (
            mock.patch.dict(
                os.environ,
                {
                    "EONA_GATEWAY_IMAGE_ROOT": str(runtime_root),
                    "EONA_GATEWAY_CANONICAL_BACKEND": "pillow",
                },
                clear=False,
            ),
            mock.patch(
                "eona.gateway_runtime._installed_distribution_version",
                side_effect=lambda name: "0.3.5" if name == "cadis" else None,
            ),
            mock.patch("eona.gateway_runtime.register_gateway_image_support", return_value={"heif": False}),
            mock.patch("PIL.Image.OPEN", {}),
        ):
            payload = inspect_gateway_runtime(strict=False)
        self.assertFalse(payload["ok"])
        self.assertIn("HEIC/HEIF decoding is not enabled in the runtime environment", payload["problems"])

    def test_gateway_runtime_requires_vips_when_requested(self) -> None:
        runtime_root = Path(self.temp_dir.name) / "image-root"
        manifest_path = runtime_root / "runtime" / "metadata" / "runtime-manifest.json"
        manifest_path.parent.mkdir(parents=True, exist_ok=True)
        manifest_path.write_text(
            json.dumps(
                {
                    "runtime_version": "gateway-v1-test",
                    "tools": {
                        "exiftool": {
                            "version": "test",
                            "executable_path": "/bin/sh",
                        }
                    },
                    "dataset_bundle": {
                        "version": "test",
                        "path": "runtime/cadis/datasets",
                    },
                }
            ),
            encoding="utf-8",
        )
        (runtime_root / "runtime" / "cadis" / "datasets").mkdir(parents=True, exist_ok=True)
        with (
            mock.patch.dict(
                os.environ,
                {
                    "EONA_GATEWAY_IMAGE_ROOT": str(runtime_root),
                    "EONA_GATEWAY_CANONICAL_BACKEND": "vips",
                },
                clear=False,
            ),
            mock.patch(
                "eona.gateway_runtime._installed_distribution_version",
                side_effect=lambda name: "0.3.5" if name == "cadis" else None,
            ),
            mock.patch("eona.gateway_runtime.register_gateway_image_support", return_value={"heif": False}),
            mock.patch("PIL.Image.OPEN", {}),
            mock.patch(
                "eona.gateway_runtime._inspect_pyvips_runtime",
                return_value={
                    "status": "missing",
                    "version": None,
                    "libvips_version": None,
                    "heif_loader": False,
                },
            ),
        ):
            payload = inspect_gateway_runtime(strict=False)
        self.assertFalse(payload["ok"])
        self.assertEqual(payload["dependencies"]["canonical_backend"]["requested"], "vips")
        self.assertIn(
            "EONA_GATEWAY_CANONICAL_BACKEND=vips but pyvips/libvips is not available. EONA_GATEWAY_CANONICAL_BACKEND is still accepted as a legacy alias.",
            payload["problems"],
        )

    def test_gateway_canonicalizer_prefers_vips_when_available(self) -> None:
        class _FakeVipsImage:
            width = 1200
            height = 900

            def get_typeof(self, _name: str) -> int:
                return 0

            def hasalpha(self) -> bool:
                return False

            def colourspace(self, _space: str):
                return self

            def jpegsave_buffer(self, **_kwargs) -> bytes:
                return b"fake-jpeg"

        class _FakeVipsModule:
            class Image:
                @staticmethod
                def new_from_file(_path: str, access: str = "sequential"):
                    self.assertEqual(access, "sequential")
                    return _FakeVipsImage()

        with mock.patch.dict(os.environ, {}, clear=False):
            with mock.patch("eona.gateway_canonicalize._load_pyvips", return_value=_FakeVipsModule()):
                canonicalizer = GatewayCanonicalizer(root_dir=Path(self.temp_dir.name))
        self.assertEqual(canonicalizer.backend_name, "vips")
        self.assertEqual(canonicalizer.canonical_spec_version, VIPS_CANONICAL_SPEC_VERSION)

    def test_gateway_canonicalizer_falls_back_to_pillow_without_vips(self) -> None:
        with mock.patch.dict(os.environ, {}, clear=False):
            with mock.patch("eona.gateway_canonicalize._load_pyvips", return_value=None):
                canonicalizer = GatewayCanonicalizer(root_dir=Path(self.temp_dir.name))
        self.assertEqual(canonicalizer.backend_name, "pillow")
        self.assertEqual(canonicalizer.canonical_spec_version, PILLOW_CANONICAL_SPEC_VERSION)

    def test_update_gateway_runtime_manifest_script_rewrites_dataset_bundle(self) -> None:
        manifest_path = Path(self.temp_dir.name) / "runtime-manifest.json"
        manifest_path.write_text(
            json.dumps(
                {
                    "runtime_version": "gateway-v1-test",
                    "dataset_bundle": {
                        "version": "old",
                        "path": "/tmp/old",
                        "required_iso2": ["GB"],
                    },
                }
            ),
            encoding="utf-8",
        )
        datasets_root = Path(self.temp_dir.name) / "datasets"
        gb_dir = datasets_root / "GB" / "gb.admin" / "v1.0.0"
        it_dir = datasets_root / "IT" / "it.admin" / "v1.0.0"
        gb_dir.mkdir(parents=True, exist_ok=True)
        it_dir.mkdir(parents=True, exist_ok=True)
        (gb_dir / "dataset_release_manifest.json").write_text(
            json.dumps({"country_iso": "GB", "dataset_id": "gb.admin", "dataset_version": "v1.0.0"}),
            encoding="utf-8",
        )
        (it_dir / "dataset_release_manifest.json").write_text(
            json.dumps({"country_iso": "IT", "dataset_id": "it.admin", "dataset_version": "v1.0.0"}),
            encoding="utf-8",
        )

        script_path = Path(__file__).resolve().parents[1] / "scripts" / "update_gateway_runtime_manifest.py"
        import subprocess

        subprocess.run(
            [
                sys.executable,
                str(script_path),
                "--manifest",
                str(manifest_path),
                "--datasets-root",
                str(datasets_root),
                "--image-datasets-path",
                "/opt/eona/runtime/cadis/datasets",
            ],
            check=True,
        )

        payload = json.loads(manifest_path.read_text(encoding="utf-8"))
        bundle = payload["dataset_bundle"]
        self.assertEqual(bundle["required_iso2"], ["GB", "IT"])
        self.assertEqual([item["country_iso"] for item in bundle["datasets"]], ["GB", "IT"])
        self.assertTrue(bundle["version"].startswith("generated-"))
        self.assertTrue(bundle["bundle_digest"].startswith("sha256:"))

    def test_update_gateway_runtime_manifest_script_check_detects_stale_bundle(self) -> None:
        manifest_path = Path(self.temp_dir.name) / "runtime-manifest.json"
        manifest_path.write_text(
            json.dumps(
                {
                    "runtime_version": "gateway-v1-test",
                    "dataset_bundle": {
                        "version": "stale",
                        "path": "/opt/eona/runtime/cadis/datasets",
                        "required_iso2": ["GB"],
                    },
                }
            ),
            encoding="utf-8",
        )
        datasets_root = Path(self.temp_dir.name) / "datasets"
        gb_dir = datasets_root / "GB" / "gb.admin" / "v1.0.0"
        it_dir = datasets_root / "IT" / "it.admin" / "v1.0.0"
        gb_dir.mkdir(parents=True, exist_ok=True)
        it_dir.mkdir(parents=True, exist_ok=True)
        (gb_dir / "dataset_release_manifest.json").write_text(
            json.dumps({"country_iso": "GB", "dataset_id": "gb.admin", "dataset_version": "v1.0.0"}),
            encoding="utf-8",
        )
        (it_dir / "dataset_release_manifest.json").write_text(
            json.dumps({"country_iso": "IT", "dataset_id": "it.admin", "dataset_version": "v1.0.0"}),
            encoding="utf-8",
        )

        script_path = Path(__file__).resolve().parents[1] / "scripts" / "update_gateway_runtime_manifest.py"
        import subprocess

        result = subprocess.run(
            [
                sys.executable,
                str(script_path),
                "--manifest",
                str(manifest_path),
                "--datasets-root",
                str(datasets_root),
                "--image-datasets-path",
                "/opt/eona/runtime/cadis/datasets",
                "--check",
            ],
            capture_output=True,
            text=True,
        )
        self.assertEqual(result.returncode, 1)
        self.assertIn('"required_iso2": [', result.stdout)

    def test_gateway_runtime_does_not_fall_back_to_path_for_exiftool(self) -> None:
        runtime_root = Path(self.temp_dir.name) / "image-root"
        manifest_path = runtime_root / "runtime" / "metadata" / "runtime-manifest.json"
        manifest_path.parent.mkdir(parents=True, exist_ok=True)
        manifest_path.write_text(
            json.dumps(
                {
                    "runtime_version": "gateway-v1-test",
                    "dataset_bundle": {
                        "version": "test",
                        "path": "runtime/cadis/datasets",
                    },
                }
            ),
            encoding="utf-8",
        )
        with (
            mock.patch.dict(os.environ, {"EONA_GATEWAY_IMAGE_ROOT": str(runtime_root)}, clear=False),
            mock.patch("eona.gateway_runtime._installed_distribution_version", return_value="0.3.5"),
        ):
            payload = inspect_gateway_runtime(strict=False)
        self.assertFalse(payload["ok"])
        self.assertEqual(payload["dependencies"]["exiftool"]["status"], "missing")

    def test_gateway_cadis_runtime_uses_image_dataset_root(self) -> None:
        runtime_root = Path(self.temp_dir.name) / "image-root"
        manifest_path = runtime_root / "runtime" / "metadata" / "runtime-manifest.json"
        manifest_path.parent.mkdir(parents=True, exist_ok=True)
        manifest_path.write_text(
            json.dumps(
                {
                    "runtime_version": "gateway-v1-test",
                    "dataset_bundle": {
                        "version": "test",
                        "path": "runtime/cadis/datasets",
                    },
                }
            ),
            encoding="utf-8",
        )
        with mock.patch.dict(os.environ, {"EONA_GATEWAY_IMAGE_ROOT": str(runtime_root)}, clear=False):
            cache_dir, is_mutable = get_effective_cadis_cache_dir()
        self.assertEqual(cache_dir, (runtime_root / "runtime" / "cadis" / "datasets").resolve())
        self.assertFalse(is_mutable)
