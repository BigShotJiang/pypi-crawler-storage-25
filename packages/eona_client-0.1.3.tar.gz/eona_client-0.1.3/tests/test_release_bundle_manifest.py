from __future__ import annotations

import hashlib
import json
import sys
import tarfile
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from scripts.write_release_bundle_manifest import build_release_bundle_manifest


class ReleaseBundleManifestTests(unittest.TestCase):
    def setUp(self) -> None:
        self.temp_dir = tempfile.TemporaryDirectory(prefix="g5-release-bundle-", dir="/tmp")
        self.addCleanup(self.temp_dir.cleanup)
        self.root = Path(self.temp_dir.name)

    def test_build_release_bundle_manifest_binds_release_label_and_artifacts(self) -> None:
        release_dir = self.root / "eona-macos-arm64-0.1.0"
        (release_dir / "release").mkdir(parents=True, exist_ok=True)
        embedded_release_manifest = {
            "release_version": "0.1.0",
            "runtime_manifest": {
                "path": "runtime/metadata/runtime-manifest.json",
                "sha256": "abc123",
            },
        }
        (release_dir / "release" / "release-manifest.json").write_text(
            json.dumps(embedded_release_manifest),
            encoding="utf-8",
        )

        macos_archive = self.root / "eona-macos-arm64-0.1.0.tar.gz"
        with tarfile.open(macos_archive, "w:gz") as archive:
            archive.add(release_dir, arcname=release_dir.name)

        client_wheel = self.root / "eona_client-0.1.0-py3-none-any.whl"
        client_wheel.write_bytes(b"wheel")
        client_sdist = self.root / "eona_client-0.1.0.tar.gz"
        client_sdist.write_bytes(b"sdist")

        payload = build_release_bundle_manifest(
            release_tag="v0.1.0",
            release_version="0.1.0",
            macos_archive=macos_archive,
            client_artifacts=[client_wheel, client_sdist],
            docker_image="ghcr.io/example/eona-gateway:0.1.0",
            docker_digest="sha256:deadbeef",
        )

        self.assertEqual(payload["release_tag"], "v0.1.0")
        self.assertEqual(payload["release_version"], "0.1.0")
        self.assertEqual(payload["artifacts"]["docker"]["digest"], "sha256:deadbeef")
        self.assertEqual(payload["artifacts"]["macos"]["filename"], macos_archive.name)
        self.assertEqual(payload["artifacts"]["macos"]["runtime_manifest"]["sha256"], "abc123")
        self.assertEqual(
            payload["artifacts"]["macos"]["release_manifest"]["sha256"],
            hashlib.sha256(json.dumps(embedded_release_manifest).encode("utf-8")).hexdigest(),
        )
        client_entries = payload["artifacts"]["client"]
        self.assertEqual(
            sorted(entry["filename"] for entry in client_entries),
            sorted([client_sdist.name, client_wheel.name]),
        )
        by_name = {entry["filename"]: entry["sha256"] for entry in client_entries}
        self.assertEqual(by_name[client_sdist.name], hashlib.sha256(client_sdist.read_bytes()).hexdigest())


if __name__ == "__main__":
    unittest.main()
