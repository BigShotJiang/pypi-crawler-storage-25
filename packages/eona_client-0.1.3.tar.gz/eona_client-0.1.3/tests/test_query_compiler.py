from __future__ import annotations

import unittest
from pathlib import Path

import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from eona.query_compiler import QueryValidationError, compile_photo_memory_query


class QueryCompilerTests(unittest.TestCase):
    def test_compile_simple_count_query(self) -> None:
        compiled = compile_photo_memory_query(
            {
                "query_version": 1,
                "anchor": {"entity": "photo"},
                "select": [{"entity": "photo", "attribute": "id", "aggregation": "count"}],
                "filters": [{"entity": "time", "attribute": "year", "operator": "==", "value": 2025}],
            }
        )

        self.assertEqual(
            compiled.sql,
            "\n".join(
                [
                    "SELECT",
                    "  COUNT(DISTINCT p.photo_id) AS photo_count",
                    "FROM gateway_query_photo_v2 AS p",
                    "WHERE COALESCE(p.duplicate_exclude_by_default, 0) = 0\n  AND p.query_year = ?",
                    "LIMIT ?",
                ]
            ),
        )
        self.assertEqual(compiled.params, (2025, 20))
        self.assertEqual(compiled.columns, [{"name": "photo_count", "type": "integer"}])
        self.assertEqual(compiled.capabilities_used, ["photo", "time"])

    def test_compile_path_filter_uses_inner_join(self) -> None:
        compiled = compile_photo_memory_query(
            {
                "query_version": 1,
                "anchor": {"entity": "photo"},
                "select": [{"entity": "photo", "attribute": "id", "aggregation": "count"}],
                "filters": [{"entity": "path", "attribute": "text", "operator": "contains", "value": "Kyoto"}],
                "limit": 10,
            }
        )

        self.assertIn("INNER JOIN gateway_query_path_v1 AS path ON path.photo_id = p.photo_id", compiled.sql)
        self.assertIn("WHERE COALESCE(p.duplicate_exclude_by_default, 0) = 0", compiled.sql)
        self.assertEqual(compiled.params, ("%Kyoto%", 10))
        self.assertEqual(compiled.resolved_plan["limit"], 10)

    def test_compile_location_filter_uses_location_view(self) -> None:
        compiled = compile_photo_memory_query(
            {
                "query_version": 1,
                "anchor": {"entity": "photo"},
                "select": [{"entity": "photo", "attribute": "id", "aggregation": "count"}],
                "filters": [{"entity": "location", "attribute": "country", "operator": "==", "value": "Japan"}],
                "limit": 10,
            }
        )

        self.assertIn("INNER JOIN gateway_query_location_v2 AS location ON location.photo_id = p.photo_id", compiled.sql)
        self.assertIn("location.query_country = ?", compiled.sql)
        self.assertEqual(compiled.params, ("Japan", 10))
        self.assertEqual(compiled.capabilities_used, ["location", "photo"])

    def test_compile_location_admin_label_filter_uses_contains(self) -> None:
        compiled = compile_photo_memory_query(
            {
                "query_version": 1,
                "anchor": {"entity": "photo"},
                "select": [{"entity": "photo", "attribute": "id", "aggregation": "count"}],
                "filters": [{"entity": "location", "attribute": "admin_label", "operator": "contains", "value": "Venezia"}],
                "limit": 10,
            }
        )

        self.assertIn("location.query_admin_label LIKE ?", compiled.sql)
        self.assertEqual(compiled.params, ("%Venezia%", 10))
        self.assertEqual(compiled.capabilities_used, ["location", "photo"])

    def test_compile_tag_filter_uses_tag_view(self) -> None:
        compiled = compile_photo_memory_query(
            {
                "query_version": 1,
                "anchor": {"entity": "photo"},
                "select": [{"entity": "photo", "attribute": "id", "aggregation": "count"}],
                "filters": [
                    {"entity": "tag", "attribute": "key", "operator": "==", "value": "has_people"},
                    {"entity": "tag", "attribute": "value", "operator": "==", "value": "true"},
                ],
                "limit": 10,
            }
        )

        self.assertIn("INNER JOIN gateway_query_tag_v1 AS tag ON tag.photo_id = p.photo_id", compiled.sql)
        self.assertIn("tag.tag_key = ?", compiled.sql)
        self.assertIn("tag.tag_value = ?", compiled.sql)
        self.assertEqual(compiled.params, ("has_people", "true", 10))
        self.assertEqual(compiled.capabilities_used, ["photo", "tag"])

    def test_compile_hostile_string_is_parameterized(self) -> None:
        payload = "' OR 1=1 --"
        compiled = compile_photo_memory_query(
            {
                "query_version": 1,
                "anchor": {"entity": "photo"},
                "select": [{"entity": "photo", "attribute": "id", "aggregation": "count"}],
                "filters": [{"entity": "path", "attribute": "text", "operator": "contains", "value": payload}],
                "limit": 10,
            }
        )

        self.assertIn("path.path_text LIKE ?", compiled.sql)
        self.assertNotIn(payload, compiled.sql)
        self.assertEqual(compiled.params, (f"%{payload}%", 10))

    def test_compile_hostile_drop_table_string_is_parameterized(self) -> None:
        payload = "Venezia'); DROP TABLE photo; --"
        compiled = compile_photo_memory_query(
            {
                "query_version": 1,
                "anchor": {"entity": "photo"},
                "select": [{"entity": "photo", "attribute": "id", "aggregation": "count"}],
                "filters": [{"entity": "location", "attribute": "admin_label", "operator": "contains", "value": payload}],
                "limit": 10,
            }
        )

        self.assertIn("location.query_admin_label LIKE ?", compiled.sql)
        self.assertNotIn(payload, compiled.sql)
        self.assertEqual(compiled.params, (f"%{payload}%", 10))

    def test_compile_grouped_camera_query(self) -> None:
        compiled = compile_photo_memory_query(
            {
                "query_version": 1,
                "anchor": {"entity": "camera"},
                "select": [
                    {"entity": "camera", "attribute": "model"},
                    {"entity": "photo", "attribute": "id", "aggregation": "count"},
                ],
                "group_by": [{"entity": "camera", "attribute": "model"}],
                "sort_by": [{"entity": "photo", "attribute": "id", "aggregation": "count", "order": "desc"}],
                "limit": 10,
            }
        )

        self.assertEqual(
            compiled.sql,
            "\n".join(
                [
                    "SELECT",
                    "  p.camera_model AS camera_model,\n  COUNT(DISTINCT p.photo_id) AS photo_count",
                    "FROM gateway_query_photo_v2 AS p",
                    "WHERE COALESCE(p.duplicate_exclude_by_default, 0) = 0",
                    "GROUP BY p.camera_model",
                    "ORDER BY COUNT(DISTINCT p.photo_id) DESC",
                    "LIMIT ?",
                ]
            ),
        )
        self.assertEqual(compiled.params, (10,))
        self.assertEqual(
            compiled.columns,
            [
                {"name": "camera_model", "type": "string"},
                {"name": "photo_count", "type": "integer"},
            ],
        )

    def test_compile_non_aggregate_selects_default_group_by(self) -> None:
        compiled = compile_photo_memory_query(
            {
                "query_version": 1,
                "anchor": {"entity": "time"},
                "select": [
                    {"entity": "time", "attribute": "year"},
                    {"entity": "photo", "attribute": "id", "aggregation": "count"},
                ],
                "sort_by": [{"entity": "time", "attribute": "year", "order": "asc"}],
            }
        )

        self.assertIn("GROUP BY p.query_year", compiled.sql)
        self.assertIn("ORDER BY p.query_year ASC", compiled.sql)
        self.assertIn("WHERE COALESCE(p.duplicate_exclude_by_default, 0) = 0", compiled.sql)
        self.assertEqual(compiled.resolved_plan["group_by"], [{"entity": "time", "attribute": "year", "alias": "time_year"}])

    def test_compile_in_filter_parameterizes_all_values(self) -> None:
        compiled = compile_photo_memory_query(
            {
                "query_version": 1,
                "anchor": {"entity": "camera"},
                "select": [{"entity": "camera", "attribute": "model"}],
                "filters": [{"entity": "camera", "attribute": "model", "operator": "in", "value": ["iphone", "pixel"]}],
            }
        )

        self.assertIn("WHERE COALESCE(p.duplicate_exclude_by_default, 0) = 0", compiled.sql)
        self.assertIn("p.camera_model IN (?, ?)", compiled.sql)
        self.assertEqual(compiled.params, ("iphone", "pixel", 20))

    def test_rejects_unsupported_entity(self) -> None:
        with self.assertRaisesRegex(QueryValidationError, "Unsupported entity `trip`"):
            compile_photo_memory_query(
                {
                    "query_version": 1,
                    "anchor": {"entity": "photo"},
                    "select": [{"entity": "trip", "attribute": "country"}],
                }
            )

    def test_rejects_invalid_limit(self) -> None:
        with self.assertRaisesRegex(QueryValidationError, "`limit` must be between 1 and 500"):
            compile_photo_memory_query(
                {
                    "query_version": 1,
                    "anchor": {"entity": "photo"},
                    "select": [{"entity": "photo", "attribute": "id", "aggregation": "count"}],
                    "limit": 0,
                }
            )


if __name__ == "__main__":
    unittest.main()
