from __future__ import annotations

import io
import json
import os
import subprocess
import sys
import tempfile
import unittest
from contextlib import redirect_stderr, redirect_stdout
from pathlib import Path
from unittest import mock

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from eona.client_cli import main as client_cli_main
from eona.gateway_client import GatewayClientError


class ClientCliTests(unittest.TestCase):
    def setUp(self) -> None:
        self.temp_dir = tempfile.TemporaryDirectory(prefix="g5-client-cli-", dir="/tmp")
        self.addCleanup(self.temp_dir.cleanup)
        self.photos_dir = Path(self.temp_dir.name) / "photos"
        self.photos_dir.mkdir(parents=True, exist_ok=True)

    def test_import_by_upload_requires_gateway_url(self) -> None:
        stderr = io.StringIO()
        with (
            mock.patch.object(sys, "argv", ["eona-client", "import", str(self.photos_dir), "--by-upload"]),
            redirect_stderr(stderr),
        ):
            with self.assertRaises(SystemExit) as exc:
                client_cli_main()
        self.assertEqual(exc.exception.code, 2)
        self.assertIn("requires `--gateway-url`", stderr.getvalue())

    def test_import_by_mount_rejects_gateway_url(self) -> None:
        stderr = io.StringIO()
        with (
            mock.patch.object(
                sys,
                "argv",
                ["eona-client", "import", str(self.photos_dir), "--by-mount", "--gateway-url", "http://127.0.0.1:18000"],
            ),
            redirect_stderr(stderr),
        ):
            with self.assertRaises(SystemExit) as exc:
                client_cli_main()
        self.assertEqual(exc.exception.code, 2)
        self.assertIn("does not allow `--gateway-url`", stderr.getvalue())

    def test_import_by_mount_json_contract(self) -> None:
        stdout = io.StringIO()
        with (
            mock.patch.object(
                sys,
                "argv",
                ["eona-client", "import", str(self.photos_dir), "--by-mount", "--json"],
            ),
            mock.patch("eona.client_cli.import_path_to_gateway") as import_mock,
            redirect_stdout(stdout),
        ):
            import_mock.return_value = {
                "ok": True,
                "status": "queued",
                "photo_folder": str(self.photos_dir),
                "file_count": 2,
                "import_id": "imp_local",
                "run_id": "run_local",
                "collection_mode": "mount",
            }
            exit_code = client_cli_main()
        payload = json.loads(stdout.getvalue())
        self.assertEqual(exit_code, 0)
        self.assertEqual(payload["collection_mode"], "mount")
        self.assertEqual(import_mock.call_args.kwargs["collection_mode"], "mount")
        self.assertEqual(import_mock.call_args.kwargs["base_url"], "http://127.0.0.1:8000")

    def test_import_by_upload_json_contract(self) -> None:
        stdout = io.StringIO()
        with (
            mock.patch.object(
                sys,
                "argv",
                [
                    "eona-client",
                    "import",
                    str(self.photos_dir),
                    "--by-upload",
                    "--gateway-url",
                    "http://127.0.0.1:18000",
                    "--json",
                ],
            ),
            mock.patch("eona.client_cli.import_path_to_gateway") as import_mock,
            redirect_stdout(stdout),
        ):
            import_mock.return_value = {
                "ok": True,
                "status": "queued",
                "photo_folder": str(self.photos_dir),
                "file_count": 3,
                "import_id": "imp_remote",
                "run_id": "run_remote",
                "collection_mode": "upload",
            }
            exit_code = client_cli_main()
        payload = json.loads(stdout.getvalue())
        self.assertEqual(exit_code, 0)
        self.assertEqual(payload["collection_mode"], "upload")
        self.assertEqual(import_mock.call_args.kwargs["collection_mode"], "upload")
        self.assertEqual(import_mock.call_args.kwargs["base_url"], "http://127.0.0.1:18000")

    def test_import_plaintext_surfaces_queue_guidance(self) -> None:
        stdout = io.StringIO()
        with (
            mock.patch.object(
                sys,
                "argv",
                ["eona-client", "import", str(self.photos_dir), "--by-mount"],
            ),
            mock.patch("eona.client_cli.import_path_to_gateway") as import_mock,
            redirect_stdout(stdout),
        ):
            import_mock.return_value = {
                "ok": True,
                "status": "queued",
                "photo_folder": str(self.photos_dir),
                "file_count": 2,
                "import_id": "imp_local",
                "run_id": "run_local",
                "collection_mode": "mount",
            }
            exit_code = client_cli_main()
        output = stdout.getvalue()
        self.assertEqual(exit_code, 0)
        self.assertIn("Queued 2 file(s) to Gateway.", output)
        self.assertIn("Import was queued as run_local.", output)

    def test_health_json_contract(self) -> None:
        stdout = io.StringIO()
        with (
            mock.patch.object(sys, "argv", ["eona-client", "health", "--gateway-url", "http://127.0.0.1:18000", "--json"]),
            mock.patch("eona.client_cli.health_check_gateway") as health_mock,
            redirect_stdout(stdout),
        ):
            health_mock.return_value = {
                "ok": True,
                "base_url": "http://127.0.0.1:18000",
                "checks": {
                    "live": {"ok": True},
                    "ready": {"ok": True},
                    "health": {"ok": True},
                },
            }
            exit_code = client_cli_main()
        payload = json.loads(stdout.getvalue())
        self.assertEqual(exit_code, 0)
        self.assertTrue(payload["ok"])
        health_mock.assert_called_once()

    def test_health_plaintext_surfaces_operational_summary(self) -> None:
        stdout = io.StringIO()
        with (
            mock.patch.object(sys, "argv", ["eona-client", "health", "--gateway-url", "http://127.0.0.1:18000"]),
            mock.patch("eona.client_cli.health_check_gateway") as health_mock,
            redirect_stdout(stdout),
        ):
            health_mock.return_value = {
                "ok": True,
                "checks": {
                    "live": {"ok": True},
                    "ready": {"ok": True},
                    "health": {
                        "ok": True,
                        "operational_summary": {
                            "user_message": "Eona is usable now. Optional improvements are available.",
                            "required_actions": [],
                            "recommended_actions": [
                                {
                                    "name": "duplicate_semantic",
                                    "what_it_is": "Duplicate cleanup",
                                    "command": "eona-client backfill-duplicate-semantic --incremental --json",
                                }
                            ],
                        },
                    },
                },
            }
            exit_code = client_cli_main()
        output = stdout.getvalue()
        self.assertEqual(exit_code, 0)
        self.assertIn("Gateway health checks passed.", output)
        self.assertIn("Eona is usable now. Optional improvements are available.", output)
        self.assertIn("recommended/duplicate_semantic: Duplicate cleanup", output)

    def test_status_json_contract(self) -> None:
        stdout = io.StringIO()
        with (
            mock.patch.object(
                sys,
                "argv",
                ["eona-client", "status", "--run-id", "run_123", "--gateway-url", "http://127.0.0.1:18000", "--json"],
            ),
            mock.patch("eona.client_cli.get_import_run") as status_mock,
            redirect_stdout(stdout),
        ):
            status_mock.return_value = {
                "ok": True,
                "run_id": "run_123",
                "status": "complete",
            }
            exit_code = client_cli_main()
        payload = json.loads(stdout.getvalue())
        self.assertEqual(exit_code, 0)
        self.assertEqual(payload["run_id"], "run_123")
        status_mock.assert_called_once_with(
            "run_123",
            base_url="http://127.0.0.1:18000",
            access_token=None,
        )

    def test_status_plaintext_surfaces_semantic_recommendations(self) -> None:
        stdout = io.StringIO()
        with (
            mock.patch.object(
                sys,
                "argv",
                ["eona-client", "status", "--run-id", "run_123", "--gateway-url", "http://127.0.0.1:18000"],
            ),
            mock.patch("eona.client_cli.get_import_run") as status_mock,
            redirect_stdout(stdout),
        ):
            status_mock.return_value = {
                "ok": True,
                "run_id": "run_123",
                "status": "complete",
                "report": {
                    "semantic_enrichment_suggestions": [
                        {
                            "job_name": "duplicate_semantic",
                            "summary": "Reduce export and burst duplicates in photo-memory queries.",
                            "command": "eona-client backfill-duplicate-semantic --incremental --json",
                        }
                    ]
                },
            }
            exit_code = client_cli_main()
        output = stdout.getvalue()
        self.assertEqual(exit_code, 0)
        self.assertIn("Gateway import run run_123 fetched.", output)
        self.assertIn("Eona is usable now and optional semantic improvements are available.", output)
        self.assertIn("recommended/duplicate_semantic: Reduce export and burst duplicates in photo-memory queries.", output)

    def test_doctor_json_contract(self) -> None:
        stdout = io.StringIO()
        with (
            mock.patch.object(
                sys,
                "argv",
                ["eona-client", "doctor", "--gateway-url", "http://127.0.0.1:18000", "--json"],
            ),
            mock.patch("eona.client_cli.doctor_gateway") as doctor_mock,
            redirect_stdout(stdout),
        ):
            doctor_mock.return_value = {
                "ok": True,
                "summary": "Gateway doctor found no issues.",
                "details": [],
            }
            exit_code = client_cli_main()
        payload = json.loads(stdout.getvalue())
        self.assertEqual(exit_code, 0)
        self.assertEqual(payload["summary"], "Gateway doctor found no issues.")
        doctor_mock.assert_called_once_with(
            base_url="http://127.0.0.1:18000",
            access_token=None,
            abandoned_older_than_hours=24.0,
        )

    def test_backfill_duplicate_semantic_json_contract(self) -> None:
        stdout = io.StringIO()
        with (
            mock.patch.object(
                sys,
                "argv",
                ["eona-client", "backfill-duplicate-semantic", "--gateway-url", "http://127.0.0.1:18000", "--limit", "5", "--json"],
            ),
            mock.patch("eona.client_cli.backfill_duplicate_semantics") as duplicate_mock,
            redirect_stdout(stdout),
        ):
            duplicate_mock.return_value = {
                "ok": True,
                "summary": "Computed duplicate semantics for 5 photo(s).",
                "scanned": 5,
                "assigned": 5,
            }
            exit_code = client_cli_main()
        payload = json.loads(stdout.getvalue())
        self.assertEqual(exit_code, 0)
        self.assertEqual(payload["assigned"], 5)
        duplicate_mock.assert_called_once_with(
            replay_mode="incremental",
            base_url="http://127.0.0.1:18000",
            access_token=None,
            limit=5,
        )

    def test_backfill_duplicate_semantic_full_replay_json_contract(self) -> None:
        stdout = io.StringIO()
        with (
            mock.patch.object(
                sys,
                "argv",
                [
                    "eona-client",
                    "backfill-duplicate-semantic",
                    "--gateway-url",
                    "http://127.0.0.1:18000",
                    "--full-replay",
                    "--json",
                ],
            ),
            mock.patch("eona.client_cli.backfill_duplicate_semantics") as duplicate_mock,
            redirect_stdout(stdout),
        ):
            duplicate_mock.return_value = {
                "ok": True,
                "summary": "Started duplicate semantic enrichment in the background.",
                "status": "started",
                "job_name": "duplicate_semantic",
                "replay_mode": "full_replay",
            }
            exit_code = client_cli_main()
        payload = json.loads(stdout.getvalue())
        self.assertEqual(exit_code, 0)
        self.assertEqual(payload["replay_mode"], "full_replay")
        duplicate_mock.assert_called_once_with(
            replay_mode="full_replay",
            base_url="http://127.0.0.1:18000",
            access_token=None,
            limit=None,
        )

    def test_backfill_duplicate_semantic_plaintext_guidance(self) -> None:
        stdout = io.StringIO()
        with (
            mock.patch.object(
                sys,
                "argv",
                ["eona-client", "backfill-duplicate-semantic", "--gateway-url", "http://127.0.0.1:18000"],
            ),
            mock.patch("eona.client_cli.backfill_duplicate_semantics") as duplicate_mock,
            redirect_stdout(stdout),
        ):
            duplicate_mock.return_value = {
                "ok": True,
                "summary": "Started duplicate semantic enrichment in the background.",
                "status": "started",
                "job_name": "duplicate_semantic",
            }
            exit_code = client_cli_main()
        output = stdout.getvalue()
        self.assertEqual(exit_code, 0)
        self.assertIn("Started duplicate semantic enrichment in the background.", output)
        self.assertIn("Duplicate semantic enrichment is running in the background.", output)
        self.assertIn("Use `eona-client health` or `eona-client doctor` to monitor progress.", output)

    def test_backfill_tags_json_contract(self) -> None:
        stdout = io.StringIO()
        with (
            mock.patch.object(
                sys,
                "argv",
                ["eona-client", "backfill-tags", "--tag", "has_people", "--gateway-url", "http://127.0.0.1:18000", "--limit", "7", "--json"],
            ),
            mock.patch("eona.client_cli.backfill_tags") as tags_mock,
            redirect_stdout(stdout),
        ):
            tags_mock.return_value = {
                "ok": True,
                "summary": "Backfilled `has_people` semantic tags for 7 photo(s).",
                "tag": "has_people",
                "updated": 7,
            }
            exit_code = client_cli_main()
        payload = json.loads(stdout.getvalue())
        self.assertEqual(exit_code, 0)
        self.assertEqual(payload["tag"], "has_people")
        tags_mock.assert_called_once_with(
            tag="has_people",
            replay_mode="incremental",
            base_url="http://127.0.0.1:18000",
            access_token=None,
            limit=7,
        )

    def test_backfill_tags_full_replay_json_contract(self) -> None:
        stdout = io.StringIO()
        with (
            mock.patch.object(
                sys,
                "argv",
                [
                    "eona-client",
                    "backfill-tags",
                    "--tag",
                    "has_people",
                    "--gateway-url",
                    "http://127.0.0.1:18000",
                    "--full-replay",
                    "--json",
                ],
            ),
            mock.patch("eona.client_cli.backfill_tags") as tags_mock,
            redirect_stdout(stdout),
        ):
            tags_mock.return_value = {
                "ok": True,
                "summary": "Backfilled `has_people` semantic tags for 10 photo(s) using full_replay mode.",
                "tag": "has_people",
                "updated": 10,
            }
            exit_code = client_cli_main()
        payload = json.loads(stdout.getvalue())
        self.assertEqual(exit_code, 0)
        self.assertEqual(payload["tag"], "has_people")
        tags_mock.assert_called_once_with(
            tag="has_people",
            replay_mode="full_replay",
            base_url="http://127.0.0.1:18000",
            access_token=None,
            limit=None,
        )

    def test_backfill_tags_plaintext_guidance(self) -> None:
        stdout = io.StringIO()
        with (
            mock.patch.object(
                sys,
                "argv",
                ["eona-client", "backfill-tags", "--tag", "has_people", "--gateway-url", "http://127.0.0.1:18000"],
            ),
            mock.patch("eona.client_cli.backfill_tags") as tags_mock,
            redirect_stdout(stdout),
        ):
            tags_mock.return_value = {
                "ok": True,
                "summary": "Started `has_people` semantic enrichment in the background.",
                "tag": "has_people",
                "status": "started",
            }
            exit_code = client_cli_main()
        output = stdout.getvalue()
        self.assertEqual(exit_code, 0)
        self.assertIn("Started `has_people` semantic enrichment in the background.", output)
        self.assertIn("`has_people` semantic enrichment is running in the background.", output)
        self.assertIn("Use `eona-client health` or `eona-client doctor` to monitor progress.", output)

    def test_client_error_json_contract(self) -> None:
        stdout = io.StringIO()
        with (
            mock.patch.object(sys, "argv", ["eona-client", "health", "--json"]),
            mock.patch("eona.client_cli.health_check_gateway", side_effect=GatewayClientError("boom")),
            redirect_stdout(stdout),
        ):
            exit_code = client_cli_main()
        payload = json.loads(stdout.getvalue())
        self.assertEqual(exit_code, 1)
        self.assertEqual(payload["summary"], "Gateway client request failed.")
        self.assertEqual(payload["details"], ["boom"])

    def test_importing_client_cli_does_not_pull_heavy_runtime_modules(self) -> None:
        env = os.environ.copy()
        env["PYTHONPATH"] = str(Path(__file__).resolve().parents[1] / "src")
        probe = subprocess.run(
            [
                sys.executable,
                "-c",
                (
                    "import json, sys; "
                    "import eona.client_cli; "
                    "offenders = sorted("
                    "name for name in sys.modules "
                    "if name == 'cv2' "
                    "or name.startswith('PIL') "
                    "or name.startswith('pyvips') "
                    "or name == 'eona.cli' "
                    "or name.startswith('eona.gateway_server') "
                    "or name.startswith('eona.gateway_service') "
                    "or name.startswith('eona.gateway_runtime')"
                    "); "
                    "print(json.dumps(offenders))"
                ),
            ],
            capture_output=True,
            text=True,
            env=env,
            check=True,
        )
        offenders = json.loads(probe.stdout)
        self.assertEqual(offenders, [])


if __name__ == "__main__":
    unittest.main()
