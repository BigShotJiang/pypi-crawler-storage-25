from __future__ import annotations

import logging
import sqlite3
import threading
import time

from eona.errors import EonaCliError
from eona.gateway_merge import GatewayMergeRunner
from eona.gateway_pipeline import GatewayPipelineRunner
from eona.gateway_service import GatewayPauseRequested, GatewayService, GatewayServiceError

logger = logging.getLogger(__name__)


def _is_retryable_locked_error(exc: sqlite3.OperationalError) -> bool:
    return "locked" in str(exc).lower()


def _is_disk_io_error(exc: sqlite3.OperationalError) -> bool:
    return "disk i/o error" in str(exc).lower()


class GatewayWorkerLoop:
    def __init__(
        self,
        *,
        service: GatewayService,
        poll_interval: float = 0.25,
        pipeline_runner: GatewayPipelineRunner | None = None,
        merge_runner: GatewayMergeRunner | None = None,
    ) -> None:
        self.service = service
        self.poll_interval = poll_interval
        self.pipeline_runner = pipeline_runner or GatewayPipelineRunner(service=service)
        self.merge_runner = merge_runner or GatewayMergeRunner(service=service)
        self._stop_event = threading.Event()
        self._graceful_stop_event = threading.Event()
        self._current_run_id_lock = threading.Lock()
        self._current_run_id: str | None = None

    @property
    def current_run_id(self) -> str | None:
        with self._current_run_id_lock:
            return self._current_run_id

    def _set_current_run_id(self, run_id: str | None) -> None:
        with self._current_run_id_lock:
            self._current_run_id = run_id

    def request_graceful_stop(self) -> None:
        self._graceful_stop_event.set()

    def run_forever(self) -> None:
        while not self._stop_event.is_set():
            if self._graceful_stop_event.is_set() and self.current_run_id is None:
                return
            try:
                claimed = self.service.claim_next_run()
            except sqlite3.OperationalError as exc:
                if _is_retryable_locked_error(exc):
                    logger.warning("Gateway worker retrying after locked database")
                    self._stop_event.wait(self.poll_interval)
                    continue
                if _is_disk_io_error(exc):
                    message = f"Gateway database storage failed with sqlite disk I/O error: {exc}"
                    logger.error(message)
                    self.service.record_storage_fault(error_code="DATABASE_IO_ERROR", message=message)
                    return
                raise
            except GatewayServiceError as exc:
                logger.warning("Gateway worker retrying after service error during claim: %s", exc)
                self._stop_event.wait(self.poll_interval)
                continue
            if claimed is None:
                if self._graceful_stop_event.is_set():
                    return
                self._stop_event.wait(self.poll_interval)
                continue
            run_id = str(claimed["run_id"])
            self._set_current_run_id(run_id)
            try:
                resume_from_stage = self.service.resume_from_stage(run_id)
                if resume_from_stage in {"SQLITE_WRITE", "CANONICALIZATION", "MERGE"}:
                    self.service.resume_paused_merge_run(run_id, merge_runner=self.merge_runner)
                    continue
                self.service.seal_run_input(run_id)
                pipeline_report = self.pipeline_runner.execute_run(run_id)
                report = self.merge_runner.execute_run(run_id)
                report_payload = report.as_dict()
                report_payload["failed_item_count"] += int(pipeline_report.get("failed_item_count", 0))
                self.service.complete_run(run_id, report=report_payload)
            except sqlite3.OperationalError as exc:
                if _is_disk_io_error(exc):
                    message = f"Gateway database storage failed with sqlite disk I/O error: {exc}"
                    logger.error(message)
                    self.service.record_storage_fault(error_code="DATABASE_IO_ERROR", message=message)
                    return
                raise
            except EonaCliError as exc:
                self.service.fail_run(run_id, error_code=exc.error_code, error_message=exc.message)
            except GatewayPauseRequested:
                logger.info("Gateway run %s paused", run_id)
                continue
            except Exception as exc:
                self.service.fail_run(run_id, error_code="INTERNAL_ERROR", error_message=str(exc))
            finally:
                self._set_current_run_id(None)

    def stop(self) -> None:
        self._stop_event.set()
