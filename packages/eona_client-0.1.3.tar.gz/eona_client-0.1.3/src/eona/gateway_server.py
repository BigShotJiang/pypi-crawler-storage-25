from __future__ import annotations

import json
import logging
import os
import secrets
import signal
import socket
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlparse

from eona.env_compat import compat_env
from eona.errors import EonaCliError
from eona.gateway_runtime import env_truthy
from eona.gateway_schema import initialize_gateway_storage
from eona.gateway_service import GatewayService, GatewayServiceError
from eona.gateway_ui import render_blocked_page, render_home_page, render_run_detail_page
from eona.gateway_worker import GatewayWorkerLoop

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s %(message)s")
logger = logging.getLogger(__name__)

PUBLIC_GATEWAY_ROUTES = {
    ("GET", "/health/live"),
    ("GET", "/health/ready"),
}


def _normalize_gateway_token(value: str | None) -> str | None:
    if value is None:
        return None
    token = value.strip()
    return token or None


def _gateway_requires_access_token() -> bool:
    return env_truthy("EONA_GATEWAY_REQUIRE_ACCESS_TOKEN", default=True)


def _gateway_allows_mount_import() -> bool:
    return env_truthy("EONA_GATEWAY_ALLOW_MOUNT_IMPORT", default=False)


def _is_loopback_host(host: str) -> bool:
    normalized = host.strip().lower()
    if normalized in {"localhost", "127.0.0.1", "::1"}:
        return True
    return normalized.startswith("127.")


def validate_gateway_policy(*, host: str) -> None:
    allow_nonlocal_bind = env_truthy("EONA_GATEWAY_ALLOW_NONLOCAL_BIND", default=False)
    require_access_token = _gateway_requires_access_token()
    access_token = _normalize_gateway_token(compat_env("EONA_GATEWAY_ACCESS_TOKEN", "EONA_GATEWAY_ACCESS_TOKEN"))

    if not _is_loopback_host(host):
        if not allow_nonlocal_bind:
            raise EonaCliError(
                "GATEWAY_POLICY_VIOLATION",
                f"Gateway policy violation: non-local bind `{host}` requires EONA_GATEWAY_ALLOW_NONLOCAL_BIND=1. EONA_GATEWAY_ALLOW_NONLOCAL_BIND is still accepted as a legacy alias.",
            )
        logger.warning("Gateway non-local bind explicitly enabled for host %s", host)

    if require_access_token and access_token is None:
        raise EonaCliError(
            "GATEWAY_POLICY_VIOLATION",
            "Gateway policy violation: access token is required for non-health routes but EONA_GATEWAY_ACCESS_TOKEN is not configured. EONA_GATEWAY_ACCESS_TOKEN is still accepted as a legacy alias.",
        )

    if not require_access_token and not _is_loopback_host(host):
        raise EonaCliError(
            "GATEWAY_POLICY_VIOLATION",
            "Gateway policy violation: non-local bind requires service authentication. Enable EONA_GATEWAY_REQUIRE_ACCESS_TOKEN and configure EONA_GATEWAY_ACCESS_TOKEN. EONA_GATEWAY_* variables are still accepted as legacy aliases.",
        )


class GatewayHTTPServer(ThreadingHTTPServer):
    def __init__(
        self,
        server_address: tuple[str, int],
        service: GatewayService,
        worker_poll_interval: float,
        *,
        startup_readiness: dict[str, object] | None = None,
        access_token: str | None = None,
        require_access_token: bool | None = None,
        allow_mount_import: bool | None = None,
    ) -> None:
        self.gateway_service = service
        self.gateway_worker = GatewayWorkerLoop(service=service, poll_interval=worker_poll_interval)
        self.worker_thread: threading.Thread | None = None
        self.semantic_job_threads: dict[str, threading.Thread] = {}
        self.semantic_job_lock = threading.Lock()
        self.startup_readiness = startup_readiness
        self.access_token = _normalize_gateway_token(access_token if access_token is not None else compat_env("EONA_GATEWAY_ACCESS_TOKEN", "EONA_GATEWAY_ACCESS_TOKEN"))
        self.require_access_token = (
            _gateway_requires_access_token() if require_access_token is None else bool(require_access_token)
        )
        self.allow_mount_import = _gateway_allows_mount_import() if allow_mount_import is None else bool(allow_mount_import)
        super().__init__(server_address, GatewayRequestHandler)

    def serve_forever(self, poll_interval: float = 0.5) -> None:
        if self.worker_thread is None:
            blocked = bool((self.startup_readiness or {}).get("lifecycle_state") in {"blocked", "failed"})
            if not blocked:
                self.gateway_service.reconcile_interrupted_runs()
                self.worker_thread = threading.Thread(target=self.gateway_worker.run_forever, daemon=True)
                self.worker_thread.start()
        super().serve_forever(poll_interval=poll_interval)

    def shutdown(self) -> None:
        self.gateway_worker.stop()
        super().shutdown()
        if self.worker_thread is not None:
            self.worker_thread.join(timeout=2.0)
        with self.semantic_job_lock:
            semantic_threads = list(self.semantic_job_threads.values())
        for thread in semantic_threads:
            thread.join(timeout=2.0)

    def request_graceful_shutdown(self, *, timeout: float = 10.0) -> None:
        self.gateway_worker.request_graceful_stop()
        active_run_id = self.gateway_worker.current_run_id
        if active_run_id:
            try:
                self.gateway_service.request_pause_run(active_run_id)
                logger.info("Gateway graceful shutdown requested pause for run %s", active_run_id)
            except GatewayServiceError as exc:
                logger.warning("Gateway graceful shutdown could not pause run %s: %s", active_run_id, exc)
        deadline = time.monotonic() + max(timeout, 0.0)
        while self.worker_thread is not None and self.worker_thread.is_alive():
            current_run_id = self.gateway_worker.current_run_id
            if current_run_id is None:
                break
            if time.monotonic() >= deadline:
                logger.warning(
                    "Gateway graceful shutdown timed out while waiting for run %s to reach a pause checkpoint",
                    current_run_id,
                )
                break
            time.sleep(0.1)

    def _cleanup_semantic_job_threads_locked(self) -> None:
        finished = [job_name for job_name, thread in self.semantic_job_threads.items() if not thread.is_alive()]
        for job_name in finished:
            self.semantic_job_threads.pop(job_name, None)

    def semantic_job_is_running(self, job_name: str) -> bool:
        with self.semantic_job_lock:
            self._cleanup_semantic_job_threads_locked()
            thread = self.semantic_job_threads.get(job_name)
            return bool(thread and thread.is_alive())

    def start_semantic_job(self, job_name: str, target) -> bool:
        with self.semantic_job_lock:
            self._cleanup_semantic_job_threads_locked()
            existing = self.semantic_job_threads.get(job_name)
            if existing is not None and existing.is_alive():
                return False

            def _runner() -> None:
                try:
                    target()
                finally:
                    with self.semantic_job_lock:
                        current = self.semantic_job_threads.get(job_name)
                        if current is threading.current_thread():
                            self.semantic_job_threads.pop(job_name, None)

            thread = threading.Thread(target=_runner, daemon=True, name=f"eona-semantic-{job_name}")
            self.semantic_job_threads[job_name] = thread
            thread.start()
            return True


class GatewayRequestHandler(BaseHTTPRequestHandler):
    server: GatewayHTTPServer

    def _blocked_readiness(self) -> dict[str, object] | None:
        readiness = self.server.gateway_service.readiness(allow_cached_pending=True)
        if readiness and readiness.get("lifecycle_state") in {"blocked", "failed"}:
            return readiness
        return None

    def _is_public_route(self, *, method: str, path: str) -> bool:
        return (method.upper(), path) in PUBLIC_GATEWAY_ROUTES

    def _check_service_auth(self, *, method: str, path: str) -> bool:
        if self._is_public_route(method=method, path=path):
            return True
        require_access_token = bool(getattr(self.server, "require_access_token", _gateway_requires_access_token()))
        if not require_access_token:
            return True
        expected_token = _normalize_gateway_token(getattr(self.server, "access_token", compat_env("EONA_GATEWAY_ACCESS_TOKEN", "EONA_GATEWAY_ACCESS_TOKEN")))
        if expected_token is None:
            self._write_json(503, {"error_code": "GATEWAY_AUTH_MISCONFIGURED", "message": "Gateway access token is not configured."})
            return False
        authorization = self.headers.get("Authorization")
        if not authorization:
            self._write_auth_error(401, "Missing bearer token.")
            return False
        scheme, _, token = authorization.partition(" ")
        if scheme.lower() != "bearer" or not token.strip():
            self._write_auth_error(401, "Authorization header must use Bearer token.")
            return False
        if not secrets.compare_digest(token.strip(), expected_token):
            self._write_auth_error(403, "Bearer token is invalid.")
            return False
        return True

    def _write_auth_error(self, status: int, message: str) -> None:
        encoded = json.dumps({"error_code": "UNAUTHORIZED", "message": message}, sort_keys=True).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(encoded)))
        if status == 401:
            self.send_header("WWW-Authenticate", 'Bearer realm="eona-gateway"')
        self.end_headers()
        self._write_response_body(encoded)

    def _check_mount_collection_allowed(self) -> bool:
        if bool(getattr(self.server, "allow_mount_import", _gateway_allows_mount_import())):
            return True
        self._write_json(
            403,
            {
                "error_code": "IMPORT_MOUNT_NOT_ALLOWED",
                "message": "Mount-backed import is not allowed by this Gateway deployment.",
            },
        )
        return False

    def do_GET(self) -> None:
        try:
            parsed = urlparse(self.path)
            if not self._check_service_auth(method="GET", path=parsed.path):
                return
            if parsed.path == "/":
                blocked = self._blocked_readiness()
                if blocked is not None:
                    self._write_html(503, render_blocked_page(readiness=blocked))
                    return
                html = render_home_page(runs=self.server.gateway_service.get_recent_runs_for_ui())
                self._write_html(200, html)
                return
            if parsed.path == "/health/live":
                self._write_json(200, self.server.gateway_service.liveness())
                return
            if parsed.path == "/health/ready":
                payload = self.server.gateway_service.readiness(allow_cached_pending=True)
                self._write_json(200 if payload.get("ok") else 503, payload)
                return
            if parsed.path.startswith("/runs/"):
                blocked = self._blocked_readiness()
                if blocked is not None:
                    self._write_html(503, render_blocked_page(readiness=blocked))
                    return
                run_id = parsed.path.split("/")[2]
                run = self.server.gateway_service.get_import_run_detail(run_id)
                import_session = None
                if run.get("source_import_id"):
                    import_session = self.server.gateway_service.get_import_session(str(run["source_import_id"]))
                self._write_html(200, render_run_detail_page(run=run, import_session=import_session))
                return
            if parsed.path == "/health":
                payload = self.server.gateway_service.health()
                self._write_json(200 if payload.get("ok") else 503, payload)
                return
            if parsed.path == "/doctor":
                params = parse_qs(parsed.query)
                abandoned_older_than_hours = float(params.get("abandoned_older_than_hours", ["24.0"])[0])
                self._write_json(
                    200,
                    self.server.gateway_service.doctor(
                        abandoned_older_than_hours=abandoned_older_than_hours,
                    ),
                )
                return
            if parsed.path.startswith("/content/"):
                blocked = self._blocked_readiness()
                if blocked is not None:
                    self._write_json(503, {"error_code": "GATEWAY_BLOCKED", "message": str(blocked.get("summary") or "Gateway is blocked.")})
                    return
                content_id = parsed.path.split("/")[2]
                content_path, headers = self.server.gateway_service.get_content_response(content_id)
                self._write_file(200, content_path=content_path, headers=headers)
                return
            if parsed.path.startswith("/photos/"):
                blocked = self._blocked_readiness()
                if blocked is not None:
                    self._write_json(503, {"error_code": "GATEWAY_BLOCKED", "message": str(blocked.get("summary") or "Gateway is blocked.")})
                    return
                photo_id = parsed.path.split("/")[2]
                self._write_json(200, self.server.gateway_service.get_photo_metadata(photo_id))
                return
            if parsed.path.startswith("/import-sessions/"):
                blocked = self._blocked_readiness()
                if blocked is not None:
                    self._write_json(503, {"error_code": "GATEWAY_BLOCKED", "message": str(blocked.get("summary") or "Gateway is blocked.")})
                    return
                import_id = parsed.path.split("/")[2]
                self._write_json(200, self.server.gateway_service.get_import_session(import_id))
                return
            if parsed.path == "/import-runs":
                blocked = self._blocked_readiness()
                if blocked is not None:
                    self._write_json(503, {"error_code": "GATEWAY_BLOCKED", "message": str(blocked.get("summary") or "Gateway is blocked.")})
                    return
                params = parse_qs(parsed.query)
                limit = int(params.get("limit", ["20"])[0])
                self._write_json(200, self.server.gateway_service.list_import_runs(limit=limit))
                return
            if parsed.path.startswith("/import-runs/"):
                blocked = self._blocked_readiness()
                if blocked is not None:
                    self._write_json(503, {"error_code": "GATEWAY_BLOCKED", "message": str(blocked.get("summary") or "Gateway is blocked.")})
                    return
                run_id = parsed.path.split("/")[2]
                self._write_json(200, self.server.gateway_service.get_import_run(run_id))
                return
            self._write_json(404, {"error_code": "NOT_FOUND", "message": "Route not found."})
        except GatewayServiceError as exc:
            self._write_json(exc.http_status, {"error_code": exc.error_code, "message": exc.message})

    def do_POST(self) -> None:
        try:
            parsed = urlparse(self.path)
            if not self._check_service_auth(method="POST", path=parsed.path):
                return
            blocked = self._blocked_readiness()
            if blocked is not None:
                self._write_json(503, {"error_code": "GATEWAY_BLOCKED", "message": str(blocked.get("summary") or "Gateway is blocked.")})
                return
            if parsed.path == "/queries/photo-memory":
                payload = self._read_json_request()
                self._write_json(200, self.server.gateway_service.query_photo_memory(payload))
                return
            if parsed.path == "/ui/import":
                session = self.server.gateway_service.create_import_session()
                import_id = str(session["import_id"])
                import_parts = self._parse_multipart_request()
                file_parts = import_parts.get("file", [])
                if not file_parts:
                    self._write_html(
                        400,
                        render_home_page(
                            runs=self.server.gateway_service.get_recent_runs_for_ui(),
                            import_error="At least one file is required.",
                        ),
                    )
                    return
                path_hints = _resolve_file_path_hints(file_parts=file_parts, import_parts=import_parts)
                for index, file_part in enumerate(file_parts):
                    path_hint = path_hints[index] if index < len(path_hints) else None
                    self.server.gateway_service.stage_import_file(
                        import_id=import_id,
                        client_filename=str(file_part["filename"] or "import.bin"),
                        content=bytes(file_part["content"]),
                        path_hint=path_hint if isinstance(path_hint, str) and path_hint.strip() else None,
                    )
                committed = self.server.gateway_service.commit_import_session(import_id)
                self.send_response(303)
                self.send_header("Location", f"/runs/{committed['run_id']}")
                self.end_headers()
                return
            if parsed.path == "/import-sessions":
                self._write_json(201, self.server.gateway_service.create_import_session())
                return
            if parsed.path.startswith("/import-sessions/") and parsed.path.endswith("/files"):
                import_id = parsed.path.split("/")[2]
                client_filename, file_bytes, path_hint = self._parse_import_request()
                self._write_json(
                    201,
                    self.server.gateway_service.stage_import_file(
                        import_id=import_id,
                        client_filename=client_filename,
                        content=file_bytes,
                        path_hint=path_hint,
                    ),
                )
                return
            if parsed.path.startswith("/import-sessions/") and parsed.path.endswith("/collect"):
                if not self._check_mount_collection_allowed():
                    return
                import_id = parsed.path.split("/")[2]
                payload = self._read_json_request()
                source_path = payload.get("source_path")
                if not isinstance(source_path, str) or not source_path.strip():
                    raise ValueError("JSON field `source_path` is required.")
                self._write_json(
                    200,
                    self.server.gateway_service.collect_import_path(
                        import_id=import_id,
                        source_path=source_path,
                    ),
                )
                return
            if parsed.path.startswith("/import-sessions/") and parsed.path.endswith("/commit"):
                import_id = parsed.path.split("/")[2]
                self._write_json(200, self.server.gateway_service.commit_import_session(import_id))
                return
            if parsed.path.startswith("/import-runs/") and parsed.path.endswith("/pause"):
                run_id = parsed.path.split("/")[2]
                paused = self.server.gateway_service.request_pause_run(run_id)
                self.send_response(303)
                self.send_header("Location", f"/runs/{paused['run_id']}")
                self.end_headers()
                return
            if parsed.path.startswith("/import-runs/") and parsed.path.endswith("/resume"):
                run_id = parsed.path.split("/")[2]
                resumed = self.server.gateway_service.resume_paused_run(run_id)
                self.send_response(303)
                self.send_header("Location", f"/runs/{resumed['run_id']}")
                self.end_headers()
                return
            if parsed.path == "/semantic-jobs/backfill-duplicate-semantic":
                payload = self._read_json_request()
                limit = payload.get("limit")
                replay_mode = payload.get("replay_mode", "incremental")
                started = self.server.start_semantic_job(
                    "duplicate_semantic",
                    lambda: self.server.gateway_service.backfill_duplicate_semantics(
                        limit=limit,
                        replay_mode=str(replay_mode),
                    ),
                )
                job = self.server.gateway_service.get_semantic_enrichment_job("duplicate_semantic")
                if started and str(job.get("status")) == "pending":
                    job = {
                        **job,
                        "status": "running",
                        "summary": f"Computing duplicate semantic enrichment ({str(replay_mode)}).",
                    }
                self._write_json(
                    202 if started else 200,
                    {
                        "ok": True,
                        "job_name": "duplicate_semantic",
                        "replay_mode": str(replay_mode),
                        "status": "started" if started else "running",
                        "summary": (
                            "Started duplicate semantic enrichment in the background."
                            if started
                            else "Duplicate semantic enrichment is already running."
                        ),
                        "job": job,
                    },
                )
                return
            if parsed.path == "/semantic-jobs/backfill-tags":
                payload = self._read_json_request()
                tag = payload.get("tag")
                limit = payload.get("limit")
                replay_mode = payload.get("replay_mode", "incremental")
                if not isinstance(tag, str) or not tag.strip():
                    raise ValueError("JSON field `tag` is required.")
                normalized_tag = str(tag).strip()
                started = self.server.start_semantic_job(
                    normalized_tag,
                    lambda: self.server.gateway_service.backfill_tags(
                        tag=normalized_tag,
                        limit=limit,
                        replay_mode=str(replay_mode),
                    ),
                )
                job = self.server.gateway_service.get_semantic_enrichment_job(normalized_tag)
                if started and str(job.get("status")) == "pending":
                    job = {**job, "status": "running", "summary": f"Computing `{normalized_tag}` semantic enrichment."}
                self._write_json(
                    202 if started else 200,
                    {
                        "ok": True,
                        "job_name": normalized_tag,
                        "tag": normalized_tag,
                        "status": "started" if started else "running",
                        "replay_mode": str(replay_mode),
                        "summary": (
                            f"Started `{normalized_tag}` semantic enrichment in the background."
                            if started
                            else f"`{normalized_tag}` semantic enrichment is already running."
                        ),
                        "job": job,
                    },
                )
                return
            self._write_json(404, {"error_code": "NOT_FOUND", "message": "Route not found."})
        except GatewayServiceError as exc:
            self._write_json(exc.http_status, {"error_code": exc.error_code, "message": exc.message})
        except ValueError as exc:
            self._write_json(400, {"error_code": "INVALID_REQUEST", "message": str(exc)})

    def log_message(self, format: str, *args) -> None:
        return None

    def _write_json(self, status: int, payload: dict) -> None:
        encoded = json.dumps(payload, sort_keys=True).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(encoded)))
        self.end_headers()
        self._write_response_body(encoded)

    def _write_html(self, status: int, body: str) -> None:
        encoded = body.encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(encoded)))
        self.end_headers()
        self._write_response_body(encoded)

    def _write_file(self, status: int, *, content_path, headers: dict[str, str]) -> None:
        self.send_response(status)
        for key, value in headers.items():
            self.send_header(key, value)
        self.end_headers()
        with open(content_path, "rb") as handle:
            self._write_response_body(handle.read())

    def _write_response_body(self, payload: bytes) -> None:
        try:
            self.wfile.write(payload)
        except (BrokenPipeError, ConnectionResetError, socket.timeout) as exc:
            logger.debug("Gateway client disconnected before response completed: %s", exc)

    def _parse_import_request(self) -> tuple[str, bytes, str | None]:
        parts = self._parse_multipart_request()
        file_parts = parts.get("file", [])
        if not file_parts:
            raise ValueError("multipart field `file` is required")
        file_part = file_parts[-1]
        client_filename = file_part["filename"] or "import.bin"
        path_hint_parts = parts.get("path_hint", [])
        path_hint = path_hint_parts[-1]["text"] if path_hint_parts else None
        return client_filename, file_part["content"], path_hint

    def _parse_multipart_request(self) -> dict[str, list[dict[str, object]]]:
        content_length = int(self.headers.get("Content-Length", "0"))
        if content_length <= 0:
            raise ValueError("Import request body is empty.")
        content_type = self.headers.get("Content-Type", "")
        boundary = _extract_boundary(content_type)
        if not boundary:
            raise ValueError("multipart boundary missing")
        body = self.rfile.read(content_length)
        return _parse_multipart(body=body, boundary=boundary)

    def _read_json_request(self) -> dict:
        content_length = int(self.headers.get("Content-Length", "0"))
        if content_length <= 0:
            raise ValueError("JSON request body is empty.")
        body = self.rfile.read(content_length)
        try:
            payload = json.loads(body.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError) as exc:
            raise ValueError("Request body must be valid JSON.") from exc
        if not isinstance(payload, dict):
            raise ValueError("JSON request body must be an object.")
        return payload


def _extract_boundary(content_type: str) -> bytes | None:
    for item in content_type.split(";"):
        key, separator, value = item.strip().partition("=")
        if separator and key == "boundary":
            return value.strip('"').encode("utf-8")
    return None


def _parse_multipart(*, body: bytes, boundary: bytes) -> dict[str, list[dict[str, object]]]:
    marker = b"--" + boundary
    result: dict[str, list[dict[str, object]]] = {}
    for chunk in body.split(marker):
        if not chunk or chunk in {b"--\r\n", b"--", b"\r\n"}:
            continue
        chunk = chunk.strip(b"\r\n")
        if chunk.endswith(b"--"):
            chunk = chunk[:-2]
        headers_blob, separator, content = chunk.partition(b"\r\n\r\n")
        if not separator:
            continue
        header_lines = headers_blob.decode("utf-8").split("\r\n")
        headers: dict[str, str] = {}
        for line in header_lines:
            key, _, value = line.partition(":")
            headers[key.strip().lower()] = value.strip()
        disposition = headers.get("content-disposition")
        if not disposition:
            continue
        params = _parse_content_disposition(disposition)
        name = params.get("name")
        if not name:
            continue
        if content.endswith(b"\r\n"):
            content = content[:-2]
        result.setdefault(name, []).append({
            "filename": params.get("filename"),
            "content": content,
            "text": content.decode("utf-8") if "filename" not in params else None,
        })
    return result


def _parse_content_disposition(value: str) -> dict[str, str]:
    params: dict[str, str] = {}
    items = [item.strip() for item in value.split(";")]
    for item in items[1:]:
        key, _, raw_value = item.partition("=")
        params[key.strip()] = raw_value.strip().strip('"')
    return params


def _resolve_file_path_hints(*, file_parts: list[dict[str, object]], import_parts: dict[str, list[dict[str, object]]]) -> list[str | None]:
    path_hint_values = import_parts.get("path_hint", [])
    normalized = [
        value.get("text") if isinstance(value.get("text"), str) else None
        for value in path_hint_values
    ]
    if len(normalized) == len(file_parts):
        return normalized
    shared_hint = normalized[-1] if normalized else None
    return [shared_hint for _ in file_parts]


def build_gateway_server(*, host: str = "127.0.0.1", port: int = 8000, poll_interval: float = 0.25) -> GatewayHTTPServer:
    validate_gateway_policy(host=host)
    initialize_gateway_storage(force=False)
    service = GatewayService()
    service.refresh_content_store_integrity_async()
    return GatewayHTTPServer((host, port), service, poll_interval, startup_readiness=service.readiness(allow_cached_pending=True))


def serve_gateway(*, host: str = "127.0.0.1", port: int = 8000, poll_interval: float = 0.25) -> int:
    validate_gateway_policy(host=host)
    initialize_gateway_storage(force=False)
    service = GatewayService()
    service.refresh_content_store_integrity_async()
    readiness = service.readiness(allow_cached_pending=True)
    if readiness.get("lifecycle_state") in {"blocked", "failed"}:
        logger.error("Gateway startup blocked: %s", readiness.get("summary") or "Gateway readiness failed.")
        for problem in readiness.get("problems") or []:
            logger.error("Gateway startup problem: %s", problem)
    server = GatewayHTTPServer((host, port), service, poll_interval, startup_readiness=readiness)
    shutdown_timeout = float(compat_env("EONA_GATEWAY_GRACEFUL_SHUTDOWN_TIMEOUT", "EONA_GATEWAY_GRACEFUL_SHUTDOWN_TIMEOUT", default="10") or "10")
    previous_sigterm = signal.getsignal(signal.SIGTERM)

    def _handle_sigterm(_signum, _frame) -> None:
        raise KeyboardInterrupt()

    signal.signal(signal.SIGTERM, _handle_sigterm)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        server.request_graceful_shutdown(timeout=shutdown_timeout)
        return 0
    finally:
        signal.signal(signal.SIGTERM, previous_sigterm)
        server.shutdown()
        server.server_close()
    return 0
