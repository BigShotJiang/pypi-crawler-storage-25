from __future__ import annotations

import json
import os
import secrets
from dataclasses import dataclass
from pathlib import Path
from typing import Any
from urllib import error, request

from eona.env_compat import compat_env


DEFAULT_GATEWAY_URL = "http://eona-gateway:8000"
SUPPORTED_IMPORT_EXTENSIONS = {".jpg", ".jpeg", ".heic", ".heif"}


@dataclass(frozen=True)
class GatewayClientError(RuntimeError):
    message: str
    status_code: int | None = None
    response_payload: dict[str, Any] | None = None

    def __str__(self) -> str:
        return self.message


def gateway_base_url() -> str:
    return (compat_env("EONA_GATEWAY_URL", "EONA_GATEWAY_URL", default=DEFAULT_GATEWAY_URL) or DEFAULT_GATEWAY_URL).rstrip("/")


def gateway_access_token() -> str:
    token = (compat_env("EONA_GATEWAY_ACCESS_TOKEN", "EONA_GATEWAY_ACCESS_TOKEN", default="") or "").strip()
    if not token:
        raise GatewayClientError(
            "EONA_GATEWAY_ACCESS_TOKEN is required to call Gateway protected routes. EONA_GATEWAY_ACCESS_TOKEN is still accepted as a legacy alias.",
        )
    return token


def post_gateway_json(
    path: str,
    payload: dict[str, Any],
    *,
    base_url: str | None = None,
    access_token: str | None = None,
    timeout: float = 30.0,
) -> dict[str, Any]:
    body = json.dumps(payload, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
    req = request.Request(
        _gateway_url(path, base_url=base_url),
        data=body,
        method="POST",
        headers={
            "Authorization": f"Bearer {access_token or gateway_access_token()}",
            "Content-Type": "application/json",
        },
    )
    return _execute_json_request(req, timeout=timeout)


def get_gateway_json(
    path: str,
    *,
    base_url: str | None = None,
    access_token: str | None = None,
    timeout: float = 30.0,
    require_auth: bool = True,
) -> dict[str, Any]:
    headers: dict[str, str] = {}
    if require_auth:
        headers["Authorization"] = f"Bearer {access_token or gateway_access_token()}"
    req = request.Request(
        _gateway_url(path, base_url=base_url),
        method="GET",
        headers=headers,
    )
    return _execute_json_request(req, timeout=timeout)


def create_import_session(
    *,
    base_url: str | None = None,
    access_token: str | None = None,
    timeout: float = 30.0,
) -> dict[str, Any]:
    req = request.Request(
        _gateway_url("/import-sessions", base_url=base_url),
        data=b"{}",
        method="POST",
        headers={
            "Authorization": f"Bearer {access_token or gateway_access_token()}",
            "Content-Type": "application/json",
        },
    )
    return _execute_json_request(req, timeout=timeout)


def import_file(
    import_id: str,
    *,
    file_path: Path,
    path_hint: str | None,
    base_url: str | None = None,
    access_token: str | None = None,
    timeout: float = 30.0,
) -> dict[str, Any]:
    boundary = f"eona-{secrets.token_hex(12)}"
    body = _encode_multipart(
        boundary=boundary,
        fields={"path_hint": path_hint} if path_hint else {},
        file_field_name="file",
        file_name=file_path.name,
        file_content=file_path.read_bytes(),
    )
    req = request.Request(
        _gateway_url(f"/import-sessions/{import_id}/files", base_url=base_url),
        data=body,
        method="POST",
        headers={
            "Authorization": f"Bearer {access_token or gateway_access_token()}",
            "Content-Type": f"multipart/form-data; boundary={boundary}",
        },
    )
    return _execute_json_request(req, timeout=timeout)


def collect_import_path(
    import_id: str,
    *,
    source_path: Path,
    base_url: str | None = None,
    access_token: str | None = None,
    timeout: float = 30.0,
) -> dict[str, Any]:
    return post_gateway_json(
        f"/import-sessions/{import_id}/collect",
        {"source_path": str(source_path.expanduser().resolve())},
        base_url=base_url,
        access_token=access_token,
        timeout=timeout,
    )


def commit_import_session(
    import_id: str,
    *,
    base_url: str | None = None,
    access_token: str | None = None,
    timeout: float = 30.0,
) -> dict[str, Any]:
    req = request.Request(
        _gateway_url(f"/import-sessions/{import_id}/commit", base_url=base_url),
        data=b"{}",
        method="POST",
        headers={
            "Authorization": f"Bearer {access_token or gateway_access_token()}",
            "Content-Type": "application/json",
        },
    )
    return _execute_json_request(req, timeout=timeout)


def health_check_gateway(
    *,
    base_url: str | None = None,
    access_token: str | None = None,
    timeout: float = 30.0,
) -> dict[str, Any]:
    payload: dict[str, Any] = {
        "ok": True,
        "base_url": (base_url or gateway_base_url()).rstrip("/"),
        "checks": {},
    }
    for path, key in (
        ("/health/live", "live"),
        ("/health/ready", "ready"),
    ):
        response = get_gateway_json(path, base_url=base_url, timeout=timeout, require_auth=False)
        payload["checks"][key] = response
    auth_health: dict[str, Any]
    try:
        auth_health = get_gateway_json(
            "/health",
            base_url=base_url,
            access_token=access_token,
            timeout=timeout,
            require_auth=True,
        )
    except GatewayClientError as exc:
        auth_health = {
            "ok": False,
            "status": "unavailable",
            "message": str(exc),
            "status_code": exc.status_code,
        }
        payload["ok"] = False
    else:
        if not bool(auth_health.get("ok", True)):
            payload["ok"] = False
    payload["checks"]["health"] = auth_health
    if not bool(payload["checks"]["ready"].get("ok", True)):
        payload["ok"] = False
    return payload


def get_import_run(
    run_id: str,
    *,
    base_url: str | None = None,
    access_token: str | None = None,
    timeout: float = 30.0,
) -> dict[str, Any]:
    return get_gateway_json(
        f"/import-runs/{run_id}",
        base_url=base_url,
        access_token=access_token,
        timeout=timeout,
        require_auth=True,
    )


def doctor_gateway(
    *,
    base_url: str | None = None,
    access_token: str | None = None,
    abandoned_older_than_hours: float = 24.0,
    timeout: float = 30.0,
) -> dict[str, Any]:
    return get_gateway_json(
        f"/doctor?abandoned_older_than_hours={abandoned_older_than_hours}",
        base_url=base_url,
        access_token=access_token,
        timeout=timeout,
        require_auth=True,
    )


def backfill_duplicate_semantics(
    *,
    limit: int | None = None,
    replay_mode: str = "incremental",
    base_url: str | None = None,
    access_token: str | None = None,
    timeout: float = 30.0,
) -> dict[str, Any]:
    payload: dict[str, Any] = {"replay_mode": str(replay_mode)}
    if limit is not None:
        payload["limit"] = int(limit)
    return post_gateway_json(
        "/semantic-jobs/backfill-duplicate-semantic",
        payload,
        base_url=base_url,
        access_token=access_token,
        timeout=timeout,
    )


def backfill_tags(
    *,
    tag: str,
    limit: int | None = None,
    replay_mode: str = "incremental",
    base_url: str | None = None,
    access_token: str | None = None,
    timeout: float = 30.0,
) -> dict[str, Any]:
    payload: dict[str, Any] = {"tag": str(tag), "replay_mode": str(replay_mode)}
    if limit is not None:
        payload["limit"] = int(limit)
    return post_gateway_json(
        "/semantic-jobs/backfill-tags",
        payload,
        base_url=base_url,
        access_token=access_token,
        timeout=timeout,
    )


def discover_import_files(source_path: Path) -> tuple[list[Path], list[dict[str, str]]]:
    root = source_path.expanduser().resolve()
    if not root.exists():
        raise GatewayClientError(f"Photo path does not exist: {root}")
    if not root.is_absolute():
        raise GatewayClientError(f"Photo path must be absolute: {root}")

    files: list[Path] = []
    errors: list[dict[str, str]] = []

    def _walk(candidate: Path) -> None:
        if candidate.name.startswith("."):
            return
        if candidate.is_symlink():
            errors.append(
                {
                    "path": str(candidate),
                    "error_code": "IMPORT_PATH_SYMLINK_UNSUPPORTED",
                    "message": f"Symlink inputs are not supported: {candidate}",
                }
            )
            return
        try:
            if candidate.is_dir():
                for child in sorted(candidate.iterdir(), key=lambda item: item.name.casefold()):
                    _walk(child)
                return
            if not candidate.is_file():
                return
            if candidate.suffix.lower() not in SUPPORTED_IMPORT_EXTENSIONS:
                return
            with candidate.open("rb") as handle:
                handle.read(1)
            files.append(candidate.resolve())
        except OSError as exc:
            errors.append(
                {
                    "path": str(candidate),
                    "error_code": "IMPORT_FILE_UNREADABLE",
                    "message": f"Import source is unreadable: {candidate} ({exc})",
                }
            )

    _walk(root)
    return files, errors


def build_path_hint(file_path: Path, *, root: Path, mode: str) -> str:
    if mode == "absolute":
        return str(file_path.resolve())
    if mode == "filename":
        return file_path.name
    if mode == "relative":
        return str(file_path.resolve().relative_to(root.resolve()))
    raise GatewayClientError(f"Unsupported path hint mode: {mode}")


def import_folder_to_gateway(
    folder: Path,
    *,
    base_url: str | None = None,
    access_token: str | None = None,
    path_hint_mode: str = "relative",
    dry_run: bool = False,
    timeout: float = 30.0,
) -> dict[str, Any]:
    root = folder.expanduser().resolve()
    if not root.is_dir():
        raise GatewayClientError(f"Photo folder is not a directory: {root}")
    files, errors = discover_import_files(root)
    if not files:
        raise GatewayClientError(f"No supported photo files found under {root}")
    if dry_run:
        return {
            "ok": True,
            "status": "dry_run",
            "photo_folder": str(root),
            "file_count": len(files),
            "error_count": len(errors),
            "errors": errors,
            "import_id": None,
            "run_id": None,
            "collection_mode": "upload",
        }

    session = create_import_session(base_url=base_url, access_token=access_token, timeout=timeout)
    import_id = str(session["import_id"])
    for file_path in files:
        import_file(
            import_id,
            file_path=file_path,
            path_hint=build_path_hint(file_path, root=root, mode=path_hint_mode),
            base_url=base_url,
            access_token=access_token,
            timeout=timeout,
        )
    committed = commit_import_session(import_id, base_url=base_url, access_token=access_token, timeout=timeout)
    return {
        "ok": True,
        "status": str(committed.get("status") or "queued"),
        "photo_folder": str(root),
        "file_count": len(files),
        "error_count": len(errors),
        "errors": errors,
        "import_id": import_id,
        "run_id": committed.get("run_id"),
        "collection_mode": "upload",
    }


def mount_import_to_gateway(
    source_path: Path,
    *,
    base_url: str | None = None,
    access_token: str | None = None,
    dry_run: bool = False,
    timeout: float = 30.0,
) -> dict[str, Any]:
    root = source_path.expanduser().resolve()
    files, errors = discover_import_files(root)
    if not files:
        raise GatewayClientError(f"No supported photo files found under {root}")
    if dry_run:
        return {
            "ok": True,
            "status": "dry_run",
            "photo_folder": str(root),
            "file_count": len(files),
            "error_count": len(errors),
            "errors": errors,
            "import_id": None,
            "run_id": None,
            "collection_mode": "mount",
        }

    session = create_import_session(base_url=base_url, access_token=access_token, timeout=timeout)
    import_id = str(session["import_id"])
    collected = collect_import_path(
        import_id,
        source_path=root,
        base_url=base_url,
        access_token=access_token,
        timeout=timeout,
    )
    committed = commit_import_session(import_id, base_url=base_url, access_token=access_token, timeout=timeout)
    return {
        "ok": True,
        "status": str(committed.get("status") or "queued"),
        "photo_folder": str(root),
        "file_count": len(files),
        "error_count": int(collected.get("error_count") or len(errors)),
        "errors": list(collected.get("errors") or errors),
        "import_id": import_id,
        "run_id": committed.get("run_id"),
        "collection_mode": "mount",
    }


def import_path_to_gateway(
    source_path: Path,
    *,
    collection_mode: str,
    base_url: str | None = None,
    access_token: str | None = None,
    path_hint_mode: str = "relative",
    dry_run: bool = False,
    timeout: float = 30.0,
) -> dict[str, Any]:
    if collection_mode == "upload":
        return import_folder_to_gateway(
            source_path,
            base_url=base_url,
            access_token=access_token,
            path_hint_mode=path_hint_mode,
            dry_run=dry_run,
            timeout=timeout,
        )
    if collection_mode == "mount":
        return mount_import_to_gateway(
            source_path,
            base_url=base_url,
            access_token=access_token,
            dry_run=dry_run,
            timeout=timeout,
        )
    raise GatewayClientError(f"Unsupported Gateway import collection mode: {collection_mode}")


def _gateway_url(path: str, *, base_url: str | None = None) -> str:
    if not path.startswith("/"):
        raise GatewayClientError(f"Gateway path must start with '/': {path}")
    return f"{(base_url or gateway_base_url()).rstrip('/')}{path}"


def _execute_json_request(req: request.Request, *, timeout: float) -> dict[str, Any]:
    try:
        with request.urlopen(req, timeout=timeout) as response:
            raw_body = response.read()
    except error.HTTPError as exc:
        error_payload = _load_json_response(exc.read())
        message = _error_message(error_payload, default=f"Gateway request failed with HTTP {exc.code}.")
        raise GatewayClientError(message, status_code=exc.code, response_payload=error_payload) from exc
    except error.URLError as exc:
        raise GatewayClientError(f"Gateway request failed: {exc.reason}") from exc
    except TimeoutError as exc:
        raise GatewayClientError("Gateway request timed out.") from exc
    return _load_json_response(raw_body)


def _encode_multipart(
    *,
    boundary: str,
    fields: dict[str, str],
    file_field_name: str,
    file_name: str,
    file_content: bytes,
) -> bytes:
    chunks: list[bytes] = []
    for key, value in fields.items():
        chunks.extend(
            [
                f"--{boundary}".encode("utf-8"),
                f'Content-Disposition: form-data; name="{key}"'.encode("utf-8"),
                b"",
                value.encode("utf-8"),
            ]
        )
    chunks.extend(
        [
            f"--{boundary}".encode("utf-8"),
            f'Content-Disposition: form-data; name="{file_field_name}"; filename="{file_name}"'.encode("utf-8"),
            b"Content-Type: application/octet-stream",
            b"",
            file_content,
            f"--{boundary}--".encode("utf-8"),
            b"",
        ]
    )
    return b"\r\n".join(chunks)


def _load_json_response(raw_body: bytes) -> dict[str, Any]:
    try:
        payload = json.loads(raw_body.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise GatewayClientError("Gateway response was not valid JSON.") from exc
    if not isinstance(payload, dict):
        raise GatewayClientError("Gateway response must be a JSON object.")
    return payload


def _error_message(payload: dict[str, Any] | None, *, default: str) -> str:
    if not isinstance(payload, dict):
        return default
    message = payload.get("message")
    if isinstance(message, str) and message.strip():
        return message
    error_code = payload.get("error_code")
    if isinstance(error_code, str) and error_code.strip():
        return f"Gateway request failed: {error_code}"
    return default
