from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path

from eona.env_compat import compat_env


@dataclass(frozen=True)
class GatewayPaths:
    root: Path
    content_dir: Path
    imports_dir: Path
    import_sessions_dir: Path
    runs_dir: Path
    db_dir: Path
    tmp_dir: Path
    database: Path


def get_gateway_paths() -> GatewayPaths:
    configured_root = compat_env("EONA_GATEWAY_HOME", "EONA_GATEWAY_HOME")
    if configured_root:
        root = Path(configured_root).expanduser().resolve()
    else:
        # Fallback for local mode: use EONA_HOME/EONA_HOME + /gateway
        eona_home = compat_env("EONA_HOME", "EONA_HOME")
        if eona_home:
            root = Path(eona_home).expanduser().resolve() / "gateway"
        else:
            # Fallback for container mode
            root = Path("/data")
    
    return GatewayPaths(
        root=root,
        content_dir=root / "content",
        imports_dir=root / "imports",
        import_sessions_dir=root / "imports" / "sessions",
        runs_dir=root / "runs",
        db_dir=root / "db",
        tmp_dir=root / "tmp",
        database=root / "db" / "gateway.db",
    )


def ensure_gateway_layout(paths: GatewayPaths | None = None) -> GatewayPaths:
    resolved = paths or get_gateway_paths()
    for directory in (
        resolved.root,
        resolved.content_dir,
        resolved.imports_dir,
        resolved.import_sessions_dir,
        resolved.runs_dir,
        resolved.db_dir,
        resolved.tmp_dir,
    ):
        directory.mkdir(parents=True, exist_ok=True)
    return resolved
