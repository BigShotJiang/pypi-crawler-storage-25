# Eona

Eona is a personal photo-memory system with a protected Gateway backend, an operator CLI, and a query-oriented agent workflow.

Current public operator surface:

- `eona-gateway`
  local self-host service lifecycle and administration
- `eona-client`
  operator actions against an existing Gateway

Public distribution split:

- `eona-macos-arm64-<version>.tar.gz`
  primary self-host release containing `eona-gateway` and local runtime assets
- `eona_client-<version>-py3-none-any.whl` and `eona_client-<version>.tar.gz`
  supplemental Python client package containing `eona-client` only

## Start Here

- [Install / Upgrade / Maintain](docs/install-upgrade-maintain.md)
- [Import Photos Locally and Remotely](docs/import-photos-locally-remotely.md)
- [Query Semantically](docs/query-semantically.md)
- [Deploy](docs/deploy.md)

## Repo Layout

- `src/eona/`
  current implementation namespace
- `docs/`
  canonical Eona runbooks
- `manifests/`
  release and curation manifests
- `integrations/openclaw/skills/`
  agent-facing lookup and publish workflows
- `deploy/docker/`
  Docker realization for Eona Gateway
- `contracts/` and `artifacts/`
  sealed runtime contracts and assets
