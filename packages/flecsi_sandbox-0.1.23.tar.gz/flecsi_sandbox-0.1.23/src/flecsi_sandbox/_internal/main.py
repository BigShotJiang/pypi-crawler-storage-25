import git
import importlib.resources
from .options import *
from .fileutils import *

# ---------------------------------------------------------------------------- #
# Main
# ---------------------------------------------------------------------------- #


def main() -> None:
    args, dargs = parse_args()

    # ------------------------------------------------------------------------ #
    # Top-level directory
    # ------------------------------------------------------------------------ #

    copy_resource("README.md", args.root)
    copy_resource("support/env.yaml", args.root)
    copy_resource(".clang-format", args.root)
    copy_resource("cmake/version.cmake", args.root)

    format_write(
        "flecsi_sandbox._auxiliary.templates",
        args.root,
        {"INPUTS": ["CMakeLists.txt"]},
        dargs,
    )
    format_write(
        "flecsi_sandbox._auxiliary.templates",
        args.root,
        {"INPUTS": ["version"], "RENAMES": [".version"]},
        dargs,
    )

    # ------------------------------------------------------------------------ #
    # Specializations
    # ------------------------------------------------------------------------ #

    if args.spec == "minimal":
        # modules
        format_write(
            "flecsi_sandbox._auxiliary.templates.minimal.modules",
            args.root / "modules",
            {"INPUTS": ["CMakeLists.txt", "config.hh.in"]},
            dargs,
        )
        # common
        format_write(
            "flecsi_sandbox._auxiliary.templates.minimal.modules.common",
            args.root / "modules/common",
            {"INPUTS": ["CMakeLists.txt", "exports.hh", "types.hh"]},
            dargs,
        )
        # spec
        format_write(
            "flecsi_sandbox._auxiliary.templates.minimal.modules.spec",
            args.root / "modules/spec",
            {
                "INPUTS": [
                    "CMakeLists.txt",
                    "control.hh",
                    "exports.hh",
                    "types.hh",
                ]
            },
            dargs,
        )
        # app
        format_write(
            "flecsi_sandbox._auxiliary.templates.minimal.app",
            args.root / "app",
            {
                "INPUTS": [
                    "advance.cc",
                    "analyze.cc",
                    "CMakeLists.txt",
                    "finalize.cc",
                    "initialize.cc",
                    "state.hh",
                    "types.hh",
                ]
            },
            dargs,
        )
        # tasks
        format_write(
            "flecsi_sandbox._auxiliary.templates.minimal.app.tasks",
            args.root / "app/tasks",
            {
                "INPUTS": [
                    "initialize.hh",
                ]
            },
            dargs,
        )
        # driver
        DRIVER = "flecsi_sandbox._auxiliary.templates.minimal.app"
    elif args.spec == "narray":
        # modules
        format_write(
            "flecsi_sandbox._auxiliary.templates.narray.modules",
            args.root / "modules",
            {"INPUTS": ["CMakeLists.txt", "config.hh.in"]},
            dargs,
        )
        # common
        format_write(
            "flecsi_sandbox._auxiliary.templates.narray.modules.common",
            args.root / "modules/common",
            {
                "INPUTS": [
                    "CMakeLists.txt",
                    "constants.hh",
                    "exports.hh",
                    "labels.hh",
                    "types.hh",
                ]
            },
            dargs,
        )
        # spec
        format_write(
            "flecsi_sandbox._auxiliary.templates.narray.modules.spec",
            args.root / "modules/spec",
            {
                "INPUTS": [
                    "CMakeLists.txt",
                    "control.hh",
                    "exports.hh",
                    "labels.hh",
                    "mesh.hh",
                    "runtime.hh",
                    "types.hh",
                    "utils.hh",
                ]
            },
            dargs,
        )
        format_write(
            "flecsi_sandbox._auxiliary.templates.narray.modules.spec.tasks",
            args.root / "modules/spec/tasks",
            {
                "INPUTS": [
                    "utils.hh",
                ]
            },
            dargs,
        )
        format_write(
            "flecsi_sandbox._auxiliary.templates.narray.modules.spec.test",
            args.root / "modules/spec/test",
            {
                "INPUTS": [
                    "mesh.cc",
                ]
            },
            dargs,
        )
        # app
        format_write(
            "flecsi_sandbox._auxiliary.templates.narray.app",
            args.root / "app",
            {
                "INPUTS": [
                    "advance.hh",
                    "advance.cc",
                    "analyze.hh",
                    "analyze.cc",
                    "CMakeLists.txt",
                    "finalize.hh",
                    "finalize.cc",
                    "initialize.hh",
                    "initialize.cc",
                    "state.hh",
                    "types.hh",
                ]
            },
            dargs,
        )
        # tasks
        format_write(
            "flecsi_sandbox._auxiliary.templates.narray.app.tasks",
            args.root / "app/tasks",
            {
                "INPUTS": [
                    "initialize.hh",
                ]
            },
            dargs,
        )
        # driver
        DRIVER = "flecsi_sandbox._auxiliary.templates.narray.app"
    #    elif args.spec == "unstructured":
    #    else:  # ntree
    #        dargs["SPEC_HEADERS"] = (
    #            "control.hh\n" + "  exports.hh\n" + "  tree.hh\n" + "  types.hh"
    #        )

    format_write(
        DRIVER,
        args.root / "app",
        {"INPUTS": ["driver.cc"], "RENAMES": [args.name + ".cc"]},
        dargs,
    )

    repo = git.Repo.init(args.root)
    copy_resource(".gitignore", args.root)
    repo.index.add(["*", ".*"])
    repo.index.commit("Initial Check-In")
