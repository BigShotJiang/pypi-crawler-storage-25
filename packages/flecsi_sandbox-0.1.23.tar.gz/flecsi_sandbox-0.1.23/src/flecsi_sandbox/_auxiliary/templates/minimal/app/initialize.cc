#include "tasks/initialize.hh"

#include "state.hh"

#include <flecsi/flog.hh>

namespace LC_APPNAME::action {

inline control<state>::action<[](control_policy<state> & cp) {
  flog(info) << "Initialize Action" << std::endl;
  auto & s = cp.state();
  auto & sch = cp.scheduler();

  // Allocate global topology to processes() (default behavior of {})
  sch.allocate(s.gt, {});

  // Initialize time variables
  sch.template execute<tasks::init::time_vars>(
    exec::on, s.t(*s.gt), s.dt(*s.gt), 0.0);
},
  cp::initialize>
  init_action;

} // namespace LC_APPNAME::action
