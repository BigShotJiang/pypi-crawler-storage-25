#ifndef SPEC_EXPORTS_HH
#define SPEC_EXPORTS_HH

#include "types.hh"

namespace spec::type::exports {

using spec::na, spec::ro, spec::wo, spec::rw;

using spec::field;
using spec::global;
using spec::single;

namespace exec = flecsi::exec;

} // namespace spec::type::exports

namespace spec::exports {

using namespace spec::type::exports;

} // namespace spec::exports

#endif // SPEC_EXPORTS_HH
