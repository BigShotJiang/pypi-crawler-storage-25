#ifndef CMMN_EXPORTS_HH
#define CMMN_EXPORTS_HH

#include "types.hh"

namespace cmmn::type::exports {

namespace ft = cmmn::ft;

} // namespace cmmn::type::exports

namespace cmmn::exports {

using namespace cmmn::type::exports;

} // namespace cmmn::exports

#endif // CMMN_EXPORTS_HH
