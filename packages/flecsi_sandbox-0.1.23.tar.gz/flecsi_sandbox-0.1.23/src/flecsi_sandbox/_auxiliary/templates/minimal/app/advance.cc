#include "state.hh"

#include <flecsi/flog.hh>

namespace LC_APPNAME::action {

inline control<state>::action<[](control_policy<state> & cp) {
  flog(info) << "Advance Action: " << cp.step() << std::endl;
},
  cp::advance>
  advance_action;

} // namespace LC_APPNAME::action
