#include "state.hh"

#include <flecsi/flog.hh>

namespace LC_APPNAME::action {

inline control<state>::action<[](control_policy<state> &) {
  flog(info) << "Finalize Action" << std::endl;
},
  cp::finalize>
  final_action;

} // namespace LC_APPNAME::action
