#ifndef UC_APPNAME_TYPES_HH
#define UC_APPNAME_TYPES_HH

#include <modules/common/exports.hh>
#include <modules/spec/control.hh>
#include <modules/spec/exports.hh>

namespace LC_APPNAME {

using namespace cmmn::exports;
using namespace spec::exports;

template<typename S>
using control_policy = spec::control::control_policy<S>;
template<typename S>
using control = flecsi::run::control<control_policy<S>>;
using cp = spec::control::cp;

} // namespace LC_APPNAME

#endif // UC_APPNAME_TYPES_HH
