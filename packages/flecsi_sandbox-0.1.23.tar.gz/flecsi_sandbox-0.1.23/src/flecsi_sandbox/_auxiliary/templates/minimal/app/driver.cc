/*----------------------------------------------------------------------------*
  Driver (main function)
 *----------------------------------------------------------------------------*/

#include "state.hh"

/*
  Headers are ordered by decreasing locality, e.g., directory, project,
  library dependency, standard library.
 */
#include "types.hh"

#include <modules/spec/control.hh>

#include <flecsi/runtime.hh>

using namespace flecsi;
using namespace LC_APPNAME;

int
main(int argc, char ** argv) {
  // Output control model information.
#if defined(UC_APPNAME_WRITE_CONTROL_INFO)
  LC_APPNAME::control<state>::write_graph("UCC_APPNAME", "cm.dot");
  LC_APPNAME::control<state>::write_actions("UCC_APPNAME", "actions.dot");
#endif

  const flecsi::getopt g;
  try {
    g(argc, argv);
  }
  catch(const std::logic_error & e) {
    std::cerr << e.what() << ' ' << g.usage(argc ? argv[0] : "");
    return 1;
  }

  const run::dependencies_guard dg;
  run::config cfg;

  runtime run(cfg);
  flog::add_output_stream("clog", std::clog, true);
  run.control<control<state>>(10, 1);
}
