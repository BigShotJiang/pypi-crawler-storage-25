#include "state.hh"

#include <flecsi/flog.hh>

namespace LC_APPNAME::action {

inline control<state>::action<[](control_policy<state> & cp) {
  flog(info) << "Analyze Action: " << cp.step() << std::endl;
},
  cp::analyze>
  analyze_action;

} // namespace LC_APPNAME::action
