#ifndef SPEC_TYPES_HH
#define SPEC_TYPES_HH

#include <flecsi/data.hh>

namespace spec {

// Concise privileges
inline constexpr flecsi::privilege na = flecsi::na, ro = flecsi::ro,
                                   wo = flecsi::wo, rw = flecsi::rw;

using flecsi::field;
using flecsi::topo::global;
template<typename T>
using single = field<T, flecsi::data::single>;

} // namespace spec

#endif // SPEC_TYPES_HH
