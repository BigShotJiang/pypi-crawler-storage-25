#ifndef COMMON_TYPES_HH
#define COMMON_TYPES_HH

#include <modules/config.hh>

namespace cmmn {

namespace ft {

using real_t = cfg::precision;

} // namespace ft

} // namespace cmmn

#endif // COMMON_TYPES_HH
