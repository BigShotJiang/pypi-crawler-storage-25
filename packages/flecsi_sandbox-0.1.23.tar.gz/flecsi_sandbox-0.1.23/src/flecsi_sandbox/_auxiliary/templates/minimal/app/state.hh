#ifndef UC_APPNAME_STATE_HH
#define UC_APPNAME_STATE_HH

#include "types.hh"

namespace LC_APPNAME {

struct state {

  /*--------------------------------------------------------------------------*
    Topology pointers.
   *--------------------------------------------------------------------------*/

  global::ptr gt; /* Global topology. */

  /*--------------------------------------------------------------------------*
    Global parameters.
   *--------------------------------------------------------------------------*/

  static inline const single<double>::definition<global> t, dt;

  /*--------------------------------------------------------------------------*
    Cycle control.
   *--------------------------------------------------------------------------*/

  static void advance(exec::cpu,
    single<ft::real_t>::accessor<rw> t,
    single<ft::real_t>::accessor<rw> dt) noexcept {
    const ft::real_t tf{1.0};
    dt = *dt;
    dt = t + dt > tf ? tf - t : dt;
    t += dt;
  }

  static bool cycle_control(control_policy<state> & cp) {
    auto & s = cp.state();
    auto & sch = cp.scheduler();
    sch.template execute<advance>(exec::on, s.t(*s.gt), s.dt(*s.gt));
    return true;
  }
};

} // namespace LC_APPNAME

#endif // UC_APPNAME_STATE_HH
