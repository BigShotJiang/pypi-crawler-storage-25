#ifndef COMMON_TYPES_HH
#define COMMON_TYPES_HH

#include <modules/config.hh>

#include <flecsi/data.hh>
#include <flecsi/flog.hh>
#include <flecsi/utilities.hh>

#include <cmath>
#include <cstddef>

namespace cmmn {

// Fundamental types.
namespace ft {

// Floating-point type from preprocessor.
using real_t = cfg::precision;

// Return a tolerance depending on the type of T. The template parameter P,
// 0 < P <= 1, controls how many digits to use out of the maximum available
// for the given type.
// NOTE: P == 0.7 gives a tolerance of 1e-12 for double and 1e-6 for float
template<typename T = ft::real_t, T P = T{0.7}>
T
tolerance() {
  static_assert(P > 0.0 && P <= 1.0, "Invalid scaling value");
  return pow(10, -T{std::round(std::numeric_limits<T>::max_digits10 * P)});
}

} // namespace ft

// Concise privileges.
inline constexpr flecsi::privilege na = flecsi::na, ro = flecsi::ro,
                                   wo = flecsi::wo, rw = flecsi::rw;

// Useful pre-defined topologies.
using flecsi::topo::global;
using flecsi::topo::index;

// Basic field type.
using flecsi::field;

// Single field type, i.e., one per color.
template<typename T>
using single = field<T, flecsi::data::single>;

// Multiaccessor.
using flecsi::data::multi;

// Future.
template<typename T>
using future = flecsi::future<T>;

} // namespace cmmn

#endif // COMMON_TYPES_HH
