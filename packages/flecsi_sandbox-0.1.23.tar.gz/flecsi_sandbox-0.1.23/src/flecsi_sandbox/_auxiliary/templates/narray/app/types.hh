#ifndef UC_APPNAME_TYPES_HH
#define UC_APPNAME_TYPES_HH

#include <modules/common/exports.hh>
#include <modules/spec/control.hh>
#include <modules/spec/exports.hh>

namespace LC_APPNAME {

// flecsi
using color_distribution = flecsi::topo::narray_impl::colors;

// common
using namespace cmmn::exports;

// specialization
using namespace spec::exports;

template<template<std::size_t> typename S, std::size_t D>
using control_policy = spec::control::basic::control_policy<S, D>;
template<template<std::size_t> typename S, std::size_t D>
using control = flecsi::run::control<control_policy<S, D>>;
using cp = spec::control::basic::cp;

} // namespace LC_APPNAME

#endif // UC_APPNAME_TYPES_HH
