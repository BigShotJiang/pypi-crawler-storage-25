#ifndef COMMON_LABELS_HH
#define COMMON_LABELS_HH

namespace cmmn {

namespace uv {
/// Unit vector type (as in vector calculus).
enum unit_vector { i, j, k }; // enum unit_vector
} // namespace uv

} // namespace cmmn

#endif // COMMON_LABELS_HH
