#ifndef UC_APPNAME_INITIALIZE_HH
#define UC_APPNAME_INITIALIZE_HH

#include "state.hh"
#include "tasks/initialize.hh"

#include <modules/spec/runtime.hh>

#include <flecsi/flog.hh>

namespace LC_APPNAME::action {

template<std::size_t D>
struct initialize {
  static void action(control_policy<state, D> & cp) {
    flog(info) << "Initialize Action" << std::endl;

    auto & s = cp.state();
    auto & sch = cp.scheduler();

    // Allocate global topology to processes() (default behavior of {})
    sch.allocate(s.gt, {});

    // Initialize time variables
    sch.template execute<tasks::init::time_vars>(
      flecsi::exec::on, s.t(*s.gt), s.dt(*s.gt), 0.0);
  }
};

static const auto init_action =
  spec::register_action<control, state, initialize, cp::initialize>();

} // namespace LC_APPNAME::action

#endif // UC_APPNAME_INITIALIZE_HH
