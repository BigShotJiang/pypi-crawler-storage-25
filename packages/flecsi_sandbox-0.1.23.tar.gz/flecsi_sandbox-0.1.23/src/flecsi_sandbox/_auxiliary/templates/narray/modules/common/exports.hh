#ifndef COMMON_EXPORTS_HH
#define COMMON_EXPORTS_HH

#include "constants.hh"
#include "labels.hh"
#include "types.hh"

#include <flecsi/data.hh>
#include <flecsi/flog.hh>
#include <flecsi/utilities.hh>

#include <cstddef>

// Suppress irritating warnings in clangd. Probably a better way to do this...
#define NS_WARN_SUPPRESS(n, m)                                                 \
  inline void n##_suppress() {                                                 \
    using m;                                                                   \
  }

/*!
  Basic types that are useful to applications and modules.
 */
namespace cmmn::type::exports {

namespace ft = cmmn::ft;
NS_WARN_SUPPRESS(ft, ft::real_t)

using cmmn::na, cmmn::ro, cmmn::wo, cmmn::rw;

using cmmn::field;
using cmmn::future;
using cmmn::global;
using cmmn::index;
using cmmn::multi;
using cmmn::single;

} // namespace cmmn::type::exports

/*!
  Miscellaneous namespaces that are useful to applications and modules.
 */
namespace cmmn::misc::exports {

namespace cnst = cmmn::cnst;
NS_WARN_SUPPRESS(cnst, cnst::pi)

namespace flog = flecsi::flog;
NS_WARN_SUPPRESS(flog, flog::container)

namespace uv = cmmn::uv;
NS_WARN_SUPPRESS(uv, uv::i)

} // namespace cmmn::misc::exports

/*!
  Exports.
 */
namespace cmmn::exports {

using namespace cmmn::type::exports;
using namespace cmmn::misc::exports;

} // namespace cmmn::exports

#endif // COMMON_EXPORTS_HH
