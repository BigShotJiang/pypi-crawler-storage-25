#ifndef SPEC_EXPORTS_HH
#define SPEC_EXPORTS_HH

#include "mesh.hh"
#include "tasks/utils.hh"
#include "utils.hh"

#include "../common/exports.hh"

#include <cstddef>

/*!
  Basic specialization types that are useful to both applications and modules.
 */
namespace spec::type::exports {

template<std::size_t D>
using mesh = spec::mesh<D>;
} // namespace spec::type::exports

/*!
  Miscellaneous namespaces that are useful to applications and modules.
 */
namespace spec::misc::exports {

namespace ax = spec::ax;
NS_WARN_SUPPRESS(ax, ax::x);

namespace bd = spec::bd;
NS_WARN_SUPPRESS(bd, bd::low);

namespace dm = spec::dm;
NS_WARN_SUPPRESS(dm, dm::all);

namespace is = spec::is;
NS_WARN_SUPPRESS(is, is::cells);

namespace util = spec::util;
using tasks::printer;
using util::mdiota_view;

} // namespace spec::misc::exports

/*!
  Exports.
 */
namespace spec::exports {
using namespace spec::type::exports;
using namespace spec::misc::exports;
} // namespace spec::exports

#endif // SPEC_EXPORTS_HH
