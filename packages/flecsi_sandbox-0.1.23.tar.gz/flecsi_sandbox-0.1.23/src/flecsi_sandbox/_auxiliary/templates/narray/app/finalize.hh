#ifndef UC_APPNAME_FINALIZE_HH
#define UC_APPNAME_FINALIZE_HH

#include "state.hh"

#include <modules/spec/runtime.hh>

#include <flecsi/flog.hh>

namespace LC_APPNAME::action {

template<std::size_t D>
struct finalize {
  static void action(control_policy<state, D> & cp) {
    flog(info) << "Finalize Action: " << cp.step() << std::endl;
  }
};

static const auto finalize_action =
  spec::register_action<control, state, finalize, cp::finalize>();

} // namespace LC_APPNAME::action

#endif // UC_APPNAME_FINALIZE_HH
