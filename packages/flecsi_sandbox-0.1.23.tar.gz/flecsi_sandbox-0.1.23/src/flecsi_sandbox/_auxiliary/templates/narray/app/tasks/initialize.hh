#ifndef UC_APPNAME_TASKS_INITIALIZE_HH
#define UC_APPNAME_TASKS_INITIALIZE_HH

#include "../types.hh"

namespace LC_APPNAME::tasks::init {

void inline time_vars(flecsi::exec::cpu,
  single<ft::real_t>::accessor<wo> t,
  single<ft::real_t>::accessor<wo> dt,
  ft::real_t t0) noexcept {
  t = t0;
  dt = 0.1;
}

} // namespace LC_APPNAME::tasks::init

#endif // UC_APPNAME_TASKS_INITIALIZE_HH
