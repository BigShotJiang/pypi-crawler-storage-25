#ifndef UC_APPNAME_ANALYZE_HH
#define UC_APPNAME_ANALYZE_HH

#include "state.hh"

#include <modules/spec/runtime.hh>

#include <flecsi/flog.hh>

namespace LC_APPNAME::action {

template<std::size_t D>
struct analyze {
  static void action(control_policy<state, D> & cp) {
    flog(info) << "Analyze Action: " << cp.step() << std::endl;
  }
};

static const auto analyze_action =
  spec::register_action<control, state, analyze, cp::analyze>();

} // namespace LC_APPNAME::action

#endif // UC_APPNAME_ANALYZE_HH
