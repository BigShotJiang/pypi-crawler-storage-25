#ifndef UC_APPNAME_ADVANCE_HH
#define UC_APPNAME_ADVANCE_HH

#include "state.hh"

#include <modules/spec/runtime.hh>

#include <flecsi/flog.hh>

namespace LC_APPNAME::action {

template<std::size_t D>
struct advance {
  static void action(control_policy<state, D> & cp) {
    flog(info) << "Advance Action: " << cp.step() << std::endl;
  }
};

static const auto advance_action =
  spec::register_action<control, state, advance, cp::advance>();

} // namespace LC_APPNAME::action

#endif // UC_APPNAME_ADVANCE_HH
