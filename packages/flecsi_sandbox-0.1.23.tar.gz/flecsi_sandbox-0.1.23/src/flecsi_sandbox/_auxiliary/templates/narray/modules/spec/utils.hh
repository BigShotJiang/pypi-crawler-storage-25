#ifndef SPEC_UTILS_HH
#define SPEC_UTILS_HH

#include <flecsi/execution.hh>
#include <flecsi/flog.hh>

#include <type_traits>

namespace spec::util {

template<typename T>
FLECSI_INLINE_TARGET std::enable_if_t<std::is_arithmetic_v<T>, T>
sqr(T t) {
  return t * t;
}

template<typename MD, typename IT>
FLECSI_INLINE_TARGET auto
mdiota_view(MD const & md, IT const & i, IT const & j) {
  return flecsi::exec::mdiota_view(md,
    flecsi::exec::sub_range{*i.begin(), *i.end()},
    flecsi::exec::sub_range{*j.begin(), *j.end()});
} // mdiota_view

template<typename MD, typename IT>
FLECSI_INLINE_TARGET auto
mdiota_view(MD const & md, IT const & i, IT const & j, IT const & k) {
  return flecsi::exec::mdiota_view(md,
    flecsi::exec::sub_range{*i.begin(), *i.end()},
    flecsi::exec::sub_range{*j.begin(), *j.end()},
    flecsi::exec::sub_range(*k.begin(), *k.end()));
} // mdiota_view

} // namespace spec::util

#endif // SPEC_UTILS_HH
