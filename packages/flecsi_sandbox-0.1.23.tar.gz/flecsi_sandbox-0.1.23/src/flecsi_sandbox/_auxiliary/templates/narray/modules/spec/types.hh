#ifndef SPEC_TYPES_HH
#define SPEC_TYPES_HH

#include "../common/exports.hh"
#include "mesh.hh"

namespace spec {

using namespace cmmn::exports;

} // namespace spec

#endif // SPEC_TYPES_HH
