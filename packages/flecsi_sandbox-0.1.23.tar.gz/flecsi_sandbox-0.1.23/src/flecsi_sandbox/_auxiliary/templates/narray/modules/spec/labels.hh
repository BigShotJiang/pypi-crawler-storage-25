#ifndef SPEC_LABELS_HH
#define SPEC_LABELS_HH

namespace spec {

namespace ax {
/// Mesh axis.
/// The axis identifies the spatial axis in the Cartesian space.
enum axis {
  /// The x axis.
  x,
  /// The y axis.
  y,
  /// The z axis.
  z
};
} // namespace ax

namespace is {
enum index_space { cells };
}

namespace dm {
/// Mesh domains.
/// The domain identifies the supported iteration spaces on the mesh.
enum domain {
  /// This domain includes the locations of the unknowns of the problem state.
  quantities,
  /// This domain includes all mesh locations where it is possible to compute
  /// a 2nd-order slope approximation.
  predictor,
  /// This domain includes all mesh locations where it is possible to compute
  /// a flux across an interface from reconstructed predictor quantities.
  corrector,
  /// This domain includes all the degrees of freedom for the elliptic solver.
  interior,
  /// This domain includes the low ghosts.
  ghost_low,
  /// This domain includes the high ghosts.
  ghost_high,
  /// This domain includes all local cells, including halo and boundary cells.
  all,
  /// This domain includes all global cells.
  global
};
} // namespace dm

namespace bd {
/// Boundary.
/// Identifies the low or high boundary along a particular axis.
enum boundary {
  /// Low axis boundary.
  low,
  /// High axis boundary.
  high
}; // enum boundary
} // namespace bd

} // namespace spec

#endif // SPEC_LABELS_HH
