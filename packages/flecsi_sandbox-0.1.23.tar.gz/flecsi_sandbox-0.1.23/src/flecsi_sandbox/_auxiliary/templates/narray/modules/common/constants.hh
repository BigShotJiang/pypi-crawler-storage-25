#ifndef COMMON_CONSTANTS_HH
#define COMMON_CONSTANTS_HH

#include "types.hh"

#include <cmath>
#include <limits>

namespace cmmn::cnst {

static constexpr ft::real_t pi [[maybe_unused]] = M_PI;
static constexpr ft::real_t e [[maybe_unused]] = M_E;

static constexpr ft::real_t real_low [[maybe_unused]] =
  std::numeric_limits<ft::real_t>::lowest();
static constexpr ft::real_t real_min [[maybe_unused]] =
  std::numeric_limits<ft::real_t>::min();
static constexpr ft::real_t real_max [[maybe_unused]] =
  std::numeric_limits<ft::real_t>::max();

} // namespace cmmn::cnst

#endif // COMMON_CONSTANTS_HH
