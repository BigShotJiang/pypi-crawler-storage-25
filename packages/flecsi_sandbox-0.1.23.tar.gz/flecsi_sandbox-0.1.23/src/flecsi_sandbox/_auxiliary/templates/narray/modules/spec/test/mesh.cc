#include "../mesh.hh"
#include "../labels.hh"

#include <flecsi/util/unit.hh>

using namespace flecsi;
using namespace spec;

template<std::size_t D>
int
initialization_test(scheduler & sc) {
  UNIT("TASK") {
    // Periodic boundary indicator.
    std::array<bool, D> pb;

    // Unit hypercube.
    typename mesh<D>::grect geom;
    geom[ax::x][bd::low] = 0.0;
    geom[ax::x][bd::high] = 1.0;

    if(D == 2 || D == 3) {
      geom[ax::y][bd::low] = 0.0;
      geom[ax::y][bd::high] = 1.0;
    } // if

    if(D == 3) {
      geom[ax::z][bd::low] = 0.0;
      geom[ax::z][bd::high] = 1.0;
    } // if

    typename mesh<D>::gcoord axis_extents(D);
    axis_extents[ax::x] = 32;

    if(D == 2 || D == 3) {
      axis_extents[ax::y] = 32;
    } // if

    if(D == 3) {
      axis_extents[ax::z] = 32;
    } // if

    typename mesh<D>::ptr m;
    sc.allocate(m,
      typename mesh<D>::mpi_coloring(
        sc, sc.runtime().processes(), axis_extents, pb),
      geom);
  };
} // initialize_mesh

int
mesh_driver(scheduler & sc) {
  UNIT("DRIVER") {
    EXPECT_EQ(initialization_test<1>(sc), 0);
    EXPECT_EQ(initialization_test<2>(sc), 0);
    EXPECT_EQ(initialization_test<3>(sc), 0);
  }; // UNIT
} // mesh_driver

flecsi::util::unit::driver<mesh_driver> driver;
