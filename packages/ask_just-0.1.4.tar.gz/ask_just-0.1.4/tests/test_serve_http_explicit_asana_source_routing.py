import os
import sqlite3
import sys
import unittest


ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
SCRIPTS = os.path.join(ROOT, "scripts")
if SCRIPTS not in sys.path:
    sys.path.insert(0, SCRIPTS)

import serve_http


class ServeHttpExplicitAsanaSourceRoutingTests(unittest.TestCase):
    def test_explicit_asana_source_keeps_project_status_adapter_hint(self):
        conn = sqlite3.connect(":memory:")
        conn.row_factory = sqlite3.Row
        conn.execute("CREATE TABLE sources (source_id TEXT PRIMARY KEY)")
        conn.execute("INSERT INTO sources VALUES ('asana_work_management')")

        plan = serve_http.build_source_query_plan(
            conn,
            "What is the Select v6 project status in Asana? Return source id and row provenance.",
            requested_source="asana_work_management",
        )

        self.assertEqual(len(plan), 1)
        self.assertEqual(plan[0]["source_id"], "asana_work_management")
        self.assertEqual(plan[0]["adapter_hint"], "asana_project_status")


if __name__ == "__main__":
    unittest.main()
