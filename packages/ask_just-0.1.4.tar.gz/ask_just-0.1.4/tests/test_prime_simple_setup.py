import pathlib
import os
import tempfile
import tomllib
import unittest
from unittest import mock

import ask_just_cli
from ask_just_cli import cli
from ask_just_cli.agent_setup import setup_agents


ROOT = pathlib.Path(__file__).resolve().parents[1]


class PrimeSimpleSetupTests(unittest.TestCase):
    def test_pyproject_exposes_ask_just_console_script(self):
        data = tomllib.loads((ROOT / "pyproject.toml").read_text())
        self.assertEqual(data["project"]["name"], "ask-just")
        self.assertEqual(data["project"]["version"], ask_just_cli.__version__)
        self.assertEqual(data["project"]["version"], "0.1.4")
        self.assertEqual(data["project"]["requires-python"], ">=3.10")
        self.assertEqual(data["project"]["scripts"]["ask-just"], "ask_just_cli.cli:main")
        self.assertIn("skills/*/SKILL.md", data["tool"]["setuptools"]["package-data"]["ask_just_cli"])
        self.assertIn("skills/*/scripts/*", data["tool"]["setuptools"]["package-data"]["ask_just_cli"])
        self.assertIn("skills/*/agents/*", data["tool"]["setuptools"]["package-data"]["ask_just_cli"])

    def test_setup_agents_writes_company_scoped_codex_and_claude_files(self):
        with tempfile.TemporaryDirectory() as home:
            result = setup_agents(home=home, agents=("codex", "claude"))
            self.assertTrue(result["ok"])

            root = pathlib.Path(home)
            for skill_name in ("askjust", "just-source", "correction", "braintrust"):
                canonical = (ROOT / "skills" / skill_name / "SKILL.md").read_bytes()
                self.assertEqual((root / ".codex" / "skills" / skill_name / "SKILL.md").read_bytes(), canonical)
                self.assertEqual((root / ".claude" / "skills" / skill_name / "SKILL.md").read_bytes(), canonical)
            self.assertEqual((root / ".codex" / "AGENTS.md").read_text().count("ASK_JUST_INSTALLER_BEGIN"), 1)
            self.assertEqual((root / ".claude" / "CLAUDE.md").read_text().count("ASK_JUST_INSTALLER_BEGIN"), 1)

    def test_setup_command_uses_stable_code_without_printing_token(self):
        def fake_request_json(url, token=None, method="GET", payload=None):
            if url.endswith("/onboarding/exchange"):
                self.assertEqual(payload, {"code": "JST-STABLE"})
                return {"ok": True, "token": "secret-token", "email": "teammate@example.com", "label": "team"}
            if url.endswith("/ready") or url.endswith("/health"):
                return {"ok": True}
            if url.endswith("/sources"):
                return {"ok": True, "rows": [{"source_id": "scorecard_monthly_data"}]}
            if url.endswith("/query"):
                self.assertEqual(payload["question"], "what is the pH of reefer meat original?")
                return {
                    "ok": True,
                    "answer": "pH 6.1",
                    "source_id": "batch_release_app",
                    "rows": [{"row_number": 1}],
                }
            return {"ok": True}

        with tempfile.TemporaryDirectory() as home:
            config_path = pathlib.Path(home) / ".config" / "ask-just" / "config.json"
            env = {
                "HOME": home,
                "ASK_JUST_BIN": str(pathlib.Path(home) / ".local" / "bin" / "ask-just"),
                "CODEX_HOME": str(pathlib.Path(home) / ".codex"),
            }
            bin_path = pathlib.Path(env["ASK_JUST_BIN"])

            def fake_persistent_cli():
                bin_path.parent.mkdir(parents=True, exist_ok=True)
                bin_path.write_text("#!/usr/bin/env sh\n")
                bin_path.chmod(0o755)
                os.environ["PATH"] = str(bin_path.parent) + os.pathsep + os.environ.get("PATH", "")
                return str(bin_path)

            with (
                mock.patch.object(cli, "CONFIG_PATH", str(config_path)),
                mock.patch.object(cli, "request_json", side_effect=fake_request_json),
                mock.patch.object(cli, "ensure_persistent_cli", side_effect=fake_persistent_cli),
                mock.patch.dict(os.environ, env, clear=False),
                mock.patch("sys.stdout") as stdout,
            ):
                code = cli.main(["setup", "--code", "JST-STABLE"])
                output = "".join(call.args[0] for call in stdout.write.call_args_list)

        self.assertEqual(code, 0)
        self.assertNotIn("secret-token", output)
        self.assertIn('"status": "ready"', output)
        self.assertIn('"source_id": "batch_release_app"', output)

    def test_setup_prefers_uv_tool_install_for_persistent_cli(self):
        with tempfile.TemporaryDirectory() as home:
            bin_path = pathlib.Path(home) / ".local" / "bin" / "ask-just"
            env = {
                "HOME": home,
                "ASK_JUST_BIN": str(bin_path),
                "ASK_JUST_TOOL_SOURCE": ".",
                "PATH": os.pathsep.join(["/tmp/uvx-shadow", str(bin_path.parent), os.environ.get("PATH", "")]),
            }
            completed = mock.Mock(returncode=0)
            with (
                mock.patch.object(cli.shutil, "which", return_value="/usr/local/bin/uv"),
                mock.patch.object(cli.subprocess, "run", return_value=completed) as run,
                mock.patch.dict(os.environ, env, clear=False),
            ):
                self.assertEqual(cli.ensure_persistent_cli(), str(bin_path))
                self.assertEqual(os.environ["PATH"].split(os.pathsep)[0], str(bin_path.parent))

        self.assertEqual(run.call_args.args[0], ["/usr/local/bin/uv", "tool", "install", "-U", "--from", ".", "ask-just"])

    def test_login_command_exchanges_stable_code_and_refreshes_agents(self):
        def fake_request_json(url, token=None, method="GET", payload=None):
            if url.endswith("/onboarding/exchange"):
                self.assertEqual(payload, {"code": "JST-STABLE"})
                return {"ok": True, "token": "secret-token", "email": "teammate@example.com", "label": "team"}
            return {"ok": True}

        with tempfile.TemporaryDirectory() as home:
            config_path = pathlib.Path(home) / ".config" / "ask-just" / "config.json"
            with (
                mock.patch.object(cli, "CONFIG_PATH", str(config_path)),
                mock.patch.object(cli, "request_json", side_effect=fake_request_json),
                mock.patch.dict(os.environ, {"HOME": home}, clear=False),
                mock.patch("sys.stdout") as stdout,
            ):
                code = cli.main(["login", "--setup-code", "JST-STABLE"])
                output = "".join(call.args[0] for call in stdout.write.call_args_list)

            self.assertEqual(code, 0)
            self.assertNotIn("secret-token", output)
            self.assertIn('"login": "configured"', output)
            self.assertTrue((pathlib.Path(home) / ".codex" / "skills" / "askjust" / "SKILL.md").exists())
            self.assertTrue((pathlib.Path(home) / ".claude" / "skills" / "askjust" / "SKILL.md").exists())

    def test_setup_agent_accepts_quiet_and_if_stale_refresh_flags(self):
        with tempfile.TemporaryDirectory() as home:
            env = {
                "HOME": home,
                "CODEX_HOME": str(pathlib.Path(home) / ".codex"),
                "CLAUDE_HOME": str(pathlib.Path(home) / ".claude"),
            }
            with mock.patch.dict(os.environ, env, clear=False), mock.patch("sys.stdout") as stdout:
                with self.assertRaises(SystemExit) as first_exit:
                    cli.main(["setup-agent", "--quiet"])
                with self.assertRaises(SystemExit) as second_exit:
                    cli.main(["setup-agent", "--if-stale", "--quiet"])

            self.assertEqual(first_exit.exception.code, 0)
            self.assertEqual(second_exit.exception.code, 0)
            self.assertEqual(stdout.write.call_args_list, [])
            self.assertTrue((pathlib.Path(home) / ".codex" / "skills" / "askjust" / "SKILL.md").exists())
            self.assertTrue((pathlib.Path(home) / ".claude" / "skills" / "askjust" / "SKILL.md").exists())

    def test_clean_home_verifier_runs_prime_simple_setup(self):
        text = (ROOT / "scripts" / "verify_prime_simple_setup.py").read_text()
        self.assertIn("ASK_JUST_SETUP_CODE", text)
        self.assertIn("ASK_JUST_TOOL_SOURCE", text)
        self.assertIn('"uvx"', text)
        self.assertIn('"--from"', text)
        self.assertIn('"ask-just"', text)
        self.assertIn('"setup"', text)
        self.assertIn('"--code"', text)
