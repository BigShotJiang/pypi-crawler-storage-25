import json
import os
import sqlite3
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
SOURCE_ID = "operations_order_allocation"


class OperationsOrderAllocationSourceTests(unittest.TestCase):
    def test_declared_but_not_queryable_until_order_allocation_sources_are_ingested(self):
        all_source_ids = json.loads((ROOT / "config" / "all-source-ids.json").read_text())
        queryable_source_ids = json.loads((ROOT / "config" / "queryable-source-ids.json").read_text())

        self.assertIn(SOURCE_ID, all_source_ids)
        self.assertNotIn(SOURCE_ID, queryable_source_ids)

    def test_ask_just_actions_are_not_separate_agents(self):
        readme = (ROOT / "README.md").read_text()
        spec = (ROOT / "SPEC.md").read_text()
        architecture = (ROOT / "ARCHITECTURE.md").read_text()
        combined = "\n".join([readme, spec, architecture])

        self.assertIn("Ask Just Actions", combined)
        self.assertIn("No separate agent", combined)
        self.assertIn("company brain, hands, and arms", combined)
        self.assertIn("order allocation", combined)

    def test_builder_records_explicit_order_allocation_source_gap(self):
        receipt_path = ROOT / "receipts" / "fresh" / f"source-granularity-{SOURCE_ID}.json"
        original_receipt = receipt_path.read_text(encoding="utf-8") if receipt_path.exists() else None
        self.addCleanup(
            lambda: receipt_path.write_text(original_receipt, encoding="utf-8")
            if original_receipt is not None
            else receipt_path.unlink(missing_ok=True)
        )
        with tempfile.TemporaryDirectory() as tmp:
            artifact_dir = Path(tmp)
            empty_proof_dir = artifact_dir / "empty-source-family-proofs"
            empty_proof_dir.mkdir()
            env = os.environ.copy()
            env["ASK_JUST_ORDER_ALLOCATION_SOURCE_FAMILY_PROOF_DIR"] = str(empty_proof_dir)
            result = subprocess.run(
                [
                    sys.executable,
                    str(ROOT / "scripts" / "build_fresh_source_database.py"),
                    "--artifact-dir",
                    str(artifact_dir),
                    "--source-id",
                    SOURCE_ID,
                ],
                cwd=ROOT,
                text=True,
                capture_output=True,
                env=env,
            )

            self.assertEqual(result.returncode, 0, result.stderr + result.stdout)

            db_path = artifact_dir / "source_index.sqlite"
            conn = sqlite3.connect(db_path)
            conn.row_factory = sqlite3.Row
            try:
                source_row = conn.execute(
                    "SELECT mapped, accessible, atomically_queryable, notes_json FROM sources WHERE source_id = ?",
                    (SOURCE_ID,),
                ).fetchone()
                atomic_rows = conn.execute(
                    "SELECT COUNT(*) AS n FROM atomic_rows WHERE source_id = ?",
                    (SOURCE_ID,),
                ).fetchone()["n"]
            finally:
                conn.close()

            self.assertIsNotNone(source_row)
            self.assertEqual(source_row["mapped"], "yes")
            self.assertEqual(source_row["accessible"], "no")
            self.assertEqual(source_row["atomically_queryable"], "no")
            self.assertEqual(atomic_rows, 0)

            notes = "\n".join(json.loads(source_row["notes_json"]))
            self.assertIn("inventory@ju.st", notes)
            self.assertIn("Evista", notes)
            self.assertIn("open order demand", notes)
            self.assertIn("customer/SKU/location/carrier routing", notes)
            self.assertIn("human approval", notes)
            self.assertIn("NetSuite commit", notes)

            receipt = json.loads(receipt_path.read_text())
            self.assertFalse(receipt["ok"])
            self.assertIn("inventory@ju.st", "\n".join(receipt["gaps"]))


if __name__ == "__main__":
    unittest.main()
