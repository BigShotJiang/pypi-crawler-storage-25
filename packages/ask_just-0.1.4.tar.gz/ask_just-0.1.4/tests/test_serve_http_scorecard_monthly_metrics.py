import json
import os
import sqlite3
import sys
import unittest


ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
SCRIPTS = os.path.join(ROOT, "scripts")
if SCRIPTS not in sys.path:
    sys.path.insert(0, SCRIPTS)

import serve_http


class ServeHttpScorecardMonthlyMetricTests(unittest.TestCase):
    def make_conn(self):
        conn = sqlite3.connect(":memory:")
        conn.row_factory = sqlite3.Row
        conn.executescript(
            """
            CREATE TABLE sources (source_id TEXT PRIMARY KEY, boundary_json TEXT);
            CREATE TABLE source_files (
                source_id TEXT,
                path TEXT,
                sha256 TEXT,
                modified_at TEXT,
                parsed TEXT,
                provenance_grain TEXT
            );
            CREATE TABLE atomic_rows (
                source_id TEXT,
                source_table TEXT,
                source_file TEXT,
                row_json TEXT,
                provenance_grain TEXT,
                row_key TEXT,
                row_index INTEGER
            );
            """
        )
        conn.execute("INSERT INTO sources VALUES (?, ?)", ("scorecard_monthly_data", "[]"))
        conn.execute(
            "INSERT INTO source_files VALUES (?, ?, ?, ?, ?, ?)",
            ("scorecard_monthly_data", "scorecard://monthly", "abc", "now", "yes", "{}"),
        )
        return conn

    def insert_metric_row(self, conn, row_key):
        conn.execute(
            "INSERT INTO atomic_rows VALUES (?, ?, ?, ?, ?, ?, ?)",
            (
                "scorecard_monthly_data",
                "scorecard_monthly_metric_fields",
                "scorecard://monthly",
                json.dumps({"row_key": row_key, "metric": row_key.split(":", 1)[1], "value": 123}),
                json.dumps({"source_id": "scorecard_monthly_data", "locator": f"scorecard://monthly#{row_key}"}),
                row_key,
                1,
            ),
        )

    def planned_rows_for(self, question):
        conn = self.make_conn()
        self.insert_metric_row(conn, "Mar '26:gross_revenue")
        self.insert_metric_row(conn, "Mar '26:retail_revenue")
        self.insert_metric_row(conn, "Mar '26:fs_revenue")
        service = serve_http.AskJustService("", "")
        return service._planned_structured_adapter_result(
            conn,
            question,
            {"source_id": "scorecard_monthly_data"},
            "all",
            5,
        )["rows"]

    def test_retail_revenue_uses_retail_revenue_metric(self):
        rows = self.planned_rows_for("For the Scorecard lane, what was retail revenue in March 2026?")
        self.assertEqual(len(rows), 1)
        self.assertIn("retail_revenue", rows[0]["snippet"])

    def test_foodservice_revenue_uses_fs_revenue_metric(self):
        rows = self.planned_rows_for("Which Scorecard record supports foodservice revenue for March 2026?")
        self.assertEqual(len(rows), 1)
        self.assertIn("fs_revenue", rows[0]["snippet"])

    def test_explicit_scorecard_monthly_beats_other_hosted_lanes(self):
        conn = self.make_conn()
        for source_id in ("dot_foodservice_weekly_sales", "replace_enter_repo_github", "operations_logistics_otif_2024v2"):
            conn.execute("INSERT INTO sources VALUES (?, ?)", (source_id, "[]"))

        plan = serve_http.build_source_query_plan(
            conn,
            "For the Scorecard lane, what was foodservice revenue in April 2026? Include source id and row locator.",
        )

        self.assertEqual([step["source_id"] for step in plan], ["scorecard_monthly_data"])


if __name__ == "__main__":
    unittest.main()
