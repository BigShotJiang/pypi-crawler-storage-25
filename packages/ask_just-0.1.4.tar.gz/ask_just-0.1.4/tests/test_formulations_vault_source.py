import importlib.util
import json
import sys
import unittest
from pathlib import Path

import yaml


ROOT = Path(__file__).resolve().parents[1]
SOURCE_ID = "rd_formulations_vault_production_formulas"


def load_builder():
    scripts_dir = ROOT / "scripts"
    if str(scripts_dir) not in sys.path:
        sys.path.insert(0, str(scripts_dir))
    spec = importlib.util.spec_from_file_location(
        "build_fresh_source_database",
        ROOT / "scripts" / "build_fresh_source_database.py",
    )
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


class FormulationsVaultSourceTest(unittest.TestCase):
    def test_formulations_vault_lane_is_declared_queryable_and_canonical(self):
        all_source_ids = json.loads((ROOT / "config/all-source-ids.json").read_text())
        queryable_source_ids = json.loads((ROOT / "config/queryable-source-ids.json").read_text())
        fresh_map = yaml.safe_load((ROOT / "config/fresh-source-map.yaml").read_text())
        fresh_sources = {source["id"]: source for source in fresh_map["sources"]}
        builder = load_builder()

        self.assertIn(SOURCE_ID, all_source_ids)
        self.assertIn(SOURCE_ID, queryable_source_ids)
        self.assertIn(SOURCE_ID, fresh_sources)
        self.assertIn(SOURCE_ID, builder.SOURCES)

        source = builder.SOURCES[SOURCE_ID]
        self.assertEqual(source["source_type"], "sharepoint_document_library")
        self.assertEqual(source["business_domain"], "r_and_d_production_formulas")
        self.assertEqual(source["parser"], "sharepoint_document_library")

        sharepoint = source["sharepoint"]
        self.assertEqual(sharepoint["site_path"], "/sites/rd")
        self.assertEqual(sharepoint["library"], "Formulations-Vault")
        self.assertEqual(sharepoint["folder_path"], "/")
        self.assertEqual(sharepoint["drive_id"], "b!hMt_G2w6GEioY6tUiLjkS6yh7KcCAhxLmQIqFnBlFVEZymVI0XPKS4LTcK_NJexg")

        declared = fresh_sources[SOURCE_ID]["declared_boundary"]
        self.assertEqual(declared["type"], "sharepoint_document_library_recursive_root")
        self.assertEqual(declared["library"], "Formulations-Vault")
        self.assertEqual(declared["folder_path"], "/")
        self.assertIn("production formula", fresh_sources[SOURCE_ID]["human_annotations"]["canonical_use"].lower())


if __name__ == "__main__":
    unittest.main()
