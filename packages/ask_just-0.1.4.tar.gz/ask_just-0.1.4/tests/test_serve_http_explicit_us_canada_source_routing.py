import os
import sqlite3
import sys
import unittest


ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
SCRIPTS = os.path.join(ROOT, "scripts")
if SCRIPTS not in sys.path:
    sys.path.insert(0, SCRIPTS)

import serve_http


class ServeHttpExplicitUSCanadaSourceRoutingTests(unittest.TestCase):
    def test_explicit_us_canada_source_keeps_bom_pnl_adapter_hint(self):
        conn = sqlite3.connect(":memory:")
        conn.row_factory = sqlite3.Row
        conn.execute("CREATE TABLE sources (source_id TEXT PRIMARY KEY)")
        conn.execute("INSERT INTO sources VALUES ('just_us_canada_p_and_l_boms')")

        plan = serve_http.build_source_query_plan(
            conn,
            "For Just US and Canada only, what BOM or P&L evidence exists for Just Egg liquid? Return source id and row provenance.",
            requested_source="just_us_canada_p_and_l_boms",
        )

        self.assertEqual(len(plan), 1)
        self.assertEqual(plan[0]["source_id"], "just_us_canada_p_and_l_boms")
        self.assertEqual(plan[0]["adapter_hint"], "just_us_canada_bom_pnl")


if __name__ == "__main__":
    unittest.main()
