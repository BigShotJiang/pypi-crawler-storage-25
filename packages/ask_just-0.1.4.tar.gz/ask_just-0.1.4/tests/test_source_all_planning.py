import json
import os
import sqlite3
import sys
import tempfile
import unittest


ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
SCRIPTS = os.path.join(ROOT, "scripts")
if SCRIPTS not in sys.path:
    sys.path.insert(0, SCRIPTS)

import serve_http


def provenance(source_id, locator):
    return json.dumps(
        {
            "source_id": source_id,
            "grain_type": "test",
            "grain_id": f"{source_id}:row",
            "locator": locator,
            "as_of": "2026-05-06T00:00:00Z",
        }
    )


class SourceAllPlanningTests(unittest.TestCase):
    def assertCanonicalRoutePlanSteps(self, route_plan):
        expected_keys = {"source_id", "adapter", "route_shape", "row_count", "fallback_policy"}
        for step in route_plan:
            self.assertTrue(expected_keys.issubset(step.keys()), step)

    def insert_batch_release_ph_fixture(self, service, batch_number, batch_id, product_name, production_date, ph, flavor_variant=""):
        conn = sqlite3.connect(service.db_path)
        try:
            conn.execute(
                "INSERT INTO atomic_rows VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                (
                    f"batch_release:record:{batch_number}:productName",
                    "batch_release_app",
                    "batch_release_record_fields",
                    "batch_release_app_state",
                    "",
                    1,
                    f"{batch_number}:productName",
                    json.dumps(
                        {
                            "batch_id": batch_id,
                            "batch_number": batch_number,
                            "field": "productName",
                            "product_name": product_name,
                            "production_date": production_date,
                            "status": "released",
                            "value": product_name,
                        }
                    ),
                    f"{batch_number} {product_name} productName",
                    provenance("batch_release_app", f"batch_release:batches#record={batch_number}&field=productName"),
                ),
            )
            conn.execute(
                "INSERT INTO atomic_rows VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                (
                    f"batch_release:record:{batch_number}:flavorVariant",
                    "batch_release_app",
                    "batch_release_record_fields",
                    "batch_release_app_state",
                    "",
                    1,
                    f"{batch_number}:flavorVariant",
                    json.dumps(
                        {
                            "batch_id": batch_id,
                            "batch_number": batch_number,
                            "field": "flavorVariant",
                            "product_name": product_name,
                            "production_date": production_date,
                            "status": "released",
                            "value": flavor_variant,
                        }
                    ),
                    f"{batch_number} {flavor_variant} flavorVariant",
                    provenance("batch_release_app", f"batch_release:batches#record={batch_number}&field=flavorVariant"),
                ),
            )
            conn.execute(
                "INSERT INTO atomic_rows VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                (
                    f"batch_release:product_tests:{batch_id}:batchNumber",
                    "batch_release_app",
                    "batch_release_product_tests_fields",
                    "batch_release_app_state",
                    "",
                    1,
                    f"batch_release:product_tests:{batch_id}:batchNumber",
                    json.dumps(
                        {
                            "app_state_key": f"batch_release:product_tests:{batch_id}",
                            "field": "batchNumber",
                            "key_family": "product_tests",
                            "row_key": f"batch_release:product_tests:{batch_id}:batchNumber",
                            "source": "batch-release",
                            "value": batch_number,
                        }
                    ),
                    f"{batch_number} batch number",
                    provenance("batch_release_app", f"batch_release:product_tests:{batch_id}#field=batchNumber"),
                ),
            )
            conn.execute(
                "INSERT INTO atomic_rows VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                (
                    f"batch_release:product_tests:{batch_id}:pH",
                    "batch_release_app",
                    "batch_release_product_tests_fields",
                    "batch_release_app_state",
                    "",
                    1,
                    f"batch_release:product_tests:{batch_id}:pH",
                    json.dumps(
                        {
                            "app_state_key": f"batch_release:product_tests:{batch_id}",
                            "field": "pH",
                            "key_family": "product_tests",
                            "row_key": f"batch_release:product_tests:{batch_id}:pH",
                            "source": "batch-release",
                            "value": ph,
                        }
                    ),
                    f"{batch_number} pH {ph}",
                    provenance("batch_release_app", f"batch_release:product_tests:{batch_id}#field=pH"),
                ),
            )
            conn.commit()
        finally:
            conn.close()

    def insert_batch_release_sauce_ph_fixture(self, service, record_index, lot_code, sauce_type, production_date, ph):
        conn = sqlite3.connect(service.db_path)
        try:
            fields = {
                "lotCode": lot_code,
                "type": sauce_type,
                "productionDate": production_date,
                "pH": ph,
            }
            for field, value in fields.items():
                conn.execute(
                    "INSERT INTO atomic_rows VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                    (
                        f"batch_release:iqkitchen:mixing_sauce:[{record_index}].{field}",
                        "batch_release_app",
                        "batch_release_iqkitchen_mixing_sauce_fields",
                        "batch_release_app_state",
                        "",
                        record_index,
                        f"batch_release:iqkitchen:mixing_sauce:[{record_index}].{field}",
                        json.dumps(
                            {
                                "field": f"[{record_index}].{field}",
                                "key_family": "iqkitchen:mixing_sauce",
                                "row_key": f"batch_release:iqkitchen:mixing_sauce:[{record_index}].{field}",
                                "source": "batch-release",
                                "value": value,
                            }
                        ),
                        f"{lot_code} {sauce_type} {field} {value}",
                        provenance("batch_release_app", f"batch_release:iqkitchen:mixing_sauce#[{record_index}].{field}"),
                    ),
                )
            conn.commit()
        finally:
            conn.close()

    def make_service(self):
        tmp = tempfile.TemporaryDirectory()
        db_path = os.path.join(tmp.name, "source_index.sqlite")
        status_path = os.path.join(tmp.name, "source_status.json")
        conn = sqlite3.connect(db_path)
        conn.execute(
            """
            CREATE TABLE sources (
              source_id TEXT PRIMARY KEY,
              boundary_json TEXT
            )
            """
        )
        conn.execute(
            """
            CREATE TABLE source_files (
              source_id TEXT NOT NULL,
              path TEXT NOT NULL,
              sha256 TEXT,
              modified_at TEXT,
              parsed TEXT,
              provenance_grain TEXT
            )
            """
        )
        conn.execute(
            """
            CREATE VIRTUAL TABLE atomic_rows_fts USING fts5(
              source_id,
              source_table,
              source_file,
              sheet,
              search_text,
              provenance_grain UNINDEXED
            )
            """
        )
        conn.execute(
            """
            CREATE TABLE atomic_rows (
              row_id TEXT PRIMARY KEY,
              source_id TEXT NOT NULL,
              source_table TEXT NOT NULL,
              source_file TEXT NOT NULL,
              sheet TEXT,
              row_index INTEGER,
              row_key TEXT NOT NULL,
              row_json TEXT NOT NULL,
              search_text TEXT NOT NULL,
              provenance_grain TEXT NOT NULL
            )
            """
        )
        rows = [
            (
                "scorecard_monthly_data",
                "scorecard_monthly_metric_fields",
                "scorecard",
                "",
                "scorecard March gross revenue current KPI",
                provenance("scorecard_monthly_data", "scorecard#record=7&field=gross_revenue"),
            ),
            (
                "netsuite_pnl_monthly",
                "netsuite_pnl_account_fields",
                "netsuite",
                "",
                "NetSuite March P&L account 41005 Gross CPG sales revenue",
                provenance("netsuite_pnl_monthly", "netsuite:/suiteql/pnl#period=2026-03&account=41005"),
            ),
            (
                "asana_work_management",
                "asana_task_fields",
                "asana",
                "",
                "Asana project Select v6 owner status task",
                provenance("asana_work_management", "asana:/project/123"),
            ),
        ]
        for row in rows:
            conn.execute("INSERT INTO sources VALUES (?, ?)", (row[0], json.dumps([row[2]])))
            conn.execute(
                "INSERT INTO source_files VALUES (?, ?, ?, ?, ?, ?)",
                (row[0], row[2], "sha", "2026-05-06T00:00:00Z", "yes", provenance(row[0], row[2])),
            )
            conn.execute("INSERT INTO atomic_rows_fts VALUES (?, ?, ?, ?, ?, ?)", row)
        quality_rows = [
            (
                "batch_release_app",
                "batch_release_product_tests",
                "batch_release_app_state",
                "",
                "Original Just Meat reefer pH 4.2 protein release product tests",
                provenance("batch_release_app", "batch_release:product_tests:JM-001#field=ph"),
            ),
            (
                "qualification_meat_sensory",
                "workbook_rows",
                "Just Meat Qualification.xlsx",
                "qualification",
                "Original Just Meat reefer qualification pH 4.1 backup source",
                provenance("qualification_meat_sensory", "Just Meat Qualification.xlsx#row=8"),
            ),
            (
                "replace_enter_repo_github",
                "replace_enter_api_formula_detail",
                "formulas/337",
                "",
                "Just Meat Original Sauce for Reefer pH 3.8 formula record",
                provenance("replace_enter_repo_github", "https://replace-enter.vercel.app/api/formulas/337#record=1"),
            ),
        ]
        for row in quality_rows:
            conn.execute("INSERT INTO sources VALUES (?, ?)", (row[0], json.dumps([row[2]])))
            conn.execute(
                "INSERT INTO source_files VALUES (?, ?, ?, ?, ?, ?)",
                (row[0], row[2], "sha", "2026-05-06T00:00:00Z", "yes", provenance(row[0], row[2])),
            )
            conn.execute("INSERT INTO atomic_rows_fts VALUES (?, ?, ?, ?, ?, ?)", row)
        batch_release_atomic_rows = [
            (
                "batch_release:sensory_data:records[62].product",
                "batch_release_app",
                "batch_release_sensory_data_fields",
                "batch_release_app_state",
                "",
                62,
                "batch_release:sensory_data:records[62].product",
                {"app_state_key": "batch_release:sensory_data", "field": "records[62].product", "value": "Just Meat - Original, Reefer"},
                "Just Meat Original Reefer product",
                provenance("batch_release_app", "batch_release:sensory_data#field=records[62].product"),
            ),
            (
                "batch_release:sensory_data:records[62].lot",
                "batch_release_app",
                "batch_release_sensory_data_fields",
                "batch_release_app_state",
                "",
                62,
                "batch_release:sensory_data:records[62].lot",
                {"app_state_key": "batch_release:sensory_data", "field": "records[62].lot", "value": "JM-001"},
                "JM-001 lot",
                provenance("batch_release_app", "batch_release:sensory_data#field=records[62].lot"),
            ),
            (
                "batch_release:record:JM-001:productName",
                "batch_release_app",
                "batch_release_record_fields",
                "batch_release_app_state",
                "",
                1,
                "JM-001:productName",
                {"field": "productName", "value": "Just Meat"},
                "Just Meat productName",
                provenance("batch_release_app", "batch_release:batches#record=JM-001&field=productName"),
            ),
            (
                "batch_release:record:JM-001:variant",
                "batch_release_app",
                "batch_release_record_fields",
                "batch_release_app_state",
                "",
                1,
                "JM-001:variant",
                {"field": "variant", "value": "Original Reefer"},
                "Original Reefer variant",
                provenance("batch_release_app", "batch_release:batches#record=JM-001&field=variant"),
            ),
            (
                "batch_release:record:JM-001:productTests:ph",
                "batch_release_app",
                "batch_release_record_fields",
                "batch_release_app_state",
                "",
                1,
                "JM-001:releaseDecision.criteria.productTests.details[1]",
                {"field": "releaseDecision.criteria.productTests.details[1]", "value": "pH: 4.2 - PASS"},
                "pH 4.2 product tests release decision",
                provenance("batch_release_app", "batch_release:batches#record=JM-001&field=releaseDecision.criteria.productTests.details[1]"),
            ),
        ]
        for row in batch_release_atomic_rows:
            conn.execute(
                "INSERT INTO atomic_rows VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                (row[0], row[1], row[2], row[3], row[4], row[5], row[6], json.dumps(row[7]), row[8], row[9]),
            )
        conn.execute("INSERT INTO sources VALUES (?, ?)", ("rd_liquid_egg_v6", json.dumps(["rd"])))
        conn.execute("INSERT INTO sources VALUES (?, ?)", ("rd_formulations_vault_production_formulas", json.dumps(["rd formulations vault"])))
        conn.execute("INSERT INTO sources VALUES (?, ?)", ("tofutown_employee_list_2026", json.dumps(["hr workbook"])))
        conn.execute("INSERT INTO sources VALUES (?, ?)", ("tofutown_bom_tt_skus", json.dumps(["tofutown bom workbook"])))
        conn.execute("INSERT INTO sources VALUES (?, ?)", ("hr_just_food_company_headcount", json.dumps(["hr workbook"])))
        conn.execute("INSERT INTO sources VALUES (?, ?)", ("dot_foodservice_weekly_sales", json.dumps(["dot foodservice workbook"])))
        dot_row_json = json.dumps(
            {
                "row_type": "weekly_foodservice_sales",
                "source_customer": "DOT",
                "channel": "Foodservice",
                "fields": {
                    "week_ending": "Week Ending 5/9",
                    "week_num": 19,
                    "year": 2026,
                    "liquid_cases": 910,
                    "liquid_sales": 105223,
                    "folded_cases": 704,
                    "folded_sales": 62615.9,
                    "mayo_cases": 125,
                    "mayo_sales": 10685.05,
                    "meat_cases": 3,
                    "meat_sales": 135,
                    "fob_sales": 178659,
                },
            }
        )
        conn.execute(
            "INSERT INTO atomic_rows VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
            (
                "dot_foodservice_weekly_sales:row:167",
                "dot_foodservice_weekly_sales",
                "dot_foodservice_weekly_sales",
                "Shipment Tracker - Foodservice. (35).xlsx",
                "Dot Week to Week",
                167,
                "Shipment Tracker - Foodservice. (35).xlsx:Dot Week to Week:weekly:167",
                dot_row_json,
                "DOT foodservice weekly sales Week Ending 5/9 2026 FOB sales Liquid Folded Mayo Meat cases",
                provenance("dot_foodservice_weekly_sales", "source-material/dot_foodservice_weekly_sales/Shipment Tracker - Foodservice. (35).xlsx#sheet=Dot%20Week%20to%20Week&row=167"),
            ),
        )
        conn.execute(
            "INSERT INTO source_files VALUES (?, ?, ?, ?, ?, ?)",
            (
                "dot_foodservice_weekly_sales",
                "Shipment Tracker - Foodservice. (35).xlsx",
                "sha",
                "2026-05-10T00:00:00Z",
                "yes",
                provenance("dot_foodservice_weekly_sales", "Shipment Tracker - Foodservice. (35).xlsx"),
            ),
        )
        conn.execute(
            "INSERT INTO source_files VALUES (?, ?, ?, ?, ?, ?)",
            (
                "rd_formulations_vault_production_formulas",
                "Liquid/JE Liquid_Formulation - JSPL026LR (increased cyto).xlsx",
                "sha",
                "2025-08-11T00:00:00Z",
                "yes",
                provenance(
                    "rd_formulations_vault_production_formulas",
                    "Liquid/JE Liquid_Formulation - JSPL026LR (increased cyto).xlsx",
                ),
            ),
        )
        conn.execute(
            "INSERT INTO source_files VALUES (?, ?, ?, ?, ?, ?)",
            (
                "rd_formulations_vault_production_formulas",
                "Liquid/JE Liquid_Formulation - JSPL027LR (decreased cyto).xlsx",
                "sha",
                "2026-03-31T20:55:40Z",
                "yes",
                provenance(
                    "rd_formulations_vault_production_formulas",
                    "Liquid/JE Liquid_Formulation - JSPL027LR (decreased cyto).xlsx",
                ),
            ),
        )
        conn.execute(
            "INSERT INTO source_files VALUES (?, ?, ?, ?, ?, ?)",
            (
                "rd_liquid_egg_v6",
                "v6 2026.xlsx",
                "sha",
                "2026-05-03T06:18:18Z",
                "yes",
                provenance("rd_liquid_egg_v6", "v6 2026.xlsx"),
            ),
        )
        conn.execute(
            "INSERT INTO source_files VALUES (?, ?, ?, ?, ?, ?)",
            (
                "tofutown_employee_list_2026",
                "Full employee list_2026.xlsx",
                "sha",
                "2026-05-05T14:50:56Z",
                "yes",
                provenance("tofutown_employee_list_2026", "Full employee list_2026.xlsx"),
            ),
        )
        conn.execute(
            "INSERT INTO source_files VALUES (?, ?, ?, ?, ?, ?)",
            (
                "tofutown_bom_tt_skus",
                "BOM_TT_SKUs.xlsx",
                "sha",
                "2026-05-05T14:50:56Z",
                "yes",
                provenance("tofutown_bom_tt_skus", "BOM_TT_SKUs.xlsx"),
            ),
        )
        conn.execute(
            "INSERT INTO source_files VALUES (?, ?, ?, ?, ?, ?)",
            (
                "hr_just_food_company_headcount",
                "JUST Food Company Headcount.xlsx",
                "sha",
                "2026-05-05T14:50:56Z",
                "yes",
                provenance("hr_just_food_company_headcount", "JUST Food Company Headcount.xlsx"),
            ),
        )
        conn.execute(
            "INSERT INTO atomic_rows VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
            (
                "scorecard:mar:gross_revenue",
                "scorecard_monthly_data",
                "scorecard_monthly_metric_fields",
                "scorecard",
                None,
                7,
                "Mar '26:gross_revenue",
                json.dumps({"month": "Mar '26", "metric": "gross_revenue", "value": 4.66}),
                "scorecard March gross revenue current KPI",
                provenance("scorecard_monthly_data", "scorecard#record=7&field=gross_revenue"),
            ),
        )
        conn.execute(
            "INSERT INTO atomic_rows VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
            (
                "netsuite:2026-03:41005:amount",
                "netsuite_pnl_monthly",
                "netsuite_pnl_account_fields",
                "netsuite",
                None,
                3,
                "2026-03:41005:amount",
                json.dumps({"period": "2026-03", "account": "41005", "amount": -4217758.41}),
                "NetSuite March P&L account 41005 Gross CPG sales revenue",
                provenance("netsuite_pnl_monthly", "netsuite:/suiteql/pnl#period=2026-03&account=41005&field=amount"),
            ),
        )
        conn.execute(
            "INSERT INTO atomic_rows VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
            (
                "rd-v6:v6-trial:row1",
                "rd_liquid_egg_v6",
                "workbook_rows",
                "v6 2026.xlsx",
                "v6 trial ",
                1,
                "v6 trial :1",
                json.dumps(
                    {
                        "cells": [
                            {"address": "D1", "column_letter": "D", "value": "2026-03-20"},
                            {"address": "E1", "column_letter": "E", "value": "2026-03-20"},
                        ]
                    }
                ),
                "2026-03-20 V6 trial workbook header",
                provenance("rd_liquid_egg_v6", "v6 2026.xlsx#sheet=v6%20trial%20&row=1"),
            ),
        )
        conn.execute(
            "INSERT INTO atomic_rows VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
            (
                "rd-v6:v6-trial:row3",
                "rd_liquid_egg_v6",
                "workbook_rows",
                "v6 2026.xlsx",
                "v6 trial ",
                3,
                "v6 trial :3",
                json.dumps(
                    {
                        "cells": [
                            {"address": "D3", "column_letter": "D", "value": "v6-47 DM"},
                            {"address": "E3", "column_letter": "E", "value": "v6-47 WM"},
                        ]
                    }
                ),
                "v6-47 DM v6-47 WM",
                provenance("rd_liquid_egg_v6", "v6 2026.xlsx#sheet=v6%20trial%20&row=3"),
            ),
        )
        conn.execute(
            "INSERT INTO atomic_rows VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
            (
                "rd-v6:tgpg:row1",
                "rd_liquid_egg_v6",
                "workbook_rows",
                "v6 2026.xlsx",
                "tgpg",
                1,
                "tgpg:1",
                json.dumps({"cells": [{"address": "D1", "column_letter": "D", "value": "2026-04-01"}]}),
                "2026-04-01 non-V6 worksheet header",
                provenance("rd_liquid_egg_v6", "v6 2026.xlsx#sheet=tgpg&row=1"),
            ),
        )
        conn.execute(
            "INSERT INTO atomic_rows VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
            (
                "rd-v6:tgpg:row3",
                "rd_liquid_egg_v6",
                "workbook_rows",
                "v6 2026.xlsx",
                "tgpg",
                3,
                "tgpg:3",
                json.dumps({"cells": [{"address": "D3", "column_letter": "D", "value": "not the V6 formula"}]}),
                "not the V6 formula",
                provenance("rd_liquid_egg_v6", "v6 2026.xlsx#sheet=tgpg&row=3"),
            ),
        )
        formulation_rows = [
            (
                "formulations-vault:jspl026lr:row13",
                "rd_formulations_vault_production_formulas",
                "workbook_rows",
                "Liquid/JE Liquid_Formulation - JSPL026LR (increased cyto).xlsx",
                "JSPL026LR",
                13,
                "JSPL026LR:13",
                {
                    "cells": [
                        {"address": "A13", "column_letter": "A", "value": "CytoGuard YM"},
                        {"address": "D13", "column_letter": "D", "value": "1.9900%"},
                    ]
                },
                "Just Egg Liquid Retail JSPL026LR production formula CytoGuard YM increased cyto",
                provenance(
                    "rd_formulations_vault_production_formulas",
                    "Liquid/JE Liquid_Formulation - JSPL026LR (increased cyto).xlsx#sheet=JSPL026LR&row=13",
                ),
            ),
            (
                "formulations-vault:jspl027lr:row13",
                "rd_formulations_vault_production_formulas",
                "workbook_rows",
                "Liquid/JE Liquid_Formulation - JSPL027LR (decreased cyto).xlsx",
                "JSPL027LR",
                13,
                "JSPL027LR:13",
                {
                    "cells": [
                        {"address": "A13", "column_letter": "A", "value": "CytoGuard YM"},
                        {"address": "D13", "column_letter": "D", "value": "0.0010"},
                    ]
                },
                "Just Egg Liquid Retail JSPL027LR production formula CytoGuard YM decreased cyto",
                provenance(
                    "rd_formulations_vault_production_formulas",
                    "Liquid/JE Liquid_Formulation - JSPL027LR (decreased cyto).xlsx#sheet=JSPL027LR&row=13",
                ),
            ),
            (
                "replace-enter:just-egg-cytoguard",
                "replace_enter_repo_github",
                "replace_enter_api_formula_detail",
                "formulas/337",
                "",
                1,
                "replace-enter:formula:337:ingredient",
                {"formula": "Just Egg Liquid Retail", "ingredient": "CytoGuard YM", "value": "catalog metadata"},
                "Just Egg Liquid Retail Replace Enter formula record CytoGuard YM catalog metadata",
                provenance("replace_enter_repo_github", "https://replace-enter.vercel.app/api/formulas/337#record=1"),
            ),
        ]
        for row in formulation_rows:
            conn.execute(
                "INSERT INTO atomic_rows VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                (row[0], row[1], row[2], row[3], row[4], row[5], row[6], json.dumps(row[7]), row[8], row[9]),
            )
        conn.execute(
            "INSERT INTO atomic_rows VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
            (
                "tofutown_employee_list_2026:full:row1",
                "tofutown_employee_list_2026",
                "workbook_rows",
                "Full employee list_2026.xlsx",
                "full employee list",
                2,
                "full employee list:2",
                json.dumps({"surname": "Surname", "first_name": "First name", "department": "Department"}),
                "Number Surname First name Department header row",
                provenance("tofutown_employee_list_2026", "Full employee list_2026.xlsx#sheet=full%20employee%20list&row=2"),
            ),
        )
        conn.execute(
            "INSERT INTO atomic_rows VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
            (
                "tofutown_employee_list_2026:full:row2",
                "tofutown_employee_list_2026",
                "workbook_rows",
                "Full employee list_2026.xlsx",
                "full employee list",
                3,
                "full employee list:3",
                json.dumps({"surname": "Westphal", "first_name": "Erik", "department": "Plant manager"}),
                "Erik Westphal Plant manager Lüneburg tofutown employee employees roster",
                provenance("tofutown_employee_list_2026", "Full employee list_2026.xlsx#sheet=full%20employee%20list&row=3"),
            ),
        )
        conn.execute(
            "INSERT INTO atomic_rows VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
            (
                "tofutown_employee_list_2026:full:row3",
                "tofutown_employee_list_2026",
                "workbook_rows",
                "Full employee list_2026.xlsx",
                "full employee list",
                4,
                "full employee list:4",
                json.dumps({"surname": "Polzin", "first_name": "Manja", "department": "Head of QA"}),
                "Manja Polzin Head of QA quality assurance tofutown employee employees roster",
                provenance("tofutown_employee_list_2026", "Full employee list_2026.xlsx#sheet=full%20employee%20list&row=4"),
            ),
        )
        conn.execute(
            "INSERT INTO atomic_rows VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
            (
                "tofutown_employee_list_2026:monthly:row4",
                "tofutown_employee_list_2026",
                "workbook_rows",
                "Full employee list_2026.xlsx",
                "Monthly Overview",
                4,
                "Monthly Overview:4",
                json.dumps(
                    {
                        "sheet": "Monthly Overview",
                        "cells": [
                            {"address": "A4", "column_letter": "A", "value": "March"},
                            {"address": "B4", "column_letter": "B", "value": 14},
                            {"address": "C4", "column_letter": "C", "value": 95.11764705882354},
                            {"address": "D4", "column_letter": "D", "value": 4.357142857142857},
                            {"address": "E4", "column_letter": "E", "value": 0.0458079335630356},
                        ]
                    }
                ),
                "March Sick Rate Avg % 0.0458079335630356 Monthly Overview TofuTown Europe sick rate",
                provenance("tofutown_employee_list_2026", "Full employee list_2026.xlsx#sheet=Monthly%20Overview&row=4"),
            ),
        )
        conn.execute(
            "INSERT INTO atomic_rows VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
            (
                "tofutown_bom_tt_skus:row1",
                "tofutown_bom_tt_skus",
                "workbook_rows",
                "BOM_TT_SKUs.xlsx",
                "BOM",
                1,
                "BOM:1",
                json.dumps({"sku": "237000", "ingredient": "water"}),
                "TofuTown BOM SKU ingredient Just Egg Europe",
                provenance("tofutown_bom_tt_skus", "BOM_TT_SKUs.xlsx#sheet=BOM&row=1"),
            ),
        )
        row_json = json.dumps(
            {
                "cells": [
                    {"address": "A1", "column_letter": "A", "value": "Payroll Company Name"},
                    {"address": "B1", "column_letter": "B", "value": "Legal First Name"},
                    {"address": "C1", "column_letter": "C", "value": "Legal Last Name"},
                    {"address": "D1", "column_letter": "D", "value": "Work Contact: Work Email"},
                    {"address": "E1", "column_letter": "E", "value": "Job Title Description"},
                    {"address": "F1", "column_letter": "F", "value": "Department Description"},
                    {"address": "G1", "column_letter": "G", "value": "EE Status"},
                ]
            }
        )
        conn.execute(
            "INSERT INTO atomic_rows VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
            (
                "just-headcount:header",
                "hr_just_food_company_headcount",
                "workbook_rows",
                "JUST Food Company Headcount.xlsx",
                "Sheet1",
                1,
                "Sheet1:1",
                row_json,
                "Payroll Company Name Legal First Name Legal Last Name Work Contact Work Email Job Title Description Department Description EE Status",
                provenance("hr_just_food_company_headcount", "JUST Food Company Headcount.xlsx#sheet=Sheet1&row=1"),
            ),
        )
        for row_id, row_index, first, last, title, department, status in [
            ("just-headcount:row2", 2, "Jane", "Doe", "Food Scientist", "R&D", "Active"),
            ("just-headcount:row3", 3, "Alex", "Kim", "Finance Analyst", "Finance", "Active"),
        ]:
            row_json = json.dumps(
                {
                    "cells": [
                        {"address": f"B{row_index}", "column_letter": "B", "value": first},
                        {"address": f"C{row_index}", "column_letter": "C", "value": last},
                        {"address": f"E{row_index}", "column_letter": "E", "value": title},
                        {"address": f"F{row_index}", "column_letter": "F", "value": department},
                        {"address": f"G{row_index}", "column_letter": "G", "value": status},
                    ]
                }
            )
            search_text = f"{first} {last} {title} {department} {status} Just employee roster"
            conn.execute(
                "INSERT INTO atomic_rows VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                (
                    row_id,
                    "hr_just_food_company_headcount",
                    "workbook_rows",
                    "JUST Food Company Headcount.xlsx",
                    "Sheet1",
                    row_index,
                    f"Sheet1:{row_index}",
                    row_json,
                    search_text,
                    provenance("hr_just_food_company_headcount", f"JUST Food Company Headcount.xlsx#sheet=Sheet1&row={row_index}"),
                ),
            )
        for row_id, source_id, source_table, source_file, row_key, row_json, search_text in [
            (
                "netsuite-ar:row1",
                "netsuite_ar_open_invoices",
                "netsuite_ar_invoice_fields",
                "netsuite_ar",
                "invoice:1",
                json.dumps({"customer": "ACME Retail", "invoice": "INV-100", "status": "Open"}),
                "netsuite ar open invoice invoices customer balance",
            ),
            (
                "batch-release:row1",
                "batch_release_app",
                "batch_release_batch_fields",
                "batch_release",
                "batch:ON03326",
                json.dumps({"batch": "ON03326", "status": "held", "micro": "pending"}),
                "batch ON03326 status held micro sensory release",
            ),
            (
                "operations-inbound:row1",
                "operations_inbound_log",
                "workbook_rows",
                "inbound_log.xlsx",
                "inbound:1",
                json.dumps({"po": "123", "site": "Vernon", "status": "received"}),
                "inbound shipment shipments PO 123 Vernon received date",
            ),
        ]:
            conn.execute("INSERT OR IGNORE INTO sources VALUES (?, ?)", (source_id, json.dumps([source_file])))
            conn.execute(
                "INSERT INTO source_files VALUES (?, ?, ?, ?, ?, ?)",
                (source_id, source_file, "sha", "2026-05-06T00:00:00Z", "yes", provenance(source_id, source_file)),
            )
            conn.execute(
                "INSERT INTO atomic_rows VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                (
                    row_id,
                    source_id,
                    source_table,
                    source_file,
                    "",
                    1,
                    row_key,
                    row_json,
                    search_text,
                    provenance(source_id, f"{source_file}#{row_key}"),
                ),
            )
        conn.execute(
            "INSERT INTO atomic_rows_fts VALUES (?, ?, ?, ?, ?, ?)",
            (
                "tofutown_employee_list_2026",
                "workbook_rows",
                "Full employee list_2026.xlsx",
                "full employee list",
                "Erik Westphal Plant manager Lüneburg tofutown employee employees roster",
                provenance("tofutown_employee_list_2026", "Full employee list_2026.xlsx#sheet=full%20employee%20list&row=2"),
            ),
        )
        conn.execute(
            "INSERT INTO atomic_rows_fts VALUES (?, ?, ?, ?, ?, ?)",
            (
                "tofutown_employee_list_2026",
                "workbook_rows",
                "Full employee list_2026.xlsx",
                "full employee list",
                "Manja Polzin Head of QA quality assurance tofutown employee employees roster",
                provenance("tofutown_employee_list_2026", "Full employee list_2026.xlsx#sheet=full%20employee%20list&row=3"),
            ),
        )
        conn.commit()
        conn.close()
        return tmp, serve_http.AskJustService(db_path, status_path)

    def test_source_all_uses_per_source_plan_for_cross_source_reconciliation(self):
        tmp, service = self.make_service()
        self.addCleanup(tmp.cleanup)

        payload = service.search(
            "Reconcile March revenue between Scorecard and NetSuite P&L",
            source="all",
            kind="atomic",
            limit=10,
        )

        self.assertTrue(payload["ok"])
        self.assertEqual(payload["source"], "all")
        self.assertEqual(payload["query_path"], "planned_source_search")
        self.assertIn("source_query_plan", payload)
        returned_sources = {row["source_id"] for row in payload["rows"]}
        self.assertIn("scorecard_monthly_data", returned_sources)
        self.assertIn("netsuite_pnl_monthly", returned_sources)
        structured_steps = [step for step in payload["source_query_plan"] if step.get("query_shape") == "structured_sql_filter"]
        self.assertGreaterEqual(len(structured_steps), 2)
        self.assertEqual(payload["routing_decision"]["route_shape"], "mixed")
        self.assertEqual(payload["routing_decision"]["adapter"], "planned_source_search")
        self.assertEqual(
            payload["routing_decision"]["selected_source_lane"],
            ["scorecard_monthly_data", "netsuite_pnl_monthly"],
        )
        self.assertEqual(len(payload["routing_decision"]["route_plan"]), len(payload["source_query_plan"]))
        self.assertCanonicalRoutePlanSteps(payload["routing_decision"]["route_plan"])
        route_adapters = {step["source_id"]: step["adapter"] for step in payload["routing_decision"]["route_plan"]}
        self.assertEqual(route_adapters["scorecard_monthly_data"], "scorecard_monthly_kpi")
        self.assertEqual(route_adapters["netsuite_pnl_monthly"], "netsuite_pnl_metric")

    def test_source_auto_uses_same_planner_instead_of_filtering_to_auto_source_id(self):
        tmp, service = self.make_service()
        self.addCleanup(tmp.cleanup)

        payload = service.search(
            "Reconcile March revenue between Scorecard and NetSuite P&L",
            source="auto",
            kind="atomic",
            limit=10,
        )

        self.assertTrue(payload["ok"])
        self.assertEqual(payload["source"], "auto")
        self.assertEqual(payload["query_path"], "planned_source_search")
        returned_sources = {row["source_id"] for row in payload["rows"]}
        self.assertIn("scorecard_monthly_data", returned_sources)
        self.assertIn("netsuite_pnl_monthly", returned_sources)
        self.assertCanonicalRoutePlanSteps(payload["routing_decision"]["route_plan"])

    def test_source_auto_returns_newest_rd_liquid_egg_v6_formula_block(self):
        tmp, service = self.make_service()
        self.addCleanup(tmp.cleanup)

        payload = service.search(
            "What is the newest V6 formula?",
            source="auto",
            kind="atomic",
            limit=10,
        )

        self.assertTrue(payload["ok"])
        self.assertEqual(payload["source"], "auto")
        self.assertEqual(payload["query_path"], "planned_source_search")
        structured_steps = [step for step in payload["source_query_plan"] if step.get("query_shape") == "structured_sql_filter"]
        self.assertTrue(any(step["source_id"] == "rd_liquid_egg_v6" for step in structured_steps))
        self.assertTrue(
            any(
                row["source_id"] == "rd_liquid_egg_v6" and "v6-47 DM" in row["snippet"]
                for row in payload["rows"]
            )
        )
        self.assertCanonicalRoutePlanSteps(payload["routing_decision"]["route_plan"])

    def test_plain_v6_formula_routes_to_named_formula_adapter(self):
        tmp, service = self.make_service()
        self.addCleanup(tmp.cleanup)

        payload = service.search(
            "what is the v6 formula for just egg",
            source="all",
            kind="atomic",
            limit=10,
        )

        self.assertTrue(payload["ok"])
        self.assertEqual(payload["query_path"], "planned_source_search")
        self.assertEqual(payload["routing_decision"]["route_shape"], "structured")
        self.assertEqual(payload["routing_decision"]["selected_source_lane"], ["rd_liquid_egg_v6"])
        self.assertEqual(payload["routing_decision"]["route_plan"][0]["adapter"], "rd_liquid_egg_v6_formula")
        self.assertIn("source_specific_fts", payload["routing_decision"]["not_used"])
        self.assertTrue(any("v6-47 DM" in row["snippet"] for row in payload["rows"]))

    def test_in_market_production_formula_routes_to_formulations_vault(self):
        tmp, service = self.make_service()
        self.addCleanup(tmp.cleanup)

        payload = service.search(
            "What is the latest production formulation of Just Egg including Cytoguard?",
            source="all",
            kind="atomic",
            limit=10,
        )

        self.assertTrue(payload["ok"])
        self.assertEqual(payload["query_path"], "planned_source_search")
        self.assertEqual(payload["routing_decision"]["route_shape"], "structured")
        self.assertEqual(
            payload["routing_decision"]["selected_source_lane"],
            ["rd_formulations_vault_production_formulas"],
        )
        self.assertEqual(
            payload["routing_decision"]["route_plan"][0]["adapter"],
            "rd_formulations_vault_production_formula",
        )
        self.assertEqual(payload["source_query_plan"][0]["query"], "cytoguard")
        self.assertEqual(
            payload["routing_decision"]["route_plan"][0]["fallback_policy"],
            "fail_closed_no_prose_fallback",
        )
        self.assertNotIn("replace_enter_repo_github", payload["routing_decision"]["selected_source_lane"])
        self.assertTrue(payload["rows"])
        self.assertTrue(all(row["source_id"] == "rd_formulations_vault_production_formulas" for row in payload["rows"]))
        serialized_rows = json.dumps(payload["rows"], ensure_ascii=False)
        self.assertIn("JSPL027LR", serialized_rows)
        self.assertIn("CytoGuard", serialized_rows)

    def test_list_just_employees_routes_to_named_people_roster_adapter(self):
        tmp, service = self.make_service()
        self.addCleanup(tmp.cleanup)

        payload = service.search(
            "list just employees",
            source="all",
            kind="atomic",
            limit=10,
        )

        self.assertTrue(payload["ok"])
        self.assertEqual(payload["query_path"], "planned_source_search")
        self.assertEqual(payload["routing_decision"]["route_shape"], "structured")
        self.assertEqual(payload["routing_decision"]["selected_source_lane"], ["hr_just_food_company_headcount"])
        self.assertEqual(payload["routing_decision"]["route_plan"][0]["adapter"], "just_people_roster")
        serialized_rows = json.dumps(payload["rows"], ensure_ascii=False)
        self.assertIn("Jane", serialized_rows)
        self.assertIn("Alex", serialized_rows)

    def test_source_scoped_just_employee_question_uses_named_people_roster_adapter(self):
        tmp, service = self.make_service()
        self.addCleanup(tmp.cleanup)

        payload = service.search(
            "List all Just Food Company employees with name, job title, department, employee status, and work email if present",
            source="hr_just_food_company_headcount",
            kind="atomic",
            limit=10,
        )

        self.assertTrue(payload["ok"])
        self.assertEqual(payload["query_path"], "planned_source_search")
        self.assertEqual(payload["routing_decision"]["route_shape"], "structured")
        self.assertEqual(payload["routing_decision"]["selected_source_lane"], ["hr_just_food_company_headcount"])
        self.assertEqual(payload["routing_decision"]["route_plan"][0]["adapter"], "just_people_roster")
        self.assertIn("broad_text_search", payload["routing_decision"]["not_used"])
        serialized_rows = json.dumps(payload["rows"], ensure_ascii=False)
        self.assertIn("Jane", serialized_rows)
        self.assertIn("Alex", serialized_rows)
        self.assertNotIn("Payroll Company Name", serialized_rows)

    def test_tofutown_employee_question_routes_to_hr_workbook(self):
        tmp, service = self.make_service()
        self.addCleanup(tmp.cleanup)

        payload = service.search(
            "list the employees at tofutown",
            source="all",
            kind="atomic",
            limit=10,
        )

        self.assertTrue(payload["ok"])
        self.assertEqual(payload["query_path"], "planned_source_search")
        self.assertEqual(payload["routing_decision"]["route_shape"], "structured")
        self.assertEqual(payload["routing_decision"]["selected_source_lane"], ["tofutown_employee_list_2026"])
        self.assertEqual(payload["routing_decision"]["route_plan"][0]["adapter"], "tofutown_people_roster")
        self.assertEqual(
            [step["source_id"] for step in payload["source_query_plan"]],
            ["tofutown_employee_list_2026"],
        )
        self.assertTrue(payload["rows"])
        self.assertTrue(all(row["source_id"] == "tofutown_employee_list_2026" for row in payload["rows"]))
        self.assertCanonicalRoutePlanSteps(payload["routing_decision"]["route_plan"])

    def test_who_works_at_tofutown_routes_to_structured_roster(self):
        tmp, service = self.make_service()
        self.addCleanup(tmp.cleanup)

        payload = service.search(
            "who works at tofutown",
            source="all",
            kind="atomic",
            limit=2,
        )

        self.assertTrue(payload["ok"])
        self.assertEqual(payload["query_path"], "planned_source_search")
        self.assertEqual(payload["routing_decision"]["route_shape"], "structured")
        self.assertEqual(payload["routing_decision"]["selected_source_lane"], ["tofutown_employee_list_2026"])
        self.assertEqual(
            [step["source_id"] for step in payload["source_query_plan"]],
            ["tofutown_employee_list_2026"],
        )
        self.assertEqual(len(payload["rows"]), 2)
        serialized_rows = json.dumps(payload["rows"], ensure_ascii=False)
        self.assertIn("Erik", serialized_rows)
        self.assertIn("Manja", serialized_rows)
        self.assertNotIn("Number Surname First name", serialized_rows)
        self.assertTrue(all(row["source_id"] == "tofutown_employee_list_2026" for row in payload["rows"]))
        self.assertCanonicalRoutePlanSteps(payload["routing_decision"]["route_plan"])

    def test_active_production_tofutown_employees_uses_roster_synonyms(self):
        tmp, service = self.make_service()
        self.addCleanup(tmp.cleanup)

        payload = service.search(
            "Who are the first 10 active Production employees at TofuTown?",
            source="all",
            kind="atomic",
            limit=10,
        )

        self.assertTrue(payload["ok"])
        self.assertEqual(payload["routing_decision"]["route_plan"][0]["adapter"], "tofutown_people_roster")
        serialized_rows = json.dumps(payload["rows"], ensure_ascii=False)
        self.assertIn("Erik", serialized_rows)
        self.assertNotIn("Manja", serialized_rows)

    def test_tofutown_sick_rate_routes_to_employee_monthly_overview(self):
        tmp, service = self.make_service()
        self.addCleanup(tmp.cleanup)

        payload = service.search(
            "What is TofuTown Europe sick rate for March 2026?",
            source="all",
            kind="atomic",
            limit=10,
        )

        self.assertTrue(payload["ok"])
        self.assertEqual(payload["query_path"], "planned_source_search")
        self.assertEqual(payload["routing_decision"]["route_plan"][0]["adapter"], "tofutown_sick_rate")
        self.assertEqual(payload["routing_decision"]["selected_source_lane"], ["tofutown_employee_list_2026"])
        self.assertEqual([step["source_id"] for step in payload["source_query_plan"]], ["tofutown_employee_list_2026"])
        self.assertEqual(len(payload["rows"]), 1)
        self.assertTrue(all(row["source_id"] == "tofutown_employee_list_2026" for row in payload["rows"]))
        serialized_rows = json.dumps(payload["rows"], ensure_ascii=False)
        self.assertIn("Monthly Overview", serialized_rows)
        self.assertIn("0.0458079335630356", serialized_rows)
        self.assertNotIn("BOM_TT_SKUs", serialized_rows)

    def test_product_ph_question_routes_to_batch_release_then_qualification_not_entr(self):
        tmp, service = self.make_service()
        self.addCleanup(tmp.cleanup)

        payload = service.search(
            "what is the pH of original Just Meat reefer?",
            source="all",
            kind="atomic",
            limit=10,
        )

        self.assertTrue(payload["ok"])
        self.assertEqual(payload["query_path"], "planned_source_search")
        planned_sources = [step["source_id"] for step in payload["source_query_plan"]]
        self.assertEqual(planned_sources[:2], ["batch_release_app", "qualification_meat_sensory"])
        self.assertNotIn("replace_enter_repo_github", planned_sources)
        returned_sources = {row["source_id"] for row in payload["rows"]}
        self.assertIn("batch_release_app", returned_sources)
        self.assertIn("qualification_meat_sensory", returned_sources)
        self.assertNotIn("replace_enter_repo_github", returned_sources)
        self.assertIn("pH: 4.2", json.dumps(payload["rows"]))
        self.assertEqual(
            payload["routing_decision"]["selected_source_lane"][:2],
            ["batch_release_app", "qualification_meat_sensory"],
        )
        self.assertIn("broad_text_search", payload["routing_decision"]["not_used"])
        self.assertCanonicalRoutePlanSteps(payload["routing_decision"]["route_plan"])

    def test_sparse_ph_question_routes_to_batch_release_first(self):
        tmp, service = self.make_service()
        self.addCleanup(tmp.cleanup)

        payload = service.search(
            "what is the pH?",
            source="all",
            kind="atomic",
            limit=10,
        )

        self.assertTrue(payload["ok"])
        self.assertEqual(payload.get("query_path"), "planned_source_search", payload)
        planned_sources = [step["source_id"] for step in payload["source_query_plan"]]
        self.assertEqual(planned_sources[0], "batch_release_app")
        self.assertIn("qualification_meat_sensory", planned_sources)
        self.assertNotIn("replace_enter_repo_github", planned_sources)
        self.assertEqual(payload["routing_decision"]["selected_source_lane"][0], "batch_release_app")
        self.assertCanonicalRoutePlanSteps(payload["routing_decision"]["route_plan"])

    def test_all_product_avg_ph_routes_to_batch_release_aggregate(self):
        tmp, service = self.make_service()
        self.addCleanup(tmp.cleanup)
        self.insert_batch_release_ph_fixture(service, "EG-001", "batch-eg-001", "Just Egg", "2026-05-05", 6.1, "Original")
        self.insert_batch_release_ph_fixture(service, "EG-002", "batch-eg-002", "Just Egg", "2026-05-06", 6.3, "Original")
        self.insert_batch_release_ph_fixture(service, "MT-001", "batch-mt-001", "Just Meat", "2026-05-05", 4.2, "Buffalo")
        self.insert_batch_release_ph_fixture(service, "MT-002", "batch-mt-002", "Just Meat", "2026-04-29", 4.4, "Original")

        payload = service.search(
            "what is the average pH for every product in 2026?",
            source="all",
            kind="atomic",
            limit=10,
        )

        self.assertTrue(payload["ok"])
        self.assertEqual(payload.get("query_path"), "planned_source_search", payload)
        self.assertEqual(payload["routing_decision"]["route_plan"][0]["source_id"], "batch_release_app")
        self.assertEqual(payload["routing_decision"]["route_plan"][0]["adapter"], "batch_release_product_ph")
        rows = [json.loads(row["snippet"]) for row in payload["rows"] if row["title"] == "batch_release_ph_aggregate"]
        grouped = {(row["product_name"], row["flavor_variant"]): row for row in rows}
        self.assertEqual(grouped[("Just Egg", "Original")]["measurement_count"], 2)
        self.assertEqual(grouped[("Just Egg", "Original")]["average_ph"], 6.2)
        self.assertEqual(grouped[("Just Meat", "Buffalo")]["average_ph"], 4.2)
        self.assertEqual(grouped[("Just Meat", "Original")]["average_ph"], 4.4)
        self.assertEqual(grouped[("Just Egg", "Original")]["period"], {"label": "2026", "start": "2026-01-01", "end": "2026-12-31"})
        self.assertTrue(all(row["source_id"] == "batch_release_app" for row in payload["rows"]))
        self.assertNotIn("replace_enter_repo_github", {row["source_id"] for row in payload["rows"]})

    def test_this_week_avg_ph_uses_current_week_window(self):
        tmp, service = self.make_service()
        self.addCleanup(tmp.cleanup)
        self.insert_batch_release_ph_fixture(service, "EG-001", "batch-eg-001", "Just Egg", "2026-05-05", 6.1, "Original")
        self.insert_batch_release_ph_fixture(service, "EG-002", "batch-eg-002", "Just Egg", "2026-05-06", 6.3, "Original")
        self.insert_batch_release_ph_fixture(service, "MT-001", "batch-mt-001", "Just Meat", "2026-05-05", 4.2, "Buffalo")
        self.insert_batch_release_ph_fixture(service, "MT-002", "batch-mt-002", "Just Meat", "2026-04-29", 4.4, "Original")
        previous_today = os.environ.get("ASK_JUST_TODAY")
        os.environ["ASK_JUST_TODAY"] = "2026-05-10"
        self.addCleanup(lambda: os.environ.pop("ASK_JUST_TODAY", None) if previous_today is None else os.environ.__setitem__("ASK_JUST_TODAY", previous_today))

        payload = service.search(
            "what is the average pH for every product this week?",
            source="all",
            kind="atomic",
            limit=10,
        )

        self.assertTrue(payload["ok"])
        rows = [json.loads(row["snippet"]) for row in payload["rows"] if row["title"] == "batch_release_ph_aggregate"]
        grouped = {(row["product_name"], row["flavor_variant"]): row for row in rows}
        self.assertEqual(grouped[("Just Egg", "Original")]["average_ph"], 6.2)
        self.assertEqual(grouped[("Just Meat", "Buffalo")]["average_ph"], 4.2)
        self.assertNotIn(("Just Meat", "Original"), grouped)
        self.assertEqual(grouped[("Just Egg", "Original")]["period"], {"label": "this week", "start": "2026-05-04", "end": "2026-05-10"})

    def test_last_week_avg_ph_uses_previous_week_window(self):
        tmp, service = self.make_service()
        self.addCleanup(tmp.cleanup)
        self.insert_batch_release_ph_fixture(service, "EG-001", "batch-eg-001", "Just Egg", "2026-05-05", 6.1, "Original")
        self.insert_batch_release_ph_fixture(service, "MT-002", "batch-mt-002", "Just Meat", "2026-04-29", 4.4, "Original")
        previous_today = os.environ.get("ASK_JUST_TODAY")
        os.environ["ASK_JUST_TODAY"] = "2026-05-10"
        self.addCleanup(lambda: os.environ.pop("ASK_JUST_TODAY", None) if previous_today is None else os.environ.__setitem__("ASK_JUST_TODAY", previous_today))

        payload = service.search(
            "what was the average pH for every product last week?",
            source="all",
            kind="atomic",
            limit=10,
        )

        self.assertTrue(payload["ok"])
        rows = [json.loads(row["snippet"]) for row in payload["rows"] if row["title"] == "batch_release_ph_aggregate"]
        grouped = {(row["product_name"], row["flavor_variant"]): row for row in rows}
        self.assertEqual(grouped[("Just Meat", "Original")]["average_ph"], 4.4)
        self.assertNotIn(("Just Egg", "Original"), grouped)
        self.assertEqual(grouped[("Just Meat", "Original")]["period"], {"label": "last week", "start": "2026-04-27", "end": "2026-05-03"})

    def test_meat_avg_ph_includes_sauce_ph_measurements(self):
        tmp, service = self.make_service()
        self.addCleanup(tmp.cleanup)
        self.insert_batch_release_ph_fixture(service, "EG-001", "batch-eg-001", "Just Egg", "2026-05-05", 6.1, "Original")
        self.insert_batch_release_ph_fixture(service, "MT-001", "batch-mt-001", "Just Meat", "2026-05-05", 4.2, "Buffalo")
        self.insert_batch_release_sauce_ph_fixture(service, 1001, "CH26030", "Just Meat Original", "2026-01-30", 6.73)
        self.insert_batch_release_sauce_ph_fixture(service, 1002, "CH26031", "Just Meat Original", "2026-01-31", 6.53)

        payload = service.search(
            "what is the average pH across Just Meat batches in 2026? include sauce pH if available",
            source="all",
            kind="atomic",
            limit=10,
        )

        self.assertTrue(payload["ok"])
        rows = [json.loads(row["snippet"]) for row in payload["rows"] if row["title"] == "batch_release_ph_aggregate"]
        grouped = {(row["product_name"], row["flavor_variant"], row["measurement_type"]): row for row in rows}
        self.assertNotIn(("Just Egg", "Original", "product_test_pH"), grouped)
        self.assertEqual(grouped[("Just Meat", "Buffalo", "product_test_pH")]["average_ph"], 4.2)
        self.assertEqual(grouped[("Just Meat Sauce", "Just Meat Original", "sauce_pH")]["measurement_count"], 2)
        self.assertEqual(grouped[("Just Meat Sauce", "Just Meat Original", "sauce_pH")]["average_ph"], 6.63)
        self.assertEqual(
            grouped[("Just Meat Sauce", "Just Meat Original", "sauce_pH")]["period"],
            {"label": "2026", "start": "2026-01-01", "end": "2026-12-31"},
        )

    def test_egg_avg_ph_across_all_time_does_not_expand_to_all_products(self):
        tmp, service = self.make_service()
        self.addCleanup(tmp.cleanup)
        self.insert_batch_release_ph_fixture(service, "EG-001", "batch-eg-001", "Just Egg", "2026-05-05", 6.1, "Original")
        self.insert_batch_release_ph_fixture(service, "MT-001", "batch-mt-001", "Just Meat", "2026-05-05", 4.2, "Buffalo")
        self.insert_batch_release_sauce_ph_fixture(service, 1001, "CH26030", "Just Meat Original", "2026-01-30", 6.73)

        payload = service.search(
            "what is the average pH of egg productions across all time?",
            source="all",
            kind="atomic",
            limit=10,
        )

        self.assertTrue(payload["ok"])
        rows = [json.loads(row["snippet"]) for row in payload["rows"] if row["title"] == "batch_release_ph_aggregate"]
        grouped = {(row["product_name"], row["flavor_variant"], row["measurement_type"]): row for row in rows}
        self.assertEqual(set(grouped), {("Just Egg", "Original", "product_test_pH")})
        self.assertEqual(grouped[("Just Egg", "Original", "product_test_pH")]["average_ph"], 6.1)

    def test_direct_search_for_product_ph_also_uses_release_evidence_not_entr(self):
        tmp, service = self.make_service()
        self.addCleanup(tmp.cleanup)

        payload = service.text_search(
            "Just Meat Original Reefer pH",
            source="all",
            kind="atomic",
            limit=10,
        )

        self.assertTrue(payload["ok"])
        self.assertEqual(payload["query_path"], "planned_source_search")
        self.assertEqual(payload["routing_decision"]["adapter"], "planned_source_search")
        self.assertIn("direct_text_search_bypass", payload["routing_decision"]["not_used"])
        planned_sources = [step["source_id"] for step in payload["source_query_plan"]]
        self.assertEqual(planned_sources[:2], ["batch_release_app", "qualification_meat_sensory"])
        self.assertNotIn("replace_enter_repo_github", planned_sources)
        returned_sources = {row["source_id"] for row in payload["rows"]}
        self.assertIn("batch_release_app", returned_sources)
        self.assertIn("qualification_meat_sensory", returned_sources)
        self.assertNotIn("replace_enter_repo_github", returned_sources)
        self.assertIn("pH: 4.2", json.dumps(payload["rows"]))
        self.assertCanonicalRoutePlanSteps(payload["routing_decision"]["route_plan"])

    def test_single_source_planned_route_honors_requested_limit(self):
        tmp, service = self.make_service()
        self.addCleanup(tmp.cleanup)

        payload = service.search(
            "list the employees at tofutown",
            source="all",
            kind="atomic",
            limit=2,
        )

        self.assertTrue(payload["ok"])
        self.assertEqual(len(payload["rows"]), 2)
        self.assertCanonicalRoutePlanSteps(payload["routing_decision"]["route_plan"])

    def test_open_ar_invoices_routes_to_netsuite_open_ar(self):
        tmp, service = self.make_service()
        self.addCleanup(tmp.cleanup)

        payload = service.search("open AR invoices", source="all", kind="atomic", limit=10)

        self.assertTrue(payload["ok"])
        self.assertEqual(payload["routing_decision"]["route_plan"][0]["adapter"], "netsuite_open_ar")
        self.assertEqual(payload["routing_decision"]["selected_source_lane"], ["netsuite_ar_open_invoices"])

    def test_held_batches_routes_to_batch_release_status(self):
        tmp, service = self.make_service()
        self.addCleanup(tmp.cleanup)

        payload = service.search("held batches", source="all", kind="atomic", limit=10)

        self.assertTrue(payload["ok"])
        self.assertEqual(payload["routing_decision"]["route_plan"][0]["adapter"], "batch_release_batch_status")
        self.assertEqual(payload["routing_decision"]["selected_source_lane"], ["batch_release_app"])

    def test_inbound_shipments_routes_to_operations_inbound_log(self):
        tmp, service = self.make_service()
        self.addCleanup(tmp.cleanup)

        payload = service.search("inbound shipments", source="all", kind="atomic", limit=10)

        self.assertTrue(payload["ok"])
        self.assertEqual(payload["routing_decision"]["route_plan"][0]["adapter"], "operations_inbound_log")
        self.assertEqual(payload["routing_decision"]["selected_source_lane"], ["operations_inbound_log"])

    def test_dot_foodservice_sales_routes_to_dot_weekly_sales(self):
        tmp, service = self.make_service()
        self.addCleanup(tmp.cleanup)

        payload = service.search("latest DOT foodservice sales", source="all", kind="atomic", limit=10)

        self.assertTrue(payload["ok"])
        self.assertEqual(payload["routing_decision"]["route_plan"][0]["adapter"], "dot_foodservice_weekly_sales")
        self.assertEqual(payload["routing_decision"]["selected_source_lane"], ["dot_foodservice_weekly_sales"])
        self.assertIn("Week Ending 5/9", payload["rows"][0]["snippet"])

    def test_source_scoped_dot_foodservice_sales_uses_typed_rows(self):
        tmp, service = self.make_service()
        self.addCleanup(tmp.cleanup)

        payload = service.search(
            "latest DOT foodservice sales",
            source="dot_foodservice_weekly_sales",
            kind="atomic",
            limit=10,
        )

        self.assertTrue(payload["ok"])
        self.assertEqual(payload["routing_decision"]["route_plan"][0]["adapter"], "dot_foodservice_weekly_sales")
        self.assertEqual(payload["routing_decision"]["selected_source_lane"], ["dot_foodservice_weekly_sales"])
        self.assertIn("Week Ending 5/9", payload["rows"][0]["snippet"])

    def test_business_adapter_registry_contains_remaining_pack_names(self):
        adapter_names = {adapter["adapter"] for adapter in serve_http.BUSINESS_ADAPTER_INTENTS}
        expected = {
            "target_tracker_retail_calendar",
            "dot_foodservice_weekly_sales",
            "rd_powerjacks_formula",
            "replace_enter_formula_record",
            "satellite_product_spec",
            "reefer_shelf_life_result",
            "operations_production_plan",
            "operations_otif",
            "appleton_jpc_current_tag",
            "asana_project_status",
            "asana_task_lookup",
            "tofutown_bom",
            "tofutown_standard_cost_margin",
            "just_us_canada_bom_pnl",
        }
        self.assertTrue(expected.issubset(adapter_names), expected - adapter_names)

    def test_broad_fts_routing_decision_uses_canonical_route_shape(self):
        tmp, service = self.make_service()
        self.addCleanup(tmp.cleanup)

        payload = service.search(
            "quality assurance",
            source="all",
            kind="atomic",
            limit=10,
        )

        self.assertTrue(payload["ok"])
        self.assertTrue(payload["rows"])
        self.assertEqual(payload["routing_decision"]["route_shape"], "prose")
        self.assertEqual(payload["routing_decision"]["adapter"], "broad_fts")
        self.assertEqual(payload["routing_decision"]["fallback_policy"], "source_specific_only")
        self.assertNotIn("retrieval_shape", payload["routing_decision"])


if __name__ == "__main__":
    unittest.main()
