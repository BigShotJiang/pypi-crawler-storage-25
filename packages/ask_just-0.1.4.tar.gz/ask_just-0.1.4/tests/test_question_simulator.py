import importlib.util
from pathlib import Path
import unittest


ROOT = Path(__file__).resolve().parents[1]
SIMULATOR_PATH = ROOT / "scripts" / "run_question_simulator.py"


def load_simulator():
    spec = importlib.util.spec_from_file_location("run_question_simulator", SIMULATOR_PATH)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


class QuestionSimulatorTests(unittest.TestCase):
    def test_generates_scorecard_question_from_verified_row(self):
        simulator = load_simulator()
        row = {
            "source_id": "scorecard_monthly_data",
            "source_table": "scorecard_monthly_metric_fields",
            "row_key": "Mar '26:gross_revenue",
            "row_json": '{"metric":"gross_revenue","month":"Mar \\"26","value":4.66,"row_key":"Mar \\"26:gross_revenue"}',
            "provenance_grain": '{"locator":"scorecard#record=7&field=values.gross_revenue"}',
        }

        cases = simulator.generate_cases_from_row(row)

        self.assertEqual(len(cases), 1)
        case = cases[0]
        self.assertEqual(case["expected_source"], "scorecard_monthly_data")
        self.assertIn("gross revenue", case["question"])
        self.assertIn("Mar", case["question"])
        self.assertEqual(case["expected_answer"]["value"], 4.66)
        self.assertIn("gross_revenue", case["expected_tokens"])

    def test_generates_hr_questions_from_workbook_row(self):
        simulator = load_simulator()
        row_json = {
            "cells": [
                {"address": "A2", "value": "Just Food Company"},
                {"address": "B2", "value": "Alan"},
                {"address": "C2", "value": "Gagne"},
                {"address": "D2", "value": "agagne@ju.st"},
                {"address": "E2", "value": "Sales & Marketing Director"},
                {"address": "F2", "value": "Sales - Retail"},
                {"address": "G2", "value": "FT Employee"},
            ],
            "row_index": 2,
            "sheet": "Sheet1",
            "workbook": "Headcount for Josh.xlsx",
        }
        row = {
            "source_id": "hr_just_food_company_headcount",
            "source_table": "workbook_rows",
            "row_key": "Headcount for Josh.xlsx:Sheet1:row:2",
            "row_json": simulator.json_dumps(row_json),
            "provenance_grain": '{"locator":"Headcount for Josh.xlsx#sheet=Sheet1&row=2"}',
        }

        cases = simulator.generate_cases_from_row(row)
        questions = [case["question"] for case in cases]

        self.assertIn("What is Alan Gagne's job title?", questions)
        job_case = next(case for case in cases if "job title" in case["question"])
        self.assertEqual(job_case["expected_tokens"], ["Alan Gagne", "Sales & Marketing Director"])

    def test_grade_live_payload_checks_route_rows_fact_provenance_and_latency(self):
        simulator = load_simulator()
        case = {
            "id": "scorecard_mar_gross_revenue",
            "expected_source": "scorecard_monthly_data",
            "expected_tokens": ["gross_revenue", "4.66"],
            "latency_budget_ms": 500,
        }
        payload = {
            "ok": True,
            "source": "scorecard_monthly_data",
            "rows": [
                {
                    "snippet": "metric gross_revenue value 4.66",
                    "provenance_grain": '{"locator":"scorecard#record=7"}',
                }
            ],
        }

        result = simulator.grade_live_payload(case, payload, latency_ms=499)

        self.assertTrue(result["passed"], result)
        self.assertEqual(result["failure_reasons"], [])

    def test_grade_live_payload_reports_mechanical_failures(self):
        simulator = load_simulator()
        case = {
            "id": "scorecard_mar_gross_revenue",
            "expected_source": "scorecard_monthly_data",
            "expected_tokens": ["gross_revenue", "4.66"],
            "latency_budget_ms": 100,
        }
        payload = {"ok": True, "source": "auto", "rows": []}

        result = simulator.grade_live_payload(case, payload, latency_ms=150)

        self.assertFalse(result["passed"], result)
        self.assertIn("wrong_source", result["failure_types"])
        self.assertIn("no_rows", result["failure_types"])
        self.assertIn("missing_expected_fact", result["failure_types"])
        self.assertIn("missing_provenance", result["failure_types"])
        self.assertIn("latency_budget", result["failure_types"])

    def test_render_outputs_include_interactive_filter_controls(self):
        simulator = load_simulator()
        report = {
            "summary": {"total": 1, "passed": 0, "failed": 1},
            "cases": [
                {
                    "id": "case_1",
                    "question": "What was gross revenue in March?",
                    "expected_source": "scorecard_monthly_data",
                    "passed": False,
                    "failure_types": ["wrong_source"],
                    "failure_reasons": ["expected source scorecard_monthly_data, got auto"],
                    "latency_ms": 612,
                    "expected_answer": {"value": 4.66},
                    "live_payload": {"ok": True, "source": "auto", "rows": []},
                    "reference_row": {"provenance_grain": '{"locator":"scorecard#record=7"}'},
                }
            ],
        }

        html = simulator.render_html(report)
        markdown = simulator.render_markdown(report)

        self.assertIn("data-source=\"scorecard_monthly_data\"", html)
        self.assertIn("filterStatus", html)
        self.assertIn("wrong_source", html)
        self.assertIn("Question Simulator Findings", markdown)
        self.assertIn("scorecard_monthly_data", markdown)

    def test_seed_sql_prefers_source_specific_business_rows(self):
        simulator = load_simulator()

        scorecard_sql = simulator.seed_sql_for_source("scorecard_monthly_data", 5)
        tofutown_sql = simulator.seed_sql_for_source("tofutown_preliminary_pl_march_2026", 5)
        hr_sql = simulator.seed_sql_for_source("hr_just_food_company_headcount", 5)

        self.assertIn("gross_revenue", scorecard_sql)
        self.assertIn("row_index in (5, 6)", tofutown_sql)
        self.assertIn("row_index > 1", hr_sql)

    def test_builds_cross_source_challenge_cases_from_verified_cases(self):
        simulator = load_simulator()
        base_cases = [
            {
                "id": "scorecard_revenue",
                "question": "What was gross revenue in Mar '26?",
                "expected_source": "scorecard_monthly_data",
                "expected_answer": {"value": 4.66},
                "expected_tokens": ["gross_revenue", "4.66"],
                "reference_row": {"row_key": "Mar '26:gross_revenue"},
            },
            {
                "id": "tofutown_revenue",
                "question": "What was TofuTown March gross revenue?",
                "expected_source": "tofutown_preliminary_pl_march_2026",
                "expected_answer": {"value_eur_k": 2093.974},
                "expected_tokens": ["Gross revenue", "2093.974"],
                "reference_row": {"row_key": "Overview_TT_only:row:5"},
            },
        ]

        cases = simulator.build_cross_source_challenge_cases(base_cases, 1)

        self.assertEqual(len(cases), 1)
        self.assertEqual(cases[0]["expected_source"], "multi_source")
        self.assertEqual(
            cases[0]["expected_sources"],
            ["scorecard_monthly_data", "tofutown_preliminary_pl_march_2026"],
        )
        self.assertIn("Answer both", cases[0]["question"])
        self.assertIn("2093.974", cases[0]["expected_tokens"])


if __name__ == "__main__":
    unittest.main()
