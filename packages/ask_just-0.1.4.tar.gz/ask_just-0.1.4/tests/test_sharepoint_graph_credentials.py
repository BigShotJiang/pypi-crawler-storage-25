import os
import sys
import unittest
from unittest import mock


ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
SCRIPTS = os.path.join(ROOT, "scripts")
if SCRIPTS not in sys.path:
    sys.path.insert(0, SCRIPTS)

import build_fresh_source_database


class SharePointGraphCredentialsTest(unittest.TestCase):
    def test_accepts_client_secret_shape(self):
        with mock.patch.dict(
            os.environ,
            {
                "MS_TENANT_ID": "tenant",
                "MS_GRAPH_CLIENT_ID": "client",
                "MS_GRAPH_CLIENT_SECRET": "secret",
            },
            clear=True,
        ):
            credentials = build_fresh_source_database.sharepoint_graph_credentials({"name": "source"})

        self.assertEqual(credentials["tenant_id"], "tenant")
        self.assertEqual(credentials["client_id"], "client")
        self.assertEqual(credentials["client_secret"], "secret")
        self.assertIsNone(credentials["refresh_token"])

    def test_accepts_refresh_token_shape(self):
        with mock.patch.dict(
            os.environ,
            {
                "GRAPH_TENANT_ID": "tenant",
                "GRAPH_CLIENT_ID": "client",
                "GRAPH_REFRESH_TOKEN": "refresh",
            },
            clear=True,
        ):
            credentials = build_fresh_source_database.sharepoint_graph_credentials({"name": "source"})

        self.assertEqual(credentials["tenant_id"], "tenant")
        self.assertEqual(credentials["client_id"], "client")
        self.assertIsNone(credentials["client_secret"])
        self.assertEqual(credentials["refresh_token"], "refresh")

    def test_accepts_previous_order_allocation_graph_secret_shape(self):
        with mock.patch.dict(
            os.environ,
            {
                "GRAPH_TENANT_ID": "tenant",
                "GRAPH_CLIENT_ID": "client",
                "GRAPH_CLIENT_SECRET": "secret",
            },
            clear=True,
        ):
            credentials = build_fresh_source_database.sharepoint_graph_credentials({"name": "source"})

        self.assertEqual(credentials["tenant_id"], "tenant")
        self.assertEqual(credentials["client_id"], "client")
        self.assertEqual(credentials["client_secret"], "secret")
        self.assertIsNone(credentials["refresh_token"])

    def test_rejects_missing_secret_or_refresh_token(self):
        with mock.patch.dict(
            os.environ,
            {
                "MS_TENANT_ID": "tenant",
                "MS_GRAPH_CLIENT_ID": "client",
            },
            clear=True,
        ):
            with self.assertRaisesRegex(RuntimeError, "GRAPH_CLIENT_SECRET"):
                build_fresh_source_database.sharepoint_graph_credentials({"name": "source"})


if __name__ == "__main__":
    unittest.main()
