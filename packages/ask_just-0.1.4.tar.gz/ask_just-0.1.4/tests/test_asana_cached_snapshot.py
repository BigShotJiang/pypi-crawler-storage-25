import json
import os
import sqlite3
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
ASANA_SOURCE_DIR = ROOT / "source-material" / "asana_work_management"


class AsanaCachedSnapshotTest(unittest.TestCase):
    def test_asana_build_uses_cached_snapshot_without_runtime_token(self):
        if not list(ASANA_SOURCE_DIR.glob("asana-rolling-*d-*.json")):
            self.skipTest("No persisted Asana snapshot is available.")

        env = dict(os.environ)
        env.pop("ASANA_ACCESS_TOKEN", None)
        env.pop("ASK_JUST_ASANA_ACCESS_TOKEN", None)
        with tempfile.TemporaryDirectory() as tmpdir:
            result = subprocess.run(
                [
                    sys.executable,
                    "scripts/build_fresh_source_database.py",
                    "--artifact-dir",
                    tmpdir,
                    "--source-id",
                    "asana_work_management",
                ],
                cwd=ROOT,
                env=env,
                check=True,
                text=True,
                capture_output=True,
            )
            payload = json.loads(result.stdout)
            self.assertTrue(payload["ok"])
            self.assertEqual(payload["source_count"], 1)
            self.assertEqual(payload["sources"], ["asana_work_management"])
            self.assertEqual(payload["files"][0]["refresh_mode"], "cached_snapshot_no_runtime_token")
            self.assertGreater(payload["atomic_row_count"], 0)

            conn = sqlite3.connect(Path(tmpdir) / "source_index.sqlite")
            conn.row_factory = sqlite3.Row
            try:
                row = conn.execute(
                    """
                    SELECT source_id, provenance_grain
                    FROM atomic_rows
                    WHERE source_id = 'asana_work_management'
                    LIMIT 1
                    """
                ).fetchone()
                self.assertIsNotNone(row)
                provenance = json.loads(row["provenance_grain"])
                self.assertEqual(provenance["source_id"], "asana_work_management")
                self.assertTrue(provenance["locator"].startswith("asana:/"))
            finally:
                conn.close()


if __name__ == "__main__":
    unittest.main()
