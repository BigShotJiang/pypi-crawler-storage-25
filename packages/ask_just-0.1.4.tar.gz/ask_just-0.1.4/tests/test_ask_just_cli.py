import os
import sys
import unittest


ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
SCRIPTS = os.path.join(ROOT, "scripts")
if SCRIPTS not in sys.path:
    sys.path.insert(0, SCRIPTS)

import ask_just


class AskJustCliTests(unittest.TestCase):
    def test_strip_trace_metadata_preserves_routing_decision(self):
        payload = {
            "ok": True,
            "trace_id": "trace-123",
            "trace_url": "https://braintrust.example/trace-123",
            "routing_decision": {
                "route_shape": "structured",
                "adapter": "tofutown_employees",
                "fallback_policy": "fail_closed_no_prose_fallback",
            },
        }

        stripped = ask_just.strip_trace_metadata(payload)

        self.assertNotIn("trace_id", stripped)
        self.assertNotIn("trace_url", stripped)
        self.assertEqual(
            stripped["routing_decision"]["adapter"],
            "tofutown_employees",
        )


if __name__ == "__main__":
    unittest.main()
