import json
import os
import sqlite3
import sys
import unittest


ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
SCRIPTS = os.path.join(ROOT, "scripts")
if SCRIPTS not in sys.path:
    sys.path.insert(0, SCRIPTS)

import serve_http


class ServeHttpOperationsRoutingTests(unittest.TestCase):
    def make_conn(self):
        conn = sqlite3.connect(":memory:")
        conn.row_factory = sqlite3.Row
        conn.execute("CREATE TABLE sources (source_id TEXT PRIMARY KEY)")
        conn.execute("INSERT INTO sources VALUES ('operations_production_plan_latest')")
        return conn

    def assert_uses_production_plan_adapter(self, question):
        plan = serve_http.build_source_query_plan(
            self.make_conn(),
            question,
            requested_source="operations_production_plan_latest",
        )

        self.assertEqual(len(plan), 1)
        self.assertEqual(plan[0]["source_id"], "operations_production_plan_latest")
        self.assertEqual(plan[0]["adapter_hint"], "operations_production_plan")

    def test_explicit_production_plan_source_keeps_structured_adapter_hint(self):
        self.assert_uses_production_plan_adapter(
            "What is the latest production plan for Just Egg? Return source id and row provenance."
        )

    def test_explicit_production_planning_workbook_wording_keeps_structured_adapter_hint(self):
        self.assert_uses_production_plan_adapter(
            "What production planning workbook rows are visible for April 2026? Return source id and row provenance."
        )

    def test_upstream_demand_prompt_uses_fast_upstream_rows(self):
        conn = sqlite3.connect(":memory:")
        conn.row_factory = sqlite3.Row
        conn.executescript(
            """
            CREATE TABLE sources (source_id TEXT PRIMARY KEY, boundary_json TEXT);
            CREATE TABLE source_files (source_id TEXT, path TEXT, sha256 TEXT, modified_at TEXT, parsed TEXT, provenance_grain TEXT);
            CREATE TABLE atomic_rows (
                source_id TEXT,
                source_table TEXT,
                source_file TEXT,
                row_json TEXT,
                provenance_grain TEXT,
                row_key TEXT,
                row_index INTEGER
            );
            """
        )
        conn.execute("INSERT INTO sources VALUES (?, ?)", ("operations_production_plan_latest", "[]"))
        conn.execute(
            "INSERT INTO atomic_rows VALUES (?, ?, ?, ?, ?, ?, ?)",
            (
                "operations_production_plan_latest",
                "workbook_rows",
                "production.xlsx",
                json.dumps({"sheet": "Upstream Demand", "value": "Just Egg demand"}),
                json.dumps({"source_id": "operations_production_plan_latest", "locator": "production.xlsx#Upstream Demand!1"}),
                "Production Planning.xlsx:Upstream Demand:row:1",
                1,
            ),
        )

        rows = serve_http._operations_production_plan_rows(
            conn,
            "Which production plan rows mention launch, upstream, or demand for Just Egg? Include provenance.",
            5,
        )

        self.assertEqual(len(rows), 1)
        self.assertEqual(rows[0]["source_id"], "operations_production_plan_latest")


if __name__ == "__main__":
    unittest.main()
