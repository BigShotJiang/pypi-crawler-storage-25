import importlib.util
from pathlib import Path
import unittest


ROOT = Path(__file__).resolve().parents[1]
RUNNER_PATH = ROOT / "scripts" / "run_askjust_golden_quality.py"


def load_runner():
    spec = importlib.util.spec_from_file_location("run_askjust_golden_quality", RUNNER_PATH)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


class AskJustGoldenQualityRunnerTests(unittest.TestCase):
    def test_grade_payload_accepts_expected_source_tokens_rows_and_approx_values(self):
        runner = load_runner()
        payload = {
            "ok": True,
            "source": "tofutown_preliminary_pl_march_2026",
            "rows": [
                {
                    "label": "Gross revenue",
                    "row_index": 5,
                    "mar_pre_cell": "F5",
                    "mar_pre_value": 2093.974,
                    "locator": "workbook.xlsx#sheet=Overview_TT_only&row=5",
                }
            ],
        }
        expectations = {
            "ok": True,
            "source": "tofutown_preliminary_pl_march_2026",
            "min_rows": 1,
            "required_tokens": ["Overview_TT_only", "Gross revenue"],
            "row_matches": [
                {
                    "where": {"label": "Gross revenue", "row_index": 5},
                    "expect": {
                        "mar_pre_cell": "F5",
                        "mar_pre_value": {"approx": 2093.974, "tolerance": 0.0001},
                    },
                }
            ],
        }

        result = runner.grade_payload(payload, expectations)

        self.assertTrue(result["passed"], result)
        self.assertEqual(result["failures"], [])

    def test_grade_payload_reports_missing_tokens_and_bad_values(self):
        runner = load_runner()
        payload = {
            "ok": True,
            "source": "scorecard_monthly_data",
            "rows": [{"snippet": "metric gross_margin value 15.9"}],
        }
        expectations = {
            "ok": True,
            "source": "scorecard_monthly_data",
            "min_rows": 1,
            "required_tokens": ["gross_revenue"],
            "row_matches": [
                {
                    "where": {"snippet": {"contains": "gross_margin"}},
                    "expect": {"snippet": {"contains": "gross_revenue"}},
                }
            ],
        }

        result = runner.grade_payload(payload, expectations)

        self.assertFalse(result["passed"], result)
        self.assertIn("missing required token: gross_revenue", result["failures"])
        self.assertTrue(
            any("expected rows[].snippet to contain gross_revenue" in failure for failure in result["failures"])
        )

    def test_run_case_uses_fake_command_runner_and_records_latency(self):
        runner = load_runner()
        case = {
            "id": "scorecard_mar_gross_revenue",
            "question": "what was march revenue?",
            "command": ["ask-just", "query", "Mar gross revenue", "--source", "scorecard_monthly_data"],
            "expect": {
                "ok": True,
                "source": "scorecard_monthly_data",
                "min_rows": 1,
                "required_tokens": ["gross_revenue"],
            },
        }

        def fake_command(argv, timeout):
            self.assertEqual(argv[0], "ask-just")
            self.assertEqual(timeout, 60)
            return 0, '{"ok": true, "source": "scorecard_monthly_data", "rows": [{"snippet": "gross_revenue"}]}', ""

        result = runner.run_case(case, command_runner=fake_command, timeout=60)

        self.assertTrue(result["passed"], result)
        self.assertGreaterEqual(result["latency_ms"], 0)
        self.assertEqual(result["case_id"], "scorecard_mar_gross_revenue")


if __name__ == "__main__":
    unittest.main()
