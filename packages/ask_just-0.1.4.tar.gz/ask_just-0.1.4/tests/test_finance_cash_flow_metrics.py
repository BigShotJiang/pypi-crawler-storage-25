import json
import sqlite3
import tempfile
import unittest
from datetime import datetime
from pathlib import Path

from openpyxl import Workbook

from scripts import build_fresh_source_database as builder


class FinanceCashFlowMetricsTest(unittest.TestCase):
    def write_fixture(self):
        handle = tempfile.NamedTemporaryFile(suffix=".xlsx", delete=False)
        handle.close()
        path = Path(handle.name)
        workbook = Workbook()
        ws = workbook.active
        ws.title = builder.CASH_FLOW_FORECAST_2026_PROJECTION_SHEET

        ws["CY1"] = datetime(2026, 4, 1)
        ws["CY2"] = "TOTAL"
        ws["CY4"] = 1827769.48
        ws["CY5"] = 3991602.78
        ws["CY6"] = -3687224.19
        ws["CY7"] = 2132148.07

        ws["DE1"] = datetime(2026, 5, 1)
        ws["CZ2"] = datetime(2025, 5, 1)
        ws["DE2"] = "TOTAL"
        ws["CZ6"] = -836618.29
        ws["CZ107"] = 794306.93
        ws["CZ100"] = 3354898.82

        workbook.save(path)
        workbook.close()
        return path

    def test_materializes_cash_flow_rows_and_corrects_stale_week_year(self):
        path = self.write_fixture()
        try:
            digest = builder.file_sha256(path)
            rows = list(
                builder.iter_finance_cash_flow_metric_rows(
                    path,
                    "finance_cash_flow_forecast_2026",
                    digest,
                    "2026-05-04T00:00:00Z",
                    "2026-05-04T01:00:00Z",
                )
            )
        finally:
            path.unlink(missing_ok=True)

        payloads = [json.loads(row["row_json"]) for row in rows]
        april_net = next(
            payload
            for payload in payloads
            if payload["metric_key"] == "net_cash_flow" and payload["period_end"] == "2026-04-30"
        )
        may_outflow = next(
            payload
            for payload in payloads
            if payload["metric_key"] == "cash_outflow" and payload["period_end"] == "2026-05-01"
        )
        payment_proof = next(
            payload
            for payload in payloads
            if payload["metric_key"] == "payment_list_proof" and payload["period_end"] == "2026-05-01"
        )

        self.assertEqual(april_net["period_type"], "month_total")
        self.assertAlmostEqual(april_net["amount"], 304378.59)
        self.assertEqual(april_net["source_cells"], ["CY5", "CY6"])
        self.assertEqual(may_outflow["period_type"], "week")
        self.assertEqual(may_outflow["period_end"], "2026-05-01")
        self.assertAlmostEqual(may_outflow["amount"], -836618.29)
        self.assertEqual(payment_proof["cell"], "CZ107")

    def test_typed_table_receives_cash_flow_metric_rows(self):
        conn = sqlite3.connect(":memory:")
        builder.create_schema(conn)
        row = builder.make_finance_cash_flow_metric_row(
            Path("/tmp/2026 Cash Flow Forecast.xlsx"),
            "finance_cash_flow_forecast_2026",
            "abc123def456",
            "2026-05-04T00:00:00Z",
            "2026-05-04T01:00:00Z",
            metric_group="cash_rollforward_computed",
            metric_key="net_cash_flow",
            metric_label="Net Cash Flow",
            account_name=None,
            period={
                "period_type": "month_total",
                "period_start": "2026-04-01",
                "period_end": "2026-04-30",
                "period_label": "April 2026 total",
                "column_letter": "CY",
                "column_index": 103,
            },
            amount=304378.59,
            cell="CY5+CY6",
            row_index=None,
            source_cells=["CY5", "CY6"],
        )
        builder.insert_atomic_row(conn, row)
        typed = conn.execute(
            """
            SELECT metric_key, period_type, period_end, amount, cell, source_cells_json
            FROM finance_cash_flow_metrics
            WHERE row_id = ?
            """,
            (row["row_id"],),
        ).fetchone()

        self.assertEqual(typed[0], "net_cash_flow")
        self.assertEqual(typed[1], "month_total")
        self.assertEqual(typed[2], "2026-04-30")
        self.assertAlmostEqual(typed[3], 304378.59)
        self.assertEqual(typed[4], "CY5+CY6")
        self.assertEqual(json.loads(typed[5]), ["CY5", "CY6"])


if __name__ == "__main__":
    unittest.main()
