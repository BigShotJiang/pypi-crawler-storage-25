import os
import sys
import unittest


ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
SCRIPTS = os.path.join(ROOT, "scripts")
if SCRIPTS not in sys.path:
    sys.path.insert(0, SCRIPTS)

import audit_spins_just_velocity_source_goal as audit


def item_row(source_id, geography, channel, upc, unit=None, dollars=None):
    fields = {
        "Geography": geography,
        "Channel": channel,
        "Time Period": "4 Weeks",
        "Description": "Just Egg Plant Based Scramble 16 Oz" if upc == "01-91011-00127" else "Competitor",
        "UPC": upc,
        "Brand": "JUST" if upc == "01-91011-00127" else "COMPETITOR",
    }
    if unit is not None:
        fields["velocity_units_per_store_per_week"] = unit
    if dollars is not None:
        fields["velocity_dollars_per_store_per_week"] = dollars
    return {
        "_source_id": source_id,
        "_row_id": f"{source_id}:{geography}:{channel}:{upc}",
        "_provenance_grain": "{\"locator\":\"fixture\"}",
        "fields": fields,
    }


def source_gap(source_id, product_key, geography, channel):
    return {
        "_source_id": source_id,
        "_row_id": f"{source_id}:gap:{product_key}:{geography}:{channel}",
        "fields": {
            "SPINS Source Gap": True,
            "product_key": product_key,
            "Geography": geography,
            "Channel": channel,
            "Time Period": "4 Weeks",
        },
    }


class SpinsVelocityGoalAuditTest(unittest.TestCase):
    def test_full_matrix_requires_covered_or_explicit_source_gap(self):
        product = {
            "product_key": "just_egg_pourable_scramble_16oz",
            "source_id": "spins_breakfast_powertabs",
            "family": "just_egg_pourable_scramble",
            "label": "JUST Egg Plant Based Scramble 16 Oz",
            "upcs": ["01-91011-00127"],
        }
        rows = [
            item_row("spins_breakfast_powertabs", "SPROUTS FARMERS MARKET - TOTAL US W/O PL", "NATURAL", "01-91011-00127", unit=3.3, dollars=21.0),
            item_row("spins_breakfast_powertabs", "SPROUTS FARMERS MARKET - TOTAL US W/O PL", "MULO", "00-00000-00000", unit=1.0, dollars=5.0),
        ]

        summary = audit.summarize_product(product, rows, [], "4 Weeks")

        self.assertFalse(summary["ok"])
        self.assertEqual(summary["expected_slice_count"], 2)
        self.assertEqual(summary["covered_slice_count"], 1)
        self.assertEqual(summary["unresolved_slice_count"], 1)

        summary_with_gap = audit.summarize_product(
            product,
            rows,
            [source_gap("spins_breakfast_powertabs", "just_egg_pourable_scramble_16oz", "SPROUTS FARMERS MARKET - TOTAL US W/O PL", "MULO")],
            "4 Weeks",
        )

        self.assertTrue(summary_with_gap["ok"])
        self.assertEqual(summary_with_gap["covered_slice_count"], 1)
        self.assertEqual(summary_with_gap["explicit_source_gap_slice_count"], 1)
        self.assertEqual(summary_with_gap["unresolved_slice_count"], 0)


if __name__ == "__main__":
    unittest.main()
