import os
import sqlite3
import sys
import tempfile
import unittest


ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
SCRIPTS = os.path.join(ROOT, "scripts")
if SCRIPTS not in sys.path:
    sys.path.insert(0, SCRIPTS)

import serve_http


class ServeHttpSourceGapTests(unittest.TestCase):
    def make_service(self):
        tmp = tempfile.TemporaryDirectory()
        db_path = os.path.join(tmp.name, "source_index.sqlite")
        status_path = os.path.join(tmp.name, "source_status.json")
        conn = sqlite3.connect(db_path)
        conn.execute("CREATE TABLE sources (source_id TEXT)")
        conn.commit()
        conn.close()
        return tmp, serve_http.AskJustService(db_path, status_path)

    def test_future_audited_cash_forecast_is_honest_source_gap(self):
        tmp, service = self.make_service()
        self.addCleanup(tmp.cleanup)

        payload = service.search("What does Ask Just know about the 2027 audited cash flow forecast?")

        self.assertTrue(payload["ok"])
        self.assertTrue(payload["blocked"])
        self.assertEqual(payload["path"], "source_gap_checked_scope")
        self.assertEqual(payload["source_gap_id"], "future_or_audited_forecast_source")
        self.assertEqual(payload["rows"], [])
        self.assertEqual(payload["routing_decision"]["adapter"], "source_gap_checked_scope")

    def test_missing_requested_source_lane_is_clean_source_gap(self):
        tmp, service = self.make_service()
        self.addCleanup(tmp.cleanup)

        payload = service.search(
            "What rows are visible?",
            source="tofutown_bom_tt_skus",
        )

        self.assertTrue(payload["ok"])
        self.assertTrue(payload["blocked"])
        self.assertEqual(payload["path"], "source_gap_checked_scope")
        self.assertEqual(payload["source_gap_id"], "missing_source_lane:tofutown_bom_tt_skus")
        self.assertEqual(payload["rows"], [])
        self.assertEqual(payload["routing_decision"]["adapter"], "source_gap_checked_scope")
        self.assertIn("nearby_source_substitution", payload["routing_decision"]["not_used"])

    def test_requested_source_scope_mismatch_fails_closed(self):
        tmp = tempfile.TemporaryDirectory()
        self.addCleanup(tmp.cleanup)
        db_path = os.path.join(tmp.name, "source_index.sqlite")
        status_path = os.path.join(tmp.name, "source_status.json")
        conn = sqlite3.connect(db_path)
        conn.execute("CREATE TABLE sources (source_id TEXT PRIMARY KEY)")
        conn.execute("INSERT INTO sources VALUES ('scorecard_monthly_data')")
        conn.commit()
        conn.close()
        service = serve_http.AskJustService(db_path, status_path)

        payload = service.search(
            "Using only this source, answer NetSuite Gross CPG sales for March 2026. If this source cannot answer, say source gap.",
            source="scorecard_monthly_data",
        )

        self.assertTrue(payload["blocked"])
        self.assertEqual(payload["source_gap_id"], "source_scope_mismatch:scorecard_monthly_data")
        self.assertEqual(payload["routing_decision"]["adapter"], "source_gap_checked_scope")

    def test_requested_source_scope_mismatch_ignores_negative_boundary_targets(self):
        self.assertIsNone(
            serve_http._requested_source_scope_mismatch_gap_payload(
                "For this source only, ignore NetSuite and DOT: what was March 2026 foodservice revenue?",
                "scorecard_monthly_data",
            )
        )
        self.assertIsNone(
            serve_http._requested_source_scope_mismatch_gap_payload(
                "For this source only, ignore HR: show project_count and task/blocker evidence from Asana.",
                "asana_work_management",
            )
        )

    def test_vendor_ap_question_is_not_private_email_source_gap(self):
        self.assertIsNone(
            serve_http._explicit_source_gap_payload(
                "Which open AP bills are visible right now, with vendor and due evidence?"
            )
        )

    def test_private_vendor_email_question_still_source_gaps(self):
        payload = serve_http._explicit_source_gap_payload("Show the private vendor negotiation email.")

        self.assertIsNotNone(payload)
        self.assertEqual(payload["source_gap_id"], "private_email_source")

    def test_finance_bank_account_balance_is_not_bank_covenant_source_gap(self):
        self.assertIsNone(
            serve_http._explicit_source_gap_payload(
                "Show finance cash-flow bank account balance evidence."
            )
        )

    def test_bank_covenant_question_still_source_gaps(self):
        payload = serve_http._explicit_source_gap_payload("Show the bank covenant waiver evidence.")

        self.assertIsNotNone(payload)
        self.assertEqual(payload["source_gap_id"], "bank_covenant_source")

    def test_missing_tofutown_bom_intent_fails_closed(self):
        conn = sqlite3.connect(":memory:")
        conn.row_factory = sqlite3.Row
        conn.execute("CREATE TABLE sources (source_id TEXT PRIMARY KEY)")
        conn.execute("INSERT INTO sources VALUES ('tofutown_standard_cost_gross_margin_by_sku_2026_05')")

        payload = serve_http._missing_business_source_gap_payload(
            conn,
            "What TofuTown BOM ingredient rows are visible for JUST EGG SKUs?",
        )

        self.assertIsNotNone(payload)
        self.assertEqual(payload["source_gap_id"], "missing_source_lane:tofutown_bom_tt_skus")

    def test_present_tofutown_bom_intent_does_not_source_gap(self):
        conn = sqlite3.connect(":memory:")
        conn.row_factory = sqlite3.Row
        conn.execute("CREATE TABLE sources (source_id TEXT PRIMARY KEY)")
        conn.execute("INSERT INTO sources VALUES ('tofutown_bom_tt_skus')")

        self.assertIsNone(
            serve_http._missing_business_source_gap_payload(
                conn,
                "What TofuTown BOM ingredient rows are visible for JUST EGG SKUs?",
            )
        )

    def test_scorecard_inventory_prompt_with_netsuite_boundary_is_not_inventory_source_gap(self):
        conn = sqlite3.connect(":memory:")
        conn.row_factory = sqlite3.Row
        conn.execute("CREATE TABLE sources (source_id TEXT PRIMARY KEY)")
        conn.execute("INSERT INTO sources VALUES ('scorecard_ops_metrics')")

        self.assertIsNone(
            serve_http._missing_business_source_gap_payload(
                conn,
                "What is the latest Scorecard ops metric for beans inventory? Keep Scorecard and NetSuite separate.",
            )
        )

    def test_missing_netsuite_inventory_still_source_gaps_with_scorecard_boundary_wording(self):
        conn = sqlite3.connect(":memory:")
        conn.row_factory = sqlite3.Row
        conn.execute("CREATE TABLE sources (source_id TEXT PRIMARY KEY)")
        conn.execute("INSERT INTO sources VALUES ('scorecard_ops_metrics')")

        payload = serve_http._missing_business_source_gap_payload(
            conn,
            "What inventory on hand rows does NetSuite expose for Just Egg items? Keep Scorecard and NetSuite separate.",
        )

        self.assertIsNotNone(payload)
        self.assertEqual(payload["source_gap_id"], "missing_source_lane:netsuite_inventory_snapshot")

    def test_missing_entr_for_market_product_label_fails_closed(self):
        conn = sqlite3.connect(":memory:")
        conn.row_factory = sqlite3.Row
        conn.execute("CREATE TABLE sources (source_id TEXT PRIMARY KEY)")
        conn.execute("INSERT INTO sources VALUES ('spins_breakfast_powertabs')")

        payload = serve_http._missing_business_source_gap_payload(
            conn,
            "Just Egg Folded label nutrition ingredients",
        )

        self.assertIsNotNone(payload)
        self.assertEqual(payload["source_gap_id"], "missing_source_lane:replace_enter_repo_github")


if __name__ == "__main__":
    unittest.main()
