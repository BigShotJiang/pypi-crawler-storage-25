import json
import os
import sqlite3
import sys
import tempfile
import threading
import unittest
from http.server import ThreadingHTTPServer
from urllib.error import HTTPError
from urllib.request import urlopen


ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
SCRIPTS = os.path.join(ROOT, "scripts")
if SCRIPTS not in sys.path:
    sys.path.insert(0, SCRIPTS)

import serve_http
import build_fresh_source_database as builder


def provenance(locator, as_of="2026-05-04T11:54:54Z"):
    return json.dumps(
        {
            "source_id": "scorecard_monthly_data",
            "source_type": "live_app:scorecard",
            "grain_type": "application/record/field",
            "grain_id": "scorecard_monthly_data:test:7:gross_margin",
            "locator": locator,
            "as_of": as_of,
        }
    )


class ServeHttpHealthTest(unittest.TestCase):
    def make_service(self):
        tmp = tempfile.TemporaryDirectory()
        db_path = os.path.join(tmp.name, "source_index.sqlite")
        status_path = os.path.join(tmp.name, "source_status.json")
        conn = sqlite3.connect(db_path)
        for table in (
            "sources",
            "source_files",
            "source_units",
            "source_chunks",
            "atomic_rows",
            "atomic_rows_fts",
            "receipts",
            "verification_questions",
            "gaps",
        ):
            conn.execute(f"CREATE TABLE {table} (id INTEGER)")
        for table, count in {
            "sources": 2,
            "source_files": 3,
            "atomic_rows": 5,
            "atomic_rows_fts": 5,
            "receipts": 7,
            "gaps": 11,
        }.items():
            conn.executemany(f"INSERT INTO {table} (id) VALUES (?)", [(i,) for i in range(count)])
        conn.commit()
        conn.close()
        with open(status_path, "w", encoding="utf-8") as handle:
            json.dump(
                {
                    "source_count": 99,
                    "source_file_count": 99,
                    "atomic_row_count": 99,
                    "external_answer_artifacts_used": False,
                    "db_path": "stale/status/path.sqlite",
                },
                handle,
            )
        return tmp, serve_http.AskJustService(db_path, status_path)

    def test_health_is_fast_readiness_without_deep_mode(self):
        tmp, service = self.make_service()
        self.addCleanup(tmp.cleanup)

        health = service.health(deep=False)["health"]

        self.assertEqual(health["health_mode"], "ready")
        self.assertEqual(health["source_count"], 2)
        self.assertNotIn("source_file_count", health)
        self.assertNotIn("atomic_row_count", health)
        self.assertNotIn("atomic_row_fts_count", health)
        self.assertIn("cheap readiness health", health["health_note"])

    def test_deep_health_uses_live_sqlite_counts(self):
        tmp, service = self.make_service()
        self.addCleanup(tmp.cleanup)

        health = service.health(deep=True)["health"]

        self.assertEqual(health["health_mode"], "deep")
        self.assertEqual(health["source_count"], 2)
        self.assertEqual(health["source_file_count"], 3)
        self.assertEqual(health["atomic_row_count"], 5)
        self.assertEqual(health["atomic_row_fts_count"], 5)
        self.assertEqual(health["receipt_count"], 7)
        self.assertEqual(health["backlog_gap_count"], 11)

    def test_summary_uses_live_sqlite_counts(self):
        tmp, service = self.make_service()
        self.addCleanup(tmp.cleanup)

        summary = service.summary()

        self.assertEqual(summary["source_count"], 2)
        self.assertEqual(summary["source_file_count"], 3)
        self.assertEqual(summary["atomic_row_count"], 5)
        self.assertEqual(summary["atomic_row_fts_count"], 5)
        self.assertEqual(summary["receipt_count"], 7)
        self.assertEqual(summary["backlog_gap_count"], 11)

    def test_public_skill_endpoint_serves_allowlisted_skill_only(self):
        tmp, service = self.make_service()
        self.addCleanup(tmp.cleanup)
        handler = serve_http.make_handler(service, token="secret")
        server = ThreadingHTTPServer(("127.0.0.1", 0), handler)
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        self.addCleanup(server.server_close)
        self.addCleanup(server.shutdown)
        base_url = f"http://127.0.0.1:{server.server_address[1]}"

        with urlopen(f"{base_url}/skills/askjust/SKILL.md", timeout=5) as response:
            body = response.read().decode("utf-8")

        self.assertEqual(response.status, 200)
        self.assertIn("name: askjust", body)
        self.assertIn("Hide retrieval mechanics by default", body)
        self.assertIn("Do not narrate tool exploration", body)

        with self.assertRaises(HTTPError) as raised:
            urlopen(f"{base_url}/skills/not-real/SKILL.md", timeout=5)

        self.assertEqual(raised.exception.code, 404)
        raised.exception.close()

    def test_kpi_uses_materialized_scorecard_table(self):
        tmp = tempfile.TemporaryDirectory()
        self.addCleanup(tmp.cleanup)
        db_path = os.path.join(tmp.name, "source_index.sqlite")
        status_path = os.path.join(tmp.name, "source_status.json")
        conn = sqlite3.connect(db_path)
        conn.execute(
            """
            CREATE TABLE scorecard_monthly_metrics (
              metric TEXT NOT NULL,
              month TEXT NOT NULL,
              short_month TEXT,
              record_index INTEGER NOT NULL,
              value REAL,
              weeks INTEGER,
              row_key TEXT NOT NULL,
              provenance_locator TEXT NOT NULL,
              as_of TEXT NOT NULL,
              fetched_at TEXT NOT NULL
            )
            """
        )
        conn.execute(
            """
            INSERT INTO scorecard_monthly_metrics
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                "gross_margin",
                "Mar '26",
                "Mar 26",
                7,
                15.9,
                4,
                "Mar '26:gross_margin",
                "https://just-scorecard.vercel.app/api/read-data?key=monthly_data#record=7&field=values.gross_margin",
                "2026-05-04T11:54:54Z",
                "2026-05-04T11:54:54Z",
            ),
        )
        conn.commit()
        conn.close()
        service = serve_http.AskJustService(db_path, status_path)

        payload = service.kpi("gross_margin")

        self.assertTrue(payload["ok"])
        self.assertEqual(payload["path"], "materialized_scorecard_monthly_metrics")
        self.assertEqual(payload["source_id"], "scorecard_monthly_data")
        self.assertEqual(payload["metric"], "gross_margin")
        self.assertEqual(payload["month"], "Mar '26")
        self.assertEqual(payload["value"], 15.9)
        self.assertEqual(payload["provenance"]["locator"], "https://just-scorecard.vercel.app/api/read-data?key=monthly_data#record=7&field=values.gross_margin")
        self.assertEqual(payload["as_of"], "2026-05-04T11:54:54Z")

    def test_kpi_falls_back_to_scorecard_atomic_rows(self):
        tmp = tempfile.TemporaryDirectory()
        self.addCleanup(tmp.cleanup)
        db_path = os.path.join(tmp.name, "source_index.sqlite")
        status_path = os.path.join(tmp.name, "source_status.json")
        conn = sqlite3.connect(db_path)
        conn.execute(
            """
            CREATE TABLE atomic_rows (
              row_id TEXT PRIMARY KEY,
              source_id TEXT NOT NULL,
              source_table TEXT NOT NULL,
              source_file TEXT NOT NULL,
              sheet TEXT,
              row_index INTEGER,
              row_key TEXT NOT NULL,
              row_json TEXT NOT NULL,
              search_text TEXT NOT NULL,
              provenance_grain TEXT NOT NULL
            )
            """
        )
        locator = "https://just-scorecard.vercel.app/api/read-data?key=monthly_data#record=7&field=values.gross_margin"
        conn.execute(
            "INSERT INTO atomic_rows VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
            (
                "scorecard_monthly_data:test:7:gross_margin",
                "scorecard_monthly_data",
                "scorecard_monthly_metric_fields",
                "https://just-scorecard.vercel.app/api/read-data?key=monthly_data",
                None,
                7,
                "Mar '26:gross_margin",
                json.dumps(
                    {
                        "metric": "gross_margin",
                        "month": "Mar '26",
                        "short_month": "Mar 26",
                        "record_index": 7,
                        "value": 15.9,
                        "weeks": 4,
                        "row_key": "Mar '26:gross_margin",
                        "fetched_at": "2026-05-04T11:54:54Z",
                    }
                ),
                "gross_margin Mar '26",
                provenance(locator),
            ),
        )
        conn.commit()
        conn.close()
        service = serve_http.AskJustService(db_path, status_path)

        payload = service.kpi("gross_margin")

        self.assertTrue(payload["ok"])
        self.assertEqual(payload["path"], "atomic_rows_scorecard_fallback")
        self.assertEqual(payload["source_id"], "scorecard_monthly_data")
        self.assertEqual(payload["row_key"], "Mar '26:gross_margin")
        self.assertEqual(payload["value"], 15.9)
        self.assertEqual(payload["provenance"]["locator"], locator)

    def test_ops_kpi_uses_materialized_scorecard_ops_table(self):
        tmp = tempfile.TemporaryDirectory()
        self.addCleanup(tmp.cleanup)
        db_path = os.path.join(tmp.name, "source_index.sqlite")
        status_path = os.path.join(tmp.name, "source_status.json")
        conn = sqlite3.connect(db_path)
        conn.execute(
            """
            CREATE TABLE scorecard_ops_metrics (
              group_name TEXT NOT NULL,
              group_index INTEGER NOT NULL,
              metric_name TEXT NOT NULL,
              metric_index INTEGER NOT NULL,
              field_key TEXT NOT NULL,
              value REAL,
              row_key TEXT NOT NULL,
              provenance_locator TEXT NOT NULL,
              as_of TEXT NOT NULL,
              fetched_at TEXT NOT NULL
            )
            """
        )
        conn.execute(
            """
            INSERT INTO scorecard_ops_metrics
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                "Upstream Inventory",
                1,
                "Protein on Hold (MT)",
                2,
                "mar",
                46,
                "Upstream Inventory:Protein on Hold (MT):mar",
                "https://just-scorecard.vercel.app/api/read-data?key=ops_metrics#group=1&row=2&field=mar",
                "2026-05-04T11:54:54Z",
                "2026-05-04T11:54:54Z",
            ),
        )
        conn.commit()
        conn.close()
        service = serve_http.AskJustService(db_path, status_path)

        payload = service.ops_kpi("Protein on Hold (MT)", "mar")

        self.assertTrue(payload["ok"])
        self.assertEqual(payload["path"], "materialized_scorecard_ops_metrics")
        self.assertEqual(payload["source_id"], "scorecard_ops_metrics")
        self.assertEqual(payload["group"], "Upstream Inventory")
        self.assertEqual(payload["metric"], "Protein on Hold (MT)")
        self.assertEqual(payload["field"], "mar")
        self.assertEqual(payload["value"], 46)

    def make_spins_service(self):
        tmp = tempfile.TemporaryDirectory()
        self.addCleanup(tmp.cleanup)
        db_path = os.path.join(tmp.name, "source_index.sqlite")
        status_path = os.path.join(tmp.name, "source_status.json")
        conn = sqlite3.connect(db_path)
        builder.create_schema(conn)
        conn.commit()
        conn.close()
        return tmp, serve_http.AskJustService(db_path, status_path)

    def insert_spins_atomic_row(self, service, row_id, source_table, fields, source_type="workbook"):
        conn = sqlite3.connect(service.db_path)
        builder.insert_atomic_row(
            conn,
            {
                "row_id": row_id,
                "source_id": "spins_breakfast_powertabs",
                "source_table": source_table,
                "source_file": "SPINS PowerTabs Eat Just Breakfast Data Ending 04-19-26.xlsx",
                "sheet": "Item",
                "row_index": 15,
                "row_key": row_id,
                "row_json": json.dumps({"fields": fields}),
                "search_text": " ".join(str(value) for value in fields.values()),
                "provenance_grain": json.dumps(
                    {
                        "source_id": "spins_breakfast_powertabs",
                        "source_type": source_type,
                        "grain_type": "visible_item_ranking_row",
                        "locator": f"Item!{row_id}",
                    }
                ),
            },
        )
        conn.commit()
        conn.close()

    def insert_workbook_atomic_row(self, service, row):
        conn = sqlite3.connect(service.db_path)
        builder.insert_atomic_row(conn, row)
        conn.commit()
        conn.close()

    def whole_foods_workbook_row(self, source_id, row_id, sheet, cells):
        return {
            "row_id": row_id,
            "source_id": source_id,
            "source_table": "workbook_rows",
            "source_file": "WHO-cube, (JUST EGG, 2026.04.19).xlsx",
            "sheet": sheet,
            "row_index": 42,
            "row_key": row_id,
            "row_json": json.dumps(
                {
                    "workbook": "WHO-cube, (JUST EGG, 2026.04.19).xlsx",
                    "sheet": sheet,
                    "row_index": 42,
                    "cells": [
                        {"address": f"{column}42", "column_letter": column, "value": value}
                        for column, value in cells.items()
                    ],
                }
            ),
            "search_text": " ".join(str(value) for value in cells.values() if value is not None),
            "provenance_grain": json.dumps(
                {
                    "source_id": source_id,
                    "source_type": "local:xlsx_workbook_snapshot",
                    "grain_type": "workbook/sheet/row/column/cell",
                    "locator": f"WHO-cube, (JUST EGG, 2026.04.19).xlsx#sheet={sheet}&row=42",
                }
            ),
        }

    def test_spins_ranking_blocks_when_required_just_sku_gap_exists(self):
        _tmp, service = self.make_spins_service()
        slice_fields = {
            "Geography": "TOTAL US - MULO",
            "Channel": "MULO",
            "Time Period": "4 Weeks",
            "Category": "REFRIGERATED EGGS",
            "Subcategory": "RF EGGS LIQUID",
        }
        self.insert_spins_atomic_row(
            service,
            "gap-just-egg-liquid-16oz",
            "spins_item_ranking_source_gaps",
            {
                **slice_fields,
                "product_key": "just_egg_pourable_scramble_16oz",
                "label": "JUST Egg Plant Based Scramble 16 Oz",
                "gap_type": "missing_spins_item_ranking_row",
                "missing_fields": ["row", "velocity_units_per_store_per_week", "velocity_dollars_per_store_per_week"],
            },
        )
        self.insert_spins_atomic_row(
            service,
            "row-competitor",
            "spins_item_ranking_rows",
            {
                **slice_fields,
                "Description": "Egglands Best Liquid Egg Whites 64 Oz",
                "UPC": "07-15141-93070",
                "Brand": "EGGLANDS BEST",
                "Dollars": 323489,
                "Units": 47032,
                "velocity_units_per_store_per_week": 20.3,
                "velocity_dollars_per_store_per_week": 139.6,
            },
        )

        payload = service.spins_ranking(
            geography="TOTAL US - MULO",
            channel="MULO",
            time_period="4 Weeks",
            category="REFRIGERATED EGGS",
            subcategory="RF EGGS LIQUID",
            order_by="dollars",
        )

        self.assertFalse(payload["ok"])
        self.assertFalse(payload["complete"])
        self.assertTrue(payload["blocked"])
        self.assertEqual(payload["path"], "typed_spins_item_rankings")
        self.assertEqual(payload["rows"], [])
        self.assertEqual(len(payload["blocking_gaps"]), 1)
        self.assertEqual(payload["blocking_gaps"][0]["product_key"], "just_egg_pourable_scramble_16oz")
        self.assertIn("JUST Egg Plant Based Scramble 16 Oz", payload["error"])

    def test_spins_ranking_returns_rows_when_required_just_sku_is_present(self):
        _tmp, service = self.make_spins_service()
        slice_fields = {
            "Geography": "SPROUTS FARMERS MARKET - TOTAL US W/O PL",
            "Channel": "NATURAL",
            "Time Period": "4 Weeks",
            "Category": "FROZEN BREAKFAST FOODS",
            "Subcategory": "FZ BREAKFAST ENTREES",
        }
        self.insert_spins_atomic_row(
            service,
            "row-just-folded",
            "spins_item_ranking_rows",
            {
                **slice_fields,
                "Description": "Just Folded Eggs From Plants 8 Oz",
                "UPC": "01-91011-00087",
                "Brand": "JUST",
                "Dollars": 4393472,
                "Units": 673866,
                "velocity_units_per_store_per_week": 4.9,
                "velocity_dollars_per_store_per_week": 29.5,
            },
        )
        self.insert_spins_atomic_row(
            service,
            "row-competitor",
            "spins_item_ranking_rows",
            {
                **slice_fields,
                "Description": "Applegate Farms Chkn Ssg Frittata Bites 8.4 Oz",
                "UPC": "00-25317-31411",
                "Brand": "APPLEGATE FARMS",
                "Dollars": 2332453,
                "Units": 235598,
                "velocity_units_per_store_per_week": 3.1,
                "velocity_dollars_per_store_per_week": 19.6,
            },
        )

        payload = service.spins_ranking(
            geography="SPROUTS FARMERS MARKET - TOTAL US W/O PL",
            channel="NATURAL",
            time_period="4 Weeks",
            category="FROZEN BREAKFAST FOODS",
            subcategory="FZ BREAKFAST ENTREES",
            order_by="dollars",
        )

        self.assertTrue(payload["ok"])
        self.assertFalse(payload["blocked"])
        self.assertEqual(payload["path"], "typed_spins_item_rankings")
        self.assertEqual([row["description"] for row in payload["rows"]], [
            "Just Folded Eggs From Plants 8 Oz",
            "Applegate Farms Chkn Ssg Frittata Bites 8.4 Oz",
        ])
        self.assertEqual(payload["rows"][0]["unit_velocity"], 4.9)

    def test_spins_ranking_present_visible_row_overrides_missing_row_gap(self):
        _tmp, service = self.make_spins_service()
        slice_fields = {
            "Geography": "SPROUTS FARMERS MARKET - TOTAL US W/O PL",
            "Channel": "NATURAL",
            "Time Period": "4 Weeks",
            "Category": "FROZEN BREAKFAST FOODS",
            "Subcategory": "FZ BREAKFAST ENTREES",
        }
        self.insert_spins_atomic_row(
            service,
            "gap-just-folded",
            "spins_item_ranking_source_gaps",
            {
                **slice_fields,
                "product_key": "just_egg_folded_8oz",
                "label": "Just Folded Eggs From Plants 8 Oz",
                "gap_type": "missing_spins_item_ranking_row",
                "missing_fields": ["spins_item_ranking_rows row", "velocity_units_per_store_per_week"],
            },
        )
        self.insert_spins_atomic_row(
            service,
            "row-just-folded-visible",
            "spins_item_ranking_rows",
            {
                **slice_fields,
                "Description": "Just Folded Eggs From Plants 8 Oz",
                "UPC": "01-91011-00087",
                "Brand": "JUST",
                "Dollars": 1948380.42,
                "Units": 335126.5,
                "velocity_units_per_store_per_week": 4.9,
            },
        )

        payload = service.spins_ranking(
            geography="SPROUTS FARMERS MARKET - TOTAL US W/O PL",
            channel="NATURAL",
            time_period="4 Weeks",
            category="FROZEN BREAKFAST FOODS",
            subcategory="FZ BREAKFAST ENTREES",
            order_by="unit_velocity",
        )

        self.assertTrue(payload["ok"])
        self.assertEqual(payload["blocking_gaps"], [])
        self.assertEqual(payload["rows"][0]["description"], "Just Folded Eggs From Plants 8 Oz")

    def test_spins_ranking_prefers_visible_snapshot_rows_for_exact_slice(self):
        _tmp, service = self.make_spins_service()
        slice_fields = {
            "Geography": "TOTAL US - NATURAL EXPANDED CHANNEL",
            "Channel": "NATURAL",
            "Time Period": "4 Weeks",
            "Category": "REFRIGERATED EGGS",
            "Subcategory": "RF EGGS LIQUID",
        }
        self.insert_spins_atomic_row(
            service,
            "row-egglands-cache",
            "spins_item_ranking_rows",
            {
                **slice_fields,
                "Description": "Egglands Best Liquid Egg Whites 32oz",
                "UPC": "07-15141-11369",
                "Brand": "EGGLANDS BEST",
                "Dollars": 5128.64,
                "velocity_units_per_store_per_week": 7.7,
            },
        )
        self.insert_spins_atomic_row(
            service,
            "row-just-visible",
            "spins_item_ranking_rows",
            {
                **slice_fields,
                "Description": "Just Egg Plant Based Scramble 16 Oz",
                "UPC": "01-91011-00127",
                "Brand": "JUST",
                "Dollars": 345083.52,
                "velocity_units_per_store_per_week": 6.225,
                "velocity_dollars_per_store_per_week": 45.6064,
            },
            source_type="local:excel_visible_report_snapshot",
        )

        payload = service.spins_ranking(
            geography="TOTAL US - NATURAL EXPANDED CHANNEL",
            channel="NATURAL",
            time_period="4 Weeks",
            category="REFRIGERATED EGGS",
            subcategory="RF EGGS LIQUID",
            order_by="unit_velocity",
        )

        self.assertTrue(payload["ok"])
        self.assertEqual(len(payload["rows"]), 1)
        self.assertEqual(payload["rows"][0]["description"], "Just Egg Plant Based Scramble 16 Oz")
        self.assertEqual(payload["rows"][0]["unit_velocity"], 6.225)

    def test_spins_ranking_does_not_block_dollars_rank_on_unneeded_dollar_velocity_gap(self):
        _tmp, service = self.make_spins_service()
        slice_fields = {
            "Geography": "PUBLIX CORP - RMA",
            "Channel": "MULO",
            "Time Period": "4 Weeks",
            "Category": "REFRIGERATED EGGS",
            "Subcategory": "RF EGGS LIQUID",
        }
        self.insert_spins_atomic_row(
            service,
            "gap-just-egg-dollar-velocity",
            "spins_item_ranking_source_gaps",
            {
                **slice_fields,
                "product_key": "just_egg_pourable_scramble_16oz",
                "label": "JUST Egg Plant Based Scramble 16 Oz",
                "gap_type": "missing_required_velocity_metric",
                "missing_fields": ["velocity_dollars_per_store_per_week"],
            },
        )
        self.insert_spins_atomic_row(
            service,
            "row-just-egg",
            "spins_item_ranking_rows",
            {
                **slice_fields,
                "Description": "JUST Egg Plant Based Scramble 16 Oz",
                "UPC": "01-91011-00127",
                "Brand": "JUST",
                "Dollars": 144098,
                "Units": 23746,
                "velocity_units_per_store_per_week": 4.2,
            },
        )

        payload = service.spins_ranking(
            geography="PUBLIX CORP - RMA",
            channel="MULO",
            time_period="4 Weeks",
            category="REFRIGERATED EGGS",
            subcategory="RF EGGS LIQUID",
            order_by="dollars",
        )

        self.assertTrue(payload["ok"])
        self.assertFalse(payload["blocked"])
        self.assertEqual(payload["blocking_gaps"], [])
        self.assertEqual(payload["rows"][0]["description"], "JUST Egg Plant Based Scramble 16 Oz")
        self.assertEqual(payload["rows"][0]["unit_velocity"], 4.2)

    def test_spins_ranking_blocks_dollar_velocity_rank_on_dollar_velocity_gap(self):
        _tmp, service = self.make_spins_service()
        slice_fields = {
            "Geography": "PUBLIX CORP - RMA",
            "Channel": "MULO",
            "Time Period": "4 Weeks",
            "Category": "REFRIGERATED EGGS",
            "Subcategory": "RF EGGS LIQUID",
        }
        self.insert_spins_atomic_row(
            service,
            "gap-just-egg-dollar-velocity",
            "spins_item_ranking_source_gaps",
            {
                **slice_fields,
                "product_key": "just_egg_pourable_scramble_16oz",
                "label": "JUST Egg Plant Based Scramble 16 Oz",
                "gap_type": "missing_required_velocity_metric",
                "missing_fields": ["velocity_dollars_per_store_per_week"],
            },
        )

        payload = service.spins_ranking(
            geography="PUBLIX CORP - RMA",
            channel="MULO",
            time_period="4 Weeks",
            category="REFRIGERATED EGGS",
            subcategory="RF EGGS LIQUID",
            order_by="dollar_velocity",
        )

        self.assertFalse(payload["ok"])
        self.assertTrue(payload["blocked"])
        self.assertEqual(payload["blocking_gaps"][0]["gap_type"], "missing_required_velocity_metric")

    def test_spins_ranking_blocks_when_required_answer_metric_is_null_on_present_row(self):
        _tmp, service = self.make_spins_service()
        slice_fields = {
            "Geography": "PUBLIX CORP - RMA",
            "Channel": "MULO",
            "Time Period": "4 Weeks",
            "Category": "REFRIGERATED EGGS",
            "Subcategory": "RF EGGS LIQUID",
        }
        self.insert_spins_atomic_row(
            service,
            "row-just-egg",
            "spins_item_ranking_rows",
            {
                **slice_fields,
                "Description": "JUST Egg Plant Based Scramble 16 Oz",
                "UPC": "01-91011-00127",
                "Brand": "JUST",
                "velocity_units_per_store_per_week": 4.2,
            },
        )

        payload = service.spins_ranking(
            geography="PUBLIX CORP - RMA",
            channel="MULO",
            time_period="4 Weeks",
            category="REFRIGERATED EGGS",
            subcategory="RF EGGS LIQUID",
            order_by="dollars",
        )

        self.assertFalse(payload["ok"])
        self.assertTrue(payload["blocked"])
        self.assertEqual(payload["blocking_gaps"][0]["gap_type"], "missing_required_answer_metric")
        self.assertIn("Dollars", payload["blocking_gaps"][0]["missing_fields"])

    def test_spins_velocity_returns_exact_typed_sku_slice(self):
        _tmp, service = self.make_spins_service()
        self.insert_spins_atomic_row(
            service,
            "wegmans-just-egg",
            "spins_item_ranking_rows",
            {
                "Geography": "WEGMANS CORP W/O METRO NY - RMA",
                "Channel": "MULO",
                "Time Period": "4 Weeks",
                "Category": "REFRIGERATED EGGS",
                "Subcategory": "RF EGGS LIQUID",
                "Description": "Just Egg Plant Based Scramble 16 Oz",
                "UPC": "01-91011-00127",
                "Brand": "JUST",
                "Dollars": 60218.37,
                "Units": 8116,
                "velocity_units_per_store_per_week": 18.625,
                "velocity_dollars_per_store_per_week": 138.1155275229358,
            },
        )

        payload = service.spins_velocity(
            geography="WEGMANS CORP W/O METRO NY - RMA",
            channel="MULO",
            time_period="4 Weeks",
            category="REFRIGERATED EGGS",
            subcategory="RF EGGS LIQUID",
            product_key="just_egg_pourable_scramble_16oz",
        )

        self.assertTrue(payload["ok"])
        self.assertEqual(payload["path"], "typed_spins_item_rankings")
        self.assertEqual(payload["rows"][0]["description"], "Just Egg Plant Based Scramble 16 Oz")
        self.assertEqual(payload["rows"][0]["unit_velocity"], 18.625)

    def test_spins_velocity_resolves_human_retailer_and_just_egg_shorthand(self):
        _tmp, service = self.make_spins_service()
        self.insert_spins_atomic_row(
            service,
            "kroger-banner-total-just-egg",
            "spins_item_ranking_rows",
            {
                "Geography": "KROGER BANNER TOTAL - RMA",
                "Channel": "MULO",
                "Time Period": "4 Weeks",
                "Category": "REFRIGERATED EGGS",
                "Subcategory": "RF EGGS LIQUID",
                "Description": "Just Egg Plant Based Scramble 16 Oz",
                "UPC": "01-91011-00127",
                "Brand": "JUST",
                "velocity_units_per_store_per_week": 4.3,
            },
        )

        payload = service.spins_velocity(
            geography="Kroger",
            channel="MULO",
            time_period="4 Weeks",
            description="Just Egg",
        )

        self.assertTrue(payload["ok"])
        self.assertEqual(payload["requested_geography"], "Kroger")
        self.assertEqual(payload["geography"], "KROGER BANNER TOTAL - RMA")
        self.assertEqual(payload["rows"][0]["description"], "Just Egg Plant Based Scramble 16 Oz")
        self.assertEqual(payload["rows"][0]["unit_velocity"], 4.3)

    def test_query_routes_plain_just_egg_kroger_velocity_to_spins_velocity(self):
        _tmp, service = self.make_spins_service()
        self.insert_spins_atomic_row(
            service,
            "kroger-banner-total-just-egg",
            "spins_item_ranking_rows",
            {
                "Geography": "KROGER BANNER TOTAL - RMA",
                "Channel": "MULO",
                "Time Period": "4 Weeks",
                "Category": "REFRIGERATED EGGS",
                "Subcategory": "RF EGGS LIQUID",
                "Description": "Just Egg Plant Based Scramble 16 Oz",
                "UPC": "01-91011-00127",
                "Brand": "JUST",
                "velocity_units_per_store_per_week": 4.3,
            },
        )

        payload = service.search("what is the Just Egg velocity in Kroger")

        self.assertTrue(payload["ok"])
        self.assertEqual(payload["path"], "typed_spins_item_rankings")
        self.assertEqual(payload["requested_geography"], "Kroger")
        self.assertEqual(payload["geography"], "KROGER BANNER TOTAL - RMA")
        self.assertEqual(payload["rows"][0]["unit_velocity"], 4.3)
        self.assertEqual(payload["routing_decision"]["route_shape"], "structured")
        self.assertEqual(payload["routing_decision"]["adapter"], "spins_velocity")
        self.assertEqual(payload["routing_decision"]["selected_source_lane"], "spins_breakfast_powertabs")
        self.assertEqual(payload["routing_decision"]["fallback_policy"], "fail_closed_no_prose_fallback")

    def test_spins_velocity_reports_gap_for_missing_exact_sku_slice(self):
        _tmp, service = self.make_spins_service()
        self.insert_spins_atomic_row(
            service,
            "wegmans-folded-gap",
            "spins_item_ranking_source_gaps",
            {
                "product_key": "just_egg_folded_8oz",
                "label": "Just Folded Eggs From Plants 8 Oz",
                "Geography": "WEGMANS CORP W/O METRO NY - RMA",
                "Channel": "MULO",
                "Time Period": "4 Weeks",
                "gap_type": "missing_spins_item_ranking_row",
                "missing_fields": ["spins_item_ranking_rows row", "velocity_units_per_store_per_week"],
            },
        )

        payload = service.spins_velocity(
            geography="WEGMANS CORP W/O METRO NY - RMA",
            channel="MULO",
            time_period="4 Weeks",
            category="FROZEN BREAKFAST FOODS",
            subcategory="FZ BREAKFAST ENTREES",
            product_key="just_egg_folded_8oz",
        )

        self.assertFalse(payload["ok"])
        self.assertTrue(payload["blocked"])
        self.assertEqual(payload["blocking_gaps"][0]["gap_type"], "missing_spins_item_ranking_row")

    def test_whole_foods_us_velocity_materializes_period_data_row(self):
        _tmp, service = self.make_spins_service()
        self.insert_workbook_atomic_row(
            service,
            self.whole_foods_workbook_row(
                "whole_foods_us_who_cube_2026_04_19",
                "whole-foods-us-period-data-liquid",
                "Period DATA",
                {
                    "B": "Florida",
                    "C": "Grocery Dairy-Refrigerated Plant Based Protein",
                    "D": "Breakfast",
                    "E": "Other",
                    "F": "EAT JUST",
                    "G": "0019101100127 EGG LIQUID PLANT BASED 16 OZ",
                    "H": "0019101100127",
                    "J": "16 OZ",
                    "K": "Last 04 Weeks",
                    "L": 16545.68,
                    "N": 2166,
                    "P": 35,
                    "R": 35,
                    "T": 1,
                    "V": "Liquid Egg 16oz",
                    "W": 4,
                },
            ),
        )

        payload = service.whole_foods_us_velocity(
            period="Last 04 Weeks",
            region="Florida",
            item="EGG LIQUID PLANT BASED",
        )

        self.assertTrue(payload["ok"])
        self.assertEqual(payload["path"], "typed_whole_foods_us_who_cube_velocity")
        self.assertEqual(payload["source_id"], "whole_foods_us_who_cube_2026_04_19")
        self.assertEqual(payload["rows"][0]["upc"], "0019101100127")
        self.assertAlmostEqual(payload["rows"][0]["unit_velocity"], 2166 / 35 / 4)

    def test_whole_foods_canada_question_does_not_route_to_us_velocity(self):
        params = serve_http._whole_foods_us_velocity_question_params(
            "what is whole foods canada just egg liquid velocity",
            "all",
        )

        self.assertIsNone(params)

    def test_whole_foods_canada_rl_upsw_materializes_velocity_rows(self):
        _tmp, service = self.make_spins_service()
        self.insert_workbook_atomic_row(
            service,
            self.whole_foods_workbook_row(
                "whole_foods_canada_just_egg_rl_upsw",
                "whole-foods-canada-liquid",
                "mj1ws46_109331306_6E64B3A8X9680",
                {
                    "A": 50816334,
                    "B": "JUST EGG PLANT LIQ",
                    "C": 580.40,
                    "D": 64,
                    "E": 5.818182,
                    "F": 52.763636,
                    "G": 1000,
                    "H": "1280 STEELES AVE E",
                    "I": "MILTON",
                    "J": "ON",
                },
            ),
        )
        self.insert_workbook_atomic_row(
            service,
            self.whole_foods_workbook_row(
                "whole_foods_canada_just_egg_rl_upsw",
                "whole-foods-canada-folded",
                "mj1ws46_109331306_6E64B3A8X9680",
                {
                    "A": 50835048,
                    "B": "JUST PLANT EGG",
                    "C": 291.00,
                    "D": 37,
                    "E": 3.4,
                    "F": 26.47,
                    "G": 3076,
                    "H": "3939 ROCHDALE BLVD",
                    "I": "REGINA",
                    "J": "SK",
                },
            ),
        )

        liquid = service.whole_foods_canada_velocity(product_key="liquid")
        folded = service.search("what is just egg folded velocity in whole foods canada")

        self.assertTrue(liquid["ok"])
        self.assertEqual(liquid["path"], "typed_whole_foods_canada_rl_upsw")
        self.assertEqual(liquid["rows"][0]["product_label"], "JUST Egg Liquid / Pourable")
        self.assertAlmostEqual(liquid["rows"][0]["unit_velocity"], 5.818182)
        self.assertEqual(folded["product_key"], "folded")
        self.assertEqual(folded["rows"][0]["product_label"], "JUST Egg Patty / Folded")
        self.assertEqual(folded["routing_decision"]["route_shape"], "structured")
        self.assertEqual(folded["routing_decision"]["adapter"], "whole_foods_canada_velocity")
        self.assertEqual(folded["routing_decision"]["selected_source_lane"], "whole_foods_canada_just_egg_rl_upsw")
        self.assertEqual(folded["routing_decision"]["fallback_policy"], "fail_closed_no_prose_fallback")

    def test_whole_foods_canada_unqualified_just_egg_velocity_defaults_to_liquid(self):
        _tmp, service = self.make_spins_service()
        self.insert_workbook_atomic_row(
            service,
            self.whole_foods_workbook_row(
                "whole_foods_canada_just_egg_rl_upsw",
                "whole-foods-canada-liquid",
                "mj1ws46_109331306_6E64B3A8X9680",
                {
                    "A": 50816334,
                    "B": "JUST EGG PLANT LIQ",
                    "C": 580.40,
                    "D": 64,
                    "E": 5.818182,
                    "F": 52.763636,
                    "G": 1000,
                    "H": "1280 STEELES AVE E",
                    "I": "MILTON",
                    "J": "ON",
                },
            ),
        )
        self.insert_workbook_atomic_row(
            service,
            self.whole_foods_workbook_row(
                "whole_foods_canada_just_egg_rl_upsw",
                "whole-foods-canada-folded",
                "mj1ws46_109331306_6E64B3A8X9680",
                {
                    "A": 50835048,
                    "B": "JUST PLANT EGG",
                    "C": 291.00,
                    "D": 37,
                    "E": 9.4,
                    "F": 26.47,
                    "G": 3076,
                    "H": "3939 ROCHDALE BLVD",
                    "I": "REGINA",
                    "J": "SK",
                },
            ),
        )

        payload = service.search("what is just egg velocity in canada whole foods")

        self.assertTrue(payload["ok"])
        self.assertEqual(payload["routing_decision"]["adapter"], "whole_foods_canada_velocity")
        self.assertEqual(payload["product_key"], "liquid")
        self.assertEqual(payload["rows"][0]["product_label"], "JUST Egg Liquid / Pourable")

    def test_whole_foods_canada_store_sales_orders_by_total_sales(self):
        _tmp, service = self.make_spins_service()
        for row_id, store_number, city, item, sales, qty, units_per_store, dollars_per_store in [
            ("liquid-low", 1000, "MILTON", "JUST EGG PLANT LIQ", 100.0, 10, 1.0, 10.0),
            ("folded-low", 1000, "MILTON", "JUST PLANT EGG", 150.0, 15, 1.5, 15.0),
            ("liquid-high", 3109, "VICTORIA", "JUST EGG PLANT LIQ", 1000.0, 100, 10.0, 100.0),
            ("folded-high", 3109, "VICTORIA", "JUST PLANT EGG", 900.0, 90, 9.0, 90.0),
        ]:
            self.insert_workbook_atomic_row(
                service,
                self.whole_foods_workbook_row(
                    "whole_foods_canada_just_egg_rl_upsw",
                    f"whole-foods-canada-{row_id}",
                    "mj1ws46_109331306_6E64B3A8X9680",
                    {
                        "A": 50816334 if "LIQ" in item else 50835048,
                        "B": item,
                        "C": sales,
                        "D": qty,
                        "E": units_per_store,
                        "F": dollars_per_store,
                        "G": store_number,
                        "H": "address",
                        "I": city,
                        "J": "BC" if city == "VICTORIA" else "ON",
                    },
                ),
            )

        payload = service.search("what store has highest sales for all just products in whole foods canada")

        self.assertTrue(payload["ok"])
        self.assertEqual(payload["path"], "typed_whole_foods_canada_rl_upsw")
        self.assertEqual(payload["rows"][0]["store_number"], "3109")
        self.assertAlmostEqual(payload["rows"][0]["pos_sales"], 1900.0)
        self.assertEqual(payload["rows"][0]["sku_count"], 2)

    def test_whole_foods_us_store_sales_materializes_summary_row(self):
        _tmp, service = self.make_spins_service()
        self.insert_workbook_atomic_row(
            service,
            self.whole_foods_workbook_row(
                "whole_foods_us_who_cube_2026_04_19",
                "whole-foods-us-store-sales-westbury",
                "Store Sales",
                {
                    "B": 2,
                    "C": "NE - Westbury - 10706",
                    "D": 2,
                    "E": 12670.92,
                    "F": 14296.81,
                    "G": -11.37,
                    "H": 1055.91,
                    "I": 1191.40,
                    "J": 1,
                    "K": 1742,
                    "L": 2040,
                    "M": -14.61,
                    "N": 145.17,
                    "O": 170,
                    "P": 7.27,
                    "Q": 7.01,
                },
            ),
        )

        payload = service.whole_foods_us_store_sales(order_by="units")

        self.assertTrue(payload["ok"])
        self.assertEqual(payload["path"], "typed_whole_foods_us_who_cube_store_sales")
        self.assertEqual(payload["rows"][0]["store_id"], "10706")
        self.assertEqual(payload["rows"][0]["region_code"], "NE")
        self.assertEqual(payload["rows"][0]["unit_rank"], 1)
        self.assertAlmostEqual(payload["rows"][0]["units_per_week"], 145.17)

    def test_whole_foods_us_store_sales_filters_just_meat_from_store_item_tabs(self):
        _tmp, service = self.make_spins_service()
        for row_id, sheet, store, original, buffalo in [
            ("units-altamonte", "By Store Units", "FL - Altamonte Springs - 10516", 85, 39),
            ("units-bayhill", "By Store Units", "FL - Bayhill - 10194", 10, 8),
            ("dollars-altamonte", "By Store Dollars", "FL - Altamonte Springs - 10516", 550.26, 243.64),
            ("dollars-bayhill", "By Store Dollars", "FL - Bayhill - 10194", 67.68, 56.62),
        ]:
            self.insert_workbook_atomic_row(
                service,
                self.whole_foods_workbook_row(
                    "whole_foods_us_who_cube_2026_04_19",
                    f"whole-foods-us-{row_id}",
                    sheet,
                    {
                        "B": 1,
                        "C": store,
                        "P": original,
                        "Q": buffalo,
                    },
                ),
            )

        payload = service.whole_foods_us_store_sales(segment="Plant Based Chicken", order_by="dollars")

        self.assertTrue(payload["ok"])
        self.assertEqual(payload["path"], "typed_whole_foods_us_who_cube_store_item_sales")
        self.assertEqual(payload["rows"][0]["store"], "FL - Altamonte Springs - 10516")
        self.assertEqual(payload["rows"][0]["sku_count"], 2)
        self.assertAlmostEqual(payload["rows"][0]["dollar_sales"], 793.90)
        self.assertAlmostEqual(payload["rows"][0]["units"], 124)

    def test_whole_foods_store_sales_question_routes_just_meat_segment(self):
        params = serve_http._whole_foods_us_store_sales_question_params(
            "show me top whole foods store sales for just meat by dollars",
            "all",
        )

        self.assertEqual(params["segment"], "Plant Based Chicken")
        self.assertEqual(params["order_by"], "dollars")
        self.assertEqual(params["period"], "Latest 12 Weeks")


if __name__ == "__main__":
    unittest.main()
