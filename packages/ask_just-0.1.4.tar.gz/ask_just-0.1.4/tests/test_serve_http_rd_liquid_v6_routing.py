import os
import sys
import unittest


ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
SCRIPTS = os.path.join(ROOT, "scripts")
if SCRIPTS not in sys.path:
    sys.path.insert(0, SCRIPTS)

import serve_http


class ServeHttpRDLiquidV6RoutingTests(unittest.TestCase):
    def test_v6_sheet_wording_is_formula_lane_intent(self):
        self.assertTrue(
            serve_http._is_rd_v6_formula_question(
                "What Liquid Egg v6 sheet rows are visible? Return source id and row provenance."
            )
        )


if __name__ == "__main__":
    unittest.main()
