import json
import os
import sqlite3
import sys
import unittest


ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
SCRIPTS = os.path.join(ROOT, "scripts")
if SCRIPTS not in sys.path:
    sys.path.insert(0, SCRIPTS)

import serve_http


class ServeHttpExplicitBatchReleaseSourceRoutingTests(unittest.TestCase):
    def test_explicit_batch_release_source_keeps_status_adapter_hint(self):
        conn = sqlite3.connect(":memory:")
        conn.row_factory = sqlite3.Row
        conn.execute("CREATE TABLE sources (source_id TEXT PRIMARY KEY)")
        conn.execute("INSERT INTO sources VALUES ('batch_release_app')")

        plan = serve_http.build_source_query_plan(
            conn,
            "What batch release status is visible for the newest batch? Return source id and row provenance.",
            requested_source="batch_release_app",
        )

        self.assertEqual(len(plan), 1)
        self.assertEqual(plan[0]["source_id"], "batch_release_app")
        self.assertEqual(plan[0]["adapter_hint"], "batch_release_batch_status")

    def test_batch_status_adapter_reads_status_rows_without_broad_scan(self):
        conn = sqlite3.connect(":memory:")
        conn.row_factory = sqlite3.Row
        conn.executescript(
            """
            CREATE TABLE sources (source_id TEXT PRIMARY KEY, boundary_json TEXT);
            CREATE TABLE source_files (source_id TEXT, path TEXT, sha256 TEXT, modified_at TEXT, parsed TEXT, provenance_grain TEXT);
            CREATE TABLE atomic_rows (
                source_id TEXT,
                source_table TEXT,
                source_file TEXT,
                row_json TEXT,
                provenance_grain TEXT,
                row_key TEXT,
                row_index INTEGER
            );
            """
        )
        conn.execute("INSERT INTO sources VALUES (?, ?)", ("batch_release_app", "[]"))
        conn.execute(
            "INSERT INTO atomic_rows VALUES (?, ?, ?, ?, ?, ?, ?)",
            (
                "batch_release_app",
                "batch_release_record_fields",
                "batch://release",
                json.dumps({"row_key": "ON03326:status", "status": "released", "value": "released"}),
                json.dumps({"source_id": "batch_release_app", "locator": "batch://release#ON03326:status"}),
                "ON03326:status",
                1,
            ),
        )

        rows = serve_http._batch_release_status_rows(
            conn,
            "Which held or released batches have QA status evidence in the batch release app?",
            5,
        )

        self.assertEqual(len(rows), 1)
        self.assertEqual(rows[0]["source_id"], "batch_release_app")
        self.assertIn("released", rows[0]["snippet"])


if __name__ == "__main__":
    unittest.main()
