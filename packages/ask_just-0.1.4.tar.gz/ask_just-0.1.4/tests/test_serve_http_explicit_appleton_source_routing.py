import json
import os
import sqlite3
import sys
import unittest


ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
SCRIPTS = os.path.join(ROOT, "scripts")
if SCRIPTS not in sys.path:
    sys.path.insert(0, SCRIPTS)

import serve_http


class ServeHttpExplicitAppletonSourceRoutingTests(unittest.TestCase):
    def make_conn(self):
        conn = sqlite3.connect(":memory:")
        conn.row_factory = sqlite3.Row
        conn.execute("CREATE TABLE sources (source_id TEXT PRIMARY KEY)")
        conn.execute("INSERT INTO sources VALUES ('appleton_jpc_factory_dashboard')")
        return conn

    def test_explicit_appleton_source_keeps_dashboard_adapter_hint(self):
        conn = self.make_conn()

        plan = serve_http.build_source_query_plan(
            conn,
            "What current Appleton JPC factory dashboard tags are available? Return source id and row provenance.",
            requested_source="appleton_jpc_factory_dashboard",
        )

        self.assertEqual(len(plan), 1)
        self.assertEqual(plan[0]["source_id"], "appleton_jpc_factory_dashboard")
        self.assertEqual(plan[0]["adapter_hint"], "appleton_jpc_current_tag")

    def test_auto_appleton_tag_beats_otif_if_wrapper_word(self):
        conn = self.make_conn()
        conn.execute("INSERT INTO sources VALUES ('operations_logistics_otif_2024v2')")

        plan = serve_http.build_source_query_plan(
            conn,
            "What Appleton bowl speed setpoint tag evidence is visible? If the lane is missing, say source gap.",
        )

        self.assertEqual(len(plan), 1)
        self.assertEqual(plan[0]["source_id"], "appleton_jpc_factory_dashboard")
        self.assertEqual(plan[0]["adapter_hint"], "appleton_jpc_current_tag")

    def test_appleton_current_tag_adapter_uses_current_readings_not_history(self):
        conn = sqlite3.connect(":memory:")
        conn.row_factory = sqlite3.Row
        conn.executescript(
            """
            CREATE TABLE sources (source_id TEXT PRIMARY KEY, boundary_json TEXT);
            CREATE TABLE source_files (source_id TEXT, path TEXT, sha256 TEXT, modified_at TEXT, parsed TEXT, provenance_grain TEXT);
            CREATE TABLE atomic_rows (
                source_id TEXT,
                source_table TEXT,
                source_file TEXT,
                row_json TEXT,
                provenance_grain TEXT,
                row_key TEXT,
                row_index INTEGER
            );
            """
        )
        conn.execute("INSERT INTO sources VALUES (?, ?)", ("appleton_jpc_factory_dashboard", "[]"))
        conn.execute(
            "INSERT INTO atomic_rows VALUES (?, ?, ?, ?, ?, ?, ?)",
            (
                "appleton_jpc_factory_dashboard",
                "appleton_jpc_factory_current_readings",
                "appleton://current",
                json.dumps({"description": "Gearbox Temp", "value": 40.7}),
                json.dumps({"source_id": "appleton_jpc_factory_dashboard", "locator": "appleton://current#gearbox"}),
                "current:gearbox",
                1,
            ),
        )
        conn.execute(
            "INSERT INTO atomic_rows VALUES (?, ?, ?, ?, ?, ?, ?)",
            (
                "appleton_jpc_factory_dashboard",
                "appleton_jpc_factory_history_points",
                "appleton://history",
                json.dumps({"description": "Gearbox Temp", "value": 39.0}),
                json.dumps({"source_id": "appleton_jpc_factory_dashboard", "locator": "appleton://history#gearbox"}),
                "history:gearbox",
                2,
            ),
        )

        rows = serve_http._appleton_current_tag_rows(conn, "What Appleton gearbox temp tag evidence is visible?", 5)

        self.assertEqual(len(rows), 1)
        self.assertEqual(rows[0]["title"], "appleton_jpc_factory_current_readings")
        self.assertIn("Gearbox Temp", rows[0]["snippet"])


if __name__ == "__main__":
    unittest.main()
