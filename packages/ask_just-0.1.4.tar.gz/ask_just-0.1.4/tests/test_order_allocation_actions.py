import json
import os
import sqlite3
import sys
import tempfile
import unittest
from unittest import mock


ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
SCRIPTS = os.path.join(ROOT, "scripts")
if SCRIPTS not in sys.path:
    sys.path.insert(0, SCRIPTS)

import ask_just
import order_allocation_actions
import serve_http


class OrderAllocationActionsTest(unittest.TestCase):
    def make_service(self):
        tmp = tempfile.TemporaryDirectory()
        self.addCleanup(tmp.cleanup)
        db_path = os.path.join(tmp.name, "source_index.sqlite")
        status_path = os.path.join(tmp.name, "source_status.json")
        conn = sqlite3.connect(db_path)
        conn.execute(
            """
            CREATE TABLE sources (
              source_id TEXT PRIMARY KEY,
              mapped TEXT,
              accessible TEXT,
              atomically_queryable TEXT,
              freshness_expectation TEXT
            )
            """
        )
        conn.execute(
            """
            CREATE TABLE atomic_rows (
              row_id TEXT PRIMARY KEY,
              source_id TEXT,
              source_table TEXT,
              source_file TEXT,
              sheet TEXT,
              row_index INTEGER,
              row_key TEXT,
              row_json TEXT,
              search_text TEXT,
              provenance_grain TEXT
            )
            """
        )
        conn.execute(
            "INSERT INTO sources VALUES (?, ?, ?, ?, ?)",
            (
                "operations_order_allocation",
                "yes",
                "no",
                "no",
                "daily_midnight_mailbox_evista_netsuite_sharepoint_refresh",
            ),
        )
        conn.commit()
        conn.close()
        with open(status_path, "w", encoding="utf-8") as handle:
            json.dump({"generated_at": "2026-05-06T14:55:00Z", "sources": ["operations_order_allocation"]}, handle)
        return serve_http.AskJustService(db_path, status_path)

    def test_allocation_window_uses_pacific_run_date_rules(self):
        self.assertEqual(
            order_allocation_actions.allocation_window_for_run_date("2026-05-04"),
            {
                "allocation_day": "monday",
                "window_start": "2026-05-11",
                "window_end": "2026-05-17",
                "run_date": "2026-05-04",
            },
        )
        self.assertEqual(
            order_allocation_actions.allocation_window_for_run_date("2026-05-07"),
            {
                "allocation_day": "thursday",
                "window_start": "2026-05-12",
                "window_end": "2026-05-15",
                "run_date": "2026-05-07",
            },
        )
        self.assertEqual(order_allocation_actions.allocation_window_for_run_date("2026-05-05")["allocation_day"], "thursday")
        self.assertEqual(order_allocation_actions.allocation_window_for_run_date("2026-05-08")["allocation_day"], "monday")
        with self.assertRaises(order_allocation_actions.OrderAllocationBlocked):
            order_allocation_actions.allocation_window_for_run_date("2026-05-09")

    def test_prepare_blocks_until_required_source_families_are_fresh(self):
        service = self.make_service()

        payload = service.order_allocation_prepare({"run_date": "2026-05-06"})

        self.assertFalse(payload["ok"])
        self.assertTrue(payload["blocked"])
        self.assertEqual(payload["action"], "order_allocation.prepare")
        self.assertEqual(payload["source_id"], "operations_order_allocation")
        self.assertEqual(payload["freshness_contract"]["required_by"], "08:00:00")
        self.assertEqual(payload["freshness_contract"]["timezone"], "America/Los_Angeles")
        self.assertTrue(payload["freshness_contract"]["no_override"])
        self.assertIn("inventory_vernon", payload["stale_or_missing_families"])
        self.assertIn("inventory_bethlehem", payload["stale_or_missing_families"])
        self.assertIn("inventory_vertical_evista", payload["stale_or_missing_families"])
        self.assertIn("netsuite_open_orders", payload["stale_or_missing_families"])
        self.assertIn("repair_instructions", payload)
        self.assertEqual(payload["draft_artifacts"], [])

    def test_prepare_reports_source_ready_when_all_required_families_are_fresh(self):
        service = self.make_service()
        conn = sqlite3.connect(service.db_path)
        conn.execute(
            "UPDATE sources SET accessible = 'yes', atomically_queryable = 'yes' WHERE source_id = ?",
            (order_allocation_actions.SOURCE_ID,),
        )
        for family in order_allocation_actions.REQUIRED_SOURCE_FAMILIES:
            record = {
                "family_id": family["id"],
                "freshness_date": "2026-05-06",
                "fetched_at": "2026-05-06T14:55:00Z",
                "source_time": "2026-05-06T14:55:00Z",
                "source_uri": f"test:/{family['id']}",
                "artifact_locator": f"test:/{family['id']}",
                "row_count": 1,
                "sha256": "a" * 64,
                "proof_type": "unit_test_source_family_proof",
            }
            conn.execute(
                """
                INSERT INTO atomic_rows (
                  row_id, source_id, source_table, source_file, sheet, row_index,
                  row_key, row_json, search_text, provenance_grain
                )
                VALUES (?, ?, ?, ?, NULL, 0, ?, ?, ?, '{}')
                """,
                (
                    f"row:{family['id']}",
                    order_allocation_actions.SOURCE_ID,
                    order_allocation_actions.SOURCE_FAMILY_PROOF_TABLE,
                    f"proofs/{family['id']}.json",
                    f"2026-05-06:{family['id']}",
                    json.dumps(record),
                    family["id"],
                ),
            )
        conn.commit()
        conn.close()

        payload = service.order_allocation_prepare({"run_date": "2026-05-06"})

        self.assertTrue(payload["ok"])
        self.assertFalse(payload["blocked"])
        self.assertTrue(payload["source_ready"])
        self.assertEqual(payload["stale_or_missing_families"], [])
        self.assertEqual(payload["source_readiness"]["accessible"], "yes")
        self.assertEqual(payload["source_readiness"]["atomically_queryable"], "yes")
        self.assertEqual(payload["draft_generation_status"], "not_enabled_in_v0")
        self.assertTrue(payload["review_required"])

    def test_rehearse_uses_same_source_gate_but_disables_external_writes(self):
        service = self.make_service()
        conn = sqlite3.connect(service.db_path)
        conn.execute(
            "UPDATE sources SET accessible = 'yes', atomically_queryable = 'yes' WHERE source_id = ?",
            (order_allocation_actions.SOURCE_ID,),
        )
        for family in order_allocation_actions.REQUIRED_SOURCE_FAMILIES:
            record = {
                "family_id": family["id"],
                "freshness_date": "2026-05-06",
                "fetched_at": "2026-05-06T14:55:00Z",
                "source_time": "2026-05-06T14:55:00Z",
                "source_uri": f"test:/{family['id']}",
                "artifact_locator": f"test:/{family['id']}",
                "row_count": 1,
                "sha256": "a" * 64,
                "proof_type": "unit_test_source_family_proof",
            }
            conn.execute(
                """
                INSERT INTO atomic_rows (
                  row_id, source_id, source_table, source_file, sheet, row_index,
                  row_key, row_json, search_text, provenance_grain
                )
                VALUES (?, ?, ?, ?, NULL, 0, ?, ?, ?, '{}')
                """,
                (
                    f"rehearsal-row:{family['id']}",
                    order_allocation_actions.SOURCE_ID,
                    order_allocation_actions.SOURCE_FAMILY_PROOF_TABLE,
                    f"proofs/{family['id']}.json",
                    f"2026-05-06:{family['id']}",
                    json.dumps(record),
                    family["id"],
                ),
            )
        conn.commit()
        conn.close()

        payload = service.order_allocation_rehearse({"run_date": "2026-05-06"})

        self.assertTrue(payload["ok"])
        self.assertFalse(payload["blocked"])
        self.assertEqual(payload["action"], "order_allocation.rehearse")
        self.assertEqual(payload["run_mode"], "rehearsal_no_commit")
        self.assertFalse(payload["external_writes_allowed"])
        self.assertFalse(payload["netsuite_commit_allowed"])
        self.assertFalse(payload["process_approved_allowed"])
        self.assertFalse(payload["rehearsal_contract"]["writes_netsuite"])
        self.assertEqual(payload["draft_generation_status"], "practice_only_no_real_order_allocation")
        self.assertEqual(len(payload["practice_packet"]["source_family_cards"]), len(order_allocation_actions.REQUIRED_SOURCE_FAMILIES))
        self.assertIn("decision_grains_needed_before_real_draft", payload["practice_packet"])
        self.assertIn(
            "inbound ETA rows proving ETA plus 2 day buffer still supports the customer delivery date",
            payload["practice_packet"]["decision_grains_needed_before_real_draft"],
        )
        self.assertIn(
            "Inbound pending is allocatable only when the inbound ETA plus a 2 day buffer still allows on-time customer delivery.",
            payload["practice_packet"]["allocation_rules"],
        )

    def test_prepare_returns_structured_weekend_block(self):
        service = self.make_service()

        payload = service.order_allocation_prepare({"run_date": "2026-05-09"})

        self.assertFalse(payload["ok"])
        self.assertTrue(payload["blocked"])
        self.assertEqual(payload["allocation_window"], None)
        self.assertIn("weekday-only", payload["reason"])
        self.assertEqual(payload["draft_artifacts"], [])

    def test_cli_routes_order_allocation_actions_through_http_service(self):
        calls = []

        def fake_call(args, path, method="GET", payload=None):
            calls.append({"path": path, "method": method, "payload": payload})
            return 0

        with mock.patch.object(ask_just, "call", side_effect=fake_call), mock.patch.object(
            sys,
            "argv",
            ["ask-just", "actions", "order-allocation", "prepare", "--run-date", "2026-05-06"],
        ):
            with self.assertRaises(SystemExit) as raised:
                ask_just.main()

        self.assertEqual(raised.exception.code, 0)

        self.assertEqual(
            calls,
            [
                {
                    "path": "/actions/order-allocation/prepare",
                    "method": "POST",
                    "payload": {"run_date": "2026-05-06"},
                }
            ],
        )

    def test_cli_routes_order_allocation_rehearsal_through_http_service(self):
        calls = []

        def fake_call(args, path, method="GET", payload=None):
            calls.append({"path": path, "method": method, "payload": payload})
            return 0

        with mock.patch.object(ask_just, "call", side_effect=fake_call), mock.patch.object(
            sys,
            "argv",
            ["ask-just", "actions", "order-allocation", "rehearse", "--run-date", "2026-05-06"],
        ):
            with self.assertRaises(SystemExit) as raised:
                ask_just.main()

        self.assertEqual(raised.exception.code, 0)
        self.assertEqual(
            calls,
            [
                {
                    "path": "/actions/order-allocation/rehearse",
                    "method": "POST",
                    "payload": {"run_date": "2026-05-06"},
                }
            ],
        )
