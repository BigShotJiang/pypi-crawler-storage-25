import json
import sqlite3
import tempfile
import unittest
from pathlib import Path
from unittest import mock

from scripts import build_fresh_source_database as builder


def workbook_row(sheet, row_index, values_by_column):
    return {
        "row_key": f"fixture:{sheet}:row:{row_index}",
        "workbook": "fixture.xlsb",
        "workbook_sha256": "abc123",
        "sheet": sheet,
        "row_index": row_index,
        "cells": [
            {
                "address": f"C{row_index}",
                "column_index": column_index,
                "column_letter": "C",
                "value": value,
            }
            for column_index, value in values_by_column.items()
        ],
    }


class SpinsItemRankingRowsTest(unittest.TestCase):
    def test_spins_item_ranking_rows_populate_typed_fact_table(self):
        path = Path("/tmp/SPINS PowerTabs Eat Just Breakfast Data Ending 04-19-26.xlsb")
        row = builder.make_spins_item_ranking_row(
            path=path,
            source_id="spins_breakfast_powertabs",
            file_digest="abc123def456",
            modified="2026-05-03T00:00:00Z",
            extracted_at="2026-05-03T01:00:00Z",
            row_index=17,
            fields={
                "Geography": "WEGMANS CORP W/O METRO NY - RMA",
                "Channel": "MULO",
                "Time Period": "4 Weeks",
                "Category": "REFRIGERATED EGGS",
                "Subcategory": "RF EGGS LIQUID",
                "Product Type": "RF LIQUID EGGS",
                "Description": "Just Egg Plant Based Scramble 16 Oz",
                "UPC": "01-91011-00127",
                "Brand": "JUST",
                "Dollars": 60218.37,
                "Units": 8116,
                "Average Weekly Units Per Store Selling Per Item": 18.625,
                "Average Weekly Dollars Per Store Selling Per Item": 138.1155275229358,
            },
            locator="/tmp/source.xlsb#sheet=Item&row=17",
        )
        conn = sqlite3.connect(":memory:")
        try:
            builder.create_schema(conn)
            builder.insert_atomic_row(conn, row)
            typed = conn.execute(
                """
                SELECT geography, channel, time_period, upc, dollars, units, unit_velocity, dollar_velocity
                FROM spins_item_rankings
                WHERE row_id = ?
                """,
                (row["row_id"],),
            ).fetchone()
        finally:
            conn.close()

        self.assertEqual(typed[0], "WEGMANS CORP W/O METRO NY - RMA")
        self.assertEqual(typed[3], "01-91011-00127")
        self.assertEqual(typed[4], 60218.37)
        self.assertEqual(typed[6], 18.625)
        self.assertAlmostEqual(typed[7], 138.1155275229358)

    def test_visible_item_ranking_materializes_walmart_just_egg_velocity(self):
        rows = [
            workbook_row("Item_Rank_ALL_Pivot", 1, {1: "Geography", 2: "WALMART CORP - RMA"}),
            workbook_row("Item_Rank_ALL_Pivot", 2, {1: "Time Period", 2: "4 Weeks"}),
            workbook_row("Item_Rank_ALL_Pivot", 3, {1: "Time Period End Date", 2: "(All)"}),
            workbook_row("Item", 4, {2: "Latest Data Ending 4/19/2026"}),
            workbook_row("Item", 12, {2: "WALMART CORP - RMA", 5: "Brand", 22: "Velocity Measures"}),
            workbook_row(
                "Item",
                13,
                {
                    2: "Rank",
                    3: "Description",
                    4: "UPC",
                    6: "Dollars",
                    24: "Units SPP",
                    26: "Average Weekly Dollars Per Store Selling Per Item",
                    27: "Average Weekly Dollars Per Store Selling Per Item % Chg",
                    28: "Average Weekly Units Per Store Selling Per Item",
                    29: "Average Weekly Units Per Store Selling Per Item % Chg",
                },
            ),
            workbook_row("Item", 14, {2: "Subcategory Level", 3: "RF EGGS LIQUID"}),
            workbook_row(
                "Item",
                17,
                {
                    2: 3.0,
                    3: "Just Egg Plant Based Scramble 16 Oz",
                    4: "01-91011-00127",
                    5: "JUST",
                    6: 461248.35,
                    24: 898.911924119241,
                    26: 35.5,
                    27: -0.201,
                    28: 5.1,
                    29: -0.156185303391,
                },
            ),
        ]

        materialized = list(
            builder.iter_spins_item_ranking_rows(
                Path("/tmp/SPINS PowerTabs Eat Just Breakfast Data Ending 04-19-26.xlsb"),
                "spins_breakfast_powertabs",
                "abc123def456",
                "2026-05-03T00:00:00Z",
                "2026-05-03T01:00:00Z",
                rows,
            )
        )

        self.assertEqual(len(materialized), 1)
        row = json.loads(materialized[0]["row_json"])
        fields = row["fields"]
        self.assertEqual(materialized[0]["source_table"], "spins_item_ranking_rows")
        self.assertEqual(fields["Geography"], "WALMART CORP - RMA")
        self.assertEqual(fields["Time Period"], "4 Weeks")
        self.assertEqual(fields["Time Period End Date"], "2026-04-19")
        self.assertEqual(fields["Description"], "Just Egg Plant Based Scramble 16 Oz")
        self.assertEqual(fields["Brand"], "JUST")
        self.assertEqual(fields["Weekly dollars/store"], 35.5)
        self.assertEqual(fields["velocity_dollars_per_store_per_week"], 35.5)
        self.assertEqual(fields["velocity_dollars_per_store_per_week_pct_change"], -0.201)
        self.assertEqual(fields["Weekly u/s/w"], 5.1)
        self.assertEqual(fields["velocity_units_per_store_per_week"], 5.1)
        self.assertEqual(fields["just_sku_family"], "just_egg_pourable_scramble")
        self.assertEqual(fields["just_sku_group"], "JUST Egg refrigerated liquid")
        self.assertEqual(fields["Subcategory"], "RF EGGS LIQUID")
        provenance = json.loads(materialized[0]["provenance_grain"])
        self.assertEqual(provenance["grain_type"], "workbook/xlsb/visible-report/item-ranking/row/field")
        self.assertIn("#sheet=Item&row=17", provenance["locator"])

    def test_normalizes_declared_just_velocity_sku_families(self):
        cases = [
            ("Just Egg Folded Plant Eggs 8 Oz", "JUST", "spins_breakfast_powertabs", "just_egg_folded"),
            ("Just Egg Breakfast Burrito 5 Oz", "JUST", "spins_breakfast_powertabs", "just_egg_burritos"),
            ("Just Meat Plant Based Buffalo Chicken 8 Oz", "JUST", "spins_plant_based_meat_powertabs", "just_meat"),
            ("Just Protein Powder Vanilla 1 Lb", "JUST", "spins_protein_powder_powertabs", "protein_powder"),
            ("Just Original Ranch 12 Oz", "JUST", "spins_condiments_powertabs", "condiments"),
        ]
        for description, brand, source_id, family in cases:
            with self.subTest(description=description):
                normalized = builder.normalize_spins_just_sku(description, brand, source_id)
                self.assertTrue(normalized["is_just_sku"])
                self.assertEqual(normalized["just_sku_family"], family)

    def test_visible_snapshot_materializes_sprouts_folded_velocity(self):
        snapshot = {
            "schema": "ask-just.spins-visible-item-ranking.v1",
            "captured_at": "2026-05-03T18:00:00Z",
            "source_id": "spins_breakfast_powertabs",
            "workbook": "SPINS PowerTabs Eat Just Breakfast Data Ending 04-19-26.xlsb",
            "sheet": "Item",
            "latest_data_ending": "2026-04-19",
            "report_filters": {
                "Geography": "SPROUTS FARMERS MARKET - TOTAL US W/O PL",
                "Time Period": "4 Weeks",
                "Time Period End Date": "(All)",
                "Category": "FROZEN BREAKFAST FOODS",
                "Subcategory": "FZ BREAKFAST ENTREES",
            },
            "subcategory": "FZ BREAKFAST ENTREES",
            "rows": [
                {
                    "row_index": 17,
                    "fields": {
                        "Rank": 3.0,
                        "Description": "Just Folded Eggs From Plants 8 Oz",
                        "UPC": "01-91011-00087",
                        "Brand": "JUST",
                        "Average Weekly Dollars Per Store Selling Per Item": 28.4,
                        "Average Weekly Units Per Store Selling Per Item": 4.9,
                        "Average Weekly Units Per Store Selling Per Item % Chg": -0.099,
                    },
                }
            ],
        }
        with tempfile.TemporaryDirectory() as directory:
            snapshot_path = Path(directory) / "breakfast.visible-item-ranking.json"
            snapshot_path.write_text(json.dumps(snapshot), encoding="utf-8")
            materialized = list(
                builder.iter_spins_visible_item_ranking_snapshot_rows(
                    snapshot_path,
                    "spins_breakfast_powertabs",
                    "2026-05-03T00:00:00Z",
                    "2026-05-03T01:00:00Z",
                )
            )

        self.assertEqual(len(materialized), 1)
        self.assertEqual(materialized[0]["source_table"], "spins_item_ranking_rows")
        row = json.loads(materialized[0]["row_json"])
        fields = row["fields"]
        self.assertEqual(fields["Geography"], "SPROUTS FARMERS MARKET - TOTAL US W/O PL")
        self.assertEqual(fields["Time Period"], "4 Weeks")
        self.assertEqual(fields["Time Period End Date"], "2026-04-19")
        self.assertEqual(fields["Subcategory"], "FZ BREAKFAST ENTREES")
        self.assertEqual(fields["Description"], "Just Folded Eggs From Plants 8 Oz")
        self.assertEqual(fields["Brand"], "JUST")
        self.assertEqual(fields["Weekly dollars/store"], 28.4)
        self.assertEqual(fields["velocity_dollars_per_store_per_week"], 28.4)
        self.assertEqual(fields["Weekly u/s/w"], 4.9)
        self.assertEqual(fields["velocity_units_per_store_per_week"], 4.9)
        self.assertEqual(fields["just_sku_family"], "just_egg_folded")
        self.assertTrue(fields["SPINS Visible Snapshot"])
        self.assertEqual(fields["Category"], "FROZEN BREAKFAST FOODS")

    def test_snapshot_row_ids_include_snapshot_slug(self):
        base_snapshot = {
            "schema": "ask-just.spins-visible-item-ranking.v1",
            "captured_at": "2026-05-03T18:00:00Z",
            "source_id": "spins_breakfast_powertabs",
            "workbook": "SPINS PowerTabs Eat Just Breakfast Data Ending 04-19-26.xlsb",
            "sheet": "Item",
            "latest_data_ending": "2026-04-19",
            "report_filters": {
                "Geography": "(All)",
                "Time Period": "4 Weeks",
                "Time Period End Date": "(All)",
            },
            "rows": [
                {
                    "row_index": 15,
                    "fields": {
                        "Rank": 1.0,
                        "Description": "Just Egg Plant Based Scramble 16 Oz",
                        "UPC": "01-91011-00127",
                        "Brand": "JUST",
                        "Dollars": 6270044.55,
                    },
                }
            ],
        }
        with tempfile.TemporaryDirectory() as directory:
            directory = Path(directory)
            paths = []
            for snapshot_id in ("refrigerated-liquid-eggs", "frozen-breakfast-entrees"):
                snapshot = dict(base_snapshot)
                snapshot["snapshot_id"] = snapshot_id
                path = directory / f"{snapshot_id}.json"
                path.write_text(json.dumps(snapshot), encoding="utf-8")
                paths.append(path)

            materialized = []
            for path in paths:
                materialized.extend(
                    builder.iter_spins_visible_item_ranking_snapshot_rows(
                        path,
                        "spins_breakfast_powertabs",
                        "2026-05-03T00:00:00Z",
                        "2026-05-03T01:00:00Z",
                    )
                )

        self.assertEqual(len(materialized), 2)
        row_ids = {row["row_id"] for row in materialized}
        row_keys = {row["row_key"] for row in materialized}
        self.assertEqual(len(row_ids), 2)
        self.assertEqual(len(row_keys), 2)
        self.assertTrue(any("refrigerated_liquid_eggs" in row_id for row_id in row_ids))
        self.assertTrue(any("frozen_breakfast_entrees" in row_id for row_id in row_ids))

    def test_standard_item_slice_materializes_from_decoded_pivot_cache(self):
        pivot_row = {
            "row_json": json.dumps(
                {
                    "pivot_cache": 7,
                    "record_index": 42,
                    "fields": {
                        "Channel": "NATURAL",
                        "Geography": "TOTAL US - NATURAL EXPANDED CHANNEL",
                        "Time Period": "4 Weeks",
                        "Time Period End Date": "2026-04-19",
                        "Category": "REFRIGERATED EGGS",
                        "Subcategory": "RF EGGS LIQUID",
                        "Product Level": "UPC",
                        "Product Type": "RF LIQUID EGGS",
                        "Description": "Just Egg Plant Based Scramble 16 Oz",
                        "UPC": "01-91011-00127",
                        "Brand": "JUST",
                        "Dollars": 6248.0,
                        "# of Stores Selling": 44.0,
                        "Units per Store Selling": 20.4,
                        "Number of Weeks Selling": 4.0,
                        "ARP": 6.95,
                    },
                }
            )
        }
        materialized = list(
            builder.iter_spins_standard_item_slice_rows(
                Path("/tmp/SPINS PowerTabs Eat Just Breakfast Data Ending 04-19-26.xlsb"),
                "spins_breakfast_powertabs",
                "abc123def456",
                "2026-05-03T00:00:00Z",
                "2026-05-03T01:00:00Z",
                [pivot_row],
            )
        )

        self.assertEqual(len(materialized), 1)
        self.assertEqual(materialized[0]["source_table"], "spins_item_ranking_rows")
        row = json.loads(materialized[0]["row_json"])
        fields = row["fields"]
        self.assertTrue(fields["SPINS Standard Item Slice"])
        self.assertTrue(fields["SPINS Standard L4W Slice"])
        self.assertEqual(fields["Channel"], "NATURAL")
        self.assertEqual(fields["Weekly u/s/w"], 5.1)
        self.assertEqual(fields["velocity_units_per_store_per_week"], 5.1)
        self.assertEqual(fields["Average Weekly Dollars Per Store Selling Per Item"], 35.5)
        self.assertEqual(fields["velocity_dollars_per_store_per_week"], 35.5)
        self.assertEqual(fields["just_sku_family"], "just_egg_pourable_scramble")
        provenance = json.loads(materialized[0]["provenance_grain"])
        self.assertEqual(
            provenance["grain_type"],
            "workbook/xlsb/standard-item-slice/pivot-cache-record/field",
        )
        self.assertIn("#pivotCache=7&record=42", provenance["locator"])

    def test_standard_item_slice_materializes_all_supported_time_periods_and_retailers(self):
        pivot_rows = []
        for index, (period, geography) in enumerate(
            [
                ("4 Weeks", "KROGER BANNER TOTAL - RMA"),
                ("12 Weeks", "KROGER BANNER TOTAL - RMA"),
                ("24 Weeks", "PLUM MARKET - TOTAL US"),
                ("52 Weeks", "SPROUTS FARMERS MARKET - TOTAL US W/O PL"),
            ],
            start=1,
        ):
            pivot_rows.append(
                {
                    "row_json": json.dumps(
                        {
                            "pivot_cache": 7,
                            "record_index": index,
                            "fields": {
                                "Channel": "MULO" if "KROGER" in geography else "NATURAL",
                                "Geography": geography,
                                "Time Period": period,
                                "Time Period End Date": "2026-04-19",
                                "Category": "FROZEN APPETIZERS & SNACKS",
                                "Subcategory": "FZ BURRITOS & POCKETS",
                                "Product Level": "UPC",
                                "Description": "Just Breakfast Skillet Burrito 5.5 Oz",
                                "UPC": "01-91011-00149",
                                "Brand": "JUST",
                                "Dollars": 599.0,
                                "# of Stores Selling": 25.0,
                                "Units per Store Selling": 10.4,
                                "Number of Weeks Selling": 4.0,
                                "ARP": 5.99,
                            },
                        }
                    )
                }
            )

        materialized = list(
            builder.iter_spins_standard_item_slice_rows(
                Path("/tmp/SPINS PowerTabs Eat Just Breakfast Data Ending 04-19-26.xlsb"),
                "spins_breakfast_powertabs",
                "abc123def456",
                "2026-05-03T00:00:00Z",
                "2026-05-03T01:00:00Z",
                pivot_rows,
            )
        )

        fields_by_period = {
            json.loads(row["row_json"])["fields"]["Time Period"]: json.loads(row["row_json"])["fields"]
            for row in materialized
        }
        self.assertEqual(set(fields_by_period), {"4 Weeks", "12 Weeks", "24 Weeks", "52 Weeks"})
        self.assertEqual(fields_by_period["4 Weeks"]["Geography"], "KROGER BANNER TOTAL - RMA")
        self.assertEqual(fields_by_period["24 Weeks"]["Geography"], "PLUM MARKET - TOTAL US")
        self.assertEqual(fields_by_period["52 Weeks"]["Geography"], "SPROUTS FARMERS MARKET - TOTAL US W/O PL")
        self.assertTrue(fields_by_period["4 Weeks"]["SPINS Standard L4W Slice"])
        self.assertNotIn("SPINS Standard L4W Slice", fields_by_period["12 Weeks"])
        self.assertEqual(fields_by_period["52 Weeks"]["velocity_units_per_store_per_week"], 2.6)

    def test_item_coverage_gap_rows_require_every_channel_and_dollar_velocity(self):
        product = {
            "product_key": "just_egg_pourable_scramble_16oz",
            "source_id": "spins_breakfast_powertabs",
            "family": "just_egg_pourable_scramble",
            "label": "JUST Egg Plant Based Scramble 16 Oz",
            "upcs": ["01-91011-00127"],
        }
        path = Path("/tmp/SPINS PowerTabs Eat Just Breakfast Data Ending 04-19-26.xlsb")
        item_row = builder.make_spins_item_ranking_row(
            path=path,
            source_id="spins_breakfast_powertabs",
            file_digest="abc123def456",
            modified="2026-05-03T00:00:00Z",
            extracted_at="2026-05-03T01:00:00Z",
            row_index=17,
            fields={
                "Geography": "SPROUTS FARMERS MARKET - TOTAL US W/O PL",
                "Channel": "NATURAL",
                "Time Period": "4 Weeks",
                "Description": "Just Egg Plant Based Scramble 16 Oz",
                "UPC": "01-91011-00127",
                "Brand": "JUST",
                "Average Weekly Units Per Store Selling Per Item": 3.3,
            },
            locator="/tmp/source.xlsb#sheet=Item&row=17",
        )
        universe_row = builder.make_spins_item_ranking_row(
            path=path,
            source_id="spins_breakfast_powertabs",
            file_digest="abc123def456",
            modified="2026-05-03T00:00:00Z",
            extracted_at="2026-05-03T01:00:00Z",
            row_index=18,
            fields={
                "Geography": "SPROUTS FARMERS MARKET - TOTAL US W/O PL",
                "Channel": "MULO",
                "Time Period": "4 Weeks",
                "Description": "Competitor Liquid Eggs 16 Oz",
                "UPC": "00-00000-00000",
                "Brand": "COMPETITOR",
                "Average Weekly Units Per Store Selling Per Item": 1.0,
                "Average Weekly Dollars Per Store Selling Per Item": 4.0,
            },
            locator="/tmp/source.xlsb#sheet=Item&row=18",
        )

        with mock.patch.object(builder, "spins_goal_products_for_source", return_value=[product]):
            gaps = list(
                builder.iter_spins_item_coverage_gap_rows(
                    path,
                    "spins_breakfast_powertabs",
                    "abc123def456",
                    "2026-05-03T00:00:00Z",
                    "2026-05-03T01:00:00Z",
                    [item_row, universe_row],
                )
            )

        self.assertEqual(len(gaps), 8)
        payloads = [json.loads(row["row_json"])["fields"] for row in gaps]
        four_week_payloads = [payload for payload in payloads if payload["Time Period"] == "4 Weeks"]
        gap_types = {payload["Channel"]: payload["gap_type"] for payload in four_week_payloads}
        self.assertEqual(gap_types["NATURAL"], "missing_required_velocity_metric")
        self.assertEqual(gap_types["MULO"], "missing_spins_item_ranking_row")
        natural = next(payload for payload in four_week_payloads if payload["Channel"] == "NATURAL")
        self.assertEqual(natural["missing_fields"], ["velocity_dollars_per_store_per_week"])

    def test_goal_product_matching_does_not_treat_family_as_sku_match(self):
        product = {
            "product_key": "just_egg_burrito_skillet",
            "source_id": "spins_breakfast_powertabs",
            "family": "just_egg_burritos",
            "label": "Just Breakfast Skillet Burrito 5.5 Oz",
            "upcs": ["01-91011-00149"],
        }
        southwest_fields = {
            "just_sku_family": "just_egg_burritos",
            "just_sku_label": "Just Southwest Breakfast Burrito 5.5 Oz",
            "Description": "Just Southwest Breakfast Burrito 5.5 Oz",
            "UPC": "01-91011-00151",
        }
        skillet_fields = {
            "just_sku_family": "just_egg_burritos",
            "just_sku_label": "Just Breakfast Skillet Burrito 5.5 Oz",
            "Description": "Just Breakfast Skillet Burrito 5.5 Oz",
            "UPC": "01-91011-00149",
        }

        self.assertFalse(builder.spins_goal_product_matches_fields(southwest_fields, product))
        self.assertTrue(builder.spins_goal_product_matches_fields(skillet_fields, product))


if __name__ == "__main__":
    unittest.main()
