import sys
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
SCRIPTS = ROOT / "scripts"
if str(SCRIPTS) not in sys.path:
    sys.path.insert(0, str(SCRIPTS))

import compare_order_allocation_historical_day as compare


class CompareOrderAllocationHistoricalDayTest(unittest.TestCase):
    def test_inbound_pending_allocates_when_eta_plus_two_days_meets_customer_date(self):
        order = {
            "order_status": "Inbound Pending",
            "requested_delivery_date": "2026-04-20",
            "inbound_eta": "2026-04-18",
        }

        decision = compare.classify_order_decision(order)

        self.assertEqual(decision["decision"], "allocated")
        self.assertEqual(decision["rule"], "inbound_eta_plus_two_day_buffer")
        self.assertEqual(decision["buffered_ready_date"], "2026-04-20")

    def test_inbound_pending_blocks_when_eta_plus_two_days_misses_customer_date(self):
        order = {
            "order_status": "Inbound Pending",
            "requested_delivery_date": "2026-04-20",
            "inbound_eta": "2026-04-19",
        }

        decision = compare.classify_order_decision(order)

        self.assertEqual(decision["decision"], "blocked")
        self.assertEqual(decision["rule"], "inbound_eta_outside_required_range")
        self.assertEqual(decision["buffered_ready_date"], "2026-04-21")

    def test_inbound_pending_requires_eta_source_proof_when_eta_is_missing(self):
        order = {
            "order_status": "Inbound Pending",
            "requested_delivery_date": "2026-04-20",
        }

        decision = compare.classify_order_decision(order)

        self.assertEqual(decision["decision"], "needs_eta_proof")
        self.assertEqual(decision["rule"], "inbound_eta_required")


if __name__ == "__main__":
    unittest.main()
