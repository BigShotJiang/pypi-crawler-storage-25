import importlib.util
import json
import sys
import unittest
from pathlib import Path

import yaml


ROOT = Path(__file__).resolve().parents[1]
SOURCE_ID = "dot_foodservice_weekly_sales"


def load_builder():
    scripts_dir = ROOT / "scripts"
    if str(scripts_dir) not in sys.path:
        sys.path.insert(0, str(scripts_dir))
    spec = importlib.util.spec_from_file_location(
        "build_fresh_source_database",
        ROOT / "scripts" / "build_fresh_source_database.py",
    )
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


class DotFoodserviceSourceTest(unittest.TestCase):
    def test_dot_foodservice_lane_is_declared_queryable_and_typed(self):
        all_source_ids = json.loads((ROOT / "config/all-source-ids.json").read_text())
        queryable_source_ids = json.loads((ROOT / "config/queryable-source-ids.json").read_text())
        fresh_map = yaml.safe_load((ROOT / "config/fresh-source-map.yaml").read_text())
        fresh_sources = {source["id"]: source for source in fresh_map["sources"]}
        builder = load_builder()

        self.assertIn(SOURCE_ID, all_source_ids)
        self.assertIn(SOURCE_ID, queryable_source_ids)
        self.assertIn(SOURCE_ID, fresh_sources)
        self.assertIn(SOURCE_ID, builder.SOURCES)

        source = builder.SOURCES[SOURCE_ID]
        self.assertEqual(source["source_type"], "local_xlsx_workbook_snapshot")
        self.assertEqual(source["business_domain"], "foodservice_sales")
        self.assertEqual(source["parser"], SOURCE_ID)
        self.assertEqual(
            Path(source["boundary"][0]).name,
            "Shipment Tracker - Foodservice. (35).xlsx",
        )

        declared = fresh_sources[SOURCE_ID]["declared_boundary"]
        self.assertEqual(declared["type"], "local_xlsx_workbook_snapshot")
        self.assertEqual(declared["primary_sheet"], "Dot Week to Week")
        self.assertIn("DOT Foodservice", fresh_sources[SOURCE_ID]["human_annotations"]["canonical_use"])


if __name__ == "__main__":
    unittest.main()
