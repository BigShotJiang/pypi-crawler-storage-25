import os
import sqlite3
import sys
import unittest


ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
SCRIPTS = os.path.join(ROOT, "scripts")
if SCRIPTS not in sys.path:
    sys.path.insert(0, SCRIPTS)

import serve_http


class ServeHttpMultiSourceRoutingTests(unittest.TestCase):
    def make_conn(self, source_ids):
        conn = sqlite3.connect(":memory:")
        conn.row_factory = sqlite3.Row
        conn.execute("CREATE TABLE sources (source_id TEXT PRIMARY KEY, boundary_json TEXT)")
        for source_id in source_ids:
            conn.execute("INSERT INTO sources VALUES (?, ?)", (source_id, "[]"))
        return conn

    def test_scorecard_netsuite_reconciliation_keeps_both_lanes(self):
        conn = self.make_conn({"scorecard_monthly_data", "netsuite_pnl_monthly"})

        plan = serve_http.build_source_query_plan(
            conn,
            "Compare March 2026 Scorecard gross revenue with NetSuite Gross CPG sales. Include both source ids.",
        )

        self.assertEqual([step["source_id"] for step in plan], ["scorecard_monthly_data", "netsuite_pnl_monthly"])

    def test_appleton_production_plan_reconciliation_keeps_both_lanes(self):
        conn = self.make_conn({"appleton_jpc_factory_dashboard", "operations_production_plan_latest"})

        plan = serve_http.build_source_query_plan(
            conn,
            "Cross-check Appleton FactoryTalk current tag evidence with the latest production plan rows for Just Egg demand.",
        )

        self.assertEqual([step["source_id"] for step in plan], ["appleton_jpc_factory_dashboard", "operations_production_plan_latest"])
        self.assertEqual(plan[0].get("adapter_hint"), "appleton_jpc_current_tag")
        self.assertEqual(plan[1].get("adapter_hint"), "operations_production_plan")

    def test_asana_hr_reconciliation_keeps_both_lanes(self):
        conn = self.make_conn({"asana_work_management", "hr_just_food_company_headcount"})

        plan = serve_http.build_source_query_plan(
            conn,
            "Compare Asana task/blocker rows with HR contractor rows. Keep work-management separate from people roster evidence.",
        )

        self.assertEqual([step["source_id"] for step in plan], ["asana_work_management", "hr_just_food_company_headcount"])
        self.assertEqual(plan[0].get("adapter_hint"), "asana_task_lookup")
        self.assertEqual(plan[1].get("adapter_hint"), "just_people_roster")

    def test_tofutown_bom_cost_us_canada_reconciliation_keeps_three_lanes(self):
        conn = self.make_conn(
            {
                "tofutown_bom_tt_skus",
                "tofutown_standard_cost_gross_margin_by_sku_2026_05",
                "just_us_canada_p_and_l_boms",
            }
        )

        plan = serve_http.build_source_query_plan(
            conn,
            "Compare TofuTown Europe BOM ingredient rows, TofuTown Europe standard-cost rows, and Just US/Canada BOM or P&L rows for Just Egg.",
        )

        self.assertEqual(
            [step["source_id"] for step in plan],
            ["just_us_canada_p_and_l_boms", "tofutown_standard_cost_gross_margin_by_sku_2026_05", "tofutown_bom_tt_skus"],
        )
        self.assertEqual([step.get("adapter_hint") for step in plan], ["just_us_canada_bom_pnl", "tofutown_standard_cost_margin", "tofutown_bom"])


if __name__ == "__main__":
    unittest.main()
