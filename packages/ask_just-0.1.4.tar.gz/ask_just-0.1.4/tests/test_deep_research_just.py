import json
import os
import sys
import tempfile
import unittest
from pathlib import Path
from unittest import mock


ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
SCRIPTS = os.path.join(ROOT, "scripts")
if SCRIPTS not in sys.path:
    sys.path.insert(0, SCRIPTS)

import deep_research_just


def write_json(path, payload):
    path.write_text(json.dumps(payload), encoding="utf-8")


def source_row(source_id):
    return {
        "source_id": source_id,
        "mapped": "yes",
        "accessible": "yes",
        "atomically_queryable": "yes",
        "freshness_expectation": "daily",
        "query_plane": "hosted_sqlite",
        "layer": "test",
    }


class DeepResearchJustTest(unittest.TestCase):
    def make_lane_path(self, lanes):
        tmp = tempfile.TemporaryDirectory()
        self.addCleanup(tmp.cleanup)
        path = Path(tmp.name) / "queryable-source-ids.json"
        write_json(path, lanes)
        return path

    def stubbed_bundle(self, lanes, hosted_sources=None, file_counts=None, atomic_counts=None, samples=None):
        lane_path = self.make_lane_path(lanes)
        hosted_sources = hosted_sources or {lane: source_row(lane) for lane in lanes}
        file_counts = file_counts or {
            lane: {"source_id": lane, "source_file_count": 1, "parsed_source_file_count": 1} for lane in lanes
        }
        atomic_counts = atomic_counts or {lane: {"source_id": lane, "atomic_row_count": 2} for lane in lanes}
        samples = samples or {lane: [{"source_id": lane, "row_id": f"{lane}:1"}] for lane in lanes}

        with mock.patch.object(deep_research_just, "fetch_hosted_sources", return_value=hosted_sources), mock.patch.object(
            deep_research_just,
            "fetch_grouped_rows",
            side_effect=lambda table, _: file_counts if table == "source_files" else atomic_counts,
        ), mock.patch.object(deep_research_just, "fetch_sample_rows", return_value=samples):
            return deep_research_just.build_bundle(question="test", source_lane_path=lane_path)

    def test_bundle_covers_every_shared_verified_lane_from_generated_inventory(self):
        bundle = self.stubbed_bundle(["scorecard_monthly_data", "netsuite_pnl_monthly"])

        self.assertTrue(bundle["verification"]["ok"])
        self.assertEqual(bundle["source_lanes_covered"], ["netsuite_pnl_monthly", "scorecard_monthly_data"])
        self.assertEqual(sorted(bundle["evidence_by_lane"]), ["netsuite_pnl_monthly", "scorecard_monthly_data"])

    def test_declared_but_unhosted_lane_is_recorded_as_not_shared_verified(self):
        bundle = self.stubbed_bundle(
            ["scorecard_monthly_data", "netsuite_pnl_monthly"],
            hosted_sources={"scorecard_monthly_data": source_row("scorecard_monthly_data")},
        )

        self.assertTrue(bundle["verification"]["ok"])
        self.assertEqual(bundle["source_lanes_covered"], ["scorecard_monthly_data"])
        self.assertEqual(bundle["declared_lanes_not_hosted"], ["netsuite_pnl_monthly"])

    def test_bad_gate_or_missing_receipt_rows_blocks_prelaunch(self):
        bad_row = source_row("scorecard_monthly_data")
        bad_row["accessible"] = "no"
        bundle = self.stubbed_bundle(
            ["scorecard_monthly_data"],
            hosted_sources={"scorecard_monthly_data": bad_row},
            file_counts={"scorecard_monthly_data": {"source_id": "scorecard_monthly_data", "source_file_count": 0}},
        )

        self.assertFalse(bundle["verification"]["ok"])
        failures = bundle["verification"]["failures"][0]["failures"]
        self.assertIn("accessible='no', expected 'yes'", failures)
        self.assertIn("missing hosted source_files receipt rows", failures)

    def test_private_overlays_are_excluded_from_shared_lane_coverage(self):
        bundle = self.stubbed_bundle(
            ["scorecard_monthly_data", "personal_mail_overlay"],
            hosted_sources={"scorecard_monthly_data": source_row("scorecard_monthly_data")},
            file_counts={"scorecard_monthly_data": {"source_id": "scorecard_monthly_data", "source_file_count": 1, "parsed_source_file_count": 1}},
            atomic_counts={"scorecard_monthly_data": {"source_id": "scorecard_monthly_data", "atomic_row_count": 2}},
            samples={"scorecard_monthly_data": [{"source_id": "scorecard_monthly_data", "row_id": "r1"}]},
        )

        self.assertTrue(bundle["verification"]["ok"])
        self.assertEqual(bundle["source_lanes_covered"], ["scorecard_monthly_data"])
        self.assertEqual(bundle["excluded_private_overlays"], ["personal_mail_overlay"])

    def test_unexpected_shared_hosted_lane_blocks_manual_inventory_drift(self):
        bundle = self.stubbed_bundle(
            ["scorecard_monthly_data"],
            hosted_sources={
                "scorecard_monthly_data": source_row("scorecard_monthly_data"),
                "unlisted_shared_lane": source_row("unlisted_shared_lane"),
            },
        )

        self.assertFalse(bundle["verification"]["ok"])
        self.assertEqual(bundle["verification"]["failures"][-1]["source_id"], "__hosted_inventory__")


if __name__ == "__main__":
    unittest.main()
