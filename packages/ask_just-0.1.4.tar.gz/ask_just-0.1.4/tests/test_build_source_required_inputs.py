import json
import os
import sys
import tempfile
import unittest
from pathlib import Path
from unittest import mock


ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
SCRIPTS = os.path.join(ROOT, "scripts")
if SCRIPTS not in sys.path:
    sys.path.insert(0, SCRIPTS)

import build_source_required_inputs


class BuildSourceRequiredInputsTest(unittest.TestCase):
    def test_completion_gate_uses_generated_source_count(self):
        with tempfile.TemporaryDirectory() as tmp:
            with mock.patch.object(
                build_source_required_inputs,
                "DEFAULT_VM_REFRESH_STATUS",
                Path(tmp) / "missing-vm-refresh.json",
            ):
                payload = build_source_required_inputs.build_payload(
                    {
                        "source_count": 2,
                        "fully_source_count": 1,
                        "partial_count": 1,
                        "not_sourced_count": 0,
                        "not_fully_source_count": 1,
                        "rows": [
                            {"source_id": "done", "status": "fully_source", "explicit_gaps": ["none"]},
                            {
                                "source_id": "blocked",
                                "status": "partial",
                                "missing_evidence": ["no_declared_gaps_for_full_source_claim"],
                                "explicit_gaps": ["needs export"],
                            },
                        ],
                    }
                )

        self.assertEqual(payload["completion_gate"]["required_fully_source_count"], 2)
        self.assertEqual(len(payload["required_inputs"]), 1)

        required_md = build_source_required_inputs.build_markdown(payload)
        access_md = build_source_required_inputs.build_access_request_markdown(payload)

        self.assertIn("fully_source_count = 2", required_md)
        self.assertNotIn("fully_source_count = 41", required_md)
        self.assertIn("blocked at 1 of 2", access_md)
        self.assertIn("needs export", access_md)

    def test_includes_failed_vm_refresh_runtime_input(self):
        with tempfile.TemporaryDirectory() as tmp:
            vm_refresh = Path(tmp) / "vm-refresh.json"
            vm_refresh.write_text(
                json.dumps(
                    {
                        "ok": False,
                        "service": {"active_state": "failed", "result": "exit-code"},
                        "gaps": ["missing MS_GRAPH_CLIENT_SECRET"],
                    }
                ),
                encoding="utf-8",
            )
            with mock.patch.object(
                build_source_required_inputs,
                "DEFAULT_VM_REFRESH_STATUS",
                vm_refresh,
            ):
                payload = build_source_required_inputs.build_payload(
                    {
                        "source_count": 1,
                        "fully_source_count": 1,
                        "partial_count": 0,
                        "not_sourced_count": 0,
                        "not_fully_source_count": 0,
                        "rows": [
                            {"source_id": "done", "status": "fully_source", "explicit_gaps": ["none"]},
                        ],
                    }
                )

        runtime_ids = {row["id"] for row in payload["runtime_required_inputs"]}
        self.assertIn("vm_source_refresh_status", runtime_ids)
        required_md = build_source_required_inputs.build_markdown(payload)
        access_md = build_source_required_inputs.build_access_request_markdown(payload)
        self.assertIn("Required Runtime Inputs", required_md)
        self.assertIn("complete successful Ask Just VM source-refresh service run", access_md)
        self.assertIn("Microsoft Graph credentials have been installed", access_md)
        self.assertIn("/etc/ask-just/source-refresh.env", access_md)
        self.assertIn("missing MS_GRAPH_CLIENT_SECRET", access_md)

    def test_current_unfinished_lanes_have_specific_input_requests(self):
        strict_table = build_source_required_inputs.load_json(
            build_source_required_inputs.DEFAULT_STRICT_TABLE
        )
        payload = build_source_required_inputs.build_payload(strict_table)
        unfinished = {
            row["source_id"]
            for row in strict_table["rows"]
            if row.get("status") != "fully_source"
        }
        requested = {row["source_id"]: row for row in payload["required_inputs"]}

        self.assertEqual(unfinished, set(requested))
        for source_id in unfinished:
            self.assertIn(source_id, build_source_required_inputs.REQUIRED_INPUTS)
            self.assertNotIn(
                "Close the explicit gaps",
                requested[source_id]["required_input"],
            )


if __name__ == "__main__":
    unittest.main()
