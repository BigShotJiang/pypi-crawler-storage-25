import os
import sqlite3
import sys
import unittest


ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
SCRIPTS = os.path.join(ROOT, "scripts")
if SCRIPTS not in sys.path:
    sys.path.insert(0, SCRIPTS)

import serve_http


class ServeHttpExplicitTofuTownSourceRoutingTests(unittest.TestCase):
    def test_explicit_tofutown_standard_cost_source_keeps_adapter_hint(self):
        conn = sqlite3.connect(":memory:")
        conn.row_factory = sqlite3.Row
        conn.execute("CREATE TABLE sources (source_id TEXT PRIMARY KEY)")
        conn.execute("INSERT INTO sources VALUES ('tofutown_standard_cost_gross_margin_by_sku_2026_05')")

        plan = serve_http.build_source_query_plan(
            conn,
            "For TofuTown Europe, what standard cost or gross margin rows are visible? Return source id and row provenance.",
            requested_source="tofutown_standard_cost_gross_margin_by_sku_2026_05",
        )

        self.assertEqual(len(plan), 1)
        self.assertEqual(plan[0]["source_id"], "tofutown_standard_cost_gross_margin_by_sku_2026_05")
        self.assertEqual(plan[0]["adapter_hint"], "tofutown_standard_cost_margin")


if __name__ == "__main__":
    unittest.main()
