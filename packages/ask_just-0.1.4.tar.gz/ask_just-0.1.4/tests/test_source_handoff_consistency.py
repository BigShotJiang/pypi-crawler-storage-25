import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


class SourceHandoffConsistencyTest(unittest.TestCase):
    def test_source_map_points_to_existing_just_source_skill(self):
        text = (ROOT / "config" / "source-map.yaml").read_text(encoding="utf-8")
        source_skill = None
        for line in text.splitlines():
            if line.strip().startswith("source_skill:"):
                source_skill = line.split(":", 1)[1].strip()
                break

        self.assertEqual(source_skill, "skills/just-source/SKILL.md")
        self.assertTrue((ROOT / source_skill).exists())

    def test_primary_handoff_docs_do_not_claim_old_11_source_plane(self):
        banned_phrases = [
            "11 mapped source",
            "11/11 sources",
            "exactly 11 active",
            "active 11-source",
            "fresh 11-source plane",
            "11-source SQLite plane",
            "291,162 atomic rows",
        ]
        paths = [
            ROOT / "README.md",
            ROOT / "SPEC.md",
            ROOT / "docs" / "ask-monarch-flow-map.md",
            ROOT / "docs" / "full-source-completion-frontier.md",
            ROOT / "docs" / "source-receipts" / "completion-audit.md",
            ROOT / "skills" / "askjust" / "SKILL.md",
            ROOT / "skills" / "just-source" / "SKILL.md",
        ]
        for path in paths:
            text = path.read_text(encoding="utf-8")
            for phrase in banned_phrases:
                self.assertNotIn(phrase, text, f"{phrase!r} found in {path.relative_to(ROOT)}")

    def test_source_refresh_env_template_matches_systemd_unit(self):
        service = (ROOT / "deploy" / "systemd" / "ask-just-source-refresh.service").read_text(
            encoding="utf-8"
        )
        template = (ROOT / "deploy" / "systemd" / "source-refresh.env.example").read_text(
            encoding="utf-8"
        )
        readme = (ROOT / "README.md").read_text(encoding="utf-8")

        self.assertIn("EnvironmentFile=-/etc/ask-just/source-refresh.env", service)
        self.assertIn("/etc/ask-just/source-refresh.env", template)
        self.assertIn("/etc/ask-just/source-refresh.env", readme)
        for name in (
            "MS_TENANT_ID",
            "MS_GRAPH_CLIENT_ID",
            "MS_GRAPH_CLIENT_SECRET",
            "GRAPH_TENANT_ID",
            "GRAPH_CLIENT_ID",
            "GRAPH_REFRESH_TOKEN",
        ):
            self.assertIn(name, template)
            self.assertIn(name, readme)


if __name__ == "__main__":
    unittest.main()
