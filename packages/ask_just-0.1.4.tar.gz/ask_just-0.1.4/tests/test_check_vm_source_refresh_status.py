import os
import sys
import unittest


ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
SCRIPTS = os.path.join(ROOT, "scripts")
if SCRIPTS not in sys.path:
    sys.path.insert(0, SCRIPTS)

import check_vm_source_refresh_status


class CheckVmSourceRefreshStatusTest(unittest.TestCase):
    def test_failed_service_and_graph_credential_gap(self):
        raw = """__SYSTEMCTL_SHOW__
ActiveState=failed
SubState=failed
Result=exit-code
ExecMainStatus=1
__JOURNAL__
RuntimeError: Just Meat Production library requires Microsoft Graph client credentials; missing MS_TENANT_ID, MS_GRAPH_CLIENT_ID, MS_GRAPH_CLIENT_SECRET
__SQLITE_COUNTS__
{"exists": true, "sources": 41, "source_files": 1, "atomic_rows": 2, "atomic_rows_fts": 2}
"""
        payload = check_vm_source_refresh_status.build_status(
            raw,
            local_counts={"exists": True, "sources": 41, "source_files": 1, "atomic_rows": 2, "atomic_rows_fts": 2},
            checked_at="2026-05-04T00:00:00Z",
        )

        self.assertFalse(payload["ok"])
        self.assertIn("Microsoft Graph credentials are missing", "\n".join(payload["gaps"]))

    def test_success_with_matching_counts_has_no_warnings(self):
        raw = """__SYSTEMCTL_SHOW__
ActiveState=inactive
SubState=dead
Result=success
ExecMainStatus=0
__JOURNAL__
completed
__SQLITE_COUNTS__
{"exists": true, "sources": 41, "source_files": 10, "atomic_rows": 20, "atomic_rows_fts": 20}
"""
        payload = check_vm_source_refresh_status.build_status(
            raw,
            local_counts={"exists": True, "sources": 41, "source_files": 10, "atomic_rows": 20, "atomic_rows_fts": 20},
            checked_at="2026-05-04T00:00:00Z",
        )

        self.assertTrue(payload["ok"])
        self.assertEqual(payload["gaps"], ["none"])
        self.assertEqual(payload["warnings"], ["none"])

    def test_successful_service_records_count_drift_as_warning(self):
        raw = """__SYSTEMCTL_SHOW__
ActiveState=inactive
SubState=dead
Result=success
ExecMainStatus=0
__JOURNAL__
completed
__SQLITE_COUNTS__
{"exists": true, "sources": 41, "source_files": 9, "atomic_rows": 20, "atomic_rows_fts": 20}
"""
        payload = check_vm_source_refresh_status.build_status(
            raw,
            local_counts={"exists": True, "sources": 41, "source_files": 10, "atomic_rows": 20, "atomic_rows_fts": 20},
            checked_at="2026-05-04T00:00:00Z",
        )

        self.assertTrue(payload["ok"])
        self.assertEqual(payload["gaps"], ["none"])
        self.assertIn("source_files=9", "\n".join(payload["warnings"]))

    def test_source_count_drift_is_a_warning(self):
        raw = """__SYSTEMCTL_SHOW__
ActiveState=inactive
SubState=dead
Result=success
ExecMainStatus=0
__JOURNAL__
completed
__SQLITE_COUNTS__
{"exists": true, "sources": 40, "source_files": 10, "atomic_rows": 20, "atomic_rows_fts": 20}
"""
        payload = check_vm_source_refresh_status.build_status(
            raw,
            local_counts={"exists": True, "sources": 41, "source_files": 10, "atomic_rows": 20, "atomic_rows_fts": 20},
            checked_at="2026-05-04T00:00:00Z",
        )

        self.assertTrue(payload["ok"])
        self.assertEqual(payload["gaps"], ["none"])
        self.assertIn("sources=40", "\n".join(payload["warnings"]))

    def test_graph_gap_suppresses_stale_pyxlsb_journal_line(self):
        raw = """__SYSTEMCTL_SHOW__
ActiveState=failed
SubState=failed
Result=exit-code
ExecMainStatus=1
__JOURNAL__
ModuleNotFoundError: No module named 'pyxlsb'
RuntimeError: Just Meat Production library requires Microsoft Graph client credentials; missing MS_TENANT_ID, MS_GRAPH_CLIENT_ID, MS_GRAPH_CLIENT_SECRET
__SQLITE_COUNTS__
{"exists": true, "sources": 41, "source_files": 10, "atomic_rows": 20, "atomic_rows_fts": 20}
"""
        payload = check_vm_source_refresh_status.build_status(
            raw,
            local_counts={"exists": True, "sources": 41, "source_files": 10, "atomic_rows": 20, "atomic_rows_fts": 20},
            checked_at="2026-05-04T00:00:00Z",
        )

        gap_text = "\n".join(payload["gaps"])
        self.assertIn("Microsoft Graph credentials are missing", gap_text)
        self.assertNotIn("pyxlsb is missing", gap_text)


if __name__ == "__main__":
    unittest.main()
