import os
import sys
import unittest


ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
SCRIPTS = os.path.join(ROOT, "scripts")
if SCRIPTS not in sys.path:
    sys.path.insert(0, SCRIPTS)

import run_cross_source_pressure as pressure


def case(source_id, question, token):
    return {
        "id": f"{source_id}_{token}",
        "question": question,
        "expected_source": source_id,
        "expected_answer": {"value": token},
        "expected_tokens": [token],
        "reference_row": {"source_id": source_id, "row_key": token},
    }


class CrossSourcePressureTests(unittest.TestCase):
    def test_build_hard_cases_uses_business_family_pairs(self):
        base_cases = [
            case("scorecard_monthly_data", "What was gross revenue in Mar '26?", "gross_revenue"),
            case("netsuite_pnl_monthly", "What was NetSuite 41005 in Mar '26?", "41005"),
        ]

        cases = pressure.build_hard_cross_source_cases(base_cases, 1)

        self.assertEqual(len(cases), 1)
        self.assertEqual(cases[0]["family"], "scorecard_kpi_vs_netsuite_reconciliation")
        self.assertEqual(cases[0]["expected_sources"], ["scorecard_monthly_data", "netsuite_pnl_monthly"])
        self.assertEqual(len(cases[0]["lane_checks"]), 2)
        self.assertIn("source provenance", cases[0]["question"])

    def test_marks_all_miss_when_lane_checks_pass_but_broad_fails(self):
        case_payload = {
            "id": "case",
            "question": "Answer both",
            "expected_sources": ["scorecard_monthly_data", "netsuite_pnl_monthly"],
            "expected_tokens": ["gross_revenue", "41005"],
            "lane_checks": [
                {"source_id": "scorecard_monthly_data", "question": "scorecard", "expected_tokens": ["gross_revenue"]},
                {"source_id": "netsuite_pnl_monthly", "question": "netsuite", "expected_tokens": ["41005"]},
            ],
        }
        calls = iter(
            [
                ({"ok": True, "source": "all", "rows": []}, 100, "", ""),
                (
                    {
                        "ok": True,
                        "source": "scorecard_monthly_data",
                        "rows": [{"source_id": "scorecard_monthly_data", "snippet": "gross_revenue", "provenance_grain": "{}"}],
                    },
                    100,
                    "",
                    "",
                ),
                (
                    {
                        "ok": True,
                        "source": "netsuite_pnl_monthly",
                        "rows": [{"source_id": "netsuite_pnl_monthly", "snippet": "41005", "provenance_grain": "{}"}],
                    },
                    100,
                    "",
                    "",
                ),
            ]
        )
        original = pressure.simulator.run_cli
        pressure.simulator.run_cli = lambda *args, **kwargs: next(calls)
        self.addCleanup(lambda: setattr(pressure.simulator, "run_cli", original))

        result = pressure.run_pressure_case(case_payload, kind="atomic", limit=5, timeout=5)

        self.assertTrue(result["source_specific_answerable"])
        self.assertTrue(result["all_missed_answerable_lane"])
        self.assertIn("all_missed_source_specific_answerable", result["failure_types"])


if __name__ == "__main__":
    unittest.main()
