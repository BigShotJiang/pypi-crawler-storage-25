import json
import os
import sqlite3
import sys
import tempfile
import threading
import unittest
from http.server import ThreadingHTTPServer
from urllib.parse import urlencode
from urllib.request import urlopen


ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
SCRIPTS = os.path.join(ROOT, "scripts")
if SCRIPTS not in sys.path:
    sys.path.insert(0, SCRIPTS)


import serve_http


class DirectBypassRoutingTests(unittest.TestCase):
    def make_service(self):
        tmp = tempfile.TemporaryDirectory()
        self.addCleanup(tmp.cleanup)
        db_path = os.path.join(tmp.name, "source_index.sqlite")
        status_path = os.path.join(tmp.name, "source_status.json")
        conn = sqlite3.connect(db_path)
        conn.execute(
            """
            CREATE TABLE sources (
              source_id TEXT PRIMARY KEY,
              boundary_json TEXT
            )
            """
        )
        conn.execute(
            """
            CREATE TABLE source_files (
              source_id TEXT NOT NULL,
              path TEXT NOT NULL,
              sha256 TEXT,
              modified_at TEXT,
              parsed TEXT,
              provenance_grain TEXT
            )
            """
        )
        conn.execute(
            """
            CREATE VIRTUAL TABLE atomic_rows_fts USING fts5(
              source_id,
              source_table,
              source_file,
              sheet,
              search_text,
              provenance_grain UNINDEXED
            )
            """
        )
        conn.execute(
            """
            CREATE TABLE atomic_rows (
              row_id TEXT PRIMARY KEY,
              source_id TEXT NOT NULL,
              source_table TEXT NOT NULL,
              source_file TEXT NOT NULL,
              sheet TEXT,
              row_index INTEGER,
              row_key TEXT NOT NULL,
              row_json TEXT NOT NULL,
              search_text TEXT NOT NULL,
              provenance_grain TEXT NOT NULL
            )
            """
        )
        conn.execute(
            "INSERT INTO sources VALUES (?, ?)",
            ("just_public_website_homepage", "[]"),
        )
        conn.execute(
            "INSERT INTO source_files VALUES (?, ?, ?, ?, ?, ?)",
            (
                "just_public_website_homepage",
                "homepage",
                "sha",
                "2026-05-08T00:00:00Z",
                "true",
                "{}",
            ),
        )
        conn.execute(
            "INSERT INTO atomic_rows_fts VALUES (?, ?, ?, ?, ?, ?)",
            (
                "just_public_website_homepage",
                "html_text",
                "homepage",
                "",
                "mission plants eggs",
                "{}",
            ),
        )
        conn.execute(
            "INSERT INTO atomic_rows VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
            (
                "r1",
                "just_public_website_homepage",
                "html_text",
                "homepage",
                "",
                1,
                "r1",
                "{}",
                "mission plants eggs",
                "{}",
            ),
        )
        conn.commit()
        conn.close()
        return serve_http.AskJustService(db_path, status_path)

    def test_text_search_bypass_is_marked(self):
        service = self.make_service()

        payload = service.text_search("mission", source="just_public_website_homepage", kind="atomic", limit=5)

        self.assertTrue(payload["ok"])
        self.assertEqual(len(payload["rows"]), 1)
        self.assertTrue(payload["routing_decision"]["bypass"])
        self.assertEqual(payload["routing_decision"]["route_shape"], "prose")
        self.assertEqual(payload["routing_decision"]["adapter"], "direct_text_search_bypass")
        self.assertEqual(payload["routing_decision"]["selected_source_lane"], "just_public_website_homepage")
        self.assertEqual(payload["routing_decision"]["fallback_policy"], "bypass")

    def test_sql_bypass_is_marked(self):
        service = self.make_service()

        payload = service.sql("select source_id from sources", limit=5)

        self.assertTrue(payload["ok"])
        self.assertTrue(payload["routing_decision"]["bypass"])
        self.assertEqual(payload["routing_decision"]["route_shape"], "structured")
        self.assertEqual(payload["routing_decision"]["adapter"], "direct_sql_bypass")
        self.assertEqual(payload["routing_decision"]["selected_source_lane"], "sql")
        self.assertEqual(payload["routing_decision"]["fallback_policy"], "bypass")

    def test_search_endpoint_uses_direct_text_search_bypass(self):
        class DispatchService:
            def __init__(self):
                self.calls = []

            def search(self, *args, **kwargs):
                self.calls.append(("search", args, kwargs))
                return {
                    "ok": True,
                    "rows": [],
                    "routing_decision": {
                        "route_shape": "prose",
                        "adapter": "broad_fts",
                        "selected_source_lane": "all",
                        "fallback_policy": "source_specific_only",
                    },
                }

            def text_search(self, *args, **kwargs):
                self.calls.append(("text_search", args, kwargs))
                return {
                    "ok": True,
                    "rows": [],
                    "routing_decision": {
                        "route_shape": "prose",
                        "adapter": "direct_text_search_bypass",
                        "selected_source_lane": "just_public_website_homepage",
                        "fallback_policy": "bypass",
                        "bypass": True,
                    },
                }

            def health(self, deep=False):
                return {"ok": True, "health": {"source_count": 1}}

        service = DispatchService()
        handler = serve_http.make_handler(service, token="")
        server = ThreadingHTTPServer(("127.0.0.1", 0), handler)
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        self.addCleanup(server.server_close)
        self.addCleanup(server.shutdown)
        base_url = f"http://127.0.0.1:{server.server_address[1]}"
        query = urlencode(
            {
                "q": "mission",
                "source": "just_public_website_homepage",
                "kind": "atomic",
                "limit": "5",
            }
        )

        with urlopen(f"{base_url}/search?{query}", timeout=5) as response:
            payload = json.loads(response.read().decode("utf-8"))

        self.assertTrue(payload["routing_decision"]["bypass"])
        self.assertEqual(payload["routing_decision"]["adapter"], "direct_text_search_bypass")
        self.assertEqual([call[0] for call in service.calls], ["text_search"])


if __name__ == "__main__":
    unittest.main()
