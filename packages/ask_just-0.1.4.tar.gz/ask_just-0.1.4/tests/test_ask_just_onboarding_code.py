import contextlib
import io
import json
import os
import sys
import tempfile
import types
import unittest
from unittest import mock


ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
SCRIPTS = os.path.join(ROOT, "scripts")
if SCRIPTS not in sys.path:
    sys.path.insert(0, SCRIPTS)

import ask_just


class AskJustOnboardingCodeTest(unittest.TestCase):
    def make_config_path(self):
        tmp = tempfile.TemporaryDirectory()
        self.addCleanup(tmp.cleanup)
        return os.path.join(tmp.name, ".config", "ask-just", "config.json")

    def test_create_posts_admin_request_and_prints_code(self):
        calls = []

        def fake_request_json(url, token=None, method="GET", payload=None):
            calls.append({"url": url, "token": token, "method": method, "payload": payload})
            return {"ok": True, "code": "JST-ABCD-1234", "email": "maya@example.com"}

        args = types.SimpleNamespace(
            url="https://ask-just.example",
            token="admin-token",
            email="",
            label="Pri setup",
            ttl_hours=24,
        )
        buffer = io.StringIO()
        with mock.patch.object(ask_just, "request_json", side_effect=fake_request_json), contextlib.redirect_stdout(buffer):
            code = ask_just.onboarding_code_create(args)

        self.assertEqual(code, 0)
        payload = json.loads(buffer.getvalue())
        self.assertEqual(payload["code"], "JST-ABCD-1234")
        self.assertEqual(calls[0]["method"], "POST")
        self.assertEqual(calls[0]["url"], "https://ask-just.example/onboarding-codes")
        self.assertEqual(calls[0]["token"], "admin-token")
        self.assertEqual(calls[0]["payload"]["email"], "")
        self.assertEqual(calls[0]["payload"]["label"], "Pri setup")
        self.assertEqual(calls[0]["payload"]["reusable"], True)

    def test_exchange_saves_returned_token_without_printing_it(self):
        config_path = self.make_config_path()

        def fake_request_json(url, token=None, method="GET", payload=None):
            return {"ok": True, "token": "new-secret-token", "email": "maya@example.com"}

        args = types.SimpleNamespace(
            url="https://ask-just.example",
            token=None,
            code="JST-ABCD-1234",
            no_configure=False,
        )
        buffer = io.StringIO()
        with mock.patch.object(ask_just, "CONFIG_PATH", config_path), mock.patch.object(
            ask_just, "request_json", side_effect=fake_request_json
        ), contextlib.redirect_stdout(buffer):
            code = ask_just.onboarding_code_exchange(args)

        self.assertEqual(code, 0)
        raw = buffer.getvalue()
        self.assertNotIn("new-secret-token", raw)
        payload = json.loads(raw)
        self.assertTrue(payload["configured"])
        with open(config_path, encoding="utf-8") as handle:
            saved = json.load(handle)
        self.assertEqual(saved["token"], "new-secret-token")
        self.assertEqual(saved["url"], "https://ask-just.example")


if __name__ == "__main__":
    unittest.main()
