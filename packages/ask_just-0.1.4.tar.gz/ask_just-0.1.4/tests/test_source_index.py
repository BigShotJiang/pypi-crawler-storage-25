import os
import sys
import unittest


ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
SCRIPTS = os.path.join(ROOT, "scripts")
if SCRIPTS not in sys.path:
    sys.path.insert(0, SCRIPTS)

import source_index


class SourceIndexFtsQueryTest(unittest.TestCase):
    def test_fts_query_removes_natural_language_fillers(self):
        query = source_index.fts_query(
            "What is Just Egg velocity at Kroger Banner Total during the last 4 weeks?"
        )

        self.assertEqual(query, "Just* AND Egg* AND Kroger* AND Banner* AND Total* AND 4*")

    def test_fts_query_keeps_original_terms_when_only_stopwords(self):
        query = source_index.fts_query("what is the velocity")

        self.assertEqual(query, "what* AND is* AND the* AND velocity*")


if __name__ == "__main__":
    unittest.main()
