import json
import os
import sqlite3
import sys
import unittest


ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
SCRIPTS = os.path.join(ROOT, "scripts")
if SCRIPTS not in sys.path:
    sys.path.insert(0, SCRIPTS)

import serve_http


class ServeHttpBatchReleasePhTests(unittest.TestCase):
    def test_certification_words_do_not_become_product_filters(self):
        self.assertEqual(
            serve_http._batch_release_product_filter_terms(
                "Use the structured adapter if available: No web, no memory: From Ask Just terminal evidence, what batch release product pH rows are visible? If the lane is missing, say source gap. Keep Scorecard and NetSuite separate. Do not use SPINS. Return the rows that justify the answer."
            ),
            [],
        )

    def test_batch_status_comparison_words_do_not_become_product_filters(self):
        self.assertEqual(
            serve_http._batch_release_product_filter_terms(
                "Compare and reconcile from mapped rows: compare batch release pH evidence with batch release QA status evidence. Return status and product-test rows from the batch release app."
            ),
            [],
        )

    def make_product_tests_conn(self):
        conn = sqlite3.connect(":memory:")
        conn.row_factory = sqlite3.Row
        conn.executescript(
            """
            CREATE TABLE sources (source_id TEXT PRIMARY KEY, boundary_json TEXT);
            CREATE TABLE source_files (source_id TEXT, path TEXT, sha256 TEXT, modified_at TEXT, parsed TEXT, provenance_grain TEXT);
            CREATE TABLE atomic_rows (
                source_id TEXT,
                source_table TEXT,
                source_file TEXT,
                row_json TEXT,
                provenance_grain TEXT,
                row_key TEXT,
                row_index INTEGER
            );
            """
        )
        conn.execute("INSERT INTO sources VALUES (?, ?)", ("batch_release_app", "[]"))
        conn.execute(
            "INSERT INTO source_files VALUES (?, ?, ?, ?, ?, ?)",
            ("batch_release_app", "batch-release://product-tests", "abc", "now", "yes", "{}"),
        )
        return conn

    def test_acidity_product_test_metric_rows_return_source_rows(self):
        conn = self.make_product_tests_conn()
        conn.execute(
            "INSERT INTO atomic_rows VALUES (?, ?, ?, ?, ?, ?, ?)",
            (
                "batch_release_app",
                "batch_release_product_tests_fields",
                "batch-release://product-tests",
                json.dumps({"field": "acidity.avg", "value": 1.23}),
                json.dumps({"source_id": "batch_release_app", "locator": "batch-release://product-tests#acidity.avg"}),
                "batch_release:product_tests:batch_1:acidity.avg",
                1,
            ),
        )

        rows = serve_http._batch_release_product_test_metric_rows(conn, "acidity", 5)

        self.assertEqual(len(rows), 1)
        self.assertEqual(rows[0]["source_id"], "batch_release_app")
        self.assertIn("acidity", rows[0]["snippet"])

    def test_batch_release_product_tests_do_not_plan_qualification_fallbacks(self):
        conn = sqlite3.connect(":memory:")
        conn.row_factory = sqlite3.Row
        conn.execute("CREATE TABLE sources (source_id TEXT PRIMARY KEY, boundary_json TEXT)")
        conn.execute("INSERT INTO sources VALUES (?, ?)", ("batch_release_app", "[]"))
        conn.execute("INSERT INTO sources VALUES (?, ?)", ("qualification_meat_sensory", "[]"))

        plan = serve_http.build_source_query_plan(
            conn,
            "What batch release product pH rows are visible? Keep Scorecard and NetSuite separate.",
        )

        self.assertEqual([step["source_id"] for step in plan], ["batch_release_app"])

    def test_same_source_batch_ph_acidity_status_plans_three_adapters(self):
        conn = sqlite3.connect(":memory:")
        conn.row_factory = sqlite3.Row
        conn.execute("CREATE TABLE sources (source_id TEXT PRIMARY KEY, boundary_json TEXT)")
        conn.execute("INSERT INTO sources VALUES (?, ?)", ("batch_release_app", "[]"))

        plan = serve_http.build_source_query_plan(
            conn,
            "Adversarial check: within batch release, return product pH aggregate rows, acidity product-test rows, and QA status rows. Use batch_release_app only.",
        )

        self.assertEqual([step["source_id"] for step in plan], ["batch_release_app", "batch_release_app", "batch_release_app"])
        self.assertEqual(
            [step.get("adapter_hint") for step in plan],
            ["batch_release_product_ph", "batch_release_product_test_metric", "batch_release_batch_status"],
        )
        for question in (
            "Adversarial check: within batch release, return product pH aggregate rows, acidity product-test rows, and QA status rows. Use batch_release_app only.",
            "Do not collapse lanes: within batch release, return product pH aggregate rows, acidity product-test rows, and QA status rows. Use batch_release_app only.",
            "Use source contract strictly: within batch release, return product pH aggregate rows, acidity product-test rows, and QA status rows. Use batch_release_app only.",
            "Return atomic evidence from every lane: within batch release, return product pH aggregate rows, acidity product-test rows, and QA status rows. Use batch_release_app only.",
            "No broad substitution: within batch release, return product pH aggregate rows, acidity product-test rows, and QA status rows. Use batch_release_app only.",
        ):
            self.assertEqual(serve_http._batch_release_product_filter_terms(question), [])

    def test_generic_ph_question_uses_fast_aggregate(self):
        conn = self.make_product_tests_conn()
        for index, value in enumerate((6.0, 6.4), start=1):
            conn.execute(
                "INSERT INTO atomic_rows VALUES (?, ?, ?, ?, ?, ?, ?)",
                (
                    "batch_release_app",
                    "batch_release_product_tests_fields",
                    "batch-release://product-tests",
                    json.dumps({"field": "pH", "value": value}),
                    json.dumps({"source_id": "batch_release_app", "locator": f"batch-release://product-tests#batch_{index}:pH"}),
                    f"batch_release:product_tests:batch_{index}:pH",
                    index,
                ),
            )

        rows = serve_http._batch_release_ph_aggregate_rows(conn, "What batch release product pH rows are visible?", 5)

        self.assertEqual(len(rows), 1)
        self.assertIn("average_ph", rows[0]["snippet"])
        self.assertIn("6.2", rows[0]["snippet"])


if __name__ == "__main__":
    unittest.main()
