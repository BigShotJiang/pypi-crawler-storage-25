import json
import os
import sqlite3
import sys
import unittest
from unittest import mock


ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
SCRIPTS = os.path.join(ROOT, "scripts")
if SCRIPTS not in sys.path:
    sys.path.insert(0, SCRIPTS)

import build_fresh_source_database as builder


class NetSuiteRevenueSourcesTest(unittest.TestCase):
    def test_revenue_sources_are_declared(self):
        self.assertIn("netsuite_revenue_by_sku_ytd", builder.SOURCES)
        self.assertIn("netsuite_revenue_by_customer_sku_channel_ytd", builder.SOURCES)
        self.assertEqual(builder.SOURCES["netsuite_revenue_by_sku_ytd"]["parser"], "netsuite_revenue_by_sku_ytd")
        self.assertEqual(
            builder.SOURCES["netsuite_revenue_by_customer_sku_channel_ytd"]["parser"],
            "netsuite_revenue_by_customer_sku_channel_ytd",
        )

    def test_revenue_queries_use_posted_invoice_credit_memo_gross_cpg_sales_lines(self):
        sku_query = builder.netsuite_revenue_by_sku_query("2026-01-01", "2026-05-04")
        customer_query = builder.netsuite_revenue_by_customer_sku_channel_query("2026-01-01", "2026-05-04")

        for query in (sku_query, customer_query):
            self.assertIn("JOIN transactionline tl", query)
            self.assertIn("JOIN account a ON tl.account = a.id", query)
            self.assertIn("a.acctnumber = '41005'", query)
            self.assertNotIn("a.acctnumber LIKE '41%'", query)
            self.assertNotIn("41008", query)
            self.assertNotIn("41025", query)
            self.assertIn("t.type IN ('CustInvc','CustCred')", query)
            self.assertIn("t.posting = 'T'", query)
            self.assertIn("-SUM(tl.amount) AS revenue", query)

        self.assertIn("LEFT JOIN customer ON customer.id = t.entity", customer_query)
        self.assertIn("BUILTIN.DF(tl.class) AS channel", customer_query)

    def test_customer_sku_channel_parser_writes_atomic_rows_and_provenance(self):
        conn = sqlite3.connect(":memory:")
        builder.create_schema(conn)
        source_id = "netsuite_revenue_by_customer_sku_channel_ytd"
        builder.insert_source(conn, source_id, builder.SOURCES[source_id], "2026-05-04T00:00:00Z")
        fake_rows = [
            {
                "customer_id": "10063",
                "customer_name": "10063",
                "customer_company": "Walmart",
                "sku": "JESO-01275",
                "display_name": "Just Egg, Scrambled, Refrigerated Retail 16oz",
                "line_count": "2",
                "quantity": "-120",
                "netsuite_amount": "-3500.00",
                "revenue": "3500.00",
            }
        ]

        with mock.patch.object(
            builder,
            "fetch_netsuite_suiteql",
            return_value=(fake_rows, "abc123def4567890", "2026-05-04T20:00:00Z"),
        ):
            summary = builder.insert_netsuite_revenue_rows(
                conn,
                source_id,
                builder.SOURCES[source_id],
                "netsuite_revenue_by_customer_sku_channel_ytd_fields",
                "application/customer/item/channel/revenue_ytd/field",
                include_customer=True,
                write_receipt=False,
            )

        self.assertEqual(summary["record_count"], 1)
        self.assertEqual(summary["total_revenue"], 3500.0)
        self.assertEqual(summary["total_quantity"], -120.0)
        row = conn.execute(
            """
            SELECT row_json, provenance_grain
            FROM atomic_rows
            WHERE source_id = ?
              AND source_table = ?
              AND row_key = ?
            """,
            (
                source_id,
                "netsuite_revenue_by_customer_sku_channel_ytd_fields",
                "10063|Walmart|Unclassified|JESO-01275:revenue",
            ),
        ).fetchone()
        self.assertIsNotNone(row)
        row_json = json.loads(row[0])
        provenance = json.loads(row[1])
        self.assertEqual(row_json["value"], 3500.0)
        self.assertEqual(row_json["channel"], "Unclassified")
        self.assertEqual(row_json["revenue_account"], "41005")
        self.assertEqual(row_json["revenue_account_name"], "Gross CPG sales")
        self.assertIn("41008", row_json["excluded_revenue_accounts"])
        self.assertEqual(
            row_json["reconciliation_status"],
            "partial_until_reconciled_to_netsuite_ui_income_statement_41005",
        )
        self.assertEqual(row_json["discount_allocation"], "not_allocated_to_product_sku")
        self.assertEqual(provenance["source_id"], source_id)
        self.assertEqual(provenance["grain_type"], "application/customer/item/channel/revenue_ytd/field")
        self.assertIn("netsuite:/suiteql/revenue_by_customer_sku_channel", provenance["locator"])


if __name__ == "__main__":
    unittest.main()
