import os
import sys
import tempfile
import unittest
from pathlib import Path


ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
SCRIPTS = os.path.join(ROOT, "scripts")
if SCRIPTS not in sys.path:
    sys.path.insert(0, SCRIPTS)

import build_fresh_source_database as builder


class SharePointBrowserSeedFallbackTests(unittest.TestCase):
    def test_local_browser_seed_tree_uses_existing_seed_files(self):
        with tempfile.TemporaryDirectory() as tmp:
            seed = Path(tmp) / "Just Egg Liquid BOM & P&L.xlsx"
            seed.write_bytes(b"seed workbook bytes")
            source = {
                "browser_seed_boundary": [str(seed), str(Path(tmp) / "missing.xlsx")],
                "sharepoint": {"exclude_paths": ["Archive"]},
            }

            token, tree = builder.local_browser_seed_sharepoint_tree("just_us_canada_p_and_l_boms", source)

        self.assertEqual(token, "local_browser_seed")
        self.assertEqual(tree["enumeration_source"], "local_browser_seed_boundary")
        self.assertEqual(tree["exclude_paths"], ["Archive"])
        self.assertEqual(len(tree["files"]), 1)
        self.assertEqual(tree["files"][0]["name"], "Just Egg Liquid BOM & P&L.xlsx")
        self.assertEqual(tree["files"][0]["c_tag"], "local_browser_seed_boundary")


if __name__ == "__main__":
    unittest.main()
