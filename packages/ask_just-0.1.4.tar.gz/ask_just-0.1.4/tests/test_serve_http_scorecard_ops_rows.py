import json
import os
import sqlite3
import sys
import unittest


ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
SCRIPTS = os.path.join(ROOT, "scripts")
if SCRIPTS not in sys.path:
    sys.path.insert(0, SCRIPTS)

import serve_http


class ServeHttpScorecardOpsRowsTests(unittest.TestCase):
    def make_conn(self):
        conn = sqlite3.connect(":memory:")
        conn.row_factory = sqlite3.Row
        conn.executescript(
            """
            CREATE TABLE sources (source_id TEXT PRIMARY KEY, boundary_json TEXT);
            CREATE TABLE source_files (source_id TEXT, path TEXT, sha256 TEXT, modified_at TEXT, parsed TEXT, provenance_grain TEXT);
            CREATE TABLE atomic_rows (
                source_id TEXT,
                source_table TEXT,
                source_file TEXT,
                row_json TEXT,
                provenance_grain TEXT,
                row_key TEXT,
                row_index INTEGER
            );
            """
        )
        conn.execute("INSERT INTO sources VALUES ('scorecard_ops_metrics', '[]')")
        conn.execute(
            "INSERT INTO source_files VALUES (?, ?, ?, ?, ?, ?)",
            ("scorecard_ops_metrics", "https://just-scorecard.vercel.app/api/read-data?key=ops_metrics", "abc", "now", "yes", "{}"),
        )
        return conn

    def insert_row(self, conn, row_key):
        conn.execute(
            "INSERT INTO atomic_rows VALUES (?, ?, ?, ?, ?, ?, ?)",
            (
                "scorecard_ops_metrics",
                "scorecard_ops_metric_fields",
                "https://just-scorecard.vercel.app/api/read-data?key=ops_metrics",
                json.dumps({"row_key": row_key, "field": "mar", "value": "1.2"}),
                json.dumps({"source_id": "scorecard_ops_metrics", "locator": f"scorecard://ops#{row_key}"}),
                row_key,
                1,
            ),
        )

    def test_certification_words_do_not_block_protein_on_hold_rows(self):
        conn = self.make_conn()
        self.insert_row(conn, "Upstream Inventory:Protein on Hold (MT):mar")

        rows = serve_http._scorecard_ops_metric_rows(
            conn,
            "What is the latest Scorecard ops metric for protein on hold? Return source id and row provenance.",
            5,
        )

        self.assertEqual(len(rows), 1)
        self.assertEqual(rows[0]["source_id"], "scorecard_ops_metrics")
        self.assertTrue(rows[0].get("source_links"))

    def test_certification_words_do_not_block_beans_inventory_rows(self):
        conn = self.make_conn()
        self.insert_row(conn, "Upstream Inventory:Beans (MT):mar")

        rows = serve_http._scorecard_ops_metric_rows(
            conn,
            "What Scorecard ops metric rows are visible for beans inventory? Return source id and row provenance.",
            5,
        )

        self.assertEqual(len(rows), 1)

    def test_average_shelf_life_matches_avg_row_label(self):
        conn = self.make_conn()
        self.insert_row(conn, "Shelf Life:Avg Shelf Life to Customer (days):mar")

        rows = serve_http._scorecard_ops_metric_rows(
            conn,
            "What Scorecard ops metric rows are visible for average shelf life to customer? Return source id and row provenance.",
            5,
        )

        self.assertEqual(len(rows), 1)

    def test_freight_per_sale_matches_freight_sale_row_label(self):
        conn = self.make_conn()
        self.insert_row(conn, "Transportation:Freight/Sale:mar")

        rows = serve_http._scorecard_ops_metric_rows(
            conn,
            "What Scorecard ops metric rows are visible for freight per sale? Return source id and row provenance.",
            5,
        )

        self.assertEqual(len(rows), 1)

    def test_frontier_wrappers_do_not_block_scorecard_ops_rows(self):
        conn = self.make_conn()
        self.insert_row(conn, "Upstream Inventory:Beans (MT):mar")

        rows = serve_http._scorecard_ops_metric_rows(
            conn,
            "Answer from the source lane only: What is the latest Scorecard ops metric for beans inventory? Return the rows that justify the answer.",
            5,
        )

        self.assertEqual(len(rows), 1)

    def test_ask_just_terminal_wrapper_does_not_block_scorecard_ops_rows(self):
        conn = self.make_conn()
        self.insert_row(conn, "Transportation:Freight/Sale:mar")

        rows = serve_http._scorecard_ops_metric_rows(
            conn,
            "From Ask Just terminal evidence: What is the latest Scorecard ops metric for freight per sale? Include provenance.",
            5,
        )

        self.assertEqual(len(rows), 1)

    def test_source_gap_and_spins_suffixes_do_not_block_scorecard_ops_rows(self):
        conn = self.make_conn()
        self.insert_row(conn, "Upstream Inventory:Protein on Hold (MT):mar")

        rows = serve_http._scorecard_ops_metric_rows(
            conn,
            "What is the latest Scorecard ops metric for protein on hold? If the lane is missing, say source gap. Do not use SPINS.",
            5,
        )

        self.assertEqual(len(rows), 1)

    def test_explicit_scorecard_ops_beats_otif_and_reefer_hosted_lanes(self):
        conn = self.make_conn()
        for source_id in ("operations_logistics_otif_2024v2", "reefer_meat_shelf_life_tests"):
            conn.execute("INSERT INTO sources VALUES (?, ?)", (source_id, "[]"))

        plan = serve_http.build_source_query_plan(
            conn,
            "Use the structured adapter if available: What is the latest Scorecard ops metric for protein on hold?",
        )

        self.assertEqual([step["source_id"] for step in plan], ["scorecard_ops_metrics"])

    def test_negative_otif_reefer_words_do_not_block_scorecard_ops_rows(self):
        conn = self.make_conn()
        self.insert_row(conn, "Upstream Inventory:Protein on Hold (MT):mar")

        rows = serve_http._scorecard_ops_metric_rows(
            conn,
            "What is the latest Scorecard ops metric for protein on hold? If the lane is missing, say source gap. Do not use OTIF or reefer tests.",
            5,
        )

        self.assertEqual(len(rows), 1)


if __name__ == "__main__":
    unittest.main()
