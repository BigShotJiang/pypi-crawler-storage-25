import importlib.util
import json
import sys
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
SOURCE_ID = "rd_processdev_project_onestream"
PROCESSDEV_DRIVE_ID = "b!hMt_G2w6GEioY6tUiLjkS6yh7KcCAhxLmQIqFnBlFVE-O_sZVxdrT63F2oKgYGm_"


def load_builder():
    scripts_dir = ROOT / "scripts"
    if str(scripts_dir) not in sys.path:
        sys.path.insert(0, str(scripts_dir))
    spec = importlib.util.spec_from_file_location(
        "build_fresh_source_database",
        ROOT / "scripts" / "build_fresh_source_database.py",
    )
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


class ProjectOneStreamSourceTest(unittest.TestCase):
    def test_project_onestream_lane_is_declared_queryable_and_narrow(self):
        all_source_ids = json.loads((ROOT / "config" / "all-source-ids.json").read_text())
        queryable_source_ids = json.loads((ROOT / "config" / "queryable-source-ids.json").read_text())
        builder = load_builder()

        self.assertIn(SOURCE_ID, all_source_ids)
        self.assertIn(SOURCE_ID, queryable_source_ids)

        source = builder.SOURCES[SOURCE_ID]
        self.assertEqual(source["source_type"], "sharepoint_document_library")
        self.assertEqual(source["business_domain"], "r_and_d_processdev_projects")
        self.assertEqual(source["parser"], "sharepoint_document_library")
        self.assertEqual(source["sharepoint"]["drive_id"], PROCESSDEV_DRIVE_ID)
        self.assertEqual(source["sharepoint"]["site_path"], "/sites/rd")
        self.assertEqual(source["sharepoint"]["library"], "ProcessDev")
        self.assertEqual(source["sharepoint"]["folder_path"], "Project OneStream")
        self.assertIn("Project OneStream", source["boundary"][0])
        self.assertIn("recursive folder enumeration", source["sharepoint"]["delta_policy"])


if __name__ == "__main__":
    unittest.main()
