import os
import sys
import unittest
from unittest import mock


ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
SCRIPTS = os.path.join(ROOT, "scripts")
if SCRIPTS not in sys.path:
    sys.path.insert(0, SCRIPTS)


class FakeService:
    def __init__(self):
        self.health_calls = 0

    def search(self, question, source="all", kind="all", limit=20, include_health=False, deep_health=False):
        result = {
            "ok": True,
            "source": source,
            "kind": kind,
            "routing_decision": {
                "route_shape": "structured",
                "adapter": "scorecard_monthly_kpi",
                "selected_source_lane": "scorecard_monthly_data",
                "fallback_policy": "fail_closed_no_prose_fallback",
            },
            "rows": [{"snippet": "gross revenue", "provenance_grain": '{"grain_id":"row:1"}'}],
        }
        if include_health:
            result["health"] = self.health(deep=deep_health)["health"]
        return result

    def health(self, deep=False):
        self.health_calls += 1
        return {
            "ok": True,
            "health": {
                "source_count": 10,
                "atomic_row_count": 285385,
                "health_mode": "deep" if deep else "cached",
            },
        }

    def sql(self, sql, limit=20, include_health=False, deep_health=False):
        result = {
            "ok": True,
            "rows": [{"employee_name": "Adam Duhoux"}],
            "routing_decision": {
                "route_shape": "structured",
                "adapter": "direct_sql_bypass",
                "selected_source_lane": "sql",
                "fallback_policy": "bypass",
                "reason": "The caller chose direct SQL instead of normal natural-language routing.",
                "bypass": True,
            },
        }
        if include_health:
            result["health"] = self.health(deep=deep_health)["health"]
        return result


class TracedQueryTests(unittest.TestCase):
    def test_execute_traced_adds_health_and_trace_fields(self):
        import serve_http

        service = FakeService()
        with mock.patch.object(serve_http.braintrust_tracing, "start_trace") as start_trace:
            recorder = start_trace.return_value
            recorder.finish.return_value = {
                "trace_id": "trace-123",
                "trace_url": "https://www.braintrust.dev/app/Andes/p/ask-just/trace?r=trace-123",
            }

            result = serve_http._execute_traced(
                service,
                "query",
                {
                    "question": "gross revenue",
                    "source": "scorecard_monthly_data",
                    "kind": "chunks",
                    "include_health": True,
                    "trace": True,
                },
                lambda: service.search(
                    "gross revenue",
                    source="scorecard_monthly_data",
                    kind="chunks",
                    include_health=True,
                ),
            )

        self.assertTrue(result["ok"])
        self.assertEqual(result["trace_id"], "trace-123")
        self.assertEqual(result["health"]["atomic_row_count"], 285385)
        user_question_events = [
            call
            for call in recorder.event.call_args_list
            if call.args and call.args[0] == "trace.user_question"
        ]
        self.assertEqual(len(user_question_events), 1)
        user_question_output = user_question_events[0].kwargs["output"]
        self.assertEqual(user_question_output["question"], "gross revenue")
        self.assertEqual(user_question_output["source"], "scorecard_monthly_data")
        self.assertEqual(user_question_output["kind"], "chunks")
        self.assertEqual(user_question_output["operation"], "query")
        recorder.event.assert_any_call(
            "trace.routing_decision",
            output={
                "route_shape": "structured",
                "adapter": "scorecard_monthly_kpi",
                "selected_source_lane": "scorecard_monthly_data",
                "fallback_policy": "fail_closed_no_prose_fallback",
            },
        )

    def test_execute_traced_adds_debug_metadata_to_user_question(self):
        import serve_http

        service = FakeService()
        with mock.patch.object(serve_http.braintrust_tracing, "start_trace") as start_trace:
            recorder = start_trace.return_value
            recorder.finish.return_value = {}

            serve_http._execute_traced(
                service,
                "query",
                {
                    "question": "gross revenue",
                    "source": "scorecard_monthly_data",
                    "kind": "chunks",
                    "trace": True,
                },
                lambda: service.search(
                    "gross revenue",
                    source="scorecard_monthly_data",
                    kind="chunks",
                ),
                request_metadata={
                    "request_id": "req-123",
                    "client_ip": "203.0.113.7",
                    "user_agent": "ask-just-test/1.0",
                    "token_label": "shared_ask_just_token",
                    "principal_kind": "shared",
                    "principal_label": "shared_ask_just_token",
                },
            )

        trace_payload = start_trace.call_args.args[1]
        self.assertEqual(trace_payload["request_id"], "req-123")
        self.assertEqual(trace_payload["client_ip"], "203.0.113.7")
        recorder.event.assert_any_call(
            "trace.user_question",
            output={
                "question": "gross revenue",
                "source": "scorecard_monthly_data",
                "kind": "chunks",
                "operation": "query",
                "request_id": "req-123",
                "client_ip": "203.0.113.7",
                "user_agent": "ask-just-test/1.0",
                "token_label": "shared_ask_just_token",
                "principal_kind": "shared",
                "principal_label": "shared_ask_just_token",
            },
        )

    def test_execute_traced_final_answer_has_debug_summary(self):
        import serve_http

        service = FakeService()
        with mock.patch.object(serve_http.braintrust_tracing, "start_trace") as start_trace:
            recorder = start_trace.return_value
            recorder.finish.return_value = {}

            serve_http._execute_traced(
                service,
                "query",
                {"question": "gross revenue", "source": "scorecard_monthly_data", "trace": True},
                lambda: service.search("gross revenue", source="scorecard_monthly_data"),
                request_metadata={"request_id": "req-456"},
            )

        final_answer_events = [
            call
            for call in recorder.event.call_args_list
            if call.args and call.args[0] == "trace.final_answer"
        ]
        self.assertEqual(len(final_answer_events), 1)
        output = final_answer_events[0].kwargs["output"]
        self.assertEqual(output["operation"], "query")
        self.assertTrue(output["ok"])
        self.assertEqual(output["status"], "ok")
        self.assertEqual(output["row_count"], 1)
        self.assertEqual(output["route_adapter"], "scorecard_monthly_kpi")
        self.assertEqual(output["request_id"], "req-456")

    def test_execute_traced_sql_preserves_plain_language_question(self):
        import serve_http

        service = FakeService()
        sql = "select employee_name from just_headcount order by employee_name"
        with mock.patch.object(serve_http.braintrust_tracing, "start_trace") as start_trace:
            recorder = start_trace.return_value
            recorder.finish.return_value = {
                "trace_id": "trace-sql-123",
                "trace_url": "https://www.braintrust.dev/app/Andes/p/ask-just/trace?r=trace-sql-123",
            }

            result = serve_http._execute_traced(
                service,
                "sql",
                {
                    "question": "list just employees",
                    "sql": sql,
                    "limit": 100,
                    "trace": True,
                },
                lambda: service.sql(sql, limit=100),
            )

        self.assertTrue(result["ok"])
        self.assertEqual(result["trace_id"], "trace-sql-123")
        user_question_events = [
            call
            for call in recorder.event.call_args_list
            if call.args and call.args[0] == "trace.user_question"
        ]
        self.assertEqual(len(user_question_events), 1)
        user_question_output = user_question_events[0].kwargs["output"]
        self.assertEqual(user_question_output["question"], "list just employees")
        self.assertEqual(user_question_output["source"], "all")
        self.assertEqual(user_question_output["kind"], "all")
        self.assertEqual(user_question_output["operation"], "sql")
        self.assertEqual(user_question_output["executed_sql"], sql)
        recorder.event.assert_any_call(
            "trace.routing_decision",
            output={
                "route_shape": "structured",
                "adapter": "direct_sql_bypass",
                "selected_source_lane": "sql",
                "fallback_policy": "bypass",
                "reason": "The caller chose direct SQL instead of normal natural-language routing.",
                "bypass": True,
            },
        )

    def test_execute_traced_skips_trace_health_when_not_requested(self):
        import braintrust_tracing
        import serve_http

        service = FakeService()
        with mock.patch.object(serve_http.braintrust_tracing, "start_trace", return_value=braintrust_tracing.NoopTraceRecorder()):
            result = serve_http._execute_traced(
                service,
                "query",
                {
                    "question": "gross revenue",
                    "source": "scorecard_monthly_data",
                    "kind": "chunks",
                    "include_health": False,
                },
                lambda: service.search(
                    "gross revenue",
                    source="scorecard_monthly_data",
                    kind="chunks",
                    include_health=False,
                ),
            )

        self.assertTrue(result["ok"])
        self.assertNotIn("trace_id", result)
        self.assertEqual(service.health_calls, 0)


if __name__ == "__main__":
    unittest.main()
