import os
import sys
import unittest


ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
SCRIPTS = os.path.join(ROOT, "scripts")
if SCRIPTS not in sys.path:
    sys.path.insert(0, SCRIPTS)

import serve_http


class ServeHttpNonSpinsRoutingTests(unittest.TestCase):
    def make_sources_conn(self, source_ids):
        import sqlite3

        conn = sqlite3.connect(":memory:")
        conn.row_factory = sqlite3.Row
        conn.execute("CREATE TABLE sources (source_id TEXT PRIMARY KEY)")
        for source_id in source_ids:
            conn.execute("INSERT INTO sources VALUES (?)", (source_id,))
        return conn

    def test_non_spins_production_plan_does_not_enter_spins_contract(self):
        self.assertTrue(
            serve_http._should_skip_spins_contract_for_non_spins_question(
                "What is the latest production plan for Just Egg?"
            )
        )

    def test_non_spins_v6_formula_does_not_enter_spins_contract(self):
        self.assertTrue(
            serve_http._should_skip_spins_contract_for_non_spins_question(
                "What is the newest V6 liquid egg formula?"
            )
        )

    def test_explicit_do_not_use_spins_business_question_skips_spins_contract(self):
        self.assertTrue(
            serve_http._should_skip_spins_contract_for_non_spins_question(
                "What inventory rows does NetSuite expose for JUST Egg items? Do not use SPINS."
            )
        )
        self.assertTrue(
            serve_http._should_skip_spins_contract_for_non_spins_question(
                "What is the standard cost for JUST EGG 6x340ml DE? Do not use SPINS."
            )
        )

    def test_product_label_nutrition_ingredients_skip_spins_contract(self):
        self.assertTrue(
            serve_http._should_skip_spins_contract_for_non_spins_question(
                "Just Egg Folded label nutrition ingredients"
            )
        )
        self.assertTrue(
            serve_http._should_skip_spins_contract_for_non_spins_question(
                "Is JUST Protein powder made from mung bean protein isolate or whole mung bean powder?"
            )
        )

    def test_market_product_label_routes_to_entr_before_spins(self):
        conn = self.make_sources_conn(
            [
                "replace_enter_repo_github",
                "spins_breakfast_powertabs",
                "rd_formulations_vault_production_formulas",
            ]
        )

        plan = serve_http.build_source_query_plan(conn, "Just Egg Folded label nutrition ingredients")

        self.assertEqual(plan[0]["source_id"], "replace_enter_repo_github")
        self.assertEqual(plan[0]["adapter_hint"], "replace_enter_formula_record")
        self.assertNotIn("spins_breakfast_powertabs", {step["source_id"] for step in plan})

    def test_non_market_ingredient_question_routes_to_rd_formula_source(self):
        conn = self.make_sources_conn(
            [
                "replace_enter_repo_github",
                "spins_breakfast_powertabs",
                "rd_liquid_egg_v6",
            ]
        )

        plan = serve_http.build_source_query_plan(conn, "What ingredients are in the V6 liquid egg workbook?")

        self.assertEqual(plan[0]["source_id"], "rd_liquid_egg_v6")
        self.assertNotIn("spins_breakfast_powertabs", {step["source_id"] for step in plan})

    def test_explicit_spins_velocity_can_still_use_spins_contract(self):
        self.assertFalse(
            serve_http._should_skip_spins_contract_for_non_spins_question(
                "What is JUST Egg velocity in SPINS MULO?"
            )
        )


if __name__ == "__main__":
    unittest.main()
