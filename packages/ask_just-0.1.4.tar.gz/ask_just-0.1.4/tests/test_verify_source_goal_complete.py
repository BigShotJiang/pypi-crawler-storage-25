import json
import os
import sys
import tempfile
import unittest
from contextlib import redirect_stdout
from io import StringIO
from pathlib import Path
from unittest import mock


ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
SCRIPTS = os.path.join(ROOT, "scripts")
if SCRIPTS not in sys.path:
    sys.path.insert(0, SCRIPTS)

import verify_source_goal_complete


def write_json(path, payload):
    path.write_text(json.dumps(payload), encoding="utf-8")


class VerifySourceGoalCompleteTest(unittest.TestCase):
    def run_verifier(self, strict_payload, spins_payload=None, vm_refresh_payload=None):
        tmp = tempfile.TemporaryDirectory()
        self.addCleanup(tmp.cleanup)
        strict_path = Path(tmp.name) / "strict.json"
        spins_path = Path(tmp.name) / "spins.json"
        vm_refresh_path = Path(tmp.name) / "vm_refresh.json"
        queryable_path = Path(tmp.name) / "queryable-source-ids.json"
        write_json(strict_path, strict_payload)
        write_json(spins_path, spins_payload or {"ok": True})
        write_json(vm_refresh_path, vm_refresh_payload or {"ok": True})
        source_ids = [row["source_id"] for row in strict_payload.get("rows") or []]
        write_json(queryable_path, source_ids)
        hosted_sources = {
            source_id: {
                "source_id": source_id,
                "mapped": "yes",
                "accessible": "yes",
                "atomically_queryable": "yes",
            }
            for source_id in source_ids
        }
        out = StringIO()
        with mock.patch.object(verify_source_goal_complete, "STRICT_TABLE", strict_path), mock.patch.object(
            verify_source_goal_complete, "SPINS_JUST_VELOCITY_GOAL", spins_path
        ), mock.patch.object(
            verify_source_goal_complete, "VM_SOURCE_REFRESH_STATUS", vm_refresh_path
        ), mock.patch.object(
            verify_source_goal_complete, "QUERYABLE_SOURCE_IDS", queryable_path
        ), mock.patch.object(
            verify_source_goal_complete, "fetch_hosted_sources", return_value=hosted_sources
        ), mock.patch.object(sys, "argv", ["verify_source_goal_complete.py"]), redirect_stdout(out):
            code = verify_source_goal_complete.main()
        return code, out.getvalue()

    def run_verifier_with_hosted_sources(self, strict_payload, hosted_sources):
        tmp = tempfile.TemporaryDirectory()
        self.addCleanup(tmp.cleanup)
        strict_path = Path(tmp.name) / "strict.json"
        spins_path = Path(tmp.name) / "spins.json"
        vm_refresh_path = Path(tmp.name) / "vm_refresh.json"
        queryable_path = Path(tmp.name) / "queryable-source-ids.json"
        write_json(strict_path, strict_payload)
        write_json(spins_path, {"ok": True})
        write_json(vm_refresh_path, {"ok": True})
        write_json(queryable_path, [row["source_id"] for row in strict_payload.get("rows") or []])
        out = StringIO()
        with mock.patch.object(verify_source_goal_complete, "STRICT_TABLE", strict_path), mock.patch.object(
            verify_source_goal_complete, "SPINS_JUST_VELOCITY_GOAL", spins_path
        ), mock.patch.object(
            verify_source_goal_complete, "VM_SOURCE_REFRESH_STATUS", vm_refresh_path
        ), mock.patch.object(
            verify_source_goal_complete, "QUERYABLE_SOURCE_IDS", queryable_path
        ), mock.patch.object(
            verify_source_goal_complete, "fetch_hosted_sources", return_value=hosted_sources
        ), mock.patch.object(sys, "argv", ["verify_source_goal_complete.py"]), redirect_stdout(out):
            code = verify_source_goal_complete.main()
        return code, out.getvalue()

    def test_accepts_any_declared_source_count_when_every_row_is_complete(self):
        rows = [
            {"source_id": "one", "status": "fully_source", "explicit_gaps": ["none"]},
            {"source_id": "two", "status": "fully_source", "explicit_gaps": ["none"]},
        ]
        code, output = self.run_verifier(
            {
                "source_count": 2,
                "fully_source_count": 2,
                "not_fully_source_count": 0,
                "rows": rows,
            }
        )

        self.assertEqual(code, 0)
        self.assertIn("2/2 lanes fully $source", output)

    def test_rejects_count_mismatch_even_if_summary_counts_look_green(self):
        rows = [{"source_id": "one", "status": "fully_source", "explicit_gaps": ["none"]}]
        code, output = self.run_verifier(
            {
                "source_count": 2,
                "fully_source_count": 2,
                "not_fully_source_count": 0,
                "rows": rows,
            }
        )

        self.assertEqual(code, 1)
        self.assertIn("strict_table_row_count=1", output)

    def test_rejects_non_none_explicit_gaps(self):
        rows = [{"source_id": "one", "status": "fully_source", "explicit_gaps": ["upstream gap"]}]
        code, output = self.run_verifier(
            {
                "source_count": 1,
                "fully_source_count": 1,
                "not_fully_source_count": 0,
                "rows": rows,
            }
        )

        self.assertEqual(code, 1)
        self.assertIn("Ask Just source goal NOT complete", output)

    def test_rejects_failed_vm_source_refresh_status(self):
        rows = [{"source_id": "one", "status": "fully_source", "explicit_gaps": ["none"]}]
        code, output = self.run_verifier(
            {
                "source_count": 1,
                "fully_source_count": 1,
                "not_fully_source_count": 0,
                "rows": rows,
            },
            vm_refresh_payload={
                "ok": False,
                "service": {
                    "active_state": "failed",
                    "result": "exit-code",
                    "exec_main_status": "1",
                },
                "gaps": ["missing MS_GRAPH_CLIENT_SECRET"],
            },
        )

        self.assertEqual(code, 1)
        self.assertIn("vm_source_refresh_status: not complete", output)
        self.assertIn("missing MS_GRAPH_CLIENT_SECRET", output)

    def test_rejects_declared_lane_missing_from_hosted_sources(self):
        rows = [
            {"source_id": "tofutown_dirk_stock_level_workbook", "status": "fully_source", "explicit_gaps": ["none"]}
        ]
        code, output = self.run_verifier_with_hosted_sources(
            {
                "source_count": 1,
                "fully_source_count": 1,
                "not_fully_source_count": 0,
                "rows": rows,
            },
            hosted_sources={},
        )

        self.assertEqual(code, 1)
        self.assertIn("hosted_inventory: not complete", output)
        self.assertIn("missing_from_hosted_ask_just_sources: tofutown_dirk_stock_level_workbook", output)

    def test_rejects_hosted_lane_with_bad_gates(self):
        rows = [{"source_id": "one", "status": "fully_source", "explicit_gaps": ["none"]}]
        code, output = self.run_verifier_with_hosted_sources(
            {
                "source_count": 1,
                "fully_source_count": 1,
                "not_fully_source_count": 0,
                "rows": rows,
            },
            hosted_sources={
                "one": {
                    "source_id": "one",
                    "mapped": "yes",
                    "accessible": "yes",
                    "atomically_queryable": "no",
                }
            },
        )

        self.assertEqual(code, 1)
        self.assertIn("hosted gate failure: one", output)


if __name__ == "__main__":
    unittest.main()
