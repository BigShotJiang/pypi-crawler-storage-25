import os
import sqlite3
import sys
import unittest


ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
SCRIPTS = os.path.join(ROOT, "scripts")
if SCRIPTS not in sys.path:
    sys.path.insert(0, SCRIPTS)

import serve_http


class ServeHttpExplicitSourceRoutingTests(unittest.TestCase):
    def test_present_requested_source_uses_source_specific_plan(self):
        conn = sqlite3.connect(":memory:")
        conn.row_factory = sqlite3.Row
        conn.execute("CREATE TABLE sources (source_id TEXT PRIMARY KEY)")
        conn.execute("INSERT INTO sources VALUES ('scorecard_monthly_data')")

        plan = serve_http.build_source_query_plan(
            conn,
            "For the Scorecard lane, what was gross revenue in May 2026?",
            requested_source="scorecard_monthly_data",
        )

        self.assertEqual(len(plan), 1)
        self.assertEqual(plan[0]["source_id"], "scorecard_monthly_data")
        self.assertEqual(plan[0]["family"], "scorecard")


if __name__ == "__main__":
    unittest.main()
