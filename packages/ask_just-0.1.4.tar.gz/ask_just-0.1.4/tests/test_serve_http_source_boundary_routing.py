import os
import sqlite3
import sys
import unittest


ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
SCRIPTS = os.path.join(ROOT, "scripts")
if SCRIPTS not in sys.path:
    sys.path.insert(0, SCRIPTS)

import serve_http


class ServeHttpSourceBoundaryRoutingTests(unittest.TestCase):
    def make_conn(self, source_ids):
        conn = sqlite3.connect(":memory:")
        conn.row_factory = sqlite3.Row
        conn.execute("CREATE TABLE sources (source_id TEXT PRIMARY KEY, boundary_json TEXT)")
        for source_id in source_ids:
            conn.execute("INSERT INTO sources VALUES (?, ?)", (source_id, "[]"))
        return conn

    def test_plain_margin_does_not_route_to_tofutown_without_europe_context(self):
        adapter = serve_http._generic_business_adapter_for_question(
            "What was gross margin in March 2026?",
            {"tofutown_standard_cost_gross_margin_by_sku_2026_05"},
        )

        self.assertIsNone(adapter)

    def test_europe_standard_cost_can_route_to_tofutown(self):
        adapter = serve_http._generic_business_adapter_for_question(
            "What is the standard cost or gross margin for JUST EGG 6x340ml DE?",
            {"tofutown_standard_cost_gross_margin_by_sku_2026_05"},
        )

        self.assertIsNotNone(adapter)
        self.assertEqual(adapter["source_id"], "tofutown_standard_cost_gross_margin_by_sku_2026_05")

    def test_plain_cost_does_not_route_to_us_canada_without_boundary_context(self):
        adapter = serve_http._generic_business_adapter_for_question(
            "What was product cost for Just Egg?",
            {"just_us_canada_p_and_l_boms"},
        )

        self.assertIsNone(adapter)

    def test_do_not_answer_with_tofutown_routes_to_us_canada_not_tofutown(self):
        adapter = serve_http._generic_business_adapter_for_question(
            "Do not answer with TofuTown: what Just US / Canada P&L row supports Just Egg liquid?",
            {
                "tofutown_standard_cost_gross_margin_by_sku_2026_05",
                "just_us_canada_p_and_l_boms",
            },
        )

        self.assertIsNotNone(adapter)
        self.assertEqual(adapter["source_id"], "just_us_canada_p_and_l_boms")

    def test_tofutown_bom_beats_netsuite_items_and_replace_enter(self):
        conn = self.make_conn(
            {
                "tofutown_bom_tt_skus",
                "netsuite_items",
                "replace_enter_repo_github",
            }
        )

        plan = serve_http.build_source_query_plan(
            conn,
            "What TofuTown BOM ingredient rows are visible for JUST EGG SKUs? Return the rows that justify the answer.",
        )

        self.assertEqual([step["source_id"] for step in plan], ["tofutown_bom_tt_skus"])
        self.assertEqual(plan[0].get("adapter_hint"), "tofutown_bom")

    def test_tofutown_standard_cost_beats_tofutown_bom(self):
        conn = self.make_conn(
            {
                "tofutown_standard_cost_gross_margin_by_sku_2026_05",
                "tofutown_bom_tt_skus",
                "operations_logistics_otif_2024v2",
            }
        )

        plan = serve_http.build_source_query_plan(
            conn,
            "For Europe only, what TofuTown standard cost evidence exists for JUST EGG 6x340ml DE? Include provenance.",
        )

        self.assertEqual([step["source_id"] for step in plan], ["tofutown_standard_cost_gross_margin_by_sku_2026_05"])
        self.assertEqual(plan[0].get("adapter_hint"), "tofutown_standard_cost_margin")

    def test_just_us_canada_pnl_beats_otif_and_tofutown(self):
        conn = self.make_conn(
            {
                "just_us_canada_p_and_l_boms",
                "operations_logistics_otif_2024v2",
                "tofutown_standard_cost_gross_margin_by_sku_2026_05",
            }
        )

        plan = serve_http.build_source_query_plan(
            conn,
            "Do not answer with TofuTown: what Just US / Canada P&L row supports Just Egg liquid? If the lane is missing, say source gap.",
        )

        self.assertEqual([step["source_id"] for step in plan], ["just_us_canada_p_and_l_boms"])
        self.assertEqual(plan[0].get("adapter_hint"), "just_us_canada_bom_pnl")

    def test_negative_just_us_context_does_not_force_us_canada_lane(self):
        conn = self.make_conn(
            {
                "just_us_canada_p_and_l_boms",
                "tofutown_bom_tt_skus",
            }
        )

        plan = serve_http.build_source_query_plan(
            conn,
            "Do not answer with Just US data: what Europe TofuTown BOM ingredient evidence exists?",
        )

        self.assertEqual([step["source_id"] for step in plan], ["tofutown_bom_tt_skus"])

    def test_satellite_brochure_beats_formulations_vault(self):
        conn = self.make_conn(
            {
                "satellite_cpg_eat_just_brochure",
                "rd_formulations_vault_production_formulas",
            }
        )

        plan = serve_http.build_source_query_plan(
            conn,
            "What product spec or nutrition evidence is in the Satellite CPG brochure? Keep Scorecard and NetSuite separate.",
        )

        self.assertEqual([step["source_id"] for step in plan], ["satellite_cpg_eat_just_brochure"])
        self.assertEqual(plan[0].get("adapter_hint"), "satellite_product_spec")


if __name__ == "__main__":
    unittest.main()
