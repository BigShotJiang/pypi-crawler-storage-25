import os
import sys
import unittest


ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
SCRIPTS = os.path.join(ROOT, "scripts")
if SCRIPTS not in sys.path:
    sys.path.insert(0, SCRIPTS)


class QueryRoutingContractTests(unittest.TestCase):
    def test_routing_map_declares_initial_structured_lanes(self):
        import query_routing

        routing_map = query_routing.load_routing_map()

        self.assertEqual(
            routing_map["sources"]["spins_breakfast_powertabs"]["adapters"]["spins_velocity"]["route_shape"],
            "structured",
        )
        self.assertEqual(
            routing_map["sources"]["whole_foods_canada_just_egg_rl_upsw"]["adapters"]["whole_foods_canada_velocity"]["fallback_policy"],
            "fail_closed_no_prose_fallback",
        )
        self.assertEqual(
            routing_map["sources"]["just_public_website_homepage"]["default_route_shape"],
            "prose",
        )

    def test_routing_map_source_ids_are_queryable_source_ids(self):
        import query_routing

        errors = query_routing.validate_routing_map()

        self.assertEqual(errors, [])

    def test_business_answer_adapter_pack_is_declared(self):
        import query_routing

        routing_map = query_routing.load_routing_map()
        sources = routing_map["sources"]
        expected = {
            "spins_breakfast_powertabs": {"spins_velocity", "spins_ranking"},
            "whole_foods_canada_just_egg_rl_upsw": {"whole_foods_canada_velocity", "whole_foods_canada_store_sales"},
            "whole_foods_us_who_cube_2026_04_19": {"whole_foods_us_velocity", "whole_foods_us_store_sales"},
            "dot_foodservice_weekly_sales": {"dot_foodservice_weekly_sales"},
            "target_tracker": {"target_tracker_retail_calendar"},
            "hr_just_food_company_headcount": {"just_people_roster"},
            "tofutown_employee_list_2026": {"tofutown_people_roster"},
            "rd_liquid_egg_v6": {"rd_liquid_egg_v6_formula"},
            "rd_powerjacks_formulations": {"rd_powerjacks_formula"},
            "rd_formulations_vault_production_formulas": {"rd_formulations_vault_production_formula"},
            "replace_enter_repo_github": {"replace_enter_formula_record"},
            "satellite_cpg_eat_just_brochure": {"satellite_product_spec"},
            "reefer_meat_shelf_life_tests": {"reefer_shelf_life_result"},
            "scorecard_monthly_data": {"scorecard_monthly_kpi"},
            "scorecard_ops_metrics": {"scorecard_ops_kpi"},
            "netsuite_pnl_monthly": {"netsuite_pnl_metric"},
            "netsuite_ar_open_invoices": {"netsuite_open_ar"},
            "netsuite_ap_open_bills": {"netsuite_open_ap"},
            "netsuite_inventory_snapshot": {"netsuite_inventory_on_hand"},
            "netsuite_items": {"netsuite_item_lookup"},
            "netsuite_revenue_by_sku_ytd": {"netsuite_revenue_by_sku"},
            "netsuite_revenue_by_customer_sku_channel_ytd": {"netsuite_revenue_by_customer_sku_channel"},
            "finance_cash_flow_forecast_2026": {"finance_cash_flow"},
            "batch_release_app": {"batch_release_batch_status"},
            "operations_production_plan_latest": {"operations_production_plan"},
            "operations_inbound_log": {"operations_inbound_log"},
            "operations_logistics_otif_2024v2": {"operations_otif"},
            "appleton_jpc_factory_dashboard": {"appleton_jpc_current_tag"},
            "asana_work_management": {"asana_project_status", "asana_task_lookup"},
            "tofutown_bom_tt_skus": {"tofutown_bom"},
            "tofutown_standard_cost_gross_margin_by_sku_2026_05": {"tofutown_standard_cost_margin"},
            "just_us_canada_p_and_l_boms": {"just_us_canada_bom_pnl"},
        }
        for source_id, adapter_names in expected.items():
            self.assertIn(source_id, sources)
            declared = set(sources[source_id]["adapters"])
            self.assertTrue(adapter_names.issubset(declared), (source_id, adapter_names - declared))

    def test_validate_routing_map_reports_unknown_injected_source_ids(self):
        import query_routing

        routing_map = {
            "sources": {
                "scorecard_monthly_data": {
                    "default_route_shape": "structured",
                    "adapters": {
                        "scorecard_monthly_kpi": {
                            "route_shape": "structured",
                            "fallback_policy": "fail_closed_no_prose_fallback",
                        }
                    },
                }
            }
        }

        errors = query_routing.validate_routing_map(routing_map=routing_map, queryable_source_ids=set())

        self.assertEqual(errors, ["unknown source_id: scorecard_monthly_data"])

    def test_validate_routing_map_accepts_bypass_fallback_policy(self):
        import query_routing

        routing_map = {
            "sources": {
                "just_public_website_homepage": {
                    "default_route_shape": "prose",
                    "adapters": {
                        "direct_text_search_bypass": {
                            "route_shape": "prose",
                            "fallback_policy": "bypass",
                        }
                    },
                }
            }
        }

        errors = query_routing.validate_routing_map(
            routing_map=routing_map,
            queryable_source_ids={"just_public_website_homepage"},
        )

        self.assertEqual(errors, [])

    def test_validate_routing_map_reports_invalid_shape_missing_fallback_and_policy_typo(self):
        import query_routing

        routing_map = {
            "sources": {
                "scorecard_monthly_data": {
                    "default_route_shape": "spreadsheet",
                    "adapters": {
                        "scorecard_monthly_kpi": {
                            "route_shape": "table",
                            "fallback_policy": "fail_closed",
                        },
                        "scorecard_missing_fallback": {
                            "route_shape": "structured",
                        },
                    },
                }
            }
        }

        errors = query_routing.validate_routing_map(
            routing_map=routing_map,
            queryable_source_ids={"scorecard_monthly_data"},
        )

        self.assertEqual(
            errors,
            [
                "scorecard_monthly_data: invalid default_route_shape 'spreadsheet'",
                "scorecard_monthly_data.scorecard_monthly_kpi: invalid route_shape 'table'",
                "scorecard_monthly_data.scorecard_monthly_kpi: invalid fallback_policy 'fail_closed'",
                "scorecard_monthly_data.scorecard_missing_fallback: missing fallback_policy",
            ],
        )

    def test_validate_routing_map_reports_malformed_scalar_values(self):
        import query_routing

        routing_map = {
            "sources": {
                "scorecard_monthly_data": {
                    "default_route_shape": ["structured"],
                    "adapters": {
                        "scorecard_monthly_kpi": {
                            "route_shape": ["structured"],
                            "fallback_policy": ["fail_closed_no_prose_fallback"],
                        },
                        "scorecard_missing_none": {
                            "route_shape": "structured",
                            "fallback_policy": None,
                        },
                        "scorecard_missing_empty": {
                            "route_shape": "structured",
                            "fallback_policy": "",
                        },
                    },
                }
            }
        }

        errors = query_routing.validate_routing_map(
            routing_map=routing_map,
            queryable_source_ids={"scorecard_monthly_data"},
        )

        self.assertEqual(
            errors,
            [
                "scorecard_monthly_data: invalid default_route_shape ['structured']",
                "scorecard_monthly_data.scorecard_monthly_kpi: invalid route_shape ['structured']",
                "scorecard_monthly_data.scorecard_monthly_kpi: invalid fallback_policy ['fail_closed_no_prose_fallback']",
                "scorecard_monthly_data.scorecard_missing_none: missing fallback_policy",
                "scorecard_monthly_data.scorecard_missing_empty: missing fallback_policy",
            ],
        )

    def test_validate_routing_map_reports_non_mapping_sections(self):
        import query_routing

        cases = [
            ({"sources": []}, {"known"}, ["sources must be a mapping"]),
            (
                {"sources": {"known": []}},
                {"known"},
                ["known: source config must be a mapping"],
            ),
            (
                {"sources": {"known": {"default_route_shape": "structured", "adapters": []}}},
                {"known"},
                ["known: adapters must be a mapping"],
            ),
            (
                {
                    "sources": {
                        "known": {
                            "default_route_shape": "structured",
                            "adapters": {"adapter": []},
                        }
                    }
                },
                {"known"},
                ["known.adapter: adapter config must be a mapping"],
            ),
        ]

        for routing_map, queryable_source_ids, expected_errors in cases:
            with self.subTest(expected_errors=expected_errors):
                errors = query_routing.validate_routing_map(
                    routing_map=routing_map,
                    queryable_source_ids=queryable_source_ids,
                )
                self.assertEqual(errors, expected_errors)


if __name__ == "__main__":
    unittest.main()
