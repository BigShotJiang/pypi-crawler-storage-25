import unittest
from pathlib import Path
import json

import scripts.build_fresh_source_database as builder


ROOT = Path(__file__).resolve().parents[1]
SOURCE_ID = "operations_logistics_otif_2024v2"
WORKBOOK = ROOT / "source-material" / SOURCE_ID / "Logistics OTIF 2024v2.xlsx"
RECEIPT = ROOT / "receipts" / "fresh" / "source-granularity-operations_logistics_otif_2024v2.json"


class OperationsLogisticsOtifSourceTest(unittest.TestCase):
    def test_source_definition_is_mapped_to_sharepoint_workbook_lane(self):
        source = builder.SOURCES[SOURCE_ID]

        self.assertEqual(source["parser"], "operations_logistics_otif_workbook")
        self.assertEqual(source["sharepoint"]["sourcedoc"], "7B85BE40-04CC-4F3C-9508-29819BB03D40")
        self.assertEqual(source["source_type"], "sharepoint_xlsx_workbook_snapshot")
        self.assertEqual(source["freshness_expectation"], "daily_midnight_graph_delta_snapshot")

    def test_receipt_records_queryable_workbook_snapshot(self):
        receipt = json.loads(RECEIPT.read_text())

        self.assertTrue(receipt["ok"])
        self.assertEqual(receipt["source"]["id"], SOURCE_ID)
        self.assertEqual(receipt["source"]["sharepoint"]["sourcedoc"], "7B85BE40-04CC-4F3C-9508-29819BB03D40")
        self.assertEqual(receipt["file"]["name"], "Logistics OTIF 2024v2.xlsx")
        self.assertEqual(
            receipt["file"]["sha256"],
            "4e429410886efb3dae69aab7bb0532f320034ba98435b23eef2527f66c3b28d6",
        )

    @unittest.skipUnless(WORKBOOK.exists(), "local workbook cache is intentionally not tracked in git")
    def test_source_definition_and_formula_cells_are_mapped(self):
        source = builder.SOURCES[SOURCE_ID]

        self.assertEqual(source["parser"], "operations_logistics_otif_workbook")
        self.assertEqual(source["sharepoint"]["sourcedoc"], "7B85BE40-04CC-4F3C-9508-29819BB03D40")

        cells = builder.extract_xlsx_formula_cells(
            WORKBOOK,
            "OTIF Revised 2025",
            {"P7", "Q7", "P8", "Q8", "P10", "Q10", "AM13", "AN13"},
        )
        self.assertEqual(cells["P7"]["value"], "Just Controlled Late")
        self.assertIn("Customer Pickup", cells["Q7"]["formula"])
        self.assertEqual(cells["P8"]["value"], "Just Controlled OTD %")
        self.assertEqual(cells["Q8"]["formula"], "=1-(Q7/Q6)")
        self.assertEqual(cells["P10"]["value"], "Total affected ordes (Short/Push/Cancelled)")
        self.assertIn('"Pushed"', cells["Q10"]["formula"])
        self.assertIn('"Short"', cells["Q10"]["formula"])
        self.assertIn('"Cancelled"', cells["Q10"]["formula"])
        self.assertEqual(cells["AM13"]["value"], "OTIF")
        self.assertEqual(cells["AN13"]["formula"], "=AVERAGE(AN12,AN8)")

    @unittest.skipUnless(WORKBOOK.exists(), "local workbook cache is intentionally not tracked in git")
    def test_threaded_comments_capture_cpu_and_late_affected_rules(self):
        comments = builder.extract_xlsx_threaded_comments(WORKBOOK, {"P7", "P10", "Y10", "Z10", "AA10"})
        by_cell = {comment["cell"]: comment["text"] for comment in comments}

        self.assertEqual(by_cell["P7"], "Not including CPUs")
        self.assertEqual(by_cell["P10"], "If an order is LATE + AFFECTED, it counts only on LATES")
        self.assertEqual(by_cell["Y10"], "1 solo shipment AFFECTED + LATE")
        self.assertEqual(by_cell["Z10"], "2 orders AFFECTED + LATE")
        self.assertEqual(by_cell["AA10"], "7 affected orders + Late")


if __name__ == "__main__":
    unittest.main()
