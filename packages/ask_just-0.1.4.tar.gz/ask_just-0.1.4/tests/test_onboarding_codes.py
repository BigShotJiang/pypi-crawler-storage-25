import json
import os
import sys
import tempfile
import unittest


ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
SCRIPTS = os.path.join(ROOT, "scripts")
if SCRIPTS not in sys.path:
    sys.path.insert(0, SCRIPTS)

from onboarding_codes import OnboardingCodeRegistry


class OnboardingCodeRegistryTest(unittest.TestCase):
    def make_registry(self, now=1000.0, code="JST-ABCD-1234"):
        tmp = tempfile.TemporaryDirectory()
        self.addCleanup(tmp.cleanup)
        path = os.path.join(tmp.name, "codes.json")
        clock = {"now": now}
        registry = OnboardingCodeRegistry(
            path,
            now=lambda: clock["now"],
            code_generator=lambda: code,
        )
        return registry, path, clock

    def test_create_stores_hash_not_plain_code_and_exchange_records_use(self):
        registry, path, _ = self.make_registry()

        created = registry.create(email="maya@example.com", label="Maya setup", created_by="admin")
        exchanged = registry.exchange("JST-ABCD-1234")

        self.assertTrue(created["ok"])
        self.assertEqual(created["code"], "JST-ABCD-1234")
        self.assertEqual(created["label"], "Maya setup")
        self.assertTrue(created["reusable"])
        self.assertIsNone(created["expires_at"])
        self.assertTrue(exchanged["ok"])
        self.assertEqual(exchanged["email"], "maya@example.com")
        self.assertEqual(exchanged["label"], "Maya setup")
        self.assertTrue(exchanged["reusable"])
        self.assertEqual(exchanged["exchange_count"], 1)
        with open(path, encoding="utf-8") as handle:
            stored = json.load(handle)
        serialized = json.dumps(stored)
        self.assertIn("code_sha256", serialized)
        self.assertNotIn("JST-ABCD-1234", serialized)
        self.assertIsNotNone(stored["codes"][0]["used_at"])
        self.assertIsNotNone(stored["codes"][0]["last_used_at"])

    def test_exchange_allows_reuse_until_revoked(self):
        registry, _, _ = self.make_registry()
        registry.create(email="maya@example.com")
        self.assertTrue(registry.exchange("JST-ABCD-1234")["ok"])

        second = registry.exchange("JST-ABCD-1234")

        self.assertTrue(second["ok"])
        self.assertEqual(second["exchange_count"], 2)

    def test_create_accepts_label_without_email(self):
        registry, _, _ = self.make_registry()

        created = registry.create(label="Pri setup", ttl_seconds=3600)

        self.assertTrue(created["ok"])
        self.assertEqual(created["label"], "Pri setup")
        self.assertEqual(created["email"], "")

    def test_exchange_rejects_expired_code(self):
        registry, _, clock = self.make_registry(now=1000.0)
        registry.create(label="Maya setup", ttl_seconds=60, reusable=False)
        clock["now"] = 2000.0

        result = registry.exchange("JST-ABCD-1234")

        self.assertFalse(result["ok"])
        self.assertEqual(result["gap"], "setup_code_expired")

    def test_exchange_rejects_revoked_code(self):
        registry, path, _ = self.make_registry()
        registry.create(label="Maya setup")
        with open(path, encoding="utf-8") as handle:
            payload = json.load(handle)
        payload["codes"][0]["revoked_at"] = "2026-05-13T00:00:00Z"
        with open(path, "w", encoding="utf-8") as handle:
            json.dump(payload, handle)

        result = registry.exchange("JST-ABCD-1234")

        self.assertFalse(result["ok"])
        self.assertEqual(result["gap"], "setup_code_revoked")

    def test_exchange_rejects_unknown_code(self):
        registry, _, _ = self.make_registry()

        result = registry.exchange("JST-NOPE-0000")

        self.assertFalse(result["ok"])
        self.assertEqual(result["gap"], "setup_code_not_found")


if __name__ == "__main__":
    unittest.main()
