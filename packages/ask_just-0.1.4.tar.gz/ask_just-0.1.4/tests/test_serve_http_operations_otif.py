import json
import os
import sqlite3
import sys
import unittest


ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
SCRIPTS = os.path.join(ROOT, "scripts")
if SCRIPTS not in sys.path:
    sys.path.insert(0, SCRIPTS)

import serve_http


class ServeHttpOperationsOtifTests(unittest.TestCase):
    def test_otif_adapter_reads_workbook_rows_without_generic_scan(self):
        conn = sqlite3.connect(":memory:")
        conn.row_factory = sqlite3.Row
        conn.executescript(
            """
            CREATE TABLE sources (source_id TEXT PRIMARY KEY, boundary_json TEXT);
            CREATE TABLE source_files (source_id TEXT, path TEXT, sha256 TEXT, modified_at TEXT, parsed TEXT, provenance_grain TEXT);
            CREATE TABLE atomic_rows (
                source_id TEXT,
                source_table TEXT,
                source_file TEXT,
                row_json TEXT,
                provenance_grain TEXT,
                row_key TEXT,
                row_index INTEGER
            );
            """
        )
        conn.execute("INSERT INTO sources VALUES (?, ?)", ("operations_logistics_otif_2024v2", "[]"))
        conn.execute(
            "INSERT INTO atomic_rows VALUES (?, ?, ?, ?, ?, ?, ?)",
            (
                "operations_logistics_otif_2024v2",
                "workbook_rows",
                "otif.xlsx",
                json.dumps({"row": 1, "label": "OTIF allocation order performance"}),
                json.dumps({"source_id": "operations_logistics_otif_2024v2", "locator": "otif.xlsx#row=1"}),
                "row:1",
                1,
            ),
        )

        rows = serve_http._operations_otif_rows(
            conn,
            "What logistics OTIF rows are visible for allocation or order performance?",
            5,
        )

        self.assertEqual(len(rows), 1)
        self.assertEqual(rows[0]["source_id"], "operations_logistics_otif_2024v2")
        self.assertIn("OTIF", rows[0]["snippet"])


if __name__ == "__main__":
    unittest.main()
