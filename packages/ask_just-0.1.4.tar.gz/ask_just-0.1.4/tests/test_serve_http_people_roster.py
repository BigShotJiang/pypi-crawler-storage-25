import json
import os
import sqlite3
import sys
import unittest


ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
SCRIPTS = os.path.join(ROOT, "scripts")
if SCRIPTS not in sys.path:
    sys.path.insert(0, SCRIPTS)

import serve_http


class ServeHttpPeopleRosterTests(unittest.TestCase):
    def make_conn(self):
        conn = sqlite3.connect(":memory:")
        conn.row_factory = sqlite3.Row
        conn.execute(
            """
            CREATE TABLE atomic_rows (
                source_id TEXT,
                source_table TEXT,
                source_file TEXT,
                sheet TEXT,
                row_index INTEGER,
                row_json TEXT,
                search_text TEXT,
                provenance_grain TEXT
            )
            """
        )
        conn.execute(
            """
            CREATE TABLE source_files (
                source_id TEXT,
                path TEXT,
                sha256 TEXT,
                modified_at TEXT,
                parsed INTEGER,
                provenance_grain TEXT
            )
            """
        )
        conn.execute("CREATE TABLE sources (source_id TEXT, boundary_json TEXT)")
        conn.execute(
            "INSERT INTO sources VALUES (?, ?)",
            ("hr_just_food_company_headcount", json.dumps(["headcount.xlsx"])),
        )
        provenance = json.dumps(
            {
                "source_id": "hr_just_food_company_headcount",
                "grain_id": "hr_just_food_company_headcount:test:row:2",
                "locator": "headcount.xlsx#sheet=Sheet1&row=2",
                "as_of": "2026-05-21T00:00:00Z",
            }
        )
        row_json = json.dumps(
            {
                "sheet": "Sheet1",
                "row_index": 2,
                "cells": [
                    {"address": "A2", "value": "Just Food Company"},
                    {"address": "B2", "value": "Alan"},
                    {"address": "C2", "value": "Gagne"},
                    {"address": "G2", "value": "FT Employee"},
                ],
            }
        )
        conn.execute(
            "INSERT INTO atomic_rows VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
            (
                "hr_just_food_company_headcount",
                "workbook_rows",
                "headcount.xlsx",
                "Sheet1",
                2,
                row_json,
                "Just Food Company Alan Gagne FT Employee",
                provenance,
            ),
        )
        contractor_json = json.dumps(
            {
                "sheet": "Sheet1",
                "row_index": 3,
                "cells": [
                    {"address": "A3", "value": "Just Food Company"},
                    {"address": "B3", "value": "Casey"},
                    {"address": "C3", "value": "Contractor"},
                    {"address": "G3", "value": "FT / perm Contractor"},
                ],
            }
        )
        conn.execute(
            "INSERT INTO atomic_rows VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
            (
                "hr_just_food_company_headcount",
                "workbook_rows",
                "headcount.xlsx",
                "Sheet1",
                3,
                contractor_json,
                "Just Food Company Casey FT perm Contractor",
                provenance,
            ),
        )
        return conn

    def test_active_headcount_matches_employee_status_not_literal_active(self):
        rows = serve_http._people_roster_rows(
            self.make_conn(),
            "hr_just_food_company_headcount",
            "Sheet1",
            "How many active Just Food Company employees are in the headcount source?",
            5,
        )

        self.assertEqual(len(rows), 2)
        self.assertEqual(rows[0]["source_id"], "hr_just_food_company_headcount")
        self.assertIn("source_links", rows[0])

    def test_contractor_question_prioritizes_contractor_rows(self):
        rows = serve_http._people_roster_rows(
            self.make_conn(),
            "hr_just_food_company_headcount",
            "Sheet1",
            "Which contractor rows are visible in the Just Food Company headcount source?",
            5,
        )

        self.assertEqual(len(rows), 1)
        self.assertIn("Contractor", rows[0]["snippet"])


if __name__ == "__main__":
    unittest.main()
