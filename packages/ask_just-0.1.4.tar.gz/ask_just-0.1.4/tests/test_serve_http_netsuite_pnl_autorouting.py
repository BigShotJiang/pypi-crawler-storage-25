import os
import sqlite3
import sys
import unittest


ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
SCRIPTS = os.path.join(ROOT, "scripts")
if SCRIPTS not in sys.path:
    sys.path.insert(0, SCRIPTS)

import serve_http


class ServeHttpNetSuitePnlAutoroutingTests(unittest.TestCase):
    def make_conn(self):
        conn = sqlite3.connect(":memory:")
        conn.row_factory = sqlite3.Row
        conn.execute("CREATE TABLE sources (source_id TEXT PRIMARY KEY)")
        conn.execute("INSERT INTO sources VALUES ('netsuite_pnl_monthly')")
        conn.execute("INSERT INTO sources VALUES ('netsuite_ap_open_bills')")
        conn.execute("INSERT INTO sources VALUES ('netsuite_ar_open_invoices')")
        conn.execute("INSERT INTO sources VALUES ('netsuite_items')")
        conn.execute("INSERT INTO sources VALUES ('scorecard_monthly_data')")
        return conn

    def test_netsuite_gross_cpg_sales_routes_to_pnl_metric_when_auto_source(self):
        plan = serve_http.build_source_query_plan(
            self.make_conn(),
            "In NetSuite accounting, what Gross CPG sales row is visible for January 2026?",
            requested_source="all",
        )

        self.assertEqual(len(plan), 1)
        self.assertEqual(plan[0]["source_id"], "netsuite_pnl_monthly")
        self.assertEqual(plan[0]["adapter_hint"], "netsuite_pnl_metric")

    def test_netsuite_gross_cpg_account_41005_stays_on_pnl_only(self):
        plan = serve_http.build_source_query_plan(
            self.make_conn(),
            "Exact row check: March 2026 NetSuite Gross CPG sales must show account 41005 and amount -4304106.73.",
            requested_source="all",
        )

        self.assertEqual(len(plan), 1)
        self.assertEqual(plan[0]["source_id"], "netsuite_pnl_monthly")
        self.assertEqual(plan[0]["adapter_hint"], "netsuite_pnl_metric")

    def test_scorecard_do_not_use_netsuite_does_not_route_to_pnl_metric(self):
        plan = serve_http.build_source_query_plan(
            self.make_conn(),
            "Do not use NetSuite: answer the March 2026 Scorecard gross margin with receipt row provenance.",
            requested_source="all",
        )

        self.assertFalse(any(step.get("source_id") == "netsuite_pnl_monthly" for step in plan))


if __name__ == "__main__":
    unittest.main()
