import json
import os
import sqlite3
import sys
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest import mock


ROOT = Path(__file__).resolve().parents[1]
SCRIPTS = ROOT / "scripts"
if str(SCRIPTS) not in sys.path:
    sys.path.insert(0, str(SCRIPTS))

import build_fresh_source_database as builder
import serve_http


SOURCE_ID = "operations_order_allocation"


class OrderAllocationSourceFamilyProofsTest(unittest.TestCase):
    def write_proof(self, directory, family_id, fetched_at="2026-05-06T14:45:00Z", row_count=12):
        path = directory / f"{family_id}.json"
        path.write_text(
            json.dumps(
                {
                    "family_id": family_id,
                    "freshness_date": "2026-05-06",
                    "fetched_at": fetched_at,
                    "source_time": fetched_at,
                    "source_uri": f"test://{family_id}",
                    "artifact_locator": f"test://{family_id}/artifact",
                    "row_count": row_count,
                    "sha256": f"{family_id}-sha",
                    "proof_type": "fixture_source_family_proof",
                }
            ),
            encoding="utf-8",
        )
        return path

    def build_with_proofs(self, proof_dir):
        source = dict(builder.SOURCES[SOURCE_ID])
        source["source_family_proof_dir"] = str(proof_dir)
        with tempfile.TemporaryDirectory() as tmp:
            artifact_dir = Path(tmp)
            with mock.patch.dict(builder.SOURCES, {SOURCE_ID: source}):
                builder.build(
                    SimpleNamespace(
                        artifact_dir=str(artifact_dir),
                        db=None,
                        status=None,
                        source_id=[SOURCE_ID],
                    )
                )
            db_path = artifact_dir / "source_index.sqlite"
            copied = Path(tempfile.mkdtemp()) / "source_index.sqlite"
            copied.write_bytes(db_path.read_bytes())
            return copied

    def test_builder_ingests_order_allocation_source_family_proofs_as_atomic_rows(self):
        with tempfile.TemporaryDirectory() as tmp:
            proof_dir = Path(tmp)
            self.write_proof(proof_dir, "inventory_vernon")
            db_path = self.build_with_proofs(proof_dir)

        conn = sqlite3.connect(db_path)
        conn.row_factory = sqlite3.Row
        self.addCleanup(lambda: db_path.unlink(missing_ok=True))
        try:
            row = conn.execute(
                """
                SELECT source_table, row_key, row_json, provenance_grain
                FROM atomic_rows
                WHERE source_id = ? AND source_table = 'operations_order_allocation_source_family_proofs'
                """,
                (SOURCE_ID,),
            ).fetchone()
            source = conn.execute(
                "SELECT accessible, atomically_queryable FROM sources WHERE source_id = ?",
                (SOURCE_ID,),
            ).fetchone()
        finally:
            conn.close()

        self.assertIsNotNone(row)
        payload = json.loads(row["row_json"])
        provenance = json.loads(row["provenance_grain"])
        self.assertEqual(row["row_key"], "2026-05-06:inventory_vernon")
        self.assertEqual(payload["family_id"], "inventory_vernon")
        self.assertEqual(payload["freshness_date"], "2026-05-06")
        self.assertEqual(payload["row_count"], 12)
        self.assertEqual(provenance["grain_type"], "application/source_family_proof")
        self.assertEqual(provenance["locator"], "test://inventory_vernon/artifact")
        self.assertEqual(source["accessible"], "partial")
        self.assertEqual(source["atomically_queryable"], "no")

    def test_prepare_uses_source_family_proof_rows_for_freshness_gap_report(self):
        with tempfile.TemporaryDirectory() as tmp:
            proof_dir = Path(tmp)
            self.write_proof(proof_dir, "inventory_vernon")
            self.write_proof(proof_dir, "inventory_bethlehem")
            db_path = self.build_with_proofs(proof_dir)
            status_path = Path(tmp) / "source_status.json"
            status_path.write_text(json.dumps({"generated_at": "2026-05-06T15:00:00Z"}), encoding="utf-8")

            service = serve_http.AskJustService(str(db_path), str(status_path))
            payload = service.order_allocation_prepare({"run_date": "2026-05-06"})

        self.assertFalse(payload["ok"])
        self.assertTrue(payload["blocked"])
        self.assertNotIn("inventory_vernon", payload["stale_or_missing_families"])
        self.assertNotIn("inventory_bethlehem", payload["stale_or_missing_families"])
        self.assertIn("inventory_vertical_evista", payload["stale_or_missing_families"])
        self.assertEqual(payload["fresh_source_families"]["inventory_vernon"]["row_count"], 12)
        self.assertEqual(payload["fresh_source_families"]["inventory_bethlehem"]["proof_type"], "fixture_source_family_proof")


if __name__ == "__main__":
    unittest.main()
