import json
import os
import threading
import sys
import tempfile
import unittest
import urllib.error
import urllib.request
from http.server import ThreadingHTTPServer
from unittest import mock


ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
SCRIPTS = os.path.join(ROOT, "scripts")
if SCRIPTS not in sys.path:
    sys.path.insert(0, SCRIPTS)

import personal_mail
import serve_http


class PersonalMailOverlayTest(unittest.TestCase):
    def test_registry_maps_bearer_token_without_storing_raw_token(self):
        token = "ask-just-personal-token"
        payload = {
            "users": [
                {
                    "label": "Josh",
                    "email": "jtetrick@ju.st",
                    "mailbox": "jtetrick@ju.st",
                    "token_sha256": personal_mail.token_sha256(token),
                    "tenant_id_env": "TEST_GRAPH_TENANT_ID",
                    "client_id_env": "TEST_GRAPH_CLIENT_ID",
                    "refresh_token_env": "TEST_GRAPH_REFRESH_TOKEN",
                }
            ]
        }
        with tempfile.NamedTemporaryFile("w", encoding="utf-8", delete=False) as handle:
            json.dump(payload, handle)
            registry_path = handle.name
        try:
            os.environ["TEST_GRAPH_TENANT_ID"] = "tenant"
            os.environ["TEST_GRAPH_CLIENT_ID"] = "client"
            os.environ["TEST_GRAPH_REFRESH_TOKEN"] = "refresh"
            registry = personal_mail.PersonalSourceRegistry.load(registry_path)
            principal = registry.principal_for_token(token)
            self.assertIsNotNone(principal)
            self.assertEqual(principal["kind"], "personal")
            self.assertEqual(principal["mailbox"], "jtetrick@ju.st")
            self.assertIsNone(registry.principal_for_token("wrong-token"))

            status = registry.public_status(principal=principal)
            self.assertTrue(status["ok"])
            self.assertEqual(status["personal_source_count"], 1)
            self.assertTrue(status["rows"][0]["shared_source_access"])
            self.assertFalse(status["rows"][0]["indexed_into_shared_sqlite"])
            self.assertTrue(status["rows"][0]["has_refresh_token"])
            self.assertFalse(status["rows"][0]["has_client_secret"])
        finally:
            os.unlink(registry_path)
            for key in ("TEST_GRAPH_TENANT_ID", "TEST_GRAPH_CLIENT_ID", "TEST_GRAPH_REFRESH_TOKEN"):
                os.environ.pop(key, None)

    def test_application_credential_status_and_mailbox_urls(self):
        entry = {
            "label": "Josh",
            "email": "jtetrick@ju.st",
            "mailbox": "jtetrick@ju.st",
            "token_sha256": personal_mail.token_sha256("personal-token"),
            "credential_mode": "application",
            "tenant_id_env": "TEST_GRAPH_TENANT_ID",
            "client_id_env": "TEST_GRAPH_CLIENT_ID",
            "client_secret_env": "TEST_GRAPH_CLIENT_SECRET",
        }
        try:
            os.environ["TEST_GRAPH_TENANT_ID"] = "tenant"
            os.environ["TEST_GRAPH_CLIENT_ID"] = "client"
            os.environ["TEST_GRAPH_CLIENT_SECRET"] = "secret"
            registry = personal_mail.PersonalSourceRegistry([entry])
            status = registry.public_status(registry.principal_for_token("personal-token"))
            self.assertEqual(status["rows"][0]["credential_mode"], "application")
            self.assertTrue(status["rows"][0]["has_client_secret"])
            self.assertIn(
                "/users/jtetrick%40ju.st/messages/message-1",
                personal_mail.graph_message_url(entry, "message-1"),
            )
            self.assertEqual(personal_mail.mailbox_base_url(entry), "https://graph.microsoft.com/v1.0/users/jtetrick%40ju.st")
        finally:
            for key in ("TEST_GRAPH_TENANT_ID", "TEST_GRAPH_CLIENT_ID", "TEST_GRAPH_CLIENT_SECRET"):
                os.environ.pop(key, None)

    def test_registry_load_permission_error_disables_overlay_without_crashing(self):
        with mock.patch("builtins.open", side_effect=PermissionError("nope")):
            registry = personal_mail.PersonalSourceRegistry.load("/etc/ask-just/personal-sources.json")

        self.assertEqual(registry.users, [])
        self.assertIsNone(registry.principal_for_token("token"))
        status = registry.public_status()
        self.assertTrue(status["ok"])
        self.assertEqual(status["personal_source_count"], 0)
        self.assertIn("PermissionError", status["registry_load_error"])

    def test_personal_message_normalization_keeps_private_overlay_provenance(self):
        message = {
            "id": "message-1",
            "internetMessageId": "<message-1@example.com>",
            "conversationId": "conversation-1",
            "subject": "Publix discussion",
            "from": {"emailAddress": {"name": "Alex", "address": "alex@example.com"}},
            "toRecipients": [{"emailAddress": {"name": "Josh", "address": "jtetrick@ju.st"}}],
            "receivedDateTime": "2026-05-05T13:00:00Z",
            "lastModifiedDateTime": "2026-05-05T13:05:00Z",
            "bodyPreview": "Here is the Publix update.",
            "webLink": "https://outlook.office.com/mail/id/message-1",
        }

        self.assertTrue(personal_mail.message_matches_query(message, "Publix Alex"))
        self.assertFalse(personal_mail.message_matches_query(message, "Kroger"))

        row = personal_mail.normalize_message(message, owner_email="jtetrick@ju.st")
        self.assertEqual(row["source_id"], "personal_mailbox")
        self.assertEqual(row["owner"], "jtetrick@ju.st")
        self.assertEqual(row["sender_address"], "alex@example.com")
        self.assertFalse(row["provenance"]["indexed_into_shared_sqlite"])
        self.assertEqual(row["provenance"]["acl_inherits_from"], "jtetrick@ju.st")

    def test_draft_payload_and_read_normalization(self):
        payload = personal_mail.draft_message_payload(
            "a@example.com; b@example.com",
            "Hello",
            "Body",
            cc="c@example.com",
        )
        self.assertEqual([row["emailAddress"]["address"] for row in payload["toRecipients"]], ["a@example.com", "b@example.com"])
        self.assertEqual(payload["ccRecipients"][0]["emailAddress"]["address"], "c@example.com")
        self.assertEqual(payload["body"]["content"], "Body")

        row = personal_mail.normalize_read_message(
            {
                "id": "message-1",
                "subject": "Hello",
                "from": {"emailAddress": {"address": "a@example.com"}},
                "body": {"contentType": "Text", "content": "Full body"},
            },
            owner_email="jtetrick@ju.st",
        )
        self.assertEqual(row["body"], "Full body")
        self.assertEqual(row["body_content_type"], "Text")
        self.assertEqual(row["provenance"]["grain_type"], "application/mail/message/full")

    def test_http_personal_status_requires_personal_token(self):
        personal_token = "personal-token"
        shared_token = "shared-token"
        registry = personal_mail.PersonalSourceRegistry(
            [
                {
                    "label": "Josh",
                    "email": "jtetrick@ju.st",
                    "mailbox": "jtetrick@ju.st",
                    "token_sha256": personal_mail.token_sha256(personal_token),
                }
            ],
            path="/tmp/personal-sources.json",
        )
        handler = serve_http.make_handler(object(), token=shared_token, personal_registry=registry)
        server = ThreadingHTTPServer(("127.0.0.1", 0), handler)
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        base = f"http://127.0.0.1:{server.server_port}"
        try:
            request = urllib.request.Request(
                f"{base}/personal-mail/status",
                headers={"Authorization": f"Bearer {personal_token}"},
            )
            with urllib.request.urlopen(request, timeout=5) as response:
                payload = json.loads(response.read().decode("utf-8"))
            self.assertTrue(payload["ok"])
            self.assertEqual(payload["personal_source_count"], 1)

            request = urllib.request.Request(
                f"{base}/personal-mail/status",
                headers={"Authorization": f"Bearer {shared_token}"},
            )
            with self.assertRaises(urllib.error.HTTPError) as raised:
                urllib.request.urlopen(request, timeout=5)
            self.assertEqual(raised.exception.code, 403)
            raised.exception.close()
        finally:
            server.shutdown()
            server.server_close()

    def test_http_personal_draft_requires_personal_token(self):
        personal_token = "personal-token"
        shared_token = "shared-token"
        registry = personal_mail.PersonalSourceRegistry(
            [
                {
                    "label": "Josh",
                    "email": "jtetrick@ju.st",
                    "mailbox": "jtetrick@ju.st",
                    "token_sha256": personal_mail.token_sha256(personal_token),
                }
            ],
            path="/tmp/personal-sources.json",
        )
        original = personal_mail.personal_mail_create_draft

        def fake_create_draft(entry, to, subject, body, cc=None, bcc=None, content_type="Text"):
            return {
                "ok": True,
                "action": "draft_created",
                "owner": entry["email"],
                "row": {
                    "message_id": "draft-1",
                    "subject": subject,
                    "to": personal_mail.parse_address_list(to),
                },
            }

        personal_mail.personal_mail_create_draft = fake_create_draft
        handler = serve_http.make_handler(object(), token=shared_token, personal_registry=registry)
        server = ThreadingHTTPServer(("127.0.0.1", 0), handler)
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        base = f"http://127.0.0.1:{server.server_port}"
        try:
            body = json.dumps({"to": "a@example.com", "subject": "Hello", "body": "Draft"}).encode("utf-8")
            request = urllib.request.Request(
                f"{base}/personal-mail/draft",
                data=body,
                headers={
                    "Authorization": f"Bearer {personal_token}",
                    "Content-Type": "application/json",
                },
                method="POST",
            )
            with urllib.request.urlopen(request, timeout=5) as response:
                payload = json.loads(response.read().decode("utf-8"))
            self.assertTrue(payload["ok"])
            self.assertEqual(payload["action"], "draft_created")
            self.assertEqual(payload["row"]["message_id"], "draft-1")
        finally:
            personal_mail.personal_mail_create_draft = original
            server.shutdown()
            server.server_close()


if __name__ == "__main__":
    unittest.main()
