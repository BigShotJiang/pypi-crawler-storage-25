import json
import os
import subprocess
import sqlite3
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
import unittest


ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
TEST_URL = "http://127.0.0.1:8794"
BASE_SOURCE_IDS = (
    "rd_powerjacks_formulations",
    "spins_plant_based_meat_powertabs",
    "scorecard_monthly_data",
    "scorecard_ops_metrics",
    "batch_release_app",
)
NETSUITE_SOURCE_IDS = (
    "netsuite_account_catalog",
    "netsuite_items",
    "netsuite_pnl_monthly",
    "netsuite_ar_open_invoices",
    "netsuite_ap_open_bills",
    "netsuite_inventory_snapshot",
)
NETSUITE_REQUIRED_ENV = (
    "NETSUITE_ACCOUNT_ID",
    "NETSUITE_CONSUMER_KEY",
    "NETSUITE_CONSUMER_SECRET",
    "NETSUITE_TOKEN_ID",
    "NETSUITE_TOKEN_SECRET",
)
REQUIRED_PROVENANCE_FIELDS = {
    "grain_id",
    "source_id",
    "source_type",
    "grain_type",
    "locator",
    "coverage_depth",
    "source_modified_time",
    "as_of",
    "extracted_at",
    "extractor_id",
    "extractor_version",
    "prompt_hash",
    "confidence",
    "confidence_basis",
    "needs_review",
    "sensitivity",
    "acl_inherits_from",
    "entity_ids",
    "derived_from",
    "valid_at_extraction",
}


def has_netsuite_credentials():
    return all(os.environ.get(name) for name in NETSUITE_REQUIRED_ENV)


def get_json(path):
    with urllib.request.urlopen(f"{TEST_URL}{path}", timeout=10) as response:
        return response.status, json.loads(response.read().decode("utf-8"))


def post_json(path, payload):
    request = urllib.request.Request(
        f"{TEST_URL}{path}",
        data=json.dumps(payload).encode("utf-8"),
        headers={"Content-Type": "application/json", "Accept": "application/json"},
        method="POST",
    )
    try:
        with urllib.request.urlopen(request, timeout=10) as response:
            return response.status, json.loads(response.read().decode("utf-8"))
    except urllib.error.HTTPError as exc:
        try:
            return exc.code, json.loads(exc.read().decode("utf-8"))
        finally:
            exc.close()


def assert_source_provenance(testcase, provenance, source_id):
    testcase.assertFalse(REQUIRED_PROVENANCE_FIELDS - set(provenance))
    testcase.assertEqual(provenance["source_id"], source_id)
    testcase.assertTrue(provenance["grain_id"])
    testcase.assertTrue(provenance["locator"])
    testcase.assertTrue(provenance["extracted_at"])
    testcase.assertEqual(provenance["extractor_id"], "scripts/build_fresh_source_database.py")
    testcase.assertEqual(provenance["extractor_version"], "fresh-source-v1")
    testcase.assertEqual(provenance["valid_at_extraction"], True)
    testcase.assertEqual(provenance["confidence"], 1.0)


class AskJustFreshSourcePlaneTest(unittest.TestCase):
    server = None
    source_ids = BASE_SOURCE_IDS
    netsuite_enabled = False

    @classmethod
    def setUpClass(cls):
        cls.netsuite_enabled = has_netsuite_credentials()
        cls.source_ids = BASE_SOURCE_IDS + (NETSUITE_SOURCE_IDS if cls.netsuite_enabled else ())
        build_args = [sys.executable, "scripts/build_fresh_source_database.py"]
        for source_id in cls.source_ids:
            build_args.extend(["--source-id", source_id])
        subprocess.run(
            build_args,
            cwd=ROOT,
            check=True,
            stdout=subprocess.DEVNULL,
        )
        cls.server = subprocess.Popen(
            [
                sys.executable,
                "scripts/serve_http.py",
                "--host",
                "127.0.0.1",
                "--port",
                "8794",
            ],
            cwd=ROOT,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            text=True,
        )
        for _ in range(50):
            try:
                status, payload = get_json("/health")
                if status == 200 and payload.get("ok"):
                    break
            except Exception:
                time.sleep(0.1)
        else:
            raise RuntimeError("Ask Just fresh-source test server did not start")

    @classmethod
    def tearDownClass(cls):
        if cls.server:
            cls.server.terminate()
            try:
                cls.server.wait(timeout=5)
            except subprocess.TimeoutExpired:
                cls.server.kill()

    def test_health_summary_and_sources_are_wired_to_fresh_db(self):
        _, health_payload = get_json("/health?deep=1")
        self.assertTrue(health_payload["ok"])
        health = health_payload["health"]
        self.assertEqual(health["source_count"], len(self.source_ids))
        self.assertGreaterEqual(health["source_file_count"], 3460)
        self.assertGreaterEqual(health["atomic_row_count"], 280000)
        self.assertFalse(health["external_answer_artifacts_used"])

        _, summary = get_json("/summary")
        self.assertTrue(summary["ok"])
        self.assertEqual(summary["source_count"], len(self.source_ids))
        self.assertGreaterEqual(summary["atomic_row_count"], 280000)

        _, sources = get_json("/sources")
        source_rows = {row["source_id"]: row for row in sources["rows"]}
        for source_id in self.source_ids:
            self.assertEqual(source_rows[source_id]["mapped"], "yes")
            self.assertEqual(source_rows[source_id]["accessible"], "yes")
            self.assertEqual(source_rows[source_id]["atomically_queryable"], "yes")

    def test_source_scoped_sql_indexes_are_present(self):
        db_path = os.path.join(ROOT, "artifacts", "ask-just-fresh-source-plane", "source_index.sqlite")
        conn = sqlite3.connect(db_path)
        try:
            atomic_indexes = {
                row[1]
                for row in conn.execute("PRAGMA index_list(atomic_rows)").fetchall()
            }
            source_file_indexes = {
                row[1]
                for row in conn.execute("PRAGMA index_list(source_files)").fetchall()
            }
            scorecard_indexes = {
                row[1]
                for row in conn.execute("PRAGMA index_list(scorecard_monthly_metrics)").fetchall()
            }
            ops_indexes = {
                row[1]
                for row in conn.execute("PRAGMA index_list(scorecard_ops_metrics)").fetchall()
            }
        finally:
            conn.close()

        self.assertIn("idx_atomic_rows_source", atomic_indexes)
        self.assertIn("idx_atomic_rows_source_file", atomic_indexes)
        self.assertIn("idx_source_files_source", source_file_indexes)
        self.assertIn("idx_scorecard_monthly_metrics_metric_record", scorecard_indexes)
        self.assertIn("idx_scorecard_ops_metrics_metric_field", ops_indexes)

    def test_cli_and_http_query_return_atomic_provenance(self):
        result = subprocess.run(
            [
                sys.executable,
                "scripts/ask_just.py",
                "--url",
                TEST_URL,
                "query",
                "Mung Protein",
                "--source",
                "rd_powerjacks_formulations",
                "--kind",
                "atomic",
                "--limit",
                "3",
                "--with-health",
            ],
            cwd=ROOT,
            check=True,
            text=True,
            capture_output=True,
        )
        payload = json.loads(result.stdout)
        self.assertTrue(payload["ok"])
        self.assertGreaterEqual(len(payload["rows"]), 1)
        provenance = json.loads(payload["rows"][0]["provenance_grain"])
        assert_source_provenance(self, provenance, "rd_powerjacks_formulations")
        self.assertEqual(provenance["source_id"], "rd_powerjacks_formulations")
        self.assertEqual(provenance["grain_type"], "workbook/sheet/row/column/cell")
        self.assertIn("Power Jacks Formulation Tracker-3.5.2026.xlsx", provenance["locator"])

        status, query_payload = post_json(
            "/query",
            {
                "question": "Mung Protein",
                "source": "rd_powerjacks_formulations",
                "kind": "atomic",
                "limit": 3,
                "include_health": True,
            },
        )
        self.assertEqual(status, 200)
        self.assertTrue(query_payload["ok"])
        self.assertEqual(query_payload["health"]["source_count"], len(self.source_ids))

    def test_spins_plant_based_meat_source_returns_xlsb_provenance(self):
        status, payload = post_json(
            "/sql",
            {
                "sql": (
                    "select 'atomic_row' as kind, source_id, source_table as title, "
                    "source_file as heading_path, provenance_grain "
                    "from atomic_rows "
                    "where source_id = 'spins_plant_based_meat_powertabs' "
                    "and source_table = 'workbook_rows' "
                    "and sheet = 'Retailer' "
                    "and row_index = 16"
                ),
                "limit": 1,
            },
        )
        self.assertEqual(status, 200)
        self.assertTrue(payload["ok"])
        self.assertEqual(len(payload["rows"]), 1)
        match = payload["rows"][0]
        provenance = json.loads(match["provenance_grain"])
        assert_source_provenance(self, provenance, "spins_plant_based_meat_powertabs")
        self.assertEqual(provenance["grain_type"], "workbook/sheet/row/column/cell")
        self.assertIn("SPINS PowerTabs Eat Just Plant Based Meat Data Ending 04-19-26", provenance["locator"])
        self.assertIn("source_links", match)
        source_file_links = [link for link in match["source_links"] if link["rel"] == "source_file"]
        self.assertEqual(len(source_file_links), 1)
        self.assertEqual(source_file_links[0]["source_id"], "spins_plant_based_meat_powertabs")
        self.assertEqual(source_file_links[0]["kind"], "local_file")
        self.assertTrue(source_file_links[0]["openable"])
        self.assertTrue(source_file_links[0]["uri"].endswith("SPINS PowerTabs Eat Just Plant Based Meat Data Ending 04-19-26 (1).xlsb"))
        evidence_links = [link for link in match["source_links"] if link["rel"] == "evidence_locator"]
        self.assertEqual(len(evidence_links), 1)
        self.assertIn("#sheet=Retailer&row=16", evidence_links[0]["uri"])

        status, sql_payload = post_json(
            "/sql",
            {
                "sql": (
                    "select count(*) as package_parts from atomic_rows "
                    "where source_id = 'spins_plant_based_meat_powertabs' "
                    "and source_table = 'workbook_package_parts'"
                ),
                "limit": 1,
            },
        )
        self.assertEqual(status, 200)
        self.assertGreaterEqual(sql_payload["rows"][0]["package_parts"], 200)

        status, sku_payload = post_json(
            "/sql",
            {
                "sql": (
                    "select row_json from atomic_rows "
                    "where source_id = 'spins_plant_based_meat_powertabs' "
                    "and source_table = 'pivot_cache_records' "
                    "and search_text like '%WALMART CORP - RMA%' "
                    "and search_text like '%Just Meat Plant Based%'"
                ),
                "limit": 20,
            },
        )
        self.assertEqual(status, 200)
        walmart_sku_rows = [
            json.loads(row["row_json"])["fields"]
            for row in sku_payload["rows"]
            if json.loads(row["row_json"])["fields"].get("Time Period") == "4 Weeks"
        ]
        self.assertEqual(
            {row["Just Meat SKU"] for row in walmart_sku_rows},
            {"Original", "Sesame Ginger", "Buffalo", "Chili-Lime"},
        )
        self.assertTrue(all(row["Geography"] == "WALMART CORP - RMA" for row in walmart_sku_rows))
        self.assertTrue(all(row["Time Period End Date"] == "2026-04-19" for row in walmart_sku_rows))

        weekly_by_sku = {
            row["Just Meat SKU"]: round(row["Weekly u/s/w"], 1)
            for row in walmart_sku_rows
        }
        self.assertEqual(
            weekly_by_sku,
            {"Original": 2.9, "Sesame Ginger": 2.3, "Buffalo": 1.5, "Chili-Lime": 1.7},
        )
        self.assertTrue(
            all("Average Weekly Units Per Store Selling Per Item" in row for row in walmart_sku_rows)
        )

    def test_source_links_endpoint_resolves_provenance_across_lane_shapes(self):
        status, spins_payload = post_json(
            "/source-links",
            {
                "source_id": "spins_plant_based_meat_powertabs",
                "locator": "/Users/josh/Downloads/SPINS PowerTabs Eat Just Plant Based Meat Data Ending 04-19-26 (1).xlsb#sheet=Retailer&row=16",
            },
        )
        self.assertEqual(status, 200)
        self.assertTrue(spins_payload["ok"])
        self.assertEqual(spins_payload["source_links"][0]["kind"], "local_file")
        self.assertTrue(spins_payload["source_links"][0]["openable"])

        status, scorecard_payload = post_json(
            "/source-links",
            {
                "source_id": "scorecard_monthly_data",
                "locator": "https://just-scorecard.vercel.app/api/read-data?key=monthly_data#record=7&month=Mar%20%2726&field=values.gross_margin",
            },
        )
        self.assertEqual(status, 200)
        self.assertTrue(scorecard_payload["ok"])
        api_links = [link for link in scorecard_payload["source_links"] if link["rel"] == "source_file"]
        self.assertEqual(api_links[0]["kind"], "url")
        self.assertTrue(api_links[0]["openable"])
        self.assertEqual(api_links[0]["uri"], "https://just-scorecard.vercel.app/api/read-data?key=monthly_data")

        if self.netsuite_enabled:
            status, netsuite_payload = post_json(
                "/source-links",
                {
                    "source_id": "netsuite_pnl_monthly",
                    "locator": "netsuite:/suiteql/pnl#period=2026-03&metric=gross_margin",
                },
            )
            self.assertEqual(status, 200)
            self.assertTrue(netsuite_payload["ok"])
            suiteql_links = [link for link in netsuite_payload["source_links"] if link["rel"] == "source_file"]
            self.assertEqual(suiteql_links[0]["kind"], "structured_locator")
            self.assertFalse(suiteql_links[0]["openable"])
            self.assertEqual(suiteql_links[0]["uri"], "netsuite:/suiteql/pnl?periods=2026-01,2026-02,2026-03,2026-04,2026-05")

    def test_every_active_source_lane_resolves_at_least_one_source_link(self):
        status, sample_payload = post_json(
            "/sql",
            {
                "sql": (
                    "select source_id, min(provenance_grain) as provenance_grain "
                    "from atomic_rows "
                    "group by source_id "
                    "order by source_id"
                ),
                "limit": 50,
            },
        )
        self.assertEqual(status, 200)
        self.assertTrue(sample_payload["ok"])
        self.assertEqual(len(sample_payload["rows"]), len(self.source_ids))
        for row in sample_payload["rows"]:
            with self.subTest(source_id=row["source_id"]):
                self.assertIn("source_links", row)
                self.assertTrue(row["source_links"])
                self.assertTrue(any(link["rel"] == "source_file" for link in row["source_links"]))

    def test_scorecard_sources_return_field_level_provenance(self):
        cases = [
            (
                "Mar gross revenue",
                "scorecard_monthly_data",
                "scorecard_monthly_metric_fields",
                "Mar '26:gross_revenue",
                4.66,
            ),
            (
                "Protein on Hold mar",
                "scorecard_ops_metrics",
                "scorecard_ops_metric_fields",
                "Upstream Inventory:Protein on Hold (MT):mar",
                46,
            ),
        ]
        for query, source_id, source_table, row_key, expected_value in cases:
            result = subprocess.run(
                [
                    sys.executable,
                    "scripts/ask_just.py",
                    "--url",
                    TEST_URL,
                    "query",
                    query,
                    "--source",
                    source_id,
                    "--kind",
                    "atomic",
                    "--limit",
                    "3",
                    "--with-health",
                ],
                cwd=ROOT,
                check=True,
                text=True,
                capture_output=True,
            )
            payload = json.loads(result.stdout)
            self.assertTrue(payload["ok"])
            match = None
            for row in payload["rows"]:
                if row["title"] == source_table:
                    match = row
                    break
            self.assertIsNotNone(match)
            provenance = json.loads(match["provenance_grain"])
            assert_source_provenance(self, provenance, source_id)
            self.assertEqual(provenance["source_id"], source_id)
            self.assertEqual(provenance["grain_type"], "application/record/field")

            escaped_source_id = source_id.replace("'", "''")
            escaped_row_key = row_key.replace("'", "''")
            status, sql_payload = post_json(
                "/sql",
                {
                    "sql": (
                        "select row_json from atomic_rows "
                        f"where source_id = '{escaped_source_id}' "
                        f"and row_key = '{escaped_row_key}'"
                    ),
                    "limit": 1,
                },
            )
            self.assertEqual(status, 200)
            row_json = json.loads(sql_payload["rows"][0]["row_json"])
            self.assertEqual(row_json["value"], expected_value)

    def test_batch_release_source_returns_field_level_provenance(self):
        result = subprocess.run(
            [
                sys.executable,
                "scripts/ask_just.py",
                "--url",
                TEST_URL,
                "query",
                "held batches",
                "--source",
                "batch_release_app",
                "--kind",
                "atomic",
                "--limit",
                "6",
                "--with-health",
            ],
            cwd=ROOT,
            check=True,
            text=True,
            capture_output=True,
        )
        payload = json.loads(result.stdout)
        self.assertTrue(payload["ok"])
        self.assertGreaterEqual(len(payload["rows"]), 1)
        match = None
        for row in payload["rows"]:
            if row["title"] == "batch_release_record_fields":
                match = row
                break
        self.assertIsNotNone(match)
        provenance = json.loads(match["provenance_grain"])
        assert_source_provenance(self, provenance, "batch_release_app")
        self.assertEqual(provenance["source_id"], "batch_release_app")
        self.assertEqual(provenance["grain_type"], "application/record/field")

        status, sql_payload = post_json(
            "/sql",
            {
                "sql": (
                    "select count(*) as held_status_rows from atomic_rows "
                    "where source_id = 'batch_release_app' "
                    "and row_key like '%:status' "
                    "and row_json like '%\"value\":\"held\"%'"
                ),
                "limit": 1,
            },
        )
        self.assertEqual(status, 200)
        self.assertGreaterEqual(sql_payload["rows"][0]["held_status_rows"], 1)

        status, sql_payload = post_json(
            "/sql",
            {
                "sql": (
                    "select count(*) as source_files from source_files "
                    "where source_id = 'batch_release_app'"
                ),
                "limit": 1,
            },
        )
        self.assertEqual(status, 200)
        self.assertGreaterEqual(sql_payload["rows"][0]["source_files"], 3400)

        status, sql_payload = post_json(
            "/sql",
            {
                "sql": (
                    "select source_table, count(*) as rows from atomic_rows "
                    "where source_id = 'batch_release_app' "
                    "and source_table in ("
                    "'batch_release_record_fields',"
                    "'batch_release_thresholds_fields',"
                    "'batch_release_audit_log_fields',"
                    "'batch_release_micro_fields',"
                    "'batch_release_product_tests_fields',"
                    "'batch_release_iqkitchen_marination_fields'"
                    ") group by source_table"
                ),
                "limit": 20,
            },
        )
        self.assertEqual(status, 200)
        table_counts = {row["source_table"]: row["rows"] for row in sql_payload["rows"]}
        for source_table in (
            "batch_release_record_fields",
            "batch_release_thresholds_fields",
            "batch_release_audit_log_fields",
            "batch_release_micro_fields",
            "batch_release_product_tests_fields",
            "batch_release_iqkitchen_marination_fields",
        ):
            self.assertGreater(table_counts.get(source_table, 0), 0)

        status, sql_payload = post_json(
            "/sql",
            {
                "sql": (
                    "select provenance_grain from atomic_rows "
                    "where source_id = 'batch_release_app' "
                    "and source_table = 'batch_release_thresholds_fields' "
                    "limit 1"
                ),
                "limit": 1,
            },
        )
        self.assertEqual(status, 200)
        app_state_provenance = json.loads(sql_payload["rows"][0]["provenance_grain"])
        assert_source_provenance(self, app_state_provenance, "batch_release_app")
        self.assertEqual(app_state_provenance["grain_type"], "application/app_state_key/field")

        status, sql_payload = post_json(
            "/sql",
            {
                "sql": (
                    "select row_key, provenance_grain from atomic_rows "
                    "where source_id = 'batch_release_app' "
                    "and source_table = 'batch_release_app_state_writer_flows' "
                    "and row_json like '%SharePoint%' "
                    "limit 1"
                ),
                "limit": 1,
            },
        )
        self.assertEqual(status, 200)
        self.assertGreaterEqual(len(sql_payload["rows"]), 1)
        flow_provenance = json.loads(sql_payload["rows"][0]["provenance_grain"])
        assert_source_provenance(self, flow_provenance, "batch_release_app")
        self.assertEqual(flow_provenance["grain_type"], "application/data_flow/write")

    def test_netsuite_items_source_returns_live_suiteql_field_provenance(self):
        if not self.netsuite_enabled:
            self.skipTest("requires NetSuite credentials")
        result = subprocess.run(
            [
                sys.executable,
                "scripts/ask_just.py",
                "--url",
                TEST_URL,
                "query",
                "Mung Bean",
                "--source",
                "netsuite_items",
                "--kind",
                "atomic",
                "--limit",
                "8",
                "--with-health",
            ],
            cwd=ROOT,
            check=True,
            text=True,
            capture_output=True,
        )
        payload = json.loads(result.stdout)
        self.assertTrue(payload["ok"])
        self.assertGreaterEqual(len(payload["rows"]), 1)
        match = None
        for row in payload["rows"]:
            if row["title"] == "netsuite_item_fields":
                match = row
                break
        self.assertIsNotNone(match)
        provenance = json.loads(match["provenance_grain"])
        assert_source_provenance(self, provenance, "netsuite_items")
        self.assertEqual(provenance["source_id"], "netsuite_items")
        self.assertEqual(provenance["grain_type"], "application/record/field")
        self.assertEqual(provenance["source_type"], "live_app:netsuite_suiteql")

        status, sql_payload = post_json(
            "/sql",
            {
                "sql": (
                    "select count(distinct json_extract(row_json, '$.record_id')) as items "
                    "from atomic_rows where source_id = 'netsuite_items'"
                ),
                "limit": 1,
            },
        )
        self.assertEqual(status, 200)
        self.assertGreaterEqual(sql_payload["rows"][0]["items"], 1)

    def test_netsuite_account_catalog_indexes_root_items_and_record_types(self):
        if not self.netsuite_enabled:
            self.skipTest("requires NetSuite credentials")
        result = subprocess.run(
            [
                sys.executable,
                "scripts/ask_just.py",
                "--url",
                TEST_URL,
                "query",
                "vendorBill suiteql row count",
                "--source",
                "netsuite_account_catalog",
                "--kind",
                "atomic",
                "--limit",
                "5",
                "--with-health",
            ],
            cwd=ROOT,
            check=True,
            text=True,
            capture_output=True,
        )
        payload = json.loads(result.stdout)
        self.assertTrue(payload["ok"])
        match = None
        for row in payload["rows"]:
            if row["title"] == "netsuite_record_type_catalog":
                match = row
                break
        self.assertIsNotNone(match)
        provenance = json.loads(match["provenance_grain"])
        assert_source_provenance(self, provenance, "netsuite_account_catalog")
        self.assertEqual(provenance["source_id"], "netsuite_account_catalog")
        self.assertEqual(provenance["grain_type"], "account_catalog/record_type/schema_count")
        self.assertEqual(provenance["source_type"], "live_app:netsuite_account_catalog_audit")

        status, vendor_payload = post_json(
            "/sql",
            {
                "sql": (
                    "select row_json from atomic_rows "
                    "where source_id = 'netsuite_account_catalog' "
                    "and row_key = 'vendorBill:catalog_audit'"
                ),
                "limit": 1,
            },
        )
        self.assertEqual(status, 200)
        row_json = json.loads(vendor_payload["rows"][0]["row_json"])
        self.assertEqual(row_json["record_type"], "vendorBill")
        self.assertTrue(row_json["metadata_accessible"])
        self.assertTrue(row_json["suiteql_accessible"])
        self.assertGreaterEqual(row_json["suiteql_row_count"], 1)

        root_result = subprocess.run(
            [
                sys.executable,
                "scripts/ask_just.py",
                "--url",
                TEST_URL,
                "query",
                "customrecord outlook sync part tracker",
                "--source",
                "netsuite_account_catalog",
                "--kind",
                "atomic",
                "--limit",
                "5",
                "--with-health",
            ],
            cwd=ROOT,
            check=True,
            text=True,
            capture_output=True,
        )
        root_payload = json.loads(root_result.stdout)
        self.assertTrue(root_payload["ok"])
        root_match = None
        for row in root_payload["rows"]:
            if row["title"] == "netsuite_metadata_catalog_root_items":
                root_match = row
                break
        self.assertIsNotNone(root_match)
        root_provenance = json.loads(root_match["provenance_grain"])
        assert_source_provenance(self, root_provenance, "netsuite_account_catalog")
        self.assertEqual(root_provenance["grain_type"], "account_catalog/root_item")

        status, root_sql_payload = post_json(
            "/sql",
            {
                "sql": (
                    "select row_json from atomic_rows "
                    "where source_id = 'netsuite_account_catalog' "
                    "and source_table = 'netsuite_metadata_catalog_root_items' "
                    "and row_key = 'metadata_catalog_root:customrecord_outlook_sync_part_tracker'"
                ),
                "limit": 1,
            },
        )
        self.assertEqual(status, 200)
        row_json = json.loads(root_sql_payload["rows"][0]["row_json"])
        self.assertEqual(row_json["name"], "customrecord_outlook_sync_part_tracker")

        status, sql_payload = post_json(
            "/sql",
            {
                "sql": (
                    "select source_table, count(*) as rows from atomic_rows "
                    "where source_id = 'netsuite_account_catalog' "
                    "group by source_table order by source_table"
                ),
                "limit": 10,
            },
        )
        self.assertEqual(status, 200)
        counts = {row["source_table"]: row["rows"] for row in sql_payload["rows"]}
        self.assertEqual(counts["netsuite_metadata_catalog_root_items"], 1076)
        self.assertEqual(counts["netsuite_record_type_catalog"], 71)

    def test_netsuite_finance_sources_return_precise_rows_and_metrics(self):
        if not self.netsuite_enabled:
            self.skipTest("requires NetSuite credentials")
        cases = [
            (
                "March 2026 net revenue",
                "netsuite_pnl_monthly",
                "netsuite_pnl_period_metrics",
                "application/period/metric",
            ),
            (
                "open AR invoices",
                "netsuite_ar_open_invoices",
                "netsuite_ar_open_invoice_fields",
                "application/transaction/field",
            ),
            (
                "open AP bills",
                "netsuite_ap_open_bills",
                "netsuite_ap_open_bill_fields",
                "application/transaction/field",
            ),
            (
                "inventory on hand",
                "netsuite_inventory_snapshot",
                "netsuite_inventory_location_fields",
                "application/item/location/field",
            ),
        ]
        for query, source_id, source_table, grain_type in cases:
            result = subprocess.run(
                [
                    sys.executable,
                    "scripts/ask_just.py",
                    "--url",
                    TEST_URL,
                    "query",
                    query,
                    "--source",
                    source_id,
                    "--kind",
                    "atomic",
                    "--limit",
                    "5",
                    "--with-health",
                ],
                cwd=ROOT,
                check=True,
                text=True,
                capture_output=True,
            )
            payload = json.loads(result.stdout)
            self.assertTrue(payload["ok"])
            match = None
            for row in payload["rows"]:
                if row["title"] == source_table:
                    match = row
                    break
            self.assertIsNotNone(match, source_id)
            provenance = json.loads(match["provenance_grain"])
            assert_source_provenance(self, provenance, source_id)
            self.assertEqual(provenance["source_id"], source_id)
            self.assertEqual(provenance["grain_type"], grain_type)
            self.assertEqual(provenance["source_type"], "live_app:netsuite_suiteql")

        status, pnl_payload = post_json(
            "/sql",
            {
                "sql": (
                    "select row_json from atomic_rows "
                    "where source_id = 'netsuite_pnl_monthly' "
                    "and row_key = '2026-03:net_revenue'"
                ),
                "limit": 1,
            },
        )
        self.assertEqual(status, 200)
        net_revenue = json.loads(pnl_payload["rows"][0]["row_json"])
        self.assertEqual(net_revenue["metric"], "net_revenue")
        self.assertGreater(net_revenue["value"], 4000000)

        for source_id, min_rows in (
            ("netsuite_ar_open_invoices", 1),
            ("netsuite_ap_open_bills", 1),
            ("netsuite_inventory_snapshot", 1),
        ):
            status, count_payload = post_json(
                "/sql",
                {
                    "sql": f"select count(*) as rows from atomic_rows where source_id = '{source_id}'",
                    "limit": 1,
                },
            )
            self.assertEqual(status, 200)
            self.assertGreaterEqual(count_payload["rows"][0]["rows"], min_rows)

    def test_sql_endpoint_is_read_only_for_fresh_db(self):
        status, payload = post_json(
            "/sql",
            {
                "sql": "select count(*) as rows from atomic_rows where source_id = 'rd_powerjacks_formulations'",
                "limit": 1,
            },
        )
        self.assertEqual(status, 200)
        self.assertTrue(payload["ok"])
        self.assertGreater(payload["rows"][0]["rows"], 536)

        status, payload = post_json("/sql", {"sql": "delete from sources", "limit": 1})
        self.assertEqual(status, 400)
        self.assertFalse(payload["ok"])
        self.assertIn("read-only", payload["error"])

    def test_strict_source_goal_completion_table_covers_declared_lanes(self):
        if not os.environ.get("ASK_JUST_RUN_FULL_SOURCE_GOAL_TESTS"):
            self.skipTest("requires a full all-lanes source build")
        result = subprocess.run(
            [sys.executable, "scripts/verify_source_goal_complete.py"],
            cwd=ROOT,
            check=True,
            text=True,
            capture_output=True,
        )
        self.assertIn("Ask Just source goal complete: 41/41", result.stdout)
        strict_table_path = os.path.join(
            ROOT,
            "artifacts",
            "ask-just-fresh-source-plane",
            "strict_source_completion_table.json",
        )
        with open(strict_table_path, encoding="utf-8") as handle:
            payload = json.load(handle)
        self.assertEqual(payload["source_count"], 41)
        self.assertEqual(payload["fully_source_count"], 41)
        self.assertEqual(payload["not_fully_source_count"], 0)
        self.assertEqual([row for row in payload["rows"] if row["status"] != "fully_source"], [])


if __name__ == "__main__":
    unittest.main()
