import json
import os
import sqlite3
import sys
import unittest


ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
SCRIPTS = os.path.join(ROOT, "scripts")
if SCRIPTS not in sys.path:
    sys.path.insert(0, SCRIPTS)

import serve_http


class ServeHttpNetSuitePnlRoutingTests(unittest.TestCase):
    def make_conn(self):
        conn = sqlite3.connect(":memory:")
        conn.row_factory = sqlite3.Row
        conn.executescript(
            """
            CREATE TABLE sources (source_id TEXT PRIMARY KEY, boundary_json TEXT);
            CREATE TABLE source_files (
                source_id TEXT,
                path TEXT,
                sha256 TEXT,
                modified_at TEXT,
                parsed TEXT,
                provenance_grain TEXT
            );
            CREATE TABLE atomic_rows (
                source_id TEXT,
                source_table TEXT,
                source_file TEXT,
                row_json TEXT,
                provenance_grain TEXT,
                row_key TEXT,
                row_index INTEGER
            );
            """
        )
        return conn

    def insert_pnl_row(self, conn, row_key, account_name="41015 Shipping and Handling"):
        conn.execute("INSERT INTO sources VALUES (?, ?)", ("netsuite_pnl_monthly", "[]"))
        conn.execute(
            "INSERT INTO source_files VALUES (?, ?, ?, ?, ?, ?)",
            ("netsuite_pnl_monthly", "netsuite:/suiteql/pnl", "abc", "now", "yes", "{}"),
        )
        conn.execute(
            "INSERT INTO atomic_rows VALUES (?, ?, ?, ?, ?, ?, ?)",
            (
                "netsuite_pnl_monthly",
                "netsuite_pnl_account_fields",
                "netsuite:/suiteql/pnl",
                json.dumps({"account_name": account_name, "row_key": row_key}),
                json.dumps({"source_id": "netsuite_pnl_monthly", "locator": f"netsuite:/suiteql/pnl#{row_key}"}),
                row_key,
                1,
            ),
        )

    def test_shipping_and_handling_question_uses_netsuite_pnl_metric_adapter(self):
        conn = self.make_conn()
        self.insert_pnl_row(conn, "2026-01:41015:amount")
        service = serve_http.AskJustService("", "")

        result = service._planned_structured_adapter_result(
            conn,
            "In NetSuite accounting, what shipping and handling P&L row is visible for January 2026? Return source id and row provenance.",
            {"source_id": "netsuite_pnl_monthly"},
            "all",
            5,
        )

        self.assertEqual(result["adapter"], "netsuite_pnl_metric")
        self.assertEqual(len(result["rows"]), 1)
        self.assertEqual(result["rows"][0]["source_id"], "netsuite_pnl_monthly")


if __name__ == "__main__":
    unittest.main()
