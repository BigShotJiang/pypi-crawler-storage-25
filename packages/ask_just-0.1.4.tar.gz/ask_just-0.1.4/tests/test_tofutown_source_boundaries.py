import importlib.util
import json
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


def load_builder():
    spec = importlib.util.spec_from_file_location(
        "build_fresh_source_database",
        ROOT / "scripts" / "build_fresh_source_database.py",
    )
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


class TofuTownSourceBoundaryTest(unittest.TestCase):
    def test_dirk_workbook_last_90_day_filter_excludes_old_rows(self):
        builder = load_builder()
        window_start, as_of = builder.source_window_bounds("2026-05-06T13:37:00Z")

        old_row = {
            "sheet": "service level 05.05.2026.CW18",
            "cells": [{"address": "C6", "value": "2026-01-01"}],
        }
        current_row = {
            "sheet": "service level 05.05.2026.CW18",
            "cells": [{"address": "C7", "value": "2026-02-01"}],
        }
        current_week_row = {
            "sheet": "stock level .week 19",
            "cells": [{"address": "A2", "value": "Aldi"}],
        }
        january_sheet_row = {
            "sheet": "stock level .01.26",
            "cells": [{"address": "A2", "value": "Aldi"}],
        }

        self.assertFalse(builder.tofutown_dirk_row_window_decision(old_row, window_start, as_of)[0])
        self.assertTrue(builder.tofutown_dirk_row_window_decision(current_row, window_start, as_of)[0])
        self.assertTrue(builder.tofutown_dirk_row_window_decision(current_week_row, window_start, as_of)[0])
        self.assertFalse(builder.tofutown_dirk_row_window_decision(january_sheet_row, window_start, as_of)[0])

    def test_qvd_lane_is_declared_but_not_queryable(self):
        all_source_ids = json.loads((ROOT / "config" / "all-source-ids.json").read_text())
        queryable_source_ids = json.loads((ROOT / "config" / "queryable-source-ids.json").read_text())

        self.assertIn("tofutown_qvd_last_90_days", all_source_ids)
        self.assertNotIn("tofutown_qvd_last_90_days", queryable_source_ids)
        self.assertIn("tofutown_qlik_cloud_app_models", queryable_source_ids)
        self.assertIn("tofutown_dirk_stock_level_workbook", queryable_source_ids)


if __name__ == "__main__":
    unittest.main()
