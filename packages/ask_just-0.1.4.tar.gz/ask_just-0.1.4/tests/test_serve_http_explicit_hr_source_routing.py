import os
import sqlite3
import sys
import unittest


ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
SCRIPTS = os.path.join(ROOT, "scripts")
if SCRIPTS not in sys.path:
    sys.path.insert(0, SCRIPTS)

import serve_http


class ServeHttpExplicitHRSourceRoutingTests(unittest.TestCase):
    def test_explicit_hr_source_active_employee_question_uses_people_roster(self):
        conn = sqlite3.connect(":memory:")
        conn.row_factory = sqlite3.Row
        conn.execute("CREATE TABLE sources (source_id TEXT PRIMARY KEY)")
        conn.execute("INSERT INTO sources VALUES ('hr_just_food_company_headcount')")

        plan = serve_http.build_source_query_plan(
            conn,
            "What active employee rows are visible in the headcount source? Return source id and row provenance.",
            requested_source="hr_just_food_company_headcount",
        )

        self.assertEqual(len(plan), 1)
        self.assertEqual(plan[0]["source_id"], "hr_just_food_company_headcount")
        self.assertEqual(plan[0]["adapter_hint"], "just_people_roster")


if __name__ == "__main__":
    unittest.main()
