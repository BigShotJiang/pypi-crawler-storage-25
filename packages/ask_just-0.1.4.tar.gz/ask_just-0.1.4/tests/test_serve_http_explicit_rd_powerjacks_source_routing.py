import os
import sqlite3
import sys
import unittest


ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
SCRIPTS = os.path.join(ROOT, "scripts")
if SCRIPTS not in sys.path:
    sys.path.insert(0, SCRIPTS)

import serve_http


class ServeHttpExplicitRDPowerJacksSourceRoutingTests(unittest.TestCase):
    def test_explicit_powerjacks_source_keeps_formula_adapter_hint(self):
        conn = sqlite3.connect(":memory:")
        conn.row_factory = sqlite3.Row
        conn.execute("CREATE TABLE sources (source_id TEXT PRIMARY KEY)")
        conn.execute("INSERT INTO sources VALUES ('rd_powerjacks_formulations')")

        plan = serve_http.build_source_query_plan(
            conn,
            "What Power Jacks formulation rows are visible? Return source id and row provenance.",
            requested_source="rd_powerjacks_formulations",
        )

        self.assertEqual(len(plan), 1)
        self.assertEqual(plan[0]["source_id"], "rd_powerjacks_formulations")
        self.assertEqual(plan[0]["adapter_hint"], "rd_powerjacks_formula")


if __name__ == "__main__":
    unittest.main()
