import importlib.util
import json
import sys
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
SOURCE_ID = "just_us_canada_p_and_l_boms"


def load_builder():
    scripts_dir = ROOT / "scripts"
    if str(scripts_dir) not in sys.path:
        sys.path.insert(0, str(scripts_dir))
    spec = importlib.util.spec_from_file_location(
        "build_fresh_source_database",
        ROOT / "scripts" / "build_fresh_source_database.py",
    )
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


class JustUsCanadaBomSourceTest(unittest.TestCase):
    def test_source_lane_is_declared_queryable_and_separate_from_tofutown(self):
        all_source_ids = json.loads((ROOT / "config" / "all-source-ids.json").read_text())
        queryable_source_ids = json.loads((ROOT / "config" / "queryable-source-ids.json").read_text())
        builder = load_builder()

        self.assertIn(SOURCE_ID, all_source_ids)
        self.assertIn(SOURCE_ID, queryable_source_ids)

        source = builder.SOURCES[SOURCE_ID]
        self.assertEqual(source["business_domain"], "just_us_canada_finance_bom")
        self.assertEqual(source["parser"], "sharepoint_document_library")
        self.assertEqual(source["sharepoint"]["drive_id"], "b!tsOP-nZOREmCs9brm2mWPj9k4KJFkqxMilVKYe74wO6DK5zwb0kZSI0TjExBGQ3a")
        self.assertEqual(source["sharepoint"]["list_id"], "f09c2b83-496f-4819-8d13-8c4c41190dda")
        self.assertIn("Archive", source["sharepoint"]["exclude_paths"][0])
        self.assertIn("Graph recursive", source["sharepoint"]["delta_policy"])
        self.assertIn("US and Canada", source["name"])

    def test_browser_seed_boundary_has_expected_non_archive_files(self):
        builder = load_builder()
        boundary_names = {Path(path).name for path in builder.SOURCES[SOURCE_ID]["browser_seed_boundary"]}

        self.assertEqual(len(boundary_names), 10)
        self.assertIn("Just Egg Liquid BOM & P&L.xlsx", boundary_names)
        self.assertIn("Just Egg Liquid EU BOM & P&L.xlsx", boundary_names)
        self.assertIn("SKU P&L Summary.xlsx", boundary_names)
        self.assertNotIn("Archive", boundary_names)


if __name__ == "__main__":
    unittest.main()
