import contextlib
import io
import json
import os
import tempfile
import threading
import types
import unittest
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from unittest import mock

from ask_just_cli import agent_setup, cli


ROOT = Path(__file__).resolve().parents[1]


class SkillServer:
    def __init__(self, bodies):
        self.bodies = bodies
        outer = self

        class Handler(BaseHTTPRequestHandler):
            def log_message(self, *_args):
                return

            def do_GET(self):
                body = outer.bodies.get(self.path)
                if body is None:
                    self.send_response(404)
                    self.end_headers()
                    return
                self.send_response(200)
                self.send_header("Content-Type", "text/markdown; charset=utf-8")
                self.end_headers()
                self.wfile.write(body)

        self.server = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
        self.thread = threading.Thread(target=self.server.serve_forever, daemon=True)

    def __enter__(self):
        self.thread.start()
        return f"http://127.0.0.1:{self.server.server_address[1]}"

    def __exit__(self, *_args):
        self.server.shutdown()
        self.server.server_close()


class AskJustParityTest(unittest.TestCase):
    def canonical_bytes(self, skill_name):
        return (ROOT / "skills" / skill_name / "SKILL.md").read_bytes()

    def hosted_bodies(self, overrides=None):
        overrides = overrides or {}
        bodies = {}
        for skill_name in agent_setup.ASK_JUST_SKILLS:
            bodies[f"/skills/{skill_name}/SKILL.md"] = overrides.get(skill_name, self.canonical_bytes(skill_name))
        return bodies

    def write_skill(self, root, skill_name, body):
        path = root / "skills" / skill_name / "SKILL.md"
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(body)
        return path

    def seed_home(self, home, missing_claude=()):
        codex_home = home / ".codex"
        claude_home = home / ".claude"
        config_lines = []
        for skill_name in agent_setup.ASK_JUST_SKILLS:
            codex_skill = self.write_skill(codex_home, skill_name, self.canonical_bytes(skill_name))
            config_lines.extend(["[[skills.config]]", f"path = {json.dumps(str(codex_skill))}", "enabled = true", ""])
            if skill_name not in missing_claude:
                self.write_skill(claude_home, skill_name, self.canonical_bytes(skill_name))
        codex_home.mkdir(parents=True, exist_ok=True)
        (codex_home / "config.toml").write_text("\n".join(config_lines), encoding="utf-8")
        (codex_home / "AGENTS.md").write_text(agent_setup.MANAGED_BLOCK, encoding="utf-8")
        claude_home.mkdir(parents=True, exist_ok=True)
        (claude_home / "CLAUDE.md").write_text(agent_setup.MANAGED_BLOCK, encoding="utf-8")
        return codex_home, claude_home

    def run_parity(self, home, base_url, extra_env=None):
        args = types.SimpleNamespace(url=base_url, token="secret-token")
        buffer = io.StringIO()
        codex_home = home / ".codex"
        claude_home = home / ".claude"
        env = {
            "HOME": str(home),
            "CODEX_HOME": str(codex_home),
            "CLAUDE_HOME": str(claude_home),
            **(extra_env or {}),
        }
        with mock.patch.dict(os.environ, env, clear=False), contextlib.redirect_stdout(buffer):
            code = cli.parity(args)
        return code, json.loads(buffer.getvalue())

    def test_parity_passes_when_all_surfaces_match(self):
        with tempfile.TemporaryDirectory() as tmp:
            home = Path(tmp) / "home"
            home.mkdir()
            self.seed_home(home)
            with SkillServer(self.hosted_bodies()) as base_url:
                code, payload = self.run_parity(home, base_url)

        self.assertEqual(code, 0)
        self.assertTrue(payload["ok"])
        self.assertEqual(payload["status"], "parity_ready")
        self.assertEqual(payload["required_gaps"], [])
        self.assertGreaterEqual(len(payload["skill_records"]), len(agent_setup.ASK_JUST_SKILLS) * 5)
        for record in payload["skill_records"]:
            self.assertEqual(record["sha256"], record["canonical_sha256"], record)
            self.assertTrue(record["ok"], record)

    def test_parity_fails_stale_codex_skill_even_with_required_phrases(self):
        with tempfile.TemporaryDirectory() as tmp:
            home = Path(tmp) / "home"
            home.mkdir()
            codex_home, _ = self.seed_home(home)
            stale = (
                "# askjust\n\n"
                "ASK_JUST_INSTALLER_BEGIN\n"
                "Ask Just is the default answer path\n"
                "Do not use web search\n"
                "without requiring the user to type a command or skill name\n"
            ).encode("utf-8")
            (codex_home / "skills" / "askjust" / "SKILL.md").write_bytes(stale)
            with SkillServer(self.hosted_bodies()) as base_url:
                code, payload = self.run_parity(home, base_url)

        self.assertEqual(code, 1)
        self.assertIn("codex_skill_mismatch:askjust", payload["required_gaps"])
        stale_records = [
            record
            for record in payload["skill_records"]
            if record["skill_name"] == "askjust" and record["surface_name"] == "codex"
        ]
        self.assertEqual(len(stale_records), 1)
        self.assertFalse(stale_records[0]["ok"])
        self.assertNotEqual(stale_records[0]["sha256"], stale_records[0]["canonical_sha256"])

    def test_parity_fails_hosted_skill_drift(self):
        with tempfile.TemporaryDirectory() as tmp:
            home = Path(tmp) / "home"
            home.mkdir()
            self.seed_home(home)
            with SkillServer(self.hosted_bodies({"askjust": b"# hosted drift\n"})) as base_url:
                code, payload = self.run_parity(home, base_url)

        self.assertEqual(code, 1)
        self.assertIn("hosted_skill_mismatch:askjust", payload["required_gaps"])

    def test_parity_fails_missing_claude_skill(self):
        with tempfile.TemporaryDirectory() as tmp:
            home = Path(tmp) / "home"
            home.mkdir()
            self.seed_home(home, missing_claude={"askjust"})
            with SkillServer(self.hosted_bodies()) as base_url:
                code, payload = self.run_parity(home, base_url)

        self.assertEqual(code, 1)
        self.assertIn("claude_skill_missing:askjust", payload["required_gaps"])

    def test_parity_fails_package_mirror_drift(self):
        with tempfile.TemporaryDirectory() as tmp:
            tmp_path = Path(tmp)
            home = tmp_path / "home"
            repo_skills = tmp_path / "repo-skills"
            package_skills = tmp_path / "package-skills"
            home.mkdir()
            for skill_name in agent_setup.ASK_JUST_SKILLS:
                repo_skill = repo_skills / skill_name / "SKILL.md"
                package_skill = package_skills / skill_name / "SKILL.md"
                repo_skill.parent.mkdir(parents=True, exist_ok=True)
                package_skill.parent.mkdir(parents=True, exist_ok=True)
                body = self.canonical_bytes(skill_name)
                repo_skill.write_bytes(body)
                package_skill.write_bytes(body)
            (package_skills / "askjust" / "SKILL.md").write_bytes(b"# package drift\n")
            self.seed_home(home)
            env = {
                "ASK_JUST_REPO_SKILLS_ROOT": str(repo_skills),
                "ASK_JUST_PACKAGE_SKILLS_ROOT": str(package_skills),
            }
            with SkillServer(self.hosted_bodies()) as base_url:
                code, payload = self.run_parity(home, base_url, extra_env=env)

        self.assertEqual(code, 1)
        self.assertIn("package_skill_mismatch:askjust", payload["required_gaps"])

    def test_parity_fails_when_codex_skill_installed_but_disabled(self):
        with tempfile.TemporaryDirectory() as tmp:
            home = Path(tmp) / "home"
            home.mkdir()
            codex_home, _ = self.seed_home(home)
            askjust_path = codex_home / "skills" / "askjust" / "SKILL.md"
            (codex_home / "config.toml").write_text(
                "\n".join(["[[skills.config]]", f"path = {json.dumps(str(askjust_path))}", "enabled = false", ""]),
                encoding="utf-8",
            )
            with SkillServer(self.hosted_bodies()) as base_url:
                code, payload = self.run_parity(home, base_url)

        self.assertEqual(code, 1)
        self.assertIn("codex_skill_disabled:askjust", payload["required_gaps"])

    def test_parity_fails_missing_global_claude_routing_block(self):
        with tempfile.TemporaryDirectory() as tmp:
            home = Path(tmp) / "home"
            home.mkdir()
            _, claude_home = self.seed_home(home)
            (claude_home / "CLAUDE.md").write_text("# CLAUDE.md\n", encoding="utf-8")
            with SkillServer(self.hosted_bodies()) as base_url:
                code, payload = self.run_parity(home, base_url)

        self.assertEqual(code, 1)
        self.assertIn("global_claude_ask_just_rule_missing", payload["required_gaps"])


if __name__ == "__main__":
    unittest.main()
