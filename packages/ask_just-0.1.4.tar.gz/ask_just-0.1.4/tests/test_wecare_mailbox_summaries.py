import json
import os
import sqlite3
import sys
import unittest


ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
SCRIPTS = os.path.join(ROOT, "scripts")
if SCRIPTS not in sys.path:
    sys.path.insert(0, SCRIPTS)

import build_fresh_source_database as builder


class WecareMailboxSummariesTest(unittest.TestCase):
    def sample_message(self):
        return {
            "id": "message-1",
            "internet_message_id": "<message-1@example.com>",
            "conversation_id": "conversation-1",
            "folder": "inbox",
            "mailbox": "wecare@ju.st",
            "subject": "[Contact Form] Product Refund, Spoiled!",
            "sender": {"name": "Sandra Marsh", "address": "sandra@example.com"},
            "from": {"name": "Sandra Marsh", "address": "sandra@example.com"},
            "received_date_time": "2026-05-05T00:54:10Z",
            "sent_date_time": "2026-05-05T00:53:41Z",
            "last_modified_date_time": "2026-05-05T00:54:10Z",
            "body_preview": "I bought JUST Egg Folded at Walmart and it smelled spoiled.",
            "body_text": "I would like a refund. The JUST Egg Folded package smelled spoiled and tasted sour.",
            "web_link": "https://outlook.office365.com/owa/?ItemID=message-1",
            "rolling_window_start": "2026-04-05T00:00:00Z",
            "rolling_window_days": 30,
        }

    def test_classifies_wecare_refund_spoilage_contact_form_message(self):
        summary = builder.classify_wecare_message(self.sample_message(), "2026-05-05T01:00:00Z")

        self.assertTrue(summary["is_customer_signal"])
        self.assertEqual(summary["customer_signal_reason"], "contact_form")
        self.assertEqual(summary["primary_intent"], "refund")
        self.assertTrue(summary["is_contact_form"])
        self.assertTrue(summary["is_refund_request"])
        self.assertTrue(summary["is_spoiled_product"])
        self.assertTrue(summary["is_product_complaint"])
        self.assertEqual(summary["sender_domain"], "example.com")
        self.assertEqual(summary["received_date"], "2026-05-05")
        self.assertIn("just egg", summary["product_terms"])
        self.assertIn("just egg folded", summary["product_terms"])
        self.assertIn("walmart", summary["retailer_terms"])

    def test_wecare_summary_atomic_row_populates_typed_table(self):
        conn = sqlite3.connect(":memory:")
        builder.create_schema(conn)
        source_id = "wecare_mailbox_last_30_days"
        source_file = "microsoft-graph:/users/wecare@ju.st/messages?receivedDateTime>=2026-04-05T00:00:00Z"
        summary = builder.classify_wecare_message(self.sample_message(), "2026-05-05T01:00:00Z")

        inserted = builder.insert_wecare_mailbox_row(
            conn,
            source_id,
            source_file,
            "wecare_mailbox_customer_issue_summaries",
            "application/mail/customer_issue_summary",
            "customer_issue_summary:message-1",
            summary,
            1,
            "2026-05-05T01:00:00Z",
        )

        self.assertEqual(inserted, 1)
        row = conn.execute(
            """
            SELECT primary_intent, is_refund_request, is_spoiled_product,
                   is_contact_form, product_terms_json, retailer_terms_json,
                   provenance_grain
            FROM wecare_customer_issue_summaries
            WHERE message_id = ?
            """,
            ("message-1",),
        ).fetchone()
        self.assertIsNotNone(row)
        self.assertEqual(row[0], "refund")
        self.assertEqual(row[1], 1)
        self.assertEqual(row[2], 1)
        self.assertEqual(row[3], 1)
        self.assertIn("just egg folded", json.loads(row[4]))
        self.assertEqual(json.loads(row[5]), ["walmart"])
        provenance = json.loads(row[6])
        self.assertEqual(provenance["source_id"], source_id)
        self.assertEqual(provenance["grain_type"], "application/mail/customer_issue_summary")

    def test_sent_reply_is_not_customer_signal(self):
        message = self.sample_message()
        message["folder"] = "sentitems"
        message["sender"] = {"name": "Eat Just WeCare", "address": "wecare@ju.st"}
        message["from"] = {"name": "Eat Just WeCare", "address": "wecare@ju.st"}

        summary = builder.classify_wecare_message(message, "2026-05-05T01:00:00Z")

        self.assertFalse(summary["is_customer_signal"])
        self.assertEqual(summary["customer_signal_reason"], "excluded_folder:sentitems")

    def test_wecare_authored_contact_form_reply_is_not_customer_signal(self):
        message = self.sample_message()
        message["folder"] = "deleteditems"
        message["subject"] = "Re: [Contact Form] (261240859NT)"
        message["sender"] = {"name": "Eat Just WeCare", "address": "wecare@ju.st"}
        message["from"] = {"name": "Eat Just WeCare", "address": "wecare@ju.st"}

        summary = builder.classify_wecare_message(message, "2026-05-05T01:00:00Z")

        self.assertFalse(summary["is_customer_signal"])
        self.assertEqual(summary["customer_signal_reason"], "internal_sender:wecare@ju.st")

    def test_admin_notification_is_not_customer_signal(self):
        message = self.sample_message()
        message["subject"] = "You've received a Business Manager partner request"
        message["sender"] = {"name": "Facebook", "address": "noreply@business.facebook.com"}
        message["from"] = {"name": "Facebook", "address": "noreply@business.facebook.com"}
        message["body_preview"] = "A business wants to partner with your Business Manager."
        message["body_text"] = "Review this partner request in Meta Business Manager."

        summary = builder.classify_wecare_message(message, "2026-05-05T01:00:00Z")

        self.assertFalse(summary["is_customer_signal"])
        self.assertEqual(summary["customer_signal_reason"], "admin_sender_domain:business.facebook.com")

    def test_vendor_pitch_is_not_customer_signal(self):
        message = self.sample_message()
        message["subject"] = "Innovative Plant Protein Solutions for Good Meat"
        message["sender"] = {"name": "Supplier", "address": "eric@seporange.com.cn"}
        message["from"] = {"name": "Supplier", "address": "eric@seporange.com.cn"}
        message["body_preview"] = "We are a supplier with innovative plant protein solutions."
        message["body_text"] = "Please review our plant protein supplier capabilities."

        summary = builder.classify_wecare_message(message, "2026-05-05T01:00:00Z")

        self.assertFalse(summary["is_customer_signal"])
        self.assertEqual(summary["customer_signal_reason"], "non_customer_sender_domain:seporange.com.cn")

    def test_vendor_sender_domain_is_not_customer_signal(self):
        message = self.sample_message()
        message["subject"] = "Meat Ofers.."
        message["sender"] = {"name": "Osona Food", "address": "comercial9@osonafood.com"}
        message["from"] = {"name": "Osona Food", "address": "comercial9@osonafood.com"}
        message["body_preview"] = "Introductory meat offers and product catalog."
        message["body_text"] = "We are offering meat products and would like to introduce our catalog."

        summary = builder.classify_wecare_message(message, "2026-05-05T01:00:00Z")

        self.assertFalse(summary["is_customer_signal"])
        self.assertEqual(summary["customer_signal_reason"], "non_customer_sender_domain:osonafood.com")


if __name__ == "__main__":
    unittest.main()
