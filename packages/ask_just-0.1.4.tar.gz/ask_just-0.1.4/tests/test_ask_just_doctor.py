import contextlib
import io
import json
import os
import sys
import tempfile
import types
import unittest
from unittest import mock


ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
SCRIPTS = os.path.join(ROOT, "scripts")
if SCRIPTS not in sys.path:
    sys.path.insert(0, SCRIPTS)

import ask_just


class AskJustDoctorTest(unittest.TestCase):
    def make_home(self):
        tmp = tempfile.TemporaryDirectory()
        self.addCleanup(tmp.cleanup)
        home = tmp.name
        local_bin = os.path.join(home, ".local", "bin")
        codex_home = os.path.join(home, ".codex")
        config_path = os.path.join(home, ".config", "ask-just", "config.json")
        os.makedirs(local_bin, exist_ok=True)
        os.makedirs(os.path.dirname(config_path), exist_ok=True)
        return home, local_bin, codex_home, config_path

    def write_config(self, config_path, token="secret-token", url=ask_just.DEFAULT_URL):
        with open(config_path, "w", encoding="utf-8") as handle:
            json.dump({"token": token, "url": url}, handle)

    def write_expected_artifacts(self, local_bin, codex_home):
        ask_just_bin = os.path.join(local_bin, "ask-just")
        with open(ask_just_bin, "w", encoding="utf-8") as handle:
            handle.write("#!/usr/bin/env python3\n")
        os.chmod(ask_just_bin, 0o755)
        config_lines = []
        for skill_name in ("askjust", "just-source", "correction", "braintrust"):
            skill_path = os.path.join(codex_home, "skills", skill_name, "SKILL.md")
            os.makedirs(os.path.dirname(skill_path), exist_ok=True)
            with open(skill_path, "w", encoding="utf-8") as handle:
                handle.write(f"# {skill_name}\n")
            config_lines.extend(
                [
                    "[[skills.config]]",
                    f'path = "{skill_path}"',
                    "enabled = true",
                    "",
                ]
            )
        os.makedirs(codex_home, exist_ok=True)
        with open(os.path.join(codex_home, "config.toml"), "w", encoding="utf-8") as handle:
            handle.write("\n".join(config_lines))
        with open(os.path.join(codex_home, "AGENTS.md"), "w", encoding="utf-8") as handle:
            handle.write(
                "\n".join(
                    [
                        "# AGENTS.md",
                        "",
                        "<!-- ASK_JUST_INSTALLER_BEGIN -->",
                        "## Ask Just",
                        "",
                        "- Ask Just is the default answer path for Just company questions.",
                        "- Use the installed `askjust` skill and hosted `ask-just` source plane without requiring the user to type a command or skill name.",
                        "- Do not use web search for Ask Just answers.",
                        "<!-- ASK_JUST_INSTALLER_END -->",
                        "",
                    ]
                )
            )

    def run_doctor(self, config_path, home, codex_home, local_bin, hosted_payloads):
        calls = []

        def fake_request_json(url, token=None, method="GET", payload=None):
            calls.append({"url": url, "token": token, "method": method, "payload": payload})
            return hosted_payloads[url.rsplit("/", 1)[-1]]

        args = types.SimpleNamespace(url=None, token=None, deep=False)
        buffer = io.StringIO()
        env = {
            "HOME": home,
            "CODEX_HOME": codex_home,
            "PATH": f"{local_bin}{os.pathsep}/usr/bin",
        }
        with mock.patch.dict(os.environ, env, clear=True), mock.patch.object(
            ask_just, "CONFIG_PATH", config_path
        ), mock.patch.object(ask_just, "request_json", side_effect=fake_request_json), contextlib.redirect_stdout(buffer):
            code = ask_just.doctor(args)
        return code, json.loads(buffer.getvalue()), buffer.getvalue(), calls

    def test_doctor_passes_when_local_artifacts_and_hosted_checks_are_ready(self):
        home, local_bin, codex_home, config_path = self.make_home()
        self.write_config(config_path)
        self.write_expected_artifacts(local_bin, codex_home)

        code, payload, raw_output, calls = self.run_doctor(
            config_path,
            home,
            codex_home,
            local_bin,
            {
                "ready": {"ok": True, "health": {"status": "ready"}},
                "sources": {"ok": True, "rows": [{"source_id": "scorecard_monthly_data"}]},
            },
        )

        self.assertEqual(code, 0)
        self.assertTrue(payload["ok"])
        self.assertEqual(payload["status"], "ready")
        self.assertEqual(payload["required_gaps"], [])
        self.assertEqual(payload["hosted_sources"]["source_count"], 1)
        self.assertNotIn("secret-token", raw_output)
        self.assertEqual([call["token"] for call in calls], ["secret-token", "secret-token"])

    def test_doctor_reports_required_gaps_without_printing_token(self):
        home, local_bin, codex_home, config_path = self.make_home()
        self.write_config(config_path)

        code, payload, raw_output, _ = self.run_doctor(
            config_path,
            home,
            codex_home,
            local_bin,
            {
                "ready": {"ok": False, "error": "service unavailable"},
                "sources": {"ok": False, "error": "source inventory unavailable"},
            },
        )

        self.assertEqual(code, 1)
        self.assertFalse(payload["ok"])
        self.assertEqual(payload["status"], "needs_attention")
        self.assertIn("hosted_ready_failed", payload["required_gaps"])
        self.assertIn("hosted_sources_failed", payload["required_gaps"])
        self.assertIn("ask_just_binary_missing", payload["required_gaps"])
        self.assertIn("codex_skill_missing:askjust", payload["required_gaps"])
        self.assertNotIn("secret-token", raw_output)

    def test_doctor_reports_unauthorized_sources_as_token_or_permission_gap(self):
        home, local_bin, codex_home, config_path = self.make_home()
        self.write_config(config_path)
        self.write_expected_artifacts(local_bin, codex_home)

        code, payload, raw_output, _ = self.run_doctor(
            config_path,
            home,
            codex_home,
            local_bin,
            {
                "ready": {"ok": True, "health": {"status": "ready"}},
                "sources": {"ok": False, "http_status": 401, "error": "unauthorized"},
            },
        )

        self.assertEqual(code, 1)
        self.assertFalse(payload["ok"])
        self.assertIn("hosted_sources_unauthorized", payload["required_gaps"])
        self.assertNotIn("secret-token", raw_output)

    def test_doctor_reports_disabled_codex_skill_config(self):
        home, local_bin, codex_home, config_path = self.make_home()
        self.write_config(config_path)
        self.write_expected_artifacts(local_bin, codex_home)
        askjust_path = os.path.join(codex_home, "skills", "askjust", "SKILL.md")
        with open(os.path.join(codex_home, "config.toml"), "w", encoding="utf-8") as handle:
            handle.write(
                "\n".join(
                    [
                        "[[skills.config]]",
                        f'path = "{askjust_path}"',
                        "enabled = false",
                        "",
                    ]
                )
            )

        code, payload, raw_output, _ = self.run_doctor(
            config_path,
            home,
            codex_home,
            local_bin,
            {
                "ready": {"ok": True, "health": {"status": "ready"}},
                "sources": {"ok": True, "rows": [{"source_id": "scorecard_monthly_data"}]},
            },
        )

        self.assertEqual(code, 1)
        self.assertFalse(payload["ok"])
        self.assertIn("codex_skill_disabled:askjust", payload["required_gaps"])
        self.assertNotIn("secret-token", raw_output)

    def test_doctor_reports_missing_global_agents_rule(self):
        home, local_bin, codex_home, config_path = self.make_home()
        self.write_config(config_path)
        self.write_expected_artifacts(local_bin, codex_home)
        os.remove(os.path.join(codex_home, "AGENTS.md"))

        code, payload, raw_output, _ = self.run_doctor(
            config_path,
            home,
            codex_home,
            local_bin,
            {
                "ready": {"ok": True, "health": {"status": "ready"}},
                "sources": {"ok": True, "rows": [{"source_id": "scorecard_monthly_data"}]},
            },
        )

        self.assertEqual(code, 1)
        self.assertFalse(payload["ok"])
        self.assertIn("global_agents_ask_just_rule_missing", payload["required_gaps"])
        self.assertNotIn("secret-token", raw_output)


if __name__ == "__main__":
    unittest.main()
