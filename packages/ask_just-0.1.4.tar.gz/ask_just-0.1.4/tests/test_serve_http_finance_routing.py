import os
import sys
import unittest


ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
SCRIPTS = os.path.join(ROOT, "scripts")
if SCRIPTS not in sys.path:
    sys.path.insert(0, SCRIPTS)

import serve_http


class ServeHttpFinanceRoutingTests(unittest.TestCase):
    def test_cash_forecast_question_routes_to_finance_cash_flow_ending_balance(self):
        params = serve_http._cash_flow_question_params(
            "What does the 2026 cash flow forecast say about May cash?",
            "all",
        )

        self.assertIsNotNone(params)
        self.assertEqual(params["metric_key"], "ending_balance")
        self.assertEqual(params["period_end"], "2026-05-31")
        self.assertEqual(params["period_type"], "month_total")


if __name__ == "__main__":
    unittest.main()
