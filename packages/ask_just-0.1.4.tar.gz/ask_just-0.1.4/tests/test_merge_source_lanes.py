import os
import sqlite3
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
SCRIPTS = os.path.join(ROOT, "scripts")
if SCRIPTS not in sys.path:
    sys.path.insert(0, SCRIPTS)

import merge_source_lanes


def init_db(path: Path):
    conn = sqlite3.connect(path)
    conn.executescript(
        """
        CREATE TABLE sources (source_id TEXT PRIMARY KEY, name TEXT, source_type TEXT, mapped TEXT, accessible TEXT, atomically_queryable TEXT);
        CREATE TABLE source_files (file_id TEXT PRIMARY KEY, source_id TEXT, path TEXT, sha256 TEXT, modified_at TEXT, parsed TEXT, provenance_grain TEXT);
        CREATE TABLE atomic_rows (row_id TEXT PRIMARY KEY, source_id TEXT, source_table TEXT, source_file TEXT, sheet TEXT, row_index INTEGER, row_key TEXT, row_json TEXT, search_text TEXT, provenance_grain TEXT);
        CREATE VIRTUAL TABLE atomic_rows_fts USING fts5(source_id, source_table, source_file, sheet, search_text, provenance_grain UNINDEXED);
        """
    )
    conn.commit()
    return conn


class MergeSourceLanesTests(unittest.TestCase):
    def test_merge_selected_source_rows_and_fts(self):
        with tempfile.TemporaryDirectory() as tmp:
            source = Path(tmp) / "source.sqlite"
            target = Path(tmp) / "target.sqlite"
            src = init_db(source)
            dst = init_db(target)
            src.execute("INSERT INTO sources VALUES ('netsuite_pnl_monthly','NetSuite P&L','live','yes','yes','yes')")
            src.execute("INSERT INTO source_files VALUES ('f1','netsuite_pnl_monthly','netsuite:/suiteql/pnl','abc','now','yes','{}')")
            src.execute("INSERT INTO atomic_rows VALUES ('r1','netsuite_pnl_monthly','netsuite_pnl_account_fields','netsuite:/suiteql/pnl',NULL,1,'2026-03:41005:amount','{}','gross cpg sales','{}')")
            src.commit(); src.close(); dst.close()
            counts = merge_source_lanes.merge_source_lanes(target, source, ["netsuite_pnl_monthly"])
            conn = sqlite3.connect(target)
            self.assertEqual(counts["atomic_rows"], 1)
            self.assertEqual(conn.execute("SELECT count(*) FROM sources WHERE source_id='netsuite_pnl_monthly'").fetchone()[0], 1)
            self.assertEqual(conn.execute("SELECT count(*) FROM atomic_rows_fts WHERE source_id='netsuite_pnl_monthly'").fetchone()[0], 1)
            conn.close()


if __name__ == "__main__":
    unittest.main()
