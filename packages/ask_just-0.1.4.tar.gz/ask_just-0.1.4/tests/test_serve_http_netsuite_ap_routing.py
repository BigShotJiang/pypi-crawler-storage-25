import json
import os
import sqlite3
import sys
import tempfile
import unittest


ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
SCRIPTS = os.path.join(ROOT, "scripts")
if SCRIPTS not in sys.path:
    sys.path.insert(0, SCRIPTS)

import serve_http


class ServeHttpNetSuiteAPRoutingTests(unittest.TestCase):
    def test_explicit_ap_source_uses_open_ap_structured_rows(self):
        tmp = tempfile.TemporaryDirectory()
        self.addCleanup(tmp.cleanup)
        db_path = os.path.join(tmp.name, "source_index.sqlite")
        status_path = os.path.join(tmp.name, "source_status.json")
        conn = sqlite3.connect(db_path)
        conn.executescript(
            """
            CREATE TABLE sources (source_id TEXT PRIMARY KEY, boundary_json TEXT);
            CREATE TABLE source_files (source_id TEXT, path TEXT, sha256 TEXT, modified_at TEXT, parsed TEXT, provenance_grain TEXT);
            CREATE TABLE atomic_rows (
                source_id TEXT,
                source_table TEXT,
                source_file TEXT,
                row_json TEXT,
                provenance_grain TEXT,
                row_key TEXT,
                row_index INTEGER
            );
            """
        )
        conn.execute("INSERT INTO sources VALUES ('netsuite_ap_open_bills', '[]')")
        conn.execute(
            "INSERT INTO source_files VALUES (?, ?, ?, ?, ?, ?)",
            ("netsuite_ap_open_bills", "netsuite:/suiteql/ap_open_bills", "abc", "now", "yes", "{}"),
        )
        for index, (field, value) in enumerate(
            [("vendor_company", "Example Vendor"), ("duedate", "5/31/2026"), ("open_amount", "123.45")],
            start=1,
        ):
            conn.execute(
                "INSERT INTO atomic_rows VALUES (?, ?, ?, ?, ?, ?, ?)",
                (
                    "netsuite_ap_open_bills",
                    "netsuite_ap_open_bill_fields",
                    "netsuite:/suiteql/ap_open_bills",
                    json.dumps({"field": field, "value": value, "vendor_company": "Example Vendor", "duedate": "5/31/2026"}),
                    json.dumps({"source_id": "netsuite_ap_open_bills", "locator": f"netsuite:/suiteql/ap_open_bills#record=1&field={field}"}),
                    f"BILL1:{field}",
                    index,
                ),
            )
        conn.commit()
        conn.close()
        service = serve_http.AskJustService(db_path, status_path)

        payload = service.search(
            "Which open AP bills are visible right now, with vendor and due evidence?",
            source="netsuite_ap_open_bills",
            limit=5,
        )

        self.assertTrue(payload["ok"])
        self.assertEqual(payload["routing_decision"]["route_plan"][0]["adapter"], "netsuite_open_ap")
        self.assertEqual(len(payload["rows"]), 3)
        self.assertEqual(payload["rows"][0]["source_id"], "netsuite_ap_open_bills")
        self.assertTrue(payload["rows"][0].get("source_links"))


if __name__ == "__main__":
    unittest.main()
