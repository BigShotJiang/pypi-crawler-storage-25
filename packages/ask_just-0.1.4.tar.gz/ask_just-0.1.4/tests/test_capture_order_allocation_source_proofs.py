import json
import os
import sys
import tempfile
import unittest
from pathlib import Path
from unittest import mock


ROOT = Path(__file__).resolve().parents[1]
SCRIPTS = ROOT / "scripts"
if str(SCRIPTS) not in sys.path:
    sys.path.insert(0, str(SCRIPTS))

import capture_order_allocation_source_proofs as capture


class CaptureOrderAllocationSourceProofsTest(unittest.TestCase):
    def test_evista_inventory_capture_writes_scraped_csv_and_proof(self):
        class FakeResponse:
            def __init__(self, text):
                self.text = text

            def raise_for_status(self):
                return None

        class FakeSession:
            def __init__(self):
                self.headers = {}
                self.get_calls = 0

            def get(self, url):
                self.get_calls += 1
                if "aInventoryResult.jsp?" in url:
                    return FakeResponse(
                        """
                        <tr class="o3" id="1">
                          <td><a href="x?itemcode=JEBU-01497"><b>JEBU-01497</b></a></td>
                          <td><a href="aInventoryDetail.jsp?lev3=LOT-1"><b>JUST Egg Folded</b></a></td>
                          <td>05.30.2026</td>
                        </tr>
                        <tr style="display:none;" id="show1">
                          <td>UNITS</td><td>170CASE</td><td>138CASE</td><td>0CASE</td><td>2CASE</td><td>1CASE</td>
                        </tr>
                        """
                    )
                return FakeResponse("<html></html>")

            def post(self, url, data=None):
                if data == {"act": "login"}:
                    return FakeResponse('<input name="sid" value="sid-1"><input name="uniqueSession" value="session-1">')
                if data and data.get("user") == "evista-user":
                    return FakeResponse('<input name="uniqueSession" value="auth-1">')
                if "aInventorySearch.jsp" in url:
                    return FakeResponse('<input name="uniqueSession" value="search-1">')
                if "aInventoryResult.jsp" in url:
                    return FakeResponse("function _p1(){uniqueSession=result-1}")
                return FakeResponse("")

        with tempfile.TemporaryDirectory() as tmp, mock.patch.dict(
            os.environ,
            {"VERTICAL_USER": "evista-user", "VERTICAL_PASS": "evista-pass"},
            clear=False,
        ), mock.patch.object(capture.requests, "Session", return_value=FakeSession()):
            root = Path(tmp)
            proof_path = capture.capture_evista_inventory(
                freshness_date="2026-05-06",
                output_dir=root / "proofs",
                artifact_dir=root / "captured",
                fetched_at="2026-05-06T15:00:00Z",
            )
            proof = json.loads(proof_path.read_text(encoding="utf-8"))
            artifact = Path(proof["captured_artifact"])
            artifact_text = artifact.read_text(encoding="utf-8")

        self.assertEqual(proof["family_id"], "inventory_vertical_evista")
        self.assertEqual(proof["proof_type"], "evista_inventory_scrape")
        self.assertEqual(proof["source_uri"], "evista:/vertical-cold-storage/inventory")
        self.assertEqual(proof["row_count"], 1)
        self.assertTrue(artifact_text.startswith("Item,"))
        self.assertIn("JEBU-01497", artifact_text)

    def test_file_artifact_writes_source_family_proof_with_artifact_hash(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            artifact = root / "vertical-inventory.csv"
            artifact.write_text("sku,cases\nJE-1,12\nJE-2,4\n", encoding="utf-8")

            proof_path = capture.capture_file_artifact(
                family_id="inventory_vertical_evista",
                artifact_path=artifact,
                freshness_date="2026-05-06",
                output_dir=root / "proofs",
                source_uri="evista:/vertical-cold-storage/inventory",
                proof_type="evista_inventory_export",
                fetched_at="2026-05-06T14:50:00Z",
            )

            proof = json.loads(proof_path.read_text(encoding="utf-8"))

        self.assertEqual(proof["family_id"], "inventory_vertical_evista")
        self.assertEqual(proof["freshness_date"], "2026-05-06")
        self.assertEqual(proof["row_count"], 2)
        self.assertEqual(proof["source_uri"], "evista:/vertical-cold-storage/inventory")
        self.assertEqual(proof["proof_type"], "evista_inventory_export")
        self.assertTrue(proof["artifact_locator"].endswith("vertical-inventory.csv"))
        self.assertEqual(len(proof["sha256"]), 64)

    def test_mailbox_inventory_capture_writes_proof_from_attachment_metadata(self):
        messages_payload = {
            "value": [
                {
                    "id": "message-1",
                    "subject": "Vernon Daily Inventory",
                    "from": {"emailAddress": {"address": "noreply@onelineage.com"}},
                    "receivedDateTime": "2026-05-06T13:30:00Z",
                    "hasAttachments": True,
                    "webLink": "https://outlook.office.com/mail/message-1",
                }
            ]
        }
        attachments_payload = {
            "value": [
                {
                    "id": "attachment-1",
                    "name": "Vernon Inventory.xlsx",
                    "contentType": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                    "size": 12345,
                    "lastModifiedDateTime": "2026-05-06T13:29:00Z",
                }
            ]
        }

        def fake_graph_request_json(url, token):
            if "/attachments?" in url:
                return attachments_payload
            return messages_payload

        with tempfile.TemporaryDirectory() as tmp, mock.patch.object(capture.builder, "graph_access_token", return_value="token"), mock.patch.object(
            capture.builder,
            "graph_request_json",
            side_effect=fake_graph_request_json,
        ):
            proof_path = capture.capture_mailbox_inventory_attachment(
                family_id="inventory_vernon",
                freshness_date="2026-05-06",
                output_dir=Path(tmp),
                subject_contains="Vernon",
                fetched_at="2026-05-06T14:45:00Z",
            )
            proof = json.loads(proof_path.read_text(encoding="utf-8"))

        self.assertEqual(proof["family_id"], "inventory_vernon")
        self.assertEqual(proof["row_count"], 1)
        self.assertEqual(proof["proof_type"], "mail_attachment_inventory_snapshot")
        self.assertEqual(proof["source_uri"], "microsoft-graph:/users/inventory@ju.st/messages?subject=Vernon&sender=noreply@onelineage.com")
        self.assertEqual(proof["artifact_locator"], "https://outlook.office.com/mail/message-1#attachment=attachment-1")
        self.assertEqual(proof["attachment"]["name"], "Vernon Inventory.xlsx")

    def test_mailbox_inventory_defaults_to_previous_repo_sender_and_subject(self):
        messages_payload = {
            "value": [
                {
                    "id": "message-1",
                    "subject": "Inventory Stock Summary Report - JUST",
                    "from": {"emailAddress": {"address": "noreply@onelineage.com"}},
                    "receivedDateTime": "2026-05-06T13:30:00Z",
                    "hasAttachments": True,
                    "webLink": "https://outlook.office.com/mail/message-1",
                }
            ]
        }
        attachments_payload = {"value": [{"id": "attachment-1", "name": "stock.csv", "isInline": False}]}

        def fake_graph_request_json(url, token):
            if "/attachments?" in url:
                return attachments_payload
            self.assertIn("%24select=id%2Csubject%2Cfrom%2CreceivedDateTime", url)
            return messages_payload

        with tempfile.TemporaryDirectory() as tmp, mock.patch.object(capture.builder, "graph_access_token", return_value="token"), mock.patch.object(
            capture.builder,
            "graph_request_json",
            side_effect=fake_graph_request_json,
        ):
            proof_path = capture.capture_mailbox_inventory_attachment(
                family_id="inventory_vernon",
                freshness_date="2026-05-06",
                output_dir=Path(tmp),
                fetched_at="2026-05-06T14:45:00Z",
            )
            proof = json.loads(proof_path.read_text(encoding="utf-8"))

        self.assertEqual(
            proof["source_uri"],
            "microsoft-graph:/users/inventory@ju.st/messages?subject=Inventory Stock Summary Report&sender=noreply@onelineage.com",
        )

    def test_sharepoint_file_capture_writes_proof_and_artifact(self):
        item_payload = {
            "id": "item-1",
            "name": "OOR Automation.xlsx",
            "lastModifiedDateTime": "2026-05-06T18:30:00Z",
            "webUrl": "https://sharepoint.example/OOR.xlsx",
            "size": 123,
        }
        raw = b"fake workbook bytes"

        with tempfile.TemporaryDirectory() as tmp, mock.patch.object(
            capture.builder,
            "graph_access_token",
            return_value="token",
        ), mock.patch.object(
            capture.builder,
            "graph_request_json",
            return_value=item_payload,
        ) as graph_json, mock.patch.object(
            capture.builder,
            "graph_request_bytes",
            return_value=raw,
        ) as graph_bytes:
            root = Path(tmp)
            proof_path = capture.capture_sharepoint_file(
                family_id="routing_rules",
                freshness_date="2026-05-06",
                output_dir=root / "proofs",
                artifact_dir=root / "captured",
                drive_id="drive-1",
                item_id="item-1",
                source_uri="sharepoint:/sites/operations/Automation/OOR Automation.xlsx",
                fetched_at="2026-05-06T19:20:00Z",
            )
            proof = json.loads(proof_path.read_text(encoding="utf-8"))
            self.assertTrue(Path(proof["captured_artifact"]).exists())
            self.assertEqual(Path(proof["captured_artifact"]).read_bytes(), raw)

        self.assertEqual(proof["family_id"], "routing_rules")
        self.assertEqual(proof["source_time"], "2026-05-06T18:30:00Z")
        self.assertEqual(proof["source_uri"], "sharepoint:/sites/operations/Automation/OOR Automation.xlsx")
        self.assertEqual(proof["artifact_locator"], "https://sharepoint.example/OOR.xlsx")
        self.assertEqual(proof["sharepoint_item"]["id"], "item-1")
        graph_json.assert_called_once()
        graph_bytes.assert_called_once()

    def test_netsuite_open_orders_capture_writes_proof_from_suiteql_result(self):
        with tempfile.TemporaryDirectory() as tmp, mock.patch.object(
            capture.builder,
            "fetch_netsuite_suiteql",
            return_value=([{"id": "SO1"}, {"id": "SO2"}], "abc123", "2026-05-06T14:46:00Z"),
        ) as fetch:
            proof_path = capture.capture_netsuite_open_orders(
                freshness_date="2026-05-06",
                output_dir=Path(tmp),
                run_date="2026-05-06",
            )
            proof = json.loads(proof_path.read_text(encoding="utf-8"))

        self.assertEqual(proof["family_id"], "netsuite_open_orders")
        self.assertEqual(proof["row_count"], 2)
        self.assertEqual(proof["proof_type"], "netsuite_suiteql_open_order_demand")
        self.assertEqual(proof["artifact_locator"], "netsuite:/suiteql/open_sales_orders_demand#run_date=2026-05-06")
        self.assertIn("2026-05-12", proof["allocation_window"]["window_start"])
        query = fetch.call_args.args[0]
        self.assertIn("SalesOrd", query)
        self.assertIn("shipdate", query.lower())

    def test_netsuite_cli_accepts_explicit_env_file_for_local_operator_runs(self):
        with tempfile.TemporaryDirectory() as tmp, mock.patch.object(
            capture,
            "capture_netsuite_open_orders",
            return_value=Path(tmp) / "proof.json",
        ) as capture_open_orders:
            env_file = Path(tmp) / "netsuite.env"
            env_file.write_text("NETSUITE_ACCOUNT_ID=test\n", encoding="utf-8")
            old_value = os.environ.pop("ASK_JUST_NETSUITE_ENV_FILE", None)
            try:
                capture.main(
                    [
                        "--output-dir",
                        tmp,
                        "netsuite-open-orders",
                        "--freshness-date",
                        "2026-05-06",
                        "--run-date",
                        "2026-05-06",
                        "--env-file",
                        str(env_file),
                    ]
                )
            finally:
                if old_value is not None:
                    os.environ["ASK_JUST_NETSUITE_ENV_FILE"] = old_value
                else:
                    os.environ.pop("ASK_JUST_NETSUITE_ENV_FILE", None)

        self.assertEqual(os.environ.get("ASK_JUST_NETSUITE_ENV_FILE"), old_value)
        capture_open_orders.assert_called_once()

    def test_mailbox_cli_accepts_explicit_graph_env_file_for_local_operator_runs(self):
        with tempfile.TemporaryDirectory() as tmp, mock.patch.object(
            capture,
            "capture_mailbox_inventory_attachment",
            return_value=Path(tmp) / "proof.json",
        ) as capture_mailbox:
            env_file = Path(tmp) / "order-allocation.env"
            env_file.write_text("GRAPH_TENANT_ID=test\n", encoding="utf-8")
            old_value = os.environ.pop("ASK_JUST_GRAPH_ENV_FILE", None)
            try:
                capture.main(
                    [
                        "--output-dir",
                        tmp,
                        "mailbox-inventory",
                        "--family-id",
                        "inventory_vernon",
                        "--freshness-date",
                        "2026-05-06",
                        "--env-file",
                        str(env_file),
                    ]
                )
            finally:
                if old_value is not None:
                    os.environ["ASK_JUST_GRAPH_ENV_FILE"] = old_value
                else:
                    os.environ.pop("ASK_JUST_GRAPH_ENV_FILE", None)

        self.assertEqual(os.environ.get("ASK_JUST_GRAPH_ENV_FILE"), old_value)
        capture_mailbox.assert_called_once()

    def test_evista_cli_accepts_explicit_env_file_for_local_operator_runs(self):
        with tempfile.TemporaryDirectory() as tmp, mock.patch.object(
            capture,
            "capture_evista_inventory",
            return_value=Path(tmp) / "proof.json",
        ) as capture_evista:
            env_file = Path(tmp) / "evista.env"
            env_file.write_text("VERTICAL_USER=test\n", encoding="utf-8")
            old_value = os.environ.pop("ASK_JUST_EVISTA_ENV_FILE", None)
            try:
                capture.main(
                    [
                        "--output-dir",
                        tmp,
                        "evista-inventory",
                        "--freshness-date",
                        "2026-05-06",
                        "--env-file",
                        str(env_file),
                    ]
                )
            finally:
                if old_value is not None:
                    os.environ["ASK_JUST_EVISTA_ENV_FILE"] = old_value
                else:
                    os.environ.pop("ASK_JUST_EVISTA_ENV_FILE", None)

        self.assertEqual(os.environ.get("ASK_JUST_EVISTA_ENV_FILE"), old_value)
        capture_evista.assert_called_once()


if __name__ == "__main__":
    unittest.main()
