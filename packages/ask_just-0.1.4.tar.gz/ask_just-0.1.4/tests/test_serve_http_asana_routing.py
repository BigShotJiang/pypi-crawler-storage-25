import json
import os
import sqlite3
import sys
import unittest


ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
SCRIPTS = os.path.join(ROOT, "scripts")
if SCRIPTS not in sys.path:
    sys.path.insert(0, SCRIPTS)

import serve_http


class ServeHttpAsanaRoutingTests(unittest.TestCase):
    def test_explicit_asana_project_status_beats_batch_status_words(self):
        adapter = serve_http._generic_business_adapter_for_question(
            "What is the status of the Select v6 project in Asana?",
            {"asana_work_management", "batch_release_app"},
        )

        self.assertEqual(adapter["source_id"], "asana_work_management")
        self.assertEqual(adapter["adapter"], "asana_project_status")

    def test_explicit_asana_task_question_uses_task_lookup(self):
        adapter = serve_http._generic_business_adapter_for_question(
            "Which Asana tasks are due for the Select v6 project?",
            {"asana_work_management", "batch_release_app"},
        )

        self.assertEqual(adapter["source_id"], "asana_work_management")
        self.assertEqual(adapter["adapter"], "asana_task_lookup")

    def test_auto_asana_snapshot_beats_hr_from_ask_just_wrapper(self):
        conn = sqlite3.connect(":memory:")
        conn.row_factory = sqlite3.Row
        conn.execute("CREATE TABLE sources (source_id TEXT PRIMARY KEY, boundary_json TEXT)")
        conn.execute("INSERT INTO sources VALUES (?, ?)", ("asana_work_management", "[]"))
        conn.execute("INSERT INTO sources VALUES (?, ?)", ("hr_just_food_company_headcount", "[]"))

        plan = serve_http.build_source_query_plan(
            conn,
            "From Ask Just terminal evidence: Which Asana project count rows are visible in the work-management snapshot?",
        )

        self.assertEqual([step["source_id"] for step in plan], ["asana_work_management"])
        self.assertEqual(plan[0].get("adapter_hint"), "asana_project_status")

    def test_same_source_asana_project_count_and_tasks_plans_two_adapters(self):
        conn = sqlite3.connect(":memory:")
        conn.row_factory = sqlite3.Row
        conn.execute("CREATE TABLE sources (source_id TEXT PRIMARY KEY, boundary_json TEXT)")
        conn.execute("INSERT INTO sources VALUES (?, ?)", ("asana_work_management", "[]"))

        plan = serve_http.build_source_query_plan(
            conn,
            "Within Asana, return both project_count snapshot rows and task/blocker rows. Use asana_work_management only.",
        )

        self.assertEqual([step["source_id"] for step in plan], ["asana_work_management", "asana_work_management"])
        self.assertEqual([step.get("adapter_hint") for step in plan], ["asana_project_status", "asana_task_lookup"])

    def test_asana_snapshot_count_rows_prioritize_requested_count_field(self):
        conn = sqlite3.connect(":memory:")
        conn.row_factory = sqlite3.Row
        conn.executescript(
            """
            CREATE TABLE sources (source_id TEXT PRIMARY KEY, boundary_json TEXT);
            CREATE TABLE source_files (source_id TEXT, path TEXT, sha256 TEXT, modified_at TEXT, parsed TEXT, provenance_grain TEXT);
            CREATE TABLE atomic_rows (
                source_id TEXT,
                source_table TEXT,
                source_file TEXT,
                row_json TEXT,
                provenance_grain TEXT,
                row_key TEXT,
                row_index INTEGER
            );
            """
        )
        conn.execute("INSERT INTO sources VALUES (?, ?)", ("asana_work_management", "[]"))
        conn.execute(
            "INSERT INTO source_files VALUES (?, ?, ?, ?, ?, ?)",
            ("asana_work_management", "asana://snapshot", "abc", "now", "yes", "{}"),
        )
        for row_index, field, value in (
            (1, "counts.attachment_count", 44),
            (2, "counts.project_count", 79),
        ):
            conn.execute(
                "INSERT INTO atomic_rows VALUES (?, ?, ?, ?, ?, ?, ?)",
                (
                    "asana_work_management",
                    "asana_snapshot_fields",
                    "asana://snapshot",
                    json.dumps({"field": field, "value": value}),
                    json.dumps({"source_id": "asana_work_management", "locator": f"asana://snapshot#{field}"}),
                    f"snapshot:rolling_30d:{field}",
                    row_index,
                ),
            )

        rows = serve_http._asana_snapshot_count_rows(conn, "What Asana attachment count rows are visible?", 5)

        self.assertEqual(len(rows), 1)
        self.assertIn("attachment_count", rows[0]["snippet"])

        rows = serve_http._asana_snapshot_count_rows(
            conn,
            "Asana snapshot must include project_count 79 and attachment_count 44, with Asana provenance.",
            5,
        )

        self.assertEqual(len(rows), 2)
        self.assertIn("project_count", rows[0]["snippet"])
        self.assertIn("attachment_count", rows[1]["snippet"])


if __name__ == "__main__":
    unittest.main()
