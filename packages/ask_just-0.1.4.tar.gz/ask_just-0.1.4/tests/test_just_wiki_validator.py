import tempfile
import unittest
from pathlib import Path

import yaml

from scripts.validate_just_wiki import validate


SOURCE_MAP = {
    "sources": [
        {"id": "scorecard_monthly_data"},
        {"id": "spins_breakfast_powertabs"},
        {"id": "satellite_cpg_eat_just_brochure"},
    ]
}


VALID_METRIC_PAGE = """---
type: metric
status: draft
canonical_sources:
  - scorecard_monthly_data
---
# Gross Revenue

## Definition
Gross revenue is a company KPI.

## Canonical Sources
- `scorecard_monthly_data`

## Ask Just Proof Path
Run Ask Just for current values.

## Ask Just Starters
- "What does Ask Just know about gross revenue?"

## Interpretation Notes
Use Scorecard by default.

## Known Gaps
None recorded in this wiki page.

## Related Pages
- [[Metrics]]

## Truth Boundary
The wiki orients; Ask Just proves current facts.
"""


PORTAL_PAGE = """---
type: portal
status: draft
---
# Metrics

## Overview
Employee-facing metric pages.

## Key Pages
- [[Gross Revenue]]

## Ask Just Connection
Ask Just proves current metric values.

## Ask Just Starters
- "Which Ask Just source lane should answer metric questions?"

## Truth Boundary
The wiki orients; Ask Just proves current facts.
"""


VALID_PRODUCT_PAGE = """---
type: product
status: draft
canonical_sources:
  - satellite_cpg_eat_just_brochure
image: ../_assets/products/just-egg.jpg
image_source_id: satellite_cpg_eat_just_brochure
image_locator: https://api.satellitecpg.com/brochure/13#field=platforms[1].platform.catalogMediaUrl
---
# JUST Egg

![JUST Egg](../_assets/products/just-egg.jpg)

> [!info] Source-Lane Badges
> `source-backed` `satellite_cpg_eat_just_brochure` `Ask Just required for exact facts`

## Short Definition
JUST Egg is a product family.

## Why It Matters
Employees browse product pages.

## Connected Concepts
- [[Products]]

## What Ask Just Can Prove
Hosted Ask Just can prove Satellite rows.

## Ask Just Starters
- "What product facts does Ask Just have for Just Egg from Satellite?"

## Current State
Use Ask Just for current facts.

## Known Gaps
None recorded in this fixture.

## Related Pages
- [[Products]]

## Truth Boundary
The wiki orients; Ask Just proves current facts.
"""


SOURCE_LANE_PAGE = """---
type: encyclopedia
status: draft
canonical_sources:
  - scorecard_monthly_data
  - spins_breakfast_powertabs
tags:
  - source-lane
---
# Source Lane

## Short Definition
This is a source lane fixture.

## Why It Matters
It proves source-lane coverage checks.

## Connected Concepts
None in this fixture.

## What Ask Just Can Prove
Hosted Ask Just can prove rows from the declared source ids.

## Ask Just Starters
- "What rows are available in this source lane?"

## Current State
The fixture is intentionally incomplete.

## Known Gaps
One source id is missing on purpose.

## Related Pages
None in this fixture.

## Truth Boundary
Hosted Ask Just proves exact rows and freshness.
"""


class JustWikiValidatorTest(unittest.TestCase):
    def write_fixture(self, files):
        tempdir = tempfile.TemporaryDirectory()
        root = Path(tempdir.name)
        wiki = root / "wiki"
        wiki.mkdir()
        source_map = root / "fresh-source-map.yaml"
        source_map.write_text(yaml.safe_dump(SOURCE_MAP))
        for rel_path, text in files.items():
            path = wiki / rel_path
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(text)
        asset = wiki / "_assets" / "products" / "just-egg.jpg"
        asset.parent.mkdir(parents=True, exist_ok=True)
        asset.write_bytes(b"fake image")
        return tempdir, wiki, source_map

    def test_validates_wikilinks_sections_and_source_ids(self):
        tempdir, wiki, source_map = self.write_fixture(
            {
                "Metrics.md": PORTAL_PAGE,
                "Gross Revenue.md": VALID_METRIC_PAGE,
            }
        )
        with tempdir:
            self.assertEqual(validate(wiki, source_map), [])

    def test_flags_unresolved_wikilinks(self):
        tempdir, wiki, source_map = self.write_fixture(
            {
                "Metrics.md": PORTAL_PAGE.replace("[[Gross Revenue]]", "[[Missing Page]]"),
                "Gross Revenue.md": VALID_METRIC_PAGE,
            }
        )
        with tempdir:
            errors = validate(wiki, source_map)
        self.assertTrue(any("unresolved wikilink" in error for error in errors))

    def test_flags_published_page_linking_to_unpublished_page(self):
        published_portal = PORTAL_PAGE.replace(
            "status: draft\n",
            "status: draft\npublish: true\n",
        )
        tempdir, wiki, source_map = self.write_fixture(
            {
                "Metrics.md": published_portal,
                "Gross Revenue.md": VALID_METRIC_PAGE,
            }
        )
        with tempdir:
            errors = validate(wiki, source_map)
        self.assertTrue(
            any("published page links to unpublished page '[[Gross Revenue]]'" in error for error in errors)
        )

    def test_flags_unknown_source_ids(self):
        tempdir, wiki, source_map = self.write_fixture(
            {
                "Metrics.md": PORTAL_PAGE,
                "Gross Revenue.md": VALID_METRIC_PAGE.replace(
                    "scorecard_monthly_data", "unknown_source"
                ),
            }
        )
        with tempdir:
            errors = validate(wiki, source_map)
        self.assertTrue(any("unknown source id 'unknown_source'" in error for error in errors))

    def test_flags_local_proof_path_language(self):
        tempdir, wiki, source_map = self.write_fixture(
            {
                "Metrics.md": PORTAL_PAGE,
                "Gross Revenue.md": VALID_METRIC_PAGE.replace(
                    "Ask Just proves current facts.",
                    "Ask Just proves current facts from local SQLite.",
                ),
            }
        )
        with tempdir:
            errors = validate(wiki, source_map)
        self.assertTrue(any("banned local proof-path phrase 'local sqlite'" in error for error in errors))

    def test_requires_product_image_metadata(self):
        tempdir, wiki, source_map = self.write_fixture(
            {
                "Products.md": PORTAL_PAGE.replace("Metrics", "Products").replace("Gross Revenue", "JUST Egg"),
                "Products/JUST Egg.md": VALID_PRODUCT_PAGE.replace(
                    "image: ../_assets/products/just-egg.jpg\n", ""
                ),
            }
        )
        with tempdir:
            errors = validate(wiki, source_map)
        self.assertTrue(any("product page missing frontmatter field 'image'" in error for error in errors))

    def test_requires_product_source_lane_badges(self):
        tempdir, wiki, source_map = self.write_fixture(
            {
                "Products.md": PORTAL_PAGE.replace("Metrics", "Products").replace("Gross Revenue", "JUST Egg"),
                "Products/JUST Egg.md": VALID_PRODUCT_PAGE.replace(
                    "\n> [!info] Source-Lane Badges\n> `source-backed` `satellite_cpg_eat_just_brochure` `Ask Just required for exact facts`\n",
                    "",
                ),
            }
        )
        with tempdir:
            errors = validate(wiki, source_map)
        self.assertTrue(any("product page missing Source-Lane Badges callout" in error for error in errors))

    def test_requires_source_bound_pages_to_declare_source_ids(self):
        page = VALID_METRIC_PAGE.replace(
            "canonical_sources:\n  - scorecard_monthly_data\n", ""
        )
        tempdir, wiki, source_map = self.write_fixture(
            {
                "Metrics.md": PORTAL_PAGE,
                "Gross Revenue.md": page,
            }
        )
        with tempdir:
            errors = validate(wiki, source_map)
        self.assertTrue(
            any("source-bound page missing declared Ask Just source ids" in error for error in errors)
        )

    def test_requires_source_lane_pages_to_cover_declared_source_ids(self):
        tempdir, wiki, source_map = self.write_fixture(
            {
                "Source Lanes/Example.md": SOURCE_LANE_PAGE,
            }
        )
        with tempdir:
            errors = validate(wiki, source_map)
        self.assertTrue(
            any(
                "source lane inventory missing wiki Source Lanes coverage for 'satellite_cpg_eat_just_brochure'"
                in error
                for error in errors
            )
        )

    def test_requires_source_backed_pages_to_include_example_provenance(self):
        page = VALID_METRIC_PAGE.replace("status: draft", "status: source-backed")
        tempdir, wiki, source_map = self.write_fixture(
            {
                "Metrics.md": PORTAL_PAGE,
                "Gross Revenue.md": page,
            }
        )
        with tempdir:
            errors = validate(wiki, source_map)
        self.assertTrue(
            any(
                "source-backed page missing '## Example Ask Just Provenance'" in error
                for error in errors
            )
        )

    def test_requires_guided_and_source_backed_pages_to_include_ask_just_starters(self):
        page = VALID_METRIC_PAGE.replace("status: draft", "status: guided").replace(
            '\n## Ask Just Starters\n- "What does Ask Just know about gross revenue?"\n',
            "",
        )
        tempdir, wiki, source_map = self.write_fixture(
            {
                "Metrics.md": PORTAL_PAGE,
                "Gross Revenue.md": page,
            }
        )
        with tempdir:
            errors = validate(wiki, source_map)
        self.assertTrue(
            any(
                "guided page missing '## Ask Just Starters'" in error
                for error in errors
            )
        )


if __name__ == "__main__":
    unittest.main()
