---
name: braintrust
description: Use when inspecting, verifying, or extending Ask Just Braintrust traces, spans, project logs, evals, prompts, or `bt` CLI setup.
---

# Braintrust For Ask Just

Use this skill for Ask Just observability work in Braintrust.

## Project Context

- Braintrust org/profile: `Andes`
- Braintrust project: `ask-just`
- Project id: `2a580ddb-dbad-4acd-a8b7-eacc2ab91123`
- Repo config: `.bt/config.json`
- Runtime tracer: `scripts/braintrust_tracing.py`
- HTTP trace wrapper: `scripts/serve_http.py`
- CLI trace helpers: `scripts/ask_just.py`

## Contract

- Prefer the `bt` CLI over direct API calls for project, trace, log, prompt, and setup inspection.
- Use `--json` for anything that will be parsed or cited.
- Do not print `BRAINTRUST_API_KEY`.
- A query is fully wired only when the runtime response includes `trace_id` and Braintrust can read back the trace.
- Ask Just tracing must fail open: missing Braintrust SDK or API key must not break source queries.
- Preserve the user's plain-English question in `trace.user_question`. For structured SQL reads, pass the natural-language question separately with `ask-just --include-trace sql --question "list just employees" "SELECT ..."`. The span output should keep `question` as the user asked it and put the actual SQL in `executed_sql`.

## Common Commands

```bash
bt status --json
bt setup doctor --local --json --profile Andes
bt view trace --object-ref project_logs:2a580ddb-dbad-4acd-a8b7-eacc2ab91123 --trace-id TRACE_ID --json --profile Andes --prefer-profile
ask-just trace-url TRACE_ID
ask-just --include-trace query "gross revenue" --source scorecard_monthly_data --limit 5
ask-just --include-trace sql --question "list just employees" "SELECT ..." --limit 100
```

## Verification Pattern

1. Run a real Ask Just query through the intended surface.
2. Confirm the response includes `trace_id`, `trace_project`, `trace_project_id`, and `trace_url`.
3. Read the trace back with `bt view trace`.
4. Confirm `trace.user_question` shows the original user wording. If the operation is `sql`, confirm the SQL appears as `executed_sql`, not as the main `question`.
5. Confirm the trace has the expected span shape:
   - `ask_just.query`
   - `trace.user_question`
   - `trace.tool_call.1.ask_just_source_query`
   - `trace.selected_evidence`
   - `trace.source_receipts`
   - `trace.final_answer`

## Local Docs

Detailed Braintrust docs fetched by `bt setup` live under `.bt/skills/docs/`.
Load only the relevant section when needed, usually:

- `.bt/skills/docs/instrument/trace-application-logic.md`
- `.bt/skills/docs/observe/examine-traces.md`
- `.bt/skills/docs/reference/sql.md`
