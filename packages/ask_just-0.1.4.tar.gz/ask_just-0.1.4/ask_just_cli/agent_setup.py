import hashlib
import json
import os
import pathlib
import re
import shutil
import urllib.error
import urllib.request


ASK_JUST_SKILLS = ("askjust", "just-source", "correction", "braintrust")
MANAGED_BEGIN = "<!-- ASK_JUST_INSTALLER_BEGIN -->"
MANAGED_END = "<!-- ASK_JUST_INSTALLER_END -->"
MANAGED_BLOCK = f"""{MANAGED_BEGIN}
## Ask Just

- Ask Just is the default answer path for Just company, product, source, metric, operations, R&D, customer, and internal-work questions.
- Use the installed `askjust` skill and hosted `ask-just` source plane without requiring the user to type a command or skill name.
- Do not use web search, general model knowledge, raw local files, SSH, direct SQLite, or alternate surfaces for Ask Just answers. If hosted Ask Just cannot answer, say there is an Ask Just source gap or setup problem.
{MANAGED_END}
"""


def repo_root():
    return pathlib.Path(__file__).resolve().parents[1]


def is_truthy(value):
    return str(value or "").lower() in {"1", "true", "yes", "y", "on"}


def package_skills_root():
    override = os.environ.get("ASK_JUST_PACKAGE_SKILLS_ROOT")
    if override:
        return pathlib.Path(override)
    return pathlib.Path(__file__).resolve().parent / "skills"


def repo_skills_root():
    override = os.environ.get("ASK_JUST_REPO_SKILLS_ROOT")
    if override:
        return pathlib.Path(override)
    return repo_root() / "skills"


def canonical_skills_root():
    override = os.environ.get("ASK_JUST_CANONICAL_SKILLS_ROOT")
    if override:
        return pathlib.Path(override)
    root = repo_skills_root()
    if root.exists():
        return root
    return package_skills_root()


def sha256_bytes(data):
    return hashlib.sha256(data).hexdigest()


def sha256_file(path):
    path = pathlib.Path(path)
    if not path.exists():
        return None
    return sha256_bytes(path.read_bytes())


def skill_file(root, skill_name):
    return pathlib.Path(root) / skill_name / "SKILL.md"


def tree_files(root):
    root = pathlib.Path(root)
    if not root.exists():
        return []
    return [
        path
        for path in sorted(root.rglob("*"))
        if path.is_file() and "__pycache__" not in path.parts
    ]


def copy_skill_tree(source_root, target_root, skill_name):
    source = pathlib.Path(source_root) / skill_name
    target = pathlib.Path(target_root) / "skills" / skill_name
    if target.exists():
        shutil.rmtree(target)
    shutil.copytree(source, target)
    return [str(path) for path in tree_files(target)]


def replace_managed_block(path, default_title):
    path.parent.mkdir(parents=True, exist_ok=True)
    text = path.read_text() if path.exists() else f"# {default_title}\n\n"
    pattern = re.compile(rf"{re.escape(MANAGED_BEGIN)}.*?{re.escape(MANAGED_END)}", flags=re.DOTALL)
    if pattern.search(text):
        text = pattern.sub(MANAGED_BLOCK.rstrip(), text)
    else:
        if text and not text.endswith("\n"):
            text += "\n"
        if text.strip():
            text += "\n"
        text += MANAGED_BLOCK
    path.write_text(text.rstrip() + "\n")


def install_skill_tree(target_root):
    source_root = package_skills_root()
    if not source_root.exists():
        source_root = repo_skills_root()
    installed = []
    for skill in ASK_JUST_SKILLS:
        installed.extend(copy_skill_tree(source_root, target_root, skill))
    return installed


def ensure_codex_skill_config(codex_root):
    config_path = codex_root / "config.toml"
    lines = config_path.read_text().splitlines() if config_path.exists() else []

    def table_ranges():
        starts = [index for index, line in enumerate(lines) if line.strip() == "[[skills.config]]"]
        ranges = []
        for start in starts:
            end = len(lines)
            for index in range(start + 1, len(lines)):
                stripped = lines[index].strip()
                if stripped.startswith("[") and stripped.endswith("]"):
                    end = index
                    break
            ranges.append((start, end))
        return ranges

    def ensure_enabled(skill):
        nonlocal lines
        skill_path = codex_root / "skills" / skill / "SKILL.md"
        expected_path = f"path = {json.dumps(str(skill_path))}"
        for start, end in table_ranges():
            block = [line.strip() for line in lines[start:end]]
            if expected_path not in block:
                continue
            for index in range(start + 1, end):
                if lines[index].strip().startswith("enabled"):
                    lines[index] = "enabled = true"
                    return
            lines.insert(end, "enabled = true")
            return
        if lines and lines[-1].strip():
            lines.append("")
        lines.extend(["[[skills.config]]", expected_path, "enabled = true", ""])

    for skill in ASK_JUST_SKILLS:
        ensure_enabled(skill)
    config_path.parent.mkdir(parents=True, exist_ok=True)
    config_path.write_text("\n".join(lines).rstrip() + "\n")
    return str(config_path)


def setup_agents(home=None, agents=("codex", "claude")):
    home_path = pathlib.Path(home or os.path.expanduser("~"))
    agents = tuple(agents)
    changed = []
    if "codex" in agents:
        codex_root = home_path / ".codex" if home is not None else pathlib.Path(os.environ.get("CODEX_HOME") or home_path / ".codex")
        changed.extend(install_skill_tree(codex_root))
        changed.append(ensure_codex_skill_config(codex_root))
        replace_managed_block(codex_root / "AGENTS.md", "AGENTS.md")
    if "claude" in agents:
        claude_root = home_path / ".claude" if home is not None else pathlib.Path(os.environ.get("CLAUDE_HOME") or home_path / ".claude")
        changed.extend(install_skill_tree(claude_root))
        replace_managed_block(claude_root / "CLAUDE.md", "CLAUDE.md")
    return {"ok": True, "changed": changed, "agents": list(agents)}


def codex_config_path(codex_root):
    return pathlib.Path(codex_root) / "config.toml"


def codex_skill_config_enabled(codex_root, skill_name):
    config_path = codex_config_path(codex_root)
    if not config_path.exists():
        return False, str(config_path)
    expected_path = pathlib.Path(codex_root) / "skills" / skill_name / "SKILL.md"
    expected_path_line = f"path = {json.dumps(str(expected_path))}"
    in_skill_config = False
    path_matches = False
    enabled = False
    for raw_line in config_path.read_text(encoding="utf-8").splitlines() + ["["]:
        line = raw_line.strip()
        if line.startswith("["):
            if in_skill_config and path_matches:
                return enabled, str(config_path)
            in_skill_config = line == "[[skills.config]]"
            path_matches = False
            enabled = False
            continue
        if not in_skill_config or "=" not in line:
            continue
        key, _value = line.split("=", 1)
        key = key.strip()
        if key == "path" and line == expected_path_line:
            path_matches = True
        elif key == "enabled":
            enabled = line.split("=", 1)[1].strip().lower() == "true"
    return False, str(config_path)


def managed_block_present(path):
    path = pathlib.Path(path)
    if not path.exists():
        return False
    text = path.read_text(encoding="utf-8")
    required = [
        MANAGED_BEGIN,
        MANAGED_END,
        "Ask Just is the default answer path",
        "without requiring the user to type a command or skill name",
        "Do not use web search",
    ]
    return all(item in text for item in required)


def fetch_url_bytes(url):
    try:
        with urllib.request.urlopen(url, timeout=15) as response:
            return True, response.read(), None
    except urllib.error.HTTPError as exc:
        return False, b"", f"http_{exc.code}"
    except urllib.error.URLError as exc:
        return False, b"", str(exc)


def surface_record(skill_name, surface_name, location, canonical_sha, data=None, exists=None, error=None):
    if exists is None:
        exists = data is not None
    actual_sha = sha256_bytes(data) if data is not None else None
    ok = bool(exists) and actual_sha == canonical_sha
    if not exists:
        gap = f"{surface_name}_skill_missing:{skill_name}"
    elif not ok:
        gap = f"{surface_name}_skill_mismatch:{skill_name}"
    else:
        gap = None
    return {
        "skill_name": skill_name,
        "surface_name": surface_name,
        "path_or_url": str(location),
        "exists": bool(exists),
        "sha256": actual_sha,
        "canonical_sha256": canonical_sha,
        "ok": ok,
        "required_gap": gap,
        **({"error": error} if error else {}),
    }


def local_skill_record(skill_name, surface_name, path, canonical_sha):
    path = pathlib.Path(path)
    data = path.read_bytes() if path.exists() else None
    return surface_record(skill_name, surface_name, path, canonical_sha, data=data, exists=path.exists())


def hosted_skill_record(skill_name, base_url, canonical_sha):
    url = f"{base_url.rstrip('/')}/skills/{skill_name}/SKILL.md"
    exists, data, error = fetch_url_bytes(url)
    return surface_record(skill_name, "hosted", url, canonical_sha, data=data if exists else None, exists=exists, error=error)


def build_parity_report(url, token=None, home=None, codex_home=None, claude_home=None):
    del token
    home_path = pathlib.Path(home or os.path.expanduser("~"))
    codex_root = pathlib.Path(codex_home or os.environ.get("CODEX_HOME") or home_path / ".codex")
    claude_root = pathlib.Path(claude_home or os.environ.get("CLAUDE_HOME") or home_path / ".claude")
    repo_root_path = repo_skills_root()
    package_root_path = package_skills_root()
    canonical_root = canonical_skills_root()
    include_repo = repo_root_path.exists() or is_truthy(os.environ.get("ASK_JUST_REQUIRE_REPO_PUBLIC"))

    skill_records = []
    required_gaps = []

    def add_gap(gap):
        if gap and gap not in required_gaps:
            required_gaps.append(gap)

    for skill_name in ASK_JUST_SKILLS:
        canonical_path = skill_file(canonical_root, skill_name)
        canonical_bytes = canonical_path.read_bytes() if canonical_path.exists() else b""
        canonical_sha = sha256_bytes(canonical_bytes)
        if not canonical_path.exists():
            add_gap(f"canonical_skill_missing:{skill_name}")

        if include_repo:
            record = local_skill_record(skill_name, "repo_public", skill_file(repo_root_path, skill_name), canonical_sha)
            skill_records.append(record)
            add_gap(record["required_gap"])

        for surface_name, path in (
            ("package", skill_file(package_root_path, skill_name)),
            ("codex", codex_root / "skills" / skill_name / "SKILL.md"),
            ("claude", claude_root / "skills" / skill_name / "SKILL.md"),
        ):
            record = local_skill_record(skill_name, surface_name, path, canonical_sha)
            skill_records.append(record)
            add_gap(record["required_gap"])

        hosted_record = hosted_skill_record(skill_name, url, canonical_sha)
        skill_records.append(hosted_record)
        add_gap(hosted_record["required_gap"])

        enabled, config_path = codex_skill_config_enabled(codex_root, skill_name)
        if not enabled:
            add_gap(f"codex_skill_disabled:{skill_name}")

    codex_agents_path = codex_root / "AGENTS.md"
    claude_agents_path = claude_root / "CLAUDE.md"
    codex_block_ok = managed_block_present(codex_agents_path)
    claude_block_ok = managed_block_present(claude_agents_path)
    if not codex_block_ok:
        add_gap("global_codex_ask_just_rule_missing")
    if not claude_block_ok:
        add_gap("global_claude_ask_just_rule_missing")

    return {
        "ok": not required_gaps,
        "status": "parity_ready" if not required_gaps else "parity_needs_attention",
        "configured_url": url,
        "canonical_surface": "repo_public" if include_repo else "package",
        "canonical_root": str(canonical_root),
        "codex_home": str(codex_root),
        "claude_home": str(claude_root),
        "required_gaps": required_gaps,
        "skill_records": skill_records,
        "setup_records": [
            {
                "name": "codex_skills_enabled",
                "ok": not any(gap.startswith("codex_skill_disabled:") for gap in required_gaps),
                "path_or_url": str(config_path),
            },
            {
                "name": "global_codex_ask_just_rule",
                "ok": codex_block_ok,
                "path_or_url": str(codex_agents_path),
                "required_gap": None if codex_block_ok else "global_codex_ask_just_rule_missing",
            },
            {
                "name": "global_claude_ask_just_rule",
                "ok": claude_block_ok,
                "path_or_url": str(claude_agents_path),
                "required_gap": None if claude_block_ok else "global_claude_ask_just_rule_missing",
            },
        ],
    }
