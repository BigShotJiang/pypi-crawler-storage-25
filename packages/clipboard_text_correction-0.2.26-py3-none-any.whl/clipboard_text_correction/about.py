# about.py

__version__ = "0.2.26"
__package__ = "clipboard_text_correction"
__linux_indicator__ = "clipboard-text-correction-indicator"
__author__ = "Fernando Pujaico Rivera" 
__email__ = "fernando.pujaico.rivera@gmail.com"
__description__ = "Program that collects text from the clipboard and improves text writing"
__url_source__ = "https://github.com/trucomanx-desktop/ClipboardTextCorrection"
__url_doc__ = "https://github.com/trucomanx-desktop/ClipboardTextCorrection/tree/main/doc"
__url_funding__ = "https://trucomanx.github.io/en/funding.html"
__url_bugs__ = "https://github.com/trucomanx-desktop/ClipboardTextCorrection/issues"


