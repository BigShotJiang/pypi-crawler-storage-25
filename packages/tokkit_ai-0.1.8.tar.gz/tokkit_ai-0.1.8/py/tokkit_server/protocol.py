"""JSON-RPC 2.0 protocol helpers for the MCP server."""
import json

PARSE_ERROR = -32700
INVALID_REQUEST = -32600
METHOD_NOT_FOUND = -32601
INTERNAL_ERROR = -32603

TOOL_DEFINITIONS = [
    {
        "name": "index_repository",
        "description": (
            "Index a repository to build a code intelligence graph. "
            "MUST be called before any other graph tool (search_graph, trace_path, etc.). "
            "Parses Python, JavaScript, and TypeScript files using tree-sitter, "
            "builds a knowledge graph of functions, classes, calls, and imports, "
            "and stores it for fast querying. Indexing takes 1-5 seconds for typical repos."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "path": {"type": "string", "description": "Absolute path to the repository root."},
                "force": {"type": "boolean", "description": "Force re-indexing even if already indexed."},
            },
            "required": ["path"],
        },
    },
    {
        "name": "search_graph",
        "description": (
            "Search the code graph for symbols (functions, classes, methods). "
            "Returns qualified names in the format project::file_path::symbol_name. "
            "Use these qualified names with get_code_snippet and trace_path. "
            "Requires index_repository to be called first."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "query": {"type": "string", "description": "Search query string (matches symbol names)."},
                "label": {"type": "string", "description": "Filter by node label: Function, Class, Method, Module, Route."},
                "limit": {"type": "integer", "description": "Maximum number of results (default: 20)."},
                "name_pattern": {"type": "string", "description": "Regex pattern to match node names."},
                "max_degree": {"type": "integer", "description": "Filter nodes with total degree <= N. Use 0 for dead code."},
                "exclude_entry_points": {"type": "boolean", "description": "Exclude main, __init__, test functions, route handlers."},
                "relationship": {"type": "string", "description": "Filter to nodes participating in this edge type (CALLS, HANDLES, TESTS, CO_CHANGED, SIMILAR_TO)."},
            },
            "required": ["query"],
        },
    },
    {
        "name": "trace_path",
        "description": (
            "Trace the call or dependency path between two code entities. "
            "Uses BFS across the knowledge graph. Returns each step with edge type and confidence score. "
            "Requires index_repository to be called first."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "from_node": {"type": "string", "description": "Starting node qualified name (from search_graph results)."},
                "to_node": {"type": "string", "description": "Ending node qualified name (from search_graph results)."},
            },
            "required": ["from_node", "to_node"],
        },
    },
    {
        "name": "trace_fan",
        "description": (
            "Fan-out/fan-in trace from a starting node. Shows what a function calls (outbound) "
            "or what calls it (inbound). Requires index_repository to be called first."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "function_name": {"type": "string", "description": "Starting node qualified name (from search_graph results)."},
                "direction": {"type": "string", "enum": ["inbound", "outbound", "both"], "description": "Edge direction to follow (default: both)."},
                "depth": {"type": "integer", "description": "Maximum traversal depth (default: 3)."},
            },
            "required": ["function_name"],
        },
    },
    {
        "name": "get_code_snippet",
        "description": (
            "Retrieve the source code for a specific function or class. "
            "Returns just the symbol body, not the entire file — much more token-efficient than reading files. "
            "Use search_graph first to find the exact qualified name. "
            "Requires index_repository to be called first."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "symbol": {"type": "string", "description": "Qualified name (project::file::symbol) from search_graph results."},
                "context_lines": {"type": "integer", "description": "Number of context lines around the snippet (default: 0)."},
            },
            "required": ["symbol"],
        },
    },
    {
        "name": "get_architecture",
        "description": (
            "Get a high-level architectural overview: languages, packages, key files, entry points. "
            "Much more efficient than reading the entire repo. "
            "Requires index_repository to be called first."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {},
        },
    },
    {
        "name": "search_code",
        "description": "Search for code patterns within the indexed repository. (Currently stubbed — use grep/ripgrep for text search.)",
        "inputSchema": {
            "type": "object",
            "properties": {
                "pattern": {"type": "string", "description": "Search pattern (regex or literal)."},
                "file_glob": {"type": "string", "description": "Optional glob to restrict files searched."},
                "limit": {"type": "integer", "description": "Maximum results to return."},
            },
            "required": ["pattern"],
        },
    },
    {
        "name": "detect_changes",
        "description": (
            "Detect files changed since the last index. Useful to know when to re-index. "
            "Requires index_repository to be called first."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {},
        },
    },
    {
        "name": "index_status",
        "description": "Check whether a repository is indexed and get node/edge counts.",
        "inputSchema": {
            "type": "object",
            "properties": {},
        },
    },
    {
        "name": "list_projects",
        "description": "List all indexed projects in the cache.",
        "inputSchema": {
            "type": "object",
            "properties": {},
        },
    },
    {
        "name": "delete_project",
        "description": "Delete the index for a project from the cache.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "project": {"type": "string", "description": "Project name to delete."},
            },
            "required": ["project"],
        },
    },
    {
        "name": "get_graph_schema",
        "description": (
            "Return available node labels (Function, Class, etc.) and edge types "
            "(CALLS, IMPORTS, TESTS, CO_CHANGED, etc.) in the graph. "
            "Requires index_repository to be called first."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {},
        },
    },
    {
        "name": "get_token_stats",
        "description": "Get aggregate token savings statistics — total queries, tokens saved, savings percentage.",
        "inputSchema": {
            "type": "object",
            "properties": {},
        },
    },
    {
        "name": "clean_html",
        "description": (
            "Strip noise from HTML and convert to token-optimized markdown or text. "
            "Removes scripts, styles, navigation, ads, and other irrelevant content. "
            "Typically saves 60-90% of tokens. Does NOT require index_repository."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "html": {
                    "type": "string",
                    "description": "Raw HTML content to clean.",
                },
                "mode": {
                    "type": "string",
                    "enum": ["markdown", "text", "minimal"],
                    "description": "Output mode. 'markdown' (default): semantic markdown. 'text': plain text. 'minimal': light clean, keep HTML.",
                },
            },
            "required": ["html"],
        },
    },
    {
        "name": "compact_json",
        "description": (
            "Convert JSON to a token-optimized format (CSV or YAML). "
            "Auto-detects: CSV for flat/tabular data (saves 50-70%), YAML for nested data (saves 20-30%). "
            "Does NOT require index_repository."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "json": {
                    "type": "string",
                    "description": "Raw JSON string to compact.",
                },
            },
            "required": ["json"],
        },
    },
]


def parse_request(line: str) -> dict:
    """Parse a JSON-RPC 2.0 request line.

    Returns a dict with id, method, and params keys.
    Raises ValueError on invalid input.
    """
    try:
        data = json.loads(line)
    except json.JSONDecodeError as exc:
        raise ValueError(f"Invalid JSON: {exc}") from exc

    if not isinstance(data, dict):
        raise ValueError("Request must be a JSON object")

    return {
        "id": data.get("id"),
        "method": data.get("method"),
        "params": data.get("params", {}),
    }


def build_response(request_id, result) -> str:
    """Build a JSON-RPC 2.0 success response."""
    return json.dumps({"jsonrpc": "2.0", "id": request_id, "result": result})


def build_error(request_id, code: int, message: str, data=None) -> str:
    """Build a JSON-RPC 2.0 error response."""
    error: dict = {"code": code, "message": message}
    if data is not None:
        error["data"] = data
    return json.dumps({"jsonrpc": "2.0", "id": request_id, "error": error})


def build_initialize_response(request_id) -> str:
    """Build the MCP initialize response."""
    return build_response(
        request_id,
        {
            "protocolVersion": "2024-11-05",
            "capabilities": {"tools": {}},
            "serverInfo": {"name": "tokkit", "version": "0.1.8"},
        },
    )


def build_tools_list_response(request_id) -> str:
    """Build the MCP tools/list response."""
    return build_response(request_id, {"tools": TOOL_DEFINITIONS})
