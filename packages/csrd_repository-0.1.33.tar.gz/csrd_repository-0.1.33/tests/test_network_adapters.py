"""Tests for MariaAdapter and PGAdapter.

These tests patch runtime driver imports so they run without pymysql/psycopg
installed in the unit-test environment.
"""

from __future__ import annotations

from types import SimpleNamespace

import pytest

from csrd.repository import MariaAdapter, PGAdapter


class _FakeMariaConn:
    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb):
        return None

    def cursor(self):
        return self

    def execute(self, query, params):
        self._last = (query, params)

    def fetchone(self):
        return {"ok": True}

    def fetchall(self):
        return [{"ok": True}]

    @property
    def rowcount(self):
        return 1

    @property
    def lastrowid(self):
        return 42


class _FakePGCursor:
    def __init__(self):
        self.rowcount = 1

    def fetchone(self):
        return {"ok": True}

    def fetchall(self):
        return [{"ok": True}]


class _FakePGConn:
    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb):
        return None

    def execute(self, query, params):
        self._last = (query, params)
        return _FakePGCursor()


def _patch_maria_import(monkeypatch: pytest.MonkeyPatch) -> None:
    import csrd.repository.maria_adapter as maria_mod

    def fake_import(name: str):
        if name == "pymysql":
            return SimpleNamespace(connect=lambda **kwargs: _FakeMariaConn())
        if name == "pymysql.cursors":
            return SimpleNamespace(DictCursor=object)
        raise ModuleNotFoundError(name)

    monkeypatch.setattr(maria_mod, "import_module", fake_import)


def _patch_pg_import(monkeypatch: pytest.MonkeyPatch) -> None:
    import csrd.repository.pg_adapter as pg_mod

    def fake_import(name: str):
        if name == "psycopg":
            return SimpleNamespace(
                connect=lambda conninfo, row_factory=None, autocommit=True: _FakePGConn()
            )
        if name == "psycopg.rows":
            return SimpleNamespace(dict_row=object)
        raise ModuleNotFoundError(name)

    monkeypatch.setattr(pg_mod, "import_module", fake_import)


class TestMariaAdapter:
    @pytest.mark.asyncio
    async def test_upsert_sql_shape(self, monkeypatch: pytest.MonkeyPatch):
        _patch_maria_import(monkeypatch)
        adapter = MariaAdapter(host="db", port=3306, user="u", password="p", database="d")

        captured: dict[str, object] = {}

        async def fake_execute(query, params):
            captured["query"] = query
            captured["params"] = params
            return 1

        monkeypatch.setattr(adapter, "execute", fake_execute)

        rows = await adapter.upsert(
            "items",
            {"name": "Widget", "updated_at": "2026-01-01T00:00:00Z"},
            {"id": "123"},
        )

        assert rows == 1
        assert "ON DUPLICATE KEY UPDATE" in str(captured["query"])


class TestPGAdapter:
    @pytest.mark.asyncio
    async def test_upsert_sql_shape(self, monkeypatch: pytest.MonkeyPatch):
        _patch_pg_import(monkeypatch)
        adapter = PGAdapter(host="db", port=5432, user="u", password="p", database="d")

        captured: dict[str, object] = {}

        async def fake_execute(query, params):
            captured["query"] = query
            captured["params"] = params
            return 1

        monkeypatch.setattr(adapter, "execute", fake_execute)

        rows = await adapter.upsert(
            "items",
            {"name": "Widget", "updated_at": "2026-01-01T00:00:00Z"},
            {"id": "123"},
        )

        assert rows == 1
        assert "ON CONFLICT" in str(captured["query"])


def test_repository_exports_network_adapters(monkeypatch: pytest.MonkeyPatch):
    _patch_maria_import(monkeypatch)
    _patch_pg_import(monkeypatch)

    maria = MariaAdapter(host="db", port=3306, user="u", password="p", database="d")
    pg = PGAdapter(host="db", port=5432, user="u", password="p", database="d")

    assert maria is not None
    assert pg is not None
