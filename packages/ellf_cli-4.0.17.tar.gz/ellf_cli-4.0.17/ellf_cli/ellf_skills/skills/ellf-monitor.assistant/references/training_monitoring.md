# Training Monitoring

How to monitor training jobs from the web assistant and interpret their signals.

## What the web assistant can do

Use broker-backed status, logs, and errors to determine:
- whether the training action is running
- whether it completed or failed
- whether logs show loss, score, or alert-like signals

## What to report

- current state
- the most recent useful metrics visible in logs
- obvious alerts such as failure, divergence, or long stalls
- whether the user should intervene

## Limits

- Do not promise automatic evaluation from the web assistant
- Do not modify training config here
- If the issue requires a restart or worker change, route to `/ellf-ops`
- If the issue requires code or config changes, route to `/ellf-handoff`

## Common alert classes

- `failed`: the process exited or the job entered an error state
- `nan_loss`: training diverged and likely needs immediate intervention
- `plateau`: scores stop improving for a sustained period
- `overfitting`: dev performance declines while training appears to continue improving
- `completed`: training finished normally

## Response pattern

1. confirm the state
2. show the most important evidence
3. explain the likely interpretation
4. recommend the next action
