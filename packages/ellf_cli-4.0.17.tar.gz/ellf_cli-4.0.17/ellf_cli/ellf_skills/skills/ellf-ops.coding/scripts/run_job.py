"""Minimal job runner — launches a command, tracks status in job_status.json."""

import argparse
import json
import subprocess
from datetime import datetime, timezone
from pathlib import Path


def write_status(path: Path, data: dict):
    path.write_text(json.dumps(data, indent=2))


def main():
    parser = argparse.ArgumentParser(description="Run a training job and track status.")
    parser.add_argument("--command", required=True, help="Full command to execute")
    parser.add_argument("--output-dir", required=True, help="Output directory")
    args = parser.parse_args()

    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    status_path = Path("job_status.json")

    start_time = datetime.now(timezone.utc).isoformat()

    process = subprocess.Popen(
        args.command,
        shell=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
    )

    write_status(
        status_path,
        {
            "pid": process.pid,
            "command": args.command,
            "output_dir": str(output_dir),
            "start_time": start_time,
            "status": "running",
        },
    )

    if process.stdout:
        for line in process.stdout:
            print(line.decode(), end="")

    process.wait()
    end_time = datetime.now(timezone.utc).isoformat()
    duration_s = (
        datetime.fromisoformat(end_time) - datetime.fromisoformat(start_time)
    ).total_seconds()

    write_status(
        status_path,
        {
            "pid": process.pid,
            "command": args.command,
            "output_dir": str(output_dir),
            "start_time": start_time,
            "end_time": end_time,
            "duration_seconds": round(duration_s, 1),
            "exit_code": process.returncode,
            "status": "completed" if process.returncode == 0 else "failed",
        },
    )


if __name__ == "__main__":
    main()
