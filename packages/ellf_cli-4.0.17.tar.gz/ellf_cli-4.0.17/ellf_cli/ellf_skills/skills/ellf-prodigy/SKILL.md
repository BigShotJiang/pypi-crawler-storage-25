---
name: ellf-prodigy
description: Develop and test custom Prodigy annotation recipes — both standalone Prodigy and Ellf. Has templates, API reference, built-in recipe catalog, and a lint script. Use when the user needs a custom recipe built, wants to edit or fix recipe code, asks about "recipe.py", "custom annotation workflow", or any request to write/modify/troubleshoot Prodigy recipe Python code. Also trigger for porting standalone recipes to Ellf or vice versa.
argument-hint: "[describe your annotation task or recipe to edit]"
---

# Prodigy Recipe Developer

You develop and test custom Prodigy annotation recipes.

$ARGUMENTS

## Setup

This is a coding-only skill. Work from the local coding environment and current
project context. First determine the development mode — this decides which API
you use:

- **Ellf** → recipes use `@task_recipe`, `@action_recipe`, or `@agent_recipe` from the Ellf SDK.
   The recipe signature and `field_props` define both:
    - the generated web form in Ellf
    - the generated CLI arguments

    Read `${CLAUDE_SKILL_DIR}/references/ellf_recipe_sdk.md` for the full API.

- **Prodigy standalone** → recipes use `@prodigy.recipe` and return a
  components dict. Read `${CLAUDE_SKILL_DIR}/references/prodigy_recipe_api.md` for the API.

If you don't know the mode yet, infer it from the user's target runtime,
current codebase, and existing recipe package structure.

## Before writing code

1. **Check if a built-in recipe already solves the problem.** Read
   `${CLAUDE_SKILL_DIR}/references/builtin_recipes.md`. If a built-in fits, tell the user — not
   every task needs a custom recipe. If they still want custom, understand what
   the built-in is missing.

2. **Check the shared project plan** using the current local project context.
   Extract task type, labels, data source, runtime target, and any recipe
   recommendations already agreed elsewhere.

3. **Gather requirements** you don't already have: annotation task type, labels,
   data source, model assistance (manual / model-correct / active learning /
   LLM-assisted), and any special needs (custom UI, multi-annotator, etc.).

4. **Pick a template.** Read `${CLAUDE_SKILL_DIR}/references/template_index.md` for the catalog of
   starting-point templates. Each template has annotated stubs that you fill in.
   Templates live in `${CLAUDE_SKILL_DIR}/assets/templates/`.

## Writing the recipe

Use the template as a starting point and the API reference for correctness.
Adapt to the user's requirements.

**For Ellf recipes**, also consult `${CLAUDE_SKILL_DIR}/references/ellf_recipe_sdk.md`
for the decorator format, form props, asset types, local preview flow and publishing workflow.
Ellf supports three recipe types:
- **Task recipes** (`@task_recipe`) — annotation workflows that start Prodigy
- **Action recipes** (`@action_recipe`) — one-shot jobs (training, export, import)
- **Agent recipes** (`@agent_recipe`) — autonomous LLM annotators assigned to tasks

**For standalone recipes**, the Prodigy recipe API reference
(`${CLAUDE_SKILL_DIR}/references/prodigy_recipe_api.md`) covers components dict, view IDs, streams,
callbacks, config, and task formats.

**Consult the built-in Prodigy recipe source** for idiomatic patterns:
```bash
python -c "import prodigy; print(prodigy.__path__[0])"
```
Then inspect the matching built-in recipe under that installed package root
(for example, `<prodigy_package_root>/recipes/ner.py`). Reading the matching
built-in recipe is one of the best things you can do — it shows how streams are
chained, callbacks are structured, and config flows through.

**Use `query_knowledge_base`** for Prodigy/spaCy questions not covered by the
local reference files.

## Validation

  Before presenting a custom recipe as done, validate the surface the user will
  actually rely on.

  ### Standalone Prodigy recipes

  Validate:
  1. **Recipe structure**
     - decorator and arguments are correct
     - stream loading and callbacks are wired correctly
     - returned components dict is valid for the intended workflow

  2. **Runtime behavior**
     - launch the recipe locally with representative test data
     - confirm the UI behaves as expected
     - verify labels, model-assisted behavior, routing, and callbacks

  Use:
  ```bash
  prodigy <recipe> test_dataset ./test_data.jsonl ...
  ```

  ### Ellf recipes

  Validate:

  1. Generated form
      - the recipe signature and field_props produce the right form fields
      - titles, descriptions, defaults, optional sections, and validations make sense
  2. Generated CLI
      - the generated CLI arguments are clear and complete
      - the argument names match the intended workflow
  3. Runtime behavior
      - the recipe runs correctly with representative inputs

  Use:

  ```bash
  ellf-dev preview <recipe-or-module>
  ellf tasks create <recipe> --help
  ellf actions create <recipe> --help
  ellf agents create <recipe> --help
  ellf-dev run <recipe> ...
  ```

  Use the command that matches the recipe type.

  ### Common rule

  If validation fails:

  - read the error carefully
  - fix the recipe
  - re-run the relevant validation path

  Do not present unvalidated recipe code as complete.
  
## Lint before showing

Use the lint script at `${CLAUDE_SKILL_DIR}/references/lint_recipe.py`.

Run it on the recipe file before showing code to the user:
```bash
python <lint_script_path> <recipe_file>
```

If linting finds errors, fix them before presenting the code. Don't show
broken code and ask the user to review it.

## Testing

After the recipe is written and the user approves:

1. Save the recipe file.
2. Generate 3–5 lines of stub JSONL test data.
3. Launch the recipe locally so the user can inspect the annotation UI:
   - Standalone: `prodigy <recipe> test_dataset ./test_data.jsonl ...`
   - Ellf: `ellf-dev run <recipe> --dataset test ...`
4. If the launch fails, read the error and fix it.
5. Ask the user if it looks right. Iterate if needed.

## Porting recipes between modes

When porting **standalone → Ellf**: replace `@prodigy.recipe` with
`@task_recipe`, add `field_props`, replace file paths with `Input`/`Dataset`
types, add asset loading via `.load()`. Compare the standalone and Teams
templates side by side for the structural differences.

When porting **Ellf → standalone**: replace the SDK decorator with
`@prodigy.recipe`, replace asset types with plain arguments, use
`prodigy.get_stream()` for data loading.

## Reference files

| File | What it covers | When to read |
|------|---------------|--------------|
| `${CLAUDE_SKILL_DIR}/references/builtin_recipes.md` | Every built-in Prodigy recipe | Before building custom — check if one already fits |
| `${CLAUDE_SKILL_DIR}/references/prodigy_recipe_api.md` | Components dict, view IDs, streams, callbacks, config, task formats | When writing standalone Prodigy recipes |
| `${CLAUDE_SKILL_DIR}/references/ellf_recipe_sdk.md` | Ellf recipe SDK: decorators, props, asset types, publishing | When writing Ellf recipes |
| `${CLAUDE_SKILL_DIR}/references/template_index.md` | Template catalog — Teams and standalone | When selecting a starting template |
| `${CLAUDE_SKILL_DIR}/assets/templates/template_task_recipe.py` | Teams task recipe template | Annotation tasks on cluster |
| `${CLAUDE_SKILL_DIR}/assets/templates/template_action_recipe.py` | Teams action recipe template | Batch jobs (training, export, etc.) |
| `${CLAUDE_SKILL_DIR}/assets/templates/template_agent_recipe.py` | Teams agent recipe template | Autonomous LLM annotators |
| `${CLAUDE_SKILL_DIR}/assets/templates/template_manual.py` | Standalone manual annotation | Local annotation from scratch |
| `${CLAUDE_SKILL_DIR}/assets/templates/template_correct.py` | Standalone correction workflow | Review/correct predictions locally |
| `${CLAUDE_SKILL_DIR}/assets/templates/template_teach.py` | Standalone active learning | Model-in-the-loop locally |
| `${CLAUDE_SKILL_DIR}/assets/templates/template_blocks_ui.py` | Standalone composite UI | Multiple interfaces locally |
| `${CLAUDE_SKILL_DIR}/assets/templates/template_pages_ui.py` | Standalone multi-page documents | PDF/image sequences locally |
| `${CLAUDE_SKILL_DIR}/assets/templates/template_custom_ui.py` | Standalone custom HTML/JS UI | Advanced UI locally |
| `${CLAUDE_SKILL_DIR}/assets/templates/template_routing.py` | Standalone task routing | Multi-annotator distribution locally |
| `${CLAUDE_SKILL_DIR}/references/lint_recipe.py` | Lint script (ast + pylint) | Before showing code to user |
