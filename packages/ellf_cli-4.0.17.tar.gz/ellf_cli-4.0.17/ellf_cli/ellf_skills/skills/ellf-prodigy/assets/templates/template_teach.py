#
# AGENT INSTRUCTIONS:
#
# Use this template for active learning workflows where a model is "in the loop".
# The model helps select the most uncertain or informative examples to be annotated,
# and it is updated with every new annotation, becoming smarter as you label.
#
# This template is data-agnostic and framework-agnostic.
#
# When to use:
# - User has a working model and wants to improve it with active learning.
# - User uses the term "teach" or "model-in-the-loop".
# - The goal is to efficiently create training data by focusing on the examples
#   the model is most unsure about.
#

from pathlib import Path
from typing import Any, Dict, List, Optional

from prodigy.components.sorters import prefer_uncertain
from prodigy.components.stream import get_stream
from prodigy.core import Arg, recipe
from prodigy.types import ScoredStreamType, SourceType, StreamType
from prodigy.util import log


# --- 1. (Stub) Data Loading Function ---
#
# Prodigy provides a number built-in data loaders. Consult: docs/api-loaders
# You can use the get_stream helper as in the example below or implement a custom
# data loading function (e.g if you need to stream data from a server or cloud storage).
# The loading function should return Prodigy StreamType. Consult
# docs/api-components#stream to learn more.
#
def load_data(source: SourceType, loader: Optional[str]) -> StreamType:
    """Load data from a source."""
    log(f"RECIPE: Loading data from {source} using loader '{loader}'")
    # The get_stream helper handles loading from various formats.
    # Set the `input_key` to match your data, e.g., "text", "image", "audio".
    return get_stream(source, loader=loader, rehash=True, dedup=True, input_key="text")


# --- 2. (Stub) Predictor Loading Function ---
#
# Load your model here. This could be a spaCy model, a PyTorch model,
# a scikit-learn classifier, etc.
def load_model(model_source: Path, labels: List[str]):
    pass


# --- 3. (Stub) Get Predictions with Scores ---
def get_predictions(stream: StreamType, model) -> ScoredStreamType:
    """Get predictions from the model and yield (score, example) tuples."""
    #
    # This function must yield tuples of (score, example). The sorter
    # uses the score to decide which examples to ask next. A score close to
    # 0.5 is considered most uncertain.
    #
    #
    for eg in stream:
        yield (0.5, eg)  # Placeholder for uncertainty


# --- 4. (Stub) Sort the Stream ---
def sort_stream(stream: ScoredStreamType) -> StreamType:
    """Sort the stream of (score, example) tuples to prioritize examples."""
    # Prodigy's sorters help you prioritize examples for annotation.
    # `prefer_uncertain` is the most common for active learning.
    # Other options include `prefer_high_scores` and `prefer_low_scores`.
    # You can also implement your own custom sorting logic here.
    # See docs/api-components#sorters for more details.
    #
    return prefer_uncertain(stream)  # Placeholder


# --- 5. (Stub) Update Callback ---
def update_model(answers: List[Dict[str, Any]], model):
    """Update the model with new annotations. This is obligatory for active learning."""
    log(f"RECIPE: Updating model with {len(answers)} answers")
    #
    # Convert the accepted/rejected answers into training examples and
    # update your model.
    #
    pass


# --- 6. Recipe Definition ---
#
# Consult CLI documentation here: docs/custom-recipes#recipe-args
#
@recipe(
    "template.teach",
    dataset=Arg(help="Dataset to save annotations to"),
    source=Arg(help="Source data to annotate"),
    model_path=Arg("--model-path", "-m", help="Path to a trained model"),
    labels=Arg("--label", "-l", help="Comma-separated labels for the task"),
    loader=Arg("--loader", "-lo", help="Loader for the source data"),
)
def teach_recipe(
    dataset: str,
    source: Path,
    labels: str,
    model_path: Optional[str] = None,
    loader: Optional[str] = None,
):
    """A generic template for active learning workflows."""
    log("RECIPE: Starting 'teach' recipe")

    if not model_path:
        raise ValueError("--model-path is required")

    label_list = [label.strip() for label in labels.split(",") if label.strip()]
    model = load_model(Path(model_path), label_list)
    stream = load_data(source, loader)

    # Get predictions and sort the stream by uncertainty
    predict_stream = get_predictions(stream, model)
    sorted_stream = sort_stream(predict_stream)

    return {
        "dataset": dataset,
        "stream": sorted_stream,
        # Set the view_id based on your task
        "view_id": "classification",
        "update": lambda answers: update_model(answers, model),
        "config": {
            "labels": label_list,
        },
    }
