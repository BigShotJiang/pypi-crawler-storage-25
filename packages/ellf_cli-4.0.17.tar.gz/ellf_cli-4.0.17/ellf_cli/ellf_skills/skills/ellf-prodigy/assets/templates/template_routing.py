#
# AGENT INSTRUCTIONS:
#
# Use this template when the user needs to implement custom logic for
# distributing tasks among multiple annotators.
#
# When to use:
# - User mentions routing tasks to specific people.
# - User wants to assign tasks based on properties of the data (e.g., language).
# - User wants to control the number of annotators per task dynamically.
#

from pathlib import Path
from typing import Dict, List

from prodigy.components.stream import get_stream
from prodigy.core import Arg, Controller, recipe
from prodigy.util import log


# --- 1. (Stub) Custom Task Router Function ---
def my_task_router(controller: Controller, session_id: str, item: Dict) -> List[str]:
    """
    A custom task router that decides which annotator(s) should see each task.
    It must return a list of session IDs.
    See docs here: https://prodi.gy/docs/task-routing
    """
    log(f"RECIPE: Routing task {item['_task_hash']}")

    # Get all currently active annotator sessions
    all_sessions = controller.session_ids
    if not all_sessions:
        return []  # Don't route if no one is connected

    # ----------------- START AGENT IMPLEMENTATION -----------------
    # Implement your routing logic here.
    # Example: Route tasks with a 'priority' key to everyone.
    if item.get("priority") == "high":
        return all_sessions

    # Example: Route based on task hash to one person (deterministic)
    # idx = item["_task_hash"] % len(all_sessions)
    # return [all_sessions[idx]]
    # ------------------ END AGENT IMPLEMENTATION ------------------

    return [session_id]  # Default: send to the person who asked for it


# --- 2. Recipe Definition ---
@recipe(
    "template.custom_router",
    dataset=Arg(help="Dataset to save annotations to"),
    source=Arg(help="Source data to annotate"),
)
def custom_router_recipe(dataset: str, source: Path):
    """A template for recipes with custom task routing logic."""
    log("RECIPE: Starting 'custom_router' recipe")

    stream = get_stream(source, rehash=True, dedup=True)

    return {
        "dataset": dataset,
        "stream": stream,
        "view_id": "text",
        # Assign the custom router function to the 'task_router' component
        "task_router": my_task_router,
        "config": {
            # Overlap must be enabled for custom routing to work
            "feed_overlap": True,
        },
    }
