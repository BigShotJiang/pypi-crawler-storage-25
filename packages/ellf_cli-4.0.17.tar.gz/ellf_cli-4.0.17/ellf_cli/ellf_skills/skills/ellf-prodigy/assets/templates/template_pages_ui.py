#
# AGENT INSTRUCTIONS:
#
# Use this template when the user needs to annotate documents that are split
# into multiple parts or pages. This workflow is ideal for annotating long texts,
# multi-page PDFs, or a sequence of related images as a single task.
#
# When to use:
# - User mentions annotating "PDFs", "long documents", or "multi-page" files.
# - User wants to view multiple pieces of content (e.g., images) together before making a decision.
# - The source data is a directory of files (e.g., images) that should be grouped into single annotation tasks.
#

from pathlib import Path
from typing import Dict, Iterator, Optional

from prodigy.components.stream import get_stream
from prodigy.core import Arg, recipe
from prodigy.util import log


# --- 1. (Stub) Data Loading and Structuring Function ---
def load_and_structure_pages(source: Path, loader: Optional[str]) -> Iterator[Dict]:
    """
    Load data and structure it for the 'pages' interface.
    This function must yield dictionaries with a "pages" key, where "pages"
    is a list of individual sub-tasks.
    """
    log(f"RECIPE: Loading data from {source} to structure for pages view.")

    # Prodigy's "pages" loader can often handle this automatically.
    # It groups files from a directory into single tasks.
    stream = get_stream(source, loader=loader, rehash=True, dedup=True)

    for eg in stream:
        # ----------------- START AGENT IMPLEMENTATION -----------------
        #
        # If you are not using the 'pages' loader, you will need to implement
        # the logic to group your data into the {"pages": [...]} structure here.
        # Each page dict should include a "_view_id" key specifying the interface.
        #
        # For example, grouping text lines from a file:
        #
        # pages = []
        # for line in eg['text'].split('\n'):
        #     pages.append({"text": line, "_view_id": "text"})
        # yield {"pages": pages}
        #
        # For image pages:
        # pages.append({"image": img_data, "_view_id": "image_manual"})
        #
        # ------------------ END AGENT IMPLEMENTATION ------------------
        yield eg


# --- 2. Recipe Definition ---
@recipe(
    "template.pages",
    dataset=Arg(help="Dataset to save annotations to"),
    source=Arg(help="Source data (e.g., directory of images, or a file)"),
    # The 'pages' loader is common for this workflow
    loader=Arg(
        "--loader", "-lo", help="Loader to use (e.g., 'pages' or 'pages:images')"
    ),
    labels=Arg(
        "--label", "-l", help="Comma-separated label(s) for the annotation task"
    ),
)
def pages_recipe(
    dataset: str,
    source: Path,
    loader: Optional[str] = "pages",
    labels: Optional[str] = None,
):
    """A generic template for creating multi-page annotation interfaces."""
    log("RECIPE: Starting 'pages' recipe")

    stream = load_and_structure_pages(source, loader)

    # Optional: If your pages have text that needs tokenization for an interface
    # like 'ner_manual', you would apply it here. `stream.apply` will automatically
    # process each page within the tasks.
    # import spacy
    # from prodigy.components.preprocess import add_tokens
    # nlp = spacy.load("en_core_web_sm") # Add model argument to recipe
    # stream.apply(add_tokens, nlp=nlp)

    return {
        "dataset": dataset,
        "stream": stream,
        # The main view_id must be 'pages'. The view_id for each individual
        # page is defined within the data itself.
        "view_id": "pages",
        "config": {
            "labels": labels.split(",") if labels else [],
            # You can add pages-specific config here.
            # For example, to show image thumbnails for navigation:
            "pages_show_thumbnails": True,
        },
    }
