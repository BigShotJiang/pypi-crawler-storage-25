#
# AGENT INSTRUCTIONS:
#
# Use this template for advanced UI customization using custom HTML, JavaScript,
# and event hooks. This allows for creating fully interactive annotation interfaces.
# If HTML and javascript are very long it's fine to save them in dedicated files.
# Consult: https://prodi.gy/docs/custom-interfaces#js-css
# When to use:
# - User wants to add custom buttons, sliders, or other interactive elements.
# - User needs to trigger backend Python functions from the UI (event hooks).
# - User provides their own HTML or JavaScript snippets.
#

from pathlib import Path

from prodigy.components.stream import get_stream
from prodigy.core import Arg, Controller, recipe
from prodigy.util import log


# --- 1. (Stub) Event Hook Handler ---
def my_event_handler(controller: Controller, *, example: dict, user_input: str) -> dict:
    """A Python function that can be called from the JavaScript frontend."""
    log(f"RECIPE: Event 'my_event' triggered with input: {user_input}")
    # ----------------- START AGENT IMPLEMENTATION -----------------
    # Perform some action on the backend, e.g., call an external API,
    # and optionally update the example in the UI.
    example["meta"] = {"status": f"Processed with '{user_input}'"}
    # ------------------ END AGENT IMPLEMENTATION ------------------
    return example  # Return the updated example to the frontend


# --- 2. Recipe Definition ---
@recipe(
    "template.advanced_ui",
    dataset=Arg(help="Dataset to save annotations to"),
    source=Arg(help="Source data to annotate"),
)
def advanced_ui_recipe(dataset: str, source: Path):
    """A template for advanced, interactive UIs."""
    log("RECIPE: Starting 'advanced_ui' recipe")

    stream = get_stream(source)

    # --- 3. (Stub) Define Custom HTML, CSS, and JavaScript ---
    html_template = """
    <strong>{{text}}</strong>
    <br><br>
    <input type="text" id="user-input" placeholder="Type something..."/>
    <button onclick="triggerEvent()">Trigger Backend Event</button>
    """

    javascript = """
    function triggerEvent() {
        const userInput = document.getElementById('user-input').value;
        // Call the backend event hook named 'my_event'
        window.prodigy.event('my_event', { user_input: userInput, example: window.prodigy.content })
            .then(updated_example => {
                // Update the UI with the returned example
                window.prodigy.update(updated_example);
            })
            .catch(err => console.error('Error in event handler:', err));
    }
    """

    return {
        "dataset": dataset,
        "stream": stream,
        "view_id": "html",
        "event_hooks": {
            "my_event": my_event_handler,  # Register the event hook
        },
        "config": {
            "html_template": html_template,
            "javascript": javascript,
        },
    }
