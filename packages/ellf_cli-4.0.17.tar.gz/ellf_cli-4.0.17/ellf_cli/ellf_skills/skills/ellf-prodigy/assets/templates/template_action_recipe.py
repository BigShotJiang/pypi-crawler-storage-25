#
# AGENT INSTRUCTIONS:
#
# Use this template for Ellf action recipes — one-shot batch jobs
# that run on the cluster and exit. Actions are used for training, data
# processing, evaluation, export, import, deployment, and any other
# non-interactive compute task.
#
# When to use:
# - User wants to run a batch job on the cluster (not annotation).
# - Examples: train a model, export data, run evaluation, process documents,
#   import from external source, trigger deployment.
# - User wants the job to appear in the Actions section of the web UI.
#
# Key differences from task recipes:
# - Decorator: @action_recipe instead of @task_recipe
# - No return value (actions don't start a Prodigy server)
# - Actions run once and exit — they don't serve an annotation UI
# - Can create output assets (models, datasets, files) via Input.create()
#
# Read references/ellf_recipe_sdk.md for the full API.
#


from ellf_recipes_sdk import (
    BoolProps,
    Input,
    InputDataset,
    TextProps,
    action_recipe,
    props,
)


# --- 1. (Stub) Processing Logic ---
#
# The core logic of the action. This is where you do the actual work:
# training, data transformation, evaluation, export, etc.
#
def process_data(examples, output_path):
    """Process the loaded data and produce output."""
    # Example: filter, transform, or analyze the data
    processed = []
    for eg in examples:
        # Add your processing logic here
        processed.append(eg)
    print(f"Processed {len(processed)} examples")
    return processed


# --- 2. Action Recipe Definition ---
#
# The @action_recipe decorator generates web UI forms and CLI arguments.
# The function does NOT return a components dict — it just runs and exits.
#
# Common patterns:
# - Training: load dataset + config, run spacy train, save model as asset
# - Export: load dataset, write to file, create output asset
# - Import: read external source, create dataset or asset
# - Evaluation: load model + test data, compute metrics, print results
#
@action_recipe(
    title="My Batch Action",
    description="Process data and produce output",
    field_props={
        "input_dataset": props.dataset_existing,
        "output_name": TextProps(
            title="Output asset name",
            description="Name for the output asset",
        ),
        "dry_run": BoolProps(
            title="Dry run",
            description="Preview what would happen without writing output",
        ),
    },
)
def my_action(
    *,
    input_dataset: InputDataset,
    output_name: str,
    dry_run: bool = False,
):
    """A template for Ellf action recipes."""
    # Load input data from the cluster dataset
    examples = list(input_dataset.load())
    print(f"Loaded {len(examples)} examples from dataset")

    # Process the data
    result = process_data(examples, output_path=None)

    if dry_run:
        print(f"Dry run: would write {len(result)} examples to '{output_name}'")
        return

    # Create an output asset on the cluster
    # The {assets} variable refers to the cluster's storage bucket
    output_path = f"{{assets}}/{output_name}/data.jsonl"
    # Write output (implement your serialization here)
    # ...

    # Register the output as a new asset
    Input.create(name=output_name, path=output_path, loader="jsonl", version="0.0.1")
    print(f"Created asset '{output_name}' at {output_path}")
