#
# AGENT INSTRUCTIONS:
#
# Use this template for Ellf task recipes — annotation workflows that
# start the Prodigy server on the cluster. This is the Ellf equivalent of
# standalone Prodigy recipes but uses the ellf SDK decorators and data types.
#
# When to use:
# - User is developing for Ellf (cluster-based).
# - User wants to create an annotation task (NER, textcat, spans, etc.).
# - User wants auto-generated forms for the web UI and CLI.
#
# Key differences from standalone Prodigy:
# - Decorator: @task_recipe instead of @prodigy.recipe
# - Arguments: keyword-only with field_props for UI form generation
# - Data loading: Input.load() instead of get_stream()
# - Data types: Dataset, Input, Model, Patterns, Secret, Lang
#
# Read references/ellf_recipe_sdk.md for the full API.
#

from dataclasses import dataclass
from typing import Literal, Optional

from ellf_pam_sdk.models import ValidationLevel, ValidationOp
from ellf_recipes_sdk import (
    Dataset,
    Input,
    IntProps,
    TextProps,
    Validation,
    props,
    task_recipe,
)
from ellf_recipes_sdk import (
    teams_type as ellf_type,
)


# --- 1. (Stub) Stream Preprocessing ---
#
# Apply any transformations to the data stream before annotation.
# For example: add tokenization, filter by length, enrich with metadata.
#
def preprocess_stream(stream, labels):
    """Preprocess the data stream before annotation."""
    for eg in stream:
        # Add preprocessing logic here.
        # For NER: tokenization is handled by the view_id.
        # For textcat: you might add options for classification.
        yield eg


# --- 2. (Stub) Optional Model Predictions ---
#
# If the task uses model-assisted annotation (e.g. ner.correct pattern),
# load the model and add predictions to the stream.
#
def add_predictions(stream, nlp, labels):
    """Add model predictions to the stream for correction."""
    for eg in stream:
        _ = nlp(eg.get("text", ""))
        # Example: add NER spans from model predictions
        # eg["spans"] = [
        #     {"start": ent.start_char, "end": ent.end_char,
        #      "label": ent.label_, "token_start": ent.start, "token_end": ent.end - 1}
        #     for ent in doc.ents if ent.label_ in labels
        # ]
        yield eg


# --- 3. (Example) Custom Type with @ellf_type ---
#
# Group related settings into a reusable dataclass. Custom types get their
# own collapsible section in the web UI form. Use them when a recipe has
# many settings that belong together (e.g. stream filters, model config).
#
@ellf_type(
    title="Stream settings",
    field_props={
        "min_length": IntProps(title="Minimum text length", min=0),
    },
)
@dataclass
class StreamSettings:
    order_by: Literal["asc", "desc"] = "asc"
    min_length: int = 0

    def apply(self, stream):
        for eg in stream:
            if len(eg.get("text", "")) >= self.min_length:
                yield eg


# --- 4. Task Recipe Definition ---
#
# The @task_recipe decorator generates web UI forms and CLI arguments
# from the function signature and field_props. The function must return
# a Prodigy components dict.
#
# See references/ellf_recipe_sdk.md for all available props and data types.
#
# Props quick reference:
#   TextProps   — str fields (title, placeholder, pattern regex)
#   IntProps    — int fields (min, max, step, widget: "number"/"range")
#   FloatProps  — float fields (min, max, step)
#   BoolProps   — bool fields (widget: "checkbox"/"toggle")
#   ListProps   — list[str] fields (comma-separated, min/max items)
#   ChoiceProps — Union/Literal fields (widget: "select"/"radio", choice dict)
#   Props       — base class, works for anything
#
# Validations: Validation(op="ge"|"gt"|"le"|"lt"|"eq"|"ne"|"re", value=...,
#              message="...", level="error"|"warning"|"info"|"success")
#
# Optional[T] fields render with a checkbox toggle in the UI.
# Union[A, B] fields with ChoiceProps render as a radio/select.
#
@task_recipe(
    title="My Annotation Task",
    description="Annotate data with custom labels",
    field_props={
        "dataset": props.dataset_choice,
        "input": TextProps(title="Input data", description="Data source to annotate"),
        "labels": props.label,
        # Optional field — renders with a checkbox toggle in the UI
        "n_examples": IntProps(
            title="Max examples",
            description="Maximum number of examples to annotate (0 = all)",
            min=0,
            validations=[
                Validation(
                    op=ValidationOp.ge,
                    value=0,
                    message="Must be non-negative",
                    level=ValidationLevel.error,
                )
            ],
        ),
        # Union field example — renders as radio buttons in the UI
        # "model": ChoiceProps(
        #     title="Model",
        #     choice={
        #         "model-use": Props(title="Pretrained model"),
        #         "model-blank": Props(title="Blank model"),
        #     },
        # ),
        # Custom type — renders as a collapsible section
        # "stream_settings": Props(title="Stream settings"),
    },
    # Override long CLI arg names for union types:
    # cli_names={
    #     "model-use.name": "model.name",
    #     "model-blank.lang": "model.lang",
    # },
)
def my_task(
    *,
    dataset: Dataset[Literal["text"]],
    input: Input,
    labels: list[str],
    n_examples: Optional[int] = 0,
    # Union type example — uncomment with the ChoiceProps above:
    # model: Union[UseModel, BlankModel],
    # Custom type example — uncomment with the Props above:
    # stream_settings: StreamSettings = StreamSettings(),
):
    """A template for Ellf task recipes."""
    stream = input.load()

    # Apply preprocessing
    stream = preprocess_stream(stream, labels)

    # Optionally limit the number of examples
    if n_examples and n_examples > 0:
        from itertools import islice

        stream = islice(stream, n_examples)

    # Return the Prodigy components dict — same structure as standalone Prodigy.
    return {
        "dataset": dataset.name,
        "stream": stream,
        # Set the view_id to the desired annotation interface:
        # "ner_manual", "ner", "textcat", "spans_manual", "text", "choice", etc.
        "view_id": "ner_manual",
        "config": {
            "labels": labels,
            "exclude_by": "input",
        },
    }
