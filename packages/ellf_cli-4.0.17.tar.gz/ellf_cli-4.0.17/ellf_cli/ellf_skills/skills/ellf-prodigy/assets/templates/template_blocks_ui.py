#
# AGENT INSTRUCTIONS:
#
# Use this template when the user wants to combine multiple annotation
# interfaces into a single view. For example, annotating entities (ner_manual)
# and providing a free-text comment (text_input) for the same example.
# This can be done via blocks: https://prodi.gy/docs/custom-interfaces#blocks
#
# When to use:
# - User mentions combining interfaces like "add a text box to NER" or "show an image with choice options".
# - User uses the term "blocks".


from pathlib import Path
from typing import Dict, Iterator

from prodigy.components.stream import get_stream
from prodigy.core import Arg, recipe
from prodigy.util import log


# --- 1. (Stub) Stream Preparation ---
def prepare_stream(stream: Iterator[Dict]) -> Iterator[Dict]:
    """Prepare the stream for the blocks interface."""
    for eg in stream:
        # Add all the data required by your blocks to the example dictionary.
        # For example, for a 'choice' block, add options:
        # eg["options"] = [{"id": 1, "text": "Option 1"}, {"id": 2, "text": "Option 2"}]
        yield eg


# --- 2. Recipe Definition ---
@recipe(
    "template.blocks",
    dataset=Arg(help="Dataset to save annotations to"),
    source=Arg(help="Source data to annotate"),
)
def blocks_recipe(dataset: str, source: Path):
    """A template for creating custom UIs with the 'blocks' interface."""
    log("RECIPE: Starting 'blocks' recipe")

    stream = get_stream(source, rehash=True, dedup=True)
    stream.apply(prepare_stream, stream)

    # Define the list of blocks. Each block is a dictionary with a "view_id"
    # and optional overrides for that interface.
    # See docs/custom-interfaces#blocks for details.
    blocks = [  # Placeholder
        {"view_id": "ner_manual", "labels": ["PERSON", "ORG"]},
        {"view_id": "text_input", "field_label": "Provide your comments here"},
        {"view_id": "choice", "text": None},  # Set text to None to avoid duplication
    ]

    return {
        "dataset": dataset,
        "stream": stream,
        "view_id": "blocks",
        "config": {
            "blocks": blocks,
            "labels": ["PERSON", "ORG"],  # Labels for the ner_manual block
        },
    }
