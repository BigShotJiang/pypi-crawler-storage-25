#
# AGENT INSTRUCTIONS:
#
# Use this template for Ellf agent recipes — autonomous LLM-powered
# annotators that can be assigned to running annotation tasks. Agents work
# in the background, fetching examples from a task's queue and submitting
# annotations automatically.
#
# When to use:
# - User wants to create an autonomous annotation agent.
# - User wants to scale annotation with LLM-powered auto-labeling.
# - User wants to assign a bot to an existing annotation task.
# - Examples: LLM-based NER annotator, classification agent, span labeler.
#
# How agents work:
# 1. The recipe function sets up resources (LLM client, model, etc.) and
#    returns an Annotator callable.
# 2. The SDK handles everything else: discovering task servers, polling for
#    new tasks, calling the annotator, and submitting answers.
# 3. The Annotator receives (task, config) dicts and returns an annotated task.
# 4. Annotations are saved to the agent's own dataset for review.
# 5. Human annotators can work alongside agents on the same task.
#
# The SDK provides helpers for common annotation patterns:
#   detect_task_type(task) — infer annotation mode from the task
#   format_prompt(task, task_type, config) — build an LLM prompt
#   parse_response(raw, task, task_type) — parse LLM JSON into annotation
#
# Read references/ellf_recipe_sdk.md for the full API.
#

from ellf_recipes_sdk import (
    Annotator,
    FloatProps,
    Secret,
    TextProps,
    agent_recipe,
    detect_task_type,
    format_prompt,
    parse_response,
)


# --- 1. (Stub) LLM Client Setup ---
#
# Set up the LLM client for annotation. This could be any LLM API:
# OpenAI, Anthropic, Google, or a local model.
#
def create_llm_client(api_key: str, model_name: str):
    """Initialize the LLM client."""
    # Example with OpenAI:
    # from openai import AsyncOpenAI
    # return AsyncOpenAI(api_key=api_key)
    #
    # Example with Anthropic:
    # import anthropic
    # return anthropic.AsyncAnthropic(api_key=api_key)
    pass


# --- 2. Agent Recipe Definition ---
#
# The @agent_recipe decorator creates an agent that can be assigned to tasks.
# The function sets up resources and returns an Annotator — a callable that
# takes (task, config) and returns an annotated task dict.
#
# The SDK reads poll_interval and idle_shutdown_seconds from the recipe
# parameters automatically — you don't need to handle them yourself.
#
# Agents are created and managed like tasks and actions:
#   ellf agents create <recipe> --name "My Agent" --api-key MY_SECRET ...
#   ellf agents start "My Agent"
#
# Then assigned to a task in the web UI or via CLI.
#
@agent_recipe(
    title="LLM Annotation Agent",
    description="Autonomous annotation agent powered by an LLM",
    field_props={
        "api_key": TextProps(
            title="API key secret",
            description="Name of the secret containing the LLM API key",
        ),
        "model_name": TextProps(
            title="Model name",
            description="LLM model to use (e.g. gpt-4o, claude-sonnet-4-20250514, gemini-2.0-flash)",
            placeholder="gpt-4o",
        ),
        "poll_interval": FloatProps(
            title="Poll interval (seconds)",
            description="How often to check for new tasks",
            min=0.1,
        ),
        "idle_shutdown_seconds": FloatProps(
            title="Idle shutdown (seconds)",
            description="Shut down after this many seconds without tasks (0 = keep running)",
            min=0.0,
        ),
    },
)
def my_agent(
    *,
    api_key: Secret,
    model_name: str = "gpt-4o",
    poll_interval: float = 1.0,
    idle_shutdown_seconds: float = 0.0,
) -> Annotator:
    """A template for Ellf agent recipes.

    Sets up the LLM client and returns an annotator function. The SDK
    handles server discovery, task polling, and answer submission.
    """
    # Initialize the LLM client
    key = api_key.value()
    _ = create_llm_client(key, model_name)

    # --- 3. Annotator function ---
    #
    # This is the core of the agent — given a task and config from the
    # annotation server, produce an annotated task. The returned dict must
    # include "answer": "accept" | "reject" | "ignore".
    #
    # The SDK helpers handle common patterns automatically:
    #   detect_task_type — figures out NER, textcat, spans, choice, etc.
    #   format_prompt — builds an appropriate LLM prompt
    #   parse_response — parses the LLM's JSON into the annotation format
    #
    # For custom logic (e.g. using spaCy instead of an LLM), you can skip
    # the helpers and build the annotation dict directly.
    #
    async def annotate(task: dict, config: dict) -> dict:
        task_type = detect_task_type(task)
        _ = format_prompt(task, task_type, config)

        # Replace this with your actual LLM call:
        # raw = await client.chat.completions.create(
        #     model=model_name,
        #     messages=[{"role": "user", "content": prompt}],
        # )
        # response_text = raw.choices[0].message.content
        response_text = "{}"  # placeholder

        return parse_response(response_text, task, task_type, model_name=model_name)

    return annotate
