#
# AGENT INSTRUCTIONS:
#
# Use this template when the user wants to review and correct predictions made by
# any kind of automated system. This is the primary "correction" workflow for
# creating high-quality, gold-standard data by having a human-in-the-loop.
#
#
# This template is data-agnostic and framework-agnostic. It can be adapted for
# text, images, or audio, using any Python-based ML framework or an LLM.
#
# Key triggers for using this template:
# - "correct model predictions" or "review annotations from my model"
# - "use a patterns file to pre-annotate" (for text)
# - "correct LLM annotations" or "review suggestions from GPT"
# - The user provides a model path, a patterns file, or an LLM config.
#

# Prodigy Recipe Template: Generic Correction Workflow

import copy
from pathlib import Path
from typing import Dict, List, Optional

from prodigy.components.stream import get_stream
from prodigy.core import Arg, recipe
from prodigy.types import SourceType, StreamType
from prodigy.util import log, msg


# --- 1. (Stub) Data Loading Function ---
#
# Prodigy provides a number of built-in data loaders. Consult: docs/api-loaders
# You can use the get_stream helper as in the example below or implement a custom
# data loading function (e.g if you need to stream data from a server or cloud storage).
# The loading function should return Prodigy StreamType. Consult
# docs/api-components#stream to learn more.
#
def load_data(source: SourceType, loader: Optional[str]) -> StreamType:
    """Load data from a source."""
    log(f"RECIPE: Loading data from {source} using loader '{loader}'")
    # The get_stream helper handles loading from various formats.
    # Set the `input_key` to match your data, e.g., "text", "image", "audio".
    return get_stream(source, loader=loader, rehash=True, dedup=True, input_key="text")


# --- 2. (Stub) Predictor Loading Function ---
#
# Load your predictor. This could be a spaCy model, a PyTorch model,
# a Prodigy PatternMatcher, or an LLM pipeline from a config.
# You can also load more than one predictor (adjust the CLI for this) and
# add logic to combine the predictions from different sources.
def load_predictor(model_source: Path):
    pass


# --- 3. (Stub) Add Predicted Labels To the Stream ---
def add_suggestions_to_stream(stream: StreamType, predictor) -> StreamType:
    """
    Add suggestions from the predictor to a stream of examples.
    """
    for eg in stream:
        task = copy.deepcopy(eg)
        # Get predictions from your predictor.
        # predictions = predictor(eg)
        #
        # Add predictions to the task dictionary in the format expected
        # by your chosen view_id (e.g., 'ner_manual', 'image_manual' or custom).
        #
        # Consult docs/api-interfaces for the expected data format.
        # For LLMs, you might also want to add the `llm_io` block to the UI.

        yield task


# --- 4. (Stub) Optional Callbacks ---
#
# Callbacks are functions that Prodigy calls at specific points in the
# annotation lifecycle. They allow you to add custom logic and behavior.
# For details on built-in callback see: docs/custom-recipes#callbacks
#
def update_model(answers: List[Dict]) -> None:
    """
    Update the model with the corrected annotations. This is not
    typically used for LLMs or pattern-based workflows.
    """
    log(f"RECIPE: Updating model with {len(answers)} answers")
    #
    # Convert the corrected annotations into a format suitable for training
    # your model (e.g., spaCy `Example` objects) and call the update logic.
    #
    pass


# --- 5. Recipe Definition ---
#
# Consult CLI documentation here: docs/custom-recipes#recipe-args
#
@recipe(
    "template.correct",
    # fmt: off
    dataset=Arg(help="Dataset to save annotations to"),
    source=Arg(
        help="Source data to annotate (file path or '-' to read from standard input)"
    ),
    model_source=Arg(
        "--model-source",
        "-m",
        help="Path to a model, patterns file, or LLM config to generate suggestions",
    ),
    loader=Arg("--loader", "-lo", help="Loader to use for the source data"),
    labels=Arg(
        "--label",
        "-l",
        help="Comma-separated label(s) to annotate or text file with one label per line",
    ),
    update=Arg("--update", "-UP", help="Whether to update the model during annotation"),
    exclude=Arg(
        "--exclude",
        "-e",
        help="Comma-separated list of dataset IDs whose annotations to exclude",
    ),
    # fmt: on
)
def correct(
    dataset: str,
    source: Path,
    model_source: Optional[str] = None,
    loader: Optional[str] = None,
    labels: Optional[str] = None,
    update: bool = False,
    exclude: Optional[List[str]] = None,
):
    """
    Generic 'correct' recipe. This template uses a trained model, patterns, or an LLM
    to pre-annotate data, which an annotator can then correct in the UI.
    """
    log("RECIPE: Starting recipe 'template.correct'")

    if not model_source:
        msg.fail("The --model-source argument is required for this recipe.", exits=1)

    predictor = load_predictor(
        Path(model_source)
    )  # Replace this with your predictor loading logic

    stream = get_stream(source, loader=loader, rehash=True, dedup=True)

    # Apply the pre-processor to the stream.
    stream = add_suggestions_to_stream(stream, predictor)

    # --- 5. Set up the Recipe Components ---
    # For more details on recipe components consult docs/custom-recipes#components
    return {
        "dataset": dataset,
        "stream": stream,
        # Set the view_id to a required interface
        "view_id": "ner_manual",
        "exclude": exclude,
        "update": update_model if update else None,
        "config": {
            "labels": labels,
            "exclude_by": "input",
            # For LLMs, add the blocks config here:
            # "blocks": [
            #     {"view_id": "ner_manual"},
            #     {"view_id": "llm_io"}
            # ]
        },
    }
