#
# AGENT INSTRUCTIONS:
#
# Use this template for tasks that require creating annotations from scratch.
# This is a "manual" workflow where the user annotates data without any
# initial predictions from a model or rules.
#
# When to use:
# - User specifies "manual annotation".
# - No model or patterns are provided as input.
#

from typing import Any, Dict, List, Optional

from prodigy.components.stream import get_stream
from prodigy.core import Arg, recipe
from prodigy.types import SourceType, StreamType
from prodigy.util import log


# --- 1. (Stub) Data Loading Function ---
#
# Prodigy provides a number built-in data loaders. Consult: docs/api-loaders
# You can use the get_stream helper as in the example below or implement a custom
# data loading function (e.g if you need to stream data from a server or cloud storage).
# The loading function should return Prodigy StreamType. Consult
# docs/api-components#stream to learn more.
#
def load_data(source: SourceType, loader: Optional[str]) -> StreamType:
    """Load data from a source."""
    log(f"RECIPE: Loading data from {source} using loader '{loader}'")
    # The get_stream helper handles loading from various formats.
    # Set the `input_key` to match your data, e.g., "text", "image", "audio".
    return get_stream(source, loader=loader, rehash=True, dedup=True, input_key="text")


# --- 2. (Stub) Optional Stream Modifier ---
#
# The job of these functions is to apply required preprocessing to the input data.
# For example, add tokenization or translations from an API call.
# See here for built-in preprocessors: docs/api-components#preprocess
def modify_stream(stream: StreamType) -> StreamType:
    """Modify the stream of examples before they are annotated."""
    for eg in stream:
        # This is where you can add pre-processing logic.
        # For example, for a 'choice' interface, you would add options:
        # eg["options"] = [{"id": "SPAM", "text": "SPAM"}, {"id": "NOT_SPAM", "text": "NOT_SPAM"}]
        #
        yield eg


# --- 3. (Stub) Optional Callbacks ---
#
# Callbacks are functions that Prodigy calls at specific points in the
# annotation lifecycle. They allow you to add custom logic and behavior.
# For details on built-in callback see: docs/custom-recipes#callbacks
#
def before_db(examples: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """Modify examples before they are saved to the database."""
    log(f"RECIPE: Calling 'before_db' on {len(examples)} examples.")
    return examples


# --- 4. Recipe Definition ---
#
# Consult CLI documentation here: docs/custom-recipes#recipe-args
#
@recipe(
    "template.manual",
    dataset=Arg(help="Dataset to save annotations to"),
    source=Arg(help="Source data to annotate"),
    loader=Arg("--loader", "-lo", help="Loader for the source data"),
)
def manual_recipe(dataset: str, source: SourceType, loader: Optional[str] = None):
    """A generic template for manual annotation workflows."""
    log("RECIPE: Starting 'manual' recipe")

    stream = load_data(source, loader)
    # Apply any stream modifications before returning the recipe config.
    stream = modify_stream(stream)

    # For more details on recipe components consult docs/custom-recipes#components
    return {
        "dataset": dataset,
        "stream": stream,
        # Set the view_id to the desired annotation interface.
        "view_id": "text",
        "before_db": before_db,
        "config": {
            "labels": ["LABEL_A", "LABEL_B"],
            "exclude_by": "input",
        },
    }
