# Prodigy Recipe Authoring — Programmatic API Reference

This document describes how to write Prodigy annotation recipe scripts using
the library's Python API. A recipe is a Python function that configures an
annotation workflow — it loads data, optionally applies model predictions or
transformations, selects a UI, and returns a components dict that the Prodigy
server uses to run the annotation session.

---

## Table of Contents

Line ranges are approximate — use them for targeted `Read` calls with `offset`/`limit`.

| Section | Lines | Key Topics |
|---------|-------|------------|
| **Basics** | | |
| Anatomy of a Recipe Script | ~30–80 | Script structure, `prodigy.serve()`, `@recipe` decorator |
| The Components Dict | ~82–113 | Required/optional keys, callbacks, config, routing |
| Loading Data — `get_stream` | ~115–150 | `get_stream()` args, built-in loaders, from-iterable |
| Stream Transformations — `stream.apply()` | ~152–217 | `stream.apply()`, `add_tokens`, `split_sentences`, `make_ner_suggestions`, `add_label_options` |
| Hashing — `set_hashes` | ~219–242 | `set_hashes`, input/task hash keys |
| **UI** | | |
| View IDs and Task Formats | ~244–536 | All view IDs: `text`, `html`, `classification`, `choice`, `ner`, `ner_manual`, `spans_manual`, `pos_manual`, `relations`, `image_manual`, `audio_manual`, `text_input`, `blocks`, `review`, `diff`, `pages` |
| **Configuration & Behavior** | | |
| Config Reference | ~538–620 | Labels, buttons, exclusion, stream, multi-annotator, theme, blocks, choice, HTML/JS/CSS, NER, relations, image, audio, pages, shortcuts |
| Callbacks | ~623–696 | `update`, `validate_answer`, `before_db`, `on_exit`, `on_load`, `event_hooks`, `progress` |
| Database Access | ~698–711 | `connect()`, `get_dataset_examples`, `add_examples` |
| **Examples & Reference** | | |
| Complete Examples | ~713–980 | Manual NER, textcat, NER correct, blocks, image, audio, API stream, relations, validation, exclusion |
| View ID Quick Reference | ~982–1005 | Summary table |
| Token Format | ~1007–1023 | Token dict keys |
| Span Format | ~1025–1037 | Span dict keys |

---

## Anatomy of a Recipe Script

A recipe script is a standalone `.py` file. It does **not** need the `@recipe`
decorator (that is only for registering CLI commands). Instead, it builds a
`ControllerComponentsDict` and calls `prodigy.serve()` to start the server.

```python
import prodigy
from prodigy.components.stream import get_stream
from prodigy.util import set_hashes

def make_stream():
    for text in ["Example one.", "Example two."]:
        yield set_hashes({"text": text})

stream = get_stream(make_stream())

components = {
    "view_id": "text",
    "dataset": "my_dataset",
    "stream": stream,
    "config": {"auto_count_stream": True},
}

# Start the annotation server
prodigy.serve("_", components=components)
```

Alternatively, using the `@recipe` decorator to register as a CLI command:

```python
from prodigy.core import recipe, Arg
from prodigy.protocols import ControllerComponentsDict
from prodigy.components.stream import get_stream

@recipe(
    "my-recipe",
    dataset=Arg(help="Dataset to save annotations to"),
    source=Arg(help="Data source"),
)
def my_recipe(dataset: str, source: str) -> ControllerComponentsDict:
    stream = get_stream(source, loader="jsonl", rehash=True, dedup=True)
    return {
        "view_id": "text",
        "dataset": dataset,
        "stream": stream,
    }
```

---

## The Components Dict

Every recipe returns a `ControllerComponentsDict`. Required and optional keys:

```python
{
    # ── Required ───────────────────────────────────────────────
    "view_id": str,                    # UI interface (see View IDs below)
    "dataset": str,                    # Dataset name to save annotations to
    "stream": Stream | Iterator[dict], # Iterable of task dicts

    # ── Optional callbacks ─────────────────────────────────────
    "update":          Callable[[List[dict]], None],        # Called after batch submitted
    "before_db":       Callable[[List[dict]], List[dict]],  # Transform before DB save
    "validate_answer": Callable[[dict], None],              # Validate per-task (raise ValueError to reject)
    "on_load":         Callable[[Controller], None],        # Called when server starts
    "on_exit":         Callable[[Controller], None],        # Called when server stops
    "progress":        Callable,                            # Custom progress tracking
    "event_hooks":     Dict[str, Callable],                 # UI event handlers

    # ── Optional settings ──────────────────────────────────────
    "config":          dict,           # UI/behavior configuration
    "exclude":         List[str],      # Dataset IDs to exclude from stream
    "db":              Database|False,  # Custom DB or False to disable persistence

    # ── Optional routing (multi-annotator) ─────────────────────
    "task_router":     Callable,       # Controls which annotators see which tasks
    "session_factory": Callable,       # Custom session creation
}
```

---

## Loading Data — `get_stream`

```python
from prodigy.components.stream import get_stream
```

```python
get_stream(
    source,                          # File path, iterable, "dataset:name", or "-" for stdin
    *,
    loader: str | None = None,       # "jsonl", "json", "csv", "txt", "images", "audio", etc.
    rehash: bool = False,            # Recompute hashes for all examples
    dedup: bool = False,             # Deduplicate by input hash
    input_key: str = UNSET,          # Key used for input hashing (e.g. "text", "image")
    skip_invalid: bool = True,       # Skip examples that fail validation
    is_binary: bool | None = None,   # Mark tasks as binary (accept/reject)
) -> Stream
```

**Built-in loaders:** `jsonl`, `json`, `csv`, `txt`, `images`, `audio`,
`video`, `image-server`, `audio-server`, `video-server`, `pages`.

The loader is guessed from the file extension when not specified.

**From an iterable:**
```python
data = [{"text": "Hello world"}, {"text": "Another example"}]
stream = get_stream(data, rehash=True)
```

**From a file:**
```python
stream = get_stream("./data.jsonl", loader="jsonl", rehash=True, dedup=True)
```

---

## Stream Transformations — `stream.apply()`

After loading, chain transformations with `stream.apply()`:

```python
stream.apply(my_transform_function, arg1=value1, arg2=value2)
```

The function receives the stream as its first positional argument (or via
a `stream=stream` keyword) and must be a generator yielding task dicts.

```python
def add_uppercase(stream):
    for eg in stream:
        eg["meta"] = {"upper": eg["text"].upper()}
        yield eg

stream.apply(add_uppercase)
```

### Built-in Preprocessing Functions

```python
from prodigy.components.preprocess import (
    add_tokens,            # Tokenize text with spaCy
    split_sentences,       # Split text into sentences
    fetch_media,           # Convert file paths/URLs to base64 data URIs
    add_label_options,     # Add choice options from a label list
    add_labels_to_stream,  # Duplicate each task per label
    add_view_id,           # Set _view_id on tasks
    add_answer,            # Set answer field
    make_ner_suggestions,  # Add NER predictions from a spaCy model
    make_spancat_suggestions,  # Add spancat predictions
    make_textcat_suggestions,  # Add textcat predictions
)
```

**Tokenization** (required for `ner_manual`, `spans_manual`, `pos_manual`,
`relations`, `dep`):
```python
import spacy
nlp = spacy.load("en_core_web_sm")
stream.apply(add_tokens, nlp=nlp, stream=stream)
```

**Sentence splitting:**
```python
stream.apply(split_sentences, nlp=nlp, stream=stream)
```

**Model suggestions for NER:**
```python
stream.apply(
    make_ner_suggestions,
    nlp=nlp,
    component="ner",
    labels=["PERSON", "ORG"],
)
```

**Adding choice options:**
```python
stream.apply(add_label_options, stream=stream, labels=["POS", "NEG", "NEUTRAL"])
```

---

## Hashing — `set_hashes`

Every task needs `_input_hash` and `_task_hash`. Use `set_hashes` when
creating tasks manually:

```python
from prodigy.util import set_hashes

task = set_hashes({"text": "Hello world"})
# task now has _input_hash and _task_hash set

# Overwrite existing hashes (e.g. after modifying annotations):
task = set_hashes(task, overwrite=True)
```

**Hash keys:**
- Input hash computed from: `text`, `image`, `html`, `input`
- Task hash computed from: `spans`, `label`, `options`, `arcs` (plus input hash)
- Ignored in hashing: `score`, `rank`, `model`, `source`, `pattern`,
  `priority`, `path`, `_view_id`, `_session_id`, `_annotator_id`, `answer`

If you use `get_stream(..., rehash=True)`, hashes are set automatically.

---

## View IDs and Task Formats

### `"text"` — Plain text display

```python
{"text": "Some text to display."}
```

### `"html"` — Custom HTML

```python
{"html": "<h2>Title</h2><p>Content here</p>"}
```

Can also use `html_template` in config for Mustache-style templates:
```python
config = {"html_template": "<h2>{{title}}</h2><p>{{text}}</p>"}
# Then tasks just provide the variables:
{"text": "Content", "title": "My Title"}
```

### `"classification"` — Binary text classification

Single label, accept/reject decision.

```python
{"text": "I love this product!", "label": "POSITIVE"}
```

### `"choice"` — Multiple choice

```python
{
    "text": "I love this product!",
    "options": [
        {"id": "POS", "text": "Positive"},
        {"id": "NEG", "text": "Negative"},
        {"id": "NEU", "text": "Neutral"},
    ],
    "accept": [],  # pre-selected options (optional)
}
```

Config options:
```python
config = {
    "choice_style": "single",       # or "multiple"
    "choice_auto_accept": True,      # auto-submit on selection
}
```

### `"ner"` — Binary NER (accept/reject predicted spans)

```python
{
    "text": "Apple is based in Cupertino.",
    "spans": [
        {"start": 0, "end": 5, "label": "ORG", "text": "Apple"},
    ],
}
```

### `"ner_manual"` — Manual NER span annotation

Requires tokenized text. The annotator highlights spans in the UI.

```python
{
    "text": "Apple is based in Cupertino.",
    "tokens": [
        {"text": "Apple", "start": 0, "end": 5, "id": 0, "ws": True},
        {"text": "is", "start": 6, "end": 8, "id": 1, "ws": True},
        {"text": "based", "start": 9, "end": 14, "id": 2, "ws": True},
        {"text": "in", "start": 15, "end": 17, "id": 3, "ws": True},
        {"text": "Cupertino", "start": 18, "end": 27, "id": 4, "ws": False},
        {"text": ".", "start": 27, "end": 28, "id": 5, "ws": False},
    ],
    "spans": [  # optional pre-annotations
        {
            "start": 0, "end": 5,
            "token_start": 0, "token_end": 0,
            "label": "ORG", "text": "Apple",
        },
    ],
}
```

Config:
```python
config = {
    "labels": ["PERSON", "ORG", "GPE"],
    "exclude_by": "input",
    "ner_manual_highlight_chars": False,  # char-level vs token-level
}
```

### `"spans_manual"` — Manual span annotation (overlapping spans allowed)

Same format as `ner_manual` but allows overlapping spans.

```python
config = {
    "labels": ["SKILL", "TOOL", "LANGUAGE"],
    "exclude_by": "input",
}
```

### `"pos_manual"` — POS tag correction

Each token gets a label. Spans represent per-token POS assignments.

```python
{
    "text": "Apple is great.",
    "tokens": [...],
    "spans": [
        {"token_start": 0, "token_end": 0, "start": 0, "end": 5,
         "text": "Apple", "label": "PROPN"},
        {"token_start": 1, "token_end": 1, "start": 6, "end": 8,
         "text": "is", "label": "AUX"},
        ...
    ],
}
```

Config: `{"labels": ["NOUN", "VERB", "ADJ", ...], "exclude_by": "input"}`

### `"relations"` — Relation/dependency annotation

```python
{
    "text": "The dog runs.",
    "tokens": [
        {"text": "The", "start": 0, "end": 3, "id": 0, "ws": True},
        {"text": "dog", "start": 4, "end": 7, "id": 1, "ws": True},
        {"text": "runs", "start": 8, "end": 12, "id": 2, "ws": False},
        {"text": ".", "start": 12, "end": 13, "id": 3, "ws": False},
    ],
    "relations": [
        {"child": 0, "head": 1, "label": "det"},
        {"child": 1, "head": 2, "label": "nsubj"},
    ],
    "spans": [  # optional: pre-defined entity spans for relation annotation
        {"start": 0, "end": 7, "token_start": 0, "token_end": 1, "label": "SUBJ"},
    ],
}
```

Config:
```python
config = {
    "labels": ["nsubj", "det", "ROOT"],
    "relations_span_labels": ["SUBJ", "OBJ"],  # labels for span endpoints
    "wrap_relations": True,
    "custom_theme": {"cardMaxWidth": "90%", "relationHeight": 150},
}
```

### `"image_manual"` — Image bounding box / polygon annotation

```python
{
    "image": "data:image/png;base64,...",  # or URL via image-server loader
    "width": 800,   # optional
    "height": 600,  # optional
    "spans": [],     # pre-annotations (optional)
}
```

Config:
```python
config = {
    "labels": ["CAT", "DOG"],
    "darken_image": 0.3,
    "image_manual_modes": ["rect", "polygon", "freehand"],
    "custom_theme": {"cardMaxWidth": 800},
    "exclude_by": "input",
}
```

### `"audio_manual"` — Audio/video region annotation

```python
{
    "audio": "data:audio/wav;base64,...",  # or path via audio-server
    "spans": [],  # pre-annotated audio regions (optional)
}
```

Config:
```python
config = {
    "labels": ["SPEECH", "MUSIC", "NOISE"],
    "audio_autoplay": False,
}
```

### `"text_input"` — Free-text input field

```python
{
    "text": "Source text to annotate...",
    "field_id": "answer",           # key to store the input under
    "field_label": "Your answer",   # label shown above the field
    "field_rows": 3,                # height in rows
    "field_placeholder": "Type here...",
    "field_autofocus": True,
}
```

### `"blocks"` — Composite interface

Combines multiple view IDs into a single card. The task dict provides
data for all blocks; each block renders its respective view.

```python
# view_id is "blocks"
{
    "text": "Some text to annotate",
    "tokens": [...],  # if an NER block needs it
    "field_id": "comment",
    "field_label": "Notes",
    "field_rows": 2,
}
```

Config:
```python
config = {
    "blocks": [
        {"view_id": "ner_manual"},
        {"view_id": "text_input"},
    ],
    "labels": ["PERSON", "ORG"],
}
```

Common block patterns:
```python
# NER + text input
{"blocks": [{"view_id": "ner_manual"}, {"view_id": "text_input"}]}

# NER + LLM I/O display
{"blocks": [{"view_id": "ner_manual"}, {"view_id": "llm_io"}]}

# Classification + HTML display
{"blocks": [{"view_id": "choice"}, {"view_id": "html", "html_template": "..."}]}

# Audio + transcription
{"blocks": [{"view_id": "audio"}, {"view_id": "text_input"}]}

# Text + custom HTML
{"blocks": [{"view_id": "text"}, {"view_id": "html", "html_template": "<b>Score:</b> {{score}}"}]}
```

### `"review"` — Multi-annotator conflict resolution

```python
{
    "text": "...",
    "versions": [
        {"spans": [...], "answer": "accept", "sessions": ["ann1"], "default": True},
        {"spans": [...], "answer": "accept", "sessions": ["ann2"]},
    ],
    "view_id": "ner_manual",  # which interface to review with
}
```

### `"diff"` — Side-by-side text diff

```python
{
    "accept": {"text": "Version A text"},
    "reject": {"text": "Version B text"},
}
```

Config: `{"diff_style": "words"}` — can be `"words"`, `"chars"`, or
`"sentences"`.

### `"pages"` — Multi-page documents

```python
{
    "pages": [
        {"image": "data:image/png;base64,...", "_view_id": "image_manual"},
        {"image": "data:image/png;base64,...", "_view_id": "image_manual"},
    ],
    "page_titles": ["Page 1", "Page 2"],
}
```

---

## Config Reference

The `config` dict in the components dict overrides settings from
`prodigy.json`. Key options:

```python
config = {
    # ── Labels ────────────────────────────────────────────────
    "labels": ["LABEL1", "LABEL2"],    # Available labels
    "label": "SINGLE_LABEL",           # For single-label classification

    # ── UI buttons and behavior ───────────────────────────────
    "buttons": ["accept", "reject", "ignore", "undo"],  # Which buttons to show
    "instant_submit": False,           # Auto-submit after one action
    "show_flag": False,                # Show flag button

    # ── Exclusion/dedup ───────────────────────────────────────
    "exclude_by": "task",              # "task" or "input"
    "auto_exclude_current": True,      # Exclude current examples

    # ── Stream ────────────────────────────────────────────────
    "auto_count_stream": False,        # Count total examples upfront
    "batch_size": 10,                  # Examples per annotation batch
    "total_examples_target": None,     # Target total for progress bar

    # ── Multi-annotator ───────────────────────────────────────
    "feed_overlap": True,              # Allow overlapping annotation
    "annotations_per_task": None,      # Target annotations per task (float)

    # ── Theme / layout ────────────────────────────────────────
    "custom_theme": {},                # e.g. {"cardMaxWidth": "90%"}
    "writing_dir": "ltr",             # "ltr" or "rtl"
    "hide_meta": False,               # Hide metadata
    "show_stats": False,              # Show annotation stats

    # ── Blocks ────────────────────────────────────────────────
    "blocks": [],                      # List of {"view_id": "..."} for composite UI

    # ── Choice ────────────────────────────────────────────────
    "choice_style": "single",         # "single" or "multiple"
    "choice_auto_accept": False,      # Auto-accept on selection

    # ── Custom HTML/JS/CSS ────────────────────────────────────
    "html_template": None,            # Mustache template for html view
    "javascript": None,               # Custom JavaScript
    "global_css": None,               # Custom global CSS
    "instructions": None,             # Path to HTML instructions or string

    # ── NER-specific ──────────────────────────────────────────
    "ner_manual_highlight_chars": False,  # Character-level highlighting
    "ner_manual_label_style": "list",     # "list" or "dropdown"

    # ── Relations-specific ────────────────────────────────────
    "wrap_relations": False,
    "relations_span_labels": [],
    "show_relations_labels": True,
    "hide_relations_arrow": False,

    # ── Image-specific ────────────────────────────────────────
    "darken_image": 0,                # Darken image (0-1)
    "image_manual_modes": ["rect", "polygon", "freehand"],

    # ── Audio-specific ────────────────────────────────────────
    "audio_autoplay": False,
    "audio_loop": False,
    "audio_rate": 1.0,

    # ── Pages-specific ────────────────────────────────────────
    "pages_show_thumbnails": True,

    # ── Keyboard shortcuts ────────────────────────────────────
    "keymap": {},                     # e.g. {"playpause": ["ctrl+enter"]}
    "keymap_by_label": {},            # e.g. {"PERSON": "1", "ORG": "2"}

    # ── Server ────────────────────────────────────────────────
    "port": 8080,
    "host": "localhost",

    # ── Text editing ──────────────────────────────────────────
    "edit_text": False,               # Allow text editing in manual NER/spans
}
```

---

## Callbacks

### `update` — Post-submission model update

Called after each batch of annotations is submitted.

```python
def update(answers: List[dict]) -> None:
    for eg in answers:
        if eg["answer"] == "accept":
            # Process accepted annotation
            pass
```

The `answer` field is `"accept"`, `"reject"`, or `"ignore"`.

### `validate_answer` — Per-task validation

Raise `ValueError` to prevent the task from being submitted. The error
message is shown to the annotator.

```python
def validate_answer(answer: dict) -> None:
    if not answer.get("spans"):
        raise ValueError("Please highlight at least one span.")
```

### `before_db` — Transform before database storage

Modify tasks before they are saved. Must return the list.

```python
def before_db(examples: List[dict]) -> List[dict]:
    for eg in examples:
        # Remove base64 data, keep only file path
        if eg.get("image", "").startswith("data:") and "path" in eg:
            eg["image"] = eg["path"]
    return examples
```

### `on_exit` — Cleanup / summary on shutdown

```python
def on_exit(ctrl) -> None:
    examples = ctrl.db.get_dataset_examples(ctrl.session_id)
    accepted = [eg for eg in examples if eg["answer"] == "accept"]
    print(f"Annotated {len(accepted)} examples")
```

### `on_load` — Initialization when server starts

```python
def on_load(ctrl) -> None:
    print(f"Starting annotation for dataset: {ctrl.dataset}")
```

### `event_hooks` — UI event handlers

Handle events fired from the frontend.

```python
event_hooks = {
    "edit_text": my_edit_text_handler,  # When text is edited in-place
}
```

### `progress` — Custom progress tracking

```python
def progress(ctrl, session, answers, update_return_value):
    return ctrl.total_annotated / 1000  # Return float 0-1
```

---

## Database Access

```python
from prodigy.components.db import connect

db = connect()                              # Connect using prodigy.json settings
datasets = db.datasets                      # List dataset names
examples = db.get_dataset_examples("name")  # Get all examples in a dataset
db.add_examples(examples, ["dataset_name"]) # Add examples to dataset(s)
hashes = db.get_input_hashes("dataset1")    # Get input hashes for exclusion
count = db.count_dataset("name")            # Count examples
```

---

## Complete Examples

### Manual NER annotation

```python
import spacy
from prodigy.components.stream import get_stream
from prodigy.components.preprocess import add_tokens

nlp = spacy.load("en_core_web_sm")

stream = get_stream(
    "./data.jsonl",
    loader="jsonl",
    rehash=True,
    dedup=True,
    input_key="text",
)
stream.apply(add_tokens, nlp=nlp, stream=stream)

components = {
    "view_id": "ner_manual",
    "dataset": "ner_annotations",
    "stream": stream,
    "config": {
        "labels": ["PERSON", "ORG", "PRODUCT"],
        "exclude_by": "input",
    },
}
```

### Text classification with multiple labels (choice)

```python
from prodigy.components.stream import get_stream
from prodigy.components.preprocess import add_label_options

labels = ["POSITIVE", "NEGATIVE", "NEUTRAL"]
stream = get_stream("./reviews.jsonl", rehash=True, dedup=True)
stream.apply(add_label_options, stream=stream, labels=labels)

components = {
    "view_id": "choice",
    "dataset": "sentiment",
    "stream": stream,
    "config": {
        "choice_style": "single",
        "choice_auto_accept": True,
        "exclude_by": "input",
    },
}
```

### NER with model suggestions (correct workflow)

```python
import spacy
from prodigy.components.stream import get_stream
from prodigy.components.preprocess import add_tokens, make_ner_suggestions

nlp = spacy.load("en_core_web_lg")
labels = ["PERSON", "ORG", "GPE"]

stream = get_stream("./articles.jsonl", rehash=True, dedup=True, input_key="text")
stream.apply(add_tokens, nlp=nlp, stream=stream)
stream.apply(
    make_ner_suggestions,
    nlp=nlp,
    component="ner",
    labels=labels,
)

components = {
    "view_id": "ner_manual",
    "dataset": "ner_corrected",
    "stream": stream,
    "config": {
        "labels": labels,
        "exclude_by": "input",
    },
}
```

### Composite blocks: NER + free-text comments

```python
import spacy
from prodigy.components.stream import get_stream
from prodigy.components.preprocess import add_tokens

nlp = spacy.load("en_core_web_sm")

stream = get_stream("./data.jsonl", rehash=True, dedup=True, input_key="text")
stream.apply(add_tokens, nlp=nlp, stream=stream)

def add_comment_field(stream):
    for eg in stream:
        eg["field_id"] = "comment"
        eg["field_label"] = "Notes"
        eg["field_rows"] = 2
        yield eg

stream.apply(add_comment_field)

components = {
    "view_id": "blocks",
    "dataset": "ner_with_comments",
    "stream": stream,
    "config": {
        "blocks": [
            {"view_id": "ner_manual"},
            {"view_id": "text_input"},
        ],
        "labels": ["PERSON", "ORG"],
    },
}
```

### Image bounding box annotation

```python
from prodigy.components.stream import get_stream
from prodigy.components.preprocess import fetch_media

stream = get_stream("./images/", loader="images", rehash=True, dedup=True)

def before_db(examples):
    for eg in examples:
        if eg["image"].startswith("data:") and "path" in eg:
            eg["image"] = eg["path"]
    return examples

components = {
    "view_id": "image_manual",
    "dataset": "image_annotations",
    "stream": stream,
    "before_db": before_db,
    "config": {
        "labels": ["CAR", "PERSON", "SIGN"],
        "darken_image": 0.3,
        "custom_theme": {"cardMaxWidth": 800},
        "exclude_by": "input",
    },
}
```

### Audio transcription (blocks)

```python
from prodigy.components.stream import get_stream
from prodigy.components.preprocess import fetch_media

stream = get_stream("./audio/", loader="audio", rehash=True, dedup=True)

def add_transcript_fields(stream):
    for eg in stream:
        eg["field_id"] = "transcript"
        eg["field_label"] = "Transcript"
        eg["field_rows"] = 4
        eg["field_autofocus"] = True
        yield eg

stream.apply(add_transcript_fields)

components = {
    "view_id": "blocks",
    "dataset": "transcriptions",
    "stream": stream,
    "config": {
        "blocks": [
            {"view_id": "audio"},
            {"view_id": "text_input"},
        ],
        "audio_autoplay": False,
        "keymap": {"playpause": ["command+enter", "ctrl+enter"]},
    },
}
```

### Custom stream from an API / generator

```python
from prodigy.components.stream import get_stream
from prodigy.util import set_hashes

def fetch_examples():
    import requests
    resp = requests.get("https://api.example.com/items")
    for item in resp.json():
        task = {
            "text": item["content"],
            "meta": {"id": item["id"], "source": "api"},
        }
        yield set_hashes(task)

stream = get_stream(fetch_examples())

components = {
    "view_id": "classification",
    "dataset": "api_review",
    "stream": stream,
    "config": {"label": "RELEVANT"},
}
```

### Relation annotation

```python
import spacy
from prodigy.components.stream import get_stream
from prodigy.components.preprocess import add_tokens

nlp = spacy.load("en_core_web_sm")
stream = get_stream("./data.jsonl", rehash=True, dedup=True, input_key="text")
stream.apply(add_tokens, nlp=nlp, stream=stream)

components = {
    "view_id": "relations",
    "dataset": "relations",
    "stream": stream,
    "config": {
        "labels": ["WORKS_FOR", "LOCATED_IN", "FOUNDED_BY"],
        "relations_span_labels": ["PERSON", "ORG", "GPE"],
        "wrap_relations": True,
        "custom_theme": {"cardMaxWidth": "90%"},
        "exclude_by": "input",
    },
}
```

### Validating annotations

```python
from prodigy.components.stream import get_stream

stream = get_stream("./data.jsonl", rehash=True, dedup=True)

def validate_answer(answer):
    if answer.get("accept") is None or len(answer["accept"]) == 0:
        raise ValueError("Please select at least one option.")

components = {
    "view_id": "choice",
    "dataset": "validated",
    "stream": stream,
    "validate_answer": validate_answer,
    "config": {
        "choice_style": "multiple",
    },
}
```

### Excluding previously annotated examples

```python
from prodigy.components.stream import get_stream

stream = get_stream("./data.jsonl", rehash=True, dedup=True)

components = {
    "view_id": "text",
    "dataset": "my_dataset",
    "stream": stream,
    "exclude": ["my_dataset", "old_dataset"],  # Skip examples already in these datasets
}
```

---

## View ID Quick Reference

| View ID | Purpose | Requires tokens | Key task fields |
|---|---|---|---|
| `text` | Display text | No | `text` |
| `html` | Custom HTML | No | `html` |
| `classification` | Binary label | No | `text`, `label` |
| `choice` | Multiple choice | No | `text`, `options` |
| `ner` | Binary NER | No | `text`, `spans` |
| `ner_manual` | Manual NER | Yes | `text`, `tokens`, `spans` |
| `spans_manual` | Overlapping spans | Yes | `text`, `tokens`, `spans` |
| `pos_manual` | POS tagging | Yes | `text`, `tokens`, `spans` |
| `relations` | Relation annotation | Yes | `text`, `tokens`, `relations`, `spans` |
| `dep` | Dependency arcs | Yes | `text`, `tokens`, `arcs` |
| `image_manual` | Image boxes/polygons | No | `image` |
| `audio_manual` | Audio regions | No | `audio` |
| `text_input` | Free text entry | No | `field_id`, `field_label` |
| `blocks` | Composite | Varies | Depends on blocks |
| `review` | Conflict resolution | Varies | `versions` |
| `diff` | Text diff | No | `accept`, `reject` |
| `pages` | Multi-page docs | Varies | `pages` |
| `llm_io` | LLM prompt/response display | No | `llm` |

---

## Token Format

When a view requires tokens, each token dict must have:

```python
{
    "text": "Apple",    # Token text
    "start": 0,         # Character start offset
    "end": 5,           # Character end offset
    "id": 0,            # Token index
    "ws": True,         # Followed by whitespace?
    "disabled": False,   # Optional: make unselectable
}
```

Use `add_tokens(nlp, stream)` to generate these automatically from a spaCy
model.

## Span Format

```python
{
    "start": 0,          # Character start offset
    "end": 5,            # Character end offset
    "token_start": 0,    # Token start index (required for manual views)
    "token_end": 0,      # Token end index inclusive (required for manual views)
    "label": "ORG",      # Span label
    "text": "Apple",     # Optional: span text
}
```
