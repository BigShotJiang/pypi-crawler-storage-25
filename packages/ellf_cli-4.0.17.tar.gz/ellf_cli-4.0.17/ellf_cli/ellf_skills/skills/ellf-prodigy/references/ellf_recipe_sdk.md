# Ellf Recipe SDK

This reference covers the Ellf recipe SDK — the API for building recipes that
run on an Ellf cluster. If the user is developing for **standalone Prodigy**,
you don't need this file — use the standard Prodigy recipe API in
`prodigy_recipe_api.md` instead.

## Key differences from standalone Prodigy

| | Standalone Prodigy | Ellf |
|---|---|---|
| Decorator | `@prodigy.recipe("name")` | `@task_recipe(title=..., field_props=...)` / `@action_recipe(...)` / `@agent_recipe(...)` |
| Arguments | Positional/keyword function params | Keyword-only params + `field_props` for UI form generation |
| Data loading | `prodigy.get_stream("file.jsonl")` | `input.load()` on `Input` / `InputDataset` instances |
| Data types | Plain strings, paths | `Dataset`, `InputDataset`, `Input`, `Model`, `BlankModel`, `Patterns`, `Secret`, `Lang` |
| Run locally | `prodigy <recipe> ...` | `ellf-dev run <recipe> ...` / `ellf-dev preview <recipe> ...` |
| Deploy | N/A (already local) | `ellf publish code ./recipes` → `ellf tasks create <recipe>` |
| Return value | Components dict (tasks) | Components dict (tasks) / nothing (actions) / `Annotator` callable (agents) |
| Package structure | Single .py file or package | Python package initialized with `ellf recipes init` |

## Recipe decorators

### @task_recipe

For annotation tasks that start the Prodigy server. The function returns a
components dict (identical to standalone Prodigy).

```python
from typing import Literal
from ellf_recipes_sdk import task_recipe, props, TextProps, Dataset, Input

@task_recipe(
    title="My NER Recipe",
    description="Annotate named entities",
    field_props={
        "dataset": props.dataset_choice,
        "input": TextProps(title="Input data"),
        "labels": props.label,
    },
)
def my_ner(*, dataset: Dataset[Literal["text"]], input: Input, labels: list[str]):
    stream = input.load()
    return {
        "dataset": dataset.name,
        "stream": stream,
        "view_id": "ner_manual",
        "config": {"labels": labels},
    }
```

| Argument | Type | Description |
|---|---|---|
| `title` | `str` | Display title |
| `description` | `str` | Display description |
| `view_id` | `str` | Prodigy interface ID for recipe preview in the app |
| `field_props` | `dict[str, Props]` | Form field metadata, keyed by argument name |
| `cli_names` | `dict[str, str]` | Map long nested names to shorter CLI names |

### @action_recipe

For one-shot jobs (training, data processing, evaluation). No return value.

```python
from ellf_recipes_sdk import action_recipe, TextProps, Input

@action_recipe(
    title="Export and Train",
    description="Export data and train a spaCy model",
    field_props={
        "input": TextProps(title="Training data"),
    },
)
def export_and_train(*, input: Input):
    data = list(input.load())
    print(f"Training on {len(data)} examples")
    # ... training logic
```

### @agent_recipe

For autonomous agents (LLM annotators, bots) that can be assigned to tasks.
The function returns an `Annotator` callable — a function that takes `(task, config)`
dicts and returns an annotated task dict. The SDK handles server discovery, polling,
and answer submission automatically.

The `poll_interval` and `idle_shutdown_seconds` parameters are picked up by the SDK
from the recipe's function signature — you don't handle them yourself.

```python
from ellf_recipes_sdk import (
    agent_recipe, Annotator, FloatProps, Secret,
    detect_task_type, format_prompt, parse_response,
)

@agent_recipe(
    title="LLM Annotator",
    description="Autonomous NER annotation agent",
    field_props={
        "poll_interval": FloatProps(title="Poll interval (seconds)", min=0.1),
    },
)
def llm_annotator(
    *, api_key: Secret, model: str = "gpt-4o", poll_interval: float = 1.0
) -> Annotator:
    key = api_key.get_secret_value()
    client = MyLLMClient(api_key=key, model=model)

    async def annotate(task: dict, config: dict) -> dict:
        task_type = detect_task_type(task)
        prompt = format_prompt(task, task_type, config)
        raw = await client.ask(prompt)
        return parse_response(raw, task, task_type, model_name=model)

    return annotate
```

#### Annotator type

```python
Annotator = Callable[
    [dict[str, Any], dict[str, Any]],
    dict[str, Any] | Awaitable[dict[str, Any]],
]
```

The annotated task dict must include `"answer": "accept" | "reject" | "ignore"`.
Optionally set `"_annotator_id"` and `"_session_id"` to identify the agent.

#### Agent helper functions

| Function | Description |
|---|---|
| `detect_task_type(task)` | Infer annotation mode from task's `_view_id` or keys |
| `format_prompt(task, task_type, config)` | Build an LLM prompt for the task |
| `parse_response(raw, task, task_type, model_name=...)` | Parse LLM JSON response into annotation dict |

## Form field props

Props describe metadata for auto-generated UI forms and CLI arguments. The type
hint of the function parameter determines the field type; props add titles,
help text, validation, and widgets.

| Props class | For | Key settings |
|---|---|---|
| `TextProps` | `str` | `title`, `description`, `placeholder`, `pattern`, `validations` |
| `IntProps` | `int` | `title`, `min`, `max`, `step`, `widget` ("number"/"range"), `validations` |
| `FloatProps` | `float` | `title`, `min`, `max`, `step`, `validations` |
| `BoolProps` | `bool` | `title`, `description`, `widget` ("checkbox"/"toggle") |
| `ListProps` | `list[str]` | `title`, `placeholder`, `min`, `max`, `validations` |
| `ChoiceProps` | `Union`/`Literal` | `title`, `choice` (dict of sub-props), `widget` ("select"/"radio") |
| `Props` | Anything | Base class, has all fields |

### Pre-defined props

```python
from ellf_recipes_sdk import props

props.dataset_new       # TextProps for new dataset name
props.dataset_existing  # Props for existing dataset dropdown
props.dataset_choice    # Choice between new or existing dataset
props.label             # ListProps for comma-separated labels
props.lang              # ChoiceProps for spaCy language selection
```

### Validations

```python
from ellf_recipes_sdk import Validation

Validation(op="lt", value=1, message="Need at least one.", level="error")
Validation(op="ge", value=1000, message="That's a lot!", level="warning")
```

Operators: `ge`, `gt`, `le`, `lt`, `eq`, `ne`, `re` (regex).
Levels: `error` (blocks submit), `warning`, `info`, `success`.

### Optional fields

Mark argument as `Optional` → shows a checkbox toggle in the UI.

```python
from typing import Optional

def recipe(*, n_examples: Optional[int] = 100):
    ...
```

Use `optional_title` in props to customize the checkbox label.

### Union fields

For arguments that can be different types. Use `ChoiceProps`:

```python
from typing import Union, List

@task_recipe(
    field_props={
        "text": ChoiceProps(
            title="Text to use",
            choice={
                "text-str": TextProps(title="Single text"),
                "text-list": ListProps(title="Multiple texts"),
            },
        ),
    },
)
def recipe(*, text: Union[str, List[str]]):
    ...
```

## Data types

### Dataset / InputDataset

```python
from ellf_recipes_sdk import Dataset, InputDataset

# New dataset (created by recipe)
def recipe(*, dataset: Dataset[Literal["text"]]):
    return {"dataset": dataset.name, ...}

# Existing dataset (load data from it)
def recipe(*, input_dataset: InputDataset[Literal["text"]]):
    stream = input_dataset.load()  # same as Prodigy get_stream
```

The `Literal["text"]` constrains which datasets appear in the UI dropdown.

### Input (data assets)

```python
from ellf_recipes_sdk import Input

def recipe(*, data: Input):
    stream = data.load()  # loads from cluster asset

# Create a new asset (in action recipes)
Input.create(name="My data", path="{assets}/data.jsonl", loader="jsonl")

# Update existing asset (increments patch version)
data.update(path="{assets}/updated_data.jsonl")
```

### Model / BlankModel / UseModel

```python
from ellf_recipes_sdk import Model, BlankModel, UseModel

# Load a model asset from cluster
def recipe(*, model: Model):
    nlp = model.load()

# Create a blank model for a language
def recipe(*, model: BlankModel):
    nlp = model.load()  # blank spaCy pipeline

# Choice: pretrained or blank, with optional update-in-loop
def recipe(*, model: Union[UseModel, BlankModel]):
    nlp = model.load()
    if isinstance(model, UseModel) and model.update:
        # update model from annotations
        ...
```

### Patterns

```python
from ellf_recipes_sdk import Patterns

def recipe(*, patterns: Patterns, model: Model):
    nlp = model.load()
    matcher = patterns.load(nlp=nlp, label="PERSON")
    stream = (eg for _, eg in matcher(stream))
```

### Secret

```python
from ellf_recipes_sdk import Secret

def recipe(*, api_key: Secret):
    key = api_key.get_secret_value()
```

### Lang

Enum of spaCy languages: `Lang.en`, `Lang.de`, etc.

### Custom types (@ellf_type)

Group related settings into a reusable dataclass:

```python
from dataclasses import dataclass
from ellf_recipes_sdk import ellf_type, IntProps

@ellf_type(
    title="Stream settings",
    field_props={
        "min_length": IntProps(title="Minimum text length"),
    },
)
@dataclass
class StreamFilter:
    order_by: Literal["asc", "desc"] = "asc"
    min_length: int = 0

    def apply(self, stream):
        for eg in stream:
            if len(eg.get("text", "")) >= self.min_length:
                yield eg
```

Custom types can also subclass `Asset` to create custom asset types. Use
`CloudPath` (not `pathlib.Path`) for cloud paths on the cluster:

```python
from typing import Literal, ClassVar
from cloudpathlib import CloudPath
from ellf_recipes_sdk import ellf_type, Asset

@ellf_type("script", title="JavaScript", description="JS to customize the UI")
class Script(Asset[Literal["script"]]):
    kind: ClassVar[Literal["script"]] = "script"

    def load(self) -> str:
        with CloudPath(self.path).open("r", encoding="utf8") as f:
            return f.read()
```

### CLI name overrides

For union types, nested CLI arguments can get long (e.g., `--model-blank.lang`).
Use `cli_names` in the decorator to shorten them:

```python
@task_recipe(
    title="My Recipe",
    field_props={"model": Props(title="Model")},
    cli_names={
        "model-blank.lang": "model.lang",
        "model-use.name": "model.name",
    },
)
def recipe(model: Union[BlankModel, UseModel]):
    ...
```

### InputDataset.export

Export dataset examples to JSONL:

```python
def recipe(*, input_dataset: InputDataset[Literal["text"]]):
    input_dataset.export(path=Path("./exported.jsonl"))
```

## Dataset/asset kind constraints

Use `Literal` to restrict which assets/datasets appear in the UI:

```python
Dataset[Literal["text"]]     # only text datasets
Asset[Literal["image"]]      # only image assets
Input                        # any input asset (no constraint)
```

## Development workflow

### Initialize a recipe package

```bash
ellf recipes init ./recipes --name my_recipes
```

### Preview the form UI (live-reloads)

```bash
ellf-dev preview my_recipe ./recipes/my_recipes/recipes/my_recipe.py
```

### Run locally

```bash
pip install -e ./recipes
ellf-dev run my_recipe --dataset test --labels PERSON,ORG
```

### Publish to cluster

```bash
ellf publish code ./recipes/my_recipes --package-version 1.0.0
# Optional: --python-version 3.11 --requirements ./requirements.in
```

After publishing, create tasks/actions from the recipe:

```bash
ellf tasks create my_recipe --help
ellf tasks create my_recipe --name "NER annotation" --labels PERSON,ORG
ellf tasks start "NER annotation"
```
