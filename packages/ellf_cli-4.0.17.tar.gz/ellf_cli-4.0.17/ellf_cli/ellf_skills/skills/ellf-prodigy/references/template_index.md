# Recipe Template Index

Use this index to select the best starting template for the user's task.
Each template is a `.py` file with stub functions that the agent fills in.

**First decide the platform mode** from the current project context and target runtime:
- **Ellf** → use an Ellf template (task_recipe, action_recipe, agent_recipe)
- **Prodigy standalone** → use a standalone template (manual, correct, teach, etc.)

## Ellf Templates

For recipes that run on an Ellf cluster. Use the ellf SDK decorators,
data types (`Dataset`, `Input`, `Model`, `Secret`), and props for auto-generated
UI forms. See `references/ellf_recipe_sdk.md` for the full API.

| Template | When to Use | Key Stubs |
|----------|-------------|-----------|
| **task_recipe** | Annotation tasks on the cluster (NER, textcat, spans, etc.) | `preprocess_stream`, `add_predictions` |
| **action_recipe** | Batch jobs: training, export, import, evaluation, deployment | `process_data` |
| **agent_recipe** | Autonomous LLM-powered annotators assigned to tasks | `create_llm_client`, `annotate` (returned as `Annotator`) |

### task_recipe

**File:** `assets/templates/template_task_recipe.py`

Use when the user wants to create an annotation task for the cluster. The
recipe uses `@task_recipe`, returns a Prodigy components dict (same as
standalone), but arguments use ellf data types (`Dataset`, `Input`, `Model`)
and `field_props` for auto-generated web forms and CLI arguments.

### action_recipe

**File:** `assets/templates/template_action_recipe.py`

Use for batch jobs that run and exit — training, data processing, evaluation,
export, import, deployment. The recipe uses `@action_recipe` and has no return
value. Actions can create output assets on the cluster via `Input.create()`.

### agent_recipe

**File:** `assets/templates/template_agent_recipe.py`

Use when the user wants to create an autonomous annotation agent powered by an
LLM. Agents are assigned to running tasks and annotate alongside humans. The
recipe uses `@agent_recipe` and returns an `Annotator` callable — a function
that takes `(task, config)` and returns an annotated task dict. The SDK handles
server discovery, polling, and answer submission automatically. Helper functions
`detect_task_type`, `format_prompt`, and `parse_response` handle common
LLM-based annotation patterns.

---

## Standalone Prodigy Templates

For recipes that run locally with `prodigy <recipe>`. Use `@prodigy.recipe`
decorator and return a components dict. See `references/prodigy_recipe_api.md`
for the API.

| Template | When to Use | Stubs |
|----------|-------------|-------|
| **manual** | Manual annotation from scratch — no model predictions | `load_data`, `modify_stream`, `before_db` |
| **correct** | Review and correct predictions from a model or pattern file | `load_data`, `load_predictor`, `add_suggestions_to_stream`, `update_model` |
| **teach** | Active learning — model selects uncertain examples, gets updated | `load_data`, `load_model`, `get_predictions`, `update_model` |
| **blocks_ui** | Composite UI combining multiple annotation interfaces | `prepare_stream` |
| **pages_ui** | Multi-page documents (PDFs, image sequences) | `load_and_structure_pages` |
| **custom_ui** | Advanced UI with custom HTML, JavaScript, and event hooks | `my_event_handler` |
| **routing** | Custom task distribution among multiple annotators | `my_task_router` |

---

## Template Details

### manual

**File:** `assets/templates/template_manual.py`

Use for tasks that require creating text, audio, image, or video annotations
from scratch. This is a manual workflow where the user annotates data without
any initial predictions from a model or rules. Best when the user specifies
"manual annotation" or provides no model.

**Stubs:**
- `load_data` — Loads data from a source such as file, directory, or API.
- `modify_stream` — Applies preprocessing to the input data, like adding tokenization or calling an API for translation.
- `before_db` — A callback to modify examples just before they are saved to the database.

---

### correct

**File:** `assets/templates/template_correct.py`

Use when a user wants to review and correct predictions made by an automated
system (like a model or patterns file). This is the primary workflow for
creating gold-standard data with a human-in-the-loop. It is data-agnostic and
can be used for text, images, or audio.

**Stubs:**
- `load_data` — Loads the source data to be corrected.
- `load_predictor` — Loads the model, patterns file, or LLM that will generate the initial predictions.
- `add_suggestions_to_stream` — Applies the predictor to each example in the stream to add the suggestions that will be corrected.
- `update_model` — An optional callback to update the model with corrected annotations during the session.

---

### teach

**File:** `assets/templates/template_teach.py`

Use for active learning workflows where a model is "in the loop". The model
selects the most uncertain examples to be annotated, and it is updated with
every new annotation. Best when the user has a working model and wants to
improve it efficiently.

**Stubs:**
- `load_data` — Loads the source data for annotation.
- `load_model` — Loads the initial model that will be taught.
- `get_predictions` — Gets predictions from the model and must yield a score (for uncertainty) and the example.
- `update_model` — An obligatory callback that updates the model with new annotations from the user.

---

### blocks_ui

**File:** `assets/templates/template_blocks_ui.py`

Use when the user wants to combine multiple annotation interfaces into a single
view, like showing NER spans and a text input box for the same document. This is
done using the "blocks" interface.

**Stubs:**
- `prepare_stream` — Prepares the stream by adding all necessary data fields required by the different blocks in the UI.

---

### pages_ui

**File:** `assets/templates/template_pages_ui.py`

Use when the user needs to annotate documents that are split into multiple parts
or pages, like a multi-page PDF or a sequence of related images. This groups
multiple pieces of content into a single annotation task.

**Stubs:**
- `load_and_structure_pages` — Loads data and structures it for the "pages" interface, which requires a "pages" key in each example.

---

### custom_ui

**File:** `assets/templates/template_custom_ui.py`

Use for advanced UI customization using custom HTML, JavaScript, and event
hooks. This allows for creating fully interactive annotation interfaces with
custom buttons, sliders, or backend Python functions triggered from the UI.

**Stubs:**
- `my_event_handler` — A Python function that can be called from the JavaScript frontend to perform backend actions.

---

### routing

**File:** `assets/templates/template_routing.py`

Use when the user needs to implement custom logic for distributing tasks among
multiple annotators, such as routing tasks based on language or assigning tasks
to specific people.

**Stubs:**
- `my_task_router` — A custom function that decides which annotator(s) should see each task.
