#!/usr/bin/env python
"""Lint a Prodigy recipe file for syntax errors and common bugs.

Usage:
    python lint_recipe.py <recipe.py>

Exit codes:
    0 — no errors
    1 — errors found (printed to stderr)

Checks run (in order):
    1. ast.parse        — syntax errors
    2. pylint --errors-only — undefined names, bad arguments, attribute errors
       (falls back to py_compile if pylint is not installed)
"""

from __future__ import annotations

import ast
import subprocess
import sys
from pathlib import Path


def check_syntax(path: Path) -> list[str]:
    """Return syntax errors, if any."""
    source = path.read_text()
    try:
        ast.parse(source, filename=str(path))
    except SyntaxError as e:
        return [f"{path}:{e.lineno}: SyntaxError: {e.msg}"]
    return []


def check_pylint(path: Path) -> list[str]:
    """Run pylint --errors-only; fall back to py_compile if unavailable."""
    try:
        result = subprocess.run(
            [
                sys.executable,
                "-m",
                "pylint",
                "--errors-only",
                "--disable=import-error,no-member",
                "--",
                str(path),
            ],
            capture_output=True,
            text=True,
            timeout=30,
        )
    except FileNotFoundError:
        return _fallback_py_compile(path)
    except subprocess.TimeoutExpired:
        return [f"{path}: pylint timed out"]

    if result.returncode == 0:
        return []

    # pylint returns 1 for fatal errors, 2+ for messages found
    # Check if it actually ran or if the module is missing
    if "No module named pylint" in result.stderr:
        return _fallback_py_compile(path)

    errors = []
    for line in result.stdout.strip().splitlines():
        line = line.strip()
        if line and not line.startswith("*"):
            errors.append(line)
    return errors


def _fallback_py_compile(path: Path) -> list[str]:
    """Compile-check only — used when pylint is not installed."""
    result = subprocess.run(
        [sys.executable, "-m", "py_compile", str(path)],
        capture_output=True,
        text=True,
        timeout=15,
    )
    if result.returncode == 0:
        return []
    msg = (result.stderr or result.stdout).strip()
    return [msg] if msg else [f"{path}: py_compile failed"]


def check_recipe_structure(path: Path) -> list[str]:
    """AST-level checks for Prodigy recipe patterns (standalone and Teams)."""
    source = path.read_text()
    tree = ast.parse(source, filename=str(path))
    errors = []

    for node in ast.walk(tree):
        if not isinstance(node, ast.FunctionDef):
            continue
        decorators = [_decorator_name(d) for d in node.decorator_list]

        # --- Teams SDK checks ---

        # @task_recipe must return something (components dict)
        if "task_recipe" in decorators:
            if not _has_return(node):
                errors.append(
                    f"{path}:{node.lineno}: @task_recipe function "
                    f"'{node.name}' has no return statement — "
                    f"task recipes must return a Prodigy components dict"
                )

        # @action_recipe should NOT return a value
        if "action_recipe" in decorators:
            if _has_return_value(node):
                errors.append(
                    f"{path}:{node.lineno}: @action_recipe function "
                    f"'{node.name}' returns a value — "
                    f"action recipes should not return anything"
                )

        # @agent_recipe must return an Annotator callable
        if "agent_recipe" in decorators:
            if not _has_return_value(node):
                errors.append(
                    f"{path}:{node.lineno}: @agent_recipe function "
                    f"'{node.name}' does not return a value — "
                    f"agent recipes must return an Annotator callable"
                )

        # Teams recipes must use keyword-only arguments
        if any(
            d in decorators for d in ("task_recipe", "action_recipe", "agent_recipe")
        ):
            if node.args.args:  # positional args (excluding self)
                errors.append(
                    f"{path}:{node.lineno}: Teams recipe '{node.name}' has "
                    f"positional arguments — Teams recipes must use "
                    f"keyword-only arguments (def recipe(*, arg1, arg2, ...))"
                )

        # --- Standalone Prodigy checks ---

        # @recipe must return something (components dict)
        if "recipe" in decorators:
            if not _has_return(node):
                errors.append(
                    f"{path}:{node.lineno}: @recipe function "
                    f"'{node.name}' has no return statement — "
                    f"recipes must return a Prodigy components dict"
                )

    return errors


def _decorator_name(node: ast.expr) -> str:
    """Extract the base name of a decorator (ignoring arguments)."""
    if isinstance(node, ast.Call):
        node = node.func
    if isinstance(node, ast.Name):
        return node.id
    if isinstance(node, ast.Attribute):
        return node.attr
    return ""


def _has_return(node: ast.FunctionDef) -> bool:
    """Check if a function has at least one return statement."""
    for child in ast.walk(node):
        if isinstance(child, ast.Return):
            return True
    return False


def _has_return_value(node: ast.FunctionDef) -> bool:
    """Check if a function has a return statement with a value."""
    for child in ast.walk(node):
        if isinstance(child, ast.Return) and child.value is not None:
            return True
    return False


def lint(path: Path) -> list[str]:
    """Run all checks and return a list of error strings."""
    errors = check_syntax(path)
    if errors:
        # No point running further checks if syntax is broken
        return errors
    errors.extend(check_recipe_structure(path))
    errors.extend(check_pylint(path))
    return errors


def main() -> int:
    if len(sys.argv) != 2:
        print(f"Usage: {sys.argv[0]} <recipe.py>", file=sys.stderr)
        return 1

    path = Path(sys.argv[1])
    if not path.is_file():
        print(f"File not found: {path}", file=sys.stderr)
        return 1

    errors = lint(path)
    if errors:
        for e in errors:
            print(e, file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
