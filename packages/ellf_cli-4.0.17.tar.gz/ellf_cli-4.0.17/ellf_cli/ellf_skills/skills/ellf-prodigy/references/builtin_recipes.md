# Built-in Recipes

Use this reference to check whether a built-in recipe already covers the user's
task. If it does, recommend the built-in recipe instead of building a custom
one. Only build a custom recipe when the user needs something the built-in
recipes don't provide.

---

## Ellf Built-in Recipes

The platform ships with built-in task and action recipes available on every
cluster. These use `@task_recipe` / `@action_recipe` decorators and are
launched via the web UI or `ellf tasks create <recipe>` / `ellf actions create <recipe>`.

### Built-in Task Recipes

| Recipe | Title | What it does |
|---|---|---|
| `ner` | Named Entity Recognition | NER annotation with model-assisted or manual modes |
| `spans` | Span Categorization | Overlapping span annotation (SpanCategorizer) |
| `textcat` | Text Classification | Single/multi-label text classification |
| `relations` | Relation Extraction | Annotate relations between entities |
| `coref` | Coreference Resolution | Link mentions and pronouns |
| `dep` | Dependency Parsing | Annotate syntactic dependencies |
| `pos` | Part of Speech Tagging | POS tag annotation |
| `terms` | Terminology List | Build terminology/gazetteer lists |
| `image` | Image Annotation | Bounding boxes, polygons, image classification |
| `audio` | Audio Annotation | Label audio regions, transcription |
| `video` | Video Annotation | Label video segments |
| `curate` | Curate and Explore | Browse and curate data |
| `review` | Review Annotations | Review and resolve annotator disagreements |
| `sent` | Sentence Segmentation | Sentence boundary annotation |

### Built-in Action Recipes

| Recipe | Title | What it does |
|---|---|---|
| `train` | Train a spaCy pipeline | Train a spaCy model from annotated data |
| `db_actions` | Dataset Operations | Merge, copy, export datasets |
| `create_asset` | Create Asset | Register a new asset on the cluster |

These cover most common workflows. Check what's available on the cluster with
`ellf recipes list` or the `recipe_list` MCP tool. Each recipe's arguments and
form fields are discoverable via the web UI or CLI `--help`.

---

## Standalone Prodigy Recipes

These use `@prodigy.recipe` and are run locally with `prodigy <recipe>`.
Same annotation workflows as above but with CLI-style positional arguments
instead of web forms.

## Named Entity Recognition

### ner.manual
Manual NER — highlight entity spans in text. No model required (uses a spaCy
model only for tokenization; `blank:lang` works fine).

```
prodigy ner.manual DATASET SPACY_MODEL SOURCE --label LABEL1,LABEL2
```

Example:
```
prodigy ner.manual ner_news blank:en ./news.jsonl --label PERSON,ORG,PRODUCT
```

Key options: `--patterns` (pre-highlight with match patterns), `--highlight-chars`
(character-level highlighting), `--edit-text` (allow text editing).

### ner.correct
Correct a spaCy NER model's predictions. Model predicts entities, annotator
fixes mistakes.

```
prodigy ner.correct DATASET SPACY_MODEL SOURCE --label LABEL1,LABEL2
```

Key options: `--update` (update model in the loop), `--component` (pipeline
component name).

### ner.teach
Active learning — model selects uncertain examples. Binary accept/reject
interface.

```
prodigy ner.teach DATASET SPACY_MODEL SOURCE --label LABEL1,LABEL2
```

Key options: `--patterns` (combine with match patterns).

### ner.llm.correct
LLM-assisted NER — correct entity predictions from a spacy-llm pipeline.
Requires a spacy-llm config file.

```
prodigy ner.llm.correct DATASET CONFIG_PATH SOURCE
```

### ner.llm.fetch
Batch-fetch LLM NER predictions to a file or dataset (no annotation UI).
Correct afterwards with `ner.manual`.

```
prodigy ner.llm.fetch CONFIG_PATH SOURCE OUTPUT
```

### ner.model-annotate
Use a model to auto-annotate data (no human UI). Useful for creating baseline
annotations to review later.

```
prodigy ner.model-annotate DATASET SPACY_MODEL SOURCE MODEL_ALIAS --label LABELS
```

### ner.silver-to-gold
Convert binary accept/reject datasets into gold-standard manual annotations.

```
prodigy ner.silver-to-gold DATASET SILVER_SETS SPACY_MODEL --label LABELS
```

### ner.eval-ab
Blind A/B comparison of two NER models on the same data.

```
prodigy ner.eval-ab DATASET MODEL_A MODEL_B SOURCE
```

---

## Span Categorization

### spans.manual
Manual span annotation — like NER but allows overlapping spans. For training
spaCy's `SpanCategorizer`.

```
prodigy spans.manual DATASET SPACY_MODEL SOURCE --label LABEL1,LABEL2
```

Key options: `--patterns`, `--suggester` (validate against a span suggester),
`--highlight-chars`, `--edit-text`.

### spans.correct
Correct a trained SpanCategorizer's predictions.

```
prodigy spans.correct DATASET SPACY_MODEL SOURCE --label LABELS
```

Key options: `--update`, `--component`.

### spans.model-annotate
Auto-annotate spans with a model (no UI).

```
prodigy spans.model-annotate DATASET SPACY_MODEL SOURCE MODEL_ALIAS --labels LABELS
```

---

## Text Classification

### textcat.manual
Manual text classification. Single label → binary accept/reject UI. Multiple
labels → multiple choice UI. No model required.

```
prodigy textcat.manual DATASET SOURCE --label LABEL1,LABEL2
```

Key options: `--exclusive` (mutually exclusive labels), `--accept-empty`.

### textcat.correct
Correct a trained text classifier's predictions.

```
prodigy textcat.correct DATASET SPACY_MODEL SOURCE --label LABELS
```

Key options: `--threshold` (score cutoff for pre-selection), `--update`.

### textcat.teach
Active learning for text classification — binary accept/reject.

```
prodigy textcat.teach DATASET SPACY_MODEL SOURCE --label LABELS
```

### textcat.llm.correct
LLM-assisted text classification via spacy-llm.

```
prodigy textcat.llm.correct DATASET CONFIG_PATH SOURCE
```

### textcat.model-annotate
Auto-annotate text categories with a model (no UI).

```
prodigy textcat.model-annotate DATASET SPACY_MODEL SOURCE MODEL_ALIAS --labels LABELS
```

---

## Relations & Dependencies

### rel.manual
Annotate directional relations between tokens/expressions. Supports joint
entity + relation annotation. Very flexible — can pre-define spans using a
model, patterns, or NER labels.

```
prodigy rel.manual DATASET SPACY_MODEL SOURCE --label REL1,REL2 --span-label ENT1,ENT2
```

Key options: `--add-ents` (use model entities), `--add-nps` (use noun phrases),
`--patterns`, `--disable-patterns`, `--wrap`.

### dep.correct
Correct dependency parse predictions from a spaCy model.

```
prodigy dep.correct DATASET SPACY_MODEL SOURCE --label ROOT,nsubj,dobj
```

Key options: `--update`, `--wrap`.

### dep.teach
Active learning for dependency parsing.

```
prodigy dep.teach DATASET SPACY_MODEL SOURCE --label LABELS
```

### coref.manual
Coreference resolution — link pronouns and mentions to antecedents.

```
prodigy coref.manual DATASET SPACY_MODEL SOURCE --label COREF
```

---

## Part-of-Speech Tagging

### pos.correct
Correct POS tag predictions from a spaCy model.

```
prodigy pos.correct DATASET SPACY_MODEL SOURCE --label NN,NNS,NNP,NNPS
```

### pos.teach
Active learning for POS tagging.

```
prodigy pos.teach DATASET SPACY_MODEL SOURCE --label LABELS
```

---

## Sentence Segmentation

### sent.correct
Correct sentence boundary predictions.

```
prodigy sent.correct DATASET SPACY_MODEL SOURCE
```

### sent.teach
Active learning for sentence segmentation.

```
prodigy sent.teach DATASET SPACY_MODEL SOURCE
```

---

## Computer Vision

### image.manual
Draw bounding boxes and polygons on images.

```
prodigy image.manual DATASET SOURCE --label LABEL1,LABEL2
```

Source can be a directory of images. Key options: `--width`, `--darken`,
`--no-fetch` (keep images as URLs), `--remove-base64`, `--loader pages`
(multi-page documents).

---

## Audio & Video

### audio.manual
Label regions in audio or video files.

```
prodigy audio.manual DATASET SOURCE --label LABEL1,LABEL2
```

Source is a directory of audio files. Key options: `--loader video` (for video),
`--autoplay`, `--fetch-media`.

### audio.transcribe
Manually transcribe audio/video files with a text input field.

```
prodigy audio.transcribe DATASET SOURCE
```

Key options: `--loader video`, `--text-rows`, `--field-id`.

---

## Review & Evaluation

### review
Review annotations from multiple annotators and resolve conflicts.

```
prodigy review DATASET DATASETS_TO_REVIEW --label LABELS
```

Key options: `--auto-accept` (skip non-conflicts), `--accept-single`,
`--show-skipped`.

### compare
Blind A/B comparison of two outputs (e.g. model vs baseline). Expects JSONL
with `id`, `input`, and `output` fields.

```
prodigy compare DATASET A_FILE B_FILE
```

Key options: `--diff` (visual diff mode).

---

## Inter-Annotator Agreement

### metric.iaa.doc
Document-level IAA (percent agreement, Krippendorff's Alpha, Gwet's AC2).

```
prodigy metric.iaa.doc SOURCE ANNOTATION_TYPE --labels LABELS
```

### metric.iaa.span
Span-level IAA (micro-averaged pairwise F1).

```
prodigy metric.iaa.span SOURCE --labels LABELS
```

### metric.iaa.binary
Binary annotation IAA.

```
prodigy metric.iaa.binary SOURCE
```

---

## When to build a custom recipe instead

A built-in recipe won't be enough when the user needs:
- Custom data loading (APIs, databases, cloud storage, non-standard formats)
- Custom preprocessing in the stream (translation, data augmentation, API calls)
- Custom UI blocks or composite interfaces beyond what built-in recipes offer
- Custom callbacks (before_db, on_exit, validate_answer)
- Custom task routing logic for multi-annotator setups
- Integration with external models not supported by spaCy/spacy-llm
- Non-standard annotation workflows (e.g. multi-step, conditional)
