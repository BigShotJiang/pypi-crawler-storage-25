---
name: ellf-handoff
description: Create a todo for the local coding agent. Summarizes the conversation, creates a structured request via the todo_create PAM tool, and tells the user to run /ellf-todo. Use when the conversation reaches a point where coding is needed — custom recipes, training scripts, pipeline components, or any work that requires local file editing.
argument-hint: "[description of what needs to be done]"
---

# Ellf Handoff

When coding work is needed, create a structured request so the user's local
coding agent can pick it up with full context.

$ARGUMENTS

## Step 1: Gather task details

Extract as much as possible from the conversation. If critical details are
missing (model choice, entity types, data source, special requirements), use
the **AskUserQuestion** tool to ask — do NOT ask in plain text.

| Field | How to get it |
|---|---|
| **description** | Specific and actionable. Not "implement NER" but "Create a custom ner.correct recipe with Ctrl+Enter keybinding for accept_best." |
| **context_summary** | 2-3 paragraphs condensing the conversation: what was discussed, decisions made, constraints, label schemes, data formats. |

## Step 2: Create the request

Call the `todo_create` PAM tool — do NOT use Bash or ellf:

```
todo_create(
  description="<description>",
  context_summary="<context_summary>"
)
```

The tool automatically scopes the request to the current project and links it
to this conversation. Do not pass project_id or conversation_id — they are
bound at session time.

## Step 3: Present the handoff

| Field | Value |
|---|---|
| **Request ID** | `<id from tool result>` |
| **Project** | <project name> |
| **Status** | planned |
| **Description** | <description> |

> I've created a todo for this. In your local Claude Code, run `/ellf-todo`
> to pick it up. It will load our conversation context automatically.

Briefly explain what the task covers — enough for the user to understand,
not a full implementation plan.
