---
name: ellf-train
description: "Has curated references for spaCy config generation, architecture selection, model selection, experiment design, training diagnostics, evaluation methodology, and troubleshooting — load this skill to get that expertise before making training decisions. Use whenever training is about to happen: creating a training action, choosing a base model, generating a config, designing experiments, interpreting scores, or debugging training problems. Also trigger on training curves, loss values, F-scores, or 'my model isn't learning'."
argument-hint: "[describe what you want to train, or provide a dataset name]"
---

# NLP Model Training

You help users go from annotated data to a trained spaCy model — locally or on the Ellf cluster.

$ARGUMENTS

## Setup

1. **Read `${CLAUDE_SKILL_DIR}/references/workflow.md`** — this is your decision flowchart. It tells you where you are in the training process and what to do next. Read it on every invocation.

2. **Check for a shared project plan** using the current project context. Read the current plan with the local `ellf plans` commands and extract training-relevant context such as task type, labels, data decisions, prior architecture choices, and any previous launch decisions.

3. **Check for `training_history.md`** in the working directory. If found, the Current Status section tells you where things stand. Resume from there.

4. **Follow the workflow flowchart** to determine the next action. The workflow includes a data validation gate — if the data doesn't meet minimum thresholds for the task type, your job is to tell the user and route to annotation, not to push through to training. A training skill that launches doomed runs isn't helping anyone.

## Your role

You are responsible for:
- training strategy
- local config and data preparation
- choosing local vs cluster execution
- preparing a launch spec for the chosen target
- interpreting results
- maintaining `training_history.md`
- updating the shared project plan with training-relevant context and decisions

You are not the primary monitoring skill after launch. Use `/ellf-monitor` for runtime inspection and long-running follow-up. Use `/ellf-ops` as the execution owner when the work is ready to run.

## Execution targets

### Local training

Use local training when the user needs:
- config generation or iteration
- export/debug loops
- quick experimentation
- local `spacy train`
- local `spacy evaluate`
- detailed config debugging

#### Local training path

For local runs, use concrete spaCy tooling as appropriate:
- `data-to-spacy`
- `spacy init config`
- `spacy debug config`
- `spacy train`
- `spacy evaluate`

Before execution:
- prepare data and config
- make sure logging/monitoring is configured
- show the exact command
- get confirmation before running

Use `/ellf-monitor` after launch to inspect training progress and outputs.

### Cluster training

Use cluster training when the user wants:
- an Ellf action running on the cluster
- managed execution with worker classes
- shared project-side execution
- training through an existing Ellf action recipe
- a run that should be visible/manageable through Ellf

### Cluster training path

**Prerequisites** — both must be accessible on the cluster before launching:
- training dataset in a cluster path or alias
- validated spaCy config

If either prerequisite exists only locally, prepare it first and then upload or reference it in the cluster path.

Typical cluster prep may include:

```bash
ellf files cp <local_train.spacy> <cluster_path_or_alias>
ellf files cp <local_config.cfg> <cluster_path_or_alias>
```

Do not guess cluster paths or recipe arg names. Confirm them explicitly.

**1. Discover the training recipe and its args:**

```bash
ellf recipes list                           # find available training recipes
ellf actions create <recipe> --help         # get exact arg names and required fields
```

Use these commands to identify the action recipe and gather the exact create arguments.

**2. Create and start the action:**

```bash
ellf actions create <recipe> --name "<name>" <args>
ellf actions start "<name>" [--worker-class <class>]
```

If the job is operationally ready and the user wants execution, hand the launch to `/ellf-ops`. This skill owns training readiness and launch-shape decisions; `/ellf-ops` owns the execution mechanics.

**Worker class selection:**

| Architecture | Worker class |
|---|---|
| `en_core_web_trf` (transformer) | `gpu` |
| `en_core_web_lg/md/sm` (tok2vec) | `base` or `medium` |
| `en_core_web_lg` with large data | `medium` |

Use `--worker-class gpu` for transformer-based configs. CPU workers are
sufficient for tok2vec architectures and are cheaper.

**3. Monitor during training:**

```bash
ellf actions logs "<name>"           # stream training output (same log format as local)
ellf actions info "<name>" --json    # check running state
```

Log interpretation (curve shape, anomaly detection, per-label scores) works the
same as for local runs. Raw log data comes from `ellf actions logs <name>` instead
of the local `training_log.jsonl`.

**4. Stop if needed:**

```bash
ellf actions stop "<name>"
```

Use `/ellf-ops` if you need to restart or manage the job operationally.

Training commands are compute-heavy. Always show the user the full command
and get confirmation before executing.

## Monitoring setup

Before launching training, ensure the relevant logging path is configured.

For local spaCy training:
- deploy `${CLAUDE_SKILL_DIR}/scripts/ellf_logger.py` when applicable
- keep structured logs available for follow-up inspection

For cluster training:
- make sure the action path exposes enough logs and outputs for `/ellf-monitor` to inspect progress
- prefer action args and outputs that make training state easy to inspect via `ellf actions info` and `ellf actions logs`

## Training history

Maintain `training_history.md` throughout the training effort:

```markdown
# Training History: [title]

## Current Status
**Phase**: [Gathering requirements / Exporting / Training / Analyzing]
**Best result**: [score + model path, or "None yet"]
**Next step**: [what should happen next]

## Setup
- **Task type**: [NER / textcat / spancat / ...]
- **Dataset**: [description and size]

## Experiment Log
### Run 1 — Baseline (YYYY-MM-DD)
- **Config**: `configs/run1_baseline.cfg`
- **Data**: dataset_name, N train / M dev
- **Result**: 0.82 F1 (LABEL_A 0.91, LABEL_B 0.72)
- **Decision**: [what to do next and why]

## Decision Log
- **[Topic]**: [Decision]. _Rationale: [why]._
```

Update `training_history.md` at every significant milestone. Also keep the
shared project plan in sync through the local plan CLI for the current project.

## Reference files

| File | What it covers | When to read |
|------|---------------|--------------|
| `${CLAUDE_SKILL_DIR}/references/workflow.md` | Decision flowchart — determines next action | Every invocation |
| `${CLAUDE_SKILL_DIR}/references/model_selection.md` | Base model selection (sm/md/lg/trf) | Architecture decisions |
| `${CLAUDE_SKILL_DIR}/references/config_architectures.md` | Architecture config snippets | Config generation |
| `${CLAUDE_SKILL_DIR}/references/config_training.md` | Training config (batchers, LR, optimizer) | Config generation |
| `${CLAUDE_SKILL_DIR}/references/config_advanced.md` | Pretraining, sourcing, loggers, score weights | Advanced config |
| `${CLAUDE_SKILL_DIR}/references/training_paradigms.md` | Active learning, distillation, pretraining strategies | Strategy decisions |
| `${CLAUDE_SKILL_DIR}/references/experiment_patterns.md` | Multi-trial, comparison, sweep templates | Experiment design |
| `${CLAUDE_SKILL_DIR}/references/evaluation_guide.md` | Metrics, per-label analysis, thresholds | Post-training analysis |
| `${CLAUDE_SKILL_DIR}/references/diagnostics.md` | Six problem classes with detection signals and fix guidance | Result interpretation and next-step decisions |
| `${CLAUDE_SKILL_DIR}/references/training_troubleshooting.md` | Error taxonomy with fixes | Concrete setup or execution debugging; prefer `/ellf-monitor` for active runtime troubleshooting |
| `${CLAUDE_SKILL_DIR}/scripts/ellf_logger.py` | JSONL step logger for spaCy train — deploy in config before training | Monitoring setup |
