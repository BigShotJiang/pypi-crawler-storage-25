# Experiment Patterns

Templates and instructions for multi-run experiments. Load this file when the
user selects an experiment mode other than "Quick run".

---

## Multiple Trials (Variance Measurement)

Run the same config with different random seeds to measure result variance.
Essential for knowing whether a score difference is real or noise.

### Script Template

Generate this script, adapted to the user's paths and config:

```python
"""Run multiple training trials with different seeds."""
import subprocess
import json
import sys
from pathlib import Path

CONFIG = "config.cfg"         # adjust per project
OUTPUT_BASE = "output/trials" # each trial gets a subdirectory
CODE_FILE = "ellf_logger.py"  # logger with anomaly detection
GPU_ID = 0                    # -1 for CPU
SEEDS = [0, 1, 2, 3, 4]      # 5 trials is a good default

def run_trial(seed: int) -> dict:
    output_dir = Path(OUTPUT_BASE) / f"seed-{seed}"
    output_dir.mkdir(parents=True, exist_ok=True)

    cmd = [
        sys.executable, "-m", "spacy", "train", CONFIG,
        "--output", str(output_dir),
        "--code", CODE_FILE,
        "--gpu-id", str(GPU_ID),
        "--training.seed", str(seed),
        "--system.seed", str(seed),
    ]
    print(f"\n{'='*60}")
    print(f"Trial seed={seed} → {output_dir}")
    print(f"{'='*60}")

    result = subprocess.run(cmd, capture_output=False)

    # Read best score from meta.json
    meta_path = output_dir / "model-best" / "meta.json"
    if meta_path.exists():
        meta = json.loads(meta_path.read_text())
        score = meta.get("performance", {}).get("score", None)
        return {"seed": seed, "score": score, "status": "ok"}
    return {"seed": seed, "score": None, "status": f"exit code {result.returncode}"}


if __name__ == "__main__":
    results = []
    for seed in SEEDS:
        results.append(run_trial(seed))

    # Summary
    print(f"\n{'='*60}")
    print("RESULTS SUMMARY")
    print(f"{'='*60}")
    scores = [r["score"] for r in results if r["score"] is not None]
    for r in results:
        status = f'{r["score"]:.4f}' if r["score"] else r["status"]
        print(f"  Seed {r['seed']}: {status}")
    if scores:
        mean = sum(scores) / len(scores)
        variance = sum((s - mean) ** 2 for s in scores) / len(scores)
        stddev = variance ** 0.5
        print(f"\n  Mean:   {mean:.4f}")
        print(f"  StdDev: {stddev:.4f}")
        print(f"  Range:  {min(scores):.4f} – {max(scores):.4f}")

    # Save results
    Path("trial_results.json").write_text(json.dumps(results, indent=2))
    print(f"\nResults saved to trial_results.json")
```

### Execution

Save the generated script and run it directly:

```bash
python run_trials.py
```

### Interpreting Results
- **StdDev < 0.01**: Results are stable, single runs are reliable.
- **StdDev 0.01–0.03**: Normal variance. Report mean ± stddev.
- **StdDev > 0.03**: High variance. Investigate: small dataset? Unstable
  architecture? Consider more data or a more stable model.

---

## Architecture Comparison

Compare different model architectures side by side. Most useful for textcat
(BOW vs CNN vs transformer) but also valuable for NER (tok2vec sizes).

### Config Generation

For each architecture, generate a separate config using `spacy init config`:

**BOW (fast baseline)**:
```bash
python -m spacy init config config-bow.cfg --lang en --pipeline textcat \
  --optimize efficiency
```

**CNN (balanced)**:
```bash
python -m spacy init config config-cnn.cfg --lang en --pipeline textcat
# Uses tok2vec + CNN by default
```

**Transformer (accuracy)**:
```bash
python -m spacy init config config-trf.cfg --lang en --pipeline textcat \
  --optimize accuracy
```

### Comparison Script

```python
"""Compare architectures by training each and collecting results."""
import subprocess
import json
import sys
from pathlib import Path

ARCHITECTURES = {
    "bow": "config-bow.cfg",
    "cnn": "config-cnn.cfg",
    "trf": "config-trf.cfg",
}
CODE_FILE = "ellf_logger.py"
GPU_ID = 0  # TRF needs GPU; BOW/CNN can use CPU

results = {}
for name, config in ARCHITECTURES.items():
    output_dir = Path(f"output/arch-{name}")
    output_dir.mkdir(parents=True, exist_ok=True)

    cmd = [
        sys.executable, "-m", "spacy", "train", config,
        "--output", str(output_dir),
        "--code", CODE_FILE,
        "--gpu-id", str(GPU_ID),
    ]
    print(f"\n{'='*60}")
    print(f"Architecture: {name} ({config})")
    print(f"{'='*60}")

    result = subprocess.run(cmd, capture_output=False)

    meta_path = output_dir / "model-best" / "meta.json"
    if meta_path.exists():
        meta = json.loads(meta_path.read_text())
        perf = meta.get("performance", {})
        results[name] = {
            "score": perf.get("score"),
            "per_component": {k: v for k, v in perf.items() if k != "score"},
            "status": "ok",
        }
    else:
        results[name] = {"score": None, "status": f"exit {result.returncode}"}

# Summary table
print(f"\n{'='*60}")
print("ARCHITECTURE COMPARISON")
print(f"{'='*60}")
print(f"{'Architecture':<15} {'Score':<10} {'Status'}")
print(f"{'-'*40}")
for name, r in results.items():
    score = f'{r["score"]:.4f}' if r.get("score") else "N/A"
    print(f"{name:<15} {score:<10} {r['status']}")

Path("arch_comparison.json").write_text(json.dumps(results, indent=2))
print(f"\nResults saved to arch_comparison.json")
```

### Execution

Save the generated script and run it directly:

```bash
python compare_archs.py
```

Each architecture can also be run independently with `spacy train`.

### Decision Guide
- **BOW wins or ties CNN**: Data is simple, use BOW for speed.
- **CNN > BOW by 3%+**: CNN is worth the marginal cost.
- **TRF > CNN by 3%+**: Transformer is worth it if you have GPU in production.
- **TRF ~= CNN**: Use CNN — same accuracy at 10x lower inference cost.

---

## Hyperparameter Sweep

Systematically search for optimal hyperparameters using local grid or random
search with JSONL logging.

### Sweep Script (`sweep.py`):

```python
"""Hyperparameter sweep — logs results to JSONL."""
import subprocess
import json
import sys
import random
from pathlib import Path
from itertools import product

# Define search space
GRID = {
    "learning_rate": [0.0001, 0.0005, 0.001, 0.005],
    "dropout": [0.1, 0.2, 0.3],
    "batch_size": [256, 512, 1000],
}

# For full grid: list(product(*GRID.values()))
# For random search: sample N combinations
MODE = "random"  # "grid" or "random"
N_TRIALS = 12    # for random mode

CODE_FILE = "ellf_logger.py"
GPU_ID = 0

def get_trials():
    if MODE == "grid":
        keys = list(GRID.keys())
        for combo in product(*GRID.values()):
            yield dict(zip(keys, combo))
    else:
        keys = list(GRID.keys())
        for _ in range(N_TRIALS):
            yield {k: random.choice(v) for k, v in GRID.items()}


results = []
for i, params in enumerate(get_trials()):
    trial_id = f"trial-{i:03d}"
    output_dir = Path(f"output/sweep/{trial_id}")
    output_dir.mkdir(parents=True, exist_ok=True)

    cmd = [
        sys.executable, "-m", "spacy", "train", "config.cfg",
        "--output", str(output_dir),
        "--code", CODE_FILE,
        "--gpu-id", str(GPU_ID),
        "--training.optimizer.learn_rate", str(params["learning_rate"]),
        "--training.dropout", str(params["dropout"]),
        "--training.batcher.size", str(params["batch_size"]),
    ]

    print(f"\n{'='*60}")
    print(f"Trial {trial_id}: {params}")
    print(f"{'='*60}")

    result = subprocess.run(cmd, capture_output=False)

    meta_path = output_dir / "model-best" / "meta.json"
    trial_result = {"trial": trial_id, "params": params}
    if meta_path.exists():
        meta = json.loads(meta_path.read_text())
        trial_result["score"] = meta.get("performance", {}).get("score")
        trial_result["status"] = "ok"
    else:
        trial_result["score"] = None
        trial_result["status"] = f"exit {result.returncode}"
    results.append(trial_result)

# Summary
print(f"\n{'='*60}")
print("SWEEP RESULTS")
print(f"{'='*60}")
results_ok = [r for r in results if r["score"] is not None]
results_ok.sort(key=lambda r: r["score"], reverse=True)
for r in results_ok[:10]:
    print(f"  {r['score']:.4f}  {r['params']}")

if results_ok:
    best = results_ok[0]
    print(f"\nBest: {best['score']:.4f} with {best['params']}")

Path("sweep_results.json").write_text(json.dumps(results, indent=2))
print(f"\nResults saved to sweep_results.json")
```

### Execution

Save the generated script and run it directly:

```bash
python sweep.py
```

---

## Results Aggregation

### Multi-Trial Summary

For multiple trials (same config, different seeds):

```
Results: 5 trials
────────────────────────
Mean F-score:  0.8234 ± 0.0089
Range:         0.8102 – 0.8341
Best seed:     3 (0.8341)
```

Report mean ± stddev. If stddev > 0.03, flag high variance and suggest
investigating causes.

### Architecture Comparison Table

```
Architecture Comparison
────────────────────────────────────────
Architecture   Score    Speed      GPU?
bow            0.7891   ~2 min     No
cnn            0.8234   ~8 min     No
trf            0.8456   ~45 min    Yes
────────────────────────────────────────
Recommendation: CNN (best accuracy/cost tradeoff)
```

Include per-component scores if the pipeline has multiple components.
Add a recommendation based on the decision guide above.

### Sweep Best Config

```
Best Configuration (from 12 trials)
────────────────────────────────────
learning_rate: 0.0005
dropout:       0.2
batch_size:    512
Score:         0.8456

Top 3 trials:
  0.8456  lr=0.0005 drop=0.2 batch=512
  0.8423  lr=0.001  drop=0.2 batch=256
  0.8401  lr=0.0005 drop=0.3 batch=512

Parameter importance (by variance contribution):
  learning_rate: HIGH
  dropout:       MEDIUM
  batch_size:    LOW
```

For parameter importance: group results by each parameter value and compare
the variance explained. Parameters where changing the value causes large
score differences are important; parameters with little effect can be left
at default.
