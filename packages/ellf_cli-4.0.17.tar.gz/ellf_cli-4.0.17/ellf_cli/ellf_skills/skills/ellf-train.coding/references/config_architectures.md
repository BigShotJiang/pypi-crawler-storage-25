# Config Patterns: Architectures & Embeddings

Copy-paste config snippets for component architecture and embedding configuration. Each pattern is self-contained — paste the relevant sections into your `config.cfg`.

---

## Table of Contents

- [Baseline Configs](#baseline-configs)
- [Frozen Components](#1-frozen-components)
- [Gradient Accumulation](#2-gradient-accumulation)
- [Shared vs Independent Tok2Vec](#3-shared-vs-independent-tok2vec)
- [Switching Architectures](#4-switching-architectures)

---

## Baseline Configs

Use `spacy init config` to generate a valid starting config. These are the two main starting points.

### CPU / Efficiency baseline

```ini
python -m spacy init config config.cfg --lang en --pipeline ner --optimize efficiency
```

### GPU / Accuracy baseline (transformer)

```ini
python -m spacy init config config.cfg --lang en --pipeline ner --optimize accuracy --gpu
```

---

## 1. Frozen Components

Freeze components to prevent their weights from updating during training. Useful for fine-tuning only specific parts of a pipeline.

### Freeze a single component

```ini
[training]
frozen_components = ["tok2vec"]
```

### Freeze multiple components

```ini
[training]
frozen_components = ["tok2vec", "tagger", "parser"]
```

### Freeze tok2vec but still propagate its embeddings

When tok2vec is frozen, downstream components won't receive updated embeddings unless you add it to `annotating_components`. This tells spaCy to run tok2vec's `set_annotations` on each batch so listeners still get embeddings.

```ini
[training]
frozen_components = ["tok2vec"]
annotating_components = ["tok2vec"]
```

### Freeze transformer, train only task heads

Common pattern for fine-tuning: freeze the expensive transformer and only train the lightweight task-specific layers.

```ini
[training]
frozen_components = ["transformer"]
annotating_components = ["transformer"]
```

### Freeze everything except one component

Train only NER while keeping all other components fixed (e.g., when adding a new entity type to an existing pipeline).

```ini
[training]
frozen_components = ["tok2vec", "tagger", "parser"]
annotating_components = ["tok2vec"]
```

### Fine-tune NER with a frozen tok2vec from an existing model

Source tok2vec from a pretrained model, freeze it, and train only NER.

```ini
[components.tok2vec]
source = "en_core_web_lg"

[components.ner]
factory = "ner"

[training]
frozen_components = ["tok2vec"]
annotating_components = ["tok2vec"]
```

---

## 2. Gradient Accumulation

Subdivide batches to reduce GPU memory usage. An `accumulate_gradient` of 3 means each batch is split into 3 sub-batches, and gradients are accumulated before the optimizer step. The effective batch size stays the same.

### Basic gradient accumulation

```ini
[training]
accumulate_gradient = 3
```

### Transformer training (typical setup)

Transformers are memory-intensive. Use gradient accumulation with a padded batcher to fit training on smaller GPUs.

```ini
[training]
accumulate_gradient = 3

[training.batcher]
@batchers = "spacy.batch_by_padded.v1"
discard_oversize = true
size = 2000
buffer = 256
```

### Large gradient accumulation for very limited GPU memory

```ini
[training]
accumulate_gradient = 8

[training.batcher]
@batchers = "spacy.batch_by_padded.v1"
discard_oversize = true
size = 1000
buffer = 256
```

---

## 3. Shared vs Independent Tok2Vec

### Pattern A: Shared tok2vec (default)

One `tok2vec` component in the pipeline, all other components use listeners. Gradients flow back from all downstream components through the shared embeddings. This is the default and most efficient setup.

```ini
[nlp]
pipeline = ["tok2vec", "ner", "tagger"]

# Shared tok2vec component
[components.tok2vec]
factory = "tok2vec"

[components.tok2vec.model]
@architectures = "spacy.Tok2Vec.v2"

[components.tok2vec.model.embed]
@architectures = "spacy.MultiHashEmbed.v2"
width = ${components.tok2vec.model.encode.width}
attrs = ["NORM", "PREFIX", "SUFFIX", "SHAPE"]
rows = [5000, 1000, 2500, 2500]
include_static_vectors = false

[components.tok2vec.model.encode]
@architectures = "spacy.MaxoutWindowEncoder.v2"
width = 96
depth = 4
window_size = 1
maxout_pieces = 3

# NER uses a listener pointing to the shared tok2vec
[components.ner]
factory = "ner"

[components.ner.model]
@architectures = "spacy.TransitionBasedParser.v2"
state_type = "ner"
extra_state_tokens = false
hidden_width = 64
maxout_pieces = 2
use_upper = true
nO = null

[components.ner.model.tok2vec]
@architectures = "spacy.Tok2VecListener.v1"
width = ${components.tok2vec.model.encode.width}

# Tagger also uses a listener
[components.tagger]
factory = "tagger"

[components.tagger.model]
@architectures = "spacy.Tagger.v2"
nO = null

[components.tagger.model.tok2vec]
@architectures = "spacy.Tok2VecListener.v1"
width = ${components.tok2vec.model.encode.width}
```

### Pattern B: Independent tok2vec per component

Each component has its own embedded tok2vec — no shared component, no listeners. Components train independently. Use this when components need different representations or when you want to train/deploy components independently.

```ini
[nlp]
pipeline = ["ner", "tagger"]
# Note: no "tok2vec" in the pipeline

# NER has its own tok2vec built into the model
[components.ner]
factory = "ner"

[components.ner.model]
@architectures = "spacy.TransitionBasedParser.v2"
state_type = "ner"
extra_state_tokens = false
hidden_width = 64
maxout_pieces = 2
use_upper = true
nO = null

[components.ner.model.tok2vec]
@architectures = "spacy.Tok2Vec.v2"

[components.ner.model.tok2vec.embed]
@architectures = "spacy.MultiHashEmbed.v2"
width = ${components.ner.model.tok2vec.encode.width}
attrs = ["NORM", "PREFIX", "SUFFIX", "SHAPE"]
rows = [5000, 1000, 2500, 2500]
include_static_vectors = false

[components.ner.model.tok2vec.encode]
@architectures = "spacy.MaxoutWindowEncoder.v2"
width = 96
depth = 4
window_size = 1
maxout_pieces = 3

# Tagger has its own separate tok2vec
[components.tagger]
factory = "tagger"

[components.tagger.model]
@architectures = "spacy.Tagger.v2"
nO = null

[components.tagger.model.tok2vec]
@architectures = "spacy.Tok2Vec.v2"

[components.tagger.model.tok2vec.embed]
@architectures = "spacy.MultiHashEmbed.v2"
width = ${components.tagger.model.tok2vec.encode.width}
attrs = ["NORM", "PREFIX", "SUFFIX", "SHAPE"]
rows = [5000, 1000, 2500, 2500]
include_static_vectors = false

[components.tagger.model.tok2vec.encode]
@architectures = "spacy.MaxoutWindowEncoder.v2"
width = 96
depth = 4
window_size = 1
maxout_pieces = 3
```

### Pattern C: Shared transformer

Same as shared tok2vec but with a transformer. Components use `TransformerListener` instead of `Tok2VecListener`.

```ini
[nlp]
pipeline = ["transformer", "ner", "tagger"]
batch_size = 128

[components.transformer]
factory = "transformer"

[components.transformer.model]
@architectures = "spacy-transformers.TransformerModel.v3"
name = "roberta-base"
tokenizer_config = {"use_fast": true}

[components.transformer.model.get_spans]
@span_getters = "spacy-transformers.strided_spans.v1"
window = 128
stride = 96

# NER listens to the transformer
[components.ner]
factory = "ner"

[components.ner.model]
@architectures = "spacy.TransitionBasedParser.v2"
state_type = "ner"
extra_state_tokens = false
hidden_width = 64
maxout_pieces = 2
use_upper = false
nO = null

[components.ner.model.tok2vec]
@architectures = "spacy-transformers.TransformerListener.v1"
grad_factor = 1.0

[components.ner.model.tok2vec.pooling]
@layers = "reduce_mean.v1"

# Tagger also listens to the transformer
[components.tagger]
factory = "tagger"

[components.tagger.model]
@architectures = "spacy.Tagger.v2"
nO = null

[components.tagger.model.tok2vec]
@architectures = "spacy-transformers.TransformerListener.v1"
grad_factor = 1.0

[components.tagger.model.tok2vec.pooling]
@layers = "reduce_mean.v1"
```

### Pattern D: Replace listeners (decouple after training)

After training with a shared tok2vec, replace listeners with standalone copies for independent packaging. Run this after training:

```bash
python -m spacy assemble config.cfg ./output --code custom.py
```

Config for `assemble` that replaces listeners:

```ini
[components.ner]
source = "./model-best"
replace_listeners = ["model.tok2vec"]
```

### Controlling listener gradient flow

Use `grad_factor` on a transformer listener to scale gradient contribution. Set to `0.0` to freeze the transformer for that component, or `1.0` for full gradient flow.

```ini
# NER gets full gradient flow
[components.ner.model.tok2vec]
@architectures = "spacy-transformers.TransformerListener.v1"
grad_factor = 1.0

# Tagger gets half the gradient contribution
[components.tagger.model.tok2vec]
@architectures = "spacy-transformers.TransformerListener.v1"
grad_factor = 0.5
```

---

## 4. Switching Architectures

### Tok2Vec: Efficiency (small CNN)

Fast, low-memory. Good for CPU training and smaller datasets.

```ini
[components.tok2vec.model.embed]
@architectures = "spacy.MultiHashEmbed.v2"
width = ${components.tok2vec.model.encode.width}
attrs = ["NORM", "PREFIX", "SUFFIX", "SHAPE"]
rows = [5000, 1000, 2500, 2500]
include_static_vectors = false

[components.tok2vec.model.encode]
@architectures = "spacy.MaxoutWindowEncoder.v2"
width = 96
depth = 4
window_size = 1
maxout_pieces = 3
```

### Tok2Vec: Accuracy (larger CNN with vectors)

Better accuracy, uses pretrained word vectors.

```ini
[paths]
vectors = "en_core_web_lg"

[components.tok2vec.model.embed]
@architectures = "spacy.MultiHashEmbed.v2"
width = ${components.tok2vec.model.encode.width}
attrs = ["NORM", "PREFIX", "SUFFIX", "SHAPE"]
rows = [5000, 1000, 2500, 2500]
include_static_vectors = true

[components.tok2vec.model.encode]
@architectures = "spacy.MaxoutWindowEncoder.v2"
width = 256
depth = 8
window_size = 1
maxout_pieces = 3

[initialize]
vectors = ${paths.vectors}
```

### Tok2Vec: Character embeddings

Character-level features instead of hash embeddings. Useful for morphologically rich languages or noisy text.

```ini
[components.tok2vec.model.embed]
@architectures = "spacy.CharacterEmbed.v2"
width = 128
rows = 7000
nM = 64
nC = 8
include_static_vectors = false
feature = "LOWER"

[components.tok2vec.model.encode]
@architectures = "spacy.MaxoutWindowEncoder.v2"
width = 128
depth = 4
window_size = 1
maxout_pieces = 3
```

### Tok2Vec: Mish activation (instead of Maxout)

Replace the Maxout encoder with a Mish encoder for a slightly different training dynamic.

```ini
[components.tok2vec.model.encode]
@architectures = "spacy.MishWindowEncoder.v2"
width = 96
depth = 4
window_size = 1
```

### Tok2Vec: BiLSTM encoder

Use a bidirectional LSTM instead of CNN for encoding. Can capture longer-range dependencies.

```ini
[components.tok2vec.model.encode]
@architectures = "spacy.TorchBiLSTMEncoder.v1"
width = 96
depth = 2
dropout = 0.2
```

### TextCat: Bag-of-Words (fast, no tok2vec needed)

Simple and fast text classifier that doesn't need a tok2vec component. Good baseline.

```ini
[components.textcat]
factory = "textcat"

[components.textcat.model]
@architectures = "spacy.TextCatBOW.v3"
exclusive_classes = true
ngram_size = 1
no_output_layer = false
length = 262144
```

### TextCat: CNN

CNN-based classifier, requires tok2vec.

```ini
[components.textcat]
factory = "textcat"

[components.textcat.model]
@architectures = "spacy.TextCatCNN.v2"
exclusive_classes = true
nO = null

[components.textcat.model.tok2vec]
@architectures = "spacy.Tok2VecListener.v1"
width = ${components.tok2vec.model.encode.width}
```

### TextCat: Ensemble (BOW + tok2vec)

Best-of-both-worlds: combines a BOW model with a tok2vec-based model.

```ini
[components.textcat]
factory = "textcat"

[components.textcat.model]
@architectures = "spacy.TextCatEnsemble.v2"
nO = null

[components.textcat.model.tok2vec]
@architectures = "spacy.Tok2VecListener.v1"
width = ${components.tok2vec.model.encode.width}

[components.textcat.model.linear_model]
@architectures = "spacy.TextCatBOW.v3"
exclusive_classes = true
length = 262144
ngram_size = 1
no_output_layer = false
```

### TextCat: Multi-label variant

Use `textcat_multilabel` when documents can belong to multiple categories simultaneously.

```ini
[components.textcat_multilabel]
factory = "textcat_multilabel"

[components.textcat_multilabel.model]
@architectures = "spacy.TextCatEnsemble.v2"
nO = null

[components.textcat_multilabel.model.tok2vec]
@architectures = "spacy.Tok2VecListener.v1"
width = ${components.tok2vec.model.encode.width}

[components.textcat_multilabel.model.linear_model]
@architectures = "spacy.TextCatBOW.v3"
exclusive_classes = false
length = 262144
ngram_size = 1
no_output_layer = false
```

### TextCat: Reduce (pooling-based)

Pools token representations using first/max/mean reduction, then classifies. A generalization of TextCatCNN — query KB for full parameter list.

```ini
[components.textcat]
factory = "textcat"

[components.textcat.model]
@architectures = "spacy.TextCatReduce.v1"
exclusive_classes = true
use_reduce_first = true
use_reduce_last = false
use_reduce_max = false
use_reduce_mean = true
nO = null

[components.textcat.model.tok2vec]
@architectures = "spacy.Tok2VecListener.v1"
width = ${components.tok2vec.model.encode.width}
```

### TextCat: Parametric Attention

Uses parametric attention over tok2vec representations. Focuses on tokens most relevant to classification — query KB for full parameter list.

```ini
[components.textcat]
factory = "textcat"

[components.textcat.model]
@architectures = "spacy.TextCatParametricAttention.v1"
exclusive_classes = true
nO = null

[components.textcat.model.tok2vec]
@architectures = "spacy.Tok2VecListener.v1"
width = ${components.tok2vec.model.encode.width}
```

### NER: Adjust model size

Increase NER capacity for harder tasks by widening the hidden layer.

```ini
[components.ner.model]
@architectures = "spacy.TransitionBasedParser.v2"
state_type = "ner"
extra_state_tokens = false
hidden_width = 128       # default: 64
maxout_pieces = 3        # default: 2
use_upper = true
nO = null
```

### Parser: Adjust model size

```ini
[components.parser.model]
@architectures = "spacy.TransitionBasedParser.v2"
state_type = "parser"
extra_state_tokens = false
hidden_width = 256       # default: 128
maxout_pieces = 3
use_upper = true
nO = null
```
