# spaCy Model Training Troubleshooting Guide

A comprehensive reference for diagnosing and resolving issues during spaCy model training. Organized by failure category with symptoms, causes, and solutions.

---

## Table of Contents

- [Diagnostic Workflow](#diagnostic-workflow)
- [Config Issues](#1-config-issues)
- [Data Issues](#2-data-issues)
- [Component-Specific Issues](#3-component-specific-issues)
  - [Tok2Vec / Transformer](#tok2vec--transformer)
  - [NER (EntityRecognizer)](#ner-entityrecognizer)
  - [Dependency Parser](#dependency-parser)
  - [Tagger](#tagger)
  - [Morphologizer](#morphologizer)
  - [TextCategorizer](#textcategorizer)
  - [SpanCategorizer](#spancategorizer)
  - [SpanFinder](#spanfinder)
  - [EntityLinker](#entitylinker)
  - [EditTreeLemmatizer](#edittreelemmatizer)
  - [SentenceRecognizer](#sentencerecognizer)
- [Training Loop Issues](#4-training-loop-issues)
- [Evaluation and Scoring Issues](#5-evaluation-and-scoring-issues)
- [Performance Issues](#6-performance-issues)
- [Debug Commands Reference](#7-debug-commands-reference)

---

## Diagnostic Workflow

Before diving into specific issues, run these commands in order:

```bash
# 1. Validate config syntax, schemas, and registered functions
python -m spacy debug config config.cfg

# 2. Inspect all config variables and their resolved values
python -m spacy debug config config.cfg --show-variables --show-functions

# 3. Validate training and dev data against the pipeline
python -m spacy debug data config.cfg

# 4. Inspect a specific component's model architecture
python -m spacy debug model config.cfg <component_name>

# 5. Train with verbose output
python -m spacy train config.cfg -o ./output -V
```

---

## 1. Config Issues

### 1.1 Config fails to load

**Symptom:** Error on `spacy train` or `spacy debug config` before training starts.

| Scenario | Error | Cause | Solution |
|----------|-------|-------|----------|
| Invalid INI syntax | `ConfigurationError` | Malformed `.cfg` file (missing brackets, bad indentation) | Use `spacy init config` to generate a valid base config, then modify |
| Unregistered function | `RegistryError: Can't find '...' in registry` | A `@function_name` in the config references a function not in spaCy's registry | Check spelling; ensure custom functions are registered with `@spacy.registry.<name>` and imported before training |
| Missing required field | `E1015` | `seed` or `gpu_allocator` missing from `[training]` | Add `seed = 0` and `gpu_allocator = null` to `[training]` block |
| Variable not defined | `InterpolationError` | Config uses `${section.key}` but the referenced value doesn't exist | Run `spacy debug config --show-variables` to see all variables; fix references |

### 1.2 Corpus path errors

| Scenario | Error | Cause | Solution |
|----------|-------|-------|----------|
| Corpus path is None | `E913` | `[training.train_corpus]` or `[training.dev_corpus]` not defined | Set `train_corpus = "corpora.train"` and define `[corpora.train]` with a valid `@readers` entry |
| Corpus resolves to object | `E897` | Corpus field resolves to a function object instead of a dot-notation string | Ensure corpus fields are strings like `"corpora.train"`, not inline function definitions |
| No corpus files found | `W090` | Path in corpus reader doesn't match any files | Check the `path` parameter in your `[corpora.train]` and verify `.spacy` files exist there |

### 1.3 Component config errors

| Scenario | Error | Cause | Solution |
|----------|-------|-------|----------|
| Unknown pipeline component | `RegistryError` | Component name in `[components.X]` doesn't have a registered factory | Check `spacy.pipeline` for valid factory names; register custom components with `@Language.component` or `@Language.factory` |
| Incompatible model architecture | `DimensionError` | Model dimensions don't match between layers (e.g., tok2vec output != component input) | Run `spacy debug model config.cfg <component>` to inspect dimensions at each layer |
| Sourced component version mismatch | `W113` | Vectors changed when sourcing a component from another model | Ensure the source model's vectors match your current pipeline's vectors |

### 1.4 Listener / shared embedding issues

| Scenario | Warning/Error | Cause | Solution |
|----------|---------------|-------|----------|
| Frozen listener, unfrozen dependent | `W086` | A tok2vec/transformer is frozen but a component using its listener is being trained | Either freeze both, or add the frozen component to `[training.annotating_components]` so it still sets annotations |
| Unfrozen listener, frozen dependent | `W087` | A tok2vec/transformer is unfrozen but its downstream component is frozen | Freeze both or unfreeze both; use `replace_listeners` to decouple if needed |
| No upstream predictions | `E954` | Listener component tried to get embeddings but tok2vec hasn't run yet | Check pipeline order: tok2vec/transformer must appear before components that listen to it |
| Batch ID mismatch | `E953` | Listener received predictions from a different batch than expected | Internal error — usually caused by modifying the pipeline between predict and update |

---

## 2. Data Issues

### 2.1 Data format and loading

| Scenario | Error | Cause | Solution |
|----------|-------|-------|----------|
| Invalid Example type | `E978` | Training data is not `Iterable[Example]` | Ensure your corpus reader returns `Example` objects, not raw `Doc` or `dict` |
| None in Example | `E972` | `Example(None, None)` — predicted or reference Doc is None | Check your data pipeline; both the predicted and reference Doc must be non-None |
| Empty training set | `E923` | No examples provided during `initialize()` | Verify your corpus files contain data. Run `python -m spacy debug data config.cfg` |
| No training batches | `E986` | Corpus exists but batcher produced zero batches | Check `max_length` setting — it may filter out all documents. Check `limit` parameter |

### 2.2 Annotation quality

| Scenario | Symptom | Cause | Solution |
|----------|---------|-------|----------|
| Whitespace entities | `debug data` error | Entity spans have leading/trailing whitespace | Clean entity offsets so they don't start/end on whitespace |
| Entity spans cross sentence boundaries | `debug data` warning | An entity annotation spans two or more sentences | Fix sentence boundaries or split the entity |
| Empty entity labels | `debug data` error | Entity with empty string as label | Ensure all entities have a non-empty label |
| Non-binary textcat values | `E851` | Category values are not exactly `0.0` or `1.0` | Convert categories to binary: `1.0` (positive) or `0.0` (negative) |
| Multiple exclusive labels | `E895` | Single-label textcat example has more than one `1.0` category | For exclusive (single-label) textcat, exactly one label should be `1.0` per example |

### 2.3 Data volume thresholds

These thresholds are checked by `spacy debug data`:

| Check | Threshold | Severity | Meaning |
|-------|-----------|----------|---------|
| Total training examples (new pipeline) | < 100 | Error | Too few examples to train from scratch |
| Total training examples (new pipeline) | < 2000 | Warning | May be insufficient for good performance |
| NER examples per label | < 50 | Warning | Label may not have enough examples to learn reliably |
| Dep labels per type | < 20 | Warning | Dependency label underrepresented |
| TextCat labels | < 2 | Error (`E867`) | Need at least 2 labels for classification |
| Missing negative examples | 0 for a label | Warning | No examples without the label — model can't learn what the label is *not* |

### 2.4 Tokenization and alignment

| Scenario | Symptom | Cause | Solution |
|----------|---------|-------|----------|
| Gold/predicted token mismatch | Low scores despite good data | Tokenizer produces different tokens than gold annotations | Use `gold_preproc=True` in corpus reader for training, but be aware of train/test skew |
| Character offset misalignment | Entity spans don't match tokens | Entity character offsets fall in the middle of a token | Align entity boundaries to token boundaries; use `spacy.training.offsets_to_biluo_tags` to diagnose |
| Retokenization breaks alignment | Alignment errors during training | A pipeline component retokenizes the Doc (e.g., merge_entities) | Ensure retokenization rules are consistent between training and inference |

### 2.5 Train/dev data overlap

| Scenario | Symptom | Cause | Solution |
|----------|---------|-------|----------|
| Duplicate texts in train and dev | `debug data` warning, inflated dev scores | Same documents appear in both sets | Deduplicate; use distinct splits |
| Label distribution mismatch | Poor generalization despite good dev scores | Dev set has different label distribution than train | Stratify splits to ensure proportional label representation |

---

## 3. Component-Specific Issues

### Tok2Vec / Transformer

Tok2Vec is a shared embedding layer — it doesn't predict anything directly but provides representations to downstream components.

| Scenario | Error | Cause | Solution |
|----------|-------|-------|----------|
| Empty tensor | `E203` | Tok2Vec is frozen or wasn't updated, but a downstream component needs its output | Add tok2vec to `[training.annotating_components]` if frozen |
| No listeners found | Training runs but tok2vec loss is always 0 | No downstream component is using a `Tok2VecListener` | Ensure at least one component in the pipeline has a `tok2vec` listener layer connected |
| Transformer OOM | CUDA out of memory | Transformer model too large for GPU | Reduce `max_length` in corpus reader; increase `accumulate_gradient`; use a smaller transformer |
| Slow training with transformer | Training is extremely slow | Large transformer model updating on every batch | Freeze the transformer and use `annotating_components` once performance plateaus |

### NER (EntityRecognizer)

Uses a transition-based parser with BILUO tagging internally.

| Scenario | Error | Cause | Solution |
|----------|-------|-------|----------|
| No transition moves | `E924` | No labels added during initialization | Ensure training data contains entity annotations; check that `initialize()` is called |
| NaN loss | `E910` | Numerical instability, often from bad alignments or extreme label imbalance | Reduce learning rate; check for misaligned entities; add more diverse examples |
| Low recall for rare entities | Poor F-score for specific types | Too few examples of the entity type (< 50) | Add more examples; consider using patterns as pretraining (via `SpanRuler` + training) |
| Entities overlap | Predictions overlap at inference | NER doesn't support overlapping entities by design | Use SpanCategorizer for overlapping spans |
| Long sequences degrade | Quality drops on long documents | `update_with_oracle_cut_size` (default 100) segments training | Increase `update_with_oracle_cut_size` if needed; or split long documents in preprocessing |
| Catastrophic forgetting on update | Existing entity types degraded after training new ones | Fine-tuning on partial annotations overwrites previous knowledge | Use `rehearsal()` to mix in old examples; use `nlp.resume_training()` instead of fresh init |

### Dependency Parser

Transition-based parser using arc-eager transitions.

| Scenario | Error | Cause | Solution |
|----------|-------|-------|----------|
| No transition moves | `E924` | No dependency labels in training data | Verify data contains `dep_` and `head` annotations |
| Non-projective trees | `debug data` warning | Training data has crossing dependency arcs | spaCy automatically projectivizes; verify projectivized labels are expected |
| Cyclic dependencies | `debug data` error | Gold parse contains cycles (e.g., A depends on B, B depends on A) | Fix annotation data — dependency trees must be acyclic |
| Low UAS/LAS scores | Poor parsing accuracy | Insufficient data, too many rare labels, or long sentences | Increase data; ensure at least 20 examples per dep label; split long sentences |
| Multiple ROOT labels | `debug data` warning | Sentences with more than one root token | Fix annotations — each sentence should have exactly one ROOT |

### Tagger

Token-level classification for POS tags or other tag schemes.

| Scenario | Error | Cause | Solution |
|----------|-------|-------|----------|
| Non-unicode label | `E187` | Label is not a string (e.g., integer or bytes) | Convert all labels to Python `str` |
| NaN in tag scores | `E940` | Model produces NaN before loss computation | Check model initialization; reduce learning rate; verify input data is clean |
| NaN loss | `E910` | Loss computation returns NaN | Same as above — also check for empty batches |
| No labels found | `E143` | No tag annotations in training data | Ensure `.tag_` is set on reference tokens in your training data |
| Tags not applied | Predicted docs have empty `.tag_` | `overwrite` parameter is False and tags were pre-set | Set `overwrite = true` in the component config |

### Morphologizer

Predicts both POS and morphological features as a combined label.

| Scenario | Error | Cause | Solution |
|----------|-------|-------|----------|
| Missing POS or morph annotations | `E143` / low scores | Training data has POS but not morph (or vice versa) | Provide both `.pos_` and `.morph` annotations in training data |
| Label explosion | Very slow training, high memory | Too many unique POS+morph combinations | Check annotation consistency; reduce morphological feature granularity if possible |
| NaN loss | `E910` | Same as Tagger | See Tagger troubleshooting |
| Morph not applied in extend mode | Features missing at inference | `extend` mode merges, but existing features take precedence | Use `overwrite = true` to replace all features |

### TextCategorizer

Document-level classification (single-label or multi-label variants).

| Scenario | Error | Cause | Solution |
|----------|-------|-------|----------|
| Non-binary category values | `E851` | Category values are not `0.0` or `1.0` | Convert probabilities or scores to binary values |
| Multiple exclusive labels set | `E895` | Single-label textcat has >1 label as `1.0` | For `textcat` (exclusive), exactly one label should be `1.0` per example |
| Fewer than 2 labels | `E867` | Only 0 or 1 unique labels found during `initialize()` | Provide examples with at least 2 distinct category labels |
| Invalid positive_label | `E919` / `E920` | `positive_label` not in labels, or set for multi-label | For binary classification, `positive_label` must be one of the labels; don't set it for multi-label |
| Label mismatch between train/dev | Low dev scores | Dev set has labels not seen in training | Ensure train and dev have the same label set |
| Using wrong variant | Unexpected behavior | Using `textcat` (exclusive) when labels aren't mutually exclusive | Use `textcat_multilabel` for non-exclusive multi-label classification |

### SpanCategorizer

Classifies candidate spans — supports overlapping spans.

| Scenario | Error | Cause | Solution |
|----------|-------|-------|----------|
| Suggester doesn't cover gold spans | Low recall despite good data | N-gram suggester's max length is shorter than gold spans | Increase `max_size` in `spacy.ngram_suggester.v1`; or use a custom suggester |
| Missing spans_key in data | No spans found during init | Training data doesn't have `.spans[spans_key]` set | Ensure gold spans are stored in the correct key (default: `"sc"`) |
| Empty span suggestions | No predictions generated | Suggester returns empty candidates for documents | Check suggester configuration; verify documents have tokens |
| Low distinctiveness | `debug data` warning | Span boundaries are not distinctive (hard for the model to learn) | Add more diverse examples; consider a different span representation |

### SpanFinder

Learns to detect span boundaries (start/end tokens) without labels.

| Scenario | Error | Cause | Solution |
|----------|-------|-------|----------|
| Invalid min/max length | `E1053` | `min_length` or `max_length` set to < 1 | Set both to >= 1 |
| Low precision | Many false positive spans | Threshold too low | Increase the `threshold` parameter to require higher confidence |
| Missing spans in reference | No training signal | Gold data lacks `.spans[spans_key]` annotations | Ensure reference docs have spans set with the configured key |

### EntityLinker

Links recognized entities to entries in a knowledge base (KB).

| Scenario | Error | Cause | Solution |
|----------|-------|-------|----------|
| KB not initialized | `E1018` | Knowledge base is empty or None | Provide a populated `KnowledgeBase` during initialization |
| Empty KB | `E139` | KB has no entities | Add entities with embeddings to the KB before training |
| Invalid threshold | `E1043` | Threshold not in [0.0, 1.0] | Set threshold to a value between 0 and 1 |
| Invalid batch size | `E1044` | `candidates_batch_size` < 1 | Set to >= 1 |
| Missing entity annotations | Low linking accuracy | Training data doesn't have entities annotated for linking | Set `use_gold_ents = true` in config; ensure gold entities are annotated with KB IDs |
| Labels_discard misconfigured | NIL predictions for valid entities | NER labels in `labels_discard` are being skipped | Remove labels you want linked from the `labels_discard` list |

### EditTreeLemmatizer

Predicts lemmas by learning character-level edit operations (edit trees).

| Scenario | Error | Cause | Solution |
|----------|-------|-------|----------|
| NaN loss | `E910` | Numerical instability | Reduce learning rate; check for empty lemma annotations |
| Entry not found | `E857` | Prediction refers to an edit tree not in the model's label set | Increase `top_k` to try more edit tree candidates; increase `min_tree_freq` to prune rare trees |
| Low lemmatization accuracy | Poor results | `min_tree_freq` too high, pruning useful trees | Lower `min_tree_freq` (default: 3); try `top_k > 1` |
| Missing lemma annotations | No training signal | Reference tokens lack `.lemma_` | Annotate lemmas in training data |
| Backoff behavior | All tokens get surface form as lemma | No edit tree applies and `backoff = "orth"` | Check if training data is sufficient; lower `min_tree_freq` |

### SentenceRecognizer

Token-level binary classification for sentence boundaries.

| Scenario | Error | Cause | Solution |
|----------|-------|-------|----------|
| NaN loss | `E910` | Same as Tagger (inherits from Tagger) | Reduce learning rate; verify sentence boundary annotations |
| No sentence boundaries in data | No training signal | Reference docs don't have `.is_sent_start` set | Ensure sentence boundaries are annotated in training data |
| Conflicts with parser | Sentence boundaries differ from parser output | Both `parser` and `senter` set sentence boundaries | Use only one of parser or senter; set `overwrite = false` on the one you want to defer |

---

## 4. Training Loop Issues

### 4.1 NaN loss (general)

**Error:** `E910` — `"Losses are not valid: {name} loss is NaN"`

| Cause | Diagnosis | Solution |
|-------|-----------|----------|
| Learning rate too high | Loss spikes then becomes NaN | Reduce `learning_rate` in `[training.optimizer]` (try halving it) |
| Exploding gradients | Loss increases rapidly before NaN | Add gradient clipping: `grad_clip = 1.0` in optimizer config |
| Bad data alignment | Some examples have misaligned annotations | Run `spacy debug data` to check for alignment issues |
| Empty batches | Batch contains no tokens | Check `max_length` and batcher settings |
| Extreme label imbalance | One label dominates heavily | Balance your training data; add more examples of minority labels |
| Division by zero in loss | Component-specific edge case | Check for empty annotation fields in training data |

### 4.2 Training doesn't start

| Scenario | Error | Cause | Solution |
|----------|-------|-------|----------|
| Failed to create output dir | `E901` | Output directory exists and can't be removed | Delete or rename existing output directory |
| Component not initialized | `E109` | `initialize()` wasn't called | This usually means the config is misconfigured — check component factory settings |
| No labels | `E143` | Component found zero labels during init | Verify training data contains annotations for the component |
| Zero moves in parser | `E924` | Parser/NER has no transition actions | Ensure training data contains dependency/entity annotations |

### 4.3 Training stalls or is too slow

| Scenario | Cause | Solution |
|----------|-------|----------|
| Training loop runs but loss doesn't decrease | Learning rate too low, or model capacity too small | Increase learning rate; use a larger model architecture |
| Training is very slow per step | Large model (transformer), large batch size, or no GPU | Use `accumulate_gradient` to reduce memory; use GPU; reduce batch size |
| Memory keeps growing | No garbage collection on large docs | Set `max_length` in corpus reader to split long documents |
| Evaluation is slow | Large dev set evaluated every `eval_frequency` steps | Increase `eval_frequency`; reduce dev set size |

### 4.4 Early stopping and patience

| Scenario | Cause | Solution |
|----------|-------|----------|
| Training stops too early | `patience` value too low | Increase `patience` in `[training]` (number of steps without improvement) |
| Training never stops | `patience = 0` (disabled) and `max_steps = 0` (disabled) | Set either `patience` or `max_steps` to a positive value |
| Best model checkpoint is very early | Model overfits quickly | Add dropout; use data augmentation; add more training data |

### 4.5 Gradient accumulation

| Scenario | Cause | Solution |
|----------|-------|----------|
| OOM with large batches | Batch too large for GPU memory | Set `accumulate_gradient > 1` (e.g., 3) to subdivide batches |
| Training is noisy with accumulation | Effective batch size too small after subdivision | Increase base batch size so each subbatch is still meaningful |

---

## 5. Evaluation and Scoring Issues

### 5.1 Score weight problems

| Scenario | Error | Cause | Solution |
|----------|-------|-------|----------|
| Score not a number | `E915` | A metric in `score_weights` returns a dict or None | Check `score_weights` keys match actual numeric metrics |
| Score type invalid | `E916` | Logger can't format the score value | Same as above — ensure only numeric scores are in `score_weights` |
| Weighted score is always 0 | Wrong metric names | `score_weights` keys don't match any returned metrics | Run `spacy evaluate` to see actual metric names; update `score_weights` |

### 5.2 Evaluation discrepancies

| Scenario | Cause | Solution |
|----------|-------|----------|
| Train loss low, dev score low | Overfitting | Add dropout; add data augmentation; collect more data; use early stopping |
| Train loss high, dev score low | Underfitting | Increase model capacity; increase learning rate; train longer |
| Dev score fluctuates wildly | Small dev set or noisy data | Use a larger dev set; clean annotation noise |
| Eval scores don't match manual inspection | Tokenization mismatch between train and eval | Ensure consistent tokenization; check `gold_preproc` setting |

---

## 6. Performance Issues

### 6.1 Low NER scores

| Possible Cause | Diagnosis | Solution |
|----------------|-----------|----------|
| Insufficient data | `debug data` shows < 50 per label | Add more annotated examples, aim for 200+ per label |
| Inconsistent annotations | Same text annotated differently in multiple places | Audit annotations for consistency; use inter-annotator agreement metrics |
| Entity boundaries wrong | Entities include leading/trailing whitespace or punctuation | Clean entity offsets |
| Missing negative examples | `debug data` warns about no negatives | Add examples that contain entity-like text but are NOT entities |
| Label scheme too fine-grained | Many labels with few examples each | Consolidate similar labels; train hierarchically |

### 6.2 Low parser scores

| Possible Cause | Diagnosis | Solution |
|----------------|-----------|----------|
| Non-projective trees | `debug data` shows non-projective count | spaCy auto-projectivizes, but verify this is acceptable for your language |
| Too many rare dep labels | Labels with < 20 examples | Merge rare labels or add more data |
| Long sentences | Parser struggles with very long sentences | Split long sentences in preprocessing |

### 6.3 Low textcat scores

| Possible Cause | Diagnosis | Solution |
|----------------|-----------|----------|
| Class imbalance | One class dominates | Balance your training data; or accept lower minority-class performance |
| Wrong variant | Using `textcat` for multi-label, or `textcat_multilabel` for exclusive | Match the component to your task |
| Texts too short/long | Model struggles with extreme lengths | Add a `min_length`/`max_length` filter in the corpus reader |

### 6.4 Catastrophic forgetting (fine-tuning)

| Scenario | Cause | Solution |
|----------|-------|----------|
| Existing component performance drops when adding new labels | Fine-tuning overwrites learned weights | Use `rehearse()` method with old examples mixed in |
| Base model knowledge lost | Full fine-tuning on small domain-specific data | Freeze tok2vec/transformer and only train task heads; use smaller learning rate |
| Pipeline interaction effects | New component changes tokenization or other annotations | Check pipeline order; use `annotating_components` to control annotation flow |

---

## 7. Debug Commands Reference

### `spacy debug config`

```bash
# Basic config validation (3-stage: syntax, init schema, training schema)
python -m spacy debug config config.cfg

# Show all interpolated variables
python -m spacy debug config config.cfg --show-variables

# Show all registered functions and their source locations
python -m spacy debug config config.cfg --show-functions

# Validate with overrides
python -m spacy debug config config.cfg --paths.train ./train.spacy
```

### `spacy debug data`

```bash
# Full data validation
python -m spacy debug data config.cfg

# With verbose output (per-label statistics)
python -m spacy debug data config.cfg -V
```

**What it checks:**
- Training/dev data loading and size
- Train/dev overlap
- Vocabulary and vector coverage
- Per-component annotation validation:
  - NER: label counts, whitespace entities, boundary crossing, negative examples
  - Parser: dep label counts, non-projective trees, cycles, root labels, sentence counts
  - Tagger/Morphologizer: label sets, missing annotations
  - TextCat: label counts, binary values, exclusive constraints, train/dev label consistency
  - SpanCat: span distinctiveness, boundary distinctiveness, length distributions
  - Lemmatizer: tree coverage, low-cardinality lemmas

### `spacy debug model`

```bash
# Full 4-step model analysis
python -m spacy debug model config.cfg ner

# Show dimensions at each layer
python -m spacy debug model config.cfg ner -DIM

# Show parameters
python -m spacy debug model config.cfg ner -PAR

# Show gradients during training
python -m spacy debug model config.cfg ner -GRAD

# Show all diagnostics
python -m spacy debug model config.cfg ner -DIM -PAR -GRAD -ATTR
```

**4-step analysis:**
1. **Step 0 — Before training:** Model architecture and layer structure
2. **Step 1 — After initialization:** Resolved dimensions and parameter shapes
3. **Step 2 — After training (3 epochs):** Gradient flow and parameter updates
4. **Step 3 — Final predictions:** Output dimensions and prediction sanity

### `spacy evaluate`

```bash
# Evaluate a trained model
python -m spacy evaluate ./model-best ./dev.spacy

# Output metrics as JSON
python -m spacy evaluate ./model-best ./dev.spacy -o metrics.json

# Render dependency parses as HTML
python -m spacy evaluate ./model-best ./dev.spacy -dp ./displacy_output
```

---

## Quick Error Code Reference

| Code | Message Summary | Likely Fix |
|------|----------------|------------|
| `E109` | Component not initialized | Call `nlp.initialize()` with training data |
| `E139` | Empty knowledge base | Populate KB with entities before training |
| `E143` | No labels found | Ensure training data has annotations for the component |
| `E187` | Non-unicode label | Convert labels to Python `str` |
| `E203` | Empty tensor (tok2vec) | Unfreeze tok2vec or add to `annotating_components` |
| `E851` | Non-binary textcat value | Use only `0.0` and `1.0` for category values |
| `E867` | Fewer than 2 textcat labels | Provide at least 2 distinct category labels |
| `E895` | Multiple exclusive labels set to 1.0 | For single-label textcat, only one label should be `1.0` |
| `E897` | Corpus field not a dot-notation string | Fix corpus references in config |
| `E901` | Can't remove output directory | Delete existing output directory manually |
| `E910` | NaN loss | Reduce learning rate; check data quality; check alignment |
| `E913` | Corpus path is None | Define corpus path in config |
| `E919` | Invalid positive_label (not in labels) | Set `positive_label` to one of the defined labels |
| `E920` | positive_label set for non-binary task | Remove `positive_label` for multi-label textcat |
| `E923` | No training data for init | Provide data via `get_examples` |
| `E924` | Zero transition moves | Verify dep/entity annotations exist in training data |
| `E940` | NaN in tag scores | Check model init; reduce learning rate |
| `E953` | Batch ID mismatch (listener) | Internal error — check pipeline order and custom components |
| `E954` | No tok2vec prediction available | Ensure tok2vec runs before dependent components |
| `E978` | Invalid Example type | Ensure data returns `Iterable[Example]` objects |
| `E986` | No training batches | Check corpus path and batcher config |
| `E1015` | Missing seed/gpu_allocator | Add to `[training]` block |
| `E1018` | KB not initialized | Create and populate knowledge base |
| `E1043` | Invalid threshold (entity linker) | Set threshold between 0.0 and 1.0 |
| `E1053` | Invalid span min/max length | Set both to >= 1 |
