# Config Patterns: Advanced & Reference

Copy-paste config snippets for pretraining, sourcing components, loggers, spancat suggesters, score weights, and callbacks. Includes a quick-reference table of all registered names.

---

## Table of Contents

- [Pretraining](#11-pretraining)
- [Sourcing Components from Existing Models](#12-sourcing-components-from-existing-models)
- [Loggers](#13-loggers)
- [SpanCat Suggesters](#14-spancat-suggesters)
- [Score Weights](#15-score-weights)
- [Callbacks](#16-callbacks)
- [Quick Reference: All Registered Names](#quick-reference-all-registered-names)

---

## 11. Pretraining

Pretrain tok2vec embeddings on raw text before supervised training. Improves performance when labeled data is limited.

### Character-based pretraining objective (default)

```ini
[paths]
raw_text = ./raw_text.jsonl

[pretraining]
max_epochs = 1000
dropout = 0.2
n_save_every = null
n_save_epoch = null
component = "tok2vec"
layer = ""
corpus = "corpora.pretrain"

[pretraining.batcher]
@batchers = "spacy.batch_by_words.v1"
size = 3000
discard_oversize = false
tolerance = 0.2

[pretraining.objective]
@architectures = "spacy.PretrainCharacters.v1"
maxout_pieces = 3
hidden_size = 300
n_characters = 4

[pretraining.optimizer]
@optimizers = "Adam.v1"
beta1 = 0.9
beta2 = 0.999
L2_is_weight_decay = true
L2 = 0.01
grad_clip = 1.0
use_averages = true
eps = 1e-8
learn_rate = 0.001

[corpora.pretrain]
@readers = "spacy.JsonlCorpus.v1"
path = ${paths.raw_text}
min_length = 5
max_length = 500
limit = 0
```

### Vector-based pretraining objective

Predict static vectors instead of characters. Requires pretrained word vectors.

```ini
[pretraining.objective]
@architectures = "spacy.PretrainVectors.v1"
maxout_pieces = 3
hidden_size = 300
loss = "cosine"           # "cosine" or "L2"
```

### Load pretrained weights into training

After running `spacy pretrain`, point training config to the pretrained weights.

```ini
[paths]
init_tok2vec = ./pretrain/model-last.bin

[initialize]
init_tok2vec = ${paths.init_tok2vec}
```

---

## 12. Sourcing Components from Existing Models

### Source a component from an existing model

Load a pretrained component from an installed spaCy model.

```ini
[components.ner]
source = "en_core_web_lg"
```

### Source with component renaming

```ini
[components.my_custom_ner]
source = "en_core_web_lg"
component = "ner"
```

### Source and replace listeners

When sourcing a component that uses a listener (e.g., tok2vec), replace the listener with a standalone copy so it doesn't depend on the original tok2vec.

```ini
[components.ner]
source = "en_core_web_lg"
replace_listeners = ["model.tok2vec"]
```

### Source tok2vec, freeze it, train NER from scratch

```ini
[nlp]
pipeline = ["tok2vec", "ner"]

[components.tok2vec]
source = "en_core_web_lg"

[components.ner]
factory = "ner"

[components.ner.model]
@architectures = "spacy.TransitionBasedParser.v2"
state_type = "ner"
extra_state_tokens = false
hidden_width = 64
maxout_pieces = 2
use_upper = true
nO = null

[components.ner.model.tok2vec]
@architectures = "spacy.Tok2VecListener.v1"
width = ${components.tok2vec.model.encode.width}

[training]
frozen_components = ["tok2vec"]
annotating_components = ["tok2vec"]
```

---

## 13. Loggers

### Console logger (default)

```ini
[training.logger]
@loggers = "spacy.ConsoleLogger.v1"
```

### Console logger v3 with progress bar and file output

```ini
[training.logger]
@loggers = "spacy.ConsoleLogger.v3"
progress_bar = "eval"            # "eval" or "train"
console_output = true
output_file = "./training.jsonl"
```

### Console logger with training progress bar

Shows total progress toward `max_steps` instead of per-evaluation progress.

```ini
[training.logger]
@loggers = "spacy.ConsoleLogger.v3"
progress_bar = "train"
console_output = true
output_file = null
```

### Ellf monitor (recommended — with anomaly detection)

Copy `ellf_logger.py` to the working directory and use:

```ini
[training.logger]
@loggers = "ellf_monitor.v2"
log_path = "training_log.jsonl"
```

---

## 14. SpanCat Suggesters

### N-gram suggester (default)

Suggests all spans of the given lengths. Good general-purpose starting point.

```ini
[components.spancat.suggester]
@misc = "spacy.ngram_suggester.v1"
sizes = [1, 2, 3]
```

### N-gram range suggester

Suggests all spans between `min_size` and `max_size` (inclusive). More convenient than listing individual sizes.

```ini
[components.spancat.suggester]
@misc = "spacy.ngram_range_suggester.v1"
min_size = 1
max_size = 5
```

### Longer span suggestions

For tasks with longer entities (addresses, legal clauses, etc.).

```ini
[components.spancat.suggester]
@misc = "spacy.ngram_range_suggester.v1"
min_size = 1
max_size = 10
```

### Preset spans suggester (from upstream component)

Use spans that are already set on the Doc (e.g., by a SpanRuler or SpanFinder). Only classify pre-identified spans rather than suggesting candidates.

```ini
[components.spancat.suggester]
@misc = "spacy.preset_spans_suggester.v1"
spans_key = "candidates"
```

### SpanFinder + SpanCat pipeline

Use SpanFinder to identify span boundaries, then SpanCat to classify them.

```ini
[nlp]
pipeline = ["tok2vec", "span_finder", "spancat"]

[components.span_finder]
factory = "span_finder"
max_length = 25
min_length = null
spans_key = "sc"
threshold = 0.5

[components.span_finder.model]
@architectures = "spacy.SpanFinder.v1"

[components.span_finder.model.scorer]
@layers = "spacy.LinearLogistic.v1"
nO = 2

[components.span_finder.model.tok2vec]
@architectures = "spacy.Tok2VecListener.v1"
width = ${components.tok2vec.model.encode.width}

[components.spancat]
factory = "spancat"
spans_key = "sc"
threshold = 0.5

[components.spancat.model]
@architectures = "spacy.SpanCategorizer.v1"

[components.spancat.model.reducer]
@layers = "spacy.mean_max_reducer.v1"
hidden_size = 128

[components.spancat.model.scorer]
@layers = "spacy.LinearLogistic.v1"
nO = null
nI = null

[components.spancat.model.tok2vec]
@architectures = "spacy.Tok2VecListener.v1"
width = ${components.tok2vec.model.encode.width}

[components.spancat.suggester]
@misc = "spacy.preset_spans_suggester.v1"
spans_key = "sc"
```

---

## 15. Score Weights

Control which metrics determine the "best" model checkpoint. Weights should sum to 1.0. Set a metric to `null` to log it without contributing to the final score. Set to `0.0` to suppress logging entirely.

### NER only

```ini
[training.score_weights]
ents_f = 1.0
ents_p = 0.0
ents_r = 0.0
```

### NER + Tagger

```ini
[training.score_weights]
tag_acc = 0.3
ents_f = 0.7
ents_p = 0.0
ents_r = 0.0
```

### Full pipeline (tagger + parser + NER)

```ini
[training.score_weights]
tag_acc = 0.33
dep_uas = 0.17
dep_las = 0.17
ents_f = 0.33
```

### Text classification only

```ini
# Single-label
[training.score_weights]
cats_score = 1.0

# Multi-label
[training.score_weights]
cats_macro_f = 0.5
cats_macro_auc = 0.5
```

### SpanCat only

```ini
[training.score_weights]
spans_sc_f = 1.0
spans_sc_p = 0.0
spans_sc_r = 0.0
```

### Log metrics without affecting checkpoint selection

Set weight to `null` to include in logs but not in the weighted score.

```ini
[training.score_weights]
ents_f = 1.0
ents_p = null
ents_r = null
```

---

## 16. Callbacks

### before_update: Custom logic each training step

```ini
[training]
before_update = {"@callbacks": "my_custom_callbacks.log_batch_stats.v1"}
```

### before_to_disk: Modify pipeline before saving

Useful for removing temporary components or cleaning up before saving checkpoints.

```ini
[training]
before_to_disk = {"@callbacks": "my_custom_callbacks.remove_debug_data.v1"}
```

### before_init / after_init: Modify nlp during initialization

```ini
[initialize]
before_init = {"@callbacks": "my_custom_callbacks.setup_vocab.v1"}
after_init = {"@callbacks": "my_custom_callbacks.validate_pipeline.v1"}
```

### before_creation / after_creation: Modify Language class or nlp instance

```ini
[nlp]
before_creation = null
after_creation = {"@callbacks": "my_custom_callbacks.add_custom_tokenizer_rules.v1"}
after_pipeline_creation = null
```

---

## Quick Reference: All Registered Names

### Architectures

| Registry Name | Use |
|---------------|-----|
| `spacy.Tok2Vec.v2` | Tok2Vec wrapper (embed + encode) |
| `spacy.MultiHashEmbed.v2` | Hash embedding layer |
| `spacy.CharacterEmbed.v2` | Character embedding layer |
| `spacy.MaxoutWindowEncoder.v2` | CNN encoder with maxout |
| `spacy.MishWindowEncoder.v2` | CNN encoder with mish activation |
| `spacy.TorchBiLSTMEncoder.v1` | BiLSTM encoder |
| `spacy.Tok2VecListener.v1` | Listener for shared tok2vec |
| `spacy.Tagger.v2` | Token classification model |
| `spacy.TransitionBasedParser.v2` | Parser/NER transition model |
| `spacy.SpanCategorizer.v1` | Span classification model |
| `spacy.SpanFinder.v1` | Span boundary detection model |
| `spacy.EntityLinker.v2` | Entity linking model |
| `spacy.TextCatBOW.v3` | Bag-of-words text classifier |
| `spacy.TextCatCNN.v2` | CNN text classifier |
| `spacy.TextCatEnsemble.v2` | Ensemble text classifier (BOW + tok2vec) |
| `spacy.TextCatReduce.v1` | Pooling-based text classifier |
| `spacy.TextCatParametricAttention.v1` | Attention-based text classifier |
| `spacy.PretrainCharacters.v1` | Pretraining: predict characters |
| `spacy.PretrainVectors.v1` | Pretraining: predict vectors |
| `spacy-transformers.TransformerModel.v3` | Transformer model |
| `spacy-transformers.TransformerListener.v1` | Listener for shared transformer |

### Batchers

| Registry Name | Strategy |
|---------------|----------|
| `spacy.batch_by_words.v1` | Target word count per batch |
| `spacy.batch_by_padded.v1` | Padded size batching (for transformers) |
| `spacy.batch_by_sequence.v1` | Fixed number of documents per batch |

### Corpus Readers

| Registry Name | Format |
|---------------|--------|
| `spacy.Corpus.v1` | `.spacy` (DocBin) files |
| `spacy.JsonlCorpus.v1` | JSONL files |
| `spacy.PlainTextCorpus.v1` | Raw text files |

### Optimizers

| Registry Name | Type |
|---------------|------|
| `Adam.v1` | Adam optimizer |

### Loggers

| Registry Name | Output |
|---------------|--------|
| `spacy.ConsoleLogger.v1` | Console (legacy) |
| `spacy.ConsoleLogger.v2` | Console + optional file |
| `spacy.ConsoleLogger.v3` | Console + file + progress bar |
| `ellf_monitor.v2` | JSONL file + anomaly detection (requires `ellf_logger.py`) |

### Augmenters

| Registry Name | Effect |
|---------------|--------|
| `spacy.lower_case.v1` | Random lowercasing |
| `spacy.orth_variants.v1` | Orthographic character variants |

### SpanCat Suggesters

| Registry Name | Strategy |
|---------------|----------|
| `spacy.ngram_suggester.v1` | Suggest spans of specific lengths |
| `spacy.ngram_range_suggester.v1` | Suggest spans in a length range |
| `spacy.preset_spans_suggester.v1` | Use pre-identified spans from `doc.spans` |

### Schedules

| Registry Name | Shape |
|---------------|-------|
| `compounding.v1` | Exponential growth/decay |
| `warmup_linear.v1` | Linear warmup then linear decay |
| `constant.v1` | Constant value |
| `cyclic_triangular.v1` | Triangular cyclic schedule |
