# Config Patterns: Training & Optimization

Copy-paste config snippets for batchers, learning rates, optimizers, training loop control, corpus readers, and data augmentation. Each pattern is self-contained — paste the relevant sections into your `config.cfg`.

---

## Table of Contents

- [Custom Batchers](#5-custom-batchers)
- [Learning Rate Schedules](#6-learning-rate-schedules)
- [Optimizer Tuning](#7-optimizer-tuning)
- [Training Loop Control](#8-training-loop-control)
- [Corpus and Data Readers](#9-corpus-and-data-readers)
- [Data Augmentation](#10-data-augmentation)

---

## 5. Custom Batchers

### Batch by words (default)

Groups examples to hit a target word count per batch. Compounding schedule starts small and grows.

```ini
[training.batcher]
@batchers = "spacy.batch_by_words.v1"
discard_oversize = false
tolerance = 0.2

[training.batcher.size]
@schedules = "compounding.v1"
start = 100
stop = 1000
compound = 1.001
```

### Batch by words with fixed size

No compounding — fixed batch size throughout training.

```ini
[training.batcher]
@batchers = "spacy.batch_by_words.v1"
discard_oversize = false
tolerance = 0.2
size = 500
```

### Batch by padded size (for transformers)

Pads sequences to the longest in the batch. Better for GPU utilization with transformers.

```ini
[training.batcher]
@batchers = "spacy.batch_by_padded.v1"
discard_oversize = true
size = 2000
buffer = 256
```

### Batch by sequence count (fixed number of docs)

Simple batching by number of documents, not word count.

```ini
[training.batcher]
@batchers = "spacy.batch_by_sequence.v1"
size = 32
```

### Batch by sequence count with compounding schedule

```ini
[training.batcher]
@batchers = "spacy.batch_by_sequence.v1"

[training.batcher.size]
@schedules = "compounding.v1"
start = 4
stop = 32
compound = 1.001
```

### Large batches for big datasets

Larger batches give smoother gradients but use more memory.

```ini
[training.batcher]
@batchers = "spacy.batch_by_words.v1"
discard_oversize = false
tolerance = 0.2

[training.batcher.size]
@schedules = "compounding.v1"
start = 500
stop = 5000
compound = 1.001
```

### Small batches for small datasets

Smaller batches for limited data — more update steps per epoch.

```ini
[training.batcher]
@batchers = "spacy.batch_by_words.v1"
discard_oversize = false
tolerance = 0.2

[training.batcher.size]
@schedules = "compounding.v1"
start = 25
stop = 200
compound = 1.001
```

---

## 6. Learning Rate Schedules

### Constant learning rate (default)

```ini
[training.optimizer]
@optimizers = "Adam.v1"
learn_rate = 0.001
```

### Warmup + linear decay (for transformers)

Warm up from zero to the initial rate, then linearly decay. Standard for transformer fine-tuning.

```ini
[training.optimizer]
@optimizers = "Adam.v1"

[training.optimizer.learn_rate]
@schedules = "warmup_linear.v1"
warmup_steps = 250
total_steps = 20000
initial_rate = 5e-5
```

### Compounding learning rate

Start low and increase. Useful when the model needs careful early training.

```ini
[training.optimizer.learn_rate]
@schedules = "compounding.v1"
start = 1e-5
stop = 1e-3
compound = 1.001
```

### Cyclic learning rate

Alternate between low and high learning rates.

```ini
[training.optimizer.learn_rate]
@schedules = "cyclic_triangular.v1"
min_lr = 1e-5
max_lr = 1e-3
period = 500
```

---

## 7. Optimizer Tuning

### Default Adam optimizer

```ini
[training.optimizer]
@optimizers = "Adam.v1"
beta1 = 0.9
beta2 = 0.999
L2_is_weight_decay = true
L2 = 0.01
grad_clip = 1.0
use_averages = false
eps = 1e-8
learn_rate = 0.001
```

### Reduce overfitting: increase weight decay

```ini
[training.optimizer]
@optimizers = "Adam.v1"
L2_is_weight_decay = true
L2 = 0.05              # default: 0.01
grad_clip = 1.0
learn_rate = 0.001
```

### Stabilize training: tighter gradient clipping

```ini
[training.optimizer]
@optimizers = "Adam.v1"
grad_clip = 0.5          # default: 1.0
learn_rate = 0.001
```

### Use parameter averaging for better generalization

Averages model parameters over training steps. Can improve final model quality.

```ini
[training.optimizer]
@optimizers = "Adam.v1"
use_averages = true
learn_rate = 0.001
```

---

## 8. Training Loop Control

### Early stopping

Stop training if no improvement for `patience` evaluation steps.

```ini
[training]
patience = 1600           # number of steps (default)
eval_frequency = 200      # evaluate every 200 steps
max_steps = 20000         # hard limit
max_epochs = 0            # 0 = unlimited epochs
```

### Train for a fixed number of epochs

```ini
[training]
max_epochs = 30
max_steps = 0             # 0 = no step limit
patience = 0              # 0 = disable early stopping
eval_frequency = 200
```

### Streaming mode (huge datasets that don't fit in memory)

Data is streamed from disk — no shuffling within the training loop, and only the first 100 examples are used for component initialization.

```ini
[training]
max_epochs = -1           # -1 = streaming mode
max_steps = 50000         # must set a step limit
patience = 5000
```

### More frequent evaluation

```ini
[training]
eval_frequency = 50       # evaluate every 50 steps
patience = 400            # patience in steps, not epochs
```

### Higher dropout for regularization

```ini
[training]
dropout = 0.3             # default: 0.1
```

---

## 9. Corpus and Data Readers

### Default .spacy corpus reader

```ini
[corpora.train]
@readers = "spacy.Corpus.v1"
path = ${paths.train}
gold_preproc = false
max_length = 0            # 0 = no length limit
limit = 0                 # 0 = no limit on number of examples
augmenter = null
```

### Limit document length (split long docs by sentence)

Documents longer than `max_length` tokens are split at sentence boundaries.

```ini
[corpora.train]
@readers = "spacy.Corpus.v1"
path = ${paths.train}
max_length = 500
```

### Use gold-standard tokenization

Use the tokenization from the gold data (reference) for the predicted Doc. Produces better alignment during training but introduces train/test skew.

```ini
[corpora.train]
@readers = "spacy.Corpus.v1"
path = ${paths.train}
gold_preproc = true
```

### Limit training examples (for debugging)

Train on a small subset to verify the pipeline works before running on all data.

```ini
[corpora.train]
@readers = "spacy.Corpus.v1"
path = ${paths.train}
limit = 100
```

### JSONL corpus reader (for text classification)

```ini
[corpora.train]
@readers = "spacy.JsonlCorpus.v1"
path = ${paths.train}
min_length = 0
max_length = 0            # 0 = no limit
limit = 0
```

### Plain text corpus (for pretraining only)

```ini
[corpora.pretrain]
@readers = "spacy.PlainTextCorpus.v1"
path = ${paths.raw_text}
min_length = 0
max_length = 0
```

---

## 10. Data Augmentation

### Lowercase augmentation

Randomly lowercases tokens to make the model more robust to casing.

```ini
[corpora.train]
@readers = "spacy.Corpus.v1"
path = ${paths.train}

[corpora.train.augmenter]
@augmenters = "spacy.lower_case.v1"
level = 0.3               # probability of lowercasing each example
```

### Orth variants augmentation

Replace tokens with orthographic variants (e.g., smart quotes, unicode normalization).

```ini
[corpora.train.augmenter]
@augmenters = "spacy.orth_variants.v1"
level = 0.2
lower = 0.5
```

### Custom combined augmentation

spaCy provides `spacy.lower_case.v1` and `spacy.orth_variants.v1` as built-in
augmenters. To combine multiple augmenters, write a custom augmenter function:

```python
import spacy
from spacy.training import Example
import random

@spacy.registry.augmenters("my_combined_augmenter.v1")
def combined_augmenter(lower_level: float = 0.3, orth_level: float = 0.2):
    lower_aug = spacy.registry.augmenters.get("spacy.lower_case.v1")(level=lower_level)
    orth_aug = spacy.registry.augmenters.get("spacy.orth_variants.v1")(level=orth_level, lower=0.0)
    def augment(nlp, example):
        if random.random() < 0.5:
            yield from lower_aug(nlp, example)
        else:
            yield from orth_aug(nlp, example)
    return augment
```

Then reference it in your config:

```ini
[corpora.train.augmenter]
@augmenters = "my_combined_augmenter.v1"
lower_level = 0.3
orth_level = 0.2
```
