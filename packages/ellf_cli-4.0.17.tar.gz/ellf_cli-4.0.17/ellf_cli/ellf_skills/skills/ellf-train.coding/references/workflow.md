# Training Workflow

This is your decision guide. Follow this flowchart to determine where you are
and what to do next. At each step, the flowchart tells you:
- What **decision** to make
- Which **reference file** to read for domain knowledge
- Which **SKILL.md action** to execute

Every training run gets a full analysis — don't just check if the overall score
is "good enough."

---

## Phase 1: Setup

```
START
  |
  +-- Have annotated data?
  |     +-- No  -> Bridge to annotation: invoke `ellf-annotate` via the
  |     |     Skill tool. Pass the task type, labels, and any data source
  |     |     so it can find the right recipe and launch annotation.
  |     |     ellf-annotate will hand off to `ellf-prodigy` if no built-in
  |     |     recipe fits the task.
  |     +-- Yes -> What format?
  |                 +-- Prodigy dataset -> Execute: Export Data
  |                 +-- .spacy files   -> Execute: Validate Data
  |
  +-- Validate data (spacy debug data)
  |     Run `spacy debug data` and present a data readiness assessment
  |     to the user BEFORE continuing. This is a gate — not a formality.
  |     Training on insufficient data produces near-random models and
  |     wastes time you'll spend arriving at "need more data" anyway.
  |
  |     The assessment must cover:
  |       1. Total example count (train / dev)
  |       2. Per-label distribution
  |       3. Whether minimum thresholds are met (see below)
  |       4. Your recommendation: proceed, fix issues, or annotate more
  |
  |     Minimum thresholds by task
  |     (from ${CLAUDE_SKILL_DIR}/references/training_troubleshooting.md S2.3):
  |       - textcat: 200+ total examples, 30+ per label
  |       - NER: 50+ examples per entity type
  |       - new pipeline from scratch: 100+ total (hard minimum)
  |       Below these, training will not produce useful models.
  |
  |     +-- Thresholds not met
  |     |     Do not proceed to config generation or training.
  |     |     Route to annotation: invoke `ellf-annotate` via the Skill
  |     |     tool with the task type, current labels, and per-label
  |     |     counts so it can set up targeted annotation for the gaps.
  |     |
  |     +-- Other issues (alignment, overlap, format errors)
  |     |     Diagnose and fix before continuing.
  |     |     Read: ${CLAUDE_SKILL_DIR}/references/diagnostics.md Class 1
  |     |     Read: ${CLAUDE_SKILL_DIR}/references/training_troubleshooting.md
  |     |           S2-2.5 (data format, annotation quality, tokenization,
  |     |           train/dev overlap)
  |     |
  |     +-- Clean and thresholds met -> Continue
  |
  +-- Select training paradigm
  |     Which approach fits the user's situation?
  |     Read: training_paradigms.md (for the full decision framework)
  |     Read: model_selection.md (for base model choice within fine-tuning)
  |     |
  |     +-- Fine-tune pretrained (default) -> Continue below
  |     +-- Train from blank (10k+ examples, very different domain) -> Continue
  |     +-- Pretrain tok2vec + train -> Follow training_paradigms.md
  |     +-- Active learning loop -> Follow training_paradigms.md
  |     +-- LLM distillation -> Follow training_paradigms.md
  |
  +-- Have a config?
  |     +-- No  -> Discuss architecture, then generate config
  |     |     Read: model_selection.md (which base model: sm/md/lg/trf)
  |     |     Read: config_architectures.md S4 (architecture config snippets)
  |     |     Read: config_architectures.md S3 (shared vs independent tok2vec)
  |     |     Read: config_training.md S5-8 (optimization: batchers, LR, etc.)
  |     |     Execute: Generate Config
  |     +-- Yes -> Validate with debug-config, fix issues
  |
  +-- Set up monitoring (for local spacy train)
  |     Phase 2 depends on structured JSONL logs with anomaly alerts.
  |     Without the logger, you're flying blind — no plateau detection,
  |     no overfitting alerts, no training curves to analyze in Phase 3.
  |
  |     1. Copy ${CLAUDE_SKILL_DIR}/scripts/ellf_logger.py to the
  |        working directory
  |     2. Update config.cfg:
  |          [training.logger]
  |          @loggers = "ellf_monitor.v2"
  |          log_path = "training_log.jsonl"
  |     3. Train with --code ellf_logger.py so spaCy registers it
  |
  |     (prodigy train does not support custom logger hooks — skip)
  |
  +-- READY TO TRAIN
        Show the user the full command and get confirmation before running.
        Local:
          spacy train config.cfg --output ./output --code ellf_logger.py [--gpu-id 0]
        Cluster:
          First, discover the recipe and its required args:
            ellf recipes list                              # find available training recipes
            ellf actions create <recipe> --help            # get exact arg names and required fields
          Then create and start:
            ellf actions create <recipe> --name "<name>" <args>
            ellf actions start "<name>"
```

---

## Phase 2: Train & Monitor

```
TRAINING LAUNCHED
  |
  +-- DURING TRAINING — interpret alerts:
  |     |
  |     +-- nan_loss
  |     |     Alert immediately, recommend stopping.
  |     |     Read: diagnostics.md Class 2
  |     |
  |     +-- loss_spike
  |     |     Don't surface unless sustained (3+ consecutive).
  |     |     Transient spikes are normal.
  |     |
  |     +-- plateau
  |     |     Mention only after 8+ evals without improvement.
  |     |     Training may have converged — check if score is acceptable
  |     |     before recommending action.
  |     |
  |     +-- overfitting
  |           Mention when sustained, but note model-best is already saved
  |           at the peak. If best score is low (e.g., F < 0.75 for NER):
  |           Read: diagnostics.md Class 3 (priority order of fixes)
  |
  +-- TRAINING COMPLETE -> Phase 3
```

Execute: Interpret Training Progress (for status checks during training)
Note: Raw log data comes from local `training_log.jsonl` or `ellf actions logs <name>` for cluster runs.
Interpretation and recommendations stay here in ellf-train.

---

## Phase 3: Analyze Results

Every completed training run gets this full analysis. Don't skip steps even if
the overall score looks good — structural issues hide under aggregate metrics.

```
TRAINING COMPLETE
  |
  +-- 1. READ TRAINING CURVES
  |     Read training_log.jsonl. Classify the curve shape.
  |     Read: evaluation_guide.md S3 (Training Curve Diagnostics)
  |     |
  |     +-- Healthy (loss down, score up, both flatten) -> Continue
  |     +-- Loss plateau (loss barely decreases)
  |     |     Read: evaluation_guide.md S3 "Loss plateau"
  |     +-- Oscillating loss (loss bounces up/down)
  |     |     Read: evaluation_guide.md S3 "Oscillating loss"
  |     +-- Overfitting (loss down but score peaks then drops)
  |     |     Read: diagnostics.md Class 3
  |     +-- Divergence (loss explodes)
  |           Read: diagnostics.md Class 2
  |
  +-- 2. RUN spacy evaluate ON model-best
  |     Execute: Analyze & Present Results (for the evaluate command)
  |     Always do this — meta.json scores are incomplete.
  |     Read: evaluation_guide.md S1-2 (reading evaluate output)
  |     |
  |     +-- Per-label scores — are any labels failing?
  |     |     A model at 0.90 overall can have one label at 0.30.
  |     |     For each underperforming label, diagnose the P/R pattern:
  |     |     +-- High P, low R -> too few examples or diverse patterns
  |     |     +-- Low P, high R -> label ambiguous or overlaps another
  |     |     +-- Low P, low R  -> label not learned (too few or poorly defined)
  |     |     Read: evaluation_guide.md S2 (Per-Label Error Analysis)
  |     |
  |     +-- Label distribution — cross-reference with debug data output
  |     |     < 20 examples  -> can't learn reliably
  |     |     20-50 examples -> marginal
  |     |     50-200         -> reasonable for clear-cut labels
  |     |     200+           -> sufficient, focus on consistency
  |     |
  |     +-- P/R balance at aggregate level
  |           +-- P >> R -> model too conservative
  |           +-- P << R -> model over-predicts
  |           Read: evaluation_guide.md S6
  |
  +-- 3. CHECK AGAINST BASELINES
  |     Don't celebrate a score without context. Compare against:
  |     +-- Prior probability baseline (predict most frequent class/entity)
  |     +-- Majority-class baseline (for textcat)
  |     +-- Random baseline
  |     A model at 79% means little if a prior-probability baseline gets 78%.
  |     If the model barely beats the baseline, the issue is likely data or
  |     task formulation, not architecture.
  |
  +-- 4. RUN MODEL ON TRAINING DATA (spot annotation issues)
  |     Apply model-best to the training corpus and inspect false positives
  |     and false negatives. Even with good overall scores, this can reveal:
  |     +-- Inconsistent entity boundaries (e.g., "CPS" vs "CPS Schools")
  |     +-- Annotation noise (contradictory labels for similar examples)
  |     +-- Label scheme ambiguity the model is confused about
  |     These errors are structural — they indicate annotation guidelines
  |     need clarifying or data needs cleaning, regardless of the score.
  |
  +-- 5. CHECK FOR STRUCTURAL ISSUES (even if scores look good)
  |     |
  |     +-- Data split quality?
  |     |     +-- Document-level splits: are all sentences from the same
  |     |     |     document in the same split? Random splitting leaks
  |     |     |     information and can inflate scores by 10-20%.
  |     |     +-- Deterministic splits: can the split be reproduced when
  |     |     |     new data is added?
  |     |     +-- Label distribution: compare train vs dev distributions.
  |     |
  |     +-- Corpus selection bias?
  |     |     Was training data filtered (e.g., keyword-based)?
  |     |     Does the dev set represent real production distribution?
  |     |
  |     +-- Catastrophic forgetting? (if fine-tuning pretrained model)
  |     |     Did existing capabilities degrade?
  |     |     Read: diagnostics.md Class 6
  |     |
  |     +-- Speed acceptable?
  |     |     Read: evaluation_guide.md S12
  |     |
  |     +-- Threshold appropriate? (spancat / textcat only)
  |     |     Read: evaluation_guide.md S11
  |     |
  |     +-- Intrinsic vs extrinsic evaluation?
  |           Token/span-level NLP metrics measure model quality.
  |           But does the system produce the right business output?
  |
  +-- 6. SYNTHESIZE -> Phase 4
```

---

## Phase 4: Decide Next Step

Based on the analysis, recommend ONE next action. Follow the priority order —
earlier items are more likely to help and cheaper to try.

```
DECISION POINT
  |
  +-- Are there data issues? (from per-label analysis)
  |     +-- Labels with < 50 examples -> Need more annotations.
  |     |     Invoke `ellf-annotate` via Skill tool with the task type,
  |     |     underperforming labels, and existing dataset name so it can
  |     |     set up a targeted annotation session.
  |     +-- Contradictory annotations -> Audit and clean data
  |     +-- Train/dev mismatch -> Re-split data
  |     +-- -> RETRAIN after fixing
  |     Execute: Export Data / Validate Data as needed
  |
  +-- Is the label scheme the problem?
  |     +-- Labels consistently confused -> Merge or redefine
  |     +-- Label not learnable from text -> Rules-based or hybrid approach
  |     +-- -> May need re-annotation, then RETRAIN
  |     Read: evaluation_guide.md S9
  |
  +-- Is training configuration the problem? (curve shape issues)
  |     +-- Learning rate, batch size, dropout, early stopping
  |     +-- -> Adjust config, RETRAIN
  |     Read: config_training.md S5-8
  |
  +-- Is the architecture the problem?
  |     +-- Model too small for the task -> Compare architectures
  |     +-- Model too large for the data -> Try simpler architecture
  |     +-- -> Set up architecture comparison experiment
  |     Read: config_architectures.md S4
  |     Read: experiment_patterns.md (architecture comparison template)
  |     Execute: Set Up Experiments
  |
  +-- Are results good but want more confidence?
  |     +-- Measure variance (multiple trials, different seeds)
  |     Read: experiment_patterns.md (multi-trial template)
  |     Execute: Set Up Experiments
  |
  +-- Are results good and want to squeeze more?
  |     +-- Hyperparameter sweep
  |     Read: experiment_patterns.md (sweep template)
  |     Execute: Set Up Experiments
  |
  +-- Results are good, no structural issues
        +-- DONE — model is ready
             Consider: package model, update training history
             Execute: Update Records
```

---

## Priority Order for Fixes

When multiple issues are found, fix them in this order. Each level is cheaper
and more likely to help than the next:

1. **Fix data** — more examples for underperforming labels, clean
   contradictions, fix alignment issues
2. **Fix label scheme** — merge confusing labels, remove unlearnable ones
3. **Tune training** — dropout, augmentation, learning rate, early stopping
   Read: config_training.md S5-8
4. **Change architecture** — only after confirming data and labels are sound
   Read: config_architectures.md S4, model_selection.md
5. **Advanced experiments** — sweeps, pretraining, ensembles
   Read: experiment_patterns.md, training_paradigms.md

Recommend the first actionable item, not the full list.

---

## Error Handling

When any command fails or the user reports an issue:

```
ERROR OCCURRED
  |
  +-- Command-line error (config, data, CLI flags)
  |     Read: training_troubleshooting.md (organized by error category)
  |     Execute: Troubleshoot Errors
  |
  +-- Runtime anomaly during training (NaN loss, overfitting, plateau)
  |     Read: diagnostics.md (6 problem classes with detection signals)
  |     Execute: Monitor Training
  |
  +-- Both (error during training that also shows monitoring anomalies)
        Read both reference files, cross-reference
        Execute: Troubleshoot Errors
```
