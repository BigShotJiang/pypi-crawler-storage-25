"""Ellf training monitor — JSONL logger with anomaly detection.

Registers as spacy.registry.loggers("ellf_monitor.v2").
Logs every evaluation step to a local JSONL file. Detects anomalies
(NaN loss, loss spikes, score plateaus, overfitting).

Deploy: copy this file to your working directory and add to config.cfg:

    [training.logger]
    @loggers = "ellf_monitor.v2"
    log_path = "training_log.jsonl"

Then train with:
    python -m spacy train config.cfg --code ellf_logger.py
"""

import json
import math
from datetime import datetime
from pathlib import Path

from spacy.util import registry as spacy_registry


class _NumpySafeEncoder(json.JSONEncoder):
    def default(self, o):
        try:
            import numpy as np

            if isinstance(o, (np.floating,)):
                return float(o)
            if isinstance(o, (np.integer,)):
                return int(o)
        except ImportError:
            pass
        return super().default(o)


@spacy_registry.loggers("ellf_monitor.v2")
def ellf_monitor_logger(log_path: str = "training_log.jsonl"):
    """Create a training logger with anomaly detection.

    Logs every evaluation step to a JSONL file. Detects anomalies:
    - NaN loss in any component
    - Loss spike > 5x previous value
    - Score plateau (8+ evals without improvement)
    - Overfitting (dev score strictly declining while train loss improving)
    """

    def setup_logger(nlp, stdout, stderr):
        log_file = Path(log_path).open("a", encoding="utf8")
        state = {
            "prev_losses": {},
            "best_score": 0.0,
            "no_improve_count": 0,
            "prev_scores": [],
            "prev_train_losses": [],
            "step_count": 0,
            "start_time": datetime.now().isoformat(),
        }

        def log_step(info):
            if not info:
                return

            state["step_count"] += 1
            alerts = []
            losses = info.get("losses", {})
            score = info.get("score", 0)

            # --- Anomaly detection ---

            for comp, loss in losses.items():
                # NaN check
                if math.isnan(loss):
                    alerts.append({"type": "nan_loss", "component": comp})
                # Loss spike
                elif comp in state["prev_losses"] and state["prev_losses"][comp] > 0:
                    ratio = loss / state["prev_losses"][comp]
                    if ratio > 5:
                        alerts.append(
                            {
                                "type": "loss_spike",
                                "component": comp,
                                "ratio": round(ratio, 1),
                            }
                        )

            # Score plateau detection
            if score > state["best_score"]:
                state["best_score"] = score
                state["no_improve_count"] = 0
            else:
                state["no_improve_count"] += 1
            if state["no_improve_count"] >= 8:
                alerts.append(
                    {
                        "type": "plateau",
                        "steps_without_improvement": state["no_improve_count"],
                    }
                )

            # Overfitting detection (strict decline, not plateau)
            state["prev_scores"].append(score)
            total_loss = sum(losses.values()) if losses else 0
            state["prev_train_losses"].append(total_loss)
            if len(state["prev_scores"]) >= 4:
                recent_scores = state["prev_scores"][-3:]
                recent_losses = state["prev_train_losses"][-3:]
                scores_declining = all(s < recent_scores[0] for s in recent_scores[1:])
                losses_improving = all(
                    loss <= recent_losses[0] for loss in recent_losses[1:]
                )
                if scores_declining and losses_improving:
                    alerts.append({"type": "overfitting"})

            # --- Build log entry ---

            entry = {
                "timestamp": datetime.now().isoformat(),
                "step": info.get("step", state["step_count"]),
                "epoch": info.get("epoch", 0),
                "score": round(score, 4),
                "losses": {k: round(v, 4) for k, v in losses.items()},
                "best_score": round(state["best_score"], 4),
            }

            # Per-component scores (if available)
            other_scores = {
                k: round(v, 4)
                for k, v in info.items()
                if k not in ("losses", "score", "step", "epoch", "checkpoints")
                and isinstance(v, (int, float))
            }
            if other_scores:
                entry["component_scores"] = other_scores

            if alerts:
                entry["alerts"] = alerts

            # --- Write to JSONL ---

            log_file.write(json.dumps(entry, cls=_NumpySafeEncoder) + "\n")
            log_file.flush()

            state["prev_losses"] = dict(losses)

        def finalize():
            # Only write summary if training actually ran (at least one step)
            if state["step_count"] > 0:
                summary = {
                    "timestamp": datetime.now().isoformat(),
                    "event": "training_complete",
                    "total_steps": state["step_count"],
                    "best_score": round(state["best_score"], 4),
                    "start_time": state["start_time"],
                }
                log_file.write(json.dumps(summary, cls=_NumpySafeEncoder) + "\n")
                log_file.flush()
            log_file.close()

        return log_step, finalize

    return setup_logger
