# prodigy-llm-bot — LLM Bot Annotation

## What It Is

`prodigy-llm-bot` is a headless LLM annotator that works alongside human
annotators in Prodigy. It polls the Prodigy REST API for tasks, annotates them
via an LLM (Gemini by default), and submits answers back — just like a human
session, but automated.

This is relevant during project planning because it affects annotation strategy,
recipe design, and throughput estimates.

## When to Recommend

- **Bootstrap phase** — The team wants to annotate a large initial batch quickly
  before switching to human review. Bot annotations get corrected by humans
  rather than annotating from scratch ("correct" workflow).
- **Scale-up** — Human annotators are the bottleneck. The bot handles easy/clear
  cases while humans focus on ambiguous ones.
- **Mixed human+bot** — Both annotate the same tasks for agreement analysis, or
  the bot pre-annotates and humans review.

## When NOT to Recommend

- **Complex annotation** (relations, nested spans, custom blocks UI) — the bot
  only supports specific view IDs (see below).
- **Image/audio/video** — not supported.
- **High-stakes tasks** where every annotation must be human-verified anyway —
  the bot adds overhead without saving time.

## Supported Task Types

The bot maps Prodigy view IDs to annotation modes:

| View ID | Bot Mode | Notes |
|---------|----------|-------|
| `choice` | choice | Multi-option selection |
| `classification` | textcat_binary | Accept/reject binary |
| `ner` | ner_binary | Accept/reject NER suggestions |
| `ner_manual` | spans_manual | Free-form span annotation |
| `spans` | ner_binary | Accept/reject span suggestions |
| `spans_manual` | spans_manual | Free-form span annotation |

**Not supported:** `image_manual`, `audio_manual`, `text_input`, `relations`,
`blocks` (composite), `review`, `diff`.

## Plan Implications

When bot annotation is part of the plan:

1. **Recipe must be compatible** — use a supported view ID from the table above.
   Flag this as a constraint in the annotation plan.
2. **Config needs multi-session support** — `feed_overlap: True` and
   `annotations_per_task` if both humans and bot annotate the same tasks.
3. **Throughput estimates change** — bot can annotate ~1000s of tasks/hour vs
   ~100-300/hour for humans. Factor this into the annotation timeline.
4. **Quality check** — plan a human review step for bot annotations, especially
   in early rounds. Bot accuracy varies by task complexity.
5. **Recipe handoff** — when bridging to `/ellf-prodigy`, note that bot
   annotation is needed so the recipe builder uses a compatible view ID.
