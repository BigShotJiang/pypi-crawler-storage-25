# Consulting Patterns — Real-World NLP Project Archetypes

Recurring project patterns from Explosion's consulting work, case studies, and
public talks. Each describes a problem, the naive approach, and the
recommended reframing.

Use these as conversational ammunition. When a user's problem matches a pattern,
reference it naturally: "This is similar to a project where..." The goal is to
show the user that their problem has a known shape and a proven approach.

## Table of Contents

1. [The Taxonomy Trap](#the-taxonomy-trap) — Large official taxonomies
2. [The Composite Entity](#the-composite-entity) — Labels mixing identity with role
3. [The Multi-Skill Entity](#the-multi-skill-entity) — Compound phrases as entities
4. [The Quote Extraction Pipeline](#the-quote-extraction-pipeline) — Structured quote extraction
5. [The PDF Pipeline](#the-pdf-pipeline) — Information extraction from PDFs
6. [The Chatbot Quality Loop](#the-chatbot-quality-loop) — Evaluating conversational agents
7. [The Label Scheme That Grew](#the-label-scheme-that-grew) — Accreted label sets
8. [The GitHub Issue Tagger](#the-github-issue-tagger) — Multi-label classification with evolving labels
9. [The Single-Label Pass](#the-single-label-pass) — Annotation with many entity types
10. [The LLM Distillation Loop](#the-llm-distillation-loop) — LLMs for dev, supervised for prod
11. [The Business Logic Factor](#the-business-logic-factor) — Separating NLP from business rules
12. [The Confusable Labels](#the-confusable-labels) — Overlapping entity types
13. [The Rules Augmentation Ladder](#the-rules-augmentation-ladder) — Layering rules and models
14. [The Oracle Ceiling](#the-oracle-ceiling) — Finding pipeline bottlenecks
15. [The Training Curve Diagnostic](#the-training-curve-diagnostic) — Diagnosing plateaus
16. [The NLI Reframe for Relations](#the-nli-reframe-for-relations) — Relations as entailment
17. [The Ten-Component Pipeline](#the-ten-component-pipeline) — Many small models over one big one
18. [The Data Drift Monitor](#the-data-drift-monitor) — Detecting when rules go stale

---

## Pattern: The Taxonomy Trap

**Domain**: Job ads, legal, medical — anything with an official taxonomy of
hundreds or thousands of categories.

**Client says**: "We need to label documents according to [taxonomy with 3000+
categories]."

**Naive approach**: One label per taxonomy entry. Labelling nightmare — the
taxonomy changes, you need examples for every category, consistency is
impossible.

**Recommended approach**: Factor into two steps: (1) Extract generic entities
with a small, stable label set (e.g., SKILL, EXPERIENCE). (2) Map extracted
entities to the taxonomy using a separate non-ML step (semantic similarity,
embedding lookup, rule matching). The mapping layer is swappable — when the
taxonomy updates, you change the mapping, not the model.

**Key insight**: Separate what needs learning (finding mentions in text) from
what needs lookup (matching to a taxonomy).

**Real case**: Nesta — 7M UK job ads. NER for SKILL/MULTISKILL/EXPERIENCE, then
similarity-based mapping to ESCO taxonomy. 375 manual annotations for a working
model.

---

## Pattern: The Composite Entity

**Domain**: Crime reports, financial filings, compliance — where desired output
combines entity identity with semantic role.

**Client says**: "We need to extract VICTIM_NAME, PERPETRATOR, COMPENSATED_EXECUTIVE."

**Naive approach**: One NER label per composite concept. Couples entity
recognition with semantic role — requires far more data and produces brittle
models.

**Recommended approach**: Decompose: (1) Text classification (is this a crime
article?). (2) Generic NER (PERSON, LOCATION, DATE). (3) Rule-based role
assignment using dependency parsing or syntactic patterns. Each sub-task is
simple, generic, and data-efficient.

**Key insight**: The composition logic is transparent and debuggable. You need
far less annotation because each model learns only one thing.

**Real case**: Matt Honnibal's crime database example (PyData Berlin 2018).

---

## Pattern: The Multi-Skill Entity

**Domain**: Job descriptions, requirements docs — compound phrases containing
multiple items.

**Client says**: "The model extracts 'developing visualizations and apps' as one
entity, but those are two skills."

**Recommended approach**: Let NER extract the full compound span, then
post-process: (1) Binary classifier — is this multi-item or single-item?
(2) For multi-items, use dependency parsing to split on noun phrases and
coordinating conjunctions.

**Key insight**: NER finds boundaries. A cheap classifier flags compounds.
Rules split them. Each step is independently testable.

**Real case**: Nesta's skills pipeline.

---

## Pattern: The Quote Extraction Pipeline

**Domain**: Journalism, media monitoring — extracting who said what.

**Client says**: "We want to extract quotes — source, cue word, and content."

**Recommended approach**: Multi-component pipeline: (1) NER for quote components
in separate annotation passes. (2) Link source to content via cue words using
dependency parsing rules. (3) Develop annotation guidelines first — define
direct vs indirect quotes, nested quotes, unnamed sources.

**Key insight**: The annotation guidelines are the most important artifact.
Pilot annotation reveals edge cases you didn't anticipate. Don't scale before
guidelines are stable.

**Real case**: The Guardian's modular journalism initiative.

---

## Pattern: The PDF Pipeline

**Domain**: Legal, financial, scientific, government — any domain drowning in
PDFs.

**Client says**: "We have 50,000 PDFs and need to extract structured information."

**Naive approach**: Send entire PDFs to an LLM, or convert to plain text losing
all structure.

**Recommended approach**: Modular pipeline: (1) Document conversion with layout
analysis (Docling, pdfplumber → spacy-layout). (2) Filtering/segmentation to
relevant sections (often rule-based). (3) Standard NLP extraction on clean text.
(4) Compose into target schema.

**Key insight**: Factor document conversion from information extraction. The
conversion happens once; NLP components are robust, fast, and independently
improvable.

---

## Pattern: The Chatbot Quality Loop

**Domain**: Customer service, banking — evaluating automated conversational
agents.

**Client says**: "We need to evaluate whether our chatbot responses are helpful."

**Recommended approach**: (1) Define "helpful" operationally — a chat contains
multiple "moments" (balance check, mortgage question). Each is a separate
annotation unit. (2) Custom Prodigy recipe with link-through to full
conversations while making binary judgements per moment. (3) Scale with
model-in-the-loop correction.

**Key insight**: Break evaluation to the smallest meaningful decision. "Was this
chat helpful?" is too coarse. "Was this banking moment handled correctly?" is
annotatable, trainable, and actionable.

**Real case**: Posh's "Helpful Banking Moments" — goal of 1 billion helpful
moments identified.

---

## Pattern: The Label Scheme That Grew

**Domain**: Any long-running project where requirements evolved.

**Client says**: [Presents 20+ overlapping categories accumulated over months.]

**What went wrong**: The scheme accreted — never designed. New categories added
ad hoc, sub-categories nested inconsistently, annotators confused, IAA dropped,
model plateaued.

**Recommended approach**: (1) Run model on its own training data — false
positives/negatives reveal annotator confusion. (2) Refactor into orthogonal
dimensions. (3) Write annotation guidelines retroactively. (4) Re-annotate a
pilot with the new scheme and compare IAA before/after.

**Key insight**: A confused annotator produces training data that teaches the
model to be confused. Fix the schema before adding more data.

**Real case**: Sofie Van Landeghem's talk on structural biases — schools/
districts boundary inconsistency.

---

## Pattern: The GitHub Issue Tagger

**Domain**: Software engineering, support tickets — multi-label classification
with evolving labels.

**Client says**: "We want to auto-tag issues/tickets with relevant categories."

**Key lessons**: (1) Look at data before designing labels — historical tags may
be systematically incomplete. (2) Render in native format (GitHub markdown with
images) — a plain-text view misses things. (3) Sample strategically: untagged
examples first, then random, then model-assisted. (4) Many NLP problems need
bespoke solutions — custom preprocessing, annotation interfaces, and evaluation.

**Key insight**: The annotation process is a learning process. Treat it as
discovery, not drudgery.

**Real case**: "Diary of a spaCy project: Predicting GitHub Tags."

---

## Pattern: The Single-Label Pass

**Domain**: Any NER project with more than a handful of entity types.

**Client says**: "We have 15–30 entity types. We show annotators each document
once to label everything."

**Naive approach**: Full label set per document. Annotators context-switch,
miss things, burn out. Quality degrades as labels grow.

**Recommended approach**: Annotate one label at a time. Multiple passes over
the same data. After the first pass, use model predictions to pre-annotate and
switch to correction mode.

**Key insight**: Annotation speed is dominated by cognitive load, not reading
time. Humans are fast at recognizing one pattern repeatedly; slow at switching.

**Real case**: S&P Global — switched to single-label passes, achieved 10x
annotation speedup. One domain expert created production-quality data in ~15
hours.

**Further reading**:
- [S&P Global case study](https://explosion.ai/blog/sp-global-commodities)

---

## Pattern: The LLM Distillation Loop

**Domain**: Any production system needing fast, private inference but wanting
to leverage LLMs during development.

**Client says**: "Should we just use GPT-4?" or "We can't send production data
to external APIs."

**Recommended approach**: Use LLMs as development-time tools: (1) LLM
pre-annotation. (2) Human correction in Prodigy → high-quality gold data.
(3) Train a task-specific spaCy pipeline — small, fast, private, often more
accurate on the specific task. (4) Deploy the small model. The LLM never
touches production.

**Key insight**: LLMs are best as annotation accelerators. Distill their broad
knowledge into something fast, cheap, and private. The LLM is scaffolding — it
comes down once the building is up.

**Real case**: S&P Global — GPT-3.5 pre-annotates, Prodigy corrects, spaCy
pipelines run at 15,000 words/second with 6 MB artifacts.

**Further reading**:
- [Human-in-the-loop distillation](https://explosion.ai/blog/human-in-the-loop-distillation)
- [S&P Global case study](https://explosion.ai/blog/sp-global-commodities)
- [How many labelled examples to beat GPT-4?](https://www.youtube.com/watch?v=3iaxLTKJROc) — Matt Honnibal's talk

---

## Pattern: The Business Logic Factor

**Domain**: Support tickets, product analytics, content moderation — combining
general NLP with company-specific rules.

**Client says**: "We need to classify tickets by product area and track which
features cause issues."

**Naive approach**: Train end-to-end into business categories. Needs retraining
every time products change or versions are released.

**Recommended approach**: Factor into: (1) General NLP — extract entities,
versions, URLs, topics, key phrases. These are stable and reusable.
(2) Business logic layer — company-specific rules on top. Transparent,
versionable, changeable by non-ML engineers.

**Key insight**: If what changes frequently is in model weights, you'll retrain
constantly. Let the model learn language; let rules encode business knowledge.

**Real case**: GitLab's support ticket analysis.

**Further reading**:
- [GitLab case study](https://explosion.ai/blog/gitlab-support-insights)
- [Refactoring data](https://explosion.ai/blog/human-in-the-loop-distillation#refactoring)

---

## Pattern: The Confusable Labels

**Domain**: Any NER domain with genuine semantic overlap between entity types.

**Client says**: "Our model keeps confusing PERSON and ORGANIZATION" or
"Annotators can't agree on DISEASE vs SYMPTOM."

**What's actually happening**: The confusion reflects genuine linguistic
ambiguity. "Goldman Sachs says..." — organization or metonym for a person?
When annotators disagree, the training signal is noise.

**Recommended approach**: (1) Run model on its own training data — confusion
matrix reveals disagreements. (2) Decide if the distinction matters for your
use case — if not, merge types and disambiguate downstream. (3) If it matters,
split into two steps: identify span first, then classify. (4) Use IAA as a
diagnostic for scheme design problems.

**Key insight**: When annotators consistently disagree on a label pair, the
problem is the scheme, not the annotators. Merge, redefine, or factor.

---

## Pattern: The Rules Augmentation Ladder

**Domain**: Healthcare, government, finance — domains with authoritative
gazetteers or controlled vocabularies.

**Client says**: "We have a dictionary of all known [facilities/drugs/
companies]. Can we just match against it?"

**Recommended approach**: Build up in layers, measuring at each step:
(1) High-precision exact dictionary matches for unambiguous terms → baseline.
(2) Fuzzy and pattern-based rules (abbreviations, misspellings) → recall jumps.
(3) Train a model with rules as features → handles novel entities. (4) Evaluate
each layer independently with strict and fuzzy matching.

**Key insight**: Rules and models aren't alternatives — they're layers. Rules
provide a high-precision floor; the model handles the long tail. Combining
almost always outperforms either alone.

**Further reading**:
- [Combining models and rules](https://spacy.io/usage/rule-based-matching#models-rules)

---

## Pattern: The Oracle Ceiling

**Domain**: Any multi-component pipeline — entity linking, relation extraction,
end-to-end IE.

**Client says**: "Our end-to-end accuracy is 60%. We're improving the final
classification stage."

**Recommended approach**: Replace each component with gold data, one at a time.
The biggest gap between oracle and actual performance is where your effort
should go. If candidate retrieval finds the correct entity only 75% of the
time, no disambiguation improvement gets you past 75%.

**Key insight**: In a pipeline, the weakest component sets the ceiling for
everything downstream. Oracle analysis takes an hour and tells you exactly
where to invest.

---

## Pattern: The Training Curve Diagnostic

**Domain**: Any supervised project where performance has stalled.

**Client says**: "Our accuracy has plateaued. Should we try a bigger model?"

**Recommended approach**: Plot a learning curve — train on 25/50/75/100% of
data. If still rising at 100%, more annotation is your best investment. If
truly flat, consider: annotation quality problem? Label scheme problem? Model
capacity issue? Compare architectures only after the curve flattens.

**Key insight**: Most "architecture problems" are data problems. The learning
curve is the cheapest diagnostic. If it's climbing, the answer is more data,
not a fancier model.

**Further reading**:
- [How many labelled examples to beat GPT-4?](https://www.youtube.com/watch?v=3iaxLTKJROc) — Matt Honnibal's talk

---

## Pattern: The NLI Reframe for Relations

**Domain**: News, financial filings, scientific literature — extracting typed
relationships between entities.

**Client says**: "We need to extract 'Company X acquired Company Y' relations in
articles with fairly complex syntactic structures."

**Naive approach**: Relation classification requiring substantial examples per
relation type. Annotation is slow — annotators must consider every entity pair.
Many relations are long distance and span sentence boundaries.

**Recommended approach**: Reframe as NLI: (1) Extract entities with standard
NER. (2) Generate hypotheses from entity pairs: "Is it true that A acquired B?"
(3) Use an NLI model to classify as entailed/contradicted/neutral. (4) Bootstrap
with LLM pre-annotation, multiple passes per relation family.

**Key insight**: NLI converts specialized annotation (draw arrows, label them)
into reading comprehension (is this statement true?). Handles long distance relations,
easier to annotate, easier to bootstrap, leverages pretrained NLI models.

---

## Pattern: The Ten-Component Pipeline

**Domain**: Music industry, legal tech, insurance — business processes with
multiple extraction and classification needs.

**Client says**: "We need an AI system that handles our entire workflow."

**Naive approach**: One big model or one LLM mega-prompt. Hard to debug, hard
to improve, fails unpredictably.

**Recommended approach**: Many small, focused models — one per sub-task. Train
and evaluate each separately. Compose in a spaCy pipeline. Mix architectures
freely (CNN for fast tasks, transformers for hard ones, rules where they work).

**Key insight**: Many small models beat one large model. Each is simple to
annotate, fast to train, easy to debug, independently improvable. New
requirements add a component, not a retrain.

**Real case**: Love Without Sound — 10 NLP components for the music industry,
each scoring 90–99% accuracy.

**Further reading**:
- [Love Without Sound case study](https://explosion.ai/blog/love-without-sound-nlp-music-industry)
- [Applied NLP Thinking](https://explosion.ai/blog/applied-nlp-thinking)

---

## Pattern: The Data Drift Monitor

**Domain**: Any production system using rules on data that evolves over time.

**Client says**: "Our rules-based system works great today. How do we keep it
working?"

**Recommended approach**: Train a shadow model alongside rules. Compare outputs
regularly. When the model predicts things rules miss, flag for human review —
these are likely new patterns the rules don't cover. Use flagged cases to update
rules or retrain.

**Key insight**: Rules are precise but frozen. Models are approximate but
adaptive. A shadow model as drift detector gives reliability of rules with early
warning when the world changes.

**Real case**: S&P Global's commodities team — shadow model flags unseen
patterns before they affect data quality.

**Further reading**:
- [S&P Global case study](https://explosion.ai/blog/sp-global-commodities)