---
name: ellf-support
description: Prepare and send a support request from the coding environment when the user wants human help from the Ellf team. Use when the user wants to escalate an issue, asks for human review, wants to contact support, or says things like "I need support", "can someone look at this", "send this to the Ellf team", or "I'm stuck". This skill gathers the issue, summarizes the current state, asks whether to attach the full Claude Code transcript, and sends the request with `ellf support create`.
argument-hint: "[describe your issue]"
---

# Human Support From Coding

Help the user escalate to human support cleanly and accurately.

$ARGUMENTS

## Scope

You are not implementing a fix here. Your job is to:
- collect the support request
- summarize the current issue and relevant local context
- include the most important recent errors or state
- ask whether to attach the full Claude Code transcript and debug log
- submit the request with `ellf support create`

Do not claim that a request was sent unless `ellf support create` succeeded.

## Collect the issue

If `$ARGUMENTS` already describes the issue clearly, use it.

Otherwise use `AskUserQuestion` to collect:
- what is going wrong
- what the user expected
- whether they want debugging help, workflow advice, or product feedback

Keep the question short and practical. Do not ask these questions in plain text.

## Transcript consent

Always ask explicitly whether the user wants to attach the full Claude Code
session transcript and debug log.

In Claude Code, the transcript source is the local session JSONL under
`~/.claude/projects/...` and the debug log under `~/.claude/debug/...` for the
current Claude session ID. The active session ID is captured by the hook into
`~/.claude/current_session.json`, and `ellf support create` only auto-attaches
when that captured `project_dir` matches the current repo.

Use a short choice:
- summary only
- summary + full transcript

Do not attach transcript or debug log content unless the user opts in.
Use `AskUserQuestion` for this choice. Do not ask for transcript consent in plain text.

## Gather context

Use the current conversation first.

Resolve the target project before you submit the request.

- If the current project is explicit from local project context or prior confirmed
  state, use it.
- If there is any ambiguity about which project the support request belongs to,
  use `ellf projects list --json` to gather candidates, then use `AskUserQuestion`
  to confirm the project with the user before running `ellf support create`.
- Offer a clear "No project / not tied to a project" option when the request is
  general feedback or otherwise not project-specific.
- When asking, present human-readable project names, not raw UUIDs.
- Do not list projects and pick one yourself. Do not guess the project ID.
- If the locally saved/default project ID does not exist in PAM, treat it as stale
  and ask the user to choose from the current project list.

When helpful, include:
- current project/workflow summary
- the most relevant recent command failure
- the most relevant local or cluster error
- what has already been tried

Do not dump raw logs into the summary. Quote only the important error lines.

## Build the support summary

Produce a concise support-ready summary with:
- user issue
- what they were trying to do
- relevant environment or workflow context
- key errors or symptoms
- current state
- what has already been tried

## Submission rule

Submit with:

```bash
ellf support create --message "<user_comment>" --summary "<support_summary>" --transcript-consent summary_only
```

If the user confirmed a verified project, include `--project "<project_id>"`.
If they chose "No project", pass `--no-project` to prevent fallback to a saved default.

If the user opted in to transcript attachment, use:

```bash
ellf support create --message "<user_comment>" --summary "<support_summary>" --transcript-consent attach_full_transcript
```

Do not pass `--session-id` by default. The CLI uses the hook-written
`~/.claude/current_session.json` metadata to resolve the current session safely.
If auto-attachment fails, do not tell the user to rerun a CLI command or pass a
CLI flag. In the conversational flow, ask whether to continue without the
transcript or to provide the transcript file path from `~/.claude/projects/`.
If the user provides a path, you may pass `--transcript-path` yourself behind
the scenes when you rerun `ellf support create`.

Do not pass `--conversation` unless you have a verified PAM conversation ID for
the current support flow. In the local coding environment this is usually not
available, so omit `--conversation` by default.

`ellf support create` attaches the current Claude Code session transcript and
debug log when available and reports the exact lookup status in its output.
Do not guess why attachments were missing. Use the reported lookup fields
(`session_id_present`, `session_id_source`, `transcript_path`, `transcript_found`,
`debug_log_path`, `debug_log_found`, `session_metadata_reason`) when explaining
what happened.

On success:
- confirm success
- show the reference ID if one was returned
- if no reference ID was returned, say that the request was sent but no support
  reference ID was provided
- say whether transcript and debug log were attached

If transcript auto-attachment failed:
- explain the reason in plain language using the CLI lookup fields
- do not expose backend-only instructions like "re-submit with --transcript-path"
- ask a short follow-up:
  - continue without transcript
  - provide transcript file path
- if the user provides a path, reuse the existing draft and rerun the support
  request yourself

On failure:
- do not pretend to send anything
- provide the support-ready summary
- explain the failure briefly

## Output format

When submission fails, present:

| Field | Value |
|---|---|
| Issue | <short title> |
| Type | <bug / workflow advice / feedback> |
| Current state | <short summary> |

Then include the support-ready summary the user can send manually.
