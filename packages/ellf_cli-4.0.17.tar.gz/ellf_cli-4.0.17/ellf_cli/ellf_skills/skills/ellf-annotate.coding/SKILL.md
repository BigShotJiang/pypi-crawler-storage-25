---
name: ellf-annotate
description: "Set up and launch annotation from the coding environment once the methodology, schema, and data are ready. Use when the user wants to start annotation on the Ellf cluster, run a local Prodigy annotation server, choose between built-in Ellf and built-in Prodigy recipes, verify that annotation is ready to launch, preview the annotation setup, or determine whether a new custom recipe is needed. Also trigger on \"I want to annotate\", \"start a local Prodigy server\", \"launch annotation on the cluster\", \"which recipe should I use\", \"can I run this locally\", \"set up review\", or \"help me run annotation\". This skill is the annotation readiness gatekeeper: it applies the audit checklist before launch, prefers built-in workflows when possible, and delegates to `/ellf-prodigy` when a new custom recipe must be implemented."
argument-hint: "[describe what you want to annotate]"
---

# Launch Annotation From Coding

Help the user get from an annotation-ready plan to a working annotation process.

$ARGUMENTS

## Your role

You are responsible for:
- checking that annotation is actually ready to launch
- choosing between built-in Ellf and built-in standalone Prodigy recipes
- deciding whether an existing custom recipe is sufficient
- deciding when a new custom recipe is required
- determining where the user wants annotation to run
- launching the annotation process
- verifying that it actually starts and is reachable

You do not implement new recipes in this skill. If a new custom workflow is required, use `/ellf-prodigy`.

## Required readiness audit

Before launching anything, read:

- `${CLAUDE_SKILL_DIR}/references/annotation_audit.md`
- `${CLAUDE_SKILL_DIR}/references/builtin_ellf_annotation_recipes.md`
- `${CLAUDE_SKILL_DIR}/references/builtin_prodigy_recipes.md`

Do not launch until you have confirmed:
- the annotation objective is clear
- the schema or review target is stable enough
- the recipe choice actually matches the task
- the input data is ready
- the output dataset or storage target is clear

If the audit fails:
- route methodological problems to `/ellf-project`
- route recipe implementation problems to `/ellf-prodigy`

## Recipe selection

### Built-in first

Prefer a built-in workflow whenever it fits cleanly.

- If the user wants to run on the Ellf cluster, prefer built-in Ellf task recipes.
- If the user wants to run locally, prefer built-in standalone Prodigy recipes.

Use the bundled references as the default selection catalog:
- `${CLAUDE_SKILL_DIR}/references/builtin_ellf_annotation_recipes.md`
- `${CLAUDE_SKILL_DIR}/references/builtin_prodigy_recipes.md`

Key selection rules:
- prefer `.correct` when the user has existing model or LLM predictions to correct; prefer `.manual` when starting from scratch
- prefer `.teach` for active learning when labels are a good fit for binary annotation
- keep `review` strictly for adjudicating existing annotations across datasets or annotators — not as a substitute for `.correct`

### Existing custom recipe

If the user already has a recipe file or published ellf recipe:
- inspect it
- verify it matches the workflow
- use it if it is already sufficient

### New custom recipe required

If built-ins and existing custom recipes do not fit:
- do not force a bad fit
- use `/ellf-prodigy`

## Annotation agents

If the user wants automated annotation:
- first ensure the base task is methodologically sound
- create or launch the task first
- then choose an annotation-capable `agent_recipe`
- create, start, and assign the agent to the task

Do not treat the agent as a replacement for the task. The task is the base annotation workflow.

## Recipe arguments and preview

When using an Ellf recipe:
- run `ellf recipes list` to confirm the recipe is available in the current environment
- run `ellf tasks create <recipe> --help` to get the exact flag names, required vs optional fields, and defaults
- treat the `--help` output as the authoritative source for arg names and required values
- fill fields from context; ask only for values that are required and still unknown

### What to validate locally before cluster launch

For custom or recently changed Ellf recipes, validate two things locally before deploying:

**1. Task creation form** — `ellf-dev preview <recipe-or-module>`

Starts a local server that renders the same form users see in the app when configuring a task. Use this to verify field names, required settings, labels, and defaults are what you expect.

```bash
ellf-dev preview <recipe-or-module>
```

**2. Annotation interface** — `ellf-dev run <recipe> [args]`

Runs the recipe locally as a Prodigy annotation server. Use this to verify the annotation UI itself — the interface, data loading, label rendering — before pushing to the cluster.

```bash
ellf-dev run <recipe> [args]
```

For trusted built-in recipes, skip local validation. For custom recipes or anything recently changed, run at least the form preview before cluster launch.

## Launch

### 1. Confirm unresolved values

If required values are still missing:
- ask only for the unresolved values, tied directly to the recipe fields

### 2. Run the appropriate commands

**Ellf cluster:**

```bash
ellf tasks create <recipe> --name "<task_name>" <args>
ellf tasks start "<task_name>" [--worker-class <class>]
```

If an annotation agent is also requested:

```bash
ellf agents create <agent_recipe> --name "<agent_name>" <agent_args>
ellf agents start "<agent_name>"
ellf agents assign "<agent_name>" --task "<task_name>"
```

**Local Prodigy:**

```bash
python -m prodigy <recipe> <dataset> <source_and_other_args>
```

or `prodigy <recipe> ...` if that is the working command in the environment.

**Other environment:** clarify the execution model before proceeding.

## Verification after launch

A launch is not complete until you verify that the annotation process is usable.

### Ellf cluster

```bash
ellf tasks info "<name>" --json
ellf tasks logs "<name>"
```

Confirm the task exists and is running. If an agent was requested:

```bash
ellf agents info "<agent_name>" --json
```

Confirm it is running and assigned to the task.

### Local Prodigy

Confirm the process started without immediate errors. Capture the local URL from the startup output and verify it is reachable.

### If launch fails

- inspect the immediate error or logs
- fix simple command or configuration issues when possible
- if the issue is operational, use `/ellf-monitor` (or consult `/ellf-ops` for the full command reference)
- if the issue is recipe capability or UI design, use `/ellf-prodigy`

When you finish:
- state whether the setup passed the readiness audit
- state which recipe path you selected
- state which runtime target will be used
- summarize the launch spec clearly
- if not launching, explain exactly what is missing and where you are routing the user next
