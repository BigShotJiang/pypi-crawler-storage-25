# Built-in Standalone Prodigy Recipes

Use this reference when the user wants to run annotation locally with Prodigy
instead of on the Ellf cluster.

Prefer built-ins whenever they fit. Delegate to `ellf-prodigy` only when the
built-ins or an existing custom recipe are not enough.

---

## Named Entity Recognition

| Recipe | Use for |
|---|---|
| `ner.manual` | Manual entity annotation |
| `ner.correct` | Correct model predictions |
| `ner.teach` | Active-learning binary review |
| `ner.llm.correct` | Correct LLM-assisted predictions |

## Span Categorization

| Recipe | Use for |
|---|---|
| `spans.manual` | Manual overlapping span annotation |
| `spans.correct` | Correct span predictions |

## Text Classification

| Recipe | Use for |
|---|---|
| `textcat.manual` | Manual text classification |
| `textcat.correct` | Correct classifier predictions |
| `textcat.teach` | Active-learning classification |
| `textcat.llm.correct` | Correct LLM-assisted predictions |

## Part-of-speech tagging

| Recipe | Use for |
|---|---|
| `pos.correct` | Correct POS predictions |
| `pos.teach` | Active-learning POS annotation |

## Sentence segmentation

| Recipe | Use for |
|---|---|
| `sent.correct` | Correct sentence boundary predictions |
| `sent.teach` | Active-learning sentence segmentation |

## Dependency parsing

| Recipe | Use for |
|---|---|
| `dep.correct` | Correct dependency predictions |
| `dep.teach` | Active-learning dependency annotation |

## Coreference resolution

| Recipe | Use for |
|---|---|
| `coref.manual` | Manual coreference annotation |

## Relations and review

| Recipe | Use for |
|---|---|
| `rel.manual` | Relation annotation |
| `review` | Review and adjudicate prior annotations across datasets or annotators |

## Selection rules

- Prefer `.correct` when the user already has usable predictions.
- Prefer `.manual` when there is no model assistance yet.
- Prefer `.teach` only when the workflow and labels are a good fit for
  active learning.
- Use `review` for adjudication, conflict resolution, or reviewing existing
  annotation datasets, not as a substitute for `.correct`.
- If the user needs a custom UI, complex workflow, routing, or validation logic
  that built-ins cannot express, delegate to `ellf-prodigy`.
