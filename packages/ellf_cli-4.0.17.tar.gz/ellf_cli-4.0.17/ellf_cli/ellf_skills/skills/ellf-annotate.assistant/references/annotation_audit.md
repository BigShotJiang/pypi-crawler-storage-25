# Annotation Audit Reference

Quick-reference for auditing an annotation plan before launching a recipe.
This covers the checks ellf-annotate runs in Step 6. For deep strategic
questions (team structure, agile workflow, full schema redesign), escalate to
ellf-project.

---

## Schema Quality Checklist

These checks catch design problems that waste annotation effort or produce
training data the model can't learn from.

### The factoring principle

**Separate what the model predicts from what the business logic computes.**

The model should predict things determinable from text alone. Business rules
combine predictions downstream.

- BAD: VICTIM_NAME, CRIME_LOCATION — couples semantic roles with entity
  recognition. Needs far more data, far more brittle.
- GOOD: PERSON, LOCATION (generic entities) + rules to assign roles.

**Quick test**: Can you determine the label from the text and general language
knowledge alone? If the answer needs external knowledge or facts that change
over time, it's business logic — factor it out.

### Label set size

More than 6-8 labels per pass creates cognitive overload. Annotator consistency
drops, inter-annotator agreement falls, and the model receives noisier signal.

**If > 6 labels**: recommend multi-pass (labels-first iteration). Each pass
focuses on 1-3 related labels. Use model predictions to pre-annotate subsequent
passes.

### Task complexity

Prefer simpler annotation interfaces when possible:
- Text classification > NER > relation extraction
- Binary decisions > multi-label decisions
- Multiple-choice > free-form span selection

If a relation extraction problem can be reframed as classification + NER +
rules, it should be.

### Common red flags

| Red flag | What to do |
|---|---|
| Labels encode business logic | Escalate to ellf-project |
| > 8 labels in one pass | Recommend multi-pass, or escalate if labels need redesign |
| Composite labels (COMPENSATED_EXECUTIVE) | Factor into components (PERSON + COMPENSATION + rules) |
| Labels require external knowledge | Factor out — model learns language patterns only |
| Annotation mirrors output schema | Redesign — annotation schema ≠ output schema |

---

## Annotation Strategy Quick Decisions

For routine setups, use these defaults. Escalate to ellf-project when
the situation is non-standard or the user needs deeper discussion.

### Annotator count

- **Pilot phase**: 1 domain expert (not outsourced, not crowdsourced)
- **Scaling**: 2-3 annotators with overlap for agreement measurement
- **Escalate if**: large team (5+), outsourcing planned, no domain expert

### Bot annotators (LLM pre-annotation)

- **Good fit**: well-defined labels, high-volume data, correction workflow
- **Poor fit**: novel/ambiguous categories, highly domain-specific labels
- **Default**: recommend if > 500 examples needed and labels are standard NER/textcat

### Annotation overlap

- **Pilot**: no overlap needed (single annotator)
- **Scaling default**: 10-20% double-annotated for agreement measurement
- **Escalate if**: regulated domain, quality-critical application, team > 3

### Single vs multi-pass

- **≤ 5 labels**: single pass is fine
- **6-8 labels**: consider multi-pass, recommend if annotators report difficulty
- **> 8 labels**: multi-pass required (labels-first iteration)

### Quality control

- **Always**: validation callbacks for schema constraints
- **Recommended**: gold-standard examples for onboarding new annotators
- **For teams**: review queue for disagreements

---

## Recipe Fit Checks

These catch cases where a different recipe would be significantly more efficient.

| Situation | Suggestion |
|---|---|
| User picks `ner.manual` but has a trained model | Suggest `ner.correct` — faster (correct vs annotate from scratch) |
| User picks `ner.manual` but has existing patterns | Use patterns for pre-annotation, then `ner.correct` to review |
| User picks `textcat.manual` but has a trained classifier | Suggest `textcat.correct` |
| User picks `spans.manual` but has a trained spans model | Suggest `spans.correct` |
| Large dataset, no model assistance | Suggest active learning recipe (`.teach` variants) |
| Complex UI needs (custom blocks, multiple views) | Delegate to ellf-prodigy for custom recipe |

---

## Escalation Triggers

Escalate to **ellf-project** (via Skill tool) when:

- Labels encode business logic and need redesign
- Task decomposition is needed (complex task → simpler sub-tasks)
- Annotation strategy questions can't be answered with defaults above
- User is unsure about the overall approach (rules vs ML vs LLM)
- Schema has fundamental issues that a quick fix won't solve

Pass the specific concern, labels, data context, and what you need answered.
Project-advice handles focused questions — it won't run a full consultation
unless one is needed.
