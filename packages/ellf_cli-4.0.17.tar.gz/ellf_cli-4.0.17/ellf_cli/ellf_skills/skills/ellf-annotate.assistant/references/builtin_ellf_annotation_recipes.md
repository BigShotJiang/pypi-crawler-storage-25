# Built-in Ellf Annotation Recipes

Use this reference to decide whether the user's annotation workflow can be
handled by a built-in Ellf recipe.

Ellf supports three recipe kinds:
- `task_recipe` for annotation and review workflows
- `agent_recipe` for autonomous annotators and background workers
- `action_recipe` for batch jobs and one-off executions

For `ellf-annotate`, the primary concern is choosing the right built-in
`task_recipe` and then deciding whether an `agent_recipe` should be assigned to
the task.

Always confirm current cluster availability with the platform recipe discovery
tools (`mcp__pam__recipe_list`) before creating anything. Treat the task recipes below as
the canonical built-in annotation and review categories, but still verify what
is actually installed and available on the connected cluster.

---

## Built-in task recipes

These are the built-in Ellf task recipe categories for annotation and review
workflows.

| Recipe | Use for |
|---|---|
| `ner` | Named entity recognition |
| `spans` | Overlapping span annotation / span categorization |
| `textcat` | Text classification |
| `relations` | Relation extraction |
| `coref` | Coreference annotation |
| `dep` | Dependency parsing |
| `pos` | Part-of-speech tagging |
| `terms` | Terminology / gazetteer building |
| `image` | Image annotation |
| `audio` | Audio annotation |
| `video` | Video annotation |
| `curate` | Data curation / exploration |
| `review` | Review and correction of prior annotations |
| `sent` | Sentence segmentation |

## Annotation-capable agent recipes

Ellf also supports `@agent_recipe` workflows for automated annotation. These
should only be used after the base annotation task is sound.

Do not assume a fixed built-in catalog of annotation agents from this document.
Unlike task recipes, agent recipes should be discovered from the current
environment with `mcp__pam__recipe_list` before proposing or creating one.

Typical pattern:
1. create or identify the annotation task
2. verify the schema and task setup are stable
3. choose an annotation-capable agent recipe from `mcp__pam__recipe_list`
4. create and start the agent
5. assign the agent to the task

Do not start with the agent recipe first. The task recipe is the base workflow;
the agent recipe augments it.

Use an agent when:
- the annotation task is already well-defined
- the schema is stable enough for automated annotation
- the user wants background annotation, prelabeling, or autonomous completion

Do not use an agent as a substitute for clarifying a weak annotation design.

## Selection rules

- Prefer a built-in task recipe whenever it fits without bending the schema.
- Use `review` when the user is correcting, adjudicating, or reviewing existing
  annotations rather than creating annotations from scratch.
- If the user needs a custom interface, multi-view workflow, unusual routing,
  or annotation logic the built-ins cannot express cleanly, delegate to
  `ellf-prodigy`.
