---
name: ellf-annotate
description: "Set up and launch annotation in the Ellf cluster once the methodology, schema, and data are ready. Use when the user wants to start annotating data in Ellf, launch an annotation task, choose the right built-in Ellf recipe, verify that annotation is ready to launch, run a review workflow, or add an annotation agent to a task. Also trigger on \"I want to annotate\", \"start annotation\", \"set up a labeling task\", \"which Ellf recipe should I use\", \"launch a review task\", \"start review\", \"set up an annotation agent\", or \"help me run annotation in Ellf\". This skill is the annotation readiness gatekeeper: it applies the audit checklist before launch, prefers built-in Ellf task recipes when possible, and delegates to `/ellf-prodigy` when a new custom recipe must be implemented."
argument-hint: "[describe what you want to annotate]"
---

# Launch Annotation In Ellf

Help the user get from an annotation-ready plan to a working Ellf task.

$ARGUMENTS

## Your role

You are responsible for:
- checking that annotation is ready to launch
- choosing the right built-in Ellf annotation and/or agent task 
- deciding whether an existing custom recipe is sufficient
- deciding when a new custom recipe is required
- setting up the Ellf task
- optionally setting up an annotation agent after the task is sound
- verifying that the task is actually running and accessible

You do not implement new recipes in this skill. If the workflow requires a new custom recipe or custom interface, use `/ellf-handoff` to route the implementation to the coding workflow.

## Required readiness audit

Before choosing a recipe or building a launch spec, read:

- `${CLAUDE_SKILL_DIR}/references/annotation_audit.md`
- `${CLAUDE_SKILL_DIR}/references/builtin_ellf_annotation_recipes.md`

The audit exists because launching with a poorly designed schema or a mismatched recipe wastes annotation effort and produces training data the model can't learn from. Use it to catch problems before you touch the platform.

Do not launch until you have confirmed:
- the annotation objective is clear
- the schema or review target is stable enough
- the recipe choice actually matches the task
- the input data is ready
- the target dataset is clear

If the audit surfaces a problem:
- methodological issues (schema design, task decomposition) → route to `/ellf-project`
- recipe implementation needs (custom UI, routing logic) → route to `/ellf-handoff`

## Recipe selection

### Built-in task recipe first

Prefer a built-in Ellf task recipe whenever it fits cleanly.
The built-in recipes are documented in `${CLAUDE_SKILL_DIR}/references/builtin_ellf_annotation_recipes.md`

Call `mcp__pam__recipe_list` to confirm the recipe is available in the current environment before committing to it.

### Existing custom recipe

If the user names an existing cluster recipe and it matches the workflow, use it.

### New custom recipe required

If the audit shows the user needs a custom interface, routing logic, or annotation flow that built-ins cannot express cleanly:
- do not force a bad built-in fit
- use `/ellf-handoff` to assign custom recipe implementation to the coding agent
- describe what the custom recipe must do

## Annotation agents

If the user wants automated annotation:
- first ensure the base task is methodologically sound
- create and start the task first
- then identify an annotation-capable `agent_recipe`
- create and start the agent
- assign the agent to the task

Do not treat the agent as a replacement for task setup. The task is the base annotation workflow.

## Recipe arguments

Once the recipe is selected:
- call `mcp__pam__recipe_list` to find the recipe ID
- call `mcp__pam__recipe_prepare_create` with the recipe ID and any known partial args
- treat the returned field spec as the authoritative source for: exact arg keys, required vs optional fields, missing required values, and dataset/asset/secret validation — this is the assistant-side equivalent of running `ellf-dev preview` locally
- fill args from context and the project plan where possible
- ask only for the values `mcp__pam__recipe_prepare_create` reports as missing and required

The annotation interface itself (what annotators see) cannot be previewed from the assistant. If the user needs to verify the annotation UI before cluster launch, they should use `ellf-dev run <recipe> [args]` in their local coding environment.

If too many required values are still missing, or the user would be better off reviewing the configuration visually, direct them to the appropriate task creation flow in the app instead of guessing.


## Launch flow

### 1. Confirm unresolved values

If required values are still missing:
- ask only for the missing values, tied directly to the recipe fields
- confirm the full configuration with `AskUserQuestion` before creating

### 2. Create the task

```
mcp__pam__task_create(
  recipe_id="<from recipe_list>",
  name="<task_name>",
  args=<resolved from recipe_prepare_create>,
  worker_class="<class if needed>"
)
```

### 3. Read back the created task

Call `mcp__pam__task_read` with the returned task ID. You need the full object to build the start payload — specifically `id`, `name`, `plan.container`, `plan.recipe_name`, `plan.args`, `plan.positional_fields`, `plan.cli_names`, `plan.package_name`, and `plan.objects`.

### 4. Start the task

```
mcp__broker__broker_request(
  method="POST",
  path="/api/v1/jobs/start-job",
  body={
    "job_id": "<task.id>",
    "job_type": "task",
    "name": "<task.name>",
    "container": "<task.plan.container>",
    "plan": {
      "recipe_name": "<task.plan.recipe_name>",
      "args": "<task.plan.args>",
      "positional_fields": "<task.plan.positional_fields>",
      "cli_names": "<task.plan.cli_names>",
      "package_name": "<task.plan.package_name>",
      "objects": "<task.plan.objects>"
    }
  }
)
```

Do not omit fields from `plan`.

### 5. Add an annotation agent if requested

If the user wants automated annotation:
1. call `mcp__pam__recipe_list` to find an annotation-capable agent recipe
2. call `mcp__pam__recipe_prepare_create` to get the agent args
3. create the agent with `mcp__pam__agent_create`
4. read it back with `mcp__pam__agent_read` to get the full plan
5. start it via broker `/api/v1/jobs/start-job` with `"job_type": "agent"`
6. assign it with `mcp__pam__task_assign_bot(task_id=..., agent_id=...)`

## Verification after launch

A launch is not complete until you verify the task is usable.

After start:
- check broker status at `GET /api/v1/jobs/{id}/status`
- confirm the task is running or healthy
- provide the task mention/link and tell the user where to open it in the app
- if an agent was added, confirm it is assigned with `mcp__pam__task_bots_read`

If startup or assignment fails:
- inspect the broker error or logs at `GET /api/v1/jobs/{id}/logs`
- if this is an operational problem, use `/ellf-monitor` (or consult `/ellf-ops` for the relevant broker/PAM commands)
- if this is a recipe-capability problem, use `/ellf-handoff`

When you finish:
- state whether the setup passed the readiness audit
- state which recipe path you selected
- summarize the launch spec
- if not launching, explain exactly what is missing and where you are routing the user next
