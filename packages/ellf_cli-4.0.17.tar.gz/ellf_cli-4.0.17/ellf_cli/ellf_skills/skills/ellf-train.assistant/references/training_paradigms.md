# Training Paradigms

Instructions for non-standard training approaches. Load this file when the
user's situation calls for pretraining, active learning, or LLM distillation.

---

## Pretraining tok2vec

Use when: the target domain is very different from general English (legal,
biomedical, financial, etc.) and you have a large unlabeled corpus in that
domain (100k+ documents).

Pretraining learns domain-specific word representations from unlabeled text.
The pretrained tok2vec weights are then used to initialize the supervised
training, giving the model a head start on domain-specific language.

### When It Helps
- Domain has specialized vocabulary not well-covered by general models
- You have plenty of raw text but limited labeled data
- General pretrained models (en_core_web_lg) underperform on domain text

### When to Skip
- Domain is close to general English (news, social media, general web)
- You already get good results with en_core_web_lg fine-tuning
- You have very little raw text (< 10k documents)

### Pretraining Objectives

Query KB for "spacy pretrain objectives" for latest details.

**Character-based objective** (`characters`):
- Predicts characters in each word from context
- Good when domain has unusual word forms (chemical names, legal terms)
- Works with any text, no vectors needed

**Vector-based objective** (`vectors`):
- Predicts pretrained word vectors from context
- Good when domain vocabulary overlaps with vector vocabulary
- Requires pretrained vectors (e.g. from `en_core_web_lg`)

### Setup

1. **Prepare raw text** — one document per line in a `.jsonl` file:
   ```jsonl
   {"text": "First document text here..."}
   {"text": "Second document text here..."}
   ```

2. **Generate pretrain config**:
   ```bash
   python -m spacy init config pretrain.cfg --lang en --pipeline ner \
     --pretraining
   ```
   This adds a `[pretraining]` block to the config.

3. **Configure the objective** in `pretrain.cfg`:
   ```ini
   [pretraining]
   max_epochs = 3
   dropout = 0.2
   n_save_every = null
   component = "tok2vec"
   layer = ""

   [pretraining.batcher]
   @batchers = "spacy.batch_by_words.v1"
   size = 3000

   [pretraining.corpus]
   @readers = "spacy.JsonlCorpus.v1"
   path = "raw_text.jsonl"

   [pretraining.objective]
   @architectures = "spacy.PretrainCharacters.v1"
   # Or: @architectures = "spacy.PretrainVectors.v1"
   ```

4. **Run pretraining**:
   ```bash
   python -m spacy pretrain pretrain.cfg ./pretrain-output --code ellf_logger.py
   ```
   This produces weight files in `pretrain-output/`.

5. **Use pretrained weights in training**:
   ```ini
   [training]
   # ... other settings ...

   [initialize]
   init_tok2vec = "pretrain-output/model-last.bin"
   ```

6. **Train normally**:
   ```bash
   python -m spacy train config.cfg --output ./output --code ellf_logger.py
   ```

### Monitoring Pretraining
Pretraining produces loss values but no task-specific scores (there are no
labels). Watch for:
- Loss should decrease steadily
- NaN loss → reduce learning rate
- Very slow convergence → try the other objective (characters ↔ vectors)

---

## Active Learning Loop

Use when: you have some labeled data and want to maximize the value of
additional annotation effort. The model identifies which examples it's most
uncertain about, so annotators focus on the hardest/most informative cases.

### When It Helps
- Limited annotation budget — need to be strategic about what to annotate
- Large pool of unlabeled data to select from
- Model is already trained but needs improvement on specific patterns

### When to Skip
- You have no model yet (need a baseline first — annotate a random sample)
- Very small data pool (< 1000 unlabeled examples)
- All examples are equally easy/hard

### Workflow

The active learning loop alternates between training and annotation:

```
Train model → Model suggests uncertain examples →
Human annotates suggestions → Add to training data →
Re-train model → ...repeat...
```

### Implementation with Prodigy

Query KB for the specific recipe arguments. The general pattern:

**For NER** — `ner.teach`:
```bash
python -m prodigy ner.teach my_dataset en_core_web_lg ./unlabeled.jsonl \
  --label PERSON,ORG,PRODUCT
```
This uses the model's uncertainty to suggest spans for annotation. The
annotator accepts or rejects each suggestion.

**For textcat** — `textcat.teach`:
```bash
python -m prodigy textcat.teach my_dataset en_core_web_lg ./unlabeled.jsonl \
  --label POSITIVE,NEGATIVE
```

**For spans** — `spans.teach` (if available):
Query KB for `spans.teach` availability and arguments.

### Iteration Strategy

1. **Baseline**: Train on initial labeled data. Record baseline score.
2. **Annotate uncertain**: Run `.teach` recipe. Annotate 100–200 examples.
3. **Re-train**: Export new data, re-train the model.
4. **Check training curve**: Use `spacy debug data` or compare scores.
   - Score improved significantly → another round of annotation
   - Score plateau → diminishing returns, stop or change strategy
5. **Repeat** until target score reached or returns diminish.

### Training Curve Analysis

After each iteration, track:
```
Iteration  Examples  Dev Score  Delta
1          200       0.72       —
2          400       0.79       +0.07
3          600       0.82       +0.03
4          800       0.83       +0.01  ← diminishing returns
```

If delta drops below 0.01, consider:
- Is the remaining error from hard cases the model will never get?
- Would a different architecture help?
- Is the label scheme the bottleneck?

### Active Learning Tips
- Start with a random sample baseline before switching to active learning
- Use `ner.correct` or `textcat.correct` (correction workflow) alongside
  `.teach` (uncertainty sampling) for variety
- Don't only annotate uncertain examples — periodically add random samples
  to avoid selection bias
- Re-train after every 100–200 annotations for best feedback loop

---

## LLM Distillation

Use when: you want a fast, deployable spaCy model but bootstrapping annotation
is expensive. Use an LLM to generate initial annotations, have humans correct
them, then train a supervised model on the corrected data.

### When It Helps
- Cold start — no labeled data at all
- LLM can do the task reasonably well (60%+ accuracy)
- You need a fast, cheap production model (not an LLM API call per prediction)
- Annotation budget exists but is limited

### When to Skip
- LLM can't do the task (too specialized, requires visual context, etc.)
- You already have good labeled data
- LLM API cost is not a concern and latency is acceptable for production

### Workflow

```
LLM generates predictions → Human corrects predictions →
Corrected data → Train supervised spaCy model →
Evaluate → If good enough, deploy spaCy model
```

### Step 1: LLM Annotation with spacy-llm

Query KB for "spacy-llm" and "ner.llm.correct" for latest API.

**Set up spacy-llm config** for the task. Example for NER:

```ini
[nlp]
pipeline = ["llm"]

[components.llm]
factory = "llm"

[components.llm.task]
@llm_tasks = "spacy.NER.v3"
labels = ["PERSON", "ORG", "PRODUCT"]

[components.llm.model]
@llm_models = "spacy.GPT-4.v1"
```

Save as `llm_config.cfg`.

### Step 2: Human Correction with Prodigy

Use Prodigy's correction recipes to have humans fix the LLM's predictions:

**For NER**:
```bash
python -m prodigy ner.llm.correct my_dataset llm_config.cfg ./texts.jsonl \
  --label PERSON,ORG,PRODUCT
```

This shows LLM predictions to the annotator, who corrects mistakes. Much
faster than annotating from scratch — humans only fix errors, not label
everything.

**For textcat**:
```bash
python -m prodigy textcat.llm.correct my_dataset llm_config.cfg ./texts.jsonl \
  --label POSITIVE,NEGATIVE
```

### Step 3: Export and Train

```bash
# Export corrected data
python -m prodigy data-to-spacy ./corpus --ner my_dataset --eval-split 0.2

# Train supervised model
python -m spacy train ./corpus/config.cfg --output ./output --code ellf_logger.py
```

### Step 4: Evaluate and Iterate

Compare the supervised model against the LLM:
- If supervised model ≥ LLM accuracy → deploy supervised model (faster, cheaper)
- If supervised model < LLM accuracy → need more corrected data, iterate
- Check per-label scores to identify weak spots

### Distillation Tips
- Start with 200–500 LLM-corrected examples as a first batch
- Track LLM error rate during correction — if > 50% of predictions need
  fixing, the LLM may not be good enough for this task
- Consider combining distillation with active learning: after initial model,
  use uncertainty sampling to find examples where the supervised model is
  weakest
- Use the correction rate as a signal: high correction rate on certain labels
  means the LLM struggles there, so collect more examples for those labels
- The `/ellf-prodigy` skill can help build custom LLM annotation recipes if
  the built-in ones don't fit

### Cost Considerations
- LLM API costs for initial annotation (varies by provider and volume)
- Human correction is faster than from-scratch annotation (typically 2–5x)
- Supervised model has near-zero marginal inference cost
- Break-even: if you'll run > 10k predictions, distillation usually pays off
