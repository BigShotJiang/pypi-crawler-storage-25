# Training Diagnostics — Problem Classification

Six problem classes for diagnosing training issues. When the user reports a
problem or you detect anomalies in `training_log.jsonl`, classify the issue
and follow the corresponding diagnosis path.

---

## Class 1: Data Issues

Problems with the training data itself — detected before or during training.

### Detection Signals
- `spacy debug data` warnings: missing labels, alignment errors, no evaluation
  data, annotation overlap, no positive/negative examples for a label
- Training starts but score is stuck at 0.0 from step 1
- Error during data loading (missing files, corrupt `.spacy` format)
- Large mismatch between train and dev label distributions

### Root Cause Analysis
1. **No evaluation data** — `eval-split` wasn't set, or dev set is empty.
2. **Missing labels** — labels in data don't match pipeline config. Common when
   data was exported with a different label set than the config expects.
3. **Alignment errors** — token boundaries don't match entity spans. Common
   with custom tokenization or when entities span whitespace.
4. **Insufficient examples** — too few examples per label (< 50 is usually
   too few for NER, < 200 for textcat).
5. **Label overlap / noise** — overlapping spans, contradictory annotations.

### Recommended Fixes
- **No eval data**: Re-export with `--eval-split 0.2` or provide a separate
  dev dataset.
- **Missing labels**: Check `config.cfg` `[components.*.model]` section. Run
  `spacy debug data` to see the mismatch. Re-export or update config.
- **Alignment errors**: Query KB for "token alignment" and "spacy gold align".
  Usually means preprocessing the text differently before annotation.
- **Insufficient examples**: Check `spacy debug data` output for per-label
  counts. If under 50 for NER, consider: annotate more, use active learning
  (`ner.teach`), or bootstrap with LLM (`ner.llm.correct`).
- **Label noise**: Use `review` recipe in Prodigy to audit a random sample.
  Check inter-annotator agreement if multiple annotators.

---

## Class 2: Training Divergence

Loss explodes or becomes NaN — training is broken.

### Detection Signals
- `nan_loss` alert in `training_log.jsonl`
- Loss spike >10x between consecutive evaluation steps
- Loss increases steadily from step 1 (never decreases)
- `RuntimeError` or `ValueError` during training (gradient issues)

### Root Cause Analysis
1. **Learning rate too high** — the default learning rate may be wrong for the
   architecture or data size. Transformer models are especially sensitive.
2. **Numerical instability** — very long documents, extreme loss values, or
   rare edge cases in the data.
3. **Architecture mismatch** — e.g. trying to fine-tune a transformer with
   settings designed for tok2vec, or wrong architecture for the task.
4. **Corrupt data** — specific examples cause numerical issues (very long
   texts, unusual Unicode).
5. **Mixed precision issues** — FP16 training with values outside half-float
   range.

### Recommended Fixes
- **Learning rate**: Reduce by 10x. For transformers, start at 5e-5. For
  tok2vec, try 1e-3 → 1e-4. Query KB for "spaCy learning rate schedule".
- **Numerical instability**: Try `--max-length` to cap document length.
  Check for extremely long texts in the corpus.
- **Architecture mismatch**: Run `spacy debug config` to validate the config.
  Ensure `source` model matches the architecture expectations.
- **Corrupt data**: Run `spacy debug data` to identify problematic examples.
  Filter outliers by length.
- **Immediate NaN**: Often means the initial weights are incompatible with
  the data. Try a different base model or reset with `--initialize.init_tok2vec`.

---

## Class 3: Overfitting

Model memorises training data, dev score plateaus or declines while training
loss keeps improving.

### Detection Signals
- `overfitting` alert in `training_log.jsonl` (dev score declining while
  training loss decreasing — sustained over 3+ eval steps)
- Large gap between training loss and dev score trajectory
- Dev score peaks early (first 20% of training) then declines
- Perfect or near-perfect training score but poor dev score

### Root Cause Analysis
1. **Class imbalance** — one class dominates (e.g., 90/10 split in binary
   textcat). The model learns to always predict the majority class. This is the
   most common cause of low textcat scores and is often invisible until you
   check the label distribution.
2. **Too little data** — model memorises small datasets quickly.
3. **Training too long** — continuing past the point where the best model was
   already saved.
4. **Model too large** — using a transformer when a CNN would suffice for the
   data size.
5. **Insufficient regularisation** — dropout too low, no augmentation.
6. **Train/dev distribution mismatch** — dev set isn't representative.

### Recommended Fixes
- **Class imbalance**: Check the class distribution in your training data. For
  binary textcat, aim for roughly balanced classes (40–60% split). If severely
  imbalanced: annotate more examples of the minority class, or downsample the
  majority class. Use `spacy debug data` to see the distribution. For
  multi-label textcat, check `cats_f_per_type` — labels with few positives
  will underperform.
- **Too little data**: The best model is already saved (`model-best`). Stop
  training. Options: annotate more data, use data augmentation (query KB for
  "spaCy augmenters"), use active learning to find high-value examples.
- **Training too long**: spaCy saves `model-best` automatically based on dev
  score, so the best model is preserved. Consider reducing `max_steps` or
  using `patience` for early stopping. Query KB for "spacy patience early
  stopping".
- **Model too large**: Switch from transformer to CNN/tok2vec. Run architecture
  comparison experiment to verify.
- **Insufficient regularisation**: Increase dropout (0.1 → 0.3). Query KB for
  "spaCy dropout settings".
- **Train/dev mismatch**: Re-split data. Ensure stratified split by label
  distribution.

### Key Insight
Overfitting is normal and expected — it's why spaCy saves `model-best`. The
question is whether the *best* score is good enough. If it is, overfitting
after that point is harmless.

### When Best Score Is Too Low

If the best score is too low (e.g., best F < 0.75 for NER), follow this
priority order — don't skip ahead:

1. **Evaluate first** — run `spacy evaluate` on `model-best` to get per-label
   P/R/F breakdown. You can't diagnose without knowing which labels are failing.
2. **Check class balance** — run `spacy debug data` and check the label
   distribution. For binary textcat, a skewed split (e.g., 85/15) is often the
   primary cause of a low best F1. If imbalanced: annotate more of the minority
   class, or downsample the majority class before retraining.
3. **Check label scheme** — are labels well-defined? Are some labels
   consistently confused? See `evaluation_guide.md` §9 (When to Fix the Schema).
4. **Add more data** — if per-label counts are low (< 50 for NER), more data
   is almost certainly the fix. Use `ner.correct` or similar to annotate more.
5. **Tune training** — increase dropout, add augmentation, adjust early stopping.
   Only try this after confirming labels and data are sound.
6. **Change architecture** — last resort. Only if data is plentiful (500+ per
   label) and scores still plateau.

---

## Class 4: Underfitting

Model fails to learn — scores stay low throughout training.

### Detection Signals
- Dev score never exceeds random baseline after 500+ steps
- Dev score < 0.3 for NER or < 0.5 for binary textcat after full training
- Training loss decreases but dev score doesn't improve
- Score plateaus at a low level early in training

### Root Cause Analysis
1. **Task is too hard for the architecture** — the model doesn't have the
   capacity to learn the patterns.
2. **Wrong base model** — using `blank:en` when fine-tuning would work better.
3. **Not enough training data** — especially for complex tasks with many labels.
4. **Label scheme issues** — labels are ambiguous, inconsistent, or not
   learnable from text alone (require world knowledge).
5. **Wrong task formulation** — trying to solve a task the model architecture
   isn't designed for.

### Recommended Fixes
- **Architecture too weak**: Upgrade from BOW → CNN → transformer. Run
  architecture comparison experiment.
- **Wrong base model**: Switch from `blank:en` to a pretrained model
  (`en_core_web_lg` or `en_core_web_trf`). Query KB for base model options.
- **Not enough data**: Check training curves (`spacy debug data` shows counts).
  If under 200 examples for textcat or 50 per entity type for NER, get more
  data before tuning anything else.
- **Label scheme issues**: Revisit with `/ellf-project`. Apply the
  factoring principle: can the model learn this from text alone? If a label
  requires domain expertise or external knowledge, it may need a different
  approach (rules + model hybrid).
- **Wrong task formulation**: e.g. using `textcat` for a task that's really
  `spancat`, or using `ner` when `rel` is needed. Revisit pipeline design.

### Key Insight
Before tuning hyperparameters, check: (1) is the data good? (2) is the
architecture appropriate? (3) is the task formulation correct? These three
explain 90% of underfitting. Hyperparameter tuning fixes the remaining 10%.

---

## Class 5: Resource Issues

Training fails or is impractical due to compute/memory constraints.

### Detection Signals
- `CUDA out of memory` error
- Training is extremely slow (< 1 step/minute for a small dataset)
- System becomes unresponsive during training
- `RuntimeError: CUDA error` or driver version mismatch
- Disk space errors when saving checkpoints

### Root Cause Analysis
1. **GPU OOM** — batch size too large for GPU memory, or model too large.
2. **No GPU** — transformer training on CPU is impractical.
3. **CUDA version mismatch** — PyTorch/cuDNN version doesn't match GPU driver.
4. **Disk space** — model checkpoints fill up disk (especially transformers).
5. **Memory leak** — rare, usually from custom components.

### Recommended Fixes
- **GPU OOM**: Reduce batch size. For transformers, try
  `[training.batcher.size] = 256` (in words) or use gradient accumulation.
  Query KB for "spaCy batch size GPU memory".
- **No GPU**: Use CPU-compatible architecture (tok2vec + CNN). If transformer
  is needed, use cloud GPU (see Compute Targets).
- **CUDA mismatch**: Check `python -c "import torch; print(torch.cuda.is_available())"`.
  If False, reinstall PyTorch with correct CUDA version. Query KB for "spaCy
  GPU setup".
- **Disk space**: Set `[training.max_epochs]` to limit checkpoints. Clean old
  `output/` directories. Only `model-best` and `model-last` are kept by
  default.
- **Slow training**: Profile with `spacy debug data` to check data size. If
  huge, consider sampling for initial experiments.

---

## Class 6: Catastrophic Forgetting

When fine-tuning a pretrained model, it loses capabilities on tasks it was
originally good at.

### Detection Signals
- Components that worked in the base model (e.g. NER in `en_core_web_lg`)
  degrade after fine-tuning a different component
- Adding a new label causes existing label performance to drop significantly
- Model performs well on new task but loses general language understanding

### Root Cause Analysis
1. **Frozen vs unfrozen components** — fine-tuning shared tok2vec affects all
   components that use it, not just the one being trained.
2. **Learning rate too high for fine-tuning** — large weight updates destroy
   pretrained knowledge.
3. **No data for existing labels** — when adding new labels to NER, the model
   needs to see old labels too, or it forgets them.

### Recommended Fixes
- **Shared embeddings**: If training one component degrades another, consider:
  (a) freezing the shared tok2vec during training with `[training.frozen_components]`,
  (b) using separate embeddings for the new component, or (c) providing
  training data for all components. Query KB for "spaCy frozen components" and
  "shared tok2vec listener".
- **Learning rate**: Use a lower learning rate for fine-tuning (1e-5 for
  transformers). Use warmup to gradually unfreeze. Query KB for "spaCy
  learning rate warmup fine-tuning".
- **Missing labels**: When extending an NER model with new entity types,
  include annotated data for existing types. Use `spacy debug data` to verify
  all labels are represented in training data. Query KB for "spaCy add new
  entity type to existing model".
- **Incremental training**: Consider `spacy train --resume-training` to
  continue from a checkpoint rather than re-initialising.

---

## Diagnostic Workflow

When the user reports a problem or you detect alerts in the log:

1. **Classify** — which problem class(es) apply?
2. **Gather evidence** — read `training_log.jsonl`, check for specific signals
3. **Identify root cause** — narrow down within the class
4. **Query KB** — get specific, grounded fix for the root cause
5. **Present** — explain the diagnosis and proposed fix clearly. Show the
   evidence (log entries, error messages, metric patterns)
6. **Execute fix** — with user approval, implement the fix and re-run
