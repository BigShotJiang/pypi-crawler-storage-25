# Base Model Selection Quick-Reference

Which pretrained model to start from, and when to pick each.

---

## Table of Contents

- [English Models at a Glance](#english-models-at-a-glance)
- [When to Pick Each Model](#when-to-pick-each-model)
- [Decision Flowchart](#decision-flowchart)
- [What's Inside Each Model](#whats-inside-each-model)
- [Word Vectors: Why They Matter](#word-vectors-why-they-matter)
- [Using a Pretrained Model as a Training Base](#using-a-pretrained-model-as-a-training-base)
- [Multilingual and Other Languages](#multilingual-and-other-languages)
- [Transformer Model Details](#transformer-model-details)
- [FAQ](#faq)

---

## English Models at a Glance

All four English models are trained on OntoNotes 5.0 (web text: blogs, news, comments) and share the same 18 NER entity types, ~49 POS tags, and ~46 dependency labels.

### Size, speed, and accuracy

| | `en_core_web_sm` | `en_core_web_md` | `en_core_web_lg` | `en_core_web_trf` |
|---|---|---|---|---|
| **Download size** | 12 MB | 31 MB | 382 MB | 436 MB |
| **Word vectors** | None | 20k unique (300d) | 514k unique (300d) | None (uses RoBERTa) |
| **NER F** | 84.3 | 84.7 | 85.5 | 89.9 |
| **POS accuracy** | 97.3 | 97.3 | 97.4 | 98.1 |
| **Dep UAS** | 91.8 | 91.8 | 92.0 | 95.2 |
| **Dep LAS** | 89.9 | 90.0 | 90.2 | 93.8 |
| **CPU speed** | ~14k WPS | ~12k WPS | ~10k WPS | ~700 WPS |
| **GPU speed** | — | — | ~15k WPS | ~3.8k WPS |
| **Requires GPU** | No | No | No | Practically yes |

WPS = words per second. CPU benchmarks on Intel Xeon; GPU on single NVIDIA GPU. Speed measured end-to-end on 10,000 Reddit comments.

### The key tradeoffs in one sentence

- **sm → md → lg**: Marginal accuracy gains (~1 point NER F), main difference is word vectors for similarity
- **lg → trf**: Significant accuracy jump (+4.4 NER F, +3.6 LAS), but 15x slower on CPU

---

## When to Pick Each Model

### `en_core_web_sm` — Pick when:

- You need the **smallest footprint** (12 MB, fits in serverless/edge deployments)
- You're building a **prototype** or doing initial experiments
- You **don't need `Token.similarity()`** or `Doc.similarity()` based on word vectors
- You're doing **rule-based processing** and just need tokenization + POS + parsing
- Speed is the top priority and accuracy differences of ~1% don't matter

### `en_core_web_md` — Pick when:

- You need **word vectors for similarity** (e.g., finding similar words, clustering) but want to keep the download small (31 MB)
- You're **fine-tuning a custom NER/textcat** model — the 20k vectors provide a meaningful boost over `sm` for training
- Good **all-around choice** when you want vectors without the 382 MB download of `lg`

### `en_core_web_lg` — Pick when:

- You need the **best word vector coverage** (514k vectors, almost no OOV for common English text)
- You're using `Token.similarity()` or `most_similar()` as part of your pipeline
- You're **training a custom model** and want the best CNN-based accuracy — `include_static_vectors = true` in tok2vec gives the biggest boost with `lg` vectors
- You're deploying on CPU and want the **best accuracy without a GPU**
- 382 MB is acceptable for your deployment

### `en_core_web_trf` — Pick when:

- **Accuracy is the top priority** and you have a GPU available
- You need the best NER (+4.4 F over `lg`) or parsing (+3.6 LAS over `lg`) out of the box
- You're using it as a **feature extractor** (freeze transformer, train custom heads on top)
- You're doing **research or benchmarking** where state-of-the-art matters
- Latency is not a hard constraint (batch processing is fine)

### Don't pick `trf` when:

- You're deploying on **CPU only** — at ~700 WPS it's impractical for real-time workloads
- You need **word vectors** for similarity lookups — `trf` doesn't ship with static vectors
- You need **real-time, low-latency inference** — even on GPU it's 4x slower than `lg`
- You're **training a custom model on a small GPU** — the transformer's memory footprint is large. Use `lg` vectors + CNN instead

---

## Decision Flowchart

```
Do you have a GPU for inference?
├─ YES
│   ├─ Is accuracy the top priority? → en_core_web_trf
│   ├─ Need word vectors for similarity? → en_core_web_lg (trf has no vectors)
│   └─ Need speed + decent accuracy? → en_core_web_lg on GPU
│
└─ NO (CPU only)
    ├─ Need word vectors?
    │   ├─ YES, and disk space doesn't matter → en_core_web_lg
    │   └─ YES, but want small download → en_core_web_md
    └─ Don't need vectors
        ├─ Smallest footprint possible → en_core_web_sm
        └─ Otherwise → en_core_web_sm (or md if you might need vectors later)
```

For **training a custom model** (not just using the pretrained pipeline):

```
Do you have a GPU for training?
├─ YES
│   ├─ Fine-tuning the full pipeline → Start from en_core_web_trf, freeze transformer
│   ├─ Training only NER/textcat → Source tok2vec from en_core_web_lg, freeze it
│   └─ Training from scratch with transformer → Use spacy init config --gpu --optimize accuracy
│
└─ NO (CPU training)
    ├─ Have enough data (500+ examples per label) → Train with en_core_web_lg vectors
    ├─ Limited data (50-500 examples) → Train with en_core_web_lg vectors (vectors help most here)
    └─ Very limited data (<50 examples) → Consider rules + en_core_web_lg as-is
```

---

## What's Inside Each Model

### CNN models (sm, md, lg) — pipeline components

| Component | Purpose | Notes |
|-----------|---------|-------|
| `tok2vec` | Shared token embeddings | CNN-based; all components except NER listen to it |
| `tagger` | Fine-grained POS tags | Listens to shared tok2vec |
| `parser` | Dependency parsing + sentence boundaries | Listens to shared tok2vec |
| `attribute_ruler` | Maps TAG → coarse POS | Rule-based, not trainable |
| `lemmatizer` | Lemmatization | Rule-based lookup in sm/md/lg; trainable in some languages |
| `ner` | Named entity recognition | Has its **own independent tok2vec** (not shared) |

**Important detail:** In the CNN models, NER has its own internal tok2vec — it doesn't share with tagger/parser. This means NER and tagger/parser learn different representations. If you're sourcing components, be aware of this asymmetry.

### Transformer model (trf) — pipeline components

| Component | Purpose | Notes |
|-----------|---------|-------|
| `transformer` | RoBERTa-base (768d) | Shared; all components listen to it |
| `tagger` | Fine-grained POS tags | Listens to transformer |
| `parser` | Dependency parsing | Listens to transformer |
| `attribute_ruler` | Maps TAG → coarse POS | Rule-based |
| `lemmatizer` | Lemmatization | Rule-based |
| `ner` | Named entity recognition | Listens to transformer (shared, unlike CNN models) |

**Important detail:** In the transformer model, all trainable components share the same transformer — including NER. This is why the trf model gets a larger accuracy boost: all components benefit from the same rich contextual representations.

### NER entity types (all English models)

All four models recognize the same 18 OntoNotes entity types:

`CARDINAL`, `DATE`, `EVENT`, `FAC`, `GPE`, `LANGUAGE`, `LAW`, `LOC`, `MONEY`, `NORP`, `ORDINAL`, `ORG`, `PERCENT`, `PERSON`, `PRODUCT`, `QUANTITY`, `TIME`, `WORK_OF_ART`

---

## Word Vectors: Why They Matter

### For similarity and search

| Task | `sm` (no vectors) | `md` (20k) | `lg` (514k) | `trf` (contextual) |
|------|-------------------|------------|-------------|---------------------|
| `Token.similarity()` | Works but unreliable | Good for common words | Best coverage | Not applicable |
| `Doc.similarity()` | Rough approximation | Decent | Good | Use transformer embeddings directly |
| `most_similar()` | Not available | Available (20k pool) | Available (514k pool) | Not available |
| OOV (out-of-vocabulary) rate | 100% | ~5-15% of tokens | ~1-3% of tokens | 0% (subword tokenization) |

### For training custom models

Static word vectors give a meaningful accuracy boost when training custom CNN-based models, especially with limited data:

| Training data size | Without vectors | With `lg` vectors | Typical improvement |
|--------------------|-----------------|-------------------|---------------------|
| < 100 examples | Poor | Marginal | Vectors alone can't compensate for too little data |
| 100–500 examples | Weak | Moderate | +2–5 F-score points |
| 500–2000 examples | Decent | Good | +1–3 F-score points |
| 2000+ examples | Good | Good+ | +0.5–2 F-score points |

**To use word vectors during training:**

```ini
[paths]
vectors = "en_core_web_lg"

[components.tok2vec.model.embed]
@architectures = "spacy.MultiHashEmbed.v2"
include_static_vectors = true

[initialize]
vectors = ${paths.vectors}
```

---

## Using a Pretrained Model as a Training Base

### Strategy 1: Source the whole pipeline and fine-tune

Start from a pretrained model and continue training on your domain-specific data.

```ini
[components.tok2vec]
source = "en_core_web_lg"

[components.ner]
source = "en_core_web_lg"

[training]
frozen_components = ["tok2vec"]
annotating_components = ["tok2vec"]
```

Best when: You want to add new entity types or adapt to a new domain while keeping existing capabilities.

### Strategy 2: Source only tok2vec, train fresh components

Use the pretrained embeddings but train your task-specific components from scratch.

```ini
[components.tok2vec]
source = "en_core_web_lg"

[components.ner]
factory = "ner"
# ... fresh NER config ...

[training]
frozen_components = ["tok2vec"]
annotating_components = ["tok2vec"]
```

Best when: Your task or label scheme is different from OntoNotes and you want good embeddings without pretrained biases.

### Strategy 3: Use only the word vectors

Don't source any components — just use the word vectors from `lg` in a fresh pipeline.

```ini
[paths]
vectors = "en_core_web_lg"

[components.tok2vec.model.embed]
@architectures = "spacy.MultiHashEmbed.v2"
include_static_vectors = true

[initialize]
vectors = ${paths.vectors}
```

Best when: You want a clean start but with the benefit of pretrained word representations.

### Strategy 4: Freeze transformer, train lightweight heads

Use the transformer as a frozen feature extractor.

```ini
[components.transformer]
source = "en_core_web_trf"

[components.ner]
factory = "ner"

[components.ner.model.tok2vec]
@architectures = "spacy-transformers.TransformerListener.v1"
grad_factor = 1.0

[training]
frozen_components = ["transformer"]
annotating_components = ["transformer"]
```

Best when: You want transformer-quality features without the cost of training the transformer itself. Much faster training, lower GPU memory.

---

## Multilingual and Other Languages

### Languages with full model suites (sm/md/lg)

| Language | Code | Models | Vectors | Transformer recommendation |
|----------|------|--------|---------|---------------------------|
| English | en | sm, md, lg, trf | Standard (514k in lg) | `roberta-base` |
| German | de | sm, md, lg, trf* | Standard | `bert-base-german-cased` |
| French | fr | sm, md, lg, trf* | Standard | `camembert-base` |
| Spanish | es | sm, md, lg, trf* | Standard | `dccuchile/bert-base-spanish-wwm-cased` |
| Italian | it | sm, md, lg | Standard | — |
| Portuguese | pt | sm, md, lg | Standard | `neuralmind/bert-base-portuguese-cased` |
| Dutch | nl | sm, md, lg | Standard | `GroNLP/bert-base-dutch-cased` |
| Polish | pl | sm, md, lg | Standard | `dkleczek/bert-base-polish-cased-v1` |
| Russian | ru | sm, md, lg | Standard | — |
| Japanese | ja | sm, md, lg, trf | Standard | — |
| Chinese | zh | sm, md, lg, trf | Standard | `bert-base-chinese` |
| Danish | da | sm, md, lg, trf | Standard | `Maltehb/danish-bert-botxo` |
| Norwegian | nb | sm, md, lg | Standard | `NbAiLab/nb-bert-base` |
| Swedish | sv | sm, md, lg | Floret | `KB/bert-base-swedish-cased` |
| Greek | el | sm, md, lg | Standard | `nlpaueb/bert-base-greek-uncased-v1` |
| Romanian | ro | sm, md, lg | Standard | `dumitrescustefan/bert-base-romanian-cased-v1` |
| Finnish | fi | sm, md, lg | Floret | — |
| Korean | ko | sm, md, lg | Floret | — |
| Croatian | hr | sm, md, lg | Floret | — |
| Lithuanian | lt | sm, md, lg | Standard | — |
| Catalan | ca | sm, md, lg, trf | Standard | — |
| Macedonian | mk | sm, md, lg | Standard | — |
| Slovenian | sl | sm, md, lg, trf | Floret | — |
| Ukrainian | uk | sm, md, lg, trf | Floret | — |

\* German, French, and Spanish have `dep` transformer models (syntax only, no NER) rather than full `core` transformer models.

### Multilingual models

| Model | Purpose | NER labels | NER F | Vectors |
|-------|---------|------------|-------|---------|
| `xx_ent_wiki_sm` | Multi-language NER | LOC, MISC, ORG, PER | 83.1 | None |
| `xx_sent_ud_sm` | Multi-language sentence segmentation | — | — | None |

### When to use the multilingual NER model

- **Quick prototype** for a language that doesn't have a dedicated spaCy model
- **Language-agnostic pipeline** that needs to handle mixed-language input
- **Only 4 entity types** (PER, ORG, LOC, MISC) — if you need more, train a custom model

### Floret vectors (special case)

Croatian, Finnish, Korean, Slovenian, Swedish, and Ukrainian use **floret** vectors instead of standard word vectors.

| Feature | Standard vectors | Floret vectors |
|---------|-----------------|----------------|
| OOV handling | Unknown words get zero vectors | No OOV — every token gets a vector via subword hashing |
| `most_similar()` | Supported | Not supported |
| Typical accuracy boost | Good | Better (especially for morphologically rich languages) |
| Vector table size (md) | 20k entries | 50k entries |
| Vector table size (lg) | 200k–514k entries | 200k entries |

Floret is particularly effective for morphologically rich languages (Finnish, Korean) where standard vectors suffer from high OOV rates.

### Picking a model for non-English languages

```
Is there a spaCy model for your language?
├─ YES, with sm/md/lg variants
│   ├─ Apply the same sm/md/lg/trf logic as English
│   └─ Check the transformer column above — if one is listed, you can train a trf pipeline
│
├─ YES, but only xx_ent_wiki_sm (multilingual)
│   ├─ Use it for quick prototyping
│   └─ For production: train a custom model using the recommended transformer for your language
│
└─ NO model available
    ├─ Start with spacy blank("<lang>") for tokenization
    ├─ Use the multilingual transformer: bert-base-multilingual-uncased
    └─ Or find a language-specific transformer on HuggingFace
```

---

## Transformer Model Details

### English: `en_core_web_trf`

| Property | Value |
|----------|-------|
| Transformer | RoBERTa-base |
| Hidden size | 768 |
| Vocab size | 50,265 |
| Tokenizer | Byte-pair encoding (BPE) |
| Window | 144 tokens |
| Stride | 104 tokens |
| `use_fast` | true |

### How strided spans work

Transformer models have a maximum input length. For longer documents, spaCy uses a sliding window (`strided_spans`):

```
Document: [tok1 tok2 tok3 ... tok200 tok201 ... tok400]

Window 1: [tok1  ... tok144]
Window 2: [tok41 ... tok184]    ← overlaps by (144 - 104) = 40 tokens
Window 3: [tok81 ... tok224]
...
```

Each token's final representation is the average of all windows that contain it. The overlap ensures no token is at the very edge of a window (where transformer attention is weakest).

### Memory requirements for training

| Setup | Approximate GPU memory |
|-------|----------------------|
| Inference only | 2–4 GB |
| Training with `accumulate_gradient = 3` | 8–12 GB |
| Training without gradient accumulation | 16–24 GB |
| Training with large batch size | 24+ GB |

If you're getting OOM errors, increase `accumulate_gradient` first (try 3, then 6, then 8).

---

## FAQ

### Q: I'm training a custom NER model from scratch. Which base model should I use?

**If you have a GPU:** Use `spacy init config --gpu --optimize accuracy` to get a transformer-based config. Start from `en_core_web_trf` and freeze the transformer if training is too slow.

**If you're on CPU:** Use `en_core_web_lg` vectors. Set `include_static_vectors = true` in your tok2vec config and `vectors = "en_core_web_lg"` in `[initialize]`. This gives the biggest accuracy boost for CNN-based models.

### Q: Can I mix and match components from different models?

Yes, but with caveats:
- Components that use **listeners** (tok2vec listener or transformer listener) must point to a compatible upstream component
- If you source a component that uses a listener, you should also source the upstream component it listens to, or use `replace_listeners` to decouple it
- Static vectors should match between components — sourcing from `lg` into a pipeline with `md` vectors may degrade performance (warning `W113`)

### Q: The accuracy difference between sm/md/lg is tiny. Why bother with lg?

For the **pretrained pipeline** out-of-the-box, the difference is indeed small (~1 point NER F). The real value of `lg` is:
1. **Word vectors** for similarity and search — `sm` has none
2. **Training base** — when training your own models, `include_static_vectors = true` with `lg` vectors gives a meaningful boost, especially with limited training data
3. **OOV handling** — `lg` has 514k vectors vs 20k in `md`, so far fewer unknown words

### Q: Should I always use the transformer model?

No. Use the transformer when:
- You have a GPU for both training and inference
- Accuracy is more important than speed
- You can afford the latency (~700 WPS on CPU vs ~10,000 WPS for `lg`)

The CNN models (`sm`/`md`/`lg`) are the right choice for:
- CPU-only deployment
- Real-time applications
- Resource-constrained environments
- When the 1–4 point accuracy gap doesn't justify the infrastructure cost

### Q: I need a model for a language not listed above. What do I do?

1. Check if spaCy has a blank language class: `spacy.blank("xx")`. If tokenization works, you're halfway there.
2. Use `xx_ent_wiki_sm` for quick NER prototyping (4 entity types).
3. For custom training, use `bert-base-multilingual-uncased` as the transformer or find a language-specific model on HuggingFace.
4. For non-transformer training, train floret vectors on your language's text corpus using the floret library, then use them in a CNN pipeline.

### Q: How do I benchmark my model against the pretrained one?

```bash
# Evaluate pretrained model on your dev set
python -m spacy evaluate en_core_web_lg ./dev.spacy --output pretrained_scores.json

# Evaluate your custom model on the same dev set
python -m spacy evaluate ./model-best ./dev.spacy --output custom_scores.json

# Compare NER F-scores, parsing LAS, etc. side by side
```

Always compare on **the same dev set**. Scores from different datasets are not comparable.

### Q: What if I only need NER and nothing else?

You can disable components you don't need for faster inference:

```python
nlp = spacy.load("en_core_web_lg", disable=["tagger", "parser", "attribute_ruler", "lemmatizer"])
```

Or configure a pipeline with only the components you need during training. For NER-only, the model doesn't need a shared tok2vec — NER in the CNN models already has its own internal tok2vec.
