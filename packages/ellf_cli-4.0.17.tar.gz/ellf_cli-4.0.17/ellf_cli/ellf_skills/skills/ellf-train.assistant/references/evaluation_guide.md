# Evaluation & Results Interpretation Guide

An opinionated guide to understanding what your spaCy training metrics actually mean, diagnosing problems from evaluation output, and making the right decisions about what to fix next.

---

## Table of Contents

- [Reading spacy evaluate Output](#1-reading-spacy-evaluate-output)
- [Per-Label Error Analysis](#2-per-label-error-analysis)
- [Training Curve Diagnostics](#3-training-curve-diagnostics)
- [The Diagnosis Decision Tree](#4-the-diagnosis-decision-tree)
- [Common Metric Patterns and What They Mean](#5-common-metric-patterns-and-what-they-mean)
- [Precision vs Recall Imbalances](#6-precision-vs-recall-imbalances)
- [When to Add More Data](#7-when-to-add-more-data)
- [When to Change Architecture](#8-when-to-change-architecture)
- [When to Fix the Schema](#9-when-to-fix-the-schema)
- [Component-Specific Evaluation Guide](#10-component-specific-evaluation-guide)
- [Threshold Tuning](#11-threshold-tuning)
- [Speed vs Accuracy Tradeoffs](#12-speed-vs-accuracy-tradeoffs)
- [Evaluation Pitfalls](#13-evaluation-pitfalls)

---

## 1. Reading `spacy evaluate` Output

### Running evaluation

```bash
# Basic evaluation
python -m spacy evaluate ./model-best ./dev.spacy

# Save full metrics as JSON (includes per-type breakdowns)
python -m spacy evaluate ./model-best ./dev.spacy --output metrics.json

# Per-component breakdown (which component contributes what)
python -m spacy evaluate ./model-best ./dev.spacy --per-component

# Render dependency parses as HTML for manual inspection
python -m spacy evaluate ./model-best ./dev.spacy --displacy-path ./parses
```

### What the output columns mean

The console table during training and evaluation shows:

| Column | Meaning | What to watch |
|--------|---------|---------------|
| `E` | Epoch number | How many passes over the data |
| `#` | Training step | Monotonically increasing |
| `Loss <component>` | Training loss for that component | Should generally decrease |
| Score columns | Dev set metrics (multiplied by 100) | Should generally increase |
| `Score` | Weighted combination of all score columns | Used to pick "best" checkpoint |

The **weighted score** is computed as:

```
Score = sum(metric_value * weight for metric, weight in score_weights.items())
```

Only metrics with non-null, non-zero weights contribute. A metric set to `null` is excluded from both the score and the log output. A metric set to `0.0` is logged but doesn't affect checkpoint selection.

### Complete metric reference

Every metric that `spacy evaluate` can report:

**Tokenization:**
- `token_acc` / `token_p` / `token_r` / `token_f` — How well the tokenizer splits text into tokens

**NER:**
- `ents_p` — Of all entities the model predicted, what fraction were correct (precision)
- `ents_r` — Of all entities in the gold data, what fraction did the model find (recall)
- `ents_f` — Harmonic mean of precision and recall (F1)
- `ents_per_type` — P/R/F broken down by entity label

**Dependency Parsing:**
- `dep_uas` — Unlabeled Attachment Score: is the head token correct? (ignoring label)
- `dep_las` — Labeled Attachment Score: are both the head and the dependency label correct?
- `dep_las_per_type` — LAS broken down by dependency label
- `sents_p` / `sents_r` / `sents_f` — Sentence boundary detection accuracy

**Tagging:**
- `tag_acc` — Fine-grained POS tag accuracy
- `pos_acc` — Coarse POS tag accuracy

**Morphology:**
- `morph_acc` — Exact match of the full morphological feature bundle
- `morph_micro_p` / `morph_micro_r` / `morph_micro_f` — Micro-averaged across all features
- `morph_per_feat` — Breakdown by morphological feature (Tense, Number, Case, etc.)

**Lemmatization:**
- `lemma_acc` — Token-level lemma accuracy

**Text Classification:**
- `cats_score` — Overall score (macro F for multi-class, macro AUC for multi-label)
- `cats_micro_p` / `cats_micro_r` / `cats_micro_f` — Micro-averaged across all labels
- `cats_macro_p` / `cats_macro_r` / `cats_macro_f` — Macro-averaged (mean of per-label scores)
- `cats_macro_auc` — Macro-averaged AUC-ROC
- `cats_f_per_type` — F-score per label
- `cats_auc_per_type` — AUC per label

**Span Categorization:**
- `spans_sc_p` / `spans_sc_r` / `spans_sc_f` — Span-level P/R/F (key = `sc` by default)
- `spans_sc_per_type` — Per-label P/R/F

**Entity Linking:**
- `nel_micro_p` / `nel_micro_r` / `nel_micro_f` — Linking accuracy (separate from NER)
- `nel_f_per_type` — Per-entity-type linking scores

**Speed:**
- `speed` — Words per second (WPS)

### Reading the JSON output

The `--output metrics.json` flag produces the full score dictionary. The critical sections to inspect:

```json
{
  "ents_f": 0.85,
  "ents_p": 0.88,
  "ents_r": 0.82,
  "ents_per_type": {
    "PERSON": {"p": 0.95, "r": 0.93, "f": 0.94},
    "ORG":    {"p": 0.82, "r": 0.75, "f": 0.78},
    "DATE":   {"p": 0.90, "r": 0.88, "f": 0.89},
    "MONEY":  {"p": 0.60, "r": 0.30, "f": 0.40}
  }
}
```

**Always look at `per_type` breakdowns.** Aggregate F-scores hide that one label might be at 94% while another is at 40%. The aggregate is dominated by the most frequent labels.

---

## 2. Per-Label Error Analysis

### Step 1: Get per-type scores

```bash
python -m spacy evaluate ./model-best ./dev.spacy --output metrics.json
```

Then inspect `ents_per_type`, `spans_sc_per_type`, `cats_f_per_type`, `dep_las_per_type`, or `morph_per_feat` in the JSON.

### Step 2: Sort labels by F-score

Rank your labels from worst to best. The bottom labels are where to focus your effort. A label at F=0.40 has more room for improvement than one at F=0.92.

### Step 3: Diagnose each underperforming label

For each low-scoring label, check the P/R split:

| Pattern | Diagnosis | Likely Cause |
|---------|-----------|--------------|
| **High P, low R** | Model is conservative — correct when it predicts, but misses many | Too few positive examples; or the label's surface patterns are diverse and underrepresented |
| **Low P, high R** | Model over-predicts — finds most instances but also makes many false predictions | Label is ambiguous or overlaps with another label; annotation inconsistency |
| **Low P, low R** | Model hasn't learned this label | Too few examples, or the label is poorly defined |
| **High P, high R** | Label is working well | No action needed |

### Step 4: Count examples per label

Cross-reference with `spacy debug data` output:

```bash
python -m spacy debug data config.cfg -V
```

The verbose output shows the count of examples per label. Common patterns:

| Examples per label | Expected quality | Action |
|--------------------|-----------------|--------|
| < 20 | Very poor | The model cannot learn this reliably. Either add data or remove the label |
| 20–50 | Marginal | Expect inconsistent results. Prioritize adding more examples |
| 50–200 | Reasonable | Should work for clear-cut labels. Ambiguous labels need more |
| 200–500 | Good | Sufficient for most labels. Focus on annotation consistency |
| 500+ | Strong | Diminishing returns from adding more data; focus on consistency and edge cases |

### Step 5: Inspect actual errors

For NER, generate predictions on your dev set and manually compare:

```python
import spacy
from spacy.tokens import DocBin

nlp = spacy.load("./model-best")
doc_bin = DocBin().from_disk("./dev.spacy")
nlp_blank = spacy.blank("en")

for gold_doc in doc_bin.get_docs(nlp_blank.vocab):
    pred_doc = nlp(gold_doc.text)
    gold_ents = {(e.start_char, e.end_char, e.label_) for e in gold_doc.ents}
    pred_ents = {(e.start_char, e.end_char, e.label_) for e in pred_doc.ents}

    false_negatives = gold_ents - pred_ents  # missed by model
    false_positives = pred_ents - gold_ents  # predicted but wrong

    if false_negatives or false_positives:
        print(f"Text: {gold_doc.text[:80]}...")
        for fn in false_negatives:
            print(f"  MISSED: '{gold_doc.text[fn[0]:fn[1]]}' ({fn[2]})")
        for fp in false_positives:
            print(f"  WRONG:  '{pred_doc.text[fp[0]:fp[1]]}' ({fp[2]})")
```

**Look for patterns in errors:**
- Are false negatives concentrated in specific contexts? (e.g., entities at the start of sentences, entities in parentheses)
- Are false positives confusing two labels? (e.g., ORG predicted where PERSON is gold)
- Are boundary errors common? (e.g., "the United States" vs "United States")

---

## 3. Training Curve Diagnostics

The training log shows loss and evaluation scores at each checkpoint. The *shape* of these curves tells you what's happening.

### Healthy training curve

```
Loss: High → steadily decreasing → flattening
Score: Low  → steadily increasing → flattening
```

This is the ideal. The model is learning from the data and converging. The flattening indicates the model has extracted most of the learnable signal from the data. The gap between train loss reaching its floor and dev score reaching its ceiling should be small.

### Curve shape diagnosis

#### Concave loss curve (loss drops fast, then flattens)

```
Loss:  ████▆▄▃▂▂▂▂▂▂▁▁▁▁▁▁▁
Score: ▁▂▃▄▅▆▆▇▇▇▇▇▇▇▇▇▇▇▇
```

**Meaning:** Normal, healthy convergence. The model learned quickly and is now in diminishing returns territory.

**What to do:** This is fine. If the final score is good enough, stop here. If the score plateaus at an unsatisfying level, the data or schema may be the bottleneck — not the training duration.

#### Loss plateau (loss stops decreasing early)

```
Loss:  ████████████████████████
Score: ▁▁▁▂▂▂▂▂▂▂▂▂▂▂▂▂▂▂▂▂
```

**Meaning:** The model is barely learning. The optimization is stuck.

**Check these causes:**
1. **Learning rate too low** — Increase it (try 2x–5x)
2. **Model capacity too small** — The architecture can't represent the patterns in the data. Try a wider/deeper tok2vec
3. **Bad data** — Annotations are contradictory or missing. The model gets conflicting signals and can't learn a consistent mapping
4. **Wrong task framing** — The label scheme is inherently ambiguous. The model can't learn what the annotators couldn't agree on

#### Oscillating loss (loss bounces up and down)

```
Loss:  █▄█▃█▄█▂█▃█▂█▃█▂█▃█▂
Score: ▁▃▂▄▃▅▄▅▄▆▅▆▅▆▅▇▆▇▆
```

**Meaning:** Training is noisy. Each batch pushes the model in a different direction.

**Check these causes:**
1. **Batch size too small** — Each batch isn't representative. Increase batch size or use `accumulate_gradient`
2. **Learning rate too high** — The optimizer overshoots. Reduce learning rate
3. **Contradictory annotations** — The same text has different labels in different examples. Audit your data for inconsistencies
4. **Extreme class imbalance** — Rare labels get overwhelmed by common ones

#### Loss decreases, score plateaus or drops (overfitting)

```
Loss:  ████▃▂▁▁▁▁▁▁▁▁▁▁▁▁▁▁
Score: ▁▂▃▅▆▇▇▆▆▅▅▅▅▅▅▅▅▅▅
```

**Meaning:** The model is memorizing the training data instead of learning generalizable patterns. Training loss keeps improving but dev performance degrades.

**Fix it:**
1. **More training data** — The single most reliable fix for overfitting
2. **Increase dropout** — From 0.1 to 0.2 or 0.3
3. **Data augmentation** — Add lowercase augmentation, orth variants
4. **Earlier stopping** — Reduce `patience` so training stops before overfitting sets in
5. **Reduce model capacity** — Smaller tok2vec width/depth (but only if you've tried the above first)
6. **Increase weight decay** — Raise `L2` in optimizer config

#### Score improves then suddenly drops

```
Loss:  ████▃▂▁▁▁▁▁▁▁█████████
Score: ▁▂▃▅▆▇▇▇▇▇▇▇▃▂▁▁▁▁▁▁
```

**Meaning:** Catastrophic event during training. Often caused by:
1. **NaN loss propagation** — A bad batch caused numerical instability that cascades
2. **Learning rate spike** — If using a schedule, check that it doesn't spike
3. **Data corruption** — A malformed example in the stream

**Fix it:** Check for NaN warnings in the training log. If the problem is a specific bad batch, clean your data. If gradients explode, reduce `grad_clip` (try 0.5 or lower).

#### Flat score from the start

```
Loss:  ████████████████████████
Score: ▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁
```

**Meaning:** The model isn't learning at all. Zero signal.

**Check these causes (in order):**
1. **Annotations are missing** — Your training data doesn't have the annotations the component expects. Run `spacy debug data`
2. **Wrong component for the task** — Using `textcat` (single-label) with multi-label data, or NER without entity annotations
3. **Broken data pipeline** — The corpus reader isn't finding files, or `max_length` filters out all documents
4. **Labels not initialized** — The component didn't see any labels during `initialize()`. Check for error `E143`

---

## 4. The Diagnosis Decision Tree

When your model's scores aren't good enough, work through this tree:

```
Is loss decreasing during training?
├─ NO → Data or config problem
│   ├─ Run: spacy debug data config.cfg
│   ├─ Check: Are annotations present for this component?
│   ├─ Check: Does the training data have enough examples? (>100 min)
│   └─ Check: Is learning rate reasonable? (try 0.001 for CNN, 5e-5 for transformer)
│
└─ YES → Model is learning. Is dev score improving?
    ├─ NO → Overfitting
    │   ├─ Increase dropout (0.2–0.3)
    │   ├─ Add data augmentation
    │   ├─ Add more training data
    │   └─ Try earlier stopping (reduce patience)
    │
    └─ YES → Model is generalizing. Is the final score good enough?
        ├─ YES → Done. Ship it.
        │
        └─ NO → Which labels are underperforming?
            ├─ ALL labels are mediocre
            │   ├─ Need more data (across the board)
            │   ├─ OR: Try a better architecture (larger tok2vec, transformer)
            │   └─ OR: The task is genuinely hard for this approach
            │
            └─ SOME labels are bad, others are fine
                ├─ Bad labels have few examples → Add more data for those labels
                ├─ Bad labels have inconsistent annotations → Fix annotation guidelines
                ├─ Bad labels overlap with other labels → Refine the label scheme
                └─ Bad labels have diverse surface forms → More data + consider rules as supplement
```

---

## 5. Common Metric Patterns and What They Mean

### NER

| ents_p | ents_r | ents_f | Interpretation |
|--------|--------|--------|----------------|
| 0.90 | 0.90 | 0.90 | Excellent. Close to production-ready for many use cases |
| 0.85 | 0.70 | 0.77 | Conservative model. Misses entities. Needs more examples, especially diverse ones |
| 0.70 | 0.85 | 0.77 | Aggressive model. Over-predicts. Label scheme may be ambiguous or annotations inconsistent |
| 0.60 | 0.60 | 0.60 | Weak model. Fundamental issue — check data volume, annotation quality, and label scheme |
| 0.95 | 0.50 | 0.66 | Very conservative. Model only predicts the easiest, most obvious entities. Likely severe data imbalance or underrepresentation |

### Text Classification

| cats_macro_f | cats_macro_auc | Interpretation |
|-------------|----------------|----------------|
| > 0.85 | > 0.95 | Strong classifier |
| 0.70–0.85 | 0.85–0.95 | Decent. Check per-label scores for weak classes |
| < 0.70 | < 0.85 | Weak. Check class balance, data volume, and whether the task is well-defined |

**Key insight for textcat:** If `cats_macro_auc` is high but `cats_macro_f` is low, your threshold is wrong. Run `spacy find-threshold` to optimize it.

### Dependency Parsing

| dep_uas | dep_las | Interpretation |
|---------|---------|----------------|
| > 0.90 | > 0.88 | Strong parser |
| 0.85–0.90 | 0.80–0.88 | Good for most use cases |
| < 0.85 | < 0.80 | Needs attention. Check data volume and annotation consistency |

**Key insight:** A large gap between UAS and LAS (e.g., UAS=0.90, LAS=0.80) means head attachment is decent but dependency labels are confused. Check `dep_las_per_type` for which labels are problematic.

### Morphology

| morph_acc | Interpretation |
|-----------|----------------|
| > 0.95 | Excellent |
| 0.90–0.95 | Good |
| < 0.90 | Check `morph_per_feat` for which features are failing |

**Key insight:** `morph_acc` is exact-match of the entire feature bundle. A single wrong feature fails the whole token. `morph_micro_f` gives a more forgiving per-feature picture — check it when `morph_acc` seems unreasonably low.

---

## 6. Precision vs Recall Imbalances

### High precision, low recall ("the model is too cautious")

The model predicts correctly when it does predict, but misses many gold annotations.

**Common causes:**
1. **Too few positive examples.** The model hasn't seen enough variation to generalize
2. **Class imbalance.** The majority class dominates; the model defaults to predicting "nothing" for minority classes
3. **Threshold too high** (for spancat/textcat). Lower it
4. **Annotation sparsity.** If only some examples are fully annotated and others have missing labels, the model learns to be conservative

**Fixes (in priority order):**
1. Add more positive examples for low-recall labels
2. Ensure all examples are fully annotated (no missing labels)
3. Tune threshold down (for spancat: try 0.3; for textcat: run `find-threshold`)
4. Supplement with rules for the specific patterns being missed

### Low precision, high recall ("the model is too aggressive")

The model finds most gold annotations but also makes many false predictions.

**Common causes:**
1. **Ambiguous label boundaries.** The model can't distinguish where one entity ends and another begins, or whether something is an entity at all
2. **Label overlap.** Two labels share surface patterns (e.g., ORG and PERSON for company names that are people's names)
3. **Missing negative examples.** The model never learned what is *not* an entity
4. **Annotation inconsistency.** The same text is labeled differently in different examples, teaching the model to hedge by predicting broadly

**Fixes (in priority order):**
1. Add negative examples — texts containing entity-like words that aren't entities
2. Audit annotation consistency. Look for the same surface form with different labels
3. Refine annotation guidelines. Make label boundaries unambiguous
4. If two labels genuinely overlap, consider merging them and post-processing

### Balanced but both low

The model is struggling overall. This usually points to a fundamental issue rather than a tuning problem.

**Most likely causes (in order):**
1. Insufficient training data
2. Poorly defined label scheme (the task isn't learnable as defined)
3. Model architecture too small
4. Domain mismatch between training data and evaluation data

---

## 7. When to Add More Data

Add more data when:

- **Per-label counts are low.** If a label has < 50 examples and performs poorly, more data is almost certainly the fix. This is the most common bottleneck.
- **The model is overfitting.** Training loss is low but dev score plateaus. More diverse training data is the best regularizer.
- **Error analysis shows missed patterns.** If the model misses entities in specific contexts (e.g., entities in lists, entities after certain words), add examples of those contexts.
- **All labels are mediocre.** When no label performs well, the dataset is likely too small overall. Aim for 2000+ total examples for a new pipeline.
- **You're fine-tuning and performance drops.** Mix in more examples from the original domain to prevent catastrophic forgetting.

**How to add data efficiently:**
- Use `ner.correct` in Prodigy to correct model predictions rather than annotating from scratch — it's 3–5x faster
- Use pattern-based pre-filtering to find examples of rare labels rather than annotating random text
- Focus on the labels and contexts where the model is weakest (per-label error analysis tells you where)
- 50 well-chosen examples of a rare pattern are worth more than 500 examples of common patterns the model already handles

**When more data won't help:**
- The model already has 500+ examples per label and scores are plateauing
- The label scheme is inherently ambiguous (no amount of data resolves genuine ambiguity)
- Annotations are inconsistent (more inconsistent data makes things worse)

---

## 8. When to Change Architecture

Change architecture when:

- **You have enough data but scores plateau.** If you have 500+ examples per label and a small CNN model (width=96, depth=4), try a larger one (width=256, depth=8) or a transformer.
- **The model is underfitting.** Training loss stays high and doesn't decrease. The model lacks the capacity to represent the patterns in your data.
- **Context window matters.** CNN-based tok2vec has a limited receptive field (determined by `depth * window_size`). If your task requires long-range context (e.g., coreference, document-level classification), try a BiLSTM or transformer.
- **Speed requirements change.** If you need faster inference, downsize from transformer to CNN. If accuracy matters more than speed, upgrade from CNN to transformer.

**Architecture change decision table:**

| Current | Scores | Data size | Try |
|---------|--------|-----------|-----|
| Small CNN (w=96, d=4) | Plateaued | 200+ per label | Large CNN (w=256, d=8) with static vectors |
| Large CNN | Plateaued | 500+ per label | Transformer |
| Transformer | Plateaued | 500+ per label | More data or fix the schema — architecture is rarely the bottleneck at this point |
| Any CNN | Needs long context | Any | BiLSTM encoder or transformer |
| Transformer | Too slow | Any | CNN with frozen transformer distillation |

**When architecture won't help:**
- You have < 200 examples per label. Get more data first — a larger model with less data just overfits faster.
- Annotations are inconsistent. A bigger model learns the inconsistencies better, not the patterns.
- The label scheme is the problem. No architecture can learn an incoherent task.

---

## 9. When to Fix the Schema

Fix the label scheme when:

- **Two labels are chronically confused.** If the confusion matrix shows LABEL_A and LABEL_B constantly swapping, the distinction may not be learnable from text alone. Either merge them or provide clearer annotation guidelines.
- **Annotators disagree.** If two annotators can't consistently agree on a label for the same text, the model can't learn it either. Simplify the scheme or provide more explicit rules.
- **A label has high data but low scores.** If a label has 500+ examples and still performs poorly, the problem is definition, not quantity. The label likely covers too many distinct phenomena.
- **The label is defined by information not in the text.** If labeling requires external knowledge the model can't access (e.g., "is this company publicly traded?"), the task may need restructuring.

**Common schema fixes:**

| Problem | Fix |
|---------|-----|
| Two labels confused | Merge into one label; split later in post-processing using rules |
| One label covers too much | Split into more specific sub-labels with clearer criteria |
| Label depends on context outside the text | Restructure as a relation or linking task; or add the context as input |
| Boundary disagreements | Standardize: e.g., always include "the" before org names, or never include it |
| Nested entities | Switch from NER to SpanCat, which handles overlapping spans |
| Label is too rare | Either collect targeted examples, or fold it into a broader label |

**The schema test:** If you give your annotation guidelines to two people and they produce annotations with < 90% agreement, the model will also struggle. Fix the guidelines first.

---

## 10. Component-Specific Evaluation Guide

### NER

**Key metrics:** `ents_f`, `ents_per_type`

**What "correct" means:** An entity is correct only if the label, start position, and end position all match exactly. A partial overlap or wrong boundary is a miss.

**Typical failure modes:**
- Boundary errors (off-by-one token) — Standardize annotation guidelines for boundary decisions
- Label confusion (PERSON vs ORG) — Simplify scheme or add disambiguation examples
- Missed entities in unusual positions — Add examples of entities in those positions
- Tokenization misalignment — Entities whose character offsets don't align with token boundaries are silently excluded from both training and evaluation. This inflates your apparent scores. Always validate tokenization with `spacy debug data`

**Realistic expectations:**
- Well-defined types (PERSON, DATE): F > 0.90 achievable with 200–500 examples
- Ambiguous types (PRODUCT, EVENT): F > 0.80 may require 1000+ examples
- Domain-specific types (GENE, CHEMICAL): F > 0.85 achievable if annotation is consistent, even with 200–500 examples

### Text Classification

**Key metrics:** `cats_macro_f` (multi-class), `cats_macro_auc` (multi-label), `cats_f_per_type`

**Important nuance — micro vs macro:**
- `cats_micro_f` is dominated by frequent classes. If 90% of your data is class A, micro F mostly reflects class A performance.
- `cats_macro_f` gives equal weight to every class. It exposes poor performance on rare classes.
- **Always look at macro metrics** unless you genuinely don't care about rare classes.

**Key insight:** If macro AUC is high but macro F is low, the model ranks correctly but the threshold is wrong. Use `spacy find-threshold`.

**Typical failure modes:**
- Class imbalance — Rare classes get drowned out. Collect more examples of rare classes
- Texts too short — Very short texts may not have enough signal. Consider BOW architecture for short text
- Wrong variant — Using single-label `textcat` when labels aren't mutually exclusive, or vice versa

### Dependency Parsing

**Key metrics:** `dep_uas`, `dep_las`, `dep_las_per_type`

**The UAS/LAS gap tells a story:**
- Small gap (< 3 points): Label assignment is good; heads are good
- Large gap (> 5 points): Heads are OK but labels are confused. Check `dep_las_per_type` for which labels
- Both low: Structural issues — check annotation format and data volume

**Typical failure modes:**
- Rare dependency labels (< 20 examples) — Merge or remove
- Long sentences — Parser struggles with long-range dependencies. Split in preprocessing if needed
- Non-projective trees — spaCy auto-projectivizes, which can introduce noise. Check with `debug data`

### SpanCat

**Key metrics:** `spans_sc_f`, `spans_sc_per_type`

**Critical evaluation consideration:** SpanCat performance depends heavily on the **suggester**. The model can only classify spans that the suggester proposes. If the suggester doesn't generate a span that matches the gold annotation, that's an automatic false negative.

**Diagnosing suggester problems:** If recall is consistently low across all labels, check if your gold spans are longer than the suggester's maximum size. Increase `max_size` in the ngram suggester or switch to `ngram_range_suggester`.

**Threshold matters:** Unlike NER, SpanCat uses a confidence threshold. The default (0.5) may not be optimal. Use `spacy find-threshold` to tune it.

### Morphologizer

**Key metrics:** `pos_acc`, `morph_acc`, `morph_per_feat`

**Always check `morph_per_feat`** when `morph_acc` looks bad. `morph_acc` is exact-match of the complete feature bundle — if 10 features are correct and 1 is wrong, the whole token counts as a miss. `morph_per_feat` shows which specific feature is causing problems (e.g., Tense accuracy might be 98% while Aspect is 70%).

### Entity Linker

**Key metrics:** `nel_micro_f`, `nel_f_per_type`

**Important:** NEL scores measure linking accuracy *given correctly recognized entities*. They are independent of NER scores. If NER is poor, NEL is evaluated only on the entities that both the model and the gold data agree exist.

---

## 11. Threshold Tuning

SpanCat and TextCat (multi-label) use confidence thresholds to decide whether a prediction is positive. The default threshold (0.5) is rarely optimal.

### Using `spacy find-threshold`

```bash
# For spancat
python -m spacy find-threshold ./model-best ./dev.spacy spancat threshold spans_sc_f

# For textcat_multilabel
python -m spacy find-threshold ./model-best ./dev.spacy textcat_multilabel threshold cats_macro_f

# With more trials for finer resolution
python -m spacy find-threshold ./model-best ./dev.spacy spancat threshold spans_sc_f --n_trials 25
```

The command tests linearly spaced thresholds between 0 and 1, evaluates each, and reports the threshold that maximizes your chosen metric.

### Threshold intuition

| Lower threshold (e.g., 0.3) | Higher threshold (e.g., 0.7) |
|-----|------|
| More predictions, higher recall | Fewer predictions, higher precision |
| More false positives | More false negatives |
| Use when missing an entity is costly | Use when false alarms are costly |

### After finding the threshold

Update your config for deployment:

```ini
[components.spancat]
threshold = 0.35   # value from find-threshold
```

---

## 12. Speed vs Accuracy Tradeoffs

### Benchmarking speed

```bash
python -m spacy benchmark speed ./model-best ./data.spacy --batch-size 256 --batches 50
```

Reports words per second with 95% confidence intervals.

### Typical performance ranges

| Architecture | WPS (CPU) | WPS (GPU) | Accuracy tier |
|-------------|-----------|-----------|---------------|
| Small CNN (w=96, d=4) | 10,000–15,000 | 30,000–50,000 | Good |
| Large CNN (w=256, d=8) | 5,000–10,000 | 20,000–40,000 | Better |
| Transformer (base) | 500–2,000 | 10,000–20,000 | Best |

**Decision factors:**
- Batch processing (not latency-sensitive): Transformer with GPU
- Real-time / interactive: CNN on CPU
- Constrained deployment (edge, mobile): Small CNN
- Maximum accuracy regardless of cost: Transformer

### Trading accuracy for speed post-training

If a transformer model is too slow for deployment, consider:
1. **Replace listeners** — Decouple the transformer, export a distilled CNN
2. **Freeze and annotate** — Use the transformer to pre-compute features, then train a faster model on those features
3. **Quantization** — If using spacy-transformers, leverage HuggingFace quantization

---

## 13. Evaluation Pitfalls

### Pitfall 1: Tokenization inflates NER scores

If the tokenizer produces tokens that don't align with your gold entity boundaries, those entities are **silently excluded** from evaluation. Your F-score looks better than it actually is because the hard cases are dropped.

**How to detect:** Run `spacy debug data` and look for tokenization alignment warnings. Also compare the number of entities in your gold data vs the number evaluated.

**How to fix:** Adjust tokenizer rules or entity boundaries so they align with token boundaries.

### Pitfall 2: Train/dev overlap

If the same texts appear in both train and dev, your dev scores are unrealistically high.

**How to detect:** `spacy debug data` checks for this automatically.

**How to fix:** Deduplicate by text content across splits.

### Pitfall 3: Dev set too small

A dev set with 50 examples will give noisy, unreliable scores. Small changes in predictions cause large score swings.

**Rule of thumb:** Use at least 500 examples for evaluation, or 20% of your total data, whichever is larger.

### Pitfall 4: Comparing scores across different dev sets

F-scores are not comparable across different datasets. An F=0.85 on one dataset is not equivalent to F=0.85 on another. Only compare scores computed on the same dev set.

### Pitfall 5: `gold_preproc` train/test skew

If you train with `gold_preproc = true` (gold tokenization), the model sees perfectly tokenized text during training but receives imperfect tokenization at inference time. This can cause a significant performance drop in production that doesn't show up in evaluation if you also evaluate with `gold_preproc = true`.

**Recommendation:** Evaluate with `gold_preproc = false` (the default) to see realistic production performance.

### Pitfall 6: Ignoring speed during evaluation

A model that takes 10x longer per document may only be 2% more accurate. Always benchmark speed alongside accuracy and make a conscious tradeoff decision.

```bash
# Run both
python -m spacy evaluate ./model-best ./dev.spacy --output metrics.json
python -m spacy benchmark speed ./model-best ./dev.spacy
```

### Pitfall 7: Frozen components still affect scores

Even though frozen components aren't updated during training, they still run during evaluation and their output affects downstream components. For example, if the parser is frozen and produces bad sentence boundaries, NER and other components that depend on sentence boundaries will suffer.

**Check this by:** Evaluating with `--per-component` to see if a frozen component is the bottleneck.
