---
name: ellf-todo
description: Pick up a todo from the web assistant and start working on it. Auto-selects the most recent request, or accepts a request ID. Use /ellf-todo ls to list all requests. Use when the user says "pick up task", "check for tasks", "todo", or runs /ellf-todo.
argument-hint: "[request ID | ls]"
---

# Pick Up Todo

Pick up a todo created by the web assistant, load its context, do the
work, and sync the results back.

$ARGUMENTS

## Discover the task

- **`$ARGUMENTS` is a UUID** → use that ID.
- **`$ARGUMENTS` is `ls`** → run `ellf todo list --json`, show requests
  grouped by status (in-progress first, then planned, then done). Let the user
  pick one via `AskUserQuestion`.
- **Empty** → run `ellf todo latest --json` to auto-pick the most recent
  non-done request. If no requests, tell the user and stop.

## Load context

1. If the request is `planned`, mark it `in_progress`:
   `ellf todo update <id> --status in_progress`

2. Get full details: `ellf todo info <id> --json`

3. Resolve the project name from the project ID:
   `ellf projects info <project_id> --json`

4. If the request has a `conversation_id`, fetch the conversation:
   `ellf todo context <id> --json`
   Read through it to understand what was discussed.

5. Read the project plan if it exists:
   ```bash
   echo <project_id> > .ellf-project
   ellf plans read --project <project_id> || true
   ```

6. Summarize what you've learned and your proposed approach.

## Do the work

Work on the task using the description and conversation context as your guide.

**Check if a built-in recipe or existing tool already solves the problem.** If
it does, that IS the solution — note it in the resolution.

Your other ellf skills have deep domain knowledge for recipe development,
training, annotation, and pattern design. Use them as needed for the task.

Verify your work before completing:
- Run `pyflakes` or `python -m py_compile` on Python files
- Run tests if they exist
- For recipes, do a quick dry-run with stub data

## Complete and sync

When done, ask the user if they want to sync and complete.

**If yes:**

1. Update the project plan progress log:
   Read the current plan, append to the Progress Log section, then write back:
   ```bash
   ellf plans write --project $(cat .ellf-project) --content "<updated plan markdown>"
   ```

2. Mark request done with a resolution summarizing what was done:
   `ellf todo update <id> --status done --resolution "<summary>"`

4. Suggest the logical next step based on what was done.

**If no:** leave task as `in_progress`. The user can resume later with
`/ellf-todo`.
