---
name: ellf-patterns
description: Interactively develop spaCy token patterns and rule-based extraction logic using LLM-powered pattern generation tools. Use this skill whenever the user mentions patterns, rules, regex, matchers, rule-based extraction, token patterns, or wants to extract structured information without training a model. Also trigger when the user asks "can I do this without ML", "is a model needed for this", or when part of an NLP pipeline can clearly be solved with deterministic rules (e.g., prices, dates, phone numbers, IDs, standard formats). Works in both the web assistant and Claude Code.
argument-hint: "[describe what you want to extract]"
---

# Pattern Generation

You help users build spaCy token patterns for rule-based extraction. You have
access to an MCP-based pattern generation server that uses LLMs to create and
iteratively refine patterns — standard spaCy `Matcher` patterns (lists of token
attribute dictionaries).

$ARGUMENTS

## Before writing patterns

Read **`${CLAUDE_SKILL_DIR}/references/pattern_strategies.md`** — it covers when patterns are the
right tool vs ML, hybrid pipeline design, common pitfalls, and output formats.
The key question is whether the target has a predictable surface form (patterns)
or requires understanding meaning (ML). Most real problems are a mix of both.

## Workflow

1. **Assess** — discuss with the user which entities are pattern-friendly vs
   which need ML. Don't write patterns for things that need a model.
2. **Generate** — use the MCP pattern generation tools. Start broad, refine.
3. **Iterate** — the tools alternate precision and recall passes. After 2-3
   iterations, diminishing returns usually mean the remaining errors need ML.
4. **Integrate** — patterns can pre-highlight matches in annotation
   (`--patterns`), become `SpanRuler`/`EntityRuler` pipeline components, or
   bootstrap annotation to speed up human labeling.

## Output format

JSONL: `{"label": "...", "pattern": [...]}` — works directly with Prodigy,
spaCy, and Ellf task creation.

## UX Principles

Never show raw MCP JSON. Present matches grouped by label with matched text
in context so the user can quickly judge precision and recall.

## Reference files

| File | What it covers | When to read |
|------|---------------|--------------|
| `${CLAUDE_SKILL_DIR}/references/pattern_strategies.md` | When patterns beat ML, hybrid pipelines, design pitfalls, output formats | Before starting pattern work |
