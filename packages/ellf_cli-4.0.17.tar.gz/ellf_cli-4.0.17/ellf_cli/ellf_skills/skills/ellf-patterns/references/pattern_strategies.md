# Pattern Strategy Guide

## When Patterns Beat ML

Patterns are the right choice when the target has a **predictable surface form**
— you can describe what it looks like in terms of token shape, not meaning.

**Strong pattern candidates:**
- Prices and currencies: `$49.99`, `EUR 1,200`, `ab 29€`
- Dates and times: `2024-01-15`, `15. Januar`, `3:30 PM`
- Identifiers: invoice numbers, order IDs, part numbers, SKUs
- Phone numbers, postal codes, email addresses, URLs
- Legal references: `§ 42 BGB`, `Art. 5 GDPR`, `Section 12(a)`
- Measurement units: `150 mg`, `2.5 km`, `30°C`
- Version numbers: `v2.1.3`, `iOS 17.4`
- Structured codes: ICD codes, NAICS codes, stock tickers

**Poor pattern candidates:**
- Person names — too variable, context-dependent
- Organizations — "Apple" is also a fruit
- Product names — arbitrary strings
- Locations — overlap with common words ("Mobile", "Nice", "Reading")
- Anything where meaning matters more than shape

## Hybrid Pipelines

Most real extraction problems have a mix: some entities are pattern-friendly,
some need ML. The efficient design is:

1. Identify which entities have predictable surface forms → patterns
2. Remaining entities → train an NER model
3. Patterns run first (cheap, fast, deterministic), model handles the rest

This focuses annotation effort on the hard entities. No point labeling 500
examples of `$49.99` as PRICE when a pattern gets 99% of them.

Patterns also bootstrap annotation: run `ner.manual --patterns patterns.jsonl`
to pre-highlight pattern matches. Annotators correct and add what the patterns
miss. This is faster than annotating from scratch.

## Pattern Design Pitfalls

### Over-specific patterns
A pattern that matches `{"LOWER": "january"}` misses `Jan`, `jan.`, `JANUARY`.
Prefer `LOWER` over `TEXT`, use `REGEX` for variants, keep patterns general.

### Under-specific patterns
A pattern `[{"LIKE_NUM": true}]` matches every number in the text. Add
surrounding context tokens or use `LENGTH`/`SHAPE` constraints to narrow down.

### Ambiguous tokens
"Rose" (color? name? past tense?), "Mobile" (phone? city?), "Real" (currency?
adjective?). When a token is ambiguous, patterns alone can't resolve it — this
is where you need ML. Don't fight this; switch to a model for ambiguous cases.

### Language-specific tokenization
Patterns depend on how spaCy tokenizes. `€49.99` may be one or three tokens
depending on the model. Always test patterns against the actual spaCy model
the user will use in production. Set `model_name` to match.

### Diminishing returns on iteration
The improve_patterns tool alternates precision and recall passes. After 2-3
iterations, patterns often oscillate — fixing one false positive introduces
a false negative. If you're stuck, the remaining errors probably need ML, not
more rules.

## Pattern Output Format

Patterns should be saved as JSONL for Prodigy compatibility:
```jsonl
{"label": "PRICE", "pattern": [{"LOWER": {"REGEX": "\\$|€|£"}}, {"LIKE_NUM": true}]}
{"label": "DATE", "pattern": [{"SHAPE": "dd"}, {"LOWER": "."}, {"SHAPE": "xxxx"}, {"SHAPE": "dddd"}]}
```

This format works directly with:
- `prodigy ner.manual --patterns patterns.jsonl` (pre-highlight matches)
- `spacy.load("model").add_pipe("span_ruler").from_disk("patterns.jsonl")`
- `ellf tasks create <recipe> --help` to inspect whether the selected Ellf recipe accepts a patterns argument
