"""Training status checker — reads metrics and detects anomalies.

Produces a structured JSON summary from either local training logs or
cluster job status. Designed to be called each iteration of a /loop
monitor, keeping raw log data out of the LLM context.

Usage:
    python check_training.py --mode local --output-dir ./output [--log-path training_log.jsonl]
    python check_training.py --mode cluster --job-name ner-v1 [--job-type action]
"""

import argparse
import json
import subprocess
import sys
from pathlib import Path


def check_local(output_dir: str, log_path: str | None = None) -> dict:
    """Check local training status from files."""
    output = Path(output_dir)

    # Check job_status.json (from run_job.py)
    status_file = Path("job_status.json")
    job_state = "unknown"
    if status_file.exists():
        job = json.loads(status_file.read_text())
        job_state = job.get("status", "unknown")
        if job_state == "failed":
            return {
                "state": "failed",
                "error": job.get("error", "Process exited with non-zero code"),
                "alerts": [
                    {"type": "failed", "message": job.get("error", "Job failed")}
                ],
            }

    # Check if model-last/meta.json exists for latest scores
    meta_path = output / "model-last" / "meta.json"
    best_meta_path = output / "model-best" / "meta.json"
    result = {
        "state": "running" if job_state == "running" else job_state,
        "step": 0,
        "total_steps": None,
        "train_loss": None,
        "dev_scores": {},
        "best_step": None,
        "best_score": None,
        "alerts": [],
    }

    if meta_path.exists():
        meta = json.loads(meta_path.read_text())
        perf = meta.get("performance", {})
        result["dev_scores"] = {
            k: round(v, 4) for k, v in perf.items() if isinstance(v, (int, float))
        }

    if best_meta_path.exists():
        best_meta = json.loads(best_meta_path.read_text())
        best_perf = best_meta.get("performance", {})
        # Find the primary score (usually the first one or "score")
        if best_perf:
            result["best_score"] = round(
                best_perf.get("score", next(iter(best_perf.values()), 0)), 4
            )

    # Parse training_log.jsonl if available (from ellf_logger.py)
    log_file = Path(log_path) if log_path else Path("training_log.jsonl")
    if log_file.exists():
        lines = log_file.read_text().strip().split("\n")
        entries = [json.loads(line) for line in lines if line.strip()]

        if entries:
            last = entries[-1]

            # Check for training_complete event
            if last.get("event") == "training_complete":
                result["state"] = "completed"
                result["step"] = last.get("total_steps", 0)
                result["best_score"] = last.get("best_score")
                result["alerts"].append(
                    {
                        "type": "completed",
                        "message": f"Training complete. Best score: {last.get('best_score')}",
                    }
                )
                return result

            result["step"] = last.get("step", 0)
            result["train_loss"] = sum(last.get("losses", {}).values()) or None
            result["best_score"] = last.get("best_score")

            if last.get("component_scores"):
                result["dev_scores"] = last["component_scores"]

            # Collect alerts from recent entries
            for entry in entries[-5:]:
                for alert in entry.get("alerts", []):
                    if alert not in result["alerts"]:
                        result["alerts"].append(alert)

    # If job completed but no training_complete in log
    if job_state in ("completed", "succeeded") and result["state"] != "completed":
        result["state"] = "completed"
        if not any(a["type"] == "completed" for a in result["alerts"]):
            result["alerts"].append(
                {
                    "type": "completed",
                    "message": f"Training complete. Best score: {result['best_score']}",
                }
            )

    return result


def check_cluster(job_name: str, job_type: str = "action") -> dict:
    """Check cluster job status via ellf CLI."""
    result = {
        "state": "unknown",
        "step": 0,
        "total_steps": None,
        "train_loss": None,
        "dev_scores": {},
        "best_step": None,
        "best_score": None,
        "alerts": [],
    }

    # Get job info
    try:
        info_out = subprocess.run(
            ["ellf", f"{job_type}s", "info", job_name, "--json"],
            capture_output=True,
            text=True,
            timeout=30,
        )
        if info_out.returncode == 0 and info_out.stdout.strip():
            info = json.loads(info_out.stdout)
            state = info.get("state", info.get("status", "unknown"))
            result["state"] = state

            if state in ("failed", "error"):
                result["alerts"].append(
                    {
                        "type": "failed",
                        "message": f"Job '{job_name}' failed",
                    }
                )
                # Try to get error from logs
                logs_out = subprocess.run(
                    ["ellf", f"{job_type}s", "logs", job_name, "--errors"],
                    capture_output=True,
                    text=True,
                    timeout=30,
                )
                if logs_out.returncode == 0 and logs_out.stdout.strip():
                    result["error"] = logs_out.stdout.strip()[:500]
                return result

            if state in ("succeeded", "completed"):
                result["state"] = "completed"
                result["alerts"].append(
                    {
                        "type": "completed",
                        "message": f"Job '{job_name}' completed",
                    }
                )
    except (subprocess.TimeoutExpired, FileNotFoundError, json.JSONDecodeError):
        pass

    # Get training metrics from logs
    try:
        logs_out = subprocess.run(
            ["ellf", f"{job_type}s", "logs", job_name],
            capture_output=True,
            text=True,
            timeout=30,
        )
        if logs_out.returncode == 0 and logs_out.stdout.strip():
            result = _parse_training_logs(logs_out.stdout, result)
    except (subprocess.TimeoutExpired, FileNotFoundError):
        pass

    return result


def _parse_training_logs(log_text: str, result: dict) -> dict:
    """Extract training metrics from spaCy train log output."""
    lines = log_text.strip().split("\n")

    for line in reversed(lines):
        line = line.strip()
        # Try to parse as JSONL (ellf_logger format)
        if line.startswith("{"):
            try:
                entry = json.loads(line)
                if entry.get("event") == "training_complete":
                    result["state"] = "completed"
                    result["best_score"] = entry.get("best_score")
                    result["step"] = entry.get("total_steps", 0)
                    break
                result["step"] = entry.get("step", result["step"])
                result["train_loss"] = sum(entry.get("losses", {}).values()) or None
                result["best_score"] = entry.get("best_score", result["best_score"])
                for alert in entry.get("alerts", []):
                    if alert not in result["alerts"]:
                        result["alerts"].append(alert)
                break
            except json.JSONDecodeError:
                continue

        # Parse spaCy train table format: "E    #    LOSS    SCORE   SCORE2"
        if line.startswith("E ") or line[0:1].isdigit():
            parts = line.split()
            if len(parts) >= 4:
                try:
                    result["step"] = int(parts[1])
                    # Last numeric column is usually the overall score
                    for val in reversed(parts[2:]):
                        try:
                            result["best_score"] = max(
                                result.get("best_score") or 0, float(val)
                            )
                            break
                        except ValueError:
                            continue
                except (ValueError, IndexError):
                    continue

    return result


def main():
    parser = argparse.ArgumentParser(description="Check training status")
    parser.add_argument("--mode", choices=["local", "cluster"], required=True)
    parser.add_argument("--output-dir", help="Local output directory")
    parser.add_argument("--log-path", help="Path to training_log.jsonl")
    parser.add_argument("--job-name", help="Cluster job name")
    parser.add_argument("--job-type", default="action", help="Job type: action, task")

    args = parser.parse_args()

    if args.mode == "local":
        if not args.output_dir:
            parser.error("--output-dir required for local mode")
        result = check_local(args.output_dir, args.log_path)
    else:
        if not args.job_name:
            parser.error("--job-name required for cluster mode")
        result = check_cluster(args.job_name, args.job_type)

    json.dump(result, sys.stdout, indent=2)
    print()


if __name__ == "__main__":
    main()
