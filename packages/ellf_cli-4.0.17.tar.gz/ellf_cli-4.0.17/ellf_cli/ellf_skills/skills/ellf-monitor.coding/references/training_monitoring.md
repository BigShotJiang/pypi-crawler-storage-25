# Training Monitoring

How to monitor training jobs, interpret alerts, and diagnose problems.

## The check script

The ellf-train skill includes `scripts/check_training.py` — it reads local
logs or cluster status and produces a structured JSON summary.

```bash
# Local
python ${CLAUDE_SKILL_DIR}/scripts/check_training.py --mode local --output-dir ./output --log-path training_log.jsonl

# Cluster
python ${CLAUDE_SKILL_DIR}/scripts/check_training.py --mode cluster --job-name ner-v1
```

Output shape:
```json
{
  "state": "running|completed|failed",
  "step": 800,
  "train_loss": 0.52,
  "dev_scores": {"ents_f": 0.79, "ents_p": 0.82, "ents_r": 0.76},
  "best_score": 0.81,
  "alerts": [{"type": "overfitting", "message": "..."}]
}
```

## Alert types and responses

| Alert | What it means | Action | Ask user? |
|---|---|---|---|
| `nan_loss` | Loss became NaN — unrecoverable | Stop training immediately, diagnose | No — auto-stop only if the monitoring workflow explicitly owns that action |
| `failed` | Process crashed or job failed | Show error, suggest fix | Yes |
| `loss_spike` | 3+ consecutive loss increases | Inform, show trend | No |
| `plateau` | 8+ evals without score improvement | Present analysis | Yes |
| `overfitting` | Dev score declining while train loss improves | Show best checkpoint info | Yes |
| `completed` | Training finished normally | Report completion and results | No |

## Diagnostics

When an alert fires, classify the problem and route to the right skill. For detailed root cause analysis, detection signals, and fix guidance for each class, read:

- `${CLAUDE_SKILL_DIR}/../ellf-train/references/diagnostics.md` — six problem classes: data issues, training divergence, overfitting, underfitting, resource issues, catastrophic forgetting
- `${CLAUDE_SKILL_DIR}/../ellf-train/references/training_troubleshooting.md` — component-specific error tables and spaCy error code reference

When the fix needs config or code changes, route to `/ellf-train` or `/ellf-prodigy`.
