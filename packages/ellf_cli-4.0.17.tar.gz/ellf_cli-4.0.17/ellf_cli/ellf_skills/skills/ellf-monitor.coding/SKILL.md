---
name: ellf-monitor
description: "Has a structured training check script, alert classification (overfitting, plateau, NaN loss, spikes), annotation metrics references, and diagnostic routing. Load this skill to monitor Ellf jobs, local Prodigy servers, training progress, or cluster health — it keeps raw logs out of context and produces structured summaries. Use proactively after launching any job, not just when the user asks. Also trigger on status checks, log inspection, 'how's the task doing', 'what failed', or training metric questions."
argument-hint: "[job name, job type, output dir, or 'cluster']"
---

# Monitor Jobs From Coding

You are the monitoring and diagnosis skill for the coding environment.

$ARGUMENTS

## Scope

You monitor and diagnose.

You do not:
- redesign strategy
- choose recipes
- implement code fixes
- perform mutations unless another skill or explicit user instruction routes that work to `/ellf-ops`

If intervention is needed:
- use `/ellf-ops` for operational changes
- use `/ellf-project` for planning or methodology
- use `/ellf-prodigy` or `/ellf-train` if implementation is required

## Monitoring surfaces

You may need to monitor:
- Ellf cluster jobs via CLI
- local training runs
- standalone local Prodigy servers
- cluster health

Determine which one applies before inspecting anything.

## Job discovery

If the user does not identify the target clearly:
1. check current tasks, actions, and agents
2. narrow to the most relevant running job
3. ask only if multiple plausible targets remain

Use:
```bash
ellf tasks list --json
ellf actions list --json
ellf agents list --json
```

## Training monitoring

Read:
- `${CLAUDE_SKILL_DIR}/references/training_monitoring.md`

If an alert fires and you need to diagnose or explain the root cause, also read:
- `${CLAUDE_SKILL_DIR}/../ellf-train/references/diagnostics.md`
- `${CLAUDE_SKILL_DIR}/../ellf-train/references/training_troubleshooting.md`

The preferred structured monitor is:
```bash
python ${CLAUDE_SKILL_DIR}/scripts/check_training.py --mode cluster --job-name <job_name> --job-type action
python ${CLAUDE_SKILL_DIR}/scripts/check_training.py --mode local --output-dir <output_dir> [--log-path <training_log.jsonl>]
```

Use it when available because it keeps raw logs out of context and produces structured alerts.

If needed, supplement with:
```bash
ellf actions info "<name>" --json
ellf actions logs "<name>"
```

For local runs, inspect:
- `job_status.json`
- `training_log.jsonl`
- `model-last/meta.json`
- `model-best/meta.json`

Report:
- current state
- best score and recent trend
- active alerts
- whether the run looks healthy, stalled, overfit, or failed

## Annotation tasks

Use:
```bash
ellf tasks info "<name>" --json
ellf tasks logs "<name>"
```

To check the linked dataset and confirm the output target:
```bash
ellf datasets info "<dataset_name>" --json
```

Read when needed:
- `${CLAUDE_SKILL_DIR}/references/annotation_metrics.md`

Report:
- task state
- task URL if available
- dataset growth signals
- any obvious operational problem

## Agents

Use:
```bash
ellf agents info "<name>" --json
ellf agents logs "<name>"
```

Report:
- agent state
- recent errors
- whether it appears to be producing work
- whether it seems blocked or misconfigured

## Generic actions

Use:
```bash
ellf actions info "<name>" --json
ellf actions logs "<name>"
```

Report:
- state
- duration
- failure signals
- whether it needs intervention

## Standalone local Prodigy

For local Prodigy servers, monitor the actual process and served URL.

Look for:
- immediate startup errors
- the local URL
- whether the process is still alive
- whether the URL is reachable

Use the captured output or process info from the launch context when available.

## Cluster health

```bash
# Connectivity and service health
ellf clusters check

# Deeper broker-side checks (K8s, NFS, database)
ellf clusters check --deep

# Node capacity and utilization (cpu, memory, gpu, pod count)
ellf clusters nodes --json
```

Report:
- overall cluster health and connectivity
- node availability and resource pressure
- any degraded state or failed checks

## Presenting results

Use compact summaries and tables.

Never dump raw logs when a short diagnosis is enough.

For training, prefer:
- current state
- best score
- notable alerts
- recommended next action

## Continuous monitoring

If the user wants ongoing monitoring, use `/loop` in the coding environment.

A good pattern is:
1. choose the right interval
2. run the structured training check or the relevant `ellf ... info/logs` command
3. report only on change or alert
4. stop when the job completes or the user says to stop

## When to escalate

Use `/ellf-ops` when:
- the user wants to stop, restart, relaunch, or reassign something
- worker class or launch settings need to change

Use `/ellf-prodigy` or `/ellf-train` when:
- the likely fix requires recipe or file changes

Use `/ellf-project` when:
- the root problem appears methodological rather than operational

## Output expectations

When you finish, state:
- what you monitored
- the current state
- the key evidence
- whether intervention is needed
- the next operational or implementation step
