---
name: ellf-ask
description: Answer questions about spaCy, Prodigy, and NLP best practices using the Ellf knowledge base. The KB contains official documentation, API references, tutorials, case studies, conference talks, Prodigy community forum discussions, and applied NLP strategy content from Explosion. Use this skill when the user asks factual questions about spaCy features, Prodigy recipes, NLP techniques, annotation best practices, troubleshooting Prodigy issues, or Explosion ecosystem tools. Also trigger on strategic questions like "should I use rules or ML", "what's the best approach for X" where grounded documentation would help. Trigger on "how do I", "what's the best way to", "does spaCy support", "which Prodigy recipe", "how does X work in spaCy/Prodigy", "I'm getting an error with Prodigy", or any question about NLP development that would benefit from up-to-date documentation.
argument-hint: "[your question about spaCy, Prodigy, or NLP]"
---

# Knowledge Base Query

You have access to the `query_knowledge_base` MCP tool — it queries a curated
collection of spaCy and Prodigy documentation, API references, tutorials,
case studies, conference talks, and Prodigy community forum discussions.

$ARGUMENTS

## How to use the KB

The KB is a **supporting and cross-checking tool**, not the primary source of
strategic knowledge. For NLP strategy (pipeline design, annotation approach,
rules vs ML decisions), the principal source is the domain expertise encoded
in other skills — especially the strategic reference files (explosion_strategy.md,
consulting_patterns.md). Use the KB to:

- **Verify** specific API details, recipe arguments, config options
- **Ground** advice with up-to-date documentation
- **Troubleshoot** errors using community forum discussions
- **Discover** relevant case studies and tutorials
- **Cross-check** recommendations against official docs

Never show raw KB output to the user — synthesize it into your own advice.

## When to Defer

This skill answers factual questions. It's not the right tool for project-level
decisions (pipeline design, label schemes, data strategy) or implementation
tasks (writing recipes, training models, launching annotation).
