"""ellf infra setup — install cluster infrastructure prerequisites."""

from typing import Optional

from radicli import Arg
from wasabi import msg

from ...cli import cli
from ._helpers import ensure_cert_manager, ensure_traefik


@cli.subcommand(
    "infra",
    "setup",
    traefik=Arg("--traefik", help="Install Traefik ingress controller"),
    cert_manager=Arg("--cert-manager", help="Install cert-manager with Let's Encrypt"),
    acme_email=Arg(
        "--acme-email", help="Email for ACME/Let's Encrypt certificate registration"
    ),
    public_ip=Arg("--public-ip", help="Static IP for the Traefik load balancer"),
)
def setup(
    traefik: bool = False,
    cert_manager: bool = False,
    acme_email: Optional[str] = None,
    public_ip: Optional[str] = None,
) -> None:
    """Install cluster infrastructure prerequisites (Traefik, cert-manager).

    These operations are idempotent and safe to re-run.
    """
    if traefik:
        ensure_traefik(public_ip=public_ip or "")
        msg.good("Traefik installed")
    if cert_manager or acme_email:
        ensure_cert_manager()
        msg.good("cert-manager installed")
