import json
import sys
from pathlib import Path
from typing import Optional
from uuid import UUID

from radicli import Arg
from wasabi import msg

from ..cli import cli
from ..ui import print_table_with_select
from ._state import get_auth_state


@cli.subcommand(
    "plans",
    "list",
    project=Arg("--project", help="Project ID"),
    as_json=Arg("--json", help="Output as JSON"),
)
def list(project: UUID, as_json: bool = False) -> None:
    """List all plans for a project"""
    client = get_auth_state().client
    items = client.project_plan.list(project)
    select = ["id", "name", "created", "updated"]
    print_table_with_select(items, select=select, as_json=as_json)


@cli.subcommand(
    "plans",
    "read",
    project=Arg("--project", help="Project ID"),
    name=Arg("--name", help="Plan name (default: project_plan)"),
    as_json=Arg("--json", help="Output as JSON"),
)
def read(
    project: UUID,
    name: str = "project_plan",
    as_json: bool = False,
) -> Optional[str]:
    """Read a plan for a project"""
    client = get_auth_state().client
    plan = client.project_plan.read(project_id=project, name=name)
    if plan is None:
        if as_json:
            print("{}")
        else:
            msg.info(f"No plan '{name}' found for this project")
        return None
    if as_json:
        print(plan.model_dump_json(indent=2))
    else:
        msg.info(f"Plan: {name} (project: {project})")
        print(plan.content)
    return plan.content


@cli.subcommand(
    "plans",
    "write",
    project=Arg("--project", help="Project ID"),
    name=Arg("--name", help="Plan name (default: project_plan)"),
    content=Arg(
        "--content", help="Plan content (markdown). Use --file to read from a file."
    ),
    file=Arg("--file", help="Path to a file containing the plan content"),
    as_json=Arg("--json", help="Output as JSON"),
)
def write(
    project: UUID,
    name: str = "project_plan",
    content: Optional[str] = None,
    file: Optional[Path] = None,
    as_json: bool = False,
) -> None:
    """Create or update a plan for a project (upsert)"""
    if content is None and file is None:
        if not sys.stdin.isatty():
            content = sys.stdin.read()
        else:
            msg.fail("Provide --content or --file (or pipe content via stdin)")
            raise SystemExit(1)
    if file is not None:
        content = file.read_text()
    assert content is not None
    client = get_auth_state().client
    plan = client.project_plan.upsert(project, name, content=content)
    if as_json:
        print(plan.model_dump_json(indent=2))
    else:
        msg.good(f"Plan '{name}' saved (id: {plan.id})")


@cli.subcommand(
    "plans",
    "delete",
    project=Arg("--project", help="Project ID"),
    name=Arg("--name", help="Plan name"),
    id=Arg("--id", help="Plan UUID (alternative to --project + --name)"),
    as_json=Arg("--json", help="Output as JSON"),
)
def delete(
    project: Optional[UUID] = None,
    name: Optional[str] = None,
    id: Optional[UUID] = None,
    as_json: bool = False,
) -> None:
    """Delete a plan"""
    if id is None and (project is None or name is None):
        msg.fail("Provide --id or both --project and --name")
        raise SystemExit(1)
    client = get_auth_state().client
    client.project_plan.delete(id=id, project_id=project, name=name)
    if as_json:
        print(json.dumps({"deleted": True}))
    else:
        msg.good("Plan deleted")
