"""Tests for ellf_cli.appdirs — application directory resolution (macOS paths)."""

from __future__ import annotations

from ellf_cli.appdirs import (
    AppDirs,
    site_config_dir,
    site_data_dir,
    user_cache_dir,
    user_config_dir,
    user_data_dir,
    user_log_dir,
    user_state_dir,
)


class TestUserDataDir:
    def test_with_appname(self):
        path = user_data_dir("TestApp")
        assert "TestApp" in path

    def test_without_appname(self):
        path = user_data_dir()
        assert isinstance(path, str)

    def test_with_version(self):
        path = user_data_dir("TestApp", version="1.0")
        assert "1.0" in path


class TestUserConfigDir:
    def test_with_appname(self):
        path = user_config_dir("TestApp")
        assert "TestApp" in path

    def test_with_version(self):
        path = user_config_dir("TestApp", version="2.0")
        assert "2.0" in path


class TestSiteDataDir:
    def test_with_appname(self):
        path = site_data_dir("TestApp")
        assert "TestApp" in path

    def test_without_appname(self):
        path = site_data_dir()
        assert isinstance(path, str)


class TestSiteConfigDir:
    def test_with_appname(self):
        path = site_config_dir("TestApp")
        assert "TestApp" in path


class TestUserCacheDir:
    def test_with_appname(self):
        path = user_cache_dir("TestApp")
        assert "TestApp" in path

    def test_with_version(self):
        path = user_cache_dir("TestApp", version="3.0")
        assert "3.0" in path


class TestUserStateDir:
    def test_with_appname(self):
        path = user_state_dir("TestApp")
        assert "TestApp" in path


class TestUserLogDir:
    def test_with_appname(self):
        path = user_log_dir("TestApp")
        assert "TestApp" in path


class TestAppDirs:
    def test_all_properties(self):
        dirs = AppDirs("TestApp", "TestAuthor", version="1.0")
        assert "TestApp" in dirs.user_data_dir
        assert "TestApp" in dirs.user_config_dir
        assert "TestApp" in dirs.user_cache_dir
        assert "TestApp" in dirs.user_state_dir
        assert "TestApp" in dirs.user_log_dir
        assert "TestApp" in dirs.site_data_dir
        assert "TestApp" in dirs.site_config_dir

    def test_without_version(self):
        dirs = AppDirs("TestApp")
        assert isinstance(dirs.user_data_dir, str)
        assert isinstance(dirs.user_config_dir, str)
