import pytest

from ellf_cli.main import cli


@pytest.mark.xfail(reason="No dummy project")
def test_list_projects(capsys):
    with pytest.raises(SystemExit):
        cli.run(["ellf", "projects", "list"])
    captured = capsys.readouterr()
    assert "Test Project" in captured.out
