"""Tests for ellf_cli.errors — custom exception classes."""

from __future__ import annotations

from pathlib import Path

from ellf_cli.errors import (
    CLIError,
    EllfError,
    EllfIDTokenError,
    EllfParseSecretsError,
    RecipeBuildMetaFailed,
)


class TestEllfError:
    def test_basic(self):
        e = EllfError("something broke")
        assert e.message == "something broke"
        assert str(e) == "something broke"

    def test_empty_message(self):
        e = EllfError()
        assert e.message == ""


class TestEllfIDTokenError:
    def test_inherits(self):
        e = EllfIDTokenError("token bad")
        assert isinstance(e, EllfError)
        assert e.message == "token bad"


class TestCLIError:
    def test_title_only(self):
        e = CLIError("Title")
        assert e.title == "Title"
        assert e.text is None
        assert e.message == "Title"

    def test_title_and_text(self):
        e = CLIError("Title", "detail text")
        assert e.title == "Title"
        assert e.text == "detail text"
        assert "Title" in e.message
        assert "detail text" in e.message


class TestEllfParseSecretsError:
    def test_with_path_and_error(self):
        path = Path("/tmp/secrets.json")
        inner = ValueError("bad json")
        e = EllfParseSecretsError(path, inner)
        assert "/tmp/secrets.json" in str(e)
        assert "bad json" in str(e)

    def test_with_none_path(self):
        e = EllfParseSecretsError(None)
        assert str(e)  # Should not crash

    def test_with_no_inner_error(self):
        path = Path("/tmp/secrets.json")
        e = EllfParseSecretsError(path)
        assert "/tmp/secrets.json" in str(e)


class TestRecipeBuildMetaFailed:
    def test_attributes(self):
        e = RecipeBuildMetaFailed("my-package", "stdout text", "stderr text")
        assert e.package_name == "my-package"
        assert e.stdout == "stdout text"
        assert e.stderr == "stderr text"
        assert "my-package" in str(e)
