import inspect

import pytest

from ellf_cli.__main__ import _normalize_legacy_args
from ellf_cli.about import __version__
from ellf_cli.main import cli


def test_ptc_cli_importable():
    """Smoke test that the CLI can be imported and has commands."""
    assert len(cli.commands) > 0


def test_ptc_cli_help_texts(command):
    """Test that all commands provide docstrings and argument help texts."""
    assert command.description, f"no docstring for {command.display_name}"
    for arg in command.args:
        if arg.id == cli.extra_key:
            continue
        assert arg.arg.help, f"no help text for {command.display_name} -> {arg.id}"


def test_pt_cli_all_annotated(command_no_placeholder):
    """Assert that all function arguments are annotated."""
    command = command_no_placeholder
    sig = inspect.signature(command.func)
    args = [a.id for a in command.args]
    params = [p for p in sig.parameters]
    assert sorted(args) == sorted(params), f"arg mismatch in {command.display_name}"


def test_ptc_cli_default_help_info(capsys):
    with pytest.raises(SystemExit):
        cli.run(["ellf"])
    captured = capsys.readouterr()
    expected_output_slice = """Ellf Command Line Interface."""
    assert expected_output_slice in captured.out


def test_version(capsys):
    with pytest.raises(SystemExit):
        cli.run(["ellf", "--version"])
    captured = capsys.readouterr()
    assert captured.out.strip() == __version__


def test_normalize_legacy_args_cluster_alias():
    assert _normalize_legacy_args(["cluster", "nodes"]) == ["clusters", "nodes"]


def test_normalize_legacy_args_noop():
    assert _normalize_legacy_args(["clusters", "nodes"]) == ["clusters", "nodes"]
