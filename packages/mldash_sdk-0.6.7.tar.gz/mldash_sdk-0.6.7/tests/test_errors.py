"""Tests for mldash._errors — exception hierarchy."""
from mldash._errors import MLDashAuthError, MLDashError, MLDashUploadError, MLDashValidationError


class TestExceptionHierarchy:
    def test_validation_error_is_mldash_error(self):
        assert issubclass(MLDashValidationError, MLDashError)

    def test_auth_error_is_mldash_error(self):
        assert issubclass(MLDashAuthError, MLDashError)

    def test_upload_error_is_mldash_error(self):
        assert issubclass(MLDashUploadError, MLDashError)

    def test_all_are_exceptions(self):
        assert issubclass(MLDashError, Exception)

    def test_can_catch_with_base(self):
        try:
            raise MLDashValidationError("bad input")
        except MLDashError as e:
            assert str(e) == "bad input"

    def test_can_catch_specific(self):
        try:
            raise MLDashAuthError("bad key")
        except MLDashAuthError as e:
            assert str(e) == "bad key"

    def test_upload_error_not_caught_as_auth(self):
        with __import__('pytest').raises(MLDashUploadError):
            raise MLDashUploadError("server down")
