# SPDX-License-Identifier: Apache-2.0
# Copyright 2026 TracineHQ contributors
"""Tests for agent_output_guard hook."""

from __future__ import annotations

import contextlib
import json
import subprocess
import sys
from pathlib import Path

import pytest

from guard.hooks.agent_output_guard import decide, hook

HOOK_PATH = (
    Path(__file__).resolve().parents[2] / "src" / "guard" / "hooks" / "agent_output_guard.py"
)


class TestDecide:
    def test_read_agent_output_denied(self):
        result = decide(
            "Read",
            {"file_path": "/private/tmp/claude-501/-Users-dev/abc123/tasks/xyz.output"},
        )
        assert result is not None
        assert result["hookSpecificOutput"]["permissionDecision"] == "deny"

    def test_cat_agent_output_denied(self):
        result = decide(
            "Bash",
            {"command": "cat /private/tmp/claude-501/-Users-dev/abc/tasks/test.output"},
        )
        assert result is not None
        assert result["hookSpecificOutput"]["permissionDecision"] == "deny"

    def test_head_agent_output_denied(self):
        result = decide(
            "Bash",
            {"command": "head -5 /private/tmp/claude-501/proj/sess/tasks/a.output"},
        )
        assert result is not None
        assert result["hookSpecificOutput"]["permissionDecision"] == "deny"

    def test_tail_agent_output_denied(self):
        result = decide(
            "Bash",
            {"command": "tail -1 /private/tmp/claude-501/proj/sess/tasks/a.output"},
        )
        assert result is not None
        assert result["hookSpecificOutput"]["permissionDecision"] == "deny"

    def test_read_normal_file_passes(self):
        assert decide("Read", {"file_path": "/Users/dev/src/main.py"}) is None

    def test_cat_normal_file_passes(self):
        assert decide("Bash", {"command": "cat /Users/dev/src/main.py"}) is None

    def test_non_output_extension_passes(self):
        assert (
            decide(
                "Read",
                {"file_path": "/private/tmp/claude-501/proj/sess/tasks/config.json"},
            )
            is None
        )

    def test_other_tool_passes(self):
        assert decide("Grep", {"pattern": "test"}) is None

    def test_empty_inputs_pass(self):
        assert decide("Read", {}) is None
        assert decide("Bash", {}) is None

    def test_deny_message_is_tool_neutral(self):
        result = decide("Read", {"file_path": "/private/tmp/claude-1/x/tasks/y.output"})
        assert result is not None
        reason = result["hookSpecificOutput"]["permissionDecisionReason"]
        assert "agent output files" in reason.lower()

    def test_linux_path_read_denied(self):
        """Linux subagent output dir is /tmp/claude-<pid>/... (no /private prefix)."""
        result = decide(
            "Read",
            {"file_path": "/tmp/claude-12345/proj/sess/tasks/abc.output"},
        )
        assert result is not None
        assert result["hookSpecificOutput"]["permissionDecision"] == "deny"

    def test_linux_path_cat_denied(self):
        result = decide(
            "Bash",
            {"command": "cat /tmp/claude-99/proj/sess/tasks/abc.output"},
        )
        assert result is not None
        assert result["hookSpecificOutput"]["permissionDecision"] == "deny"

    def test_unrelated_dot_output_passes(self):
        """Paths containing .output mid-string outside /tasks/ must not match."""
        assert decide("Read", {"file_path": "/Users/dev/x.output.bak"}) is None
        assert decide("Read", {"file_path": "/var/log/foo.output_old"}) is None


class TestExpandedReaderCoverage:
    """File-reader coverage beyond cat/head/tail."""

    @pytest.mark.parametrize(
        "command",
        [
            "less /private/tmp/claude-1/x/tasks/y.output",
            "bat /private/tmp/claude-1/x/tasks/y.output",
            "more /private/tmp/claude-1/x/tasks/y.output",
            "vim /private/tmp/claude-1/x/tasks/y.output",
            "view /private/tmp/claude-1/x/tasks/y.output",
            "xxd /private/tmp/claude-1/x/tasks/y.output",
            "hexdump /private/tmp/claude-1/x/tasks/y.output",
            "strings /private/tmp/claude-1/x/tasks/y.output",
            "rg foo /private/tmp/claude-1/x/tasks/y.output",
            "grep foo /private/tmp/claude-1/x/tasks/y.output",
            "tac /private/tmp/claude-1/x/tasks/y.output",
            " cat /private/tmp/claude-1/x/tasks/y.output",  # leading space
            "/bin/cat /private/tmp/claude-1/x/tasks/y.output",  # absolute path
        ],
    )
    def test_reader_command_denied(self, command):
        result = decide("Bash", {"command": command})
        assert result is not None
        assert result["hookSpecificOutput"]["permissionDecision"] == "deny"

    @pytest.mark.parametrize(
        "command",
        [
            # copy / move / network-copy
            "cp /private/tmp/claude-1/x/tasks/y.output /tmp/leak.txt",
            "mv /private/tmp/claude-1/x/tasks/y.output /tmp/leak.txt",
            "scp /tmp/claude-1/x/tasks/y.output user@host:/tmp/",
            "rsync /tmp/claude-1/x/tasks/y.output backup:/tmp/",
            "dd if=/private/tmp/claude-1/x/tasks/y.output of=/tmp/leak",
            # editors
            "nano /private/tmp/claude-1/x/tasks/y.output",
            "emacs /private/tmp/claude-1/x/tasks/y.output",
            # fingerprinting / size-leak
            "wc -l /private/tmp/claude-1/x/tasks/y.output",
            "md5sum /private/tmp/claude-1/x/tasks/y.output",
            "shasum /private/tmp/claude-1/x/tasks/y.output",
            "diff /private/tmp/claude-1/x/tasks/y.output /tmp/other",
            "tee /tmp/leak < /private/tmp/claude-1/x/tasks/y.output",
        ],
    )
    def test_extended_reader_command_denied(self, command):
        result = decide("Bash", {"command": command})
        assert result is not None, f"reader missed: {command!r}"
        assert result["hookSpecificOutput"]["permissionDecision"] == "deny"


class TestPathAsSignal:
    """Path-as-signal: any tool_input mentioning the pattern denies, regardless of verb."""

    AGENT_PATH = "/private/tmp/claude-1/x/tasks/y.output"
    LINUX_PATH = "/tmp/claude-99/x/tasks/y.output"

    def _assert_deny(self, result, label=""):
        assert result is not None, f"expected deny for {label!r}, got passthrough"
        assert result["hookSpecificOutput"]["permissionDecision"] == "deny"

    def test_read_with_path_denied(self):
        # Regression for the original Read-only enforcement.
        self._assert_deny(decide("Read", {"file_path": self.AGENT_PATH}))

    def test_glob_pattern_with_path_denied(self):
        self._assert_deny(decide("Glob", {"pattern": self.AGENT_PATH}))

    def test_grep_path_field_denied(self):
        self._assert_deny(decide("Grep", {"pattern": "foo", "path": self.AGENT_PATH}))

    def test_multiedit_file_path_denied(self):
        self._assert_deny(
            decide(
                "MultiEdit",
                {"file_path": self.AGENT_PATH, "edits": [{"old_string": "a", "new_string": "b"}]},
            )
        )

    def test_webfetch_file_url_denied(self):
        self._assert_deny(
            decide("WebFetch", {"url": f"file://{self.AGENT_PATH}", "prompt": "summarize"})
        )

    @pytest.mark.parametrize(
        "command",
        [
            # script-arg with no reader verb
            "python3 /private/tmp/claude-1/x/tasks/y.output",
            # bare stdin redirect
            "< /private/tmp/claude-1/x/tasks/y.output",
            # compound shell construct
            "while read l; do echo $l; done < /private/tmp/claude-1/x/tasks/y.output",
            # arbitrary binary
            "node /tmp/claude-99/x/tasks/y.output",
        ],
    )
    def test_bash_compound_shapes_denied(self, command):
        self._assert_deny(decide("Bash", {"command": command}), label=command)


class TestGlobPidBypass:
    """Glob metacharacters in the pid slot must still match the pattern."""

    @pytest.mark.parametrize(
        "command",
        [
            "cat /private/tmp/claude-*/proj/sess/tasks/*.output",
            "cat /tmp/claude-*/proj/sess/tasks/abc.output",
            "cat /private/tmp/claude-?/proj/sess/tasks/abc.output",
            "cat /private/tmp/claude-12*4/proj/sess/tasks/abc.output",
        ],
    )
    def test_glob_pid_in_command_denied(self, command):
        result = decide("Bash", {"command": command})
        assert result is not None, f"glob-pid bypass not denied: {command!r}"
        assert result["hookSpecificOutput"]["permissionDecision"] == "deny"

    def test_glob_pid_via_read_denied(self):
        result = decide(
            "Read",
            {"file_path": "/private/tmp/claude-*/proj/sess/tasks/abc.output"},
        )
        assert result is not None
        assert result["hookSpecificOutput"]["permissionDecision"] == "deny"

    def test_numeric_pid_still_matches(self):
        """Regression: literal digit pids must still match after the regex change."""
        result = decide(
            "Read",
            {"file_path": "/private/tmp/claude-1234/proj/sess/tasks/x.output"},
        )
        assert result is not None
        assert result["hookSpecificOutput"]["permissionDecision"] == "deny"


class TestCwdRelativeBypass:
    """Relative paths under an agent-session cwd must be resolved + matched."""

    AGENT_CWD = "/private/tmp/claude-1234/proj/sess"

    def test_cwd_relative_cat_denied(self):
        result = decide(
            "Bash",
            {"command": "cat tasks/abc.output"},
            cwd=self.AGENT_CWD,
        )
        assert result is not None
        assert result["hookSpecificOutput"]["permissionDecision"] == "deny"

    def test_cwd_relative_dotslash_cat_denied(self):
        result = decide(
            "Bash",
            {"command": "cat ./tasks/abc.output"},
            cwd=self.AGENT_CWD,
        )
        assert result is not None

    def test_cwd_relative_glob_cat_denied(self):
        result = decide(
            "Bash",
            {"command": "cat tasks/*.output"},
            cwd=self.AGENT_CWD,
        )
        assert result is not None

    def test_cwd_relative_read_denied(self):
        result = decide(
            "Read",
            {"file_path": "tasks/abc.output"},
            cwd=self.AGENT_CWD,
        )
        assert result is not None
        assert result["hookSpecificOutput"]["permissionDecision"] == "deny"

    def test_cwd_relative_linux_form_denied(self):
        result = decide(
            "Bash",
            {"command": "cat tasks/abc.output"},
            cwd="/tmp/claude-99/proj/sess",
        )
        assert result is not None

    def test_cwd_outside_session_passes(self):
        # Same relative path but cwd is NOT inside an agent session — passes.
        result = decide(
            "Bash",
            {"command": "cat tasks/abc.output"},
            cwd="/Users/dev/develop/myproj",
        )
        assert result is None

    def test_cwd_none_does_not_crash(self):
        # Default cwd=None must not break anything.
        result = decide("Bash", {"command": "cat tasks/abc.output"})
        assert result is None


class TestDecideRobustness:
    def test_numeric_file_path(self):
        with contextlib.suppress(TypeError):
            decide("Read", {"file_path": 12345})

    def test_empty_command_string(self):
        assert decide("Bash", {"command": ""}) is None

    def test_missing_file_path_key(self):
        assert decide("Read", {"other_key": "value"}) is None

    def test_missing_command_key(self):
        assert decide("Bash", {"other_key": "value"}) is None


class TestHookFunction:
    def test_agent_output_guard_imports(self):
        # Top-level import is the contract.
        assert callable(hook)

    def test_agent_output_guard_allows_safe_input(self, capsys):
        hook({"tool_name": "Read", "tool_input": {"file_path": "/Users/dev/file.py"}})
        assert capsys.readouterr().out == ""

    def test_agent_output_guard_denies_unsafe_input(self, capsys):
        # Fix #7: deny path now exits 2 — wrap in pytest.raises(SystemExit).
        with pytest.raises(SystemExit) as exc:
            hook(
                {
                    "tool_name": "Read",
                    "tool_input": {"file_path": "/private/tmp/claude-1/proj/sess/tasks/x.output"},
                }
            )
        assert exc.value.code == 2
        out = capsys.readouterr().out
        envelope = json.loads(out)
        assert envelope["hookSpecificOutput"]["permissionDecision"] == "deny"


class TestSubprocess:
    def _run_hook(self, stdin_data):
        return subprocess.run(
            [sys.executable, str(HOOK_PATH)],
            input=stdin_data,
            capture_output=True,
            text=True,
            check=False,
        )

    def test_empty_stdin(self):
        result = self._run_hook("")
        assert result.returncode == 0
        assert result.stdout.strip() == ""

    def test_malformed_json(self):
        # Malformed JSON fails closed with rc=2 instead of silently passing.
        result = self._run_hook("not json at all")
        assert result.returncode == 2

    def test_json_missing_keys(self):
        result = self._run_hook(json.dumps({"unexpected": "data"}))
        assert result.returncode == 0
        assert result.stdout.strip() == ""

    def test_subprocess_denies_agent_output(self):
        # Fix #7: deny path now exits 2.
        payload = json.dumps(
            {
                "tool_name": "Read",
                "tool_input": {"file_path": "/private/tmp/claude-1/proj/sess/tasks/x.output"},
            }
        )
        result = self._run_hook(payload)
        assert result.returncode == 2
        envelope = json.loads(result.stdout)
        assert envelope["hookSpecificOutput"]["permissionDecision"] == "deny"
