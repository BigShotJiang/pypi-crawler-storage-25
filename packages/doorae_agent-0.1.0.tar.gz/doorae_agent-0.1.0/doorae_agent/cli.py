"""CLI entry points -- ``doorae-agent`` and ``doorae-client``."""

from __future__ import annotations

import asyncio
import sys
from typing import Any

import click
import structlog

from doorae_agent.auth.token import load_token
from doorae_agent.integrations import ENGINES
from doorae_agent.profile.loader import load_profile

logger = structlog.get_logger(__name__)

_ENGINE_CHOICES = sorted(ENGINES.keys())


@click.command("doorae-agent")
@click.option(
    "--engine",
    required=False,
    default=None,
    type=click.Choice(_ENGINE_CHOICES),
    help="LLM engine to use.",
)
@click.option("--name", required=False, default=None, help="Agent display name")
@click.option("--server", required=False, default=None, help="WebSocket server URL (e.g. ws://localhost:8000)")
@click.option("--token", default=None, help="Auth token (or set DOORAE_TOKEN)")
@click.option("--room", "rooms", multiple=True, help="Room IDs to join")
@click.option("--model", default=None, help="LLM model name override")
@click.option("--system-prompt", default=None, help="System prompt override")
@click.option("--profile", default=None, help="Load agent profile from YAML file")
@click.option("--reasoning-effort", default=None, help="Reasoning effort level (low/medium/high)")
def agent_main(
    engine: str | None,
    name: str | None,
    server: str | None,
    token: str | None,
    rooms: tuple[str, ...],
    model: str | None,
    system_prompt: str | None,
    profile: str | None,
    reasoning_effort: str | None,
) -> None:
    """Run a Doorae agent with the specified engine."""
    # If --profile is given, load defaults from the YAML profile
    if profile:
        try:
            agent_profile = load_profile(profile)
        except FileNotFoundError as exc:
            click.echo(str(exc), err=True)
            sys.exit(1)
        engine = engine or agent_profile.engine
        name = name or agent_profile.name
        model = model or agent_profile.model or None
        system_prompt = system_prompt or agent_profile.system_prompt
        if not rooms:
            rooms = tuple(agent_profile.rooms)

    # Validate required fields after profile merge
    if not engine:
        click.echo("Error: --engine is required (or specify --profile).", err=True)
        sys.exit(1)
    if not name:
        click.echo("Error: --name is required (or specify --profile).", err=True)
        sys.exit(1)
    if not server:
        click.echo("Error: --server is required.", err=True)
        sys.exit(1)
    if not rooms:
        click.echo("Error: at least one --room is required (or specify --profile).", err=True)
        sys.exit(1)

    resolved_token = load_token(cli_token=token)
    asyncio.run(
        _run_agent(engine, name, server, resolved_token, list(rooms), model, system_prompt, reasoning_effort)
    )


async def _run_agent(
    engine: str,
    name: str,
    server: str,
    token: str,
    rooms: list[str],
    model: str | None,
    system_prompt: str | None,
    reasoning_effort: str | None = None,
) -> None:
    from doorae_agent.client import ChatClient

    client = ChatClient(server, token=token, agent_name=name)

    # Build kwargs for the integration function based on engine
    await _setup_engine(client, engine, name, model, system_prompt, reasoning_effort)

    for room_id in rooms:
        await client.join_room(room_id)

    click.echo(f"Agent '{name}' running with engine={engine}, rooms={rooms}")
    try:
        await client.run()
    finally:
        await client.close()


async def _setup_engine(
    client: Any,
    engine: str,
    name: str,
    model: str | None,
    system_prompt: str | None,
    reasoning_effort: str | None = None,
) -> None:
    """Lazy-import and wire the chosen engine to the client."""
    if engine == "openai":
        from doorae_agent.integrations.openai import integrate_with_openai

        await integrate_with_openai(
            client,
            model=model or "gpt-4o",
            system_prompt=system_prompt or "You are a helpful assistant.",
        )
    elif engine == "claude-code":
        from doorae_agent.integrations.claude_code import integrate_with_claude_code

        # Leave system_prompt None by default so CLAUDE.md (which
        # Phase 0 materializer symlinks to AGENTS.md) is the sole
        # system-level source. If a caller passes an explicit
        # system_prompt string, it gets layered on top via
        # ClaudeAgentOptions.system_prompt.
        await integrate_with_claude_code(
            client,
            agent_config={
                "name": name,
                "system_prompt": system_prompt,
                "model": model,
            },
        )
    elif engine == "anthropic":
        from doorae_agent.integrations.anthropic import integrate_with_anthropic

        await integrate_with_anthropic(
            client,
            model=model or "claude-sonnet-4-20250514",
            system_prompt=system_prompt or "You are a helpful assistant.",
        )
    elif engine == "codex":
        from doorae_agent.integrations.codex import integrate_with_codex

        await integrate_with_codex(
            client,
            model=model,  # None → codex CLI 기본 모델 사용
            system_prompt=system_prompt or "You are a helpful coding assistant.",
            reasoning_effort=reasoning_effort,
        )
    elif engine == "gemini-cli":
        from doorae_agent.integrations.gemini_cli import integrate_with_gemini_cli

        await integrate_with_gemini_cli(
            client,
            model=model,  # None → gemini CLI 기본 모델 사용
            system_prompt=system_prompt or "You are a helpful coding assistant.",
            reasoning_effort=reasoning_effort,
        )
    elif engine == "openhands":
        from doorae_agent.integrations.openhands import integrate_with_openhands

        await integrate_with_openhands(client)
    elif engine == "deep-agents":
        from doorae_agent.integrations.deep_agents import integrate_with_deep_agents

        await integrate_with_deep_agents(client)
    else:
        click.echo(f"Engine '{engine}' is not yet implemented.", err=True)
        sys.exit(1)


@click.command("doorae-client")
@click.option("--server", required=True, help="WebSocket server URL")
@click.option("--user", required=True, help="User display name")
@click.option("--room", "rooms", multiple=True, required=True, help="Room IDs to join")
@click.option("--token", default=None, help="Auth token (or set DOORAE_TOKEN)")
def client_main(
    server: str,
    user: str,
    rooms: tuple[str, ...],
    token: str | None,
) -> None:
    """Run a text-based chat client."""
    resolved_token = load_token(cli_token=token)
    asyncio.run(_run_client(server, user, list(rooms), resolved_token))


async def _run_client(
    server: str,
    user: str,
    rooms: list[str],
    token: str,
) -> None:
    from doorae_agent.client import ChatClient

    client = ChatClient(server, token=token, agent_name=user)

    @client.on_message
    async def _print_msg(msg: dict) -> None:
        content = msg.get("content", "")
        pid = msg.get("participant_id", "?")
        room_id = msg.get("room_id", "?")
        print(f"[{room_id}] {pid}: {content}")

    for room_id in rooms:
        await client.join_room(room_id)

    click.echo(f"Connected as '{user}' to rooms: {rooms}")
    click.echo("Type messages and press Enter to send. Ctrl+C to exit.")

    # Run reader and stdin sender concurrently
    async def _stdin_sender() -> None:
        loop = asyncio.get_event_loop()
        while True:
            try:
                line = await loop.run_in_executor(None, sys.stdin.readline)
                if not line:
                    break
                line = line.strip()
                if line and rooms:
                    await client.send(rooms[0], line)
            except (EOFError, KeyboardInterrupt):
                break

    try:
        await asyncio.gather(
            client.run(),
            _stdin_sender(),
            return_exceptions=True,
        )
    finally:
        await client.close()


if __name__ == "__main__":
    agent_main()
