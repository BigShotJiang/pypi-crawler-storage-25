"""HTTP transport layer with retry, throttle, and error handling."""

from __future__ import annotations

import logging
import time
import warnings
from typing import Any

import httpx
from tenacity import (
    RetryCallState,
    retry,
    retry_if_result,
    stop_after_attempt,
    wait_exponential,
)

logger = logging.getLogger("prismadata.http")

_update_warned: set[str] = set()

from ._auth import AuthManager
from ._constants import (
    DEFAULT_TIMEOUT,
    RETRYABLE_STATUS_CODES,
    RETRY_AFTER_MAX,
    RETRY_MAX_ATTEMPTS,
    RETRY_WAIT_MAX,
    RETRY_WAIT_MIN,
    USER_AGENT_PREFIX,
)
from .exceptions import (
    AuthenticationError,
    PrismaDataError,
    QuotaExhaustedError,
    RateLimitError,
    ValidationError,
)


def _is_retryable(response: httpx.Response) -> bool:
    if response.status_code == 429:
        if response.headers.get("x-quota-remaining") == "0":
            return False
    return response.status_code in RETRYABLE_STATUS_CODES


_exponential = wait_exponential(min=RETRY_WAIT_MIN, max=RETRY_WAIT_MAX)


def _wait_for_retry(retry_state: RetryCallState) -> float:
    """Choose wait time based on server retry headers, falling back to exponential."""
    response = retry_state.outcome.result()

    retry_after = response.headers.get("retry-after")
    if retry_after is not None:
        try:
            return min(max(float(retry_after), 0), RETRY_AFTER_MAX)
        except ValueError:
            pass

    reset = response.headers.get("x-ratelimit-reset")
    if reset is not None and response.status_code == 429:
        try:
            wait = float(reset) - time.time()
            if wait > 0:
                return min(wait, RETRY_AFTER_MAX)
        except ValueError:
            pass

    return _exponential(retry_state)


class HttpClient:
    """HTTP client with automatic auth, retry, and throttle."""

    def __init__(
        self,
        auth: AuthManager,
        timeout: int = DEFAULT_TIMEOUT,
        version: str = "0.1.0",
        app_name: str | None = None,
    ) -> None:
        self._auth = auth
        self._timeout = timeout
        self._last_request_time: float = 0.0
        self._rl_remaining: int | None = None
        self._rl_reset: float | None = None
        self._quota_remaining: int | None = None
        self._quota_reset: float | None = None
        self._quota_limit: int | None = None
        self._quota_used: int | None = None
        self._quota_period: str | None = None
        headers: dict[str, str] = {
            "User-Agent": f"{USER_AGENT_PREFIX}/{version}",
            "X-Client": f"{USER_AGENT_PREFIX}/{version}",
        }
        if app_name:
            headers["X-App"] = app_name
        self._client = httpx.Client(timeout=timeout, headers=headers)

    def close(self) -> None:
        self._client.close()

    def get(self, path: str, params: dict[str, Any] | None = None) -> Any:
        return self._request("GET", path, params=params)

    def post(
        self, path: str, json_body: Any = None, params: dict[str, Any] | None = None,
        timeout: int | None = None,
    ) -> Any:
        return self._request("POST", path, json_body=json_body, params=params, timeout=timeout)

    def _request(
        self,
        method: str,
        path: str,
        params: dict[str, Any] | None = None,
        json_body: Any = None,
        timeout: int | None = None,
    ) -> Any:
        response = self._do_request(method, path, params, json_body, timeout=timeout)
        return _handle_response(response)

    @retry(
        retry=retry_if_result(_is_retryable),
        stop=stop_after_attempt(RETRY_MAX_ATTEMPTS),
        wait=_wait_for_retry,
        retry_error_callback=lambda state: state.outcome.result(),
    )
    def _do_request(
        self,
        method: str,
        path: str,
        params: dict[str, Any] | None = None,
        json_body: Any = None,
        timeout: int | None = None,
    ) -> httpx.Response:
        self._throttle()
        headers = self._auth.get_headers()
        url = f"{self._auth._base_url}{path}"

        if params:
            params = {k: v for k, v in params.items() if v is not None}

        request_kwargs: dict[str, Any] = {}
        if timeout is not None:
            request_kwargs["timeout"] = timeout

        logger.debug("%s %s", method, path)
        t0 = time.monotonic()
        response = self._client.request(
            method, url, params=params, json=json_body, headers=headers, **request_kwargs
        )
        elapsed = time.monotonic() - t0
        self._update_rate_limit(response)
        status = response.status_code
        if status in RETRYABLE_STATUS_CODES:
            logger.warning("Retryable %d on %s %s, will retry", status, method, path)
        else:
            logger.debug("%s %s -> %d (%.1fs)", method, path, status, elapsed)
        return response

    def _update_rate_limit(self, response: httpx.Response) -> None:
        """Read rate limit and quota state from KrakenD response headers."""
        remaining = response.headers.get("x-ratelimit-remaining")
        reset = response.headers.get("x-ratelimit-reset")
        if remaining is not None:
            self._rl_remaining = int(remaining)
        if reset is not None:
            self._rl_reset = float(reset)
        q_remaining = response.headers.get("x-quota-remaining")
        if q_remaining is not None:
            self._quota_remaining = int(q_remaining)
            q_limit = response.headers.get("x-quota-limit")
            q_used = response.headers.get("x-quota-used")
            q_period = response.headers.get("x-quota-period")
            q_reset = response.headers.get("x-quota-reset")
            if q_limit is not None:
                self._quota_limit = int(q_limit)
            if q_used is not None:
                self._quota_used = int(q_used)
            if q_period is not None:
                self._quota_period = q_period
            if q_reset is not None:
                self._quota_reset = float(q_reset)

    def _throttle(self) -> None:
        if self._quota_remaining is not None and self._quota_remaining <= 0:
            msg = "Quota exhausted: 0 requests remaining"
            if self._quota_reset:
                msg += f" (resets at {int(self._quota_reset)})"
            raise QuotaExhaustedError(msg)

        if self._rl_remaining is not None and self._rl_remaining <= 0:
            if self._rl_reset:
                wait = self._rl_reset - time.time()
                if wait > 0:
                    logger.debug("Rate limit: sleeping %.2fs (headers)", wait)
                    time.sleep(wait)
            self._rl_remaining = None
            self._rl_reset = None
            return

        if self._rl_remaining is not None:
            return

        rate_limit = self._auth.rate_limit
        if not rate_limit or rate_limit <= 0:
            return
        min_interval = 1.0 / rate_limit
        elapsed = time.time() - self._last_request_time
        if elapsed < min_interval:
            wait = min_interval - elapsed
            logger.debug("Rate limit: sleeping %.2fs (jwt claim)", wait)
            time.sleep(wait)
        self._last_request_time = time.time()


def _check_client_update(response: httpx.Response) -> None:
    """Warn user once if server signals a newer SDK version is available."""
    header = response.headers.get("x-client-update")
    if not header:
        return
    version = header.split(";", 1)[0].strip()
    if version in _update_warned:
        return
    _update_warned.add(version)
    message = header.split(";", 1)[1].strip() if ";" in header else (
        f"A new version of the PrismaData SDK is available: {version}. "
        f"Upgrade with: pip install --upgrade prismadata"
    )
    warnings.warn(message, UserWarning, stacklevel=6)
    logger.info("SDK update available: %s", version)


def _handle_response(response: httpx.Response) -> Any:
    _check_client_update(response)
    status = response.status_code

    if status == 200:
        try:
            return response.json()
        except Exception as exc:
            raise PrismaDataError(
                f"Invalid JSON in API response: {exc}",
                status_code=status, body=response.text,
                headers=dict(response.headers),
            ) from exc

    try:
        body = response.json()
    except Exception:
        body = response.text

    headers = dict(response.headers)

    if status in (401, 403):
        raise AuthenticationError(
            f"Authentication error ({status}): {response.text}",
            status_code=status, body=body, headers=headers,
        )

    if status == 422:
        raise ValidationError(
            f"Validation error: {response.text}",
            status_code=status, body=body, headers=headers,
        )

    if status == 429:
        if response.headers.get("x-quota-remaining") == "0":
            raise QuotaExhaustedError(
                f"Quota exhausted: {response.text}",
                status_code=status, body=body, headers=headers,
            )
        raise RateLimitError(
            f"Rate limit exceeded: {response.text}",
            status_code=status, body=body, headers=headers,
        )

    if status == 402:
        raise QuotaExhaustedError(
            f"Quota exhausted: {response.text}",
            status_code=status, body=body, headers=headers,
        )

    raise PrismaDataError(
        f"API error ({status}): {response.text}",
        status_code=status, body=body, headers=headers,
    )
