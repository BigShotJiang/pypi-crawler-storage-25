"""Batch processing with automatic chunking."""

from __future__ import annotations

import logging
import math
from typing import Any, Awaitable, Callable, Literal

from .exceptions import BatchError

logger = logging.getLogger("prismadata.batch")


def split_into_groups(
    items: dict[str, Any], num_groups: int,
) -> list[dict[str, Any]]:
    """Split a dict into num_groups roughly-equal sub-dicts.

    Args:
        items: Dictionary to split.
        num_groups: Number of groups (must be >= 1).

    Returns:
        List of dicts, each containing a subset of the items.
    """
    keys = list(items.keys())
    group_size = math.ceil(len(keys) / num_groups)
    return [
        {k: items[k] for k in keys[i : i + group_size]}
        for i in range(0, len(keys), group_size)
    ]


def _raise_if_partial(
    results: dict[str, Any],
    failed_keys: list[str],
    errors: list[Exception],
) -> None:
    """Raise BatchError if any chunks failed."""
    if not errors:
        return
    msg = f"Batch completed with {len(errors)} chunk failure(s), {len(failed_keys)} keys failed"
    raise BatchError(
        msg,
        partial_results=results,
        failed_keys=failed_keys,
    )


def _validate_on_error(on_error: str) -> None:
    if on_error not in ("raise", "skip"):
        raise ValueError(f"on_error must be 'raise' or 'skip', got {on_error!r}")


def process_batch(
    items: dict[str, list[float]],
    request_fn: Callable[[dict[str, list[float]]], dict[str, Any]],
    max_size: int,
    on_progress: Callable[[int], None] | None = None,
    on_error: Literal["raise", "skip"] = "raise",
) -> dict[str, Any]:
    """Split a dict of {id: [lat, lng]} into chunks and merge results.

    Args:
        items: Mapping of point_id to [lat, lng].
        request_fn: Function that posts a batch and returns results dict.
        max_size: Maximum items per request.
        on_progress: Callback invoked with the number of items completed per chunk.
        on_error: ``"raise"`` (default) raises BatchError on partial failure;
            ``"skip"`` logs a warning and returns partial results.

    Returns:
        Merged results dict.

    Raises:
        BatchError: If one or more chunks fail and on_error is ``"raise"``.
    """
    _validate_on_error(on_error)
    keys = list(items.keys())
    total = len(keys)
    num_chunks = math.ceil(total / max_size) if total else 0
    logger.debug("Processing %d items in %d chunks (max_size=%d)", total, num_chunks, max_size)
    results: dict[str, Any] = {}
    failed_keys: list[str] = []
    errors: list[Exception] = []

    chunk_idx = 0
    for start in range(0, total, max_size):
        chunk_idx += 1
        chunk_keys = keys[start : start + max_size]
        chunk = {k: items[k] for k in chunk_keys}
        try:
            chunk_result = request_fn(chunk)
            results.update(chunk_result)
            logger.debug("Chunk %d/%d completed (%d items)", chunk_idx, num_chunks, len(chunk_keys))
        except Exception as exc:
            failed_keys.extend(chunk_keys)
            errors.append(exc)
            logger.warning("Chunk %d/%d failed (%d items): %s", chunk_idx, num_chunks, len(chunk_keys), exc)
        if on_progress:
            on_progress(len(chunk_keys))

    if on_error == "raise":
        _raise_if_partial(results, failed_keys, errors)
    elif errors:
        logger.warning(
            "Batch completed with %d failure(s), %d keys skipped, returning %d partial results",
            len(errors), len(failed_keys), len(results),
        )
    return results


def process_routing_batch(
    items: list[dict[str, Any]],
    request_fn: Callable[[list[dict[str, Any]]], dict[str, Any]],
    max_size: int,
    on_progress: Callable[[int], None] | None = None,
    on_error: Literal["raise", "skip"] = "raise",
) -> dict[str, Any]:
    """Split a list of routing items into chunks and merge results.

    Args:
        items: List of routing request items.
        request_fn: Function that posts a batch and returns results dict.
        max_size: Maximum items per request.
        on_progress: Callback invoked with the number of items completed per chunk.
        on_error: ``"raise"`` (default) raises BatchError on partial failure;
            ``"skip"`` logs a warning and returns partial results.

    Returns:
        Merged results dict with TOTAL, SUCESSOS, FALHAS, RESULTADOS.

    Raises:
        BatchError: If one or more chunks fail and on_error is ``"raise"``.
    """
    _validate_on_error(on_error)
    total = len(items)
    num_chunks = math.ceil(total / max_size) if total else 0
    logger.debug("Processing %d items in %d chunks (max_size=%d)", total, num_chunks, max_size)
    merged: dict[str, Any] = {"TOTAL": 0, "SUCESSOS": 0, "FALHAS": 0, "RESULTADOS": []}
    failed_keys: list[str] = []
    errors: list[Exception] = []

    chunk_idx = 0
    for start in range(0, total, max_size):
        chunk_idx += 1
        chunk = items[start : start + max_size]
        try:
            chunk_result = request_fn(chunk)
            merged["TOTAL"] += chunk_result.get("TOTAL", 0)
            merged["SUCESSOS"] += chunk_result.get("SUCESSOS", 0)
            merged["FALHAS"] += chunk_result.get("FALHAS", 0)
            merged["RESULTADOS"].extend(chunk_result.get("RESULTADOS", []))
            logger.debug("Chunk %d/%d completed (%d items)", chunk_idx, num_chunks, len(chunk))
        except Exception as exc:
            failed_keys.extend(str(start + i) for i in range(len(chunk)))
            errors.append(exc)
            logger.warning("Chunk %d/%d failed (%d items): %s", chunk_idx, num_chunks, len(chunk), exc)
        if on_progress:
            on_progress(len(chunk))

    if on_error == "raise":
        _raise_if_partial(merged, failed_keys, errors)
    elif errors:
        logger.warning(
            "Batch completed with %d failure(s), %d keys skipped, returning %d partial results",
            len(errors), len(failed_keys), merged["SUCESSOS"],
        )
    return merged


async def async_process_batch(
    items: dict[str, list[float]],
    request_fn: Callable[[dict[str, list[float]]], Awaitable[dict[str, Any]]],
    max_size: int,
    on_progress: Callable[[int], None] | None = None,
    on_error: Literal["raise", "skip"] = "raise",
) -> dict[str, Any]:
    """Async version of process_batch — sequential chunks to respect rate limits."""
    _validate_on_error(on_error)
    keys = list(items.keys())
    total = len(keys)
    num_chunks = math.ceil(total / max_size) if total else 0
    logger.debug("Async processing %d items in %d chunks (max_size=%d)", total, num_chunks, max_size)
    results: dict[str, Any] = {}
    failed_keys: list[str] = []
    errors: list[Exception] = []

    chunk_idx = 0
    for start in range(0, total, max_size):
        chunk_idx += 1
        chunk_keys = keys[start : start + max_size]
        chunk = {k: items[k] for k in chunk_keys}
        try:
            chunk_result = await request_fn(chunk)
            results.update(chunk_result)
            logger.debug("Chunk %d/%d completed (%d items)", chunk_idx, num_chunks, len(chunk_keys))
        except Exception as exc:
            failed_keys.extend(chunk_keys)
            errors.append(exc)
            logger.warning("Chunk %d/%d failed (%d items): %s", chunk_idx, num_chunks, len(chunk_keys), exc)
        if on_progress:
            on_progress(len(chunk_keys))

    if on_error == "raise":
        _raise_if_partial(results, failed_keys, errors)
    elif errors:
        logger.warning(
            "Batch completed with %d failure(s), %d keys skipped, returning %d partial results",
            len(errors), len(failed_keys), len(results),
        )
    return results


async def async_process_routing_batch(
    items: list[dict[str, Any]],
    request_fn: Callable[[list[dict[str, Any]]], Awaitable[dict[str, Any]]],
    max_size: int,
    on_progress: Callable[[int], None] | None = None,
    on_error: Literal["raise", "skip"] = "raise",
) -> dict[str, Any]:
    """Async version of process_routing_batch — sequential chunks to respect rate limits."""
    _validate_on_error(on_error)
    total = len(items)
    num_chunks = math.ceil(total / max_size) if total else 0
    logger.debug("Async processing %d items in %d chunks (max_size=%d)", total, num_chunks, max_size)
    merged: dict[str, Any] = {"TOTAL": 0, "SUCESSOS": 0, "FALHAS": 0, "RESULTADOS": []}
    failed_keys: list[str] = []
    errors: list[Exception] = []

    chunk_idx = 0
    for start in range(0, total, max_size):
        chunk_idx += 1
        chunk = items[start : start + max_size]
        try:
            chunk_result = await request_fn(chunk)
            merged["TOTAL"] += chunk_result.get("TOTAL", 0)
            merged["SUCESSOS"] += chunk_result.get("SUCESSOS", 0)
            merged["FALHAS"] += chunk_result.get("FALHAS", 0)
            merged["RESULTADOS"].extend(chunk_result.get("RESULTADOS", []))
            logger.debug("Chunk %d/%d completed (%d items)", chunk_idx, num_chunks, len(chunk))
        except Exception as exc:
            failed_keys.extend(str(start + i) for i in range(len(chunk)))
            errors.append(exc)
            logger.warning("Chunk %d/%d failed (%d items): %s", chunk_idx, num_chunks, len(chunk), exc)
        if on_progress:
            on_progress(len(chunk))

    if on_error == "raise":
        _raise_if_partial(merged, failed_keys, errors)
    elif errors:
        logger.warning(
            "Batch completed with %d failure(s), %d keys skipped, returning %d partial results",
            len(errors), len(failed_keys), merged["SUCESSOS"],
        )
    return merged
