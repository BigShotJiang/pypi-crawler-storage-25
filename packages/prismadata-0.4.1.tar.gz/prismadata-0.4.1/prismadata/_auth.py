"""JWT authentication manager for the PrismaData API."""

from __future__ import annotations

import base64
import json
import logging
import threading
import time
from typing import Any

import httpx

from ._constants import TOKEN_RENEW_MARGIN
from .exceptions import AuthenticationError

logger = logging.getLogger("prismadata.auth")


class AuthManager:
    """Manages JWT token lifecycle: obtain, cache, and auto-renew."""

    def __init__(
        self,
        base_url: str,
        timeout: int,
        *,
        api_key: str | None = None,
        username: str | None = None,
        password: str | None = None,
    ) -> None:
        self._base_url = base_url
        self._timeout = timeout
        self._api_key = api_key
        self._username = username
        self._password = password
        self._token: str | None = None
        self._token_exp: float = 0.0
        self._rate_limit: float | None = None
        self._sandbox: bool = False
        self._lock = threading.Lock()

    @property
    def rate_limit(self) -> float | None:
        return self._rate_limit

    @property
    def is_sandbox(self) -> bool:
        return self._sandbox

    def authenticate(self) -> None:
        """Force token fetch immediately. Raises AuthenticationError on failure."""
        with self._lock:
            self._fetch_token()

    def get_headers(self) -> dict[str, str]:
        if self._api_key:
            self._try_refresh_claims()
            return {"X-Apikey": self._api_key}
        self._ensure_token()
        return {"Authorization": f"Bearer {self._token}"}

    def _try_refresh_claims(self) -> None:
        """Best-effort claim refresh in API key mode.

        Uses token exp as cadence — adapts to whatever validity
        the server sets. Failures are logged as warnings.
        """
        try:
            self._ensure_token()
        except Exception as exc:
            logger.warning("Claim refresh failed (API key mode): %s", exc)

    def _ensure_token(self) -> None:
        if self._token and time.time() < (self._token_exp - TOKEN_RENEW_MARGIN):
            return
        with self._lock:
            if self._token and time.time() < (self._token_exp - TOKEN_RENEW_MARGIN):
                return
            self._fetch_token()

    def _fetch_token(self) -> None:
        mode = "api_key" if self._api_key else "credentials"
        logger.debug("Fetching token (mode=%s)", mode)

        if self._api_key:
            data = {"api_key": self._api_key}
        else:
            data = {"username": self._username, "password": self._password}

        try:
            resp = httpx.post(
                f"{self._base_url}/auth/token",
                data=data,
                timeout=self._timeout,
            )
        except httpx.HTTPError as exc:
            raise AuthenticationError(f"Failed to connect to auth endpoint: {exc}") from exc

        if resp.status_code in (401, 403):
            raise AuthenticationError(f"Authentication failed: {resp.text}")
        resp.raise_for_status()

        body = resp.json()
        self._token = body["access_token"]
        claims = _decode_jwt_claims(self._token)
        self._token_exp = claims.get("exp", time.time() + 3600)
        self._rate_limit = claims.get("rate_limit")
        self._sandbox = claims.get("sandbox", False)
        expires_in = self._token_exp - time.time()
        logger.debug("Token obtained, expires in %.0fs, rate_limit=%s", expires_in, self._rate_limit)


def _decode_jwt_claims(token: str) -> dict[str, Any]:
    """Decode JWT payload without signature verification."""
    parts = token.split(".")
    if len(parts) != 3:
        return {}
    payload = parts[1]
    padding = 4 - len(payload) % 4
    if padding != 4:
        payload += "=" * padding
    try:
        return json.loads(base64.urlsafe_b64decode(payload))
    except Exception:
        return {}
