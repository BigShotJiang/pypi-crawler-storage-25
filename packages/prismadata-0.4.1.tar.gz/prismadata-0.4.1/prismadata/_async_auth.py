"""Async JWT authentication manager for the PrismaData API."""

from __future__ import annotations

import asyncio
import logging
import time
from typing import Any

import httpx

from ._auth import _decode_jwt_claims
from ._constants import TOKEN_RENEW_MARGIN
from .exceptions import AuthenticationError

logger = logging.getLogger("prismadata.async_auth")


class AsyncAuthManager:
    """Manages JWT token lifecycle asynchronously."""

    def __init__(
        self,
        base_url: str,
        timeout: int,
        *,
        api_key: str | None = None,
        username: str | None = None,
        password: str | None = None,
    ) -> None:
        self._base_url = base_url
        self._timeout = timeout
        self._api_key = api_key
        self._username = username
        self._password = password
        self._token: str | None = None
        self._token_exp: float = 0.0
        self._rate_limit: float | None = None
        self._sandbox: bool = False
        self._lock = asyncio.Lock()
        self._http_client: httpx.AsyncClient | None = None

    def set_http_client(self, client: httpx.AsyncClient) -> None:
        """Attach a shared httpx.AsyncClient for token refresh requests."""
        self._http_client = client

    @property
    def rate_limit(self) -> float | None:
        return self._rate_limit

    @property
    def is_sandbox(self) -> bool:
        return self._sandbox

    async def authenticate(self) -> None:
        """Force token fetch immediately."""
        async with self._lock:
            await self._fetch_token()

    async def ensure_valid_token(self) -> None:
        """Ensure a valid token is available, refreshing if needed."""
        if self._token and time.time() < (self._token_exp - TOKEN_RENEW_MARGIN):
            return
        async with self._lock:
            if self._token and time.time() < (self._token_exp - TOKEN_RENEW_MARGIN):
                return
            await self._fetch_token()

    def get_headers(self) -> dict[str, str]:
        """Return auth headers (sync — call ensure_valid_token first)."""
        if self._api_key:
            return {"X-Apikey": self._api_key}
        return {"Authorization": f"Bearer {self._token}"}

    async def _try_refresh_claims(self) -> None:
        """Best-effort claim refresh in API key mode."""
        try:
            await self.ensure_valid_token()
        except Exception as exc:
            logger.warning("Claim refresh failed (API key mode): %s", exc)

    async def _fetch_token(self) -> None:
        mode = "api_key" if self._api_key else "credentials"
        logger.debug("Fetching token (mode=%s)", mode)

        if self._api_key:
            data = {"api_key": self._api_key}
        else:
            data = {"username": self._username, "password": self._password}

        url = f"{self._base_url}/auth/token"
        try:
            if self._http_client is not None:
                resp = await self._http_client.post(url, data=data)
            else:
                async with httpx.AsyncClient(timeout=self._timeout) as http:
                    resp = await http.post(url, data=data)
        except httpx.HTTPError as exc:
            raise AuthenticationError(f"Failed to connect to auth endpoint: {exc}") from exc

        if resp.status_code in (401, 403):
            raise AuthenticationError(f"Authentication failed: {resp.text}")
        resp.raise_for_status()

        body = resp.json()
        self._token = body["access_token"]
        claims = _decode_jwt_claims(self._token)
        self._token_exp = claims.get("exp", time.time() + 3600)
        self._rate_limit = claims.get("rate_limit")
        self._sandbox = claims.get("sandbox", False)
        expires_in = self._token_exp - time.time()
        logger.debug("Token obtained, expires in %.0fs, rate_limit=%s", expires_in, self._rate_limit)
