"""Input validation helpers."""

from __future__ import annotations

_VALID_PROFILES = {"car", "foot", "bike"}


def validate_lat_lng(lat: float, lng: float) -> None:
    """Raise ValueError if coordinates are out of range."""
    if not -90 <= lat <= 90:
        raise ValueError(f"lat must be between -90 and 90, got {lat}")
    if not -180 <= lng <= 180:
        raise ValueError(f"lng must be between -180 and 180, got {lng}")


def validate_profile(profile: str) -> None:
    """Raise ValueError if routing profile is invalid."""
    if profile not in _VALID_PROFILES:
        raise ValueError(
            f"profile must be one of {sorted(_VALID_PROFILES)}, got '{profile}'"
        )


def validate_route_points(points: list) -> None:
    """Raise ValueError if route has fewer than 2 points."""
    if len(points) < 2:
        raise ValueError(
            f"route() requires at least 2 points, got {len(points)}"
        )
