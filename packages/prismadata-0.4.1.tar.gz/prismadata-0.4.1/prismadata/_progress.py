"""Optional tqdm progress bar wrapper."""

from __future__ import annotations

from contextlib import contextmanager
from typing import Any, Iterator


class _NoopBar:
    """No-op progress bar when tqdm is not available."""

    def update(self, n: int = 1) -> None:
        pass

    def close(self) -> None:
        pass


@contextmanager
def progress_bar(total: int, desc: str = "", enabled: bool = True) -> Iterator[Any]:
    """Create a progress bar if tqdm is available and enabled."""
    if not enabled:
        yield _NoopBar()
        return

    try:
        from tqdm import tqdm
        bar = tqdm(total=total, desc=desc, unit="req")
        try:
            yield bar
        finally:
            bar.close()
    except ImportError:
        yield _NoopBar()
