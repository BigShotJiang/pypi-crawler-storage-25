"""Column name cleaning utilities.

Transforms API column names like 'prismadata__geocoder__latitude'
into cleaner names like 'geocoder_latitude', keeping the service
prefix to avoid collisions across services.
"""

from __future__ import annotations

from typing import Any


def clean_columns(data: dict[str, Any]) -> dict[str, Any]:
    """Remove the 'prismadata__' prefix and convert '__' to '_'.

    Example:
        'prismadata__geocoder__latitude' -> 'geocoder_latitude'
        'prismadata__favela__distancia_m' -> 'favela_distancia_m'
    """
    return {_clean_key(k): v for k, v in data.items()}


def clean_columns_list(items: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Clean column names for a list of dicts."""
    return [clean_columns(item) for item in items]


def _clean_key(key: str) -> str:
    prefix = "prismadata__"
    if key.startswith(prefix):
        key = key[len(prefix):]
    return key.replace("__", "_")
