"""PrismaData API client with flat method interface."""

from __future__ import annotations

import os
import warnings
from typing import Any, Literal, TYPE_CHECKING

from ._auth import AuthManager
from ._batch import process_batch, process_routing_batch, split_into_groups
from ._types import QuotaInfo
from ._cache import CacheManager
from ._columns import clean_columns
from ._constants import (
    BASE_URL,
    DEFAULT_CACHE_TTL,
    DEFAULT_CHUNK_THRESHOLD,
    DEFAULT_MAX_WORKERS,
    DEFAULT_TIMEOUT,
    DIRECTION_MAP,
    ENV_API_KEY,
    ENV_PASSWORD,
    ENV_USERNAME,
    MAX_BATCH_SIZE,
    MAX_ROUTING_BATCH,
)
from ._http import HttpClient
from ._prepare import batch_complete, batch_prepare, wait_until_ready
from ._progress import progress_bar
from ._validation import validate_lat_lng, validate_profile, validate_route_points
from .exceptions import AuthenticationError

if TYPE_CHECKING:
    import pandas as pd

    from ._types import (
        BorderResult,
        GeocodeResult,
        IncomePdfResult,
        IncomeStaticResult,
        InfoscResult,
        IsochroneResult,
        PrecatoryResult,
        PrisonResult,
        ReverseGeocodeResult,
        RouteResult,
        RoutingBatchResult,
        SlumResult,
        UserInfo,
    )


def _resolve_credentials(
    api_key: str | None,
    username: str | None,
    password: str | None,
) -> dict[str, str]:
    """Resolve credentials from explicit args or environment variables."""
    if api_key:
        return {"api_key": api_key}
    if username and password:
        return {"username": username, "password": password}

    env_key = os.environ.get(ENV_API_KEY)
    if env_key:
        return {"api_key": env_key}

    env_user = os.environ.get(ENV_USERNAME)
    env_pass = os.environ.get(ENV_PASSWORD)
    if env_user and env_pass:
        return {"username": env_user, "password": env_pass}

    raise AuthenticationError(
        "No credentials provided. Pass api_key, username/password, "
        "or set PRISMADATA_APIKEY / PRISMADATA_USERNAME+PRISMADATA_PASSWORD "
        "environment variables."
    )


class Client:
    """PrismaData API client.

    Args:
        api_key: Your PrismaData API key.
        username: Username for login (alternative to api_key).
        password: Password for login (used with username).
        base_url: API base URL. Defaults to production.
        timeout: Request timeout in seconds.
        cache: Enable local disk cache (requires ``diskcache``).
        cache_ttl: Cache time-to-live in seconds.
        clean_columns: Strip the ``prismadata__`` prefix from response keys.
        show_progress: Show tqdm progress bars for batch operations.
        app_name: Application name sent in ``X-App`` header on every request.

    Credentials are resolved in order: explicit api_key, explicit
    username/password, then environment variables ``PRISMADATA_APIKEY``
    or ``PRISMADATA_USERNAME`` + ``PRISMADATA_PASSWORD``.

    Example::

        from prismadata import Client

        client = Client(api_key="your-key")
        result = client.geocode(full_address="Av Paulista 1000, Sao Paulo")
        print(result)
    """

    def __init__(
        self,
        api_key: str | None = None,
        *,
        username: str | None = None,
        password: str | None = None,
        base_url: str = BASE_URL,
        timeout: int = DEFAULT_TIMEOUT,
        cache: bool = False,
        cache_ttl: int = DEFAULT_CACHE_TTL,
        clean_columns: bool = False,
        show_progress: bool = True,
        app_name: str | None = None,
    ) -> None:
        credentials = _resolve_credentials(api_key, username, password)
        self._clean = clean_columns
        self._show_progress = show_progress
        self._auth = AuthManager(base_url, timeout, **credentials)
        self._auth.authenticate()
        if self._auth.is_sandbox:
            warnings.warn(
                "This token is configured for sandbox mode. "
                "API responses will contain synthetic data.",
                UserWarning,
                stacklevel=2,
            )
        from . import __version__

        self._http = HttpClient(self._auth, timeout=timeout, version=__version__, app_name=app_name)
        self._cache = CacheManager(enabled=cache, ttl=cache_ttl)

    def close(self) -> None:
        """Close underlying HTTP and cache connections."""
        self._http.close()
        self._cache.close()

    def __enter__(self) -> Client:
        return self

    def __exit__(self, *exc: object) -> None:
        self.close()

    @property
    def quota_info(self) -> QuotaInfo | None:
        """Last observed quota status, or ``None`` if no quota headers received."""
        if self._http._quota_remaining is None:
            return None
        info: QuotaInfo = {"remaining": self._http._quota_remaining}
        if self._http._quota_limit is not None:
            info["limit"] = self._http._quota_limit
        if self._http._quota_used is not None:
            info["used"] = self._http._quota_used
        if self._http._quota_period is not None:
            info["period"] = self._http._quota_period
        if self._http._quota_reset is not None:
            info["reset"] = int(self._http._quota_reset)
        return info

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _get(self, path: str, params: dict[str, Any] | None = None) -> Any:
        if params and self._cache.enabled:
            cached = self._cache.get(path, params)
            if cached is not None:
                return cached

        result = self._http.get(path, params)

        if params and self._cache.enabled:
            self._cache.set(path, params, result)

        return result

    def _post(
        self, path: str, body: Any = None, params: dict[str, Any] | None = None,
        timeout: int | None = None,
    ) -> Any:
        return self._http.post(path, json_body=body, params=params, timeout=timeout)

    def _maybe_clean(self, data: dict[str, Any]) -> dict[str, Any]:
        return clean_columns(data) if self._clean else data

    # ------------------------------------------------------------------
    # Auth
    # ------------------------------------------------------------------

    def me(self) -> UserInfo:
        """Return authenticated user information."""
        return self._get("/auth/me")

    # ------------------------------------------------------------------
    # Geocoding
    # ------------------------------------------------------------------

    def geocode(
        self,
        full_address: str | None = None,
        *,
        zipcode: str | None = None,
        number: str | int | None = None,
        street: str | None = None,
        city: str | None = None,
        state: str | None = None,
        neighborhood: str | None = None,
        street_type: str | None = None,
        street_title: str | None = None,
    ) -> GeocodeResult:
        """Geocode an address to coordinates.

        Args:
            full_address: Complete address string.
            zipcode: Postal code (CEP).
            number: Street number.
            street: Street name.
            city: City name.
            state: State abbreviation.
            neighborhood: Neighborhood / district.
            street_type: Street type (e.g. 'Rua', 'Avenida').
            street_title: Street title (e.g. 'Coronel', 'São').
        """
        params = {
            "endereco_completo": full_address,
            "cep": zipcode,
            "numero": number,
            "logradouro": street,
            "municipio": city,
            "estado": state,
            "localidade": neighborhood,
            "tipo_logradouro": street_type,
            "titulo_logradouro": street_title,
        }
        return self._maybe_clean(self._get("/location/geocoder", params))

    def reverse_geocode(self, lat: float, lng: float) -> ReverseGeocodeResult:
        """Reverse geocode coordinates to the nearest address.

        Args:
            lat: Latitude (-90 to 90).
            lng: Longitude (-180 to 180).
        """
        validate_lat_lng(lat, lng)
        return self._maybe_clean(self._get("/location/reverse_geocoder", {"lat": lat, "lng": lng}))

    # ------------------------------------------------------------------
    # Location services
    # ------------------------------------------------------------------

    def slum(self, lat: float, lng: float) -> SlumResult:
        """Query nearest slum/favela proximity data.

        Args:
            lat: Latitude.
            lng: Longitude.
        """
        validate_lat_lng(lat, lng)
        return self._maybe_clean(self._get("/location/slum", {"lat": lat, "lng": lng}))

    def prison(self, lat: float, lng: float) -> PrisonResult:
        """Query nearest prison proximity data.

        Args:
            lat: Latitude.
            lng: Longitude.
        """
        validate_lat_lng(lat, lng)
        return self._maybe_clean(self._get("/location/prison", {"lat": lat, "lng": lng}))

    def border(self, lat: float, lng: float) -> BorderResult:
        """Query proximity to Brazilian borders.

        Args:
            lat: Latitude.
            lng: Longitude.
        """
        validate_lat_lng(lat, lng)
        return self._maybe_clean(self._get("/location/border", {"lat": lat, "lng": lng}))

    def infosc(self, lat: float, lng: float) -> InfoscResult:
        """Query census sector information.

        Args:
            lat: Latitude.
            lng: Longitude.
        """
        validate_lat_lng(lat, lng)
        return self._maybe_clean(self._get("/location/infosc", {"lat": lat, "lng": lng}))

    def income_static(self, lat: float, lng: float) -> IncomeStaticResult:
        """Query static income estimates (percentiles and salary range).

        Args:
            lat: Latitude.
            lng: Longitude.
        """
        validate_lat_lng(lat, lng)
        return self._maybe_clean(
            self._get("/location/personal_income_static", {"lat": lat, "lng": lng})
        )

    def income_pdf(
        self,
        lat: float,
        lng: float,
        *,
        date: str | None = None,
        gender: str | None = None,
        age: float | None = None,
        is_responsible: str | None = None,
        income_compared: float | None = None,
    ) -> IncomePdfResult:
        """Query dynamic income estimates with detailed statistics.

        Args:
            lat: Latitude.
            lng: Longitude.
            date: Reference date (YYYY-MM-DD).
            gender: 'M' or 'F'.
            age: Person age (15-90).
            is_responsible: Whether head of household ('true'/'false').
            income_compared: Income value for comparison.
        """
        validate_lat_lng(lat, lng)
        params = {
            "lat": lat,
            "lng": lng,
            "date_income": date,
            "gender": gender,
            "age": age,
            "is_responsible": is_responsible,
            "income_compared": income_compared,
        }
        return self._maybe_clean(self._get("/location/personal_income_pdf", params))

    # ------------------------------------------------------------------
    # Routing
    # ------------------------------------------------------------------

    def route(
        self,
        points: list[tuple[float, float]],
        *,
        profile: str = "car",
    ) -> RouteResult:
        """Calculate a route between two or more points.

        Args:
            points: List of (lat, lng) tuples. Minimum 2 points.
            profile: Transportation profile ('car', 'foot', 'bike').
        """
        validate_route_points(points)
        validate_profile(profile)
        formatted = [f"{lat},{lng}" for lat, lng in points]
        return self._maybe_clean(
            self._get("/routing/route", {"points": formatted, "profile": profile})
        )

    def isochrone(
        self,
        lat: float,
        lng: float,
        *,
        time_limit: int = 600,
        profile: str = "car",
        direction: str = "outgoing",
    ) -> IsochroneResult:
        """Calculate an isochrone (reachable area within a time limit).

        Args:
            lat: Latitude.
            lng: Longitude.
            time_limit: Time limit in seconds (60-7200).
            profile: Transportation profile ('car', 'foot', 'bike').
            direction: 'outgoing' (from point) or 'incoming' (to point).
        """
        validate_lat_lng(lat, lng)
        validate_profile(profile)
        params = {
            "lat": lat,
            "lng": lng,
            "time_limit": time_limit,
            "profile": profile,
            "sentido": DIRECTION_MAP.get(direction, direction),
        }
        return self._maybe_clean(self._get("/routing/isochrone", params))

    # ------------------------------------------------------------------
    # Address validation
    # ------------------------------------------------------------------

    def compare_address(
        self,
        lat: float,
        lng: float,
        *,
        full_address: str | None = None,
        zipcode: str | None = None,
        number: str | int | None = None,
        street: str | None = None,
        city: str | None = None,
        state: str | None = None,
        neighborhood: str | None = None,
    ) -> dict[str, Any]:
        """Compare an address with coordinates to evaluate concordance.

        Args:
            lat: Latitude.
            lng: Longitude.
            full_address: Complete address string.
            zipcode: Postal code (CEP).
            number: Street number.
            street: Street name.
            city: City name.
            state: State abbreviation.
            neighborhood: Neighborhood / district.
        """
        validate_lat_lng(lat, lng)
        params = {
            "lat": lat,
            "lng": lng,
            "endereco_completo": full_address,
            "cep": zipcode,
            "numero": number,
            "logradouro": street,
            "municipio": city,
            "estado": state,
            "localidade": neighborhood,
        }
        return self._maybe_clean(self._get("/location/compare_address", params))

    def validate_address(
        self,
        locations: list[list[float]],
        addresses: list[str],
    ) -> list[dict[str, Any]]:
        """Validate addresses against a location history.

        Args:
            locations: List of [lat, lng, timestamp] location signals.
            addresses: List of full address strings (max 5).
        """
        body = {"locations": locations, "enderecos": addresses}
        result = self._post("/location/validate_addr", body)
        items = result.get("items", result) if isinstance(result, dict) else result
        if self._clean and isinstance(items, list):
            return [clean_columns(item) for item in items]
        return items

    def cluster_locations(
        self,
        locations: list[list[float]],
    ) -> list[dict[str, Any]]:
        """Cluster location history to identify frequent/prolonged locations.

        Args:
            locations: List of [lat, lng, timestamp] location signals.
        """
        result = self._post("/location/cluster_location_historic", locations)
        items = result.get("items", result) if isinstance(result, dict) else result
        if self._clean and isinstance(items, list):
            return [clean_columns(item) for item in items]
        return items

    # ------------------------------------------------------------------
    # Credit (precatory / RPV)
    # ------------------------------------------------------------------

    def precatory(
        self,
        *,
        cpf_cnpj: str | None = None,
        name: str | None = None,
    ) -> PrecatoryResult:
        """Query consolidated credit summary (precatorios and RPVs).

        Args:
            cpf_cnpj: CPF or CNPJ of the creditor.
            name: Creditor name.
        """
        params = {"id_credor": cpf_cnpj, "nome_credor": name}
        return self._maybe_clean(
            self._get("/credit/precatorio_rpv/consulta_credito", params)
        )

    def precatory_detail(
        self,
        *,
        cpf_cnpj: str | None = None,
        name: str | None = None,
    ) -> list[dict[str, Any]]:
        """Query detailed list of precatorios/RPVs for a creditor.

        Args:
            cpf_cnpj: CPF or CNPJ of the creditor.
            name: Creditor name.
        """
        params = {"id_credor": cpf_cnpj, "nome_credor": name}
        result = self._get("/credit/precatorio_rpv/detalha_credito", params)
        items = result.get("items", result) if isinstance(result, dict) else result
        if self._clean and isinstance(items, list):
            return [clean_columns(item) for item in items]
        return items

    # ------------------------------------------------------------------
    # Batch operations
    # ------------------------------------------------------------------

    def slum_batch(
        self, points: dict[str, list[float]], *,
        batch_size: int | None = None,
        on_error: Literal["raise", "skip"] = "raise",
        timeout: int | None = None,
    ) -> dict[str, Any]:
        """Batch query slum/favela data for multiple points.

        Args:
            points: Mapping of point_id to [lat, lng]. Max 1024 per request.
            batch_size: Override default chunk size (1024).
            on_error: ``"raise"`` (default) or ``"skip"`` to return partial results.
            timeout: Override default request timeout (seconds).
        """
        return self._location_batch(
            "/location/batch/slum", points,
            batch_size=batch_size, on_error=on_error, timeout=timeout,
        )

    def prison_batch(
        self, points: dict[str, list[float]], *,
        batch_size: int | None = None,
        on_error: Literal["raise", "skip"] = "raise",
        timeout: int | None = None,
    ) -> dict[str, Any]:
        """Batch query prison data for multiple points.

        Args:
            points: Mapping of point_id to [lat, lng]. Max 1024 per request.
            batch_size: Override default chunk size (1024).
            on_error: ``"raise"`` (default) or ``"skip"`` to return partial results.
            timeout: Override default request timeout (seconds).
        """
        return self._location_batch(
            "/location/batch/prison", points,
            batch_size=batch_size, on_error=on_error, timeout=timeout,
        )

    def border_batch(
        self, points: dict[str, list[float]], *,
        batch_size: int | None = None,
        on_error: Literal["raise", "skip"] = "raise",
        timeout: int | None = None,
    ) -> dict[str, Any]:
        """Batch query border data for multiple points.

        Args:
            points: Mapping of point_id to [lat, lng]. Max 1024 per request.
            batch_size: Override default chunk size (1024).
            on_error: ``"raise"`` (default) or ``"skip"`` to return partial results.
            timeout: Override default request timeout (seconds).
        """
        return self._location_batch(
            "/location/batch/border", points,
            batch_size=batch_size, on_error=on_error, timeout=timeout,
        )

    def infosc_batch(
        self, points: dict[str, list[float]], *,
        batch_size: int | None = None,
        on_error: Literal["raise", "skip"] = "raise",
        timeout: int | None = None,
    ) -> dict[str, Any]:
        """Batch query census sector data for multiple points.

        Args:
            points: Mapping of point_id to [lat, lng]. Max 1024 per request.
            batch_size: Override default chunk size (1024).
            on_error: ``"raise"`` (default) or ``"skip"`` to return partial results.
            timeout: Override default request timeout (seconds).
        """
        return self._location_batch(
            "/location/batch/infosc", points,
            batch_size=batch_size, on_error=on_error, timeout=timeout,
        )

    def personal_income_static_batch(
        self, points: dict[str, list[float]], *,
        batch_size: int | None = None,
        on_error: Literal["raise", "skip"] = "raise",
        timeout: int | None = None,
    ) -> dict[str, Any]:
        """Batch query static personal income data for multiple points.

        Args:
            points: Mapping of point_id to [lat, lng]. Max 1024 per request.
            batch_size: Override default chunk size (1024).
            on_error: ``"raise"`` (default) or ``"skip"`` to return partial results.
            timeout: Override default request timeout (seconds).
        """
        return self._location_batch(
            "/location/batch/personal_income_static", points,
            batch_size=batch_size, on_error=on_error, timeout=timeout,
        )

    def personal_income_pdf_batch(
        self, points: dict[str, list[float]], *,
        batch_size: int | None = None,
        on_error: Literal["raise", "skip"] = "raise",
        timeout: int | None = None,
    ) -> dict[str, Any]:
        """Batch query personal income PDF (probability distribution) for multiple points.

        Args:
            points: Mapping of point_id to [lat, lng]. Max 1024 per request.
            batch_size: Override default chunk size (1024).
            on_error: ``"raise"`` (default) or ``"skip"`` to return partial results.
            timeout: Override default request timeout (seconds).
        """
        return self._location_batch(
            "/location/batch/personal_income_pdf", points,
            batch_size=batch_size, on_error=on_error, timeout=timeout,
        )

    def personal_income_pdf_batch_detailed(
        self, points: dict[str, dict], *,
        batch_size: int | None = None,
        on_error: Literal["raise", "skip"] = "raise",
        timeout: int | None = None,
    ) -> dict[str, Any]:
        """Batch query personal income PDF with demographic parameters per point.

        Args:
            points: Mapping of point_id to dict with keys:
                - lat (float): Latitude (required)
                - lng (float): Longitude (required)
                - gender (str, optional): "M" or "F"
                - age (int, optional): Age
                - date_income (str, optional): Reference date
                - is_responsible (bool, optional): Household head
                - income_compared (str, optional): Income comparison
            batch_size: Override default chunk size (1024).
            on_error: ``"raise"`` (default) or ``"skip"`` to return partial results.
            timeout: Override default request timeout (seconds).
        """
        chunk_size = batch_size if batch_size is not None else MAX_BATCH_SIZE

        def _request(chunk: dict[str, dict]) -> dict[str, Any]:
            return self._post("/location/batch/personal_income_pdf", chunk, timeout=timeout)

        result = process_batch(points, _request, chunk_size, on_error=on_error)
        if self._clean:
            return {k: clean_columns(v) if isinstance(v, dict) else v for k, v in result.items()}
        return result

    def route_batch(
        self,
        items: list[dict[str, Any]],
        *,
        profile: str = "car",
        on_error: Literal["raise", "skip"] = "raise",
        timeout: int | None = None,
    ) -> RoutingBatchResult:
        """Batch calculate routes.

        Args:
            items: List of dicts with 'points' key (list of [lat, lng] pairs).
            profile: Transportation profile ('car', 'foot', 'bike').
            on_error: ``"raise"`` (default) or ``"skip"`` to return partial results.
            timeout: Override default request timeout (seconds).
        """

        validate_profile(profile)

        def _request(chunk: list[dict[str, Any]]) -> dict[str, Any]:
            return self._post("/routing/batch/route", {"items": chunk, "profile": profile}, timeout=timeout)

        return process_routing_batch(items, _request, MAX_ROUTING_BATCH, on_error=on_error)

    def isochrone_batch(
        self,
        items: list[dict[str, Any]],
        *,
        profile: str = "car",
        direction: str = "outgoing",
        on_error: Literal["raise", "skip"] = "raise",
        timeout: int | None = None,
    ) -> RoutingBatchResult:
        """Batch calculate isochrones.

        Args:
            items: List of dicts with 'lat', 'lng', and optional 'time_limit'.
            profile: Transportation profile ('car', 'foot', 'bike').
            direction: 'outgoing' or 'incoming'.
            on_error: ``"raise"`` (default) or ``"skip"`` to return partial results.
            timeout: Override default request timeout (seconds).
        """
        validate_profile(profile)
        sentido = DIRECTION_MAP.get(direction, direction)

        def _request(chunk: list[dict[str, Any]]) -> dict[str, Any]:
            return self._post(
                "/routing/batch/isochrone",
                {"items": chunk, "profile": profile, "sentido": sentido},
                timeout=timeout,
            )

        return process_routing_batch(items, _request, MAX_ROUTING_BATCH, on_error=on_error)

    # ------------------------------------------------------------------
    # Aggregator
    # ------------------------------------------------------------------

    def aggregate(
        self,
        lat: float,
        lng: float,
        *,
        services: list[str],
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Aggregate multiple location APIs in a single call.

        Args:
            lat: Latitude.
            lng: Longitude.
            services: List of service names to enable (e.g. ['slum', 'prison', 'infosc']).
            **kwargs: Additional parameters for specific services (e.g. gender, age).
        """
        validate_lat_lng(lat, lng)
        params: dict[str, Any] = {"lat": lat, "lng": lng}
        for svc in services:
            params[svc] = True
        params.update(kwargs)
        return self._maybe_clean(self._get("/location/aggregator", params))

    def aggregate_batch(
        self,
        points: dict[str, list[float]],
        *,
        services: list[str],
        batch_size: int | None = None,
        on_error: Literal["raise", "skip"] = "raise",
        timeout: int | None = None,
        show_progress: bool | None = None,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Batch aggregate multiple location APIs for multiple points.

        Args:
            points: Mapping of point_id to [lat, lng].
            services: List of service names to enable.
            batch_size: Override default chunk size (1024).
            on_error: ``"raise"`` (default) or ``"skip"`` to return partial results.
            timeout: Override default request timeout (seconds).
            show_progress: Override progress bar setting.
            **kwargs: Additional parameters for specific services.
        """
        params: dict[str, Any] = {}
        for svc in services:
            params[svc] = True
        params.update(kwargs)

        chunk_size = batch_size if batch_size is not None else MAX_BATCH_SIZE
        use_progress = show_progress if show_progress is not None else self._show_progress

        def _request(chunk: dict[str, list[float]]) -> dict[str, Any]:
            return self._post("/location/batch/aggregator", chunk, params=params, timeout=timeout)

        with progress_bar(len(points), desc="Aggregating", enabled=use_progress) as bar:

            def _on_progress(n: int) -> None:
                bar.update(n)

            result = process_batch(points, _request, chunk_size, on_progress=_on_progress, on_error=on_error)

        if self._clean:
            return {k: clean_columns(v) if isinstance(v, dict) else v for k, v in result.items()}
        return result

    # ------------------------------------------------------------------
    # Geocoder + Aggregator
    # ------------------------------------------------------------------

    def geocode_aggregate(
        self,
        *,
        services: list[str],
        full_address: str | None = None,
        zipcode: str | None = None,
        number: str | int | None = None,
        street: str | None = None,
        city: str | None = None,
        state: str | None = None,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Geocode an address and aggregate location APIs in a single call.

        Args:
            services: List of service names to enable.
            full_address: Complete address string.
            zipcode: Postal code (CEP).
            number: Street number.
            street: Street name.
            city: City name.
            state: State abbreviation.
            **kwargs: Additional parameters for specific services.
        """
        params: dict[str, Any] = {
            "endereco_completo": full_address,
            "cep": zipcode,
            "numero": number,
            "logradouro": street,
            "municipio": city,
            "estado": state,
        }
        for svc in services:
            params[svc] = True
        params.update(kwargs)
        return self._maybe_clean(self._get("/location/geocoder/aggregator", params))

    # ------------------------------------------------------------------
    # Batch geocoding
    # ------------------------------------------------------------------

    def geocode_batch(
        self,
        addresses: dict[str, dict[str, str]],
        *,
        batch_size: int | None = None,
        on_error: Literal["raise", "skip"] = "raise",
        timeout: int | None = None,
    ) -> dict[str, Any]:
        """Batch geocode multiple addresses.

        Args:
            addresses: Mapping of id to address dict. Each address dict may
                contain keys like ``endereco_completo``, ``cep``, ``numero``,
                ``logradouro``, ``municipio``, ``estado``, etc. Max 512 per chunk.
            batch_size: Override default chunk size (512).
            on_error: ``"raise"`` (default) or ``"skip"`` to return partial results.
            timeout: Override default request timeout (seconds).
        """
        chunk_size = batch_size if batch_size is not None else 512

        def _request(chunk: dict) -> dict[str, Any]:
            return self._post("/location/batch/geocoder", chunk, timeout=timeout)

        result = process_batch(addresses, _request, chunk_size, on_error=on_error)
        if self._clean:
            return {k: clean_columns(v) if isinstance(v, dict) else v for k, v in result.items()}
        return result

    def reverse_geocode_batch(
        self,
        points: dict[str, list[float]],
        *,
        batch_size: int | None = None,
        on_error: Literal["raise", "skip"] = "raise",
        timeout: int | None = None,
    ) -> dict[str, Any]:
        """Batch reverse geocode multiple coordinates.

        Args:
            points: Mapping of point_id to [lat, lng]. Max 1024 per request.
            batch_size: Override default chunk size (1024).
            on_error: ``"raise"`` (default) or ``"skip"`` to return partial results.
            timeout: Override default request timeout (seconds).
        """
        formatted = {k: {"lat": v[0], "lng": v[1]} for k, v in points.items()}
        return self._location_batch(
            "/location/batch/reverse_geocoder", formatted,
            batch_size=batch_size, on_error=on_error, timeout=timeout,
        )

    def geocode_aggregate_batch(
        self,
        addresses: dict[str, dict[str, str]],
        *,
        services: list[str],
        batch_size: int | None = None,
        on_error: Literal["raise", "skip"] = "raise",
        timeout: int | None = None,
        show_progress: bool | None = None,
        auto_scale: bool = True,
        max_workers: int = DEFAULT_MAX_WORKERS,
        chunk_threshold: int = DEFAULT_CHUNK_THRESHOLD,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Batch geocode addresses and aggregate location APIs.

        For large batches (above ``chunk_threshold``), the SDK signals the API
        to scale up infrastructure, splits the work across parallel workers,
        and signals scale-down when finished.

        Args:
            addresses: Mapping of id to address dict.
            services: List of service names to enable.
            batch_size: Override default chunk size (1024).
            on_error: ``"raise"`` (default) or ``"skip"`` to return partial results.
            timeout: Override default request timeout (seconds).
            show_progress: Override progress bar setting.
            auto_scale: If True, call prepare/complete for large batches.
            max_workers: Max parallel workers (server may return fewer).
            chunk_threshold: Minimum items to trigger auto-scaling.
            **kwargs: Additional parameters for specific services.
        """
        params: dict[str, Any] = {}
        for svc in services:
            params[svc] = True
        params.update(kwargs)

        chunk_size = batch_size if batch_size is not None else MAX_BATCH_SIZE
        use_progress = show_progress if show_progress is not None else self._show_progress
        total = len(addresses)
        should_scale = auto_scale and total >= chunk_threshold

        def _request(chunk: dict) -> dict[str, Any]:
            return self._post("/location/batch/geocoder/aggregator", chunk, params=params, timeout=timeout)

        if not should_scale:
            with progress_bar(total, desc="Geocode+Aggregating", enabled=use_progress) as bar:

                def _on_progress(n: int) -> None:
                    bar.update(n)

                result = process_batch(addresses, _request, chunk_size, on_progress=_on_progress, on_error=on_error)
        else:
            resp = batch_prepare(self._post, total)
            session_id = resp["session_id"]
            num_workers = min(max_workers, resp.get("max_workers", max_workers))

            try:
                wait_until_ready(self._get, session_id)
                groups = split_into_groups(addresses, num_workers)

                from concurrent.futures import ThreadPoolExecutor, as_completed

                def _process_group(group: dict) -> dict[str, Any]:
                    return process_batch(group, _request, chunk_size, on_error=on_error)

                with ThreadPoolExecutor(max_workers=num_workers) as executor:
                    futures = [executor.submit(_process_group, g) for g in groups]
                    result = {}
                    for f in as_completed(futures):
                        chunk_result = f.result()
                        result.update(chunk_result)
            finally:
                batch_complete(self._post, session_id)

        if self._clean:
            return {k: clean_columns(v) if isinstance(v, dict) else v for k, v in result.items()}
        return result

    # ------------------------------------------------------------------
    # Enrich (DataFrame)
    # ------------------------------------------------------------------

    def enrich(
        self,
        df: pd.DataFrame,
        *,
        lat_col: str = "lat",
        lng_col: str = "lng",
        services: list[str],
        show_progress: bool | None = None,
    ) -> pd.DataFrame:
        """Enrich a pandas DataFrame with PrismaData location intelligence.

        Extracts lat/lng coordinates, calls the aggregator batch endpoint,
        and merges results back into the DataFrame.

        Args:
            df: Input DataFrame with latitude and longitude columns.
            lat_col: Name of the latitude column.
            lng_col: Name of the longitude column.
            services: List of service names to aggregate.
            show_progress: Override progress bar setting.

        Returns:
            New DataFrame with enrichment columns appended.

        Example::

            import pandas as pd
            from prismadata import Client

            client = Client(api_key="your-key")
            df = pd.DataFrame({"lat": [-23.56], "lng": [-46.65]})
            enriched = client.enrich(df, services=["slum", "income_static"])
        """
        from ._enrich import enrich_dataframe

        use_progress = show_progress if show_progress is not None else self._show_progress

        def _batch_fn(
            points: dict[str, list[float]],
            services: list[str],
            show_progress: bool,
        ) -> dict[str, Any]:
            return self.aggregate_batch(
                points, services=services, show_progress=show_progress
            )

        return enrich_dataframe(
            df,
            batch_fn=_batch_fn,
            lat_col=lat_col,
            lng_col=lng_col,
            services=services,
            do_clean_columns=self._clean,
            show_progress=use_progress,
        )

    # ------------------------------------------------------------------
    # Sklearn integration
    # ------------------------------------------------------------------

    def get_transformer(
        self,
        *,
        services: list[str],
        lat_col: str = "lat",
        lng_col: str = "lng",
    ) -> Any:
        """Create a scikit-learn transformer that reuses this client session.

        Requires ``scikit-learn`` and ``pandas``::

            pip install prismadata[sklearn]

        Args:
            services: List of service names to aggregate.
            lat_col: Name of the latitude column.
            lng_col: Name of the longitude column.

        Returns:
            A ``PrismaDataTransformer`` bound to this client.

        Example::

            client = Client(api_key="your-key")
            transformer = client.get_transformer(
                services=["slum", "income_static"],
                lat_col="latitude",
                lng_col="longitude",
            )
            enriched = transformer.fit_transform(df)
        """
        from .sklearn import PrismaDataTransformer

        return PrismaDataTransformer(
            services=services,
            lat_col=lat_col,
            lng_col=lng_col,
            clean_columns=self._clean,
            _client=self,
        )

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    def _location_batch(
        self,
        path: str,
        points: dict[str, list[float]],
        *,
        batch_size: int | None = None,
        on_error: Literal["raise", "skip"] = "raise",
        timeout: int | None = None,
    ) -> dict[str, Any]:
        """Shared implementation for location batch endpoints."""
        chunk_size = batch_size if batch_size is not None else MAX_BATCH_SIZE

        def _request(chunk: dict[str, list[float]]) -> dict[str, Any]:
            return self._post(path, chunk, timeout=timeout)

        result = process_batch(points, _request, chunk_size, on_error=on_error)
        if self._clean:
            return {k: clean_columns(v) if isinstance(v, dict) else v for k, v in result.items()}
        return result
