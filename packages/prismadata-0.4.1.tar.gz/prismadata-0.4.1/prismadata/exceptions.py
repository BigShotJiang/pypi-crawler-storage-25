"""Custom exceptions for the PrismaData client."""

from __future__ import annotations

from typing import Any


class PrismaDataError(Exception):
    """Base exception for all PrismaData errors."""

    def __init__(
        self,
        message: str,
        *,
        status_code: int | None = None,
        body: Any = None,
        headers: dict[str, str] | None = None,
    ) -> None:
        super().__init__(message)
        self.status_code = status_code
        self.body = body
        self.headers = headers


class AuthenticationError(PrismaDataError):
    """Raised when authentication fails (401/403)."""


class RateLimitError(PrismaDataError):
    """Raised when the API rate limit is exceeded (429)."""


class QuotaExhaustedError(PrismaDataError):
    """Raised when the API quota is exhausted."""


class ValidationError(PrismaDataError):
    """Raised when the API returns a validation error (422)."""


class BatchPrepareError(PrismaDataError):
    """Raised when batch prepare polling times out or fails."""


class BatchError(PrismaDataError):
    """Raised when a batch operation has partial failures.

    Attributes:
        partial_results: Results that succeeded before the error.
        failed_keys: Keys of the items that failed.
    """

    def __init__(
        self,
        message: str,
        partial_results: dict[str, Any] | None = None,
        failed_keys: list[str] | None = None,
        *,
        status_code: int | None = None,
        body: Any = None,
        headers: dict[str, str] | None = None,
    ) -> None:
        super().__init__(message, status_code=status_code, body=body, headers=headers)
        self.partial_results = partial_results or {}
        self.failed_keys = failed_keys or []
