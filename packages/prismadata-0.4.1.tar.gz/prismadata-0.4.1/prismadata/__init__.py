"""PrismaData - Python client for location intelligence API.

Usage::

    from prismadata import Client

    client = Client(api_key="your-key")
    result = client.geocode(full_address="Av Paulista 1000, Sao Paulo")

Async usage::

    from prismadata import AsyncClient

    async with await AsyncClient.create(api_key="your-key") as client:
        result = await client.geocode(full_address="Av Paulista 1000, Sao Paulo")
"""

from ._types import (
    BorderResult,
    GeocodeResult,
    IncomePdfResult,
    IncomeStaticResult,
    InfoscResult,
    IsochroneResult,
    PersonalIncomePdfParams,
    PrecatoryResult,
    PrisonResult,
    QuotaInfo,
    ReverseGeocodeResult,
    RouteResult,
    RoutingBatchResult,
    SlumResult,
    UserInfo,
)
from .async_client import AsyncClient
from .client import Client
from .exceptions import (
    AuthenticationError,
    BatchError,
    BatchPrepareError,
    PrismaDataError,
    QuotaExhaustedError,
    RateLimitError,
    ValidationError,
)

from importlib.metadata import version as _pkg_version, PackageNotFoundError

try:
    __version__ = _pkg_version("prismadata")
except PackageNotFoundError:
    # Fallback for editable installs or running from source
    from pathlib import Path as _Path
    import re as _re

    _pyproject = _Path(__file__).resolve().parent.parent / "pyproject.toml"
    _match = _re.search(r'^version\s*=\s*"([^"]+)"', _pyproject.read_text(), _re.MULTILINE)
    __version__ = _match.group(1) if _match else "0.0.0"

__all__ = [
    "AsyncClient",
    "Client",
    "__version__",
    "AuthenticationError",
    "BatchError",
    "BatchPrepareError",
    "PrismaDataError",
    "QuotaExhaustedError",
    "RateLimitError",
    "ValidationError",
    "BorderResult",
    "GeocodeResult",
    "IncomePdfResult",
    "IncomeStaticResult",
    "InfoscResult",
    "IsochroneResult",
    "PersonalIncomePdfParams",
    "PrecatoryResult",
    "PrisonResult",
    "QuotaInfo",
    "ReverseGeocodeResult",
    "RouteResult",
    "RoutingBatchResult",
    "SlumResult",
    "UserInfo",
]
