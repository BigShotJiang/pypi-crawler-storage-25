"""TypedDict definitions for API response types.

These provide IDE autocompletion and documentation for common API responses.
All fields use the raw API naming convention (``prismadata__`` prefix).
When ``clean_columns=True``, keys will be cleaned at runtime but these
types still serve as documentation of available fields.

Note: API responses may include additional fields not listed here.
These TypedDicts use ``total=False`` to allow partial matches.
"""

from __future__ import annotations

from typing import Any, TypedDict


class GeocodeResult(TypedDict, total=False):
    """Response from ``geocode()``."""
    prismadata__geocoder__latitude: float
    prismadata__geocoder__longitude: float
    prismadata__geocoder__endereco_completo: str
    prismadata__geocoder__municipio: str
    prismadata__geocoder__estado: str
    prismadata__geocoder__cep: str
    prismadata__geocoder__logradouro: str
    prismadata__geocoder__numero: str
    prismadata__geocoder__localidade: str
    prismadata__geocoder__qualidade: str


class ReverseGeocodeResult(TypedDict, total=False):
    """Response from ``reverse_geocode()``."""
    prismadata__reverse_geocoder__endereco_completo: str
    prismadata__reverse_geocoder__distancia_m: float
    prismadata__reverse_geocoder__municipio: str
    prismadata__reverse_geocoder__estado: str
    prismadata__reverse_geocoder__cep: str


class SlumResult(TypedDict, total=False):
    """Response from ``slum()``."""
    prismadata__favela__nome: str
    prismadata__favela__distancia_m: float
    prismadata__favela__municipio: str
    prismadata__favela__estado: str


class PrisonResult(TypedDict, total=False):
    """Response from ``prison()``."""
    prismadata__presidio__nome: str
    prismadata__presidio__distancia_centroide_m: float
    prismadata__presidio__municipio: str


class BorderResult(TypedDict, total=False):
    """Response from ``border()``."""
    prismadata__fronteira__distancia_m: float
    prismadata__fronteira__pais_vizinho: str
    prismadata__fronteira__nome: str


class InfoscResult(TypedDict, total=False):
    """Response from ``infosc()``."""
    prismadata__infosc__municipio: str
    prismadata__infosc__estado: str
    prismadata__infosc__codigo_setor: str
    prismadata__infosc__tipo_setor: str


class IncomeStaticResult(TypedDict, total=False):
    """Response from ``income_static()``."""
    prismadata__personal_income_static__percentil_br: int
    prismadata__personal_income_static__faixa_sm_min: float
    prismadata__personal_income_static__faixa_sm_max: float
    prismadata__personal_income_static__renda_media: float


class IncomePdfResult(TypedDict, total=False):
    """Response from ``income_pdf()``."""
    prismadata__personal_income_pdf__renda_media_pessoas: float
    prismadata__personal_income_pdf__renda_mediana_pessoas: float
    prismadata__personal_income_pdf__percentil_br: int


class RouteResult(TypedDict, total=False):
    """Response from ``route()``."""
    prismadata__routing_route__distancia_m: float
    prismadata__routing_route__tempo_s: float
    prismadata__routing_route__perfil: str


class IsochroneResult(TypedDict, total=False):
    """Response from ``isochrone()``."""
    prismadata__routing_isochrone__area_m2: float
    prismadata__routing_isochrone__perfil: str
    prismadata__routing_isochrone__tempo_limite_s: int


class PrecatoryResult(TypedDict, total=False):
    """Response from ``precatory()``."""
    prismadata__precatorio_rpv__nome_credor: str
    prismadata__precatorio_rpv__quantidade_creditos_precatorio: int
    prismadata__precatorio_rpv__quantidade_creditos_rpv: int
    prismadata__precatorio_rpv__valor_total_estimado: float


class RoutingBatchResult(TypedDict, total=False):
    """Response from ``route_batch()`` and ``isochrone_batch()``."""
    TOTAL: int
    SUCESSOS: int
    FALHAS: int
    RESULTADOS: list[dict[str, Any]]


class UserInfo(TypedDict, total=False):
    """Response from ``me()``."""
    username: str
    roles: list[str]


class PersonalIncomePdfParams(TypedDict, total=False):
    """Parameters for ``personal_income_pdf_batch_detailed()``."""
    lat: float
    lng: float
    gender: str
    age: int
    date_income: str
    is_responsible: bool
    income_compared: str


class QuotaInfo(TypedDict, total=False):
    """Quota status from ``quota_info`` property."""
    limit: int
    used: int
    remaining: int
    period: str
    reset: int
