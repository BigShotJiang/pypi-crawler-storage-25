"""Optional disk cache wrapper using diskcache."""

from __future__ import annotations

import hashlib
import json
import os
from typing import Any


class CacheManager:
    """Transparent disk cache. Degrades gracefully if diskcache is not installed."""

    def __init__(self, enabled: bool = False, ttl: int = 86400, directory: str | None = None) -> None:
        self._enabled = enabled
        self._ttl = ttl
        self._cache: Any = None

        if not enabled:
            return

        try:
            import diskcache
            cache_dir = directory or os.path.expanduser("~/.prismadata/cache")
            self._cache = diskcache.Cache(cache_dir)
        except ImportError:
            self._enabled = False

    @property
    def enabled(self) -> bool:
        return self._enabled and self._cache is not None

    def get(self, endpoint: str, params: dict[str, Any]) -> Any | None:
        if not self.enabled:
            return None
        key = _make_key(endpoint, params)
        return self._cache.get(key)

    def set(self, endpoint: str, params: dict[str, Any], value: Any) -> None:
        if not self.enabled:
            return
        key = _make_key(endpoint, params)
        self._cache.set(key, value, expire=self._ttl)

    def close(self) -> None:
        if self._cache is not None:
            self._cache.close()


def _make_key(endpoint: str, params: dict[str, Any]) -> str:
    raw = json.dumps({"e": endpoint, "p": params}, sort_keys=True)
    return hashlib.sha256(raw.encode()).hexdigest()
