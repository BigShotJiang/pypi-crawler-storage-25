"""DataFrame enrichment utilities."""

from __future__ import annotations

from typing import Any, Awaitable, Callable, TYPE_CHECKING

from ._columns import clean_columns

if TYPE_CHECKING:
    import pandas as pd


def enrich_dataframe(
    df: pd.DataFrame,
    batch_fn: Any,
    lat_col: str,
    lng_col: str,
    services: list[str],
    do_clean_columns: bool,
    show_progress: bool,
) -> pd.DataFrame:
    """Enrich a DataFrame by calling the aggregator batch endpoint.

    Args:
        df: Input DataFrame with lat/lng columns.
        batch_fn: Callable(points, services, show_progress) -> dict of results.
        lat_col: Name of the latitude column.
        lng_col: Name of the longitude column.
        services: List of service names to aggregate.
        do_clean_columns: Whether to clean column names.
        show_progress: Whether to show a progress bar.

    Returns:
        New DataFrame with enrichment columns appended.
    """
    import pandas as pd

    keys, points = _extract_points(df, lat_col, lng_col)

    results = batch_fn(points, services=services, show_progress=show_progress)

    rows = []
    for key in keys:
        point_data = results.get(key, {})
        if do_clean_columns:
            point_data = clean_columns(point_data)
        rows.append(point_data)

    enriched = pd.DataFrame(rows, index=df.index)
    return pd.concat([df, enriched], axis=1)


def _extract_points(
    df: Any, lat_col: str, lng_col: str,
) -> tuple[list[str], dict[str, list[float]]]:
    """Extract positional {key: [lat, lng]} from a DataFrame.

    Uses sequential integer keys to avoid collisions from duplicate indices.

    Returns:
        Tuple of (ordered key list, points dict).
    """
    keys: list[str] = []
    points: dict[str, list[float]] = {}
    for i, (_, row) in enumerate(df.iterrows()):
        key = str(i)
        keys.append(key)
        points[key] = [float(row[lat_col]), float(row[lng_col])]
    return keys, points


async def async_enrich_dataframe(
    df: pd.DataFrame,
    batch_fn: Any,
    lat_col: str,
    lng_col: str,
    services: list[str],
    do_clean_columns: bool,
    show_progress: bool,
) -> pd.DataFrame:
    """Async version of enrich_dataframe."""
    import pandas as pd

    keys, points = _extract_points(df, lat_col, lng_col)

    results = await batch_fn(points, services=services, show_progress=show_progress)

    rows = []
    for key in keys:
        point_data = results.get(key, {})
        if do_clean_columns:
            point_data = clean_columns(point_data)
        rows.append(point_data)

    enriched = pd.DataFrame(rows, index=df.index)
    return pd.concat([df, enriched], axis=1)
