"""Async HTTP transport layer with retry, throttle, and error handling."""

from __future__ import annotations

import asyncio
import logging
import time
from typing import Any

import httpx
from tenacity import (
    RetryCallState,
    retry,
    retry_if_result,
    stop_after_attempt,
)

from ._async_auth import AsyncAuthManager
from ._constants import (
    DEFAULT_TIMEOUT,
    RETRYABLE_STATUS_CODES,
    RETRY_MAX_ATTEMPTS,
    USER_AGENT_PREFIX,
)
from .exceptions import QuotaExhaustedError
from ._http import _handle_response, _is_retryable, _wait_for_retry

logger = logging.getLogger("prismadata.async_http")


class AsyncHttpClient:
    """Async HTTP client with automatic auth, retry, and throttle."""

    def __init__(
        self,
        auth: AsyncAuthManager,
        timeout: int = DEFAULT_TIMEOUT,
        version: str = "0.1.0",
        app_name: str | None = None,
    ) -> None:
        self._auth = auth
        self._timeout = timeout
        self._last_request_time: float = 0.0
        self._rl_remaining: int | None = None
        self._rl_reset: float | None = None
        self._quota_remaining: int | None = None
        self._quota_reset: float | None = None
        self._quota_limit: int | None = None
        self._quota_used: int | None = None
        self._quota_period: str | None = None
        headers: dict[str, str] = {
            "User-Agent": f"{USER_AGENT_PREFIX}/{version}",
            "X-Client": f"{USER_AGENT_PREFIX}/{version}",
        }
        if app_name:
            headers["X-App"] = app_name
        self._client = httpx.AsyncClient(timeout=timeout, headers=headers)

    async def close(self) -> None:
        await self._client.aclose()

    async def get(self, path: str, params: dict[str, Any] | None = None) -> Any:
        return await self._request("GET", path, params=params)

    async def post(
        self, path: str, json_body: Any = None, params: dict[str, Any] | None = None,
        timeout: int | None = None,
    ) -> Any:
        return await self._request("POST", path, json_body=json_body, params=params, timeout=timeout)

    async def _request(
        self,
        method: str,
        path: str,
        params: dict[str, Any] | None = None,
        json_body: Any = None,
        timeout: int | None = None,
    ) -> Any:
        response = await self._do_request(method, path, params, json_body, timeout=timeout)
        return _handle_response(response)

    @retry(
        retry=retry_if_result(_is_retryable),
        stop=stop_after_attempt(RETRY_MAX_ATTEMPTS),
        wait=_wait_for_retry,
        retry_error_callback=lambda state: state.outcome.result(),
    )
    async def _do_request(
        self,
        method: str,
        path: str,
        params: dict[str, Any] | None = None,
        json_body: Any = None,
        timeout: int | None = None,
    ) -> httpx.Response:
        await self._throttle()

        if self._auth._api_key:
            await self._auth._try_refresh_claims()
        else:
            await self._auth.ensure_valid_token()
        headers = self._auth.get_headers()

        url = f"{self._auth._base_url}{path}"

        if params:
            params = {k: v for k, v in params.items() if v is not None}

        request_kwargs: dict[str, Any] = {}
        if timeout is not None:
            request_kwargs["timeout"] = timeout

        logger.debug("%s %s", method, path)
        t0 = time.monotonic()
        response = await self._client.request(
            method, url, params=params, json=json_body, headers=headers, **request_kwargs
        )
        elapsed = time.monotonic() - t0
        self._update_rate_limit(response)
        status = response.status_code
        if status in RETRYABLE_STATUS_CODES:
            logger.warning("Retryable %d on %s %s, will retry", status, method, path)
        else:
            logger.debug("%s %s -> %d (%.1fs)", method, path, status, elapsed)
        return response

    def _update_rate_limit(self, response: httpx.Response) -> None:
        remaining = response.headers.get("x-ratelimit-remaining")
        reset = response.headers.get("x-ratelimit-reset")
        if remaining is not None:
            self._rl_remaining = int(remaining)
        if reset is not None:
            self._rl_reset = float(reset)
        q_remaining = response.headers.get("x-quota-remaining")
        if q_remaining is not None:
            self._quota_remaining = int(q_remaining)
            q_limit = response.headers.get("x-quota-limit")
            q_used = response.headers.get("x-quota-used")
            q_period = response.headers.get("x-quota-period")
            q_reset = response.headers.get("x-quota-reset")
            if q_limit is not None:
                self._quota_limit = int(q_limit)
            if q_used is not None:
                self._quota_used = int(q_used)
            if q_period is not None:
                self._quota_period = q_period
            if q_reset is not None:
                self._quota_reset = float(q_reset)

    async def _throttle(self) -> None:
        if self._quota_remaining is not None and self._quota_remaining <= 0:
            msg = "Quota exhausted: 0 requests remaining"
            if self._quota_reset:
                msg += f" (resets at {int(self._quota_reset)})"
            raise QuotaExhaustedError(msg)

        if self._rl_remaining is not None and self._rl_remaining <= 0:
            if self._rl_reset:
                wait = self._rl_reset - time.time()
                if wait > 0:
                    logger.debug("Rate limit: sleeping %.2fs (headers)", wait)
                    await asyncio.sleep(wait)
            self._rl_remaining = None
            self._rl_reset = None
            return

        if self._rl_remaining is not None:
            return

        rate_limit = self._auth.rate_limit
        if not rate_limit or rate_limit <= 0:
            return
        min_interval = 1.0 / rate_limit
        elapsed = time.time() - self._last_request_time
        if elapsed < min_interval:
            wait = min_interval - elapsed
            logger.debug("Rate limit: sleeping %.2fs (jwt claim)", wait)
            await asyncio.sleep(wait)
        self._last_request_time = time.time()
