"""Async PrismaData API client with flat method interface."""

from __future__ import annotations

import warnings
from typing import Any, Literal, TYPE_CHECKING

from ._async_auth import AsyncAuthManager
from ._async_http import AsyncHttpClient
from ._types import QuotaInfo
from ._batch import async_process_batch, async_process_routing_batch, split_into_groups
from ._cache import CacheManager
from ._columns import clean_columns
from ._constants import (
    BASE_URL,
    DEFAULT_CACHE_TTL,
    DEFAULT_CHUNK_THRESHOLD,
    DEFAULT_MAX_WORKERS,
    DEFAULT_TIMEOUT,
    DIRECTION_MAP,
    MAX_BATCH_SIZE,
    MAX_ROUTING_BATCH,
)
from ._prepare import async_batch_complete, async_batch_prepare, async_wait_until_ready
from ._progress import progress_bar
from ._validation import validate_lat_lng, validate_profile, validate_route_points
from .client import _resolve_credentials

if TYPE_CHECKING:
    import pandas as pd

    from ._types import (
        BorderResult,
        GeocodeResult,
        IncomePdfResult,
        IncomeStaticResult,
        InfoscResult,
        IsochroneResult,
        PrecatoryResult,
        PrisonResult,
        ReverseGeocodeResult,
        RouteResult,
        RoutingBatchResult,
        SlumResult,
        UserInfo,
    )


class AsyncClient:
    """Async PrismaData API client.

    Must be created via the ``create`` classmethod::

        client = await AsyncClient.create(api_key="your-key")
        result = await client.slum(-23.56, -46.65)
        await client.close()

    Or as an async context manager::

        async with await AsyncClient.create(api_key="your-key") as client:
            result = await client.slum(-23.56, -46.65)
    """

    def __init__(
        self,
        auth: AsyncAuthManager,
        http: AsyncHttpClient,
        cache: CacheManager,
        clean: bool,
        show_progress: bool,
    ) -> None:
        self._auth = auth
        self._http = http
        self._cache = cache
        self._clean = clean
        self._show_progress = show_progress

    @classmethod
    async def create(
        cls,
        api_key: str | None = None,
        *,
        username: str | None = None,
        password: str | None = None,
        base_url: str = BASE_URL,
        timeout: int = DEFAULT_TIMEOUT,
        cache: bool = False,
        cache_ttl: int = DEFAULT_CACHE_TTL,
        clean_columns: bool = False,
        show_progress: bool = True,
        app_name: str | None = None,
    ) -> AsyncClient:
        """Create and authenticate an AsyncClient.

        Args:
            api_key: Your PrismaData API key.
            username: Username for login.
            password: Password for login.
            base_url: API base URL.
            timeout: Request timeout in seconds.
            cache: Enable local disk cache.
            cache_ttl: Cache time-to-live in seconds.
            clean_columns: Strip the ``prismadata__`` prefix from response keys.
            show_progress: Show progress bars for batch operations.
            app_name: Application name sent in ``X-App`` header.
        """
        credentials = _resolve_credentials(api_key, username, password)
        auth = AsyncAuthManager(base_url, timeout, **credentials)
        await auth.authenticate()
        if auth.is_sandbox:
            warnings.warn(
                "This token is configured for sandbox mode. "
                "API responses will contain synthetic data.",
                UserWarning,
                stacklevel=2,
            )
        from . import __version__

        http = AsyncHttpClient(auth, timeout=timeout, version=__version__, app_name=app_name)
        auth.set_http_client(http._client)
        cache_mgr = CacheManager(enabled=cache, ttl=cache_ttl)
        return cls(auth, http, cache_mgr, clean_columns, show_progress)

    async def close(self) -> None:
        """Close underlying HTTP and cache connections."""
        await self._http.close()
        self._cache.close()

    async def __aenter__(self) -> AsyncClient:
        return self

    async def __aexit__(self, *exc: object) -> None:
        await self.close()

    @property
    def quota_info(self) -> QuotaInfo | None:
        """Last observed quota status, or ``None`` if no quota headers received."""
        if self._http._quota_remaining is None:
            return None
        info: QuotaInfo = {"remaining": self._http._quota_remaining}
        if self._http._quota_limit is not None:
            info["limit"] = self._http._quota_limit
        if self._http._quota_used is not None:
            info["used"] = self._http._quota_used
        if self._http._quota_period is not None:
            info["period"] = self._http._quota_period
        if self._http._quota_reset is not None:
            info["reset"] = int(self._http._quota_reset)
        return info

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    async def _get(self, path: str, params: dict[str, Any] | None = None) -> Any:
        if params and self._cache.enabled:
            cached = self._cache.get(path, params)
            if cached is not None:
                return cached

        result = await self._http.get(path, params)

        if params and self._cache.enabled:
            self._cache.set(path, params, result)

        return result

    async def _post(
        self, path: str, body: Any = None, params: dict[str, Any] | None = None,
        timeout: int | None = None,
    ) -> Any:
        return await self._http.post(path, json_body=body, params=params, timeout=timeout)

    def _maybe_clean(self, data: dict[str, Any]) -> dict[str, Any]:
        return clean_columns(data) if self._clean else data

    # ------------------------------------------------------------------
    # Auth
    # ------------------------------------------------------------------

    async def me(self) -> UserInfo:
        """Return authenticated user information."""
        return await self._get("/auth/me")

    # ------------------------------------------------------------------
    # Geocoding
    # ------------------------------------------------------------------

    async def geocode(
        self,
        full_address: str | None = None,
        *,
        zipcode: str | None = None,
        number: str | int | None = None,
        street: str | None = None,
        city: str | None = None,
        state: str | None = None,
        neighborhood: str | None = None,
        street_type: str | None = None,
        street_title: str | None = None,
    ) -> GeocodeResult:
        """Geocode an address to coordinates."""
        params = {
            "endereco_completo": full_address,
            "cep": zipcode,
            "numero": number,
            "logradouro": street,
            "municipio": city,
            "estado": state,
            "localidade": neighborhood,
            "tipo_logradouro": street_type,
            "titulo_logradouro": street_title,
        }
        return self._maybe_clean(await self._get("/location/geocoder", params))

    async def reverse_geocode(self, lat: float, lng: float) -> ReverseGeocodeResult:
        """Reverse geocode coordinates to the nearest address."""
        validate_lat_lng(lat, lng)
        return self._maybe_clean(await self._get("/location/reverse_geocoder", {"lat": lat, "lng": lng}))

    # ------------------------------------------------------------------
    # Location services
    # ------------------------------------------------------------------

    async def slum(self, lat: float, lng: float) -> SlumResult:
        """Query nearest slum/favela proximity data."""
        validate_lat_lng(lat, lng)
        return self._maybe_clean(await self._get("/location/slum", {"lat": lat, "lng": lng}))

    async def prison(self, lat: float, lng: float) -> PrisonResult:
        """Query nearest prison proximity data."""
        validate_lat_lng(lat, lng)
        return self._maybe_clean(await self._get("/location/prison", {"lat": lat, "lng": lng}))

    async def border(self, lat: float, lng: float) -> BorderResult:
        """Query proximity to Brazilian borders."""
        validate_lat_lng(lat, lng)
        return self._maybe_clean(await self._get("/location/border", {"lat": lat, "lng": lng}))

    async def infosc(self, lat: float, lng: float) -> InfoscResult:
        """Query census sector information."""
        validate_lat_lng(lat, lng)
        return self._maybe_clean(await self._get("/location/infosc", {"lat": lat, "lng": lng}))

    async def income_static(self, lat: float, lng: float) -> IncomeStaticResult:
        """Query static income estimates."""
        validate_lat_lng(lat, lng)
        return self._maybe_clean(
            await self._get("/location/personal_income_static", {"lat": lat, "lng": lng})
        )

    async def income_pdf(
        self,
        lat: float,
        lng: float,
        *,
        date: str | None = None,
        gender: str | None = None,
        age: float | None = None,
        is_responsible: str | None = None,
        income_compared: float | None = None,
    ) -> IncomePdfResult:
        """Query dynamic income estimates with detailed statistics."""
        validate_lat_lng(lat, lng)
        params = {
            "lat": lat,
            "lng": lng,
            "date_income": date,
            "gender": gender,
            "age": age,
            "is_responsible": is_responsible,
            "income_compared": income_compared,
        }
        return self._maybe_clean(await self._get("/location/personal_income_pdf", params))

    # ------------------------------------------------------------------
    # Routing
    # ------------------------------------------------------------------

    async def route(
        self,
        points: list[tuple[float, float]],
        *,
        profile: str = "car",
    ) -> RouteResult:
        """Calculate a route between two or more points."""
        validate_route_points(points)
        validate_profile(profile)
        formatted = [f"{lat},{lng}" for lat, lng in points]
        return self._maybe_clean(
            await self._get("/routing/route", {"points": formatted, "profile": profile})
        )

    async def isochrone(
        self,
        lat: float,
        lng: float,
        *,
        time_limit: int = 600,
        profile: str = "car",
        direction: str = "outgoing",
    ) -> IsochroneResult:
        """Calculate an isochrone (reachable area within a time limit)."""
        validate_lat_lng(lat, lng)
        validate_profile(profile)
        params = {
            "lat": lat,
            "lng": lng,
            "time_limit": time_limit,
            "profile": profile,
            "sentido": DIRECTION_MAP.get(direction, direction),
        }
        return self._maybe_clean(await self._get("/routing/isochrone", params))

    # ------------------------------------------------------------------
    # Address validation
    # ------------------------------------------------------------------

    async def compare_address(
        self,
        lat: float,
        lng: float,
        *,
        full_address: str | None = None,
        zipcode: str | None = None,
        number: str | int | None = None,
        street: str | None = None,
        city: str | None = None,
        state: str | None = None,
        neighborhood: str | None = None,
    ) -> dict[str, Any]:
        """Compare an address with coordinates to evaluate concordance."""
        validate_lat_lng(lat, lng)
        params = {
            "lat": lat,
            "lng": lng,
            "endereco_completo": full_address,
            "cep": zipcode,
            "numero": number,
            "logradouro": street,
            "municipio": city,
            "estado": state,
            "localidade": neighborhood,
        }
        return self._maybe_clean(await self._get("/location/compare_address", params))

    async def validate_address(
        self,
        locations: list[list[float]],
        addresses: list[str],
    ) -> list[dict[str, Any]]:
        """Validate addresses against a location history."""
        body = {"locations": locations, "enderecos": addresses}
        result = await self._post("/location/validate_addr", body)
        items = result.get("items", result) if isinstance(result, dict) else result
        if self._clean and isinstance(items, list):
            return [clean_columns(item) for item in items]
        return items

    async def cluster_locations(
        self,
        locations: list[list[float]],
    ) -> list[dict[str, Any]]:
        """Cluster location history to identify frequent/prolonged locations."""
        result = await self._post("/location/cluster_location_historic", locations)
        items = result.get("items", result) if isinstance(result, dict) else result
        if self._clean and isinstance(items, list):
            return [clean_columns(item) for item in items]
        return items

    # ------------------------------------------------------------------
    # Credit (precatory / RPV)
    # ------------------------------------------------------------------

    async def precatory(
        self,
        *,
        cpf_cnpj: str | None = None,
        name: str | None = None,
    ) -> PrecatoryResult:
        """Query consolidated credit summary (precatorios and RPVs)."""
        params = {"id_credor": cpf_cnpj, "nome_credor": name}
        return self._maybe_clean(
            await self._get("/credit/precatorio_rpv/consulta_credito", params)
        )

    async def precatory_detail(
        self,
        *,
        cpf_cnpj: str | None = None,
        name: str | None = None,
    ) -> list[dict[str, Any]]:
        """Query detailed list of precatorios/RPVs for a creditor."""
        params = {"id_credor": cpf_cnpj, "nome_credor": name}
        result = await self._get("/credit/precatorio_rpv/detalha_credito", params)
        items = result.get("items", result) if isinstance(result, dict) else result
        if self._clean and isinstance(items, list):
            return [clean_columns(item) for item in items]
        return items

    # ------------------------------------------------------------------
    # Batch operations
    # ------------------------------------------------------------------

    async def slum_batch(
        self, points: dict[str, list[float]], *,
        batch_size: int | None = None,
        on_error: Literal["raise", "skip"] = "raise",
        timeout: int | None = None,
    ) -> dict[str, Any]:
        """Batch query slum/favela data for multiple points."""
        return await self._location_batch(
            "/location/batch/slum", points,
            batch_size=batch_size, on_error=on_error, timeout=timeout,
        )

    async def prison_batch(
        self, points: dict[str, list[float]], *,
        batch_size: int | None = None,
        on_error: Literal["raise", "skip"] = "raise",
        timeout: int | None = None,
    ) -> dict[str, Any]:
        """Batch query prison data for multiple points."""
        return await self._location_batch(
            "/location/batch/prison", points,
            batch_size=batch_size, on_error=on_error, timeout=timeout,
        )

    async def border_batch(
        self, points: dict[str, list[float]], *,
        batch_size: int | None = None,
        on_error: Literal["raise", "skip"] = "raise",
        timeout: int | None = None,
    ) -> dict[str, Any]:
        """Batch query border data for multiple points."""
        return await self._location_batch(
            "/location/batch/border", points,
            batch_size=batch_size, on_error=on_error, timeout=timeout,
        )

    async def infosc_batch(
        self, points: dict[str, list[float]], *,
        batch_size: int | None = None,
        on_error: Literal["raise", "skip"] = "raise",
        timeout: int | None = None,
    ) -> dict[str, Any]:
        """Batch query census sector data for multiple points."""
        return await self._location_batch(
            "/location/batch/infosc", points,
            batch_size=batch_size, on_error=on_error, timeout=timeout,
        )

    async def personal_income_static_batch(
        self, points: dict[str, list[float]], *,
        batch_size: int | None = None,
        on_error: Literal["raise", "skip"] = "raise",
        timeout: int | None = None,
    ) -> dict[str, Any]:
        """Batch query static personal income data for multiple points."""
        return await self._location_batch(
            "/location/batch/personal_income_static", points,
            batch_size=batch_size, on_error=on_error, timeout=timeout,
        )

    async def personal_income_pdf_batch(
        self, points: dict[str, list[float]], *,
        batch_size: int | None = None,
        on_error: Literal["raise", "skip"] = "raise",
        timeout: int | None = None,
    ) -> dict[str, Any]:
        """Batch query personal income PDF (probability distribution) for multiple points."""
        return await self._location_batch(
            "/location/batch/personal_income_pdf", points,
            batch_size=batch_size, on_error=on_error, timeout=timeout,
        )

    async def personal_income_pdf_batch_detailed(
        self, points: dict[str, dict], *,
        batch_size: int | None = None,
        on_error: Literal["raise", "skip"] = "raise",
        timeout: int | None = None,
    ) -> dict[str, Any]:
        """Batch query personal income PDF with demographic parameters per point."""
        chunk_size = batch_size if batch_size is not None else MAX_BATCH_SIZE

        async def _request(chunk: dict[str, dict]) -> dict[str, Any]:
            return await self._post("/location/batch/personal_income_pdf", chunk, timeout=timeout)

        result = await async_process_batch(points, _request, chunk_size, on_error=on_error)
        if self._clean:
            return {k: clean_columns(v) if isinstance(v, dict) else v for k, v in result.items()}
        return result

    async def route_batch(
        self,
        items: list[dict[str, Any]],
        *,
        profile: str = "car",
        on_error: Literal["raise", "skip"] = "raise",
        timeout: int | None = None,
    ) -> RoutingBatchResult:
        """Batch calculate routes."""
        validate_profile(profile)

        async def _request(chunk: list[dict[str, Any]]) -> dict[str, Any]:
            return await self._post("/routing/batch/route", {"items": chunk, "profile": profile}, timeout=timeout)

        return await async_process_routing_batch(items, _request, MAX_ROUTING_BATCH, on_error=on_error)

    async def isochrone_batch(
        self,
        items: list[dict[str, Any]],
        *,
        profile: str = "car",
        direction: str = "outgoing",
        on_error: Literal["raise", "skip"] = "raise",
        timeout: int | None = None,
    ) -> RoutingBatchResult:
        """Batch calculate isochrones."""
        validate_profile(profile)
        sentido = DIRECTION_MAP.get(direction, direction)

        async def _request(chunk: list[dict[str, Any]]) -> dict[str, Any]:
            return await self._post(
                "/routing/batch/isochrone",
                {"items": chunk, "profile": profile, "sentido": sentido},
                timeout=timeout,
            )

        return await async_process_routing_batch(items, _request, MAX_ROUTING_BATCH, on_error=on_error)

    # ------------------------------------------------------------------
    # Aggregator
    # ------------------------------------------------------------------

    async def aggregate(
        self,
        lat: float,
        lng: float,
        *,
        services: list[str],
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Aggregate multiple location APIs in a single call."""
        validate_lat_lng(lat, lng)
        params: dict[str, Any] = {"lat": lat, "lng": lng}
        for svc in services:
            params[svc] = True
        params.update(kwargs)
        return self._maybe_clean(await self._get("/location/aggregator", params))

    async def aggregate_batch(
        self,
        points: dict[str, list[float]],
        *,
        services: list[str],
        batch_size: int | None = None,
        on_error: Literal["raise", "skip"] = "raise",
        timeout: int | None = None,
        show_progress: bool | None = None,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Batch aggregate multiple location APIs for multiple points."""
        params: dict[str, Any] = {}
        for svc in services:
            params[svc] = True
        params.update(kwargs)

        chunk_size = batch_size if batch_size is not None else MAX_BATCH_SIZE
        use_progress = show_progress if show_progress is not None else self._show_progress

        async def _request(chunk: dict[str, list[float]]) -> dict[str, Any]:
            return await self._post("/location/batch/aggregator", chunk, params=params, timeout=timeout)

        with progress_bar(len(points), desc="Aggregating", enabled=use_progress) as bar:

            def _on_progress(n: int) -> None:
                bar.update(n)

            result = await async_process_batch(points, _request, chunk_size, on_progress=_on_progress, on_error=on_error)

        if self._clean:
            return {k: clean_columns(v) if isinstance(v, dict) else v for k, v in result.items()}
        return result

    # ------------------------------------------------------------------
    # Geocoder + Aggregator
    # ------------------------------------------------------------------

    async def geocode_aggregate(
        self,
        *,
        services: list[str],
        full_address: str | None = None,
        zipcode: str | None = None,
        number: str | int | None = None,
        street: str | None = None,
        city: str | None = None,
        state: str | None = None,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Geocode an address and aggregate location APIs in a single call."""
        params: dict[str, Any] = {
            "endereco_completo": full_address,
            "cep": zipcode,
            "numero": number,
            "logradouro": street,
            "municipio": city,
            "estado": state,
        }
        for svc in services:
            params[svc] = True
        params.update(kwargs)
        return self._maybe_clean(await self._get("/location/geocoder/aggregator", params))

    # ------------------------------------------------------------------
    # Batch geocoding
    # ------------------------------------------------------------------

    async def geocode_batch(
        self,
        addresses: dict[str, dict[str, str]],
        *,
        batch_size: int | None = None,
        on_error: Literal["raise", "skip"] = "raise",
        timeout: int | None = None,
    ) -> dict[str, Any]:
        """Batch geocode multiple addresses."""
        chunk_size = batch_size if batch_size is not None else 512

        async def _request(chunk: dict) -> dict[str, Any]:
            return await self._post("/location/batch/geocoder", chunk, timeout=timeout)

        result = await async_process_batch(addresses, _request, chunk_size, on_error=on_error)
        if self._clean:
            return {k: clean_columns(v) if isinstance(v, dict) else v for k, v in result.items()}
        return result

    async def reverse_geocode_batch(
        self,
        points: dict[str, list[float]],
        *,
        batch_size: int | None = None,
        on_error: Literal["raise", "skip"] = "raise",
        timeout: int | None = None,
    ) -> dict[str, Any]:
        """Batch reverse geocode multiple coordinates."""
        formatted = {k: {"lat": v[0], "lng": v[1]} for k, v in points.items()}
        return await self._location_batch(
            "/location/batch/reverse_geocoder", formatted,
            batch_size=batch_size, on_error=on_error, timeout=timeout,
        )

    async def geocode_aggregate_batch(
        self,
        addresses: dict[str, dict[str, str]],
        *,
        services: list[str],
        batch_size: int | None = None,
        on_error: Literal["raise", "skip"] = "raise",
        timeout: int | None = None,
        show_progress: bool | None = None,
        auto_scale: bool = True,
        max_workers: int = DEFAULT_MAX_WORKERS,
        chunk_threshold: int = DEFAULT_CHUNK_THRESHOLD,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Batch geocode addresses and aggregate location APIs.

        For large batches (above ``chunk_threshold``), the SDK signals the API
        to scale up infrastructure, splits the work across parallel workers,
        and signals scale-down when finished.
        """
        params: dict[str, Any] = {}
        for svc in services:
            params[svc] = True
        params.update(kwargs)

        chunk_size = batch_size if batch_size is not None else MAX_BATCH_SIZE
        use_progress = show_progress if show_progress is not None else self._show_progress
        total = len(addresses)
        should_scale = auto_scale and total >= chunk_threshold

        async def _request(chunk: dict) -> dict[str, Any]:
            return await self._post("/location/batch/geocoder/aggregator", chunk, params=params, timeout=timeout)

        if not should_scale:
            with progress_bar(total, desc="Geocode+Aggregating", enabled=use_progress) as bar:

                def _on_progress(n: int) -> None:
                    bar.update(n)

                result = await async_process_batch(addresses, _request, chunk_size, on_progress=_on_progress, on_error=on_error)
        else:
            import asyncio

            resp = await async_batch_prepare(self._post, total)
            session_id = resp["session_id"]
            num_workers = min(max_workers, resp.get("max_workers", max_workers))

            try:
                await async_wait_until_ready(self._get, session_id)
                groups = split_into_groups(addresses, num_workers)

                async def _process_group(group: dict) -> dict[str, Any]:
                    return await async_process_batch(group, _request, chunk_size, on_error=on_error)

                group_results = await asyncio.gather(
                    *[_process_group(g) for g in groups],
                    return_exceptions=(on_error == "skip"),
                )
                result = {}
                for gr in group_results:
                    if isinstance(gr, Exception):
                        continue
                    result.update(gr)
            finally:
                await async_batch_complete(self._post, session_id)

        if self._clean:
            return {k: clean_columns(v) if isinstance(v, dict) else v for k, v in result.items()}
        return result

    # ------------------------------------------------------------------
    # Enrich (DataFrame)
    # ------------------------------------------------------------------

    async def enrich(
        self,
        df: pd.DataFrame,
        *,
        lat_col: str = "lat",
        lng_col: str = "lng",
        services: list[str],
        show_progress: bool | None = None,
    ) -> pd.DataFrame:
        """Enrich a pandas DataFrame with PrismaData location intelligence."""
        from ._enrich import async_enrich_dataframe

        use_progress = show_progress if show_progress is not None else self._show_progress

        async def _batch_fn(
            points: dict[str, list[float]],
            services: list[str],
            show_progress: bool,
        ) -> dict[str, Any]:
            return await self.aggregate_batch(
                points, services=services, show_progress=show_progress
            )

        return await async_enrich_dataframe(
            df,
            batch_fn=_batch_fn,
            lat_col=lat_col,
            lng_col=lng_col,
            services=services,
            do_clean_columns=self._clean,
            show_progress=use_progress,
        )

    # ------------------------------------------------------------------
    # Sklearn integration
    # ------------------------------------------------------------------

    def get_transformer(
        self,
        *,
        services: list[str],
        lat_col: str = "lat",
        lng_col: str = "lng",
    ) -> Any:
        """Create a scikit-learn transformer that uses a sync Client internally.

        Sklearn transformers must be synchronous, so this creates a new
        sync ``Client`` with the same credentials. The transformer manages
        its own client lifecycle.

        Args:
            services: List of service names to aggregate.
            lat_col: Name of the latitude column.
            lng_col: Name of the longitude column.

        Returns:
            A ``PrismaDataTransformer`` instance.
        """
        from .sklearn import PrismaDataTransformer

        creds: dict[str, Any] = {}
        if self._auth._api_key:
            creds["api_key"] = self._auth._api_key
        else:
            creds["username"] = self._auth._username
            creds["password"] = self._auth._password

        return PrismaDataTransformer(
            services=services,
            lat_col=lat_col,
            lng_col=lng_col,
            clean_columns=self._clean,
            cache=self._cache.enabled,
            **creds,
        )

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    async def _location_batch(
        self,
        path: str,
        points: dict[str, list[float]],
        *,
        batch_size: int | None = None,
        on_error: Literal["raise", "skip"] = "raise",
        timeout: int | None = None,
    ) -> dict[str, Any]:
        """Shared implementation for location batch endpoints."""
        chunk_size = batch_size if batch_size is not None else MAX_BATCH_SIZE

        async def _request(chunk: dict[str, list[float]]) -> dict[str, Any]:
            return await self._post(path, chunk, timeout=timeout)

        result = await async_process_batch(points, _request, chunk_size, on_error=on_error)
        if self._clean:
            return {k: clean_columns(v) if isinstance(v, dict) else v for k, v in result.items()}
        return result
