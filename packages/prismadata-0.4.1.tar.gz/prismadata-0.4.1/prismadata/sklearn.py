"""Scikit-learn compatible transformer for PrismaData enrichment.

Requires ``scikit-learn`` and ``pandas``::

    pip install prismadata[sklearn]

Example::

    from sklearn.pipeline import Pipeline
    from prismadata.sklearn import PrismaDataTransformer

    pipe = Pipeline([
        ("enrich", PrismaDataTransformer(
            api_key="your-key",
            services=["slum", "income_static"],
        )),
        ("model", YourModel()),
    ])
"""

from __future__ import annotations

from typing import Any

from sklearn.base import BaseEstimator, TransformerMixin

from .client import Client


class PrismaDataTransformer(BaseEstimator, TransformerMixin):
    """Sklearn transformer that enriches DataFrames via the PrismaData API.

    This transformer adds new feature columns from the API but does NOT
    perform encoding, scaling, or other transformations. Compose it with
    other sklearn transformers as needed.

    Can be created standalone (pass credentials) or via
    ``Client.get_transformer()`` to reuse an existing session.

    Args:
        api_key: PrismaData API key.
        username: Username for login (alternative to api_key).
        password: Password for login (used with username).
        services: List of service names to aggregate.
        lat_col: Name of the latitude column.
        lng_col: Name of the longitude column.
        cache: Enable disk cache.
        clean_columns: Strip the ``prismadata__`` prefix from column names.
        app_name: Application name sent in ``X-App`` header.
        _client: Pre-configured Client instance (internal, set by
            ``Client.get_transformer()``). When provided, credential
            and config args are ignored and the client is not closed
            by this transformer.
    """

    def __init__(
        self,
        api_key: str | None = None,
        services: list[str] | None = None,
        lat_col: str = "lat",
        lng_col: str = "lng",
        cache: bool = True,
        clean_columns: bool = False,
        username: str | None = None,
        password: str | None = None,
        app_name: str | None = None,
        _client: Client | None = None,
    ) -> None:
        self.api_key = api_key
        self.services = services or []
        self.lat_col = lat_col
        self.lng_col = lng_col
        self.cache = cache
        self.clean_columns = clean_columns
        self.username = username
        self.password = password
        self.app_name = app_name
        self._client = _client

    def fit(self, X: Any, y: Any = None) -> PrismaDataTransformer:
        """Discover output feature names by enriching the first row.

        Args:
            X: DataFrame with lat/lng columns.
            y: Ignored.
        """
        import pandas as pd

        sample = X.head(1) if hasattr(X, "head") else pd.DataFrame(X).head(1)
        client, owned = self._resolve_client()
        try:
            enriched = client.enrich(
                sample,
                lat_col=self.lat_col,
                lng_col=self.lng_col,
                services=self.services,
                show_progress=False,
            )
            original_cols = set(sample.columns)
            self.feature_names_out_ = [
                c for c in enriched.columns if c not in original_cols
            ]
        finally:
            if owned:
                client.close()
        return self

    def transform(self, X: Any) -> Any:
        """Enrich the DataFrame with PrismaData features.

        Args:
            X: DataFrame with lat/lng columns.

        Returns:
            Enriched DataFrame.
        """
        client, owned = self._resolve_client()
        try:
            return client.enrich(
                X,
                lat_col=self.lat_col,
                lng_col=self.lng_col,
                services=self.services,
                show_progress=False,
            )
        finally:
            if owned:
                client.close()

    def get_feature_names_out(self, input_features: Any = None) -> list[str]:
        """Return the names of output features added by this transformer."""
        return self.feature_names_out_

    def _resolve_client(self) -> tuple[Client, bool]:
        """Return (client, owned) — owned is True when we created it."""
        if self._client is not None:
            return self._client, False
        return Client(
            api_key=self.api_key,
            username=self.username,
            password=self.password,
            cache=self.cache,
            clean_columns=self.clean_columns,
            show_progress=False,
            app_name=self.app_name,
        ), True
