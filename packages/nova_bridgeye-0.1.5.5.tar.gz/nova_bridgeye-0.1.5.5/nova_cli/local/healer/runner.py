# nova_cli/local/healer/runner.py

import os
import time
import subprocess
from typing import Dict, List, Optional
import py_compile
import tempfile


from nova_cli.nova_core.ai.api_client import BridgeyeAPIClient
from nova_cli.local.file_manager.commands import handle_ai_commands
from nova_cli.local.ui import ui
import core.prompts as prompts


def _syntax_check(path: str) -> tuple[bool, str]:
    try:
        py_compile.compile(path, doraise=True)
        return True, ""
    except Exception as e:
        return False, str(e)


def _read_text(path: str) -> str:
    with open(path, "r", encoding="utf-8") as f:
        return f.read()


def _write_text(path: str, content: str) -> None:
    with open(path, "w", encoding="utf-8") as f:
        f.write(content)


def _strip_utf8_bom(path: str) -> bool:
    try:
        with open(path, "rb") as f:
            raw = f.read()
        if raw.startswith(b"\xef\xbb\xbf"):
            with open(path, "wb") as f:
                f.write(raw[3:])
            return True
    except Exception:
        return False
    return False


def _ensure_target_file_in_context(command_args: List[str], cwd: str, ctx: Dict[str, str]) -> None:
    """
    Ensure the executed target file is present in context with canonical keys.
    """
    if not command_args:
        return

    target = command_args[-1]
    if not (isinstance(target, str) and "." in target):
        return
    
    raw_abs = os.path.abspath(os.path.join(cwd, target))
    if not os.path.exists(raw_abs) or os.path.isdir(raw_abs):
        return

    # Canonical Windows Path: D:/path/to/file.ext
    drive, rest = os.path.splitdrive(raw_abs)
    abs_path = (drive.upper() + rest).replace("\\", "/")

    try:
        with open(raw_abs, "r", encoding="utf-8", errors="replace") as f:
            content = f.read().replace("\r\n", "\n").replace("\r", "\n").lstrip("\ufeff")
    except Exception:
        return

    # Map only canonical Absolute and Relative paths
    ctx[abs_path] = content
    try:
        rel = os.path.relpath(raw_abs, cwd).replace("\\", "/")
        ctx[rel] = content
    except Exception:
        pass


def _run_once(command_args: List[str], cwd: str) -> tuple[int, str, str]:
    """Runs the process and streams output to terminal in real-time."""
    stdout_lines = []
    stderr_lines = []
    
    # Use shell=True on Windows for command wrappers (.cmd/.bat)
    # Use a string command on Windows when shell=True for better resolution
    use_shell = os.name == "nt"
    cmd = " ".join(f'"{a}"' if " " in a else a for a in command_args) if use_shell else command_args
    
    try:
        process = subprocess.Popen(
            cmd,
            cwd=cwd,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            stdin=subprocess.DEVNULL,
            text=True,
            encoding="utf-8",
            errors="replace",
            bufsize=1,
            universal_newlines=True,
            shell=use_shell
        )
    except FileNotFoundError:
        return 127, "", f"Nova Error: The runner executable '{command_args[0]}' could not be found in the system PATH."

    import threading
    def stream_reader(pipe, container):
        for line in iter(pipe.readline, ''):
            if line:
                container.append(line)
                # Raw print removed here to allow Rich UI to handle the display once.
        pipe.close()

    t1 = threading.Thread(target=stream_reader, args=(process.stdout, stdout_lines))
    t2 = threading.Thread(target=stream_reader, args=(process.stderr, stderr_lines))
    
    t1.start()
    t2.start()
    
    exit_code = process.wait()
    t1.join()
    t2.join()

    return exit_code, "".join(stdout_lines), "".join(stderr_lines)


def run_with_healing(
    *,
    command_args: List[str],
    cwd: str,
    model: str,
    provider: str,
    context: Optional[Dict[str, str]] = None,
    extra_context: Optional[Dict[str, str]] = None,
    repo_map: Optional[str] = None,
    max_attempts: int = 3,
) -> str:
    """
    Runs the command locally.
    On failure: calls NOVA_API /healer/run to get a patch block ([EDIT]/[SHELL]).
    Applies the patch locally via handle_ai_commands(), then retries.
    Returns "SUCCESS_SIGNAL" on success.
    Raises on final failure.
    """

    from nova_cli.local.contextifier import run_contextify

    merged_context: Dict[str, str] = {}
    if context:
        merged_context.update(context)
    if extra_context:
        merged_context.update(extra_context)
        
    try:
        from nova_cli.local.contextifier import run_contextify
        project_ctx = run_contextify(cwd, save_to_disk=False)
        merged_context.update(project_ctx)
    except Exception:
        pass

    if repo_map is None:
        try:
            repo_map = prompts.get_repo_map_cached(cwd)
        except Exception:
            repo_map = None

    api = BridgeyeAPIClient()
    last_err = ""

    # Best-effort: infer target file path
    target_abs: Optional[str] = None
    if command_args and isinstance(command_args[-1], str) and command_args[-1].lower().endswith((".py", ".js", ".mjs", ".ts", ".r", ".R")):
        t = command_args[-1]
        target_abs = t if os.path.isabs(t) else os.path.abspath(os.path.join(cwd, t))
        target_abs = target_abs.replace("\\", "/")

    # Bounded history for prompt stability
    healing_history: List[str] = []
    MAX_HISTORY_ITEMS = 6
    MAX_HISTORY_CHARS = 2000

    # Redundant scan removed. Dependency check is managed by the shell before execution.

    def _push_history(item: str) -> None:
        if not item:
            return
        healing_history.append(item[:MAX_HISTORY_CHARS])
        if len(healing_history) > MAX_HISTORY_ITEMS:
            del healing_history[:-MAX_HISTORY_ITEMS]

    def _norm_path(p: str) -> str:
        return (p or "").replace("\\", "/")

    def _basename(p: str) -> str:
        return os.path.basename(_norm_path(p))

    def _resolve_modified_paths(modified: List[str]) -> List[str]:
        """
        Convert returned modified file identifiers into real on-disk paths when possible.
        Returns absolute, normalized paths for files that exist.
        """
        out: List[str] = []
        for f in modified or []:
            if not f or f == "SYSTEM_ENVIRONMENT" or not isinstance(f, str):
                continue

            f_norm = _norm_path(f)

            candidates = []
            if os.path.isabs(f_norm):
                candidates.append(f_norm)
            else:
                candidates.append(_norm_path(os.path.abspath(os.path.join(cwd, f_norm))))

            # Also try basename in cwd if AI returned weird relative fragments
            candidates.append(_norm_path(os.path.abspath(os.path.join(cwd, os.path.basename(f_norm)))))

            found = None
            for c in candidates:
                if os.path.exists(c) and os.path.isfile(c):
                    found = c
                    break

            if found and found not in out:
                out.append(found)

        return out

    def _snapshot_files(paths: List[str]) -> Dict[str, str]:
        snap: Dict[str, str] = {}
        for p in paths:
            try:
                snap[p] = _read_text(p)
            except Exception:
                pass
        return snap

    def _revert_files(snapshot: Dict[str, str]) -> None:
        for p, content in snapshot.items():
            try:
                _write_text(p, content)
            except Exception:
                pass

    for attempt in range(1, max_attempts + 1):
        ui.print(f"[dim]>> Run attempt {attempt}/{max_attempts}: {' '.join(command_args)}[/dim]")

        exit_code, stdout, stderr = _run_once(command_args, cwd)
        full_logs = (stdout or "") + (stderr or "")
        last_err = stderr or stdout or f"exit_code={exit_code}"

        if exit_code == 0:
            # If successful, we return the full logs so the Interpretation Phase has data
            return full_logs if full_logs.strip() else "SUCCESS_SIGNAL"

        err_text = (stderr or "") + "\n" + (stdout or "")

        # Local hotfix: strip UTF-8 BOM bytes that can break Python
        if (
            ("U+FEFF" in err_text or "invalid non-printable character" in err_text)
            and target_abs
            and os.path.exists(target_abs)
        ):
            if _strip_utf8_bom(target_abs):
                ui.print("[yellow]>> Detected UTF-8 BOM (U+FEFF). Removed BOM and retrying...[/yellow]")
                prompts.clear_file_tree_cache()
                _ensure_target_file_in_context(command_args, cwd, merged_context)
                continue

        # Force a fresh read from disk to avoid "search_not_found" errors
        prompts.clear_file_tree_cache()
        
        # REBUILD CONTEXT FROM SCRATCH - Pure state, no shell pollution
        merged_context.clear()
        
        try:
            from nova_cli.local.contextifier import run_contextify
            # Generate/update project context file in the current working directory before healing
            project_ctx = run_contextify(cwd, save_to_disk=True)
            if isinstance(project_ctx, dict):
                merged_context.update(project_ctx)
            elif isinstance(project_ctx, str):
                # Inject string dumps as a virtual file so the AI can read it
                merged_context["PROJECT_CONTEXT_SUMMARY.txt"] = project_ctx
        except Exception: pass
        
        _ensure_target_file_in_context(command_args, cwd, merged_context)

        clean_stdout = (stdout or "").replace("\r\n", "\n").replace("\r", "\n")
        clean_stderr = (stderr or "").replace("\r\n", "\n").replace("\r", "\n")

        # Detect language to prevent misclassification in Healer
        lang = "Python"
        package_manager = "pip install"
        if any(arg.endswith((".r", ".R")) for arg in command_args): 
            lang = "R-Language"
            package_manager = "Rscript -e 'install.packages(...)'"
        elif any(arg.endswith(".js") for arg in command_args): 
            lang = "Node.js"
            package_manager = "npm install"

        with ui.create_loader(f"NOVA is analyzing {lang} logs and generating a fix..."):
            # Inject strict language instructions into stderr for the AI
            lang_instruction = (
                f"CRITICAL: The current language is {lang}.\n"
                f"You MUST use {package_manager} if a library is missing.\n"
                "DO NOT suggest Python packages for R or Node errors.\n"
                "CRITICAL: For [EDIT: filename] blocks, you MUST use the relative path (e.g. src/repositories/index.js). Do NOT use absolute paths.\n"
                "CRITICAL: Your SEARCH block must be EXACTLY 1 or 2 lines of original code. Do NOT use '...' or '// ...' to skip lines.\n"
                "CRITICAL: The SEARCH block must match the original file exactly, including all spaces and indentation."
            )
            
            # Normalize line endings to \n to guarantee match with API validator
            # AND expand keys to include absolute paths just in case AI hallucinates them
            expanded_ctx = {}
            for k, v in list(merged_context.items()):
                normalized_v = v.replace("\r\n", "\n").replace("\r", "\n")
                expanded_ctx[k] = normalized_v
                if not os.path.isabs(k):
                    abs_p = os.path.abspath(os.path.join(cwd, k))
                    expanded_ctx[abs_p] = normalized_v
                    expanded_ctx[abs_p.replace("\\", "/")] = normalized_v
            
            merged_context.clear()
            merged_context.update(expanded_ctx)
            
            # CRITICAL FIX: Clear the history so the AI doesn't hallucinate old code
            # after the file was successfully mutated in Attempt 1.
            if isinstance(healing_history, list):
                healing_history.clear()
            
            patch_block = api.run_with_healing(
                command=command_args,
                cwd=cwd,
                model="openai/gpt-oss-120b",
                provider="openrouter",
                exit_code=exit_code,
                stdout=clean_stdout,
                stderr=f"{lang_instruction}\n{clean_stderr}",
                context=merged_context,
                repo_map=repo_map,
                healing_history=[],  # Force empty history
            )

        if not patch_block or not patch_block.strip():
            ui.display_error(
                "NOVA could not generate a valid repair patch for this error. \n\n[cyan]Please report or give feedback on support@bridgeye.com.[/cyan]",
                title="Healing Failure"
            )
            return "FAILURE_SIGNAL"

        ui.print("[cyan]>> Healer suggested patch. Applying...[/cyan]")

        # Apply patch
        modified = handle_ai_commands(patch_block, cwd=cwd)

        # Record what we tried (ONCE)
        _push_history(patch_block)

        # If nothing applied, add a corrective hint and retry
        if not modified:
            _push_history(
                "EDIT_NOT_APPLIED: CLI could not apply patch. "
                "CAUSE: SEARCH not found or invalid SEARCH/REPLACE structure. "
                "NEXT: Copy SEARCH lines verbatim from FILE_CONTEXT, include exact indentation."
            )
            _ensure_target_file_in_context(command_args, cwd, merged_context)
            continue

        # Resolve real modified file paths and snapshot for possible revert
        modified_paths = _resolve_modified_paths(modified)
        snapshot = _snapshot_files(modified_paths)

        # Syntax check: if any modified .py file fails compile, revert and retry
        syntax_failed = False
        syntax_err = ""
        for p in modified_paths:
            if p.lower().endswith(".py"):
                ok, err = _syntax_check(p)
                if not ok:
                    syntax_failed = True
                    syntax_err = f"{os.path.basename(p)}: {err}"
                    break

        if syntax_failed:
            ui.print("[red]>> Edit Rejected: Resulting code has Syntax Error.[/red]")
            ui.print(f"[red]>> {syntax_err}[/red]")
            _revert_files(snapshot)
            _push_history(f"SYNTAX_ERROR_AFTER_PATCH: {syntax_err}")
            _ensure_target_file_in_context(command_args, cwd, merged_context)
            continue

        # After file ops, clear repo-map cache + refresh context for modified files
        prompts.clear_file_tree_cache()

        # REFRESH CONTEXT: Strictly re-read all modified files from disk
        for p in modified_paths:
            try:
                with open(p, "r", encoding="utf-8") as fp:
                    content = fp.read()
                
                content = content.replace("\r\n", "\n").replace("\r", "\n")
                if content.startswith("\ufeff"):
                    content = content.lstrip("\ufeff")

                abs_key = _norm_path(p)
                rel_key = None
                try:
                    rel_key = os.path.relpath(p, cwd).replace("\\", "/")
                except Exception:
                    pass

                # Remove all possible stale versions of this file from the dictionary
                # Use lower() to handle Windows case-insensitivity during refresh
                p_base = _basename(p).lower()
                keys_to_clear = [k for k in merged_context.keys() if _basename(k).lower() == p_base]
                for k in keys_to_clear:
                    del merged_context[k]

                # Re-insert fresh content
                merged_context[abs_key] = content
                if rel_key:
                    merged_context[rel_key] = content
            except Exception:
                pass

        # Force a refresh of the target file context specifically
        _ensure_target_file_in_context(command_args, cwd, merged_context)

    raise RuntimeError(f"Command failed after {max_attempts} attempts.\nLast error:\n{last_err}")

