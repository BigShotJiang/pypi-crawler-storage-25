from rich.console import Console, Group
from rich.panel import Panel
from rich.markdown import Markdown
from rich.live import Live
from rich.table import Table
from rich.rule import Rule
from rich import box
import os
import questionary
import requests
from questionary import Separator
from nova_cli import __version__, config
from nova_cli.nova_core.ai.utils import MODELS  # CLI model selector list
from nova_cli.local.file_manager.git_ops import get_repo

class Interface:
    def __init__(self):
        # Removed fixed width=120 to allow responsiveness to terminal size
        self.console = Console(force_terminal=True)
        self._update_status = None

    def print(self, *args, **kwargs):
        # We set soft_wrap=True as default unless specifically told otherwise
        if "soft_wrap" not in kwargs:
            kwargs["soft_wrap"] = True
        self.console.print(*args, **kwargs)

    def input(self, prompt_text):
        """Renders prompt with Rich and uses prompt_toolkit for perfect scrolling and wrapping."""
        from prompt_toolkit import prompt
        from prompt_toolkit.formatted_text import ANSI
        
        with self.console.capture() as capture:
            self.console.print(prompt_text, end="")
        raw_prompt = capture.get()
        
        try:
            return prompt(ANSI(raw_prompt))
        except (EOFError, KeyboardInterrupt):
            raise
    
    def script_output(self, text: str, title: str = "Terminal Output", color: str = "white"):
        """Displays script output in a structured, pretty terminal panel."""
        if not text or not text.strip():
            return
        
        from rich.text import Text
        # Use markup=False to preserve raw data/logs exactly as they appeared
        content = Text(text.strip(), style=color) 
        
        self.console.print(Panel(
            content,
            title=f"[bold]{title}[/bold]",
            border_style="bright_black",
            padding=(1, 2),
            subtitle="[dim]Execution complete[/dim]",
            subtitle_align="right"
        ))

    def display_error(self, message: str, title: str = "System Error"):
        """Renders a prettified error message, hiding technical noise."""
        import re
        # Clean JSON structures and raw error codes
        clean_msg = str(message)
        if "{" in clean_msg and "}" in clean_msg:
            # Extract message from JSON-like strings if possible, else generic fallback
            match = re.search(r"['\"]message['\"]:\s*['\"](.*?)['\"]", clean_msg)
            clean_msg = match.group(1) if match else "An unexpected internal error occurred."
        
        # Replace common technical codes with user-friendly language
        if "403" in clean_msg:
            clean_msg = "Access denied. Please ensure you are logged in or check your network settings."
        elif "504" in clean_msg or "503" in clean_msg or "500" in clean_msg:
            clean_msg = "The server is currently unreachable or timed out. Please check your internet connection."
        
        # Remove Provider-specific prefixes
        clean_msg = re.sub(r"^[A-Z]+\sProvider\sError:\s*", "", clean_msg)
        clean_msg = re.sub(r"^Error\scode:\s\d+\s-\s*", "", clean_msg)

        self.console.print(Panel(
            f"[bold white]{clean_msg}[/bold white]",
            title=f"[bold red] {title} [/bold red]",
            border_style="red",
            padding=(1, 2),
        ))

    def display_interpretation(self, interpretation_text: str):
        """Displays AI-generated data insights in a specialized panel."""
        if not interpretation_text:
            return
        self.console.print(Panel(
            Markdown(interpretation_text.strip()),
            title="[bold magenta]NOVA DATA INTERPRETATION[/bold magenta]",
            border_style="magenta",
            padding=(1, 2)
        ))

    def create_loader(self, text=""):
        # Bigger dots12 spinner matching spark terminal bold cyan color
        return self.console.status(
            f"[bold cyan]{text}[/bold cyan]",
            spinner="dots12",
            spinner_style="cyan",
            speed=1.0
        )

    def show_model_selector(self, current_model: str):
        # Build (provider, model) pairs so we can return both
        options = []
        for provider, models in MODELS.items():
            for m in models:
                options.append((provider, m))

        # Show only model names in UI, but keep provider in the value
        choices = [
            questionary.Choice(title=model, value=(provider, model))
            for provider, model in options
        ]

        # Default selection
        default_value = None
        for provider, model in options:
            if model == current_model:
                default_value = (provider, model)
                break

        answer = questionary.select(
            "Model:",
            choices=choices,
            default=default_value,
            style=questionary.Style([
                ("qmark", "fg:#00ffff bold"),
                ("question", "fg:#ffffff bold"),
                ("answer", "fg:#00ffff bold"),
                ("pointer", "fg:#00ffff bold"),
                ("selected", "fg:#00ffff"),
            ]),
        ).ask()

        if not answer:
            # keep current model, assume openrouter if unknown
            return current_model, "openrouter"

        provider, model = answer
        return model, provider



    def show_git_options(self, auto_commit, auto_push):
        """Displays the Git Configuration Menu with dynamic Init option."""
        # Check if repo exists to dynamically change the menu
        has_repo = get_repo() is not None

        state_ac = "🟢 ON " if auto_commit else "🔴 OFF"
        state_ap = "🟢 ON " if auto_push else "🔴 OFF"

        choices = [
            Separator("--- AUTOMATION SETTINGS ---"),
            f"Toggle Auto-Commit  [{state_ac}]",
            f"Toggle Auto-Push    [{state_ap}]",
            
            Separator("--- ACTIONS ---"),
        ]

        if not has_repo:
            choices.append("📦 Initialize Git Repository")
        else:
            choices.extend([
                "📝 Manual Commit (Stage & Commit all)",
                "🚀 Push to Origin",
                "⬇️  Pull from Origin",
                "📊 Git Status",
            ])
            
        choices.extend([
            Separator("--- EXIT ---"),
            "🔙 Back to Terminal"
        ])

        answer = questionary.select(
            "Git Operations Center",
            choices=choices,
            style=questionary.Style([
                ('qmark', 'fg:#00ff00 bold'),       
                ('question', 'fg:#ffffff bold'),    
                ('answer', 'fg:#00ff00 bold'),      
                ('pointer', 'fg:#00ff00 bold'),     
                ('selected', 'fg:#00ff00'),
                ('separator', 'fg:#666666'),
            ]),
            use_indicator=True
        ).ask()
        
        if not answer: return "Back"
        if "Initialize" in answer: return "Initialize"
        if "Back" in answer: return "Back"
        if "Auto-Commit" in answer: return "Toggle Auto-Commit"
        if "Auto-Push" in answer: return "Toggle Auto-Push"
        if "Manual Commit" in answer: return "Manual Commit"
        if "Push" in answer: return "Push"
        if "Pull" in answer: return "Pull"
        if "Force Sync" in answer: return "Force Sync"
        if "Git Status" in answer: return "Git Status"
        
        return answer

    def get_multiline_input(self):
        self.print("[dim]Paste code below. Type 'EOF' to finish.[/dim]")
        lines = []
        while True:
            try:
                line = self.console.input()
                if line.strip().upper() == "EOF": break
                lines.append(line)
            except KeyboardInterrupt:
                return ""
        return "\n\n".join(lines)

    def clear(self):
        self.console.clear()

    def display_interpretation(self, interpretation_text: str):
        """Displays AI-generated data insights in a specialized panel."""
        if not interpretation_text:
            return
        self.console.print(Panel(
            Markdown(interpretation_text.strip()),
            title="[bold magenta]NOVA DATA INTERPRETATION[/bold magenta]",
            border_style="magenta",
            padding=(1, 2)
        ))

    def display_coding_mode(self, model_name: str):
        """Displays a high-visibility banner for the selected implementation model."""
        display_name = "KIMI k2.6"
        
        self.console.print(Panel(
            f"[bold white]CORE UPGRADE:[/bold white] [bold purple]{display_name} ACTIVE[/bold purple]\n"
            f"[dim]Mode: Surgical Implementation | Model: {model_name}[/dim]",
            border_style="purple",
            expand=False
        ))

    def display_blueprint(self, blueprint_text: str):
        """Displays the AST-based repository map."""
        from rich.syntax import Syntax
        syntax = Syntax(blueprint_text, "python", theme="monokai", line_numbers=False, word_wrap=True)
        self.console.print(Panel(
            syntax,
            title="[bold cyan]Project Blueprint (Repository Map)[/bold cyan]",
            border_style="cyan",
            padding=(1, 2)
        ))

    def render_ai_response(self, text: str):
        """Renders AI markdown response with high-fidelity formatting."""
        if not text:
            return
        
        # Parse as Markdown to properly render tables, headers, and formatting
        md = Markdown(text.strip())
        
        self.console.print()  # Vertical spacer
        self.console.print(md)
        # Visual divider to separate response from the next input prompt
        self.console.print("[dim]────────────────────────────────────────────────────────────────────────────────[/dim]")

    def render_help_menu(self, sections: dict):
        """Renders a responsive, structured help menu using Tables."""
        table = Table(box=None, show_header=False, padding=(0, 2), expand=True)
        table.add_column("Command", style="bold cyan", no_wrap=True, width=15)
        table.add_column("Description", style="dim")

        for section_title, commands in sections.items():
            table.add_row(f"\n[bold magenta]{section_title}[/bold magenta]")
            for cmd, desc in commands.items():
                table.add_row(cmd, desc)

        self.console.print(Panel(table, title="[bold white]NOVA HELP CENTER[/bold white]", border_style="cyan", padding=(1, 2)))

    def render_ai_response(self, text: str):
        if not text:
            return
        
        # Markdown handles tables and headers responsively
        md = Markdown(text.strip())
        self.console.print() 
        self.console.print(md)
        # Rule automatically expands to fill the current terminal width
        self.console.print(Rule(style="dim"))

    def _get_update_status(self):
        """Checks API URL to toggle Developer Mode or Update notifications."""
        if self._update_status:
            return self._update_status

        api_url = config.NOVA_API_BASE_URL.lower()
        is_localhost = "localhost" in api_url or "127.0.0.1" in api_url

        # 1. Always establish the current version display first
        current_version_display = f"[dim]v{__version__}[/dim]"

        if is_localhost:
            self._update_status = f"[bold green]Local Build[/bold green] {current_version_display}"
            return self._update_status

        # 2. Production / Remote environment: Check for updates on PyPI
        try:
            response = requests.get("https://pypi.org/pypi/nova-bridgeye/json", timeout=1.5)
            latest_version = response.json()["info"]["version"]

            # Helper function to convert "0.1.5.1" into (0, 1, 5, 1) for accurate math comparison
            def parse_ver(v):
                return tuple(map(int, (v.split("."))))

            # Only notify if PyPI version is strictly greater than installed version
            if parse_ver(latest_version) > parse_ver(__version__):
                self._update_status = (
                    f"{current_version_display}  [bold yellow]Update Available: v{latest_version}[/bold yellow]\n"
                    f"[dim]Run: pip install --upgrade nova-bridgeye[/dim]"
                )
            else:
                self._update_status = f"{current_version_display} [dim](Up to date)[/dim]"
        except Exception:
            # Fallback if PyPI is unreachable or parsing fails
            self._update_status = current_version_display

        return self._update_status

    def display_startup_hint(self, logged_in: bool = True):
        """Displays a visually appealing prompt based on login status."""
        if logged_in:
            msg = "Welcome back! Type [bold cyan]help[/bold cyan] to explore available commands and features."
        else:
            msg = "Welcome to [bold cyan]NOVA[/bold cyan]! Type [bold cyan]login[/bold cyan] to connect your account and start building."
            
        self.console.print(Panel(
            msg,
            border_style="bright_black",
            padding=(0, 2),
            expand=False
        ))

    def display_header(self, model_name, cwd):
        self.clear()
        
        # Build Top Header Row (Left: Identity & CWD, Right: Version Status)
        header_table = Table.grid(expand=True)
        # vertical="top" keeps alignment perfect even if there is no update
        header_table.add_column(justify="left", vertical="top")
        header_table.add_column(justify="right", vertical="top")
        
        identity_and_cwd = f"[bold white]NOVA[/bold white] [dim]│[/dim] [cyan]{model_name}[/cyan]\n[dim]{cwd}[/dim]"
        version_info = self._get_update_status()
        
        header_table.add_row(identity_and_cwd, version_info)

        self.console.print(Rule(style="dim"))
        self.console.print(header_table)
        self.console.print(Rule(style="dim"))

    def stream_response(self, chat_generator):
        full_text = ""
        self.print() 
        
        from rich.spinner import Spinner
        spinner = Spinner("dots12", text="[bold cyan]NOVA is thinking...[/bold cyan]", speed=1.5)

        with Live(spinner, refresh_per_second=15, auto_refresh=True, vertical_overflow="visible") as live:
            chunk_counter = 0
            for chunk in chat_generator:
                if chunk.text:
                    full_text += chunk.text
                    chunk_counter += 1
                    if chunk_counter % 4 == 0:
                        live.update(Markdown(full_text))
            
            if full_text:
                live.update(Markdown(full_text))
        
        self.print() 
        return full_text

    def stream_rich_response(self, chat_generator, show_reasoning: bool = True):
        """Beautified stream for models with reasoning (Thinking) capabilities."""
        full_content = ""
        thought_content = ""
        self.print()

        from rich.spinner import Spinner
        spinner = Spinner("dots12", text="[bold cyan]NOVA is thinking...[/bold cyan]", speed=1.5)

        with Live(spinner, refresh_per_second=15, auto_refresh=True, vertical_overflow="visible") as live:
            for event in chat_generator:
                if event.get("type") == "chunk":
                    text = event.get("text", "")
                    is_reasoning = event.get("is_reasoning", False)

                    if is_reasoning:
                        if show_reasoning:
                            thought_content += text
                    else:
                        full_content += text

                    # Build the display group
                    display_parts = []
                    if thought_content and show_reasoning:
                        display_parts.append(Panel(thought_content.strip(), title="[dim]NOVA Thinking...[/dim]", border_style="dim", style="dim"))
                    if full_content:
                        display_parts.append(Markdown(full_content))
                    
                    if not display_parts:
                        live.update(spinner)
                    else:
                        live.update(Group(*display_parts))
                elif event.get("type") == "error":
                    err_msg = event.get("error", "").lower()
                    if any(k in err_msg for k in ["rate_limit", "413", "tpm"]):
                        raise RuntimeError("The model is very busy due to high demand. Please switch to another model using :model.")
                    if "504" in err_msg:
                        raise RuntimeError("Connection timed out. Please check your internet and try again.")
                    if "403" in err_msg:
                        raise RuntimeError("Access denied. Please check your internet connection or login status.")
                    raise RuntimeError("An unexpected error occurred during the build sequence.")

        # Ensure a clean break after implementation tasks
        self.print()
        
        # Fallback: If the model mistakenly outputs everything as reasoning, return the thought content so edits aren't lost.
        final_result = full_content if full_content.strip() else thought_content
        return final_result

ui = Interface()