import re
import ast
import os
from typing import List, Tuple, Optional

def extract_code_from_markdown(md_text: str) -> Optional[str]:
    """
    Finds the most relevant code block. Uses greedy matching to handle nested blocks 
    (e.g. a Markdown plan containing smaller code snippets).
    """
    # Greedy match to capture outermost block if nested
    pattern = r"```(?:\w+)?\s*\n?([\s\S]*)```"
    match = re.search(pattern, md_text)
    
    if match:
        return match.group(1).strip()
    
    # Fallback to non-greedy findall if greedy failed
    pattern_fallback = r"```(?:\w+)?\s*(.*?)```"
    matches = re.findall(pattern_fallback, md_text, re.DOTALL)
    if not matches:
        return None

    candidates = []
    
    # Analyze matches to score them
    for content in matches:
        lines = content.strip().splitlines()
        line_count = len(lines)
        
        # Heuristic: Detect shell commands
        is_shell = False
        first_word = lines[0].strip().split()[0] if lines and lines[0].strip() else ""
        if first_word.lower() in ["pip", "python", "npm", "cd", "ls", "nova", "git", "bash", "sh"]:
            is_shell = True
            
        candidates.append({
            "content": content.strip(),
            "lines": line_count,
            "is_shell": is_shell
        })

    # Filter: If we have multiple blocks, discard short shell blocks
    if len(candidates) > 1:
        filtered = [c for c in candidates if not (c["is_shell"] and c["lines"] < 5)]
        if filtered:
            candidates = filtered

    # Sort by length (descending) - Assume the actual code is the largest chunk
    candidates.sort(key=lambda x: x["lines"], reverse=True)

    return candidates[0]["content"]

def parse_multiple_files(text: str) -> List[Tuple[str, str]]:
    """
    Parses text for multiple [CREATE: filename] ... content pairs.
    
    Robustness: 
    1. Handles bolding/whitespace in tags.
    2. FIRST tries to find a Markdown code block.
    3. FALLBACK: If no code block is found, captures text but STOPS at conversational markers.
    
    Args:
        text (str): The text to parse for [CREATE: filename] ... content pairs.
    
    Returns:
        List[Tuple[str, str]]: A list of tuples containing the filename and content.
    """
    files_to_create: List[Tuple[str, str]] = []
    
    # 1. Split text by the [CREATE: filename] tag
    # This divides the text into [preamble, filename1, content1, filename2, content2...]
    split_pattern = r"(?:\*\*|__)?\[CREATE:\s*(.*?)\s*\](?:\*\*|__)?"
    segments = re.split(split_pattern, text, flags=re.IGNORECASE)
    
    if len(segments) < 3:
        return []

    # Iterate starting from index 1 (first filename), taking steps of 2
    for i in range(1, len(segments), 2):
        filename = segments[i].strip()
        following_text = segments[i+1]
        
        # Clean up filename (remove potential trailing punctuation)
        filename = filename.rstrip(".:,")
        
        # Strategy A: Look for explicit Markdown Code Block (Preferred)
        # We use a greedy match ([\s\S]*) to capture internal code blocks (mermaid, etc.)
        # We then manually strip the very last set of triple backticks if they exist.
        match = re.search(r"```(?:\w+)?\s*\n?([\s\S]*)", following_text)
        
        if match:
            # We capture everything after the first ```
            code = match.group(1).strip()
            
            # IMPROVED LOGIC: Only strip the closing fence if it's the 
            # VERY LAST thing in the segment. This prevents truncating 
            # at internal code blocks (like JSON snippets in a PLAN.md).
            if code.endswith("```"):
                code = code[:-3].strip()
            elif "```" in code:
                # If there's a fence but not at the end, the model likely 
                # stopped mid-sentence or used internal blocks. 
                # We search for the outermost closing fence.
                potential_end = code.rfind("```")
                # If there is conversational text after the last fence, 
                # we cut at the last fence.
                if potential_end != -1:
                    code = code[:potential_end].strip()
                
            files_to_create.append((filename, code))
        else:
            # Strategy B (Fallback): The AI forgot backticks. 
            # We take the raw text and stop ONLY if we see another NOVA tag.
            # This ensures Markdown headers (#) and bold (**) aren't cut off.
            raw_content = following_text.strip()
            
            # If the next tag exists in this block, cut the content there
            next_tag = re.search(r"\[(?:CREATE|EDIT|MKDIR|DELETE):", raw_content, re.IGNORECASE)
            if next_tag:
                raw_content = raw_content[:next_tag.start()].strip()
            
            if raw_content:
                files_to_create.append((filename, raw_content))
            
    return files_to_create

def check_syntax(content: str, filename: str) -> Tuple[bool, str]:
    """
    Verifies if the code content is valid syntax for Python, Node.js, or R.
    """
    import subprocess
    import tempfile

    ext = os.path.splitext(filename)[1].lower()
    
    if ext == ".py":
        try:
            ast.parse(content)
            return True, ""
        except SyntaxError as e:
            return False, f"Line {e.lineno}: {e.msg}"
        except Exception as e:
            return False, str(e)

    elif ext in [".js", ".mjs", ".ts"]:
        # Use node --check for a dry-run syntax validation
        with tempfile.NamedTemporaryFile(suffix=ext, delete=False, mode='w', encoding='utf-8') as tmp:
            tmp.write(content)
            tmp_path = tmp.name
        try:
            node_bin = "node.exe" if os.name == "nt" else "node"
            res = subprocess.run([node_bin, "--check", tmp_path], capture_output=True, text=True)
            os.remove(tmp_path)
            if res.returncode != 0:
                return False, res.stderr
            return True, ""
        except Exception:
            return True, "" # Fallback if node isn't installed

    return True, ""

def generate_ast_map(startpath: str) -> str:
    """
    Scans the directory and generates a high-level map of the code structure
    (Classes and Functions) using AST, skipping bodies to save tokens.
    """
    repo_map = []
    
    excluded_dirs = {
        ".git", "__pycache__", "venv", "env", "node_modules", 
        ".idea", ".vscode", "dist", "build", ".next", ".ds_store", 
        ".mypy_cache", ".nova"
    }

    for root, dirs, files in os.walk(startpath):
        # Filter directories in-place
        dirs[:] = [d for d in dirs if d not in excluded_dirs and not d.startswith(".")]
        
        # Define extensions we want to show in the map
        trackable_extensions = (".py", ".html", ".css", ".js", ".ts", ".r", ".json", ".md")

        for file in files:
            if not file.endswith(trackable_extensions):
                continue
                
            full_path = os.path.join(root, file)
            rel_path = os.path.relpath(full_path, startpath).replace("\\", "/")
            
            # Case 1: Python Files (AST parsing for structure)
            if file.endswith(".py"):
                try:
                    with open(full_path, 'r', encoding='utf-8') as f:
                        content = f.read()
                        if not content.strip(): continue
                        tree = ast.parse(content)
                    
                    repo_map.append(f"FILE: {rel_path}")
                    
                    for node in tree.body:
                        if isinstance(node, ast.ClassDef):
                            repo_map.append(f"  class {node.name}:")
                            for sub in node.body:
                                if isinstance(sub, (ast.FunctionDef, ast.AsyncFunctionDef)) and not sub.name.startswith("_"):
                                    args = [a.arg for a in sub.args.args]
                                    sig = f"def {sub.name}({', '.join(args)})"
                                    prefix = "    async " if isinstance(sub, ast.AsyncFunctionDef) else "    "
                                    repo_map.append(f"{prefix}{sig}")
                        elif isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                            args = [a.arg for a in node.args.args]
                            sig = f"def {node.name}({', '.join(args)})"
                            prefix = "async " if isinstance(node, ast.AsyncFunctionDef) else ""
                            repo_map.append(f"  {prefix}{sig}")
                            
                except Exception:
                    repo_map.append(f"FILE: {rel_path} (Parse Error)")
            
            # Case 2: Node.js / R / Web (Lightweight symbol extraction)
            elif file.endswith((".js", ".ts", ".r", ".R")):
                repo_map.append(f"FILE: {rel_path}")
                try:
                    with open(full_path, 'r', encoding='utf-8') as f:
                        lines = f.readlines()
                    for line in lines:
                        # Match JS functions: function name() or const name = () =>
                        js_func = re.search(r'(?:function\s+([\w\d_]+)|(?:const|let|var)\s+([\w\d_]+)\s*=\s*(?:async\s*)?\(.*?\)\s*=>)', line)
                        if js_func:
                            name = js_func.group(1) or js_func.group(2)
                            repo_map.append(f"  function {name}()")
                        
                        # Match R functions: name <- function(...)
                        r_func = re.search(r'([\w\d\._]+)\s*(?:<-|=)\s*function\s*\(', line)
                        if r_func:
                            repo_map.append(f"  function {r_func.group(1)}()")
                except: pass
            else:
                repo_map.append(f"FILE: {rel_path}")
                
    return "\n".join(repo_map)

def strip_ansi(text: str) -> str:
    """Aggressive cleaner that removes ANSI and broken terminal fragments."""
    if not text: return ""
    import re
    # 1. Standard ANSI Escape codes
    ansi_escape = re.compile(r'\x1B(?:[@-Z\\-_]|\[[0-?]*[ -/]*[@-~])')
    text = ansi_escape.sub('', text)
    
    # 2. Fix broken fragments (like [1m or [0m appearing as literal text)
    text = re.sub(r'\[\d+(?:\;\d+)*m', '', text)
    
    # 3. Remove Carriage Returns (\r) which cause line overwriting/backspacing artifacts
    text = text.replace('\r', '')
    
    # 4. Keep only printable characters to ensure the UI stays clean
    return "".join(ch for ch in text if ch.isprintable() or ch in "\n\t")

def get_platform_install_cmd(tool_name: str) -> str:
    """Returns the OS-specific installation command for a given tool."""
    import platform
    import sys
    os_type = platform.system().lower()
    
    # Winget flags: --silent (no UI), --accept-source-agreements, --accept-package-agreements
    win_flags = "--silent --accept-source-agreements --accept-package-agreements"

    installers = {
        "node": {
            "windows": f"winget install OpenJS.NodeJS {win_flags}",
            "darwin": "brew install node",
            "linux": "sudo apt-get update && sudo apt-get install -y nodejs npm"
        },
        "npm": {
            "windows": f"winget install OpenJS.NodeJS {win_flags}",
            "darwin": "brew install node",
            "linux": "sudo apt-get update && sudo apt-get install -y npm"
        },
        "npx": {
            "windows": f"winget install OpenJS.NodeJS {win_flags}",
            "darwin": "brew install node",
            "linux": "sudo apt-get update && sudo apt-get install -y nodejs npm"
        },
        "Rscript": {
            "windows": f"winget install RProject.R {win_flags}",
            "darwin": "brew install r",
            "linux": "sudo apt-get update && sudo apt-get install -y r-base"
        },
        "streamlit": {
            "windows": f"{sys.executable} -m pip install streamlit",
            "darwin": f"{sys.executable} -m pip install streamlit",
            "linux": f"{sys.executable} -m pip install streamlit"
        }
    }

    if tool_name in installers:
        target_os = "darwin" if os_type == "darwin" else ("windows" if os_type == "windows" else "linux")
        return installers[tool_name].get(target_os, "")
    
    return ""

def refresh_environment_variables():
    """Reloads PATH from the OS across Windows, Mac, and Linux without restarting."""
    import os
    import sys
    import platform
    
    os_type = platform.system().lower()

    if os_type == "windows":
        try:
            import winreg
            paths = []
            # Pull from User and System Registry
            for hkey, subkey in [(winreg.HKEY_CURRENT_USER, "Environment"), 
                                (winreg.HKEY_LOCAL_MACHINE, r"SYSTEM\CurrentControlSet\Control\Session Manager\Environment")]:
                with winreg.OpenKey(hkey, subkey) as key:
                    try:
                        raw_path, _ = winreg.QueryValueEx(key, "Path")
                        paths.extend(raw_path.split(os.pathsep))
                    except FileNotFoundError:
                        continue
            
            # Merge and de-duplicate
            current_path = os.environ.get("PATH", "").split(os.pathsep)
            updated_path = list(dict.fromkeys(current_path + paths)) 
            os.environ["PATH"] = os.pathsep.join(updated_path)
        except Exception:
            pass
            
    elif os_type in ["darwin", "linux"]:
        # Standard binary locations that installers (brew/apt) target
        standard_bins = [
            "/usr/local/bin", "/usr/bin", "/bin", "/usr/sbin", "/sbin",
            "/opt/homebrew/bin", "/opt/homebrew/sbin", # Mac Brew
            os.path.expanduser("~/.local/bin"),        # Linux/Python user bins
            os.path.expanduser("~/bin")
        ]
        current_path = os.environ.get("PATH", "").split(os.pathsep)
        updated_path = list(dict.fromkeys(current_path + standard_bins))
        os.environ["PATH"] = os.pathsep.join(updated_path)

def ensure_dependencies(file_path: str, tool_path: str = None):
    """Universal entry point to scan and install dependencies for Python, R, and Node."""
    ext = os.path.splitext(file_path)[1].lower()
    if ext == ".py":
        _ensure_python_deps(file_path)
    elif ext in [".r", ".R"]:
        _ensure_r_deps(file_path, tool_path)
    elif ext == ".js":
        _ensure_node_deps(file_path, tool_path)

def _ensure_python_deps(file_path: str):
    import importlib.metadata
    import sys
    import subprocess
    from nova_cli.local.ui import ui

    ui.print(f"[dim]>> Pre-scanning Python dependencies for {os.path.basename(file_path)}...[/dim]")
    with open(file_path, "r", encoding="utf-8") as f:
        content = f.read()

    imports = re.findall(r"^(?:import|from)\s+([\w\d_]+)", content, re.MULTILINE)
    unique_imports = set(imports)
    std_lib = {"os", "sys", "re", "time", "json", "datetime", "math", "random", "shutil", "subprocess", "shlex", "ast", "logging", "io", "base64", "collections", "itertools", "functools", "pathlib", "threading", "queue", "pickle", "csv"}
    
    missing = []
    for mod in unique_imports:
        if mod in std_lib: continue
        try:
            importlib.metadata.version(mod)
        except importlib.metadata.PackageNotFoundError:
            mapping = {"sklearn": "scikit-learn", "cv2": "opencv-python", "PIL": "Pillow", "yaml": "pyyaml"}
            missing.append(mapping.get(mod, mod))
            
    if missing:
        ui.print(f"[bold cyan]>> Environment Check: Found {len(missing)} missing Python packages.[/bold cyan]")
        try:
            subprocess.check_call([sys.executable, "-m", "pip", "install"] + missing)
            ui.print("[bold green]>> Python environment synchronized.[/bold green]")
        except Exception:
            for pkg in missing:
                try: subprocess.check_call([sys.executable, "-m", "pip", "install", pkg], stderr=subprocess.DEVNULL, stdout=subprocess.DEVNULL)
                except Exception: pass

def _ensure_r_deps(file_path: str, tool_path: str = None):
    import subprocess
    from nova_cli.local.ui import ui
    ui.print(f"[dim]>> Pre-scanning R dependencies for {os.path.basename(file_path)}...[/dim]")
    
    with open(file_path, "r", encoding="utf-8") as f:
        content = f.read()
    
    pkgs = re.findall(r"(?:library|require)\s*\(\s*\"?([\w\d\.]+)\"?\s*\)", content)
    if pkgs:
        ui.print(f"[bold cyan]>> Environment Check: Ensuring R packages: {', '.join(set(pkgs))}[/bold cyan]")
        
        # Use the resolved tool_path if provided, else fallback to 'Rscript'
        r_bin = f'"{tool_path}"' if tool_path else "Rscript"
        
        for pkg in set(pkgs):
            # Logic: 
            # 1. Create a user-writable library directory if it doesn't exist
            # 2. Tell R to install the package there
            r_cmd = (
                f"dir.create(Sys.getenv('R_LIBS_USER'), showWarnings=FALSE, recursive=TRUE); "
                f".libPaths(Sys.getenv('R_LIBS_USER')); "
                f"if(!require('{pkg}')) install.packages('{pkg}', repos='https://cloud.r-project.org', lib=.libPaths()[1])"
            )
            
            # Wrap in quotes for shell execution
            full_cmd = f'{r_bin} -e "{r_cmd}"'
            subprocess.call(full_cmd, shell=True)
            
        ui.print("[bold green]>> R environment synchronized (User Library).[/bold green]")

def _ensure_node_deps(file_path: str, tool_path: str = None):
    import subprocess
    from nova_cli.local.ui import ui
    if not os.path.exists("package.json"):
        ui.print(f"[dim]>> Pre-scanning Node dependencies for {os.path.basename(file_path)}...[/dim]")
        with open(file_path, "r", encoding="utf-8") as f:
            content = f.read()
        mods = re.findall(r"(?:import|require)\s*\(?\s*['\"]([\w\d\.\-\/]+)['\"]", content)
        if mods:
            ui.print(f"[bold cyan]>> Environment Check: Installing npm modules...[/bold cyan]")
            # Use npm.cmd on Windows for better resolution
            npm_bin = "npm.cmd" if os.name == "nt" else "npm"
            subprocess.call(f"{npm_bin} install " + " ".join(set(mods)), shell=True)