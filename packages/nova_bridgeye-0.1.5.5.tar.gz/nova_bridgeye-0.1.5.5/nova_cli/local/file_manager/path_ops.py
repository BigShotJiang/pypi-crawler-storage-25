import os
from nova_cli.local.file_manager.git_ops import repo


def validate_path(filepath: str) -> str:
    """
    Security Barrier: Ensures the target path is within the established PROJECT_ROOT.
    Prevents directory traversal attacks.
    """
    from nova_cli import config as cli_config
    
    # Boundary is defined by the current set PROJECT_ROOT
    root_boundary = cli_config.PROJECT_ROOT
    target = os.path.abspath(filepath)

    if os.path.commonpath([root_boundary, target]) != root_boundary:
        raise PermissionError(
            f"Access Denied: Operating outside of restricted root: {root_boundary}"
        )

    return target


def resolve_path(filepath: str) -> str:
    """
    Resolves a filepath. 
    1. Prioritizes the current working directory (CWD).
    2. If not found in CWD, searches relative to the Git Root.
    3. Defaults to CWD absolute path for new files.
    """
    # Normalize path separators
    filepath = filepath.replace("\\", "/")
    
    # 1. Check relative to current working directory (exact path first)
    cwd_path = os.path.abspath(filepath)
    if os.path.exists(cwd_path) and os.path.isfile(cwd_path):
        return cwd_path

    # 1.5 Handle AI hallucinating the project root folder name in the path
    cwd_basename = os.path.basename(os.path.abspath(os.getcwd()))
    if filepath.startswith(cwd_basename + "/") or filepath.startswith(cwd_basename + "\\"):
        stripped_path = filepath[len(cwd_basename) + 1:]
        test_path = os.path.abspath(stripped_path)
        if os.path.exists(test_path) and os.path.isfile(test_path):
            return test_path

    # 2. Check relative to Git Root (only if file exists there)
    # This helps find files if the AI uses root-relative paths while we are in a subfolder.
    if repo and repo.working_dir:
        root_path = os.path.abspath(os.path.join(repo.working_dir, filepath))
        if os.path.exists(root_path):
            return root_path

    # 3. Fallback: Return path relative to CWD (for new file creation)
    return cwd_path
