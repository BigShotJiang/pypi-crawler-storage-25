import os
from nova_cli.local.utils import check_syntax
from nova_cli.local.file_manager.path_ops import resolve_path, validate_path

def normalize_line(line: str) -> str:
    """Removes all whitespace and lowercases to create a comparison fingerprint."""
    return "".join(line.split()).lower()


def fuzzy_replace(content: str, search_block: str, replace_block: str, strict: bool = True) -> tuple[bool, str]:
    """
    Advanced fuzzy matcher that ignores leading/trailing whitespace and empty lines.
    If strict=False, it aggressively strips ALL internal whitespace and case differences.
    It finds the logical match and applies the replacement while attempting to
    preserve the original file's relative indentation.
    """
    import re
    content_lines = content.splitlines()
    # Filter out empty lines from search to handle AI omissions
    search_lines_raw = [l for l in search_block.strip().splitlines() if l.strip()]
    if not search_lines_raw:
        return False, content
    
    if strict:
        search_lines_norm = [l.strip() for l in search_lines_raw]
    else:
        # Aggressively remove all spaces, tabs, and standardize to lowercase
        search_lines_norm = [re.sub(r'\s+', '', l).lower() for l in search_lines_raw]
    
    # We create a map of content lines that are NOT empty
    content_map = [] # list of (original_index, normalized_text)
    for idx, line in enumerate(content_lines):
        if line.strip():
            if strict:
                content_map.append((idx, line.strip()))
            else:
                content_map.append((idx, re.sub(r'\s+', '', line).lower()))
            
    search_len = len(search_lines_norm)
    match_start_in_map = -1
    
    for i in range(len(content_map) - search_len + 1):
        # Compare normalized segments
        if [pair[1] for pair in content_map[i : i + search_len]] == search_lines_norm:
            match_start_in_map = i
            break
            
    if match_start_in_map == -1:
        return False, content

    # Get the actual line indices in the original file
    start_line_idx = content_map[match_start_in_map][0]
    end_line_idx = content_map[match_start_in_map + search_len - 1][0]
    
    # Capture original indentation from the first matched line
    first_line = content_lines[start_line_idx]
    indentation = first_line[:len(first_line) - len(first_line.lstrip())]
    
    # Prepare replacement with correct relative indentation
    replace_lines_raw = replace_block.splitlines()
    replacement_lines = []
    if replace_lines_raw:
        first_replace_line = next((l for l in replace_lines_raw if l.strip()), "")
        ai_indentation = first_replace_line[:len(first_replace_line) - len(first_replace_line.lstrip())]
        
        for l in replace_lines_raw:
            if not l.strip():
                replacement_lines.append(l)
            else:
                if l.startswith(ai_indentation):
                    replacement_lines.append(indentation + l[len(ai_indentation):])
                else:
                    replacement_lines.append(indentation + l.lstrip())
    
    new_lines = content_lines[:start_line_idx] + replacement_lines + content_lines[end_line_idx + 1:]
    return True, "\n".join(new_lines) + "\n"


def apply_surgical_edit(filepath: str, search_block: str, replace_block: str) -> bool:
    """
    Reads file, finds search_block, replaces with replace_block.
    Supports exact match and fuzzy match (whitespace insensitive).
    Performs syntax check before saving.
    """
    # LOCAL IMPORTS to break circular dependency
    from nova_cli.local.ui import ui
    from nova_cli.local.file_manager.git_ops import commit_changes

    full_path = filepath 
    
    if not os.path.isabs(full_path):
        try:
            full_path = validate_path(resolve_path(filepath))
        except Exception:
            full_path = os.path.abspath(filepath)

    if not os.path.exists(full_path):
        ui.print(f"[red]>> Edit Failed: File not found {filepath}[/red]")
        return False

    with open(full_path, "r", encoding="utf-8") as f:
        content = f.read()

    search_block_norm = search_block.replace("\r\n", "\n")
    content_norm = content.replace("\r\n", "\n")

    new_content = None
    method_used = ""

    # Normalize internal line endings and trailing whitespace for a fairer comparison
    search_stripped = "\n".join([l.rstrip() for l in search_block_norm.strip().splitlines()])
    content_stripped = "\n".join([l.rstrip() for l in content_norm.splitlines()])

    # Pass 1: Try Exact Match (Fastest)
    if search_block_norm.strip() in content_norm:
        new_content = content_norm.replace(search_block_norm.strip(), replace_block.strip())
        method_used = "Exact Match"
    
    # Pass 2: Line-by-Line Normalization Match (Resilient to trailing spaces)
    if not new_content:
        search_lines = [l.rstrip() for l in search_block_norm.strip().splitlines()]
        content_lines = [l.rstrip() for l in content_norm.splitlines()]
        
        for i in range(len(content_lines) - len(search_lines) + 1):
            if content_lines[i : i + len(search_lines)] == search_lines:
                orig_lines = content_norm.splitlines()
                reconstructed = orig_lines[:i] + replace_block.strip().splitlines() + orig_lines[i + len(search_lines):]
                new_content = "\n".join(reconstructed) + "\n"
                method_used = "Line-Normalized Match"
                break

    # Pass 3: Indentation-Insensitive Fuzzy Match
    if not new_content:
        success, fuzzy_content = fuzzy_replace(content_norm, search_block_norm, replace_block, strict=True)
        if success:
            new_content = fuzzy_content
            method_used = "Indentation-Insensitive Match"

    try:
        display_name = os.path.relpath(filepath).replace("\\", "/")
    except Exception:
        display_name = os.path.basename(filepath)

    if not new_content:
        # Pass 4: Ultra-Robust Fuzzy Match (Ignores internal spaces & case)
        success, fuzzy_content = fuzzy_replace(content_norm, search_block_norm, replace_block.strip(), strict=False)
        if success:
            new_content = fuzzy_content
            method_used = "Ultra-Robust Match"
        else:
            ui.print(f"[red]>> Edit Failed: SEARCH block not found in {display_name}[/red]")
            ui.print("[dim]   (Tip: The AI might have hallucinated indentation or spacing. Check file content.)[/dim]")
            return False

    is_valid, syntax_error = check_syntax(new_content, full_path)
    if not is_valid:
        ui.print("[bold red]>> Edit Rejected: Resulting code has Syntax Error.[/bold red]")
        ui.print(f"[red]>> {syntax_error}[/red]")
        return False

    with open(full_path, "w", encoding="utf-8") as f:
        f.write(new_content)

    ui.print(f"[green]>> Surgical Edit Applied ({method_used}): {display_name}[/green]")
        
    # Force Git sync for discovered files to maintain repo integrity
    from nova_cli.local.file_manager.git_ops import commit_changes
    commit_changes(f"Surgical edit: {display_name}", full_path, use_semantic=True)
    return True