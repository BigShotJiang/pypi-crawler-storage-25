# NOVA_CLI/nova_cli/local/file_manager/git_ops.py

import os
from pathlib import Path

import git

from nova_cli import config

from nova_cli.nova_core.ai.api_client import BridgeyeAPIClient

# --- GIT INTEGRATION ---
repo_path: Path = Path(os.getcwd())
repo: git.Repo | None = None


def _default_commit_message() -> str:
    return "chore: update files"

def get_repo():
    """Lazily load the repo only when needed."""
    global repo
    try:
        # Check if current dir or any parent is a git repo
        repo = git.Repo(os.getcwd(), search_parent_directories=True)
        return repo
    except (git.exc.InvalidGitRepositoryError, git.exc.NoSuchPathError):
        repo = None
        return None

def _get_origin_url(r) -> str | None:
    try:
        if "origin" in r.remotes:
            return next(r.remotes.origin.urls, None)
    except Exception:
        pass
    return None
    
def initialize_repo() -> bool:
    from nova_cli.local.ui import ui
    global repo
    try:
        repo = git.Repo.init(os.getcwd())
        
        # PRO MOVE: Create a default .gitignore if it doesn't exist
        gitignore_path = os.path.join(os.getcwd(), ".gitignore")
        if not os.path.exists(gitignore_path):
            with open(gitignore_path, "w") as f:
                f.write(".nova_history\n__pycache__/\n*.pyc\n.env\n")
        
        ui.print("[green]✔ Git repository initialized with default .gitignore.[/green]")
        return True
    except Exception as e:
        ui.print(f"[red]Failed to initialize Git: {e}[/red]")
        return False

def update_repo_path(new_path: str) -> None:
    """Updates the repo object when user CDs without forcing init."""
    global repo, repo_path
    repo_path = Path(new_path)
    repo = get_repo()

def commit_changes(message: str, filepath: str | None = None, use_semantic: bool = False) -> bool:
    from nova_cli.local.ui import ui
    r = get_repo()
    
    # 1. Respect Auto-Commit Toggle
    if not r or not config.GIT_AUTO_COMMIT:
        return False

    try:
        # 2. Stage changes
        if filepath and os.path.exists(filepath):
            r.git.add(filepath)
        else:
            # Stage all modified and deleted files
            r.git.add(update=True)

        # 3. Check for staged changes (Robust check for initial & existing repos)
        has_staged_changes = False
        try:
            # If HEAD exists, diff against it
            if r.index.diff("HEAD"):
                has_staged_changes = True
        except git.exc.BadName:
            # HEAD doesn't exist (Initial Commit) - check if index is not empty
            if len(r.index.entries) > 0:
                has_staged_changes = True

        if has_staged_changes:
            final_msg = f"NOVA: {message}"
            if use_semantic and filepath:
                final_msg = f"chore: update {os.path.basename(filepath)}"

            r.index.commit(final_msg)
            ui.print(f"[dim]>> Auto-Commit: {final_msg}[/dim]")

            # 4. Respect Auto-Push Toggle (Chained)
            if config.GIT_AUTO_PUSH:
                perform_push()
            return True

    except Exception as e:
        ui.print(f"[yellow]>> Git Auto-Commit Error: {e}[/yellow]")

    return False


def manual_commit(model: str | None = None, provider: str | None = None) -> bool:
    """Forces a commit with an option for AI generation or manual input."""
    from nova_cli.local.ui import ui
    import questionary
    
    r = get_repo()
    if not r:
        ui.print("[yellow]>> Not a git repository. Use ':gitoptions' to initialize.[/yellow]")
        return False

    try:
        r.git.add(".")
        # Robust check for changes
        has_changes = False
        try:
            if r.is_dirty(untracked_files=True) or r.index.diff("HEAD"):
                has_changes = True
        except git.exc.BadName:
            if len(r.index.entries) > 0:
                has_changes = True

        if not has_changes:
            ui.print("[dim]>> Nothing to commit (clean working tree).[/dim]")
            return False

        ui.print("[dim]>> Detected changes to commit.[/dim]")
        choice = questionary.select(
            "Choose commit message option:",
            choices=[
                "🤖 Auto-generate commit message",
                "✍️  Enter manually",
            ],
        ).ask()

        if not choice:
            ui.print("[red]>> Commit cancelled.[/red]")
            return False

        commit_msg = None
        if "Auto-generate" in choice:
            try:
                ui.print("[dim cyan]>> Generating commit message...[/dim cyan]")
                diff = r.git.diff(cached=True) or r.git.diff() # Check staged then unstaged

                client = BridgeyeAPIClient()
                commit_msg = client.generate_commit_message(
                    diff_text=diff,
                    model=model or config.DEFAULT_MODEL,
                    provider=provider or "openrouter",
                )
                if not commit_msg.strip():
                    commit_msg = _default_commit_message()
                ui.print(f"[dim]>> AI Commit: {commit_msg}[/dim]")
            except Exception as e:
                ui.print(f"[yellow]>> AI generation failed: {e}[/yellow]")
                commit_msg = _default_commit_message()
        else:
            commit_msg = ui.input("[cyan]Enter commit message:[/cyan] ").strip()
            if not commit_msg:
                commit_msg = _default_commit_message()

        r.index.commit(f"NOVA: {commit_msg}")
        ui.print(f"[green]>> Commit Success: {commit_msg}[/green]")
        return True

    except Exception as e:
        ui.print(f"[red]>> Commit Failed: {e}[/red]")
        return False


def perform_push(model: str | None = None, provider: str | None = None) -> None:
    from nova_cli.local.ui import ui
    import questionary

    r = get_repo()
    if not r:
        ui.print("[yellow]>> No repository found to push.[/yellow]")
        return

    if not ensure_git_identity(r):
        return

    try:
        # ----------------------------
        # STEP 1: Ensure changes are committed
        # ----------------------------
        manual_commit(model=model, provider=provider)

        # ----------------------------
        # STEP 2: Ensure remote exists
        # ----------------------------
        if not ensure_remote_origin(r):
            return

        # ----------------------------
        # STEP 3: Push
        # ----------------------------
        ui.print("[dim]>> Pushing to origin...[/dim]")
        try:
            branch = r.active_branch.name
            r.git.push("--set-upstream", "origin", branch)
        except Exception:
            r.remotes.origin.push()

        ui.print("[green]>> Push Complete.[/green]")
        origin_url = _get_origin_url(r)
        if origin_url:
            ui.print(f"[dim]>> Remote:[/dim] {origin_url}")

    except Exception as e:
        ui.print(f"[red]>> Push Failed: {e}[/red]")


def perform_pull() -> None:
    from nova_cli.local.ui import ui
    import questionary

    r = get_repo()

    if not r:
        choice = questionary.select(
            "This folder is not a git repository. What would you like to do?",
            choices=[
                "📦 Initialize repository and continue",
                "❌ Cancel",
            ],
        ).ask()

        if not choice or "Cancel" in choice:
            ui.print("[red]>> Pull cancelled.[/red]")
            return

        if not initialize_repo():
            return

        r = get_repo()
        if not r:
            ui.print("[red]>> Failed to initialize repository.[/red]")
            return

    try:
        # 1. Ensure remote exists first
        if not ensure_remote_for_pull(r):
            return

        # 2. Fetch first
        ui.print("[dim]>> Fetching from origin...[/dim]")
        r.remotes.origin.fetch()

        # 3. Warn only now, right before actual pull/checkout
        if r.is_dirty(untracked_files=True):
            ui.print("[yellow]>> You have local changes. Pull may cause conflicts.[/yellow]")

            choice = questionary.select(
                "How would you like to continue?",
                choices=[
                    "⬇️ Continue pull",
                    "🧨 Force sync with origin",
                    "❌ Cancel",
                ],
            ).ask()

            if not choice or "Cancel" in choice:
                ui.print("[red]>> Pull cancelled.[/red]")
                return

            if "Force sync" in choice:
                force_sync_with_origin()
                return

        # 4. Normal pull path
        try:
            branch = r.active_branch.name
            ui.print(f"[dim]>> Pulling branch '{branch}' from origin...[/dim]")
            r.git.pull("origin", branch)
            ui.print("[green]>> Pull Complete.[/green]")

            origin_url = _get_origin_url(r)
            if origin_url:
                ui.print(f"[dim]>> Remote:[/dim] {origin_url}")
            return

        except Exception:
            pass

        # 5. Fallback for fresh repos with no checked-out branch yet
        remote_head = None
        try:
            remote_head = r.git.symbolic_ref("refs/remotes/origin/HEAD")
            remote_head = remote_head.split("/")[-1].strip()
        except Exception:
            pass

        if not remote_head:
            for candidate in ("main", "master"):
                try:
                    r.git.rev_parse(f"origin/{candidate}")
                    remote_head = candidate
                    break
                except Exception:
                    continue

        if not remote_head:
            ui.print("[red]>> Could not determine remote default branch.[/red]")
            return

        ui.print(f"[dim]>> Checking out '{remote_head}' from origin...[/dim]")
        try:
            r.git.checkout("-b", remote_head, f"origin/{remote_head}")
        except Exception:
            r.git.checkout(remote_head)

        ui.print("[green]>> Pull Complete.[/green]")

        origin_url = _get_origin_url(r)
        if origin_url:
            ui.print(f"[dim]>> Remote:[/dim] {origin_url}")

    except Exception as e:
        ui.print(f"[red]>> Pull Failed: {e}")


def git_status() -> None:
    from nova_cli.local.ui import ui
    r = get_repo()
    if not r:
        ui.print("[dim]>> Not a git repository.[/dim]")
        return
    try:
        origin_url = _get_origin_url(r)
        if origin_url:
            ui.print(f"[dim]Remote:[/dim] {origin_url}")

        if r.is_dirty(untracked_files=True):
            ui.print(f"[yellow]{r.git.status()}[/yellow]")
        else:
            ui.print("[green]Git Status: Clean working tree.[/green]")
    except Exception as e:
        ui.print(f"[red]{e}[/red]")

def ensure_git_identity(r) -> bool:
    from nova_cli.local.ui import ui

    try:
        name = r.config_reader().get_value("user", "name")
        email = r.config_reader().get_value("user", "email")
        if name and email:
            return True
    except Exception:
        pass

    ui.print("[yellow]>> Git user identity not configured.[/yellow]")

    name = ui.input("[cyan]Enter your Git username:[/cyan] ").strip()
    email = ui.input("[cyan]Enter your Git email:[/cyan] ").strip()

    if not name or not email:
        ui.print("[red]>> Git identity setup cancelled.[/red]")
        return False

    r.config_writer().set_value("user", "name", name).release()
    r.config_writer().set_value("user", "email", email).release()

    ui.print("[green]>> Git identity configured.[/green]")
    return True
    
def ensure_remote_origin(r) -> bool:
    from nova_cli.local.ui import ui
    import questionary

    if "origin" in r.remotes:
        return True

    ui.print("[yellow]>> No remote 'origin' found.[/yellow]")

    choice = questionary.select(
        "How would you like to set up remote?",
        choices=[
            "🔗 Use existing repository URL",
            "🆕 Create new GitHub repository (recommended)",
        ],
    ).ask()

    if not choice:
        ui.print("[red]>> Remote setup cancelled.[/red]")
        return False

    if "existing" in choice:
        repo_url = ui.input("[cyan]Enter remote repository URL:[/cyan] ").strip()
        if not repo_url:
            ui.print("[red]>> Cancelled.[/red]")
            return False

    else:
        repo_name = ui.input("[cyan]Enter new repository name:[/cyan] ").strip()
        if not repo_name:
            ui.print("[red]>> Cancelled.[/red]")
            return False

        is_private = questionary.select(
            "Choose repository visibility:",
            choices=[
                "🔒 Private",
                "🌍 Public",
            ],
            default="🔒 Private",
        ).ask()

        if not is_private:
            ui.print("[red]>> Repository creation cancelled.[/red]")
            return False

        private_flag = is_private.startswith("🔒")

        ui.print("[dim]>> Creating GitHub repository...[/dim]")

        try:
            client = BridgeyeAPIClient()
            result = client.create_github_repo(
                repo_name=repo_name,
                private=private_flag,
                description="Created via NOVA CLI",
            )

            repo_url = (result.get("clone_url") or "").strip()
            if not repo_url:
                raise RuntimeError("GitHub repo created but clone_url missing")

            visibility = "private" if private_flag else "public"
            ui.print(f"[green]>> GitHub {visibility} repo created: {result.get('html_url')}[/green]")

        except Exception as e:
            msg = str(e)
            if "already exists" in msg.lower() or "name already exists" in msg.lower():
                ui.print("[red]>> Repository with this name already exists on GitHub. Try another name.[/red]")
            else:
                ui.print(f"[red]>> Failed to create GitHub repo: {e}[/red]")
            return False
    

    try:
        r.create_remote("origin", repo_url)
        ui.print(f"[green]>> Remote added: {repo_url}[/green]")
        return True
    except Exception as e:
        ui.print(f"[red]>> Failed to add remote: {e}[/red]")
        return False

def ensure_remote_for_pull(r) -> bool:
    from nova_cli.local.ui import ui

    if "origin" in r.remotes:
        return True

    ui.print("[yellow]>> No remote 'origin' found.[/yellow]")
    repo_url = ui.input("[cyan]Enter existing repository URL to pull from:[/cyan] ").strip()

    if not repo_url:
        ui.print("[red]>> Pull cancelled.[/red]")
        return False

    try:
        r.create_remote("origin", repo_url)
        ui.print(f"[green]>> Remote added: {repo_url}[/green]")
        return True
    except Exception as e:
        ui.print(f"[red]>> Failed to add remote: {e}[/red]")
        return False 

def force_sync_with_origin() -> None:
    from nova_cli.local.ui import ui
    import questionary

    r = get_repo()
    if not r:
        ui.print("[yellow]>> Not a git repository.[/yellow]")
        return

    if not ensure_remote_for_pull(r):
        return

    confirm = questionary.confirm(
        "This will discard local changes and hard reset to the remote branch. Continue?",
        default=False,
    ).ask()

    if not confirm:
        ui.print("[red]>> Force sync cancelled.[/red]")
        return

    try:
        ui.print("[dim]>> Fetching from origin...[/dim]")
        r.remotes.origin.fetch()

        branch = None
        try:
            branch = r.active_branch.name
        except Exception:
            pass

        if not branch:
            for candidate in ("main", "master"):
                try:
                    r.git.rev_parse(f"origin/{candidate}")
                    branch = candidate
                    break
                except Exception:
                    continue

        if not branch:
            ui.print("[red]>> Could not determine remote branch for force sync.[/red]")
            return

        ui.print(f"[dim]>> Resetting hard to origin/{branch}...[/dim]")
        r.git.reset("--hard", f"origin/{branch}")
        ui.print("[green]>> Force sync complete.[/green]")

        origin_url = _get_origin_url(r)
        if origin_url:
            ui.print(f"[dim]>> Remote:[/dim] {origin_url}")

    except Exception as e:
        ui.print(f"[red]>> Force sync failed: {e}[/red]")       