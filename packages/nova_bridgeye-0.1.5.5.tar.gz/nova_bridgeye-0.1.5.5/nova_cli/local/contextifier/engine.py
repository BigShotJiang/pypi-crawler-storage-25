import os

IGNORE_DIRS = {
    ".git", "node_modules", "dist", "build", ".vscode", 
    "__pycache__", ".idea", "venv", ".venv", "env", ".env", 
    ".dart_tool", ".pub-cache", ".pytest_cache", ".mypy_cache", ".venv_obf",
    ".venv_build", "release", "obf", "pyarmor_runtime_000000", "pkg_root",
    "assets", ".nova", "project_context.txt"
}

IGNORE_EXTENSIONS = {
    ".png", ".jpg", ".jpeg", ".gif", ".ico", ".svg", ".webp", ".pdf", 
    ".lock", ".log", ".zip", ".tar", ".gz", ".DS_Store", ".pyc",
    ".arb", ".exe", ".bin", ".dll", ".so", ".dylib", ".class", ".csv", ".xlsx", ".JSON"
}

IGNORE_FILES = {
    "project_context.txt",
    "PLAN.md"
}

def is_binary_file(filepath, chunk_size=1024):
    try:
        with open(filepath, 'rb') as f:
            chunk = f.read(chunk_size)
            if b'\0' in chunk:
                return True
        return False
    except Exception:
        return True

def generate_tree(startpath, ignore_dirs):
    tree_lines = []
    for root, dirs, files in os.walk(startpath, topdown=True):
        dirs[:] = [d for d in dirs if d not in ignore_dirs]
        level = root.replace(startpath, '').count(os.sep)
        indent = ' ' * 4 * level
        folder_name = os.path.basename(root)
        if folder_name == '': folder_name = "."
        tree_lines.append(f"{indent}{folder_name}/")
        subindent = ' ' * 4 * (level + 1)
        for f in sorted(files):
            if f in IGNORE_FILES or any(f.endswith(ext) for ext in IGNORE_EXTENSIONS):
                continue
            tree_lines.append(f"{subindent}{f}")
    return "\n".join(tree_lines)

def run_contextify(start_dir='.', verbose_callback=None, save_to_disk=False) -> dict[str, str]:
    """
    Analyzes the project and returns a dictionary of {relative_path: content}
    for all valid files, following the Contextify exclusion logic.
    """
    context_data = {}
    output_buffer = []

    # Tree Section
    if save_to_disk:
        output_buffer.append("Project file structure:\n=======================\n")
        output_buffer.append(generate_tree(start_dir, IGNORE_DIRS))
        output_buffer.append("\n\n\nFile Contents:\n===============\n")

    for root, dirs, files in os.walk(start_dir, topdown=True):
        # Filter directories in-place
        dirs[:] = [d for d in dirs if d not in IGNORE_DIRS]
        
        for file in sorted(files):
            if file in IGNORE_FILES or any(file.endswith(ext) for ext in IGNORE_EXTENSIONS):
                continue

            file_path = os.path.join(root, file)
            relative_path = os.path.relpath(file_path, start_dir).replace(os.sep, '/')

            if is_binary_file(file_path):
                continue

            try:
                if verbose_callback:
                    verbose_callback(relative_path)
                with open(file_path, "r", encoding="utf-8", errors="ignore") as infile:
                    content = infile.read()
                    context_data[relative_path] = content
                    if save_to_disk:
                        output_buffer.append(f"\n\n--- FILE: {relative_path} ---\n\n")
                        output_buffer.append(content)
            except Exception:
                continue

    if save_to_disk:
        with open("project_context.txt", "w", encoding="utf-8") as f:
            f.write("".join(output_buffer))

    return context_data