
import logging
import os
import shlex
import signal
import sys
import time

import core.state as state
import core.prompts as prompts
from nova_cli import config
from nova_cli.cli.commands import register_core_commands
from nova_cli.cli.registry import CommandRegistry

from nova_cli.cli.shell_parts.ai_logic import ShellAILogicMixin
from nova_cli.cli.shell_parts.handlers import ShellHandlersMixin
from nova_cli.cli.shell_parts.ui_utils import ShellUIUtilsMixin

from nova_cli.local.ui import ui
from nova_cli.local.healer.runner import run_with_healing


class NovaShell(ShellHandlersMixin, ShellUIUtilsMixin, ShellAILogicMixin):
    def __init__(self):
        # --- CONFIGURE LOGGING (File only, no Console) ---
        logging.basicConfig(
            filename='nova.log',
            level=logging.INFO,
            format='%(asctime)s - %(levelname)s - %(message)s'
        )
        # Prevent logs from propagating to the console (stderr)
        logging.getLogger().propagate = False
        for handler in logging.root.handlers[:]:
            if not isinstance(handler, logging.FileHandler):
                logging.root.removeHandler(handler)

        # --- STRICT RED-LOADER SHUTDOWN HANDLER ---
        def force_quit(signum, frame):
            sys.stdout.write("\r") # Clear current prompt line
            # Use the interface console directly for a clean, red status
            with self.interface.console.status("[bold red]STRICT SHUTDOWN: Terminating all processes...", spinner="line", spinner_style="red"):
                time.sleep(0.8) # Brief pause so the user sees the red loader
            os._exit(0)
            
        signal.signal(signal.SIGINT, force_quit)

        self.state = state.SessionState()
        self.interface = ui

        # API-only mode (no local model client)
        self.groq_client = None
        self.chat_session = None
        self.context_loader = None

        # Configuration
        self.provider = config.DEFAULT_PROVIDER
        self.model_name = config.DEFAULT_MODEL

        # Command Registry
        self.registry = CommandRegistry()
        register_core_commands(self.registry, self)
        
        # --- PROMPT TOOLKIT SETUP (Replaces Readline for perfect scrolling/wrapping) ---
        self.history_file = os.path.expanduser("~/.nova_history")
        
        from prompt_toolkit import PromptSession
        from prompt_toolkit.history import FileHistory
        from prompt_toolkit.completion import Completer, Completion
        
        class NovaCompleter(Completer):
            def __init__(self, registry):
                self.registry = registry

            def get_completions(self, document, complete_event):
                text = document.text_before_cursor
                if " " not in text:
                    for cmd in self.registry.all().keys():
                        if cmd.startswith(text):
                            yield Completion(cmd, start_position=-len(text))
                else:
                    import glob
                    word = text.split(" ")[-1]
                    matches = glob.glob(word + "*")
                    for m in matches:
                        display = m + ("/" if os.path.isdir(m) else "")
                        yield Completion(display, start_position=-len(word))
                        
        self.prompt_session = PromptSession(
            history=FileHistory(self.history_file),
            completer=NovaCompleter(self.registry)
        )
        
        # Load any interrupted build state from disk
        self.state.load_build_state()

    def get_prompt_text(self):
        prefix = ""
        if self.state.active_file:
            prefix = f"[dim]({os.path.basename(self.state.active_file)})[/dim] "
        if len(self.state.loaded_files) > 0:
            prefix += f"[dim][{len(self.state.loaded_files)} loaded][/dim] "
        
        # Color changes to RED in overdrive mode
        prompt_color = "bold red" if config.OVERDRIVE else "bold cyan"
        overdrive_indicator = "[bold red]O[/bold red] " if config.OVERDRIVE else ""
        
        return f"{prefix}{overdrive_indicator}[{prompt_color}]spark terminal >[/{prompt_color}]  "


    # --- COMMAND HANDLERS ---

    def run(self):
        self.interface.clear()
        logging.info(f"Session started in {config.PROJECT_ROOT}")

        # Simple non-interactive entry
        if len(sys.argv) > 1:
            cmd = sys.argv[1]
            args = sys.argv[2:] if len(sys.argv) > 2 else []

            if cmd == "run":
                if args:
                    try:
                        output = run_with_healing(
                            command_args=args,
                            cwd=os.getcwd(),
                            model=self.model_name,
                            provider=self.provider,
                            context=self.state.loaded_files,
                            repo_map=prompts.get_repo_map_cached(os.getcwd()),
                        )
                        if output and output != "SUCCESS_SIGNAL":
                            print(output)
                    except Exception as e:
                        print(f"Healer Error: {e}")
                    return
                print("Usage: nova run <command>")
                return

            if cmd == "clean":
                # in non-interactive mode, clean requires loaded context; keep it simple for now
                print("Use interactive mode for clean (load files first).")
                return

            if cmd.lower() == "build":
                self.cmd_build_it(args)
                return

        self.interface.display_header(self.model_name, os.getcwd())
        from nova_cli.nova_core.auth.storage import is_logged_in
        self.interface.display_startup_hint(is_logged_in())

        from prompt_toolkit.formatted_text import ANSI
        
        while True:
            try:
                # Capture Rich formatted prompt to pass into PromptSession
                with self.interface.console.capture() as cap:
                    self.interface.console.print(self.get_prompt_text(), end="")
                
                cmd_raw = self.prompt_session.prompt(ANSI(cap.get())).strip()
                if not cmd_raw:
                    continue

                try:
                    parts = shlex.split(cmd_raw)
                except ValueError:
                    # Fallback for natural language containing unbalanced quotes (e.g. "How're you?")
                    parts = cmd_raw.split()

                cmd_base = parts[0]
                # FIX: We pass the raw parts[1:] list to handlers that support it, 
                # or the correctly escaped string to others.
                args = " ".join(shlex.quote(p) for p in parts[1:]) if len(parts) > 1 else ""

                ai_prompt = None

                handler = self.registry.get(cmd_base)

                if handler:
                    # Pass the joined but safely quoted string to the handler
                    result = handler(args)
                    if result == "EXIT":
                        break
                    if isinstance(result, str):
                        ai_prompt = result
                else:
                    ai_prompt = cmd_raw

                if ai_prompt:
                    # 1. Determine Intent
                    intent = self._get_nlp_intent(ai_prompt)
                    plan_exists = os.path.exists(os.path.join(os.getcwd(), "PLAN.md"))

                    # 2. Strict Architect Gate: If no PLAN.md, force 'make/create' requests to PLAN
                    creation_keywords = ["make", "create", "build", "generate", "setup", "write a"]
                    is_creation_request = any(kw in ai_prompt.lower() for kw in creation_keywords)
                    
                    # WEB BUILDER INTERCEPT:
                    # Prevent general creation keywords ("make") from triggering PLAN if it's a web request
                    web_keywords = ["website", "landing page", "web page", "web site", "frontend", "react app", "html site", "portfolio site", "ecommerce site", "web app", "web based", "site"]
                    is_web_query = any(wk in ai_prompt.lower() for wk in web_keywords)
                    
                    # DATA ANALYSIS INTERCEPT:
                    # Prevent data analysis queries from triggering PLAN and entering the prompt enhancer
                    lower_p = ai_prompt.lower()
                    data_extensions = [".csv", ".xlsx", ".parquet", ".json"]
                    is_data_query = any(ext in lower_p for ext in data_extensions)
                    
                    # Catch natural language analysis requests even if the extension isn't explicitly typed
                    if not is_data_query and (("analyse" in lower_p or "analyze" in lower_p) and "data" in lower_p):
                        is_data_query = True
                        
                    config_files = ["package.json", "tsconfig.json", "composer.json", "package-lock.json"]
                    if any(cfg in lower_p for cfg in config_files):
                        remaining_p = lower_p
                        for cfg in config_files:
                            remaining_p = remaining_p.replace(cfg, "")
                        is_data_query = any(ext in remaining_p for ext in data_extensions)
                    
                    if is_web_query or is_data_query:
                        intent = "SKILLS"
                    elif not plan_exists and is_creation_request:
                        intent = "PLAN"
                    
                    # 3. Check for Enhancement Gate
                    if self.should_use_prompt_enhancer(ai_prompt, intent):
                        enhanced = self.run_prompt_enhancement_flow(ai_prompt)
                        if not enhanced:
                            continue # User cancelled
                        
                        # Set override to proceed to Architect Phase (PLAN.md creation)
                        ai_prompt = f"SYSTEM_OVERRIDE: Based on this approved plan, create the PLAN.md:\n{enhanced}"
                        self.handle_ai_request(ai_prompt, nlp_intent="PLAN")
                    else:
                        # Direct routing for BUILD, ANALYZE, EDIT, or existing PLAN intents
                        self.handle_ai_request(ai_prompt, nlp_intent=intent)

            except EOFError:
                with self.interface.console.status("[bold red]SHUTDOWN: Closing Nova...", spinner="line", spinner_style="red"):
                    time.sleep(0.5)
                break
