import logging
import os
import re
import shlex
import subprocess
import sys
import time

from core import prompts
from nova_cli import config
from nova_cli.local.contextifier.engine import run_contextify
from nova_cli.local.file_manager.commands import handle_ai_commands
from nova_cli.local.file_manager.git_ops import git_status, manual_commit, perform_pull, perform_push, update_repo_path
from nova_cli.local.file_manager.io_ops import load_file, map_directory, save_code_to_file
from nova_cli.local.file_manager.path_ops import resolve_path
from nova_cli.local.healer.runner import run_with_healing
from nova_cli.nova_core.ai.api_client import BridgeyeAPIClient
from nova_cli.nova_core.auth.client import NovaAuthClient
from nova_cli.nova_core.auth.storage import save_auth



class ShellHandlersMixin:
    def cmd_overdrive(self, args):
            # Handle both ":overdrive" (toggle) and ":exit overdrive" (off)
            if "overdrive" in args.lower() and "exit" in sys._getframe(1).f_locals.get('cmd_raw', ''):
                config.OVERDRIVE = False
            else:
                config.OVERDRIVE = not config.OVERDRIVE
                
            status = "[bold green]ENABLED[/bold green]" if config.OVERDRIVE else "[bold red]DISABLED[/bold red]"
            self.interface.print(f"[cyan]>> Overdrive Mode: {status}[/cyan]")

    def cmd_makeroot(self, args):
            config.PROJECT_ROOT = os.path.abspath(os.getcwd())
            self.interface.print(f"[bold yellow]>> Restricted Root Set:[/bold yellow] {config.PROJECT_ROOT}")
            self.interface.print("[dim]NOVA will no longer create or edit files outside this directory.[/dim]")

    def cmd_exitroot(self, args):
            config.PROJECT_ROOT = config.INITIAL_ROOT
            self.interface.print(f"[bold green]>> Root Restored to Initial Path:[/bold green] {config.PROJECT_ROOT}")

    def cmd_doctor(self, args):
            from nova_cli.cli.main import _doctor
            _doctor()

    def cmd_help(self, args):
            help_data = {
                "Build & Execute": {
                    "build / build it": "Execute the implementation steps in PLAN.md",
                    "continue": "Resume an interrupted build process",
                    "run <cmd>": "Run code with automated error healing",
                    "clean": "Trigger Janitor for style & formatting refactor"
                },
                "File & Context": {
                    "ls / :map": "View project blueprint (AST map)",
                    ":create [folder|file] <name>": "Create a folder or file instantly",
                    ":delete [folder|file] <name>": "Delete a folder or file safely",
                    ":load <path>": "Load file content into AI memory",
                    ":unload": "Clear specific or all files from context",
                    ":paste": "Provide multi-line logs or snippets",
                    "cd / pwd": "Navigate directories / Print current path"
                },
                "System & Auth": {
                    "login": "Authenticate your NOVA session",
                    ":model": "Switch AI reasoning/coding models",
                    ":gitoptions": "Git Automation (Commit/Push/Pull)",
                    ":overdrive": "Enable auto-confirm (Prompt turns RED)",
                    ":exit overdrive": "Disable auto-confirm mode",
                    ":makeroot": "Lock NOVA operations to current folder",
                    ":exitroot": "Release folder lock to initial root",
                    "reset / exit": "Clear session / Shutdown NOVA"
                }
            }
            self.interface.render_help_menu(help_data)

    def cmd_gitoptions(self, args):
            from nova_cli.local.file_manager.git_ops import initialize_repo
            
            while True:
                # Pass current state to UI for display
                choice = self.interface.show_git_options(config.GIT_AUTO_COMMIT, config.GIT_AUTO_PUSH)

                if choice == "Back":
                    break
                elif choice == "Initialize":
                    initialize_repo()
                elif choice == "Toggle Auto-Commit":
                    config.GIT_AUTO_COMMIT = not config.GIT_AUTO_COMMIT
                    status = "ENABLED" if config.GIT_AUTO_COMMIT else "DISABLED"
                    self.interface.print(f"[yellow]>> Auto-Commit: {status}[/yellow]")
                elif choice == "Toggle Auto-Push":
                    config.GIT_AUTO_PUSH = not config.GIT_AUTO_PUSH
                    status = "ENABLED" if config.GIT_AUTO_PUSH else "DISABLED"
                    self.interface.print(f"[yellow]>> Auto-Push: {status}[/yellow]")
                elif choice == "Manual Commit":
                    manual_commit(model=self.model_name, provider=self.provider)
                elif choice == "Push":
                    perform_push(model=self.model_name, provider=self.provider)
                elif choice == "Pull":
                    perform_pull()
                elif choice == "Force Sync":
                    from nova_cli.local.file_manager.git_ops import force_sync_with_origin
                    force_sync_with_origin()
                elif choice == "Git Status":
                    git_status()
                    self.interface.input("[dim]Press Enter to continue...[/dim]")

    def cmd_login(self, args):
            auth = NovaAuthClient()

            print("[cyan]Opening browser for authentication...[/cyan]")
            session_id = auth.create_session()
            auth.open_browser(session_id)

            print("[dim]Waiting for approval...[/dim]")

            auth_code = auth.poll_session(session_id)

            if not auth_code:
                print("[red]Login timed out.[/red]")
                return

            tokens = auth.exchange_auth_code(auth_code)

            if not tokens or tokens.get("error"):
                self.interface.print("\n[bold red]Verification failed.[/bold red]")
                self.interface.print("[cyan]Please login again. Give us two seconds while we verify you.[/cyan]")
                return


            tokens["issued_at"] = time.time()
            save_auth(tokens)

            self.interface.print("[bold green]Login successful! You are now authenticated.[/bold green]")
            self.interface.display_startup_hint()

    def cmd_model(self, args):
            new_model, new_provider = self.interface.show_model_selector(self.model_name)
            if new_model != self.model_name:
                self.model_name = new_model
                self.provider = new_provider
                logging.info(f"Switched model to {self.model_name}")
                self.interface.display_header(self.model_name, os.getcwd())

    def cmd_reset(self, args):
            self.state.reset()
            self.interface.clear()
            logging.info("Session reset")
            self.interface.display_header(self.model_name, os.getcwd())

    def cmd_unload(self, args):
            if not args:
                self.state.active_file = None
                self.state.loaded_files = {}
                self.state.loaded_paths = {}
                self.interface.print("[dim]  Unloaded all files.[/dim]")
            else:
                fname = args.replace('"', "").replace("'", "").strip()
                found_key = None
                for key in self.state.loaded_files.keys():
                    if key == fname or os.path.basename(key) == fname:
                        found_key = key
                        break

                if found_key:
                    del self.state.loaded_files[found_key]
                    if found_key in self.state.loaded_paths:
                        del self.state.loaded_paths[found_key]

                    self.interface.print(f"[dim]  Unloaded: {found_key}[/dim]")

                    if self.state.active_file and os.path.basename(self.state.active_file) == found_key:
                        self.state.active_file = None
                else:
                    self.interface.print(f"[red]  File '{fname}' is not currently loaded.[/red]")


    def cmd_map(self, args):
            """Triggers a recursive AST scan and displays the Project Blueprint."""
            prompts.clear_file_tree_cache()
            # 1. Visual Folder Tree
            map_directory()
            # 2. AST Blueprint (Project Map)
            self._step_start("Scanning project architecture...")
            blueprint = prompts.get_repo_map_cached(os.getcwd())
            self.interface.display_blueprint(blueprint)

    def cmd_wizard(self, args):
            self.interface.print("[yellow]Wizard is not available in API-only CLI mode yet.[/yellow]")

    def cmd_apply(self, args):
            save_code_to_file(self.state.active_file, self.state.last_generated_code)

    def cmd_cd(self, args):
            if not args:
                return
            try:
                target_path = os.path.abspath(args)
                
                # Security Barrier: check against global PROJECT_ROOT using commonpath
                if os.path.commonpath([config.PROJECT_ROOT, target_path]) != config.PROJECT_ROOT:
                    self.interface.print("[bold red]SECURITY ALERT:[/bold red] You are in sticky root. To disable it, use :exitroot")
                    logging.warning(f"Access denied: {target_path}")
                    return

                os.chdir(target_path)
                self.interface.print(f"[dim]  cwd: {os.getcwd()}[/dim]")
                if os.path.exists(os.path.join(os.getcwd(), ".git")):
                    update_repo_path(os.getcwd())
            except Exception as e:
                self.interface.print(f"[red]{e}[/red]")

    def cmd_pwd(self, args):
            self.interface.print(f"[dim]{os.getcwd()}[/dim]")

    def cmd_build_it(self, args):
            plan_path = os.path.join(os.getcwd(), "PLAN.md")
            if not os.path.exists(plan_path):
                if not args:
                    # No args + no PLAN.md: prompt inline rather than dead-end
                    self.interface.print("[yellow]No PLAN.md found.[/yellow]")
                    description = self.interface.input("[cyan]What do you want to build? > [/cyan]").strip()
                    if not description:
                        self.interface.print("[dim]Cancelled.[/dim]")
                        return
                    self.interface.print("[cyan]>> Rerouting to Architect & Planning Phase...[/cyan]")
                    # "Create ..." guarantees PLAN classification; triggers enhancer → PLAN.md
                    return f"Create {description}"

                self.interface.print("[cyan]>> No PLAN.md found. Rerouting to Architect & Planning Phase...[/cyan]")
                # Returning a string delegates to the AI loop.
                # Prefix with "Create" to guarantee PLAN classification.
                return f"Create {args}"

            try:
                with open(plan_path, "r", encoding="utf-8") as f:
                    plan_content = f.read()
            except Exception as e:
                self.interface.print(f"[red]Failed to read PLAN.md: {e}[/red]")
                return

            self._step_start("Contextifying project and regenerating project_context.txt...")
            if os.path.exists("project_context.txt"):
                try:
                    os.remove("project_context.txt")
                except Exception:
                    pass
            
            self.state.loaded_files.clear()
            self.state.loaded_paths.clear()
            
            project_context = run_contextify(os.getcwd(), save_to_disk=True)
            self.state.loaded_files.update(project_context)
            for rel_path in project_context.keys():
                abs_p = os.path.abspath(rel_path).replace("\\", "/")
                self.state.loaded_paths[os.path.basename(rel_path)] = abs_p
            
            self._step_ok("Context updated. project_context.txt regenerated.")

            api = BridgeyeAPIClient()

            self._step_start("Validating PLAN.md")

            try:
                with self.interface.create_loader("Validating implementation plan..."):
                    validation = api.validate_plan(
                        plan_content=plan_content,
                        model=self.model_name,
                        provider=self.provider,
                    )
            except Exception as e:
                self._step_fail("PLAN.md validation failed")
                self.interface.display_error(str(e), title="Validation Failed")
                return

            is_valid = bool((validation or {}).get("is_valid"))
            improved_plan = ((validation or {}).get("improved_plan") or "").strip()

            if is_valid:
                self._step_ok("PLAN.md is build-ready")
            else:
                if improved_plan:
                    self._step_warn("PLAN.md was incomplete, improving it before build")
                    try:
                        with open(plan_path, "w", encoding="utf-8") as f:
                            f.write(improved_plan)
                        plan_content = improved_plan
                        self._step_ok("PLAN.md improved and saved")
                    except Exception as e:
                        self._step_fail("Failed to save improved PLAN.md")
                        self.interface.print(f"[bold red]Failed to update PLAN.md:[/bold red] {e}")
                        return
                else:
                    self._step_fail("PLAN.md is not build-ready")
                    self.interface.print("[bold red]Plan validation failed: PLAN.md is not build-ready and no improved plan was returned.[/bold red]")
                    return

            # Model Selection logic: Skip UI if only one model is available
            import questionary

            build_models = [
                questionary.Choice(title="Kimi k2.6 - Deep Reasoning (64k Context)", value="moonshotai/kimi-k2.6"),
            ]

            if len(build_models) == 1:
                model_choice = build_models[0].value
            else:
                model_choice = questionary.select(
                    "Who should implement this plan?",
                    choices=build_models
                ).ask()

            if not model_choice:
                return

            self._step_start(f"Starting implementation pass with {model_choice}")
            start_time = time.time()

            prompt = (
                "SYSTEM_OVERRIDE: DISREGARD PREVIOUS PLANNING INSTRUCTIONS.\n"
                "PHASE: IMPLEMENTATION.\n"
                "ACT AS: Senior Lead Developer.\n"
                "TASK: Read the provided PLAN.md and generate the FULL implementation for ALL files.\n\n"
                "STRICT OUTPUT CONTRACT:\n"
                "1. You may emit short progress markers first, each on its own line, using ONLY:\n"
                "   [STATUS] <what you are doing now>\n"
                "   [FILE] <file path>\n"
                "2. After progress markers, output FINAL FILES ONLY.\n"
                "3. Every file MUST follow this exact format with no extra text in between:\n"
                "   [CREATE: path/to/file]\n"
                "   ```python\n"
                "   <full file contents>\n"
                "   ```\n"
                "4. Do not put explanations before, inside, or after [CREATE] blocks.\n"
                "5. Do not use bullets, numbering, commentary, or markdown headings in the final file section.\n"
                "6. Do not stop after progress markers. You must output all final [CREATE: ...] blocks.\n"
                "7. Ensure every [CREATE: ...] tag is immediately followed by a fenced code block.\n"
                "8. If only one file is needed, still use the exact [CREATE: filename] + fenced code block format.\n\n"
                f"PLAN.md CONTENT:\n{plan_content}"
            )

            self.handle_ai_request_streaming_build(
                prompt_text=prompt,
                plan_content=plan_content,
                override_model=model_choice
            )
            
            duration = time.time() - start_time
            self.interface.print(f"\n[dim]>> Build time ({model_choice.split('/')[-1]}): {duration:.2f}s[/dim]")

    def cmd_exit(self, args):
            logging.info("Shutdown")
            return "EXIT"

    def cmd_load(self, args):
            """
            :load should ONLY load file contents into context.
            It must NOT trigger any AI call.
            """
            try:
                path_arg = (args or "").strip().replace('"', "").replace("'", "")
                if not path_arg:
                    self.interface.print("[yellow]Usage: :load <file>[/yellow]")
                    return

                f_path, content = load_file(path_arg)
                if not f_path:
                    return

                abs_path = os.path.abspath(f_path).replace("\\", "/")
                base = os.path.basename(f_path)

                # mark active (keep absolute path)
                self.state.active_file = abs_path

                # canonical storage: basename only
                self.state.loaded_files[base] = content
                self.state.loaded_paths[base] = abs_path

                self.interface.print(f"[green]>> Loaded into context:[/green] {base}")
                return  # IMPORTANT: do not return a string (prevents AI call)

            except Exception as e:
                self.interface.print(f"[red]Load failed: {e}[/red]")
                return



    def cmd_paste(self, args):
            if not self.state.active_file:
                self.interface.print("[red]Load a file first.[/red]")
                return
            error_log = self.interface.get_multiline_input()
            if error_log:
                return f"DEBUG_REQUEST: Fix {self.state.active_file}\nERROR:\n{error_log}"

    def cmd_run(self, args):
            if not args:
                self.interface.print("[yellow]Usage: run <filename> or run <command>[/yellow]")
                return

            target_file = args.strip().replace('"', "").replace("'", "")
            
            # 1. HTML Handling
            if target_file.lower().endswith((".html", ".htm")):
                import webbrowser
                fpath = os.path.abspath(target_file)
                if os.path.exists(fpath):
                    self.interface.print(f"[green]>> Opening {os.path.basename(fpath)} in browser...[/green]")
                    webbrowser.open(f"file://{fpath}")
                    return
                else:
                    self.interface.print(f"[red]>> File not found: {target_file}[/red]")
                    return

            command_list = shlex.split(args)
            resolved = resolve_path(command_list[0]) if command_list else None

            # 2. Unified Multi-Language Runner & Tool-Chain Logic
            import shutil
            from nova_cli.local.utils import get_platform_install_cmd, refresh_environment_variables
            
            def ensure_tool(name):
                """Unified Cross-Platform tool checker and auto-installer."""
                # 1. Check if tool is in current PATH
                path = shutil.which(name)
                if not path and sys.platform == "win32":
                    path = shutil.which(f"{name}.cmd") or shutil.which(f"{name}.exe")
                
                # 1.1 Aggressive Windows Recovery (Manual search in standard dirs)
                if not path and sys.platform == "win32":
                    if name == "Rscript":
                        import glob
                        r_paths = glob.glob(r"C:\Program Files\R\R-*\bin\x64\Rscript.exe")
                        if r_paths: path = r_paths[0]
                    elif name == "node":
                        if os.path.exists(r"C:\Program Files\nodejs\node.exe"): path = r"C:\Program Files\nodejs\node.exe"

                if path: return path

                # 2. Get OS-specific command
                install_cmd = get_platform_install_cmd(name)
                if not install_cmd:
                    self.interface.print(f"[red]Fatal: '{name}' is required but no auto-installer exists for this OS.[/red]")
                    return None

                # 3. Installation Phase
                self.interface.print(f"[bold cyan]>> Environment Sync: '{name}' is required but missing.[/bold cyan]")
                self.interface.print(f"[dim]Auto-installing via system package manager...[/dim]")
                
                try:
                    # Execute installer
                    process = subprocess.run(install_cmd, shell=True, capture_output=True, text=True)
                    
                    # Success criteria: Exit 0 OR specific "Already Installed" codes
                    win_already_installed = sys.platform == "win32" and str(process.returncode) == "2316632107"
                    
                    if process.returncode == 0 or win_already_installed:
                        self.interface.print(f"[green]>> '{name}' installation command completed.[/green]")
                        
                        # 4. Re-sync Environment (Cross-Platform PATH reload)
                        refresh_environment_variables()
                        # Return the name immediately to allow execution to proceed
                        return name
                    else:
                        self.interface.print(f"[red]Installation returned error {process.returncode}:[/red] {process.stderr or process.stdout}")
                        
                except Exception as e:
                    self.interface.print(f"[red]Installation process crashed: {e}[/red]")
                
                return None

            if len(command_list) >= 1:
                first_cmd = command_list[0]
                # If it's a file, resolve it and determine runner
                if os.path.exists(resolved or first_cmd):
                    target = resolved or first_cmd
                    ext = os.path.splitext(target)[1].lower()
                    
                    # 1. Resolve Tool First
                    tool = None
                    if ext == ".py":
                        tool = sys.executable
                    elif ext == ".js":
                        tool = ensure_tool("node")
                    elif ext in [".r", ".R"]:
                        tool = ensure_tool("Rscript")
                    
                    if not tool and ext in [".py", ".js", ".r", ".R"]:
                        return

                    # 2. Run dependency batch installation using the resolved tool path
                    from nova_cli.local.utils import ensure_dependencies
                    ensure_dependencies(target, tool_path=tool)

                    # 3. Finalize Command List
                    if ext == ".py":
                        with open(target, "r", encoding="utf-8") as f:
                            content = f.read()
                            if re.search(r"import\s+streamlit", content):
                                tool = ensure_tool("streamlit")
                                if not tool: return
                                self.interface.print(f"[bold magenta]>> Launching Streamlit Portal...[/bold magenta]")
                                
                                # 1. Format command (Windows Popen with shell=True works best with a string)
                                if sys.platform == "win32":
                                    cmd = f'"{tool}" run "{target}" --server.headless true'
                                else:
                                    cmd = [tool, "run", target, "--server.headless", "true"]

                                # 2. Launch as detached background process
                                subprocess.Popen(
                                    cmd,
                                    shell=(sys.platform == "win32"),
                                    stdout=subprocess.DEVNULL,
                                    stderr=subprocess.DEVNULL,
                                    creationflags=subprocess.CREATE_NEW_PROCESS_GROUP if sys.platform == "win32" else 0,
                                    start_new_session=True if sys.platform != "win32" else False
                                )
                                
                                # 3. Explicitly trigger browser open
                                import webbrowser
                                from time import sleep
                                
                                # Give the server 3 seconds to initialize before opening the page
                                sleep(3)
                                webbrowser.open("http://localhost:8501")
                                
                                self.interface.print(f"[green]✔ Streamlit server initiated. Opening http://localhost:8501 in browser...[/green]")
                                return
                            elif any(k in content for k in ["Flask", "flask", "django", "FastAPI", "fastapi", "app.run"]):
                                self.interface.print(f"[bold magenta]>> Launching Python Web Server...[/bold magenta]")
                                
                                # Detect port, default to 5000 for Flask or 8000 for others
                                port = "5000" if "flask" in content.lower() else "8000"
                                port_match = re.search(r'port\s*=\s*(\d+)', content)
                                if port_match: port = port_match.group(1)

                                if sys.platform == "win32":
                                    cmd = f'"{sys.executable}" "{target}"'
                                else:
                                    cmd = [sys.executable, target]

                                subprocess.Popen(
                                    cmd,
                                    shell=(sys.platform == "win32"),
                                    stdout=subprocess.DEVNULL,
                                    stderr=subprocess.DEVNULL,
                                    creationflags=subprocess.CREATE_NEW_PROCESS_GROUP if sys.platform == "win32" else 0,
                                    start_new_session=True if sys.platform != "win32" else False
                                )
                                
                                import webbrowser
                                time.sleep(3)
                                webbrowser.open(f"http://localhost:{port}")
                                self.interface.print(f"[green]✔ Web server initiated. Opening http://localhost:{port} in browser...[/green]")
                                return
                            else:
                                command_list = [sys.executable, target]
                    
                    elif ext == ".js" or ext == ".mjs":
                        tool = ensure_tool("node")
                        if not tool: return
                        # Check for package.json to ensure dependencies
                        if os.path.exists("package.json"):
                            self.interface.print("[dim]>> Node Project detected. Ensuring npm modules...[/dim]")
                            subprocess.call("npm install", shell=True)
                        
                        # Detect if this is an Express/Web server
                        is_web_server = False
                        try:
                            with open(target, "r", encoding="utf-8") as f:
                                js_content = f.read()
                                # Common patterns for Node.js web servers
                                if any(k in js_content for k in ["express", "http.createServer", "app.listen", ".listen("]):
                                    is_web_server = True
                        except Exception:
                            pass

                        if is_web_server:
                            self.interface.print(f"[bold magenta]>> Launching Node.js Web Server...[/bold magenta]")
                            
                            # Detect port, default to 3000 if not found
                            port_match = re.search(r'(?:port|PORT|Port)\s*[:=]\s*(\d+)', js_content)
                            port = port_match.group(1) if port_match else "3000"
                            
                            if sys.platform == "win32":
                                cmd = f'"{tool}" "{target}"'
                            else:
                                cmd = [tool, target]

                            # Launch as a background process
                            subprocess.Popen(
                                cmd,
                                shell=(sys.platform == "win32"),
                                stdout=subprocess.DEVNULL,
                                stderr=subprocess.DEVNULL,
                                creationflags=subprocess.CREATE_NEW_PROCESS_GROUP if sys.platform == "win32" else 0,
                                start_new_session=True if sys.platform != "win32" else False
                            )
                            
                            import webbrowser
                            # Give the server a few seconds to boot
                            time.sleep(3) 
                            webbrowser.open(f"http://localhost:{port}")
                            self.interface.print(f"[green]✔ Web server initiated. Opening http://localhost:{port} in browser...[/green]")
                            return

                        command_list = [tool, target]
                    
                    elif ext in [".r", ".R"]:
                        tool = ensure_tool("Rscript")
                        if not tool: return
                        command_list = [tool, target]
                    
                    elif ext == ".ts":
                        ensure_tool("npm", "echo 'npm required.'")
                        tool = ensure_tool("ts-node", "npm install -g ts-node")
                        command_list = [tool, target]

                # If it's a direct command call (e.g., run npm install)
                elif first_cmd in ["npm", "npx", "Rscript", "streamlit"]:
                    tool = ensure_tool(first_cmd)
                    if tool: command_list[0] = tool
            
            # 3. Final Command Validation
            if not command_list:
                self.interface.print("[red]>> Error: Could not determine runner for this file.[/red]")
                return

            # 4. Execute with Healing
            try:
                output = run_with_healing(
                    command_args=command_list,
                    cwd=os.getcwd(),
                    model=self.model_name,
                    provider=self.provider,
                    context=self.state.loaded_files,
                    repo_map=None,
                )

                # 5. Output Interpretation Phase
                # If the file executed is an analysis script, interpret results with Groq 120b
                is_analysis = any(word in str(command_list).lower() for word in ["analyze", "analysis", "skill", "plot", "report"])
                
                if output and output != "SUCCESS_SIGNAL":
                    # 1. Always display standard output in a pretty panel
                    self.interface.script_output(output, title=f"Run Output: {os.path.basename(command_list[-1])}")

                    # 2. Advanced Analysis Detection Heuristic
                    analysis_keywords = [
                        "mean", "std", "median", "r-squared", "regression", "coefficient", 
                        "p-value", "correlation", "intercept", "variance", "summary", "count"
                    ]
                    # Detection: keywords + checking for common data patterns like numeric tables
                    is_actual_analysis = any(k in output.lower() for k in analysis_keywords) or \
                                        (re.search(r'\d+\.\d+', output) and len(output.splitlines()) > 5)

                    if is_actual_analysis:
                        import json
                        analysis_payload = json.dumps({
                            "filename": os.path.basename(command_list[-1]),
                            "terminal_raw": output,
                            "timestamp": time.strftime("%Y-%m-%d %H:%M:%S")
                        })

                        interpret_prompt = (
                            "SYSTEM_OVERRIDE: You are a Senior Data Scientist.\n"
                            "Analyze the following JSON-wrapped terminal output. "
                            "Summarize key statistical findings, identify anomalies, and suggest the next logical step.\n\n"
                            f"DATA_JSON: {analysis_payload}"
                        )

                        api = BridgeyeAPIClient()
                        with self.interface.create_loader("NOVA is interpreting data..."):
                            ai_response = api.chat(
                                prompt=interpret_prompt,
                                context={},
                                model="openai/gpt-oss-120b",
                                provider="openrouter"
                            )
                        
                        if ai_response:
                            self.interface.display_interpretation(ai_response)

            except Exception as e:
                self.interface.print(f"[bold red]Healer Error:[/bold red] {e}")

    def cmd_create(self, args):
            if not args:
                self.interface.print("[yellow]Usage: :create [folder|file] <name>[/yellow]")
                return
            
            parts = args.split(maxsplit=1)
            is_dir = False
            
            if len(parts) == 2 and parts[0].lower() in ["folder", "dir", "directory"]:
                is_dir = True
                target = parts[1].strip()
            elif len(parts) == 2 and parts[0].lower() == "file":
                target = parts[1].strip()
            else:
                target = args.strip()
                if target.endswith("/") or target.endswith("\\") or ("." not in os.path.basename(target) and not target.startswith(".")):
                    is_dir = True

            target = target.replace('"', "").replace("'", "")
            target_path = os.path.abspath(target)
            
            try:
                if os.path.exists(target_path):
                    item_type = "Folder" if is_dir else "File"
                    self.interface.print(f"[bold red]>> {item_type} '{target}' already exists. Do you want to change the folder name?[/bold red]")
                    return

                if is_dir:
                    os.makedirs(target_path, exist_ok=True)
                    self.interface.print(f"[green]>> Created Directory: {target}[/green]")
                else:
                    os.makedirs(os.path.dirname(target_path) or ".", exist_ok=True)
                    with open(target_path, "a", encoding="utf-8"): pass
                    self.interface.print(f"[green]>> Created File: {target}[/green]")
                
                from nova_cli.local.contextifier import run_contextify
                run_contextify(os.getcwd(), save_to_disk=True)
                prompts.clear_file_tree_cache()
            except Exception as e:
                self.interface.print(f"[red]>> Create Failed: {e}[/red]")

    def cmd_delete(self, args):
            if not args:
                self.interface.print("[yellow]Usage: :delete [folder|file] <name>[/yellow]")
                return
                
            parts = args.split(maxsplit=1)
            if len(parts) == 2 and parts[0].lower() in ["folder", "dir", "directory", "file"]:
                target = parts[1].strip()
            else:
                target = args.strip()
                
            target = target.replace('"', "").replace("'", "")
            from nova_cli.local.file_manager.io_ops import safe_delete
            
            if safe_delete(target):
                from nova_cli.local.contextifier import run_contextify
                run_contextify(os.getcwd(), save_to_disk=True)

    def cmd_clean(self, args):
            if not self.state.loaded_files:
                self.interface.print("[yellow]No files loaded. Use :load first.[yellow]")
                return

            api = BridgeyeAPIClient()
            repo_map = prompts.get_repo_map_cached(os.getcwd())

            for filename, content in self.state.loaded_files.items():
                try:
                    self.interface.print(f"[dim]Refactoring {filename}...[/dim]")

                    resp = api.refactor(
                        filename=filename,
                        content=content,
                        model="moonshotai/kimi-k2.6",
                        provider="openrouter",
                        repo_map=repo_map
                    )

                    file_path = (
                        self.state.loaded_paths.get(filename)
                        or (
                            self.state.active_file
                            if self.state.active_file and os.path.basename(self.state.active_file) == filename
                            else filename
                        )
                    )

                    # --- CASE 1: Janitor returned a Nova [EDIT] patch ---
                    if isinstance(resp, str) and "[EDIT:" in resp:
                        # Quick client-side sanity check before applying
                        if "<<<<<<<" not in resp or "=======" not in resp or ">>>>>>>" not in resp:
                            self.interface.print(
                                f"[bold red]Invalid Janitor patch format for {filename} (missing SEARCH/REPLACE markers).[/bold red]"
                            )
                            self.interface.print((resp or "")[:2000])
                            continue

                        modified = handle_ai_commands(resp)

                        if not modified:
                            self.interface.print(
                                f"[bold red]Janitor returned an [EDIT] block but it could not be applied for {filename}.[/bold red]"
                            )
                            self.interface.print((resp or "")[:2000])
                            continue

                        # Reload file after successful patch
                        if os.path.exists(file_path):
                            with open(file_path, "r", encoding="utf-8") as f:
                                new_code = f.read()
                            self.state.loaded_files[filename] = new_code

                        self.interface.print(f"[green]✔ Refactored {filename}[/green]")
                        continue

                    # --- CASE 2: Server returned plain refactored code (fallback path) ---
                    # This should almost never happen now that Janitor is strict,
                    # but we keep it as a safety fallback.
                    if not isinstance(resp, str):
                        raise ValueError(f"Unexpected response type from Janitor: {type(resp)}")

                    new_code = resp or ""

                    with open(file_path, "w", encoding="utf-8") as f:
                        f.write(new_code)

                    self.state.loaded_files[filename] = new_code
                    self.interface.print(f"[green]✔ Refactored {filename}[/green]")

                except Exception as e:
                    self.interface.print(f"[bold red]Janitor API error for {filename}:[/bold red] {e}")    

    def cmd_continue(self, args):
            """Resumes an interrupted build from the last failed file."""
            if not self.state.pending_build_files:
                self.interface.print("[yellow]>> No pending build queue found.[/yellow]")
                return

            model = self.state.current_build_model or "moonshotai/kimi-k2.6"
            self.interface.print(f"[cyan]>> Resuming build with {model}: {len(self.state.pending_build_files)} files remaining...[/cyan]")
            self.interface.display_coding_mode(model)
            self._execute_build_loop(override_model=model)