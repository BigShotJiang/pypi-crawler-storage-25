import logging
import os
import re
import sys
import time

from rich.panel import Panel

from core import prompts
from nova_cli import config
from nova_cli.cli.shell_parts.ui_utils import extract_enhanced_prompt
from nova_cli.local.contextifier.engine import run_contextify
from nova_cli.local.file_manager.commands import handle_ai_commands
from nova_cli.local.utils import extract_code_from_markdown, ensure_dependencies
from nova_cli.nova_core.ai.api_client import BridgeyeAPIClient



class ShellAILogicMixin:
    
    def handle_ai_request(self, prompt_text, override_model=None, nlp_intent=None):
            """
            Orchestrates AI interaction with automated context discovery.
            """
            try:
                plan_exists = os.path.exists(os.path.join(os.getcwd(), "PLAN.md"))
                api = BridgeyeAPIClient()
                lower_p = prompt_text.lower()
                
                # --- 1. HARD HEURISTIC CHECK (Highest Priority) ---
                
                # DELETE HEURISTIC (Absolute Highest Priority)
                delete_keywords = ["delete", "remove", "rm", "erase", "wipe"]
                # Match whole words AND restrict to shorter prompts to prevent massive web-build prompts from triggering false positives
                is_delete_query = len(prompt_text.split()) < 30 and any(re.search(rf'\b{kw}\b', lower_p) for kw in delete_keywords) and bool(re.findall(r'[\w\-\/]+\.\w+', lower_p))

                # SKILLS HEURISTIC (Data files) - Ignore common config files to prevent intent hijacking
                data_extensions = [".csv", ".xlsx", ".parquet", ".json"]
                is_data_query = any(ext in lower_p for ext in data_extensions)
                
                # Exclude project config files from being treated as "Data to Analyze"
                config_files = ["package.json", "tsconfig.json", "composer.json", "package-lock.json"]
                if any(cfg in lower_p for cfg in config_files):
                    # If ONLY config files are present, it's not a data query
                    # We check if a real data extension exists outside of the config filenames
                    remaining_p = lower_p
                    for cfg in config_files:
                        remaining_p = remaining_p.replace(cfg, "")
                    is_data_query = any(ext in remaining_p for ext in data_extensions)

                # EDIT HEURISTIC: Force EDIT if a code file and modification verb are present
                mentioned_code_files = re.findall(r'\b[\w\-\/]+\.(?:py|js|html|css|ts|jsx|tsx|cpp|c|h|java|go|rs|md)\b', lower_p)
                edit_keywords = ["update", "fix", "change", "modify", "add", "refactor", "edit"]
                
                # Logic: Allow EDIT heuristic if a code file is mentioned and modification verbs are used
                is_edit_query = bool(mentioned_code_files) and any(kw in lower_p for kw in edit_keywords)

                # WEB HEURISTIC: Force SKILLS for web builds to avoid PLAN hijacking
                web_keywords = ["website", "landing page", "web page", "web site", "frontend", "react app", "html site", "portfolio site", "ecommerce site", "web app", "web based", "site"]
                is_web_query = any(wk in lower_p for wk in web_keywords)

                # REPO OVERVIEW HEURISTIC: Force ANALYZE and trigger full context load
                repo_overview_keywords = ["about the repo", "about the folder", "about this project", "overview of the folder", "overview of the repo", "explain this project", "explain the repo", "explain this folder", "repo overview", "project overview", "folder overview"]
                
                # Prevent heuristics from being hijacked by words inside our own internal prompts
                if "system_override" in lower_p:
                    is_repo_overview = False
                else:
                    is_repo_overview = any(kw in lower_p for kw in repo_overview_keywords)

                if "SYSTEM_OVERRIDE" in prompt_text:
                    # If it's an internal approved plan routing, don't let heuristics hijack it
                    intent = nlp_intent or "PLAN"
                elif is_delete_query:
                    intent = "DELETE"
                elif is_web_query:
                    intent = "SKILLS"
                elif is_data_query:
                    intent = "SKILLS"
                elif is_repo_overview:
                    intent = "ANALYZE"
                elif is_edit_query:
                    intent = "EDIT"
                else:
                    intent = nlp_intent

                # --- 2. INTENT CLASSIFICATION (Fallback) ---
                if not intent:
                    if (("analyse" in lower_p or "analyze" in lower_p) and "data" in lower_p):
                        intent = "SKILLS"
                    elif not override_model and "SYSTEM_OVERRIDE" not in prompt_text:
                        intent = self._get_nlp_intent(prompt_text)
                
                # --- 3. ARCHITECT LOCK ---
                # If no plan exists and it's not a deletion, skill, or explicit edit, force intent to PLAN.
                # This ensures creation requests properly enter the Architect phase.
                if not plan_exists and intent not in ["DELETE", "SKILLS", "GENERAL", "ANALYZE", "EDIT"]:
                    intent = "PLAN"

                intent = intent or "GENERAL"

                # --- 2. SKILLS GATE (Hard Intercept) ---
                if intent == "SKILLS":
                    skill_match = self._route_skill(prompt_text)
                    
                    if skill_match and skill_match != "NONE":
                        self._execute_skill_flow(skill_match, prompt_text, override_model)
                        return # EXIT: Ensure we never fall back to general chat models
                    else:
                        # If it was forced to SKILLS by heuristic but no skill code exists,
                        # manually force the data-analysis fallback if files are mentioned.
                        if is_data_query:
                            self._execute_skill_flow("data-analysis", prompt_text, override_model)
                            return

                # --- 4. CONTEXT DISCOVERY (Automated Context Loading) ---
                if intent in ["EDIT", "CREATE", "PLAN", "ANALYZE"]:
                    if is_repo_overview:
                        self._step_start("Scanning project architecture for comprehensive overview...")
                        self.state.loaded_files.clear()
                        self.state.loaded_paths.clear()
                        project_context = run_contextify(os.getcwd(), save_to_disk=True)
                        self.state.loaded_files.update(project_context)
                        for rel_path in project_context.keys():
                            abs_p = os.path.abspath(rel_path).replace("\\", "/")
                            self.state.loaded_paths[os.path.basename(rel_path)] = abs_p
                        self._step_ok("Project context synchronized.")
                    else:
                        mentioned_files = re.findall(r'[\w\-\/]+\.\w+', prompt_text)
                        for mf in mentioned_files:
                            # Ignore data files for text context; they are handled by skills
                            if any(mf.endswith(ext) for ext in [".csv", ".xlsx", ".parquet", ".json"]):
                                continue
                            if os.path.exists(mf):
                                self.state.active_file = os.path.abspath(mf).replace("\\", "/")
                                base = os.path.basename(self.state.active_file)
                                try:
                                    with open(self.state.active_file, "r", encoding="utf-8") as f:
                                        self.state.loaded_files[base] = f.read()
                                    self.state.loaded_paths[base] = self.state.active_file
                                except Exception:
                                    pass
                                # Load only the first relevant file mentioned as the "Active" file
                                break

                # --- 2. FILE DISCOVERY (Only after intent is known) ---
                if intent in ["EDIT", "CREATE", "ANALYZE", "SKILLS"]:
                    mentioned_files = re.findall(r'[\w\-\/]+\.\w+', prompt_text)
                    if mentioned_files:
                        for mf in mentioned_files:
                            if os.path.exists(mf):
                                self.state.active_file = os.path.abspath(mf).replace("\\", "/")
                                base = os.path.basename(self.state.active_file)
                                try:
                                    with open(self.state.active_file, "r", encoding="utf-8") as f:
                                        self.state.loaded_files[base] = f.read()
                                    self.state.loaded_paths[base] = self.state.active_file
                                except Exception:
                                    pass
                                break

                # --- BUILD REDIRECT ---
                if intent == "BUILD":
                    self.interface.print("[bold green]>> Build intent detected. Triggering implementation sequence...[/bold green]")
                    self.cmd_build_it("")
                    return

                # --- SKILL ROUTER INTERCEPT ---
                if intent == "SKILLS":
                    skill_match = self._route_skill(prompt_text)
                    if skill_match and skill_match != "NONE":
                        self._execute_skill_flow(skill_match, prompt_text, override_model)
                        return
                    else:
                        self.interface.print("[yellow]>> No matching skill found. Falling back to GENERAL intent.[/yellow]")
                        intent = "GENERAL"

                # --- LOCAL DELETE INTERCEPT (Bypass AI API entirely) ---
                if intent == "DELETE":
                    targets = []
                    for word in prompt_text.split():
                        clean_word = word.strip("',.\"")
                        # STRICT MATCH: Only target files that actually exist on disk.
                        # This prevents accidental deletion attempts on version numbers (18.3.1), CSS classes (px-1.5), or JS snippets (window.X)
                        if os.path.exists(clean_word) and os.path.isfile(clean_word):
                            if clean_word not in targets:
                                targets.append(clean_word)
                    
                    if targets:
                        self.interface.print(f"[cyan]>> Direct Action: Executing local delete for {', '.join(targets)}[/cyan]")
                        fake_output = "\n".join([f"[DELETE: {t}]" for t in targets])
                        
                        modified_files = handle_ai_commands(fake_output)
                        
                        if isinstance(modified_files, list) and modified_files:
                            for fpath in modified_files:
                                if fpath.startswith("DELETED:"):
                                    del_path = fpath.split("DELETED:", 1)[1].strip()
                                    abs_del = os.path.abspath(del_path).replace("\\", "/")
                                    base_del = os.path.basename(abs_del)
                                    
                                    if base_del in self.state.loaded_files:
                                        del self.state.loaded_files[base_del]
                                    if base_del in self.state.loaded_paths:
                                        del self.state.loaded_paths[base_del]
                                    if self.state.active_file == abs_del:
                                        self.state.active_file = None
                                        
                                    self.interface.print(f"[dim]>> Removed {base_del} from AI context.[/dim]")
                            
                            # Trigger full context regeneration after successful local deletions
                            if any(f.startswith("DELETED:") for f in modified_files):
                                self._step_start("Rebuilding project context after deletion...")
                                self.state.loaded_files.clear()
                                self.state.loaded_paths.clear()
                                
                                project_context = run_contextify(os.getcwd(), save_to_disk=True)
                                self.state.loaded_files.update(project_context)
                                for rel_path in project_context.keys():
                                    abs_p = os.path.abspath(rel_path).replace("\\", "/")
                                    self.state.loaded_paths[os.path.basename(rel_path)] = abs_p
                                    
                                self._step_ok("Context updated. project_context.txt regenerated.")
                        return
                    else:
                        self.interface.print("[yellow]>> Delete intent recognized, but no valid target file could be identified in the prompt.[/yellow]")
                        return
                # --- 2. MODEL & PROMPT CONFIGURATION ---
                target_model = override_model if override_model else self.model_name
                target_provider = self.provider

                # Implementation Gate: Kimi is the BUILDER. Groq 120B is the ARCHITECT.
                # PLAN intent MUST use the Groq 120B model to create PLAN.md.
                # EDIT and BUILD intents use KIMI K2.6.
                if (intent in ["EDIT", "BUILD"] or "PHASE: IMPLEMENTATION" in prompt_text) and intent != "PLAN":
                    target_model = "moonshotai/kimi-k2.6"
                    target_provider = "openrouter"
                    
                    # [FLOWCHART STEP 3]: Every time such event is triggered, whole project is first contextified.
                    self._step_start(f"Synchronizing project context for {intent}...")
                    if os.path.exists("project_context.txt"):
                        try:
                            os.remove("project_context.txt")
                        except Exception:
                            pass
                    
                    self.state.loaded_files.clear()
                    self.state.loaded_paths.clear()

                    def log_file(p):
                        if len(self.state.loaded_files) % 5 == 0:
                            self.interface.print(f"[dim]  Scanning: {p}[/dim]", soft_wrap=True)
                    
                    # [FLOWCHART STEP 4]: Latest contextified version of project is generated.
                    project_context = run_contextify(os.getcwd(), verbose_callback=log_file, save_to_disk=True)
                    self.state.loaded_files.update(project_context)
                    for rel_path in project_context.keys():
                        abs_p = os.path.abspath(rel_path).replace("\\", "/")
                        self.state.loaded_paths[os.path.basename(rel_path)] = abs_p
                    
                    # Force-sync the active file to ensure the AI's immediate target is fresh.
                    if self.state.active_file and os.path.exists(self.state.active_file):
                        base = os.path.basename(self.state.active_file)
                        try:
                            with open(self.state.active_file, "r", encoding="utf-8") as f:
                                self.state.loaded_files[base] = f.read()
                            self.state.loaded_paths[base] = self.state.active_file
                        except Exception:
                            pass
                    
                    self._step_ok(f"Context verified. NOVA is now ready to identify and fix the code...")
                    self.interface.display_coding_mode(target_model)
                else:
                    # ANALYSIS / Default
                    target_model = override_model or self.model_name
                
                # Refresh and Fetch Map for Peripheral Vision
                prompts.clear_file_tree_cache()
                repo_map = prompts.get_repo_map_cached(os.getcwd())

                # Inject Map into dynamic system instructions based on NLP intent
                if not override_model and "SYSTEM_OVERRIDE" not in prompt_text:
                    if intent == "EDIT":
                        # [FLOWCHART STEP 5]: Kimi K2.6 will take full context and give SEARCH REPLACE blocks.
                        phase_instruction = "YOU ARE IN SURGICAL EDIT MODE. PHASE: IMMEDIATE IMPLEMENTATION."
                        task_instruction = (
                            "1. Identify the relevant code bits across the project context.\n"
                            "2. Provide surgical [EDIT] tags immediately.\n"
                            "3. YOU MUST use the SEARCH/REPLACE block syntax for all updates.\n"
                            "4. Ensure your SEARCH block matches the project context exactly."
                        )
                    elif intent == "PLAN":
                        phase_instruction = "YOU ARE IN THE ARCHITECT & PLANNING PHASE."
                        # Force the model to output the PLAN.md file using the Nova protocol
                        task_instruction = (
                            "1. Your goal is to write a comprehensive, implementation-ready PLAN.md based on the user request.\n"
                            "2. CRITICAL: DO NOT generate any [EDIT] blocks or application code. Your ONLY output must be the PLAN.md file.\n"
                            "3. You MUST output the plan using the exact tag: [CREATE: PLAN.md] followed by a triple-backtick Markdown code block.\n"
                            "4. TECHNOLOGY RULE: If the request is web-based, you MUST use HTML, CSS, and JS unless specifically told otherwise.\n"
                            "5. The plan must include: Objective, Architecture, File Structure, and Implementation Steps."
                        )
                    else:
                        # ANALYZE / GENERAL / READ / Default
                        phase_instruction = f"YOU ARE IN {intent} MODE."
                        if is_repo_overview:
                            task_instruction = (
                                "1. Analyze the provided REPOSITORY_MAP and full project context.\n"
                                "2. Provide a beautiful, highly detailed summary of the repository/folder.\n"
                                "3. Explain what files are present, the overall architecture, how components interconnect, and their relationships.\n"
                                "4. Use rich markdown formatting (headers, bullet points, bold text) to make it visually appealing and easy to digest."
                            )
                        else:
                            task_instruction = "1. Answer the user's question directly. Use the REPOSITORY_MAP to explain structure or logic."

                    prompt_text = (
                        f"SYSTEM_INSTRUCTION: {phase_instruction}\n"
                        f"REPOSITORY_MAP:\n{repo_map}\n\n"
                        f"{task_instruction}\n"
                        "2. DO NOT use native tool-calling. Use ONLY [CREATE], [EDIT], [MKDIR], [DELETE] tags if file changes are required.\n"
                        "3. CRITICAL: For [EDIT] or [CREATE], always follow with a Markdown code block.\n\n"
                        f"USER_REQUEST: {prompt_text}"
                    )

                # --- 3. API EXECUTION (STREAMING) ---
                # Technical logs are only shown for Coding or Build tasks per flowchart
                if intent in ["EDIT", "CREATE", "BUILD"] or "PHASE: IMPLEMENTATION" in prompt_text:
                    self._step_start(f"Transmitting context to {target_model}...")
                    total_bytes = sum(len(v) for v in self.state.loaded_files.values())
                    self.interface.print(f"[dim]  Payload size: {total_bytes / 1024:.1f} KB[/dim]")
                    self.interface.print(f"[cyan]>> {target_model} is reasoning (Thinking)...[/cyan]")

                # Switch to Streaming Response to show the Thinking Process
                active_basename = os.path.basename(self.state.active_file) if self.state.active_file else None
                
                # Disable thinking display for general conversation or analysis
                display_reasoning = intent not in ["GENERAL", "ANALYZE"]
                
                output = self.interface.stream_rich_response(
                    api.chat_stream(
                        prompt=prompt_text,
                        context=self.state.loaded_files,
                        model=target_model,
                        provider=target_provider,
                        repo_map=repo_map,
                        active_file=active_basename
                    ),
                    show_reasoning=display_reasoning
                )

                if not output:
                    self._step_fail("No response received from AI.")
                    return

                self.state.last_ai_response = output

                # Buffer extracted code for the ':apply' command
                extracted_code = extract_code_from_markdown(output)
                if extracted_code:
                    self.state.last_generated_code = extracted_code

                # --- 4. LOCAL STATE SYNCHRONIZATION ---
                # Execute [CREATE], [EDIT], [MKDIR], [DELETE] tags.
                modified_files = handle_ai_commands(output)

                # If the AI modified or created files, reload them into the persistent CLI context immediately.
                if isinstance(modified_files, list) and modified_files:
                    for fpath in modified_files:
                        if fpath == "SYSTEM_ENVIRONMENT": 
                            continue
                                
                            # Handle Context Eviction for Deleted Files
                        if fpath.startswith("DELETED:"):
                            del_path = fpath.split("DELETED:", 1)[1].strip()
                            abs_del = os.path.abspath(del_path).replace("\\", "/")
                            base_del = os.path.basename(abs_del)
                                
                            if base_del in self.state.loaded_files:
                                del self.state.loaded_files[base_del]
                            if base_del in self.state.loaded_paths:
                                del self.state.loaded_paths[base_del]
                            if self.state.active_file == abs_del:
                                    self.state.active_file = None
                                    
                            self.interface.print(f"[dim]>> Removed {base_del} from AI context.[/dim]")
                            continue
                            
                        # Automated Discovery Sync: Normalize and track absolute paths
                        abs_path = os.path.abspath(fpath).replace("\\", "/")
                        if os.path.exists(abs_path):
                            self.state.active_file = abs_path
                            base = os.path.basename(abs_path)
                            try:
                                with open(abs_path, "r", encoding="utf-8") as f:
                                    content = f.read()
                                    self.state.loaded_files[base] = content
                                    # CRITICAL: Map basename to absolute path for future Turn logic
                                    self.state.loaded_paths[base] = abs_path
                            except Exception:
                                pass

                    # --- POST-EDIT SYNC & EXECUTION ---
                    # [FLOWCHART STEP 6]: Edits/Updates/Adds what user wants and automatically runs the file.
                    if intent in ["EDIT", "CREATE"]:
                        self._step_start("Edits applied. Refreshing project context...")
                        # Immediately regenerate project_context.txt to reflect the new state of the code.
                        new_context = run_contextify(os.getcwd(), save_to_disk=True)
                        self.state.loaded_files.update(new_context)
                        self._step_ok("Project context updated.")

                        if self.state.active_file:
                            self.interface.print(f"[bold green]>> Edits applied successfully. Automatically running {os.path.basename(self.state.active_file)}...[/bold green]")
                            self.cmd_run(self.state.active_file)

                    # --- PLAN COMPLETION GUIDANCE ---
                    # Tell the user exactly what to do next so they don't get stuck
                    if intent == "PLAN":
                        plan_check = os.path.join(os.getcwd(), "PLAN.md")
                        if os.path.exists(plan_check):
                            self.interface.print("\n[bold green]✓ PLAN.md created.[/bold green]")
                            self.interface.print("[cyan]>> Type [bold]build it[/bold] to start implementation with Kimi K2.6.[/cyan]\n")

                logging.info(f"Interaction | Model: {target_model} | Output Len: {len(output)}")
                
                # Draw a divider after the conversation finishes
                self.interface.console.rule(style="dim")

            except Exception as e:
                # Display only the pretty panel to the user
                self.interface.display_error(str(e))
                
                # Record the technical details silently in the background file
                with open("nova.log", "a", encoding="utf-8") as f:
                    timestamp = time.strftime("%Y-%m-%d %H:%M:%S")
                    f.write(f"{timestamp} - ERROR - Chat API Error: {str(e)}\n")

    def handle_ai_request_streaming_build(self, prompt_text, plan_content, override_model=None):
            """
            Hybrid build path:
            1. Streams the implementation overview (visual process).
            2. Automatically extracts the file list from that stream.
            3. Builds files one-by-one to prevent 504 timeouts.
            """
            try:
                api = BridgeyeAPIClient()
                target_model = override_model or "moonshotai/kimi-k2.6"
                target_provider = "openrouter"
                self.interface.display_coding_mode(target_model)

                # --- PHASE 1: OVERVIEW STREAM ---
                self.interface.print("[bold cyan]NOVA is planning the build sequence...[/bold cyan]")
                
                # Refresh Peripheral Vision so AI sees existing files
                prompts.clear_file_tree_cache()
                repo_map = prompts.get_repo_map_cached(os.getcwd())

                overview_prompt = (
                    "PHASE: IMPLEMENTATION_OVERVIEW.\n"
                    f"CURRENT PROJECT STRUCTURE:\n{repo_map}\n\n"
                    "TASK: Briefly describe your implementation strategy and provide a list of ALL files required by PLAN.md.\n"
                    "CRITICAL: If files already exist in the CURRENT PROJECT STRUCTURE, they must still be included in the list if they are part of the plan.\n"
                    "STRICT FORMAT FOR FILE LIST:\n"
                    "Every file you intend to create must be on its own line like this: [FILE] path/to/file.ext\n\n"
                    f"PLAN.md:\n{plan_content}"
                )

                # Use the beautified streaming UI component
                try:
                    full_overview = self.interface.stream_rich_response(
                        api.chat_stream(overview_prompt, self.state.loaded_files, target_model, target_provider)
                    )
                except RuntimeError as e:
                    self.interface.display_error(f"{str(e)}\n\nCheck your internet and type [bold cyan]build it[/bold cyan] to try again.")
                    return

                # --- PHASE 2: EXTRACT FILE LIST (Fail-Safe Extraction) ---
                # 1. High-Priority: Explicit Tags (We trust these 100%)
                tagged_files = re.findall(r'\[FILE\]\s*([\w\-\/\.]+)', full_overview)
                tagged_files.extend(re.findall(r'\[CREATE:\s*([\w\-\/\.]+)\]', full_overview))

                # 2. Low-Priority Fallback: Markdown lists
                fallback_files = []
                lines = full_overview.splitlines()
                for line in lines:
                    line = line.strip()
                    # Matches "- path/file.ext" or "1. path/file.ext"
                    m = re.search(r'(?:^[-*]\s*|^\d+\.\s*)([\w\-\/\.]+\.\w+)', line)
                    if m:
                        fallback_files.append(m.group(1))

                # 3. Intelligent Filtering for Fallbacks
                # We only filter the fallback list to avoid technical terms like "Node.js"
                ignore_list = {"node.js", "express.js", "npm", "github", "express", "v14", "v16", "v18", "v20"}
                filtered_fallbacks = [
                    f for f in fallback_files 
                    if f.lower() not in ignore_list and not f.lower().endswith(('.md', '.txt'))
                ]

                # 4. Combine and Deduplicate
                # We prioritize tagged files, then add unique filtered fallbacks
                final_list = []
                seen = set()
                for f in (tagged_files + filtered_fallbacks):
                    f_norm = f.strip().replace("\\", "/")
                    f_low = f_norm.lower()

                    # CRITICAL: Ignore version numbers (e.g., 1.0, 2.4.1)
                    if re.match(r'^\d+(\.\d+)+$', f_norm):
                        continue

                    if f_low not in seen:
                        final_list.append(f_norm)
                        seen.add(f_low)
                
                files_to_build = final_list

                if not files_to_build:
                    self._step_fail("No files identified for build. Please check implementation overview.")
                    return

                self._step_ok(f"Identified {len(files_to_build)} unique files to build sequentially.")
                
                # Save build state for potential :continue resumption
                self.state.pending_build_files = files_to_build
                self.state.current_plan_content = plan_content
                self.state.save_build_state()

                # Trigger the shared execution loop with the selected model
                self._execute_build_loop(override_model=target_model)

            except Exception as e:
                self.interface.print(f"[bold red]Build API Error:[/bold red] {e}")
                logging.error(f"Hybrid Build Error: {e}")
    
    def should_use_prompt_enhancer(self, prompt_text: str, intent: str) -> bool:
            """
            Mandatory gate for the Architect phase.
            """
            plan_exists = os.path.exists(os.path.join(os.getcwd(), "PLAN.md"))

            # Skip for system internal calls or very short inputs
            if "SYSTEM_OVERRIDE" in prompt_text or len(prompt_text.strip()) < 5:
                return False

            # If we are explicitly building, we don't enhance the prompt
            if intent == "BUILD":
                return False

            # RULE: If no PLAN.md exists, any intent to CREATE or PLAN must go through the Enhancer
            if not plan_exists and intent in ["PLAN", "CREATE"]:
                return True

            # RULE: If user explicitly asks for a re-plan
            if intent == "PLAN":
                replan_keywords = ["new plan", "redo plan", "update plan", "replan", "start over", "scrap the plan"]
                if any(kw in prompt_text.lower() for kw in replan_keywords):
                    return True

            return False

    def run_prompt_enhancement_flow(self, user_prompt: str) -> str | None:
            """
            Enhances the user's raw prompt before execution.
            Allows the user to:
            1. approve
            2. suggest edits
            3. cancel

            Returns:
                - final approved prompt as str
                - None if cancelled or failed
            """
            api = BridgeyeAPIClient()

            current_enhanced_prompt = None
            edit_request = None

            while True:
                try:
                    with self.interface.create_loader(
                        "Enhancing and completing your instructions to make them more executable..."
                    ):
                        response = api.enhance_prompt(
                            user_prompt=user_prompt,
                            model=self.model_name,
                            provider=self.provider,
                            current_enhanced_prompt=current_enhanced_prompt,
                            edit_request=edit_request,
                        )
                except Exception as e:
                    self.interface.print(f"[bold red]Prompt Enhancer Error:[/bold red] {e}")
                    return None

                enhanced_prompt = extract_enhanced_prompt((response or {}).get("enhanced_prompt", ""))
                if not enhanced_prompt:
                    self.interface.print("[bold red]Prompt Enhancer Error:[/bold red] Empty enhanced prompt received.")
                    return None

                self.interface.print("\n[bold cyan]Enhanced Prompt:[/bold cyan]")
                self.interface.print(Panel(enhanced_prompt, border_style="cyan"))

                self.interface.print("\n[bold yellow]Choose an option:[/bold yellow]")
                self.interface.print("[green]1.[/green] Approve and continue")
                self.interface.print("[green]2.[/green] Suggest edits")
                self.interface.print("[green]3.[/green] Cancel")

                choice = self.interface.input("[cyan]Enter choice > [/cyan]").strip()

                if choice == "1":
                    return enhanced_prompt

                if choice == "3":
                    self.interface.print("[dim]Prompt enhancement cancelled.[/dim]")
                    return None

                if choice == "2":
                    edit_request = self.interface.input(
                        "[cyan]Enter what you want changed in the enhanced prompt > [/cyan]"
                    ).strip()

                    if not edit_request:
                        self.interface.print("[yellow]No edit request entered. Showing current enhanced prompt again.[/yellow]")
                        edit_request = None
                        continue

                    current_enhanced_prompt = enhanced_prompt
                    continue

                self.interface.print("[yellow]Invalid choice. Please enter 1, 2, or 3.[/yellow]")
                edit_request = None

    def _get_nlp_intent(self, prompt_text: str) -> str:
                """High-fidelity intent classification to drive the Architect/Builder flow."""
                api = BridgeyeAPIClient()
                
                plan_path = os.path.join(os.getcwd(), "PLAN.md")
                plan_exists = os.path.exists(plan_path)
                
                classifier_prompt = (
                    "SYSTEM: You are a strict intent classifier for NOVA, a terminal-native AI coding assistant. "
                    "Output EXACTLY one word from the allowed set. No explanation. No punctuation. No extra text. "
                    "Any deviation is a critical failure.\n\n"
                    "ALLOWED OUTPUT VALUES: PLAN | BUILD | EDIT | ANALYZE | SKILLS | DELETE | GENERAL\n\n"

                    "=== ABSOLUTE GATE — READ BEFORE ANYTHING ELSE ===\n"
                    f"PLAN_MD_EXISTS={plan_exists}\n"
                    "RULE A: If PLAN_MD_EXISTS=False → BUILD is IMPOSSIBLE. Never output BUILD.\n"
                    "RULE B: If PLAN_MD_EXISTS=False AND the user is asking for anything to be "
                    "created, built, written, made, or developed → output PLAN. No exceptions.\n"
                    "RULE C: The 'CREATE' intent is deprecated. Use 'PLAN' for all new creation requests.\n\n"

                    "=== CATEGORY DEFINITIONS ===\n\n"

                    "PLAN [creation intent]:\n"
                    "  Trigger for ANY request where the user wants a NEW project, app, tool, script, feature, "
                    "component, or system. Even if files exist in the directory, if the user says 'make me a X' "
                    "and X is a feature or app, it is a PLAN intent.\n"
                    "  Trigger on ANY of these words or phrases:\n"
                    "    make, create, build, write, develop, generate, design, scaffold, set up, initialize,\n"
                    "    start, I want, I need, I'd like, give me, help me make, help me create, help me build,\n"
                    "    can you make, can you create, can you write, can you build, please make, please create,\n"
                    "    please build, please write, put together, come up with, draft, architect, spin up,\n"
                    "    bootstrap, produce, implement a new, code a new.\n"
                    "  CRITICAL: If the user says 'Make me a [something]', ALWAYS output PLAN.\n\n"

                    "BUILD [execution intent — PLAN.md must exist]:\n"
                    "  Trigger ONLY when PLAN_MD_EXISTS=True AND user explicitly wants to execute the existing plan.\n"
                    "  Trigger phrases: build it, implement, implement the plan, execute, execute the plan, "
                    "run the plan, start building, code it up, develop it, ship it, go ahead, let's go, "
                    "start now, do it, proceed, kick it off.\n"
                    "  HARD RULE: PLAN_MD_EXISTS=False → output PLAN instead. Always.\n\n"

                    "EDIT [modification intent — file already exists]:\n"
                    "  Trigger when user wants to change, fix, update, or refactor an EXISTING file.\n"
                    "  Strong signals: a specific filename is mentioned (e.g. app.py, server.js), OR verbs like\n"
                    "    fix, change, update, modify, rename, refactor, replace, patch, adjust, tweak, rewrite, improve.\n"
                    "  GUARD: 'fix a bug', 'remove a bug', 'clean up my code' = EDIT not DELETE.\n"
                    "  GUARD: no filename mentioned + creation verb = PLAN not EDIT.\n\n"

                    "ANALYZE [question intent — no file changes]:\n"
                    "  Trigger when user asks a question or wants explanation, review, or understanding only.\n"
                    "  Trigger phrases: explain, how does, what does, why is, summarize, review, audit, describe,\n"
                    "    walk me through, understand, what is happening, is this correct, does this look right,\n"
                    "    tell me about, break down, what should I.\n\n"

                    "SKILLS [data/pipeline intent]:\n"
                    "  Trigger when user wants to process a file, run a data pipeline, or invoke a skill module.\n"
                    "  Trigger phrases: analyze data, process dataset, run skill, load dataset, parse file,\n"
                    "    run pipeline, extract from file.\n"
                    "  Also trigger when a .csv, .xlsx, .parquet, or .json file is explicitly mentioned.\n\n"

                    "DELETE [removal intent — explicit file target]:\n"
                    "  Trigger ONLY for explicit requests to remove files or directories.\n"
                    "  Trigger phrases: delete [file], remove [file], erase, wipe, drop [file].\n"
                    "  GUARD: 'remove a bug' or 'clean up code' = EDIT not DELETE.\n\n"

                    "GENERAL [fallback — no clear actionable intent]:\n"
                    "  Trigger for greetings, thanks, small talk, or purely factual questions.\n"
                    "  IMPORTANT: Do NOT default to GENERAL if the request involves creating or modifying code.\n\n"

                    "=== CONFLICT RESOLUTION PRIORITY (top-down, stop at first match) ===\n"
                    "P0. PLAN_MD_EXISTS=False + any creation/build/make intent → PLAN. No exceptions.\n"
                    "P1. PLAN_MD_EXISTS=True + explicit execution phrase ('build it', 'implement', 'go ahead') → BUILD.\n"
                    "P2. Explicit file deletion target → DELETE.\n"
                    "P3. Specific existing filename + modification verb → EDIT.\n"
                    "P4. Any creation/making/writing of something new (no existing filename) → PLAN.\n"
                    "P5. Question, explanation, or review request → ANALYZE.\n"
                    "P6. Data file or pipeline mentioned → SKILLS.\n"
                    "P7. Default → GENERAL.\n\n"

                    "=== FEW-SHOT EXAMPLES (ground truth — override definitions if conflict) ===\n\n"

                    "PLAN_MD_EXISTS=False | 'Make me a calculator app in Python' -> PLAN\n"
                    "PLAN_MD_EXISTS=False | 'Make me a single file python calculator in gui. All buttons should be functional.' -> PLAN\n"
                    "PLAN_MD_EXISTS=False | 'Create a REST API with Flask that handles user auth' -> PLAN\n"
                    "PLAN_MD_EXISTS=False | 'Build a to-do list app with a dark theme' -> PLAN\n"
                    "PLAN_MD_EXISTS=False | 'Write me a web scraper for Amazon prices' -> PLAN\n"
                    "PLAN_MD_EXISTS=False | 'I want a CLI tool that converts CSV to JSON' -> PLAN\n"
                    "PLAN_MD_EXISTS=False | 'I need a dashboard that shows sales data' -> PLAN\n"
                    "PLAN_MD_EXISTS=False | 'Give me a Python script that monitors CPU usage' -> PLAN\n"
                    "PLAN_MD_EXISTS=False | 'Can you make a chatbot with memory?' -> PLAN\n"
                    "PLAN_MD_EXISTS=False | 'Develop a login system with JWT auth' -> PLAN\n"
                    "PLAN_MD_EXISTS=False | 'Set up a FastAPI backend with CRUD operations' -> PLAN\n"
                    "PLAN_MD_EXISTS=False | 'Design a task manager app with a React frontend' -> PLAN\n"
                    "PLAN_MD_EXISTS=False | 'Build it' -> PLAN\n"
                    "PLAN_MD_EXISTS=False | 'Build a snake game' -> PLAN\n"
                    "PLAN_MD_EXISTS=False | 'Implement a sorting algorithm visualizer' -> PLAN\n"
                    "PLAN_MD_EXISTS=False | 'Please write a REST client for the GitHub API' -> PLAN\n"
                    "PLAN_MD_EXISTS=False | 'Put together a Tkinter GUI calculator' -> PLAN\n"
                    "PLAN_MD_EXISTS=True  | 'Build it' -> BUILD\n"
                    "PLAN_MD_EXISTS=True  | 'Implement the plan' -> BUILD\n"
                    "PLAN_MD_EXISTS=True  | 'Start building' -> BUILD\n"
                    "PLAN_MD_EXISTS=True  | 'Execute the plan' -> BUILD\n"
                    "PLAN_MD_EXISTS=True  | 'Go ahead and build' -> BUILD\n"
                    "PLAN_MD_EXISTS=True  | 'Let\\'s go' -> BUILD\n"
                    "PLAN_MD_EXISTS=True  | 'Do it' -> BUILD\n"
                    "PLAN_MD_EXISTS=False | 'Fix the login bug in auth.py' -> EDIT\n"
                    "PLAN_MD_EXISTS=True  | 'Change the button color in app.py' -> EDIT\n"
                    "PLAN_MD_EXISTS=False | 'Refactor the database connection logic in db.py' -> EDIT\n"
                    "PLAN_MD_EXISTS=False | 'Update the API endpoint in routes.py' -> EDIT\n"
                    "PLAN_MD_EXISTS=False | 'How does the authentication flow work?' -> ANALYZE\n"
                    "PLAN_MD_EXISTS=False | 'Explain what this function does' -> ANALYZE\n"
                    "PLAN_MD_EXISTS=False | 'What does shell.py do?' -> ANALYZE\n"
                    "PLAN_MD_EXISTS=False | 'Analyze this CSV and extract the top 10 rows' -> SKILLS\n"
                    "PLAN_MD_EXISTS=False | 'Process my sales.xlsx file' -> SKILLS\n"
                    "PLAN_MD_EXISTS=False | 'Delete the old config.py file' -> DELETE\n"
                    "PLAN_MD_EXISTS=False | 'Remove utils.py' -> DELETE\n"
                    "PLAN_MD_EXISTS=False | 'Hey, how are you?' -> GENERAL\n"
                    "PLAN_MD_EXISTS=False | 'Thanks!' -> GENERAL\n"
                    "PLAN_MD_EXISTS=False | 'What is Python?' -> GENERAL\n\n"

                    "=== OUTPUT INSTRUCTION ===\n"
                    "Respond with EXACTLY one word. Allowed: PLAN, BUILD, EDIT, ANALYZE, SKILLS, DELETE, GENERAL.\n"
                    "Any response that is not one of these exact words is a critical failure.\n\n"

                    f"PLAN_MD_EXISTS={plan_exists} | USER_REQUEST: {prompt_text}"
                )
                try:
                    # Use the currently selected model and provider for intent classification
                    response = api.chat(
                        prompt=classifier_prompt,
                        context={},
                        model=self.model_name,
                        provider=self.provider,
                        repo_map=""
                    )
                    return response.strip().upper()
                except Exception:
                    return "PLAN"

    def _execute_build_loop(self, override_model=None):
                """Core incremental generator loop with state tracking and 429 retries."""
                api = BridgeyeAPIClient()
                target_model = override_model or "moonshotai/kimi-k2.6"
                target_provider = "openrouter"
                
                # Use a copy for safe iteration while modifying original state
                files_to_process = list(self.state.pending_build_files)
                total_files = len(files_to_process)
                final_built_files = []

                for i, fpath in enumerate(files_to_process, 1):
                    # Safety Check: Skip invalid "filenames" that are just numbers or known false positives
                    if re.match(r'^\d+(\.\d+)+$', fpath) or fpath.lower() in ["node.js", "express.js", "npm"]:
                        if fpath in self.state.pending_build_files:
                            self.state.pending_build_files.remove(fpath)
                        continue

                    # Rate-limit prevention: Small pause between high-compute requests
                    if i > 1:
                        time.sleep(2)

                    file_output = ""
                    max_retries = 5 

                    for attempt in range(max_retries):
                        try:
                            self.interface.print(f"\n[bold cyan]─── [{i}/{total_files}] Constructing: {fpath} ───[/bold cyan]")
                            
                            build_prompt = (
                                f"PHASE: IMPLEMENTATION. Generate the complete code for: {fpath}\n"
                                f"PLAN CONTEXT:\n{self.state.current_plan_content}\n"
                                f"STRICT: Output ONLY the [CREATE: {fpath}] tag followed by a Markdown code block.\n"
                                "CRITICAL: DO NOT use '<<<<<<< SEARCH', '=======', or '>>>>>>> REPLACE' markers. Output the raw, full file content only.\n"
                                "CRITICAL: DO NOT include docstrings, comments, thoughts, or explanations. The resulting file must contain ONLY valid, functional code for the target language."
                            )
                            
                            # Use stream_rich_response instead of loader to preserve Kimi's Thinking process
                            file_output = self.interface.stream_rich_response(
                                api.chat_stream(
                                    prompt=build_prompt,
                                    context=self.state.loaded_files,
                                    model=target_model,
                                    provider=target_provider
                                )
                            )
                            
                            if file_output:
                                break

                        except RuntimeError as e:
                            if any(err in str(e) for err in ["429", "timeout", "504", "internet", "connection"]) and attempt < max_retries - 1:
                                # Exponential backoff: 5s, 10s, 20s, 40s
                                wait_time = 5 * (2 ** attempt)
                                self.interface.print(f"[yellow]>> Connection unstable. Retrying in {wait_time}s... ({attempt+1}/{max_retries})[/yellow]")
                                time.sleep(wait_time)
                                continue
                            
                            # Final failure after retries
                            self.interface.display_error(
                                "Build Interrupted: Check your internet connection. \nType [bold cyan]continue[/bold cyan] to resume building from this file.", 
                                title="Connection Failure"
                            )
                            return

                    # Process the output
                    modified = handle_ai_commands(file_output)
                    
                    if modified:
                        final_built_files.append(fpath)
                        self.scan_and_load_context(fpath)
                        self._step_ok(f"Synced {fpath} to project.")
                        # Remove from state ONLY after successful sync
                        if fpath in self.state.pending_build_files:
                            self.state.pending_build_files.remove(fpath)
                            self.state.save_build_state() # PERSIST PROGRESS
                    else:
                        self._step_warn(f"Warning: {fpath} parser error (tag mismatch).")

                if not self.state.pending_build_files:
                    self._step_ok("Build complete. All modules synchronized.")
                    
                    # 1. Update Context Post-Build
                    self._step_start("Contextifying project after build...")
                    self.state.loaded_files.clear()
                    self.state.loaded_paths.clear()
                    
                    project_context = run_contextify(os.getcwd(), save_to_disk=True)
                    self.state.loaded_files.update(project_context)
                    for rel_path in project_context.keys():
                        abs_p = os.path.abspath(rel_path).replace("\\", "/")
                        self.state.loaded_paths[os.path.basename(rel_path)] = abs_p
                    self._step_ok("Context updated. project_context.txt regenerated.")
                    
                    # 2. Auto-Run What Nova Built (Intelligent Entry Point Identification)
                    entry_point = None
                    
                    if final_built_files:
                        try:
                            # Use the Architect model to analyze the plan and the files we actually created
                            with self.interface.create_loader("Identifying project entry point..."):
                                id_prompt = (
                                    "TASK: Identify the single primary entry point file (the one that starts the application) "
                                    "from the list of files provided below, using the provided PLAN.md as reference.\n\n"
                                    "RULES:\n"
                                    "1. Output ONLY the filename (e.g., 'start.py' or 'src/main.js').\n"
                                    "2. No explanation, no quotes, no markdown.\n"
                                    "3. The file must exist in the provided list.\n\n"
                                    f"FILES BUILT: {', '.join(final_built_files)}\n\n"
                                    f"PLAN.md:\n{self.state.current_plan_content}"
                                )
                                
                                ai_id = api.chat(
                                    prompt=id_prompt,
                                    context={},
                                    model=self.model_name,
                                    provider=self.provider
                                )
                                
                                candidate = ai_id.strip().replace('"', '').replace("'", "")
                                
                                # Validate the AI returned a file we actually built
                                if candidate in final_built_files:
                                    entry_point = candidate
                                else:
                                    # Try a basename match as a safety fallback
                                    for f in final_built_files:
                                        if os.path.basename(f) == os.path.basename(candidate):
                                            entry_point = f
                                            break
                        except Exception:
                            entry_point = None

                    # Fallback to hardcoded defaults if AI identification failed or was skipped
                    if not entry_point:
                        for candidate in ["main.py", "app.py", "index.js", "server.js", "run.py"]:
                            if candidate in self.state.loaded_files:
                                entry_point = candidate
                                break
                    
                    # Final Fallback to active file
                    if not entry_point and self.state.active_file:
                        entry_point = os.path.basename(self.state.active_file)
                    
                    if entry_point:
                        self.interface.print(f"\n[bold green]>> Build finished. Identified Entry Point: {entry_point}[/bold green]")
                        self.cmd_run(entry_point)
                    else:
                        self.interface.print("\n[bold green]>> Build finished. Use 'run <filename>' or 'run <command>' to execute.[/bold green]")

    def _route_skill(self, prompt_text: str) -> str | None:
                """Determines which skill to trigger based on installed package components."""
                lower_p = prompt_text.lower()
                
                data_extensions = [".csv", ".xlsx", ".parquet", ".json"]
                is_data = any(ext in lower_p for ext in data_extensions)
                
                # Security: Do not treat project configs as data files
                config_files = ["package.json", "tsconfig.json", "composer.json", "package-lock.json"]
                if any(cfg in lower_p for cfg in config_files):
                    remaining_p = lower_p
                    for cfg in config_files:
                        remaining_p = remaining_p.replace(cfg, "")
                    is_data = any(ext in remaining_p for ext in data_extensions)

                # 1. Direct Route for Data (Highest Priority - Bypass folder check)
                if is_data:
                    return "data-analysis"

                # 2. Resolve Skills Directory Path (Absolute)
                # Check standard installation location
                project_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
                skills_dir = os.path.join(project_root, "skills")
                
                # Fallback for editable install/standard package layout
                if not os.path.exists(skills_dir):
                    # Check if skills is inside nova_cli (some distribution styles)
                    skills_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))), "skills")

                available_skills = []
                if os.path.exists(skills_dir):
                    available_skills = [d for d in os.listdir(skills_dir) if os.path.isdir(os.path.join(skills_dir, d))]

                if not available_skills:
                    return None

                # 2. Stage 1 — Web Build Gatekeeper
                api = BridgeyeAPIClient()
                if "frontend-web" in available_skills:
                    gate_prompt = (
                        "TASK: CLASSIFY_WEB_BUILD\n"
                        "Analyze if the user is asking to build a website, landing page, web page, or web UI.\n"
                        "Output EXACTLY a valid JSON object with a single boolean key 'is_web_build'.\n"
                        f"USER REQUEST: {prompt_text}"
                    )
                    try:
                        # Removed invalid current_task kwarg
                        gate_resp = api.chat(prompt=gate_prompt, context={}, model="openai/gpt-oss-120b", provider="openrouter", repo_map="")
                        if "true" in gate_resp.lower() and "is_web_build" in gate_resp:
                            return "frontend-web"
                    except Exception:
                        pass

                # 3. AI Classifier for non-data skills (Fallback)
                classifier_prompt = (
                    "TASK: CLASSIFY_INTENT\n"
                    f"Classify this request into one of these available skills: {available_skills}.\n"
                    "If no clear match, return 'NONE'. Output ONLY the word.\n\n"
                    f"REQUEST: {prompt_text}"
                )
                try:
                    # Removed invalid current_task kwarg
                    response = api.chat(prompt=classifier_prompt, context={}, model=config.DEFAULT_MODEL, provider="openrouter", repo_map="")
                    match = response.strip()
                    return match if match in available_skills else None
                except Exception:
                    return None

    def _execute_skill_flow(self, skill_name: str, prompt_text: str, override_model: str = None):
                """Executes the strict skill flow using the localized component data."""
                
                # Delegate to dedicated orchestrator for frontend-web
                if skill_name == "frontend-web":
                    from rich.panel import Panel
                    self.interface.print()
                    self.interface.print(Panel(
                        "[bold white]Your NOVA Web Developer is here.[/bold white]\n[dim]Analyzing requirements and preparing your website blueprint...[/dim]",
                        title="[bold magenta]NOVA The Builder ACTIVE[/bold magenta]",
                        border_style="magenta",
                        expand=False
                        ))
                        
                    import importlib.util
                    project_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
                    builder_path = os.path.join(project_root, "skills", "frontend-web", "builder.py")
                    
                    # Fallback path if installed as editable package
                    if not os.path.exists(builder_path):
                        builder_path = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "skills", "frontend-web", "builder.py")

                    if os.path.exists(builder_path):
                        spec = importlib.util.spec_from_file_location("web_builder", builder_path)
                        web_builder = importlib.util.module_from_spec(spec)
                        sys.modules["web_builder"] = web_builder
                        spec.loader.exec_module(web_builder)
                        
                        # Pre-build Context generation
                        self._step_start("Preparing project context...")
                        from nova_cli.local.contextifier import run_contextify
                        run_contextify(os.getcwd(), save_to_disk=True)
                        self._step_ok("Project context ready.")

                        modified_files = web_builder.run(user_prompt=prompt_text)
                        
                        # Contextify and Auto-Run (Mirroring standard build flow)
                        if modified_files:
                            self._step_start("Web build applied. Refreshing project context...")
                            from nova_cli.local.contextifier import run_contextify
                            new_context = run_contextify(os.getcwd(), save_to_disk=True)
                            self.state.loaded_files.update(new_context)
                            for rel_path in new_context.keys():
                                abs_p = os.path.abspath(rel_path).replace("\\", "/")
                                self.state.loaded_paths[os.path.basename(rel_path)] = abs_p
                            self._step_ok("Project context updated.")
                            
                            # Determine entry point to run
                            entry_point = None
                            for f in modified_files:
                                if isinstance(f, str) and f.endswith("index.html"):
                                    entry_point = f
                                    break
                            if not entry_point and modified_files:
                                entry_point = modified_files[0]
                                
                            if isinstance(entry_point, str) and not entry_point.startswith("DELETED:"):
                                self.interface.print(f"\n[bold green]>> Automatically running {os.path.basename(entry_point)}...[/bold green]")
                                self.cmd_run(entry_point)

                    else:
                        self.interface.print("[red]>> Skill execution failed: builder.py not found in frontend-web.[/red]")
                    return

                import subprocess
                import questionary
                self.interface.print(f"[cyan]>> Initiating Skill Protocol: {skill_name}[/cyan]")
                
                # Resolve Absolute Path to Skills Folder
                project_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
                skill_dir = os.path.join(project_root, "skills", skill_name)
                
                # Site-packages / Package-internal fallback
                if not os.path.exists(skill_dir):
                    skill_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))), "skills", skill_name)

                target_md_filename = "SKILL.md"
                analysis_mode = "simple"
                
                # NEW: Data Analysis Interactive Menu
                if skill_name == "data-analysis":
                    import questionary
                    choice_main = questionary.select(
                        "How would you like to analyze this data?",
                        choices=["1. Simple Analysis with interpretation", "2. Dashboard"]
                    ).ask()
                    
                    if choice_main and "2. Dashboard" in choice_main:
                        choice_dash = questionary.select(
                            "Which dashboard technology should NOVA use?",
                            choices=["1. Streamlit", "2. Browser based (Html, css, js)"]
                        ).ask()
                        
                        if choice_dash and "1. Streamlit" in choice_dash:
                            target_md_filename = "streamlit_da_dashaboard.md"
                            analysis_mode = "streamlit"
                        elif choice_dash and "2. Browser based" in choice_dash:
                            target_md_filename = "dashboard.md"
                            analysis_mode = "browser"

                    # Determine dynamic subtext
                    if analysis_mode == "streamlit":
                        analyst_subtext = "Profiling dataset(s) and preparing your Streamlit executive dashboard..."
                    elif analysis_mode == "browser":
                        analyst_subtext = "Profiling dataset(s) and preparing your Browser-based executive dashboard..."
                    else:
                        analyst_subtext = "Profiling dataset(s) and preparing your comprehensive analysis..."

                    from rich.panel import Panel
                    self.interface.print()
                    self.interface.print(Panel(
                        f"[bold white]Your NOVA Data Analyst is here.[/bold white]\n[dim]{analyst_subtext}[/dim]",
                        title="[bold cyan]NOVA Data Analyst ACTIVE[/bold cyan]",
                        border_style="cyan",
                        expand=False
                    ))

                skill_md_path = os.path.abspath(os.path.join(skill_dir, target_md_filename))
                pipeline_path = os.path.abspath(os.path.join(skill_dir, "pipeline.py"))
                
                if not os.path.exists(skill_md_path):
                    self.interface.print(f"[red]>> Skill execution failed: {skill_md_path} not found.[/red]")
                    return
                    
                self._step_start(f"Loading {skill_name} component context...")
                skill_context = {}
                with open(skill_md_path, "r", encoding="utf-8") as f:
                    skill_context[target_md_filename] = f.read()
                    
                # Execute pipeline.py to extract JSON data
                if os.path.exists(pipeline_path):
                    self._step_start(f"Executing {skill_name} pipeline preprocessing...")
                    
                    # 1. Extract and Validate Target File(s)
                    import re
                    file_matches = re.findall(r'[\w\.\-/]+\.(?:csv|xlsx|json|parquet|xls)', prompt_text)
                    target_files = []
                    
                    # Check if any matches exist physically on disk
                    for match in file_matches:
                        clean_match = match.strip("'\"")
                        if os.path.exists(clean_match) and clean_match not in target_files:
                            target_files.append(clean_match)
                    
                    if not target_files:
                        self._step_fail("Data Analysis Aborted.")
                        msg = f"NOVA couldn't find the data file '{file_matches[0]}' in your current folder." if file_matches else "No supported data file (.csv, .xlsx, etc.) was detected in your request."
                        self.interface.display_error(msg, title="File Not Found")
                        return

                    # 2. Execute Data Pipeline for all files
                    files_str = ", ".join(target_files)
                    self._step_start(f"Profiling dataset(s): {files_str}")
                    pipeline_args = [sys.executable, pipeline_path] + target_files

                    try:
                        result = subprocess.run(
                            pipeline_args,
                            cwd=os.getcwd(),
                            capture_output=True,
                            text=True
                        )
                        if result.returncode == 0:
                            skill_context["pipeline_output.json"] = result.stdout
                            self._step_ok(f"Dataset(s) '{files_str}' profiled successfully.")
                        else:
                            self._step_fail(f"Pipeline execution failed for '{files_str}'.")
                            self.interface.print(f"[red]Error:[/red] {result.stderr or result.stdout}")
                            return # Hard stop if profiling fails
                    except Exception as e:
                        self._step_fail(f"Critical error running pipeline: {e}")
                        return
                        
                self._step_ok(f"Context loaded for {skill_name}.")
                
                # Enforce Kimi k2.6 for Skill Execution
                target_model = "moonshotai/kimi-k2.6"
                target_provider = "openrouter"
                
                # Display the Purple Upgrade Banner
                self.interface.display_coding_mode(target_model)
                
                skill_prompt = (
                    f"SYSTEM_OVERRIDE: You are executing the '{skill_name}' skill.\n"
                    f"Strictly follow the rules, intent triggers, and instructions defined in the provided {target_md_filename} context.\n"
                    "Use the provided pipeline_output.json data to fulfill the request. Always use the exact [CREATE: filename.ext] syntax to output files.\n"
                    f"CRITICAL: The target data file(s) are located at: {', '.join(target_files)}. You MUST write the code to load and combine these exact files dynamically in your dashboard.\n\n"
                    f"USER_REQUEST: {prompt_text}"
                )
                
                self.interface.print(f"[cyan]>> NOVA is processing the {skill_name} request...[/cyan]")
                api = BridgeyeAPIClient()
                
                # Stream the reasoning and output
                output = self.interface.stream_rich_response(
                    api.chat_stream(
                        prompt=skill_prompt,
                        context=skill_context,
                        model=target_model,
                        provider=target_provider,
                        repo_map=prompts.get_repo_map_cached(os.getcwd())
                    )
                )
                
                if not output:
                    self._step_fail("No response received from Skill Execution.")
                    return
                    
                self.state.last_ai_response = output
                
                # 3. Parse [CREATE] tags, save file, and trigger execution
                modified_files = handle_ai_commands(output)
                
                if modified_files:
                    prompts.clear_file_tree_cache()
                    
                    if analysis_mode == "streamlit":
                        # Dashboard Execution Phase (Streamlit)
                        for fpath in modified_files:
                            if isinstance(fpath, str) and fpath.endswith(".py") and not fpath.startswith("DELETED:"):
                                self.interface.print(f"[bold green]>> Auto-running Streamlit Dashboard: {os.path.basename(fpath)}...[/bold green]")
                                self.cmd_run(fpath)
                                break
                    elif analysis_mode == "browser":
                        # Dashboard Execution Phase (HTML/JS)
                        for fpath in modified_files:
                            if isinstance(fpath, str) and fpath.endswith((".html", ".htm")) and not fpath.startswith("DELETED:"):
                                self.interface.print(f"[bold green]>> Auto-running Browser Dashboard: {os.path.basename(fpath)}...[/bold green]")
                                self.cmd_run(fpath)
                                break
                    else:
                        # Simple Analysis Execution Phase
                        for fpath in modified_files:
                            if isinstance(fpath, str) and fpath.endswith(".py") and not fpath.startswith("DELETED:"):
                                self.interface.print(f"[bold green]>> Auto-running generated skill script: {os.path.basename(fpath)}...[/bold green]")
                                
                                ensure_dependencies(fpath)

                                # Capture the output for interpretation
                                import subprocess
                                from nova_cli.local.healer.runner import run_with_healing
                                
                                try:
                                    # Use run_with_healing to ensure the file works, then capture final output
                                    execution_result = run_with_healing(
                                        command_args=[sys.executable, fpath],
                                        cwd=os.getcwd(),
                                        model=target_model,
                                        provider=target_provider,
                                        context=self.state.loaded_files
                                    )
                                    
                                    # --- INTERPRETATION PHASE (Groq 120b) ---
                                    if execution_result:
                                        self.interface.print("\n[bold cyan]• NOVA is interpreting the analysis results...[/bold cyan]")
                                        interpret_prompt = (
                                            "SYSTEM_OVERRIDE: You are a Lead Data Scientist.\n"
                                            f"The following is the terminal output from a data analysis script run on {', '.join(target_files)}.\n"
                                            "Interpret the numbers, trends, and quality flags. Provide a high-level executive summary.\n\n"
                                            f"TERMINAL_OUTPUT:\n{execution_result}"
                                        )
                                        
                                        self.interface.stream_rich_response(
                                            api.chat_stream(
                                                prompt=interpret_prompt,
                                                context={},
                                                model="openai/gpt-oss-120b",
                                                provider="openrouter"
                                            )
                                        )
                                except Exception as e:
                                    self.interface.print(f"[red]Execution interpretation failed: {e}[/red]")
                                break
                else:
                    self._step_warn("No files were created or modified by the AI. Check if [CREATE] tags were missing in the response.")
