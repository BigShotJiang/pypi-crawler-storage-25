import os
import re

from nova_cli import config
def extract_enhanced_prompt(raw_output: str) -> str:
        import re
        # Strip model special tokens e.g. <|end|>, <|start|>, <|channel|>
        raw_output = re.sub(r'<\|[^|>]*\|>', '', raw_output)
        # Case 1: Both tags present
        matches = re.findall(r"<enhanced_prompt\s*>(.*?)</enhanced_prompt\s*>", raw_output, re.DOTALL | re.IGNORECASE)
        if matches:
            return matches[-1].strip()
        # Case 2: Opening tag only
        match = re.search(r".*<enhanced_prompt\s*>(.*)", raw_output, re.DOTALL | re.IGNORECASE)
        if match:
            return match.group(1).strip()
        # Case 3: No tags — thinking uses plain "Task:", actual content uses **Task** (bold)
        idx = raw_output.find('**Task**')
        if idx != -1:
            return raw_output[idx:].strip()
        return raw_output.strip()
class ShellUIUtilsMixin:
    

    def get_prompt_text(self):
            prefix = ""
            if self.state.active_file:
                prefix = f"[dim]({os.path.basename(self.state.active_file)})[/dim] "
            if len(self.state.loaded_files) > 0:
                prefix += f"[dim][{len(self.state.loaded_files)} loaded][/dim] "
            
            # Color changes to RED in overdrive mode
            prompt_color = "bold red" if config.OVERDRIVE else "bold cyan"
            overdrive_indicator = "[bold red]O[/bold red] " if config.OVERDRIVE else ""
            
            return f"{prefix}{overdrive_indicator}[{prompt_color}]spark terminal >[/{prompt_color}]  "

    def _step_start(self, message: str):
            self.interface.print(f"[cyan]• {message}[/cyan]")

    def _step_ok(self, message: str):
            self.interface.print(f"[green]✓ {message}[/green]")

    def _step_warn(self, message: str):
            self.interface.print(f"[yellow]⚠ {message}[/yellow]")

    def _step_fail(self, message: str):
            self.interface.print(f"[red]✗ {message}[/red]")

    def scan_and_load_context(self, text):
                potential_files = re.findall(r"\b[\w\-\/]+\.\w+\b", text)

                loaded_any = False
                for fname in potential_files:
                    if os.path.exists(fname) and os.path.isfile(fname):
                        try:
                            abs_path = os.path.abspath(fname).replace("\\", "/")
                            base = os.path.basename(fname)

                            with open(fname, "r", encoding="utf-8") as f:
                                self.state.loaded_files[base] = f.read()
                            self.state.loaded_paths[base] = abs_path

                            if not self.state.active_file:
                                self.state.active_file = abs_path

                            loaded_any = True
                        except Exception:
                            pass

                if self.state.active_file and os.path.exists(self.state.active_file):
                    try:
                        base = os.path.basename(self.state.active_file)
                        with open(self.state.active_file, "r", encoding="utf-8") as f:
                            self.state.loaded_files[base] = f.read()
                        self.state.loaded_paths[base] = os.path.abspath(self.state.active_file).replace("\\", "/")
                    except Exception:
                        pass

                if loaded_any:
                    self.interface.print("[dim]>> Auto-loaded file context for AI visibility.[/dim]") 