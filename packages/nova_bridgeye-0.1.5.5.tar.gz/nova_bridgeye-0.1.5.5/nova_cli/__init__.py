import importlib.metadata

try:
    # Dynamically fetch the version installed via pip
    __version__ = importlib.metadata.version("nova-bridgeye")
except importlib.metadata.PackageNotFoundError:
    # Fallback if running from source without installing
    __version__ = "0.1.5.2"