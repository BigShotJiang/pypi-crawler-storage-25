# NOVA-CLI\nova_cli\nova_core\ai\api_client.py

import os
import requests
from typing import List, Optional, Dict, Any, Iterator
import json

from nova_cli.nova_core.auth.storage import (
    get_access_token,
    get_refresh_token,
    update_tokens,
)
from nova_cli.nova_core.auth.client import NovaAuthClient


class BridgeyeAPIClient:
    """
    Thin HTTP client used by Nova CLI.
    This client contains NO AI logic.
    """

    def __init__(self, base_url: Optional[str] = None, timeout: int = 1200):
        env_url = os.getenv("NOVA_API_BASE_URL")
        self.base_url = (base_url or env_url or "https://api.nova.bridgeye.com").rstrip("/")
        self.timeout = timeout
        self._last_refresh_error: Optional[Dict[str, Any]] = None

        self.user_agent = os.getenv("NOVA_USER_AGENT", "NovaCLI/1.0")
        # Set NOVA_DEBUG_AUTH=1 if you want verbose auth errors locally
        self.debug_auth = os.getenv("NOVA_DEBUG_AUTH", "").strip() in ("1", "true", "TRUE", "yes", "YES")

    def _headers(self) -> Dict[str, str]:
        headers: Dict[str, str] = {"User-Agent": self.user_agent}
        tok = get_access_token()
        if tok:
            headers["Authorization"] = f"Bearer {tok}"
        return headers

    def _debug(self, msg: str) -> None:
        if not self.debug_auth:
            return
        try:
            print(msg)
        except Exception:
            pass

    def _try_refresh(self) -> bool:
        rt = get_refresh_token()
        if not rt:
            self._last_refresh_error = {"kind": "no_refresh_token_on_disk"}
            return False

        auth = NovaAuthClient()
        resp = auth.refresh_access(rt)

        if not isinstance(resp, dict):
            self._last_refresh_error = {"kind": "refresh_bad_response_type", "type": str(type(resp))}
            self._debug(f"[auth] refresh failed: {self._last_refresh_error}")
            return False

        if resp.get("error"):
            self._last_refresh_error = {
                "kind": resp.get("error"),
                "status": resp.get("status"),
                "body": resp.get("body"),
            }
            self._debug(f"[auth] refresh failed: {self._last_refresh_error}")
            return False

        new_access = resp.get("access_token")
        new_refresh = resp.get("refresh_token")
        expires_in = resp.get("expires_in")
        issued_at = resp.get("issued_at")

        if not new_access or not new_refresh or not expires_in:
            self._last_refresh_error = {
                "kind": "refresh_missing_fields",
                "has_access": bool(new_access),
                "has_refresh": bool(new_refresh),
                "expires_in": expires_in,
            }
            self._debug(f"[auth] refresh failed: {self._last_refresh_error} resp={resp}")
            return False

        update_tokens(
            access_token=new_access,
            refresh_token=new_refresh,
            expires_in=int(expires_in),
            issued_at=float(issued_at) if issued_at else None,
        )

        self._last_refresh_error = None
        return True

    def _require_auth(self) -> str:
        tok = get_access_token()
        if tok:
            return tok

        if self._try_refresh():
            tok = get_access_token()
            if tok:
                return tok

        # Prettified Auth Error (Consistent with _parse_json)
        raise RuntimeError("Your session has expired or is invalid. Please run [bold]nova login[/bold] to continue.")

    def _post_with_auth_retry(self, path: str, payload: Dict[str, Any]) -> requests.Response:
        self._require_auth()
        url = f"{self.base_url}{path}"

        try:
            resp = requests.post(
                url,
                json=payload,
                headers=self._headers(),
                timeout=self.timeout,
            )
        except (requests.exceptions.ConnectionError, requests.exceptions.Timeout):
            raise RuntimeError("Please check your internet connection. NOVA is unable to reach the server.")
        except requests.RequestException:
            raise RuntimeError("Network instability detected. Please check your internet and try again.")

        if resp.status_code != 401:
            return resp

        if self._try_refresh():
            try:
                resp = requests.post(
                    url,
                    json=payload,
                    headers=self._headers(),
                    timeout=self.timeout,
                )
            except requests.RequestException as e:
                raise RuntimeError(f"API request failed after refresh: {e}")

        return resp

    def _get_with_auth_retry(self, path: str) -> requests.Response:
        self._require_auth()
        url = f"{self.base_url}{path}"

        try:
            resp = requests.get(
                url,
                headers=self._headers(),
                timeout=self.timeout,
            )
        except requests.RequestException as e:
            raise RuntimeError(f"API request failed: {e}")

        if resp.status_code != 401:
            return resp

        if self._try_refresh():
            try:
                resp = requests.get(
                    url,
                    headers=self._headers(),
                    timeout=self.timeout,
                )
            except requests.RequestException as e:
                raise RuntimeError(f"API request failed after refresh: {e}")

        return resp

    def _parse_json(self, resp: requests.Response) -> Dict[str, Any]:
        if resp.status_code == 402:
            raise RuntimeError("Usage limit reached. Please check your account credits.")
        
        if resp.status_code == 401:
            raise RuntimeError("Your session has expired. Please run [bold]login[/bold] to continue.")

        if resp.status_code in (413, 429):
            raise RuntimeError("The selected model is currently at capacity. Please try again or switch models using [bold cyan]:model[/bold cyan].")

        if resp.status_code in (500, 502, 503, 504):
            raise RuntimeError("Connection error. The server is unreachable or timed out. Please try again in a few seconds.")

        try:
            data = resp.json()
            if isinstance(data, dict) and not data.get("success", True):
                err_msg = data.get("error", "").lower()
                if any(k in err_msg for k in ["rate_limit", "tpm", "tokens"]):
                    raise RuntimeError("Model capacity reached. Please switch models using [bold cyan]:model[/bold cyan].")
                # If error exists in JSON but isn't recognized, return a clean generic message
                raise RuntimeError("An internal process error occurred. Please try again.")
            return data
        except (ValueError, KeyError):
            raise RuntimeError("Invalid response from server. Please check your network and try again.")

    def health(self) -> bool:
        """
        Simple reachability check for NOVA_API.
        Assumes NOVA_API exposes GET /health -> 200 OK.
        """
        url = f"{self.base_url}/health"
        try:
            r = requests.get(url, timeout=10, headers={"User-Agent": self.user_agent})
            return r.status_code == 200
        except Exception:
            return False

    def chat(self, prompt: str, context: Optional[Dict[str, str]], model: str, provider: str, repo_map: Optional[str] = None, active_file: Optional[str] = None) -> str:
        """
        Calls NOVA_API chat endpoint with optional repository map.
        """
        payload = {
            "prompt": prompt,
            "context": context or {},
            "model": model,
            "provider": provider,
            "repo_map": repo_map,
            "active_file": active_file
        }

        tried: List[str] = []
        last_error: Optional[str] = None

        for path in ("/chat", "/chat/run"):
            tried.append(path)
            resp = self._post_with_auth_retry(path, payload)

            if resp.status_code == 401:
                raise RuntimeError("Unauthorized. Run: login")

            if resp.status_code == 404:
                last_error = f"404 on {path}"
                continue

            resp.raise_for_status()
            data = self._parse_json(resp)

            if not data.get("success"):
                raise RuntimeError(data.get("error") or "Chat failed")

            return data.get("output", "") or ""

        raise RuntimeError(
            f"Chat endpoint not found. Tried: {', '.join(tried)}. Last error: {last_error or 'unknown'}"
        )

    def enhance_prompt(
        self,
        user_prompt: str,
        model: str,
        provider: str,
        current_enhanced_prompt: Optional[str] = None,
        edit_request: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        Calls NOVA_API prompt enhancement endpoint.

        Supports:
        - initial prompt enhancement
        - revision enhancement with edit instructions
        """

        payload = {
            "user_prompt": user_prompt,
            "model": model,
            "provider": provider,
            "current_enhanced_prompt": current_enhanced_prompt,
            "edit_request": edit_request,
        }

        resp = self._post_with_auth_retry("/prompt/enhance", payload)

        if resp.status_code == 401:
            raise RuntimeError("Unauthorized. Run: login")

        resp.raise_for_status()
        data = self._parse_json(resp)

        if not data.get("success"):
            raise RuntimeError(data.get("error") or "Prompt enhancement failed")

        return data
    
    def validate_plan(
        self,
        plan_content: str,
        model: str,
        provider: str,
    ) -> Dict[str, Any]:
        """
        Calls NOVA_API plan validation endpoint.

        Returns:
            {
                "success": bool,
                "is_valid": bool,
                "improved_plan": Optional[str],
                "error": Optional[str]
            }
        """
        payload = {
            "plan_content": plan_content,
            "model": model,
            "provider": provider,
        }

        resp = self._post_with_auth_retry("/plan/validate", payload)

        if resp.status_code == 401:
            raise RuntimeError("Unauthorized. Run: login")

        resp.raise_for_status()
        data = self._parse_json(resp)

        if not data.get("success"):
            raise RuntimeError(data.get("error") or "Plan validation failed")

        return data
    
    def sync_map(self, repo_map: str) -> bool:
        """Transmits the Project Blueprint to NOVA API."""
        resp = self._post_with_auth_retry("/repo/sync-map", {"repo_map": repo_map})
        return resp.status_code == 200

    def generate_commit_message(
        self,
        diff_text: str,
        model: str,
        provider: str,
    ) -> str:
        """
        Calls NOVA_API commit message generation endpoint.

        Returns:
            str -> generated commit message
        """
        payload = {
            "diff_text": diff_text,
            "model": model,
            "provider": provider,
        }

        resp = self._post_with_auth_retry("/commit/message", payload)

        if resp.status_code == 401:
            raise RuntimeError("Unauthorized. Run: login")

        resp.raise_for_status()
        data = self._parse_json(resp)

        if not data.get("success"):
            raise RuntimeError(data.get("error") or "Commit message generation failed")

        return data.get("commit_message", "") or ""


    def refactor(self, filename: str, content: str, model: str, provider: str, repo_map: Optional[str] = None) -> str:
        resp = self._post_with_auth_retry(
            "/janitor/refactor",
            {"filename": filename, "content": content, "model": model, "provider": provider, "repo_map": repo_map},
        )

        if resp.status_code == 401:
            raise RuntimeError("Unauthorized. Run: login")

        resp.raise_for_status()
        data = self._parse_json(resp)

        if not data.get("success"):
            raise RuntimeError(data.get("error") or "Janitor failed")

        return data.get("output", "")

    def run_with_healing(
        self,
        command: List[str],
        cwd: str,
        model: str,
        provider: str,
        exit_code: int,
        stdout: str,
        stderr: str,
        context: Optional[dict] = None,
        repo_map: Optional[str] = None,
        healing_history: Optional[List[str]] = None,
    ) -> str:
        payload = {
            "command": command,
            "cwd": cwd,
            "model": model,
            "provider": provider,
            "exit_code": exit_code,
            "stdout": stdout or "",
            "stderr": stderr or "",
            "context": context or {},
            "repo_map": repo_map,
            "healing_history": healing_history or [],
        }

        tried: List[str] = []
        last_error: Optional[str] = None

        for path in ("/healer/run", "/healer"):
            tried.append(path)
            resp = self._post_with_auth_retry(path, payload)

            if resp.status_code == 401:
                raise RuntimeError("Unauthorized. Run: login")

            if resp.status_code == 404:
                last_error = f"404 on {path}"
                continue

            resp.raise_for_status()
            data = self._parse_json(resp)

            if not data.get("success"):
                raise RuntimeError(data.get("error") or "Healer failed")

            return data.get("output", "") or ""

        raise RuntimeError(
            f"Healer endpoint not found. Tried: {', '.join(tried)}. Last error: {last_error or 'unknown'}"
        )
    
    def create_github_repo(
        self,
        repo_name: str,
        private: bool = False,
        description: Optional[str] = None,
    ) -> Dict[str, Any]:
            """
            Calls NOVA_API to create a GitHub repository for the authenticated user.
            """

            payload = {
                "repo_name": repo_name,
                "private": private,
                "description": description,
            }

            resp = self._post_with_auth_retry("/github/create-repo", payload)

            if resp.status_code == 401:
                raise RuntimeError("Unauthorized. Run: login")

            resp.raise_for_status()
            data = self._parse_json(resp)

            if not data.get("ok"):
                raise RuntimeError(data.get("detail") or "GitHub repo creation failed")

            return data
    def chat_stream(
        self,
        prompt: str,
        context: Optional[Dict[str, str]],
        model: str,
        provider: str,
        repo_map: Optional[str] = None,
        active_file: Optional[str] = None,
    ) -> Iterator[Dict[str, Any]]:
        """
        Calls NOVA_API streaming chat endpoint and yields SSE events.
        """
        payload = {
            "prompt": prompt,
            "context": context or {},
            "model": model,
            "provider": provider,
            "repo_map": repo_map,
            "active_file": active_file
        }

        self._require_auth()
        url = f"{self.base_url}/chat/stream"

        try:
            resp = requests.post(
                url,
                json=payload,
                headers=self._headers(),
                timeout=self.timeout,
                stream=True,
            )
        except (requests.exceptions.ConnectionError, requests.exceptions.Timeout):
            raise RuntimeError("Build stream interrupted. Please check your internet connection.")
        except requests.RequestException:
            raise RuntimeError("Network failure during build. Check your internet and try again.")

        if resp.status_code == 401:
            if self._try_refresh():
                try:
                    resp = requests.post(
                        url,
                        json=payload,
                        headers=self._headers(),
                        timeout=self.timeout,
                        stream=True,
                    )
                except requests.RequestException as e:
                    raise RuntimeError(f"Streaming API request failed after refresh: {e}")

        if resp.status_code == 401:
            raise RuntimeError("Unauthorized. Run: login")

        if resp.status_code >= 400:
            # Map technical status codes to clean human messages
            if resp.status_code == 403:
                msg = "Access denied. Please check your internet connection or login status."
            elif resp.status_code in (500, 502, 503, 504):
                msg = "The server is currently unreachable. Please check your internet connection and try again."
            elif resp.status_code == 401:
                msg = "Session expired. Please run 'nova login' to re-authenticate."
            elif resp.status_code == 402:
                msg = "Usage limit reached. Please upgrade your plan by visiting [bold cyan][link=https://nova.bridgeye.com/plans]https://nova.bridgeye.com/plans[/link][/bold cyan]"
            else:
                msg = "A connection error occurred. Please try again shortly."
            
            # Raise only the clean message, exposing no codes or JSON
            raise RuntimeError(msg)

        for raw_line in resp.iter_lines(decode_unicode=True):
            if not raw_line:
                continue

            line = raw_line.strip()
            if not line.startswith("data: "):
                continue

            data_str = line[len("data: "):].strip()
            if not data_str:
                continue

            try:
                yield json.loads(data_str)
            except Exception:
                yield {"type": "error", "error": f"Invalid stream payload: {data_str}"}
