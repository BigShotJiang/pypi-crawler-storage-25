---
name: data-analysis
description: Data profiling, analysis, cleaning, and visualisation using pipeline.py for automated dataset profiling followed by LLM-generated, NOVA-executed Python code.
origin: NOVA
---

# Data Analysis Skill

End-to-end skill for understanding, analysing, and transforming datasets. Automatically profiles the input file, interprets the profile, and generates runnable Python code to answer the user's request.

## When to Activate

- User provides a file and asks to analyse, explore, or summarise it
- User asks what analyses are possible on their data
- User asks to clean, fix, or prepare their data
- User asks to visualise any aspect of their data
- User asks to find patterns, outliers, correlations, or trends
- User asks a specific question about their dataset (e.g. "which column has the most nulls?")
- User asks to filter, group, aggregate, or transform their data

## Core Skill Flow

### Step 1 — Run the profiler

Always run `pipeline.py` first on the provided file before doing anything else. This gives the LLM accurate, data-specific context rather than assumptions.

```bash
python skills/data-analysis/pipeline.py <file_path>
```

The output is a JSON profile covering shape, column types, nulls, distributions, outliers, correlations, and quality flags.

### Step 2 — Build the LLM prompt

Combine three inputs into one prompt:

```
[SKILL.md instructions]
+
[pipeline.py JSON output]
+
[User's original query]
```

The LLM uses the JSON profile to write code that is accurate for the actual dataset — correct column names, correct dtypes, no hallucinated columns.

### Step 3 — Generate summary + code

The LLM response must always have two parts:

**Part 1 — Data summary** (plain text, always present regardless of query)

**Part 2 — Analysis code** (Python, directly runnable by NOVA)

### Step 4 — NOVA executes the code

NOVA runs the generated code. If it fails, NOVA automatically fixes and reruns until execution succeeds or the retry limit is reached.

---

## Response Format

Every response must follow this exact structure:

```
## Data summary
One paragraph: dataset size, column breakdown by type, notable quality issues from flags[].

## Key observations
- Nulls: list columns with null_pct > 0, sorted by severity
- Distributions: skew, outliers, ranges worth calling out
- Data quality: flags from pipeline output (duplicates, constants, ID columns)
- Correlations: pairs from high_correlations[] if present

## What I'm doing
One sentence: what the code below does, in plain language.

## Code
\`\`\`python
# clean, commented, runnable Python
\`\`\`

## Output interpretation
Brief explanation of how to read the output once the code runs.
```

**Rules:**
- Never skip the data summary, even for simple queries
- Always surface quality flags before analysis — bad data should be acknowledged first
- Code must use only column names that exist in `columns[].name` from the profile
- Code must respect dtypes from the profile (don't treat a string column as numeric)

---

## Code Generation Rules

### Imports

Always include all required imports inside the generated code block. NOVA runs the code in isolation.

```python
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from pathlib import Path
```

### File loading

Always use the same file path the user provided. Use the extension from `file.extension` in the profile to load correctly.

```python
# CSV
df = pd.read_csv("path/to/file.csv")

# Excel
df = pd.read_excel("path/to/file.xlsx", sheet_name=0)

# JSON
df = pd.read_json("path/to/file.json")

# Parquet
df = pd.read_parquet("path/to/file.parquet")
```

### Column name safety

Always reference column names using bracket notation, not dot notation, to handle spaces and special characters.

```python
# Correct
df["column name with spaces"]

# Incorrect — will fail
df.column name with spaces
```

### Dtype handling

Check the `col_type` field from the profile before operating on a column.

```python
# Numeric operations only on col_type: numeric
df["sales"].mean()

# String operations only on col_type: categorical or text
df["category"].value_counts()

# Date operations only on col_type: datetime
df["date"].dt.year
```

### Visualisations

Save plots to file, never use `plt.show()` — NOVA runs headlessly.

```python
plt.figure(figsize=(10, 6))
sns.histplot(df["column"], kde=True)
plt.title("Distribution of column")
plt.tight_layout()
plt.savefig("output_plot.png", dpi=150)
plt.close()
```

### Cleaning operations

When cleaning, always create a copy and report what was changed.

```python
df_clean = df.copy()

# Drop high-null columns (> 50%)
high_null_cols = ["col_a", "col_b"]
df_clean = df_clean.drop(columns=high_null_cols)

# Fill numeric nulls with median
df_clean["revenue"] = df_clean["revenue"].fillna(df_clean["revenue"].median())

# Drop duplicates
before = len(df_clean)
df_clean = df_clean.drop_duplicates()
print(f"Removed {before - len(df_clean)} duplicate rows")

# Save cleaned file
df_clean.to_csv("cleaned_output.csv", index=False)
print(f"Cleaned dataset: {df_clean.shape[0]} rows x {df_clean.shape[1]} cols")
```

---

## Common Patterns

### Exploratory analysis

```python
import pandas as pd

df = pd.read_csv("data.csv")

# Overview
print(f"Shape: {df.shape}")
print(f"\nDtypes:\n{df.dtypes}")
print(f"\nNull counts:\n{df.isnull().sum()}")
print(f"\nDescriptive stats:\n{df.describe()}")
```

### Correlation matrix

```python
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt

df = pd.read_csv("data.csv")
numeric_df = df.select_dtypes(include="number")

plt.figure(figsize=(12, 8))
sns.heatmap(numeric_df.corr(), annot=True, fmt=".2f", cmap="coolwarm", center=0)
plt.title("Correlation matrix")
plt.tight_layout()
plt.savefig("correlation_matrix.png", dpi=150)
plt.close()
```

### Outlier detection and removal

```python
import pandas as pd
import numpy as np

df = pd.read_csv("data.csv")

def remove_outliers_iqr(df, col):
    q1 = df[col].quantile(0.25)
    q3 = df[col].quantile(0.75)
    iqr = q3 - q1
    mask = (df[col] >= q1 - 1.5 * iqr) & (df[col] <= q3 + 1.5 * iqr)
    removed = (~mask).sum()
    print(f"'{col}': removed {removed} outliers")
    return df[mask]

for col in df.select_dtypes(include="number").columns:
    df = remove_outliers_iqr(df, col)
```

### Group-by aggregation

```python
import pandas as pd

df = pd.read_csv("data.csv")

result = (
    df.groupby("category_col")
    .agg(
        count=("value_col", "count"),
        mean=("value_col", "mean"),
        total=("value_col", "sum"),
    )
    .sort_values("total", ascending=False)
    .reset_index()
)

print(result.to_string(index=False))
```

### Missing value summary

```python
import pandas as pd

df = pd.read_csv("data.csv")

null_summary = (
    pd.DataFrame({
        "null_count": df.isnull().sum(),
        "null_pct": (df.isnull().mean() * 100).round(2),
        "dtype": df.dtypes,
    })
    .query("null_count > 0")
    .sort_values("null_pct", ascending=False)
)

print(null_summary.to_string())
```

---

## Reading the Pipeline JSON

Key fields to use when writing code:

| Field | How to use |
|---|---|
| `shape.rows` / `shape.cols` | Report dataset size in summary |
| `columns[].name` | Use exact names in code — never guess |
| `columns[].col_type` | Determines valid operations on that column |
| `columns[].null_pct` | Prioritise in cleaning; mention if > 10% |
| `columns[].skewness` | Flag if abs > 2; suggest log transform |
| `columns[].outlier_pct` | Mention if > 5%; suggest IQR removal |
| `columns[].top_values` | Use for categorical grouping or filtering |
| `columns[].min_date` / `max_date` | Set date range context in summary |
| `high_correlations[]` | Flag multicollinearity; mention in summary |
| `flags[]` | Always surface all flags in key observations |
| `duplicate_pct` | Mention if > 0; recommend drop_duplicates |

---

## Best Practices

### DO

- **Always profile first** — never generate code without running pipeline.py
- **Surface flags first** — quality issues come before any analysis
- **Use exact column names** — copy from `columns[].name` in the profile
- **Save all outputs** — CSVs to file, plots to PNG; NOVA runs headlessly
- **Comment the code** — explain what each block does in one line
- **Handle nulls explicitly** — never assume a column is clean
- **Report changes** — print row counts before and after any filtering or cleaning
- **Respect dtypes** — check col_type before applying numeric or string operations

### DON'T

- **Don't assume column names** — always read them from the profile
- **Don't use plt.show()** — will hang in headless execution
- **Don't skip the summary** — even if the user only asked for code
- **Don't operate on all columns blindly** — filter by col_type first
- **Don't hardcode file paths** — use the path from the user's input
- **Don't generate analysis without data context** — if pipeline fails, ask the user to re-provide the file

---

## Quick Reference

| User asks | What to generate |
|---|---|
| "Analyse this data" | Full summary + descriptive stats code |
| "What can I do with this?" | Summary + list of 5 suggested analyses with code stubs |
| "Clean the data" | Flag-based cleaning code + save to new file |
| "Show me the distribution of X" | Histogram + KDE plot saved to PNG |
| "Find correlations" | Heatmap + high-correlation pairs printed |
| "Find outliers in X" | IQR-based detection + count report |
| "Group by X and sum Y" | groupby aggregation + printed table |
| "How many nulls?" | Null summary table sorted by severity |
| "Remove duplicates" | drop_duplicates + before/after count |
| "What's the date range?" | Min/max from datetime columns in profile |
