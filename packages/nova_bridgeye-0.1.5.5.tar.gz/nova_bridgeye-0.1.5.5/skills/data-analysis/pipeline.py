import sys
import json
import os
import warnings
warnings.filterwarnings('ignore')

import pandas as pd
import numpy as np


# ─── File loading ────────────────────────────────────────────────────────────

def detect_ext(path):
    return os.path.splitext(path)[1].lower()


def load_file(path):
    ext = detect_ext(path)
    meta = {}

    if ext == '.csv':
        try:
            df = pd.read_csv(path, encoding='utf-8')
        except UnicodeDecodeError:
            df = pd.read_csv(path, encoding='latin-1')
            meta['encoding'] = 'latin-1'

    elif ext in ['.xlsx', '.xls']:
        xl = pd.ExcelFile(path)
        sheets = xl.sheet_names
        meta['sheets'] = sheets
        meta['active_sheet'] = sheets[0]
        if len(sheets) > 1:
            meta['note'] = f'{len(sheets)} sheets detected — profiling first sheet only'
        df = pd.read_excel(path, sheet_name=sheets[0])

    elif ext == '.json':
        df = pd.read_json(path)

    elif ext == '.parquet':
        df = pd.read_parquet(path)

    else:
        raise ValueError(f"Unsupported file type: {ext}")

    return df, meta


# ─── Column classification ────────────────────────────────────────────────────

def categorical_threshold(n_rows):
    """
    Returns (ratio_threshold, abs_threshold).
    A column is categorical if unique/total < ratio AND unique count < abs.
    Scales with dataset size so large datasets aren't over-flagged.
    """
    if n_rows < 1_000:
        return 0.05, 20
    elif n_rows < 10_000:
        return 0.05, 50
    elif n_rows < 100_000:
        return 0.03, 100
    else:
        return 0.01, 200


def classify_column(series, n_rows):
    ratio_thresh, abs_thresh = categorical_threshold(n_rows)
    n_unique = series.nunique()
    ratio = n_unique / n_rows if n_rows > 0 else 0

    if pd.api.types.is_bool_dtype(series):
        return 'boolean'

    if pd.api.types.is_datetime64_any_dtype(series):
        return 'datetime'

    if pd.api.types.is_numeric_dtype(series):
        if ratio > 0.9:
            return 'id_numeric'
        return 'numeric'

    if series.dtype == 'object':
        if ratio > 0.9:
            return 'high_cardinality'
        if n_unique <= abs_thresh or ratio <= ratio_thresh:
            return 'categorical'
        return 'text'

    return 'other'


# ─── Column profiling ─────────────────────────────────────────────────────────

def profile_column(name, series, col_type, n_rows):
    p = {
        'name': name,
        'dtype': str(series.dtype),
        'col_type': col_type,
        'null_count': int(series.isnull().sum()),
        'null_pct': round(series.isnull().mean() * 100, 2),
        'unique_count': int(series.nunique()),
        'unique_pct': round(series.nunique() / n_rows * 100, 2) if n_rows > 0 else 0,
    }

    if col_type == 'numeric':
        clean = series.dropna()
        q1, q3 = clean.quantile(0.25), clean.quantile(0.75)
        iqr = q3 - q1
        outliers = int(((clean < q1 - 1.5 * iqr) | (clean > q3 + 1.5 * iqr)).sum())
        p.update({
            'min':           _safe_round(clean.min()),
            'max':           _safe_round(clean.max()),
            'mean':          _safe_round(clean.mean()),
            'median':        _safe_round(clean.median()),
            'std':           _safe_round(clean.std()),
            'q25':           _safe_round(q1),
            'q75':           _safe_round(q3),
            'skewness':      _safe_round(clean.skew()),
            'outlier_count': outliers,
            'outlier_pct':   round(outliers / n_rows * 100, 2) if n_rows > 0 else 0,
        })

    elif col_type == 'categorical':
        top = series.value_counts().head(5)
        p['top_values'] = {str(k): int(v) for k, v in top.items()}

    elif col_type == 'datetime':
        p['min_date'] = str(series.min())
        p['max_date'] = str(series.max())
        p['range_days'] = int((series.max() - series.min()).days) if not series.isnull().all() else None

    elif col_type == 'boolean':
        vc = series.value_counts()
        p['value_counts'] = {str(k): int(v) for k, v in vc.items()}

    elif col_type in ['high_cardinality', 'text']:
        p['sample_values'] = [str(v) for v in series.dropna().head(3).tolist()]

    return p


def _safe_round(val, digits=4):
    try:
        return round(float(val), digits) if not pd.isna(val) else None
    except Exception:
        return None


# ─── Correlation ──────────────────────────────────────────────────────────────

def high_correlations(df, threshold=0.8):
    num_cols = df.select_dtypes(include=[np.number]).columns.tolist()
    if len(num_cols) < 2:
        return []

    corr = df[num_cols].corr()
    pairs = []
    for i in range(len(corr.columns)):
        for j in range(i + 1, len(corr.columns)):
            val = corr.iloc[i, j]
            if abs(val) >= threshold:
                pairs.append({
                    'col_a': corr.columns[i],
                    'col_b': corr.columns[j],
                    'correlation': round(float(val), 4),
                })
    return pairs


# ─── Quality flags ────────────────────────────────────────────────────────────

def build_flags(columns, duplicate_pct):
    flags = []

    for col in columns:
        name = col['name']

        if col['null_pct'] > 50:
            flags.append(f"High nulls in '{name}': {col['null_pct']}%")

        if col['col_type'] == 'id_numeric':
            flags.append(f"Possible ID column (numeric): '{name}' — {col['unique_pct']}% unique values")

        if col['col_type'] == 'high_cardinality':
            flags.append(f"High cardinality column: '{name}' — {col['unique_pct']}% unique values")

        if col['col_type'] == 'numeric':
            skew = col.get('skewness') or 0
            if abs(skew) > 2:
                flags.append(f"High skewness in '{name}': {skew}")
            if col.get('outlier_pct', 0) > 5:
                flags.append(f"Significant outliers in '{name}': {col['outlier_pct']}% of rows")

        if col['unique_count'] == 1:
            flags.append(f"Constant column '{name}': only one unique value")

    if duplicate_pct > 1:
        flags.append(f"Duplicate rows detected: {duplicate_pct}% of dataset")

    return flags


# ─── Main pipeline ────────────────────────────────────────────────────────────

def run(paths):
    output = {}

    # File metadata and Load
    dfs = []
    files_info = []
    for path in paths:
        size = os.path.getsize(path)
        df, file_meta = load_file(path)
        f_info = {
            'name':       os.path.basename(path),
            'extension':  detect_ext(path),
            'size_kb':    round(size / 1024, 2),
        }
        f_info.update(file_meta)
        files_info.append(f_info)
        dfs.append(df)

    output['files'] = files_info
    
    # Combine all dataframes
    df = pd.concat(dfs, ignore_index=True)

    # Try to parse object columns as datetime
    for col in df.select_dtypes(include='object').columns:
        try:
            df[col] = pd.to_datetime(df[col], infer_datetime_format=True)
        except Exception:
            pass

    n_rows, n_cols = df.shape
    dup_count = int(df.duplicated().sum())
    dup_pct = round(dup_count / n_rows * 100, 2) if n_rows > 0 else 0

    output['shape'] = {'rows': n_rows, 'cols': n_cols}
    output['duplicate_rows'] = dup_count
    output['duplicate_pct'] = dup_pct

    # Column profiles
    columns = []
    for col in df.columns:
        col_type = classify_column(df[col], n_rows)
        columns.append(profile_column(col, df[col], col_type, n_rows))

    output['columns'] = columns

    # Column type breakdown
    type_summary = {}
    for col in columns:
        ct = col['col_type']
        type_summary[ct] = type_summary.get(ct, 0) + 1
    output['column_type_summary'] = type_summary

    # Correlations
    output['high_correlations'] = high_correlations(df)

    # Quality flags
    output['flags'] = build_flags(columns, dup_pct)

    return output


# ─── Entry point ──────────────────────────────────────────────────────────────

if __name__ == '__main__':
    if len(sys.argv) < 2:
        print(json.dumps({'error': 'Usage: python pipeline.py <file_path> [file_path_2 ... ]'}))
        sys.exit(1)

    file_paths = sys.argv[1:]
    valid_paths = []

    for fp in file_paths:
        if not os.path.exists(fp):
            print(json.dumps({'error': f'File not found: {fp}'}))
            sys.exit(1)
        valid_paths.append(fp)

    result = run(valid_paths)
    print(json.dumps(result, indent=2, default=str))
