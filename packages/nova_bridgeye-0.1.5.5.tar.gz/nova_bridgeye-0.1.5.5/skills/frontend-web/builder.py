import os
import json
import re
import questionary
from typing import Dict, Any

from nova_cli.nova_core.ai.api_client import BridgeyeAPIClient
from nova_cli.local.ui import ui
from nova_cli.local.file_manager.commands import handle_ai_commands
from rich.tree import Tree
from rich.panel import Panel

# --- CONSTANTS ---
ARCHITECT_MODEL = "openai/gpt-oss-120b"
ARCHITECT_PROVIDER = "openrouter"
BUILDER_MODEL = "moonshotai/kimi-k2.6"
BUILDER_PROVIDER = "openrouter"

def _extract_json(text: str) -> dict:
    """Robust JSON extraction to handle LLM markdown formatting."""
    try:
        # If it's wrapped in markdown backticks
        match = re.search(r'```(?:json)?\s*(\{.*?\})\s*```', text, re.DOTALL)
        if match:
            return json.loads(match.group(1))
        # Fallback: find the first { and last }
        start = text.find('{')
        end = text.rfind('}')
        if start != -1 and end != -1:
            return json.loads(text[start:end+1])
        return json.loads(text)
    except Exception as e:
        ui.print(f"[red]Failed to parse, Trying Again...[/red]")
        return {}

def load_skill_md() -> str:
    """Loads the SKILL.md rules to inject into the planner."""
    skill_path = os.path.join(os.path.dirname(__file__), "SKILL.md")
    if os.path.exists(skill_path):
        with open(skill_path, "r", encoding="utf-8") as f:
            return f.read()
    return ""

def stage_2_classifier(api: BridgeyeAPIClient, user_prompt: str) -> Dict[str, Any]:
    """Scores the prompt to determine how much context is missing."""
    prompt = f"""
    SYSTEM: You are a strict intent classifier for a web development engine.
    Analyze the user's web build request and score its completeness.
    Output ONLY valid JSON. No markdown backticks, no explanations.

    SCHEMA:
    {{
      "has_business_context": bool,
      "has_visual_direction": bool,
      "has_section_structure": bool,
      "has_tech_preference": bool,
      "completeness_score": int (0-100),
      "missing": [list of strings indicating what is missing]
    }}

    USER REQUEST:
    {user_prompt}
    """
    with ui.create_loader("Analyzing request complexity..."):
        res = api.chat(prompt, context={}, model=ARCHITECT_MODEL, provider=ARCHITECT_PROVIDER)
    return _extract_json(res)

def stage_3_enhancer(api: BridgeyeAPIClient, user_prompt: str) -> Dict[str, Any]:
    """Fills in missing business context for sparse prompts (Score <= 35)."""
    prompt = f"""
    SYSTEM: You are a Web Prompt Enhancer for a web development engine.
    The user provided a very sparse request. Infer and fill in reasonable defaults for the business.
    Do NOT invent visual themes or colors (that is handled later). Focus purely on content/business logic.
    Output ONLY valid JSON. No markdown backticks.

    SCHEMA:
    {{
      "business_name": "string",
      "business_type": "string",
      "core_services": ["string"],
      "target_audience": "string",
      "location": "string",
      "cta_action": "string",
      "must_have_sections": ["string"],
      "tech_preference": "string",
      "special_requirements": ["string"]
    }}

    SPARSE USER REQUEST:
    {user_prompt}
    """
    with ui.create_loader("Running Web Prompt Enhancer..."):
        res = api.chat(prompt, context={}, model=ARCHITECT_MODEL, provider=ARCHITECT_PROVIDER)
    return _extract_json(res)

def stage_4_planner(api: BridgeyeAPIClient, user_prompt: str, classification: dict, enhancer_data: dict, skill_md: str) -> Dict[str, Any]:
    """Combines all context with SKILL.md to generate the definitive Build Plan."""
    
    score = classification.get("completeness_score", 0)
    missing = classification.get("missing", [])

    # Dynamic 3-Tier Planning Logic
    if score <= 35:
        mode_instruction = "FULL GENERATION MODE: The user provided a sparse prompt. Use the ENHANCED BUSINESS CONTEXT below. Auto-select the most appropriate theme from SKILL.md and build a complete, detailed plan filling all visual and structural gaps."
        context_str = f"ENHANCED BUSINESS CONTEXT:\n{json.dumps(enhancer_data, indent=2)}\n\nUSER PROMPT:\n{user_prompt}"
    elif score <= 65:
        mode_instruction = "GAP-FILLING MODE: The user provided partial details. Lock all user-stated preferences. Fill the specific gaps listed in IDENTIFIED GAPS using SKILL.md defaults."
        context_str = f"USER PROMPT:\n{user_prompt}\n\nIDENTIFIED GAPS TO FILL:\n{json.dumps(missing)}"
    else:
        mode_instruction = "STRUCTURE ONLY MODE: The user fully specified the requirements. Lock EVERY user-specified value (colors, fonts, sections). Do NOT reinterpret or override user intent. Use SKILL.md ONLY to fill the minor missing pieces."
        context_str = f"USER PROMPT:\n{user_prompt}\n\nMINOR GAPS TO FILL:\n{json.dumps(missing)}"

    prompt = f"""
    SYSTEM_OVERRIDE: You are the Lead Architect. Your job is to create a definitive JSON Blueprint for a web build.
    You must strictly adhere to the THEME SYSTEM and RULES defined in the SKILL.md document.
    Rule: User-stated details are locked. SKILL.md fills the silence.

    {mode_instruction}

    SKILL.md RULES:
    {skill_md}

    {context_str}

    REQUIRED JSON SCHEMA:
    {{
      "theme": "string (MUST be one of the themes from SKILL.md)",
      "theme_reason": "string (Explain why this theme was chosen or how it adapts the user's request)",
      "palette": {{ "background": "", "primary": "", "accent": "", "text": "", "surface": "" }},
      "fonts": {{ "heading": "", "body": "" }},
      "scope": "single-page or multi-page",
      "tech": "string (e.g. html-css-js, react)",
      "sections": ["string"],
      "copy_outline": {{ "hero_headline": "", "hero_subline": "", "cta_label": "", "section_notes": {{}} }},
      "file_structure": {{
         "pages": ["filename.ext"],
         "shared_components": ["filename.ext"],
         "build_order": ["filename.ext"]
      }} // Only include file_structure if scope is multi-page, otherwise null
    }}
    """
    with ui.create_loader("NOVA is Architecting Blueprint..."):
        res = api.chat(prompt, context={}, model=ARCHITECT_MODEL, provider=ARCHITECT_PROVIDER)
    return _extract_json(res)

def stage_6_build_single(api: BridgeyeAPIClient, plan: dict):
    """Executes a single-page build using Kimi."""
    prompt = f"""
    SYSTEM_OVERRIDE: PHASE: IMPLEMENTATION.
    You are an expert Frontend Developer executing a strict blueprint.
    Output ONLY a [CREATE: index.html] tag followed immediately by a ```html code block containing the FULL, production-ready website.
    Do NOT output any markdown text outside the block.
    Ensure CSS is in <style>, JS is in <script>. Use CSS variables in :root for the palette.
    
    BLUEPRINT:
    {json.dumps(plan, indent=2)}
    """
    ui.print("[cyan]>> NOVA (Kimi k2.6) is generating your single-page website...[/cyan]")
    output = ui.stream_rich_response(api.chat_stream(prompt, context={}, model=BUILDER_MODEL, provider=BUILDER_PROVIDER))
    
    # Save the file locally using the standard CLI engine
    return handle_ai_commands(output)

def stage_6_build_multi(api: BridgeyeAPIClient, plan: dict):
    """Executes a multi-page build iteratively using Kimi."""
    file_struct = plan.get("file_structure", {})
    build_order = file_struct.get("build_order", [])
    
    if not build_order:
        ui.print("[red]Error: Multi-page plan missing build order.[/red]")
        return []

    # Keep a running context of generated files to maintain consistency
    built_context = {}
    all_modified = []
    
    for i, filename in enumerate(build_order, 1):
        ui.print(f"\n[bold cyan]─── Building [{i}/{len(build_order)}]: {filename} ───[/bold cyan]")
        
        prompt = f"""
        SYSTEM_OVERRIDE: PHASE: IMPLEMENTATION.
        You are executing a multi-file web application blueprint.
        Currently building: {filename}.
        Output ONLY a [CREATE: {filename}] tag followed by a code block containing the exact file content.
        Do NOT add conversational text.
        
        GLOBAL BLUEPRINT:
        {json.dumps(plan, indent=2)}
        """
        
        output = ui.stream_rich_response(
            api.chat_stream(
                prompt, 
                context=built_context, 
                model=BUILDER_MODEL, 
                provider=BUILDER_PROVIDER
            )
        )
        
        # Save file to disk
        modified = handle_ai_commands(output)
        
        # Load the newly created file into the context for the next turn
        if modified:
            all_modified.extend(modified)
            for f in modified:
                if os.path.exists(f):
                    with open(f, "r", encoding="utf-8") as file:
                        built_context[os.path.basename(f)] = file.read()
                        
    return all_modified

def run(user_prompt: str):
    """Main Orchestrator Entry Point for the Frontend Web Builder Skill."""
    api = BridgeyeAPIClient()
    skill_md = load_skill_md()
    modified_files = []

    if not skill_md:
        ui.print("[red]Fatal: SKILL.md not found in frontend-web directory.[/red]")
        return modified_files

    # Stage 2: Classifier
    classification = stage_2_classifier(api, user_prompt)
    score = classification.get("completeness_score", 0)

    # Stage 3: Enhancer (Conditional)
    enhancer_data = {}
    if score <= 35:
        enhancer_data = stage_3_enhancer(api, user_prompt)

    # Stage 4: Planner
    plan = stage_4_planner(api, user_prompt, classification, enhancer_data, skill_md)
    if not plan:
        ui.print("[red]Failed to generate build plan. Aborting.[/red]")
        return modified_files

    # Stage 5: Scope Decision & Checkpoint
    scope = plan.get("scope", "single-page")
    theme = plan.get("theme", "MINIMAL")
    palette = plan.get("palette", {})
    fonts = plan.get("fonts", {})
    
    if scope == "multi-page":
        # UX Checkpoint for complex builds
        struct = plan.get("file_structure", {})
        
        ui.print("\n[bold magenta]>> NOVA Architect Plan Ready[/bold magenta]")
        # ui.print(f"[dim]Theme: {theme} | Tech: {plan.get('tech')} | Palette: {palette.get('primary', '')}[/dim]")
        
        # Build Visual Tree
        tree = Tree("[bold cyan]Project File Structure (Build Order)[/bold cyan]")
        for f in struct.get("build_order", []):
            tree.add(f"📄 {f}")
        ui.print(Panel(tree, border_style="cyan"))
        
        confirm = questionary.confirm("Review the plan above. Proceed with build?").ask()
        if not confirm:
            ui.print("[dim]Build cancelled by user.[/dim]")
            return modified_files
            
        ui.display_coding_mode(BUILDER_MODEL)
        modified_files = stage_6_build_multi(api, plan)
        
    else:
        # Single-page immediate execution
        # ui.print(f"\n[green]Using {theme} theme[/green] — {palette.get('background', 'Background')}, {fonts.get('heading', 'Serif')} + {fonts.get('body', 'Sans')}, single HTML file.")
        ui.display_coding_mode(BUILDER_MODEL)
        modified_files = stage_6_build_single(api, plan)
        
    ui.print("\n[bold green]✔ Web Build Complete![/bold green]")
    return modified_files