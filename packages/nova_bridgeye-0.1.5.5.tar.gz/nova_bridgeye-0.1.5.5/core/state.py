import json
import os

BUILD_STATE_FILE = os.path.expanduser("~/.nova/build_state.json")

class SessionState:
    def __init__(self) -> None:
        """
        Initializes the SessionState with default values.

        Attributes:
            active_file (str | None): The file currently being focused on/edited (absolute path).
            last_ai_response (str): The last response from the AI.
            last_generated_code (str | None): The last valid code block generated.
            loaded_files (dict[str, str]): Canonical mapping {basename: content} for persistent context.
            loaded_paths (dict[str, str]): Mapping {basename: absolute_path} for writing/applying edits.
            total_tokens_used (int): The total number of tokens used.
        """
        self.active_file: str | None = None
        self.last_ai_response: str = ""
        self.last_generated_code: str | None = None

        # Canonical: basename -> content
        self.loaded_files: dict[str, str] = {}

        # Canonical: basename -> abs path
        self.loaded_paths: dict[str, str] = {}

        # Build State tracking for :continue
        self.pending_build_files: list[str] = []
        self.current_plan_content: str = ""
        self.current_build_model: str = ""

        self.total_tokens_used: int = 0

    def reset(self) -> None:
        """
        Resets the session state to initial defaults and clears saved build state.
        """
        self.active_file = None
        self.last_ai_response = ""
        self.last_generated_code = None
        self.loaded_files = {}
        self.loaded_paths = {}
        self.total_tokens_used = 0
        if os.path.exists(BUILD_STATE_FILE):
            os.remove(BUILD_STATE_FILE)

    def save_build_state(self):
        """Persists the current build queue to disk."""
        os.makedirs(os.path.dirname(BUILD_STATE_FILE), exist_ok=True)
        data = {
            "pending_build_files": self.pending_build_files,
            "current_plan_content": self.current_plan_content,
            "current_build_model": self.current_build_model
        }
        with open(BUILD_STATE_FILE, "w", encoding="utf-8") as f:
            json.dump(data, f)

    def load_build_state(self):
        """Loads build queue from disk if it exists."""
        if os.path.exists(BUILD_STATE_FILE):
            try:
                with open(BUILD_STATE_FILE, "r", encoding="utf-8") as f:
                    data = json.load(f)
                    self.pending_build_files = data.get("pending_build_files", [])
                    self.current_plan_content = data.get("current_plan_content", "")
                    return True
            except Exception:
                return False
        return False
