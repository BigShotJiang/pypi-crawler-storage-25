"""System R CLI — trading operating system in your terminal."""

__version__ = "2.2.1"
