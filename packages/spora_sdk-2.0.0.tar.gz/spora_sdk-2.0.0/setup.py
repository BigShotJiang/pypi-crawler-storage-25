from setuptools import setup

setup(
    name="spora-sdk",
    version="2.0.0",
    description="Official Python SDK for the Spora agronomic intelligence API",
    long_description=open("README.md").read() if __import__("os").path.exists("README.md") else "",
    long_description_content_type="text/markdown",
    py_modules=["spora"],
    python_requires=">=3.9",
    install_requires=["requests>=2.28.0"],
    author="Spora",
    author_email="hello.spora@yahoo.com",
    url="https://spora.engineer",
    project_urls={"Documentation": "https://spora.engineer/docs"},
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Topic :: Scientific/Engineering",
        "Intended Audience :: Developers",
    ],
    keywords=["agronomy", "agriculture", "api", "plants", "crops"],
)
