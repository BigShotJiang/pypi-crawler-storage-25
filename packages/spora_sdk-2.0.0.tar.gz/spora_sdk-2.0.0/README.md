# Spora Python SDK

Official Python client for the [Spora agronomic intelligence API](https://spora.engineer).

## Installation

```bash
pip install spora-sdk
```

## Quick start

```python
from spora import Spora

client = Spora(api_key="spk_live_your_key_here")

# Search species
species = client.search_species("Rosa", limit=5)

# Get crop requirements
crop = client.get_crop("solanum_lycopersicum")
print(crop["temp_optimal_min"], crop["temp_optimal_max"])

# AI question (paid key)
answer = client.ask(
    "When should I irrigate my tomatoes?",
    crop="solanum_lycopersicum",
    lat=45.4, lon=11.0,
    tone="concise",
)
print(answer["response"])

# Batch
results = client.batch([
    ("weather",      {"lat": 45.4, "lon": 11.0, "days": 3}),
    ("should_water", {"lat": 45.4, "lon": 11.0, "crop": "vitis_vinifera"}),
])
```

## Error handling

```python
from spora import Spora, SporaError

client = Spora(api_key="spk_live_your_key_here")

try:
    result = client.ask("Best cover crop for clay soil?")
except SporaError as e:
    print(e.status, e.error)

print(client.rate_limit.remaining, "/", client.rate_limit.limit)
```

## Links

- [Documentation](https://spora.engineer/docs/sdk)
- [API Reference](https://spora.engineer/docs)
- [Get an API key](https://spora.engineer/request)
