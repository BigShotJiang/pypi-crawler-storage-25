"""dmr-toolkit — Reusable design pattern helpers for Django REST APIs."""

__version__ = "0.1.0"
