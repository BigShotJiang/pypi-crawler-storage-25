"""
dmr_toolkit.patterns.command
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Command pattern with execute/undo semantics, async variants, OTel tracing,
and optional audit logging.

Usage::

    from dmr_toolkit.patterns.command import Command

    class IncrementCounter(Command[int]):
        def __init__(self, counter: list[int]) -> None:
            self._counter = counter
            self._previous: int | None = None

        def execute(self) -> int:
            self._previous = self._counter[0]
            self._counter[0] += 1
            return self._counter[0]

        def undo(self) -> None:
            if self._previous is not None:
                self._counter[0] = self._previous

Requirements: 11.1, 11.2, 11.3, 11.4, 11.5, 11.6, 14.3, 15.1, 15.2
"""
from __future__ import annotations

import asyncio
import datetime
from abc import ABC, abstractmethod
from typing import Any, Generic, TypeVar

from dmr_toolkit.patterns._telemetry import span

R = TypeVar("R")

# ---------------------------------------------------------------------------
# In-memory audit log fallback (used when DB is unavailable, e.g. in tests)
# ---------------------------------------------------------------------------

_audit_log: list[dict[str, Any]] = []


def _is_audit_enabled() -> bool:
    """Return True when Django is configured and audit logging is enabled.

    Delegates to :func:`~dmr_toolkit.patterns._settings.get_patterns_settings`
    so that the ``DMR_TOOLKIT["patterns"]["audit"]`` setting is the single
    source of truth.
    """
    try:
        from dmr_toolkit.patterns._settings import get_patterns_settings

        return bool(get_patterns_settings().get("audit", False))
    except Exception:
        return False


def _write_audit_record(record: dict[str, Any]) -> None:
    """Write an audit record to the DB model or fall back to the in-memory list."""
    try:
        from dmr_toolkit.patterns.models import CommandAuditLog  # type: ignore[import]

        CommandAuditLog.objects.create(
            command_class=record["command_class"],
            input_params=record["input_params"],
            result=record["result"],
            executed_by=record.get("executed_by"),
            success=record["success"],
        )
    except Exception:
        # DB unavailable (no migrations, test environment, etc.) — use in-memory list
        _audit_log.append(record)


# ---------------------------------------------------------------------------
# Command base class
# ---------------------------------------------------------------------------


class Command(ABC, Generic[R]):
    """Abstract base class for the Command pattern.

    Subclasses must implement :meth:`execute` and :meth:`undo`.  Async
    variants (:meth:`aexecute` / :meth:`aundo`) are provided with default
    implementations that run the sync methods in a thread executor.

    Audit records are written when ``DMR_TOOLKIT["patterns"]["audit"]`` is
    ``True`` in Django settings.  When the DB model is unavailable (e.g. in
    tests without migrations), records fall back to the module-level
    :data:`_audit_log` list.

    Requirements: 11.1, 11.2, 11.3, 11.4, 11.5, 11.6, 14.3, 15.1, 15.2
    """

    # ------------------------------------------------------------------
    # Abstract interface (Requirements 11.1, 11.2, 11.3)
    # ------------------------------------------------------------------

    @abstractmethod
    def execute(self) -> R:
        """Perform the operation and return a result.

        Requirements: 11.1, 11.2
        """
        ...

    @abstractmethod
    def undo(self) -> None:
        """Reverse the operation and restore previous state.

        Requirements: 11.1, 11.3
        """
        ...

    # ------------------------------------------------------------------
    # Async variants (Requirement 11.5)
    # ------------------------------------------------------------------

    async def aexecute(self) -> R:
        """Async variant of :meth:`execute`.

        Default implementation runs :meth:`execute` in a thread executor so
        that blocking implementations do not stall the event loop.

        Requirements: 11.5
        """
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, self.execute)

    async def aundo(self) -> None:
        """Async variant of :meth:`undo`.

        Default implementation runs :meth:`undo` in a thread executor.

        Requirements: 11.5
        """
        loop = asyncio.get_event_loop()
        await loop.run_in_executor(None, self.undo)

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _get_input_params(self) -> dict[str, Any]:
        """Return a JSON-serialisable dict of input parameters for audit logging.

        Subclasses may override this to provide richer parameter information.
        By default, returns an empty dict.
        """
        return {}

    def _get_executed_by(self) -> Any:
        """Return the user performing this command, or None.

        Subclasses may override to supply the current user.
        """
        return None

    # ------------------------------------------------------------------
    # Execute with tracing + audit (Requirements 11.4, 14.3)
    # ------------------------------------------------------------------

    def _execute_with_audit(self) -> R:
        """Internal: run execute() with OTel span and optional audit record."""
        command_name = type(self).__name__
        result: R
        success = False

        with span(
            f"command.execute",
            attributes={"command": command_name},
        ):
            try:
                result = self.execute()
                success = True
            except Exception:
                raise
            finally:
                if _is_audit_enabled():
                    record: dict[str, Any] = {
                        "command_class": command_name,
                        "input_params": self._get_input_params(),
                        "result": None if not success else _safe_json(result),
                        "executed_by": self._get_executed_by(),
                        "success": success,
                        "timestamp": datetime.datetime.now(datetime.timezone.utc).isoformat(),
                    }
                    _write_audit_record(record)

        return result  # type: ignore[return-value]

    def _undo_with_audit(self) -> None:
        """Internal: run undo() with OTel span."""
        command_name = type(self).__name__

        with span(
            f"command.undo",
            attributes={"command": command_name},
        ):
            self.undo()

    # ------------------------------------------------------------------
    # Pretty-printing (Requirements 15.1, 15.2)
    # ------------------------------------------------------------------

    def __repr__(self) -> str:
        return f"{type(self).__name__}()"

    def __str__(self) -> str:
        return f"{type(self).__name__}\n  pattern: Command"


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _safe_json(value: Any) -> Any:
    """Return *value* if JSON-serialisable, else its string representation."""
    import json

    try:
        json.dumps(value)
        return value
    except (TypeError, ValueError):
        return str(value)
