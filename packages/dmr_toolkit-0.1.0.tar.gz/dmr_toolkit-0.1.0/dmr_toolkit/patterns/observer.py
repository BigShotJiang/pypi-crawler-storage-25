"""
dmr_toolkit.patterns.observer
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Observer / EventBus pattern.

Provides a typed publish-subscribe event bus with:
- Decorator-based handler registration: ``@bus.on("order.created")``
- Wildcard subscriptions via ``fnmatch`` (e.g. ``"order.*"``)
- Mixed sync/async handler dispatch
- Fault isolation: all handlers are invoked even if some raise; errors are
  collected into a single ``EventDispatchError``

Usage::

    from dmr_toolkit.patterns.observer import EventBus

    bus = EventBus()

    @bus.on("order.created")
    def handle_order(payload):
        print(payload)

    bus.emit("order.created", {"id": 1})
"""
from __future__ import annotations

import asyncio
import inspect
import logging
from fnmatch import fnmatch
from typing import Any, Callable

from dmr_toolkit.patterns.exceptions import EventDispatchError

logger = logging.getLogger(__name__)

# Type alias for a handler callable (sync or async)
Handler = Callable[..., Any]


class EventBus:
    """Publish-subscribe event bus supporting sync and async handlers.

    Handlers are registered with :meth:`on` and invoked in registration order
    when an event is emitted via :meth:`emit` or :meth:`aemit`.

    Wildcard patterns (e.g. ``"order.*"``) are matched using :func:`fnmatch`.

    Requirements: 7.1, 7.2, 7.3, 7.4, 7.5, 7.6, 15.1, 15.2
    """

    def __init__(self) -> None:
        # List of (pattern, handler) pairs in registration order
        self._handlers: list[tuple[str, Handler]] = []

    # ------------------------------------------------------------------
    # Registration
    # ------------------------------------------------------------------

    def on(self, event_type: str) -> Callable[[Handler], Handler]:
        """Decorator that registers *handler* for *event_type*.

        Supports wildcard patterns (e.g. ``"order.*"``).

        Example::

            @bus.on("order.created")
            def handle(payload): ...

        Requirements: 7.1, 7.6
        """
        def decorator(handler: Handler) -> Handler:
            self._handlers.append((event_type, handler))
            return handler
        return decorator

    # ------------------------------------------------------------------
    # Synchronous dispatch
    # ------------------------------------------------------------------

    def emit(self, event_type: str, payload: dict[str, Any]) -> None:
        """Emit *event_type* synchronously, invoking all matching handlers.

        Handlers are called in registration order (Requirement 7.2).
        Async handlers are scheduled on the running event loop when one
        exists, or run in a new loop as a fallback (Requirement 7.4).

        If any handler raises, execution continues for remaining handlers.
        All errors are collected and raised as a single
        :class:`~dmr_toolkit.patterns.exceptions.EventDispatchError` after
        all handlers have been invoked (Requirement 7.5).

        Requirements: 7.2, 7.4, 7.5
        """
        errors: list[Exception] = []
        for pattern, handler in self._handlers:
            if not fnmatch(event_type, pattern):
                continue
            try:
                if inspect.iscoroutinefunction(handler):
                    self._dispatch_async(handler, payload)
                else:
                    handler(payload)
            except Exception as exc:  # noqa: BLE001
                logger.error(
                    "Handler %r raised while processing event %r: %s",
                    handler,
                    event_type,
                    exc,
                    exc_info=True,
                )
                errors.append(exc)

        if errors:
            raise EventDispatchError(event_type=event_type, errors=errors)

    def _dispatch_async(self, handler: Handler, payload: dict[str, Any]) -> None:
        """Schedule an async *handler* from a synchronous context."""
        try:
            loop = asyncio.get_running_loop()
            # A loop is running (e.g. inside an async framework) — schedule as a task
            loop.create_task(handler(payload))
        except RuntimeError:
            # No running loop — run in a new one
            asyncio.run(handler(payload))

    # ------------------------------------------------------------------
    # Asynchronous dispatch
    # ------------------------------------------------------------------

    async def aemit(self, event_type: str, payload: dict[str, Any]) -> None:
        """Emit *event_type* asynchronously, invoking all matching handlers.

        Sync handlers are called directly; async handlers are awaited.
        All handlers are invoked even if some raise.  Errors are collected
        and raised as a single :class:`EventDispatchError`.

        Requirements: 7.2, 7.3, 7.5
        """
        errors: list[Exception] = []
        for pattern, handler in self._handlers:
            if not fnmatch(event_type, pattern):
                continue
            try:
                if inspect.iscoroutinefunction(handler):
                    await handler(payload)
                else:
                    handler(payload)
            except Exception as exc:  # noqa: BLE001
                logger.error(
                    "Handler %r raised while processing event %r: %s",
                    handler,
                    event_type,
                    exc,
                    exc_info=True,
                )
                errors.append(exc)

        if errors:
            raise EventDispatchError(event_type=event_type, errors=errors)

    # ------------------------------------------------------------------
    # Introspection helpers
    # ------------------------------------------------------------------

    def handlers_for(self, event_type: str) -> list[Handler]:
        """Return all handlers whose pattern matches *event_type*, in order."""
        return [h for pattern, h in self._handlers if fnmatch(event_type, pattern)]

    def clear(self) -> None:
        """Remove all registered handlers."""
        self._handlers.clear()

    # ------------------------------------------------------------------
    # Pretty-printing (Requirements 15.1, 15.2)
    # ------------------------------------------------------------------

    def __repr__(self) -> str:
        return f"EventBus(handlers={len(self._handlers)})"

    def __str__(self) -> str:
        lines = [f"EventBus with {len(self._handlers)} registered handler(s):"]
        for pattern, handler in self._handlers:
            lines.append(f"  {pattern!r} -> {handler.__qualname__}")
        return "\n".join(lines)
