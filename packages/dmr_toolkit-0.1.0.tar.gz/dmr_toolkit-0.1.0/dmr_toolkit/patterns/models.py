"""
dmr_toolkit.patterns.models
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Django ORM models for the patterns module.

Models:
- StateTransitionAudit  — audit log for StateMachine transitions
- CommandAuditLog       — audit log for Command executions
- DomainEvent           — immutable event record for Event Sourcing
- Snapshot              — aggregate snapshot for Event Sourcing

All models use ``app_label = "dmr_toolkit_patterns"`` so they can be
discovered without adding the full package path to ``INSTALLED_APPS``.

Requirements: 4.5, 11.4, 13.1, 13.6
"""
from __future__ import annotations

from uuid import uuid4

from django.conf import settings
from django.db import models


class StateTransitionAudit(models.Model):
    """Audit record for a single StateMachine transition.

    Requirements: 4.5
    """

    content_type = models.ForeignKey(
        "contenttypes.ContentType",
        on_delete=models.CASCADE,
        null=True,
        blank=True,
    )
    object_id = models.CharField(max_length=255)
    transition = models.CharField(max_length=255)
    from_state = models.CharField(max_length=255)
    to_state = models.CharField(max_length=255)
    triggered_by = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        null=True,
        blank=True,
        on_delete=models.SET_NULL,
        related_name="+",
    )
    timestamp = models.DateTimeField(auto_now_add=True)

    class Meta:
        app_label = "dmr_toolkit_patterns"

    def __repr__(self) -> str:
        return (
            f"StateTransitionAudit(transition={self.transition!r}, "
            f"from={self.from_state!r}, to={self.to_state!r})"
        )

    def __str__(self) -> str:
        return (
            f"StateTransitionAudit\n"
            f"  transition : {self.transition!r}\n"
            f"  from_state : {self.from_state!r}\n"
            f"  to_state   : {self.to_state!r}\n"
            f"  timestamp  : {self.timestamp}"
        )


class CommandAuditLog(models.Model):
    """Audit record for a single Command execution.

    Requirements: 11.4
    """

    command_class = models.CharField(max_length=255)
    input_params = models.JSONField()
    result = models.JSONField(null=True, blank=True)
    executed_by = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        null=True,
        blank=True,
        on_delete=models.SET_NULL,
        related_name="+",
    )
    timestamp = models.DateTimeField(auto_now_add=True)
    success = models.BooleanField()

    class Meta:
        app_label = "dmr_toolkit_patterns"

    def __repr__(self) -> str:
        return (
            f"CommandAuditLog(command_class={self.command_class!r}, "
            f"success={self.success!r})"
        )

    def __str__(self) -> str:
        return (
            f"CommandAuditLog\n"
            f"  command_class : {self.command_class!r}\n"
            f"  success       : {self.success}\n"
            f"  timestamp     : {self.timestamp}"
        )


class DomainEvent(models.Model):
    """Immutable domain event record for Event Sourcing.

    Requirements: 13.1, 13.2
    """

    id = models.UUIDField(primary_key=True, default=uuid4)
    aggregate_id = models.CharField(max_length=255, db_index=True)
    aggregate_type = models.CharField(max_length=255)
    event_type = models.CharField(max_length=255, db_index=True)
    payload = models.JSONField()
    schema_version = models.PositiveIntegerField(default=1)
    sequence = models.PositiveIntegerField()
    timestamp = models.DateTimeField(auto_now_add=True)

    class Meta:
        app_label = "dmr_toolkit_patterns"
        unique_together = [("aggregate_id", "sequence")]
        ordering = ["aggregate_id", "sequence"]

    def __repr__(self) -> str:
        return (
            f"DomainEvent(aggregate_id={self.aggregate_id!r}, "
            f"event_type={self.event_type!r}, sequence={self.sequence!r})"
        )

    def __str__(self) -> str:
        return (
            f"DomainEvent\n"
            f"  aggregate_id   : {self.aggregate_id!r}\n"
            f"  aggregate_type : {self.aggregate_type!r}\n"
            f"  event_type     : {self.event_type!r}\n"
            f"  sequence       : {self.sequence}\n"
            f"  timestamp      : {self.timestamp}"
        )


class Snapshot(models.Model):
    """Aggregate snapshot for Event Sourcing.

    Requirements: 13.6
    """

    aggregate_id = models.CharField(max_length=255, unique=True)
    aggregate_type = models.CharField(max_length=255)
    state = models.JSONField()
    sequence = models.PositiveIntegerField()
    timestamp = models.DateTimeField(auto_now_add=True)

    class Meta:
        app_label = "dmr_toolkit_patterns"

    def __repr__(self) -> str:
        return (
            f"Snapshot(aggregate_id={self.aggregate_id!r}, "
            f"sequence={self.sequence!r})"
        )

    def __str__(self) -> str:
        return (
            f"Snapshot\n"
            f"  aggregate_id   : {self.aggregate_id!r}\n"
            f"  aggregate_type : {self.aggregate_type!r}\n"
            f"  sequence       : {self.sequence}\n"
            f"  timestamp      : {self.timestamp}"
        )
