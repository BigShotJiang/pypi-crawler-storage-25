"""
dmr_toolkit.patterns.strategy
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Strategy pattern with a class-level registry.

Each concrete Strategy subclass gets its own isolated ``_registry`` dict
(via ``__init_subclass__``), so registrations on one subclass hierarchy
never pollute another.

Usage::

    class PricingStrategy(Strategy):
        @abstractmethod
        def execute(self, order) -> Decimal: ...

    @PricingStrategy.register("standard")
    class StandardPricing(PricingStrategy):
        def execute(self, order) -> Decimal:
            return order.subtotal

    cls = PricingStrategy.resolve("standard")
    result = cls().execute(order)
"""
from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any, ClassVar

from dmr_toolkit.patterns.exceptions import StrategyNotFound


class Strategy(ABC):
    """Abstract base class for the Strategy pattern.

    Subclasses define their own algorithm family.  Concrete implementations
    are registered by name and resolved at runtime.

    Each direct or indirect subclass receives its own ``_registry`` dict so
    that sibling hierarchies remain independent.
    """

    _registry: ClassVar[dict[str, type["Strategy"]]] = {}

    # ------------------------------------------------------------------
    # Subclass isolation
    # ------------------------------------------------------------------

    def __init_subclass__(cls, **kwargs: Any) -> None:
        super().__init_subclass__(**kwargs)
        # Give every subclass its own fresh registry so that registrations
        # on one hierarchy never bleed into another.
        cls._registry = {}

    # ------------------------------------------------------------------
    # Registry helpers
    # ------------------------------------------------------------------

    @classmethod
    def register(cls, name: str):
        """Class decorator that adds a concrete strategy to *this* class's registry.

        Example::

            @MyStrategy.register("fast")
            class FastStrategy(MyStrategy):
                def execute(self, *args, **kwargs): ...
        """
        def decorator(strategy_cls: type) -> type:
            cls._registry[name] = strategy_cls
            return strategy_cls
        return decorator

    @classmethod
    def resolve(cls, name: str) -> type["Strategy"]:
        """Return the strategy class registered under *name*.

        Raises:
            StrategyNotFound: if *name* is not in the registry.
        """
        if name not in cls._registry:
            raise StrategyNotFound(name=name, available=list(cls._registry.keys()))
        return cls._registry[name]

    # ------------------------------------------------------------------
    # Abstract interface
    # ------------------------------------------------------------------

    @abstractmethod
    def execute(self, *args: Any, **kwargs: Any) -> Any:
        """Execute the strategy.  Concrete subclasses must implement this."""
        ...

    # ------------------------------------------------------------------
    # Pretty-printing (Requirements 15.1, 15.2)
    # ------------------------------------------------------------------

    def __repr__(self) -> str:
        return (
            f"{type(self).__name__}("
            f"registry_size={len(type(self)._registry)})"
        )

    def __str__(self) -> str:
        available = list(type(self)._registry.keys())
        return (
            f"{type(self).__name__}\n"
            f"  registered strategies: {available!r}"
        )
