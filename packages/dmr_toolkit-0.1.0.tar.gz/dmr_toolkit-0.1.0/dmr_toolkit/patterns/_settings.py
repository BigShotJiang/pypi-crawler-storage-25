"""
dmr_toolkit.patterns._settings
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Settings loader for the patterns sub-package.

Reads configuration from ``DMR_TOOLKIT["patterns"]`` in Django settings and
returns a validated dict with sensible defaults.

Usage::

    from dmr_toolkit.patterns._settings import get_patterns_settings

    cfg = get_patterns_settings()
    if cfg["audit"]:
        ...

Requirements: 1.2, 1.3, 14.5
"""
from __future__ import annotations

from typing import Any

# Default values for every supported key.
_DEFAULTS: dict[str, Any] = {
    "audit": False,
    "cache_backend": "default",
    "event_bus": "default",
    "event_store_backend": "django",
    "plugin_group": "dmr_toolkit.plugins",
}

# Validation rules: key -> (expected_type, human-readable type name)
_VALIDATORS: dict[str, tuple[type, str]] = {
    "audit": (bool, "bool"),
    "cache_backend": (str, "str"),
    "event_bus": (str, "str"),
    "event_store_backend": (str, "str"),
    "plugin_group": (str, "str"),
}


def get_patterns_settings() -> dict[str, Any]:
    """Return the validated patterns settings dict.

    Reads ``DMR_TOOLKIT["patterns"]`` from Django settings.  When the key is
    absent (or Django is not configured), the defaults are returned without
    error.

    Returns:
        A dict with keys ``audit``, ``cache_backend``, ``event_bus``,
        ``event_store_backend``, and ``plugin_group``.

    Raises:
        django.core.exceptions.ImproperlyConfigured: When a key is present but
            has an invalid type (e.g. ``audit`` is a string instead of a bool).

    Requirements: 1.2, 1.3, 14.5
    """
    raw: dict[str, Any] = {}

    try:
        from django.conf import settings  # type: ignore[import]

        if settings.configured:
            dmr = getattr(settings, "DMR_TOOLKIT", None)
            if isinstance(dmr, dict):
                raw = dmr.get("patterns", {}) or {}
    except Exception:
        # Django not installed or not configured — use defaults silently.
        pass

    result: dict[str, Any] = dict(_DEFAULTS)

    for key, value in raw.items():
        if key not in _VALIDATORS:
            # Unknown keys are ignored (forward-compatibility).
            continue

        expected_type, type_name = _VALIDATORS[key]
        if not isinstance(value, expected_type):
            _raise_improperly_configured(key, value, type_name)

        result[key] = value

    return result


def _raise_improperly_configured(key: str, value: Any, expected: str) -> None:
    """Raise ``ImproperlyConfigured`` with a descriptive message."""
    try:
        from django.core.exceptions import ImproperlyConfigured  # type: ignore[import]
    except ImportError:
        raise ValueError(
            f"DMR_TOOLKIT['patterns']['{key}'] must be {expected}, "
            f"got {type(value).__name__!r}: {value!r}"
        )

    raise ImproperlyConfigured(
        f"DMR_TOOLKIT['patterns']['{key}'] must be {expected}, "
        f"got {type(value).__name__!r}: {value!r}.  "
        f"Check your Django settings."
    )
