"""
dmr_toolkit.patterns.unit_of_work
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Unit of Work pattern.

Provides a context manager that groups multiple Repository operations into a
single atomic transaction with automatic rollback on failure.

Features:
- Sync and async context manager protocol
- Django ``transaction.atomic()`` with savepoints for nesting
- No-DB fallback (in-memory simulation) when Django DB is unavailable
- EventBus event buffering: events are dispatched only after a successful
  commit and suppressed on rollback
- ``register_repository(repo)`` for future integration hooks

Cross-Pattern Integration
--------------------------

**UnitOfWork + Repository + EventBus** (Requirements 12.2, 12.5, 14.1)

The three patterns compose naturally::

    from dmr_toolkit.patterns.unit_of_work import UnitOfWork
    from dmr_toolkit.patterns.observer import EventBus
    from dmr_toolkit.testing.repository import InMemoryRepository

    bus = EventBus()
    repo = InMemoryRepository()

    @bus.on("entity.added")
    def on_added(payload):
        print("entity added:", payload["entity"])

    with UnitOfWork(event_bus=bus) as uow:
        uow.register_repository(repo)
        entity = repo.add(my_entity)
        bus.emit("entity.added", {"entity": entity})
        # ↑ event is buffered here, NOT dispatched yet

    # ↑ on successful exit: transaction committed, then buffered events dispatched
    # ↑ on exception: transaction rolled back, buffered events discarded

**UnitOfWork + Command** (Requirement 11.6)

Commands can be executed atomically inside a UoW block::

    with UnitOfWork() as uow:
        result = my_command.execute()
        # if execute() raises, the whole block rolls back

**Nesting** (Requirement 12.6)

Nested UoW blocks use Django savepoints so inner failures do not affect the
outer transaction::

    with UnitOfWork() as outer:
        repo.add(entity_a)
        try:
            with UnitOfWork() as inner:
                repo.add(entity_b)
                raise ValueError("inner failure")
        except ValueError:
            pass  # entity_b rolled back; entity_a still pending
    # entity_a committed here
"""
from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Any, Optional

if TYPE_CHECKING:
    from dmr_toolkit.patterns.observer import EventBus
    from dmr_toolkit.patterns.repository import Repository

logger = logging.getLogger(__name__)


class UnitOfWork:
    """Atomic transaction boundary with optional EventBus event buffering.

    Args:
        event_bus: Optional :class:`~dmr_toolkit.patterns.observer.EventBus`.
            When provided, ``emit`` calls inside the block are buffered and
            replayed after a successful commit, or discarded on rollback.

    Requirements: 12.1, 12.2, 12.3, 12.4, 12.5, 12.6, 15.1, 15.2
    """

    def __init__(self, event_bus: Optional["EventBus"] = None) -> None:
        self._event_bus = event_bus
        self._repositories: list["Repository[Any, Any]"] = []
        self._committed: bool = False
        self._rolled_back: bool = False
        # Nesting depth — incremented on each __enter__, decremented on __exit__
        self._depth: int = 0
        # Buffered (event_type, payload) pairs
        self._buffered_events: list[tuple[str, dict[str, Any]]] = []
        # Original emit method (saved when we patch the bus)
        self._original_emit: Any = None
        # Django transaction context managers (one per nesting level)
        self._atomic_ctx: Any = None

    # ------------------------------------------------------------------
    # Repository registration
    # ------------------------------------------------------------------

    def register_repository(self, repo: "Repository[Any, Any]") -> None:
        """Store a reference to *repo* for future integration hooks.

        Requirements: 12.1
        """
        self._repositories.append(repo)

    # ------------------------------------------------------------------
    # EventBus buffering helpers
    # ------------------------------------------------------------------

    def _install_event_buffer(self) -> None:
        """Replace ``event_bus.emit`` with a buffering version."""
        if self._event_bus is None:
            return
        self._original_emit = self._event_bus.emit

        bus = self._event_bus
        buffer = self._buffered_events

        def _buffered_emit(event_type: str, payload: dict[str, Any]) -> None:
            buffer.append((event_type, payload))

        bus.emit = _buffered_emit  # type: ignore[method-assign]

    def _restore_event_bus(self) -> None:
        """Restore the original ``emit`` method."""
        if self._event_bus is not None and self._original_emit is not None:
            self._event_bus.emit = self._original_emit  # type: ignore[method-assign]
            self._original_emit = None

    def _flush_events(self) -> None:
        """Dispatch all buffered events via the original emit."""
        if self._event_bus is None or self._original_emit is None:
            return
        original = self._original_emit
        for event_type, payload in self._buffered_events:
            try:
                original(event_type, payload)
            except Exception:  # noqa: BLE001
                logger.exception("Error dispatching buffered event %r", event_type)
        self._buffered_events.clear()

    def _discard_events(self) -> None:
        """Discard all buffered events (rollback path)."""
        self._buffered_events.clear()

    # ------------------------------------------------------------------
    # Django transaction helpers
    # ------------------------------------------------------------------

    def _enter_transaction(self) -> None:
        """Enter a Django atomic block (or savepoint for nested UoW)."""
        try:
            from django.db import transaction as dj_tx

            if self._depth == 0:
                self._atomic_ctx = dj_tx.atomic()
            else:
                # Nested: use savepoint
                self._atomic_ctx = dj_tx.atomic(savepoint=True)
            self._atomic_ctx.__enter__()
        except Exception:  # noqa: BLE001
            # Django not configured or DB unavailable — use in-memory simulation
            self._atomic_ctx = None

    def _exit_transaction(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
        """Exit the Django atomic block, or update in-memory flags."""
        if self._atomic_ctx is not None:
            try:
                self._atomic_ctx.__exit__(exc_type, exc_val, exc_tb)
            except Exception:  # noqa: BLE001
                pass
            self._atomic_ctx = None
        else:
            # In-memory simulation
            if exc_type is None:
                self._committed = True
            else:
                self._rolled_back = True

    # ------------------------------------------------------------------
    # Sync context manager
    # ------------------------------------------------------------------

    def __enter__(self) -> "UnitOfWork":
        self._depth += 1
        self._install_event_buffer()
        self._enter_transaction()
        return self

    def __exit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> bool:
        try:
            self._exit_transaction(exc_type, exc_val, exc_tb)
            if exc_type is None:
                self._committed = True
                self._flush_events()
                self._restore_event_bus()
            else:
                self._rolled_back = True
                self._discard_events()
                self._restore_event_bus()
        finally:
            self._depth -= 1
        # Never suppress exceptions
        return False

    # ------------------------------------------------------------------
    # Async context manager
    # ------------------------------------------------------------------

    async def __aenter__(self) -> "UnitOfWork":
        self._depth += 1
        self._install_event_buffer()
        self._enter_transaction()
        return self

    async def __aexit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> bool:
        try:
            self._exit_transaction(exc_type, exc_val, exc_tb)
            if exc_type is None:
                self._committed = True
                self._flush_events()
                self._restore_event_bus()
            else:
                self._rolled_back = True
                self._discard_events()
                self._restore_event_bus()
        finally:
            self._depth -= 1
        return False

    # ------------------------------------------------------------------
    # Pretty-printing (Requirements 15.1, 15.2)
    # ------------------------------------------------------------------

    def __repr__(self) -> str:
        status = "committed" if self._committed else ("rolled_back" if self._rolled_back else "open")
        return (
            f"UnitOfWork(depth={self._depth}, status={status!r}, "
            f"repos={len(self._repositories)}, "
            f"buffered_events={len(self._buffered_events)})"
        )

    def __str__(self) -> str:
        status = "committed" if self._committed else ("rolled_back" if self._rolled_back else "open")
        lines = [
            f"UnitOfWork [status={status}]",
            f"  nesting depth : {self._depth}",
            f"  repositories  : {len(self._repositories)}",
            f"  buffered events: {len(self._buffered_events)}",
        ]
        return "\n".join(lines)
