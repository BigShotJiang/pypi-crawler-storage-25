"""
dmr_toolkit.patterns.specification
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Composable Specification pattern for building query predicates.

Usage::

    from dmr_toolkit.patterns.specification import Specification

    class ActiveUser(Specification):
        def is_satisfied_by(self, entity) -> bool:
            return entity.is_active

        def to_query(self) -> Q:
            return Q(is_active=True)

    spec = ActiveUser() & ~BannedUser()
    qs = User.objects.filter(spec.to_query())
"""
from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any

from django.db.models import Q


class Specification(ABC):
    """Abstract base for composable query predicates.

    Subclasses must implement :meth:`is_satisfied_by` and :meth:`to_query`.
    Operator overloads (``&``, ``|``, ``~``) produce composite specifications.
    """

    @abstractmethod
    def is_satisfied_by(self, entity: object) -> bool:
        """Return ``True`` if *entity* satisfies this specification."""

    @abstractmethod
    def to_query(self) -> Q:
        """Return a Django ``Q`` object representing this specification."""

    # ------------------------------------------------------------------
    # Serialisation (Requirements 3.6, 3.7, 15.3)
    # ------------------------------------------------------------------

    def to_dict(self) -> dict[str, Any]:
        """Serialise this specification to a JSON-compatible dictionary.

        The default implementation stores the fully-qualified class name so
        that :meth:`from_dict` can reconstruct the object.  Subclasses that
        carry constructor arguments MUST override both ``to_dict`` and
        ``from_dict`` to include those arguments under the ``"kwargs"`` key.
        """
        return {
            "type": f"{type(self).__module__}.{type(self).__qualname__}",
            "kwargs": {},
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "Specification":
        """Reconstruct a :class:`Specification` from a dictionary produced by
        :meth:`to_dict`.

        Supports composite nodes (``and``, ``or``, ``not``) as well as any
        concrete subclass that stores its fully-qualified class name under the
        ``"type"`` key.
        """
        spec_type = data.get("type", "")

        # Composite nodes use short sentinel names
        if spec_type == "and":
            left = cls.from_dict(data["left"])
            right = cls.from_dict(data["right"])
            return AndSpecification(left, right)
        if spec_type == "or":
            left = cls.from_dict(data["left"])
            right = cls.from_dict(data["right"])
            return OrSpecification(left, right)
        if spec_type == "not":
            operand = cls.from_dict(data["operand"])
            return NotSpecification(operand)

        # Concrete subclass — resolve by fully-qualified name
        import importlib

        module_name, _, qualname = spec_type.rpartition(".")
        if not module_name:
            raise ValueError(f"Cannot deserialise specification: invalid type {spec_type!r}")

        module = importlib.import_module(module_name)
        # Support nested classes via dotted qualname
        klass: Any = module
        for part in qualname.split("."):
            klass = getattr(klass, part)

        kwargs = data.get("kwargs", {})
        instance = klass(**kwargs)
        if not isinstance(instance, Specification):
            raise TypeError(f"{spec_type!r} is not a Specification subclass")
        return instance

    # ------------------------------------------------------------------
    # Operator overloads (Requirements 3.3, 3.4, 3.5)
    # ------------------------------------------------------------------

    def __and__(self, other: "Specification") -> "AndSpecification":
        return AndSpecification(self, other)

    def __or__(self, other: "Specification") -> "OrSpecification":
        return OrSpecification(self, other)

    def __invert__(self) -> "NotSpecification":
        return NotSpecification(self)

    # ------------------------------------------------------------------
    # Pretty-printing (Requirements 15.1, 15.2)
    # ------------------------------------------------------------------

    def __repr__(self) -> str:
        return f"{type(self).__name__}()"

    def __str__(self) -> str:
        return f"{type(self).__name__}"


# ---------------------------------------------------------------------------
# Composite nodes
# ---------------------------------------------------------------------------


class AndSpecification(Specification):
    """Logical AND of two specifications (``s1 & s2``)."""

    def __init__(self, left: Specification, right: Specification) -> None:
        self.left = left
        self.right = right

    def is_satisfied_by(self, entity: object) -> bool:
        return self.left.is_satisfied_by(entity) and self.right.is_satisfied_by(entity)

    def to_query(self) -> Q:
        return self.left.to_query() & self.right.to_query()

    def to_dict(self) -> dict[str, Any]:
        return {
            "type": "and",
            "left": self.left.to_dict(),
            "right": self.right.to_dict(),
        }

    def __repr__(self) -> str:
        return f"AndSpecification({self.left!r}, {self.right!r})"

    def __str__(self) -> str:
        return f"({self.left} AND {self.right})"


class OrSpecification(Specification):
    """Logical OR of two specifications (``s1 | s2``)."""

    def __init__(self, left: Specification, right: Specification) -> None:
        self.left = left
        self.right = right

    def is_satisfied_by(self, entity: object) -> bool:
        return self.left.is_satisfied_by(entity) or self.right.is_satisfied_by(entity)

    def to_query(self) -> Q:
        return self.left.to_query() | self.right.to_query()

    def to_dict(self) -> dict[str, Any]:
        return {
            "type": "or",
            "left": self.left.to_dict(),
            "right": self.right.to_dict(),
        }

    def __repr__(self) -> str:
        return f"OrSpecification({self.left!r}, {self.right!r})"

    def __str__(self) -> str:
        return f"({self.left} OR {self.right})"


class NotSpecification(Specification):
    """Logical NOT of a specification (``~s``)."""

    def __init__(self, operand: Specification) -> None:
        self.operand = operand

    def is_satisfied_by(self, entity: object) -> bool:
        return not self.operand.is_satisfied_by(entity)

    def to_query(self) -> Q:
        return ~self.operand.to_query()

    def to_dict(self) -> dict[str, Any]:
        return {
            "type": "not",
            "operand": self.operand.to_dict(),
        }

    def __repr__(self) -> str:
        return f"NotSpecification({self.operand!r})"

    def __str__(self) -> str:
        return f"(NOT {self.operand})"
