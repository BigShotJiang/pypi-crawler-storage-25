# Generated migration for dmr_toolkit_patterns
# Requirements: 13.1, 4.5, 11.4

import uuid

import django.db.models.deletion
from django.conf import settings
from django.db import migrations, models


class Migration(migrations.Migration):

    initial = True

    dependencies = [
        ("contenttypes", "0002_remove_content_type_name"),
        ("auth", "0012_alter_user_first_name_max_length"),
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
    ]

    operations = [
        migrations.CreateModel(
            name="StateTransitionAudit",
            fields=[
                (
                    "id",
                    models.AutoField(
                        auto_created=True,
                        primary_key=True,
                        serialize=False,
                        verbose_name="ID",
                    ),
                ),
                ("object_id", models.CharField(max_length=255)),
                ("transition", models.CharField(max_length=255)),
                ("from_state", models.CharField(max_length=255)),
                ("to_state", models.CharField(max_length=255)),
                ("timestamp", models.DateTimeField(auto_now_add=True)),
                (
                    "content_type",
                    models.ForeignKey(
                        blank=True,
                        null=True,
                        on_delete=django.db.models.deletion.CASCADE,
                        to="contenttypes.contenttype",
                    ),
                ),
                (
                    "triggered_by",
                    models.ForeignKey(
                        blank=True,
                        null=True,
                        on_delete=django.db.models.deletion.SET_NULL,
                        related_name="+",
                        to=settings.AUTH_USER_MODEL,
                    ),
                ),
            ],
            options={
                "app_label": "dmr_toolkit_patterns",
            },
        ),
        migrations.CreateModel(
            name="CommandAuditLog",
            fields=[
                (
                    "id",
                    models.AutoField(
                        auto_created=True,
                        primary_key=True,
                        serialize=False,
                        verbose_name="ID",
                    ),
                ),
                ("command_class", models.CharField(max_length=255)),
                ("input_params", models.JSONField()),
                ("result", models.JSONField(blank=True, null=True)),
                ("timestamp", models.DateTimeField(auto_now_add=True)),
                ("success", models.BooleanField()),
                (
                    "executed_by",
                    models.ForeignKey(
                        blank=True,
                        null=True,
                        on_delete=django.db.models.deletion.SET_NULL,
                        related_name="+",
                        to=settings.AUTH_USER_MODEL,
                    ),
                ),
            ],
            options={
                "app_label": "dmr_toolkit_patterns",
            },
        ),
        migrations.CreateModel(
            name="DomainEvent",
            fields=[
                (
                    "id",
                    models.UUIDField(
                        default=uuid.uuid4,
                        primary_key=True,
                        serialize=False,
                    ),
                ),
                ("aggregate_id", models.CharField(db_index=True, max_length=255)),
                ("aggregate_type", models.CharField(max_length=255)),
                ("event_type", models.CharField(db_index=True, max_length=255)),
                ("payload", models.JSONField()),
                ("schema_version", models.PositiveIntegerField(default=1)),
                ("sequence", models.PositiveIntegerField()),
                ("timestamp", models.DateTimeField(auto_now_add=True)),
            ],
            options={
                "app_label": "dmr_toolkit_patterns",
                "ordering": ["aggregate_id", "sequence"],
            },
        ),
        migrations.AddConstraint(
            model_name="domainevent",
            constraint=models.UniqueConstraint(
                fields=["aggregate_id", "sequence"],
                name="dmr_toolkit_patterns_domainevent_aggregate_id_sequence_uniq",
            ),
        ),
        migrations.CreateModel(
            name="Snapshot",
            fields=[
                (
                    "id",
                    models.AutoField(
                        auto_created=True,
                        primary_key=True,
                        serialize=False,
                        verbose_name="ID",
                    ),
                ),
                ("aggregate_id", models.CharField(max_length=255, unique=True)),
                ("aggregate_type", models.CharField(max_length=255)),
                ("state", models.JSONField()),
                ("sequence", models.PositiveIntegerField()),
                ("timestamp", models.DateTimeField(auto_now_add=True)),
            ],
            options={
                "app_label": "dmr_toolkit_patterns",
            },
        ),
    ]
