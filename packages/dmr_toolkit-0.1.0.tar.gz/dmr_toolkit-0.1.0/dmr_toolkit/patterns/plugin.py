"""
dmr_toolkit.patterns.plugin
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Plugin Registry pattern.

Provides a runtime registry that discovers, validates, and activates
third-party plugins declared under an entry-point group.

Usage::

    from dmr_toolkit.patterns.plugin import PluginRegistry, PluginMeta

    registry = PluginRegistry()
    registry.load_entry_points("dmr_toolkit.plugins")

    registry.register("my_plugin", MyPlugin)
    plugin_class = registry.get("my_plugin")
    registry.unregister("my_plugin")

    for meta in registry.list_plugins():
        print(meta.name, meta.status)
"""
from __future__ import annotations

import logging
from dataclasses import dataclass
from importlib.metadata import entry_points
from typing import Any, Literal

from dmr_toolkit.patterns.exceptions import DuplicatePlugin

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Plugin interface
# ---------------------------------------------------------------------------

class Plugin:
    """Minimal interface that all plugins must implement.

    Third-party plugins should subclass this (or implement the same interface)
    to be accepted by :class:`PluginRegistry`.
    """

    #: Human-readable name for the plugin.
    name: str = ""
    #: Semantic version string, e.g. ``"1.0.0"``.
    version: str = "0.0.0"

    def activate(self) -> None:  # pragma: no cover
        """Called once when the plugin is activated."""

    def deactivate(self) -> None:  # pragma: no cover
        """Called once when the plugin is unregistered."""

    def __repr__(self) -> str:
        return f"{type(self).__name__}(name={self.name!r}, version={self.version!r})"

    def __str__(self) -> str:
        return f"{type(self).__name__} '{self.name}' v{self.version}"


# ---------------------------------------------------------------------------
# PluginMeta dataclass
# ---------------------------------------------------------------------------

@dataclass
class PluginMeta:
    """Metadata record for a registered plugin.

    Requirements: 5.6, 15.1, 15.2
    """

    name: str
    version: str
    status: Literal["active", "failed", "disabled"]
    plugin_class: type

    def __repr__(self) -> str:
        return (
            f"PluginMeta(name={self.name!r}, version={self.version!r}, "
            f"status={self.status!r}, plugin_class={self.plugin_class.__name__!r})"
        )

    def __str__(self) -> str:
        return (
            f"Plugin '{self.name}' v{self.version} "
            f"[{self.status}] ({self.plugin_class.__name__})"
        )


# ---------------------------------------------------------------------------
# PluginRegistry
# ---------------------------------------------------------------------------

class PluginRegistry:
    """Runtime registry for discovering, validating, and managing plugins.

    Plugins are discovered via :meth:`load_entry_points` (using
    ``importlib.metadata``) or registered manually via :meth:`register`.

    Interface validation is performed before activation; plugins that do not
    implement the required :class:`Plugin` interface are rejected.  Plugins
    that raise during loading are logged and skipped (fault isolation).

    Requirements: 5.1, 5.2, 5.3, 5.4, 5.5, 5.6, 15.1, 15.2
    """

    def __init__(self) -> None:
        # name -> PluginMeta
        self._plugins: dict[str, PluginMeta] = {}

    # ------------------------------------------------------------------
    # Discovery
    # ------------------------------------------------------------------

    def load_entry_points(self, group: str = "dmr_toolkit.plugins") -> None:
        """Discover and register plugins declared under *group* in pyproject.toml.

        For each entry point:
        - Load the plugin class.
        - Validate the interface.
        - Register if valid; log and skip on any failure.

        Requirements: 5.1, 5.3
        """
        eps = entry_points(group=group)
        for ep in eps:
            try:
                plugin_class: type = ep.load()
                self._validate_interface(plugin_class)
                name = getattr(plugin_class, "name", None) or ep.name
                version = getattr(plugin_class, "version", "0.0.0")
                self._add(name, version, plugin_class)
            except DuplicatePlugin:
                raise
            except Exception as exc:  # noqa: BLE001
                logger.warning(
                    "Failed to load plugin from entry point %r: %s",
                    ep.name,
                    exc,
                    exc_info=True,
                )

    # ------------------------------------------------------------------
    # Manual management (Requirement 5.4)
    # ------------------------------------------------------------------

    def register(self, name: str, plugin_class: type) -> None:
        """Register *plugin_class* under *name*.

        Raises :class:`~dmr_toolkit.patterns.exceptions.DuplicatePlugin` if
        *name* is already registered (Requirement 5.5).

        Raises :exc:`TypeError` if *plugin_class* does not implement the
        required :class:`Plugin` interface (Requirement 5.2).
        """
        self._validate_interface(plugin_class)
        version = getattr(plugin_class, "version", "0.0.0")
        self._add(name, version, plugin_class)

    def unregister(self, name: str) -> None:
        """Remove the plugin registered under *name*.

        Raises :exc:`KeyError` if *name* is not registered.
        """
        if name not in self._plugins:
            raise KeyError(f"No plugin registered under name {name!r}")
        del self._plugins[name]

    def get(self, name: str) -> type:
        """Return the plugin class registered under *name*.

        Raises :exc:`KeyError` if *name* is not registered.
        """
        if name not in self._plugins:
            raise KeyError(f"No plugin registered under name {name!r}")
        return self._plugins[name].plugin_class

    # ------------------------------------------------------------------
    # Introspection (Requirement 5.6)
    # ------------------------------------------------------------------

    def list_plugins(self) -> list[PluginMeta]:
        """Return metadata for all registered plugins."""
        return list(self._plugins.values())

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _validate_interface(self, plugin_class: type) -> None:
        """Raise :exc:`TypeError` if *plugin_class* is not a valid Plugin.

        A valid plugin must be a class (not an instance) and must be a
        subclass of :class:`Plugin` or implement ``activate`` and
        ``deactivate`` callables.

        Requirement 5.2
        """
        if not isinstance(plugin_class, type):
            raise TypeError(
                f"Plugin must be a class, got {type(plugin_class).__name__!r}"
            )
        has_activate = callable(getattr(plugin_class, "activate", None))
        has_deactivate = callable(getattr(plugin_class, "deactivate", None))
        if not (has_activate and has_deactivate):
            raise TypeError(
                f"Plugin class {plugin_class.__name__!r} must implement "
                "'activate' and 'deactivate' methods"
            )

    def _add(self, name: str, version: str, plugin_class: type) -> None:
        """Internal: add a validated plugin, raising DuplicatePlugin if needed."""
        if name in self._plugins:
            raise DuplicatePlugin(name=name)
        meta = PluginMeta(
            name=name,
            version=version,
            status="active",
            plugin_class=plugin_class,
        )
        self._plugins[name] = meta

    # ------------------------------------------------------------------
    # Pretty-printing (Requirements 15.1, 15.2)
    # ------------------------------------------------------------------

    def __repr__(self) -> str:
        return f"PluginRegistry(plugins={list(self._plugins.keys())!r})"

    def __str__(self) -> str:
        lines = [f"PluginRegistry with {len(self._plugins)} plugin(s):"]
        for meta in self._plugins.values():
            lines.append(f"  {meta}")
        return "\n".join(lines)
