"""
dmr_toolkit.patterns.lazy
~~~~~~~~~~~~~~~~~~~~~~~~~~
Lazy Loader descriptor for deferred, cached resource initialisation.

Usage::

    from dmr_toolkit.patterns import lazy

    class MyService:
        client = lazy(lambda: ExpensiveClient())
        cached_data = lazy(lambda: fetch_data(), ttl=60.0)

    svc = MyService()
    svc.client   # factory called once; result cached on svc
    svc.client   # returns cached value — factory NOT called again

    # Clear the cache on demand:
    MyService.client.reset(svc)
"""
from __future__ import annotations

import threading
import time
from typing import Callable, Generic, Optional, TypeVar

__all__ = ["lazy"]

T = TypeVar("T")

# Sentinel used to distinguish "not yet computed" from a cached value of None.
_MISSING = object()


class lazy(Generic[T]):
    """Descriptor that defers and caches the result of *factory* on first access.

    Args:
        factory: Zero-argument callable whose return value is cached on the
            owning instance after the first access.
        ttl: Optional time-to-live in seconds.  After *ttl* seconds the cached
            value is considered stale; the next access re-invokes *factory*.

    Thread safety:
        A ``threading.Lock`` is stored per owning *instance* (not per
        descriptor) so that concurrent first-accesses on the same instance
        invoke *factory* exactly once.
    """

    # Per-instance storage keys derived from the descriptor's attribute name.
    # We use mangled names to avoid collisions with user-defined attributes.
    _CACHE_KEY_TMPL = "_lazy_cache_{name}"
    _LOCK_KEY_TMPL = "_lazy_lock_{name}"
    _TS_KEY_TMPL = "_lazy_ts_{name}"

    def __init__(
        self,
        factory: Callable[[], T],
        ttl: Optional[float] = None,
    ) -> None:
        self._factory = factory
        self._ttl = ttl
        self._attr_name: str = ""  # set by __set_name__

    # ------------------------------------------------------------------
    # Descriptor protocol
    # ------------------------------------------------------------------

    def __set_name__(self, owner: type, name: str) -> None:
        """Called by Python when the descriptor is assigned to a class attribute."""
        self._attr_name = name

    def __get__(self, obj: object, objtype: type = None) -> T:  # type: ignore[override]
        # Class-level access (obj is None) — return the descriptor itself so
        # callers can invoke .reset() via the class.
        if obj is None:
            return self  # type: ignore[return-value]

        cache_key = self._CACHE_KEY_TMPL.format(name=self._attr_name)
        lock_key = self._LOCK_KEY_TMPL.format(name=self._attr_name)
        ts_key = self._TS_KEY_TMPL.format(name=self._attr_name)

        # Ensure a per-instance lock exists.  We use a double-checked pattern
        # to avoid a race on the lock creation itself.
        if not hasattr(obj, lock_key):
            # Use object.__setattr__ to bypass any custom __setattr__ on owner.
            object.__setattr__(obj, lock_key, threading.Lock())

        lock: threading.Lock = object.__getattribute__(obj, lock_key)

        with lock:
            cached = getattr(obj, cache_key, _MISSING)

            # Check TTL expiry.
            if cached is not _MISSING and self._ttl is not None:
                ts: float = getattr(obj, ts_key, 0.0)
                if time.monotonic() - ts >= self._ttl:
                    cached = _MISSING  # treat as expired

            if cached is _MISSING:
                cached = self._factory()
                object.__setattr__(obj, cache_key, cached)
                if self._ttl is not None:
                    object.__setattr__(obj, ts_key, time.monotonic())

        return cached  # type: ignore[return-value]

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def reset(self, obj: object) -> None:
        """Clear the cached value on *obj*.

        The next attribute access will re-invoke the factory callable.

        Args:
            obj: The owning instance whose cached value should be cleared.
        """
        cache_key = self._CACHE_KEY_TMPL.format(name=self._attr_name)
        ts_key = self._TS_KEY_TMPL.format(name=self._attr_name)

        lock_key = self._LOCK_KEY_TMPL.format(name=self._attr_name)
        lock: Optional[threading.Lock] = getattr(obj, lock_key, None)

        def _clear() -> None:
            try:
                object.__delattr__(obj, cache_key)
            except AttributeError:
                pass
            try:
                object.__delattr__(obj, ts_key)
            except AttributeError:
                pass

        if lock is not None:
            with lock:
                _clear()
        else:
            _clear()

    # ------------------------------------------------------------------
    # Pretty-printing (Requirements 15.1, 15.2)
    # ------------------------------------------------------------------

    def __repr__(self) -> str:
        ttl_part = f", ttl={self._ttl!r}" if self._ttl is not None else ""
        return (
            f"lazy(factory={self._factory!r}{ttl_part}, attr={self._attr_name!r})"
        )

    def __str__(self) -> str:
        ttl_info = (
            f"TTL: {self._ttl}s" if self._ttl is not None else "TTL: none (permanent cache)"
        )
        return (
            f"lazy descriptor '{self._attr_name}'\n"
            f"  factory : {self._factory!r}\n"
            f"  {ttl_info}"
        )
