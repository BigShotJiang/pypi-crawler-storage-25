"""
dmr_toolkit.patterns.component
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Component pattern: self-contained, reusable API response fragments.

Usage::

    from dmr_toolkit.patterns.component import Component, DMRComponentMixin

    class UserCard(Component):
        def render(self, context: dict) -> dict:
            return {"user_id": context.get("user_id"), "name": "Alice"}

    class ProfilePage(Component):
        children = [UserCard()]

        def render(self, context: dict) -> dict:
            result = {"page": "profile"}
            for child in self.children:
                result.update(child.render(context))
            return result
"""
from __future__ import annotations

import asyncio
import json
from abc import ABC, abstractmethod
from typing import TYPE_CHECKING, Optional

from django.core.cache import cache

from dmr_toolkit.patterns.cache import _key_registry

if TYPE_CHECKING:
    pass


class Component(ABC):
    """Abstract base class for composable API response fragments.

    Subclasses must implement :meth:`render`. Children are resolved
    recursively; async rendering resolves siblings concurrently via
    :func:`asyncio.gather`.

    Class attributes:
        cache_ttl: When set, rendered output is cached for this many seconds
            using Django's cache framework.
        children: Child components whose output is merged into this
            component's render result.
    """

    cache_ttl: Optional[int] = None
    children: list["Component"] = []

    @abstractmethod
    def render(self, context: dict) -> dict:
        """Render this component and return a JSON-serialisable dict.

        Args:
            context: Arbitrary context data passed down from the caller.

        Returns:
            A dict that can be serialised with :func:`json.dumps`.
        """
        ...  # pragma: no cover

    def _cache_key(self, context: dict) -> str:
        """Build a deterministic cache key for this component + context."""
        return f"{type(self).__name__}:{context!s}"

    def _render_with_cache(self, context: dict) -> dict:
        """Call :meth:`render` with optional caching.

        If ``cache_ttl`` is set, the result is stored in Django's cache
        framework and returned on subsequent calls with the same context.
        """
        if self.cache_ttl is None:
            result = self.render(context)
            # Merge children
            for child in self.children:
                result.update(child._render_with_cache(context))
            return result

        key = self._cache_key(context)
        cached_value = cache.get(key)
        if cached_value is not None:
            return cached_value  # type: ignore[return-value]

        result = self.render(context)
        for child in self.children:
            result.update(child._render_with_cache(context))

        cache.set(key, result, self.cache_ttl)
        _key_registry.add(key)
        return result

    async def arender(self, context: dict) -> dict:
        """Async render that resolves children concurrently via asyncio.gather.

        Args:
            context: Arbitrary context data passed down from the caller.

        Returns:
            Merged dict from this component and all children.
        """
        # Run own render in executor to avoid blocking the event loop
        loop = asyncio.get_event_loop()
        own_result = await loop.run_in_executor(None, self.render, context)

        if self.children:
            child_results = await asyncio.gather(
                *[child.arender(context) for child in self.children]
            )
            for child_result in child_results:
                own_result.update(child_result)

        return own_result

    def __repr__(self) -> str:
        return (
            f"{type(self).__name__}("
            f"cache_ttl={self.cache_ttl!r}, "
            f"children={self.children!r})"
        )

    def __str__(self) -> str:
        child_count = len(self.children)
        return (
            f"{type(self).__name__} "
            f"[cache_ttl={self.cache_ttl}, children={child_count}]"
        )


class DMRComponentMixin:
    """Mixin for DMR_Controller that adds component-based response rendering.

    Usage::

        class MyController(DMRComponentMixin, DMRController):
            def get(self, request):
                root = MyRootComponent()
                return self.component_response(root)
    """

    def component_response(self, root: "Component") -> dict:
        """Render *root* and return the merged result dict.

        Args:
            root: The root :class:`Component` to render.

        Returns:
            The fully merged response dict from the component tree.
        """
        return root._render_with_cache({})

    def __repr__(self) -> str:
        return f"{type(self).__name__}(DMRComponentMixin)"

    def __str__(self) -> str:
        return f"{type(self).__name__} [DMRComponentMixin]"
