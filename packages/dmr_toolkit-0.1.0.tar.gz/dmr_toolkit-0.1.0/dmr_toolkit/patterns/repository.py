"""
dmr_toolkit.patterns.repository
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Abstract Repository pattern and Django ORM concrete implementation.

Usage::

    from dmr_toolkit.patterns.repository import DjangoRepository

    class OrderRepository(DjangoRepository[Order, int]):
        pass

    repo = OrderRepository(Order)
    order = repo.get(42)          # raises NotFound if missing
    orders = repo.list(ActiveSpec())
"""
from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any, Generic, Optional, Sequence, TypeVar

from dmr_toolkit.patterns._telemetry import span
from dmr_toolkit.patterns.exceptions import NotFound
from dmr_toolkit.patterns.specification import Specification

T = TypeVar("T")
ID = TypeVar("ID")


class Repository(ABC, Generic[T, ID]):
    """Abstract typed repository.

    Subclasses bind to a concrete storage backend and implement all
    sync/async CRUD operations.
    """

    @abstractmethod
    def get(self, id: ID) -> T:
        """Return the entity with the given *id*, or raise :exc:`NotFound`."""

    @abstractmethod
    async def aget(self, id: ID) -> T:
        """Async variant of :meth:`get`."""

    @abstractmethod
    def list(self, spec: Optional[Specification] = None) -> Sequence[T]:
        """Return all entities, optionally filtered by *spec*."""

    @abstractmethod
    async def alist(self, spec: Optional[Specification] = None) -> Sequence[T]:
        """Async variant of :meth:`list`."""

    @abstractmethod
    def add(self, entity: T) -> T:
        """Persist a new *entity* and return it."""

    @abstractmethod
    async def aadd(self, entity: T) -> T:
        """Async variant of :meth:`add`."""

    @abstractmethod
    def update(self, entity: T) -> T:
        """Persist changes to an existing *entity* and return it."""

    @abstractmethod
    async def aupdate(self, entity: T) -> T:
        """Async variant of :meth:`update`."""

    @abstractmethod
    def remove(self, id: ID) -> None:
        """Delete the entity with the given *id*."""

    @abstractmethod
    async def aremove(self, id: ID) -> None:
        """Async variant of :meth:`remove`."""

    def __repr__(self) -> str:
        return f"{type(self).__name__}()"

    def __str__(self) -> str:
        return type(self).__name__


class DjangoRepository(Repository[T, ID]):
    """Concrete repository backed by a Django Model's default manager.

    Args:
        model_class: The Django Model class to manage.

    Example::

        repo = DjangoRepository(Order)
        order = repo.get(42)
    """

    def __init__(self, model_class: type) -> None:
        self._model_class = model_class

    # ------------------------------------------------------------------
    # get / aget
    # ------------------------------------------------------------------

    def get(self, id: ID) -> T:
        with span("repository.get", attributes={"model": self._model_class.__name__}):
            try:
                return self._model_class._default_manager.get(pk=id)  # type: ignore[return-value]
            except self._model_class.DoesNotExist:
                raise NotFound(model=self._model_class.__name__, id=id)

    async def aget(self, id: ID) -> T:
        with span("repository.aget", attributes={"model": self._model_class.__name__}):
            try:
                return await self._model_class._default_manager.aget(pk=id)  # type: ignore[return-value]
            except self._model_class.DoesNotExist:
                raise NotFound(model=self._model_class.__name__, id=id)

    # ------------------------------------------------------------------
    # list / alist
    # ------------------------------------------------------------------

    def list(self, spec: Optional[Specification] = None) -> Sequence[T]:
        with span("repository.list", attributes={"model": self._model_class.__name__}):
            manager = self._model_class._default_manager
            if spec is not None:
                return list(manager.filter(spec.to_query()))  # type: ignore[return-value]
            return list(manager.all())  # type: ignore[return-value]

    async def alist(self, spec: Optional[Specification] = None) -> Sequence[T]:
        with span("repository.alist", attributes={"model": self._model_class.__name__}):
            manager = self._model_class._default_manager
            qs = manager.filter(spec.to_query()) if spec is not None else manager.all()
            return [obj async for obj in qs]  # type: ignore[return-value]

    # ------------------------------------------------------------------
    # add / aadd
    # ------------------------------------------------------------------

    def add(self, entity: T) -> T:
        with span("repository.add", attributes={"model": self._model_class.__name__}):
            entity.save()  # type: ignore[union-attr]
            return entity

    async def aadd(self, entity: T) -> T:
        with span("repository.aadd", attributes={"model": self._model_class.__name__}):
            await entity.asave()  # type: ignore[union-attr]
            return entity

    # ------------------------------------------------------------------
    # update / aupdate
    # ------------------------------------------------------------------

    def update(self, entity: T) -> T:
        with span("repository.update", attributes={"model": self._model_class.__name__}):
            entity.save()  # type: ignore[union-attr]
            return entity

    async def aupdate(self, entity: T) -> T:
        with span("repository.aupdate", attributes={"model": self._model_class.__name__}):
            await entity.asave()  # type: ignore[union-attr]
            return entity

    # ------------------------------------------------------------------
    # remove / aremove
    # ------------------------------------------------------------------

    def remove(self, id: ID) -> None:
        with span("repository.remove", attributes={"model": self._model_class.__name__}):
            self._model_class._default_manager.filter(pk=id).delete()

    async def aremove(self, id: ID) -> None:
        with span("repository.aremove", attributes={"model": self._model_class.__name__}):
            await self._model_class._default_manager.filter(pk=id).adelete()

    # ------------------------------------------------------------------
    # Repr / str
    # ------------------------------------------------------------------

    def __repr__(self) -> str:
        return f"{type(self).__name__}(model_class={self._model_class.__name__!r})"

    def __str__(self) -> str:
        return f"{type(self).__name__}[{self._model_class.__name__}]"
