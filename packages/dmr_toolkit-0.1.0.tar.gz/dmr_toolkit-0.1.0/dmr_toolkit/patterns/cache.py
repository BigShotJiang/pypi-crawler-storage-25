"""
dmr_toolkit.patterns.cache
~~~~~~~~~~~~~~~~~~~~~~~~~~~
Cache Layer pattern: transparent, key-managed caching decorators.

Usage::

    from dmr_toolkit.patterns.cache import cached, cache_invalidate

    @cached(ttl=60, key_prefix="orders:", vary_on=["user_id"])
    def get_orders(user_id: int) -> list:
        ...

    @cache_invalidate("orders:*")
    def create_order(user_id: int, data: dict) -> None:
        ...

Repository Integration (Requirement 10.7)
------------------------------------------

Use ``@cached`` on read methods and ``@cache_invalidate`` on mutating methods
to add transparent caching to a ``DjangoRepository`` subclass::

    from dmr_toolkit.patterns.cache import cached, cache_invalidate
    from dmr_toolkit.patterns.repository import DjangoRepository

    class CachedOrderRepository(DjangoRepository):
        @cached(ttl=300, key_prefix="orders:list:")
        def list(self, spec=None):
            return super().list(spec)

        @cache_invalidate("orders:list:*")
        def add(self, entity):
            return super().add(entity)

        @cache_invalidate("orders:list:*")
        def update(self, entity):
            return super().update(entity)

        @cache_invalidate("orders:list:*")
        def remove(self, id):
            return super().remove(id)

After any ``add``, ``update``, or ``remove`` call, all ``list`` cache entries
matching ``"orders:list:*"`` are deleted so the next ``list`` call re-queries
the database.
"""
from __future__ import annotations

import fnmatch
import functools
from typing import Any, Callable

from django.core.cache import cache

from dmr_toolkit.patterns._telemetry import span

# ---------------------------------------------------------------------------
# Internal key registry — tracks all keys set by @cached
# (Django's LocMemCache does not support cache.keys(), so we maintain our own)
# ---------------------------------------------------------------------------

_key_registry: set[str] = set()


def _build_key(
    func: Callable,
    args: tuple,
    kwargs: dict,
    key_prefix: str,
    vary_on: list[str],
) -> str:
    """Build a deterministic cache key for *func* called with *args*/*kwargs*.

    Key format::

        <key_prefix><func.__qualname__>:<hash(args)>[:<vary_val1>:<vary_val2>...]
    """
    base = f"{key_prefix}{func.__qualname__}:{hash(args)}"

    if vary_on:
        vary_parts: list[str] = []
        for path in vary_on:
            # Resolve dotted path from kwargs first, then from a 'request' kwarg
            value = _resolve_path(path, kwargs)
            vary_parts.append(str(value))
        base = base + ":" + ":".join(vary_parts)

    return base


def _resolve_path(path: str, kwargs: dict) -> Any:
    """Resolve a dotted attribute path from *kwargs*.

    For example, ``"user.id"`` first looks for ``kwargs["user"]`` then
    accesses ``.id`` on it.  A plain ``"user_id"`` looks for
    ``kwargs["user_id"]`` directly.
    """
    parts = path.split(".")
    root = parts[0]

    # Try direct kwarg first
    obj = kwargs.get(root)
    if obj is None:
        # Fall back to request kwarg
        request = kwargs.get("request")
        if request is not None:
            obj = getattr(request, root, None)

    for attr in parts[1:]:
        if obj is None:
            break
        obj = getattr(obj, attr, None)

    return obj


# ---------------------------------------------------------------------------
# @cached decorator
# ---------------------------------------------------------------------------


def cached(
    ttl: int = 300,
    key_prefix: str = "",
    vary_on: list[str] | None = None,
) -> Callable:
    """Decorator factory that caches the return value of the wrapped callable.

    Args:
        ttl: Time-to-live in seconds (default 300).
        key_prefix: Namespace prefix prepended to every cache key.
        vary_on: List of dotted attribute paths resolved from kwargs (or a
            ``request`` kwarg) to include in the cache key, enabling
            per-user / per-tenant isolation.

    Returns:
        A decorator that wraps the target callable with caching logic.
    """
    _vary_on: list[str] = vary_on if vary_on is not None else []

    def decorator(func: Callable) -> "_CachedWrapper":
        wrapper = _CachedWrapper(func, ttl=ttl, key_prefix=key_prefix, vary_on=_vary_on)
        return wrapper

    return decorator


class _CachedWrapper:
    """Callable wrapper produced by :func:`cached`.

    Implements ``__call__``, ``__repr__``, and ``__str__``.
    """

    def __init__(
        self,
        func: Callable,
        ttl: int,
        key_prefix: str,
        vary_on: list[str],
    ) -> None:
        self._func = func
        self._ttl = ttl
        self._key_prefix = key_prefix
        self._vary_on = vary_on
        functools.update_wrapper(self, func)

    def __call__(self, *args: Any, **kwargs: Any) -> Any:
        key = _build_key(
            self._func,
            args,
            kwargs,
            self._key_prefix,
            self._vary_on,
        )

        with span(
            "cache.get",
            attributes={"key": key, "func": self._func.__qualname__},
        ):
            cached_value = cache.get(key)

        if cached_value is not None:
            # Cache hit
            with span("cache.hit", attributes={"key": key}):
                pass
            return cached_value

        # Cache miss — invoke the underlying callable
        with span("cache.miss", attributes={"key": key}):
            result = self._func(*args, **kwargs)

        cache.set(key, result, self._ttl)
        _key_registry.add(key)

        return result

    def __repr__(self) -> str:
        return (
            f"_CachedWrapper(func={self._func.__qualname__!r}, "
            f"ttl={self._ttl!r}, key_prefix={self._key_prefix!r}, "
            f"vary_on={self._vary_on!r})"
        )

    def __str__(self) -> str:
        return (
            f"cached({self._func.__qualname__}) "
            f"[ttl={self._ttl}s, prefix={self._key_prefix!r}, "
            f"vary_on={self._vary_on}]"
        )


# ---------------------------------------------------------------------------
# @cache_invalidate decorator
# ---------------------------------------------------------------------------


def cache_invalidate(pattern: str) -> Callable:
    """Decorator factory that invalidates cache keys matching *pattern*.

    When the decorated function is called, all keys in the internal registry
    that match *pattern* (using :func:`fnmatch.fnmatch`) are deleted from the
    cache.

    Args:
        pattern: A glob-style pattern (e.g. ``"orders:*"``).

    Returns:
        A decorator that wraps the target callable with invalidation logic.
    """

    def decorator(func: Callable) -> "_InvalidateWrapper":
        wrapper = _InvalidateWrapper(func, pattern=pattern)
        return wrapper

    return decorator


class _InvalidateWrapper:
    """Callable wrapper produced by :func:`cache_invalidate`.

    Implements ``__call__``, ``__repr__``, and ``__str__``.
    """

    def __init__(self, func: Callable, pattern: str) -> None:
        self._func = func
        self._pattern = pattern
        functools.update_wrapper(self, func)

    def __call__(self, *args: Any, **kwargs: Any) -> Any:
        result = self._func(*args, **kwargs)
        self._invalidate()
        return result

    def _invalidate(self) -> None:
        """Delete all registry keys matching ``self._pattern``."""
        matching = {
            key for key in _key_registry if fnmatch.fnmatch(key, self._pattern)
        }
        if matching:
            with span(
                "cache.invalidate",
                attributes={"pattern": self._pattern, "count": len(matching)},
            ):
                for key in matching:
                    cache.delete(key)
                _key_registry.difference_update(matching)

    def __repr__(self) -> str:
        return (
            f"_InvalidateWrapper(func={self._func.__qualname__!r}, "
            f"pattern={self._pattern!r})"
        )

    def __str__(self) -> str:
        return f"cache_invalidate({self._func.__qualname__}) [pattern={self._pattern!r}]"
