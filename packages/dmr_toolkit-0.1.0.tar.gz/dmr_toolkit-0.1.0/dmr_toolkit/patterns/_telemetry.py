"""
dmr_toolkit.patterns._telemetry
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Internal OpenTelemetry span helpers.

This module provides a thin wrapper around OTel tracing. When the
observability middleware (and therefore the ``opentelemetry`` package) is
absent, every helper degrades gracefully to a no-op so that the patterns
module remains importable without optional dependencies.

Usage::

    from dmr_toolkit.patterns._telemetry import span

    with span("repository.get", attributes={"model": "Order", "id": 42}):
        ...  # your operation here
"""
from __future__ import annotations

import contextlib
from typing import Any, Generator

# ---------------------------------------------------------------------------
# Optional OTel import — no-op when the package is absent
# ---------------------------------------------------------------------------

_otel_trace = None  # type: ignore[assignment]
_StatusCode = None  # type: ignore[assignment]

try:
    from opentelemetry import trace as _otel_trace  # type: ignore[import]
    from opentelemetry.trace import StatusCode as _StatusCode  # type: ignore[import]

    _OTEL_AVAILABLE = True
except ImportError:  # pragma: no cover
    _OTEL_AVAILABLE = False


# ---------------------------------------------------------------------------
# Public helpers
# ---------------------------------------------------------------------------


@contextlib.contextmanager
def span(
    operation_name: str,
    attributes: dict[str, Any] | None = None,
) -> Generator[Any, None, None]:
    """Context manager that wraps *operation_name* in an OTel span.

    When ``opentelemetry`` is not installed (or the tracer provider has not
    been configured), this is a transparent no-op — the body executes
    normally without any tracing overhead.

    Args:
        operation_name: Human-readable name for the span (e.g.
            ``"repository.get"``).
        attributes: Optional mapping of span attributes to record.

    Yields:
        The active OTel ``Span`` object when tracing is available, or
        ``None`` when it is not.
    """
    if not _OTEL_AVAILABLE:
        yield None
        return

    tracer = _otel_trace.get_tracer("dmr_toolkit.patterns")
    with tracer.start_as_current_span(operation_name) as active_span:
        if attributes:
            for key, value in attributes.items():
                active_span.set_attribute(key, str(value))
        try:
            yield active_span
        except Exception as exc:
            active_span.set_status(_StatusCode.ERROR, str(exc))
            active_span.record_exception(exc)
            raise


def record_error(exc: Exception) -> None:
    """Record *exc* on the currently active OTel span, if any.

    No-op when OTel is unavailable or no span is active.
    """
    if not _OTEL_AVAILABLE:
        return

    current_span = _otel_trace.get_current_span()
    if current_span and current_span.is_recording():
        current_span.set_status(_StatusCode.ERROR, str(exc))
        current_span.record_exception(exc)
