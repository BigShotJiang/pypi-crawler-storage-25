"""
dmr_toolkit.patterns.state_machine
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Declarative state machine bound to a model field.

Provides a class-level DSL for declaring states and transitions, with guard
conditions, Observer event emission, optional audit logging, and OTel tracing.

Usage::

    from dmr_toolkit.patterns.state_machine import StateMachine, Transition

    class OrderMachine(StateMachine):
        class Meta:
            states = ["pending", "paid", "shipped", "cancelled"]
            transitions = [
                Transition("pay",    source="pending",  target="paid"),
                Transition("ship",   source="paid",     target="shipped",  guards=[is_in_stock]),
                Transition("cancel", source=["pending", "paid"], target="cancelled"),
            ]
            state_field = "status"
            audit = True

    machine = OrderMachine()
    machine.trigger(order, "pay", user=request.user)

Requirements: 4.1, 4.2, 4.3, 4.4, 4.5, 4.6, 4.7, 7.7, 14.3, 15.1, 15.2, 15.4
"""
from __future__ import annotations

import datetime
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any, Callable

from dmr_toolkit.patterns._telemetry import span
from dmr_toolkit.patterns.exceptions import GuardFailed, InvalidTransition

if TYPE_CHECKING:
    from dmr_toolkit.patterns.observer import EventBus


@dataclass
class Transition:
    """Describes a single valid state transition.

    Attributes:
        name:    Unique identifier for the transition (e.g. ``"pay"``).
        source:  One or more source states from which this transition is valid.
        target:  The state the entity moves to after the transition.
        guards:  Optional list of callables ``(entity) -> bool``; all must
                 return ``True`` for the transition to proceed.

    Requirements: 4.1, 4.6
    """

    name: str
    source: str | list[str]
    target: str
    guards: list[Callable[..., bool]] = field(default_factory=list)

    def sources(self) -> list[str]:
        """Return source states as a list regardless of how they were declared."""
        if isinstance(self.source, list):
            return self.source
        return [self.source]

    def __repr__(self) -> str:
        return (
            f"Transition(name={self.name!r}, source={self.source!r}, "
            f"target={self.target!r}, guards={self.guards!r})"
        )

    def __str__(self) -> str:
        guard_names = [g.__name__ for g in self.guards]
        return (
            f"Transition '{self.name}': {self.source!r} -> {self.target!r}"
            + (f" [guards: {guard_names}]" if guard_names else "")
        )


class StateMachine:
    """Declarative state machine bound to a Django (or plain Python) model field.

    Subclass and define an inner ``Meta`` class, or pass a ``Meta`` class to
    the constructor directly::

        class OrderMachine(StateMachine):
            class Meta:
                states = ["pending", "paid", "shipped"]
                transitions = [Transition("pay", "pending", "paid")]

    Requirements: 4.1, 4.2, 4.3, 4.4, 4.5, 4.6, 4.7, 7.7, 14.3, 15.1, 15.2, 15.4
    """

    class Meta:
        """Default (empty) Meta — subclasses override this."""

        states: list[str] = []
        transitions: list[Transition] = []
        state_field: str = "status"
        audit: bool = False

    # ------------------------------------------------------------------
    # Construction
    # ------------------------------------------------------------------

    def __init__(self, meta: type | None = None) -> None:
        """Initialise the state machine.

        Args:
            meta: An optional ``Meta`` class to use instead of the subclass
                  ``Meta``.  When omitted the subclass's own ``Meta`` is used.
        """
        resolved_meta: type = meta if meta is not None else type(self).Meta

        self._states: list[str] = list(getattr(resolved_meta, "states", []))
        self._transitions: list[Transition] = list(getattr(resolved_meta, "transitions", []))
        self._state_field: str = getattr(resolved_meta, "state_field", "status")
        self._audit_enabled: bool = bool(getattr(resolved_meta, "audit", False))

        self._event_bus: EventBus | None = None
        self._audit_log: list[dict[str, Any]] = []

    # ------------------------------------------------------------------
    # Event bus wiring (Requirement 7.7)
    # ------------------------------------------------------------------

    def set_event_bus(self, bus: EventBus) -> None:
        """Attach an :class:`~dmr_toolkit.patterns.observer.EventBus` for event emission.

        After calling this method, every successful :meth:`trigger` call will
        emit an event on *bus* with the event type ``"<ModelName>.<transition>"``
        and a payload containing ``entity``, ``from_state``, ``to_state``, and
        ``user``.  This wires the StateMachine → EventBus integration described
        in Requirements 4.4 and 7.7.

        Example::

            from dmr_toolkit.patterns.observer import EventBus
            from dmr_toolkit.patterns.state_machine import StateMachine, Transition

            bus = EventBus()

            @bus.on("order.pay")
            def on_paid(payload):
                print("order paid:", payload["entity"])

            machine = OrderMachine()
            machine.set_event_bus(bus)
            machine.trigger(order, "pay", user=request.user)
            # ↑ emits "order.pay" on bus after successful transition

        Requirements: 4.4, 7.7
        """
        self._event_bus = bus

    # ------------------------------------------------------------------
    # Core trigger (Requirements 4.2, 4.3, 4.4, 4.5, 4.6, 4.7, 14.3)
    # ------------------------------------------------------------------

    def trigger(self, entity: Any, transition_name: str, user: Any = None) -> None:
        """Validate and execute a named transition on *entity*.

        Steps:
        1. Locate the :class:`Transition` by name.
        2. Verify the entity's current state is a valid source state.
        3. Run all guard callables.
        4. Update the state field.
        5. Persist via ``entity.save()`` if available.
        6. Emit an Observer event on the attached bus.
        7. Append an audit entry when audit logging is enabled.

        Args:
            entity:          The object whose state field will be updated.
            transition_name: Name of the transition to trigger.
            user:            Optional user performing the transition (included
                             in the emitted event payload).

        Raises:
            InvalidTransition: When the entity's current state is not a valid
                               source for the requested transition.
            GuardFailed:       When any guard callable returns ``False``.

        Requirements: 4.2, 4.3, 4.4, 4.5, 4.6, 4.7, 14.3
        """
        model_name = type(entity).__name__

        with span(
            f"state_machine.trigger",
            attributes={
                "model": model_name,
                "transition": transition_name,
                "state_field": self._state_field,
            },
        ):
            # 1. Find transition
            transition = self._find_transition(transition_name)

            # 2. Validate source state
            current_state: str = getattr(entity, self._state_field)
            if current_state not in transition.sources():
                raise InvalidTransition(
                    current_state=current_state,
                    transition=transition_name,
                    model=model_name,
                )

            # 3. Run guards (Requirement 4.6, 4.7)
            for guard in transition.guards:
                if not guard(entity):
                    raise GuardFailed(
                        guard=guard.__name__,
                        transition=transition_name,
                    )

            old_state = current_state

            # 4. Update state field (Requirement 4.2)
            setattr(entity, self._state_field, transition.target)

            # 5. Persist (Requirement 4.2)
            if hasattr(entity, "save") and callable(entity.save):
                entity.save()

            # 6. Emit Observer event (Requirement 4.4, 7.7)
            if self._event_bus is not None:
                event_type = f"{model_name.lower()}.{transition_name}"
                self._event_bus.emit(
                    event_type,
                    {
                        "entity": entity,
                        "from_state": old_state,
                        "to_state": transition.target,
                        "user": user,
                    },
                )

            # 7. Audit log (Requirement 4.5)
            if self._audit_enabled:
                self._audit_log.append(
                    {
                        "model": model_name,
                        "transition": transition_name,
                        "from_state": old_state,
                        "to_state": transition.target,
                        "user": user,
                        "timestamp": datetime.datetime.now(datetime.timezone.utc).isoformat(),
                    }
                )

    # ------------------------------------------------------------------
    # Diagram (Requirement 15.4)
    # ------------------------------------------------------------------

    def diagram(self) -> str:
        """Return a Mermaid ``stateDiagram-v2`` string for all states and transitions.

        Example output::

            stateDiagram-v2
                [*] --> pending
                pending --> paid : pay
                paid --> shipped : ship
                pending --> cancelled : cancel
                paid --> cancelled : cancel

        Requirements: 15.4
        """
        lines: list[str] = ["stateDiagram-v2"]

        # Initial arrow to first declared state (if any)
        if self._states:
            lines.append(f"    [*] --> {self._states[0]}")

        # Emit all declared states so isolated states appear in the diagram
        referenced: set[str] = set()
        for t in self._transitions:
            referenced.update(t.sources())
            referenced.add(t.target)
        for state in self._states:
            if state not in referenced:
                lines.append(f"    {state}")

        for t in self._transitions:
            for src in t.sources():
                lines.append(f"    {src} --> {t.target} : {t.name}")

        return "\n".join(lines)

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _find_transition(self, name: str) -> Transition:
        """Return the :class:`Transition` with the given *name*.

        Raises:
            InvalidTransition: When no transition with that name exists.
        """
        for t in self._transitions:
            if t.name == name:
                return t
        raise InvalidTransition(
            current_state="<unknown>",
            transition=name,
            model="<unknown>",
        )

    # ------------------------------------------------------------------
    # Pretty-printing (Requirements 15.1, 15.2)
    # ------------------------------------------------------------------

    def __repr__(self) -> str:
        return (
            f"StateMachine(states={self._states!r}, "
            f"transitions={[t.name for t in self._transitions]!r}, "
            f"state_field={self._state_field!r}, "
            f"audit={self._audit_enabled!r})"
        )

    def __str__(self) -> str:
        lines = [
            f"StateMachine",
            f"  state_field : {self._state_field!r}",
            f"  audit       : {self._audit_enabled}",
            f"  states      : {', '.join(self._states) or '(none)'}",
            f"  transitions :",
        ]
        for t in self._transitions:
            guard_names = [g.__name__ for g in t.guards]
            lines.append(
                f"    {t.name!r}: {t.source!r} -> {t.target!r}"
                + (f"  [guards: {guard_names}]" if guard_names else "")
            )
        return "\n".join(lines)
