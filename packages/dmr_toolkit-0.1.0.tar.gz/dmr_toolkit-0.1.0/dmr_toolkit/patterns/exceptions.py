"""
dmr_toolkit.patterns.exceptions
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Exception hierarchy for the patterns module.

All exceptions carry structured context kwargs to aid debugging and logging.
"""
from __future__ import annotations

from typing import Any


class PatternError(Exception):
    """Base exception for all dmr_toolkit.patterns errors."""

    def __init__(self, message: str = "", **context: Any) -> None:
        self.message = message
        self.context = context
        super().__init__(message)

    def __repr__(self) -> str:
        ctx = ", ".join(f"{k}={v!r}" for k, v in self.context.items())
        parts = [repr(self.message)] if self.message else []
        if ctx:
            parts.append(ctx)
        return f"{type(self).__name__}({', '.join(parts)})"

    def __str__(self) -> str:
        lines = [f"{type(self).__name__}: {self.message}" if self.message else type(self).__name__]
        for key, value in self.context.items():
            lines.append(f"  {key}: {value!r}")
        return "\n".join(lines)


class NotFound(PatternError):
    """Raised by Repository.get / aget when the requested entity does not exist.

    Example::

        raise NotFound(model="Order", id=42)
    """

    def __init__(self, model: str = "", id: Any = None, **context: Any) -> None:
        message = f"{model} with id={id!r} not found" if model else "Entity not found"
        super().__init__(message, model=model, id=id, **context)


class InvalidTransition(PatternError):
    """Raised by StateMachine when a transition is attempted from an invalid source state.

    Example::

        raise InvalidTransition(
            model="Order",
            current_state="cancelled",
            transition="ship",
        )
    """

    def __init__(
        self,
        current_state: str = "",
        transition: str = "",
        model: str = "",
        **context: Any,
    ) -> None:
        message = (
            f"Cannot trigger '{transition}' from state '{current_state}'"
            if transition and current_state
            else "Invalid state transition"
        )
        super().__init__(message, model=model, current_state=current_state, transition=transition, **context)


class GuardFailed(PatternError):
    """Raised by StateMachine when a guard condition returns False.

    Example::

        raise GuardFailed(guard="is_paid", transition="ship", reason="Order not paid")
    """

    def __init__(
        self,
        guard: str = "",
        transition: str = "",
        reason: str = "",
        **context: Any,
    ) -> None:
        message = (
            f"Guard '{guard}' failed for transition '{transition}'"
            + (f": {reason}" if reason else "")
            if guard
            else "Guard condition failed"
        )
        super().__init__(message, guard=guard, transition=transition, reason=reason, **context)


class DuplicatePlugin(PatternError):
    """Raised by PluginRegistry when a plugin name is registered more than once.

    Example::

        raise DuplicatePlugin(name="my_plugin")
    """

    def __init__(self, name: str = "", **context: Any) -> None:
        message = f"Plugin '{name}' is already registered" if name else "Duplicate plugin registration"
        super().__init__(message, name=name, **context)


class StrategyNotFound(PatternError):
    """Raised by Strategy.resolve when the requested name is not in the registry.

    Example::

        raise StrategyNotFound(name="fast", available=["slow", "balanced"])
    """

    def __init__(self, name: str = "", available: list[str] | None = None, **context: Any) -> None:
        available = available or []
        message = (
            f"Strategy '{name}' not found. Available: {available!r}"
            if name
            else "Strategy not found"
        )
        super().__init__(message, name=name, available=available, **context)


class ConcurrencyConflict(PatternError):
    """Raised by EventStore when an append is attempted with a mismatched expected_seq.

    Example::

        raise ConcurrencyConflict(
            aggregate_id="order-1",
            expected_seq=5,
            actual_seq=7,
        )
    """

    def __init__(
        self,
        aggregate_id: str = "",
        expected_seq: int | None = None,
        actual_seq: int | None = None,
        **context: Any,
    ) -> None:
        message = (
            f"Concurrency conflict on aggregate '{aggregate_id}': "
            f"expected seq={expected_seq}, actual seq={actual_seq}"
            if aggregate_id
            else "Concurrency conflict"
        )
        super().__init__(
            message,
            aggregate_id=aggregate_id,
            expected_seq=expected_seq,
            actual_seq=actual_seq,
            **context,
        )


class EventDispatchError(PatternError):
    """Raised by EventBus after dispatching an event when one or more handlers raised exceptions.

    Aggregates all handler errors so that every handler is invoked before the error is surfaced.

    Example::

        raise EventDispatchError(event_type="order.created", errors=[ValueError("bad"), ...])
    """

    def __init__(
        self,
        event_type: str = "",
        errors: list[Exception] | None = None,
        **context: Any,
    ) -> None:
        self.errors: list[Exception] = errors or []
        count = len(self.errors)
        message = (
            f"{count} handler(s) failed while dispatching event '{event_type}'"
            if event_type
            else f"{count} handler(s) failed during event dispatch"
        )
        super().__init__(message, event_type=event_type, error_count=count, **context)

    def __repr__(self) -> str:
        return (
            f"EventDispatchError(event_type={self.context.get('event_type')!r}, "
            f"error_count={self.context.get('error_count')!r})"
        )

    def __str__(self) -> str:
        base = super().__str__()
        if self.errors:
            error_lines = "\n".join(f"  [{i}] {type(e).__name__}: {e}" for i, e in enumerate(self.errors))
            return f"{base}\nErrors:\n{error_lines}"
        return base
