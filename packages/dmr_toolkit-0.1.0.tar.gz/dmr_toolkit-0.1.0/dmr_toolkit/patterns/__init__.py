"""
dmr_toolkit.patterns
~~~~~~~~~~~~~~~~~~~~~
Reusable, composable design pattern helpers for Django REST APIs.

Each pattern is independently importable::

    from dmr_toolkit.patterns import Repository
    from dmr_toolkit.patterns import Specification
    from dmr_toolkit.patterns.exceptions import NotFound, PatternError

Public symbols are enumerated in ``__all__`` (Requirement 1.4).
"""
from __future__ import annotations

from dmr_toolkit.patterns.exceptions import (
    ConcurrencyConflict,
    DuplicatePlugin,
    EventDispatchError,
    GuardFailed,
    InvalidTransition,
    NotFound,
    PatternError,
    StrategyNotFound,
)
from dmr_toolkit.patterns.repository import (
    DjangoRepository,
    Repository,
)
from dmr_toolkit.patterns.observer import EventBus
from dmr_toolkit.patterns.state_machine import StateMachine, Transition
from dmr_toolkit.patterns.lazy import lazy
from dmr_toolkit.patterns.plugin import Plugin, PluginMeta, PluginRegistry
from dmr_toolkit.patterns.strategy import Strategy
from dmr_toolkit.patterns.cache import cached, cache_invalidate
from dmr_toolkit.patterns.component import Component, DMRComponentMixin
from dmr_toolkit.patterns.command import Command
from dmr_toolkit.patterns.unit_of_work import UnitOfWork
from dmr_toolkit.patterns.event_store import EventStore, EventRecord, SnapshotRecord
from dmr_toolkit.patterns.specification import (
    AndSpecification,
    NotSpecification,
    OrSpecification,
    Specification,
)

__all__: list[str] = [
    # Exceptions
    "PatternError",
    "NotFound",
    "InvalidTransition",
    "GuardFailed",
    "DuplicatePlugin",
    "StrategyNotFound",
    "ConcurrencyConflict",
    "EventDispatchError",
    # Repository
    "Repository",
    "DjangoRepository",
    # Specification
    "Specification",
    "AndSpecification",
    "OrSpecification",
    "NotSpecification",
    # Observer
    "EventBus",
    # State Machine
    "StateMachine",
    "Transition",
    # Plugin Registry
    "Plugin",
    "PluginMeta",
    "PluginRegistry",
    # Lazy Loader
    "lazy",
    # Strategy
    "Strategy",
    # Cache Layer
    "cached",
    "cache_invalidate",
    # Component
    "Component",
    "DMRComponentMixin",
    # Command
    "Command",
    # Unit of Work
    "UnitOfWork",
    # Event Store
    "EventStore",
    "EventRecord",
    "SnapshotRecord",
]
