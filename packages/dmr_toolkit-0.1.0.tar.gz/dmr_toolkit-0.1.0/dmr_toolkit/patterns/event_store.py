"""
dmr_toolkit.patterns.event_store
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
In-memory Event Store for Event Sourcing.

Uses plain Python dicts/lists internally so tests work without Django migrations.
Django ORM models (DomainEvent, Snapshot) live in models.py for persistence use-cases.

Requirements: 13.1–13.6, 15.1, 15.2, 15.5
"""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Callable, Optional

from dmr_toolkit.patterns.exceptions import ConcurrencyConflict


@dataclass
class EventRecord:
    """Immutable in-memory domain event record."""

    aggregate_id: str
    aggregate_type: str
    event_type: str
    payload: dict
    schema_version: int
    sequence: int
    timestamp: datetime

    def __repr__(self) -> str:
        return (
            f"EventRecord(aggregate_id={self.aggregate_id!r}, "
            f"event_type={self.event_type!r}, sequence={self.sequence!r})"
        )

    def __str__(self) -> str:
        return (
            f"EventRecord\n"
            f"  aggregate_id   : {self.aggregate_id!r}\n"
            f"  aggregate_type : {self.aggregate_type!r}\n"
            f"  event_type     : {self.event_type!r}\n"
            f"  sequence       : {self.sequence}\n"
            f"  timestamp      : {self.timestamp}"
        )


@dataclass
class SnapshotRecord:
    """In-memory aggregate snapshot record."""

    aggregate_id: str
    aggregate_type: str
    state: dict
    sequence: int
    timestamp: datetime

    def __repr__(self) -> str:
        return (
            f"SnapshotRecord(aggregate_id={self.aggregate_id!r}, "
            f"sequence={self.sequence!r})"
        )

    def __str__(self) -> str:
        return (
            f"SnapshotRecord\n"
            f"  aggregate_id   : {self.aggregate_id!r}\n"
            f"  aggregate_type : {self.aggregate_type!r}\n"
            f"  sequence       : {self.sequence}\n"
            f"  timestamp      : {self.timestamp}"
        )


class EventStore:
    """In-memory append-only event store.

    Internal storage:
    - ``_streams``: dict[aggregate_id, list[EventRecord]] — ordered by sequence
    - ``_snapshots``: dict[aggregate_id, SnapshotRecord]
    - ``_projections``: dict[event_type, list[Callable]]

    Requirements: 13.1–13.6, 15.1, 15.2, 15.5
    """

    def __init__(self) -> None:
        self._streams: dict[str, list[EventRecord]] = {}
        self._snapshots: dict[str, SnapshotRecord] = {}
        self._projections: dict[str, list[Callable[[EventRecord], None]]] = {}

    # ------------------------------------------------------------------
    # Core API
    # ------------------------------------------------------------------

    def append(
        self,
        aggregate_id: str,
        aggregate_type: str,
        event_type: str,
        payload: dict,
        expected_seq: Optional[int] = None,
    ) -> EventRecord:
        """Append a new event to the aggregate stream.

        Assigns the next 1-based sequence number.  Raises ``ConcurrencyConflict``
        when ``expected_seq`` is provided and does not match the current head.

        Requirements: 13.1, 13.2, 13.4
        """
        stream = self._streams.setdefault(aggregate_id, [])
        current_head = stream[-1].sequence if stream else 0

        if expected_seq is not None and expected_seq != current_head:
            raise ConcurrencyConflict(
                aggregate_id=aggregate_id,
                expected_seq=expected_seq,
                actual_seq=current_head,
            )

        record = EventRecord(
            aggregate_id=aggregate_id,
            aggregate_type=aggregate_type,
            event_type=event_type,
            payload=payload,
            schema_version=1,
            sequence=current_head + 1,
            timestamp=datetime.now(tz=timezone.utc),
        )
        stream.append(record)

        # Invoke registered projections for this event type
        for handler in self._projections.get(event_type, []):
            handler(record)

        return record

    def load(self, aggregate_id: str, after_seq: int = 0) -> list[EventRecord]:
        """Return events for ``aggregate_id`` with sequence > ``after_seq``.

        Requirements: 13.3
        """
        stream = self._streams.get(aggregate_id, [])
        return [e for e in stream if e.sequence > after_seq]

    def project(self, event_type: str, handler: Callable[[EventRecord], None]) -> None:
        """Register a projection handler called on every future append of ``event_type``.

        Requirements: 13.5
        """
        self._projections.setdefault(event_type, []).append(handler)

    def save_snapshot(self, aggregate_id: str, state: dict, seq: int) -> None:
        """Persist a snapshot for ``aggregate_id`` at sequence ``seq``.

        Requirements: 13.6
        """
        # Derive aggregate_type from the stream if available
        stream = self._streams.get(aggregate_id, [])
        aggregate_type = stream[0].aggregate_type if stream else ""

        self._snapshots[aggregate_id] = SnapshotRecord(
            aggregate_id=aggregate_id,
            aggregate_type=aggregate_type,
            state=state,
            sequence=seq,
            timestamp=datetime.now(tz=timezone.utc),
        )

    def load_snapshot(self, aggregate_id: str) -> Optional[SnapshotRecord]:
        """Return the latest snapshot for ``aggregate_id``, or ``None``.

        Requirements: 13.6
        """
        return self._snapshots.get(aggregate_id)

    def replay_log(self, aggregate_id: str) -> str:
        """Return a human-readable replay log for all events in the stream.

        Format: ``"seq=1 type=OrderCreated\\nseq=2 type=OrderShipped\\n"``

        Requirements: 15.5
        """
        stream = self._streams.get(aggregate_id, [])
        lines = [f"seq={e.sequence} type={e.event_type}" for e in stream]
        return "\n".join(lines) + ("\n" if lines else "")

    # ------------------------------------------------------------------
    # Dunder helpers
    # ------------------------------------------------------------------

    def __repr__(self) -> str:
        return (
            f"EventStore(streams={len(self._streams)}, "
            f"snapshots={len(self._snapshots)}, "
            f"projections={len(self._projections)})"
        )

    def __str__(self) -> str:
        return (
            f"EventStore\n"
            f"  streams     : {len(self._streams)}\n"
            f"  snapshots   : {len(self._snapshots)}\n"
            f"  projections : {len(self._projections)}"
        )
