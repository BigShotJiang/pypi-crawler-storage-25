"""
dmr_toolkit.testing.repository
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
In-memory Repository test double.

Dict-backed ``Repository[Any, Any]`` subclass suitable for unit tests that
do not require a database.

Requirements: 14.4
"""
from __future__ import annotations

from typing import Any, Optional, Sequence

from dmr_toolkit.patterns.exceptions import NotFound
from dmr_toolkit.patterns.repository import Repository
from dmr_toolkit.patterns.specification import Specification


def _entity_id(entity: Any) -> Any:
    """Return the entity's ``id`` attribute if present, else ``id(entity)``."""
    if hasattr(entity, "id"):
        return entity.id
    return id(entity)


class InMemoryRepository(Repository[Any, Any]):
    """Dict-backed in-memory repository for use in tests.

    Entities are stored by their ``id`` attribute when available, otherwise
    by ``id(entity)`` (Python object identity).

    Raises :exc:`~dmr_toolkit.patterns.exceptions.NotFound` (never
    ``KeyError``) when a requested entity does not exist.

    Requirements: 14.4
    """

    def __init__(self) -> None:
        self._store: dict[Any, Any] = {}

    # ------------------------------------------------------------------
    # get / aget
    # ------------------------------------------------------------------

    def get(self, id: Any) -> Any:
        if id not in self._store:
            raise NotFound(model="InMemoryRepository", id=id)
        return self._store[id]

    async def aget(self, id: Any) -> Any:
        if id not in self._store:
            raise NotFound(model="InMemoryRepository", id=id)
        return self._store[id]

    # ------------------------------------------------------------------
    # list / alist
    # ------------------------------------------------------------------

    def list(self, spec: Optional[Specification] = None) -> Sequence[Any]:
        entities = list(self._store.values())
        if spec is not None:
            return [e for e in entities if spec.is_satisfied_by(e)]
        return entities

    async def alist(self, spec: Optional[Specification] = None) -> Sequence[Any]:
        entities = list(self._store.values())
        if spec is not None:
            return [e for e in entities if spec.is_satisfied_by(e)]
        return entities

    # ------------------------------------------------------------------
    # add / aadd
    # ------------------------------------------------------------------

    def add(self, entity: Any) -> Any:
        key = _entity_id(entity)
        self._store[key] = entity
        return entity

    async def aadd(self, entity: Any) -> Any:
        key = _entity_id(entity)
        self._store[key] = entity
        return entity

    # ------------------------------------------------------------------
    # update / aupdate
    # ------------------------------------------------------------------

    def update(self, entity: Any) -> Any:
        key = _entity_id(entity)
        self._store[key] = entity
        return entity

    async def aupdate(self, entity: Any) -> Any:
        key = _entity_id(entity)
        self._store[key] = entity
        return entity

    # ------------------------------------------------------------------
    # remove / aremove
    # ------------------------------------------------------------------

    def remove(self, id: Any) -> None:
        self._store.pop(id, None)

    async def aremove(self, id: Any) -> None:
        self._store.pop(id, None)

    # ------------------------------------------------------------------
    # Pretty-printing (Requirements 15.1, 15.2)
    # ------------------------------------------------------------------

    def __repr__(self) -> str:
        return f"InMemoryRepository(size={len(self._store)})"

    def __str__(self) -> str:
        return (
            f"InMemoryRepository\n"
            f"  entities stored: {len(self._store)}"
        )
