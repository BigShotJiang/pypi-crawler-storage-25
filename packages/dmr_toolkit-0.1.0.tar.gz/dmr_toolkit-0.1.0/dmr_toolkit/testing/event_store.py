"""
dmr_toolkit.testing.event_store
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Fake EventStore test double.

Thin wrapper around the real :class:`~dmr_toolkit.patterns.event_store.EventStore`
that adds a :meth:`reset` method to clear all state between tests.

Requirements: 14.4
"""
from __future__ import annotations

from typing import Callable, Optional

from dmr_toolkit.patterns.event_store import EventRecord, EventStore, SnapshotRecord


class FakeEventStore:
    """In-memory EventStore test double with a ``reset()`` helper.

    Delegates all operations to a real :class:`EventStore` instance so that
    the full production logic is exercised in tests without requiring a
    database.

    Requirements: 14.4
    """

    def __init__(self) -> None:
        self._store = EventStore()

    # ------------------------------------------------------------------
    # Delegated EventStore API
    # ------------------------------------------------------------------

    def append(
        self,
        aggregate_id: str,
        aggregate_type: str,
        event_type: str,
        payload: dict,
        expected_seq: Optional[int] = None,
    ) -> EventRecord:
        """Append a new event — delegates to the underlying :class:`EventStore`."""
        return self._store.append(
            aggregate_id=aggregate_id,
            aggregate_type=aggregate_type,
            event_type=event_type,
            payload=payload,
            expected_seq=expected_seq,
        )

    def load(self, aggregate_id: str, after_seq: int = 0) -> list[EventRecord]:
        """Load events for *aggregate_id* — delegates to the underlying store."""
        return self._store.load(aggregate_id, after_seq=after_seq)

    def project(self, event_type: str, handler: Callable[[EventRecord], None]) -> None:
        """Register a projection handler — delegates to the underlying store."""
        self._store.project(event_type, handler)

    def save_snapshot(self, aggregate_id: str, state: dict, seq: int) -> None:
        """Save a snapshot — delegates to the underlying store."""
        self._store.save_snapshot(aggregate_id, state, seq)

    def load_snapshot(self, aggregate_id: str) -> Optional[SnapshotRecord]:
        """Load the latest snapshot — delegates to the underlying store."""
        return self._store.load_snapshot(aggregate_id)

    def replay_log(self, aggregate_id: str) -> str:
        """Return a human-readable replay log — delegates to the underlying store."""
        return self._store.replay_log(aggregate_id)

    # ------------------------------------------------------------------
    # Test helper
    # ------------------------------------------------------------------

    def reset(self) -> None:
        """Clear all stored events, snapshots, and projections.

        Call this in test ``teardown`` or ``setup`` to ensure a clean slate
        between test cases.
        """
        self._store = EventStore()

    # ------------------------------------------------------------------
    # Pretty-printing (Requirements 15.1, 15.2)
    # ------------------------------------------------------------------

    def __repr__(self) -> str:
        inner = repr(self._store)
        return f"FakeEventStore(inner={inner})"

    def __str__(self) -> str:
        return (
            f"FakeEventStore\n"
            f"  streams     : {len(self._store._streams)}\n"
            f"  snapshots   : {len(self._store._snapshots)}\n"
            f"  projections : {len(self._store._projections)}"
        )
