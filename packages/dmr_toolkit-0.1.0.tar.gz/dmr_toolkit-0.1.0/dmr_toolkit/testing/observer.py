"""
dmr_toolkit.testing.observer
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
MockObserver test double.

Records all emitted events so that tests can assert on what was emitted
without requiring a real EventBus or side-effect handlers.

Requirements: 14.4
"""
from __future__ import annotations

from typing import Any, Optional


class MockObserver:
    """Records emitted events for assertion in tests.

    Instead of dispatching events to real handlers, :meth:`emit` stores
    each ``(event_type, payload)`` pair internally.  Tests can then use
    :meth:`assert_emitted` and :meth:`get_emitted` to verify behaviour.

    Requirements: 14.4
    """

    def __init__(self) -> None:
        # Maps event_type -> list of payloads
        self._records: dict[str, list[Any]] = {}

    # ------------------------------------------------------------------
    # Emit
    # ------------------------------------------------------------------

    def emit(self, event_type: str, payload: Any = None) -> None:
        """Record an event instead of dispatching it.

        Args:
            event_type: The name of the event (e.g. ``"order.created"``).
            payload: Arbitrary payload associated with the event.
        """
        self._records.setdefault(event_type, []).append(payload)

    # ------------------------------------------------------------------
    # Assertion helpers
    # ------------------------------------------------------------------

    def assert_emitted(self, event_type: str, payload: Optional[Any] = None) -> None:
        """Assert that *event_type* was emitted at least once.

        If *payload* is provided, also asserts that at least one emission
        carried that exact payload.

        Raises:
            AssertionError: if the event was not emitted, or if *payload* is
                provided and no matching payload was recorded.
        """
        if event_type not in self._records or not self._records[event_type]:
            raise AssertionError(
                f"Expected event {event_type!r} to have been emitted, "
                f"but it was not. Recorded events: {list(self._records.keys())!r}"
            )
        if payload is not None:
            payloads = self._records[event_type]
            if payload not in payloads:
                raise AssertionError(
                    f"Expected event {event_type!r} with payload {payload!r}, "
                    f"but recorded payloads were: {payloads!r}"
                )

    def get_emitted(self, event_type: str) -> list[Any]:
        """Return the list of payloads recorded for *event_type*.

        Returns an empty list if the event was never emitted.
        """
        return list(self._records.get(event_type, []))

    # ------------------------------------------------------------------
    # Reset
    # ------------------------------------------------------------------

    def clear(self) -> None:
        """Clear all recorded events."""
        self._records.clear()

    # ------------------------------------------------------------------
    # Pretty-printing (Requirements 15.1, 15.2)
    # ------------------------------------------------------------------

    def __repr__(self) -> str:
        total = sum(len(v) for v in self._records.values())
        return f"MockObserver(event_types={len(self._records)}, total_emissions={total})"

    def __str__(self) -> str:
        lines = [f"MockObserver with {len(self._records)} event type(s):"]
        for event_type, payloads in self._records.items():
            lines.append(f"  {event_type!r}: {len(payloads)} emission(s)")
        return "\n".join(lines)
