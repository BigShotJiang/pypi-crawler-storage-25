"""
dmr_toolkit.testing
~~~~~~~~~~~~~~~~~~~~
Test doubles for each pattern in dmr_toolkit.patterns.

Provides:
- InMemoryRepository: Dict-backed Repository for use in tests
- FakeEventStore: In-memory EventStore with reset() support
- MockObserver: Records emitted events for assertion
- StrategyTestCase: Base pytest class that isolates the strategy registry per test

Requirements: 14.4
"""
from dmr_toolkit.testing.repository import InMemoryRepository
from dmr_toolkit.testing.event_store import FakeEventStore
from dmr_toolkit.testing.observer import MockObserver
from dmr_toolkit.testing.strategy import StrategyTestCase

__all__ = ["InMemoryRepository", "FakeEventStore", "MockObserver", "StrategyTestCase"]
