"""
dmr_toolkit.testing.strategy
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
StrategyTestCase — base pytest class that isolates the Strategy registry per test.

Saves and restores ``Strategy._registry`` and all subclass registries around
each test method so that registrations in one test cannot leak into another.

Requirements: 14.4
"""
from __future__ import annotations

import copy
from typing import Any


class StrategyTestCase:
    """Base pytest class that isolates the Strategy registry per test.

    Subclass this in your test classes to ensure that any ``Strategy``
    registrations made during a test are automatically rolled back when the
    test finishes.

    Example::

        class TestMyStrategy(StrategyTestCase):
            def test_register_and_resolve(self):
                @MyStrategy.register("test")
                class TestImpl(MyStrategy):
                    def execute(self): return "ok"

                assert MyStrategy.resolve("test") is TestImpl
            # registry is restored after this test

    Requirements: 14.4
    """

    def setup_method(self, method: Any = None) -> None:
        """Save the current registry state for all Strategy subclasses."""
        from dmr_toolkit.patterns.strategy import Strategy

        # Collect Strategy and every subclass that has its own _registry
        self._saved_registries: dict[type, dict] = {}
        self._strategy_cls = Strategy

        classes_to_save = [Strategy] + self._collect_subclasses(Strategy)
        for cls in classes_to_save:
            if "_registry" in cls.__dict__:
                self._saved_registries[cls] = copy.copy(cls._registry)

    def teardown_method(self, method: Any = None) -> None:
        """Restore all Strategy registries to their pre-test state."""
        from dmr_toolkit.patterns.strategy import Strategy

        # Restore saved registries
        for cls, registry in self._saved_registries.items():
            cls._registry = registry

        # Remove any new subclasses that were created during the test
        # by clearing registries on classes not in the saved set
        all_current = [Strategy] + self._collect_subclasses(Strategy)
        for cls in all_current:
            if cls not in self._saved_registries and "_registry" in cls.__dict__:
                cls._registry = {}

    @staticmethod
    def _collect_subclasses(cls: type) -> list[type]:
        """Recursively collect all subclasses of *cls*."""
        result: list[type] = []
        for sub in cls.__subclasses__():
            result.append(sub)
            result.extend(StrategyTestCase._collect_subclasses(sub))
        return result

    # ------------------------------------------------------------------
    # Pretty-printing (Requirements 15.1, 15.2)
    # ------------------------------------------------------------------

    def __repr__(self) -> str:
        saved = getattr(self, "_saved_registries", {})
        return f"StrategyTestCase(saved_classes={len(saved)})"

    def __str__(self) -> str:
        saved = getattr(self, "_saved_registries", {})
        return (
            f"StrategyTestCase\n"
            f"  saved registry snapshots: {len(saved)}"
        )
