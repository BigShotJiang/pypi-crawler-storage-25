"""Abstract base class for SQL executors."""

from abc import ABC, abstractmethod


class BaseExecutor(ABC):
    """Abstract interface for warehouse SQL execution."""

    @abstractmethod
    async def execute(self, sql: str) -> list[dict]:
        """Execute SQL and return list of row dicts."""

    @abstractmethod
    async def test_connection(self) -> bool:
        """Ping the warehouse. Used on startup."""

    @abstractmethod
    def get_adapter_type(self) -> str:
        """Returns 'postgres' | 'bigquery' | 'snowflake' | 'duckdb'."""
