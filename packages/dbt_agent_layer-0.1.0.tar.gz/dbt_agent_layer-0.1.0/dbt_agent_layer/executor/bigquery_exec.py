"""BigQuery executor adapter."""

import asyncio
import logging
from typing import Any

from .base import BaseExecutor

logger = logging.getLogger(__name__)


class BigQueryExecutor(BaseExecutor):
    """Execute SQL against Google BigQuery (async via run_in_executor)."""

    def __init__(
        self,
        project: str = "",
        dataset: str = "",
        keyfile: str | None = None,
        **kwargs: Any,
    ) -> None:
        self._project = project
        self._dataset = dataset
        self._keyfile = keyfile
        self._client: Any = None

    def _get_client(self) -> Any:
        """Lazy-init BigQuery client."""
        if self._client is None:
            try:
                from google.cloud import bigquery
                from google.oauth2 import service_account
            except ImportError:
                raise ImportError(
                    "google-cloud-bigquery is not installed. "
                    "Run: pip install 'dbt-agent-layer[bigquery]'"
                )
            if self._keyfile:
                credentials = service_account.Credentials.from_service_account_file(
                    self._keyfile,
                    scopes=["https://www.googleapis.com/auth/bigquery"],
                )
                self._client = bigquery.Client(
                    project=self._project, credentials=credentials
                )
            else:
                # Use Application Default Credentials
                self._client = bigquery.Client(project=self._project)
        return self._client

    async def execute(self, sql: str) -> list[dict]:
        """Execute SQL and return list of row dicts."""
        logger.debug("BigQuery executing: %s", sql[:200])
        client = self._get_client()

        def _run() -> list[dict]:
            job = client.query(sql)
            rows = job.result()
            return [dict(row) for row in rows]

        return await asyncio.get_event_loop().run_in_executor(None, _run)

    async def test_connection(self) -> bool:
        """Test BigQuery connectivity."""
        try:
            await self.execute("SELECT 1")
            return True
        except Exception as e:
            logger.error("BigQuery connection test failed: %s", e)
            return False

    def get_adapter_type(self) -> str:
        return "bigquery"
